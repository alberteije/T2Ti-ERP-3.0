// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'database.dart';

// ignore_for_file: type=lint
class $GedDocumentoDetalhesTable extends GedDocumentoDetalhes
    with TableInfo<$GedDocumentoDetalhesTable, GedDocumentoDetalhe> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $GedDocumentoDetalhesTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
    'id',
    aliasedName,
    true,
    type: DriftSqlType.int,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _idGedDocumentoCabecalhoMeta =
      const VerificationMeta('idGedDocumentoCabecalho');
  @override
  late final GeneratedColumn<int> idGedDocumentoCabecalho =
      GeneratedColumn<int>(
        'id_ged_documento_cabecalho',
        aliasedName,
        true,
        type: DriftSqlType.int,
        requiredDuringInsert: false,
      );
  static const VerificationMeta _idGedTipoDocumentoMeta =
      const VerificationMeta('idGedTipoDocumento');
  @override
  late final GeneratedColumn<int> idGedTipoDocumento = GeneratedColumn<int>(
    'id_ged_tipo_documento',
    aliasedName,
    true,
    type: DriftSqlType.int,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _nomeMeta = const VerificationMeta('nome');
  @override
  late final GeneratedColumn<String> nome = GeneratedColumn<String>(
    'nome',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 100,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _descricaoMeta = const VerificationMeta(
    'descricao',
  );
  @override
  late final GeneratedColumn<String> descricao = GeneratedColumn<String>(
    'descricao',
    aliasedName,
    true,
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _palavrasChaveMeta = const VerificationMeta(
    'palavrasChave',
  );
  @override
  late final GeneratedColumn<String> palavrasChave = GeneratedColumn<String>(
    'palavras_chave',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 250,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _podeExcluirMeta = const VerificationMeta(
    'podeExcluir',
  );
  @override
  late final GeneratedColumn<String> podeExcluir = GeneratedColumn<String>(
    'pode_excluir',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 1,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _podeAlterarMeta = const VerificationMeta(
    'podeAlterar',
  );
  @override
  late final GeneratedColumn<String> podeAlterar = GeneratedColumn<String>(
    'pode_alterar',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 1,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _assinadoMeta = const VerificationMeta(
    'assinado',
  );
  @override
  late final GeneratedColumn<String> assinado = GeneratedColumn<String>(
    'assinado',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 1,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _dataFimVigenciaMeta = const VerificationMeta(
    'dataFimVigencia',
  );
  @override
  late final GeneratedColumn<DateTime> dataFimVigencia =
      GeneratedColumn<DateTime>(
        'data_fim_vigencia',
        aliasedName,
        true,
        type: DriftSqlType.dateTime,
        requiredDuringInsert: false,
      );
  static const VerificationMeta _dataExclusaoMeta = const VerificationMeta(
    'dataExclusao',
  );
  @override
  late final GeneratedColumn<DateTime> dataExclusao = GeneratedColumn<DateTime>(
    'data_exclusao',
    aliasedName,
    true,
    type: DriftSqlType.dateTime,
    requiredDuringInsert: false,
  );
  @override
  List<GeneratedColumn> get $columns => [
    id,
    idGedDocumentoCabecalho,
    idGedTipoDocumento,
    nome,
    descricao,
    palavrasChave,
    podeExcluir,
    podeAlterar,
    assinado,
    dataFimVigencia,
    dataExclusao,
  ];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'ged_documento_detalhe';
  @override
  VerificationContext validateIntegrity(
    Insertable<GedDocumentoDetalhe> instance, {
    bool isInserting = false,
  }) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('id_ged_documento_cabecalho')) {
      context.handle(
        _idGedDocumentoCabecalhoMeta,
        idGedDocumentoCabecalho.isAcceptableOrUnknown(
          data['id_ged_documento_cabecalho']!,
          _idGedDocumentoCabecalhoMeta,
        ),
      );
    }
    if (data.containsKey('id_ged_tipo_documento')) {
      context.handle(
        _idGedTipoDocumentoMeta,
        idGedTipoDocumento.isAcceptableOrUnknown(
          data['id_ged_tipo_documento']!,
          _idGedTipoDocumentoMeta,
        ),
      );
    }
    if (data.containsKey('nome')) {
      context.handle(
        _nomeMeta,
        nome.isAcceptableOrUnknown(data['nome']!, _nomeMeta),
      );
    }
    if (data.containsKey('descricao')) {
      context.handle(
        _descricaoMeta,
        descricao.isAcceptableOrUnknown(data['descricao']!, _descricaoMeta),
      );
    }
    if (data.containsKey('palavras_chave')) {
      context.handle(
        _palavrasChaveMeta,
        palavrasChave.isAcceptableOrUnknown(
          data['palavras_chave']!,
          _palavrasChaveMeta,
        ),
      );
    }
    if (data.containsKey('pode_excluir')) {
      context.handle(
        _podeExcluirMeta,
        podeExcluir.isAcceptableOrUnknown(
          data['pode_excluir']!,
          _podeExcluirMeta,
        ),
      );
    }
    if (data.containsKey('pode_alterar')) {
      context.handle(
        _podeAlterarMeta,
        podeAlterar.isAcceptableOrUnknown(
          data['pode_alterar']!,
          _podeAlterarMeta,
        ),
      );
    }
    if (data.containsKey('assinado')) {
      context.handle(
        _assinadoMeta,
        assinado.isAcceptableOrUnknown(data['assinado']!, _assinadoMeta),
      );
    }
    if (data.containsKey('data_fim_vigencia')) {
      context.handle(
        _dataFimVigenciaMeta,
        dataFimVigencia.isAcceptableOrUnknown(
          data['data_fim_vigencia']!,
          _dataFimVigenciaMeta,
        ),
      );
    }
    if (data.containsKey('data_exclusao')) {
      context.handle(
        _dataExclusaoMeta,
        dataExclusao.isAcceptableOrUnknown(
          data['data_exclusao']!,
          _dataExclusaoMeta,
        ),
      );
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  GedDocumentoDetalhe map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return GedDocumentoDetalhe(
      id: attachedDatabase.typeMapping.read(
        DriftSqlType.int,
        data['${effectivePrefix}id'],
      ),
      idGedDocumentoCabecalho: attachedDatabase.typeMapping.read(
        DriftSqlType.int,
        data['${effectivePrefix}id_ged_documento_cabecalho'],
      ),
      idGedTipoDocumento: attachedDatabase.typeMapping.read(
        DriftSqlType.int,
        data['${effectivePrefix}id_ged_tipo_documento'],
      ),
      nome: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}nome'],
      ),
      descricao: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}descricao'],
      ),
      palavrasChave: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}palavras_chave'],
      ),
      podeExcluir: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}pode_excluir'],
      ),
      podeAlterar: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}pode_alterar'],
      ),
      assinado: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}assinado'],
      ),
      dataFimVigencia: attachedDatabase.typeMapping.read(
        DriftSqlType.dateTime,
        data['${effectivePrefix}data_fim_vigencia'],
      ),
      dataExclusao: attachedDatabase.typeMapping.read(
        DriftSqlType.dateTime,
        data['${effectivePrefix}data_exclusao'],
      ),
    );
  }

  @override
  $GedDocumentoDetalhesTable createAlias(String alias) {
    return $GedDocumentoDetalhesTable(attachedDatabase, alias);
  }
}

class GedDocumentoDetalhe extends DataClass
    implements Insertable<GedDocumentoDetalhe> {
  final int? id;
  final int? idGedDocumentoCabecalho;
  final int? idGedTipoDocumento;
  final String? nome;
  final String? descricao;
  final String? palavrasChave;
  final String? podeExcluir;
  final String? podeAlterar;
  final String? assinado;
  final DateTime? dataFimVigencia;
  final DateTime? dataExclusao;
  const GedDocumentoDetalhe({
    this.id,
    this.idGedDocumentoCabecalho,
    this.idGedTipoDocumento,
    this.nome,
    this.descricao,
    this.palavrasChave,
    this.podeExcluir,
    this.podeAlterar,
    this.assinado,
    this.dataFimVigencia,
    this.dataExclusao,
  });
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || idGedDocumentoCabecalho != null) {
      map['id_ged_documento_cabecalho'] = Variable<int>(
        idGedDocumentoCabecalho,
      );
    }
    if (!nullToAbsent || idGedTipoDocumento != null) {
      map['id_ged_tipo_documento'] = Variable<int>(idGedTipoDocumento);
    }
    if (!nullToAbsent || nome != null) {
      map['nome'] = Variable<String>(nome);
    }
    if (!nullToAbsent || descricao != null) {
      map['descricao'] = Variable<String>(descricao);
    }
    if (!nullToAbsent || palavrasChave != null) {
      map['palavras_chave'] = Variable<String>(palavrasChave);
    }
    if (!nullToAbsent || podeExcluir != null) {
      map['pode_excluir'] = Variable<String>(podeExcluir);
    }
    if (!nullToAbsent || podeAlterar != null) {
      map['pode_alterar'] = Variable<String>(podeAlterar);
    }
    if (!nullToAbsent || assinado != null) {
      map['assinado'] = Variable<String>(assinado);
    }
    if (!nullToAbsent || dataFimVigencia != null) {
      map['data_fim_vigencia'] = Variable<DateTime>(dataFimVigencia);
    }
    if (!nullToAbsent || dataExclusao != null) {
      map['data_exclusao'] = Variable<DateTime>(dataExclusao);
    }
    return map;
  }

  factory GedDocumentoDetalhe.fromJson(
    Map<String, dynamic> json, {
    ValueSerializer? serializer,
  }) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return GedDocumentoDetalhe(
      id: serializer.fromJson<int?>(json['id']),
      idGedDocumentoCabecalho: serializer.fromJson<int?>(
        json['idGedDocumentoCabecalho'],
      ),
      idGedTipoDocumento: serializer.fromJson<int?>(json['idGedTipoDocumento']),
      nome: serializer.fromJson<String?>(json['nome']),
      descricao: serializer.fromJson<String?>(json['descricao']),
      palavrasChave: serializer.fromJson<String?>(json['palavrasChave']),
      podeExcluir: serializer.fromJson<String?>(json['podeExcluir']),
      podeAlterar: serializer.fromJson<String?>(json['podeAlterar']),
      assinado: serializer.fromJson<String?>(json['assinado']),
      dataFimVigencia: serializer.fromJson<DateTime?>(json['dataFimVigencia']),
      dataExclusao: serializer.fromJson<DateTime?>(json['dataExclusao']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'idGedDocumentoCabecalho': serializer.toJson<int?>(
        idGedDocumentoCabecalho,
      ),
      'idGedTipoDocumento': serializer.toJson<int?>(idGedTipoDocumento),
      'nome': serializer.toJson<String?>(nome),
      'descricao': serializer.toJson<String?>(descricao),
      'palavrasChave': serializer.toJson<String?>(palavrasChave),
      'podeExcluir': serializer.toJson<String?>(podeExcluir),
      'podeAlterar': serializer.toJson<String?>(podeAlterar),
      'assinado': serializer.toJson<String?>(assinado),
      'dataFimVigencia': serializer.toJson<DateTime?>(dataFimVigencia),
      'dataExclusao': serializer.toJson<DateTime?>(dataExclusao),
    };
  }

  GedDocumentoDetalhe copyWith({
    Value<int?> id = const Value.absent(),
    Value<int?> idGedDocumentoCabecalho = const Value.absent(),
    Value<int?> idGedTipoDocumento = const Value.absent(),
    Value<String?> nome = const Value.absent(),
    Value<String?> descricao = const Value.absent(),
    Value<String?> palavrasChave = const Value.absent(),
    Value<String?> podeExcluir = const Value.absent(),
    Value<String?> podeAlterar = const Value.absent(),
    Value<String?> assinado = const Value.absent(),
    Value<DateTime?> dataFimVigencia = const Value.absent(),
    Value<DateTime?> dataExclusao = const Value.absent(),
  }) => GedDocumentoDetalhe(
    id: id.present ? id.value : this.id,
    idGedDocumentoCabecalho:
        idGedDocumentoCabecalho.present
            ? idGedDocumentoCabecalho.value
            : this.idGedDocumentoCabecalho,
    idGedTipoDocumento:
        idGedTipoDocumento.present
            ? idGedTipoDocumento.value
            : this.idGedTipoDocumento,
    nome: nome.present ? nome.value : this.nome,
    descricao: descricao.present ? descricao.value : this.descricao,
    palavrasChave:
        palavrasChave.present ? palavrasChave.value : this.palavrasChave,
    podeExcluir: podeExcluir.present ? podeExcluir.value : this.podeExcluir,
    podeAlterar: podeAlterar.present ? podeAlterar.value : this.podeAlterar,
    assinado: assinado.present ? assinado.value : this.assinado,
    dataFimVigencia:
        dataFimVigencia.present ? dataFimVigencia.value : this.dataFimVigencia,
    dataExclusao: dataExclusao.present ? dataExclusao.value : this.dataExclusao,
  );
  GedDocumentoDetalhe copyWithCompanion(GedDocumentoDetalhesCompanion data) {
    return GedDocumentoDetalhe(
      id: data.id.present ? data.id.value : this.id,
      idGedDocumentoCabecalho:
          data.idGedDocumentoCabecalho.present
              ? data.idGedDocumentoCabecalho.value
              : this.idGedDocumentoCabecalho,
      idGedTipoDocumento:
          data.idGedTipoDocumento.present
              ? data.idGedTipoDocumento.value
              : this.idGedTipoDocumento,
      nome: data.nome.present ? data.nome.value : this.nome,
      descricao: data.descricao.present ? data.descricao.value : this.descricao,
      palavrasChave:
          data.palavrasChave.present
              ? data.palavrasChave.value
              : this.palavrasChave,
      podeExcluir:
          data.podeExcluir.present ? data.podeExcluir.value : this.podeExcluir,
      podeAlterar:
          data.podeAlterar.present ? data.podeAlterar.value : this.podeAlterar,
      assinado: data.assinado.present ? data.assinado.value : this.assinado,
      dataFimVigencia:
          data.dataFimVigencia.present
              ? data.dataFimVigencia.value
              : this.dataFimVigencia,
      dataExclusao:
          data.dataExclusao.present
              ? data.dataExclusao.value
              : this.dataExclusao,
    );
  }

  @override
  String toString() {
    return (StringBuffer('GedDocumentoDetalhe(')
          ..write('id: $id, ')
          ..write('idGedDocumentoCabecalho: $idGedDocumentoCabecalho, ')
          ..write('idGedTipoDocumento: $idGedTipoDocumento, ')
          ..write('nome: $nome, ')
          ..write('descricao: $descricao, ')
          ..write('palavrasChave: $palavrasChave, ')
          ..write('podeExcluir: $podeExcluir, ')
          ..write('podeAlterar: $podeAlterar, ')
          ..write('assinado: $assinado, ')
          ..write('dataFimVigencia: $dataFimVigencia, ')
          ..write('dataExclusao: $dataExclusao')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(
    id,
    idGedDocumentoCabecalho,
    idGedTipoDocumento,
    nome,
    descricao,
    palavrasChave,
    podeExcluir,
    podeAlterar,
    assinado,
    dataFimVigencia,
    dataExclusao,
  );
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is GedDocumentoDetalhe &&
          other.id == this.id &&
          other.idGedDocumentoCabecalho == this.idGedDocumentoCabecalho &&
          other.idGedTipoDocumento == this.idGedTipoDocumento &&
          other.nome == this.nome &&
          other.descricao == this.descricao &&
          other.palavrasChave == this.palavrasChave &&
          other.podeExcluir == this.podeExcluir &&
          other.podeAlterar == this.podeAlterar &&
          other.assinado == this.assinado &&
          other.dataFimVigencia == this.dataFimVigencia &&
          other.dataExclusao == this.dataExclusao);
}

class GedDocumentoDetalhesCompanion
    extends UpdateCompanion<GedDocumentoDetalhe> {
  final Value<int?> id;
  final Value<int?> idGedDocumentoCabecalho;
  final Value<int?> idGedTipoDocumento;
  final Value<String?> nome;
  final Value<String?> descricao;
  final Value<String?> palavrasChave;
  final Value<String?> podeExcluir;
  final Value<String?> podeAlterar;
  final Value<String?> assinado;
  final Value<DateTime?> dataFimVigencia;
  final Value<DateTime?> dataExclusao;
  const GedDocumentoDetalhesCompanion({
    this.id = const Value.absent(),
    this.idGedDocumentoCabecalho = const Value.absent(),
    this.idGedTipoDocumento = const Value.absent(),
    this.nome = const Value.absent(),
    this.descricao = const Value.absent(),
    this.palavrasChave = const Value.absent(),
    this.podeExcluir = const Value.absent(),
    this.podeAlterar = const Value.absent(),
    this.assinado = const Value.absent(),
    this.dataFimVigencia = const Value.absent(),
    this.dataExclusao = const Value.absent(),
  });
  GedDocumentoDetalhesCompanion.insert({
    this.id = const Value.absent(),
    this.idGedDocumentoCabecalho = const Value.absent(),
    this.idGedTipoDocumento = const Value.absent(),
    this.nome = const Value.absent(),
    this.descricao = const Value.absent(),
    this.palavrasChave = const Value.absent(),
    this.podeExcluir = const Value.absent(),
    this.podeAlterar = const Value.absent(),
    this.assinado = const Value.absent(),
    this.dataFimVigencia = const Value.absent(),
    this.dataExclusao = const Value.absent(),
  });
  static Insertable<GedDocumentoDetalhe> custom({
    Expression<int>? id,
    Expression<int>? idGedDocumentoCabecalho,
    Expression<int>? idGedTipoDocumento,
    Expression<String>? nome,
    Expression<String>? descricao,
    Expression<String>? palavrasChave,
    Expression<String>? podeExcluir,
    Expression<String>? podeAlterar,
    Expression<String>? assinado,
    Expression<DateTime>? dataFimVigencia,
    Expression<DateTime>? dataExclusao,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (idGedDocumentoCabecalho != null)
        'id_ged_documento_cabecalho': idGedDocumentoCabecalho,
      if (idGedTipoDocumento != null)
        'id_ged_tipo_documento': idGedTipoDocumento,
      if (nome != null) 'nome': nome,
      if (descricao != null) 'descricao': descricao,
      if (palavrasChave != null) 'palavras_chave': palavrasChave,
      if (podeExcluir != null) 'pode_excluir': podeExcluir,
      if (podeAlterar != null) 'pode_alterar': podeAlterar,
      if (assinado != null) 'assinado': assinado,
      if (dataFimVigencia != null) 'data_fim_vigencia': dataFimVigencia,
      if (dataExclusao != null) 'data_exclusao': dataExclusao,
    });
  }

  GedDocumentoDetalhesCompanion copyWith({
    Value<int?>? id,
    Value<int?>? idGedDocumentoCabecalho,
    Value<int?>? idGedTipoDocumento,
    Value<String?>? nome,
    Value<String?>? descricao,
    Value<String?>? palavrasChave,
    Value<String?>? podeExcluir,
    Value<String?>? podeAlterar,
    Value<String?>? assinado,
    Value<DateTime?>? dataFimVigencia,
    Value<DateTime?>? dataExclusao,
  }) {
    return GedDocumentoDetalhesCompanion(
      id: id ?? this.id,
      idGedDocumentoCabecalho:
          idGedDocumentoCabecalho ?? this.idGedDocumentoCabecalho,
      idGedTipoDocumento: idGedTipoDocumento ?? this.idGedTipoDocumento,
      nome: nome ?? this.nome,
      descricao: descricao ?? this.descricao,
      palavrasChave: palavrasChave ?? this.palavrasChave,
      podeExcluir: podeExcluir ?? this.podeExcluir,
      podeAlterar: podeAlterar ?? this.podeAlterar,
      assinado: assinado ?? this.assinado,
      dataFimVigencia: dataFimVigencia ?? this.dataFimVigencia,
      dataExclusao: dataExclusao ?? this.dataExclusao,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (idGedDocumentoCabecalho.present) {
      map['id_ged_documento_cabecalho'] = Variable<int>(
        idGedDocumentoCabecalho.value,
      );
    }
    if (idGedTipoDocumento.present) {
      map['id_ged_tipo_documento'] = Variable<int>(idGedTipoDocumento.value);
    }
    if (nome.present) {
      map['nome'] = Variable<String>(nome.value);
    }
    if (descricao.present) {
      map['descricao'] = Variable<String>(descricao.value);
    }
    if (palavrasChave.present) {
      map['palavras_chave'] = Variable<String>(palavrasChave.value);
    }
    if (podeExcluir.present) {
      map['pode_excluir'] = Variable<String>(podeExcluir.value);
    }
    if (podeAlterar.present) {
      map['pode_alterar'] = Variable<String>(podeAlterar.value);
    }
    if (assinado.present) {
      map['assinado'] = Variable<String>(assinado.value);
    }
    if (dataFimVigencia.present) {
      map['data_fim_vigencia'] = Variable<DateTime>(dataFimVigencia.value);
    }
    if (dataExclusao.present) {
      map['data_exclusao'] = Variable<DateTime>(dataExclusao.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('GedDocumentoDetalhesCompanion(')
          ..write('id: $id, ')
          ..write('idGedDocumentoCabecalho: $idGedDocumentoCabecalho, ')
          ..write('idGedTipoDocumento: $idGedTipoDocumento, ')
          ..write('nome: $nome, ')
          ..write('descricao: $descricao, ')
          ..write('palavrasChave: $palavrasChave, ')
          ..write('podeExcluir: $podeExcluir, ')
          ..write('podeAlterar: $podeAlterar, ')
          ..write('assinado: $assinado, ')
          ..write('dataFimVigencia: $dataFimVigencia, ')
          ..write('dataExclusao: $dataExclusao')
          ..write(')'))
        .toString();
  }
}

class $GedDocumentoCabecalhosTable extends GedDocumentoCabecalhos
    with TableInfo<$GedDocumentoCabecalhosTable, GedDocumentoCabecalho> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $GedDocumentoCabecalhosTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
    'id',
    aliasedName,
    true,
    type: DriftSqlType.int,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _nomeMeta = const VerificationMeta('nome');
  @override
  late final GeneratedColumn<String> nome = GeneratedColumn<String>(
    'nome',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 100,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _dataInclusaoMeta = const VerificationMeta(
    'dataInclusao',
  );
  @override
  late final GeneratedColumn<DateTime> dataInclusao = GeneratedColumn<DateTime>(
    'data_inclusao',
    aliasedName,
    true,
    type: DriftSqlType.dateTime,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _descricaoMeta = const VerificationMeta(
    'descricao',
  );
  @override
  late final GeneratedColumn<String> descricao = GeneratedColumn<String>(
    'descricao',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 250,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  @override
  List<GeneratedColumn> get $columns => [id, nome, dataInclusao, descricao];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'ged_documento_cabecalho';
  @override
  VerificationContext validateIntegrity(
    Insertable<GedDocumentoCabecalho> instance, {
    bool isInserting = false,
  }) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('nome')) {
      context.handle(
        _nomeMeta,
        nome.isAcceptableOrUnknown(data['nome']!, _nomeMeta),
      );
    }
    if (data.containsKey('data_inclusao')) {
      context.handle(
        _dataInclusaoMeta,
        dataInclusao.isAcceptableOrUnknown(
          data['data_inclusao']!,
          _dataInclusaoMeta,
        ),
      );
    }
    if (data.containsKey('descricao')) {
      context.handle(
        _descricaoMeta,
        descricao.isAcceptableOrUnknown(data['descricao']!, _descricaoMeta),
      );
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  GedDocumentoCabecalho map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return GedDocumentoCabecalho(
      id: attachedDatabase.typeMapping.read(
        DriftSqlType.int,
        data['${effectivePrefix}id'],
      ),
      nome: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}nome'],
      ),
      dataInclusao: attachedDatabase.typeMapping.read(
        DriftSqlType.dateTime,
        data['${effectivePrefix}data_inclusao'],
      ),
      descricao: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}descricao'],
      ),
    );
  }

  @override
  $GedDocumentoCabecalhosTable createAlias(String alias) {
    return $GedDocumentoCabecalhosTable(attachedDatabase, alias);
  }
}

class GedDocumentoCabecalho extends DataClass
    implements Insertable<GedDocumentoCabecalho> {
  final int? id;
  final String? nome;
  final DateTime? dataInclusao;
  final String? descricao;
  const GedDocumentoCabecalho({
    this.id,
    this.nome,
    this.dataInclusao,
    this.descricao,
  });
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || nome != null) {
      map['nome'] = Variable<String>(nome);
    }
    if (!nullToAbsent || dataInclusao != null) {
      map['data_inclusao'] = Variable<DateTime>(dataInclusao);
    }
    if (!nullToAbsent || descricao != null) {
      map['descricao'] = Variable<String>(descricao);
    }
    return map;
  }

  factory GedDocumentoCabecalho.fromJson(
    Map<String, dynamic> json, {
    ValueSerializer? serializer,
  }) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return GedDocumentoCabecalho(
      id: serializer.fromJson<int?>(json['id']),
      nome: serializer.fromJson<String?>(json['nome']),
      dataInclusao: serializer.fromJson<DateTime?>(json['dataInclusao']),
      descricao: serializer.fromJson<String?>(json['descricao']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'nome': serializer.toJson<String?>(nome),
      'dataInclusao': serializer.toJson<DateTime?>(dataInclusao),
      'descricao': serializer.toJson<String?>(descricao),
    };
  }

  GedDocumentoCabecalho copyWith({
    Value<int?> id = const Value.absent(),
    Value<String?> nome = const Value.absent(),
    Value<DateTime?> dataInclusao = const Value.absent(),
    Value<String?> descricao = const Value.absent(),
  }) => GedDocumentoCabecalho(
    id: id.present ? id.value : this.id,
    nome: nome.present ? nome.value : this.nome,
    dataInclusao: dataInclusao.present ? dataInclusao.value : this.dataInclusao,
    descricao: descricao.present ? descricao.value : this.descricao,
  );
  GedDocumentoCabecalho copyWithCompanion(
    GedDocumentoCabecalhosCompanion data,
  ) {
    return GedDocumentoCabecalho(
      id: data.id.present ? data.id.value : this.id,
      nome: data.nome.present ? data.nome.value : this.nome,
      dataInclusao:
          data.dataInclusao.present
              ? data.dataInclusao.value
              : this.dataInclusao,
      descricao: data.descricao.present ? data.descricao.value : this.descricao,
    );
  }

  @override
  String toString() {
    return (StringBuffer('GedDocumentoCabecalho(')
          ..write('id: $id, ')
          ..write('nome: $nome, ')
          ..write('dataInclusao: $dataInclusao, ')
          ..write('descricao: $descricao')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(id, nome, dataInclusao, descricao);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is GedDocumentoCabecalho &&
          other.id == this.id &&
          other.nome == this.nome &&
          other.dataInclusao == this.dataInclusao &&
          other.descricao == this.descricao);
}

class GedDocumentoCabecalhosCompanion
    extends UpdateCompanion<GedDocumentoCabecalho> {
  final Value<int?> id;
  final Value<String?> nome;
  final Value<DateTime?> dataInclusao;
  final Value<String?> descricao;
  const GedDocumentoCabecalhosCompanion({
    this.id = const Value.absent(),
    this.nome = const Value.absent(),
    this.dataInclusao = const Value.absent(),
    this.descricao = const Value.absent(),
  });
  GedDocumentoCabecalhosCompanion.insert({
    this.id = const Value.absent(),
    this.nome = const Value.absent(),
    this.dataInclusao = const Value.absent(),
    this.descricao = const Value.absent(),
  });
  static Insertable<GedDocumentoCabecalho> custom({
    Expression<int>? id,
    Expression<String>? nome,
    Expression<DateTime>? dataInclusao,
    Expression<String>? descricao,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (nome != null) 'nome': nome,
      if (dataInclusao != null) 'data_inclusao': dataInclusao,
      if (descricao != null) 'descricao': descricao,
    });
  }

  GedDocumentoCabecalhosCompanion copyWith({
    Value<int?>? id,
    Value<String?>? nome,
    Value<DateTime?>? dataInclusao,
    Value<String?>? descricao,
  }) {
    return GedDocumentoCabecalhosCompanion(
      id: id ?? this.id,
      nome: nome ?? this.nome,
      dataInclusao: dataInclusao ?? this.dataInclusao,
      descricao: descricao ?? this.descricao,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (nome.present) {
      map['nome'] = Variable<String>(nome.value);
    }
    if (dataInclusao.present) {
      map['data_inclusao'] = Variable<DateTime>(dataInclusao.value);
    }
    if (descricao.present) {
      map['descricao'] = Variable<String>(descricao.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('GedDocumentoCabecalhosCompanion(')
          ..write('id: $id, ')
          ..write('nome: $nome, ')
          ..write('dataInclusao: $dataInclusao, ')
          ..write('descricao: $descricao')
          ..write(')'))
        .toString();
  }
}

class $GedTipoDocumentosTable extends GedTipoDocumentos
    with TableInfo<$GedTipoDocumentosTable, GedTipoDocumento> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $GedTipoDocumentosTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
    'id',
    aliasedName,
    true,
    type: DriftSqlType.int,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _nomeMeta = const VerificationMeta('nome');
  @override
  late final GeneratedColumn<String> nome = GeneratedColumn<String>(
    'nome',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 100,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _tamanhoMaximoMeta = const VerificationMeta(
    'tamanhoMaximo',
  );
  @override
  late final GeneratedColumn<double> tamanhoMaximo = GeneratedColumn<double>(
    'tamanho_maximo',
    aliasedName,
    true,
    type: DriftSqlType.double,
    requiredDuringInsert: false,
  );
  @override
  List<GeneratedColumn> get $columns => [id, nome, tamanhoMaximo];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'ged_tipo_documento';
  @override
  VerificationContext validateIntegrity(
    Insertable<GedTipoDocumento> instance, {
    bool isInserting = false,
  }) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('nome')) {
      context.handle(
        _nomeMeta,
        nome.isAcceptableOrUnknown(data['nome']!, _nomeMeta),
      );
    }
    if (data.containsKey('tamanho_maximo')) {
      context.handle(
        _tamanhoMaximoMeta,
        tamanhoMaximo.isAcceptableOrUnknown(
          data['tamanho_maximo']!,
          _tamanhoMaximoMeta,
        ),
      );
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  GedTipoDocumento map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return GedTipoDocumento(
      id: attachedDatabase.typeMapping.read(
        DriftSqlType.int,
        data['${effectivePrefix}id'],
      ),
      nome: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}nome'],
      ),
      tamanhoMaximo: attachedDatabase.typeMapping.read(
        DriftSqlType.double,
        data['${effectivePrefix}tamanho_maximo'],
      ),
    );
  }

  @override
  $GedTipoDocumentosTable createAlias(String alias) {
    return $GedTipoDocumentosTable(attachedDatabase, alias);
  }
}

class GedTipoDocumento extends DataClass
    implements Insertable<GedTipoDocumento> {
  final int? id;
  final String? nome;
  final double? tamanhoMaximo;
  const GedTipoDocumento({this.id, this.nome, this.tamanhoMaximo});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || nome != null) {
      map['nome'] = Variable<String>(nome);
    }
    if (!nullToAbsent || tamanhoMaximo != null) {
      map['tamanho_maximo'] = Variable<double>(tamanhoMaximo);
    }
    return map;
  }

  factory GedTipoDocumento.fromJson(
    Map<String, dynamic> json, {
    ValueSerializer? serializer,
  }) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return GedTipoDocumento(
      id: serializer.fromJson<int?>(json['id']),
      nome: serializer.fromJson<String?>(json['nome']),
      tamanhoMaximo: serializer.fromJson<double?>(json['tamanhoMaximo']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'nome': serializer.toJson<String?>(nome),
      'tamanhoMaximo': serializer.toJson<double?>(tamanhoMaximo),
    };
  }

  GedTipoDocumento copyWith({
    Value<int?> id = const Value.absent(),
    Value<String?> nome = const Value.absent(),
    Value<double?> tamanhoMaximo = const Value.absent(),
  }) => GedTipoDocumento(
    id: id.present ? id.value : this.id,
    nome: nome.present ? nome.value : this.nome,
    tamanhoMaximo:
        tamanhoMaximo.present ? tamanhoMaximo.value : this.tamanhoMaximo,
  );
  GedTipoDocumento copyWithCompanion(GedTipoDocumentosCompanion data) {
    return GedTipoDocumento(
      id: data.id.present ? data.id.value : this.id,
      nome: data.nome.present ? data.nome.value : this.nome,
      tamanhoMaximo:
          data.tamanhoMaximo.present
              ? data.tamanhoMaximo.value
              : this.tamanhoMaximo,
    );
  }

  @override
  String toString() {
    return (StringBuffer('GedTipoDocumento(')
          ..write('id: $id, ')
          ..write('nome: $nome, ')
          ..write('tamanhoMaximo: $tamanhoMaximo')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(id, nome, tamanhoMaximo);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is GedTipoDocumento &&
          other.id == this.id &&
          other.nome == this.nome &&
          other.tamanhoMaximo == this.tamanhoMaximo);
}

class GedTipoDocumentosCompanion extends UpdateCompanion<GedTipoDocumento> {
  final Value<int?> id;
  final Value<String?> nome;
  final Value<double?> tamanhoMaximo;
  const GedTipoDocumentosCompanion({
    this.id = const Value.absent(),
    this.nome = const Value.absent(),
    this.tamanhoMaximo = const Value.absent(),
  });
  GedTipoDocumentosCompanion.insert({
    this.id = const Value.absent(),
    this.nome = const Value.absent(),
    this.tamanhoMaximo = const Value.absent(),
  });
  static Insertable<GedTipoDocumento> custom({
    Expression<int>? id,
    Expression<String>? nome,
    Expression<double>? tamanhoMaximo,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (nome != null) 'nome': nome,
      if (tamanhoMaximo != null) 'tamanho_maximo': tamanhoMaximo,
    });
  }

  GedTipoDocumentosCompanion copyWith({
    Value<int?>? id,
    Value<String?>? nome,
    Value<double?>? tamanhoMaximo,
  }) {
    return GedTipoDocumentosCompanion(
      id: id ?? this.id,
      nome: nome ?? this.nome,
      tamanhoMaximo: tamanhoMaximo ?? this.tamanhoMaximo,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (nome.present) {
      map['nome'] = Variable<String>(nome.value);
    }
    if (tamanhoMaximo.present) {
      map['tamanho_maximo'] = Variable<double>(tamanhoMaximo.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('GedTipoDocumentosCompanion(')
          ..write('id: $id, ')
          ..write('nome: $nome, ')
          ..write('tamanhoMaximo: $tamanhoMaximo')
          ..write(')'))
        .toString();
  }
}

class $GedVersaoDocumentosTable extends GedVersaoDocumentos
    with TableInfo<$GedVersaoDocumentosTable, GedVersaoDocumento> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $GedVersaoDocumentosTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
    'id',
    aliasedName,
    true,
    type: DriftSqlType.int,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _idGedDocumentoDetalheMeta =
      const VerificationMeta('idGedDocumentoDetalhe');
  @override
  late final GeneratedColumn<int> idGedDocumentoDetalhe = GeneratedColumn<int>(
    'id_ged_documento_detalhe',
    aliasedName,
    true,
    type: DriftSqlType.int,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _idColaboradorMeta = const VerificationMeta(
    'idColaborador',
  );
  @override
  late final GeneratedColumn<int> idColaborador = GeneratedColumn<int>(
    'id_colaborador',
    aliasedName,
    true,
    type: DriftSqlType.int,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _acaoMeta = const VerificationMeta('acao');
  @override
  late final GeneratedColumn<String> acao = GeneratedColumn<String>(
    'acao',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 1,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _versaoMeta = const VerificationMeta('versao');
  @override
  late final GeneratedColumn<int> versao = GeneratedColumn<int>(
    'versao',
    aliasedName,
    true,
    type: DriftSqlType.int,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _dataVersaoMeta = const VerificationMeta(
    'dataVersao',
  );
  @override
  late final GeneratedColumn<DateTime> dataVersao = GeneratedColumn<DateTime>(
    'data_versao',
    aliasedName,
    true,
    type: DriftSqlType.dateTime,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _horaVersaoMeta = const VerificationMeta(
    'horaVersao',
  );
  @override
  late final GeneratedColumn<String> horaVersao = GeneratedColumn<String>(
    'hora_versao',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 8,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _hashArquivoMeta = const VerificationMeta(
    'hashArquivo',
  );
  @override
  late final GeneratedColumn<String> hashArquivo = GeneratedColumn<String>(
    'hash_arquivo',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 250,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _caminhoMeta = const VerificationMeta(
    'caminho',
  );
  @override
  late final GeneratedColumn<String> caminho = GeneratedColumn<String>(
    'caminho',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 250,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  @override
  List<GeneratedColumn> get $columns => [
    id,
    idGedDocumentoDetalhe,
    idColaborador,
    acao,
    versao,
    dataVersao,
    horaVersao,
    hashArquivo,
    caminho,
  ];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'ged_versao_documento';
  @override
  VerificationContext validateIntegrity(
    Insertable<GedVersaoDocumento> instance, {
    bool isInserting = false,
  }) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('id_ged_documento_detalhe')) {
      context.handle(
        _idGedDocumentoDetalheMeta,
        idGedDocumentoDetalhe.isAcceptableOrUnknown(
          data['id_ged_documento_detalhe']!,
          _idGedDocumentoDetalheMeta,
        ),
      );
    }
    if (data.containsKey('id_colaborador')) {
      context.handle(
        _idColaboradorMeta,
        idColaborador.isAcceptableOrUnknown(
          data['id_colaborador']!,
          _idColaboradorMeta,
        ),
      );
    }
    if (data.containsKey('acao')) {
      context.handle(
        _acaoMeta,
        acao.isAcceptableOrUnknown(data['acao']!, _acaoMeta),
      );
    }
    if (data.containsKey('versao')) {
      context.handle(
        _versaoMeta,
        versao.isAcceptableOrUnknown(data['versao']!, _versaoMeta),
      );
    }
    if (data.containsKey('data_versao')) {
      context.handle(
        _dataVersaoMeta,
        dataVersao.isAcceptableOrUnknown(data['data_versao']!, _dataVersaoMeta),
      );
    }
    if (data.containsKey('hora_versao')) {
      context.handle(
        _horaVersaoMeta,
        horaVersao.isAcceptableOrUnknown(data['hora_versao']!, _horaVersaoMeta),
      );
    }
    if (data.containsKey('hash_arquivo')) {
      context.handle(
        _hashArquivoMeta,
        hashArquivo.isAcceptableOrUnknown(
          data['hash_arquivo']!,
          _hashArquivoMeta,
        ),
      );
    }
    if (data.containsKey('caminho')) {
      context.handle(
        _caminhoMeta,
        caminho.isAcceptableOrUnknown(data['caminho']!, _caminhoMeta),
      );
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  GedVersaoDocumento map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return GedVersaoDocumento(
      id: attachedDatabase.typeMapping.read(
        DriftSqlType.int,
        data['${effectivePrefix}id'],
      ),
      idGedDocumentoDetalhe: attachedDatabase.typeMapping.read(
        DriftSqlType.int,
        data['${effectivePrefix}id_ged_documento_detalhe'],
      ),
      idColaborador: attachedDatabase.typeMapping.read(
        DriftSqlType.int,
        data['${effectivePrefix}id_colaborador'],
      ),
      acao: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}acao'],
      ),
      versao: attachedDatabase.typeMapping.read(
        DriftSqlType.int,
        data['${effectivePrefix}versao'],
      ),
      dataVersao: attachedDatabase.typeMapping.read(
        DriftSqlType.dateTime,
        data['${effectivePrefix}data_versao'],
      ),
      horaVersao: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}hora_versao'],
      ),
      hashArquivo: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}hash_arquivo'],
      ),
      caminho: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}caminho'],
      ),
    );
  }

  @override
  $GedVersaoDocumentosTable createAlias(String alias) {
    return $GedVersaoDocumentosTable(attachedDatabase, alias);
  }
}

class GedVersaoDocumento extends DataClass
    implements Insertable<GedVersaoDocumento> {
  final int? id;
  final int? idGedDocumentoDetalhe;
  final int? idColaborador;
  final String? acao;
  final int? versao;
  final DateTime? dataVersao;
  final String? horaVersao;
  final String? hashArquivo;
  final String? caminho;
  const GedVersaoDocumento({
    this.id,
    this.idGedDocumentoDetalhe,
    this.idColaborador,
    this.acao,
    this.versao,
    this.dataVersao,
    this.horaVersao,
    this.hashArquivo,
    this.caminho,
  });
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || idGedDocumentoDetalhe != null) {
      map['id_ged_documento_detalhe'] = Variable<int>(idGedDocumentoDetalhe);
    }
    if (!nullToAbsent || idColaborador != null) {
      map['id_colaborador'] = Variable<int>(idColaborador);
    }
    if (!nullToAbsent || acao != null) {
      map['acao'] = Variable<String>(acao);
    }
    if (!nullToAbsent || versao != null) {
      map['versao'] = Variable<int>(versao);
    }
    if (!nullToAbsent || dataVersao != null) {
      map['data_versao'] = Variable<DateTime>(dataVersao);
    }
    if (!nullToAbsent || horaVersao != null) {
      map['hora_versao'] = Variable<String>(horaVersao);
    }
    if (!nullToAbsent || hashArquivo != null) {
      map['hash_arquivo'] = Variable<String>(hashArquivo);
    }
    if (!nullToAbsent || caminho != null) {
      map['caminho'] = Variable<String>(caminho);
    }
    return map;
  }

  factory GedVersaoDocumento.fromJson(
    Map<String, dynamic> json, {
    ValueSerializer? serializer,
  }) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return GedVersaoDocumento(
      id: serializer.fromJson<int?>(json['id']),
      idGedDocumentoDetalhe: serializer.fromJson<int?>(
        json['idGedDocumentoDetalhe'],
      ),
      idColaborador: serializer.fromJson<int?>(json['idColaborador']),
      acao: serializer.fromJson<String?>(json['acao']),
      versao: serializer.fromJson<int?>(json['versao']),
      dataVersao: serializer.fromJson<DateTime?>(json['dataVersao']),
      horaVersao: serializer.fromJson<String?>(json['horaVersao']),
      hashArquivo: serializer.fromJson<String?>(json['hashArquivo']),
      caminho: serializer.fromJson<String?>(json['caminho']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'idGedDocumentoDetalhe': serializer.toJson<int?>(idGedDocumentoDetalhe),
      'idColaborador': serializer.toJson<int?>(idColaborador),
      'acao': serializer.toJson<String?>(acao),
      'versao': serializer.toJson<int?>(versao),
      'dataVersao': serializer.toJson<DateTime?>(dataVersao),
      'horaVersao': serializer.toJson<String?>(horaVersao),
      'hashArquivo': serializer.toJson<String?>(hashArquivo),
      'caminho': serializer.toJson<String?>(caminho),
    };
  }

  GedVersaoDocumento copyWith({
    Value<int?> id = const Value.absent(),
    Value<int?> idGedDocumentoDetalhe = const Value.absent(),
    Value<int?> idColaborador = const Value.absent(),
    Value<String?> acao = const Value.absent(),
    Value<int?> versao = const Value.absent(),
    Value<DateTime?> dataVersao = const Value.absent(),
    Value<String?> horaVersao = const Value.absent(),
    Value<String?> hashArquivo = const Value.absent(),
    Value<String?> caminho = const Value.absent(),
  }) => GedVersaoDocumento(
    id: id.present ? id.value : this.id,
    idGedDocumentoDetalhe:
        idGedDocumentoDetalhe.present
            ? idGedDocumentoDetalhe.value
            : this.idGedDocumentoDetalhe,
    idColaborador:
        idColaborador.present ? idColaborador.value : this.idColaborador,
    acao: acao.present ? acao.value : this.acao,
    versao: versao.present ? versao.value : this.versao,
    dataVersao: dataVersao.present ? dataVersao.value : this.dataVersao,
    horaVersao: horaVersao.present ? horaVersao.value : this.horaVersao,
    hashArquivo: hashArquivo.present ? hashArquivo.value : this.hashArquivo,
    caminho: caminho.present ? caminho.value : this.caminho,
  );
  GedVersaoDocumento copyWithCompanion(GedVersaoDocumentosCompanion data) {
    return GedVersaoDocumento(
      id: data.id.present ? data.id.value : this.id,
      idGedDocumentoDetalhe:
          data.idGedDocumentoDetalhe.present
              ? data.idGedDocumentoDetalhe.value
              : this.idGedDocumentoDetalhe,
      idColaborador:
          data.idColaborador.present
              ? data.idColaborador.value
              : this.idColaborador,
      acao: data.acao.present ? data.acao.value : this.acao,
      versao: data.versao.present ? data.versao.value : this.versao,
      dataVersao:
          data.dataVersao.present ? data.dataVersao.value : this.dataVersao,
      horaVersao:
          data.horaVersao.present ? data.horaVersao.value : this.horaVersao,
      hashArquivo:
          data.hashArquivo.present ? data.hashArquivo.value : this.hashArquivo,
      caminho: data.caminho.present ? data.caminho.value : this.caminho,
    );
  }

  @override
  String toString() {
    return (StringBuffer('GedVersaoDocumento(')
          ..write('id: $id, ')
          ..write('idGedDocumentoDetalhe: $idGedDocumentoDetalhe, ')
          ..write('idColaborador: $idColaborador, ')
          ..write('acao: $acao, ')
          ..write('versao: $versao, ')
          ..write('dataVersao: $dataVersao, ')
          ..write('horaVersao: $horaVersao, ')
          ..write('hashArquivo: $hashArquivo, ')
          ..write('caminho: $caminho')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(
    id,
    idGedDocumentoDetalhe,
    idColaborador,
    acao,
    versao,
    dataVersao,
    horaVersao,
    hashArquivo,
    caminho,
  );
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is GedVersaoDocumento &&
          other.id == this.id &&
          other.idGedDocumentoDetalhe == this.idGedDocumentoDetalhe &&
          other.idColaborador == this.idColaborador &&
          other.acao == this.acao &&
          other.versao == this.versao &&
          other.dataVersao == this.dataVersao &&
          other.horaVersao == this.horaVersao &&
          other.hashArquivo == this.hashArquivo &&
          other.caminho == this.caminho);
}

class GedVersaoDocumentosCompanion extends UpdateCompanion<GedVersaoDocumento> {
  final Value<int?> id;
  final Value<int?> idGedDocumentoDetalhe;
  final Value<int?> idColaborador;
  final Value<String?> acao;
  final Value<int?> versao;
  final Value<DateTime?> dataVersao;
  final Value<String?> horaVersao;
  final Value<String?> hashArquivo;
  final Value<String?> caminho;
  const GedVersaoDocumentosCompanion({
    this.id = const Value.absent(),
    this.idGedDocumentoDetalhe = const Value.absent(),
    this.idColaborador = const Value.absent(),
    this.acao = const Value.absent(),
    this.versao = const Value.absent(),
    this.dataVersao = const Value.absent(),
    this.horaVersao = const Value.absent(),
    this.hashArquivo = const Value.absent(),
    this.caminho = const Value.absent(),
  });
  GedVersaoDocumentosCompanion.insert({
    this.id = const Value.absent(),
    this.idGedDocumentoDetalhe = const Value.absent(),
    this.idColaborador = const Value.absent(),
    this.acao = const Value.absent(),
    this.versao = const Value.absent(),
    this.dataVersao = const Value.absent(),
    this.horaVersao = const Value.absent(),
    this.hashArquivo = const Value.absent(),
    this.caminho = const Value.absent(),
  });
  static Insertable<GedVersaoDocumento> custom({
    Expression<int>? id,
    Expression<int>? idGedDocumentoDetalhe,
    Expression<int>? idColaborador,
    Expression<String>? acao,
    Expression<int>? versao,
    Expression<DateTime>? dataVersao,
    Expression<String>? horaVersao,
    Expression<String>? hashArquivo,
    Expression<String>? caminho,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (idGedDocumentoDetalhe != null)
        'id_ged_documento_detalhe': idGedDocumentoDetalhe,
      if (idColaborador != null) 'id_colaborador': idColaborador,
      if (acao != null) 'acao': acao,
      if (versao != null) 'versao': versao,
      if (dataVersao != null) 'data_versao': dataVersao,
      if (horaVersao != null) 'hora_versao': horaVersao,
      if (hashArquivo != null) 'hash_arquivo': hashArquivo,
      if (caminho != null) 'caminho': caminho,
    });
  }

  GedVersaoDocumentosCompanion copyWith({
    Value<int?>? id,
    Value<int?>? idGedDocumentoDetalhe,
    Value<int?>? idColaborador,
    Value<String?>? acao,
    Value<int?>? versao,
    Value<DateTime?>? dataVersao,
    Value<String?>? horaVersao,
    Value<String?>? hashArquivo,
    Value<String?>? caminho,
  }) {
    return GedVersaoDocumentosCompanion(
      id: id ?? this.id,
      idGedDocumentoDetalhe:
          idGedDocumentoDetalhe ?? this.idGedDocumentoDetalhe,
      idColaborador: idColaborador ?? this.idColaborador,
      acao: acao ?? this.acao,
      versao: versao ?? this.versao,
      dataVersao: dataVersao ?? this.dataVersao,
      horaVersao: horaVersao ?? this.horaVersao,
      hashArquivo: hashArquivo ?? this.hashArquivo,
      caminho: caminho ?? this.caminho,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (idGedDocumentoDetalhe.present) {
      map['id_ged_documento_detalhe'] = Variable<int>(
        idGedDocumentoDetalhe.value,
      );
    }
    if (idColaborador.present) {
      map['id_colaborador'] = Variable<int>(idColaborador.value);
    }
    if (acao.present) {
      map['acao'] = Variable<String>(acao.value);
    }
    if (versao.present) {
      map['versao'] = Variable<int>(versao.value);
    }
    if (dataVersao.present) {
      map['data_versao'] = Variable<DateTime>(dataVersao.value);
    }
    if (horaVersao.present) {
      map['hora_versao'] = Variable<String>(horaVersao.value);
    }
    if (hashArquivo.present) {
      map['hash_arquivo'] = Variable<String>(hashArquivo.value);
    }
    if (caminho.present) {
      map['caminho'] = Variable<String>(caminho.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('GedVersaoDocumentosCompanion(')
          ..write('id: $id, ')
          ..write('idGedDocumentoDetalhe: $idGedDocumentoDetalhe, ')
          ..write('idColaborador: $idColaborador, ')
          ..write('acao: $acao, ')
          ..write('versao: $versao, ')
          ..write('dataVersao: $dataVersao, ')
          ..write('horaVersao: $horaVersao, ')
          ..write('hashArquivo: $hashArquivo, ')
          ..write('caminho: $caminho')
          ..write(')'))
        .toString();
  }
}

class $ViewControleAcessosTable extends ViewControleAcessos
    with TableInfo<$ViewControleAcessosTable, ViewControleAcesso> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $ViewControleAcessosTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
    'id',
    aliasedName,
    true,
    type: DriftSqlType.int,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _idPessoaMeta = const VerificationMeta(
    'idPessoa',
  );
  @override
  late final GeneratedColumn<int> idPessoa = GeneratedColumn<int>(
    'id_pessoa',
    aliasedName,
    true,
    type: DriftSqlType.int,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _pessoaNomeMeta = const VerificationMeta(
    'pessoaNome',
  );
  @override
  late final GeneratedColumn<String> pessoaNome = GeneratedColumn<String>(
    'pessoa_nome',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 450,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _idColaboradorMeta = const VerificationMeta(
    'idColaborador',
  );
  @override
  late final GeneratedColumn<int> idColaborador = GeneratedColumn<int>(
    'id_colaborador',
    aliasedName,
    true,
    type: DriftSqlType.int,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _idUsuarioMeta = const VerificationMeta(
    'idUsuario',
  );
  @override
  late final GeneratedColumn<int> idUsuario = GeneratedColumn<int>(
    'id_usuario',
    aliasedName,
    true,
    type: DriftSqlType.int,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _administradorMeta = const VerificationMeta(
    'administrador',
  );
  @override
  late final GeneratedColumn<String> administrador = GeneratedColumn<String>(
    'administrador',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 3,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _idPapelMeta = const VerificationMeta(
    'idPapel',
  );
  @override
  late final GeneratedColumn<int> idPapel = GeneratedColumn<int>(
    'id_papel',
    aliasedName,
    true,
    type: DriftSqlType.int,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _papelNomeMeta = const VerificationMeta(
    'papelNome',
  );
  @override
  late final GeneratedColumn<String> papelNome = GeneratedColumn<String>(
    'papel_nome',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 300,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _papelDescricaoMeta = const VerificationMeta(
    'papelDescricao',
  );
  @override
  late final GeneratedColumn<String> papelDescricao = GeneratedColumn<String>(
    'papel_descricao',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 750,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _idFuncaoMeta = const VerificationMeta(
    'idFuncao',
  );
  @override
  late final GeneratedColumn<int> idFuncao = GeneratedColumn<int>(
    'id_funcao',
    aliasedName,
    true,
    type: DriftSqlType.int,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _funcaoNomeMeta = const VerificationMeta(
    'funcaoNome',
  );
  @override
  late final GeneratedColumn<String> funcaoNome = GeneratedColumn<String>(
    'funcao_nome',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 300,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _funcaoDescricaoMeta = const VerificationMeta(
    'funcaoDescricao',
  );
  @override
  late final GeneratedColumn<String> funcaoDescricao = GeneratedColumn<String>(
    'funcao_descricao',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 750,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _idPapelFuncaoMeta = const VerificationMeta(
    'idPapelFuncao',
  );
  @override
  late final GeneratedColumn<int> idPapelFuncao = GeneratedColumn<int>(
    'id_papel_funcao',
    aliasedName,
    true,
    type: DriftSqlType.int,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _habilitadoMeta = const VerificationMeta(
    'habilitado',
  );
  @override
  late final GeneratedColumn<String> habilitado = GeneratedColumn<String>(
    'habilitado',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 3,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _podeInserirMeta = const VerificationMeta(
    'podeInserir',
  );
  @override
  late final GeneratedColumn<String> podeInserir = GeneratedColumn<String>(
    'pode_inserir',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 3,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _podeAlterarMeta = const VerificationMeta(
    'podeAlterar',
  );
  @override
  late final GeneratedColumn<String> podeAlterar = GeneratedColumn<String>(
    'pode_alterar',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 3,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _podeExcluirMeta = const VerificationMeta(
    'podeExcluir',
  );
  @override
  late final GeneratedColumn<String> podeExcluir = GeneratedColumn<String>(
    'pode_excluir',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 3,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  @override
  List<GeneratedColumn> get $columns => [
    id,
    idPessoa,
    pessoaNome,
    idColaborador,
    idUsuario,
    administrador,
    idPapel,
    papelNome,
    papelDescricao,
    idFuncao,
    funcaoNome,
    funcaoDescricao,
    idPapelFuncao,
    habilitado,
    podeInserir,
    podeAlterar,
    podeExcluir,
  ];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'view_controle_acesso';
  @override
  VerificationContext validateIntegrity(
    Insertable<ViewControleAcesso> instance, {
    bool isInserting = false,
  }) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('id_pessoa')) {
      context.handle(
        _idPessoaMeta,
        idPessoa.isAcceptableOrUnknown(data['id_pessoa']!, _idPessoaMeta),
      );
    }
    if (data.containsKey('pessoa_nome')) {
      context.handle(
        _pessoaNomeMeta,
        pessoaNome.isAcceptableOrUnknown(data['pessoa_nome']!, _pessoaNomeMeta),
      );
    }
    if (data.containsKey('id_colaborador')) {
      context.handle(
        _idColaboradorMeta,
        idColaborador.isAcceptableOrUnknown(
          data['id_colaborador']!,
          _idColaboradorMeta,
        ),
      );
    }
    if (data.containsKey('id_usuario')) {
      context.handle(
        _idUsuarioMeta,
        idUsuario.isAcceptableOrUnknown(data['id_usuario']!, _idUsuarioMeta),
      );
    }
    if (data.containsKey('administrador')) {
      context.handle(
        _administradorMeta,
        administrador.isAcceptableOrUnknown(
          data['administrador']!,
          _administradorMeta,
        ),
      );
    }
    if (data.containsKey('id_papel')) {
      context.handle(
        _idPapelMeta,
        idPapel.isAcceptableOrUnknown(data['id_papel']!, _idPapelMeta),
      );
    }
    if (data.containsKey('papel_nome')) {
      context.handle(
        _papelNomeMeta,
        papelNome.isAcceptableOrUnknown(data['papel_nome']!, _papelNomeMeta),
      );
    }
    if (data.containsKey('papel_descricao')) {
      context.handle(
        _papelDescricaoMeta,
        papelDescricao.isAcceptableOrUnknown(
          data['papel_descricao']!,
          _papelDescricaoMeta,
        ),
      );
    }
    if (data.containsKey('id_funcao')) {
      context.handle(
        _idFuncaoMeta,
        idFuncao.isAcceptableOrUnknown(data['id_funcao']!, _idFuncaoMeta),
      );
    }
    if (data.containsKey('funcao_nome')) {
      context.handle(
        _funcaoNomeMeta,
        funcaoNome.isAcceptableOrUnknown(data['funcao_nome']!, _funcaoNomeMeta),
      );
    }
    if (data.containsKey('funcao_descricao')) {
      context.handle(
        _funcaoDescricaoMeta,
        funcaoDescricao.isAcceptableOrUnknown(
          data['funcao_descricao']!,
          _funcaoDescricaoMeta,
        ),
      );
    }
    if (data.containsKey('id_papel_funcao')) {
      context.handle(
        _idPapelFuncaoMeta,
        idPapelFuncao.isAcceptableOrUnknown(
          data['id_papel_funcao']!,
          _idPapelFuncaoMeta,
        ),
      );
    }
    if (data.containsKey('habilitado')) {
      context.handle(
        _habilitadoMeta,
        habilitado.isAcceptableOrUnknown(data['habilitado']!, _habilitadoMeta),
      );
    }
    if (data.containsKey('pode_inserir')) {
      context.handle(
        _podeInserirMeta,
        podeInserir.isAcceptableOrUnknown(
          data['pode_inserir']!,
          _podeInserirMeta,
        ),
      );
    }
    if (data.containsKey('pode_alterar')) {
      context.handle(
        _podeAlterarMeta,
        podeAlterar.isAcceptableOrUnknown(
          data['pode_alterar']!,
          _podeAlterarMeta,
        ),
      );
    }
    if (data.containsKey('pode_excluir')) {
      context.handle(
        _podeExcluirMeta,
        podeExcluir.isAcceptableOrUnknown(
          data['pode_excluir']!,
          _podeExcluirMeta,
        ),
      );
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  ViewControleAcesso map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return ViewControleAcesso(
      id: attachedDatabase.typeMapping.read(
        DriftSqlType.int,
        data['${effectivePrefix}id'],
      ),
      idPessoa: attachedDatabase.typeMapping.read(
        DriftSqlType.int,
        data['${effectivePrefix}id_pessoa'],
      ),
      pessoaNome: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}pessoa_nome'],
      ),
      idColaborador: attachedDatabase.typeMapping.read(
        DriftSqlType.int,
        data['${effectivePrefix}id_colaborador'],
      ),
      idUsuario: attachedDatabase.typeMapping.read(
        DriftSqlType.int,
        data['${effectivePrefix}id_usuario'],
      ),
      administrador: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}administrador'],
      ),
      idPapel: attachedDatabase.typeMapping.read(
        DriftSqlType.int,
        data['${effectivePrefix}id_papel'],
      ),
      papelNome: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}papel_nome'],
      ),
      papelDescricao: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}papel_descricao'],
      ),
      idFuncao: attachedDatabase.typeMapping.read(
        DriftSqlType.int,
        data['${effectivePrefix}id_funcao'],
      ),
      funcaoNome: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}funcao_nome'],
      ),
      funcaoDescricao: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}funcao_descricao'],
      ),
      idPapelFuncao: attachedDatabase.typeMapping.read(
        DriftSqlType.int,
        data['${effectivePrefix}id_papel_funcao'],
      ),
      habilitado: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}habilitado'],
      ),
      podeInserir: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}pode_inserir'],
      ),
      podeAlterar: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}pode_alterar'],
      ),
      podeExcluir: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}pode_excluir'],
      ),
    );
  }

  @override
  $ViewControleAcessosTable createAlias(String alias) {
    return $ViewControleAcessosTable(attachedDatabase, alias);
  }
}

class ViewControleAcesso extends DataClass
    implements Insertable<ViewControleAcesso> {
  final int? id;
  final int? idPessoa;
  final String? pessoaNome;
  final int? idColaborador;
  final int? idUsuario;
  final String? administrador;
  final int? idPapel;
  final String? papelNome;
  final String? papelDescricao;
  final int? idFuncao;
  final String? funcaoNome;
  final String? funcaoDescricao;
  final int? idPapelFuncao;
  final String? habilitado;
  final String? podeInserir;
  final String? podeAlterar;
  final String? podeExcluir;
  const ViewControleAcesso({
    this.id,
    this.idPessoa,
    this.pessoaNome,
    this.idColaborador,
    this.idUsuario,
    this.administrador,
    this.idPapel,
    this.papelNome,
    this.papelDescricao,
    this.idFuncao,
    this.funcaoNome,
    this.funcaoDescricao,
    this.idPapelFuncao,
    this.habilitado,
    this.podeInserir,
    this.podeAlterar,
    this.podeExcluir,
  });
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || idPessoa != null) {
      map['id_pessoa'] = Variable<int>(idPessoa);
    }
    if (!nullToAbsent || pessoaNome != null) {
      map['pessoa_nome'] = Variable<String>(pessoaNome);
    }
    if (!nullToAbsent || idColaborador != null) {
      map['id_colaborador'] = Variable<int>(idColaborador);
    }
    if (!nullToAbsent || idUsuario != null) {
      map['id_usuario'] = Variable<int>(idUsuario);
    }
    if (!nullToAbsent || administrador != null) {
      map['administrador'] = Variable<String>(administrador);
    }
    if (!nullToAbsent || idPapel != null) {
      map['id_papel'] = Variable<int>(idPapel);
    }
    if (!nullToAbsent || papelNome != null) {
      map['papel_nome'] = Variable<String>(papelNome);
    }
    if (!nullToAbsent || papelDescricao != null) {
      map['papel_descricao'] = Variable<String>(papelDescricao);
    }
    if (!nullToAbsent || idFuncao != null) {
      map['id_funcao'] = Variable<int>(idFuncao);
    }
    if (!nullToAbsent || funcaoNome != null) {
      map['funcao_nome'] = Variable<String>(funcaoNome);
    }
    if (!nullToAbsent || funcaoDescricao != null) {
      map['funcao_descricao'] = Variable<String>(funcaoDescricao);
    }
    if (!nullToAbsent || idPapelFuncao != null) {
      map['id_papel_funcao'] = Variable<int>(idPapelFuncao);
    }
    if (!nullToAbsent || habilitado != null) {
      map['habilitado'] = Variable<String>(habilitado);
    }
    if (!nullToAbsent || podeInserir != null) {
      map['pode_inserir'] = Variable<String>(podeInserir);
    }
    if (!nullToAbsent || podeAlterar != null) {
      map['pode_alterar'] = Variable<String>(podeAlterar);
    }
    if (!nullToAbsent || podeExcluir != null) {
      map['pode_excluir'] = Variable<String>(podeExcluir);
    }
    return map;
  }

  factory ViewControleAcesso.fromJson(
    Map<String, dynamic> json, {
    ValueSerializer? serializer,
  }) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return ViewControleAcesso(
      id: serializer.fromJson<int?>(json['id']),
      idPessoa: serializer.fromJson<int?>(json['idPessoa']),
      pessoaNome: serializer.fromJson<String?>(json['pessoaNome']),
      idColaborador: serializer.fromJson<int?>(json['idColaborador']),
      idUsuario: serializer.fromJson<int?>(json['idUsuario']),
      administrador: serializer.fromJson<String?>(json['administrador']),
      idPapel: serializer.fromJson<int?>(json['idPapel']),
      papelNome: serializer.fromJson<String?>(json['papelNome']),
      papelDescricao: serializer.fromJson<String?>(json['papelDescricao']),
      idFuncao: serializer.fromJson<int?>(json['idFuncao']),
      funcaoNome: serializer.fromJson<String?>(json['funcaoNome']),
      funcaoDescricao: serializer.fromJson<String?>(json['funcaoDescricao']),
      idPapelFuncao: serializer.fromJson<int?>(json['idPapelFuncao']),
      habilitado: serializer.fromJson<String?>(json['habilitado']),
      podeInserir: serializer.fromJson<String?>(json['podeInserir']),
      podeAlterar: serializer.fromJson<String?>(json['podeAlterar']),
      podeExcluir: serializer.fromJson<String?>(json['podeExcluir']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'idPessoa': serializer.toJson<int?>(idPessoa),
      'pessoaNome': serializer.toJson<String?>(pessoaNome),
      'idColaborador': serializer.toJson<int?>(idColaborador),
      'idUsuario': serializer.toJson<int?>(idUsuario),
      'administrador': serializer.toJson<String?>(administrador),
      'idPapel': serializer.toJson<int?>(idPapel),
      'papelNome': serializer.toJson<String?>(papelNome),
      'papelDescricao': serializer.toJson<String?>(papelDescricao),
      'idFuncao': serializer.toJson<int?>(idFuncao),
      'funcaoNome': serializer.toJson<String?>(funcaoNome),
      'funcaoDescricao': serializer.toJson<String?>(funcaoDescricao),
      'idPapelFuncao': serializer.toJson<int?>(idPapelFuncao),
      'habilitado': serializer.toJson<String?>(habilitado),
      'podeInserir': serializer.toJson<String?>(podeInserir),
      'podeAlterar': serializer.toJson<String?>(podeAlterar),
      'podeExcluir': serializer.toJson<String?>(podeExcluir),
    };
  }

  ViewControleAcesso copyWith({
    Value<int?> id = const Value.absent(),
    Value<int?> idPessoa = const Value.absent(),
    Value<String?> pessoaNome = const Value.absent(),
    Value<int?> idColaborador = const Value.absent(),
    Value<int?> idUsuario = const Value.absent(),
    Value<String?> administrador = const Value.absent(),
    Value<int?> idPapel = const Value.absent(),
    Value<String?> papelNome = const Value.absent(),
    Value<String?> papelDescricao = const Value.absent(),
    Value<int?> idFuncao = const Value.absent(),
    Value<String?> funcaoNome = const Value.absent(),
    Value<String?> funcaoDescricao = const Value.absent(),
    Value<int?> idPapelFuncao = const Value.absent(),
    Value<String?> habilitado = const Value.absent(),
    Value<String?> podeInserir = const Value.absent(),
    Value<String?> podeAlterar = const Value.absent(),
    Value<String?> podeExcluir = const Value.absent(),
  }) => ViewControleAcesso(
    id: id.present ? id.value : this.id,
    idPessoa: idPessoa.present ? idPessoa.value : this.idPessoa,
    pessoaNome: pessoaNome.present ? pessoaNome.value : this.pessoaNome,
    idColaborador:
        idColaborador.present ? idColaborador.value : this.idColaborador,
    idUsuario: idUsuario.present ? idUsuario.value : this.idUsuario,
    administrador:
        administrador.present ? administrador.value : this.administrador,
    idPapel: idPapel.present ? idPapel.value : this.idPapel,
    papelNome: papelNome.present ? papelNome.value : this.papelNome,
    papelDescricao:
        papelDescricao.present ? papelDescricao.value : this.papelDescricao,
    idFuncao: idFuncao.present ? idFuncao.value : this.idFuncao,
    funcaoNome: funcaoNome.present ? funcaoNome.value : this.funcaoNome,
    funcaoDescricao:
        funcaoDescricao.present ? funcaoDescricao.value : this.funcaoDescricao,
    idPapelFuncao:
        idPapelFuncao.present ? idPapelFuncao.value : this.idPapelFuncao,
    habilitado: habilitado.present ? habilitado.value : this.habilitado,
    podeInserir: podeInserir.present ? podeInserir.value : this.podeInserir,
    podeAlterar: podeAlterar.present ? podeAlterar.value : this.podeAlterar,
    podeExcluir: podeExcluir.present ? podeExcluir.value : this.podeExcluir,
  );
  ViewControleAcesso copyWithCompanion(ViewControleAcessosCompanion data) {
    return ViewControleAcesso(
      id: data.id.present ? data.id.value : this.id,
      idPessoa: data.idPessoa.present ? data.idPessoa.value : this.idPessoa,
      pessoaNome:
          data.pessoaNome.present ? data.pessoaNome.value : this.pessoaNome,
      idColaborador:
          data.idColaborador.present
              ? data.idColaborador.value
              : this.idColaborador,
      idUsuario: data.idUsuario.present ? data.idUsuario.value : this.idUsuario,
      administrador:
          data.administrador.present
              ? data.administrador.value
              : this.administrador,
      idPapel: data.idPapel.present ? data.idPapel.value : this.idPapel,
      papelNome: data.papelNome.present ? data.papelNome.value : this.papelNome,
      papelDescricao:
          data.papelDescricao.present
              ? data.papelDescricao.value
              : this.papelDescricao,
      idFuncao: data.idFuncao.present ? data.idFuncao.value : this.idFuncao,
      funcaoNome:
          data.funcaoNome.present ? data.funcaoNome.value : this.funcaoNome,
      funcaoDescricao:
          data.funcaoDescricao.present
              ? data.funcaoDescricao.value
              : this.funcaoDescricao,
      idPapelFuncao:
          data.idPapelFuncao.present
              ? data.idPapelFuncao.value
              : this.idPapelFuncao,
      habilitado:
          data.habilitado.present ? data.habilitado.value : this.habilitado,
      podeInserir:
          data.podeInserir.present ? data.podeInserir.value : this.podeInserir,
      podeAlterar:
          data.podeAlterar.present ? data.podeAlterar.value : this.podeAlterar,
      podeExcluir:
          data.podeExcluir.present ? data.podeExcluir.value : this.podeExcluir,
    );
  }

  @override
  String toString() {
    return (StringBuffer('ViewControleAcesso(')
          ..write('id: $id, ')
          ..write('idPessoa: $idPessoa, ')
          ..write('pessoaNome: $pessoaNome, ')
          ..write('idColaborador: $idColaborador, ')
          ..write('idUsuario: $idUsuario, ')
          ..write('administrador: $administrador, ')
          ..write('idPapel: $idPapel, ')
          ..write('papelNome: $papelNome, ')
          ..write('papelDescricao: $papelDescricao, ')
          ..write('idFuncao: $idFuncao, ')
          ..write('funcaoNome: $funcaoNome, ')
          ..write('funcaoDescricao: $funcaoDescricao, ')
          ..write('idPapelFuncao: $idPapelFuncao, ')
          ..write('habilitado: $habilitado, ')
          ..write('podeInserir: $podeInserir, ')
          ..write('podeAlterar: $podeAlterar, ')
          ..write('podeExcluir: $podeExcluir')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(
    id,
    idPessoa,
    pessoaNome,
    idColaborador,
    idUsuario,
    administrador,
    idPapel,
    papelNome,
    papelDescricao,
    idFuncao,
    funcaoNome,
    funcaoDescricao,
    idPapelFuncao,
    habilitado,
    podeInserir,
    podeAlterar,
    podeExcluir,
  );
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is ViewControleAcesso &&
          other.id == this.id &&
          other.idPessoa == this.idPessoa &&
          other.pessoaNome == this.pessoaNome &&
          other.idColaborador == this.idColaborador &&
          other.idUsuario == this.idUsuario &&
          other.administrador == this.administrador &&
          other.idPapel == this.idPapel &&
          other.papelNome == this.papelNome &&
          other.papelDescricao == this.papelDescricao &&
          other.idFuncao == this.idFuncao &&
          other.funcaoNome == this.funcaoNome &&
          other.funcaoDescricao == this.funcaoDescricao &&
          other.idPapelFuncao == this.idPapelFuncao &&
          other.habilitado == this.habilitado &&
          other.podeInserir == this.podeInserir &&
          other.podeAlterar == this.podeAlterar &&
          other.podeExcluir == this.podeExcluir);
}

class ViewControleAcessosCompanion extends UpdateCompanion<ViewControleAcesso> {
  final Value<int?> id;
  final Value<int?> idPessoa;
  final Value<String?> pessoaNome;
  final Value<int?> idColaborador;
  final Value<int?> idUsuario;
  final Value<String?> administrador;
  final Value<int?> idPapel;
  final Value<String?> papelNome;
  final Value<String?> papelDescricao;
  final Value<int?> idFuncao;
  final Value<String?> funcaoNome;
  final Value<String?> funcaoDescricao;
  final Value<int?> idPapelFuncao;
  final Value<String?> habilitado;
  final Value<String?> podeInserir;
  final Value<String?> podeAlterar;
  final Value<String?> podeExcluir;
  const ViewControleAcessosCompanion({
    this.id = const Value.absent(),
    this.idPessoa = const Value.absent(),
    this.pessoaNome = const Value.absent(),
    this.idColaborador = const Value.absent(),
    this.idUsuario = const Value.absent(),
    this.administrador = const Value.absent(),
    this.idPapel = const Value.absent(),
    this.papelNome = const Value.absent(),
    this.papelDescricao = const Value.absent(),
    this.idFuncao = const Value.absent(),
    this.funcaoNome = const Value.absent(),
    this.funcaoDescricao = const Value.absent(),
    this.idPapelFuncao = const Value.absent(),
    this.habilitado = const Value.absent(),
    this.podeInserir = const Value.absent(),
    this.podeAlterar = const Value.absent(),
    this.podeExcluir = const Value.absent(),
  });
  ViewControleAcessosCompanion.insert({
    this.id = const Value.absent(),
    this.idPessoa = const Value.absent(),
    this.pessoaNome = const Value.absent(),
    this.idColaborador = const Value.absent(),
    this.idUsuario = const Value.absent(),
    this.administrador = const Value.absent(),
    this.idPapel = const Value.absent(),
    this.papelNome = const Value.absent(),
    this.papelDescricao = const Value.absent(),
    this.idFuncao = const Value.absent(),
    this.funcaoNome = const Value.absent(),
    this.funcaoDescricao = const Value.absent(),
    this.idPapelFuncao = const Value.absent(),
    this.habilitado = const Value.absent(),
    this.podeInserir = const Value.absent(),
    this.podeAlterar = const Value.absent(),
    this.podeExcluir = const Value.absent(),
  });
  static Insertable<ViewControleAcesso> custom({
    Expression<int>? id,
    Expression<int>? idPessoa,
    Expression<String>? pessoaNome,
    Expression<int>? idColaborador,
    Expression<int>? idUsuario,
    Expression<String>? administrador,
    Expression<int>? idPapel,
    Expression<String>? papelNome,
    Expression<String>? papelDescricao,
    Expression<int>? idFuncao,
    Expression<String>? funcaoNome,
    Expression<String>? funcaoDescricao,
    Expression<int>? idPapelFuncao,
    Expression<String>? habilitado,
    Expression<String>? podeInserir,
    Expression<String>? podeAlterar,
    Expression<String>? podeExcluir,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (idPessoa != null) 'id_pessoa': idPessoa,
      if (pessoaNome != null) 'pessoa_nome': pessoaNome,
      if (idColaborador != null) 'id_colaborador': idColaborador,
      if (idUsuario != null) 'id_usuario': idUsuario,
      if (administrador != null) 'administrador': administrador,
      if (idPapel != null) 'id_papel': idPapel,
      if (papelNome != null) 'papel_nome': papelNome,
      if (papelDescricao != null) 'papel_descricao': papelDescricao,
      if (idFuncao != null) 'id_funcao': idFuncao,
      if (funcaoNome != null) 'funcao_nome': funcaoNome,
      if (funcaoDescricao != null) 'funcao_descricao': funcaoDescricao,
      if (idPapelFuncao != null) 'id_papel_funcao': idPapelFuncao,
      if (habilitado != null) 'habilitado': habilitado,
      if (podeInserir != null) 'pode_inserir': podeInserir,
      if (podeAlterar != null) 'pode_alterar': podeAlterar,
      if (podeExcluir != null) 'pode_excluir': podeExcluir,
    });
  }

  ViewControleAcessosCompanion copyWith({
    Value<int?>? id,
    Value<int?>? idPessoa,
    Value<String?>? pessoaNome,
    Value<int?>? idColaborador,
    Value<int?>? idUsuario,
    Value<String?>? administrador,
    Value<int?>? idPapel,
    Value<String?>? papelNome,
    Value<String?>? papelDescricao,
    Value<int?>? idFuncao,
    Value<String?>? funcaoNome,
    Value<String?>? funcaoDescricao,
    Value<int?>? idPapelFuncao,
    Value<String?>? habilitado,
    Value<String?>? podeInserir,
    Value<String?>? podeAlterar,
    Value<String?>? podeExcluir,
  }) {
    return ViewControleAcessosCompanion(
      id: id ?? this.id,
      idPessoa: idPessoa ?? this.idPessoa,
      pessoaNome: pessoaNome ?? this.pessoaNome,
      idColaborador: idColaborador ?? this.idColaborador,
      idUsuario: idUsuario ?? this.idUsuario,
      administrador: administrador ?? this.administrador,
      idPapel: idPapel ?? this.idPapel,
      papelNome: papelNome ?? this.papelNome,
      papelDescricao: papelDescricao ?? this.papelDescricao,
      idFuncao: idFuncao ?? this.idFuncao,
      funcaoNome: funcaoNome ?? this.funcaoNome,
      funcaoDescricao: funcaoDescricao ?? this.funcaoDescricao,
      idPapelFuncao: idPapelFuncao ?? this.idPapelFuncao,
      habilitado: habilitado ?? this.habilitado,
      podeInserir: podeInserir ?? this.podeInserir,
      podeAlterar: podeAlterar ?? this.podeAlterar,
      podeExcluir: podeExcluir ?? this.podeExcluir,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (idPessoa.present) {
      map['id_pessoa'] = Variable<int>(idPessoa.value);
    }
    if (pessoaNome.present) {
      map['pessoa_nome'] = Variable<String>(pessoaNome.value);
    }
    if (idColaborador.present) {
      map['id_colaborador'] = Variable<int>(idColaborador.value);
    }
    if (idUsuario.present) {
      map['id_usuario'] = Variable<int>(idUsuario.value);
    }
    if (administrador.present) {
      map['administrador'] = Variable<String>(administrador.value);
    }
    if (idPapel.present) {
      map['id_papel'] = Variable<int>(idPapel.value);
    }
    if (papelNome.present) {
      map['papel_nome'] = Variable<String>(papelNome.value);
    }
    if (papelDescricao.present) {
      map['papel_descricao'] = Variable<String>(papelDescricao.value);
    }
    if (idFuncao.present) {
      map['id_funcao'] = Variable<int>(idFuncao.value);
    }
    if (funcaoNome.present) {
      map['funcao_nome'] = Variable<String>(funcaoNome.value);
    }
    if (funcaoDescricao.present) {
      map['funcao_descricao'] = Variable<String>(funcaoDescricao.value);
    }
    if (idPapelFuncao.present) {
      map['id_papel_funcao'] = Variable<int>(idPapelFuncao.value);
    }
    if (habilitado.present) {
      map['habilitado'] = Variable<String>(habilitado.value);
    }
    if (podeInserir.present) {
      map['pode_inserir'] = Variable<String>(podeInserir.value);
    }
    if (podeAlterar.present) {
      map['pode_alterar'] = Variable<String>(podeAlterar.value);
    }
    if (podeExcluir.present) {
      map['pode_excluir'] = Variable<String>(podeExcluir.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('ViewControleAcessosCompanion(')
          ..write('id: $id, ')
          ..write('idPessoa: $idPessoa, ')
          ..write('pessoaNome: $pessoaNome, ')
          ..write('idColaborador: $idColaborador, ')
          ..write('idUsuario: $idUsuario, ')
          ..write('administrador: $administrador, ')
          ..write('idPapel: $idPapel, ')
          ..write('papelNome: $papelNome, ')
          ..write('papelDescricao: $papelDescricao, ')
          ..write('idFuncao: $idFuncao, ')
          ..write('funcaoNome: $funcaoNome, ')
          ..write('funcaoDescricao: $funcaoDescricao, ')
          ..write('idPapelFuncao: $idPapelFuncao, ')
          ..write('habilitado: $habilitado, ')
          ..write('podeInserir: $podeInserir, ')
          ..write('podeAlterar: $podeAlterar, ')
          ..write('podeExcluir: $podeExcluir')
          ..write(')'))
        .toString();
  }
}

class $ViewPessoaUsuariosTable extends ViewPessoaUsuarios
    with TableInfo<$ViewPessoaUsuariosTable, ViewPessoaUsuario> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $ViewPessoaUsuariosTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
    'id',
    aliasedName,
    true,
    type: DriftSqlType.int,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _idPessoaMeta = const VerificationMeta(
    'idPessoa',
  );
  @override
  late final GeneratedColumn<int> idPessoa = GeneratedColumn<int>(
    'id_pessoa',
    aliasedName,
    true,
    type: DriftSqlType.int,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _pessoaNomeMeta = const VerificationMeta(
    'pessoaNome',
  );
  @override
  late final GeneratedColumn<String> pessoaNome = GeneratedColumn<String>(
    'pessoa_nome',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 450,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _tipoMeta = const VerificationMeta('tipo');
  @override
  late final GeneratedColumn<String> tipo = GeneratedColumn<String>(
    'tipo',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 3,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _emailMeta = const VerificationMeta('email');
  @override
  late final GeneratedColumn<String> email = GeneratedColumn<String>(
    'email',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 750,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _idColaboradorMeta = const VerificationMeta(
    'idColaborador',
  );
  @override
  late final GeneratedColumn<int> idColaborador = GeneratedColumn<int>(
    'id_colaborador',
    aliasedName,
    true,
    type: DriftSqlType.int,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _idUsuarioMeta = const VerificationMeta(
    'idUsuario',
  );
  @override
  late final GeneratedColumn<int> idUsuario = GeneratedColumn<int>(
    'id_usuario',
    aliasedName,
    true,
    type: DriftSqlType.int,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _loginMeta = const VerificationMeta('login');
  @override
  late final GeneratedColumn<String> login = GeneratedColumn<String>(
    'login',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 150,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _senhaMeta = const VerificationMeta('senha');
  @override
  late final GeneratedColumn<String> senha = GeneratedColumn<String>(
    'senha',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 150,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _dataCadastroMeta = const VerificationMeta(
    'dataCadastro',
  );
  @override
  late final GeneratedColumn<DateTime> dataCadastro = GeneratedColumn<DateTime>(
    'data_cadastro',
    aliasedName,
    true,
    type: DriftSqlType.dateTime,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _administradorMeta = const VerificationMeta(
    'administrador',
  );
  @override
  late final GeneratedColumn<String> administrador = GeneratedColumn<String>(
    'administrador',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 3,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  @override
  List<GeneratedColumn> get $columns => [
    id,
    idPessoa,
    pessoaNome,
    tipo,
    email,
    idColaborador,
    idUsuario,
    login,
    senha,
    dataCadastro,
    administrador,
  ];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'view_pessoa_usuario';
  @override
  VerificationContext validateIntegrity(
    Insertable<ViewPessoaUsuario> instance, {
    bool isInserting = false,
  }) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('id_pessoa')) {
      context.handle(
        _idPessoaMeta,
        idPessoa.isAcceptableOrUnknown(data['id_pessoa']!, _idPessoaMeta),
      );
    }
    if (data.containsKey('pessoa_nome')) {
      context.handle(
        _pessoaNomeMeta,
        pessoaNome.isAcceptableOrUnknown(data['pessoa_nome']!, _pessoaNomeMeta),
      );
    }
    if (data.containsKey('tipo')) {
      context.handle(
        _tipoMeta,
        tipo.isAcceptableOrUnknown(data['tipo']!, _tipoMeta),
      );
    }
    if (data.containsKey('email')) {
      context.handle(
        _emailMeta,
        email.isAcceptableOrUnknown(data['email']!, _emailMeta),
      );
    }
    if (data.containsKey('id_colaborador')) {
      context.handle(
        _idColaboradorMeta,
        idColaborador.isAcceptableOrUnknown(
          data['id_colaborador']!,
          _idColaboradorMeta,
        ),
      );
    }
    if (data.containsKey('id_usuario')) {
      context.handle(
        _idUsuarioMeta,
        idUsuario.isAcceptableOrUnknown(data['id_usuario']!, _idUsuarioMeta),
      );
    }
    if (data.containsKey('login')) {
      context.handle(
        _loginMeta,
        login.isAcceptableOrUnknown(data['login']!, _loginMeta),
      );
    }
    if (data.containsKey('senha')) {
      context.handle(
        _senhaMeta,
        senha.isAcceptableOrUnknown(data['senha']!, _senhaMeta),
      );
    }
    if (data.containsKey('data_cadastro')) {
      context.handle(
        _dataCadastroMeta,
        dataCadastro.isAcceptableOrUnknown(
          data['data_cadastro']!,
          _dataCadastroMeta,
        ),
      );
    }
    if (data.containsKey('administrador')) {
      context.handle(
        _administradorMeta,
        administrador.isAcceptableOrUnknown(
          data['administrador']!,
          _administradorMeta,
        ),
      );
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  ViewPessoaUsuario map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return ViewPessoaUsuario(
      id: attachedDatabase.typeMapping.read(
        DriftSqlType.int,
        data['${effectivePrefix}id'],
      ),
      idPessoa: attachedDatabase.typeMapping.read(
        DriftSqlType.int,
        data['${effectivePrefix}id_pessoa'],
      ),
      pessoaNome: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}pessoa_nome'],
      ),
      tipo: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}tipo'],
      ),
      email: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}email'],
      ),
      idColaborador: attachedDatabase.typeMapping.read(
        DriftSqlType.int,
        data['${effectivePrefix}id_colaborador'],
      ),
      idUsuario: attachedDatabase.typeMapping.read(
        DriftSqlType.int,
        data['${effectivePrefix}id_usuario'],
      ),
      login: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}login'],
      ),
      senha: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}senha'],
      ),
      dataCadastro: attachedDatabase.typeMapping.read(
        DriftSqlType.dateTime,
        data['${effectivePrefix}data_cadastro'],
      ),
      administrador: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}administrador'],
      ),
    );
  }

  @override
  $ViewPessoaUsuariosTable createAlias(String alias) {
    return $ViewPessoaUsuariosTable(attachedDatabase, alias);
  }
}

class ViewPessoaUsuario extends DataClass
    implements Insertable<ViewPessoaUsuario> {
  final int? id;
  final int? idPessoa;
  final String? pessoaNome;
  final String? tipo;
  final String? email;
  final int? idColaborador;
  final int? idUsuario;
  final String? login;
  final String? senha;
  final DateTime? dataCadastro;
  final String? administrador;
  const ViewPessoaUsuario({
    this.id,
    this.idPessoa,
    this.pessoaNome,
    this.tipo,
    this.email,
    this.idColaborador,
    this.idUsuario,
    this.login,
    this.senha,
    this.dataCadastro,
    this.administrador,
  });
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || idPessoa != null) {
      map['id_pessoa'] = Variable<int>(idPessoa);
    }
    if (!nullToAbsent || pessoaNome != null) {
      map['pessoa_nome'] = Variable<String>(pessoaNome);
    }
    if (!nullToAbsent || tipo != null) {
      map['tipo'] = Variable<String>(tipo);
    }
    if (!nullToAbsent || email != null) {
      map['email'] = Variable<String>(email);
    }
    if (!nullToAbsent || idColaborador != null) {
      map['id_colaborador'] = Variable<int>(idColaborador);
    }
    if (!nullToAbsent || idUsuario != null) {
      map['id_usuario'] = Variable<int>(idUsuario);
    }
    if (!nullToAbsent || login != null) {
      map['login'] = Variable<String>(login);
    }
    if (!nullToAbsent || senha != null) {
      map['senha'] = Variable<String>(senha);
    }
    if (!nullToAbsent || dataCadastro != null) {
      map['data_cadastro'] = Variable<DateTime>(dataCadastro);
    }
    if (!nullToAbsent || administrador != null) {
      map['administrador'] = Variable<String>(administrador);
    }
    return map;
  }

  factory ViewPessoaUsuario.fromJson(
    Map<String, dynamic> json, {
    ValueSerializer? serializer,
  }) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return ViewPessoaUsuario(
      id: serializer.fromJson<int?>(json['id']),
      idPessoa: serializer.fromJson<int?>(json['idPessoa']),
      pessoaNome: serializer.fromJson<String?>(json['pessoaNome']),
      tipo: serializer.fromJson<String?>(json['tipo']),
      email: serializer.fromJson<String?>(json['email']),
      idColaborador: serializer.fromJson<int?>(json['idColaborador']),
      idUsuario: serializer.fromJson<int?>(json['idUsuario']),
      login: serializer.fromJson<String?>(json['login']),
      senha: serializer.fromJson<String?>(json['senha']),
      dataCadastro: serializer.fromJson<DateTime?>(json['dataCadastro']),
      administrador: serializer.fromJson<String?>(json['administrador']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'idPessoa': serializer.toJson<int?>(idPessoa),
      'pessoaNome': serializer.toJson<String?>(pessoaNome),
      'tipo': serializer.toJson<String?>(tipo),
      'email': serializer.toJson<String?>(email),
      'idColaborador': serializer.toJson<int?>(idColaborador),
      'idUsuario': serializer.toJson<int?>(idUsuario),
      'login': serializer.toJson<String?>(login),
      'senha': serializer.toJson<String?>(senha),
      'dataCadastro': serializer.toJson<DateTime?>(dataCadastro),
      'administrador': serializer.toJson<String?>(administrador),
    };
  }

  ViewPessoaUsuario copyWith({
    Value<int?> id = const Value.absent(),
    Value<int?> idPessoa = const Value.absent(),
    Value<String?> pessoaNome = const Value.absent(),
    Value<String?> tipo = const Value.absent(),
    Value<String?> email = const Value.absent(),
    Value<int?> idColaborador = const Value.absent(),
    Value<int?> idUsuario = const Value.absent(),
    Value<String?> login = const Value.absent(),
    Value<String?> senha = const Value.absent(),
    Value<DateTime?> dataCadastro = const Value.absent(),
    Value<String?> administrador = const Value.absent(),
  }) => ViewPessoaUsuario(
    id: id.present ? id.value : this.id,
    idPessoa: idPessoa.present ? idPessoa.value : this.idPessoa,
    pessoaNome: pessoaNome.present ? pessoaNome.value : this.pessoaNome,
    tipo: tipo.present ? tipo.value : this.tipo,
    email: email.present ? email.value : this.email,
    idColaborador:
        idColaborador.present ? idColaborador.value : this.idColaborador,
    idUsuario: idUsuario.present ? idUsuario.value : this.idUsuario,
    login: login.present ? login.value : this.login,
    senha: senha.present ? senha.value : this.senha,
    dataCadastro: dataCadastro.present ? dataCadastro.value : this.dataCadastro,
    administrador:
        administrador.present ? administrador.value : this.administrador,
  );
  ViewPessoaUsuario copyWithCompanion(ViewPessoaUsuariosCompanion data) {
    return ViewPessoaUsuario(
      id: data.id.present ? data.id.value : this.id,
      idPessoa: data.idPessoa.present ? data.idPessoa.value : this.idPessoa,
      pessoaNome:
          data.pessoaNome.present ? data.pessoaNome.value : this.pessoaNome,
      tipo: data.tipo.present ? data.tipo.value : this.tipo,
      email: data.email.present ? data.email.value : this.email,
      idColaborador:
          data.idColaborador.present
              ? data.idColaborador.value
              : this.idColaborador,
      idUsuario: data.idUsuario.present ? data.idUsuario.value : this.idUsuario,
      login: data.login.present ? data.login.value : this.login,
      senha: data.senha.present ? data.senha.value : this.senha,
      dataCadastro:
          data.dataCadastro.present
              ? data.dataCadastro.value
              : this.dataCadastro,
      administrador:
          data.administrador.present
              ? data.administrador.value
              : this.administrador,
    );
  }

  @override
  String toString() {
    return (StringBuffer('ViewPessoaUsuario(')
          ..write('id: $id, ')
          ..write('idPessoa: $idPessoa, ')
          ..write('pessoaNome: $pessoaNome, ')
          ..write('tipo: $tipo, ')
          ..write('email: $email, ')
          ..write('idColaborador: $idColaborador, ')
          ..write('idUsuario: $idUsuario, ')
          ..write('login: $login, ')
          ..write('senha: $senha, ')
          ..write('dataCadastro: $dataCadastro, ')
          ..write('administrador: $administrador')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(
    id,
    idPessoa,
    pessoaNome,
    tipo,
    email,
    idColaborador,
    idUsuario,
    login,
    senha,
    dataCadastro,
    administrador,
  );
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is ViewPessoaUsuario &&
          other.id == this.id &&
          other.idPessoa == this.idPessoa &&
          other.pessoaNome == this.pessoaNome &&
          other.tipo == this.tipo &&
          other.email == this.email &&
          other.idColaborador == this.idColaborador &&
          other.idUsuario == this.idUsuario &&
          other.login == this.login &&
          other.senha == this.senha &&
          other.dataCadastro == this.dataCadastro &&
          other.administrador == this.administrador);
}

class ViewPessoaUsuariosCompanion extends UpdateCompanion<ViewPessoaUsuario> {
  final Value<int?> id;
  final Value<int?> idPessoa;
  final Value<String?> pessoaNome;
  final Value<String?> tipo;
  final Value<String?> email;
  final Value<int?> idColaborador;
  final Value<int?> idUsuario;
  final Value<String?> login;
  final Value<String?> senha;
  final Value<DateTime?> dataCadastro;
  final Value<String?> administrador;
  const ViewPessoaUsuariosCompanion({
    this.id = const Value.absent(),
    this.idPessoa = const Value.absent(),
    this.pessoaNome = const Value.absent(),
    this.tipo = const Value.absent(),
    this.email = const Value.absent(),
    this.idColaborador = const Value.absent(),
    this.idUsuario = const Value.absent(),
    this.login = const Value.absent(),
    this.senha = const Value.absent(),
    this.dataCadastro = const Value.absent(),
    this.administrador = const Value.absent(),
  });
  ViewPessoaUsuariosCompanion.insert({
    this.id = const Value.absent(),
    this.idPessoa = const Value.absent(),
    this.pessoaNome = const Value.absent(),
    this.tipo = const Value.absent(),
    this.email = const Value.absent(),
    this.idColaborador = const Value.absent(),
    this.idUsuario = const Value.absent(),
    this.login = const Value.absent(),
    this.senha = const Value.absent(),
    this.dataCadastro = const Value.absent(),
    this.administrador = const Value.absent(),
  });
  static Insertable<ViewPessoaUsuario> custom({
    Expression<int>? id,
    Expression<int>? idPessoa,
    Expression<String>? pessoaNome,
    Expression<String>? tipo,
    Expression<String>? email,
    Expression<int>? idColaborador,
    Expression<int>? idUsuario,
    Expression<String>? login,
    Expression<String>? senha,
    Expression<DateTime>? dataCadastro,
    Expression<String>? administrador,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (idPessoa != null) 'id_pessoa': idPessoa,
      if (pessoaNome != null) 'pessoa_nome': pessoaNome,
      if (tipo != null) 'tipo': tipo,
      if (email != null) 'email': email,
      if (idColaborador != null) 'id_colaborador': idColaborador,
      if (idUsuario != null) 'id_usuario': idUsuario,
      if (login != null) 'login': login,
      if (senha != null) 'senha': senha,
      if (dataCadastro != null) 'data_cadastro': dataCadastro,
      if (administrador != null) 'administrador': administrador,
    });
  }

  ViewPessoaUsuariosCompanion copyWith({
    Value<int?>? id,
    Value<int?>? idPessoa,
    Value<String?>? pessoaNome,
    Value<String?>? tipo,
    Value<String?>? email,
    Value<int?>? idColaborador,
    Value<int?>? idUsuario,
    Value<String?>? login,
    Value<String?>? senha,
    Value<DateTime?>? dataCadastro,
    Value<String?>? administrador,
  }) {
    return ViewPessoaUsuariosCompanion(
      id: id ?? this.id,
      idPessoa: idPessoa ?? this.idPessoa,
      pessoaNome: pessoaNome ?? this.pessoaNome,
      tipo: tipo ?? this.tipo,
      email: email ?? this.email,
      idColaborador: idColaborador ?? this.idColaborador,
      idUsuario: idUsuario ?? this.idUsuario,
      login: login ?? this.login,
      senha: senha ?? this.senha,
      dataCadastro: dataCadastro ?? this.dataCadastro,
      administrador: administrador ?? this.administrador,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (idPessoa.present) {
      map['id_pessoa'] = Variable<int>(idPessoa.value);
    }
    if (pessoaNome.present) {
      map['pessoa_nome'] = Variable<String>(pessoaNome.value);
    }
    if (tipo.present) {
      map['tipo'] = Variable<String>(tipo.value);
    }
    if (email.present) {
      map['email'] = Variable<String>(email.value);
    }
    if (idColaborador.present) {
      map['id_colaborador'] = Variable<int>(idColaborador.value);
    }
    if (idUsuario.present) {
      map['id_usuario'] = Variable<int>(idUsuario.value);
    }
    if (login.present) {
      map['login'] = Variable<String>(login.value);
    }
    if (senha.present) {
      map['senha'] = Variable<String>(senha.value);
    }
    if (dataCadastro.present) {
      map['data_cadastro'] = Variable<DateTime>(dataCadastro.value);
    }
    if (administrador.present) {
      map['administrador'] = Variable<String>(administrador.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('ViewPessoaUsuariosCompanion(')
          ..write('id: $id, ')
          ..write('idPessoa: $idPessoa, ')
          ..write('pessoaNome: $pessoaNome, ')
          ..write('tipo: $tipo, ')
          ..write('email: $email, ')
          ..write('idColaborador: $idColaborador, ')
          ..write('idUsuario: $idUsuario, ')
          ..write('login: $login, ')
          ..write('senha: $senha, ')
          ..write('dataCadastro: $dataCadastro, ')
          ..write('administrador: $administrador')
          ..write(')'))
        .toString();
  }
}

class $ViewPessoaColaboradorsTable extends ViewPessoaColaboradors
    with TableInfo<$ViewPessoaColaboradorsTable, ViewPessoaColaborador> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $ViewPessoaColaboradorsTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
    'id',
    aliasedName,
    true,
    type: DriftSqlType.int,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _nomeMeta = const VerificationMeta('nome');
  @override
  late final GeneratedColumn<String> nome = GeneratedColumn<String>(
    'nome',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 450,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _tipoMeta = const VerificationMeta('tipo');
  @override
  late final GeneratedColumn<String> tipo = GeneratedColumn<String>(
    'tipo',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 3,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _emailMeta = const VerificationMeta('email');
  @override
  late final GeneratedColumn<String> email = GeneratedColumn<String>(
    'email',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 750,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _siteMeta = const VerificationMeta('site');
  @override
  late final GeneratedColumn<String> site = GeneratedColumn<String>(
    'site',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 450,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _cpfCnpjMeta = const VerificationMeta(
    'cpfCnpj',
  );
  @override
  late final GeneratedColumn<String> cpfCnpj = GeneratedColumn<String>(
    'cpf_cnpj',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 20,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _rgIeMeta = const VerificationMeta('rgIe');
  @override
  late final GeneratedColumn<String> rgIe = GeneratedColumn<String>(
    'rg_ie',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 20,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _matriculaMeta = const VerificationMeta(
    'matricula',
  );
  @override
  late final GeneratedColumn<String> matricula = GeneratedColumn<String>(
    'matricula',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 50,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _dataCadastroMeta = const VerificationMeta(
    'dataCadastro',
  );
  @override
  late final GeneratedColumn<DateTime> dataCadastro = GeneratedColumn<DateTime>(
    'data_cadastro',
    aliasedName,
    true,
    type: DriftSqlType.dateTime,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _dataAdmissaoMeta = const VerificationMeta(
    'dataAdmissao',
  );
  @override
  late final GeneratedColumn<DateTime> dataAdmissao = GeneratedColumn<DateTime>(
    'data_admissao',
    aliasedName,
    true,
    type: DriftSqlType.dateTime,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _dataDemissaoMeta = const VerificationMeta(
    'dataDemissao',
  );
  @override
  late final GeneratedColumn<DateTime> dataDemissao = GeneratedColumn<DateTime>(
    'data_demissao',
    aliasedName,
    true,
    type: DriftSqlType.dateTime,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _ctpsNumeroMeta = const VerificationMeta(
    'ctpsNumero',
  );
  @override
  late final GeneratedColumn<String> ctpsNumero = GeneratedColumn<String>(
    'ctps_numero',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 20,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _ctpsSerieMeta = const VerificationMeta(
    'ctpsSerie',
  );
  @override
  late final GeneratedColumn<String> ctpsSerie = GeneratedColumn<String>(
    'ctps_serie',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 10,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _ctpsDataExpedicaoMeta = const VerificationMeta(
    'ctpsDataExpedicao',
  );
  @override
  late final GeneratedColumn<DateTime> ctpsDataExpedicao =
      GeneratedColumn<DateTime>(
        'ctps_data_expedicao',
        aliasedName,
        true,
        type: DriftSqlType.dateTime,
        requiredDuringInsert: false,
      );
  static const VerificationMeta _ctpsUfMeta = const VerificationMeta('ctpsUf');
  @override
  late final GeneratedColumn<String> ctpsUf = GeneratedColumn<String>(
    'ctps_uf',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 2,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _observacaoMeta = const VerificationMeta(
    'observacao',
  );
  @override
  late final GeneratedColumn<String> observacao = GeneratedColumn<String>(
    'observacao',
    aliasedName,
    true,
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _logradouroMeta = const VerificationMeta(
    'logradouro',
  );
  @override
  late final GeneratedColumn<String> logradouro = GeneratedColumn<String>(
    'logradouro',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 450,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _numeroMeta = const VerificationMeta('numero');
  @override
  late final GeneratedColumn<String> numero = GeneratedColumn<String>(
    'numero',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 20,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _complementoMeta = const VerificationMeta(
    'complemento',
  );
  @override
  late final GeneratedColumn<String> complemento = GeneratedColumn<String>(
    'complemento',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 450,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _bairroMeta = const VerificationMeta('bairro');
  @override
  late final GeneratedColumn<String> bairro = GeneratedColumn<String>(
    'bairro',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 150,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _cidadeMeta = const VerificationMeta('cidade');
  @override
  late final GeneratedColumn<String> cidade = GeneratedColumn<String>(
    'cidade',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 150,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _cepMeta = const VerificationMeta('cep');
  @override
  late final GeneratedColumn<String> cep = GeneratedColumn<String>(
    'cep',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 10,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _municipioIbgeMeta = const VerificationMeta(
    'municipioIbge',
  );
  @override
  late final GeneratedColumn<String> municipioIbge = GeneratedColumn<String>(
    'municipio_ibge',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 10,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _ufMeta = const VerificationMeta('uf');
  @override
  late final GeneratedColumn<String> uf = GeneratedColumn<String>(
    'uf',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 2,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _idPessoaMeta = const VerificationMeta(
    'idPessoa',
  );
  @override
  late final GeneratedColumn<int> idPessoa = GeneratedColumn<int>(
    'id_pessoa',
    aliasedName,
    true,
    type: DriftSqlType.int,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _idCargoMeta = const VerificationMeta(
    'idCargo',
  );
  @override
  late final GeneratedColumn<int> idCargo = GeneratedColumn<int>(
    'id_cargo',
    aliasedName,
    true,
    type: DriftSqlType.int,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _idSetorMeta = const VerificationMeta(
    'idSetor',
  );
  @override
  late final GeneratedColumn<int> idSetor = GeneratedColumn<int>(
    'id_setor',
    aliasedName,
    true,
    type: DriftSqlType.int,
    requiredDuringInsert: false,
  );
  @override
  List<GeneratedColumn> get $columns => [
    id,
    nome,
    tipo,
    email,
    site,
    cpfCnpj,
    rgIe,
    matricula,
    dataCadastro,
    dataAdmissao,
    dataDemissao,
    ctpsNumero,
    ctpsSerie,
    ctpsDataExpedicao,
    ctpsUf,
    observacao,
    logradouro,
    numero,
    complemento,
    bairro,
    cidade,
    cep,
    municipioIbge,
    uf,
    idPessoa,
    idCargo,
    idSetor,
  ];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'view_pessoa_colaborador';
  @override
  VerificationContext validateIntegrity(
    Insertable<ViewPessoaColaborador> instance, {
    bool isInserting = false,
  }) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('nome')) {
      context.handle(
        _nomeMeta,
        nome.isAcceptableOrUnknown(data['nome']!, _nomeMeta),
      );
    }
    if (data.containsKey('tipo')) {
      context.handle(
        _tipoMeta,
        tipo.isAcceptableOrUnknown(data['tipo']!, _tipoMeta),
      );
    }
    if (data.containsKey('email')) {
      context.handle(
        _emailMeta,
        email.isAcceptableOrUnknown(data['email']!, _emailMeta),
      );
    }
    if (data.containsKey('site')) {
      context.handle(
        _siteMeta,
        site.isAcceptableOrUnknown(data['site']!, _siteMeta),
      );
    }
    if (data.containsKey('cpf_cnpj')) {
      context.handle(
        _cpfCnpjMeta,
        cpfCnpj.isAcceptableOrUnknown(data['cpf_cnpj']!, _cpfCnpjMeta),
      );
    }
    if (data.containsKey('rg_ie')) {
      context.handle(
        _rgIeMeta,
        rgIe.isAcceptableOrUnknown(data['rg_ie']!, _rgIeMeta),
      );
    }
    if (data.containsKey('matricula')) {
      context.handle(
        _matriculaMeta,
        matricula.isAcceptableOrUnknown(data['matricula']!, _matriculaMeta),
      );
    }
    if (data.containsKey('data_cadastro')) {
      context.handle(
        _dataCadastroMeta,
        dataCadastro.isAcceptableOrUnknown(
          data['data_cadastro']!,
          _dataCadastroMeta,
        ),
      );
    }
    if (data.containsKey('data_admissao')) {
      context.handle(
        _dataAdmissaoMeta,
        dataAdmissao.isAcceptableOrUnknown(
          data['data_admissao']!,
          _dataAdmissaoMeta,
        ),
      );
    }
    if (data.containsKey('data_demissao')) {
      context.handle(
        _dataDemissaoMeta,
        dataDemissao.isAcceptableOrUnknown(
          data['data_demissao']!,
          _dataDemissaoMeta,
        ),
      );
    }
    if (data.containsKey('ctps_numero')) {
      context.handle(
        _ctpsNumeroMeta,
        ctpsNumero.isAcceptableOrUnknown(data['ctps_numero']!, _ctpsNumeroMeta),
      );
    }
    if (data.containsKey('ctps_serie')) {
      context.handle(
        _ctpsSerieMeta,
        ctpsSerie.isAcceptableOrUnknown(data['ctps_serie']!, _ctpsSerieMeta),
      );
    }
    if (data.containsKey('ctps_data_expedicao')) {
      context.handle(
        _ctpsDataExpedicaoMeta,
        ctpsDataExpedicao.isAcceptableOrUnknown(
          data['ctps_data_expedicao']!,
          _ctpsDataExpedicaoMeta,
        ),
      );
    }
    if (data.containsKey('ctps_uf')) {
      context.handle(
        _ctpsUfMeta,
        ctpsUf.isAcceptableOrUnknown(data['ctps_uf']!, _ctpsUfMeta),
      );
    }
    if (data.containsKey('observacao')) {
      context.handle(
        _observacaoMeta,
        observacao.isAcceptableOrUnknown(data['observacao']!, _observacaoMeta),
      );
    }
    if (data.containsKey('logradouro')) {
      context.handle(
        _logradouroMeta,
        logradouro.isAcceptableOrUnknown(data['logradouro']!, _logradouroMeta),
      );
    }
    if (data.containsKey('numero')) {
      context.handle(
        _numeroMeta,
        numero.isAcceptableOrUnknown(data['numero']!, _numeroMeta),
      );
    }
    if (data.containsKey('complemento')) {
      context.handle(
        _complementoMeta,
        complemento.isAcceptableOrUnknown(
          data['complemento']!,
          _complementoMeta,
        ),
      );
    }
    if (data.containsKey('bairro')) {
      context.handle(
        _bairroMeta,
        bairro.isAcceptableOrUnknown(data['bairro']!, _bairroMeta),
      );
    }
    if (data.containsKey('cidade')) {
      context.handle(
        _cidadeMeta,
        cidade.isAcceptableOrUnknown(data['cidade']!, _cidadeMeta),
      );
    }
    if (data.containsKey('cep')) {
      context.handle(
        _cepMeta,
        cep.isAcceptableOrUnknown(data['cep']!, _cepMeta),
      );
    }
    if (data.containsKey('municipio_ibge')) {
      context.handle(
        _municipioIbgeMeta,
        municipioIbge.isAcceptableOrUnknown(
          data['municipio_ibge']!,
          _municipioIbgeMeta,
        ),
      );
    }
    if (data.containsKey('uf')) {
      context.handle(_ufMeta, uf.isAcceptableOrUnknown(data['uf']!, _ufMeta));
    }
    if (data.containsKey('id_pessoa')) {
      context.handle(
        _idPessoaMeta,
        idPessoa.isAcceptableOrUnknown(data['id_pessoa']!, _idPessoaMeta),
      );
    }
    if (data.containsKey('id_cargo')) {
      context.handle(
        _idCargoMeta,
        idCargo.isAcceptableOrUnknown(data['id_cargo']!, _idCargoMeta),
      );
    }
    if (data.containsKey('id_setor')) {
      context.handle(
        _idSetorMeta,
        idSetor.isAcceptableOrUnknown(data['id_setor']!, _idSetorMeta),
      );
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  ViewPessoaColaborador map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return ViewPessoaColaborador(
      id: attachedDatabase.typeMapping.read(
        DriftSqlType.int,
        data['${effectivePrefix}id'],
      ),
      nome: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}nome'],
      ),
      tipo: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}tipo'],
      ),
      email: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}email'],
      ),
      site: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}site'],
      ),
      cpfCnpj: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}cpf_cnpj'],
      ),
      rgIe: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}rg_ie'],
      ),
      matricula: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}matricula'],
      ),
      dataCadastro: attachedDatabase.typeMapping.read(
        DriftSqlType.dateTime,
        data['${effectivePrefix}data_cadastro'],
      ),
      dataAdmissao: attachedDatabase.typeMapping.read(
        DriftSqlType.dateTime,
        data['${effectivePrefix}data_admissao'],
      ),
      dataDemissao: attachedDatabase.typeMapping.read(
        DriftSqlType.dateTime,
        data['${effectivePrefix}data_demissao'],
      ),
      ctpsNumero: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}ctps_numero'],
      ),
      ctpsSerie: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}ctps_serie'],
      ),
      ctpsDataExpedicao: attachedDatabase.typeMapping.read(
        DriftSqlType.dateTime,
        data['${effectivePrefix}ctps_data_expedicao'],
      ),
      ctpsUf: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}ctps_uf'],
      ),
      observacao: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}observacao'],
      ),
      logradouro: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}logradouro'],
      ),
      numero: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}numero'],
      ),
      complemento: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}complemento'],
      ),
      bairro: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}bairro'],
      ),
      cidade: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}cidade'],
      ),
      cep: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}cep'],
      ),
      municipioIbge: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}municipio_ibge'],
      ),
      uf: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}uf'],
      ),
      idPessoa: attachedDatabase.typeMapping.read(
        DriftSqlType.int,
        data['${effectivePrefix}id_pessoa'],
      ),
      idCargo: attachedDatabase.typeMapping.read(
        DriftSqlType.int,
        data['${effectivePrefix}id_cargo'],
      ),
      idSetor: attachedDatabase.typeMapping.read(
        DriftSqlType.int,
        data['${effectivePrefix}id_setor'],
      ),
    );
  }

  @override
  $ViewPessoaColaboradorsTable createAlias(String alias) {
    return $ViewPessoaColaboradorsTable(attachedDatabase, alias);
  }
}

class ViewPessoaColaborador extends DataClass
    implements Insertable<ViewPessoaColaborador> {
  final int? id;
  final String? nome;
  final String? tipo;
  final String? email;
  final String? site;
  final String? cpfCnpj;
  final String? rgIe;
  final String? matricula;
  final DateTime? dataCadastro;
  final DateTime? dataAdmissao;
  final DateTime? dataDemissao;
  final String? ctpsNumero;
  final String? ctpsSerie;
  final DateTime? ctpsDataExpedicao;
  final String? ctpsUf;
  final String? observacao;
  final String? logradouro;
  final String? numero;
  final String? complemento;
  final String? bairro;
  final String? cidade;
  final String? cep;
  final String? municipioIbge;
  final String? uf;
  final int? idPessoa;
  final int? idCargo;
  final int? idSetor;
  const ViewPessoaColaborador({
    this.id,
    this.nome,
    this.tipo,
    this.email,
    this.site,
    this.cpfCnpj,
    this.rgIe,
    this.matricula,
    this.dataCadastro,
    this.dataAdmissao,
    this.dataDemissao,
    this.ctpsNumero,
    this.ctpsSerie,
    this.ctpsDataExpedicao,
    this.ctpsUf,
    this.observacao,
    this.logradouro,
    this.numero,
    this.complemento,
    this.bairro,
    this.cidade,
    this.cep,
    this.municipioIbge,
    this.uf,
    this.idPessoa,
    this.idCargo,
    this.idSetor,
  });
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || nome != null) {
      map['nome'] = Variable<String>(nome);
    }
    if (!nullToAbsent || tipo != null) {
      map['tipo'] = Variable<String>(tipo);
    }
    if (!nullToAbsent || email != null) {
      map['email'] = Variable<String>(email);
    }
    if (!nullToAbsent || site != null) {
      map['site'] = Variable<String>(site);
    }
    if (!nullToAbsent || cpfCnpj != null) {
      map['cpf_cnpj'] = Variable<String>(cpfCnpj);
    }
    if (!nullToAbsent || rgIe != null) {
      map['rg_ie'] = Variable<String>(rgIe);
    }
    if (!nullToAbsent || matricula != null) {
      map['matricula'] = Variable<String>(matricula);
    }
    if (!nullToAbsent || dataCadastro != null) {
      map['data_cadastro'] = Variable<DateTime>(dataCadastro);
    }
    if (!nullToAbsent || dataAdmissao != null) {
      map['data_admissao'] = Variable<DateTime>(dataAdmissao);
    }
    if (!nullToAbsent || dataDemissao != null) {
      map['data_demissao'] = Variable<DateTime>(dataDemissao);
    }
    if (!nullToAbsent || ctpsNumero != null) {
      map['ctps_numero'] = Variable<String>(ctpsNumero);
    }
    if (!nullToAbsent || ctpsSerie != null) {
      map['ctps_serie'] = Variable<String>(ctpsSerie);
    }
    if (!nullToAbsent || ctpsDataExpedicao != null) {
      map['ctps_data_expedicao'] = Variable<DateTime>(ctpsDataExpedicao);
    }
    if (!nullToAbsent || ctpsUf != null) {
      map['ctps_uf'] = Variable<String>(ctpsUf);
    }
    if (!nullToAbsent || observacao != null) {
      map['observacao'] = Variable<String>(observacao);
    }
    if (!nullToAbsent || logradouro != null) {
      map['logradouro'] = Variable<String>(logradouro);
    }
    if (!nullToAbsent || numero != null) {
      map['numero'] = Variable<String>(numero);
    }
    if (!nullToAbsent || complemento != null) {
      map['complemento'] = Variable<String>(complemento);
    }
    if (!nullToAbsent || bairro != null) {
      map['bairro'] = Variable<String>(bairro);
    }
    if (!nullToAbsent || cidade != null) {
      map['cidade'] = Variable<String>(cidade);
    }
    if (!nullToAbsent || cep != null) {
      map['cep'] = Variable<String>(cep);
    }
    if (!nullToAbsent || municipioIbge != null) {
      map['municipio_ibge'] = Variable<String>(municipioIbge);
    }
    if (!nullToAbsent || uf != null) {
      map['uf'] = Variable<String>(uf);
    }
    if (!nullToAbsent || idPessoa != null) {
      map['id_pessoa'] = Variable<int>(idPessoa);
    }
    if (!nullToAbsent || idCargo != null) {
      map['id_cargo'] = Variable<int>(idCargo);
    }
    if (!nullToAbsent || idSetor != null) {
      map['id_setor'] = Variable<int>(idSetor);
    }
    return map;
  }

  factory ViewPessoaColaborador.fromJson(
    Map<String, dynamic> json, {
    ValueSerializer? serializer,
  }) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return ViewPessoaColaborador(
      id: serializer.fromJson<int?>(json['id']),
      nome: serializer.fromJson<String?>(json['nome']),
      tipo: serializer.fromJson<String?>(json['tipo']),
      email: serializer.fromJson<String?>(json['email']),
      site: serializer.fromJson<String?>(json['site']),
      cpfCnpj: serializer.fromJson<String?>(json['cpfCnpj']),
      rgIe: serializer.fromJson<String?>(json['rgIe']),
      matricula: serializer.fromJson<String?>(json['matricula']),
      dataCadastro: serializer.fromJson<DateTime?>(json['dataCadastro']),
      dataAdmissao: serializer.fromJson<DateTime?>(json['dataAdmissao']),
      dataDemissao: serializer.fromJson<DateTime?>(json['dataDemissao']),
      ctpsNumero: serializer.fromJson<String?>(json['ctpsNumero']),
      ctpsSerie: serializer.fromJson<String?>(json['ctpsSerie']),
      ctpsDataExpedicao: serializer.fromJson<DateTime?>(
        json['ctpsDataExpedicao'],
      ),
      ctpsUf: serializer.fromJson<String?>(json['ctpsUf']),
      observacao: serializer.fromJson<String?>(json['observacao']),
      logradouro: serializer.fromJson<String?>(json['logradouro']),
      numero: serializer.fromJson<String?>(json['numero']),
      complemento: serializer.fromJson<String?>(json['complemento']),
      bairro: serializer.fromJson<String?>(json['bairro']),
      cidade: serializer.fromJson<String?>(json['cidade']),
      cep: serializer.fromJson<String?>(json['cep']),
      municipioIbge: serializer.fromJson<String?>(json['municipioIbge']),
      uf: serializer.fromJson<String?>(json['uf']),
      idPessoa: serializer.fromJson<int?>(json['idPessoa']),
      idCargo: serializer.fromJson<int?>(json['idCargo']),
      idSetor: serializer.fromJson<int?>(json['idSetor']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'nome': serializer.toJson<String?>(nome),
      'tipo': serializer.toJson<String?>(tipo),
      'email': serializer.toJson<String?>(email),
      'site': serializer.toJson<String?>(site),
      'cpfCnpj': serializer.toJson<String?>(cpfCnpj),
      'rgIe': serializer.toJson<String?>(rgIe),
      'matricula': serializer.toJson<String?>(matricula),
      'dataCadastro': serializer.toJson<DateTime?>(dataCadastro),
      'dataAdmissao': serializer.toJson<DateTime?>(dataAdmissao),
      'dataDemissao': serializer.toJson<DateTime?>(dataDemissao),
      'ctpsNumero': serializer.toJson<String?>(ctpsNumero),
      'ctpsSerie': serializer.toJson<String?>(ctpsSerie),
      'ctpsDataExpedicao': serializer.toJson<DateTime?>(ctpsDataExpedicao),
      'ctpsUf': serializer.toJson<String?>(ctpsUf),
      'observacao': serializer.toJson<String?>(observacao),
      'logradouro': serializer.toJson<String?>(logradouro),
      'numero': serializer.toJson<String?>(numero),
      'complemento': serializer.toJson<String?>(complemento),
      'bairro': serializer.toJson<String?>(bairro),
      'cidade': serializer.toJson<String?>(cidade),
      'cep': serializer.toJson<String?>(cep),
      'municipioIbge': serializer.toJson<String?>(municipioIbge),
      'uf': serializer.toJson<String?>(uf),
      'idPessoa': serializer.toJson<int?>(idPessoa),
      'idCargo': serializer.toJson<int?>(idCargo),
      'idSetor': serializer.toJson<int?>(idSetor),
    };
  }

  ViewPessoaColaborador copyWith({
    Value<int?> id = const Value.absent(),
    Value<String?> nome = const Value.absent(),
    Value<String?> tipo = const Value.absent(),
    Value<String?> email = const Value.absent(),
    Value<String?> site = const Value.absent(),
    Value<String?> cpfCnpj = const Value.absent(),
    Value<String?> rgIe = const Value.absent(),
    Value<String?> matricula = const Value.absent(),
    Value<DateTime?> dataCadastro = const Value.absent(),
    Value<DateTime?> dataAdmissao = const Value.absent(),
    Value<DateTime?> dataDemissao = const Value.absent(),
    Value<String?> ctpsNumero = const Value.absent(),
    Value<String?> ctpsSerie = const Value.absent(),
    Value<DateTime?> ctpsDataExpedicao = const Value.absent(),
    Value<String?> ctpsUf = const Value.absent(),
    Value<String?> observacao = const Value.absent(),
    Value<String?> logradouro = const Value.absent(),
    Value<String?> numero = const Value.absent(),
    Value<String?> complemento = const Value.absent(),
    Value<String?> bairro = const Value.absent(),
    Value<String?> cidade = const Value.absent(),
    Value<String?> cep = const Value.absent(),
    Value<String?> municipioIbge = const Value.absent(),
    Value<String?> uf = const Value.absent(),
    Value<int?> idPessoa = const Value.absent(),
    Value<int?> idCargo = const Value.absent(),
    Value<int?> idSetor = const Value.absent(),
  }) => ViewPessoaColaborador(
    id: id.present ? id.value : this.id,
    nome: nome.present ? nome.value : this.nome,
    tipo: tipo.present ? tipo.value : this.tipo,
    email: email.present ? email.value : this.email,
    site: site.present ? site.value : this.site,
    cpfCnpj: cpfCnpj.present ? cpfCnpj.value : this.cpfCnpj,
    rgIe: rgIe.present ? rgIe.value : this.rgIe,
    matricula: matricula.present ? matricula.value : this.matricula,
    dataCadastro: dataCadastro.present ? dataCadastro.value : this.dataCadastro,
    dataAdmissao: dataAdmissao.present ? dataAdmissao.value : this.dataAdmissao,
    dataDemissao: dataDemissao.present ? dataDemissao.value : this.dataDemissao,
    ctpsNumero: ctpsNumero.present ? ctpsNumero.value : this.ctpsNumero,
    ctpsSerie: ctpsSerie.present ? ctpsSerie.value : this.ctpsSerie,
    ctpsDataExpedicao:
        ctpsDataExpedicao.present
            ? ctpsDataExpedicao.value
            : this.ctpsDataExpedicao,
    ctpsUf: ctpsUf.present ? ctpsUf.value : this.ctpsUf,
    observacao: observacao.present ? observacao.value : this.observacao,
    logradouro: logradouro.present ? logradouro.value : this.logradouro,
    numero: numero.present ? numero.value : this.numero,
    complemento: complemento.present ? complemento.value : this.complemento,
    bairro: bairro.present ? bairro.value : this.bairro,
    cidade: cidade.present ? cidade.value : this.cidade,
    cep: cep.present ? cep.value : this.cep,
    municipioIbge:
        municipioIbge.present ? municipioIbge.value : this.municipioIbge,
    uf: uf.present ? uf.value : this.uf,
    idPessoa: idPessoa.present ? idPessoa.value : this.idPessoa,
    idCargo: idCargo.present ? idCargo.value : this.idCargo,
    idSetor: idSetor.present ? idSetor.value : this.idSetor,
  );
  ViewPessoaColaborador copyWithCompanion(
    ViewPessoaColaboradorsCompanion data,
  ) {
    return ViewPessoaColaborador(
      id: data.id.present ? data.id.value : this.id,
      nome: data.nome.present ? data.nome.value : this.nome,
      tipo: data.tipo.present ? data.tipo.value : this.tipo,
      email: data.email.present ? data.email.value : this.email,
      site: data.site.present ? data.site.value : this.site,
      cpfCnpj: data.cpfCnpj.present ? data.cpfCnpj.value : this.cpfCnpj,
      rgIe: data.rgIe.present ? data.rgIe.value : this.rgIe,
      matricula: data.matricula.present ? data.matricula.value : this.matricula,
      dataCadastro:
          data.dataCadastro.present
              ? data.dataCadastro.value
              : this.dataCadastro,
      dataAdmissao:
          data.dataAdmissao.present
              ? data.dataAdmissao.value
              : this.dataAdmissao,
      dataDemissao:
          data.dataDemissao.present
              ? data.dataDemissao.value
              : this.dataDemissao,
      ctpsNumero:
          data.ctpsNumero.present ? data.ctpsNumero.value : this.ctpsNumero,
      ctpsSerie: data.ctpsSerie.present ? data.ctpsSerie.value : this.ctpsSerie,
      ctpsDataExpedicao:
          data.ctpsDataExpedicao.present
              ? data.ctpsDataExpedicao.value
              : this.ctpsDataExpedicao,
      ctpsUf: data.ctpsUf.present ? data.ctpsUf.value : this.ctpsUf,
      observacao:
          data.observacao.present ? data.observacao.value : this.observacao,
      logradouro:
          data.logradouro.present ? data.logradouro.value : this.logradouro,
      numero: data.numero.present ? data.numero.value : this.numero,
      complemento:
          data.complemento.present ? data.complemento.value : this.complemento,
      bairro: data.bairro.present ? data.bairro.value : this.bairro,
      cidade: data.cidade.present ? data.cidade.value : this.cidade,
      cep: data.cep.present ? data.cep.value : this.cep,
      municipioIbge:
          data.municipioIbge.present
              ? data.municipioIbge.value
              : this.municipioIbge,
      uf: data.uf.present ? data.uf.value : this.uf,
      idPessoa: data.idPessoa.present ? data.idPessoa.value : this.idPessoa,
      idCargo: data.idCargo.present ? data.idCargo.value : this.idCargo,
      idSetor: data.idSetor.present ? data.idSetor.value : this.idSetor,
    );
  }

  @override
  String toString() {
    return (StringBuffer('ViewPessoaColaborador(')
          ..write('id: $id, ')
          ..write('nome: $nome, ')
          ..write('tipo: $tipo, ')
          ..write('email: $email, ')
          ..write('site: $site, ')
          ..write('cpfCnpj: $cpfCnpj, ')
          ..write('rgIe: $rgIe, ')
          ..write('matricula: $matricula, ')
          ..write('dataCadastro: $dataCadastro, ')
          ..write('dataAdmissao: $dataAdmissao, ')
          ..write('dataDemissao: $dataDemissao, ')
          ..write('ctpsNumero: $ctpsNumero, ')
          ..write('ctpsSerie: $ctpsSerie, ')
          ..write('ctpsDataExpedicao: $ctpsDataExpedicao, ')
          ..write('ctpsUf: $ctpsUf, ')
          ..write('observacao: $observacao, ')
          ..write('logradouro: $logradouro, ')
          ..write('numero: $numero, ')
          ..write('complemento: $complemento, ')
          ..write('bairro: $bairro, ')
          ..write('cidade: $cidade, ')
          ..write('cep: $cep, ')
          ..write('municipioIbge: $municipioIbge, ')
          ..write('uf: $uf, ')
          ..write('idPessoa: $idPessoa, ')
          ..write('idCargo: $idCargo, ')
          ..write('idSetor: $idSetor')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hashAll([
    id,
    nome,
    tipo,
    email,
    site,
    cpfCnpj,
    rgIe,
    matricula,
    dataCadastro,
    dataAdmissao,
    dataDemissao,
    ctpsNumero,
    ctpsSerie,
    ctpsDataExpedicao,
    ctpsUf,
    observacao,
    logradouro,
    numero,
    complemento,
    bairro,
    cidade,
    cep,
    municipioIbge,
    uf,
    idPessoa,
    idCargo,
    idSetor,
  ]);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is ViewPessoaColaborador &&
          other.id == this.id &&
          other.nome == this.nome &&
          other.tipo == this.tipo &&
          other.email == this.email &&
          other.site == this.site &&
          other.cpfCnpj == this.cpfCnpj &&
          other.rgIe == this.rgIe &&
          other.matricula == this.matricula &&
          other.dataCadastro == this.dataCadastro &&
          other.dataAdmissao == this.dataAdmissao &&
          other.dataDemissao == this.dataDemissao &&
          other.ctpsNumero == this.ctpsNumero &&
          other.ctpsSerie == this.ctpsSerie &&
          other.ctpsDataExpedicao == this.ctpsDataExpedicao &&
          other.ctpsUf == this.ctpsUf &&
          other.observacao == this.observacao &&
          other.logradouro == this.logradouro &&
          other.numero == this.numero &&
          other.complemento == this.complemento &&
          other.bairro == this.bairro &&
          other.cidade == this.cidade &&
          other.cep == this.cep &&
          other.municipioIbge == this.municipioIbge &&
          other.uf == this.uf &&
          other.idPessoa == this.idPessoa &&
          other.idCargo == this.idCargo &&
          other.idSetor == this.idSetor);
}

class ViewPessoaColaboradorsCompanion
    extends UpdateCompanion<ViewPessoaColaborador> {
  final Value<int?> id;
  final Value<String?> nome;
  final Value<String?> tipo;
  final Value<String?> email;
  final Value<String?> site;
  final Value<String?> cpfCnpj;
  final Value<String?> rgIe;
  final Value<String?> matricula;
  final Value<DateTime?> dataCadastro;
  final Value<DateTime?> dataAdmissao;
  final Value<DateTime?> dataDemissao;
  final Value<String?> ctpsNumero;
  final Value<String?> ctpsSerie;
  final Value<DateTime?> ctpsDataExpedicao;
  final Value<String?> ctpsUf;
  final Value<String?> observacao;
  final Value<String?> logradouro;
  final Value<String?> numero;
  final Value<String?> complemento;
  final Value<String?> bairro;
  final Value<String?> cidade;
  final Value<String?> cep;
  final Value<String?> municipioIbge;
  final Value<String?> uf;
  final Value<int?> idPessoa;
  final Value<int?> idCargo;
  final Value<int?> idSetor;
  const ViewPessoaColaboradorsCompanion({
    this.id = const Value.absent(),
    this.nome = const Value.absent(),
    this.tipo = const Value.absent(),
    this.email = const Value.absent(),
    this.site = const Value.absent(),
    this.cpfCnpj = const Value.absent(),
    this.rgIe = const Value.absent(),
    this.matricula = const Value.absent(),
    this.dataCadastro = const Value.absent(),
    this.dataAdmissao = const Value.absent(),
    this.dataDemissao = const Value.absent(),
    this.ctpsNumero = const Value.absent(),
    this.ctpsSerie = const Value.absent(),
    this.ctpsDataExpedicao = const Value.absent(),
    this.ctpsUf = const Value.absent(),
    this.observacao = const Value.absent(),
    this.logradouro = const Value.absent(),
    this.numero = const Value.absent(),
    this.complemento = const Value.absent(),
    this.bairro = const Value.absent(),
    this.cidade = const Value.absent(),
    this.cep = const Value.absent(),
    this.municipioIbge = const Value.absent(),
    this.uf = const Value.absent(),
    this.idPessoa = const Value.absent(),
    this.idCargo = const Value.absent(),
    this.idSetor = const Value.absent(),
  });
  ViewPessoaColaboradorsCompanion.insert({
    this.id = const Value.absent(),
    this.nome = const Value.absent(),
    this.tipo = const Value.absent(),
    this.email = const Value.absent(),
    this.site = const Value.absent(),
    this.cpfCnpj = const Value.absent(),
    this.rgIe = const Value.absent(),
    this.matricula = const Value.absent(),
    this.dataCadastro = const Value.absent(),
    this.dataAdmissao = const Value.absent(),
    this.dataDemissao = const Value.absent(),
    this.ctpsNumero = const Value.absent(),
    this.ctpsSerie = const Value.absent(),
    this.ctpsDataExpedicao = const Value.absent(),
    this.ctpsUf = const Value.absent(),
    this.observacao = const Value.absent(),
    this.logradouro = const Value.absent(),
    this.numero = const Value.absent(),
    this.complemento = const Value.absent(),
    this.bairro = const Value.absent(),
    this.cidade = const Value.absent(),
    this.cep = const Value.absent(),
    this.municipioIbge = const Value.absent(),
    this.uf = const Value.absent(),
    this.idPessoa = const Value.absent(),
    this.idCargo = const Value.absent(),
    this.idSetor = const Value.absent(),
  });
  static Insertable<ViewPessoaColaborador> custom({
    Expression<int>? id,
    Expression<String>? nome,
    Expression<String>? tipo,
    Expression<String>? email,
    Expression<String>? site,
    Expression<String>? cpfCnpj,
    Expression<String>? rgIe,
    Expression<String>? matricula,
    Expression<DateTime>? dataCadastro,
    Expression<DateTime>? dataAdmissao,
    Expression<DateTime>? dataDemissao,
    Expression<String>? ctpsNumero,
    Expression<String>? ctpsSerie,
    Expression<DateTime>? ctpsDataExpedicao,
    Expression<String>? ctpsUf,
    Expression<String>? observacao,
    Expression<String>? logradouro,
    Expression<String>? numero,
    Expression<String>? complemento,
    Expression<String>? bairro,
    Expression<String>? cidade,
    Expression<String>? cep,
    Expression<String>? municipioIbge,
    Expression<String>? uf,
    Expression<int>? idPessoa,
    Expression<int>? idCargo,
    Expression<int>? idSetor,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (nome != null) 'nome': nome,
      if (tipo != null) 'tipo': tipo,
      if (email != null) 'email': email,
      if (site != null) 'site': site,
      if (cpfCnpj != null) 'cpf_cnpj': cpfCnpj,
      if (rgIe != null) 'rg_ie': rgIe,
      if (matricula != null) 'matricula': matricula,
      if (dataCadastro != null) 'data_cadastro': dataCadastro,
      if (dataAdmissao != null) 'data_admissao': dataAdmissao,
      if (dataDemissao != null) 'data_demissao': dataDemissao,
      if (ctpsNumero != null) 'ctps_numero': ctpsNumero,
      if (ctpsSerie != null) 'ctps_serie': ctpsSerie,
      if (ctpsDataExpedicao != null) 'ctps_data_expedicao': ctpsDataExpedicao,
      if (ctpsUf != null) 'ctps_uf': ctpsUf,
      if (observacao != null) 'observacao': observacao,
      if (logradouro != null) 'logradouro': logradouro,
      if (numero != null) 'numero': numero,
      if (complemento != null) 'complemento': complemento,
      if (bairro != null) 'bairro': bairro,
      if (cidade != null) 'cidade': cidade,
      if (cep != null) 'cep': cep,
      if (municipioIbge != null) 'municipio_ibge': municipioIbge,
      if (uf != null) 'uf': uf,
      if (idPessoa != null) 'id_pessoa': idPessoa,
      if (idCargo != null) 'id_cargo': idCargo,
      if (idSetor != null) 'id_setor': idSetor,
    });
  }

  ViewPessoaColaboradorsCompanion copyWith({
    Value<int?>? id,
    Value<String?>? nome,
    Value<String?>? tipo,
    Value<String?>? email,
    Value<String?>? site,
    Value<String?>? cpfCnpj,
    Value<String?>? rgIe,
    Value<String?>? matricula,
    Value<DateTime?>? dataCadastro,
    Value<DateTime?>? dataAdmissao,
    Value<DateTime?>? dataDemissao,
    Value<String?>? ctpsNumero,
    Value<String?>? ctpsSerie,
    Value<DateTime?>? ctpsDataExpedicao,
    Value<String?>? ctpsUf,
    Value<String?>? observacao,
    Value<String?>? logradouro,
    Value<String?>? numero,
    Value<String?>? complemento,
    Value<String?>? bairro,
    Value<String?>? cidade,
    Value<String?>? cep,
    Value<String?>? municipioIbge,
    Value<String?>? uf,
    Value<int?>? idPessoa,
    Value<int?>? idCargo,
    Value<int?>? idSetor,
  }) {
    return ViewPessoaColaboradorsCompanion(
      id: id ?? this.id,
      nome: nome ?? this.nome,
      tipo: tipo ?? this.tipo,
      email: email ?? this.email,
      site: site ?? this.site,
      cpfCnpj: cpfCnpj ?? this.cpfCnpj,
      rgIe: rgIe ?? this.rgIe,
      matricula: matricula ?? this.matricula,
      dataCadastro: dataCadastro ?? this.dataCadastro,
      dataAdmissao: dataAdmissao ?? this.dataAdmissao,
      dataDemissao: dataDemissao ?? this.dataDemissao,
      ctpsNumero: ctpsNumero ?? this.ctpsNumero,
      ctpsSerie: ctpsSerie ?? this.ctpsSerie,
      ctpsDataExpedicao: ctpsDataExpedicao ?? this.ctpsDataExpedicao,
      ctpsUf: ctpsUf ?? this.ctpsUf,
      observacao: observacao ?? this.observacao,
      logradouro: logradouro ?? this.logradouro,
      numero: numero ?? this.numero,
      complemento: complemento ?? this.complemento,
      bairro: bairro ?? this.bairro,
      cidade: cidade ?? this.cidade,
      cep: cep ?? this.cep,
      municipioIbge: municipioIbge ?? this.municipioIbge,
      uf: uf ?? this.uf,
      idPessoa: idPessoa ?? this.idPessoa,
      idCargo: idCargo ?? this.idCargo,
      idSetor: idSetor ?? this.idSetor,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (nome.present) {
      map['nome'] = Variable<String>(nome.value);
    }
    if (tipo.present) {
      map['tipo'] = Variable<String>(tipo.value);
    }
    if (email.present) {
      map['email'] = Variable<String>(email.value);
    }
    if (site.present) {
      map['site'] = Variable<String>(site.value);
    }
    if (cpfCnpj.present) {
      map['cpf_cnpj'] = Variable<String>(cpfCnpj.value);
    }
    if (rgIe.present) {
      map['rg_ie'] = Variable<String>(rgIe.value);
    }
    if (matricula.present) {
      map['matricula'] = Variable<String>(matricula.value);
    }
    if (dataCadastro.present) {
      map['data_cadastro'] = Variable<DateTime>(dataCadastro.value);
    }
    if (dataAdmissao.present) {
      map['data_admissao'] = Variable<DateTime>(dataAdmissao.value);
    }
    if (dataDemissao.present) {
      map['data_demissao'] = Variable<DateTime>(dataDemissao.value);
    }
    if (ctpsNumero.present) {
      map['ctps_numero'] = Variable<String>(ctpsNumero.value);
    }
    if (ctpsSerie.present) {
      map['ctps_serie'] = Variable<String>(ctpsSerie.value);
    }
    if (ctpsDataExpedicao.present) {
      map['ctps_data_expedicao'] = Variable<DateTime>(ctpsDataExpedicao.value);
    }
    if (ctpsUf.present) {
      map['ctps_uf'] = Variable<String>(ctpsUf.value);
    }
    if (observacao.present) {
      map['observacao'] = Variable<String>(observacao.value);
    }
    if (logradouro.present) {
      map['logradouro'] = Variable<String>(logradouro.value);
    }
    if (numero.present) {
      map['numero'] = Variable<String>(numero.value);
    }
    if (complemento.present) {
      map['complemento'] = Variable<String>(complemento.value);
    }
    if (bairro.present) {
      map['bairro'] = Variable<String>(bairro.value);
    }
    if (cidade.present) {
      map['cidade'] = Variable<String>(cidade.value);
    }
    if (cep.present) {
      map['cep'] = Variable<String>(cep.value);
    }
    if (municipioIbge.present) {
      map['municipio_ibge'] = Variable<String>(municipioIbge.value);
    }
    if (uf.present) {
      map['uf'] = Variable<String>(uf.value);
    }
    if (idPessoa.present) {
      map['id_pessoa'] = Variable<int>(idPessoa.value);
    }
    if (idCargo.present) {
      map['id_cargo'] = Variable<int>(idCargo.value);
    }
    if (idSetor.present) {
      map['id_setor'] = Variable<int>(idSetor.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('ViewPessoaColaboradorsCompanion(')
          ..write('id: $id, ')
          ..write('nome: $nome, ')
          ..write('tipo: $tipo, ')
          ..write('email: $email, ')
          ..write('site: $site, ')
          ..write('cpfCnpj: $cpfCnpj, ')
          ..write('rgIe: $rgIe, ')
          ..write('matricula: $matricula, ')
          ..write('dataCadastro: $dataCadastro, ')
          ..write('dataAdmissao: $dataAdmissao, ')
          ..write('dataDemissao: $dataDemissao, ')
          ..write('ctpsNumero: $ctpsNumero, ')
          ..write('ctpsSerie: $ctpsSerie, ')
          ..write('ctpsDataExpedicao: $ctpsDataExpedicao, ')
          ..write('ctpsUf: $ctpsUf, ')
          ..write('observacao: $observacao, ')
          ..write('logradouro: $logradouro, ')
          ..write('numero: $numero, ')
          ..write('complemento: $complemento, ')
          ..write('bairro: $bairro, ')
          ..write('cidade: $cidade, ')
          ..write('cep: $cep, ')
          ..write('municipioIbge: $municipioIbge, ')
          ..write('uf: $uf, ')
          ..write('idPessoa: $idPessoa, ')
          ..write('idCargo: $idCargo, ')
          ..write('idSetor: $idSetor')
          ..write(')'))
        .toString();
  }
}

class $ViewPessoaVendedorsTable extends ViewPessoaVendedors
    with TableInfo<$ViewPessoaVendedorsTable, ViewPessoaVendedor> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $ViewPessoaVendedorsTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
    'id',
    aliasedName,
    true,
    type: DriftSqlType.int,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _nomeMeta = const VerificationMeta('nome');
  @override
  late final GeneratedColumn<String> nome = GeneratedColumn<String>(
    'nome',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 450,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _tipoMeta = const VerificationMeta('tipo');
  @override
  late final GeneratedColumn<String> tipo = GeneratedColumn<String>(
    'tipo',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 3,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _emailMeta = const VerificationMeta('email');
  @override
  late final GeneratedColumn<String> email = GeneratedColumn<String>(
    'email',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 750,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _siteMeta = const VerificationMeta('site');
  @override
  late final GeneratedColumn<String> site = GeneratedColumn<String>(
    'site',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 450,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _cpfCnpjMeta = const VerificationMeta(
    'cpfCnpj',
  );
  @override
  late final GeneratedColumn<String> cpfCnpj = GeneratedColumn<String>(
    'cpf_cnpj',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 20,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _rgIeMeta = const VerificationMeta('rgIe');
  @override
  late final GeneratedColumn<String> rgIe = GeneratedColumn<String>(
    'rg_ie',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 20,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _matriculaMeta = const VerificationMeta(
    'matricula',
  );
  @override
  late final GeneratedColumn<String> matricula = GeneratedColumn<String>(
    'matricula',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 50,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _dataCadastroMeta = const VerificationMeta(
    'dataCadastro',
  );
  @override
  late final GeneratedColumn<DateTime> dataCadastro = GeneratedColumn<DateTime>(
    'data_cadastro',
    aliasedName,
    true,
    type: DriftSqlType.dateTime,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _dataAdmissaoMeta = const VerificationMeta(
    'dataAdmissao',
  );
  @override
  late final GeneratedColumn<DateTime> dataAdmissao = GeneratedColumn<DateTime>(
    'data_admissao',
    aliasedName,
    true,
    type: DriftSqlType.dateTime,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _dataDemissaoMeta = const VerificationMeta(
    'dataDemissao',
  );
  @override
  late final GeneratedColumn<DateTime> dataDemissao = GeneratedColumn<DateTime>(
    'data_demissao',
    aliasedName,
    true,
    type: DriftSqlType.dateTime,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _ctpsNumeroMeta = const VerificationMeta(
    'ctpsNumero',
  );
  @override
  late final GeneratedColumn<String> ctpsNumero = GeneratedColumn<String>(
    'ctps_numero',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 20,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _ctpsSerieMeta = const VerificationMeta(
    'ctpsSerie',
  );
  @override
  late final GeneratedColumn<String> ctpsSerie = GeneratedColumn<String>(
    'ctps_serie',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 10,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _ctpsDataExpedicaoMeta = const VerificationMeta(
    'ctpsDataExpedicao',
  );
  @override
  late final GeneratedColumn<DateTime> ctpsDataExpedicao =
      GeneratedColumn<DateTime>(
        'ctps_data_expedicao',
        aliasedName,
        true,
        type: DriftSqlType.dateTime,
        requiredDuringInsert: false,
      );
  static const VerificationMeta _ctpsUfMeta = const VerificationMeta('ctpsUf');
  @override
  late final GeneratedColumn<String> ctpsUf = GeneratedColumn<String>(
    'ctps_uf',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 2,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _observacaoMeta = const VerificationMeta(
    'observacao',
  );
  @override
  late final GeneratedColumn<String> observacao = GeneratedColumn<String>(
    'observacao',
    aliasedName,
    true,
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _logradouroMeta = const VerificationMeta(
    'logradouro',
  );
  @override
  late final GeneratedColumn<String> logradouro = GeneratedColumn<String>(
    'logradouro',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 450,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _numeroMeta = const VerificationMeta('numero');
  @override
  late final GeneratedColumn<String> numero = GeneratedColumn<String>(
    'numero',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 20,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _complementoMeta = const VerificationMeta(
    'complemento',
  );
  @override
  late final GeneratedColumn<String> complemento = GeneratedColumn<String>(
    'complemento',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 450,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _bairroMeta = const VerificationMeta('bairro');
  @override
  late final GeneratedColumn<String> bairro = GeneratedColumn<String>(
    'bairro',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 150,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _cidadeMeta = const VerificationMeta('cidade');
  @override
  late final GeneratedColumn<String> cidade = GeneratedColumn<String>(
    'cidade',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 150,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _cepMeta = const VerificationMeta('cep');
  @override
  late final GeneratedColumn<String> cep = GeneratedColumn<String>(
    'cep',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 10,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _municipioIbgeMeta = const VerificationMeta(
    'municipioIbge',
  );
  @override
  late final GeneratedColumn<String> municipioIbge = GeneratedColumn<String>(
    'municipio_ibge',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 10,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _ufMeta = const VerificationMeta('uf');
  @override
  late final GeneratedColumn<String> uf = GeneratedColumn<String>(
    'uf',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 2,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _idPessoaMeta = const VerificationMeta(
    'idPessoa',
  );
  @override
  late final GeneratedColumn<int> idPessoa = GeneratedColumn<int>(
    'id_pessoa',
    aliasedName,
    true,
    type: DriftSqlType.int,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _idCargoMeta = const VerificationMeta(
    'idCargo',
  );
  @override
  late final GeneratedColumn<int> idCargo = GeneratedColumn<int>(
    'id_cargo',
    aliasedName,
    true,
    type: DriftSqlType.int,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _idSetorMeta = const VerificationMeta(
    'idSetor',
  );
  @override
  late final GeneratedColumn<int> idSetor = GeneratedColumn<int>(
    'id_setor',
    aliasedName,
    true,
    type: DriftSqlType.int,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _comissaoMeta = const VerificationMeta(
    'comissao',
  );
  @override
  late final GeneratedColumn<double> comissao = GeneratedColumn<double>(
    'comissao',
    aliasedName,
    true,
    type: DriftSqlType.double,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _metaVendaMeta = const VerificationMeta(
    'metaVenda',
  );
  @override
  late final GeneratedColumn<double> metaVenda = GeneratedColumn<double>(
    'meta_venda',
    aliasedName,
    true,
    type: DriftSqlType.double,
    requiredDuringInsert: false,
  );
  @override
  List<GeneratedColumn> get $columns => [
    id,
    nome,
    tipo,
    email,
    site,
    cpfCnpj,
    rgIe,
    matricula,
    dataCadastro,
    dataAdmissao,
    dataDemissao,
    ctpsNumero,
    ctpsSerie,
    ctpsDataExpedicao,
    ctpsUf,
    observacao,
    logradouro,
    numero,
    complemento,
    bairro,
    cidade,
    cep,
    municipioIbge,
    uf,
    idPessoa,
    idCargo,
    idSetor,
    comissao,
    metaVenda,
  ];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'view_pessoa_vendedor';
  @override
  VerificationContext validateIntegrity(
    Insertable<ViewPessoaVendedor> instance, {
    bool isInserting = false,
  }) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('nome')) {
      context.handle(
        _nomeMeta,
        nome.isAcceptableOrUnknown(data['nome']!, _nomeMeta),
      );
    }
    if (data.containsKey('tipo')) {
      context.handle(
        _tipoMeta,
        tipo.isAcceptableOrUnknown(data['tipo']!, _tipoMeta),
      );
    }
    if (data.containsKey('email')) {
      context.handle(
        _emailMeta,
        email.isAcceptableOrUnknown(data['email']!, _emailMeta),
      );
    }
    if (data.containsKey('site')) {
      context.handle(
        _siteMeta,
        site.isAcceptableOrUnknown(data['site']!, _siteMeta),
      );
    }
    if (data.containsKey('cpf_cnpj')) {
      context.handle(
        _cpfCnpjMeta,
        cpfCnpj.isAcceptableOrUnknown(data['cpf_cnpj']!, _cpfCnpjMeta),
      );
    }
    if (data.containsKey('rg_ie')) {
      context.handle(
        _rgIeMeta,
        rgIe.isAcceptableOrUnknown(data['rg_ie']!, _rgIeMeta),
      );
    }
    if (data.containsKey('matricula')) {
      context.handle(
        _matriculaMeta,
        matricula.isAcceptableOrUnknown(data['matricula']!, _matriculaMeta),
      );
    }
    if (data.containsKey('data_cadastro')) {
      context.handle(
        _dataCadastroMeta,
        dataCadastro.isAcceptableOrUnknown(
          data['data_cadastro']!,
          _dataCadastroMeta,
        ),
      );
    }
    if (data.containsKey('data_admissao')) {
      context.handle(
        _dataAdmissaoMeta,
        dataAdmissao.isAcceptableOrUnknown(
          data['data_admissao']!,
          _dataAdmissaoMeta,
        ),
      );
    }
    if (data.containsKey('data_demissao')) {
      context.handle(
        _dataDemissaoMeta,
        dataDemissao.isAcceptableOrUnknown(
          data['data_demissao']!,
          _dataDemissaoMeta,
        ),
      );
    }
    if (data.containsKey('ctps_numero')) {
      context.handle(
        _ctpsNumeroMeta,
        ctpsNumero.isAcceptableOrUnknown(data['ctps_numero']!, _ctpsNumeroMeta),
      );
    }
    if (data.containsKey('ctps_serie')) {
      context.handle(
        _ctpsSerieMeta,
        ctpsSerie.isAcceptableOrUnknown(data['ctps_serie']!, _ctpsSerieMeta),
      );
    }
    if (data.containsKey('ctps_data_expedicao')) {
      context.handle(
        _ctpsDataExpedicaoMeta,
        ctpsDataExpedicao.isAcceptableOrUnknown(
          data['ctps_data_expedicao']!,
          _ctpsDataExpedicaoMeta,
        ),
      );
    }
    if (data.containsKey('ctps_uf')) {
      context.handle(
        _ctpsUfMeta,
        ctpsUf.isAcceptableOrUnknown(data['ctps_uf']!, _ctpsUfMeta),
      );
    }
    if (data.containsKey('observacao')) {
      context.handle(
        _observacaoMeta,
        observacao.isAcceptableOrUnknown(data['observacao']!, _observacaoMeta),
      );
    }
    if (data.containsKey('logradouro')) {
      context.handle(
        _logradouroMeta,
        logradouro.isAcceptableOrUnknown(data['logradouro']!, _logradouroMeta),
      );
    }
    if (data.containsKey('numero')) {
      context.handle(
        _numeroMeta,
        numero.isAcceptableOrUnknown(data['numero']!, _numeroMeta),
      );
    }
    if (data.containsKey('complemento')) {
      context.handle(
        _complementoMeta,
        complemento.isAcceptableOrUnknown(
          data['complemento']!,
          _complementoMeta,
        ),
      );
    }
    if (data.containsKey('bairro')) {
      context.handle(
        _bairroMeta,
        bairro.isAcceptableOrUnknown(data['bairro']!, _bairroMeta),
      );
    }
    if (data.containsKey('cidade')) {
      context.handle(
        _cidadeMeta,
        cidade.isAcceptableOrUnknown(data['cidade']!, _cidadeMeta),
      );
    }
    if (data.containsKey('cep')) {
      context.handle(
        _cepMeta,
        cep.isAcceptableOrUnknown(data['cep']!, _cepMeta),
      );
    }
    if (data.containsKey('municipio_ibge')) {
      context.handle(
        _municipioIbgeMeta,
        municipioIbge.isAcceptableOrUnknown(
          data['municipio_ibge']!,
          _municipioIbgeMeta,
        ),
      );
    }
    if (data.containsKey('uf')) {
      context.handle(_ufMeta, uf.isAcceptableOrUnknown(data['uf']!, _ufMeta));
    }
    if (data.containsKey('id_pessoa')) {
      context.handle(
        _idPessoaMeta,
        idPessoa.isAcceptableOrUnknown(data['id_pessoa']!, _idPessoaMeta),
      );
    }
    if (data.containsKey('id_cargo')) {
      context.handle(
        _idCargoMeta,
        idCargo.isAcceptableOrUnknown(data['id_cargo']!, _idCargoMeta),
      );
    }
    if (data.containsKey('id_setor')) {
      context.handle(
        _idSetorMeta,
        idSetor.isAcceptableOrUnknown(data['id_setor']!, _idSetorMeta),
      );
    }
    if (data.containsKey('comissao')) {
      context.handle(
        _comissaoMeta,
        comissao.isAcceptableOrUnknown(data['comissao']!, _comissaoMeta),
      );
    }
    if (data.containsKey('meta_venda')) {
      context.handle(
        _metaVendaMeta,
        metaVenda.isAcceptableOrUnknown(data['meta_venda']!, _metaVendaMeta),
      );
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  ViewPessoaVendedor map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return ViewPessoaVendedor(
      id: attachedDatabase.typeMapping.read(
        DriftSqlType.int,
        data['${effectivePrefix}id'],
      ),
      nome: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}nome'],
      ),
      tipo: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}tipo'],
      ),
      email: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}email'],
      ),
      site: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}site'],
      ),
      cpfCnpj: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}cpf_cnpj'],
      ),
      rgIe: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}rg_ie'],
      ),
      matricula: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}matricula'],
      ),
      dataCadastro: attachedDatabase.typeMapping.read(
        DriftSqlType.dateTime,
        data['${effectivePrefix}data_cadastro'],
      ),
      dataAdmissao: attachedDatabase.typeMapping.read(
        DriftSqlType.dateTime,
        data['${effectivePrefix}data_admissao'],
      ),
      dataDemissao: attachedDatabase.typeMapping.read(
        DriftSqlType.dateTime,
        data['${effectivePrefix}data_demissao'],
      ),
      ctpsNumero: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}ctps_numero'],
      ),
      ctpsSerie: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}ctps_serie'],
      ),
      ctpsDataExpedicao: attachedDatabase.typeMapping.read(
        DriftSqlType.dateTime,
        data['${effectivePrefix}ctps_data_expedicao'],
      ),
      ctpsUf: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}ctps_uf'],
      ),
      observacao: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}observacao'],
      ),
      logradouro: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}logradouro'],
      ),
      numero: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}numero'],
      ),
      complemento: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}complemento'],
      ),
      bairro: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}bairro'],
      ),
      cidade: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}cidade'],
      ),
      cep: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}cep'],
      ),
      municipioIbge: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}municipio_ibge'],
      ),
      uf: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}uf'],
      ),
      idPessoa: attachedDatabase.typeMapping.read(
        DriftSqlType.int,
        data['${effectivePrefix}id_pessoa'],
      ),
      idCargo: attachedDatabase.typeMapping.read(
        DriftSqlType.int,
        data['${effectivePrefix}id_cargo'],
      ),
      idSetor: attachedDatabase.typeMapping.read(
        DriftSqlType.int,
        data['${effectivePrefix}id_setor'],
      ),
      comissao: attachedDatabase.typeMapping.read(
        DriftSqlType.double,
        data['${effectivePrefix}comissao'],
      ),
      metaVenda: attachedDatabase.typeMapping.read(
        DriftSqlType.double,
        data['${effectivePrefix}meta_venda'],
      ),
    );
  }

  @override
  $ViewPessoaVendedorsTable createAlias(String alias) {
    return $ViewPessoaVendedorsTable(attachedDatabase, alias);
  }
}

class ViewPessoaVendedor extends DataClass
    implements Insertable<ViewPessoaVendedor> {
  final int? id;
  final String? nome;
  final String? tipo;
  final String? email;
  final String? site;
  final String? cpfCnpj;
  final String? rgIe;
  final String? matricula;
  final DateTime? dataCadastro;
  final DateTime? dataAdmissao;
  final DateTime? dataDemissao;
  final String? ctpsNumero;
  final String? ctpsSerie;
  final DateTime? ctpsDataExpedicao;
  final String? ctpsUf;
  final String? observacao;
  final String? logradouro;
  final String? numero;
  final String? complemento;
  final String? bairro;
  final String? cidade;
  final String? cep;
  final String? municipioIbge;
  final String? uf;
  final int? idPessoa;
  final int? idCargo;
  final int? idSetor;
  final double? comissao;
  final double? metaVenda;
  const ViewPessoaVendedor({
    this.id,
    this.nome,
    this.tipo,
    this.email,
    this.site,
    this.cpfCnpj,
    this.rgIe,
    this.matricula,
    this.dataCadastro,
    this.dataAdmissao,
    this.dataDemissao,
    this.ctpsNumero,
    this.ctpsSerie,
    this.ctpsDataExpedicao,
    this.ctpsUf,
    this.observacao,
    this.logradouro,
    this.numero,
    this.complemento,
    this.bairro,
    this.cidade,
    this.cep,
    this.municipioIbge,
    this.uf,
    this.idPessoa,
    this.idCargo,
    this.idSetor,
    this.comissao,
    this.metaVenda,
  });
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || nome != null) {
      map['nome'] = Variable<String>(nome);
    }
    if (!nullToAbsent || tipo != null) {
      map['tipo'] = Variable<String>(tipo);
    }
    if (!nullToAbsent || email != null) {
      map['email'] = Variable<String>(email);
    }
    if (!nullToAbsent || site != null) {
      map['site'] = Variable<String>(site);
    }
    if (!nullToAbsent || cpfCnpj != null) {
      map['cpf_cnpj'] = Variable<String>(cpfCnpj);
    }
    if (!nullToAbsent || rgIe != null) {
      map['rg_ie'] = Variable<String>(rgIe);
    }
    if (!nullToAbsent || matricula != null) {
      map['matricula'] = Variable<String>(matricula);
    }
    if (!nullToAbsent || dataCadastro != null) {
      map['data_cadastro'] = Variable<DateTime>(dataCadastro);
    }
    if (!nullToAbsent || dataAdmissao != null) {
      map['data_admissao'] = Variable<DateTime>(dataAdmissao);
    }
    if (!nullToAbsent || dataDemissao != null) {
      map['data_demissao'] = Variable<DateTime>(dataDemissao);
    }
    if (!nullToAbsent || ctpsNumero != null) {
      map['ctps_numero'] = Variable<String>(ctpsNumero);
    }
    if (!nullToAbsent || ctpsSerie != null) {
      map['ctps_serie'] = Variable<String>(ctpsSerie);
    }
    if (!nullToAbsent || ctpsDataExpedicao != null) {
      map['ctps_data_expedicao'] = Variable<DateTime>(ctpsDataExpedicao);
    }
    if (!nullToAbsent || ctpsUf != null) {
      map['ctps_uf'] = Variable<String>(ctpsUf);
    }
    if (!nullToAbsent || observacao != null) {
      map['observacao'] = Variable<String>(observacao);
    }
    if (!nullToAbsent || logradouro != null) {
      map['logradouro'] = Variable<String>(logradouro);
    }
    if (!nullToAbsent || numero != null) {
      map['numero'] = Variable<String>(numero);
    }
    if (!nullToAbsent || complemento != null) {
      map['complemento'] = Variable<String>(complemento);
    }
    if (!nullToAbsent || bairro != null) {
      map['bairro'] = Variable<String>(bairro);
    }
    if (!nullToAbsent || cidade != null) {
      map['cidade'] = Variable<String>(cidade);
    }
    if (!nullToAbsent || cep != null) {
      map['cep'] = Variable<String>(cep);
    }
    if (!nullToAbsent || municipioIbge != null) {
      map['municipio_ibge'] = Variable<String>(municipioIbge);
    }
    if (!nullToAbsent || uf != null) {
      map['uf'] = Variable<String>(uf);
    }
    if (!nullToAbsent || idPessoa != null) {
      map['id_pessoa'] = Variable<int>(idPessoa);
    }
    if (!nullToAbsent || idCargo != null) {
      map['id_cargo'] = Variable<int>(idCargo);
    }
    if (!nullToAbsent || idSetor != null) {
      map['id_setor'] = Variable<int>(idSetor);
    }
    if (!nullToAbsent || comissao != null) {
      map['comissao'] = Variable<double>(comissao);
    }
    if (!nullToAbsent || metaVenda != null) {
      map['meta_venda'] = Variable<double>(metaVenda);
    }
    return map;
  }

  factory ViewPessoaVendedor.fromJson(
    Map<String, dynamic> json, {
    ValueSerializer? serializer,
  }) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return ViewPessoaVendedor(
      id: serializer.fromJson<int?>(json['id']),
      nome: serializer.fromJson<String?>(json['nome']),
      tipo: serializer.fromJson<String?>(json['tipo']),
      email: serializer.fromJson<String?>(json['email']),
      site: serializer.fromJson<String?>(json['site']),
      cpfCnpj: serializer.fromJson<String?>(json['cpfCnpj']),
      rgIe: serializer.fromJson<String?>(json['rgIe']),
      matricula: serializer.fromJson<String?>(json['matricula']),
      dataCadastro: serializer.fromJson<DateTime?>(json['dataCadastro']),
      dataAdmissao: serializer.fromJson<DateTime?>(json['dataAdmissao']),
      dataDemissao: serializer.fromJson<DateTime?>(json['dataDemissao']),
      ctpsNumero: serializer.fromJson<String?>(json['ctpsNumero']),
      ctpsSerie: serializer.fromJson<String?>(json['ctpsSerie']),
      ctpsDataExpedicao: serializer.fromJson<DateTime?>(
        json['ctpsDataExpedicao'],
      ),
      ctpsUf: serializer.fromJson<String?>(json['ctpsUf']),
      observacao: serializer.fromJson<String?>(json['observacao']),
      logradouro: serializer.fromJson<String?>(json['logradouro']),
      numero: serializer.fromJson<String?>(json['numero']),
      complemento: serializer.fromJson<String?>(json['complemento']),
      bairro: serializer.fromJson<String?>(json['bairro']),
      cidade: serializer.fromJson<String?>(json['cidade']),
      cep: serializer.fromJson<String?>(json['cep']),
      municipioIbge: serializer.fromJson<String?>(json['municipioIbge']),
      uf: serializer.fromJson<String?>(json['uf']),
      idPessoa: serializer.fromJson<int?>(json['idPessoa']),
      idCargo: serializer.fromJson<int?>(json['idCargo']),
      idSetor: serializer.fromJson<int?>(json['idSetor']),
      comissao: serializer.fromJson<double?>(json['comissao']),
      metaVenda: serializer.fromJson<double?>(json['metaVenda']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'nome': serializer.toJson<String?>(nome),
      'tipo': serializer.toJson<String?>(tipo),
      'email': serializer.toJson<String?>(email),
      'site': serializer.toJson<String?>(site),
      'cpfCnpj': serializer.toJson<String?>(cpfCnpj),
      'rgIe': serializer.toJson<String?>(rgIe),
      'matricula': serializer.toJson<String?>(matricula),
      'dataCadastro': serializer.toJson<DateTime?>(dataCadastro),
      'dataAdmissao': serializer.toJson<DateTime?>(dataAdmissao),
      'dataDemissao': serializer.toJson<DateTime?>(dataDemissao),
      'ctpsNumero': serializer.toJson<String?>(ctpsNumero),
      'ctpsSerie': serializer.toJson<String?>(ctpsSerie),
      'ctpsDataExpedicao': serializer.toJson<DateTime?>(ctpsDataExpedicao),
      'ctpsUf': serializer.toJson<String?>(ctpsUf),
      'observacao': serializer.toJson<String?>(observacao),
      'logradouro': serializer.toJson<String?>(logradouro),
      'numero': serializer.toJson<String?>(numero),
      'complemento': serializer.toJson<String?>(complemento),
      'bairro': serializer.toJson<String?>(bairro),
      'cidade': serializer.toJson<String?>(cidade),
      'cep': serializer.toJson<String?>(cep),
      'municipioIbge': serializer.toJson<String?>(municipioIbge),
      'uf': serializer.toJson<String?>(uf),
      'idPessoa': serializer.toJson<int?>(idPessoa),
      'idCargo': serializer.toJson<int?>(idCargo),
      'idSetor': serializer.toJson<int?>(idSetor),
      'comissao': serializer.toJson<double?>(comissao),
      'metaVenda': serializer.toJson<double?>(metaVenda),
    };
  }

  ViewPessoaVendedor copyWith({
    Value<int?> id = const Value.absent(),
    Value<String?> nome = const Value.absent(),
    Value<String?> tipo = const Value.absent(),
    Value<String?> email = const Value.absent(),
    Value<String?> site = const Value.absent(),
    Value<String?> cpfCnpj = const Value.absent(),
    Value<String?> rgIe = const Value.absent(),
    Value<String?> matricula = const Value.absent(),
    Value<DateTime?> dataCadastro = const Value.absent(),
    Value<DateTime?> dataAdmissao = const Value.absent(),
    Value<DateTime?> dataDemissao = const Value.absent(),
    Value<String?> ctpsNumero = const Value.absent(),
    Value<String?> ctpsSerie = const Value.absent(),
    Value<DateTime?> ctpsDataExpedicao = const Value.absent(),
    Value<String?> ctpsUf = const Value.absent(),
    Value<String?> observacao = const Value.absent(),
    Value<String?> logradouro = const Value.absent(),
    Value<String?> numero = const Value.absent(),
    Value<String?> complemento = const Value.absent(),
    Value<String?> bairro = const Value.absent(),
    Value<String?> cidade = const Value.absent(),
    Value<String?> cep = const Value.absent(),
    Value<String?> municipioIbge = const Value.absent(),
    Value<String?> uf = const Value.absent(),
    Value<int?> idPessoa = const Value.absent(),
    Value<int?> idCargo = const Value.absent(),
    Value<int?> idSetor = const Value.absent(),
    Value<double?> comissao = const Value.absent(),
    Value<double?> metaVenda = const Value.absent(),
  }) => ViewPessoaVendedor(
    id: id.present ? id.value : this.id,
    nome: nome.present ? nome.value : this.nome,
    tipo: tipo.present ? tipo.value : this.tipo,
    email: email.present ? email.value : this.email,
    site: site.present ? site.value : this.site,
    cpfCnpj: cpfCnpj.present ? cpfCnpj.value : this.cpfCnpj,
    rgIe: rgIe.present ? rgIe.value : this.rgIe,
    matricula: matricula.present ? matricula.value : this.matricula,
    dataCadastro: dataCadastro.present ? dataCadastro.value : this.dataCadastro,
    dataAdmissao: dataAdmissao.present ? dataAdmissao.value : this.dataAdmissao,
    dataDemissao: dataDemissao.present ? dataDemissao.value : this.dataDemissao,
    ctpsNumero: ctpsNumero.present ? ctpsNumero.value : this.ctpsNumero,
    ctpsSerie: ctpsSerie.present ? ctpsSerie.value : this.ctpsSerie,
    ctpsDataExpedicao:
        ctpsDataExpedicao.present
            ? ctpsDataExpedicao.value
            : this.ctpsDataExpedicao,
    ctpsUf: ctpsUf.present ? ctpsUf.value : this.ctpsUf,
    observacao: observacao.present ? observacao.value : this.observacao,
    logradouro: logradouro.present ? logradouro.value : this.logradouro,
    numero: numero.present ? numero.value : this.numero,
    complemento: complemento.present ? complemento.value : this.complemento,
    bairro: bairro.present ? bairro.value : this.bairro,
    cidade: cidade.present ? cidade.value : this.cidade,
    cep: cep.present ? cep.value : this.cep,
    municipioIbge:
        municipioIbge.present ? municipioIbge.value : this.municipioIbge,
    uf: uf.present ? uf.value : this.uf,
    idPessoa: idPessoa.present ? idPessoa.value : this.idPessoa,
    idCargo: idCargo.present ? idCargo.value : this.idCargo,
    idSetor: idSetor.present ? idSetor.value : this.idSetor,
    comissao: comissao.present ? comissao.value : this.comissao,
    metaVenda: metaVenda.present ? metaVenda.value : this.metaVenda,
  );
  ViewPessoaVendedor copyWithCompanion(ViewPessoaVendedorsCompanion data) {
    return ViewPessoaVendedor(
      id: data.id.present ? data.id.value : this.id,
      nome: data.nome.present ? data.nome.value : this.nome,
      tipo: data.tipo.present ? data.tipo.value : this.tipo,
      email: data.email.present ? data.email.value : this.email,
      site: data.site.present ? data.site.value : this.site,
      cpfCnpj: data.cpfCnpj.present ? data.cpfCnpj.value : this.cpfCnpj,
      rgIe: data.rgIe.present ? data.rgIe.value : this.rgIe,
      matricula: data.matricula.present ? data.matricula.value : this.matricula,
      dataCadastro:
          data.dataCadastro.present
              ? data.dataCadastro.value
              : this.dataCadastro,
      dataAdmissao:
          data.dataAdmissao.present
              ? data.dataAdmissao.value
              : this.dataAdmissao,
      dataDemissao:
          data.dataDemissao.present
              ? data.dataDemissao.value
              : this.dataDemissao,
      ctpsNumero:
          data.ctpsNumero.present ? data.ctpsNumero.value : this.ctpsNumero,
      ctpsSerie: data.ctpsSerie.present ? data.ctpsSerie.value : this.ctpsSerie,
      ctpsDataExpedicao:
          data.ctpsDataExpedicao.present
              ? data.ctpsDataExpedicao.value
              : this.ctpsDataExpedicao,
      ctpsUf: data.ctpsUf.present ? data.ctpsUf.value : this.ctpsUf,
      observacao:
          data.observacao.present ? data.observacao.value : this.observacao,
      logradouro:
          data.logradouro.present ? data.logradouro.value : this.logradouro,
      numero: data.numero.present ? data.numero.value : this.numero,
      complemento:
          data.complemento.present ? data.complemento.value : this.complemento,
      bairro: data.bairro.present ? data.bairro.value : this.bairro,
      cidade: data.cidade.present ? data.cidade.value : this.cidade,
      cep: data.cep.present ? data.cep.value : this.cep,
      municipioIbge:
          data.municipioIbge.present
              ? data.municipioIbge.value
              : this.municipioIbge,
      uf: data.uf.present ? data.uf.value : this.uf,
      idPessoa: data.idPessoa.present ? data.idPessoa.value : this.idPessoa,
      idCargo: data.idCargo.present ? data.idCargo.value : this.idCargo,
      idSetor: data.idSetor.present ? data.idSetor.value : this.idSetor,
      comissao: data.comissao.present ? data.comissao.value : this.comissao,
      metaVenda: data.metaVenda.present ? data.metaVenda.value : this.metaVenda,
    );
  }

  @override
  String toString() {
    return (StringBuffer('ViewPessoaVendedor(')
          ..write('id: $id, ')
          ..write('nome: $nome, ')
          ..write('tipo: $tipo, ')
          ..write('email: $email, ')
          ..write('site: $site, ')
          ..write('cpfCnpj: $cpfCnpj, ')
          ..write('rgIe: $rgIe, ')
          ..write('matricula: $matricula, ')
          ..write('dataCadastro: $dataCadastro, ')
          ..write('dataAdmissao: $dataAdmissao, ')
          ..write('dataDemissao: $dataDemissao, ')
          ..write('ctpsNumero: $ctpsNumero, ')
          ..write('ctpsSerie: $ctpsSerie, ')
          ..write('ctpsDataExpedicao: $ctpsDataExpedicao, ')
          ..write('ctpsUf: $ctpsUf, ')
          ..write('observacao: $observacao, ')
          ..write('logradouro: $logradouro, ')
          ..write('numero: $numero, ')
          ..write('complemento: $complemento, ')
          ..write('bairro: $bairro, ')
          ..write('cidade: $cidade, ')
          ..write('cep: $cep, ')
          ..write('municipioIbge: $municipioIbge, ')
          ..write('uf: $uf, ')
          ..write('idPessoa: $idPessoa, ')
          ..write('idCargo: $idCargo, ')
          ..write('idSetor: $idSetor, ')
          ..write('comissao: $comissao, ')
          ..write('metaVenda: $metaVenda')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hashAll([
    id,
    nome,
    tipo,
    email,
    site,
    cpfCnpj,
    rgIe,
    matricula,
    dataCadastro,
    dataAdmissao,
    dataDemissao,
    ctpsNumero,
    ctpsSerie,
    ctpsDataExpedicao,
    ctpsUf,
    observacao,
    logradouro,
    numero,
    complemento,
    bairro,
    cidade,
    cep,
    municipioIbge,
    uf,
    idPessoa,
    idCargo,
    idSetor,
    comissao,
    metaVenda,
  ]);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is ViewPessoaVendedor &&
          other.id == this.id &&
          other.nome == this.nome &&
          other.tipo == this.tipo &&
          other.email == this.email &&
          other.site == this.site &&
          other.cpfCnpj == this.cpfCnpj &&
          other.rgIe == this.rgIe &&
          other.matricula == this.matricula &&
          other.dataCadastro == this.dataCadastro &&
          other.dataAdmissao == this.dataAdmissao &&
          other.dataDemissao == this.dataDemissao &&
          other.ctpsNumero == this.ctpsNumero &&
          other.ctpsSerie == this.ctpsSerie &&
          other.ctpsDataExpedicao == this.ctpsDataExpedicao &&
          other.ctpsUf == this.ctpsUf &&
          other.observacao == this.observacao &&
          other.logradouro == this.logradouro &&
          other.numero == this.numero &&
          other.complemento == this.complemento &&
          other.bairro == this.bairro &&
          other.cidade == this.cidade &&
          other.cep == this.cep &&
          other.municipioIbge == this.municipioIbge &&
          other.uf == this.uf &&
          other.idPessoa == this.idPessoa &&
          other.idCargo == this.idCargo &&
          other.idSetor == this.idSetor &&
          other.comissao == this.comissao &&
          other.metaVenda == this.metaVenda);
}

class ViewPessoaVendedorsCompanion extends UpdateCompanion<ViewPessoaVendedor> {
  final Value<int?> id;
  final Value<String?> nome;
  final Value<String?> tipo;
  final Value<String?> email;
  final Value<String?> site;
  final Value<String?> cpfCnpj;
  final Value<String?> rgIe;
  final Value<String?> matricula;
  final Value<DateTime?> dataCadastro;
  final Value<DateTime?> dataAdmissao;
  final Value<DateTime?> dataDemissao;
  final Value<String?> ctpsNumero;
  final Value<String?> ctpsSerie;
  final Value<DateTime?> ctpsDataExpedicao;
  final Value<String?> ctpsUf;
  final Value<String?> observacao;
  final Value<String?> logradouro;
  final Value<String?> numero;
  final Value<String?> complemento;
  final Value<String?> bairro;
  final Value<String?> cidade;
  final Value<String?> cep;
  final Value<String?> municipioIbge;
  final Value<String?> uf;
  final Value<int?> idPessoa;
  final Value<int?> idCargo;
  final Value<int?> idSetor;
  final Value<double?> comissao;
  final Value<double?> metaVenda;
  const ViewPessoaVendedorsCompanion({
    this.id = const Value.absent(),
    this.nome = const Value.absent(),
    this.tipo = const Value.absent(),
    this.email = const Value.absent(),
    this.site = const Value.absent(),
    this.cpfCnpj = const Value.absent(),
    this.rgIe = const Value.absent(),
    this.matricula = const Value.absent(),
    this.dataCadastro = const Value.absent(),
    this.dataAdmissao = const Value.absent(),
    this.dataDemissao = const Value.absent(),
    this.ctpsNumero = const Value.absent(),
    this.ctpsSerie = const Value.absent(),
    this.ctpsDataExpedicao = const Value.absent(),
    this.ctpsUf = const Value.absent(),
    this.observacao = const Value.absent(),
    this.logradouro = const Value.absent(),
    this.numero = const Value.absent(),
    this.complemento = const Value.absent(),
    this.bairro = const Value.absent(),
    this.cidade = const Value.absent(),
    this.cep = const Value.absent(),
    this.municipioIbge = const Value.absent(),
    this.uf = const Value.absent(),
    this.idPessoa = const Value.absent(),
    this.idCargo = const Value.absent(),
    this.idSetor = const Value.absent(),
    this.comissao = const Value.absent(),
    this.metaVenda = const Value.absent(),
  });
  ViewPessoaVendedorsCompanion.insert({
    this.id = const Value.absent(),
    this.nome = const Value.absent(),
    this.tipo = const Value.absent(),
    this.email = const Value.absent(),
    this.site = const Value.absent(),
    this.cpfCnpj = const Value.absent(),
    this.rgIe = const Value.absent(),
    this.matricula = const Value.absent(),
    this.dataCadastro = const Value.absent(),
    this.dataAdmissao = const Value.absent(),
    this.dataDemissao = const Value.absent(),
    this.ctpsNumero = const Value.absent(),
    this.ctpsSerie = const Value.absent(),
    this.ctpsDataExpedicao = const Value.absent(),
    this.ctpsUf = const Value.absent(),
    this.observacao = const Value.absent(),
    this.logradouro = const Value.absent(),
    this.numero = const Value.absent(),
    this.complemento = const Value.absent(),
    this.bairro = const Value.absent(),
    this.cidade = const Value.absent(),
    this.cep = const Value.absent(),
    this.municipioIbge = const Value.absent(),
    this.uf = const Value.absent(),
    this.idPessoa = const Value.absent(),
    this.idCargo = const Value.absent(),
    this.idSetor = const Value.absent(),
    this.comissao = const Value.absent(),
    this.metaVenda = const Value.absent(),
  });
  static Insertable<ViewPessoaVendedor> custom({
    Expression<int>? id,
    Expression<String>? nome,
    Expression<String>? tipo,
    Expression<String>? email,
    Expression<String>? site,
    Expression<String>? cpfCnpj,
    Expression<String>? rgIe,
    Expression<String>? matricula,
    Expression<DateTime>? dataCadastro,
    Expression<DateTime>? dataAdmissao,
    Expression<DateTime>? dataDemissao,
    Expression<String>? ctpsNumero,
    Expression<String>? ctpsSerie,
    Expression<DateTime>? ctpsDataExpedicao,
    Expression<String>? ctpsUf,
    Expression<String>? observacao,
    Expression<String>? logradouro,
    Expression<String>? numero,
    Expression<String>? complemento,
    Expression<String>? bairro,
    Expression<String>? cidade,
    Expression<String>? cep,
    Expression<String>? municipioIbge,
    Expression<String>? uf,
    Expression<int>? idPessoa,
    Expression<int>? idCargo,
    Expression<int>? idSetor,
    Expression<double>? comissao,
    Expression<double>? metaVenda,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (nome != null) 'nome': nome,
      if (tipo != null) 'tipo': tipo,
      if (email != null) 'email': email,
      if (site != null) 'site': site,
      if (cpfCnpj != null) 'cpf_cnpj': cpfCnpj,
      if (rgIe != null) 'rg_ie': rgIe,
      if (matricula != null) 'matricula': matricula,
      if (dataCadastro != null) 'data_cadastro': dataCadastro,
      if (dataAdmissao != null) 'data_admissao': dataAdmissao,
      if (dataDemissao != null) 'data_demissao': dataDemissao,
      if (ctpsNumero != null) 'ctps_numero': ctpsNumero,
      if (ctpsSerie != null) 'ctps_serie': ctpsSerie,
      if (ctpsDataExpedicao != null) 'ctps_data_expedicao': ctpsDataExpedicao,
      if (ctpsUf != null) 'ctps_uf': ctpsUf,
      if (observacao != null) 'observacao': observacao,
      if (logradouro != null) 'logradouro': logradouro,
      if (numero != null) 'numero': numero,
      if (complemento != null) 'complemento': complemento,
      if (bairro != null) 'bairro': bairro,
      if (cidade != null) 'cidade': cidade,
      if (cep != null) 'cep': cep,
      if (municipioIbge != null) 'municipio_ibge': municipioIbge,
      if (uf != null) 'uf': uf,
      if (idPessoa != null) 'id_pessoa': idPessoa,
      if (idCargo != null) 'id_cargo': idCargo,
      if (idSetor != null) 'id_setor': idSetor,
      if (comissao != null) 'comissao': comissao,
      if (metaVenda != null) 'meta_venda': metaVenda,
    });
  }

  ViewPessoaVendedorsCompanion copyWith({
    Value<int?>? id,
    Value<String?>? nome,
    Value<String?>? tipo,
    Value<String?>? email,
    Value<String?>? site,
    Value<String?>? cpfCnpj,
    Value<String?>? rgIe,
    Value<String?>? matricula,
    Value<DateTime?>? dataCadastro,
    Value<DateTime?>? dataAdmissao,
    Value<DateTime?>? dataDemissao,
    Value<String?>? ctpsNumero,
    Value<String?>? ctpsSerie,
    Value<DateTime?>? ctpsDataExpedicao,
    Value<String?>? ctpsUf,
    Value<String?>? observacao,
    Value<String?>? logradouro,
    Value<String?>? numero,
    Value<String?>? complemento,
    Value<String?>? bairro,
    Value<String?>? cidade,
    Value<String?>? cep,
    Value<String?>? municipioIbge,
    Value<String?>? uf,
    Value<int?>? idPessoa,
    Value<int?>? idCargo,
    Value<int?>? idSetor,
    Value<double?>? comissao,
    Value<double?>? metaVenda,
  }) {
    return ViewPessoaVendedorsCompanion(
      id: id ?? this.id,
      nome: nome ?? this.nome,
      tipo: tipo ?? this.tipo,
      email: email ?? this.email,
      site: site ?? this.site,
      cpfCnpj: cpfCnpj ?? this.cpfCnpj,
      rgIe: rgIe ?? this.rgIe,
      matricula: matricula ?? this.matricula,
      dataCadastro: dataCadastro ?? this.dataCadastro,
      dataAdmissao: dataAdmissao ?? this.dataAdmissao,
      dataDemissao: dataDemissao ?? this.dataDemissao,
      ctpsNumero: ctpsNumero ?? this.ctpsNumero,
      ctpsSerie: ctpsSerie ?? this.ctpsSerie,
      ctpsDataExpedicao: ctpsDataExpedicao ?? this.ctpsDataExpedicao,
      ctpsUf: ctpsUf ?? this.ctpsUf,
      observacao: observacao ?? this.observacao,
      logradouro: logradouro ?? this.logradouro,
      numero: numero ?? this.numero,
      complemento: complemento ?? this.complemento,
      bairro: bairro ?? this.bairro,
      cidade: cidade ?? this.cidade,
      cep: cep ?? this.cep,
      municipioIbge: municipioIbge ?? this.municipioIbge,
      uf: uf ?? this.uf,
      idPessoa: idPessoa ?? this.idPessoa,
      idCargo: idCargo ?? this.idCargo,
      idSetor: idSetor ?? this.idSetor,
      comissao: comissao ?? this.comissao,
      metaVenda: metaVenda ?? this.metaVenda,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (nome.present) {
      map['nome'] = Variable<String>(nome.value);
    }
    if (tipo.present) {
      map['tipo'] = Variable<String>(tipo.value);
    }
    if (email.present) {
      map['email'] = Variable<String>(email.value);
    }
    if (site.present) {
      map['site'] = Variable<String>(site.value);
    }
    if (cpfCnpj.present) {
      map['cpf_cnpj'] = Variable<String>(cpfCnpj.value);
    }
    if (rgIe.present) {
      map['rg_ie'] = Variable<String>(rgIe.value);
    }
    if (matricula.present) {
      map['matricula'] = Variable<String>(matricula.value);
    }
    if (dataCadastro.present) {
      map['data_cadastro'] = Variable<DateTime>(dataCadastro.value);
    }
    if (dataAdmissao.present) {
      map['data_admissao'] = Variable<DateTime>(dataAdmissao.value);
    }
    if (dataDemissao.present) {
      map['data_demissao'] = Variable<DateTime>(dataDemissao.value);
    }
    if (ctpsNumero.present) {
      map['ctps_numero'] = Variable<String>(ctpsNumero.value);
    }
    if (ctpsSerie.present) {
      map['ctps_serie'] = Variable<String>(ctpsSerie.value);
    }
    if (ctpsDataExpedicao.present) {
      map['ctps_data_expedicao'] = Variable<DateTime>(ctpsDataExpedicao.value);
    }
    if (ctpsUf.present) {
      map['ctps_uf'] = Variable<String>(ctpsUf.value);
    }
    if (observacao.present) {
      map['observacao'] = Variable<String>(observacao.value);
    }
    if (logradouro.present) {
      map['logradouro'] = Variable<String>(logradouro.value);
    }
    if (numero.present) {
      map['numero'] = Variable<String>(numero.value);
    }
    if (complemento.present) {
      map['complemento'] = Variable<String>(complemento.value);
    }
    if (bairro.present) {
      map['bairro'] = Variable<String>(bairro.value);
    }
    if (cidade.present) {
      map['cidade'] = Variable<String>(cidade.value);
    }
    if (cep.present) {
      map['cep'] = Variable<String>(cep.value);
    }
    if (municipioIbge.present) {
      map['municipio_ibge'] = Variable<String>(municipioIbge.value);
    }
    if (uf.present) {
      map['uf'] = Variable<String>(uf.value);
    }
    if (idPessoa.present) {
      map['id_pessoa'] = Variable<int>(idPessoa.value);
    }
    if (idCargo.present) {
      map['id_cargo'] = Variable<int>(idCargo.value);
    }
    if (idSetor.present) {
      map['id_setor'] = Variable<int>(idSetor.value);
    }
    if (comissao.present) {
      map['comissao'] = Variable<double>(comissao.value);
    }
    if (metaVenda.present) {
      map['meta_venda'] = Variable<double>(metaVenda.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('ViewPessoaVendedorsCompanion(')
          ..write('id: $id, ')
          ..write('nome: $nome, ')
          ..write('tipo: $tipo, ')
          ..write('email: $email, ')
          ..write('site: $site, ')
          ..write('cpfCnpj: $cpfCnpj, ')
          ..write('rgIe: $rgIe, ')
          ..write('matricula: $matricula, ')
          ..write('dataCadastro: $dataCadastro, ')
          ..write('dataAdmissao: $dataAdmissao, ')
          ..write('dataDemissao: $dataDemissao, ')
          ..write('ctpsNumero: $ctpsNumero, ')
          ..write('ctpsSerie: $ctpsSerie, ')
          ..write('ctpsDataExpedicao: $ctpsDataExpedicao, ')
          ..write('ctpsUf: $ctpsUf, ')
          ..write('observacao: $observacao, ')
          ..write('logradouro: $logradouro, ')
          ..write('numero: $numero, ')
          ..write('complemento: $complemento, ')
          ..write('bairro: $bairro, ')
          ..write('cidade: $cidade, ')
          ..write('cep: $cep, ')
          ..write('municipioIbge: $municipioIbge, ')
          ..write('uf: $uf, ')
          ..write('idPessoa: $idPessoa, ')
          ..write('idCargo: $idCargo, ')
          ..write('idSetor: $idSetor, ')
          ..write('comissao: $comissao, ')
          ..write('metaVenda: $metaVenda')
          ..write(')'))
        .toString();
  }
}

class $ViewPessoaTransportadorasTable extends ViewPessoaTransportadoras
    with TableInfo<$ViewPessoaTransportadorasTable, ViewPessoaTransportadora> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $ViewPessoaTransportadorasTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
    'id',
    aliasedName,
    true,
    type: DriftSqlType.int,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _nomeMeta = const VerificationMeta('nome');
  @override
  late final GeneratedColumn<String> nome = GeneratedColumn<String>(
    'nome',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 450,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _tipoMeta = const VerificationMeta('tipo');
  @override
  late final GeneratedColumn<String> tipo = GeneratedColumn<String>(
    'tipo',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 3,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _emailMeta = const VerificationMeta('email');
  @override
  late final GeneratedColumn<String> email = GeneratedColumn<String>(
    'email',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 750,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _siteMeta = const VerificationMeta('site');
  @override
  late final GeneratedColumn<String> site = GeneratedColumn<String>(
    'site',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 450,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _cpfCnpjMeta = const VerificationMeta(
    'cpfCnpj',
  );
  @override
  late final GeneratedColumn<String> cpfCnpj = GeneratedColumn<String>(
    'cpf_cnpj',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 20,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _rgIeMeta = const VerificationMeta('rgIe');
  @override
  late final GeneratedColumn<String> rgIe = GeneratedColumn<String>(
    'rg_ie',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 20,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _dataCadastroMeta = const VerificationMeta(
    'dataCadastro',
  );
  @override
  late final GeneratedColumn<DateTime> dataCadastro = GeneratedColumn<DateTime>(
    'data_cadastro',
    aliasedName,
    true,
    type: DriftSqlType.dateTime,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _observacaoMeta = const VerificationMeta(
    'observacao',
  );
  @override
  late final GeneratedColumn<String> observacao = GeneratedColumn<String>(
    'observacao',
    aliasedName,
    true,
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _idPessoaMeta = const VerificationMeta(
    'idPessoa',
  );
  @override
  late final GeneratedColumn<int> idPessoa = GeneratedColumn<int>(
    'id_pessoa',
    aliasedName,
    true,
    type: DriftSqlType.int,
    requiredDuringInsert: false,
  );
  @override
  List<GeneratedColumn> get $columns => [
    id,
    nome,
    tipo,
    email,
    site,
    cpfCnpj,
    rgIe,
    dataCadastro,
    observacao,
    idPessoa,
  ];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'view_pessoa_transportadora';
  @override
  VerificationContext validateIntegrity(
    Insertable<ViewPessoaTransportadora> instance, {
    bool isInserting = false,
  }) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('nome')) {
      context.handle(
        _nomeMeta,
        nome.isAcceptableOrUnknown(data['nome']!, _nomeMeta),
      );
    }
    if (data.containsKey('tipo')) {
      context.handle(
        _tipoMeta,
        tipo.isAcceptableOrUnknown(data['tipo']!, _tipoMeta),
      );
    }
    if (data.containsKey('email')) {
      context.handle(
        _emailMeta,
        email.isAcceptableOrUnknown(data['email']!, _emailMeta),
      );
    }
    if (data.containsKey('site')) {
      context.handle(
        _siteMeta,
        site.isAcceptableOrUnknown(data['site']!, _siteMeta),
      );
    }
    if (data.containsKey('cpf_cnpj')) {
      context.handle(
        _cpfCnpjMeta,
        cpfCnpj.isAcceptableOrUnknown(data['cpf_cnpj']!, _cpfCnpjMeta),
      );
    }
    if (data.containsKey('rg_ie')) {
      context.handle(
        _rgIeMeta,
        rgIe.isAcceptableOrUnknown(data['rg_ie']!, _rgIeMeta),
      );
    }
    if (data.containsKey('data_cadastro')) {
      context.handle(
        _dataCadastroMeta,
        dataCadastro.isAcceptableOrUnknown(
          data['data_cadastro']!,
          _dataCadastroMeta,
        ),
      );
    }
    if (data.containsKey('observacao')) {
      context.handle(
        _observacaoMeta,
        observacao.isAcceptableOrUnknown(data['observacao']!, _observacaoMeta),
      );
    }
    if (data.containsKey('id_pessoa')) {
      context.handle(
        _idPessoaMeta,
        idPessoa.isAcceptableOrUnknown(data['id_pessoa']!, _idPessoaMeta),
      );
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  ViewPessoaTransportadora map(
    Map<String, dynamic> data, {
    String? tablePrefix,
  }) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return ViewPessoaTransportadora(
      id: attachedDatabase.typeMapping.read(
        DriftSqlType.int,
        data['${effectivePrefix}id'],
      ),
      nome: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}nome'],
      ),
      tipo: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}tipo'],
      ),
      email: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}email'],
      ),
      site: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}site'],
      ),
      cpfCnpj: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}cpf_cnpj'],
      ),
      rgIe: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}rg_ie'],
      ),
      dataCadastro: attachedDatabase.typeMapping.read(
        DriftSqlType.dateTime,
        data['${effectivePrefix}data_cadastro'],
      ),
      observacao: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}observacao'],
      ),
      idPessoa: attachedDatabase.typeMapping.read(
        DriftSqlType.int,
        data['${effectivePrefix}id_pessoa'],
      ),
    );
  }

  @override
  $ViewPessoaTransportadorasTable createAlias(String alias) {
    return $ViewPessoaTransportadorasTable(attachedDatabase, alias);
  }
}

class ViewPessoaTransportadora extends DataClass
    implements Insertable<ViewPessoaTransportadora> {
  final int? id;
  final String? nome;
  final String? tipo;
  final String? email;
  final String? site;
  final String? cpfCnpj;
  final String? rgIe;
  final DateTime? dataCadastro;
  final String? observacao;
  final int? idPessoa;
  const ViewPessoaTransportadora({
    this.id,
    this.nome,
    this.tipo,
    this.email,
    this.site,
    this.cpfCnpj,
    this.rgIe,
    this.dataCadastro,
    this.observacao,
    this.idPessoa,
  });
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || nome != null) {
      map['nome'] = Variable<String>(nome);
    }
    if (!nullToAbsent || tipo != null) {
      map['tipo'] = Variable<String>(tipo);
    }
    if (!nullToAbsent || email != null) {
      map['email'] = Variable<String>(email);
    }
    if (!nullToAbsent || site != null) {
      map['site'] = Variable<String>(site);
    }
    if (!nullToAbsent || cpfCnpj != null) {
      map['cpf_cnpj'] = Variable<String>(cpfCnpj);
    }
    if (!nullToAbsent || rgIe != null) {
      map['rg_ie'] = Variable<String>(rgIe);
    }
    if (!nullToAbsent || dataCadastro != null) {
      map['data_cadastro'] = Variable<DateTime>(dataCadastro);
    }
    if (!nullToAbsent || observacao != null) {
      map['observacao'] = Variable<String>(observacao);
    }
    if (!nullToAbsent || idPessoa != null) {
      map['id_pessoa'] = Variable<int>(idPessoa);
    }
    return map;
  }

  factory ViewPessoaTransportadora.fromJson(
    Map<String, dynamic> json, {
    ValueSerializer? serializer,
  }) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return ViewPessoaTransportadora(
      id: serializer.fromJson<int?>(json['id']),
      nome: serializer.fromJson<String?>(json['nome']),
      tipo: serializer.fromJson<String?>(json['tipo']),
      email: serializer.fromJson<String?>(json['email']),
      site: serializer.fromJson<String?>(json['site']),
      cpfCnpj: serializer.fromJson<String?>(json['cpfCnpj']),
      rgIe: serializer.fromJson<String?>(json['rgIe']),
      dataCadastro: serializer.fromJson<DateTime?>(json['dataCadastro']),
      observacao: serializer.fromJson<String?>(json['observacao']),
      idPessoa: serializer.fromJson<int?>(json['idPessoa']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'nome': serializer.toJson<String?>(nome),
      'tipo': serializer.toJson<String?>(tipo),
      'email': serializer.toJson<String?>(email),
      'site': serializer.toJson<String?>(site),
      'cpfCnpj': serializer.toJson<String?>(cpfCnpj),
      'rgIe': serializer.toJson<String?>(rgIe),
      'dataCadastro': serializer.toJson<DateTime?>(dataCadastro),
      'observacao': serializer.toJson<String?>(observacao),
      'idPessoa': serializer.toJson<int?>(idPessoa),
    };
  }

  ViewPessoaTransportadora copyWith({
    Value<int?> id = const Value.absent(),
    Value<String?> nome = const Value.absent(),
    Value<String?> tipo = const Value.absent(),
    Value<String?> email = const Value.absent(),
    Value<String?> site = const Value.absent(),
    Value<String?> cpfCnpj = const Value.absent(),
    Value<String?> rgIe = const Value.absent(),
    Value<DateTime?> dataCadastro = const Value.absent(),
    Value<String?> observacao = const Value.absent(),
    Value<int?> idPessoa = const Value.absent(),
  }) => ViewPessoaTransportadora(
    id: id.present ? id.value : this.id,
    nome: nome.present ? nome.value : this.nome,
    tipo: tipo.present ? tipo.value : this.tipo,
    email: email.present ? email.value : this.email,
    site: site.present ? site.value : this.site,
    cpfCnpj: cpfCnpj.present ? cpfCnpj.value : this.cpfCnpj,
    rgIe: rgIe.present ? rgIe.value : this.rgIe,
    dataCadastro: dataCadastro.present ? dataCadastro.value : this.dataCadastro,
    observacao: observacao.present ? observacao.value : this.observacao,
    idPessoa: idPessoa.present ? idPessoa.value : this.idPessoa,
  );
  ViewPessoaTransportadora copyWithCompanion(
    ViewPessoaTransportadorasCompanion data,
  ) {
    return ViewPessoaTransportadora(
      id: data.id.present ? data.id.value : this.id,
      nome: data.nome.present ? data.nome.value : this.nome,
      tipo: data.tipo.present ? data.tipo.value : this.tipo,
      email: data.email.present ? data.email.value : this.email,
      site: data.site.present ? data.site.value : this.site,
      cpfCnpj: data.cpfCnpj.present ? data.cpfCnpj.value : this.cpfCnpj,
      rgIe: data.rgIe.present ? data.rgIe.value : this.rgIe,
      dataCadastro:
          data.dataCadastro.present
              ? data.dataCadastro.value
              : this.dataCadastro,
      observacao:
          data.observacao.present ? data.observacao.value : this.observacao,
      idPessoa: data.idPessoa.present ? data.idPessoa.value : this.idPessoa,
    );
  }

  @override
  String toString() {
    return (StringBuffer('ViewPessoaTransportadora(')
          ..write('id: $id, ')
          ..write('nome: $nome, ')
          ..write('tipo: $tipo, ')
          ..write('email: $email, ')
          ..write('site: $site, ')
          ..write('cpfCnpj: $cpfCnpj, ')
          ..write('rgIe: $rgIe, ')
          ..write('dataCadastro: $dataCadastro, ')
          ..write('observacao: $observacao, ')
          ..write('idPessoa: $idPessoa')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(
    id,
    nome,
    tipo,
    email,
    site,
    cpfCnpj,
    rgIe,
    dataCadastro,
    observacao,
    idPessoa,
  );
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is ViewPessoaTransportadora &&
          other.id == this.id &&
          other.nome == this.nome &&
          other.tipo == this.tipo &&
          other.email == this.email &&
          other.site == this.site &&
          other.cpfCnpj == this.cpfCnpj &&
          other.rgIe == this.rgIe &&
          other.dataCadastro == this.dataCadastro &&
          other.observacao == this.observacao &&
          other.idPessoa == this.idPessoa);
}

class ViewPessoaTransportadorasCompanion
    extends UpdateCompanion<ViewPessoaTransportadora> {
  final Value<int?> id;
  final Value<String?> nome;
  final Value<String?> tipo;
  final Value<String?> email;
  final Value<String?> site;
  final Value<String?> cpfCnpj;
  final Value<String?> rgIe;
  final Value<DateTime?> dataCadastro;
  final Value<String?> observacao;
  final Value<int?> idPessoa;
  const ViewPessoaTransportadorasCompanion({
    this.id = const Value.absent(),
    this.nome = const Value.absent(),
    this.tipo = const Value.absent(),
    this.email = const Value.absent(),
    this.site = const Value.absent(),
    this.cpfCnpj = const Value.absent(),
    this.rgIe = const Value.absent(),
    this.dataCadastro = const Value.absent(),
    this.observacao = const Value.absent(),
    this.idPessoa = const Value.absent(),
  });
  ViewPessoaTransportadorasCompanion.insert({
    this.id = const Value.absent(),
    this.nome = const Value.absent(),
    this.tipo = const Value.absent(),
    this.email = const Value.absent(),
    this.site = const Value.absent(),
    this.cpfCnpj = const Value.absent(),
    this.rgIe = const Value.absent(),
    this.dataCadastro = const Value.absent(),
    this.observacao = const Value.absent(),
    this.idPessoa = const Value.absent(),
  });
  static Insertable<ViewPessoaTransportadora> custom({
    Expression<int>? id,
    Expression<String>? nome,
    Expression<String>? tipo,
    Expression<String>? email,
    Expression<String>? site,
    Expression<String>? cpfCnpj,
    Expression<String>? rgIe,
    Expression<DateTime>? dataCadastro,
    Expression<String>? observacao,
    Expression<int>? idPessoa,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (nome != null) 'nome': nome,
      if (tipo != null) 'tipo': tipo,
      if (email != null) 'email': email,
      if (site != null) 'site': site,
      if (cpfCnpj != null) 'cpf_cnpj': cpfCnpj,
      if (rgIe != null) 'rg_ie': rgIe,
      if (dataCadastro != null) 'data_cadastro': dataCadastro,
      if (observacao != null) 'observacao': observacao,
      if (idPessoa != null) 'id_pessoa': idPessoa,
    });
  }

  ViewPessoaTransportadorasCompanion copyWith({
    Value<int?>? id,
    Value<String?>? nome,
    Value<String?>? tipo,
    Value<String?>? email,
    Value<String?>? site,
    Value<String?>? cpfCnpj,
    Value<String?>? rgIe,
    Value<DateTime?>? dataCadastro,
    Value<String?>? observacao,
    Value<int?>? idPessoa,
  }) {
    return ViewPessoaTransportadorasCompanion(
      id: id ?? this.id,
      nome: nome ?? this.nome,
      tipo: tipo ?? this.tipo,
      email: email ?? this.email,
      site: site ?? this.site,
      cpfCnpj: cpfCnpj ?? this.cpfCnpj,
      rgIe: rgIe ?? this.rgIe,
      dataCadastro: dataCadastro ?? this.dataCadastro,
      observacao: observacao ?? this.observacao,
      idPessoa: idPessoa ?? this.idPessoa,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (nome.present) {
      map['nome'] = Variable<String>(nome.value);
    }
    if (tipo.present) {
      map['tipo'] = Variable<String>(tipo.value);
    }
    if (email.present) {
      map['email'] = Variable<String>(email.value);
    }
    if (site.present) {
      map['site'] = Variable<String>(site.value);
    }
    if (cpfCnpj.present) {
      map['cpf_cnpj'] = Variable<String>(cpfCnpj.value);
    }
    if (rgIe.present) {
      map['rg_ie'] = Variable<String>(rgIe.value);
    }
    if (dataCadastro.present) {
      map['data_cadastro'] = Variable<DateTime>(dataCadastro.value);
    }
    if (observacao.present) {
      map['observacao'] = Variable<String>(observacao.value);
    }
    if (idPessoa.present) {
      map['id_pessoa'] = Variable<int>(idPessoa.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('ViewPessoaTransportadorasCompanion(')
          ..write('id: $id, ')
          ..write('nome: $nome, ')
          ..write('tipo: $tipo, ')
          ..write('email: $email, ')
          ..write('site: $site, ')
          ..write('cpfCnpj: $cpfCnpj, ')
          ..write('rgIe: $rgIe, ')
          ..write('dataCadastro: $dataCadastro, ')
          ..write('observacao: $observacao, ')
          ..write('idPessoa: $idPessoa')
          ..write(')'))
        .toString();
  }
}

abstract class _$AppDatabase extends GeneratedDatabase {
  _$AppDatabase(QueryExecutor e) : super(e);
  $AppDatabaseManager get managers => $AppDatabaseManager(this);
  late final $GedDocumentoDetalhesTable gedDocumentoDetalhes =
      $GedDocumentoDetalhesTable(this);
  late final $GedDocumentoCabecalhosTable gedDocumentoCabecalhos =
      $GedDocumentoCabecalhosTable(this);
  late final $GedTipoDocumentosTable gedTipoDocumentos =
      $GedTipoDocumentosTable(this);
  late final $GedVersaoDocumentosTable gedVersaoDocumentos =
      $GedVersaoDocumentosTable(this);
  late final $ViewControleAcessosTable viewControleAcessos =
      $ViewControleAcessosTable(this);
  late final $ViewPessoaUsuariosTable viewPessoaUsuarios =
      $ViewPessoaUsuariosTable(this);
  late final $ViewPessoaColaboradorsTable viewPessoaColaboradors =
      $ViewPessoaColaboradorsTable(this);
  late final $ViewPessoaVendedorsTable viewPessoaVendedors =
      $ViewPessoaVendedorsTable(this);
  late final $ViewPessoaTransportadorasTable viewPessoaTransportadoras =
      $ViewPessoaTransportadorasTable(this);
  late final GedDocumentoCabecalhoDao gedDocumentoCabecalhoDao =
      GedDocumentoCabecalhoDao(this as AppDatabase);
  late final GedTipoDocumentoDao gedTipoDocumentoDao = GedTipoDocumentoDao(
    this as AppDatabase,
  );
  late final GedVersaoDocumentoDao gedVersaoDocumentoDao =
      GedVersaoDocumentoDao(this as AppDatabase);
  late final ViewControleAcessoDao viewControleAcessoDao =
      ViewControleAcessoDao(this as AppDatabase);
  late final ViewPessoaUsuarioDao viewPessoaUsuarioDao = ViewPessoaUsuarioDao(
    this as AppDatabase,
  );
  late final ViewPessoaColaboradorDao viewPessoaColaboradorDao =
      ViewPessoaColaboradorDao(this as AppDatabase);
  late final ViewPessoaVendedorDao viewPessoaVendedorDao =
      ViewPessoaVendedorDao(this as AppDatabase);
  late final ViewPessoaTransportadoraDao viewPessoaTransportadoraDao =
      ViewPessoaTransportadoraDao(this as AppDatabase);
  @override
  Iterable<TableInfo<Table, Object?>> get allTables =>
      allSchemaEntities.whereType<TableInfo<Table, Object?>>();
  @override
  List<DatabaseSchemaEntity> get allSchemaEntities => [
    gedDocumentoDetalhes,
    gedDocumentoCabecalhos,
    gedTipoDocumentos,
    gedVersaoDocumentos,
    viewControleAcessos,
    viewPessoaUsuarios,
    viewPessoaColaboradors,
    viewPessoaVendedors,
    viewPessoaTransportadoras,
  ];
}

typedef $$GedDocumentoDetalhesTableCreateCompanionBuilder =
    GedDocumentoDetalhesCompanion Function({
      Value<int?> id,
      Value<int?> idGedDocumentoCabecalho,
      Value<int?> idGedTipoDocumento,
      Value<String?> nome,
      Value<String?> descricao,
      Value<String?> palavrasChave,
      Value<String?> podeExcluir,
      Value<String?> podeAlterar,
      Value<String?> assinado,
      Value<DateTime?> dataFimVigencia,
      Value<DateTime?> dataExclusao,
    });
typedef $$GedDocumentoDetalhesTableUpdateCompanionBuilder =
    GedDocumentoDetalhesCompanion Function({
      Value<int?> id,
      Value<int?> idGedDocumentoCabecalho,
      Value<int?> idGedTipoDocumento,
      Value<String?> nome,
      Value<String?> descricao,
      Value<String?> palavrasChave,
      Value<String?> podeExcluir,
      Value<String?> podeAlterar,
      Value<String?> assinado,
      Value<DateTime?> dataFimVigencia,
      Value<DateTime?> dataExclusao,
    });

class $$GedDocumentoDetalhesTableFilterComposer
    extends Composer<_$AppDatabase, $GedDocumentoDetalhesTable> {
  $$GedDocumentoDetalhesTableFilterComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnFilters<int> get id => $composableBuilder(
    column: $table.id,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<int> get idGedDocumentoCabecalho => $composableBuilder(
    column: $table.idGedDocumentoCabecalho,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<int> get idGedTipoDocumento => $composableBuilder(
    column: $table.idGedTipoDocumento,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get nome => $composableBuilder(
    column: $table.nome,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get descricao => $composableBuilder(
    column: $table.descricao,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get palavrasChave => $composableBuilder(
    column: $table.palavrasChave,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get podeExcluir => $composableBuilder(
    column: $table.podeExcluir,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get podeAlterar => $composableBuilder(
    column: $table.podeAlterar,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get assinado => $composableBuilder(
    column: $table.assinado,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<DateTime> get dataFimVigencia => $composableBuilder(
    column: $table.dataFimVigencia,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<DateTime> get dataExclusao => $composableBuilder(
    column: $table.dataExclusao,
    builder: (column) => ColumnFilters(column),
  );
}

class $$GedDocumentoDetalhesTableOrderingComposer
    extends Composer<_$AppDatabase, $GedDocumentoDetalhesTable> {
  $$GedDocumentoDetalhesTableOrderingComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnOrderings<int> get id => $composableBuilder(
    column: $table.id,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<int> get idGedDocumentoCabecalho => $composableBuilder(
    column: $table.idGedDocumentoCabecalho,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<int> get idGedTipoDocumento => $composableBuilder(
    column: $table.idGedTipoDocumento,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get nome => $composableBuilder(
    column: $table.nome,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get descricao => $composableBuilder(
    column: $table.descricao,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get palavrasChave => $composableBuilder(
    column: $table.palavrasChave,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get podeExcluir => $composableBuilder(
    column: $table.podeExcluir,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get podeAlterar => $composableBuilder(
    column: $table.podeAlterar,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get assinado => $composableBuilder(
    column: $table.assinado,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<DateTime> get dataFimVigencia => $composableBuilder(
    column: $table.dataFimVigencia,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<DateTime> get dataExclusao => $composableBuilder(
    column: $table.dataExclusao,
    builder: (column) => ColumnOrderings(column),
  );
}

class $$GedDocumentoDetalhesTableAnnotationComposer
    extends Composer<_$AppDatabase, $GedDocumentoDetalhesTable> {
  $$GedDocumentoDetalhesTableAnnotationComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  GeneratedColumn<int> get id =>
      $composableBuilder(column: $table.id, builder: (column) => column);

  GeneratedColumn<int> get idGedDocumentoCabecalho => $composableBuilder(
    column: $table.idGedDocumentoCabecalho,
    builder: (column) => column,
  );

  GeneratedColumn<int> get idGedTipoDocumento => $composableBuilder(
    column: $table.idGedTipoDocumento,
    builder: (column) => column,
  );

  GeneratedColumn<String> get nome =>
      $composableBuilder(column: $table.nome, builder: (column) => column);

  GeneratedColumn<String> get descricao =>
      $composableBuilder(column: $table.descricao, builder: (column) => column);

  GeneratedColumn<String> get palavrasChave => $composableBuilder(
    column: $table.palavrasChave,
    builder: (column) => column,
  );

  GeneratedColumn<String> get podeExcluir => $composableBuilder(
    column: $table.podeExcluir,
    builder: (column) => column,
  );

  GeneratedColumn<String> get podeAlterar => $composableBuilder(
    column: $table.podeAlterar,
    builder: (column) => column,
  );

  GeneratedColumn<String> get assinado =>
      $composableBuilder(column: $table.assinado, builder: (column) => column);

  GeneratedColumn<DateTime> get dataFimVigencia => $composableBuilder(
    column: $table.dataFimVigencia,
    builder: (column) => column,
  );

  GeneratedColumn<DateTime> get dataExclusao => $composableBuilder(
    column: $table.dataExclusao,
    builder: (column) => column,
  );
}

class $$GedDocumentoDetalhesTableTableManager
    extends
        RootTableManager<
          _$AppDatabase,
          $GedDocumentoDetalhesTable,
          GedDocumentoDetalhe,
          $$GedDocumentoDetalhesTableFilterComposer,
          $$GedDocumentoDetalhesTableOrderingComposer,
          $$GedDocumentoDetalhesTableAnnotationComposer,
          $$GedDocumentoDetalhesTableCreateCompanionBuilder,
          $$GedDocumentoDetalhesTableUpdateCompanionBuilder,
          (
            GedDocumentoDetalhe,
            BaseReferences<
              _$AppDatabase,
              $GedDocumentoDetalhesTable,
              GedDocumentoDetalhe
            >,
          ),
          GedDocumentoDetalhe,
          PrefetchHooks Function()
        > {
  $$GedDocumentoDetalhesTableTableManager(
    _$AppDatabase db,
    $GedDocumentoDetalhesTable table,
  ) : super(
        TableManagerState(
          db: db,
          table: table,
          createFilteringComposer:
              () => $$GedDocumentoDetalhesTableFilterComposer(
                $db: db,
                $table: table,
              ),
          createOrderingComposer:
              () => $$GedDocumentoDetalhesTableOrderingComposer(
                $db: db,
                $table: table,
              ),
          createComputedFieldComposer:
              () => $$GedDocumentoDetalhesTableAnnotationComposer(
                $db: db,
                $table: table,
              ),
          updateCompanionCallback:
              ({
                Value<int?> id = const Value.absent(),
                Value<int?> idGedDocumentoCabecalho = const Value.absent(),
                Value<int?> idGedTipoDocumento = const Value.absent(),
                Value<String?> nome = const Value.absent(),
                Value<String?> descricao = const Value.absent(),
                Value<String?> palavrasChave = const Value.absent(),
                Value<String?> podeExcluir = const Value.absent(),
                Value<String?> podeAlterar = const Value.absent(),
                Value<String?> assinado = const Value.absent(),
                Value<DateTime?> dataFimVigencia = const Value.absent(),
                Value<DateTime?> dataExclusao = const Value.absent(),
              }) => GedDocumentoDetalhesCompanion(
                id: id,
                idGedDocumentoCabecalho: idGedDocumentoCabecalho,
                idGedTipoDocumento: idGedTipoDocumento,
                nome: nome,
                descricao: descricao,
                palavrasChave: palavrasChave,
                podeExcluir: podeExcluir,
                podeAlterar: podeAlterar,
                assinado: assinado,
                dataFimVigencia: dataFimVigencia,
                dataExclusao: dataExclusao,
              ),
          createCompanionCallback:
              ({
                Value<int?> id = const Value.absent(),
                Value<int?> idGedDocumentoCabecalho = const Value.absent(),
                Value<int?> idGedTipoDocumento = const Value.absent(),
                Value<String?> nome = const Value.absent(),
                Value<String?> descricao = const Value.absent(),
                Value<String?> palavrasChave = const Value.absent(),
                Value<String?> podeExcluir = const Value.absent(),
                Value<String?> podeAlterar = const Value.absent(),
                Value<String?> assinado = const Value.absent(),
                Value<DateTime?> dataFimVigencia = const Value.absent(),
                Value<DateTime?> dataExclusao = const Value.absent(),
              }) => GedDocumentoDetalhesCompanion.insert(
                id: id,
                idGedDocumentoCabecalho: idGedDocumentoCabecalho,
                idGedTipoDocumento: idGedTipoDocumento,
                nome: nome,
                descricao: descricao,
                palavrasChave: palavrasChave,
                podeExcluir: podeExcluir,
                podeAlterar: podeAlterar,
                assinado: assinado,
                dataFimVigencia: dataFimVigencia,
                dataExclusao: dataExclusao,
              ),
          withReferenceMapper:
              (p0) =>
                  p0
                      .map(
                        (e) => (
                          e.readTable(table),
                          BaseReferences(db, table, e),
                        ),
                      )
                      .toList(),
          prefetchHooksCallback: null,
        ),
      );
}

typedef $$GedDocumentoDetalhesTableProcessedTableManager =
    ProcessedTableManager<
      _$AppDatabase,
      $GedDocumentoDetalhesTable,
      GedDocumentoDetalhe,
      $$GedDocumentoDetalhesTableFilterComposer,
      $$GedDocumentoDetalhesTableOrderingComposer,
      $$GedDocumentoDetalhesTableAnnotationComposer,
      $$GedDocumentoDetalhesTableCreateCompanionBuilder,
      $$GedDocumentoDetalhesTableUpdateCompanionBuilder,
      (
        GedDocumentoDetalhe,
        BaseReferences<
          _$AppDatabase,
          $GedDocumentoDetalhesTable,
          GedDocumentoDetalhe
        >,
      ),
      GedDocumentoDetalhe,
      PrefetchHooks Function()
    >;
typedef $$GedDocumentoCabecalhosTableCreateCompanionBuilder =
    GedDocumentoCabecalhosCompanion Function({
      Value<int?> id,
      Value<String?> nome,
      Value<DateTime?> dataInclusao,
      Value<String?> descricao,
    });
typedef $$GedDocumentoCabecalhosTableUpdateCompanionBuilder =
    GedDocumentoCabecalhosCompanion Function({
      Value<int?> id,
      Value<String?> nome,
      Value<DateTime?> dataInclusao,
      Value<String?> descricao,
    });

class $$GedDocumentoCabecalhosTableFilterComposer
    extends Composer<_$AppDatabase, $GedDocumentoCabecalhosTable> {
  $$GedDocumentoCabecalhosTableFilterComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnFilters<int> get id => $composableBuilder(
    column: $table.id,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get nome => $composableBuilder(
    column: $table.nome,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<DateTime> get dataInclusao => $composableBuilder(
    column: $table.dataInclusao,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get descricao => $composableBuilder(
    column: $table.descricao,
    builder: (column) => ColumnFilters(column),
  );
}

class $$GedDocumentoCabecalhosTableOrderingComposer
    extends Composer<_$AppDatabase, $GedDocumentoCabecalhosTable> {
  $$GedDocumentoCabecalhosTableOrderingComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnOrderings<int> get id => $composableBuilder(
    column: $table.id,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get nome => $composableBuilder(
    column: $table.nome,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<DateTime> get dataInclusao => $composableBuilder(
    column: $table.dataInclusao,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get descricao => $composableBuilder(
    column: $table.descricao,
    builder: (column) => ColumnOrderings(column),
  );
}

class $$GedDocumentoCabecalhosTableAnnotationComposer
    extends Composer<_$AppDatabase, $GedDocumentoCabecalhosTable> {
  $$GedDocumentoCabecalhosTableAnnotationComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  GeneratedColumn<int> get id =>
      $composableBuilder(column: $table.id, builder: (column) => column);

  GeneratedColumn<String> get nome =>
      $composableBuilder(column: $table.nome, builder: (column) => column);

  GeneratedColumn<DateTime> get dataInclusao => $composableBuilder(
    column: $table.dataInclusao,
    builder: (column) => column,
  );

  GeneratedColumn<String> get descricao =>
      $composableBuilder(column: $table.descricao, builder: (column) => column);
}

class $$GedDocumentoCabecalhosTableTableManager
    extends
        RootTableManager<
          _$AppDatabase,
          $GedDocumentoCabecalhosTable,
          GedDocumentoCabecalho,
          $$GedDocumentoCabecalhosTableFilterComposer,
          $$GedDocumentoCabecalhosTableOrderingComposer,
          $$GedDocumentoCabecalhosTableAnnotationComposer,
          $$GedDocumentoCabecalhosTableCreateCompanionBuilder,
          $$GedDocumentoCabecalhosTableUpdateCompanionBuilder,
          (
            GedDocumentoCabecalho,
            BaseReferences<
              _$AppDatabase,
              $GedDocumentoCabecalhosTable,
              GedDocumentoCabecalho
            >,
          ),
          GedDocumentoCabecalho,
          PrefetchHooks Function()
        > {
  $$GedDocumentoCabecalhosTableTableManager(
    _$AppDatabase db,
    $GedDocumentoCabecalhosTable table,
  ) : super(
        TableManagerState(
          db: db,
          table: table,
          createFilteringComposer:
              () => $$GedDocumentoCabecalhosTableFilterComposer(
                $db: db,
                $table: table,
              ),
          createOrderingComposer:
              () => $$GedDocumentoCabecalhosTableOrderingComposer(
                $db: db,
                $table: table,
              ),
          createComputedFieldComposer:
              () => $$GedDocumentoCabecalhosTableAnnotationComposer(
                $db: db,
                $table: table,
              ),
          updateCompanionCallback:
              ({
                Value<int?> id = const Value.absent(),
                Value<String?> nome = const Value.absent(),
                Value<DateTime?> dataInclusao = const Value.absent(),
                Value<String?> descricao = const Value.absent(),
              }) => GedDocumentoCabecalhosCompanion(
                id: id,
                nome: nome,
                dataInclusao: dataInclusao,
                descricao: descricao,
              ),
          createCompanionCallback:
              ({
                Value<int?> id = const Value.absent(),
                Value<String?> nome = const Value.absent(),
                Value<DateTime?> dataInclusao = const Value.absent(),
                Value<String?> descricao = const Value.absent(),
              }) => GedDocumentoCabecalhosCompanion.insert(
                id: id,
                nome: nome,
                dataInclusao: dataInclusao,
                descricao: descricao,
              ),
          withReferenceMapper:
              (p0) =>
                  p0
                      .map(
                        (e) => (
                          e.readTable(table),
                          BaseReferences(db, table, e),
                        ),
                      )
                      .toList(),
          prefetchHooksCallback: null,
        ),
      );
}

typedef $$GedDocumentoCabecalhosTableProcessedTableManager =
    ProcessedTableManager<
      _$AppDatabase,
      $GedDocumentoCabecalhosTable,
      GedDocumentoCabecalho,
      $$GedDocumentoCabecalhosTableFilterComposer,
      $$GedDocumentoCabecalhosTableOrderingComposer,
      $$GedDocumentoCabecalhosTableAnnotationComposer,
      $$GedDocumentoCabecalhosTableCreateCompanionBuilder,
      $$GedDocumentoCabecalhosTableUpdateCompanionBuilder,
      (
        GedDocumentoCabecalho,
        BaseReferences<
          _$AppDatabase,
          $GedDocumentoCabecalhosTable,
          GedDocumentoCabecalho
        >,
      ),
      GedDocumentoCabecalho,
      PrefetchHooks Function()
    >;
typedef $$GedTipoDocumentosTableCreateCompanionBuilder =
    GedTipoDocumentosCompanion Function({
      Value<int?> id,
      Value<String?> nome,
      Value<double?> tamanhoMaximo,
    });
typedef $$GedTipoDocumentosTableUpdateCompanionBuilder =
    GedTipoDocumentosCompanion Function({
      Value<int?> id,
      Value<String?> nome,
      Value<double?> tamanhoMaximo,
    });

class $$GedTipoDocumentosTableFilterComposer
    extends Composer<_$AppDatabase, $GedTipoDocumentosTable> {
  $$GedTipoDocumentosTableFilterComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnFilters<int> get id => $composableBuilder(
    column: $table.id,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get nome => $composableBuilder(
    column: $table.nome,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<double> get tamanhoMaximo => $composableBuilder(
    column: $table.tamanhoMaximo,
    builder: (column) => ColumnFilters(column),
  );
}

class $$GedTipoDocumentosTableOrderingComposer
    extends Composer<_$AppDatabase, $GedTipoDocumentosTable> {
  $$GedTipoDocumentosTableOrderingComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnOrderings<int> get id => $composableBuilder(
    column: $table.id,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get nome => $composableBuilder(
    column: $table.nome,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<double> get tamanhoMaximo => $composableBuilder(
    column: $table.tamanhoMaximo,
    builder: (column) => ColumnOrderings(column),
  );
}

class $$GedTipoDocumentosTableAnnotationComposer
    extends Composer<_$AppDatabase, $GedTipoDocumentosTable> {
  $$GedTipoDocumentosTableAnnotationComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  GeneratedColumn<int> get id =>
      $composableBuilder(column: $table.id, builder: (column) => column);

  GeneratedColumn<String> get nome =>
      $composableBuilder(column: $table.nome, builder: (column) => column);

  GeneratedColumn<double> get tamanhoMaximo => $composableBuilder(
    column: $table.tamanhoMaximo,
    builder: (column) => column,
  );
}

class $$GedTipoDocumentosTableTableManager
    extends
        RootTableManager<
          _$AppDatabase,
          $GedTipoDocumentosTable,
          GedTipoDocumento,
          $$GedTipoDocumentosTableFilterComposer,
          $$GedTipoDocumentosTableOrderingComposer,
          $$GedTipoDocumentosTableAnnotationComposer,
          $$GedTipoDocumentosTableCreateCompanionBuilder,
          $$GedTipoDocumentosTableUpdateCompanionBuilder,
          (
            GedTipoDocumento,
            BaseReferences<
              _$AppDatabase,
              $GedTipoDocumentosTable,
              GedTipoDocumento
            >,
          ),
          GedTipoDocumento,
          PrefetchHooks Function()
        > {
  $$GedTipoDocumentosTableTableManager(
    _$AppDatabase db,
    $GedTipoDocumentosTable table,
  ) : super(
        TableManagerState(
          db: db,
          table: table,
          createFilteringComposer:
              () => $$GedTipoDocumentosTableFilterComposer(
                $db: db,
                $table: table,
              ),
          createOrderingComposer:
              () => $$GedTipoDocumentosTableOrderingComposer(
                $db: db,
                $table: table,
              ),
          createComputedFieldComposer:
              () => $$GedTipoDocumentosTableAnnotationComposer(
                $db: db,
                $table: table,
              ),
          updateCompanionCallback:
              ({
                Value<int?> id = const Value.absent(),
                Value<String?> nome = const Value.absent(),
                Value<double?> tamanhoMaximo = const Value.absent(),
              }) => GedTipoDocumentosCompanion(
                id: id,
                nome: nome,
                tamanhoMaximo: tamanhoMaximo,
              ),
          createCompanionCallback:
              ({
                Value<int?> id = const Value.absent(),
                Value<String?> nome = const Value.absent(),
                Value<double?> tamanhoMaximo = const Value.absent(),
              }) => GedTipoDocumentosCompanion.insert(
                id: id,
                nome: nome,
                tamanhoMaximo: tamanhoMaximo,
              ),
          withReferenceMapper:
              (p0) =>
                  p0
                      .map(
                        (e) => (
                          e.readTable(table),
                          BaseReferences(db, table, e),
                        ),
                      )
                      .toList(),
          prefetchHooksCallback: null,
        ),
      );
}

typedef $$GedTipoDocumentosTableProcessedTableManager =
    ProcessedTableManager<
      _$AppDatabase,
      $GedTipoDocumentosTable,
      GedTipoDocumento,
      $$GedTipoDocumentosTableFilterComposer,
      $$GedTipoDocumentosTableOrderingComposer,
      $$GedTipoDocumentosTableAnnotationComposer,
      $$GedTipoDocumentosTableCreateCompanionBuilder,
      $$GedTipoDocumentosTableUpdateCompanionBuilder,
      (
        GedTipoDocumento,
        BaseReferences<
          _$AppDatabase,
          $GedTipoDocumentosTable,
          GedTipoDocumento
        >,
      ),
      GedTipoDocumento,
      PrefetchHooks Function()
    >;
typedef $$GedVersaoDocumentosTableCreateCompanionBuilder =
    GedVersaoDocumentosCompanion Function({
      Value<int?> id,
      Value<int?> idGedDocumentoDetalhe,
      Value<int?> idColaborador,
      Value<String?> acao,
      Value<int?> versao,
      Value<DateTime?> dataVersao,
      Value<String?> horaVersao,
      Value<String?> hashArquivo,
      Value<String?> caminho,
    });
typedef $$GedVersaoDocumentosTableUpdateCompanionBuilder =
    GedVersaoDocumentosCompanion Function({
      Value<int?> id,
      Value<int?> idGedDocumentoDetalhe,
      Value<int?> idColaborador,
      Value<String?> acao,
      Value<int?> versao,
      Value<DateTime?> dataVersao,
      Value<String?> horaVersao,
      Value<String?> hashArquivo,
      Value<String?> caminho,
    });

class $$GedVersaoDocumentosTableFilterComposer
    extends Composer<_$AppDatabase, $GedVersaoDocumentosTable> {
  $$GedVersaoDocumentosTableFilterComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnFilters<int> get id => $composableBuilder(
    column: $table.id,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<int> get idGedDocumentoDetalhe => $composableBuilder(
    column: $table.idGedDocumentoDetalhe,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<int> get idColaborador => $composableBuilder(
    column: $table.idColaborador,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get acao => $composableBuilder(
    column: $table.acao,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<int> get versao => $composableBuilder(
    column: $table.versao,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<DateTime> get dataVersao => $composableBuilder(
    column: $table.dataVersao,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get horaVersao => $composableBuilder(
    column: $table.horaVersao,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get hashArquivo => $composableBuilder(
    column: $table.hashArquivo,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get caminho => $composableBuilder(
    column: $table.caminho,
    builder: (column) => ColumnFilters(column),
  );
}

class $$GedVersaoDocumentosTableOrderingComposer
    extends Composer<_$AppDatabase, $GedVersaoDocumentosTable> {
  $$GedVersaoDocumentosTableOrderingComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnOrderings<int> get id => $composableBuilder(
    column: $table.id,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<int> get idGedDocumentoDetalhe => $composableBuilder(
    column: $table.idGedDocumentoDetalhe,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<int> get idColaborador => $composableBuilder(
    column: $table.idColaborador,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get acao => $composableBuilder(
    column: $table.acao,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<int> get versao => $composableBuilder(
    column: $table.versao,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<DateTime> get dataVersao => $composableBuilder(
    column: $table.dataVersao,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get horaVersao => $composableBuilder(
    column: $table.horaVersao,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get hashArquivo => $composableBuilder(
    column: $table.hashArquivo,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get caminho => $composableBuilder(
    column: $table.caminho,
    builder: (column) => ColumnOrderings(column),
  );
}

class $$GedVersaoDocumentosTableAnnotationComposer
    extends Composer<_$AppDatabase, $GedVersaoDocumentosTable> {
  $$GedVersaoDocumentosTableAnnotationComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  GeneratedColumn<int> get id =>
      $composableBuilder(column: $table.id, builder: (column) => column);

  GeneratedColumn<int> get idGedDocumentoDetalhe => $composableBuilder(
    column: $table.idGedDocumentoDetalhe,
    builder: (column) => column,
  );

  GeneratedColumn<int> get idColaborador => $composableBuilder(
    column: $table.idColaborador,
    builder: (column) => column,
  );

  GeneratedColumn<String> get acao =>
      $composableBuilder(column: $table.acao, builder: (column) => column);

  GeneratedColumn<int> get versao =>
      $composableBuilder(column: $table.versao, builder: (column) => column);

  GeneratedColumn<DateTime> get dataVersao => $composableBuilder(
    column: $table.dataVersao,
    builder: (column) => column,
  );

  GeneratedColumn<String> get horaVersao => $composableBuilder(
    column: $table.horaVersao,
    builder: (column) => column,
  );

  GeneratedColumn<String> get hashArquivo => $composableBuilder(
    column: $table.hashArquivo,
    builder: (column) => column,
  );

  GeneratedColumn<String> get caminho =>
      $composableBuilder(column: $table.caminho, builder: (column) => column);
}

class $$GedVersaoDocumentosTableTableManager
    extends
        RootTableManager<
          _$AppDatabase,
          $GedVersaoDocumentosTable,
          GedVersaoDocumento,
          $$GedVersaoDocumentosTableFilterComposer,
          $$GedVersaoDocumentosTableOrderingComposer,
          $$GedVersaoDocumentosTableAnnotationComposer,
          $$GedVersaoDocumentosTableCreateCompanionBuilder,
          $$GedVersaoDocumentosTableUpdateCompanionBuilder,
          (
            GedVersaoDocumento,
            BaseReferences<
              _$AppDatabase,
              $GedVersaoDocumentosTable,
              GedVersaoDocumento
            >,
          ),
          GedVersaoDocumento,
          PrefetchHooks Function()
        > {
  $$GedVersaoDocumentosTableTableManager(
    _$AppDatabase db,
    $GedVersaoDocumentosTable table,
  ) : super(
        TableManagerState(
          db: db,
          table: table,
          createFilteringComposer:
              () => $$GedVersaoDocumentosTableFilterComposer(
                $db: db,
                $table: table,
              ),
          createOrderingComposer:
              () => $$GedVersaoDocumentosTableOrderingComposer(
                $db: db,
                $table: table,
              ),
          createComputedFieldComposer:
              () => $$GedVersaoDocumentosTableAnnotationComposer(
                $db: db,
                $table: table,
              ),
          updateCompanionCallback:
              ({
                Value<int?> id = const Value.absent(),
                Value<int?> idGedDocumentoDetalhe = const Value.absent(),
                Value<int?> idColaborador = const Value.absent(),
                Value<String?> acao = const Value.absent(),
                Value<int?> versao = const Value.absent(),
                Value<DateTime?> dataVersao = const Value.absent(),
                Value<String?> horaVersao = const Value.absent(),
                Value<String?> hashArquivo = const Value.absent(),
                Value<String?> caminho = const Value.absent(),
              }) => GedVersaoDocumentosCompanion(
                id: id,
                idGedDocumentoDetalhe: idGedDocumentoDetalhe,
                idColaborador: idColaborador,
                acao: acao,
                versao: versao,
                dataVersao: dataVersao,
                horaVersao: horaVersao,
                hashArquivo: hashArquivo,
                caminho: caminho,
              ),
          createCompanionCallback:
              ({
                Value<int?> id = const Value.absent(),
                Value<int?> idGedDocumentoDetalhe = const Value.absent(),
                Value<int?> idColaborador = const Value.absent(),
                Value<String?> acao = const Value.absent(),
                Value<int?> versao = const Value.absent(),
                Value<DateTime?> dataVersao = const Value.absent(),
                Value<String?> horaVersao = const Value.absent(),
                Value<String?> hashArquivo = const Value.absent(),
                Value<String?> caminho = const Value.absent(),
              }) => GedVersaoDocumentosCompanion.insert(
                id: id,
                idGedDocumentoDetalhe: idGedDocumentoDetalhe,
                idColaborador: idColaborador,
                acao: acao,
                versao: versao,
                dataVersao: dataVersao,
                horaVersao: horaVersao,
                hashArquivo: hashArquivo,
                caminho: caminho,
              ),
          withReferenceMapper:
              (p0) =>
                  p0
                      .map(
                        (e) => (
                          e.readTable(table),
                          BaseReferences(db, table, e),
                        ),
                      )
                      .toList(),
          prefetchHooksCallback: null,
        ),
      );
}

typedef $$GedVersaoDocumentosTableProcessedTableManager =
    ProcessedTableManager<
      _$AppDatabase,
      $GedVersaoDocumentosTable,
      GedVersaoDocumento,
      $$GedVersaoDocumentosTableFilterComposer,
      $$GedVersaoDocumentosTableOrderingComposer,
      $$GedVersaoDocumentosTableAnnotationComposer,
      $$GedVersaoDocumentosTableCreateCompanionBuilder,
      $$GedVersaoDocumentosTableUpdateCompanionBuilder,
      (
        GedVersaoDocumento,
        BaseReferences<
          _$AppDatabase,
          $GedVersaoDocumentosTable,
          GedVersaoDocumento
        >,
      ),
      GedVersaoDocumento,
      PrefetchHooks Function()
    >;
typedef $$ViewControleAcessosTableCreateCompanionBuilder =
    ViewControleAcessosCompanion Function({
      Value<int?> id,
      Value<int?> idPessoa,
      Value<String?> pessoaNome,
      Value<int?> idColaborador,
      Value<int?> idUsuario,
      Value<String?> administrador,
      Value<int?> idPapel,
      Value<String?> papelNome,
      Value<String?> papelDescricao,
      Value<int?> idFuncao,
      Value<String?> funcaoNome,
      Value<String?> funcaoDescricao,
      Value<int?> idPapelFuncao,
      Value<String?> habilitado,
      Value<String?> podeInserir,
      Value<String?> podeAlterar,
      Value<String?> podeExcluir,
    });
typedef $$ViewControleAcessosTableUpdateCompanionBuilder =
    ViewControleAcessosCompanion Function({
      Value<int?> id,
      Value<int?> idPessoa,
      Value<String?> pessoaNome,
      Value<int?> idColaborador,
      Value<int?> idUsuario,
      Value<String?> administrador,
      Value<int?> idPapel,
      Value<String?> papelNome,
      Value<String?> papelDescricao,
      Value<int?> idFuncao,
      Value<String?> funcaoNome,
      Value<String?> funcaoDescricao,
      Value<int?> idPapelFuncao,
      Value<String?> habilitado,
      Value<String?> podeInserir,
      Value<String?> podeAlterar,
      Value<String?> podeExcluir,
    });

class $$ViewControleAcessosTableFilterComposer
    extends Composer<_$AppDatabase, $ViewControleAcessosTable> {
  $$ViewControleAcessosTableFilterComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnFilters<int> get id => $composableBuilder(
    column: $table.id,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<int> get idPessoa => $composableBuilder(
    column: $table.idPessoa,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get pessoaNome => $composableBuilder(
    column: $table.pessoaNome,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<int> get idColaborador => $composableBuilder(
    column: $table.idColaborador,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<int> get idUsuario => $composableBuilder(
    column: $table.idUsuario,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get administrador => $composableBuilder(
    column: $table.administrador,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<int> get idPapel => $composableBuilder(
    column: $table.idPapel,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get papelNome => $composableBuilder(
    column: $table.papelNome,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get papelDescricao => $composableBuilder(
    column: $table.papelDescricao,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<int> get idFuncao => $composableBuilder(
    column: $table.idFuncao,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get funcaoNome => $composableBuilder(
    column: $table.funcaoNome,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get funcaoDescricao => $composableBuilder(
    column: $table.funcaoDescricao,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<int> get idPapelFuncao => $composableBuilder(
    column: $table.idPapelFuncao,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get habilitado => $composableBuilder(
    column: $table.habilitado,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get podeInserir => $composableBuilder(
    column: $table.podeInserir,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get podeAlterar => $composableBuilder(
    column: $table.podeAlterar,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get podeExcluir => $composableBuilder(
    column: $table.podeExcluir,
    builder: (column) => ColumnFilters(column),
  );
}

class $$ViewControleAcessosTableOrderingComposer
    extends Composer<_$AppDatabase, $ViewControleAcessosTable> {
  $$ViewControleAcessosTableOrderingComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnOrderings<int> get id => $composableBuilder(
    column: $table.id,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<int> get idPessoa => $composableBuilder(
    column: $table.idPessoa,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get pessoaNome => $composableBuilder(
    column: $table.pessoaNome,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<int> get idColaborador => $composableBuilder(
    column: $table.idColaborador,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<int> get idUsuario => $composableBuilder(
    column: $table.idUsuario,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get administrador => $composableBuilder(
    column: $table.administrador,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<int> get idPapel => $composableBuilder(
    column: $table.idPapel,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get papelNome => $composableBuilder(
    column: $table.papelNome,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get papelDescricao => $composableBuilder(
    column: $table.papelDescricao,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<int> get idFuncao => $composableBuilder(
    column: $table.idFuncao,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get funcaoNome => $composableBuilder(
    column: $table.funcaoNome,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get funcaoDescricao => $composableBuilder(
    column: $table.funcaoDescricao,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<int> get idPapelFuncao => $composableBuilder(
    column: $table.idPapelFuncao,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get habilitado => $composableBuilder(
    column: $table.habilitado,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get podeInserir => $composableBuilder(
    column: $table.podeInserir,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get podeAlterar => $composableBuilder(
    column: $table.podeAlterar,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get podeExcluir => $composableBuilder(
    column: $table.podeExcluir,
    builder: (column) => ColumnOrderings(column),
  );
}

class $$ViewControleAcessosTableAnnotationComposer
    extends Composer<_$AppDatabase, $ViewControleAcessosTable> {
  $$ViewControleAcessosTableAnnotationComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  GeneratedColumn<int> get id =>
      $composableBuilder(column: $table.id, builder: (column) => column);

  GeneratedColumn<int> get idPessoa =>
      $composableBuilder(column: $table.idPessoa, builder: (column) => column);

  GeneratedColumn<String> get pessoaNome => $composableBuilder(
    column: $table.pessoaNome,
    builder: (column) => column,
  );

  GeneratedColumn<int> get idColaborador => $composableBuilder(
    column: $table.idColaborador,
    builder: (column) => column,
  );

  GeneratedColumn<int> get idUsuario =>
      $composableBuilder(column: $table.idUsuario, builder: (column) => column);

  GeneratedColumn<String> get administrador => $composableBuilder(
    column: $table.administrador,
    builder: (column) => column,
  );

  GeneratedColumn<int> get idPapel =>
      $composableBuilder(column: $table.idPapel, builder: (column) => column);

  GeneratedColumn<String> get papelNome =>
      $composableBuilder(column: $table.papelNome, builder: (column) => column);

  GeneratedColumn<String> get papelDescricao => $composableBuilder(
    column: $table.papelDescricao,
    builder: (column) => column,
  );

  GeneratedColumn<int> get idFuncao =>
      $composableBuilder(column: $table.idFuncao, builder: (column) => column);

  GeneratedColumn<String> get funcaoNome => $composableBuilder(
    column: $table.funcaoNome,
    builder: (column) => column,
  );

  GeneratedColumn<String> get funcaoDescricao => $composableBuilder(
    column: $table.funcaoDescricao,
    builder: (column) => column,
  );

  GeneratedColumn<int> get idPapelFuncao => $composableBuilder(
    column: $table.idPapelFuncao,
    builder: (column) => column,
  );

  GeneratedColumn<String> get habilitado => $composableBuilder(
    column: $table.habilitado,
    builder: (column) => column,
  );

  GeneratedColumn<String> get podeInserir => $composableBuilder(
    column: $table.podeInserir,
    builder: (column) => column,
  );

  GeneratedColumn<String> get podeAlterar => $composableBuilder(
    column: $table.podeAlterar,
    builder: (column) => column,
  );

  GeneratedColumn<String> get podeExcluir => $composableBuilder(
    column: $table.podeExcluir,
    builder: (column) => column,
  );
}

class $$ViewControleAcessosTableTableManager
    extends
        RootTableManager<
          _$AppDatabase,
          $ViewControleAcessosTable,
          ViewControleAcesso,
          $$ViewControleAcessosTableFilterComposer,
          $$ViewControleAcessosTableOrderingComposer,
          $$ViewControleAcessosTableAnnotationComposer,
          $$ViewControleAcessosTableCreateCompanionBuilder,
          $$ViewControleAcessosTableUpdateCompanionBuilder,
          (
            ViewControleAcesso,
            BaseReferences<
              _$AppDatabase,
              $ViewControleAcessosTable,
              ViewControleAcesso
            >,
          ),
          ViewControleAcesso,
          PrefetchHooks Function()
        > {
  $$ViewControleAcessosTableTableManager(
    _$AppDatabase db,
    $ViewControleAcessosTable table,
  ) : super(
        TableManagerState(
          db: db,
          table: table,
          createFilteringComposer:
              () => $$ViewControleAcessosTableFilterComposer(
                $db: db,
                $table: table,
              ),
          createOrderingComposer:
              () => $$ViewControleAcessosTableOrderingComposer(
                $db: db,
                $table: table,
              ),
          createComputedFieldComposer:
              () => $$ViewControleAcessosTableAnnotationComposer(
                $db: db,
                $table: table,
              ),
          updateCompanionCallback:
              ({
                Value<int?> id = const Value.absent(),
                Value<int?> idPessoa = const Value.absent(),
                Value<String?> pessoaNome = const Value.absent(),
                Value<int?> idColaborador = const Value.absent(),
                Value<int?> idUsuario = const Value.absent(),
                Value<String?> administrador = const Value.absent(),
                Value<int?> idPapel = const Value.absent(),
                Value<String?> papelNome = const Value.absent(),
                Value<String?> papelDescricao = const Value.absent(),
                Value<int?> idFuncao = const Value.absent(),
                Value<String?> funcaoNome = const Value.absent(),
                Value<String?> funcaoDescricao = const Value.absent(),
                Value<int?> idPapelFuncao = const Value.absent(),
                Value<String?> habilitado = const Value.absent(),
                Value<String?> podeInserir = const Value.absent(),
                Value<String?> podeAlterar = const Value.absent(),
                Value<String?> podeExcluir = const Value.absent(),
              }) => ViewControleAcessosCompanion(
                id: id,
                idPessoa: idPessoa,
                pessoaNome: pessoaNome,
                idColaborador: idColaborador,
                idUsuario: idUsuario,
                administrador: administrador,
                idPapel: idPapel,
                papelNome: papelNome,
                papelDescricao: papelDescricao,
                idFuncao: idFuncao,
                funcaoNome: funcaoNome,
                funcaoDescricao: funcaoDescricao,
                idPapelFuncao: idPapelFuncao,
                habilitado: habilitado,
                podeInserir: podeInserir,
                podeAlterar: podeAlterar,
                podeExcluir: podeExcluir,
              ),
          createCompanionCallback:
              ({
                Value<int?> id = const Value.absent(),
                Value<int?> idPessoa = const Value.absent(),
                Value<String?> pessoaNome = const Value.absent(),
                Value<int?> idColaborador = const Value.absent(),
                Value<int?> idUsuario = const Value.absent(),
                Value<String?> administrador = const Value.absent(),
                Value<int?> idPapel = const Value.absent(),
                Value<String?> papelNome = const Value.absent(),
                Value<String?> papelDescricao = const Value.absent(),
                Value<int?> idFuncao = const Value.absent(),
                Value<String?> funcaoNome = const Value.absent(),
                Value<String?> funcaoDescricao = const Value.absent(),
                Value<int?> idPapelFuncao = const Value.absent(),
                Value<String?> habilitado = const Value.absent(),
                Value<String?> podeInserir = const Value.absent(),
                Value<String?> podeAlterar = const Value.absent(),
                Value<String?> podeExcluir = const Value.absent(),
              }) => ViewControleAcessosCompanion.insert(
                id: id,
                idPessoa: idPessoa,
                pessoaNome: pessoaNome,
                idColaborador: idColaborador,
                idUsuario: idUsuario,
                administrador: administrador,
                idPapel: idPapel,
                papelNome: papelNome,
                papelDescricao: papelDescricao,
                idFuncao: idFuncao,
                funcaoNome: funcaoNome,
                funcaoDescricao: funcaoDescricao,
                idPapelFuncao: idPapelFuncao,
                habilitado: habilitado,
                podeInserir: podeInserir,
                podeAlterar: podeAlterar,
                podeExcluir: podeExcluir,
              ),
          withReferenceMapper:
              (p0) =>
                  p0
                      .map(
                        (e) => (
                          e.readTable(table),
                          BaseReferences(db, table, e),
                        ),
                      )
                      .toList(),
          prefetchHooksCallback: null,
        ),
      );
}

typedef $$ViewControleAcessosTableProcessedTableManager =
    ProcessedTableManager<
      _$AppDatabase,
      $ViewControleAcessosTable,
      ViewControleAcesso,
      $$ViewControleAcessosTableFilterComposer,
      $$ViewControleAcessosTableOrderingComposer,
      $$ViewControleAcessosTableAnnotationComposer,
      $$ViewControleAcessosTableCreateCompanionBuilder,
      $$ViewControleAcessosTableUpdateCompanionBuilder,
      (
        ViewControleAcesso,
        BaseReferences<
          _$AppDatabase,
          $ViewControleAcessosTable,
          ViewControleAcesso
        >,
      ),
      ViewControleAcesso,
      PrefetchHooks Function()
    >;
typedef $$ViewPessoaUsuariosTableCreateCompanionBuilder =
    ViewPessoaUsuariosCompanion Function({
      Value<int?> id,
      Value<int?> idPessoa,
      Value<String?> pessoaNome,
      Value<String?> tipo,
      Value<String?> email,
      Value<int?> idColaborador,
      Value<int?> idUsuario,
      Value<String?> login,
      Value<String?> senha,
      Value<DateTime?> dataCadastro,
      Value<String?> administrador,
    });
typedef $$ViewPessoaUsuariosTableUpdateCompanionBuilder =
    ViewPessoaUsuariosCompanion Function({
      Value<int?> id,
      Value<int?> idPessoa,
      Value<String?> pessoaNome,
      Value<String?> tipo,
      Value<String?> email,
      Value<int?> idColaborador,
      Value<int?> idUsuario,
      Value<String?> login,
      Value<String?> senha,
      Value<DateTime?> dataCadastro,
      Value<String?> administrador,
    });

class $$ViewPessoaUsuariosTableFilterComposer
    extends Composer<_$AppDatabase, $ViewPessoaUsuariosTable> {
  $$ViewPessoaUsuariosTableFilterComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnFilters<int> get id => $composableBuilder(
    column: $table.id,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<int> get idPessoa => $composableBuilder(
    column: $table.idPessoa,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get pessoaNome => $composableBuilder(
    column: $table.pessoaNome,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get tipo => $composableBuilder(
    column: $table.tipo,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get email => $composableBuilder(
    column: $table.email,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<int> get idColaborador => $composableBuilder(
    column: $table.idColaborador,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<int> get idUsuario => $composableBuilder(
    column: $table.idUsuario,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get login => $composableBuilder(
    column: $table.login,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get senha => $composableBuilder(
    column: $table.senha,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<DateTime> get dataCadastro => $composableBuilder(
    column: $table.dataCadastro,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get administrador => $composableBuilder(
    column: $table.administrador,
    builder: (column) => ColumnFilters(column),
  );
}

class $$ViewPessoaUsuariosTableOrderingComposer
    extends Composer<_$AppDatabase, $ViewPessoaUsuariosTable> {
  $$ViewPessoaUsuariosTableOrderingComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnOrderings<int> get id => $composableBuilder(
    column: $table.id,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<int> get idPessoa => $composableBuilder(
    column: $table.idPessoa,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get pessoaNome => $composableBuilder(
    column: $table.pessoaNome,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get tipo => $composableBuilder(
    column: $table.tipo,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get email => $composableBuilder(
    column: $table.email,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<int> get idColaborador => $composableBuilder(
    column: $table.idColaborador,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<int> get idUsuario => $composableBuilder(
    column: $table.idUsuario,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get login => $composableBuilder(
    column: $table.login,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get senha => $composableBuilder(
    column: $table.senha,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<DateTime> get dataCadastro => $composableBuilder(
    column: $table.dataCadastro,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get administrador => $composableBuilder(
    column: $table.administrador,
    builder: (column) => ColumnOrderings(column),
  );
}

class $$ViewPessoaUsuariosTableAnnotationComposer
    extends Composer<_$AppDatabase, $ViewPessoaUsuariosTable> {
  $$ViewPessoaUsuariosTableAnnotationComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  GeneratedColumn<int> get id =>
      $composableBuilder(column: $table.id, builder: (column) => column);

  GeneratedColumn<int> get idPessoa =>
      $composableBuilder(column: $table.idPessoa, builder: (column) => column);

  GeneratedColumn<String> get pessoaNome => $composableBuilder(
    column: $table.pessoaNome,
    builder: (column) => column,
  );

  GeneratedColumn<String> get tipo =>
      $composableBuilder(column: $table.tipo, builder: (column) => column);

  GeneratedColumn<String> get email =>
      $composableBuilder(column: $table.email, builder: (column) => column);

  GeneratedColumn<int> get idColaborador => $composableBuilder(
    column: $table.idColaborador,
    builder: (column) => column,
  );

  GeneratedColumn<int> get idUsuario =>
      $composableBuilder(column: $table.idUsuario, builder: (column) => column);

  GeneratedColumn<String> get login =>
      $composableBuilder(column: $table.login, builder: (column) => column);

  GeneratedColumn<String> get senha =>
      $composableBuilder(column: $table.senha, builder: (column) => column);

  GeneratedColumn<DateTime> get dataCadastro => $composableBuilder(
    column: $table.dataCadastro,
    builder: (column) => column,
  );

  GeneratedColumn<String> get administrador => $composableBuilder(
    column: $table.administrador,
    builder: (column) => column,
  );
}

class $$ViewPessoaUsuariosTableTableManager
    extends
        RootTableManager<
          _$AppDatabase,
          $ViewPessoaUsuariosTable,
          ViewPessoaUsuario,
          $$ViewPessoaUsuariosTableFilterComposer,
          $$ViewPessoaUsuariosTableOrderingComposer,
          $$ViewPessoaUsuariosTableAnnotationComposer,
          $$ViewPessoaUsuariosTableCreateCompanionBuilder,
          $$ViewPessoaUsuariosTableUpdateCompanionBuilder,
          (
            ViewPessoaUsuario,
            BaseReferences<
              _$AppDatabase,
              $ViewPessoaUsuariosTable,
              ViewPessoaUsuario
            >,
          ),
          ViewPessoaUsuario,
          PrefetchHooks Function()
        > {
  $$ViewPessoaUsuariosTableTableManager(
    _$AppDatabase db,
    $ViewPessoaUsuariosTable table,
  ) : super(
        TableManagerState(
          db: db,
          table: table,
          createFilteringComposer:
              () => $$ViewPessoaUsuariosTableFilterComposer(
                $db: db,
                $table: table,
              ),
          createOrderingComposer:
              () => $$ViewPessoaUsuariosTableOrderingComposer(
                $db: db,
                $table: table,
              ),
          createComputedFieldComposer:
              () => $$ViewPessoaUsuariosTableAnnotationComposer(
                $db: db,
                $table: table,
              ),
          updateCompanionCallback:
              ({
                Value<int?> id = const Value.absent(),
                Value<int?> idPessoa = const Value.absent(),
                Value<String?> pessoaNome = const Value.absent(),
                Value<String?> tipo = const Value.absent(),
                Value<String?> email = const Value.absent(),
                Value<int?> idColaborador = const Value.absent(),
                Value<int?> idUsuario = const Value.absent(),
                Value<String?> login = const Value.absent(),
                Value<String?> senha = const Value.absent(),
                Value<DateTime?> dataCadastro = const Value.absent(),
                Value<String?> administrador = const Value.absent(),
              }) => ViewPessoaUsuariosCompanion(
                id: id,
                idPessoa: idPessoa,
                pessoaNome: pessoaNome,
                tipo: tipo,
                email: email,
                idColaborador: idColaborador,
                idUsuario: idUsuario,
                login: login,
                senha: senha,
                dataCadastro: dataCadastro,
                administrador: administrador,
              ),
          createCompanionCallback:
              ({
                Value<int?> id = const Value.absent(),
                Value<int?> idPessoa = const Value.absent(),
                Value<String?> pessoaNome = const Value.absent(),
                Value<String?> tipo = const Value.absent(),
                Value<String?> email = const Value.absent(),
                Value<int?> idColaborador = const Value.absent(),
                Value<int?> idUsuario = const Value.absent(),
                Value<String?> login = const Value.absent(),
                Value<String?> senha = const Value.absent(),
                Value<DateTime?> dataCadastro = const Value.absent(),
                Value<String?> administrador = const Value.absent(),
              }) => ViewPessoaUsuariosCompanion.insert(
                id: id,
                idPessoa: idPessoa,
                pessoaNome: pessoaNome,
                tipo: tipo,
                email: email,
                idColaborador: idColaborador,
                idUsuario: idUsuario,
                login: login,
                senha: senha,
                dataCadastro: dataCadastro,
                administrador: administrador,
              ),
          withReferenceMapper:
              (p0) =>
                  p0
                      .map(
                        (e) => (
                          e.readTable(table),
                          BaseReferences(db, table, e),
                        ),
                      )
                      .toList(),
          prefetchHooksCallback: null,
        ),
      );
}

typedef $$ViewPessoaUsuariosTableProcessedTableManager =
    ProcessedTableManager<
      _$AppDatabase,
      $ViewPessoaUsuariosTable,
      ViewPessoaUsuario,
      $$ViewPessoaUsuariosTableFilterComposer,
      $$ViewPessoaUsuariosTableOrderingComposer,
      $$ViewPessoaUsuariosTableAnnotationComposer,
      $$ViewPessoaUsuariosTableCreateCompanionBuilder,
      $$ViewPessoaUsuariosTableUpdateCompanionBuilder,
      (
        ViewPessoaUsuario,
        BaseReferences<
          _$AppDatabase,
          $ViewPessoaUsuariosTable,
          ViewPessoaUsuario
        >,
      ),
      ViewPessoaUsuario,
      PrefetchHooks Function()
    >;
typedef $$ViewPessoaColaboradorsTableCreateCompanionBuilder =
    ViewPessoaColaboradorsCompanion Function({
      Value<int?> id,
      Value<String?> nome,
      Value<String?> tipo,
      Value<String?> email,
      Value<String?> site,
      Value<String?> cpfCnpj,
      Value<String?> rgIe,
      Value<String?> matricula,
      Value<DateTime?> dataCadastro,
      Value<DateTime?> dataAdmissao,
      Value<DateTime?> dataDemissao,
      Value<String?> ctpsNumero,
      Value<String?> ctpsSerie,
      Value<DateTime?> ctpsDataExpedicao,
      Value<String?> ctpsUf,
      Value<String?> observacao,
      Value<String?> logradouro,
      Value<String?> numero,
      Value<String?> complemento,
      Value<String?> bairro,
      Value<String?> cidade,
      Value<String?> cep,
      Value<String?> municipioIbge,
      Value<String?> uf,
      Value<int?> idPessoa,
      Value<int?> idCargo,
      Value<int?> idSetor,
    });
typedef $$ViewPessoaColaboradorsTableUpdateCompanionBuilder =
    ViewPessoaColaboradorsCompanion Function({
      Value<int?> id,
      Value<String?> nome,
      Value<String?> tipo,
      Value<String?> email,
      Value<String?> site,
      Value<String?> cpfCnpj,
      Value<String?> rgIe,
      Value<String?> matricula,
      Value<DateTime?> dataCadastro,
      Value<DateTime?> dataAdmissao,
      Value<DateTime?> dataDemissao,
      Value<String?> ctpsNumero,
      Value<String?> ctpsSerie,
      Value<DateTime?> ctpsDataExpedicao,
      Value<String?> ctpsUf,
      Value<String?> observacao,
      Value<String?> logradouro,
      Value<String?> numero,
      Value<String?> complemento,
      Value<String?> bairro,
      Value<String?> cidade,
      Value<String?> cep,
      Value<String?> municipioIbge,
      Value<String?> uf,
      Value<int?> idPessoa,
      Value<int?> idCargo,
      Value<int?> idSetor,
    });

class $$ViewPessoaColaboradorsTableFilterComposer
    extends Composer<_$AppDatabase, $ViewPessoaColaboradorsTable> {
  $$ViewPessoaColaboradorsTableFilterComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnFilters<int> get id => $composableBuilder(
    column: $table.id,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get nome => $composableBuilder(
    column: $table.nome,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get tipo => $composableBuilder(
    column: $table.tipo,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get email => $composableBuilder(
    column: $table.email,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get site => $composableBuilder(
    column: $table.site,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get cpfCnpj => $composableBuilder(
    column: $table.cpfCnpj,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get rgIe => $composableBuilder(
    column: $table.rgIe,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get matricula => $composableBuilder(
    column: $table.matricula,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<DateTime> get dataCadastro => $composableBuilder(
    column: $table.dataCadastro,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<DateTime> get dataAdmissao => $composableBuilder(
    column: $table.dataAdmissao,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<DateTime> get dataDemissao => $composableBuilder(
    column: $table.dataDemissao,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get ctpsNumero => $composableBuilder(
    column: $table.ctpsNumero,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get ctpsSerie => $composableBuilder(
    column: $table.ctpsSerie,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<DateTime> get ctpsDataExpedicao => $composableBuilder(
    column: $table.ctpsDataExpedicao,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get ctpsUf => $composableBuilder(
    column: $table.ctpsUf,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get observacao => $composableBuilder(
    column: $table.observacao,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get logradouro => $composableBuilder(
    column: $table.logradouro,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get numero => $composableBuilder(
    column: $table.numero,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get complemento => $composableBuilder(
    column: $table.complemento,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get bairro => $composableBuilder(
    column: $table.bairro,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get cidade => $composableBuilder(
    column: $table.cidade,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get cep => $composableBuilder(
    column: $table.cep,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get municipioIbge => $composableBuilder(
    column: $table.municipioIbge,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get uf => $composableBuilder(
    column: $table.uf,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<int> get idPessoa => $composableBuilder(
    column: $table.idPessoa,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<int> get idCargo => $composableBuilder(
    column: $table.idCargo,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<int> get idSetor => $composableBuilder(
    column: $table.idSetor,
    builder: (column) => ColumnFilters(column),
  );
}

class $$ViewPessoaColaboradorsTableOrderingComposer
    extends Composer<_$AppDatabase, $ViewPessoaColaboradorsTable> {
  $$ViewPessoaColaboradorsTableOrderingComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnOrderings<int> get id => $composableBuilder(
    column: $table.id,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get nome => $composableBuilder(
    column: $table.nome,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get tipo => $composableBuilder(
    column: $table.tipo,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get email => $composableBuilder(
    column: $table.email,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get site => $composableBuilder(
    column: $table.site,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get cpfCnpj => $composableBuilder(
    column: $table.cpfCnpj,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get rgIe => $composableBuilder(
    column: $table.rgIe,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get matricula => $composableBuilder(
    column: $table.matricula,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<DateTime> get dataCadastro => $composableBuilder(
    column: $table.dataCadastro,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<DateTime> get dataAdmissao => $composableBuilder(
    column: $table.dataAdmissao,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<DateTime> get dataDemissao => $composableBuilder(
    column: $table.dataDemissao,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get ctpsNumero => $composableBuilder(
    column: $table.ctpsNumero,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get ctpsSerie => $composableBuilder(
    column: $table.ctpsSerie,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<DateTime> get ctpsDataExpedicao => $composableBuilder(
    column: $table.ctpsDataExpedicao,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get ctpsUf => $composableBuilder(
    column: $table.ctpsUf,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get observacao => $composableBuilder(
    column: $table.observacao,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get logradouro => $composableBuilder(
    column: $table.logradouro,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get numero => $composableBuilder(
    column: $table.numero,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get complemento => $composableBuilder(
    column: $table.complemento,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get bairro => $composableBuilder(
    column: $table.bairro,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get cidade => $composableBuilder(
    column: $table.cidade,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get cep => $composableBuilder(
    column: $table.cep,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get municipioIbge => $composableBuilder(
    column: $table.municipioIbge,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get uf => $composableBuilder(
    column: $table.uf,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<int> get idPessoa => $composableBuilder(
    column: $table.idPessoa,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<int> get idCargo => $composableBuilder(
    column: $table.idCargo,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<int> get idSetor => $composableBuilder(
    column: $table.idSetor,
    builder: (column) => ColumnOrderings(column),
  );
}

class $$ViewPessoaColaboradorsTableAnnotationComposer
    extends Composer<_$AppDatabase, $ViewPessoaColaboradorsTable> {
  $$ViewPessoaColaboradorsTableAnnotationComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  GeneratedColumn<int> get id =>
      $composableBuilder(column: $table.id, builder: (column) => column);

  GeneratedColumn<String> get nome =>
      $composableBuilder(column: $table.nome, builder: (column) => column);

  GeneratedColumn<String> get tipo =>
      $composableBuilder(column: $table.tipo, builder: (column) => column);

  GeneratedColumn<String> get email =>
      $composableBuilder(column: $table.email, builder: (column) => column);

  GeneratedColumn<String> get site =>
      $composableBuilder(column: $table.site, builder: (column) => column);

  GeneratedColumn<String> get cpfCnpj =>
      $composableBuilder(column: $table.cpfCnpj, builder: (column) => column);

  GeneratedColumn<String> get rgIe =>
      $composableBuilder(column: $table.rgIe, builder: (column) => column);

  GeneratedColumn<String> get matricula =>
      $composableBuilder(column: $table.matricula, builder: (column) => column);

  GeneratedColumn<DateTime> get dataCadastro => $composableBuilder(
    column: $table.dataCadastro,
    builder: (column) => column,
  );

  GeneratedColumn<DateTime> get dataAdmissao => $composableBuilder(
    column: $table.dataAdmissao,
    builder: (column) => column,
  );

  GeneratedColumn<DateTime> get dataDemissao => $composableBuilder(
    column: $table.dataDemissao,
    builder: (column) => column,
  );

  GeneratedColumn<String> get ctpsNumero => $composableBuilder(
    column: $table.ctpsNumero,
    builder: (column) => column,
  );

  GeneratedColumn<String> get ctpsSerie =>
      $composableBuilder(column: $table.ctpsSerie, builder: (column) => column);

  GeneratedColumn<DateTime> get ctpsDataExpedicao => $composableBuilder(
    column: $table.ctpsDataExpedicao,
    builder: (column) => column,
  );

  GeneratedColumn<String> get ctpsUf =>
      $composableBuilder(column: $table.ctpsUf, builder: (column) => column);

  GeneratedColumn<String> get observacao => $composableBuilder(
    column: $table.observacao,
    builder: (column) => column,
  );

  GeneratedColumn<String> get logradouro => $composableBuilder(
    column: $table.logradouro,
    builder: (column) => column,
  );

  GeneratedColumn<String> get numero =>
      $composableBuilder(column: $table.numero, builder: (column) => column);

  GeneratedColumn<String> get complemento => $composableBuilder(
    column: $table.complemento,
    builder: (column) => column,
  );

  GeneratedColumn<String> get bairro =>
      $composableBuilder(column: $table.bairro, builder: (column) => column);

  GeneratedColumn<String> get cidade =>
      $composableBuilder(column: $table.cidade, builder: (column) => column);

  GeneratedColumn<String> get cep =>
      $composableBuilder(column: $table.cep, builder: (column) => column);

  GeneratedColumn<String> get municipioIbge => $composableBuilder(
    column: $table.municipioIbge,
    builder: (column) => column,
  );

  GeneratedColumn<String> get uf =>
      $composableBuilder(column: $table.uf, builder: (column) => column);

  GeneratedColumn<int> get idPessoa =>
      $composableBuilder(column: $table.idPessoa, builder: (column) => column);

  GeneratedColumn<int> get idCargo =>
      $composableBuilder(column: $table.idCargo, builder: (column) => column);

  GeneratedColumn<int> get idSetor =>
      $composableBuilder(column: $table.idSetor, builder: (column) => column);
}

class $$ViewPessoaColaboradorsTableTableManager
    extends
        RootTableManager<
          _$AppDatabase,
          $ViewPessoaColaboradorsTable,
          ViewPessoaColaborador,
          $$ViewPessoaColaboradorsTableFilterComposer,
          $$ViewPessoaColaboradorsTableOrderingComposer,
          $$ViewPessoaColaboradorsTableAnnotationComposer,
          $$ViewPessoaColaboradorsTableCreateCompanionBuilder,
          $$ViewPessoaColaboradorsTableUpdateCompanionBuilder,
          (
            ViewPessoaColaborador,
            BaseReferences<
              _$AppDatabase,
              $ViewPessoaColaboradorsTable,
              ViewPessoaColaborador
            >,
          ),
          ViewPessoaColaborador,
          PrefetchHooks Function()
        > {
  $$ViewPessoaColaboradorsTableTableManager(
    _$AppDatabase db,
    $ViewPessoaColaboradorsTable table,
  ) : super(
        TableManagerState(
          db: db,
          table: table,
          createFilteringComposer:
              () => $$ViewPessoaColaboradorsTableFilterComposer(
                $db: db,
                $table: table,
              ),
          createOrderingComposer:
              () => $$ViewPessoaColaboradorsTableOrderingComposer(
                $db: db,
                $table: table,
              ),
          createComputedFieldComposer:
              () => $$ViewPessoaColaboradorsTableAnnotationComposer(
                $db: db,
                $table: table,
              ),
          updateCompanionCallback:
              ({
                Value<int?> id = const Value.absent(),
                Value<String?> nome = const Value.absent(),
                Value<String?> tipo = const Value.absent(),
                Value<String?> email = const Value.absent(),
                Value<String?> site = const Value.absent(),
                Value<String?> cpfCnpj = const Value.absent(),
                Value<String?> rgIe = const Value.absent(),
                Value<String?> matricula = const Value.absent(),
                Value<DateTime?> dataCadastro = const Value.absent(),
                Value<DateTime?> dataAdmissao = const Value.absent(),
                Value<DateTime?> dataDemissao = const Value.absent(),
                Value<String?> ctpsNumero = const Value.absent(),
                Value<String?> ctpsSerie = const Value.absent(),
                Value<DateTime?> ctpsDataExpedicao = const Value.absent(),
                Value<String?> ctpsUf = const Value.absent(),
                Value<String?> observacao = const Value.absent(),
                Value<String?> logradouro = const Value.absent(),
                Value<String?> numero = const Value.absent(),
                Value<String?> complemento = const Value.absent(),
                Value<String?> bairro = const Value.absent(),
                Value<String?> cidade = const Value.absent(),
                Value<String?> cep = const Value.absent(),
                Value<String?> municipioIbge = const Value.absent(),
                Value<String?> uf = const Value.absent(),
                Value<int?> idPessoa = const Value.absent(),
                Value<int?> idCargo = const Value.absent(),
                Value<int?> idSetor = const Value.absent(),
              }) => ViewPessoaColaboradorsCompanion(
                id: id,
                nome: nome,
                tipo: tipo,
                email: email,
                site: site,
                cpfCnpj: cpfCnpj,
                rgIe: rgIe,
                matricula: matricula,
                dataCadastro: dataCadastro,
                dataAdmissao: dataAdmissao,
                dataDemissao: dataDemissao,
                ctpsNumero: ctpsNumero,
                ctpsSerie: ctpsSerie,
                ctpsDataExpedicao: ctpsDataExpedicao,
                ctpsUf: ctpsUf,
                observacao: observacao,
                logradouro: logradouro,
                numero: numero,
                complemento: complemento,
                bairro: bairro,
                cidade: cidade,
                cep: cep,
                municipioIbge: municipioIbge,
                uf: uf,
                idPessoa: idPessoa,
                idCargo: idCargo,
                idSetor: idSetor,
              ),
          createCompanionCallback:
              ({
                Value<int?> id = const Value.absent(),
                Value<String?> nome = const Value.absent(),
                Value<String?> tipo = const Value.absent(),
                Value<String?> email = const Value.absent(),
                Value<String?> site = const Value.absent(),
                Value<String?> cpfCnpj = const Value.absent(),
                Value<String?> rgIe = const Value.absent(),
                Value<String?> matricula = const Value.absent(),
                Value<DateTime?> dataCadastro = const Value.absent(),
                Value<DateTime?> dataAdmissao = const Value.absent(),
                Value<DateTime?> dataDemissao = const Value.absent(),
                Value<String?> ctpsNumero = const Value.absent(),
                Value<String?> ctpsSerie = const Value.absent(),
                Value<DateTime?> ctpsDataExpedicao = const Value.absent(),
                Value<String?> ctpsUf = const Value.absent(),
                Value<String?> observacao = const Value.absent(),
                Value<String?> logradouro = const Value.absent(),
                Value<String?> numero = const Value.absent(),
                Value<String?> complemento = const Value.absent(),
                Value<String?> bairro = const Value.absent(),
                Value<String?> cidade = const Value.absent(),
                Value<String?> cep = const Value.absent(),
                Value<String?> municipioIbge = const Value.absent(),
                Value<String?> uf = const Value.absent(),
                Value<int?> idPessoa = const Value.absent(),
                Value<int?> idCargo = const Value.absent(),
                Value<int?> idSetor = const Value.absent(),
              }) => ViewPessoaColaboradorsCompanion.insert(
                id: id,
                nome: nome,
                tipo: tipo,
                email: email,
                site: site,
                cpfCnpj: cpfCnpj,
                rgIe: rgIe,
                matricula: matricula,
                dataCadastro: dataCadastro,
                dataAdmissao: dataAdmissao,
                dataDemissao: dataDemissao,
                ctpsNumero: ctpsNumero,
                ctpsSerie: ctpsSerie,
                ctpsDataExpedicao: ctpsDataExpedicao,
                ctpsUf: ctpsUf,
                observacao: observacao,
                logradouro: logradouro,
                numero: numero,
                complemento: complemento,
                bairro: bairro,
                cidade: cidade,
                cep: cep,
                municipioIbge: municipioIbge,
                uf: uf,
                idPessoa: idPessoa,
                idCargo: idCargo,
                idSetor: idSetor,
              ),
          withReferenceMapper:
              (p0) =>
                  p0
                      .map(
                        (e) => (
                          e.readTable(table),
                          BaseReferences(db, table, e),
                        ),
                      )
                      .toList(),
          prefetchHooksCallback: null,
        ),
      );
}

typedef $$ViewPessoaColaboradorsTableProcessedTableManager =
    ProcessedTableManager<
      _$AppDatabase,
      $ViewPessoaColaboradorsTable,
      ViewPessoaColaborador,
      $$ViewPessoaColaboradorsTableFilterComposer,
      $$ViewPessoaColaboradorsTableOrderingComposer,
      $$ViewPessoaColaboradorsTableAnnotationComposer,
      $$ViewPessoaColaboradorsTableCreateCompanionBuilder,
      $$ViewPessoaColaboradorsTableUpdateCompanionBuilder,
      (
        ViewPessoaColaborador,
        BaseReferences<
          _$AppDatabase,
          $ViewPessoaColaboradorsTable,
          ViewPessoaColaborador
        >,
      ),
      ViewPessoaColaborador,
      PrefetchHooks Function()
    >;
typedef $$ViewPessoaVendedorsTableCreateCompanionBuilder =
    ViewPessoaVendedorsCompanion Function({
      Value<int?> id,
      Value<String?> nome,
      Value<String?> tipo,
      Value<String?> email,
      Value<String?> site,
      Value<String?> cpfCnpj,
      Value<String?> rgIe,
      Value<String?> matricula,
      Value<DateTime?> dataCadastro,
      Value<DateTime?> dataAdmissao,
      Value<DateTime?> dataDemissao,
      Value<String?> ctpsNumero,
      Value<String?> ctpsSerie,
      Value<DateTime?> ctpsDataExpedicao,
      Value<String?> ctpsUf,
      Value<String?> observacao,
      Value<String?> logradouro,
      Value<String?> numero,
      Value<String?> complemento,
      Value<String?> bairro,
      Value<String?> cidade,
      Value<String?> cep,
      Value<String?> municipioIbge,
      Value<String?> uf,
      Value<int?> idPessoa,
      Value<int?> idCargo,
      Value<int?> idSetor,
      Value<double?> comissao,
      Value<double?> metaVenda,
    });
typedef $$ViewPessoaVendedorsTableUpdateCompanionBuilder =
    ViewPessoaVendedorsCompanion Function({
      Value<int?> id,
      Value<String?> nome,
      Value<String?> tipo,
      Value<String?> email,
      Value<String?> site,
      Value<String?> cpfCnpj,
      Value<String?> rgIe,
      Value<String?> matricula,
      Value<DateTime?> dataCadastro,
      Value<DateTime?> dataAdmissao,
      Value<DateTime?> dataDemissao,
      Value<String?> ctpsNumero,
      Value<String?> ctpsSerie,
      Value<DateTime?> ctpsDataExpedicao,
      Value<String?> ctpsUf,
      Value<String?> observacao,
      Value<String?> logradouro,
      Value<String?> numero,
      Value<String?> complemento,
      Value<String?> bairro,
      Value<String?> cidade,
      Value<String?> cep,
      Value<String?> municipioIbge,
      Value<String?> uf,
      Value<int?> idPessoa,
      Value<int?> idCargo,
      Value<int?> idSetor,
      Value<double?> comissao,
      Value<double?> metaVenda,
    });

class $$ViewPessoaVendedorsTableFilterComposer
    extends Composer<_$AppDatabase, $ViewPessoaVendedorsTable> {
  $$ViewPessoaVendedorsTableFilterComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnFilters<int> get id => $composableBuilder(
    column: $table.id,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get nome => $composableBuilder(
    column: $table.nome,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get tipo => $composableBuilder(
    column: $table.tipo,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get email => $composableBuilder(
    column: $table.email,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get site => $composableBuilder(
    column: $table.site,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get cpfCnpj => $composableBuilder(
    column: $table.cpfCnpj,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get rgIe => $composableBuilder(
    column: $table.rgIe,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get matricula => $composableBuilder(
    column: $table.matricula,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<DateTime> get dataCadastro => $composableBuilder(
    column: $table.dataCadastro,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<DateTime> get dataAdmissao => $composableBuilder(
    column: $table.dataAdmissao,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<DateTime> get dataDemissao => $composableBuilder(
    column: $table.dataDemissao,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get ctpsNumero => $composableBuilder(
    column: $table.ctpsNumero,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get ctpsSerie => $composableBuilder(
    column: $table.ctpsSerie,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<DateTime> get ctpsDataExpedicao => $composableBuilder(
    column: $table.ctpsDataExpedicao,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get ctpsUf => $composableBuilder(
    column: $table.ctpsUf,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get observacao => $composableBuilder(
    column: $table.observacao,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get logradouro => $composableBuilder(
    column: $table.logradouro,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get numero => $composableBuilder(
    column: $table.numero,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get complemento => $composableBuilder(
    column: $table.complemento,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get bairro => $composableBuilder(
    column: $table.bairro,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get cidade => $composableBuilder(
    column: $table.cidade,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get cep => $composableBuilder(
    column: $table.cep,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get municipioIbge => $composableBuilder(
    column: $table.municipioIbge,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get uf => $composableBuilder(
    column: $table.uf,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<int> get idPessoa => $composableBuilder(
    column: $table.idPessoa,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<int> get idCargo => $composableBuilder(
    column: $table.idCargo,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<int> get idSetor => $composableBuilder(
    column: $table.idSetor,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<double> get comissao => $composableBuilder(
    column: $table.comissao,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<double> get metaVenda => $composableBuilder(
    column: $table.metaVenda,
    builder: (column) => ColumnFilters(column),
  );
}

class $$ViewPessoaVendedorsTableOrderingComposer
    extends Composer<_$AppDatabase, $ViewPessoaVendedorsTable> {
  $$ViewPessoaVendedorsTableOrderingComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnOrderings<int> get id => $composableBuilder(
    column: $table.id,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get nome => $composableBuilder(
    column: $table.nome,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get tipo => $composableBuilder(
    column: $table.tipo,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get email => $composableBuilder(
    column: $table.email,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get site => $composableBuilder(
    column: $table.site,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get cpfCnpj => $composableBuilder(
    column: $table.cpfCnpj,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get rgIe => $composableBuilder(
    column: $table.rgIe,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get matricula => $composableBuilder(
    column: $table.matricula,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<DateTime> get dataCadastro => $composableBuilder(
    column: $table.dataCadastro,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<DateTime> get dataAdmissao => $composableBuilder(
    column: $table.dataAdmissao,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<DateTime> get dataDemissao => $composableBuilder(
    column: $table.dataDemissao,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get ctpsNumero => $composableBuilder(
    column: $table.ctpsNumero,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get ctpsSerie => $composableBuilder(
    column: $table.ctpsSerie,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<DateTime> get ctpsDataExpedicao => $composableBuilder(
    column: $table.ctpsDataExpedicao,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get ctpsUf => $composableBuilder(
    column: $table.ctpsUf,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get observacao => $composableBuilder(
    column: $table.observacao,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get logradouro => $composableBuilder(
    column: $table.logradouro,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get numero => $composableBuilder(
    column: $table.numero,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get complemento => $composableBuilder(
    column: $table.complemento,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get bairro => $composableBuilder(
    column: $table.bairro,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get cidade => $composableBuilder(
    column: $table.cidade,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get cep => $composableBuilder(
    column: $table.cep,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get municipioIbge => $composableBuilder(
    column: $table.municipioIbge,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get uf => $composableBuilder(
    column: $table.uf,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<int> get idPessoa => $composableBuilder(
    column: $table.idPessoa,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<int> get idCargo => $composableBuilder(
    column: $table.idCargo,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<int> get idSetor => $composableBuilder(
    column: $table.idSetor,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<double> get comissao => $composableBuilder(
    column: $table.comissao,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<double> get metaVenda => $composableBuilder(
    column: $table.metaVenda,
    builder: (column) => ColumnOrderings(column),
  );
}

class $$ViewPessoaVendedorsTableAnnotationComposer
    extends Composer<_$AppDatabase, $ViewPessoaVendedorsTable> {
  $$ViewPessoaVendedorsTableAnnotationComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  GeneratedColumn<int> get id =>
      $composableBuilder(column: $table.id, builder: (column) => column);

  GeneratedColumn<String> get nome =>
      $composableBuilder(column: $table.nome, builder: (column) => column);

  GeneratedColumn<String> get tipo =>
      $composableBuilder(column: $table.tipo, builder: (column) => column);

  GeneratedColumn<String> get email =>
      $composableBuilder(column: $table.email, builder: (column) => column);

  GeneratedColumn<String> get site =>
      $composableBuilder(column: $table.site, builder: (column) => column);

  GeneratedColumn<String> get cpfCnpj =>
      $composableBuilder(column: $table.cpfCnpj, builder: (column) => column);

  GeneratedColumn<String> get rgIe =>
      $composableBuilder(column: $table.rgIe, builder: (column) => column);

  GeneratedColumn<String> get matricula =>
      $composableBuilder(column: $table.matricula, builder: (column) => column);

  GeneratedColumn<DateTime> get dataCadastro => $composableBuilder(
    column: $table.dataCadastro,
    builder: (column) => column,
  );

  GeneratedColumn<DateTime> get dataAdmissao => $composableBuilder(
    column: $table.dataAdmissao,
    builder: (column) => column,
  );

  GeneratedColumn<DateTime> get dataDemissao => $composableBuilder(
    column: $table.dataDemissao,
    builder: (column) => column,
  );

  GeneratedColumn<String> get ctpsNumero => $composableBuilder(
    column: $table.ctpsNumero,
    builder: (column) => column,
  );

  GeneratedColumn<String> get ctpsSerie =>
      $composableBuilder(column: $table.ctpsSerie, builder: (column) => column);

  GeneratedColumn<DateTime> get ctpsDataExpedicao => $composableBuilder(
    column: $table.ctpsDataExpedicao,
    builder: (column) => column,
  );

  GeneratedColumn<String> get ctpsUf =>
      $composableBuilder(column: $table.ctpsUf, builder: (column) => column);

  GeneratedColumn<String> get observacao => $composableBuilder(
    column: $table.observacao,
    builder: (column) => column,
  );

  GeneratedColumn<String> get logradouro => $composableBuilder(
    column: $table.logradouro,
    builder: (column) => column,
  );

  GeneratedColumn<String> get numero =>
      $composableBuilder(column: $table.numero, builder: (column) => column);

  GeneratedColumn<String> get complemento => $composableBuilder(
    column: $table.complemento,
    builder: (column) => column,
  );

  GeneratedColumn<String> get bairro =>
      $composableBuilder(column: $table.bairro, builder: (column) => column);

  GeneratedColumn<String> get cidade =>
      $composableBuilder(column: $table.cidade, builder: (column) => column);

  GeneratedColumn<String> get cep =>
      $composableBuilder(column: $table.cep, builder: (column) => column);

  GeneratedColumn<String> get municipioIbge => $composableBuilder(
    column: $table.municipioIbge,
    builder: (column) => column,
  );

  GeneratedColumn<String> get uf =>
      $composableBuilder(column: $table.uf, builder: (column) => column);

  GeneratedColumn<int> get idPessoa =>
      $composableBuilder(column: $table.idPessoa, builder: (column) => column);

  GeneratedColumn<int> get idCargo =>
      $composableBuilder(column: $table.idCargo, builder: (column) => column);

  GeneratedColumn<int> get idSetor =>
      $composableBuilder(column: $table.idSetor, builder: (column) => column);

  GeneratedColumn<double> get comissao =>
      $composableBuilder(column: $table.comissao, builder: (column) => column);

  GeneratedColumn<double> get metaVenda =>
      $composableBuilder(column: $table.metaVenda, builder: (column) => column);
}

class $$ViewPessoaVendedorsTableTableManager
    extends
        RootTableManager<
          _$AppDatabase,
          $ViewPessoaVendedorsTable,
          ViewPessoaVendedor,
          $$ViewPessoaVendedorsTableFilterComposer,
          $$ViewPessoaVendedorsTableOrderingComposer,
          $$ViewPessoaVendedorsTableAnnotationComposer,
          $$ViewPessoaVendedorsTableCreateCompanionBuilder,
          $$ViewPessoaVendedorsTableUpdateCompanionBuilder,
          (
            ViewPessoaVendedor,
            BaseReferences<
              _$AppDatabase,
              $ViewPessoaVendedorsTable,
              ViewPessoaVendedor
            >,
          ),
          ViewPessoaVendedor,
          PrefetchHooks Function()
        > {
  $$ViewPessoaVendedorsTableTableManager(
    _$AppDatabase db,
    $ViewPessoaVendedorsTable table,
  ) : super(
        TableManagerState(
          db: db,
          table: table,
          createFilteringComposer:
              () => $$ViewPessoaVendedorsTableFilterComposer(
                $db: db,
                $table: table,
              ),
          createOrderingComposer:
              () => $$ViewPessoaVendedorsTableOrderingComposer(
                $db: db,
                $table: table,
              ),
          createComputedFieldComposer:
              () => $$ViewPessoaVendedorsTableAnnotationComposer(
                $db: db,
                $table: table,
              ),
          updateCompanionCallback:
              ({
                Value<int?> id = const Value.absent(),
                Value<String?> nome = const Value.absent(),
                Value<String?> tipo = const Value.absent(),
                Value<String?> email = const Value.absent(),
                Value<String?> site = const Value.absent(),
                Value<String?> cpfCnpj = const Value.absent(),
                Value<String?> rgIe = const Value.absent(),
                Value<String?> matricula = const Value.absent(),
                Value<DateTime?> dataCadastro = const Value.absent(),
                Value<DateTime?> dataAdmissao = const Value.absent(),
                Value<DateTime?> dataDemissao = const Value.absent(),
                Value<String?> ctpsNumero = const Value.absent(),
                Value<String?> ctpsSerie = const Value.absent(),
                Value<DateTime?> ctpsDataExpedicao = const Value.absent(),
                Value<String?> ctpsUf = const Value.absent(),
                Value<String?> observacao = const Value.absent(),
                Value<String?> logradouro = const Value.absent(),
                Value<String?> numero = const Value.absent(),
                Value<String?> complemento = const Value.absent(),
                Value<String?> bairro = const Value.absent(),
                Value<String?> cidade = const Value.absent(),
                Value<String?> cep = const Value.absent(),
                Value<String?> municipioIbge = const Value.absent(),
                Value<String?> uf = const Value.absent(),
                Value<int?> idPessoa = const Value.absent(),
                Value<int?> idCargo = const Value.absent(),
                Value<int?> idSetor = const Value.absent(),
                Value<double?> comissao = const Value.absent(),
                Value<double?> metaVenda = const Value.absent(),
              }) => ViewPessoaVendedorsCompanion(
                id: id,
                nome: nome,
                tipo: tipo,
                email: email,
                site: site,
                cpfCnpj: cpfCnpj,
                rgIe: rgIe,
                matricula: matricula,
                dataCadastro: dataCadastro,
                dataAdmissao: dataAdmissao,
                dataDemissao: dataDemissao,
                ctpsNumero: ctpsNumero,
                ctpsSerie: ctpsSerie,
                ctpsDataExpedicao: ctpsDataExpedicao,
                ctpsUf: ctpsUf,
                observacao: observacao,
                logradouro: logradouro,
                numero: numero,
                complemento: complemento,
                bairro: bairro,
                cidade: cidade,
                cep: cep,
                municipioIbge: municipioIbge,
                uf: uf,
                idPessoa: idPessoa,
                idCargo: idCargo,
                idSetor: idSetor,
                comissao: comissao,
                metaVenda: metaVenda,
              ),
          createCompanionCallback:
              ({
                Value<int?> id = const Value.absent(),
                Value<String?> nome = const Value.absent(),
                Value<String?> tipo = const Value.absent(),
                Value<String?> email = const Value.absent(),
                Value<String?> site = const Value.absent(),
                Value<String?> cpfCnpj = const Value.absent(),
                Value<String?> rgIe = const Value.absent(),
                Value<String?> matricula = const Value.absent(),
                Value<DateTime?> dataCadastro = const Value.absent(),
                Value<DateTime?> dataAdmissao = const Value.absent(),
                Value<DateTime?> dataDemissao = const Value.absent(),
                Value<String?> ctpsNumero = const Value.absent(),
                Value<String?> ctpsSerie = const Value.absent(),
                Value<DateTime?> ctpsDataExpedicao = const Value.absent(),
                Value<String?> ctpsUf = const Value.absent(),
                Value<String?> observacao = const Value.absent(),
                Value<String?> logradouro = const Value.absent(),
                Value<String?> numero = const Value.absent(),
                Value<String?> complemento = const Value.absent(),
                Value<String?> bairro = const Value.absent(),
                Value<String?> cidade = const Value.absent(),
                Value<String?> cep = const Value.absent(),
                Value<String?> municipioIbge = const Value.absent(),
                Value<String?> uf = const Value.absent(),
                Value<int?> idPessoa = const Value.absent(),
                Value<int?> idCargo = const Value.absent(),
                Value<int?> idSetor = const Value.absent(),
                Value<double?> comissao = const Value.absent(),
                Value<double?> metaVenda = const Value.absent(),
              }) => ViewPessoaVendedorsCompanion.insert(
                id: id,
                nome: nome,
                tipo: tipo,
                email: email,
                site: site,
                cpfCnpj: cpfCnpj,
                rgIe: rgIe,
                matricula: matricula,
                dataCadastro: dataCadastro,
                dataAdmissao: dataAdmissao,
                dataDemissao: dataDemissao,
                ctpsNumero: ctpsNumero,
                ctpsSerie: ctpsSerie,
                ctpsDataExpedicao: ctpsDataExpedicao,
                ctpsUf: ctpsUf,
                observacao: observacao,
                logradouro: logradouro,
                numero: numero,
                complemento: complemento,
                bairro: bairro,
                cidade: cidade,
                cep: cep,
                municipioIbge: municipioIbge,
                uf: uf,
                idPessoa: idPessoa,
                idCargo: idCargo,
                idSetor: idSetor,
                comissao: comissao,
                metaVenda: metaVenda,
              ),
          withReferenceMapper:
              (p0) =>
                  p0
                      .map(
                        (e) => (
                          e.readTable(table),
                          BaseReferences(db, table, e),
                        ),
                      )
                      .toList(),
          prefetchHooksCallback: null,
        ),
      );
}

typedef $$ViewPessoaVendedorsTableProcessedTableManager =
    ProcessedTableManager<
      _$AppDatabase,
      $ViewPessoaVendedorsTable,
      ViewPessoaVendedor,
      $$ViewPessoaVendedorsTableFilterComposer,
      $$ViewPessoaVendedorsTableOrderingComposer,
      $$ViewPessoaVendedorsTableAnnotationComposer,
      $$ViewPessoaVendedorsTableCreateCompanionBuilder,
      $$ViewPessoaVendedorsTableUpdateCompanionBuilder,
      (
        ViewPessoaVendedor,
        BaseReferences<
          _$AppDatabase,
          $ViewPessoaVendedorsTable,
          ViewPessoaVendedor
        >,
      ),
      ViewPessoaVendedor,
      PrefetchHooks Function()
    >;
typedef $$ViewPessoaTransportadorasTableCreateCompanionBuilder =
    ViewPessoaTransportadorasCompanion Function({
      Value<int?> id,
      Value<String?> nome,
      Value<String?> tipo,
      Value<String?> email,
      Value<String?> site,
      Value<String?> cpfCnpj,
      Value<String?> rgIe,
      Value<DateTime?> dataCadastro,
      Value<String?> observacao,
      Value<int?> idPessoa,
    });
typedef $$ViewPessoaTransportadorasTableUpdateCompanionBuilder =
    ViewPessoaTransportadorasCompanion Function({
      Value<int?> id,
      Value<String?> nome,
      Value<String?> tipo,
      Value<String?> email,
      Value<String?> site,
      Value<String?> cpfCnpj,
      Value<String?> rgIe,
      Value<DateTime?> dataCadastro,
      Value<String?> observacao,
      Value<int?> idPessoa,
    });

class $$ViewPessoaTransportadorasTableFilterComposer
    extends Composer<_$AppDatabase, $ViewPessoaTransportadorasTable> {
  $$ViewPessoaTransportadorasTableFilterComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnFilters<int> get id => $composableBuilder(
    column: $table.id,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get nome => $composableBuilder(
    column: $table.nome,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get tipo => $composableBuilder(
    column: $table.tipo,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get email => $composableBuilder(
    column: $table.email,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get site => $composableBuilder(
    column: $table.site,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get cpfCnpj => $composableBuilder(
    column: $table.cpfCnpj,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get rgIe => $composableBuilder(
    column: $table.rgIe,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<DateTime> get dataCadastro => $composableBuilder(
    column: $table.dataCadastro,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get observacao => $composableBuilder(
    column: $table.observacao,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<int> get idPessoa => $composableBuilder(
    column: $table.idPessoa,
    builder: (column) => ColumnFilters(column),
  );
}

class $$ViewPessoaTransportadorasTableOrderingComposer
    extends Composer<_$AppDatabase, $ViewPessoaTransportadorasTable> {
  $$ViewPessoaTransportadorasTableOrderingComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnOrderings<int> get id => $composableBuilder(
    column: $table.id,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get nome => $composableBuilder(
    column: $table.nome,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get tipo => $composableBuilder(
    column: $table.tipo,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get email => $composableBuilder(
    column: $table.email,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get site => $composableBuilder(
    column: $table.site,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get cpfCnpj => $composableBuilder(
    column: $table.cpfCnpj,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get rgIe => $composableBuilder(
    column: $table.rgIe,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<DateTime> get dataCadastro => $composableBuilder(
    column: $table.dataCadastro,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get observacao => $composableBuilder(
    column: $table.observacao,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<int> get idPessoa => $composableBuilder(
    column: $table.idPessoa,
    builder: (column) => ColumnOrderings(column),
  );
}

class $$ViewPessoaTransportadorasTableAnnotationComposer
    extends Composer<_$AppDatabase, $ViewPessoaTransportadorasTable> {
  $$ViewPessoaTransportadorasTableAnnotationComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  GeneratedColumn<int> get id =>
      $composableBuilder(column: $table.id, builder: (column) => column);

  GeneratedColumn<String> get nome =>
      $composableBuilder(column: $table.nome, builder: (column) => column);

  GeneratedColumn<String> get tipo =>
      $composableBuilder(column: $table.tipo, builder: (column) => column);

  GeneratedColumn<String> get email =>
      $composableBuilder(column: $table.email, builder: (column) => column);

  GeneratedColumn<String> get site =>
      $composableBuilder(column: $table.site, builder: (column) => column);

  GeneratedColumn<String> get cpfCnpj =>
      $composableBuilder(column: $table.cpfCnpj, builder: (column) => column);

  GeneratedColumn<String> get rgIe =>
      $composableBuilder(column: $table.rgIe, builder: (column) => column);

  GeneratedColumn<DateTime> get dataCadastro => $composableBuilder(
    column: $table.dataCadastro,
    builder: (column) => column,
  );

  GeneratedColumn<String> get observacao => $composableBuilder(
    column: $table.observacao,
    builder: (column) => column,
  );

  GeneratedColumn<int> get idPessoa =>
      $composableBuilder(column: $table.idPessoa, builder: (column) => column);
}

class $$ViewPessoaTransportadorasTableTableManager
    extends
        RootTableManager<
          _$AppDatabase,
          $ViewPessoaTransportadorasTable,
          ViewPessoaTransportadora,
          $$ViewPessoaTransportadorasTableFilterComposer,
          $$ViewPessoaTransportadorasTableOrderingComposer,
          $$ViewPessoaTransportadorasTableAnnotationComposer,
          $$ViewPessoaTransportadorasTableCreateCompanionBuilder,
          $$ViewPessoaTransportadorasTableUpdateCompanionBuilder,
          (
            ViewPessoaTransportadora,
            BaseReferences<
              _$AppDatabase,
              $ViewPessoaTransportadorasTable,
              ViewPessoaTransportadora
            >,
          ),
          ViewPessoaTransportadora,
          PrefetchHooks Function()
        > {
  $$ViewPessoaTransportadorasTableTableManager(
    _$AppDatabase db,
    $ViewPessoaTransportadorasTable table,
  ) : super(
        TableManagerState(
          db: db,
          table: table,
          createFilteringComposer:
              () => $$ViewPessoaTransportadorasTableFilterComposer(
                $db: db,
                $table: table,
              ),
          createOrderingComposer:
              () => $$ViewPessoaTransportadorasTableOrderingComposer(
                $db: db,
                $table: table,
              ),
          createComputedFieldComposer:
              () => $$ViewPessoaTransportadorasTableAnnotationComposer(
                $db: db,
                $table: table,
              ),
          updateCompanionCallback:
              ({
                Value<int?> id = const Value.absent(),
                Value<String?> nome = const Value.absent(),
                Value<String?> tipo = const Value.absent(),
                Value<String?> email = const Value.absent(),
                Value<String?> site = const Value.absent(),
                Value<String?> cpfCnpj = const Value.absent(),
                Value<String?> rgIe = const Value.absent(),
                Value<DateTime?> dataCadastro = const Value.absent(),
                Value<String?> observacao = const Value.absent(),
                Value<int?> idPessoa = const Value.absent(),
              }) => ViewPessoaTransportadorasCompanion(
                id: id,
                nome: nome,
                tipo: tipo,
                email: email,
                site: site,
                cpfCnpj: cpfCnpj,
                rgIe: rgIe,
                dataCadastro: dataCadastro,
                observacao: observacao,
                idPessoa: idPessoa,
              ),
          createCompanionCallback:
              ({
                Value<int?> id = const Value.absent(),
                Value<String?> nome = const Value.absent(),
                Value<String?> tipo = const Value.absent(),
                Value<String?> email = const Value.absent(),
                Value<String?> site = const Value.absent(),
                Value<String?> cpfCnpj = const Value.absent(),
                Value<String?> rgIe = const Value.absent(),
                Value<DateTime?> dataCadastro = const Value.absent(),
                Value<String?> observacao = const Value.absent(),
                Value<int?> idPessoa = const Value.absent(),
              }) => ViewPessoaTransportadorasCompanion.insert(
                id: id,
                nome: nome,
                tipo: tipo,
                email: email,
                site: site,
                cpfCnpj: cpfCnpj,
                rgIe: rgIe,
                dataCadastro: dataCadastro,
                observacao: observacao,
                idPessoa: idPessoa,
              ),
          withReferenceMapper:
              (p0) =>
                  p0
                      .map(
                        (e) => (
                          e.readTable(table),
                          BaseReferences(db, table, e),
                        ),
                      )
                      .toList(),
          prefetchHooksCallback: null,
        ),
      );
}

typedef $$ViewPessoaTransportadorasTableProcessedTableManager =
    ProcessedTableManager<
      _$AppDatabase,
      $ViewPessoaTransportadorasTable,
      ViewPessoaTransportadora,
      $$ViewPessoaTransportadorasTableFilterComposer,
      $$ViewPessoaTransportadorasTableOrderingComposer,
      $$ViewPessoaTransportadorasTableAnnotationComposer,
      $$ViewPessoaTransportadorasTableCreateCompanionBuilder,
      $$ViewPessoaTransportadorasTableUpdateCompanionBuilder,
      (
        ViewPessoaTransportadora,
        BaseReferences<
          _$AppDatabase,
          $ViewPessoaTransportadorasTable,
          ViewPessoaTransportadora
        >,
      ),
      ViewPessoaTransportadora,
      PrefetchHooks Function()
    >;

class $AppDatabaseManager {
  final _$AppDatabase _db;
  $AppDatabaseManager(this._db);
  $$GedDocumentoDetalhesTableTableManager get gedDocumentoDetalhes =>
      $$GedDocumentoDetalhesTableTableManager(_db, _db.gedDocumentoDetalhes);
  $$GedDocumentoCabecalhosTableTableManager get gedDocumentoCabecalhos =>
      $$GedDocumentoCabecalhosTableTableManager(
        _db,
        _db.gedDocumentoCabecalhos,
      );
  $$GedTipoDocumentosTableTableManager get gedTipoDocumentos =>
      $$GedTipoDocumentosTableTableManager(_db, _db.gedTipoDocumentos);
  $$GedVersaoDocumentosTableTableManager get gedVersaoDocumentos =>
      $$GedVersaoDocumentosTableTableManager(_db, _db.gedVersaoDocumentos);
  $$ViewControleAcessosTableTableManager get viewControleAcessos =>
      $$ViewControleAcessosTableTableManager(_db, _db.viewControleAcessos);
  $$ViewPessoaUsuariosTableTableManager get viewPessoaUsuarios =>
      $$ViewPessoaUsuariosTableTableManager(_db, _db.viewPessoaUsuarios);
  $$ViewPessoaColaboradorsTableTableManager get viewPessoaColaboradors =>
      $$ViewPessoaColaboradorsTableTableManager(
        _db,
        _db.viewPessoaColaboradors,
      );
  $$ViewPessoaVendedorsTableTableManager get viewPessoaVendedors =>
      $$ViewPessoaVendedorsTableTableManager(_db, _db.viewPessoaVendedors);
  $$ViewPessoaTransportadorasTableTableManager get viewPessoaTransportadoras =>
      $$ViewPessoaTransportadorasTableTableManager(
        _db,
        _db.viewPessoaTransportadoras,
      );
}
