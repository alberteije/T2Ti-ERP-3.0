// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'ged_documento_cabecalho_dao.dart';

// ignore_for_file: type=lint
mixin _$GedDocumentoCabecalhoDaoMixin on DatabaseAccessor<AppDatabase> {
  $GedDocumentoCabecalhosTable get gedDocumentoCabecalhos =>
      attachedDatabase.gedDocumentoCabecalhos;
  $GedDocumentoDetalhesTable get gedDocumentoDetalhes =>
      attachedDatabase.gedDocumentoDetalhes;
  $GedTipoDocumentosTable get gedTipoDocumentos =>
      attachedDatabase.gedTipoDocumentos;
}
