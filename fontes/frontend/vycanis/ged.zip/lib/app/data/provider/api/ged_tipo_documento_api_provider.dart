import 'package:ged/app/data/provider/api/api_provider_base.dart';
import 'package:ged/app/data/model/model_imports.dart';

class GedTipoDocumentoApiProvider extends ApiProviderBase {
  static const _path = '/ged-tipo-documento';

  Future<List<GedTipoDocumentoModel>?> getList({Filter? filter}) {
    return super.getListBase(
      '$_path/',
      (json) => GedTipoDocumentoModel.fromJson(json),
      filter: filter,
    );
  }

  Future<GedTipoDocumentoModel?> getObject(dynamic pk) {
    return super.getObjectBase(
      _path,
      pk,
      (json) => GedTipoDocumentoModel.fromJson(json),
    );
  }

  Future<GedTipoDocumentoModel?>? insert(GedTipoDocumentoModel model) {
    return super.insertBase(
      _path,
      model,
      (json) => GedTipoDocumentoModel.fromJson(json),
    );
  }

  Future<GedTipoDocumentoModel?>? update(GedTipoDocumentoModel model) {
    return super.updateBase(
      _path,
      model,
      (json) => GedTipoDocumentoModel.fromJson(json),
    );
  }

  Future<bool?> delete(dynamic pk) {
    return super.deleteBase(_path, pk);
  }
}
