// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'ged_tipo_documento_dao.dart';

// ignore_for_file: type=lint
mixin _$GedTipoDocumentoDaoMixin on DatabaseAccessor<AppDatabase> {
  $GedTipoDocumentosTable get gedTipoDocumentos =>
      attachedDatabase.gedTipoDocumentos;
}
