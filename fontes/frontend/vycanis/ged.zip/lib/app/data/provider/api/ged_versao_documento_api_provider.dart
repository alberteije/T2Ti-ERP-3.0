import 'package:ged/app/data/provider/api/api_provider_base.dart';
import 'package:ged/app/data/model/model_imports.dart';

class GedVersaoDocumentoApiProvider extends ApiProviderBase {
  static const _path = '/ged-versao-documento';

  Future<List<GedVersaoDocumentoModel>?> getList({Filter? filter}) {
    return super.getListBase(
      '$_path/',
      (json) => GedVersaoDocumentoModel.fromJson(json),
      filter: filter,
    );
  }

  Future<GedVersaoDocumentoModel?> getObject(dynamic pk) {
    return super.getObjectBase(
      _path,
      pk,
      (json) => GedVersaoDocumentoModel.fromJson(json),
    );
  }

  Future<GedVersaoDocumentoModel?>? insert(GedVersaoDocumentoModel model) {
    return super.insertBase(
      _path,
      model,
      (json) => GedVersaoDocumentoModel.fromJson(json),
    );
  }

  Future<GedVersaoDocumentoModel?>? update(GedVersaoDocumentoModel model) {
    return super.updateBase(
      _path,
      model,
      (json) => GedVersaoDocumentoModel.fromJson(json),
    );
  }

  Future<bool?> delete(dynamic pk) {
    return super.deleteBase(_path, pk);
  }
}
