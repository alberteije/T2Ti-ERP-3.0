import 'package:ged/app/data/provider/api/api_provider_base.dart';
import 'package:ged/app/data/model/model_imports.dart';

class ViewPessoaVendedorApiProvider extends ApiProviderBase {
  static const _path = '/view-pessoa-vendedor';

  Future<List<ViewPessoaVendedorModel>?> getList({Filter? filter}) {
    return super.getListBase(
      '$_path/',
      (json) => ViewPessoaVendedorModel.fromJson(json),
      filter: filter,
    );
  }

  Future<ViewPessoaVendedorModel?> getObject(dynamic pk) {
    return super.getObjectBase(
      _path,
      pk,
      (json) => ViewPessoaVendedorModel.fromJson(json),
    );
  }

  Future<ViewPessoaVendedorModel?>? insert(ViewPessoaVendedorModel model) {
    return super.insertBase(
      _path,
      model,
      (json) => ViewPessoaVendedorModel.fromJson(json),
    );
  }

  Future<ViewPessoaVendedorModel?>? update(ViewPessoaVendedorModel model) {
    return super.updateBase(
      _path,
      model,
      (json) => ViewPessoaVendedorModel.fromJson(json),
    );
  }

  Future<bool?> delete(dynamic pk) {
    return super.deleteBase(_path, pk);
  }
}
