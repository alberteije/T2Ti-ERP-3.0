import 'dart:convert';
import 'package:pluto_grid/pluto_grid.dart';
import 'package:ged/app/data/model/model_imports.dart';

import 'package:ged/app/infra/infra_imports.dart';
import 'package:intl/intl.dart';

class GedDocumentoCabecalhoModel extends ModelBase {
  int? id;
  String? nome;
  DateTime? dataInclusao;
  String? descricao;
  List<GedDocumentoDetalheModel>? gedDocumentoDetalheModelList;

  GedDocumentoCabecalhoModel({
    this.id,
    this.nome,
    this.dataInclusao,
    this.descricao,
    List<GedDocumentoDetalheModel>? gedDocumentoDetalheModelList,
  }) {
    this.gedDocumentoDetalheModelList = gedDocumentoDetalheModelList?.toList(growable: true) ?? [];
  }

  static List<String> dbColumns = <String>[
    'id',
    'nome',
    'data_inclusao',
    'descricao',
  ];

  static List<String> aliasColumns = <String>[
    'Id',
    'Nome',
    'Data Inclusao',
    'Descricao',
  ];

  GedDocumentoCabecalhoModel.fromJson(Map<String, dynamic> jsonData) {
    id = jsonData['id'];
    nome = jsonData['nome'];
    dataInclusao = jsonData['dataInclusao'] != null ? DateTime.tryParse(jsonData['dataInclusao']) : null;
    descricao = jsonData['descricao'];
    gedDocumentoDetalheModelList = (jsonData['gedDocumentoDetalheModelList'] as Iterable?)?.map((m) => GedDocumentoDetalheModel.fromJson(m)).toList() ?? [];
  }

  Map<String, dynamic> get toJson {
    Map<String, dynamic> jsonData = <String, dynamic>{};

    jsonData['id'] = id != 0 ? id : null;
    jsonData['nome'] = nome;
    jsonData['dataInclusao'] = dataInclusao != null ? DateFormat('yyyy-MM-ddT00:00:00').format(dataInclusao!) : null;
    jsonData['descricao'] = descricao;
    
		var gedDocumentoDetalheModelLocalList = []; 
		for (GedDocumentoDetalheModel object in gedDocumentoDetalheModelList ?? []) { 
			gedDocumentoDetalheModelLocalList.add(object.toJson); 
		}
		jsonData['gedDocumentoDetalheModelList'] = gedDocumentoDetalheModelLocalList;

    return jsonData;
  }

  String objectEncodeJson() {
    final jsonData = toJson;
    return json.encode(jsonData);
  }

  static GedDocumentoCabecalhoModel fromPlutoRow(PlutoRow row) {
    return GedDocumentoCabecalhoModel(
      id: row.cells['id']?.value,
      nome: row.cells['nome']?.value,
      dataInclusao: Util.stringToDate(row.cells['dataInclusao']?.value),
      descricao: row.cells['descricao']?.value,
    );
  }

  PlutoRow toPlutoRow() {
    return PlutoRow(
      cells: {
        'tempId': PlutoCell(value: tempId),
        'id': PlutoCell(value: id ?? 0),
        'nome': PlutoCell(value: nome ?? ''),
        'dataInclusao': PlutoCell(value: dataInclusao),
        'descricao': PlutoCell(value: descricao ?? ''),
      },
    );
  }

  GedDocumentoCabecalhoModel clone() {
    return GedDocumentoCabecalhoModel(
      id: id,
      nome: nome,
      dataInclusao: dataInclusao,
      descricao: descricao,
      gedDocumentoDetalheModelList: gedDocumentoDetalheModelListClone(gedDocumentoDetalheModelList!),
    );
  }

  gedDocumentoDetalheModelListClone(List<GedDocumentoDetalheModel> gedDocumentoDetalheModelList) { 
		List<GedDocumentoDetalheModel> resultList = [];
		for (var gedDocumentoDetalheModel in gedDocumentoDetalheModelList) {
			resultList.add(gedDocumentoDetalheModel.clone());
		}
		return resultList;
	}


}