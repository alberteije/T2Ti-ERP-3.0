import 'dart:convert';
import 'package:pluto_grid/pluto_grid.dart';
import 'package:ged/app/data/model/model_imports.dart';

import 'package:ged/app/infra/infra_imports.dart';
import 'package:intl/intl.dart';
import 'package:ged/app/data/domain/domain_imports.dart';

class GedVersaoDocumentoModel extends ModelBase {
  int? id;
  int? idGedDocumentoDetalhe;
  int? idColaborador;
  String? acao;
  int? versao;
  DateTime? dataVersao;
  String? horaVersao;
  String? hashArquivo;
  String? caminho;
  ViewPessoaColaboradorModel? viewPessoaColaboradorModel;

  GedVersaoDocumentoModel({
    this.id,
    this.idGedDocumentoDetalhe,
    this.idColaborador,
    this.acao = 'Incluído',
    this.versao,
    this.dataVersao,
    this.horaVersao,
    this.hashArquivo,
    this.caminho,
    GedDocumentoDetalheModel? gedDocumentoDetalheModel,
    ViewPessoaColaboradorModel? viewPessoaColaboradorModel,
  }) {
    this.viewPessoaColaboradorModel = viewPessoaColaboradorModel ?? ViewPessoaColaboradorModel();
  }

  static List<String> dbColumns = <String>[
    'id',
    'acao',
    'versao',
    'data_versao',
    'hora_versao',
    'hash_arquivo',
    'caminho',
  ];

  static List<String> aliasColumns = <String>[
    'Id',
    'Acao',
    'Versao',
    'Data Versao',
    'Hora Versao',
    'Hash Arquivo',
    'Caminho',
  ];

  GedVersaoDocumentoModel.fromJson(Map<String, dynamic> jsonData) {
    id = jsonData['id'];
    idGedDocumentoDetalhe = jsonData['idGedDocumentoDetalhe'];
    idColaborador = jsonData['idColaborador'];
    acao = GedVersaoDocumentoDomain.getAcao(jsonData['acao']);
    versao = jsonData['versao'];
    dataVersao = jsonData['dataVersao'] != null ? DateTime.tryParse(jsonData['dataVersao']) : null;
    horaVersao = jsonData['horaVersao'];
    hashArquivo = jsonData['hashArquivo'];
    caminho = jsonData['caminho'];
    viewPessoaColaboradorModel = jsonData['viewPessoaColaboradorModel'] == null ? ViewPessoaColaboradorModel() : ViewPessoaColaboradorModel.fromJson(jsonData['viewPessoaColaboradorModel']);
  }

  Map<String, dynamic> get toJson {
    Map<String, dynamic> jsonData = <String, dynamic>{};

    jsonData['id'] = id != 0 ? id : null;
    jsonData['idGedDocumentoDetalhe'] = idGedDocumentoDetalhe != 0 ? idGedDocumentoDetalhe : null;
    jsonData['idColaborador'] = idColaborador != 0 ? idColaborador : null;
    jsonData['acao'] = GedVersaoDocumentoDomain.setAcao(acao);
    jsonData['versao'] = versao;
    jsonData['dataVersao'] = dataVersao != null ? DateFormat('yyyy-MM-ddT00:00:00').format(dataVersao!) : null;
    jsonData['horaVersao'] = Util.removeMask(horaVersao);
    jsonData['hashArquivo'] = hashArquivo;
    jsonData['caminho'] = caminho;
    jsonData['viewPessoaColaboradorModel'] = viewPessoaColaboradorModel?.toJson;
    jsonData['viewPessoaColaborador'] = viewPessoaColaboradorModel?.nome ?? '';

    return jsonData;
  }

  String objectEncodeJson() {
    final jsonData = toJson;
    return json.encode(jsonData);
  }

  static GedVersaoDocumentoModel fromPlutoRow(PlutoRow row) {
    return GedVersaoDocumentoModel(
      id: row.cells['id']?.value,
      idGedDocumentoDetalhe: row.cells['idGedDocumentoDetalhe']?.value,
      idColaborador: row.cells['idColaborador']?.value,
      acao: row.cells['acao']?.value,
      versao: row.cells['versao']?.value,
      dataVersao: Util.stringToDate(row.cells['dataVersao']?.value),
      horaVersao: row.cells['horaVersao']?.value,
      hashArquivo: row.cells['hashArquivo']?.value,
      caminho: row.cells['caminho']?.value,
    );
  }

  PlutoRow toPlutoRow() {
    return PlutoRow(
      cells: {
        'tempId': PlutoCell(value: tempId),
        'id': PlutoCell(value: id ?? 0),
        'idGedDocumentoDetalhe': PlutoCell(value: idGedDocumentoDetalhe ?? 0),
        'idColaborador': PlutoCell(value: idColaborador ?? 0),
        'acao': PlutoCell(value: acao ?? ''),
        'versao': PlutoCell(value: versao ?? 0),
        'dataVersao': PlutoCell(value: dataVersao),
        'horaVersao': PlutoCell(value: horaVersao ?? ''),
        'hashArquivo': PlutoCell(value: hashArquivo ?? ''),
        'caminho': PlutoCell(value: caminho ?? ''),
        'viewPessoaColaborador': PlutoCell(value: viewPessoaColaboradorModel?.nome ?? ''),
      },
    );
  }

  GedVersaoDocumentoModel clone() {
    return GedVersaoDocumentoModel(
      id: id,
      idGedDocumentoDetalhe: idGedDocumentoDetalhe,
      idColaborador: idColaborador,
      acao: acao,
      versao: versao,
      dataVersao: dataVersao,
      horaVersao: horaVersao,
      hashArquivo: hashArquivo,
      caminho: caminho,
      viewPessoaColaboradorModel: viewPessoaColaboradorModel?.clone(),
    );
  }


}