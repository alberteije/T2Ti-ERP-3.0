import 'dart:convert';
import 'package:pluto_grid/pluto_grid.dart';
import 'package:ged/app/data/model/model_imports.dart';

import 'package:ged/app/infra/infra_imports.dart';
import 'package:intl/intl.dart';
import 'package:ged/app/data/domain/domain_imports.dart';

class GedDocumentoDetalheModel extends ModelBase {
  int? id;
  int? idGedDocumentoCabecalho;
  int? idGedTipoDocumento;
  String? nome;
  String? descricao;
  String? palavrasChave;
  String? podeExcluir;
  String? podeAlterar;
  String? assinado;
  DateTime? dataFimVigencia;
  DateTime? dataExclusao;
  GedTipoDocumentoModel? gedTipoDocumentoModel;
	List<GedVersaoDocumentoModel>? gedVersaoDocumentoModelList;

  GedDocumentoDetalheModel({
    this.id,
    this.idGedDocumentoCabecalho,
    this.idGedTipoDocumento,
    this.nome,
    this.descricao,
    this.palavrasChave,
    this.podeExcluir = 'S',
    this.podeAlterar = 'S',
    this.assinado = 'S',
    this.dataFimVigencia,
    this.dataExclusao,
    GedTipoDocumentoModel? gedTipoDocumentoModel,
    List<GedVersaoDocumentoModel>? gedVersaoDocumentoModelList,
  }) {
    this.gedTipoDocumentoModel = gedTipoDocumentoModel ?? GedTipoDocumentoModel();
    this.gedVersaoDocumentoModelList = gedVersaoDocumentoModelList?.toList(growable: true) ?? [];
  }

  static List<String> dbColumns = <String>[
    'id',
    'nome',
    'descricao',
    'palavras_chave',
    'pode_excluir',
    'pode_alterar',
    'assinado',
    'data_fim_vigencia',
    'data_exclusao',
  ];

  static List<String> aliasColumns = <String>[
    'Id',
    'Nome',
    'Descricao',
    'Palavras Chave',
    'Pode Excluir',
    'Pode Alterar',
    'Assinado',
    'Data Fim Vigencia',
    'Data Exclusao',
  ];

  GedDocumentoDetalheModel.fromJson(Map<String, dynamic> jsonData) {
    id = jsonData['id'];
    idGedDocumentoCabecalho = jsonData['idGedDocumentoCabecalho'];
    idGedTipoDocumento = jsonData['idGedTipoDocumento'];
    nome = jsonData['nome'];
    descricao = jsonData['descricao'];
    palavrasChave = jsonData['palavrasChave'];
    podeExcluir = GedDocumentoDetalheDomain.getPodeExcluir(jsonData['podeExcluir']);
    podeAlterar = GedDocumentoDetalheDomain.getPodeAlterar(jsonData['podeAlterar']);
    assinado = GedDocumentoDetalheDomain.getAssinado(jsonData['assinado']);
    dataFimVigencia = jsonData['dataFimVigencia'] != null ? DateTime.tryParse(jsonData['dataFimVigencia']) : null;
    dataExclusao = jsonData['dataExclusao'] != null ? DateTime.tryParse(jsonData['dataExclusao']) : null;
    gedTipoDocumentoModel = jsonData['gedTipoDocumentoModel'] == null ? GedTipoDocumentoModel() : GedTipoDocumentoModel.fromJson(jsonData['gedTipoDocumentoModel']);
		gedVersaoDocumentoModelList = (jsonData['gedVersaoDocumentoModelList'] as Iterable?)?.map((m) => GedVersaoDocumentoModel.fromJson(m)).toList() ?? [];
  }

  Map<String, dynamic> get toJson {
    Map<String, dynamic> jsonData = <String, dynamic>{};

    jsonData['id'] = id != 0 ? id : null;
    jsonData['idGedDocumentoCabecalho'] = idGedDocumentoCabecalho != 0 ? idGedDocumentoCabecalho : null;
    jsonData['idGedTipoDocumento'] = idGedTipoDocumento != 0 ? idGedTipoDocumento : null;
    jsonData['nome'] = nome;
    jsonData['descricao'] = descricao;
    jsonData['palavrasChave'] = palavrasChave;
    jsonData['podeExcluir'] = GedDocumentoDetalheDomain.setPodeExcluir(podeExcluir);
    jsonData['podeAlterar'] = GedDocumentoDetalheDomain.setPodeAlterar(podeAlterar);
    jsonData['assinado'] = GedDocumentoDetalheDomain.setAssinado(assinado);
    jsonData['dataFimVigencia'] = dataFimVigencia != null ? DateFormat('yyyy-MM-ddT00:00:00').format(dataFimVigencia!) : null;
    jsonData['dataExclusao'] = dataExclusao != null ? DateFormat('yyyy-MM-ddT00:00:00').format(dataExclusao!) : null;
    jsonData['gedTipoDocumentoModel'] = gedTipoDocumentoModel?.toJson;
    jsonData['gedTipoDocumento'] = gedTipoDocumentoModel?.nome ?? '';

		var gedDocumentoDetalheModelLocalList = [];
		for (GedVersaoDocumentoModel object in gedVersaoDocumentoModelList ?? []) {
			gedDocumentoDetalheModelLocalList.add(object.toJson);
		}
		jsonData['gedVersaoDocumentoModelList'] = gedDocumentoDetalheModelLocalList;

    return jsonData;
  }

  String objectEncodeJson() {
    final jsonData = toJson;
    return json.encode(jsonData);
  }

  static GedDocumentoDetalheModel fromPlutoRow(PlutoRow row) {
    return GedDocumentoDetalheModel(
      id: row.cells['id']?.value,
      idGedDocumentoCabecalho: row.cells['idGedDocumentoCabecalho']?.value,
      idGedTipoDocumento: row.cells['idGedTipoDocumento']?.value,
      nome: row.cells['nome']?.value,
      descricao: row.cells['descricao']?.value,
      palavrasChave: row.cells['palavrasChave']?.value,
      podeExcluir: row.cells['podeExcluir']?.value,
      podeAlterar: row.cells['podeAlterar']?.value,
      assinado: row.cells['assinado']?.value,
      dataFimVigencia: Util.stringToDate(row.cells['dataFimVigencia']?.value),
      dataExclusao: Util.stringToDate(row.cells['dataExclusao']?.value),
    );
  }

  PlutoRow toPlutoRow() {
    return PlutoRow(
      cells: {
        'tempId': PlutoCell(value: tempId),
        'id': PlutoCell(value: id ?? 0),
        'idGedDocumentoCabecalho': PlutoCell(value: idGedDocumentoCabecalho ?? 0),
        'idGedTipoDocumento': PlutoCell(value: idGedTipoDocumento ?? 0),
        'nome': PlutoCell(value: nome ?? ''),
        'descricao': PlutoCell(value: descricao ?? ''),
        'palavrasChave': PlutoCell(value: palavrasChave ?? ''),
        'podeExcluir': PlutoCell(value: podeExcluir ?? ''),
        'podeAlterar': PlutoCell(value: podeAlterar ?? ''),
        'assinado': PlutoCell(value: assinado ?? ''),
        'dataFimVigencia': PlutoCell(value: dataFimVigencia),
        'dataExclusao': PlutoCell(value: dataExclusao),
        'gedTipoDocumento': PlutoCell(value: gedTipoDocumentoModel?.nome ?? ''),
      },
    );
  }

  GedDocumentoDetalheModel clone() {
    return GedDocumentoDetalheModel(
      id: id,
      idGedDocumentoCabecalho: idGedDocumentoCabecalho,
      idGedTipoDocumento: idGedTipoDocumento,
      nome: nome,
      descricao: descricao,
      palavrasChave: palavrasChave,
      podeExcluir: podeExcluir,
      podeAlterar: podeAlterar,
      assinado: assinado,
      dataFimVigencia: dataFimVigencia,
      dataExclusao: dataExclusao,
      gedTipoDocumentoModel: gedTipoDocumentoModel?.clone(),
      gedVersaoDocumentoModelList: gedVersaoDocumentoModelListClone(gedVersaoDocumentoModelList!),
    );
  }

  gedVersaoDocumentoModelListClone(List<GedVersaoDocumentoModel> gedVersaoDocumentoModelList) { 
		List<GedVersaoDocumentoModel> resultList = [];
		for (var gedVersaoDocumentoModel in gedVersaoDocumentoModelList) {
			resultList.add(gedVersaoDocumentoModel.clone());
		}
		return resultList;
	}
}