class ViewPessoaTransportadoraDomain {
  ViewPessoaTransportadoraDomain._();

  static getTipo(String? tipo) { 
		switch (tipo) { 
			case '': 
			case '0': 
				return 'AAA'; 
			case '1': 
				return 'BBB'; 
			case '2': 
				return 'CCC'; 
			default: 
				return null; 
		} 
	} 

  static setTipo(String? tipo) { 
		switch (tipo) { 
			case 'AAA': 
				return '0'; 
			case 'BBB': 
				return '1'; 
			case 'CCC': 
				return '2'; 
			default: 
				return null; 
		} 
	}


  static final tipoListDropdown = ['AAA','BBB','CCC'];

}