import 'dart:convert';
import 'package:pluto_grid/pluto_grid.dart';
import 'package:vendas/app/data/model/model_imports.dart';


class FinDocumentoOrigemModel extends ModelBase {
  int? id;
  String? codigo;
  String? sigla;
  String? descricao;

  FinDocumentoOrigemModel({
    this.id,
    this.codigo,
    this.sigla,
    this.descricao,
  });

  static List<String> dbColumns = <String>[
    'id',
    'codigo',
    'sigla',
    'descricao',
  ];

  static List<String> aliasColumns = <String>[
    'Id',
    'Codigo',
    'Sigla',
    'Descricao',
  ];

  FinDocumentoOrigemModel.fromJson(Map<String, dynamic> jsonData) {
    id = jsonData['id'];
    codigo = jsonData['codigo'];
    sigla = jsonData['sigla'];
    descricao = jsonData['descricao'];
  }

  Map<String, dynamic> get toJson {
    Map<String, dynamic> jsonData = <String, dynamic>{};

    jsonData['id'] = id != 0 ? id : null;
    jsonData['codigo'] = codigo;
    jsonData['sigla'] = sigla;
    jsonData['descricao'] = descricao;

    return jsonData;
  }

  String objectEncodeJson() {
    final jsonData = toJson;
    return json.encode(jsonData);
  }

  static FinDocumentoOrigemModel fromPlutoRow(PlutoRow row) {
    return FinDocumentoOrigemModel(
      id: row.cells['id']?.value,
      codigo: row.cells['codigo']?.value,
      sigla: row.cells['sigla']?.value,
      descricao: row.cells['descricao']?.value,
    );
  }

  PlutoRow toPlutoRow() {
    return PlutoRow(
      cells: {
        'tempId': PlutoCell(value: tempId),
        'id': PlutoCell(value: id ?? 0),
        'codigo': PlutoCell(value: codigo ?? ''),
        'sigla': PlutoCell(value: sigla ?? ''),
        'descricao': PlutoCell(value: descricao ?? ''),
      },
    );
  }

  FinDocumentoOrigemModel clone() {
    return FinDocumentoOrigemModel(
      id: id,
      codigo: codigo,
      sigla: sigla,
      descricao: descricao,
    );
  }

  static FinDocumentoOrigemModel cloneFrom(FinDocumentoOrigemModel? model) {
    return FinDocumentoOrigemModel(
      id: model?.id,
      codigo: model?.codigo,
      sigla: model?.sigla,
      descricao: model?.descricao,
    );
  }


}