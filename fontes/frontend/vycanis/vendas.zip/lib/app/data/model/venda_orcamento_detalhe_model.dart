import 'dart:convert';
import 'package:pluto_grid/pluto_grid.dart';
import 'package:vendas/app/data/model/model_imports.dart';


class VendaOrcamentoDetalheModel extends ModelBase {
  int? id;
  int? idVendaOrcamentoCabecalho;
  int? idProduto;
  double? quantidade;
  double? valorUnitario;
  double? valorSubtotal;
  double? taxaDesconto;
  double? valorDesconto;
  double? valorTotal;
  ProdutoModel? produtoModel;

  VendaOrcamentoDetalheModel({
    this.id,
    this.idVendaOrcamentoCabecalho,
    this.idProduto,
    this.quantidade,
    this.valorUnitario,
    this.valorSubtotal,
    this.taxaDesconto,
    this.valorDesconto,
    this.valorTotal,
    ProdutoModel? produtoModel,
  }) {
    this.produtoModel = produtoModel ?? ProdutoModel();
  }

  static List<String> dbColumns = <String>[
    'id',
    'quantidade',
    'valor_unitario',
    'valor_subtotal',
    'taxa_desconto',
    'valor_desconto',
    'valor_total',
  ];

  static List<String> aliasColumns = <String>[
    'Id',
    'Quantidade',
    'Valor Unitario',
    'Valor Subtotal',
    'Taxa Desconto',
    'Valor Desconto',
    'Valor Total',
  ];

  VendaOrcamentoDetalheModel.fromJson(Map<String, dynamic> jsonData) {
    id = jsonData['id'];
    idVendaOrcamentoCabecalho = jsonData['idVendaOrcamentoCabecalho'];
    idProduto = jsonData['idProduto'];
    quantidade = jsonData['quantidade']?.toDouble();
    valorUnitario = jsonData['valorUnitario']?.toDouble();
    valorSubtotal = jsonData['valorSubtotal']?.toDouble();
    taxaDesconto = jsonData['taxaDesconto']?.toDouble();
    valorDesconto = jsonData['valorDesconto']?.toDouble();
    valorTotal = jsonData['valorTotal']?.toDouble();
    produtoModel = jsonData['produtoModel'] == null ? ProdutoModel() : ProdutoModel.fromJson(jsonData['produtoModel']);
  }

  Map<String, dynamic> get toJson {
    Map<String, dynamic> jsonData = <String, dynamic>{};

    jsonData['id'] = id != 0 ? id : null;
    jsonData['idVendaOrcamentoCabecalho'] = idVendaOrcamentoCabecalho != 0 ? idVendaOrcamentoCabecalho : null;
    jsonData['idProduto'] = idProduto != 0 ? idProduto : null;
    jsonData['quantidade'] = quantidade;
    jsonData['valorUnitario'] = valorUnitario;
    jsonData['valorSubtotal'] = valorSubtotal;
    jsonData['taxaDesconto'] = taxaDesconto;
    jsonData['valorDesconto'] = valorDesconto;
    jsonData['valorTotal'] = valorTotal;
    jsonData['produtoModel'] = produtoModel?.toJson;
    jsonData['produto'] = produtoModel?.nome ?? '';

    return jsonData;
  }

  String objectEncodeJson() {
    final jsonData = toJson;
    return json.encode(jsonData);
  }

  static VendaOrcamentoDetalheModel fromPlutoRow(PlutoRow row) {
    return VendaOrcamentoDetalheModel(
      id: row.cells['id']?.value,
      idVendaOrcamentoCabecalho: row.cells['idVendaOrcamentoCabecalho']?.value,
      idProduto: row.cells['idProduto']?.value,
      quantidade: row.cells['quantidade']?.value,
      valorUnitario: row.cells['valorUnitario']?.value,
      valorSubtotal: row.cells['valorSubtotal']?.value,
      taxaDesconto: row.cells['taxaDesconto']?.value,
      valorDesconto: row.cells['valorDesconto']?.value,
      valorTotal: row.cells['valorTotal']?.value,
    );
  }

  PlutoRow toPlutoRow() {
    return PlutoRow(
      cells: {
        'tempId': PlutoCell(value: tempId),
        'id': PlutoCell(value: id ?? 0),
        'idVendaOrcamentoCabecalho': PlutoCell(value: idVendaOrcamentoCabecalho ?? 0),
        'idProduto': PlutoCell(value: idProduto ?? 0),
        'quantidade': PlutoCell(value: quantidade ?? 0.0),
        'valorUnitario': PlutoCell(value: valorUnitario ?? 0.0),
        'valorSubtotal': PlutoCell(value: valorSubtotal ?? 0.0),
        'taxaDesconto': PlutoCell(value: taxaDesconto ?? 0.0),
        'valorDesconto': PlutoCell(value: valorDesconto ?? 0.0),
        'valorTotal': PlutoCell(value: valorTotal ?? 0.0),
        'produto': PlutoCell(value: produtoModel?.nome ?? ''),
      },
    );
  }

  VendaOrcamentoDetalheModel clone() {
    return VendaOrcamentoDetalheModel(
      id: id,
      idVendaOrcamentoCabecalho: idVendaOrcamentoCabecalho,
      idProduto: idProduto,
      quantidade: quantidade,
      valorUnitario: valorUnitario,
      valorSubtotal: valorSubtotal,
      taxaDesconto: taxaDesconto,
      valorDesconto: valorDesconto,
      valorTotal: valorTotal,
      produtoModel: ProdutoModel.cloneFrom(produtoModel),
    );
  }

  static VendaOrcamentoDetalheModel cloneFrom(VendaOrcamentoDetalheModel? model) {
    return VendaOrcamentoDetalheModel(
      id: model?.id,
      idVendaOrcamentoCabecalho: model?.idVendaOrcamentoCabecalho,
      idProduto: model?.idProduto,
      quantidade: model?.quantidade,
      valorUnitario: model?.valorUnitario,
      valorSubtotal: model?.valorSubtotal,
      taxaDesconto: model?.taxaDesconto,
      valorDesconto: model?.valorDesconto,
      valorTotal: model?.valorTotal,
      produtoModel: ProdutoModel.cloneFrom(model?.produtoModel),
    );
  }


}