import 'dart:convert';
import 'package:pluto_grid/pluto_grid.dart';
import 'package:vendas/app/data/model/model_imports.dart';

import 'package:vendas/app/infra/infra_imports.dart';
import 'package:intl/intl.dart';

class FinLancamentoReceberModel extends ModelBase {
  int? id;
  int? idCliente;
  int? idBancoContaCaixa;
  int? idFinDocumentoOrigem;
  int? idFinNaturezaFinanceira;
  int? quantidadeParcela;
  double? valorAReceber;
  DateTime? dataLancamento;
  String? numeroDocumento;
  DateTime? primeiroVencimento;
  double? taxaComissao;
  double? valorComissao;
  int? intervaloEntreParcelas;
  String? diaFixo;
  List<FinParcelaReceberModel>? finParcelaReceberModelList;
  FinDocumentoOrigemModel? finDocumentoOrigemModel;
  BancoContaCaixaModel? bancoContaCaixaModel;
  FinNaturezaFinanceiraModel? finNaturezaFinanceiraModel;
  ViewPessoaClienteModel? viewPessoaClienteModel;

  FinLancamentoReceberModel({
    this.id,
    this.idCliente,
    this.idBancoContaCaixa,
    this.idFinDocumentoOrigem,
    this.idFinNaturezaFinanceira,
    this.quantidadeParcela,
    this.valorAReceber,
    this.dataLancamento,
    this.numeroDocumento,
    this.primeiroVencimento,
    this.taxaComissao,
    this.valorComissao,
    this.intervaloEntreParcelas,
    this.diaFixo,
    List<FinParcelaReceberModel>? finParcelaReceberModelList,
    FinDocumentoOrigemModel? finDocumentoOrigemModel,
    BancoContaCaixaModel? bancoContaCaixaModel,
    FinNaturezaFinanceiraModel? finNaturezaFinanceiraModel,
    ViewPessoaClienteModel? viewPessoaClienteModel,
  }) {
    this.finParcelaReceberModelList = finParcelaReceberModelList?.toList(growable: true) ?? [];
    this.finDocumentoOrigemModel = finDocumentoOrigemModel ?? FinDocumentoOrigemModel();
    this.bancoContaCaixaModel = bancoContaCaixaModel ?? BancoContaCaixaModel();
    this.finNaturezaFinanceiraModel = finNaturezaFinanceiraModel ?? FinNaturezaFinanceiraModel();
    this.viewPessoaClienteModel = viewPessoaClienteModel ?? ViewPessoaClienteModel();
  }

  static List<String> dbColumns = <String>[
    'id',
    'quantidade_parcela',
    'valor_a_receber',
    'data_lancamento',
    'numero_documento',
    'primeiro_vencimento',
    'taxa_comissao',
    'valor_comissao',
    'intervalo_entre_parcelas',
    'dia_fixo',
  ];

  static List<String> aliasColumns = <String>[
    'Id',
    'Quantidade Parcela',
    'Valor A Receber',
    'Data Lancamento',
    'Numero Documento',
    'Primeiro Vencimento',
    'Taxa Comissao',
    'Valor Comissao',
    'Intervalo Entre Parcelas',
    'Dia Fixo',
  ];

  FinLancamentoReceberModel.fromJson(Map<String, dynamic> jsonData) {
    id = jsonData['id'];
    idCliente = jsonData['idCliente'];
    idBancoContaCaixa = jsonData['idBancoContaCaixa'];
    idFinDocumentoOrigem = jsonData['idFinDocumentoOrigem'];
    idFinNaturezaFinanceira = jsonData['idFinNaturezaFinanceira'];
    quantidadeParcela = jsonData['quantidadeParcela'];
    valorAReceber = jsonData['valorAReceber']?.toDouble();
    dataLancamento = jsonData['dataLancamento'] != null ? DateTime.tryParse(jsonData['dataLancamento']) : null;
    numeroDocumento = jsonData['numeroDocumento'];
    primeiroVencimento = jsonData['primeiroVencimento'] != null ? DateTime.tryParse(jsonData['primeiroVencimento']) : null;
    taxaComissao = jsonData['taxaComissao']?.toDouble();
    valorComissao = jsonData['valorComissao']?.toDouble();
    intervaloEntreParcelas = jsonData['intervaloEntreParcelas'];
    diaFixo = jsonData['diaFixo'];
    finParcelaReceberModelList = (jsonData['finParcelaReceberModelList'] as Iterable?)?.map((m) => FinParcelaReceberModel.fromJson(m)).toList() ?? [];
    finDocumentoOrigemModel = jsonData['finDocumentoOrigemModel'] == null ? FinDocumentoOrigemModel() : FinDocumentoOrigemModel.fromJson(jsonData['finDocumentoOrigemModel']);
    bancoContaCaixaModel = jsonData['bancoContaCaixaModel'] == null ? BancoContaCaixaModel() : BancoContaCaixaModel.fromJson(jsonData['bancoContaCaixaModel']);
    finNaturezaFinanceiraModel = jsonData['finNaturezaFinanceiraModel'] == null ? FinNaturezaFinanceiraModel() : FinNaturezaFinanceiraModel.fromJson(jsonData['finNaturezaFinanceiraModel']);
    viewPessoaClienteModel = jsonData['viewPessoaClienteModel'] == null ? ViewPessoaClienteModel() : ViewPessoaClienteModel.fromJson(jsonData['viewPessoaClienteModel']);
  }

  Map<String, dynamic> get toJson {
    Map<String, dynamic> jsonData = <String, dynamic>{};

    jsonData['id'] = id != 0 ? id : null;
    jsonData['idCliente'] = idCliente != 0 ? idCliente : null;
    jsonData['idBancoContaCaixa'] = idBancoContaCaixa != 0 ? idBancoContaCaixa : null;
    jsonData['idFinDocumentoOrigem'] = idFinDocumentoOrigem != 0 ? idFinDocumentoOrigem : null;
    jsonData['idFinNaturezaFinanceira'] = idFinNaturezaFinanceira != 0 ? idFinNaturezaFinanceira : null;
    jsonData['quantidadeParcela'] = quantidadeParcela;
    jsonData['valorAReceber'] = valorAReceber;
    jsonData['dataLancamento'] = dataLancamento != null ? DateFormat('yyyy-MM-ddT00:00:00').format(dataLancamento!) : null;
    jsonData['numeroDocumento'] = numeroDocumento;
    jsonData['primeiroVencimento'] = primeiroVencimento != null ? DateFormat('yyyy-MM-ddT00:00:00').format(primeiroVencimento!) : null;
    jsonData['taxaComissao'] = taxaComissao;
    jsonData['valorComissao'] = valorComissao;
    jsonData['intervaloEntreParcelas'] = intervaloEntreParcelas;
    jsonData['diaFixo'] = diaFixo;
    
		var finParcelaReceberModelLocalList = []; 
		for (FinParcelaReceberModel object in finParcelaReceberModelList ?? []) { 
			finParcelaReceberModelLocalList.add(object.toJson); 
		}
		jsonData['finParcelaReceberModelList'] = finParcelaReceberModelLocalList;
    jsonData['finDocumentoOrigemModel'] = finDocumentoOrigemModel?.toJson;
    jsonData['finDocumentoOrigem'] = finDocumentoOrigemModel?.sigla ?? '';
    jsonData['bancoContaCaixaModel'] = bancoContaCaixaModel?.toJson;
    jsonData['bancoContaCaixa'] = bancoContaCaixaModel?.nome ?? '';
    jsonData['finNaturezaFinanceiraModel'] = finNaturezaFinanceiraModel?.toJson;
    jsonData['finNaturezaFinanceira'] = finNaturezaFinanceiraModel?.descricao ?? '';
    jsonData['viewPessoaClienteModel'] = viewPessoaClienteModel?.toJson;
    jsonData['viewPessoaCliente'] = viewPessoaClienteModel?.nome ?? '';

    return jsonData;
  }

  String objectEncodeJson() {
    final jsonData = toJson;
    return json.encode(jsonData);
  }

  static FinLancamentoReceberModel fromPlutoRow(PlutoRow row) {
    return FinLancamentoReceberModel(
      id: row.cells['id']?.value,
      idCliente: row.cells['idCliente']?.value,
      idBancoContaCaixa: row.cells['idBancoContaCaixa']?.value,
      idFinDocumentoOrigem: row.cells['idFinDocumentoOrigem']?.value,
      idFinNaturezaFinanceira: row.cells['idFinNaturezaFinanceira']?.value,
      quantidadeParcela: row.cells['quantidadeParcela']?.value,
      valorAReceber: row.cells['valorAReceber']?.value,
      dataLancamento: Util.stringToDate(row.cells['dataLancamento']?.value),
      numeroDocumento: row.cells['numeroDocumento']?.value,
      primeiroVencimento: Util.stringToDate(row.cells['primeiroVencimento']?.value),
      taxaComissao: row.cells['taxaComissao']?.value,
      valorComissao: row.cells['valorComissao']?.value,
      intervaloEntreParcelas: row.cells['intervaloEntreParcelas']?.value,
      diaFixo: row.cells['diaFixo']?.value,
    );
  }

  PlutoRow toPlutoRow() {
    return PlutoRow(
      cells: {
        'tempId': PlutoCell(value: tempId),
        'id': PlutoCell(value: id ?? 0),
        'idCliente': PlutoCell(value: idCliente ?? 0),
        'idBancoContaCaixa': PlutoCell(value: idBancoContaCaixa ?? 0),
        'idFinDocumentoOrigem': PlutoCell(value: idFinDocumentoOrigem ?? 0),
        'idFinNaturezaFinanceira': PlutoCell(value: idFinNaturezaFinanceira ?? 0),
        'quantidadeParcela': PlutoCell(value: quantidadeParcela ?? 0),
        'valorAReceber': PlutoCell(value: valorAReceber ?? 0.0),
        'dataLancamento': PlutoCell(value: dataLancamento),
        'numeroDocumento': PlutoCell(value: numeroDocumento ?? ''),
        'primeiroVencimento': PlutoCell(value: primeiroVencimento),
        'taxaComissao': PlutoCell(value: taxaComissao ?? 0.0),
        'valorComissao': PlutoCell(value: valorComissao ?? 0.0),
        'intervaloEntreParcelas': PlutoCell(value: intervaloEntreParcelas ?? 0),
        'diaFixo': PlutoCell(value: diaFixo ?? ''),
        'finDocumentoOrigem': PlutoCell(value: finDocumentoOrigemModel?.sigla ?? ''),
        'bancoContaCaixa': PlutoCell(value: bancoContaCaixaModel?.nome ?? ''),
        'finNaturezaFinanceira': PlutoCell(value: finNaturezaFinanceiraModel?.descricao ?? ''),
        'viewPessoaCliente': PlutoCell(value: viewPessoaClienteModel?.nome ?? ''),
      },
    );
  }

  FinLancamentoReceberModel clone() {
    return FinLancamentoReceberModel(
      id: id,
      idCliente: idCliente,
      idBancoContaCaixa: idBancoContaCaixa,
      idFinDocumentoOrigem: idFinDocumentoOrigem,
      idFinNaturezaFinanceira: idFinNaturezaFinanceira,
      quantidadeParcela: quantidadeParcela,
      valorAReceber: valorAReceber,
      dataLancamento: dataLancamento,
      numeroDocumento: numeroDocumento,
      primeiroVencimento: primeiroVencimento,
      taxaComissao: taxaComissao,
      valorComissao: valorComissao,
      intervaloEntreParcelas: intervaloEntreParcelas,
      diaFixo: diaFixo,
      finParcelaReceberModelList: finParcelaReceberModelListClone(finParcelaReceberModelList!),
      finDocumentoOrigemModel: FinDocumentoOrigemModel.cloneFrom(finDocumentoOrigemModel),
      bancoContaCaixaModel: BancoContaCaixaModel.cloneFrom(bancoContaCaixaModel),
      finNaturezaFinanceiraModel: FinNaturezaFinanceiraModel.cloneFrom(finNaturezaFinanceiraModel),
      viewPessoaClienteModel: ViewPessoaClienteModel.cloneFrom(viewPessoaClienteModel),
    );
  }

  static FinLancamentoReceberModel cloneFrom(FinLancamentoReceberModel? model) {
    return FinLancamentoReceberModel(
      id: model?.id,
      idCliente: model?.idCliente,
      idBancoContaCaixa: model?.idBancoContaCaixa,
      idFinDocumentoOrigem: model?.idFinDocumentoOrigem,
      idFinNaturezaFinanceira: model?.idFinNaturezaFinanceira,
      quantidadeParcela: model?.quantidadeParcela,
      valorAReceber: model?.valorAReceber,
      dataLancamento: model?.dataLancamento,
      numeroDocumento: model?.numeroDocumento,
      primeiroVencimento: model?.primeiroVencimento,
      taxaComissao: model?.taxaComissao,
      valorComissao: model?.valorComissao,
      intervaloEntreParcelas: model?.intervaloEntreParcelas,
      diaFixo: model?.diaFixo,
      finDocumentoOrigemModel: FinDocumentoOrigemModel.cloneFrom(model?.finDocumentoOrigemModel),
      bancoContaCaixaModel: BancoContaCaixaModel.cloneFrom(model?.bancoContaCaixaModel),
      finNaturezaFinanceiraModel: FinNaturezaFinanceiraModel.cloneFrom(model?.finNaturezaFinanceiraModel),
      viewPessoaClienteModel: ViewPessoaClienteModel.cloneFrom(model?.viewPessoaClienteModel),
    );
  }

  finParcelaReceberModelListClone(List<FinParcelaReceberModel> finParcelaReceberModelList) { 
		List<FinParcelaReceberModel> resultList = [];
		for (var finParcelaReceberModel in finParcelaReceberModelList) {
			resultList.add(FinParcelaReceberModel.cloneFrom(finParcelaReceberModel));
		}
		return resultList;
	}


}