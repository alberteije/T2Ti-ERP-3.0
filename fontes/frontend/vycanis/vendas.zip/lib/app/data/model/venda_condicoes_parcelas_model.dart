import 'dart:convert';
import 'package:pluto_grid/pluto_grid.dart';
import 'package:vendas/app/data/model/model_imports.dart';


class VendaCondicoesParcelasModel extends ModelBase {
  int? id;
  int? idVendaCondicoesPagamento;
  int? parcela;
  int? dias;
  double? taxa;

  VendaCondicoesParcelasModel({
    this.id,
    this.idVendaCondicoesPagamento,
    this.parcela,
    this.dias,
    this.taxa,
  });

  static List<String> dbColumns = <String>[
    'id',
    'parcela',
    'dias',
    'taxa',
  ];

  static List<String> aliasColumns = <String>[
    'Id',
    'Parcela',
    'Dias',
    'Taxa',
  ];

  VendaCondicoesParcelasModel.fromJson(Map<String, dynamic> jsonData) {
    id = jsonData['id'];
    idVendaCondicoesPagamento = jsonData['idVendaCondicoesPagamento'];
    parcela = jsonData['parcela'];
    dias = jsonData['dias'];
    taxa = jsonData['taxa']?.toDouble();
  }

  Map<String, dynamic> get toJson {
    Map<String, dynamic> jsonData = <String, dynamic>{};

    jsonData['id'] = id != 0 ? id : null;
    jsonData['idVendaCondicoesPagamento'] = idVendaCondicoesPagamento != 0 ? idVendaCondicoesPagamento : null;
    jsonData['parcela'] = parcela;
    jsonData['dias'] = dias;
    jsonData['taxa'] = taxa;

    return jsonData;
  }

  String objectEncodeJson() {
    final jsonData = toJson;
    return json.encode(jsonData);
  }

  static VendaCondicoesParcelasModel fromPlutoRow(PlutoRow row) {
    return VendaCondicoesParcelasModel(
      id: row.cells['id']?.value,
      idVendaCondicoesPagamento: row.cells['idVendaCondicoesPagamento']?.value,
      parcela: row.cells['parcela']?.value,
      dias: row.cells['dias']?.value,
      taxa: row.cells['taxa']?.value,
    );
  }

  PlutoRow toPlutoRow() {
    return PlutoRow(
      cells: {
        'tempId': PlutoCell(value: tempId),
        'id': PlutoCell(value: id ?? 0),
        'idVendaCondicoesPagamento': PlutoCell(value: idVendaCondicoesPagamento ?? 0),
        'parcela': PlutoCell(value: parcela ?? 0),
        'dias': PlutoCell(value: dias ?? 0),
        'taxa': PlutoCell(value: taxa ?? 0.0),
      },
    );
  }

  VendaCondicoesParcelasModel clone() {
    return VendaCondicoesParcelasModel(
      id: id,
      idVendaCondicoesPagamento: idVendaCondicoesPagamento,
      parcela: parcela,
      dias: dias,
      taxa: taxa,
    );
  }

  static VendaCondicoesParcelasModel cloneFrom(VendaCondicoesParcelasModel? model) {
    return VendaCondicoesParcelasModel(
      id: model?.id,
      idVendaCondicoesPagamento: model?.idVendaCondicoesPagamento,
      parcela: model?.parcela,
      dias: model?.dias,
      taxa: model?.taxa,
    );
  }


}