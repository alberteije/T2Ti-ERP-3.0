import 'dart:convert';
import 'package:pluto_grid/pluto_grid.dart';
import 'package:vendas/app/data/model/model_imports.dart';

import 'package:vendas/app/data/domain/domain_imports.dart';

class VendaCondicoesPagamentoModel extends ModelBase {
  int? id;
  String? nome;
  String? descricao;
  double? faturamentoMinimo;
  double? faturamentoMaximo;
  double? indiceCorrecao;
  int? diasTolerancia;
  double? valorTolerancia;
  int? prazoMedio;
  String? vistaPrazo;
  List<VendaCondicoesParcelasModel>? vendaCondicoesParcelasModelList;

  VendaCondicoesPagamentoModel({
    this.id,
    this.nome,
    this.descricao,
    this.faturamentoMinimo,
    this.faturamentoMaximo,
    this.indiceCorrecao,
    this.diasTolerancia,
    this.valorTolerancia,
    this.prazoMedio,
    this.vistaPrazo = 'A Vista',
    List<VendaCondicoesParcelasModel>? vendaCondicoesParcelasModelList,
  }) {
    this.vendaCondicoesParcelasModelList = vendaCondicoesParcelasModelList?.toList(growable: true) ?? [];
  }

  static List<String> dbColumns = <String>[
    'id',
    'nome',
    'descricao',
    'faturamento_minimo',
    'faturamento_maximo',
    'indice_correcao',
    'dias_tolerancia',
    'valor_tolerancia',
    'prazo_medio',
    'vista_prazo',
  ];

  static List<String> aliasColumns = <String>[
    'Id',
    'Nome',
    'Descricao',
    'Faturamento Minimo',
    'Faturamento Maximo',
    'Indice Correcao',
    'Dias Tolerancia',
    'Valor Tolerancia',
    'Prazo Medio',
    'Vista Prazo',
  ];

  VendaCondicoesPagamentoModel.fromJson(Map<String, dynamic> jsonData) {
    id = jsonData['id'];
    nome = jsonData['nome'];
    descricao = jsonData['descricao'];
    faturamentoMinimo = jsonData['faturamentoMinimo']?.toDouble();
    faturamentoMaximo = jsonData['faturamentoMaximo']?.toDouble();
    indiceCorrecao = jsonData['indiceCorrecao']?.toDouble();
    diasTolerancia = jsonData['diasTolerancia'];
    valorTolerancia = jsonData['valorTolerancia']?.toDouble();
    prazoMedio = jsonData['prazoMedio'];
    vistaPrazo = VendaCondicoesPagamentoDomain.getVistaPrazo(jsonData['vistaPrazo']);
    vendaCondicoesParcelasModelList = (jsonData['vendaCondicoesParcelasModelList'] as Iterable?)?.map((m) => VendaCondicoesParcelasModel.fromJson(m)).toList() ?? [];
  }

  Map<String, dynamic> get toJson {
    Map<String, dynamic> jsonData = <String, dynamic>{};

    jsonData['id'] = id != 0 ? id : null;
    jsonData['nome'] = nome;
    jsonData['descricao'] = descricao;
    jsonData['faturamentoMinimo'] = faturamentoMinimo;
    jsonData['faturamentoMaximo'] = faturamentoMaximo;
    jsonData['indiceCorrecao'] = indiceCorrecao;
    jsonData['diasTolerancia'] = diasTolerancia;
    jsonData['valorTolerancia'] = valorTolerancia;
    jsonData['prazoMedio'] = prazoMedio;
    jsonData['vistaPrazo'] = VendaCondicoesPagamentoDomain.setVistaPrazo(vistaPrazo);
    
		var vendaCondicoesParcelasModelLocalList = []; 
		for (VendaCondicoesParcelasModel object in vendaCondicoesParcelasModelList ?? []) { 
			vendaCondicoesParcelasModelLocalList.add(object.toJson); 
		}
		jsonData['vendaCondicoesParcelasModelList'] = vendaCondicoesParcelasModelLocalList;

    return jsonData;
  }

  String objectEncodeJson() {
    final jsonData = toJson;
    return json.encode(jsonData);
  }

  static VendaCondicoesPagamentoModel fromPlutoRow(PlutoRow row) {
    return VendaCondicoesPagamentoModel(
      id: row.cells['id']?.value,
      nome: row.cells['nome']?.value,
      descricao: row.cells['descricao']?.value,
      faturamentoMinimo: row.cells['faturamentoMinimo']?.value,
      faturamentoMaximo: row.cells['faturamentoMaximo']?.value,
      indiceCorrecao: row.cells['indiceCorrecao']?.value,
      diasTolerancia: row.cells['diasTolerancia']?.value,
      valorTolerancia: row.cells['valorTolerancia']?.value,
      prazoMedio: row.cells['prazoMedio']?.value,
      vistaPrazo: row.cells['vistaPrazo']?.value,
    );
  }

  PlutoRow toPlutoRow() {
    return PlutoRow(
      cells: {
        'tempId': PlutoCell(value: tempId),
        'id': PlutoCell(value: id ?? 0),
        'nome': PlutoCell(value: nome ?? ''),
        'descricao': PlutoCell(value: descricao ?? ''),
        'faturamentoMinimo': PlutoCell(value: faturamentoMinimo ?? 0.0),
        'faturamentoMaximo': PlutoCell(value: faturamentoMaximo ?? 0.0),
        'indiceCorrecao': PlutoCell(value: indiceCorrecao ?? 0.0),
        'diasTolerancia': PlutoCell(value: diasTolerancia ?? 0),
        'valorTolerancia': PlutoCell(value: valorTolerancia ?? 0.0),
        'prazoMedio': PlutoCell(value: prazoMedio ?? 0),
        'vistaPrazo': PlutoCell(value: vistaPrazo ?? ''),
      },
    );
  }

  VendaCondicoesPagamentoModel clone() {
    return VendaCondicoesPagamentoModel(
      id: id,
      nome: nome,
      descricao: descricao,
      faturamentoMinimo: faturamentoMinimo,
      faturamentoMaximo: faturamentoMaximo,
      indiceCorrecao: indiceCorrecao,
      diasTolerancia: diasTolerancia,
      valorTolerancia: valorTolerancia,
      prazoMedio: prazoMedio,
      vistaPrazo: vistaPrazo,
      vendaCondicoesParcelasModelList: vendaCondicoesParcelasModelListClone(vendaCondicoesParcelasModelList!),
    );
  }

  static VendaCondicoesPagamentoModel cloneFrom(VendaCondicoesPagamentoModel? model) {
    return VendaCondicoesPagamentoModel(
      id: model?.id,
      nome: model?.nome,
      descricao: model?.descricao,
      faturamentoMinimo: model?.faturamentoMinimo,
      faturamentoMaximo: model?.faturamentoMaximo,
      indiceCorrecao: model?.indiceCorrecao,
      diasTolerancia: model?.diasTolerancia,
      valorTolerancia: model?.valorTolerancia,
      prazoMedio: model?.prazoMedio,
      vistaPrazo: model?.vistaPrazo,
      vendaCondicoesParcelasModelList: model?.vendaCondicoesParcelasModelListClone(model.vendaCondicoesParcelasModelList!),
    );
  }

  vendaCondicoesParcelasModelListClone(List<VendaCondicoesParcelasModel> vendaCondicoesParcelasModelList) { 
		List<VendaCondicoesParcelasModel> resultList = [];
		for (var vendaCondicoesParcelasModel in vendaCondicoesParcelasModelList) {
			resultList.add(VendaCondicoesParcelasModel.cloneFrom(vendaCondicoesParcelasModel));
		}
		return resultList;
	}


}