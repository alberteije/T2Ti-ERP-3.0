import 'dart:convert';
import 'package:pluto_grid/pluto_grid.dart';
import 'package:vendas/app/data/model/model_imports.dart';

import 'package:vendas/app/data/domain/domain_imports.dart';

class VendaFreteModel extends ModelBase {
  int? id;
  int? idVendaCabecalho;
  int? idTransportadora;
  String? responsavel;
  int? conhecimento;
  String? placa;
  String? ufPlaca;
  int? seloFiscal;
  double? quantidadeVolume;
  String? marcaVolume;
  String? especieVolume;
  double? pesoBruto;
  double? pesoLiquido;
  ViewPessoaTransportadoraModel? viewPessoaTransportadoraModel;

  VendaFreteModel({
    this.id,
    this.idVendaCabecalho,
    this.idTransportadora,
    this.responsavel = '1-Emitente',
    this.conhecimento,
    this.placa,
    this.ufPlaca = 'AC',
    this.seloFiscal,
    this.quantidadeVolume,
    this.marcaVolume,
    this.especieVolume,
    this.pesoBruto,
    this.pesoLiquido,
    ViewPessoaTransportadoraModel? viewPessoaTransportadoraModel,
  }) {
    this.viewPessoaTransportadoraModel = viewPessoaTransportadoraModel ?? ViewPessoaTransportadoraModel();
  }

  static List<String> dbColumns = <String>[
    'id',
    'responsavel',
    'conhecimento',
    'placa',
    'uf_placa',
    'selo_fiscal',
    'quantidade_volume',
    'marca_volume',
    'especie_volume',
    'peso_bruto',
    'peso_liquido',
  ];

  static List<String> aliasColumns = <String>[
    'Id',
    'Responsavel',
    'Conhecimento',
    'Placa',
    'Uf Placa',
    'Selo Fiscal',
    'Quantidade Volume',
    'Marca Volume',
    'Especie Volume',
    'Peso Bruto',
    'Peso Liquido',
  ];

  VendaFreteModel.fromJson(Map<String, dynamic> jsonData) {
    id = jsonData['id'];
    idVendaCabecalho = jsonData['idVendaCabecalho'];
    idTransportadora = jsonData['idTransportadora'];
    responsavel = VendaFreteDomain.getResponsavel(jsonData['responsavel']);
    conhecimento = jsonData['conhecimento'];
    placa = jsonData['placa'];
    ufPlaca = VendaFreteDomain.getUfPlaca(jsonData['ufPlaca']);
    seloFiscal = jsonData['seloFiscal'];
    quantidadeVolume = jsonData['quantidadeVolume']?.toDouble();
    marcaVolume = jsonData['marcaVolume'];
    especieVolume = jsonData['especieVolume'];
    pesoBruto = jsonData['pesoBruto']?.toDouble();
    pesoLiquido = jsonData['pesoLiquido']?.toDouble();
    viewPessoaTransportadoraModel = jsonData['viewPessoaTransportadoraModel'] == null ? ViewPessoaTransportadoraModel() : ViewPessoaTransportadoraModel.fromJson(jsonData['viewPessoaTransportadoraModel']);
  }

  Map<String, dynamic> get toJson {
    Map<String, dynamic> jsonData = <String, dynamic>{};

    jsonData['id'] = id != 0 ? id : null;
    jsonData['idVendaCabecalho'] = idVendaCabecalho != 0 ? idVendaCabecalho : null;
    jsonData['idTransportadora'] = idTransportadora != 0 ? idTransportadora : null;
    jsonData['responsavel'] = VendaFreteDomain.setResponsavel(responsavel);
    jsonData['conhecimento'] = conhecimento;
    jsonData['placa'] = placa;
    jsonData['ufPlaca'] = VendaFreteDomain.setUfPlaca(ufPlaca);
    jsonData['seloFiscal'] = seloFiscal;
    jsonData['quantidadeVolume'] = quantidadeVolume;
    jsonData['marcaVolume'] = marcaVolume;
    jsonData['especieVolume'] = especieVolume;
    jsonData['pesoBruto'] = pesoBruto;
    jsonData['pesoLiquido'] = pesoLiquido;
    jsonData['viewPessoaTransportadoraModel'] = viewPessoaTransportadoraModel?.toJson;
    jsonData['viewPessoaTransportadora'] = viewPessoaTransportadoraModel?.nome ?? '';

    return jsonData;
  }

  String objectEncodeJson() {
    final jsonData = toJson;
    return json.encode(jsonData);
  }

  static VendaFreteModel fromPlutoRow(PlutoRow row) {
    return VendaFreteModel(
      id: row.cells['id']?.value,
      idVendaCabecalho: row.cells['idVendaCabecalho']?.value,
      idTransportadora: row.cells['idTransportadora']?.value,
      responsavel: row.cells['responsavel']?.value,
      conhecimento: row.cells['conhecimento']?.value,
      placa: row.cells['placa']?.value,
      ufPlaca: row.cells['ufPlaca']?.value,
      seloFiscal: row.cells['seloFiscal']?.value,
      quantidadeVolume: row.cells['quantidadeVolume']?.value,
      marcaVolume: row.cells['marcaVolume']?.value,
      especieVolume: row.cells['especieVolume']?.value,
      pesoBruto: row.cells['pesoBruto']?.value,
      pesoLiquido: row.cells['pesoLiquido']?.value,
    );
  }

  PlutoRow toPlutoRow() {
    return PlutoRow(
      cells: {
        'tempId': PlutoCell(value: tempId),
        'id': PlutoCell(value: id ?? 0),
        'idVendaCabecalho': PlutoCell(value: idVendaCabecalho ?? 0),
        'idTransportadora': PlutoCell(value: idTransportadora ?? 0),
        'responsavel': PlutoCell(value: responsavel ?? ''),
        'conhecimento': PlutoCell(value: conhecimento ?? 0),
        'placa': PlutoCell(value: placa ?? ''),
        'ufPlaca': PlutoCell(value: ufPlaca ?? ''),
        'seloFiscal': PlutoCell(value: seloFiscal ?? 0),
        'quantidadeVolume': PlutoCell(value: quantidadeVolume ?? 0.0),
        'marcaVolume': PlutoCell(value: marcaVolume ?? ''),
        'especieVolume': PlutoCell(value: especieVolume ?? ''),
        'pesoBruto': PlutoCell(value: pesoBruto ?? 0.0),
        'pesoLiquido': PlutoCell(value: pesoLiquido ?? 0.0),
        'viewPessoaTransportadora': PlutoCell(value: viewPessoaTransportadoraModel?.nome ?? ''),
      },
    );
  }

  VendaFreteModel clone() {
    return VendaFreteModel(
      id: id,
      idVendaCabecalho: idVendaCabecalho,
      idTransportadora: idTransportadora,
      responsavel: responsavel,
      conhecimento: conhecimento,
      placa: placa,
      ufPlaca: ufPlaca,
      seloFiscal: seloFiscal,
      quantidadeVolume: quantidadeVolume,
      marcaVolume: marcaVolume,
      especieVolume: especieVolume,
      pesoBruto: pesoBruto,
      pesoLiquido: pesoLiquido,
      viewPessoaTransportadoraModel: ViewPessoaTransportadoraModel.cloneFrom(viewPessoaTransportadoraModel),
    );
  }

  static VendaFreteModel cloneFrom(VendaFreteModel? model) {
    return VendaFreteModel(
      id: model?.id,
      idVendaCabecalho: model?.idVendaCabecalho,
      idTransportadora: model?.idTransportadora,
      responsavel: model?.responsavel,
      conhecimento: model?.conhecimento,
      placa: model?.placa,
      ufPlaca: model?.ufPlaca,
      seloFiscal: model?.seloFiscal,
      quantidadeVolume: model?.quantidadeVolume,
      marcaVolume: model?.marcaVolume,
      especieVolume: model?.especieVolume,
      pesoBruto: model?.pesoBruto,
      pesoLiquido: model?.pesoLiquido,
      viewPessoaTransportadoraModel: ViewPessoaTransportadoraModel.cloneFrom(model?.viewPessoaTransportadoraModel),
    );
  }


}