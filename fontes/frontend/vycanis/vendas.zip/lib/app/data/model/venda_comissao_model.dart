import 'dart:convert';
import 'package:pluto_grid/pluto_grid.dart';
import 'package:vendas/app/data/model/model_imports.dart';

import 'package:vendas/app/infra/infra_imports.dart';
import 'package:intl/intl.dart';
import 'package:vendas/app/data/domain/domain_imports.dart';

class VendaComissaoModel extends ModelBase {
  int? id;
  int? idVendaCabecalho;
  int? idVendedor;
  double? valorVenda;
  String? tipoContabil;
  double? valorComissao;
  String? situacao;
  DateTime? dataLancamento;
  ViewPessoaVendedorModel? viewPessoaVendedorModel;

  VendaComissaoModel({
    this.id,
    this.idVendaCabecalho,
    this.idVendedor,
    this.valorVenda,
    this.tipoContabil = 'Crédito',
    this.valorComissao,
    this.situacao = 'Aberto',
    this.dataLancamento,
    ViewPessoaVendedorModel? viewPessoaVendedorModel,
  }) {
    this.viewPessoaVendedorModel = viewPessoaVendedorModel ?? ViewPessoaVendedorModel();
  }

  static List<String> dbColumns = <String>[
    'id',
    'valor_venda',
    'tipo_contabil',
    'valor_comissao',
    'situacao',
    'data_lancamento',
  ];

  static List<String> aliasColumns = <String>[
    'Id',
    'Valor Venda',
    'Tipo Contabil',
    'Valor Comissao',
    'Situacao',
    'Data Lancamento',
  ];

  VendaComissaoModel.fromJson(Map<String, dynamic> jsonData) {
    id = jsonData['id'];
    idVendaCabecalho = jsonData['idVendaCabecalho'];
    idVendedor = jsonData['idVendedor'];
    valorVenda = jsonData['valorVenda']?.toDouble();
    tipoContabil = VendaComissaoDomain.getTipoContabil(jsonData['tipoContabil']);
    valorComissao = jsonData['valorComissao']?.toDouble();
    situacao = VendaComissaoDomain.getSituacao(jsonData['situacao']);
    dataLancamento = jsonData['dataLancamento'] != null ? DateTime.tryParse(jsonData['dataLancamento']) : null;
    viewPessoaVendedorModel = jsonData['viewPessoaVendedorModel'] == null ? ViewPessoaVendedorModel() : ViewPessoaVendedorModel.fromJson(jsonData['viewPessoaVendedorModel']);
  }

  Map<String, dynamic> get toJson {
    Map<String, dynamic> jsonData = <String, dynamic>{};

    jsonData['id'] = id != 0 ? id : null;
    jsonData['idVendaCabecalho'] = idVendaCabecalho != 0 ? idVendaCabecalho : null;
    jsonData['idVendedor'] = idVendedor != 0 ? idVendedor : null;
    jsonData['valorVenda'] = valorVenda;
    jsonData['tipoContabil'] = VendaComissaoDomain.setTipoContabil(tipoContabil);
    jsonData['valorComissao'] = valorComissao;
    jsonData['situacao'] = VendaComissaoDomain.setSituacao(situacao);
    jsonData['dataLancamento'] = dataLancamento != null ? DateFormat('yyyy-MM-ddT00:00:00').format(dataLancamento!) : null;
    jsonData['viewPessoaVendedorModel'] = viewPessoaVendedorModel?.toJson;
    jsonData['viewPessoaVendedor'] = viewPessoaVendedorModel?.nome ?? '';

    return jsonData;
  }

  String objectEncodeJson() {
    final jsonData = toJson;
    return json.encode(jsonData);
  }

  static VendaComissaoModel fromPlutoRow(PlutoRow row) {
    return VendaComissaoModel(
      id: row.cells['id']?.value,
      idVendaCabecalho: row.cells['idVendaCabecalho']?.value,
      idVendedor: row.cells['idVendedor']?.value,
      valorVenda: row.cells['valorVenda']?.value,
      tipoContabil: row.cells['tipoContabil']?.value,
      valorComissao: row.cells['valorComissao']?.value,
      situacao: row.cells['situacao']?.value,
      dataLancamento: Util.stringToDate(row.cells['dataLancamento']?.value),
    );
  }

  PlutoRow toPlutoRow() {
    return PlutoRow(
      cells: {
        'tempId': PlutoCell(value: tempId),
        'id': PlutoCell(value: id ?? 0),
        'idVendaCabecalho': PlutoCell(value: idVendaCabecalho ?? 0),
        'idVendedor': PlutoCell(value: idVendedor ?? 0),
        'valorVenda': PlutoCell(value: valorVenda ?? 0.0),
        'tipoContabil': PlutoCell(value: tipoContabil ?? ''),
        'valorComissao': PlutoCell(value: valorComissao ?? 0.0),
        'situacao': PlutoCell(value: situacao ?? ''),
        'dataLancamento': PlutoCell(value: dataLancamento),
        'viewPessoaVendedor': PlutoCell(value: viewPessoaVendedorModel?.nome ?? ''),
      },
    );
  }

  VendaComissaoModel clone() {
    return VendaComissaoModel(
      id: id,
      idVendaCabecalho: idVendaCabecalho,
      idVendedor: idVendedor,
      valorVenda: valorVenda,
      tipoContabil: tipoContabil,
      valorComissao: valorComissao,
      situacao: situacao,
      dataLancamento: dataLancamento,
      viewPessoaVendedorModel: ViewPessoaVendedorModel.cloneFrom(viewPessoaVendedorModel),
    );
  }

  static VendaComissaoModel cloneFrom(VendaComissaoModel? model) {
    return VendaComissaoModel(
      id: model?.id,
      idVendaCabecalho: model?.idVendaCabecalho,
      idVendedor: model?.idVendedor,
      valorVenda: model?.valorVenda,
      tipoContabil: model?.tipoContabil,
      valorComissao: model?.valorComissao,
      situacao: model?.situacao,
      dataLancamento: model?.dataLancamento,
      viewPessoaVendedorModel: ViewPessoaVendedorModel.cloneFrom(model?.viewPessoaVendedorModel),
    );
  }


}