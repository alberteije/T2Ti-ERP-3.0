import 'dart:convert';
import 'package:pluto_grid/pluto_grid.dart';
import 'package:vendas/app/data/model/model_imports.dart';

import 'package:vendas/app/infra/infra_imports.dart';
import 'package:intl/intl.dart';
import 'package:vendas/app/data/domain/domain_imports.dart';

class VendaOrcamentoCabecalhoModel extends ModelBase {
  int? id;
  int? idVendedor;
  int? idCliente;
  int? idVendaCondicoesPagamento;
  int? idTransportadora;
  String? tipoFrete;
  String? codigo;
  DateTime? dataCadastro;
  DateTime? dataEntrega;
  DateTime? dataValidade;
  double? valorSubtotal;
  double? valorFrete;
  double? taxaComissao;
  double? valorComissao;
  double? taxaDesconto;
  double? valorDesconto;
  double? valorTotal;
  String? observacao;
  List<VendaOrcamentoDetalheModel>? vendaOrcamentoDetalheModelList;
  VendaCondicoesPagamentoModel? vendaCondicoesPagamentoModel;
  ViewPessoaVendedorModel? viewPessoaVendedorModel;
  ViewPessoaTransportadoraModel? viewPessoaTransportadoraModel;
  ViewPessoaClienteModel? viewPessoaClienteModel;

  VendaOrcamentoCabecalhoModel({
    this.id,
    this.idVendedor,
    this.idCliente,
    this.idVendaCondicoesPagamento,
    this.idTransportadora,
    this.tipoFrete = 'CIF',
    this.codigo,
    this.dataCadastro,
    this.dataEntrega,
    this.dataValidade,
    this.valorSubtotal,
    this.valorFrete,
    this.taxaComissao,
    this.valorComissao,
    this.taxaDesconto,
    this.valorDesconto,
    this.valorTotal,
    this.observacao,
    List<VendaOrcamentoDetalheModel>? vendaOrcamentoDetalheModelList,
    VendaCondicoesPagamentoModel? vendaCondicoesPagamentoModel,
    ViewPessoaVendedorModel? viewPessoaVendedorModel,
    ViewPessoaTransportadoraModel? viewPessoaTransportadoraModel,
    ViewPessoaClienteModel? viewPessoaClienteModel,
  }) {
    this.vendaOrcamentoDetalheModelList = vendaOrcamentoDetalheModelList?.toList(growable: true) ?? [];
    this.vendaCondicoesPagamentoModel = vendaCondicoesPagamentoModel ?? VendaCondicoesPagamentoModel();
    this.viewPessoaVendedorModel = viewPessoaVendedorModel ?? ViewPessoaVendedorModel();
    this.viewPessoaTransportadoraModel = viewPessoaTransportadoraModel ?? ViewPessoaTransportadoraModel();
    this.viewPessoaClienteModel = viewPessoaClienteModel ?? ViewPessoaClienteModel();
  }

  static List<String> dbColumns = <String>[
    'id',
    'tipo_frete',
    'codigo',
    'data_cadastro',
    'data_entrega',
    'data_validade',
    'valor_subtotal',
    'valor_frete',
    'taxa_comissao',
    'valor_comissao',
    'taxa_desconto',
    'valor_desconto',
    'valor_total',
    'observacao',
  ];

  static List<String> aliasColumns = <String>[
    'Id',
    'Tipo Frete',
    'Codigo',
    'Data Cadastro',
    'Data Entrega',
    'Data Validade',
    'Valor Subtotal',
    'Valor Frete',
    'Taxa Comissao',
    'Valor Comissao',
    'Taxa Desconto',
    'Valor Desconto',
    'Valor Total',
    'Observacao',
  ];

  VendaOrcamentoCabecalhoModel.fromJson(Map<String, dynamic> jsonData) {
    id = jsonData['id'];
    idVendedor = jsonData['idVendedor'];
    idCliente = jsonData['idCliente'];
    idVendaCondicoesPagamento = jsonData['idVendaCondicoesPagamento'];
    idTransportadora = jsonData['idTransportadora'];
    tipoFrete = VendaOrcamentoCabecalhoDomain.getTipoFrete(jsonData['tipoFrete']);
    codigo = jsonData['codigo'];
    dataCadastro = jsonData['dataCadastro'] != null ? DateTime.tryParse(jsonData['dataCadastro']) : null;
    dataEntrega = jsonData['dataEntrega'] != null ? DateTime.tryParse(jsonData['dataEntrega']) : null;
    dataValidade = jsonData['dataValidade'] != null ? DateTime.tryParse(jsonData['dataValidade']) : null;
    valorSubtotal = jsonData['valorSubtotal']?.toDouble();
    valorFrete = jsonData['valorFrete']?.toDouble();
    taxaComissao = jsonData['taxaComissao']?.toDouble();
    valorComissao = jsonData['valorComissao']?.toDouble();
    taxaDesconto = jsonData['taxaDesconto']?.toDouble();
    valorDesconto = jsonData['valorDesconto']?.toDouble();
    valorTotal = jsonData['valorTotal']?.toDouble();
    observacao = jsonData['observacao'];
    vendaOrcamentoDetalheModelList = (jsonData['vendaOrcamentoDetalheModelList'] as Iterable?)?.map((m) => VendaOrcamentoDetalheModel.fromJson(m)).toList() ?? [];
    vendaCondicoesPagamentoModel = jsonData['vendaCondicoesPagamentoModel'] == null ? VendaCondicoesPagamentoModel() : VendaCondicoesPagamentoModel.fromJson(jsonData['vendaCondicoesPagamentoModel']);
    viewPessoaVendedorModel = jsonData['viewPessoaVendedorModel'] == null ? ViewPessoaVendedorModel() : ViewPessoaVendedorModel.fromJson(jsonData['viewPessoaVendedorModel']);
    viewPessoaTransportadoraModel = jsonData['viewPessoaTransportadoraModel'] == null ? ViewPessoaTransportadoraModel() : ViewPessoaTransportadoraModel.fromJson(jsonData['viewPessoaTransportadoraModel']);
    viewPessoaClienteModel = jsonData['viewPessoaClienteModel'] == null ? ViewPessoaClienteModel() : ViewPessoaClienteModel.fromJson(jsonData['viewPessoaClienteModel']);
  }

  Map<String, dynamic> get toJson {
    Map<String, dynamic> jsonData = <String, dynamic>{};

    jsonData['id'] = id != 0 ? id : null;
    jsonData['idVendedor'] = idVendedor != 0 ? idVendedor : null;
    jsonData['idCliente'] = idCliente != 0 ? idCliente : null;
    jsonData['idVendaCondicoesPagamento'] = idVendaCondicoesPagamento != 0 ? idVendaCondicoesPagamento : null;
    jsonData['idTransportadora'] = idTransportadora != 0 ? idTransportadora : null;
    jsonData['tipoFrete'] = VendaOrcamentoCabecalhoDomain.setTipoFrete(tipoFrete);
    jsonData['codigo'] = codigo;
    jsonData['dataCadastro'] = dataCadastro != null ? DateFormat('yyyy-MM-ddT00:00:00').format(dataCadastro!) : null;
    jsonData['dataEntrega'] = dataEntrega != null ? DateFormat('yyyy-MM-ddT00:00:00').format(dataEntrega!) : null;
    jsonData['dataValidade'] = dataValidade != null ? DateFormat('yyyy-MM-ddT00:00:00').format(dataValidade!) : null;
    jsonData['valorSubtotal'] = valorSubtotal;
    jsonData['valorFrete'] = valorFrete;
    jsonData['taxaComissao'] = taxaComissao;
    jsonData['valorComissao'] = valorComissao;
    jsonData['taxaDesconto'] = taxaDesconto;
    jsonData['valorDesconto'] = valorDesconto;
    jsonData['valorTotal'] = valorTotal;
    jsonData['observacao'] = observacao;
    
		var vendaOrcamentoDetalheModelLocalList = []; 
		for (VendaOrcamentoDetalheModel object in vendaOrcamentoDetalheModelList ?? []) { 
			vendaOrcamentoDetalheModelLocalList.add(object.toJson); 
		}
		jsonData['vendaOrcamentoDetalheModelList'] = vendaOrcamentoDetalheModelLocalList;
    jsonData['vendaCondicoesPagamentoModel'] = vendaCondicoesPagamentoModel?.toJson;
    jsonData['vendaCondicoesPagamento'] = vendaCondicoesPagamentoModel?.nome ?? '';
    jsonData['viewPessoaVendedorModel'] = viewPessoaVendedorModel?.toJson;
    jsonData['viewPessoaVendedor'] = viewPessoaVendedorModel?.nome ?? '';
    jsonData['viewPessoaTransportadoraModel'] = viewPessoaTransportadoraModel?.toJson;
    jsonData['viewPessoaTransportadora'] = viewPessoaTransportadoraModel?.nome ?? '';
    jsonData['viewPessoaClienteModel'] = viewPessoaClienteModel?.toJson;
    jsonData['viewPessoaCliente'] = viewPessoaClienteModel?.nome ?? '';

    return jsonData;
  }

  String objectEncodeJson() {
    final jsonData = toJson;
    return json.encode(jsonData);
  }

  static VendaOrcamentoCabecalhoModel fromPlutoRow(PlutoRow row) {
    return VendaOrcamentoCabecalhoModel(
      id: row.cells['id']?.value,
      idVendedor: row.cells['idVendedor']?.value,
      idCliente: row.cells['idCliente']?.value,
      idVendaCondicoesPagamento: row.cells['idVendaCondicoesPagamento']?.value,
      idTransportadora: row.cells['idTransportadora']?.value,
      tipoFrete: row.cells['tipoFrete']?.value,
      codigo: row.cells['codigo']?.value,
      dataCadastro: Util.stringToDate(row.cells['dataCadastro']?.value),
      dataEntrega: Util.stringToDate(row.cells['dataEntrega']?.value),
      dataValidade: Util.stringToDate(row.cells['dataValidade']?.value),
      valorSubtotal: row.cells['valorSubtotal']?.value,
      valorFrete: row.cells['valorFrete']?.value,
      taxaComissao: row.cells['taxaComissao']?.value,
      valorComissao: row.cells['valorComissao']?.value,
      taxaDesconto: row.cells['taxaDesconto']?.value,
      valorDesconto: row.cells['valorDesconto']?.value,
      valorTotal: row.cells['valorTotal']?.value,
      observacao: row.cells['observacao']?.value,
    );
  }

  PlutoRow toPlutoRow() {
    return PlutoRow(
      cells: {
        'tempId': PlutoCell(value: tempId),
        'id': PlutoCell(value: id ?? 0),
        'idVendedor': PlutoCell(value: idVendedor ?? 0),
        'idCliente': PlutoCell(value: idCliente ?? 0),
        'idVendaCondicoesPagamento': PlutoCell(value: idVendaCondicoesPagamento ?? 0),
        'idTransportadora': PlutoCell(value: idTransportadora ?? 0),
        'tipoFrete': PlutoCell(value: tipoFrete ?? ''),
        'codigo': PlutoCell(value: codigo ?? ''),
        'dataCadastro': PlutoCell(value: dataCadastro),
        'dataEntrega': PlutoCell(value: dataEntrega),
        'dataValidade': PlutoCell(value: dataValidade),
        'valorSubtotal': PlutoCell(value: valorSubtotal ?? 0.0),
        'valorFrete': PlutoCell(value: valorFrete ?? 0.0),
        'taxaComissao': PlutoCell(value: taxaComissao ?? 0.0),
        'valorComissao': PlutoCell(value: valorComissao ?? 0.0),
        'taxaDesconto': PlutoCell(value: taxaDesconto ?? 0.0),
        'valorDesconto': PlutoCell(value: valorDesconto ?? 0.0),
        'valorTotal': PlutoCell(value: valorTotal ?? 0.0),
        'observacao': PlutoCell(value: observacao ?? ''),
        'vendaCondicoesPagamento': PlutoCell(value: vendaCondicoesPagamentoModel?.nome ?? ''),
        'viewPessoaVendedor': PlutoCell(value: viewPessoaVendedorModel?.nome ?? ''),
        'viewPessoaTransportadora': PlutoCell(value: viewPessoaTransportadoraModel?.nome ?? ''),
        'viewPessoaCliente': PlutoCell(value: viewPessoaClienteModel?.nome ?? ''),
      },
    );
  }

  VendaOrcamentoCabecalhoModel clone() {
    return VendaOrcamentoCabecalhoModel(
      id: id,
      idVendedor: idVendedor,
      idCliente: idCliente,
      idVendaCondicoesPagamento: idVendaCondicoesPagamento,
      idTransportadora: idTransportadora,
      tipoFrete: tipoFrete,
      codigo: codigo,
      dataCadastro: dataCadastro,
      dataEntrega: dataEntrega,
      dataValidade: dataValidade,
      valorSubtotal: valorSubtotal,
      valorFrete: valorFrete,
      taxaComissao: taxaComissao,
      valorComissao: valorComissao,
      taxaDesconto: taxaDesconto,
      valorDesconto: valorDesconto,
      valorTotal: valorTotal,
      observacao: observacao,
      vendaOrcamentoDetalheModelList: vendaOrcamentoDetalheModelListClone(vendaOrcamentoDetalheModelList!),
      vendaCondicoesPagamentoModel: VendaCondicoesPagamentoModel.cloneFrom(vendaCondicoesPagamentoModel),
      viewPessoaVendedorModel: ViewPessoaVendedorModel.cloneFrom(viewPessoaVendedorModel),
      viewPessoaTransportadoraModel: ViewPessoaTransportadoraModel.cloneFrom(viewPessoaTransportadoraModel),
      viewPessoaClienteModel: ViewPessoaClienteModel.cloneFrom(viewPessoaClienteModel),
    );
  }

  static VendaOrcamentoCabecalhoModel cloneFrom(VendaOrcamentoCabecalhoModel? model) {
    return VendaOrcamentoCabecalhoModel(
      id: model?.id,
      idVendedor: model?.idVendedor,
      idCliente: model?.idCliente,
      idVendaCondicoesPagamento: model?.idVendaCondicoesPagamento,
      idTransportadora: model?.idTransportadora,
      tipoFrete: model?.tipoFrete,
      codigo: model?.codigo,
      dataCadastro: model?.dataCadastro,
      dataEntrega: model?.dataEntrega,
      dataValidade: model?.dataValidade,
      valorSubtotal: model?.valorSubtotal,
      valorFrete: model?.valorFrete,
      taxaComissao: model?.taxaComissao,
      valorComissao: model?.valorComissao,
      taxaDesconto: model?.taxaDesconto,
      valorDesconto: model?.valorDesconto,
      valorTotal: model?.valorTotal,
      observacao: model?.observacao,
      vendaCondicoesPagamentoModel: VendaCondicoesPagamentoModel.cloneFrom(model?.vendaCondicoesPagamentoModel),
      viewPessoaVendedorModel: ViewPessoaVendedorModel.cloneFrom(model?.viewPessoaVendedorModel),
      viewPessoaTransportadoraModel: ViewPessoaTransportadoraModel.cloneFrom(model?.viewPessoaTransportadoraModel),
      viewPessoaClienteModel: ViewPessoaClienteModel.cloneFrom(model?.viewPessoaClienteModel),
    );
  }

  vendaOrcamentoDetalheModelListClone(List<VendaOrcamentoDetalheModel> vendaOrcamentoDetalheModelList) { 
		List<VendaOrcamentoDetalheModel> resultList = [];
		for (var vendaOrcamentoDetalheModel in vendaOrcamentoDetalheModelList) {
			resultList.add(VendaOrcamentoDetalheModel.cloneFrom(vendaOrcamentoDetalheModel));
		}
		return resultList;
	}


}