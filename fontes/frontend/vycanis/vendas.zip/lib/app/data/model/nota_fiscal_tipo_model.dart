import 'dart:convert';
import 'package:pluto_grid/pluto_grid.dart';
import 'package:vendas/app/data/model/model_imports.dart';


class NotaFiscalTipoModel extends ModelBase {
  int? id;
  int? idNotaFiscalModelo;
  String? nome;
  String? descricao;
  String? serie;
  String? serieScan;
  int? ultimoNumero;
  NotaFiscalModeloModel? notaFiscalModeloModel;

  NotaFiscalTipoModel({
    this.id,
    this.idNotaFiscalModelo,
    this.nome,
    this.descricao,
    this.serie,
    this.serieScan,
    this.ultimoNumero,
    NotaFiscalModeloModel? notaFiscalModeloModel,
  }) {
    this.notaFiscalModeloModel = notaFiscalModeloModel ?? NotaFiscalModeloModel();
  }

  static List<String> dbColumns = <String>[
    'id',
    'nome',
    'descricao',
    'serie',
    'serie_scan',
    'ultimo_numero',
  ];

  static List<String> aliasColumns = <String>[
    'Id',
    'Nome',
    'Descricao',
    'Serie',
    'Serie Scan',
    'Ultimo Numero',
  ];

  NotaFiscalTipoModel.fromJson(Map<String, dynamic> jsonData) {
    id = jsonData['id'];
    idNotaFiscalModelo = jsonData['idNotaFiscalModelo'];
    nome = jsonData['nome'];
    descricao = jsonData['descricao'];
    serie = jsonData['serie'];
    serieScan = jsonData['serieScan'];
    ultimoNumero = jsonData['ultimoNumero'];
    notaFiscalModeloModel = jsonData['notaFiscalModeloModel'] == null ? NotaFiscalModeloModel() : NotaFiscalModeloModel.fromJson(jsonData['notaFiscalModeloModel']);
  }

  Map<String, dynamic> get toJson {
    Map<String, dynamic> jsonData = <String, dynamic>{};

    jsonData['id'] = id != 0 ? id : null;
    jsonData['idNotaFiscalModelo'] = idNotaFiscalModelo != 0 ? idNotaFiscalModelo : null;
    jsonData['nome'] = nome;
    jsonData['descricao'] = descricao;
    jsonData['serie'] = serie;
    jsonData['serieScan'] = serieScan;
    jsonData['ultimoNumero'] = ultimoNumero;
    jsonData['notaFiscalModeloModel'] = notaFiscalModeloModel?.toJson;
    jsonData['notaFiscalModelo'] = notaFiscalModeloModel?.modelo ?? '';

    return jsonData;
  }

  String objectEncodeJson() {
    final jsonData = toJson;
    return json.encode(jsonData);
  }

  static NotaFiscalTipoModel fromPlutoRow(PlutoRow row) {
    return NotaFiscalTipoModel(
      id: row.cells['id']?.value,
      idNotaFiscalModelo: row.cells['idNotaFiscalModelo']?.value,
      nome: row.cells['nome']?.value,
      descricao: row.cells['descricao']?.value,
      serie: row.cells['serie']?.value,
      serieScan: row.cells['serieScan']?.value,
      ultimoNumero: row.cells['ultimoNumero']?.value,
    );
  }

  PlutoRow toPlutoRow() {
    return PlutoRow(
      cells: {
        'tempId': PlutoCell(value: tempId),
        'id': PlutoCell(value: id ?? 0),
        'idNotaFiscalModelo': PlutoCell(value: idNotaFiscalModelo ?? 0),
        'nome': PlutoCell(value: nome ?? ''),
        'descricao': PlutoCell(value: descricao ?? ''),
        'serie': PlutoCell(value: serie ?? ''),
        'serieScan': PlutoCell(value: serieScan ?? ''),
        'ultimoNumero': PlutoCell(value: ultimoNumero ?? 0),
        'notaFiscalModelo': PlutoCell(value: notaFiscalModeloModel?.modelo ?? ''),
      },
    );
  }

  NotaFiscalTipoModel clone() {
    return NotaFiscalTipoModel(
      id: id,
      idNotaFiscalModelo: idNotaFiscalModelo,
      nome: nome,
      descricao: descricao,
      serie: serie,
      serieScan: serieScan,
      ultimoNumero: ultimoNumero,
      notaFiscalModeloModel: NotaFiscalModeloModel.cloneFrom(notaFiscalModeloModel),
    );
  }

  static NotaFiscalTipoModel cloneFrom(NotaFiscalTipoModel? model) {
    return NotaFiscalTipoModel(
      id: model?.id,
      idNotaFiscalModelo: model?.idNotaFiscalModelo,
      nome: model?.nome,
      descricao: model?.descricao,
      serie: model?.serie,
      serieScan: model?.serieScan,
      ultimoNumero: model?.ultimoNumero,
      notaFiscalModeloModel: NotaFiscalModeloModel.cloneFrom(model?.notaFiscalModeloModel),
    );
  }


}