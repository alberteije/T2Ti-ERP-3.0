import 'dart:convert';
import 'package:pluto_grid/pluto_grid.dart';
import 'package:vendas/app/data/model/model_imports.dart';

class FinStatusParcelaModel extends ModelBase {
  int? id;
  String? situacao;
  String? descricao;
  String? procedimento;

  FinStatusParcelaModel({
    this.id,
    this.situacao = '01 = Aberto',
    this.descricao,
    this.procedimento,
  });

  static List<String> dbColumns = <String>[
    'id',
    'situacao',
    'descricao',
    'procedimento',
  ];

  static List<String> aliasColumns = <String>[
    'Id',
    'Situacao',
    'Descricao',
    'Procedimento',
  ];

  FinStatusParcelaModel.fromJson(Map<String, dynamic> jsonData) {
    id = jsonData['id'];
    situacao = jsonData['situacao'];
    descricao = jsonData['descricao'];
    procedimento = jsonData['procedimento'];
  }

  Map<String, dynamic> get toJson {
    Map<String, dynamic> jsonData = <String, dynamic>{};

    jsonData['id'] = id != 0 ? id : null;
    jsonData['situacao'] = situacao;
    jsonData['descricao'] = descricao;
    jsonData['procedimento'] = procedimento;

    return jsonData;
  }

  String objectEncodeJson() {
    final jsonData = toJson;
    return json.encode(jsonData);
  }

  static FinStatusParcelaModel fromPlutoRow(PlutoRow row) {
    return FinStatusParcelaModel(
      id: row.cells['id']?.value,
      situacao: row.cells['situacao']?.value,
      descricao: row.cells['descricao']?.value,
      procedimento: row.cells['procedimento']?.value,
    );
  }

  PlutoRow toPlutoRow() {
    return PlutoRow(
      cells: {
        'tempId': PlutoCell(value: tempId),
        'id': PlutoCell(value: id ?? 0),
        'situacao': PlutoCell(value: situacao ?? ''),
        'descricao': PlutoCell(value: descricao ?? ''),
        'procedimento': PlutoCell(value: procedimento ?? ''),
      },
    );
  }

  FinStatusParcelaModel clone() {
    return FinStatusParcelaModel(
      id: id,
      situacao: situacao,
      descricao: descricao,
      procedimento: procedimento,
    );
  }

  static FinStatusParcelaModel cloneFrom(FinStatusParcelaModel? model) {
    return FinStatusParcelaModel(
      id: model?.id,
      situacao: model?.situacao,
      descricao: model?.descricao,
      procedimento: model?.procedimento,
    );
  }


}