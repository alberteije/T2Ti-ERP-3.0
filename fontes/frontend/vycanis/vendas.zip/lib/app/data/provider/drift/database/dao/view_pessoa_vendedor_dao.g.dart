// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'view_pessoa_vendedor_dao.dart';

// ignore_for_file: type=lint
mixin _$ViewPessoaVendedorDaoMixin on DatabaseAccessor<AppDatabase> {
  $ViewPessoaVendedorsTable get viewPessoaVendedors =>
      attachedDatabase.viewPessoaVendedors;
}
