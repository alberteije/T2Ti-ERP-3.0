// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'venda_orcamento_cabecalho_dao.dart';

// ignore_for_file: type=lint
mixin _$VendaOrcamentoCabecalhoDaoMixin on DatabaseAccessor<AppDatabase> {
  $VendaOrcamentoCabecalhosTable get vendaOrcamentoCabecalhos =>
      attachedDatabase.vendaOrcamentoCabecalhos;
  $VendaOrcamentoDetalhesTable get vendaOrcamentoDetalhes =>
      attachedDatabase.vendaOrcamentoDetalhes;
  $ProdutosTable get produtos => attachedDatabase.produtos;
  $VendaCondicoesPagamentosTable get vendaCondicoesPagamentos =>
      attachedDatabase.vendaCondicoesPagamentos;
  $ViewPessoaVendedorsTable get viewPessoaVendedors =>
      attachedDatabase.viewPessoaVendedors;
  $ViewPessoaTransportadorasTable get viewPessoaTransportadoras =>
      attachedDatabase.viewPessoaTransportadoras;
  $ViewPessoaClientesTable get viewPessoaClientes =>
      attachedDatabase.viewPessoaClientes;
}
