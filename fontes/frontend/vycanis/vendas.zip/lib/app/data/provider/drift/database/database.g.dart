// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'database.dart';

// ignore_for_file: type=lint
class $ProdutosTable extends Produtos with TableInfo<$ProdutosTable, Produto> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $ProdutosTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
      'id', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _idProdutoSubgrupoMeta =
      const VerificationMeta('idProdutoSubgrupo');
  @override
  late final GeneratedColumn<int> idProdutoSubgrupo = GeneratedColumn<int>(
      'id_produto_subgrupo', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _idProdutoMarcaMeta =
      const VerificationMeta('idProdutoMarca');
  @override
  late final GeneratedColumn<int> idProdutoMarca = GeneratedColumn<int>(
      'id_produto_marca', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _idProdutoUnidadeMeta =
      const VerificationMeta('idProdutoUnidade');
  @override
  late final GeneratedColumn<int> idProdutoUnidade = GeneratedColumn<int>(
      'id_produto_unidade', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _idTributIcmsCustomCabMeta =
      const VerificationMeta('idTributIcmsCustomCab');
  @override
  late final GeneratedColumn<int> idTributIcmsCustomCab = GeneratedColumn<int>(
      'id_tribut_icms_custom_cab', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _idTributGrupoTributarioMeta =
      const VerificationMeta('idTributGrupoTributario');
  @override
  late final GeneratedColumn<int> idTributGrupoTributario =
      GeneratedColumn<int>('id_tribut_grupo_tributario', aliasedName, true,
          type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _nomeMeta = const VerificationMeta('nome');
  @override
  late final GeneratedColumn<String> nome = GeneratedColumn<String>(
      'nome', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 100),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _descricaoMeta =
      const VerificationMeta('descricao');
  @override
  late final GeneratedColumn<String> descricao = GeneratedColumn<String>(
      'descricao', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 250),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _gtinMeta = const VerificationMeta('gtin');
  @override
  late final GeneratedColumn<String> gtin = GeneratedColumn<String>(
      'gtin', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 14),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _codigoInternoMeta =
      const VerificationMeta('codigoInterno');
  @override
  late final GeneratedColumn<String> codigoInterno = GeneratedColumn<String>(
      'codigo_interno', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 50),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _valorCompraMeta =
      const VerificationMeta('valorCompra');
  @override
  late final GeneratedColumn<double> valorCompra = GeneratedColumn<double>(
      'valor_compra', aliasedName, true,
      type: DriftSqlType.double, requiredDuringInsert: false);
  static const VerificationMeta _valorVendaMeta =
      const VerificationMeta('valorVenda');
  @override
  late final GeneratedColumn<double> valorVenda = GeneratedColumn<double>(
      'valor_venda', aliasedName, true,
      type: DriftSqlType.double, requiredDuringInsert: false);
  static const VerificationMeta _codigoNcmMeta =
      const VerificationMeta('codigoNcm');
  @override
  late final GeneratedColumn<String> codigoNcm = GeneratedColumn<String>(
      'codigo_ncm', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 8),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _estoqueMinimoMeta =
      const VerificationMeta('estoqueMinimo');
  @override
  late final GeneratedColumn<double> estoqueMinimo = GeneratedColumn<double>(
      'estoque_minimo', aliasedName, true,
      type: DriftSqlType.double, requiredDuringInsert: false);
  static const VerificationMeta _estoqueMaximoMeta =
      const VerificationMeta('estoqueMaximo');
  @override
  late final GeneratedColumn<double> estoqueMaximo = GeneratedColumn<double>(
      'estoque_maximo', aliasedName, true,
      type: DriftSqlType.double, requiredDuringInsert: false);
  static const VerificationMeta _quantidadeEstoqueMeta =
      const VerificationMeta('quantidadeEstoque');
  @override
  late final GeneratedColumn<double> quantidadeEstoque =
      GeneratedColumn<double>('quantidade_estoque', aliasedName, true,
          type: DriftSqlType.double, requiredDuringInsert: false);
  static const VerificationMeta _dataCadastroMeta =
      const VerificationMeta('dataCadastro');
  @override
  late final GeneratedColumn<DateTime> dataCadastro = GeneratedColumn<DateTime>(
      'data_cadastro', aliasedName, true,
      type: DriftSqlType.dateTime, requiredDuringInsert: false);
  @override
  List<GeneratedColumn> get $columns => [
        id,
        idProdutoSubgrupo,
        idProdutoMarca,
        idProdutoUnidade,
        idTributIcmsCustomCab,
        idTributGrupoTributario,
        nome,
        descricao,
        gtin,
        codigoInterno,
        valorCompra,
        valorVenda,
        codigoNcm,
        estoqueMinimo,
        estoqueMaximo,
        quantidadeEstoque,
        dataCadastro
      ];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'produto';
  @override
  VerificationContext validateIntegrity(Insertable<Produto> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('id_produto_subgrupo')) {
      context.handle(
          _idProdutoSubgrupoMeta,
          idProdutoSubgrupo.isAcceptableOrUnknown(
              data['id_produto_subgrupo']!, _idProdutoSubgrupoMeta));
    }
    if (data.containsKey('id_produto_marca')) {
      context.handle(
          _idProdutoMarcaMeta,
          idProdutoMarca.isAcceptableOrUnknown(
              data['id_produto_marca']!, _idProdutoMarcaMeta));
    }
    if (data.containsKey('id_produto_unidade')) {
      context.handle(
          _idProdutoUnidadeMeta,
          idProdutoUnidade.isAcceptableOrUnknown(
              data['id_produto_unidade']!, _idProdutoUnidadeMeta));
    }
    if (data.containsKey('id_tribut_icms_custom_cab')) {
      context.handle(
          _idTributIcmsCustomCabMeta,
          idTributIcmsCustomCab.isAcceptableOrUnknown(
              data['id_tribut_icms_custom_cab']!, _idTributIcmsCustomCabMeta));
    }
    if (data.containsKey('id_tribut_grupo_tributario')) {
      context.handle(
          _idTributGrupoTributarioMeta,
          idTributGrupoTributario.isAcceptableOrUnknown(
              data['id_tribut_grupo_tributario']!,
              _idTributGrupoTributarioMeta));
    }
    if (data.containsKey('nome')) {
      context.handle(
          _nomeMeta, nome.isAcceptableOrUnknown(data['nome']!, _nomeMeta));
    }
    if (data.containsKey('descricao')) {
      context.handle(_descricaoMeta,
          descricao.isAcceptableOrUnknown(data['descricao']!, _descricaoMeta));
    }
    if (data.containsKey('gtin')) {
      context.handle(
          _gtinMeta, gtin.isAcceptableOrUnknown(data['gtin']!, _gtinMeta));
    }
    if (data.containsKey('codigo_interno')) {
      context.handle(
          _codigoInternoMeta,
          codigoInterno.isAcceptableOrUnknown(
              data['codigo_interno']!, _codigoInternoMeta));
    }
    if (data.containsKey('valor_compra')) {
      context.handle(
          _valorCompraMeta,
          valorCompra.isAcceptableOrUnknown(
              data['valor_compra']!, _valorCompraMeta));
    }
    if (data.containsKey('valor_venda')) {
      context.handle(
          _valorVendaMeta,
          valorVenda.isAcceptableOrUnknown(
              data['valor_venda']!, _valorVendaMeta));
    }
    if (data.containsKey('codigo_ncm')) {
      context.handle(_codigoNcmMeta,
          codigoNcm.isAcceptableOrUnknown(data['codigo_ncm']!, _codigoNcmMeta));
    }
    if (data.containsKey('estoque_minimo')) {
      context.handle(
          _estoqueMinimoMeta,
          estoqueMinimo.isAcceptableOrUnknown(
              data['estoque_minimo']!, _estoqueMinimoMeta));
    }
    if (data.containsKey('estoque_maximo')) {
      context.handle(
          _estoqueMaximoMeta,
          estoqueMaximo.isAcceptableOrUnknown(
              data['estoque_maximo']!, _estoqueMaximoMeta));
    }
    if (data.containsKey('quantidade_estoque')) {
      context.handle(
          _quantidadeEstoqueMeta,
          quantidadeEstoque.isAcceptableOrUnknown(
              data['quantidade_estoque']!, _quantidadeEstoqueMeta));
    }
    if (data.containsKey('data_cadastro')) {
      context.handle(
          _dataCadastroMeta,
          dataCadastro.isAcceptableOrUnknown(
              data['data_cadastro']!, _dataCadastroMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  Produto map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return Produto(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id']),
      idProdutoSubgrupo: attachedDatabase.typeMapping.read(
          DriftSqlType.int, data['${effectivePrefix}id_produto_subgrupo']),
      idProdutoMarca: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id_produto_marca']),
      idProdutoUnidade: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id_produto_unidade']),
      idTributIcmsCustomCab: attachedDatabase.typeMapping.read(DriftSqlType.int,
          data['${effectivePrefix}id_tribut_icms_custom_cab']),
      idTributGrupoTributario: attachedDatabase.typeMapping.read(
          DriftSqlType.int,
          data['${effectivePrefix}id_tribut_grupo_tributario']),
      nome: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}nome']),
      descricao: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}descricao']),
      gtin: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}gtin']),
      codigoInterno: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}codigo_interno']),
      valorCompra: attachedDatabase.typeMapping
          .read(DriftSqlType.double, data['${effectivePrefix}valor_compra']),
      valorVenda: attachedDatabase.typeMapping
          .read(DriftSqlType.double, data['${effectivePrefix}valor_venda']),
      codigoNcm: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}codigo_ncm']),
      estoqueMinimo: attachedDatabase.typeMapping
          .read(DriftSqlType.double, data['${effectivePrefix}estoque_minimo']),
      estoqueMaximo: attachedDatabase.typeMapping
          .read(DriftSqlType.double, data['${effectivePrefix}estoque_maximo']),
      quantidadeEstoque: attachedDatabase.typeMapping.read(
          DriftSqlType.double, data['${effectivePrefix}quantidade_estoque']),
      dataCadastro: attachedDatabase.typeMapping
          .read(DriftSqlType.dateTime, data['${effectivePrefix}data_cadastro']),
    );
  }

  @override
  $ProdutosTable createAlias(String alias) {
    return $ProdutosTable(attachedDatabase, alias);
  }
}

class Produto extends DataClass implements Insertable<Produto> {
  final int? id;
  final int? idProdutoSubgrupo;
  final int? idProdutoMarca;
  final int? idProdutoUnidade;
  final int? idTributIcmsCustomCab;
  final int? idTributGrupoTributario;
  final String? nome;
  final String? descricao;
  final String? gtin;
  final String? codigoInterno;
  final double? valorCompra;
  final double? valorVenda;
  final String? codigoNcm;
  final double? estoqueMinimo;
  final double? estoqueMaximo;
  final double? quantidadeEstoque;
  final DateTime? dataCadastro;
  const Produto(
      {this.id,
      this.idProdutoSubgrupo,
      this.idProdutoMarca,
      this.idProdutoUnidade,
      this.idTributIcmsCustomCab,
      this.idTributGrupoTributario,
      this.nome,
      this.descricao,
      this.gtin,
      this.codigoInterno,
      this.valorCompra,
      this.valorVenda,
      this.codigoNcm,
      this.estoqueMinimo,
      this.estoqueMaximo,
      this.quantidadeEstoque,
      this.dataCadastro});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || idProdutoSubgrupo != null) {
      map['id_produto_subgrupo'] = Variable<int>(idProdutoSubgrupo);
    }
    if (!nullToAbsent || idProdutoMarca != null) {
      map['id_produto_marca'] = Variable<int>(idProdutoMarca);
    }
    if (!nullToAbsent || idProdutoUnidade != null) {
      map['id_produto_unidade'] = Variable<int>(idProdutoUnidade);
    }
    if (!nullToAbsent || idTributIcmsCustomCab != null) {
      map['id_tribut_icms_custom_cab'] = Variable<int>(idTributIcmsCustomCab);
    }
    if (!nullToAbsent || idTributGrupoTributario != null) {
      map['id_tribut_grupo_tributario'] =
          Variable<int>(idTributGrupoTributario);
    }
    if (!nullToAbsent || nome != null) {
      map['nome'] = Variable<String>(nome);
    }
    if (!nullToAbsent || descricao != null) {
      map['descricao'] = Variable<String>(descricao);
    }
    if (!nullToAbsent || gtin != null) {
      map['gtin'] = Variable<String>(gtin);
    }
    if (!nullToAbsent || codigoInterno != null) {
      map['codigo_interno'] = Variable<String>(codigoInterno);
    }
    if (!nullToAbsent || valorCompra != null) {
      map['valor_compra'] = Variable<double>(valorCompra);
    }
    if (!nullToAbsent || valorVenda != null) {
      map['valor_venda'] = Variable<double>(valorVenda);
    }
    if (!nullToAbsent || codigoNcm != null) {
      map['codigo_ncm'] = Variable<String>(codigoNcm);
    }
    if (!nullToAbsent || estoqueMinimo != null) {
      map['estoque_minimo'] = Variable<double>(estoqueMinimo);
    }
    if (!nullToAbsent || estoqueMaximo != null) {
      map['estoque_maximo'] = Variable<double>(estoqueMaximo);
    }
    if (!nullToAbsent || quantidadeEstoque != null) {
      map['quantidade_estoque'] = Variable<double>(quantidadeEstoque);
    }
    if (!nullToAbsent || dataCadastro != null) {
      map['data_cadastro'] = Variable<DateTime>(dataCadastro);
    }
    return map;
  }

  factory Produto.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return Produto(
      id: serializer.fromJson<int?>(json['id']),
      idProdutoSubgrupo: serializer.fromJson<int?>(json['idProdutoSubgrupo']),
      idProdutoMarca: serializer.fromJson<int?>(json['idProdutoMarca']),
      idProdutoUnidade: serializer.fromJson<int?>(json['idProdutoUnidade']),
      idTributIcmsCustomCab:
          serializer.fromJson<int?>(json['idTributIcmsCustomCab']),
      idTributGrupoTributario:
          serializer.fromJson<int?>(json['idTributGrupoTributario']),
      nome: serializer.fromJson<String?>(json['nome']),
      descricao: serializer.fromJson<String?>(json['descricao']),
      gtin: serializer.fromJson<String?>(json['gtin']),
      codigoInterno: serializer.fromJson<String?>(json['codigoInterno']),
      valorCompra: serializer.fromJson<double?>(json['valorCompra']),
      valorVenda: serializer.fromJson<double?>(json['valorVenda']),
      codigoNcm: serializer.fromJson<String?>(json['codigoNcm']),
      estoqueMinimo: serializer.fromJson<double?>(json['estoqueMinimo']),
      estoqueMaximo: serializer.fromJson<double?>(json['estoqueMaximo']),
      quantidadeEstoque:
          serializer.fromJson<double?>(json['quantidadeEstoque']),
      dataCadastro: serializer.fromJson<DateTime?>(json['dataCadastro']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'idProdutoSubgrupo': serializer.toJson<int?>(idProdutoSubgrupo),
      'idProdutoMarca': serializer.toJson<int?>(idProdutoMarca),
      'idProdutoUnidade': serializer.toJson<int?>(idProdutoUnidade),
      'idTributIcmsCustomCab': serializer.toJson<int?>(idTributIcmsCustomCab),
      'idTributGrupoTributario':
          serializer.toJson<int?>(idTributGrupoTributario),
      'nome': serializer.toJson<String?>(nome),
      'descricao': serializer.toJson<String?>(descricao),
      'gtin': serializer.toJson<String?>(gtin),
      'codigoInterno': serializer.toJson<String?>(codigoInterno),
      'valorCompra': serializer.toJson<double?>(valorCompra),
      'valorVenda': serializer.toJson<double?>(valorVenda),
      'codigoNcm': serializer.toJson<String?>(codigoNcm),
      'estoqueMinimo': serializer.toJson<double?>(estoqueMinimo),
      'estoqueMaximo': serializer.toJson<double?>(estoqueMaximo),
      'quantidadeEstoque': serializer.toJson<double?>(quantidadeEstoque),
      'dataCadastro': serializer.toJson<DateTime?>(dataCadastro),
    };
  }

  Produto copyWith(
          {Value<int?> id = const Value.absent(),
          Value<int?> idProdutoSubgrupo = const Value.absent(),
          Value<int?> idProdutoMarca = const Value.absent(),
          Value<int?> idProdutoUnidade = const Value.absent(),
          Value<int?> idTributIcmsCustomCab = const Value.absent(),
          Value<int?> idTributGrupoTributario = const Value.absent(),
          Value<String?> nome = const Value.absent(),
          Value<String?> descricao = const Value.absent(),
          Value<String?> gtin = const Value.absent(),
          Value<String?> codigoInterno = const Value.absent(),
          Value<double?> valorCompra = const Value.absent(),
          Value<double?> valorVenda = const Value.absent(),
          Value<String?> codigoNcm = const Value.absent(),
          Value<double?> estoqueMinimo = const Value.absent(),
          Value<double?> estoqueMaximo = const Value.absent(),
          Value<double?> quantidadeEstoque = const Value.absent(),
          Value<DateTime?> dataCadastro = const Value.absent()}) =>
      Produto(
        id: id.present ? id.value : this.id,
        idProdutoSubgrupo: idProdutoSubgrupo.present
            ? idProdutoSubgrupo.value
            : this.idProdutoSubgrupo,
        idProdutoMarca:
            idProdutoMarca.present ? idProdutoMarca.value : this.idProdutoMarca,
        idProdutoUnidade: idProdutoUnidade.present
            ? idProdutoUnidade.value
            : this.idProdutoUnidade,
        idTributIcmsCustomCab: idTributIcmsCustomCab.present
            ? idTributIcmsCustomCab.value
            : this.idTributIcmsCustomCab,
        idTributGrupoTributario: idTributGrupoTributario.present
            ? idTributGrupoTributario.value
            : this.idTributGrupoTributario,
        nome: nome.present ? nome.value : this.nome,
        descricao: descricao.present ? descricao.value : this.descricao,
        gtin: gtin.present ? gtin.value : this.gtin,
        codigoInterno:
            codigoInterno.present ? codigoInterno.value : this.codigoInterno,
        valorCompra: valorCompra.present ? valorCompra.value : this.valorCompra,
        valorVenda: valorVenda.present ? valorVenda.value : this.valorVenda,
        codigoNcm: codigoNcm.present ? codigoNcm.value : this.codigoNcm,
        estoqueMinimo:
            estoqueMinimo.present ? estoqueMinimo.value : this.estoqueMinimo,
        estoqueMaximo:
            estoqueMaximo.present ? estoqueMaximo.value : this.estoqueMaximo,
        quantidadeEstoque: quantidadeEstoque.present
            ? quantidadeEstoque.value
            : this.quantidadeEstoque,
        dataCadastro:
            dataCadastro.present ? dataCadastro.value : this.dataCadastro,
      );
  Produto copyWithCompanion(ProdutosCompanion data) {
    return Produto(
      id: data.id.present ? data.id.value : this.id,
      idProdutoSubgrupo: data.idProdutoSubgrupo.present
          ? data.idProdutoSubgrupo.value
          : this.idProdutoSubgrupo,
      idProdutoMarca: data.idProdutoMarca.present
          ? data.idProdutoMarca.value
          : this.idProdutoMarca,
      idProdutoUnidade: data.idProdutoUnidade.present
          ? data.idProdutoUnidade.value
          : this.idProdutoUnidade,
      idTributIcmsCustomCab: data.idTributIcmsCustomCab.present
          ? data.idTributIcmsCustomCab.value
          : this.idTributIcmsCustomCab,
      idTributGrupoTributario: data.idTributGrupoTributario.present
          ? data.idTributGrupoTributario.value
          : this.idTributGrupoTributario,
      nome: data.nome.present ? data.nome.value : this.nome,
      descricao: data.descricao.present ? data.descricao.value : this.descricao,
      gtin: data.gtin.present ? data.gtin.value : this.gtin,
      codigoInterno: data.codigoInterno.present
          ? data.codigoInterno.value
          : this.codigoInterno,
      valorCompra:
          data.valorCompra.present ? data.valorCompra.value : this.valorCompra,
      valorVenda:
          data.valorVenda.present ? data.valorVenda.value : this.valorVenda,
      codigoNcm: data.codigoNcm.present ? data.codigoNcm.value : this.codigoNcm,
      estoqueMinimo: data.estoqueMinimo.present
          ? data.estoqueMinimo.value
          : this.estoqueMinimo,
      estoqueMaximo: data.estoqueMaximo.present
          ? data.estoqueMaximo.value
          : this.estoqueMaximo,
      quantidadeEstoque: data.quantidadeEstoque.present
          ? data.quantidadeEstoque.value
          : this.quantidadeEstoque,
      dataCadastro: data.dataCadastro.present
          ? data.dataCadastro.value
          : this.dataCadastro,
    );
  }

  @override
  String toString() {
    return (StringBuffer('Produto(')
          ..write('id: $id, ')
          ..write('idProdutoSubgrupo: $idProdutoSubgrupo, ')
          ..write('idProdutoMarca: $idProdutoMarca, ')
          ..write('idProdutoUnidade: $idProdutoUnidade, ')
          ..write('idTributIcmsCustomCab: $idTributIcmsCustomCab, ')
          ..write('idTributGrupoTributario: $idTributGrupoTributario, ')
          ..write('nome: $nome, ')
          ..write('descricao: $descricao, ')
          ..write('gtin: $gtin, ')
          ..write('codigoInterno: $codigoInterno, ')
          ..write('valorCompra: $valorCompra, ')
          ..write('valorVenda: $valorVenda, ')
          ..write('codigoNcm: $codigoNcm, ')
          ..write('estoqueMinimo: $estoqueMinimo, ')
          ..write('estoqueMaximo: $estoqueMaximo, ')
          ..write('quantidadeEstoque: $quantidadeEstoque, ')
          ..write('dataCadastro: $dataCadastro')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(
      id,
      idProdutoSubgrupo,
      idProdutoMarca,
      idProdutoUnidade,
      idTributIcmsCustomCab,
      idTributGrupoTributario,
      nome,
      descricao,
      gtin,
      codigoInterno,
      valorCompra,
      valorVenda,
      codigoNcm,
      estoqueMinimo,
      estoqueMaximo,
      quantidadeEstoque,
      dataCadastro);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is Produto &&
          other.id == this.id &&
          other.idProdutoSubgrupo == this.idProdutoSubgrupo &&
          other.idProdutoMarca == this.idProdutoMarca &&
          other.idProdutoUnidade == this.idProdutoUnidade &&
          other.idTributIcmsCustomCab == this.idTributIcmsCustomCab &&
          other.idTributGrupoTributario == this.idTributGrupoTributario &&
          other.nome == this.nome &&
          other.descricao == this.descricao &&
          other.gtin == this.gtin &&
          other.codigoInterno == this.codigoInterno &&
          other.valorCompra == this.valorCompra &&
          other.valorVenda == this.valorVenda &&
          other.codigoNcm == this.codigoNcm &&
          other.estoqueMinimo == this.estoqueMinimo &&
          other.estoqueMaximo == this.estoqueMaximo &&
          other.quantidadeEstoque == this.quantidadeEstoque &&
          other.dataCadastro == this.dataCadastro);
}

class ProdutosCompanion extends UpdateCompanion<Produto> {
  final Value<int?> id;
  final Value<int?> idProdutoSubgrupo;
  final Value<int?> idProdutoMarca;
  final Value<int?> idProdutoUnidade;
  final Value<int?> idTributIcmsCustomCab;
  final Value<int?> idTributGrupoTributario;
  final Value<String?> nome;
  final Value<String?> descricao;
  final Value<String?> gtin;
  final Value<String?> codigoInterno;
  final Value<double?> valorCompra;
  final Value<double?> valorVenda;
  final Value<String?> codigoNcm;
  final Value<double?> estoqueMinimo;
  final Value<double?> estoqueMaximo;
  final Value<double?> quantidadeEstoque;
  final Value<DateTime?> dataCadastro;
  const ProdutosCompanion({
    this.id = const Value.absent(),
    this.idProdutoSubgrupo = const Value.absent(),
    this.idProdutoMarca = const Value.absent(),
    this.idProdutoUnidade = const Value.absent(),
    this.idTributIcmsCustomCab = const Value.absent(),
    this.idTributGrupoTributario = const Value.absent(),
    this.nome = const Value.absent(),
    this.descricao = const Value.absent(),
    this.gtin = const Value.absent(),
    this.codigoInterno = const Value.absent(),
    this.valorCompra = const Value.absent(),
    this.valorVenda = const Value.absent(),
    this.codigoNcm = const Value.absent(),
    this.estoqueMinimo = const Value.absent(),
    this.estoqueMaximo = const Value.absent(),
    this.quantidadeEstoque = const Value.absent(),
    this.dataCadastro = const Value.absent(),
  });
  ProdutosCompanion.insert({
    this.id = const Value.absent(),
    this.idProdutoSubgrupo = const Value.absent(),
    this.idProdutoMarca = const Value.absent(),
    this.idProdutoUnidade = const Value.absent(),
    this.idTributIcmsCustomCab = const Value.absent(),
    this.idTributGrupoTributario = const Value.absent(),
    this.nome = const Value.absent(),
    this.descricao = const Value.absent(),
    this.gtin = const Value.absent(),
    this.codigoInterno = const Value.absent(),
    this.valorCompra = const Value.absent(),
    this.valorVenda = const Value.absent(),
    this.codigoNcm = const Value.absent(),
    this.estoqueMinimo = const Value.absent(),
    this.estoqueMaximo = const Value.absent(),
    this.quantidadeEstoque = const Value.absent(),
    this.dataCadastro = const Value.absent(),
  });
  static Insertable<Produto> custom({
    Expression<int>? id,
    Expression<int>? idProdutoSubgrupo,
    Expression<int>? idProdutoMarca,
    Expression<int>? idProdutoUnidade,
    Expression<int>? idTributIcmsCustomCab,
    Expression<int>? idTributGrupoTributario,
    Expression<String>? nome,
    Expression<String>? descricao,
    Expression<String>? gtin,
    Expression<String>? codigoInterno,
    Expression<double>? valorCompra,
    Expression<double>? valorVenda,
    Expression<String>? codigoNcm,
    Expression<double>? estoqueMinimo,
    Expression<double>? estoqueMaximo,
    Expression<double>? quantidadeEstoque,
    Expression<DateTime>? dataCadastro,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (idProdutoSubgrupo != null) 'id_produto_subgrupo': idProdutoSubgrupo,
      if (idProdutoMarca != null) 'id_produto_marca': idProdutoMarca,
      if (idProdutoUnidade != null) 'id_produto_unidade': idProdutoUnidade,
      if (idTributIcmsCustomCab != null)
        'id_tribut_icms_custom_cab': idTributIcmsCustomCab,
      if (idTributGrupoTributario != null)
        'id_tribut_grupo_tributario': idTributGrupoTributario,
      if (nome != null) 'nome': nome,
      if (descricao != null) 'descricao': descricao,
      if (gtin != null) 'gtin': gtin,
      if (codigoInterno != null) 'codigo_interno': codigoInterno,
      if (valorCompra != null) 'valor_compra': valorCompra,
      if (valorVenda != null) 'valor_venda': valorVenda,
      if (codigoNcm != null) 'codigo_ncm': codigoNcm,
      if (estoqueMinimo != null) 'estoque_minimo': estoqueMinimo,
      if (estoqueMaximo != null) 'estoque_maximo': estoqueMaximo,
      if (quantidadeEstoque != null) 'quantidade_estoque': quantidadeEstoque,
      if (dataCadastro != null) 'data_cadastro': dataCadastro,
    });
  }

  ProdutosCompanion copyWith(
      {Value<int?>? id,
      Value<int?>? idProdutoSubgrupo,
      Value<int?>? idProdutoMarca,
      Value<int?>? idProdutoUnidade,
      Value<int?>? idTributIcmsCustomCab,
      Value<int?>? idTributGrupoTributario,
      Value<String?>? nome,
      Value<String?>? descricao,
      Value<String?>? gtin,
      Value<String?>? codigoInterno,
      Value<double?>? valorCompra,
      Value<double?>? valorVenda,
      Value<String?>? codigoNcm,
      Value<double?>? estoqueMinimo,
      Value<double?>? estoqueMaximo,
      Value<double?>? quantidadeEstoque,
      Value<DateTime?>? dataCadastro}) {
    return ProdutosCompanion(
      id: id ?? this.id,
      idProdutoSubgrupo: idProdutoSubgrupo ?? this.idProdutoSubgrupo,
      idProdutoMarca: idProdutoMarca ?? this.idProdutoMarca,
      idProdutoUnidade: idProdutoUnidade ?? this.idProdutoUnidade,
      idTributIcmsCustomCab:
          idTributIcmsCustomCab ?? this.idTributIcmsCustomCab,
      idTributGrupoTributario:
          idTributGrupoTributario ?? this.idTributGrupoTributario,
      nome: nome ?? this.nome,
      descricao: descricao ?? this.descricao,
      gtin: gtin ?? this.gtin,
      codigoInterno: codigoInterno ?? this.codigoInterno,
      valorCompra: valorCompra ?? this.valorCompra,
      valorVenda: valorVenda ?? this.valorVenda,
      codigoNcm: codigoNcm ?? this.codigoNcm,
      estoqueMinimo: estoqueMinimo ?? this.estoqueMinimo,
      estoqueMaximo: estoqueMaximo ?? this.estoqueMaximo,
      quantidadeEstoque: quantidadeEstoque ?? this.quantidadeEstoque,
      dataCadastro: dataCadastro ?? this.dataCadastro,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (idProdutoSubgrupo.present) {
      map['id_produto_subgrupo'] = Variable<int>(idProdutoSubgrupo.value);
    }
    if (idProdutoMarca.present) {
      map['id_produto_marca'] = Variable<int>(idProdutoMarca.value);
    }
    if (idProdutoUnidade.present) {
      map['id_produto_unidade'] = Variable<int>(idProdutoUnidade.value);
    }
    if (idTributIcmsCustomCab.present) {
      map['id_tribut_icms_custom_cab'] =
          Variable<int>(idTributIcmsCustomCab.value);
    }
    if (idTributGrupoTributario.present) {
      map['id_tribut_grupo_tributario'] =
          Variable<int>(idTributGrupoTributario.value);
    }
    if (nome.present) {
      map['nome'] = Variable<String>(nome.value);
    }
    if (descricao.present) {
      map['descricao'] = Variable<String>(descricao.value);
    }
    if (gtin.present) {
      map['gtin'] = Variable<String>(gtin.value);
    }
    if (codigoInterno.present) {
      map['codigo_interno'] = Variable<String>(codigoInterno.value);
    }
    if (valorCompra.present) {
      map['valor_compra'] = Variable<double>(valorCompra.value);
    }
    if (valorVenda.present) {
      map['valor_venda'] = Variable<double>(valorVenda.value);
    }
    if (codigoNcm.present) {
      map['codigo_ncm'] = Variable<String>(codigoNcm.value);
    }
    if (estoqueMinimo.present) {
      map['estoque_minimo'] = Variable<double>(estoqueMinimo.value);
    }
    if (estoqueMaximo.present) {
      map['estoque_maximo'] = Variable<double>(estoqueMaximo.value);
    }
    if (quantidadeEstoque.present) {
      map['quantidade_estoque'] = Variable<double>(quantidadeEstoque.value);
    }
    if (dataCadastro.present) {
      map['data_cadastro'] = Variable<DateTime>(dataCadastro.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('ProdutosCompanion(')
          ..write('id: $id, ')
          ..write('idProdutoSubgrupo: $idProdutoSubgrupo, ')
          ..write('idProdutoMarca: $idProdutoMarca, ')
          ..write('idProdutoUnidade: $idProdutoUnidade, ')
          ..write('idTributIcmsCustomCab: $idTributIcmsCustomCab, ')
          ..write('idTributGrupoTributario: $idTributGrupoTributario, ')
          ..write('nome: $nome, ')
          ..write('descricao: $descricao, ')
          ..write('gtin: $gtin, ')
          ..write('codigoInterno: $codigoInterno, ')
          ..write('valorCompra: $valorCompra, ')
          ..write('valorVenda: $valorVenda, ')
          ..write('codigoNcm: $codigoNcm, ')
          ..write('estoqueMinimo: $estoqueMinimo, ')
          ..write('estoqueMaximo: $estoqueMaximo, ')
          ..write('quantidadeEstoque: $quantidadeEstoque, ')
          ..write('dataCadastro: $dataCadastro')
          ..write(')'))
        .toString();
  }
}

class $VendaOrcamentoDetalhesTable extends VendaOrcamentoDetalhes
    with TableInfo<$VendaOrcamentoDetalhesTable, VendaOrcamentoDetalhe> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $VendaOrcamentoDetalhesTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
      'id', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _idVendaOrcamentoCabecalhoMeta =
      const VerificationMeta('idVendaOrcamentoCabecalho');
  @override
  late final GeneratedColumn<int> idVendaOrcamentoCabecalho =
      GeneratedColumn<int>('id_venda_orcamento_cabecalho', aliasedName, true,
          type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _idProdutoMeta =
      const VerificationMeta('idProduto');
  @override
  late final GeneratedColumn<int> idProduto = GeneratedColumn<int>(
      'id_produto', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _quantidadeMeta =
      const VerificationMeta('quantidade');
  @override
  late final GeneratedColumn<double> quantidade = GeneratedColumn<double>(
      'quantidade', aliasedName, true,
      type: DriftSqlType.double, requiredDuringInsert: false);
  static const VerificationMeta _valorUnitarioMeta =
      const VerificationMeta('valorUnitario');
  @override
  late final GeneratedColumn<double> valorUnitario = GeneratedColumn<double>(
      'valor_unitario', aliasedName, true,
      type: DriftSqlType.double, requiredDuringInsert: false);
  static const VerificationMeta _valorSubtotalMeta =
      const VerificationMeta('valorSubtotal');
  @override
  late final GeneratedColumn<double> valorSubtotal = GeneratedColumn<double>(
      'valor_subtotal', aliasedName, true,
      type: DriftSqlType.double, requiredDuringInsert: false);
  static const VerificationMeta _taxaDescontoMeta =
      const VerificationMeta('taxaDesconto');
  @override
  late final GeneratedColumn<double> taxaDesconto = GeneratedColumn<double>(
      'taxa_desconto', aliasedName, true,
      type: DriftSqlType.double, requiredDuringInsert: false);
  static const VerificationMeta _valorDescontoMeta =
      const VerificationMeta('valorDesconto');
  @override
  late final GeneratedColumn<double> valorDesconto = GeneratedColumn<double>(
      'valor_desconto', aliasedName, true,
      type: DriftSqlType.double, requiredDuringInsert: false);
  static const VerificationMeta _valorTotalMeta =
      const VerificationMeta('valorTotal');
  @override
  late final GeneratedColumn<double> valorTotal = GeneratedColumn<double>(
      'valor_total', aliasedName, true,
      type: DriftSqlType.double, requiredDuringInsert: false);
  @override
  List<GeneratedColumn> get $columns => [
        id,
        idVendaOrcamentoCabecalho,
        idProduto,
        quantidade,
        valorUnitario,
        valorSubtotal,
        taxaDesconto,
        valorDesconto,
        valorTotal
      ];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'venda_orcamento_detalhe';
  @override
  VerificationContext validateIntegrity(
      Insertable<VendaOrcamentoDetalhe> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('id_venda_orcamento_cabecalho')) {
      context.handle(
          _idVendaOrcamentoCabecalhoMeta,
          idVendaOrcamentoCabecalho.isAcceptableOrUnknown(
              data['id_venda_orcamento_cabecalho']!,
              _idVendaOrcamentoCabecalhoMeta));
    }
    if (data.containsKey('id_produto')) {
      context.handle(_idProdutoMeta,
          idProduto.isAcceptableOrUnknown(data['id_produto']!, _idProdutoMeta));
    }
    if (data.containsKey('quantidade')) {
      context.handle(
          _quantidadeMeta,
          quantidade.isAcceptableOrUnknown(
              data['quantidade']!, _quantidadeMeta));
    }
    if (data.containsKey('valor_unitario')) {
      context.handle(
          _valorUnitarioMeta,
          valorUnitario.isAcceptableOrUnknown(
              data['valor_unitario']!, _valorUnitarioMeta));
    }
    if (data.containsKey('valor_subtotal')) {
      context.handle(
          _valorSubtotalMeta,
          valorSubtotal.isAcceptableOrUnknown(
              data['valor_subtotal']!, _valorSubtotalMeta));
    }
    if (data.containsKey('taxa_desconto')) {
      context.handle(
          _taxaDescontoMeta,
          taxaDesconto.isAcceptableOrUnknown(
              data['taxa_desconto']!, _taxaDescontoMeta));
    }
    if (data.containsKey('valor_desconto')) {
      context.handle(
          _valorDescontoMeta,
          valorDesconto.isAcceptableOrUnknown(
              data['valor_desconto']!, _valorDescontoMeta));
    }
    if (data.containsKey('valor_total')) {
      context.handle(
          _valorTotalMeta,
          valorTotal.isAcceptableOrUnknown(
              data['valor_total']!, _valorTotalMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  VendaOrcamentoDetalhe map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return VendaOrcamentoDetalhe(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id']),
      idVendaOrcamentoCabecalho: attachedDatabase.typeMapping.read(
          DriftSqlType.int,
          data['${effectivePrefix}id_venda_orcamento_cabecalho']),
      idProduto: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id_produto']),
      quantidade: attachedDatabase.typeMapping
          .read(DriftSqlType.double, data['${effectivePrefix}quantidade']),
      valorUnitario: attachedDatabase.typeMapping
          .read(DriftSqlType.double, data['${effectivePrefix}valor_unitario']),
      valorSubtotal: attachedDatabase.typeMapping
          .read(DriftSqlType.double, data['${effectivePrefix}valor_subtotal']),
      taxaDesconto: attachedDatabase.typeMapping
          .read(DriftSqlType.double, data['${effectivePrefix}taxa_desconto']),
      valorDesconto: attachedDatabase.typeMapping
          .read(DriftSqlType.double, data['${effectivePrefix}valor_desconto']),
      valorTotal: attachedDatabase.typeMapping
          .read(DriftSqlType.double, data['${effectivePrefix}valor_total']),
    );
  }

  @override
  $VendaOrcamentoDetalhesTable createAlias(String alias) {
    return $VendaOrcamentoDetalhesTable(attachedDatabase, alias);
  }
}

class VendaOrcamentoDetalhe extends DataClass
    implements Insertable<VendaOrcamentoDetalhe> {
  final int? id;
  final int? idVendaOrcamentoCabecalho;
  final int? idProduto;
  final double? quantidade;
  final double? valorUnitario;
  final double? valorSubtotal;
  final double? taxaDesconto;
  final double? valorDesconto;
  final double? valorTotal;
  const VendaOrcamentoDetalhe(
      {this.id,
      this.idVendaOrcamentoCabecalho,
      this.idProduto,
      this.quantidade,
      this.valorUnitario,
      this.valorSubtotal,
      this.taxaDesconto,
      this.valorDesconto,
      this.valorTotal});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || idVendaOrcamentoCabecalho != null) {
      map['id_venda_orcamento_cabecalho'] =
          Variable<int>(idVendaOrcamentoCabecalho);
    }
    if (!nullToAbsent || idProduto != null) {
      map['id_produto'] = Variable<int>(idProduto);
    }
    if (!nullToAbsent || quantidade != null) {
      map['quantidade'] = Variable<double>(quantidade);
    }
    if (!nullToAbsent || valorUnitario != null) {
      map['valor_unitario'] = Variable<double>(valorUnitario);
    }
    if (!nullToAbsent || valorSubtotal != null) {
      map['valor_subtotal'] = Variable<double>(valorSubtotal);
    }
    if (!nullToAbsent || taxaDesconto != null) {
      map['taxa_desconto'] = Variable<double>(taxaDesconto);
    }
    if (!nullToAbsent || valorDesconto != null) {
      map['valor_desconto'] = Variable<double>(valorDesconto);
    }
    if (!nullToAbsent || valorTotal != null) {
      map['valor_total'] = Variable<double>(valorTotal);
    }
    return map;
  }

  factory VendaOrcamentoDetalhe.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return VendaOrcamentoDetalhe(
      id: serializer.fromJson<int?>(json['id']),
      idVendaOrcamentoCabecalho:
          serializer.fromJson<int?>(json['idVendaOrcamentoCabecalho']),
      idProduto: serializer.fromJson<int?>(json['idProduto']),
      quantidade: serializer.fromJson<double?>(json['quantidade']),
      valorUnitario: serializer.fromJson<double?>(json['valorUnitario']),
      valorSubtotal: serializer.fromJson<double?>(json['valorSubtotal']),
      taxaDesconto: serializer.fromJson<double?>(json['taxaDesconto']),
      valorDesconto: serializer.fromJson<double?>(json['valorDesconto']),
      valorTotal: serializer.fromJson<double?>(json['valorTotal']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'idVendaOrcamentoCabecalho':
          serializer.toJson<int?>(idVendaOrcamentoCabecalho),
      'idProduto': serializer.toJson<int?>(idProduto),
      'quantidade': serializer.toJson<double?>(quantidade),
      'valorUnitario': serializer.toJson<double?>(valorUnitario),
      'valorSubtotal': serializer.toJson<double?>(valorSubtotal),
      'taxaDesconto': serializer.toJson<double?>(taxaDesconto),
      'valorDesconto': serializer.toJson<double?>(valorDesconto),
      'valorTotal': serializer.toJson<double?>(valorTotal),
    };
  }

  VendaOrcamentoDetalhe copyWith(
          {Value<int?> id = const Value.absent(),
          Value<int?> idVendaOrcamentoCabecalho = const Value.absent(),
          Value<int?> idProduto = const Value.absent(),
          Value<double?> quantidade = const Value.absent(),
          Value<double?> valorUnitario = const Value.absent(),
          Value<double?> valorSubtotal = const Value.absent(),
          Value<double?> taxaDesconto = const Value.absent(),
          Value<double?> valorDesconto = const Value.absent(),
          Value<double?> valorTotal = const Value.absent()}) =>
      VendaOrcamentoDetalhe(
        id: id.present ? id.value : this.id,
        idVendaOrcamentoCabecalho: idVendaOrcamentoCabecalho.present
            ? idVendaOrcamentoCabecalho.value
            : this.idVendaOrcamentoCabecalho,
        idProduto: idProduto.present ? idProduto.value : this.idProduto,
        quantidade: quantidade.present ? quantidade.value : this.quantidade,
        valorUnitario:
            valorUnitario.present ? valorUnitario.value : this.valorUnitario,
        valorSubtotal:
            valorSubtotal.present ? valorSubtotal.value : this.valorSubtotal,
        taxaDesconto:
            taxaDesconto.present ? taxaDesconto.value : this.taxaDesconto,
        valorDesconto:
            valorDesconto.present ? valorDesconto.value : this.valorDesconto,
        valorTotal: valorTotal.present ? valorTotal.value : this.valorTotal,
      );
  VendaOrcamentoDetalhe copyWithCompanion(
      VendaOrcamentoDetalhesCompanion data) {
    return VendaOrcamentoDetalhe(
      id: data.id.present ? data.id.value : this.id,
      idVendaOrcamentoCabecalho: data.idVendaOrcamentoCabecalho.present
          ? data.idVendaOrcamentoCabecalho.value
          : this.idVendaOrcamentoCabecalho,
      idProduto: data.idProduto.present ? data.idProduto.value : this.idProduto,
      quantidade:
          data.quantidade.present ? data.quantidade.value : this.quantidade,
      valorUnitario: data.valorUnitario.present
          ? data.valorUnitario.value
          : this.valorUnitario,
      valorSubtotal: data.valorSubtotal.present
          ? data.valorSubtotal.value
          : this.valorSubtotal,
      taxaDesconto: data.taxaDesconto.present
          ? data.taxaDesconto.value
          : this.taxaDesconto,
      valorDesconto: data.valorDesconto.present
          ? data.valorDesconto.value
          : this.valorDesconto,
      valorTotal:
          data.valorTotal.present ? data.valorTotal.value : this.valorTotal,
    );
  }

  @override
  String toString() {
    return (StringBuffer('VendaOrcamentoDetalhe(')
          ..write('id: $id, ')
          ..write('idVendaOrcamentoCabecalho: $idVendaOrcamentoCabecalho, ')
          ..write('idProduto: $idProduto, ')
          ..write('quantidade: $quantidade, ')
          ..write('valorUnitario: $valorUnitario, ')
          ..write('valorSubtotal: $valorSubtotal, ')
          ..write('taxaDesconto: $taxaDesconto, ')
          ..write('valorDesconto: $valorDesconto, ')
          ..write('valorTotal: $valorTotal')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(
      id,
      idVendaOrcamentoCabecalho,
      idProduto,
      quantidade,
      valorUnitario,
      valorSubtotal,
      taxaDesconto,
      valorDesconto,
      valorTotal);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is VendaOrcamentoDetalhe &&
          other.id == this.id &&
          other.idVendaOrcamentoCabecalho == this.idVendaOrcamentoCabecalho &&
          other.idProduto == this.idProduto &&
          other.quantidade == this.quantidade &&
          other.valorUnitario == this.valorUnitario &&
          other.valorSubtotal == this.valorSubtotal &&
          other.taxaDesconto == this.taxaDesconto &&
          other.valorDesconto == this.valorDesconto &&
          other.valorTotal == this.valorTotal);
}

class VendaOrcamentoDetalhesCompanion
    extends UpdateCompanion<VendaOrcamentoDetalhe> {
  final Value<int?> id;
  final Value<int?> idVendaOrcamentoCabecalho;
  final Value<int?> idProduto;
  final Value<double?> quantidade;
  final Value<double?> valorUnitario;
  final Value<double?> valorSubtotal;
  final Value<double?> taxaDesconto;
  final Value<double?> valorDesconto;
  final Value<double?> valorTotal;
  const VendaOrcamentoDetalhesCompanion({
    this.id = const Value.absent(),
    this.idVendaOrcamentoCabecalho = const Value.absent(),
    this.idProduto = const Value.absent(),
    this.quantidade = const Value.absent(),
    this.valorUnitario = const Value.absent(),
    this.valorSubtotal = const Value.absent(),
    this.taxaDesconto = const Value.absent(),
    this.valorDesconto = const Value.absent(),
    this.valorTotal = const Value.absent(),
  });
  VendaOrcamentoDetalhesCompanion.insert({
    this.id = const Value.absent(),
    this.idVendaOrcamentoCabecalho = const Value.absent(),
    this.idProduto = const Value.absent(),
    this.quantidade = const Value.absent(),
    this.valorUnitario = const Value.absent(),
    this.valorSubtotal = const Value.absent(),
    this.taxaDesconto = const Value.absent(),
    this.valorDesconto = const Value.absent(),
    this.valorTotal = const Value.absent(),
  });
  static Insertable<VendaOrcamentoDetalhe> custom({
    Expression<int>? id,
    Expression<int>? idVendaOrcamentoCabecalho,
    Expression<int>? idProduto,
    Expression<double>? quantidade,
    Expression<double>? valorUnitario,
    Expression<double>? valorSubtotal,
    Expression<double>? taxaDesconto,
    Expression<double>? valorDesconto,
    Expression<double>? valorTotal,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (idVendaOrcamentoCabecalho != null)
        'id_venda_orcamento_cabecalho': idVendaOrcamentoCabecalho,
      if (idProduto != null) 'id_produto': idProduto,
      if (quantidade != null) 'quantidade': quantidade,
      if (valorUnitario != null) 'valor_unitario': valorUnitario,
      if (valorSubtotal != null) 'valor_subtotal': valorSubtotal,
      if (taxaDesconto != null) 'taxa_desconto': taxaDesconto,
      if (valorDesconto != null) 'valor_desconto': valorDesconto,
      if (valorTotal != null) 'valor_total': valorTotal,
    });
  }

  VendaOrcamentoDetalhesCompanion copyWith(
      {Value<int?>? id,
      Value<int?>? idVendaOrcamentoCabecalho,
      Value<int?>? idProduto,
      Value<double?>? quantidade,
      Value<double?>? valorUnitario,
      Value<double?>? valorSubtotal,
      Value<double?>? taxaDesconto,
      Value<double?>? valorDesconto,
      Value<double?>? valorTotal}) {
    return VendaOrcamentoDetalhesCompanion(
      id: id ?? this.id,
      idVendaOrcamentoCabecalho:
          idVendaOrcamentoCabecalho ?? this.idVendaOrcamentoCabecalho,
      idProduto: idProduto ?? this.idProduto,
      quantidade: quantidade ?? this.quantidade,
      valorUnitario: valorUnitario ?? this.valorUnitario,
      valorSubtotal: valorSubtotal ?? this.valorSubtotal,
      taxaDesconto: taxaDesconto ?? this.taxaDesconto,
      valorDesconto: valorDesconto ?? this.valorDesconto,
      valorTotal: valorTotal ?? this.valorTotal,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (idVendaOrcamentoCabecalho.present) {
      map['id_venda_orcamento_cabecalho'] =
          Variable<int>(idVendaOrcamentoCabecalho.value);
    }
    if (idProduto.present) {
      map['id_produto'] = Variable<int>(idProduto.value);
    }
    if (quantidade.present) {
      map['quantidade'] = Variable<double>(quantidade.value);
    }
    if (valorUnitario.present) {
      map['valor_unitario'] = Variable<double>(valorUnitario.value);
    }
    if (valorSubtotal.present) {
      map['valor_subtotal'] = Variable<double>(valorSubtotal.value);
    }
    if (taxaDesconto.present) {
      map['taxa_desconto'] = Variable<double>(taxaDesconto.value);
    }
    if (valorDesconto.present) {
      map['valor_desconto'] = Variable<double>(valorDesconto.value);
    }
    if (valorTotal.present) {
      map['valor_total'] = Variable<double>(valorTotal.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('VendaOrcamentoDetalhesCompanion(')
          ..write('id: $id, ')
          ..write('idVendaOrcamentoCabecalho: $idVendaOrcamentoCabecalho, ')
          ..write('idProduto: $idProduto, ')
          ..write('quantidade: $quantidade, ')
          ..write('valorUnitario: $valorUnitario, ')
          ..write('valorSubtotal: $valorSubtotal, ')
          ..write('taxaDesconto: $taxaDesconto, ')
          ..write('valorDesconto: $valorDesconto, ')
          ..write('valorTotal: $valorTotal')
          ..write(')'))
        .toString();
  }
}

class $VendaDetalhesTable extends VendaDetalhes
    with TableInfo<$VendaDetalhesTable, VendaDetalhe> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $VendaDetalhesTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
      'id', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _idVendaCabecalhoMeta =
      const VerificationMeta('idVendaCabecalho');
  @override
  late final GeneratedColumn<int> idVendaCabecalho = GeneratedColumn<int>(
      'id_venda_cabecalho', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _idProdutoMeta =
      const VerificationMeta('idProduto');
  @override
  late final GeneratedColumn<int> idProduto = GeneratedColumn<int>(
      'id_produto', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _quantidadeMeta =
      const VerificationMeta('quantidade');
  @override
  late final GeneratedColumn<double> quantidade = GeneratedColumn<double>(
      'quantidade', aliasedName, true,
      type: DriftSqlType.double, requiredDuringInsert: false);
  static const VerificationMeta _valorUnitarioMeta =
      const VerificationMeta('valorUnitario');
  @override
  late final GeneratedColumn<double> valorUnitario = GeneratedColumn<double>(
      'valor_unitario', aliasedName, true,
      type: DriftSqlType.double, requiredDuringInsert: false);
  static const VerificationMeta _valorSubtotalMeta =
      const VerificationMeta('valorSubtotal');
  @override
  late final GeneratedColumn<double> valorSubtotal = GeneratedColumn<double>(
      'valor_subtotal', aliasedName, true,
      type: DriftSqlType.double, requiredDuringInsert: false);
  static const VerificationMeta _taxaDescontoMeta =
      const VerificationMeta('taxaDesconto');
  @override
  late final GeneratedColumn<double> taxaDesconto = GeneratedColumn<double>(
      'taxa_desconto', aliasedName, true,
      type: DriftSqlType.double, requiredDuringInsert: false);
  static const VerificationMeta _valorDescontoMeta =
      const VerificationMeta('valorDesconto');
  @override
  late final GeneratedColumn<double> valorDesconto = GeneratedColumn<double>(
      'valor_desconto', aliasedName, true,
      type: DriftSqlType.double, requiredDuringInsert: false);
  static const VerificationMeta _valorTotalMeta =
      const VerificationMeta('valorTotal');
  @override
  late final GeneratedColumn<double> valorTotal = GeneratedColumn<double>(
      'valor_total', aliasedName, true,
      type: DriftSqlType.double, requiredDuringInsert: false);
  @override
  List<GeneratedColumn> get $columns => [
        id,
        idVendaCabecalho,
        idProduto,
        quantidade,
        valorUnitario,
        valorSubtotal,
        taxaDesconto,
        valorDesconto,
        valorTotal
      ];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'venda_detalhe';
  @override
  VerificationContext validateIntegrity(Insertable<VendaDetalhe> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('id_venda_cabecalho')) {
      context.handle(
          _idVendaCabecalhoMeta,
          idVendaCabecalho.isAcceptableOrUnknown(
              data['id_venda_cabecalho']!, _idVendaCabecalhoMeta));
    }
    if (data.containsKey('id_produto')) {
      context.handle(_idProdutoMeta,
          idProduto.isAcceptableOrUnknown(data['id_produto']!, _idProdutoMeta));
    }
    if (data.containsKey('quantidade')) {
      context.handle(
          _quantidadeMeta,
          quantidade.isAcceptableOrUnknown(
              data['quantidade']!, _quantidadeMeta));
    }
    if (data.containsKey('valor_unitario')) {
      context.handle(
          _valorUnitarioMeta,
          valorUnitario.isAcceptableOrUnknown(
              data['valor_unitario']!, _valorUnitarioMeta));
    }
    if (data.containsKey('valor_subtotal')) {
      context.handle(
          _valorSubtotalMeta,
          valorSubtotal.isAcceptableOrUnknown(
              data['valor_subtotal']!, _valorSubtotalMeta));
    }
    if (data.containsKey('taxa_desconto')) {
      context.handle(
          _taxaDescontoMeta,
          taxaDesconto.isAcceptableOrUnknown(
              data['taxa_desconto']!, _taxaDescontoMeta));
    }
    if (data.containsKey('valor_desconto')) {
      context.handle(
          _valorDescontoMeta,
          valorDesconto.isAcceptableOrUnknown(
              data['valor_desconto']!, _valorDescontoMeta));
    }
    if (data.containsKey('valor_total')) {
      context.handle(
          _valorTotalMeta,
          valorTotal.isAcceptableOrUnknown(
              data['valor_total']!, _valorTotalMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  VendaDetalhe map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return VendaDetalhe(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id']),
      idVendaCabecalho: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id_venda_cabecalho']),
      idProduto: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id_produto']),
      quantidade: attachedDatabase.typeMapping
          .read(DriftSqlType.double, data['${effectivePrefix}quantidade']),
      valorUnitario: attachedDatabase.typeMapping
          .read(DriftSqlType.double, data['${effectivePrefix}valor_unitario']),
      valorSubtotal: attachedDatabase.typeMapping
          .read(DriftSqlType.double, data['${effectivePrefix}valor_subtotal']),
      taxaDesconto: attachedDatabase.typeMapping
          .read(DriftSqlType.double, data['${effectivePrefix}taxa_desconto']),
      valorDesconto: attachedDatabase.typeMapping
          .read(DriftSqlType.double, data['${effectivePrefix}valor_desconto']),
      valorTotal: attachedDatabase.typeMapping
          .read(DriftSqlType.double, data['${effectivePrefix}valor_total']),
    );
  }

  @override
  $VendaDetalhesTable createAlias(String alias) {
    return $VendaDetalhesTable(attachedDatabase, alias);
  }
}

class VendaDetalhe extends DataClass implements Insertable<VendaDetalhe> {
  final int? id;
  final int? idVendaCabecalho;
  final int? idProduto;
  final double? quantidade;
  final double? valorUnitario;
  final double? valorSubtotal;
  final double? taxaDesconto;
  final double? valorDesconto;
  final double? valorTotal;
  const VendaDetalhe(
      {this.id,
      this.idVendaCabecalho,
      this.idProduto,
      this.quantidade,
      this.valorUnitario,
      this.valorSubtotal,
      this.taxaDesconto,
      this.valorDesconto,
      this.valorTotal});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || idVendaCabecalho != null) {
      map['id_venda_cabecalho'] = Variable<int>(idVendaCabecalho);
    }
    if (!nullToAbsent || idProduto != null) {
      map['id_produto'] = Variable<int>(idProduto);
    }
    if (!nullToAbsent || quantidade != null) {
      map['quantidade'] = Variable<double>(quantidade);
    }
    if (!nullToAbsent || valorUnitario != null) {
      map['valor_unitario'] = Variable<double>(valorUnitario);
    }
    if (!nullToAbsent || valorSubtotal != null) {
      map['valor_subtotal'] = Variable<double>(valorSubtotal);
    }
    if (!nullToAbsent || taxaDesconto != null) {
      map['taxa_desconto'] = Variable<double>(taxaDesconto);
    }
    if (!nullToAbsent || valorDesconto != null) {
      map['valor_desconto'] = Variable<double>(valorDesconto);
    }
    if (!nullToAbsent || valorTotal != null) {
      map['valor_total'] = Variable<double>(valorTotal);
    }
    return map;
  }

  factory VendaDetalhe.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return VendaDetalhe(
      id: serializer.fromJson<int?>(json['id']),
      idVendaCabecalho: serializer.fromJson<int?>(json['idVendaCabecalho']),
      idProduto: serializer.fromJson<int?>(json['idProduto']),
      quantidade: serializer.fromJson<double?>(json['quantidade']),
      valorUnitario: serializer.fromJson<double?>(json['valorUnitario']),
      valorSubtotal: serializer.fromJson<double?>(json['valorSubtotal']),
      taxaDesconto: serializer.fromJson<double?>(json['taxaDesconto']),
      valorDesconto: serializer.fromJson<double?>(json['valorDesconto']),
      valorTotal: serializer.fromJson<double?>(json['valorTotal']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'idVendaCabecalho': serializer.toJson<int?>(idVendaCabecalho),
      'idProduto': serializer.toJson<int?>(idProduto),
      'quantidade': serializer.toJson<double?>(quantidade),
      'valorUnitario': serializer.toJson<double?>(valorUnitario),
      'valorSubtotal': serializer.toJson<double?>(valorSubtotal),
      'taxaDesconto': serializer.toJson<double?>(taxaDesconto),
      'valorDesconto': serializer.toJson<double?>(valorDesconto),
      'valorTotal': serializer.toJson<double?>(valorTotal),
    };
  }

  VendaDetalhe copyWith(
          {Value<int?> id = const Value.absent(),
          Value<int?> idVendaCabecalho = const Value.absent(),
          Value<int?> idProduto = const Value.absent(),
          Value<double?> quantidade = const Value.absent(),
          Value<double?> valorUnitario = const Value.absent(),
          Value<double?> valorSubtotal = const Value.absent(),
          Value<double?> taxaDesconto = const Value.absent(),
          Value<double?> valorDesconto = const Value.absent(),
          Value<double?> valorTotal = const Value.absent()}) =>
      VendaDetalhe(
        id: id.present ? id.value : this.id,
        idVendaCabecalho: idVendaCabecalho.present
            ? idVendaCabecalho.value
            : this.idVendaCabecalho,
        idProduto: idProduto.present ? idProduto.value : this.idProduto,
        quantidade: quantidade.present ? quantidade.value : this.quantidade,
        valorUnitario:
            valorUnitario.present ? valorUnitario.value : this.valorUnitario,
        valorSubtotal:
            valorSubtotal.present ? valorSubtotal.value : this.valorSubtotal,
        taxaDesconto:
            taxaDesconto.present ? taxaDesconto.value : this.taxaDesconto,
        valorDesconto:
            valorDesconto.present ? valorDesconto.value : this.valorDesconto,
        valorTotal: valorTotal.present ? valorTotal.value : this.valorTotal,
      );
  VendaDetalhe copyWithCompanion(VendaDetalhesCompanion data) {
    return VendaDetalhe(
      id: data.id.present ? data.id.value : this.id,
      idVendaCabecalho: data.idVendaCabecalho.present
          ? data.idVendaCabecalho.value
          : this.idVendaCabecalho,
      idProduto: data.idProduto.present ? data.idProduto.value : this.idProduto,
      quantidade:
          data.quantidade.present ? data.quantidade.value : this.quantidade,
      valorUnitario: data.valorUnitario.present
          ? data.valorUnitario.value
          : this.valorUnitario,
      valorSubtotal: data.valorSubtotal.present
          ? data.valorSubtotal.value
          : this.valorSubtotal,
      taxaDesconto: data.taxaDesconto.present
          ? data.taxaDesconto.value
          : this.taxaDesconto,
      valorDesconto: data.valorDesconto.present
          ? data.valorDesconto.value
          : this.valorDesconto,
      valorTotal:
          data.valorTotal.present ? data.valorTotal.value : this.valorTotal,
    );
  }

  @override
  String toString() {
    return (StringBuffer('VendaDetalhe(')
          ..write('id: $id, ')
          ..write('idVendaCabecalho: $idVendaCabecalho, ')
          ..write('idProduto: $idProduto, ')
          ..write('quantidade: $quantidade, ')
          ..write('valorUnitario: $valorUnitario, ')
          ..write('valorSubtotal: $valorSubtotal, ')
          ..write('taxaDesconto: $taxaDesconto, ')
          ..write('valorDesconto: $valorDesconto, ')
          ..write('valorTotal: $valorTotal')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(id, idVendaCabecalho, idProduto, quantidade,
      valorUnitario, valorSubtotal, taxaDesconto, valorDesconto, valorTotal);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is VendaDetalhe &&
          other.id == this.id &&
          other.idVendaCabecalho == this.idVendaCabecalho &&
          other.idProduto == this.idProduto &&
          other.quantidade == this.quantidade &&
          other.valorUnitario == this.valorUnitario &&
          other.valorSubtotal == this.valorSubtotal &&
          other.taxaDesconto == this.taxaDesconto &&
          other.valorDesconto == this.valorDesconto &&
          other.valorTotal == this.valorTotal);
}

class VendaDetalhesCompanion extends UpdateCompanion<VendaDetalhe> {
  final Value<int?> id;
  final Value<int?> idVendaCabecalho;
  final Value<int?> idProduto;
  final Value<double?> quantidade;
  final Value<double?> valorUnitario;
  final Value<double?> valorSubtotal;
  final Value<double?> taxaDesconto;
  final Value<double?> valorDesconto;
  final Value<double?> valorTotal;
  const VendaDetalhesCompanion({
    this.id = const Value.absent(),
    this.idVendaCabecalho = const Value.absent(),
    this.idProduto = const Value.absent(),
    this.quantidade = const Value.absent(),
    this.valorUnitario = const Value.absent(),
    this.valorSubtotal = const Value.absent(),
    this.taxaDesconto = const Value.absent(),
    this.valorDesconto = const Value.absent(),
    this.valorTotal = const Value.absent(),
  });
  VendaDetalhesCompanion.insert({
    this.id = const Value.absent(),
    this.idVendaCabecalho = const Value.absent(),
    this.idProduto = const Value.absent(),
    this.quantidade = const Value.absent(),
    this.valorUnitario = const Value.absent(),
    this.valorSubtotal = const Value.absent(),
    this.taxaDesconto = const Value.absent(),
    this.valorDesconto = const Value.absent(),
    this.valorTotal = const Value.absent(),
  });
  static Insertable<VendaDetalhe> custom({
    Expression<int>? id,
    Expression<int>? idVendaCabecalho,
    Expression<int>? idProduto,
    Expression<double>? quantidade,
    Expression<double>? valorUnitario,
    Expression<double>? valorSubtotal,
    Expression<double>? taxaDesconto,
    Expression<double>? valorDesconto,
    Expression<double>? valorTotal,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (idVendaCabecalho != null) 'id_venda_cabecalho': idVendaCabecalho,
      if (idProduto != null) 'id_produto': idProduto,
      if (quantidade != null) 'quantidade': quantidade,
      if (valorUnitario != null) 'valor_unitario': valorUnitario,
      if (valorSubtotal != null) 'valor_subtotal': valorSubtotal,
      if (taxaDesconto != null) 'taxa_desconto': taxaDesconto,
      if (valorDesconto != null) 'valor_desconto': valorDesconto,
      if (valorTotal != null) 'valor_total': valorTotal,
    });
  }

  VendaDetalhesCompanion copyWith(
      {Value<int?>? id,
      Value<int?>? idVendaCabecalho,
      Value<int?>? idProduto,
      Value<double?>? quantidade,
      Value<double?>? valorUnitario,
      Value<double?>? valorSubtotal,
      Value<double?>? taxaDesconto,
      Value<double?>? valorDesconto,
      Value<double?>? valorTotal}) {
    return VendaDetalhesCompanion(
      id: id ?? this.id,
      idVendaCabecalho: idVendaCabecalho ?? this.idVendaCabecalho,
      idProduto: idProduto ?? this.idProduto,
      quantidade: quantidade ?? this.quantidade,
      valorUnitario: valorUnitario ?? this.valorUnitario,
      valorSubtotal: valorSubtotal ?? this.valorSubtotal,
      taxaDesconto: taxaDesconto ?? this.taxaDesconto,
      valorDesconto: valorDesconto ?? this.valorDesconto,
      valorTotal: valorTotal ?? this.valorTotal,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (idVendaCabecalho.present) {
      map['id_venda_cabecalho'] = Variable<int>(idVendaCabecalho.value);
    }
    if (idProduto.present) {
      map['id_produto'] = Variable<int>(idProduto.value);
    }
    if (quantidade.present) {
      map['quantidade'] = Variable<double>(quantidade.value);
    }
    if (valorUnitario.present) {
      map['valor_unitario'] = Variable<double>(valorUnitario.value);
    }
    if (valorSubtotal.present) {
      map['valor_subtotal'] = Variable<double>(valorSubtotal.value);
    }
    if (taxaDesconto.present) {
      map['taxa_desconto'] = Variable<double>(taxaDesconto.value);
    }
    if (valorDesconto.present) {
      map['valor_desconto'] = Variable<double>(valorDesconto.value);
    }
    if (valorTotal.present) {
      map['valor_total'] = Variable<double>(valorTotal.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('VendaDetalhesCompanion(')
          ..write('id: $id, ')
          ..write('idVendaCabecalho: $idVendaCabecalho, ')
          ..write('idProduto: $idProduto, ')
          ..write('quantidade: $quantidade, ')
          ..write('valorUnitario: $valorUnitario, ')
          ..write('valorSubtotal: $valorSubtotal, ')
          ..write('taxaDesconto: $taxaDesconto, ')
          ..write('valorDesconto: $valorDesconto, ')
          ..write('valorTotal: $valorTotal')
          ..write(')'))
        .toString();
  }
}

class $VendaCondicoesParcelassTable extends VendaCondicoesParcelass
    with TableInfo<$VendaCondicoesParcelassTable, VendaCondicoesParcelas> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $VendaCondicoesParcelassTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
      'id', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _idVendaCondicoesPagamentoMeta =
      const VerificationMeta('idVendaCondicoesPagamento');
  @override
  late final GeneratedColumn<int> idVendaCondicoesPagamento =
      GeneratedColumn<int>('id_venda_condicoes_pagamento', aliasedName, true,
          type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _parcelaMeta =
      const VerificationMeta('parcela');
  @override
  late final GeneratedColumn<int> parcela = GeneratedColumn<int>(
      'parcela', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _diasMeta = const VerificationMeta('dias');
  @override
  late final GeneratedColumn<int> dias = GeneratedColumn<int>(
      'dias', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _taxaMeta = const VerificationMeta('taxa');
  @override
  late final GeneratedColumn<double> taxa = GeneratedColumn<double>(
      'taxa', aliasedName, true,
      type: DriftSqlType.double, requiredDuringInsert: false);
  @override
  List<GeneratedColumn> get $columns =>
      [id, idVendaCondicoesPagamento, parcela, dias, taxa];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'venda_condicoes_parcelas';
  @override
  VerificationContext validateIntegrity(
      Insertable<VendaCondicoesParcelas> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('id_venda_condicoes_pagamento')) {
      context.handle(
          _idVendaCondicoesPagamentoMeta,
          idVendaCondicoesPagamento.isAcceptableOrUnknown(
              data['id_venda_condicoes_pagamento']!,
              _idVendaCondicoesPagamentoMeta));
    }
    if (data.containsKey('parcela')) {
      context.handle(_parcelaMeta,
          parcela.isAcceptableOrUnknown(data['parcela']!, _parcelaMeta));
    }
    if (data.containsKey('dias')) {
      context.handle(
          _diasMeta, dias.isAcceptableOrUnknown(data['dias']!, _diasMeta));
    }
    if (data.containsKey('taxa')) {
      context.handle(
          _taxaMeta, taxa.isAcceptableOrUnknown(data['taxa']!, _taxaMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  VendaCondicoesParcelas map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return VendaCondicoesParcelas(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id']),
      idVendaCondicoesPagamento: attachedDatabase.typeMapping.read(
          DriftSqlType.int,
          data['${effectivePrefix}id_venda_condicoes_pagamento']),
      parcela: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}parcela']),
      dias: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}dias']),
      taxa: attachedDatabase.typeMapping
          .read(DriftSqlType.double, data['${effectivePrefix}taxa']),
    );
  }

  @override
  $VendaCondicoesParcelassTable createAlias(String alias) {
    return $VendaCondicoesParcelassTable(attachedDatabase, alias);
  }
}

class VendaCondicoesParcelas extends DataClass
    implements Insertable<VendaCondicoesParcelas> {
  final int? id;
  final int? idVendaCondicoesPagamento;
  final int? parcela;
  final int? dias;
  final double? taxa;
  const VendaCondicoesParcelas(
      {this.id,
      this.idVendaCondicoesPagamento,
      this.parcela,
      this.dias,
      this.taxa});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || idVendaCondicoesPagamento != null) {
      map['id_venda_condicoes_pagamento'] =
          Variable<int>(idVendaCondicoesPagamento);
    }
    if (!nullToAbsent || parcela != null) {
      map['parcela'] = Variable<int>(parcela);
    }
    if (!nullToAbsent || dias != null) {
      map['dias'] = Variable<int>(dias);
    }
    if (!nullToAbsent || taxa != null) {
      map['taxa'] = Variable<double>(taxa);
    }
    return map;
  }

  factory VendaCondicoesParcelas.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return VendaCondicoesParcelas(
      id: serializer.fromJson<int?>(json['id']),
      idVendaCondicoesPagamento:
          serializer.fromJson<int?>(json['idVendaCondicoesPagamento']),
      parcela: serializer.fromJson<int?>(json['parcela']),
      dias: serializer.fromJson<int?>(json['dias']),
      taxa: serializer.fromJson<double?>(json['taxa']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'idVendaCondicoesPagamento':
          serializer.toJson<int?>(idVendaCondicoesPagamento),
      'parcela': serializer.toJson<int?>(parcela),
      'dias': serializer.toJson<int?>(dias),
      'taxa': serializer.toJson<double?>(taxa),
    };
  }

  VendaCondicoesParcelas copyWith(
          {Value<int?> id = const Value.absent(),
          Value<int?> idVendaCondicoesPagamento = const Value.absent(),
          Value<int?> parcela = const Value.absent(),
          Value<int?> dias = const Value.absent(),
          Value<double?> taxa = const Value.absent()}) =>
      VendaCondicoesParcelas(
        id: id.present ? id.value : this.id,
        idVendaCondicoesPagamento: idVendaCondicoesPagamento.present
            ? idVendaCondicoesPagamento.value
            : this.idVendaCondicoesPagamento,
        parcela: parcela.present ? parcela.value : this.parcela,
        dias: dias.present ? dias.value : this.dias,
        taxa: taxa.present ? taxa.value : this.taxa,
      );
  VendaCondicoesParcelas copyWithCompanion(
      VendaCondicoesParcelassCompanion data) {
    return VendaCondicoesParcelas(
      id: data.id.present ? data.id.value : this.id,
      idVendaCondicoesPagamento: data.idVendaCondicoesPagamento.present
          ? data.idVendaCondicoesPagamento.value
          : this.idVendaCondicoesPagamento,
      parcela: data.parcela.present ? data.parcela.value : this.parcela,
      dias: data.dias.present ? data.dias.value : this.dias,
      taxa: data.taxa.present ? data.taxa.value : this.taxa,
    );
  }

  @override
  String toString() {
    return (StringBuffer('VendaCondicoesParcelas(')
          ..write('id: $id, ')
          ..write('idVendaCondicoesPagamento: $idVendaCondicoesPagamento, ')
          ..write('parcela: $parcela, ')
          ..write('dias: $dias, ')
          ..write('taxa: $taxa')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode =>
      Object.hash(id, idVendaCondicoesPagamento, parcela, dias, taxa);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is VendaCondicoesParcelas &&
          other.id == this.id &&
          other.idVendaCondicoesPagamento == this.idVendaCondicoesPagamento &&
          other.parcela == this.parcela &&
          other.dias == this.dias &&
          other.taxa == this.taxa);
}

class VendaCondicoesParcelassCompanion
    extends UpdateCompanion<VendaCondicoesParcelas> {
  final Value<int?> id;
  final Value<int?> idVendaCondicoesPagamento;
  final Value<int?> parcela;
  final Value<int?> dias;
  final Value<double?> taxa;
  const VendaCondicoesParcelassCompanion({
    this.id = const Value.absent(),
    this.idVendaCondicoesPagamento = const Value.absent(),
    this.parcela = const Value.absent(),
    this.dias = const Value.absent(),
    this.taxa = const Value.absent(),
  });
  VendaCondicoesParcelassCompanion.insert({
    this.id = const Value.absent(),
    this.idVendaCondicoesPagamento = const Value.absent(),
    this.parcela = const Value.absent(),
    this.dias = const Value.absent(),
    this.taxa = const Value.absent(),
  });
  static Insertable<VendaCondicoesParcelas> custom({
    Expression<int>? id,
    Expression<int>? idVendaCondicoesPagamento,
    Expression<int>? parcela,
    Expression<int>? dias,
    Expression<double>? taxa,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (idVendaCondicoesPagamento != null)
        'id_venda_condicoes_pagamento': idVendaCondicoesPagamento,
      if (parcela != null) 'parcela': parcela,
      if (dias != null) 'dias': dias,
      if (taxa != null) 'taxa': taxa,
    });
  }

  VendaCondicoesParcelassCompanion copyWith(
      {Value<int?>? id,
      Value<int?>? idVendaCondicoesPagamento,
      Value<int?>? parcela,
      Value<int?>? dias,
      Value<double?>? taxa}) {
    return VendaCondicoesParcelassCompanion(
      id: id ?? this.id,
      idVendaCondicoesPagamento:
          idVendaCondicoesPagamento ?? this.idVendaCondicoesPagamento,
      parcela: parcela ?? this.parcela,
      dias: dias ?? this.dias,
      taxa: taxa ?? this.taxa,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (idVendaCondicoesPagamento.present) {
      map['id_venda_condicoes_pagamento'] =
          Variable<int>(idVendaCondicoesPagamento.value);
    }
    if (parcela.present) {
      map['parcela'] = Variable<int>(parcela.value);
    }
    if (dias.present) {
      map['dias'] = Variable<int>(dias.value);
    }
    if (taxa.present) {
      map['taxa'] = Variable<double>(taxa.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('VendaCondicoesParcelassCompanion(')
          ..write('id: $id, ')
          ..write('idVendaCondicoesPagamento: $idVendaCondicoesPagamento, ')
          ..write('parcela: $parcela, ')
          ..write('dias: $dias, ')
          ..write('taxa: $taxa')
          ..write(')'))
        .toString();
  }
}

class $VendaFretesTable extends VendaFretes
    with TableInfo<$VendaFretesTable, VendaFrete> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $VendaFretesTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
      'id', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _idVendaCabecalhoMeta =
      const VerificationMeta('idVendaCabecalho');
  @override
  late final GeneratedColumn<int> idVendaCabecalho = GeneratedColumn<int>(
      'id_venda_cabecalho', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _idTransportadoraMeta =
      const VerificationMeta('idTransportadora');
  @override
  late final GeneratedColumn<int> idTransportadora = GeneratedColumn<int>(
      'id_transportadora', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _responsavelMeta =
      const VerificationMeta('responsavel');
  @override
  late final GeneratedColumn<String> responsavel = GeneratedColumn<String>(
      'responsavel', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 1),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _conhecimentoMeta =
      const VerificationMeta('conhecimento');
  @override
  late final GeneratedColumn<int> conhecimento = GeneratedColumn<int>(
      'conhecimento', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _placaMeta = const VerificationMeta('placa');
  @override
  late final GeneratedColumn<String> placa = GeneratedColumn<String>(
      'placa', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 7),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _ufPlacaMeta =
      const VerificationMeta('ufPlaca');
  @override
  late final GeneratedColumn<String> ufPlaca = GeneratedColumn<String>(
      'uf_placa', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 2),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _seloFiscalMeta =
      const VerificationMeta('seloFiscal');
  @override
  late final GeneratedColumn<int> seloFiscal = GeneratedColumn<int>(
      'selo_fiscal', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _quantidadeVolumeMeta =
      const VerificationMeta('quantidadeVolume');
  @override
  late final GeneratedColumn<double> quantidadeVolume = GeneratedColumn<double>(
      'quantidade_volume', aliasedName, true,
      type: DriftSqlType.double, requiredDuringInsert: false);
  static const VerificationMeta _marcaVolumeMeta =
      const VerificationMeta('marcaVolume');
  @override
  late final GeneratedColumn<String> marcaVolume = GeneratedColumn<String>(
      'marca_volume', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 50),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _especieVolumeMeta =
      const VerificationMeta('especieVolume');
  @override
  late final GeneratedColumn<String> especieVolume = GeneratedColumn<String>(
      'especie_volume', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 20),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _pesoBrutoMeta =
      const VerificationMeta('pesoBruto');
  @override
  late final GeneratedColumn<double> pesoBruto = GeneratedColumn<double>(
      'peso_bruto', aliasedName, true,
      type: DriftSqlType.double, requiredDuringInsert: false);
  static const VerificationMeta _pesoLiquidoMeta =
      const VerificationMeta('pesoLiquido');
  @override
  late final GeneratedColumn<double> pesoLiquido = GeneratedColumn<double>(
      'peso_liquido', aliasedName, true,
      type: DriftSqlType.double, requiredDuringInsert: false);
  @override
  List<GeneratedColumn> get $columns => [
        id,
        idVendaCabecalho,
        idTransportadora,
        responsavel,
        conhecimento,
        placa,
        ufPlaca,
        seloFiscal,
        quantidadeVolume,
        marcaVolume,
        especieVolume,
        pesoBruto,
        pesoLiquido
      ];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'venda_frete';
  @override
  VerificationContext validateIntegrity(Insertable<VendaFrete> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('id_venda_cabecalho')) {
      context.handle(
          _idVendaCabecalhoMeta,
          idVendaCabecalho.isAcceptableOrUnknown(
              data['id_venda_cabecalho']!, _idVendaCabecalhoMeta));
    }
    if (data.containsKey('id_transportadora')) {
      context.handle(
          _idTransportadoraMeta,
          idTransportadora.isAcceptableOrUnknown(
              data['id_transportadora']!, _idTransportadoraMeta));
    }
    if (data.containsKey('responsavel')) {
      context.handle(
          _responsavelMeta,
          responsavel.isAcceptableOrUnknown(
              data['responsavel']!, _responsavelMeta));
    }
    if (data.containsKey('conhecimento')) {
      context.handle(
          _conhecimentoMeta,
          conhecimento.isAcceptableOrUnknown(
              data['conhecimento']!, _conhecimentoMeta));
    }
    if (data.containsKey('placa')) {
      context.handle(
          _placaMeta, placa.isAcceptableOrUnknown(data['placa']!, _placaMeta));
    }
    if (data.containsKey('uf_placa')) {
      context.handle(_ufPlacaMeta,
          ufPlaca.isAcceptableOrUnknown(data['uf_placa']!, _ufPlacaMeta));
    }
    if (data.containsKey('selo_fiscal')) {
      context.handle(
          _seloFiscalMeta,
          seloFiscal.isAcceptableOrUnknown(
              data['selo_fiscal']!, _seloFiscalMeta));
    }
    if (data.containsKey('quantidade_volume')) {
      context.handle(
          _quantidadeVolumeMeta,
          quantidadeVolume.isAcceptableOrUnknown(
              data['quantidade_volume']!, _quantidadeVolumeMeta));
    }
    if (data.containsKey('marca_volume')) {
      context.handle(
          _marcaVolumeMeta,
          marcaVolume.isAcceptableOrUnknown(
              data['marca_volume']!, _marcaVolumeMeta));
    }
    if (data.containsKey('especie_volume')) {
      context.handle(
          _especieVolumeMeta,
          especieVolume.isAcceptableOrUnknown(
              data['especie_volume']!, _especieVolumeMeta));
    }
    if (data.containsKey('peso_bruto')) {
      context.handle(_pesoBrutoMeta,
          pesoBruto.isAcceptableOrUnknown(data['peso_bruto']!, _pesoBrutoMeta));
    }
    if (data.containsKey('peso_liquido')) {
      context.handle(
          _pesoLiquidoMeta,
          pesoLiquido.isAcceptableOrUnknown(
              data['peso_liquido']!, _pesoLiquidoMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  VendaFrete map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return VendaFrete(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id']),
      idVendaCabecalho: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id_venda_cabecalho']),
      idTransportadora: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id_transportadora']),
      responsavel: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}responsavel']),
      conhecimento: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}conhecimento']),
      placa: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}placa']),
      ufPlaca: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}uf_placa']),
      seloFiscal: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}selo_fiscal']),
      quantidadeVolume: attachedDatabase.typeMapping.read(
          DriftSqlType.double, data['${effectivePrefix}quantidade_volume']),
      marcaVolume: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}marca_volume']),
      especieVolume: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}especie_volume']),
      pesoBruto: attachedDatabase.typeMapping
          .read(DriftSqlType.double, data['${effectivePrefix}peso_bruto']),
      pesoLiquido: attachedDatabase.typeMapping
          .read(DriftSqlType.double, data['${effectivePrefix}peso_liquido']),
    );
  }

  @override
  $VendaFretesTable createAlias(String alias) {
    return $VendaFretesTable(attachedDatabase, alias);
  }
}

class VendaFrete extends DataClass implements Insertable<VendaFrete> {
  final int? id;
  final int? idVendaCabecalho;
  final int? idTransportadora;
  final String? responsavel;
  final int? conhecimento;
  final String? placa;
  final String? ufPlaca;
  final int? seloFiscal;
  final double? quantidadeVolume;
  final String? marcaVolume;
  final String? especieVolume;
  final double? pesoBruto;
  final double? pesoLiquido;
  const VendaFrete(
      {this.id,
      this.idVendaCabecalho,
      this.idTransportadora,
      this.responsavel,
      this.conhecimento,
      this.placa,
      this.ufPlaca,
      this.seloFiscal,
      this.quantidadeVolume,
      this.marcaVolume,
      this.especieVolume,
      this.pesoBruto,
      this.pesoLiquido});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || idVendaCabecalho != null) {
      map['id_venda_cabecalho'] = Variable<int>(idVendaCabecalho);
    }
    if (!nullToAbsent || idTransportadora != null) {
      map['id_transportadora'] = Variable<int>(idTransportadora);
    }
    if (!nullToAbsent || responsavel != null) {
      map['responsavel'] = Variable<String>(responsavel);
    }
    if (!nullToAbsent || conhecimento != null) {
      map['conhecimento'] = Variable<int>(conhecimento);
    }
    if (!nullToAbsent || placa != null) {
      map['placa'] = Variable<String>(placa);
    }
    if (!nullToAbsent || ufPlaca != null) {
      map['uf_placa'] = Variable<String>(ufPlaca);
    }
    if (!nullToAbsent || seloFiscal != null) {
      map['selo_fiscal'] = Variable<int>(seloFiscal);
    }
    if (!nullToAbsent || quantidadeVolume != null) {
      map['quantidade_volume'] = Variable<double>(quantidadeVolume);
    }
    if (!nullToAbsent || marcaVolume != null) {
      map['marca_volume'] = Variable<String>(marcaVolume);
    }
    if (!nullToAbsent || especieVolume != null) {
      map['especie_volume'] = Variable<String>(especieVolume);
    }
    if (!nullToAbsent || pesoBruto != null) {
      map['peso_bruto'] = Variable<double>(pesoBruto);
    }
    if (!nullToAbsent || pesoLiquido != null) {
      map['peso_liquido'] = Variable<double>(pesoLiquido);
    }
    return map;
  }

  factory VendaFrete.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return VendaFrete(
      id: serializer.fromJson<int?>(json['id']),
      idVendaCabecalho: serializer.fromJson<int?>(json['idVendaCabecalho']),
      idTransportadora: serializer.fromJson<int?>(json['idTransportadora']),
      responsavel: serializer.fromJson<String?>(json['responsavel']),
      conhecimento: serializer.fromJson<int?>(json['conhecimento']),
      placa: serializer.fromJson<String?>(json['placa']),
      ufPlaca: serializer.fromJson<String?>(json['ufPlaca']),
      seloFiscal: serializer.fromJson<int?>(json['seloFiscal']),
      quantidadeVolume: serializer.fromJson<double?>(json['quantidadeVolume']),
      marcaVolume: serializer.fromJson<String?>(json['marcaVolume']),
      especieVolume: serializer.fromJson<String?>(json['especieVolume']),
      pesoBruto: serializer.fromJson<double?>(json['pesoBruto']),
      pesoLiquido: serializer.fromJson<double?>(json['pesoLiquido']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'idVendaCabecalho': serializer.toJson<int?>(idVendaCabecalho),
      'idTransportadora': serializer.toJson<int?>(idTransportadora),
      'responsavel': serializer.toJson<String?>(responsavel),
      'conhecimento': serializer.toJson<int?>(conhecimento),
      'placa': serializer.toJson<String?>(placa),
      'ufPlaca': serializer.toJson<String?>(ufPlaca),
      'seloFiscal': serializer.toJson<int?>(seloFiscal),
      'quantidadeVolume': serializer.toJson<double?>(quantidadeVolume),
      'marcaVolume': serializer.toJson<String?>(marcaVolume),
      'especieVolume': serializer.toJson<String?>(especieVolume),
      'pesoBruto': serializer.toJson<double?>(pesoBruto),
      'pesoLiquido': serializer.toJson<double?>(pesoLiquido),
    };
  }

  VendaFrete copyWith(
          {Value<int?> id = const Value.absent(),
          Value<int?> idVendaCabecalho = const Value.absent(),
          Value<int?> idTransportadora = const Value.absent(),
          Value<String?> responsavel = const Value.absent(),
          Value<int?> conhecimento = const Value.absent(),
          Value<String?> placa = const Value.absent(),
          Value<String?> ufPlaca = const Value.absent(),
          Value<int?> seloFiscal = const Value.absent(),
          Value<double?> quantidadeVolume = const Value.absent(),
          Value<String?> marcaVolume = const Value.absent(),
          Value<String?> especieVolume = const Value.absent(),
          Value<double?> pesoBruto = const Value.absent(),
          Value<double?> pesoLiquido = const Value.absent()}) =>
      VendaFrete(
        id: id.present ? id.value : this.id,
        idVendaCabecalho: idVendaCabecalho.present
            ? idVendaCabecalho.value
            : this.idVendaCabecalho,
        idTransportadora: idTransportadora.present
            ? idTransportadora.value
            : this.idTransportadora,
        responsavel: responsavel.present ? responsavel.value : this.responsavel,
        conhecimento:
            conhecimento.present ? conhecimento.value : this.conhecimento,
        placa: placa.present ? placa.value : this.placa,
        ufPlaca: ufPlaca.present ? ufPlaca.value : this.ufPlaca,
        seloFiscal: seloFiscal.present ? seloFiscal.value : this.seloFiscal,
        quantidadeVolume: quantidadeVolume.present
            ? quantidadeVolume.value
            : this.quantidadeVolume,
        marcaVolume: marcaVolume.present ? marcaVolume.value : this.marcaVolume,
        especieVolume:
            especieVolume.present ? especieVolume.value : this.especieVolume,
        pesoBruto: pesoBruto.present ? pesoBruto.value : this.pesoBruto,
        pesoLiquido: pesoLiquido.present ? pesoLiquido.value : this.pesoLiquido,
      );
  VendaFrete copyWithCompanion(VendaFretesCompanion data) {
    return VendaFrete(
      id: data.id.present ? data.id.value : this.id,
      idVendaCabecalho: data.idVendaCabecalho.present
          ? data.idVendaCabecalho.value
          : this.idVendaCabecalho,
      idTransportadora: data.idTransportadora.present
          ? data.idTransportadora.value
          : this.idTransportadora,
      responsavel:
          data.responsavel.present ? data.responsavel.value : this.responsavel,
      conhecimento: data.conhecimento.present
          ? data.conhecimento.value
          : this.conhecimento,
      placa: data.placa.present ? data.placa.value : this.placa,
      ufPlaca: data.ufPlaca.present ? data.ufPlaca.value : this.ufPlaca,
      seloFiscal:
          data.seloFiscal.present ? data.seloFiscal.value : this.seloFiscal,
      quantidadeVolume: data.quantidadeVolume.present
          ? data.quantidadeVolume.value
          : this.quantidadeVolume,
      marcaVolume:
          data.marcaVolume.present ? data.marcaVolume.value : this.marcaVolume,
      especieVolume: data.especieVolume.present
          ? data.especieVolume.value
          : this.especieVolume,
      pesoBruto: data.pesoBruto.present ? data.pesoBruto.value : this.pesoBruto,
      pesoLiquido:
          data.pesoLiquido.present ? data.pesoLiquido.value : this.pesoLiquido,
    );
  }

  @override
  String toString() {
    return (StringBuffer('VendaFrete(')
          ..write('id: $id, ')
          ..write('idVendaCabecalho: $idVendaCabecalho, ')
          ..write('idTransportadora: $idTransportadora, ')
          ..write('responsavel: $responsavel, ')
          ..write('conhecimento: $conhecimento, ')
          ..write('placa: $placa, ')
          ..write('ufPlaca: $ufPlaca, ')
          ..write('seloFiscal: $seloFiscal, ')
          ..write('quantidadeVolume: $quantidadeVolume, ')
          ..write('marcaVolume: $marcaVolume, ')
          ..write('especieVolume: $especieVolume, ')
          ..write('pesoBruto: $pesoBruto, ')
          ..write('pesoLiquido: $pesoLiquido')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(
      id,
      idVendaCabecalho,
      idTransportadora,
      responsavel,
      conhecimento,
      placa,
      ufPlaca,
      seloFiscal,
      quantidadeVolume,
      marcaVolume,
      especieVolume,
      pesoBruto,
      pesoLiquido);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is VendaFrete &&
          other.id == this.id &&
          other.idVendaCabecalho == this.idVendaCabecalho &&
          other.idTransportadora == this.idTransportadora &&
          other.responsavel == this.responsavel &&
          other.conhecimento == this.conhecimento &&
          other.placa == this.placa &&
          other.ufPlaca == this.ufPlaca &&
          other.seloFiscal == this.seloFiscal &&
          other.quantidadeVolume == this.quantidadeVolume &&
          other.marcaVolume == this.marcaVolume &&
          other.especieVolume == this.especieVolume &&
          other.pesoBruto == this.pesoBruto &&
          other.pesoLiquido == this.pesoLiquido);
}

class VendaFretesCompanion extends UpdateCompanion<VendaFrete> {
  final Value<int?> id;
  final Value<int?> idVendaCabecalho;
  final Value<int?> idTransportadora;
  final Value<String?> responsavel;
  final Value<int?> conhecimento;
  final Value<String?> placa;
  final Value<String?> ufPlaca;
  final Value<int?> seloFiscal;
  final Value<double?> quantidadeVolume;
  final Value<String?> marcaVolume;
  final Value<String?> especieVolume;
  final Value<double?> pesoBruto;
  final Value<double?> pesoLiquido;
  const VendaFretesCompanion({
    this.id = const Value.absent(),
    this.idVendaCabecalho = const Value.absent(),
    this.idTransportadora = const Value.absent(),
    this.responsavel = const Value.absent(),
    this.conhecimento = const Value.absent(),
    this.placa = const Value.absent(),
    this.ufPlaca = const Value.absent(),
    this.seloFiscal = const Value.absent(),
    this.quantidadeVolume = const Value.absent(),
    this.marcaVolume = const Value.absent(),
    this.especieVolume = const Value.absent(),
    this.pesoBruto = const Value.absent(),
    this.pesoLiquido = const Value.absent(),
  });
  VendaFretesCompanion.insert({
    this.id = const Value.absent(),
    this.idVendaCabecalho = const Value.absent(),
    this.idTransportadora = const Value.absent(),
    this.responsavel = const Value.absent(),
    this.conhecimento = const Value.absent(),
    this.placa = const Value.absent(),
    this.ufPlaca = const Value.absent(),
    this.seloFiscal = const Value.absent(),
    this.quantidadeVolume = const Value.absent(),
    this.marcaVolume = const Value.absent(),
    this.especieVolume = const Value.absent(),
    this.pesoBruto = const Value.absent(),
    this.pesoLiquido = const Value.absent(),
  });
  static Insertable<VendaFrete> custom({
    Expression<int>? id,
    Expression<int>? idVendaCabecalho,
    Expression<int>? idTransportadora,
    Expression<String>? responsavel,
    Expression<int>? conhecimento,
    Expression<String>? placa,
    Expression<String>? ufPlaca,
    Expression<int>? seloFiscal,
    Expression<double>? quantidadeVolume,
    Expression<String>? marcaVolume,
    Expression<String>? especieVolume,
    Expression<double>? pesoBruto,
    Expression<double>? pesoLiquido,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (idVendaCabecalho != null) 'id_venda_cabecalho': idVendaCabecalho,
      if (idTransportadora != null) 'id_transportadora': idTransportadora,
      if (responsavel != null) 'responsavel': responsavel,
      if (conhecimento != null) 'conhecimento': conhecimento,
      if (placa != null) 'placa': placa,
      if (ufPlaca != null) 'uf_placa': ufPlaca,
      if (seloFiscal != null) 'selo_fiscal': seloFiscal,
      if (quantidadeVolume != null) 'quantidade_volume': quantidadeVolume,
      if (marcaVolume != null) 'marca_volume': marcaVolume,
      if (especieVolume != null) 'especie_volume': especieVolume,
      if (pesoBruto != null) 'peso_bruto': pesoBruto,
      if (pesoLiquido != null) 'peso_liquido': pesoLiquido,
    });
  }

  VendaFretesCompanion copyWith(
      {Value<int?>? id,
      Value<int?>? idVendaCabecalho,
      Value<int?>? idTransportadora,
      Value<String?>? responsavel,
      Value<int?>? conhecimento,
      Value<String?>? placa,
      Value<String?>? ufPlaca,
      Value<int?>? seloFiscal,
      Value<double?>? quantidadeVolume,
      Value<String?>? marcaVolume,
      Value<String?>? especieVolume,
      Value<double?>? pesoBruto,
      Value<double?>? pesoLiquido}) {
    return VendaFretesCompanion(
      id: id ?? this.id,
      idVendaCabecalho: idVendaCabecalho ?? this.idVendaCabecalho,
      idTransportadora: idTransportadora ?? this.idTransportadora,
      responsavel: responsavel ?? this.responsavel,
      conhecimento: conhecimento ?? this.conhecimento,
      placa: placa ?? this.placa,
      ufPlaca: ufPlaca ?? this.ufPlaca,
      seloFiscal: seloFiscal ?? this.seloFiscal,
      quantidadeVolume: quantidadeVolume ?? this.quantidadeVolume,
      marcaVolume: marcaVolume ?? this.marcaVolume,
      especieVolume: especieVolume ?? this.especieVolume,
      pesoBruto: pesoBruto ?? this.pesoBruto,
      pesoLiquido: pesoLiquido ?? this.pesoLiquido,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (idVendaCabecalho.present) {
      map['id_venda_cabecalho'] = Variable<int>(idVendaCabecalho.value);
    }
    if (idTransportadora.present) {
      map['id_transportadora'] = Variable<int>(idTransportadora.value);
    }
    if (responsavel.present) {
      map['responsavel'] = Variable<String>(responsavel.value);
    }
    if (conhecimento.present) {
      map['conhecimento'] = Variable<int>(conhecimento.value);
    }
    if (placa.present) {
      map['placa'] = Variable<String>(placa.value);
    }
    if (ufPlaca.present) {
      map['uf_placa'] = Variable<String>(ufPlaca.value);
    }
    if (seloFiscal.present) {
      map['selo_fiscal'] = Variable<int>(seloFiscal.value);
    }
    if (quantidadeVolume.present) {
      map['quantidade_volume'] = Variable<double>(quantidadeVolume.value);
    }
    if (marcaVolume.present) {
      map['marca_volume'] = Variable<String>(marcaVolume.value);
    }
    if (especieVolume.present) {
      map['especie_volume'] = Variable<String>(especieVolume.value);
    }
    if (pesoBruto.present) {
      map['peso_bruto'] = Variable<double>(pesoBruto.value);
    }
    if (pesoLiquido.present) {
      map['peso_liquido'] = Variable<double>(pesoLiquido.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('VendaFretesCompanion(')
          ..write('id: $id, ')
          ..write('idVendaCabecalho: $idVendaCabecalho, ')
          ..write('idTransportadora: $idTransportadora, ')
          ..write('responsavel: $responsavel, ')
          ..write('conhecimento: $conhecimento, ')
          ..write('placa: $placa, ')
          ..write('ufPlaca: $ufPlaca, ')
          ..write('seloFiscal: $seloFiscal, ')
          ..write('quantidadeVolume: $quantidadeVolume, ')
          ..write('marcaVolume: $marcaVolume, ')
          ..write('especieVolume: $especieVolume, ')
          ..write('pesoBruto: $pesoBruto, ')
          ..write('pesoLiquido: $pesoLiquido')
          ..write(')'))
        .toString();
  }
}

class $VendaComissaosTable extends VendaComissaos
    with TableInfo<$VendaComissaosTable, VendaComissao> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $VendaComissaosTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
      'id', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _idVendaCabecalhoMeta =
      const VerificationMeta('idVendaCabecalho');
  @override
  late final GeneratedColumn<int> idVendaCabecalho = GeneratedColumn<int>(
      'id_venda_cabecalho', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _idVendedorMeta =
      const VerificationMeta('idVendedor');
  @override
  late final GeneratedColumn<int> idVendedor = GeneratedColumn<int>(
      'id_vendedor', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _valorVendaMeta =
      const VerificationMeta('valorVenda');
  @override
  late final GeneratedColumn<double> valorVenda = GeneratedColumn<double>(
      'valor_venda', aliasedName, true,
      type: DriftSqlType.double, requiredDuringInsert: false);
  static const VerificationMeta _tipoContabilMeta =
      const VerificationMeta('tipoContabil');
  @override
  late final GeneratedColumn<String> tipoContabil = GeneratedColumn<String>(
      'tipo_contabil', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 1),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _valorComissaoMeta =
      const VerificationMeta('valorComissao');
  @override
  late final GeneratedColumn<double> valorComissao = GeneratedColumn<double>(
      'valor_comissao', aliasedName, true,
      type: DriftSqlType.double, requiredDuringInsert: false);
  static const VerificationMeta _situacaoMeta =
      const VerificationMeta('situacao');
  @override
  late final GeneratedColumn<String> situacao = GeneratedColumn<String>(
      'situacao', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 1),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _dataLancamentoMeta =
      const VerificationMeta('dataLancamento');
  @override
  late final GeneratedColumn<DateTime> dataLancamento =
      GeneratedColumn<DateTime>('data_lancamento', aliasedName, true,
          type: DriftSqlType.dateTime, requiredDuringInsert: false);
  @override
  List<GeneratedColumn> get $columns => [
        id,
        idVendaCabecalho,
        idVendedor,
        valorVenda,
        tipoContabil,
        valorComissao,
        situacao,
        dataLancamento
      ];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'venda_comissao';
  @override
  VerificationContext validateIntegrity(Insertable<VendaComissao> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('id_venda_cabecalho')) {
      context.handle(
          _idVendaCabecalhoMeta,
          idVendaCabecalho.isAcceptableOrUnknown(
              data['id_venda_cabecalho']!, _idVendaCabecalhoMeta));
    }
    if (data.containsKey('id_vendedor')) {
      context.handle(
          _idVendedorMeta,
          idVendedor.isAcceptableOrUnknown(
              data['id_vendedor']!, _idVendedorMeta));
    }
    if (data.containsKey('valor_venda')) {
      context.handle(
          _valorVendaMeta,
          valorVenda.isAcceptableOrUnknown(
              data['valor_venda']!, _valorVendaMeta));
    }
    if (data.containsKey('tipo_contabil')) {
      context.handle(
          _tipoContabilMeta,
          tipoContabil.isAcceptableOrUnknown(
              data['tipo_contabil']!, _tipoContabilMeta));
    }
    if (data.containsKey('valor_comissao')) {
      context.handle(
          _valorComissaoMeta,
          valorComissao.isAcceptableOrUnknown(
              data['valor_comissao']!, _valorComissaoMeta));
    }
    if (data.containsKey('situacao')) {
      context.handle(_situacaoMeta,
          situacao.isAcceptableOrUnknown(data['situacao']!, _situacaoMeta));
    }
    if (data.containsKey('data_lancamento')) {
      context.handle(
          _dataLancamentoMeta,
          dataLancamento.isAcceptableOrUnknown(
              data['data_lancamento']!, _dataLancamentoMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  VendaComissao map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return VendaComissao(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id']),
      idVendaCabecalho: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id_venda_cabecalho']),
      idVendedor: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id_vendedor']),
      valorVenda: attachedDatabase.typeMapping
          .read(DriftSqlType.double, data['${effectivePrefix}valor_venda']),
      tipoContabil: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}tipo_contabil']),
      valorComissao: attachedDatabase.typeMapping
          .read(DriftSqlType.double, data['${effectivePrefix}valor_comissao']),
      situacao: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}situacao']),
      dataLancamento: attachedDatabase.typeMapping.read(
          DriftSqlType.dateTime, data['${effectivePrefix}data_lancamento']),
    );
  }

  @override
  $VendaComissaosTable createAlias(String alias) {
    return $VendaComissaosTable(attachedDatabase, alias);
  }
}

class VendaComissao extends DataClass implements Insertable<VendaComissao> {
  final int? id;
  final int? idVendaCabecalho;
  final int? idVendedor;
  final double? valorVenda;
  final String? tipoContabil;
  final double? valorComissao;
  final String? situacao;
  final DateTime? dataLancamento;
  const VendaComissao(
      {this.id,
      this.idVendaCabecalho,
      this.idVendedor,
      this.valorVenda,
      this.tipoContabil,
      this.valorComissao,
      this.situacao,
      this.dataLancamento});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || idVendaCabecalho != null) {
      map['id_venda_cabecalho'] = Variable<int>(idVendaCabecalho);
    }
    if (!nullToAbsent || idVendedor != null) {
      map['id_vendedor'] = Variable<int>(idVendedor);
    }
    if (!nullToAbsent || valorVenda != null) {
      map['valor_venda'] = Variable<double>(valorVenda);
    }
    if (!nullToAbsent || tipoContabil != null) {
      map['tipo_contabil'] = Variable<String>(tipoContabil);
    }
    if (!nullToAbsent || valorComissao != null) {
      map['valor_comissao'] = Variable<double>(valorComissao);
    }
    if (!nullToAbsent || situacao != null) {
      map['situacao'] = Variable<String>(situacao);
    }
    if (!nullToAbsent || dataLancamento != null) {
      map['data_lancamento'] = Variable<DateTime>(dataLancamento);
    }
    return map;
  }

  factory VendaComissao.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return VendaComissao(
      id: serializer.fromJson<int?>(json['id']),
      idVendaCabecalho: serializer.fromJson<int?>(json['idVendaCabecalho']),
      idVendedor: serializer.fromJson<int?>(json['idVendedor']),
      valorVenda: serializer.fromJson<double?>(json['valorVenda']),
      tipoContabil: serializer.fromJson<String?>(json['tipoContabil']),
      valorComissao: serializer.fromJson<double?>(json['valorComissao']),
      situacao: serializer.fromJson<String?>(json['situacao']),
      dataLancamento: serializer.fromJson<DateTime?>(json['dataLancamento']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'idVendaCabecalho': serializer.toJson<int?>(idVendaCabecalho),
      'idVendedor': serializer.toJson<int?>(idVendedor),
      'valorVenda': serializer.toJson<double?>(valorVenda),
      'tipoContabil': serializer.toJson<String?>(tipoContabil),
      'valorComissao': serializer.toJson<double?>(valorComissao),
      'situacao': serializer.toJson<String?>(situacao),
      'dataLancamento': serializer.toJson<DateTime?>(dataLancamento),
    };
  }

  VendaComissao copyWith(
          {Value<int?> id = const Value.absent(),
          Value<int?> idVendaCabecalho = const Value.absent(),
          Value<int?> idVendedor = const Value.absent(),
          Value<double?> valorVenda = const Value.absent(),
          Value<String?> tipoContabil = const Value.absent(),
          Value<double?> valorComissao = const Value.absent(),
          Value<String?> situacao = const Value.absent(),
          Value<DateTime?> dataLancamento = const Value.absent()}) =>
      VendaComissao(
        id: id.present ? id.value : this.id,
        idVendaCabecalho: idVendaCabecalho.present
            ? idVendaCabecalho.value
            : this.idVendaCabecalho,
        idVendedor: idVendedor.present ? idVendedor.value : this.idVendedor,
        valorVenda: valorVenda.present ? valorVenda.value : this.valorVenda,
        tipoContabil:
            tipoContabil.present ? tipoContabil.value : this.tipoContabil,
        valorComissao:
            valorComissao.present ? valorComissao.value : this.valorComissao,
        situacao: situacao.present ? situacao.value : this.situacao,
        dataLancamento:
            dataLancamento.present ? dataLancamento.value : this.dataLancamento,
      );
  VendaComissao copyWithCompanion(VendaComissaosCompanion data) {
    return VendaComissao(
      id: data.id.present ? data.id.value : this.id,
      idVendaCabecalho: data.idVendaCabecalho.present
          ? data.idVendaCabecalho.value
          : this.idVendaCabecalho,
      idVendedor:
          data.idVendedor.present ? data.idVendedor.value : this.idVendedor,
      valorVenda:
          data.valorVenda.present ? data.valorVenda.value : this.valorVenda,
      tipoContabil: data.tipoContabil.present
          ? data.tipoContabil.value
          : this.tipoContabil,
      valorComissao: data.valorComissao.present
          ? data.valorComissao.value
          : this.valorComissao,
      situacao: data.situacao.present ? data.situacao.value : this.situacao,
      dataLancamento: data.dataLancamento.present
          ? data.dataLancamento.value
          : this.dataLancamento,
    );
  }

  @override
  String toString() {
    return (StringBuffer('VendaComissao(')
          ..write('id: $id, ')
          ..write('idVendaCabecalho: $idVendaCabecalho, ')
          ..write('idVendedor: $idVendedor, ')
          ..write('valorVenda: $valorVenda, ')
          ..write('tipoContabil: $tipoContabil, ')
          ..write('valorComissao: $valorComissao, ')
          ..write('situacao: $situacao, ')
          ..write('dataLancamento: $dataLancamento')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(id, idVendaCabecalho, idVendedor, valorVenda,
      tipoContabil, valorComissao, situacao, dataLancamento);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is VendaComissao &&
          other.id == this.id &&
          other.idVendaCabecalho == this.idVendaCabecalho &&
          other.idVendedor == this.idVendedor &&
          other.valorVenda == this.valorVenda &&
          other.tipoContabil == this.tipoContabil &&
          other.valorComissao == this.valorComissao &&
          other.situacao == this.situacao &&
          other.dataLancamento == this.dataLancamento);
}

class VendaComissaosCompanion extends UpdateCompanion<VendaComissao> {
  final Value<int?> id;
  final Value<int?> idVendaCabecalho;
  final Value<int?> idVendedor;
  final Value<double?> valorVenda;
  final Value<String?> tipoContabil;
  final Value<double?> valorComissao;
  final Value<String?> situacao;
  final Value<DateTime?> dataLancamento;
  const VendaComissaosCompanion({
    this.id = const Value.absent(),
    this.idVendaCabecalho = const Value.absent(),
    this.idVendedor = const Value.absent(),
    this.valorVenda = const Value.absent(),
    this.tipoContabil = const Value.absent(),
    this.valorComissao = const Value.absent(),
    this.situacao = const Value.absent(),
    this.dataLancamento = const Value.absent(),
  });
  VendaComissaosCompanion.insert({
    this.id = const Value.absent(),
    this.idVendaCabecalho = const Value.absent(),
    this.idVendedor = const Value.absent(),
    this.valorVenda = const Value.absent(),
    this.tipoContabil = const Value.absent(),
    this.valorComissao = const Value.absent(),
    this.situacao = const Value.absent(),
    this.dataLancamento = const Value.absent(),
  });
  static Insertable<VendaComissao> custom({
    Expression<int>? id,
    Expression<int>? idVendaCabecalho,
    Expression<int>? idVendedor,
    Expression<double>? valorVenda,
    Expression<String>? tipoContabil,
    Expression<double>? valorComissao,
    Expression<String>? situacao,
    Expression<DateTime>? dataLancamento,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (idVendaCabecalho != null) 'id_venda_cabecalho': idVendaCabecalho,
      if (idVendedor != null) 'id_vendedor': idVendedor,
      if (valorVenda != null) 'valor_venda': valorVenda,
      if (tipoContabil != null) 'tipo_contabil': tipoContabil,
      if (valorComissao != null) 'valor_comissao': valorComissao,
      if (situacao != null) 'situacao': situacao,
      if (dataLancamento != null) 'data_lancamento': dataLancamento,
    });
  }

  VendaComissaosCompanion copyWith(
      {Value<int?>? id,
      Value<int?>? idVendaCabecalho,
      Value<int?>? idVendedor,
      Value<double?>? valorVenda,
      Value<String?>? tipoContabil,
      Value<double?>? valorComissao,
      Value<String?>? situacao,
      Value<DateTime?>? dataLancamento}) {
    return VendaComissaosCompanion(
      id: id ?? this.id,
      idVendaCabecalho: idVendaCabecalho ?? this.idVendaCabecalho,
      idVendedor: idVendedor ?? this.idVendedor,
      valorVenda: valorVenda ?? this.valorVenda,
      tipoContabil: tipoContabil ?? this.tipoContabil,
      valorComissao: valorComissao ?? this.valorComissao,
      situacao: situacao ?? this.situacao,
      dataLancamento: dataLancamento ?? this.dataLancamento,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (idVendaCabecalho.present) {
      map['id_venda_cabecalho'] = Variable<int>(idVendaCabecalho.value);
    }
    if (idVendedor.present) {
      map['id_vendedor'] = Variable<int>(idVendedor.value);
    }
    if (valorVenda.present) {
      map['valor_venda'] = Variable<double>(valorVenda.value);
    }
    if (tipoContabil.present) {
      map['tipo_contabil'] = Variable<String>(tipoContabil.value);
    }
    if (valorComissao.present) {
      map['valor_comissao'] = Variable<double>(valorComissao.value);
    }
    if (situacao.present) {
      map['situacao'] = Variable<String>(situacao.value);
    }
    if (dataLancamento.present) {
      map['data_lancamento'] = Variable<DateTime>(dataLancamento.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('VendaComissaosCompanion(')
          ..write('id: $id, ')
          ..write('idVendaCabecalho: $idVendaCabecalho, ')
          ..write('idVendedor: $idVendedor, ')
          ..write('valorVenda: $valorVenda, ')
          ..write('tipoContabil: $tipoContabil, ')
          ..write('valorComissao: $valorComissao, ')
          ..write('situacao: $situacao, ')
          ..write('dataLancamento: $dataLancamento')
          ..write(')'))
        .toString();
  }
}

class $ProdutoGruposTable extends ProdutoGrupos
    with TableInfo<$ProdutoGruposTable, ProdutoGrupo> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $ProdutoGruposTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
      'id', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _nomeMeta = const VerificationMeta('nome');
  @override
  late final GeneratedColumn<String> nome = GeneratedColumn<String>(
      'nome', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 100),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _descricaoMeta =
      const VerificationMeta('descricao');
  @override
  late final GeneratedColumn<String> descricao = GeneratedColumn<String>(
      'descricao', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 250),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  @override
  List<GeneratedColumn> get $columns => [id, nome, descricao];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'produto_grupo';
  @override
  VerificationContext validateIntegrity(Insertable<ProdutoGrupo> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('nome')) {
      context.handle(
          _nomeMeta, nome.isAcceptableOrUnknown(data['nome']!, _nomeMeta));
    }
    if (data.containsKey('descricao')) {
      context.handle(_descricaoMeta,
          descricao.isAcceptableOrUnknown(data['descricao']!, _descricaoMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  ProdutoGrupo map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return ProdutoGrupo(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id']),
      nome: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}nome']),
      descricao: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}descricao']),
    );
  }

  @override
  $ProdutoGruposTable createAlias(String alias) {
    return $ProdutoGruposTable(attachedDatabase, alias);
  }
}

class ProdutoGrupo extends DataClass implements Insertable<ProdutoGrupo> {
  final int? id;
  final String? nome;
  final String? descricao;
  const ProdutoGrupo({this.id, this.nome, this.descricao});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || nome != null) {
      map['nome'] = Variable<String>(nome);
    }
    if (!nullToAbsent || descricao != null) {
      map['descricao'] = Variable<String>(descricao);
    }
    return map;
  }

  factory ProdutoGrupo.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return ProdutoGrupo(
      id: serializer.fromJson<int?>(json['id']),
      nome: serializer.fromJson<String?>(json['nome']),
      descricao: serializer.fromJson<String?>(json['descricao']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'nome': serializer.toJson<String?>(nome),
      'descricao': serializer.toJson<String?>(descricao),
    };
  }

  ProdutoGrupo copyWith(
          {Value<int?> id = const Value.absent(),
          Value<String?> nome = const Value.absent(),
          Value<String?> descricao = const Value.absent()}) =>
      ProdutoGrupo(
        id: id.present ? id.value : this.id,
        nome: nome.present ? nome.value : this.nome,
        descricao: descricao.present ? descricao.value : this.descricao,
      );
  ProdutoGrupo copyWithCompanion(ProdutoGruposCompanion data) {
    return ProdutoGrupo(
      id: data.id.present ? data.id.value : this.id,
      nome: data.nome.present ? data.nome.value : this.nome,
      descricao: data.descricao.present ? data.descricao.value : this.descricao,
    );
  }

  @override
  String toString() {
    return (StringBuffer('ProdutoGrupo(')
          ..write('id: $id, ')
          ..write('nome: $nome, ')
          ..write('descricao: $descricao')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(id, nome, descricao);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is ProdutoGrupo &&
          other.id == this.id &&
          other.nome == this.nome &&
          other.descricao == this.descricao);
}

class ProdutoGruposCompanion extends UpdateCompanion<ProdutoGrupo> {
  final Value<int?> id;
  final Value<String?> nome;
  final Value<String?> descricao;
  const ProdutoGruposCompanion({
    this.id = const Value.absent(),
    this.nome = const Value.absent(),
    this.descricao = const Value.absent(),
  });
  ProdutoGruposCompanion.insert({
    this.id = const Value.absent(),
    this.nome = const Value.absent(),
    this.descricao = const Value.absent(),
  });
  static Insertable<ProdutoGrupo> custom({
    Expression<int>? id,
    Expression<String>? nome,
    Expression<String>? descricao,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (nome != null) 'nome': nome,
      if (descricao != null) 'descricao': descricao,
    });
  }

  ProdutoGruposCompanion copyWith(
      {Value<int?>? id, Value<String?>? nome, Value<String?>? descricao}) {
    return ProdutoGruposCompanion(
      id: id ?? this.id,
      nome: nome ?? this.nome,
      descricao: descricao ?? this.descricao,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (nome.present) {
      map['nome'] = Variable<String>(nome.value);
    }
    if (descricao.present) {
      map['descricao'] = Variable<String>(descricao.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('ProdutoGruposCompanion(')
          ..write('id: $id, ')
          ..write('nome: $nome, ')
          ..write('descricao: $descricao')
          ..write(')'))
        .toString();
  }
}

class $ProdutoSubgruposTable extends ProdutoSubgrupos
    with TableInfo<$ProdutoSubgruposTable, ProdutoSubgrupo> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $ProdutoSubgruposTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
      'id', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _idProdutoGrupoMeta =
      const VerificationMeta('idProdutoGrupo');
  @override
  late final GeneratedColumn<int> idProdutoGrupo = GeneratedColumn<int>(
      'id_produto_grupo', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _nomeMeta = const VerificationMeta('nome');
  @override
  late final GeneratedColumn<String> nome = GeneratedColumn<String>(
      'nome', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 100),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _descricaoMeta =
      const VerificationMeta('descricao');
  @override
  late final GeneratedColumn<String> descricao = GeneratedColumn<String>(
      'descricao', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 250),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  @override
  List<GeneratedColumn> get $columns => [id, idProdutoGrupo, nome, descricao];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'produto_subgrupo';
  @override
  VerificationContext validateIntegrity(Insertable<ProdutoSubgrupo> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('id_produto_grupo')) {
      context.handle(
          _idProdutoGrupoMeta,
          idProdutoGrupo.isAcceptableOrUnknown(
              data['id_produto_grupo']!, _idProdutoGrupoMeta));
    }
    if (data.containsKey('nome')) {
      context.handle(
          _nomeMeta, nome.isAcceptableOrUnknown(data['nome']!, _nomeMeta));
    }
    if (data.containsKey('descricao')) {
      context.handle(_descricaoMeta,
          descricao.isAcceptableOrUnknown(data['descricao']!, _descricaoMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  ProdutoSubgrupo map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return ProdutoSubgrupo(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id']),
      idProdutoGrupo: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id_produto_grupo']),
      nome: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}nome']),
      descricao: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}descricao']),
    );
  }

  @override
  $ProdutoSubgruposTable createAlias(String alias) {
    return $ProdutoSubgruposTable(attachedDatabase, alias);
  }
}

class ProdutoSubgrupo extends DataClass implements Insertable<ProdutoSubgrupo> {
  final int? id;
  final int? idProdutoGrupo;
  final String? nome;
  final String? descricao;
  const ProdutoSubgrupo(
      {this.id, this.idProdutoGrupo, this.nome, this.descricao});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || idProdutoGrupo != null) {
      map['id_produto_grupo'] = Variable<int>(idProdutoGrupo);
    }
    if (!nullToAbsent || nome != null) {
      map['nome'] = Variable<String>(nome);
    }
    if (!nullToAbsent || descricao != null) {
      map['descricao'] = Variable<String>(descricao);
    }
    return map;
  }

  factory ProdutoSubgrupo.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return ProdutoSubgrupo(
      id: serializer.fromJson<int?>(json['id']),
      idProdutoGrupo: serializer.fromJson<int?>(json['idProdutoGrupo']),
      nome: serializer.fromJson<String?>(json['nome']),
      descricao: serializer.fromJson<String?>(json['descricao']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'idProdutoGrupo': serializer.toJson<int?>(idProdutoGrupo),
      'nome': serializer.toJson<String?>(nome),
      'descricao': serializer.toJson<String?>(descricao),
    };
  }

  ProdutoSubgrupo copyWith(
          {Value<int?> id = const Value.absent(),
          Value<int?> idProdutoGrupo = const Value.absent(),
          Value<String?> nome = const Value.absent(),
          Value<String?> descricao = const Value.absent()}) =>
      ProdutoSubgrupo(
        id: id.present ? id.value : this.id,
        idProdutoGrupo:
            idProdutoGrupo.present ? idProdutoGrupo.value : this.idProdutoGrupo,
        nome: nome.present ? nome.value : this.nome,
        descricao: descricao.present ? descricao.value : this.descricao,
      );
  ProdutoSubgrupo copyWithCompanion(ProdutoSubgruposCompanion data) {
    return ProdutoSubgrupo(
      id: data.id.present ? data.id.value : this.id,
      idProdutoGrupo: data.idProdutoGrupo.present
          ? data.idProdutoGrupo.value
          : this.idProdutoGrupo,
      nome: data.nome.present ? data.nome.value : this.nome,
      descricao: data.descricao.present ? data.descricao.value : this.descricao,
    );
  }

  @override
  String toString() {
    return (StringBuffer('ProdutoSubgrupo(')
          ..write('id: $id, ')
          ..write('idProdutoGrupo: $idProdutoGrupo, ')
          ..write('nome: $nome, ')
          ..write('descricao: $descricao')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(id, idProdutoGrupo, nome, descricao);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is ProdutoSubgrupo &&
          other.id == this.id &&
          other.idProdutoGrupo == this.idProdutoGrupo &&
          other.nome == this.nome &&
          other.descricao == this.descricao);
}

class ProdutoSubgruposCompanion extends UpdateCompanion<ProdutoSubgrupo> {
  final Value<int?> id;
  final Value<int?> idProdutoGrupo;
  final Value<String?> nome;
  final Value<String?> descricao;
  const ProdutoSubgruposCompanion({
    this.id = const Value.absent(),
    this.idProdutoGrupo = const Value.absent(),
    this.nome = const Value.absent(),
    this.descricao = const Value.absent(),
  });
  ProdutoSubgruposCompanion.insert({
    this.id = const Value.absent(),
    this.idProdutoGrupo = const Value.absent(),
    this.nome = const Value.absent(),
    this.descricao = const Value.absent(),
  });
  static Insertable<ProdutoSubgrupo> custom({
    Expression<int>? id,
    Expression<int>? idProdutoGrupo,
    Expression<String>? nome,
    Expression<String>? descricao,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (idProdutoGrupo != null) 'id_produto_grupo': idProdutoGrupo,
      if (nome != null) 'nome': nome,
      if (descricao != null) 'descricao': descricao,
    });
  }

  ProdutoSubgruposCompanion copyWith(
      {Value<int?>? id,
      Value<int?>? idProdutoGrupo,
      Value<String?>? nome,
      Value<String?>? descricao}) {
    return ProdutoSubgruposCompanion(
      id: id ?? this.id,
      idProdutoGrupo: idProdutoGrupo ?? this.idProdutoGrupo,
      nome: nome ?? this.nome,
      descricao: descricao ?? this.descricao,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (idProdutoGrupo.present) {
      map['id_produto_grupo'] = Variable<int>(idProdutoGrupo.value);
    }
    if (nome.present) {
      map['nome'] = Variable<String>(nome.value);
    }
    if (descricao.present) {
      map['descricao'] = Variable<String>(descricao.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('ProdutoSubgruposCompanion(')
          ..write('id: $id, ')
          ..write('idProdutoGrupo: $idProdutoGrupo, ')
          ..write('nome: $nome, ')
          ..write('descricao: $descricao')
          ..write(')'))
        .toString();
  }
}

class $ProdutoMarcasTable extends ProdutoMarcas
    with TableInfo<$ProdutoMarcasTable, ProdutoMarca> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $ProdutoMarcasTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
      'id', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _nomeMeta = const VerificationMeta('nome');
  @override
  late final GeneratedColumn<String> nome = GeneratedColumn<String>(
      'nome', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 100),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _descricaoMeta =
      const VerificationMeta('descricao');
  @override
  late final GeneratedColumn<String> descricao = GeneratedColumn<String>(
      'descricao', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 250),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  @override
  List<GeneratedColumn> get $columns => [id, nome, descricao];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'produto_marca';
  @override
  VerificationContext validateIntegrity(Insertable<ProdutoMarca> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('nome')) {
      context.handle(
          _nomeMeta, nome.isAcceptableOrUnknown(data['nome']!, _nomeMeta));
    }
    if (data.containsKey('descricao')) {
      context.handle(_descricaoMeta,
          descricao.isAcceptableOrUnknown(data['descricao']!, _descricaoMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  ProdutoMarca map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return ProdutoMarca(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id']),
      nome: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}nome']),
      descricao: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}descricao']),
    );
  }

  @override
  $ProdutoMarcasTable createAlias(String alias) {
    return $ProdutoMarcasTable(attachedDatabase, alias);
  }
}

class ProdutoMarca extends DataClass implements Insertable<ProdutoMarca> {
  final int? id;
  final String? nome;
  final String? descricao;
  const ProdutoMarca({this.id, this.nome, this.descricao});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || nome != null) {
      map['nome'] = Variable<String>(nome);
    }
    if (!nullToAbsent || descricao != null) {
      map['descricao'] = Variable<String>(descricao);
    }
    return map;
  }

  factory ProdutoMarca.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return ProdutoMarca(
      id: serializer.fromJson<int?>(json['id']),
      nome: serializer.fromJson<String?>(json['nome']),
      descricao: serializer.fromJson<String?>(json['descricao']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'nome': serializer.toJson<String?>(nome),
      'descricao': serializer.toJson<String?>(descricao),
    };
  }

  ProdutoMarca copyWith(
          {Value<int?> id = const Value.absent(),
          Value<String?> nome = const Value.absent(),
          Value<String?> descricao = const Value.absent()}) =>
      ProdutoMarca(
        id: id.present ? id.value : this.id,
        nome: nome.present ? nome.value : this.nome,
        descricao: descricao.present ? descricao.value : this.descricao,
      );
  ProdutoMarca copyWithCompanion(ProdutoMarcasCompanion data) {
    return ProdutoMarca(
      id: data.id.present ? data.id.value : this.id,
      nome: data.nome.present ? data.nome.value : this.nome,
      descricao: data.descricao.present ? data.descricao.value : this.descricao,
    );
  }

  @override
  String toString() {
    return (StringBuffer('ProdutoMarca(')
          ..write('id: $id, ')
          ..write('nome: $nome, ')
          ..write('descricao: $descricao')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(id, nome, descricao);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is ProdutoMarca &&
          other.id == this.id &&
          other.nome == this.nome &&
          other.descricao == this.descricao);
}

class ProdutoMarcasCompanion extends UpdateCompanion<ProdutoMarca> {
  final Value<int?> id;
  final Value<String?> nome;
  final Value<String?> descricao;
  const ProdutoMarcasCompanion({
    this.id = const Value.absent(),
    this.nome = const Value.absent(),
    this.descricao = const Value.absent(),
  });
  ProdutoMarcasCompanion.insert({
    this.id = const Value.absent(),
    this.nome = const Value.absent(),
    this.descricao = const Value.absent(),
  });
  static Insertable<ProdutoMarca> custom({
    Expression<int>? id,
    Expression<String>? nome,
    Expression<String>? descricao,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (nome != null) 'nome': nome,
      if (descricao != null) 'descricao': descricao,
    });
  }

  ProdutoMarcasCompanion copyWith(
      {Value<int?>? id, Value<String?>? nome, Value<String?>? descricao}) {
    return ProdutoMarcasCompanion(
      id: id ?? this.id,
      nome: nome ?? this.nome,
      descricao: descricao ?? this.descricao,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (nome.present) {
      map['nome'] = Variable<String>(nome.value);
    }
    if (descricao.present) {
      map['descricao'] = Variable<String>(descricao.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('ProdutoMarcasCompanion(')
          ..write('id: $id, ')
          ..write('nome: $nome, ')
          ..write('descricao: $descricao')
          ..write(')'))
        .toString();
  }
}

class $ProdutoUnidadesTable extends ProdutoUnidades
    with TableInfo<$ProdutoUnidadesTable, ProdutoUnidade> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $ProdutoUnidadesTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
      'id', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _siglaMeta = const VerificationMeta('sigla');
  @override
  late final GeneratedColumn<String> sigla = GeneratedColumn<String>(
      'sigla', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 10),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _descricaoMeta =
      const VerificationMeta('descricao');
  @override
  late final GeneratedColumn<String> descricao = GeneratedColumn<String>(
      'descricao', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 250),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _podeFracionarMeta =
      const VerificationMeta('podeFracionar');
  @override
  late final GeneratedColumn<String> podeFracionar = GeneratedColumn<String>(
      'pode_fracionar', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 1),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  @override
  List<GeneratedColumn> get $columns => [id, sigla, descricao, podeFracionar];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'produto_unidade';
  @override
  VerificationContext validateIntegrity(Insertable<ProdutoUnidade> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('sigla')) {
      context.handle(
          _siglaMeta, sigla.isAcceptableOrUnknown(data['sigla']!, _siglaMeta));
    }
    if (data.containsKey('descricao')) {
      context.handle(_descricaoMeta,
          descricao.isAcceptableOrUnknown(data['descricao']!, _descricaoMeta));
    }
    if (data.containsKey('pode_fracionar')) {
      context.handle(
          _podeFracionarMeta,
          podeFracionar.isAcceptableOrUnknown(
              data['pode_fracionar']!, _podeFracionarMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  ProdutoUnidade map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return ProdutoUnidade(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id']),
      sigla: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}sigla']),
      descricao: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}descricao']),
      podeFracionar: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}pode_fracionar']),
    );
  }

  @override
  $ProdutoUnidadesTable createAlias(String alias) {
    return $ProdutoUnidadesTable(attachedDatabase, alias);
  }
}

class ProdutoUnidade extends DataClass implements Insertable<ProdutoUnidade> {
  final int? id;
  final String? sigla;
  final String? descricao;
  final String? podeFracionar;
  const ProdutoUnidade(
      {this.id, this.sigla, this.descricao, this.podeFracionar});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || sigla != null) {
      map['sigla'] = Variable<String>(sigla);
    }
    if (!nullToAbsent || descricao != null) {
      map['descricao'] = Variable<String>(descricao);
    }
    if (!nullToAbsent || podeFracionar != null) {
      map['pode_fracionar'] = Variable<String>(podeFracionar);
    }
    return map;
  }

  factory ProdutoUnidade.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return ProdutoUnidade(
      id: serializer.fromJson<int?>(json['id']),
      sigla: serializer.fromJson<String?>(json['sigla']),
      descricao: serializer.fromJson<String?>(json['descricao']),
      podeFracionar: serializer.fromJson<String?>(json['podeFracionar']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'sigla': serializer.toJson<String?>(sigla),
      'descricao': serializer.toJson<String?>(descricao),
      'podeFracionar': serializer.toJson<String?>(podeFracionar),
    };
  }

  ProdutoUnidade copyWith(
          {Value<int?> id = const Value.absent(),
          Value<String?> sigla = const Value.absent(),
          Value<String?> descricao = const Value.absent(),
          Value<String?> podeFracionar = const Value.absent()}) =>
      ProdutoUnidade(
        id: id.present ? id.value : this.id,
        sigla: sigla.present ? sigla.value : this.sigla,
        descricao: descricao.present ? descricao.value : this.descricao,
        podeFracionar:
            podeFracionar.present ? podeFracionar.value : this.podeFracionar,
      );
  ProdutoUnidade copyWithCompanion(ProdutoUnidadesCompanion data) {
    return ProdutoUnidade(
      id: data.id.present ? data.id.value : this.id,
      sigla: data.sigla.present ? data.sigla.value : this.sigla,
      descricao: data.descricao.present ? data.descricao.value : this.descricao,
      podeFracionar: data.podeFracionar.present
          ? data.podeFracionar.value
          : this.podeFracionar,
    );
  }

  @override
  String toString() {
    return (StringBuffer('ProdutoUnidade(')
          ..write('id: $id, ')
          ..write('sigla: $sigla, ')
          ..write('descricao: $descricao, ')
          ..write('podeFracionar: $podeFracionar')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(id, sigla, descricao, podeFracionar);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is ProdutoUnidade &&
          other.id == this.id &&
          other.sigla == this.sigla &&
          other.descricao == this.descricao &&
          other.podeFracionar == this.podeFracionar);
}

class ProdutoUnidadesCompanion extends UpdateCompanion<ProdutoUnidade> {
  final Value<int?> id;
  final Value<String?> sigla;
  final Value<String?> descricao;
  final Value<String?> podeFracionar;
  const ProdutoUnidadesCompanion({
    this.id = const Value.absent(),
    this.sigla = const Value.absent(),
    this.descricao = const Value.absent(),
    this.podeFracionar = const Value.absent(),
  });
  ProdutoUnidadesCompanion.insert({
    this.id = const Value.absent(),
    this.sigla = const Value.absent(),
    this.descricao = const Value.absent(),
    this.podeFracionar = const Value.absent(),
  });
  static Insertable<ProdutoUnidade> custom({
    Expression<int>? id,
    Expression<String>? sigla,
    Expression<String>? descricao,
    Expression<String>? podeFracionar,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (sigla != null) 'sigla': sigla,
      if (descricao != null) 'descricao': descricao,
      if (podeFracionar != null) 'pode_fracionar': podeFracionar,
    });
  }

  ProdutoUnidadesCompanion copyWith(
      {Value<int?>? id,
      Value<String?>? sigla,
      Value<String?>? descricao,
      Value<String?>? podeFracionar}) {
    return ProdutoUnidadesCompanion(
      id: id ?? this.id,
      sigla: sigla ?? this.sigla,
      descricao: descricao ?? this.descricao,
      podeFracionar: podeFracionar ?? this.podeFracionar,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (sigla.present) {
      map['sigla'] = Variable<String>(sigla.value);
    }
    if (descricao.present) {
      map['descricao'] = Variable<String>(descricao.value);
    }
    if (podeFracionar.present) {
      map['pode_fracionar'] = Variable<String>(podeFracionar.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('ProdutoUnidadesCompanion(')
          ..write('id: $id, ')
          ..write('sigla: $sigla, ')
          ..write('descricao: $descricao, ')
          ..write('podeFracionar: $podeFracionar')
          ..write(')'))
        .toString();
  }
}

class $VendaCondicoesPagamentosTable extends VendaCondicoesPagamentos
    with TableInfo<$VendaCondicoesPagamentosTable, VendaCondicoesPagamento> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $VendaCondicoesPagamentosTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
      'id', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _nomeMeta = const VerificationMeta('nome');
  @override
  late final GeneratedColumn<String> nome = GeneratedColumn<String>(
      'nome', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 50),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _descricaoMeta =
      const VerificationMeta('descricao');
  @override
  late final GeneratedColumn<String> descricao = GeneratedColumn<String>(
      'descricao', aliasedName, true,
      type: DriftSqlType.string, requiredDuringInsert: false);
  static const VerificationMeta _faturamentoMinimoMeta =
      const VerificationMeta('faturamentoMinimo');
  @override
  late final GeneratedColumn<double> faturamentoMinimo =
      GeneratedColumn<double>('faturamento_minimo', aliasedName, true,
          type: DriftSqlType.double, requiredDuringInsert: false);
  static const VerificationMeta _faturamentoMaximoMeta =
      const VerificationMeta('faturamentoMaximo');
  @override
  late final GeneratedColumn<double> faturamentoMaximo =
      GeneratedColumn<double>('faturamento_maximo', aliasedName, true,
          type: DriftSqlType.double, requiredDuringInsert: false);
  static const VerificationMeta _indiceCorrecaoMeta =
      const VerificationMeta('indiceCorrecao');
  @override
  late final GeneratedColumn<double> indiceCorrecao = GeneratedColumn<double>(
      'indice_correcao', aliasedName, true,
      type: DriftSqlType.double, requiredDuringInsert: false);
  static const VerificationMeta _diasToleranciaMeta =
      const VerificationMeta('diasTolerancia');
  @override
  late final GeneratedColumn<int> diasTolerancia = GeneratedColumn<int>(
      'dias_tolerancia', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _valorToleranciaMeta =
      const VerificationMeta('valorTolerancia');
  @override
  late final GeneratedColumn<double> valorTolerancia = GeneratedColumn<double>(
      'valor_tolerancia', aliasedName, true,
      type: DriftSqlType.double, requiredDuringInsert: false);
  static const VerificationMeta _prazoMedioMeta =
      const VerificationMeta('prazoMedio');
  @override
  late final GeneratedColumn<int> prazoMedio = GeneratedColumn<int>(
      'prazo_medio', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _vistaPrazoMeta =
      const VerificationMeta('vistaPrazo');
  @override
  late final GeneratedColumn<String> vistaPrazo = GeneratedColumn<String>(
      'vista_prazo', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 1),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  @override
  List<GeneratedColumn> get $columns => [
        id,
        nome,
        descricao,
        faturamentoMinimo,
        faturamentoMaximo,
        indiceCorrecao,
        diasTolerancia,
        valorTolerancia,
        prazoMedio,
        vistaPrazo
      ];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'venda_condicoes_pagamento';
  @override
  VerificationContext validateIntegrity(
      Insertable<VendaCondicoesPagamento> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('nome')) {
      context.handle(
          _nomeMeta, nome.isAcceptableOrUnknown(data['nome']!, _nomeMeta));
    }
    if (data.containsKey('descricao')) {
      context.handle(_descricaoMeta,
          descricao.isAcceptableOrUnknown(data['descricao']!, _descricaoMeta));
    }
    if (data.containsKey('faturamento_minimo')) {
      context.handle(
          _faturamentoMinimoMeta,
          faturamentoMinimo.isAcceptableOrUnknown(
              data['faturamento_minimo']!, _faturamentoMinimoMeta));
    }
    if (data.containsKey('faturamento_maximo')) {
      context.handle(
          _faturamentoMaximoMeta,
          faturamentoMaximo.isAcceptableOrUnknown(
              data['faturamento_maximo']!, _faturamentoMaximoMeta));
    }
    if (data.containsKey('indice_correcao')) {
      context.handle(
          _indiceCorrecaoMeta,
          indiceCorrecao.isAcceptableOrUnknown(
              data['indice_correcao']!, _indiceCorrecaoMeta));
    }
    if (data.containsKey('dias_tolerancia')) {
      context.handle(
          _diasToleranciaMeta,
          diasTolerancia.isAcceptableOrUnknown(
              data['dias_tolerancia']!, _diasToleranciaMeta));
    }
    if (data.containsKey('valor_tolerancia')) {
      context.handle(
          _valorToleranciaMeta,
          valorTolerancia.isAcceptableOrUnknown(
              data['valor_tolerancia']!, _valorToleranciaMeta));
    }
    if (data.containsKey('prazo_medio')) {
      context.handle(
          _prazoMedioMeta,
          prazoMedio.isAcceptableOrUnknown(
              data['prazo_medio']!, _prazoMedioMeta));
    }
    if (data.containsKey('vista_prazo')) {
      context.handle(
          _vistaPrazoMeta,
          vistaPrazo.isAcceptableOrUnknown(
              data['vista_prazo']!, _vistaPrazoMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  VendaCondicoesPagamento map(Map<String, dynamic> data,
      {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return VendaCondicoesPagamento(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id']),
      nome: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}nome']),
      descricao: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}descricao']),
      faturamentoMinimo: attachedDatabase.typeMapping.read(
          DriftSqlType.double, data['${effectivePrefix}faturamento_minimo']),
      faturamentoMaximo: attachedDatabase.typeMapping.read(
          DriftSqlType.double, data['${effectivePrefix}faturamento_maximo']),
      indiceCorrecao: attachedDatabase.typeMapping
          .read(DriftSqlType.double, data['${effectivePrefix}indice_correcao']),
      diasTolerancia: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}dias_tolerancia']),
      valorTolerancia: attachedDatabase.typeMapping.read(
          DriftSqlType.double, data['${effectivePrefix}valor_tolerancia']),
      prazoMedio: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}prazo_medio']),
      vistaPrazo: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}vista_prazo']),
    );
  }

  @override
  $VendaCondicoesPagamentosTable createAlias(String alias) {
    return $VendaCondicoesPagamentosTable(attachedDatabase, alias);
  }
}

class VendaCondicoesPagamento extends DataClass
    implements Insertable<VendaCondicoesPagamento> {
  final int? id;
  final String? nome;
  final String? descricao;
  final double? faturamentoMinimo;
  final double? faturamentoMaximo;
  final double? indiceCorrecao;
  final int? diasTolerancia;
  final double? valorTolerancia;
  final int? prazoMedio;
  final String? vistaPrazo;
  const VendaCondicoesPagamento(
      {this.id,
      this.nome,
      this.descricao,
      this.faturamentoMinimo,
      this.faturamentoMaximo,
      this.indiceCorrecao,
      this.diasTolerancia,
      this.valorTolerancia,
      this.prazoMedio,
      this.vistaPrazo});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || nome != null) {
      map['nome'] = Variable<String>(nome);
    }
    if (!nullToAbsent || descricao != null) {
      map['descricao'] = Variable<String>(descricao);
    }
    if (!nullToAbsent || faturamentoMinimo != null) {
      map['faturamento_minimo'] = Variable<double>(faturamentoMinimo);
    }
    if (!nullToAbsent || faturamentoMaximo != null) {
      map['faturamento_maximo'] = Variable<double>(faturamentoMaximo);
    }
    if (!nullToAbsent || indiceCorrecao != null) {
      map['indice_correcao'] = Variable<double>(indiceCorrecao);
    }
    if (!nullToAbsent || diasTolerancia != null) {
      map['dias_tolerancia'] = Variable<int>(diasTolerancia);
    }
    if (!nullToAbsent || valorTolerancia != null) {
      map['valor_tolerancia'] = Variable<double>(valorTolerancia);
    }
    if (!nullToAbsent || prazoMedio != null) {
      map['prazo_medio'] = Variable<int>(prazoMedio);
    }
    if (!nullToAbsent || vistaPrazo != null) {
      map['vista_prazo'] = Variable<String>(vistaPrazo);
    }
    return map;
  }

  factory VendaCondicoesPagamento.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return VendaCondicoesPagamento(
      id: serializer.fromJson<int?>(json['id']),
      nome: serializer.fromJson<String?>(json['nome']),
      descricao: serializer.fromJson<String?>(json['descricao']),
      faturamentoMinimo:
          serializer.fromJson<double?>(json['faturamentoMinimo']),
      faturamentoMaximo:
          serializer.fromJson<double?>(json['faturamentoMaximo']),
      indiceCorrecao: serializer.fromJson<double?>(json['indiceCorrecao']),
      diasTolerancia: serializer.fromJson<int?>(json['diasTolerancia']),
      valorTolerancia: serializer.fromJson<double?>(json['valorTolerancia']),
      prazoMedio: serializer.fromJson<int?>(json['prazoMedio']),
      vistaPrazo: serializer.fromJson<String?>(json['vistaPrazo']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'nome': serializer.toJson<String?>(nome),
      'descricao': serializer.toJson<String?>(descricao),
      'faturamentoMinimo': serializer.toJson<double?>(faturamentoMinimo),
      'faturamentoMaximo': serializer.toJson<double?>(faturamentoMaximo),
      'indiceCorrecao': serializer.toJson<double?>(indiceCorrecao),
      'diasTolerancia': serializer.toJson<int?>(diasTolerancia),
      'valorTolerancia': serializer.toJson<double?>(valorTolerancia),
      'prazoMedio': serializer.toJson<int?>(prazoMedio),
      'vistaPrazo': serializer.toJson<String?>(vistaPrazo),
    };
  }

  VendaCondicoesPagamento copyWith(
          {Value<int?> id = const Value.absent(),
          Value<String?> nome = const Value.absent(),
          Value<String?> descricao = const Value.absent(),
          Value<double?> faturamentoMinimo = const Value.absent(),
          Value<double?> faturamentoMaximo = const Value.absent(),
          Value<double?> indiceCorrecao = const Value.absent(),
          Value<int?> diasTolerancia = const Value.absent(),
          Value<double?> valorTolerancia = const Value.absent(),
          Value<int?> prazoMedio = const Value.absent(),
          Value<String?> vistaPrazo = const Value.absent()}) =>
      VendaCondicoesPagamento(
        id: id.present ? id.value : this.id,
        nome: nome.present ? nome.value : this.nome,
        descricao: descricao.present ? descricao.value : this.descricao,
        faturamentoMinimo: faturamentoMinimo.present
            ? faturamentoMinimo.value
            : this.faturamentoMinimo,
        faturamentoMaximo: faturamentoMaximo.present
            ? faturamentoMaximo.value
            : this.faturamentoMaximo,
        indiceCorrecao:
            indiceCorrecao.present ? indiceCorrecao.value : this.indiceCorrecao,
        diasTolerancia:
            diasTolerancia.present ? diasTolerancia.value : this.diasTolerancia,
        valorTolerancia: valorTolerancia.present
            ? valorTolerancia.value
            : this.valorTolerancia,
        prazoMedio: prazoMedio.present ? prazoMedio.value : this.prazoMedio,
        vistaPrazo: vistaPrazo.present ? vistaPrazo.value : this.vistaPrazo,
      );
  VendaCondicoesPagamento copyWithCompanion(
      VendaCondicoesPagamentosCompanion data) {
    return VendaCondicoesPagamento(
      id: data.id.present ? data.id.value : this.id,
      nome: data.nome.present ? data.nome.value : this.nome,
      descricao: data.descricao.present ? data.descricao.value : this.descricao,
      faturamentoMinimo: data.faturamentoMinimo.present
          ? data.faturamentoMinimo.value
          : this.faturamentoMinimo,
      faturamentoMaximo: data.faturamentoMaximo.present
          ? data.faturamentoMaximo.value
          : this.faturamentoMaximo,
      indiceCorrecao: data.indiceCorrecao.present
          ? data.indiceCorrecao.value
          : this.indiceCorrecao,
      diasTolerancia: data.diasTolerancia.present
          ? data.diasTolerancia.value
          : this.diasTolerancia,
      valorTolerancia: data.valorTolerancia.present
          ? data.valorTolerancia.value
          : this.valorTolerancia,
      prazoMedio:
          data.prazoMedio.present ? data.prazoMedio.value : this.prazoMedio,
      vistaPrazo:
          data.vistaPrazo.present ? data.vistaPrazo.value : this.vistaPrazo,
    );
  }

  @override
  String toString() {
    return (StringBuffer('VendaCondicoesPagamento(')
          ..write('id: $id, ')
          ..write('nome: $nome, ')
          ..write('descricao: $descricao, ')
          ..write('faturamentoMinimo: $faturamentoMinimo, ')
          ..write('faturamentoMaximo: $faturamentoMaximo, ')
          ..write('indiceCorrecao: $indiceCorrecao, ')
          ..write('diasTolerancia: $diasTolerancia, ')
          ..write('valorTolerancia: $valorTolerancia, ')
          ..write('prazoMedio: $prazoMedio, ')
          ..write('vistaPrazo: $vistaPrazo')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(
      id,
      nome,
      descricao,
      faturamentoMinimo,
      faturamentoMaximo,
      indiceCorrecao,
      diasTolerancia,
      valorTolerancia,
      prazoMedio,
      vistaPrazo);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is VendaCondicoesPagamento &&
          other.id == this.id &&
          other.nome == this.nome &&
          other.descricao == this.descricao &&
          other.faturamentoMinimo == this.faturamentoMinimo &&
          other.faturamentoMaximo == this.faturamentoMaximo &&
          other.indiceCorrecao == this.indiceCorrecao &&
          other.diasTolerancia == this.diasTolerancia &&
          other.valorTolerancia == this.valorTolerancia &&
          other.prazoMedio == this.prazoMedio &&
          other.vistaPrazo == this.vistaPrazo);
}

class VendaCondicoesPagamentosCompanion
    extends UpdateCompanion<VendaCondicoesPagamento> {
  final Value<int?> id;
  final Value<String?> nome;
  final Value<String?> descricao;
  final Value<double?> faturamentoMinimo;
  final Value<double?> faturamentoMaximo;
  final Value<double?> indiceCorrecao;
  final Value<int?> diasTolerancia;
  final Value<double?> valorTolerancia;
  final Value<int?> prazoMedio;
  final Value<String?> vistaPrazo;
  const VendaCondicoesPagamentosCompanion({
    this.id = const Value.absent(),
    this.nome = const Value.absent(),
    this.descricao = const Value.absent(),
    this.faturamentoMinimo = const Value.absent(),
    this.faturamentoMaximo = const Value.absent(),
    this.indiceCorrecao = const Value.absent(),
    this.diasTolerancia = const Value.absent(),
    this.valorTolerancia = const Value.absent(),
    this.prazoMedio = const Value.absent(),
    this.vistaPrazo = const Value.absent(),
  });
  VendaCondicoesPagamentosCompanion.insert({
    this.id = const Value.absent(),
    this.nome = const Value.absent(),
    this.descricao = const Value.absent(),
    this.faturamentoMinimo = const Value.absent(),
    this.faturamentoMaximo = const Value.absent(),
    this.indiceCorrecao = const Value.absent(),
    this.diasTolerancia = const Value.absent(),
    this.valorTolerancia = const Value.absent(),
    this.prazoMedio = const Value.absent(),
    this.vistaPrazo = const Value.absent(),
  });
  static Insertable<VendaCondicoesPagamento> custom({
    Expression<int>? id,
    Expression<String>? nome,
    Expression<String>? descricao,
    Expression<double>? faturamentoMinimo,
    Expression<double>? faturamentoMaximo,
    Expression<double>? indiceCorrecao,
    Expression<int>? diasTolerancia,
    Expression<double>? valorTolerancia,
    Expression<int>? prazoMedio,
    Expression<String>? vistaPrazo,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (nome != null) 'nome': nome,
      if (descricao != null) 'descricao': descricao,
      if (faturamentoMinimo != null) 'faturamento_minimo': faturamentoMinimo,
      if (faturamentoMaximo != null) 'faturamento_maximo': faturamentoMaximo,
      if (indiceCorrecao != null) 'indice_correcao': indiceCorrecao,
      if (diasTolerancia != null) 'dias_tolerancia': diasTolerancia,
      if (valorTolerancia != null) 'valor_tolerancia': valorTolerancia,
      if (prazoMedio != null) 'prazo_medio': prazoMedio,
      if (vistaPrazo != null) 'vista_prazo': vistaPrazo,
    });
  }

  VendaCondicoesPagamentosCompanion copyWith(
      {Value<int?>? id,
      Value<String?>? nome,
      Value<String?>? descricao,
      Value<double?>? faturamentoMinimo,
      Value<double?>? faturamentoMaximo,
      Value<double?>? indiceCorrecao,
      Value<int?>? diasTolerancia,
      Value<double?>? valorTolerancia,
      Value<int?>? prazoMedio,
      Value<String?>? vistaPrazo}) {
    return VendaCondicoesPagamentosCompanion(
      id: id ?? this.id,
      nome: nome ?? this.nome,
      descricao: descricao ?? this.descricao,
      faturamentoMinimo: faturamentoMinimo ?? this.faturamentoMinimo,
      faturamentoMaximo: faturamentoMaximo ?? this.faturamentoMaximo,
      indiceCorrecao: indiceCorrecao ?? this.indiceCorrecao,
      diasTolerancia: diasTolerancia ?? this.diasTolerancia,
      valorTolerancia: valorTolerancia ?? this.valorTolerancia,
      prazoMedio: prazoMedio ?? this.prazoMedio,
      vistaPrazo: vistaPrazo ?? this.vistaPrazo,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (nome.present) {
      map['nome'] = Variable<String>(nome.value);
    }
    if (descricao.present) {
      map['descricao'] = Variable<String>(descricao.value);
    }
    if (faturamentoMinimo.present) {
      map['faturamento_minimo'] = Variable<double>(faturamentoMinimo.value);
    }
    if (faturamentoMaximo.present) {
      map['faturamento_maximo'] = Variable<double>(faturamentoMaximo.value);
    }
    if (indiceCorrecao.present) {
      map['indice_correcao'] = Variable<double>(indiceCorrecao.value);
    }
    if (diasTolerancia.present) {
      map['dias_tolerancia'] = Variable<int>(diasTolerancia.value);
    }
    if (valorTolerancia.present) {
      map['valor_tolerancia'] = Variable<double>(valorTolerancia.value);
    }
    if (prazoMedio.present) {
      map['prazo_medio'] = Variable<int>(prazoMedio.value);
    }
    if (vistaPrazo.present) {
      map['vista_prazo'] = Variable<String>(vistaPrazo.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('VendaCondicoesPagamentosCompanion(')
          ..write('id: $id, ')
          ..write('nome: $nome, ')
          ..write('descricao: $descricao, ')
          ..write('faturamentoMinimo: $faturamentoMinimo, ')
          ..write('faturamentoMaximo: $faturamentoMaximo, ')
          ..write('indiceCorrecao: $indiceCorrecao, ')
          ..write('diasTolerancia: $diasTolerancia, ')
          ..write('valorTolerancia: $valorTolerancia, ')
          ..write('prazoMedio: $prazoMedio, ')
          ..write('vistaPrazo: $vistaPrazo')
          ..write(')'))
        .toString();
  }
}

class $VendaOrcamentoCabecalhosTable extends VendaOrcamentoCabecalhos
    with TableInfo<$VendaOrcamentoCabecalhosTable, VendaOrcamentoCabecalho> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $VendaOrcamentoCabecalhosTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
      'id', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _idVendedorMeta =
      const VerificationMeta('idVendedor');
  @override
  late final GeneratedColumn<int> idVendedor = GeneratedColumn<int>(
      'id_vendedor', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _idClienteMeta =
      const VerificationMeta('idCliente');
  @override
  late final GeneratedColumn<int> idCliente = GeneratedColumn<int>(
      'id_cliente', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _idVendaCondicoesPagamentoMeta =
      const VerificationMeta('idVendaCondicoesPagamento');
  @override
  late final GeneratedColumn<int> idVendaCondicoesPagamento =
      GeneratedColumn<int>('id_venda_condicoes_pagamento', aliasedName, true,
          type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _idTransportadoraMeta =
      const VerificationMeta('idTransportadora');
  @override
  late final GeneratedColumn<int> idTransportadora = GeneratedColumn<int>(
      'id_transportadora', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _tipoFreteMeta =
      const VerificationMeta('tipoFrete');
  @override
  late final GeneratedColumn<String> tipoFrete = GeneratedColumn<String>(
      'tipo_frete', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 1),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _codigoMeta = const VerificationMeta('codigo');
  @override
  late final GeneratedColumn<String> codigo = GeneratedColumn<String>(
      'codigo', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 20),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _dataCadastroMeta =
      const VerificationMeta('dataCadastro');
  @override
  late final GeneratedColumn<DateTime> dataCadastro = GeneratedColumn<DateTime>(
      'data_cadastro', aliasedName, true,
      type: DriftSqlType.dateTime, requiredDuringInsert: false);
  static const VerificationMeta _dataEntregaMeta =
      const VerificationMeta('dataEntrega');
  @override
  late final GeneratedColumn<DateTime> dataEntrega = GeneratedColumn<DateTime>(
      'data_entrega', aliasedName, true,
      type: DriftSqlType.dateTime, requiredDuringInsert: false);
  static const VerificationMeta _dataValidadeMeta =
      const VerificationMeta('dataValidade');
  @override
  late final GeneratedColumn<DateTime> dataValidade = GeneratedColumn<DateTime>(
      'data_validade', aliasedName, true,
      type: DriftSqlType.dateTime, requiredDuringInsert: false);
  static const VerificationMeta _valorSubtotalMeta =
      const VerificationMeta('valorSubtotal');
  @override
  late final GeneratedColumn<double> valorSubtotal = GeneratedColumn<double>(
      'valor_subtotal', aliasedName, true,
      type: DriftSqlType.double, requiredDuringInsert: false);
  static const VerificationMeta _valorFreteMeta =
      const VerificationMeta('valorFrete');
  @override
  late final GeneratedColumn<double> valorFrete = GeneratedColumn<double>(
      'valor_frete', aliasedName, true,
      type: DriftSqlType.double, requiredDuringInsert: false);
  static const VerificationMeta _taxaComissaoMeta =
      const VerificationMeta('taxaComissao');
  @override
  late final GeneratedColumn<double> taxaComissao = GeneratedColumn<double>(
      'taxa_comissao', aliasedName, true,
      type: DriftSqlType.double, requiredDuringInsert: false);
  static const VerificationMeta _valorComissaoMeta =
      const VerificationMeta('valorComissao');
  @override
  late final GeneratedColumn<double> valorComissao = GeneratedColumn<double>(
      'valor_comissao', aliasedName, true,
      type: DriftSqlType.double, requiredDuringInsert: false);
  static const VerificationMeta _taxaDescontoMeta =
      const VerificationMeta('taxaDesconto');
  @override
  late final GeneratedColumn<double> taxaDesconto = GeneratedColumn<double>(
      'taxa_desconto', aliasedName, true,
      type: DriftSqlType.double, requiredDuringInsert: false);
  static const VerificationMeta _valorDescontoMeta =
      const VerificationMeta('valorDesconto');
  @override
  late final GeneratedColumn<double> valorDesconto = GeneratedColumn<double>(
      'valor_desconto', aliasedName, true,
      type: DriftSqlType.double, requiredDuringInsert: false);
  static const VerificationMeta _valorTotalMeta =
      const VerificationMeta('valorTotal');
  @override
  late final GeneratedColumn<double> valorTotal = GeneratedColumn<double>(
      'valor_total', aliasedName, true,
      type: DriftSqlType.double, requiredDuringInsert: false);
  static const VerificationMeta _observacaoMeta =
      const VerificationMeta('observacao');
  @override
  late final GeneratedColumn<String> observacao = GeneratedColumn<String>(
      'observacao', aliasedName, true,
      type: DriftSqlType.string, requiredDuringInsert: false);
  @override
  List<GeneratedColumn> get $columns => [
        id,
        idVendedor,
        idCliente,
        idVendaCondicoesPagamento,
        idTransportadora,
        tipoFrete,
        codigo,
        dataCadastro,
        dataEntrega,
        dataValidade,
        valorSubtotal,
        valorFrete,
        taxaComissao,
        valorComissao,
        taxaDesconto,
        valorDesconto,
        valorTotal,
        observacao
      ];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'venda_orcamento_cabecalho';
  @override
  VerificationContext validateIntegrity(
      Insertable<VendaOrcamentoCabecalho> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('id_vendedor')) {
      context.handle(
          _idVendedorMeta,
          idVendedor.isAcceptableOrUnknown(
              data['id_vendedor']!, _idVendedorMeta));
    }
    if (data.containsKey('id_cliente')) {
      context.handle(_idClienteMeta,
          idCliente.isAcceptableOrUnknown(data['id_cliente']!, _idClienteMeta));
    }
    if (data.containsKey('id_venda_condicoes_pagamento')) {
      context.handle(
          _idVendaCondicoesPagamentoMeta,
          idVendaCondicoesPagamento.isAcceptableOrUnknown(
              data['id_venda_condicoes_pagamento']!,
              _idVendaCondicoesPagamentoMeta));
    }
    if (data.containsKey('id_transportadora')) {
      context.handle(
          _idTransportadoraMeta,
          idTransportadora.isAcceptableOrUnknown(
              data['id_transportadora']!, _idTransportadoraMeta));
    }
    if (data.containsKey('tipo_frete')) {
      context.handle(_tipoFreteMeta,
          tipoFrete.isAcceptableOrUnknown(data['tipo_frete']!, _tipoFreteMeta));
    }
    if (data.containsKey('codigo')) {
      context.handle(_codigoMeta,
          codigo.isAcceptableOrUnknown(data['codigo']!, _codigoMeta));
    }
    if (data.containsKey('data_cadastro')) {
      context.handle(
          _dataCadastroMeta,
          dataCadastro.isAcceptableOrUnknown(
              data['data_cadastro']!, _dataCadastroMeta));
    }
    if (data.containsKey('data_entrega')) {
      context.handle(
          _dataEntregaMeta,
          dataEntrega.isAcceptableOrUnknown(
              data['data_entrega']!, _dataEntregaMeta));
    }
    if (data.containsKey('data_validade')) {
      context.handle(
          _dataValidadeMeta,
          dataValidade.isAcceptableOrUnknown(
              data['data_validade']!, _dataValidadeMeta));
    }
    if (data.containsKey('valor_subtotal')) {
      context.handle(
          _valorSubtotalMeta,
          valorSubtotal.isAcceptableOrUnknown(
              data['valor_subtotal']!, _valorSubtotalMeta));
    }
    if (data.containsKey('valor_frete')) {
      context.handle(
          _valorFreteMeta,
          valorFrete.isAcceptableOrUnknown(
              data['valor_frete']!, _valorFreteMeta));
    }
    if (data.containsKey('taxa_comissao')) {
      context.handle(
          _taxaComissaoMeta,
          taxaComissao.isAcceptableOrUnknown(
              data['taxa_comissao']!, _taxaComissaoMeta));
    }
    if (data.containsKey('valor_comissao')) {
      context.handle(
          _valorComissaoMeta,
          valorComissao.isAcceptableOrUnknown(
              data['valor_comissao']!, _valorComissaoMeta));
    }
    if (data.containsKey('taxa_desconto')) {
      context.handle(
          _taxaDescontoMeta,
          taxaDesconto.isAcceptableOrUnknown(
              data['taxa_desconto']!, _taxaDescontoMeta));
    }
    if (data.containsKey('valor_desconto')) {
      context.handle(
          _valorDescontoMeta,
          valorDesconto.isAcceptableOrUnknown(
              data['valor_desconto']!, _valorDescontoMeta));
    }
    if (data.containsKey('valor_total')) {
      context.handle(
          _valorTotalMeta,
          valorTotal.isAcceptableOrUnknown(
              data['valor_total']!, _valorTotalMeta));
    }
    if (data.containsKey('observacao')) {
      context.handle(
          _observacaoMeta,
          observacao.isAcceptableOrUnknown(
              data['observacao']!, _observacaoMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  VendaOrcamentoCabecalho map(Map<String, dynamic> data,
      {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return VendaOrcamentoCabecalho(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id']),
      idVendedor: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id_vendedor']),
      idCliente: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id_cliente']),
      idVendaCondicoesPagamento: attachedDatabase.typeMapping.read(
          DriftSqlType.int,
          data['${effectivePrefix}id_venda_condicoes_pagamento']),
      idTransportadora: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id_transportadora']),
      tipoFrete: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}tipo_frete']),
      codigo: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}codigo']),
      dataCadastro: attachedDatabase.typeMapping
          .read(DriftSqlType.dateTime, data['${effectivePrefix}data_cadastro']),
      dataEntrega: attachedDatabase.typeMapping
          .read(DriftSqlType.dateTime, data['${effectivePrefix}data_entrega']),
      dataValidade: attachedDatabase.typeMapping
          .read(DriftSqlType.dateTime, data['${effectivePrefix}data_validade']),
      valorSubtotal: attachedDatabase.typeMapping
          .read(DriftSqlType.double, data['${effectivePrefix}valor_subtotal']),
      valorFrete: attachedDatabase.typeMapping
          .read(DriftSqlType.double, data['${effectivePrefix}valor_frete']),
      taxaComissao: attachedDatabase.typeMapping
          .read(DriftSqlType.double, data['${effectivePrefix}taxa_comissao']),
      valorComissao: attachedDatabase.typeMapping
          .read(DriftSqlType.double, data['${effectivePrefix}valor_comissao']),
      taxaDesconto: attachedDatabase.typeMapping
          .read(DriftSqlType.double, data['${effectivePrefix}taxa_desconto']),
      valorDesconto: attachedDatabase.typeMapping
          .read(DriftSqlType.double, data['${effectivePrefix}valor_desconto']),
      valorTotal: attachedDatabase.typeMapping
          .read(DriftSqlType.double, data['${effectivePrefix}valor_total']),
      observacao: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}observacao']),
    );
  }

  @override
  $VendaOrcamentoCabecalhosTable createAlias(String alias) {
    return $VendaOrcamentoCabecalhosTable(attachedDatabase, alias);
  }
}

class VendaOrcamentoCabecalho extends DataClass
    implements Insertable<VendaOrcamentoCabecalho> {
  final int? id;
  final int? idVendedor;
  final int? idCliente;
  final int? idVendaCondicoesPagamento;
  final int? idTransportadora;
  final String? tipoFrete;
  final String? codigo;
  final DateTime? dataCadastro;
  final DateTime? dataEntrega;
  final DateTime? dataValidade;
  final double? valorSubtotal;
  final double? valorFrete;
  final double? taxaComissao;
  final double? valorComissao;
  final double? taxaDesconto;
  final double? valorDesconto;
  final double? valorTotal;
  final String? observacao;
  const VendaOrcamentoCabecalho(
      {this.id,
      this.idVendedor,
      this.idCliente,
      this.idVendaCondicoesPagamento,
      this.idTransportadora,
      this.tipoFrete,
      this.codigo,
      this.dataCadastro,
      this.dataEntrega,
      this.dataValidade,
      this.valorSubtotal,
      this.valorFrete,
      this.taxaComissao,
      this.valorComissao,
      this.taxaDesconto,
      this.valorDesconto,
      this.valorTotal,
      this.observacao});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || idVendedor != null) {
      map['id_vendedor'] = Variable<int>(idVendedor);
    }
    if (!nullToAbsent || idCliente != null) {
      map['id_cliente'] = Variable<int>(idCliente);
    }
    if (!nullToAbsent || idVendaCondicoesPagamento != null) {
      map['id_venda_condicoes_pagamento'] =
          Variable<int>(idVendaCondicoesPagamento);
    }
    if (!nullToAbsent || idTransportadora != null) {
      map['id_transportadora'] = Variable<int>(idTransportadora);
    }
    if (!nullToAbsent || tipoFrete != null) {
      map['tipo_frete'] = Variable<String>(tipoFrete);
    }
    if (!nullToAbsent || codigo != null) {
      map['codigo'] = Variable<String>(codigo);
    }
    if (!nullToAbsent || dataCadastro != null) {
      map['data_cadastro'] = Variable<DateTime>(dataCadastro);
    }
    if (!nullToAbsent || dataEntrega != null) {
      map['data_entrega'] = Variable<DateTime>(dataEntrega);
    }
    if (!nullToAbsent || dataValidade != null) {
      map['data_validade'] = Variable<DateTime>(dataValidade);
    }
    if (!nullToAbsent || valorSubtotal != null) {
      map['valor_subtotal'] = Variable<double>(valorSubtotal);
    }
    if (!nullToAbsent || valorFrete != null) {
      map['valor_frete'] = Variable<double>(valorFrete);
    }
    if (!nullToAbsent || taxaComissao != null) {
      map['taxa_comissao'] = Variable<double>(taxaComissao);
    }
    if (!nullToAbsent || valorComissao != null) {
      map['valor_comissao'] = Variable<double>(valorComissao);
    }
    if (!nullToAbsent || taxaDesconto != null) {
      map['taxa_desconto'] = Variable<double>(taxaDesconto);
    }
    if (!nullToAbsent || valorDesconto != null) {
      map['valor_desconto'] = Variable<double>(valorDesconto);
    }
    if (!nullToAbsent || valorTotal != null) {
      map['valor_total'] = Variable<double>(valorTotal);
    }
    if (!nullToAbsent || observacao != null) {
      map['observacao'] = Variable<String>(observacao);
    }
    return map;
  }

  factory VendaOrcamentoCabecalho.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return VendaOrcamentoCabecalho(
      id: serializer.fromJson<int?>(json['id']),
      idVendedor: serializer.fromJson<int?>(json['idVendedor']),
      idCliente: serializer.fromJson<int?>(json['idCliente']),
      idVendaCondicoesPagamento:
          serializer.fromJson<int?>(json['idVendaCondicoesPagamento']),
      idTransportadora: serializer.fromJson<int?>(json['idTransportadora']),
      tipoFrete: serializer.fromJson<String?>(json['tipoFrete']),
      codigo: serializer.fromJson<String?>(json['codigo']),
      dataCadastro: serializer.fromJson<DateTime?>(json['dataCadastro']),
      dataEntrega: serializer.fromJson<DateTime?>(json['dataEntrega']),
      dataValidade: serializer.fromJson<DateTime?>(json['dataValidade']),
      valorSubtotal: serializer.fromJson<double?>(json['valorSubtotal']),
      valorFrete: serializer.fromJson<double?>(json['valorFrete']),
      taxaComissao: serializer.fromJson<double?>(json['taxaComissao']),
      valorComissao: serializer.fromJson<double?>(json['valorComissao']),
      taxaDesconto: serializer.fromJson<double?>(json['taxaDesconto']),
      valorDesconto: serializer.fromJson<double?>(json['valorDesconto']),
      valorTotal: serializer.fromJson<double?>(json['valorTotal']),
      observacao: serializer.fromJson<String?>(json['observacao']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'idVendedor': serializer.toJson<int?>(idVendedor),
      'idCliente': serializer.toJson<int?>(idCliente),
      'idVendaCondicoesPagamento':
          serializer.toJson<int?>(idVendaCondicoesPagamento),
      'idTransportadora': serializer.toJson<int?>(idTransportadora),
      'tipoFrete': serializer.toJson<String?>(tipoFrete),
      'codigo': serializer.toJson<String?>(codigo),
      'dataCadastro': serializer.toJson<DateTime?>(dataCadastro),
      'dataEntrega': serializer.toJson<DateTime?>(dataEntrega),
      'dataValidade': serializer.toJson<DateTime?>(dataValidade),
      'valorSubtotal': serializer.toJson<double?>(valorSubtotal),
      'valorFrete': serializer.toJson<double?>(valorFrete),
      'taxaComissao': serializer.toJson<double?>(taxaComissao),
      'valorComissao': serializer.toJson<double?>(valorComissao),
      'taxaDesconto': serializer.toJson<double?>(taxaDesconto),
      'valorDesconto': serializer.toJson<double?>(valorDesconto),
      'valorTotal': serializer.toJson<double?>(valorTotal),
      'observacao': serializer.toJson<String?>(observacao),
    };
  }

  VendaOrcamentoCabecalho copyWith(
          {Value<int?> id = const Value.absent(),
          Value<int?> idVendedor = const Value.absent(),
          Value<int?> idCliente = const Value.absent(),
          Value<int?> idVendaCondicoesPagamento = const Value.absent(),
          Value<int?> idTransportadora = const Value.absent(),
          Value<String?> tipoFrete = const Value.absent(),
          Value<String?> codigo = const Value.absent(),
          Value<DateTime?> dataCadastro = const Value.absent(),
          Value<DateTime?> dataEntrega = const Value.absent(),
          Value<DateTime?> dataValidade = const Value.absent(),
          Value<double?> valorSubtotal = const Value.absent(),
          Value<double?> valorFrete = const Value.absent(),
          Value<double?> taxaComissao = const Value.absent(),
          Value<double?> valorComissao = const Value.absent(),
          Value<double?> taxaDesconto = const Value.absent(),
          Value<double?> valorDesconto = const Value.absent(),
          Value<double?> valorTotal = const Value.absent(),
          Value<String?> observacao = const Value.absent()}) =>
      VendaOrcamentoCabecalho(
        id: id.present ? id.value : this.id,
        idVendedor: idVendedor.present ? idVendedor.value : this.idVendedor,
        idCliente: idCliente.present ? idCliente.value : this.idCliente,
        idVendaCondicoesPagamento: idVendaCondicoesPagamento.present
            ? idVendaCondicoesPagamento.value
            : this.idVendaCondicoesPagamento,
        idTransportadora: idTransportadora.present
            ? idTransportadora.value
            : this.idTransportadora,
        tipoFrete: tipoFrete.present ? tipoFrete.value : this.tipoFrete,
        codigo: codigo.present ? codigo.value : this.codigo,
        dataCadastro:
            dataCadastro.present ? dataCadastro.value : this.dataCadastro,
        dataEntrega: dataEntrega.present ? dataEntrega.value : this.dataEntrega,
        dataValidade:
            dataValidade.present ? dataValidade.value : this.dataValidade,
        valorSubtotal:
            valorSubtotal.present ? valorSubtotal.value : this.valorSubtotal,
        valorFrete: valorFrete.present ? valorFrete.value : this.valorFrete,
        taxaComissao:
            taxaComissao.present ? taxaComissao.value : this.taxaComissao,
        valorComissao:
            valorComissao.present ? valorComissao.value : this.valorComissao,
        taxaDesconto:
            taxaDesconto.present ? taxaDesconto.value : this.taxaDesconto,
        valorDesconto:
            valorDesconto.present ? valorDesconto.value : this.valorDesconto,
        valorTotal: valorTotal.present ? valorTotal.value : this.valorTotal,
        observacao: observacao.present ? observacao.value : this.observacao,
      );
  VendaOrcamentoCabecalho copyWithCompanion(
      VendaOrcamentoCabecalhosCompanion data) {
    return VendaOrcamentoCabecalho(
      id: data.id.present ? data.id.value : this.id,
      idVendedor:
          data.idVendedor.present ? data.idVendedor.value : this.idVendedor,
      idCliente: data.idCliente.present ? data.idCliente.value : this.idCliente,
      idVendaCondicoesPagamento: data.idVendaCondicoesPagamento.present
          ? data.idVendaCondicoesPagamento.value
          : this.idVendaCondicoesPagamento,
      idTransportadora: data.idTransportadora.present
          ? data.idTransportadora.value
          : this.idTransportadora,
      tipoFrete: data.tipoFrete.present ? data.tipoFrete.value : this.tipoFrete,
      codigo: data.codigo.present ? data.codigo.value : this.codigo,
      dataCadastro: data.dataCadastro.present
          ? data.dataCadastro.value
          : this.dataCadastro,
      dataEntrega:
          data.dataEntrega.present ? data.dataEntrega.value : this.dataEntrega,
      dataValidade: data.dataValidade.present
          ? data.dataValidade.value
          : this.dataValidade,
      valorSubtotal: data.valorSubtotal.present
          ? data.valorSubtotal.value
          : this.valorSubtotal,
      valorFrete:
          data.valorFrete.present ? data.valorFrete.value : this.valorFrete,
      taxaComissao: data.taxaComissao.present
          ? data.taxaComissao.value
          : this.taxaComissao,
      valorComissao: data.valorComissao.present
          ? data.valorComissao.value
          : this.valorComissao,
      taxaDesconto: data.taxaDesconto.present
          ? data.taxaDesconto.value
          : this.taxaDesconto,
      valorDesconto: data.valorDesconto.present
          ? data.valorDesconto.value
          : this.valorDesconto,
      valorTotal:
          data.valorTotal.present ? data.valorTotal.value : this.valorTotal,
      observacao:
          data.observacao.present ? data.observacao.value : this.observacao,
    );
  }

  @override
  String toString() {
    return (StringBuffer('VendaOrcamentoCabecalho(')
          ..write('id: $id, ')
          ..write('idVendedor: $idVendedor, ')
          ..write('idCliente: $idCliente, ')
          ..write('idVendaCondicoesPagamento: $idVendaCondicoesPagamento, ')
          ..write('idTransportadora: $idTransportadora, ')
          ..write('tipoFrete: $tipoFrete, ')
          ..write('codigo: $codigo, ')
          ..write('dataCadastro: $dataCadastro, ')
          ..write('dataEntrega: $dataEntrega, ')
          ..write('dataValidade: $dataValidade, ')
          ..write('valorSubtotal: $valorSubtotal, ')
          ..write('valorFrete: $valorFrete, ')
          ..write('taxaComissao: $taxaComissao, ')
          ..write('valorComissao: $valorComissao, ')
          ..write('taxaDesconto: $taxaDesconto, ')
          ..write('valorDesconto: $valorDesconto, ')
          ..write('valorTotal: $valorTotal, ')
          ..write('observacao: $observacao')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(
      id,
      idVendedor,
      idCliente,
      idVendaCondicoesPagamento,
      idTransportadora,
      tipoFrete,
      codigo,
      dataCadastro,
      dataEntrega,
      dataValidade,
      valorSubtotal,
      valorFrete,
      taxaComissao,
      valorComissao,
      taxaDesconto,
      valorDesconto,
      valorTotal,
      observacao);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is VendaOrcamentoCabecalho &&
          other.id == this.id &&
          other.idVendedor == this.idVendedor &&
          other.idCliente == this.idCliente &&
          other.idVendaCondicoesPagamento == this.idVendaCondicoesPagamento &&
          other.idTransportadora == this.idTransportadora &&
          other.tipoFrete == this.tipoFrete &&
          other.codigo == this.codigo &&
          other.dataCadastro == this.dataCadastro &&
          other.dataEntrega == this.dataEntrega &&
          other.dataValidade == this.dataValidade &&
          other.valorSubtotal == this.valorSubtotal &&
          other.valorFrete == this.valorFrete &&
          other.taxaComissao == this.taxaComissao &&
          other.valorComissao == this.valorComissao &&
          other.taxaDesconto == this.taxaDesconto &&
          other.valorDesconto == this.valorDesconto &&
          other.valorTotal == this.valorTotal &&
          other.observacao == this.observacao);
}

class VendaOrcamentoCabecalhosCompanion
    extends UpdateCompanion<VendaOrcamentoCabecalho> {
  final Value<int?> id;
  final Value<int?> idVendedor;
  final Value<int?> idCliente;
  final Value<int?> idVendaCondicoesPagamento;
  final Value<int?> idTransportadora;
  final Value<String?> tipoFrete;
  final Value<String?> codigo;
  final Value<DateTime?> dataCadastro;
  final Value<DateTime?> dataEntrega;
  final Value<DateTime?> dataValidade;
  final Value<double?> valorSubtotal;
  final Value<double?> valorFrete;
  final Value<double?> taxaComissao;
  final Value<double?> valorComissao;
  final Value<double?> taxaDesconto;
  final Value<double?> valorDesconto;
  final Value<double?> valorTotal;
  final Value<String?> observacao;
  const VendaOrcamentoCabecalhosCompanion({
    this.id = const Value.absent(),
    this.idVendedor = const Value.absent(),
    this.idCliente = const Value.absent(),
    this.idVendaCondicoesPagamento = const Value.absent(),
    this.idTransportadora = const Value.absent(),
    this.tipoFrete = const Value.absent(),
    this.codigo = const Value.absent(),
    this.dataCadastro = const Value.absent(),
    this.dataEntrega = const Value.absent(),
    this.dataValidade = const Value.absent(),
    this.valorSubtotal = const Value.absent(),
    this.valorFrete = const Value.absent(),
    this.taxaComissao = const Value.absent(),
    this.valorComissao = const Value.absent(),
    this.taxaDesconto = const Value.absent(),
    this.valorDesconto = const Value.absent(),
    this.valorTotal = const Value.absent(),
    this.observacao = const Value.absent(),
  });
  VendaOrcamentoCabecalhosCompanion.insert({
    this.id = const Value.absent(),
    this.idVendedor = const Value.absent(),
    this.idCliente = const Value.absent(),
    this.idVendaCondicoesPagamento = const Value.absent(),
    this.idTransportadora = const Value.absent(),
    this.tipoFrete = const Value.absent(),
    this.codigo = const Value.absent(),
    this.dataCadastro = const Value.absent(),
    this.dataEntrega = const Value.absent(),
    this.dataValidade = const Value.absent(),
    this.valorSubtotal = const Value.absent(),
    this.valorFrete = const Value.absent(),
    this.taxaComissao = const Value.absent(),
    this.valorComissao = const Value.absent(),
    this.taxaDesconto = const Value.absent(),
    this.valorDesconto = const Value.absent(),
    this.valorTotal = const Value.absent(),
    this.observacao = const Value.absent(),
  });
  static Insertable<VendaOrcamentoCabecalho> custom({
    Expression<int>? id,
    Expression<int>? idVendedor,
    Expression<int>? idCliente,
    Expression<int>? idVendaCondicoesPagamento,
    Expression<int>? idTransportadora,
    Expression<String>? tipoFrete,
    Expression<String>? codigo,
    Expression<DateTime>? dataCadastro,
    Expression<DateTime>? dataEntrega,
    Expression<DateTime>? dataValidade,
    Expression<double>? valorSubtotal,
    Expression<double>? valorFrete,
    Expression<double>? taxaComissao,
    Expression<double>? valorComissao,
    Expression<double>? taxaDesconto,
    Expression<double>? valorDesconto,
    Expression<double>? valorTotal,
    Expression<String>? observacao,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (idVendedor != null) 'id_vendedor': idVendedor,
      if (idCliente != null) 'id_cliente': idCliente,
      if (idVendaCondicoesPagamento != null)
        'id_venda_condicoes_pagamento': idVendaCondicoesPagamento,
      if (idTransportadora != null) 'id_transportadora': idTransportadora,
      if (tipoFrete != null) 'tipo_frete': tipoFrete,
      if (codigo != null) 'codigo': codigo,
      if (dataCadastro != null) 'data_cadastro': dataCadastro,
      if (dataEntrega != null) 'data_entrega': dataEntrega,
      if (dataValidade != null) 'data_validade': dataValidade,
      if (valorSubtotal != null) 'valor_subtotal': valorSubtotal,
      if (valorFrete != null) 'valor_frete': valorFrete,
      if (taxaComissao != null) 'taxa_comissao': taxaComissao,
      if (valorComissao != null) 'valor_comissao': valorComissao,
      if (taxaDesconto != null) 'taxa_desconto': taxaDesconto,
      if (valorDesconto != null) 'valor_desconto': valorDesconto,
      if (valorTotal != null) 'valor_total': valorTotal,
      if (observacao != null) 'observacao': observacao,
    });
  }

  VendaOrcamentoCabecalhosCompanion copyWith(
      {Value<int?>? id,
      Value<int?>? idVendedor,
      Value<int?>? idCliente,
      Value<int?>? idVendaCondicoesPagamento,
      Value<int?>? idTransportadora,
      Value<String?>? tipoFrete,
      Value<String?>? codigo,
      Value<DateTime?>? dataCadastro,
      Value<DateTime?>? dataEntrega,
      Value<DateTime?>? dataValidade,
      Value<double?>? valorSubtotal,
      Value<double?>? valorFrete,
      Value<double?>? taxaComissao,
      Value<double?>? valorComissao,
      Value<double?>? taxaDesconto,
      Value<double?>? valorDesconto,
      Value<double?>? valorTotal,
      Value<String?>? observacao}) {
    return VendaOrcamentoCabecalhosCompanion(
      id: id ?? this.id,
      idVendedor: idVendedor ?? this.idVendedor,
      idCliente: idCliente ?? this.idCliente,
      idVendaCondicoesPagamento:
          idVendaCondicoesPagamento ?? this.idVendaCondicoesPagamento,
      idTransportadora: idTransportadora ?? this.idTransportadora,
      tipoFrete: tipoFrete ?? this.tipoFrete,
      codigo: codigo ?? this.codigo,
      dataCadastro: dataCadastro ?? this.dataCadastro,
      dataEntrega: dataEntrega ?? this.dataEntrega,
      dataValidade: dataValidade ?? this.dataValidade,
      valorSubtotal: valorSubtotal ?? this.valorSubtotal,
      valorFrete: valorFrete ?? this.valorFrete,
      taxaComissao: taxaComissao ?? this.taxaComissao,
      valorComissao: valorComissao ?? this.valorComissao,
      taxaDesconto: taxaDesconto ?? this.taxaDesconto,
      valorDesconto: valorDesconto ?? this.valorDesconto,
      valorTotal: valorTotal ?? this.valorTotal,
      observacao: observacao ?? this.observacao,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (idVendedor.present) {
      map['id_vendedor'] = Variable<int>(idVendedor.value);
    }
    if (idCliente.present) {
      map['id_cliente'] = Variable<int>(idCliente.value);
    }
    if (idVendaCondicoesPagamento.present) {
      map['id_venda_condicoes_pagamento'] =
          Variable<int>(idVendaCondicoesPagamento.value);
    }
    if (idTransportadora.present) {
      map['id_transportadora'] = Variable<int>(idTransportadora.value);
    }
    if (tipoFrete.present) {
      map['tipo_frete'] = Variable<String>(tipoFrete.value);
    }
    if (codigo.present) {
      map['codigo'] = Variable<String>(codigo.value);
    }
    if (dataCadastro.present) {
      map['data_cadastro'] = Variable<DateTime>(dataCadastro.value);
    }
    if (dataEntrega.present) {
      map['data_entrega'] = Variable<DateTime>(dataEntrega.value);
    }
    if (dataValidade.present) {
      map['data_validade'] = Variable<DateTime>(dataValidade.value);
    }
    if (valorSubtotal.present) {
      map['valor_subtotal'] = Variable<double>(valorSubtotal.value);
    }
    if (valorFrete.present) {
      map['valor_frete'] = Variable<double>(valorFrete.value);
    }
    if (taxaComissao.present) {
      map['taxa_comissao'] = Variable<double>(taxaComissao.value);
    }
    if (valorComissao.present) {
      map['valor_comissao'] = Variable<double>(valorComissao.value);
    }
    if (taxaDesconto.present) {
      map['taxa_desconto'] = Variable<double>(taxaDesconto.value);
    }
    if (valorDesconto.present) {
      map['valor_desconto'] = Variable<double>(valorDesconto.value);
    }
    if (valorTotal.present) {
      map['valor_total'] = Variable<double>(valorTotal.value);
    }
    if (observacao.present) {
      map['observacao'] = Variable<String>(observacao.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('VendaOrcamentoCabecalhosCompanion(')
          ..write('id: $id, ')
          ..write('idVendedor: $idVendedor, ')
          ..write('idCliente: $idCliente, ')
          ..write('idVendaCondicoesPagamento: $idVendaCondicoesPagamento, ')
          ..write('idTransportadora: $idTransportadora, ')
          ..write('tipoFrete: $tipoFrete, ')
          ..write('codigo: $codigo, ')
          ..write('dataCadastro: $dataCadastro, ')
          ..write('dataEntrega: $dataEntrega, ')
          ..write('dataValidade: $dataValidade, ')
          ..write('valorSubtotal: $valorSubtotal, ')
          ..write('valorFrete: $valorFrete, ')
          ..write('taxaComissao: $taxaComissao, ')
          ..write('valorComissao: $valorComissao, ')
          ..write('taxaDesconto: $taxaDesconto, ')
          ..write('valorDesconto: $valorDesconto, ')
          ..write('valorTotal: $valorTotal, ')
          ..write('observacao: $observacao')
          ..write(')'))
        .toString();
  }
}

class $VendaCabecalhosTable extends VendaCabecalhos
    with TableInfo<$VendaCabecalhosTable, VendaCabecalho> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $VendaCabecalhosTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
      'id', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _idVendaOrcamentoCabecalhoMeta =
      const VerificationMeta('idVendaOrcamentoCabecalho');
  @override
  late final GeneratedColumn<int> idVendaOrcamentoCabecalho =
      GeneratedColumn<int>('id_venda_orcamento_cabecalho', aliasedName, true,
          type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _idNotaFiscalTipoMeta =
      const VerificationMeta('idNotaFiscalTipo');
  @override
  late final GeneratedColumn<int> idNotaFiscalTipo = GeneratedColumn<int>(
      'id_nota_fiscal_tipo', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _idVendedorMeta =
      const VerificationMeta('idVendedor');
  @override
  late final GeneratedColumn<int> idVendedor = GeneratedColumn<int>(
      'id_vendedor', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _idVendaCondicoesPagamentoMeta =
      const VerificationMeta('idVendaCondicoesPagamento');
  @override
  late final GeneratedColumn<int> idVendaCondicoesPagamento =
      GeneratedColumn<int>('id_venda_condicoes_pagamento', aliasedName, true,
          type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _idTransportadoraMeta =
      const VerificationMeta('idTransportadora');
  @override
  late final GeneratedColumn<int> idTransportadora = GeneratedColumn<int>(
      'id_transportadora', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _idClienteMeta =
      const VerificationMeta('idCliente');
  @override
  late final GeneratedColumn<int> idCliente = GeneratedColumn<int>(
      'id_cliente', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _localEntregaMeta =
      const VerificationMeta('localEntrega');
  @override
  late final GeneratedColumn<String> localEntrega = GeneratedColumn<String>(
      'local_entrega', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 100),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _localCobrancaMeta =
      const VerificationMeta('localCobranca');
  @override
  late final GeneratedColumn<String> localCobranca = GeneratedColumn<String>(
      'local_cobranca', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 100),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _tipoFreteMeta =
      const VerificationMeta('tipoFrete');
  @override
  late final GeneratedColumn<String> tipoFrete = GeneratedColumn<String>(
      'tipo_frete', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 1),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _formaPagamentoMeta =
      const VerificationMeta('formaPagamento');
  @override
  late final GeneratedColumn<String> formaPagamento = GeneratedColumn<String>(
      'forma_pagamento', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 1),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _dataVendaMeta =
      const VerificationMeta('dataVenda');
  @override
  late final GeneratedColumn<DateTime> dataVenda = GeneratedColumn<DateTime>(
      'data_venda', aliasedName, true,
      type: DriftSqlType.dateTime, requiredDuringInsert: false);
  static const VerificationMeta _dataSaidaMeta =
      const VerificationMeta('dataSaida');
  @override
  late final GeneratedColumn<DateTime> dataSaida = GeneratedColumn<DateTime>(
      'data_saida', aliasedName, true,
      type: DriftSqlType.dateTime, requiredDuringInsert: false);
  static const VerificationMeta _horaSaidaMeta =
      const VerificationMeta('horaSaida');
  @override
  late final GeneratedColumn<String> horaSaida = GeneratedColumn<String>(
      'hora_saida', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 8),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _numeroFaturaMeta =
      const VerificationMeta('numeroFatura');
  @override
  late final GeneratedColumn<int> numeroFatura = GeneratedColumn<int>(
      'numero_fatura', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _valorFreteMeta =
      const VerificationMeta('valorFrete');
  @override
  late final GeneratedColumn<double> valorFrete = GeneratedColumn<double>(
      'valor_frete', aliasedName, true,
      type: DriftSqlType.double, requiredDuringInsert: false);
  static const VerificationMeta _valorSeguroMeta =
      const VerificationMeta('valorSeguro');
  @override
  late final GeneratedColumn<double> valorSeguro = GeneratedColumn<double>(
      'valor_seguro', aliasedName, true,
      type: DriftSqlType.double, requiredDuringInsert: false);
  static const VerificationMeta _valorSubtotalMeta =
      const VerificationMeta('valorSubtotal');
  @override
  late final GeneratedColumn<double> valorSubtotal = GeneratedColumn<double>(
      'valor_subtotal', aliasedName, true,
      type: DriftSqlType.double, requiredDuringInsert: false);
  static const VerificationMeta _taxaComissaoMeta =
      const VerificationMeta('taxaComissao');
  @override
  late final GeneratedColumn<double> taxaComissao = GeneratedColumn<double>(
      'taxa_comissao', aliasedName, true,
      type: DriftSqlType.double, requiredDuringInsert: false);
  static const VerificationMeta _valorComissaoMeta =
      const VerificationMeta('valorComissao');
  @override
  late final GeneratedColumn<double> valorComissao = GeneratedColumn<double>(
      'valor_comissao', aliasedName, true,
      type: DriftSqlType.double, requiredDuringInsert: false);
  static const VerificationMeta _taxaDescontoMeta =
      const VerificationMeta('taxaDesconto');
  @override
  late final GeneratedColumn<double> taxaDesconto = GeneratedColumn<double>(
      'taxa_desconto', aliasedName, true,
      type: DriftSqlType.double, requiredDuringInsert: false);
  static const VerificationMeta _valorDescontoMeta =
      const VerificationMeta('valorDesconto');
  @override
  late final GeneratedColumn<double> valorDesconto = GeneratedColumn<double>(
      'valor_desconto', aliasedName, true,
      type: DriftSqlType.double, requiredDuringInsert: false);
  static const VerificationMeta _valorTotalMeta =
      const VerificationMeta('valorTotal');
  @override
  late final GeneratedColumn<double> valorTotal = GeneratedColumn<double>(
      'valor_total', aliasedName, true,
      type: DriftSqlType.double, requiredDuringInsert: false);
  static const VerificationMeta _situacaoMeta =
      const VerificationMeta('situacao');
  @override
  late final GeneratedColumn<String> situacao = GeneratedColumn<String>(
      'situacao', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 1),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _diaFixoParcelaMeta =
      const VerificationMeta('diaFixoParcela');
  @override
  late final GeneratedColumn<String> diaFixoParcela = GeneratedColumn<String>(
      'dia_fixo_parcela', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 2),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _observacaoMeta =
      const VerificationMeta('observacao');
  @override
  late final GeneratedColumn<String> observacao = GeneratedColumn<String>(
      'observacao', aliasedName, true,
      type: DriftSqlType.string, requiredDuringInsert: false);
  @override
  List<GeneratedColumn> get $columns => [
        id,
        idVendaOrcamentoCabecalho,
        idNotaFiscalTipo,
        idVendedor,
        idVendaCondicoesPagamento,
        idTransportadora,
        idCliente,
        localEntrega,
        localCobranca,
        tipoFrete,
        formaPagamento,
        dataVenda,
        dataSaida,
        horaSaida,
        numeroFatura,
        valorFrete,
        valorSeguro,
        valorSubtotal,
        taxaComissao,
        valorComissao,
        taxaDesconto,
        valorDesconto,
        valorTotal,
        situacao,
        diaFixoParcela,
        observacao
      ];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'venda_cabecalho';
  @override
  VerificationContext validateIntegrity(Insertable<VendaCabecalho> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('id_venda_orcamento_cabecalho')) {
      context.handle(
          _idVendaOrcamentoCabecalhoMeta,
          idVendaOrcamentoCabecalho.isAcceptableOrUnknown(
              data['id_venda_orcamento_cabecalho']!,
              _idVendaOrcamentoCabecalhoMeta));
    }
    if (data.containsKey('id_nota_fiscal_tipo')) {
      context.handle(
          _idNotaFiscalTipoMeta,
          idNotaFiscalTipo.isAcceptableOrUnknown(
              data['id_nota_fiscal_tipo']!, _idNotaFiscalTipoMeta));
    }
    if (data.containsKey('id_vendedor')) {
      context.handle(
          _idVendedorMeta,
          idVendedor.isAcceptableOrUnknown(
              data['id_vendedor']!, _idVendedorMeta));
    }
    if (data.containsKey('id_venda_condicoes_pagamento')) {
      context.handle(
          _idVendaCondicoesPagamentoMeta,
          idVendaCondicoesPagamento.isAcceptableOrUnknown(
              data['id_venda_condicoes_pagamento']!,
              _idVendaCondicoesPagamentoMeta));
    }
    if (data.containsKey('id_transportadora')) {
      context.handle(
          _idTransportadoraMeta,
          idTransportadora.isAcceptableOrUnknown(
              data['id_transportadora']!, _idTransportadoraMeta));
    }
    if (data.containsKey('id_cliente')) {
      context.handle(_idClienteMeta,
          idCliente.isAcceptableOrUnknown(data['id_cliente']!, _idClienteMeta));
    }
    if (data.containsKey('local_entrega')) {
      context.handle(
          _localEntregaMeta,
          localEntrega.isAcceptableOrUnknown(
              data['local_entrega']!, _localEntregaMeta));
    }
    if (data.containsKey('local_cobranca')) {
      context.handle(
          _localCobrancaMeta,
          localCobranca.isAcceptableOrUnknown(
              data['local_cobranca']!, _localCobrancaMeta));
    }
    if (data.containsKey('tipo_frete')) {
      context.handle(_tipoFreteMeta,
          tipoFrete.isAcceptableOrUnknown(data['tipo_frete']!, _tipoFreteMeta));
    }
    if (data.containsKey('forma_pagamento')) {
      context.handle(
          _formaPagamentoMeta,
          formaPagamento.isAcceptableOrUnknown(
              data['forma_pagamento']!, _formaPagamentoMeta));
    }
    if (data.containsKey('data_venda')) {
      context.handle(_dataVendaMeta,
          dataVenda.isAcceptableOrUnknown(data['data_venda']!, _dataVendaMeta));
    }
    if (data.containsKey('data_saida')) {
      context.handle(_dataSaidaMeta,
          dataSaida.isAcceptableOrUnknown(data['data_saida']!, _dataSaidaMeta));
    }
    if (data.containsKey('hora_saida')) {
      context.handle(_horaSaidaMeta,
          horaSaida.isAcceptableOrUnknown(data['hora_saida']!, _horaSaidaMeta));
    }
    if (data.containsKey('numero_fatura')) {
      context.handle(
          _numeroFaturaMeta,
          numeroFatura.isAcceptableOrUnknown(
              data['numero_fatura']!, _numeroFaturaMeta));
    }
    if (data.containsKey('valor_frete')) {
      context.handle(
          _valorFreteMeta,
          valorFrete.isAcceptableOrUnknown(
              data['valor_frete']!, _valorFreteMeta));
    }
    if (data.containsKey('valor_seguro')) {
      context.handle(
          _valorSeguroMeta,
          valorSeguro.isAcceptableOrUnknown(
              data['valor_seguro']!, _valorSeguroMeta));
    }
    if (data.containsKey('valor_subtotal')) {
      context.handle(
          _valorSubtotalMeta,
          valorSubtotal.isAcceptableOrUnknown(
              data['valor_subtotal']!, _valorSubtotalMeta));
    }
    if (data.containsKey('taxa_comissao')) {
      context.handle(
          _taxaComissaoMeta,
          taxaComissao.isAcceptableOrUnknown(
              data['taxa_comissao']!, _taxaComissaoMeta));
    }
    if (data.containsKey('valor_comissao')) {
      context.handle(
          _valorComissaoMeta,
          valorComissao.isAcceptableOrUnknown(
              data['valor_comissao']!, _valorComissaoMeta));
    }
    if (data.containsKey('taxa_desconto')) {
      context.handle(
          _taxaDescontoMeta,
          taxaDesconto.isAcceptableOrUnknown(
              data['taxa_desconto']!, _taxaDescontoMeta));
    }
    if (data.containsKey('valor_desconto')) {
      context.handle(
          _valorDescontoMeta,
          valorDesconto.isAcceptableOrUnknown(
              data['valor_desconto']!, _valorDescontoMeta));
    }
    if (data.containsKey('valor_total')) {
      context.handle(
          _valorTotalMeta,
          valorTotal.isAcceptableOrUnknown(
              data['valor_total']!, _valorTotalMeta));
    }
    if (data.containsKey('situacao')) {
      context.handle(_situacaoMeta,
          situacao.isAcceptableOrUnknown(data['situacao']!, _situacaoMeta));
    }
    if (data.containsKey('dia_fixo_parcela')) {
      context.handle(
          _diaFixoParcelaMeta,
          diaFixoParcela.isAcceptableOrUnknown(
              data['dia_fixo_parcela']!, _diaFixoParcelaMeta));
    }
    if (data.containsKey('observacao')) {
      context.handle(
          _observacaoMeta,
          observacao.isAcceptableOrUnknown(
              data['observacao']!, _observacaoMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  VendaCabecalho map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return VendaCabecalho(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id']),
      idVendaOrcamentoCabecalho: attachedDatabase.typeMapping.read(
          DriftSqlType.int,
          data['${effectivePrefix}id_venda_orcamento_cabecalho']),
      idNotaFiscalTipo: attachedDatabase.typeMapping.read(
          DriftSqlType.int, data['${effectivePrefix}id_nota_fiscal_tipo']),
      idVendedor: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id_vendedor']),
      idVendaCondicoesPagamento: attachedDatabase.typeMapping.read(
          DriftSqlType.int,
          data['${effectivePrefix}id_venda_condicoes_pagamento']),
      idTransportadora: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id_transportadora']),
      idCliente: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id_cliente']),
      localEntrega: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}local_entrega']),
      localCobranca: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}local_cobranca']),
      tipoFrete: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}tipo_frete']),
      formaPagamento: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}forma_pagamento']),
      dataVenda: attachedDatabase.typeMapping
          .read(DriftSqlType.dateTime, data['${effectivePrefix}data_venda']),
      dataSaida: attachedDatabase.typeMapping
          .read(DriftSqlType.dateTime, data['${effectivePrefix}data_saida']),
      horaSaida: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}hora_saida']),
      numeroFatura: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}numero_fatura']),
      valorFrete: attachedDatabase.typeMapping
          .read(DriftSqlType.double, data['${effectivePrefix}valor_frete']),
      valorSeguro: attachedDatabase.typeMapping
          .read(DriftSqlType.double, data['${effectivePrefix}valor_seguro']),
      valorSubtotal: attachedDatabase.typeMapping
          .read(DriftSqlType.double, data['${effectivePrefix}valor_subtotal']),
      taxaComissao: attachedDatabase.typeMapping
          .read(DriftSqlType.double, data['${effectivePrefix}taxa_comissao']),
      valorComissao: attachedDatabase.typeMapping
          .read(DriftSqlType.double, data['${effectivePrefix}valor_comissao']),
      taxaDesconto: attachedDatabase.typeMapping
          .read(DriftSqlType.double, data['${effectivePrefix}taxa_desconto']),
      valorDesconto: attachedDatabase.typeMapping
          .read(DriftSqlType.double, data['${effectivePrefix}valor_desconto']),
      valorTotal: attachedDatabase.typeMapping
          .read(DriftSqlType.double, data['${effectivePrefix}valor_total']),
      situacao: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}situacao']),
      diaFixoParcela: attachedDatabase.typeMapping.read(
          DriftSqlType.string, data['${effectivePrefix}dia_fixo_parcela']),
      observacao: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}observacao']),
    );
  }

  @override
  $VendaCabecalhosTable createAlias(String alias) {
    return $VendaCabecalhosTable(attachedDatabase, alias);
  }
}

class VendaCabecalho extends DataClass implements Insertable<VendaCabecalho> {
  final int? id;
  final int? idVendaOrcamentoCabecalho;
  final int? idNotaFiscalTipo;
  final int? idVendedor;
  final int? idVendaCondicoesPagamento;
  final int? idTransportadora;
  final int? idCliente;
  final String? localEntrega;
  final String? localCobranca;
  final String? tipoFrete;
  final String? formaPagamento;
  final DateTime? dataVenda;
  final DateTime? dataSaida;
  final String? horaSaida;
  final int? numeroFatura;
  final double? valorFrete;
  final double? valorSeguro;
  final double? valorSubtotal;
  final double? taxaComissao;
  final double? valorComissao;
  final double? taxaDesconto;
  final double? valorDesconto;
  final double? valorTotal;
  final String? situacao;
  final String? diaFixoParcela;
  final String? observacao;
  const VendaCabecalho(
      {this.id,
      this.idVendaOrcamentoCabecalho,
      this.idNotaFiscalTipo,
      this.idVendedor,
      this.idVendaCondicoesPagamento,
      this.idTransportadora,
      this.idCliente,
      this.localEntrega,
      this.localCobranca,
      this.tipoFrete,
      this.formaPagamento,
      this.dataVenda,
      this.dataSaida,
      this.horaSaida,
      this.numeroFatura,
      this.valorFrete,
      this.valorSeguro,
      this.valorSubtotal,
      this.taxaComissao,
      this.valorComissao,
      this.taxaDesconto,
      this.valorDesconto,
      this.valorTotal,
      this.situacao,
      this.diaFixoParcela,
      this.observacao});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || idVendaOrcamentoCabecalho != null) {
      map['id_venda_orcamento_cabecalho'] =
          Variable<int>(idVendaOrcamentoCabecalho);
    }
    if (!nullToAbsent || idNotaFiscalTipo != null) {
      map['id_nota_fiscal_tipo'] = Variable<int>(idNotaFiscalTipo);
    }
    if (!nullToAbsent || idVendedor != null) {
      map['id_vendedor'] = Variable<int>(idVendedor);
    }
    if (!nullToAbsent || idVendaCondicoesPagamento != null) {
      map['id_venda_condicoes_pagamento'] =
          Variable<int>(idVendaCondicoesPagamento);
    }
    if (!nullToAbsent || idTransportadora != null) {
      map['id_transportadora'] = Variable<int>(idTransportadora);
    }
    if (!nullToAbsent || idCliente != null) {
      map['id_cliente'] = Variable<int>(idCliente);
    }
    if (!nullToAbsent || localEntrega != null) {
      map['local_entrega'] = Variable<String>(localEntrega);
    }
    if (!nullToAbsent || localCobranca != null) {
      map['local_cobranca'] = Variable<String>(localCobranca);
    }
    if (!nullToAbsent || tipoFrete != null) {
      map['tipo_frete'] = Variable<String>(tipoFrete);
    }
    if (!nullToAbsent || formaPagamento != null) {
      map['forma_pagamento'] = Variable<String>(formaPagamento);
    }
    if (!nullToAbsent || dataVenda != null) {
      map['data_venda'] = Variable<DateTime>(dataVenda);
    }
    if (!nullToAbsent || dataSaida != null) {
      map['data_saida'] = Variable<DateTime>(dataSaida);
    }
    if (!nullToAbsent || horaSaida != null) {
      map['hora_saida'] = Variable<String>(horaSaida);
    }
    if (!nullToAbsent || numeroFatura != null) {
      map['numero_fatura'] = Variable<int>(numeroFatura);
    }
    if (!nullToAbsent || valorFrete != null) {
      map['valor_frete'] = Variable<double>(valorFrete);
    }
    if (!nullToAbsent || valorSeguro != null) {
      map['valor_seguro'] = Variable<double>(valorSeguro);
    }
    if (!nullToAbsent || valorSubtotal != null) {
      map['valor_subtotal'] = Variable<double>(valorSubtotal);
    }
    if (!nullToAbsent || taxaComissao != null) {
      map['taxa_comissao'] = Variable<double>(taxaComissao);
    }
    if (!nullToAbsent || valorComissao != null) {
      map['valor_comissao'] = Variable<double>(valorComissao);
    }
    if (!nullToAbsent || taxaDesconto != null) {
      map['taxa_desconto'] = Variable<double>(taxaDesconto);
    }
    if (!nullToAbsent || valorDesconto != null) {
      map['valor_desconto'] = Variable<double>(valorDesconto);
    }
    if (!nullToAbsent || valorTotal != null) {
      map['valor_total'] = Variable<double>(valorTotal);
    }
    if (!nullToAbsent || situacao != null) {
      map['situacao'] = Variable<String>(situacao);
    }
    if (!nullToAbsent || diaFixoParcela != null) {
      map['dia_fixo_parcela'] = Variable<String>(diaFixoParcela);
    }
    if (!nullToAbsent || observacao != null) {
      map['observacao'] = Variable<String>(observacao);
    }
    return map;
  }

  factory VendaCabecalho.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return VendaCabecalho(
      id: serializer.fromJson<int?>(json['id']),
      idVendaOrcamentoCabecalho:
          serializer.fromJson<int?>(json['idVendaOrcamentoCabecalho']),
      idNotaFiscalTipo: serializer.fromJson<int?>(json['idNotaFiscalTipo']),
      idVendedor: serializer.fromJson<int?>(json['idVendedor']),
      idVendaCondicoesPagamento:
          serializer.fromJson<int?>(json['idVendaCondicoesPagamento']),
      idTransportadora: serializer.fromJson<int?>(json['idTransportadora']),
      idCliente: serializer.fromJson<int?>(json['idCliente']),
      localEntrega: serializer.fromJson<String?>(json['localEntrega']),
      localCobranca: serializer.fromJson<String?>(json['localCobranca']),
      tipoFrete: serializer.fromJson<String?>(json['tipoFrete']),
      formaPagamento: serializer.fromJson<String?>(json['formaPagamento']),
      dataVenda: serializer.fromJson<DateTime?>(json['dataVenda']),
      dataSaida: serializer.fromJson<DateTime?>(json['dataSaida']),
      horaSaida: serializer.fromJson<String?>(json['horaSaida']),
      numeroFatura: serializer.fromJson<int?>(json['numeroFatura']),
      valorFrete: serializer.fromJson<double?>(json['valorFrete']),
      valorSeguro: serializer.fromJson<double?>(json['valorSeguro']),
      valorSubtotal: serializer.fromJson<double?>(json['valorSubtotal']),
      taxaComissao: serializer.fromJson<double?>(json['taxaComissao']),
      valorComissao: serializer.fromJson<double?>(json['valorComissao']),
      taxaDesconto: serializer.fromJson<double?>(json['taxaDesconto']),
      valorDesconto: serializer.fromJson<double?>(json['valorDesconto']),
      valorTotal: serializer.fromJson<double?>(json['valorTotal']),
      situacao: serializer.fromJson<String?>(json['situacao']),
      diaFixoParcela: serializer.fromJson<String?>(json['diaFixoParcela']),
      observacao: serializer.fromJson<String?>(json['observacao']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'idVendaOrcamentoCabecalho':
          serializer.toJson<int?>(idVendaOrcamentoCabecalho),
      'idNotaFiscalTipo': serializer.toJson<int?>(idNotaFiscalTipo),
      'idVendedor': serializer.toJson<int?>(idVendedor),
      'idVendaCondicoesPagamento':
          serializer.toJson<int?>(idVendaCondicoesPagamento),
      'idTransportadora': serializer.toJson<int?>(idTransportadora),
      'idCliente': serializer.toJson<int?>(idCliente),
      'localEntrega': serializer.toJson<String?>(localEntrega),
      'localCobranca': serializer.toJson<String?>(localCobranca),
      'tipoFrete': serializer.toJson<String?>(tipoFrete),
      'formaPagamento': serializer.toJson<String?>(formaPagamento),
      'dataVenda': serializer.toJson<DateTime?>(dataVenda),
      'dataSaida': serializer.toJson<DateTime?>(dataSaida),
      'horaSaida': serializer.toJson<String?>(horaSaida),
      'numeroFatura': serializer.toJson<int?>(numeroFatura),
      'valorFrete': serializer.toJson<double?>(valorFrete),
      'valorSeguro': serializer.toJson<double?>(valorSeguro),
      'valorSubtotal': serializer.toJson<double?>(valorSubtotal),
      'taxaComissao': serializer.toJson<double?>(taxaComissao),
      'valorComissao': serializer.toJson<double?>(valorComissao),
      'taxaDesconto': serializer.toJson<double?>(taxaDesconto),
      'valorDesconto': serializer.toJson<double?>(valorDesconto),
      'valorTotal': serializer.toJson<double?>(valorTotal),
      'situacao': serializer.toJson<String?>(situacao),
      'diaFixoParcela': serializer.toJson<String?>(diaFixoParcela),
      'observacao': serializer.toJson<String?>(observacao),
    };
  }

  VendaCabecalho copyWith(
          {Value<int?> id = const Value.absent(),
          Value<int?> idVendaOrcamentoCabecalho = const Value.absent(),
          Value<int?> idNotaFiscalTipo = const Value.absent(),
          Value<int?> idVendedor = const Value.absent(),
          Value<int?> idVendaCondicoesPagamento = const Value.absent(),
          Value<int?> idTransportadora = const Value.absent(),
          Value<int?> idCliente = const Value.absent(),
          Value<String?> localEntrega = const Value.absent(),
          Value<String?> localCobranca = const Value.absent(),
          Value<String?> tipoFrete = const Value.absent(),
          Value<String?> formaPagamento = const Value.absent(),
          Value<DateTime?> dataVenda = const Value.absent(),
          Value<DateTime?> dataSaida = const Value.absent(),
          Value<String?> horaSaida = const Value.absent(),
          Value<int?> numeroFatura = const Value.absent(),
          Value<double?> valorFrete = const Value.absent(),
          Value<double?> valorSeguro = const Value.absent(),
          Value<double?> valorSubtotal = const Value.absent(),
          Value<double?> taxaComissao = const Value.absent(),
          Value<double?> valorComissao = const Value.absent(),
          Value<double?> taxaDesconto = const Value.absent(),
          Value<double?> valorDesconto = const Value.absent(),
          Value<double?> valorTotal = const Value.absent(),
          Value<String?> situacao = const Value.absent(),
          Value<String?> diaFixoParcela = const Value.absent(),
          Value<String?> observacao = const Value.absent()}) =>
      VendaCabecalho(
        id: id.present ? id.value : this.id,
        idVendaOrcamentoCabecalho: idVendaOrcamentoCabecalho.present
            ? idVendaOrcamentoCabecalho.value
            : this.idVendaOrcamentoCabecalho,
        idNotaFiscalTipo: idNotaFiscalTipo.present
            ? idNotaFiscalTipo.value
            : this.idNotaFiscalTipo,
        idVendedor: idVendedor.present ? idVendedor.value : this.idVendedor,
        idVendaCondicoesPagamento: idVendaCondicoesPagamento.present
            ? idVendaCondicoesPagamento.value
            : this.idVendaCondicoesPagamento,
        idTransportadora: idTransportadora.present
            ? idTransportadora.value
            : this.idTransportadora,
        idCliente: idCliente.present ? idCliente.value : this.idCliente,
        localEntrega:
            localEntrega.present ? localEntrega.value : this.localEntrega,
        localCobranca:
            localCobranca.present ? localCobranca.value : this.localCobranca,
        tipoFrete: tipoFrete.present ? tipoFrete.value : this.tipoFrete,
        formaPagamento:
            formaPagamento.present ? formaPagamento.value : this.formaPagamento,
        dataVenda: dataVenda.present ? dataVenda.value : this.dataVenda,
        dataSaida: dataSaida.present ? dataSaida.value : this.dataSaida,
        horaSaida: horaSaida.present ? horaSaida.value : this.horaSaida,
        numeroFatura:
            numeroFatura.present ? numeroFatura.value : this.numeroFatura,
        valorFrete: valorFrete.present ? valorFrete.value : this.valorFrete,
        valorSeguro: valorSeguro.present ? valorSeguro.value : this.valorSeguro,
        valorSubtotal:
            valorSubtotal.present ? valorSubtotal.value : this.valorSubtotal,
        taxaComissao:
            taxaComissao.present ? taxaComissao.value : this.taxaComissao,
        valorComissao:
            valorComissao.present ? valorComissao.value : this.valorComissao,
        taxaDesconto:
            taxaDesconto.present ? taxaDesconto.value : this.taxaDesconto,
        valorDesconto:
            valorDesconto.present ? valorDesconto.value : this.valorDesconto,
        valorTotal: valorTotal.present ? valorTotal.value : this.valorTotal,
        situacao: situacao.present ? situacao.value : this.situacao,
        diaFixoParcela:
            diaFixoParcela.present ? diaFixoParcela.value : this.diaFixoParcela,
        observacao: observacao.present ? observacao.value : this.observacao,
      );
  VendaCabecalho copyWithCompanion(VendaCabecalhosCompanion data) {
    return VendaCabecalho(
      id: data.id.present ? data.id.value : this.id,
      idVendaOrcamentoCabecalho: data.idVendaOrcamentoCabecalho.present
          ? data.idVendaOrcamentoCabecalho.value
          : this.idVendaOrcamentoCabecalho,
      idNotaFiscalTipo: data.idNotaFiscalTipo.present
          ? data.idNotaFiscalTipo.value
          : this.idNotaFiscalTipo,
      idVendedor:
          data.idVendedor.present ? data.idVendedor.value : this.idVendedor,
      idVendaCondicoesPagamento: data.idVendaCondicoesPagamento.present
          ? data.idVendaCondicoesPagamento.value
          : this.idVendaCondicoesPagamento,
      idTransportadora: data.idTransportadora.present
          ? data.idTransportadora.value
          : this.idTransportadora,
      idCliente: data.idCliente.present ? data.idCliente.value : this.idCliente,
      localEntrega: data.localEntrega.present
          ? data.localEntrega.value
          : this.localEntrega,
      localCobranca: data.localCobranca.present
          ? data.localCobranca.value
          : this.localCobranca,
      tipoFrete: data.tipoFrete.present ? data.tipoFrete.value : this.tipoFrete,
      formaPagamento: data.formaPagamento.present
          ? data.formaPagamento.value
          : this.formaPagamento,
      dataVenda: data.dataVenda.present ? data.dataVenda.value : this.dataVenda,
      dataSaida: data.dataSaida.present ? data.dataSaida.value : this.dataSaida,
      horaSaida: data.horaSaida.present ? data.horaSaida.value : this.horaSaida,
      numeroFatura: data.numeroFatura.present
          ? data.numeroFatura.value
          : this.numeroFatura,
      valorFrete:
          data.valorFrete.present ? data.valorFrete.value : this.valorFrete,
      valorSeguro:
          data.valorSeguro.present ? data.valorSeguro.value : this.valorSeguro,
      valorSubtotal: data.valorSubtotal.present
          ? data.valorSubtotal.value
          : this.valorSubtotal,
      taxaComissao: data.taxaComissao.present
          ? data.taxaComissao.value
          : this.taxaComissao,
      valorComissao: data.valorComissao.present
          ? data.valorComissao.value
          : this.valorComissao,
      taxaDesconto: data.taxaDesconto.present
          ? data.taxaDesconto.value
          : this.taxaDesconto,
      valorDesconto: data.valorDesconto.present
          ? data.valorDesconto.value
          : this.valorDesconto,
      valorTotal:
          data.valorTotal.present ? data.valorTotal.value : this.valorTotal,
      situacao: data.situacao.present ? data.situacao.value : this.situacao,
      diaFixoParcela: data.diaFixoParcela.present
          ? data.diaFixoParcela.value
          : this.diaFixoParcela,
      observacao:
          data.observacao.present ? data.observacao.value : this.observacao,
    );
  }

  @override
  String toString() {
    return (StringBuffer('VendaCabecalho(')
          ..write('id: $id, ')
          ..write('idVendaOrcamentoCabecalho: $idVendaOrcamentoCabecalho, ')
          ..write('idNotaFiscalTipo: $idNotaFiscalTipo, ')
          ..write('idVendedor: $idVendedor, ')
          ..write('idVendaCondicoesPagamento: $idVendaCondicoesPagamento, ')
          ..write('idTransportadora: $idTransportadora, ')
          ..write('idCliente: $idCliente, ')
          ..write('localEntrega: $localEntrega, ')
          ..write('localCobranca: $localCobranca, ')
          ..write('tipoFrete: $tipoFrete, ')
          ..write('formaPagamento: $formaPagamento, ')
          ..write('dataVenda: $dataVenda, ')
          ..write('dataSaida: $dataSaida, ')
          ..write('horaSaida: $horaSaida, ')
          ..write('numeroFatura: $numeroFatura, ')
          ..write('valorFrete: $valorFrete, ')
          ..write('valorSeguro: $valorSeguro, ')
          ..write('valorSubtotal: $valorSubtotal, ')
          ..write('taxaComissao: $taxaComissao, ')
          ..write('valorComissao: $valorComissao, ')
          ..write('taxaDesconto: $taxaDesconto, ')
          ..write('valorDesconto: $valorDesconto, ')
          ..write('valorTotal: $valorTotal, ')
          ..write('situacao: $situacao, ')
          ..write('diaFixoParcela: $diaFixoParcela, ')
          ..write('observacao: $observacao')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hashAll([
        id,
        idVendaOrcamentoCabecalho,
        idNotaFiscalTipo,
        idVendedor,
        idVendaCondicoesPagamento,
        idTransportadora,
        idCliente,
        localEntrega,
        localCobranca,
        tipoFrete,
        formaPagamento,
        dataVenda,
        dataSaida,
        horaSaida,
        numeroFatura,
        valorFrete,
        valorSeguro,
        valorSubtotal,
        taxaComissao,
        valorComissao,
        taxaDesconto,
        valorDesconto,
        valorTotal,
        situacao,
        diaFixoParcela,
        observacao
      ]);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is VendaCabecalho &&
          other.id == this.id &&
          other.idVendaOrcamentoCabecalho == this.idVendaOrcamentoCabecalho &&
          other.idNotaFiscalTipo == this.idNotaFiscalTipo &&
          other.idVendedor == this.idVendedor &&
          other.idVendaCondicoesPagamento == this.idVendaCondicoesPagamento &&
          other.idTransportadora == this.idTransportadora &&
          other.idCliente == this.idCliente &&
          other.localEntrega == this.localEntrega &&
          other.localCobranca == this.localCobranca &&
          other.tipoFrete == this.tipoFrete &&
          other.formaPagamento == this.formaPagamento &&
          other.dataVenda == this.dataVenda &&
          other.dataSaida == this.dataSaida &&
          other.horaSaida == this.horaSaida &&
          other.numeroFatura == this.numeroFatura &&
          other.valorFrete == this.valorFrete &&
          other.valorSeguro == this.valorSeguro &&
          other.valorSubtotal == this.valorSubtotal &&
          other.taxaComissao == this.taxaComissao &&
          other.valorComissao == this.valorComissao &&
          other.taxaDesconto == this.taxaDesconto &&
          other.valorDesconto == this.valorDesconto &&
          other.valorTotal == this.valorTotal &&
          other.situacao == this.situacao &&
          other.diaFixoParcela == this.diaFixoParcela &&
          other.observacao == this.observacao);
}

class VendaCabecalhosCompanion extends UpdateCompanion<VendaCabecalho> {
  final Value<int?> id;
  final Value<int?> idVendaOrcamentoCabecalho;
  final Value<int?> idNotaFiscalTipo;
  final Value<int?> idVendedor;
  final Value<int?> idVendaCondicoesPagamento;
  final Value<int?> idTransportadora;
  final Value<int?> idCliente;
  final Value<String?> localEntrega;
  final Value<String?> localCobranca;
  final Value<String?> tipoFrete;
  final Value<String?> formaPagamento;
  final Value<DateTime?> dataVenda;
  final Value<DateTime?> dataSaida;
  final Value<String?> horaSaida;
  final Value<int?> numeroFatura;
  final Value<double?> valorFrete;
  final Value<double?> valorSeguro;
  final Value<double?> valorSubtotal;
  final Value<double?> taxaComissao;
  final Value<double?> valorComissao;
  final Value<double?> taxaDesconto;
  final Value<double?> valorDesconto;
  final Value<double?> valorTotal;
  final Value<String?> situacao;
  final Value<String?> diaFixoParcela;
  final Value<String?> observacao;
  const VendaCabecalhosCompanion({
    this.id = const Value.absent(),
    this.idVendaOrcamentoCabecalho = const Value.absent(),
    this.idNotaFiscalTipo = const Value.absent(),
    this.idVendedor = const Value.absent(),
    this.idVendaCondicoesPagamento = const Value.absent(),
    this.idTransportadora = const Value.absent(),
    this.idCliente = const Value.absent(),
    this.localEntrega = const Value.absent(),
    this.localCobranca = const Value.absent(),
    this.tipoFrete = const Value.absent(),
    this.formaPagamento = const Value.absent(),
    this.dataVenda = const Value.absent(),
    this.dataSaida = const Value.absent(),
    this.horaSaida = const Value.absent(),
    this.numeroFatura = const Value.absent(),
    this.valorFrete = const Value.absent(),
    this.valorSeguro = const Value.absent(),
    this.valorSubtotal = const Value.absent(),
    this.taxaComissao = const Value.absent(),
    this.valorComissao = const Value.absent(),
    this.taxaDesconto = const Value.absent(),
    this.valorDesconto = const Value.absent(),
    this.valorTotal = const Value.absent(),
    this.situacao = const Value.absent(),
    this.diaFixoParcela = const Value.absent(),
    this.observacao = const Value.absent(),
  });
  VendaCabecalhosCompanion.insert({
    this.id = const Value.absent(),
    this.idVendaOrcamentoCabecalho = const Value.absent(),
    this.idNotaFiscalTipo = const Value.absent(),
    this.idVendedor = const Value.absent(),
    this.idVendaCondicoesPagamento = const Value.absent(),
    this.idTransportadora = const Value.absent(),
    this.idCliente = const Value.absent(),
    this.localEntrega = const Value.absent(),
    this.localCobranca = const Value.absent(),
    this.tipoFrete = const Value.absent(),
    this.formaPagamento = const Value.absent(),
    this.dataVenda = const Value.absent(),
    this.dataSaida = const Value.absent(),
    this.horaSaida = const Value.absent(),
    this.numeroFatura = const Value.absent(),
    this.valorFrete = const Value.absent(),
    this.valorSeguro = const Value.absent(),
    this.valorSubtotal = const Value.absent(),
    this.taxaComissao = const Value.absent(),
    this.valorComissao = const Value.absent(),
    this.taxaDesconto = const Value.absent(),
    this.valorDesconto = const Value.absent(),
    this.valorTotal = const Value.absent(),
    this.situacao = const Value.absent(),
    this.diaFixoParcela = const Value.absent(),
    this.observacao = const Value.absent(),
  });
  static Insertable<VendaCabecalho> custom({
    Expression<int>? id,
    Expression<int>? idVendaOrcamentoCabecalho,
    Expression<int>? idNotaFiscalTipo,
    Expression<int>? idVendedor,
    Expression<int>? idVendaCondicoesPagamento,
    Expression<int>? idTransportadora,
    Expression<int>? idCliente,
    Expression<String>? localEntrega,
    Expression<String>? localCobranca,
    Expression<String>? tipoFrete,
    Expression<String>? formaPagamento,
    Expression<DateTime>? dataVenda,
    Expression<DateTime>? dataSaida,
    Expression<String>? horaSaida,
    Expression<int>? numeroFatura,
    Expression<double>? valorFrete,
    Expression<double>? valorSeguro,
    Expression<double>? valorSubtotal,
    Expression<double>? taxaComissao,
    Expression<double>? valorComissao,
    Expression<double>? taxaDesconto,
    Expression<double>? valorDesconto,
    Expression<double>? valorTotal,
    Expression<String>? situacao,
    Expression<String>? diaFixoParcela,
    Expression<String>? observacao,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (idVendaOrcamentoCabecalho != null)
        'id_venda_orcamento_cabecalho': idVendaOrcamentoCabecalho,
      if (idNotaFiscalTipo != null) 'id_nota_fiscal_tipo': idNotaFiscalTipo,
      if (idVendedor != null) 'id_vendedor': idVendedor,
      if (idVendaCondicoesPagamento != null)
        'id_venda_condicoes_pagamento': idVendaCondicoesPagamento,
      if (idTransportadora != null) 'id_transportadora': idTransportadora,
      if (idCliente != null) 'id_cliente': idCliente,
      if (localEntrega != null) 'local_entrega': localEntrega,
      if (localCobranca != null) 'local_cobranca': localCobranca,
      if (tipoFrete != null) 'tipo_frete': tipoFrete,
      if (formaPagamento != null) 'forma_pagamento': formaPagamento,
      if (dataVenda != null) 'data_venda': dataVenda,
      if (dataSaida != null) 'data_saida': dataSaida,
      if (horaSaida != null) 'hora_saida': horaSaida,
      if (numeroFatura != null) 'numero_fatura': numeroFatura,
      if (valorFrete != null) 'valor_frete': valorFrete,
      if (valorSeguro != null) 'valor_seguro': valorSeguro,
      if (valorSubtotal != null) 'valor_subtotal': valorSubtotal,
      if (taxaComissao != null) 'taxa_comissao': taxaComissao,
      if (valorComissao != null) 'valor_comissao': valorComissao,
      if (taxaDesconto != null) 'taxa_desconto': taxaDesconto,
      if (valorDesconto != null) 'valor_desconto': valorDesconto,
      if (valorTotal != null) 'valor_total': valorTotal,
      if (situacao != null) 'situacao': situacao,
      if (diaFixoParcela != null) 'dia_fixo_parcela': diaFixoParcela,
      if (observacao != null) 'observacao': observacao,
    });
  }

  VendaCabecalhosCompanion copyWith(
      {Value<int?>? id,
      Value<int?>? idVendaOrcamentoCabecalho,
      Value<int?>? idNotaFiscalTipo,
      Value<int?>? idVendedor,
      Value<int?>? idVendaCondicoesPagamento,
      Value<int?>? idTransportadora,
      Value<int?>? idCliente,
      Value<String?>? localEntrega,
      Value<String?>? localCobranca,
      Value<String?>? tipoFrete,
      Value<String?>? formaPagamento,
      Value<DateTime?>? dataVenda,
      Value<DateTime?>? dataSaida,
      Value<String?>? horaSaida,
      Value<int?>? numeroFatura,
      Value<double?>? valorFrete,
      Value<double?>? valorSeguro,
      Value<double?>? valorSubtotal,
      Value<double?>? taxaComissao,
      Value<double?>? valorComissao,
      Value<double?>? taxaDesconto,
      Value<double?>? valorDesconto,
      Value<double?>? valorTotal,
      Value<String?>? situacao,
      Value<String?>? diaFixoParcela,
      Value<String?>? observacao}) {
    return VendaCabecalhosCompanion(
      id: id ?? this.id,
      idVendaOrcamentoCabecalho:
          idVendaOrcamentoCabecalho ?? this.idVendaOrcamentoCabecalho,
      idNotaFiscalTipo: idNotaFiscalTipo ?? this.idNotaFiscalTipo,
      idVendedor: idVendedor ?? this.idVendedor,
      idVendaCondicoesPagamento:
          idVendaCondicoesPagamento ?? this.idVendaCondicoesPagamento,
      idTransportadora: idTransportadora ?? this.idTransportadora,
      idCliente: idCliente ?? this.idCliente,
      localEntrega: localEntrega ?? this.localEntrega,
      localCobranca: localCobranca ?? this.localCobranca,
      tipoFrete: tipoFrete ?? this.tipoFrete,
      formaPagamento: formaPagamento ?? this.formaPagamento,
      dataVenda: dataVenda ?? this.dataVenda,
      dataSaida: dataSaida ?? this.dataSaida,
      horaSaida: horaSaida ?? this.horaSaida,
      numeroFatura: numeroFatura ?? this.numeroFatura,
      valorFrete: valorFrete ?? this.valorFrete,
      valorSeguro: valorSeguro ?? this.valorSeguro,
      valorSubtotal: valorSubtotal ?? this.valorSubtotal,
      taxaComissao: taxaComissao ?? this.taxaComissao,
      valorComissao: valorComissao ?? this.valorComissao,
      taxaDesconto: taxaDesconto ?? this.taxaDesconto,
      valorDesconto: valorDesconto ?? this.valorDesconto,
      valorTotal: valorTotal ?? this.valorTotal,
      situacao: situacao ?? this.situacao,
      diaFixoParcela: diaFixoParcela ?? this.diaFixoParcela,
      observacao: observacao ?? this.observacao,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (idVendaOrcamentoCabecalho.present) {
      map['id_venda_orcamento_cabecalho'] =
          Variable<int>(idVendaOrcamentoCabecalho.value);
    }
    if (idNotaFiscalTipo.present) {
      map['id_nota_fiscal_tipo'] = Variable<int>(idNotaFiscalTipo.value);
    }
    if (idVendedor.present) {
      map['id_vendedor'] = Variable<int>(idVendedor.value);
    }
    if (idVendaCondicoesPagamento.present) {
      map['id_venda_condicoes_pagamento'] =
          Variable<int>(idVendaCondicoesPagamento.value);
    }
    if (idTransportadora.present) {
      map['id_transportadora'] = Variable<int>(idTransportadora.value);
    }
    if (idCliente.present) {
      map['id_cliente'] = Variable<int>(idCliente.value);
    }
    if (localEntrega.present) {
      map['local_entrega'] = Variable<String>(localEntrega.value);
    }
    if (localCobranca.present) {
      map['local_cobranca'] = Variable<String>(localCobranca.value);
    }
    if (tipoFrete.present) {
      map['tipo_frete'] = Variable<String>(tipoFrete.value);
    }
    if (formaPagamento.present) {
      map['forma_pagamento'] = Variable<String>(formaPagamento.value);
    }
    if (dataVenda.present) {
      map['data_venda'] = Variable<DateTime>(dataVenda.value);
    }
    if (dataSaida.present) {
      map['data_saida'] = Variable<DateTime>(dataSaida.value);
    }
    if (horaSaida.present) {
      map['hora_saida'] = Variable<String>(horaSaida.value);
    }
    if (numeroFatura.present) {
      map['numero_fatura'] = Variable<int>(numeroFatura.value);
    }
    if (valorFrete.present) {
      map['valor_frete'] = Variable<double>(valorFrete.value);
    }
    if (valorSeguro.present) {
      map['valor_seguro'] = Variable<double>(valorSeguro.value);
    }
    if (valorSubtotal.present) {
      map['valor_subtotal'] = Variable<double>(valorSubtotal.value);
    }
    if (taxaComissao.present) {
      map['taxa_comissao'] = Variable<double>(taxaComissao.value);
    }
    if (valorComissao.present) {
      map['valor_comissao'] = Variable<double>(valorComissao.value);
    }
    if (taxaDesconto.present) {
      map['taxa_desconto'] = Variable<double>(taxaDesconto.value);
    }
    if (valorDesconto.present) {
      map['valor_desconto'] = Variable<double>(valorDesconto.value);
    }
    if (valorTotal.present) {
      map['valor_total'] = Variable<double>(valorTotal.value);
    }
    if (situacao.present) {
      map['situacao'] = Variable<String>(situacao.value);
    }
    if (diaFixoParcela.present) {
      map['dia_fixo_parcela'] = Variable<String>(diaFixoParcela.value);
    }
    if (observacao.present) {
      map['observacao'] = Variable<String>(observacao.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('VendaCabecalhosCompanion(')
          ..write('id: $id, ')
          ..write('idVendaOrcamentoCabecalho: $idVendaOrcamentoCabecalho, ')
          ..write('idNotaFiscalTipo: $idNotaFiscalTipo, ')
          ..write('idVendedor: $idVendedor, ')
          ..write('idVendaCondicoesPagamento: $idVendaCondicoesPagamento, ')
          ..write('idTransportadora: $idTransportadora, ')
          ..write('idCliente: $idCliente, ')
          ..write('localEntrega: $localEntrega, ')
          ..write('localCobranca: $localCobranca, ')
          ..write('tipoFrete: $tipoFrete, ')
          ..write('formaPagamento: $formaPagamento, ')
          ..write('dataVenda: $dataVenda, ')
          ..write('dataSaida: $dataSaida, ')
          ..write('horaSaida: $horaSaida, ')
          ..write('numeroFatura: $numeroFatura, ')
          ..write('valorFrete: $valorFrete, ')
          ..write('valorSeguro: $valorSeguro, ')
          ..write('valorSubtotal: $valorSubtotal, ')
          ..write('taxaComissao: $taxaComissao, ')
          ..write('valorComissao: $valorComissao, ')
          ..write('taxaDesconto: $taxaDesconto, ')
          ..write('valorDesconto: $valorDesconto, ')
          ..write('valorTotal: $valorTotal, ')
          ..write('situacao: $situacao, ')
          ..write('diaFixoParcela: $diaFixoParcela, ')
          ..write('observacao: $observacao')
          ..write(')'))
        .toString();
  }
}

class $NotaFiscalModelosTable extends NotaFiscalModelos
    with TableInfo<$NotaFiscalModelosTable, NotaFiscalModelo> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $NotaFiscalModelosTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
      'id', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _codigoMeta = const VerificationMeta('codigo');
  @override
  late final GeneratedColumn<String> codigo = GeneratedColumn<String>(
      'codigo', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 2),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _descricaoMeta =
      const VerificationMeta('descricao');
  @override
  late final GeneratedColumn<String> descricao = GeneratedColumn<String>(
      'descricao', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 100),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _modeloMeta = const VerificationMeta('modelo');
  @override
  late final GeneratedColumn<String> modelo = GeneratedColumn<String>(
      'modelo', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 10),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  @override
  List<GeneratedColumn> get $columns => [id, codigo, descricao, modelo];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'nota_fiscal_modelo';
  @override
  VerificationContext validateIntegrity(Insertable<NotaFiscalModelo> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('codigo')) {
      context.handle(_codigoMeta,
          codigo.isAcceptableOrUnknown(data['codigo']!, _codigoMeta));
    }
    if (data.containsKey('descricao')) {
      context.handle(_descricaoMeta,
          descricao.isAcceptableOrUnknown(data['descricao']!, _descricaoMeta));
    }
    if (data.containsKey('modelo')) {
      context.handle(_modeloMeta,
          modelo.isAcceptableOrUnknown(data['modelo']!, _modeloMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  NotaFiscalModelo map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return NotaFiscalModelo(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id']),
      codigo: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}codigo']),
      descricao: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}descricao']),
      modelo: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}modelo']),
    );
  }

  @override
  $NotaFiscalModelosTable createAlias(String alias) {
    return $NotaFiscalModelosTable(attachedDatabase, alias);
  }
}

class NotaFiscalModelo extends DataClass
    implements Insertable<NotaFiscalModelo> {
  final int? id;
  final String? codigo;
  final String? descricao;
  final String? modelo;
  const NotaFiscalModelo({this.id, this.codigo, this.descricao, this.modelo});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || codigo != null) {
      map['codigo'] = Variable<String>(codigo);
    }
    if (!nullToAbsent || descricao != null) {
      map['descricao'] = Variable<String>(descricao);
    }
    if (!nullToAbsent || modelo != null) {
      map['modelo'] = Variable<String>(modelo);
    }
    return map;
  }

  factory NotaFiscalModelo.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return NotaFiscalModelo(
      id: serializer.fromJson<int?>(json['id']),
      codigo: serializer.fromJson<String?>(json['codigo']),
      descricao: serializer.fromJson<String?>(json['descricao']),
      modelo: serializer.fromJson<String?>(json['modelo']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'codigo': serializer.toJson<String?>(codigo),
      'descricao': serializer.toJson<String?>(descricao),
      'modelo': serializer.toJson<String?>(modelo),
    };
  }

  NotaFiscalModelo copyWith(
          {Value<int?> id = const Value.absent(),
          Value<String?> codigo = const Value.absent(),
          Value<String?> descricao = const Value.absent(),
          Value<String?> modelo = const Value.absent()}) =>
      NotaFiscalModelo(
        id: id.present ? id.value : this.id,
        codigo: codigo.present ? codigo.value : this.codigo,
        descricao: descricao.present ? descricao.value : this.descricao,
        modelo: modelo.present ? modelo.value : this.modelo,
      );
  NotaFiscalModelo copyWithCompanion(NotaFiscalModelosCompanion data) {
    return NotaFiscalModelo(
      id: data.id.present ? data.id.value : this.id,
      codigo: data.codigo.present ? data.codigo.value : this.codigo,
      descricao: data.descricao.present ? data.descricao.value : this.descricao,
      modelo: data.modelo.present ? data.modelo.value : this.modelo,
    );
  }

  @override
  String toString() {
    return (StringBuffer('NotaFiscalModelo(')
          ..write('id: $id, ')
          ..write('codigo: $codigo, ')
          ..write('descricao: $descricao, ')
          ..write('modelo: $modelo')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(id, codigo, descricao, modelo);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is NotaFiscalModelo &&
          other.id == this.id &&
          other.codigo == this.codigo &&
          other.descricao == this.descricao &&
          other.modelo == this.modelo);
}

class NotaFiscalModelosCompanion extends UpdateCompanion<NotaFiscalModelo> {
  final Value<int?> id;
  final Value<String?> codigo;
  final Value<String?> descricao;
  final Value<String?> modelo;
  const NotaFiscalModelosCompanion({
    this.id = const Value.absent(),
    this.codigo = const Value.absent(),
    this.descricao = const Value.absent(),
    this.modelo = const Value.absent(),
  });
  NotaFiscalModelosCompanion.insert({
    this.id = const Value.absent(),
    this.codigo = const Value.absent(),
    this.descricao = const Value.absent(),
    this.modelo = const Value.absent(),
  });
  static Insertable<NotaFiscalModelo> custom({
    Expression<int>? id,
    Expression<String>? codigo,
    Expression<String>? descricao,
    Expression<String>? modelo,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (codigo != null) 'codigo': codigo,
      if (descricao != null) 'descricao': descricao,
      if (modelo != null) 'modelo': modelo,
    });
  }

  NotaFiscalModelosCompanion copyWith(
      {Value<int?>? id,
      Value<String?>? codigo,
      Value<String?>? descricao,
      Value<String?>? modelo}) {
    return NotaFiscalModelosCompanion(
      id: id ?? this.id,
      codigo: codigo ?? this.codigo,
      descricao: descricao ?? this.descricao,
      modelo: modelo ?? this.modelo,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (codigo.present) {
      map['codigo'] = Variable<String>(codigo.value);
    }
    if (descricao.present) {
      map['descricao'] = Variable<String>(descricao.value);
    }
    if (modelo.present) {
      map['modelo'] = Variable<String>(modelo.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('NotaFiscalModelosCompanion(')
          ..write('id: $id, ')
          ..write('codigo: $codigo, ')
          ..write('descricao: $descricao, ')
          ..write('modelo: $modelo')
          ..write(')'))
        .toString();
  }
}

class $NotaFiscalTiposTable extends NotaFiscalTipos
    with TableInfo<$NotaFiscalTiposTable, NotaFiscalTipo> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $NotaFiscalTiposTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
      'id', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _idNotaFiscalModeloMeta =
      const VerificationMeta('idNotaFiscalModelo');
  @override
  late final GeneratedColumn<int> idNotaFiscalModelo = GeneratedColumn<int>(
      'id_nota_fiscal_modelo', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _nomeMeta = const VerificationMeta('nome');
  @override
  late final GeneratedColumn<String> nome = GeneratedColumn<String>(
      'nome', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 50),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _descricaoMeta =
      const VerificationMeta('descricao');
  @override
  late final GeneratedColumn<String> descricao = GeneratedColumn<String>(
      'descricao', aliasedName, true,
      type: DriftSqlType.string, requiredDuringInsert: false);
  static const VerificationMeta _serieMeta = const VerificationMeta('serie');
  @override
  late final GeneratedColumn<String> serie = GeneratedColumn<String>(
      'serie', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 3),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _serieScanMeta =
      const VerificationMeta('serieScan');
  @override
  late final GeneratedColumn<String> serieScan = GeneratedColumn<String>(
      'serie_scan', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 3),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _ultimoNumeroMeta =
      const VerificationMeta('ultimoNumero');
  @override
  late final GeneratedColumn<int> ultimoNumero = GeneratedColumn<int>(
      'ultimo_numero', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  @override
  List<GeneratedColumn> get $columns =>
      [id, idNotaFiscalModelo, nome, descricao, serie, serieScan, ultimoNumero];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'nota_fiscal_tipo';
  @override
  VerificationContext validateIntegrity(Insertable<NotaFiscalTipo> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('id_nota_fiscal_modelo')) {
      context.handle(
          _idNotaFiscalModeloMeta,
          idNotaFiscalModelo.isAcceptableOrUnknown(
              data['id_nota_fiscal_modelo']!, _idNotaFiscalModeloMeta));
    }
    if (data.containsKey('nome')) {
      context.handle(
          _nomeMeta, nome.isAcceptableOrUnknown(data['nome']!, _nomeMeta));
    }
    if (data.containsKey('descricao')) {
      context.handle(_descricaoMeta,
          descricao.isAcceptableOrUnknown(data['descricao']!, _descricaoMeta));
    }
    if (data.containsKey('serie')) {
      context.handle(
          _serieMeta, serie.isAcceptableOrUnknown(data['serie']!, _serieMeta));
    }
    if (data.containsKey('serie_scan')) {
      context.handle(_serieScanMeta,
          serieScan.isAcceptableOrUnknown(data['serie_scan']!, _serieScanMeta));
    }
    if (data.containsKey('ultimo_numero')) {
      context.handle(
          _ultimoNumeroMeta,
          ultimoNumero.isAcceptableOrUnknown(
              data['ultimo_numero']!, _ultimoNumeroMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  NotaFiscalTipo map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return NotaFiscalTipo(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id']),
      idNotaFiscalModelo: attachedDatabase.typeMapping.read(
          DriftSqlType.int, data['${effectivePrefix}id_nota_fiscal_modelo']),
      nome: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}nome']),
      descricao: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}descricao']),
      serie: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}serie']),
      serieScan: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}serie_scan']),
      ultimoNumero: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}ultimo_numero']),
    );
  }

  @override
  $NotaFiscalTiposTable createAlias(String alias) {
    return $NotaFiscalTiposTable(attachedDatabase, alias);
  }
}

class NotaFiscalTipo extends DataClass implements Insertable<NotaFiscalTipo> {
  final int? id;
  final int? idNotaFiscalModelo;
  final String? nome;
  final String? descricao;
  final String? serie;
  final String? serieScan;
  final int? ultimoNumero;
  const NotaFiscalTipo(
      {this.id,
      this.idNotaFiscalModelo,
      this.nome,
      this.descricao,
      this.serie,
      this.serieScan,
      this.ultimoNumero});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || idNotaFiscalModelo != null) {
      map['id_nota_fiscal_modelo'] = Variable<int>(idNotaFiscalModelo);
    }
    if (!nullToAbsent || nome != null) {
      map['nome'] = Variable<String>(nome);
    }
    if (!nullToAbsent || descricao != null) {
      map['descricao'] = Variable<String>(descricao);
    }
    if (!nullToAbsent || serie != null) {
      map['serie'] = Variable<String>(serie);
    }
    if (!nullToAbsent || serieScan != null) {
      map['serie_scan'] = Variable<String>(serieScan);
    }
    if (!nullToAbsent || ultimoNumero != null) {
      map['ultimo_numero'] = Variable<int>(ultimoNumero);
    }
    return map;
  }

  factory NotaFiscalTipo.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return NotaFiscalTipo(
      id: serializer.fromJson<int?>(json['id']),
      idNotaFiscalModelo: serializer.fromJson<int?>(json['idNotaFiscalModelo']),
      nome: serializer.fromJson<String?>(json['nome']),
      descricao: serializer.fromJson<String?>(json['descricao']),
      serie: serializer.fromJson<String?>(json['serie']),
      serieScan: serializer.fromJson<String?>(json['serieScan']),
      ultimoNumero: serializer.fromJson<int?>(json['ultimoNumero']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'idNotaFiscalModelo': serializer.toJson<int?>(idNotaFiscalModelo),
      'nome': serializer.toJson<String?>(nome),
      'descricao': serializer.toJson<String?>(descricao),
      'serie': serializer.toJson<String?>(serie),
      'serieScan': serializer.toJson<String?>(serieScan),
      'ultimoNumero': serializer.toJson<int?>(ultimoNumero),
    };
  }

  NotaFiscalTipo copyWith(
          {Value<int?> id = const Value.absent(),
          Value<int?> idNotaFiscalModelo = const Value.absent(),
          Value<String?> nome = const Value.absent(),
          Value<String?> descricao = const Value.absent(),
          Value<String?> serie = const Value.absent(),
          Value<String?> serieScan = const Value.absent(),
          Value<int?> ultimoNumero = const Value.absent()}) =>
      NotaFiscalTipo(
        id: id.present ? id.value : this.id,
        idNotaFiscalModelo: idNotaFiscalModelo.present
            ? idNotaFiscalModelo.value
            : this.idNotaFiscalModelo,
        nome: nome.present ? nome.value : this.nome,
        descricao: descricao.present ? descricao.value : this.descricao,
        serie: serie.present ? serie.value : this.serie,
        serieScan: serieScan.present ? serieScan.value : this.serieScan,
        ultimoNumero:
            ultimoNumero.present ? ultimoNumero.value : this.ultimoNumero,
      );
  NotaFiscalTipo copyWithCompanion(NotaFiscalTiposCompanion data) {
    return NotaFiscalTipo(
      id: data.id.present ? data.id.value : this.id,
      idNotaFiscalModelo: data.idNotaFiscalModelo.present
          ? data.idNotaFiscalModelo.value
          : this.idNotaFiscalModelo,
      nome: data.nome.present ? data.nome.value : this.nome,
      descricao: data.descricao.present ? data.descricao.value : this.descricao,
      serie: data.serie.present ? data.serie.value : this.serie,
      serieScan: data.serieScan.present ? data.serieScan.value : this.serieScan,
      ultimoNumero: data.ultimoNumero.present
          ? data.ultimoNumero.value
          : this.ultimoNumero,
    );
  }

  @override
  String toString() {
    return (StringBuffer('NotaFiscalTipo(')
          ..write('id: $id, ')
          ..write('idNotaFiscalModelo: $idNotaFiscalModelo, ')
          ..write('nome: $nome, ')
          ..write('descricao: $descricao, ')
          ..write('serie: $serie, ')
          ..write('serieScan: $serieScan, ')
          ..write('ultimoNumero: $ultimoNumero')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(
      id, idNotaFiscalModelo, nome, descricao, serie, serieScan, ultimoNumero);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is NotaFiscalTipo &&
          other.id == this.id &&
          other.idNotaFiscalModelo == this.idNotaFiscalModelo &&
          other.nome == this.nome &&
          other.descricao == this.descricao &&
          other.serie == this.serie &&
          other.serieScan == this.serieScan &&
          other.ultimoNumero == this.ultimoNumero);
}

class NotaFiscalTiposCompanion extends UpdateCompanion<NotaFiscalTipo> {
  final Value<int?> id;
  final Value<int?> idNotaFiscalModelo;
  final Value<String?> nome;
  final Value<String?> descricao;
  final Value<String?> serie;
  final Value<String?> serieScan;
  final Value<int?> ultimoNumero;
  const NotaFiscalTiposCompanion({
    this.id = const Value.absent(),
    this.idNotaFiscalModelo = const Value.absent(),
    this.nome = const Value.absent(),
    this.descricao = const Value.absent(),
    this.serie = const Value.absent(),
    this.serieScan = const Value.absent(),
    this.ultimoNumero = const Value.absent(),
  });
  NotaFiscalTiposCompanion.insert({
    this.id = const Value.absent(),
    this.idNotaFiscalModelo = const Value.absent(),
    this.nome = const Value.absent(),
    this.descricao = const Value.absent(),
    this.serie = const Value.absent(),
    this.serieScan = const Value.absent(),
    this.ultimoNumero = const Value.absent(),
  });
  static Insertable<NotaFiscalTipo> custom({
    Expression<int>? id,
    Expression<int>? idNotaFiscalModelo,
    Expression<String>? nome,
    Expression<String>? descricao,
    Expression<String>? serie,
    Expression<String>? serieScan,
    Expression<int>? ultimoNumero,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (idNotaFiscalModelo != null)
        'id_nota_fiscal_modelo': idNotaFiscalModelo,
      if (nome != null) 'nome': nome,
      if (descricao != null) 'descricao': descricao,
      if (serie != null) 'serie': serie,
      if (serieScan != null) 'serie_scan': serieScan,
      if (ultimoNumero != null) 'ultimo_numero': ultimoNumero,
    });
  }

  NotaFiscalTiposCompanion copyWith(
      {Value<int?>? id,
      Value<int?>? idNotaFiscalModelo,
      Value<String?>? nome,
      Value<String?>? descricao,
      Value<String?>? serie,
      Value<String?>? serieScan,
      Value<int?>? ultimoNumero}) {
    return NotaFiscalTiposCompanion(
      id: id ?? this.id,
      idNotaFiscalModelo: idNotaFiscalModelo ?? this.idNotaFiscalModelo,
      nome: nome ?? this.nome,
      descricao: descricao ?? this.descricao,
      serie: serie ?? this.serie,
      serieScan: serieScan ?? this.serieScan,
      ultimoNumero: ultimoNumero ?? this.ultimoNumero,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (idNotaFiscalModelo.present) {
      map['id_nota_fiscal_modelo'] = Variable<int>(idNotaFiscalModelo.value);
    }
    if (nome.present) {
      map['nome'] = Variable<String>(nome.value);
    }
    if (descricao.present) {
      map['descricao'] = Variable<String>(descricao.value);
    }
    if (serie.present) {
      map['serie'] = Variable<String>(serie.value);
    }
    if (serieScan.present) {
      map['serie_scan'] = Variable<String>(serieScan.value);
    }
    if (ultimoNumero.present) {
      map['ultimo_numero'] = Variable<int>(ultimoNumero.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('NotaFiscalTiposCompanion(')
          ..write('id: $id, ')
          ..write('idNotaFiscalModelo: $idNotaFiscalModelo, ')
          ..write('nome: $nome, ')
          ..write('descricao: $descricao, ')
          ..write('serie: $serie, ')
          ..write('serieScan: $serieScan, ')
          ..write('ultimoNumero: $ultimoNumero')
          ..write(')'))
        .toString();
  }
}

class $ViewControleAcessosTable extends ViewControleAcessos
    with TableInfo<$ViewControleAcessosTable, ViewControleAcesso> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $ViewControleAcessosTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
      'id', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _idPessoaMeta =
      const VerificationMeta('idPessoa');
  @override
  late final GeneratedColumn<int> idPessoa = GeneratedColumn<int>(
      'id_pessoa', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _pessoaNomeMeta =
      const VerificationMeta('pessoaNome');
  @override
  late final GeneratedColumn<String> pessoaNome = GeneratedColumn<String>(
      'pessoa_nome', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 450),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _idColaboradorMeta =
      const VerificationMeta('idColaborador');
  @override
  late final GeneratedColumn<int> idColaborador = GeneratedColumn<int>(
      'id_colaborador', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _idUsuarioMeta =
      const VerificationMeta('idUsuario');
  @override
  late final GeneratedColumn<int> idUsuario = GeneratedColumn<int>(
      'id_usuario', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _administradorMeta =
      const VerificationMeta('administrador');
  @override
  late final GeneratedColumn<String> administrador = GeneratedColumn<String>(
      'administrador', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 3),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _idPapelMeta =
      const VerificationMeta('idPapel');
  @override
  late final GeneratedColumn<int> idPapel = GeneratedColumn<int>(
      'id_papel', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _papelNomeMeta =
      const VerificationMeta('papelNome');
  @override
  late final GeneratedColumn<String> papelNome = GeneratedColumn<String>(
      'papel_nome', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 300),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _papelDescricaoMeta =
      const VerificationMeta('papelDescricao');
  @override
  late final GeneratedColumn<String> papelDescricao = GeneratedColumn<String>(
      'papel_descricao', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 750),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _idFuncaoMeta =
      const VerificationMeta('idFuncao');
  @override
  late final GeneratedColumn<int> idFuncao = GeneratedColumn<int>(
      'id_funcao', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _funcaoNomeMeta =
      const VerificationMeta('funcaoNome');
  @override
  late final GeneratedColumn<String> funcaoNome = GeneratedColumn<String>(
      'funcao_nome', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 300),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _funcaoDescricaoMeta =
      const VerificationMeta('funcaoDescricao');
  @override
  late final GeneratedColumn<String> funcaoDescricao = GeneratedColumn<String>(
      'funcao_descricao', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 750),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _idPapelFuncaoMeta =
      const VerificationMeta('idPapelFuncao');
  @override
  late final GeneratedColumn<int> idPapelFuncao = GeneratedColumn<int>(
      'id_papel_funcao', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _habilitadoMeta =
      const VerificationMeta('habilitado');
  @override
  late final GeneratedColumn<String> habilitado = GeneratedColumn<String>(
      'habilitado', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 3),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _podeInserirMeta =
      const VerificationMeta('podeInserir');
  @override
  late final GeneratedColumn<String> podeInserir = GeneratedColumn<String>(
      'pode_inserir', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 3),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _podeAlterarMeta =
      const VerificationMeta('podeAlterar');
  @override
  late final GeneratedColumn<String> podeAlterar = GeneratedColumn<String>(
      'pode_alterar', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 3),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _podeExcluirMeta =
      const VerificationMeta('podeExcluir');
  @override
  late final GeneratedColumn<String> podeExcluir = GeneratedColumn<String>(
      'pode_excluir', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 3),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  @override
  List<GeneratedColumn> get $columns => [
        id,
        idPessoa,
        pessoaNome,
        idColaborador,
        idUsuario,
        administrador,
        idPapel,
        papelNome,
        papelDescricao,
        idFuncao,
        funcaoNome,
        funcaoDescricao,
        idPapelFuncao,
        habilitado,
        podeInserir,
        podeAlterar,
        podeExcluir
      ];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'view_controle_acesso';
  @override
  VerificationContext validateIntegrity(Insertable<ViewControleAcesso> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('id_pessoa')) {
      context.handle(_idPessoaMeta,
          idPessoa.isAcceptableOrUnknown(data['id_pessoa']!, _idPessoaMeta));
    }
    if (data.containsKey('pessoa_nome')) {
      context.handle(
          _pessoaNomeMeta,
          pessoaNome.isAcceptableOrUnknown(
              data['pessoa_nome']!, _pessoaNomeMeta));
    }
    if (data.containsKey('id_colaborador')) {
      context.handle(
          _idColaboradorMeta,
          idColaborador.isAcceptableOrUnknown(
              data['id_colaborador']!, _idColaboradorMeta));
    }
    if (data.containsKey('id_usuario')) {
      context.handle(_idUsuarioMeta,
          idUsuario.isAcceptableOrUnknown(data['id_usuario']!, _idUsuarioMeta));
    }
    if (data.containsKey('administrador')) {
      context.handle(
          _administradorMeta,
          administrador.isAcceptableOrUnknown(
              data['administrador']!, _administradorMeta));
    }
    if (data.containsKey('id_papel')) {
      context.handle(_idPapelMeta,
          idPapel.isAcceptableOrUnknown(data['id_papel']!, _idPapelMeta));
    }
    if (data.containsKey('papel_nome')) {
      context.handle(_papelNomeMeta,
          papelNome.isAcceptableOrUnknown(data['papel_nome']!, _papelNomeMeta));
    }
    if (data.containsKey('papel_descricao')) {
      context.handle(
          _papelDescricaoMeta,
          papelDescricao.isAcceptableOrUnknown(
              data['papel_descricao']!, _papelDescricaoMeta));
    }
    if (data.containsKey('id_funcao')) {
      context.handle(_idFuncaoMeta,
          idFuncao.isAcceptableOrUnknown(data['id_funcao']!, _idFuncaoMeta));
    }
    if (data.containsKey('funcao_nome')) {
      context.handle(
          _funcaoNomeMeta,
          funcaoNome.isAcceptableOrUnknown(
              data['funcao_nome']!, _funcaoNomeMeta));
    }
    if (data.containsKey('funcao_descricao')) {
      context.handle(
          _funcaoDescricaoMeta,
          funcaoDescricao.isAcceptableOrUnknown(
              data['funcao_descricao']!, _funcaoDescricaoMeta));
    }
    if (data.containsKey('id_papel_funcao')) {
      context.handle(
          _idPapelFuncaoMeta,
          idPapelFuncao.isAcceptableOrUnknown(
              data['id_papel_funcao']!, _idPapelFuncaoMeta));
    }
    if (data.containsKey('habilitado')) {
      context.handle(
          _habilitadoMeta,
          habilitado.isAcceptableOrUnknown(
              data['habilitado']!, _habilitadoMeta));
    }
    if (data.containsKey('pode_inserir')) {
      context.handle(
          _podeInserirMeta,
          podeInserir.isAcceptableOrUnknown(
              data['pode_inserir']!, _podeInserirMeta));
    }
    if (data.containsKey('pode_alterar')) {
      context.handle(
          _podeAlterarMeta,
          podeAlterar.isAcceptableOrUnknown(
              data['pode_alterar']!, _podeAlterarMeta));
    }
    if (data.containsKey('pode_excluir')) {
      context.handle(
          _podeExcluirMeta,
          podeExcluir.isAcceptableOrUnknown(
              data['pode_excluir']!, _podeExcluirMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  ViewControleAcesso map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return ViewControleAcesso(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id']),
      idPessoa: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id_pessoa']),
      pessoaNome: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}pessoa_nome']),
      idColaborador: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id_colaborador']),
      idUsuario: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id_usuario']),
      administrador: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}administrador']),
      idPapel: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id_papel']),
      papelNome: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}papel_nome']),
      papelDescricao: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}papel_descricao']),
      idFuncao: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id_funcao']),
      funcaoNome: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}funcao_nome']),
      funcaoDescricao: attachedDatabase.typeMapping.read(
          DriftSqlType.string, data['${effectivePrefix}funcao_descricao']),
      idPapelFuncao: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id_papel_funcao']),
      habilitado: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}habilitado']),
      podeInserir: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}pode_inserir']),
      podeAlterar: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}pode_alterar']),
      podeExcluir: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}pode_excluir']),
    );
  }

  @override
  $ViewControleAcessosTable createAlias(String alias) {
    return $ViewControleAcessosTable(attachedDatabase, alias);
  }
}

class ViewControleAcesso extends DataClass
    implements Insertable<ViewControleAcesso> {
  final int? id;
  final int? idPessoa;
  final String? pessoaNome;
  final int? idColaborador;
  final int? idUsuario;
  final String? administrador;
  final int? idPapel;
  final String? papelNome;
  final String? papelDescricao;
  final int? idFuncao;
  final String? funcaoNome;
  final String? funcaoDescricao;
  final int? idPapelFuncao;
  final String? habilitado;
  final String? podeInserir;
  final String? podeAlterar;
  final String? podeExcluir;
  const ViewControleAcesso(
      {this.id,
      this.idPessoa,
      this.pessoaNome,
      this.idColaborador,
      this.idUsuario,
      this.administrador,
      this.idPapel,
      this.papelNome,
      this.papelDescricao,
      this.idFuncao,
      this.funcaoNome,
      this.funcaoDescricao,
      this.idPapelFuncao,
      this.habilitado,
      this.podeInserir,
      this.podeAlterar,
      this.podeExcluir});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || idPessoa != null) {
      map['id_pessoa'] = Variable<int>(idPessoa);
    }
    if (!nullToAbsent || pessoaNome != null) {
      map['pessoa_nome'] = Variable<String>(pessoaNome);
    }
    if (!nullToAbsent || idColaborador != null) {
      map['id_colaborador'] = Variable<int>(idColaborador);
    }
    if (!nullToAbsent || idUsuario != null) {
      map['id_usuario'] = Variable<int>(idUsuario);
    }
    if (!nullToAbsent || administrador != null) {
      map['administrador'] = Variable<String>(administrador);
    }
    if (!nullToAbsent || idPapel != null) {
      map['id_papel'] = Variable<int>(idPapel);
    }
    if (!nullToAbsent || papelNome != null) {
      map['papel_nome'] = Variable<String>(papelNome);
    }
    if (!nullToAbsent || papelDescricao != null) {
      map['papel_descricao'] = Variable<String>(papelDescricao);
    }
    if (!nullToAbsent || idFuncao != null) {
      map['id_funcao'] = Variable<int>(idFuncao);
    }
    if (!nullToAbsent || funcaoNome != null) {
      map['funcao_nome'] = Variable<String>(funcaoNome);
    }
    if (!nullToAbsent || funcaoDescricao != null) {
      map['funcao_descricao'] = Variable<String>(funcaoDescricao);
    }
    if (!nullToAbsent || idPapelFuncao != null) {
      map['id_papel_funcao'] = Variable<int>(idPapelFuncao);
    }
    if (!nullToAbsent || habilitado != null) {
      map['habilitado'] = Variable<String>(habilitado);
    }
    if (!nullToAbsent || podeInserir != null) {
      map['pode_inserir'] = Variable<String>(podeInserir);
    }
    if (!nullToAbsent || podeAlterar != null) {
      map['pode_alterar'] = Variable<String>(podeAlterar);
    }
    if (!nullToAbsent || podeExcluir != null) {
      map['pode_excluir'] = Variable<String>(podeExcluir);
    }
    return map;
  }

  factory ViewControleAcesso.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return ViewControleAcesso(
      id: serializer.fromJson<int?>(json['id']),
      idPessoa: serializer.fromJson<int?>(json['idPessoa']),
      pessoaNome: serializer.fromJson<String?>(json['pessoaNome']),
      idColaborador: serializer.fromJson<int?>(json['idColaborador']),
      idUsuario: serializer.fromJson<int?>(json['idUsuario']),
      administrador: serializer.fromJson<String?>(json['administrador']),
      idPapel: serializer.fromJson<int?>(json['idPapel']),
      papelNome: serializer.fromJson<String?>(json['papelNome']),
      papelDescricao: serializer.fromJson<String?>(json['papelDescricao']),
      idFuncao: serializer.fromJson<int?>(json['idFuncao']),
      funcaoNome: serializer.fromJson<String?>(json['funcaoNome']),
      funcaoDescricao: serializer.fromJson<String?>(json['funcaoDescricao']),
      idPapelFuncao: serializer.fromJson<int?>(json['idPapelFuncao']),
      habilitado: serializer.fromJson<String?>(json['habilitado']),
      podeInserir: serializer.fromJson<String?>(json['podeInserir']),
      podeAlterar: serializer.fromJson<String?>(json['podeAlterar']),
      podeExcluir: serializer.fromJson<String?>(json['podeExcluir']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'idPessoa': serializer.toJson<int?>(idPessoa),
      'pessoaNome': serializer.toJson<String?>(pessoaNome),
      'idColaborador': serializer.toJson<int?>(idColaborador),
      'idUsuario': serializer.toJson<int?>(idUsuario),
      'administrador': serializer.toJson<String?>(administrador),
      'idPapel': serializer.toJson<int?>(idPapel),
      'papelNome': serializer.toJson<String?>(papelNome),
      'papelDescricao': serializer.toJson<String?>(papelDescricao),
      'idFuncao': serializer.toJson<int?>(idFuncao),
      'funcaoNome': serializer.toJson<String?>(funcaoNome),
      'funcaoDescricao': serializer.toJson<String?>(funcaoDescricao),
      'idPapelFuncao': serializer.toJson<int?>(idPapelFuncao),
      'habilitado': serializer.toJson<String?>(habilitado),
      'podeInserir': serializer.toJson<String?>(podeInserir),
      'podeAlterar': serializer.toJson<String?>(podeAlterar),
      'podeExcluir': serializer.toJson<String?>(podeExcluir),
    };
  }

  ViewControleAcesso copyWith(
          {Value<int?> id = const Value.absent(),
          Value<int?> idPessoa = const Value.absent(),
          Value<String?> pessoaNome = const Value.absent(),
          Value<int?> idColaborador = const Value.absent(),
          Value<int?> idUsuario = const Value.absent(),
          Value<String?> administrador = const Value.absent(),
          Value<int?> idPapel = const Value.absent(),
          Value<String?> papelNome = const Value.absent(),
          Value<String?> papelDescricao = const Value.absent(),
          Value<int?> idFuncao = const Value.absent(),
          Value<String?> funcaoNome = const Value.absent(),
          Value<String?> funcaoDescricao = const Value.absent(),
          Value<int?> idPapelFuncao = const Value.absent(),
          Value<String?> habilitado = const Value.absent(),
          Value<String?> podeInserir = const Value.absent(),
          Value<String?> podeAlterar = const Value.absent(),
          Value<String?> podeExcluir = const Value.absent()}) =>
      ViewControleAcesso(
        id: id.present ? id.value : this.id,
        idPessoa: idPessoa.present ? idPessoa.value : this.idPessoa,
        pessoaNome: pessoaNome.present ? pessoaNome.value : this.pessoaNome,
        idColaborador:
            idColaborador.present ? idColaborador.value : this.idColaborador,
        idUsuario: idUsuario.present ? idUsuario.value : this.idUsuario,
        administrador:
            administrador.present ? administrador.value : this.administrador,
        idPapel: idPapel.present ? idPapel.value : this.idPapel,
        papelNome: papelNome.present ? papelNome.value : this.papelNome,
        papelDescricao:
            papelDescricao.present ? papelDescricao.value : this.papelDescricao,
        idFuncao: idFuncao.present ? idFuncao.value : this.idFuncao,
        funcaoNome: funcaoNome.present ? funcaoNome.value : this.funcaoNome,
        funcaoDescricao: funcaoDescricao.present
            ? funcaoDescricao.value
            : this.funcaoDescricao,
        idPapelFuncao:
            idPapelFuncao.present ? idPapelFuncao.value : this.idPapelFuncao,
        habilitado: habilitado.present ? habilitado.value : this.habilitado,
        podeInserir: podeInserir.present ? podeInserir.value : this.podeInserir,
        podeAlterar: podeAlterar.present ? podeAlterar.value : this.podeAlterar,
        podeExcluir: podeExcluir.present ? podeExcluir.value : this.podeExcluir,
      );
  ViewControleAcesso copyWithCompanion(ViewControleAcessosCompanion data) {
    return ViewControleAcesso(
      id: data.id.present ? data.id.value : this.id,
      idPessoa: data.idPessoa.present ? data.idPessoa.value : this.idPessoa,
      pessoaNome:
          data.pessoaNome.present ? data.pessoaNome.value : this.pessoaNome,
      idColaborador: data.idColaborador.present
          ? data.idColaborador.value
          : this.idColaborador,
      idUsuario: data.idUsuario.present ? data.idUsuario.value : this.idUsuario,
      administrador: data.administrador.present
          ? data.administrador.value
          : this.administrador,
      idPapel: data.idPapel.present ? data.idPapel.value : this.idPapel,
      papelNome: data.papelNome.present ? data.papelNome.value : this.papelNome,
      papelDescricao: data.papelDescricao.present
          ? data.papelDescricao.value
          : this.papelDescricao,
      idFuncao: data.idFuncao.present ? data.idFuncao.value : this.idFuncao,
      funcaoNome:
          data.funcaoNome.present ? data.funcaoNome.value : this.funcaoNome,
      funcaoDescricao: data.funcaoDescricao.present
          ? data.funcaoDescricao.value
          : this.funcaoDescricao,
      idPapelFuncao: data.idPapelFuncao.present
          ? data.idPapelFuncao.value
          : this.idPapelFuncao,
      habilitado:
          data.habilitado.present ? data.habilitado.value : this.habilitado,
      podeInserir:
          data.podeInserir.present ? data.podeInserir.value : this.podeInserir,
      podeAlterar:
          data.podeAlterar.present ? data.podeAlterar.value : this.podeAlterar,
      podeExcluir:
          data.podeExcluir.present ? data.podeExcluir.value : this.podeExcluir,
    );
  }

  @override
  String toString() {
    return (StringBuffer('ViewControleAcesso(')
          ..write('id: $id, ')
          ..write('idPessoa: $idPessoa, ')
          ..write('pessoaNome: $pessoaNome, ')
          ..write('idColaborador: $idColaborador, ')
          ..write('idUsuario: $idUsuario, ')
          ..write('administrador: $administrador, ')
          ..write('idPapel: $idPapel, ')
          ..write('papelNome: $papelNome, ')
          ..write('papelDescricao: $papelDescricao, ')
          ..write('idFuncao: $idFuncao, ')
          ..write('funcaoNome: $funcaoNome, ')
          ..write('funcaoDescricao: $funcaoDescricao, ')
          ..write('idPapelFuncao: $idPapelFuncao, ')
          ..write('habilitado: $habilitado, ')
          ..write('podeInserir: $podeInserir, ')
          ..write('podeAlterar: $podeAlterar, ')
          ..write('podeExcluir: $podeExcluir')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(
      id,
      idPessoa,
      pessoaNome,
      idColaborador,
      idUsuario,
      administrador,
      idPapel,
      papelNome,
      papelDescricao,
      idFuncao,
      funcaoNome,
      funcaoDescricao,
      idPapelFuncao,
      habilitado,
      podeInserir,
      podeAlterar,
      podeExcluir);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is ViewControleAcesso &&
          other.id == this.id &&
          other.idPessoa == this.idPessoa &&
          other.pessoaNome == this.pessoaNome &&
          other.idColaborador == this.idColaborador &&
          other.idUsuario == this.idUsuario &&
          other.administrador == this.administrador &&
          other.idPapel == this.idPapel &&
          other.papelNome == this.papelNome &&
          other.papelDescricao == this.papelDescricao &&
          other.idFuncao == this.idFuncao &&
          other.funcaoNome == this.funcaoNome &&
          other.funcaoDescricao == this.funcaoDescricao &&
          other.idPapelFuncao == this.idPapelFuncao &&
          other.habilitado == this.habilitado &&
          other.podeInserir == this.podeInserir &&
          other.podeAlterar == this.podeAlterar &&
          other.podeExcluir == this.podeExcluir);
}

class ViewControleAcessosCompanion extends UpdateCompanion<ViewControleAcesso> {
  final Value<int?> id;
  final Value<int?> idPessoa;
  final Value<String?> pessoaNome;
  final Value<int?> idColaborador;
  final Value<int?> idUsuario;
  final Value<String?> administrador;
  final Value<int?> idPapel;
  final Value<String?> papelNome;
  final Value<String?> papelDescricao;
  final Value<int?> idFuncao;
  final Value<String?> funcaoNome;
  final Value<String?> funcaoDescricao;
  final Value<int?> idPapelFuncao;
  final Value<String?> habilitado;
  final Value<String?> podeInserir;
  final Value<String?> podeAlterar;
  final Value<String?> podeExcluir;
  const ViewControleAcessosCompanion({
    this.id = const Value.absent(),
    this.idPessoa = const Value.absent(),
    this.pessoaNome = const Value.absent(),
    this.idColaborador = const Value.absent(),
    this.idUsuario = const Value.absent(),
    this.administrador = const Value.absent(),
    this.idPapel = const Value.absent(),
    this.papelNome = const Value.absent(),
    this.papelDescricao = const Value.absent(),
    this.idFuncao = const Value.absent(),
    this.funcaoNome = const Value.absent(),
    this.funcaoDescricao = const Value.absent(),
    this.idPapelFuncao = const Value.absent(),
    this.habilitado = const Value.absent(),
    this.podeInserir = const Value.absent(),
    this.podeAlterar = const Value.absent(),
    this.podeExcluir = const Value.absent(),
  });
  ViewControleAcessosCompanion.insert({
    this.id = const Value.absent(),
    this.idPessoa = const Value.absent(),
    this.pessoaNome = const Value.absent(),
    this.idColaborador = const Value.absent(),
    this.idUsuario = const Value.absent(),
    this.administrador = const Value.absent(),
    this.idPapel = const Value.absent(),
    this.papelNome = const Value.absent(),
    this.papelDescricao = const Value.absent(),
    this.idFuncao = const Value.absent(),
    this.funcaoNome = const Value.absent(),
    this.funcaoDescricao = const Value.absent(),
    this.idPapelFuncao = const Value.absent(),
    this.habilitado = const Value.absent(),
    this.podeInserir = const Value.absent(),
    this.podeAlterar = const Value.absent(),
    this.podeExcluir = const Value.absent(),
  });
  static Insertable<ViewControleAcesso> custom({
    Expression<int>? id,
    Expression<int>? idPessoa,
    Expression<String>? pessoaNome,
    Expression<int>? idColaborador,
    Expression<int>? idUsuario,
    Expression<String>? administrador,
    Expression<int>? idPapel,
    Expression<String>? papelNome,
    Expression<String>? papelDescricao,
    Expression<int>? idFuncao,
    Expression<String>? funcaoNome,
    Expression<String>? funcaoDescricao,
    Expression<int>? idPapelFuncao,
    Expression<String>? habilitado,
    Expression<String>? podeInserir,
    Expression<String>? podeAlterar,
    Expression<String>? podeExcluir,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (idPessoa != null) 'id_pessoa': idPessoa,
      if (pessoaNome != null) 'pessoa_nome': pessoaNome,
      if (idColaborador != null) 'id_colaborador': idColaborador,
      if (idUsuario != null) 'id_usuario': idUsuario,
      if (administrador != null) 'administrador': administrador,
      if (idPapel != null) 'id_papel': idPapel,
      if (papelNome != null) 'papel_nome': papelNome,
      if (papelDescricao != null) 'papel_descricao': papelDescricao,
      if (idFuncao != null) 'id_funcao': idFuncao,
      if (funcaoNome != null) 'funcao_nome': funcaoNome,
      if (funcaoDescricao != null) 'funcao_descricao': funcaoDescricao,
      if (idPapelFuncao != null) 'id_papel_funcao': idPapelFuncao,
      if (habilitado != null) 'habilitado': habilitado,
      if (podeInserir != null) 'pode_inserir': podeInserir,
      if (podeAlterar != null) 'pode_alterar': podeAlterar,
      if (podeExcluir != null) 'pode_excluir': podeExcluir,
    });
  }

  ViewControleAcessosCompanion copyWith(
      {Value<int?>? id,
      Value<int?>? idPessoa,
      Value<String?>? pessoaNome,
      Value<int?>? idColaborador,
      Value<int?>? idUsuario,
      Value<String?>? administrador,
      Value<int?>? idPapel,
      Value<String?>? papelNome,
      Value<String?>? papelDescricao,
      Value<int?>? idFuncao,
      Value<String?>? funcaoNome,
      Value<String?>? funcaoDescricao,
      Value<int?>? idPapelFuncao,
      Value<String?>? habilitado,
      Value<String?>? podeInserir,
      Value<String?>? podeAlterar,
      Value<String?>? podeExcluir}) {
    return ViewControleAcessosCompanion(
      id: id ?? this.id,
      idPessoa: idPessoa ?? this.idPessoa,
      pessoaNome: pessoaNome ?? this.pessoaNome,
      idColaborador: idColaborador ?? this.idColaborador,
      idUsuario: idUsuario ?? this.idUsuario,
      administrador: administrador ?? this.administrador,
      idPapel: idPapel ?? this.idPapel,
      papelNome: papelNome ?? this.papelNome,
      papelDescricao: papelDescricao ?? this.papelDescricao,
      idFuncao: idFuncao ?? this.idFuncao,
      funcaoNome: funcaoNome ?? this.funcaoNome,
      funcaoDescricao: funcaoDescricao ?? this.funcaoDescricao,
      idPapelFuncao: idPapelFuncao ?? this.idPapelFuncao,
      habilitado: habilitado ?? this.habilitado,
      podeInserir: podeInserir ?? this.podeInserir,
      podeAlterar: podeAlterar ?? this.podeAlterar,
      podeExcluir: podeExcluir ?? this.podeExcluir,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (idPessoa.present) {
      map['id_pessoa'] = Variable<int>(idPessoa.value);
    }
    if (pessoaNome.present) {
      map['pessoa_nome'] = Variable<String>(pessoaNome.value);
    }
    if (idColaborador.present) {
      map['id_colaborador'] = Variable<int>(idColaborador.value);
    }
    if (idUsuario.present) {
      map['id_usuario'] = Variable<int>(idUsuario.value);
    }
    if (administrador.present) {
      map['administrador'] = Variable<String>(administrador.value);
    }
    if (idPapel.present) {
      map['id_papel'] = Variable<int>(idPapel.value);
    }
    if (papelNome.present) {
      map['papel_nome'] = Variable<String>(papelNome.value);
    }
    if (papelDescricao.present) {
      map['papel_descricao'] = Variable<String>(papelDescricao.value);
    }
    if (idFuncao.present) {
      map['id_funcao'] = Variable<int>(idFuncao.value);
    }
    if (funcaoNome.present) {
      map['funcao_nome'] = Variable<String>(funcaoNome.value);
    }
    if (funcaoDescricao.present) {
      map['funcao_descricao'] = Variable<String>(funcaoDescricao.value);
    }
    if (idPapelFuncao.present) {
      map['id_papel_funcao'] = Variable<int>(idPapelFuncao.value);
    }
    if (habilitado.present) {
      map['habilitado'] = Variable<String>(habilitado.value);
    }
    if (podeInserir.present) {
      map['pode_inserir'] = Variable<String>(podeInserir.value);
    }
    if (podeAlterar.present) {
      map['pode_alterar'] = Variable<String>(podeAlterar.value);
    }
    if (podeExcluir.present) {
      map['pode_excluir'] = Variable<String>(podeExcluir.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('ViewControleAcessosCompanion(')
          ..write('id: $id, ')
          ..write('idPessoa: $idPessoa, ')
          ..write('pessoaNome: $pessoaNome, ')
          ..write('idColaborador: $idColaborador, ')
          ..write('idUsuario: $idUsuario, ')
          ..write('administrador: $administrador, ')
          ..write('idPapel: $idPapel, ')
          ..write('papelNome: $papelNome, ')
          ..write('papelDescricao: $papelDescricao, ')
          ..write('idFuncao: $idFuncao, ')
          ..write('funcaoNome: $funcaoNome, ')
          ..write('funcaoDescricao: $funcaoDescricao, ')
          ..write('idPapelFuncao: $idPapelFuncao, ')
          ..write('habilitado: $habilitado, ')
          ..write('podeInserir: $podeInserir, ')
          ..write('podeAlterar: $podeAlterar, ')
          ..write('podeExcluir: $podeExcluir')
          ..write(')'))
        .toString();
  }
}

class $ViewPessoaUsuariosTable extends ViewPessoaUsuarios
    with TableInfo<$ViewPessoaUsuariosTable, ViewPessoaUsuario> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $ViewPessoaUsuariosTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
      'id', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _idPessoaMeta =
      const VerificationMeta('idPessoa');
  @override
  late final GeneratedColumn<int> idPessoa = GeneratedColumn<int>(
      'id_pessoa', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _pessoaNomeMeta =
      const VerificationMeta('pessoaNome');
  @override
  late final GeneratedColumn<String> pessoaNome = GeneratedColumn<String>(
      'pessoa_nome', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 450),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _tipoMeta = const VerificationMeta('tipo');
  @override
  late final GeneratedColumn<String> tipo = GeneratedColumn<String>(
      'tipo', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 3),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _emailMeta = const VerificationMeta('email');
  @override
  late final GeneratedColumn<String> email = GeneratedColumn<String>(
      'email', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 750),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _idColaboradorMeta =
      const VerificationMeta('idColaborador');
  @override
  late final GeneratedColumn<int> idColaborador = GeneratedColumn<int>(
      'id_colaborador', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _idUsuarioMeta =
      const VerificationMeta('idUsuario');
  @override
  late final GeneratedColumn<int> idUsuario = GeneratedColumn<int>(
      'id_usuario', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _loginMeta = const VerificationMeta('login');
  @override
  late final GeneratedColumn<String> login = GeneratedColumn<String>(
      'login', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 150),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _senhaMeta = const VerificationMeta('senha');
  @override
  late final GeneratedColumn<String> senha = GeneratedColumn<String>(
      'senha', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 150),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _dataCadastroMeta =
      const VerificationMeta('dataCadastro');
  @override
  late final GeneratedColumn<DateTime> dataCadastro = GeneratedColumn<DateTime>(
      'data_cadastro', aliasedName, true,
      type: DriftSqlType.dateTime, requiredDuringInsert: false);
  static const VerificationMeta _administradorMeta =
      const VerificationMeta('administrador');
  @override
  late final GeneratedColumn<String> administrador = GeneratedColumn<String>(
      'administrador', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 3),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  @override
  List<GeneratedColumn> get $columns => [
        id,
        idPessoa,
        pessoaNome,
        tipo,
        email,
        idColaborador,
        idUsuario,
        login,
        senha,
        dataCadastro,
        administrador
      ];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'view_pessoa_usuario';
  @override
  VerificationContext validateIntegrity(Insertable<ViewPessoaUsuario> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('id_pessoa')) {
      context.handle(_idPessoaMeta,
          idPessoa.isAcceptableOrUnknown(data['id_pessoa']!, _idPessoaMeta));
    }
    if (data.containsKey('pessoa_nome')) {
      context.handle(
          _pessoaNomeMeta,
          pessoaNome.isAcceptableOrUnknown(
              data['pessoa_nome']!, _pessoaNomeMeta));
    }
    if (data.containsKey('tipo')) {
      context.handle(
          _tipoMeta, tipo.isAcceptableOrUnknown(data['tipo']!, _tipoMeta));
    }
    if (data.containsKey('email')) {
      context.handle(
          _emailMeta, email.isAcceptableOrUnknown(data['email']!, _emailMeta));
    }
    if (data.containsKey('id_colaborador')) {
      context.handle(
          _idColaboradorMeta,
          idColaborador.isAcceptableOrUnknown(
              data['id_colaborador']!, _idColaboradorMeta));
    }
    if (data.containsKey('id_usuario')) {
      context.handle(_idUsuarioMeta,
          idUsuario.isAcceptableOrUnknown(data['id_usuario']!, _idUsuarioMeta));
    }
    if (data.containsKey('login')) {
      context.handle(
          _loginMeta, login.isAcceptableOrUnknown(data['login']!, _loginMeta));
    }
    if (data.containsKey('senha')) {
      context.handle(
          _senhaMeta, senha.isAcceptableOrUnknown(data['senha']!, _senhaMeta));
    }
    if (data.containsKey('data_cadastro')) {
      context.handle(
          _dataCadastroMeta,
          dataCadastro.isAcceptableOrUnknown(
              data['data_cadastro']!, _dataCadastroMeta));
    }
    if (data.containsKey('administrador')) {
      context.handle(
          _administradorMeta,
          administrador.isAcceptableOrUnknown(
              data['administrador']!, _administradorMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  ViewPessoaUsuario map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return ViewPessoaUsuario(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id']),
      idPessoa: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id_pessoa']),
      pessoaNome: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}pessoa_nome']),
      tipo: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}tipo']),
      email: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}email']),
      idColaborador: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id_colaborador']),
      idUsuario: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id_usuario']),
      login: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}login']),
      senha: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}senha']),
      dataCadastro: attachedDatabase.typeMapping
          .read(DriftSqlType.dateTime, data['${effectivePrefix}data_cadastro']),
      administrador: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}administrador']),
    );
  }

  @override
  $ViewPessoaUsuariosTable createAlias(String alias) {
    return $ViewPessoaUsuariosTable(attachedDatabase, alias);
  }
}

class ViewPessoaUsuario extends DataClass
    implements Insertable<ViewPessoaUsuario> {
  final int? id;
  final int? idPessoa;
  final String? pessoaNome;
  final String? tipo;
  final String? email;
  final int? idColaborador;
  final int? idUsuario;
  final String? login;
  final String? senha;
  final DateTime? dataCadastro;
  final String? administrador;
  const ViewPessoaUsuario(
      {this.id,
      this.idPessoa,
      this.pessoaNome,
      this.tipo,
      this.email,
      this.idColaborador,
      this.idUsuario,
      this.login,
      this.senha,
      this.dataCadastro,
      this.administrador});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || idPessoa != null) {
      map['id_pessoa'] = Variable<int>(idPessoa);
    }
    if (!nullToAbsent || pessoaNome != null) {
      map['pessoa_nome'] = Variable<String>(pessoaNome);
    }
    if (!nullToAbsent || tipo != null) {
      map['tipo'] = Variable<String>(tipo);
    }
    if (!nullToAbsent || email != null) {
      map['email'] = Variable<String>(email);
    }
    if (!nullToAbsent || idColaborador != null) {
      map['id_colaborador'] = Variable<int>(idColaborador);
    }
    if (!nullToAbsent || idUsuario != null) {
      map['id_usuario'] = Variable<int>(idUsuario);
    }
    if (!nullToAbsent || login != null) {
      map['login'] = Variable<String>(login);
    }
    if (!nullToAbsent || senha != null) {
      map['senha'] = Variable<String>(senha);
    }
    if (!nullToAbsent || dataCadastro != null) {
      map['data_cadastro'] = Variable<DateTime>(dataCadastro);
    }
    if (!nullToAbsent || administrador != null) {
      map['administrador'] = Variable<String>(administrador);
    }
    return map;
  }

  factory ViewPessoaUsuario.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return ViewPessoaUsuario(
      id: serializer.fromJson<int?>(json['id']),
      idPessoa: serializer.fromJson<int?>(json['idPessoa']),
      pessoaNome: serializer.fromJson<String?>(json['pessoaNome']),
      tipo: serializer.fromJson<String?>(json['tipo']),
      email: serializer.fromJson<String?>(json['email']),
      idColaborador: serializer.fromJson<int?>(json['idColaborador']),
      idUsuario: serializer.fromJson<int?>(json['idUsuario']),
      login: serializer.fromJson<String?>(json['login']),
      senha: serializer.fromJson<String?>(json['senha']),
      dataCadastro: serializer.fromJson<DateTime?>(json['dataCadastro']),
      administrador: serializer.fromJson<String?>(json['administrador']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'idPessoa': serializer.toJson<int?>(idPessoa),
      'pessoaNome': serializer.toJson<String?>(pessoaNome),
      'tipo': serializer.toJson<String?>(tipo),
      'email': serializer.toJson<String?>(email),
      'idColaborador': serializer.toJson<int?>(idColaborador),
      'idUsuario': serializer.toJson<int?>(idUsuario),
      'login': serializer.toJson<String?>(login),
      'senha': serializer.toJson<String?>(senha),
      'dataCadastro': serializer.toJson<DateTime?>(dataCadastro),
      'administrador': serializer.toJson<String?>(administrador),
    };
  }

  ViewPessoaUsuario copyWith(
          {Value<int?> id = const Value.absent(),
          Value<int?> idPessoa = const Value.absent(),
          Value<String?> pessoaNome = const Value.absent(),
          Value<String?> tipo = const Value.absent(),
          Value<String?> email = const Value.absent(),
          Value<int?> idColaborador = const Value.absent(),
          Value<int?> idUsuario = const Value.absent(),
          Value<String?> login = const Value.absent(),
          Value<String?> senha = const Value.absent(),
          Value<DateTime?> dataCadastro = const Value.absent(),
          Value<String?> administrador = const Value.absent()}) =>
      ViewPessoaUsuario(
        id: id.present ? id.value : this.id,
        idPessoa: idPessoa.present ? idPessoa.value : this.idPessoa,
        pessoaNome: pessoaNome.present ? pessoaNome.value : this.pessoaNome,
        tipo: tipo.present ? tipo.value : this.tipo,
        email: email.present ? email.value : this.email,
        idColaborador:
            idColaborador.present ? idColaborador.value : this.idColaborador,
        idUsuario: idUsuario.present ? idUsuario.value : this.idUsuario,
        login: login.present ? login.value : this.login,
        senha: senha.present ? senha.value : this.senha,
        dataCadastro:
            dataCadastro.present ? dataCadastro.value : this.dataCadastro,
        administrador:
            administrador.present ? administrador.value : this.administrador,
      );
  ViewPessoaUsuario copyWithCompanion(ViewPessoaUsuariosCompanion data) {
    return ViewPessoaUsuario(
      id: data.id.present ? data.id.value : this.id,
      idPessoa: data.idPessoa.present ? data.idPessoa.value : this.idPessoa,
      pessoaNome:
          data.pessoaNome.present ? data.pessoaNome.value : this.pessoaNome,
      tipo: data.tipo.present ? data.tipo.value : this.tipo,
      email: data.email.present ? data.email.value : this.email,
      idColaborador: data.idColaborador.present
          ? data.idColaborador.value
          : this.idColaborador,
      idUsuario: data.idUsuario.present ? data.idUsuario.value : this.idUsuario,
      login: data.login.present ? data.login.value : this.login,
      senha: data.senha.present ? data.senha.value : this.senha,
      dataCadastro: data.dataCadastro.present
          ? data.dataCadastro.value
          : this.dataCadastro,
      administrador: data.administrador.present
          ? data.administrador.value
          : this.administrador,
    );
  }

  @override
  String toString() {
    return (StringBuffer('ViewPessoaUsuario(')
          ..write('id: $id, ')
          ..write('idPessoa: $idPessoa, ')
          ..write('pessoaNome: $pessoaNome, ')
          ..write('tipo: $tipo, ')
          ..write('email: $email, ')
          ..write('idColaborador: $idColaborador, ')
          ..write('idUsuario: $idUsuario, ')
          ..write('login: $login, ')
          ..write('senha: $senha, ')
          ..write('dataCadastro: $dataCadastro, ')
          ..write('administrador: $administrador')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(id, idPessoa, pessoaNome, tipo, email,
      idColaborador, idUsuario, login, senha, dataCadastro, administrador);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is ViewPessoaUsuario &&
          other.id == this.id &&
          other.idPessoa == this.idPessoa &&
          other.pessoaNome == this.pessoaNome &&
          other.tipo == this.tipo &&
          other.email == this.email &&
          other.idColaborador == this.idColaborador &&
          other.idUsuario == this.idUsuario &&
          other.login == this.login &&
          other.senha == this.senha &&
          other.dataCadastro == this.dataCadastro &&
          other.administrador == this.administrador);
}

class ViewPessoaUsuariosCompanion extends UpdateCompanion<ViewPessoaUsuario> {
  final Value<int?> id;
  final Value<int?> idPessoa;
  final Value<String?> pessoaNome;
  final Value<String?> tipo;
  final Value<String?> email;
  final Value<int?> idColaborador;
  final Value<int?> idUsuario;
  final Value<String?> login;
  final Value<String?> senha;
  final Value<DateTime?> dataCadastro;
  final Value<String?> administrador;
  const ViewPessoaUsuariosCompanion({
    this.id = const Value.absent(),
    this.idPessoa = const Value.absent(),
    this.pessoaNome = const Value.absent(),
    this.tipo = const Value.absent(),
    this.email = const Value.absent(),
    this.idColaborador = const Value.absent(),
    this.idUsuario = const Value.absent(),
    this.login = const Value.absent(),
    this.senha = const Value.absent(),
    this.dataCadastro = const Value.absent(),
    this.administrador = const Value.absent(),
  });
  ViewPessoaUsuariosCompanion.insert({
    this.id = const Value.absent(),
    this.idPessoa = const Value.absent(),
    this.pessoaNome = const Value.absent(),
    this.tipo = const Value.absent(),
    this.email = const Value.absent(),
    this.idColaborador = const Value.absent(),
    this.idUsuario = const Value.absent(),
    this.login = const Value.absent(),
    this.senha = const Value.absent(),
    this.dataCadastro = const Value.absent(),
    this.administrador = const Value.absent(),
  });
  static Insertable<ViewPessoaUsuario> custom({
    Expression<int>? id,
    Expression<int>? idPessoa,
    Expression<String>? pessoaNome,
    Expression<String>? tipo,
    Expression<String>? email,
    Expression<int>? idColaborador,
    Expression<int>? idUsuario,
    Expression<String>? login,
    Expression<String>? senha,
    Expression<DateTime>? dataCadastro,
    Expression<String>? administrador,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (idPessoa != null) 'id_pessoa': idPessoa,
      if (pessoaNome != null) 'pessoa_nome': pessoaNome,
      if (tipo != null) 'tipo': tipo,
      if (email != null) 'email': email,
      if (idColaborador != null) 'id_colaborador': idColaborador,
      if (idUsuario != null) 'id_usuario': idUsuario,
      if (login != null) 'login': login,
      if (senha != null) 'senha': senha,
      if (dataCadastro != null) 'data_cadastro': dataCadastro,
      if (administrador != null) 'administrador': administrador,
    });
  }

  ViewPessoaUsuariosCompanion copyWith(
      {Value<int?>? id,
      Value<int?>? idPessoa,
      Value<String?>? pessoaNome,
      Value<String?>? tipo,
      Value<String?>? email,
      Value<int?>? idColaborador,
      Value<int?>? idUsuario,
      Value<String?>? login,
      Value<String?>? senha,
      Value<DateTime?>? dataCadastro,
      Value<String?>? administrador}) {
    return ViewPessoaUsuariosCompanion(
      id: id ?? this.id,
      idPessoa: idPessoa ?? this.idPessoa,
      pessoaNome: pessoaNome ?? this.pessoaNome,
      tipo: tipo ?? this.tipo,
      email: email ?? this.email,
      idColaborador: idColaborador ?? this.idColaborador,
      idUsuario: idUsuario ?? this.idUsuario,
      login: login ?? this.login,
      senha: senha ?? this.senha,
      dataCadastro: dataCadastro ?? this.dataCadastro,
      administrador: administrador ?? this.administrador,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (idPessoa.present) {
      map['id_pessoa'] = Variable<int>(idPessoa.value);
    }
    if (pessoaNome.present) {
      map['pessoa_nome'] = Variable<String>(pessoaNome.value);
    }
    if (tipo.present) {
      map['tipo'] = Variable<String>(tipo.value);
    }
    if (email.present) {
      map['email'] = Variable<String>(email.value);
    }
    if (idColaborador.present) {
      map['id_colaborador'] = Variable<int>(idColaborador.value);
    }
    if (idUsuario.present) {
      map['id_usuario'] = Variable<int>(idUsuario.value);
    }
    if (login.present) {
      map['login'] = Variable<String>(login.value);
    }
    if (senha.present) {
      map['senha'] = Variable<String>(senha.value);
    }
    if (dataCadastro.present) {
      map['data_cadastro'] = Variable<DateTime>(dataCadastro.value);
    }
    if (administrador.present) {
      map['administrador'] = Variable<String>(administrador.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('ViewPessoaUsuariosCompanion(')
          ..write('id: $id, ')
          ..write('idPessoa: $idPessoa, ')
          ..write('pessoaNome: $pessoaNome, ')
          ..write('tipo: $tipo, ')
          ..write('email: $email, ')
          ..write('idColaborador: $idColaborador, ')
          ..write('idUsuario: $idUsuario, ')
          ..write('login: $login, ')
          ..write('senha: $senha, ')
          ..write('dataCadastro: $dataCadastro, ')
          ..write('administrador: $administrador')
          ..write(')'))
        .toString();
  }
}

class $ViewPessoaClientesTable extends ViewPessoaClientes
    with TableInfo<$ViewPessoaClientesTable, ViewPessoaCliente> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $ViewPessoaClientesTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
      'id', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _nomeMeta = const VerificationMeta('nome');
  @override
  late final GeneratedColumn<String> nome = GeneratedColumn<String>(
      'nome', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 450),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _tipoMeta = const VerificationMeta('tipo');
  @override
  late final GeneratedColumn<String> tipo = GeneratedColumn<String>(
      'tipo', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 3),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _emailMeta = const VerificationMeta('email');
  @override
  late final GeneratedColumn<String> email = GeneratedColumn<String>(
      'email', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 750),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _siteMeta = const VerificationMeta('site');
  @override
  late final GeneratedColumn<String> site = GeneratedColumn<String>(
      'site', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 450),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _cpfCnpjMeta =
      const VerificationMeta('cpfCnpj');
  @override
  late final GeneratedColumn<String> cpfCnpj = GeneratedColumn<String>(
      'cpf_cnpj', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 20),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _rgIeMeta = const VerificationMeta('rgIe');
  @override
  late final GeneratedColumn<String> rgIe = GeneratedColumn<String>(
      'rg_ie', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 20),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _desdeMeta = const VerificationMeta('desde');
  @override
  late final GeneratedColumn<DateTime> desde = GeneratedColumn<DateTime>(
      'desde', aliasedName, true,
      type: DriftSqlType.dateTime, requiredDuringInsert: false);
  static const VerificationMeta _taxaDescontoMeta =
      const VerificationMeta('taxaDesconto');
  @override
  late final GeneratedColumn<double> taxaDesconto = GeneratedColumn<double>(
      'taxa_desconto', aliasedName, true,
      type: DriftSqlType.double, requiredDuringInsert: false);
  static const VerificationMeta _limiteCreditoMeta =
      const VerificationMeta('limiteCredito');
  @override
  late final GeneratedColumn<double> limiteCredito = GeneratedColumn<double>(
      'limite_credito', aliasedName, true,
      type: DriftSqlType.double, requiredDuringInsert: false);
  static const VerificationMeta _dataCadastroMeta =
      const VerificationMeta('dataCadastro');
  @override
  late final GeneratedColumn<DateTime> dataCadastro = GeneratedColumn<DateTime>(
      'data_cadastro', aliasedName, true,
      type: DriftSqlType.dateTime, requiredDuringInsert: false);
  static const VerificationMeta _observacaoMeta =
      const VerificationMeta('observacao');
  @override
  late final GeneratedColumn<String> observacao = GeneratedColumn<String>(
      'observacao', aliasedName, true,
      type: DriftSqlType.string, requiredDuringInsert: false);
  static const VerificationMeta _idPessoaMeta =
      const VerificationMeta('idPessoa');
  @override
  late final GeneratedColumn<int> idPessoa = GeneratedColumn<int>(
      'id_pessoa', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  @override
  List<GeneratedColumn> get $columns => [
        id,
        nome,
        tipo,
        email,
        site,
        cpfCnpj,
        rgIe,
        desde,
        taxaDesconto,
        limiteCredito,
        dataCadastro,
        observacao,
        idPessoa
      ];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'view_pessoa_cliente';
  @override
  VerificationContext validateIntegrity(Insertable<ViewPessoaCliente> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('nome')) {
      context.handle(
          _nomeMeta, nome.isAcceptableOrUnknown(data['nome']!, _nomeMeta));
    }
    if (data.containsKey('tipo')) {
      context.handle(
          _tipoMeta, tipo.isAcceptableOrUnknown(data['tipo']!, _tipoMeta));
    }
    if (data.containsKey('email')) {
      context.handle(
          _emailMeta, email.isAcceptableOrUnknown(data['email']!, _emailMeta));
    }
    if (data.containsKey('site')) {
      context.handle(
          _siteMeta, site.isAcceptableOrUnknown(data['site']!, _siteMeta));
    }
    if (data.containsKey('cpf_cnpj')) {
      context.handle(_cpfCnpjMeta,
          cpfCnpj.isAcceptableOrUnknown(data['cpf_cnpj']!, _cpfCnpjMeta));
    }
    if (data.containsKey('rg_ie')) {
      context.handle(
          _rgIeMeta, rgIe.isAcceptableOrUnknown(data['rg_ie']!, _rgIeMeta));
    }
    if (data.containsKey('desde')) {
      context.handle(
          _desdeMeta, desde.isAcceptableOrUnknown(data['desde']!, _desdeMeta));
    }
    if (data.containsKey('taxa_desconto')) {
      context.handle(
          _taxaDescontoMeta,
          taxaDesconto.isAcceptableOrUnknown(
              data['taxa_desconto']!, _taxaDescontoMeta));
    }
    if (data.containsKey('limite_credito')) {
      context.handle(
          _limiteCreditoMeta,
          limiteCredito.isAcceptableOrUnknown(
              data['limite_credito']!, _limiteCreditoMeta));
    }
    if (data.containsKey('data_cadastro')) {
      context.handle(
          _dataCadastroMeta,
          dataCadastro.isAcceptableOrUnknown(
              data['data_cadastro']!, _dataCadastroMeta));
    }
    if (data.containsKey('observacao')) {
      context.handle(
          _observacaoMeta,
          observacao.isAcceptableOrUnknown(
              data['observacao']!, _observacaoMeta));
    }
    if (data.containsKey('id_pessoa')) {
      context.handle(_idPessoaMeta,
          idPessoa.isAcceptableOrUnknown(data['id_pessoa']!, _idPessoaMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  ViewPessoaCliente map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return ViewPessoaCliente(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id']),
      nome: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}nome']),
      tipo: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}tipo']),
      email: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}email']),
      site: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}site']),
      cpfCnpj: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}cpf_cnpj']),
      rgIe: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}rg_ie']),
      desde: attachedDatabase.typeMapping
          .read(DriftSqlType.dateTime, data['${effectivePrefix}desde']),
      taxaDesconto: attachedDatabase.typeMapping
          .read(DriftSqlType.double, data['${effectivePrefix}taxa_desconto']),
      limiteCredito: attachedDatabase.typeMapping
          .read(DriftSqlType.double, data['${effectivePrefix}limite_credito']),
      dataCadastro: attachedDatabase.typeMapping
          .read(DriftSqlType.dateTime, data['${effectivePrefix}data_cadastro']),
      observacao: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}observacao']),
      idPessoa: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id_pessoa']),
    );
  }

  @override
  $ViewPessoaClientesTable createAlias(String alias) {
    return $ViewPessoaClientesTable(attachedDatabase, alias);
  }
}

class ViewPessoaCliente extends DataClass
    implements Insertable<ViewPessoaCliente> {
  final int? id;
  final String? nome;
  final String? tipo;
  final String? email;
  final String? site;
  final String? cpfCnpj;
  final String? rgIe;
  final DateTime? desde;
  final double? taxaDesconto;
  final double? limiteCredito;
  final DateTime? dataCadastro;
  final String? observacao;
  final int? idPessoa;
  const ViewPessoaCliente(
      {this.id,
      this.nome,
      this.tipo,
      this.email,
      this.site,
      this.cpfCnpj,
      this.rgIe,
      this.desde,
      this.taxaDesconto,
      this.limiteCredito,
      this.dataCadastro,
      this.observacao,
      this.idPessoa});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || nome != null) {
      map['nome'] = Variable<String>(nome);
    }
    if (!nullToAbsent || tipo != null) {
      map['tipo'] = Variable<String>(tipo);
    }
    if (!nullToAbsent || email != null) {
      map['email'] = Variable<String>(email);
    }
    if (!nullToAbsent || site != null) {
      map['site'] = Variable<String>(site);
    }
    if (!nullToAbsent || cpfCnpj != null) {
      map['cpf_cnpj'] = Variable<String>(cpfCnpj);
    }
    if (!nullToAbsent || rgIe != null) {
      map['rg_ie'] = Variable<String>(rgIe);
    }
    if (!nullToAbsent || desde != null) {
      map['desde'] = Variable<DateTime>(desde);
    }
    if (!nullToAbsent || taxaDesconto != null) {
      map['taxa_desconto'] = Variable<double>(taxaDesconto);
    }
    if (!nullToAbsent || limiteCredito != null) {
      map['limite_credito'] = Variable<double>(limiteCredito);
    }
    if (!nullToAbsent || dataCadastro != null) {
      map['data_cadastro'] = Variable<DateTime>(dataCadastro);
    }
    if (!nullToAbsent || observacao != null) {
      map['observacao'] = Variable<String>(observacao);
    }
    if (!nullToAbsent || idPessoa != null) {
      map['id_pessoa'] = Variable<int>(idPessoa);
    }
    return map;
  }

  factory ViewPessoaCliente.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return ViewPessoaCliente(
      id: serializer.fromJson<int?>(json['id']),
      nome: serializer.fromJson<String?>(json['nome']),
      tipo: serializer.fromJson<String?>(json['tipo']),
      email: serializer.fromJson<String?>(json['email']),
      site: serializer.fromJson<String?>(json['site']),
      cpfCnpj: serializer.fromJson<String?>(json['cpfCnpj']),
      rgIe: serializer.fromJson<String?>(json['rgIe']),
      desde: serializer.fromJson<DateTime?>(json['desde']),
      taxaDesconto: serializer.fromJson<double?>(json['taxaDesconto']),
      limiteCredito: serializer.fromJson<double?>(json['limiteCredito']),
      dataCadastro: serializer.fromJson<DateTime?>(json['dataCadastro']),
      observacao: serializer.fromJson<String?>(json['observacao']),
      idPessoa: serializer.fromJson<int?>(json['idPessoa']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'nome': serializer.toJson<String?>(nome),
      'tipo': serializer.toJson<String?>(tipo),
      'email': serializer.toJson<String?>(email),
      'site': serializer.toJson<String?>(site),
      'cpfCnpj': serializer.toJson<String?>(cpfCnpj),
      'rgIe': serializer.toJson<String?>(rgIe),
      'desde': serializer.toJson<DateTime?>(desde),
      'taxaDesconto': serializer.toJson<double?>(taxaDesconto),
      'limiteCredito': serializer.toJson<double?>(limiteCredito),
      'dataCadastro': serializer.toJson<DateTime?>(dataCadastro),
      'observacao': serializer.toJson<String?>(observacao),
      'idPessoa': serializer.toJson<int?>(idPessoa),
    };
  }

  ViewPessoaCliente copyWith(
          {Value<int?> id = const Value.absent(),
          Value<String?> nome = const Value.absent(),
          Value<String?> tipo = const Value.absent(),
          Value<String?> email = const Value.absent(),
          Value<String?> site = const Value.absent(),
          Value<String?> cpfCnpj = const Value.absent(),
          Value<String?> rgIe = const Value.absent(),
          Value<DateTime?> desde = const Value.absent(),
          Value<double?> taxaDesconto = const Value.absent(),
          Value<double?> limiteCredito = const Value.absent(),
          Value<DateTime?> dataCadastro = const Value.absent(),
          Value<String?> observacao = const Value.absent(),
          Value<int?> idPessoa = const Value.absent()}) =>
      ViewPessoaCliente(
        id: id.present ? id.value : this.id,
        nome: nome.present ? nome.value : this.nome,
        tipo: tipo.present ? tipo.value : this.tipo,
        email: email.present ? email.value : this.email,
        site: site.present ? site.value : this.site,
        cpfCnpj: cpfCnpj.present ? cpfCnpj.value : this.cpfCnpj,
        rgIe: rgIe.present ? rgIe.value : this.rgIe,
        desde: desde.present ? desde.value : this.desde,
        taxaDesconto:
            taxaDesconto.present ? taxaDesconto.value : this.taxaDesconto,
        limiteCredito:
            limiteCredito.present ? limiteCredito.value : this.limiteCredito,
        dataCadastro:
            dataCadastro.present ? dataCadastro.value : this.dataCadastro,
        observacao: observacao.present ? observacao.value : this.observacao,
        idPessoa: idPessoa.present ? idPessoa.value : this.idPessoa,
      );
  ViewPessoaCliente copyWithCompanion(ViewPessoaClientesCompanion data) {
    return ViewPessoaCliente(
      id: data.id.present ? data.id.value : this.id,
      nome: data.nome.present ? data.nome.value : this.nome,
      tipo: data.tipo.present ? data.tipo.value : this.tipo,
      email: data.email.present ? data.email.value : this.email,
      site: data.site.present ? data.site.value : this.site,
      cpfCnpj: data.cpfCnpj.present ? data.cpfCnpj.value : this.cpfCnpj,
      rgIe: data.rgIe.present ? data.rgIe.value : this.rgIe,
      desde: data.desde.present ? data.desde.value : this.desde,
      taxaDesconto: data.taxaDesconto.present
          ? data.taxaDesconto.value
          : this.taxaDesconto,
      limiteCredito: data.limiteCredito.present
          ? data.limiteCredito.value
          : this.limiteCredito,
      dataCadastro: data.dataCadastro.present
          ? data.dataCadastro.value
          : this.dataCadastro,
      observacao:
          data.observacao.present ? data.observacao.value : this.observacao,
      idPessoa: data.idPessoa.present ? data.idPessoa.value : this.idPessoa,
    );
  }

  @override
  String toString() {
    return (StringBuffer('ViewPessoaCliente(')
          ..write('id: $id, ')
          ..write('nome: $nome, ')
          ..write('tipo: $tipo, ')
          ..write('email: $email, ')
          ..write('site: $site, ')
          ..write('cpfCnpj: $cpfCnpj, ')
          ..write('rgIe: $rgIe, ')
          ..write('desde: $desde, ')
          ..write('taxaDesconto: $taxaDesconto, ')
          ..write('limiteCredito: $limiteCredito, ')
          ..write('dataCadastro: $dataCadastro, ')
          ..write('observacao: $observacao, ')
          ..write('idPessoa: $idPessoa')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(id, nome, tipo, email, site, cpfCnpj, rgIe,
      desde, taxaDesconto, limiteCredito, dataCadastro, observacao, idPessoa);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is ViewPessoaCliente &&
          other.id == this.id &&
          other.nome == this.nome &&
          other.tipo == this.tipo &&
          other.email == this.email &&
          other.site == this.site &&
          other.cpfCnpj == this.cpfCnpj &&
          other.rgIe == this.rgIe &&
          other.desde == this.desde &&
          other.taxaDesconto == this.taxaDesconto &&
          other.limiteCredito == this.limiteCredito &&
          other.dataCadastro == this.dataCadastro &&
          other.observacao == this.observacao &&
          other.idPessoa == this.idPessoa);
}

class ViewPessoaClientesCompanion extends UpdateCompanion<ViewPessoaCliente> {
  final Value<int?> id;
  final Value<String?> nome;
  final Value<String?> tipo;
  final Value<String?> email;
  final Value<String?> site;
  final Value<String?> cpfCnpj;
  final Value<String?> rgIe;
  final Value<DateTime?> desde;
  final Value<double?> taxaDesconto;
  final Value<double?> limiteCredito;
  final Value<DateTime?> dataCadastro;
  final Value<String?> observacao;
  final Value<int?> idPessoa;
  const ViewPessoaClientesCompanion({
    this.id = const Value.absent(),
    this.nome = const Value.absent(),
    this.tipo = const Value.absent(),
    this.email = const Value.absent(),
    this.site = const Value.absent(),
    this.cpfCnpj = const Value.absent(),
    this.rgIe = const Value.absent(),
    this.desde = const Value.absent(),
    this.taxaDesconto = const Value.absent(),
    this.limiteCredito = const Value.absent(),
    this.dataCadastro = const Value.absent(),
    this.observacao = const Value.absent(),
    this.idPessoa = const Value.absent(),
  });
  ViewPessoaClientesCompanion.insert({
    this.id = const Value.absent(),
    this.nome = const Value.absent(),
    this.tipo = const Value.absent(),
    this.email = const Value.absent(),
    this.site = const Value.absent(),
    this.cpfCnpj = const Value.absent(),
    this.rgIe = const Value.absent(),
    this.desde = const Value.absent(),
    this.taxaDesconto = const Value.absent(),
    this.limiteCredito = const Value.absent(),
    this.dataCadastro = const Value.absent(),
    this.observacao = const Value.absent(),
    this.idPessoa = const Value.absent(),
  });
  static Insertable<ViewPessoaCliente> custom({
    Expression<int>? id,
    Expression<String>? nome,
    Expression<String>? tipo,
    Expression<String>? email,
    Expression<String>? site,
    Expression<String>? cpfCnpj,
    Expression<String>? rgIe,
    Expression<DateTime>? desde,
    Expression<double>? taxaDesconto,
    Expression<double>? limiteCredito,
    Expression<DateTime>? dataCadastro,
    Expression<String>? observacao,
    Expression<int>? idPessoa,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (nome != null) 'nome': nome,
      if (tipo != null) 'tipo': tipo,
      if (email != null) 'email': email,
      if (site != null) 'site': site,
      if (cpfCnpj != null) 'cpf_cnpj': cpfCnpj,
      if (rgIe != null) 'rg_ie': rgIe,
      if (desde != null) 'desde': desde,
      if (taxaDesconto != null) 'taxa_desconto': taxaDesconto,
      if (limiteCredito != null) 'limite_credito': limiteCredito,
      if (dataCadastro != null) 'data_cadastro': dataCadastro,
      if (observacao != null) 'observacao': observacao,
      if (idPessoa != null) 'id_pessoa': idPessoa,
    });
  }

  ViewPessoaClientesCompanion copyWith(
      {Value<int?>? id,
      Value<String?>? nome,
      Value<String?>? tipo,
      Value<String?>? email,
      Value<String?>? site,
      Value<String?>? cpfCnpj,
      Value<String?>? rgIe,
      Value<DateTime?>? desde,
      Value<double?>? taxaDesconto,
      Value<double?>? limiteCredito,
      Value<DateTime?>? dataCadastro,
      Value<String?>? observacao,
      Value<int?>? idPessoa}) {
    return ViewPessoaClientesCompanion(
      id: id ?? this.id,
      nome: nome ?? this.nome,
      tipo: tipo ?? this.tipo,
      email: email ?? this.email,
      site: site ?? this.site,
      cpfCnpj: cpfCnpj ?? this.cpfCnpj,
      rgIe: rgIe ?? this.rgIe,
      desde: desde ?? this.desde,
      taxaDesconto: taxaDesconto ?? this.taxaDesconto,
      limiteCredito: limiteCredito ?? this.limiteCredito,
      dataCadastro: dataCadastro ?? this.dataCadastro,
      observacao: observacao ?? this.observacao,
      idPessoa: idPessoa ?? this.idPessoa,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (nome.present) {
      map['nome'] = Variable<String>(nome.value);
    }
    if (tipo.present) {
      map['tipo'] = Variable<String>(tipo.value);
    }
    if (email.present) {
      map['email'] = Variable<String>(email.value);
    }
    if (site.present) {
      map['site'] = Variable<String>(site.value);
    }
    if (cpfCnpj.present) {
      map['cpf_cnpj'] = Variable<String>(cpfCnpj.value);
    }
    if (rgIe.present) {
      map['rg_ie'] = Variable<String>(rgIe.value);
    }
    if (desde.present) {
      map['desde'] = Variable<DateTime>(desde.value);
    }
    if (taxaDesconto.present) {
      map['taxa_desconto'] = Variable<double>(taxaDesconto.value);
    }
    if (limiteCredito.present) {
      map['limite_credito'] = Variable<double>(limiteCredito.value);
    }
    if (dataCadastro.present) {
      map['data_cadastro'] = Variable<DateTime>(dataCadastro.value);
    }
    if (observacao.present) {
      map['observacao'] = Variable<String>(observacao.value);
    }
    if (idPessoa.present) {
      map['id_pessoa'] = Variable<int>(idPessoa.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('ViewPessoaClientesCompanion(')
          ..write('id: $id, ')
          ..write('nome: $nome, ')
          ..write('tipo: $tipo, ')
          ..write('email: $email, ')
          ..write('site: $site, ')
          ..write('cpfCnpj: $cpfCnpj, ')
          ..write('rgIe: $rgIe, ')
          ..write('desde: $desde, ')
          ..write('taxaDesconto: $taxaDesconto, ')
          ..write('limiteCredito: $limiteCredito, ')
          ..write('dataCadastro: $dataCadastro, ')
          ..write('observacao: $observacao, ')
          ..write('idPessoa: $idPessoa')
          ..write(')'))
        .toString();
  }
}

class $ViewPessoaVendedorsTable extends ViewPessoaVendedors
    with TableInfo<$ViewPessoaVendedorsTable, ViewPessoaVendedor> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $ViewPessoaVendedorsTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
      'id', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _nomeMeta = const VerificationMeta('nome');
  @override
  late final GeneratedColumn<String> nome = GeneratedColumn<String>(
      'nome', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 450),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _tipoMeta = const VerificationMeta('tipo');
  @override
  late final GeneratedColumn<String> tipo = GeneratedColumn<String>(
      'tipo', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 3),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _emailMeta = const VerificationMeta('email');
  @override
  late final GeneratedColumn<String> email = GeneratedColumn<String>(
      'email', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 750),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _siteMeta = const VerificationMeta('site');
  @override
  late final GeneratedColumn<String> site = GeneratedColumn<String>(
      'site', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 450),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _cpfCnpjMeta =
      const VerificationMeta('cpfCnpj');
  @override
  late final GeneratedColumn<String> cpfCnpj = GeneratedColumn<String>(
      'cpf_cnpj', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 20),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _rgIeMeta = const VerificationMeta('rgIe');
  @override
  late final GeneratedColumn<String> rgIe = GeneratedColumn<String>(
      'rg_ie', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 20),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _matriculaMeta =
      const VerificationMeta('matricula');
  @override
  late final GeneratedColumn<String> matricula = GeneratedColumn<String>(
      'matricula', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 50),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _dataCadastroMeta =
      const VerificationMeta('dataCadastro');
  @override
  late final GeneratedColumn<DateTime> dataCadastro = GeneratedColumn<DateTime>(
      'data_cadastro', aliasedName, true,
      type: DriftSqlType.dateTime, requiredDuringInsert: false);
  static const VerificationMeta _dataAdmissaoMeta =
      const VerificationMeta('dataAdmissao');
  @override
  late final GeneratedColumn<DateTime> dataAdmissao = GeneratedColumn<DateTime>(
      'data_admissao', aliasedName, true,
      type: DriftSqlType.dateTime, requiredDuringInsert: false);
  static const VerificationMeta _dataDemissaoMeta =
      const VerificationMeta('dataDemissao');
  @override
  late final GeneratedColumn<DateTime> dataDemissao = GeneratedColumn<DateTime>(
      'data_demissao', aliasedName, true,
      type: DriftSqlType.dateTime, requiredDuringInsert: false);
  static const VerificationMeta _ctpsNumeroMeta =
      const VerificationMeta('ctpsNumero');
  @override
  late final GeneratedColumn<String> ctpsNumero = GeneratedColumn<String>(
      'ctps_numero', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 20),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _ctpsSerieMeta =
      const VerificationMeta('ctpsSerie');
  @override
  late final GeneratedColumn<String> ctpsSerie = GeneratedColumn<String>(
      'ctps_serie', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 10),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _ctpsDataExpedicaoMeta =
      const VerificationMeta('ctpsDataExpedicao');
  @override
  late final GeneratedColumn<DateTime> ctpsDataExpedicao =
      GeneratedColumn<DateTime>('ctps_data_expedicao', aliasedName, true,
          type: DriftSqlType.dateTime, requiredDuringInsert: false);
  static const VerificationMeta _ctpsUfMeta = const VerificationMeta('ctpsUf');
  @override
  late final GeneratedColumn<String> ctpsUf = GeneratedColumn<String>(
      'ctps_uf', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 2),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _observacaoMeta =
      const VerificationMeta('observacao');
  @override
  late final GeneratedColumn<String> observacao = GeneratedColumn<String>(
      'observacao', aliasedName, true,
      type: DriftSqlType.string, requiredDuringInsert: false);
  static const VerificationMeta _logradouroMeta =
      const VerificationMeta('logradouro');
  @override
  late final GeneratedColumn<String> logradouro = GeneratedColumn<String>(
      'logradouro', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 450),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _numeroMeta = const VerificationMeta('numero');
  @override
  late final GeneratedColumn<String> numero = GeneratedColumn<String>(
      'numero', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 20),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _complementoMeta =
      const VerificationMeta('complemento');
  @override
  late final GeneratedColumn<String> complemento = GeneratedColumn<String>(
      'complemento', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 450),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _bairroMeta = const VerificationMeta('bairro');
  @override
  late final GeneratedColumn<String> bairro = GeneratedColumn<String>(
      'bairro', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 150),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _cidadeMeta = const VerificationMeta('cidade');
  @override
  late final GeneratedColumn<String> cidade = GeneratedColumn<String>(
      'cidade', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 150),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _cepMeta = const VerificationMeta('cep');
  @override
  late final GeneratedColumn<String> cep = GeneratedColumn<String>(
      'cep', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 10),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _municipioIbgeMeta =
      const VerificationMeta('municipioIbge');
  @override
  late final GeneratedColumn<String> municipioIbge = GeneratedColumn<String>(
      'municipio_ibge', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 10),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _ufMeta = const VerificationMeta('uf');
  @override
  late final GeneratedColumn<String> uf = GeneratedColumn<String>(
      'uf', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 2),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _idPessoaMeta =
      const VerificationMeta('idPessoa');
  @override
  late final GeneratedColumn<int> idPessoa = GeneratedColumn<int>(
      'id_pessoa', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _idCargoMeta =
      const VerificationMeta('idCargo');
  @override
  late final GeneratedColumn<int> idCargo = GeneratedColumn<int>(
      'id_cargo', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _idSetorMeta =
      const VerificationMeta('idSetor');
  @override
  late final GeneratedColumn<int> idSetor = GeneratedColumn<int>(
      'id_setor', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _comissaoMeta =
      const VerificationMeta('comissao');
  @override
  late final GeneratedColumn<double> comissao = GeneratedColumn<double>(
      'comissao', aliasedName, true,
      type: DriftSqlType.double, requiredDuringInsert: false);
  static const VerificationMeta _metaVendaMeta =
      const VerificationMeta('metaVenda');
  @override
  late final GeneratedColumn<double> metaVenda = GeneratedColumn<double>(
      'meta_venda', aliasedName, true,
      type: DriftSqlType.double, requiredDuringInsert: false);
  @override
  List<GeneratedColumn> get $columns => [
        id,
        nome,
        tipo,
        email,
        site,
        cpfCnpj,
        rgIe,
        matricula,
        dataCadastro,
        dataAdmissao,
        dataDemissao,
        ctpsNumero,
        ctpsSerie,
        ctpsDataExpedicao,
        ctpsUf,
        observacao,
        logradouro,
        numero,
        complemento,
        bairro,
        cidade,
        cep,
        municipioIbge,
        uf,
        idPessoa,
        idCargo,
        idSetor,
        comissao,
        metaVenda
      ];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'view_pessoa_vendedor';
  @override
  VerificationContext validateIntegrity(Insertable<ViewPessoaVendedor> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('nome')) {
      context.handle(
          _nomeMeta, nome.isAcceptableOrUnknown(data['nome']!, _nomeMeta));
    }
    if (data.containsKey('tipo')) {
      context.handle(
          _tipoMeta, tipo.isAcceptableOrUnknown(data['tipo']!, _tipoMeta));
    }
    if (data.containsKey('email')) {
      context.handle(
          _emailMeta, email.isAcceptableOrUnknown(data['email']!, _emailMeta));
    }
    if (data.containsKey('site')) {
      context.handle(
          _siteMeta, site.isAcceptableOrUnknown(data['site']!, _siteMeta));
    }
    if (data.containsKey('cpf_cnpj')) {
      context.handle(_cpfCnpjMeta,
          cpfCnpj.isAcceptableOrUnknown(data['cpf_cnpj']!, _cpfCnpjMeta));
    }
    if (data.containsKey('rg_ie')) {
      context.handle(
          _rgIeMeta, rgIe.isAcceptableOrUnknown(data['rg_ie']!, _rgIeMeta));
    }
    if (data.containsKey('matricula')) {
      context.handle(_matriculaMeta,
          matricula.isAcceptableOrUnknown(data['matricula']!, _matriculaMeta));
    }
    if (data.containsKey('data_cadastro')) {
      context.handle(
          _dataCadastroMeta,
          dataCadastro.isAcceptableOrUnknown(
              data['data_cadastro']!, _dataCadastroMeta));
    }
    if (data.containsKey('data_admissao')) {
      context.handle(
          _dataAdmissaoMeta,
          dataAdmissao.isAcceptableOrUnknown(
              data['data_admissao']!, _dataAdmissaoMeta));
    }
    if (data.containsKey('data_demissao')) {
      context.handle(
          _dataDemissaoMeta,
          dataDemissao.isAcceptableOrUnknown(
              data['data_demissao']!, _dataDemissaoMeta));
    }
    if (data.containsKey('ctps_numero')) {
      context.handle(
          _ctpsNumeroMeta,
          ctpsNumero.isAcceptableOrUnknown(
              data['ctps_numero']!, _ctpsNumeroMeta));
    }
    if (data.containsKey('ctps_serie')) {
      context.handle(_ctpsSerieMeta,
          ctpsSerie.isAcceptableOrUnknown(data['ctps_serie']!, _ctpsSerieMeta));
    }
    if (data.containsKey('ctps_data_expedicao')) {
      context.handle(
          _ctpsDataExpedicaoMeta,
          ctpsDataExpedicao.isAcceptableOrUnknown(
              data['ctps_data_expedicao']!, _ctpsDataExpedicaoMeta));
    }
    if (data.containsKey('ctps_uf')) {
      context.handle(_ctpsUfMeta,
          ctpsUf.isAcceptableOrUnknown(data['ctps_uf']!, _ctpsUfMeta));
    }
    if (data.containsKey('observacao')) {
      context.handle(
          _observacaoMeta,
          observacao.isAcceptableOrUnknown(
              data['observacao']!, _observacaoMeta));
    }
    if (data.containsKey('logradouro')) {
      context.handle(
          _logradouroMeta,
          logradouro.isAcceptableOrUnknown(
              data['logradouro']!, _logradouroMeta));
    }
    if (data.containsKey('numero')) {
      context.handle(_numeroMeta,
          numero.isAcceptableOrUnknown(data['numero']!, _numeroMeta));
    }
    if (data.containsKey('complemento')) {
      context.handle(
          _complementoMeta,
          complemento.isAcceptableOrUnknown(
              data['complemento']!, _complementoMeta));
    }
    if (data.containsKey('bairro')) {
      context.handle(_bairroMeta,
          bairro.isAcceptableOrUnknown(data['bairro']!, _bairroMeta));
    }
    if (data.containsKey('cidade')) {
      context.handle(_cidadeMeta,
          cidade.isAcceptableOrUnknown(data['cidade']!, _cidadeMeta));
    }
    if (data.containsKey('cep')) {
      context.handle(
          _cepMeta, cep.isAcceptableOrUnknown(data['cep']!, _cepMeta));
    }
    if (data.containsKey('municipio_ibge')) {
      context.handle(
          _municipioIbgeMeta,
          municipioIbge.isAcceptableOrUnknown(
              data['municipio_ibge']!, _municipioIbgeMeta));
    }
    if (data.containsKey('uf')) {
      context.handle(_ufMeta, uf.isAcceptableOrUnknown(data['uf']!, _ufMeta));
    }
    if (data.containsKey('id_pessoa')) {
      context.handle(_idPessoaMeta,
          idPessoa.isAcceptableOrUnknown(data['id_pessoa']!, _idPessoaMeta));
    }
    if (data.containsKey('id_cargo')) {
      context.handle(_idCargoMeta,
          idCargo.isAcceptableOrUnknown(data['id_cargo']!, _idCargoMeta));
    }
    if (data.containsKey('id_setor')) {
      context.handle(_idSetorMeta,
          idSetor.isAcceptableOrUnknown(data['id_setor']!, _idSetorMeta));
    }
    if (data.containsKey('comissao')) {
      context.handle(_comissaoMeta,
          comissao.isAcceptableOrUnknown(data['comissao']!, _comissaoMeta));
    }
    if (data.containsKey('meta_venda')) {
      context.handle(_metaVendaMeta,
          metaVenda.isAcceptableOrUnknown(data['meta_venda']!, _metaVendaMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  ViewPessoaVendedor map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return ViewPessoaVendedor(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id']),
      nome: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}nome']),
      tipo: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}tipo']),
      email: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}email']),
      site: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}site']),
      cpfCnpj: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}cpf_cnpj']),
      rgIe: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}rg_ie']),
      matricula: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}matricula']),
      dataCadastro: attachedDatabase.typeMapping
          .read(DriftSqlType.dateTime, data['${effectivePrefix}data_cadastro']),
      dataAdmissao: attachedDatabase.typeMapping
          .read(DriftSqlType.dateTime, data['${effectivePrefix}data_admissao']),
      dataDemissao: attachedDatabase.typeMapping
          .read(DriftSqlType.dateTime, data['${effectivePrefix}data_demissao']),
      ctpsNumero: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}ctps_numero']),
      ctpsSerie: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}ctps_serie']),
      ctpsDataExpedicao: attachedDatabase.typeMapping.read(
          DriftSqlType.dateTime, data['${effectivePrefix}ctps_data_expedicao']),
      ctpsUf: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}ctps_uf']),
      observacao: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}observacao']),
      logradouro: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}logradouro']),
      numero: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}numero']),
      complemento: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}complemento']),
      bairro: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}bairro']),
      cidade: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}cidade']),
      cep: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}cep']),
      municipioIbge: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}municipio_ibge']),
      uf: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}uf']),
      idPessoa: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id_pessoa']),
      idCargo: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id_cargo']),
      idSetor: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id_setor']),
      comissao: attachedDatabase.typeMapping
          .read(DriftSqlType.double, data['${effectivePrefix}comissao']),
      metaVenda: attachedDatabase.typeMapping
          .read(DriftSqlType.double, data['${effectivePrefix}meta_venda']),
    );
  }

  @override
  $ViewPessoaVendedorsTable createAlias(String alias) {
    return $ViewPessoaVendedorsTable(attachedDatabase, alias);
  }
}

class ViewPessoaVendedor extends DataClass
    implements Insertable<ViewPessoaVendedor> {
  final int? id;
  final String? nome;
  final String? tipo;
  final String? email;
  final String? site;
  final String? cpfCnpj;
  final String? rgIe;
  final String? matricula;
  final DateTime? dataCadastro;
  final DateTime? dataAdmissao;
  final DateTime? dataDemissao;
  final String? ctpsNumero;
  final String? ctpsSerie;
  final DateTime? ctpsDataExpedicao;
  final String? ctpsUf;
  final String? observacao;
  final String? logradouro;
  final String? numero;
  final String? complemento;
  final String? bairro;
  final String? cidade;
  final String? cep;
  final String? municipioIbge;
  final String? uf;
  final int? idPessoa;
  final int? idCargo;
  final int? idSetor;
  final double? comissao;
  final double? metaVenda;
  const ViewPessoaVendedor(
      {this.id,
      this.nome,
      this.tipo,
      this.email,
      this.site,
      this.cpfCnpj,
      this.rgIe,
      this.matricula,
      this.dataCadastro,
      this.dataAdmissao,
      this.dataDemissao,
      this.ctpsNumero,
      this.ctpsSerie,
      this.ctpsDataExpedicao,
      this.ctpsUf,
      this.observacao,
      this.logradouro,
      this.numero,
      this.complemento,
      this.bairro,
      this.cidade,
      this.cep,
      this.municipioIbge,
      this.uf,
      this.idPessoa,
      this.idCargo,
      this.idSetor,
      this.comissao,
      this.metaVenda});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || nome != null) {
      map['nome'] = Variable<String>(nome);
    }
    if (!nullToAbsent || tipo != null) {
      map['tipo'] = Variable<String>(tipo);
    }
    if (!nullToAbsent || email != null) {
      map['email'] = Variable<String>(email);
    }
    if (!nullToAbsent || site != null) {
      map['site'] = Variable<String>(site);
    }
    if (!nullToAbsent || cpfCnpj != null) {
      map['cpf_cnpj'] = Variable<String>(cpfCnpj);
    }
    if (!nullToAbsent || rgIe != null) {
      map['rg_ie'] = Variable<String>(rgIe);
    }
    if (!nullToAbsent || matricula != null) {
      map['matricula'] = Variable<String>(matricula);
    }
    if (!nullToAbsent || dataCadastro != null) {
      map['data_cadastro'] = Variable<DateTime>(dataCadastro);
    }
    if (!nullToAbsent || dataAdmissao != null) {
      map['data_admissao'] = Variable<DateTime>(dataAdmissao);
    }
    if (!nullToAbsent || dataDemissao != null) {
      map['data_demissao'] = Variable<DateTime>(dataDemissao);
    }
    if (!nullToAbsent || ctpsNumero != null) {
      map['ctps_numero'] = Variable<String>(ctpsNumero);
    }
    if (!nullToAbsent || ctpsSerie != null) {
      map['ctps_serie'] = Variable<String>(ctpsSerie);
    }
    if (!nullToAbsent || ctpsDataExpedicao != null) {
      map['ctps_data_expedicao'] = Variable<DateTime>(ctpsDataExpedicao);
    }
    if (!nullToAbsent || ctpsUf != null) {
      map['ctps_uf'] = Variable<String>(ctpsUf);
    }
    if (!nullToAbsent || observacao != null) {
      map['observacao'] = Variable<String>(observacao);
    }
    if (!nullToAbsent || logradouro != null) {
      map['logradouro'] = Variable<String>(logradouro);
    }
    if (!nullToAbsent || numero != null) {
      map['numero'] = Variable<String>(numero);
    }
    if (!nullToAbsent || complemento != null) {
      map['complemento'] = Variable<String>(complemento);
    }
    if (!nullToAbsent || bairro != null) {
      map['bairro'] = Variable<String>(bairro);
    }
    if (!nullToAbsent || cidade != null) {
      map['cidade'] = Variable<String>(cidade);
    }
    if (!nullToAbsent || cep != null) {
      map['cep'] = Variable<String>(cep);
    }
    if (!nullToAbsent || municipioIbge != null) {
      map['municipio_ibge'] = Variable<String>(municipioIbge);
    }
    if (!nullToAbsent || uf != null) {
      map['uf'] = Variable<String>(uf);
    }
    if (!nullToAbsent || idPessoa != null) {
      map['id_pessoa'] = Variable<int>(idPessoa);
    }
    if (!nullToAbsent || idCargo != null) {
      map['id_cargo'] = Variable<int>(idCargo);
    }
    if (!nullToAbsent || idSetor != null) {
      map['id_setor'] = Variable<int>(idSetor);
    }
    if (!nullToAbsent || comissao != null) {
      map['comissao'] = Variable<double>(comissao);
    }
    if (!nullToAbsent || metaVenda != null) {
      map['meta_venda'] = Variable<double>(metaVenda);
    }
    return map;
  }

  factory ViewPessoaVendedor.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return ViewPessoaVendedor(
      id: serializer.fromJson<int?>(json['id']),
      nome: serializer.fromJson<String?>(json['nome']),
      tipo: serializer.fromJson<String?>(json['tipo']),
      email: serializer.fromJson<String?>(json['email']),
      site: serializer.fromJson<String?>(json['site']),
      cpfCnpj: serializer.fromJson<String?>(json['cpfCnpj']),
      rgIe: serializer.fromJson<String?>(json['rgIe']),
      matricula: serializer.fromJson<String?>(json['matricula']),
      dataCadastro: serializer.fromJson<DateTime?>(json['dataCadastro']),
      dataAdmissao: serializer.fromJson<DateTime?>(json['dataAdmissao']),
      dataDemissao: serializer.fromJson<DateTime?>(json['dataDemissao']),
      ctpsNumero: serializer.fromJson<String?>(json['ctpsNumero']),
      ctpsSerie: serializer.fromJson<String?>(json['ctpsSerie']),
      ctpsDataExpedicao:
          serializer.fromJson<DateTime?>(json['ctpsDataExpedicao']),
      ctpsUf: serializer.fromJson<String?>(json['ctpsUf']),
      observacao: serializer.fromJson<String?>(json['observacao']),
      logradouro: serializer.fromJson<String?>(json['logradouro']),
      numero: serializer.fromJson<String?>(json['numero']),
      complemento: serializer.fromJson<String?>(json['complemento']),
      bairro: serializer.fromJson<String?>(json['bairro']),
      cidade: serializer.fromJson<String?>(json['cidade']),
      cep: serializer.fromJson<String?>(json['cep']),
      municipioIbge: serializer.fromJson<String?>(json['municipioIbge']),
      uf: serializer.fromJson<String?>(json['uf']),
      idPessoa: serializer.fromJson<int?>(json['idPessoa']),
      idCargo: serializer.fromJson<int?>(json['idCargo']),
      idSetor: serializer.fromJson<int?>(json['idSetor']),
      comissao: serializer.fromJson<double?>(json['comissao']),
      metaVenda: serializer.fromJson<double?>(json['metaVenda']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'nome': serializer.toJson<String?>(nome),
      'tipo': serializer.toJson<String?>(tipo),
      'email': serializer.toJson<String?>(email),
      'site': serializer.toJson<String?>(site),
      'cpfCnpj': serializer.toJson<String?>(cpfCnpj),
      'rgIe': serializer.toJson<String?>(rgIe),
      'matricula': serializer.toJson<String?>(matricula),
      'dataCadastro': serializer.toJson<DateTime?>(dataCadastro),
      'dataAdmissao': serializer.toJson<DateTime?>(dataAdmissao),
      'dataDemissao': serializer.toJson<DateTime?>(dataDemissao),
      'ctpsNumero': serializer.toJson<String?>(ctpsNumero),
      'ctpsSerie': serializer.toJson<String?>(ctpsSerie),
      'ctpsDataExpedicao': serializer.toJson<DateTime?>(ctpsDataExpedicao),
      'ctpsUf': serializer.toJson<String?>(ctpsUf),
      'observacao': serializer.toJson<String?>(observacao),
      'logradouro': serializer.toJson<String?>(logradouro),
      'numero': serializer.toJson<String?>(numero),
      'complemento': serializer.toJson<String?>(complemento),
      'bairro': serializer.toJson<String?>(bairro),
      'cidade': serializer.toJson<String?>(cidade),
      'cep': serializer.toJson<String?>(cep),
      'municipioIbge': serializer.toJson<String?>(municipioIbge),
      'uf': serializer.toJson<String?>(uf),
      'idPessoa': serializer.toJson<int?>(idPessoa),
      'idCargo': serializer.toJson<int?>(idCargo),
      'idSetor': serializer.toJson<int?>(idSetor),
      'comissao': serializer.toJson<double?>(comissao),
      'metaVenda': serializer.toJson<double?>(metaVenda),
    };
  }

  ViewPessoaVendedor copyWith(
          {Value<int?> id = const Value.absent(),
          Value<String?> nome = const Value.absent(),
          Value<String?> tipo = const Value.absent(),
          Value<String?> email = const Value.absent(),
          Value<String?> site = const Value.absent(),
          Value<String?> cpfCnpj = const Value.absent(),
          Value<String?> rgIe = const Value.absent(),
          Value<String?> matricula = const Value.absent(),
          Value<DateTime?> dataCadastro = const Value.absent(),
          Value<DateTime?> dataAdmissao = const Value.absent(),
          Value<DateTime?> dataDemissao = const Value.absent(),
          Value<String?> ctpsNumero = const Value.absent(),
          Value<String?> ctpsSerie = const Value.absent(),
          Value<DateTime?> ctpsDataExpedicao = const Value.absent(),
          Value<String?> ctpsUf = const Value.absent(),
          Value<String?> observacao = const Value.absent(),
          Value<String?> logradouro = const Value.absent(),
          Value<String?> numero = const Value.absent(),
          Value<String?> complemento = const Value.absent(),
          Value<String?> bairro = const Value.absent(),
          Value<String?> cidade = const Value.absent(),
          Value<String?> cep = const Value.absent(),
          Value<String?> municipioIbge = const Value.absent(),
          Value<String?> uf = const Value.absent(),
          Value<int?> idPessoa = const Value.absent(),
          Value<int?> idCargo = const Value.absent(),
          Value<int?> idSetor = const Value.absent(),
          Value<double?> comissao = const Value.absent(),
          Value<double?> metaVenda = const Value.absent()}) =>
      ViewPessoaVendedor(
        id: id.present ? id.value : this.id,
        nome: nome.present ? nome.value : this.nome,
        tipo: tipo.present ? tipo.value : this.tipo,
        email: email.present ? email.value : this.email,
        site: site.present ? site.value : this.site,
        cpfCnpj: cpfCnpj.present ? cpfCnpj.value : this.cpfCnpj,
        rgIe: rgIe.present ? rgIe.value : this.rgIe,
        matricula: matricula.present ? matricula.value : this.matricula,
        dataCadastro:
            dataCadastro.present ? dataCadastro.value : this.dataCadastro,
        dataAdmissao:
            dataAdmissao.present ? dataAdmissao.value : this.dataAdmissao,
        dataDemissao:
            dataDemissao.present ? dataDemissao.value : this.dataDemissao,
        ctpsNumero: ctpsNumero.present ? ctpsNumero.value : this.ctpsNumero,
        ctpsSerie: ctpsSerie.present ? ctpsSerie.value : this.ctpsSerie,
        ctpsDataExpedicao: ctpsDataExpedicao.present
            ? ctpsDataExpedicao.value
            : this.ctpsDataExpedicao,
        ctpsUf: ctpsUf.present ? ctpsUf.value : this.ctpsUf,
        observacao: observacao.present ? observacao.value : this.observacao,
        logradouro: logradouro.present ? logradouro.value : this.logradouro,
        numero: numero.present ? numero.value : this.numero,
        complemento: complemento.present ? complemento.value : this.complemento,
        bairro: bairro.present ? bairro.value : this.bairro,
        cidade: cidade.present ? cidade.value : this.cidade,
        cep: cep.present ? cep.value : this.cep,
        municipioIbge:
            municipioIbge.present ? municipioIbge.value : this.municipioIbge,
        uf: uf.present ? uf.value : this.uf,
        idPessoa: idPessoa.present ? idPessoa.value : this.idPessoa,
        idCargo: idCargo.present ? idCargo.value : this.idCargo,
        idSetor: idSetor.present ? idSetor.value : this.idSetor,
        comissao: comissao.present ? comissao.value : this.comissao,
        metaVenda: metaVenda.present ? metaVenda.value : this.metaVenda,
      );
  ViewPessoaVendedor copyWithCompanion(ViewPessoaVendedorsCompanion data) {
    return ViewPessoaVendedor(
      id: data.id.present ? data.id.value : this.id,
      nome: data.nome.present ? data.nome.value : this.nome,
      tipo: data.tipo.present ? data.tipo.value : this.tipo,
      email: data.email.present ? data.email.value : this.email,
      site: data.site.present ? data.site.value : this.site,
      cpfCnpj: data.cpfCnpj.present ? data.cpfCnpj.value : this.cpfCnpj,
      rgIe: data.rgIe.present ? data.rgIe.value : this.rgIe,
      matricula: data.matricula.present ? data.matricula.value : this.matricula,
      dataCadastro: data.dataCadastro.present
          ? data.dataCadastro.value
          : this.dataCadastro,
      dataAdmissao: data.dataAdmissao.present
          ? data.dataAdmissao.value
          : this.dataAdmissao,
      dataDemissao: data.dataDemissao.present
          ? data.dataDemissao.value
          : this.dataDemissao,
      ctpsNumero:
          data.ctpsNumero.present ? data.ctpsNumero.value : this.ctpsNumero,
      ctpsSerie: data.ctpsSerie.present ? data.ctpsSerie.value : this.ctpsSerie,
      ctpsDataExpedicao: data.ctpsDataExpedicao.present
          ? data.ctpsDataExpedicao.value
          : this.ctpsDataExpedicao,
      ctpsUf: data.ctpsUf.present ? data.ctpsUf.value : this.ctpsUf,
      observacao:
          data.observacao.present ? data.observacao.value : this.observacao,
      logradouro:
          data.logradouro.present ? data.logradouro.value : this.logradouro,
      numero: data.numero.present ? data.numero.value : this.numero,
      complemento:
          data.complemento.present ? data.complemento.value : this.complemento,
      bairro: data.bairro.present ? data.bairro.value : this.bairro,
      cidade: data.cidade.present ? data.cidade.value : this.cidade,
      cep: data.cep.present ? data.cep.value : this.cep,
      municipioIbge: data.municipioIbge.present
          ? data.municipioIbge.value
          : this.municipioIbge,
      uf: data.uf.present ? data.uf.value : this.uf,
      idPessoa: data.idPessoa.present ? data.idPessoa.value : this.idPessoa,
      idCargo: data.idCargo.present ? data.idCargo.value : this.idCargo,
      idSetor: data.idSetor.present ? data.idSetor.value : this.idSetor,
      comissao: data.comissao.present ? data.comissao.value : this.comissao,
      metaVenda: data.metaVenda.present ? data.metaVenda.value : this.metaVenda,
    );
  }

  @override
  String toString() {
    return (StringBuffer('ViewPessoaVendedor(')
          ..write('id: $id, ')
          ..write('nome: $nome, ')
          ..write('tipo: $tipo, ')
          ..write('email: $email, ')
          ..write('site: $site, ')
          ..write('cpfCnpj: $cpfCnpj, ')
          ..write('rgIe: $rgIe, ')
          ..write('matricula: $matricula, ')
          ..write('dataCadastro: $dataCadastro, ')
          ..write('dataAdmissao: $dataAdmissao, ')
          ..write('dataDemissao: $dataDemissao, ')
          ..write('ctpsNumero: $ctpsNumero, ')
          ..write('ctpsSerie: $ctpsSerie, ')
          ..write('ctpsDataExpedicao: $ctpsDataExpedicao, ')
          ..write('ctpsUf: $ctpsUf, ')
          ..write('observacao: $observacao, ')
          ..write('logradouro: $logradouro, ')
          ..write('numero: $numero, ')
          ..write('complemento: $complemento, ')
          ..write('bairro: $bairro, ')
          ..write('cidade: $cidade, ')
          ..write('cep: $cep, ')
          ..write('municipioIbge: $municipioIbge, ')
          ..write('uf: $uf, ')
          ..write('idPessoa: $idPessoa, ')
          ..write('idCargo: $idCargo, ')
          ..write('idSetor: $idSetor, ')
          ..write('comissao: $comissao, ')
          ..write('metaVenda: $metaVenda')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hashAll([
        id,
        nome,
        tipo,
        email,
        site,
        cpfCnpj,
        rgIe,
        matricula,
        dataCadastro,
        dataAdmissao,
        dataDemissao,
        ctpsNumero,
        ctpsSerie,
        ctpsDataExpedicao,
        ctpsUf,
        observacao,
        logradouro,
        numero,
        complemento,
        bairro,
        cidade,
        cep,
        municipioIbge,
        uf,
        idPessoa,
        idCargo,
        idSetor,
        comissao,
        metaVenda
      ]);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is ViewPessoaVendedor &&
          other.id == this.id &&
          other.nome == this.nome &&
          other.tipo == this.tipo &&
          other.email == this.email &&
          other.site == this.site &&
          other.cpfCnpj == this.cpfCnpj &&
          other.rgIe == this.rgIe &&
          other.matricula == this.matricula &&
          other.dataCadastro == this.dataCadastro &&
          other.dataAdmissao == this.dataAdmissao &&
          other.dataDemissao == this.dataDemissao &&
          other.ctpsNumero == this.ctpsNumero &&
          other.ctpsSerie == this.ctpsSerie &&
          other.ctpsDataExpedicao == this.ctpsDataExpedicao &&
          other.ctpsUf == this.ctpsUf &&
          other.observacao == this.observacao &&
          other.logradouro == this.logradouro &&
          other.numero == this.numero &&
          other.complemento == this.complemento &&
          other.bairro == this.bairro &&
          other.cidade == this.cidade &&
          other.cep == this.cep &&
          other.municipioIbge == this.municipioIbge &&
          other.uf == this.uf &&
          other.idPessoa == this.idPessoa &&
          other.idCargo == this.idCargo &&
          other.idSetor == this.idSetor &&
          other.comissao == this.comissao &&
          other.metaVenda == this.metaVenda);
}

class ViewPessoaVendedorsCompanion extends UpdateCompanion<ViewPessoaVendedor> {
  final Value<int?> id;
  final Value<String?> nome;
  final Value<String?> tipo;
  final Value<String?> email;
  final Value<String?> site;
  final Value<String?> cpfCnpj;
  final Value<String?> rgIe;
  final Value<String?> matricula;
  final Value<DateTime?> dataCadastro;
  final Value<DateTime?> dataAdmissao;
  final Value<DateTime?> dataDemissao;
  final Value<String?> ctpsNumero;
  final Value<String?> ctpsSerie;
  final Value<DateTime?> ctpsDataExpedicao;
  final Value<String?> ctpsUf;
  final Value<String?> observacao;
  final Value<String?> logradouro;
  final Value<String?> numero;
  final Value<String?> complemento;
  final Value<String?> bairro;
  final Value<String?> cidade;
  final Value<String?> cep;
  final Value<String?> municipioIbge;
  final Value<String?> uf;
  final Value<int?> idPessoa;
  final Value<int?> idCargo;
  final Value<int?> idSetor;
  final Value<double?> comissao;
  final Value<double?> metaVenda;
  const ViewPessoaVendedorsCompanion({
    this.id = const Value.absent(),
    this.nome = const Value.absent(),
    this.tipo = const Value.absent(),
    this.email = const Value.absent(),
    this.site = const Value.absent(),
    this.cpfCnpj = const Value.absent(),
    this.rgIe = const Value.absent(),
    this.matricula = const Value.absent(),
    this.dataCadastro = const Value.absent(),
    this.dataAdmissao = const Value.absent(),
    this.dataDemissao = const Value.absent(),
    this.ctpsNumero = const Value.absent(),
    this.ctpsSerie = const Value.absent(),
    this.ctpsDataExpedicao = const Value.absent(),
    this.ctpsUf = const Value.absent(),
    this.observacao = const Value.absent(),
    this.logradouro = const Value.absent(),
    this.numero = const Value.absent(),
    this.complemento = const Value.absent(),
    this.bairro = const Value.absent(),
    this.cidade = const Value.absent(),
    this.cep = const Value.absent(),
    this.municipioIbge = const Value.absent(),
    this.uf = const Value.absent(),
    this.idPessoa = const Value.absent(),
    this.idCargo = const Value.absent(),
    this.idSetor = const Value.absent(),
    this.comissao = const Value.absent(),
    this.metaVenda = const Value.absent(),
  });
  ViewPessoaVendedorsCompanion.insert({
    this.id = const Value.absent(),
    this.nome = const Value.absent(),
    this.tipo = const Value.absent(),
    this.email = const Value.absent(),
    this.site = const Value.absent(),
    this.cpfCnpj = const Value.absent(),
    this.rgIe = const Value.absent(),
    this.matricula = const Value.absent(),
    this.dataCadastro = const Value.absent(),
    this.dataAdmissao = const Value.absent(),
    this.dataDemissao = const Value.absent(),
    this.ctpsNumero = const Value.absent(),
    this.ctpsSerie = const Value.absent(),
    this.ctpsDataExpedicao = const Value.absent(),
    this.ctpsUf = const Value.absent(),
    this.observacao = const Value.absent(),
    this.logradouro = const Value.absent(),
    this.numero = const Value.absent(),
    this.complemento = const Value.absent(),
    this.bairro = const Value.absent(),
    this.cidade = const Value.absent(),
    this.cep = const Value.absent(),
    this.municipioIbge = const Value.absent(),
    this.uf = const Value.absent(),
    this.idPessoa = const Value.absent(),
    this.idCargo = const Value.absent(),
    this.idSetor = const Value.absent(),
    this.comissao = const Value.absent(),
    this.metaVenda = const Value.absent(),
  });
  static Insertable<ViewPessoaVendedor> custom({
    Expression<int>? id,
    Expression<String>? nome,
    Expression<String>? tipo,
    Expression<String>? email,
    Expression<String>? site,
    Expression<String>? cpfCnpj,
    Expression<String>? rgIe,
    Expression<String>? matricula,
    Expression<DateTime>? dataCadastro,
    Expression<DateTime>? dataAdmissao,
    Expression<DateTime>? dataDemissao,
    Expression<String>? ctpsNumero,
    Expression<String>? ctpsSerie,
    Expression<DateTime>? ctpsDataExpedicao,
    Expression<String>? ctpsUf,
    Expression<String>? observacao,
    Expression<String>? logradouro,
    Expression<String>? numero,
    Expression<String>? complemento,
    Expression<String>? bairro,
    Expression<String>? cidade,
    Expression<String>? cep,
    Expression<String>? municipioIbge,
    Expression<String>? uf,
    Expression<int>? idPessoa,
    Expression<int>? idCargo,
    Expression<int>? idSetor,
    Expression<double>? comissao,
    Expression<double>? metaVenda,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (nome != null) 'nome': nome,
      if (tipo != null) 'tipo': tipo,
      if (email != null) 'email': email,
      if (site != null) 'site': site,
      if (cpfCnpj != null) 'cpf_cnpj': cpfCnpj,
      if (rgIe != null) 'rg_ie': rgIe,
      if (matricula != null) 'matricula': matricula,
      if (dataCadastro != null) 'data_cadastro': dataCadastro,
      if (dataAdmissao != null) 'data_admissao': dataAdmissao,
      if (dataDemissao != null) 'data_demissao': dataDemissao,
      if (ctpsNumero != null) 'ctps_numero': ctpsNumero,
      if (ctpsSerie != null) 'ctps_serie': ctpsSerie,
      if (ctpsDataExpedicao != null) 'ctps_data_expedicao': ctpsDataExpedicao,
      if (ctpsUf != null) 'ctps_uf': ctpsUf,
      if (observacao != null) 'observacao': observacao,
      if (logradouro != null) 'logradouro': logradouro,
      if (numero != null) 'numero': numero,
      if (complemento != null) 'complemento': complemento,
      if (bairro != null) 'bairro': bairro,
      if (cidade != null) 'cidade': cidade,
      if (cep != null) 'cep': cep,
      if (municipioIbge != null) 'municipio_ibge': municipioIbge,
      if (uf != null) 'uf': uf,
      if (idPessoa != null) 'id_pessoa': idPessoa,
      if (idCargo != null) 'id_cargo': idCargo,
      if (idSetor != null) 'id_setor': idSetor,
      if (comissao != null) 'comissao': comissao,
      if (metaVenda != null) 'meta_venda': metaVenda,
    });
  }

  ViewPessoaVendedorsCompanion copyWith(
      {Value<int?>? id,
      Value<String?>? nome,
      Value<String?>? tipo,
      Value<String?>? email,
      Value<String?>? site,
      Value<String?>? cpfCnpj,
      Value<String?>? rgIe,
      Value<String?>? matricula,
      Value<DateTime?>? dataCadastro,
      Value<DateTime?>? dataAdmissao,
      Value<DateTime?>? dataDemissao,
      Value<String?>? ctpsNumero,
      Value<String?>? ctpsSerie,
      Value<DateTime?>? ctpsDataExpedicao,
      Value<String?>? ctpsUf,
      Value<String?>? observacao,
      Value<String?>? logradouro,
      Value<String?>? numero,
      Value<String?>? complemento,
      Value<String?>? bairro,
      Value<String?>? cidade,
      Value<String?>? cep,
      Value<String?>? municipioIbge,
      Value<String?>? uf,
      Value<int?>? idPessoa,
      Value<int?>? idCargo,
      Value<int?>? idSetor,
      Value<double?>? comissao,
      Value<double?>? metaVenda}) {
    return ViewPessoaVendedorsCompanion(
      id: id ?? this.id,
      nome: nome ?? this.nome,
      tipo: tipo ?? this.tipo,
      email: email ?? this.email,
      site: site ?? this.site,
      cpfCnpj: cpfCnpj ?? this.cpfCnpj,
      rgIe: rgIe ?? this.rgIe,
      matricula: matricula ?? this.matricula,
      dataCadastro: dataCadastro ?? this.dataCadastro,
      dataAdmissao: dataAdmissao ?? this.dataAdmissao,
      dataDemissao: dataDemissao ?? this.dataDemissao,
      ctpsNumero: ctpsNumero ?? this.ctpsNumero,
      ctpsSerie: ctpsSerie ?? this.ctpsSerie,
      ctpsDataExpedicao: ctpsDataExpedicao ?? this.ctpsDataExpedicao,
      ctpsUf: ctpsUf ?? this.ctpsUf,
      observacao: observacao ?? this.observacao,
      logradouro: logradouro ?? this.logradouro,
      numero: numero ?? this.numero,
      complemento: complemento ?? this.complemento,
      bairro: bairro ?? this.bairro,
      cidade: cidade ?? this.cidade,
      cep: cep ?? this.cep,
      municipioIbge: municipioIbge ?? this.municipioIbge,
      uf: uf ?? this.uf,
      idPessoa: idPessoa ?? this.idPessoa,
      idCargo: idCargo ?? this.idCargo,
      idSetor: idSetor ?? this.idSetor,
      comissao: comissao ?? this.comissao,
      metaVenda: metaVenda ?? this.metaVenda,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (nome.present) {
      map['nome'] = Variable<String>(nome.value);
    }
    if (tipo.present) {
      map['tipo'] = Variable<String>(tipo.value);
    }
    if (email.present) {
      map['email'] = Variable<String>(email.value);
    }
    if (site.present) {
      map['site'] = Variable<String>(site.value);
    }
    if (cpfCnpj.present) {
      map['cpf_cnpj'] = Variable<String>(cpfCnpj.value);
    }
    if (rgIe.present) {
      map['rg_ie'] = Variable<String>(rgIe.value);
    }
    if (matricula.present) {
      map['matricula'] = Variable<String>(matricula.value);
    }
    if (dataCadastro.present) {
      map['data_cadastro'] = Variable<DateTime>(dataCadastro.value);
    }
    if (dataAdmissao.present) {
      map['data_admissao'] = Variable<DateTime>(dataAdmissao.value);
    }
    if (dataDemissao.present) {
      map['data_demissao'] = Variable<DateTime>(dataDemissao.value);
    }
    if (ctpsNumero.present) {
      map['ctps_numero'] = Variable<String>(ctpsNumero.value);
    }
    if (ctpsSerie.present) {
      map['ctps_serie'] = Variable<String>(ctpsSerie.value);
    }
    if (ctpsDataExpedicao.present) {
      map['ctps_data_expedicao'] = Variable<DateTime>(ctpsDataExpedicao.value);
    }
    if (ctpsUf.present) {
      map['ctps_uf'] = Variable<String>(ctpsUf.value);
    }
    if (observacao.present) {
      map['observacao'] = Variable<String>(observacao.value);
    }
    if (logradouro.present) {
      map['logradouro'] = Variable<String>(logradouro.value);
    }
    if (numero.present) {
      map['numero'] = Variable<String>(numero.value);
    }
    if (complemento.present) {
      map['complemento'] = Variable<String>(complemento.value);
    }
    if (bairro.present) {
      map['bairro'] = Variable<String>(bairro.value);
    }
    if (cidade.present) {
      map['cidade'] = Variable<String>(cidade.value);
    }
    if (cep.present) {
      map['cep'] = Variable<String>(cep.value);
    }
    if (municipioIbge.present) {
      map['municipio_ibge'] = Variable<String>(municipioIbge.value);
    }
    if (uf.present) {
      map['uf'] = Variable<String>(uf.value);
    }
    if (idPessoa.present) {
      map['id_pessoa'] = Variable<int>(idPessoa.value);
    }
    if (idCargo.present) {
      map['id_cargo'] = Variable<int>(idCargo.value);
    }
    if (idSetor.present) {
      map['id_setor'] = Variable<int>(idSetor.value);
    }
    if (comissao.present) {
      map['comissao'] = Variable<double>(comissao.value);
    }
    if (metaVenda.present) {
      map['meta_venda'] = Variable<double>(metaVenda.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('ViewPessoaVendedorsCompanion(')
          ..write('id: $id, ')
          ..write('nome: $nome, ')
          ..write('tipo: $tipo, ')
          ..write('email: $email, ')
          ..write('site: $site, ')
          ..write('cpfCnpj: $cpfCnpj, ')
          ..write('rgIe: $rgIe, ')
          ..write('matricula: $matricula, ')
          ..write('dataCadastro: $dataCadastro, ')
          ..write('dataAdmissao: $dataAdmissao, ')
          ..write('dataDemissao: $dataDemissao, ')
          ..write('ctpsNumero: $ctpsNumero, ')
          ..write('ctpsSerie: $ctpsSerie, ')
          ..write('ctpsDataExpedicao: $ctpsDataExpedicao, ')
          ..write('ctpsUf: $ctpsUf, ')
          ..write('observacao: $observacao, ')
          ..write('logradouro: $logradouro, ')
          ..write('numero: $numero, ')
          ..write('complemento: $complemento, ')
          ..write('bairro: $bairro, ')
          ..write('cidade: $cidade, ')
          ..write('cep: $cep, ')
          ..write('municipioIbge: $municipioIbge, ')
          ..write('uf: $uf, ')
          ..write('idPessoa: $idPessoa, ')
          ..write('idCargo: $idCargo, ')
          ..write('idSetor: $idSetor, ')
          ..write('comissao: $comissao, ')
          ..write('metaVenda: $metaVenda')
          ..write(')'))
        .toString();
  }
}

class $ViewPessoaTransportadorasTable extends ViewPessoaTransportadoras
    with TableInfo<$ViewPessoaTransportadorasTable, ViewPessoaTransportadora> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $ViewPessoaTransportadorasTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
      'id', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _nomeMeta = const VerificationMeta('nome');
  @override
  late final GeneratedColumn<String> nome = GeneratedColumn<String>(
      'nome', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 450),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _tipoMeta = const VerificationMeta('tipo');
  @override
  late final GeneratedColumn<String> tipo = GeneratedColumn<String>(
      'tipo', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 3),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _emailMeta = const VerificationMeta('email');
  @override
  late final GeneratedColumn<String> email = GeneratedColumn<String>(
      'email', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 750),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _siteMeta = const VerificationMeta('site');
  @override
  late final GeneratedColumn<String> site = GeneratedColumn<String>(
      'site', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 450),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _cpfCnpjMeta =
      const VerificationMeta('cpfCnpj');
  @override
  late final GeneratedColumn<String> cpfCnpj = GeneratedColumn<String>(
      'cpf_cnpj', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 20),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _rgIeMeta = const VerificationMeta('rgIe');
  @override
  late final GeneratedColumn<String> rgIe = GeneratedColumn<String>(
      'rg_ie', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 20),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _dataCadastroMeta =
      const VerificationMeta('dataCadastro');
  @override
  late final GeneratedColumn<DateTime> dataCadastro = GeneratedColumn<DateTime>(
      'data_cadastro', aliasedName, true,
      type: DriftSqlType.dateTime, requiredDuringInsert: false);
  static const VerificationMeta _observacaoMeta =
      const VerificationMeta('observacao');
  @override
  late final GeneratedColumn<String> observacao = GeneratedColumn<String>(
      'observacao', aliasedName, true,
      type: DriftSqlType.string, requiredDuringInsert: false);
  static const VerificationMeta _idPessoaMeta =
      const VerificationMeta('idPessoa');
  @override
  late final GeneratedColumn<int> idPessoa = GeneratedColumn<int>(
      'id_pessoa', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  @override
  List<GeneratedColumn> get $columns => [
        id,
        nome,
        tipo,
        email,
        site,
        cpfCnpj,
        rgIe,
        dataCadastro,
        observacao,
        idPessoa
      ];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'view_pessoa_transportadora';
  @override
  VerificationContext validateIntegrity(
      Insertable<ViewPessoaTransportadora> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('nome')) {
      context.handle(
          _nomeMeta, nome.isAcceptableOrUnknown(data['nome']!, _nomeMeta));
    }
    if (data.containsKey('tipo')) {
      context.handle(
          _tipoMeta, tipo.isAcceptableOrUnknown(data['tipo']!, _tipoMeta));
    }
    if (data.containsKey('email')) {
      context.handle(
          _emailMeta, email.isAcceptableOrUnknown(data['email']!, _emailMeta));
    }
    if (data.containsKey('site')) {
      context.handle(
          _siteMeta, site.isAcceptableOrUnknown(data['site']!, _siteMeta));
    }
    if (data.containsKey('cpf_cnpj')) {
      context.handle(_cpfCnpjMeta,
          cpfCnpj.isAcceptableOrUnknown(data['cpf_cnpj']!, _cpfCnpjMeta));
    }
    if (data.containsKey('rg_ie')) {
      context.handle(
          _rgIeMeta, rgIe.isAcceptableOrUnknown(data['rg_ie']!, _rgIeMeta));
    }
    if (data.containsKey('data_cadastro')) {
      context.handle(
          _dataCadastroMeta,
          dataCadastro.isAcceptableOrUnknown(
              data['data_cadastro']!, _dataCadastroMeta));
    }
    if (data.containsKey('observacao')) {
      context.handle(
          _observacaoMeta,
          observacao.isAcceptableOrUnknown(
              data['observacao']!, _observacaoMeta));
    }
    if (data.containsKey('id_pessoa')) {
      context.handle(_idPessoaMeta,
          idPessoa.isAcceptableOrUnknown(data['id_pessoa']!, _idPessoaMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  ViewPessoaTransportadora map(Map<String, dynamic> data,
      {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return ViewPessoaTransportadora(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id']),
      nome: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}nome']),
      tipo: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}tipo']),
      email: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}email']),
      site: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}site']),
      cpfCnpj: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}cpf_cnpj']),
      rgIe: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}rg_ie']),
      dataCadastro: attachedDatabase.typeMapping
          .read(DriftSqlType.dateTime, data['${effectivePrefix}data_cadastro']),
      observacao: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}observacao']),
      idPessoa: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id_pessoa']),
    );
  }

  @override
  $ViewPessoaTransportadorasTable createAlias(String alias) {
    return $ViewPessoaTransportadorasTable(attachedDatabase, alias);
  }
}

class ViewPessoaTransportadora extends DataClass
    implements Insertable<ViewPessoaTransportadora> {
  final int? id;
  final String? nome;
  final String? tipo;
  final String? email;
  final String? site;
  final String? cpfCnpj;
  final String? rgIe;
  final DateTime? dataCadastro;
  final String? observacao;
  final int? idPessoa;
  const ViewPessoaTransportadora(
      {this.id,
      this.nome,
      this.tipo,
      this.email,
      this.site,
      this.cpfCnpj,
      this.rgIe,
      this.dataCadastro,
      this.observacao,
      this.idPessoa});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || nome != null) {
      map['nome'] = Variable<String>(nome);
    }
    if (!nullToAbsent || tipo != null) {
      map['tipo'] = Variable<String>(tipo);
    }
    if (!nullToAbsent || email != null) {
      map['email'] = Variable<String>(email);
    }
    if (!nullToAbsent || site != null) {
      map['site'] = Variable<String>(site);
    }
    if (!nullToAbsent || cpfCnpj != null) {
      map['cpf_cnpj'] = Variable<String>(cpfCnpj);
    }
    if (!nullToAbsent || rgIe != null) {
      map['rg_ie'] = Variable<String>(rgIe);
    }
    if (!nullToAbsent || dataCadastro != null) {
      map['data_cadastro'] = Variable<DateTime>(dataCadastro);
    }
    if (!nullToAbsent || observacao != null) {
      map['observacao'] = Variable<String>(observacao);
    }
    if (!nullToAbsent || idPessoa != null) {
      map['id_pessoa'] = Variable<int>(idPessoa);
    }
    return map;
  }

  factory ViewPessoaTransportadora.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return ViewPessoaTransportadora(
      id: serializer.fromJson<int?>(json['id']),
      nome: serializer.fromJson<String?>(json['nome']),
      tipo: serializer.fromJson<String?>(json['tipo']),
      email: serializer.fromJson<String?>(json['email']),
      site: serializer.fromJson<String?>(json['site']),
      cpfCnpj: serializer.fromJson<String?>(json['cpfCnpj']),
      rgIe: serializer.fromJson<String?>(json['rgIe']),
      dataCadastro: serializer.fromJson<DateTime?>(json['dataCadastro']),
      observacao: serializer.fromJson<String?>(json['observacao']),
      idPessoa: serializer.fromJson<int?>(json['idPessoa']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'nome': serializer.toJson<String?>(nome),
      'tipo': serializer.toJson<String?>(tipo),
      'email': serializer.toJson<String?>(email),
      'site': serializer.toJson<String?>(site),
      'cpfCnpj': serializer.toJson<String?>(cpfCnpj),
      'rgIe': serializer.toJson<String?>(rgIe),
      'dataCadastro': serializer.toJson<DateTime?>(dataCadastro),
      'observacao': serializer.toJson<String?>(observacao),
      'idPessoa': serializer.toJson<int?>(idPessoa),
    };
  }

  ViewPessoaTransportadora copyWith(
          {Value<int?> id = const Value.absent(),
          Value<String?> nome = const Value.absent(),
          Value<String?> tipo = const Value.absent(),
          Value<String?> email = const Value.absent(),
          Value<String?> site = const Value.absent(),
          Value<String?> cpfCnpj = const Value.absent(),
          Value<String?> rgIe = const Value.absent(),
          Value<DateTime?> dataCadastro = const Value.absent(),
          Value<String?> observacao = const Value.absent(),
          Value<int?> idPessoa = const Value.absent()}) =>
      ViewPessoaTransportadora(
        id: id.present ? id.value : this.id,
        nome: nome.present ? nome.value : this.nome,
        tipo: tipo.present ? tipo.value : this.tipo,
        email: email.present ? email.value : this.email,
        site: site.present ? site.value : this.site,
        cpfCnpj: cpfCnpj.present ? cpfCnpj.value : this.cpfCnpj,
        rgIe: rgIe.present ? rgIe.value : this.rgIe,
        dataCadastro:
            dataCadastro.present ? dataCadastro.value : this.dataCadastro,
        observacao: observacao.present ? observacao.value : this.observacao,
        idPessoa: idPessoa.present ? idPessoa.value : this.idPessoa,
      );
  ViewPessoaTransportadora copyWithCompanion(
      ViewPessoaTransportadorasCompanion data) {
    return ViewPessoaTransportadora(
      id: data.id.present ? data.id.value : this.id,
      nome: data.nome.present ? data.nome.value : this.nome,
      tipo: data.tipo.present ? data.tipo.value : this.tipo,
      email: data.email.present ? data.email.value : this.email,
      site: data.site.present ? data.site.value : this.site,
      cpfCnpj: data.cpfCnpj.present ? data.cpfCnpj.value : this.cpfCnpj,
      rgIe: data.rgIe.present ? data.rgIe.value : this.rgIe,
      dataCadastro: data.dataCadastro.present
          ? data.dataCadastro.value
          : this.dataCadastro,
      observacao:
          data.observacao.present ? data.observacao.value : this.observacao,
      idPessoa: data.idPessoa.present ? data.idPessoa.value : this.idPessoa,
    );
  }

  @override
  String toString() {
    return (StringBuffer('ViewPessoaTransportadora(')
          ..write('id: $id, ')
          ..write('nome: $nome, ')
          ..write('tipo: $tipo, ')
          ..write('email: $email, ')
          ..write('site: $site, ')
          ..write('cpfCnpj: $cpfCnpj, ')
          ..write('rgIe: $rgIe, ')
          ..write('dataCadastro: $dataCadastro, ')
          ..write('observacao: $observacao, ')
          ..write('idPessoa: $idPessoa')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(id, nome, tipo, email, site, cpfCnpj, rgIe,
      dataCadastro, observacao, idPessoa);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is ViewPessoaTransportadora &&
          other.id == this.id &&
          other.nome == this.nome &&
          other.tipo == this.tipo &&
          other.email == this.email &&
          other.site == this.site &&
          other.cpfCnpj == this.cpfCnpj &&
          other.rgIe == this.rgIe &&
          other.dataCadastro == this.dataCadastro &&
          other.observacao == this.observacao &&
          other.idPessoa == this.idPessoa);
}

class ViewPessoaTransportadorasCompanion
    extends UpdateCompanion<ViewPessoaTransportadora> {
  final Value<int?> id;
  final Value<String?> nome;
  final Value<String?> tipo;
  final Value<String?> email;
  final Value<String?> site;
  final Value<String?> cpfCnpj;
  final Value<String?> rgIe;
  final Value<DateTime?> dataCadastro;
  final Value<String?> observacao;
  final Value<int?> idPessoa;
  const ViewPessoaTransportadorasCompanion({
    this.id = const Value.absent(),
    this.nome = const Value.absent(),
    this.tipo = const Value.absent(),
    this.email = const Value.absent(),
    this.site = const Value.absent(),
    this.cpfCnpj = const Value.absent(),
    this.rgIe = const Value.absent(),
    this.dataCadastro = const Value.absent(),
    this.observacao = const Value.absent(),
    this.idPessoa = const Value.absent(),
  });
  ViewPessoaTransportadorasCompanion.insert({
    this.id = const Value.absent(),
    this.nome = const Value.absent(),
    this.tipo = const Value.absent(),
    this.email = const Value.absent(),
    this.site = const Value.absent(),
    this.cpfCnpj = const Value.absent(),
    this.rgIe = const Value.absent(),
    this.dataCadastro = const Value.absent(),
    this.observacao = const Value.absent(),
    this.idPessoa = const Value.absent(),
  });
  static Insertable<ViewPessoaTransportadora> custom({
    Expression<int>? id,
    Expression<String>? nome,
    Expression<String>? tipo,
    Expression<String>? email,
    Expression<String>? site,
    Expression<String>? cpfCnpj,
    Expression<String>? rgIe,
    Expression<DateTime>? dataCadastro,
    Expression<String>? observacao,
    Expression<int>? idPessoa,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (nome != null) 'nome': nome,
      if (tipo != null) 'tipo': tipo,
      if (email != null) 'email': email,
      if (site != null) 'site': site,
      if (cpfCnpj != null) 'cpf_cnpj': cpfCnpj,
      if (rgIe != null) 'rg_ie': rgIe,
      if (dataCadastro != null) 'data_cadastro': dataCadastro,
      if (observacao != null) 'observacao': observacao,
      if (idPessoa != null) 'id_pessoa': idPessoa,
    });
  }

  ViewPessoaTransportadorasCompanion copyWith(
      {Value<int?>? id,
      Value<String?>? nome,
      Value<String?>? tipo,
      Value<String?>? email,
      Value<String?>? site,
      Value<String?>? cpfCnpj,
      Value<String?>? rgIe,
      Value<DateTime?>? dataCadastro,
      Value<String?>? observacao,
      Value<int?>? idPessoa}) {
    return ViewPessoaTransportadorasCompanion(
      id: id ?? this.id,
      nome: nome ?? this.nome,
      tipo: tipo ?? this.tipo,
      email: email ?? this.email,
      site: site ?? this.site,
      cpfCnpj: cpfCnpj ?? this.cpfCnpj,
      rgIe: rgIe ?? this.rgIe,
      dataCadastro: dataCadastro ?? this.dataCadastro,
      observacao: observacao ?? this.observacao,
      idPessoa: idPessoa ?? this.idPessoa,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (nome.present) {
      map['nome'] = Variable<String>(nome.value);
    }
    if (tipo.present) {
      map['tipo'] = Variable<String>(tipo.value);
    }
    if (email.present) {
      map['email'] = Variable<String>(email.value);
    }
    if (site.present) {
      map['site'] = Variable<String>(site.value);
    }
    if (cpfCnpj.present) {
      map['cpf_cnpj'] = Variable<String>(cpfCnpj.value);
    }
    if (rgIe.present) {
      map['rg_ie'] = Variable<String>(rgIe.value);
    }
    if (dataCadastro.present) {
      map['data_cadastro'] = Variable<DateTime>(dataCadastro.value);
    }
    if (observacao.present) {
      map['observacao'] = Variable<String>(observacao.value);
    }
    if (idPessoa.present) {
      map['id_pessoa'] = Variable<int>(idPessoa.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('ViewPessoaTransportadorasCompanion(')
          ..write('id: $id, ')
          ..write('nome: $nome, ')
          ..write('tipo: $tipo, ')
          ..write('email: $email, ')
          ..write('site: $site, ')
          ..write('cpfCnpj: $cpfCnpj, ')
          ..write('rgIe: $rgIe, ')
          ..write('dataCadastro: $dataCadastro, ')
          ..write('observacao: $observacao, ')
          ..write('idPessoa: $idPessoa')
          ..write(')'))
        .toString();
  }
}

abstract class _$AppDatabase extends GeneratedDatabase {
  _$AppDatabase(QueryExecutor e) : super(e);
  $AppDatabaseManager get managers => $AppDatabaseManager(this);
  late final $ProdutosTable produtos = $ProdutosTable(this);
  late final $VendaOrcamentoDetalhesTable vendaOrcamentoDetalhes =
      $VendaOrcamentoDetalhesTable(this);
  late final $VendaDetalhesTable vendaDetalhes = $VendaDetalhesTable(this);
  late final $VendaCondicoesParcelassTable vendaCondicoesParcelass =
      $VendaCondicoesParcelassTable(this);
  late final $VendaFretesTable vendaFretes = $VendaFretesTable(this);
  late final $VendaComissaosTable vendaComissaos = $VendaComissaosTable(this);
  late final $ProdutoGruposTable produtoGrupos = $ProdutoGruposTable(this);
  late final $ProdutoSubgruposTable produtoSubgrupos =
      $ProdutoSubgruposTable(this);
  late final $ProdutoMarcasTable produtoMarcas = $ProdutoMarcasTable(this);
  late final $ProdutoUnidadesTable produtoUnidades =
      $ProdutoUnidadesTable(this);
  late final $VendaCondicoesPagamentosTable vendaCondicoesPagamentos =
      $VendaCondicoesPagamentosTable(this);
  late final $VendaOrcamentoCabecalhosTable vendaOrcamentoCabecalhos =
      $VendaOrcamentoCabecalhosTable(this);
  late final $VendaCabecalhosTable vendaCabecalhos =
      $VendaCabecalhosTable(this);
  late final $NotaFiscalModelosTable notaFiscalModelos =
      $NotaFiscalModelosTable(this);
  late final $NotaFiscalTiposTable notaFiscalTipos =
      $NotaFiscalTiposTable(this);
  late final $ViewControleAcessosTable viewControleAcessos =
      $ViewControleAcessosTable(this);
  late final $ViewPessoaUsuariosTable viewPessoaUsuarios =
      $ViewPessoaUsuariosTable(this);
  late final $ViewPessoaClientesTable viewPessoaClientes =
      $ViewPessoaClientesTable(this);
  late final $ViewPessoaVendedorsTable viewPessoaVendedors =
      $ViewPessoaVendedorsTable(this);
  late final $ViewPessoaTransportadorasTable viewPessoaTransportadoras =
      $ViewPessoaTransportadorasTable(this);
  late final ProdutoGrupoDao produtoGrupoDao =
      ProdutoGrupoDao(this as AppDatabase);
  late final ProdutoSubgrupoDao produtoSubgrupoDao =
      ProdutoSubgrupoDao(this as AppDatabase);
  late final ProdutoMarcaDao produtoMarcaDao =
      ProdutoMarcaDao(this as AppDatabase);
  late final ProdutoUnidadeDao produtoUnidadeDao =
      ProdutoUnidadeDao(this as AppDatabase);
  late final VendaCondicoesPagamentoDao vendaCondicoesPagamentoDao =
      VendaCondicoesPagamentoDao(this as AppDatabase);
  late final VendaOrcamentoCabecalhoDao vendaOrcamentoCabecalhoDao =
      VendaOrcamentoCabecalhoDao(this as AppDatabase);
  late final VendaCabecalhoDao vendaCabecalhoDao =
      VendaCabecalhoDao(this as AppDatabase);
  late final NotaFiscalModeloDao notaFiscalModeloDao =
      NotaFiscalModeloDao(this as AppDatabase);
  late final NotaFiscalTipoDao notaFiscalTipoDao =
      NotaFiscalTipoDao(this as AppDatabase);
  late final ViewControleAcessoDao viewControleAcessoDao =
      ViewControleAcessoDao(this as AppDatabase);
  late final ViewPessoaUsuarioDao viewPessoaUsuarioDao =
      ViewPessoaUsuarioDao(this as AppDatabase);
  late final ViewPessoaClienteDao viewPessoaClienteDao =
      ViewPessoaClienteDao(this as AppDatabase);
  late final ViewPessoaVendedorDao viewPessoaVendedorDao =
      ViewPessoaVendedorDao(this as AppDatabase);
  late final ViewPessoaTransportadoraDao viewPessoaTransportadoraDao =
      ViewPessoaTransportadoraDao(this as AppDatabase);
  @override
  Iterable<TableInfo<Table, Object?>> get allTables =>
      allSchemaEntities.whereType<TableInfo<Table, Object?>>();
  @override
  List<DatabaseSchemaEntity> get allSchemaEntities => [
        produtos,
        vendaOrcamentoDetalhes,
        vendaDetalhes,
        vendaCondicoesParcelass,
        vendaFretes,
        vendaComissaos,
        produtoGrupos,
        produtoSubgrupos,
        produtoMarcas,
        produtoUnidades,
        vendaCondicoesPagamentos,
        vendaOrcamentoCabecalhos,
        vendaCabecalhos,
        notaFiscalModelos,
        notaFiscalTipos,
        viewControleAcessos,
        viewPessoaUsuarios,
        viewPessoaClientes,
        viewPessoaVendedors,
        viewPessoaTransportadoras
      ];
}

typedef $$ProdutosTableCreateCompanionBuilder = ProdutosCompanion Function({
  Value<int?> id,
  Value<int?> idProdutoSubgrupo,
  Value<int?> idProdutoMarca,
  Value<int?> idProdutoUnidade,
  Value<int?> idTributIcmsCustomCab,
  Value<int?> idTributGrupoTributario,
  Value<String?> nome,
  Value<String?> descricao,
  Value<String?> gtin,
  Value<String?> codigoInterno,
  Value<double?> valorCompra,
  Value<double?> valorVenda,
  Value<String?> codigoNcm,
  Value<double?> estoqueMinimo,
  Value<double?> estoqueMaximo,
  Value<double?> quantidadeEstoque,
  Value<DateTime?> dataCadastro,
});
typedef $$ProdutosTableUpdateCompanionBuilder = ProdutosCompanion Function({
  Value<int?> id,
  Value<int?> idProdutoSubgrupo,
  Value<int?> idProdutoMarca,
  Value<int?> idProdutoUnidade,
  Value<int?> idTributIcmsCustomCab,
  Value<int?> idTributGrupoTributario,
  Value<String?> nome,
  Value<String?> descricao,
  Value<String?> gtin,
  Value<String?> codigoInterno,
  Value<double?> valorCompra,
  Value<double?> valorVenda,
  Value<String?> codigoNcm,
  Value<double?> estoqueMinimo,
  Value<double?> estoqueMaximo,
  Value<double?> quantidadeEstoque,
  Value<DateTime?> dataCadastro,
});

class $$ProdutosTableTableManager extends RootTableManager<
    _$AppDatabase,
    $ProdutosTable,
    Produto,
    $$ProdutosTableFilterComposer,
    $$ProdutosTableOrderingComposer,
    $$ProdutosTableCreateCompanionBuilder,
    $$ProdutosTableUpdateCompanionBuilder> {
  $$ProdutosTableTableManager(_$AppDatabase db, $ProdutosTable table)
      : super(TableManagerState(
          db: db,
          table: table,
          filteringComposer:
              $$ProdutosTableFilterComposer(ComposerState(db, table)),
          orderingComposer:
              $$ProdutosTableOrderingComposer(ComposerState(db, table)),
          updateCompanionCallback: ({
            Value<int?> id = const Value.absent(),
            Value<int?> idProdutoSubgrupo = const Value.absent(),
            Value<int?> idProdutoMarca = const Value.absent(),
            Value<int?> idProdutoUnidade = const Value.absent(),
            Value<int?> idTributIcmsCustomCab = const Value.absent(),
            Value<int?> idTributGrupoTributario = const Value.absent(),
            Value<String?> nome = const Value.absent(),
            Value<String?> descricao = const Value.absent(),
            Value<String?> gtin = const Value.absent(),
            Value<String?> codigoInterno = const Value.absent(),
            Value<double?> valorCompra = const Value.absent(),
            Value<double?> valorVenda = const Value.absent(),
            Value<String?> codigoNcm = const Value.absent(),
            Value<double?> estoqueMinimo = const Value.absent(),
            Value<double?> estoqueMaximo = const Value.absent(),
            Value<double?> quantidadeEstoque = const Value.absent(),
            Value<DateTime?> dataCadastro = const Value.absent(),
          }) =>
              ProdutosCompanion(
            id: id,
            idProdutoSubgrupo: idProdutoSubgrupo,
            idProdutoMarca: idProdutoMarca,
            idProdutoUnidade: idProdutoUnidade,
            idTributIcmsCustomCab: idTributIcmsCustomCab,
            idTributGrupoTributario: idTributGrupoTributario,
            nome: nome,
            descricao: descricao,
            gtin: gtin,
            codigoInterno: codigoInterno,
            valorCompra: valorCompra,
            valorVenda: valorVenda,
            codigoNcm: codigoNcm,
            estoqueMinimo: estoqueMinimo,
            estoqueMaximo: estoqueMaximo,
            quantidadeEstoque: quantidadeEstoque,
            dataCadastro: dataCadastro,
          ),
          createCompanionCallback: ({
            Value<int?> id = const Value.absent(),
            Value<int?> idProdutoSubgrupo = const Value.absent(),
            Value<int?> idProdutoMarca = const Value.absent(),
            Value<int?> idProdutoUnidade = const Value.absent(),
            Value<int?> idTributIcmsCustomCab = const Value.absent(),
            Value<int?> idTributGrupoTributario = const Value.absent(),
            Value<String?> nome = const Value.absent(),
            Value<String?> descricao = const Value.absent(),
            Value<String?> gtin = const Value.absent(),
            Value<String?> codigoInterno = const Value.absent(),
            Value<double?> valorCompra = const Value.absent(),
            Value<double?> valorVenda = const Value.absent(),
            Value<String?> codigoNcm = const Value.absent(),
            Value<double?> estoqueMinimo = const Value.absent(),
            Value<double?> estoqueMaximo = const Value.absent(),
            Value<double?> quantidadeEstoque = const Value.absent(),
            Value<DateTime?> dataCadastro = const Value.absent(),
          }) =>
              ProdutosCompanion.insert(
            id: id,
            idProdutoSubgrupo: idProdutoSubgrupo,
            idProdutoMarca: idProdutoMarca,
            idProdutoUnidade: idProdutoUnidade,
            idTributIcmsCustomCab: idTributIcmsCustomCab,
            idTributGrupoTributario: idTributGrupoTributario,
            nome: nome,
            descricao: descricao,
            gtin: gtin,
            codigoInterno: codigoInterno,
            valorCompra: valorCompra,
            valorVenda: valorVenda,
            codigoNcm: codigoNcm,
            estoqueMinimo: estoqueMinimo,
            estoqueMaximo: estoqueMaximo,
            quantidadeEstoque: quantidadeEstoque,
            dataCadastro: dataCadastro,
          ),
        ));
}

class $$ProdutosTableFilterComposer
    extends FilterComposer<_$AppDatabase, $ProdutosTable> {
  $$ProdutosTableFilterComposer(super.$state);
  ColumnFilters<int> get id => $state.composableBuilder(
      column: $state.table.id,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<int> get idProdutoSubgrupo => $state.composableBuilder(
      column: $state.table.idProdutoSubgrupo,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<int> get idProdutoMarca => $state.composableBuilder(
      column: $state.table.idProdutoMarca,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<int> get idProdutoUnidade => $state.composableBuilder(
      column: $state.table.idProdutoUnidade,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<int> get idTributIcmsCustomCab => $state.composableBuilder(
      column: $state.table.idTributIcmsCustomCab,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<int> get idTributGrupoTributario => $state.composableBuilder(
      column: $state.table.idTributGrupoTributario,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get nome => $state.composableBuilder(
      column: $state.table.nome,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get descricao => $state.composableBuilder(
      column: $state.table.descricao,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get gtin => $state.composableBuilder(
      column: $state.table.gtin,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get codigoInterno => $state.composableBuilder(
      column: $state.table.codigoInterno,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<double> get valorCompra => $state.composableBuilder(
      column: $state.table.valorCompra,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<double> get valorVenda => $state.composableBuilder(
      column: $state.table.valorVenda,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get codigoNcm => $state.composableBuilder(
      column: $state.table.codigoNcm,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<double> get estoqueMinimo => $state.composableBuilder(
      column: $state.table.estoqueMinimo,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<double> get estoqueMaximo => $state.composableBuilder(
      column: $state.table.estoqueMaximo,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<double> get quantidadeEstoque => $state.composableBuilder(
      column: $state.table.quantidadeEstoque,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<DateTime> get dataCadastro => $state.composableBuilder(
      column: $state.table.dataCadastro,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));
}

class $$ProdutosTableOrderingComposer
    extends OrderingComposer<_$AppDatabase, $ProdutosTable> {
  $$ProdutosTableOrderingComposer(super.$state);
  ColumnOrderings<int> get id => $state.composableBuilder(
      column: $state.table.id,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<int> get idProdutoSubgrupo => $state.composableBuilder(
      column: $state.table.idProdutoSubgrupo,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<int> get idProdutoMarca => $state.composableBuilder(
      column: $state.table.idProdutoMarca,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<int> get idProdutoUnidade => $state.composableBuilder(
      column: $state.table.idProdutoUnidade,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<int> get idTributIcmsCustomCab => $state.composableBuilder(
      column: $state.table.idTributIcmsCustomCab,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<int> get idTributGrupoTributario => $state.composableBuilder(
      column: $state.table.idTributGrupoTributario,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get nome => $state.composableBuilder(
      column: $state.table.nome,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get descricao => $state.composableBuilder(
      column: $state.table.descricao,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get gtin => $state.composableBuilder(
      column: $state.table.gtin,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get codigoInterno => $state.composableBuilder(
      column: $state.table.codigoInterno,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<double> get valorCompra => $state.composableBuilder(
      column: $state.table.valorCompra,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<double> get valorVenda => $state.composableBuilder(
      column: $state.table.valorVenda,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get codigoNcm => $state.composableBuilder(
      column: $state.table.codigoNcm,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<double> get estoqueMinimo => $state.composableBuilder(
      column: $state.table.estoqueMinimo,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<double> get estoqueMaximo => $state.composableBuilder(
      column: $state.table.estoqueMaximo,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<double> get quantidadeEstoque => $state.composableBuilder(
      column: $state.table.quantidadeEstoque,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<DateTime> get dataCadastro => $state.composableBuilder(
      column: $state.table.dataCadastro,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));
}

typedef $$VendaOrcamentoDetalhesTableCreateCompanionBuilder
    = VendaOrcamentoDetalhesCompanion Function({
  Value<int?> id,
  Value<int?> idVendaOrcamentoCabecalho,
  Value<int?> idProduto,
  Value<double?> quantidade,
  Value<double?> valorUnitario,
  Value<double?> valorSubtotal,
  Value<double?> taxaDesconto,
  Value<double?> valorDesconto,
  Value<double?> valorTotal,
});
typedef $$VendaOrcamentoDetalhesTableUpdateCompanionBuilder
    = VendaOrcamentoDetalhesCompanion Function({
  Value<int?> id,
  Value<int?> idVendaOrcamentoCabecalho,
  Value<int?> idProduto,
  Value<double?> quantidade,
  Value<double?> valorUnitario,
  Value<double?> valorSubtotal,
  Value<double?> taxaDesconto,
  Value<double?> valorDesconto,
  Value<double?> valorTotal,
});

class $$VendaOrcamentoDetalhesTableTableManager extends RootTableManager<
    _$AppDatabase,
    $VendaOrcamentoDetalhesTable,
    VendaOrcamentoDetalhe,
    $$VendaOrcamentoDetalhesTableFilterComposer,
    $$VendaOrcamentoDetalhesTableOrderingComposer,
    $$VendaOrcamentoDetalhesTableCreateCompanionBuilder,
    $$VendaOrcamentoDetalhesTableUpdateCompanionBuilder> {
  $$VendaOrcamentoDetalhesTableTableManager(
      _$AppDatabase db, $VendaOrcamentoDetalhesTable table)
      : super(TableManagerState(
          db: db,
          table: table,
          filteringComposer: $$VendaOrcamentoDetalhesTableFilterComposer(
              ComposerState(db, table)),
          orderingComposer: $$VendaOrcamentoDetalhesTableOrderingComposer(
              ComposerState(db, table)),
          updateCompanionCallback: ({
            Value<int?> id = const Value.absent(),
            Value<int?> idVendaOrcamentoCabecalho = const Value.absent(),
            Value<int?> idProduto = const Value.absent(),
            Value<double?> quantidade = const Value.absent(),
            Value<double?> valorUnitario = const Value.absent(),
            Value<double?> valorSubtotal = const Value.absent(),
            Value<double?> taxaDesconto = const Value.absent(),
            Value<double?> valorDesconto = const Value.absent(),
            Value<double?> valorTotal = const Value.absent(),
          }) =>
              VendaOrcamentoDetalhesCompanion(
            id: id,
            idVendaOrcamentoCabecalho: idVendaOrcamentoCabecalho,
            idProduto: idProduto,
            quantidade: quantidade,
            valorUnitario: valorUnitario,
            valorSubtotal: valorSubtotal,
            taxaDesconto: taxaDesconto,
            valorDesconto: valorDesconto,
            valorTotal: valorTotal,
          ),
          createCompanionCallback: ({
            Value<int?> id = const Value.absent(),
            Value<int?> idVendaOrcamentoCabecalho = const Value.absent(),
            Value<int?> idProduto = const Value.absent(),
            Value<double?> quantidade = const Value.absent(),
            Value<double?> valorUnitario = const Value.absent(),
            Value<double?> valorSubtotal = const Value.absent(),
            Value<double?> taxaDesconto = const Value.absent(),
            Value<double?> valorDesconto = const Value.absent(),
            Value<double?> valorTotal = const Value.absent(),
          }) =>
              VendaOrcamentoDetalhesCompanion.insert(
            id: id,
            idVendaOrcamentoCabecalho: idVendaOrcamentoCabecalho,
            idProduto: idProduto,
            quantidade: quantidade,
            valorUnitario: valorUnitario,
            valorSubtotal: valorSubtotal,
            taxaDesconto: taxaDesconto,
            valorDesconto: valorDesconto,
            valorTotal: valorTotal,
          ),
        ));
}

class $$VendaOrcamentoDetalhesTableFilterComposer
    extends FilterComposer<_$AppDatabase, $VendaOrcamentoDetalhesTable> {
  $$VendaOrcamentoDetalhesTableFilterComposer(super.$state);
  ColumnFilters<int> get id => $state.composableBuilder(
      column: $state.table.id,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<int> get idVendaOrcamentoCabecalho => $state.composableBuilder(
      column: $state.table.idVendaOrcamentoCabecalho,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<int> get idProduto => $state.composableBuilder(
      column: $state.table.idProduto,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<double> get quantidade => $state.composableBuilder(
      column: $state.table.quantidade,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<double> get valorUnitario => $state.composableBuilder(
      column: $state.table.valorUnitario,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<double> get valorSubtotal => $state.composableBuilder(
      column: $state.table.valorSubtotal,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<double> get taxaDesconto => $state.composableBuilder(
      column: $state.table.taxaDesconto,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<double> get valorDesconto => $state.composableBuilder(
      column: $state.table.valorDesconto,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<double> get valorTotal => $state.composableBuilder(
      column: $state.table.valorTotal,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));
}

class $$VendaOrcamentoDetalhesTableOrderingComposer
    extends OrderingComposer<_$AppDatabase, $VendaOrcamentoDetalhesTable> {
  $$VendaOrcamentoDetalhesTableOrderingComposer(super.$state);
  ColumnOrderings<int> get id => $state.composableBuilder(
      column: $state.table.id,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<int> get idVendaOrcamentoCabecalho =>
      $state.composableBuilder(
          column: $state.table.idVendaOrcamentoCabecalho,
          builder: (column, joinBuilders) =>
              ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<int> get idProduto => $state.composableBuilder(
      column: $state.table.idProduto,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<double> get quantidade => $state.composableBuilder(
      column: $state.table.quantidade,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<double> get valorUnitario => $state.composableBuilder(
      column: $state.table.valorUnitario,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<double> get valorSubtotal => $state.composableBuilder(
      column: $state.table.valorSubtotal,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<double> get taxaDesconto => $state.composableBuilder(
      column: $state.table.taxaDesconto,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<double> get valorDesconto => $state.composableBuilder(
      column: $state.table.valorDesconto,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<double> get valorTotal => $state.composableBuilder(
      column: $state.table.valorTotal,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));
}

typedef $$VendaDetalhesTableCreateCompanionBuilder = VendaDetalhesCompanion
    Function({
  Value<int?> id,
  Value<int?> idVendaCabecalho,
  Value<int?> idProduto,
  Value<double?> quantidade,
  Value<double?> valorUnitario,
  Value<double?> valorSubtotal,
  Value<double?> taxaDesconto,
  Value<double?> valorDesconto,
  Value<double?> valorTotal,
});
typedef $$VendaDetalhesTableUpdateCompanionBuilder = VendaDetalhesCompanion
    Function({
  Value<int?> id,
  Value<int?> idVendaCabecalho,
  Value<int?> idProduto,
  Value<double?> quantidade,
  Value<double?> valorUnitario,
  Value<double?> valorSubtotal,
  Value<double?> taxaDesconto,
  Value<double?> valorDesconto,
  Value<double?> valorTotal,
});

class $$VendaDetalhesTableTableManager extends RootTableManager<
    _$AppDatabase,
    $VendaDetalhesTable,
    VendaDetalhe,
    $$VendaDetalhesTableFilterComposer,
    $$VendaDetalhesTableOrderingComposer,
    $$VendaDetalhesTableCreateCompanionBuilder,
    $$VendaDetalhesTableUpdateCompanionBuilder> {
  $$VendaDetalhesTableTableManager(_$AppDatabase db, $VendaDetalhesTable table)
      : super(TableManagerState(
          db: db,
          table: table,
          filteringComposer:
              $$VendaDetalhesTableFilterComposer(ComposerState(db, table)),
          orderingComposer:
              $$VendaDetalhesTableOrderingComposer(ComposerState(db, table)),
          updateCompanionCallback: ({
            Value<int?> id = const Value.absent(),
            Value<int?> idVendaCabecalho = const Value.absent(),
            Value<int?> idProduto = const Value.absent(),
            Value<double?> quantidade = const Value.absent(),
            Value<double?> valorUnitario = const Value.absent(),
            Value<double?> valorSubtotal = const Value.absent(),
            Value<double?> taxaDesconto = const Value.absent(),
            Value<double?> valorDesconto = const Value.absent(),
            Value<double?> valorTotal = const Value.absent(),
          }) =>
              VendaDetalhesCompanion(
            id: id,
            idVendaCabecalho: idVendaCabecalho,
            idProduto: idProduto,
            quantidade: quantidade,
            valorUnitario: valorUnitario,
            valorSubtotal: valorSubtotal,
            taxaDesconto: taxaDesconto,
            valorDesconto: valorDesconto,
            valorTotal: valorTotal,
          ),
          createCompanionCallback: ({
            Value<int?> id = const Value.absent(),
            Value<int?> idVendaCabecalho = const Value.absent(),
            Value<int?> idProduto = const Value.absent(),
            Value<double?> quantidade = const Value.absent(),
            Value<double?> valorUnitario = const Value.absent(),
            Value<double?> valorSubtotal = const Value.absent(),
            Value<double?> taxaDesconto = const Value.absent(),
            Value<double?> valorDesconto = const Value.absent(),
            Value<double?> valorTotal = const Value.absent(),
          }) =>
              VendaDetalhesCompanion.insert(
            id: id,
            idVendaCabecalho: idVendaCabecalho,
            idProduto: idProduto,
            quantidade: quantidade,
            valorUnitario: valorUnitario,
            valorSubtotal: valorSubtotal,
            taxaDesconto: taxaDesconto,
            valorDesconto: valorDesconto,
            valorTotal: valorTotal,
          ),
        ));
}

class $$VendaDetalhesTableFilterComposer
    extends FilterComposer<_$AppDatabase, $VendaDetalhesTable> {
  $$VendaDetalhesTableFilterComposer(super.$state);
  ColumnFilters<int> get id => $state.composableBuilder(
      column: $state.table.id,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<int> get idVendaCabecalho => $state.composableBuilder(
      column: $state.table.idVendaCabecalho,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<int> get idProduto => $state.composableBuilder(
      column: $state.table.idProduto,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<double> get quantidade => $state.composableBuilder(
      column: $state.table.quantidade,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<double> get valorUnitario => $state.composableBuilder(
      column: $state.table.valorUnitario,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<double> get valorSubtotal => $state.composableBuilder(
      column: $state.table.valorSubtotal,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<double> get taxaDesconto => $state.composableBuilder(
      column: $state.table.taxaDesconto,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<double> get valorDesconto => $state.composableBuilder(
      column: $state.table.valorDesconto,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<double> get valorTotal => $state.composableBuilder(
      column: $state.table.valorTotal,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));
}

class $$VendaDetalhesTableOrderingComposer
    extends OrderingComposer<_$AppDatabase, $VendaDetalhesTable> {
  $$VendaDetalhesTableOrderingComposer(super.$state);
  ColumnOrderings<int> get id => $state.composableBuilder(
      column: $state.table.id,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<int> get idVendaCabecalho => $state.composableBuilder(
      column: $state.table.idVendaCabecalho,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<int> get idProduto => $state.composableBuilder(
      column: $state.table.idProduto,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<double> get quantidade => $state.composableBuilder(
      column: $state.table.quantidade,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<double> get valorUnitario => $state.composableBuilder(
      column: $state.table.valorUnitario,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<double> get valorSubtotal => $state.composableBuilder(
      column: $state.table.valorSubtotal,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<double> get taxaDesconto => $state.composableBuilder(
      column: $state.table.taxaDesconto,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<double> get valorDesconto => $state.composableBuilder(
      column: $state.table.valorDesconto,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<double> get valorTotal => $state.composableBuilder(
      column: $state.table.valorTotal,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));
}

typedef $$VendaCondicoesParcelassTableCreateCompanionBuilder
    = VendaCondicoesParcelassCompanion Function({
  Value<int?> id,
  Value<int?> idVendaCondicoesPagamento,
  Value<int?> parcela,
  Value<int?> dias,
  Value<double?> taxa,
});
typedef $$VendaCondicoesParcelassTableUpdateCompanionBuilder
    = VendaCondicoesParcelassCompanion Function({
  Value<int?> id,
  Value<int?> idVendaCondicoesPagamento,
  Value<int?> parcela,
  Value<int?> dias,
  Value<double?> taxa,
});

class $$VendaCondicoesParcelassTableTableManager extends RootTableManager<
    _$AppDatabase,
    $VendaCondicoesParcelassTable,
    VendaCondicoesParcelas,
    $$VendaCondicoesParcelassTableFilterComposer,
    $$VendaCondicoesParcelassTableOrderingComposer,
    $$VendaCondicoesParcelassTableCreateCompanionBuilder,
    $$VendaCondicoesParcelassTableUpdateCompanionBuilder> {
  $$VendaCondicoesParcelassTableTableManager(
      _$AppDatabase db, $VendaCondicoesParcelassTable table)
      : super(TableManagerState(
          db: db,
          table: table,
          filteringComposer: $$VendaCondicoesParcelassTableFilterComposer(
              ComposerState(db, table)),
          orderingComposer: $$VendaCondicoesParcelassTableOrderingComposer(
              ComposerState(db, table)),
          updateCompanionCallback: ({
            Value<int?> id = const Value.absent(),
            Value<int?> idVendaCondicoesPagamento = const Value.absent(),
            Value<int?> parcela = const Value.absent(),
            Value<int?> dias = const Value.absent(),
            Value<double?> taxa = const Value.absent(),
          }) =>
              VendaCondicoesParcelassCompanion(
            id: id,
            idVendaCondicoesPagamento: idVendaCondicoesPagamento,
            parcela: parcela,
            dias: dias,
            taxa: taxa,
          ),
          createCompanionCallback: ({
            Value<int?> id = const Value.absent(),
            Value<int?> idVendaCondicoesPagamento = const Value.absent(),
            Value<int?> parcela = const Value.absent(),
            Value<int?> dias = const Value.absent(),
            Value<double?> taxa = const Value.absent(),
          }) =>
              VendaCondicoesParcelassCompanion.insert(
            id: id,
            idVendaCondicoesPagamento: idVendaCondicoesPagamento,
            parcela: parcela,
            dias: dias,
            taxa: taxa,
          ),
        ));
}

class $$VendaCondicoesParcelassTableFilterComposer
    extends FilterComposer<_$AppDatabase, $VendaCondicoesParcelassTable> {
  $$VendaCondicoesParcelassTableFilterComposer(super.$state);
  ColumnFilters<int> get id => $state.composableBuilder(
      column: $state.table.id,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<int> get idVendaCondicoesPagamento => $state.composableBuilder(
      column: $state.table.idVendaCondicoesPagamento,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<int> get parcela => $state.composableBuilder(
      column: $state.table.parcela,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<int> get dias => $state.composableBuilder(
      column: $state.table.dias,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<double> get taxa => $state.composableBuilder(
      column: $state.table.taxa,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));
}

class $$VendaCondicoesParcelassTableOrderingComposer
    extends OrderingComposer<_$AppDatabase, $VendaCondicoesParcelassTable> {
  $$VendaCondicoesParcelassTableOrderingComposer(super.$state);
  ColumnOrderings<int> get id => $state.composableBuilder(
      column: $state.table.id,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<int> get idVendaCondicoesPagamento =>
      $state.composableBuilder(
          column: $state.table.idVendaCondicoesPagamento,
          builder: (column, joinBuilders) =>
              ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<int> get parcela => $state.composableBuilder(
      column: $state.table.parcela,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<int> get dias => $state.composableBuilder(
      column: $state.table.dias,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<double> get taxa => $state.composableBuilder(
      column: $state.table.taxa,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));
}

typedef $$VendaFretesTableCreateCompanionBuilder = VendaFretesCompanion
    Function({
  Value<int?> id,
  Value<int?> idVendaCabecalho,
  Value<int?> idTransportadora,
  Value<String?> responsavel,
  Value<int?> conhecimento,
  Value<String?> placa,
  Value<String?> ufPlaca,
  Value<int?> seloFiscal,
  Value<double?> quantidadeVolume,
  Value<String?> marcaVolume,
  Value<String?> especieVolume,
  Value<double?> pesoBruto,
  Value<double?> pesoLiquido,
});
typedef $$VendaFretesTableUpdateCompanionBuilder = VendaFretesCompanion
    Function({
  Value<int?> id,
  Value<int?> idVendaCabecalho,
  Value<int?> idTransportadora,
  Value<String?> responsavel,
  Value<int?> conhecimento,
  Value<String?> placa,
  Value<String?> ufPlaca,
  Value<int?> seloFiscal,
  Value<double?> quantidadeVolume,
  Value<String?> marcaVolume,
  Value<String?> especieVolume,
  Value<double?> pesoBruto,
  Value<double?> pesoLiquido,
});

class $$VendaFretesTableTableManager extends RootTableManager<
    _$AppDatabase,
    $VendaFretesTable,
    VendaFrete,
    $$VendaFretesTableFilterComposer,
    $$VendaFretesTableOrderingComposer,
    $$VendaFretesTableCreateCompanionBuilder,
    $$VendaFretesTableUpdateCompanionBuilder> {
  $$VendaFretesTableTableManager(_$AppDatabase db, $VendaFretesTable table)
      : super(TableManagerState(
          db: db,
          table: table,
          filteringComposer:
              $$VendaFretesTableFilterComposer(ComposerState(db, table)),
          orderingComposer:
              $$VendaFretesTableOrderingComposer(ComposerState(db, table)),
          updateCompanionCallback: ({
            Value<int?> id = const Value.absent(),
            Value<int?> idVendaCabecalho = const Value.absent(),
            Value<int?> idTransportadora = const Value.absent(),
            Value<String?> responsavel = const Value.absent(),
            Value<int?> conhecimento = const Value.absent(),
            Value<String?> placa = const Value.absent(),
            Value<String?> ufPlaca = const Value.absent(),
            Value<int?> seloFiscal = const Value.absent(),
            Value<double?> quantidadeVolume = const Value.absent(),
            Value<String?> marcaVolume = const Value.absent(),
            Value<String?> especieVolume = const Value.absent(),
            Value<double?> pesoBruto = const Value.absent(),
            Value<double?> pesoLiquido = const Value.absent(),
          }) =>
              VendaFretesCompanion(
            id: id,
            idVendaCabecalho: idVendaCabecalho,
            idTransportadora: idTransportadora,
            responsavel: responsavel,
            conhecimento: conhecimento,
            placa: placa,
            ufPlaca: ufPlaca,
            seloFiscal: seloFiscal,
            quantidadeVolume: quantidadeVolume,
            marcaVolume: marcaVolume,
            especieVolume: especieVolume,
            pesoBruto: pesoBruto,
            pesoLiquido: pesoLiquido,
          ),
          createCompanionCallback: ({
            Value<int?> id = const Value.absent(),
            Value<int?> idVendaCabecalho = const Value.absent(),
            Value<int?> idTransportadora = const Value.absent(),
            Value<String?> responsavel = const Value.absent(),
            Value<int?> conhecimento = const Value.absent(),
            Value<String?> placa = const Value.absent(),
            Value<String?> ufPlaca = const Value.absent(),
            Value<int?> seloFiscal = const Value.absent(),
            Value<double?> quantidadeVolume = const Value.absent(),
            Value<String?> marcaVolume = const Value.absent(),
            Value<String?> especieVolume = const Value.absent(),
            Value<double?> pesoBruto = const Value.absent(),
            Value<double?> pesoLiquido = const Value.absent(),
          }) =>
              VendaFretesCompanion.insert(
            id: id,
            idVendaCabecalho: idVendaCabecalho,
            idTransportadora: idTransportadora,
            responsavel: responsavel,
            conhecimento: conhecimento,
            placa: placa,
            ufPlaca: ufPlaca,
            seloFiscal: seloFiscal,
            quantidadeVolume: quantidadeVolume,
            marcaVolume: marcaVolume,
            especieVolume: especieVolume,
            pesoBruto: pesoBruto,
            pesoLiquido: pesoLiquido,
          ),
        ));
}

class $$VendaFretesTableFilterComposer
    extends FilterComposer<_$AppDatabase, $VendaFretesTable> {
  $$VendaFretesTableFilterComposer(super.$state);
  ColumnFilters<int> get id => $state.composableBuilder(
      column: $state.table.id,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<int> get idVendaCabecalho => $state.composableBuilder(
      column: $state.table.idVendaCabecalho,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<int> get idTransportadora => $state.composableBuilder(
      column: $state.table.idTransportadora,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get responsavel => $state.composableBuilder(
      column: $state.table.responsavel,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<int> get conhecimento => $state.composableBuilder(
      column: $state.table.conhecimento,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get placa => $state.composableBuilder(
      column: $state.table.placa,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get ufPlaca => $state.composableBuilder(
      column: $state.table.ufPlaca,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<int> get seloFiscal => $state.composableBuilder(
      column: $state.table.seloFiscal,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<double> get quantidadeVolume => $state.composableBuilder(
      column: $state.table.quantidadeVolume,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get marcaVolume => $state.composableBuilder(
      column: $state.table.marcaVolume,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get especieVolume => $state.composableBuilder(
      column: $state.table.especieVolume,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<double> get pesoBruto => $state.composableBuilder(
      column: $state.table.pesoBruto,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<double> get pesoLiquido => $state.composableBuilder(
      column: $state.table.pesoLiquido,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));
}

class $$VendaFretesTableOrderingComposer
    extends OrderingComposer<_$AppDatabase, $VendaFretesTable> {
  $$VendaFretesTableOrderingComposer(super.$state);
  ColumnOrderings<int> get id => $state.composableBuilder(
      column: $state.table.id,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<int> get idVendaCabecalho => $state.composableBuilder(
      column: $state.table.idVendaCabecalho,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<int> get idTransportadora => $state.composableBuilder(
      column: $state.table.idTransportadora,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get responsavel => $state.composableBuilder(
      column: $state.table.responsavel,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<int> get conhecimento => $state.composableBuilder(
      column: $state.table.conhecimento,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get placa => $state.composableBuilder(
      column: $state.table.placa,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get ufPlaca => $state.composableBuilder(
      column: $state.table.ufPlaca,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<int> get seloFiscal => $state.composableBuilder(
      column: $state.table.seloFiscal,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<double> get quantidadeVolume => $state.composableBuilder(
      column: $state.table.quantidadeVolume,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get marcaVolume => $state.composableBuilder(
      column: $state.table.marcaVolume,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get especieVolume => $state.composableBuilder(
      column: $state.table.especieVolume,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<double> get pesoBruto => $state.composableBuilder(
      column: $state.table.pesoBruto,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<double> get pesoLiquido => $state.composableBuilder(
      column: $state.table.pesoLiquido,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));
}

typedef $$VendaComissaosTableCreateCompanionBuilder = VendaComissaosCompanion
    Function({
  Value<int?> id,
  Value<int?> idVendaCabecalho,
  Value<int?> idVendedor,
  Value<double?> valorVenda,
  Value<String?> tipoContabil,
  Value<double?> valorComissao,
  Value<String?> situacao,
  Value<DateTime?> dataLancamento,
});
typedef $$VendaComissaosTableUpdateCompanionBuilder = VendaComissaosCompanion
    Function({
  Value<int?> id,
  Value<int?> idVendaCabecalho,
  Value<int?> idVendedor,
  Value<double?> valorVenda,
  Value<String?> tipoContabil,
  Value<double?> valorComissao,
  Value<String?> situacao,
  Value<DateTime?> dataLancamento,
});

class $$VendaComissaosTableTableManager extends RootTableManager<
    _$AppDatabase,
    $VendaComissaosTable,
    VendaComissao,
    $$VendaComissaosTableFilterComposer,
    $$VendaComissaosTableOrderingComposer,
    $$VendaComissaosTableCreateCompanionBuilder,
    $$VendaComissaosTableUpdateCompanionBuilder> {
  $$VendaComissaosTableTableManager(
      _$AppDatabase db, $VendaComissaosTable table)
      : super(TableManagerState(
          db: db,
          table: table,
          filteringComposer:
              $$VendaComissaosTableFilterComposer(ComposerState(db, table)),
          orderingComposer:
              $$VendaComissaosTableOrderingComposer(ComposerState(db, table)),
          updateCompanionCallback: ({
            Value<int?> id = const Value.absent(),
            Value<int?> idVendaCabecalho = const Value.absent(),
            Value<int?> idVendedor = const Value.absent(),
            Value<double?> valorVenda = const Value.absent(),
            Value<String?> tipoContabil = const Value.absent(),
            Value<double?> valorComissao = const Value.absent(),
            Value<String?> situacao = const Value.absent(),
            Value<DateTime?> dataLancamento = const Value.absent(),
          }) =>
              VendaComissaosCompanion(
            id: id,
            idVendaCabecalho: idVendaCabecalho,
            idVendedor: idVendedor,
            valorVenda: valorVenda,
            tipoContabil: tipoContabil,
            valorComissao: valorComissao,
            situacao: situacao,
            dataLancamento: dataLancamento,
          ),
          createCompanionCallback: ({
            Value<int?> id = const Value.absent(),
            Value<int?> idVendaCabecalho = const Value.absent(),
            Value<int?> idVendedor = const Value.absent(),
            Value<double?> valorVenda = const Value.absent(),
            Value<String?> tipoContabil = const Value.absent(),
            Value<double?> valorComissao = const Value.absent(),
            Value<String?> situacao = const Value.absent(),
            Value<DateTime?> dataLancamento = const Value.absent(),
          }) =>
              VendaComissaosCompanion.insert(
            id: id,
            idVendaCabecalho: idVendaCabecalho,
            idVendedor: idVendedor,
            valorVenda: valorVenda,
            tipoContabil: tipoContabil,
            valorComissao: valorComissao,
            situacao: situacao,
            dataLancamento: dataLancamento,
          ),
        ));
}

class $$VendaComissaosTableFilterComposer
    extends FilterComposer<_$AppDatabase, $VendaComissaosTable> {
  $$VendaComissaosTableFilterComposer(super.$state);
  ColumnFilters<int> get id => $state.composableBuilder(
      column: $state.table.id,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<int> get idVendaCabecalho => $state.composableBuilder(
      column: $state.table.idVendaCabecalho,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<int> get idVendedor => $state.composableBuilder(
      column: $state.table.idVendedor,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<double> get valorVenda => $state.composableBuilder(
      column: $state.table.valorVenda,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get tipoContabil => $state.composableBuilder(
      column: $state.table.tipoContabil,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<double> get valorComissao => $state.composableBuilder(
      column: $state.table.valorComissao,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get situacao => $state.composableBuilder(
      column: $state.table.situacao,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<DateTime> get dataLancamento => $state.composableBuilder(
      column: $state.table.dataLancamento,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));
}

class $$VendaComissaosTableOrderingComposer
    extends OrderingComposer<_$AppDatabase, $VendaComissaosTable> {
  $$VendaComissaosTableOrderingComposer(super.$state);
  ColumnOrderings<int> get id => $state.composableBuilder(
      column: $state.table.id,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<int> get idVendaCabecalho => $state.composableBuilder(
      column: $state.table.idVendaCabecalho,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<int> get idVendedor => $state.composableBuilder(
      column: $state.table.idVendedor,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<double> get valorVenda => $state.composableBuilder(
      column: $state.table.valorVenda,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get tipoContabil => $state.composableBuilder(
      column: $state.table.tipoContabil,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<double> get valorComissao => $state.composableBuilder(
      column: $state.table.valorComissao,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get situacao => $state.composableBuilder(
      column: $state.table.situacao,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<DateTime> get dataLancamento => $state.composableBuilder(
      column: $state.table.dataLancamento,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));
}

typedef $$ProdutoGruposTableCreateCompanionBuilder = ProdutoGruposCompanion
    Function({
  Value<int?> id,
  Value<String?> nome,
  Value<String?> descricao,
});
typedef $$ProdutoGruposTableUpdateCompanionBuilder = ProdutoGruposCompanion
    Function({
  Value<int?> id,
  Value<String?> nome,
  Value<String?> descricao,
});

class $$ProdutoGruposTableTableManager extends RootTableManager<
    _$AppDatabase,
    $ProdutoGruposTable,
    ProdutoGrupo,
    $$ProdutoGruposTableFilterComposer,
    $$ProdutoGruposTableOrderingComposer,
    $$ProdutoGruposTableCreateCompanionBuilder,
    $$ProdutoGruposTableUpdateCompanionBuilder> {
  $$ProdutoGruposTableTableManager(_$AppDatabase db, $ProdutoGruposTable table)
      : super(TableManagerState(
          db: db,
          table: table,
          filteringComposer:
              $$ProdutoGruposTableFilterComposer(ComposerState(db, table)),
          orderingComposer:
              $$ProdutoGruposTableOrderingComposer(ComposerState(db, table)),
          updateCompanionCallback: ({
            Value<int?> id = const Value.absent(),
            Value<String?> nome = const Value.absent(),
            Value<String?> descricao = const Value.absent(),
          }) =>
              ProdutoGruposCompanion(
            id: id,
            nome: nome,
            descricao: descricao,
          ),
          createCompanionCallback: ({
            Value<int?> id = const Value.absent(),
            Value<String?> nome = const Value.absent(),
            Value<String?> descricao = const Value.absent(),
          }) =>
              ProdutoGruposCompanion.insert(
            id: id,
            nome: nome,
            descricao: descricao,
          ),
        ));
}

class $$ProdutoGruposTableFilterComposer
    extends FilterComposer<_$AppDatabase, $ProdutoGruposTable> {
  $$ProdutoGruposTableFilterComposer(super.$state);
  ColumnFilters<int> get id => $state.composableBuilder(
      column: $state.table.id,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get nome => $state.composableBuilder(
      column: $state.table.nome,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get descricao => $state.composableBuilder(
      column: $state.table.descricao,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));
}

class $$ProdutoGruposTableOrderingComposer
    extends OrderingComposer<_$AppDatabase, $ProdutoGruposTable> {
  $$ProdutoGruposTableOrderingComposer(super.$state);
  ColumnOrderings<int> get id => $state.composableBuilder(
      column: $state.table.id,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get nome => $state.composableBuilder(
      column: $state.table.nome,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get descricao => $state.composableBuilder(
      column: $state.table.descricao,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));
}

typedef $$ProdutoSubgruposTableCreateCompanionBuilder
    = ProdutoSubgruposCompanion Function({
  Value<int?> id,
  Value<int?> idProdutoGrupo,
  Value<String?> nome,
  Value<String?> descricao,
});
typedef $$ProdutoSubgruposTableUpdateCompanionBuilder
    = ProdutoSubgruposCompanion Function({
  Value<int?> id,
  Value<int?> idProdutoGrupo,
  Value<String?> nome,
  Value<String?> descricao,
});

class $$ProdutoSubgruposTableTableManager extends RootTableManager<
    _$AppDatabase,
    $ProdutoSubgruposTable,
    ProdutoSubgrupo,
    $$ProdutoSubgruposTableFilterComposer,
    $$ProdutoSubgruposTableOrderingComposer,
    $$ProdutoSubgruposTableCreateCompanionBuilder,
    $$ProdutoSubgruposTableUpdateCompanionBuilder> {
  $$ProdutoSubgruposTableTableManager(
      _$AppDatabase db, $ProdutoSubgruposTable table)
      : super(TableManagerState(
          db: db,
          table: table,
          filteringComposer:
              $$ProdutoSubgruposTableFilterComposer(ComposerState(db, table)),
          orderingComposer:
              $$ProdutoSubgruposTableOrderingComposer(ComposerState(db, table)),
          updateCompanionCallback: ({
            Value<int?> id = const Value.absent(),
            Value<int?> idProdutoGrupo = const Value.absent(),
            Value<String?> nome = const Value.absent(),
            Value<String?> descricao = const Value.absent(),
          }) =>
              ProdutoSubgruposCompanion(
            id: id,
            idProdutoGrupo: idProdutoGrupo,
            nome: nome,
            descricao: descricao,
          ),
          createCompanionCallback: ({
            Value<int?> id = const Value.absent(),
            Value<int?> idProdutoGrupo = const Value.absent(),
            Value<String?> nome = const Value.absent(),
            Value<String?> descricao = const Value.absent(),
          }) =>
              ProdutoSubgruposCompanion.insert(
            id: id,
            idProdutoGrupo: idProdutoGrupo,
            nome: nome,
            descricao: descricao,
          ),
        ));
}

class $$ProdutoSubgruposTableFilterComposer
    extends FilterComposer<_$AppDatabase, $ProdutoSubgruposTable> {
  $$ProdutoSubgruposTableFilterComposer(super.$state);
  ColumnFilters<int> get id => $state.composableBuilder(
      column: $state.table.id,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<int> get idProdutoGrupo => $state.composableBuilder(
      column: $state.table.idProdutoGrupo,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get nome => $state.composableBuilder(
      column: $state.table.nome,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get descricao => $state.composableBuilder(
      column: $state.table.descricao,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));
}

class $$ProdutoSubgruposTableOrderingComposer
    extends OrderingComposer<_$AppDatabase, $ProdutoSubgruposTable> {
  $$ProdutoSubgruposTableOrderingComposer(super.$state);
  ColumnOrderings<int> get id => $state.composableBuilder(
      column: $state.table.id,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<int> get idProdutoGrupo => $state.composableBuilder(
      column: $state.table.idProdutoGrupo,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get nome => $state.composableBuilder(
      column: $state.table.nome,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get descricao => $state.composableBuilder(
      column: $state.table.descricao,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));
}

typedef $$ProdutoMarcasTableCreateCompanionBuilder = ProdutoMarcasCompanion
    Function({
  Value<int?> id,
  Value<String?> nome,
  Value<String?> descricao,
});
typedef $$ProdutoMarcasTableUpdateCompanionBuilder = ProdutoMarcasCompanion
    Function({
  Value<int?> id,
  Value<String?> nome,
  Value<String?> descricao,
});

class $$ProdutoMarcasTableTableManager extends RootTableManager<
    _$AppDatabase,
    $ProdutoMarcasTable,
    ProdutoMarca,
    $$ProdutoMarcasTableFilterComposer,
    $$ProdutoMarcasTableOrderingComposer,
    $$ProdutoMarcasTableCreateCompanionBuilder,
    $$ProdutoMarcasTableUpdateCompanionBuilder> {
  $$ProdutoMarcasTableTableManager(_$AppDatabase db, $ProdutoMarcasTable table)
      : super(TableManagerState(
          db: db,
          table: table,
          filteringComposer:
              $$ProdutoMarcasTableFilterComposer(ComposerState(db, table)),
          orderingComposer:
              $$ProdutoMarcasTableOrderingComposer(ComposerState(db, table)),
          updateCompanionCallback: ({
            Value<int?> id = const Value.absent(),
            Value<String?> nome = const Value.absent(),
            Value<String?> descricao = const Value.absent(),
          }) =>
              ProdutoMarcasCompanion(
            id: id,
            nome: nome,
            descricao: descricao,
          ),
          createCompanionCallback: ({
            Value<int?> id = const Value.absent(),
            Value<String?> nome = const Value.absent(),
            Value<String?> descricao = const Value.absent(),
          }) =>
              ProdutoMarcasCompanion.insert(
            id: id,
            nome: nome,
            descricao: descricao,
          ),
        ));
}

class $$ProdutoMarcasTableFilterComposer
    extends FilterComposer<_$AppDatabase, $ProdutoMarcasTable> {
  $$ProdutoMarcasTableFilterComposer(super.$state);
  ColumnFilters<int> get id => $state.composableBuilder(
      column: $state.table.id,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get nome => $state.composableBuilder(
      column: $state.table.nome,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get descricao => $state.composableBuilder(
      column: $state.table.descricao,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));
}

class $$ProdutoMarcasTableOrderingComposer
    extends OrderingComposer<_$AppDatabase, $ProdutoMarcasTable> {
  $$ProdutoMarcasTableOrderingComposer(super.$state);
  ColumnOrderings<int> get id => $state.composableBuilder(
      column: $state.table.id,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get nome => $state.composableBuilder(
      column: $state.table.nome,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get descricao => $state.composableBuilder(
      column: $state.table.descricao,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));
}

typedef $$ProdutoUnidadesTableCreateCompanionBuilder = ProdutoUnidadesCompanion
    Function({
  Value<int?> id,
  Value<String?> sigla,
  Value<String?> descricao,
  Value<String?> podeFracionar,
});
typedef $$ProdutoUnidadesTableUpdateCompanionBuilder = ProdutoUnidadesCompanion
    Function({
  Value<int?> id,
  Value<String?> sigla,
  Value<String?> descricao,
  Value<String?> podeFracionar,
});

class $$ProdutoUnidadesTableTableManager extends RootTableManager<
    _$AppDatabase,
    $ProdutoUnidadesTable,
    ProdutoUnidade,
    $$ProdutoUnidadesTableFilterComposer,
    $$ProdutoUnidadesTableOrderingComposer,
    $$ProdutoUnidadesTableCreateCompanionBuilder,
    $$ProdutoUnidadesTableUpdateCompanionBuilder> {
  $$ProdutoUnidadesTableTableManager(
      _$AppDatabase db, $ProdutoUnidadesTable table)
      : super(TableManagerState(
          db: db,
          table: table,
          filteringComposer:
              $$ProdutoUnidadesTableFilterComposer(ComposerState(db, table)),
          orderingComposer:
              $$ProdutoUnidadesTableOrderingComposer(ComposerState(db, table)),
          updateCompanionCallback: ({
            Value<int?> id = const Value.absent(),
            Value<String?> sigla = const Value.absent(),
            Value<String?> descricao = const Value.absent(),
            Value<String?> podeFracionar = const Value.absent(),
          }) =>
              ProdutoUnidadesCompanion(
            id: id,
            sigla: sigla,
            descricao: descricao,
            podeFracionar: podeFracionar,
          ),
          createCompanionCallback: ({
            Value<int?> id = const Value.absent(),
            Value<String?> sigla = const Value.absent(),
            Value<String?> descricao = const Value.absent(),
            Value<String?> podeFracionar = const Value.absent(),
          }) =>
              ProdutoUnidadesCompanion.insert(
            id: id,
            sigla: sigla,
            descricao: descricao,
            podeFracionar: podeFracionar,
          ),
        ));
}

class $$ProdutoUnidadesTableFilterComposer
    extends FilterComposer<_$AppDatabase, $ProdutoUnidadesTable> {
  $$ProdutoUnidadesTableFilterComposer(super.$state);
  ColumnFilters<int> get id => $state.composableBuilder(
      column: $state.table.id,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get sigla => $state.composableBuilder(
      column: $state.table.sigla,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get descricao => $state.composableBuilder(
      column: $state.table.descricao,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get podeFracionar => $state.composableBuilder(
      column: $state.table.podeFracionar,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));
}

class $$ProdutoUnidadesTableOrderingComposer
    extends OrderingComposer<_$AppDatabase, $ProdutoUnidadesTable> {
  $$ProdutoUnidadesTableOrderingComposer(super.$state);
  ColumnOrderings<int> get id => $state.composableBuilder(
      column: $state.table.id,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get sigla => $state.composableBuilder(
      column: $state.table.sigla,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get descricao => $state.composableBuilder(
      column: $state.table.descricao,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get podeFracionar => $state.composableBuilder(
      column: $state.table.podeFracionar,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));
}

typedef $$VendaCondicoesPagamentosTableCreateCompanionBuilder
    = VendaCondicoesPagamentosCompanion Function({
  Value<int?> id,
  Value<String?> nome,
  Value<String?> descricao,
  Value<double?> faturamentoMinimo,
  Value<double?> faturamentoMaximo,
  Value<double?> indiceCorrecao,
  Value<int?> diasTolerancia,
  Value<double?> valorTolerancia,
  Value<int?> prazoMedio,
  Value<String?> vistaPrazo,
});
typedef $$VendaCondicoesPagamentosTableUpdateCompanionBuilder
    = VendaCondicoesPagamentosCompanion Function({
  Value<int?> id,
  Value<String?> nome,
  Value<String?> descricao,
  Value<double?> faturamentoMinimo,
  Value<double?> faturamentoMaximo,
  Value<double?> indiceCorrecao,
  Value<int?> diasTolerancia,
  Value<double?> valorTolerancia,
  Value<int?> prazoMedio,
  Value<String?> vistaPrazo,
});

class $$VendaCondicoesPagamentosTableTableManager extends RootTableManager<
    _$AppDatabase,
    $VendaCondicoesPagamentosTable,
    VendaCondicoesPagamento,
    $$VendaCondicoesPagamentosTableFilterComposer,
    $$VendaCondicoesPagamentosTableOrderingComposer,
    $$VendaCondicoesPagamentosTableCreateCompanionBuilder,
    $$VendaCondicoesPagamentosTableUpdateCompanionBuilder> {
  $$VendaCondicoesPagamentosTableTableManager(
      _$AppDatabase db, $VendaCondicoesPagamentosTable table)
      : super(TableManagerState(
          db: db,
          table: table,
          filteringComposer: $$VendaCondicoesPagamentosTableFilterComposer(
              ComposerState(db, table)),
          orderingComposer: $$VendaCondicoesPagamentosTableOrderingComposer(
              ComposerState(db, table)),
          updateCompanionCallback: ({
            Value<int?> id = const Value.absent(),
            Value<String?> nome = const Value.absent(),
            Value<String?> descricao = const Value.absent(),
            Value<double?> faturamentoMinimo = const Value.absent(),
            Value<double?> faturamentoMaximo = const Value.absent(),
            Value<double?> indiceCorrecao = const Value.absent(),
            Value<int?> diasTolerancia = const Value.absent(),
            Value<double?> valorTolerancia = const Value.absent(),
            Value<int?> prazoMedio = const Value.absent(),
            Value<String?> vistaPrazo = const Value.absent(),
          }) =>
              VendaCondicoesPagamentosCompanion(
            id: id,
            nome: nome,
            descricao: descricao,
            faturamentoMinimo: faturamentoMinimo,
            faturamentoMaximo: faturamentoMaximo,
            indiceCorrecao: indiceCorrecao,
            diasTolerancia: diasTolerancia,
            valorTolerancia: valorTolerancia,
            prazoMedio: prazoMedio,
            vistaPrazo: vistaPrazo,
          ),
          createCompanionCallback: ({
            Value<int?> id = const Value.absent(),
            Value<String?> nome = const Value.absent(),
            Value<String?> descricao = const Value.absent(),
            Value<double?> faturamentoMinimo = const Value.absent(),
            Value<double?> faturamentoMaximo = const Value.absent(),
            Value<double?> indiceCorrecao = const Value.absent(),
            Value<int?> diasTolerancia = const Value.absent(),
            Value<double?> valorTolerancia = const Value.absent(),
            Value<int?> prazoMedio = const Value.absent(),
            Value<String?> vistaPrazo = const Value.absent(),
          }) =>
              VendaCondicoesPagamentosCompanion.insert(
            id: id,
            nome: nome,
            descricao: descricao,
            faturamentoMinimo: faturamentoMinimo,
            faturamentoMaximo: faturamentoMaximo,
            indiceCorrecao: indiceCorrecao,
            diasTolerancia: diasTolerancia,
            valorTolerancia: valorTolerancia,
            prazoMedio: prazoMedio,
            vistaPrazo: vistaPrazo,
          ),
        ));
}

class $$VendaCondicoesPagamentosTableFilterComposer
    extends FilterComposer<_$AppDatabase, $VendaCondicoesPagamentosTable> {
  $$VendaCondicoesPagamentosTableFilterComposer(super.$state);
  ColumnFilters<int> get id => $state.composableBuilder(
      column: $state.table.id,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get nome => $state.composableBuilder(
      column: $state.table.nome,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get descricao => $state.composableBuilder(
      column: $state.table.descricao,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<double> get faturamentoMinimo => $state.composableBuilder(
      column: $state.table.faturamentoMinimo,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<double> get faturamentoMaximo => $state.composableBuilder(
      column: $state.table.faturamentoMaximo,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<double> get indiceCorrecao => $state.composableBuilder(
      column: $state.table.indiceCorrecao,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<int> get diasTolerancia => $state.composableBuilder(
      column: $state.table.diasTolerancia,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<double> get valorTolerancia => $state.composableBuilder(
      column: $state.table.valorTolerancia,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<int> get prazoMedio => $state.composableBuilder(
      column: $state.table.prazoMedio,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get vistaPrazo => $state.composableBuilder(
      column: $state.table.vistaPrazo,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));
}

class $$VendaCondicoesPagamentosTableOrderingComposer
    extends OrderingComposer<_$AppDatabase, $VendaCondicoesPagamentosTable> {
  $$VendaCondicoesPagamentosTableOrderingComposer(super.$state);
  ColumnOrderings<int> get id => $state.composableBuilder(
      column: $state.table.id,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get nome => $state.composableBuilder(
      column: $state.table.nome,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get descricao => $state.composableBuilder(
      column: $state.table.descricao,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<double> get faturamentoMinimo => $state.composableBuilder(
      column: $state.table.faturamentoMinimo,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<double> get faturamentoMaximo => $state.composableBuilder(
      column: $state.table.faturamentoMaximo,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<double> get indiceCorrecao => $state.composableBuilder(
      column: $state.table.indiceCorrecao,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<int> get diasTolerancia => $state.composableBuilder(
      column: $state.table.diasTolerancia,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<double> get valorTolerancia => $state.composableBuilder(
      column: $state.table.valorTolerancia,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<int> get prazoMedio => $state.composableBuilder(
      column: $state.table.prazoMedio,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get vistaPrazo => $state.composableBuilder(
      column: $state.table.vistaPrazo,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));
}

typedef $$VendaOrcamentoCabecalhosTableCreateCompanionBuilder
    = VendaOrcamentoCabecalhosCompanion Function({
  Value<int?> id,
  Value<int?> idVendedor,
  Value<int?> idCliente,
  Value<int?> idVendaCondicoesPagamento,
  Value<int?> idTransportadora,
  Value<String?> tipoFrete,
  Value<String?> codigo,
  Value<DateTime?> dataCadastro,
  Value<DateTime?> dataEntrega,
  Value<DateTime?> dataValidade,
  Value<double?> valorSubtotal,
  Value<double?> valorFrete,
  Value<double?> taxaComissao,
  Value<double?> valorComissao,
  Value<double?> taxaDesconto,
  Value<double?> valorDesconto,
  Value<double?> valorTotal,
  Value<String?> observacao,
});
typedef $$VendaOrcamentoCabecalhosTableUpdateCompanionBuilder
    = VendaOrcamentoCabecalhosCompanion Function({
  Value<int?> id,
  Value<int?> idVendedor,
  Value<int?> idCliente,
  Value<int?> idVendaCondicoesPagamento,
  Value<int?> idTransportadora,
  Value<String?> tipoFrete,
  Value<String?> codigo,
  Value<DateTime?> dataCadastro,
  Value<DateTime?> dataEntrega,
  Value<DateTime?> dataValidade,
  Value<double?> valorSubtotal,
  Value<double?> valorFrete,
  Value<double?> taxaComissao,
  Value<double?> valorComissao,
  Value<double?> taxaDesconto,
  Value<double?> valorDesconto,
  Value<double?> valorTotal,
  Value<String?> observacao,
});

class $$VendaOrcamentoCabecalhosTableTableManager extends RootTableManager<
    _$AppDatabase,
    $VendaOrcamentoCabecalhosTable,
    VendaOrcamentoCabecalho,
    $$VendaOrcamentoCabecalhosTableFilterComposer,
    $$VendaOrcamentoCabecalhosTableOrderingComposer,
    $$VendaOrcamentoCabecalhosTableCreateCompanionBuilder,
    $$VendaOrcamentoCabecalhosTableUpdateCompanionBuilder> {
  $$VendaOrcamentoCabecalhosTableTableManager(
      _$AppDatabase db, $VendaOrcamentoCabecalhosTable table)
      : super(TableManagerState(
          db: db,
          table: table,
          filteringComposer: $$VendaOrcamentoCabecalhosTableFilterComposer(
              ComposerState(db, table)),
          orderingComposer: $$VendaOrcamentoCabecalhosTableOrderingComposer(
              ComposerState(db, table)),
          updateCompanionCallback: ({
            Value<int?> id = const Value.absent(),
            Value<int?> idVendedor = const Value.absent(),
            Value<int?> idCliente = const Value.absent(),
            Value<int?> idVendaCondicoesPagamento = const Value.absent(),
            Value<int?> idTransportadora = const Value.absent(),
            Value<String?> tipoFrete = const Value.absent(),
            Value<String?> codigo = const Value.absent(),
            Value<DateTime?> dataCadastro = const Value.absent(),
            Value<DateTime?> dataEntrega = const Value.absent(),
            Value<DateTime?> dataValidade = const Value.absent(),
            Value<double?> valorSubtotal = const Value.absent(),
            Value<double?> valorFrete = const Value.absent(),
            Value<double?> taxaComissao = const Value.absent(),
            Value<double?> valorComissao = const Value.absent(),
            Value<double?> taxaDesconto = const Value.absent(),
            Value<double?> valorDesconto = const Value.absent(),
            Value<double?> valorTotal = const Value.absent(),
            Value<String?> observacao = const Value.absent(),
          }) =>
              VendaOrcamentoCabecalhosCompanion(
            id: id,
            idVendedor: idVendedor,
            idCliente: idCliente,
            idVendaCondicoesPagamento: idVendaCondicoesPagamento,
            idTransportadora: idTransportadora,
            tipoFrete: tipoFrete,
            codigo: codigo,
            dataCadastro: dataCadastro,
            dataEntrega: dataEntrega,
            dataValidade: dataValidade,
            valorSubtotal: valorSubtotal,
            valorFrete: valorFrete,
            taxaComissao: taxaComissao,
            valorComissao: valorComissao,
            taxaDesconto: taxaDesconto,
            valorDesconto: valorDesconto,
            valorTotal: valorTotal,
            observacao: observacao,
          ),
          createCompanionCallback: ({
            Value<int?> id = const Value.absent(),
            Value<int?> idVendedor = const Value.absent(),
            Value<int?> idCliente = const Value.absent(),
            Value<int?> idVendaCondicoesPagamento = const Value.absent(),
            Value<int?> idTransportadora = const Value.absent(),
            Value<String?> tipoFrete = const Value.absent(),
            Value<String?> codigo = const Value.absent(),
            Value<DateTime?> dataCadastro = const Value.absent(),
            Value<DateTime?> dataEntrega = const Value.absent(),
            Value<DateTime?> dataValidade = const Value.absent(),
            Value<double?> valorSubtotal = const Value.absent(),
            Value<double?> valorFrete = const Value.absent(),
            Value<double?> taxaComissao = const Value.absent(),
            Value<double?> valorComissao = const Value.absent(),
            Value<double?> taxaDesconto = const Value.absent(),
            Value<double?> valorDesconto = const Value.absent(),
            Value<double?> valorTotal = const Value.absent(),
            Value<String?> observacao = const Value.absent(),
          }) =>
              VendaOrcamentoCabecalhosCompanion.insert(
            id: id,
            idVendedor: idVendedor,
            idCliente: idCliente,
            idVendaCondicoesPagamento: idVendaCondicoesPagamento,
            idTransportadora: idTransportadora,
            tipoFrete: tipoFrete,
            codigo: codigo,
            dataCadastro: dataCadastro,
            dataEntrega: dataEntrega,
            dataValidade: dataValidade,
            valorSubtotal: valorSubtotal,
            valorFrete: valorFrete,
            taxaComissao: taxaComissao,
            valorComissao: valorComissao,
            taxaDesconto: taxaDesconto,
            valorDesconto: valorDesconto,
            valorTotal: valorTotal,
            observacao: observacao,
          ),
        ));
}

class $$VendaOrcamentoCabecalhosTableFilterComposer
    extends FilterComposer<_$AppDatabase, $VendaOrcamentoCabecalhosTable> {
  $$VendaOrcamentoCabecalhosTableFilterComposer(super.$state);
  ColumnFilters<int> get id => $state.composableBuilder(
      column: $state.table.id,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<int> get idVendedor => $state.composableBuilder(
      column: $state.table.idVendedor,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<int> get idCliente => $state.composableBuilder(
      column: $state.table.idCliente,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<int> get idVendaCondicoesPagamento => $state.composableBuilder(
      column: $state.table.idVendaCondicoesPagamento,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<int> get idTransportadora => $state.composableBuilder(
      column: $state.table.idTransportadora,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get tipoFrete => $state.composableBuilder(
      column: $state.table.tipoFrete,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get codigo => $state.composableBuilder(
      column: $state.table.codigo,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<DateTime> get dataCadastro => $state.composableBuilder(
      column: $state.table.dataCadastro,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<DateTime> get dataEntrega => $state.composableBuilder(
      column: $state.table.dataEntrega,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<DateTime> get dataValidade => $state.composableBuilder(
      column: $state.table.dataValidade,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<double> get valorSubtotal => $state.composableBuilder(
      column: $state.table.valorSubtotal,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<double> get valorFrete => $state.composableBuilder(
      column: $state.table.valorFrete,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<double> get taxaComissao => $state.composableBuilder(
      column: $state.table.taxaComissao,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<double> get valorComissao => $state.composableBuilder(
      column: $state.table.valorComissao,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<double> get taxaDesconto => $state.composableBuilder(
      column: $state.table.taxaDesconto,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<double> get valorDesconto => $state.composableBuilder(
      column: $state.table.valorDesconto,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<double> get valorTotal => $state.composableBuilder(
      column: $state.table.valorTotal,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get observacao => $state.composableBuilder(
      column: $state.table.observacao,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));
}

class $$VendaOrcamentoCabecalhosTableOrderingComposer
    extends OrderingComposer<_$AppDatabase, $VendaOrcamentoCabecalhosTable> {
  $$VendaOrcamentoCabecalhosTableOrderingComposer(super.$state);
  ColumnOrderings<int> get id => $state.composableBuilder(
      column: $state.table.id,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<int> get idVendedor => $state.composableBuilder(
      column: $state.table.idVendedor,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<int> get idCliente => $state.composableBuilder(
      column: $state.table.idCliente,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<int> get idVendaCondicoesPagamento =>
      $state.composableBuilder(
          column: $state.table.idVendaCondicoesPagamento,
          builder: (column, joinBuilders) =>
              ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<int> get idTransportadora => $state.composableBuilder(
      column: $state.table.idTransportadora,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get tipoFrete => $state.composableBuilder(
      column: $state.table.tipoFrete,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get codigo => $state.composableBuilder(
      column: $state.table.codigo,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<DateTime> get dataCadastro => $state.composableBuilder(
      column: $state.table.dataCadastro,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<DateTime> get dataEntrega => $state.composableBuilder(
      column: $state.table.dataEntrega,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<DateTime> get dataValidade => $state.composableBuilder(
      column: $state.table.dataValidade,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<double> get valorSubtotal => $state.composableBuilder(
      column: $state.table.valorSubtotal,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<double> get valorFrete => $state.composableBuilder(
      column: $state.table.valorFrete,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<double> get taxaComissao => $state.composableBuilder(
      column: $state.table.taxaComissao,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<double> get valorComissao => $state.composableBuilder(
      column: $state.table.valorComissao,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<double> get taxaDesconto => $state.composableBuilder(
      column: $state.table.taxaDesconto,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<double> get valorDesconto => $state.composableBuilder(
      column: $state.table.valorDesconto,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<double> get valorTotal => $state.composableBuilder(
      column: $state.table.valorTotal,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get observacao => $state.composableBuilder(
      column: $state.table.observacao,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));
}

typedef $$VendaCabecalhosTableCreateCompanionBuilder = VendaCabecalhosCompanion
    Function({
  Value<int?> id,
  Value<int?> idVendaOrcamentoCabecalho,
  Value<int?> idNotaFiscalTipo,
  Value<int?> idVendedor,
  Value<int?> idVendaCondicoesPagamento,
  Value<int?> idTransportadora,
  Value<int?> idCliente,
  Value<String?> localEntrega,
  Value<String?> localCobranca,
  Value<String?> tipoFrete,
  Value<String?> formaPagamento,
  Value<DateTime?> dataVenda,
  Value<DateTime?> dataSaida,
  Value<String?> horaSaida,
  Value<int?> numeroFatura,
  Value<double?> valorFrete,
  Value<double?> valorSeguro,
  Value<double?> valorSubtotal,
  Value<double?> taxaComissao,
  Value<double?> valorComissao,
  Value<double?> taxaDesconto,
  Value<double?> valorDesconto,
  Value<double?> valorTotal,
  Value<String?> situacao,
  Value<String?> diaFixoParcela,
  Value<String?> observacao,
});
typedef $$VendaCabecalhosTableUpdateCompanionBuilder = VendaCabecalhosCompanion
    Function({
  Value<int?> id,
  Value<int?> idVendaOrcamentoCabecalho,
  Value<int?> idNotaFiscalTipo,
  Value<int?> idVendedor,
  Value<int?> idVendaCondicoesPagamento,
  Value<int?> idTransportadora,
  Value<int?> idCliente,
  Value<String?> localEntrega,
  Value<String?> localCobranca,
  Value<String?> tipoFrete,
  Value<String?> formaPagamento,
  Value<DateTime?> dataVenda,
  Value<DateTime?> dataSaida,
  Value<String?> horaSaida,
  Value<int?> numeroFatura,
  Value<double?> valorFrete,
  Value<double?> valorSeguro,
  Value<double?> valorSubtotal,
  Value<double?> taxaComissao,
  Value<double?> valorComissao,
  Value<double?> taxaDesconto,
  Value<double?> valorDesconto,
  Value<double?> valorTotal,
  Value<String?> situacao,
  Value<String?> diaFixoParcela,
  Value<String?> observacao,
});

class $$VendaCabecalhosTableTableManager extends RootTableManager<
    _$AppDatabase,
    $VendaCabecalhosTable,
    VendaCabecalho,
    $$VendaCabecalhosTableFilterComposer,
    $$VendaCabecalhosTableOrderingComposer,
    $$VendaCabecalhosTableCreateCompanionBuilder,
    $$VendaCabecalhosTableUpdateCompanionBuilder> {
  $$VendaCabecalhosTableTableManager(
      _$AppDatabase db, $VendaCabecalhosTable table)
      : super(TableManagerState(
          db: db,
          table: table,
          filteringComposer:
              $$VendaCabecalhosTableFilterComposer(ComposerState(db, table)),
          orderingComposer:
              $$VendaCabecalhosTableOrderingComposer(ComposerState(db, table)),
          updateCompanionCallback: ({
            Value<int?> id = const Value.absent(),
            Value<int?> idVendaOrcamentoCabecalho = const Value.absent(),
            Value<int?> idNotaFiscalTipo = const Value.absent(),
            Value<int?> idVendedor = const Value.absent(),
            Value<int?> idVendaCondicoesPagamento = const Value.absent(),
            Value<int?> idTransportadora = const Value.absent(),
            Value<int?> idCliente = const Value.absent(),
            Value<String?> localEntrega = const Value.absent(),
            Value<String?> localCobranca = const Value.absent(),
            Value<String?> tipoFrete = const Value.absent(),
            Value<String?> formaPagamento = const Value.absent(),
            Value<DateTime?> dataVenda = const Value.absent(),
            Value<DateTime?> dataSaida = const Value.absent(),
            Value<String?> horaSaida = const Value.absent(),
            Value<int?> numeroFatura = const Value.absent(),
            Value<double?> valorFrete = const Value.absent(),
            Value<double?> valorSeguro = const Value.absent(),
            Value<double?> valorSubtotal = const Value.absent(),
            Value<double?> taxaComissao = const Value.absent(),
            Value<double?> valorComissao = const Value.absent(),
            Value<double?> taxaDesconto = const Value.absent(),
            Value<double?> valorDesconto = const Value.absent(),
            Value<double?> valorTotal = const Value.absent(),
            Value<String?> situacao = const Value.absent(),
            Value<String?> diaFixoParcela = const Value.absent(),
            Value<String?> observacao = const Value.absent(),
          }) =>
              VendaCabecalhosCompanion(
            id: id,
            idVendaOrcamentoCabecalho: idVendaOrcamentoCabecalho,
            idNotaFiscalTipo: idNotaFiscalTipo,
            idVendedor: idVendedor,
            idVendaCondicoesPagamento: idVendaCondicoesPagamento,
            idTransportadora: idTransportadora,
            idCliente: idCliente,
            localEntrega: localEntrega,
            localCobranca: localCobranca,
            tipoFrete: tipoFrete,
            formaPagamento: formaPagamento,
            dataVenda: dataVenda,
            dataSaida: dataSaida,
            horaSaida: horaSaida,
            numeroFatura: numeroFatura,
            valorFrete: valorFrete,
            valorSeguro: valorSeguro,
            valorSubtotal: valorSubtotal,
            taxaComissao: taxaComissao,
            valorComissao: valorComissao,
            taxaDesconto: taxaDesconto,
            valorDesconto: valorDesconto,
            valorTotal: valorTotal,
            situacao: situacao,
            diaFixoParcela: diaFixoParcela,
            observacao: observacao,
          ),
          createCompanionCallback: ({
            Value<int?> id = const Value.absent(),
            Value<int?> idVendaOrcamentoCabecalho = const Value.absent(),
            Value<int?> idNotaFiscalTipo = const Value.absent(),
            Value<int?> idVendedor = const Value.absent(),
            Value<int?> idVendaCondicoesPagamento = const Value.absent(),
            Value<int?> idTransportadora = const Value.absent(),
            Value<int?> idCliente = const Value.absent(),
            Value<String?> localEntrega = const Value.absent(),
            Value<String?> localCobranca = const Value.absent(),
            Value<String?> tipoFrete = const Value.absent(),
            Value<String?> formaPagamento = const Value.absent(),
            Value<DateTime?> dataVenda = const Value.absent(),
            Value<DateTime?> dataSaida = const Value.absent(),
            Value<String?> horaSaida = const Value.absent(),
            Value<int?> numeroFatura = const Value.absent(),
            Value<double?> valorFrete = const Value.absent(),
            Value<double?> valorSeguro = const Value.absent(),
            Value<double?> valorSubtotal = const Value.absent(),
            Value<double?> taxaComissao = const Value.absent(),
            Value<double?> valorComissao = const Value.absent(),
            Value<double?> taxaDesconto = const Value.absent(),
            Value<double?> valorDesconto = const Value.absent(),
            Value<double?> valorTotal = const Value.absent(),
            Value<String?> situacao = const Value.absent(),
            Value<String?> diaFixoParcela = const Value.absent(),
            Value<String?> observacao = const Value.absent(),
          }) =>
              VendaCabecalhosCompanion.insert(
            id: id,
            idVendaOrcamentoCabecalho: idVendaOrcamentoCabecalho,
            idNotaFiscalTipo: idNotaFiscalTipo,
            idVendedor: idVendedor,
            idVendaCondicoesPagamento: idVendaCondicoesPagamento,
            idTransportadora: idTransportadora,
            idCliente: idCliente,
            localEntrega: localEntrega,
            localCobranca: localCobranca,
            tipoFrete: tipoFrete,
            formaPagamento: formaPagamento,
            dataVenda: dataVenda,
            dataSaida: dataSaida,
            horaSaida: horaSaida,
            numeroFatura: numeroFatura,
            valorFrete: valorFrete,
            valorSeguro: valorSeguro,
            valorSubtotal: valorSubtotal,
            taxaComissao: taxaComissao,
            valorComissao: valorComissao,
            taxaDesconto: taxaDesconto,
            valorDesconto: valorDesconto,
            valorTotal: valorTotal,
            situacao: situacao,
            diaFixoParcela: diaFixoParcela,
            observacao: observacao,
          ),
        ));
}

class $$VendaCabecalhosTableFilterComposer
    extends FilterComposer<_$AppDatabase, $VendaCabecalhosTable> {
  $$VendaCabecalhosTableFilterComposer(super.$state);
  ColumnFilters<int> get id => $state.composableBuilder(
      column: $state.table.id,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<int> get idVendaOrcamentoCabecalho => $state.composableBuilder(
      column: $state.table.idVendaOrcamentoCabecalho,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<int> get idNotaFiscalTipo => $state.composableBuilder(
      column: $state.table.idNotaFiscalTipo,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<int> get idVendedor => $state.composableBuilder(
      column: $state.table.idVendedor,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<int> get idVendaCondicoesPagamento => $state.composableBuilder(
      column: $state.table.idVendaCondicoesPagamento,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<int> get idTransportadora => $state.composableBuilder(
      column: $state.table.idTransportadora,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<int> get idCliente => $state.composableBuilder(
      column: $state.table.idCliente,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get localEntrega => $state.composableBuilder(
      column: $state.table.localEntrega,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get localCobranca => $state.composableBuilder(
      column: $state.table.localCobranca,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get tipoFrete => $state.composableBuilder(
      column: $state.table.tipoFrete,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get formaPagamento => $state.composableBuilder(
      column: $state.table.formaPagamento,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<DateTime> get dataVenda => $state.composableBuilder(
      column: $state.table.dataVenda,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<DateTime> get dataSaida => $state.composableBuilder(
      column: $state.table.dataSaida,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get horaSaida => $state.composableBuilder(
      column: $state.table.horaSaida,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<int> get numeroFatura => $state.composableBuilder(
      column: $state.table.numeroFatura,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<double> get valorFrete => $state.composableBuilder(
      column: $state.table.valorFrete,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<double> get valorSeguro => $state.composableBuilder(
      column: $state.table.valorSeguro,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<double> get valorSubtotal => $state.composableBuilder(
      column: $state.table.valorSubtotal,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<double> get taxaComissao => $state.composableBuilder(
      column: $state.table.taxaComissao,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<double> get valorComissao => $state.composableBuilder(
      column: $state.table.valorComissao,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<double> get taxaDesconto => $state.composableBuilder(
      column: $state.table.taxaDesconto,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<double> get valorDesconto => $state.composableBuilder(
      column: $state.table.valorDesconto,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<double> get valorTotal => $state.composableBuilder(
      column: $state.table.valorTotal,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get situacao => $state.composableBuilder(
      column: $state.table.situacao,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get diaFixoParcela => $state.composableBuilder(
      column: $state.table.diaFixoParcela,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get observacao => $state.composableBuilder(
      column: $state.table.observacao,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));
}

class $$VendaCabecalhosTableOrderingComposer
    extends OrderingComposer<_$AppDatabase, $VendaCabecalhosTable> {
  $$VendaCabecalhosTableOrderingComposer(super.$state);
  ColumnOrderings<int> get id => $state.composableBuilder(
      column: $state.table.id,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<int> get idVendaOrcamentoCabecalho =>
      $state.composableBuilder(
          column: $state.table.idVendaOrcamentoCabecalho,
          builder: (column, joinBuilders) =>
              ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<int> get idNotaFiscalTipo => $state.composableBuilder(
      column: $state.table.idNotaFiscalTipo,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<int> get idVendedor => $state.composableBuilder(
      column: $state.table.idVendedor,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<int> get idVendaCondicoesPagamento =>
      $state.composableBuilder(
          column: $state.table.idVendaCondicoesPagamento,
          builder: (column, joinBuilders) =>
              ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<int> get idTransportadora => $state.composableBuilder(
      column: $state.table.idTransportadora,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<int> get idCliente => $state.composableBuilder(
      column: $state.table.idCliente,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get localEntrega => $state.composableBuilder(
      column: $state.table.localEntrega,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get localCobranca => $state.composableBuilder(
      column: $state.table.localCobranca,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get tipoFrete => $state.composableBuilder(
      column: $state.table.tipoFrete,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get formaPagamento => $state.composableBuilder(
      column: $state.table.formaPagamento,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<DateTime> get dataVenda => $state.composableBuilder(
      column: $state.table.dataVenda,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<DateTime> get dataSaida => $state.composableBuilder(
      column: $state.table.dataSaida,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get horaSaida => $state.composableBuilder(
      column: $state.table.horaSaida,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<int> get numeroFatura => $state.composableBuilder(
      column: $state.table.numeroFatura,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<double> get valorFrete => $state.composableBuilder(
      column: $state.table.valorFrete,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<double> get valorSeguro => $state.composableBuilder(
      column: $state.table.valorSeguro,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<double> get valorSubtotal => $state.composableBuilder(
      column: $state.table.valorSubtotal,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<double> get taxaComissao => $state.composableBuilder(
      column: $state.table.taxaComissao,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<double> get valorComissao => $state.composableBuilder(
      column: $state.table.valorComissao,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<double> get taxaDesconto => $state.composableBuilder(
      column: $state.table.taxaDesconto,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<double> get valorDesconto => $state.composableBuilder(
      column: $state.table.valorDesconto,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<double> get valorTotal => $state.composableBuilder(
      column: $state.table.valorTotal,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get situacao => $state.composableBuilder(
      column: $state.table.situacao,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get diaFixoParcela => $state.composableBuilder(
      column: $state.table.diaFixoParcela,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get observacao => $state.composableBuilder(
      column: $state.table.observacao,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));
}

typedef $$NotaFiscalModelosTableCreateCompanionBuilder
    = NotaFiscalModelosCompanion Function({
  Value<int?> id,
  Value<String?> codigo,
  Value<String?> descricao,
  Value<String?> modelo,
});
typedef $$NotaFiscalModelosTableUpdateCompanionBuilder
    = NotaFiscalModelosCompanion Function({
  Value<int?> id,
  Value<String?> codigo,
  Value<String?> descricao,
  Value<String?> modelo,
});

class $$NotaFiscalModelosTableTableManager extends RootTableManager<
    _$AppDatabase,
    $NotaFiscalModelosTable,
    NotaFiscalModelo,
    $$NotaFiscalModelosTableFilterComposer,
    $$NotaFiscalModelosTableOrderingComposer,
    $$NotaFiscalModelosTableCreateCompanionBuilder,
    $$NotaFiscalModelosTableUpdateCompanionBuilder> {
  $$NotaFiscalModelosTableTableManager(
      _$AppDatabase db, $NotaFiscalModelosTable table)
      : super(TableManagerState(
          db: db,
          table: table,
          filteringComposer:
              $$NotaFiscalModelosTableFilterComposer(ComposerState(db, table)),
          orderingComposer: $$NotaFiscalModelosTableOrderingComposer(
              ComposerState(db, table)),
          updateCompanionCallback: ({
            Value<int?> id = const Value.absent(),
            Value<String?> codigo = const Value.absent(),
            Value<String?> descricao = const Value.absent(),
            Value<String?> modelo = const Value.absent(),
          }) =>
              NotaFiscalModelosCompanion(
            id: id,
            codigo: codigo,
            descricao: descricao,
            modelo: modelo,
          ),
          createCompanionCallback: ({
            Value<int?> id = const Value.absent(),
            Value<String?> codigo = const Value.absent(),
            Value<String?> descricao = const Value.absent(),
            Value<String?> modelo = const Value.absent(),
          }) =>
              NotaFiscalModelosCompanion.insert(
            id: id,
            codigo: codigo,
            descricao: descricao,
            modelo: modelo,
          ),
        ));
}

class $$NotaFiscalModelosTableFilterComposer
    extends FilterComposer<_$AppDatabase, $NotaFiscalModelosTable> {
  $$NotaFiscalModelosTableFilterComposer(super.$state);
  ColumnFilters<int> get id => $state.composableBuilder(
      column: $state.table.id,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get codigo => $state.composableBuilder(
      column: $state.table.codigo,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get descricao => $state.composableBuilder(
      column: $state.table.descricao,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get modelo => $state.composableBuilder(
      column: $state.table.modelo,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));
}

class $$NotaFiscalModelosTableOrderingComposer
    extends OrderingComposer<_$AppDatabase, $NotaFiscalModelosTable> {
  $$NotaFiscalModelosTableOrderingComposer(super.$state);
  ColumnOrderings<int> get id => $state.composableBuilder(
      column: $state.table.id,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get codigo => $state.composableBuilder(
      column: $state.table.codigo,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get descricao => $state.composableBuilder(
      column: $state.table.descricao,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get modelo => $state.composableBuilder(
      column: $state.table.modelo,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));
}

typedef $$NotaFiscalTiposTableCreateCompanionBuilder = NotaFiscalTiposCompanion
    Function({
  Value<int?> id,
  Value<int?> idNotaFiscalModelo,
  Value<String?> nome,
  Value<String?> descricao,
  Value<String?> serie,
  Value<String?> serieScan,
  Value<int?> ultimoNumero,
});
typedef $$NotaFiscalTiposTableUpdateCompanionBuilder = NotaFiscalTiposCompanion
    Function({
  Value<int?> id,
  Value<int?> idNotaFiscalModelo,
  Value<String?> nome,
  Value<String?> descricao,
  Value<String?> serie,
  Value<String?> serieScan,
  Value<int?> ultimoNumero,
});

class $$NotaFiscalTiposTableTableManager extends RootTableManager<
    _$AppDatabase,
    $NotaFiscalTiposTable,
    NotaFiscalTipo,
    $$NotaFiscalTiposTableFilterComposer,
    $$NotaFiscalTiposTableOrderingComposer,
    $$NotaFiscalTiposTableCreateCompanionBuilder,
    $$NotaFiscalTiposTableUpdateCompanionBuilder> {
  $$NotaFiscalTiposTableTableManager(
      _$AppDatabase db, $NotaFiscalTiposTable table)
      : super(TableManagerState(
          db: db,
          table: table,
          filteringComposer:
              $$NotaFiscalTiposTableFilterComposer(ComposerState(db, table)),
          orderingComposer:
              $$NotaFiscalTiposTableOrderingComposer(ComposerState(db, table)),
          updateCompanionCallback: ({
            Value<int?> id = const Value.absent(),
            Value<int?> idNotaFiscalModelo = const Value.absent(),
            Value<String?> nome = const Value.absent(),
            Value<String?> descricao = const Value.absent(),
            Value<String?> serie = const Value.absent(),
            Value<String?> serieScan = const Value.absent(),
            Value<int?> ultimoNumero = const Value.absent(),
          }) =>
              NotaFiscalTiposCompanion(
            id: id,
            idNotaFiscalModelo: idNotaFiscalModelo,
            nome: nome,
            descricao: descricao,
            serie: serie,
            serieScan: serieScan,
            ultimoNumero: ultimoNumero,
          ),
          createCompanionCallback: ({
            Value<int?> id = const Value.absent(),
            Value<int?> idNotaFiscalModelo = const Value.absent(),
            Value<String?> nome = const Value.absent(),
            Value<String?> descricao = const Value.absent(),
            Value<String?> serie = const Value.absent(),
            Value<String?> serieScan = const Value.absent(),
            Value<int?> ultimoNumero = const Value.absent(),
          }) =>
              NotaFiscalTiposCompanion.insert(
            id: id,
            idNotaFiscalModelo: idNotaFiscalModelo,
            nome: nome,
            descricao: descricao,
            serie: serie,
            serieScan: serieScan,
            ultimoNumero: ultimoNumero,
          ),
        ));
}

class $$NotaFiscalTiposTableFilterComposer
    extends FilterComposer<_$AppDatabase, $NotaFiscalTiposTable> {
  $$NotaFiscalTiposTableFilterComposer(super.$state);
  ColumnFilters<int> get id => $state.composableBuilder(
      column: $state.table.id,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<int> get idNotaFiscalModelo => $state.composableBuilder(
      column: $state.table.idNotaFiscalModelo,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get nome => $state.composableBuilder(
      column: $state.table.nome,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get descricao => $state.composableBuilder(
      column: $state.table.descricao,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get serie => $state.composableBuilder(
      column: $state.table.serie,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get serieScan => $state.composableBuilder(
      column: $state.table.serieScan,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<int> get ultimoNumero => $state.composableBuilder(
      column: $state.table.ultimoNumero,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));
}

class $$NotaFiscalTiposTableOrderingComposer
    extends OrderingComposer<_$AppDatabase, $NotaFiscalTiposTable> {
  $$NotaFiscalTiposTableOrderingComposer(super.$state);
  ColumnOrderings<int> get id => $state.composableBuilder(
      column: $state.table.id,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<int> get idNotaFiscalModelo => $state.composableBuilder(
      column: $state.table.idNotaFiscalModelo,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get nome => $state.composableBuilder(
      column: $state.table.nome,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get descricao => $state.composableBuilder(
      column: $state.table.descricao,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get serie => $state.composableBuilder(
      column: $state.table.serie,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get serieScan => $state.composableBuilder(
      column: $state.table.serieScan,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<int> get ultimoNumero => $state.composableBuilder(
      column: $state.table.ultimoNumero,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));
}

typedef $$ViewControleAcessosTableCreateCompanionBuilder
    = ViewControleAcessosCompanion Function({
  Value<int?> id,
  Value<int?> idPessoa,
  Value<String?> pessoaNome,
  Value<int?> idColaborador,
  Value<int?> idUsuario,
  Value<String?> administrador,
  Value<int?> idPapel,
  Value<String?> papelNome,
  Value<String?> papelDescricao,
  Value<int?> idFuncao,
  Value<String?> funcaoNome,
  Value<String?> funcaoDescricao,
  Value<int?> idPapelFuncao,
  Value<String?> habilitado,
  Value<String?> podeInserir,
  Value<String?> podeAlterar,
  Value<String?> podeExcluir,
});
typedef $$ViewControleAcessosTableUpdateCompanionBuilder
    = ViewControleAcessosCompanion Function({
  Value<int?> id,
  Value<int?> idPessoa,
  Value<String?> pessoaNome,
  Value<int?> idColaborador,
  Value<int?> idUsuario,
  Value<String?> administrador,
  Value<int?> idPapel,
  Value<String?> papelNome,
  Value<String?> papelDescricao,
  Value<int?> idFuncao,
  Value<String?> funcaoNome,
  Value<String?> funcaoDescricao,
  Value<int?> idPapelFuncao,
  Value<String?> habilitado,
  Value<String?> podeInserir,
  Value<String?> podeAlterar,
  Value<String?> podeExcluir,
});

class $$ViewControleAcessosTableTableManager extends RootTableManager<
    _$AppDatabase,
    $ViewControleAcessosTable,
    ViewControleAcesso,
    $$ViewControleAcessosTableFilterComposer,
    $$ViewControleAcessosTableOrderingComposer,
    $$ViewControleAcessosTableCreateCompanionBuilder,
    $$ViewControleAcessosTableUpdateCompanionBuilder> {
  $$ViewControleAcessosTableTableManager(
      _$AppDatabase db, $ViewControleAcessosTable table)
      : super(TableManagerState(
          db: db,
          table: table,
          filteringComposer: $$ViewControleAcessosTableFilterComposer(
              ComposerState(db, table)),
          orderingComposer: $$ViewControleAcessosTableOrderingComposer(
              ComposerState(db, table)),
          updateCompanionCallback: ({
            Value<int?> id = const Value.absent(),
            Value<int?> idPessoa = const Value.absent(),
            Value<String?> pessoaNome = const Value.absent(),
            Value<int?> idColaborador = const Value.absent(),
            Value<int?> idUsuario = const Value.absent(),
            Value<String?> administrador = const Value.absent(),
            Value<int?> idPapel = const Value.absent(),
            Value<String?> papelNome = const Value.absent(),
            Value<String?> papelDescricao = const Value.absent(),
            Value<int?> idFuncao = const Value.absent(),
            Value<String?> funcaoNome = const Value.absent(),
            Value<String?> funcaoDescricao = const Value.absent(),
            Value<int?> idPapelFuncao = const Value.absent(),
            Value<String?> habilitado = const Value.absent(),
            Value<String?> podeInserir = const Value.absent(),
            Value<String?> podeAlterar = const Value.absent(),
            Value<String?> podeExcluir = const Value.absent(),
          }) =>
              ViewControleAcessosCompanion(
            id: id,
            idPessoa: idPessoa,
            pessoaNome: pessoaNome,
            idColaborador: idColaborador,
            idUsuario: idUsuario,
            administrador: administrador,
            idPapel: idPapel,
            papelNome: papelNome,
            papelDescricao: papelDescricao,
            idFuncao: idFuncao,
            funcaoNome: funcaoNome,
            funcaoDescricao: funcaoDescricao,
            idPapelFuncao: idPapelFuncao,
            habilitado: habilitado,
            podeInserir: podeInserir,
            podeAlterar: podeAlterar,
            podeExcluir: podeExcluir,
          ),
          createCompanionCallback: ({
            Value<int?> id = const Value.absent(),
            Value<int?> idPessoa = const Value.absent(),
            Value<String?> pessoaNome = const Value.absent(),
            Value<int?> idColaborador = const Value.absent(),
            Value<int?> idUsuario = const Value.absent(),
            Value<String?> administrador = const Value.absent(),
            Value<int?> idPapel = const Value.absent(),
            Value<String?> papelNome = const Value.absent(),
            Value<String?> papelDescricao = const Value.absent(),
            Value<int?> idFuncao = const Value.absent(),
            Value<String?> funcaoNome = const Value.absent(),
            Value<String?> funcaoDescricao = const Value.absent(),
            Value<int?> idPapelFuncao = const Value.absent(),
            Value<String?> habilitado = const Value.absent(),
            Value<String?> podeInserir = const Value.absent(),
            Value<String?> podeAlterar = const Value.absent(),
            Value<String?> podeExcluir = const Value.absent(),
          }) =>
              ViewControleAcessosCompanion.insert(
            id: id,
            idPessoa: idPessoa,
            pessoaNome: pessoaNome,
            idColaborador: idColaborador,
            idUsuario: idUsuario,
            administrador: administrador,
            idPapel: idPapel,
            papelNome: papelNome,
            papelDescricao: papelDescricao,
            idFuncao: idFuncao,
            funcaoNome: funcaoNome,
            funcaoDescricao: funcaoDescricao,
            idPapelFuncao: idPapelFuncao,
            habilitado: habilitado,
            podeInserir: podeInserir,
            podeAlterar: podeAlterar,
            podeExcluir: podeExcluir,
          ),
        ));
}

class $$ViewControleAcessosTableFilterComposer
    extends FilterComposer<_$AppDatabase, $ViewControleAcessosTable> {
  $$ViewControleAcessosTableFilterComposer(super.$state);
  ColumnFilters<int> get id => $state.composableBuilder(
      column: $state.table.id,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<int> get idPessoa => $state.composableBuilder(
      column: $state.table.idPessoa,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get pessoaNome => $state.composableBuilder(
      column: $state.table.pessoaNome,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<int> get idColaborador => $state.composableBuilder(
      column: $state.table.idColaborador,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<int> get idUsuario => $state.composableBuilder(
      column: $state.table.idUsuario,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get administrador => $state.composableBuilder(
      column: $state.table.administrador,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<int> get idPapel => $state.composableBuilder(
      column: $state.table.idPapel,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get papelNome => $state.composableBuilder(
      column: $state.table.papelNome,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get papelDescricao => $state.composableBuilder(
      column: $state.table.papelDescricao,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<int> get idFuncao => $state.composableBuilder(
      column: $state.table.idFuncao,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get funcaoNome => $state.composableBuilder(
      column: $state.table.funcaoNome,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get funcaoDescricao => $state.composableBuilder(
      column: $state.table.funcaoDescricao,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<int> get idPapelFuncao => $state.composableBuilder(
      column: $state.table.idPapelFuncao,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get habilitado => $state.composableBuilder(
      column: $state.table.habilitado,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get podeInserir => $state.composableBuilder(
      column: $state.table.podeInserir,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get podeAlterar => $state.composableBuilder(
      column: $state.table.podeAlterar,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get podeExcluir => $state.composableBuilder(
      column: $state.table.podeExcluir,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));
}

class $$ViewControleAcessosTableOrderingComposer
    extends OrderingComposer<_$AppDatabase, $ViewControleAcessosTable> {
  $$ViewControleAcessosTableOrderingComposer(super.$state);
  ColumnOrderings<int> get id => $state.composableBuilder(
      column: $state.table.id,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<int> get idPessoa => $state.composableBuilder(
      column: $state.table.idPessoa,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get pessoaNome => $state.composableBuilder(
      column: $state.table.pessoaNome,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<int> get idColaborador => $state.composableBuilder(
      column: $state.table.idColaborador,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<int> get idUsuario => $state.composableBuilder(
      column: $state.table.idUsuario,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get administrador => $state.composableBuilder(
      column: $state.table.administrador,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<int> get idPapel => $state.composableBuilder(
      column: $state.table.idPapel,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get papelNome => $state.composableBuilder(
      column: $state.table.papelNome,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get papelDescricao => $state.composableBuilder(
      column: $state.table.papelDescricao,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<int> get idFuncao => $state.composableBuilder(
      column: $state.table.idFuncao,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get funcaoNome => $state.composableBuilder(
      column: $state.table.funcaoNome,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get funcaoDescricao => $state.composableBuilder(
      column: $state.table.funcaoDescricao,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<int> get idPapelFuncao => $state.composableBuilder(
      column: $state.table.idPapelFuncao,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get habilitado => $state.composableBuilder(
      column: $state.table.habilitado,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get podeInserir => $state.composableBuilder(
      column: $state.table.podeInserir,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get podeAlterar => $state.composableBuilder(
      column: $state.table.podeAlterar,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get podeExcluir => $state.composableBuilder(
      column: $state.table.podeExcluir,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));
}

typedef $$ViewPessoaUsuariosTableCreateCompanionBuilder
    = ViewPessoaUsuariosCompanion Function({
  Value<int?> id,
  Value<int?> idPessoa,
  Value<String?> pessoaNome,
  Value<String?> tipo,
  Value<String?> email,
  Value<int?> idColaborador,
  Value<int?> idUsuario,
  Value<String?> login,
  Value<String?> senha,
  Value<DateTime?> dataCadastro,
  Value<String?> administrador,
});
typedef $$ViewPessoaUsuariosTableUpdateCompanionBuilder
    = ViewPessoaUsuariosCompanion Function({
  Value<int?> id,
  Value<int?> idPessoa,
  Value<String?> pessoaNome,
  Value<String?> tipo,
  Value<String?> email,
  Value<int?> idColaborador,
  Value<int?> idUsuario,
  Value<String?> login,
  Value<String?> senha,
  Value<DateTime?> dataCadastro,
  Value<String?> administrador,
});

class $$ViewPessoaUsuariosTableTableManager extends RootTableManager<
    _$AppDatabase,
    $ViewPessoaUsuariosTable,
    ViewPessoaUsuario,
    $$ViewPessoaUsuariosTableFilterComposer,
    $$ViewPessoaUsuariosTableOrderingComposer,
    $$ViewPessoaUsuariosTableCreateCompanionBuilder,
    $$ViewPessoaUsuariosTableUpdateCompanionBuilder> {
  $$ViewPessoaUsuariosTableTableManager(
      _$AppDatabase db, $ViewPessoaUsuariosTable table)
      : super(TableManagerState(
          db: db,
          table: table,
          filteringComposer:
              $$ViewPessoaUsuariosTableFilterComposer(ComposerState(db, table)),
          orderingComposer: $$ViewPessoaUsuariosTableOrderingComposer(
              ComposerState(db, table)),
          updateCompanionCallback: ({
            Value<int?> id = const Value.absent(),
            Value<int?> idPessoa = const Value.absent(),
            Value<String?> pessoaNome = const Value.absent(),
            Value<String?> tipo = const Value.absent(),
            Value<String?> email = const Value.absent(),
            Value<int?> idColaborador = const Value.absent(),
            Value<int?> idUsuario = const Value.absent(),
            Value<String?> login = const Value.absent(),
            Value<String?> senha = const Value.absent(),
            Value<DateTime?> dataCadastro = const Value.absent(),
            Value<String?> administrador = const Value.absent(),
          }) =>
              ViewPessoaUsuariosCompanion(
            id: id,
            idPessoa: idPessoa,
            pessoaNome: pessoaNome,
            tipo: tipo,
            email: email,
            idColaborador: idColaborador,
            idUsuario: idUsuario,
            login: login,
            senha: senha,
            dataCadastro: dataCadastro,
            administrador: administrador,
          ),
          createCompanionCallback: ({
            Value<int?> id = const Value.absent(),
            Value<int?> idPessoa = const Value.absent(),
            Value<String?> pessoaNome = const Value.absent(),
            Value<String?> tipo = const Value.absent(),
            Value<String?> email = const Value.absent(),
            Value<int?> idColaborador = const Value.absent(),
            Value<int?> idUsuario = const Value.absent(),
            Value<String?> login = const Value.absent(),
            Value<String?> senha = const Value.absent(),
            Value<DateTime?> dataCadastro = const Value.absent(),
            Value<String?> administrador = const Value.absent(),
          }) =>
              ViewPessoaUsuariosCompanion.insert(
            id: id,
            idPessoa: idPessoa,
            pessoaNome: pessoaNome,
            tipo: tipo,
            email: email,
            idColaborador: idColaborador,
            idUsuario: idUsuario,
            login: login,
            senha: senha,
            dataCadastro: dataCadastro,
            administrador: administrador,
          ),
        ));
}

class $$ViewPessoaUsuariosTableFilterComposer
    extends FilterComposer<_$AppDatabase, $ViewPessoaUsuariosTable> {
  $$ViewPessoaUsuariosTableFilterComposer(super.$state);
  ColumnFilters<int> get id => $state.composableBuilder(
      column: $state.table.id,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<int> get idPessoa => $state.composableBuilder(
      column: $state.table.idPessoa,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get pessoaNome => $state.composableBuilder(
      column: $state.table.pessoaNome,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get tipo => $state.composableBuilder(
      column: $state.table.tipo,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get email => $state.composableBuilder(
      column: $state.table.email,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<int> get idColaborador => $state.composableBuilder(
      column: $state.table.idColaborador,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<int> get idUsuario => $state.composableBuilder(
      column: $state.table.idUsuario,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get login => $state.composableBuilder(
      column: $state.table.login,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get senha => $state.composableBuilder(
      column: $state.table.senha,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<DateTime> get dataCadastro => $state.composableBuilder(
      column: $state.table.dataCadastro,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get administrador => $state.composableBuilder(
      column: $state.table.administrador,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));
}

class $$ViewPessoaUsuariosTableOrderingComposer
    extends OrderingComposer<_$AppDatabase, $ViewPessoaUsuariosTable> {
  $$ViewPessoaUsuariosTableOrderingComposer(super.$state);
  ColumnOrderings<int> get id => $state.composableBuilder(
      column: $state.table.id,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<int> get idPessoa => $state.composableBuilder(
      column: $state.table.idPessoa,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get pessoaNome => $state.composableBuilder(
      column: $state.table.pessoaNome,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get tipo => $state.composableBuilder(
      column: $state.table.tipo,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get email => $state.composableBuilder(
      column: $state.table.email,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<int> get idColaborador => $state.composableBuilder(
      column: $state.table.idColaborador,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<int> get idUsuario => $state.composableBuilder(
      column: $state.table.idUsuario,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get login => $state.composableBuilder(
      column: $state.table.login,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get senha => $state.composableBuilder(
      column: $state.table.senha,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<DateTime> get dataCadastro => $state.composableBuilder(
      column: $state.table.dataCadastro,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get administrador => $state.composableBuilder(
      column: $state.table.administrador,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));
}

typedef $$ViewPessoaClientesTableCreateCompanionBuilder
    = ViewPessoaClientesCompanion Function({
  Value<int?> id,
  Value<String?> nome,
  Value<String?> tipo,
  Value<String?> email,
  Value<String?> site,
  Value<String?> cpfCnpj,
  Value<String?> rgIe,
  Value<DateTime?> desde,
  Value<double?> taxaDesconto,
  Value<double?> limiteCredito,
  Value<DateTime?> dataCadastro,
  Value<String?> observacao,
  Value<int?> idPessoa,
});
typedef $$ViewPessoaClientesTableUpdateCompanionBuilder
    = ViewPessoaClientesCompanion Function({
  Value<int?> id,
  Value<String?> nome,
  Value<String?> tipo,
  Value<String?> email,
  Value<String?> site,
  Value<String?> cpfCnpj,
  Value<String?> rgIe,
  Value<DateTime?> desde,
  Value<double?> taxaDesconto,
  Value<double?> limiteCredito,
  Value<DateTime?> dataCadastro,
  Value<String?> observacao,
  Value<int?> idPessoa,
});

class $$ViewPessoaClientesTableTableManager extends RootTableManager<
    _$AppDatabase,
    $ViewPessoaClientesTable,
    ViewPessoaCliente,
    $$ViewPessoaClientesTableFilterComposer,
    $$ViewPessoaClientesTableOrderingComposer,
    $$ViewPessoaClientesTableCreateCompanionBuilder,
    $$ViewPessoaClientesTableUpdateCompanionBuilder> {
  $$ViewPessoaClientesTableTableManager(
      _$AppDatabase db, $ViewPessoaClientesTable table)
      : super(TableManagerState(
          db: db,
          table: table,
          filteringComposer:
              $$ViewPessoaClientesTableFilterComposer(ComposerState(db, table)),
          orderingComposer: $$ViewPessoaClientesTableOrderingComposer(
              ComposerState(db, table)),
          updateCompanionCallback: ({
            Value<int?> id = const Value.absent(),
            Value<String?> nome = const Value.absent(),
            Value<String?> tipo = const Value.absent(),
            Value<String?> email = const Value.absent(),
            Value<String?> site = const Value.absent(),
            Value<String?> cpfCnpj = const Value.absent(),
            Value<String?> rgIe = const Value.absent(),
            Value<DateTime?> desde = const Value.absent(),
            Value<double?> taxaDesconto = const Value.absent(),
            Value<double?> limiteCredito = const Value.absent(),
            Value<DateTime?> dataCadastro = const Value.absent(),
            Value<String?> observacao = const Value.absent(),
            Value<int?> idPessoa = const Value.absent(),
          }) =>
              ViewPessoaClientesCompanion(
            id: id,
            nome: nome,
            tipo: tipo,
            email: email,
            site: site,
            cpfCnpj: cpfCnpj,
            rgIe: rgIe,
            desde: desde,
            taxaDesconto: taxaDesconto,
            limiteCredito: limiteCredito,
            dataCadastro: dataCadastro,
            observacao: observacao,
            idPessoa: idPessoa,
          ),
          createCompanionCallback: ({
            Value<int?> id = const Value.absent(),
            Value<String?> nome = const Value.absent(),
            Value<String?> tipo = const Value.absent(),
            Value<String?> email = const Value.absent(),
            Value<String?> site = const Value.absent(),
            Value<String?> cpfCnpj = const Value.absent(),
            Value<String?> rgIe = const Value.absent(),
            Value<DateTime?> desde = const Value.absent(),
            Value<double?> taxaDesconto = const Value.absent(),
            Value<double?> limiteCredito = const Value.absent(),
            Value<DateTime?> dataCadastro = const Value.absent(),
            Value<String?> observacao = const Value.absent(),
            Value<int?> idPessoa = const Value.absent(),
          }) =>
              ViewPessoaClientesCompanion.insert(
            id: id,
            nome: nome,
            tipo: tipo,
            email: email,
            site: site,
            cpfCnpj: cpfCnpj,
            rgIe: rgIe,
            desde: desde,
            taxaDesconto: taxaDesconto,
            limiteCredito: limiteCredito,
            dataCadastro: dataCadastro,
            observacao: observacao,
            idPessoa: idPessoa,
          ),
        ));
}

class $$ViewPessoaClientesTableFilterComposer
    extends FilterComposer<_$AppDatabase, $ViewPessoaClientesTable> {
  $$ViewPessoaClientesTableFilterComposer(super.$state);
  ColumnFilters<int> get id => $state.composableBuilder(
      column: $state.table.id,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get nome => $state.composableBuilder(
      column: $state.table.nome,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get tipo => $state.composableBuilder(
      column: $state.table.tipo,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get email => $state.composableBuilder(
      column: $state.table.email,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get site => $state.composableBuilder(
      column: $state.table.site,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get cpfCnpj => $state.composableBuilder(
      column: $state.table.cpfCnpj,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get rgIe => $state.composableBuilder(
      column: $state.table.rgIe,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<DateTime> get desde => $state.composableBuilder(
      column: $state.table.desde,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<double> get taxaDesconto => $state.composableBuilder(
      column: $state.table.taxaDesconto,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<double> get limiteCredito => $state.composableBuilder(
      column: $state.table.limiteCredito,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<DateTime> get dataCadastro => $state.composableBuilder(
      column: $state.table.dataCadastro,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get observacao => $state.composableBuilder(
      column: $state.table.observacao,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<int> get idPessoa => $state.composableBuilder(
      column: $state.table.idPessoa,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));
}

class $$ViewPessoaClientesTableOrderingComposer
    extends OrderingComposer<_$AppDatabase, $ViewPessoaClientesTable> {
  $$ViewPessoaClientesTableOrderingComposer(super.$state);
  ColumnOrderings<int> get id => $state.composableBuilder(
      column: $state.table.id,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get nome => $state.composableBuilder(
      column: $state.table.nome,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get tipo => $state.composableBuilder(
      column: $state.table.tipo,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get email => $state.composableBuilder(
      column: $state.table.email,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get site => $state.composableBuilder(
      column: $state.table.site,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get cpfCnpj => $state.composableBuilder(
      column: $state.table.cpfCnpj,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get rgIe => $state.composableBuilder(
      column: $state.table.rgIe,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<DateTime> get desde => $state.composableBuilder(
      column: $state.table.desde,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<double> get taxaDesconto => $state.composableBuilder(
      column: $state.table.taxaDesconto,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<double> get limiteCredito => $state.composableBuilder(
      column: $state.table.limiteCredito,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<DateTime> get dataCadastro => $state.composableBuilder(
      column: $state.table.dataCadastro,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get observacao => $state.composableBuilder(
      column: $state.table.observacao,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<int> get idPessoa => $state.composableBuilder(
      column: $state.table.idPessoa,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));
}

typedef $$ViewPessoaVendedorsTableCreateCompanionBuilder
    = ViewPessoaVendedorsCompanion Function({
  Value<int?> id,
  Value<String?> nome,
  Value<String?> tipo,
  Value<String?> email,
  Value<String?> site,
  Value<String?> cpfCnpj,
  Value<String?> rgIe,
  Value<String?> matricula,
  Value<DateTime?> dataCadastro,
  Value<DateTime?> dataAdmissao,
  Value<DateTime?> dataDemissao,
  Value<String?> ctpsNumero,
  Value<String?> ctpsSerie,
  Value<DateTime?> ctpsDataExpedicao,
  Value<String?> ctpsUf,
  Value<String?> observacao,
  Value<String?> logradouro,
  Value<String?> numero,
  Value<String?> complemento,
  Value<String?> bairro,
  Value<String?> cidade,
  Value<String?> cep,
  Value<String?> municipioIbge,
  Value<String?> uf,
  Value<int?> idPessoa,
  Value<int?> idCargo,
  Value<int?> idSetor,
  Value<double?> comissao,
  Value<double?> metaVenda,
});
typedef $$ViewPessoaVendedorsTableUpdateCompanionBuilder
    = ViewPessoaVendedorsCompanion Function({
  Value<int?> id,
  Value<String?> nome,
  Value<String?> tipo,
  Value<String?> email,
  Value<String?> site,
  Value<String?> cpfCnpj,
  Value<String?> rgIe,
  Value<String?> matricula,
  Value<DateTime?> dataCadastro,
  Value<DateTime?> dataAdmissao,
  Value<DateTime?> dataDemissao,
  Value<String?> ctpsNumero,
  Value<String?> ctpsSerie,
  Value<DateTime?> ctpsDataExpedicao,
  Value<String?> ctpsUf,
  Value<String?> observacao,
  Value<String?> logradouro,
  Value<String?> numero,
  Value<String?> complemento,
  Value<String?> bairro,
  Value<String?> cidade,
  Value<String?> cep,
  Value<String?> municipioIbge,
  Value<String?> uf,
  Value<int?> idPessoa,
  Value<int?> idCargo,
  Value<int?> idSetor,
  Value<double?> comissao,
  Value<double?> metaVenda,
});

class $$ViewPessoaVendedorsTableTableManager extends RootTableManager<
    _$AppDatabase,
    $ViewPessoaVendedorsTable,
    ViewPessoaVendedor,
    $$ViewPessoaVendedorsTableFilterComposer,
    $$ViewPessoaVendedorsTableOrderingComposer,
    $$ViewPessoaVendedorsTableCreateCompanionBuilder,
    $$ViewPessoaVendedorsTableUpdateCompanionBuilder> {
  $$ViewPessoaVendedorsTableTableManager(
      _$AppDatabase db, $ViewPessoaVendedorsTable table)
      : super(TableManagerState(
          db: db,
          table: table,
          filteringComposer: $$ViewPessoaVendedorsTableFilterComposer(
              ComposerState(db, table)),
          orderingComposer: $$ViewPessoaVendedorsTableOrderingComposer(
              ComposerState(db, table)),
          updateCompanionCallback: ({
            Value<int?> id = const Value.absent(),
            Value<String?> nome = const Value.absent(),
            Value<String?> tipo = const Value.absent(),
            Value<String?> email = const Value.absent(),
            Value<String?> site = const Value.absent(),
            Value<String?> cpfCnpj = const Value.absent(),
            Value<String?> rgIe = const Value.absent(),
            Value<String?> matricula = const Value.absent(),
            Value<DateTime?> dataCadastro = const Value.absent(),
            Value<DateTime?> dataAdmissao = const Value.absent(),
            Value<DateTime?> dataDemissao = const Value.absent(),
            Value<String?> ctpsNumero = const Value.absent(),
            Value<String?> ctpsSerie = const Value.absent(),
            Value<DateTime?> ctpsDataExpedicao = const Value.absent(),
            Value<String?> ctpsUf = const Value.absent(),
            Value<String?> observacao = const Value.absent(),
            Value<String?> logradouro = const Value.absent(),
            Value<String?> numero = const Value.absent(),
            Value<String?> complemento = const Value.absent(),
            Value<String?> bairro = const Value.absent(),
            Value<String?> cidade = const Value.absent(),
            Value<String?> cep = const Value.absent(),
            Value<String?> municipioIbge = const Value.absent(),
            Value<String?> uf = const Value.absent(),
            Value<int?> idPessoa = const Value.absent(),
            Value<int?> idCargo = const Value.absent(),
            Value<int?> idSetor = const Value.absent(),
            Value<double?> comissao = const Value.absent(),
            Value<double?> metaVenda = const Value.absent(),
          }) =>
              ViewPessoaVendedorsCompanion(
            id: id,
            nome: nome,
            tipo: tipo,
            email: email,
            site: site,
            cpfCnpj: cpfCnpj,
            rgIe: rgIe,
            matricula: matricula,
            dataCadastro: dataCadastro,
            dataAdmissao: dataAdmissao,
            dataDemissao: dataDemissao,
            ctpsNumero: ctpsNumero,
            ctpsSerie: ctpsSerie,
            ctpsDataExpedicao: ctpsDataExpedicao,
            ctpsUf: ctpsUf,
            observacao: observacao,
            logradouro: logradouro,
            numero: numero,
            complemento: complemento,
            bairro: bairro,
            cidade: cidade,
            cep: cep,
            municipioIbge: municipioIbge,
            uf: uf,
            idPessoa: idPessoa,
            idCargo: idCargo,
            idSetor: idSetor,
            comissao: comissao,
            metaVenda: metaVenda,
          ),
          createCompanionCallback: ({
            Value<int?> id = const Value.absent(),
            Value<String?> nome = const Value.absent(),
            Value<String?> tipo = const Value.absent(),
            Value<String?> email = const Value.absent(),
            Value<String?> site = const Value.absent(),
            Value<String?> cpfCnpj = const Value.absent(),
            Value<String?> rgIe = const Value.absent(),
            Value<String?> matricula = const Value.absent(),
            Value<DateTime?> dataCadastro = const Value.absent(),
            Value<DateTime?> dataAdmissao = const Value.absent(),
            Value<DateTime?> dataDemissao = const Value.absent(),
            Value<String?> ctpsNumero = const Value.absent(),
            Value<String?> ctpsSerie = const Value.absent(),
            Value<DateTime?> ctpsDataExpedicao = const Value.absent(),
            Value<String?> ctpsUf = const Value.absent(),
            Value<String?> observacao = const Value.absent(),
            Value<String?> logradouro = const Value.absent(),
            Value<String?> numero = const Value.absent(),
            Value<String?> complemento = const Value.absent(),
            Value<String?> bairro = const Value.absent(),
            Value<String?> cidade = const Value.absent(),
            Value<String?> cep = const Value.absent(),
            Value<String?> municipioIbge = const Value.absent(),
            Value<String?> uf = const Value.absent(),
            Value<int?> idPessoa = const Value.absent(),
            Value<int?> idCargo = const Value.absent(),
            Value<int?> idSetor = const Value.absent(),
            Value<double?> comissao = const Value.absent(),
            Value<double?> metaVenda = const Value.absent(),
          }) =>
              ViewPessoaVendedorsCompanion.insert(
            id: id,
            nome: nome,
            tipo: tipo,
            email: email,
            site: site,
            cpfCnpj: cpfCnpj,
            rgIe: rgIe,
            matricula: matricula,
            dataCadastro: dataCadastro,
            dataAdmissao: dataAdmissao,
            dataDemissao: dataDemissao,
            ctpsNumero: ctpsNumero,
            ctpsSerie: ctpsSerie,
            ctpsDataExpedicao: ctpsDataExpedicao,
            ctpsUf: ctpsUf,
            observacao: observacao,
            logradouro: logradouro,
            numero: numero,
            complemento: complemento,
            bairro: bairro,
            cidade: cidade,
            cep: cep,
            municipioIbge: municipioIbge,
            uf: uf,
            idPessoa: idPessoa,
            idCargo: idCargo,
            idSetor: idSetor,
            comissao: comissao,
            metaVenda: metaVenda,
          ),
        ));
}

class $$ViewPessoaVendedorsTableFilterComposer
    extends FilterComposer<_$AppDatabase, $ViewPessoaVendedorsTable> {
  $$ViewPessoaVendedorsTableFilterComposer(super.$state);
  ColumnFilters<int> get id => $state.composableBuilder(
      column: $state.table.id,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get nome => $state.composableBuilder(
      column: $state.table.nome,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get tipo => $state.composableBuilder(
      column: $state.table.tipo,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get email => $state.composableBuilder(
      column: $state.table.email,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get site => $state.composableBuilder(
      column: $state.table.site,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get cpfCnpj => $state.composableBuilder(
      column: $state.table.cpfCnpj,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get rgIe => $state.composableBuilder(
      column: $state.table.rgIe,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get matricula => $state.composableBuilder(
      column: $state.table.matricula,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<DateTime> get dataCadastro => $state.composableBuilder(
      column: $state.table.dataCadastro,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<DateTime> get dataAdmissao => $state.composableBuilder(
      column: $state.table.dataAdmissao,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<DateTime> get dataDemissao => $state.composableBuilder(
      column: $state.table.dataDemissao,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get ctpsNumero => $state.composableBuilder(
      column: $state.table.ctpsNumero,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get ctpsSerie => $state.composableBuilder(
      column: $state.table.ctpsSerie,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<DateTime> get ctpsDataExpedicao => $state.composableBuilder(
      column: $state.table.ctpsDataExpedicao,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get ctpsUf => $state.composableBuilder(
      column: $state.table.ctpsUf,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get observacao => $state.composableBuilder(
      column: $state.table.observacao,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get logradouro => $state.composableBuilder(
      column: $state.table.logradouro,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get numero => $state.composableBuilder(
      column: $state.table.numero,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get complemento => $state.composableBuilder(
      column: $state.table.complemento,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get bairro => $state.composableBuilder(
      column: $state.table.bairro,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get cidade => $state.composableBuilder(
      column: $state.table.cidade,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get cep => $state.composableBuilder(
      column: $state.table.cep,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get municipioIbge => $state.composableBuilder(
      column: $state.table.municipioIbge,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get uf => $state.composableBuilder(
      column: $state.table.uf,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<int> get idPessoa => $state.composableBuilder(
      column: $state.table.idPessoa,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<int> get idCargo => $state.composableBuilder(
      column: $state.table.idCargo,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<int> get idSetor => $state.composableBuilder(
      column: $state.table.idSetor,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<double> get comissao => $state.composableBuilder(
      column: $state.table.comissao,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<double> get metaVenda => $state.composableBuilder(
      column: $state.table.metaVenda,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));
}

class $$ViewPessoaVendedorsTableOrderingComposer
    extends OrderingComposer<_$AppDatabase, $ViewPessoaVendedorsTable> {
  $$ViewPessoaVendedorsTableOrderingComposer(super.$state);
  ColumnOrderings<int> get id => $state.composableBuilder(
      column: $state.table.id,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get nome => $state.composableBuilder(
      column: $state.table.nome,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get tipo => $state.composableBuilder(
      column: $state.table.tipo,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get email => $state.composableBuilder(
      column: $state.table.email,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get site => $state.composableBuilder(
      column: $state.table.site,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get cpfCnpj => $state.composableBuilder(
      column: $state.table.cpfCnpj,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get rgIe => $state.composableBuilder(
      column: $state.table.rgIe,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get matricula => $state.composableBuilder(
      column: $state.table.matricula,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<DateTime> get dataCadastro => $state.composableBuilder(
      column: $state.table.dataCadastro,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<DateTime> get dataAdmissao => $state.composableBuilder(
      column: $state.table.dataAdmissao,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<DateTime> get dataDemissao => $state.composableBuilder(
      column: $state.table.dataDemissao,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get ctpsNumero => $state.composableBuilder(
      column: $state.table.ctpsNumero,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get ctpsSerie => $state.composableBuilder(
      column: $state.table.ctpsSerie,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<DateTime> get ctpsDataExpedicao => $state.composableBuilder(
      column: $state.table.ctpsDataExpedicao,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get ctpsUf => $state.composableBuilder(
      column: $state.table.ctpsUf,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get observacao => $state.composableBuilder(
      column: $state.table.observacao,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get logradouro => $state.composableBuilder(
      column: $state.table.logradouro,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get numero => $state.composableBuilder(
      column: $state.table.numero,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get complemento => $state.composableBuilder(
      column: $state.table.complemento,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get bairro => $state.composableBuilder(
      column: $state.table.bairro,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get cidade => $state.composableBuilder(
      column: $state.table.cidade,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get cep => $state.composableBuilder(
      column: $state.table.cep,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get municipioIbge => $state.composableBuilder(
      column: $state.table.municipioIbge,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get uf => $state.composableBuilder(
      column: $state.table.uf,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<int> get idPessoa => $state.composableBuilder(
      column: $state.table.idPessoa,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<int> get idCargo => $state.composableBuilder(
      column: $state.table.idCargo,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<int> get idSetor => $state.composableBuilder(
      column: $state.table.idSetor,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<double> get comissao => $state.composableBuilder(
      column: $state.table.comissao,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<double> get metaVenda => $state.composableBuilder(
      column: $state.table.metaVenda,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));
}

typedef $$ViewPessoaTransportadorasTableCreateCompanionBuilder
    = ViewPessoaTransportadorasCompanion Function({
  Value<int?> id,
  Value<String?> nome,
  Value<String?> tipo,
  Value<String?> email,
  Value<String?> site,
  Value<String?> cpfCnpj,
  Value<String?> rgIe,
  Value<DateTime?> dataCadastro,
  Value<String?> observacao,
  Value<int?> idPessoa,
});
typedef $$ViewPessoaTransportadorasTableUpdateCompanionBuilder
    = ViewPessoaTransportadorasCompanion Function({
  Value<int?> id,
  Value<String?> nome,
  Value<String?> tipo,
  Value<String?> email,
  Value<String?> site,
  Value<String?> cpfCnpj,
  Value<String?> rgIe,
  Value<DateTime?> dataCadastro,
  Value<String?> observacao,
  Value<int?> idPessoa,
});

class $$ViewPessoaTransportadorasTableTableManager extends RootTableManager<
    _$AppDatabase,
    $ViewPessoaTransportadorasTable,
    ViewPessoaTransportadora,
    $$ViewPessoaTransportadorasTableFilterComposer,
    $$ViewPessoaTransportadorasTableOrderingComposer,
    $$ViewPessoaTransportadorasTableCreateCompanionBuilder,
    $$ViewPessoaTransportadorasTableUpdateCompanionBuilder> {
  $$ViewPessoaTransportadorasTableTableManager(
      _$AppDatabase db, $ViewPessoaTransportadorasTable table)
      : super(TableManagerState(
          db: db,
          table: table,
          filteringComposer: $$ViewPessoaTransportadorasTableFilterComposer(
              ComposerState(db, table)),
          orderingComposer: $$ViewPessoaTransportadorasTableOrderingComposer(
              ComposerState(db, table)),
          updateCompanionCallback: ({
            Value<int?> id = const Value.absent(),
            Value<String?> nome = const Value.absent(),
            Value<String?> tipo = const Value.absent(),
            Value<String?> email = const Value.absent(),
            Value<String?> site = const Value.absent(),
            Value<String?> cpfCnpj = const Value.absent(),
            Value<String?> rgIe = const Value.absent(),
            Value<DateTime?> dataCadastro = const Value.absent(),
            Value<String?> observacao = const Value.absent(),
            Value<int?> idPessoa = const Value.absent(),
          }) =>
              ViewPessoaTransportadorasCompanion(
            id: id,
            nome: nome,
            tipo: tipo,
            email: email,
            site: site,
            cpfCnpj: cpfCnpj,
            rgIe: rgIe,
            dataCadastro: dataCadastro,
            observacao: observacao,
            idPessoa: idPessoa,
          ),
          createCompanionCallback: ({
            Value<int?> id = const Value.absent(),
            Value<String?> nome = const Value.absent(),
            Value<String?> tipo = const Value.absent(),
            Value<String?> email = const Value.absent(),
            Value<String?> site = const Value.absent(),
            Value<String?> cpfCnpj = const Value.absent(),
            Value<String?> rgIe = const Value.absent(),
            Value<DateTime?> dataCadastro = const Value.absent(),
            Value<String?> observacao = const Value.absent(),
            Value<int?> idPessoa = const Value.absent(),
          }) =>
              ViewPessoaTransportadorasCompanion.insert(
            id: id,
            nome: nome,
            tipo: tipo,
            email: email,
            site: site,
            cpfCnpj: cpfCnpj,
            rgIe: rgIe,
            dataCadastro: dataCadastro,
            observacao: observacao,
            idPessoa: idPessoa,
          ),
        ));
}

class $$ViewPessoaTransportadorasTableFilterComposer
    extends FilterComposer<_$AppDatabase, $ViewPessoaTransportadorasTable> {
  $$ViewPessoaTransportadorasTableFilterComposer(super.$state);
  ColumnFilters<int> get id => $state.composableBuilder(
      column: $state.table.id,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get nome => $state.composableBuilder(
      column: $state.table.nome,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get tipo => $state.composableBuilder(
      column: $state.table.tipo,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get email => $state.composableBuilder(
      column: $state.table.email,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get site => $state.composableBuilder(
      column: $state.table.site,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get cpfCnpj => $state.composableBuilder(
      column: $state.table.cpfCnpj,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get rgIe => $state.composableBuilder(
      column: $state.table.rgIe,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<DateTime> get dataCadastro => $state.composableBuilder(
      column: $state.table.dataCadastro,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get observacao => $state.composableBuilder(
      column: $state.table.observacao,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<int> get idPessoa => $state.composableBuilder(
      column: $state.table.idPessoa,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));
}

class $$ViewPessoaTransportadorasTableOrderingComposer
    extends OrderingComposer<_$AppDatabase, $ViewPessoaTransportadorasTable> {
  $$ViewPessoaTransportadorasTableOrderingComposer(super.$state);
  ColumnOrderings<int> get id => $state.composableBuilder(
      column: $state.table.id,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get nome => $state.composableBuilder(
      column: $state.table.nome,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get tipo => $state.composableBuilder(
      column: $state.table.tipo,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get email => $state.composableBuilder(
      column: $state.table.email,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get site => $state.composableBuilder(
      column: $state.table.site,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get cpfCnpj => $state.composableBuilder(
      column: $state.table.cpfCnpj,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get rgIe => $state.composableBuilder(
      column: $state.table.rgIe,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<DateTime> get dataCadastro => $state.composableBuilder(
      column: $state.table.dataCadastro,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get observacao => $state.composableBuilder(
      column: $state.table.observacao,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<int> get idPessoa => $state.composableBuilder(
      column: $state.table.idPessoa,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));
}

class $AppDatabaseManager {
  final _$AppDatabase _db;
  $AppDatabaseManager(this._db);
  $$ProdutosTableTableManager get produtos =>
      $$ProdutosTableTableManager(_db, _db.produtos);
  $$VendaOrcamentoDetalhesTableTableManager get vendaOrcamentoDetalhes =>
      $$VendaOrcamentoDetalhesTableTableManager(
          _db, _db.vendaOrcamentoDetalhes);
  $$VendaDetalhesTableTableManager get vendaDetalhes =>
      $$VendaDetalhesTableTableManager(_db, _db.vendaDetalhes);
  $$VendaCondicoesParcelassTableTableManager get vendaCondicoesParcelass =>
      $$VendaCondicoesParcelassTableTableManager(
          _db, _db.vendaCondicoesParcelass);
  $$VendaFretesTableTableManager get vendaFretes =>
      $$VendaFretesTableTableManager(_db, _db.vendaFretes);
  $$VendaComissaosTableTableManager get vendaComissaos =>
      $$VendaComissaosTableTableManager(_db, _db.vendaComissaos);
  $$ProdutoGruposTableTableManager get produtoGrupos =>
      $$ProdutoGruposTableTableManager(_db, _db.produtoGrupos);
  $$ProdutoSubgruposTableTableManager get produtoSubgrupos =>
      $$ProdutoSubgruposTableTableManager(_db, _db.produtoSubgrupos);
  $$ProdutoMarcasTableTableManager get produtoMarcas =>
      $$ProdutoMarcasTableTableManager(_db, _db.produtoMarcas);
  $$ProdutoUnidadesTableTableManager get produtoUnidades =>
      $$ProdutoUnidadesTableTableManager(_db, _db.produtoUnidades);
  $$VendaCondicoesPagamentosTableTableManager get vendaCondicoesPagamentos =>
      $$VendaCondicoesPagamentosTableTableManager(
          _db, _db.vendaCondicoesPagamentos);
  $$VendaOrcamentoCabecalhosTableTableManager get vendaOrcamentoCabecalhos =>
      $$VendaOrcamentoCabecalhosTableTableManager(
          _db, _db.vendaOrcamentoCabecalhos);
  $$VendaCabecalhosTableTableManager get vendaCabecalhos =>
      $$VendaCabecalhosTableTableManager(_db, _db.vendaCabecalhos);
  $$NotaFiscalModelosTableTableManager get notaFiscalModelos =>
      $$NotaFiscalModelosTableTableManager(_db, _db.notaFiscalModelos);
  $$NotaFiscalTiposTableTableManager get notaFiscalTipos =>
      $$NotaFiscalTiposTableTableManager(_db, _db.notaFiscalTipos);
  $$ViewControleAcessosTableTableManager get viewControleAcessos =>
      $$ViewControleAcessosTableTableManager(_db, _db.viewControleAcessos);
  $$ViewPessoaUsuariosTableTableManager get viewPessoaUsuarios =>
      $$ViewPessoaUsuariosTableTableManager(_db, _db.viewPessoaUsuarios);
  $$ViewPessoaClientesTableTableManager get viewPessoaClientes =>
      $$ViewPessoaClientesTableTableManager(_db, _db.viewPessoaClientes);
  $$ViewPessoaVendedorsTableTableManager get viewPessoaVendedors =>
      $$ViewPessoaVendedorsTableTableManager(_db, _db.viewPessoaVendedors);
  $$ViewPessoaTransportadorasTableTableManager get viewPessoaTransportadoras =>
      $$ViewPessoaTransportadorasTableTableManager(
          _db, _db.viewPessoaTransportadoras);
}
