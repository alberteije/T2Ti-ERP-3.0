// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'venda_condicoes_pagamento_dao.dart';

// ignore_for_file: type=lint
mixin _$VendaCondicoesPagamentoDaoMixin on DatabaseAccessor<AppDatabase> {
  $VendaCondicoesPagamentosTable get vendaCondicoesPagamentos =>
      attachedDatabase.vendaCondicoesPagamentos;
  $VendaCondicoesParcelassTable get vendaCondicoesParcelass =>
      attachedDatabase.vendaCondicoesParcelass;
}
