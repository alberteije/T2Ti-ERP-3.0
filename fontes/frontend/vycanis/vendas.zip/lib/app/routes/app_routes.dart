abstract class Routes{
	
	static const splashPage = '/splashPage';
	static const loginPage = '/loginPage';
	static const homePage = '/homePage';
	static const filterPage = '/filterPage';
	static const lookupPage = '/lookupPage';
  static const menuModulesPage = '/menuModulesPage';
		
	static const vendaCondicoesPagamentoListPage = '/vendaCondicoesPagamentoListPage'; 
	static const vendaCondicoesPagamentoTabPage = '/vendaCondicoesPagamentoTabPage';
	static const vendaOrcamentoCabecalhoListPage = '/vendaOrcamentoCabecalhoListPage'; 
	static const vendaOrcamentoCabecalhoTabPage = '/vendaOrcamentoCabecalhoTabPage';
	static const vendaCabecalhoListPage = '/vendaCabecalhoListPage'; 
	static const vendaCabecalhoTabPage = '/vendaCabecalhoTabPage';
	static const notaFiscalTipoListPage = '/notaFiscalTipoListPage'; 
	static const notaFiscalTipoEditPage = '/notaFiscalTipoEditPage';
}