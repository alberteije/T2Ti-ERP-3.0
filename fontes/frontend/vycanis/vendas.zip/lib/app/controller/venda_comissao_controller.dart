import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:extended_masked_text/extended_masked_text.dart';
import 'package:vendas/app/page/grid_columns/grid_columns_imports.dart';
import 'package:vendas/app/page/shared_widget/message_dialog.dart';
import 'package:vendas/app/routes/app_routes.dart';
import 'package:vendas/app/infra/infra_imports.dart';
import 'package:vendas/app/controller/controller_imports.dart';
import 'package:vendas/app/data/model/model_imports.dart';

class VendaComissaoController extends ControllerBase<VendaComissaoModel, void> {

  VendaComissaoController() : super(repository: null) {
    dbColumns = VendaComissaoModel.dbColumns;
    aliasColumns = VendaComissaoModel.aliasColumns;
    functionName = "venda_comissao";
    screenTitle = "Comissão";
  }

	String? mandatoryMessage;

  final _vendaComissaoModel = VendaComissaoModel().obs;
  VendaComissaoModel get vendaComissaoModel => Get.find<VendaCabecalhoController>().currentModel.vendaComissaoModel ?? VendaComissaoModel();
  set vendaComissaoModel(value) => _vendaComissaoModel.value = value ?? VendaComissaoModel();

  final _formWasChangedDetail = false.obs;
  bool get formWasChangedDetail => _formWasChangedDetail.value;
  set formWasChangedDetail(value) => _formWasChangedDetail.value = value;

  final vendaComissaoScaffoldKey = GlobalKey<ScaffoldState>();
  final vendaComissaoFormKey = GlobalKey<FormState>();

  @override
  VendaComissaoModel createNewModel() => VendaComissaoModel();

  @override
  final standardFieldForFilter = "";

  final viewPessoaVendedorModelController = TextEditingController();
  final valorVendaController = MoneyMaskedTextController();
  final valorComissaoController = MoneyMaskedTextController();

  final Map<String, dynamic> mobileConfig = {};

  List<Map<String, dynamic>> get mobileItems {
    return modelList.map((vendaComissao) => vendaComissao.toJson).toList();
  }

  @override
  Future<void> getList({Filter? filter}) async {}

  @override
  Future<void> loadData() async {}

  @override
  void prepareForInsert() {}

  @override
  void selectRowForEditingById(int id) {}

  void _resetForm() {
    formWasChangedDetail = false;
    viewPessoaVendedorModelController.text = '';
    valorVendaController.updateValue(0);
    valorComissaoController.updateValue(0);
  }

  void updateControllersFromModel() {
		_resetForm();
    viewPessoaVendedorModelController.text = vendaComissaoModel.viewPessoaVendedorModel?.nome?.toString() ?? '';
    valorVendaController.updateValue(vendaComissaoModel.valorVenda ?? 0);
    valorComissaoController.updateValue(vendaComissaoModel.valorComissao ?? 0);
  }

  @override
  Future<void> save() async {}

	bool validateForm() {
    mandatoryMessage = ValidateFormField.validateMandatory(vendaComissaoModel.viewPessoaVendedorModel?.nome); 
		if (mandatoryMessage != null) { 
			showErrorSnackBar(message: '$mandatoryMessage [Id Vendedor]'); 
			return false; 
		}
    return true;
	}

  Future callViewPessoaVendedorLookup() async { 
		final lookupController = Get.find<LookupController>(); 
		lookupController.refreshItems(standardValue: '%'); 
		lookupController.title = '${'lookup_page_title'.tr} [Id Vendedor]'; 
		lookupController.route = '/view-pessoa-vendedor/'; 
		lookupController.gridColumns = viewPessoaVendedorGridColumns(isForLookup: true); 
		lookupController.aliasColumns = ViewPessoaVendedorModel.aliasColumns; 
		lookupController.dbColumns = ViewPessoaVendedorModel.dbColumns; 
		lookupController.standardColumn = ViewPessoaVendedorModel.aliasColumns[ViewPessoaVendedorModel.dbColumns.indexOf('nome')]; 

		final plutoRowResult = await Get.toNamed(Routes.lookupPage); 
		if (plutoRowResult != null) { 
			vendaComissaoModel.idVendedor = plutoRowResult.cells['id']!.value; 
			vendaComissaoModel.viewPessoaVendedorModel = ViewPessoaVendedorModel.fromPlutoRow(plutoRowResult); 
			viewPessoaVendedorModelController.text = vendaComissaoModel.viewPessoaVendedorModel?.nome ?? ''; 
			formWasChanged = true; 
		}
	}


  @override
  void onClose() {
    viewPessoaVendedorModelController.dispose();
    valorVendaController.dispose();
    valorComissaoController.dispose();
  }

}