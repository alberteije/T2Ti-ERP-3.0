import 'package:flutter/material.dart';
import 'dart:math';
import 'package:get/get.dart';
import 'package:extended_masked_text/extended_masked_text.dart';

import 'package:vendas/app/infra/infra_imports.dart';
import 'package:vendas/app/page/page_imports.dart';
import 'package:vendas/app/page/shared_widget/message_dialog.dart';
import 'package:vendas/app/page/grid_columns/grid_columns_imports.dart';
import 'package:vendas/app/routes/app_routes.dart';
import 'package:vendas/app/controller/controller_imports.dart';
import 'package:vendas/app/data/model/model_imports.dart';
import 'package:vendas/app/data/repository/venda_orcamento_cabecalho_repository.dart';

class VendaOrcamentoCabecalhoController extends ControllerBase<VendaOrcamentoCabecalhoModel, VendaOrcamentoCabecalhoRepository> 
with GetSingleTickerProviderStateMixin {

  VendaOrcamentoCabecalhoController({required super.repository}) {
    dbColumns = VendaOrcamentoCabecalhoModel.dbColumns;
    aliasColumns = VendaOrcamentoCabecalhoModel.aliasColumns;
    gridColumns = vendaOrcamentoCabecalhoGridColumns();
    functionName = "venda_orcamento_cabecalho";
    screenTitle = "Orçamento de Venda";
  }

  final vendaOrcamentoCabecalhoScaffoldKey = GlobalKey<ScaffoldState>();
  final vendaOrcamentoCabecalhoTabPageScaffoldKey = GlobalKey<ScaffoldState>();
  final vendaOrcamentoCabecalhoFormKey = GlobalKey<FormState>();
  late TabController tabController;
  String? mandatoryMessage;  

  @override
  VendaOrcamentoCabecalhoModel createNewModel() => VendaOrcamentoCabecalhoModel();

  @override
  final standardFieldForFilter = VendaOrcamentoCabecalhoModel.aliasColumns[VendaOrcamentoCabecalhoModel.dbColumns.indexOf('tipo_frete')];

  final viewPessoaVendedorModelController = TextEditingController();
  final viewPessoaClienteModelController = TextEditingController();
  final vendaCondicoesPagamentoModelController = TextEditingController();
  final viewPessoaTransportadoraModelController = TextEditingController();
  final codigoController = TextEditingController();
  final valorSubtotalController = MoneyMaskedTextController();
  final valorFreteController = MoneyMaskedTextController();
  final taxaComissaoController = MoneyMaskedTextController();
  final valorComissaoController = MoneyMaskedTextController();
  final taxaDescontoController = MoneyMaskedTextController();
  final valorDescontoController = MoneyMaskedTextController();
  final valorTotalController = MoneyMaskedTextController();
  final observacaoController = TextEditingController();

  final Map<String, dynamic> mobileConfig = {
    'primaryColumns': ['tipo_frete'],
    'secondaryColumns': ['codigo'],
  };

  List<Map<String, dynamic>> get mobileItems {
    return modelList.map((vendaOrcamentoCabecalho) => vendaOrcamentoCabecalho.toJson).toList();
  }

  @override
  void prepareForInsert() {
    isNewRecord = true;
    currentModel = createNewModel();
    _resetForm();
    tabController.animateTo(0);
    _configureChildrenControllers();
    Get.toNamed(Routes.vendaOrcamentoCabecalhoTabPage);
  }

  void _resetForm() {
    formWasChanged = false;
    viewPessoaVendedorModelController.text = '';
    viewPessoaClienteModelController.text = '';
    vendaCondicoesPagamentoModelController.text = '';
    viewPessoaTransportadoraModelController.text = '';
    codigoController.text = '';
    valorSubtotalController.updateValue(0);
    valorFreteController.updateValue(0);
    taxaComissaoController.updateValue(0);
    valorComissaoController.updateValue(0);
    taxaDescontoController.updateValue(0);
    valorDescontoController.updateValue(0);
    valorTotalController.updateValue(0);
    observacaoController.text = '';
  }

  @override
  void selectRowForEditingById(int id) {
    final model = modelList.firstWhere((m) => m.id == id);
    currentModel = model.clone();
    updateControllersFromModel();

    tabController.animateTo(0);
    _configureChildrenControllers();
    Get.toNamed(Routes.vendaOrcamentoCabecalhoTabPage);
  }

  _configureChildrenControllers() {
    //Itens do Orçamento
		Get.put<VendaOrcamentoDetalheController>(VendaOrcamentoDetalheController()); 
		final vendaOrcamentoDetalheController = Get.find<VendaOrcamentoDetalheController>(); 
		vendaOrcamentoDetalheController.userMadeChanges = false; 

  }
  
  void updateControllersFromModel() {
    viewPessoaVendedorModelController.text = currentModel.viewPessoaVendedorModel?.nome?.toString() ?? '';
    viewPessoaClienteModelController.text = currentModel.viewPessoaClienteModel?.nome?.toString() ?? '';
    vendaCondicoesPagamentoModelController.text = currentModel.vendaCondicoesPagamentoModel?.nome?.toString() ?? '';
    viewPessoaTransportadoraModelController.text = currentModel.viewPessoaTransportadoraModel?.nome?.toString() ?? '';
    codigoController.text = currentModel.codigo ?? '';
    valorSubtotalController.updateValue(currentModel.valorSubtotal ?? 0);
    valorFreteController.updateValue(currentModel.valorFrete ?? 0);
    taxaComissaoController.updateValue(currentModel.taxaComissao ?? 0);
    valorComissaoController.updateValue(currentModel.valorComissao ?? 0);
    taxaDescontoController.updateValue(currentModel.taxaDesconto ?? 0);
    valorDescontoController.updateValue(currentModel.valorDesconto ?? 0);
    valorTotalController.updateValue(currentModel.valorTotal ?? 0);
    observacaoController.text = currentModel.observacao ?? '';
    formWasChanged = false;
  }

  @override
  Future<void> save() async {
    if (!validateCurrentForm()) return;
    if (validateForms()) {
      if (userMadeChanges()) {
        final existingIndex = modelList.indexWhere((m) => m.id == currentModel.id);

        if (existingIndex >= 0) {
          modelList[existingIndex] = currentModel.clone();
        }

        final result = await repository.save(vendaOrcamentoCabecalhoModel: currentModel);
        if (result == null) return;

        if (existingIndex >= 0) {
          modelList[existingIndex] = result;
        } else {
          modelList.insert(0, result);
        }

        if (!GetPlatform.isMobile) {
          updateGridRow(result);
        }

        Get.back(result: true);
      } else {
        Get.back();
      }
    } 
  }

  Future callViewPessoaVendedorLookup() async { 
		final lookupController = Get.find<LookupController>(); 
		lookupController.refreshItems(standardValue: '%'); 
		lookupController.title = '${'lookup_page_title'.tr} [Vendedor]'; 
		lookupController.route = '/view-pessoa-vendedor/'; 
		lookupController.gridColumns = viewPessoaVendedorGridColumns(isForLookup: true); 
		lookupController.aliasColumns = ViewPessoaVendedorModel.aliasColumns; 
		lookupController.dbColumns = ViewPessoaVendedorModel.dbColumns; 
		lookupController.standardColumn = ViewPessoaVendedorModel.aliasColumns[ViewPessoaVendedorModel.dbColumns.indexOf('nome')]; 

		final plutoRowResult = await Get.toNamed(Routes.lookupPage); 
		if (plutoRowResult != null) { 
			currentModel.idVendedor = plutoRowResult.cells['id']!.value; 
			currentModel.viewPessoaVendedorModel = ViewPessoaVendedorModel.fromPlutoRow(plutoRowResult); 
			viewPessoaVendedorModelController.text = currentModel.viewPessoaVendedorModel?.nome ?? ''; 
			formWasChanged = true; 
		}
	}

  Future callViewPessoaClienteLookup() async { 
		final lookupController = Get.find<LookupController>(); 
		lookupController.refreshItems(standardValue: '%'); 
		lookupController.title = '${'lookup_page_title'.tr} [Cliente]'; 
		lookupController.route = '/view-pessoa-cliente/'; 
		lookupController.gridColumns = viewPessoaClienteGridColumns(isForLookup: true); 
		lookupController.aliasColumns = ViewPessoaClienteModel.aliasColumns; 
		lookupController.dbColumns = ViewPessoaClienteModel.dbColumns; 
		lookupController.standardColumn = ViewPessoaClienteModel.aliasColumns[ViewPessoaClienteModel.dbColumns.indexOf('nome')]; 

		final plutoRowResult = await Get.toNamed(Routes.lookupPage); 
		if (plutoRowResult != null) { 
			currentModel.idCliente = plutoRowResult.cells['id']!.value; 
			currentModel.viewPessoaClienteModel = ViewPessoaClienteModel.fromPlutoRow(plutoRowResult); 
			viewPessoaClienteModelController.text = currentModel.viewPessoaClienteModel?.nome ?? ''; 
			formWasChanged = true; 
		}
	}

  Future callVendaCondicoesPagamentoLookup() async { 
		final lookupController = Get.find<LookupController>(); 
		lookupController.refreshItems(standardValue: '%'); 
		lookupController.title = '${'lookup_page_title'.tr} [Condicoes Pagamento]'; 
		lookupController.route = '/venda-condicoes-pagamento/'; 
		lookupController.gridColumns = vendaCondicoesPagamentoGridColumns(isForLookup: true); 
		lookupController.aliasColumns = VendaCondicoesPagamentoModel.aliasColumns; 
		lookupController.dbColumns = VendaCondicoesPagamentoModel.dbColumns; 
		lookupController.standardColumn = VendaCondicoesPagamentoModel.aliasColumns[VendaCondicoesPagamentoModel.dbColumns.indexOf('nome')]; 

		final plutoRowResult = await Get.toNamed(Routes.lookupPage); 
		if (plutoRowResult != null) { 
			currentModel.idVendaCondicoesPagamento = plutoRowResult.cells['id']!.value; 
			currentModel.vendaCondicoesPagamentoModel = VendaCondicoesPagamentoModel.fromPlutoRow(plutoRowResult); 
			vendaCondicoesPagamentoModelController.text = currentModel.vendaCondicoesPagamentoModel?.nome ?? ''; 
			formWasChanged = true; 
		}
	}

  Future callViewPessoaTransportadoraLookup() async { 
		final lookupController = Get.find<LookupController>(); 
		lookupController.refreshItems(standardValue: '%'); 
		lookupController.title = '${'lookup_page_title'.tr} [Transportadora]'; 
		lookupController.route = '/view-pessoa-transportadora/'; 
		lookupController.gridColumns = viewPessoaTransportadoraGridColumns(isForLookup: true); 
		lookupController.aliasColumns = ViewPessoaTransportadoraModel.aliasColumns; 
		lookupController.dbColumns = ViewPessoaTransportadoraModel.dbColumns; 
		lookupController.standardColumn = ViewPessoaTransportadoraModel.aliasColumns[ViewPessoaTransportadoraModel.dbColumns.indexOf('nome')]; 

		final plutoRowResult = await Get.toNamed(Routes.lookupPage); 
		if (plutoRowResult != null) { 
			currentModel.idTransportadora = plutoRowResult.cells['id']!.value; 
			currentModel.viewPessoaTransportadoraModel = ViewPessoaTransportadoraModel.fromPlutoRow(plutoRowResult); 
			viewPessoaTransportadoraModelController.text = currentModel.viewPessoaTransportadoraModel?.nome ?? ''; 
			formWasChanged = true; 
		}
	}


  List<Tab> tabItems = [
    Tab( 
			icon: Icon(iconDataList[Random().nextInt(10)]), 
			text: 'Orçamento de Venda', 
		),
    Tab( 
			icon: Icon(iconDataList[Random().nextInt(10)]), 
			text: 'Itens do Orçamento', 
		),
  ];

  List<Widget> tabPages() {
    return [
      VendaOrcamentoCabecalhoEditPage(),
      const VendaOrcamentoDetalheListPage(),
    ];
  }

  @override
  void preventDataLoss() {
    if (userMadeChanges()) {
      showQuestionDialog('message_data_loss'.tr, () { 
        Get.back(); 
      });
    } else {
      Get.back();
    }
  }  

  bool userMadeChanges() {
    return
    formWasChanged 
    || 
		Get.find<VendaOrcamentoDetalheController>().userMadeChanges
    ;
  }

  void tabChange(int index) {
    validateCurrentForm();
  }

  bool validateCurrentForm() {
    mandatoryMessage = ValidateFormField.validateMandatory(currentModel.viewPessoaVendedorModel?.nome); 
		if (mandatoryMessage != null) { 
			tabController.animateTo(0); 
			showErrorSnackBar(message: '$mandatoryMessage [Vendedor]'); 
			return false; 
		}
    mandatoryMessage = ValidateFormField.validateMandatory(currentModel.viewPessoaClienteModel?.nome); 
		if (mandatoryMessage != null) { 
			tabController.animateTo(0); 
			showErrorSnackBar(message: '$mandatoryMessage [Cliente]'); 
			return false; 
		}
    mandatoryMessage = ValidateFormField.validateMandatory(currentModel.vendaCondicoesPagamentoModel?.nome); 
		if (mandatoryMessage != null) { 
			tabController.animateTo(0); 
			showErrorSnackBar(message: '$mandatoryMessage [Condicoes Pagamento]'); 
			return false; 
		}
    mandatoryMessage = ValidateFormField.validateMandatory(currentModel.viewPessoaTransportadoraModel?.nome); 
		if (mandatoryMessage != null) { 
			tabController.animateTo(0); 
			showErrorSnackBar(message: '$mandatoryMessage [Transportadora]'); 
			return false; 
		}
    return true;
  }

  bool validateForms() {
    return true;
  }

  @override
  void onInit() {
    super.onInit();
    tabController = TabController(vsync: this, length: tabItems.length);
  }
	
  @override
  void onClose() {
    tabController.dispose();
    viewPessoaVendedorModelController.dispose();
    viewPessoaClienteModelController.dispose();
    vendaCondicoesPagamentoModelController.dispose();
    viewPessoaTransportadoraModelController.dispose();
    codigoController.dispose();
    valorSubtotalController.dispose();
    valorFreteController.dispose();
    taxaComissaoController.dispose();
    valorComissaoController.dispose();
    taxaDescontoController.dispose();
    valorDescontoController.dispose();
    valorTotalController.dispose();
    observacaoController.dispose();
    super.onClose();
  }	
}