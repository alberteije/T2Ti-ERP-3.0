import 'package:flutter/material.dart';
import 'dart:math';
import 'package:get/get.dart';
import 'package:extended_masked_text/extended_masked_text.dart';

import 'package:vendas/app/infra/infra_imports.dart';
import 'package:vendas/app/page/page_imports.dart';
import 'package:vendas/app/page/shared_widget/message_dialog.dart';
import 'package:vendas/app/page/grid_columns/grid_columns_imports.dart';
import 'package:vendas/app/routes/app_routes.dart';
import 'package:vendas/app/controller/controller_imports.dart';
import 'package:vendas/app/data/model/model_imports.dart';
import 'package:vendas/app/data/repository/venda_cabecalho_repository.dart';

class VendaCabecalhoController extends ControllerBase<VendaCabecalhoModel, VendaCabecalhoRepository> 
with GetSingleTickerProviderStateMixin {

  VendaCabecalhoController({required super.repository}) {
    dbColumns = VendaCabecalhoModel.dbColumns;
    aliasColumns = VendaCabecalhoModel.aliasColumns;
    gridColumns = vendaCabecalhoGridColumns();
    functionName = "venda_cabecalho";
    screenTitle = "Venda";
  }

  final vendaCabecalhoScaffoldKey = GlobalKey<ScaffoldState>();
  final vendaCabecalhoTabPageScaffoldKey = GlobalKey<ScaffoldState>();
  final vendaCabecalhoFormKey = GlobalKey<FormState>();
  late TabController tabController;
  String? mandatoryMessage;  

  @override
  VendaCabecalhoModel createNewModel() => VendaCabecalhoModel();

  @override
  final standardFieldForFilter = VendaCabecalhoModel.aliasColumns[VendaCabecalhoModel.dbColumns.indexOf('local_entrega')];

  final vendaOrcamentoCabecalhoModelController = TextEditingController();
  final notaFiscalTipoModelController = TextEditingController();
  final viewPessoaVendedorModelController = TextEditingController();
  final vendaCondicoesPagamentoModelController = TextEditingController();
  final viewPessoaTransportadoraModelController = TextEditingController();
  final viewPessoaClienteModelController = TextEditingController();
  final localEntregaController = TextEditingController();
  final localCobrancaController = TextEditingController();
  final horaSaidaController = MaskedTextController(mask: '00:00:00',);
  final numeroFaturaController = MoneyMaskedTextController(precision: 0, decimalSeparator: '', thousandSeparator: '');
  final valorFreteController = MoneyMaskedTextController();
  final valorSeguroController = MoneyMaskedTextController();
  final valorSubtotalController = MoneyMaskedTextController();
  final taxaComissaoController = MoneyMaskedTextController();
  final valorComissaoController = MoneyMaskedTextController();
  final taxaDescontoController = MoneyMaskedTextController();
  final valorDescontoController = MoneyMaskedTextController();
  final valorTotalController = MoneyMaskedTextController();
  final diaFixoParcelaController = TextEditingController();
  final observacaoController = TextEditingController();

  final Map<String, dynamic> mobileConfig = {
    'primaryColumns': ['local_entrega'],
    'secondaryColumns': ['local_cobranca'],
  };

  List<Map<String, dynamic>> get mobileItems {
    return modelList.map((vendaCabecalho) => vendaCabecalho.toJson).toList();
  }

  @override
  void prepareForInsert() {
    isNewRecord = true;
    currentModel = createNewModel();
    _resetForm();
    tabController.animateTo(0);
    _configureChildrenControllers();
    Get.toNamed(Routes.vendaCabecalhoTabPage);
  }

  void _resetForm() {
    formWasChanged = false;
    vendaOrcamentoCabecalhoModelController.text = '';
    notaFiscalTipoModelController.text = '';
    viewPessoaVendedorModelController.text = '';
    vendaCondicoesPagamentoModelController.text = '';
    viewPessoaTransportadoraModelController.text = '';
    viewPessoaClienteModelController.text = '';
    localEntregaController.text = '';
    localCobrancaController.text = '';
    horaSaidaController.text = '';
    numeroFaturaController.updateValue(0);
    valorFreteController.updateValue(0);
    valorSeguroController.updateValue(0);
    valorSubtotalController.updateValue(0);
    taxaComissaoController.updateValue(0);
    valorComissaoController.updateValue(0);
    taxaDescontoController.updateValue(0);
    valorDescontoController.updateValue(0);
    valorTotalController.updateValue(0);
    diaFixoParcelaController.text = '';
    observacaoController.text = '';
  }

  @override
  void selectRowForEditingById(int id) {
    final model = modelList.firstWhere((m) => m.id == id);
    currentModel = model.clone();
    updateControllersFromModel();

    tabController.animateTo(0);
    _configureChildrenControllers();
    Get.toNamed(Routes.vendaCabecalhoTabPage);
  }

  _configureChildrenControllers() {
    //Comissão
		Get.put<VendaComissaoController>(VendaComissaoController()); 
		final vendaComissaoController = Get.find<VendaComissaoController>(); 
		vendaComissaoController.updateControllersFromModel(); 

    //Itens da Venda
		Get.put<VendaDetalheController>(VendaDetalheController()); 
		final vendaDetalheController = Get.find<VendaDetalheController>(); 
		vendaDetalheController.userMadeChanges = false; 

    //Frete
		Get.put<VendaFreteController>(VendaFreteController()); 
		final vendaFreteController = Get.find<VendaFreteController>(); 
		vendaFreteController.userMadeChanges = false; 

  }
  
  void updateControllersFromModel() {
    vendaOrcamentoCabecalhoModelController.text = currentModel.vendaOrcamentoCabecalhoModel?.codigo?.toString() ?? '';
    notaFiscalTipoModelController.text = currentModel.notaFiscalTipoModel?.nome?.toString() ?? '';
    viewPessoaVendedorModelController.text = currentModel.viewPessoaVendedorModel?.nome?.toString() ?? '';
    vendaCondicoesPagamentoModelController.text = currentModel.vendaCondicoesPagamentoModel?.nome?.toString() ?? '';
    viewPessoaTransportadoraModelController.text = currentModel.viewPessoaTransportadoraModel?.nome?.toString() ?? '';
    viewPessoaClienteModelController.text = currentModel.viewPessoaClienteModel?.nome?.toString() ?? '';
    localEntregaController.text = currentModel.localEntrega ?? '';
    localCobrancaController.text = currentModel.localCobranca ?? '';
    horaSaidaController.text = currentModel.horaSaida ?? '';
    numeroFaturaController.updateValue((currentModel.numeroFatura ?? 0).toDouble());
    valorFreteController.updateValue(currentModel.valorFrete ?? 0);
    valorSeguroController.updateValue(currentModel.valorSeguro ?? 0);
    valorSubtotalController.updateValue(currentModel.valorSubtotal ?? 0);
    taxaComissaoController.updateValue(currentModel.taxaComissao ?? 0);
    valorComissaoController.updateValue(currentModel.valorComissao ?? 0);
    taxaDescontoController.updateValue(currentModel.taxaDesconto ?? 0);
    valorDescontoController.updateValue(currentModel.valorDesconto ?? 0);
    valorTotalController.updateValue(currentModel.valorTotal ?? 0);
    diaFixoParcelaController.text = currentModel.diaFixoParcela ?? '';
    observacaoController.text = currentModel.observacao ?? '';
    formWasChanged = false;
  }

  @override
  Future<void> save() async {
    if (!validateCurrentForm()) return;
    if (validateForms()) {
      if (userMadeChanges()) {
        final existingIndex = modelList.indexWhere((m) => m.id == currentModel.id);

        if (existingIndex >= 0) {
          modelList[existingIndex] = currentModel.clone();
        }

        final result = await repository.save(vendaCabecalhoModel: currentModel);
        if (result == null) return;

        if (existingIndex >= 0) {
          modelList[existingIndex] = result;
        } else {
          modelList.insert(0, result);
        }

        if (!GetPlatform.isMobile) {
          updateGridRow(result);
        }

        Get.back(result: true);
      } else {
        Get.back();
      }
    } 
  }

  Future callVendaOrcamentoCabecalhoLookup() async { 
		final lookupController = Get.find<LookupController>(); 
		lookupController.refreshItems(standardValue: '%'); 
		lookupController.title = '${'lookup_page_title'.tr} [Orçamento]'; 
		lookupController.route = '/venda-orcamento-cabecalho/'; 
		lookupController.gridColumns = vendaOrcamentoCabecalhoGridColumns(isForLookup: true); 
		lookupController.aliasColumns = VendaOrcamentoCabecalhoModel.aliasColumns; 
		lookupController.dbColumns = VendaOrcamentoCabecalhoModel.dbColumns; 
		lookupController.standardColumn = VendaOrcamentoCabecalhoModel.aliasColumns[VendaOrcamentoCabecalhoModel.dbColumns.indexOf('codigo')]; 

		final plutoRowResult = await Get.toNamed(Routes.lookupPage); 
		if (plutoRowResult != null) { 
			currentModel.idVendaOrcamentoCabecalho = plutoRowResult.cells['id']!.value; 
			currentModel.vendaOrcamentoCabecalhoModel = VendaOrcamentoCabecalhoModel.fromPlutoRow(plutoRowResult); 
			vendaOrcamentoCabecalhoModelController.text = currentModel.vendaOrcamentoCabecalhoModel?.codigo ?? ''; 
			formWasChanged = true; 
		}
	}

  Future callNotaFiscalTipoLookup() async { 
		final lookupController = Get.find<LookupController>(); 
		lookupController.refreshItems(standardValue: '%'); 
		lookupController.title = '${'lookup_page_title'.tr} [Tipo Nota Fiscal]'; 
		lookupController.route = '/nota-fiscal-tipo/'; 
		lookupController.gridColumns = notaFiscalTipoGridColumns(isForLookup: true); 
		lookupController.aliasColumns = NotaFiscalTipoModel.aliasColumns; 
		lookupController.dbColumns = NotaFiscalTipoModel.dbColumns; 
		lookupController.standardColumn = NotaFiscalTipoModel.aliasColumns[NotaFiscalTipoModel.dbColumns.indexOf('nome')]; 

		final plutoRowResult = await Get.toNamed(Routes.lookupPage); 
		if (plutoRowResult != null) { 
			currentModel.idNotaFiscalTipo = plutoRowResult.cells['id']!.value; 
			currentModel.notaFiscalTipoModel = NotaFiscalTipoModel.fromPlutoRow(plutoRowResult); 
			notaFiscalTipoModelController.text = currentModel.notaFiscalTipoModel?.nome ?? ''; 
			formWasChanged = true; 
		}
	}

  Future callViewPessoaVendedorLookup() async { 
		final lookupController = Get.find<LookupController>(); 
		lookupController.refreshItems(standardValue: '%'); 
		lookupController.title = '${'lookup_page_title'.tr} [Vendedor]'; 
		lookupController.route = '/view-pessoa-vendedor/'; 
		lookupController.gridColumns = viewPessoaVendedorGridColumns(isForLookup: true); 
		lookupController.aliasColumns = ViewPessoaVendedorModel.aliasColumns; 
		lookupController.dbColumns = ViewPessoaVendedorModel.dbColumns; 
		lookupController.standardColumn = ViewPessoaVendedorModel.aliasColumns[ViewPessoaVendedorModel.dbColumns.indexOf('nome')]; 

		final plutoRowResult = await Get.toNamed(Routes.lookupPage); 
		if (plutoRowResult != null) { 
			currentModel.idVendedor = plutoRowResult.cells['id']!.value; 
			currentModel.viewPessoaVendedorModel = ViewPessoaVendedorModel.fromPlutoRow(plutoRowResult); 
			viewPessoaVendedorModelController.text = currentModel.viewPessoaVendedorModel?.nome ?? ''; 
			formWasChanged = true; 
		}
	}

  Future callVendaCondicoesPagamentoLookup() async { 
		final lookupController = Get.find<LookupController>(); 
		lookupController.refreshItems(standardValue: '%'); 
		lookupController.title = '${'lookup_page_title'.tr} [Condicoes Pagamento]'; 
		lookupController.route = '/venda-condicoes-pagamento/'; 
		lookupController.gridColumns = vendaCondicoesPagamentoGridColumns(isForLookup: true); 
		lookupController.aliasColumns = VendaCondicoesPagamentoModel.aliasColumns; 
		lookupController.dbColumns = VendaCondicoesPagamentoModel.dbColumns; 
		lookupController.standardColumn = VendaCondicoesPagamentoModel.aliasColumns[VendaCondicoesPagamentoModel.dbColumns.indexOf('nome')]; 

		final plutoRowResult = await Get.toNamed(Routes.lookupPage); 
		if (plutoRowResult != null) { 
			currentModel.idVendaCondicoesPagamento = plutoRowResult.cells['id']!.value; 
			currentModel.vendaCondicoesPagamentoModel = VendaCondicoesPagamentoModel.fromPlutoRow(plutoRowResult); 
			vendaCondicoesPagamentoModelController.text = currentModel.vendaCondicoesPagamentoModel?.nome ?? ''; 
			formWasChanged = true; 
		}
	}

  Future callViewPessoaTransportadoraLookup() async { 
		final lookupController = Get.find<LookupController>(); 
		lookupController.refreshItems(standardValue: '%'); 
		lookupController.title = '${'lookup_page_title'.tr} [Transportadora]'; 
		lookupController.route = '/view-pessoa-transportadora/'; 
		lookupController.gridColumns = viewPessoaTransportadoraGridColumns(isForLookup: true); 
		lookupController.aliasColumns = ViewPessoaTransportadoraModel.aliasColumns; 
		lookupController.dbColumns = ViewPessoaTransportadoraModel.dbColumns; 
		lookupController.standardColumn = ViewPessoaTransportadoraModel.aliasColumns[ViewPessoaTransportadoraModel.dbColumns.indexOf('nome')]; 

		final plutoRowResult = await Get.toNamed(Routes.lookupPage); 
		if (plutoRowResult != null) { 
			currentModel.idTransportadora = plutoRowResult.cells['id']!.value; 
			currentModel.viewPessoaTransportadoraModel = ViewPessoaTransportadoraModel.fromPlutoRow(plutoRowResult); 
			viewPessoaTransportadoraModelController.text = currentModel.viewPessoaTransportadoraModel?.nome ?? ''; 
			formWasChanged = true; 
		}
	}

  Future callViewPessoaClienteLookup() async { 
		final lookupController = Get.find<LookupController>(); 
		lookupController.refreshItems(standardValue: '%'); 
		lookupController.title = '${'lookup_page_title'.tr} [Cliente]'; 
		lookupController.route = '/view-pessoa-cliente/'; 
		lookupController.gridColumns = viewPessoaClienteGridColumns(isForLookup: true); 
		lookupController.aliasColumns = ViewPessoaClienteModel.aliasColumns; 
		lookupController.dbColumns = ViewPessoaClienteModel.dbColumns; 
		lookupController.standardColumn = ViewPessoaClienteModel.aliasColumns[ViewPessoaClienteModel.dbColumns.indexOf('nome')]; 

		final plutoRowResult = await Get.toNamed(Routes.lookupPage); 
		if (plutoRowResult != null) { 
			currentModel.idCliente = plutoRowResult.cells['id']!.value; 
			currentModel.viewPessoaClienteModel = ViewPessoaClienteModel.fromPlutoRow(plutoRowResult); 
			viewPessoaClienteModelController.text = currentModel.viewPessoaClienteModel?.nome ?? ''; 
			formWasChanged = true; 
		}
	}


  List<Tab> tabItems = [
    Tab( 
			icon: Icon(iconDataList[Random().nextInt(10)]), 
			text: 'Venda', 
		),
    Tab( 
			icon: Icon(iconDataList[Random().nextInt(10)]), 
			text: 'Itens da Venda', 
		),
    Tab( 
			icon: Icon(iconDataList[Random().nextInt(10)]), 
			text: 'Frete', 
		),
    Tab( 
			icon: Icon(iconDataList[Random().nextInt(10)]), 
			text: 'Comissão', 
		),
  ];

  List<Widget> tabPages() {
    return [
      VendaCabecalhoEditPage(),
      const VendaDetalheListPage(),
      const VendaFreteListPage(),
      VendaComissaoEditPage(),
    ];
  }

  @override
  void preventDataLoss() {
    if (userMadeChanges()) {
      showQuestionDialog('message_data_loss'.tr, () { 
        Get.back(); 
      });
    } else {
      Get.back();
    }
  }  

  bool userMadeChanges() {
    return
    formWasChanged 
    || 
		Get.find<VendaComissaoController>().formWasChangedDetail
    || 
		Get.find<VendaDetalheController>().userMadeChanges
    || 
		Get.find<VendaFreteController>().userMadeChanges
    ;
  }

  void tabChange(int index) {
    validateCurrentForm();
  }

  bool validateCurrentForm() {
    mandatoryMessage = ValidateFormField.validateMandatory(currentModel.notaFiscalTipoModel?.nome); 
		if (mandatoryMessage != null) { 
			tabController.animateTo(0); 
			showErrorSnackBar(message: '$mandatoryMessage [Tipo Nota Fiscal]'); 
			return false; 
		}
    mandatoryMessage = ValidateFormField.validateMandatory(currentModel.viewPessoaVendedorModel?.nome); 
		if (mandatoryMessage != null) { 
			tabController.animateTo(0); 
			showErrorSnackBar(message: '$mandatoryMessage [Vendedor]'); 
			return false; 
		}
    mandatoryMessage = ValidateFormField.validateMandatory(currentModel.vendaCondicoesPagamentoModel?.nome); 
		if (mandatoryMessage != null) { 
			tabController.animateTo(0); 
			showErrorSnackBar(message: '$mandatoryMessage [Condicoes Pagamento]'); 
			return false; 
		}
    mandatoryMessage = ValidateFormField.validateMandatory(currentModel.viewPessoaTransportadoraModel?.nome); 
		if (mandatoryMessage != null) { 
			tabController.animateTo(0); 
			showErrorSnackBar(message: '$mandatoryMessage [Transportadora]'); 
			return false; 
		}
    mandatoryMessage = ValidateFormField.validateMandatory(currentModel.viewPessoaClienteModel?.nome); 
		if (mandatoryMessage != null) { 
			tabController.animateTo(0); 
			showErrorSnackBar(message: '$mandatoryMessage [Cliente]'); 
			return false; 
		}
    return true;
  }

  bool validateForms() {
    final resultVendaComissao = Get.find<VendaComissaoController>().validateForm(); 
		if (!resultVendaComissao) { 
			tabController.animateTo(1); 
			return false; 
		}
    return true;
  }

  Future<void> lancarContasReceber() async {
    showQuestionDialog('Deseja realizar o lançamento para o contas a receber?', () async {
      final listaParcelas = currentModel.vendaCondicoesPagamentoModel?.vendaCondicoesParcelasModelList;
      final quantidadeParcelas = listaParcelas?.length ?? 1;
      var quantidadeDiasPrimeiraParcela = 0;
      var intervaloEntreParcelas = 0;
      if (listaParcelas != null && listaParcelas.isNotEmpty) {
        quantidadeDiasPrimeiraParcela = listaParcelas
          .where((item) => item.dias != null)
          .reduce((a, b) => (a.dias! < b.dias!) ? a : b)
          .dias!;

        intervaloEntreParcelas = _calcularIntervalosEntreParcelas(listaParcelas)[0];
      }
      final primeiroVencimento = currentModel.dataVenda?.add(Duration(days: quantidadeDiasPrimeiraParcela));
      final lancamento = FinLancamentoReceberModel(
        // TODO: insira padronizações na tabela adm_parametro e informe os dados de acodo com os parametros
        bancoContaCaixaModel: BancoContaCaixaModel(id: 1),
        finNaturezaFinanceiraModel: FinNaturezaFinanceiraModel(id: 1),
        finDocumentoOrigemModel: FinDocumentoOrigemModel(id: 1),
        viewPessoaClienteModel: ViewPessoaClienteModel(id: 1),
        valorAReceber: currentModel.valorTotal,
        dataLancamento: DateTime.now(),
        quantidadeParcela: quantidadeParcelas,
        primeiroVencimento: primeiroVencimento,
        taxaComissao: currentModel.taxaComissao,
        valorComissao: currentModel.valorComissao,
        diaFixo: currentModel.diaFixoParcela,
        intervaloEntreParcelas: intervaloEntreParcelas,
      );

      // Gerar cada parcela
      final valorPorParcela = lancamento.valorAReceber! / lancamento.quantidadeParcela!;
      for (var i = 0; i < lancamento.quantidadeParcela!; i++) {
        final parcela = FinParcelaReceberModel(
          idFinLancamentoReceber: currentModel.id,
          numeroParcela: i + 1,
          valor: valorPorParcela,
          dataEmissao: DateTime.now(),
          dataVencimento: _calcularDataVencimento(lancamento, i),
          dataRecebimento: null,
          finStatusParcelaModel: FinStatusParcelaModel(id: 1, situacao: '01', descricao: 'Aberto'), // TODO: insira padronizações na tabela adm_parametro e informe os dados de acodo com os parametros
          finTipoRecebimentoModel: FinTipoRecebimentoModel(id: 1, codigo: '01', descricao: 'Dinheiro'), // TODO: insira padronizações na tabela adm_parametro e informe os dados de acodo com os parametros
        );

        // Adicionar à lista
        lancamento.finParcelaReceberModelList!.add(parcela);
      }

      await repository.lancarContasReceber(finLancamentoReceber: lancamento);

      showInfoSnackBar(message: "Lançamento realizado com sucesso.");
    });
  }

  DateTime _calcularDataVencimento(FinLancamentoReceberModel lancamento, int numeroParcela) {
    DateTime dataBase = lancamento.primeiroVencimento!;

    // Se tem dia fixo definido
    if (lancamento.diaFixo != null && lancamento.diaFixo!.isNotEmpty) {
      final diaFixo = int.tryParse(lancamento.diaFixo!) ?? dataBase.day;

      // Para a primeira parcela, usa a data base se o dia já for o fixo
      if (numeroParcela == 0 && dataBase.day == diaFixo) {
        return dataBase;
      }

      // Para outras parcelas ou quando o dia base não coincide
      return DateTime(dataBase.year, dataBase.month + numeroParcela, diaFixo);
    }

    // Se não tem dia fixo, usa o intervalo entre parcelas
    final intervalo = lancamento.intervaloEntreParcelas ?? 30;
    return dataBase.add(Duration(days: intervalo * numeroParcela));
  }

  List<int> _calcularIntervalosEntreParcelas(List<VendaCondicoesParcelasModel> parcelas) {
    // Remove nulos e ordena por 'dias'
    final listaOrdenada = parcelas
        .where((p) => p.dias != null)
        .toList()
      ..sort((a, b) => a.dias!.compareTo(b.dias!));

    List<int> intervalos = [];

    for (int i = 1; i < listaOrdenada.length; i++) {
      final diasAnterior = listaOrdenada[i - 1].dias!;
      final diasAtual = listaOrdenada[i].dias!;
      intervalos.add(diasAtual - diasAnterior);
    }

    return intervalos;
  }


  @override
  void onInit() {
    super.onInit();
    tabController = TabController(vsync: this, length: tabItems.length);
  }
	
  @override
  void onClose() {
    tabController.dispose();
    vendaOrcamentoCabecalhoModelController.dispose();
    notaFiscalTipoModelController.dispose();
    viewPessoaVendedorModelController.dispose();
    vendaCondicoesPagamentoModelController.dispose();
    viewPessoaTransportadoraModelController.dispose();
    viewPessoaClienteModelController.dispose();
    localEntregaController.dispose();
    localCobrancaController.dispose();
    horaSaidaController.dispose();
    numeroFaturaController.dispose();
    valorFreteController.dispose();
    valorSeguroController.dispose();
    valorSubtotalController.dispose();
    taxaComissaoController.dispose();
    valorComissaoController.dispose();
    taxaDescontoController.dispose();
    valorDescontoController.dispose();
    valorTotalController.dispose();
    diaFixoParcelaController.dispose();
    observacaoController.dispose();
    super.onClose();
  }	
}