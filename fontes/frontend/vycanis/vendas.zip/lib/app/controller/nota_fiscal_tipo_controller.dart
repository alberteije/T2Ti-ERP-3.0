import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:extended_masked_text/extended_masked_text.dart';

import 'package:vendas/app/page/shared_widget/message_dialog.dart';
import 'package:vendas/app/page/grid_columns/grid_columns_imports.dart';
import 'package:vendas/app/routes/app_routes.dart';
import 'package:vendas/app/controller/controller_imports.dart';
import 'package:vendas/app/data/model/model_imports.dart';
import 'package:vendas/app/data/repository/nota_fiscal_tipo_repository.dart';

class NotaFiscalTipoController extends ControllerBase<NotaFiscalTipoModel, NotaFiscalTipoRepository> {

  NotaFiscalTipoController({required super.repository}) {
    dbColumns = NotaFiscalTipoModel.dbColumns;
    aliasColumns = NotaFiscalTipoModel.aliasColumns;
    gridColumns = notaFiscalTipoGridColumns();
    functionName = "nota_fiscal_tipo";
    screenTitle = "Tipo de Nota Fiscal";
  }

  @override
  NotaFiscalTipoModel createNewModel() => NotaFiscalTipoModel();

  @override
  final standardFieldForFilter = NotaFiscalTipoModel.aliasColumns[NotaFiscalTipoModel.dbColumns.indexOf('nome')];

  final notaFiscalModeloModelController = TextEditingController();
  final nomeController = TextEditingController();
  final descricaoController = TextEditingController();
  final serieController = TextEditingController();
  final serieScanController = TextEditingController();
  final ultimoNumeroController = MoneyMaskedTextController(precision: 0, decimalSeparator: '', thousandSeparator: '');

  final Map<String, dynamic> mobileConfig = {
    'primaryColumns': ['nome'],
    'secondaryColumns': ['descricao'],
  };

  List<Map<String, dynamic>> get mobileItems {
    return modelList.map((notaFiscalTipo) => notaFiscalTipo.toJson).toList();
  }

  @override
  void prepareForInsert() {
    isNewRecord = true;
    currentModel = createNewModel();
    _resetForm();
    Get.toNamed(Routes.notaFiscalTipoEditPage);
  }

  void _resetForm() {
    formWasChanged = false;
    notaFiscalModeloModelController.text = '';
    nomeController.text = '';
    descricaoController.text = '';
    serieController.text = '';
    serieScanController.text = '';
    ultimoNumeroController.updateValue(0);
  }

  @override
  void selectRowForEditingById(int id) {
    final model = modelList.firstWhere((m) => m.id == id);
    currentModel = model.clone();
    updateControllersFromModel();
    Get.toNamed(Routes.notaFiscalTipoEditPage);
  }

  void updateControllersFromModel() {
    notaFiscalModeloModelController.text = currentModel.notaFiscalModeloModel?.modelo?.toString() ?? '';
    nomeController.text = currentModel.nome ?? '';
    descricaoController.text = currentModel.descricao ?? '';
    serieController.text = currentModel.serie ?? '';
    serieScanController.text = currentModel.serieScan ?? '';
    ultimoNumeroController.updateValue((currentModel.ultimoNumero ?? 0).toDouble());
    formWasChanged = false;
  }

  @override
  Future<void> save() async {
    if (!formKey.currentState!.validate()) {
      showErrorSnackBar(message: 'validator_form_message'.tr);
      return;
    }

    final existingIndex = modelList.indexWhere((m) => m.id == currentModel.id);

    if (existingIndex >= 0) {
      modelList[existingIndex] = currentModel.clone();
    }

    final result = await repository.save(notaFiscalTipoModel: currentModel);
    if (result == null) return;

    if (existingIndex >= 0) {
      modelList[existingIndex] = result;
    } else {
      modelList.insert(0, result);
    }

    if (!GetPlatform.isMobile) {
      updateGridRow(result);
    }

    Get.back(result: true);
  }

  Future callNotaFiscalModeloLookup() async { 
		final lookupController = Get.find<LookupController>(); 
		lookupController.refreshItems(standardValue: '%'); 
		lookupController.title = '${'lookup_page_title'.tr} [Nota Fiscal Modelo]'; 
		lookupController.route = '/nota-fiscal-modelo/'; 
		lookupController.gridColumns = notaFiscalModeloGridColumns(isForLookup: true); 
		lookupController.aliasColumns = NotaFiscalModeloModel.aliasColumns; 
		lookupController.dbColumns = NotaFiscalModeloModel.dbColumns; 
		lookupController.standardColumn = NotaFiscalModeloModel.aliasColumns[NotaFiscalModeloModel.dbColumns.indexOf('modelo')]; 

		final plutoRowResult = await Get.toNamed(Routes.lookupPage); 
		if (plutoRowResult != null) { 
			currentModel.idNotaFiscalModelo = plutoRowResult.cells['id']!.value; 
			currentModel.notaFiscalModeloModel = NotaFiscalModeloModel.fromPlutoRow(plutoRowResult); 
			notaFiscalModeloModelController.text = currentModel.notaFiscalModeloModel?.modelo ?? ''; 
			formWasChanged = true; 
		}
	}


  @override
  void onClose() {
    notaFiscalModeloModelController.dispose();
    nomeController.dispose();
    descricaoController.dispose();
    serieController.dispose();
    serieScanController.dispose();
    ultimoNumeroController.dispose();
    super.onClose();
  }

}