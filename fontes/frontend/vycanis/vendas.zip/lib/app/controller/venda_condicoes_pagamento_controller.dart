import 'package:flutter/material.dart';
import 'dart:math';
import 'package:get/get.dart';
import 'package:extended_masked_text/extended_masked_text.dart';

import 'package:vendas/app/infra/infra_imports.dart';
import 'package:vendas/app/page/page_imports.dart';
import 'package:vendas/app/page/shared_widget/message_dialog.dart';
import 'package:vendas/app/page/grid_columns/grid_columns_imports.dart';
import 'package:vendas/app/routes/app_routes.dart';
import 'package:vendas/app/controller/controller_imports.dart';
import 'package:vendas/app/data/model/model_imports.dart';
import 'package:vendas/app/data/repository/venda_condicoes_pagamento_repository.dart';

class VendaCondicoesPagamentoController extends ControllerBase<VendaCondicoesPagamentoModel, VendaCondicoesPagamentoRepository> 
with GetSingleTickerProviderStateMixin {

  VendaCondicoesPagamentoController({required super.repository}) {
    dbColumns = VendaCondicoesPagamentoModel.dbColumns;
    aliasColumns = VendaCondicoesPagamentoModel.aliasColumns;
    gridColumns = vendaCondicoesPagamentoGridColumns();
    functionName = "venda_condicoes_pagamento";
    screenTitle = "Condições de Pagamento";
  }

  final vendaCondicoesPagamentoScaffoldKey = GlobalKey<ScaffoldState>();
  final vendaCondicoesPagamentoTabPageScaffoldKey = GlobalKey<ScaffoldState>();
  final vendaCondicoesPagamentoFormKey = GlobalKey<FormState>();
  late TabController tabController;
  String? mandatoryMessage;  

  @override
  VendaCondicoesPagamentoModel createNewModel() => VendaCondicoesPagamentoModel();

  @override
  final standardFieldForFilter = VendaCondicoesPagamentoModel.aliasColumns[VendaCondicoesPagamentoModel.dbColumns.indexOf('nome')];

  final nomeController = TextEditingController();
  final descricaoController = TextEditingController();
  final faturamentoMinimoController = MoneyMaskedTextController();
  final faturamentoMaximoController = MoneyMaskedTextController();
  final indiceCorrecaoController = MoneyMaskedTextController();
  final diasToleranciaController = MoneyMaskedTextController(precision: 0, decimalSeparator: '', thousandSeparator: '');
  final valorToleranciaController = MoneyMaskedTextController();
  final prazoMedioController = MoneyMaskedTextController(precision: 0, decimalSeparator: '', thousandSeparator: '');

  final Map<String, dynamic> mobileConfig = {
    'primaryColumns': ['nome'],
    'secondaryColumns': ['descricao'],
  };

  List<Map<String, dynamic>> get mobileItems {
    return modelList.map((vendaCondicoesPagamento) => vendaCondicoesPagamento.toJson).toList();
  }

  @override
  void prepareForInsert() {
    isNewRecord = true;
    currentModel = createNewModel();
    _resetForm();
    tabController.animateTo(0);
    _configureChildrenControllers();
    Get.toNamed(Routes.vendaCondicoesPagamentoTabPage);
  }

  void _resetForm() {
    formWasChanged = false;
    nomeController.text = '';
    descricaoController.text = '';
    faturamentoMinimoController.updateValue(0);
    faturamentoMaximoController.updateValue(0);
    indiceCorrecaoController.updateValue(0);
    diasToleranciaController.updateValue(0);
    valorToleranciaController.updateValue(0);
    prazoMedioController.updateValue(0);
  }

  @override
  void selectRowForEditingById(int id) {
    final model = modelList.firstWhere((m) => m.id == id);
    currentModel = model.clone();
    updateControllersFromModel();

    tabController.animateTo(0);
    _configureChildrenControllers();
    Get.toNamed(Routes.vendaCondicoesPagamentoTabPage);
  }

  _configureChildrenControllers() {
    //Parcelas
		Get.put<VendaCondicoesParcelasController>(VendaCondicoesParcelasController()); 
		final vendaCondicoesParcelasController = Get.find<VendaCondicoesParcelasController>(); 
		vendaCondicoesParcelasController.userMadeChanges = false; 

  }
  
  void updateControllersFromModel() {
    nomeController.text = currentModel.nome ?? '';
    descricaoController.text = currentModel.descricao ?? '';
    faturamentoMinimoController.updateValue(currentModel.faturamentoMinimo ?? 0);
    faturamentoMaximoController.updateValue(currentModel.faturamentoMaximo ?? 0);
    indiceCorrecaoController.updateValue(currentModel.indiceCorrecao ?? 0);
    diasToleranciaController.updateValue((currentModel.diasTolerancia ?? 0).toDouble());
    valorToleranciaController.updateValue(currentModel.valorTolerancia ?? 0);
    prazoMedioController.updateValue((currentModel.prazoMedio ?? 0).toDouble());
    formWasChanged = false;
  }

  @override
  Future<void> save() async {
    if (!validateCurrentForm()) return;
    if (validateForms()) {
      if (userMadeChanges()) {
        final existingIndex = modelList.indexWhere((m) => m.id == currentModel.id);

        if (existingIndex >= 0) {
          modelList[existingIndex] = currentModel.clone();
        }

        final result = await repository.save(vendaCondicoesPagamentoModel: currentModel);
        if (result == null) return;

        if (existingIndex >= 0) {
          modelList[existingIndex] = result;
        } else {
          modelList.insert(0, result);
        }

        if (!GetPlatform.isMobile) {
          updateGridRow(result);
        }

        Get.back(result: true);
      } else {
        Get.back();
      }
    } 
  }


  List<Tab> tabItems = [
    Tab( 
			icon: Icon(iconDataList[Random().nextInt(10)]), 
			text: 'Condições de Pagamento', 
		),
    Tab( 
			icon: Icon(iconDataList[Random().nextInt(10)]), 
			text: 'Parcelas', 
		),
  ];

  List<Widget> tabPages() {
    return [
      VendaCondicoesPagamentoEditPage(),
      const VendaCondicoesParcelasListPage(),
    ];
  }

  @override
  void preventDataLoss() {
    if (userMadeChanges()) {
      showQuestionDialog('message_data_loss'.tr, () { 
        Get.back(); 
      });
    } else {
      Get.back();
    }
  }  

  bool userMadeChanges() {
    return
    formWasChanged 
    || 
		Get.find<VendaCondicoesParcelasController>().userMadeChanges
    ;
  }

  void tabChange(int index) {
    validateCurrentForm();
  }

  bool validateCurrentForm() {
    return true;
  }

  bool validateForms() {
    return true;
  }

  @override
  void onInit() {
    super.onInit();
    tabController = TabController(vsync: this, length: tabItems.length);
  }
	
  @override
  void onClose() {
    tabController.dispose();
    nomeController.dispose();
    descricaoController.dispose();
    faturamentoMinimoController.dispose();
    faturamentoMaximoController.dispose();
    indiceCorrecaoController.dispose();
    diasToleranciaController.dispose();
    valorToleranciaController.dispose();
    prazoMedioController.dispose();
    super.onClose();
  }	
}