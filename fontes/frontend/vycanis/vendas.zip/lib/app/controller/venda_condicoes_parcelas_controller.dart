import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:pluto_grid/pluto_grid.dart';
import 'package:extended_masked_text/extended_masked_text.dart';

import 'package:vendas/app/page/page_imports.dart';
import 'package:vendas/app/page/shared_widget/message_dialog.dart';
import 'package:vendas/app/page/grid_columns/grid_columns_imports.dart';
import 'package:vendas/app/controller/controller_imports.dart';
import 'package:vendas/app/data/model/model_imports.dart';

class VendaCondicoesParcelasController extends ControllerBase<VendaCondicoesParcelasModel, void> {

  VendaCondicoesParcelasController() : super(repository: null) {
    dbColumns = VendaCondicoesParcelasModel.dbColumns;
    aliasColumns = VendaCondicoesParcelasModel.aliasColumns;
    gridColumns = vendaCondicoesParcelasGridColumns();
    functionName = "venda_condicoes_parcelas";
    screenTitle = "Parcelas";
  }

  final _vendaCondicoesParcelasModel = VendaCondicoesParcelasModel().obs;
  VendaCondicoesParcelasModel get vendaCondicoesParcelasModel => _vendaCondicoesParcelasModel.value;
  set vendaCondicoesParcelasModel(value) => _vendaCondicoesParcelasModel.value = value ?? VendaCondicoesParcelasModel();

  List<VendaCondicoesParcelasModel> get vendaCondicoesParcelasModelList => Get.find<VendaCondicoesPagamentoController>().currentModel.vendaCondicoesParcelasModelList ?? [];

  final _userMadeChanges = false.obs;
  get userMadeChanges => _userMadeChanges.value;
  set userMadeChanges(value) => _userMadeChanges.value = value;

  final _formWasChangedDetail = false.obs;
  bool get formWasChangedDetail => _formWasChangedDetail.value;
  set formWasChangedDetail(value) => _formWasChangedDetail.value = value;

  late PlutoGridStateManager _plutoGridStateManager;
  @override
  PlutoGridStateManager get plutoGridStateManager => _plutoGridStateManager;
  @override
  set plutoGridStateManager(value) => _plutoGridStateManager = value;

  final vendaCondicoesParcelasScaffoldKey = GlobalKey<ScaffoldState>();
  final vendaCondicoesParcelasFormKey = GlobalKey<FormState>();

  @override
  VendaCondicoesParcelasModel createNewModel() => VendaCondicoesParcelasModel();

  @override
  final standardFieldForFilter = VendaCondicoesParcelasModel.aliasColumns[VendaCondicoesParcelasModel.dbColumns.indexOf('parcela')];

  final parcelaController = MoneyMaskedTextController(precision: 0, decimalSeparator: '', thousandSeparator: '');
  final diasController = MoneyMaskedTextController(precision: 0, decimalSeparator: '', thousandSeparator: '');
  final taxaController = MoneyMaskedTextController();

  final Map<String, dynamic> mobileConfig = {
    'primaryColumns': ['parcela'],
    'secondaryColumns': ['dias'],
  };

  List<Map<String, dynamic>> get mobileItems {
    return modelList.map((vendaCondicoesParcelas) => vendaCondicoesParcelas.toJson).toList();
  }

  @override
  List<PlutoRow> plutoRows() => List<PlutoRow>.from(vendaCondicoesParcelasModelList.map((model) => model.toPlutoRow()));

  @override
  Future<void> getList({Filter? filter}) async {}

  @override
  void prepareForInsert() {
    isNewRecord = true;
    vendaCondicoesParcelasModel = createNewModel();
    _resetForm();
    Get.to(() => VendaCondicoesParcelasEditPage());
  }

  void _resetForm() {
    formWasChangedDetail = false;
    parcelaController.updateValue(0);
    diasController.updateValue(0);
    taxaController.updateValue(0);
  }

  @override
  void selectRowForEditing(PlutoRow? row) async {
    if (row == null) {
      showInfoSnackBar(message: 'message_select_one_to_edited'.tr);
      return;
    }

    selectRowForEditingByTempId(row.cells['tempId']?.value);
  }

  @override
  void selectRowForEditingById(int id) {}

  void selectRowForEditingByTempId(String tempId) {
		isNewRecord = false;
    final model = vendaCondicoesParcelasModelList.firstWhere((m) => m.tempId == tempId);
    vendaCondicoesParcelasModel = model.clone();
		vendaCondicoesParcelasModel.tempId = model.tempId;
    updateControllersFromModel();
    Get.to(() => VendaCondicoesParcelasEditPage());
  }

  void updateControllersFromModel() {
    parcelaController.updateValue((vendaCondicoesParcelasModel.parcela ?? 0).toDouble());
    diasController.updateValue((vendaCondicoesParcelasModel.dias ?? 0).toDouble());
    taxaController.updateValue(vendaCondicoesParcelasModel.taxa ?? 0);
    formWasChangedDetail = false;
  }

  @override
  Future<void> save() async {
    if (!vendaCondicoesParcelasFormKey.currentState!.validate()) {
      showErrorSnackBar(message: 'validator_form_message'.tr);
      return;
    }

    if (formWasChangedDetail) {
      if (isNewRecord) {
        vendaCondicoesParcelasModelList.insert(0, vendaCondicoesParcelasModel.clone());
      } else {
        final index = vendaCondicoesParcelasModelList.indexWhere((m) => m.tempId == vendaCondicoesParcelasModel.tempId);
        if (index >= 0) {
          vendaCondicoesParcelasModelList[index] = vendaCondicoesParcelasModel.clone();
        }
      }

      userMadeChanges = true;
      loadData();
      Get.back(result: true);
    } else {
      Get.back();
    }
  }


  @override
  Future deleteSelected() async {
    final currentRow = plutoGridStateManager.currentRow;
    if (currentRow == null) {
      showInfoSnackBar(message: 'message_select_one_to_delete'.tr);
      return null;
    }
    showDeleteDialog(() async {
      final id = currentRow.cells['id']?.value;
      final tempId = currentRow.cells['tempId']?.value;
      vendaCondicoesParcelasModelList.removeWhere((model) => (id != 0 && model.id == id) || (id == 0 && model.tempId == tempId));
      plutoGridStateManager.removeCurrentRow();
      userMadeChanges = true;
    });
  }

  @override
  void preventDataLoss() {
    if (formWasChangedDetail) {
      showQuestionDialog('message_data_loss'.tr, () => Get.back());
    } else {
      formWasChangedDetail = false;
      Get.back();
    }
  }

  @override
  void onClose() {
    parcelaController.dispose();
    diasController.dispose();
    taxaController.dispose();
  }

}