import 'dart:convert';
import 'package:pluto_grid/pluto_grid.dart';
import 'package:bpe/app/data/model/model_imports.dart';

import 'package:bpe/app/infra/infra_imports.dart';
import 'package:intl/intl.dart';
import 'package:bpe/app/data/domain/domain_imports.dart';

class BpeViagemModel extends ModelBase {
  int? id;
  int? idBpeCabecalho;
  String? codigoPercurso;
  String? descricaoPercurso;
  String? tipoViagem;
  String? tipoServico;
  String? tipoAcomodacao;
  String? tipoTrecho;
  DateTime? dataHoraViagem;
  DateTime? dataHoraConexao;
  String? prefixoLinha;
  String? poltrona;
  String? plataforma;

  BpeViagemModel({
    this.id,
    this.idBpeCabecalho,
    this.codigoPercurso,
    this.descricaoPercurso,
    this.tipoViagem = '00-regular',
    this.tipoServico = '1-Convencional com sanitário',
    this.tipoAcomodacao = '1-Assento/poltrona',
    this.tipoTrecho = '1-Normal',
    this.dataHoraViagem,
    this.dataHoraConexao,
    this.prefixoLinha,
    this.poltrona,
    this.plataforma,
  });

  static List<String> dbColumns = <String>[
    'id',
    'codigo_percurso',
    'descricao_percurso',
    'tipo_viagem',
    'tipo_servico',
    'tipo_acomodacao',
    'tipo_trecho',
    'data_hora_viagem',
    'data_hora_conexao',
    'prefixo_linha',
    'poltrona',
    'plataforma',
  ];

  static List<String> aliasColumns = <String>[
    'Id',
    'Codigo Percurso',
    'Descricao Percurso',
    'Tipo Viagem',
    'Tipo Servico',
    'Tipo Acomodacao',
    'Tipo Trecho',
    'Data Hora Viagem',
    'Data Hora Conexao',
    'Prefixo Linha',
    'Poltrona',
    'Plataforma',
  ];

  BpeViagemModel.fromJson(Map<String, dynamic> jsonData) {
    id = jsonData['id'];
    idBpeCabecalho = jsonData['idBpeCabecalho'];
    codigoPercurso = jsonData['codigoPercurso'];
    descricaoPercurso = jsonData['descricaoPercurso'];
    tipoViagem = BpeViagemDomain.getTipoViagem(jsonData['tipoViagem']);
    tipoServico = BpeViagemDomain.getTipoServico(jsonData['tipoServico']);
    tipoAcomodacao = BpeViagemDomain.getTipoAcomodacao(jsonData['tipoAcomodacao']);
    tipoTrecho = BpeViagemDomain.getTipoTrecho(jsonData['tipoTrecho']);
    dataHoraViagem = jsonData['dataHoraViagem'] != null ? DateTime.tryParse(jsonData['dataHoraViagem']) : null;
    dataHoraConexao = jsonData['dataHoraConexao'] != null ? DateTime.tryParse(jsonData['dataHoraConexao']) : null;
    prefixoLinha = jsonData['prefixoLinha'];
    poltrona = jsonData['poltrona'];
    plataforma = jsonData['plataforma'];
  }

  Map<String, dynamic> get toJson {
    Map<String, dynamic> jsonData = <String, dynamic>{};

    jsonData['id'] = id != 0 ? id : null;
    jsonData['idBpeCabecalho'] = idBpeCabecalho != 0 ? idBpeCabecalho : null;
    jsonData['codigoPercurso'] = codigoPercurso;
    jsonData['descricaoPercurso'] = descricaoPercurso;
    jsonData['tipoViagem'] = BpeViagemDomain.setTipoViagem(tipoViagem);
    jsonData['tipoServico'] = BpeViagemDomain.setTipoServico(tipoServico);
    jsonData['tipoAcomodacao'] = BpeViagemDomain.setTipoAcomodacao(tipoAcomodacao);
    jsonData['tipoTrecho'] = BpeViagemDomain.setTipoTrecho(tipoTrecho);
    jsonData['dataHoraViagem'] = dataHoraViagem != null ? DateFormat('yyyy-MM-ddT00:00:00').format(dataHoraViagem!) : null;
    jsonData['dataHoraConexao'] = dataHoraConexao != null ? DateFormat('yyyy-MM-ddT00:00:00').format(dataHoraConexao!) : null;
    jsonData['prefixoLinha'] = prefixoLinha;
    jsonData['poltrona'] = poltrona;
    jsonData['plataforma'] = plataforma;

    return jsonData;
  }

  String objectEncodeJson() {
    final jsonData = toJson;
    return json.encode(jsonData);
  }

  static BpeViagemModel fromPlutoRow(PlutoRow row) {
    return BpeViagemModel(
      id: row.cells['id']?.value,
      idBpeCabecalho: row.cells['idBpeCabecalho']?.value,
      codigoPercurso: row.cells['codigoPercurso']?.value,
      descricaoPercurso: row.cells['descricaoPercurso']?.value,
      tipoViagem: row.cells['tipoViagem']?.value,
      tipoServico: row.cells['tipoServico']?.value,
      tipoAcomodacao: row.cells['tipoAcomodacao']?.value,
      tipoTrecho: row.cells['tipoTrecho']?.value,
      dataHoraViagem: Util.stringToDate(row.cells['dataHoraViagem']?.value),
      dataHoraConexao: Util.stringToDate(row.cells['dataHoraConexao']?.value),
      prefixoLinha: row.cells['prefixoLinha']?.value,
      poltrona: row.cells['poltrona']?.value,
      plataforma: row.cells['plataforma']?.value,
    );
  }

  PlutoRow toPlutoRow() {
    return PlutoRow(
      cells: {
        'tempId': PlutoCell(value: tempId),
        'id': PlutoCell(value: id ?? 0),
        'idBpeCabecalho': PlutoCell(value: idBpeCabecalho ?? 0),
        'codigoPercurso': PlutoCell(value: codigoPercurso ?? ''),
        'descricaoPercurso': PlutoCell(value: descricaoPercurso ?? ''),
        'tipoViagem': PlutoCell(value: tipoViagem ?? ''),
        'tipoServico': PlutoCell(value: tipoServico ?? ''),
        'tipoAcomodacao': PlutoCell(value: tipoAcomodacao ?? ''),
        'tipoTrecho': PlutoCell(value: tipoTrecho ?? ''),
        'dataHoraViagem': PlutoCell(value: dataHoraViagem),
        'dataHoraConexao': PlutoCell(value: dataHoraConexao),
        'prefixoLinha': PlutoCell(value: prefixoLinha ?? ''),
        'poltrona': PlutoCell(value: poltrona ?? ''),
        'plataforma': PlutoCell(value: plataforma ?? ''),
      },
    );
  }

  BpeViagemModel clone() {
    return BpeViagemModel(
      id: id,
      idBpeCabecalho: idBpeCabecalho,
      codigoPercurso: codigoPercurso,
      descricaoPercurso: descricaoPercurso,
      tipoViagem: tipoViagem,
      tipoServico: tipoServico,
      tipoAcomodacao: tipoAcomodacao,
      tipoTrecho: tipoTrecho,
      dataHoraViagem: dataHoraViagem,
      dataHoraConexao: dataHoraConexao,
      prefixoLinha: prefixoLinha,
      poltrona: poltrona,
      plataforma: plataforma,
    );
  }


}