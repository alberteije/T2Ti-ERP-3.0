import 'dart:convert';
import 'package:pluto_grid/pluto_grid.dart';
import 'package:bpe/app/data/model/model_imports.dart';

import 'package:bpe/app/infra/infra_imports.dart';
import 'package:intl/intl.dart';
import 'package:bpe/app/data/domain/domain_imports.dart';

class BpePassageiroModel extends ModelBase {
  int? id;
  int? idBpeCabecalho;
  String? nome;
  String? cpf;
  String? tipoDocumentoIdentificacao;
  String? numeroDocumento;
  String? documentoOutrosDescricao;
  DateTime? dataNascimento;
  String? telefone;
  String? email;

  BpePassageiroModel({
    this.id,
    this.idBpeCabecalho,
    this.nome,
    this.cpf,
    this.tipoDocumentoIdentificacao = '1-RG',
    this.numeroDocumento,
    this.documentoOutrosDescricao,
    this.dataNascimento,
    this.telefone,
    this.email,
  });

  static List<String> dbColumns = <String>[
    'id',
    'nome',
    'cpf',
    'tipo_documento_identificacao',
    'numero_documento',
    'documento_outros_descricao',
    'data_nascimento',
    'telefone',
    'email',
  ];

  static List<String> aliasColumns = <String>[
    'Id',
    'Nome',
    'Cpf',
    'Tipo Documento Identificacao',
    'Numero Documento',
    'Documento Outros Descricao',
    'Data Nascimento',
    'Telefone',
    'Email',
  ];

  BpePassageiroModel.fromJson(Map<String, dynamic> jsonData) {
    id = jsonData['id'];
    idBpeCabecalho = jsonData['idBpeCabecalho'];
    nome = jsonData['nome'];
    cpf = jsonData['cpf'];
    tipoDocumentoIdentificacao = BpePassageiroDomain.getTipoDocumentoIdentificacao(jsonData['tipoDocumentoIdentificacao']);
    numeroDocumento = jsonData['numeroDocumento'];
    documentoOutrosDescricao = jsonData['documentoOutrosDescricao'];
    dataNascimento = jsonData['dataNascimento'] != null ? DateTime.tryParse(jsonData['dataNascimento']) : null;
    telefone = jsonData['telefone'];
    email = jsonData['email'];
  }

  Map<String, dynamic> get toJson {
    Map<String, dynamic> jsonData = <String, dynamic>{};

    jsonData['id'] = id != 0 ? id : null;
    jsonData['idBpeCabecalho'] = idBpeCabecalho != 0 ? idBpeCabecalho : null;
    jsonData['nome'] = nome;
    jsonData['cpf'] = Util.removeMask(cpf);
    jsonData['tipoDocumentoIdentificacao'] = BpePassageiroDomain.setTipoDocumentoIdentificacao(tipoDocumentoIdentificacao);
    jsonData['numeroDocumento'] = numeroDocumento;
    jsonData['documentoOutrosDescricao'] = documentoOutrosDescricao;
    jsonData['dataNascimento'] = dataNascimento != null ? DateFormat('yyyy-MM-ddT00:00:00').format(dataNascimento!) : null;
    jsonData['telefone'] = telefone;
    jsonData['email'] = email;

    return jsonData;
  }

  String objectEncodeJson() {
    final jsonData = toJson;
    return json.encode(jsonData);
  }

  static BpePassageiroModel fromPlutoRow(PlutoRow row) {
    return BpePassageiroModel(
      id: row.cells['id']?.value,
      idBpeCabecalho: row.cells['idBpeCabecalho']?.value,
      nome: row.cells['nome']?.value,
      cpf: row.cells['cpf']?.value,
      tipoDocumentoIdentificacao: row.cells['tipoDocumentoIdentificacao']?.value,
      numeroDocumento: row.cells['numeroDocumento']?.value,
      documentoOutrosDescricao: row.cells['documentoOutrosDescricao']?.value,
      dataNascimento: Util.stringToDate(row.cells['dataNascimento']?.value),
      telefone: row.cells['telefone']?.value,
      email: row.cells['email']?.value,
    );
  }

  PlutoRow toPlutoRow() {
    return PlutoRow(
      cells: {
        'tempId': PlutoCell(value: tempId),
        'id': PlutoCell(value: id ?? 0),
        'idBpeCabecalho': PlutoCell(value: idBpeCabecalho ?? 0),
        'nome': PlutoCell(value: nome ?? ''),
        'cpf': PlutoCell(value: cpf ?? ''),
        'tipoDocumentoIdentificacao': PlutoCell(value: tipoDocumentoIdentificacao ?? ''),
        'numeroDocumento': PlutoCell(value: numeroDocumento ?? ''),
        'documentoOutrosDescricao': PlutoCell(value: documentoOutrosDescricao ?? ''),
        'dataNascimento': PlutoCell(value: dataNascimento),
        'telefone': PlutoCell(value: telefone ?? ''),
        'email': PlutoCell(value: email ?? ''),
      },
    );
  }

  BpePassageiroModel clone() {
    return BpePassageiroModel(
      id: id,
      idBpeCabecalho: idBpeCabecalho,
      nome: nome,
      cpf: cpf,
      tipoDocumentoIdentificacao: tipoDocumentoIdentificacao,
      numeroDocumento: numeroDocumento,
      documentoOutrosDescricao: documentoOutrosDescricao,
      dataNascimento: dataNascimento,
      telefone: telefone,
      email: email,
    );
  }


}