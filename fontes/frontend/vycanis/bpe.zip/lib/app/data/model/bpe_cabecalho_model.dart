import 'dart:convert';
import 'package:pluto_grid/pluto_grid.dart';
import 'package:bpe/app/data/model/model_imports.dart';

import 'package:bpe/app/infra/infra_imports.dart';
import 'package:intl/intl.dart';
import 'package:bpe/app/data/domain/domain_imports.dart';

class BpeCabecalhoModel extends ModelBase {
  int? id;
  String? ufEmitente;
  String? ambiente;
  String? modelo;
  String? serie;
  String? numero;
  String? codigoNumerico;
  String? chaveAcesso;
  String? digitoChaveAcesso;
  String? modal;
  DateTime? dataHoraEmissao;
  String? tipoEmissao;
  String? versaoProcessoEmissao;
  String? tipoBpe;
  String? consumidorPresenca;
  String? ufInicioViagem;
  int? codigoMunicipioInicioViagem;
  String? ufFimViagem;
  int? codigoMunicipioFimViagem;
  double? valorBilhete;
  double? valorDesconto;
  double? valorPago;
  double? valorTroco;
  String? tipoDesconto;
  String? descontoDescricao;
  String? descontoConcedidoOutros;
  String? formaPagamento;
  String? formaPagamentoOutros;
  String? formaPagamentoDocumento;
  String? cst;
  double? baseCalculoIcms;
  double? aliquotaIcms;
  double? valorIcms;
  double? percentualReducaoBcIcms;
  String? informacoesAddFisco;
  List<BpeEmitenteModel>? bpeEmitenteModelList;
  List<BpePassageiroModel>? bpePassageiroModelList;
  List<BpeCompradorModel>? bpeCompradorModelList;
  List<BpeViagemModel>? bpeViagemModelList;
  List<BpeAgenciaModel>? bpeAgenciaModelList;
  List<BpePassagemModel>? bpePassagemModelList;

  BpeCabecalhoModel({
    this.id,
    this.ufEmitente,
    this.ambiente = '1 - Produção',
    this.modelo = '63',
    this.serie,
    this.numero,
    this.codigoNumerico,
    this.chaveAcesso,
    this.digitoChaveAcesso,
    this.modal = '1 - Rodoviário',
    this.dataHoraEmissao,
    this.tipoEmissao = '1 - Normal',
    this.versaoProcessoEmissao,
    this.tipoBpe = '0 - BP-e normal',
    this.consumidorPresenca = '1=Operação presencial não embarcado',
    this.ufInicioViagem = 'AC',
    this.codigoMunicipioInicioViagem,
    this.ufFimViagem = 'AC',
    this.codigoMunicipioFimViagem,
    this.valorBilhete,
    this.valorDesconto,
    this.valorPago,
    this.valorTroco,
    this.tipoDesconto = '01 - Tarifa promocional',
    this.descontoDescricao,
    this.descontoConcedidoOutros,
    this.formaPagamento = '01-Dinheiro',
    this.formaPagamentoOutros,
    this.formaPagamentoDocumento,
    this.cst,
    this.baseCalculoIcms,
    this.aliquotaIcms,
    this.valorIcms,
    this.percentualReducaoBcIcms,
    this.informacoesAddFisco,
    List<BpeEmitenteModel>? bpeEmitenteModelList,
    List<BpePassageiroModel>? bpePassageiroModelList,
    List<BpeCompradorModel>? bpeCompradorModelList,
    List<BpeViagemModel>? bpeViagemModelList,
    List<BpeAgenciaModel>? bpeAgenciaModelList,
    List<BpePassagemModel>? bpePassagemModelList,
  }) {
    this.bpeEmitenteModelList = bpeEmitenteModelList?.toList(growable: true) ?? [];
    this.bpePassageiroModelList = bpePassageiroModelList?.toList(growable: true) ?? [];
    this.bpeCompradorModelList = bpeCompradorModelList?.toList(growable: true) ?? [];
    this.bpeViagemModelList = bpeViagemModelList?.toList(growable: true) ?? [];
    this.bpeAgenciaModelList = bpeAgenciaModelList?.toList(growable: true) ?? [];
    this.bpePassagemModelList = bpePassagemModelList?.toList(growable: true) ?? [];
  }

  static List<String> dbColumns = <String>[
    'id',
    'uf_emitente',
    'ambiente',
    'modelo',
    'serie',
    'numero',
    'codigo_numerico',
    'chave_acesso',
    'digito_chave_acesso',
    'modal',
    'data_hora_emissao',
    'tipo_emissao',
    'versao_processo_emissao',
    'tipo_bpe',
    'consumidor_presenca',
    'uf_inicio_viagem',
    'codigo_municipio_inicio_viagem',
    'uf_fim_viagem',
    'codigo_municipio_fim_viagem',
    'valor_bilhete',
    'valor_desconto',
    'valor_pago',
    'valor_troco',
    'tipo_desconto',
    'desconto_descricao',
    'desconto_concedido_outros',
    'forma_pagamento',
    'forma_pagamento_outros',
    'forma_pagamento_documento',
    'cst',
    'base_calculo_icms',
    'aliquota_icms',
    'valor_icms',
    'percentual_reducao_bc_icms',
    'informacoes_add_fisco',
  ];

  static List<String> aliasColumns = <String>[
    'Id',
    'Uf Emitente',
    'Ambiente',
    'Modelo',
    'Serie',
    'Numero',
    'Codigo Numerico',
    'Chave Acesso',
    'Digito Chave Acesso',
    'Modal',
    'Data Hora Emissao',
    'Tipo Emissao',
    'Versao Processo Emissao',
    'Tipo Bpe',
    'Consumidor Presenca',
    'Uf Inicio Viagem',
    'Codigo Municipio Inicio Viagem',
    'Uf Fim Viagem',
    'Codigo Municipio Fim Viagem',
    'Valor Bilhete',
    'Valor Desconto',
    'Valor Pago',
    'Valor Troco',
    'Tipo Desconto',
    'Desconto Descricao',
    'Desconto Concedido Outros',
    'Forma Pagamento',
    'Forma Pagamento Outros',
    'Forma Pagamento Documento',
    'Cst',
    'Base Calculo Icms',
    'Aliquota Icms',
    'Valor Icms',
    'Percentual Reducao Bc Icms',
    'Informacoes Add Fisco',
  ];

  BpeCabecalhoModel.fromJson(Map<String, dynamic> jsonData) {
    id = jsonData['id'];
    ufEmitente = jsonData['ufEmitente'];
    ambiente = BpeCabecalhoDomain.getAmbiente(jsonData['ambiente']);
    modelo = BpeCabecalhoDomain.getModelo(jsonData['modelo']);
    serie = jsonData['serie'];
    numero = jsonData['numero'];
    codigoNumerico = jsonData['codigoNumerico'];
    chaveAcesso = jsonData['chaveAcesso'];
    digitoChaveAcesso = jsonData['digitoChaveAcesso'];
    modal = BpeCabecalhoDomain.getModal(jsonData['modal']);
    dataHoraEmissao = jsonData['dataHoraEmissao'] != null ? DateTime.tryParse(jsonData['dataHoraEmissao']) : null;
    tipoEmissao = BpeCabecalhoDomain.getTipoEmissao(jsonData['tipoEmissao']);
    versaoProcessoEmissao = jsonData['versaoProcessoEmissao'];
    tipoBpe = BpeCabecalhoDomain.getTipoBpe(jsonData['tipoBpe']);
    consumidorPresenca = BpeCabecalhoDomain.getConsumidorPresenca(jsonData['consumidorPresenca']);
    ufInicioViagem = BpeCabecalhoDomain.getUfInicioViagem(jsonData['ufInicioViagem']);
    codigoMunicipioInicioViagem = jsonData['codigoMunicipioInicioViagem'];
    ufFimViagem = BpeCabecalhoDomain.getUfFimViagem(jsonData['ufFimViagem']);
    codigoMunicipioFimViagem = jsonData['codigoMunicipioFimViagem'];
    valorBilhete = jsonData['valorBilhete']?.toDouble();
    valorDesconto = jsonData['valorDesconto']?.toDouble();
    valorPago = jsonData['valorPago']?.toDouble();
    valorTroco = jsonData['valorTroco']?.toDouble();
    tipoDesconto = BpeCabecalhoDomain.getTipoDesconto(jsonData['tipoDesconto']);
    descontoDescricao = jsonData['descontoDescricao'];
    descontoConcedidoOutros = jsonData['descontoConcedidoOutros'];
    formaPagamento = BpeCabecalhoDomain.getFormaPagamento(jsonData['formaPagamento']);
    formaPagamentoOutros = jsonData['formaPagamentoOutros'];
    formaPagamentoDocumento = jsonData['formaPagamentoDocumento'];
    cst = jsonData['cst'];
    baseCalculoIcms = jsonData['baseCalculoIcms']?.toDouble();
    aliquotaIcms = jsonData['aliquotaIcms']?.toDouble();
    valorIcms = jsonData['valorIcms']?.toDouble();
    percentualReducaoBcIcms = jsonData['percentualReducaoBcIcms']?.toDouble();
    informacoesAddFisco = jsonData['informacoesAddFisco'];
    bpeEmitenteModelList = (jsonData['bpeEmitenteModelList'] as Iterable?)?.map((m) => BpeEmitenteModel.fromJson(m)).toList() ?? [];
    bpePassageiroModelList = (jsonData['bpePassageiroModelList'] as Iterable?)?.map((m) => BpePassageiroModel.fromJson(m)).toList() ?? [];
    bpeCompradorModelList = (jsonData['bpeCompradorModelList'] as Iterable?)?.map((m) => BpeCompradorModel.fromJson(m)).toList() ?? [];
    bpeViagemModelList = (jsonData['bpeViagemModelList'] as Iterable?)?.map((m) => BpeViagemModel.fromJson(m)).toList() ?? [];
    bpeAgenciaModelList = (jsonData['bpeAgenciaModelList'] as Iterable?)?.map((m) => BpeAgenciaModel.fromJson(m)).toList() ?? [];
    bpePassagemModelList = (jsonData['bpePassagemModelList'] as Iterable?)?.map((m) => BpePassagemModel.fromJson(m)).toList() ?? [];
  }

  Map<String, dynamic> get toJson {
    Map<String, dynamic> jsonData = <String, dynamic>{};

    jsonData['id'] = id != 0 ? id : null;
    jsonData['ufEmitente'] = ufEmitente;
    jsonData['ambiente'] = BpeCabecalhoDomain.setAmbiente(ambiente);
    jsonData['modelo'] = BpeCabecalhoDomain.setModelo(modelo);
    jsonData['serie'] = serie;
    jsonData['numero'] = numero;
    jsonData['codigoNumerico'] = codigoNumerico;
    jsonData['chaveAcesso'] = chaveAcesso;
    jsonData['digitoChaveAcesso'] = digitoChaveAcesso;
    jsonData['modal'] = BpeCabecalhoDomain.setModal(modal);
    jsonData['dataHoraEmissao'] = dataHoraEmissao != null ? DateFormat('yyyy-MM-ddT00:00:00').format(dataHoraEmissao!) : null;
    jsonData['tipoEmissao'] = BpeCabecalhoDomain.setTipoEmissao(tipoEmissao);
    jsonData['versaoProcessoEmissao'] = versaoProcessoEmissao;
    jsonData['tipoBpe'] = BpeCabecalhoDomain.setTipoBpe(tipoBpe);
    jsonData['consumidorPresenca'] = BpeCabecalhoDomain.setConsumidorPresenca(consumidorPresenca);
    jsonData['ufInicioViagem'] = BpeCabecalhoDomain.setUfInicioViagem(ufInicioViagem);
    jsonData['codigoMunicipioInicioViagem'] = codigoMunicipioInicioViagem;
    jsonData['ufFimViagem'] = BpeCabecalhoDomain.setUfFimViagem(ufFimViagem);
    jsonData['codigoMunicipioFimViagem'] = codigoMunicipioFimViagem;
    jsonData['valorBilhete'] = valorBilhete;
    jsonData['valorDesconto'] = valorDesconto;
    jsonData['valorPago'] = valorPago;
    jsonData['valorTroco'] = valorTroco;
    jsonData['tipoDesconto'] = BpeCabecalhoDomain.setTipoDesconto(tipoDesconto);
    jsonData['descontoDescricao'] = descontoDescricao;
    jsonData['descontoConcedidoOutros'] = descontoConcedidoOutros;
    jsonData['formaPagamento'] = BpeCabecalhoDomain.setFormaPagamento(formaPagamento);
    jsonData['formaPagamentoOutros'] = formaPagamentoOutros;
    jsonData['formaPagamentoDocumento'] = formaPagamentoDocumento;
    jsonData['cst'] = cst;
    jsonData['baseCalculoIcms'] = baseCalculoIcms;
    jsonData['aliquotaIcms'] = aliquotaIcms;
    jsonData['valorIcms'] = valorIcms;
    jsonData['percentualReducaoBcIcms'] = percentualReducaoBcIcms;
    jsonData['informacoesAddFisco'] = informacoesAddFisco;
    
		var bpeEmitenteModelLocalList = []; 
		for (BpeEmitenteModel object in bpeEmitenteModelList ?? []) { 
			bpeEmitenteModelLocalList.add(object.toJson); 
		}
		jsonData['bpeEmitenteModelList'] = bpeEmitenteModelLocalList;
    
		var bpePassageiroModelLocalList = []; 
		for (BpePassageiroModel object in bpePassageiroModelList ?? []) { 
			bpePassageiroModelLocalList.add(object.toJson); 
		}
		jsonData['bpePassageiroModelList'] = bpePassageiroModelLocalList;
    
		var bpeCompradorModelLocalList = []; 
		for (BpeCompradorModel object in bpeCompradorModelList ?? []) { 
			bpeCompradorModelLocalList.add(object.toJson); 
		}
		jsonData['bpeCompradorModelList'] = bpeCompradorModelLocalList;
    
		var bpeViagemModelLocalList = []; 
		for (BpeViagemModel object in bpeViagemModelList ?? []) { 
			bpeViagemModelLocalList.add(object.toJson); 
		}
		jsonData['bpeViagemModelList'] = bpeViagemModelLocalList;
    
		var bpeAgenciaModelLocalList = []; 
		for (BpeAgenciaModel object in bpeAgenciaModelList ?? []) { 
			bpeAgenciaModelLocalList.add(object.toJson); 
		}
		jsonData['bpeAgenciaModelList'] = bpeAgenciaModelLocalList;
    
		var bpePassagemModelLocalList = []; 
		for (BpePassagemModel object in bpePassagemModelList ?? []) { 
			bpePassagemModelLocalList.add(object.toJson); 
		}
		jsonData['bpePassagemModelList'] = bpePassagemModelLocalList;

    return jsonData;
  }

  String objectEncodeJson() {
    final jsonData = toJson;
    return json.encode(jsonData);
  }

  static BpeCabecalhoModel fromPlutoRow(PlutoRow row) {
    return BpeCabecalhoModel(
      id: row.cells['id']?.value,
      ufEmitente: row.cells['ufEmitente']?.value,
      ambiente: row.cells['ambiente']?.value,
      modelo: row.cells['modelo']?.value,
      serie: row.cells['serie']?.value,
      numero: row.cells['numero']?.value,
      codigoNumerico: row.cells['codigoNumerico']?.value,
      chaveAcesso: row.cells['chaveAcesso']?.value,
      digitoChaveAcesso: row.cells['digitoChaveAcesso']?.value,
      modal: row.cells['modal']?.value,
      dataHoraEmissao: Util.stringToDate(row.cells['dataHoraEmissao']?.value),
      tipoEmissao: row.cells['tipoEmissao']?.value,
      versaoProcessoEmissao: row.cells['versaoProcessoEmissao']?.value,
      tipoBpe: row.cells['tipoBpe']?.value,
      consumidorPresenca: row.cells['consumidorPresenca']?.value,
      ufInicioViagem: row.cells['ufInicioViagem']?.value,
      codigoMunicipioInicioViagem: row.cells['codigoMunicipioInicioViagem']?.value,
      ufFimViagem: row.cells['ufFimViagem']?.value,
      codigoMunicipioFimViagem: row.cells['codigoMunicipioFimViagem']?.value,
      valorBilhete: row.cells['valorBilhete']?.value,
      valorDesconto: row.cells['valorDesconto']?.value,
      valorPago: row.cells['valorPago']?.value,
      valorTroco: row.cells['valorTroco']?.value,
      tipoDesconto: row.cells['tipoDesconto']?.value,
      descontoDescricao: row.cells['descontoDescricao']?.value,
      descontoConcedidoOutros: row.cells['descontoConcedidoOutros']?.value,
      formaPagamento: row.cells['formaPagamento']?.value,
      formaPagamentoOutros: row.cells['formaPagamentoOutros']?.value,
      formaPagamentoDocumento: row.cells['formaPagamentoDocumento']?.value,
      cst: row.cells['cst']?.value,
      baseCalculoIcms: row.cells['baseCalculoIcms']?.value,
      aliquotaIcms: row.cells['aliquotaIcms']?.value,
      valorIcms: row.cells['valorIcms']?.value,
      percentualReducaoBcIcms: row.cells['percentualReducaoBcIcms']?.value,
      informacoesAddFisco: row.cells['informacoesAddFisco']?.value,
    );
  }

  PlutoRow toPlutoRow() {
    return PlutoRow(
      cells: {
        'tempId': PlutoCell(value: tempId),
        'id': PlutoCell(value: id ?? 0),
        'ufEmitente': PlutoCell(value: ufEmitente ?? ''),
        'ambiente': PlutoCell(value: ambiente ?? ''),
        'modelo': PlutoCell(value: modelo ?? ''),
        'serie': PlutoCell(value: serie ?? ''),
        'numero': PlutoCell(value: numero ?? ''),
        'codigoNumerico': PlutoCell(value: codigoNumerico ?? ''),
        'chaveAcesso': PlutoCell(value: chaveAcesso ?? ''),
        'digitoChaveAcesso': PlutoCell(value: digitoChaveAcesso ?? ''),
        'modal': PlutoCell(value: modal ?? ''),
        'dataHoraEmissao': PlutoCell(value: dataHoraEmissao),
        'tipoEmissao': PlutoCell(value: tipoEmissao ?? ''),
        'versaoProcessoEmissao': PlutoCell(value: versaoProcessoEmissao ?? ''),
        'tipoBpe': PlutoCell(value: tipoBpe ?? ''),
        'consumidorPresenca': PlutoCell(value: consumidorPresenca ?? ''),
        'ufInicioViagem': PlutoCell(value: ufInicioViagem ?? ''),
        'codigoMunicipioInicioViagem': PlutoCell(value: codigoMunicipioInicioViagem ?? 0),
        'ufFimViagem': PlutoCell(value: ufFimViagem ?? ''),
        'codigoMunicipioFimViagem': PlutoCell(value: codigoMunicipioFimViagem ?? 0),
        'valorBilhete': PlutoCell(value: valorBilhete ?? 0.0),
        'valorDesconto': PlutoCell(value: valorDesconto ?? 0.0),
        'valorPago': PlutoCell(value: valorPago ?? 0.0),
        'valorTroco': PlutoCell(value: valorTroco ?? 0.0),
        'tipoDesconto': PlutoCell(value: tipoDesconto ?? ''),
        'descontoDescricao': PlutoCell(value: descontoDescricao ?? ''),
        'descontoConcedidoOutros': PlutoCell(value: descontoConcedidoOutros ?? ''),
        'formaPagamento': PlutoCell(value: formaPagamento ?? ''),
        'formaPagamentoOutros': PlutoCell(value: formaPagamentoOutros ?? ''),
        'formaPagamentoDocumento': PlutoCell(value: formaPagamentoDocumento ?? ''),
        'cst': PlutoCell(value: cst ?? ''),
        'baseCalculoIcms': PlutoCell(value: baseCalculoIcms ?? 0.0),
        'aliquotaIcms': PlutoCell(value: aliquotaIcms ?? 0.0),
        'valorIcms': PlutoCell(value: valorIcms ?? 0.0),
        'percentualReducaoBcIcms': PlutoCell(value: percentualReducaoBcIcms ?? 0.0),
        'informacoesAddFisco': PlutoCell(value: informacoesAddFisco ?? ''),
      },
    );
  }

  BpeCabecalhoModel clone() {
    return BpeCabecalhoModel(
      id: id,
      ufEmitente: ufEmitente,
      ambiente: ambiente,
      modelo: modelo,
      serie: serie,
      numero: numero,
      codigoNumerico: codigoNumerico,
      chaveAcesso: chaveAcesso,
      digitoChaveAcesso: digitoChaveAcesso,
      modal: modal,
      dataHoraEmissao: dataHoraEmissao,
      tipoEmissao: tipoEmissao,
      versaoProcessoEmissao: versaoProcessoEmissao,
      tipoBpe: tipoBpe,
      consumidorPresenca: consumidorPresenca,
      ufInicioViagem: ufInicioViagem,
      codigoMunicipioInicioViagem: codigoMunicipioInicioViagem,
      ufFimViagem: ufFimViagem,
      codigoMunicipioFimViagem: codigoMunicipioFimViagem,
      valorBilhete: valorBilhete,
      valorDesconto: valorDesconto,
      valorPago: valorPago,
      valorTroco: valorTroco,
      tipoDesconto: tipoDesconto,
      descontoDescricao: descontoDescricao,
      descontoConcedidoOutros: descontoConcedidoOutros,
      formaPagamento: formaPagamento,
      formaPagamentoOutros: formaPagamentoOutros,
      formaPagamentoDocumento: formaPagamentoDocumento,
      cst: cst,
      baseCalculoIcms: baseCalculoIcms,
      aliquotaIcms: aliquotaIcms,
      valorIcms: valorIcms,
      percentualReducaoBcIcms: percentualReducaoBcIcms,
      informacoesAddFisco: informacoesAddFisco,
      bpeEmitenteModelList: bpeEmitenteModelListClone(bpeEmitenteModelList!),
      bpePassageiroModelList: bpePassageiroModelListClone(bpePassageiroModelList!),
      bpeCompradorModelList: bpeCompradorModelListClone(bpeCompradorModelList!),
      bpeViagemModelList: bpeViagemModelListClone(bpeViagemModelList!),
      bpeAgenciaModelList: bpeAgenciaModelListClone(bpeAgenciaModelList!),
      bpePassagemModelList: bpePassagemModelListClone(bpePassagemModelList!),
    );
  }

  bpeEmitenteModelListClone(List<BpeEmitenteModel> bpeEmitenteModelList) { 
		List<BpeEmitenteModel> resultList = [];
		for (var bpeEmitenteModel in bpeEmitenteModelList) {
			resultList.add(bpeEmitenteModel.clone());
		}
		return resultList;
	}

  bpePassageiroModelListClone(List<BpePassageiroModel> bpePassageiroModelList) { 
		List<BpePassageiroModel> resultList = [];
		for (var bpePassageiroModel in bpePassageiroModelList) {
			resultList.add(bpePassageiroModel.clone());
		}
		return resultList;
	}

  bpeCompradorModelListClone(List<BpeCompradorModel> bpeCompradorModelList) { 
		List<BpeCompradorModel> resultList = [];
		for (var bpeCompradorModel in bpeCompradorModelList) {
			resultList.add(bpeCompradorModel.clone());
		}
		return resultList;
	}

  bpeViagemModelListClone(List<BpeViagemModel> bpeViagemModelList) { 
		List<BpeViagemModel> resultList = [];
		for (var bpeViagemModel in bpeViagemModelList) {
			resultList.add(bpeViagemModel.clone());
		}
		return resultList;
	}

  bpeAgenciaModelListClone(List<BpeAgenciaModel> bpeAgenciaModelList) { 
		List<BpeAgenciaModel> resultList = [];
		for (var bpeAgenciaModel in bpeAgenciaModelList) {
			resultList.add(bpeAgenciaModel.clone());
		}
		return resultList;
	}

  bpePassagemModelListClone(List<BpePassagemModel> bpePassagemModelList) { 
		List<BpePassagemModel> resultList = [];
		for (var bpePassagemModel in bpePassagemModelList) {
			resultList.add(bpePassagemModel.clone());
		}
		return resultList;
	}


}