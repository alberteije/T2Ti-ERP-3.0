import 'dart:convert';
import 'package:pluto_grid/pluto_grid.dart';
import 'package:bpe/app/data/model/model_imports.dart';

import 'package:bpe/app/infra/infra_imports.dart';
import 'package:bpe/app/data/domain/domain_imports.dart';

class BpeEmitenteModel extends ModelBase {
  int? id;
  int? idBpeCabecalho;
  String? cnpj;
  String? ie;
  String? iest;
  String? im;
  String? cnae;
  String? crt;
  String? nome;
  String? fantasia;
  String? logradouro;
  String? numero;
  String? complemento;
  String? bairro;
  int? codigoMunicipio;
  String? nomeMunicipio;
  String? uf;
  String? cep;
  String? telefone;

  BpeEmitenteModel({
    this.id,
    this.idBpeCabecalho,
    this.cnpj,
    this.ie,
    this.iest,
    this.im,
    this.cnae,
    this.crt,
    this.nome,
    this.fantasia,
    this.logradouro,
    this.numero,
    this.complemento,
    this.bairro,
    this.codigoMunicipio,
    this.nomeMunicipio,
    this.uf = 'AC',
    this.cep,
    this.telefone,
  });

  static List<String> dbColumns = <String>[
    'id',
    'cnpj',
    'ie',
    'iest',
    'im',
    'cnae',
    'crt',
    'nome',
    'fantasia',
    'logradouro',
    'numero',
    'complemento',
    'bairro',
    'codigo_municipio',
    'nome_municipio',
    'uf',
    'cep',
    'telefone',
  ];

  static List<String> aliasColumns = <String>[
    'Id',
    'Cnpj',
    'Ie',
    'Iest',
    'Im',
    'Cnae',
    'Crt',
    'Nome',
    'Fantasia',
    'Logradouro',
    'Numero',
    'Complemento',
    'Bairro',
    'Codigo Municipio',
    'Nome Municipio',
    'Uf',
    'Cep',
    'Telefone',
  ];

  BpeEmitenteModel.fromJson(Map<String, dynamic> jsonData) {
    id = jsonData['id'];
    idBpeCabecalho = jsonData['idBpeCabecalho'];
    cnpj = jsonData['cnpj'];
    ie = jsonData['ie'];
    iest = jsonData['iest'];
    im = jsonData['im'];
    cnae = jsonData['cnae'];
    crt = jsonData['crt'];
    nome = jsonData['nome'];
    fantasia = jsonData['fantasia'];
    logradouro = jsonData['logradouro'];
    numero = jsonData['numero'];
    complemento = jsonData['complemento'];
    bairro = jsonData['bairro'];
    codigoMunicipio = jsonData['codigoMunicipio'];
    nomeMunicipio = jsonData['nomeMunicipio'];
    uf = BpeEmitenteDomain.getUf(jsonData['uf']);
    cep = jsonData['cep'];
    telefone = jsonData['telefone'];
  }

  Map<String, dynamic> get toJson {
    Map<String, dynamic> jsonData = <String, dynamic>{};

    jsonData['id'] = id != 0 ? id : null;
    jsonData['idBpeCabecalho'] = idBpeCabecalho != 0 ? idBpeCabecalho : null;
    jsonData['cnpj'] = Util.removeMask(cnpj);
    jsonData['ie'] = ie;
    jsonData['iest'] = iest;
    jsonData['im'] = im;
    jsonData['cnae'] = cnae;
    jsonData['crt'] = crt;
    jsonData['nome'] = nome;
    jsonData['fantasia'] = fantasia;
    jsonData['logradouro'] = logradouro;
    jsonData['numero'] = numero;
    jsonData['complemento'] = complemento;
    jsonData['bairro'] = bairro;
    jsonData['codigoMunicipio'] = codigoMunicipio;
    jsonData['nomeMunicipio'] = nomeMunicipio;
    jsonData['uf'] = BpeEmitenteDomain.setUf(uf);
    jsonData['cep'] = Util.removeMask(cep);
    jsonData['telefone'] = telefone;

    return jsonData;
  }

  String objectEncodeJson() {
    final jsonData = toJson;
    return json.encode(jsonData);
  }

  static BpeEmitenteModel fromPlutoRow(PlutoRow row) {
    return BpeEmitenteModel(
      id: row.cells['id']?.value,
      idBpeCabecalho: row.cells['idBpeCabecalho']?.value,
      cnpj: row.cells['cnpj']?.value,
      ie: row.cells['ie']?.value,
      iest: row.cells['iest']?.value,
      im: row.cells['im']?.value,
      cnae: row.cells['cnae']?.value,
      crt: row.cells['crt']?.value,
      nome: row.cells['nome']?.value,
      fantasia: row.cells['fantasia']?.value,
      logradouro: row.cells['logradouro']?.value,
      numero: row.cells['numero']?.value,
      complemento: row.cells['complemento']?.value,
      bairro: row.cells['bairro']?.value,
      codigoMunicipio: row.cells['codigoMunicipio']?.value,
      nomeMunicipio: row.cells['nomeMunicipio']?.value,
      uf: row.cells['uf']?.value,
      cep: row.cells['cep']?.value,
      telefone: row.cells['telefone']?.value,
    );
  }

  PlutoRow toPlutoRow() {
    return PlutoRow(
      cells: {
        'tempId': PlutoCell(value: tempId),
        'id': PlutoCell(value: id ?? 0),
        'idBpeCabecalho': PlutoCell(value: idBpeCabecalho ?? 0),
        'cnpj': PlutoCell(value: cnpj ?? ''),
        'ie': PlutoCell(value: ie ?? ''),
        'iest': PlutoCell(value: iest ?? ''),
        'im': PlutoCell(value: im ?? ''),
        'cnae': PlutoCell(value: cnae ?? ''),
        'crt': PlutoCell(value: crt ?? ''),
        'nome': PlutoCell(value: nome ?? ''),
        'fantasia': PlutoCell(value: fantasia ?? ''),
        'logradouro': PlutoCell(value: logradouro ?? ''),
        'numero': PlutoCell(value: numero ?? ''),
        'complemento': PlutoCell(value: complemento ?? ''),
        'bairro': PlutoCell(value: bairro ?? ''),
        'codigoMunicipio': PlutoCell(value: codigoMunicipio ?? 0),
        'nomeMunicipio': PlutoCell(value: nomeMunicipio ?? ''),
        'uf': PlutoCell(value: uf ?? ''),
        'cep': PlutoCell(value: cep ?? ''),
        'telefone': PlutoCell(value: telefone ?? ''),
      },
    );
  }

  BpeEmitenteModel clone() {
    return BpeEmitenteModel(
      id: id,
      idBpeCabecalho: idBpeCabecalho,
      cnpj: cnpj,
      ie: ie,
      iest: iest,
      im: im,
      cnae: cnae,
      crt: crt,
      nome: nome,
      fantasia: fantasia,
      logradouro: logradouro,
      numero: numero,
      complemento: complemento,
      bairro: bairro,
      codigoMunicipio: codigoMunicipio,
      nomeMunicipio: nomeMunicipio,
      uf: uf,
      cep: cep,
      telefone: telefone,
    );
  }


}