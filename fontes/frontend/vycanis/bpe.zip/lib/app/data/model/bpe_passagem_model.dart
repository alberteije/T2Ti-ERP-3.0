import 'dart:convert';
import 'package:pluto_grid/pluto_grid.dart';
import 'package:bpe/app/data/model/model_imports.dart';

import 'package:bpe/app/infra/infra_imports.dart';
import 'package:intl/intl.dart';

class BpePassagemModel extends ModelBase {
  int? id;
  int? idBpeCabecalho;
  String? codigoLocalidadeOrigem;
  String? descricaoLocalidadeOrigem;
  String? codigoLocalidadeDestino;
  String? descricaoLocalidadeDestino;
  DateTime? dataHoraEmbarque;
  DateTime? dataHoraValidade;

  BpePassagemModel({
    this.id,
    this.idBpeCabecalho,
    this.codigoLocalidadeOrigem,
    this.descricaoLocalidadeOrigem,
    this.codigoLocalidadeDestino,
    this.descricaoLocalidadeDestino,
    this.dataHoraEmbarque,
    this.dataHoraValidade,
  });

  static List<String> dbColumns = <String>[
    'id',
    'codigo_localidade_origem',
    'descricao_localidade_origem',
    'codigo_localidade_destino',
    'descricao_localidade_destino',
    'data_hora_embarque',
    'data_hora_validade',
  ];

  static List<String> aliasColumns = <String>[
    'Id',
    'Codigo Localidade Origem',
    'Descricao Localidade Origem',
    'Codigo Localidade Destino',
    'Descricao Localidade Destino',
    'Data Hora Embarque',
    'Data Hora Validade',
  ];

  BpePassagemModel.fromJson(Map<String, dynamic> jsonData) {
    id = jsonData['id'];
    idBpeCabecalho = jsonData['idBpeCabecalho'];
    codigoLocalidadeOrigem = jsonData['codigoLocalidadeOrigem'];
    descricaoLocalidadeOrigem = jsonData['descricaoLocalidadeOrigem'];
    codigoLocalidadeDestino = jsonData['codigoLocalidadeDestino'];
    descricaoLocalidadeDestino = jsonData['descricaoLocalidadeDestino'];
    dataHoraEmbarque = jsonData['dataHoraEmbarque'] != null ? DateTime.tryParse(jsonData['dataHoraEmbarque']) : null;
    dataHoraValidade = jsonData['dataHoraValidade'] != null ? DateTime.tryParse(jsonData['dataHoraValidade']) : null;
  }

  Map<String, dynamic> get toJson {
    Map<String, dynamic> jsonData = <String, dynamic>{};

    jsonData['id'] = id != 0 ? id : null;
    jsonData['idBpeCabecalho'] = idBpeCabecalho != 0 ? idBpeCabecalho : null;
    jsonData['codigoLocalidadeOrigem'] = codigoLocalidadeOrigem;
    jsonData['descricaoLocalidadeOrigem'] = descricaoLocalidadeOrigem;
    jsonData['codigoLocalidadeDestino'] = codigoLocalidadeDestino;
    jsonData['descricaoLocalidadeDestino'] = descricaoLocalidadeDestino;
    jsonData['dataHoraEmbarque'] = dataHoraEmbarque != null ? DateFormat('yyyy-MM-ddT00:00:00').format(dataHoraEmbarque!) : null;
    jsonData['dataHoraValidade'] = dataHoraValidade != null ? DateFormat('yyyy-MM-ddT00:00:00').format(dataHoraValidade!) : null;

    return jsonData;
  }

  String objectEncodeJson() {
    final jsonData = toJson;
    return json.encode(jsonData);
  }

  static BpePassagemModel fromPlutoRow(PlutoRow row) {
    return BpePassagemModel(
      id: row.cells['id']?.value,
      idBpeCabecalho: row.cells['idBpeCabecalho']?.value,
      codigoLocalidadeOrigem: row.cells['codigoLocalidadeOrigem']?.value,
      descricaoLocalidadeOrigem: row.cells['descricaoLocalidadeOrigem']?.value,
      codigoLocalidadeDestino: row.cells['codigoLocalidadeDestino']?.value,
      descricaoLocalidadeDestino: row.cells['descricaoLocalidadeDestino']?.value,
      dataHoraEmbarque: Util.stringToDate(row.cells['dataHoraEmbarque']?.value),
      dataHoraValidade: Util.stringToDate(row.cells['dataHoraValidade']?.value),
    );
  }

  PlutoRow toPlutoRow() {
    return PlutoRow(
      cells: {
        'tempId': PlutoCell(value: tempId),
        'id': PlutoCell(value: id ?? 0),
        'idBpeCabecalho': PlutoCell(value: idBpeCabecalho ?? 0),
        'codigoLocalidadeOrigem': PlutoCell(value: codigoLocalidadeOrigem ?? ''),
        'descricaoLocalidadeOrigem': PlutoCell(value: descricaoLocalidadeOrigem ?? ''),
        'codigoLocalidadeDestino': PlutoCell(value: codigoLocalidadeDestino ?? ''),
        'descricaoLocalidadeDestino': PlutoCell(value: descricaoLocalidadeDestino ?? ''),
        'dataHoraEmbarque': PlutoCell(value: dataHoraEmbarque),
        'dataHoraValidade': PlutoCell(value: dataHoraValidade),
      },
    );
  }

  BpePassagemModel clone() {
    return BpePassagemModel(
      id: id,
      idBpeCabecalho: idBpeCabecalho,
      codigoLocalidadeOrigem: codigoLocalidadeOrigem,
      descricaoLocalidadeOrigem: descricaoLocalidadeOrigem,
      codigoLocalidadeDestino: codigoLocalidadeDestino,
      descricaoLocalidadeDestino: descricaoLocalidadeDestino,
      dataHoraEmbarque: dataHoraEmbarque,
      dataHoraValidade: dataHoraValidade,
    );
  }


}