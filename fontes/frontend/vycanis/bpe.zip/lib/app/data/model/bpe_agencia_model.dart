import 'dart:convert';
import 'package:pluto_grid/pluto_grid.dart';
import 'package:bpe/app/data/model/model_imports.dart';

import 'package:bpe/app/infra/infra_imports.dart';
import 'package:bpe/app/data/domain/domain_imports.dart';

class BpeAgenciaModel extends ModelBase {
  int? id;
  int? idBpeCabecalho;
  String? cnpj;
  String? nome;
  String? telefone;
  String? logradouro;
  String? numero;
  String? complemento;
  String? bairro;
  int? codigoMunicipio;
  String? nomeMunicipio;
  String? uf;
  String? cep;
  int? codigoPais;
  String? nomePais;
  String? email;

  BpeAgenciaModel({
    this.id,
    this.idBpeCabecalho,
    this.cnpj,
    this.nome,
    this.telefone,
    this.logradouro,
    this.numero,
    this.complemento,
    this.bairro,
    this.codigoMunicipio,
    this.nomeMunicipio,
    this.uf = 'AC',
    this.cep,
    this.codigoPais,
    this.nomePais,
    this.email,
  });

  static List<String> dbColumns = <String>[
    'id',
    'cnpj',
    'nome',
    'telefone',
    'logradouro',
    'numero',
    'complemento',
    'bairro',
    'codigo_municipio',
    'nome_municipio',
    'uf',
    'cep',
    'codigo_pais',
    'nome_pais',
    'email',
  ];

  static List<String> aliasColumns = <String>[
    'Id',
    'Cnpj',
    'Nome',
    'Telefone',
    'Logradouro',
    'Numero',
    'Complemento',
    'Bairro',
    'Codigo Municipio',
    'Nome Municipio',
    'Uf',
    'Cep',
    'Codigo Pais',
    'Nome Pais',
    'Email',
  ];

  BpeAgenciaModel.fromJson(Map<String, dynamic> jsonData) {
    id = jsonData['id'];
    idBpeCabecalho = jsonData['idBpeCabecalho'];
    cnpj = jsonData['cnpj'];
    nome = jsonData['nome'];
    telefone = jsonData['telefone'];
    logradouro = jsonData['logradouro'];
    numero = jsonData['numero'];
    complemento = jsonData['complemento'];
    bairro = jsonData['bairro'];
    codigoMunicipio = jsonData['codigoMunicipio'];
    nomeMunicipio = jsonData['nomeMunicipio'];
    uf = BpeAgenciaDomain.getUf(jsonData['uf']);
    cep = jsonData['cep'];
    codigoPais = jsonData['codigoPais'];
    nomePais = jsonData['nomePais'];
    email = jsonData['email'];
  }

  Map<String, dynamic> get toJson {
    Map<String, dynamic> jsonData = <String, dynamic>{};

    jsonData['id'] = id != 0 ? id : null;
    jsonData['idBpeCabecalho'] = idBpeCabecalho != 0 ? idBpeCabecalho : null;
    jsonData['cnpj'] = Util.removeMask(cnpj);
    jsonData['nome'] = nome;
    jsonData['telefone'] = telefone;
    jsonData['logradouro'] = logradouro;
    jsonData['numero'] = numero;
    jsonData['complemento'] = complemento;
    jsonData['bairro'] = bairro;
    jsonData['codigoMunicipio'] = codigoMunicipio;
    jsonData['nomeMunicipio'] = nomeMunicipio;
    jsonData['uf'] = BpeAgenciaDomain.setUf(uf);
    jsonData['cep'] = Util.removeMask(cep);
    jsonData['codigoPais'] = codigoPais;
    jsonData['nomePais'] = nomePais;
    jsonData['email'] = email;

    return jsonData;
  }

  String objectEncodeJson() {
    final jsonData = toJson;
    return json.encode(jsonData);
  }

  static BpeAgenciaModel fromPlutoRow(PlutoRow row) {
    return BpeAgenciaModel(
      id: row.cells['id']?.value,
      idBpeCabecalho: row.cells['idBpeCabecalho']?.value,
      cnpj: row.cells['cnpj']?.value,
      nome: row.cells['nome']?.value,
      telefone: row.cells['telefone']?.value,
      logradouro: row.cells['logradouro']?.value,
      numero: row.cells['numero']?.value,
      complemento: row.cells['complemento']?.value,
      bairro: row.cells['bairro']?.value,
      codigoMunicipio: row.cells['codigoMunicipio']?.value,
      nomeMunicipio: row.cells['nomeMunicipio']?.value,
      uf: row.cells['uf']?.value,
      cep: row.cells['cep']?.value,
      codigoPais: row.cells['codigoPais']?.value,
      nomePais: row.cells['nomePais']?.value,
      email: row.cells['email']?.value,
    );
  }

  PlutoRow toPlutoRow() {
    return PlutoRow(
      cells: {
        'tempId': PlutoCell(value: tempId),
        'id': PlutoCell(value: id ?? 0),
        'idBpeCabecalho': PlutoCell(value: idBpeCabecalho ?? 0),
        'cnpj': PlutoCell(value: cnpj ?? ''),
        'nome': PlutoCell(value: nome ?? ''),
        'telefone': PlutoCell(value: telefone ?? ''),
        'logradouro': PlutoCell(value: logradouro ?? ''),
        'numero': PlutoCell(value: numero ?? ''),
        'complemento': PlutoCell(value: complemento ?? ''),
        'bairro': PlutoCell(value: bairro ?? ''),
        'codigoMunicipio': PlutoCell(value: codigoMunicipio ?? 0),
        'nomeMunicipio': PlutoCell(value: nomeMunicipio ?? ''),
        'uf': PlutoCell(value: uf ?? ''),
        'cep': PlutoCell(value: cep ?? ''),
        'codigoPais': PlutoCell(value: codigoPais ?? 0),
        'nomePais': PlutoCell(value: nomePais ?? ''),
        'email': PlutoCell(value: email ?? ''),
      },
    );
  }

  BpeAgenciaModel clone() {
    return BpeAgenciaModel(
      id: id,
      idBpeCabecalho: idBpeCabecalho,
      cnpj: cnpj,
      nome: nome,
      telefone: telefone,
      logradouro: logradouro,
      numero: numero,
      complemento: complemento,
      bairro: bairro,
      codigoMunicipio: codigoMunicipio,
      nomeMunicipio: nomeMunicipio,
      uf: uf,
      cep: cep,
      codigoPais: codigoPais,
      nomePais: nomePais,
      email: email,
    );
  }


}