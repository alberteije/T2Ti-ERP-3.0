import 'package:bpe/app/infra/constants.dart';
import 'package:bpe/app/data/provider/api/bpe_cabecalho_api_provider.dart';
import 'package:bpe/app/data/provider/drift/bpe_cabecalho_drift_provider.dart';
import 'package:bpe/app/data/model/model_imports.dart';

class BpeCabecalhoRepository {
  final BpeCabecalhoApiProvider bpeCabecalhoApiProvider;
  final BpeCabecalhoDriftProvider bpeCabecalhoDriftProvider;

  BpeCabecalhoRepository({required this.bpeCabecalhoApiProvider, required this.bpeCabecalhoDriftProvider});

  Future getList({Filter? filter}) async {
    if (Constants.usingLocalDatabase) {
      return await bpeCabecalhoDriftProvider.getList(filter: filter);
    } else {
      return await bpeCabecalhoApiProvider.getList(filter: filter);
    }
  }

  Future<BpeCabecalhoModel?>? save({required BpeCabecalhoModel bpeCabecalhoModel}) async {
    if (bpeCabecalhoModel.id != null) {
      if (Constants.usingLocalDatabase) {
        return await bpeCabecalhoDriftProvider.update(bpeCabecalhoModel);
      } else {
        return await bpeCabecalhoApiProvider.update(bpeCabecalhoModel);
      }
    } else {
      if (Constants.usingLocalDatabase) {
        return await bpeCabecalhoDriftProvider.insert(bpeCabecalhoModel);
      } else {
        return await bpeCabecalhoApiProvider.insert(bpeCabecalhoModel);
      }
    }   
  }

  Future<bool> delete({required int id}) async {
    if (Constants.usingLocalDatabase) {
      return await bpeCabecalhoDriftProvider.delete(id) ?? false;
    } else {
      return await bpeCabecalhoApiProvider.delete(id) ?? false;
    }
  }

  Future<dynamic> transmitirBpe({required BpeCabecalhoModel bpeCabecalhoModel}) async {
    return await bpeCabecalhoApiProvider.transmitirBpe(bpeCabecalhoModel);
  }
}