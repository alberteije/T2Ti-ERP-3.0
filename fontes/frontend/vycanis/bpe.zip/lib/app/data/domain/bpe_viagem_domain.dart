class BpeViagemDomain {
  BpeViagemDomain._();

  static getTipoViagem(String? tipoViagem) { 
		switch (tipoViagem) { 
			case '': 
			case '0': 
				return '00-regular'; 
			case '1': 
				return '01-extra '; 
			default: 
				return null; 
		} 
	} 

  static setTipoViagem(String? tipoViagem) { 
		switch (tipoViagem) { 
			case '00-regular': 
				return '0'; 
			case '01-extra ': 
				return '1'; 
			default: 
				return null; 
		} 
	}

  static getTipoServico(String? tipoServico) { 
		switch (tipoServico) { 
			case '': 
			case '1': 
				return '1-Convencional com sanitário'; 
			case '2': 
				return '2-Convencional sem sanitário'; 
			case '3': 
				return '3-Semileito'; 
			case '4': 
				return '4-Leito com ar condicionado'; 
			case '5': 
				return '5-Leito sem ar condicionado'; 
			case '6': 
				return '6-Executivo'; 
			case '7': 
				return '7-Semiurbano'; 
			case '8': 
				return '8-Longitudinal'; 
			case '9': 
				return '9-Travessia '; 
			default: 
				return null; 
		} 
	} 

  static setTipoServico(String? tipoServico) { 
		switch (tipoServico) { 
			case '1-Convencional com sanitário': 
				return '1'; 
			case '2-Convencional sem sanitário': 
				return '2'; 
			case '3-Semileito': 
				return '3'; 
			case '4-Leito com ar condicionado': 
				return '4'; 
			case '5-Leito sem ar condicionado': 
				return '5'; 
			case '6-Executivo': 
				return '6'; 
			case '7-Semiurbano': 
				return '7'; 
			case '8-Longitudinal': 
				return '8'; 
			case '9-Travessia ': 
				return '9'; 
			default: 
				return null; 
		} 
	}

  static getTipoAcomodacao(String? tipoAcomodacao) { 
		switch (tipoAcomodacao) { 
			case '': 
			case '1': 
				return '1-Assento/poltrona'; 
			case '2': 
				return '2-Rede'; 
			case '3': 
				return '3-Rede com ar-condicionado'; 
			case '4': 
				return '4-Cabine'; 
			case '5': 
				return '5-Outros '; 
			default: 
				return null; 
		} 
	} 

  static setTipoAcomodacao(String? tipoAcomodacao) { 
		switch (tipoAcomodacao) { 
			case '1-Assento/poltrona': 
				return '1'; 
			case '2-Rede': 
				return '2'; 
			case '3-Rede com ar-condicionado': 
				return '3'; 
			case '4-Cabine': 
				return '4'; 
			case '5-Outros ': 
				return '5'; 
			default: 
				return null; 
		} 
	}

  static getTipoTrecho(String? tipoTrecho) { 
		switch (tipoTrecho) { 
			case '': 
			case '1': 
				return '1-Normal'; 
			case '2': 
				return '2-Trecho Inicial'; 
			case '3': 
				return '3-Conexão '; 
			default: 
				return null; 
		} 
	} 

  static setTipoTrecho(String? tipoTrecho) { 
		switch (tipoTrecho) { 
			case '1-Normal': 
				return '1'; 
			case '2-Trecho Inicial': 
				return '2'; 
			case '3-Conexão ': 
				return '3'; 
			default: 
				return null; 
		} 
	}


  static final tipoViagemListDropdown = ['00-regular','01-extra '];
  static final tipoServicoListDropdown = ['1-Convencional com sanitário','2-Convencional sem sanitário','3-Semileito','4-Leito com ar condicionado','5-Leito sem ar condicionado','6-Executivo','7-Semiurbano','8-Longitudinal','9-Travessia '];
  static final tipoAcomodacaoListDropdown = ['1-Assento/poltrona','2-Rede','3-Rede com ar-condicionado','4-Cabine','5-Outros '];
  static final tipoTrechoListDropdown = ['1-Normal','2-Trecho Inicial','3-Conexão '];

}