class BpePassageiroDomain {
  BpePassageiroDomain._();

  static getTipoDocumentoIdentificacao(String? tipoDocumentoIdentificacao) { 
		switch (tipoDocumentoIdentificacao) { 
			case '': 
			case '1': 
				return '1-RG'; 
			case '2': 
				return '2-Título de Eleitor'; 
			case '3': 
				return '3-Passaporte'; 
			case '4': 
				return '4-CNH'; 
			case '5': 
				return '5-Outros'; 
			default: 
				return null; 
		} 
	} 

  static setTipoDocumentoIdentificacao(String? tipoDocumentoIdentificacao) { 
		switch (tipoDocumentoIdentificacao) { 
			case '1-RG': 
				return '1'; 
			case '2-Título de Eleitor': 
				return '2'; 
			case '3-Passaporte': 
				return '3'; 
			case '4-CNH': 
				return '4'; 
			case '5-Outros': 
				return '5'; 
			default: 
				return null; 
		} 
	}


  static final tipoDocumentoIdentificacaoListDropdown = ['1-RG','2-Título de Eleitor','3-Passaporte','4-CNH','5-Outros'];

}