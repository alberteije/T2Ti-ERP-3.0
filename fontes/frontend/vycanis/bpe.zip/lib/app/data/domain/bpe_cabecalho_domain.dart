class BpeCabecalhoDomain {
  BpeCabecalhoDomain._();

  static getAmbiente(String? ambiente) { 
		switch (ambiente) { 
			case '': 
			case '1': 
				return '1 - Produção'; 
			case '2': 
				return '2 - Homologação'; 
			default: 
				return null; 
		} 
	} 

  static setAmbiente(String? ambiente) { 
		switch (ambiente) { 
			case '1 - Produção': 
				return '1'; 
			case '2 - Homologação': 
				return '2'; 
			default: 
				return null; 
		} 
	}

  static getModelo(String? modelo) { 
		switch (modelo) { 
			case '': 
			case '63': 
				return '63'; 
			default: 
				return null; 
		} 
	} 

  static setModelo(String? modelo) { 
		switch (modelo) { 
			case '63': 
				return '63'; 
			default: 
				return null; 
		} 
	}

  static getModal(String? modal) { 
		switch (modal) { 
			case '': 
			case '1': 
				return '1 - Rodoviário'; 
			case '3': 
				return '3 - Aquaviário'; 
			case '4': 
				return '4 - Ferroviário'; 
			default: 
				return null; 
		} 
	} 

  static setModal(String? modal) { 
		switch (modal) { 
			case '1 - Rodoviário': 
				return '1'; 
			case '3 - Aquaviário': 
				return '3'; 
			case '4 - Ferroviário': 
				return '4'; 
			default: 
				return null; 
		} 
	}

  static getTipoEmissao(String? tipoEmissao) { 
		switch (tipoEmissao) { 
			case '': 
			case '1': 
				return '1 - Normal'; 
			case '2': 
				return '2 - Contingência Off-Line'; 
			default: 
				return null; 
		} 
	} 

  static setTipoEmissao(String? tipoEmissao) { 
		switch (tipoEmissao) { 
			case '1 - Normal': 
				return '1'; 
			case '2 - Contingência Off-Line': 
				return '2'; 
			default: 
				return null; 
		} 
	}

  static getTipoBpe(String? tipoBpe) { 
		switch (tipoBpe) { 
			case '': 
			case '0': 
				return '0 - BP-e normal'; 
			case '3': 
				return '3 - BP-e substituição '; 
			default: 
				return null; 
		} 
	} 

  static setTipoBpe(String? tipoBpe) { 
		switch (tipoBpe) { 
			case '0 - BP-e normal': 
				return '0'; 
			case '3 - BP-e substituição ': 
				return '3'; 
			default: 
				return null; 
		} 
	}

  static getConsumidorPresenca(String? consumidorPresenca) { 
		switch (consumidorPresenca) { 
			case '': 
			case '1': 
				return '1=Operação presencial não embarcado'; 
			case '2': 
				return '2=Operação não presencial pela Internet'; 
			case '3': 
				return '3=Operação não presencial Teleatendimento'; 
			case '4': 
				return '4=BP-e em operação com entrega a domicílio'; 
			case '5': 
				return '5=Operação presencial embarcada'; 
			case '9': 
				return '9=Operação não presencial outros. '; 
			default: 
				return null; 
		} 
	} 

  static setConsumidorPresenca(String? consumidorPresenca) { 
		switch (consumidorPresenca) { 
			case '1=Operação presencial não embarcado': 
				return '1'; 
			case '2=Operação não presencial pela Internet': 
				return '2'; 
			case '3=Operação não presencial Teleatendimento': 
				return '3'; 
			case '4=BP-e em operação com entrega a domicílio': 
				return '4'; 
			case '5=Operação presencial embarcada': 
				return '5'; 
			case '9=Operação não presencial outros. ': 
				return '9'; 
			default: 
				return null; 
		} 
	}

  static getUfInicioViagem(String? ufInicioViagem) { 
		switch (ufInicioViagem) { 
			case '': 
			case 'AC': 
				return 'AC'; 
			case 'AL': 
				return 'AL'; 
			case 'AP': 
				return 'AP'; 
			case 'AM': 
				return 'AM'; 
			case 'BA': 
				return 'BA'; 
			case 'CE': 
				return 'CE'; 
			case 'DF': 
				return 'DF'; 
			case 'ES': 
				return 'ES'; 
			case 'GO': 
				return 'GO'; 
			case 'MA': 
				return 'MA'; 
			case 'MT': 
				return 'MT'; 
			case 'MS': 
				return 'MS'; 
			case 'MG': 
				return 'MG'; 
			case 'PA': 
				return 'PA'; 
			case 'PB': 
				return 'PB'; 
			case 'PR': 
				return 'PR'; 
			case 'PE': 
				return 'PE'; 
			case 'PI': 
				return 'PI'; 
			case 'RJ': 
				return 'RJ'; 
			case 'RN': 
				return 'RN'; 
			case 'RS': 
				return 'RS'; 
			case 'RO': 
				return 'RO'; 
			case 'RR': 
				return 'RR'; 
			case 'SC': 
				return 'SC'; 
			case 'SP': 
				return 'SP'; 
			case 'SE': 
				return 'SE'; 
			case 'TO': 
				return 'TO'; 
			default: 
				return null; 
		} 
	} 

  static setUfInicioViagem(String? ufInicioViagem) { 
		switch (ufInicioViagem) { 
			case 'AC': 
				return 'AC'; 
			case 'AL': 
				return 'AL'; 
			case 'AP': 
				return 'AP'; 
			case 'AM': 
				return 'AM'; 
			case 'BA': 
				return 'BA'; 
			case 'CE': 
				return 'CE'; 
			case 'DF': 
				return 'DF'; 
			case 'ES': 
				return 'ES'; 
			case 'GO': 
				return 'GO'; 
			case 'MA': 
				return 'MA'; 
			case 'MT': 
				return 'MT'; 
			case 'MS': 
				return 'MS'; 
			case 'MG': 
				return 'MG'; 
			case 'PA': 
				return 'PA'; 
			case 'PB': 
				return 'PB'; 
			case 'PR': 
				return 'PR'; 
			case 'PE': 
				return 'PE'; 
			case 'PI': 
				return 'PI'; 
			case 'RJ': 
				return 'RJ'; 
			case 'RN': 
				return 'RN'; 
			case 'RS': 
				return 'RS'; 
			case 'RO': 
				return 'RO'; 
			case 'RR': 
				return 'RR'; 
			case 'SC': 
				return 'SC'; 
			case 'SP': 
				return 'SP'; 
			case 'SE': 
				return 'SE'; 
			case 'TO': 
				return 'TO'; 
			default: 
				return null; 
		} 
	}

  static getUfFimViagem(String? ufFimViagem) { 
		switch (ufFimViagem) { 
			case '': 
			case 'AC': 
				return 'AC'; 
			case 'AL': 
				return 'AL'; 
			case 'AP': 
				return 'AP'; 
			case 'AM': 
				return 'AM'; 
			case 'BA': 
				return 'BA'; 
			case 'CE': 
				return 'CE'; 
			case 'DF': 
				return 'DF'; 
			case 'ES': 
				return 'ES'; 
			case 'GO': 
				return 'GO'; 
			case 'MA': 
				return 'MA'; 
			case 'MT': 
				return 'MT'; 
			case 'MS': 
				return 'MS'; 
			case 'MG': 
				return 'MG'; 
			case 'PA': 
				return 'PA'; 
			case 'PB': 
				return 'PB'; 
			case 'PR': 
				return 'PR'; 
			case 'PE': 
				return 'PE'; 
			case 'PI': 
				return 'PI'; 
			case 'RJ': 
				return 'RJ'; 
			case 'RN': 
				return 'RN'; 
			case 'RS': 
				return 'RS'; 
			case 'RO': 
				return 'RO'; 
			case 'RR': 
				return 'RR'; 
			case 'SC': 
				return 'SC'; 
			case 'SP': 
				return 'SP'; 
			case 'SE': 
				return 'SE'; 
			case 'TO': 
				return 'TO'; 
			default: 
				return null; 
		} 
	} 

  static setUfFimViagem(String? ufFimViagem) { 
		switch (ufFimViagem) { 
			case 'AC': 
				return 'AC'; 
			case 'AL': 
				return 'AL'; 
			case 'AP': 
				return 'AP'; 
			case 'AM': 
				return 'AM'; 
			case 'BA': 
				return 'BA'; 
			case 'CE': 
				return 'CE'; 
			case 'DF': 
				return 'DF'; 
			case 'ES': 
				return 'ES'; 
			case 'GO': 
				return 'GO'; 
			case 'MA': 
				return 'MA'; 
			case 'MT': 
				return 'MT'; 
			case 'MS': 
				return 'MS'; 
			case 'MG': 
				return 'MG'; 
			case 'PA': 
				return 'PA'; 
			case 'PB': 
				return 'PB'; 
			case 'PR': 
				return 'PR'; 
			case 'PE': 
				return 'PE'; 
			case 'PI': 
				return 'PI'; 
			case 'RJ': 
				return 'RJ'; 
			case 'RN': 
				return 'RN'; 
			case 'RS': 
				return 'RS'; 
			case 'RO': 
				return 'RO'; 
			case 'RR': 
				return 'RR'; 
			case 'SC': 
				return 'SC'; 
			case 'SP': 
				return 'SP'; 
			case 'SE': 
				return 'SE'; 
			case 'TO': 
				return 'TO'; 
			default: 
				return null; 
		} 
	}

  static getTipoDesconto(String? tipoDesconto) { 
		switch (tipoDesconto) { 
			case '': 
			case '0': 
				return '01 - Tarifa promocional'; 
			case '1': 
				return '02 - Idoso'; 
			case '2': 
				return '03 - Criança'; 
			case '3': 
				return '04 - Deficiente'; 
			case '4': 
				return '05 - Estudante'; 
			case '5': 
				return '06 - Animal Doméstico'; 
			case '6': 
				return '07 - Acordo Coletivo'; 
			case '7': 
				return '08 - Profissional em Deslocamento'; 
			case '8': 
				return '09 - Profissional da Empresa'; 
			case '9': 
				return '10 - Jovem'; 
			case '10': 
				return '99 - Outros'; 
			default: 
				return null; 
		} 
	} 

  static setTipoDesconto(String? tipoDesconto) { 
		switch (tipoDesconto) { 
			case '01 - Tarifa promocional': 
				return '0'; 
			case '02 - Idoso': 
				return '1'; 
			case '03 - Criança': 
				return '2'; 
			case '04 - Deficiente': 
				return '3'; 
			case '05 - Estudante': 
				return '4'; 
			case '06 - Animal Doméstico': 
				return '5'; 
			case '07 - Acordo Coletivo': 
				return '6'; 
			case '08 - Profissional em Deslocamento': 
				return '7'; 
			case '09 - Profissional da Empresa': 
				return '8'; 
			case '10 - Jovem': 
				return '9'; 
			case '99 - Outros': 
				return '10'; 
			default: 
				return null; 
		} 
	}

  static getFormaPagamento(String? formaPagamento) { 
		switch (formaPagamento) { 
			case '': 
			case '0': 
				return '01-Dinheiro'; 
			case '1': 
				return '02-Cheque'; 
			case '2': 
				return '03-Cartão de Crédito'; 
			case '3': 
				return '04-Cartão de Débito'; 
			case '4': 
				return '05-Vale Transporte'; 
			case '5': 
				return '99–Outros'; 
			default: 
				return null; 
		} 
	} 

  static setFormaPagamento(String? formaPagamento) { 
		switch (formaPagamento) { 
			case '01-Dinheiro': 
				return '0'; 
			case '02-Cheque': 
				return '1'; 
			case '03-Cartão de Crédito': 
				return '2'; 
			case '04-Cartão de Débito': 
				return '3'; 
			case '05-Vale Transporte': 
				return '4'; 
			case '99–Outros': 
				return '5'; 
			default: 
				return null; 
		} 
	}


  static final ambienteListDropdown = ['1 - Produção','2 - Homologação'];
  static final modeloListDropdown = ['63'];
  static final modalListDropdown = ['1 - Rodoviário','3 - Aquaviário','4 - Ferroviário'];
  static final tipoEmissaoListDropdown = ['1 - Normal','2 - Contingência Off-Line'];
  static final tipoBpeListDropdown = ['0 - BP-e normal','3 - BP-e substituição '];
  static final consumidorPresencaListDropdown = ['1=Operação presencial não embarcado','2=Operação não presencial pela Internet','3=Operação não presencial Teleatendimento','4=BP-e em operação com entrega a domicílio','5=Operação presencial embarcada','9=Operação não presencial outros. '];
  static final ufInicioViagemListDropdown = ['AC','AL','AP','AM','BA','CE','DF','ES','GO','MA','MT','MS','MG','PA','PB','PR','PE','PI','RJ','RN','RS','RO','RR','SC','SP','SE','TO'];
  static final ufFimViagemListDropdown = ['AC','AL','AP','AM','BA','CE','DF','ES','GO','MA','MT','MS','MG','PA','PB','PR','PE','PI','RJ','RN','RS','RO','RR','SC','SP','SE','TO'];
  static final tipoDescontoListDropdown = ['01 - Tarifa promocional','02 - Idoso','03 - Criança','04 - Deficiente','05 - Estudante','06 - Animal Doméstico','07 - Acordo Coletivo','08 - Profissional em Deslocamento','09 - Profissional da Empresa','10 - Jovem','99 - Outros'];
  static final formaPagamentoListDropdown = ['01-Dinheiro','02-Cheque','03-Cartão de Crédito','04-Cartão de Débito','05-Vale Transporte','99–Outros'];

}