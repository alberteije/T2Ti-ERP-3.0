import 'package:drift/drift.dart';
import 'package:bpe/app/data/provider/drift/database/database.dart';

@DataClassName("BpePassagem")
class BpePassagems extends Table {
	@override
	String get tableName => 'bpe_passagem';

	IntColumn get id => integer().named('id').nullable()();
	IntColumn get idBpeCabecalho => integer().named('id_bpe_cabecalho').nullable()();
	TextColumn get codigoLocalidadeOrigem => text().named('codigo_localidade_origem').withLength(min: 0, max: 7).nullable()();
	TextColumn get descricaoLocalidadeOrigem => text().named('descricao_localidade_origem').withLength(min: 0, max: 60).nullable()();
	TextColumn get codigoLocalidadeDestino => text().named('codigo_localidade_destino').withLength(min: 0, max: 7).nullable()();
	TextColumn get descricaoLocalidadeDestino => text().named('descricao_localidade_destino').withLength(min: 0, max: 60).nullable()();
	DateTimeColumn get dataHoraEmbarque => dateTime().named('data_hora_embarque').nullable()();
	DateTimeColumn get dataHoraValidade => dateTime().named('data_hora_validade').nullable()();

	@override
	Set<Column> get primaryKey => { id };	
	
}

class BpePassagemGrouped {
	BpePassagem? bpePassagem; 

  BpePassagemGrouped({
		this.bpePassagem, 

  });
}
