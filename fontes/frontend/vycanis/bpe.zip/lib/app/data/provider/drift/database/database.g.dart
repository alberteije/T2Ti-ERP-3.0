// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'database.dart';

// ignore_for_file: type=lint
class $BpeEmitentesTable extends BpeEmitentes
    with TableInfo<$BpeEmitentesTable, BpeEmitente> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $BpeEmitentesTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
    'id',
    aliasedName,
    true,
    type: DriftSqlType.int,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _idBpeCabecalhoMeta = const VerificationMeta(
    'idBpeCabecalho',
  );
  @override
  late final GeneratedColumn<int> idBpeCabecalho = GeneratedColumn<int>(
    'id_bpe_cabecalho',
    aliasedName,
    true,
    type: DriftSqlType.int,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _cnpjMeta = const VerificationMeta('cnpj');
  @override
  late final GeneratedColumn<String> cnpj = GeneratedColumn<String>(
    'cnpj',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 14,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _ieMeta = const VerificationMeta('ie');
  @override
  late final GeneratedColumn<String> ie = GeneratedColumn<String>(
    'ie',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 14,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _iestMeta = const VerificationMeta('iest');
  @override
  late final GeneratedColumn<String> iest = GeneratedColumn<String>(
    'iest',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 14,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _imMeta = const VerificationMeta('im');
  @override
  late final GeneratedColumn<String> im = GeneratedColumn<String>(
    'im',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 15,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _cnaeMeta = const VerificationMeta('cnae');
  @override
  late final GeneratedColumn<String> cnae = GeneratedColumn<String>(
    'cnae',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 7,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _crtMeta = const VerificationMeta('crt');
  @override
  late final GeneratedColumn<String> crt = GeneratedColumn<String>(
    'crt',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 1,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _nomeMeta = const VerificationMeta('nome');
  @override
  late final GeneratedColumn<String> nome = GeneratedColumn<String>(
    'nome',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 60,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _fantasiaMeta = const VerificationMeta(
    'fantasia',
  );
  @override
  late final GeneratedColumn<String> fantasia = GeneratedColumn<String>(
    'fantasia',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 60,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _logradouroMeta = const VerificationMeta(
    'logradouro',
  );
  @override
  late final GeneratedColumn<String> logradouro = GeneratedColumn<String>(
    'logradouro',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 60,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _numeroMeta = const VerificationMeta('numero');
  @override
  late final GeneratedColumn<String> numero = GeneratedColumn<String>(
    'numero',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 60,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _complementoMeta = const VerificationMeta(
    'complemento',
  );
  @override
  late final GeneratedColumn<String> complemento = GeneratedColumn<String>(
    'complemento',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 60,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _bairroMeta = const VerificationMeta('bairro');
  @override
  late final GeneratedColumn<String> bairro = GeneratedColumn<String>(
    'bairro',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 60,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _codigoMunicipioMeta = const VerificationMeta(
    'codigoMunicipio',
  );
  @override
  late final GeneratedColumn<int> codigoMunicipio = GeneratedColumn<int>(
    'codigo_municipio',
    aliasedName,
    true,
    type: DriftSqlType.int,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _nomeMunicipioMeta = const VerificationMeta(
    'nomeMunicipio',
  );
  @override
  late final GeneratedColumn<String> nomeMunicipio = GeneratedColumn<String>(
    'nome_municipio',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 60,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _ufMeta = const VerificationMeta('uf');
  @override
  late final GeneratedColumn<String> uf = GeneratedColumn<String>(
    'uf',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 2,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _cepMeta = const VerificationMeta('cep');
  @override
  late final GeneratedColumn<String> cep = GeneratedColumn<String>(
    'cep',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 8,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _telefoneMeta = const VerificationMeta(
    'telefone',
  );
  @override
  late final GeneratedColumn<String> telefone = GeneratedColumn<String>(
    'telefone',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 14,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  @override
  List<GeneratedColumn> get $columns => [
    id,
    idBpeCabecalho,
    cnpj,
    ie,
    iest,
    im,
    cnae,
    crt,
    nome,
    fantasia,
    logradouro,
    numero,
    complemento,
    bairro,
    codigoMunicipio,
    nomeMunicipio,
    uf,
    cep,
    telefone,
  ];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'bpe_emitente';
  @override
  VerificationContext validateIntegrity(
    Insertable<BpeEmitente> instance, {
    bool isInserting = false,
  }) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('id_bpe_cabecalho')) {
      context.handle(
        _idBpeCabecalhoMeta,
        idBpeCabecalho.isAcceptableOrUnknown(
          data['id_bpe_cabecalho']!,
          _idBpeCabecalhoMeta,
        ),
      );
    }
    if (data.containsKey('cnpj')) {
      context.handle(
        _cnpjMeta,
        cnpj.isAcceptableOrUnknown(data['cnpj']!, _cnpjMeta),
      );
    }
    if (data.containsKey('ie')) {
      context.handle(_ieMeta, ie.isAcceptableOrUnknown(data['ie']!, _ieMeta));
    }
    if (data.containsKey('iest')) {
      context.handle(
        _iestMeta,
        iest.isAcceptableOrUnknown(data['iest']!, _iestMeta),
      );
    }
    if (data.containsKey('im')) {
      context.handle(_imMeta, im.isAcceptableOrUnknown(data['im']!, _imMeta));
    }
    if (data.containsKey('cnae')) {
      context.handle(
        _cnaeMeta,
        cnae.isAcceptableOrUnknown(data['cnae']!, _cnaeMeta),
      );
    }
    if (data.containsKey('crt')) {
      context.handle(
        _crtMeta,
        crt.isAcceptableOrUnknown(data['crt']!, _crtMeta),
      );
    }
    if (data.containsKey('nome')) {
      context.handle(
        _nomeMeta,
        nome.isAcceptableOrUnknown(data['nome']!, _nomeMeta),
      );
    }
    if (data.containsKey('fantasia')) {
      context.handle(
        _fantasiaMeta,
        fantasia.isAcceptableOrUnknown(data['fantasia']!, _fantasiaMeta),
      );
    }
    if (data.containsKey('logradouro')) {
      context.handle(
        _logradouroMeta,
        logradouro.isAcceptableOrUnknown(data['logradouro']!, _logradouroMeta),
      );
    }
    if (data.containsKey('numero')) {
      context.handle(
        _numeroMeta,
        numero.isAcceptableOrUnknown(data['numero']!, _numeroMeta),
      );
    }
    if (data.containsKey('complemento')) {
      context.handle(
        _complementoMeta,
        complemento.isAcceptableOrUnknown(
          data['complemento']!,
          _complementoMeta,
        ),
      );
    }
    if (data.containsKey('bairro')) {
      context.handle(
        _bairroMeta,
        bairro.isAcceptableOrUnknown(data['bairro']!, _bairroMeta),
      );
    }
    if (data.containsKey('codigo_municipio')) {
      context.handle(
        _codigoMunicipioMeta,
        codigoMunicipio.isAcceptableOrUnknown(
          data['codigo_municipio']!,
          _codigoMunicipioMeta,
        ),
      );
    }
    if (data.containsKey('nome_municipio')) {
      context.handle(
        _nomeMunicipioMeta,
        nomeMunicipio.isAcceptableOrUnknown(
          data['nome_municipio']!,
          _nomeMunicipioMeta,
        ),
      );
    }
    if (data.containsKey('uf')) {
      context.handle(_ufMeta, uf.isAcceptableOrUnknown(data['uf']!, _ufMeta));
    }
    if (data.containsKey('cep')) {
      context.handle(
        _cepMeta,
        cep.isAcceptableOrUnknown(data['cep']!, _cepMeta),
      );
    }
    if (data.containsKey('telefone')) {
      context.handle(
        _telefoneMeta,
        telefone.isAcceptableOrUnknown(data['telefone']!, _telefoneMeta),
      );
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  BpeEmitente map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return BpeEmitente(
      id: attachedDatabase.typeMapping.read(
        DriftSqlType.int,
        data['${effectivePrefix}id'],
      ),
      idBpeCabecalho: attachedDatabase.typeMapping.read(
        DriftSqlType.int,
        data['${effectivePrefix}id_bpe_cabecalho'],
      ),
      cnpj: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}cnpj'],
      ),
      ie: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}ie'],
      ),
      iest: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}iest'],
      ),
      im: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}im'],
      ),
      cnae: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}cnae'],
      ),
      crt: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}crt'],
      ),
      nome: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}nome'],
      ),
      fantasia: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}fantasia'],
      ),
      logradouro: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}logradouro'],
      ),
      numero: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}numero'],
      ),
      complemento: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}complemento'],
      ),
      bairro: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}bairro'],
      ),
      codigoMunicipio: attachedDatabase.typeMapping.read(
        DriftSqlType.int,
        data['${effectivePrefix}codigo_municipio'],
      ),
      nomeMunicipio: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}nome_municipio'],
      ),
      uf: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}uf'],
      ),
      cep: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}cep'],
      ),
      telefone: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}telefone'],
      ),
    );
  }

  @override
  $BpeEmitentesTable createAlias(String alias) {
    return $BpeEmitentesTable(attachedDatabase, alias);
  }
}

class BpeEmitente extends DataClass implements Insertable<BpeEmitente> {
  final int? id;
  final int? idBpeCabecalho;
  final String? cnpj;
  final String? ie;
  final String? iest;
  final String? im;
  final String? cnae;
  final String? crt;
  final String? nome;
  final String? fantasia;
  final String? logradouro;
  final String? numero;
  final String? complemento;
  final String? bairro;
  final int? codigoMunicipio;
  final String? nomeMunicipio;
  final String? uf;
  final String? cep;
  final String? telefone;
  const BpeEmitente({
    this.id,
    this.idBpeCabecalho,
    this.cnpj,
    this.ie,
    this.iest,
    this.im,
    this.cnae,
    this.crt,
    this.nome,
    this.fantasia,
    this.logradouro,
    this.numero,
    this.complemento,
    this.bairro,
    this.codigoMunicipio,
    this.nomeMunicipio,
    this.uf,
    this.cep,
    this.telefone,
  });
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || idBpeCabecalho != null) {
      map['id_bpe_cabecalho'] = Variable<int>(idBpeCabecalho);
    }
    if (!nullToAbsent || cnpj != null) {
      map['cnpj'] = Variable<String>(cnpj);
    }
    if (!nullToAbsent || ie != null) {
      map['ie'] = Variable<String>(ie);
    }
    if (!nullToAbsent || iest != null) {
      map['iest'] = Variable<String>(iest);
    }
    if (!nullToAbsent || im != null) {
      map['im'] = Variable<String>(im);
    }
    if (!nullToAbsent || cnae != null) {
      map['cnae'] = Variable<String>(cnae);
    }
    if (!nullToAbsent || crt != null) {
      map['crt'] = Variable<String>(crt);
    }
    if (!nullToAbsent || nome != null) {
      map['nome'] = Variable<String>(nome);
    }
    if (!nullToAbsent || fantasia != null) {
      map['fantasia'] = Variable<String>(fantasia);
    }
    if (!nullToAbsent || logradouro != null) {
      map['logradouro'] = Variable<String>(logradouro);
    }
    if (!nullToAbsent || numero != null) {
      map['numero'] = Variable<String>(numero);
    }
    if (!nullToAbsent || complemento != null) {
      map['complemento'] = Variable<String>(complemento);
    }
    if (!nullToAbsent || bairro != null) {
      map['bairro'] = Variable<String>(bairro);
    }
    if (!nullToAbsent || codigoMunicipio != null) {
      map['codigo_municipio'] = Variable<int>(codigoMunicipio);
    }
    if (!nullToAbsent || nomeMunicipio != null) {
      map['nome_municipio'] = Variable<String>(nomeMunicipio);
    }
    if (!nullToAbsent || uf != null) {
      map['uf'] = Variable<String>(uf);
    }
    if (!nullToAbsent || cep != null) {
      map['cep'] = Variable<String>(cep);
    }
    if (!nullToAbsent || telefone != null) {
      map['telefone'] = Variable<String>(telefone);
    }
    return map;
  }

  factory BpeEmitente.fromJson(
    Map<String, dynamic> json, {
    ValueSerializer? serializer,
  }) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return BpeEmitente(
      id: serializer.fromJson<int?>(json['id']),
      idBpeCabecalho: serializer.fromJson<int?>(json['idBpeCabecalho']),
      cnpj: serializer.fromJson<String?>(json['cnpj']),
      ie: serializer.fromJson<String?>(json['ie']),
      iest: serializer.fromJson<String?>(json['iest']),
      im: serializer.fromJson<String?>(json['im']),
      cnae: serializer.fromJson<String?>(json['cnae']),
      crt: serializer.fromJson<String?>(json['crt']),
      nome: serializer.fromJson<String?>(json['nome']),
      fantasia: serializer.fromJson<String?>(json['fantasia']),
      logradouro: serializer.fromJson<String?>(json['logradouro']),
      numero: serializer.fromJson<String?>(json['numero']),
      complemento: serializer.fromJson<String?>(json['complemento']),
      bairro: serializer.fromJson<String?>(json['bairro']),
      codigoMunicipio: serializer.fromJson<int?>(json['codigoMunicipio']),
      nomeMunicipio: serializer.fromJson<String?>(json['nomeMunicipio']),
      uf: serializer.fromJson<String?>(json['uf']),
      cep: serializer.fromJson<String?>(json['cep']),
      telefone: serializer.fromJson<String?>(json['telefone']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'idBpeCabecalho': serializer.toJson<int?>(idBpeCabecalho),
      'cnpj': serializer.toJson<String?>(cnpj),
      'ie': serializer.toJson<String?>(ie),
      'iest': serializer.toJson<String?>(iest),
      'im': serializer.toJson<String?>(im),
      'cnae': serializer.toJson<String?>(cnae),
      'crt': serializer.toJson<String?>(crt),
      'nome': serializer.toJson<String?>(nome),
      'fantasia': serializer.toJson<String?>(fantasia),
      'logradouro': serializer.toJson<String?>(logradouro),
      'numero': serializer.toJson<String?>(numero),
      'complemento': serializer.toJson<String?>(complemento),
      'bairro': serializer.toJson<String?>(bairro),
      'codigoMunicipio': serializer.toJson<int?>(codigoMunicipio),
      'nomeMunicipio': serializer.toJson<String?>(nomeMunicipio),
      'uf': serializer.toJson<String?>(uf),
      'cep': serializer.toJson<String?>(cep),
      'telefone': serializer.toJson<String?>(telefone),
    };
  }

  BpeEmitente copyWith({
    Value<int?> id = const Value.absent(),
    Value<int?> idBpeCabecalho = const Value.absent(),
    Value<String?> cnpj = const Value.absent(),
    Value<String?> ie = const Value.absent(),
    Value<String?> iest = const Value.absent(),
    Value<String?> im = const Value.absent(),
    Value<String?> cnae = const Value.absent(),
    Value<String?> crt = const Value.absent(),
    Value<String?> nome = const Value.absent(),
    Value<String?> fantasia = const Value.absent(),
    Value<String?> logradouro = const Value.absent(),
    Value<String?> numero = const Value.absent(),
    Value<String?> complemento = const Value.absent(),
    Value<String?> bairro = const Value.absent(),
    Value<int?> codigoMunicipio = const Value.absent(),
    Value<String?> nomeMunicipio = const Value.absent(),
    Value<String?> uf = const Value.absent(),
    Value<String?> cep = const Value.absent(),
    Value<String?> telefone = const Value.absent(),
  }) => BpeEmitente(
    id: id.present ? id.value : this.id,
    idBpeCabecalho:
        idBpeCabecalho.present ? idBpeCabecalho.value : this.idBpeCabecalho,
    cnpj: cnpj.present ? cnpj.value : this.cnpj,
    ie: ie.present ? ie.value : this.ie,
    iest: iest.present ? iest.value : this.iest,
    im: im.present ? im.value : this.im,
    cnae: cnae.present ? cnae.value : this.cnae,
    crt: crt.present ? crt.value : this.crt,
    nome: nome.present ? nome.value : this.nome,
    fantasia: fantasia.present ? fantasia.value : this.fantasia,
    logradouro: logradouro.present ? logradouro.value : this.logradouro,
    numero: numero.present ? numero.value : this.numero,
    complemento: complemento.present ? complemento.value : this.complemento,
    bairro: bairro.present ? bairro.value : this.bairro,
    codigoMunicipio:
        codigoMunicipio.present ? codigoMunicipio.value : this.codigoMunicipio,
    nomeMunicipio:
        nomeMunicipio.present ? nomeMunicipio.value : this.nomeMunicipio,
    uf: uf.present ? uf.value : this.uf,
    cep: cep.present ? cep.value : this.cep,
    telefone: telefone.present ? telefone.value : this.telefone,
  );
  BpeEmitente copyWithCompanion(BpeEmitentesCompanion data) {
    return BpeEmitente(
      id: data.id.present ? data.id.value : this.id,
      idBpeCabecalho:
          data.idBpeCabecalho.present
              ? data.idBpeCabecalho.value
              : this.idBpeCabecalho,
      cnpj: data.cnpj.present ? data.cnpj.value : this.cnpj,
      ie: data.ie.present ? data.ie.value : this.ie,
      iest: data.iest.present ? data.iest.value : this.iest,
      im: data.im.present ? data.im.value : this.im,
      cnae: data.cnae.present ? data.cnae.value : this.cnae,
      crt: data.crt.present ? data.crt.value : this.crt,
      nome: data.nome.present ? data.nome.value : this.nome,
      fantasia: data.fantasia.present ? data.fantasia.value : this.fantasia,
      logradouro:
          data.logradouro.present ? data.logradouro.value : this.logradouro,
      numero: data.numero.present ? data.numero.value : this.numero,
      complemento:
          data.complemento.present ? data.complemento.value : this.complemento,
      bairro: data.bairro.present ? data.bairro.value : this.bairro,
      codigoMunicipio:
          data.codigoMunicipio.present
              ? data.codigoMunicipio.value
              : this.codigoMunicipio,
      nomeMunicipio:
          data.nomeMunicipio.present
              ? data.nomeMunicipio.value
              : this.nomeMunicipio,
      uf: data.uf.present ? data.uf.value : this.uf,
      cep: data.cep.present ? data.cep.value : this.cep,
      telefone: data.telefone.present ? data.telefone.value : this.telefone,
    );
  }

  @override
  String toString() {
    return (StringBuffer('BpeEmitente(')
          ..write('id: $id, ')
          ..write('idBpeCabecalho: $idBpeCabecalho, ')
          ..write('cnpj: $cnpj, ')
          ..write('ie: $ie, ')
          ..write('iest: $iest, ')
          ..write('im: $im, ')
          ..write('cnae: $cnae, ')
          ..write('crt: $crt, ')
          ..write('nome: $nome, ')
          ..write('fantasia: $fantasia, ')
          ..write('logradouro: $logradouro, ')
          ..write('numero: $numero, ')
          ..write('complemento: $complemento, ')
          ..write('bairro: $bairro, ')
          ..write('codigoMunicipio: $codigoMunicipio, ')
          ..write('nomeMunicipio: $nomeMunicipio, ')
          ..write('uf: $uf, ')
          ..write('cep: $cep, ')
          ..write('telefone: $telefone')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(
    id,
    idBpeCabecalho,
    cnpj,
    ie,
    iest,
    im,
    cnae,
    crt,
    nome,
    fantasia,
    logradouro,
    numero,
    complemento,
    bairro,
    codigoMunicipio,
    nomeMunicipio,
    uf,
    cep,
    telefone,
  );
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is BpeEmitente &&
          other.id == this.id &&
          other.idBpeCabecalho == this.idBpeCabecalho &&
          other.cnpj == this.cnpj &&
          other.ie == this.ie &&
          other.iest == this.iest &&
          other.im == this.im &&
          other.cnae == this.cnae &&
          other.crt == this.crt &&
          other.nome == this.nome &&
          other.fantasia == this.fantasia &&
          other.logradouro == this.logradouro &&
          other.numero == this.numero &&
          other.complemento == this.complemento &&
          other.bairro == this.bairro &&
          other.codigoMunicipio == this.codigoMunicipio &&
          other.nomeMunicipio == this.nomeMunicipio &&
          other.uf == this.uf &&
          other.cep == this.cep &&
          other.telefone == this.telefone);
}

class BpeEmitentesCompanion extends UpdateCompanion<BpeEmitente> {
  final Value<int?> id;
  final Value<int?> idBpeCabecalho;
  final Value<String?> cnpj;
  final Value<String?> ie;
  final Value<String?> iest;
  final Value<String?> im;
  final Value<String?> cnae;
  final Value<String?> crt;
  final Value<String?> nome;
  final Value<String?> fantasia;
  final Value<String?> logradouro;
  final Value<String?> numero;
  final Value<String?> complemento;
  final Value<String?> bairro;
  final Value<int?> codigoMunicipio;
  final Value<String?> nomeMunicipio;
  final Value<String?> uf;
  final Value<String?> cep;
  final Value<String?> telefone;
  const BpeEmitentesCompanion({
    this.id = const Value.absent(),
    this.idBpeCabecalho = const Value.absent(),
    this.cnpj = const Value.absent(),
    this.ie = const Value.absent(),
    this.iest = const Value.absent(),
    this.im = const Value.absent(),
    this.cnae = const Value.absent(),
    this.crt = const Value.absent(),
    this.nome = const Value.absent(),
    this.fantasia = const Value.absent(),
    this.logradouro = const Value.absent(),
    this.numero = const Value.absent(),
    this.complemento = const Value.absent(),
    this.bairro = const Value.absent(),
    this.codigoMunicipio = const Value.absent(),
    this.nomeMunicipio = const Value.absent(),
    this.uf = const Value.absent(),
    this.cep = const Value.absent(),
    this.telefone = const Value.absent(),
  });
  BpeEmitentesCompanion.insert({
    this.id = const Value.absent(),
    this.idBpeCabecalho = const Value.absent(),
    this.cnpj = const Value.absent(),
    this.ie = const Value.absent(),
    this.iest = const Value.absent(),
    this.im = const Value.absent(),
    this.cnae = const Value.absent(),
    this.crt = const Value.absent(),
    this.nome = const Value.absent(),
    this.fantasia = const Value.absent(),
    this.logradouro = const Value.absent(),
    this.numero = const Value.absent(),
    this.complemento = const Value.absent(),
    this.bairro = const Value.absent(),
    this.codigoMunicipio = const Value.absent(),
    this.nomeMunicipio = const Value.absent(),
    this.uf = const Value.absent(),
    this.cep = const Value.absent(),
    this.telefone = const Value.absent(),
  });
  static Insertable<BpeEmitente> custom({
    Expression<int>? id,
    Expression<int>? idBpeCabecalho,
    Expression<String>? cnpj,
    Expression<String>? ie,
    Expression<String>? iest,
    Expression<String>? im,
    Expression<String>? cnae,
    Expression<String>? crt,
    Expression<String>? nome,
    Expression<String>? fantasia,
    Expression<String>? logradouro,
    Expression<String>? numero,
    Expression<String>? complemento,
    Expression<String>? bairro,
    Expression<int>? codigoMunicipio,
    Expression<String>? nomeMunicipio,
    Expression<String>? uf,
    Expression<String>? cep,
    Expression<String>? telefone,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (idBpeCabecalho != null) 'id_bpe_cabecalho': idBpeCabecalho,
      if (cnpj != null) 'cnpj': cnpj,
      if (ie != null) 'ie': ie,
      if (iest != null) 'iest': iest,
      if (im != null) 'im': im,
      if (cnae != null) 'cnae': cnae,
      if (crt != null) 'crt': crt,
      if (nome != null) 'nome': nome,
      if (fantasia != null) 'fantasia': fantasia,
      if (logradouro != null) 'logradouro': logradouro,
      if (numero != null) 'numero': numero,
      if (complemento != null) 'complemento': complemento,
      if (bairro != null) 'bairro': bairro,
      if (codigoMunicipio != null) 'codigo_municipio': codigoMunicipio,
      if (nomeMunicipio != null) 'nome_municipio': nomeMunicipio,
      if (uf != null) 'uf': uf,
      if (cep != null) 'cep': cep,
      if (telefone != null) 'telefone': telefone,
    });
  }

  BpeEmitentesCompanion copyWith({
    Value<int?>? id,
    Value<int?>? idBpeCabecalho,
    Value<String?>? cnpj,
    Value<String?>? ie,
    Value<String?>? iest,
    Value<String?>? im,
    Value<String?>? cnae,
    Value<String?>? crt,
    Value<String?>? nome,
    Value<String?>? fantasia,
    Value<String?>? logradouro,
    Value<String?>? numero,
    Value<String?>? complemento,
    Value<String?>? bairro,
    Value<int?>? codigoMunicipio,
    Value<String?>? nomeMunicipio,
    Value<String?>? uf,
    Value<String?>? cep,
    Value<String?>? telefone,
  }) {
    return BpeEmitentesCompanion(
      id: id ?? this.id,
      idBpeCabecalho: idBpeCabecalho ?? this.idBpeCabecalho,
      cnpj: cnpj ?? this.cnpj,
      ie: ie ?? this.ie,
      iest: iest ?? this.iest,
      im: im ?? this.im,
      cnae: cnae ?? this.cnae,
      crt: crt ?? this.crt,
      nome: nome ?? this.nome,
      fantasia: fantasia ?? this.fantasia,
      logradouro: logradouro ?? this.logradouro,
      numero: numero ?? this.numero,
      complemento: complemento ?? this.complemento,
      bairro: bairro ?? this.bairro,
      codigoMunicipio: codigoMunicipio ?? this.codigoMunicipio,
      nomeMunicipio: nomeMunicipio ?? this.nomeMunicipio,
      uf: uf ?? this.uf,
      cep: cep ?? this.cep,
      telefone: telefone ?? this.telefone,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (idBpeCabecalho.present) {
      map['id_bpe_cabecalho'] = Variable<int>(idBpeCabecalho.value);
    }
    if (cnpj.present) {
      map['cnpj'] = Variable<String>(cnpj.value);
    }
    if (ie.present) {
      map['ie'] = Variable<String>(ie.value);
    }
    if (iest.present) {
      map['iest'] = Variable<String>(iest.value);
    }
    if (im.present) {
      map['im'] = Variable<String>(im.value);
    }
    if (cnae.present) {
      map['cnae'] = Variable<String>(cnae.value);
    }
    if (crt.present) {
      map['crt'] = Variable<String>(crt.value);
    }
    if (nome.present) {
      map['nome'] = Variable<String>(nome.value);
    }
    if (fantasia.present) {
      map['fantasia'] = Variable<String>(fantasia.value);
    }
    if (logradouro.present) {
      map['logradouro'] = Variable<String>(logradouro.value);
    }
    if (numero.present) {
      map['numero'] = Variable<String>(numero.value);
    }
    if (complemento.present) {
      map['complemento'] = Variable<String>(complemento.value);
    }
    if (bairro.present) {
      map['bairro'] = Variable<String>(bairro.value);
    }
    if (codigoMunicipio.present) {
      map['codigo_municipio'] = Variable<int>(codigoMunicipio.value);
    }
    if (nomeMunicipio.present) {
      map['nome_municipio'] = Variable<String>(nomeMunicipio.value);
    }
    if (uf.present) {
      map['uf'] = Variable<String>(uf.value);
    }
    if (cep.present) {
      map['cep'] = Variable<String>(cep.value);
    }
    if (telefone.present) {
      map['telefone'] = Variable<String>(telefone.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('BpeEmitentesCompanion(')
          ..write('id: $id, ')
          ..write('idBpeCabecalho: $idBpeCabecalho, ')
          ..write('cnpj: $cnpj, ')
          ..write('ie: $ie, ')
          ..write('iest: $iest, ')
          ..write('im: $im, ')
          ..write('cnae: $cnae, ')
          ..write('crt: $crt, ')
          ..write('nome: $nome, ')
          ..write('fantasia: $fantasia, ')
          ..write('logradouro: $logradouro, ')
          ..write('numero: $numero, ')
          ..write('complemento: $complemento, ')
          ..write('bairro: $bairro, ')
          ..write('codigoMunicipio: $codigoMunicipio, ')
          ..write('nomeMunicipio: $nomeMunicipio, ')
          ..write('uf: $uf, ')
          ..write('cep: $cep, ')
          ..write('telefone: $telefone')
          ..write(')'))
        .toString();
  }
}

class $BpePassageirosTable extends BpePassageiros
    with TableInfo<$BpePassageirosTable, BpePassageiro> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $BpePassageirosTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
    'id',
    aliasedName,
    true,
    type: DriftSqlType.int,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _idBpeCabecalhoMeta = const VerificationMeta(
    'idBpeCabecalho',
  );
  @override
  late final GeneratedColumn<int> idBpeCabecalho = GeneratedColumn<int>(
    'id_bpe_cabecalho',
    aliasedName,
    true,
    type: DriftSqlType.int,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _nomeMeta = const VerificationMeta('nome');
  @override
  late final GeneratedColumn<String> nome = GeneratedColumn<String>(
    'nome',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 60,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _cpfMeta = const VerificationMeta('cpf');
  @override
  late final GeneratedColumn<String> cpf = GeneratedColumn<String>(
    'cpf',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 11,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _tipoDocumentoIdentificacaoMeta =
      const VerificationMeta('tipoDocumentoIdentificacao');
  @override
  late final GeneratedColumn<String> tipoDocumentoIdentificacao =
      GeneratedColumn<String>(
        'tipo_documento_identificacao',
        aliasedName,
        true,
        additionalChecks: GeneratedColumn.checkTextLength(
          minTextLength: 0,
          maxTextLength: 1,
        ),
        type: DriftSqlType.string,
        requiredDuringInsert: false,
      );
  static const VerificationMeta _numeroDocumentoMeta = const VerificationMeta(
    'numeroDocumento',
  );
  @override
  late final GeneratedColumn<String> numeroDocumento = GeneratedColumn<String>(
    'numero_documento',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 20,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _documentoOutrosDescricaoMeta =
      const VerificationMeta('documentoOutrosDescricao');
  @override
  late final GeneratedColumn<String> documentoOutrosDescricao =
      GeneratedColumn<String>(
        'documento_outros_descricao',
        aliasedName,
        true,
        additionalChecks: GeneratedColumn.checkTextLength(
          minTextLength: 0,
          maxTextLength: 100,
        ),
        type: DriftSqlType.string,
        requiredDuringInsert: false,
      );
  static const VerificationMeta _dataNascimentoMeta = const VerificationMeta(
    'dataNascimento',
  );
  @override
  late final GeneratedColumn<DateTime> dataNascimento =
      GeneratedColumn<DateTime>(
        'data_nascimento',
        aliasedName,
        true,
        type: DriftSqlType.dateTime,
        requiredDuringInsert: false,
      );
  static const VerificationMeta _telefoneMeta = const VerificationMeta(
    'telefone',
  );
  @override
  late final GeneratedColumn<String> telefone = GeneratedColumn<String>(
    'telefone',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 12,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _emailMeta = const VerificationMeta('email');
  @override
  late final GeneratedColumn<String> email = GeneratedColumn<String>(
    'email',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 60,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  @override
  List<GeneratedColumn> get $columns => [
    id,
    idBpeCabecalho,
    nome,
    cpf,
    tipoDocumentoIdentificacao,
    numeroDocumento,
    documentoOutrosDescricao,
    dataNascimento,
    telefone,
    email,
  ];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'bpe_passageiro';
  @override
  VerificationContext validateIntegrity(
    Insertable<BpePassageiro> instance, {
    bool isInserting = false,
  }) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('id_bpe_cabecalho')) {
      context.handle(
        _idBpeCabecalhoMeta,
        idBpeCabecalho.isAcceptableOrUnknown(
          data['id_bpe_cabecalho']!,
          _idBpeCabecalhoMeta,
        ),
      );
    }
    if (data.containsKey('nome')) {
      context.handle(
        _nomeMeta,
        nome.isAcceptableOrUnknown(data['nome']!, _nomeMeta),
      );
    }
    if (data.containsKey('cpf')) {
      context.handle(
        _cpfMeta,
        cpf.isAcceptableOrUnknown(data['cpf']!, _cpfMeta),
      );
    }
    if (data.containsKey('tipo_documento_identificacao')) {
      context.handle(
        _tipoDocumentoIdentificacaoMeta,
        tipoDocumentoIdentificacao.isAcceptableOrUnknown(
          data['tipo_documento_identificacao']!,
          _tipoDocumentoIdentificacaoMeta,
        ),
      );
    }
    if (data.containsKey('numero_documento')) {
      context.handle(
        _numeroDocumentoMeta,
        numeroDocumento.isAcceptableOrUnknown(
          data['numero_documento']!,
          _numeroDocumentoMeta,
        ),
      );
    }
    if (data.containsKey('documento_outros_descricao')) {
      context.handle(
        _documentoOutrosDescricaoMeta,
        documentoOutrosDescricao.isAcceptableOrUnknown(
          data['documento_outros_descricao']!,
          _documentoOutrosDescricaoMeta,
        ),
      );
    }
    if (data.containsKey('data_nascimento')) {
      context.handle(
        _dataNascimentoMeta,
        dataNascimento.isAcceptableOrUnknown(
          data['data_nascimento']!,
          _dataNascimentoMeta,
        ),
      );
    }
    if (data.containsKey('telefone')) {
      context.handle(
        _telefoneMeta,
        telefone.isAcceptableOrUnknown(data['telefone']!, _telefoneMeta),
      );
    }
    if (data.containsKey('email')) {
      context.handle(
        _emailMeta,
        email.isAcceptableOrUnknown(data['email']!, _emailMeta),
      );
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  BpePassageiro map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return BpePassageiro(
      id: attachedDatabase.typeMapping.read(
        DriftSqlType.int,
        data['${effectivePrefix}id'],
      ),
      idBpeCabecalho: attachedDatabase.typeMapping.read(
        DriftSqlType.int,
        data['${effectivePrefix}id_bpe_cabecalho'],
      ),
      nome: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}nome'],
      ),
      cpf: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}cpf'],
      ),
      tipoDocumentoIdentificacao: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}tipo_documento_identificacao'],
      ),
      numeroDocumento: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}numero_documento'],
      ),
      documentoOutrosDescricao: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}documento_outros_descricao'],
      ),
      dataNascimento: attachedDatabase.typeMapping.read(
        DriftSqlType.dateTime,
        data['${effectivePrefix}data_nascimento'],
      ),
      telefone: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}telefone'],
      ),
      email: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}email'],
      ),
    );
  }

  @override
  $BpePassageirosTable createAlias(String alias) {
    return $BpePassageirosTable(attachedDatabase, alias);
  }
}

class BpePassageiro extends DataClass implements Insertable<BpePassageiro> {
  final int? id;
  final int? idBpeCabecalho;
  final String? nome;
  final String? cpf;
  final String? tipoDocumentoIdentificacao;
  final String? numeroDocumento;
  final String? documentoOutrosDescricao;
  final DateTime? dataNascimento;
  final String? telefone;
  final String? email;
  const BpePassageiro({
    this.id,
    this.idBpeCabecalho,
    this.nome,
    this.cpf,
    this.tipoDocumentoIdentificacao,
    this.numeroDocumento,
    this.documentoOutrosDescricao,
    this.dataNascimento,
    this.telefone,
    this.email,
  });
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || idBpeCabecalho != null) {
      map['id_bpe_cabecalho'] = Variable<int>(idBpeCabecalho);
    }
    if (!nullToAbsent || nome != null) {
      map['nome'] = Variable<String>(nome);
    }
    if (!nullToAbsent || cpf != null) {
      map['cpf'] = Variable<String>(cpf);
    }
    if (!nullToAbsent || tipoDocumentoIdentificacao != null) {
      map['tipo_documento_identificacao'] = Variable<String>(
        tipoDocumentoIdentificacao,
      );
    }
    if (!nullToAbsent || numeroDocumento != null) {
      map['numero_documento'] = Variable<String>(numeroDocumento);
    }
    if (!nullToAbsent || documentoOutrosDescricao != null) {
      map['documento_outros_descricao'] = Variable<String>(
        documentoOutrosDescricao,
      );
    }
    if (!nullToAbsent || dataNascimento != null) {
      map['data_nascimento'] = Variable<DateTime>(dataNascimento);
    }
    if (!nullToAbsent || telefone != null) {
      map['telefone'] = Variable<String>(telefone);
    }
    if (!nullToAbsent || email != null) {
      map['email'] = Variable<String>(email);
    }
    return map;
  }

  factory BpePassageiro.fromJson(
    Map<String, dynamic> json, {
    ValueSerializer? serializer,
  }) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return BpePassageiro(
      id: serializer.fromJson<int?>(json['id']),
      idBpeCabecalho: serializer.fromJson<int?>(json['idBpeCabecalho']),
      nome: serializer.fromJson<String?>(json['nome']),
      cpf: serializer.fromJson<String?>(json['cpf']),
      tipoDocumentoIdentificacao: serializer.fromJson<String?>(
        json['tipoDocumentoIdentificacao'],
      ),
      numeroDocumento: serializer.fromJson<String?>(json['numeroDocumento']),
      documentoOutrosDescricao: serializer.fromJson<String?>(
        json['documentoOutrosDescricao'],
      ),
      dataNascimento: serializer.fromJson<DateTime?>(json['dataNascimento']),
      telefone: serializer.fromJson<String?>(json['telefone']),
      email: serializer.fromJson<String?>(json['email']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'idBpeCabecalho': serializer.toJson<int?>(idBpeCabecalho),
      'nome': serializer.toJson<String?>(nome),
      'cpf': serializer.toJson<String?>(cpf),
      'tipoDocumentoIdentificacao': serializer.toJson<String?>(
        tipoDocumentoIdentificacao,
      ),
      'numeroDocumento': serializer.toJson<String?>(numeroDocumento),
      'documentoOutrosDescricao': serializer.toJson<String?>(
        documentoOutrosDescricao,
      ),
      'dataNascimento': serializer.toJson<DateTime?>(dataNascimento),
      'telefone': serializer.toJson<String?>(telefone),
      'email': serializer.toJson<String?>(email),
    };
  }

  BpePassageiro copyWith({
    Value<int?> id = const Value.absent(),
    Value<int?> idBpeCabecalho = const Value.absent(),
    Value<String?> nome = const Value.absent(),
    Value<String?> cpf = const Value.absent(),
    Value<String?> tipoDocumentoIdentificacao = const Value.absent(),
    Value<String?> numeroDocumento = const Value.absent(),
    Value<String?> documentoOutrosDescricao = const Value.absent(),
    Value<DateTime?> dataNascimento = const Value.absent(),
    Value<String?> telefone = const Value.absent(),
    Value<String?> email = const Value.absent(),
  }) => BpePassageiro(
    id: id.present ? id.value : this.id,
    idBpeCabecalho:
        idBpeCabecalho.present ? idBpeCabecalho.value : this.idBpeCabecalho,
    nome: nome.present ? nome.value : this.nome,
    cpf: cpf.present ? cpf.value : this.cpf,
    tipoDocumentoIdentificacao:
        tipoDocumentoIdentificacao.present
            ? tipoDocumentoIdentificacao.value
            : this.tipoDocumentoIdentificacao,
    numeroDocumento:
        numeroDocumento.present ? numeroDocumento.value : this.numeroDocumento,
    documentoOutrosDescricao:
        documentoOutrosDescricao.present
            ? documentoOutrosDescricao.value
            : this.documentoOutrosDescricao,
    dataNascimento:
        dataNascimento.present ? dataNascimento.value : this.dataNascimento,
    telefone: telefone.present ? telefone.value : this.telefone,
    email: email.present ? email.value : this.email,
  );
  BpePassageiro copyWithCompanion(BpePassageirosCompanion data) {
    return BpePassageiro(
      id: data.id.present ? data.id.value : this.id,
      idBpeCabecalho:
          data.idBpeCabecalho.present
              ? data.idBpeCabecalho.value
              : this.idBpeCabecalho,
      nome: data.nome.present ? data.nome.value : this.nome,
      cpf: data.cpf.present ? data.cpf.value : this.cpf,
      tipoDocumentoIdentificacao:
          data.tipoDocumentoIdentificacao.present
              ? data.tipoDocumentoIdentificacao.value
              : this.tipoDocumentoIdentificacao,
      numeroDocumento:
          data.numeroDocumento.present
              ? data.numeroDocumento.value
              : this.numeroDocumento,
      documentoOutrosDescricao:
          data.documentoOutrosDescricao.present
              ? data.documentoOutrosDescricao.value
              : this.documentoOutrosDescricao,
      dataNascimento:
          data.dataNascimento.present
              ? data.dataNascimento.value
              : this.dataNascimento,
      telefone: data.telefone.present ? data.telefone.value : this.telefone,
      email: data.email.present ? data.email.value : this.email,
    );
  }

  @override
  String toString() {
    return (StringBuffer('BpePassageiro(')
          ..write('id: $id, ')
          ..write('idBpeCabecalho: $idBpeCabecalho, ')
          ..write('nome: $nome, ')
          ..write('cpf: $cpf, ')
          ..write('tipoDocumentoIdentificacao: $tipoDocumentoIdentificacao, ')
          ..write('numeroDocumento: $numeroDocumento, ')
          ..write('documentoOutrosDescricao: $documentoOutrosDescricao, ')
          ..write('dataNascimento: $dataNascimento, ')
          ..write('telefone: $telefone, ')
          ..write('email: $email')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(
    id,
    idBpeCabecalho,
    nome,
    cpf,
    tipoDocumentoIdentificacao,
    numeroDocumento,
    documentoOutrosDescricao,
    dataNascimento,
    telefone,
    email,
  );
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is BpePassageiro &&
          other.id == this.id &&
          other.idBpeCabecalho == this.idBpeCabecalho &&
          other.nome == this.nome &&
          other.cpf == this.cpf &&
          other.tipoDocumentoIdentificacao == this.tipoDocumentoIdentificacao &&
          other.numeroDocumento == this.numeroDocumento &&
          other.documentoOutrosDescricao == this.documentoOutrosDescricao &&
          other.dataNascimento == this.dataNascimento &&
          other.telefone == this.telefone &&
          other.email == this.email);
}

class BpePassageirosCompanion extends UpdateCompanion<BpePassageiro> {
  final Value<int?> id;
  final Value<int?> idBpeCabecalho;
  final Value<String?> nome;
  final Value<String?> cpf;
  final Value<String?> tipoDocumentoIdentificacao;
  final Value<String?> numeroDocumento;
  final Value<String?> documentoOutrosDescricao;
  final Value<DateTime?> dataNascimento;
  final Value<String?> telefone;
  final Value<String?> email;
  const BpePassageirosCompanion({
    this.id = const Value.absent(),
    this.idBpeCabecalho = const Value.absent(),
    this.nome = const Value.absent(),
    this.cpf = const Value.absent(),
    this.tipoDocumentoIdentificacao = const Value.absent(),
    this.numeroDocumento = const Value.absent(),
    this.documentoOutrosDescricao = const Value.absent(),
    this.dataNascimento = const Value.absent(),
    this.telefone = const Value.absent(),
    this.email = const Value.absent(),
  });
  BpePassageirosCompanion.insert({
    this.id = const Value.absent(),
    this.idBpeCabecalho = const Value.absent(),
    this.nome = const Value.absent(),
    this.cpf = const Value.absent(),
    this.tipoDocumentoIdentificacao = const Value.absent(),
    this.numeroDocumento = const Value.absent(),
    this.documentoOutrosDescricao = const Value.absent(),
    this.dataNascimento = const Value.absent(),
    this.telefone = const Value.absent(),
    this.email = const Value.absent(),
  });
  static Insertable<BpePassageiro> custom({
    Expression<int>? id,
    Expression<int>? idBpeCabecalho,
    Expression<String>? nome,
    Expression<String>? cpf,
    Expression<String>? tipoDocumentoIdentificacao,
    Expression<String>? numeroDocumento,
    Expression<String>? documentoOutrosDescricao,
    Expression<DateTime>? dataNascimento,
    Expression<String>? telefone,
    Expression<String>? email,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (idBpeCabecalho != null) 'id_bpe_cabecalho': idBpeCabecalho,
      if (nome != null) 'nome': nome,
      if (cpf != null) 'cpf': cpf,
      if (tipoDocumentoIdentificacao != null)
        'tipo_documento_identificacao': tipoDocumentoIdentificacao,
      if (numeroDocumento != null) 'numero_documento': numeroDocumento,
      if (documentoOutrosDescricao != null)
        'documento_outros_descricao': documentoOutrosDescricao,
      if (dataNascimento != null) 'data_nascimento': dataNascimento,
      if (telefone != null) 'telefone': telefone,
      if (email != null) 'email': email,
    });
  }

  BpePassageirosCompanion copyWith({
    Value<int?>? id,
    Value<int?>? idBpeCabecalho,
    Value<String?>? nome,
    Value<String?>? cpf,
    Value<String?>? tipoDocumentoIdentificacao,
    Value<String?>? numeroDocumento,
    Value<String?>? documentoOutrosDescricao,
    Value<DateTime?>? dataNascimento,
    Value<String?>? telefone,
    Value<String?>? email,
  }) {
    return BpePassageirosCompanion(
      id: id ?? this.id,
      idBpeCabecalho: idBpeCabecalho ?? this.idBpeCabecalho,
      nome: nome ?? this.nome,
      cpf: cpf ?? this.cpf,
      tipoDocumentoIdentificacao:
          tipoDocumentoIdentificacao ?? this.tipoDocumentoIdentificacao,
      numeroDocumento: numeroDocumento ?? this.numeroDocumento,
      documentoOutrosDescricao:
          documentoOutrosDescricao ?? this.documentoOutrosDescricao,
      dataNascimento: dataNascimento ?? this.dataNascimento,
      telefone: telefone ?? this.telefone,
      email: email ?? this.email,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (idBpeCabecalho.present) {
      map['id_bpe_cabecalho'] = Variable<int>(idBpeCabecalho.value);
    }
    if (nome.present) {
      map['nome'] = Variable<String>(nome.value);
    }
    if (cpf.present) {
      map['cpf'] = Variable<String>(cpf.value);
    }
    if (tipoDocumentoIdentificacao.present) {
      map['tipo_documento_identificacao'] = Variable<String>(
        tipoDocumentoIdentificacao.value,
      );
    }
    if (numeroDocumento.present) {
      map['numero_documento'] = Variable<String>(numeroDocumento.value);
    }
    if (documentoOutrosDescricao.present) {
      map['documento_outros_descricao'] = Variable<String>(
        documentoOutrosDescricao.value,
      );
    }
    if (dataNascimento.present) {
      map['data_nascimento'] = Variable<DateTime>(dataNascimento.value);
    }
    if (telefone.present) {
      map['telefone'] = Variable<String>(telefone.value);
    }
    if (email.present) {
      map['email'] = Variable<String>(email.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('BpePassageirosCompanion(')
          ..write('id: $id, ')
          ..write('idBpeCabecalho: $idBpeCabecalho, ')
          ..write('nome: $nome, ')
          ..write('cpf: $cpf, ')
          ..write('tipoDocumentoIdentificacao: $tipoDocumentoIdentificacao, ')
          ..write('numeroDocumento: $numeroDocumento, ')
          ..write('documentoOutrosDescricao: $documentoOutrosDescricao, ')
          ..write('dataNascimento: $dataNascimento, ')
          ..write('telefone: $telefone, ')
          ..write('email: $email')
          ..write(')'))
        .toString();
  }
}

class $BpeCompradorsTable extends BpeCompradors
    with TableInfo<$BpeCompradorsTable, BpeComprador> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $BpeCompradorsTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
    'id',
    aliasedName,
    true,
    type: DriftSqlType.int,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _idBpeCabecalhoMeta = const VerificationMeta(
    'idBpeCabecalho',
  );
  @override
  late final GeneratedColumn<int> idBpeCabecalho = GeneratedColumn<int>(
    'id_bpe_cabecalho',
    aliasedName,
    true,
    type: DriftSqlType.int,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _cnpjMeta = const VerificationMeta('cnpj');
  @override
  late final GeneratedColumn<String> cnpj = GeneratedColumn<String>(
    'cnpj',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 14,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _cpfMeta = const VerificationMeta('cpf');
  @override
  late final GeneratedColumn<String> cpf = GeneratedColumn<String>(
    'cpf',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 11,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _ieMeta = const VerificationMeta('ie');
  @override
  late final GeneratedColumn<String> ie = GeneratedColumn<String>(
    'ie',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 20,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _nomeMeta = const VerificationMeta('nome');
  @override
  late final GeneratedColumn<String> nome = GeneratedColumn<String>(
    'nome',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 60,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _fantasiaMeta = const VerificationMeta(
    'fantasia',
  );
  @override
  late final GeneratedColumn<String> fantasia = GeneratedColumn<String>(
    'fantasia',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 60,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _telefoneMeta = const VerificationMeta(
    'telefone',
  );
  @override
  late final GeneratedColumn<String> telefone = GeneratedColumn<String>(
    'telefone',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 14,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _logradouroMeta = const VerificationMeta(
    'logradouro',
  );
  @override
  late final GeneratedColumn<String> logradouro = GeneratedColumn<String>(
    'logradouro',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 250,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _numeroMeta = const VerificationMeta('numero');
  @override
  late final GeneratedColumn<String> numero = GeneratedColumn<String>(
    'numero',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 60,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _complementoMeta = const VerificationMeta(
    'complemento',
  );
  @override
  late final GeneratedColumn<String> complemento = GeneratedColumn<String>(
    'complemento',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 60,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _bairroMeta = const VerificationMeta('bairro');
  @override
  late final GeneratedColumn<String> bairro = GeneratedColumn<String>(
    'bairro',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 60,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _codigoMunicipioMeta = const VerificationMeta(
    'codigoMunicipio',
  );
  @override
  late final GeneratedColumn<int> codigoMunicipio = GeneratedColumn<int>(
    'codigo_municipio',
    aliasedName,
    true,
    type: DriftSqlType.int,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _nomeMunicipioMeta = const VerificationMeta(
    'nomeMunicipio',
  );
  @override
  late final GeneratedColumn<String> nomeMunicipio = GeneratedColumn<String>(
    'nome_municipio',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 60,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _ufMeta = const VerificationMeta('uf');
  @override
  late final GeneratedColumn<String> uf = GeneratedColumn<String>(
    'uf',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 2,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _cepMeta = const VerificationMeta('cep');
  @override
  late final GeneratedColumn<String> cep = GeneratedColumn<String>(
    'cep',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 8,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _codigoPaisMeta = const VerificationMeta(
    'codigoPais',
  );
  @override
  late final GeneratedColumn<int> codigoPais = GeneratedColumn<int>(
    'codigo_pais',
    aliasedName,
    true,
    type: DriftSqlType.int,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _nomePaisMeta = const VerificationMeta(
    'nomePais',
  );
  @override
  late final GeneratedColumn<String> nomePais = GeneratedColumn<String>(
    'nome_pais',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 60,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _emailMeta = const VerificationMeta('email');
  @override
  late final GeneratedColumn<String> email = GeneratedColumn<String>(
    'email',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 60,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  @override
  List<GeneratedColumn> get $columns => [
    id,
    idBpeCabecalho,
    cnpj,
    cpf,
    ie,
    nome,
    fantasia,
    telefone,
    logradouro,
    numero,
    complemento,
    bairro,
    codigoMunicipio,
    nomeMunicipio,
    uf,
    cep,
    codigoPais,
    nomePais,
    email,
  ];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'bpe_comprador';
  @override
  VerificationContext validateIntegrity(
    Insertable<BpeComprador> instance, {
    bool isInserting = false,
  }) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('id_bpe_cabecalho')) {
      context.handle(
        _idBpeCabecalhoMeta,
        idBpeCabecalho.isAcceptableOrUnknown(
          data['id_bpe_cabecalho']!,
          _idBpeCabecalhoMeta,
        ),
      );
    }
    if (data.containsKey('cnpj')) {
      context.handle(
        _cnpjMeta,
        cnpj.isAcceptableOrUnknown(data['cnpj']!, _cnpjMeta),
      );
    }
    if (data.containsKey('cpf')) {
      context.handle(
        _cpfMeta,
        cpf.isAcceptableOrUnknown(data['cpf']!, _cpfMeta),
      );
    }
    if (data.containsKey('ie')) {
      context.handle(_ieMeta, ie.isAcceptableOrUnknown(data['ie']!, _ieMeta));
    }
    if (data.containsKey('nome')) {
      context.handle(
        _nomeMeta,
        nome.isAcceptableOrUnknown(data['nome']!, _nomeMeta),
      );
    }
    if (data.containsKey('fantasia')) {
      context.handle(
        _fantasiaMeta,
        fantasia.isAcceptableOrUnknown(data['fantasia']!, _fantasiaMeta),
      );
    }
    if (data.containsKey('telefone')) {
      context.handle(
        _telefoneMeta,
        telefone.isAcceptableOrUnknown(data['telefone']!, _telefoneMeta),
      );
    }
    if (data.containsKey('logradouro')) {
      context.handle(
        _logradouroMeta,
        logradouro.isAcceptableOrUnknown(data['logradouro']!, _logradouroMeta),
      );
    }
    if (data.containsKey('numero')) {
      context.handle(
        _numeroMeta,
        numero.isAcceptableOrUnknown(data['numero']!, _numeroMeta),
      );
    }
    if (data.containsKey('complemento')) {
      context.handle(
        _complementoMeta,
        complemento.isAcceptableOrUnknown(
          data['complemento']!,
          _complementoMeta,
        ),
      );
    }
    if (data.containsKey('bairro')) {
      context.handle(
        _bairroMeta,
        bairro.isAcceptableOrUnknown(data['bairro']!, _bairroMeta),
      );
    }
    if (data.containsKey('codigo_municipio')) {
      context.handle(
        _codigoMunicipioMeta,
        codigoMunicipio.isAcceptableOrUnknown(
          data['codigo_municipio']!,
          _codigoMunicipioMeta,
        ),
      );
    }
    if (data.containsKey('nome_municipio')) {
      context.handle(
        _nomeMunicipioMeta,
        nomeMunicipio.isAcceptableOrUnknown(
          data['nome_municipio']!,
          _nomeMunicipioMeta,
        ),
      );
    }
    if (data.containsKey('uf')) {
      context.handle(_ufMeta, uf.isAcceptableOrUnknown(data['uf']!, _ufMeta));
    }
    if (data.containsKey('cep')) {
      context.handle(
        _cepMeta,
        cep.isAcceptableOrUnknown(data['cep']!, _cepMeta),
      );
    }
    if (data.containsKey('codigo_pais')) {
      context.handle(
        _codigoPaisMeta,
        codigoPais.isAcceptableOrUnknown(data['codigo_pais']!, _codigoPaisMeta),
      );
    }
    if (data.containsKey('nome_pais')) {
      context.handle(
        _nomePaisMeta,
        nomePais.isAcceptableOrUnknown(data['nome_pais']!, _nomePaisMeta),
      );
    }
    if (data.containsKey('email')) {
      context.handle(
        _emailMeta,
        email.isAcceptableOrUnknown(data['email']!, _emailMeta),
      );
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  BpeComprador map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return BpeComprador(
      id: attachedDatabase.typeMapping.read(
        DriftSqlType.int,
        data['${effectivePrefix}id'],
      ),
      idBpeCabecalho: attachedDatabase.typeMapping.read(
        DriftSqlType.int,
        data['${effectivePrefix}id_bpe_cabecalho'],
      ),
      cnpj: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}cnpj'],
      ),
      cpf: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}cpf'],
      ),
      ie: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}ie'],
      ),
      nome: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}nome'],
      ),
      fantasia: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}fantasia'],
      ),
      telefone: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}telefone'],
      ),
      logradouro: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}logradouro'],
      ),
      numero: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}numero'],
      ),
      complemento: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}complemento'],
      ),
      bairro: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}bairro'],
      ),
      codigoMunicipio: attachedDatabase.typeMapping.read(
        DriftSqlType.int,
        data['${effectivePrefix}codigo_municipio'],
      ),
      nomeMunicipio: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}nome_municipio'],
      ),
      uf: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}uf'],
      ),
      cep: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}cep'],
      ),
      codigoPais: attachedDatabase.typeMapping.read(
        DriftSqlType.int,
        data['${effectivePrefix}codigo_pais'],
      ),
      nomePais: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}nome_pais'],
      ),
      email: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}email'],
      ),
    );
  }

  @override
  $BpeCompradorsTable createAlias(String alias) {
    return $BpeCompradorsTable(attachedDatabase, alias);
  }
}

class BpeComprador extends DataClass implements Insertable<BpeComprador> {
  final int? id;
  final int? idBpeCabecalho;
  final String? cnpj;
  final String? cpf;
  final String? ie;
  final String? nome;
  final String? fantasia;
  final String? telefone;
  final String? logradouro;
  final String? numero;
  final String? complemento;
  final String? bairro;
  final int? codigoMunicipio;
  final String? nomeMunicipio;
  final String? uf;
  final String? cep;
  final int? codigoPais;
  final String? nomePais;
  final String? email;
  const BpeComprador({
    this.id,
    this.idBpeCabecalho,
    this.cnpj,
    this.cpf,
    this.ie,
    this.nome,
    this.fantasia,
    this.telefone,
    this.logradouro,
    this.numero,
    this.complemento,
    this.bairro,
    this.codigoMunicipio,
    this.nomeMunicipio,
    this.uf,
    this.cep,
    this.codigoPais,
    this.nomePais,
    this.email,
  });
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || idBpeCabecalho != null) {
      map['id_bpe_cabecalho'] = Variable<int>(idBpeCabecalho);
    }
    if (!nullToAbsent || cnpj != null) {
      map['cnpj'] = Variable<String>(cnpj);
    }
    if (!nullToAbsent || cpf != null) {
      map['cpf'] = Variable<String>(cpf);
    }
    if (!nullToAbsent || ie != null) {
      map['ie'] = Variable<String>(ie);
    }
    if (!nullToAbsent || nome != null) {
      map['nome'] = Variable<String>(nome);
    }
    if (!nullToAbsent || fantasia != null) {
      map['fantasia'] = Variable<String>(fantasia);
    }
    if (!nullToAbsent || telefone != null) {
      map['telefone'] = Variable<String>(telefone);
    }
    if (!nullToAbsent || logradouro != null) {
      map['logradouro'] = Variable<String>(logradouro);
    }
    if (!nullToAbsent || numero != null) {
      map['numero'] = Variable<String>(numero);
    }
    if (!nullToAbsent || complemento != null) {
      map['complemento'] = Variable<String>(complemento);
    }
    if (!nullToAbsent || bairro != null) {
      map['bairro'] = Variable<String>(bairro);
    }
    if (!nullToAbsent || codigoMunicipio != null) {
      map['codigo_municipio'] = Variable<int>(codigoMunicipio);
    }
    if (!nullToAbsent || nomeMunicipio != null) {
      map['nome_municipio'] = Variable<String>(nomeMunicipio);
    }
    if (!nullToAbsent || uf != null) {
      map['uf'] = Variable<String>(uf);
    }
    if (!nullToAbsent || cep != null) {
      map['cep'] = Variable<String>(cep);
    }
    if (!nullToAbsent || codigoPais != null) {
      map['codigo_pais'] = Variable<int>(codigoPais);
    }
    if (!nullToAbsent || nomePais != null) {
      map['nome_pais'] = Variable<String>(nomePais);
    }
    if (!nullToAbsent || email != null) {
      map['email'] = Variable<String>(email);
    }
    return map;
  }

  factory BpeComprador.fromJson(
    Map<String, dynamic> json, {
    ValueSerializer? serializer,
  }) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return BpeComprador(
      id: serializer.fromJson<int?>(json['id']),
      idBpeCabecalho: serializer.fromJson<int?>(json['idBpeCabecalho']),
      cnpj: serializer.fromJson<String?>(json['cnpj']),
      cpf: serializer.fromJson<String?>(json['cpf']),
      ie: serializer.fromJson<String?>(json['ie']),
      nome: serializer.fromJson<String?>(json['nome']),
      fantasia: serializer.fromJson<String?>(json['fantasia']),
      telefone: serializer.fromJson<String?>(json['telefone']),
      logradouro: serializer.fromJson<String?>(json['logradouro']),
      numero: serializer.fromJson<String?>(json['numero']),
      complemento: serializer.fromJson<String?>(json['complemento']),
      bairro: serializer.fromJson<String?>(json['bairro']),
      codigoMunicipio: serializer.fromJson<int?>(json['codigoMunicipio']),
      nomeMunicipio: serializer.fromJson<String?>(json['nomeMunicipio']),
      uf: serializer.fromJson<String?>(json['uf']),
      cep: serializer.fromJson<String?>(json['cep']),
      codigoPais: serializer.fromJson<int?>(json['codigoPais']),
      nomePais: serializer.fromJson<String?>(json['nomePais']),
      email: serializer.fromJson<String?>(json['email']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'idBpeCabecalho': serializer.toJson<int?>(idBpeCabecalho),
      'cnpj': serializer.toJson<String?>(cnpj),
      'cpf': serializer.toJson<String?>(cpf),
      'ie': serializer.toJson<String?>(ie),
      'nome': serializer.toJson<String?>(nome),
      'fantasia': serializer.toJson<String?>(fantasia),
      'telefone': serializer.toJson<String?>(telefone),
      'logradouro': serializer.toJson<String?>(logradouro),
      'numero': serializer.toJson<String?>(numero),
      'complemento': serializer.toJson<String?>(complemento),
      'bairro': serializer.toJson<String?>(bairro),
      'codigoMunicipio': serializer.toJson<int?>(codigoMunicipio),
      'nomeMunicipio': serializer.toJson<String?>(nomeMunicipio),
      'uf': serializer.toJson<String?>(uf),
      'cep': serializer.toJson<String?>(cep),
      'codigoPais': serializer.toJson<int?>(codigoPais),
      'nomePais': serializer.toJson<String?>(nomePais),
      'email': serializer.toJson<String?>(email),
    };
  }

  BpeComprador copyWith({
    Value<int?> id = const Value.absent(),
    Value<int?> idBpeCabecalho = const Value.absent(),
    Value<String?> cnpj = const Value.absent(),
    Value<String?> cpf = const Value.absent(),
    Value<String?> ie = const Value.absent(),
    Value<String?> nome = const Value.absent(),
    Value<String?> fantasia = const Value.absent(),
    Value<String?> telefone = const Value.absent(),
    Value<String?> logradouro = const Value.absent(),
    Value<String?> numero = const Value.absent(),
    Value<String?> complemento = const Value.absent(),
    Value<String?> bairro = const Value.absent(),
    Value<int?> codigoMunicipio = const Value.absent(),
    Value<String?> nomeMunicipio = const Value.absent(),
    Value<String?> uf = const Value.absent(),
    Value<String?> cep = const Value.absent(),
    Value<int?> codigoPais = const Value.absent(),
    Value<String?> nomePais = const Value.absent(),
    Value<String?> email = const Value.absent(),
  }) => BpeComprador(
    id: id.present ? id.value : this.id,
    idBpeCabecalho:
        idBpeCabecalho.present ? idBpeCabecalho.value : this.idBpeCabecalho,
    cnpj: cnpj.present ? cnpj.value : this.cnpj,
    cpf: cpf.present ? cpf.value : this.cpf,
    ie: ie.present ? ie.value : this.ie,
    nome: nome.present ? nome.value : this.nome,
    fantasia: fantasia.present ? fantasia.value : this.fantasia,
    telefone: telefone.present ? telefone.value : this.telefone,
    logradouro: logradouro.present ? logradouro.value : this.logradouro,
    numero: numero.present ? numero.value : this.numero,
    complemento: complemento.present ? complemento.value : this.complemento,
    bairro: bairro.present ? bairro.value : this.bairro,
    codigoMunicipio:
        codigoMunicipio.present ? codigoMunicipio.value : this.codigoMunicipio,
    nomeMunicipio:
        nomeMunicipio.present ? nomeMunicipio.value : this.nomeMunicipio,
    uf: uf.present ? uf.value : this.uf,
    cep: cep.present ? cep.value : this.cep,
    codigoPais: codigoPais.present ? codigoPais.value : this.codigoPais,
    nomePais: nomePais.present ? nomePais.value : this.nomePais,
    email: email.present ? email.value : this.email,
  );
  BpeComprador copyWithCompanion(BpeCompradorsCompanion data) {
    return BpeComprador(
      id: data.id.present ? data.id.value : this.id,
      idBpeCabecalho:
          data.idBpeCabecalho.present
              ? data.idBpeCabecalho.value
              : this.idBpeCabecalho,
      cnpj: data.cnpj.present ? data.cnpj.value : this.cnpj,
      cpf: data.cpf.present ? data.cpf.value : this.cpf,
      ie: data.ie.present ? data.ie.value : this.ie,
      nome: data.nome.present ? data.nome.value : this.nome,
      fantasia: data.fantasia.present ? data.fantasia.value : this.fantasia,
      telefone: data.telefone.present ? data.telefone.value : this.telefone,
      logradouro:
          data.logradouro.present ? data.logradouro.value : this.logradouro,
      numero: data.numero.present ? data.numero.value : this.numero,
      complemento:
          data.complemento.present ? data.complemento.value : this.complemento,
      bairro: data.bairro.present ? data.bairro.value : this.bairro,
      codigoMunicipio:
          data.codigoMunicipio.present
              ? data.codigoMunicipio.value
              : this.codigoMunicipio,
      nomeMunicipio:
          data.nomeMunicipio.present
              ? data.nomeMunicipio.value
              : this.nomeMunicipio,
      uf: data.uf.present ? data.uf.value : this.uf,
      cep: data.cep.present ? data.cep.value : this.cep,
      codigoPais:
          data.codigoPais.present ? data.codigoPais.value : this.codigoPais,
      nomePais: data.nomePais.present ? data.nomePais.value : this.nomePais,
      email: data.email.present ? data.email.value : this.email,
    );
  }

  @override
  String toString() {
    return (StringBuffer('BpeComprador(')
          ..write('id: $id, ')
          ..write('idBpeCabecalho: $idBpeCabecalho, ')
          ..write('cnpj: $cnpj, ')
          ..write('cpf: $cpf, ')
          ..write('ie: $ie, ')
          ..write('nome: $nome, ')
          ..write('fantasia: $fantasia, ')
          ..write('telefone: $telefone, ')
          ..write('logradouro: $logradouro, ')
          ..write('numero: $numero, ')
          ..write('complemento: $complemento, ')
          ..write('bairro: $bairro, ')
          ..write('codigoMunicipio: $codigoMunicipio, ')
          ..write('nomeMunicipio: $nomeMunicipio, ')
          ..write('uf: $uf, ')
          ..write('cep: $cep, ')
          ..write('codigoPais: $codigoPais, ')
          ..write('nomePais: $nomePais, ')
          ..write('email: $email')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(
    id,
    idBpeCabecalho,
    cnpj,
    cpf,
    ie,
    nome,
    fantasia,
    telefone,
    logradouro,
    numero,
    complemento,
    bairro,
    codigoMunicipio,
    nomeMunicipio,
    uf,
    cep,
    codigoPais,
    nomePais,
    email,
  );
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is BpeComprador &&
          other.id == this.id &&
          other.idBpeCabecalho == this.idBpeCabecalho &&
          other.cnpj == this.cnpj &&
          other.cpf == this.cpf &&
          other.ie == this.ie &&
          other.nome == this.nome &&
          other.fantasia == this.fantasia &&
          other.telefone == this.telefone &&
          other.logradouro == this.logradouro &&
          other.numero == this.numero &&
          other.complemento == this.complemento &&
          other.bairro == this.bairro &&
          other.codigoMunicipio == this.codigoMunicipio &&
          other.nomeMunicipio == this.nomeMunicipio &&
          other.uf == this.uf &&
          other.cep == this.cep &&
          other.codigoPais == this.codigoPais &&
          other.nomePais == this.nomePais &&
          other.email == this.email);
}

class BpeCompradorsCompanion extends UpdateCompanion<BpeComprador> {
  final Value<int?> id;
  final Value<int?> idBpeCabecalho;
  final Value<String?> cnpj;
  final Value<String?> cpf;
  final Value<String?> ie;
  final Value<String?> nome;
  final Value<String?> fantasia;
  final Value<String?> telefone;
  final Value<String?> logradouro;
  final Value<String?> numero;
  final Value<String?> complemento;
  final Value<String?> bairro;
  final Value<int?> codigoMunicipio;
  final Value<String?> nomeMunicipio;
  final Value<String?> uf;
  final Value<String?> cep;
  final Value<int?> codigoPais;
  final Value<String?> nomePais;
  final Value<String?> email;
  const BpeCompradorsCompanion({
    this.id = const Value.absent(),
    this.idBpeCabecalho = const Value.absent(),
    this.cnpj = const Value.absent(),
    this.cpf = const Value.absent(),
    this.ie = const Value.absent(),
    this.nome = const Value.absent(),
    this.fantasia = const Value.absent(),
    this.telefone = const Value.absent(),
    this.logradouro = const Value.absent(),
    this.numero = const Value.absent(),
    this.complemento = const Value.absent(),
    this.bairro = const Value.absent(),
    this.codigoMunicipio = const Value.absent(),
    this.nomeMunicipio = const Value.absent(),
    this.uf = const Value.absent(),
    this.cep = const Value.absent(),
    this.codigoPais = const Value.absent(),
    this.nomePais = const Value.absent(),
    this.email = const Value.absent(),
  });
  BpeCompradorsCompanion.insert({
    this.id = const Value.absent(),
    this.idBpeCabecalho = const Value.absent(),
    this.cnpj = const Value.absent(),
    this.cpf = const Value.absent(),
    this.ie = const Value.absent(),
    this.nome = const Value.absent(),
    this.fantasia = const Value.absent(),
    this.telefone = const Value.absent(),
    this.logradouro = const Value.absent(),
    this.numero = const Value.absent(),
    this.complemento = const Value.absent(),
    this.bairro = const Value.absent(),
    this.codigoMunicipio = const Value.absent(),
    this.nomeMunicipio = const Value.absent(),
    this.uf = const Value.absent(),
    this.cep = const Value.absent(),
    this.codigoPais = const Value.absent(),
    this.nomePais = const Value.absent(),
    this.email = const Value.absent(),
  });
  static Insertable<BpeComprador> custom({
    Expression<int>? id,
    Expression<int>? idBpeCabecalho,
    Expression<String>? cnpj,
    Expression<String>? cpf,
    Expression<String>? ie,
    Expression<String>? nome,
    Expression<String>? fantasia,
    Expression<String>? telefone,
    Expression<String>? logradouro,
    Expression<String>? numero,
    Expression<String>? complemento,
    Expression<String>? bairro,
    Expression<int>? codigoMunicipio,
    Expression<String>? nomeMunicipio,
    Expression<String>? uf,
    Expression<String>? cep,
    Expression<int>? codigoPais,
    Expression<String>? nomePais,
    Expression<String>? email,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (idBpeCabecalho != null) 'id_bpe_cabecalho': idBpeCabecalho,
      if (cnpj != null) 'cnpj': cnpj,
      if (cpf != null) 'cpf': cpf,
      if (ie != null) 'ie': ie,
      if (nome != null) 'nome': nome,
      if (fantasia != null) 'fantasia': fantasia,
      if (telefone != null) 'telefone': telefone,
      if (logradouro != null) 'logradouro': logradouro,
      if (numero != null) 'numero': numero,
      if (complemento != null) 'complemento': complemento,
      if (bairro != null) 'bairro': bairro,
      if (codigoMunicipio != null) 'codigo_municipio': codigoMunicipio,
      if (nomeMunicipio != null) 'nome_municipio': nomeMunicipio,
      if (uf != null) 'uf': uf,
      if (cep != null) 'cep': cep,
      if (codigoPais != null) 'codigo_pais': codigoPais,
      if (nomePais != null) 'nome_pais': nomePais,
      if (email != null) 'email': email,
    });
  }

  BpeCompradorsCompanion copyWith({
    Value<int?>? id,
    Value<int?>? idBpeCabecalho,
    Value<String?>? cnpj,
    Value<String?>? cpf,
    Value<String?>? ie,
    Value<String?>? nome,
    Value<String?>? fantasia,
    Value<String?>? telefone,
    Value<String?>? logradouro,
    Value<String?>? numero,
    Value<String?>? complemento,
    Value<String?>? bairro,
    Value<int?>? codigoMunicipio,
    Value<String?>? nomeMunicipio,
    Value<String?>? uf,
    Value<String?>? cep,
    Value<int?>? codigoPais,
    Value<String?>? nomePais,
    Value<String?>? email,
  }) {
    return BpeCompradorsCompanion(
      id: id ?? this.id,
      idBpeCabecalho: idBpeCabecalho ?? this.idBpeCabecalho,
      cnpj: cnpj ?? this.cnpj,
      cpf: cpf ?? this.cpf,
      ie: ie ?? this.ie,
      nome: nome ?? this.nome,
      fantasia: fantasia ?? this.fantasia,
      telefone: telefone ?? this.telefone,
      logradouro: logradouro ?? this.logradouro,
      numero: numero ?? this.numero,
      complemento: complemento ?? this.complemento,
      bairro: bairro ?? this.bairro,
      codigoMunicipio: codigoMunicipio ?? this.codigoMunicipio,
      nomeMunicipio: nomeMunicipio ?? this.nomeMunicipio,
      uf: uf ?? this.uf,
      cep: cep ?? this.cep,
      codigoPais: codigoPais ?? this.codigoPais,
      nomePais: nomePais ?? this.nomePais,
      email: email ?? this.email,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (idBpeCabecalho.present) {
      map['id_bpe_cabecalho'] = Variable<int>(idBpeCabecalho.value);
    }
    if (cnpj.present) {
      map['cnpj'] = Variable<String>(cnpj.value);
    }
    if (cpf.present) {
      map['cpf'] = Variable<String>(cpf.value);
    }
    if (ie.present) {
      map['ie'] = Variable<String>(ie.value);
    }
    if (nome.present) {
      map['nome'] = Variable<String>(nome.value);
    }
    if (fantasia.present) {
      map['fantasia'] = Variable<String>(fantasia.value);
    }
    if (telefone.present) {
      map['telefone'] = Variable<String>(telefone.value);
    }
    if (logradouro.present) {
      map['logradouro'] = Variable<String>(logradouro.value);
    }
    if (numero.present) {
      map['numero'] = Variable<String>(numero.value);
    }
    if (complemento.present) {
      map['complemento'] = Variable<String>(complemento.value);
    }
    if (bairro.present) {
      map['bairro'] = Variable<String>(bairro.value);
    }
    if (codigoMunicipio.present) {
      map['codigo_municipio'] = Variable<int>(codigoMunicipio.value);
    }
    if (nomeMunicipio.present) {
      map['nome_municipio'] = Variable<String>(nomeMunicipio.value);
    }
    if (uf.present) {
      map['uf'] = Variable<String>(uf.value);
    }
    if (cep.present) {
      map['cep'] = Variable<String>(cep.value);
    }
    if (codigoPais.present) {
      map['codigo_pais'] = Variable<int>(codigoPais.value);
    }
    if (nomePais.present) {
      map['nome_pais'] = Variable<String>(nomePais.value);
    }
    if (email.present) {
      map['email'] = Variable<String>(email.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('BpeCompradorsCompanion(')
          ..write('id: $id, ')
          ..write('idBpeCabecalho: $idBpeCabecalho, ')
          ..write('cnpj: $cnpj, ')
          ..write('cpf: $cpf, ')
          ..write('ie: $ie, ')
          ..write('nome: $nome, ')
          ..write('fantasia: $fantasia, ')
          ..write('telefone: $telefone, ')
          ..write('logradouro: $logradouro, ')
          ..write('numero: $numero, ')
          ..write('complemento: $complemento, ')
          ..write('bairro: $bairro, ')
          ..write('codigoMunicipio: $codigoMunicipio, ')
          ..write('nomeMunicipio: $nomeMunicipio, ')
          ..write('uf: $uf, ')
          ..write('cep: $cep, ')
          ..write('codigoPais: $codigoPais, ')
          ..write('nomePais: $nomePais, ')
          ..write('email: $email')
          ..write(')'))
        .toString();
  }
}

class $BpeViagemsTable extends BpeViagems
    with TableInfo<$BpeViagemsTable, BpeViagem> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $BpeViagemsTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
    'id',
    aliasedName,
    true,
    type: DriftSqlType.int,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _idBpeCabecalhoMeta = const VerificationMeta(
    'idBpeCabecalho',
  );
  @override
  late final GeneratedColumn<int> idBpeCabecalho = GeneratedColumn<int>(
    'id_bpe_cabecalho',
    aliasedName,
    true,
    type: DriftSqlType.int,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _codigoPercursoMeta = const VerificationMeta(
    'codigoPercurso',
  );
  @override
  late final GeneratedColumn<String> codigoPercurso = GeneratedColumn<String>(
    'codigo_percurso',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 20,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _descricaoPercursoMeta = const VerificationMeta(
    'descricaoPercurso',
  );
  @override
  late final GeneratedColumn<String> descricaoPercurso =
      GeneratedColumn<String>(
        'descricao_percurso',
        aliasedName,
        true,
        additionalChecks: GeneratedColumn.checkTextLength(
          minTextLength: 0,
          maxTextLength: 100,
        ),
        type: DriftSqlType.string,
        requiredDuringInsert: false,
      );
  static const VerificationMeta _tipoViagemMeta = const VerificationMeta(
    'tipoViagem',
  );
  @override
  late final GeneratedColumn<String> tipoViagem = GeneratedColumn<String>(
    'tipo_viagem',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 1,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _tipoServicoMeta = const VerificationMeta(
    'tipoServico',
  );
  @override
  late final GeneratedColumn<String> tipoServico = GeneratedColumn<String>(
    'tipo_servico',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 1,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _tipoAcomodacaoMeta = const VerificationMeta(
    'tipoAcomodacao',
  );
  @override
  late final GeneratedColumn<String> tipoAcomodacao = GeneratedColumn<String>(
    'tipo_acomodacao',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 1,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _tipoTrechoMeta = const VerificationMeta(
    'tipoTrecho',
  );
  @override
  late final GeneratedColumn<String> tipoTrecho = GeneratedColumn<String>(
    'tipo_trecho',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 1,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _dataHoraViagemMeta = const VerificationMeta(
    'dataHoraViagem',
  );
  @override
  late final GeneratedColumn<DateTime> dataHoraViagem =
      GeneratedColumn<DateTime>(
        'data_hora_viagem',
        aliasedName,
        true,
        type: DriftSqlType.dateTime,
        requiredDuringInsert: false,
      );
  static const VerificationMeta _dataHoraConexaoMeta = const VerificationMeta(
    'dataHoraConexao',
  );
  @override
  late final GeneratedColumn<DateTime> dataHoraConexao =
      GeneratedColumn<DateTime>(
        'data_hora_conexao',
        aliasedName,
        true,
        type: DriftSqlType.dateTime,
        requiredDuringInsert: false,
      );
  static const VerificationMeta _prefixoLinhaMeta = const VerificationMeta(
    'prefixoLinha',
  );
  @override
  late final GeneratedColumn<String> prefixoLinha = GeneratedColumn<String>(
    'prefixo_linha',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 20,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _poltronaMeta = const VerificationMeta(
    'poltrona',
  );
  @override
  late final GeneratedColumn<String> poltrona = GeneratedColumn<String>(
    'poltrona',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 3,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _plataformaMeta = const VerificationMeta(
    'plataforma',
  );
  @override
  late final GeneratedColumn<String> plataforma = GeneratedColumn<String>(
    'plataforma',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 10,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  @override
  List<GeneratedColumn> get $columns => [
    id,
    idBpeCabecalho,
    codigoPercurso,
    descricaoPercurso,
    tipoViagem,
    tipoServico,
    tipoAcomodacao,
    tipoTrecho,
    dataHoraViagem,
    dataHoraConexao,
    prefixoLinha,
    poltrona,
    plataforma,
  ];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'bpe_viagem';
  @override
  VerificationContext validateIntegrity(
    Insertable<BpeViagem> instance, {
    bool isInserting = false,
  }) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('id_bpe_cabecalho')) {
      context.handle(
        _idBpeCabecalhoMeta,
        idBpeCabecalho.isAcceptableOrUnknown(
          data['id_bpe_cabecalho']!,
          _idBpeCabecalhoMeta,
        ),
      );
    }
    if (data.containsKey('codigo_percurso')) {
      context.handle(
        _codigoPercursoMeta,
        codigoPercurso.isAcceptableOrUnknown(
          data['codigo_percurso']!,
          _codigoPercursoMeta,
        ),
      );
    }
    if (data.containsKey('descricao_percurso')) {
      context.handle(
        _descricaoPercursoMeta,
        descricaoPercurso.isAcceptableOrUnknown(
          data['descricao_percurso']!,
          _descricaoPercursoMeta,
        ),
      );
    }
    if (data.containsKey('tipo_viagem')) {
      context.handle(
        _tipoViagemMeta,
        tipoViagem.isAcceptableOrUnknown(data['tipo_viagem']!, _tipoViagemMeta),
      );
    }
    if (data.containsKey('tipo_servico')) {
      context.handle(
        _tipoServicoMeta,
        tipoServico.isAcceptableOrUnknown(
          data['tipo_servico']!,
          _tipoServicoMeta,
        ),
      );
    }
    if (data.containsKey('tipo_acomodacao')) {
      context.handle(
        _tipoAcomodacaoMeta,
        tipoAcomodacao.isAcceptableOrUnknown(
          data['tipo_acomodacao']!,
          _tipoAcomodacaoMeta,
        ),
      );
    }
    if (data.containsKey('tipo_trecho')) {
      context.handle(
        _tipoTrechoMeta,
        tipoTrecho.isAcceptableOrUnknown(data['tipo_trecho']!, _tipoTrechoMeta),
      );
    }
    if (data.containsKey('data_hora_viagem')) {
      context.handle(
        _dataHoraViagemMeta,
        dataHoraViagem.isAcceptableOrUnknown(
          data['data_hora_viagem']!,
          _dataHoraViagemMeta,
        ),
      );
    }
    if (data.containsKey('data_hora_conexao')) {
      context.handle(
        _dataHoraConexaoMeta,
        dataHoraConexao.isAcceptableOrUnknown(
          data['data_hora_conexao']!,
          _dataHoraConexaoMeta,
        ),
      );
    }
    if (data.containsKey('prefixo_linha')) {
      context.handle(
        _prefixoLinhaMeta,
        prefixoLinha.isAcceptableOrUnknown(
          data['prefixo_linha']!,
          _prefixoLinhaMeta,
        ),
      );
    }
    if (data.containsKey('poltrona')) {
      context.handle(
        _poltronaMeta,
        poltrona.isAcceptableOrUnknown(data['poltrona']!, _poltronaMeta),
      );
    }
    if (data.containsKey('plataforma')) {
      context.handle(
        _plataformaMeta,
        plataforma.isAcceptableOrUnknown(data['plataforma']!, _plataformaMeta),
      );
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  BpeViagem map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return BpeViagem(
      id: attachedDatabase.typeMapping.read(
        DriftSqlType.int,
        data['${effectivePrefix}id'],
      ),
      idBpeCabecalho: attachedDatabase.typeMapping.read(
        DriftSqlType.int,
        data['${effectivePrefix}id_bpe_cabecalho'],
      ),
      codigoPercurso: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}codigo_percurso'],
      ),
      descricaoPercurso: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}descricao_percurso'],
      ),
      tipoViagem: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}tipo_viagem'],
      ),
      tipoServico: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}tipo_servico'],
      ),
      tipoAcomodacao: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}tipo_acomodacao'],
      ),
      tipoTrecho: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}tipo_trecho'],
      ),
      dataHoraViagem: attachedDatabase.typeMapping.read(
        DriftSqlType.dateTime,
        data['${effectivePrefix}data_hora_viagem'],
      ),
      dataHoraConexao: attachedDatabase.typeMapping.read(
        DriftSqlType.dateTime,
        data['${effectivePrefix}data_hora_conexao'],
      ),
      prefixoLinha: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}prefixo_linha'],
      ),
      poltrona: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}poltrona'],
      ),
      plataforma: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}plataforma'],
      ),
    );
  }

  @override
  $BpeViagemsTable createAlias(String alias) {
    return $BpeViagemsTable(attachedDatabase, alias);
  }
}

class BpeViagem extends DataClass implements Insertable<BpeViagem> {
  final int? id;
  final int? idBpeCabecalho;
  final String? codigoPercurso;
  final String? descricaoPercurso;
  final String? tipoViagem;
  final String? tipoServico;
  final String? tipoAcomodacao;
  final String? tipoTrecho;
  final DateTime? dataHoraViagem;
  final DateTime? dataHoraConexao;
  final String? prefixoLinha;
  final String? poltrona;
  final String? plataforma;
  const BpeViagem({
    this.id,
    this.idBpeCabecalho,
    this.codigoPercurso,
    this.descricaoPercurso,
    this.tipoViagem,
    this.tipoServico,
    this.tipoAcomodacao,
    this.tipoTrecho,
    this.dataHoraViagem,
    this.dataHoraConexao,
    this.prefixoLinha,
    this.poltrona,
    this.plataforma,
  });
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || idBpeCabecalho != null) {
      map['id_bpe_cabecalho'] = Variable<int>(idBpeCabecalho);
    }
    if (!nullToAbsent || codigoPercurso != null) {
      map['codigo_percurso'] = Variable<String>(codigoPercurso);
    }
    if (!nullToAbsent || descricaoPercurso != null) {
      map['descricao_percurso'] = Variable<String>(descricaoPercurso);
    }
    if (!nullToAbsent || tipoViagem != null) {
      map['tipo_viagem'] = Variable<String>(tipoViagem);
    }
    if (!nullToAbsent || tipoServico != null) {
      map['tipo_servico'] = Variable<String>(tipoServico);
    }
    if (!nullToAbsent || tipoAcomodacao != null) {
      map['tipo_acomodacao'] = Variable<String>(tipoAcomodacao);
    }
    if (!nullToAbsent || tipoTrecho != null) {
      map['tipo_trecho'] = Variable<String>(tipoTrecho);
    }
    if (!nullToAbsent || dataHoraViagem != null) {
      map['data_hora_viagem'] = Variable<DateTime>(dataHoraViagem);
    }
    if (!nullToAbsent || dataHoraConexao != null) {
      map['data_hora_conexao'] = Variable<DateTime>(dataHoraConexao);
    }
    if (!nullToAbsent || prefixoLinha != null) {
      map['prefixo_linha'] = Variable<String>(prefixoLinha);
    }
    if (!nullToAbsent || poltrona != null) {
      map['poltrona'] = Variable<String>(poltrona);
    }
    if (!nullToAbsent || plataforma != null) {
      map['plataforma'] = Variable<String>(plataforma);
    }
    return map;
  }

  factory BpeViagem.fromJson(
    Map<String, dynamic> json, {
    ValueSerializer? serializer,
  }) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return BpeViagem(
      id: serializer.fromJson<int?>(json['id']),
      idBpeCabecalho: serializer.fromJson<int?>(json['idBpeCabecalho']),
      codigoPercurso: serializer.fromJson<String?>(json['codigoPercurso']),
      descricaoPercurso: serializer.fromJson<String?>(
        json['descricaoPercurso'],
      ),
      tipoViagem: serializer.fromJson<String?>(json['tipoViagem']),
      tipoServico: serializer.fromJson<String?>(json['tipoServico']),
      tipoAcomodacao: serializer.fromJson<String?>(json['tipoAcomodacao']),
      tipoTrecho: serializer.fromJson<String?>(json['tipoTrecho']),
      dataHoraViagem: serializer.fromJson<DateTime?>(json['dataHoraViagem']),
      dataHoraConexao: serializer.fromJson<DateTime?>(json['dataHoraConexao']),
      prefixoLinha: serializer.fromJson<String?>(json['prefixoLinha']),
      poltrona: serializer.fromJson<String?>(json['poltrona']),
      plataforma: serializer.fromJson<String?>(json['plataforma']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'idBpeCabecalho': serializer.toJson<int?>(idBpeCabecalho),
      'codigoPercurso': serializer.toJson<String?>(codigoPercurso),
      'descricaoPercurso': serializer.toJson<String?>(descricaoPercurso),
      'tipoViagem': serializer.toJson<String?>(tipoViagem),
      'tipoServico': serializer.toJson<String?>(tipoServico),
      'tipoAcomodacao': serializer.toJson<String?>(tipoAcomodacao),
      'tipoTrecho': serializer.toJson<String?>(tipoTrecho),
      'dataHoraViagem': serializer.toJson<DateTime?>(dataHoraViagem),
      'dataHoraConexao': serializer.toJson<DateTime?>(dataHoraConexao),
      'prefixoLinha': serializer.toJson<String?>(prefixoLinha),
      'poltrona': serializer.toJson<String?>(poltrona),
      'plataforma': serializer.toJson<String?>(plataforma),
    };
  }

  BpeViagem copyWith({
    Value<int?> id = const Value.absent(),
    Value<int?> idBpeCabecalho = const Value.absent(),
    Value<String?> codigoPercurso = const Value.absent(),
    Value<String?> descricaoPercurso = const Value.absent(),
    Value<String?> tipoViagem = const Value.absent(),
    Value<String?> tipoServico = const Value.absent(),
    Value<String?> tipoAcomodacao = const Value.absent(),
    Value<String?> tipoTrecho = const Value.absent(),
    Value<DateTime?> dataHoraViagem = const Value.absent(),
    Value<DateTime?> dataHoraConexao = const Value.absent(),
    Value<String?> prefixoLinha = const Value.absent(),
    Value<String?> poltrona = const Value.absent(),
    Value<String?> plataforma = const Value.absent(),
  }) => BpeViagem(
    id: id.present ? id.value : this.id,
    idBpeCabecalho:
        idBpeCabecalho.present ? idBpeCabecalho.value : this.idBpeCabecalho,
    codigoPercurso:
        codigoPercurso.present ? codigoPercurso.value : this.codigoPercurso,
    descricaoPercurso:
        descricaoPercurso.present
            ? descricaoPercurso.value
            : this.descricaoPercurso,
    tipoViagem: tipoViagem.present ? tipoViagem.value : this.tipoViagem,
    tipoServico: tipoServico.present ? tipoServico.value : this.tipoServico,
    tipoAcomodacao:
        tipoAcomodacao.present ? tipoAcomodacao.value : this.tipoAcomodacao,
    tipoTrecho: tipoTrecho.present ? tipoTrecho.value : this.tipoTrecho,
    dataHoraViagem:
        dataHoraViagem.present ? dataHoraViagem.value : this.dataHoraViagem,
    dataHoraConexao:
        dataHoraConexao.present ? dataHoraConexao.value : this.dataHoraConexao,
    prefixoLinha: prefixoLinha.present ? prefixoLinha.value : this.prefixoLinha,
    poltrona: poltrona.present ? poltrona.value : this.poltrona,
    plataforma: plataforma.present ? plataforma.value : this.plataforma,
  );
  BpeViagem copyWithCompanion(BpeViagemsCompanion data) {
    return BpeViagem(
      id: data.id.present ? data.id.value : this.id,
      idBpeCabecalho:
          data.idBpeCabecalho.present
              ? data.idBpeCabecalho.value
              : this.idBpeCabecalho,
      codigoPercurso:
          data.codigoPercurso.present
              ? data.codigoPercurso.value
              : this.codigoPercurso,
      descricaoPercurso:
          data.descricaoPercurso.present
              ? data.descricaoPercurso.value
              : this.descricaoPercurso,
      tipoViagem:
          data.tipoViagem.present ? data.tipoViagem.value : this.tipoViagem,
      tipoServico:
          data.tipoServico.present ? data.tipoServico.value : this.tipoServico,
      tipoAcomodacao:
          data.tipoAcomodacao.present
              ? data.tipoAcomodacao.value
              : this.tipoAcomodacao,
      tipoTrecho:
          data.tipoTrecho.present ? data.tipoTrecho.value : this.tipoTrecho,
      dataHoraViagem:
          data.dataHoraViagem.present
              ? data.dataHoraViagem.value
              : this.dataHoraViagem,
      dataHoraConexao:
          data.dataHoraConexao.present
              ? data.dataHoraConexao.value
              : this.dataHoraConexao,
      prefixoLinha:
          data.prefixoLinha.present
              ? data.prefixoLinha.value
              : this.prefixoLinha,
      poltrona: data.poltrona.present ? data.poltrona.value : this.poltrona,
      plataforma:
          data.plataforma.present ? data.plataforma.value : this.plataforma,
    );
  }

  @override
  String toString() {
    return (StringBuffer('BpeViagem(')
          ..write('id: $id, ')
          ..write('idBpeCabecalho: $idBpeCabecalho, ')
          ..write('codigoPercurso: $codigoPercurso, ')
          ..write('descricaoPercurso: $descricaoPercurso, ')
          ..write('tipoViagem: $tipoViagem, ')
          ..write('tipoServico: $tipoServico, ')
          ..write('tipoAcomodacao: $tipoAcomodacao, ')
          ..write('tipoTrecho: $tipoTrecho, ')
          ..write('dataHoraViagem: $dataHoraViagem, ')
          ..write('dataHoraConexao: $dataHoraConexao, ')
          ..write('prefixoLinha: $prefixoLinha, ')
          ..write('poltrona: $poltrona, ')
          ..write('plataforma: $plataforma')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(
    id,
    idBpeCabecalho,
    codigoPercurso,
    descricaoPercurso,
    tipoViagem,
    tipoServico,
    tipoAcomodacao,
    tipoTrecho,
    dataHoraViagem,
    dataHoraConexao,
    prefixoLinha,
    poltrona,
    plataforma,
  );
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is BpeViagem &&
          other.id == this.id &&
          other.idBpeCabecalho == this.idBpeCabecalho &&
          other.codigoPercurso == this.codigoPercurso &&
          other.descricaoPercurso == this.descricaoPercurso &&
          other.tipoViagem == this.tipoViagem &&
          other.tipoServico == this.tipoServico &&
          other.tipoAcomodacao == this.tipoAcomodacao &&
          other.tipoTrecho == this.tipoTrecho &&
          other.dataHoraViagem == this.dataHoraViagem &&
          other.dataHoraConexao == this.dataHoraConexao &&
          other.prefixoLinha == this.prefixoLinha &&
          other.poltrona == this.poltrona &&
          other.plataforma == this.plataforma);
}

class BpeViagemsCompanion extends UpdateCompanion<BpeViagem> {
  final Value<int?> id;
  final Value<int?> idBpeCabecalho;
  final Value<String?> codigoPercurso;
  final Value<String?> descricaoPercurso;
  final Value<String?> tipoViagem;
  final Value<String?> tipoServico;
  final Value<String?> tipoAcomodacao;
  final Value<String?> tipoTrecho;
  final Value<DateTime?> dataHoraViagem;
  final Value<DateTime?> dataHoraConexao;
  final Value<String?> prefixoLinha;
  final Value<String?> poltrona;
  final Value<String?> plataforma;
  const BpeViagemsCompanion({
    this.id = const Value.absent(),
    this.idBpeCabecalho = const Value.absent(),
    this.codigoPercurso = const Value.absent(),
    this.descricaoPercurso = const Value.absent(),
    this.tipoViagem = const Value.absent(),
    this.tipoServico = const Value.absent(),
    this.tipoAcomodacao = const Value.absent(),
    this.tipoTrecho = const Value.absent(),
    this.dataHoraViagem = const Value.absent(),
    this.dataHoraConexao = const Value.absent(),
    this.prefixoLinha = const Value.absent(),
    this.poltrona = const Value.absent(),
    this.plataforma = const Value.absent(),
  });
  BpeViagemsCompanion.insert({
    this.id = const Value.absent(),
    this.idBpeCabecalho = const Value.absent(),
    this.codigoPercurso = const Value.absent(),
    this.descricaoPercurso = const Value.absent(),
    this.tipoViagem = const Value.absent(),
    this.tipoServico = const Value.absent(),
    this.tipoAcomodacao = const Value.absent(),
    this.tipoTrecho = const Value.absent(),
    this.dataHoraViagem = const Value.absent(),
    this.dataHoraConexao = const Value.absent(),
    this.prefixoLinha = const Value.absent(),
    this.poltrona = const Value.absent(),
    this.plataforma = const Value.absent(),
  });
  static Insertable<BpeViagem> custom({
    Expression<int>? id,
    Expression<int>? idBpeCabecalho,
    Expression<String>? codigoPercurso,
    Expression<String>? descricaoPercurso,
    Expression<String>? tipoViagem,
    Expression<String>? tipoServico,
    Expression<String>? tipoAcomodacao,
    Expression<String>? tipoTrecho,
    Expression<DateTime>? dataHoraViagem,
    Expression<DateTime>? dataHoraConexao,
    Expression<String>? prefixoLinha,
    Expression<String>? poltrona,
    Expression<String>? plataforma,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (idBpeCabecalho != null) 'id_bpe_cabecalho': idBpeCabecalho,
      if (codigoPercurso != null) 'codigo_percurso': codigoPercurso,
      if (descricaoPercurso != null) 'descricao_percurso': descricaoPercurso,
      if (tipoViagem != null) 'tipo_viagem': tipoViagem,
      if (tipoServico != null) 'tipo_servico': tipoServico,
      if (tipoAcomodacao != null) 'tipo_acomodacao': tipoAcomodacao,
      if (tipoTrecho != null) 'tipo_trecho': tipoTrecho,
      if (dataHoraViagem != null) 'data_hora_viagem': dataHoraViagem,
      if (dataHoraConexao != null) 'data_hora_conexao': dataHoraConexao,
      if (prefixoLinha != null) 'prefixo_linha': prefixoLinha,
      if (poltrona != null) 'poltrona': poltrona,
      if (plataforma != null) 'plataforma': plataforma,
    });
  }

  BpeViagemsCompanion copyWith({
    Value<int?>? id,
    Value<int?>? idBpeCabecalho,
    Value<String?>? codigoPercurso,
    Value<String?>? descricaoPercurso,
    Value<String?>? tipoViagem,
    Value<String?>? tipoServico,
    Value<String?>? tipoAcomodacao,
    Value<String?>? tipoTrecho,
    Value<DateTime?>? dataHoraViagem,
    Value<DateTime?>? dataHoraConexao,
    Value<String?>? prefixoLinha,
    Value<String?>? poltrona,
    Value<String?>? plataforma,
  }) {
    return BpeViagemsCompanion(
      id: id ?? this.id,
      idBpeCabecalho: idBpeCabecalho ?? this.idBpeCabecalho,
      codigoPercurso: codigoPercurso ?? this.codigoPercurso,
      descricaoPercurso: descricaoPercurso ?? this.descricaoPercurso,
      tipoViagem: tipoViagem ?? this.tipoViagem,
      tipoServico: tipoServico ?? this.tipoServico,
      tipoAcomodacao: tipoAcomodacao ?? this.tipoAcomodacao,
      tipoTrecho: tipoTrecho ?? this.tipoTrecho,
      dataHoraViagem: dataHoraViagem ?? this.dataHoraViagem,
      dataHoraConexao: dataHoraConexao ?? this.dataHoraConexao,
      prefixoLinha: prefixoLinha ?? this.prefixoLinha,
      poltrona: poltrona ?? this.poltrona,
      plataforma: plataforma ?? this.plataforma,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (idBpeCabecalho.present) {
      map['id_bpe_cabecalho'] = Variable<int>(idBpeCabecalho.value);
    }
    if (codigoPercurso.present) {
      map['codigo_percurso'] = Variable<String>(codigoPercurso.value);
    }
    if (descricaoPercurso.present) {
      map['descricao_percurso'] = Variable<String>(descricaoPercurso.value);
    }
    if (tipoViagem.present) {
      map['tipo_viagem'] = Variable<String>(tipoViagem.value);
    }
    if (tipoServico.present) {
      map['tipo_servico'] = Variable<String>(tipoServico.value);
    }
    if (tipoAcomodacao.present) {
      map['tipo_acomodacao'] = Variable<String>(tipoAcomodacao.value);
    }
    if (tipoTrecho.present) {
      map['tipo_trecho'] = Variable<String>(tipoTrecho.value);
    }
    if (dataHoraViagem.present) {
      map['data_hora_viagem'] = Variable<DateTime>(dataHoraViagem.value);
    }
    if (dataHoraConexao.present) {
      map['data_hora_conexao'] = Variable<DateTime>(dataHoraConexao.value);
    }
    if (prefixoLinha.present) {
      map['prefixo_linha'] = Variable<String>(prefixoLinha.value);
    }
    if (poltrona.present) {
      map['poltrona'] = Variable<String>(poltrona.value);
    }
    if (plataforma.present) {
      map['plataforma'] = Variable<String>(plataforma.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('BpeViagemsCompanion(')
          ..write('id: $id, ')
          ..write('idBpeCabecalho: $idBpeCabecalho, ')
          ..write('codigoPercurso: $codigoPercurso, ')
          ..write('descricaoPercurso: $descricaoPercurso, ')
          ..write('tipoViagem: $tipoViagem, ')
          ..write('tipoServico: $tipoServico, ')
          ..write('tipoAcomodacao: $tipoAcomodacao, ')
          ..write('tipoTrecho: $tipoTrecho, ')
          ..write('dataHoraViagem: $dataHoraViagem, ')
          ..write('dataHoraConexao: $dataHoraConexao, ')
          ..write('prefixoLinha: $prefixoLinha, ')
          ..write('poltrona: $poltrona, ')
          ..write('plataforma: $plataforma')
          ..write(')'))
        .toString();
  }
}

class $BpeAgenciasTable extends BpeAgencias
    with TableInfo<$BpeAgenciasTable, BpeAgencia> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $BpeAgenciasTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
    'id',
    aliasedName,
    true,
    type: DriftSqlType.int,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _idBpeCabecalhoMeta = const VerificationMeta(
    'idBpeCabecalho',
  );
  @override
  late final GeneratedColumn<int> idBpeCabecalho = GeneratedColumn<int>(
    'id_bpe_cabecalho',
    aliasedName,
    true,
    type: DriftSqlType.int,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _cnpjMeta = const VerificationMeta('cnpj');
  @override
  late final GeneratedColumn<String> cnpj = GeneratedColumn<String>(
    'cnpj',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 14,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _nomeMeta = const VerificationMeta('nome');
  @override
  late final GeneratedColumn<String> nome = GeneratedColumn<String>(
    'nome',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 60,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _telefoneMeta = const VerificationMeta(
    'telefone',
  );
  @override
  late final GeneratedColumn<String> telefone = GeneratedColumn<String>(
    'telefone',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 14,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _logradouroMeta = const VerificationMeta(
    'logradouro',
  );
  @override
  late final GeneratedColumn<String> logradouro = GeneratedColumn<String>(
    'logradouro',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 250,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _numeroMeta = const VerificationMeta('numero');
  @override
  late final GeneratedColumn<String> numero = GeneratedColumn<String>(
    'numero',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 60,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _complementoMeta = const VerificationMeta(
    'complemento',
  );
  @override
  late final GeneratedColumn<String> complemento = GeneratedColumn<String>(
    'complemento',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 60,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _bairroMeta = const VerificationMeta('bairro');
  @override
  late final GeneratedColumn<String> bairro = GeneratedColumn<String>(
    'bairro',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 60,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _codigoMunicipioMeta = const VerificationMeta(
    'codigoMunicipio',
  );
  @override
  late final GeneratedColumn<int> codigoMunicipio = GeneratedColumn<int>(
    'codigo_municipio',
    aliasedName,
    true,
    type: DriftSqlType.int,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _nomeMunicipioMeta = const VerificationMeta(
    'nomeMunicipio',
  );
  @override
  late final GeneratedColumn<String> nomeMunicipio = GeneratedColumn<String>(
    'nome_municipio',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 60,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _ufMeta = const VerificationMeta('uf');
  @override
  late final GeneratedColumn<String> uf = GeneratedColumn<String>(
    'uf',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 2,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _cepMeta = const VerificationMeta('cep');
  @override
  late final GeneratedColumn<String> cep = GeneratedColumn<String>(
    'cep',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 8,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _codigoPaisMeta = const VerificationMeta(
    'codigoPais',
  );
  @override
  late final GeneratedColumn<int> codigoPais = GeneratedColumn<int>(
    'codigo_pais',
    aliasedName,
    true,
    type: DriftSqlType.int,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _nomePaisMeta = const VerificationMeta(
    'nomePais',
  );
  @override
  late final GeneratedColumn<String> nomePais = GeneratedColumn<String>(
    'nome_pais',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 60,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _emailMeta = const VerificationMeta('email');
  @override
  late final GeneratedColumn<String> email = GeneratedColumn<String>(
    'email',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 60,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  @override
  List<GeneratedColumn> get $columns => [
    id,
    idBpeCabecalho,
    cnpj,
    nome,
    telefone,
    logradouro,
    numero,
    complemento,
    bairro,
    codigoMunicipio,
    nomeMunicipio,
    uf,
    cep,
    codigoPais,
    nomePais,
    email,
  ];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'bpe_agencia';
  @override
  VerificationContext validateIntegrity(
    Insertable<BpeAgencia> instance, {
    bool isInserting = false,
  }) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('id_bpe_cabecalho')) {
      context.handle(
        _idBpeCabecalhoMeta,
        idBpeCabecalho.isAcceptableOrUnknown(
          data['id_bpe_cabecalho']!,
          _idBpeCabecalhoMeta,
        ),
      );
    }
    if (data.containsKey('cnpj')) {
      context.handle(
        _cnpjMeta,
        cnpj.isAcceptableOrUnknown(data['cnpj']!, _cnpjMeta),
      );
    }
    if (data.containsKey('nome')) {
      context.handle(
        _nomeMeta,
        nome.isAcceptableOrUnknown(data['nome']!, _nomeMeta),
      );
    }
    if (data.containsKey('telefone')) {
      context.handle(
        _telefoneMeta,
        telefone.isAcceptableOrUnknown(data['telefone']!, _telefoneMeta),
      );
    }
    if (data.containsKey('logradouro')) {
      context.handle(
        _logradouroMeta,
        logradouro.isAcceptableOrUnknown(data['logradouro']!, _logradouroMeta),
      );
    }
    if (data.containsKey('numero')) {
      context.handle(
        _numeroMeta,
        numero.isAcceptableOrUnknown(data['numero']!, _numeroMeta),
      );
    }
    if (data.containsKey('complemento')) {
      context.handle(
        _complementoMeta,
        complemento.isAcceptableOrUnknown(
          data['complemento']!,
          _complementoMeta,
        ),
      );
    }
    if (data.containsKey('bairro')) {
      context.handle(
        _bairroMeta,
        bairro.isAcceptableOrUnknown(data['bairro']!, _bairroMeta),
      );
    }
    if (data.containsKey('codigo_municipio')) {
      context.handle(
        _codigoMunicipioMeta,
        codigoMunicipio.isAcceptableOrUnknown(
          data['codigo_municipio']!,
          _codigoMunicipioMeta,
        ),
      );
    }
    if (data.containsKey('nome_municipio')) {
      context.handle(
        _nomeMunicipioMeta,
        nomeMunicipio.isAcceptableOrUnknown(
          data['nome_municipio']!,
          _nomeMunicipioMeta,
        ),
      );
    }
    if (data.containsKey('uf')) {
      context.handle(_ufMeta, uf.isAcceptableOrUnknown(data['uf']!, _ufMeta));
    }
    if (data.containsKey('cep')) {
      context.handle(
        _cepMeta,
        cep.isAcceptableOrUnknown(data['cep']!, _cepMeta),
      );
    }
    if (data.containsKey('codigo_pais')) {
      context.handle(
        _codigoPaisMeta,
        codigoPais.isAcceptableOrUnknown(data['codigo_pais']!, _codigoPaisMeta),
      );
    }
    if (data.containsKey('nome_pais')) {
      context.handle(
        _nomePaisMeta,
        nomePais.isAcceptableOrUnknown(data['nome_pais']!, _nomePaisMeta),
      );
    }
    if (data.containsKey('email')) {
      context.handle(
        _emailMeta,
        email.isAcceptableOrUnknown(data['email']!, _emailMeta),
      );
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  BpeAgencia map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return BpeAgencia(
      id: attachedDatabase.typeMapping.read(
        DriftSqlType.int,
        data['${effectivePrefix}id'],
      ),
      idBpeCabecalho: attachedDatabase.typeMapping.read(
        DriftSqlType.int,
        data['${effectivePrefix}id_bpe_cabecalho'],
      ),
      cnpj: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}cnpj'],
      ),
      nome: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}nome'],
      ),
      telefone: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}telefone'],
      ),
      logradouro: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}logradouro'],
      ),
      numero: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}numero'],
      ),
      complemento: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}complemento'],
      ),
      bairro: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}bairro'],
      ),
      codigoMunicipio: attachedDatabase.typeMapping.read(
        DriftSqlType.int,
        data['${effectivePrefix}codigo_municipio'],
      ),
      nomeMunicipio: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}nome_municipio'],
      ),
      uf: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}uf'],
      ),
      cep: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}cep'],
      ),
      codigoPais: attachedDatabase.typeMapping.read(
        DriftSqlType.int,
        data['${effectivePrefix}codigo_pais'],
      ),
      nomePais: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}nome_pais'],
      ),
      email: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}email'],
      ),
    );
  }

  @override
  $BpeAgenciasTable createAlias(String alias) {
    return $BpeAgenciasTable(attachedDatabase, alias);
  }
}

class BpeAgencia extends DataClass implements Insertable<BpeAgencia> {
  final int? id;
  final int? idBpeCabecalho;
  final String? cnpj;
  final String? nome;
  final String? telefone;
  final String? logradouro;
  final String? numero;
  final String? complemento;
  final String? bairro;
  final int? codigoMunicipio;
  final String? nomeMunicipio;
  final String? uf;
  final String? cep;
  final int? codigoPais;
  final String? nomePais;
  final String? email;
  const BpeAgencia({
    this.id,
    this.idBpeCabecalho,
    this.cnpj,
    this.nome,
    this.telefone,
    this.logradouro,
    this.numero,
    this.complemento,
    this.bairro,
    this.codigoMunicipio,
    this.nomeMunicipio,
    this.uf,
    this.cep,
    this.codigoPais,
    this.nomePais,
    this.email,
  });
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || idBpeCabecalho != null) {
      map['id_bpe_cabecalho'] = Variable<int>(idBpeCabecalho);
    }
    if (!nullToAbsent || cnpj != null) {
      map['cnpj'] = Variable<String>(cnpj);
    }
    if (!nullToAbsent || nome != null) {
      map['nome'] = Variable<String>(nome);
    }
    if (!nullToAbsent || telefone != null) {
      map['telefone'] = Variable<String>(telefone);
    }
    if (!nullToAbsent || logradouro != null) {
      map['logradouro'] = Variable<String>(logradouro);
    }
    if (!nullToAbsent || numero != null) {
      map['numero'] = Variable<String>(numero);
    }
    if (!nullToAbsent || complemento != null) {
      map['complemento'] = Variable<String>(complemento);
    }
    if (!nullToAbsent || bairro != null) {
      map['bairro'] = Variable<String>(bairro);
    }
    if (!nullToAbsent || codigoMunicipio != null) {
      map['codigo_municipio'] = Variable<int>(codigoMunicipio);
    }
    if (!nullToAbsent || nomeMunicipio != null) {
      map['nome_municipio'] = Variable<String>(nomeMunicipio);
    }
    if (!nullToAbsent || uf != null) {
      map['uf'] = Variable<String>(uf);
    }
    if (!nullToAbsent || cep != null) {
      map['cep'] = Variable<String>(cep);
    }
    if (!nullToAbsent || codigoPais != null) {
      map['codigo_pais'] = Variable<int>(codigoPais);
    }
    if (!nullToAbsent || nomePais != null) {
      map['nome_pais'] = Variable<String>(nomePais);
    }
    if (!nullToAbsent || email != null) {
      map['email'] = Variable<String>(email);
    }
    return map;
  }

  factory BpeAgencia.fromJson(
    Map<String, dynamic> json, {
    ValueSerializer? serializer,
  }) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return BpeAgencia(
      id: serializer.fromJson<int?>(json['id']),
      idBpeCabecalho: serializer.fromJson<int?>(json['idBpeCabecalho']),
      cnpj: serializer.fromJson<String?>(json['cnpj']),
      nome: serializer.fromJson<String?>(json['nome']),
      telefone: serializer.fromJson<String?>(json['telefone']),
      logradouro: serializer.fromJson<String?>(json['logradouro']),
      numero: serializer.fromJson<String?>(json['numero']),
      complemento: serializer.fromJson<String?>(json['complemento']),
      bairro: serializer.fromJson<String?>(json['bairro']),
      codigoMunicipio: serializer.fromJson<int?>(json['codigoMunicipio']),
      nomeMunicipio: serializer.fromJson<String?>(json['nomeMunicipio']),
      uf: serializer.fromJson<String?>(json['uf']),
      cep: serializer.fromJson<String?>(json['cep']),
      codigoPais: serializer.fromJson<int?>(json['codigoPais']),
      nomePais: serializer.fromJson<String?>(json['nomePais']),
      email: serializer.fromJson<String?>(json['email']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'idBpeCabecalho': serializer.toJson<int?>(idBpeCabecalho),
      'cnpj': serializer.toJson<String?>(cnpj),
      'nome': serializer.toJson<String?>(nome),
      'telefone': serializer.toJson<String?>(telefone),
      'logradouro': serializer.toJson<String?>(logradouro),
      'numero': serializer.toJson<String?>(numero),
      'complemento': serializer.toJson<String?>(complemento),
      'bairro': serializer.toJson<String?>(bairro),
      'codigoMunicipio': serializer.toJson<int?>(codigoMunicipio),
      'nomeMunicipio': serializer.toJson<String?>(nomeMunicipio),
      'uf': serializer.toJson<String?>(uf),
      'cep': serializer.toJson<String?>(cep),
      'codigoPais': serializer.toJson<int?>(codigoPais),
      'nomePais': serializer.toJson<String?>(nomePais),
      'email': serializer.toJson<String?>(email),
    };
  }

  BpeAgencia copyWith({
    Value<int?> id = const Value.absent(),
    Value<int?> idBpeCabecalho = const Value.absent(),
    Value<String?> cnpj = const Value.absent(),
    Value<String?> nome = const Value.absent(),
    Value<String?> telefone = const Value.absent(),
    Value<String?> logradouro = const Value.absent(),
    Value<String?> numero = const Value.absent(),
    Value<String?> complemento = const Value.absent(),
    Value<String?> bairro = const Value.absent(),
    Value<int?> codigoMunicipio = const Value.absent(),
    Value<String?> nomeMunicipio = const Value.absent(),
    Value<String?> uf = const Value.absent(),
    Value<String?> cep = const Value.absent(),
    Value<int?> codigoPais = const Value.absent(),
    Value<String?> nomePais = const Value.absent(),
    Value<String?> email = const Value.absent(),
  }) => BpeAgencia(
    id: id.present ? id.value : this.id,
    idBpeCabecalho:
        idBpeCabecalho.present ? idBpeCabecalho.value : this.idBpeCabecalho,
    cnpj: cnpj.present ? cnpj.value : this.cnpj,
    nome: nome.present ? nome.value : this.nome,
    telefone: telefone.present ? telefone.value : this.telefone,
    logradouro: logradouro.present ? logradouro.value : this.logradouro,
    numero: numero.present ? numero.value : this.numero,
    complemento: complemento.present ? complemento.value : this.complemento,
    bairro: bairro.present ? bairro.value : this.bairro,
    codigoMunicipio:
        codigoMunicipio.present ? codigoMunicipio.value : this.codigoMunicipio,
    nomeMunicipio:
        nomeMunicipio.present ? nomeMunicipio.value : this.nomeMunicipio,
    uf: uf.present ? uf.value : this.uf,
    cep: cep.present ? cep.value : this.cep,
    codigoPais: codigoPais.present ? codigoPais.value : this.codigoPais,
    nomePais: nomePais.present ? nomePais.value : this.nomePais,
    email: email.present ? email.value : this.email,
  );
  BpeAgencia copyWithCompanion(BpeAgenciasCompanion data) {
    return BpeAgencia(
      id: data.id.present ? data.id.value : this.id,
      idBpeCabecalho:
          data.idBpeCabecalho.present
              ? data.idBpeCabecalho.value
              : this.idBpeCabecalho,
      cnpj: data.cnpj.present ? data.cnpj.value : this.cnpj,
      nome: data.nome.present ? data.nome.value : this.nome,
      telefone: data.telefone.present ? data.telefone.value : this.telefone,
      logradouro:
          data.logradouro.present ? data.logradouro.value : this.logradouro,
      numero: data.numero.present ? data.numero.value : this.numero,
      complemento:
          data.complemento.present ? data.complemento.value : this.complemento,
      bairro: data.bairro.present ? data.bairro.value : this.bairro,
      codigoMunicipio:
          data.codigoMunicipio.present
              ? data.codigoMunicipio.value
              : this.codigoMunicipio,
      nomeMunicipio:
          data.nomeMunicipio.present
              ? data.nomeMunicipio.value
              : this.nomeMunicipio,
      uf: data.uf.present ? data.uf.value : this.uf,
      cep: data.cep.present ? data.cep.value : this.cep,
      codigoPais:
          data.codigoPais.present ? data.codigoPais.value : this.codigoPais,
      nomePais: data.nomePais.present ? data.nomePais.value : this.nomePais,
      email: data.email.present ? data.email.value : this.email,
    );
  }

  @override
  String toString() {
    return (StringBuffer('BpeAgencia(')
          ..write('id: $id, ')
          ..write('idBpeCabecalho: $idBpeCabecalho, ')
          ..write('cnpj: $cnpj, ')
          ..write('nome: $nome, ')
          ..write('telefone: $telefone, ')
          ..write('logradouro: $logradouro, ')
          ..write('numero: $numero, ')
          ..write('complemento: $complemento, ')
          ..write('bairro: $bairro, ')
          ..write('codigoMunicipio: $codigoMunicipio, ')
          ..write('nomeMunicipio: $nomeMunicipio, ')
          ..write('uf: $uf, ')
          ..write('cep: $cep, ')
          ..write('codigoPais: $codigoPais, ')
          ..write('nomePais: $nomePais, ')
          ..write('email: $email')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(
    id,
    idBpeCabecalho,
    cnpj,
    nome,
    telefone,
    logradouro,
    numero,
    complemento,
    bairro,
    codigoMunicipio,
    nomeMunicipio,
    uf,
    cep,
    codigoPais,
    nomePais,
    email,
  );
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is BpeAgencia &&
          other.id == this.id &&
          other.idBpeCabecalho == this.idBpeCabecalho &&
          other.cnpj == this.cnpj &&
          other.nome == this.nome &&
          other.telefone == this.telefone &&
          other.logradouro == this.logradouro &&
          other.numero == this.numero &&
          other.complemento == this.complemento &&
          other.bairro == this.bairro &&
          other.codigoMunicipio == this.codigoMunicipio &&
          other.nomeMunicipio == this.nomeMunicipio &&
          other.uf == this.uf &&
          other.cep == this.cep &&
          other.codigoPais == this.codigoPais &&
          other.nomePais == this.nomePais &&
          other.email == this.email);
}

class BpeAgenciasCompanion extends UpdateCompanion<BpeAgencia> {
  final Value<int?> id;
  final Value<int?> idBpeCabecalho;
  final Value<String?> cnpj;
  final Value<String?> nome;
  final Value<String?> telefone;
  final Value<String?> logradouro;
  final Value<String?> numero;
  final Value<String?> complemento;
  final Value<String?> bairro;
  final Value<int?> codigoMunicipio;
  final Value<String?> nomeMunicipio;
  final Value<String?> uf;
  final Value<String?> cep;
  final Value<int?> codigoPais;
  final Value<String?> nomePais;
  final Value<String?> email;
  const BpeAgenciasCompanion({
    this.id = const Value.absent(),
    this.idBpeCabecalho = const Value.absent(),
    this.cnpj = const Value.absent(),
    this.nome = const Value.absent(),
    this.telefone = const Value.absent(),
    this.logradouro = const Value.absent(),
    this.numero = const Value.absent(),
    this.complemento = const Value.absent(),
    this.bairro = const Value.absent(),
    this.codigoMunicipio = const Value.absent(),
    this.nomeMunicipio = const Value.absent(),
    this.uf = const Value.absent(),
    this.cep = const Value.absent(),
    this.codigoPais = const Value.absent(),
    this.nomePais = const Value.absent(),
    this.email = const Value.absent(),
  });
  BpeAgenciasCompanion.insert({
    this.id = const Value.absent(),
    this.idBpeCabecalho = const Value.absent(),
    this.cnpj = const Value.absent(),
    this.nome = const Value.absent(),
    this.telefone = const Value.absent(),
    this.logradouro = const Value.absent(),
    this.numero = const Value.absent(),
    this.complemento = const Value.absent(),
    this.bairro = const Value.absent(),
    this.codigoMunicipio = const Value.absent(),
    this.nomeMunicipio = const Value.absent(),
    this.uf = const Value.absent(),
    this.cep = const Value.absent(),
    this.codigoPais = const Value.absent(),
    this.nomePais = const Value.absent(),
    this.email = const Value.absent(),
  });
  static Insertable<BpeAgencia> custom({
    Expression<int>? id,
    Expression<int>? idBpeCabecalho,
    Expression<String>? cnpj,
    Expression<String>? nome,
    Expression<String>? telefone,
    Expression<String>? logradouro,
    Expression<String>? numero,
    Expression<String>? complemento,
    Expression<String>? bairro,
    Expression<int>? codigoMunicipio,
    Expression<String>? nomeMunicipio,
    Expression<String>? uf,
    Expression<String>? cep,
    Expression<int>? codigoPais,
    Expression<String>? nomePais,
    Expression<String>? email,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (idBpeCabecalho != null) 'id_bpe_cabecalho': idBpeCabecalho,
      if (cnpj != null) 'cnpj': cnpj,
      if (nome != null) 'nome': nome,
      if (telefone != null) 'telefone': telefone,
      if (logradouro != null) 'logradouro': logradouro,
      if (numero != null) 'numero': numero,
      if (complemento != null) 'complemento': complemento,
      if (bairro != null) 'bairro': bairro,
      if (codigoMunicipio != null) 'codigo_municipio': codigoMunicipio,
      if (nomeMunicipio != null) 'nome_municipio': nomeMunicipio,
      if (uf != null) 'uf': uf,
      if (cep != null) 'cep': cep,
      if (codigoPais != null) 'codigo_pais': codigoPais,
      if (nomePais != null) 'nome_pais': nomePais,
      if (email != null) 'email': email,
    });
  }

  BpeAgenciasCompanion copyWith({
    Value<int?>? id,
    Value<int?>? idBpeCabecalho,
    Value<String?>? cnpj,
    Value<String?>? nome,
    Value<String?>? telefone,
    Value<String?>? logradouro,
    Value<String?>? numero,
    Value<String?>? complemento,
    Value<String?>? bairro,
    Value<int?>? codigoMunicipio,
    Value<String?>? nomeMunicipio,
    Value<String?>? uf,
    Value<String?>? cep,
    Value<int?>? codigoPais,
    Value<String?>? nomePais,
    Value<String?>? email,
  }) {
    return BpeAgenciasCompanion(
      id: id ?? this.id,
      idBpeCabecalho: idBpeCabecalho ?? this.idBpeCabecalho,
      cnpj: cnpj ?? this.cnpj,
      nome: nome ?? this.nome,
      telefone: telefone ?? this.telefone,
      logradouro: logradouro ?? this.logradouro,
      numero: numero ?? this.numero,
      complemento: complemento ?? this.complemento,
      bairro: bairro ?? this.bairro,
      codigoMunicipio: codigoMunicipio ?? this.codigoMunicipio,
      nomeMunicipio: nomeMunicipio ?? this.nomeMunicipio,
      uf: uf ?? this.uf,
      cep: cep ?? this.cep,
      codigoPais: codigoPais ?? this.codigoPais,
      nomePais: nomePais ?? this.nomePais,
      email: email ?? this.email,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (idBpeCabecalho.present) {
      map['id_bpe_cabecalho'] = Variable<int>(idBpeCabecalho.value);
    }
    if (cnpj.present) {
      map['cnpj'] = Variable<String>(cnpj.value);
    }
    if (nome.present) {
      map['nome'] = Variable<String>(nome.value);
    }
    if (telefone.present) {
      map['telefone'] = Variable<String>(telefone.value);
    }
    if (logradouro.present) {
      map['logradouro'] = Variable<String>(logradouro.value);
    }
    if (numero.present) {
      map['numero'] = Variable<String>(numero.value);
    }
    if (complemento.present) {
      map['complemento'] = Variable<String>(complemento.value);
    }
    if (bairro.present) {
      map['bairro'] = Variable<String>(bairro.value);
    }
    if (codigoMunicipio.present) {
      map['codigo_municipio'] = Variable<int>(codigoMunicipio.value);
    }
    if (nomeMunicipio.present) {
      map['nome_municipio'] = Variable<String>(nomeMunicipio.value);
    }
    if (uf.present) {
      map['uf'] = Variable<String>(uf.value);
    }
    if (cep.present) {
      map['cep'] = Variable<String>(cep.value);
    }
    if (codigoPais.present) {
      map['codigo_pais'] = Variable<int>(codigoPais.value);
    }
    if (nomePais.present) {
      map['nome_pais'] = Variable<String>(nomePais.value);
    }
    if (email.present) {
      map['email'] = Variable<String>(email.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('BpeAgenciasCompanion(')
          ..write('id: $id, ')
          ..write('idBpeCabecalho: $idBpeCabecalho, ')
          ..write('cnpj: $cnpj, ')
          ..write('nome: $nome, ')
          ..write('telefone: $telefone, ')
          ..write('logradouro: $logradouro, ')
          ..write('numero: $numero, ')
          ..write('complemento: $complemento, ')
          ..write('bairro: $bairro, ')
          ..write('codigoMunicipio: $codigoMunicipio, ')
          ..write('nomeMunicipio: $nomeMunicipio, ')
          ..write('uf: $uf, ')
          ..write('cep: $cep, ')
          ..write('codigoPais: $codigoPais, ')
          ..write('nomePais: $nomePais, ')
          ..write('email: $email')
          ..write(')'))
        .toString();
  }
}

class $BpePassagemsTable extends BpePassagems
    with TableInfo<$BpePassagemsTable, BpePassagem> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $BpePassagemsTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
    'id',
    aliasedName,
    true,
    type: DriftSqlType.int,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _idBpeCabecalhoMeta = const VerificationMeta(
    'idBpeCabecalho',
  );
  @override
  late final GeneratedColumn<int> idBpeCabecalho = GeneratedColumn<int>(
    'id_bpe_cabecalho',
    aliasedName,
    true,
    type: DriftSqlType.int,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _codigoLocalidadeOrigemMeta =
      const VerificationMeta('codigoLocalidadeOrigem');
  @override
  late final GeneratedColumn<String> codigoLocalidadeOrigem =
      GeneratedColumn<String>(
        'codigo_localidade_origem',
        aliasedName,
        true,
        additionalChecks: GeneratedColumn.checkTextLength(
          minTextLength: 0,
          maxTextLength: 7,
        ),
        type: DriftSqlType.string,
        requiredDuringInsert: false,
      );
  static const VerificationMeta _descricaoLocalidadeOrigemMeta =
      const VerificationMeta('descricaoLocalidadeOrigem');
  @override
  late final GeneratedColumn<String> descricaoLocalidadeOrigem =
      GeneratedColumn<String>(
        'descricao_localidade_origem',
        aliasedName,
        true,
        additionalChecks: GeneratedColumn.checkTextLength(
          minTextLength: 0,
          maxTextLength: 60,
        ),
        type: DriftSqlType.string,
        requiredDuringInsert: false,
      );
  static const VerificationMeta _codigoLocalidadeDestinoMeta =
      const VerificationMeta('codigoLocalidadeDestino');
  @override
  late final GeneratedColumn<String> codigoLocalidadeDestino =
      GeneratedColumn<String>(
        'codigo_localidade_destino',
        aliasedName,
        true,
        additionalChecks: GeneratedColumn.checkTextLength(
          minTextLength: 0,
          maxTextLength: 7,
        ),
        type: DriftSqlType.string,
        requiredDuringInsert: false,
      );
  static const VerificationMeta _descricaoLocalidadeDestinoMeta =
      const VerificationMeta('descricaoLocalidadeDestino');
  @override
  late final GeneratedColumn<String> descricaoLocalidadeDestino =
      GeneratedColumn<String>(
        'descricao_localidade_destino',
        aliasedName,
        true,
        additionalChecks: GeneratedColumn.checkTextLength(
          minTextLength: 0,
          maxTextLength: 60,
        ),
        type: DriftSqlType.string,
        requiredDuringInsert: false,
      );
  static const VerificationMeta _dataHoraEmbarqueMeta = const VerificationMeta(
    'dataHoraEmbarque',
  );
  @override
  late final GeneratedColumn<DateTime> dataHoraEmbarque =
      GeneratedColumn<DateTime>(
        'data_hora_embarque',
        aliasedName,
        true,
        type: DriftSqlType.dateTime,
        requiredDuringInsert: false,
      );
  static const VerificationMeta _dataHoraValidadeMeta = const VerificationMeta(
    'dataHoraValidade',
  );
  @override
  late final GeneratedColumn<DateTime> dataHoraValidade =
      GeneratedColumn<DateTime>(
        'data_hora_validade',
        aliasedName,
        true,
        type: DriftSqlType.dateTime,
        requiredDuringInsert: false,
      );
  @override
  List<GeneratedColumn> get $columns => [
    id,
    idBpeCabecalho,
    codigoLocalidadeOrigem,
    descricaoLocalidadeOrigem,
    codigoLocalidadeDestino,
    descricaoLocalidadeDestino,
    dataHoraEmbarque,
    dataHoraValidade,
  ];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'bpe_passagem';
  @override
  VerificationContext validateIntegrity(
    Insertable<BpePassagem> instance, {
    bool isInserting = false,
  }) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('id_bpe_cabecalho')) {
      context.handle(
        _idBpeCabecalhoMeta,
        idBpeCabecalho.isAcceptableOrUnknown(
          data['id_bpe_cabecalho']!,
          _idBpeCabecalhoMeta,
        ),
      );
    }
    if (data.containsKey('codigo_localidade_origem')) {
      context.handle(
        _codigoLocalidadeOrigemMeta,
        codigoLocalidadeOrigem.isAcceptableOrUnknown(
          data['codigo_localidade_origem']!,
          _codigoLocalidadeOrigemMeta,
        ),
      );
    }
    if (data.containsKey('descricao_localidade_origem')) {
      context.handle(
        _descricaoLocalidadeOrigemMeta,
        descricaoLocalidadeOrigem.isAcceptableOrUnknown(
          data['descricao_localidade_origem']!,
          _descricaoLocalidadeOrigemMeta,
        ),
      );
    }
    if (data.containsKey('codigo_localidade_destino')) {
      context.handle(
        _codigoLocalidadeDestinoMeta,
        codigoLocalidadeDestino.isAcceptableOrUnknown(
          data['codigo_localidade_destino']!,
          _codigoLocalidadeDestinoMeta,
        ),
      );
    }
    if (data.containsKey('descricao_localidade_destino')) {
      context.handle(
        _descricaoLocalidadeDestinoMeta,
        descricaoLocalidadeDestino.isAcceptableOrUnknown(
          data['descricao_localidade_destino']!,
          _descricaoLocalidadeDestinoMeta,
        ),
      );
    }
    if (data.containsKey('data_hora_embarque')) {
      context.handle(
        _dataHoraEmbarqueMeta,
        dataHoraEmbarque.isAcceptableOrUnknown(
          data['data_hora_embarque']!,
          _dataHoraEmbarqueMeta,
        ),
      );
    }
    if (data.containsKey('data_hora_validade')) {
      context.handle(
        _dataHoraValidadeMeta,
        dataHoraValidade.isAcceptableOrUnknown(
          data['data_hora_validade']!,
          _dataHoraValidadeMeta,
        ),
      );
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  BpePassagem map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return BpePassagem(
      id: attachedDatabase.typeMapping.read(
        DriftSqlType.int,
        data['${effectivePrefix}id'],
      ),
      idBpeCabecalho: attachedDatabase.typeMapping.read(
        DriftSqlType.int,
        data['${effectivePrefix}id_bpe_cabecalho'],
      ),
      codigoLocalidadeOrigem: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}codigo_localidade_origem'],
      ),
      descricaoLocalidadeOrigem: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}descricao_localidade_origem'],
      ),
      codigoLocalidadeDestino: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}codigo_localidade_destino'],
      ),
      descricaoLocalidadeDestino: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}descricao_localidade_destino'],
      ),
      dataHoraEmbarque: attachedDatabase.typeMapping.read(
        DriftSqlType.dateTime,
        data['${effectivePrefix}data_hora_embarque'],
      ),
      dataHoraValidade: attachedDatabase.typeMapping.read(
        DriftSqlType.dateTime,
        data['${effectivePrefix}data_hora_validade'],
      ),
    );
  }

  @override
  $BpePassagemsTable createAlias(String alias) {
    return $BpePassagemsTable(attachedDatabase, alias);
  }
}

class BpePassagem extends DataClass implements Insertable<BpePassagem> {
  final int? id;
  final int? idBpeCabecalho;
  final String? codigoLocalidadeOrigem;
  final String? descricaoLocalidadeOrigem;
  final String? codigoLocalidadeDestino;
  final String? descricaoLocalidadeDestino;
  final DateTime? dataHoraEmbarque;
  final DateTime? dataHoraValidade;
  const BpePassagem({
    this.id,
    this.idBpeCabecalho,
    this.codigoLocalidadeOrigem,
    this.descricaoLocalidadeOrigem,
    this.codigoLocalidadeDestino,
    this.descricaoLocalidadeDestino,
    this.dataHoraEmbarque,
    this.dataHoraValidade,
  });
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || idBpeCabecalho != null) {
      map['id_bpe_cabecalho'] = Variable<int>(idBpeCabecalho);
    }
    if (!nullToAbsent || codigoLocalidadeOrigem != null) {
      map['codigo_localidade_origem'] = Variable<String>(
        codigoLocalidadeOrigem,
      );
    }
    if (!nullToAbsent || descricaoLocalidadeOrigem != null) {
      map['descricao_localidade_origem'] = Variable<String>(
        descricaoLocalidadeOrigem,
      );
    }
    if (!nullToAbsent || codigoLocalidadeDestino != null) {
      map['codigo_localidade_destino'] = Variable<String>(
        codigoLocalidadeDestino,
      );
    }
    if (!nullToAbsent || descricaoLocalidadeDestino != null) {
      map['descricao_localidade_destino'] = Variable<String>(
        descricaoLocalidadeDestino,
      );
    }
    if (!nullToAbsent || dataHoraEmbarque != null) {
      map['data_hora_embarque'] = Variable<DateTime>(dataHoraEmbarque);
    }
    if (!nullToAbsent || dataHoraValidade != null) {
      map['data_hora_validade'] = Variable<DateTime>(dataHoraValidade);
    }
    return map;
  }

  factory BpePassagem.fromJson(
    Map<String, dynamic> json, {
    ValueSerializer? serializer,
  }) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return BpePassagem(
      id: serializer.fromJson<int?>(json['id']),
      idBpeCabecalho: serializer.fromJson<int?>(json['idBpeCabecalho']),
      codigoLocalidadeOrigem: serializer.fromJson<String?>(
        json['codigoLocalidadeOrigem'],
      ),
      descricaoLocalidadeOrigem: serializer.fromJson<String?>(
        json['descricaoLocalidadeOrigem'],
      ),
      codigoLocalidadeDestino: serializer.fromJson<String?>(
        json['codigoLocalidadeDestino'],
      ),
      descricaoLocalidadeDestino: serializer.fromJson<String?>(
        json['descricaoLocalidadeDestino'],
      ),
      dataHoraEmbarque: serializer.fromJson<DateTime?>(
        json['dataHoraEmbarque'],
      ),
      dataHoraValidade: serializer.fromJson<DateTime?>(
        json['dataHoraValidade'],
      ),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'idBpeCabecalho': serializer.toJson<int?>(idBpeCabecalho),
      'codigoLocalidadeOrigem': serializer.toJson<String?>(
        codigoLocalidadeOrigem,
      ),
      'descricaoLocalidadeOrigem': serializer.toJson<String?>(
        descricaoLocalidadeOrigem,
      ),
      'codigoLocalidadeDestino': serializer.toJson<String?>(
        codigoLocalidadeDestino,
      ),
      'descricaoLocalidadeDestino': serializer.toJson<String?>(
        descricaoLocalidadeDestino,
      ),
      'dataHoraEmbarque': serializer.toJson<DateTime?>(dataHoraEmbarque),
      'dataHoraValidade': serializer.toJson<DateTime?>(dataHoraValidade),
    };
  }

  BpePassagem copyWith({
    Value<int?> id = const Value.absent(),
    Value<int?> idBpeCabecalho = const Value.absent(),
    Value<String?> codigoLocalidadeOrigem = const Value.absent(),
    Value<String?> descricaoLocalidadeOrigem = const Value.absent(),
    Value<String?> codigoLocalidadeDestino = const Value.absent(),
    Value<String?> descricaoLocalidadeDestino = const Value.absent(),
    Value<DateTime?> dataHoraEmbarque = const Value.absent(),
    Value<DateTime?> dataHoraValidade = const Value.absent(),
  }) => BpePassagem(
    id: id.present ? id.value : this.id,
    idBpeCabecalho:
        idBpeCabecalho.present ? idBpeCabecalho.value : this.idBpeCabecalho,
    codigoLocalidadeOrigem:
        codigoLocalidadeOrigem.present
            ? codigoLocalidadeOrigem.value
            : this.codigoLocalidadeOrigem,
    descricaoLocalidadeOrigem:
        descricaoLocalidadeOrigem.present
            ? descricaoLocalidadeOrigem.value
            : this.descricaoLocalidadeOrigem,
    codigoLocalidadeDestino:
        codigoLocalidadeDestino.present
            ? codigoLocalidadeDestino.value
            : this.codigoLocalidadeDestino,
    descricaoLocalidadeDestino:
        descricaoLocalidadeDestino.present
            ? descricaoLocalidadeDestino.value
            : this.descricaoLocalidadeDestino,
    dataHoraEmbarque:
        dataHoraEmbarque.present
            ? dataHoraEmbarque.value
            : this.dataHoraEmbarque,
    dataHoraValidade:
        dataHoraValidade.present
            ? dataHoraValidade.value
            : this.dataHoraValidade,
  );
  BpePassagem copyWithCompanion(BpePassagemsCompanion data) {
    return BpePassagem(
      id: data.id.present ? data.id.value : this.id,
      idBpeCabecalho:
          data.idBpeCabecalho.present
              ? data.idBpeCabecalho.value
              : this.idBpeCabecalho,
      codigoLocalidadeOrigem:
          data.codigoLocalidadeOrigem.present
              ? data.codigoLocalidadeOrigem.value
              : this.codigoLocalidadeOrigem,
      descricaoLocalidadeOrigem:
          data.descricaoLocalidadeOrigem.present
              ? data.descricaoLocalidadeOrigem.value
              : this.descricaoLocalidadeOrigem,
      codigoLocalidadeDestino:
          data.codigoLocalidadeDestino.present
              ? data.codigoLocalidadeDestino.value
              : this.codigoLocalidadeDestino,
      descricaoLocalidadeDestino:
          data.descricaoLocalidadeDestino.present
              ? data.descricaoLocalidadeDestino.value
              : this.descricaoLocalidadeDestino,
      dataHoraEmbarque:
          data.dataHoraEmbarque.present
              ? data.dataHoraEmbarque.value
              : this.dataHoraEmbarque,
      dataHoraValidade:
          data.dataHoraValidade.present
              ? data.dataHoraValidade.value
              : this.dataHoraValidade,
    );
  }

  @override
  String toString() {
    return (StringBuffer('BpePassagem(')
          ..write('id: $id, ')
          ..write('idBpeCabecalho: $idBpeCabecalho, ')
          ..write('codigoLocalidadeOrigem: $codigoLocalidadeOrigem, ')
          ..write('descricaoLocalidadeOrigem: $descricaoLocalidadeOrigem, ')
          ..write('codigoLocalidadeDestino: $codigoLocalidadeDestino, ')
          ..write('descricaoLocalidadeDestino: $descricaoLocalidadeDestino, ')
          ..write('dataHoraEmbarque: $dataHoraEmbarque, ')
          ..write('dataHoraValidade: $dataHoraValidade')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(
    id,
    idBpeCabecalho,
    codigoLocalidadeOrigem,
    descricaoLocalidadeOrigem,
    codigoLocalidadeDestino,
    descricaoLocalidadeDestino,
    dataHoraEmbarque,
    dataHoraValidade,
  );
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is BpePassagem &&
          other.id == this.id &&
          other.idBpeCabecalho == this.idBpeCabecalho &&
          other.codigoLocalidadeOrigem == this.codigoLocalidadeOrigem &&
          other.descricaoLocalidadeOrigem == this.descricaoLocalidadeOrigem &&
          other.codigoLocalidadeDestino == this.codigoLocalidadeDestino &&
          other.descricaoLocalidadeDestino == this.descricaoLocalidadeDestino &&
          other.dataHoraEmbarque == this.dataHoraEmbarque &&
          other.dataHoraValidade == this.dataHoraValidade);
}

class BpePassagemsCompanion extends UpdateCompanion<BpePassagem> {
  final Value<int?> id;
  final Value<int?> idBpeCabecalho;
  final Value<String?> codigoLocalidadeOrigem;
  final Value<String?> descricaoLocalidadeOrigem;
  final Value<String?> codigoLocalidadeDestino;
  final Value<String?> descricaoLocalidadeDestino;
  final Value<DateTime?> dataHoraEmbarque;
  final Value<DateTime?> dataHoraValidade;
  const BpePassagemsCompanion({
    this.id = const Value.absent(),
    this.idBpeCabecalho = const Value.absent(),
    this.codigoLocalidadeOrigem = const Value.absent(),
    this.descricaoLocalidadeOrigem = const Value.absent(),
    this.codigoLocalidadeDestino = const Value.absent(),
    this.descricaoLocalidadeDestino = const Value.absent(),
    this.dataHoraEmbarque = const Value.absent(),
    this.dataHoraValidade = const Value.absent(),
  });
  BpePassagemsCompanion.insert({
    this.id = const Value.absent(),
    this.idBpeCabecalho = const Value.absent(),
    this.codigoLocalidadeOrigem = const Value.absent(),
    this.descricaoLocalidadeOrigem = const Value.absent(),
    this.codigoLocalidadeDestino = const Value.absent(),
    this.descricaoLocalidadeDestino = const Value.absent(),
    this.dataHoraEmbarque = const Value.absent(),
    this.dataHoraValidade = const Value.absent(),
  });
  static Insertable<BpePassagem> custom({
    Expression<int>? id,
    Expression<int>? idBpeCabecalho,
    Expression<String>? codigoLocalidadeOrigem,
    Expression<String>? descricaoLocalidadeOrigem,
    Expression<String>? codigoLocalidadeDestino,
    Expression<String>? descricaoLocalidadeDestino,
    Expression<DateTime>? dataHoraEmbarque,
    Expression<DateTime>? dataHoraValidade,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (idBpeCabecalho != null) 'id_bpe_cabecalho': idBpeCabecalho,
      if (codigoLocalidadeOrigem != null)
        'codigo_localidade_origem': codigoLocalidadeOrigem,
      if (descricaoLocalidadeOrigem != null)
        'descricao_localidade_origem': descricaoLocalidadeOrigem,
      if (codigoLocalidadeDestino != null)
        'codigo_localidade_destino': codigoLocalidadeDestino,
      if (descricaoLocalidadeDestino != null)
        'descricao_localidade_destino': descricaoLocalidadeDestino,
      if (dataHoraEmbarque != null) 'data_hora_embarque': dataHoraEmbarque,
      if (dataHoraValidade != null) 'data_hora_validade': dataHoraValidade,
    });
  }

  BpePassagemsCompanion copyWith({
    Value<int?>? id,
    Value<int?>? idBpeCabecalho,
    Value<String?>? codigoLocalidadeOrigem,
    Value<String?>? descricaoLocalidadeOrigem,
    Value<String?>? codigoLocalidadeDestino,
    Value<String?>? descricaoLocalidadeDestino,
    Value<DateTime?>? dataHoraEmbarque,
    Value<DateTime?>? dataHoraValidade,
  }) {
    return BpePassagemsCompanion(
      id: id ?? this.id,
      idBpeCabecalho: idBpeCabecalho ?? this.idBpeCabecalho,
      codigoLocalidadeOrigem:
          codigoLocalidadeOrigem ?? this.codigoLocalidadeOrigem,
      descricaoLocalidadeOrigem:
          descricaoLocalidadeOrigem ?? this.descricaoLocalidadeOrigem,
      codigoLocalidadeDestino:
          codigoLocalidadeDestino ?? this.codigoLocalidadeDestino,
      descricaoLocalidadeDestino:
          descricaoLocalidadeDestino ?? this.descricaoLocalidadeDestino,
      dataHoraEmbarque: dataHoraEmbarque ?? this.dataHoraEmbarque,
      dataHoraValidade: dataHoraValidade ?? this.dataHoraValidade,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (idBpeCabecalho.present) {
      map['id_bpe_cabecalho'] = Variable<int>(idBpeCabecalho.value);
    }
    if (codigoLocalidadeOrigem.present) {
      map['codigo_localidade_origem'] = Variable<String>(
        codigoLocalidadeOrigem.value,
      );
    }
    if (descricaoLocalidadeOrigem.present) {
      map['descricao_localidade_origem'] = Variable<String>(
        descricaoLocalidadeOrigem.value,
      );
    }
    if (codigoLocalidadeDestino.present) {
      map['codigo_localidade_destino'] = Variable<String>(
        codigoLocalidadeDestino.value,
      );
    }
    if (descricaoLocalidadeDestino.present) {
      map['descricao_localidade_destino'] = Variable<String>(
        descricaoLocalidadeDestino.value,
      );
    }
    if (dataHoraEmbarque.present) {
      map['data_hora_embarque'] = Variable<DateTime>(dataHoraEmbarque.value);
    }
    if (dataHoraValidade.present) {
      map['data_hora_validade'] = Variable<DateTime>(dataHoraValidade.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('BpePassagemsCompanion(')
          ..write('id: $id, ')
          ..write('idBpeCabecalho: $idBpeCabecalho, ')
          ..write('codigoLocalidadeOrigem: $codigoLocalidadeOrigem, ')
          ..write('descricaoLocalidadeOrigem: $descricaoLocalidadeOrigem, ')
          ..write('codigoLocalidadeDestino: $codigoLocalidadeDestino, ')
          ..write('descricaoLocalidadeDestino: $descricaoLocalidadeDestino, ')
          ..write('dataHoraEmbarque: $dataHoraEmbarque, ')
          ..write('dataHoraValidade: $dataHoraValidade')
          ..write(')'))
        .toString();
  }
}

class $BpeCabecalhosTable extends BpeCabecalhos
    with TableInfo<$BpeCabecalhosTable, BpeCabecalho> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $BpeCabecalhosTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
    'id',
    aliasedName,
    true,
    type: DriftSqlType.int,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _ufEmitenteMeta = const VerificationMeta(
    'ufEmitente',
  );
  @override
  late final GeneratedColumn<String> ufEmitente = GeneratedColumn<String>(
    'uf_emitente',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 2,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _ambienteMeta = const VerificationMeta(
    'ambiente',
  );
  @override
  late final GeneratedColumn<String> ambiente = GeneratedColumn<String>(
    'ambiente',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 1,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _modeloMeta = const VerificationMeta('modelo');
  @override
  late final GeneratedColumn<String> modelo = GeneratedColumn<String>(
    'modelo',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 2,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _serieMeta = const VerificationMeta('serie');
  @override
  late final GeneratedColumn<String> serie = GeneratedColumn<String>(
    'serie',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 3,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _numeroMeta = const VerificationMeta('numero');
  @override
  late final GeneratedColumn<String> numero = GeneratedColumn<String>(
    'numero',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 9,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _codigoNumericoMeta = const VerificationMeta(
    'codigoNumerico',
  );
  @override
  late final GeneratedColumn<String> codigoNumerico = GeneratedColumn<String>(
    'codigo_numerico',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 8,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _chaveAcessoMeta = const VerificationMeta(
    'chaveAcesso',
  );
  @override
  late final GeneratedColumn<String> chaveAcesso = GeneratedColumn<String>(
    'chave_acesso',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 44,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _digitoChaveAcessoMeta = const VerificationMeta(
    'digitoChaveAcesso',
  );
  @override
  late final GeneratedColumn<String> digitoChaveAcesso =
      GeneratedColumn<String>(
        'digito_chave_acesso',
        aliasedName,
        true,
        additionalChecks: GeneratedColumn.checkTextLength(
          minTextLength: 0,
          maxTextLength: 1,
        ),
        type: DriftSqlType.string,
        requiredDuringInsert: false,
      );
  static const VerificationMeta _modalMeta = const VerificationMeta('modal');
  @override
  late final GeneratedColumn<String> modal = GeneratedColumn<String>(
    'modal',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 2,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _dataHoraEmissaoMeta = const VerificationMeta(
    'dataHoraEmissao',
  );
  @override
  late final GeneratedColumn<DateTime> dataHoraEmissao =
      GeneratedColumn<DateTime>(
        'data_hora_emissao',
        aliasedName,
        true,
        type: DriftSqlType.dateTime,
        requiredDuringInsert: false,
      );
  static const VerificationMeta _tipoEmissaoMeta = const VerificationMeta(
    'tipoEmissao',
  );
  @override
  late final GeneratedColumn<String> tipoEmissao = GeneratedColumn<String>(
    'tipo_emissao',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 1,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _versaoProcessoEmissaoMeta =
      const VerificationMeta('versaoProcessoEmissao');
  @override
  late final GeneratedColumn<String> versaoProcessoEmissao =
      GeneratedColumn<String>(
        'versao_processo_emissao',
        aliasedName,
        true,
        additionalChecks: GeneratedColumn.checkTextLength(
          minTextLength: 0,
          maxTextLength: 20,
        ),
        type: DriftSqlType.string,
        requiredDuringInsert: false,
      );
  static const VerificationMeta _tipoBpeMeta = const VerificationMeta(
    'tipoBpe',
  );
  @override
  late final GeneratedColumn<String> tipoBpe = GeneratedColumn<String>(
    'tipo_bpe',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 1,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _consumidorPresencaMeta =
      const VerificationMeta('consumidorPresenca');
  @override
  late final GeneratedColumn<String> consumidorPresenca =
      GeneratedColumn<String>(
        'consumidor_presenca',
        aliasedName,
        true,
        additionalChecks: GeneratedColumn.checkTextLength(
          minTextLength: 0,
          maxTextLength: 1,
        ),
        type: DriftSqlType.string,
        requiredDuringInsert: false,
      );
  static const VerificationMeta _ufInicioViagemMeta = const VerificationMeta(
    'ufInicioViagem',
  );
  @override
  late final GeneratedColumn<String> ufInicioViagem = GeneratedColumn<String>(
    'uf_inicio_viagem',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 2,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _codigoMunicipioInicioViagemMeta =
      const VerificationMeta('codigoMunicipioInicioViagem');
  @override
  late final GeneratedColumn<int> codigoMunicipioInicioViagem =
      GeneratedColumn<int>(
        'codigo_municipio_inicio_viagem',
        aliasedName,
        true,
        type: DriftSqlType.int,
        requiredDuringInsert: false,
      );
  static const VerificationMeta _ufFimViagemMeta = const VerificationMeta(
    'ufFimViagem',
  );
  @override
  late final GeneratedColumn<String> ufFimViagem = GeneratedColumn<String>(
    'uf_fim_viagem',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 2,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _codigoMunicipioFimViagemMeta =
      const VerificationMeta('codigoMunicipioFimViagem');
  @override
  late final GeneratedColumn<int> codigoMunicipioFimViagem =
      GeneratedColumn<int>(
        'codigo_municipio_fim_viagem',
        aliasedName,
        true,
        type: DriftSqlType.int,
        requiredDuringInsert: false,
      );
  static const VerificationMeta _valorBilheteMeta = const VerificationMeta(
    'valorBilhete',
  );
  @override
  late final GeneratedColumn<double> valorBilhete = GeneratedColumn<double>(
    'valor_bilhete',
    aliasedName,
    true,
    type: DriftSqlType.double,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _valorDescontoMeta = const VerificationMeta(
    'valorDesconto',
  );
  @override
  late final GeneratedColumn<double> valorDesconto = GeneratedColumn<double>(
    'valor_desconto',
    aliasedName,
    true,
    type: DriftSqlType.double,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _valorPagoMeta = const VerificationMeta(
    'valorPago',
  );
  @override
  late final GeneratedColumn<double> valorPago = GeneratedColumn<double>(
    'valor_pago',
    aliasedName,
    true,
    type: DriftSqlType.double,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _valorTrocoMeta = const VerificationMeta(
    'valorTroco',
  );
  @override
  late final GeneratedColumn<double> valorTroco = GeneratedColumn<double>(
    'valor_troco',
    aliasedName,
    true,
    type: DriftSqlType.double,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _tipoDescontoMeta = const VerificationMeta(
    'tipoDesconto',
  );
  @override
  late final GeneratedColumn<String> tipoDesconto = GeneratedColumn<String>(
    'tipo_desconto',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 1,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _descontoDescricaoMeta = const VerificationMeta(
    'descontoDescricao',
  );
  @override
  late final GeneratedColumn<String> descontoDescricao =
      GeneratedColumn<String>(
        'desconto_descricao',
        aliasedName,
        true,
        additionalChecks: GeneratedColumn.checkTextLength(
          minTextLength: 0,
          maxTextLength: 100,
        ),
        type: DriftSqlType.string,
        requiredDuringInsert: false,
      );
  static const VerificationMeta _descontoConcedidoOutrosMeta =
      const VerificationMeta('descontoConcedidoOutros');
  @override
  late final GeneratedColumn<String> descontoConcedidoOutros =
      GeneratedColumn<String>(
        'desconto_concedido_outros',
        aliasedName,
        true,
        additionalChecks: GeneratedColumn.checkTextLength(
          minTextLength: 0,
          maxTextLength: 20,
        ),
        type: DriftSqlType.string,
        requiredDuringInsert: false,
      );
  static const VerificationMeta _formaPagamentoMeta = const VerificationMeta(
    'formaPagamento',
  );
  @override
  late final GeneratedColumn<String> formaPagamento = GeneratedColumn<String>(
    'forma_pagamento',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 1,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _formaPagamentoOutrosMeta =
      const VerificationMeta('formaPagamentoOutros');
  @override
  late final GeneratedColumn<String> formaPagamentoOutros =
      GeneratedColumn<String>(
        'forma_pagamento_outros',
        aliasedName,
        true,
        additionalChecks: GeneratedColumn.checkTextLength(
          minTextLength: 0,
          maxTextLength: 100,
        ),
        type: DriftSqlType.string,
        requiredDuringInsert: false,
      );
  static const VerificationMeta _formaPagamentoDocumentoMeta =
      const VerificationMeta('formaPagamentoDocumento');
  @override
  late final GeneratedColumn<String> formaPagamentoDocumento =
      GeneratedColumn<String>(
        'forma_pagamento_documento',
        aliasedName,
        true,
        additionalChecks: GeneratedColumn.checkTextLength(
          minTextLength: 0,
          maxTextLength: 20,
        ),
        type: DriftSqlType.string,
        requiredDuringInsert: false,
      );
  static const VerificationMeta _cstMeta = const VerificationMeta('cst');
  @override
  late final GeneratedColumn<String> cst = GeneratedColumn<String>(
    'cst',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 2,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _baseCalculoIcmsMeta = const VerificationMeta(
    'baseCalculoIcms',
  );
  @override
  late final GeneratedColumn<double> baseCalculoIcms = GeneratedColumn<double>(
    'base_calculo_icms',
    aliasedName,
    true,
    type: DriftSqlType.double,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _aliquotaIcmsMeta = const VerificationMeta(
    'aliquotaIcms',
  );
  @override
  late final GeneratedColumn<double> aliquotaIcms = GeneratedColumn<double>(
    'aliquota_icms',
    aliasedName,
    true,
    type: DriftSqlType.double,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _valorIcmsMeta = const VerificationMeta(
    'valorIcms',
  );
  @override
  late final GeneratedColumn<double> valorIcms = GeneratedColumn<double>(
    'valor_icms',
    aliasedName,
    true,
    type: DriftSqlType.double,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _percentualReducaoBcIcmsMeta =
      const VerificationMeta('percentualReducaoBcIcms');
  @override
  late final GeneratedColumn<double> percentualReducaoBcIcms =
      GeneratedColumn<double>(
        'percentual_reducao_bc_icms',
        aliasedName,
        true,
        type: DriftSqlType.double,
        requiredDuringInsert: false,
      );
  static const VerificationMeta _informacoesAddFiscoMeta =
      const VerificationMeta('informacoesAddFisco');
  @override
  late final GeneratedColumn<String> informacoesAddFisco =
      GeneratedColumn<String>(
        'informacoes_add_fisco',
        aliasedName,
        true,
        type: DriftSqlType.string,
        requiredDuringInsert: false,
      );
  @override
  List<GeneratedColumn> get $columns => [
    id,
    ufEmitente,
    ambiente,
    modelo,
    serie,
    numero,
    codigoNumerico,
    chaveAcesso,
    digitoChaveAcesso,
    modal,
    dataHoraEmissao,
    tipoEmissao,
    versaoProcessoEmissao,
    tipoBpe,
    consumidorPresenca,
    ufInicioViagem,
    codigoMunicipioInicioViagem,
    ufFimViagem,
    codigoMunicipioFimViagem,
    valorBilhete,
    valorDesconto,
    valorPago,
    valorTroco,
    tipoDesconto,
    descontoDescricao,
    descontoConcedidoOutros,
    formaPagamento,
    formaPagamentoOutros,
    formaPagamentoDocumento,
    cst,
    baseCalculoIcms,
    aliquotaIcms,
    valorIcms,
    percentualReducaoBcIcms,
    informacoesAddFisco,
  ];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'bpe_cabecalho';
  @override
  VerificationContext validateIntegrity(
    Insertable<BpeCabecalho> instance, {
    bool isInserting = false,
  }) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('uf_emitente')) {
      context.handle(
        _ufEmitenteMeta,
        ufEmitente.isAcceptableOrUnknown(data['uf_emitente']!, _ufEmitenteMeta),
      );
    }
    if (data.containsKey('ambiente')) {
      context.handle(
        _ambienteMeta,
        ambiente.isAcceptableOrUnknown(data['ambiente']!, _ambienteMeta),
      );
    }
    if (data.containsKey('modelo')) {
      context.handle(
        _modeloMeta,
        modelo.isAcceptableOrUnknown(data['modelo']!, _modeloMeta),
      );
    }
    if (data.containsKey('serie')) {
      context.handle(
        _serieMeta,
        serie.isAcceptableOrUnknown(data['serie']!, _serieMeta),
      );
    }
    if (data.containsKey('numero')) {
      context.handle(
        _numeroMeta,
        numero.isAcceptableOrUnknown(data['numero']!, _numeroMeta),
      );
    }
    if (data.containsKey('codigo_numerico')) {
      context.handle(
        _codigoNumericoMeta,
        codigoNumerico.isAcceptableOrUnknown(
          data['codigo_numerico']!,
          _codigoNumericoMeta,
        ),
      );
    }
    if (data.containsKey('chave_acesso')) {
      context.handle(
        _chaveAcessoMeta,
        chaveAcesso.isAcceptableOrUnknown(
          data['chave_acesso']!,
          _chaveAcessoMeta,
        ),
      );
    }
    if (data.containsKey('digito_chave_acesso')) {
      context.handle(
        _digitoChaveAcessoMeta,
        digitoChaveAcesso.isAcceptableOrUnknown(
          data['digito_chave_acesso']!,
          _digitoChaveAcessoMeta,
        ),
      );
    }
    if (data.containsKey('modal')) {
      context.handle(
        _modalMeta,
        modal.isAcceptableOrUnknown(data['modal']!, _modalMeta),
      );
    }
    if (data.containsKey('data_hora_emissao')) {
      context.handle(
        _dataHoraEmissaoMeta,
        dataHoraEmissao.isAcceptableOrUnknown(
          data['data_hora_emissao']!,
          _dataHoraEmissaoMeta,
        ),
      );
    }
    if (data.containsKey('tipo_emissao')) {
      context.handle(
        _tipoEmissaoMeta,
        tipoEmissao.isAcceptableOrUnknown(
          data['tipo_emissao']!,
          _tipoEmissaoMeta,
        ),
      );
    }
    if (data.containsKey('versao_processo_emissao')) {
      context.handle(
        _versaoProcessoEmissaoMeta,
        versaoProcessoEmissao.isAcceptableOrUnknown(
          data['versao_processo_emissao']!,
          _versaoProcessoEmissaoMeta,
        ),
      );
    }
    if (data.containsKey('tipo_bpe')) {
      context.handle(
        _tipoBpeMeta,
        tipoBpe.isAcceptableOrUnknown(data['tipo_bpe']!, _tipoBpeMeta),
      );
    }
    if (data.containsKey('consumidor_presenca')) {
      context.handle(
        _consumidorPresencaMeta,
        consumidorPresenca.isAcceptableOrUnknown(
          data['consumidor_presenca']!,
          _consumidorPresencaMeta,
        ),
      );
    }
    if (data.containsKey('uf_inicio_viagem')) {
      context.handle(
        _ufInicioViagemMeta,
        ufInicioViagem.isAcceptableOrUnknown(
          data['uf_inicio_viagem']!,
          _ufInicioViagemMeta,
        ),
      );
    }
    if (data.containsKey('codigo_municipio_inicio_viagem')) {
      context.handle(
        _codigoMunicipioInicioViagemMeta,
        codigoMunicipioInicioViagem.isAcceptableOrUnknown(
          data['codigo_municipio_inicio_viagem']!,
          _codigoMunicipioInicioViagemMeta,
        ),
      );
    }
    if (data.containsKey('uf_fim_viagem')) {
      context.handle(
        _ufFimViagemMeta,
        ufFimViagem.isAcceptableOrUnknown(
          data['uf_fim_viagem']!,
          _ufFimViagemMeta,
        ),
      );
    }
    if (data.containsKey('codigo_municipio_fim_viagem')) {
      context.handle(
        _codigoMunicipioFimViagemMeta,
        codigoMunicipioFimViagem.isAcceptableOrUnknown(
          data['codigo_municipio_fim_viagem']!,
          _codigoMunicipioFimViagemMeta,
        ),
      );
    }
    if (data.containsKey('valor_bilhete')) {
      context.handle(
        _valorBilheteMeta,
        valorBilhete.isAcceptableOrUnknown(
          data['valor_bilhete']!,
          _valorBilheteMeta,
        ),
      );
    }
    if (data.containsKey('valor_desconto')) {
      context.handle(
        _valorDescontoMeta,
        valorDesconto.isAcceptableOrUnknown(
          data['valor_desconto']!,
          _valorDescontoMeta,
        ),
      );
    }
    if (data.containsKey('valor_pago')) {
      context.handle(
        _valorPagoMeta,
        valorPago.isAcceptableOrUnknown(data['valor_pago']!, _valorPagoMeta),
      );
    }
    if (data.containsKey('valor_troco')) {
      context.handle(
        _valorTrocoMeta,
        valorTroco.isAcceptableOrUnknown(data['valor_troco']!, _valorTrocoMeta),
      );
    }
    if (data.containsKey('tipo_desconto')) {
      context.handle(
        _tipoDescontoMeta,
        tipoDesconto.isAcceptableOrUnknown(
          data['tipo_desconto']!,
          _tipoDescontoMeta,
        ),
      );
    }
    if (data.containsKey('desconto_descricao')) {
      context.handle(
        _descontoDescricaoMeta,
        descontoDescricao.isAcceptableOrUnknown(
          data['desconto_descricao']!,
          _descontoDescricaoMeta,
        ),
      );
    }
    if (data.containsKey('desconto_concedido_outros')) {
      context.handle(
        _descontoConcedidoOutrosMeta,
        descontoConcedidoOutros.isAcceptableOrUnknown(
          data['desconto_concedido_outros']!,
          _descontoConcedidoOutrosMeta,
        ),
      );
    }
    if (data.containsKey('forma_pagamento')) {
      context.handle(
        _formaPagamentoMeta,
        formaPagamento.isAcceptableOrUnknown(
          data['forma_pagamento']!,
          _formaPagamentoMeta,
        ),
      );
    }
    if (data.containsKey('forma_pagamento_outros')) {
      context.handle(
        _formaPagamentoOutrosMeta,
        formaPagamentoOutros.isAcceptableOrUnknown(
          data['forma_pagamento_outros']!,
          _formaPagamentoOutrosMeta,
        ),
      );
    }
    if (data.containsKey('forma_pagamento_documento')) {
      context.handle(
        _formaPagamentoDocumentoMeta,
        formaPagamentoDocumento.isAcceptableOrUnknown(
          data['forma_pagamento_documento']!,
          _formaPagamentoDocumentoMeta,
        ),
      );
    }
    if (data.containsKey('cst')) {
      context.handle(
        _cstMeta,
        cst.isAcceptableOrUnknown(data['cst']!, _cstMeta),
      );
    }
    if (data.containsKey('base_calculo_icms')) {
      context.handle(
        _baseCalculoIcmsMeta,
        baseCalculoIcms.isAcceptableOrUnknown(
          data['base_calculo_icms']!,
          _baseCalculoIcmsMeta,
        ),
      );
    }
    if (data.containsKey('aliquota_icms')) {
      context.handle(
        _aliquotaIcmsMeta,
        aliquotaIcms.isAcceptableOrUnknown(
          data['aliquota_icms']!,
          _aliquotaIcmsMeta,
        ),
      );
    }
    if (data.containsKey('valor_icms')) {
      context.handle(
        _valorIcmsMeta,
        valorIcms.isAcceptableOrUnknown(data['valor_icms']!, _valorIcmsMeta),
      );
    }
    if (data.containsKey('percentual_reducao_bc_icms')) {
      context.handle(
        _percentualReducaoBcIcmsMeta,
        percentualReducaoBcIcms.isAcceptableOrUnknown(
          data['percentual_reducao_bc_icms']!,
          _percentualReducaoBcIcmsMeta,
        ),
      );
    }
    if (data.containsKey('informacoes_add_fisco')) {
      context.handle(
        _informacoesAddFiscoMeta,
        informacoesAddFisco.isAcceptableOrUnknown(
          data['informacoes_add_fisco']!,
          _informacoesAddFiscoMeta,
        ),
      );
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  BpeCabecalho map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return BpeCabecalho(
      id: attachedDatabase.typeMapping.read(
        DriftSqlType.int,
        data['${effectivePrefix}id'],
      ),
      ufEmitente: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}uf_emitente'],
      ),
      ambiente: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}ambiente'],
      ),
      modelo: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}modelo'],
      ),
      serie: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}serie'],
      ),
      numero: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}numero'],
      ),
      codigoNumerico: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}codigo_numerico'],
      ),
      chaveAcesso: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}chave_acesso'],
      ),
      digitoChaveAcesso: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}digito_chave_acesso'],
      ),
      modal: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}modal'],
      ),
      dataHoraEmissao: attachedDatabase.typeMapping.read(
        DriftSqlType.dateTime,
        data['${effectivePrefix}data_hora_emissao'],
      ),
      tipoEmissao: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}tipo_emissao'],
      ),
      versaoProcessoEmissao: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}versao_processo_emissao'],
      ),
      tipoBpe: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}tipo_bpe'],
      ),
      consumidorPresenca: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}consumidor_presenca'],
      ),
      ufInicioViagem: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}uf_inicio_viagem'],
      ),
      codigoMunicipioInicioViagem: attachedDatabase.typeMapping.read(
        DriftSqlType.int,
        data['${effectivePrefix}codigo_municipio_inicio_viagem'],
      ),
      ufFimViagem: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}uf_fim_viagem'],
      ),
      codigoMunicipioFimViagem: attachedDatabase.typeMapping.read(
        DriftSqlType.int,
        data['${effectivePrefix}codigo_municipio_fim_viagem'],
      ),
      valorBilhete: attachedDatabase.typeMapping.read(
        DriftSqlType.double,
        data['${effectivePrefix}valor_bilhete'],
      ),
      valorDesconto: attachedDatabase.typeMapping.read(
        DriftSqlType.double,
        data['${effectivePrefix}valor_desconto'],
      ),
      valorPago: attachedDatabase.typeMapping.read(
        DriftSqlType.double,
        data['${effectivePrefix}valor_pago'],
      ),
      valorTroco: attachedDatabase.typeMapping.read(
        DriftSqlType.double,
        data['${effectivePrefix}valor_troco'],
      ),
      tipoDesconto: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}tipo_desconto'],
      ),
      descontoDescricao: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}desconto_descricao'],
      ),
      descontoConcedidoOutros: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}desconto_concedido_outros'],
      ),
      formaPagamento: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}forma_pagamento'],
      ),
      formaPagamentoOutros: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}forma_pagamento_outros'],
      ),
      formaPagamentoDocumento: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}forma_pagamento_documento'],
      ),
      cst: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}cst'],
      ),
      baseCalculoIcms: attachedDatabase.typeMapping.read(
        DriftSqlType.double,
        data['${effectivePrefix}base_calculo_icms'],
      ),
      aliquotaIcms: attachedDatabase.typeMapping.read(
        DriftSqlType.double,
        data['${effectivePrefix}aliquota_icms'],
      ),
      valorIcms: attachedDatabase.typeMapping.read(
        DriftSqlType.double,
        data['${effectivePrefix}valor_icms'],
      ),
      percentualReducaoBcIcms: attachedDatabase.typeMapping.read(
        DriftSqlType.double,
        data['${effectivePrefix}percentual_reducao_bc_icms'],
      ),
      informacoesAddFisco: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}informacoes_add_fisco'],
      ),
    );
  }

  @override
  $BpeCabecalhosTable createAlias(String alias) {
    return $BpeCabecalhosTable(attachedDatabase, alias);
  }
}

class BpeCabecalho extends DataClass implements Insertable<BpeCabecalho> {
  final int? id;
  final String? ufEmitente;
  final String? ambiente;
  final String? modelo;
  final String? serie;
  final String? numero;
  final String? codigoNumerico;
  final String? chaveAcesso;
  final String? digitoChaveAcesso;
  final String? modal;
  final DateTime? dataHoraEmissao;
  final String? tipoEmissao;
  final String? versaoProcessoEmissao;
  final String? tipoBpe;
  final String? consumidorPresenca;
  final String? ufInicioViagem;
  final int? codigoMunicipioInicioViagem;
  final String? ufFimViagem;
  final int? codigoMunicipioFimViagem;
  final double? valorBilhete;
  final double? valorDesconto;
  final double? valorPago;
  final double? valorTroco;
  final String? tipoDesconto;
  final String? descontoDescricao;
  final String? descontoConcedidoOutros;
  final String? formaPagamento;
  final String? formaPagamentoOutros;
  final String? formaPagamentoDocumento;
  final String? cst;
  final double? baseCalculoIcms;
  final double? aliquotaIcms;
  final double? valorIcms;
  final double? percentualReducaoBcIcms;
  final String? informacoesAddFisco;
  const BpeCabecalho({
    this.id,
    this.ufEmitente,
    this.ambiente,
    this.modelo,
    this.serie,
    this.numero,
    this.codigoNumerico,
    this.chaveAcesso,
    this.digitoChaveAcesso,
    this.modal,
    this.dataHoraEmissao,
    this.tipoEmissao,
    this.versaoProcessoEmissao,
    this.tipoBpe,
    this.consumidorPresenca,
    this.ufInicioViagem,
    this.codigoMunicipioInicioViagem,
    this.ufFimViagem,
    this.codigoMunicipioFimViagem,
    this.valorBilhete,
    this.valorDesconto,
    this.valorPago,
    this.valorTroco,
    this.tipoDesconto,
    this.descontoDescricao,
    this.descontoConcedidoOutros,
    this.formaPagamento,
    this.formaPagamentoOutros,
    this.formaPagamentoDocumento,
    this.cst,
    this.baseCalculoIcms,
    this.aliquotaIcms,
    this.valorIcms,
    this.percentualReducaoBcIcms,
    this.informacoesAddFisco,
  });
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || ufEmitente != null) {
      map['uf_emitente'] = Variable<String>(ufEmitente);
    }
    if (!nullToAbsent || ambiente != null) {
      map['ambiente'] = Variable<String>(ambiente);
    }
    if (!nullToAbsent || modelo != null) {
      map['modelo'] = Variable<String>(modelo);
    }
    if (!nullToAbsent || serie != null) {
      map['serie'] = Variable<String>(serie);
    }
    if (!nullToAbsent || numero != null) {
      map['numero'] = Variable<String>(numero);
    }
    if (!nullToAbsent || codigoNumerico != null) {
      map['codigo_numerico'] = Variable<String>(codigoNumerico);
    }
    if (!nullToAbsent || chaveAcesso != null) {
      map['chave_acesso'] = Variable<String>(chaveAcesso);
    }
    if (!nullToAbsent || digitoChaveAcesso != null) {
      map['digito_chave_acesso'] = Variable<String>(digitoChaveAcesso);
    }
    if (!nullToAbsent || modal != null) {
      map['modal'] = Variable<String>(modal);
    }
    if (!nullToAbsent || dataHoraEmissao != null) {
      map['data_hora_emissao'] = Variable<DateTime>(dataHoraEmissao);
    }
    if (!nullToAbsent || tipoEmissao != null) {
      map['tipo_emissao'] = Variable<String>(tipoEmissao);
    }
    if (!nullToAbsent || versaoProcessoEmissao != null) {
      map['versao_processo_emissao'] = Variable<String>(versaoProcessoEmissao);
    }
    if (!nullToAbsent || tipoBpe != null) {
      map['tipo_bpe'] = Variable<String>(tipoBpe);
    }
    if (!nullToAbsent || consumidorPresenca != null) {
      map['consumidor_presenca'] = Variable<String>(consumidorPresenca);
    }
    if (!nullToAbsent || ufInicioViagem != null) {
      map['uf_inicio_viagem'] = Variable<String>(ufInicioViagem);
    }
    if (!nullToAbsent || codigoMunicipioInicioViagem != null) {
      map['codigo_municipio_inicio_viagem'] = Variable<int>(
        codigoMunicipioInicioViagem,
      );
    }
    if (!nullToAbsent || ufFimViagem != null) {
      map['uf_fim_viagem'] = Variable<String>(ufFimViagem);
    }
    if (!nullToAbsent || codigoMunicipioFimViagem != null) {
      map['codigo_municipio_fim_viagem'] = Variable<int>(
        codigoMunicipioFimViagem,
      );
    }
    if (!nullToAbsent || valorBilhete != null) {
      map['valor_bilhete'] = Variable<double>(valorBilhete);
    }
    if (!nullToAbsent || valorDesconto != null) {
      map['valor_desconto'] = Variable<double>(valorDesconto);
    }
    if (!nullToAbsent || valorPago != null) {
      map['valor_pago'] = Variable<double>(valorPago);
    }
    if (!nullToAbsent || valorTroco != null) {
      map['valor_troco'] = Variable<double>(valorTroco);
    }
    if (!nullToAbsent || tipoDesconto != null) {
      map['tipo_desconto'] = Variable<String>(tipoDesconto);
    }
    if (!nullToAbsent || descontoDescricao != null) {
      map['desconto_descricao'] = Variable<String>(descontoDescricao);
    }
    if (!nullToAbsent || descontoConcedidoOutros != null) {
      map['desconto_concedido_outros'] = Variable<String>(
        descontoConcedidoOutros,
      );
    }
    if (!nullToAbsent || formaPagamento != null) {
      map['forma_pagamento'] = Variable<String>(formaPagamento);
    }
    if (!nullToAbsent || formaPagamentoOutros != null) {
      map['forma_pagamento_outros'] = Variable<String>(formaPagamentoOutros);
    }
    if (!nullToAbsent || formaPagamentoDocumento != null) {
      map['forma_pagamento_documento'] = Variable<String>(
        formaPagamentoDocumento,
      );
    }
    if (!nullToAbsent || cst != null) {
      map['cst'] = Variable<String>(cst);
    }
    if (!nullToAbsent || baseCalculoIcms != null) {
      map['base_calculo_icms'] = Variable<double>(baseCalculoIcms);
    }
    if (!nullToAbsent || aliquotaIcms != null) {
      map['aliquota_icms'] = Variable<double>(aliquotaIcms);
    }
    if (!nullToAbsent || valorIcms != null) {
      map['valor_icms'] = Variable<double>(valorIcms);
    }
    if (!nullToAbsent || percentualReducaoBcIcms != null) {
      map['percentual_reducao_bc_icms'] = Variable<double>(
        percentualReducaoBcIcms,
      );
    }
    if (!nullToAbsent || informacoesAddFisco != null) {
      map['informacoes_add_fisco'] = Variable<String>(informacoesAddFisco);
    }
    return map;
  }

  factory BpeCabecalho.fromJson(
    Map<String, dynamic> json, {
    ValueSerializer? serializer,
  }) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return BpeCabecalho(
      id: serializer.fromJson<int?>(json['id']),
      ufEmitente: serializer.fromJson<String?>(json['ufEmitente']),
      ambiente: serializer.fromJson<String?>(json['ambiente']),
      modelo: serializer.fromJson<String?>(json['modelo']),
      serie: serializer.fromJson<String?>(json['serie']),
      numero: serializer.fromJson<String?>(json['numero']),
      codigoNumerico: serializer.fromJson<String?>(json['codigoNumerico']),
      chaveAcesso: serializer.fromJson<String?>(json['chaveAcesso']),
      digitoChaveAcesso: serializer.fromJson<String?>(
        json['digitoChaveAcesso'],
      ),
      modal: serializer.fromJson<String?>(json['modal']),
      dataHoraEmissao: serializer.fromJson<DateTime?>(json['dataHoraEmissao']),
      tipoEmissao: serializer.fromJson<String?>(json['tipoEmissao']),
      versaoProcessoEmissao: serializer.fromJson<String?>(
        json['versaoProcessoEmissao'],
      ),
      tipoBpe: serializer.fromJson<String?>(json['tipoBpe']),
      consumidorPresenca: serializer.fromJson<String?>(
        json['consumidorPresenca'],
      ),
      ufInicioViagem: serializer.fromJson<String?>(json['ufInicioViagem']),
      codigoMunicipioInicioViagem: serializer.fromJson<int?>(
        json['codigoMunicipioInicioViagem'],
      ),
      ufFimViagem: serializer.fromJson<String?>(json['ufFimViagem']),
      codigoMunicipioFimViagem: serializer.fromJson<int?>(
        json['codigoMunicipioFimViagem'],
      ),
      valorBilhete: serializer.fromJson<double?>(json['valorBilhete']),
      valorDesconto: serializer.fromJson<double?>(json['valorDesconto']),
      valorPago: serializer.fromJson<double?>(json['valorPago']),
      valorTroco: serializer.fromJson<double?>(json['valorTroco']),
      tipoDesconto: serializer.fromJson<String?>(json['tipoDesconto']),
      descontoDescricao: serializer.fromJson<String?>(
        json['descontoDescricao'],
      ),
      descontoConcedidoOutros: serializer.fromJson<String?>(
        json['descontoConcedidoOutros'],
      ),
      formaPagamento: serializer.fromJson<String?>(json['formaPagamento']),
      formaPagamentoOutros: serializer.fromJson<String?>(
        json['formaPagamentoOutros'],
      ),
      formaPagamentoDocumento: serializer.fromJson<String?>(
        json['formaPagamentoDocumento'],
      ),
      cst: serializer.fromJson<String?>(json['cst']),
      baseCalculoIcms: serializer.fromJson<double?>(json['baseCalculoIcms']),
      aliquotaIcms: serializer.fromJson<double?>(json['aliquotaIcms']),
      valorIcms: serializer.fromJson<double?>(json['valorIcms']),
      percentualReducaoBcIcms: serializer.fromJson<double?>(
        json['percentualReducaoBcIcms'],
      ),
      informacoesAddFisco: serializer.fromJson<String?>(
        json['informacoesAddFisco'],
      ),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'ufEmitente': serializer.toJson<String?>(ufEmitente),
      'ambiente': serializer.toJson<String?>(ambiente),
      'modelo': serializer.toJson<String?>(modelo),
      'serie': serializer.toJson<String?>(serie),
      'numero': serializer.toJson<String?>(numero),
      'codigoNumerico': serializer.toJson<String?>(codigoNumerico),
      'chaveAcesso': serializer.toJson<String?>(chaveAcesso),
      'digitoChaveAcesso': serializer.toJson<String?>(digitoChaveAcesso),
      'modal': serializer.toJson<String?>(modal),
      'dataHoraEmissao': serializer.toJson<DateTime?>(dataHoraEmissao),
      'tipoEmissao': serializer.toJson<String?>(tipoEmissao),
      'versaoProcessoEmissao': serializer.toJson<String?>(
        versaoProcessoEmissao,
      ),
      'tipoBpe': serializer.toJson<String?>(tipoBpe),
      'consumidorPresenca': serializer.toJson<String?>(consumidorPresenca),
      'ufInicioViagem': serializer.toJson<String?>(ufInicioViagem),
      'codigoMunicipioInicioViagem': serializer.toJson<int?>(
        codigoMunicipioInicioViagem,
      ),
      'ufFimViagem': serializer.toJson<String?>(ufFimViagem),
      'codigoMunicipioFimViagem': serializer.toJson<int?>(
        codigoMunicipioFimViagem,
      ),
      'valorBilhete': serializer.toJson<double?>(valorBilhete),
      'valorDesconto': serializer.toJson<double?>(valorDesconto),
      'valorPago': serializer.toJson<double?>(valorPago),
      'valorTroco': serializer.toJson<double?>(valorTroco),
      'tipoDesconto': serializer.toJson<String?>(tipoDesconto),
      'descontoDescricao': serializer.toJson<String?>(descontoDescricao),
      'descontoConcedidoOutros': serializer.toJson<String?>(
        descontoConcedidoOutros,
      ),
      'formaPagamento': serializer.toJson<String?>(formaPagamento),
      'formaPagamentoOutros': serializer.toJson<String?>(formaPagamentoOutros),
      'formaPagamentoDocumento': serializer.toJson<String?>(
        formaPagamentoDocumento,
      ),
      'cst': serializer.toJson<String?>(cst),
      'baseCalculoIcms': serializer.toJson<double?>(baseCalculoIcms),
      'aliquotaIcms': serializer.toJson<double?>(aliquotaIcms),
      'valorIcms': serializer.toJson<double?>(valorIcms),
      'percentualReducaoBcIcms': serializer.toJson<double?>(
        percentualReducaoBcIcms,
      ),
      'informacoesAddFisco': serializer.toJson<String?>(informacoesAddFisco),
    };
  }

  BpeCabecalho copyWith({
    Value<int?> id = const Value.absent(),
    Value<String?> ufEmitente = const Value.absent(),
    Value<String?> ambiente = const Value.absent(),
    Value<String?> modelo = const Value.absent(),
    Value<String?> serie = const Value.absent(),
    Value<String?> numero = const Value.absent(),
    Value<String?> codigoNumerico = const Value.absent(),
    Value<String?> chaveAcesso = const Value.absent(),
    Value<String?> digitoChaveAcesso = const Value.absent(),
    Value<String?> modal = const Value.absent(),
    Value<DateTime?> dataHoraEmissao = const Value.absent(),
    Value<String?> tipoEmissao = const Value.absent(),
    Value<String?> versaoProcessoEmissao = const Value.absent(),
    Value<String?> tipoBpe = const Value.absent(),
    Value<String?> consumidorPresenca = const Value.absent(),
    Value<String?> ufInicioViagem = const Value.absent(),
    Value<int?> codigoMunicipioInicioViagem = const Value.absent(),
    Value<String?> ufFimViagem = const Value.absent(),
    Value<int?> codigoMunicipioFimViagem = const Value.absent(),
    Value<double?> valorBilhete = const Value.absent(),
    Value<double?> valorDesconto = const Value.absent(),
    Value<double?> valorPago = const Value.absent(),
    Value<double?> valorTroco = const Value.absent(),
    Value<String?> tipoDesconto = const Value.absent(),
    Value<String?> descontoDescricao = const Value.absent(),
    Value<String?> descontoConcedidoOutros = const Value.absent(),
    Value<String?> formaPagamento = const Value.absent(),
    Value<String?> formaPagamentoOutros = const Value.absent(),
    Value<String?> formaPagamentoDocumento = const Value.absent(),
    Value<String?> cst = const Value.absent(),
    Value<double?> baseCalculoIcms = const Value.absent(),
    Value<double?> aliquotaIcms = const Value.absent(),
    Value<double?> valorIcms = const Value.absent(),
    Value<double?> percentualReducaoBcIcms = const Value.absent(),
    Value<String?> informacoesAddFisco = const Value.absent(),
  }) => BpeCabecalho(
    id: id.present ? id.value : this.id,
    ufEmitente: ufEmitente.present ? ufEmitente.value : this.ufEmitente,
    ambiente: ambiente.present ? ambiente.value : this.ambiente,
    modelo: modelo.present ? modelo.value : this.modelo,
    serie: serie.present ? serie.value : this.serie,
    numero: numero.present ? numero.value : this.numero,
    codigoNumerico:
        codigoNumerico.present ? codigoNumerico.value : this.codigoNumerico,
    chaveAcesso: chaveAcesso.present ? chaveAcesso.value : this.chaveAcesso,
    digitoChaveAcesso:
        digitoChaveAcesso.present
            ? digitoChaveAcesso.value
            : this.digitoChaveAcesso,
    modal: modal.present ? modal.value : this.modal,
    dataHoraEmissao:
        dataHoraEmissao.present ? dataHoraEmissao.value : this.dataHoraEmissao,
    tipoEmissao: tipoEmissao.present ? tipoEmissao.value : this.tipoEmissao,
    versaoProcessoEmissao:
        versaoProcessoEmissao.present
            ? versaoProcessoEmissao.value
            : this.versaoProcessoEmissao,
    tipoBpe: tipoBpe.present ? tipoBpe.value : this.tipoBpe,
    consumidorPresenca:
        consumidorPresenca.present
            ? consumidorPresenca.value
            : this.consumidorPresenca,
    ufInicioViagem:
        ufInicioViagem.present ? ufInicioViagem.value : this.ufInicioViagem,
    codigoMunicipioInicioViagem:
        codigoMunicipioInicioViagem.present
            ? codigoMunicipioInicioViagem.value
            : this.codigoMunicipioInicioViagem,
    ufFimViagem: ufFimViagem.present ? ufFimViagem.value : this.ufFimViagem,
    codigoMunicipioFimViagem:
        codigoMunicipioFimViagem.present
            ? codigoMunicipioFimViagem.value
            : this.codigoMunicipioFimViagem,
    valorBilhete: valorBilhete.present ? valorBilhete.value : this.valorBilhete,
    valorDesconto:
        valorDesconto.present ? valorDesconto.value : this.valorDesconto,
    valorPago: valorPago.present ? valorPago.value : this.valorPago,
    valorTroco: valorTroco.present ? valorTroco.value : this.valorTroco,
    tipoDesconto: tipoDesconto.present ? tipoDesconto.value : this.tipoDesconto,
    descontoDescricao:
        descontoDescricao.present
            ? descontoDescricao.value
            : this.descontoDescricao,
    descontoConcedidoOutros:
        descontoConcedidoOutros.present
            ? descontoConcedidoOutros.value
            : this.descontoConcedidoOutros,
    formaPagamento:
        formaPagamento.present ? formaPagamento.value : this.formaPagamento,
    formaPagamentoOutros:
        formaPagamentoOutros.present
            ? formaPagamentoOutros.value
            : this.formaPagamentoOutros,
    formaPagamentoDocumento:
        formaPagamentoDocumento.present
            ? formaPagamentoDocumento.value
            : this.formaPagamentoDocumento,
    cst: cst.present ? cst.value : this.cst,
    baseCalculoIcms:
        baseCalculoIcms.present ? baseCalculoIcms.value : this.baseCalculoIcms,
    aliquotaIcms: aliquotaIcms.present ? aliquotaIcms.value : this.aliquotaIcms,
    valorIcms: valorIcms.present ? valorIcms.value : this.valorIcms,
    percentualReducaoBcIcms:
        percentualReducaoBcIcms.present
            ? percentualReducaoBcIcms.value
            : this.percentualReducaoBcIcms,
    informacoesAddFisco:
        informacoesAddFisco.present
            ? informacoesAddFisco.value
            : this.informacoesAddFisco,
  );
  BpeCabecalho copyWithCompanion(BpeCabecalhosCompanion data) {
    return BpeCabecalho(
      id: data.id.present ? data.id.value : this.id,
      ufEmitente:
          data.ufEmitente.present ? data.ufEmitente.value : this.ufEmitente,
      ambiente: data.ambiente.present ? data.ambiente.value : this.ambiente,
      modelo: data.modelo.present ? data.modelo.value : this.modelo,
      serie: data.serie.present ? data.serie.value : this.serie,
      numero: data.numero.present ? data.numero.value : this.numero,
      codigoNumerico:
          data.codigoNumerico.present
              ? data.codigoNumerico.value
              : this.codigoNumerico,
      chaveAcesso:
          data.chaveAcesso.present ? data.chaveAcesso.value : this.chaveAcesso,
      digitoChaveAcesso:
          data.digitoChaveAcesso.present
              ? data.digitoChaveAcesso.value
              : this.digitoChaveAcesso,
      modal: data.modal.present ? data.modal.value : this.modal,
      dataHoraEmissao:
          data.dataHoraEmissao.present
              ? data.dataHoraEmissao.value
              : this.dataHoraEmissao,
      tipoEmissao:
          data.tipoEmissao.present ? data.tipoEmissao.value : this.tipoEmissao,
      versaoProcessoEmissao:
          data.versaoProcessoEmissao.present
              ? data.versaoProcessoEmissao.value
              : this.versaoProcessoEmissao,
      tipoBpe: data.tipoBpe.present ? data.tipoBpe.value : this.tipoBpe,
      consumidorPresenca:
          data.consumidorPresenca.present
              ? data.consumidorPresenca.value
              : this.consumidorPresenca,
      ufInicioViagem:
          data.ufInicioViagem.present
              ? data.ufInicioViagem.value
              : this.ufInicioViagem,
      codigoMunicipioInicioViagem:
          data.codigoMunicipioInicioViagem.present
              ? data.codigoMunicipioInicioViagem.value
              : this.codigoMunicipioInicioViagem,
      ufFimViagem:
          data.ufFimViagem.present ? data.ufFimViagem.value : this.ufFimViagem,
      codigoMunicipioFimViagem:
          data.codigoMunicipioFimViagem.present
              ? data.codigoMunicipioFimViagem.value
              : this.codigoMunicipioFimViagem,
      valorBilhete:
          data.valorBilhete.present
              ? data.valorBilhete.value
              : this.valorBilhete,
      valorDesconto:
          data.valorDesconto.present
              ? data.valorDesconto.value
              : this.valorDesconto,
      valorPago: data.valorPago.present ? data.valorPago.value : this.valorPago,
      valorTroco:
          data.valorTroco.present ? data.valorTroco.value : this.valorTroco,
      tipoDesconto:
          data.tipoDesconto.present
              ? data.tipoDesconto.value
              : this.tipoDesconto,
      descontoDescricao:
          data.descontoDescricao.present
              ? data.descontoDescricao.value
              : this.descontoDescricao,
      descontoConcedidoOutros:
          data.descontoConcedidoOutros.present
              ? data.descontoConcedidoOutros.value
              : this.descontoConcedidoOutros,
      formaPagamento:
          data.formaPagamento.present
              ? data.formaPagamento.value
              : this.formaPagamento,
      formaPagamentoOutros:
          data.formaPagamentoOutros.present
              ? data.formaPagamentoOutros.value
              : this.formaPagamentoOutros,
      formaPagamentoDocumento:
          data.formaPagamentoDocumento.present
              ? data.formaPagamentoDocumento.value
              : this.formaPagamentoDocumento,
      cst: data.cst.present ? data.cst.value : this.cst,
      baseCalculoIcms:
          data.baseCalculoIcms.present
              ? data.baseCalculoIcms.value
              : this.baseCalculoIcms,
      aliquotaIcms:
          data.aliquotaIcms.present
              ? data.aliquotaIcms.value
              : this.aliquotaIcms,
      valorIcms: data.valorIcms.present ? data.valorIcms.value : this.valorIcms,
      percentualReducaoBcIcms:
          data.percentualReducaoBcIcms.present
              ? data.percentualReducaoBcIcms.value
              : this.percentualReducaoBcIcms,
      informacoesAddFisco:
          data.informacoesAddFisco.present
              ? data.informacoesAddFisco.value
              : this.informacoesAddFisco,
    );
  }

  @override
  String toString() {
    return (StringBuffer('BpeCabecalho(')
          ..write('id: $id, ')
          ..write('ufEmitente: $ufEmitente, ')
          ..write('ambiente: $ambiente, ')
          ..write('modelo: $modelo, ')
          ..write('serie: $serie, ')
          ..write('numero: $numero, ')
          ..write('codigoNumerico: $codigoNumerico, ')
          ..write('chaveAcesso: $chaveAcesso, ')
          ..write('digitoChaveAcesso: $digitoChaveAcesso, ')
          ..write('modal: $modal, ')
          ..write('dataHoraEmissao: $dataHoraEmissao, ')
          ..write('tipoEmissao: $tipoEmissao, ')
          ..write('versaoProcessoEmissao: $versaoProcessoEmissao, ')
          ..write('tipoBpe: $tipoBpe, ')
          ..write('consumidorPresenca: $consumidorPresenca, ')
          ..write('ufInicioViagem: $ufInicioViagem, ')
          ..write('codigoMunicipioInicioViagem: $codigoMunicipioInicioViagem, ')
          ..write('ufFimViagem: $ufFimViagem, ')
          ..write('codigoMunicipioFimViagem: $codigoMunicipioFimViagem, ')
          ..write('valorBilhete: $valorBilhete, ')
          ..write('valorDesconto: $valorDesconto, ')
          ..write('valorPago: $valorPago, ')
          ..write('valorTroco: $valorTroco, ')
          ..write('tipoDesconto: $tipoDesconto, ')
          ..write('descontoDescricao: $descontoDescricao, ')
          ..write('descontoConcedidoOutros: $descontoConcedidoOutros, ')
          ..write('formaPagamento: $formaPagamento, ')
          ..write('formaPagamentoOutros: $formaPagamentoOutros, ')
          ..write('formaPagamentoDocumento: $formaPagamentoDocumento, ')
          ..write('cst: $cst, ')
          ..write('baseCalculoIcms: $baseCalculoIcms, ')
          ..write('aliquotaIcms: $aliquotaIcms, ')
          ..write('valorIcms: $valorIcms, ')
          ..write('percentualReducaoBcIcms: $percentualReducaoBcIcms, ')
          ..write('informacoesAddFisco: $informacoesAddFisco')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hashAll([
    id,
    ufEmitente,
    ambiente,
    modelo,
    serie,
    numero,
    codigoNumerico,
    chaveAcesso,
    digitoChaveAcesso,
    modal,
    dataHoraEmissao,
    tipoEmissao,
    versaoProcessoEmissao,
    tipoBpe,
    consumidorPresenca,
    ufInicioViagem,
    codigoMunicipioInicioViagem,
    ufFimViagem,
    codigoMunicipioFimViagem,
    valorBilhete,
    valorDesconto,
    valorPago,
    valorTroco,
    tipoDesconto,
    descontoDescricao,
    descontoConcedidoOutros,
    formaPagamento,
    formaPagamentoOutros,
    formaPagamentoDocumento,
    cst,
    baseCalculoIcms,
    aliquotaIcms,
    valorIcms,
    percentualReducaoBcIcms,
    informacoesAddFisco,
  ]);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is BpeCabecalho &&
          other.id == this.id &&
          other.ufEmitente == this.ufEmitente &&
          other.ambiente == this.ambiente &&
          other.modelo == this.modelo &&
          other.serie == this.serie &&
          other.numero == this.numero &&
          other.codigoNumerico == this.codigoNumerico &&
          other.chaveAcesso == this.chaveAcesso &&
          other.digitoChaveAcesso == this.digitoChaveAcesso &&
          other.modal == this.modal &&
          other.dataHoraEmissao == this.dataHoraEmissao &&
          other.tipoEmissao == this.tipoEmissao &&
          other.versaoProcessoEmissao == this.versaoProcessoEmissao &&
          other.tipoBpe == this.tipoBpe &&
          other.consumidorPresenca == this.consumidorPresenca &&
          other.ufInicioViagem == this.ufInicioViagem &&
          other.codigoMunicipioInicioViagem ==
              this.codigoMunicipioInicioViagem &&
          other.ufFimViagem == this.ufFimViagem &&
          other.codigoMunicipioFimViagem == this.codigoMunicipioFimViagem &&
          other.valorBilhete == this.valorBilhete &&
          other.valorDesconto == this.valorDesconto &&
          other.valorPago == this.valorPago &&
          other.valorTroco == this.valorTroco &&
          other.tipoDesconto == this.tipoDesconto &&
          other.descontoDescricao == this.descontoDescricao &&
          other.descontoConcedidoOutros == this.descontoConcedidoOutros &&
          other.formaPagamento == this.formaPagamento &&
          other.formaPagamentoOutros == this.formaPagamentoOutros &&
          other.formaPagamentoDocumento == this.formaPagamentoDocumento &&
          other.cst == this.cst &&
          other.baseCalculoIcms == this.baseCalculoIcms &&
          other.aliquotaIcms == this.aliquotaIcms &&
          other.valorIcms == this.valorIcms &&
          other.percentualReducaoBcIcms == this.percentualReducaoBcIcms &&
          other.informacoesAddFisco == this.informacoesAddFisco);
}

class BpeCabecalhosCompanion extends UpdateCompanion<BpeCabecalho> {
  final Value<int?> id;
  final Value<String?> ufEmitente;
  final Value<String?> ambiente;
  final Value<String?> modelo;
  final Value<String?> serie;
  final Value<String?> numero;
  final Value<String?> codigoNumerico;
  final Value<String?> chaveAcesso;
  final Value<String?> digitoChaveAcesso;
  final Value<String?> modal;
  final Value<DateTime?> dataHoraEmissao;
  final Value<String?> tipoEmissao;
  final Value<String?> versaoProcessoEmissao;
  final Value<String?> tipoBpe;
  final Value<String?> consumidorPresenca;
  final Value<String?> ufInicioViagem;
  final Value<int?> codigoMunicipioInicioViagem;
  final Value<String?> ufFimViagem;
  final Value<int?> codigoMunicipioFimViagem;
  final Value<double?> valorBilhete;
  final Value<double?> valorDesconto;
  final Value<double?> valorPago;
  final Value<double?> valorTroco;
  final Value<String?> tipoDesconto;
  final Value<String?> descontoDescricao;
  final Value<String?> descontoConcedidoOutros;
  final Value<String?> formaPagamento;
  final Value<String?> formaPagamentoOutros;
  final Value<String?> formaPagamentoDocumento;
  final Value<String?> cst;
  final Value<double?> baseCalculoIcms;
  final Value<double?> aliquotaIcms;
  final Value<double?> valorIcms;
  final Value<double?> percentualReducaoBcIcms;
  final Value<String?> informacoesAddFisco;
  const BpeCabecalhosCompanion({
    this.id = const Value.absent(),
    this.ufEmitente = const Value.absent(),
    this.ambiente = const Value.absent(),
    this.modelo = const Value.absent(),
    this.serie = const Value.absent(),
    this.numero = const Value.absent(),
    this.codigoNumerico = const Value.absent(),
    this.chaveAcesso = const Value.absent(),
    this.digitoChaveAcesso = const Value.absent(),
    this.modal = const Value.absent(),
    this.dataHoraEmissao = const Value.absent(),
    this.tipoEmissao = const Value.absent(),
    this.versaoProcessoEmissao = const Value.absent(),
    this.tipoBpe = const Value.absent(),
    this.consumidorPresenca = const Value.absent(),
    this.ufInicioViagem = const Value.absent(),
    this.codigoMunicipioInicioViagem = const Value.absent(),
    this.ufFimViagem = const Value.absent(),
    this.codigoMunicipioFimViagem = const Value.absent(),
    this.valorBilhete = const Value.absent(),
    this.valorDesconto = const Value.absent(),
    this.valorPago = const Value.absent(),
    this.valorTroco = const Value.absent(),
    this.tipoDesconto = const Value.absent(),
    this.descontoDescricao = const Value.absent(),
    this.descontoConcedidoOutros = const Value.absent(),
    this.formaPagamento = const Value.absent(),
    this.formaPagamentoOutros = const Value.absent(),
    this.formaPagamentoDocumento = const Value.absent(),
    this.cst = const Value.absent(),
    this.baseCalculoIcms = const Value.absent(),
    this.aliquotaIcms = const Value.absent(),
    this.valorIcms = const Value.absent(),
    this.percentualReducaoBcIcms = const Value.absent(),
    this.informacoesAddFisco = const Value.absent(),
  });
  BpeCabecalhosCompanion.insert({
    this.id = const Value.absent(),
    this.ufEmitente = const Value.absent(),
    this.ambiente = const Value.absent(),
    this.modelo = const Value.absent(),
    this.serie = const Value.absent(),
    this.numero = const Value.absent(),
    this.codigoNumerico = const Value.absent(),
    this.chaveAcesso = const Value.absent(),
    this.digitoChaveAcesso = const Value.absent(),
    this.modal = const Value.absent(),
    this.dataHoraEmissao = const Value.absent(),
    this.tipoEmissao = const Value.absent(),
    this.versaoProcessoEmissao = const Value.absent(),
    this.tipoBpe = const Value.absent(),
    this.consumidorPresenca = const Value.absent(),
    this.ufInicioViagem = const Value.absent(),
    this.codigoMunicipioInicioViagem = const Value.absent(),
    this.ufFimViagem = const Value.absent(),
    this.codigoMunicipioFimViagem = const Value.absent(),
    this.valorBilhete = const Value.absent(),
    this.valorDesconto = const Value.absent(),
    this.valorPago = const Value.absent(),
    this.valorTroco = const Value.absent(),
    this.tipoDesconto = const Value.absent(),
    this.descontoDescricao = const Value.absent(),
    this.descontoConcedidoOutros = const Value.absent(),
    this.formaPagamento = const Value.absent(),
    this.formaPagamentoOutros = const Value.absent(),
    this.formaPagamentoDocumento = const Value.absent(),
    this.cst = const Value.absent(),
    this.baseCalculoIcms = const Value.absent(),
    this.aliquotaIcms = const Value.absent(),
    this.valorIcms = const Value.absent(),
    this.percentualReducaoBcIcms = const Value.absent(),
    this.informacoesAddFisco = const Value.absent(),
  });
  static Insertable<BpeCabecalho> custom({
    Expression<int>? id,
    Expression<String>? ufEmitente,
    Expression<String>? ambiente,
    Expression<String>? modelo,
    Expression<String>? serie,
    Expression<String>? numero,
    Expression<String>? codigoNumerico,
    Expression<String>? chaveAcesso,
    Expression<String>? digitoChaveAcesso,
    Expression<String>? modal,
    Expression<DateTime>? dataHoraEmissao,
    Expression<String>? tipoEmissao,
    Expression<String>? versaoProcessoEmissao,
    Expression<String>? tipoBpe,
    Expression<String>? consumidorPresenca,
    Expression<String>? ufInicioViagem,
    Expression<int>? codigoMunicipioInicioViagem,
    Expression<String>? ufFimViagem,
    Expression<int>? codigoMunicipioFimViagem,
    Expression<double>? valorBilhete,
    Expression<double>? valorDesconto,
    Expression<double>? valorPago,
    Expression<double>? valorTroco,
    Expression<String>? tipoDesconto,
    Expression<String>? descontoDescricao,
    Expression<String>? descontoConcedidoOutros,
    Expression<String>? formaPagamento,
    Expression<String>? formaPagamentoOutros,
    Expression<String>? formaPagamentoDocumento,
    Expression<String>? cst,
    Expression<double>? baseCalculoIcms,
    Expression<double>? aliquotaIcms,
    Expression<double>? valorIcms,
    Expression<double>? percentualReducaoBcIcms,
    Expression<String>? informacoesAddFisco,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (ufEmitente != null) 'uf_emitente': ufEmitente,
      if (ambiente != null) 'ambiente': ambiente,
      if (modelo != null) 'modelo': modelo,
      if (serie != null) 'serie': serie,
      if (numero != null) 'numero': numero,
      if (codigoNumerico != null) 'codigo_numerico': codigoNumerico,
      if (chaveAcesso != null) 'chave_acesso': chaveAcesso,
      if (digitoChaveAcesso != null) 'digito_chave_acesso': digitoChaveAcesso,
      if (modal != null) 'modal': modal,
      if (dataHoraEmissao != null) 'data_hora_emissao': dataHoraEmissao,
      if (tipoEmissao != null) 'tipo_emissao': tipoEmissao,
      if (versaoProcessoEmissao != null)
        'versao_processo_emissao': versaoProcessoEmissao,
      if (tipoBpe != null) 'tipo_bpe': tipoBpe,
      if (consumidorPresenca != null) 'consumidor_presenca': consumidorPresenca,
      if (ufInicioViagem != null) 'uf_inicio_viagem': ufInicioViagem,
      if (codigoMunicipioInicioViagem != null)
        'codigo_municipio_inicio_viagem': codigoMunicipioInicioViagem,
      if (ufFimViagem != null) 'uf_fim_viagem': ufFimViagem,
      if (codigoMunicipioFimViagem != null)
        'codigo_municipio_fim_viagem': codigoMunicipioFimViagem,
      if (valorBilhete != null) 'valor_bilhete': valorBilhete,
      if (valorDesconto != null) 'valor_desconto': valorDesconto,
      if (valorPago != null) 'valor_pago': valorPago,
      if (valorTroco != null) 'valor_troco': valorTroco,
      if (tipoDesconto != null) 'tipo_desconto': tipoDesconto,
      if (descontoDescricao != null) 'desconto_descricao': descontoDescricao,
      if (descontoConcedidoOutros != null)
        'desconto_concedido_outros': descontoConcedidoOutros,
      if (formaPagamento != null) 'forma_pagamento': formaPagamento,
      if (formaPagamentoOutros != null)
        'forma_pagamento_outros': formaPagamentoOutros,
      if (formaPagamentoDocumento != null)
        'forma_pagamento_documento': formaPagamentoDocumento,
      if (cst != null) 'cst': cst,
      if (baseCalculoIcms != null) 'base_calculo_icms': baseCalculoIcms,
      if (aliquotaIcms != null) 'aliquota_icms': aliquotaIcms,
      if (valorIcms != null) 'valor_icms': valorIcms,
      if (percentualReducaoBcIcms != null)
        'percentual_reducao_bc_icms': percentualReducaoBcIcms,
      if (informacoesAddFisco != null)
        'informacoes_add_fisco': informacoesAddFisco,
    });
  }

  BpeCabecalhosCompanion copyWith({
    Value<int?>? id,
    Value<String?>? ufEmitente,
    Value<String?>? ambiente,
    Value<String?>? modelo,
    Value<String?>? serie,
    Value<String?>? numero,
    Value<String?>? codigoNumerico,
    Value<String?>? chaveAcesso,
    Value<String?>? digitoChaveAcesso,
    Value<String?>? modal,
    Value<DateTime?>? dataHoraEmissao,
    Value<String?>? tipoEmissao,
    Value<String?>? versaoProcessoEmissao,
    Value<String?>? tipoBpe,
    Value<String?>? consumidorPresenca,
    Value<String?>? ufInicioViagem,
    Value<int?>? codigoMunicipioInicioViagem,
    Value<String?>? ufFimViagem,
    Value<int?>? codigoMunicipioFimViagem,
    Value<double?>? valorBilhete,
    Value<double?>? valorDesconto,
    Value<double?>? valorPago,
    Value<double?>? valorTroco,
    Value<String?>? tipoDesconto,
    Value<String?>? descontoDescricao,
    Value<String?>? descontoConcedidoOutros,
    Value<String?>? formaPagamento,
    Value<String?>? formaPagamentoOutros,
    Value<String?>? formaPagamentoDocumento,
    Value<String?>? cst,
    Value<double?>? baseCalculoIcms,
    Value<double?>? aliquotaIcms,
    Value<double?>? valorIcms,
    Value<double?>? percentualReducaoBcIcms,
    Value<String?>? informacoesAddFisco,
  }) {
    return BpeCabecalhosCompanion(
      id: id ?? this.id,
      ufEmitente: ufEmitente ?? this.ufEmitente,
      ambiente: ambiente ?? this.ambiente,
      modelo: modelo ?? this.modelo,
      serie: serie ?? this.serie,
      numero: numero ?? this.numero,
      codigoNumerico: codigoNumerico ?? this.codigoNumerico,
      chaveAcesso: chaveAcesso ?? this.chaveAcesso,
      digitoChaveAcesso: digitoChaveAcesso ?? this.digitoChaveAcesso,
      modal: modal ?? this.modal,
      dataHoraEmissao: dataHoraEmissao ?? this.dataHoraEmissao,
      tipoEmissao: tipoEmissao ?? this.tipoEmissao,
      versaoProcessoEmissao:
          versaoProcessoEmissao ?? this.versaoProcessoEmissao,
      tipoBpe: tipoBpe ?? this.tipoBpe,
      consumidorPresenca: consumidorPresenca ?? this.consumidorPresenca,
      ufInicioViagem: ufInicioViagem ?? this.ufInicioViagem,
      codigoMunicipioInicioViagem:
          codigoMunicipioInicioViagem ?? this.codigoMunicipioInicioViagem,
      ufFimViagem: ufFimViagem ?? this.ufFimViagem,
      codigoMunicipioFimViagem:
          codigoMunicipioFimViagem ?? this.codigoMunicipioFimViagem,
      valorBilhete: valorBilhete ?? this.valorBilhete,
      valorDesconto: valorDesconto ?? this.valorDesconto,
      valorPago: valorPago ?? this.valorPago,
      valorTroco: valorTroco ?? this.valorTroco,
      tipoDesconto: tipoDesconto ?? this.tipoDesconto,
      descontoDescricao: descontoDescricao ?? this.descontoDescricao,
      descontoConcedidoOutros:
          descontoConcedidoOutros ?? this.descontoConcedidoOutros,
      formaPagamento: formaPagamento ?? this.formaPagamento,
      formaPagamentoOutros: formaPagamentoOutros ?? this.formaPagamentoOutros,
      formaPagamentoDocumento:
          formaPagamentoDocumento ?? this.formaPagamentoDocumento,
      cst: cst ?? this.cst,
      baseCalculoIcms: baseCalculoIcms ?? this.baseCalculoIcms,
      aliquotaIcms: aliquotaIcms ?? this.aliquotaIcms,
      valorIcms: valorIcms ?? this.valorIcms,
      percentualReducaoBcIcms:
          percentualReducaoBcIcms ?? this.percentualReducaoBcIcms,
      informacoesAddFisco: informacoesAddFisco ?? this.informacoesAddFisco,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (ufEmitente.present) {
      map['uf_emitente'] = Variable<String>(ufEmitente.value);
    }
    if (ambiente.present) {
      map['ambiente'] = Variable<String>(ambiente.value);
    }
    if (modelo.present) {
      map['modelo'] = Variable<String>(modelo.value);
    }
    if (serie.present) {
      map['serie'] = Variable<String>(serie.value);
    }
    if (numero.present) {
      map['numero'] = Variable<String>(numero.value);
    }
    if (codigoNumerico.present) {
      map['codigo_numerico'] = Variable<String>(codigoNumerico.value);
    }
    if (chaveAcesso.present) {
      map['chave_acesso'] = Variable<String>(chaveAcesso.value);
    }
    if (digitoChaveAcesso.present) {
      map['digito_chave_acesso'] = Variable<String>(digitoChaveAcesso.value);
    }
    if (modal.present) {
      map['modal'] = Variable<String>(modal.value);
    }
    if (dataHoraEmissao.present) {
      map['data_hora_emissao'] = Variable<DateTime>(dataHoraEmissao.value);
    }
    if (tipoEmissao.present) {
      map['tipo_emissao'] = Variable<String>(tipoEmissao.value);
    }
    if (versaoProcessoEmissao.present) {
      map['versao_processo_emissao'] = Variable<String>(
        versaoProcessoEmissao.value,
      );
    }
    if (tipoBpe.present) {
      map['tipo_bpe'] = Variable<String>(tipoBpe.value);
    }
    if (consumidorPresenca.present) {
      map['consumidor_presenca'] = Variable<String>(consumidorPresenca.value);
    }
    if (ufInicioViagem.present) {
      map['uf_inicio_viagem'] = Variable<String>(ufInicioViagem.value);
    }
    if (codigoMunicipioInicioViagem.present) {
      map['codigo_municipio_inicio_viagem'] = Variable<int>(
        codigoMunicipioInicioViagem.value,
      );
    }
    if (ufFimViagem.present) {
      map['uf_fim_viagem'] = Variable<String>(ufFimViagem.value);
    }
    if (codigoMunicipioFimViagem.present) {
      map['codigo_municipio_fim_viagem'] = Variable<int>(
        codigoMunicipioFimViagem.value,
      );
    }
    if (valorBilhete.present) {
      map['valor_bilhete'] = Variable<double>(valorBilhete.value);
    }
    if (valorDesconto.present) {
      map['valor_desconto'] = Variable<double>(valorDesconto.value);
    }
    if (valorPago.present) {
      map['valor_pago'] = Variable<double>(valorPago.value);
    }
    if (valorTroco.present) {
      map['valor_troco'] = Variable<double>(valorTroco.value);
    }
    if (tipoDesconto.present) {
      map['tipo_desconto'] = Variable<String>(tipoDesconto.value);
    }
    if (descontoDescricao.present) {
      map['desconto_descricao'] = Variable<String>(descontoDescricao.value);
    }
    if (descontoConcedidoOutros.present) {
      map['desconto_concedido_outros'] = Variable<String>(
        descontoConcedidoOutros.value,
      );
    }
    if (formaPagamento.present) {
      map['forma_pagamento'] = Variable<String>(formaPagamento.value);
    }
    if (formaPagamentoOutros.present) {
      map['forma_pagamento_outros'] = Variable<String>(
        formaPagamentoOutros.value,
      );
    }
    if (formaPagamentoDocumento.present) {
      map['forma_pagamento_documento'] = Variable<String>(
        formaPagamentoDocumento.value,
      );
    }
    if (cst.present) {
      map['cst'] = Variable<String>(cst.value);
    }
    if (baseCalculoIcms.present) {
      map['base_calculo_icms'] = Variable<double>(baseCalculoIcms.value);
    }
    if (aliquotaIcms.present) {
      map['aliquota_icms'] = Variable<double>(aliquotaIcms.value);
    }
    if (valorIcms.present) {
      map['valor_icms'] = Variable<double>(valorIcms.value);
    }
    if (percentualReducaoBcIcms.present) {
      map['percentual_reducao_bc_icms'] = Variable<double>(
        percentualReducaoBcIcms.value,
      );
    }
    if (informacoesAddFisco.present) {
      map['informacoes_add_fisco'] = Variable<String>(
        informacoesAddFisco.value,
      );
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('BpeCabecalhosCompanion(')
          ..write('id: $id, ')
          ..write('ufEmitente: $ufEmitente, ')
          ..write('ambiente: $ambiente, ')
          ..write('modelo: $modelo, ')
          ..write('serie: $serie, ')
          ..write('numero: $numero, ')
          ..write('codigoNumerico: $codigoNumerico, ')
          ..write('chaveAcesso: $chaveAcesso, ')
          ..write('digitoChaveAcesso: $digitoChaveAcesso, ')
          ..write('modal: $modal, ')
          ..write('dataHoraEmissao: $dataHoraEmissao, ')
          ..write('tipoEmissao: $tipoEmissao, ')
          ..write('versaoProcessoEmissao: $versaoProcessoEmissao, ')
          ..write('tipoBpe: $tipoBpe, ')
          ..write('consumidorPresenca: $consumidorPresenca, ')
          ..write('ufInicioViagem: $ufInicioViagem, ')
          ..write('codigoMunicipioInicioViagem: $codigoMunicipioInicioViagem, ')
          ..write('ufFimViagem: $ufFimViagem, ')
          ..write('codigoMunicipioFimViagem: $codigoMunicipioFimViagem, ')
          ..write('valorBilhete: $valorBilhete, ')
          ..write('valorDesconto: $valorDesconto, ')
          ..write('valorPago: $valorPago, ')
          ..write('valorTroco: $valorTroco, ')
          ..write('tipoDesconto: $tipoDesconto, ')
          ..write('descontoDescricao: $descontoDescricao, ')
          ..write('descontoConcedidoOutros: $descontoConcedidoOutros, ')
          ..write('formaPagamento: $formaPagamento, ')
          ..write('formaPagamentoOutros: $formaPagamentoOutros, ')
          ..write('formaPagamentoDocumento: $formaPagamentoDocumento, ')
          ..write('cst: $cst, ')
          ..write('baseCalculoIcms: $baseCalculoIcms, ')
          ..write('aliquotaIcms: $aliquotaIcms, ')
          ..write('valorIcms: $valorIcms, ')
          ..write('percentualReducaoBcIcms: $percentualReducaoBcIcms, ')
          ..write('informacoesAddFisco: $informacoesAddFisco')
          ..write(')'))
        .toString();
  }
}

class $ViewControleAcessosTable extends ViewControleAcessos
    with TableInfo<$ViewControleAcessosTable, ViewControleAcesso> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $ViewControleAcessosTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
    'id',
    aliasedName,
    true,
    type: DriftSqlType.int,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _idPessoaMeta = const VerificationMeta(
    'idPessoa',
  );
  @override
  late final GeneratedColumn<int> idPessoa = GeneratedColumn<int>(
    'id_pessoa',
    aliasedName,
    true,
    type: DriftSqlType.int,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _pessoaNomeMeta = const VerificationMeta(
    'pessoaNome',
  );
  @override
  late final GeneratedColumn<String> pessoaNome = GeneratedColumn<String>(
    'pessoa_nome',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 450,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _idColaboradorMeta = const VerificationMeta(
    'idColaborador',
  );
  @override
  late final GeneratedColumn<int> idColaborador = GeneratedColumn<int>(
    'id_colaborador',
    aliasedName,
    true,
    type: DriftSqlType.int,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _idUsuarioMeta = const VerificationMeta(
    'idUsuario',
  );
  @override
  late final GeneratedColumn<int> idUsuario = GeneratedColumn<int>(
    'id_usuario',
    aliasedName,
    true,
    type: DriftSqlType.int,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _administradorMeta = const VerificationMeta(
    'administrador',
  );
  @override
  late final GeneratedColumn<String> administrador = GeneratedColumn<String>(
    'administrador',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 3,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _idPapelMeta = const VerificationMeta(
    'idPapel',
  );
  @override
  late final GeneratedColumn<int> idPapel = GeneratedColumn<int>(
    'id_papel',
    aliasedName,
    true,
    type: DriftSqlType.int,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _papelNomeMeta = const VerificationMeta(
    'papelNome',
  );
  @override
  late final GeneratedColumn<String> papelNome = GeneratedColumn<String>(
    'papel_nome',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 300,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _papelDescricaoMeta = const VerificationMeta(
    'papelDescricao',
  );
  @override
  late final GeneratedColumn<String> papelDescricao = GeneratedColumn<String>(
    'papel_descricao',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 750,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _idFuncaoMeta = const VerificationMeta(
    'idFuncao',
  );
  @override
  late final GeneratedColumn<int> idFuncao = GeneratedColumn<int>(
    'id_funcao',
    aliasedName,
    true,
    type: DriftSqlType.int,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _funcaoNomeMeta = const VerificationMeta(
    'funcaoNome',
  );
  @override
  late final GeneratedColumn<String> funcaoNome = GeneratedColumn<String>(
    'funcao_nome',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 300,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _funcaoDescricaoMeta = const VerificationMeta(
    'funcaoDescricao',
  );
  @override
  late final GeneratedColumn<String> funcaoDescricao = GeneratedColumn<String>(
    'funcao_descricao',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 750,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _idPapelFuncaoMeta = const VerificationMeta(
    'idPapelFuncao',
  );
  @override
  late final GeneratedColumn<int> idPapelFuncao = GeneratedColumn<int>(
    'id_papel_funcao',
    aliasedName,
    true,
    type: DriftSqlType.int,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _habilitadoMeta = const VerificationMeta(
    'habilitado',
  );
  @override
  late final GeneratedColumn<String> habilitado = GeneratedColumn<String>(
    'habilitado',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 3,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _podeInserirMeta = const VerificationMeta(
    'podeInserir',
  );
  @override
  late final GeneratedColumn<String> podeInserir = GeneratedColumn<String>(
    'pode_inserir',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 3,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _podeAlterarMeta = const VerificationMeta(
    'podeAlterar',
  );
  @override
  late final GeneratedColumn<String> podeAlterar = GeneratedColumn<String>(
    'pode_alterar',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 3,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _podeExcluirMeta = const VerificationMeta(
    'podeExcluir',
  );
  @override
  late final GeneratedColumn<String> podeExcluir = GeneratedColumn<String>(
    'pode_excluir',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 3,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  @override
  List<GeneratedColumn> get $columns => [
    id,
    idPessoa,
    pessoaNome,
    idColaborador,
    idUsuario,
    administrador,
    idPapel,
    papelNome,
    papelDescricao,
    idFuncao,
    funcaoNome,
    funcaoDescricao,
    idPapelFuncao,
    habilitado,
    podeInserir,
    podeAlterar,
    podeExcluir,
  ];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'view_controle_acesso';
  @override
  VerificationContext validateIntegrity(
    Insertable<ViewControleAcesso> instance, {
    bool isInserting = false,
  }) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('id_pessoa')) {
      context.handle(
        _idPessoaMeta,
        idPessoa.isAcceptableOrUnknown(data['id_pessoa']!, _idPessoaMeta),
      );
    }
    if (data.containsKey('pessoa_nome')) {
      context.handle(
        _pessoaNomeMeta,
        pessoaNome.isAcceptableOrUnknown(data['pessoa_nome']!, _pessoaNomeMeta),
      );
    }
    if (data.containsKey('id_colaborador')) {
      context.handle(
        _idColaboradorMeta,
        idColaborador.isAcceptableOrUnknown(
          data['id_colaborador']!,
          _idColaboradorMeta,
        ),
      );
    }
    if (data.containsKey('id_usuario')) {
      context.handle(
        _idUsuarioMeta,
        idUsuario.isAcceptableOrUnknown(data['id_usuario']!, _idUsuarioMeta),
      );
    }
    if (data.containsKey('administrador')) {
      context.handle(
        _administradorMeta,
        administrador.isAcceptableOrUnknown(
          data['administrador']!,
          _administradorMeta,
        ),
      );
    }
    if (data.containsKey('id_papel')) {
      context.handle(
        _idPapelMeta,
        idPapel.isAcceptableOrUnknown(data['id_papel']!, _idPapelMeta),
      );
    }
    if (data.containsKey('papel_nome')) {
      context.handle(
        _papelNomeMeta,
        papelNome.isAcceptableOrUnknown(data['papel_nome']!, _papelNomeMeta),
      );
    }
    if (data.containsKey('papel_descricao')) {
      context.handle(
        _papelDescricaoMeta,
        papelDescricao.isAcceptableOrUnknown(
          data['papel_descricao']!,
          _papelDescricaoMeta,
        ),
      );
    }
    if (data.containsKey('id_funcao')) {
      context.handle(
        _idFuncaoMeta,
        idFuncao.isAcceptableOrUnknown(data['id_funcao']!, _idFuncaoMeta),
      );
    }
    if (data.containsKey('funcao_nome')) {
      context.handle(
        _funcaoNomeMeta,
        funcaoNome.isAcceptableOrUnknown(data['funcao_nome']!, _funcaoNomeMeta),
      );
    }
    if (data.containsKey('funcao_descricao')) {
      context.handle(
        _funcaoDescricaoMeta,
        funcaoDescricao.isAcceptableOrUnknown(
          data['funcao_descricao']!,
          _funcaoDescricaoMeta,
        ),
      );
    }
    if (data.containsKey('id_papel_funcao')) {
      context.handle(
        _idPapelFuncaoMeta,
        idPapelFuncao.isAcceptableOrUnknown(
          data['id_papel_funcao']!,
          _idPapelFuncaoMeta,
        ),
      );
    }
    if (data.containsKey('habilitado')) {
      context.handle(
        _habilitadoMeta,
        habilitado.isAcceptableOrUnknown(data['habilitado']!, _habilitadoMeta),
      );
    }
    if (data.containsKey('pode_inserir')) {
      context.handle(
        _podeInserirMeta,
        podeInserir.isAcceptableOrUnknown(
          data['pode_inserir']!,
          _podeInserirMeta,
        ),
      );
    }
    if (data.containsKey('pode_alterar')) {
      context.handle(
        _podeAlterarMeta,
        podeAlterar.isAcceptableOrUnknown(
          data['pode_alterar']!,
          _podeAlterarMeta,
        ),
      );
    }
    if (data.containsKey('pode_excluir')) {
      context.handle(
        _podeExcluirMeta,
        podeExcluir.isAcceptableOrUnknown(
          data['pode_excluir']!,
          _podeExcluirMeta,
        ),
      );
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  ViewControleAcesso map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return ViewControleAcesso(
      id: attachedDatabase.typeMapping.read(
        DriftSqlType.int,
        data['${effectivePrefix}id'],
      ),
      idPessoa: attachedDatabase.typeMapping.read(
        DriftSqlType.int,
        data['${effectivePrefix}id_pessoa'],
      ),
      pessoaNome: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}pessoa_nome'],
      ),
      idColaborador: attachedDatabase.typeMapping.read(
        DriftSqlType.int,
        data['${effectivePrefix}id_colaborador'],
      ),
      idUsuario: attachedDatabase.typeMapping.read(
        DriftSqlType.int,
        data['${effectivePrefix}id_usuario'],
      ),
      administrador: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}administrador'],
      ),
      idPapel: attachedDatabase.typeMapping.read(
        DriftSqlType.int,
        data['${effectivePrefix}id_papel'],
      ),
      papelNome: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}papel_nome'],
      ),
      papelDescricao: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}papel_descricao'],
      ),
      idFuncao: attachedDatabase.typeMapping.read(
        DriftSqlType.int,
        data['${effectivePrefix}id_funcao'],
      ),
      funcaoNome: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}funcao_nome'],
      ),
      funcaoDescricao: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}funcao_descricao'],
      ),
      idPapelFuncao: attachedDatabase.typeMapping.read(
        DriftSqlType.int,
        data['${effectivePrefix}id_papel_funcao'],
      ),
      habilitado: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}habilitado'],
      ),
      podeInserir: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}pode_inserir'],
      ),
      podeAlterar: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}pode_alterar'],
      ),
      podeExcluir: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}pode_excluir'],
      ),
    );
  }

  @override
  $ViewControleAcessosTable createAlias(String alias) {
    return $ViewControleAcessosTable(attachedDatabase, alias);
  }
}

class ViewControleAcesso extends DataClass
    implements Insertable<ViewControleAcesso> {
  final int? id;
  final int? idPessoa;
  final String? pessoaNome;
  final int? idColaborador;
  final int? idUsuario;
  final String? administrador;
  final int? idPapel;
  final String? papelNome;
  final String? papelDescricao;
  final int? idFuncao;
  final String? funcaoNome;
  final String? funcaoDescricao;
  final int? idPapelFuncao;
  final String? habilitado;
  final String? podeInserir;
  final String? podeAlterar;
  final String? podeExcluir;
  const ViewControleAcesso({
    this.id,
    this.idPessoa,
    this.pessoaNome,
    this.idColaborador,
    this.idUsuario,
    this.administrador,
    this.idPapel,
    this.papelNome,
    this.papelDescricao,
    this.idFuncao,
    this.funcaoNome,
    this.funcaoDescricao,
    this.idPapelFuncao,
    this.habilitado,
    this.podeInserir,
    this.podeAlterar,
    this.podeExcluir,
  });
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || idPessoa != null) {
      map['id_pessoa'] = Variable<int>(idPessoa);
    }
    if (!nullToAbsent || pessoaNome != null) {
      map['pessoa_nome'] = Variable<String>(pessoaNome);
    }
    if (!nullToAbsent || idColaborador != null) {
      map['id_colaborador'] = Variable<int>(idColaborador);
    }
    if (!nullToAbsent || idUsuario != null) {
      map['id_usuario'] = Variable<int>(idUsuario);
    }
    if (!nullToAbsent || administrador != null) {
      map['administrador'] = Variable<String>(administrador);
    }
    if (!nullToAbsent || idPapel != null) {
      map['id_papel'] = Variable<int>(idPapel);
    }
    if (!nullToAbsent || papelNome != null) {
      map['papel_nome'] = Variable<String>(papelNome);
    }
    if (!nullToAbsent || papelDescricao != null) {
      map['papel_descricao'] = Variable<String>(papelDescricao);
    }
    if (!nullToAbsent || idFuncao != null) {
      map['id_funcao'] = Variable<int>(idFuncao);
    }
    if (!nullToAbsent || funcaoNome != null) {
      map['funcao_nome'] = Variable<String>(funcaoNome);
    }
    if (!nullToAbsent || funcaoDescricao != null) {
      map['funcao_descricao'] = Variable<String>(funcaoDescricao);
    }
    if (!nullToAbsent || idPapelFuncao != null) {
      map['id_papel_funcao'] = Variable<int>(idPapelFuncao);
    }
    if (!nullToAbsent || habilitado != null) {
      map['habilitado'] = Variable<String>(habilitado);
    }
    if (!nullToAbsent || podeInserir != null) {
      map['pode_inserir'] = Variable<String>(podeInserir);
    }
    if (!nullToAbsent || podeAlterar != null) {
      map['pode_alterar'] = Variable<String>(podeAlterar);
    }
    if (!nullToAbsent || podeExcluir != null) {
      map['pode_excluir'] = Variable<String>(podeExcluir);
    }
    return map;
  }

  factory ViewControleAcesso.fromJson(
    Map<String, dynamic> json, {
    ValueSerializer? serializer,
  }) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return ViewControleAcesso(
      id: serializer.fromJson<int?>(json['id']),
      idPessoa: serializer.fromJson<int?>(json['idPessoa']),
      pessoaNome: serializer.fromJson<String?>(json['pessoaNome']),
      idColaborador: serializer.fromJson<int?>(json['idColaborador']),
      idUsuario: serializer.fromJson<int?>(json['idUsuario']),
      administrador: serializer.fromJson<String?>(json['administrador']),
      idPapel: serializer.fromJson<int?>(json['idPapel']),
      papelNome: serializer.fromJson<String?>(json['papelNome']),
      papelDescricao: serializer.fromJson<String?>(json['papelDescricao']),
      idFuncao: serializer.fromJson<int?>(json['idFuncao']),
      funcaoNome: serializer.fromJson<String?>(json['funcaoNome']),
      funcaoDescricao: serializer.fromJson<String?>(json['funcaoDescricao']),
      idPapelFuncao: serializer.fromJson<int?>(json['idPapelFuncao']),
      habilitado: serializer.fromJson<String?>(json['habilitado']),
      podeInserir: serializer.fromJson<String?>(json['podeInserir']),
      podeAlterar: serializer.fromJson<String?>(json['podeAlterar']),
      podeExcluir: serializer.fromJson<String?>(json['podeExcluir']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'idPessoa': serializer.toJson<int?>(idPessoa),
      'pessoaNome': serializer.toJson<String?>(pessoaNome),
      'idColaborador': serializer.toJson<int?>(idColaborador),
      'idUsuario': serializer.toJson<int?>(idUsuario),
      'administrador': serializer.toJson<String?>(administrador),
      'idPapel': serializer.toJson<int?>(idPapel),
      'papelNome': serializer.toJson<String?>(papelNome),
      'papelDescricao': serializer.toJson<String?>(papelDescricao),
      'idFuncao': serializer.toJson<int?>(idFuncao),
      'funcaoNome': serializer.toJson<String?>(funcaoNome),
      'funcaoDescricao': serializer.toJson<String?>(funcaoDescricao),
      'idPapelFuncao': serializer.toJson<int?>(idPapelFuncao),
      'habilitado': serializer.toJson<String?>(habilitado),
      'podeInserir': serializer.toJson<String?>(podeInserir),
      'podeAlterar': serializer.toJson<String?>(podeAlterar),
      'podeExcluir': serializer.toJson<String?>(podeExcluir),
    };
  }

  ViewControleAcesso copyWith({
    Value<int?> id = const Value.absent(),
    Value<int?> idPessoa = const Value.absent(),
    Value<String?> pessoaNome = const Value.absent(),
    Value<int?> idColaborador = const Value.absent(),
    Value<int?> idUsuario = const Value.absent(),
    Value<String?> administrador = const Value.absent(),
    Value<int?> idPapel = const Value.absent(),
    Value<String?> papelNome = const Value.absent(),
    Value<String?> papelDescricao = const Value.absent(),
    Value<int?> idFuncao = const Value.absent(),
    Value<String?> funcaoNome = const Value.absent(),
    Value<String?> funcaoDescricao = const Value.absent(),
    Value<int?> idPapelFuncao = const Value.absent(),
    Value<String?> habilitado = const Value.absent(),
    Value<String?> podeInserir = const Value.absent(),
    Value<String?> podeAlterar = const Value.absent(),
    Value<String?> podeExcluir = const Value.absent(),
  }) => ViewControleAcesso(
    id: id.present ? id.value : this.id,
    idPessoa: idPessoa.present ? idPessoa.value : this.idPessoa,
    pessoaNome: pessoaNome.present ? pessoaNome.value : this.pessoaNome,
    idColaborador:
        idColaborador.present ? idColaborador.value : this.idColaborador,
    idUsuario: idUsuario.present ? idUsuario.value : this.idUsuario,
    administrador:
        administrador.present ? administrador.value : this.administrador,
    idPapel: idPapel.present ? idPapel.value : this.idPapel,
    papelNome: papelNome.present ? papelNome.value : this.papelNome,
    papelDescricao:
        papelDescricao.present ? papelDescricao.value : this.papelDescricao,
    idFuncao: idFuncao.present ? idFuncao.value : this.idFuncao,
    funcaoNome: funcaoNome.present ? funcaoNome.value : this.funcaoNome,
    funcaoDescricao:
        funcaoDescricao.present ? funcaoDescricao.value : this.funcaoDescricao,
    idPapelFuncao:
        idPapelFuncao.present ? idPapelFuncao.value : this.idPapelFuncao,
    habilitado: habilitado.present ? habilitado.value : this.habilitado,
    podeInserir: podeInserir.present ? podeInserir.value : this.podeInserir,
    podeAlterar: podeAlterar.present ? podeAlterar.value : this.podeAlterar,
    podeExcluir: podeExcluir.present ? podeExcluir.value : this.podeExcluir,
  );
  ViewControleAcesso copyWithCompanion(ViewControleAcessosCompanion data) {
    return ViewControleAcesso(
      id: data.id.present ? data.id.value : this.id,
      idPessoa: data.idPessoa.present ? data.idPessoa.value : this.idPessoa,
      pessoaNome:
          data.pessoaNome.present ? data.pessoaNome.value : this.pessoaNome,
      idColaborador:
          data.idColaborador.present
              ? data.idColaborador.value
              : this.idColaborador,
      idUsuario: data.idUsuario.present ? data.idUsuario.value : this.idUsuario,
      administrador:
          data.administrador.present
              ? data.administrador.value
              : this.administrador,
      idPapel: data.idPapel.present ? data.idPapel.value : this.idPapel,
      papelNome: data.papelNome.present ? data.papelNome.value : this.papelNome,
      papelDescricao:
          data.papelDescricao.present
              ? data.papelDescricao.value
              : this.papelDescricao,
      idFuncao: data.idFuncao.present ? data.idFuncao.value : this.idFuncao,
      funcaoNome:
          data.funcaoNome.present ? data.funcaoNome.value : this.funcaoNome,
      funcaoDescricao:
          data.funcaoDescricao.present
              ? data.funcaoDescricao.value
              : this.funcaoDescricao,
      idPapelFuncao:
          data.idPapelFuncao.present
              ? data.idPapelFuncao.value
              : this.idPapelFuncao,
      habilitado:
          data.habilitado.present ? data.habilitado.value : this.habilitado,
      podeInserir:
          data.podeInserir.present ? data.podeInserir.value : this.podeInserir,
      podeAlterar:
          data.podeAlterar.present ? data.podeAlterar.value : this.podeAlterar,
      podeExcluir:
          data.podeExcluir.present ? data.podeExcluir.value : this.podeExcluir,
    );
  }

  @override
  String toString() {
    return (StringBuffer('ViewControleAcesso(')
          ..write('id: $id, ')
          ..write('idPessoa: $idPessoa, ')
          ..write('pessoaNome: $pessoaNome, ')
          ..write('idColaborador: $idColaborador, ')
          ..write('idUsuario: $idUsuario, ')
          ..write('administrador: $administrador, ')
          ..write('idPapel: $idPapel, ')
          ..write('papelNome: $papelNome, ')
          ..write('papelDescricao: $papelDescricao, ')
          ..write('idFuncao: $idFuncao, ')
          ..write('funcaoNome: $funcaoNome, ')
          ..write('funcaoDescricao: $funcaoDescricao, ')
          ..write('idPapelFuncao: $idPapelFuncao, ')
          ..write('habilitado: $habilitado, ')
          ..write('podeInserir: $podeInserir, ')
          ..write('podeAlterar: $podeAlterar, ')
          ..write('podeExcluir: $podeExcluir')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(
    id,
    idPessoa,
    pessoaNome,
    idColaborador,
    idUsuario,
    administrador,
    idPapel,
    papelNome,
    papelDescricao,
    idFuncao,
    funcaoNome,
    funcaoDescricao,
    idPapelFuncao,
    habilitado,
    podeInserir,
    podeAlterar,
    podeExcluir,
  );
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is ViewControleAcesso &&
          other.id == this.id &&
          other.idPessoa == this.idPessoa &&
          other.pessoaNome == this.pessoaNome &&
          other.idColaborador == this.idColaborador &&
          other.idUsuario == this.idUsuario &&
          other.administrador == this.administrador &&
          other.idPapel == this.idPapel &&
          other.papelNome == this.papelNome &&
          other.papelDescricao == this.papelDescricao &&
          other.idFuncao == this.idFuncao &&
          other.funcaoNome == this.funcaoNome &&
          other.funcaoDescricao == this.funcaoDescricao &&
          other.idPapelFuncao == this.idPapelFuncao &&
          other.habilitado == this.habilitado &&
          other.podeInserir == this.podeInserir &&
          other.podeAlterar == this.podeAlterar &&
          other.podeExcluir == this.podeExcluir);
}

class ViewControleAcessosCompanion extends UpdateCompanion<ViewControleAcesso> {
  final Value<int?> id;
  final Value<int?> idPessoa;
  final Value<String?> pessoaNome;
  final Value<int?> idColaborador;
  final Value<int?> idUsuario;
  final Value<String?> administrador;
  final Value<int?> idPapel;
  final Value<String?> papelNome;
  final Value<String?> papelDescricao;
  final Value<int?> idFuncao;
  final Value<String?> funcaoNome;
  final Value<String?> funcaoDescricao;
  final Value<int?> idPapelFuncao;
  final Value<String?> habilitado;
  final Value<String?> podeInserir;
  final Value<String?> podeAlterar;
  final Value<String?> podeExcluir;
  const ViewControleAcessosCompanion({
    this.id = const Value.absent(),
    this.idPessoa = const Value.absent(),
    this.pessoaNome = const Value.absent(),
    this.idColaborador = const Value.absent(),
    this.idUsuario = const Value.absent(),
    this.administrador = const Value.absent(),
    this.idPapel = const Value.absent(),
    this.papelNome = const Value.absent(),
    this.papelDescricao = const Value.absent(),
    this.idFuncao = const Value.absent(),
    this.funcaoNome = const Value.absent(),
    this.funcaoDescricao = const Value.absent(),
    this.idPapelFuncao = const Value.absent(),
    this.habilitado = const Value.absent(),
    this.podeInserir = const Value.absent(),
    this.podeAlterar = const Value.absent(),
    this.podeExcluir = const Value.absent(),
  });
  ViewControleAcessosCompanion.insert({
    this.id = const Value.absent(),
    this.idPessoa = const Value.absent(),
    this.pessoaNome = const Value.absent(),
    this.idColaborador = const Value.absent(),
    this.idUsuario = const Value.absent(),
    this.administrador = const Value.absent(),
    this.idPapel = const Value.absent(),
    this.papelNome = const Value.absent(),
    this.papelDescricao = const Value.absent(),
    this.idFuncao = const Value.absent(),
    this.funcaoNome = const Value.absent(),
    this.funcaoDescricao = const Value.absent(),
    this.idPapelFuncao = const Value.absent(),
    this.habilitado = const Value.absent(),
    this.podeInserir = const Value.absent(),
    this.podeAlterar = const Value.absent(),
    this.podeExcluir = const Value.absent(),
  });
  static Insertable<ViewControleAcesso> custom({
    Expression<int>? id,
    Expression<int>? idPessoa,
    Expression<String>? pessoaNome,
    Expression<int>? idColaborador,
    Expression<int>? idUsuario,
    Expression<String>? administrador,
    Expression<int>? idPapel,
    Expression<String>? papelNome,
    Expression<String>? papelDescricao,
    Expression<int>? idFuncao,
    Expression<String>? funcaoNome,
    Expression<String>? funcaoDescricao,
    Expression<int>? idPapelFuncao,
    Expression<String>? habilitado,
    Expression<String>? podeInserir,
    Expression<String>? podeAlterar,
    Expression<String>? podeExcluir,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (idPessoa != null) 'id_pessoa': idPessoa,
      if (pessoaNome != null) 'pessoa_nome': pessoaNome,
      if (idColaborador != null) 'id_colaborador': idColaborador,
      if (idUsuario != null) 'id_usuario': idUsuario,
      if (administrador != null) 'administrador': administrador,
      if (idPapel != null) 'id_papel': idPapel,
      if (papelNome != null) 'papel_nome': papelNome,
      if (papelDescricao != null) 'papel_descricao': papelDescricao,
      if (idFuncao != null) 'id_funcao': idFuncao,
      if (funcaoNome != null) 'funcao_nome': funcaoNome,
      if (funcaoDescricao != null) 'funcao_descricao': funcaoDescricao,
      if (idPapelFuncao != null) 'id_papel_funcao': idPapelFuncao,
      if (habilitado != null) 'habilitado': habilitado,
      if (podeInserir != null) 'pode_inserir': podeInserir,
      if (podeAlterar != null) 'pode_alterar': podeAlterar,
      if (podeExcluir != null) 'pode_excluir': podeExcluir,
    });
  }

  ViewControleAcessosCompanion copyWith({
    Value<int?>? id,
    Value<int?>? idPessoa,
    Value<String?>? pessoaNome,
    Value<int?>? idColaborador,
    Value<int?>? idUsuario,
    Value<String?>? administrador,
    Value<int?>? idPapel,
    Value<String?>? papelNome,
    Value<String?>? papelDescricao,
    Value<int?>? idFuncao,
    Value<String?>? funcaoNome,
    Value<String?>? funcaoDescricao,
    Value<int?>? idPapelFuncao,
    Value<String?>? habilitado,
    Value<String?>? podeInserir,
    Value<String?>? podeAlterar,
    Value<String?>? podeExcluir,
  }) {
    return ViewControleAcessosCompanion(
      id: id ?? this.id,
      idPessoa: idPessoa ?? this.idPessoa,
      pessoaNome: pessoaNome ?? this.pessoaNome,
      idColaborador: idColaborador ?? this.idColaborador,
      idUsuario: idUsuario ?? this.idUsuario,
      administrador: administrador ?? this.administrador,
      idPapel: idPapel ?? this.idPapel,
      papelNome: papelNome ?? this.papelNome,
      papelDescricao: papelDescricao ?? this.papelDescricao,
      idFuncao: idFuncao ?? this.idFuncao,
      funcaoNome: funcaoNome ?? this.funcaoNome,
      funcaoDescricao: funcaoDescricao ?? this.funcaoDescricao,
      idPapelFuncao: idPapelFuncao ?? this.idPapelFuncao,
      habilitado: habilitado ?? this.habilitado,
      podeInserir: podeInserir ?? this.podeInserir,
      podeAlterar: podeAlterar ?? this.podeAlterar,
      podeExcluir: podeExcluir ?? this.podeExcluir,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (idPessoa.present) {
      map['id_pessoa'] = Variable<int>(idPessoa.value);
    }
    if (pessoaNome.present) {
      map['pessoa_nome'] = Variable<String>(pessoaNome.value);
    }
    if (idColaborador.present) {
      map['id_colaborador'] = Variable<int>(idColaborador.value);
    }
    if (idUsuario.present) {
      map['id_usuario'] = Variable<int>(idUsuario.value);
    }
    if (administrador.present) {
      map['administrador'] = Variable<String>(administrador.value);
    }
    if (idPapel.present) {
      map['id_papel'] = Variable<int>(idPapel.value);
    }
    if (papelNome.present) {
      map['papel_nome'] = Variable<String>(papelNome.value);
    }
    if (papelDescricao.present) {
      map['papel_descricao'] = Variable<String>(papelDescricao.value);
    }
    if (idFuncao.present) {
      map['id_funcao'] = Variable<int>(idFuncao.value);
    }
    if (funcaoNome.present) {
      map['funcao_nome'] = Variable<String>(funcaoNome.value);
    }
    if (funcaoDescricao.present) {
      map['funcao_descricao'] = Variable<String>(funcaoDescricao.value);
    }
    if (idPapelFuncao.present) {
      map['id_papel_funcao'] = Variable<int>(idPapelFuncao.value);
    }
    if (habilitado.present) {
      map['habilitado'] = Variable<String>(habilitado.value);
    }
    if (podeInserir.present) {
      map['pode_inserir'] = Variable<String>(podeInserir.value);
    }
    if (podeAlterar.present) {
      map['pode_alterar'] = Variable<String>(podeAlterar.value);
    }
    if (podeExcluir.present) {
      map['pode_excluir'] = Variable<String>(podeExcluir.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('ViewControleAcessosCompanion(')
          ..write('id: $id, ')
          ..write('idPessoa: $idPessoa, ')
          ..write('pessoaNome: $pessoaNome, ')
          ..write('idColaborador: $idColaborador, ')
          ..write('idUsuario: $idUsuario, ')
          ..write('administrador: $administrador, ')
          ..write('idPapel: $idPapel, ')
          ..write('papelNome: $papelNome, ')
          ..write('papelDescricao: $papelDescricao, ')
          ..write('idFuncao: $idFuncao, ')
          ..write('funcaoNome: $funcaoNome, ')
          ..write('funcaoDescricao: $funcaoDescricao, ')
          ..write('idPapelFuncao: $idPapelFuncao, ')
          ..write('habilitado: $habilitado, ')
          ..write('podeInserir: $podeInserir, ')
          ..write('podeAlterar: $podeAlterar, ')
          ..write('podeExcluir: $podeExcluir')
          ..write(')'))
        .toString();
  }
}

class $ViewPessoaUsuariosTable extends ViewPessoaUsuarios
    with TableInfo<$ViewPessoaUsuariosTable, ViewPessoaUsuario> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $ViewPessoaUsuariosTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
    'id',
    aliasedName,
    true,
    type: DriftSqlType.int,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _idPessoaMeta = const VerificationMeta(
    'idPessoa',
  );
  @override
  late final GeneratedColumn<int> idPessoa = GeneratedColumn<int>(
    'id_pessoa',
    aliasedName,
    true,
    type: DriftSqlType.int,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _pessoaNomeMeta = const VerificationMeta(
    'pessoaNome',
  );
  @override
  late final GeneratedColumn<String> pessoaNome = GeneratedColumn<String>(
    'pessoa_nome',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 450,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _tipoMeta = const VerificationMeta('tipo');
  @override
  late final GeneratedColumn<String> tipo = GeneratedColumn<String>(
    'tipo',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 3,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _emailMeta = const VerificationMeta('email');
  @override
  late final GeneratedColumn<String> email = GeneratedColumn<String>(
    'email',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 750,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _idColaboradorMeta = const VerificationMeta(
    'idColaborador',
  );
  @override
  late final GeneratedColumn<int> idColaborador = GeneratedColumn<int>(
    'id_colaborador',
    aliasedName,
    true,
    type: DriftSqlType.int,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _idUsuarioMeta = const VerificationMeta(
    'idUsuario',
  );
  @override
  late final GeneratedColumn<int> idUsuario = GeneratedColumn<int>(
    'id_usuario',
    aliasedName,
    true,
    type: DriftSqlType.int,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _loginMeta = const VerificationMeta('login');
  @override
  late final GeneratedColumn<String> login = GeneratedColumn<String>(
    'login',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 150,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _senhaMeta = const VerificationMeta('senha');
  @override
  late final GeneratedColumn<String> senha = GeneratedColumn<String>(
    'senha',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 150,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _dataCadastroMeta = const VerificationMeta(
    'dataCadastro',
  );
  @override
  late final GeneratedColumn<DateTime> dataCadastro = GeneratedColumn<DateTime>(
    'data_cadastro',
    aliasedName,
    true,
    type: DriftSqlType.dateTime,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _administradorMeta = const VerificationMeta(
    'administrador',
  );
  @override
  late final GeneratedColumn<String> administrador = GeneratedColumn<String>(
    'administrador',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 3,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  @override
  List<GeneratedColumn> get $columns => [
    id,
    idPessoa,
    pessoaNome,
    tipo,
    email,
    idColaborador,
    idUsuario,
    login,
    senha,
    dataCadastro,
    administrador,
  ];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'view_pessoa_usuario';
  @override
  VerificationContext validateIntegrity(
    Insertable<ViewPessoaUsuario> instance, {
    bool isInserting = false,
  }) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('id_pessoa')) {
      context.handle(
        _idPessoaMeta,
        idPessoa.isAcceptableOrUnknown(data['id_pessoa']!, _idPessoaMeta),
      );
    }
    if (data.containsKey('pessoa_nome')) {
      context.handle(
        _pessoaNomeMeta,
        pessoaNome.isAcceptableOrUnknown(data['pessoa_nome']!, _pessoaNomeMeta),
      );
    }
    if (data.containsKey('tipo')) {
      context.handle(
        _tipoMeta,
        tipo.isAcceptableOrUnknown(data['tipo']!, _tipoMeta),
      );
    }
    if (data.containsKey('email')) {
      context.handle(
        _emailMeta,
        email.isAcceptableOrUnknown(data['email']!, _emailMeta),
      );
    }
    if (data.containsKey('id_colaborador')) {
      context.handle(
        _idColaboradorMeta,
        idColaborador.isAcceptableOrUnknown(
          data['id_colaborador']!,
          _idColaboradorMeta,
        ),
      );
    }
    if (data.containsKey('id_usuario')) {
      context.handle(
        _idUsuarioMeta,
        idUsuario.isAcceptableOrUnknown(data['id_usuario']!, _idUsuarioMeta),
      );
    }
    if (data.containsKey('login')) {
      context.handle(
        _loginMeta,
        login.isAcceptableOrUnknown(data['login']!, _loginMeta),
      );
    }
    if (data.containsKey('senha')) {
      context.handle(
        _senhaMeta,
        senha.isAcceptableOrUnknown(data['senha']!, _senhaMeta),
      );
    }
    if (data.containsKey('data_cadastro')) {
      context.handle(
        _dataCadastroMeta,
        dataCadastro.isAcceptableOrUnknown(
          data['data_cadastro']!,
          _dataCadastroMeta,
        ),
      );
    }
    if (data.containsKey('administrador')) {
      context.handle(
        _administradorMeta,
        administrador.isAcceptableOrUnknown(
          data['administrador']!,
          _administradorMeta,
        ),
      );
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  ViewPessoaUsuario map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return ViewPessoaUsuario(
      id: attachedDatabase.typeMapping.read(
        DriftSqlType.int,
        data['${effectivePrefix}id'],
      ),
      idPessoa: attachedDatabase.typeMapping.read(
        DriftSqlType.int,
        data['${effectivePrefix}id_pessoa'],
      ),
      pessoaNome: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}pessoa_nome'],
      ),
      tipo: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}tipo'],
      ),
      email: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}email'],
      ),
      idColaborador: attachedDatabase.typeMapping.read(
        DriftSqlType.int,
        data['${effectivePrefix}id_colaborador'],
      ),
      idUsuario: attachedDatabase.typeMapping.read(
        DriftSqlType.int,
        data['${effectivePrefix}id_usuario'],
      ),
      login: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}login'],
      ),
      senha: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}senha'],
      ),
      dataCadastro: attachedDatabase.typeMapping.read(
        DriftSqlType.dateTime,
        data['${effectivePrefix}data_cadastro'],
      ),
      administrador: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}administrador'],
      ),
    );
  }

  @override
  $ViewPessoaUsuariosTable createAlias(String alias) {
    return $ViewPessoaUsuariosTable(attachedDatabase, alias);
  }
}

class ViewPessoaUsuario extends DataClass
    implements Insertable<ViewPessoaUsuario> {
  final int? id;
  final int? idPessoa;
  final String? pessoaNome;
  final String? tipo;
  final String? email;
  final int? idColaborador;
  final int? idUsuario;
  final String? login;
  final String? senha;
  final DateTime? dataCadastro;
  final String? administrador;
  const ViewPessoaUsuario({
    this.id,
    this.idPessoa,
    this.pessoaNome,
    this.tipo,
    this.email,
    this.idColaborador,
    this.idUsuario,
    this.login,
    this.senha,
    this.dataCadastro,
    this.administrador,
  });
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || idPessoa != null) {
      map['id_pessoa'] = Variable<int>(idPessoa);
    }
    if (!nullToAbsent || pessoaNome != null) {
      map['pessoa_nome'] = Variable<String>(pessoaNome);
    }
    if (!nullToAbsent || tipo != null) {
      map['tipo'] = Variable<String>(tipo);
    }
    if (!nullToAbsent || email != null) {
      map['email'] = Variable<String>(email);
    }
    if (!nullToAbsent || idColaborador != null) {
      map['id_colaborador'] = Variable<int>(idColaborador);
    }
    if (!nullToAbsent || idUsuario != null) {
      map['id_usuario'] = Variable<int>(idUsuario);
    }
    if (!nullToAbsent || login != null) {
      map['login'] = Variable<String>(login);
    }
    if (!nullToAbsent || senha != null) {
      map['senha'] = Variable<String>(senha);
    }
    if (!nullToAbsent || dataCadastro != null) {
      map['data_cadastro'] = Variable<DateTime>(dataCadastro);
    }
    if (!nullToAbsent || administrador != null) {
      map['administrador'] = Variable<String>(administrador);
    }
    return map;
  }

  factory ViewPessoaUsuario.fromJson(
    Map<String, dynamic> json, {
    ValueSerializer? serializer,
  }) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return ViewPessoaUsuario(
      id: serializer.fromJson<int?>(json['id']),
      idPessoa: serializer.fromJson<int?>(json['idPessoa']),
      pessoaNome: serializer.fromJson<String?>(json['pessoaNome']),
      tipo: serializer.fromJson<String?>(json['tipo']),
      email: serializer.fromJson<String?>(json['email']),
      idColaborador: serializer.fromJson<int?>(json['idColaborador']),
      idUsuario: serializer.fromJson<int?>(json['idUsuario']),
      login: serializer.fromJson<String?>(json['login']),
      senha: serializer.fromJson<String?>(json['senha']),
      dataCadastro: serializer.fromJson<DateTime?>(json['dataCadastro']),
      administrador: serializer.fromJson<String?>(json['administrador']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'idPessoa': serializer.toJson<int?>(idPessoa),
      'pessoaNome': serializer.toJson<String?>(pessoaNome),
      'tipo': serializer.toJson<String?>(tipo),
      'email': serializer.toJson<String?>(email),
      'idColaborador': serializer.toJson<int?>(idColaborador),
      'idUsuario': serializer.toJson<int?>(idUsuario),
      'login': serializer.toJson<String?>(login),
      'senha': serializer.toJson<String?>(senha),
      'dataCadastro': serializer.toJson<DateTime?>(dataCadastro),
      'administrador': serializer.toJson<String?>(administrador),
    };
  }

  ViewPessoaUsuario copyWith({
    Value<int?> id = const Value.absent(),
    Value<int?> idPessoa = const Value.absent(),
    Value<String?> pessoaNome = const Value.absent(),
    Value<String?> tipo = const Value.absent(),
    Value<String?> email = const Value.absent(),
    Value<int?> idColaborador = const Value.absent(),
    Value<int?> idUsuario = const Value.absent(),
    Value<String?> login = const Value.absent(),
    Value<String?> senha = const Value.absent(),
    Value<DateTime?> dataCadastro = const Value.absent(),
    Value<String?> administrador = const Value.absent(),
  }) => ViewPessoaUsuario(
    id: id.present ? id.value : this.id,
    idPessoa: idPessoa.present ? idPessoa.value : this.idPessoa,
    pessoaNome: pessoaNome.present ? pessoaNome.value : this.pessoaNome,
    tipo: tipo.present ? tipo.value : this.tipo,
    email: email.present ? email.value : this.email,
    idColaborador:
        idColaborador.present ? idColaborador.value : this.idColaborador,
    idUsuario: idUsuario.present ? idUsuario.value : this.idUsuario,
    login: login.present ? login.value : this.login,
    senha: senha.present ? senha.value : this.senha,
    dataCadastro: dataCadastro.present ? dataCadastro.value : this.dataCadastro,
    administrador:
        administrador.present ? administrador.value : this.administrador,
  );
  ViewPessoaUsuario copyWithCompanion(ViewPessoaUsuariosCompanion data) {
    return ViewPessoaUsuario(
      id: data.id.present ? data.id.value : this.id,
      idPessoa: data.idPessoa.present ? data.idPessoa.value : this.idPessoa,
      pessoaNome:
          data.pessoaNome.present ? data.pessoaNome.value : this.pessoaNome,
      tipo: data.tipo.present ? data.tipo.value : this.tipo,
      email: data.email.present ? data.email.value : this.email,
      idColaborador:
          data.idColaborador.present
              ? data.idColaborador.value
              : this.idColaborador,
      idUsuario: data.idUsuario.present ? data.idUsuario.value : this.idUsuario,
      login: data.login.present ? data.login.value : this.login,
      senha: data.senha.present ? data.senha.value : this.senha,
      dataCadastro:
          data.dataCadastro.present
              ? data.dataCadastro.value
              : this.dataCadastro,
      administrador:
          data.administrador.present
              ? data.administrador.value
              : this.administrador,
    );
  }

  @override
  String toString() {
    return (StringBuffer('ViewPessoaUsuario(')
          ..write('id: $id, ')
          ..write('idPessoa: $idPessoa, ')
          ..write('pessoaNome: $pessoaNome, ')
          ..write('tipo: $tipo, ')
          ..write('email: $email, ')
          ..write('idColaborador: $idColaborador, ')
          ..write('idUsuario: $idUsuario, ')
          ..write('login: $login, ')
          ..write('senha: $senha, ')
          ..write('dataCadastro: $dataCadastro, ')
          ..write('administrador: $administrador')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(
    id,
    idPessoa,
    pessoaNome,
    tipo,
    email,
    idColaborador,
    idUsuario,
    login,
    senha,
    dataCadastro,
    administrador,
  );
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is ViewPessoaUsuario &&
          other.id == this.id &&
          other.idPessoa == this.idPessoa &&
          other.pessoaNome == this.pessoaNome &&
          other.tipo == this.tipo &&
          other.email == this.email &&
          other.idColaborador == this.idColaborador &&
          other.idUsuario == this.idUsuario &&
          other.login == this.login &&
          other.senha == this.senha &&
          other.dataCadastro == this.dataCadastro &&
          other.administrador == this.administrador);
}

class ViewPessoaUsuariosCompanion extends UpdateCompanion<ViewPessoaUsuario> {
  final Value<int?> id;
  final Value<int?> idPessoa;
  final Value<String?> pessoaNome;
  final Value<String?> tipo;
  final Value<String?> email;
  final Value<int?> idColaborador;
  final Value<int?> idUsuario;
  final Value<String?> login;
  final Value<String?> senha;
  final Value<DateTime?> dataCadastro;
  final Value<String?> administrador;
  const ViewPessoaUsuariosCompanion({
    this.id = const Value.absent(),
    this.idPessoa = const Value.absent(),
    this.pessoaNome = const Value.absent(),
    this.tipo = const Value.absent(),
    this.email = const Value.absent(),
    this.idColaborador = const Value.absent(),
    this.idUsuario = const Value.absent(),
    this.login = const Value.absent(),
    this.senha = const Value.absent(),
    this.dataCadastro = const Value.absent(),
    this.administrador = const Value.absent(),
  });
  ViewPessoaUsuariosCompanion.insert({
    this.id = const Value.absent(),
    this.idPessoa = const Value.absent(),
    this.pessoaNome = const Value.absent(),
    this.tipo = const Value.absent(),
    this.email = const Value.absent(),
    this.idColaborador = const Value.absent(),
    this.idUsuario = const Value.absent(),
    this.login = const Value.absent(),
    this.senha = const Value.absent(),
    this.dataCadastro = const Value.absent(),
    this.administrador = const Value.absent(),
  });
  static Insertable<ViewPessoaUsuario> custom({
    Expression<int>? id,
    Expression<int>? idPessoa,
    Expression<String>? pessoaNome,
    Expression<String>? tipo,
    Expression<String>? email,
    Expression<int>? idColaborador,
    Expression<int>? idUsuario,
    Expression<String>? login,
    Expression<String>? senha,
    Expression<DateTime>? dataCadastro,
    Expression<String>? administrador,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (idPessoa != null) 'id_pessoa': idPessoa,
      if (pessoaNome != null) 'pessoa_nome': pessoaNome,
      if (tipo != null) 'tipo': tipo,
      if (email != null) 'email': email,
      if (idColaborador != null) 'id_colaborador': idColaborador,
      if (idUsuario != null) 'id_usuario': idUsuario,
      if (login != null) 'login': login,
      if (senha != null) 'senha': senha,
      if (dataCadastro != null) 'data_cadastro': dataCadastro,
      if (administrador != null) 'administrador': administrador,
    });
  }

  ViewPessoaUsuariosCompanion copyWith({
    Value<int?>? id,
    Value<int?>? idPessoa,
    Value<String?>? pessoaNome,
    Value<String?>? tipo,
    Value<String?>? email,
    Value<int?>? idColaborador,
    Value<int?>? idUsuario,
    Value<String?>? login,
    Value<String?>? senha,
    Value<DateTime?>? dataCadastro,
    Value<String?>? administrador,
  }) {
    return ViewPessoaUsuariosCompanion(
      id: id ?? this.id,
      idPessoa: idPessoa ?? this.idPessoa,
      pessoaNome: pessoaNome ?? this.pessoaNome,
      tipo: tipo ?? this.tipo,
      email: email ?? this.email,
      idColaborador: idColaborador ?? this.idColaborador,
      idUsuario: idUsuario ?? this.idUsuario,
      login: login ?? this.login,
      senha: senha ?? this.senha,
      dataCadastro: dataCadastro ?? this.dataCadastro,
      administrador: administrador ?? this.administrador,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (idPessoa.present) {
      map['id_pessoa'] = Variable<int>(idPessoa.value);
    }
    if (pessoaNome.present) {
      map['pessoa_nome'] = Variable<String>(pessoaNome.value);
    }
    if (tipo.present) {
      map['tipo'] = Variable<String>(tipo.value);
    }
    if (email.present) {
      map['email'] = Variable<String>(email.value);
    }
    if (idColaborador.present) {
      map['id_colaborador'] = Variable<int>(idColaborador.value);
    }
    if (idUsuario.present) {
      map['id_usuario'] = Variable<int>(idUsuario.value);
    }
    if (login.present) {
      map['login'] = Variable<String>(login.value);
    }
    if (senha.present) {
      map['senha'] = Variable<String>(senha.value);
    }
    if (dataCadastro.present) {
      map['data_cadastro'] = Variable<DateTime>(dataCadastro.value);
    }
    if (administrador.present) {
      map['administrador'] = Variable<String>(administrador.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('ViewPessoaUsuariosCompanion(')
          ..write('id: $id, ')
          ..write('idPessoa: $idPessoa, ')
          ..write('pessoaNome: $pessoaNome, ')
          ..write('tipo: $tipo, ')
          ..write('email: $email, ')
          ..write('idColaborador: $idColaborador, ')
          ..write('idUsuario: $idUsuario, ')
          ..write('login: $login, ')
          ..write('senha: $senha, ')
          ..write('dataCadastro: $dataCadastro, ')
          ..write('administrador: $administrador')
          ..write(')'))
        .toString();
  }
}

abstract class _$AppDatabase extends GeneratedDatabase {
  _$AppDatabase(QueryExecutor e) : super(e);
  $AppDatabaseManager get managers => $AppDatabaseManager(this);
  late final $BpeEmitentesTable bpeEmitentes = $BpeEmitentesTable(this);
  late final $BpePassageirosTable bpePassageiros = $BpePassageirosTable(this);
  late final $BpeCompradorsTable bpeCompradors = $BpeCompradorsTable(this);
  late final $BpeViagemsTable bpeViagems = $BpeViagemsTable(this);
  late final $BpeAgenciasTable bpeAgencias = $BpeAgenciasTable(this);
  late final $BpePassagemsTable bpePassagems = $BpePassagemsTable(this);
  late final $BpeCabecalhosTable bpeCabecalhos = $BpeCabecalhosTable(this);
  late final $ViewControleAcessosTable viewControleAcessos =
      $ViewControleAcessosTable(this);
  late final $ViewPessoaUsuariosTable viewPessoaUsuarios =
      $ViewPessoaUsuariosTable(this);
  late final BpeCabecalhoDao bpeCabecalhoDao = BpeCabecalhoDao(
    this as AppDatabase,
  );
  late final ViewControleAcessoDao viewControleAcessoDao =
      ViewControleAcessoDao(this as AppDatabase);
  late final ViewPessoaUsuarioDao viewPessoaUsuarioDao = ViewPessoaUsuarioDao(
    this as AppDatabase,
  );
  @override
  Iterable<TableInfo<Table, Object?>> get allTables =>
      allSchemaEntities.whereType<TableInfo<Table, Object?>>();
  @override
  List<DatabaseSchemaEntity> get allSchemaEntities => [
    bpeEmitentes,
    bpePassageiros,
    bpeCompradors,
    bpeViagems,
    bpeAgencias,
    bpePassagems,
    bpeCabecalhos,
    viewControleAcessos,
    viewPessoaUsuarios,
  ];
}

typedef $$BpeEmitentesTableCreateCompanionBuilder =
    BpeEmitentesCompanion Function({
      Value<int?> id,
      Value<int?> idBpeCabecalho,
      Value<String?> cnpj,
      Value<String?> ie,
      Value<String?> iest,
      Value<String?> im,
      Value<String?> cnae,
      Value<String?> crt,
      Value<String?> nome,
      Value<String?> fantasia,
      Value<String?> logradouro,
      Value<String?> numero,
      Value<String?> complemento,
      Value<String?> bairro,
      Value<int?> codigoMunicipio,
      Value<String?> nomeMunicipio,
      Value<String?> uf,
      Value<String?> cep,
      Value<String?> telefone,
    });
typedef $$BpeEmitentesTableUpdateCompanionBuilder =
    BpeEmitentesCompanion Function({
      Value<int?> id,
      Value<int?> idBpeCabecalho,
      Value<String?> cnpj,
      Value<String?> ie,
      Value<String?> iest,
      Value<String?> im,
      Value<String?> cnae,
      Value<String?> crt,
      Value<String?> nome,
      Value<String?> fantasia,
      Value<String?> logradouro,
      Value<String?> numero,
      Value<String?> complemento,
      Value<String?> bairro,
      Value<int?> codigoMunicipio,
      Value<String?> nomeMunicipio,
      Value<String?> uf,
      Value<String?> cep,
      Value<String?> telefone,
    });

class $$BpeEmitentesTableFilterComposer
    extends Composer<_$AppDatabase, $BpeEmitentesTable> {
  $$BpeEmitentesTableFilterComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnFilters<int> get id => $composableBuilder(
    column: $table.id,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<int> get idBpeCabecalho => $composableBuilder(
    column: $table.idBpeCabecalho,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get cnpj => $composableBuilder(
    column: $table.cnpj,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get ie => $composableBuilder(
    column: $table.ie,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get iest => $composableBuilder(
    column: $table.iest,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get im => $composableBuilder(
    column: $table.im,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get cnae => $composableBuilder(
    column: $table.cnae,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get crt => $composableBuilder(
    column: $table.crt,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get nome => $composableBuilder(
    column: $table.nome,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get fantasia => $composableBuilder(
    column: $table.fantasia,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get logradouro => $composableBuilder(
    column: $table.logradouro,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get numero => $composableBuilder(
    column: $table.numero,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get complemento => $composableBuilder(
    column: $table.complemento,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get bairro => $composableBuilder(
    column: $table.bairro,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<int> get codigoMunicipio => $composableBuilder(
    column: $table.codigoMunicipio,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get nomeMunicipio => $composableBuilder(
    column: $table.nomeMunicipio,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get uf => $composableBuilder(
    column: $table.uf,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get cep => $composableBuilder(
    column: $table.cep,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get telefone => $composableBuilder(
    column: $table.telefone,
    builder: (column) => ColumnFilters(column),
  );
}

class $$BpeEmitentesTableOrderingComposer
    extends Composer<_$AppDatabase, $BpeEmitentesTable> {
  $$BpeEmitentesTableOrderingComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnOrderings<int> get id => $composableBuilder(
    column: $table.id,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<int> get idBpeCabecalho => $composableBuilder(
    column: $table.idBpeCabecalho,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get cnpj => $composableBuilder(
    column: $table.cnpj,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get ie => $composableBuilder(
    column: $table.ie,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get iest => $composableBuilder(
    column: $table.iest,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get im => $composableBuilder(
    column: $table.im,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get cnae => $composableBuilder(
    column: $table.cnae,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get crt => $composableBuilder(
    column: $table.crt,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get nome => $composableBuilder(
    column: $table.nome,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get fantasia => $composableBuilder(
    column: $table.fantasia,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get logradouro => $composableBuilder(
    column: $table.logradouro,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get numero => $composableBuilder(
    column: $table.numero,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get complemento => $composableBuilder(
    column: $table.complemento,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get bairro => $composableBuilder(
    column: $table.bairro,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<int> get codigoMunicipio => $composableBuilder(
    column: $table.codigoMunicipio,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get nomeMunicipio => $composableBuilder(
    column: $table.nomeMunicipio,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get uf => $composableBuilder(
    column: $table.uf,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get cep => $composableBuilder(
    column: $table.cep,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get telefone => $composableBuilder(
    column: $table.telefone,
    builder: (column) => ColumnOrderings(column),
  );
}

class $$BpeEmitentesTableAnnotationComposer
    extends Composer<_$AppDatabase, $BpeEmitentesTable> {
  $$BpeEmitentesTableAnnotationComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  GeneratedColumn<int> get id =>
      $composableBuilder(column: $table.id, builder: (column) => column);

  GeneratedColumn<int> get idBpeCabecalho => $composableBuilder(
    column: $table.idBpeCabecalho,
    builder: (column) => column,
  );

  GeneratedColumn<String> get cnpj =>
      $composableBuilder(column: $table.cnpj, builder: (column) => column);

  GeneratedColumn<String> get ie =>
      $composableBuilder(column: $table.ie, builder: (column) => column);

  GeneratedColumn<String> get iest =>
      $composableBuilder(column: $table.iest, builder: (column) => column);

  GeneratedColumn<String> get im =>
      $composableBuilder(column: $table.im, builder: (column) => column);

  GeneratedColumn<String> get cnae =>
      $composableBuilder(column: $table.cnae, builder: (column) => column);

  GeneratedColumn<String> get crt =>
      $composableBuilder(column: $table.crt, builder: (column) => column);

  GeneratedColumn<String> get nome =>
      $composableBuilder(column: $table.nome, builder: (column) => column);

  GeneratedColumn<String> get fantasia =>
      $composableBuilder(column: $table.fantasia, builder: (column) => column);

  GeneratedColumn<String> get logradouro => $composableBuilder(
    column: $table.logradouro,
    builder: (column) => column,
  );

  GeneratedColumn<String> get numero =>
      $composableBuilder(column: $table.numero, builder: (column) => column);

  GeneratedColumn<String> get complemento => $composableBuilder(
    column: $table.complemento,
    builder: (column) => column,
  );

  GeneratedColumn<String> get bairro =>
      $composableBuilder(column: $table.bairro, builder: (column) => column);

  GeneratedColumn<int> get codigoMunicipio => $composableBuilder(
    column: $table.codigoMunicipio,
    builder: (column) => column,
  );

  GeneratedColumn<String> get nomeMunicipio => $composableBuilder(
    column: $table.nomeMunicipio,
    builder: (column) => column,
  );

  GeneratedColumn<String> get uf =>
      $composableBuilder(column: $table.uf, builder: (column) => column);

  GeneratedColumn<String> get cep =>
      $composableBuilder(column: $table.cep, builder: (column) => column);

  GeneratedColumn<String> get telefone =>
      $composableBuilder(column: $table.telefone, builder: (column) => column);
}

class $$BpeEmitentesTableTableManager
    extends
        RootTableManager<
          _$AppDatabase,
          $BpeEmitentesTable,
          BpeEmitente,
          $$BpeEmitentesTableFilterComposer,
          $$BpeEmitentesTableOrderingComposer,
          $$BpeEmitentesTableAnnotationComposer,
          $$BpeEmitentesTableCreateCompanionBuilder,
          $$BpeEmitentesTableUpdateCompanionBuilder,
          (
            BpeEmitente,
            BaseReferences<_$AppDatabase, $BpeEmitentesTable, BpeEmitente>,
          ),
          BpeEmitente,
          PrefetchHooks Function()
        > {
  $$BpeEmitentesTableTableManager(_$AppDatabase db, $BpeEmitentesTable table)
    : super(
        TableManagerState(
          db: db,
          table: table,
          createFilteringComposer:
              () => $$BpeEmitentesTableFilterComposer($db: db, $table: table),
          createOrderingComposer:
              () => $$BpeEmitentesTableOrderingComposer($db: db, $table: table),
          createComputedFieldComposer:
              () =>
                  $$BpeEmitentesTableAnnotationComposer($db: db, $table: table),
          updateCompanionCallback:
              ({
                Value<int?> id = const Value.absent(),
                Value<int?> idBpeCabecalho = const Value.absent(),
                Value<String?> cnpj = const Value.absent(),
                Value<String?> ie = const Value.absent(),
                Value<String?> iest = const Value.absent(),
                Value<String?> im = const Value.absent(),
                Value<String?> cnae = const Value.absent(),
                Value<String?> crt = const Value.absent(),
                Value<String?> nome = const Value.absent(),
                Value<String?> fantasia = const Value.absent(),
                Value<String?> logradouro = const Value.absent(),
                Value<String?> numero = const Value.absent(),
                Value<String?> complemento = const Value.absent(),
                Value<String?> bairro = const Value.absent(),
                Value<int?> codigoMunicipio = const Value.absent(),
                Value<String?> nomeMunicipio = const Value.absent(),
                Value<String?> uf = const Value.absent(),
                Value<String?> cep = const Value.absent(),
                Value<String?> telefone = const Value.absent(),
              }) => BpeEmitentesCompanion(
                id: id,
                idBpeCabecalho: idBpeCabecalho,
                cnpj: cnpj,
                ie: ie,
                iest: iest,
                im: im,
                cnae: cnae,
                crt: crt,
                nome: nome,
                fantasia: fantasia,
                logradouro: logradouro,
                numero: numero,
                complemento: complemento,
                bairro: bairro,
                codigoMunicipio: codigoMunicipio,
                nomeMunicipio: nomeMunicipio,
                uf: uf,
                cep: cep,
                telefone: telefone,
              ),
          createCompanionCallback:
              ({
                Value<int?> id = const Value.absent(),
                Value<int?> idBpeCabecalho = const Value.absent(),
                Value<String?> cnpj = const Value.absent(),
                Value<String?> ie = const Value.absent(),
                Value<String?> iest = const Value.absent(),
                Value<String?> im = const Value.absent(),
                Value<String?> cnae = const Value.absent(),
                Value<String?> crt = const Value.absent(),
                Value<String?> nome = const Value.absent(),
                Value<String?> fantasia = const Value.absent(),
                Value<String?> logradouro = const Value.absent(),
                Value<String?> numero = const Value.absent(),
                Value<String?> complemento = const Value.absent(),
                Value<String?> bairro = const Value.absent(),
                Value<int?> codigoMunicipio = const Value.absent(),
                Value<String?> nomeMunicipio = const Value.absent(),
                Value<String?> uf = const Value.absent(),
                Value<String?> cep = const Value.absent(),
                Value<String?> telefone = const Value.absent(),
              }) => BpeEmitentesCompanion.insert(
                id: id,
                idBpeCabecalho: idBpeCabecalho,
                cnpj: cnpj,
                ie: ie,
                iest: iest,
                im: im,
                cnae: cnae,
                crt: crt,
                nome: nome,
                fantasia: fantasia,
                logradouro: logradouro,
                numero: numero,
                complemento: complemento,
                bairro: bairro,
                codigoMunicipio: codigoMunicipio,
                nomeMunicipio: nomeMunicipio,
                uf: uf,
                cep: cep,
                telefone: telefone,
              ),
          withReferenceMapper:
              (p0) =>
                  p0
                      .map(
                        (e) => (
                          e.readTable(table),
                          BaseReferences(db, table, e),
                        ),
                      )
                      .toList(),
          prefetchHooksCallback: null,
        ),
      );
}

typedef $$BpeEmitentesTableProcessedTableManager =
    ProcessedTableManager<
      _$AppDatabase,
      $BpeEmitentesTable,
      BpeEmitente,
      $$BpeEmitentesTableFilterComposer,
      $$BpeEmitentesTableOrderingComposer,
      $$BpeEmitentesTableAnnotationComposer,
      $$BpeEmitentesTableCreateCompanionBuilder,
      $$BpeEmitentesTableUpdateCompanionBuilder,
      (
        BpeEmitente,
        BaseReferences<_$AppDatabase, $BpeEmitentesTable, BpeEmitente>,
      ),
      BpeEmitente,
      PrefetchHooks Function()
    >;
typedef $$BpePassageirosTableCreateCompanionBuilder =
    BpePassageirosCompanion Function({
      Value<int?> id,
      Value<int?> idBpeCabecalho,
      Value<String?> nome,
      Value<String?> cpf,
      Value<String?> tipoDocumentoIdentificacao,
      Value<String?> numeroDocumento,
      Value<String?> documentoOutrosDescricao,
      Value<DateTime?> dataNascimento,
      Value<String?> telefone,
      Value<String?> email,
    });
typedef $$BpePassageirosTableUpdateCompanionBuilder =
    BpePassageirosCompanion Function({
      Value<int?> id,
      Value<int?> idBpeCabecalho,
      Value<String?> nome,
      Value<String?> cpf,
      Value<String?> tipoDocumentoIdentificacao,
      Value<String?> numeroDocumento,
      Value<String?> documentoOutrosDescricao,
      Value<DateTime?> dataNascimento,
      Value<String?> telefone,
      Value<String?> email,
    });

class $$BpePassageirosTableFilterComposer
    extends Composer<_$AppDatabase, $BpePassageirosTable> {
  $$BpePassageirosTableFilterComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnFilters<int> get id => $composableBuilder(
    column: $table.id,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<int> get idBpeCabecalho => $composableBuilder(
    column: $table.idBpeCabecalho,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get nome => $composableBuilder(
    column: $table.nome,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get cpf => $composableBuilder(
    column: $table.cpf,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get tipoDocumentoIdentificacao => $composableBuilder(
    column: $table.tipoDocumentoIdentificacao,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get numeroDocumento => $composableBuilder(
    column: $table.numeroDocumento,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get documentoOutrosDescricao => $composableBuilder(
    column: $table.documentoOutrosDescricao,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<DateTime> get dataNascimento => $composableBuilder(
    column: $table.dataNascimento,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get telefone => $composableBuilder(
    column: $table.telefone,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get email => $composableBuilder(
    column: $table.email,
    builder: (column) => ColumnFilters(column),
  );
}

class $$BpePassageirosTableOrderingComposer
    extends Composer<_$AppDatabase, $BpePassageirosTable> {
  $$BpePassageirosTableOrderingComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnOrderings<int> get id => $composableBuilder(
    column: $table.id,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<int> get idBpeCabecalho => $composableBuilder(
    column: $table.idBpeCabecalho,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get nome => $composableBuilder(
    column: $table.nome,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get cpf => $composableBuilder(
    column: $table.cpf,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get tipoDocumentoIdentificacao => $composableBuilder(
    column: $table.tipoDocumentoIdentificacao,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get numeroDocumento => $composableBuilder(
    column: $table.numeroDocumento,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get documentoOutrosDescricao => $composableBuilder(
    column: $table.documentoOutrosDescricao,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<DateTime> get dataNascimento => $composableBuilder(
    column: $table.dataNascimento,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get telefone => $composableBuilder(
    column: $table.telefone,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get email => $composableBuilder(
    column: $table.email,
    builder: (column) => ColumnOrderings(column),
  );
}

class $$BpePassageirosTableAnnotationComposer
    extends Composer<_$AppDatabase, $BpePassageirosTable> {
  $$BpePassageirosTableAnnotationComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  GeneratedColumn<int> get id =>
      $composableBuilder(column: $table.id, builder: (column) => column);

  GeneratedColumn<int> get idBpeCabecalho => $composableBuilder(
    column: $table.idBpeCabecalho,
    builder: (column) => column,
  );

  GeneratedColumn<String> get nome =>
      $composableBuilder(column: $table.nome, builder: (column) => column);

  GeneratedColumn<String> get cpf =>
      $composableBuilder(column: $table.cpf, builder: (column) => column);

  GeneratedColumn<String> get tipoDocumentoIdentificacao => $composableBuilder(
    column: $table.tipoDocumentoIdentificacao,
    builder: (column) => column,
  );

  GeneratedColumn<String> get numeroDocumento => $composableBuilder(
    column: $table.numeroDocumento,
    builder: (column) => column,
  );

  GeneratedColumn<String> get documentoOutrosDescricao => $composableBuilder(
    column: $table.documentoOutrosDescricao,
    builder: (column) => column,
  );

  GeneratedColumn<DateTime> get dataNascimento => $composableBuilder(
    column: $table.dataNascimento,
    builder: (column) => column,
  );

  GeneratedColumn<String> get telefone =>
      $composableBuilder(column: $table.telefone, builder: (column) => column);

  GeneratedColumn<String> get email =>
      $composableBuilder(column: $table.email, builder: (column) => column);
}

class $$BpePassageirosTableTableManager
    extends
        RootTableManager<
          _$AppDatabase,
          $BpePassageirosTable,
          BpePassageiro,
          $$BpePassageirosTableFilterComposer,
          $$BpePassageirosTableOrderingComposer,
          $$BpePassageirosTableAnnotationComposer,
          $$BpePassageirosTableCreateCompanionBuilder,
          $$BpePassageirosTableUpdateCompanionBuilder,
          (
            BpePassageiro,
            BaseReferences<_$AppDatabase, $BpePassageirosTable, BpePassageiro>,
          ),
          BpePassageiro,
          PrefetchHooks Function()
        > {
  $$BpePassageirosTableTableManager(
    _$AppDatabase db,
    $BpePassageirosTable table,
  ) : super(
        TableManagerState(
          db: db,
          table: table,
          createFilteringComposer:
              () => $$BpePassageirosTableFilterComposer($db: db, $table: table),
          createOrderingComposer:
              () =>
                  $$BpePassageirosTableOrderingComposer($db: db, $table: table),
          createComputedFieldComposer:
              () => $$BpePassageirosTableAnnotationComposer(
                $db: db,
                $table: table,
              ),
          updateCompanionCallback:
              ({
                Value<int?> id = const Value.absent(),
                Value<int?> idBpeCabecalho = const Value.absent(),
                Value<String?> nome = const Value.absent(),
                Value<String?> cpf = const Value.absent(),
                Value<String?> tipoDocumentoIdentificacao =
                    const Value.absent(),
                Value<String?> numeroDocumento = const Value.absent(),
                Value<String?> documentoOutrosDescricao = const Value.absent(),
                Value<DateTime?> dataNascimento = const Value.absent(),
                Value<String?> telefone = const Value.absent(),
                Value<String?> email = const Value.absent(),
              }) => BpePassageirosCompanion(
                id: id,
                idBpeCabecalho: idBpeCabecalho,
                nome: nome,
                cpf: cpf,
                tipoDocumentoIdentificacao: tipoDocumentoIdentificacao,
                numeroDocumento: numeroDocumento,
                documentoOutrosDescricao: documentoOutrosDescricao,
                dataNascimento: dataNascimento,
                telefone: telefone,
                email: email,
              ),
          createCompanionCallback:
              ({
                Value<int?> id = const Value.absent(),
                Value<int?> idBpeCabecalho = const Value.absent(),
                Value<String?> nome = const Value.absent(),
                Value<String?> cpf = const Value.absent(),
                Value<String?> tipoDocumentoIdentificacao =
                    const Value.absent(),
                Value<String?> numeroDocumento = const Value.absent(),
                Value<String?> documentoOutrosDescricao = const Value.absent(),
                Value<DateTime?> dataNascimento = const Value.absent(),
                Value<String?> telefone = const Value.absent(),
                Value<String?> email = const Value.absent(),
              }) => BpePassageirosCompanion.insert(
                id: id,
                idBpeCabecalho: idBpeCabecalho,
                nome: nome,
                cpf: cpf,
                tipoDocumentoIdentificacao: tipoDocumentoIdentificacao,
                numeroDocumento: numeroDocumento,
                documentoOutrosDescricao: documentoOutrosDescricao,
                dataNascimento: dataNascimento,
                telefone: telefone,
                email: email,
              ),
          withReferenceMapper:
              (p0) =>
                  p0
                      .map(
                        (e) => (
                          e.readTable(table),
                          BaseReferences(db, table, e),
                        ),
                      )
                      .toList(),
          prefetchHooksCallback: null,
        ),
      );
}

typedef $$BpePassageirosTableProcessedTableManager =
    ProcessedTableManager<
      _$AppDatabase,
      $BpePassageirosTable,
      BpePassageiro,
      $$BpePassageirosTableFilterComposer,
      $$BpePassageirosTableOrderingComposer,
      $$BpePassageirosTableAnnotationComposer,
      $$BpePassageirosTableCreateCompanionBuilder,
      $$BpePassageirosTableUpdateCompanionBuilder,
      (
        BpePassageiro,
        BaseReferences<_$AppDatabase, $BpePassageirosTable, BpePassageiro>,
      ),
      BpePassageiro,
      PrefetchHooks Function()
    >;
typedef $$BpeCompradorsTableCreateCompanionBuilder =
    BpeCompradorsCompanion Function({
      Value<int?> id,
      Value<int?> idBpeCabecalho,
      Value<String?> cnpj,
      Value<String?> cpf,
      Value<String?> ie,
      Value<String?> nome,
      Value<String?> fantasia,
      Value<String?> telefone,
      Value<String?> logradouro,
      Value<String?> numero,
      Value<String?> complemento,
      Value<String?> bairro,
      Value<int?> codigoMunicipio,
      Value<String?> nomeMunicipio,
      Value<String?> uf,
      Value<String?> cep,
      Value<int?> codigoPais,
      Value<String?> nomePais,
      Value<String?> email,
    });
typedef $$BpeCompradorsTableUpdateCompanionBuilder =
    BpeCompradorsCompanion Function({
      Value<int?> id,
      Value<int?> idBpeCabecalho,
      Value<String?> cnpj,
      Value<String?> cpf,
      Value<String?> ie,
      Value<String?> nome,
      Value<String?> fantasia,
      Value<String?> telefone,
      Value<String?> logradouro,
      Value<String?> numero,
      Value<String?> complemento,
      Value<String?> bairro,
      Value<int?> codigoMunicipio,
      Value<String?> nomeMunicipio,
      Value<String?> uf,
      Value<String?> cep,
      Value<int?> codigoPais,
      Value<String?> nomePais,
      Value<String?> email,
    });

class $$BpeCompradorsTableFilterComposer
    extends Composer<_$AppDatabase, $BpeCompradorsTable> {
  $$BpeCompradorsTableFilterComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnFilters<int> get id => $composableBuilder(
    column: $table.id,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<int> get idBpeCabecalho => $composableBuilder(
    column: $table.idBpeCabecalho,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get cnpj => $composableBuilder(
    column: $table.cnpj,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get cpf => $composableBuilder(
    column: $table.cpf,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get ie => $composableBuilder(
    column: $table.ie,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get nome => $composableBuilder(
    column: $table.nome,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get fantasia => $composableBuilder(
    column: $table.fantasia,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get telefone => $composableBuilder(
    column: $table.telefone,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get logradouro => $composableBuilder(
    column: $table.logradouro,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get numero => $composableBuilder(
    column: $table.numero,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get complemento => $composableBuilder(
    column: $table.complemento,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get bairro => $composableBuilder(
    column: $table.bairro,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<int> get codigoMunicipio => $composableBuilder(
    column: $table.codigoMunicipio,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get nomeMunicipio => $composableBuilder(
    column: $table.nomeMunicipio,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get uf => $composableBuilder(
    column: $table.uf,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get cep => $composableBuilder(
    column: $table.cep,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<int> get codigoPais => $composableBuilder(
    column: $table.codigoPais,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get nomePais => $composableBuilder(
    column: $table.nomePais,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get email => $composableBuilder(
    column: $table.email,
    builder: (column) => ColumnFilters(column),
  );
}

class $$BpeCompradorsTableOrderingComposer
    extends Composer<_$AppDatabase, $BpeCompradorsTable> {
  $$BpeCompradorsTableOrderingComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnOrderings<int> get id => $composableBuilder(
    column: $table.id,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<int> get idBpeCabecalho => $composableBuilder(
    column: $table.idBpeCabecalho,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get cnpj => $composableBuilder(
    column: $table.cnpj,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get cpf => $composableBuilder(
    column: $table.cpf,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get ie => $composableBuilder(
    column: $table.ie,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get nome => $composableBuilder(
    column: $table.nome,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get fantasia => $composableBuilder(
    column: $table.fantasia,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get telefone => $composableBuilder(
    column: $table.telefone,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get logradouro => $composableBuilder(
    column: $table.logradouro,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get numero => $composableBuilder(
    column: $table.numero,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get complemento => $composableBuilder(
    column: $table.complemento,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get bairro => $composableBuilder(
    column: $table.bairro,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<int> get codigoMunicipio => $composableBuilder(
    column: $table.codigoMunicipio,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get nomeMunicipio => $composableBuilder(
    column: $table.nomeMunicipio,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get uf => $composableBuilder(
    column: $table.uf,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get cep => $composableBuilder(
    column: $table.cep,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<int> get codigoPais => $composableBuilder(
    column: $table.codigoPais,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get nomePais => $composableBuilder(
    column: $table.nomePais,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get email => $composableBuilder(
    column: $table.email,
    builder: (column) => ColumnOrderings(column),
  );
}

class $$BpeCompradorsTableAnnotationComposer
    extends Composer<_$AppDatabase, $BpeCompradorsTable> {
  $$BpeCompradorsTableAnnotationComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  GeneratedColumn<int> get id =>
      $composableBuilder(column: $table.id, builder: (column) => column);

  GeneratedColumn<int> get idBpeCabecalho => $composableBuilder(
    column: $table.idBpeCabecalho,
    builder: (column) => column,
  );

  GeneratedColumn<String> get cnpj =>
      $composableBuilder(column: $table.cnpj, builder: (column) => column);

  GeneratedColumn<String> get cpf =>
      $composableBuilder(column: $table.cpf, builder: (column) => column);

  GeneratedColumn<String> get ie =>
      $composableBuilder(column: $table.ie, builder: (column) => column);

  GeneratedColumn<String> get nome =>
      $composableBuilder(column: $table.nome, builder: (column) => column);

  GeneratedColumn<String> get fantasia =>
      $composableBuilder(column: $table.fantasia, builder: (column) => column);

  GeneratedColumn<String> get telefone =>
      $composableBuilder(column: $table.telefone, builder: (column) => column);

  GeneratedColumn<String> get logradouro => $composableBuilder(
    column: $table.logradouro,
    builder: (column) => column,
  );

  GeneratedColumn<String> get numero =>
      $composableBuilder(column: $table.numero, builder: (column) => column);

  GeneratedColumn<String> get complemento => $composableBuilder(
    column: $table.complemento,
    builder: (column) => column,
  );

  GeneratedColumn<String> get bairro =>
      $composableBuilder(column: $table.bairro, builder: (column) => column);

  GeneratedColumn<int> get codigoMunicipio => $composableBuilder(
    column: $table.codigoMunicipio,
    builder: (column) => column,
  );

  GeneratedColumn<String> get nomeMunicipio => $composableBuilder(
    column: $table.nomeMunicipio,
    builder: (column) => column,
  );

  GeneratedColumn<String> get uf =>
      $composableBuilder(column: $table.uf, builder: (column) => column);

  GeneratedColumn<String> get cep =>
      $composableBuilder(column: $table.cep, builder: (column) => column);

  GeneratedColumn<int> get codigoPais => $composableBuilder(
    column: $table.codigoPais,
    builder: (column) => column,
  );

  GeneratedColumn<String> get nomePais =>
      $composableBuilder(column: $table.nomePais, builder: (column) => column);

  GeneratedColumn<String> get email =>
      $composableBuilder(column: $table.email, builder: (column) => column);
}

class $$BpeCompradorsTableTableManager
    extends
        RootTableManager<
          _$AppDatabase,
          $BpeCompradorsTable,
          BpeComprador,
          $$BpeCompradorsTableFilterComposer,
          $$BpeCompradorsTableOrderingComposer,
          $$BpeCompradorsTableAnnotationComposer,
          $$BpeCompradorsTableCreateCompanionBuilder,
          $$BpeCompradorsTableUpdateCompanionBuilder,
          (
            BpeComprador,
            BaseReferences<_$AppDatabase, $BpeCompradorsTable, BpeComprador>,
          ),
          BpeComprador,
          PrefetchHooks Function()
        > {
  $$BpeCompradorsTableTableManager(_$AppDatabase db, $BpeCompradorsTable table)
    : super(
        TableManagerState(
          db: db,
          table: table,
          createFilteringComposer:
              () => $$BpeCompradorsTableFilterComposer($db: db, $table: table),
          createOrderingComposer:
              () =>
                  $$BpeCompradorsTableOrderingComposer($db: db, $table: table),
          createComputedFieldComposer:
              () => $$BpeCompradorsTableAnnotationComposer(
                $db: db,
                $table: table,
              ),
          updateCompanionCallback:
              ({
                Value<int?> id = const Value.absent(),
                Value<int?> idBpeCabecalho = const Value.absent(),
                Value<String?> cnpj = const Value.absent(),
                Value<String?> cpf = const Value.absent(),
                Value<String?> ie = const Value.absent(),
                Value<String?> nome = const Value.absent(),
                Value<String?> fantasia = const Value.absent(),
                Value<String?> telefone = const Value.absent(),
                Value<String?> logradouro = const Value.absent(),
                Value<String?> numero = const Value.absent(),
                Value<String?> complemento = const Value.absent(),
                Value<String?> bairro = const Value.absent(),
                Value<int?> codigoMunicipio = const Value.absent(),
                Value<String?> nomeMunicipio = const Value.absent(),
                Value<String?> uf = const Value.absent(),
                Value<String?> cep = const Value.absent(),
                Value<int?> codigoPais = const Value.absent(),
                Value<String?> nomePais = const Value.absent(),
                Value<String?> email = const Value.absent(),
              }) => BpeCompradorsCompanion(
                id: id,
                idBpeCabecalho: idBpeCabecalho,
                cnpj: cnpj,
                cpf: cpf,
                ie: ie,
                nome: nome,
                fantasia: fantasia,
                telefone: telefone,
                logradouro: logradouro,
                numero: numero,
                complemento: complemento,
                bairro: bairro,
                codigoMunicipio: codigoMunicipio,
                nomeMunicipio: nomeMunicipio,
                uf: uf,
                cep: cep,
                codigoPais: codigoPais,
                nomePais: nomePais,
                email: email,
              ),
          createCompanionCallback:
              ({
                Value<int?> id = const Value.absent(),
                Value<int?> idBpeCabecalho = const Value.absent(),
                Value<String?> cnpj = const Value.absent(),
                Value<String?> cpf = const Value.absent(),
                Value<String?> ie = const Value.absent(),
                Value<String?> nome = const Value.absent(),
                Value<String?> fantasia = const Value.absent(),
                Value<String?> telefone = const Value.absent(),
                Value<String?> logradouro = const Value.absent(),
                Value<String?> numero = const Value.absent(),
                Value<String?> complemento = const Value.absent(),
                Value<String?> bairro = const Value.absent(),
                Value<int?> codigoMunicipio = const Value.absent(),
                Value<String?> nomeMunicipio = const Value.absent(),
                Value<String?> uf = const Value.absent(),
                Value<String?> cep = const Value.absent(),
                Value<int?> codigoPais = const Value.absent(),
                Value<String?> nomePais = const Value.absent(),
                Value<String?> email = const Value.absent(),
              }) => BpeCompradorsCompanion.insert(
                id: id,
                idBpeCabecalho: idBpeCabecalho,
                cnpj: cnpj,
                cpf: cpf,
                ie: ie,
                nome: nome,
                fantasia: fantasia,
                telefone: telefone,
                logradouro: logradouro,
                numero: numero,
                complemento: complemento,
                bairro: bairro,
                codigoMunicipio: codigoMunicipio,
                nomeMunicipio: nomeMunicipio,
                uf: uf,
                cep: cep,
                codigoPais: codigoPais,
                nomePais: nomePais,
                email: email,
              ),
          withReferenceMapper:
              (p0) =>
                  p0
                      .map(
                        (e) => (
                          e.readTable(table),
                          BaseReferences(db, table, e),
                        ),
                      )
                      .toList(),
          prefetchHooksCallback: null,
        ),
      );
}

typedef $$BpeCompradorsTableProcessedTableManager =
    ProcessedTableManager<
      _$AppDatabase,
      $BpeCompradorsTable,
      BpeComprador,
      $$BpeCompradorsTableFilterComposer,
      $$BpeCompradorsTableOrderingComposer,
      $$BpeCompradorsTableAnnotationComposer,
      $$BpeCompradorsTableCreateCompanionBuilder,
      $$BpeCompradorsTableUpdateCompanionBuilder,
      (
        BpeComprador,
        BaseReferences<_$AppDatabase, $BpeCompradorsTable, BpeComprador>,
      ),
      BpeComprador,
      PrefetchHooks Function()
    >;
typedef $$BpeViagemsTableCreateCompanionBuilder =
    BpeViagemsCompanion Function({
      Value<int?> id,
      Value<int?> idBpeCabecalho,
      Value<String?> codigoPercurso,
      Value<String?> descricaoPercurso,
      Value<String?> tipoViagem,
      Value<String?> tipoServico,
      Value<String?> tipoAcomodacao,
      Value<String?> tipoTrecho,
      Value<DateTime?> dataHoraViagem,
      Value<DateTime?> dataHoraConexao,
      Value<String?> prefixoLinha,
      Value<String?> poltrona,
      Value<String?> plataforma,
    });
typedef $$BpeViagemsTableUpdateCompanionBuilder =
    BpeViagemsCompanion Function({
      Value<int?> id,
      Value<int?> idBpeCabecalho,
      Value<String?> codigoPercurso,
      Value<String?> descricaoPercurso,
      Value<String?> tipoViagem,
      Value<String?> tipoServico,
      Value<String?> tipoAcomodacao,
      Value<String?> tipoTrecho,
      Value<DateTime?> dataHoraViagem,
      Value<DateTime?> dataHoraConexao,
      Value<String?> prefixoLinha,
      Value<String?> poltrona,
      Value<String?> plataforma,
    });

class $$BpeViagemsTableFilterComposer
    extends Composer<_$AppDatabase, $BpeViagemsTable> {
  $$BpeViagemsTableFilterComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnFilters<int> get id => $composableBuilder(
    column: $table.id,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<int> get idBpeCabecalho => $composableBuilder(
    column: $table.idBpeCabecalho,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get codigoPercurso => $composableBuilder(
    column: $table.codigoPercurso,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get descricaoPercurso => $composableBuilder(
    column: $table.descricaoPercurso,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get tipoViagem => $composableBuilder(
    column: $table.tipoViagem,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get tipoServico => $composableBuilder(
    column: $table.tipoServico,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get tipoAcomodacao => $composableBuilder(
    column: $table.tipoAcomodacao,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get tipoTrecho => $composableBuilder(
    column: $table.tipoTrecho,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<DateTime> get dataHoraViagem => $composableBuilder(
    column: $table.dataHoraViagem,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<DateTime> get dataHoraConexao => $composableBuilder(
    column: $table.dataHoraConexao,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get prefixoLinha => $composableBuilder(
    column: $table.prefixoLinha,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get poltrona => $composableBuilder(
    column: $table.poltrona,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get plataforma => $composableBuilder(
    column: $table.plataforma,
    builder: (column) => ColumnFilters(column),
  );
}

class $$BpeViagemsTableOrderingComposer
    extends Composer<_$AppDatabase, $BpeViagemsTable> {
  $$BpeViagemsTableOrderingComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnOrderings<int> get id => $composableBuilder(
    column: $table.id,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<int> get idBpeCabecalho => $composableBuilder(
    column: $table.idBpeCabecalho,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get codigoPercurso => $composableBuilder(
    column: $table.codigoPercurso,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get descricaoPercurso => $composableBuilder(
    column: $table.descricaoPercurso,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get tipoViagem => $composableBuilder(
    column: $table.tipoViagem,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get tipoServico => $composableBuilder(
    column: $table.tipoServico,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get tipoAcomodacao => $composableBuilder(
    column: $table.tipoAcomodacao,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get tipoTrecho => $composableBuilder(
    column: $table.tipoTrecho,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<DateTime> get dataHoraViagem => $composableBuilder(
    column: $table.dataHoraViagem,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<DateTime> get dataHoraConexao => $composableBuilder(
    column: $table.dataHoraConexao,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get prefixoLinha => $composableBuilder(
    column: $table.prefixoLinha,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get poltrona => $composableBuilder(
    column: $table.poltrona,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get plataforma => $composableBuilder(
    column: $table.plataforma,
    builder: (column) => ColumnOrderings(column),
  );
}

class $$BpeViagemsTableAnnotationComposer
    extends Composer<_$AppDatabase, $BpeViagemsTable> {
  $$BpeViagemsTableAnnotationComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  GeneratedColumn<int> get id =>
      $composableBuilder(column: $table.id, builder: (column) => column);

  GeneratedColumn<int> get idBpeCabecalho => $composableBuilder(
    column: $table.idBpeCabecalho,
    builder: (column) => column,
  );

  GeneratedColumn<String> get codigoPercurso => $composableBuilder(
    column: $table.codigoPercurso,
    builder: (column) => column,
  );

  GeneratedColumn<String> get descricaoPercurso => $composableBuilder(
    column: $table.descricaoPercurso,
    builder: (column) => column,
  );

  GeneratedColumn<String> get tipoViagem => $composableBuilder(
    column: $table.tipoViagem,
    builder: (column) => column,
  );

  GeneratedColumn<String> get tipoServico => $composableBuilder(
    column: $table.tipoServico,
    builder: (column) => column,
  );

  GeneratedColumn<String> get tipoAcomodacao => $composableBuilder(
    column: $table.tipoAcomodacao,
    builder: (column) => column,
  );

  GeneratedColumn<String> get tipoTrecho => $composableBuilder(
    column: $table.tipoTrecho,
    builder: (column) => column,
  );

  GeneratedColumn<DateTime> get dataHoraViagem => $composableBuilder(
    column: $table.dataHoraViagem,
    builder: (column) => column,
  );

  GeneratedColumn<DateTime> get dataHoraConexao => $composableBuilder(
    column: $table.dataHoraConexao,
    builder: (column) => column,
  );

  GeneratedColumn<String> get prefixoLinha => $composableBuilder(
    column: $table.prefixoLinha,
    builder: (column) => column,
  );

  GeneratedColumn<String> get poltrona =>
      $composableBuilder(column: $table.poltrona, builder: (column) => column);

  GeneratedColumn<String> get plataforma => $composableBuilder(
    column: $table.plataforma,
    builder: (column) => column,
  );
}

class $$BpeViagemsTableTableManager
    extends
        RootTableManager<
          _$AppDatabase,
          $BpeViagemsTable,
          BpeViagem,
          $$BpeViagemsTableFilterComposer,
          $$BpeViagemsTableOrderingComposer,
          $$BpeViagemsTableAnnotationComposer,
          $$BpeViagemsTableCreateCompanionBuilder,
          $$BpeViagemsTableUpdateCompanionBuilder,
          (
            BpeViagem,
            BaseReferences<_$AppDatabase, $BpeViagemsTable, BpeViagem>,
          ),
          BpeViagem,
          PrefetchHooks Function()
        > {
  $$BpeViagemsTableTableManager(_$AppDatabase db, $BpeViagemsTable table)
    : super(
        TableManagerState(
          db: db,
          table: table,
          createFilteringComposer:
              () => $$BpeViagemsTableFilterComposer($db: db, $table: table),
          createOrderingComposer:
              () => $$BpeViagemsTableOrderingComposer($db: db, $table: table),
          createComputedFieldComposer:
              () => $$BpeViagemsTableAnnotationComposer($db: db, $table: table),
          updateCompanionCallback:
              ({
                Value<int?> id = const Value.absent(),
                Value<int?> idBpeCabecalho = const Value.absent(),
                Value<String?> codigoPercurso = const Value.absent(),
                Value<String?> descricaoPercurso = const Value.absent(),
                Value<String?> tipoViagem = const Value.absent(),
                Value<String?> tipoServico = const Value.absent(),
                Value<String?> tipoAcomodacao = const Value.absent(),
                Value<String?> tipoTrecho = const Value.absent(),
                Value<DateTime?> dataHoraViagem = const Value.absent(),
                Value<DateTime?> dataHoraConexao = const Value.absent(),
                Value<String?> prefixoLinha = const Value.absent(),
                Value<String?> poltrona = const Value.absent(),
                Value<String?> plataforma = const Value.absent(),
              }) => BpeViagemsCompanion(
                id: id,
                idBpeCabecalho: idBpeCabecalho,
                codigoPercurso: codigoPercurso,
                descricaoPercurso: descricaoPercurso,
                tipoViagem: tipoViagem,
                tipoServico: tipoServico,
                tipoAcomodacao: tipoAcomodacao,
                tipoTrecho: tipoTrecho,
                dataHoraViagem: dataHoraViagem,
                dataHoraConexao: dataHoraConexao,
                prefixoLinha: prefixoLinha,
                poltrona: poltrona,
                plataforma: plataforma,
              ),
          createCompanionCallback:
              ({
                Value<int?> id = const Value.absent(),
                Value<int?> idBpeCabecalho = const Value.absent(),
                Value<String?> codigoPercurso = const Value.absent(),
                Value<String?> descricaoPercurso = const Value.absent(),
                Value<String?> tipoViagem = const Value.absent(),
                Value<String?> tipoServico = const Value.absent(),
                Value<String?> tipoAcomodacao = const Value.absent(),
                Value<String?> tipoTrecho = const Value.absent(),
                Value<DateTime?> dataHoraViagem = const Value.absent(),
                Value<DateTime?> dataHoraConexao = const Value.absent(),
                Value<String?> prefixoLinha = const Value.absent(),
                Value<String?> poltrona = const Value.absent(),
                Value<String?> plataforma = const Value.absent(),
              }) => BpeViagemsCompanion.insert(
                id: id,
                idBpeCabecalho: idBpeCabecalho,
                codigoPercurso: codigoPercurso,
                descricaoPercurso: descricaoPercurso,
                tipoViagem: tipoViagem,
                tipoServico: tipoServico,
                tipoAcomodacao: tipoAcomodacao,
                tipoTrecho: tipoTrecho,
                dataHoraViagem: dataHoraViagem,
                dataHoraConexao: dataHoraConexao,
                prefixoLinha: prefixoLinha,
                poltrona: poltrona,
                plataforma: plataforma,
              ),
          withReferenceMapper:
              (p0) =>
                  p0
                      .map(
                        (e) => (
                          e.readTable(table),
                          BaseReferences(db, table, e),
                        ),
                      )
                      .toList(),
          prefetchHooksCallback: null,
        ),
      );
}

typedef $$BpeViagemsTableProcessedTableManager =
    ProcessedTableManager<
      _$AppDatabase,
      $BpeViagemsTable,
      BpeViagem,
      $$BpeViagemsTableFilterComposer,
      $$BpeViagemsTableOrderingComposer,
      $$BpeViagemsTableAnnotationComposer,
      $$BpeViagemsTableCreateCompanionBuilder,
      $$BpeViagemsTableUpdateCompanionBuilder,
      (BpeViagem, BaseReferences<_$AppDatabase, $BpeViagemsTable, BpeViagem>),
      BpeViagem,
      PrefetchHooks Function()
    >;
typedef $$BpeAgenciasTableCreateCompanionBuilder =
    BpeAgenciasCompanion Function({
      Value<int?> id,
      Value<int?> idBpeCabecalho,
      Value<String?> cnpj,
      Value<String?> nome,
      Value<String?> telefone,
      Value<String?> logradouro,
      Value<String?> numero,
      Value<String?> complemento,
      Value<String?> bairro,
      Value<int?> codigoMunicipio,
      Value<String?> nomeMunicipio,
      Value<String?> uf,
      Value<String?> cep,
      Value<int?> codigoPais,
      Value<String?> nomePais,
      Value<String?> email,
    });
typedef $$BpeAgenciasTableUpdateCompanionBuilder =
    BpeAgenciasCompanion Function({
      Value<int?> id,
      Value<int?> idBpeCabecalho,
      Value<String?> cnpj,
      Value<String?> nome,
      Value<String?> telefone,
      Value<String?> logradouro,
      Value<String?> numero,
      Value<String?> complemento,
      Value<String?> bairro,
      Value<int?> codigoMunicipio,
      Value<String?> nomeMunicipio,
      Value<String?> uf,
      Value<String?> cep,
      Value<int?> codigoPais,
      Value<String?> nomePais,
      Value<String?> email,
    });

class $$BpeAgenciasTableFilterComposer
    extends Composer<_$AppDatabase, $BpeAgenciasTable> {
  $$BpeAgenciasTableFilterComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnFilters<int> get id => $composableBuilder(
    column: $table.id,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<int> get idBpeCabecalho => $composableBuilder(
    column: $table.idBpeCabecalho,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get cnpj => $composableBuilder(
    column: $table.cnpj,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get nome => $composableBuilder(
    column: $table.nome,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get telefone => $composableBuilder(
    column: $table.telefone,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get logradouro => $composableBuilder(
    column: $table.logradouro,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get numero => $composableBuilder(
    column: $table.numero,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get complemento => $composableBuilder(
    column: $table.complemento,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get bairro => $composableBuilder(
    column: $table.bairro,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<int> get codigoMunicipio => $composableBuilder(
    column: $table.codigoMunicipio,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get nomeMunicipio => $composableBuilder(
    column: $table.nomeMunicipio,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get uf => $composableBuilder(
    column: $table.uf,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get cep => $composableBuilder(
    column: $table.cep,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<int> get codigoPais => $composableBuilder(
    column: $table.codigoPais,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get nomePais => $composableBuilder(
    column: $table.nomePais,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get email => $composableBuilder(
    column: $table.email,
    builder: (column) => ColumnFilters(column),
  );
}

class $$BpeAgenciasTableOrderingComposer
    extends Composer<_$AppDatabase, $BpeAgenciasTable> {
  $$BpeAgenciasTableOrderingComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnOrderings<int> get id => $composableBuilder(
    column: $table.id,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<int> get idBpeCabecalho => $composableBuilder(
    column: $table.idBpeCabecalho,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get cnpj => $composableBuilder(
    column: $table.cnpj,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get nome => $composableBuilder(
    column: $table.nome,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get telefone => $composableBuilder(
    column: $table.telefone,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get logradouro => $composableBuilder(
    column: $table.logradouro,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get numero => $composableBuilder(
    column: $table.numero,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get complemento => $composableBuilder(
    column: $table.complemento,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get bairro => $composableBuilder(
    column: $table.bairro,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<int> get codigoMunicipio => $composableBuilder(
    column: $table.codigoMunicipio,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get nomeMunicipio => $composableBuilder(
    column: $table.nomeMunicipio,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get uf => $composableBuilder(
    column: $table.uf,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get cep => $composableBuilder(
    column: $table.cep,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<int> get codigoPais => $composableBuilder(
    column: $table.codigoPais,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get nomePais => $composableBuilder(
    column: $table.nomePais,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get email => $composableBuilder(
    column: $table.email,
    builder: (column) => ColumnOrderings(column),
  );
}

class $$BpeAgenciasTableAnnotationComposer
    extends Composer<_$AppDatabase, $BpeAgenciasTable> {
  $$BpeAgenciasTableAnnotationComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  GeneratedColumn<int> get id =>
      $composableBuilder(column: $table.id, builder: (column) => column);

  GeneratedColumn<int> get idBpeCabecalho => $composableBuilder(
    column: $table.idBpeCabecalho,
    builder: (column) => column,
  );

  GeneratedColumn<String> get cnpj =>
      $composableBuilder(column: $table.cnpj, builder: (column) => column);

  GeneratedColumn<String> get nome =>
      $composableBuilder(column: $table.nome, builder: (column) => column);

  GeneratedColumn<String> get telefone =>
      $composableBuilder(column: $table.telefone, builder: (column) => column);

  GeneratedColumn<String> get logradouro => $composableBuilder(
    column: $table.logradouro,
    builder: (column) => column,
  );

  GeneratedColumn<String> get numero =>
      $composableBuilder(column: $table.numero, builder: (column) => column);

  GeneratedColumn<String> get complemento => $composableBuilder(
    column: $table.complemento,
    builder: (column) => column,
  );

  GeneratedColumn<String> get bairro =>
      $composableBuilder(column: $table.bairro, builder: (column) => column);

  GeneratedColumn<int> get codigoMunicipio => $composableBuilder(
    column: $table.codigoMunicipio,
    builder: (column) => column,
  );

  GeneratedColumn<String> get nomeMunicipio => $composableBuilder(
    column: $table.nomeMunicipio,
    builder: (column) => column,
  );

  GeneratedColumn<String> get uf =>
      $composableBuilder(column: $table.uf, builder: (column) => column);

  GeneratedColumn<String> get cep =>
      $composableBuilder(column: $table.cep, builder: (column) => column);

  GeneratedColumn<int> get codigoPais => $composableBuilder(
    column: $table.codigoPais,
    builder: (column) => column,
  );

  GeneratedColumn<String> get nomePais =>
      $composableBuilder(column: $table.nomePais, builder: (column) => column);

  GeneratedColumn<String> get email =>
      $composableBuilder(column: $table.email, builder: (column) => column);
}

class $$BpeAgenciasTableTableManager
    extends
        RootTableManager<
          _$AppDatabase,
          $BpeAgenciasTable,
          BpeAgencia,
          $$BpeAgenciasTableFilterComposer,
          $$BpeAgenciasTableOrderingComposer,
          $$BpeAgenciasTableAnnotationComposer,
          $$BpeAgenciasTableCreateCompanionBuilder,
          $$BpeAgenciasTableUpdateCompanionBuilder,
          (
            BpeAgencia,
            BaseReferences<_$AppDatabase, $BpeAgenciasTable, BpeAgencia>,
          ),
          BpeAgencia,
          PrefetchHooks Function()
        > {
  $$BpeAgenciasTableTableManager(_$AppDatabase db, $BpeAgenciasTable table)
    : super(
        TableManagerState(
          db: db,
          table: table,
          createFilteringComposer:
              () => $$BpeAgenciasTableFilterComposer($db: db, $table: table),
          createOrderingComposer:
              () => $$BpeAgenciasTableOrderingComposer($db: db, $table: table),
          createComputedFieldComposer:
              () =>
                  $$BpeAgenciasTableAnnotationComposer($db: db, $table: table),
          updateCompanionCallback:
              ({
                Value<int?> id = const Value.absent(),
                Value<int?> idBpeCabecalho = const Value.absent(),
                Value<String?> cnpj = const Value.absent(),
                Value<String?> nome = const Value.absent(),
                Value<String?> telefone = const Value.absent(),
                Value<String?> logradouro = const Value.absent(),
                Value<String?> numero = const Value.absent(),
                Value<String?> complemento = const Value.absent(),
                Value<String?> bairro = const Value.absent(),
                Value<int?> codigoMunicipio = const Value.absent(),
                Value<String?> nomeMunicipio = const Value.absent(),
                Value<String?> uf = const Value.absent(),
                Value<String?> cep = const Value.absent(),
                Value<int?> codigoPais = const Value.absent(),
                Value<String?> nomePais = const Value.absent(),
                Value<String?> email = const Value.absent(),
              }) => BpeAgenciasCompanion(
                id: id,
                idBpeCabecalho: idBpeCabecalho,
                cnpj: cnpj,
                nome: nome,
                telefone: telefone,
                logradouro: logradouro,
                numero: numero,
                complemento: complemento,
                bairro: bairro,
                codigoMunicipio: codigoMunicipio,
                nomeMunicipio: nomeMunicipio,
                uf: uf,
                cep: cep,
                codigoPais: codigoPais,
                nomePais: nomePais,
                email: email,
              ),
          createCompanionCallback:
              ({
                Value<int?> id = const Value.absent(),
                Value<int?> idBpeCabecalho = const Value.absent(),
                Value<String?> cnpj = const Value.absent(),
                Value<String?> nome = const Value.absent(),
                Value<String?> telefone = const Value.absent(),
                Value<String?> logradouro = const Value.absent(),
                Value<String?> numero = const Value.absent(),
                Value<String?> complemento = const Value.absent(),
                Value<String?> bairro = const Value.absent(),
                Value<int?> codigoMunicipio = const Value.absent(),
                Value<String?> nomeMunicipio = const Value.absent(),
                Value<String?> uf = const Value.absent(),
                Value<String?> cep = const Value.absent(),
                Value<int?> codigoPais = const Value.absent(),
                Value<String?> nomePais = const Value.absent(),
                Value<String?> email = const Value.absent(),
              }) => BpeAgenciasCompanion.insert(
                id: id,
                idBpeCabecalho: idBpeCabecalho,
                cnpj: cnpj,
                nome: nome,
                telefone: telefone,
                logradouro: logradouro,
                numero: numero,
                complemento: complemento,
                bairro: bairro,
                codigoMunicipio: codigoMunicipio,
                nomeMunicipio: nomeMunicipio,
                uf: uf,
                cep: cep,
                codigoPais: codigoPais,
                nomePais: nomePais,
                email: email,
              ),
          withReferenceMapper:
              (p0) =>
                  p0
                      .map(
                        (e) => (
                          e.readTable(table),
                          BaseReferences(db, table, e),
                        ),
                      )
                      .toList(),
          prefetchHooksCallback: null,
        ),
      );
}

typedef $$BpeAgenciasTableProcessedTableManager =
    ProcessedTableManager<
      _$AppDatabase,
      $BpeAgenciasTable,
      BpeAgencia,
      $$BpeAgenciasTableFilterComposer,
      $$BpeAgenciasTableOrderingComposer,
      $$BpeAgenciasTableAnnotationComposer,
      $$BpeAgenciasTableCreateCompanionBuilder,
      $$BpeAgenciasTableUpdateCompanionBuilder,
      (
        BpeAgencia,
        BaseReferences<_$AppDatabase, $BpeAgenciasTable, BpeAgencia>,
      ),
      BpeAgencia,
      PrefetchHooks Function()
    >;
typedef $$BpePassagemsTableCreateCompanionBuilder =
    BpePassagemsCompanion Function({
      Value<int?> id,
      Value<int?> idBpeCabecalho,
      Value<String?> codigoLocalidadeOrigem,
      Value<String?> descricaoLocalidadeOrigem,
      Value<String?> codigoLocalidadeDestino,
      Value<String?> descricaoLocalidadeDestino,
      Value<DateTime?> dataHoraEmbarque,
      Value<DateTime?> dataHoraValidade,
    });
typedef $$BpePassagemsTableUpdateCompanionBuilder =
    BpePassagemsCompanion Function({
      Value<int?> id,
      Value<int?> idBpeCabecalho,
      Value<String?> codigoLocalidadeOrigem,
      Value<String?> descricaoLocalidadeOrigem,
      Value<String?> codigoLocalidadeDestino,
      Value<String?> descricaoLocalidadeDestino,
      Value<DateTime?> dataHoraEmbarque,
      Value<DateTime?> dataHoraValidade,
    });

class $$BpePassagemsTableFilterComposer
    extends Composer<_$AppDatabase, $BpePassagemsTable> {
  $$BpePassagemsTableFilterComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnFilters<int> get id => $composableBuilder(
    column: $table.id,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<int> get idBpeCabecalho => $composableBuilder(
    column: $table.idBpeCabecalho,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get codigoLocalidadeOrigem => $composableBuilder(
    column: $table.codigoLocalidadeOrigem,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get descricaoLocalidadeOrigem => $composableBuilder(
    column: $table.descricaoLocalidadeOrigem,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get codigoLocalidadeDestino => $composableBuilder(
    column: $table.codigoLocalidadeDestino,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get descricaoLocalidadeDestino => $composableBuilder(
    column: $table.descricaoLocalidadeDestino,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<DateTime> get dataHoraEmbarque => $composableBuilder(
    column: $table.dataHoraEmbarque,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<DateTime> get dataHoraValidade => $composableBuilder(
    column: $table.dataHoraValidade,
    builder: (column) => ColumnFilters(column),
  );
}

class $$BpePassagemsTableOrderingComposer
    extends Composer<_$AppDatabase, $BpePassagemsTable> {
  $$BpePassagemsTableOrderingComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnOrderings<int> get id => $composableBuilder(
    column: $table.id,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<int> get idBpeCabecalho => $composableBuilder(
    column: $table.idBpeCabecalho,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get codigoLocalidadeOrigem => $composableBuilder(
    column: $table.codigoLocalidadeOrigem,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get descricaoLocalidadeOrigem => $composableBuilder(
    column: $table.descricaoLocalidadeOrigem,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get codigoLocalidadeDestino => $composableBuilder(
    column: $table.codigoLocalidadeDestino,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get descricaoLocalidadeDestino => $composableBuilder(
    column: $table.descricaoLocalidadeDestino,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<DateTime> get dataHoraEmbarque => $composableBuilder(
    column: $table.dataHoraEmbarque,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<DateTime> get dataHoraValidade => $composableBuilder(
    column: $table.dataHoraValidade,
    builder: (column) => ColumnOrderings(column),
  );
}

class $$BpePassagemsTableAnnotationComposer
    extends Composer<_$AppDatabase, $BpePassagemsTable> {
  $$BpePassagemsTableAnnotationComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  GeneratedColumn<int> get id =>
      $composableBuilder(column: $table.id, builder: (column) => column);

  GeneratedColumn<int> get idBpeCabecalho => $composableBuilder(
    column: $table.idBpeCabecalho,
    builder: (column) => column,
  );

  GeneratedColumn<String> get codigoLocalidadeOrigem => $composableBuilder(
    column: $table.codigoLocalidadeOrigem,
    builder: (column) => column,
  );

  GeneratedColumn<String> get descricaoLocalidadeOrigem => $composableBuilder(
    column: $table.descricaoLocalidadeOrigem,
    builder: (column) => column,
  );

  GeneratedColumn<String> get codigoLocalidadeDestino => $composableBuilder(
    column: $table.codigoLocalidadeDestino,
    builder: (column) => column,
  );

  GeneratedColumn<String> get descricaoLocalidadeDestino => $composableBuilder(
    column: $table.descricaoLocalidadeDestino,
    builder: (column) => column,
  );

  GeneratedColumn<DateTime> get dataHoraEmbarque => $composableBuilder(
    column: $table.dataHoraEmbarque,
    builder: (column) => column,
  );

  GeneratedColumn<DateTime> get dataHoraValidade => $composableBuilder(
    column: $table.dataHoraValidade,
    builder: (column) => column,
  );
}

class $$BpePassagemsTableTableManager
    extends
        RootTableManager<
          _$AppDatabase,
          $BpePassagemsTable,
          BpePassagem,
          $$BpePassagemsTableFilterComposer,
          $$BpePassagemsTableOrderingComposer,
          $$BpePassagemsTableAnnotationComposer,
          $$BpePassagemsTableCreateCompanionBuilder,
          $$BpePassagemsTableUpdateCompanionBuilder,
          (
            BpePassagem,
            BaseReferences<_$AppDatabase, $BpePassagemsTable, BpePassagem>,
          ),
          BpePassagem,
          PrefetchHooks Function()
        > {
  $$BpePassagemsTableTableManager(_$AppDatabase db, $BpePassagemsTable table)
    : super(
        TableManagerState(
          db: db,
          table: table,
          createFilteringComposer:
              () => $$BpePassagemsTableFilterComposer($db: db, $table: table),
          createOrderingComposer:
              () => $$BpePassagemsTableOrderingComposer($db: db, $table: table),
          createComputedFieldComposer:
              () =>
                  $$BpePassagemsTableAnnotationComposer($db: db, $table: table),
          updateCompanionCallback:
              ({
                Value<int?> id = const Value.absent(),
                Value<int?> idBpeCabecalho = const Value.absent(),
                Value<String?> codigoLocalidadeOrigem = const Value.absent(),
                Value<String?> descricaoLocalidadeOrigem = const Value.absent(),
                Value<String?> codigoLocalidadeDestino = const Value.absent(),
                Value<String?> descricaoLocalidadeDestino =
                    const Value.absent(),
                Value<DateTime?> dataHoraEmbarque = const Value.absent(),
                Value<DateTime?> dataHoraValidade = const Value.absent(),
              }) => BpePassagemsCompanion(
                id: id,
                idBpeCabecalho: idBpeCabecalho,
                codigoLocalidadeOrigem: codigoLocalidadeOrigem,
                descricaoLocalidadeOrigem: descricaoLocalidadeOrigem,
                codigoLocalidadeDestino: codigoLocalidadeDestino,
                descricaoLocalidadeDestino: descricaoLocalidadeDestino,
                dataHoraEmbarque: dataHoraEmbarque,
                dataHoraValidade: dataHoraValidade,
              ),
          createCompanionCallback:
              ({
                Value<int?> id = const Value.absent(),
                Value<int?> idBpeCabecalho = const Value.absent(),
                Value<String?> codigoLocalidadeOrigem = const Value.absent(),
                Value<String?> descricaoLocalidadeOrigem = const Value.absent(),
                Value<String?> codigoLocalidadeDestino = const Value.absent(),
                Value<String?> descricaoLocalidadeDestino =
                    const Value.absent(),
                Value<DateTime?> dataHoraEmbarque = const Value.absent(),
                Value<DateTime?> dataHoraValidade = const Value.absent(),
              }) => BpePassagemsCompanion.insert(
                id: id,
                idBpeCabecalho: idBpeCabecalho,
                codigoLocalidadeOrigem: codigoLocalidadeOrigem,
                descricaoLocalidadeOrigem: descricaoLocalidadeOrigem,
                codigoLocalidadeDestino: codigoLocalidadeDestino,
                descricaoLocalidadeDestino: descricaoLocalidadeDestino,
                dataHoraEmbarque: dataHoraEmbarque,
                dataHoraValidade: dataHoraValidade,
              ),
          withReferenceMapper:
              (p0) =>
                  p0
                      .map(
                        (e) => (
                          e.readTable(table),
                          BaseReferences(db, table, e),
                        ),
                      )
                      .toList(),
          prefetchHooksCallback: null,
        ),
      );
}

typedef $$BpePassagemsTableProcessedTableManager =
    ProcessedTableManager<
      _$AppDatabase,
      $BpePassagemsTable,
      BpePassagem,
      $$BpePassagemsTableFilterComposer,
      $$BpePassagemsTableOrderingComposer,
      $$BpePassagemsTableAnnotationComposer,
      $$BpePassagemsTableCreateCompanionBuilder,
      $$BpePassagemsTableUpdateCompanionBuilder,
      (
        BpePassagem,
        BaseReferences<_$AppDatabase, $BpePassagemsTable, BpePassagem>,
      ),
      BpePassagem,
      PrefetchHooks Function()
    >;
typedef $$BpeCabecalhosTableCreateCompanionBuilder =
    BpeCabecalhosCompanion Function({
      Value<int?> id,
      Value<String?> ufEmitente,
      Value<String?> ambiente,
      Value<String?> modelo,
      Value<String?> serie,
      Value<String?> numero,
      Value<String?> codigoNumerico,
      Value<String?> chaveAcesso,
      Value<String?> digitoChaveAcesso,
      Value<String?> modal,
      Value<DateTime?> dataHoraEmissao,
      Value<String?> tipoEmissao,
      Value<String?> versaoProcessoEmissao,
      Value<String?> tipoBpe,
      Value<String?> consumidorPresenca,
      Value<String?> ufInicioViagem,
      Value<int?> codigoMunicipioInicioViagem,
      Value<String?> ufFimViagem,
      Value<int?> codigoMunicipioFimViagem,
      Value<double?> valorBilhete,
      Value<double?> valorDesconto,
      Value<double?> valorPago,
      Value<double?> valorTroco,
      Value<String?> tipoDesconto,
      Value<String?> descontoDescricao,
      Value<String?> descontoConcedidoOutros,
      Value<String?> formaPagamento,
      Value<String?> formaPagamentoOutros,
      Value<String?> formaPagamentoDocumento,
      Value<String?> cst,
      Value<double?> baseCalculoIcms,
      Value<double?> aliquotaIcms,
      Value<double?> valorIcms,
      Value<double?> percentualReducaoBcIcms,
      Value<String?> informacoesAddFisco,
    });
typedef $$BpeCabecalhosTableUpdateCompanionBuilder =
    BpeCabecalhosCompanion Function({
      Value<int?> id,
      Value<String?> ufEmitente,
      Value<String?> ambiente,
      Value<String?> modelo,
      Value<String?> serie,
      Value<String?> numero,
      Value<String?> codigoNumerico,
      Value<String?> chaveAcesso,
      Value<String?> digitoChaveAcesso,
      Value<String?> modal,
      Value<DateTime?> dataHoraEmissao,
      Value<String?> tipoEmissao,
      Value<String?> versaoProcessoEmissao,
      Value<String?> tipoBpe,
      Value<String?> consumidorPresenca,
      Value<String?> ufInicioViagem,
      Value<int?> codigoMunicipioInicioViagem,
      Value<String?> ufFimViagem,
      Value<int?> codigoMunicipioFimViagem,
      Value<double?> valorBilhete,
      Value<double?> valorDesconto,
      Value<double?> valorPago,
      Value<double?> valorTroco,
      Value<String?> tipoDesconto,
      Value<String?> descontoDescricao,
      Value<String?> descontoConcedidoOutros,
      Value<String?> formaPagamento,
      Value<String?> formaPagamentoOutros,
      Value<String?> formaPagamentoDocumento,
      Value<String?> cst,
      Value<double?> baseCalculoIcms,
      Value<double?> aliquotaIcms,
      Value<double?> valorIcms,
      Value<double?> percentualReducaoBcIcms,
      Value<String?> informacoesAddFisco,
    });

class $$BpeCabecalhosTableFilterComposer
    extends Composer<_$AppDatabase, $BpeCabecalhosTable> {
  $$BpeCabecalhosTableFilterComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnFilters<int> get id => $composableBuilder(
    column: $table.id,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get ufEmitente => $composableBuilder(
    column: $table.ufEmitente,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get ambiente => $composableBuilder(
    column: $table.ambiente,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get modelo => $composableBuilder(
    column: $table.modelo,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get serie => $composableBuilder(
    column: $table.serie,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get numero => $composableBuilder(
    column: $table.numero,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get codigoNumerico => $composableBuilder(
    column: $table.codigoNumerico,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get chaveAcesso => $composableBuilder(
    column: $table.chaveAcesso,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get digitoChaveAcesso => $composableBuilder(
    column: $table.digitoChaveAcesso,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get modal => $composableBuilder(
    column: $table.modal,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<DateTime> get dataHoraEmissao => $composableBuilder(
    column: $table.dataHoraEmissao,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get tipoEmissao => $composableBuilder(
    column: $table.tipoEmissao,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get versaoProcessoEmissao => $composableBuilder(
    column: $table.versaoProcessoEmissao,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get tipoBpe => $composableBuilder(
    column: $table.tipoBpe,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get consumidorPresenca => $composableBuilder(
    column: $table.consumidorPresenca,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get ufInicioViagem => $composableBuilder(
    column: $table.ufInicioViagem,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<int> get codigoMunicipioInicioViagem => $composableBuilder(
    column: $table.codigoMunicipioInicioViagem,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get ufFimViagem => $composableBuilder(
    column: $table.ufFimViagem,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<int> get codigoMunicipioFimViagem => $composableBuilder(
    column: $table.codigoMunicipioFimViagem,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<double> get valorBilhete => $composableBuilder(
    column: $table.valorBilhete,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<double> get valorDesconto => $composableBuilder(
    column: $table.valorDesconto,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<double> get valorPago => $composableBuilder(
    column: $table.valorPago,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<double> get valorTroco => $composableBuilder(
    column: $table.valorTroco,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get tipoDesconto => $composableBuilder(
    column: $table.tipoDesconto,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get descontoDescricao => $composableBuilder(
    column: $table.descontoDescricao,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get descontoConcedidoOutros => $composableBuilder(
    column: $table.descontoConcedidoOutros,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get formaPagamento => $composableBuilder(
    column: $table.formaPagamento,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get formaPagamentoOutros => $composableBuilder(
    column: $table.formaPagamentoOutros,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get formaPagamentoDocumento => $composableBuilder(
    column: $table.formaPagamentoDocumento,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get cst => $composableBuilder(
    column: $table.cst,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<double> get baseCalculoIcms => $composableBuilder(
    column: $table.baseCalculoIcms,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<double> get aliquotaIcms => $composableBuilder(
    column: $table.aliquotaIcms,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<double> get valorIcms => $composableBuilder(
    column: $table.valorIcms,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<double> get percentualReducaoBcIcms => $composableBuilder(
    column: $table.percentualReducaoBcIcms,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get informacoesAddFisco => $composableBuilder(
    column: $table.informacoesAddFisco,
    builder: (column) => ColumnFilters(column),
  );
}

class $$BpeCabecalhosTableOrderingComposer
    extends Composer<_$AppDatabase, $BpeCabecalhosTable> {
  $$BpeCabecalhosTableOrderingComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnOrderings<int> get id => $composableBuilder(
    column: $table.id,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get ufEmitente => $composableBuilder(
    column: $table.ufEmitente,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get ambiente => $composableBuilder(
    column: $table.ambiente,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get modelo => $composableBuilder(
    column: $table.modelo,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get serie => $composableBuilder(
    column: $table.serie,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get numero => $composableBuilder(
    column: $table.numero,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get codigoNumerico => $composableBuilder(
    column: $table.codigoNumerico,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get chaveAcesso => $composableBuilder(
    column: $table.chaveAcesso,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get digitoChaveAcesso => $composableBuilder(
    column: $table.digitoChaveAcesso,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get modal => $composableBuilder(
    column: $table.modal,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<DateTime> get dataHoraEmissao => $composableBuilder(
    column: $table.dataHoraEmissao,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get tipoEmissao => $composableBuilder(
    column: $table.tipoEmissao,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get versaoProcessoEmissao => $composableBuilder(
    column: $table.versaoProcessoEmissao,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get tipoBpe => $composableBuilder(
    column: $table.tipoBpe,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get consumidorPresenca => $composableBuilder(
    column: $table.consumidorPresenca,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get ufInicioViagem => $composableBuilder(
    column: $table.ufInicioViagem,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<int> get codigoMunicipioInicioViagem => $composableBuilder(
    column: $table.codigoMunicipioInicioViagem,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get ufFimViagem => $composableBuilder(
    column: $table.ufFimViagem,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<int> get codigoMunicipioFimViagem => $composableBuilder(
    column: $table.codigoMunicipioFimViagem,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<double> get valorBilhete => $composableBuilder(
    column: $table.valorBilhete,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<double> get valorDesconto => $composableBuilder(
    column: $table.valorDesconto,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<double> get valorPago => $composableBuilder(
    column: $table.valorPago,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<double> get valorTroco => $composableBuilder(
    column: $table.valorTroco,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get tipoDesconto => $composableBuilder(
    column: $table.tipoDesconto,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get descontoDescricao => $composableBuilder(
    column: $table.descontoDescricao,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get descontoConcedidoOutros => $composableBuilder(
    column: $table.descontoConcedidoOutros,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get formaPagamento => $composableBuilder(
    column: $table.formaPagamento,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get formaPagamentoOutros => $composableBuilder(
    column: $table.formaPagamentoOutros,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get formaPagamentoDocumento => $composableBuilder(
    column: $table.formaPagamentoDocumento,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get cst => $composableBuilder(
    column: $table.cst,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<double> get baseCalculoIcms => $composableBuilder(
    column: $table.baseCalculoIcms,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<double> get aliquotaIcms => $composableBuilder(
    column: $table.aliquotaIcms,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<double> get valorIcms => $composableBuilder(
    column: $table.valorIcms,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<double> get percentualReducaoBcIcms => $composableBuilder(
    column: $table.percentualReducaoBcIcms,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get informacoesAddFisco => $composableBuilder(
    column: $table.informacoesAddFisco,
    builder: (column) => ColumnOrderings(column),
  );
}

class $$BpeCabecalhosTableAnnotationComposer
    extends Composer<_$AppDatabase, $BpeCabecalhosTable> {
  $$BpeCabecalhosTableAnnotationComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  GeneratedColumn<int> get id =>
      $composableBuilder(column: $table.id, builder: (column) => column);

  GeneratedColumn<String> get ufEmitente => $composableBuilder(
    column: $table.ufEmitente,
    builder: (column) => column,
  );

  GeneratedColumn<String> get ambiente =>
      $composableBuilder(column: $table.ambiente, builder: (column) => column);

  GeneratedColumn<String> get modelo =>
      $composableBuilder(column: $table.modelo, builder: (column) => column);

  GeneratedColumn<String> get serie =>
      $composableBuilder(column: $table.serie, builder: (column) => column);

  GeneratedColumn<String> get numero =>
      $composableBuilder(column: $table.numero, builder: (column) => column);

  GeneratedColumn<String> get codigoNumerico => $composableBuilder(
    column: $table.codigoNumerico,
    builder: (column) => column,
  );

  GeneratedColumn<String> get chaveAcesso => $composableBuilder(
    column: $table.chaveAcesso,
    builder: (column) => column,
  );

  GeneratedColumn<String> get digitoChaveAcesso => $composableBuilder(
    column: $table.digitoChaveAcesso,
    builder: (column) => column,
  );

  GeneratedColumn<String> get modal =>
      $composableBuilder(column: $table.modal, builder: (column) => column);

  GeneratedColumn<DateTime> get dataHoraEmissao => $composableBuilder(
    column: $table.dataHoraEmissao,
    builder: (column) => column,
  );

  GeneratedColumn<String> get tipoEmissao => $composableBuilder(
    column: $table.tipoEmissao,
    builder: (column) => column,
  );

  GeneratedColumn<String> get versaoProcessoEmissao => $composableBuilder(
    column: $table.versaoProcessoEmissao,
    builder: (column) => column,
  );

  GeneratedColumn<String> get tipoBpe =>
      $composableBuilder(column: $table.tipoBpe, builder: (column) => column);

  GeneratedColumn<String> get consumidorPresenca => $composableBuilder(
    column: $table.consumidorPresenca,
    builder: (column) => column,
  );

  GeneratedColumn<String> get ufInicioViagem => $composableBuilder(
    column: $table.ufInicioViagem,
    builder: (column) => column,
  );

  GeneratedColumn<int> get codigoMunicipioInicioViagem => $composableBuilder(
    column: $table.codigoMunicipioInicioViagem,
    builder: (column) => column,
  );

  GeneratedColumn<String> get ufFimViagem => $composableBuilder(
    column: $table.ufFimViagem,
    builder: (column) => column,
  );

  GeneratedColumn<int> get codigoMunicipioFimViagem => $composableBuilder(
    column: $table.codigoMunicipioFimViagem,
    builder: (column) => column,
  );

  GeneratedColumn<double> get valorBilhete => $composableBuilder(
    column: $table.valorBilhete,
    builder: (column) => column,
  );

  GeneratedColumn<double> get valorDesconto => $composableBuilder(
    column: $table.valorDesconto,
    builder: (column) => column,
  );

  GeneratedColumn<double> get valorPago =>
      $composableBuilder(column: $table.valorPago, builder: (column) => column);

  GeneratedColumn<double> get valorTroco => $composableBuilder(
    column: $table.valorTroco,
    builder: (column) => column,
  );

  GeneratedColumn<String> get tipoDesconto => $composableBuilder(
    column: $table.tipoDesconto,
    builder: (column) => column,
  );

  GeneratedColumn<String> get descontoDescricao => $composableBuilder(
    column: $table.descontoDescricao,
    builder: (column) => column,
  );

  GeneratedColumn<String> get descontoConcedidoOutros => $composableBuilder(
    column: $table.descontoConcedidoOutros,
    builder: (column) => column,
  );

  GeneratedColumn<String> get formaPagamento => $composableBuilder(
    column: $table.formaPagamento,
    builder: (column) => column,
  );

  GeneratedColumn<String> get formaPagamentoOutros => $composableBuilder(
    column: $table.formaPagamentoOutros,
    builder: (column) => column,
  );

  GeneratedColumn<String> get formaPagamentoDocumento => $composableBuilder(
    column: $table.formaPagamentoDocumento,
    builder: (column) => column,
  );

  GeneratedColumn<String> get cst =>
      $composableBuilder(column: $table.cst, builder: (column) => column);

  GeneratedColumn<double> get baseCalculoIcms => $composableBuilder(
    column: $table.baseCalculoIcms,
    builder: (column) => column,
  );

  GeneratedColumn<double> get aliquotaIcms => $composableBuilder(
    column: $table.aliquotaIcms,
    builder: (column) => column,
  );

  GeneratedColumn<double> get valorIcms =>
      $composableBuilder(column: $table.valorIcms, builder: (column) => column);

  GeneratedColumn<double> get percentualReducaoBcIcms => $composableBuilder(
    column: $table.percentualReducaoBcIcms,
    builder: (column) => column,
  );

  GeneratedColumn<String> get informacoesAddFisco => $composableBuilder(
    column: $table.informacoesAddFisco,
    builder: (column) => column,
  );
}

class $$BpeCabecalhosTableTableManager
    extends
        RootTableManager<
          _$AppDatabase,
          $BpeCabecalhosTable,
          BpeCabecalho,
          $$BpeCabecalhosTableFilterComposer,
          $$BpeCabecalhosTableOrderingComposer,
          $$BpeCabecalhosTableAnnotationComposer,
          $$BpeCabecalhosTableCreateCompanionBuilder,
          $$BpeCabecalhosTableUpdateCompanionBuilder,
          (
            BpeCabecalho,
            BaseReferences<_$AppDatabase, $BpeCabecalhosTable, BpeCabecalho>,
          ),
          BpeCabecalho,
          PrefetchHooks Function()
        > {
  $$BpeCabecalhosTableTableManager(_$AppDatabase db, $BpeCabecalhosTable table)
    : super(
        TableManagerState(
          db: db,
          table: table,
          createFilteringComposer:
              () => $$BpeCabecalhosTableFilterComposer($db: db, $table: table),
          createOrderingComposer:
              () =>
                  $$BpeCabecalhosTableOrderingComposer($db: db, $table: table),
          createComputedFieldComposer:
              () => $$BpeCabecalhosTableAnnotationComposer(
                $db: db,
                $table: table,
              ),
          updateCompanionCallback:
              ({
                Value<int?> id = const Value.absent(),
                Value<String?> ufEmitente = const Value.absent(),
                Value<String?> ambiente = const Value.absent(),
                Value<String?> modelo = const Value.absent(),
                Value<String?> serie = const Value.absent(),
                Value<String?> numero = const Value.absent(),
                Value<String?> codigoNumerico = const Value.absent(),
                Value<String?> chaveAcesso = const Value.absent(),
                Value<String?> digitoChaveAcesso = const Value.absent(),
                Value<String?> modal = const Value.absent(),
                Value<DateTime?> dataHoraEmissao = const Value.absent(),
                Value<String?> tipoEmissao = const Value.absent(),
                Value<String?> versaoProcessoEmissao = const Value.absent(),
                Value<String?> tipoBpe = const Value.absent(),
                Value<String?> consumidorPresenca = const Value.absent(),
                Value<String?> ufInicioViagem = const Value.absent(),
                Value<int?> codigoMunicipioInicioViagem = const Value.absent(),
                Value<String?> ufFimViagem = const Value.absent(),
                Value<int?> codigoMunicipioFimViagem = const Value.absent(),
                Value<double?> valorBilhete = const Value.absent(),
                Value<double?> valorDesconto = const Value.absent(),
                Value<double?> valorPago = const Value.absent(),
                Value<double?> valorTroco = const Value.absent(),
                Value<String?> tipoDesconto = const Value.absent(),
                Value<String?> descontoDescricao = const Value.absent(),
                Value<String?> descontoConcedidoOutros = const Value.absent(),
                Value<String?> formaPagamento = const Value.absent(),
                Value<String?> formaPagamentoOutros = const Value.absent(),
                Value<String?> formaPagamentoDocumento = const Value.absent(),
                Value<String?> cst = const Value.absent(),
                Value<double?> baseCalculoIcms = const Value.absent(),
                Value<double?> aliquotaIcms = const Value.absent(),
                Value<double?> valorIcms = const Value.absent(),
                Value<double?> percentualReducaoBcIcms = const Value.absent(),
                Value<String?> informacoesAddFisco = const Value.absent(),
              }) => BpeCabecalhosCompanion(
                id: id,
                ufEmitente: ufEmitente,
                ambiente: ambiente,
                modelo: modelo,
                serie: serie,
                numero: numero,
                codigoNumerico: codigoNumerico,
                chaveAcesso: chaveAcesso,
                digitoChaveAcesso: digitoChaveAcesso,
                modal: modal,
                dataHoraEmissao: dataHoraEmissao,
                tipoEmissao: tipoEmissao,
                versaoProcessoEmissao: versaoProcessoEmissao,
                tipoBpe: tipoBpe,
                consumidorPresenca: consumidorPresenca,
                ufInicioViagem: ufInicioViagem,
                codigoMunicipioInicioViagem: codigoMunicipioInicioViagem,
                ufFimViagem: ufFimViagem,
                codigoMunicipioFimViagem: codigoMunicipioFimViagem,
                valorBilhete: valorBilhete,
                valorDesconto: valorDesconto,
                valorPago: valorPago,
                valorTroco: valorTroco,
                tipoDesconto: tipoDesconto,
                descontoDescricao: descontoDescricao,
                descontoConcedidoOutros: descontoConcedidoOutros,
                formaPagamento: formaPagamento,
                formaPagamentoOutros: formaPagamentoOutros,
                formaPagamentoDocumento: formaPagamentoDocumento,
                cst: cst,
                baseCalculoIcms: baseCalculoIcms,
                aliquotaIcms: aliquotaIcms,
                valorIcms: valorIcms,
                percentualReducaoBcIcms: percentualReducaoBcIcms,
                informacoesAddFisco: informacoesAddFisco,
              ),
          createCompanionCallback:
              ({
                Value<int?> id = const Value.absent(),
                Value<String?> ufEmitente = const Value.absent(),
                Value<String?> ambiente = const Value.absent(),
                Value<String?> modelo = const Value.absent(),
                Value<String?> serie = const Value.absent(),
                Value<String?> numero = const Value.absent(),
                Value<String?> codigoNumerico = const Value.absent(),
                Value<String?> chaveAcesso = const Value.absent(),
                Value<String?> digitoChaveAcesso = const Value.absent(),
                Value<String?> modal = const Value.absent(),
                Value<DateTime?> dataHoraEmissao = const Value.absent(),
                Value<String?> tipoEmissao = const Value.absent(),
                Value<String?> versaoProcessoEmissao = const Value.absent(),
                Value<String?> tipoBpe = const Value.absent(),
                Value<String?> consumidorPresenca = const Value.absent(),
                Value<String?> ufInicioViagem = const Value.absent(),
                Value<int?> codigoMunicipioInicioViagem = const Value.absent(),
                Value<String?> ufFimViagem = const Value.absent(),
                Value<int?> codigoMunicipioFimViagem = const Value.absent(),
                Value<double?> valorBilhete = const Value.absent(),
                Value<double?> valorDesconto = const Value.absent(),
                Value<double?> valorPago = const Value.absent(),
                Value<double?> valorTroco = const Value.absent(),
                Value<String?> tipoDesconto = const Value.absent(),
                Value<String?> descontoDescricao = const Value.absent(),
                Value<String?> descontoConcedidoOutros = const Value.absent(),
                Value<String?> formaPagamento = const Value.absent(),
                Value<String?> formaPagamentoOutros = const Value.absent(),
                Value<String?> formaPagamentoDocumento = const Value.absent(),
                Value<String?> cst = const Value.absent(),
                Value<double?> baseCalculoIcms = const Value.absent(),
                Value<double?> aliquotaIcms = const Value.absent(),
                Value<double?> valorIcms = const Value.absent(),
                Value<double?> percentualReducaoBcIcms = const Value.absent(),
                Value<String?> informacoesAddFisco = const Value.absent(),
              }) => BpeCabecalhosCompanion.insert(
                id: id,
                ufEmitente: ufEmitente,
                ambiente: ambiente,
                modelo: modelo,
                serie: serie,
                numero: numero,
                codigoNumerico: codigoNumerico,
                chaveAcesso: chaveAcesso,
                digitoChaveAcesso: digitoChaveAcesso,
                modal: modal,
                dataHoraEmissao: dataHoraEmissao,
                tipoEmissao: tipoEmissao,
                versaoProcessoEmissao: versaoProcessoEmissao,
                tipoBpe: tipoBpe,
                consumidorPresenca: consumidorPresenca,
                ufInicioViagem: ufInicioViagem,
                codigoMunicipioInicioViagem: codigoMunicipioInicioViagem,
                ufFimViagem: ufFimViagem,
                codigoMunicipioFimViagem: codigoMunicipioFimViagem,
                valorBilhete: valorBilhete,
                valorDesconto: valorDesconto,
                valorPago: valorPago,
                valorTroco: valorTroco,
                tipoDesconto: tipoDesconto,
                descontoDescricao: descontoDescricao,
                descontoConcedidoOutros: descontoConcedidoOutros,
                formaPagamento: formaPagamento,
                formaPagamentoOutros: formaPagamentoOutros,
                formaPagamentoDocumento: formaPagamentoDocumento,
                cst: cst,
                baseCalculoIcms: baseCalculoIcms,
                aliquotaIcms: aliquotaIcms,
                valorIcms: valorIcms,
                percentualReducaoBcIcms: percentualReducaoBcIcms,
                informacoesAddFisco: informacoesAddFisco,
              ),
          withReferenceMapper:
              (p0) =>
                  p0
                      .map(
                        (e) => (
                          e.readTable(table),
                          BaseReferences(db, table, e),
                        ),
                      )
                      .toList(),
          prefetchHooksCallback: null,
        ),
      );
}

typedef $$BpeCabecalhosTableProcessedTableManager =
    ProcessedTableManager<
      _$AppDatabase,
      $BpeCabecalhosTable,
      BpeCabecalho,
      $$BpeCabecalhosTableFilterComposer,
      $$BpeCabecalhosTableOrderingComposer,
      $$BpeCabecalhosTableAnnotationComposer,
      $$BpeCabecalhosTableCreateCompanionBuilder,
      $$BpeCabecalhosTableUpdateCompanionBuilder,
      (
        BpeCabecalho,
        BaseReferences<_$AppDatabase, $BpeCabecalhosTable, BpeCabecalho>,
      ),
      BpeCabecalho,
      PrefetchHooks Function()
    >;
typedef $$ViewControleAcessosTableCreateCompanionBuilder =
    ViewControleAcessosCompanion Function({
      Value<int?> id,
      Value<int?> idPessoa,
      Value<String?> pessoaNome,
      Value<int?> idColaborador,
      Value<int?> idUsuario,
      Value<String?> administrador,
      Value<int?> idPapel,
      Value<String?> papelNome,
      Value<String?> papelDescricao,
      Value<int?> idFuncao,
      Value<String?> funcaoNome,
      Value<String?> funcaoDescricao,
      Value<int?> idPapelFuncao,
      Value<String?> habilitado,
      Value<String?> podeInserir,
      Value<String?> podeAlterar,
      Value<String?> podeExcluir,
    });
typedef $$ViewControleAcessosTableUpdateCompanionBuilder =
    ViewControleAcessosCompanion Function({
      Value<int?> id,
      Value<int?> idPessoa,
      Value<String?> pessoaNome,
      Value<int?> idColaborador,
      Value<int?> idUsuario,
      Value<String?> administrador,
      Value<int?> idPapel,
      Value<String?> papelNome,
      Value<String?> papelDescricao,
      Value<int?> idFuncao,
      Value<String?> funcaoNome,
      Value<String?> funcaoDescricao,
      Value<int?> idPapelFuncao,
      Value<String?> habilitado,
      Value<String?> podeInserir,
      Value<String?> podeAlterar,
      Value<String?> podeExcluir,
    });

class $$ViewControleAcessosTableFilterComposer
    extends Composer<_$AppDatabase, $ViewControleAcessosTable> {
  $$ViewControleAcessosTableFilterComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnFilters<int> get id => $composableBuilder(
    column: $table.id,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<int> get idPessoa => $composableBuilder(
    column: $table.idPessoa,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get pessoaNome => $composableBuilder(
    column: $table.pessoaNome,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<int> get idColaborador => $composableBuilder(
    column: $table.idColaborador,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<int> get idUsuario => $composableBuilder(
    column: $table.idUsuario,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get administrador => $composableBuilder(
    column: $table.administrador,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<int> get idPapel => $composableBuilder(
    column: $table.idPapel,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get papelNome => $composableBuilder(
    column: $table.papelNome,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get papelDescricao => $composableBuilder(
    column: $table.papelDescricao,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<int> get idFuncao => $composableBuilder(
    column: $table.idFuncao,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get funcaoNome => $composableBuilder(
    column: $table.funcaoNome,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get funcaoDescricao => $composableBuilder(
    column: $table.funcaoDescricao,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<int> get idPapelFuncao => $composableBuilder(
    column: $table.idPapelFuncao,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get habilitado => $composableBuilder(
    column: $table.habilitado,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get podeInserir => $composableBuilder(
    column: $table.podeInserir,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get podeAlterar => $composableBuilder(
    column: $table.podeAlterar,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get podeExcluir => $composableBuilder(
    column: $table.podeExcluir,
    builder: (column) => ColumnFilters(column),
  );
}

class $$ViewControleAcessosTableOrderingComposer
    extends Composer<_$AppDatabase, $ViewControleAcessosTable> {
  $$ViewControleAcessosTableOrderingComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnOrderings<int> get id => $composableBuilder(
    column: $table.id,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<int> get idPessoa => $composableBuilder(
    column: $table.idPessoa,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get pessoaNome => $composableBuilder(
    column: $table.pessoaNome,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<int> get idColaborador => $composableBuilder(
    column: $table.idColaborador,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<int> get idUsuario => $composableBuilder(
    column: $table.idUsuario,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get administrador => $composableBuilder(
    column: $table.administrador,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<int> get idPapel => $composableBuilder(
    column: $table.idPapel,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get papelNome => $composableBuilder(
    column: $table.papelNome,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get papelDescricao => $composableBuilder(
    column: $table.papelDescricao,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<int> get idFuncao => $composableBuilder(
    column: $table.idFuncao,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get funcaoNome => $composableBuilder(
    column: $table.funcaoNome,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get funcaoDescricao => $composableBuilder(
    column: $table.funcaoDescricao,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<int> get idPapelFuncao => $composableBuilder(
    column: $table.idPapelFuncao,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get habilitado => $composableBuilder(
    column: $table.habilitado,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get podeInserir => $composableBuilder(
    column: $table.podeInserir,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get podeAlterar => $composableBuilder(
    column: $table.podeAlterar,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get podeExcluir => $composableBuilder(
    column: $table.podeExcluir,
    builder: (column) => ColumnOrderings(column),
  );
}

class $$ViewControleAcessosTableAnnotationComposer
    extends Composer<_$AppDatabase, $ViewControleAcessosTable> {
  $$ViewControleAcessosTableAnnotationComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  GeneratedColumn<int> get id =>
      $composableBuilder(column: $table.id, builder: (column) => column);

  GeneratedColumn<int> get idPessoa =>
      $composableBuilder(column: $table.idPessoa, builder: (column) => column);

  GeneratedColumn<String> get pessoaNome => $composableBuilder(
    column: $table.pessoaNome,
    builder: (column) => column,
  );

  GeneratedColumn<int> get idColaborador => $composableBuilder(
    column: $table.idColaborador,
    builder: (column) => column,
  );

  GeneratedColumn<int> get idUsuario =>
      $composableBuilder(column: $table.idUsuario, builder: (column) => column);

  GeneratedColumn<String> get administrador => $composableBuilder(
    column: $table.administrador,
    builder: (column) => column,
  );

  GeneratedColumn<int> get idPapel =>
      $composableBuilder(column: $table.idPapel, builder: (column) => column);

  GeneratedColumn<String> get papelNome =>
      $composableBuilder(column: $table.papelNome, builder: (column) => column);

  GeneratedColumn<String> get papelDescricao => $composableBuilder(
    column: $table.papelDescricao,
    builder: (column) => column,
  );

  GeneratedColumn<int> get idFuncao =>
      $composableBuilder(column: $table.idFuncao, builder: (column) => column);

  GeneratedColumn<String> get funcaoNome => $composableBuilder(
    column: $table.funcaoNome,
    builder: (column) => column,
  );

  GeneratedColumn<String> get funcaoDescricao => $composableBuilder(
    column: $table.funcaoDescricao,
    builder: (column) => column,
  );

  GeneratedColumn<int> get idPapelFuncao => $composableBuilder(
    column: $table.idPapelFuncao,
    builder: (column) => column,
  );

  GeneratedColumn<String> get habilitado => $composableBuilder(
    column: $table.habilitado,
    builder: (column) => column,
  );

  GeneratedColumn<String> get podeInserir => $composableBuilder(
    column: $table.podeInserir,
    builder: (column) => column,
  );

  GeneratedColumn<String> get podeAlterar => $composableBuilder(
    column: $table.podeAlterar,
    builder: (column) => column,
  );

  GeneratedColumn<String> get podeExcluir => $composableBuilder(
    column: $table.podeExcluir,
    builder: (column) => column,
  );
}

class $$ViewControleAcessosTableTableManager
    extends
        RootTableManager<
          _$AppDatabase,
          $ViewControleAcessosTable,
          ViewControleAcesso,
          $$ViewControleAcessosTableFilterComposer,
          $$ViewControleAcessosTableOrderingComposer,
          $$ViewControleAcessosTableAnnotationComposer,
          $$ViewControleAcessosTableCreateCompanionBuilder,
          $$ViewControleAcessosTableUpdateCompanionBuilder,
          (
            ViewControleAcesso,
            BaseReferences<
              _$AppDatabase,
              $ViewControleAcessosTable,
              ViewControleAcesso
            >,
          ),
          ViewControleAcesso,
          PrefetchHooks Function()
        > {
  $$ViewControleAcessosTableTableManager(
    _$AppDatabase db,
    $ViewControleAcessosTable table,
  ) : super(
        TableManagerState(
          db: db,
          table: table,
          createFilteringComposer:
              () => $$ViewControleAcessosTableFilterComposer(
                $db: db,
                $table: table,
              ),
          createOrderingComposer:
              () => $$ViewControleAcessosTableOrderingComposer(
                $db: db,
                $table: table,
              ),
          createComputedFieldComposer:
              () => $$ViewControleAcessosTableAnnotationComposer(
                $db: db,
                $table: table,
              ),
          updateCompanionCallback:
              ({
                Value<int?> id = const Value.absent(),
                Value<int?> idPessoa = const Value.absent(),
                Value<String?> pessoaNome = const Value.absent(),
                Value<int?> idColaborador = const Value.absent(),
                Value<int?> idUsuario = const Value.absent(),
                Value<String?> administrador = const Value.absent(),
                Value<int?> idPapel = const Value.absent(),
                Value<String?> papelNome = const Value.absent(),
                Value<String?> papelDescricao = const Value.absent(),
                Value<int?> idFuncao = const Value.absent(),
                Value<String?> funcaoNome = const Value.absent(),
                Value<String?> funcaoDescricao = const Value.absent(),
                Value<int?> idPapelFuncao = const Value.absent(),
                Value<String?> habilitado = const Value.absent(),
                Value<String?> podeInserir = const Value.absent(),
                Value<String?> podeAlterar = const Value.absent(),
                Value<String?> podeExcluir = const Value.absent(),
              }) => ViewControleAcessosCompanion(
                id: id,
                idPessoa: idPessoa,
                pessoaNome: pessoaNome,
                idColaborador: idColaborador,
                idUsuario: idUsuario,
                administrador: administrador,
                idPapel: idPapel,
                papelNome: papelNome,
                papelDescricao: papelDescricao,
                idFuncao: idFuncao,
                funcaoNome: funcaoNome,
                funcaoDescricao: funcaoDescricao,
                idPapelFuncao: idPapelFuncao,
                habilitado: habilitado,
                podeInserir: podeInserir,
                podeAlterar: podeAlterar,
                podeExcluir: podeExcluir,
              ),
          createCompanionCallback:
              ({
                Value<int?> id = const Value.absent(),
                Value<int?> idPessoa = const Value.absent(),
                Value<String?> pessoaNome = const Value.absent(),
                Value<int?> idColaborador = const Value.absent(),
                Value<int?> idUsuario = const Value.absent(),
                Value<String?> administrador = const Value.absent(),
                Value<int?> idPapel = const Value.absent(),
                Value<String?> papelNome = const Value.absent(),
                Value<String?> papelDescricao = const Value.absent(),
                Value<int?> idFuncao = const Value.absent(),
                Value<String?> funcaoNome = const Value.absent(),
                Value<String?> funcaoDescricao = const Value.absent(),
                Value<int?> idPapelFuncao = const Value.absent(),
                Value<String?> habilitado = const Value.absent(),
                Value<String?> podeInserir = const Value.absent(),
                Value<String?> podeAlterar = const Value.absent(),
                Value<String?> podeExcluir = const Value.absent(),
              }) => ViewControleAcessosCompanion.insert(
                id: id,
                idPessoa: idPessoa,
                pessoaNome: pessoaNome,
                idColaborador: idColaborador,
                idUsuario: idUsuario,
                administrador: administrador,
                idPapel: idPapel,
                papelNome: papelNome,
                papelDescricao: papelDescricao,
                idFuncao: idFuncao,
                funcaoNome: funcaoNome,
                funcaoDescricao: funcaoDescricao,
                idPapelFuncao: idPapelFuncao,
                habilitado: habilitado,
                podeInserir: podeInserir,
                podeAlterar: podeAlterar,
                podeExcluir: podeExcluir,
              ),
          withReferenceMapper:
              (p0) =>
                  p0
                      .map(
                        (e) => (
                          e.readTable(table),
                          BaseReferences(db, table, e),
                        ),
                      )
                      .toList(),
          prefetchHooksCallback: null,
        ),
      );
}

typedef $$ViewControleAcessosTableProcessedTableManager =
    ProcessedTableManager<
      _$AppDatabase,
      $ViewControleAcessosTable,
      ViewControleAcesso,
      $$ViewControleAcessosTableFilterComposer,
      $$ViewControleAcessosTableOrderingComposer,
      $$ViewControleAcessosTableAnnotationComposer,
      $$ViewControleAcessosTableCreateCompanionBuilder,
      $$ViewControleAcessosTableUpdateCompanionBuilder,
      (
        ViewControleAcesso,
        BaseReferences<
          _$AppDatabase,
          $ViewControleAcessosTable,
          ViewControleAcesso
        >,
      ),
      ViewControleAcesso,
      PrefetchHooks Function()
    >;
typedef $$ViewPessoaUsuariosTableCreateCompanionBuilder =
    ViewPessoaUsuariosCompanion Function({
      Value<int?> id,
      Value<int?> idPessoa,
      Value<String?> pessoaNome,
      Value<String?> tipo,
      Value<String?> email,
      Value<int?> idColaborador,
      Value<int?> idUsuario,
      Value<String?> login,
      Value<String?> senha,
      Value<DateTime?> dataCadastro,
      Value<String?> administrador,
    });
typedef $$ViewPessoaUsuariosTableUpdateCompanionBuilder =
    ViewPessoaUsuariosCompanion Function({
      Value<int?> id,
      Value<int?> idPessoa,
      Value<String?> pessoaNome,
      Value<String?> tipo,
      Value<String?> email,
      Value<int?> idColaborador,
      Value<int?> idUsuario,
      Value<String?> login,
      Value<String?> senha,
      Value<DateTime?> dataCadastro,
      Value<String?> administrador,
    });

class $$ViewPessoaUsuariosTableFilterComposer
    extends Composer<_$AppDatabase, $ViewPessoaUsuariosTable> {
  $$ViewPessoaUsuariosTableFilterComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnFilters<int> get id => $composableBuilder(
    column: $table.id,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<int> get idPessoa => $composableBuilder(
    column: $table.idPessoa,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get pessoaNome => $composableBuilder(
    column: $table.pessoaNome,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get tipo => $composableBuilder(
    column: $table.tipo,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get email => $composableBuilder(
    column: $table.email,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<int> get idColaborador => $composableBuilder(
    column: $table.idColaborador,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<int> get idUsuario => $composableBuilder(
    column: $table.idUsuario,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get login => $composableBuilder(
    column: $table.login,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get senha => $composableBuilder(
    column: $table.senha,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<DateTime> get dataCadastro => $composableBuilder(
    column: $table.dataCadastro,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get administrador => $composableBuilder(
    column: $table.administrador,
    builder: (column) => ColumnFilters(column),
  );
}

class $$ViewPessoaUsuariosTableOrderingComposer
    extends Composer<_$AppDatabase, $ViewPessoaUsuariosTable> {
  $$ViewPessoaUsuariosTableOrderingComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnOrderings<int> get id => $composableBuilder(
    column: $table.id,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<int> get idPessoa => $composableBuilder(
    column: $table.idPessoa,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get pessoaNome => $composableBuilder(
    column: $table.pessoaNome,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get tipo => $composableBuilder(
    column: $table.tipo,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get email => $composableBuilder(
    column: $table.email,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<int> get idColaborador => $composableBuilder(
    column: $table.idColaborador,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<int> get idUsuario => $composableBuilder(
    column: $table.idUsuario,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get login => $composableBuilder(
    column: $table.login,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get senha => $composableBuilder(
    column: $table.senha,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<DateTime> get dataCadastro => $composableBuilder(
    column: $table.dataCadastro,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get administrador => $composableBuilder(
    column: $table.administrador,
    builder: (column) => ColumnOrderings(column),
  );
}

class $$ViewPessoaUsuariosTableAnnotationComposer
    extends Composer<_$AppDatabase, $ViewPessoaUsuariosTable> {
  $$ViewPessoaUsuariosTableAnnotationComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  GeneratedColumn<int> get id =>
      $composableBuilder(column: $table.id, builder: (column) => column);

  GeneratedColumn<int> get idPessoa =>
      $composableBuilder(column: $table.idPessoa, builder: (column) => column);

  GeneratedColumn<String> get pessoaNome => $composableBuilder(
    column: $table.pessoaNome,
    builder: (column) => column,
  );

  GeneratedColumn<String> get tipo =>
      $composableBuilder(column: $table.tipo, builder: (column) => column);

  GeneratedColumn<String> get email =>
      $composableBuilder(column: $table.email, builder: (column) => column);

  GeneratedColumn<int> get idColaborador => $composableBuilder(
    column: $table.idColaborador,
    builder: (column) => column,
  );

  GeneratedColumn<int> get idUsuario =>
      $composableBuilder(column: $table.idUsuario, builder: (column) => column);

  GeneratedColumn<String> get login =>
      $composableBuilder(column: $table.login, builder: (column) => column);

  GeneratedColumn<String> get senha =>
      $composableBuilder(column: $table.senha, builder: (column) => column);

  GeneratedColumn<DateTime> get dataCadastro => $composableBuilder(
    column: $table.dataCadastro,
    builder: (column) => column,
  );

  GeneratedColumn<String> get administrador => $composableBuilder(
    column: $table.administrador,
    builder: (column) => column,
  );
}

class $$ViewPessoaUsuariosTableTableManager
    extends
        RootTableManager<
          _$AppDatabase,
          $ViewPessoaUsuariosTable,
          ViewPessoaUsuario,
          $$ViewPessoaUsuariosTableFilterComposer,
          $$ViewPessoaUsuariosTableOrderingComposer,
          $$ViewPessoaUsuariosTableAnnotationComposer,
          $$ViewPessoaUsuariosTableCreateCompanionBuilder,
          $$ViewPessoaUsuariosTableUpdateCompanionBuilder,
          (
            ViewPessoaUsuario,
            BaseReferences<
              _$AppDatabase,
              $ViewPessoaUsuariosTable,
              ViewPessoaUsuario
            >,
          ),
          ViewPessoaUsuario,
          PrefetchHooks Function()
        > {
  $$ViewPessoaUsuariosTableTableManager(
    _$AppDatabase db,
    $ViewPessoaUsuariosTable table,
  ) : super(
        TableManagerState(
          db: db,
          table: table,
          createFilteringComposer:
              () => $$ViewPessoaUsuariosTableFilterComposer(
                $db: db,
                $table: table,
              ),
          createOrderingComposer:
              () => $$ViewPessoaUsuariosTableOrderingComposer(
                $db: db,
                $table: table,
              ),
          createComputedFieldComposer:
              () => $$ViewPessoaUsuariosTableAnnotationComposer(
                $db: db,
                $table: table,
              ),
          updateCompanionCallback:
              ({
                Value<int?> id = const Value.absent(),
                Value<int?> idPessoa = const Value.absent(),
                Value<String?> pessoaNome = const Value.absent(),
                Value<String?> tipo = const Value.absent(),
                Value<String?> email = const Value.absent(),
                Value<int?> idColaborador = const Value.absent(),
                Value<int?> idUsuario = const Value.absent(),
                Value<String?> login = const Value.absent(),
                Value<String?> senha = const Value.absent(),
                Value<DateTime?> dataCadastro = const Value.absent(),
                Value<String?> administrador = const Value.absent(),
              }) => ViewPessoaUsuariosCompanion(
                id: id,
                idPessoa: idPessoa,
                pessoaNome: pessoaNome,
                tipo: tipo,
                email: email,
                idColaborador: idColaborador,
                idUsuario: idUsuario,
                login: login,
                senha: senha,
                dataCadastro: dataCadastro,
                administrador: administrador,
              ),
          createCompanionCallback:
              ({
                Value<int?> id = const Value.absent(),
                Value<int?> idPessoa = const Value.absent(),
                Value<String?> pessoaNome = const Value.absent(),
                Value<String?> tipo = const Value.absent(),
                Value<String?> email = const Value.absent(),
                Value<int?> idColaborador = const Value.absent(),
                Value<int?> idUsuario = const Value.absent(),
                Value<String?> login = const Value.absent(),
                Value<String?> senha = const Value.absent(),
                Value<DateTime?> dataCadastro = const Value.absent(),
                Value<String?> administrador = const Value.absent(),
              }) => ViewPessoaUsuariosCompanion.insert(
                id: id,
                idPessoa: idPessoa,
                pessoaNome: pessoaNome,
                tipo: tipo,
                email: email,
                idColaborador: idColaborador,
                idUsuario: idUsuario,
                login: login,
                senha: senha,
                dataCadastro: dataCadastro,
                administrador: administrador,
              ),
          withReferenceMapper:
              (p0) =>
                  p0
                      .map(
                        (e) => (
                          e.readTable(table),
                          BaseReferences(db, table, e),
                        ),
                      )
                      .toList(),
          prefetchHooksCallback: null,
        ),
      );
}

typedef $$ViewPessoaUsuariosTableProcessedTableManager =
    ProcessedTableManager<
      _$AppDatabase,
      $ViewPessoaUsuariosTable,
      ViewPessoaUsuario,
      $$ViewPessoaUsuariosTableFilterComposer,
      $$ViewPessoaUsuariosTableOrderingComposer,
      $$ViewPessoaUsuariosTableAnnotationComposer,
      $$ViewPessoaUsuariosTableCreateCompanionBuilder,
      $$ViewPessoaUsuariosTableUpdateCompanionBuilder,
      (
        ViewPessoaUsuario,
        BaseReferences<
          _$AppDatabase,
          $ViewPessoaUsuariosTable,
          ViewPessoaUsuario
        >,
      ),
      ViewPessoaUsuario,
      PrefetchHooks Function()
    >;

class $AppDatabaseManager {
  final _$AppDatabase _db;
  $AppDatabaseManager(this._db);
  $$BpeEmitentesTableTableManager get bpeEmitentes =>
      $$BpeEmitentesTableTableManager(_db, _db.bpeEmitentes);
  $$BpePassageirosTableTableManager get bpePassageiros =>
      $$BpePassageirosTableTableManager(_db, _db.bpePassageiros);
  $$BpeCompradorsTableTableManager get bpeCompradors =>
      $$BpeCompradorsTableTableManager(_db, _db.bpeCompradors);
  $$BpeViagemsTableTableManager get bpeViagems =>
      $$BpeViagemsTableTableManager(_db, _db.bpeViagems);
  $$BpeAgenciasTableTableManager get bpeAgencias =>
      $$BpeAgenciasTableTableManager(_db, _db.bpeAgencias);
  $$BpePassagemsTableTableManager get bpePassagems =>
      $$BpePassagemsTableTableManager(_db, _db.bpePassagems);
  $$BpeCabecalhosTableTableManager get bpeCabecalhos =>
      $$BpeCabecalhosTableTableManager(_db, _db.bpeCabecalhos);
  $$ViewControleAcessosTableTableManager get viewControleAcessos =>
      $$ViewControleAcessosTableTableManager(_db, _db.viewControleAcessos);
  $$ViewPessoaUsuariosTableTableManager get viewPessoaUsuarios =>
      $$ViewPessoaUsuariosTableTableManager(_db, _db.viewPessoaUsuarios);
}
