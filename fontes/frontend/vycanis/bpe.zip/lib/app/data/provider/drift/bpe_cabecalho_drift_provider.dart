import 'package:bpe/app/data/provider/drift/database/database_imports.dart';
import 'package:bpe/app/infra/infra_imports.dart';
import 'package:bpe/app/data/provider/provider_base.dart';
import 'package:bpe/app/data/provider/drift/database/database.dart';
import 'package:bpe/app/data/model/model_imports.dart';
import 'package:bpe/app/data/domain/domain_imports.dart';

class BpeCabecalhoDriftProvider extends ProviderBase {

	Future<List<BpeCabecalhoModel>?> getList({Filter? filter}) async {
		List<BpeCabecalhoGrouped> bpeCabecalhoDriftList = [];

		try {
			if (filter != null && filter.field != null) {
				bpeCabecalhoDriftList = await Session.database.bpeCabecalhoDao.getGroupedList(field: filter.field, value: filter.value!);
			} else {
				bpeCabecalhoDriftList = await Session.database.bpeCabecalhoDao.getGroupedList(); 
			}
			if (bpeCabecalhoDriftList.isNotEmpty) {
				return toListModel(bpeCabecalhoDriftList);
			} else {
				return [];
			}			 
		} catch (e) {
			handleResultError(null, null, exception: e);
			return null;
		}
	}

	Future<BpeCabecalhoModel?> getObject(dynamic pk) async {
		try {
			final result = await Session.database.bpeCabecalhoDao.getObjectGrouped(field: 'id', value: pk);
			return toModel(result);
		} catch (e) {
			handleResultError(null, null, exception: e);
		}
		return null;
	}

	Future<BpeCabecalhoModel?>? insert(BpeCabecalhoModel bpeCabecalhoModel) async {
		try {
			final lastPk = await Session.database.bpeCabecalhoDao.insertObject(toDrift(bpeCabecalhoModel));
			bpeCabecalhoModel.id = lastPk;
			return bpeCabecalhoModel;
		} catch (e) {
			handleResultError(null, null, exception: e);
		}
		return null;
	}

	Future<BpeCabecalhoModel?>? update(BpeCabecalhoModel bpeCabecalhoModel) async {
		try {
			await Session.database.bpeCabecalhoDao.updateObject(toDrift(bpeCabecalhoModel));
			return bpeCabecalhoModel;
		} catch (e) {
			handleResultError(null, null, exception: e);
		}
		return null;
	}

	Future<bool?> delete(dynamic pk) async {
		try {
			await Session.database.bpeCabecalhoDao.deleteObject(toDrift(BpeCabecalhoModel(id: pk)));
			return true;
		} catch (e) {
			handleResultError(null, null, exception: e);
		}
		return null;
	}	

	List<BpeCabecalhoModel> toListModel(List<BpeCabecalhoGrouped> bpeCabecalhoDriftList) {
		List<BpeCabecalhoModel> listModel = [];
		for (var bpeCabecalhoDrift in bpeCabecalhoDriftList) {
			listModel.add(toModel(bpeCabecalhoDrift)!);
		}
		return listModel;
	}	

	BpeCabecalhoModel? toModel(BpeCabecalhoGrouped? bpeCabecalhoDrift) {
		if (bpeCabecalhoDrift != null) {
			return BpeCabecalhoModel(
				id: bpeCabecalhoDrift.bpeCabecalho?.id,
				ufEmitente: bpeCabecalhoDrift.bpeCabecalho?.ufEmitente,
				ambiente: BpeCabecalhoDomain.getAmbiente(bpeCabecalhoDrift.bpeCabecalho?.ambiente),
				modelo: BpeCabecalhoDomain.getModelo(bpeCabecalhoDrift.bpeCabecalho?.modelo),
				serie: bpeCabecalhoDrift.bpeCabecalho?.serie,
				numero: bpeCabecalhoDrift.bpeCabecalho?.numero,
				codigoNumerico: bpeCabecalhoDrift.bpeCabecalho?.codigoNumerico,
				chaveAcesso: bpeCabecalhoDrift.bpeCabecalho?.chaveAcesso,
				digitoChaveAcesso: bpeCabecalhoDrift.bpeCabecalho?.digitoChaveAcesso,
				modal: BpeCabecalhoDomain.getModal(bpeCabecalhoDrift.bpeCabecalho?.modal),
				dataHoraEmissao: bpeCabecalhoDrift.bpeCabecalho?.dataHoraEmissao,
				tipoEmissao: BpeCabecalhoDomain.getTipoEmissao(bpeCabecalhoDrift.bpeCabecalho?.tipoEmissao),
				versaoProcessoEmissao: bpeCabecalhoDrift.bpeCabecalho?.versaoProcessoEmissao,
				tipoBpe: BpeCabecalhoDomain.getTipoBpe(bpeCabecalhoDrift.bpeCabecalho?.tipoBpe),
				consumidorPresenca: BpeCabecalhoDomain.getConsumidorPresenca(bpeCabecalhoDrift.bpeCabecalho?.consumidorPresenca),
				ufInicioViagem: BpeCabecalhoDomain.getUfInicioViagem(bpeCabecalhoDrift.bpeCabecalho?.ufInicioViagem),
				codigoMunicipioInicioViagem: bpeCabecalhoDrift.bpeCabecalho?.codigoMunicipioInicioViagem,
				ufFimViagem: BpeCabecalhoDomain.getUfFimViagem(bpeCabecalhoDrift.bpeCabecalho?.ufFimViagem),
				codigoMunicipioFimViagem: bpeCabecalhoDrift.bpeCabecalho?.codigoMunicipioFimViagem,
				valorBilhete: bpeCabecalhoDrift.bpeCabecalho?.valorBilhete,
				valorDesconto: bpeCabecalhoDrift.bpeCabecalho?.valorDesconto,
				valorPago: bpeCabecalhoDrift.bpeCabecalho?.valorPago,
				valorTroco: bpeCabecalhoDrift.bpeCabecalho?.valorTroco,
				tipoDesconto: BpeCabecalhoDomain.getTipoDesconto(bpeCabecalhoDrift.bpeCabecalho?.tipoDesconto),
				descontoDescricao: bpeCabecalhoDrift.bpeCabecalho?.descontoDescricao,
				descontoConcedidoOutros: bpeCabecalhoDrift.bpeCabecalho?.descontoConcedidoOutros,
				formaPagamento: BpeCabecalhoDomain.getFormaPagamento(bpeCabecalhoDrift.bpeCabecalho?.formaPagamento),
				formaPagamentoOutros: bpeCabecalhoDrift.bpeCabecalho?.formaPagamentoOutros,
				formaPagamentoDocumento: bpeCabecalhoDrift.bpeCabecalho?.formaPagamentoDocumento,
				cst: bpeCabecalhoDrift.bpeCabecalho?.cst,
				baseCalculoIcms: bpeCabecalhoDrift.bpeCabecalho?.baseCalculoIcms,
				aliquotaIcms: bpeCabecalhoDrift.bpeCabecalho?.aliquotaIcms,
				valorIcms: bpeCabecalhoDrift.bpeCabecalho?.valorIcms,
				percentualReducaoBcIcms: bpeCabecalhoDrift.bpeCabecalho?.percentualReducaoBcIcms,
				informacoesAddFisco: bpeCabecalhoDrift.bpeCabecalho?.informacoesAddFisco,
				bpeEmitenteModelList: bpeEmitenteDriftToModel(bpeCabecalhoDrift.bpeEmitenteGroupedList),
				bpePassageiroModelList: bpePassageiroDriftToModel(bpeCabecalhoDrift.bpePassageiroGroupedList),
				bpeCompradorModelList: bpeCompradorDriftToModel(bpeCabecalhoDrift.bpeCompradorGroupedList),
				bpeViagemModelList: bpeViagemDriftToModel(bpeCabecalhoDrift.bpeViagemGroupedList),
				bpeAgenciaModelList: bpeAgenciaDriftToModel(bpeCabecalhoDrift.bpeAgenciaGroupedList),
				bpePassagemModelList: bpePassagemDriftToModel(bpeCabecalhoDrift.bpePassagemGroupedList),
			);
		} else {
			return null;
		}
	}

	List<BpeEmitenteModel> bpeEmitenteDriftToModel(List<BpeEmitenteGrouped>? bpeEmitenteDriftList) { 
		List<BpeEmitenteModel> bpeEmitenteModelList = [];
		if (bpeEmitenteDriftList != null) {
			for (var bpeEmitenteGrouped in bpeEmitenteDriftList) {
				bpeEmitenteModelList.add(
					BpeEmitenteModel(
						id: bpeEmitenteGrouped.bpeEmitente?.id,
						idBpeCabecalho: bpeEmitenteGrouped.bpeEmitente?.idBpeCabecalho,
						cnpj: bpeEmitenteGrouped.bpeEmitente?.cnpj,
						ie: bpeEmitenteGrouped.bpeEmitente?.ie,
						iest: bpeEmitenteGrouped.bpeEmitente?.iest,
						im: bpeEmitenteGrouped.bpeEmitente?.im,
						cnae: bpeEmitenteGrouped.bpeEmitente?.cnae,
						crt: bpeEmitenteGrouped.bpeEmitente?.crt,
						nome: bpeEmitenteGrouped.bpeEmitente?.nome,
						fantasia: bpeEmitenteGrouped.bpeEmitente?.fantasia,
						logradouro: bpeEmitenteGrouped.bpeEmitente?.logradouro,
						numero: bpeEmitenteGrouped.bpeEmitente?.numero,
						complemento: bpeEmitenteGrouped.bpeEmitente?.complemento,
						bairro: bpeEmitenteGrouped.bpeEmitente?.bairro,
						codigoMunicipio: bpeEmitenteGrouped.bpeEmitente?.codigoMunicipio,
						nomeMunicipio: bpeEmitenteGrouped.bpeEmitente?.nomeMunicipio,
						uf: BpeEmitenteDomain.getUf(bpeEmitenteGrouped.bpeEmitente?.uf),
						cep: bpeEmitenteGrouped.bpeEmitente?.cep,
						telefone: bpeEmitenteGrouped.bpeEmitente?.telefone,
					)
				);
			}
			return bpeEmitenteModelList;
		}
		return [];
	}

	List<BpePassageiroModel> bpePassageiroDriftToModel(List<BpePassageiroGrouped>? bpePassageiroDriftList) { 
		List<BpePassageiroModel> bpePassageiroModelList = [];
		if (bpePassageiroDriftList != null) {
			for (var bpePassageiroGrouped in bpePassageiroDriftList) {
				bpePassageiroModelList.add(
					BpePassageiroModel(
						id: bpePassageiroGrouped.bpePassageiro?.id,
						idBpeCabecalho: bpePassageiroGrouped.bpePassageiro?.idBpeCabecalho,
						nome: bpePassageiroGrouped.bpePassageiro?.nome,
						cpf: bpePassageiroGrouped.bpePassageiro?.cpf,
						tipoDocumentoIdentificacao: BpePassageiroDomain.getTipoDocumentoIdentificacao(bpePassageiroGrouped.bpePassageiro?.tipoDocumentoIdentificacao),
						numeroDocumento: bpePassageiroGrouped.bpePassageiro?.numeroDocumento,
						documentoOutrosDescricao: bpePassageiroGrouped.bpePassageiro?.documentoOutrosDescricao,
						dataNascimento: bpePassageiroGrouped.bpePassageiro?.dataNascimento,
						telefone: bpePassageiroGrouped.bpePassageiro?.telefone,
						email: bpePassageiroGrouped.bpePassageiro?.email,
					)
				);
			}
			return bpePassageiroModelList;
		}
		return [];
	}

	List<BpeCompradorModel> bpeCompradorDriftToModel(List<BpeCompradorGrouped>? bpeCompradorDriftList) { 
		List<BpeCompradorModel> bpeCompradorModelList = [];
		if (bpeCompradorDriftList != null) {
			for (var bpeCompradorGrouped in bpeCompradorDriftList) {
				bpeCompradorModelList.add(
					BpeCompradorModel(
						id: bpeCompradorGrouped.bpeComprador?.id,
						idBpeCabecalho: bpeCompradorGrouped.bpeComprador?.idBpeCabecalho,
						cnpj: bpeCompradorGrouped.bpeComprador?.cnpj,
						cpf: bpeCompradorGrouped.bpeComprador?.cpf,
						ie: bpeCompradorGrouped.bpeComprador?.ie,
						nome: bpeCompradorGrouped.bpeComprador?.nome,
						fantasia: bpeCompradorGrouped.bpeComprador?.fantasia,
						telefone: bpeCompradorGrouped.bpeComprador?.telefone,
						logradouro: bpeCompradorGrouped.bpeComprador?.logradouro,
						numero: bpeCompradorGrouped.bpeComprador?.numero,
						complemento: bpeCompradorGrouped.bpeComprador?.complemento,
						bairro: bpeCompradorGrouped.bpeComprador?.bairro,
						codigoMunicipio: bpeCompradorGrouped.bpeComprador?.codigoMunicipio,
						nomeMunicipio: bpeCompradorGrouped.bpeComprador?.nomeMunicipio,
						uf: BpeCompradorDomain.getUf(bpeCompradorGrouped.bpeComprador?.uf),
						cep: bpeCompradorGrouped.bpeComprador?.cep,
						codigoPais: bpeCompradorGrouped.bpeComprador?.codigoPais,
						nomePais: bpeCompradorGrouped.bpeComprador?.nomePais,
						email: bpeCompradorGrouped.bpeComprador?.email,
					)
				);
			}
			return bpeCompradorModelList;
		}
		return [];
	}

	List<BpeViagemModel> bpeViagemDriftToModel(List<BpeViagemGrouped>? bpeViagemDriftList) { 
		List<BpeViagemModel> bpeViagemModelList = [];
		if (bpeViagemDriftList != null) {
			for (var bpeViagemGrouped in bpeViagemDriftList) {
				bpeViagemModelList.add(
					BpeViagemModel(
						id: bpeViagemGrouped.bpeViagem?.id,
						idBpeCabecalho: bpeViagemGrouped.bpeViagem?.idBpeCabecalho,
						codigoPercurso: bpeViagemGrouped.bpeViagem?.codigoPercurso,
						descricaoPercurso: bpeViagemGrouped.bpeViagem?.descricaoPercurso,
						tipoViagem: BpeViagemDomain.getTipoViagem(bpeViagemGrouped.bpeViagem?.tipoViagem),
						tipoServico: BpeViagemDomain.getTipoServico(bpeViagemGrouped.bpeViagem?.tipoServico),
						tipoAcomodacao: BpeViagemDomain.getTipoAcomodacao(bpeViagemGrouped.bpeViagem?.tipoAcomodacao),
						tipoTrecho: BpeViagemDomain.getTipoTrecho(bpeViagemGrouped.bpeViagem?.tipoTrecho),
						dataHoraViagem: bpeViagemGrouped.bpeViagem?.dataHoraViagem,
						dataHoraConexao: bpeViagemGrouped.bpeViagem?.dataHoraConexao,
						prefixoLinha: bpeViagemGrouped.bpeViagem?.prefixoLinha,
						poltrona: bpeViagemGrouped.bpeViagem?.poltrona,
						plataforma: bpeViagemGrouped.bpeViagem?.plataforma,
					)
				);
			}
			return bpeViagemModelList;
		}
		return [];
	}

	List<BpeAgenciaModel> bpeAgenciaDriftToModel(List<BpeAgenciaGrouped>? bpeAgenciaDriftList) { 
		List<BpeAgenciaModel> bpeAgenciaModelList = [];
		if (bpeAgenciaDriftList != null) {
			for (var bpeAgenciaGrouped in bpeAgenciaDriftList) {
				bpeAgenciaModelList.add(
					BpeAgenciaModel(
						id: bpeAgenciaGrouped.bpeAgencia?.id,
						idBpeCabecalho: bpeAgenciaGrouped.bpeAgencia?.idBpeCabecalho,
						cnpj: bpeAgenciaGrouped.bpeAgencia?.cnpj,
						nome: bpeAgenciaGrouped.bpeAgencia?.nome,
						telefone: bpeAgenciaGrouped.bpeAgencia?.telefone,
						logradouro: bpeAgenciaGrouped.bpeAgencia?.logradouro,
						numero: bpeAgenciaGrouped.bpeAgencia?.numero,
						complemento: bpeAgenciaGrouped.bpeAgencia?.complemento,
						bairro: bpeAgenciaGrouped.bpeAgencia?.bairro,
						codigoMunicipio: bpeAgenciaGrouped.bpeAgencia?.codigoMunicipio,
						nomeMunicipio: bpeAgenciaGrouped.bpeAgencia?.nomeMunicipio,
						uf: BpeAgenciaDomain.getUf(bpeAgenciaGrouped.bpeAgencia?.uf),
						cep: bpeAgenciaGrouped.bpeAgencia?.cep,
						codigoPais: bpeAgenciaGrouped.bpeAgencia?.codigoPais,
						nomePais: bpeAgenciaGrouped.bpeAgencia?.nomePais,
						email: bpeAgenciaGrouped.bpeAgencia?.email,
					)
				);
			}
			return bpeAgenciaModelList;
		}
		return [];
	}

	List<BpePassagemModel> bpePassagemDriftToModel(List<BpePassagemGrouped>? bpePassagemDriftList) { 
		List<BpePassagemModel> bpePassagemModelList = [];
		if (bpePassagemDriftList != null) {
			for (var bpePassagemGrouped in bpePassagemDriftList) {
				bpePassagemModelList.add(
					BpePassagemModel(
						id: bpePassagemGrouped.bpePassagem?.id,
						idBpeCabecalho: bpePassagemGrouped.bpePassagem?.idBpeCabecalho,
						codigoLocalidadeOrigem: bpePassagemGrouped.bpePassagem?.codigoLocalidadeOrigem,
						descricaoLocalidadeOrigem: bpePassagemGrouped.bpePassagem?.descricaoLocalidadeOrigem,
						codigoLocalidadeDestino: bpePassagemGrouped.bpePassagem?.codigoLocalidadeDestino,
						descricaoLocalidadeDestino: bpePassagemGrouped.bpePassagem?.descricaoLocalidadeDestino,
						dataHoraEmbarque: bpePassagemGrouped.bpePassagem?.dataHoraEmbarque,
						dataHoraValidade: bpePassagemGrouped.bpePassagem?.dataHoraValidade,
					)
				);
			}
			return bpePassagemModelList;
		}
		return [];
	}


	BpeCabecalhoGrouped toDrift(BpeCabecalhoModel bpeCabecalhoModel) {
		return BpeCabecalhoGrouped(
			bpeCabecalho: BpeCabecalho(
				id: bpeCabecalhoModel.id,
				ufEmitente: bpeCabecalhoModel.ufEmitente,
				ambiente: BpeCabecalhoDomain.setAmbiente(bpeCabecalhoModel.ambiente),
				modelo: BpeCabecalhoDomain.setModelo(bpeCabecalhoModel.modelo),
				serie: bpeCabecalhoModel.serie,
				numero: bpeCabecalhoModel.numero,
				codigoNumerico: bpeCabecalhoModel.codigoNumerico,
				chaveAcesso: bpeCabecalhoModel.chaveAcesso,
				digitoChaveAcesso: bpeCabecalhoModel.digitoChaveAcesso,
				modal: BpeCabecalhoDomain.setModal(bpeCabecalhoModel.modal),
				dataHoraEmissao: bpeCabecalhoModel.dataHoraEmissao,
				tipoEmissao: BpeCabecalhoDomain.setTipoEmissao(bpeCabecalhoModel.tipoEmissao),
				versaoProcessoEmissao: bpeCabecalhoModel.versaoProcessoEmissao,
				tipoBpe: BpeCabecalhoDomain.setTipoBpe(bpeCabecalhoModel.tipoBpe),
				consumidorPresenca: BpeCabecalhoDomain.setConsumidorPresenca(bpeCabecalhoModel.consumidorPresenca),
				ufInicioViagem: BpeCabecalhoDomain.setUfInicioViagem(bpeCabecalhoModel.ufInicioViagem),
				codigoMunicipioInicioViagem: bpeCabecalhoModel.codigoMunicipioInicioViagem,
				ufFimViagem: BpeCabecalhoDomain.setUfFimViagem(bpeCabecalhoModel.ufFimViagem),
				codigoMunicipioFimViagem: bpeCabecalhoModel.codigoMunicipioFimViagem,
				valorBilhete: bpeCabecalhoModel.valorBilhete,
				valorDesconto: bpeCabecalhoModel.valorDesconto,
				valorPago: bpeCabecalhoModel.valorPago,
				valorTroco: bpeCabecalhoModel.valorTroco,
				tipoDesconto: BpeCabecalhoDomain.setTipoDesconto(bpeCabecalhoModel.tipoDesconto),
				descontoDescricao: bpeCabecalhoModel.descontoDescricao,
				descontoConcedidoOutros: bpeCabecalhoModel.descontoConcedidoOutros,
				formaPagamento: BpeCabecalhoDomain.setFormaPagamento(bpeCabecalhoModel.formaPagamento),
				formaPagamentoOutros: bpeCabecalhoModel.formaPagamentoOutros,
				formaPagamentoDocumento: bpeCabecalhoModel.formaPagamentoDocumento,
				cst: bpeCabecalhoModel.cst,
				baseCalculoIcms: bpeCabecalhoModel.baseCalculoIcms,
				aliquotaIcms: bpeCabecalhoModel.aliquotaIcms,
				valorIcms: bpeCabecalhoModel.valorIcms,
				percentualReducaoBcIcms: bpeCabecalhoModel.percentualReducaoBcIcms,
				informacoesAddFisco: bpeCabecalhoModel.informacoesAddFisco,
			),
			bpeEmitenteGroupedList: bpeEmitenteModelToDrift(bpeCabecalhoModel.bpeEmitenteModelList),
			bpePassageiroGroupedList: bpePassageiroModelToDrift(bpeCabecalhoModel.bpePassageiroModelList),
			bpeCompradorGroupedList: bpeCompradorModelToDrift(bpeCabecalhoModel.bpeCompradorModelList),
			bpeViagemGroupedList: bpeViagemModelToDrift(bpeCabecalhoModel.bpeViagemModelList),
			bpeAgenciaGroupedList: bpeAgenciaModelToDrift(bpeCabecalhoModel.bpeAgenciaModelList),
			bpePassagemGroupedList: bpePassagemModelToDrift(bpeCabecalhoModel.bpePassagemModelList),
		);
	}

	List<BpeEmitenteGrouped> bpeEmitenteModelToDrift(List<BpeEmitenteModel>? bpeEmitenteModelList) { 
		List<BpeEmitenteGrouped> bpeEmitenteGroupedList = [];
		if (bpeEmitenteModelList != null) {
			for (var bpeEmitenteModel in bpeEmitenteModelList) {
				bpeEmitenteGroupedList.add(
					BpeEmitenteGrouped(
						bpeEmitente: BpeEmitente(
							id: bpeEmitenteModel.id,
							idBpeCabecalho: bpeEmitenteModel.idBpeCabecalho,
							cnpj: Util.removeMask(bpeEmitenteModel.cnpj),
							ie: bpeEmitenteModel.ie,
							iest: bpeEmitenteModel.iest,
							im: bpeEmitenteModel.im,
							cnae: bpeEmitenteModel.cnae,
							crt: bpeEmitenteModel.crt,
							nome: bpeEmitenteModel.nome,
							fantasia: bpeEmitenteModel.fantasia,
							logradouro: bpeEmitenteModel.logradouro,
							numero: bpeEmitenteModel.numero,
							complemento: bpeEmitenteModel.complemento,
							bairro: bpeEmitenteModel.bairro,
							codigoMunicipio: bpeEmitenteModel.codigoMunicipio,
							nomeMunicipio: bpeEmitenteModel.nomeMunicipio,
							uf: BpeEmitenteDomain.setUf(bpeEmitenteModel.uf),
							cep: Util.removeMask(bpeEmitenteModel.cep),
							telefone: bpeEmitenteModel.telefone,
						),
					),
				);
			}
			return bpeEmitenteGroupedList;
		}
		return [];
	}

	List<BpePassageiroGrouped> bpePassageiroModelToDrift(List<BpePassageiroModel>? bpePassageiroModelList) { 
		List<BpePassageiroGrouped> bpePassageiroGroupedList = [];
		if (bpePassageiroModelList != null) {
			for (var bpePassageiroModel in bpePassageiroModelList) {
				bpePassageiroGroupedList.add(
					BpePassageiroGrouped(
						bpePassageiro: BpePassageiro(
							id: bpePassageiroModel.id,
							idBpeCabecalho: bpePassageiroModel.idBpeCabecalho,
							nome: bpePassageiroModel.nome,
							cpf: Util.removeMask(bpePassageiroModel.cpf),
							tipoDocumentoIdentificacao: BpePassageiroDomain.setTipoDocumentoIdentificacao(bpePassageiroModel.tipoDocumentoIdentificacao),
							numeroDocumento: bpePassageiroModel.numeroDocumento,
							documentoOutrosDescricao: bpePassageiroModel.documentoOutrosDescricao,
							dataNascimento: bpePassageiroModel.dataNascimento,
							telefone: bpePassageiroModel.telefone,
							email: bpePassageiroModel.email,
						),
					),
				);
			}
			return bpePassageiroGroupedList;
		}
		return [];
	}

	List<BpeCompradorGrouped> bpeCompradorModelToDrift(List<BpeCompradorModel>? bpeCompradorModelList) { 
		List<BpeCompradorGrouped> bpeCompradorGroupedList = [];
		if (bpeCompradorModelList != null) {
			for (var bpeCompradorModel in bpeCompradorModelList) {
				bpeCompradorGroupedList.add(
					BpeCompradorGrouped(
						bpeComprador: BpeComprador(
							id: bpeCompradorModel.id,
							idBpeCabecalho: bpeCompradorModel.idBpeCabecalho,
							cnpj: Util.removeMask(bpeCompradorModel.cnpj),
							cpf: Util.removeMask(bpeCompradorModel.cpf),
							ie: bpeCompradorModel.ie,
							nome: bpeCompradorModel.nome,
							fantasia: bpeCompradorModel.fantasia,
							telefone: bpeCompradorModel.telefone,
							logradouro: bpeCompradorModel.logradouro,
							numero: bpeCompradorModel.numero,
							complemento: bpeCompradorModel.complemento,
							bairro: bpeCompradorModel.bairro,
							codigoMunicipio: bpeCompradorModel.codigoMunicipio,
							nomeMunicipio: bpeCompradorModel.nomeMunicipio,
							uf: BpeCompradorDomain.setUf(bpeCompradorModel.uf),
							cep: Util.removeMask(bpeCompradorModel.cep),
							codigoPais: bpeCompradorModel.codigoPais,
							nomePais: bpeCompradorModel.nomePais,
							email: bpeCompradorModel.email,
						),
					),
				);
			}
			return bpeCompradorGroupedList;
		}
		return [];
	}

	List<BpeViagemGrouped> bpeViagemModelToDrift(List<BpeViagemModel>? bpeViagemModelList) { 
		List<BpeViagemGrouped> bpeViagemGroupedList = [];
		if (bpeViagemModelList != null) {
			for (var bpeViagemModel in bpeViagemModelList) {
				bpeViagemGroupedList.add(
					BpeViagemGrouped(
						bpeViagem: BpeViagem(
							id: bpeViagemModel.id,
							idBpeCabecalho: bpeViagemModel.idBpeCabecalho,
							codigoPercurso: bpeViagemModel.codigoPercurso,
							descricaoPercurso: bpeViagemModel.descricaoPercurso,
							tipoViagem: BpeViagemDomain.setTipoViagem(bpeViagemModel.tipoViagem),
							tipoServico: BpeViagemDomain.setTipoServico(bpeViagemModel.tipoServico),
							tipoAcomodacao: BpeViagemDomain.setTipoAcomodacao(bpeViagemModel.tipoAcomodacao),
							tipoTrecho: BpeViagemDomain.setTipoTrecho(bpeViagemModel.tipoTrecho),
							dataHoraViagem: bpeViagemModel.dataHoraViagem,
							dataHoraConexao: bpeViagemModel.dataHoraConexao,
							prefixoLinha: bpeViagemModel.prefixoLinha,
							poltrona: bpeViagemModel.poltrona,
							plataforma: bpeViagemModel.plataforma,
						),
					),
				);
			}
			return bpeViagemGroupedList;
		}
		return [];
	}

	List<BpeAgenciaGrouped> bpeAgenciaModelToDrift(List<BpeAgenciaModel>? bpeAgenciaModelList) { 
		List<BpeAgenciaGrouped> bpeAgenciaGroupedList = [];
		if (bpeAgenciaModelList != null) {
			for (var bpeAgenciaModel in bpeAgenciaModelList) {
				bpeAgenciaGroupedList.add(
					BpeAgenciaGrouped(
						bpeAgencia: BpeAgencia(
							id: bpeAgenciaModel.id,
							idBpeCabecalho: bpeAgenciaModel.idBpeCabecalho,
							cnpj: Util.removeMask(bpeAgenciaModel.cnpj),
							nome: bpeAgenciaModel.nome,
							telefone: bpeAgenciaModel.telefone,
							logradouro: bpeAgenciaModel.logradouro,
							numero: bpeAgenciaModel.numero,
							complemento: bpeAgenciaModel.complemento,
							bairro: bpeAgenciaModel.bairro,
							codigoMunicipio: bpeAgenciaModel.codigoMunicipio,
							nomeMunicipio: bpeAgenciaModel.nomeMunicipio,
							uf: BpeAgenciaDomain.setUf(bpeAgenciaModel.uf),
							cep: Util.removeMask(bpeAgenciaModel.cep),
							codigoPais: bpeAgenciaModel.codigoPais,
							nomePais: bpeAgenciaModel.nomePais,
							email: bpeAgenciaModel.email,
						),
					),
				);
			}
			return bpeAgenciaGroupedList;
		}
		return [];
	}

	List<BpePassagemGrouped> bpePassagemModelToDrift(List<BpePassagemModel>? bpePassagemModelList) { 
		List<BpePassagemGrouped> bpePassagemGroupedList = [];
		if (bpePassagemModelList != null) {
			for (var bpePassagemModel in bpePassagemModelList) {
				bpePassagemGroupedList.add(
					BpePassagemGrouped(
						bpePassagem: BpePassagem(
							id: bpePassagemModel.id,
							idBpeCabecalho: bpePassagemModel.idBpeCabecalho,
							codigoLocalidadeOrigem: bpePassagemModel.codigoLocalidadeOrigem,
							descricaoLocalidadeOrigem: bpePassagemModel.descricaoLocalidadeOrigem,
							codigoLocalidadeDestino: bpePassagemModel.codigoLocalidadeDestino,
							descricaoLocalidadeDestino: bpePassagemModel.descricaoLocalidadeDestino,
							dataHoraEmbarque: bpePassagemModel.dataHoraEmbarque,
							dataHoraValidade: bpePassagemModel.dataHoraValidade,
						),
					),
				);
			}
			return bpePassagemGroupedList;
		}
		return [];
	}

		
}
