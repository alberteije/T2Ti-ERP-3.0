import 'package:drift/drift.dart';
import 'package:bpe/app/data/provider/drift/database/database.dart';

@DataClassName("BpeViagem")
class BpeViagems extends Table {
	@override
	String get tableName => 'bpe_viagem';

	IntColumn get id => integer().named('id').nullable()();
	IntColumn get idBpeCabecalho => integer().named('id_bpe_cabecalho').nullable()();
	TextColumn get codigoPercurso => text().named('codigo_percurso').withLength(min: 0, max: 20).nullable()();
	TextColumn get descricaoPercurso => text().named('descricao_percurso').withLength(min: 0, max: 100).nullable()();
	TextColumn get tipoViagem => text().named('tipo_viagem').withLength(min: 0, max: 1).nullable()();
	TextColumn get tipoServico => text().named('tipo_servico').withLength(min: 0, max: 1).nullable()();
	TextColumn get tipoAcomodacao => text().named('tipo_acomodacao').withLength(min: 0, max: 1).nullable()();
	TextColumn get tipoTrecho => text().named('tipo_trecho').withLength(min: 0, max: 1).nullable()();
	DateTimeColumn get dataHoraViagem => dateTime().named('data_hora_viagem').nullable()();
	DateTimeColumn get dataHoraConexao => dateTime().named('data_hora_conexao').nullable()();
	TextColumn get prefixoLinha => text().named('prefixo_linha').withLength(min: 0, max: 20).nullable()();
	TextColumn get poltrona => text().named('poltrona').withLength(min: 0, max: 3).nullable()();
	TextColumn get plataforma => text().named('plataforma').withLength(min: 0, max: 10).nullable()();

	@override
	Set<Column> get primaryKey => { id };	
	
}

class BpeViagemGrouped {
	BpeViagem? bpeViagem; 

  BpeViagemGrouped({
		this.bpeViagem, 

  });
}
