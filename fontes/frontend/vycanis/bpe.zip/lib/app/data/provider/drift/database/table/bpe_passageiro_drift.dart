import 'package:drift/drift.dart';
import 'package:bpe/app/data/provider/drift/database/database.dart';

@DataClassName("BpePassageiro")
class BpePassageiros extends Table {
	@override
	String get tableName => 'bpe_passageiro';

	IntColumn get id => integer().named('id').nullable()();
	IntColumn get idBpeCabecalho => integer().named('id_bpe_cabecalho').nullable()();
	TextColumn get nome => text().named('nome').withLength(min: 0, max: 60).nullable()();
	TextColumn get cpf => text().named('cpf').withLength(min: 0, max: 11).nullable()();
	TextColumn get tipoDocumentoIdentificacao => text().named('tipo_documento_identificacao').withLength(min: 0, max: 1).nullable()();
	TextColumn get numeroDocumento => text().named('numero_documento').withLength(min: 0, max: 20).nullable()();
	TextColumn get documentoOutrosDescricao => text().named('documento_outros_descricao').withLength(min: 0, max: 100).nullable()();
	DateTimeColumn get dataNascimento => dateTime().named('data_nascimento').nullable()();
	TextColumn get telefone => text().named('telefone').withLength(min: 0, max: 12).nullable()();
	TextColumn get email => text().named('email').withLength(min: 0, max: 60).nullable()();

	@override
	Set<Column> get primaryKey => { id };	
	
}

class BpePassageiroGrouped {
	BpePassageiro? bpePassageiro; 

  BpePassageiroGrouped({
		this.bpePassageiro, 

  });
}
