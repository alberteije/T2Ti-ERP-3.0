import 'package:drift/drift.dart';
import 'package:bpe/app/data/provider/drift/database/database.dart';
import 'package:bpe/app/data/provider/drift/database/database_imports.dart';

@DataClassName("BpeCabecalho")
class BpeCabecalhos extends Table {
	@override
	String get tableName => 'bpe_cabecalho';

	IntColumn get id => integer().named('id').nullable()();
	TextColumn get ufEmitente => text().named('uf_emitente').withLength(min: 0, max: 2).nullable()();
	TextColumn get ambiente => text().named('ambiente').withLength(min: 0, max: 1).nullable()();
	TextColumn get modelo => text().named('modelo').withLength(min: 0, max: 2).nullable()();
	TextColumn get serie => text().named('serie').withLength(min: 0, max: 3).nullable()();
	TextColumn get numero => text().named('numero').withLength(min: 0, max: 9).nullable()();
	TextColumn get codigoNumerico => text().named('codigo_numerico').withLength(min: 0, max: 8).nullable()();
	TextColumn get chaveAcesso => text().named('chave_acesso').withLength(min: 0, max: 44).nullable()();
	TextColumn get digitoChaveAcesso => text().named('digito_chave_acesso').withLength(min: 0, max: 1).nullable()();
	TextColumn get modal => text().named('modal').withLength(min: 0, max: 2).nullable()();
	DateTimeColumn get dataHoraEmissao => dateTime().named('data_hora_emissao').nullable()();
	TextColumn get tipoEmissao => text().named('tipo_emissao').withLength(min: 0, max: 1).nullable()();
	TextColumn get versaoProcessoEmissao => text().named('versao_processo_emissao').withLength(min: 0, max: 20).nullable()();
	TextColumn get tipoBpe => text().named('tipo_bpe').withLength(min: 0, max: 1).nullable()();
	TextColumn get consumidorPresenca => text().named('consumidor_presenca').withLength(min: 0, max: 1).nullable()();
	TextColumn get ufInicioViagem => text().named('uf_inicio_viagem').withLength(min: 0, max: 2).nullable()();
	IntColumn get codigoMunicipioInicioViagem => integer().named('codigo_municipio_inicio_viagem').nullable()();
	TextColumn get ufFimViagem => text().named('uf_fim_viagem').withLength(min: 0, max: 2).nullable()();
	IntColumn get codigoMunicipioFimViagem => integer().named('codigo_municipio_fim_viagem').nullable()();
	RealColumn get valorBilhete => real().named('valor_bilhete').nullable()();
	RealColumn get valorDesconto => real().named('valor_desconto').nullable()();
	RealColumn get valorPago => real().named('valor_pago').nullable()();
	RealColumn get valorTroco => real().named('valor_troco').nullable()();
	TextColumn get tipoDesconto => text().named('tipo_desconto').withLength(min: 0, max: 1).nullable()();
	TextColumn get descontoDescricao => text().named('desconto_descricao').withLength(min: 0, max: 100).nullable()();
	TextColumn get descontoConcedidoOutros => text().named('desconto_concedido_outros').withLength(min: 0, max: 20).nullable()();
	TextColumn get formaPagamento => text().named('forma_pagamento').withLength(min: 0, max: 1).nullable()();
	TextColumn get formaPagamentoOutros => text().named('forma_pagamento_outros').withLength(min: 0, max: 100).nullable()();
	TextColumn get formaPagamentoDocumento => text().named('forma_pagamento_documento').withLength(min: 0, max: 20).nullable()();
	TextColumn get cst => text().named('cst').withLength(min: 0, max: 2).nullable()();
	RealColumn get baseCalculoIcms => real().named('base_calculo_icms').nullable()();
	RealColumn get aliquotaIcms => real().named('aliquota_icms').nullable()();
	RealColumn get valorIcms => real().named('valor_icms').nullable()();
	RealColumn get percentualReducaoBcIcms => real().named('percentual_reducao_bc_icms').nullable()();
	TextColumn get informacoesAddFisco => text().named('informacoes_add_fisco').nullable()();

	@override
	Set<Column> get primaryKey => { id };	
	
}

class BpeCabecalhoGrouped {
	BpeCabecalho? bpeCabecalho; 
	List<BpeEmitenteGrouped>? bpeEmitenteGroupedList; 
	List<BpePassageiroGrouped>? bpePassageiroGroupedList; 
	List<BpeCompradorGrouped>? bpeCompradorGroupedList; 
	List<BpeViagemGrouped>? bpeViagemGroupedList; 
	List<BpeAgenciaGrouped>? bpeAgenciaGroupedList; 
	List<BpePassagemGrouped>? bpePassagemGroupedList; 

  BpeCabecalhoGrouped({
		this.bpeCabecalho, 
		this.bpeEmitenteGroupedList, 
		this.bpePassageiroGroupedList, 
		this.bpeCompradorGroupedList, 
		this.bpeViagemGroupedList, 
		this.bpeAgenciaGroupedList, 
		this.bpePassagemGroupedList, 

  });
}
