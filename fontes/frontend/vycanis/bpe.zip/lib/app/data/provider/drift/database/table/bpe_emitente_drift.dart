import 'package:drift/drift.dart';
import 'package:bpe/app/data/provider/drift/database/database.dart';

@DataClassName("BpeEmitente")
class BpeEmitentes extends Table {
	@override
	String get tableName => 'bpe_emitente';

	IntColumn get id => integer().named('id').nullable()();
	IntColumn get idBpeCabecalho => integer().named('id_bpe_cabecalho').nullable()();
	TextColumn get cnpj => text().named('cnpj').withLength(min: 0, max: 14).nullable()();
	TextColumn get ie => text().named('ie').withLength(min: 0, max: 14).nullable()();
	TextColumn get iest => text().named('iest').withLength(min: 0, max: 14).nullable()();
	TextColumn get im => text().named('im').withLength(min: 0, max: 15).nullable()();
	TextColumn get cnae => text().named('cnae').withLength(min: 0, max: 7).nullable()();
	TextColumn get crt => text().named('crt').withLength(min: 0, max: 1).nullable()();
	TextColumn get nome => text().named('nome').withLength(min: 0, max: 60).nullable()();
	TextColumn get fantasia => text().named('fantasia').withLength(min: 0, max: 60).nullable()();
	TextColumn get logradouro => text().named('logradouro').withLength(min: 0, max: 60).nullable()();
	TextColumn get numero => text().named('numero').withLength(min: 0, max: 60).nullable()();
	TextColumn get complemento => text().named('complemento').withLength(min: 0, max: 60).nullable()();
	TextColumn get bairro => text().named('bairro').withLength(min: 0, max: 60).nullable()();
	IntColumn get codigoMunicipio => integer().named('codigo_municipio').nullable()();
	TextColumn get nomeMunicipio => text().named('nome_municipio').withLength(min: 0, max: 60).nullable()();
	TextColumn get uf => text().named('uf').withLength(min: 0, max: 2).nullable()();
	TextColumn get cep => text().named('cep').withLength(min: 0, max: 8).nullable()();
	TextColumn get telefone => text().named('telefone').withLength(min: 0, max: 14).nullable()();

	@override
	Set<Column> get primaryKey => { id };	
	
}

class BpeEmitenteGrouped {
	BpeEmitente? bpeEmitente; 

  BpeEmitenteGrouped({
		this.bpeEmitente, 

  });
}
