import 'dart:convert';

import 'package:bpe/app/data/provider/api/api_provider_base.dart';
import 'package:bpe/app/data/model/model_imports.dart';

class BpeCabecalhoApiProvider extends ApiProviderBase {
  static const _path = '/bpe-cabecalho';

  Future<List<BpeCabecalhoModel>?> getList({Filter? filter}) {
    return super.getListBase(
      '$_path/',
      (json) => BpeCabecalhoModel.fromJson(json),
      filter: filter,
    );
  }

  Future<BpeCabecalhoModel?> getObject(dynamic pk) {
    return super.getObjectBase(
      _path,
      pk,
      (json) => BpeCabecalhoModel.fromJson(json),
    );
  }

  Future<BpeCabecalhoModel?>? insert(BpeCabecalhoModel model) {
    return super.insertBase(
      _path,
      model,
      (json) => BpeCabecalhoModel.fromJson(json),
    );
  }

  Future<BpeCabecalhoModel?>? update(BpeCabecalhoModel model) {
    return super.updateBase(
      _path,
      model,
      (json) => BpeCabecalhoModel.fromJson(json),
    );
  }

  Future<bool?> delete(dynamic pk) {
    return super.deleteBase(_path, pk);
  }

  Future<dynamic> transmitirBpe(BpeCabecalhoModel bpeCabecalhoModel) async {
    try {
      final response = await ApiProviderBase.httpClient.post(
        Uri.tryParse('$endpoint/bpe-cabecalho/transmite-bpe/')!,
				headers: ApiProviderBase.headerRequisition(),
				body: bpeCabecalhoModel.objectEncodeJson(),
      );

      if (response.statusCode == 200 || response.statusCode == 201) {
        if (response.headers["content-type"]!.contains("html")) {
          handleResultError(response.body, response.headers);
          return null;
        } else {
          final pdf = response.bodyBytes;
          return pdf;
        }
      } else if (response.statusCode == 418) {
        return json.decode(response.body)["message"];
      } else {
        handleResultError(response.body, response.headers);
        return null;
      }
    } on Exception catch (e) {
      handleResultError(null, null, exception: e);
    }
    return null;
  }
}
