// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'bpe_cabecalho_dao.dart';

// ignore_for_file: type=lint
mixin _$BpeCabecalhoDaoMixin on DatabaseAccessor<AppDatabase> {
  $BpeCabecalhosTable get bpeCabecalhos => attachedDatabase.bpeCabecalhos;
  $BpeEmitentesTable get bpeEmitentes => attachedDatabase.bpeEmitentes;
  $BpePassageirosTable get bpePassageiros => attachedDatabase.bpePassageiros;
  $BpeCompradorsTable get bpeCompradors => attachedDatabase.bpeCompradors;
  $BpeViagemsTable get bpeViagems => attachedDatabase.bpeViagems;
  $BpeAgenciasTable get bpeAgencias => attachedDatabase.bpeAgencias;
  $BpePassagemsTable get bpePassagems => attachedDatabase.bpePassagems;
}
