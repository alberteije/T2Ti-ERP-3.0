import 'package:drift/drift.dart';
import 'package:bpe/app/data/provider/drift/database/database.dart';
import 'package:bpe/app/data/provider/drift/database/database_imports.dart';

part 'bpe_cabecalho_dao.g.dart';

@DriftAccessor(tables: [
	BpeCabecalhos,
	BpeEmitentes,
	BpePassageiros,
	BpeCompradors,
	BpeViagems,
	BpeAgencias,
	BpePassagems,
])
class BpeCabecalhoDao extends DatabaseAccessor<AppDatabase> with _$BpeCabecalhoDaoMixin {
	final AppDatabase db;

	List<BpeCabecalho> bpeCabecalhoList = []; 
	List<BpeCabecalhoGrouped> bpeCabecalhoGroupedList = []; 

	BpeCabecalhoDao(this.db) : super(db);

	Future<List<BpeCabecalho>> getList() async {
		bpeCabecalhoList = await select(bpeCabecalhos).get();
		return bpeCabecalhoList;
	}

	Future<List<BpeCabecalho>> getListFilter(String field, String value) async {
		final query = " $field like '%$value%'";
		final expression = CustomExpression<bool>(query);
		bpeCabecalhoList = await (select(bpeCabecalhos)..where((t) => expression)).get();
		return bpeCabecalhoList;	 
	}

	Future<List<BpeCabecalhoGrouped>> getGroupedList({String? field, dynamic value}) async {
		final query = select(bpeCabecalhos)
			.join([]);

		if (field != null && field != '') { 
			final column = bpeCabecalhos.$columns.where(((column) => column.$name == field)).first;
			if (column is TextColumn) {
				query.where((column as TextColumn).like('%$value%'));
			} else if (column is IntColumn) {
				query.where(column.equals(int.tryParse(value) as Object));
			} else if (column is RealColumn) {
				query.where(column.equals(double.tryParse(value) as Object));
			}
		}

		bpeCabecalhoGroupedList = await query.map((row) {
			final bpeCabecalho = row.readTableOrNull(bpeCabecalhos); 

			return BpeCabecalhoGrouped(
				bpeCabecalho: bpeCabecalho, 

			);
		}).get();

		// fill internal lists
		dynamic expression;
		for (var bpeCabecalhoGrouped in bpeCabecalhoGroupedList) {
			bpeCabecalhoGrouped.bpeEmitenteGroupedList = [];
			final queryBpeEmitente = ' id_bpe_cabecalho = ${bpeCabecalhoGrouped.bpeCabecalho!.id}';
			expression = CustomExpression<bool>(queryBpeEmitente);
			final bpeEmitenteList = await (select(bpeEmitentes)..where((t) => expression)).get();
			for (var bpeEmitente in bpeEmitenteList) {
				BpeEmitenteGrouped bpeEmitenteGrouped = BpeEmitenteGrouped(
					bpeEmitente: bpeEmitente,
				);
				bpeCabecalhoGrouped.bpeEmitenteGroupedList!.add(bpeEmitenteGrouped);
			}

			bpeCabecalhoGrouped.bpePassageiroGroupedList = [];
			final queryBpePassageiro = ' id_bpe_cabecalho = ${bpeCabecalhoGrouped.bpeCabecalho!.id}';
			expression = CustomExpression<bool>(queryBpePassageiro);
			final bpePassageiroList = await (select(bpePassageiros)..where((t) => expression)).get();
			for (var bpePassageiro in bpePassageiroList) {
				BpePassageiroGrouped bpePassageiroGrouped = BpePassageiroGrouped(
					bpePassageiro: bpePassageiro,
				);
				bpeCabecalhoGrouped.bpePassageiroGroupedList!.add(bpePassageiroGrouped);
			}

			bpeCabecalhoGrouped.bpeCompradorGroupedList = [];
			final queryBpeComprador = ' id_bpe_cabecalho = ${bpeCabecalhoGrouped.bpeCabecalho!.id}';
			expression = CustomExpression<bool>(queryBpeComprador);
			final bpeCompradorList = await (select(bpeCompradors)..where((t) => expression)).get();
			for (var bpeComprador in bpeCompradorList) {
				BpeCompradorGrouped bpeCompradorGrouped = BpeCompradorGrouped(
					bpeComprador: bpeComprador,
				);
				bpeCabecalhoGrouped.bpeCompradorGroupedList!.add(bpeCompradorGrouped);
			}

			bpeCabecalhoGrouped.bpeViagemGroupedList = [];
			final queryBpeViagem = ' id_bpe_cabecalho = ${bpeCabecalhoGrouped.bpeCabecalho!.id}';
			expression = CustomExpression<bool>(queryBpeViagem);
			final bpeViagemList = await (select(bpeViagems)..where((t) => expression)).get();
			for (var bpeViagem in bpeViagemList) {
				BpeViagemGrouped bpeViagemGrouped = BpeViagemGrouped(
					bpeViagem: bpeViagem,
				);
				bpeCabecalhoGrouped.bpeViagemGroupedList!.add(bpeViagemGrouped);
			}

			bpeCabecalhoGrouped.bpeAgenciaGroupedList = [];
			final queryBpeAgencia = ' id_bpe_cabecalho = ${bpeCabecalhoGrouped.bpeCabecalho!.id}';
			expression = CustomExpression<bool>(queryBpeAgencia);
			final bpeAgenciaList = await (select(bpeAgencias)..where((t) => expression)).get();
			for (var bpeAgencia in bpeAgenciaList) {
				BpeAgenciaGrouped bpeAgenciaGrouped = BpeAgenciaGrouped(
					bpeAgencia: bpeAgencia,
				);
				bpeCabecalhoGrouped.bpeAgenciaGroupedList!.add(bpeAgenciaGrouped);
			}

			bpeCabecalhoGrouped.bpePassagemGroupedList = [];
			final queryBpePassagem = ' id_bpe_cabecalho = ${bpeCabecalhoGrouped.bpeCabecalho!.id}';
			expression = CustomExpression<bool>(queryBpePassagem);
			final bpePassagemList = await (select(bpePassagems)..where((t) => expression)).get();
			for (var bpePassagem in bpePassagemList) {
				BpePassagemGrouped bpePassagemGrouped = BpePassagemGrouped(
					bpePassagem: bpePassagem,
				);
				bpeCabecalhoGrouped.bpePassagemGroupedList!.add(bpePassagemGrouped);
			}

		}		

		return bpeCabecalhoGroupedList;	
	}

	Future<BpeCabecalho?> getObject(dynamic pk) async {
		return await (select(bpeCabecalhos)..where((t) => t.id.equals(pk))).getSingleOrNull();
	} 

	Future<BpeCabecalho?> getObjectFilter(String field, String value) async {
		final query = "SELECT * FROM bpe_cabecalho WHERE $field like '%$value%'";
		return (await customSelect(query).getSingleOrNull()) as BpeCabecalho;		 
	} 

	Future<BpeCabecalhoGrouped?> getObjectGrouped({String? field, dynamic value}) async {
		final result = await getGroupedList(field: field, value: value);

		if (result.length != 1) {
			return null;
		} else {
			return result[0];
		} 
	}

	Future<int> insertObject(BpeCabecalhoGrouped object) {
		return transaction(() async {
			final maxPk = await lastPk();
			object.bpeCabecalho = object.bpeCabecalho!.copyWith(id: Value(maxPk + 1));
			final pkInserted = await into(bpeCabecalhos).insert(object.bpeCabecalho!);
			object.bpeCabecalho = object.bpeCabecalho!.copyWith(id: Value(pkInserted));			 
			await insertChildren(object);
			return pkInserted;
		});		
	}	 

	Future<bool> updateObject(BpeCabecalhoGrouped object) {
		return transaction(() async {
			await deleteChildren(object);
			await insertChildren(object);
			return update(bpeCabecalhos).replace(object.bpeCabecalho!);
		});	 
	} 

	Future<int> deleteObject(BpeCabecalhoGrouped object) {
		return transaction(() async {
			await deleteChildren(object);
			return delete(bpeCabecalhos).delete(object.bpeCabecalho!);
		});		
	}

	Future<void> insertChildren(BpeCabecalhoGrouped object) async {
		for (var bpeEmitenteGrouped in object.bpeEmitenteGroupedList!) {
			bpeEmitenteGrouped.bpeEmitente = bpeEmitenteGrouped.bpeEmitente?.copyWith(
				id: const Value(null),
				idBpeCabecalho: Value(object.bpeCabecalho!.id),
			);
			await into(bpeEmitentes).insert(bpeEmitenteGrouped.bpeEmitente!);
		}
		for (var bpePassageiroGrouped in object.bpePassageiroGroupedList!) {
			bpePassageiroGrouped.bpePassageiro = bpePassageiroGrouped.bpePassageiro?.copyWith(
				id: const Value(null),
				idBpeCabecalho: Value(object.bpeCabecalho!.id),
			);
			await into(bpePassageiros).insert(bpePassageiroGrouped.bpePassageiro!);
		}
		for (var bpeCompradorGrouped in object.bpeCompradorGroupedList!) {
			bpeCompradorGrouped.bpeComprador = bpeCompradorGrouped.bpeComprador?.copyWith(
				id: const Value(null),
				idBpeCabecalho: Value(object.bpeCabecalho!.id),
			);
			await into(bpeCompradors).insert(bpeCompradorGrouped.bpeComprador!);
		}
		for (var bpeViagemGrouped in object.bpeViagemGroupedList!) {
			bpeViagemGrouped.bpeViagem = bpeViagemGrouped.bpeViagem?.copyWith(
				id: const Value(null),
				idBpeCabecalho: Value(object.bpeCabecalho!.id),
			);
			await into(bpeViagems).insert(bpeViagemGrouped.bpeViagem!);
		}
		for (var bpeAgenciaGrouped in object.bpeAgenciaGroupedList!) {
			bpeAgenciaGrouped.bpeAgencia = bpeAgenciaGrouped.bpeAgencia?.copyWith(
				id: const Value(null),
				idBpeCabecalho: Value(object.bpeCabecalho!.id),
			);
			await into(bpeAgencias).insert(bpeAgenciaGrouped.bpeAgencia!);
		}
		for (var bpePassagemGrouped in object.bpePassagemGroupedList!) {
			bpePassagemGrouped.bpePassagem = bpePassagemGrouped.bpePassagem?.copyWith(
				id: const Value(null),
				idBpeCabecalho: Value(object.bpeCabecalho!.id),
			);
			await into(bpePassagems).insert(bpePassagemGrouped.bpePassagem!);
		}
	}
	
	Future<void> deleteChildren(BpeCabecalhoGrouped object) async {
		await (delete(bpeEmitentes)..where((t) => t.idBpeCabecalho.equals(object.bpeCabecalho!.id!))).go();
		await (delete(bpePassageiros)..where((t) => t.idBpeCabecalho.equals(object.bpeCabecalho!.id!))).go();
		await (delete(bpeCompradors)..where((t) => t.idBpeCabecalho.equals(object.bpeCabecalho!.id!))).go();
		await (delete(bpeViagems)..where((t) => t.idBpeCabecalho.equals(object.bpeCabecalho!.id!))).go();
		await (delete(bpeAgencias)..where((t) => t.idBpeCabecalho.equals(object.bpeCabecalho!.id!))).go();
		await (delete(bpePassagems)..where((t) => t.idBpeCabecalho.equals(object.bpeCabecalho!.id!))).go();
	}

	Future<int> lastPk() async {
		final result = await customSelect("select MAX(id) as LAST from bpe_cabecalho").getSingleOrNull();
		return result?.data["LAST"] ?? 0;
	} 
}