import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:pluto_grid/pluto_grid.dart';
import 'package:bpe/app/page/shared_widget/input/input_imports.dart';

import 'package:bpe/app/page/page_imports.dart';
import 'package:bpe/app/page/shared_widget/message_dialog.dart';
import 'package:bpe/app/page/grid_columns/grid_columns_imports.dart';
import 'package:bpe/app/controller/controller_imports.dart';
import 'package:bpe/app/data/model/model_imports.dart';

class BpeViagemController extends ControllerBase<BpeViagemModel, void> {

  BpeViagemController() : super(repository: null) {
    dbColumns = BpeViagemModel.dbColumns;
    aliasColumns = BpeViagemModel.aliasColumns;
    gridColumns = bpeViagemGridColumns();
    functionName = "bpe_viagem";
    screenTitle = "Viagem";
  }

  final _bpeViagemModel = BpeViagemModel().obs;
  BpeViagemModel get bpeViagemModel => _bpeViagemModel.value;
  set bpeViagemModel(value) => _bpeViagemModel.value = value ?? BpeViagemModel();

  List<BpeViagemModel> get bpeViagemModelList => Get.find<BpeCabecalhoController>().currentModel.bpeViagemModelList ?? [];

  final _userMadeChanges = false.obs;
  get userMadeChanges => _userMadeChanges.value;
  set userMadeChanges(value) => _userMadeChanges.value = value;

  final _formWasChangedDetail = false.obs;
  bool get formWasChangedDetail => _formWasChangedDetail.value;
  set formWasChangedDetail(value) => _formWasChangedDetail.value = value;

  late PlutoGridStateManager _plutoGridStateManager;
  @override
  PlutoGridStateManager get plutoGridStateManager => _plutoGridStateManager;
  @override
  set plutoGridStateManager(value) => _plutoGridStateManager = value;

  final bpeViagemScaffoldKey = GlobalKey<ScaffoldState>();
  final bpeViagemFormKey = GlobalKey<FormState>();

  @override
  BpeViagemModel createNewModel() => BpeViagemModel();

  @override
  final standardFieldForFilter = BpeViagemModel.aliasColumns[BpeViagemModel.dbColumns.indexOf('codigo_percurso')];

  final codigoPercursoController = TextEditingController();
  final descricaoPercursoController = TextEditingController();
  final tipoViagemController = CustomDropdownButtonController('00-regular');
  final tipoServicoController = CustomDropdownButtonController('1-Convencional com sanitário');
  final tipoAcomodacaoController = CustomDropdownButtonController('1-Assento/poltrona');
  final tipoTrechoController = CustomDropdownButtonController('1-Normal');
  final dataHoraViagemController = DatePickerItemController(null);
  final dataHoraConexaoController = DatePickerItemController(null);
  final prefixoLinhaController = TextEditingController();
  final poltronaController = TextEditingController();
  final plataformaController = TextEditingController();

  final Map<String, dynamic> mobileConfig = {
    'primaryColumns': ['codigo_percurso'],
    'secondaryColumns': ['descricao_percurso'],
  };

  List<Map<String, dynamic>> get mobileItems {
    return modelList.map((bpeViagem) => bpeViagem.toJson).toList();
  }

  @override
  List<PlutoRow> plutoRows() => List<PlutoRow>.from(bpeViagemModelList.map((model) => model.toPlutoRow()));

  @override
  Future<void> getList({Filter? filter}) async {}

  @override
  void prepareForInsert() {
    isNewRecord = true;
    bpeViagemModel = createNewModel();
    _resetForm();
    Get.to(() => BpeViagemEditPage());
  }

  void _resetForm() {
    formWasChangedDetail = false;
    codigoPercursoController.text = '';
    descricaoPercursoController.text = '';
    tipoViagemController.selected = '00-regular';
    tipoServicoController.selected = '1-Convencional com sanitário';
    tipoAcomodacaoController.selected = '1-Assento/poltrona';
    tipoTrechoController.selected = '1-Normal';
    dataHoraViagemController.date = null;
    dataHoraConexaoController.date = null;
    prefixoLinhaController.text = '';
    poltronaController.text = '';
    plataformaController.text = '';
  }

  @override
  void selectRowForEditing(PlutoRow? row) async {
    if (row == null) {
      showInfoSnackBar(message: 'message_select_one_to_edited'.tr);
      return;
    }

    selectRowForEditingByTempId(row.cells['tempId']?.value);
  }

  @override
  void selectRowForEditingById(int id) {}

  void selectRowForEditingByTempId(String tempId) {
		isNewRecord = false;
    final model = bpeViagemModelList.firstWhere((m) => m.tempId == tempId);
    bpeViagemModel = model.clone();
		bpeViagemModel.tempId = model.tempId;
    updateControllersFromModel();
    Get.to(() => BpeViagemEditPage());
  }

  void updateControllersFromModel() {
    codigoPercursoController.text = bpeViagemModel.codigoPercurso ?? '';
    descricaoPercursoController.text = bpeViagemModel.descricaoPercurso ?? '';
    tipoViagemController.selected = bpeViagemModel.tipoViagem ?? '00-regular';
    tipoServicoController.selected = bpeViagemModel.tipoServico ?? '1-Convencional com sanitário';
    tipoAcomodacaoController.selected = bpeViagemModel.tipoAcomodacao ?? '1-Assento/poltrona';
    tipoTrechoController.selected = bpeViagemModel.tipoTrecho ?? '1-Normal';
    dataHoraViagemController.date = bpeViagemModel.dataHoraViagem;
    dataHoraConexaoController.date = bpeViagemModel.dataHoraConexao;
    prefixoLinhaController.text = bpeViagemModel.prefixoLinha ?? '';
    poltronaController.text = bpeViagemModel.poltrona ?? '';
    plataformaController.text = bpeViagemModel.plataforma ?? '';
    formWasChangedDetail = false;
  }

  @override
  Future<void> save() async {
    if (!bpeViagemFormKey.currentState!.validate()) {
      showErrorSnackBar(message: 'validator_form_message'.tr);
      return;
    }

    if (formWasChangedDetail) {
      if (isNewRecord) {
        bpeViagemModelList.insert(0, bpeViagemModel.clone());
      } else {
        final index = bpeViagemModelList.indexWhere((m) => m.tempId == bpeViagemModel.tempId);
        if (index >= 0) {
          bpeViagemModelList[index] = bpeViagemModel.clone();
        }
      }

      userMadeChanges = true;
      loadData();
      Get.back(result: true);
    } else {
      Get.back();
    }
  }


  @override
  Future deleteSelected() async {
    final currentRow = plutoGridStateManager.currentRow;
    if (currentRow == null) {
      showInfoSnackBar(message: 'message_select_one_to_delete'.tr);
      return null;
    }
    showDeleteDialog(() async {
      final id = currentRow.cells['id']?.value;
      final tempId = currentRow.cells['tempId']?.value;
      bpeViagemModelList.removeWhere((model) => (id != 0 && model.id == id) || (id == 0 && model.tempId == tempId));
      plutoGridStateManager.removeCurrentRow();
      userMadeChanges = true;
    });
  }

  @override
  void preventDataLoss() {
    if (formWasChangedDetail) {
      showQuestionDialog('message_data_loss'.tr, () => Get.back());
    } else {
      formWasChangedDetail = false;
      Get.back();
    }
  }

  @override
  void onClose() {
    codigoPercursoController.dispose();
    descricaoPercursoController.dispose();
    tipoViagemController.dispose();
    tipoServicoController.dispose();
    tipoAcomodacaoController.dispose();
    tipoTrechoController.dispose();
    dataHoraViagemController.dispose();
    dataHoraConexaoController.dispose();
    prefixoLinhaController.dispose();
    poltronaController.dispose();
    plataformaController.dispose();
  }

}