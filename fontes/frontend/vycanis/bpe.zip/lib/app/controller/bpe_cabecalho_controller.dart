import 'dart:typed_data';

import 'package:bpe/app/page/shared_page/shared_page_imports.dart';
import 'package:flutter/material.dart';
import 'dart:math';
import 'package:get/get.dart';
import 'package:extended_masked_text/extended_masked_text.dart';
import 'package:bpe/app/page/shared_widget/input/input_imports.dart';

import 'package:bpe/app/infra/infra_imports.dart';
import 'package:bpe/app/page/page_imports.dart';
import 'package:bpe/app/page/shared_widget/message_dialog.dart';
import 'package:bpe/app/page/grid_columns/grid_columns_imports.dart';
import 'package:bpe/app/routes/app_routes.dart';
import 'package:bpe/app/controller/controller_imports.dart';
import 'package:bpe/app/data/model/model_imports.dart';
import 'package:bpe/app/data/repository/bpe_cabecalho_repository.dart';

class BpeCabecalhoController extends ControllerBase<BpeCabecalhoModel, BpeCabecalhoRepository> 
with GetSingleTickerProviderStateMixin {

  BpeCabecalhoController({required super.repository}) {
    dbColumns = BpeCabecalhoModel.dbColumns;
    aliasColumns = BpeCabecalhoModel.aliasColumns;
    gridColumns = bpeCabecalhoGridColumns();
    functionName = "bpe_cabecalho";
    screenTitle = "Principal";
  }

  final bpeCabecalhoScaffoldKey = GlobalKey<ScaffoldState>();
  final bpeCabecalhoTabPageScaffoldKey = GlobalKey<ScaffoldState>();
  final bpeCabecalhoFormKey = GlobalKey<FormState>();
  late TabController tabController;
  String? mandatoryMessage;  

  @override
  BpeCabecalhoModel createNewModel() => BpeCabecalhoModel();

  @override
  final standardFieldForFilter = BpeCabecalhoModel.aliasColumns[BpeCabecalhoModel.dbColumns.indexOf('uf_emitente')];

  final ufEmitenteController = TextEditingController();
  final ambienteController = CustomDropdownButtonController('1 - Produção');
  final modeloController = CustomDropdownButtonController('63');
  final serieController = TextEditingController();
  final numeroController = TextEditingController();
  final codigoNumericoController = TextEditingController();
  final chaveAcessoController = TextEditingController();
  final digitoChaveAcessoController = TextEditingController();
  final modalController = CustomDropdownButtonController('1 - Rodoviário');
  final dataHoraEmissaoController = DatePickerItemController(null);
  final tipoEmissaoController = CustomDropdownButtonController('1 - Normal');
  final versaoProcessoEmissaoController = TextEditingController();
  final tipoBpeController = CustomDropdownButtonController('0 - BP-e normal');
  final consumidorPresencaController = CustomDropdownButtonController('1=Operação presencial não embarcado');
  final ufInicioViagemController = CustomDropdownButtonController('AC');
  final codigoMunicipioInicioViagemController = MoneyMaskedTextController(precision: 0, decimalSeparator: '', thousandSeparator: '');
  final ufFimViagemController = CustomDropdownButtonController('AC');
  final codigoMunicipioFimViagemController = MoneyMaskedTextController(precision: 0, decimalSeparator: '', thousandSeparator: '');
  final valorBilheteController = MoneyMaskedTextController();
  final valorDescontoController = MoneyMaskedTextController();
  final valorPagoController = MoneyMaskedTextController();
  final valorTrocoController = MoneyMaskedTextController();
  final tipoDescontoController = CustomDropdownButtonController('01 - Tarifa promocional');
  final descontoDescricaoController = TextEditingController();
  final descontoConcedidoOutrosController = TextEditingController();
  final formaPagamentoController = CustomDropdownButtonController('01-Dinheiro');
  final formaPagamentoOutrosController = TextEditingController();
  final formaPagamentoDocumentoController = TextEditingController();
  final cstController = TextEditingController();
  final baseCalculoIcmsController = MoneyMaskedTextController();
  final aliquotaIcmsController = MoneyMaskedTextController();
  final valorIcmsController = MoneyMaskedTextController();
  final percentualReducaoBcIcmsController = MoneyMaskedTextController();
  final informacoesAddFiscoController = TextEditingController();

  final Map<String, dynamic> mobileConfig = {
    'primaryColumns': ['uf_emitente'],
    'secondaryColumns': ['ambiente'],
  };

  List<Map<String, dynamic>> get mobileItems {
    return modelList.map((bpeCabecalho) => bpeCabecalho.toJson).toList();
  }

  @override
  void prepareForInsert() {
    isNewRecord = true;
    currentModel = createNewModel();
    _resetForm();
    tabController.animateTo(0);
    updateControllersFromModel();
    Get.toNamed(Routes.bpeCabecalhoTabPage);
  }

  void _resetForm() {
    formWasChanged = false;
    ufEmitenteController.text = '';
    ambienteController.selected = '1 - Produção';
    modeloController.selected = '63';
    serieController.text = '';
    numeroController.text = '';
    codigoNumericoController.text = '';
    chaveAcessoController.text = '';
    digitoChaveAcessoController.text = '';
    modalController.selected = '1 - Rodoviário';
    dataHoraEmissaoController.date = null;
    tipoEmissaoController.selected = '1 - Normal';
    versaoProcessoEmissaoController.text = '';
    tipoBpeController.selected = '0 - BP-e normal';
    consumidorPresencaController.selected = '1=Operação presencial não embarcado';
    ufInicioViagemController.selected = 'AC';
    codigoMunicipioInicioViagemController.updateValue(0);
    ufFimViagemController.selected = 'AC';
    codigoMunicipioFimViagemController.updateValue(0);
    valorBilheteController.updateValue(0);
    valorDescontoController.updateValue(0);
    valorPagoController.updateValue(0);
    valorTrocoController.updateValue(0);
    tipoDescontoController.selected = '01 - Tarifa promocional';
    descontoDescricaoController.text = '';
    descontoConcedidoOutrosController.text = '';
    formaPagamentoController.selected = '01-Dinheiro';
    formaPagamentoOutrosController.text = '';
    formaPagamentoDocumentoController.text = '';
    cstController.text = '';
    baseCalculoIcmsController.updateValue(0);
    aliquotaIcmsController.updateValue(0);
    valorIcmsController.updateValue(0);
    percentualReducaoBcIcmsController.updateValue(0);
    informacoesAddFiscoController.text = '';
  }

  @override
  void selectRowForEditingById(int id) {
    final model = modelList.firstWhere((m) => m.id == id);
    currentModel = model.clone();
    updateControllersFromModel();
    tabController.animateTo(0);
    Get.toNamed(Routes.bpeCabecalhoTabPage);
  }

  _configureChildrenControllers() {
    //Emitente
		Get.put<BpeEmitenteController>(BpeEmitenteController()); 

    //Passageiro
		Get.put<BpePassageiroController>(BpePassageiroController()); 

    //Comprador
		Get.put<BpeCompradorController>(BpeCompradorController()); 

    //Viagem
		Get.put<BpeViagemController>(BpeViagemController()); 

    //Agência
		Get.put<BpeAgenciaController>(BpeAgenciaController()); 

    //Passagem
		Get.put<BpePassagemController>(BpePassagemController()); 

  }
	
	_releaseChildrenControllers() {
    //Emitente
		Get.delete<BpeEmitenteController>(); 

    //Passageiro
		Get.delete<BpePassageiroController>(); 

    //Comprador
		Get.delete<BpeCompradorController>(); 

    //Viagem
		Get.delete<BpeViagemController>(); 

    //Agência
		Get.delete<BpeAgenciaController>(); 

    //Passagem
		Get.delete<BpePassagemController>(); 

	}
  
  void updateControllersFromModel() {
    ufEmitenteController.text = currentModel.ufEmitente ?? '';
    ambienteController.selected = currentModel.ambiente ?? '1 - Produção';
    modeloController.selected = currentModel.modelo ?? '63';
    serieController.text = currentModel.serie ?? '';
    numeroController.text = currentModel.numero ?? '';
    codigoNumericoController.text = currentModel.codigoNumerico ?? '';
    chaveAcessoController.text = currentModel.chaveAcesso ?? '';
    digitoChaveAcessoController.text = currentModel.digitoChaveAcesso ?? '';
    modalController.selected = currentModel.modal ?? '1 - Rodoviário';
    dataHoraEmissaoController.date = currentModel.dataHoraEmissao;
    tipoEmissaoController.selected = currentModel.tipoEmissao ?? '1 - Normal';
    versaoProcessoEmissaoController.text = currentModel.versaoProcessoEmissao ?? '';
    tipoBpeController.selected = currentModel.tipoBpe ?? '0 - BP-e normal';
    consumidorPresencaController.selected = currentModel.consumidorPresenca ?? '1=Operação presencial não embarcado';
    ufInicioViagemController.selected = currentModel.ufInicioViagem ?? 'AC';
    codigoMunicipioInicioViagemController.updateValue((currentModel.codigoMunicipioInicioViagem ?? 0).toDouble());
    ufFimViagemController.selected = currentModel.ufFimViagem ?? 'AC';
    codigoMunicipioFimViagemController.updateValue((currentModel.codigoMunicipioFimViagem ?? 0).toDouble());
    valorBilheteController.updateValue(currentModel.valorBilhete ?? 0);
    valorDescontoController.updateValue(currentModel.valorDesconto ?? 0);
    valorPagoController.updateValue(currentModel.valorPago ?? 0);
    valorTrocoController.updateValue(currentModel.valorTroco ?? 0);
    tipoDescontoController.selected = currentModel.tipoDesconto ?? '01 - Tarifa promocional';
    descontoDescricaoController.text = currentModel.descontoDescricao ?? '';
    descontoConcedidoOutrosController.text = currentModel.descontoConcedidoOutros ?? '';
    formaPagamentoController.selected = currentModel.formaPagamento ?? '01-Dinheiro';
    formaPagamentoOutrosController.text = currentModel.formaPagamentoOutros ?? '';
    formaPagamentoDocumentoController.text = currentModel.formaPagamentoDocumento ?? '';
    cstController.text = currentModel.cst ?? '';
    baseCalculoIcmsController.updateValue(currentModel.baseCalculoIcms ?? 0);
    aliquotaIcmsController.updateValue(currentModel.aliquotaIcms ?? 0);
    valorIcmsController.updateValue(currentModel.valorIcms ?? 0);
    percentualReducaoBcIcmsController.updateValue(currentModel.percentualReducaoBcIcms ?? 0);
    informacoesAddFiscoController.text = currentModel.informacoesAddFisco ?? '';

    formWasChanged = false;
    _updateChildrenControllersFromModel();
  }

  void _updateChildrenControllersFromModel() {
    //Emitente
		final bpeEmitenteController = Get.find<BpeEmitenteController>(); 
		bpeEmitenteController.userMadeChanges = false; 

    //Passageiro
		final bpePassageiroController = Get.find<BpePassageiroController>(); 
		bpePassageiroController.userMadeChanges = false; 

    //Comprador
		final bpeCompradorController = Get.find<BpeCompradorController>(); 
		bpeCompradorController.userMadeChanges = false; 

    //Viagem
		final bpeViagemController = Get.find<BpeViagemController>(); 
		bpeViagemController.userMadeChanges = false; 

    //Agência
		final bpeAgenciaController = Get.find<BpeAgenciaController>(); 
		bpeAgenciaController.userMadeChanges = false; 

    //Passagem
		final bpePassagemController = Get.find<BpePassagemController>(); 
		bpePassagemController.userMadeChanges = false; 

  }

  @override
  Future<void> save() async {
    if (!validateCurrentForm()) return;
    if (validateForms()) {
      if (userMadeChanges()) {
        final existingIndex = modelList.indexWhere((m) => m.id == currentModel.id);

        if (existingIndex >= 0) {
          modelList[existingIndex] = currentModel.clone();
        }

        final result = await repository.save(bpeCabecalhoModel: currentModel);
        if (result == null) return;

        if (existingIndex >= 0) {
          modelList[existingIndex] = result;
        } else {
          modelList.insert(0, result);
        }

        if (!GetPlatform.isMobile) {
          updateGridRow(result);
        }

        Get.back(result: true);
      } else {
        Get.back();
      }
    } 
  }


  List<Tab> tabItems = [
    Tab( 
			icon: Icon(iconDataList[Random().nextInt(10)]), 
			text: 'Principal', 
		),
    Tab( 
			icon: Icon(iconDataList[Random().nextInt(10)]), 
			text: 'Emitente', 
		),
    Tab( 
			icon: Icon(iconDataList[Random().nextInt(10)]), 
			text: 'Passageiro', 
		),
    Tab( 
			icon: Icon(iconDataList[Random().nextInt(10)]), 
			text: 'Comprador', 
		),
    Tab( 
			icon: Icon(iconDataList[Random().nextInt(10)]), 
			text: 'Viagem', 
		),
    Tab( 
			icon: Icon(iconDataList[Random().nextInt(10)]), 
			text: 'Agência', 
		),
    Tab( 
			icon: Icon(iconDataList[Random().nextInt(10)]), 
			text: 'Passagem', 
		),
  ];

  List<Widget> tabPages() {
    return [
      BpeCabecalhoEditPage(),
      const BpeEmitenteListPage(),
      const BpePassageiroListPage(),
      const BpeCompradorListPage(),
      const BpeViagemListPage(),
      const BpeAgenciaListPage(),
      const BpePassagemListPage(),
    ];
  }

  @override
  void preventDataLoss() {
    if (userMadeChanges()) {
      showQuestionDialog('message_data_loss'.tr, () { 
        Get.back(); 
      });
    } else {
      Get.back();
    }
  }  

  bool userMadeChanges() {
    return
    formWasChanged 
    || 
		Get.find<BpeEmitenteController>().userMadeChanges
    || 
		Get.find<BpePassageiroController>().userMadeChanges
    || 
		Get.find<BpeCompradorController>().userMadeChanges
    || 
		Get.find<BpeViagemController>().userMadeChanges
    || 
		Get.find<BpeAgenciaController>().userMadeChanges
    || 
		Get.find<BpePassagemController>().userMadeChanges
    ;
  }

  void tabChange(int index) {
    validateCurrentForm();
  }

  bool validateCurrentForm() {
    return true;
  }

  bool validateForms() {
    return true;
  }

  Future transmitirBpe() async {
    if (currentModel.id == null) {
      showErrorSnackBar(message: 'Primeiro salve o documento para então transmiti-lo.');
      return;
    }

    showQuestionDialog('Deseja Gerar e Transmitir o BP-e?', () async {
      try {
        final result = await repository.transmitirBpe(bpeCabecalhoModel: currentModel);
        if (result == null) return;

        if (result is String) {
          showErrorDialog('Ocorreu um problema na geração do BP-e: \n$result');
        } else if (result is Uint8List) {
          _imprimirDanfse(result);
        }
      } catch (e) {
        showErrorSnackBar(message: "Erro ao transmitir o BP-e: ${e.toString()}");
      }
    });
  }

  void _imprimirDanfse(Uint8List dabpe) {
    Get.to(() => PdfPage(
      title: "DaBPe",
      pdfFile: dabpe,
    ));
  }

  @override
  void onInit() {
    super.onInit();
    tabController = TabController(vsync: this, length: tabItems.length);
    _configureChildrenControllers();
  }
	
  @override
  void onClose() {
    tabController.dispose();
    ufEmitenteController.dispose();
    ambienteController.dispose();
    modeloController.dispose();
    serieController.dispose();
    numeroController.dispose();
    codigoNumericoController.dispose();
    chaveAcessoController.dispose();
    digitoChaveAcessoController.dispose();
    modalController.dispose();
    dataHoraEmissaoController.dispose();
    tipoEmissaoController.dispose();
    versaoProcessoEmissaoController.dispose();
    tipoBpeController.dispose();
    consumidorPresencaController.dispose();
    ufInicioViagemController.dispose();
    codigoMunicipioInicioViagemController.dispose();
    ufFimViagemController.dispose();
    codigoMunicipioFimViagemController.dispose();
    valorBilheteController.dispose();
    valorDescontoController.dispose();
    valorPagoController.dispose();
    valorTrocoController.dispose();
    tipoDescontoController.dispose();
    descontoDescricaoController.dispose();
    descontoConcedidoOutrosController.dispose();
    formaPagamentoController.dispose();
    formaPagamentoOutrosController.dispose();
    formaPagamentoDocumentoController.dispose();
    cstController.dispose();
    baseCalculoIcmsController.dispose();
    aliquotaIcmsController.dispose();
    valorIcmsController.dispose();
    percentualReducaoBcIcmsController.dispose();
    informacoesAddFiscoController.dispose();
    _releaseChildrenControllers();
    super.onClose();
  }	
}