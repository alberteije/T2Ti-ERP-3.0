import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:pluto_grid/pluto_grid.dart';
import 'package:extended_masked_text/extended_masked_text.dart';
import 'package:bpe/app/page/shared_widget/input/input_imports.dart';

import 'package:bpe/app/page/page_imports.dart';
import 'package:bpe/app/page/shared_widget/message_dialog.dart';
import 'package:bpe/app/page/grid_columns/grid_columns_imports.dart';
import 'package:bpe/app/controller/controller_imports.dart';
import 'package:bpe/app/data/model/model_imports.dart';

class BpeAgenciaController extends ControllerBase<BpeAgenciaModel, void> {

  BpeAgenciaController() : super(repository: null) {
    dbColumns = BpeAgenciaModel.dbColumns;
    aliasColumns = BpeAgenciaModel.aliasColumns;
    gridColumns = bpeAgenciaGridColumns();
    functionName = "bpe_agencia";
    screenTitle = "Agência";
  }

  final _bpeAgenciaModel = BpeAgenciaModel().obs;
  BpeAgenciaModel get bpeAgenciaModel => _bpeAgenciaModel.value;
  set bpeAgenciaModel(value) => _bpeAgenciaModel.value = value ?? BpeAgenciaModel();

  List<BpeAgenciaModel> get bpeAgenciaModelList => Get.find<BpeCabecalhoController>().currentModel.bpeAgenciaModelList ?? [];

  final _userMadeChanges = false.obs;
  get userMadeChanges => _userMadeChanges.value;
  set userMadeChanges(value) => _userMadeChanges.value = value;

  final _formWasChangedDetail = false.obs;
  bool get formWasChangedDetail => _formWasChangedDetail.value;
  set formWasChangedDetail(value) => _formWasChangedDetail.value = value;

  late PlutoGridStateManager _plutoGridStateManager;
  @override
  PlutoGridStateManager get plutoGridStateManager => _plutoGridStateManager;
  @override
  set plutoGridStateManager(value) => _plutoGridStateManager = value;

  final bpeAgenciaScaffoldKey = GlobalKey<ScaffoldState>();
  final bpeAgenciaFormKey = GlobalKey<FormState>();

  @override
  BpeAgenciaModel createNewModel() => BpeAgenciaModel();

  @override
  final standardFieldForFilter = BpeAgenciaModel.aliasColumns[BpeAgenciaModel.dbColumns.indexOf('cnpj')];

  final cnpjController = MaskedTextController(mask: '00.000.000/0000-00',);
  final nomeController = TextEditingController();
  final telefoneController = TextEditingController();
  final logradouroController = TextEditingController();
  final numeroController = TextEditingController();
  final complementoController = TextEditingController();
  final bairroController = TextEditingController();
  final codigoMunicipioController = MoneyMaskedTextController(precision: 0, decimalSeparator: '', thousandSeparator: '');
  final nomeMunicipioController = TextEditingController();
  final ufController = CustomDropdownButtonController('AC');
  final cepController = MaskedTextController(mask: '00000-000',);
  final codigoPaisController = MoneyMaskedTextController(precision: 0, decimalSeparator: '', thousandSeparator: '');
  final nomePaisController = TextEditingController();
  final emailController = TextEditingController();

  final Map<String, dynamic> mobileConfig = {
    'primaryColumns': ['cnpj'],
    'secondaryColumns': ['nome'],
  };

  List<Map<String, dynamic>> get mobileItems {
    return modelList.map((bpeAgencia) => bpeAgencia.toJson).toList();
  }

  @override
  List<PlutoRow> plutoRows() => List<PlutoRow>.from(bpeAgenciaModelList.map((model) => model.toPlutoRow()));

  @override
  Future<void> getList({Filter? filter}) async {}

  @override
  void prepareForInsert() {
    isNewRecord = true;
    bpeAgenciaModel = createNewModel();
    _resetForm();
    Get.to(() => BpeAgenciaEditPage());
  }

  void _resetForm() {
    formWasChangedDetail = false;
    cnpjController.text = '';
    nomeController.text = '';
    telefoneController.text = '';
    logradouroController.text = '';
    numeroController.text = '';
    complementoController.text = '';
    bairroController.text = '';
    codigoMunicipioController.updateValue(0);
    nomeMunicipioController.text = '';
    ufController.selected = 'AC';
    cepController.text = '';
    codigoPaisController.updateValue(0);
    nomePaisController.text = '';
    emailController.text = '';
  }

  @override
  void selectRowForEditing(PlutoRow? row) async {
    if (row == null) {
      showInfoSnackBar(message: 'message_select_one_to_edited'.tr);
      return;
    }

    selectRowForEditingByTempId(row.cells['tempId']?.value);
  }

  @override
  void selectRowForEditingById(int id) {}

  void selectRowForEditingByTempId(String tempId) {
		isNewRecord = false;
    final model = bpeAgenciaModelList.firstWhere((m) => m.tempId == tempId);
    bpeAgenciaModel = model.clone();
		bpeAgenciaModel.tempId = model.tempId;
    updateControllersFromModel();
    Get.to(() => BpeAgenciaEditPage());
  }

  void updateControllersFromModel() {
    cnpjController.text = bpeAgenciaModel.cnpj ?? '';
    nomeController.text = bpeAgenciaModel.nome ?? '';
    telefoneController.text = bpeAgenciaModel.telefone ?? '';
    logradouroController.text = bpeAgenciaModel.logradouro ?? '';
    numeroController.text = bpeAgenciaModel.numero ?? '';
    complementoController.text = bpeAgenciaModel.complemento ?? '';
    bairroController.text = bpeAgenciaModel.bairro ?? '';
    codigoMunicipioController.updateValue((bpeAgenciaModel.codigoMunicipio ?? 0).toDouble());
    nomeMunicipioController.text = bpeAgenciaModel.nomeMunicipio ?? '';
    ufController.selected = bpeAgenciaModel.uf ?? 'AC';
    cepController.text = bpeAgenciaModel.cep ?? '';
    codigoPaisController.updateValue((bpeAgenciaModel.codigoPais ?? 0).toDouble());
    nomePaisController.text = bpeAgenciaModel.nomePais ?? '';
    emailController.text = bpeAgenciaModel.email ?? '';
    formWasChangedDetail = false;
  }

  @override
  Future<void> save() async {
    if (!bpeAgenciaFormKey.currentState!.validate()) {
      showErrorSnackBar(message: 'validator_form_message'.tr);
      return;
    }

    if (formWasChangedDetail) {
      if (isNewRecord) {
        bpeAgenciaModelList.insert(0, bpeAgenciaModel.clone());
      } else {
        final index = bpeAgenciaModelList.indexWhere((m) => m.tempId == bpeAgenciaModel.tempId);
        if (index >= 0) {
          bpeAgenciaModelList[index] = bpeAgenciaModel.clone();
        }
      }

      userMadeChanges = true;
      loadData();
      Get.back(result: true);
    } else {
      Get.back();
    }
  }


  @override
  Future deleteSelected() async {
    final currentRow = plutoGridStateManager.currentRow;
    if (currentRow == null) {
      showInfoSnackBar(message: 'message_select_one_to_delete'.tr);
      return null;
    }
    showDeleteDialog(() async {
      final id = currentRow.cells['id']?.value;
      final tempId = currentRow.cells['tempId']?.value;
      bpeAgenciaModelList.removeWhere((model) => (id != 0 && model.id == id) || (id == 0 && model.tempId == tempId));
      plutoGridStateManager.removeCurrentRow();
      userMadeChanges = true;
    });
  }

  @override
  void preventDataLoss() {
    if (formWasChangedDetail) {
      showQuestionDialog('message_data_loss'.tr, () => Get.back());
    } else {
      formWasChangedDetail = false;
      Get.back();
    }
  }

  @override
  void onClose() {
    cnpjController.dispose();
    nomeController.dispose();
    telefoneController.dispose();
    logradouroController.dispose();
    numeroController.dispose();
    complementoController.dispose();
    bairroController.dispose();
    codigoMunicipioController.dispose();
    nomeMunicipioController.dispose();
    ufController.dispose();
    cepController.dispose();
    codigoPaisController.dispose();
    nomePaisController.dispose();
    emailController.dispose();
  }

}