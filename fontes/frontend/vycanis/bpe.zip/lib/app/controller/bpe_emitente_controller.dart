import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:pluto_grid/pluto_grid.dart';
import 'package:extended_masked_text/extended_masked_text.dart';
import 'package:bpe/app/page/shared_widget/input/input_imports.dart';

import 'package:bpe/app/page/page_imports.dart';
import 'package:bpe/app/page/shared_widget/message_dialog.dart';
import 'package:bpe/app/page/grid_columns/grid_columns_imports.dart';
import 'package:bpe/app/controller/controller_imports.dart';
import 'package:bpe/app/data/model/model_imports.dart';

class BpeEmitenteController extends ControllerBase<BpeEmitenteModel, void> {

  BpeEmitenteController() : super(repository: null) {
    dbColumns = BpeEmitenteModel.dbColumns;
    aliasColumns = BpeEmitenteModel.aliasColumns;
    gridColumns = bpeEmitenteGridColumns();
    functionName = "bpe_emitente";
    screenTitle = "Emitente";
  }

  final _bpeEmitenteModel = BpeEmitenteModel().obs;
  BpeEmitenteModel get bpeEmitenteModel => _bpeEmitenteModel.value;
  set bpeEmitenteModel(value) => _bpeEmitenteModel.value = value ?? BpeEmitenteModel();

  List<BpeEmitenteModel> get bpeEmitenteModelList => Get.find<BpeCabecalhoController>().currentModel.bpeEmitenteModelList ?? [];

  final _userMadeChanges = false.obs;
  get userMadeChanges => _userMadeChanges.value;
  set userMadeChanges(value) => _userMadeChanges.value = value;

  final _formWasChangedDetail = false.obs;
  bool get formWasChangedDetail => _formWasChangedDetail.value;
  set formWasChangedDetail(value) => _formWasChangedDetail.value = value;

  late PlutoGridStateManager _plutoGridStateManager;
  @override
  PlutoGridStateManager get plutoGridStateManager => _plutoGridStateManager;
  @override
  set plutoGridStateManager(value) => _plutoGridStateManager = value;

  final bpeEmitenteScaffoldKey = GlobalKey<ScaffoldState>();
  final bpeEmitenteFormKey = GlobalKey<FormState>();

  @override
  BpeEmitenteModel createNewModel() => BpeEmitenteModel();

  @override
  final standardFieldForFilter = BpeEmitenteModel.aliasColumns[BpeEmitenteModel.dbColumns.indexOf('cnpj')];

  final cnpjController = MaskedTextController(mask: '00.000.000/0000-00',);
  final ieController = TextEditingController();
  final iestController = TextEditingController();
  final imController = TextEditingController();
  final cnaeController = TextEditingController();
  final crtController = TextEditingController();
  final nomeController = TextEditingController();
  final fantasiaController = TextEditingController();
  final logradouroController = TextEditingController();
  final numeroController = TextEditingController();
  final complementoController = TextEditingController();
  final bairroController = TextEditingController();
  final codigoMunicipioController = MoneyMaskedTextController(precision: 0, decimalSeparator: '', thousandSeparator: '');
  final nomeMunicipioController = TextEditingController();
  final ufController = CustomDropdownButtonController('AC');
  final cepController = MaskedTextController(mask: '00000-000',);
  final telefoneController = TextEditingController();

  final Map<String, dynamic> mobileConfig = {
    'primaryColumns': ['cnpj'],
    'secondaryColumns': ['ie'],
  };

  List<Map<String, dynamic>> get mobileItems {
    return modelList.map((bpeEmitente) => bpeEmitente.toJson).toList();
  }

  @override
  List<PlutoRow> plutoRows() => List<PlutoRow>.from(bpeEmitenteModelList.map((model) => model.toPlutoRow()));

  @override
  Future<void> getList({Filter? filter}) async {}

  @override
  void prepareForInsert() {
    isNewRecord = true;
    bpeEmitenteModel = createNewModel();
    _resetForm();
    Get.to(() => BpeEmitenteEditPage());
  }

  void _resetForm() {
    formWasChangedDetail = false;
    cnpjController.text = '';
    ieController.text = '';
    iestController.text = '';
    imController.text = '';
    cnaeController.text = '';
    crtController.text = '';
    nomeController.text = '';
    fantasiaController.text = '';
    logradouroController.text = '';
    numeroController.text = '';
    complementoController.text = '';
    bairroController.text = '';
    codigoMunicipioController.updateValue(0);
    nomeMunicipioController.text = '';
    ufController.selected = 'AC';
    cepController.text = '';
    telefoneController.text = '';
  }

  @override
  void selectRowForEditing(PlutoRow? row) async {
    if (row == null) {
      showInfoSnackBar(message: 'message_select_one_to_edited'.tr);
      return;
    }

    selectRowForEditingByTempId(row.cells['tempId']?.value);
  }

  @override
  void selectRowForEditingById(int id) {}

  void selectRowForEditingByTempId(String tempId) {
		isNewRecord = false;
    final model = bpeEmitenteModelList.firstWhere((m) => m.tempId == tempId);
    bpeEmitenteModel = model.clone();
		bpeEmitenteModel.tempId = model.tempId;
    updateControllersFromModel();
    Get.to(() => BpeEmitenteEditPage());
  }

  void updateControllersFromModel() {
    cnpjController.text = bpeEmitenteModel.cnpj ?? '';
    ieController.text = bpeEmitenteModel.ie ?? '';
    iestController.text = bpeEmitenteModel.iest ?? '';
    imController.text = bpeEmitenteModel.im ?? '';
    cnaeController.text = bpeEmitenteModel.cnae ?? '';
    crtController.text = bpeEmitenteModel.crt ?? '';
    nomeController.text = bpeEmitenteModel.nome ?? '';
    fantasiaController.text = bpeEmitenteModel.fantasia ?? '';
    logradouroController.text = bpeEmitenteModel.logradouro ?? '';
    numeroController.text = bpeEmitenteModel.numero ?? '';
    complementoController.text = bpeEmitenteModel.complemento ?? '';
    bairroController.text = bpeEmitenteModel.bairro ?? '';
    codigoMunicipioController.updateValue((bpeEmitenteModel.codigoMunicipio ?? 0).toDouble());
    nomeMunicipioController.text = bpeEmitenteModel.nomeMunicipio ?? '';
    ufController.selected = bpeEmitenteModel.uf ?? 'AC';
    cepController.text = bpeEmitenteModel.cep ?? '';
    telefoneController.text = bpeEmitenteModel.telefone ?? '';
    formWasChangedDetail = false;
  }

  @override
  Future<void> save() async {
    if (!bpeEmitenteFormKey.currentState!.validate()) {
      showErrorSnackBar(message: 'validator_form_message'.tr);
      return;
    }

    if (formWasChangedDetail) {
      if (isNewRecord) {
        bpeEmitenteModelList.insert(0, bpeEmitenteModel.clone());
      } else {
        final index = bpeEmitenteModelList.indexWhere((m) => m.tempId == bpeEmitenteModel.tempId);
        if (index >= 0) {
          bpeEmitenteModelList[index] = bpeEmitenteModel.clone();
        }
      }

      userMadeChanges = true;
      loadData();
      Get.back(result: true);
    } else {
      Get.back();
    }
  }


  @override
  Future deleteSelected() async {
    final currentRow = plutoGridStateManager.currentRow;
    if (currentRow == null) {
      showInfoSnackBar(message: 'message_select_one_to_delete'.tr);
      return null;
    }
    showDeleteDialog(() async {
      final id = currentRow.cells['id']?.value;
      final tempId = currentRow.cells['tempId']?.value;
      bpeEmitenteModelList.removeWhere((model) => (id != 0 && model.id == id) || (id == 0 && model.tempId == tempId));
      plutoGridStateManager.removeCurrentRow();
      userMadeChanges = true;
    });
  }

  @override
  void preventDataLoss() {
    if (formWasChangedDetail) {
      showQuestionDialog('message_data_loss'.tr, () => Get.back());
    } else {
      formWasChangedDetail = false;
      Get.back();
    }
  }

  @override
  void onClose() {
    cnpjController.dispose();
    ieController.dispose();
    iestController.dispose();
    imController.dispose();
    cnaeController.dispose();
    crtController.dispose();
    nomeController.dispose();
    fantasiaController.dispose();
    logradouroController.dispose();
    numeroController.dispose();
    complementoController.dispose();
    bairroController.dispose();
    codigoMunicipioController.dispose();
    nomeMunicipioController.dispose();
    ufController.dispose();
    cepController.dispose();
    telefoneController.dispose();
  }

}