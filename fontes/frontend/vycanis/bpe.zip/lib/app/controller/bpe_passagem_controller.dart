import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:pluto_grid/pluto_grid.dart';
import 'package:bpe/app/page/shared_widget/input/input_imports.dart';

import 'package:bpe/app/page/page_imports.dart';
import 'package:bpe/app/page/shared_widget/message_dialog.dart';
import 'package:bpe/app/page/grid_columns/grid_columns_imports.dart';
import 'package:bpe/app/controller/controller_imports.dart';
import 'package:bpe/app/data/model/model_imports.dart';

class BpePassagemController extends ControllerBase<BpePassagemModel, void> {

  BpePassagemController() : super(repository: null) {
    dbColumns = BpePassagemModel.dbColumns;
    aliasColumns = BpePassagemModel.aliasColumns;
    gridColumns = bpePassagemGridColumns();
    functionName = "bpe_passagem";
    screenTitle = "Passagem";
  }

  final _bpePassagemModel = BpePassagemModel().obs;
  BpePassagemModel get bpePassagemModel => _bpePassagemModel.value;
  set bpePassagemModel(value) => _bpePassagemModel.value = value ?? BpePassagemModel();

  List<BpePassagemModel> get bpePassagemModelList => Get.find<BpeCabecalhoController>().currentModel.bpePassagemModelList ?? [];

  final _userMadeChanges = false.obs;
  get userMadeChanges => _userMadeChanges.value;
  set userMadeChanges(value) => _userMadeChanges.value = value;

  final _formWasChangedDetail = false.obs;
  bool get formWasChangedDetail => _formWasChangedDetail.value;
  set formWasChangedDetail(value) => _formWasChangedDetail.value = value;

  late PlutoGridStateManager _plutoGridStateManager;
  @override
  PlutoGridStateManager get plutoGridStateManager => _plutoGridStateManager;
  @override
  set plutoGridStateManager(value) => _plutoGridStateManager = value;

  final bpePassagemScaffoldKey = GlobalKey<ScaffoldState>();
  final bpePassagemFormKey = GlobalKey<FormState>();

  @override
  BpePassagemModel createNewModel() => BpePassagemModel();

  @override
  final standardFieldForFilter = BpePassagemModel.aliasColumns[BpePassagemModel.dbColumns.indexOf('codigo_localidade_origem')];

  final codigoLocalidadeOrigemController = TextEditingController();
  final descricaoLocalidadeOrigemController = TextEditingController();
  final codigoLocalidadeDestinoController = TextEditingController();
  final descricaoLocalidadeDestinoController = TextEditingController();
  final dataHoraEmbarqueController = DatePickerItemController(null);
  final dataHoraValidadeController = DatePickerItemController(null);

  final Map<String, dynamic> mobileConfig = {
    'primaryColumns': ['codigo_localidade_origem'],
    'secondaryColumns': ['descricao_localidade_origem'],
  };

  List<Map<String, dynamic>> get mobileItems {
    return modelList.map((bpePassagem) => bpePassagem.toJson).toList();
  }

  @override
  List<PlutoRow> plutoRows() => List<PlutoRow>.from(bpePassagemModelList.map((model) => model.toPlutoRow()));

  @override
  Future<void> getList({Filter? filter}) async {}

  @override
  void prepareForInsert() {
    isNewRecord = true;
    bpePassagemModel = createNewModel();
    _resetForm();
    Get.to(() => BpePassagemEditPage());
  }

  void _resetForm() {
    formWasChangedDetail = false;
    codigoLocalidadeOrigemController.text = '';
    descricaoLocalidadeOrigemController.text = '';
    codigoLocalidadeDestinoController.text = '';
    descricaoLocalidadeDestinoController.text = '';
    dataHoraEmbarqueController.date = null;
    dataHoraValidadeController.date = null;
  }

  @override
  void selectRowForEditing(PlutoRow? row) async {
    if (row == null) {
      showInfoSnackBar(message: 'message_select_one_to_edited'.tr);
      return;
    }

    selectRowForEditingByTempId(row.cells['tempId']?.value);
  }

  @override
  void selectRowForEditingById(int id) {}

  void selectRowForEditingByTempId(String tempId) {
		isNewRecord = false;
    final model = bpePassagemModelList.firstWhere((m) => m.tempId == tempId);
    bpePassagemModel = model.clone();
		bpePassagemModel.tempId = model.tempId;
    updateControllersFromModel();
    Get.to(() => BpePassagemEditPage());
  }

  void updateControllersFromModel() {
    codigoLocalidadeOrigemController.text = bpePassagemModel.codigoLocalidadeOrigem ?? '';
    descricaoLocalidadeOrigemController.text = bpePassagemModel.descricaoLocalidadeOrigem ?? '';
    codigoLocalidadeDestinoController.text = bpePassagemModel.codigoLocalidadeDestino ?? '';
    descricaoLocalidadeDestinoController.text = bpePassagemModel.descricaoLocalidadeDestino ?? '';
    dataHoraEmbarqueController.date = bpePassagemModel.dataHoraEmbarque;
    dataHoraValidadeController.date = bpePassagemModel.dataHoraValidade;
    formWasChangedDetail = false;
  }

  @override
  Future<void> save() async {
    if (!bpePassagemFormKey.currentState!.validate()) {
      showErrorSnackBar(message: 'validator_form_message'.tr);
      return;
    }

    if (formWasChangedDetail) {
      if (isNewRecord) {
        bpePassagemModelList.insert(0, bpePassagemModel.clone());
      } else {
        final index = bpePassagemModelList.indexWhere((m) => m.tempId == bpePassagemModel.tempId);
        if (index >= 0) {
          bpePassagemModelList[index] = bpePassagemModel.clone();
        }
      }

      userMadeChanges = true;
      loadData();
      Get.back(result: true);
    } else {
      Get.back();
    }
  }


  @override
  Future deleteSelected() async {
    final currentRow = plutoGridStateManager.currentRow;
    if (currentRow == null) {
      showInfoSnackBar(message: 'message_select_one_to_delete'.tr);
      return null;
    }
    showDeleteDialog(() async {
      final id = currentRow.cells['id']?.value;
      final tempId = currentRow.cells['tempId']?.value;
      bpePassagemModelList.removeWhere((model) => (id != 0 && model.id == id) || (id == 0 && model.tempId == tempId));
      plutoGridStateManager.removeCurrentRow();
      userMadeChanges = true;
    });
  }

  @override
  void preventDataLoss() {
    if (formWasChangedDetail) {
      showQuestionDialog('message_data_loss'.tr, () => Get.back());
    } else {
      formWasChangedDetail = false;
      Get.back();
    }
  }

  @override
  void onClose() {
    codigoLocalidadeOrigemController.dispose();
    descricaoLocalidadeOrigemController.dispose();
    codigoLocalidadeDestinoController.dispose();
    descricaoLocalidadeDestinoController.dispose();
    dataHoraEmbarqueController.dispose();
    dataHoraValidadeController.dispose();
  }

}