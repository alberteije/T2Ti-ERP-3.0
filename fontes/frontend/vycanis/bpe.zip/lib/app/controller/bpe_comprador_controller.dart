import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:pluto_grid/pluto_grid.dart';
import 'package:extended_masked_text/extended_masked_text.dart';
import 'package:bpe/app/page/shared_widget/input/input_imports.dart';

import 'package:bpe/app/page/page_imports.dart';
import 'package:bpe/app/page/shared_widget/message_dialog.dart';
import 'package:bpe/app/page/grid_columns/grid_columns_imports.dart';
import 'package:bpe/app/controller/controller_imports.dart';
import 'package:bpe/app/data/model/model_imports.dart';

class BpeCompradorController extends ControllerBase<BpeCompradorModel, void> {

  BpeCompradorController() : super(repository: null) {
    dbColumns = BpeCompradorModel.dbColumns;
    aliasColumns = BpeCompradorModel.aliasColumns;
    gridColumns = bpeCompradorGridColumns();
    functionName = "bpe_comprador";
    screenTitle = "Comprador";
  }

  final _bpeCompradorModel = BpeCompradorModel().obs;
  BpeCompradorModel get bpeCompradorModel => _bpeCompradorModel.value;
  set bpeCompradorModel(value) => _bpeCompradorModel.value = value ?? BpeCompradorModel();

  List<BpeCompradorModel> get bpeCompradorModelList => Get.find<BpeCabecalhoController>().currentModel.bpeCompradorModelList ?? [];

  final _userMadeChanges = false.obs;
  get userMadeChanges => _userMadeChanges.value;
  set userMadeChanges(value) => _userMadeChanges.value = value;

  final _formWasChangedDetail = false.obs;
  bool get formWasChangedDetail => _formWasChangedDetail.value;
  set formWasChangedDetail(value) => _formWasChangedDetail.value = value;

  late PlutoGridStateManager _plutoGridStateManager;
  @override
  PlutoGridStateManager get plutoGridStateManager => _plutoGridStateManager;
  @override
  set plutoGridStateManager(value) => _plutoGridStateManager = value;

  final bpeCompradorScaffoldKey = GlobalKey<ScaffoldState>();
  final bpeCompradorFormKey = GlobalKey<FormState>();

  @override
  BpeCompradorModel createNewModel() => BpeCompradorModel();

  @override
  final standardFieldForFilter = BpeCompradorModel.aliasColumns[BpeCompradorModel.dbColumns.indexOf('cnpj')];

  final cnpjController = MaskedTextController(mask: '00.000.000/0000-00',);
  final cpfController = MaskedTextController(mask: '000.000.000-00',);
  final ieController = TextEditingController();
  final nomeController = TextEditingController();
  final fantasiaController = TextEditingController();
  final telefoneController = TextEditingController();
  final logradouroController = TextEditingController();
  final numeroController = TextEditingController();
  final complementoController = TextEditingController();
  final bairroController = TextEditingController();
  final codigoMunicipioController = MoneyMaskedTextController(precision: 0, decimalSeparator: '', thousandSeparator: '');
  final nomeMunicipioController = TextEditingController();
  final ufController = CustomDropdownButtonController('AC');
  final cepController = MaskedTextController(mask: '00000-000',);
  final codigoPaisController = MoneyMaskedTextController(precision: 0, decimalSeparator: '', thousandSeparator: '');
  final nomePaisController = TextEditingController();
  final emailController = TextEditingController();

  final Map<String, dynamic> mobileConfig = {
    'primaryColumns': ['cnpj'],
    'secondaryColumns': ['cpf'],
  };

  List<Map<String, dynamic>> get mobileItems {
    return modelList.map((bpeComprador) => bpeComprador.toJson).toList();
  }

  @override
  List<PlutoRow> plutoRows() => List<PlutoRow>.from(bpeCompradorModelList.map((model) => model.toPlutoRow()));

  @override
  Future<void> getList({Filter? filter}) async {}

  @override
  void prepareForInsert() {
    isNewRecord = true;
    bpeCompradorModel = createNewModel();
    _resetForm();
    Get.to(() => BpeCompradorEditPage());
  }

  void _resetForm() {
    formWasChangedDetail = false;
    cnpjController.text = '';
    cpfController.text = '';
    ieController.text = '';
    nomeController.text = '';
    fantasiaController.text = '';
    telefoneController.text = '';
    logradouroController.text = '';
    numeroController.text = '';
    complementoController.text = '';
    bairroController.text = '';
    codigoMunicipioController.updateValue(0);
    nomeMunicipioController.text = '';
    ufController.selected = 'AC';
    cepController.text = '';
    codigoPaisController.updateValue(0);
    nomePaisController.text = '';
    emailController.text = '';
  }

  @override
  void selectRowForEditing(PlutoRow? row) async {
    if (row == null) {
      showInfoSnackBar(message: 'message_select_one_to_edited'.tr);
      return;
    }

    selectRowForEditingByTempId(row.cells['tempId']?.value);
  }

  @override
  void selectRowForEditingById(int id) {}

  void selectRowForEditingByTempId(String tempId) {
		isNewRecord = false;
    final model = bpeCompradorModelList.firstWhere((m) => m.tempId == tempId);
    bpeCompradorModel = model.clone();
		bpeCompradorModel.tempId = model.tempId;
    updateControllersFromModel();
    Get.to(() => BpeCompradorEditPage());
  }

  void updateControllersFromModel() {
    cnpjController.text = bpeCompradorModel.cnpj ?? '';
    cpfController.text = bpeCompradorModel.cpf ?? '';
    ieController.text = bpeCompradorModel.ie ?? '';
    nomeController.text = bpeCompradorModel.nome ?? '';
    fantasiaController.text = bpeCompradorModel.fantasia ?? '';
    telefoneController.text = bpeCompradorModel.telefone ?? '';
    logradouroController.text = bpeCompradorModel.logradouro ?? '';
    numeroController.text = bpeCompradorModel.numero ?? '';
    complementoController.text = bpeCompradorModel.complemento ?? '';
    bairroController.text = bpeCompradorModel.bairro ?? '';
    codigoMunicipioController.updateValue((bpeCompradorModel.codigoMunicipio ?? 0).toDouble());
    nomeMunicipioController.text = bpeCompradorModel.nomeMunicipio ?? '';
    ufController.selected = bpeCompradorModel.uf ?? 'AC';
    cepController.text = bpeCompradorModel.cep ?? '';
    codigoPaisController.updateValue((bpeCompradorModel.codigoPais ?? 0).toDouble());
    nomePaisController.text = bpeCompradorModel.nomePais ?? '';
    emailController.text = bpeCompradorModel.email ?? '';
    formWasChangedDetail = false;
  }

  @override
  Future<void> save() async {
    if (!bpeCompradorFormKey.currentState!.validate()) {
      showErrorSnackBar(message: 'validator_form_message'.tr);
      return;
    }

    if (formWasChangedDetail) {
      if (isNewRecord) {
        bpeCompradorModelList.insert(0, bpeCompradorModel.clone());
      } else {
        final index = bpeCompradorModelList.indexWhere((m) => m.tempId == bpeCompradorModel.tempId);
        if (index >= 0) {
          bpeCompradorModelList[index] = bpeCompradorModel.clone();
        }
      }

      userMadeChanges = true;
      loadData();
      Get.back(result: true);
    } else {
      Get.back();
    }
  }


  @override
  Future deleteSelected() async {
    final currentRow = plutoGridStateManager.currentRow;
    if (currentRow == null) {
      showInfoSnackBar(message: 'message_select_one_to_delete'.tr);
      return null;
    }
    showDeleteDialog(() async {
      final id = currentRow.cells['id']?.value;
      final tempId = currentRow.cells['tempId']?.value;
      bpeCompradorModelList.removeWhere((model) => (id != 0 && model.id == id) || (id == 0 && model.tempId == tempId));
      plutoGridStateManager.removeCurrentRow();
      userMadeChanges = true;
    });
  }

  @override
  void preventDataLoss() {
    if (formWasChangedDetail) {
      showQuestionDialog('message_data_loss'.tr, () => Get.back());
    } else {
      formWasChangedDetail = false;
      Get.back();
    }
  }

  @override
  void onClose() {
    cnpjController.dispose();
    cpfController.dispose();
    ieController.dispose();
    nomeController.dispose();
    fantasiaController.dispose();
    telefoneController.dispose();
    logradouroController.dispose();
    numeroController.dispose();
    complementoController.dispose();
    bairroController.dispose();
    codigoMunicipioController.dispose();
    nomeMunicipioController.dispose();
    ufController.dispose();
    cepController.dispose();
    codigoPaisController.dispose();
    nomePaisController.dispose();
    emailController.dispose();
  }

}