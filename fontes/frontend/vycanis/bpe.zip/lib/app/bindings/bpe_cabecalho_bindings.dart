import 'package:get/get.dart';
import 'package:bpe/app/controller/bpe_cabecalho_controller.dart';
import 'package:bpe/app/data/provider/api/bpe_cabecalho_api_provider.dart';
import 'package:bpe/app/data/provider/drift/bpe_cabecalho_drift_provider.dart';
import 'package:bpe/app/data/repository/bpe_cabecalho_repository.dart';

class BpeCabecalhoBindings implements Binding {
	@override
	List<Bind> dependencies() {
		return [
			Bind.lazyPut<BpeCabecalhoController>(() => BpeCabecalhoController(
					repository: BpeCabecalhoRepository(bpeCabecalhoApiProvider: BpeCabecalhoApiProvider(), bpeCabecalhoDriftProvider: BpeCabecalhoDriftProvider()))),
		];
	}
}
