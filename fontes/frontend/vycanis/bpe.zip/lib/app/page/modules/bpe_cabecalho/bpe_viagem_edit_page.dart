import 'package:flutter/material.dart';
import 'package:flutter_bootstrap/flutter_bootstrap.dart';
import 'package:get/get.dart';
import 'package:bpe/app/page/shared_widget/shared_widget_imports.dart';
import 'package:bpe/app/data/domain/domain_imports.dart';
import 'package:bpe/app/controller/bpe_viagem_controller.dart';
import 'package:bpe/app/infra/infra_imports.dart';
import 'package:bpe/app/page/shared_widget/input/input_imports.dart';

class BpeViagemEditPage extends StatelessWidget {
	BpeViagemEditPage({Key? key}) : super(key: key);
	final bpeViagemController = Get.find<BpeViagemController>();

	@override
	Widget build(BuildContext context) {
			return Scaffold(
				key: bpeViagemController.bpeViagemScaffoldKey,	
				appBar: AppBar(
					automaticallyImplyLeading: false,
					title: Text('${ bpeViagemController.screenTitle } - ${ bpeViagemController.isNewRecord ? 'inserting'.tr : 'editing'.tr }',),
					actions: [
						saveButton(onPressed: bpeViagemController.save),
						cancelAndExitButton(onPressed: bpeViagemController.preventDataLoss),
					]
				),
				body: SafeArea(
					top: false,
					bottom: false,
					child: Form(
						key: bpeViagemController.bpeViagemFormKey,
						autovalidateMode: AutovalidateMode.always,
						child: Scrollbar(
							controller: bpeViagemController.scrollController,
							child: SingleChildScrollView(
								controller: bpeViagemController.scrollController,
								child: BootstrapContainer(
									fluid: true,
									padding: const EdgeInsets.all(10.0),
									children: <Widget>[
										const Divider(
											color: Colors.transparent,
										),
										BootstrapRow(
											height: 60,
											children: <BootstrapCol>[
												BootstrapCol(
													sizes: 'col-12 col-md-3',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: TextFormField(
															autofocus: true,
															maxLength: 20,
															controller: bpeViagemController.codigoPercursoController,
															decoration: inputDecoration(
																hintText: 'Informe os dados para o campo Codigo Percurso',
																labelText: 'Codigo Percurso',
																usePadding: true,
															),
															onSaved: (String? value) {},
															onChanged: (text) {
																bpeViagemController.bpeViagemModel.codigoPercurso = text;
																bpeViagemController.formWasChangedDetail = true;
															},
														),
													),
												),
												BootstrapCol(
													sizes: 'col-12 col-md-9',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: TextFormField(
															autofocus: true,
															maxLength: 100,
															controller: bpeViagemController.descricaoPercursoController,
															decoration: inputDecoration(
																hintText: 'Informe os dados para o campo Descricao Percurso',
																labelText: 'Descricao Percurso',
																usePadding: true,
															),
															onSaved: (String? value) {},
															onChanged: (text) {
																bpeViagemController.bpeViagemModel.descricaoPercurso = text;
																bpeViagemController.formWasChangedDetail = true;
															},
														),
													),
												),
											],
										),
										const Divider(
											color: Colors.transparent,
										),
										BootstrapRow(
											height: 60,
											children: <BootstrapCol>[
												BootstrapCol(
													sizes: 'col-12 col-md-4',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: CustomDropdownButton(
															controller: bpeViagemController.tipoViagemController,
															labelText: 'Tipo Viagem',
															hintText: 'Informe os dados para o campo Tipo Viagem',
															items: BpeViagemDomain.tipoViagemListDropdown,
															onChanged: (dynamic newValue) {
																bpeViagemController.bpeViagemModel.tipoViagem = newValue;
																bpeViagemController.formWasChangedDetail = true;
															},
														),
													),
												),
												BootstrapCol(
													sizes: 'col-12 col-md-4',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: CustomDropdownButton(
															controller: bpeViagemController.tipoServicoController,
															labelText: 'Tipo Servico',
															hintText: 'Informe os dados para o campo Tipo Servico',
															items: BpeViagemDomain.tipoServicoListDropdown,
															onChanged: (dynamic newValue) {
																bpeViagemController.bpeViagemModel.tipoServico = newValue;
																bpeViagemController.formWasChangedDetail = true;
															},
														),
													),
												),
												BootstrapCol(
													sizes: 'col-12 col-md-4',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: CustomDropdownButton(
															controller: bpeViagemController.tipoAcomodacaoController,
															labelText: 'Tipo Acomodacao',
															hintText: 'Informe os dados para o campo Tipo Acomodacao',
															items: BpeViagemDomain.tipoAcomodacaoListDropdown,
															onChanged: (dynamic newValue) {
																bpeViagemController.bpeViagemModel.tipoAcomodacao = newValue;
																bpeViagemController.formWasChangedDetail = true;
															},
														),
													),
												),
											],
										),
										const Divider(
											color: Colors.transparent,
										),
										BootstrapRow(
											height: 60,
											children: <BootstrapCol>[
												BootstrapCol(
													sizes: 'col-12 col-md-4',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: CustomDropdownButton(
															controller: bpeViagemController.tipoTrechoController,
															labelText: 'Tipo Trecho',
															hintText: 'Informe os dados para o campo Tipo Trecho',
															items: BpeViagemDomain.tipoTrechoListDropdown,
															onChanged: (dynamic newValue) {
																bpeViagemController.bpeViagemModel.tipoTrecho = newValue;
																bpeViagemController.formWasChangedDetail = true;
															},
														),
													),
												),
												BootstrapCol(
													sizes: 'col-12 col-md-4',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: InputDecorator(
															decoration: inputDecoration(
																hintText: 'Informe os dados para o campo Data Hora Viagem',
																labelText: 'Data Hora Viagem',
																usePadding: true,
															),
															isEmpty: false,
															child: DatePickerItem(
																controller: bpeViagemController.dataHoraViagemController,
																firstDate: DateTime.parse('1000-01-01'),
																lastDate: DateTime.parse('5000-01-01'),
																onChanged: (DateTime? value) {
																	bpeViagemController.bpeViagemModel.dataHoraViagem = value;
																	bpeViagemController.formWasChangedDetail = true;
																},
															),
														),
													),
												),
												BootstrapCol(
													sizes: 'col-12 col-md-4',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: InputDecorator(
															decoration: inputDecoration(
																hintText: 'Informe os dados para o campo Data Hora Conexao',
																labelText: 'Data Hora Conexao',
																usePadding: true,
															),
															isEmpty: false,
															child: DatePickerItem(
																controller: bpeViagemController.dataHoraConexaoController,
																firstDate: DateTime.parse('1000-01-01'),
																lastDate: DateTime.parse('5000-01-01'),
																onChanged: (DateTime? value) {
																	bpeViagemController.bpeViagemModel.dataHoraConexao = value;
																	bpeViagemController.formWasChangedDetail = true;
																},
															),
														),
													),
												),
											],
										),
										const Divider(
											color: Colors.transparent,
										),
										BootstrapRow(
											height: 60,
											children: <BootstrapCol>[
												BootstrapCol(
													sizes: 'col-12 col-md-4',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: TextFormField(
															autofocus: true,
															maxLength: 20,
															controller: bpeViagemController.prefixoLinhaController,
															decoration: inputDecoration(
																hintText: 'Informe os dados para o campo Prefixo Linha',
																labelText: 'Prefixo Linha',
																usePadding: true,
															),
															onSaved: (String? value) {},
															onChanged: (text) {
																bpeViagemController.bpeViagemModel.prefixoLinha = text;
																bpeViagemController.formWasChangedDetail = true;
															},
														),
													),
												),
												BootstrapCol(
													sizes: 'col-12 col-md-4',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: TextFormField(
															autofocus: true,
															maxLength: 3,
															controller: bpeViagemController.poltronaController,
															decoration: inputDecoration(
																hintText: 'Informe os dados para o campo Poltrona',
																labelText: 'Poltrona',
																usePadding: true,
															),
															onSaved: (String? value) {},
															onChanged: (text) {
																bpeViagemController.bpeViagemModel.poltrona = text;
																bpeViagemController.formWasChangedDetail = true;
															},
														),
													),
												),
												BootstrapCol(
													sizes: 'col-12 col-md-4',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: TextFormField(
															autofocus: true,
															maxLength: 10,
															controller: bpeViagemController.plataformaController,
															decoration: inputDecoration(
																hintText: 'Informe os dados para o campo Plataforma',
																labelText: 'Plataforma',
																usePadding: true,
															),
															onSaved: (String? value) {},
															onChanged: (text) {
																bpeViagemController.bpeViagemModel.plataforma = text;
																bpeViagemController.formWasChangedDetail = true;
															},
														),
													),
												),
											],
										),
										const Divider(
											indent: 10,
											endIndent: 10,
											thickness: 2,
										),
										BootstrapRow(
											height: 60,
											children: <BootstrapCol>[
												BootstrapCol(
													sizes: 'col-12',
													child: Text(
														'field_is_mandatory'.tr,
														style: Theme.of(context).textTheme.bodySmall,
													),
												),
											],
										),
										const SizedBox(height: 10.0),
									],
								),
							),
						),
					),
				),
			);
	}
}
