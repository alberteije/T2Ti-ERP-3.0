import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:buttons_tabbar/buttons_tabbar.dart';
import 'package:get/get.dart';
import 'package:bpe/app/controller/bpe_cabecalho_controller.dart';
import 'package:bpe/app/page/shared_widget/shared_widget_imports.dart';

class BpeCabecalhoTabPage extends StatelessWidget {
  BpeCabecalhoTabPage({Key? key}) : super(key: key);
  final bpeCabecalhoController = Get.find<BpeCabecalhoController>();

  @override
  Widget build(BuildContext context) {
		return KeyboardListener(
			autofocus: false,
			focusNode: FocusNode(),
			onKeyEvent: (event) {
				if (event.logicalKey == LogicalKeyboardKey.escape) {
          bpeCabecalhoController.preventDataLoss();
        }
      },
      child: Scaffold(
        key: bpeCabecalhoController.bpeCabecalhoTabPageScaffoldKey,
        appBar: AppBar(
					automaticallyImplyLeading: false, 
					title: Text('${ bpeCabecalhoController.screenTitle } - ${ bpeCabecalhoController.isNewRecord ? 'inserting'.tr : 'editing'.tr }',),
					actions: [
            IconButton(
              tooltip: 'Transmitir Bpe',
              icon: const Icon(Icons.cloud_upload, color: Colors.greenAccent),
              color: Colors.yellow,
              onPressed: bpeCabecalhoController.transmitirBpe,
            ),
						saveButton(onPressed: bpeCabecalhoController.save),
						cancelAndExitButton(onPressed: bpeCabecalhoController.preventDataLoss),
					]
				),
        body: SafeArea(
          child: Column(
            children: <Widget>[
              Expanded(
                child: TabBarView(
                  controller: bpeCabecalhoController.tabController,
                  children: bpeCabecalhoController.tabPages(),
                ),
              ),
              ButtonsTabBar(
                controller: bpeCabecalhoController.tabController,
                onTap: bpeCabecalhoController.tabChange,
                height: 40,
                elevation: 2,
                borderWidth: 0,
                backgroundColor: Colors.blueGrey,
                unselectedBackgroundColor: Colors.grey[300],
                unselectedLabelStyle: const TextStyle(color: Colors.black),
                labelStyle: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold),
                tabs: bpeCabecalhoController.tabItems,
              ),
              const SizedBox(
                height: 10,
              ),
            ],
          ),
        ),
      ),
    );
  }
}
