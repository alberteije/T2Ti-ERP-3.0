import 'package:flutter/material.dart';
import 'package:flutter_bootstrap/flutter_bootstrap.dart';
import 'package:get/get.dart';
import 'package:bpe/app/page/shared_widget/shared_widget_imports.dart';
import 'package:bpe/app/controller/bpe_passagem_controller.dart';
import 'package:bpe/app/infra/infra_imports.dart';
import 'package:bpe/app/page/shared_widget/input/input_imports.dart';

class BpePassagemEditPage extends StatelessWidget {
	BpePassagemEditPage({Key? key}) : super(key: key);
	final bpePassagemController = Get.find<BpePassagemController>();

	@override
	Widget build(BuildContext context) {
			return Scaffold(
				key: bpePassagemController.bpePassagemScaffoldKey,	
				appBar: AppBar(
					automaticallyImplyLeading: false,
					title: Text('${ bpePassagemController.screenTitle } - ${ bpePassagemController.isNewRecord ? 'inserting'.tr : 'editing'.tr }',),
					actions: [
						saveButton(onPressed: bpePassagemController.save),
						cancelAndExitButton(onPressed: bpePassagemController.preventDataLoss),
					]
				),
				body: SafeArea(
					top: false,
					bottom: false,
					child: Form(
						key: bpePassagemController.bpePassagemFormKey,
						autovalidateMode: AutovalidateMode.always,
						child: Scrollbar(
							controller: bpePassagemController.scrollController,
							child: SingleChildScrollView(
								controller: bpePassagemController.scrollController,
								child: BootstrapContainer(
									fluid: true,
									padding: const EdgeInsets.all(10.0),
									children: <Widget>[
										const Divider(
											color: Colors.transparent,
										),
										BootstrapRow(
											height: 60,
											children: <BootstrapCol>[
												BootstrapCol(
													sizes: 'col-12 col-md-3',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: TextFormField(
															autofocus: true,
															maxLength: 7,
															controller: bpePassagemController.codigoLocalidadeOrigemController,
															decoration: inputDecoration(
																hintText: 'Informe os dados para o campo Codigo Localidade Origem',
																labelText: 'Codigo Localidade Origem',
																usePadding: true,
															),
															onSaved: (String? value) {},
															onChanged: (text) {
																bpePassagemController.bpePassagemModel.codigoLocalidadeOrigem = text;
																bpePassagemController.formWasChangedDetail = true;
															},
														),
													),
												),
												BootstrapCol(
													sizes: 'col-12 col-md-9',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: TextFormField(
															autofocus: true,
															maxLength: 60,
															controller: bpePassagemController.descricaoLocalidadeOrigemController,
															decoration: inputDecoration(
																hintText: 'Informe os dados para o campo Descricao Localidade Origem',
																labelText: 'Descricao Localidade Origem',
																usePadding: true,
															),
															onSaved: (String? value) {},
															onChanged: (text) {
																bpePassagemController.bpePassagemModel.descricaoLocalidadeOrigem = text;
																bpePassagemController.formWasChangedDetail = true;
															},
														),
													),
												),
											],
										),
										const Divider(
											color: Colors.transparent,
										),
										BootstrapRow(
											height: 60,
											children: <BootstrapCol>[
												BootstrapCol(
													sizes: 'col-12 col-md-3',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: TextFormField(
															autofocus: true,
															maxLength: 7,
															controller: bpePassagemController.codigoLocalidadeDestinoController,
															decoration: inputDecoration(
																hintText: 'Informe os dados para o campo Codigo Localidade Destino',
																labelText: 'Codigo Localidade Destino',
																usePadding: true,
															),
															onSaved: (String? value) {},
															onChanged: (text) {
																bpePassagemController.bpePassagemModel.codigoLocalidadeDestino = text;
																bpePassagemController.formWasChangedDetail = true;
															},
														),
													),
												),
												BootstrapCol(
													sizes: 'col-12 col-md-9',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: TextFormField(
															autofocus: true,
															maxLength: 60,
															controller: bpePassagemController.descricaoLocalidadeDestinoController,
															decoration: inputDecoration(
																hintText: 'Informe os dados para o campo Descricao Localidade Destino',
																labelText: 'Descricao Localidade Destino',
																usePadding: true,
															),
															onSaved: (String? value) {},
															onChanged: (text) {
																bpePassagemController.bpePassagemModel.descricaoLocalidadeDestino = text;
																bpePassagemController.formWasChangedDetail = true;
															},
														),
													),
												),
											],
										),
										const Divider(
											color: Colors.transparent,
										),
										BootstrapRow(
											height: 60,
											children: <BootstrapCol>[
												BootstrapCol(
													sizes: 'col-12 col-md-6',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: InputDecorator(
															decoration: inputDecoration(
																hintText: 'Informe os dados para o campo Data Hora Embarque',
																labelText: 'Data Hora Embarque',
																usePadding: true,
															),
															isEmpty: false,
															child: DatePickerItem(
																controller: bpePassagemController.dataHoraEmbarqueController,
																firstDate: DateTime.parse('1000-01-01'),
																lastDate: DateTime.parse('5000-01-01'),
																onChanged: (DateTime? value) {
																	bpePassagemController.bpePassagemModel.dataHoraEmbarque = value;
																	bpePassagemController.formWasChangedDetail = true;
																},
															),
														),
													),
												),
												BootstrapCol(
													sizes: 'col-12 col-md-6',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: InputDecorator(
															decoration: inputDecoration(
																hintText: 'Informe os dados para o campo Data Hora Validade',
																labelText: 'Data Hora Validade',
																usePadding: true,
															),
															isEmpty: false,
															child: DatePickerItem(
																controller: bpePassagemController.dataHoraValidadeController,
																firstDate: DateTime.parse('1000-01-01'),
																lastDate: DateTime.parse('5000-01-01'),
																onChanged: (DateTime? value) {
																	bpePassagemController.bpePassagemModel.dataHoraValidade = value;
																	bpePassagemController.formWasChangedDetail = true;
																},
															),
														),
													),
												),
											],
										),
										const Divider(
											indent: 10,
											endIndent: 10,
											thickness: 2,
										),
										BootstrapRow(
											height: 60,
											children: <BootstrapCol>[
												BootstrapCol(
													sizes: 'col-12',
													child: Text(
														'field_is_mandatory'.tr,
														style: Theme.of(context).textTheme.bodySmall,
													),
												),
											],
										),
										const SizedBox(height: 10.0),
									],
								),
							),
						),
					),
				),
			);
	}
}
