import 'package:flutter/material.dart';
import 'package:flutter_bootstrap/flutter_bootstrap.dart';
import 'package:get/get.dart';
import 'package:bpe/app/page/shared_widget/shared_widget_imports.dart';
import 'package:bpe/app/data/domain/domain_imports.dart';
import 'package:bpe/app/controller/bpe_passageiro_controller.dart';
import 'package:bpe/app/infra/infra_imports.dart';
import 'package:bpe/app/page/shared_widget/input/input_imports.dart';

class BpePassageiroEditPage extends StatelessWidget {
	BpePassageiroEditPage({Key? key}) : super(key: key);
	final bpePassageiroController = Get.find<BpePassageiroController>();

	@override
	Widget build(BuildContext context) {
			return Scaffold(
				key: bpePassageiroController.bpePassageiroScaffoldKey,	
				appBar: AppBar(
					automaticallyImplyLeading: false,
					title: Text('${ bpePassageiroController.screenTitle } - ${ bpePassageiroController.isNewRecord ? 'inserting'.tr : 'editing'.tr }',),
					actions: [
						saveButton(onPressed: bpePassageiroController.save),
						cancelAndExitButton(onPressed: bpePassageiroController.preventDataLoss),
					]
				),
				body: SafeArea(
					top: false,
					bottom: false,
					child: Form(
						key: bpePassageiroController.bpePassageiroFormKey,
						autovalidateMode: AutovalidateMode.always,
						child: Scrollbar(
							controller: bpePassageiroController.scrollController,
							child: SingleChildScrollView(
								controller: bpePassageiroController.scrollController,
								child: BootstrapContainer(
									fluid: true,
									padding: const EdgeInsets.all(10.0),
									children: <Widget>[
										const Divider(
											color: Colors.transparent,
										),
										BootstrapRow(
											height: 60,
											children: <BootstrapCol>[
												BootstrapCol(
													sizes: 'col-12',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: TextFormField(
															autofocus: true,
															maxLength: 60,
															controller: bpePassageiroController.nomeController,
															decoration: inputDecoration(
																hintText: 'Informe os dados para o campo Nome',
																labelText: 'Nome',
																usePadding: true,
															),
															onSaved: (String? value) {},
															onChanged: (text) {
																bpePassageiroController.bpePassageiroModel.nome = text;
																bpePassageiroController.formWasChangedDetail = true;
															},
														),
													),
												),
											],
										),
										const Divider(
											color: Colors.transparent,
										),
										BootstrapRow(
											height: 60,
											children: <BootstrapCol>[
												BootstrapCol(
													sizes: 'col-12 col-md-4',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: TextFormField(
															autofocus: true,
															controller: bpePassageiroController.cpfController,
															decoration: inputDecoration(
																hintText: 'Informe os dados para o campo Cpf',
																labelText: 'Cpf',
																usePadding: true,
															),
															onSaved: (String? value) {},
															onChanged: (text) {
																bpePassageiroController.bpePassageiroModel.cpf = text;
																bpePassageiroController.formWasChangedDetail = true;
															},
														),
													),
												),
												BootstrapCol(
													sizes: 'col-12 col-md-4',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: CustomDropdownButton(
															controller: bpePassageiroController.tipoDocumentoIdentificacaoController,
															labelText: 'Tipo Documento Identificacao',
															hintText: 'Informe os dados para o campo Tipo Documento Identificacao',
															items: BpePassageiroDomain.tipoDocumentoIdentificacaoListDropdown,
															onChanged: (dynamic newValue) {
																bpePassageiroController.bpePassageiroModel.tipoDocumentoIdentificacao = newValue;
																bpePassageiroController.formWasChangedDetail = true;
															},
														),
													),
												),
												BootstrapCol(
													sizes: 'col-12 col-md-4',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: TextFormField(
															autofocus: true,
															maxLength: 20,
															controller: bpePassageiroController.numeroDocumentoController,
															decoration: inputDecoration(
																hintText: 'Informe os dados para o campo Numero Documento',
																labelText: 'Numero Documento',
																usePadding: true,
															),
															onSaved: (String? value) {},
															onChanged: (text) {
																bpePassageiroController.bpePassageiroModel.numeroDocumento = text;
																bpePassageiroController.formWasChangedDetail = true;
															},
														),
													),
												),
											],
										),
										const Divider(
											color: Colors.transparent,
										),
										BootstrapRow(
											height: 60,
											children: <BootstrapCol>[
												BootstrapCol(
													sizes: 'col-12',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: TextFormField(
															autofocus: true,
															maxLength: 100,
															controller: bpePassageiroController.documentoOutrosDescricaoController,
															decoration: inputDecoration(
																hintText: 'Informe os dados para o campo Documento Outros Descricao',
																labelText: 'Documento Outros Descricao',
																usePadding: true,
															),
															onSaved: (String? value) {},
															onChanged: (text) {
																bpePassageiroController.bpePassageiroModel.documentoOutrosDescricao = text;
																bpePassageiroController.formWasChangedDetail = true;
															},
														),
													),
												),
											],
										),
										const Divider(
											color: Colors.transparent,
										),
										BootstrapRow(
											height: 60,
											children: <BootstrapCol>[
												BootstrapCol(
													sizes: 'col-12 col-md-6',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: InputDecorator(
															decoration: inputDecoration(
																hintText: 'Informe os dados para o campo Data Nascimento',
																labelText: 'Data Nascimento',
																usePadding: true,
															),
															isEmpty: false,
															child: DatePickerItem(
																controller: bpePassageiroController.dataNascimentoController,
																firstDate: DateTime.parse('1000-01-01'),
																lastDate: DateTime.parse('5000-01-01'),
																onChanged: (DateTime? value) {
																	bpePassageiroController.bpePassageiroModel.dataNascimento = value;
																	bpePassageiroController.formWasChangedDetail = true;
																},
															),
														),
													),
												),
												BootstrapCol(
													sizes: 'col-12 col-md-6',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: TextFormField(
															autofocus: true,
															maxLength: 12,
															controller: bpePassageiroController.telefoneController,
															decoration: inputDecoration(
																hintText: 'Informe os dados para o campo Telefone',
																labelText: 'Telefone',
																usePadding: true,
															),
															onSaved: (String? value) {},
															onChanged: (text) {
																bpePassageiroController.bpePassageiroModel.telefone = text;
																bpePassageiroController.formWasChangedDetail = true;
															},
														),
													),
												),
											],
										),
										const Divider(
											color: Colors.transparent,
										),
										BootstrapRow(
											height: 60,
											children: <BootstrapCol>[
												BootstrapCol(
													sizes: 'col-12',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: TextFormField(
															autofocus: true,
															validator: ValidateFormField.validateEmail,
															maxLength: 60,
															controller: bpePassageiroController.emailController,
															decoration: inputDecoration(
																hintText: 'Informe os dados para o campo Email',
																labelText: 'Email',
																usePadding: true,
															),
															onSaved: (String? value) {},
															onChanged: (text) {
																bpePassageiroController.bpePassageiroModel.email = text;
																bpePassageiroController.formWasChangedDetail = true;
															},
														),
													),
												),
											],
										),
										const Divider(
											indent: 10,
											endIndent: 10,
											thickness: 2,
										),
										BootstrapRow(
											height: 60,
											children: <BootstrapCol>[
												BootstrapCol(
													sizes: 'col-12',
													child: Text(
														'field_is_mandatory'.tr,
														style: Theme.of(context).textTheme.bodySmall,
													),
												),
											],
										),
										const SizedBox(height: 10.0),
									],
								),
							),
						),
					),
				),
			);
	}
}
