import 'package:flutter/material.dart';
import 'package:flutter_bootstrap/flutter_bootstrap.dart';
import 'package:get/get.dart';
import 'package:bpe/app/data/domain/domain_imports.dart';
import 'package:bpe/app/controller/bpe_cabecalho_controller.dart';
import 'package:bpe/app/infra/infra_imports.dart';
import 'package:bpe/app/page/shared_widget/input/input_imports.dart';

class BpeCabecalhoEditPage extends StatelessWidget {
	BpeCabecalhoEditPage({Key? key}) : super(key: key);
	final bpeCabecalhoController = Get.find<BpeCabecalhoController>();

	@override
	Widget build(BuildContext context) {
			return Scaffold(
				key: bpeCabecalhoController.bpeCabecalhoScaffoldKey,
				body: SafeArea(
					top: false,
					bottom: false,
					child: Form(
						key: bpeCabecalhoController.bpeCabecalhoFormKey,
						autovalidateMode: AutovalidateMode.always,
						child: Scrollbar(
							controller: bpeCabecalhoController.scrollController,
							child: SingleChildScrollView(
								controller: bpeCabecalhoController.scrollController,
								child: BootstrapContainer(
									fluid: true,
									padding: const EdgeInsets.all(10),
									children: <Widget>[
										const Divider(
											color: Colors.transparent,
										),
										BootstrapRow(
											height: 60,
											children: <BootstrapCol>[
												BootstrapCol(
													sizes: 'col-12 col-md-3',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: TextFormField(
															autofocus: true,
															maxLength: 2,
															controller: bpeCabecalhoController.ufEmitenteController,
															decoration: inputDecoration(
																hintText: 'Informe os dados para o campo Uf Emitente',
																labelText: 'Uf Emitente',
																usePadding: true,
															),
															onSaved: (String? value) {},
															onChanged: (text) {
																bpeCabecalhoController.currentModel.ufEmitente = text;
																bpeCabecalhoController.formWasChanged = true;
															},
														),
													),
												),
												BootstrapCol(
													sizes: 'col-12 col-md-3',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: CustomDropdownButton(
															controller: bpeCabecalhoController.ambienteController,
															labelText: 'Ambiente',
															hintText: 'Informe os dados para o campo Ambiente',
															items: BpeCabecalhoDomain.ambienteListDropdown,
															onChanged: (dynamic newValue) {
																bpeCabecalhoController.currentModel.ambiente = newValue;
																bpeCabecalhoController.formWasChanged = true;
															},
														),
													),
												),
												BootstrapCol(
													sizes: 'col-12 col-md-3',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: CustomDropdownButton(
															controller: bpeCabecalhoController.modeloController,
															labelText: 'Modelo',
															hintText: 'Informe os dados para o campo Modelo',
															items: BpeCabecalhoDomain.modeloListDropdown,
															onChanged: (dynamic newValue) {
																bpeCabecalhoController.currentModel.modelo = newValue;
																bpeCabecalhoController.formWasChanged = true;
															},
														),
													),
												),
												BootstrapCol(
													sizes: 'col-12 col-md-3',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: TextFormField(
															autofocus: true,
															maxLength: 3,
															controller: bpeCabecalhoController.serieController,
															decoration: inputDecoration(
																hintText: 'Informe os dados para o campo Serie',
																labelText: 'Serie',
																usePadding: true,
															),
															onSaved: (String? value) {},
															onChanged: (text) {
																bpeCabecalhoController.currentModel.serie = text;
																bpeCabecalhoController.formWasChanged = true;
															},
														),
													),
												),
											],
										),
										const Divider(
											color: Colors.transparent,
										),
										BootstrapRow(
											height: 60,
											children: <BootstrapCol>[
												BootstrapCol(
													sizes: 'col-12 col-md-3',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: TextFormField(
															autofocus: true,
															maxLength: 9,
															controller: bpeCabecalhoController.numeroController,
															decoration: inputDecoration(
																hintText: 'Informe os dados para o campo Numero',
																labelText: 'Numero',
																usePadding: true,
															),
															onSaved: (String? value) {},
															onChanged: (text) {
																bpeCabecalhoController.currentModel.numero = text;
																bpeCabecalhoController.formWasChanged = true;
															},
														),
													),
												),
												BootstrapCol(
													sizes: 'col-12 col-md-3',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: TextFormField(
															autofocus: true,
															maxLength: 8,
															controller: bpeCabecalhoController.codigoNumericoController,
															decoration: inputDecoration(
																hintText: 'Informe os dados para o campo Codigo Numerico',
																labelText: 'Codigo Numerico',
																usePadding: true,
															),
															onSaved: (String? value) {},
															onChanged: (text) {
																bpeCabecalhoController.currentModel.codigoNumerico = text;
																bpeCabecalhoController.formWasChanged = true;
															},
														),
													),
												),
												BootstrapCol(
													sizes: 'col-12 col-md-5',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: TextFormField(
															autofocus: true,
															maxLength: 44,
															controller: bpeCabecalhoController.chaveAcessoController,
															decoration: inputDecoration(
																hintText: 'Informe os dados para o campo Chave Acesso',
																labelText: 'Chave Acesso',
																usePadding: true,
															),
															onSaved: (String? value) {},
															onChanged: (text) {
																bpeCabecalhoController.currentModel.chaveAcesso = text;
																bpeCabecalhoController.formWasChanged = true;
															},
														),
													),
												),
												BootstrapCol(
													sizes: 'col-12 col-md-1',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: TextFormField(
															autofocus: true,
															maxLength: 1,
															controller: bpeCabecalhoController.digitoChaveAcessoController,
															decoration: inputDecoration(
																hintText: 'Informe os dados para o campo Digito Chave Acesso',
																labelText: 'Digito Chave Acesso',
																usePadding: true,
															),
															onSaved: (String? value) {},
															onChanged: (text) {
																bpeCabecalhoController.currentModel.digitoChaveAcesso = text;
																bpeCabecalhoController.formWasChanged = true;
															},
														),
													),
												),
											],
										),
										const Divider(
											color: Colors.transparent,
										),
										BootstrapRow(
											height: 60,
											children: <BootstrapCol>[
												BootstrapCol(
													sizes: 'col-12 col-md-3',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: CustomDropdownButton(
															controller: bpeCabecalhoController.modalController,
															labelText: 'Modal',
															hintText: 'Informe os dados para o campo Modal',
															items: BpeCabecalhoDomain.modalListDropdown,
															onChanged: (dynamic newValue) {
																bpeCabecalhoController.currentModel.modal = newValue;
																bpeCabecalhoController.formWasChanged = true;
															},
														),
													),
												),
												BootstrapCol(
													sizes: 'col-12 col-md-3',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: InputDecorator(
															decoration: inputDecoration(
																hintText: 'Informe os dados para o campo Data Hora Emissao',
																labelText: 'Data Hora Emissao',
																usePadding: true,
															),
															isEmpty: false,
															child: DatePickerItem(
																controller: bpeCabecalhoController.dataHoraEmissaoController,
																firstDate: DateTime.parse('1000-01-01'),
																lastDate: DateTime.parse('5000-01-01'),
																onChanged: (DateTime? value) {
																	bpeCabecalhoController.currentModel.dataHoraEmissao = value;
																	bpeCabecalhoController.formWasChanged = true;
																},
															),
														),
													),
												),
												BootstrapCol(
													sizes: 'col-12 col-md-3',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: CustomDropdownButton(
															controller: bpeCabecalhoController.tipoEmissaoController,
															labelText: 'Tipo Emissao',
															hintText: 'Informe os dados para o campo Tipo Emissao',
															items: BpeCabecalhoDomain.tipoEmissaoListDropdown,
															onChanged: (dynamic newValue) {
																bpeCabecalhoController.currentModel.tipoEmissao = newValue;
																bpeCabecalhoController.formWasChanged = true;
															},
														),
													),
												),
												BootstrapCol(
													sizes: 'col-12 col-md-3',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: TextFormField(
															autofocus: true,
															maxLength: 20,
															controller: bpeCabecalhoController.versaoProcessoEmissaoController,
															decoration: inputDecoration(
																hintText: 'Informe os dados para o campo Versao Processo Emissao',
																labelText: 'Versao Processo Emissao',
																usePadding: true,
															),
															onSaved: (String? value) {},
															onChanged: (text) {
																bpeCabecalhoController.currentModel.versaoProcessoEmissao = text;
																bpeCabecalhoController.formWasChanged = true;
															},
														),
													),
												),
											],
										),
										const Divider(
											color: Colors.transparent,
										),
										BootstrapRow(
											height: 60,
											children: <BootstrapCol>[
												BootstrapCol(
													sizes: 'col-12 col-md-6',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: CustomDropdownButton(
															controller: bpeCabecalhoController.tipoBpeController,
															labelText: 'Tipo Bpe',
															hintText: 'Informe os dados para o campo Tipo Bpe',
															items: BpeCabecalhoDomain.tipoBpeListDropdown,
															onChanged: (dynamic newValue) {
																bpeCabecalhoController.currentModel.tipoBpe = newValue;
																bpeCabecalhoController.formWasChanged = true;
															},
														),
													),
												),
												BootstrapCol(
													sizes: 'col-12 col-md-6',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: CustomDropdownButton(
															controller: bpeCabecalhoController.consumidorPresencaController,
															labelText: 'Consumidor Presenca',
															hintText: 'Informe os dados para o campo Consumidor Presenca',
															items: BpeCabecalhoDomain.consumidorPresencaListDropdown,
															onChanged: (dynamic newValue) {
																bpeCabecalhoController.currentModel.consumidorPresenca = newValue;
																bpeCabecalhoController.formWasChanged = true;
															},
														),
													),
												),
											],
										),
										const Divider(
											color: Colors.transparent,
										),
										BootstrapRow(
											height: 60,
											children: <BootstrapCol>[
												BootstrapCol(
													sizes: 'col-12 col-md-3',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: CustomDropdownButton(
															controller: bpeCabecalhoController.ufInicioViagemController,
															labelText: 'Uf Inicio Viagem',
															hintText: 'Informe os dados para o campo Uf Inicio Viagem',
															items: BpeCabecalhoDomain.ufInicioViagemListDropdown,
															onChanged: (dynamic newValue) {
																bpeCabecalhoController.currentModel.ufInicioViagem = newValue;
																bpeCabecalhoController.formWasChanged = true;
															},
														),
													),
												),
												BootstrapCol(
													sizes: 'col-12 col-md-3',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: TextFormField(
															autofocus: true,
															controller: bpeCabecalhoController.codigoMunicipioInicioViagemController,
															decoration: inputDecoration(
																hintText: 'Informe os dados para o campo Codigo Municipio Inicio Viagem',
																labelText: 'Codigo Municipio Inicio Viagem',
																usePadding: true,
															),
															onSaved: (String? value) {},
															onChanged: (text) {
																bpeCabecalhoController.currentModel.codigoMunicipioInicioViagem = int.tryParse(text);
																bpeCabecalhoController.formWasChanged = true;
															},
														),
													),
												),
												BootstrapCol(
													sizes: 'col-12 col-md-3',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: CustomDropdownButton(
															controller: bpeCabecalhoController.ufFimViagemController,
															labelText: 'Uf Fim Viagem',
															hintText: 'Informe os dados para o campo Uf Fim Viagem',
															items: BpeCabecalhoDomain.ufFimViagemListDropdown,
															onChanged: (dynamic newValue) {
																bpeCabecalhoController.currentModel.ufFimViagem = newValue;
																bpeCabecalhoController.formWasChanged = true;
															},
														),
													),
												),
												BootstrapCol(
													sizes: 'col-12 col-md-3',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: TextFormField(
															autofocus: true,
															controller: bpeCabecalhoController.codigoMunicipioFimViagemController,
															decoration: inputDecoration(
																hintText: 'Informe os dados para o campo Codigo Municipio Fim Viagem',
																labelText: 'Codigo Municipio Fim Viagem',
																usePadding: true,
															),
															onSaved: (String? value) {},
															onChanged: (text) {
																bpeCabecalhoController.currentModel.codigoMunicipioFimViagem = int.tryParse(text);
																bpeCabecalhoController.formWasChanged = true;
															},
														),
													),
												),
											],
										),
										const Divider(
											color: Colors.transparent,
										),
										BootstrapRow(
											height: 60,
											children: <BootstrapCol>[
												BootstrapCol(
													sizes: 'col-12 col-md-3',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: TextFormField(
															autofocus: true,
															controller: bpeCabecalhoController.valorBilheteController,
															decoration: inputDecoration(
																hintText: 'Informe os dados para o campo Valor Bilhete',
																labelText: 'Valor Bilhete',
																usePadding: true,
															),
															onSaved: (String? value) {},
															onChanged: (text) {
																bpeCabecalhoController.currentModel.valorBilhete = bpeCabecalhoController.valorBilheteController.numberValue;
																bpeCabecalhoController.formWasChanged = true;
															},
														),
													),
												),
												BootstrapCol(
													sizes: 'col-12 col-md-3',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: TextFormField(
															autofocus: true,
															controller: bpeCabecalhoController.valorDescontoController,
															decoration: inputDecoration(
																hintText: 'Informe os dados para o campo Valor Desconto',
																labelText: 'Valor Desconto',
																usePadding: true,
															),
															onSaved: (String? value) {},
															onChanged: (text) {
																bpeCabecalhoController.currentModel.valorDesconto = bpeCabecalhoController.valorDescontoController.numberValue;
																bpeCabecalhoController.formWasChanged = true;
															},
														),
													),
												),
												BootstrapCol(
													sizes: 'col-12 col-md-3',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: TextFormField(
															autofocus: true,
															controller: bpeCabecalhoController.valorPagoController,
															decoration: inputDecoration(
																hintText: 'Informe os dados para o campo Valor Pago',
																labelText: 'Valor Pago',
																usePadding: true,
															),
															onSaved: (String? value) {},
															onChanged: (text) {
																bpeCabecalhoController.currentModel.valorPago = bpeCabecalhoController.valorPagoController.numberValue;
																bpeCabecalhoController.formWasChanged = true;
															},
														),
													),
												),
												BootstrapCol(
													sizes: 'col-12 col-md-3',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: TextFormField(
															autofocus: true,
															controller: bpeCabecalhoController.valorTrocoController,
															decoration: inputDecoration(
																hintText: 'Informe os dados para o campo Valor Troco',
																labelText: 'Valor Troco',
																usePadding: true,
															),
															onSaved: (String? value) {},
															onChanged: (text) {
																bpeCabecalhoController.currentModel.valorTroco = bpeCabecalhoController.valorTrocoController.numberValue;
																bpeCabecalhoController.formWasChanged = true;
															},
														),
													),
												),
											],
										),
										const Divider(
											color: Colors.transparent,
										),
										BootstrapRow(
											height: 60,
											children: <BootstrapCol>[
												BootstrapCol(
													sizes: 'col-12 col-md-4',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: CustomDropdownButton(
															controller: bpeCabecalhoController.tipoDescontoController,
															labelText: 'Tipo Desconto',
															hintText: 'Informe os dados para o campo Tipo Desconto',
															items: BpeCabecalhoDomain.tipoDescontoListDropdown,
															onChanged: (dynamic newValue) {
																bpeCabecalhoController.currentModel.tipoDesconto = newValue;
																bpeCabecalhoController.formWasChanged = true;
															},
														),
													),
												),
												BootstrapCol(
													sizes: 'col-12 col-md-4',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: TextFormField(
															autofocus: true,
															maxLength: 100,
															controller: bpeCabecalhoController.descontoDescricaoController,
															decoration: inputDecoration(
																hintText: 'Informe os dados para o campo Desconto Descricao',
																labelText: 'Desconto Descricao',
																usePadding: true,
															),
															onSaved: (String? value) {},
															onChanged: (text) {
																bpeCabecalhoController.currentModel.descontoDescricao = text;
																bpeCabecalhoController.formWasChanged = true;
															},
														),
													),
												),
												BootstrapCol(
													sizes: 'col-12 col-md-4',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: TextFormField(
															autofocus: true,
															maxLength: 20,
															controller: bpeCabecalhoController.descontoConcedidoOutrosController,
															decoration: inputDecoration(
																hintText: 'Informe os dados para o campo Desconto Concedido Outros',
																labelText: 'Desconto Concedido Outros',
																usePadding: true,
															),
															onSaved: (String? value) {},
															onChanged: (text) {
																bpeCabecalhoController.currentModel.descontoConcedidoOutros = text;
																bpeCabecalhoController.formWasChanged = true;
															},
														),
													),
												),
											],
										),
										const Divider(
											color: Colors.transparent,
										),
										BootstrapRow(
											height: 60,
											children: <BootstrapCol>[
												BootstrapCol(
													sizes: 'col-12 col-md-3',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: CustomDropdownButton(
															controller: bpeCabecalhoController.formaPagamentoController,
															labelText: 'Forma Pagamento',
															hintText: 'Informe os dados para o campo Forma Pagamento',
															items: BpeCabecalhoDomain.formaPagamentoListDropdown,
															onChanged: (dynamic newValue) {
																bpeCabecalhoController.currentModel.formaPagamento = newValue;
																bpeCabecalhoController.formWasChanged = true;
															},
														),
													),
												),
												BootstrapCol(
													sizes: 'col-12 col-md-3',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: TextFormField(
															autofocus: true,
															maxLength: 100,
															controller: bpeCabecalhoController.formaPagamentoOutrosController,
															decoration: inputDecoration(
																hintText: 'Informe os dados para o campo Forma Pagamento Outros',
																labelText: 'Forma Pagamento Outros',
																usePadding: true,
															),
															onSaved: (String? value) {},
															onChanged: (text) {
																bpeCabecalhoController.currentModel.formaPagamentoOutros = text;
																bpeCabecalhoController.formWasChanged = true;
															},
														),
													),
												),
												BootstrapCol(
													sizes: 'col-12 col-md-3',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: TextFormField(
															autofocus: true,
															maxLength: 20,
															controller: bpeCabecalhoController.formaPagamentoDocumentoController,
															decoration: inputDecoration(
																hintText: 'Informe os dados para o campo Forma Pagamento Documento',
																labelText: 'Forma Pagamento Documento',
																usePadding: true,
															),
															onSaved: (String? value) {},
															onChanged: (text) {
																bpeCabecalhoController.currentModel.formaPagamentoDocumento = text;
																bpeCabecalhoController.formWasChanged = true;
															},
														),
													),
												),
												BootstrapCol(
													sizes: 'col-12 col-md-3',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: TextFormField(
															autofocus: true,
															maxLength: 2,
															controller: bpeCabecalhoController.cstController,
															decoration: inputDecoration(
																hintText: 'Informe os dados para o campo Cst',
																labelText: 'Cst',
																usePadding: true,
															),
															onSaved: (String? value) {},
															onChanged: (text) {
																bpeCabecalhoController.currentModel.cst = text;
																bpeCabecalhoController.formWasChanged = true;
															},
														),
													),
												),
											],
										),
										const Divider(
											color: Colors.transparent,
										),
										BootstrapRow(
											height: 60,
											children: <BootstrapCol>[
												BootstrapCol(
													sizes: 'col-12 col-md-3',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: TextFormField(
															autofocus: true,
															controller: bpeCabecalhoController.baseCalculoIcmsController,
															decoration: inputDecoration(
																hintText: 'Informe os dados para o campo Base Calculo Icms',
																labelText: 'Base Calculo Icms',
																usePadding: true,
															),
															onSaved: (String? value) {},
															onChanged: (text) {
																bpeCabecalhoController.currentModel.baseCalculoIcms = bpeCabecalhoController.baseCalculoIcmsController.numberValue;
																bpeCabecalhoController.formWasChanged = true;
															},
														),
													),
												),
												BootstrapCol(
													sizes: 'col-12 col-md-3',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: TextFormField(
															autofocus: true,
															controller: bpeCabecalhoController.aliquotaIcmsController,
															decoration: inputDecoration(
																hintText: 'Informe os dados para o campo Aliquota Icms',
																labelText: 'Aliquota Icms',
																usePadding: true,
															),
															onSaved: (String? value) {},
															onChanged: (text) {
																bpeCabecalhoController.currentModel.aliquotaIcms = bpeCabecalhoController.aliquotaIcmsController.numberValue;
																bpeCabecalhoController.formWasChanged = true;
															},
														),
													),
												),
												BootstrapCol(
													sizes: 'col-12 col-md-3',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: TextFormField(
															autofocus: true,
															controller: bpeCabecalhoController.valorIcmsController,
															decoration: inputDecoration(
																hintText: 'Informe os dados para o campo Valor Icms',
																labelText: 'Valor Icms',
																usePadding: true,
															),
															onSaved: (String? value) {},
															onChanged: (text) {
																bpeCabecalhoController.currentModel.valorIcms = bpeCabecalhoController.valorIcmsController.numberValue;
																bpeCabecalhoController.formWasChanged = true;
															},
														),
													),
												),
												BootstrapCol(
													sizes: 'col-12 col-md-3',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: TextFormField(
															autofocus: true,
															controller: bpeCabecalhoController.percentualReducaoBcIcmsController,
															decoration: inputDecoration(
																hintText: 'Informe os dados para o campo Percentual Reducao Bc Icms',
																labelText: 'Percentual Reducao Bc Icms',
																usePadding: true,
															),
															onSaved: (String? value) {},
															onChanged: (text) {
																bpeCabecalhoController.currentModel.percentualReducaoBcIcms = bpeCabecalhoController.percentualReducaoBcIcmsController.numberValue;
																bpeCabecalhoController.formWasChanged = true;
															},
														),
													),
												),
											],
										),
										const Divider(
											color: Colors.transparent,
										),
										BootstrapRow(
											height: 60,
											children: <BootstrapCol>[
												BootstrapCol(
													sizes: 'col-12',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: TextFormField(
															autofocus: true,
															maxLines: 3,
															controller: bpeCabecalhoController.informacoesAddFiscoController,
															decoration: inputDecoration(
																hintText: 'Informe os dados para o campo Informacoes Add Fisco',
																labelText: 'Informacoes Add Fisco',
																usePadding: true,
															),
															onSaved: (String? value) {},
															onChanged: (text) {
																bpeCabecalhoController.currentModel.informacoesAddFisco = text;
																bpeCabecalhoController.formWasChanged = true;
															},
														),
													),
												),
											],
										),
										const Divider(
											indent: 10,
											endIndent: 10,
											thickness: 2,
										),
										BootstrapRow(
											height: 60,
											children: <BootstrapCol>[
												BootstrapCol(
													sizes: 'col-12',
													child: Text(
														'field_is_mandatory'.tr,
														style: Theme.of(context).textTheme.bodySmall,
													),
												),
											],
										),
										const SizedBox(height: 10.0),
									],
								),
							),
						),
					),
				),
			);
	}
}
