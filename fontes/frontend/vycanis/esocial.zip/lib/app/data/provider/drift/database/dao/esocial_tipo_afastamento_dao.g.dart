// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'esocial_tipo_afastamento_dao.dart';

// ignore_for_file: type=lint
mixin _$EsocialTipoAfastamentoDaoMixin on DatabaseAccessor<AppDatabase> {
  $EsocialTipoAfastamentosTable get esocialTipoAfastamentos =>
      attachedDatabase.esocialTipoAfastamentos;
}
