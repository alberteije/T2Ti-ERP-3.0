// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'esocial_natureza_juridica_dao.dart';

// ignore_for_file: type=lint
mixin _$EsocialNaturezaJuridicaDaoMixin on DatabaseAccessor<AppDatabase> {
  $EsocialNaturezaJuridicasTable get esocialNaturezaJuridicas =>
      attachedDatabase.esocialNaturezaJuridicas;
}
