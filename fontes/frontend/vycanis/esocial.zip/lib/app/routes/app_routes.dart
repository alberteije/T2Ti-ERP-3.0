abstract class Routes{
	
	static const splashPage = '/splashPage';
	static const loginPage = '/loginPage';
	static const homePage = '/homePage';
	static const filterPage = '/filterPage';
	static const lookupPage = '/lookupPage';
  static const menuModulesPage = '/menuModulesPage';
		
	static const esocialNaturezaJuridicaListPage = '/esocialNaturezaJuridicaListPage'; 
	static const esocialNaturezaJuridicaEditPage = '/esocialNaturezaJuridicaEditPage';
	static const esocialRubricaListPage = '/esocialRubricaListPage'; 
	static const esocialRubricaEditPage = '/esocialRubricaEditPage';
	static const esocialTipoAfastamentoListPage = '/esocialTipoAfastamentoListPage'; 
	static const esocialTipoAfastamentoEditPage = '/esocialTipoAfastamentoEditPage';
	static const esocialMotivoDesligamentoListPage = '/esocialMotivoDesligamentoListPage'; 
	static const esocialMotivoDesligamentoEditPage = '/esocialMotivoDesligamentoEditPage';
	static const esocialClassificacaoTributListPage = '/esocialClassificacaoTributListPage'; 
	static const esocialClassificacaoTributEditPage = '/esocialClassificacaoTributEditPage';
}