import 'package:get/get.dart';
import 'package:pcp/app/controller/pcp_servico_controller.dart';

class PcpServicoBindings implements Binding {
	@override
	List<Bind> dependencies() {
		return [
			Bind.lazyPut<PcpServicoController>(() => PcpServicoController()),
		];
	}
}
