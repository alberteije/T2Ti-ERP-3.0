import 'dart:convert';
import 'package:pluto_grid/pluto_grid.dart';
import 'package:pcp/app/data/model/model_imports.dart';


class PcpServicoColaboradorModel extends ModelBase {
  int? id;
  int? idPcpServico;
  int? idColaborador;
  ViewPessoaColaboradorModel? viewPessoaColaboradorModel;

  PcpServicoColaboradorModel({
    this.id,
    this.idPcpServico,
    this.idColaborador,
    ViewPessoaColaboradorModel? viewPessoaColaboradorModel,
  }) {
    this.viewPessoaColaboradorModel = viewPessoaColaboradorModel ?? ViewPessoaColaboradorModel();
  }

  static List<String> dbColumns = <String>[
    'id',
  ];

  static List<String> aliasColumns = <String>[
    'Id',
  ];

  PcpServicoColaboradorModel.fromJson(Map<String, dynamic> jsonData) {
    id = jsonData['id'];
    idPcpServico = jsonData['idPcpServico'];
    idColaborador = jsonData['idColaborador'];
    viewPessoaColaboradorModel = jsonData['viewPessoaColaboradorModel'] == null ? ViewPessoaColaboradorModel() : ViewPessoaColaboradorModel.fromJson(jsonData['viewPessoaColaboradorModel']);
  }

  Map<String, dynamic> get toJson {
    Map<String, dynamic> jsonData = <String, dynamic>{};

    jsonData['id'] = id != 0 ? id : null;
    jsonData['idPcpServico'] = idPcpServico != 0 ? idPcpServico : null;
    jsonData['idColaborador'] = idColaborador != 0 ? idColaborador : null;
    jsonData['viewPessoaColaboradorModel'] = viewPessoaColaboradorModel?.toJson;
    jsonData['viewPessoaColaborador'] = viewPessoaColaboradorModel?.nome ?? '';

    return jsonData;
  }

  String objectEncodeJson() {
    final jsonData = toJson;
    return json.encode(jsonData);
  }

  static PcpServicoColaboradorModel fromPlutoRow(PlutoRow row) {
    return PcpServicoColaboradorModel(
      id: row.cells['id']?.value,
      idPcpServico: row.cells['idPcpServico']?.value,
      idColaborador: row.cells['idColaborador']?.value,
    );
  }

  PlutoRow toPlutoRow() {
    return PlutoRow(
      cells: {
        'tempId': PlutoCell(value: tempId),
        'id': PlutoCell(value: id ?? 0),
        'idPcpServico': PlutoCell(value: idPcpServico ?? 0),
        'idColaborador': PlutoCell(value: idColaborador ?? 0),
        'viewPessoaColaborador': PlutoCell(value: viewPessoaColaboradorModel?.nome ?? ''),
      },
    );
  }

  PcpServicoColaboradorModel clone() {
    return PcpServicoColaboradorModel(
      id: id,
      idPcpServico: idPcpServico,
      idColaborador: idColaborador,
      viewPessoaColaboradorModel: viewPessoaColaboradorModel?.clone(),
    );
  }


}