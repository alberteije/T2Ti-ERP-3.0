import 'dart:convert';
import 'package:pluto_grid/pluto_grid.dart';
import 'package:pcp/app/data/model/model_imports.dart';


class PcpInstrucaoOpModel extends ModelBase {
  int? id;
  int? idPcpOpCabecalho;
  int? idPcpInstrucao;
  PcpInstrucaoModel? pcpInstrucaoModel;

  PcpInstrucaoOpModel({
    this.id,
    this.idPcpOpCabecalho,
    this.idPcpInstrucao,
    PcpInstrucaoModel? pcpInstrucaoModel,
  }) {
    this.pcpInstrucaoModel = pcpInstrucaoModel ?? PcpInstrucaoModel();
  }

  static List<String> dbColumns = <String>[
    'id',
  ];

  static List<String> aliasColumns = <String>[
    'Id',
  ];

  PcpInstrucaoOpModel.fromJson(Map<String, dynamic> jsonData) {
    id = jsonData['id'];
    idPcpOpCabecalho = jsonData['idPcpOpCabecalho'];
    idPcpInstrucao = jsonData['idPcpInstrucao'];
    pcpInstrucaoModel = jsonData['pcpInstrucaoModel'] == null ? PcpInstrucaoModel() : PcpInstrucaoModel.fromJson(jsonData['pcpInstrucaoModel']);
  }

  Map<String, dynamic> get toJson {
    Map<String, dynamic> jsonData = <String, dynamic>{};

    jsonData['id'] = id != 0 ? id : null;
    jsonData['idPcpOpCabecalho'] = idPcpOpCabecalho != 0 ? idPcpOpCabecalho : null;
    jsonData['idPcpInstrucao'] = idPcpInstrucao != 0 ? idPcpInstrucao : null;
    jsonData['pcpInstrucaoModel'] = pcpInstrucaoModel?.toJson;
    jsonData['pcpInstrucao'] = pcpInstrucaoModel?.descricao ?? '';

    return jsonData;
  }

  String objectEncodeJson() {
    final jsonData = toJson;
    return json.encode(jsonData);
  }

  static PcpInstrucaoOpModel fromPlutoRow(PlutoRow row) {
    return PcpInstrucaoOpModel(
      id: row.cells['id']?.value,
      idPcpOpCabecalho: row.cells['idPcpOpCabecalho']?.value,
      idPcpInstrucao: row.cells['idPcpInstrucao']?.value,
    );
  }

  PlutoRow toPlutoRow() {
    return PlutoRow(
      cells: {
        'tempId': PlutoCell(value: tempId),
        'id': PlutoCell(value: id ?? 0),
        'idPcpOpCabecalho': PlutoCell(value: idPcpOpCabecalho ?? 0),
        'idPcpInstrucao': PlutoCell(value: idPcpInstrucao ?? 0),
        'pcpInstrucao': PlutoCell(value: pcpInstrucaoModel?.descricao ?? ''),
      },
    );
  }

  PcpInstrucaoOpModel clone() {
    return PcpInstrucaoOpModel(
      id: id,
      idPcpOpCabecalho: idPcpOpCabecalho,
      idPcpInstrucao: idPcpInstrucao,
      pcpInstrucaoModel: pcpInstrucaoModel?.clone(),
    );
  }


}