import 'dart:convert';
import 'package:pluto_grid/pluto_grid.dart';
import 'package:pcp/app/data/model/model_imports.dart';


class PcpOpDetalheModel extends ModelBase {
  int? id;
  int? idPcpOpCabecalho;
  int? idProduto;
  double? quantidadeProduzir;
  double? quantidadeProduzida;
  double? quantidadeEntregue;
  double? custoPrevisto;
  double? custoRealizado;
  ProdutoModel? produtoModel;
  List<PcpServicoModel>? pcpServicoModelList;

  PcpOpDetalheModel({
    this.id,
    this.idPcpOpCabecalho,
    this.idProduto,
    this.quantidadeProduzir,
    this.quantidadeProduzida,
    this.quantidadeEntregue,
    this.custoPrevisto,
    this.custoRealizado,
    ProdutoModel? produtoModel,
    List<PcpServicoModel>? pcpServicoModelList,
  }) {
    this.produtoModel = produtoModel ?? ProdutoModel();
    this.pcpServicoModelList = pcpServicoModelList?.toList(growable: true) ?? [];
  }

  static List<String> dbColumns = <String>[
    'id',
    'quantidade_produzir',
    'quantidade_produzida',
    'quantidade_entregue',
    'custo_previsto',
    'custo_realizado',
  ];

  static List<String> aliasColumns = <String>[
    'Id',
    'Quantidade Produzir',
    'Quantidade Produzida',
    'Quantidade Entregue',
    'Custo Previsto',
    'Custo Realizado',
  ];

  PcpOpDetalheModel.fromJson(Map<String, dynamic> jsonData) {
    id = jsonData['id'];
    idPcpOpCabecalho = jsonData['idPcpOpCabecalho'];
    idProduto = jsonData['idProduto'];
    quantidadeProduzir = jsonData['quantidadeProduzir']?.toDouble();
    quantidadeProduzida = jsonData['quantidadeProduzida']?.toDouble();
    quantidadeEntregue = jsonData['quantidadeEntregue']?.toDouble();
    custoPrevisto = jsonData['custoPrevisto']?.toDouble();
    custoRealizado = jsonData['custoRealizado']?.toDouble();
    produtoModel = jsonData['produtoModel'] == null ? ProdutoModel() : ProdutoModel.fromJson(jsonData['produtoModel']);
    pcpServicoModelList = (jsonData['pcpServicoModelList'] as Iterable?)?.map((m) => PcpServicoModel.fromJson(m)).toList() ?? [];
  }

  Map<String, dynamic> get toJson {
    Map<String, dynamic> jsonData = <String, dynamic>{};

    jsonData['id'] = id != 0 ? id : null;
    jsonData['idPcpOpCabecalho'] = idPcpOpCabecalho != 0 ? idPcpOpCabecalho : null;
    jsonData['idProduto'] = idProduto != 0 ? idProduto : null;
    jsonData['quantidadeProduzir'] = quantidadeProduzir;
    jsonData['quantidadeProduzida'] = quantidadeProduzida;
    jsonData['quantidadeEntregue'] = quantidadeEntregue;
    jsonData['custoPrevisto'] = custoPrevisto;
    jsonData['custoRealizado'] = custoRealizado;
    jsonData['produtoModel'] = produtoModel?.toJson;
    jsonData['produto'] = produtoModel?.nome ?? '';

		var pcpServicoModelLocalList = []; 
		for (PcpServicoModel object in pcpServicoModelList ?? []) { 
			pcpServicoModelLocalList.add(object.toJson); 
		}
		jsonData['pcpServicoModelList'] = pcpServicoModelLocalList;

    return jsonData;
  }

  String objectEncodeJson() {
    final jsonData = toJson;
    return json.encode(jsonData);
  }

  static PcpOpDetalheModel fromPlutoRow(PlutoRow row) {
    return PcpOpDetalheModel(
      id: row.cells['id']?.value,
      idPcpOpCabecalho: row.cells['idPcpOpCabecalho']?.value,
      idProduto: row.cells['idProduto']?.value,
      quantidadeProduzir: row.cells['quantidadeProduzir']?.value,
      quantidadeProduzida: row.cells['quantidadeProduzida']?.value,
      quantidadeEntregue: row.cells['quantidadeEntregue']?.value,
      custoPrevisto: row.cells['custoPrevisto']?.value,
      custoRealizado: row.cells['custoRealizado']?.value,
    );
  }

  PlutoRow toPlutoRow() {
    return PlutoRow(
      cells: {
        'tempId': PlutoCell(value: tempId),
        'id': PlutoCell(value: id ?? 0),
        'idPcpOpCabecalho': PlutoCell(value: idPcpOpCabecalho ?? 0),
        'idProduto': PlutoCell(value: idProduto ?? 0),
        'quantidadeProduzir': PlutoCell(value: quantidadeProduzir ?? 0.0),
        'quantidadeProduzida': PlutoCell(value: quantidadeProduzida ?? 0.0),
        'quantidadeEntregue': PlutoCell(value: quantidadeEntregue ?? 0.0),
        'custoPrevisto': PlutoCell(value: custoPrevisto ?? 0.0),
        'custoRealizado': PlutoCell(value: custoRealizado ?? 0.0),
        'produto': PlutoCell(value: produtoModel?.nome ?? ''),
      },
    );
  }

  PcpOpDetalheModel clone() {
    return PcpOpDetalheModel(
      id: id,
      idPcpOpCabecalho: idPcpOpCabecalho,
      idProduto: idProduto,
      quantidadeProduzir: quantidadeProduzir,
      quantidadeProduzida: quantidadeProduzida,
      quantidadeEntregue: quantidadeEntregue,
      custoPrevisto: custoPrevisto,
      custoRealizado: custoRealizado,
      produtoModel: produtoModel?.clone(),
      pcpServicoModelList: pcpServicoModelListClone(pcpServicoModelList!),
    );
  }

  pcpServicoModelListClone(List<PcpServicoModel> pcpServicoModelList) { 
		List<PcpServicoModel> resultList = [];
		for (var pcpServicoModel in pcpServicoModelList) {
			resultList.add(pcpServicoModel.clone());
		}
		return resultList;
	}

}