import 'dart:convert';
import 'package:pluto_grid/pluto_grid.dart';
import 'package:pcp/app/data/model/model_imports.dart';


class PcpServicoEquipamentoModel extends ModelBase {
  int? id;
  int? idPcpServico;
  int? idPatrimBem;
  PatrimBemModel? patrimBemModel;

  PcpServicoEquipamentoModel({
    this.id,
    this.idPcpServico,
    this.idPatrimBem,
    PatrimBemModel? patrimBemModel,
  }) {
    this.patrimBemModel = patrimBemModel ?? PatrimBemModel();
  }

  static List<String> dbColumns = <String>[
    'id',
  ];

  static List<String> aliasColumns = <String>[
    'Id',
  ];

  PcpServicoEquipamentoModel.fromJson(Map<String, dynamic> jsonData) {
    id = jsonData['id'];
    idPcpServico = jsonData['idPcpServico'];
    idPatrimBem = jsonData['idPatrimBem'];
    patrimBemModel = jsonData['patrimBemModel'] == null ? PatrimBemModel() : PatrimBemModel.fromJson(jsonData['patrimBemModel']);
  }

  Map<String, dynamic> get toJson {
    Map<String, dynamic> jsonData = <String, dynamic>{};

    jsonData['id'] = id != 0 ? id : null;
    jsonData['idPcpServico'] = idPcpServico != 0 ? idPcpServico : null;
    jsonData['idPatrimBem'] = idPatrimBem != 0 ? idPatrimBem : null;
    jsonData['patrimBemModel'] = patrimBemModel?.toJson;
    jsonData['patrimBem'] = patrimBemModel?.nome ?? '';

    return jsonData;
  }

  String objectEncodeJson() {
    final jsonData = toJson;
    return json.encode(jsonData);
  }

  static PcpServicoEquipamentoModel fromPlutoRow(PlutoRow row) {
    return PcpServicoEquipamentoModel(
      id: row.cells['id']?.value,
      idPcpServico: row.cells['idPcpServico']?.value,
      idPatrimBem: row.cells['idPatrimBem']?.value,
    );
  }

  PlutoRow toPlutoRow() {
    return PlutoRow(
      cells: {
        'tempId': PlutoCell(value: tempId),
        'id': PlutoCell(value: id ?? 0),
        'idPcpServico': PlutoCell(value: idPcpServico ?? 0),
        'idPatrimBem': PlutoCell(value: idPatrimBem ?? 0),
        'patrimBem': PlutoCell(value: patrimBemModel?.nome ?? ''),
      },
    );
  }

  PcpServicoEquipamentoModel clone() {
    return PcpServicoEquipamentoModel(
      id: id,
      idPcpServico: idPcpServico,
      idPatrimBem: idPatrimBem,
      patrimBemModel: patrimBemModel?.clone(),
    );
  }


}