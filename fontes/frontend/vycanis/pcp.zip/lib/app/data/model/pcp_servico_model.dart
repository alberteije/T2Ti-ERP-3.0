import 'dart:convert';
import 'package:pluto_grid/pluto_grid.dart';
import 'package:pcp/app/data/model/model_imports.dart';

import 'package:pcp/app/infra/infra_imports.dart';
import 'package:intl/intl.dart';

class PcpServicoModel extends ModelBase {
  int? id;
  int? idPcpOpDetalhe;
  DateTime? inicioRealizado;
  DateTime? terminoRealizado;
  int? horasRealizado;
  int? minutosRealizado;
  int? segundosRealizado;
  double? custoRealizado;
  DateTime? inicioPrevisto;
  DateTime? terminoPrevisto;
  int? horasPrevisto;
  int? minutosPrevisto;
  int? segundosPrevisto;
  double? custoPrevisto;
  List<PcpServicoColaboradorModel>? pcpServicoColaboradorModelList;
  List<PcpServicoEquipamentoModel>? pcpServicoEquipamentoModelList;

  PcpServicoModel({
    this.id,
    this.idPcpOpDetalhe,
    this.inicioRealizado,
    this.terminoRealizado,
    this.horasRealizado,
    this.minutosRealizado,
    this.segundosRealizado,
    this.custoRealizado,
    this.inicioPrevisto,
    this.terminoPrevisto,
    this.horasPrevisto,
    this.minutosPrevisto,
    this.segundosPrevisto,
    this.custoPrevisto,
    List<PcpServicoColaboradorModel>? pcpServicoColaboradorModelList,
    List<PcpServicoEquipamentoModel>? pcpServicoEquipamentoModelList,
  }) {
    this.pcpServicoColaboradorModelList = pcpServicoColaboradorModelList?.toList(growable: true) ?? [];
    this.pcpServicoEquipamentoModelList = pcpServicoEquipamentoModelList?.toList(growable: true) ?? [];
  }

  static List<String> dbColumns = <String>[
    'id',
    'inicio_realizado',
    'termino_realizado',
    'horas_realizado',
    'minutos_realizado',
    'segundos_realizado',
    'custo_realizado',
    'inicio_previsto',
    'termino_previsto',
    'horas_previsto',
    'minutos_previsto',
    'segundos_previsto',
    'custo_previsto',
  ];

  static List<String> aliasColumns = <String>[
    'Id',
    'Inicio Realizado',
    'Termino Realizado',
    'Horas Realizado',
    'Minutos Realizado',
    'Segundos Realizado',
    'Custo Realizado',
    'Inicio Previsto',
    'Termino Previsto',
    'Horas Previsto',
    'Minutos Previsto',
    'Segundos Previsto',
    'Custo Previsto',
  ];

  PcpServicoModel.fromJson(Map<String, dynamic> jsonData) {
    id = jsonData['id'];
    idPcpOpDetalhe = jsonData['idPcpOpDetalhe'];
    inicioRealizado = jsonData['inicioRealizado'] != null ? DateTime.tryParse(jsonData['inicioRealizado']) : null;
    terminoRealizado = jsonData['terminoRealizado'] != null ? DateTime.tryParse(jsonData['terminoRealizado']) : null;
    horasRealizado = jsonData['horasRealizado'];
    minutosRealizado = jsonData['minutosRealizado'];
    segundosRealizado = jsonData['segundosRealizado'];
    custoRealizado = jsonData['custoRealizado']?.toDouble();
    inicioPrevisto = jsonData['inicioPrevisto'] != null ? DateTime.tryParse(jsonData['inicioPrevisto']) : null;
    terminoPrevisto = jsonData['terminoPrevisto'] != null ? DateTime.tryParse(jsonData['terminoPrevisto']) : null;
    horasPrevisto = jsonData['horasPrevisto'];
    minutosPrevisto = jsonData['minutosPrevisto'];
    segundosPrevisto = jsonData['segundosPrevisto'];
    custoPrevisto = jsonData['custoPrevisto']?.toDouble();
    pcpServicoColaboradorModelList = (jsonData['pcpServicoColaboradorModelList'] as Iterable?)?.map((m) => PcpServicoColaboradorModel.fromJson(m)).toList() ?? [];
    pcpServicoEquipamentoModelList = (jsonData['pcpServicoEquipamentoModelList'] as Iterable?)?.map((m) => PcpServicoEquipamentoModel.fromJson(m)).toList() ?? [];
  }

  Map<String, dynamic> get toJson {
    Map<String, dynamic> jsonData = <String, dynamic>{};

    jsonData['id'] = id != 0 ? id : null;
    jsonData['idPcpOpDetalhe'] = idPcpOpDetalhe != 0 ? idPcpOpDetalhe : null;
    jsonData['inicioRealizado'] = inicioRealizado != null ? DateFormat('yyyy-MM-ddT00:00:00').format(inicioRealizado!) : null;
    jsonData['terminoRealizado'] = terminoRealizado != null ? DateFormat('yyyy-MM-ddT00:00:00').format(terminoRealizado!) : null;
    jsonData['horasRealizado'] = horasRealizado;
    jsonData['minutosRealizado'] = minutosRealizado;
    jsonData['segundosRealizado'] = segundosRealizado;
    jsonData['custoRealizado'] = custoRealizado;
    jsonData['inicioPrevisto'] = inicioPrevisto != null ? DateFormat('yyyy-MM-ddT00:00:00').format(inicioPrevisto!) : null;
    jsonData['terminoPrevisto'] = terminoPrevisto != null ? DateFormat('yyyy-MM-ddT00:00:00').format(terminoPrevisto!) : null;
    jsonData['horasPrevisto'] = horasPrevisto;
    jsonData['minutosPrevisto'] = minutosPrevisto;
    jsonData['segundosPrevisto'] = segundosPrevisto;
    jsonData['custoPrevisto'] = custoPrevisto;
    
		var pcpServicoColaboradorModelLocalList = []; 
		for (PcpServicoColaboradorModel object in pcpServicoColaboradorModelList ?? []) { 
			pcpServicoColaboradorModelLocalList.add(object.toJson); 
		}
		jsonData['pcpServicoColaboradorModelList'] = pcpServicoColaboradorModelLocalList;
    
		var pcpServicoEquipamentoModelLocalList = []; 
		for (PcpServicoEquipamentoModel object in pcpServicoEquipamentoModelList ?? []) { 
			pcpServicoEquipamentoModelLocalList.add(object.toJson); 
		}
		jsonData['pcpServicoEquipamentoModelList'] = pcpServicoEquipamentoModelLocalList;

    return jsonData;
  }

  String objectEncodeJson() {
    final jsonData = toJson;
    return json.encode(jsonData);
  }

  static PcpServicoModel fromPlutoRow(PlutoRow row) {
    return PcpServicoModel(
      id: row.cells['id']?.value,
      idPcpOpDetalhe: row.cells['idPcpOpDetalhe']?.value,
      inicioRealizado: Util.stringToDate(row.cells['inicioRealizado']?.value),
      terminoRealizado: Util.stringToDate(row.cells['terminoRealizado']?.value),
      horasRealizado: row.cells['horasRealizado']?.value,
      minutosRealizado: row.cells['minutosRealizado']?.value,
      segundosRealizado: row.cells['segundosRealizado']?.value,
      custoRealizado: row.cells['custoRealizado']?.value,
      inicioPrevisto: Util.stringToDate(row.cells['inicioPrevisto']?.value),
      terminoPrevisto: Util.stringToDate(row.cells['terminoPrevisto']?.value),
      horasPrevisto: row.cells['horasPrevisto']?.value,
      minutosPrevisto: row.cells['minutosPrevisto']?.value,
      segundosPrevisto: row.cells['segundosPrevisto']?.value,
      custoPrevisto: row.cells['custoPrevisto']?.value,
    );
  }

  PlutoRow toPlutoRow() {
    return PlutoRow(
      cells: {
        'tempId': PlutoCell(value: tempId),
        'id': PlutoCell(value: id ?? 0),
        'idPcpOpDetalhe': PlutoCell(value: idPcpOpDetalhe ?? 0),
        'inicioRealizado': PlutoCell(value: inicioRealizado),
        'terminoRealizado': PlutoCell(value: terminoRealizado),
        'horasRealizado': PlutoCell(value: horasRealizado ?? 0),
        'minutosRealizado': PlutoCell(value: minutosRealizado ?? 0),
        'segundosRealizado': PlutoCell(value: segundosRealizado ?? 0),
        'custoRealizado': PlutoCell(value: custoRealizado ?? 0.0),
        'inicioPrevisto': PlutoCell(value: inicioPrevisto),
        'terminoPrevisto': PlutoCell(value: terminoPrevisto),
        'horasPrevisto': PlutoCell(value: horasPrevisto ?? 0),
        'minutosPrevisto': PlutoCell(value: minutosPrevisto ?? 0),
        'segundosPrevisto': PlutoCell(value: segundosPrevisto ?? 0),
        'custoPrevisto': PlutoCell(value: custoPrevisto ?? 0.0),
      },
    );
  }

  PcpServicoModel clone() {
    return PcpServicoModel(
      id: id,
      idPcpOpDetalhe: idPcpOpDetalhe,
      inicioRealizado: inicioRealizado,
      terminoRealizado: terminoRealizado,
      horasRealizado: horasRealizado,
      minutosRealizado: minutosRealizado,
      segundosRealizado: segundosRealizado,
      custoRealizado: custoRealizado,
      inicioPrevisto: inicioPrevisto,
      terminoPrevisto: terminoPrevisto,
      horasPrevisto: horasPrevisto,
      minutosPrevisto: minutosPrevisto,
      segundosPrevisto: segundosPrevisto,
      custoPrevisto: custoPrevisto,
      pcpServicoColaboradorModelList: pcpServicoColaboradorModelListClone(pcpServicoColaboradorModelList!),
      pcpServicoEquipamentoModelList: pcpServicoEquipamentoModelListClone(pcpServicoEquipamentoModelList!),
    );
  }

  pcpServicoColaboradorModelListClone(List<PcpServicoColaboradorModel> pcpServicoColaboradorModelList) { 
		List<PcpServicoColaboradorModel> resultList = [];
		for (var pcpServicoColaboradorModel in pcpServicoColaboradorModelList) {
			resultList.add(pcpServicoColaboradorModel.clone());
		}
		return resultList;
	}

  pcpServicoEquipamentoModelListClone(List<PcpServicoEquipamentoModel> pcpServicoEquipamentoModelList) { 
		List<PcpServicoEquipamentoModel> resultList = [];
		for (var pcpServicoEquipamentoModel in pcpServicoEquipamentoModelList) {
			resultList.add(pcpServicoEquipamentoModel.clone());
		}
		return resultList;
	}


}