import 'dart:convert';
import 'package:pluto_grid/pluto_grid.dart';
import 'package:pcp/app/data/model/model_imports.dart';

import 'package:pcp/app/infra/infra_imports.dart';
import 'package:intl/intl.dart';
import 'package:pcp/app/data/domain/domain_imports.dart';

class PatrimBemModel extends ModelBase {
  int? id;
  int? idCentroResultado;
  int? idPatrimTipoAquisicaoBem;
  int? idPatrimEstadoConservacao;
  int? idPatrimGrupoBem;
  int? idFornecedor;
  int? idSetor;
  String? numeroNb;
  String? nome;
  String? descricao;
  String? numeroSerie;
  DateTime? dataAquisicao;
  DateTime? dataAceite;
  DateTime? dataCadastro;
  DateTime? dataContabilizado;
  DateTime? dataVistoria;
  DateTime? dataMarcacao;
  DateTime? dataBaixa;
  DateTime? vencimentoGarantia;
  String? numeroNotaFiscal;
  String? chaveNfe;
  double? valorOriginal;
  double? valorCompra;
  double? valorAtualizado;
  double? valorBaixa;
  String? deprecia;
  String? metodoDepreciacao;
  DateTime? inicioDepreciacao;
  DateTime? ultimaDepreciacao;
  String? tipoDepreciacao;
  double? taxaAnualDepreciacao;
  double? taxaMensalDepreciacao;
  double? taxaDepreciacaoAcelerada;
  double? taxaDepreciacaoIncentivada;
  String? funcao;

  PatrimBemModel({
    this.id,
    this.idCentroResultado,
    this.idPatrimTipoAquisicaoBem,
    this.idPatrimEstadoConservacao,
    this.idPatrimGrupoBem,
    this.idFornecedor,
    this.idSetor,
    this.numeroNb,
    this.nome,
    this.descricao,
    this.numeroSerie,
    this.dataAquisicao,
    this.dataAceite,
    this.dataCadastro,
    this.dataContabilizado,
    this.dataVistoria,
    this.dataMarcacao,
    this.dataBaixa,
    this.vencimentoGarantia,
    this.numeroNotaFiscal,
    this.chaveNfe,
    this.valorOriginal,
    this.valorCompra,
    this.valorAtualizado,
    this.valorBaixa,
    this.deprecia = 'AAA',
    this.metodoDepreciacao = 'AAA',
    this.inicioDepreciacao,
    this.ultimaDepreciacao,
    this.tipoDepreciacao = 'AAA',
    this.taxaAnualDepreciacao,
    this.taxaMensalDepreciacao,
    this.taxaDepreciacaoAcelerada,
    this.taxaDepreciacaoIncentivada,
    this.funcao,
  });

  static List<String> dbColumns = <String>[
    'id',
    'id_centro_resultado',
    'id_patrim_tipo_aquisicao_bem',
    'id_patrim_estado_conservacao',
    'id_patrim_grupo_bem',
    'id_fornecedor',
    'id_setor',
    'numero_nb',
    'nome',
    'descricao',
    'numero_serie',
    'data_aquisicao',
    'data_aceite',
    'data_cadastro',
    'data_contabilizado',
    'data_vistoria',
    'data_marcacao',
    'data_baixa',
    'vencimento_garantia',
    'numero_nota_fiscal',
    'chave_nfe',
    'valor_original',
    'valor_compra',
    'valor_atualizado',
    'valor_baixa',
    'deprecia',
    'metodo_depreciacao',
    'inicio_depreciacao',
    'ultima_depreciacao',
    'tipo_depreciacao',
    'taxa_anual_depreciacao',
    'taxa_mensal_depreciacao',
    'taxa_depreciacao_acelerada',
    'taxa_depreciacao_incentivada',
    'funcao',
  ];

  static List<String> aliasColumns = <String>[
    'Id',
    'Id Centro Resultado',
    'Id Patrim Tipo Aquisicao Bem',
    'Id Patrim Estado Conservacao',
    'Id Patrim Grupo Bem',
    'Id Fornecedor',
    'Id Setor',
    'Numero Nb',
    'Nome',
    'Descricao',
    'Numero Serie',
    'Data Aquisicao',
    'Data Aceite',
    'Data Cadastro',
    'Data Contabilizado',
    'Data Vistoria',
    'Data Marcacao',
    'Data Baixa',
    'Vencimento Garantia',
    'Numero Nota Fiscal',
    'Chave Nfe',
    'Valor Original',
    'Valor Compra',
    'Valor Atualizado',
    'Valor Baixa',
    'Deprecia',
    'Metodo Depreciacao',
    'Inicio Depreciacao',
    'Ultima Depreciacao',
    'Tipo Depreciacao',
    'Taxa Anual Depreciacao',
    'Taxa Mensal Depreciacao',
    'Taxa Depreciacao Acelerada',
    'Taxa Depreciacao Incentivada',
    'Funcao',
  ];

  PatrimBemModel.fromJson(Map<String, dynamic> jsonData) {
    id = jsonData['id'];
    idCentroResultado = jsonData['idCentroResultado'];
    idPatrimTipoAquisicaoBem = jsonData['idPatrimTipoAquisicaoBem'];
    idPatrimEstadoConservacao = jsonData['idPatrimEstadoConservacao'];
    idPatrimGrupoBem = jsonData['idPatrimGrupoBem'];
    idFornecedor = jsonData['idFornecedor'];
    idSetor = jsonData['idSetor'];
    numeroNb = jsonData['numeroNb'];
    nome = jsonData['nome'];
    descricao = jsonData['descricao'];
    numeroSerie = jsonData['numeroSerie'];
    dataAquisicao = jsonData['dataAquisicao'] != null ? DateTime.tryParse(jsonData['dataAquisicao']) : null;
    dataAceite = jsonData['dataAceite'] != null ? DateTime.tryParse(jsonData['dataAceite']) : null;
    dataCadastro = jsonData['dataCadastro'] != null ? DateTime.tryParse(jsonData['dataCadastro']) : null;
    dataContabilizado = jsonData['dataContabilizado'] != null ? DateTime.tryParse(jsonData['dataContabilizado']) : null;
    dataVistoria = jsonData['dataVistoria'] != null ? DateTime.tryParse(jsonData['dataVistoria']) : null;
    dataMarcacao = jsonData['dataMarcacao'] != null ? DateTime.tryParse(jsonData['dataMarcacao']) : null;
    dataBaixa = jsonData['dataBaixa'] != null ? DateTime.tryParse(jsonData['dataBaixa']) : null;
    vencimentoGarantia = jsonData['vencimentoGarantia'] != null ? DateTime.tryParse(jsonData['vencimentoGarantia']) : null;
    numeroNotaFiscal = jsonData['numeroNotaFiscal'];
    chaveNfe = jsonData['chaveNfe'];
    valorOriginal = jsonData['valorOriginal']?.toDouble();
    valorCompra = jsonData['valorCompra']?.toDouble();
    valorAtualizado = jsonData['valorAtualizado']?.toDouble();
    valorBaixa = jsonData['valorBaixa']?.toDouble();
    deprecia = PatrimBemDomain.getDeprecia(jsonData['deprecia']);
    metodoDepreciacao = PatrimBemDomain.getMetodoDepreciacao(jsonData['metodoDepreciacao']);
    inicioDepreciacao = jsonData['inicioDepreciacao'] != null ? DateTime.tryParse(jsonData['inicioDepreciacao']) : null;
    ultimaDepreciacao = jsonData['ultimaDepreciacao'] != null ? DateTime.tryParse(jsonData['ultimaDepreciacao']) : null;
    tipoDepreciacao = PatrimBemDomain.getTipoDepreciacao(jsonData['tipoDepreciacao']);
    taxaAnualDepreciacao = jsonData['taxaAnualDepreciacao']?.toDouble();
    taxaMensalDepreciacao = jsonData['taxaMensalDepreciacao']?.toDouble();
    taxaDepreciacaoAcelerada = jsonData['taxaDepreciacaoAcelerada']?.toDouble();
    taxaDepreciacaoIncentivada = jsonData['taxaDepreciacaoIncentivada']?.toDouble();
    funcao = jsonData['funcao'];
  }

  Map<String, dynamic> get toJson {
    Map<String, dynamic> jsonData = <String, dynamic>{};

    jsonData['id'] = id != 0 ? id : null;
    jsonData['idCentroResultado'] = idCentroResultado;
    jsonData['idPatrimTipoAquisicaoBem'] = idPatrimTipoAquisicaoBem;
    jsonData['idPatrimEstadoConservacao'] = idPatrimEstadoConservacao;
    jsonData['idPatrimGrupoBem'] = idPatrimGrupoBem;
    jsonData['idFornecedor'] = idFornecedor;
    jsonData['idSetor'] = idSetor;
    jsonData['numeroNb'] = numeroNb;
    jsonData['nome'] = nome;
    jsonData['descricao'] = descricao;
    jsonData['numeroSerie'] = numeroSerie;
    jsonData['dataAquisicao'] = dataAquisicao != null ? DateFormat('yyyy-MM-ddT00:00:00').format(dataAquisicao!) : null;
    jsonData['dataAceite'] = dataAceite != null ? DateFormat('yyyy-MM-ddT00:00:00').format(dataAceite!) : null;
    jsonData['dataCadastro'] = dataCadastro != null ? DateFormat('yyyy-MM-ddT00:00:00').format(dataCadastro!) : null;
    jsonData['dataContabilizado'] = dataContabilizado != null ? DateFormat('yyyy-MM-ddT00:00:00').format(dataContabilizado!) : null;
    jsonData['dataVistoria'] = dataVistoria != null ? DateFormat('yyyy-MM-ddT00:00:00').format(dataVistoria!) : null;
    jsonData['dataMarcacao'] = dataMarcacao != null ? DateFormat('yyyy-MM-ddT00:00:00').format(dataMarcacao!) : null;
    jsonData['dataBaixa'] = dataBaixa != null ? DateFormat('yyyy-MM-ddT00:00:00').format(dataBaixa!) : null;
    jsonData['vencimentoGarantia'] = vencimentoGarantia != null ? DateFormat('yyyy-MM-ddT00:00:00').format(vencimentoGarantia!) : null;
    jsonData['numeroNotaFiscal'] = numeroNotaFiscal;
    jsonData['chaveNfe'] = chaveNfe;
    jsonData['valorOriginal'] = valorOriginal;
    jsonData['valorCompra'] = valorCompra;
    jsonData['valorAtualizado'] = valorAtualizado;
    jsonData['valorBaixa'] = valorBaixa;
    jsonData['deprecia'] = PatrimBemDomain.setDeprecia(deprecia);
    jsonData['metodoDepreciacao'] = PatrimBemDomain.setMetodoDepreciacao(metodoDepreciacao);
    jsonData['inicioDepreciacao'] = inicioDepreciacao != null ? DateFormat('yyyy-MM-ddT00:00:00').format(inicioDepreciacao!) : null;
    jsonData['ultimaDepreciacao'] = ultimaDepreciacao != null ? DateFormat('yyyy-MM-ddT00:00:00').format(ultimaDepreciacao!) : null;
    jsonData['tipoDepreciacao'] = PatrimBemDomain.setTipoDepreciacao(tipoDepreciacao);
    jsonData['taxaAnualDepreciacao'] = taxaAnualDepreciacao;
    jsonData['taxaMensalDepreciacao'] = taxaMensalDepreciacao;
    jsonData['taxaDepreciacaoAcelerada'] = taxaDepreciacaoAcelerada;
    jsonData['taxaDepreciacaoIncentivada'] = taxaDepreciacaoIncentivada;
    jsonData['funcao'] = funcao;

    return jsonData;
  }

  String objectEncodeJson() {
    final jsonData = toJson;
    return json.encode(jsonData);
  }

  static PatrimBemModel fromPlutoRow(PlutoRow row) {
    return PatrimBemModel(
      id: row.cells['id']?.value,
      idCentroResultado: row.cells['idCentroResultado']?.value,
      idPatrimTipoAquisicaoBem: row.cells['idPatrimTipoAquisicaoBem']?.value,
      idPatrimEstadoConservacao: row.cells['idPatrimEstadoConservacao']?.value,
      idPatrimGrupoBem: row.cells['idPatrimGrupoBem']?.value,
      idFornecedor: row.cells['idFornecedor']?.value,
      idSetor: row.cells['idSetor']?.value,
      numeroNb: row.cells['numeroNb']?.value,
      nome: row.cells['nome']?.value,
      descricao: row.cells['descricao']?.value,
      numeroSerie: row.cells['numeroSerie']?.value,
      dataAquisicao: Util.stringToDate(row.cells['dataAquisicao']?.value),
      dataAceite: Util.stringToDate(row.cells['dataAceite']?.value),
      dataCadastro: Util.stringToDate(row.cells['dataCadastro']?.value),
      dataContabilizado: Util.stringToDate(row.cells['dataContabilizado']?.value),
      dataVistoria: Util.stringToDate(row.cells['dataVistoria']?.value),
      dataMarcacao: Util.stringToDate(row.cells['dataMarcacao']?.value),
      dataBaixa: Util.stringToDate(row.cells['dataBaixa']?.value),
      vencimentoGarantia: Util.stringToDate(row.cells['vencimentoGarantia']?.value),
      numeroNotaFiscal: row.cells['numeroNotaFiscal']?.value,
      chaveNfe: row.cells['chaveNfe']?.value,
      valorOriginal: row.cells['valorOriginal']?.value,
      valorCompra: row.cells['valorCompra']?.value,
      valorAtualizado: row.cells['valorAtualizado']?.value,
      valorBaixa: row.cells['valorBaixa']?.value,
      deprecia: row.cells['deprecia']?.value,
      metodoDepreciacao: row.cells['metodoDepreciacao']?.value,
      inicioDepreciacao: Util.stringToDate(row.cells['inicioDepreciacao']?.value),
      ultimaDepreciacao: Util.stringToDate(row.cells['ultimaDepreciacao']?.value),
      tipoDepreciacao: row.cells['tipoDepreciacao']?.value,
      taxaAnualDepreciacao: row.cells['taxaAnualDepreciacao']?.value,
      taxaMensalDepreciacao: row.cells['taxaMensalDepreciacao']?.value,
      taxaDepreciacaoAcelerada: row.cells['taxaDepreciacaoAcelerada']?.value,
      taxaDepreciacaoIncentivada: row.cells['taxaDepreciacaoIncentivada']?.value,
      funcao: row.cells['funcao']?.value,
    );
  }

  PlutoRow toPlutoRow() {
    return PlutoRow(
      cells: {
        'tempId': PlutoCell(value: tempId),
        'id': PlutoCell(value: id ?? 0),
        'idCentroResultado': PlutoCell(value: idCentroResultado ?? 0),
        'idPatrimTipoAquisicaoBem': PlutoCell(value: idPatrimTipoAquisicaoBem ?? 0),
        'idPatrimEstadoConservacao': PlutoCell(value: idPatrimEstadoConservacao ?? 0),
        'idPatrimGrupoBem': PlutoCell(value: idPatrimGrupoBem ?? 0),
        'idFornecedor': PlutoCell(value: idFornecedor ?? 0),
        'idSetor': PlutoCell(value: idSetor ?? 0),
        'numeroNb': PlutoCell(value: numeroNb ?? ''),
        'nome': PlutoCell(value: nome ?? ''),
        'descricao': PlutoCell(value: descricao ?? ''),
        'numeroSerie': PlutoCell(value: numeroSerie ?? ''),
        'dataAquisicao': PlutoCell(value: dataAquisicao),
        'dataAceite': PlutoCell(value: dataAceite),
        'dataCadastro': PlutoCell(value: dataCadastro),
        'dataContabilizado': PlutoCell(value: dataContabilizado),
        'dataVistoria': PlutoCell(value: dataVistoria),
        'dataMarcacao': PlutoCell(value: dataMarcacao),
        'dataBaixa': PlutoCell(value: dataBaixa),
        'vencimentoGarantia': PlutoCell(value: vencimentoGarantia),
        'numeroNotaFiscal': PlutoCell(value: numeroNotaFiscal ?? ''),
        'chaveNfe': PlutoCell(value: chaveNfe ?? ''),
        'valorOriginal': PlutoCell(value: valorOriginal ?? 0.0),
        'valorCompra': PlutoCell(value: valorCompra ?? 0.0),
        'valorAtualizado': PlutoCell(value: valorAtualizado ?? 0.0),
        'valorBaixa': PlutoCell(value: valorBaixa ?? 0.0),
        'deprecia': PlutoCell(value: deprecia ?? ''),
        'metodoDepreciacao': PlutoCell(value: metodoDepreciacao ?? ''),
        'inicioDepreciacao': PlutoCell(value: inicioDepreciacao),
        'ultimaDepreciacao': PlutoCell(value: ultimaDepreciacao),
        'tipoDepreciacao': PlutoCell(value: tipoDepreciacao ?? ''),
        'taxaAnualDepreciacao': PlutoCell(value: taxaAnualDepreciacao ?? 0.0),
        'taxaMensalDepreciacao': PlutoCell(value: taxaMensalDepreciacao ?? 0.0),
        'taxaDepreciacaoAcelerada': PlutoCell(value: taxaDepreciacaoAcelerada ?? 0.0),
        'taxaDepreciacaoIncentivada': PlutoCell(value: taxaDepreciacaoIncentivada ?? 0.0),
        'funcao': PlutoCell(value: funcao ?? ''),
      },
    );
  }

  PatrimBemModel clone() {
    return PatrimBemModel(
      id: id,
      idCentroResultado: idCentroResultado,
      idPatrimTipoAquisicaoBem: idPatrimTipoAquisicaoBem,
      idPatrimEstadoConservacao: idPatrimEstadoConservacao,
      idPatrimGrupoBem: idPatrimGrupoBem,
      idFornecedor: idFornecedor,
      idSetor: idSetor,
      numeroNb: numeroNb,
      nome: nome,
      descricao: descricao,
      numeroSerie: numeroSerie,
      dataAquisicao: dataAquisicao,
      dataAceite: dataAceite,
      dataCadastro: dataCadastro,
      dataContabilizado: dataContabilizado,
      dataVistoria: dataVistoria,
      dataMarcacao: dataMarcacao,
      dataBaixa: dataBaixa,
      vencimentoGarantia: vencimentoGarantia,
      numeroNotaFiscal: numeroNotaFiscal,
      chaveNfe: chaveNfe,
      valorOriginal: valorOriginal,
      valorCompra: valorCompra,
      valorAtualizado: valorAtualizado,
      valorBaixa: valorBaixa,
      deprecia: deprecia,
      metodoDepreciacao: metodoDepreciacao,
      inicioDepreciacao: inicioDepreciacao,
      ultimaDepreciacao: ultimaDepreciacao,
      tipoDepreciacao: tipoDepreciacao,
      taxaAnualDepreciacao: taxaAnualDepreciacao,
      taxaMensalDepreciacao: taxaMensalDepreciacao,
      taxaDepreciacaoAcelerada: taxaDepreciacaoAcelerada,
      taxaDepreciacaoIncentivada: taxaDepreciacaoIncentivada,
      funcao: funcao,
    );
  }


}