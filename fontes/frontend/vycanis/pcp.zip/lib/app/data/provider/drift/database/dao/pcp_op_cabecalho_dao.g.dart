// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'pcp_op_cabecalho_dao.dart';

// ignore_for_file: type=lint
mixin _$PcpOpCabecalhoDaoMixin on DatabaseAccessor<AppDatabase> {
  $PcpOpCabecalhosTable get pcpOpCabecalhos => attachedDatabase.pcpOpCabecalhos;
  $PcpOpDetalhesTable get pcpOpDetalhes => attachedDatabase.pcpOpDetalhes;
  $ProdutosTable get produtos => attachedDatabase.produtos;
  $PcpInstrucaoOpsTable get pcpInstrucaoOps => attachedDatabase.pcpInstrucaoOps;
  $PcpInstrucaosTable get pcpInstrucaos => attachedDatabase.pcpInstrucaos;
}
