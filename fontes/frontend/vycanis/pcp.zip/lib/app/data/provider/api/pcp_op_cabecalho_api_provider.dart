import 'package:pcp/app/data/provider/api/api_provider_base.dart';
import 'package:pcp/app/data/model/model_imports.dart';

class PcpOpCabecalhoApiProvider extends ApiProviderBase {
  static const _path = '/pcp-op-cabecalho';

  Future<List<PcpOpCabecalhoModel>?> getList({Filter? filter}) {
    return super.getListBase(
      '$_path/',
      (json) => PcpOpCabecalhoModel.fromJson(json),
      filter: filter,
    );
  }

  Future<PcpOpCabecalhoModel?> getObject(dynamic pk) {
    return super.getObjectBase(
      _path,
      pk,
      (json) => PcpOpCabecalhoModel.fromJson(json),
    );
  }

  Future<PcpOpCabecalhoModel?>? insert(PcpOpCabecalhoModel model) {
    return super.insertBase(
      _path,
      model,
      (json) => PcpOpCabecalhoModel.fromJson(json),
    );
  }

  Future<PcpOpCabecalhoModel?>? update(PcpOpCabecalhoModel model) {
    return super.updateBase(
      _path,
      model,
      (json) => PcpOpCabecalhoModel.fromJson(json),
    );
  }

  Future<bool?> delete(dynamic pk) {
    return super.deleteBase(_path, pk);
  }
}
