// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'pcp_instrucao_dao.dart';

// ignore_for_file: type=lint
mixin _$PcpInstrucaoDaoMixin on DatabaseAccessor<AppDatabase> {
  $PcpInstrucaosTable get pcpInstrucaos => attachedDatabase.pcpInstrucaos;
}
