import 'package:pcp/app/data/provider/api/api_provider_base.dart';
import 'package:pcp/app/data/model/model_imports.dart';

class PcpInstrucaoApiProvider extends ApiProviderBase {
  static const _path = '/pcp-instrucao';

  Future<List<PcpInstrucaoModel>?> getList({Filter? filter}) {
    return super.getListBase(
      '$_path/',
      (json) => PcpInstrucaoModel.fromJson(json),
      filter: filter,
    );
  }

  Future<PcpInstrucaoModel?> getObject(dynamic pk) {
    return super.getObjectBase(
      _path,
      pk,
      (json) => PcpInstrucaoModel.fromJson(json),
    );
  }

  Future<PcpInstrucaoModel?>? insert(PcpInstrucaoModel model) {
    return super.insertBase(
      _path,
      model,
      (json) => PcpInstrucaoModel.fromJson(json),
    );
  }

  Future<PcpInstrucaoModel?>? update(PcpInstrucaoModel model) {
    return super.updateBase(
      _path,
      model,
      (json) => PcpInstrucaoModel.fromJson(json),
    );
  }

  Future<bool?> delete(dynamic pk) {
    return super.deleteBase(_path, pk);
  }
}
