// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'pcp_servico_dao.dart';

// ignore_for_file: type=lint
mixin _$PcpServicoDaoMixin on DatabaseAccessor<AppDatabase> {
  $PcpServicosTable get pcpServicos => attachedDatabase.pcpServicos;
  $PcpServicoColaboradorsTable get pcpServicoColaboradors =>
      attachedDatabase.pcpServicoColaboradors;
  $ViewPessoaColaboradorsTable get viewPessoaColaboradors =>
      attachedDatabase.viewPessoaColaboradors;
  $PcpServicoEquipamentosTable get pcpServicoEquipamentos =>
      attachedDatabase.pcpServicoEquipamentos;
  $PatrimBemsTable get patrimBems => attachedDatabase.patrimBems;
  $PcpOpDetalhesTable get pcpOpDetalhes => attachedDatabase.pcpOpDetalhes;
}
