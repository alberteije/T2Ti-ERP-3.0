// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'database.dart';

// ignore_for_file: type=lint
class $PcpOpDetalhesTable extends PcpOpDetalhes
    with TableInfo<$PcpOpDetalhesTable, PcpOpDetalhe> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $PcpOpDetalhesTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
    'id',
    aliasedName,
    true,
    type: DriftSqlType.int,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _idPcpOpCabecalhoMeta = const VerificationMeta(
    'idPcpOpCabecalho',
  );
  @override
  late final GeneratedColumn<int> idPcpOpCabecalho = GeneratedColumn<int>(
    'id_pcp_op_cabecalho',
    aliasedName,
    true,
    type: DriftSqlType.int,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _idProdutoMeta = const VerificationMeta(
    'idProduto',
  );
  @override
  late final GeneratedColumn<int> idProduto = GeneratedColumn<int>(
    'id_produto',
    aliasedName,
    true,
    type: DriftSqlType.int,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _quantidadeProduzirMeta =
      const VerificationMeta('quantidadeProduzir');
  @override
  late final GeneratedColumn<double> quantidadeProduzir =
      GeneratedColumn<double>(
        'quantidade_produzir',
        aliasedName,
        true,
        type: DriftSqlType.double,
        requiredDuringInsert: false,
      );
  static const VerificationMeta _quantidadeProduzidaMeta =
      const VerificationMeta('quantidadeProduzida');
  @override
  late final GeneratedColumn<double> quantidadeProduzida =
      GeneratedColumn<double>(
        'quantidade_produzida',
        aliasedName,
        true,
        type: DriftSqlType.double,
        requiredDuringInsert: false,
      );
  static const VerificationMeta _quantidadeEntregueMeta =
      const VerificationMeta('quantidadeEntregue');
  @override
  late final GeneratedColumn<double> quantidadeEntregue =
      GeneratedColumn<double>(
        'quantidade_entregue',
        aliasedName,
        true,
        type: DriftSqlType.double,
        requiredDuringInsert: false,
      );
  static const VerificationMeta _custoPrevistoMeta = const VerificationMeta(
    'custoPrevisto',
  );
  @override
  late final GeneratedColumn<double> custoPrevisto = GeneratedColumn<double>(
    'custo_previsto',
    aliasedName,
    true,
    type: DriftSqlType.double,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _custoRealizadoMeta = const VerificationMeta(
    'custoRealizado',
  );
  @override
  late final GeneratedColumn<double> custoRealizado = GeneratedColumn<double>(
    'custo_realizado',
    aliasedName,
    true,
    type: DriftSqlType.double,
    requiredDuringInsert: false,
  );
  @override
  List<GeneratedColumn> get $columns => [
    id,
    idPcpOpCabecalho,
    idProduto,
    quantidadeProduzir,
    quantidadeProduzida,
    quantidadeEntregue,
    custoPrevisto,
    custoRealizado,
  ];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'pcp_op_detalhe';
  @override
  VerificationContext validateIntegrity(
    Insertable<PcpOpDetalhe> instance, {
    bool isInserting = false,
  }) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('id_pcp_op_cabecalho')) {
      context.handle(
        _idPcpOpCabecalhoMeta,
        idPcpOpCabecalho.isAcceptableOrUnknown(
          data['id_pcp_op_cabecalho']!,
          _idPcpOpCabecalhoMeta,
        ),
      );
    }
    if (data.containsKey('id_produto')) {
      context.handle(
        _idProdutoMeta,
        idProduto.isAcceptableOrUnknown(data['id_produto']!, _idProdutoMeta),
      );
    }
    if (data.containsKey('quantidade_produzir')) {
      context.handle(
        _quantidadeProduzirMeta,
        quantidadeProduzir.isAcceptableOrUnknown(
          data['quantidade_produzir']!,
          _quantidadeProduzirMeta,
        ),
      );
    }
    if (data.containsKey('quantidade_produzida')) {
      context.handle(
        _quantidadeProduzidaMeta,
        quantidadeProduzida.isAcceptableOrUnknown(
          data['quantidade_produzida']!,
          _quantidadeProduzidaMeta,
        ),
      );
    }
    if (data.containsKey('quantidade_entregue')) {
      context.handle(
        _quantidadeEntregueMeta,
        quantidadeEntregue.isAcceptableOrUnknown(
          data['quantidade_entregue']!,
          _quantidadeEntregueMeta,
        ),
      );
    }
    if (data.containsKey('custo_previsto')) {
      context.handle(
        _custoPrevistoMeta,
        custoPrevisto.isAcceptableOrUnknown(
          data['custo_previsto']!,
          _custoPrevistoMeta,
        ),
      );
    }
    if (data.containsKey('custo_realizado')) {
      context.handle(
        _custoRealizadoMeta,
        custoRealizado.isAcceptableOrUnknown(
          data['custo_realizado']!,
          _custoRealizadoMeta,
        ),
      );
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  PcpOpDetalhe map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return PcpOpDetalhe(
      id: attachedDatabase.typeMapping.read(
        DriftSqlType.int,
        data['${effectivePrefix}id'],
      ),
      idPcpOpCabecalho: attachedDatabase.typeMapping.read(
        DriftSqlType.int,
        data['${effectivePrefix}id_pcp_op_cabecalho'],
      ),
      idProduto: attachedDatabase.typeMapping.read(
        DriftSqlType.int,
        data['${effectivePrefix}id_produto'],
      ),
      quantidadeProduzir: attachedDatabase.typeMapping.read(
        DriftSqlType.double,
        data['${effectivePrefix}quantidade_produzir'],
      ),
      quantidadeProduzida: attachedDatabase.typeMapping.read(
        DriftSqlType.double,
        data['${effectivePrefix}quantidade_produzida'],
      ),
      quantidadeEntregue: attachedDatabase.typeMapping.read(
        DriftSqlType.double,
        data['${effectivePrefix}quantidade_entregue'],
      ),
      custoPrevisto: attachedDatabase.typeMapping.read(
        DriftSqlType.double,
        data['${effectivePrefix}custo_previsto'],
      ),
      custoRealizado: attachedDatabase.typeMapping.read(
        DriftSqlType.double,
        data['${effectivePrefix}custo_realizado'],
      ),
    );
  }

  @override
  $PcpOpDetalhesTable createAlias(String alias) {
    return $PcpOpDetalhesTable(attachedDatabase, alias);
  }
}

class PcpOpDetalhe extends DataClass implements Insertable<PcpOpDetalhe> {
  final int? id;
  final int? idPcpOpCabecalho;
  final int? idProduto;
  final double? quantidadeProduzir;
  final double? quantidadeProduzida;
  final double? quantidadeEntregue;
  final double? custoPrevisto;
  final double? custoRealizado;
  const PcpOpDetalhe({
    this.id,
    this.idPcpOpCabecalho,
    this.idProduto,
    this.quantidadeProduzir,
    this.quantidadeProduzida,
    this.quantidadeEntregue,
    this.custoPrevisto,
    this.custoRealizado,
  });
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || idPcpOpCabecalho != null) {
      map['id_pcp_op_cabecalho'] = Variable<int>(idPcpOpCabecalho);
    }
    if (!nullToAbsent || idProduto != null) {
      map['id_produto'] = Variable<int>(idProduto);
    }
    if (!nullToAbsent || quantidadeProduzir != null) {
      map['quantidade_produzir'] = Variable<double>(quantidadeProduzir);
    }
    if (!nullToAbsent || quantidadeProduzida != null) {
      map['quantidade_produzida'] = Variable<double>(quantidadeProduzida);
    }
    if (!nullToAbsent || quantidadeEntregue != null) {
      map['quantidade_entregue'] = Variable<double>(quantidadeEntregue);
    }
    if (!nullToAbsent || custoPrevisto != null) {
      map['custo_previsto'] = Variable<double>(custoPrevisto);
    }
    if (!nullToAbsent || custoRealizado != null) {
      map['custo_realizado'] = Variable<double>(custoRealizado);
    }
    return map;
  }

  factory PcpOpDetalhe.fromJson(
    Map<String, dynamic> json, {
    ValueSerializer? serializer,
  }) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return PcpOpDetalhe(
      id: serializer.fromJson<int?>(json['id']),
      idPcpOpCabecalho: serializer.fromJson<int?>(json['idPcpOpCabecalho']),
      idProduto: serializer.fromJson<int?>(json['idProduto']),
      quantidadeProduzir: serializer.fromJson<double?>(
        json['quantidadeProduzir'],
      ),
      quantidadeProduzida: serializer.fromJson<double?>(
        json['quantidadeProduzida'],
      ),
      quantidadeEntregue: serializer.fromJson<double?>(
        json['quantidadeEntregue'],
      ),
      custoPrevisto: serializer.fromJson<double?>(json['custoPrevisto']),
      custoRealizado: serializer.fromJson<double?>(json['custoRealizado']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'idPcpOpCabecalho': serializer.toJson<int?>(idPcpOpCabecalho),
      'idProduto': serializer.toJson<int?>(idProduto),
      'quantidadeProduzir': serializer.toJson<double?>(quantidadeProduzir),
      'quantidadeProduzida': serializer.toJson<double?>(quantidadeProduzida),
      'quantidadeEntregue': serializer.toJson<double?>(quantidadeEntregue),
      'custoPrevisto': serializer.toJson<double?>(custoPrevisto),
      'custoRealizado': serializer.toJson<double?>(custoRealizado),
    };
  }

  PcpOpDetalhe copyWith({
    Value<int?> id = const Value.absent(),
    Value<int?> idPcpOpCabecalho = const Value.absent(),
    Value<int?> idProduto = const Value.absent(),
    Value<double?> quantidadeProduzir = const Value.absent(),
    Value<double?> quantidadeProduzida = const Value.absent(),
    Value<double?> quantidadeEntregue = const Value.absent(),
    Value<double?> custoPrevisto = const Value.absent(),
    Value<double?> custoRealizado = const Value.absent(),
  }) => PcpOpDetalhe(
    id: id.present ? id.value : this.id,
    idPcpOpCabecalho:
        idPcpOpCabecalho.present
            ? idPcpOpCabecalho.value
            : this.idPcpOpCabecalho,
    idProduto: idProduto.present ? idProduto.value : this.idProduto,
    quantidadeProduzir:
        quantidadeProduzir.present
            ? quantidadeProduzir.value
            : this.quantidadeProduzir,
    quantidadeProduzida:
        quantidadeProduzida.present
            ? quantidadeProduzida.value
            : this.quantidadeProduzida,
    quantidadeEntregue:
        quantidadeEntregue.present
            ? quantidadeEntregue.value
            : this.quantidadeEntregue,
    custoPrevisto:
        custoPrevisto.present ? custoPrevisto.value : this.custoPrevisto,
    custoRealizado:
        custoRealizado.present ? custoRealizado.value : this.custoRealizado,
  );
  PcpOpDetalhe copyWithCompanion(PcpOpDetalhesCompanion data) {
    return PcpOpDetalhe(
      id: data.id.present ? data.id.value : this.id,
      idPcpOpCabecalho:
          data.idPcpOpCabecalho.present
              ? data.idPcpOpCabecalho.value
              : this.idPcpOpCabecalho,
      idProduto: data.idProduto.present ? data.idProduto.value : this.idProduto,
      quantidadeProduzir:
          data.quantidadeProduzir.present
              ? data.quantidadeProduzir.value
              : this.quantidadeProduzir,
      quantidadeProduzida:
          data.quantidadeProduzida.present
              ? data.quantidadeProduzida.value
              : this.quantidadeProduzida,
      quantidadeEntregue:
          data.quantidadeEntregue.present
              ? data.quantidadeEntregue.value
              : this.quantidadeEntregue,
      custoPrevisto:
          data.custoPrevisto.present
              ? data.custoPrevisto.value
              : this.custoPrevisto,
      custoRealizado:
          data.custoRealizado.present
              ? data.custoRealizado.value
              : this.custoRealizado,
    );
  }

  @override
  String toString() {
    return (StringBuffer('PcpOpDetalhe(')
          ..write('id: $id, ')
          ..write('idPcpOpCabecalho: $idPcpOpCabecalho, ')
          ..write('idProduto: $idProduto, ')
          ..write('quantidadeProduzir: $quantidadeProduzir, ')
          ..write('quantidadeProduzida: $quantidadeProduzida, ')
          ..write('quantidadeEntregue: $quantidadeEntregue, ')
          ..write('custoPrevisto: $custoPrevisto, ')
          ..write('custoRealizado: $custoRealizado')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(
    id,
    idPcpOpCabecalho,
    idProduto,
    quantidadeProduzir,
    quantidadeProduzida,
    quantidadeEntregue,
    custoPrevisto,
    custoRealizado,
  );
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is PcpOpDetalhe &&
          other.id == this.id &&
          other.idPcpOpCabecalho == this.idPcpOpCabecalho &&
          other.idProduto == this.idProduto &&
          other.quantidadeProduzir == this.quantidadeProduzir &&
          other.quantidadeProduzida == this.quantidadeProduzida &&
          other.quantidadeEntregue == this.quantidadeEntregue &&
          other.custoPrevisto == this.custoPrevisto &&
          other.custoRealizado == this.custoRealizado);
}

class PcpOpDetalhesCompanion extends UpdateCompanion<PcpOpDetalhe> {
  final Value<int?> id;
  final Value<int?> idPcpOpCabecalho;
  final Value<int?> idProduto;
  final Value<double?> quantidadeProduzir;
  final Value<double?> quantidadeProduzida;
  final Value<double?> quantidadeEntregue;
  final Value<double?> custoPrevisto;
  final Value<double?> custoRealizado;
  const PcpOpDetalhesCompanion({
    this.id = const Value.absent(),
    this.idPcpOpCabecalho = const Value.absent(),
    this.idProduto = const Value.absent(),
    this.quantidadeProduzir = const Value.absent(),
    this.quantidadeProduzida = const Value.absent(),
    this.quantidadeEntregue = const Value.absent(),
    this.custoPrevisto = const Value.absent(),
    this.custoRealizado = const Value.absent(),
  });
  PcpOpDetalhesCompanion.insert({
    this.id = const Value.absent(),
    this.idPcpOpCabecalho = const Value.absent(),
    this.idProduto = const Value.absent(),
    this.quantidadeProduzir = const Value.absent(),
    this.quantidadeProduzida = const Value.absent(),
    this.quantidadeEntregue = const Value.absent(),
    this.custoPrevisto = const Value.absent(),
    this.custoRealizado = const Value.absent(),
  });
  static Insertable<PcpOpDetalhe> custom({
    Expression<int>? id,
    Expression<int>? idPcpOpCabecalho,
    Expression<int>? idProduto,
    Expression<double>? quantidadeProduzir,
    Expression<double>? quantidadeProduzida,
    Expression<double>? quantidadeEntregue,
    Expression<double>? custoPrevisto,
    Expression<double>? custoRealizado,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (idPcpOpCabecalho != null) 'id_pcp_op_cabecalho': idPcpOpCabecalho,
      if (idProduto != null) 'id_produto': idProduto,
      if (quantidadeProduzir != null) 'quantidade_produzir': quantidadeProduzir,
      if (quantidadeProduzida != null)
        'quantidade_produzida': quantidadeProduzida,
      if (quantidadeEntregue != null) 'quantidade_entregue': quantidadeEntregue,
      if (custoPrevisto != null) 'custo_previsto': custoPrevisto,
      if (custoRealizado != null) 'custo_realizado': custoRealizado,
    });
  }

  PcpOpDetalhesCompanion copyWith({
    Value<int?>? id,
    Value<int?>? idPcpOpCabecalho,
    Value<int?>? idProduto,
    Value<double?>? quantidadeProduzir,
    Value<double?>? quantidadeProduzida,
    Value<double?>? quantidadeEntregue,
    Value<double?>? custoPrevisto,
    Value<double?>? custoRealizado,
  }) {
    return PcpOpDetalhesCompanion(
      id: id ?? this.id,
      idPcpOpCabecalho: idPcpOpCabecalho ?? this.idPcpOpCabecalho,
      idProduto: idProduto ?? this.idProduto,
      quantidadeProduzir: quantidadeProduzir ?? this.quantidadeProduzir,
      quantidadeProduzida: quantidadeProduzida ?? this.quantidadeProduzida,
      quantidadeEntregue: quantidadeEntregue ?? this.quantidadeEntregue,
      custoPrevisto: custoPrevisto ?? this.custoPrevisto,
      custoRealizado: custoRealizado ?? this.custoRealizado,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (idPcpOpCabecalho.present) {
      map['id_pcp_op_cabecalho'] = Variable<int>(idPcpOpCabecalho.value);
    }
    if (idProduto.present) {
      map['id_produto'] = Variable<int>(idProduto.value);
    }
    if (quantidadeProduzir.present) {
      map['quantidade_produzir'] = Variable<double>(quantidadeProduzir.value);
    }
    if (quantidadeProduzida.present) {
      map['quantidade_produzida'] = Variable<double>(quantidadeProduzida.value);
    }
    if (quantidadeEntregue.present) {
      map['quantidade_entregue'] = Variable<double>(quantidadeEntregue.value);
    }
    if (custoPrevisto.present) {
      map['custo_previsto'] = Variable<double>(custoPrevisto.value);
    }
    if (custoRealizado.present) {
      map['custo_realizado'] = Variable<double>(custoRealizado.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('PcpOpDetalhesCompanion(')
          ..write('id: $id, ')
          ..write('idPcpOpCabecalho: $idPcpOpCabecalho, ')
          ..write('idProduto: $idProduto, ')
          ..write('quantidadeProduzir: $quantidadeProduzir, ')
          ..write('quantidadeProduzida: $quantidadeProduzida, ')
          ..write('quantidadeEntregue: $quantidadeEntregue, ')
          ..write('custoPrevisto: $custoPrevisto, ')
          ..write('custoRealizado: $custoRealizado')
          ..write(')'))
        .toString();
  }
}

class $PcpServicoColaboradorsTable extends PcpServicoColaboradors
    with TableInfo<$PcpServicoColaboradorsTable, PcpServicoColaborador> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $PcpServicoColaboradorsTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
    'id',
    aliasedName,
    true,
    type: DriftSqlType.int,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _idColaboradorMeta = const VerificationMeta(
    'idColaborador',
  );
  @override
  late final GeneratedColumn<int> idColaborador = GeneratedColumn<int>(
    'id_colaborador',
    aliasedName,
    true,
    type: DriftSqlType.int,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _idPcpServicoMeta = const VerificationMeta(
    'idPcpServico',
  );
  @override
  late final GeneratedColumn<int> idPcpServico = GeneratedColumn<int>(
    'id_pcp_servico',
    aliasedName,
    true,
    type: DriftSqlType.int,
    requiredDuringInsert: false,
  );
  @override
  List<GeneratedColumn> get $columns => [id, idColaborador, idPcpServico];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'pcp_servico_colaborador';
  @override
  VerificationContext validateIntegrity(
    Insertable<PcpServicoColaborador> instance, {
    bool isInserting = false,
  }) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('id_colaborador')) {
      context.handle(
        _idColaboradorMeta,
        idColaborador.isAcceptableOrUnknown(
          data['id_colaborador']!,
          _idColaboradorMeta,
        ),
      );
    }
    if (data.containsKey('id_pcp_servico')) {
      context.handle(
        _idPcpServicoMeta,
        idPcpServico.isAcceptableOrUnknown(
          data['id_pcp_servico']!,
          _idPcpServicoMeta,
        ),
      );
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  PcpServicoColaborador map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return PcpServicoColaborador(
      id: attachedDatabase.typeMapping.read(
        DriftSqlType.int,
        data['${effectivePrefix}id'],
      ),
      idColaborador: attachedDatabase.typeMapping.read(
        DriftSqlType.int,
        data['${effectivePrefix}id_colaborador'],
      ),
      idPcpServico: attachedDatabase.typeMapping.read(
        DriftSqlType.int,
        data['${effectivePrefix}id_pcp_servico'],
      ),
    );
  }

  @override
  $PcpServicoColaboradorsTable createAlias(String alias) {
    return $PcpServicoColaboradorsTable(attachedDatabase, alias);
  }
}

class PcpServicoColaborador extends DataClass
    implements Insertable<PcpServicoColaborador> {
  final int? id;
  final int? idColaborador;
  final int? idPcpServico;
  const PcpServicoColaborador({this.id, this.idColaborador, this.idPcpServico});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || idColaborador != null) {
      map['id_colaborador'] = Variable<int>(idColaborador);
    }
    if (!nullToAbsent || idPcpServico != null) {
      map['id_pcp_servico'] = Variable<int>(idPcpServico);
    }
    return map;
  }

  factory PcpServicoColaborador.fromJson(
    Map<String, dynamic> json, {
    ValueSerializer? serializer,
  }) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return PcpServicoColaborador(
      id: serializer.fromJson<int?>(json['id']),
      idColaborador: serializer.fromJson<int?>(json['idColaborador']),
      idPcpServico: serializer.fromJson<int?>(json['idPcpServico']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'idColaborador': serializer.toJson<int?>(idColaborador),
      'idPcpServico': serializer.toJson<int?>(idPcpServico),
    };
  }

  PcpServicoColaborador copyWith({
    Value<int?> id = const Value.absent(),
    Value<int?> idColaborador = const Value.absent(),
    Value<int?> idPcpServico = const Value.absent(),
  }) => PcpServicoColaborador(
    id: id.present ? id.value : this.id,
    idColaborador:
        idColaborador.present ? idColaborador.value : this.idColaborador,
    idPcpServico: idPcpServico.present ? idPcpServico.value : this.idPcpServico,
  );
  PcpServicoColaborador copyWithCompanion(
    PcpServicoColaboradorsCompanion data,
  ) {
    return PcpServicoColaborador(
      id: data.id.present ? data.id.value : this.id,
      idColaborador:
          data.idColaborador.present
              ? data.idColaborador.value
              : this.idColaborador,
      idPcpServico:
          data.idPcpServico.present
              ? data.idPcpServico.value
              : this.idPcpServico,
    );
  }

  @override
  String toString() {
    return (StringBuffer('PcpServicoColaborador(')
          ..write('id: $id, ')
          ..write('idColaborador: $idColaborador, ')
          ..write('idPcpServico: $idPcpServico')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(id, idColaborador, idPcpServico);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is PcpServicoColaborador &&
          other.id == this.id &&
          other.idColaborador == this.idColaborador &&
          other.idPcpServico == this.idPcpServico);
}

class PcpServicoColaboradorsCompanion
    extends UpdateCompanion<PcpServicoColaborador> {
  final Value<int?> id;
  final Value<int?> idColaborador;
  final Value<int?> idPcpServico;
  const PcpServicoColaboradorsCompanion({
    this.id = const Value.absent(),
    this.idColaborador = const Value.absent(),
    this.idPcpServico = const Value.absent(),
  });
  PcpServicoColaboradorsCompanion.insert({
    this.id = const Value.absent(),
    this.idColaborador = const Value.absent(),
    this.idPcpServico = const Value.absent(),
  });
  static Insertable<PcpServicoColaborador> custom({
    Expression<int>? id,
    Expression<int>? idColaborador,
    Expression<int>? idPcpServico,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (idColaborador != null) 'id_colaborador': idColaborador,
      if (idPcpServico != null) 'id_pcp_servico': idPcpServico,
    });
  }

  PcpServicoColaboradorsCompanion copyWith({
    Value<int?>? id,
    Value<int?>? idColaborador,
    Value<int?>? idPcpServico,
  }) {
    return PcpServicoColaboradorsCompanion(
      id: id ?? this.id,
      idColaborador: idColaborador ?? this.idColaborador,
      idPcpServico: idPcpServico ?? this.idPcpServico,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (idColaborador.present) {
      map['id_colaborador'] = Variable<int>(idColaborador.value);
    }
    if (idPcpServico.present) {
      map['id_pcp_servico'] = Variable<int>(idPcpServico.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('PcpServicoColaboradorsCompanion(')
          ..write('id: $id, ')
          ..write('idColaborador: $idColaborador, ')
          ..write('idPcpServico: $idPcpServico')
          ..write(')'))
        .toString();
  }
}

class $PcpInstrucaoOpsTable extends PcpInstrucaoOps
    with TableInfo<$PcpInstrucaoOpsTable, PcpInstrucaoOp> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $PcpInstrucaoOpsTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
    'id',
    aliasedName,
    true,
    type: DriftSqlType.int,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _idPcpInstrucaoMeta = const VerificationMeta(
    'idPcpInstrucao',
  );
  @override
  late final GeneratedColumn<int> idPcpInstrucao = GeneratedColumn<int>(
    'id_pcp_instrucao',
    aliasedName,
    true,
    type: DriftSqlType.int,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _idPcpOpCabecalhoMeta = const VerificationMeta(
    'idPcpOpCabecalho',
  );
  @override
  late final GeneratedColumn<int> idPcpOpCabecalho = GeneratedColumn<int>(
    'id_pcp_op_cabecalho',
    aliasedName,
    true,
    type: DriftSqlType.int,
    requiredDuringInsert: false,
  );
  @override
  List<GeneratedColumn> get $columns => [id, idPcpInstrucao, idPcpOpCabecalho];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'pcp_instrucao_op';
  @override
  VerificationContext validateIntegrity(
    Insertable<PcpInstrucaoOp> instance, {
    bool isInserting = false,
  }) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('id_pcp_instrucao')) {
      context.handle(
        _idPcpInstrucaoMeta,
        idPcpInstrucao.isAcceptableOrUnknown(
          data['id_pcp_instrucao']!,
          _idPcpInstrucaoMeta,
        ),
      );
    }
    if (data.containsKey('id_pcp_op_cabecalho')) {
      context.handle(
        _idPcpOpCabecalhoMeta,
        idPcpOpCabecalho.isAcceptableOrUnknown(
          data['id_pcp_op_cabecalho']!,
          _idPcpOpCabecalhoMeta,
        ),
      );
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  PcpInstrucaoOp map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return PcpInstrucaoOp(
      id: attachedDatabase.typeMapping.read(
        DriftSqlType.int,
        data['${effectivePrefix}id'],
      ),
      idPcpInstrucao: attachedDatabase.typeMapping.read(
        DriftSqlType.int,
        data['${effectivePrefix}id_pcp_instrucao'],
      ),
      idPcpOpCabecalho: attachedDatabase.typeMapping.read(
        DriftSqlType.int,
        data['${effectivePrefix}id_pcp_op_cabecalho'],
      ),
    );
  }

  @override
  $PcpInstrucaoOpsTable createAlias(String alias) {
    return $PcpInstrucaoOpsTable(attachedDatabase, alias);
  }
}

class PcpInstrucaoOp extends DataClass implements Insertable<PcpInstrucaoOp> {
  final int? id;
  final int? idPcpInstrucao;
  final int? idPcpOpCabecalho;
  const PcpInstrucaoOp({this.id, this.idPcpInstrucao, this.idPcpOpCabecalho});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || idPcpInstrucao != null) {
      map['id_pcp_instrucao'] = Variable<int>(idPcpInstrucao);
    }
    if (!nullToAbsent || idPcpOpCabecalho != null) {
      map['id_pcp_op_cabecalho'] = Variable<int>(idPcpOpCabecalho);
    }
    return map;
  }

  factory PcpInstrucaoOp.fromJson(
    Map<String, dynamic> json, {
    ValueSerializer? serializer,
  }) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return PcpInstrucaoOp(
      id: serializer.fromJson<int?>(json['id']),
      idPcpInstrucao: serializer.fromJson<int?>(json['idPcpInstrucao']),
      idPcpOpCabecalho: serializer.fromJson<int?>(json['idPcpOpCabecalho']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'idPcpInstrucao': serializer.toJson<int?>(idPcpInstrucao),
      'idPcpOpCabecalho': serializer.toJson<int?>(idPcpOpCabecalho),
    };
  }

  PcpInstrucaoOp copyWith({
    Value<int?> id = const Value.absent(),
    Value<int?> idPcpInstrucao = const Value.absent(),
    Value<int?> idPcpOpCabecalho = const Value.absent(),
  }) => PcpInstrucaoOp(
    id: id.present ? id.value : this.id,
    idPcpInstrucao:
        idPcpInstrucao.present ? idPcpInstrucao.value : this.idPcpInstrucao,
    idPcpOpCabecalho:
        idPcpOpCabecalho.present
            ? idPcpOpCabecalho.value
            : this.idPcpOpCabecalho,
  );
  PcpInstrucaoOp copyWithCompanion(PcpInstrucaoOpsCompanion data) {
    return PcpInstrucaoOp(
      id: data.id.present ? data.id.value : this.id,
      idPcpInstrucao:
          data.idPcpInstrucao.present
              ? data.idPcpInstrucao.value
              : this.idPcpInstrucao,
      idPcpOpCabecalho:
          data.idPcpOpCabecalho.present
              ? data.idPcpOpCabecalho.value
              : this.idPcpOpCabecalho,
    );
  }

  @override
  String toString() {
    return (StringBuffer('PcpInstrucaoOp(')
          ..write('id: $id, ')
          ..write('idPcpInstrucao: $idPcpInstrucao, ')
          ..write('idPcpOpCabecalho: $idPcpOpCabecalho')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(id, idPcpInstrucao, idPcpOpCabecalho);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is PcpInstrucaoOp &&
          other.id == this.id &&
          other.idPcpInstrucao == this.idPcpInstrucao &&
          other.idPcpOpCabecalho == this.idPcpOpCabecalho);
}

class PcpInstrucaoOpsCompanion extends UpdateCompanion<PcpInstrucaoOp> {
  final Value<int?> id;
  final Value<int?> idPcpInstrucao;
  final Value<int?> idPcpOpCabecalho;
  const PcpInstrucaoOpsCompanion({
    this.id = const Value.absent(),
    this.idPcpInstrucao = const Value.absent(),
    this.idPcpOpCabecalho = const Value.absent(),
  });
  PcpInstrucaoOpsCompanion.insert({
    this.id = const Value.absent(),
    this.idPcpInstrucao = const Value.absent(),
    this.idPcpOpCabecalho = const Value.absent(),
  });
  static Insertable<PcpInstrucaoOp> custom({
    Expression<int>? id,
    Expression<int>? idPcpInstrucao,
    Expression<int>? idPcpOpCabecalho,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (idPcpInstrucao != null) 'id_pcp_instrucao': idPcpInstrucao,
      if (idPcpOpCabecalho != null) 'id_pcp_op_cabecalho': idPcpOpCabecalho,
    });
  }

  PcpInstrucaoOpsCompanion copyWith({
    Value<int?>? id,
    Value<int?>? idPcpInstrucao,
    Value<int?>? idPcpOpCabecalho,
  }) {
    return PcpInstrucaoOpsCompanion(
      id: id ?? this.id,
      idPcpInstrucao: idPcpInstrucao ?? this.idPcpInstrucao,
      idPcpOpCabecalho: idPcpOpCabecalho ?? this.idPcpOpCabecalho,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (idPcpInstrucao.present) {
      map['id_pcp_instrucao'] = Variable<int>(idPcpInstrucao.value);
    }
    if (idPcpOpCabecalho.present) {
      map['id_pcp_op_cabecalho'] = Variable<int>(idPcpOpCabecalho.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('PcpInstrucaoOpsCompanion(')
          ..write('id: $id, ')
          ..write('idPcpInstrucao: $idPcpInstrucao, ')
          ..write('idPcpOpCabecalho: $idPcpOpCabecalho')
          ..write(')'))
        .toString();
  }
}

class $PcpServicoEquipamentosTable extends PcpServicoEquipamentos
    with TableInfo<$PcpServicoEquipamentosTable, PcpServicoEquipamento> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $PcpServicoEquipamentosTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
    'id',
    aliasedName,
    true,
    type: DriftSqlType.int,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _idPcpServicoMeta = const VerificationMeta(
    'idPcpServico',
  );
  @override
  late final GeneratedColumn<int> idPcpServico = GeneratedColumn<int>(
    'id_pcp_servico',
    aliasedName,
    true,
    type: DriftSqlType.int,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _idPatrimBemMeta = const VerificationMeta(
    'idPatrimBem',
  );
  @override
  late final GeneratedColumn<int> idPatrimBem = GeneratedColumn<int>(
    'id_patrim_bem',
    aliasedName,
    true,
    type: DriftSqlType.int,
    requiredDuringInsert: false,
  );
  @override
  List<GeneratedColumn> get $columns => [id, idPcpServico, idPatrimBem];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'pcp_servico_equipamento';
  @override
  VerificationContext validateIntegrity(
    Insertable<PcpServicoEquipamento> instance, {
    bool isInserting = false,
  }) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('id_pcp_servico')) {
      context.handle(
        _idPcpServicoMeta,
        idPcpServico.isAcceptableOrUnknown(
          data['id_pcp_servico']!,
          _idPcpServicoMeta,
        ),
      );
    }
    if (data.containsKey('id_patrim_bem')) {
      context.handle(
        _idPatrimBemMeta,
        idPatrimBem.isAcceptableOrUnknown(
          data['id_patrim_bem']!,
          _idPatrimBemMeta,
        ),
      );
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  PcpServicoEquipamento map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return PcpServicoEquipamento(
      id: attachedDatabase.typeMapping.read(
        DriftSqlType.int,
        data['${effectivePrefix}id'],
      ),
      idPcpServico: attachedDatabase.typeMapping.read(
        DriftSqlType.int,
        data['${effectivePrefix}id_pcp_servico'],
      ),
      idPatrimBem: attachedDatabase.typeMapping.read(
        DriftSqlType.int,
        data['${effectivePrefix}id_patrim_bem'],
      ),
    );
  }

  @override
  $PcpServicoEquipamentosTable createAlias(String alias) {
    return $PcpServicoEquipamentosTable(attachedDatabase, alias);
  }
}

class PcpServicoEquipamento extends DataClass
    implements Insertable<PcpServicoEquipamento> {
  final int? id;
  final int? idPcpServico;
  final int? idPatrimBem;
  const PcpServicoEquipamento({this.id, this.idPcpServico, this.idPatrimBem});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || idPcpServico != null) {
      map['id_pcp_servico'] = Variable<int>(idPcpServico);
    }
    if (!nullToAbsent || idPatrimBem != null) {
      map['id_patrim_bem'] = Variable<int>(idPatrimBem);
    }
    return map;
  }

  factory PcpServicoEquipamento.fromJson(
    Map<String, dynamic> json, {
    ValueSerializer? serializer,
  }) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return PcpServicoEquipamento(
      id: serializer.fromJson<int?>(json['id']),
      idPcpServico: serializer.fromJson<int?>(json['idPcpServico']),
      idPatrimBem: serializer.fromJson<int?>(json['idPatrimBem']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'idPcpServico': serializer.toJson<int?>(idPcpServico),
      'idPatrimBem': serializer.toJson<int?>(idPatrimBem),
    };
  }

  PcpServicoEquipamento copyWith({
    Value<int?> id = const Value.absent(),
    Value<int?> idPcpServico = const Value.absent(),
    Value<int?> idPatrimBem = const Value.absent(),
  }) => PcpServicoEquipamento(
    id: id.present ? id.value : this.id,
    idPcpServico: idPcpServico.present ? idPcpServico.value : this.idPcpServico,
    idPatrimBem: idPatrimBem.present ? idPatrimBem.value : this.idPatrimBem,
  );
  PcpServicoEquipamento copyWithCompanion(
    PcpServicoEquipamentosCompanion data,
  ) {
    return PcpServicoEquipamento(
      id: data.id.present ? data.id.value : this.id,
      idPcpServico:
          data.idPcpServico.present
              ? data.idPcpServico.value
              : this.idPcpServico,
      idPatrimBem:
          data.idPatrimBem.present ? data.idPatrimBem.value : this.idPatrimBem,
    );
  }

  @override
  String toString() {
    return (StringBuffer('PcpServicoEquipamento(')
          ..write('id: $id, ')
          ..write('idPcpServico: $idPcpServico, ')
          ..write('idPatrimBem: $idPatrimBem')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(id, idPcpServico, idPatrimBem);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is PcpServicoEquipamento &&
          other.id == this.id &&
          other.idPcpServico == this.idPcpServico &&
          other.idPatrimBem == this.idPatrimBem);
}

class PcpServicoEquipamentosCompanion
    extends UpdateCompanion<PcpServicoEquipamento> {
  final Value<int?> id;
  final Value<int?> idPcpServico;
  final Value<int?> idPatrimBem;
  const PcpServicoEquipamentosCompanion({
    this.id = const Value.absent(),
    this.idPcpServico = const Value.absent(),
    this.idPatrimBem = const Value.absent(),
  });
  PcpServicoEquipamentosCompanion.insert({
    this.id = const Value.absent(),
    this.idPcpServico = const Value.absent(),
    this.idPatrimBem = const Value.absent(),
  });
  static Insertable<PcpServicoEquipamento> custom({
    Expression<int>? id,
    Expression<int>? idPcpServico,
    Expression<int>? idPatrimBem,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (idPcpServico != null) 'id_pcp_servico': idPcpServico,
      if (idPatrimBem != null) 'id_patrim_bem': idPatrimBem,
    });
  }

  PcpServicoEquipamentosCompanion copyWith({
    Value<int?>? id,
    Value<int?>? idPcpServico,
    Value<int?>? idPatrimBem,
  }) {
    return PcpServicoEquipamentosCompanion(
      id: id ?? this.id,
      idPcpServico: idPcpServico ?? this.idPcpServico,
      idPatrimBem: idPatrimBem ?? this.idPatrimBem,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (idPcpServico.present) {
      map['id_pcp_servico'] = Variable<int>(idPcpServico.value);
    }
    if (idPatrimBem.present) {
      map['id_patrim_bem'] = Variable<int>(idPatrimBem.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('PcpServicoEquipamentosCompanion(')
          ..write('id: $id, ')
          ..write('idPcpServico: $idPcpServico, ')
          ..write('idPatrimBem: $idPatrimBem')
          ..write(')'))
        .toString();
  }
}

class $PcpOpCabecalhosTable extends PcpOpCabecalhos
    with TableInfo<$PcpOpCabecalhosTable, PcpOpCabecalho> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $PcpOpCabecalhosTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
    'id',
    aliasedName,
    true,
    type: DriftSqlType.int,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _dataInicioMeta = const VerificationMeta(
    'dataInicio',
  );
  @override
  late final GeneratedColumn<DateTime> dataInicio = GeneratedColumn<DateTime>(
    'data_inicio',
    aliasedName,
    true,
    type: DriftSqlType.dateTime,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _dataPrevisaoEntregaMeta =
      const VerificationMeta('dataPrevisaoEntrega');
  @override
  late final GeneratedColumn<DateTime> dataPrevisaoEntrega =
      GeneratedColumn<DateTime>(
        'data_previsao_entrega',
        aliasedName,
        true,
        type: DriftSqlType.dateTime,
        requiredDuringInsert: false,
      );
  static const VerificationMeta _dataTerminoMeta = const VerificationMeta(
    'dataTermino',
  );
  @override
  late final GeneratedColumn<DateTime> dataTermino = GeneratedColumn<DateTime>(
    'data_termino',
    aliasedName,
    true,
    type: DriftSqlType.dateTime,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _custoTotalPrevistoMeta =
      const VerificationMeta('custoTotalPrevisto');
  @override
  late final GeneratedColumn<double> custoTotalPrevisto =
      GeneratedColumn<double>(
        'custo_total_previsto',
        aliasedName,
        true,
        type: DriftSqlType.double,
        requiredDuringInsert: false,
      );
  static const VerificationMeta _custoTotalRealizadoMeta =
      const VerificationMeta('custoTotalRealizado');
  @override
  late final GeneratedColumn<double> custoTotalRealizado =
      GeneratedColumn<double>(
        'custo_total_realizado',
        aliasedName,
        true,
        type: DriftSqlType.double,
        requiredDuringInsert: false,
      );
  static const VerificationMeta _porcentoVendaMeta = const VerificationMeta(
    'porcentoVenda',
  );
  @override
  late final GeneratedColumn<double> porcentoVenda = GeneratedColumn<double>(
    'porcento_venda',
    aliasedName,
    true,
    type: DriftSqlType.double,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _porcentoEstoqueMeta = const VerificationMeta(
    'porcentoEstoque',
  );
  @override
  late final GeneratedColumn<double> porcentoEstoque = GeneratedColumn<double>(
    'porcento_estoque',
    aliasedName,
    true,
    type: DriftSqlType.double,
    requiredDuringInsert: false,
  );
  @override
  List<GeneratedColumn> get $columns => [
    id,
    dataInicio,
    dataPrevisaoEntrega,
    dataTermino,
    custoTotalPrevisto,
    custoTotalRealizado,
    porcentoVenda,
    porcentoEstoque,
  ];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'pcp_op_cabecalho';
  @override
  VerificationContext validateIntegrity(
    Insertable<PcpOpCabecalho> instance, {
    bool isInserting = false,
  }) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('data_inicio')) {
      context.handle(
        _dataInicioMeta,
        dataInicio.isAcceptableOrUnknown(data['data_inicio']!, _dataInicioMeta),
      );
    }
    if (data.containsKey('data_previsao_entrega')) {
      context.handle(
        _dataPrevisaoEntregaMeta,
        dataPrevisaoEntrega.isAcceptableOrUnknown(
          data['data_previsao_entrega']!,
          _dataPrevisaoEntregaMeta,
        ),
      );
    }
    if (data.containsKey('data_termino')) {
      context.handle(
        _dataTerminoMeta,
        dataTermino.isAcceptableOrUnknown(
          data['data_termino']!,
          _dataTerminoMeta,
        ),
      );
    }
    if (data.containsKey('custo_total_previsto')) {
      context.handle(
        _custoTotalPrevistoMeta,
        custoTotalPrevisto.isAcceptableOrUnknown(
          data['custo_total_previsto']!,
          _custoTotalPrevistoMeta,
        ),
      );
    }
    if (data.containsKey('custo_total_realizado')) {
      context.handle(
        _custoTotalRealizadoMeta,
        custoTotalRealizado.isAcceptableOrUnknown(
          data['custo_total_realizado']!,
          _custoTotalRealizadoMeta,
        ),
      );
    }
    if (data.containsKey('porcento_venda')) {
      context.handle(
        _porcentoVendaMeta,
        porcentoVenda.isAcceptableOrUnknown(
          data['porcento_venda']!,
          _porcentoVendaMeta,
        ),
      );
    }
    if (data.containsKey('porcento_estoque')) {
      context.handle(
        _porcentoEstoqueMeta,
        porcentoEstoque.isAcceptableOrUnknown(
          data['porcento_estoque']!,
          _porcentoEstoqueMeta,
        ),
      );
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  PcpOpCabecalho map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return PcpOpCabecalho(
      id: attachedDatabase.typeMapping.read(
        DriftSqlType.int,
        data['${effectivePrefix}id'],
      ),
      dataInicio: attachedDatabase.typeMapping.read(
        DriftSqlType.dateTime,
        data['${effectivePrefix}data_inicio'],
      ),
      dataPrevisaoEntrega: attachedDatabase.typeMapping.read(
        DriftSqlType.dateTime,
        data['${effectivePrefix}data_previsao_entrega'],
      ),
      dataTermino: attachedDatabase.typeMapping.read(
        DriftSqlType.dateTime,
        data['${effectivePrefix}data_termino'],
      ),
      custoTotalPrevisto: attachedDatabase.typeMapping.read(
        DriftSqlType.double,
        data['${effectivePrefix}custo_total_previsto'],
      ),
      custoTotalRealizado: attachedDatabase.typeMapping.read(
        DriftSqlType.double,
        data['${effectivePrefix}custo_total_realizado'],
      ),
      porcentoVenda: attachedDatabase.typeMapping.read(
        DriftSqlType.double,
        data['${effectivePrefix}porcento_venda'],
      ),
      porcentoEstoque: attachedDatabase.typeMapping.read(
        DriftSqlType.double,
        data['${effectivePrefix}porcento_estoque'],
      ),
    );
  }

  @override
  $PcpOpCabecalhosTable createAlias(String alias) {
    return $PcpOpCabecalhosTable(attachedDatabase, alias);
  }
}

class PcpOpCabecalho extends DataClass implements Insertable<PcpOpCabecalho> {
  final int? id;
  final DateTime? dataInicio;
  final DateTime? dataPrevisaoEntrega;
  final DateTime? dataTermino;
  final double? custoTotalPrevisto;
  final double? custoTotalRealizado;
  final double? porcentoVenda;
  final double? porcentoEstoque;
  const PcpOpCabecalho({
    this.id,
    this.dataInicio,
    this.dataPrevisaoEntrega,
    this.dataTermino,
    this.custoTotalPrevisto,
    this.custoTotalRealizado,
    this.porcentoVenda,
    this.porcentoEstoque,
  });
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || dataInicio != null) {
      map['data_inicio'] = Variable<DateTime>(dataInicio);
    }
    if (!nullToAbsent || dataPrevisaoEntrega != null) {
      map['data_previsao_entrega'] = Variable<DateTime>(dataPrevisaoEntrega);
    }
    if (!nullToAbsent || dataTermino != null) {
      map['data_termino'] = Variable<DateTime>(dataTermino);
    }
    if (!nullToAbsent || custoTotalPrevisto != null) {
      map['custo_total_previsto'] = Variable<double>(custoTotalPrevisto);
    }
    if (!nullToAbsent || custoTotalRealizado != null) {
      map['custo_total_realizado'] = Variable<double>(custoTotalRealizado);
    }
    if (!nullToAbsent || porcentoVenda != null) {
      map['porcento_venda'] = Variable<double>(porcentoVenda);
    }
    if (!nullToAbsent || porcentoEstoque != null) {
      map['porcento_estoque'] = Variable<double>(porcentoEstoque);
    }
    return map;
  }

  factory PcpOpCabecalho.fromJson(
    Map<String, dynamic> json, {
    ValueSerializer? serializer,
  }) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return PcpOpCabecalho(
      id: serializer.fromJson<int?>(json['id']),
      dataInicio: serializer.fromJson<DateTime?>(json['dataInicio']),
      dataPrevisaoEntrega: serializer.fromJson<DateTime?>(
        json['dataPrevisaoEntrega'],
      ),
      dataTermino: serializer.fromJson<DateTime?>(json['dataTermino']),
      custoTotalPrevisto: serializer.fromJson<double?>(
        json['custoTotalPrevisto'],
      ),
      custoTotalRealizado: serializer.fromJson<double?>(
        json['custoTotalRealizado'],
      ),
      porcentoVenda: serializer.fromJson<double?>(json['porcentoVenda']),
      porcentoEstoque: serializer.fromJson<double?>(json['porcentoEstoque']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'dataInicio': serializer.toJson<DateTime?>(dataInicio),
      'dataPrevisaoEntrega': serializer.toJson<DateTime?>(dataPrevisaoEntrega),
      'dataTermino': serializer.toJson<DateTime?>(dataTermino),
      'custoTotalPrevisto': serializer.toJson<double?>(custoTotalPrevisto),
      'custoTotalRealizado': serializer.toJson<double?>(custoTotalRealizado),
      'porcentoVenda': serializer.toJson<double?>(porcentoVenda),
      'porcentoEstoque': serializer.toJson<double?>(porcentoEstoque),
    };
  }

  PcpOpCabecalho copyWith({
    Value<int?> id = const Value.absent(),
    Value<DateTime?> dataInicio = const Value.absent(),
    Value<DateTime?> dataPrevisaoEntrega = const Value.absent(),
    Value<DateTime?> dataTermino = const Value.absent(),
    Value<double?> custoTotalPrevisto = const Value.absent(),
    Value<double?> custoTotalRealizado = const Value.absent(),
    Value<double?> porcentoVenda = const Value.absent(),
    Value<double?> porcentoEstoque = const Value.absent(),
  }) => PcpOpCabecalho(
    id: id.present ? id.value : this.id,
    dataInicio: dataInicio.present ? dataInicio.value : this.dataInicio,
    dataPrevisaoEntrega:
        dataPrevisaoEntrega.present
            ? dataPrevisaoEntrega.value
            : this.dataPrevisaoEntrega,
    dataTermino: dataTermino.present ? dataTermino.value : this.dataTermino,
    custoTotalPrevisto:
        custoTotalPrevisto.present
            ? custoTotalPrevisto.value
            : this.custoTotalPrevisto,
    custoTotalRealizado:
        custoTotalRealizado.present
            ? custoTotalRealizado.value
            : this.custoTotalRealizado,
    porcentoVenda:
        porcentoVenda.present ? porcentoVenda.value : this.porcentoVenda,
    porcentoEstoque:
        porcentoEstoque.present ? porcentoEstoque.value : this.porcentoEstoque,
  );
  PcpOpCabecalho copyWithCompanion(PcpOpCabecalhosCompanion data) {
    return PcpOpCabecalho(
      id: data.id.present ? data.id.value : this.id,
      dataInicio:
          data.dataInicio.present ? data.dataInicio.value : this.dataInicio,
      dataPrevisaoEntrega:
          data.dataPrevisaoEntrega.present
              ? data.dataPrevisaoEntrega.value
              : this.dataPrevisaoEntrega,
      dataTermino:
          data.dataTermino.present ? data.dataTermino.value : this.dataTermino,
      custoTotalPrevisto:
          data.custoTotalPrevisto.present
              ? data.custoTotalPrevisto.value
              : this.custoTotalPrevisto,
      custoTotalRealizado:
          data.custoTotalRealizado.present
              ? data.custoTotalRealizado.value
              : this.custoTotalRealizado,
      porcentoVenda:
          data.porcentoVenda.present
              ? data.porcentoVenda.value
              : this.porcentoVenda,
      porcentoEstoque:
          data.porcentoEstoque.present
              ? data.porcentoEstoque.value
              : this.porcentoEstoque,
    );
  }

  @override
  String toString() {
    return (StringBuffer('PcpOpCabecalho(')
          ..write('id: $id, ')
          ..write('dataInicio: $dataInicio, ')
          ..write('dataPrevisaoEntrega: $dataPrevisaoEntrega, ')
          ..write('dataTermino: $dataTermino, ')
          ..write('custoTotalPrevisto: $custoTotalPrevisto, ')
          ..write('custoTotalRealizado: $custoTotalRealizado, ')
          ..write('porcentoVenda: $porcentoVenda, ')
          ..write('porcentoEstoque: $porcentoEstoque')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(
    id,
    dataInicio,
    dataPrevisaoEntrega,
    dataTermino,
    custoTotalPrevisto,
    custoTotalRealizado,
    porcentoVenda,
    porcentoEstoque,
  );
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is PcpOpCabecalho &&
          other.id == this.id &&
          other.dataInicio == this.dataInicio &&
          other.dataPrevisaoEntrega == this.dataPrevisaoEntrega &&
          other.dataTermino == this.dataTermino &&
          other.custoTotalPrevisto == this.custoTotalPrevisto &&
          other.custoTotalRealizado == this.custoTotalRealizado &&
          other.porcentoVenda == this.porcentoVenda &&
          other.porcentoEstoque == this.porcentoEstoque);
}

class PcpOpCabecalhosCompanion extends UpdateCompanion<PcpOpCabecalho> {
  final Value<int?> id;
  final Value<DateTime?> dataInicio;
  final Value<DateTime?> dataPrevisaoEntrega;
  final Value<DateTime?> dataTermino;
  final Value<double?> custoTotalPrevisto;
  final Value<double?> custoTotalRealizado;
  final Value<double?> porcentoVenda;
  final Value<double?> porcentoEstoque;
  const PcpOpCabecalhosCompanion({
    this.id = const Value.absent(),
    this.dataInicio = const Value.absent(),
    this.dataPrevisaoEntrega = const Value.absent(),
    this.dataTermino = const Value.absent(),
    this.custoTotalPrevisto = const Value.absent(),
    this.custoTotalRealizado = const Value.absent(),
    this.porcentoVenda = const Value.absent(),
    this.porcentoEstoque = const Value.absent(),
  });
  PcpOpCabecalhosCompanion.insert({
    this.id = const Value.absent(),
    this.dataInicio = const Value.absent(),
    this.dataPrevisaoEntrega = const Value.absent(),
    this.dataTermino = const Value.absent(),
    this.custoTotalPrevisto = const Value.absent(),
    this.custoTotalRealizado = const Value.absent(),
    this.porcentoVenda = const Value.absent(),
    this.porcentoEstoque = const Value.absent(),
  });
  static Insertable<PcpOpCabecalho> custom({
    Expression<int>? id,
    Expression<DateTime>? dataInicio,
    Expression<DateTime>? dataPrevisaoEntrega,
    Expression<DateTime>? dataTermino,
    Expression<double>? custoTotalPrevisto,
    Expression<double>? custoTotalRealizado,
    Expression<double>? porcentoVenda,
    Expression<double>? porcentoEstoque,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (dataInicio != null) 'data_inicio': dataInicio,
      if (dataPrevisaoEntrega != null)
        'data_previsao_entrega': dataPrevisaoEntrega,
      if (dataTermino != null) 'data_termino': dataTermino,
      if (custoTotalPrevisto != null)
        'custo_total_previsto': custoTotalPrevisto,
      if (custoTotalRealizado != null)
        'custo_total_realizado': custoTotalRealizado,
      if (porcentoVenda != null) 'porcento_venda': porcentoVenda,
      if (porcentoEstoque != null) 'porcento_estoque': porcentoEstoque,
    });
  }

  PcpOpCabecalhosCompanion copyWith({
    Value<int?>? id,
    Value<DateTime?>? dataInicio,
    Value<DateTime?>? dataPrevisaoEntrega,
    Value<DateTime?>? dataTermino,
    Value<double?>? custoTotalPrevisto,
    Value<double?>? custoTotalRealizado,
    Value<double?>? porcentoVenda,
    Value<double?>? porcentoEstoque,
  }) {
    return PcpOpCabecalhosCompanion(
      id: id ?? this.id,
      dataInicio: dataInicio ?? this.dataInicio,
      dataPrevisaoEntrega: dataPrevisaoEntrega ?? this.dataPrevisaoEntrega,
      dataTermino: dataTermino ?? this.dataTermino,
      custoTotalPrevisto: custoTotalPrevisto ?? this.custoTotalPrevisto,
      custoTotalRealizado: custoTotalRealizado ?? this.custoTotalRealizado,
      porcentoVenda: porcentoVenda ?? this.porcentoVenda,
      porcentoEstoque: porcentoEstoque ?? this.porcentoEstoque,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (dataInicio.present) {
      map['data_inicio'] = Variable<DateTime>(dataInicio.value);
    }
    if (dataPrevisaoEntrega.present) {
      map['data_previsao_entrega'] = Variable<DateTime>(
        dataPrevisaoEntrega.value,
      );
    }
    if (dataTermino.present) {
      map['data_termino'] = Variable<DateTime>(dataTermino.value);
    }
    if (custoTotalPrevisto.present) {
      map['custo_total_previsto'] = Variable<double>(custoTotalPrevisto.value);
    }
    if (custoTotalRealizado.present) {
      map['custo_total_realizado'] = Variable<double>(
        custoTotalRealizado.value,
      );
    }
    if (porcentoVenda.present) {
      map['porcento_venda'] = Variable<double>(porcentoVenda.value);
    }
    if (porcentoEstoque.present) {
      map['porcento_estoque'] = Variable<double>(porcentoEstoque.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('PcpOpCabecalhosCompanion(')
          ..write('id: $id, ')
          ..write('dataInicio: $dataInicio, ')
          ..write('dataPrevisaoEntrega: $dataPrevisaoEntrega, ')
          ..write('dataTermino: $dataTermino, ')
          ..write('custoTotalPrevisto: $custoTotalPrevisto, ')
          ..write('custoTotalRealizado: $custoTotalRealizado, ')
          ..write('porcentoVenda: $porcentoVenda, ')
          ..write('porcentoEstoque: $porcentoEstoque')
          ..write(')'))
        .toString();
  }
}

class $PcpServicosTable extends PcpServicos
    with TableInfo<$PcpServicosTable, PcpServico> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $PcpServicosTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
    'id',
    aliasedName,
    true,
    type: DriftSqlType.int,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _idPcpOpDetalheMeta = const VerificationMeta(
    'idPcpOpDetalhe',
  );
  @override
  late final GeneratedColumn<int> idPcpOpDetalhe = GeneratedColumn<int>(
    'id_pcp_op_detalhe',
    aliasedName,
    true,
    type: DriftSqlType.int,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _inicioPrevistoMeta = const VerificationMeta(
    'inicioPrevisto',
  );
  @override
  late final GeneratedColumn<DateTime> inicioPrevisto =
      GeneratedColumn<DateTime>(
        'inicio_previsto',
        aliasedName,
        true,
        type: DriftSqlType.dateTime,
        requiredDuringInsert: false,
      );
  static const VerificationMeta _terminoPrevistoMeta = const VerificationMeta(
    'terminoPrevisto',
  );
  @override
  late final GeneratedColumn<DateTime> terminoPrevisto =
      GeneratedColumn<DateTime>(
        'termino_previsto',
        aliasedName,
        true,
        type: DriftSqlType.dateTime,
        requiredDuringInsert: false,
      );
  static const VerificationMeta _horasPrevistoMeta = const VerificationMeta(
    'horasPrevisto',
  );
  @override
  late final GeneratedColumn<int> horasPrevisto = GeneratedColumn<int>(
    'horas_previsto',
    aliasedName,
    true,
    type: DriftSqlType.int,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _minutosPrevistoMeta = const VerificationMeta(
    'minutosPrevisto',
  );
  @override
  late final GeneratedColumn<int> minutosPrevisto = GeneratedColumn<int>(
    'minutos_previsto',
    aliasedName,
    true,
    type: DriftSqlType.int,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _segundosPrevistoMeta = const VerificationMeta(
    'segundosPrevisto',
  );
  @override
  late final GeneratedColumn<int> segundosPrevisto = GeneratedColumn<int>(
    'segundos_previsto',
    aliasedName,
    true,
    type: DriftSqlType.int,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _custoPrevistoMeta = const VerificationMeta(
    'custoPrevisto',
  );
  @override
  late final GeneratedColumn<double> custoPrevisto = GeneratedColumn<double>(
    'custo_previsto',
    aliasedName,
    true,
    type: DriftSqlType.double,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _inicioRealizadoMeta = const VerificationMeta(
    'inicioRealizado',
  );
  @override
  late final GeneratedColumn<DateTime> inicioRealizado =
      GeneratedColumn<DateTime>(
        'inicio_realizado',
        aliasedName,
        true,
        type: DriftSqlType.dateTime,
        requiredDuringInsert: false,
      );
  static const VerificationMeta _terminoRealizadoMeta = const VerificationMeta(
    'terminoRealizado',
  );
  @override
  late final GeneratedColumn<DateTime> terminoRealizado =
      GeneratedColumn<DateTime>(
        'termino_realizado',
        aliasedName,
        true,
        type: DriftSqlType.dateTime,
        requiredDuringInsert: false,
      );
  static const VerificationMeta _horasRealizadoMeta = const VerificationMeta(
    'horasRealizado',
  );
  @override
  late final GeneratedColumn<int> horasRealizado = GeneratedColumn<int>(
    'horas_realizado',
    aliasedName,
    true,
    type: DriftSqlType.int,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _minutosRealizadoMeta = const VerificationMeta(
    'minutosRealizado',
  );
  @override
  late final GeneratedColumn<int> minutosRealizado = GeneratedColumn<int>(
    'minutos_realizado',
    aliasedName,
    true,
    type: DriftSqlType.int,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _segundosRealizadoMeta = const VerificationMeta(
    'segundosRealizado',
  );
  @override
  late final GeneratedColumn<int> segundosRealizado = GeneratedColumn<int>(
    'segundos_realizado',
    aliasedName,
    true,
    type: DriftSqlType.int,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _custoRealizadoMeta = const VerificationMeta(
    'custoRealizado',
  );
  @override
  late final GeneratedColumn<double> custoRealizado = GeneratedColumn<double>(
    'custo_realizado',
    aliasedName,
    true,
    type: DriftSqlType.double,
    requiredDuringInsert: false,
  );
  @override
  List<GeneratedColumn> get $columns => [
    id,
    idPcpOpDetalhe,
    inicioPrevisto,
    terminoPrevisto,
    horasPrevisto,
    minutosPrevisto,
    segundosPrevisto,
    custoPrevisto,
    inicioRealizado,
    terminoRealizado,
    horasRealizado,
    minutosRealizado,
    segundosRealizado,
    custoRealizado,
  ];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'pcp_servico';
  @override
  VerificationContext validateIntegrity(
    Insertable<PcpServico> instance, {
    bool isInserting = false,
  }) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('id_pcp_op_detalhe')) {
      context.handle(
        _idPcpOpDetalheMeta,
        idPcpOpDetalhe.isAcceptableOrUnknown(
          data['id_pcp_op_detalhe']!,
          _idPcpOpDetalheMeta,
        ),
      );
    }
    if (data.containsKey('inicio_previsto')) {
      context.handle(
        _inicioPrevistoMeta,
        inicioPrevisto.isAcceptableOrUnknown(
          data['inicio_previsto']!,
          _inicioPrevistoMeta,
        ),
      );
    }
    if (data.containsKey('termino_previsto')) {
      context.handle(
        _terminoPrevistoMeta,
        terminoPrevisto.isAcceptableOrUnknown(
          data['termino_previsto']!,
          _terminoPrevistoMeta,
        ),
      );
    }
    if (data.containsKey('horas_previsto')) {
      context.handle(
        _horasPrevistoMeta,
        horasPrevisto.isAcceptableOrUnknown(
          data['horas_previsto']!,
          _horasPrevistoMeta,
        ),
      );
    }
    if (data.containsKey('minutos_previsto')) {
      context.handle(
        _minutosPrevistoMeta,
        minutosPrevisto.isAcceptableOrUnknown(
          data['minutos_previsto']!,
          _minutosPrevistoMeta,
        ),
      );
    }
    if (data.containsKey('segundos_previsto')) {
      context.handle(
        _segundosPrevistoMeta,
        segundosPrevisto.isAcceptableOrUnknown(
          data['segundos_previsto']!,
          _segundosPrevistoMeta,
        ),
      );
    }
    if (data.containsKey('custo_previsto')) {
      context.handle(
        _custoPrevistoMeta,
        custoPrevisto.isAcceptableOrUnknown(
          data['custo_previsto']!,
          _custoPrevistoMeta,
        ),
      );
    }
    if (data.containsKey('inicio_realizado')) {
      context.handle(
        _inicioRealizadoMeta,
        inicioRealizado.isAcceptableOrUnknown(
          data['inicio_realizado']!,
          _inicioRealizadoMeta,
        ),
      );
    }
    if (data.containsKey('termino_realizado')) {
      context.handle(
        _terminoRealizadoMeta,
        terminoRealizado.isAcceptableOrUnknown(
          data['termino_realizado']!,
          _terminoRealizadoMeta,
        ),
      );
    }
    if (data.containsKey('horas_realizado')) {
      context.handle(
        _horasRealizadoMeta,
        horasRealizado.isAcceptableOrUnknown(
          data['horas_realizado']!,
          _horasRealizadoMeta,
        ),
      );
    }
    if (data.containsKey('minutos_realizado')) {
      context.handle(
        _minutosRealizadoMeta,
        minutosRealizado.isAcceptableOrUnknown(
          data['minutos_realizado']!,
          _minutosRealizadoMeta,
        ),
      );
    }
    if (data.containsKey('segundos_realizado')) {
      context.handle(
        _segundosRealizadoMeta,
        segundosRealizado.isAcceptableOrUnknown(
          data['segundos_realizado']!,
          _segundosRealizadoMeta,
        ),
      );
    }
    if (data.containsKey('custo_realizado')) {
      context.handle(
        _custoRealizadoMeta,
        custoRealizado.isAcceptableOrUnknown(
          data['custo_realizado']!,
          _custoRealizadoMeta,
        ),
      );
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  PcpServico map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return PcpServico(
      id: attachedDatabase.typeMapping.read(
        DriftSqlType.int,
        data['${effectivePrefix}id'],
      ),
      idPcpOpDetalhe: attachedDatabase.typeMapping.read(
        DriftSqlType.int,
        data['${effectivePrefix}id_pcp_op_detalhe'],
      ),
      inicioPrevisto: attachedDatabase.typeMapping.read(
        DriftSqlType.dateTime,
        data['${effectivePrefix}inicio_previsto'],
      ),
      terminoPrevisto: attachedDatabase.typeMapping.read(
        DriftSqlType.dateTime,
        data['${effectivePrefix}termino_previsto'],
      ),
      horasPrevisto: attachedDatabase.typeMapping.read(
        DriftSqlType.int,
        data['${effectivePrefix}horas_previsto'],
      ),
      minutosPrevisto: attachedDatabase.typeMapping.read(
        DriftSqlType.int,
        data['${effectivePrefix}minutos_previsto'],
      ),
      segundosPrevisto: attachedDatabase.typeMapping.read(
        DriftSqlType.int,
        data['${effectivePrefix}segundos_previsto'],
      ),
      custoPrevisto: attachedDatabase.typeMapping.read(
        DriftSqlType.double,
        data['${effectivePrefix}custo_previsto'],
      ),
      inicioRealizado: attachedDatabase.typeMapping.read(
        DriftSqlType.dateTime,
        data['${effectivePrefix}inicio_realizado'],
      ),
      terminoRealizado: attachedDatabase.typeMapping.read(
        DriftSqlType.dateTime,
        data['${effectivePrefix}termino_realizado'],
      ),
      horasRealizado: attachedDatabase.typeMapping.read(
        DriftSqlType.int,
        data['${effectivePrefix}horas_realizado'],
      ),
      minutosRealizado: attachedDatabase.typeMapping.read(
        DriftSqlType.int,
        data['${effectivePrefix}minutos_realizado'],
      ),
      segundosRealizado: attachedDatabase.typeMapping.read(
        DriftSqlType.int,
        data['${effectivePrefix}segundos_realizado'],
      ),
      custoRealizado: attachedDatabase.typeMapping.read(
        DriftSqlType.double,
        data['${effectivePrefix}custo_realizado'],
      ),
    );
  }

  @override
  $PcpServicosTable createAlias(String alias) {
    return $PcpServicosTable(attachedDatabase, alias);
  }
}

class PcpServico extends DataClass implements Insertable<PcpServico> {
  final int? id;
  final int? idPcpOpDetalhe;
  final DateTime? inicioPrevisto;
  final DateTime? terminoPrevisto;
  final int? horasPrevisto;
  final int? minutosPrevisto;
  final int? segundosPrevisto;
  final double? custoPrevisto;
  final DateTime? inicioRealizado;
  final DateTime? terminoRealizado;
  final int? horasRealizado;
  final int? minutosRealizado;
  final int? segundosRealizado;
  final double? custoRealizado;
  const PcpServico({
    this.id,
    this.idPcpOpDetalhe,
    this.inicioPrevisto,
    this.terminoPrevisto,
    this.horasPrevisto,
    this.minutosPrevisto,
    this.segundosPrevisto,
    this.custoPrevisto,
    this.inicioRealizado,
    this.terminoRealizado,
    this.horasRealizado,
    this.minutosRealizado,
    this.segundosRealizado,
    this.custoRealizado,
  });
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || idPcpOpDetalhe != null) {
      map['id_pcp_op_detalhe'] = Variable<int>(idPcpOpDetalhe);
    }
    if (!nullToAbsent || inicioPrevisto != null) {
      map['inicio_previsto'] = Variable<DateTime>(inicioPrevisto);
    }
    if (!nullToAbsent || terminoPrevisto != null) {
      map['termino_previsto'] = Variable<DateTime>(terminoPrevisto);
    }
    if (!nullToAbsent || horasPrevisto != null) {
      map['horas_previsto'] = Variable<int>(horasPrevisto);
    }
    if (!nullToAbsent || minutosPrevisto != null) {
      map['minutos_previsto'] = Variable<int>(minutosPrevisto);
    }
    if (!nullToAbsent || segundosPrevisto != null) {
      map['segundos_previsto'] = Variable<int>(segundosPrevisto);
    }
    if (!nullToAbsent || custoPrevisto != null) {
      map['custo_previsto'] = Variable<double>(custoPrevisto);
    }
    if (!nullToAbsent || inicioRealizado != null) {
      map['inicio_realizado'] = Variable<DateTime>(inicioRealizado);
    }
    if (!nullToAbsent || terminoRealizado != null) {
      map['termino_realizado'] = Variable<DateTime>(terminoRealizado);
    }
    if (!nullToAbsent || horasRealizado != null) {
      map['horas_realizado'] = Variable<int>(horasRealizado);
    }
    if (!nullToAbsent || minutosRealizado != null) {
      map['minutos_realizado'] = Variable<int>(minutosRealizado);
    }
    if (!nullToAbsent || segundosRealizado != null) {
      map['segundos_realizado'] = Variable<int>(segundosRealizado);
    }
    if (!nullToAbsent || custoRealizado != null) {
      map['custo_realizado'] = Variable<double>(custoRealizado);
    }
    return map;
  }

  factory PcpServico.fromJson(
    Map<String, dynamic> json, {
    ValueSerializer? serializer,
  }) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return PcpServico(
      id: serializer.fromJson<int?>(json['id']),
      idPcpOpDetalhe: serializer.fromJson<int?>(json['idPcpOpDetalhe']),
      inicioPrevisto: serializer.fromJson<DateTime?>(json['inicioPrevisto']),
      terminoPrevisto: serializer.fromJson<DateTime?>(json['terminoPrevisto']),
      horasPrevisto: serializer.fromJson<int?>(json['horasPrevisto']),
      minutosPrevisto: serializer.fromJson<int?>(json['minutosPrevisto']),
      segundosPrevisto: serializer.fromJson<int?>(json['segundosPrevisto']),
      custoPrevisto: serializer.fromJson<double?>(json['custoPrevisto']),
      inicioRealizado: serializer.fromJson<DateTime?>(json['inicioRealizado']),
      terminoRealizado: serializer.fromJson<DateTime?>(
        json['terminoRealizado'],
      ),
      horasRealizado: serializer.fromJson<int?>(json['horasRealizado']),
      minutosRealizado: serializer.fromJson<int?>(json['minutosRealizado']),
      segundosRealizado: serializer.fromJson<int?>(json['segundosRealizado']),
      custoRealizado: serializer.fromJson<double?>(json['custoRealizado']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'idPcpOpDetalhe': serializer.toJson<int?>(idPcpOpDetalhe),
      'inicioPrevisto': serializer.toJson<DateTime?>(inicioPrevisto),
      'terminoPrevisto': serializer.toJson<DateTime?>(terminoPrevisto),
      'horasPrevisto': serializer.toJson<int?>(horasPrevisto),
      'minutosPrevisto': serializer.toJson<int?>(minutosPrevisto),
      'segundosPrevisto': serializer.toJson<int?>(segundosPrevisto),
      'custoPrevisto': serializer.toJson<double?>(custoPrevisto),
      'inicioRealizado': serializer.toJson<DateTime?>(inicioRealizado),
      'terminoRealizado': serializer.toJson<DateTime?>(terminoRealizado),
      'horasRealizado': serializer.toJson<int?>(horasRealizado),
      'minutosRealizado': serializer.toJson<int?>(minutosRealizado),
      'segundosRealizado': serializer.toJson<int?>(segundosRealizado),
      'custoRealizado': serializer.toJson<double?>(custoRealizado),
    };
  }

  PcpServico copyWith({
    Value<int?> id = const Value.absent(),
    Value<int?> idPcpOpDetalhe = const Value.absent(),
    Value<DateTime?> inicioPrevisto = const Value.absent(),
    Value<DateTime?> terminoPrevisto = const Value.absent(),
    Value<int?> horasPrevisto = const Value.absent(),
    Value<int?> minutosPrevisto = const Value.absent(),
    Value<int?> segundosPrevisto = const Value.absent(),
    Value<double?> custoPrevisto = const Value.absent(),
    Value<DateTime?> inicioRealizado = const Value.absent(),
    Value<DateTime?> terminoRealizado = const Value.absent(),
    Value<int?> horasRealizado = const Value.absent(),
    Value<int?> minutosRealizado = const Value.absent(),
    Value<int?> segundosRealizado = const Value.absent(),
    Value<double?> custoRealizado = const Value.absent(),
  }) => PcpServico(
    id: id.present ? id.value : this.id,
    idPcpOpDetalhe:
        idPcpOpDetalhe.present ? idPcpOpDetalhe.value : this.idPcpOpDetalhe,
    inicioPrevisto:
        inicioPrevisto.present ? inicioPrevisto.value : this.inicioPrevisto,
    terminoPrevisto:
        terminoPrevisto.present ? terminoPrevisto.value : this.terminoPrevisto,
    horasPrevisto:
        horasPrevisto.present ? horasPrevisto.value : this.horasPrevisto,
    minutosPrevisto:
        minutosPrevisto.present ? minutosPrevisto.value : this.minutosPrevisto,
    segundosPrevisto:
        segundosPrevisto.present
            ? segundosPrevisto.value
            : this.segundosPrevisto,
    custoPrevisto:
        custoPrevisto.present ? custoPrevisto.value : this.custoPrevisto,
    inicioRealizado:
        inicioRealizado.present ? inicioRealizado.value : this.inicioRealizado,
    terminoRealizado:
        terminoRealizado.present
            ? terminoRealizado.value
            : this.terminoRealizado,
    horasRealizado:
        horasRealizado.present ? horasRealizado.value : this.horasRealizado,
    minutosRealizado:
        minutosRealizado.present
            ? minutosRealizado.value
            : this.minutosRealizado,
    segundosRealizado:
        segundosRealizado.present
            ? segundosRealizado.value
            : this.segundosRealizado,
    custoRealizado:
        custoRealizado.present ? custoRealizado.value : this.custoRealizado,
  );
  PcpServico copyWithCompanion(PcpServicosCompanion data) {
    return PcpServico(
      id: data.id.present ? data.id.value : this.id,
      idPcpOpDetalhe:
          data.idPcpOpDetalhe.present
              ? data.idPcpOpDetalhe.value
              : this.idPcpOpDetalhe,
      inicioPrevisto:
          data.inicioPrevisto.present
              ? data.inicioPrevisto.value
              : this.inicioPrevisto,
      terminoPrevisto:
          data.terminoPrevisto.present
              ? data.terminoPrevisto.value
              : this.terminoPrevisto,
      horasPrevisto:
          data.horasPrevisto.present
              ? data.horasPrevisto.value
              : this.horasPrevisto,
      minutosPrevisto:
          data.minutosPrevisto.present
              ? data.minutosPrevisto.value
              : this.minutosPrevisto,
      segundosPrevisto:
          data.segundosPrevisto.present
              ? data.segundosPrevisto.value
              : this.segundosPrevisto,
      custoPrevisto:
          data.custoPrevisto.present
              ? data.custoPrevisto.value
              : this.custoPrevisto,
      inicioRealizado:
          data.inicioRealizado.present
              ? data.inicioRealizado.value
              : this.inicioRealizado,
      terminoRealizado:
          data.terminoRealizado.present
              ? data.terminoRealizado.value
              : this.terminoRealizado,
      horasRealizado:
          data.horasRealizado.present
              ? data.horasRealizado.value
              : this.horasRealizado,
      minutosRealizado:
          data.minutosRealizado.present
              ? data.minutosRealizado.value
              : this.minutosRealizado,
      segundosRealizado:
          data.segundosRealizado.present
              ? data.segundosRealizado.value
              : this.segundosRealizado,
      custoRealizado:
          data.custoRealizado.present
              ? data.custoRealizado.value
              : this.custoRealizado,
    );
  }

  @override
  String toString() {
    return (StringBuffer('PcpServico(')
          ..write('id: $id, ')
          ..write('idPcpOpDetalhe: $idPcpOpDetalhe, ')
          ..write('inicioPrevisto: $inicioPrevisto, ')
          ..write('terminoPrevisto: $terminoPrevisto, ')
          ..write('horasPrevisto: $horasPrevisto, ')
          ..write('minutosPrevisto: $minutosPrevisto, ')
          ..write('segundosPrevisto: $segundosPrevisto, ')
          ..write('custoPrevisto: $custoPrevisto, ')
          ..write('inicioRealizado: $inicioRealizado, ')
          ..write('terminoRealizado: $terminoRealizado, ')
          ..write('horasRealizado: $horasRealizado, ')
          ..write('minutosRealizado: $minutosRealizado, ')
          ..write('segundosRealizado: $segundosRealizado, ')
          ..write('custoRealizado: $custoRealizado')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(
    id,
    idPcpOpDetalhe,
    inicioPrevisto,
    terminoPrevisto,
    horasPrevisto,
    minutosPrevisto,
    segundosPrevisto,
    custoPrevisto,
    inicioRealizado,
    terminoRealizado,
    horasRealizado,
    minutosRealizado,
    segundosRealizado,
    custoRealizado,
  );
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is PcpServico &&
          other.id == this.id &&
          other.idPcpOpDetalhe == this.idPcpOpDetalhe &&
          other.inicioPrevisto == this.inicioPrevisto &&
          other.terminoPrevisto == this.terminoPrevisto &&
          other.horasPrevisto == this.horasPrevisto &&
          other.minutosPrevisto == this.minutosPrevisto &&
          other.segundosPrevisto == this.segundosPrevisto &&
          other.custoPrevisto == this.custoPrevisto &&
          other.inicioRealizado == this.inicioRealizado &&
          other.terminoRealizado == this.terminoRealizado &&
          other.horasRealizado == this.horasRealizado &&
          other.minutosRealizado == this.minutosRealizado &&
          other.segundosRealizado == this.segundosRealizado &&
          other.custoRealizado == this.custoRealizado);
}

class PcpServicosCompanion extends UpdateCompanion<PcpServico> {
  final Value<int?> id;
  final Value<int?> idPcpOpDetalhe;
  final Value<DateTime?> inicioPrevisto;
  final Value<DateTime?> terminoPrevisto;
  final Value<int?> horasPrevisto;
  final Value<int?> minutosPrevisto;
  final Value<int?> segundosPrevisto;
  final Value<double?> custoPrevisto;
  final Value<DateTime?> inicioRealizado;
  final Value<DateTime?> terminoRealizado;
  final Value<int?> horasRealizado;
  final Value<int?> minutosRealizado;
  final Value<int?> segundosRealizado;
  final Value<double?> custoRealizado;
  const PcpServicosCompanion({
    this.id = const Value.absent(),
    this.idPcpOpDetalhe = const Value.absent(),
    this.inicioPrevisto = const Value.absent(),
    this.terminoPrevisto = const Value.absent(),
    this.horasPrevisto = const Value.absent(),
    this.minutosPrevisto = const Value.absent(),
    this.segundosPrevisto = const Value.absent(),
    this.custoPrevisto = const Value.absent(),
    this.inicioRealizado = const Value.absent(),
    this.terminoRealizado = const Value.absent(),
    this.horasRealizado = const Value.absent(),
    this.minutosRealizado = const Value.absent(),
    this.segundosRealizado = const Value.absent(),
    this.custoRealizado = const Value.absent(),
  });
  PcpServicosCompanion.insert({
    this.id = const Value.absent(),
    this.idPcpOpDetalhe = const Value.absent(),
    this.inicioPrevisto = const Value.absent(),
    this.terminoPrevisto = const Value.absent(),
    this.horasPrevisto = const Value.absent(),
    this.minutosPrevisto = const Value.absent(),
    this.segundosPrevisto = const Value.absent(),
    this.custoPrevisto = const Value.absent(),
    this.inicioRealizado = const Value.absent(),
    this.terminoRealizado = const Value.absent(),
    this.horasRealizado = const Value.absent(),
    this.minutosRealizado = const Value.absent(),
    this.segundosRealizado = const Value.absent(),
    this.custoRealizado = const Value.absent(),
  });
  static Insertable<PcpServico> custom({
    Expression<int>? id,
    Expression<int>? idPcpOpDetalhe,
    Expression<DateTime>? inicioPrevisto,
    Expression<DateTime>? terminoPrevisto,
    Expression<int>? horasPrevisto,
    Expression<int>? minutosPrevisto,
    Expression<int>? segundosPrevisto,
    Expression<double>? custoPrevisto,
    Expression<DateTime>? inicioRealizado,
    Expression<DateTime>? terminoRealizado,
    Expression<int>? horasRealizado,
    Expression<int>? minutosRealizado,
    Expression<int>? segundosRealizado,
    Expression<double>? custoRealizado,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (idPcpOpDetalhe != null) 'id_pcp_op_detalhe': idPcpOpDetalhe,
      if (inicioPrevisto != null) 'inicio_previsto': inicioPrevisto,
      if (terminoPrevisto != null) 'termino_previsto': terminoPrevisto,
      if (horasPrevisto != null) 'horas_previsto': horasPrevisto,
      if (minutosPrevisto != null) 'minutos_previsto': minutosPrevisto,
      if (segundosPrevisto != null) 'segundos_previsto': segundosPrevisto,
      if (custoPrevisto != null) 'custo_previsto': custoPrevisto,
      if (inicioRealizado != null) 'inicio_realizado': inicioRealizado,
      if (terminoRealizado != null) 'termino_realizado': terminoRealizado,
      if (horasRealizado != null) 'horas_realizado': horasRealizado,
      if (minutosRealizado != null) 'minutos_realizado': minutosRealizado,
      if (segundosRealizado != null) 'segundos_realizado': segundosRealizado,
      if (custoRealizado != null) 'custo_realizado': custoRealizado,
    });
  }

  PcpServicosCompanion copyWith({
    Value<int?>? id,
    Value<int?>? idPcpOpDetalhe,
    Value<DateTime?>? inicioPrevisto,
    Value<DateTime?>? terminoPrevisto,
    Value<int?>? horasPrevisto,
    Value<int?>? minutosPrevisto,
    Value<int?>? segundosPrevisto,
    Value<double?>? custoPrevisto,
    Value<DateTime?>? inicioRealizado,
    Value<DateTime?>? terminoRealizado,
    Value<int?>? horasRealizado,
    Value<int?>? minutosRealizado,
    Value<int?>? segundosRealizado,
    Value<double?>? custoRealizado,
  }) {
    return PcpServicosCompanion(
      id: id ?? this.id,
      idPcpOpDetalhe: idPcpOpDetalhe ?? this.idPcpOpDetalhe,
      inicioPrevisto: inicioPrevisto ?? this.inicioPrevisto,
      terminoPrevisto: terminoPrevisto ?? this.terminoPrevisto,
      horasPrevisto: horasPrevisto ?? this.horasPrevisto,
      minutosPrevisto: minutosPrevisto ?? this.minutosPrevisto,
      segundosPrevisto: segundosPrevisto ?? this.segundosPrevisto,
      custoPrevisto: custoPrevisto ?? this.custoPrevisto,
      inicioRealizado: inicioRealizado ?? this.inicioRealizado,
      terminoRealizado: terminoRealizado ?? this.terminoRealizado,
      horasRealizado: horasRealizado ?? this.horasRealizado,
      minutosRealizado: minutosRealizado ?? this.minutosRealizado,
      segundosRealizado: segundosRealizado ?? this.segundosRealizado,
      custoRealizado: custoRealizado ?? this.custoRealizado,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (idPcpOpDetalhe.present) {
      map['id_pcp_op_detalhe'] = Variable<int>(idPcpOpDetalhe.value);
    }
    if (inicioPrevisto.present) {
      map['inicio_previsto'] = Variable<DateTime>(inicioPrevisto.value);
    }
    if (terminoPrevisto.present) {
      map['termino_previsto'] = Variable<DateTime>(terminoPrevisto.value);
    }
    if (horasPrevisto.present) {
      map['horas_previsto'] = Variable<int>(horasPrevisto.value);
    }
    if (minutosPrevisto.present) {
      map['minutos_previsto'] = Variable<int>(minutosPrevisto.value);
    }
    if (segundosPrevisto.present) {
      map['segundos_previsto'] = Variable<int>(segundosPrevisto.value);
    }
    if (custoPrevisto.present) {
      map['custo_previsto'] = Variable<double>(custoPrevisto.value);
    }
    if (inicioRealizado.present) {
      map['inicio_realizado'] = Variable<DateTime>(inicioRealizado.value);
    }
    if (terminoRealizado.present) {
      map['termino_realizado'] = Variable<DateTime>(terminoRealizado.value);
    }
    if (horasRealizado.present) {
      map['horas_realizado'] = Variable<int>(horasRealizado.value);
    }
    if (minutosRealizado.present) {
      map['minutos_realizado'] = Variable<int>(minutosRealizado.value);
    }
    if (segundosRealizado.present) {
      map['segundos_realizado'] = Variable<int>(segundosRealizado.value);
    }
    if (custoRealizado.present) {
      map['custo_realizado'] = Variable<double>(custoRealizado.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('PcpServicosCompanion(')
          ..write('id: $id, ')
          ..write('idPcpOpDetalhe: $idPcpOpDetalhe, ')
          ..write('inicioPrevisto: $inicioPrevisto, ')
          ..write('terminoPrevisto: $terminoPrevisto, ')
          ..write('horasPrevisto: $horasPrevisto, ')
          ..write('minutosPrevisto: $minutosPrevisto, ')
          ..write('segundosPrevisto: $segundosPrevisto, ')
          ..write('custoPrevisto: $custoPrevisto, ')
          ..write('inicioRealizado: $inicioRealizado, ')
          ..write('terminoRealizado: $terminoRealizado, ')
          ..write('horasRealizado: $horasRealizado, ')
          ..write('minutosRealizado: $minutosRealizado, ')
          ..write('segundosRealizado: $segundosRealizado, ')
          ..write('custoRealizado: $custoRealizado')
          ..write(')'))
        .toString();
  }
}

class $ProdutosTable extends Produtos with TableInfo<$ProdutosTable, Produto> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $ProdutosTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
    'id',
    aliasedName,
    true,
    type: DriftSqlType.int,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _idTributIcmsCustomCabMeta =
      const VerificationMeta('idTributIcmsCustomCab');
  @override
  late final GeneratedColumn<int> idTributIcmsCustomCab = GeneratedColumn<int>(
    'id_tribut_icms_custom_cab',
    aliasedName,
    true,
    type: DriftSqlType.int,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _idTributGrupoTributarioMeta =
      const VerificationMeta('idTributGrupoTributario');
  @override
  late final GeneratedColumn<int> idTributGrupoTributario =
      GeneratedColumn<int>(
        'id_tribut_grupo_tributario',
        aliasedName,
        true,
        type: DriftSqlType.int,
        requiredDuringInsert: false,
      );
  static const VerificationMeta _nomeMeta = const VerificationMeta('nome');
  @override
  late final GeneratedColumn<String> nome = GeneratedColumn<String>(
    'nome',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 100,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _descricaoMeta = const VerificationMeta(
    'descricao',
  );
  @override
  late final GeneratedColumn<String> descricao = GeneratedColumn<String>(
    'descricao',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 250,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _gtinMeta = const VerificationMeta('gtin');
  @override
  late final GeneratedColumn<String> gtin = GeneratedColumn<String>(
    'gtin',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 14,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _codigoInternoMeta = const VerificationMeta(
    'codigoInterno',
  );
  @override
  late final GeneratedColumn<String> codigoInterno = GeneratedColumn<String>(
    'codigo_interno',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 50,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _valorCompraMeta = const VerificationMeta(
    'valorCompra',
  );
  @override
  late final GeneratedColumn<double> valorCompra = GeneratedColumn<double>(
    'valor_compra',
    aliasedName,
    true,
    type: DriftSqlType.double,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _valorVendaMeta = const VerificationMeta(
    'valorVenda',
  );
  @override
  late final GeneratedColumn<double> valorVenda = GeneratedColumn<double>(
    'valor_venda',
    aliasedName,
    true,
    type: DriftSqlType.double,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _codigoNcmMeta = const VerificationMeta(
    'codigoNcm',
  );
  @override
  late final GeneratedColumn<String> codigoNcm = GeneratedColumn<String>(
    'codigo_ncm',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 8,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _estoqueMinimoMeta = const VerificationMeta(
    'estoqueMinimo',
  );
  @override
  late final GeneratedColumn<double> estoqueMinimo = GeneratedColumn<double>(
    'estoque_minimo',
    aliasedName,
    true,
    type: DriftSqlType.double,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _estoqueMaximoMeta = const VerificationMeta(
    'estoqueMaximo',
  );
  @override
  late final GeneratedColumn<double> estoqueMaximo = GeneratedColumn<double>(
    'estoque_maximo',
    aliasedName,
    true,
    type: DriftSqlType.double,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _quantidadeEstoqueMeta = const VerificationMeta(
    'quantidadeEstoque',
  );
  @override
  late final GeneratedColumn<double> quantidadeEstoque =
      GeneratedColumn<double>(
        'quantidade_estoque',
        aliasedName,
        true,
        type: DriftSqlType.double,
        requiredDuringInsert: false,
      );
  static const VerificationMeta _dataCadastroMeta = const VerificationMeta(
    'dataCadastro',
  );
  @override
  late final GeneratedColumn<DateTime> dataCadastro = GeneratedColumn<DateTime>(
    'data_cadastro',
    aliasedName,
    true,
    type: DriftSqlType.dateTime,
    requiredDuringInsert: false,
  );
  @override
  List<GeneratedColumn> get $columns => [
    id,
    idTributIcmsCustomCab,
    idTributGrupoTributario,
    nome,
    descricao,
    gtin,
    codigoInterno,
    valorCompra,
    valorVenda,
    codigoNcm,
    estoqueMinimo,
    estoqueMaximo,
    quantidadeEstoque,
    dataCadastro,
  ];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'produto';
  @override
  VerificationContext validateIntegrity(
    Insertable<Produto> instance, {
    bool isInserting = false,
  }) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('id_tribut_icms_custom_cab')) {
      context.handle(
        _idTributIcmsCustomCabMeta,
        idTributIcmsCustomCab.isAcceptableOrUnknown(
          data['id_tribut_icms_custom_cab']!,
          _idTributIcmsCustomCabMeta,
        ),
      );
    }
    if (data.containsKey('id_tribut_grupo_tributario')) {
      context.handle(
        _idTributGrupoTributarioMeta,
        idTributGrupoTributario.isAcceptableOrUnknown(
          data['id_tribut_grupo_tributario']!,
          _idTributGrupoTributarioMeta,
        ),
      );
    }
    if (data.containsKey('nome')) {
      context.handle(
        _nomeMeta,
        nome.isAcceptableOrUnknown(data['nome']!, _nomeMeta),
      );
    }
    if (data.containsKey('descricao')) {
      context.handle(
        _descricaoMeta,
        descricao.isAcceptableOrUnknown(data['descricao']!, _descricaoMeta),
      );
    }
    if (data.containsKey('gtin')) {
      context.handle(
        _gtinMeta,
        gtin.isAcceptableOrUnknown(data['gtin']!, _gtinMeta),
      );
    }
    if (data.containsKey('codigo_interno')) {
      context.handle(
        _codigoInternoMeta,
        codigoInterno.isAcceptableOrUnknown(
          data['codigo_interno']!,
          _codigoInternoMeta,
        ),
      );
    }
    if (data.containsKey('valor_compra')) {
      context.handle(
        _valorCompraMeta,
        valorCompra.isAcceptableOrUnknown(
          data['valor_compra']!,
          _valorCompraMeta,
        ),
      );
    }
    if (data.containsKey('valor_venda')) {
      context.handle(
        _valorVendaMeta,
        valorVenda.isAcceptableOrUnknown(data['valor_venda']!, _valorVendaMeta),
      );
    }
    if (data.containsKey('codigo_ncm')) {
      context.handle(
        _codigoNcmMeta,
        codigoNcm.isAcceptableOrUnknown(data['codigo_ncm']!, _codigoNcmMeta),
      );
    }
    if (data.containsKey('estoque_minimo')) {
      context.handle(
        _estoqueMinimoMeta,
        estoqueMinimo.isAcceptableOrUnknown(
          data['estoque_minimo']!,
          _estoqueMinimoMeta,
        ),
      );
    }
    if (data.containsKey('estoque_maximo')) {
      context.handle(
        _estoqueMaximoMeta,
        estoqueMaximo.isAcceptableOrUnknown(
          data['estoque_maximo']!,
          _estoqueMaximoMeta,
        ),
      );
    }
    if (data.containsKey('quantidade_estoque')) {
      context.handle(
        _quantidadeEstoqueMeta,
        quantidadeEstoque.isAcceptableOrUnknown(
          data['quantidade_estoque']!,
          _quantidadeEstoqueMeta,
        ),
      );
    }
    if (data.containsKey('data_cadastro')) {
      context.handle(
        _dataCadastroMeta,
        dataCadastro.isAcceptableOrUnknown(
          data['data_cadastro']!,
          _dataCadastroMeta,
        ),
      );
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  Produto map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return Produto(
      id: attachedDatabase.typeMapping.read(
        DriftSqlType.int,
        data['${effectivePrefix}id'],
      ),
      idTributIcmsCustomCab: attachedDatabase.typeMapping.read(
        DriftSqlType.int,
        data['${effectivePrefix}id_tribut_icms_custom_cab'],
      ),
      idTributGrupoTributario: attachedDatabase.typeMapping.read(
        DriftSqlType.int,
        data['${effectivePrefix}id_tribut_grupo_tributario'],
      ),
      nome: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}nome'],
      ),
      descricao: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}descricao'],
      ),
      gtin: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}gtin'],
      ),
      codigoInterno: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}codigo_interno'],
      ),
      valorCompra: attachedDatabase.typeMapping.read(
        DriftSqlType.double,
        data['${effectivePrefix}valor_compra'],
      ),
      valorVenda: attachedDatabase.typeMapping.read(
        DriftSqlType.double,
        data['${effectivePrefix}valor_venda'],
      ),
      codigoNcm: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}codigo_ncm'],
      ),
      estoqueMinimo: attachedDatabase.typeMapping.read(
        DriftSqlType.double,
        data['${effectivePrefix}estoque_minimo'],
      ),
      estoqueMaximo: attachedDatabase.typeMapping.read(
        DriftSqlType.double,
        data['${effectivePrefix}estoque_maximo'],
      ),
      quantidadeEstoque: attachedDatabase.typeMapping.read(
        DriftSqlType.double,
        data['${effectivePrefix}quantidade_estoque'],
      ),
      dataCadastro: attachedDatabase.typeMapping.read(
        DriftSqlType.dateTime,
        data['${effectivePrefix}data_cadastro'],
      ),
    );
  }

  @override
  $ProdutosTable createAlias(String alias) {
    return $ProdutosTable(attachedDatabase, alias);
  }
}

class Produto extends DataClass implements Insertable<Produto> {
  final int? id;
  final int? idTributIcmsCustomCab;
  final int? idTributGrupoTributario;
  final String? nome;
  final String? descricao;
  final String? gtin;
  final String? codigoInterno;
  final double? valorCompra;
  final double? valorVenda;
  final String? codigoNcm;
  final double? estoqueMinimo;
  final double? estoqueMaximo;
  final double? quantidadeEstoque;
  final DateTime? dataCadastro;
  const Produto({
    this.id,
    this.idTributIcmsCustomCab,
    this.idTributGrupoTributario,
    this.nome,
    this.descricao,
    this.gtin,
    this.codigoInterno,
    this.valorCompra,
    this.valorVenda,
    this.codigoNcm,
    this.estoqueMinimo,
    this.estoqueMaximo,
    this.quantidadeEstoque,
    this.dataCadastro,
  });
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || idTributIcmsCustomCab != null) {
      map['id_tribut_icms_custom_cab'] = Variable<int>(idTributIcmsCustomCab);
    }
    if (!nullToAbsent || idTributGrupoTributario != null) {
      map['id_tribut_grupo_tributario'] = Variable<int>(
        idTributGrupoTributario,
      );
    }
    if (!nullToAbsent || nome != null) {
      map['nome'] = Variable<String>(nome);
    }
    if (!nullToAbsent || descricao != null) {
      map['descricao'] = Variable<String>(descricao);
    }
    if (!nullToAbsent || gtin != null) {
      map['gtin'] = Variable<String>(gtin);
    }
    if (!nullToAbsent || codigoInterno != null) {
      map['codigo_interno'] = Variable<String>(codigoInterno);
    }
    if (!nullToAbsent || valorCompra != null) {
      map['valor_compra'] = Variable<double>(valorCompra);
    }
    if (!nullToAbsent || valorVenda != null) {
      map['valor_venda'] = Variable<double>(valorVenda);
    }
    if (!nullToAbsent || codigoNcm != null) {
      map['codigo_ncm'] = Variable<String>(codigoNcm);
    }
    if (!nullToAbsent || estoqueMinimo != null) {
      map['estoque_minimo'] = Variable<double>(estoqueMinimo);
    }
    if (!nullToAbsent || estoqueMaximo != null) {
      map['estoque_maximo'] = Variable<double>(estoqueMaximo);
    }
    if (!nullToAbsent || quantidadeEstoque != null) {
      map['quantidade_estoque'] = Variable<double>(quantidadeEstoque);
    }
    if (!nullToAbsent || dataCadastro != null) {
      map['data_cadastro'] = Variable<DateTime>(dataCadastro);
    }
    return map;
  }

  factory Produto.fromJson(
    Map<String, dynamic> json, {
    ValueSerializer? serializer,
  }) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return Produto(
      id: serializer.fromJson<int?>(json['id']),
      idTributIcmsCustomCab: serializer.fromJson<int?>(
        json['idTributIcmsCustomCab'],
      ),
      idTributGrupoTributario: serializer.fromJson<int?>(
        json['idTributGrupoTributario'],
      ),
      nome: serializer.fromJson<String?>(json['nome']),
      descricao: serializer.fromJson<String?>(json['descricao']),
      gtin: serializer.fromJson<String?>(json['gtin']),
      codigoInterno: serializer.fromJson<String?>(json['codigoInterno']),
      valorCompra: serializer.fromJson<double?>(json['valorCompra']),
      valorVenda: serializer.fromJson<double?>(json['valorVenda']),
      codigoNcm: serializer.fromJson<String?>(json['codigoNcm']),
      estoqueMinimo: serializer.fromJson<double?>(json['estoqueMinimo']),
      estoqueMaximo: serializer.fromJson<double?>(json['estoqueMaximo']),
      quantidadeEstoque: serializer.fromJson<double?>(
        json['quantidadeEstoque'],
      ),
      dataCadastro: serializer.fromJson<DateTime?>(json['dataCadastro']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'idTributIcmsCustomCab': serializer.toJson<int?>(idTributIcmsCustomCab),
      'idTributGrupoTributario': serializer.toJson<int?>(
        idTributGrupoTributario,
      ),
      'nome': serializer.toJson<String?>(nome),
      'descricao': serializer.toJson<String?>(descricao),
      'gtin': serializer.toJson<String?>(gtin),
      'codigoInterno': serializer.toJson<String?>(codigoInterno),
      'valorCompra': serializer.toJson<double?>(valorCompra),
      'valorVenda': serializer.toJson<double?>(valorVenda),
      'codigoNcm': serializer.toJson<String?>(codigoNcm),
      'estoqueMinimo': serializer.toJson<double?>(estoqueMinimo),
      'estoqueMaximo': serializer.toJson<double?>(estoqueMaximo),
      'quantidadeEstoque': serializer.toJson<double?>(quantidadeEstoque),
      'dataCadastro': serializer.toJson<DateTime?>(dataCadastro),
    };
  }

  Produto copyWith({
    Value<int?> id = const Value.absent(),
    Value<int?> idTributIcmsCustomCab = const Value.absent(),
    Value<int?> idTributGrupoTributario = const Value.absent(),
    Value<String?> nome = const Value.absent(),
    Value<String?> descricao = const Value.absent(),
    Value<String?> gtin = const Value.absent(),
    Value<String?> codigoInterno = const Value.absent(),
    Value<double?> valorCompra = const Value.absent(),
    Value<double?> valorVenda = const Value.absent(),
    Value<String?> codigoNcm = const Value.absent(),
    Value<double?> estoqueMinimo = const Value.absent(),
    Value<double?> estoqueMaximo = const Value.absent(),
    Value<double?> quantidadeEstoque = const Value.absent(),
    Value<DateTime?> dataCadastro = const Value.absent(),
  }) => Produto(
    id: id.present ? id.value : this.id,
    idTributIcmsCustomCab:
        idTributIcmsCustomCab.present
            ? idTributIcmsCustomCab.value
            : this.idTributIcmsCustomCab,
    idTributGrupoTributario:
        idTributGrupoTributario.present
            ? idTributGrupoTributario.value
            : this.idTributGrupoTributario,
    nome: nome.present ? nome.value : this.nome,
    descricao: descricao.present ? descricao.value : this.descricao,
    gtin: gtin.present ? gtin.value : this.gtin,
    codigoInterno:
        codigoInterno.present ? codigoInterno.value : this.codigoInterno,
    valorCompra: valorCompra.present ? valorCompra.value : this.valorCompra,
    valorVenda: valorVenda.present ? valorVenda.value : this.valorVenda,
    codigoNcm: codigoNcm.present ? codigoNcm.value : this.codigoNcm,
    estoqueMinimo:
        estoqueMinimo.present ? estoqueMinimo.value : this.estoqueMinimo,
    estoqueMaximo:
        estoqueMaximo.present ? estoqueMaximo.value : this.estoqueMaximo,
    quantidadeEstoque:
        quantidadeEstoque.present
            ? quantidadeEstoque.value
            : this.quantidadeEstoque,
    dataCadastro: dataCadastro.present ? dataCadastro.value : this.dataCadastro,
  );
  Produto copyWithCompanion(ProdutosCompanion data) {
    return Produto(
      id: data.id.present ? data.id.value : this.id,
      idTributIcmsCustomCab:
          data.idTributIcmsCustomCab.present
              ? data.idTributIcmsCustomCab.value
              : this.idTributIcmsCustomCab,
      idTributGrupoTributario:
          data.idTributGrupoTributario.present
              ? data.idTributGrupoTributario.value
              : this.idTributGrupoTributario,
      nome: data.nome.present ? data.nome.value : this.nome,
      descricao: data.descricao.present ? data.descricao.value : this.descricao,
      gtin: data.gtin.present ? data.gtin.value : this.gtin,
      codigoInterno:
          data.codigoInterno.present
              ? data.codigoInterno.value
              : this.codigoInterno,
      valorCompra:
          data.valorCompra.present ? data.valorCompra.value : this.valorCompra,
      valorVenda:
          data.valorVenda.present ? data.valorVenda.value : this.valorVenda,
      codigoNcm: data.codigoNcm.present ? data.codigoNcm.value : this.codigoNcm,
      estoqueMinimo:
          data.estoqueMinimo.present
              ? data.estoqueMinimo.value
              : this.estoqueMinimo,
      estoqueMaximo:
          data.estoqueMaximo.present
              ? data.estoqueMaximo.value
              : this.estoqueMaximo,
      quantidadeEstoque:
          data.quantidadeEstoque.present
              ? data.quantidadeEstoque.value
              : this.quantidadeEstoque,
      dataCadastro:
          data.dataCadastro.present
              ? data.dataCadastro.value
              : this.dataCadastro,
    );
  }

  @override
  String toString() {
    return (StringBuffer('Produto(')
          ..write('id: $id, ')
          ..write('idTributIcmsCustomCab: $idTributIcmsCustomCab, ')
          ..write('idTributGrupoTributario: $idTributGrupoTributario, ')
          ..write('nome: $nome, ')
          ..write('descricao: $descricao, ')
          ..write('gtin: $gtin, ')
          ..write('codigoInterno: $codigoInterno, ')
          ..write('valorCompra: $valorCompra, ')
          ..write('valorVenda: $valorVenda, ')
          ..write('codigoNcm: $codigoNcm, ')
          ..write('estoqueMinimo: $estoqueMinimo, ')
          ..write('estoqueMaximo: $estoqueMaximo, ')
          ..write('quantidadeEstoque: $quantidadeEstoque, ')
          ..write('dataCadastro: $dataCadastro')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(
    id,
    idTributIcmsCustomCab,
    idTributGrupoTributario,
    nome,
    descricao,
    gtin,
    codigoInterno,
    valorCompra,
    valorVenda,
    codigoNcm,
    estoqueMinimo,
    estoqueMaximo,
    quantidadeEstoque,
    dataCadastro,
  );
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is Produto &&
          other.id == this.id &&
          other.idTributIcmsCustomCab == this.idTributIcmsCustomCab &&
          other.idTributGrupoTributario == this.idTributGrupoTributario &&
          other.nome == this.nome &&
          other.descricao == this.descricao &&
          other.gtin == this.gtin &&
          other.codigoInterno == this.codigoInterno &&
          other.valorCompra == this.valorCompra &&
          other.valorVenda == this.valorVenda &&
          other.codigoNcm == this.codigoNcm &&
          other.estoqueMinimo == this.estoqueMinimo &&
          other.estoqueMaximo == this.estoqueMaximo &&
          other.quantidadeEstoque == this.quantidadeEstoque &&
          other.dataCadastro == this.dataCadastro);
}

class ProdutosCompanion extends UpdateCompanion<Produto> {
  final Value<int?> id;
  final Value<int?> idTributIcmsCustomCab;
  final Value<int?> idTributGrupoTributario;
  final Value<String?> nome;
  final Value<String?> descricao;
  final Value<String?> gtin;
  final Value<String?> codigoInterno;
  final Value<double?> valorCompra;
  final Value<double?> valorVenda;
  final Value<String?> codigoNcm;
  final Value<double?> estoqueMinimo;
  final Value<double?> estoqueMaximo;
  final Value<double?> quantidadeEstoque;
  final Value<DateTime?> dataCadastro;
  const ProdutosCompanion({
    this.id = const Value.absent(),
    this.idTributIcmsCustomCab = const Value.absent(),
    this.idTributGrupoTributario = const Value.absent(),
    this.nome = const Value.absent(),
    this.descricao = const Value.absent(),
    this.gtin = const Value.absent(),
    this.codigoInterno = const Value.absent(),
    this.valorCompra = const Value.absent(),
    this.valorVenda = const Value.absent(),
    this.codigoNcm = const Value.absent(),
    this.estoqueMinimo = const Value.absent(),
    this.estoqueMaximo = const Value.absent(),
    this.quantidadeEstoque = const Value.absent(),
    this.dataCadastro = const Value.absent(),
  });
  ProdutosCompanion.insert({
    this.id = const Value.absent(),
    this.idTributIcmsCustomCab = const Value.absent(),
    this.idTributGrupoTributario = const Value.absent(),
    this.nome = const Value.absent(),
    this.descricao = const Value.absent(),
    this.gtin = const Value.absent(),
    this.codigoInterno = const Value.absent(),
    this.valorCompra = const Value.absent(),
    this.valorVenda = const Value.absent(),
    this.codigoNcm = const Value.absent(),
    this.estoqueMinimo = const Value.absent(),
    this.estoqueMaximo = const Value.absent(),
    this.quantidadeEstoque = const Value.absent(),
    this.dataCadastro = const Value.absent(),
  });
  static Insertable<Produto> custom({
    Expression<int>? id,
    Expression<int>? idTributIcmsCustomCab,
    Expression<int>? idTributGrupoTributario,
    Expression<String>? nome,
    Expression<String>? descricao,
    Expression<String>? gtin,
    Expression<String>? codigoInterno,
    Expression<double>? valorCompra,
    Expression<double>? valorVenda,
    Expression<String>? codigoNcm,
    Expression<double>? estoqueMinimo,
    Expression<double>? estoqueMaximo,
    Expression<double>? quantidadeEstoque,
    Expression<DateTime>? dataCadastro,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (idTributIcmsCustomCab != null)
        'id_tribut_icms_custom_cab': idTributIcmsCustomCab,
      if (idTributGrupoTributario != null)
        'id_tribut_grupo_tributario': idTributGrupoTributario,
      if (nome != null) 'nome': nome,
      if (descricao != null) 'descricao': descricao,
      if (gtin != null) 'gtin': gtin,
      if (codigoInterno != null) 'codigo_interno': codigoInterno,
      if (valorCompra != null) 'valor_compra': valorCompra,
      if (valorVenda != null) 'valor_venda': valorVenda,
      if (codigoNcm != null) 'codigo_ncm': codigoNcm,
      if (estoqueMinimo != null) 'estoque_minimo': estoqueMinimo,
      if (estoqueMaximo != null) 'estoque_maximo': estoqueMaximo,
      if (quantidadeEstoque != null) 'quantidade_estoque': quantidadeEstoque,
      if (dataCadastro != null) 'data_cadastro': dataCadastro,
    });
  }

  ProdutosCompanion copyWith({
    Value<int?>? id,
    Value<int?>? idTributIcmsCustomCab,
    Value<int?>? idTributGrupoTributario,
    Value<String?>? nome,
    Value<String?>? descricao,
    Value<String?>? gtin,
    Value<String?>? codigoInterno,
    Value<double?>? valorCompra,
    Value<double?>? valorVenda,
    Value<String?>? codigoNcm,
    Value<double?>? estoqueMinimo,
    Value<double?>? estoqueMaximo,
    Value<double?>? quantidadeEstoque,
    Value<DateTime?>? dataCadastro,
  }) {
    return ProdutosCompanion(
      id: id ?? this.id,
      idTributIcmsCustomCab:
          idTributIcmsCustomCab ?? this.idTributIcmsCustomCab,
      idTributGrupoTributario:
          idTributGrupoTributario ?? this.idTributGrupoTributario,
      nome: nome ?? this.nome,
      descricao: descricao ?? this.descricao,
      gtin: gtin ?? this.gtin,
      codigoInterno: codigoInterno ?? this.codigoInterno,
      valorCompra: valorCompra ?? this.valorCompra,
      valorVenda: valorVenda ?? this.valorVenda,
      codigoNcm: codigoNcm ?? this.codigoNcm,
      estoqueMinimo: estoqueMinimo ?? this.estoqueMinimo,
      estoqueMaximo: estoqueMaximo ?? this.estoqueMaximo,
      quantidadeEstoque: quantidadeEstoque ?? this.quantidadeEstoque,
      dataCadastro: dataCadastro ?? this.dataCadastro,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (idTributIcmsCustomCab.present) {
      map['id_tribut_icms_custom_cab'] = Variable<int>(
        idTributIcmsCustomCab.value,
      );
    }
    if (idTributGrupoTributario.present) {
      map['id_tribut_grupo_tributario'] = Variable<int>(
        idTributGrupoTributario.value,
      );
    }
    if (nome.present) {
      map['nome'] = Variable<String>(nome.value);
    }
    if (descricao.present) {
      map['descricao'] = Variable<String>(descricao.value);
    }
    if (gtin.present) {
      map['gtin'] = Variable<String>(gtin.value);
    }
    if (codigoInterno.present) {
      map['codigo_interno'] = Variable<String>(codigoInterno.value);
    }
    if (valorCompra.present) {
      map['valor_compra'] = Variable<double>(valorCompra.value);
    }
    if (valorVenda.present) {
      map['valor_venda'] = Variable<double>(valorVenda.value);
    }
    if (codigoNcm.present) {
      map['codigo_ncm'] = Variable<String>(codigoNcm.value);
    }
    if (estoqueMinimo.present) {
      map['estoque_minimo'] = Variable<double>(estoqueMinimo.value);
    }
    if (estoqueMaximo.present) {
      map['estoque_maximo'] = Variable<double>(estoqueMaximo.value);
    }
    if (quantidadeEstoque.present) {
      map['quantidade_estoque'] = Variable<double>(quantidadeEstoque.value);
    }
    if (dataCadastro.present) {
      map['data_cadastro'] = Variable<DateTime>(dataCadastro.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('ProdutosCompanion(')
          ..write('id: $id, ')
          ..write('idTributIcmsCustomCab: $idTributIcmsCustomCab, ')
          ..write('idTributGrupoTributario: $idTributGrupoTributario, ')
          ..write('nome: $nome, ')
          ..write('descricao: $descricao, ')
          ..write('gtin: $gtin, ')
          ..write('codigoInterno: $codigoInterno, ')
          ..write('valorCompra: $valorCompra, ')
          ..write('valorVenda: $valorVenda, ')
          ..write('codigoNcm: $codigoNcm, ')
          ..write('estoqueMinimo: $estoqueMinimo, ')
          ..write('estoqueMaximo: $estoqueMaximo, ')
          ..write('quantidadeEstoque: $quantidadeEstoque, ')
          ..write('dataCadastro: $dataCadastro')
          ..write(')'))
        .toString();
  }
}

class $PatrimBemsTable extends PatrimBems
    with TableInfo<$PatrimBemsTable, PatrimBem> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $PatrimBemsTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
    'id',
    aliasedName,
    true,
    type: DriftSqlType.int,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _idCentroResultadoMeta = const VerificationMeta(
    'idCentroResultado',
  );
  @override
  late final GeneratedColumn<int> idCentroResultado = GeneratedColumn<int>(
    'id_centro_resultado',
    aliasedName,
    true,
    type: DriftSqlType.int,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _idPatrimTipoAquisicaoBemMeta =
      const VerificationMeta('idPatrimTipoAquisicaoBem');
  @override
  late final GeneratedColumn<int> idPatrimTipoAquisicaoBem =
      GeneratedColumn<int>(
        'id_patrim_tipo_aquisicao_bem',
        aliasedName,
        true,
        type: DriftSqlType.int,
        requiredDuringInsert: false,
      );
  static const VerificationMeta _idPatrimEstadoConservacaoMeta =
      const VerificationMeta('idPatrimEstadoConservacao');
  @override
  late final GeneratedColumn<int> idPatrimEstadoConservacao =
      GeneratedColumn<int>(
        'id_patrim_estado_conservacao',
        aliasedName,
        true,
        type: DriftSqlType.int,
        requiredDuringInsert: false,
      );
  static const VerificationMeta _idPatrimGrupoBemMeta = const VerificationMeta(
    'idPatrimGrupoBem',
  );
  @override
  late final GeneratedColumn<int> idPatrimGrupoBem = GeneratedColumn<int>(
    'id_patrim_grupo_bem',
    aliasedName,
    true,
    type: DriftSqlType.int,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _idFornecedorMeta = const VerificationMeta(
    'idFornecedor',
  );
  @override
  late final GeneratedColumn<int> idFornecedor = GeneratedColumn<int>(
    'id_fornecedor',
    aliasedName,
    true,
    type: DriftSqlType.int,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _idSetorMeta = const VerificationMeta(
    'idSetor',
  );
  @override
  late final GeneratedColumn<int> idSetor = GeneratedColumn<int>(
    'id_setor',
    aliasedName,
    true,
    type: DriftSqlType.int,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _numeroNbMeta = const VerificationMeta(
    'numeroNb',
  );
  @override
  late final GeneratedColumn<String> numeroNb = GeneratedColumn<String>(
    'numero_nb',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 20,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _nomeMeta = const VerificationMeta('nome');
  @override
  late final GeneratedColumn<String> nome = GeneratedColumn<String>(
    'nome',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 100,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _descricaoMeta = const VerificationMeta(
    'descricao',
  );
  @override
  late final GeneratedColumn<String> descricao = GeneratedColumn<String>(
    'descricao',
    aliasedName,
    true,
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _numeroSerieMeta = const VerificationMeta(
    'numeroSerie',
  );
  @override
  late final GeneratedColumn<String> numeroSerie = GeneratedColumn<String>(
    'numero_serie',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 50,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _dataAquisicaoMeta = const VerificationMeta(
    'dataAquisicao',
  );
  @override
  late final GeneratedColumn<DateTime> dataAquisicao =
      GeneratedColumn<DateTime>(
        'data_aquisicao',
        aliasedName,
        true,
        type: DriftSqlType.dateTime,
        requiredDuringInsert: false,
      );
  static const VerificationMeta _dataAceiteMeta = const VerificationMeta(
    'dataAceite',
  );
  @override
  late final GeneratedColumn<DateTime> dataAceite = GeneratedColumn<DateTime>(
    'data_aceite',
    aliasedName,
    true,
    type: DriftSqlType.dateTime,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _dataCadastroMeta = const VerificationMeta(
    'dataCadastro',
  );
  @override
  late final GeneratedColumn<DateTime> dataCadastro = GeneratedColumn<DateTime>(
    'data_cadastro',
    aliasedName,
    true,
    type: DriftSqlType.dateTime,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _dataContabilizadoMeta = const VerificationMeta(
    'dataContabilizado',
  );
  @override
  late final GeneratedColumn<DateTime> dataContabilizado =
      GeneratedColumn<DateTime>(
        'data_contabilizado',
        aliasedName,
        true,
        type: DriftSqlType.dateTime,
        requiredDuringInsert: false,
      );
  static const VerificationMeta _dataVistoriaMeta = const VerificationMeta(
    'dataVistoria',
  );
  @override
  late final GeneratedColumn<DateTime> dataVistoria = GeneratedColumn<DateTime>(
    'data_vistoria',
    aliasedName,
    true,
    type: DriftSqlType.dateTime,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _dataMarcacaoMeta = const VerificationMeta(
    'dataMarcacao',
  );
  @override
  late final GeneratedColumn<DateTime> dataMarcacao = GeneratedColumn<DateTime>(
    'data_marcacao',
    aliasedName,
    true,
    type: DriftSqlType.dateTime,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _dataBaixaMeta = const VerificationMeta(
    'dataBaixa',
  );
  @override
  late final GeneratedColumn<DateTime> dataBaixa = GeneratedColumn<DateTime>(
    'data_baixa',
    aliasedName,
    true,
    type: DriftSqlType.dateTime,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _vencimentoGarantiaMeta =
      const VerificationMeta('vencimentoGarantia');
  @override
  late final GeneratedColumn<DateTime> vencimentoGarantia =
      GeneratedColumn<DateTime>(
        'vencimento_garantia',
        aliasedName,
        true,
        type: DriftSqlType.dateTime,
        requiredDuringInsert: false,
      );
  static const VerificationMeta _numeroNotaFiscalMeta = const VerificationMeta(
    'numeroNotaFiscal',
  );
  @override
  late final GeneratedColumn<String> numeroNotaFiscal = GeneratedColumn<String>(
    'numero_nota_fiscal',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 50,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _chaveNfeMeta = const VerificationMeta(
    'chaveNfe',
  );
  @override
  late final GeneratedColumn<String> chaveNfe = GeneratedColumn<String>(
    'chave_nfe',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 44,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _valorOriginalMeta = const VerificationMeta(
    'valorOriginal',
  );
  @override
  late final GeneratedColumn<double> valorOriginal = GeneratedColumn<double>(
    'valor_original',
    aliasedName,
    true,
    type: DriftSqlType.double,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _valorCompraMeta = const VerificationMeta(
    'valorCompra',
  );
  @override
  late final GeneratedColumn<double> valorCompra = GeneratedColumn<double>(
    'valor_compra',
    aliasedName,
    true,
    type: DriftSqlType.double,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _valorAtualizadoMeta = const VerificationMeta(
    'valorAtualizado',
  );
  @override
  late final GeneratedColumn<double> valorAtualizado = GeneratedColumn<double>(
    'valor_atualizado',
    aliasedName,
    true,
    type: DriftSqlType.double,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _valorBaixaMeta = const VerificationMeta(
    'valorBaixa',
  );
  @override
  late final GeneratedColumn<double> valorBaixa = GeneratedColumn<double>(
    'valor_baixa',
    aliasedName,
    true,
    type: DriftSqlType.double,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _depreciaMeta = const VerificationMeta(
    'deprecia',
  );
  @override
  late final GeneratedColumn<String> deprecia = GeneratedColumn<String>(
    'deprecia',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 1,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _metodoDepreciacaoMeta = const VerificationMeta(
    'metodoDepreciacao',
  );
  @override
  late final GeneratedColumn<String> metodoDepreciacao =
      GeneratedColumn<String>(
        'metodo_depreciacao',
        aliasedName,
        true,
        additionalChecks: GeneratedColumn.checkTextLength(
          minTextLength: 0,
          maxTextLength: 1,
        ),
        type: DriftSqlType.string,
        requiredDuringInsert: false,
      );
  static const VerificationMeta _inicioDepreciacaoMeta = const VerificationMeta(
    'inicioDepreciacao',
  );
  @override
  late final GeneratedColumn<DateTime> inicioDepreciacao =
      GeneratedColumn<DateTime>(
        'inicio_depreciacao',
        aliasedName,
        true,
        type: DriftSqlType.dateTime,
        requiredDuringInsert: false,
      );
  static const VerificationMeta _ultimaDepreciacaoMeta = const VerificationMeta(
    'ultimaDepreciacao',
  );
  @override
  late final GeneratedColumn<DateTime> ultimaDepreciacao =
      GeneratedColumn<DateTime>(
        'ultima_depreciacao',
        aliasedName,
        true,
        type: DriftSqlType.dateTime,
        requiredDuringInsert: false,
      );
  static const VerificationMeta _tipoDepreciacaoMeta = const VerificationMeta(
    'tipoDepreciacao',
  );
  @override
  late final GeneratedColumn<String> tipoDepreciacao = GeneratedColumn<String>(
    'tipo_depreciacao',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 1,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _taxaAnualDepreciacaoMeta =
      const VerificationMeta('taxaAnualDepreciacao');
  @override
  late final GeneratedColumn<double> taxaAnualDepreciacao =
      GeneratedColumn<double>(
        'taxa_anual_depreciacao',
        aliasedName,
        true,
        type: DriftSqlType.double,
        requiredDuringInsert: false,
      );
  static const VerificationMeta _taxaMensalDepreciacaoMeta =
      const VerificationMeta('taxaMensalDepreciacao');
  @override
  late final GeneratedColumn<double> taxaMensalDepreciacao =
      GeneratedColumn<double>(
        'taxa_mensal_depreciacao',
        aliasedName,
        true,
        type: DriftSqlType.double,
        requiredDuringInsert: false,
      );
  static const VerificationMeta _taxaDepreciacaoAceleradaMeta =
      const VerificationMeta('taxaDepreciacaoAcelerada');
  @override
  late final GeneratedColumn<double> taxaDepreciacaoAcelerada =
      GeneratedColumn<double>(
        'taxa_depreciacao_acelerada',
        aliasedName,
        true,
        type: DriftSqlType.double,
        requiredDuringInsert: false,
      );
  static const VerificationMeta _taxaDepreciacaoIncentivadaMeta =
      const VerificationMeta('taxaDepreciacaoIncentivada');
  @override
  late final GeneratedColumn<double> taxaDepreciacaoIncentivada =
      GeneratedColumn<double>(
        'taxa_depreciacao_incentivada',
        aliasedName,
        true,
        type: DriftSqlType.double,
        requiredDuringInsert: false,
      );
  static const VerificationMeta _funcaoMeta = const VerificationMeta('funcao');
  @override
  late final GeneratedColumn<String> funcao = GeneratedColumn<String>(
    'funcao',
    aliasedName,
    true,
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  @override
  List<GeneratedColumn> get $columns => [
    id,
    idCentroResultado,
    idPatrimTipoAquisicaoBem,
    idPatrimEstadoConservacao,
    idPatrimGrupoBem,
    idFornecedor,
    idSetor,
    numeroNb,
    nome,
    descricao,
    numeroSerie,
    dataAquisicao,
    dataAceite,
    dataCadastro,
    dataContabilizado,
    dataVistoria,
    dataMarcacao,
    dataBaixa,
    vencimentoGarantia,
    numeroNotaFiscal,
    chaveNfe,
    valorOriginal,
    valorCompra,
    valorAtualizado,
    valorBaixa,
    deprecia,
    metodoDepreciacao,
    inicioDepreciacao,
    ultimaDepreciacao,
    tipoDepreciacao,
    taxaAnualDepreciacao,
    taxaMensalDepreciacao,
    taxaDepreciacaoAcelerada,
    taxaDepreciacaoIncentivada,
    funcao,
  ];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'patrim_bem';
  @override
  VerificationContext validateIntegrity(
    Insertable<PatrimBem> instance, {
    bool isInserting = false,
  }) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('id_centro_resultado')) {
      context.handle(
        _idCentroResultadoMeta,
        idCentroResultado.isAcceptableOrUnknown(
          data['id_centro_resultado']!,
          _idCentroResultadoMeta,
        ),
      );
    }
    if (data.containsKey('id_patrim_tipo_aquisicao_bem')) {
      context.handle(
        _idPatrimTipoAquisicaoBemMeta,
        idPatrimTipoAquisicaoBem.isAcceptableOrUnknown(
          data['id_patrim_tipo_aquisicao_bem']!,
          _idPatrimTipoAquisicaoBemMeta,
        ),
      );
    }
    if (data.containsKey('id_patrim_estado_conservacao')) {
      context.handle(
        _idPatrimEstadoConservacaoMeta,
        idPatrimEstadoConservacao.isAcceptableOrUnknown(
          data['id_patrim_estado_conservacao']!,
          _idPatrimEstadoConservacaoMeta,
        ),
      );
    }
    if (data.containsKey('id_patrim_grupo_bem')) {
      context.handle(
        _idPatrimGrupoBemMeta,
        idPatrimGrupoBem.isAcceptableOrUnknown(
          data['id_patrim_grupo_bem']!,
          _idPatrimGrupoBemMeta,
        ),
      );
    }
    if (data.containsKey('id_fornecedor')) {
      context.handle(
        _idFornecedorMeta,
        idFornecedor.isAcceptableOrUnknown(
          data['id_fornecedor']!,
          _idFornecedorMeta,
        ),
      );
    }
    if (data.containsKey('id_setor')) {
      context.handle(
        _idSetorMeta,
        idSetor.isAcceptableOrUnknown(data['id_setor']!, _idSetorMeta),
      );
    }
    if (data.containsKey('numero_nb')) {
      context.handle(
        _numeroNbMeta,
        numeroNb.isAcceptableOrUnknown(data['numero_nb']!, _numeroNbMeta),
      );
    }
    if (data.containsKey('nome')) {
      context.handle(
        _nomeMeta,
        nome.isAcceptableOrUnknown(data['nome']!, _nomeMeta),
      );
    }
    if (data.containsKey('descricao')) {
      context.handle(
        _descricaoMeta,
        descricao.isAcceptableOrUnknown(data['descricao']!, _descricaoMeta),
      );
    }
    if (data.containsKey('numero_serie')) {
      context.handle(
        _numeroSerieMeta,
        numeroSerie.isAcceptableOrUnknown(
          data['numero_serie']!,
          _numeroSerieMeta,
        ),
      );
    }
    if (data.containsKey('data_aquisicao')) {
      context.handle(
        _dataAquisicaoMeta,
        dataAquisicao.isAcceptableOrUnknown(
          data['data_aquisicao']!,
          _dataAquisicaoMeta,
        ),
      );
    }
    if (data.containsKey('data_aceite')) {
      context.handle(
        _dataAceiteMeta,
        dataAceite.isAcceptableOrUnknown(data['data_aceite']!, _dataAceiteMeta),
      );
    }
    if (data.containsKey('data_cadastro')) {
      context.handle(
        _dataCadastroMeta,
        dataCadastro.isAcceptableOrUnknown(
          data['data_cadastro']!,
          _dataCadastroMeta,
        ),
      );
    }
    if (data.containsKey('data_contabilizado')) {
      context.handle(
        _dataContabilizadoMeta,
        dataContabilizado.isAcceptableOrUnknown(
          data['data_contabilizado']!,
          _dataContabilizadoMeta,
        ),
      );
    }
    if (data.containsKey('data_vistoria')) {
      context.handle(
        _dataVistoriaMeta,
        dataVistoria.isAcceptableOrUnknown(
          data['data_vistoria']!,
          _dataVistoriaMeta,
        ),
      );
    }
    if (data.containsKey('data_marcacao')) {
      context.handle(
        _dataMarcacaoMeta,
        dataMarcacao.isAcceptableOrUnknown(
          data['data_marcacao']!,
          _dataMarcacaoMeta,
        ),
      );
    }
    if (data.containsKey('data_baixa')) {
      context.handle(
        _dataBaixaMeta,
        dataBaixa.isAcceptableOrUnknown(data['data_baixa']!, _dataBaixaMeta),
      );
    }
    if (data.containsKey('vencimento_garantia')) {
      context.handle(
        _vencimentoGarantiaMeta,
        vencimentoGarantia.isAcceptableOrUnknown(
          data['vencimento_garantia']!,
          _vencimentoGarantiaMeta,
        ),
      );
    }
    if (data.containsKey('numero_nota_fiscal')) {
      context.handle(
        _numeroNotaFiscalMeta,
        numeroNotaFiscal.isAcceptableOrUnknown(
          data['numero_nota_fiscal']!,
          _numeroNotaFiscalMeta,
        ),
      );
    }
    if (data.containsKey('chave_nfe')) {
      context.handle(
        _chaveNfeMeta,
        chaveNfe.isAcceptableOrUnknown(data['chave_nfe']!, _chaveNfeMeta),
      );
    }
    if (data.containsKey('valor_original')) {
      context.handle(
        _valorOriginalMeta,
        valorOriginal.isAcceptableOrUnknown(
          data['valor_original']!,
          _valorOriginalMeta,
        ),
      );
    }
    if (data.containsKey('valor_compra')) {
      context.handle(
        _valorCompraMeta,
        valorCompra.isAcceptableOrUnknown(
          data['valor_compra']!,
          _valorCompraMeta,
        ),
      );
    }
    if (data.containsKey('valor_atualizado')) {
      context.handle(
        _valorAtualizadoMeta,
        valorAtualizado.isAcceptableOrUnknown(
          data['valor_atualizado']!,
          _valorAtualizadoMeta,
        ),
      );
    }
    if (data.containsKey('valor_baixa')) {
      context.handle(
        _valorBaixaMeta,
        valorBaixa.isAcceptableOrUnknown(data['valor_baixa']!, _valorBaixaMeta),
      );
    }
    if (data.containsKey('deprecia')) {
      context.handle(
        _depreciaMeta,
        deprecia.isAcceptableOrUnknown(data['deprecia']!, _depreciaMeta),
      );
    }
    if (data.containsKey('metodo_depreciacao')) {
      context.handle(
        _metodoDepreciacaoMeta,
        metodoDepreciacao.isAcceptableOrUnknown(
          data['metodo_depreciacao']!,
          _metodoDepreciacaoMeta,
        ),
      );
    }
    if (data.containsKey('inicio_depreciacao')) {
      context.handle(
        _inicioDepreciacaoMeta,
        inicioDepreciacao.isAcceptableOrUnknown(
          data['inicio_depreciacao']!,
          _inicioDepreciacaoMeta,
        ),
      );
    }
    if (data.containsKey('ultima_depreciacao')) {
      context.handle(
        _ultimaDepreciacaoMeta,
        ultimaDepreciacao.isAcceptableOrUnknown(
          data['ultima_depreciacao']!,
          _ultimaDepreciacaoMeta,
        ),
      );
    }
    if (data.containsKey('tipo_depreciacao')) {
      context.handle(
        _tipoDepreciacaoMeta,
        tipoDepreciacao.isAcceptableOrUnknown(
          data['tipo_depreciacao']!,
          _tipoDepreciacaoMeta,
        ),
      );
    }
    if (data.containsKey('taxa_anual_depreciacao')) {
      context.handle(
        _taxaAnualDepreciacaoMeta,
        taxaAnualDepreciacao.isAcceptableOrUnknown(
          data['taxa_anual_depreciacao']!,
          _taxaAnualDepreciacaoMeta,
        ),
      );
    }
    if (data.containsKey('taxa_mensal_depreciacao')) {
      context.handle(
        _taxaMensalDepreciacaoMeta,
        taxaMensalDepreciacao.isAcceptableOrUnknown(
          data['taxa_mensal_depreciacao']!,
          _taxaMensalDepreciacaoMeta,
        ),
      );
    }
    if (data.containsKey('taxa_depreciacao_acelerada')) {
      context.handle(
        _taxaDepreciacaoAceleradaMeta,
        taxaDepreciacaoAcelerada.isAcceptableOrUnknown(
          data['taxa_depreciacao_acelerada']!,
          _taxaDepreciacaoAceleradaMeta,
        ),
      );
    }
    if (data.containsKey('taxa_depreciacao_incentivada')) {
      context.handle(
        _taxaDepreciacaoIncentivadaMeta,
        taxaDepreciacaoIncentivada.isAcceptableOrUnknown(
          data['taxa_depreciacao_incentivada']!,
          _taxaDepreciacaoIncentivadaMeta,
        ),
      );
    }
    if (data.containsKey('funcao')) {
      context.handle(
        _funcaoMeta,
        funcao.isAcceptableOrUnknown(data['funcao']!, _funcaoMeta),
      );
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  PatrimBem map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return PatrimBem(
      id: attachedDatabase.typeMapping.read(
        DriftSqlType.int,
        data['${effectivePrefix}id'],
      ),
      idCentroResultado: attachedDatabase.typeMapping.read(
        DriftSqlType.int,
        data['${effectivePrefix}id_centro_resultado'],
      ),
      idPatrimTipoAquisicaoBem: attachedDatabase.typeMapping.read(
        DriftSqlType.int,
        data['${effectivePrefix}id_patrim_tipo_aquisicao_bem'],
      ),
      idPatrimEstadoConservacao: attachedDatabase.typeMapping.read(
        DriftSqlType.int,
        data['${effectivePrefix}id_patrim_estado_conservacao'],
      ),
      idPatrimGrupoBem: attachedDatabase.typeMapping.read(
        DriftSqlType.int,
        data['${effectivePrefix}id_patrim_grupo_bem'],
      ),
      idFornecedor: attachedDatabase.typeMapping.read(
        DriftSqlType.int,
        data['${effectivePrefix}id_fornecedor'],
      ),
      idSetor: attachedDatabase.typeMapping.read(
        DriftSqlType.int,
        data['${effectivePrefix}id_setor'],
      ),
      numeroNb: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}numero_nb'],
      ),
      nome: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}nome'],
      ),
      descricao: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}descricao'],
      ),
      numeroSerie: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}numero_serie'],
      ),
      dataAquisicao: attachedDatabase.typeMapping.read(
        DriftSqlType.dateTime,
        data['${effectivePrefix}data_aquisicao'],
      ),
      dataAceite: attachedDatabase.typeMapping.read(
        DriftSqlType.dateTime,
        data['${effectivePrefix}data_aceite'],
      ),
      dataCadastro: attachedDatabase.typeMapping.read(
        DriftSqlType.dateTime,
        data['${effectivePrefix}data_cadastro'],
      ),
      dataContabilizado: attachedDatabase.typeMapping.read(
        DriftSqlType.dateTime,
        data['${effectivePrefix}data_contabilizado'],
      ),
      dataVistoria: attachedDatabase.typeMapping.read(
        DriftSqlType.dateTime,
        data['${effectivePrefix}data_vistoria'],
      ),
      dataMarcacao: attachedDatabase.typeMapping.read(
        DriftSqlType.dateTime,
        data['${effectivePrefix}data_marcacao'],
      ),
      dataBaixa: attachedDatabase.typeMapping.read(
        DriftSqlType.dateTime,
        data['${effectivePrefix}data_baixa'],
      ),
      vencimentoGarantia: attachedDatabase.typeMapping.read(
        DriftSqlType.dateTime,
        data['${effectivePrefix}vencimento_garantia'],
      ),
      numeroNotaFiscal: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}numero_nota_fiscal'],
      ),
      chaveNfe: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}chave_nfe'],
      ),
      valorOriginal: attachedDatabase.typeMapping.read(
        DriftSqlType.double,
        data['${effectivePrefix}valor_original'],
      ),
      valorCompra: attachedDatabase.typeMapping.read(
        DriftSqlType.double,
        data['${effectivePrefix}valor_compra'],
      ),
      valorAtualizado: attachedDatabase.typeMapping.read(
        DriftSqlType.double,
        data['${effectivePrefix}valor_atualizado'],
      ),
      valorBaixa: attachedDatabase.typeMapping.read(
        DriftSqlType.double,
        data['${effectivePrefix}valor_baixa'],
      ),
      deprecia: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}deprecia'],
      ),
      metodoDepreciacao: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}metodo_depreciacao'],
      ),
      inicioDepreciacao: attachedDatabase.typeMapping.read(
        DriftSqlType.dateTime,
        data['${effectivePrefix}inicio_depreciacao'],
      ),
      ultimaDepreciacao: attachedDatabase.typeMapping.read(
        DriftSqlType.dateTime,
        data['${effectivePrefix}ultima_depreciacao'],
      ),
      tipoDepreciacao: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}tipo_depreciacao'],
      ),
      taxaAnualDepreciacao: attachedDatabase.typeMapping.read(
        DriftSqlType.double,
        data['${effectivePrefix}taxa_anual_depreciacao'],
      ),
      taxaMensalDepreciacao: attachedDatabase.typeMapping.read(
        DriftSqlType.double,
        data['${effectivePrefix}taxa_mensal_depreciacao'],
      ),
      taxaDepreciacaoAcelerada: attachedDatabase.typeMapping.read(
        DriftSqlType.double,
        data['${effectivePrefix}taxa_depreciacao_acelerada'],
      ),
      taxaDepreciacaoIncentivada: attachedDatabase.typeMapping.read(
        DriftSqlType.double,
        data['${effectivePrefix}taxa_depreciacao_incentivada'],
      ),
      funcao: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}funcao'],
      ),
    );
  }

  @override
  $PatrimBemsTable createAlias(String alias) {
    return $PatrimBemsTable(attachedDatabase, alias);
  }
}

class PatrimBem extends DataClass implements Insertable<PatrimBem> {
  final int? id;
  final int? idCentroResultado;
  final int? idPatrimTipoAquisicaoBem;
  final int? idPatrimEstadoConservacao;
  final int? idPatrimGrupoBem;
  final int? idFornecedor;
  final int? idSetor;
  final String? numeroNb;
  final String? nome;
  final String? descricao;
  final String? numeroSerie;
  final DateTime? dataAquisicao;
  final DateTime? dataAceite;
  final DateTime? dataCadastro;
  final DateTime? dataContabilizado;
  final DateTime? dataVistoria;
  final DateTime? dataMarcacao;
  final DateTime? dataBaixa;
  final DateTime? vencimentoGarantia;
  final String? numeroNotaFiscal;
  final String? chaveNfe;
  final double? valorOriginal;
  final double? valorCompra;
  final double? valorAtualizado;
  final double? valorBaixa;
  final String? deprecia;
  final String? metodoDepreciacao;
  final DateTime? inicioDepreciacao;
  final DateTime? ultimaDepreciacao;
  final String? tipoDepreciacao;
  final double? taxaAnualDepreciacao;
  final double? taxaMensalDepreciacao;
  final double? taxaDepreciacaoAcelerada;
  final double? taxaDepreciacaoIncentivada;
  final String? funcao;
  const PatrimBem({
    this.id,
    this.idCentroResultado,
    this.idPatrimTipoAquisicaoBem,
    this.idPatrimEstadoConservacao,
    this.idPatrimGrupoBem,
    this.idFornecedor,
    this.idSetor,
    this.numeroNb,
    this.nome,
    this.descricao,
    this.numeroSerie,
    this.dataAquisicao,
    this.dataAceite,
    this.dataCadastro,
    this.dataContabilizado,
    this.dataVistoria,
    this.dataMarcacao,
    this.dataBaixa,
    this.vencimentoGarantia,
    this.numeroNotaFiscal,
    this.chaveNfe,
    this.valorOriginal,
    this.valorCompra,
    this.valorAtualizado,
    this.valorBaixa,
    this.deprecia,
    this.metodoDepreciacao,
    this.inicioDepreciacao,
    this.ultimaDepreciacao,
    this.tipoDepreciacao,
    this.taxaAnualDepreciacao,
    this.taxaMensalDepreciacao,
    this.taxaDepreciacaoAcelerada,
    this.taxaDepreciacaoIncentivada,
    this.funcao,
  });
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || idCentroResultado != null) {
      map['id_centro_resultado'] = Variable<int>(idCentroResultado);
    }
    if (!nullToAbsent || idPatrimTipoAquisicaoBem != null) {
      map['id_patrim_tipo_aquisicao_bem'] = Variable<int>(
        idPatrimTipoAquisicaoBem,
      );
    }
    if (!nullToAbsent || idPatrimEstadoConservacao != null) {
      map['id_patrim_estado_conservacao'] = Variable<int>(
        idPatrimEstadoConservacao,
      );
    }
    if (!nullToAbsent || idPatrimGrupoBem != null) {
      map['id_patrim_grupo_bem'] = Variable<int>(idPatrimGrupoBem);
    }
    if (!nullToAbsent || idFornecedor != null) {
      map['id_fornecedor'] = Variable<int>(idFornecedor);
    }
    if (!nullToAbsent || idSetor != null) {
      map['id_setor'] = Variable<int>(idSetor);
    }
    if (!nullToAbsent || numeroNb != null) {
      map['numero_nb'] = Variable<String>(numeroNb);
    }
    if (!nullToAbsent || nome != null) {
      map['nome'] = Variable<String>(nome);
    }
    if (!nullToAbsent || descricao != null) {
      map['descricao'] = Variable<String>(descricao);
    }
    if (!nullToAbsent || numeroSerie != null) {
      map['numero_serie'] = Variable<String>(numeroSerie);
    }
    if (!nullToAbsent || dataAquisicao != null) {
      map['data_aquisicao'] = Variable<DateTime>(dataAquisicao);
    }
    if (!nullToAbsent || dataAceite != null) {
      map['data_aceite'] = Variable<DateTime>(dataAceite);
    }
    if (!nullToAbsent || dataCadastro != null) {
      map['data_cadastro'] = Variable<DateTime>(dataCadastro);
    }
    if (!nullToAbsent || dataContabilizado != null) {
      map['data_contabilizado'] = Variable<DateTime>(dataContabilizado);
    }
    if (!nullToAbsent || dataVistoria != null) {
      map['data_vistoria'] = Variable<DateTime>(dataVistoria);
    }
    if (!nullToAbsent || dataMarcacao != null) {
      map['data_marcacao'] = Variable<DateTime>(dataMarcacao);
    }
    if (!nullToAbsent || dataBaixa != null) {
      map['data_baixa'] = Variable<DateTime>(dataBaixa);
    }
    if (!nullToAbsent || vencimentoGarantia != null) {
      map['vencimento_garantia'] = Variable<DateTime>(vencimentoGarantia);
    }
    if (!nullToAbsent || numeroNotaFiscal != null) {
      map['numero_nota_fiscal'] = Variable<String>(numeroNotaFiscal);
    }
    if (!nullToAbsent || chaveNfe != null) {
      map['chave_nfe'] = Variable<String>(chaveNfe);
    }
    if (!nullToAbsent || valorOriginal != null) {
      map['valor_original'] = Variable<double>(valorOriginal);
    }
    if (!nullToAbsent || valorCompra != null) {
      map['valor_compra'] = Variable<double>(valorCompra);
    }
    if (!nullToAbsent || valorAtualizado != null) {
      map['valor_atualizado'] = Variable<double>(valorAtualizado);
    }
    if (!nullToAbsent || valorBaixa != null) {
      map['valor_baixa'] = Variable<double>(valorBaixa);
    }
    if (!nullToAbsent || deprecia != null) {
      map['deprecia'] = Variable<String>(deprecia);
    }
    if (!nullToAbsent || metodoDepreciacao != null) {
      map['metodo_depreciacao'] = Variable<String>(metodoDepreciacao);
    }
    if (!nullToAbsent || inicioDepreciacao != null) {
      map['inicio_depreciacao'] = Variable<DateTime>(inicioDepreciacao);
    }
    if (!nullToAbsent || ultimaDepreciacao != null) {
      map['ultima_depreciacao'] = Variable<DateTime>(ultimaDepreciacao);
    }
    if (!nullToAbsent || tipoDepreciacao != null) {
      map['tipo_depreciacao'] = Variable<String>(tipoDepreciacao);
    }
    if (!nullToAbsent || taxaAnualDepreciacao != null) {
      map['taxa_anual_depreciacao'] = Variable<double>(taxaAnualDepreciacao);
    }
    if (!nullToAbsent || taxaMensalDepreciacao != null) {
      map['taxa_mensal_depreciacao'] = Variable<double>(taxaMensalDepreciacao);
    }
    if (!nullToAbsent || taxaDepreciacaoAcelerada != null) {
      map['taxa_depreciacao_acelerada'] = Variable<double>(
        taxaDepreciacaoAcelerada,
      );
    }
    if (!nullToAbsent || taxaDepreciacaoIncentivada != null) {
      map['taxa_depreciacao_incentivada'] = Variable<double>(
        taxaDepreciacaoIncentivada,
      );
    }
    if (!nullToAbsent || funcao != null) {
      map['funcao'] = Variable<String>(funcao);
    }
    return map;
  }

  factory PatrimBem.fromJson(
    Map<String, dynamic> json, {
    ValueSerializer? serializer,
  }) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return PatrimBem(
      id: serializer.fromJson<int?>(json['id']),
      idCentroResultado: serializer.fromJson<int?>(json['idCentroResultado']),
      idPatrimTipoAquisicaoBem: serializer.fromJson<int?>(
        json['idPatrimTipoAquisicaoBem'],
      ),
      idPatrimEstadoConservacao: serializer.fromJson<int?>(
        json['idPatrimEstadoConservacao'],
      ),
      idPatrimGrupoBem: serializer.fromJson<int?>(json['idPatrimGrupoBem']),
      idFornecedor: serializer.fromJson<int?>(json['idFornecedor']),
      idSetor: serializer.fromJson<int?>(json['idSetor']),
      numeroNb: serializer.fromJson<String?>(json['numeroNb']),
      nome: serializer.fromJson<String?>(json['nome']),
      descricao: serializer.fromJson<String?>(json['descricao']),
      numeroSerie: serializer.fromJson<String?>(json['numeroSerie']),
      dataAquisicao: serializer.fromJson<DateTime?>(json['dataAquisicao']),
      dataAceite: serializer.fromJson<DateTime?>(json['dataAceite']),
      dataCadastro: serializer.fromJson<DateTime?>(json['dataCadastro']),
      dataContabilizado: serializer.fromJson<DateTime?>(
        json['dataContabilizado'],
      ),
      dataVistoria: serializer.fromJson<DateTime?>(json['dataVistoria']),
      dataMarcacao: serializer.fromJson<DateTime?>(json['dataMarcacao']),
      dataBaixa: serializer.fromJson<DateTime?>(json['dataBaixa']),
      vencimentoGarantia: serializer.fromJson<DateTime?>(
        json['vencimentoGarantia'],
      ),
      numeroNotaFiscal: serializer.fromJson<String?>(json['numeroNotaFiscal']),
      chaveNfe: serializer.fromJson<String?>(json['chaveNfe']),
      valorOriginal: serializer.fromJson<double?>(json['valorOriginal']),
      valorCompra: serializer.fromJson<double?>(json['valorCompra']),
      valorAtualizado: serializer.fromJson<double?>(json['valorAtualizado']),
      valorBaixa: serializer.fromJson<double?>(json['valorBaixa']),
      deprecia: serializer.fromJson<String?>(json['deprecia']),
      metodoDepreciacao: serializer.fromJson<String?>(
        json['metodoDepreciacao'],
      ),
      inicioDepreciacao: serializer.fromJson<DateTime?>(
        json['inicioDepreciacao'],
      ),
      ultimaDepreciacao: serializer.fromJson<DateTime?>(
        json['ultimaDepreciacao'],
      ),
      tipoDepreciacao: serializer.fromJson<String?>(json['tipoDepreciacao']),
      taxaAnualDepreciacao: serializer.fromJson<double?>(
        json['taxaAnualDepreciacao'],
      ),
      taxaMensalDepreciacao: serializer.fromJson<double?>(
        json['taxaMensalDepreciacao'],
      ),
      taxaDepreciacaoAcelerada: serializer.fromJson<double?>(
        json['taxaDepreciacaoAcelerada'],
      ),
      taxaDepreciacaoIncentivada: serializer.fromJson<double?>(
        json['taxaDepreciacaoIncentivada'],
      ),
      funcao: serializer.fromJson<String?>(json['funcao']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'idCentroResultado': serializer.toJson<int?>(idCentroResultado),
      'idPatrimTipoAquisicaoBem': serializer.toJson<int?>(
        idPatrimTipoAquisicaoBem,
      ),
      'idPatrimEstadoConservacao': serializer.toJson<int?>(
        idPatrimEstadoConservacao,
      ),
      'idPatrimGrupoBem': serializer.toJson<int?>(idPatrimGrupoBem),
      'idFornecedor': serializer.toJson<int?>(idFornecedor),
      'idSetor': serializer.toJson<int?>(idSetor),
      'numeroNb': serializer.toJson<String?>(numeroNb),
      'nome': serializer.toJson<String?>(nome),
      'descricao': serializer.toJson<String?>(descricao),
      'numeroSerie': serializer.toJson<String?>(numeroSerie),
      'dataAquisicao': serializer.toJson<DateTime?>(dataAquisicao),
      'dataAceite': serializer.toJson<DateTime?>(dataAceite),
      'dataCadastro': serializer.toJson<DateTime?>(dataCadastro),
      'dataContabilizado': serializer.toJson<DateTime?>(dataContabilizado),
      'dataVistoria': serializer.toJson<DateTime?>(dataVistoria),
      'dataMarcacao': serializer.toJson<DateTime?>(dataMarcacao),
      'dataBaixa': serializer.toJson<DateTime?>(dataBaixa),
      'vencimentoGarantia': serializer.toJson<DateTime?>(vencimentoGarantia),
      'numeroNotaFiscal': serializer.toJson<String?>(numeroNotaFiscal),
      'chaveNfe': serializer.toJson<String?>(chaveNfe),
      'valorOriginal': serializer.toJson<double?>(valorOriginal),
      'valorCompra': serializer.toJson<double?>(valorCompra),
      'valorAtualizado': serializer.toJson<double?>(valorAtualizado),
      'valorBaixa': serializer.toJson<double?>(valorBaixa),
      'deprecia': serializer.toJson<String?>(deprecia),
      'metodoDepreciacao': serializer.toJson<String?>(metodoDepreciacao),
      'inicioDepreciacao': serializer.toJson<DateTime?>(inicioDepreciacao),
      'ultimaDepreciacao': serializer.toJson<DateTime?>(ultimaDepreciacao),
      'tipoDepreciacao': serializer.toJson<String?>(tipoDepreciacao),
      'taxaAnualDepreciacao': serializer.toJson<double?>(taxaAnualDepreciacao),
      'taxaMensalDepreciacao': serializer.toJson<double?>(
        taxaMensalDepreciacao,
      ),
      'taxaDepreciacaoAcelerada': serializer.toJson<double?>(
        taxaDepreciacaoAcelerada,
      ),
      'taxaDepreciacaoIncentivada': serializer.toJson<double?>(
        taxaDepreciacaoIncentivada,
      ),
      'funcao': serializer.toJson<String?>(funcao),
    };
  }

  PatrimBem copyWith({
    Value<int?> id = const Value.absent(),
    Value<int?> idCentroResultado = const Value.absent(),
    Value<int?> idPatrimTipoAquisicaoBem = const Value.absent(),
    Value<int?> idPatrimEstadoConservacao = const Value.absent(),
    Value<int?> idPatrimGrupoBem = const Value.absent(),
    Value<int?> idFornecedor = const Value.absent(),
    Value<int?> idSetor = const Value.absent(),
    Value<String?> numeroNb = const Value.absent(),
    Value<String?> nome = const Value.absent(),
    Value<String?> descricao = const Value.absent(),
    Value<String?> numeroSerie = const Value.absent(),
    Value<DateTime?> dataAquisicao = const Value.absent(),
    Value<DateTime?> dataAceite = const Value.absent(),
    Value<DateTime?> dataCadastro = const Value.absent(),
    Value<DateTime?> dataContabilizado = const Value.absent(),
    Value<DateTime?> dataVistoria = const Value.absent(),
    Value<DateTime?> dataMarcacao = const Value.absent(),
    Value<DateTime?> dataBaixa = const Value.absent(),
    Value<DateTime?> vencimentoGarantia = const Value.absent(),
    Value<String?> numeroNotaFiscal = const Value.absent(),
    Value<String?> chaveNfe = const Value.absent(),
    Value<double?> valorOriginal = const Value.absent(),
    Value<double?> valorCompra = const Value.absent(),
    Value<double?> valorAtualizado = const Value.absent(),
    Value<double?> valorBaixa = const Value.absent(),
    Value<String?> deprecia = const Value.absent(),
    Value<String?> metodoDepreciacao = const Value.absent(),
    Value<DateTime?> inicioDepreciacao = const Value.absent(),
    Value<DateTime?> ultimaDepreciacao = const Value.absent(),
    Value<String?> tipoDepreciacao = const Value.absent(),
    Value<double?> taxaAnualDepreciacao = const Value.absent(),
    Value<double?> taxaMensalDepreciacao = const Value.absent(),
    Value<double?> taxaDepreciacaoAcelerada = const Value.absent(),
    Value<double?> taxaDepreciacaoIncentivada = const Value.absent(),
    Value<String?> funcao = const Value.absent(),
  }) => PatrimBem(
    id: id.present ? id.value : this.id,
    idCentroResultado:
        idCentroResultado.present
            ? idCentroResultado.value
            : this.idCentroResultado,
    idPatrimTipoAquisicaoBem:
        idPatrimTipoAquisicaoBem.present
            ? idPatrimTipoAquisicaoBem.value
            : this.idPatrimTipoAquisicaoBem,
    idPatrimEstadoConservacao:
        idPatrimEstadoConservacao.present
            ? idPatrimEstadoConservacao.value
            : this.idPatrimEstadoConservacao,
    idPatrimGrupoBem:
        idPatrimGrupoBem.present
            ? idPatrimGrupoBem.value
            : this.idPatrimGrupoBem,
    idFornecedor: idFornecedor.present ? idFornecedor.value : this.idFornecedor,
    idSetor: idSetor.present ? idSetor.value : this.idSetor,
    numeroNb: numeroNb.present ? numeroNb.value : this.numeroNb,
    nome: nome.present ? nome.value : this.nome,
    descricao: descricao.present ? descricao.value : this.descricao,
    numeroSerie: numeroSerie.present ? numeroSerie.value : this.numeroSerie,
    dataAquisicao:
        dataAquisicao.present ? dataAquisicao.value : this.dataAquisicao,
    dataAceite: dataAceite.present ? dataAceite.value : this.dataAceite,
    dataCadastro: dataCadastro.present ? dataCadastro.value : this.dataCadastro,
    dataContabilizado:
        dataContabilizado.present
            ? dataContabilizado.value
            : this.dataContabilizado,
    dataVistoria: dataVistoria.present ? dataVistoria.value : this.dataVistoria,
    dataMarcacao: dataMarcacao.present ? dataMarcacao.value : this.dataMarcacao,
    dataBaixa: dataBaixa.present ? dataBaixa.value : this.dataBaixa,
    vencimentoGarantia:
        vencimentoGarantia.present
            ? vencimentoGarantia.value
            : this.vencimentoGarantia,
    numeroNotaFiscal:
        numeroNotaFiscal.present
            ? numeroNotaFiscal.value
            : this.numeroNotaFiscal,
    chaveNfe: chaveNfe.present ? chaveNfe.value : this.chaveNfe,
    valorOriginal:
        valorOriginal.present ? valorOriginal.value : this.valorOriginal,
    valorCompra: valorCompra.present ? valorCompra.value : this.valorCompra,
    valorAtualizado:
        valorAtualizado.present ? valorAtualizado.value : this.valorAtualizado,
    valorBaixa: valorBaixa.present ? valorBaixa.value : this.valorBaixa,
    deprecia: deprecia.present ? deprecia.value : this.deprecia,
    metodoDepreciacao:
        metodoDepreciacao.present
            ? metodoDepreciacao.value
            : this.metodoDepreciacao,
    inicioDepreciacao:
        inicioDepreciacao.present
            ? inicioDepreciacao.value
            : this.inicioDepreciacao,
    ultimaDepreciacao:
        ultimaDepreciacao.present
            ? ultimaDepreciacao.value
            : this.ultimaDepreciacao,
    tipoDepreciacao:
        tipoDepreciacao.present ? tipoDepreciacao.value : this.tipoDepreciacao,
    taxaAnualDepreciacao:
        taxaAnualDepreciacao.present
            ? taxaAnualDepreciacao.value
            : this.taxaAnualDepreciacao,
    taxaMensalDepreciacao:
        taxaMensalDepreciacao.present
            ? taxaMensalDepreciacao.value
            : this.taxaMensalDepreciacao,
    taxaDepreciacaoAcelerada:
        taxaDepreciacaoAcelerada.present
            ? taxaDepreciacaoAcelerada.value
            : this.taxaDepreciacaoAcelerada,
    taxaDepreciacaoIncentivada:
        taxaDepreciacaoIncentivada.present
            ? taxaDepreciacaoIncentivada.value
            : this.taxaDepreciacaoIncentivada,
    funcao: funcao.present ? funcao.value : this.funcao,
  );
  PatrimBem copyWithCompanion(PatrimBemsCompanion data) {
    return PatrimBem(
      id: data.id.present ? data.id.value : this.id,
      idCentroResultado:
          data.idCentroResultado.present
              ? data.idCentroResultado.value
              : this.idCentroResultado,
      idPatrimTipoAquisicaoBem:
          data.idPatrimTipoAquisicaoBem.present
              ? data.idPatrimTipoAquisicaoBem.value
              : this.idPatrimTipoAquisicaoBem,
      idPatrimEstadoConservacao:
          data.idPatrimEstadoConservacao.present
              ? data.idPatrimEstadoConservacao.value
              : this.idPatrimEstadoConservacao,
      idPatrimGrupoBem:
          data.idPatrimGrupoBem.present
              ? data.idPatrimGrupoBem.value
              : this.idPatrimGrupoBem,
      idFornecedor:
          data.idFornecedor.present
              ? data.idFornecedor.value
              : this.idFornecedor,
      idSetor: data.idSetor.present ? data.idSetor.value : this.idSetor,
      numeroNb: data.numeroNb.present ? data.numeroNb.value : this.numeroNb,
      nome: data.nome.present ? data.nome.value : this.nome,
      descricao: data.descricao.present ? data.descricao.value : this.descricao,
      numeroSerie:
          data.numeroSerie.present ? data.numeroSerie.value : this.numeroSerie,
      dataAquisicao:
          data.dataAquisicao.present
              ? data.dataAquisicao.value
              : this.dataAquisicao,
      dataAceite:
          data.dataAceite.present ? data.dataAceite.value : this.dataAceite,
      dataCadastro:
          data.dataCadastro.present
              ? data.dataCadastro.value
              : this.dataCadastro,
      dataContabilizado:
          data.dataContabilizado.present
              ? data.dataContabilizado.value
              : this.dataContabilizado,
      dataVistoria:
          data.dataVistoria.present
              ? data.dataVistoria.value
              : this.dataVistoria,
      dataMarcacao:
          data.dataMarcacao.present
              ? data.dataMarcacao.value
              : this.dataMarcacao,
      dataBaixa: data.dataBaixa.present ? data.dataBaixa.value : this.dataBaixa,
      vencimentoGarantia:
          data.vencimentoGarantia.present
              ? data.vencimentoGarantia.value
              : this.vencimentoGarantia,
      numeroNotaFiscal:
          data.numeroNotaFiscal.present
              ? data.numeroNotaFiscal.value
              : this.numeroNotaFiscal,
      chaveNfe: data.chaveNfe.present ? data.chaveNfe.value : this.chaveNfe,
      valorOriginal:
          data.valorOriginal.present
              ? data.valorOriginal.value
              : this.valorOriginal,
      valorCompra:
          data.valorCompra.present ? data.valorCompra.value : this.valorCompra,
      valorAtualizado:
          data.valorAtualizado.present
              ? data.valorAtualizado.value
              : this.valorAtualizado,
      valorBaixa:
          data.valorBaixa.present ? data.valorBaixa.value : this.valorBaixa,
      deprecia: data.deprecia.present ? data.deprecia.value : this.deprecia,
      metodoDepreciacao:
          data.metodoDepreciacao.present
              ? data.metodoDepreciacao.value
              : this.metodoDepreciacao,
      inicioDepreciacao:
          data.inicioDepreciacao.present
              ? data.inicioDepreciacao.value
              : this.inicioDepreciacao,
      ultimaDepreciacao:
          data.ultimaDepreciacao.present
              ? data.ultimaDepreciacao.value
              : this.ultimaDepreciacao,
      tipoDepreciacao:
          data.tipoDepreciacao.present
              ? data.tipoDepreciacao.value
              : this.tipoDepreciacao,
      taxaAnualDepreciacao:
          data.taxaAnualDepreciacao.present
              ? data.taxaAnualDepreciacao.value
              : this.taxaAnualDepreciacao,
      taxaMensalDepreciacao:
          data.taxaMensalDepreciacao.present
              ? data.taxaMensalDepreciacao.value
              : this.taxaMensalDepreciacao,
      taxaDepreciacaoAcelerada:
          data.taxaDepreciacaoAcelerada.present
              ? data.taxaDepreciacaoAcelerada.value
              : this.taxaDepreciacaoAcelerada,
      taxaDepreciacaoIncentivada:
          data.taxaDepreciacaoIncentivada.present
              ? data.taxaDepreciacaoIncentivada.value
              : this.taxaDepreciacaoIncentivada,
      funcao: data.funcao.present ? data.funcao.value : this.funcao,
    );
  }

  @override
  String toString() {
    return (StringBuffer('PatrimBem(')
          ..write('id: $id, ')
          ..write('idCentroResultado: $idCentroResultado, ')
          ..write('idPatrimTipoAquisicaoBem: $idPatrimTipoAquisicaoBem, ')
          ..write('idPatrimEstadoConservacao: $idPatrimEstadoConservacao, ')
          ..write('idPatrimGrupoBem: $idPatrimGrupoBem, ')
          ..write('idFornecedor: $idFornecedor, ')
          ..write('idSetor: $idSetor, ')
          ..write('numeroNb: $numeroNb, ')
          ..write('nome: $nome, ')
          ..write('descricao: $descricao, ')
          ..write('numeroSerie: $numeroSerie, ')
          ..write('dataAquisicao: $dataAquisicao, ')
          ..write('dataAceite: $dataAceite, ')
          ..write('dataCadastro: $dataCadastro, ')
          ..write('dataContabilizado: $dataContabilizado, ')
          ..write('dataVistoria: $dataVistoria, ')
          ..write('dataMarcacao: $dataMarcacao, ')
          ..write('dataBaixa: $dataBaixa, ')
          ..write('vencimentoGarantia: $vencimentoGarantia, ')
          ..write('numeroNotaFiscal: $numeroNotaFiscal, ')
          ..write('chaveNfe: $chaveNfe, ')
          ..write('valorOriginal: $valorOriginal, ')
          ..write('valorCompra: $valorCompra, ')
          ..write('valorAtualizado: $valorAtualizado, ')
          ..write('valorBaixa: $valorBaixa, ')
          ..write('deprecia: $deprecia, ')
          ..write('metodoDepreciacao: $metodoDepreciacao, ')
          ..write('inicioDepreciacao: $inicioDepreciacao, ')
          ..write('ultimaDepreciacao: $ultimaDepreciacao, ')
          ..write('tipoDepreciacao: $tipoDepreciacao, ')
          ..write('taxaAnualDepreciacao: $taxaAnualDepreciacao, ')
          ..write('taxaMensalDepreciacao: $taxaMensalDepreciacao, ')
          ..write('taxaDepreciacaoAcelerada: $taxaDepreciacaoAcelerada, ')
          ..write('taxaDepreciacaoIncentivada: $taxaDepreciacaoIncentivada, ')
          ..write('funcao: $funcao')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hashAll([
    id,
    idCentroResultado,
    idPatrimTipoAquisicaoBem,
    idPatrimEstadoConservacao,
    idPatrimGrupoBem,
    idFornecedor,
    idSetor,
    numeroNb,
    nome,
    descricao,
    numeroSerie,
    dataAquisicao,
    dataAceite,
    dataCadastro,
    dataContabilizado,
    dataVistoria,
    dataMarcacao,
    dataBaixa,
    vencimentoGarantia,
    numeroNotaFiscal,
    chaveNfe,
    valorOriginal,
    valorCompra,
    valorAtualizado,
    valorBaixa,
    deprecia,
    metodoDepreciacao,
    inicioDepreciacao,
    ultimaDepreciacao,
    tipoDepreciacao,
    taxaAnualDepreciacao,
    taxaMensalDepreciacao,
    taxaDepreciacaoAcelerada,
    taxaDepreciacaoIncentivada,
    funcao,
  ]);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is PatrimBem &&
          other.id == this.id &&
          other.idCentroResultado == this.idCentroResultado &&
          other.idPatrimTipoAquisicaoBem == this.idPatrimTipoAquisicaoBem &&
          other.idPatrimEstadoConservacao == this.idPatrimEstadoConservacao &&
          other.idPatrimGrupoBem == this.idPatrimGrupoBem &&
          other.idFornecedor == this.idFornecedor &&
          other.idSetor == this.idSetor &&
          other.numeroNb == this.numeroNb &&
          other.nome == this.nome &&
          other.descricao == this.descricao &&
          other.numeroSerie == this.numeroSerie &&
          other.dataAquisicao == this.dataAquisicao &&
          other.dataAceite == this.dataAceite &&
          other.dataCadastro == this.dataCadastro &&
          other.dataContabilizado == this.dataContabilizado &&
          other.dataVistoria == this.dataVistoria &&
          other.dataMarcacao == this.dataMarcacao &&
          other.dataBaixa == this.dataBaixa &&
          other.vencimentoGarantia == this.vencimentoGarantia &&
          other.numeroNotaFiscal == this.numeroNotaFiscal &&
          other.chaveNfe == this.chaveNfe &&
          other.valorOriginal == this.valorOriginal &&
          other.valorCompra == this.valorCompra &&
          other.valorAtualizado == this.valorAtualizado &&
          other.valorBaixa == this.valorBaixa &&
          other.deprecia == this.deprecia &&
          other.metodoDepreciacao == this.metodoDepreciacao &&
          other.inicioDepreciacao == this.inicioDepreciacao &&
          other.ultimaDepreciacao == this.ultimaDepreciacao &&
          other.tipoDepreciacao == this.tipoDepreciacao &&
          other.taxaAnualDepreciacao == this.taxaAnualDepreciacao &&
          other.taxaMensalDepreciacao == this.taxaMensalDepreciacao &&
          other.taxaDepreciacaoAcelerada == this.taxaDepreciacaoAcelerada &&
          other.taxaDepreciacaoIncentivada == this.taxaDepreciacaoIncentivada &&
          other.funcao == this.funcao);
}

class PatrimBemsCompanion extends UpdateCompanion<PatrimBem> {
  final Value<int?> id;
  final Value<int?> idCentroResultado;
  final Value<int?> idPatrimTipoAquisicaoBem;
  final Value<int?> idPatrimEstadoConservacao;
  final Value<int?> idPatrimGrupoBem;
  final Value<int?> idFornecedor;
  final Value<int?> idSetor;
  final Value<String?> numeroNb;
  final Value<String?> nome;
  final Value<String?> descricao;
  final Value<String?> numeroSerie;
  final Value<DateTime?> dataAquisicao;
  final Value<DateTime?> dataAceite;
  final Value<DateTime?> dataCadastro;
  final Value<DateTime?> dataContabilizado;
  final Value<DateTime?> dataVistoria;
  final Value<DateTime?> dataMarcacao;
  final Value<DateTime?> dataBaixa;
  final Value<DateTime?> vencimentoGarantia;
  final Value<String?> numeroNotaFiscal;
  final Value<String?> chaveNfe;
  final Value<double?> valorOriginal;
  final Value<double?> valorCompra;
  final Value<double?> valorAtualizado;
  final Value<double?> valorBaixa;
  final Value<String?> deprecia;
  final Value<String?> metodoDepreciacao;
  final Value<DateTime?> inicioDepreciacao;
  final Value<DateTime?> ultimaDepreciacao;
  final Value<String?> tipoDepreciacao;
  final Value<double?> taxaAnualDepreciacao;
  final Value<double?> taxaMensalDepreciacao;
  final Value<double?> taxaDepreciacaoAcelerada;
  final Value<double?> taxaDepreciacaoIncentivada;
  final Value<String?> funcao;
  const PatrimBemsCompanion({
    this.id = const Value.absent(),
    this.idCentroResultado = const Value.absent(),
    this.idPatrimTipoAquisicaoBem = const Value.absent(),
    this.idPatrimEstadoConservacao = const Value.absent(),
    this.idPatrimGrupoBem = const Value.absent(),
    this.idFornecedor = const Value.absent(),
    this.idSetor = const Value.absent(),
    this.numeroNb = const Value.absent(),
    this.nome = const Value.absent(),
    this.descricao = const Value.absent(),
    this.numeroSerie = const Value.absent(),
    this.dataAquisicao = const Value.absent(),
    this.dataAceite = const Value.absent(),
    this.dataCadastro = const Value.absent(),
    this.dataContabilizado = const Value.absent(),
    this.dataVistoria = const Value.absent(),
    this.dataMarcacao = const Value.absent(),
    this.dataBaixa = const Value.absent(),
    this.vencimentoGarantia = const Value.absent(),
    this.numeroNotaFiscal = const Value.absent(),
    this.chaveNfe = const Value.absent(),
    this.valorOriginal = const Value.absent(),
    this.valorCompra = const Value.absent(),
    this.valorAtualizado = const Value.absent(),
    this.valorBaixa = const Value.absent(),
    this.deprecia = const Value.absent(),
    this.metodoDepreciacao = const Value.absent(),
    this.inicioDepreciacao = const Value.absent(),
    this.ultimaDepreciacao = const Value.absent(),
    this.tipoDepreciacao = const Value.absent(),
    this.taxaAnualDepreciacao = const Value.absent(),
    this.taxaMensalDepreciacao = const Value.absent(),
    this.taxaDepreciacaoAcelerada = const Value.absent(),
    this.taxaDepreciacaoIncentivada = const Value.absent(),
    this.funcao = const Value.absent(),
  });
  PatrimBemsCompanion.insert({
    this.id = const Value.absent(),
    this.idCentroResultado = const Value.absent(),
    this.idPatrimTipoAquisicaoBem = const Value.absent(),
    this.idPatrimEstadoConservacao = const Value.absent(),
    this.idPatrimGrupoBem = const Value.absent(),
    this.idFornecedor = const Value.absent(),
    this.idSetor = const Value.absent(),
    this.numeroNb = const Value.absent(),
    this.nome = const Value.absent(),
    this.descricao = const Value.absent(),
    this.numeroSerie = const Value.absent(),
    this.dataAquisicao = const Value.absent(),
    this.dataAceite = const Value.absent(),
    this.dataCadastro = const Value.absent(),
    this.dataContabilizado = const Value.absent(),
    this.dataVistoria = const Value.absent(),
    this.dataMarcacao = const Value.absent(),
    this.dataBaixa = const Value.absent(),
    this.vencimentoGarantia = const Value.absent(),
    this.numeroNotaFiscal = const Value.absent(),
    this.chaveNfe = const Value.absent(),
    this.valorOriginal = const Value.absent(),
    this.valorCompra = const Value.absent(),
    this.valorAtualizado = const Value.absent(),
    this.valorBaixa = const Value.absent(),
    this.deprecia = const Value.absent(),
    this.metodoDepreciacao = const Value.absent(),
    this.inicioDepreciacao = const Value.absent(),
    this.ultimaDepreciacao = const Value.absent(),
    this.tipoDepreciacao = const Value.absent(),
    this.taxaAnualDepreciacao = const Value.absent(),
    this.taxaMensalDepreciacao = const Value.absent(),
    this.taxaDepreciacaoAcelerada = const Value.absent(),
    this.taxaDepreciacaoIncentivada = const Value.absent(),
    this.funcao = const Value.absent(),
  });
  static Insertable<PatrimBem> custom({
    Expression<int>? id,
    Expression<int>? idCentroResultado,
    Expression<int>? idPatrimTipoAquisicaoBem,
    Expression<int>? idPatrimEstadoConservacao,
    Expression<int>? idPatrimGrupoBem,
    Expression<int>? idFornecedor,
    Expression<int>? idSetor,
    Expression<String>? numeroNb,
    Expression<String>? nome,
    Expression<String>? descricao,
    Expression<String>? numeroSerie,
    Expression<DateTime>? dataAquisicao,
    Expression<DateTime>? dataAceite,
    Expression<DateTime>? dataCadastro,
    Expression<DateTime>? dataContabilizado,
    Expression<DateTime>? dataVistoria,
    Expression<DateTime>? dataMarcacao,
    Expression<DateTime>? dataBaixa,
    Expression<DateTime>? vencimentoGarantia,
    Expression<String>? numeroNotaFiscal,
    Expression<String>? chaveNfe,
    Expression<double>? valorOriginal,
    Expression<double>? valorCompra,
    Expression<double>? valorAtualizado,
    Expression<double>? valorBaixa,
    Expression<String>? deprecia,
    Expression<String>? metodoDepreciacao,
    Expression<DateTime>? inicioDepreciacao,
    Expression<DateTime>? ultimaDepreciacao,
    Expression<String>? tipoDepreciacao,
    Expression<double>? taxaAnualDepreciacao,
    Expression<double>? taxaMensalDepreciacao,
    Expression<double>? taxaDepreciacaoAcelerada,
    Expression<double>? taxaDepreciacaoIncentivada,
    Expression<String>? funcao,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (idCentroResultado != null) 'id_centro_resultado': idCentroResultado,
      if (idPatrimTipoAquisicaoBem != null)
        'id_patrim_tipo_aquisicao_bem': idPatrimTipoAquisicaoBem,
      if (idPatrimEstadoConservacao != null)
        'id_patrim_estado_conservacao': idPatrimEstadoConservacao,
      if (idPatrimGrupoBem != null) 'id_patrim_grupo_bem': idPatrimGrupoBem,
      if (idFornecedor != null) 'id_fornecedor': idFornecedor,
      if (idSetor != null) 'id_setor': idSetor,
      if (numeroNb != null) 'numero_nb': numeroNb,
      if (nome != null) 'nome': nome,
      if (descricao != null) 'descricao': descricao,
      if (numeroSerie != null) 'numero_serie': numeroSerie,
      if (dataAquisicao != null) 'data_aquisicao': dataAquisicao,
      if (dataAceite != null) 'data_aceite': dataAceite,
      if (dataCadastro != null) 'data_cadastro': dataCadastro,
      if (dataContabilizado != null) 'data_contabilizado': dataContabilizado,
      if (dataVistoria != null) 'data_vistoria': dataVistoria,
      if (dataMarcacao != null) 'data_marcacao': dataMarcacao,
      if (dataBaixa != null) 'data_baixa': dataBaixa,
      if (vencimentoGarantia != null) 'vencimento_garantia': vencimentoGarantia,
      if (numeroNotaFiscal != null) 'numero_nota_fiscal': numeroNotaFiscal,
      if (chaveNfe != null) 'chave_nfe': chaveNfe,
      if (valorOriginal != null) 'valor_original': valorOriginal,
      if (valorCompra != null) 'valor_compra': valorCompra,
      if (valorAtualizado != null) 'valor_atualizado': valorAtualizado,
      if (valorBaixa != null) 'valor_baixa': valorBaixa,
      if (deprecia != null) 'deprecia': deprecia,
      if (metodoDepreciacao != null) 'metodo_depreciacao': metodoDepreciacao,
      if (inicioDepreciacao != null) 'inicio_depreciacao': inicioDepreciacao,
      if (ultimaDepreciacao != null) 'ultima_depreciacao': ultimaDepreciacao,
      if (tipoDepreciacao != null) 'tipo_depreciacao': tipoDepreciacao,
      if (taxaAnualDepreciacao != null)
        'taxa_anual_depreciacao': taxaAnualDepreciacao,
      if (taxaMensalDepreciacao != null)
        'taxa_mensal_depreciacao': taxaMensalDepreciacao,
      if (taxaDepreciacaoAcelerada != null)
        'taxa_depreciacao_acelerada': taxaDepreciacaoAcelerada,
      if (taxaDepreciacaoIncentivada != null)
        'taxa_depreciacao_incentivada': taxaDepreciacaoIncentivada,
      if (funcao != null) 'funcao': funcao,
    });
  }

  PatrimBemsCompanion copyWith({
    Value<int?>? id,
    Value<int?>? idCentroResultado,
    Value<int?>? idPatrimTipoAquisicaoBem,
    Value<int?>? idPatrimEstadoConservacao,
    Value<int?>? idPatrimGrupoBem,
    Value<int?>? idFornecedor,
    Value<int?>? idSetor,
    Value<String?>? numeroNb,
    Value<String?>? nome,
    Value<String?>? descricao,
    Value<String?>? numeroSerie,
    Value<DateTime?>? dataAquisicao,
    Value<DateTime?>? dataAceite,
    Value<DateTime?>? dataCadastro,
    Value<DateTime?>? dataContabilizado,
    Value<DateTime?>? dataVistoria,
    Value<DateTime?>? dataMarcacao,
    Value<DateTime?>? dataBaixa,
    Value<DateTime?>? vencimentoGarantia,
    Value<String?>? numeroNotaFiscal,
    Value<String?>? chaveNfe,
    Value<double?>? valorOriginal,
    Value<double?>? valorCompra,
    Value<double?>? valorAtualizado,
    Value<double?>? valorBaixa,
    Value<String?>? deprecia,
    Value<String?>? metodoDepreciacao,
    Value<DateTime?>? inicioDepreciacao,
    Value<DateTime?>? ultimaDepreciacao,
    Value<String?>? tipoDepreciacao,
    Value<double?>? taxaAnualDepreciacao,
    Value<double?>? taxaMensalDepreciacao,
    Value<double?>? taxaDepreciacaoAcelerada,
    Value<double?>? taxaDepreciacaoIncentivada,
    Value<String?>? funcao,
  }) {
    return PatrimBemsCompanion(
      id: id ?? this.id,
      idCentroResultado: idCentroResultado ?? this.idCentroResultado,
      idPatrimTipoAquisicaoBem:
          idPatrimTipoAquisicaoBem ?? this.idPatrimTipoAquisicaoBem,
      idPatrimEstadoConservacao:
          idPatrimEstadoConservacao ?? this.idPatrimEstadoConservacao,
      idPatrimGrupoBem: idPatrimGrupoBem ?? this.idPatrimGrupoBem,
      idFornecedor: idFornecedor ?? this.idFornecedor,
      idSetor: idSetor ?? this.idSetor,
      numeroNb: numeroNb ?? this.numeroNb,
      nome: nome ?? this.nome,
      descricao: descricao ?? this.descricao,
      numeroSerie: numeroSerie ?? this.numeroSerie,
      dataAquisicao: dataAquisicao ?? this.dataAquisicao,
      dataAceite: dataAceite ?? this.dataAceite,
      dataCadastro: dataCadastro ?? this.dataCadastro,
      dataContabilizado: dataContabilizado ?? this.dataContabilizado,
      dataVistoria: dataVistoria ?? this.dataVistoria,
      dataMarcacao: dataMarcacao ?? this.dataMarcacao,
      dataBaixa: dataBaixa ?? this.dataBaixa,
      vencimentoGarantia: vencimentoGarantia ?? this.vencimentoGarantia,
      numeroNotaFiscal: numeroNotaFiscal ?? this.numeroNotaFiscal,
      chaveNfe: chaveNfe ?? this.chaveNfe,
      valorOriginal: valorOriginal ?? this.valorOriginal,
      valorCompra: valorCompra ?? this.valorCompra,
      valorAtualizado: valorAtualizado ?? this.valorAtualizado,
      valorBaixa: valorBaixa ?? this.valorBaixa,
      deprecia: deprecia ?? this.deprecia,
      metodoDepreciacao: metodoDepreciacao ?? this.metodoDepreciacao,
      inicioDepreciacao: inicioDepreciacao ?? this.inicioDepreciacao,
      ultimaDepreciacao: ultimaDepreciacao ?? this.ultimaDepreciacao,
      tipoDepreciacao: tipoDepreciacao ?? this.tipoDepreciacao,
      taxaAnualDepreciacao: taxaAnualDepreciacao ?? this.taxaAnualDepreciacao,
      taxaMensalDepreciacao:
          taxaMensalDepreciacao ?? this.taxaMensalDepreciacao,
      taxaDepreciacaoAcelerada:
          taxaDepreciacaoAcelerada ?? this.taxaDepreciacaoAcelerada,
      taxaDepreciacaoIncentivada:
          taxaDepreciacaoIncentivada ?? this.taxaDepreciacaoIncentivada,
      funcao: funcao ?? this.funcao,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (idCentroResultado.present) {
      map['id_centro_resultado'] = Variable<int>(idCentroResultado.value);
    }
    if (idPatrimTipoAquisicaoBem.present) {
      map['id_patrim_tipo_aquisicao_bem'] = Variable<int>(
        idPatrimTipoAquisicaoBem.value,
      );
    }
    if (idPatrimEstadoConservacao.present) {
      map['id_patrim_estado_conservacao'] = Variable<int>(
        idPatrimEstadoConservacao.value,
      );
    }
    if (idPatrimGrupoBem.present) {
      map['id_patrim_grupo_bem'] = Variable<int>(idPatrimGrupoBem.value);
    }
    if (idFornecedor.present) {
      map['id_fornecedor'] = Variable<int>(idFornecedor.value);
    }
    if (idSetor.present) {
      map['id_setor'] = Variable<int>(idSetor.value);
    }
    if (numeroNb.present) {
      map['numero_nb'] = Variable<String>(numeroNb.value);
    }
    if (nome.present) {
      map['nome'] = Variable<String>(nome.value);
    }
    if (descricao.present) {
      map['descricao'] = Variable<String>(descricao.value);
    }
    if (numeroSerie.present) {
      map['numero_serie'] = Variable<String>(numeroSerie.value);
    }
    if (dataAquisicao.present) {
      map['data_aquisicao'] = Variable<DateTime>(dataAquisicao.value);
    }
    if (dataAceite.present) {
      map['data_aceite'] = Variable<DateTime>(dataAceite.value);
    }
    if (dataCadastro.present) {
      map['data_cadastro'] = Variable<DateTime>(dataCadastro.value);
    }
    if (dataContabilizado.present) {
      map['data_contabilizado'] = Variable<DateTime>(dataContabilizado.value);
    }
    if (dataVistoria.present) {
      map['data_vistoria'] = Variable<DateTime>(dataVistoria.value);
    }
    if (dataMarcacao.present) {
      map['data_marcacao'] = Variable<DateTime>(dataMarcacao.value);
    }
    if (dataBaixa.present) {
      map['data_baixa'] = Variable<DateTime>(dataBaixa.value);
    }
    if (vencimentoGarantia.present) {
      map['vencimento_garantia'] = Variable<DateTime>(vencimentoGarantia.value);
    }
    if (numeroNotaFiscal.present) {
      map['numero_nota_fiscal'] = Variable<String>(numeroNotaFiscal.value);
    }
    if (chaveNfe.present) {
      map['chave_nfe'] = Variable<String>(chaveNfe.value);
    }
    if (valorOriginal.present) {
      map['valor_original'] = Variable<double>(valorOriginal.value);
    }
    if (valorCompra.present) {
      map['valor_compra'] = Variable<double>(valorCompra.value);
    }
    if (valorAtualizado.present) {
      map['valor_atualizado'] = Variable<double>(valorAtualizado.value);
    }
    if (valorBaixa.present) {
      map['valor_baixa'] = Variable<double>(valorBaixa.value);
    }
    if (deprecia.present) {
      map['deprecia'] = Variable<String>(deprecia.value);
    }
    if (metodoDepreciacao.present) {
      map['metodo_depreciacao'] = Variable<String>(metodoDepreciacao.value);
    }
    if (inicioDepreciacao.present) {
      map['inicio_depreciacao'] = Variable<DateTime>(inicioDepreciacao.value);
    }
    if (ultimaDepreciacao.present) {
      map['ultima_depreciacao'] = Variable<DateTime>(ultimaDepreciacao.value);
    }
    if (tipoDepreciacao.present) {
      map['tipo_depreciacao'] = Variable<String>(tipoDepreciacao.value);
    }
    if (taxaAnualDepreciacao.present) {
      map['taxa_anual_depreciacao'] = Variable<double>(
        taxaAnualDepreciacao.value,
      );
    }
    if (taxaMensalDepreciacao.present) {
      map['taxa_mensal_depreciacao'] = Variable<double>(
        taxaMensalDepreciacao.value,
      );
    }
    if (taxaDepreciacaoAcelerada.present) {
      map['taxa_depreciacao_acelerada'] = Variable<double>(
        taxaDepreciacaoAcelerada.value,
      );
    }
    if (taxaDepreciacaoIncentivada.present) {
      map['taxa_depreciacao_incentivada'] = Variable<double>(
        taxaDepreciacaoIncentivada.value,
      );
    }
    if (funcao.present) {
      map['funcao'] = Variable<String>(funcao.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('PatrimBemsCompanion(')
          ..write('id: $id, ')
          ..write('idCentroResultado: $idCentroResultado, ')
          ..write('idPatrimTipoAquisicaoBem: $idPatrimTipoAquisicaoBem, ')
          ..write('idPatrimEstadoConservacao: $idPatrimEstadoConservacao, ')
          ..write('idPatrimGrupoBem: $idPatrimGrupoBem, ')
          ..write('idFornecedor: $idFornecedor, ')
          ..write('idSetor: $idSetor, ')
          ..write('numeroNb: $numeroNb, ')
          ..write('nome: $nome, ')
          ..write('descricao: $descricao, ')
          ..write('numeroSerie: $numeroSerie, ')
          ..write('dataAquisicao: $dataAquisicao, ')
          ..write('dataAceite: $dataAceite, ')
          ..write('dataCadastro: $dataCadastro, ')
          ..write('dataContabilizado: $dataContabilizado, ')
          ..write('dataVistoria: $dataVistoria, ')
          ..write('dataMarcacao: $dataMarcacao, ')
          ..write('dataBaixa: $dataBaixa, ')
          ..write('vencimentoGarantia: $vencimentoGarantia, ')
          ..write('numeroNotaFiscal: $numeroNotaFiscal, ')
          ..write('chaveNfe: $chaveNfe, ')
          ..write('valorOriginal: $valorOriginal, ')
          ..write('valorCompra: $valorCompra, ')
          ..write('valorAtualizado: $valorAtualizado, ')
          ..write('valorBaixa: $valorBaixa, ')
          ..write('deprecia: $deprecia, ')
          ..write('metodoDepreciacao: $metodoDepreciacao, ')
          ..write('inicioDepreciacao: $inicioDepreciacao, ')
          ..write('ultimaDepreciacao: $ultimaDepreciacao, ')
          ..write('tipoDepreciacao: $tipoDepreciacao, ')
          ..write('taxaAnualDepreciacao: $taxaAnualDepreciacao, ')
          ..write('taxaMensalDepreciacao: $taxaMensalDepreciacao, ')
          ..write('taxaDepreciacaoAcelerada: $taxaDepreciacaoAcelerada, ')
          ..write('taxaDepreciacaoIncentivada: $taxaDepreciacaoIncentivada, ')
          ..write('funcao: $funcao')
          ..write(')'))
        .toString();
  }
}

class $PcpInstrucaosTable extends PcpInstrucaos
    with TableInfo<$PcpInstrucaosTable, PcpInstrucao> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $PcpInstrucaosTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
    'id',
    aliasedName,
    true,
    type: DriftSqlType.int,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _codigoMeta = const VerificationMeta('codigo');
  @override
  late final GeneratedColumn<String> codigo = GeneratedColumn<String>(
    'codigo',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 3,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _descricaoMeta = const VerificationMeta(
    'descricao',
  );
  @override
  late final GeneratedColumn<String> descricao = GeneratedColumn<String>(
    'descricao',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 100,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  @override
  List<GeneratedColumn> get $columns => [id, codigo, descricao];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'pcp_instrucao';
  @override
  VerificationContext validateIntegrity(
    Insertable<PcpInstrucao> instance, {
    bool isInserting = false,
  }) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('codigo')) {
      context.handle(
        _codigoMeta,
        codigo.isAcceptableOrUnknown(data['codigo']!, _codigoMeta),
      );
    }
    if (data.containsKey('descricao')) {
      context.handle(
        _descricaoMeta,
        descricao.isAcceptableOrUnknown(data['descricao']!, _descricaoMeta),
      );
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  PcpInstrucao map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return PcpInstrucao(
      id: attachedDatabase.typeMapping.read(
        DriftSqlType.int,
        data['${effectivePrefix}id'],
      ),
      codigo: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}codigo'],
      ),
      descricao: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}descricao'],
      ),
    );
  }

  @override
  $PcpInstrucaosTable createAlias(String alias) {
    return $PcpInstrucaosTable(attachedDatabase, alias);
  }
}

class PcpInstrucao extends DataClass implements Insertable<PcpInstrucao> {
  final int? id;
  final String? codigo;
  final String? descricao;
  const PcpInstrucao({this.id, this.codigo, this.descricao});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || codigo != null) {
      map['codigo'] = Variable<String>(codigo);
    }
    if (!nullToAbsent || descricao != null) {
      map['descricao'] = Variable<String>(descricao);
    }
    return map;
  }

  factory PcpInstrucao.fromJson(
    Map<String, dynamic> json, {
    ValueSerializer? serializer,
  }) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return PcpInstrucao(
      id: serializer.fromJson<int?>(json['id']),
      codigo: serializer.fromJson<String?>(json['codigo']),
      descricao: serializer.fromJson<String?>(json['descricao']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'codigo': serializer.toJson<String?>(codigo),
      'descricao': serializer.toJson<String?>(descricao),
    };
  }

  PcpInstrucao copyWith({
    Value<int?> id = const Value.absent(),
    Value<String?> codigo = const Value.absent(),
    Value<String?> descricao = const Value.absent(),
  }) => PcpInstrucao(
    id: id.present ? id.value : this.id,
    codigo: codigo.present ? codigo.value : this.codigo,
    descricao: descricao.present ? descricao.value : this.descricao,
  );
  PcpInstrucao copyWithCompanion(PcpInstrucaosCompanion data) {
    return PcpInstrucao(
      id: data.id.present ? data.id.value : this.id,
      codigo: data.codigo.present ? data.codigo.value : this.codigo,
      descricao: data.descricao.present ? data.descricao.value : this.descricao,
    );
  }

  @override
  String toString() {
    return (StringBuffer('PcpInstrucao(')
          ..write('id: $id, ')
          ..write('codigo: $codigo, ')
          ..write('descricao: $descricao')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(id, codigo, descricao);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is PcpInstrucao &&
          other.id == this.id &&
          other.codigo == this.codigo &&
          other.descricao == this.descricao);
}

class PcpInstrucaosCompanion extends UpdateCompanion<PcpInstrucao> {
  final Value<int?> id;
  final Value<String?> codigo;
  final Value<String?> descricao;
  const PcpInstrucaosCompanion({
    this.id = const Value.absent(),
    this.codigo = const Value.absent(),
    this.descricao = const Value.absent(),
  });
  PcpInstrucaosCompanion.insert({
    this.id = const Value.absent(),
    this.codigo = const Value.absent(),
    this.descricao = const Value.absent(),
  });
  static Insertable<PcpInstrucao> custom({
    Expression<int>? id,
    Expression<String>? codigo,
    Expression<String>? descricao,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (codigo != null) 'codigo': codigo,
      if (descricao != null) 'descricao': descricao,
    });
  }

  PcpInstrucaosCompanion copyWith({
    Value<int?>? id,
    Value<String?>? codigo,
    Value<String?>? descricao,
  }) {
    return PcpInstrucaosCompanion(
      id: id ?? this.id,
      codigo: codigo ?? this.codigo,
      descricao: descricao ?? this.descricao,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (codigo.present) {
      map['codigo'] = Variable<String>(codigo.value);
    }
    if (descricao.present) {
      map['descricao'] = Variable<String>(descricao.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('PcpInstrucaosCompanion(')
          ..write('id: $id, ')
          ..write('codigo: $codigo, ')
          ..write('descricao: $descricao')
          ..write(')'))
        .toString();
  }
}

class $ViewControleAcessosTable extends ViewControleAcessos
    with TableInfo<$ViewControleAcessosTable, ViewControleAcesso> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $ViewControleAcessosTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
    'id',
    aliasedName,
    true,
    type: DriftSqlType.int,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _idPessoaMeta = const VerificationMeta(
    'idPessoa',
  );
  @override
  late final GeneratedColumn<int> idPessoa = GeneratedColumn<int>(
    'id_pessoa',
    aliasedName,
    true,
    type: DriftSqlType.int,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _pessoaNomeMeta = const VerificationMeta(
    'pessoaNome',
  );
  @override
  late final GeneratedColumn<String> pessoaNome = GeneratedColumn<String>(
    'pessoa_nome',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 450,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _idColaboradorMeta = const VerificationMeta(
    'idColaborador',
  );
  @override
  late final GeneratedColumn<int> idColaborador = GeneratedColumn<int>(
    'id_colaborador',
    aliasedName,
    true,
    type: DriftSqlType.int,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _idUsuarioMeta = const VerificationMeta(
    'idUsuario',
  );
  @override
  late final GeneratedColumn<int> idUsuario = GeneratedColumn<int>(
    'id_usuario',
    aliasedName,
    true,
    type: DriftSqlType.int,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _administradorMeta = const VerificationMeta(
    'administrador',
  );
  @override
  late final GeneratedColumn<String> administrador = GeneratedColumn<String>(
    'administrador',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 3,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _idPapelMeta = const VerificationMeta(
    'idPapel',
  );
  @override
  late final GeneratedColumn<int> idPapel = GeneratedColumn<int>(
    'id_papel',
    aliasedName,
    true,
    type: DriftSqlType.int,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _papelNomeMeta = const VerificationMeta(
    'papelNome',
  );
  @override
  late final GeneratedColumn<String> papelNome = GeneratedColumn<String>(
    'papel_nome',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 300,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _papelDescricaoMeta = const VerificationMeta(
    'papelDescricao',
  );
  @override
  late final GeneratedColumn<String> papelDescricao = GeneratedColumn<String>(
    'papel_descricao',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 750,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _idFuncaoMeta = const VerificationMeta(
    'idFuncao',
  );
  @override
  late final GeneratedColumn<int> idFuncao = GeneratedColumn<int>(
    'id_funcao',
    aliasedName,
    true,
    type: DriftSqlType.int,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _funcaoNomeMeta = const VerificationMeta(
    'funcaoNome',
  );
  @override
  late final GeneratedColumn<String> funcaoNome = GeneratedColumn<String>(
    'funcao_nome',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 300,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _funcaoDescricaoMeta = const VerificationMeta(
    'funcaoDescricao',
  );
  @override
  late final GeneratedColumn<String> funcaoDescricao = GeneratedColumn<String>(
    'funcao_descricao',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 750,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _idPapelFuncaoMeta = const VerificationMeta(
    'idPapelFuncao',
  );
  @override
  late final GeneratedColumn<int> idPapelFuncao = GeneratedColumn<int>(
    'id_papel_funcao',
    aliasedName,
    true,
    type: DriftSqlType.int,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _habilitadoMeta = const VerificationMeta(
    'habilitado',
  );
  @override
  late final GeneratedColumn<String> habilitado = GeneratedColumn<String>(
    'habilitado',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 3,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _podeInserirMeta = const VerificationMeta(
    'podeInserir',
  );
  @override
  late final GeneratedColumn<String> podeInserir = GeneratedColumn<String>(
    'pode_inserir',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 3,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _podeAlterarMeta = const VerificationMeta(
    'podeAlterar',
  );
  @override
  late final GeneratedColumn<String> podeAlterar = GeneratedColumn<String>(
    'pode_alterar',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 3,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _podeExcluirMeta = const VerificationMeta(
    'podeExcluir',
  );
  @override
  late final GeneratedColumn<String> podeExcluir = GeneratedColumn<String>(
    'pode_excluir',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 3,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  @override
  List<GeneratedColumn> get $columns => [
    id,
    idPessoa,
    pessoaNome,
    idColaborador,
    idUsuario,
    administrador,
    idPapel,
    papelNome,
    papelDescricao,
    idFuncao,
    funcaoNome,
    funcaoDescricao,
    idPapelFuncao,
    habilitado,
    podeInserir,
    podeAlterar,
    podeExcluir,
  ];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'view_controle_acesso';
  @override
  VerificationContext validateIntegrity(
    Insertable<ViewControleAcesso> instance, {
    bool isInserting = false,
  }) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('id_pessoa')) {
      context.handle(
        _idPessoaMeta,
        idPessoa.isAcceptableOrUnknown(data['id_pessoa']!, _idPessoaMeta),
      );
    }
    if (data.containsKey('pessoa_nome')) {
      context.handle(
        _pessoaNomeMeta,
        pessoaNome.isAcceptableOrUnknown(data['pessoa_nome']!, _pessoaNomeMeta),
      );
    }
    if (data.containsKey('id_colaborador')) {
      context.handle(
        _idColaboradorMeta,
        idColaborador.isAcceptableOrUnknown(
          data['id_colaborador']!,
          _idColaboradorMeta,
        ),
      );
    }
    if (data.containsKey('id_usuario')) {
      context.handle(
        _idUsuarioMeta,
        idUsuario.isAcceptableOrUnknown(data['id_usuario']!, _idUsuarioMeta),
      );
    }
    if (data.containsKey('administrador')) {
      context.handle(
        _administradorMeta,
        administrador.isAcceptableOrUnknown(
          data['administrador']!,
          _administradorMeta,
        ),
      );
    }
    if (data.containsKey('id_papel')) {
      context.handle(
        _idPapelMeta,
        idPapel.isAcceptableOrUnknown(data['id_papel']!, _idPapelMeta),
      );
    }
    if (data.containsKey('papel_nome')) {
      context.handle(
        _papelNomeMeta,
        papelNome.isAcceptableOrUnknown(data['papel_nome']!, _papelNomeMeta),
      );
    }
    if (data.containsKey('papel_descricao')) {
      context.handle(
        _papelDescricaoMeta,
        papelDescricao.isAcceptableOrUnknown(
          data['papel_descricao']!,
          _papelDescricaoMeta,
        ),
      );
    }
    if (data.containsKey('id_funcao')) {
      context.handle(
        _idFuncaoMeta,
        idFuncao.isAcceptableOrUnknown(data['id_funcao']!, _idFuncaoMeta),
      );
    }
    if (data.containsKey('funcao_nome')) {
      context.handle(
        _funcaoNomeMeta,
        funcaoNome.isAcceptableOrUnknown(data['funcao_nome']!, _funcaoNomeMeta),
      );
    }
    if (data.containsKey('funcao_descricao')) {
      context.handle(
        _funcaoDescricaoMeta,
        funcaoDescricao.isAcceptableOrUnknown(
          data['funcao_descricao']!,
          _funcaoDescricaoMeta,
        ),
      );
    }
    if (data.containsKey('id_papel_funcao')) {
      context.handle(
        _idPapelFuncaoMeta,
        idPapelFuncao.isAcceptableOrUnknown(
          data['id_papel_funcao']!,
          _idPapelFuncaoMeta,
        ),
      );
    }
    if (data.containsKey('habilitado')) {
      context.handle(
        _habilitadoMeta,
        habilitado.isAcceptableOrUnknown(data['habilitado']!, _habilitadoMeta),
      );
    }
    if (data.containsKey('pode_inserir')) {
      context.handle(
        _podeInserirMeta,
        podeInserir.isAcceptableOrUnknown(
          data['pode_inserir']!,
          _podeInserirMeta,
        ),
      );
    }
    if (data.containsKey('pode_alterar')) {
      context.handle(
        _podeAlterarMeta,
        podeAlterar.isAcceptableOrUnknown(
          data['pode_alterar']!,
          _podeAlterarMeta,
        ),
      );
    }
    if (data.containsKey('pode_excluir')) {
      context.handle(
        _podeExcluirMeta,
        podeExcluir.isAcceptableOrUnknown(
          data['pode_excluir']!,
          _podeExcluirMeta,
        ),
      );
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  ViewControleAcesso map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return ViewControleAcesso(
      id: attachedDatabase.typeMapping.read(
        DriftSqlType.int,
        data['${effectivePrefix}id'],
      ),
      idPessoa: attachedDatabase.typeMapping.read(
        DriftSqlType.int,
        data['${effectivePrefix}id_pessoa'],
      ),
      pessoaNome: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}pessoa_nome'],
      ),
      idColaborador: attachedDatabase.typeMapping.read(
        DriftSqlType.int,
        data['${effectivePrefix}id_colaborador'],
      ),
      idUsuario: attachedDatabase.typeMapping.read(
        DriftSqlType.int,
        data['${effectivePrefix}id_usuario'],
      ),
      administrador: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}administrador'],
      ),
      idPapel: attachedDatabase.typeMapping.read(
        DriftSqlType.int,
        data['${effectivePrefix}id_papel'],
      ),
      papelNome: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}papel_nome'],
      ),
      papelDescricao: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}papel_descricao'],
      ),
      idFuncao: attachedDatabase.typeMapping.read(
        DriftSqlType.int,
        data['${effectivePrefix}id_funcao'],
      ),
      funcaoNome: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}funcao_nome'],
      ),
      funcaoDescricao: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}funcao_descricao'],
      ),
      idPapelFuncao: attachedDatabase.typeMapping.read(
        DriftSqlType.int,
        data['${effectivePrefix}id_papel_funcao'],
      ),
      habilitado: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}habilitado'],
      ),
      podeInserir: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}pode_inserir'],
      ),
      podeAlterar: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}pode_alterar'],
      ),
      podeExcluir: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}pode_excluir'],
      ),
    );
  }

  @override
  $ViewControleAcessosTable createAlias(String alias) {
    return $ViewControleAcessosTable(attachedDatabase, alias);
  }
}

class ViewControleAcesso extends DataClass
    implements Insertable<ViewControleAcesso> {
  final int? id;
  final int? idPessoa;
  final String? pessoaNome;
  final int? idColaborador;
  final int? idUsuario;
  final String? administrador;
  final int? idPapel;
  final String? papelNome;
  final String? papelDescricao;
  final int? idFuncao;
  final String? funcaoNome;
  final String? funcaoDescricao;
  final int? idPapelFuncao;
  final String? habilitado;
  final String? podeInserir;
  final String? podeAlterar;
  final String? podeExcluir;
  const ViewControleAcesso({
    this.id,
    this.idPessoa,
    this.pessoaNome,
    this.idColaborador,
    this.idUsuario,
    this.administrador,
    this.idPapel,
    this.papelNome,
    this.papelDescricao,
    this.idFuncao,
    this.funcaoNome,
    this.funcaoDescricao,
    this.idPapelFuncao,
    this.habilitado,
    this.podeInserir,
    this.podeAlterar,
    this.podeExcluir,
  });
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || idPessoa != null) {
      map['id_pessoa'] = Variable<int>(idPessoa);
    }
    if (!nullToAbsent || pessoaNome != null) {
      map['pessoa_nome'] = Variable<String>(pessoaNome);
    }
    if (!nullToAbsent || idColaborador != null) {
      map['id_colaborador'] = Variable<int>(idColaborador);
    }
    if (!nullToAbsent || idUsuario != null) {
      map['id_usuario'] = Variable<int>(idUsuario);
    }
    if (!nullToAbsent || administrador != null) {
      map['administrador'] = Variable<String>(administrador);
    }
    if (!nullToAbsent || idPapel != null) {
      map['id_papel'] = Variable<int>(idPapel);
    }
    if (!nullToAbsent || papelNome != null) {
      map['papel_nome'] = Variable<String>(papelNome);
    }
    if (!nullToAbsent || papelDescricao != null) {
      map['papel_descricao'] = Variable<String>(papelDescricao);
    }
    if (!nullToAbsent || idFuncao != null) {
      map['id_funcao'] = Variable<int>(idFuncao);
    }
    if (!nullToAbsent || funcaoNome != null) {
      map['funcao_nome'] = Variable<String>(funcaoNome);
    }
    if (!nullToAbsent || funcaoDescricao != null) {
      map['funcao_descricao'] = Variable<String>(funcaoDescricao);
    }
    if (!nullToAbsent || idPapelFuncao != null) {
      map['id_papel_funcao'] = Variable<int>(idPapelFuncao);
    }
    if (!nullToAbsent || habilitado != null) {
      map['habilitado'] = Variable<String>(habilitado);
    }
    if (!nullToAbsent || podeInserir != null) {
      map['pode_inserir'] = Variable<String>(podeInserir);
    }
    if (!nullToAbsent || podeAlterar != null) {
      map['pode_alterar'] = Variable<String>(podeAlterar);
    }
    if (!nullToAbsent || podeExcluir != null) {
      map['pode_excluir'] = Variable<String>(podeExcluir);
    }
    return map;
  }

  factory ViewControleAcesso.fromJson(
    Map<String, dynamic> json, {
    ValueSerializer? serializer,
  }) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return ViewControleAcesso(
      id: serializer.fromJson<int?>(json['id']),
      idPessoa: serializer.fromJson<int?>(json['idPessoa']),
      pessoaNome: serializer.fromJson<String?>(json['pessoaNome']),
      idColaborador: serializer.fromJson<int?>(json['idColaborador']),
      idUsuario: serializer.fromJson<int?>(json['idUsuario']),
      administrador: serializer.fromJson<String?>(json['administrador']),
      idPapel: serializer.fromJson<int?>(json['idPapel']),
      papelNome: serializer.fromJson<String?>(json['papelNome']),
      papelDescricao: serializer.fromJson<String?>(json['papelDescricao']),
      idFuncao: serializer.fromJson<int?>(json['idFuncao']),
      funcaoNome: serializer.fromJson<String?>(json['funcaoNome']),
      funcaoDescricao: serializer.fromJson<String?>(json['funcaoDescricao']),
      idPapelFuncao: serializer.fromJson<int?>(json['idPapelFuncao']),
      habilitado: serializer.fromJson<String?>(json['habilitado']),
      podeInserir: serializer.fromJson<String?>(json['podeInserir']),
      podeAlterar: serializer.fromJson<String?>(json['podeAlterar']),
      podeExcluir: serializer.fromJson<String?>(json['podeExcluir']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'idPessoa': serializer.toJson<int?>(idPessoa),
      'pessoaNome': serializer.toJson<String?>(pessoaNome),
      'idColaborador': serializer.toJson<int?>(idColaborador),
      'idUsuario': serializer.toJson<int?>(idUsuario),
      'administrador': serializer.toJson<String?>(administrador),
      'idPapel': serializer.toJson<int?>(idPapel),
      'papelNome': serializer.toJson<String?>(papelNome),
      'papelDescricao': serializer.toJson<String?>(papelDescricao),
      'idFuncao': serializer.toJson<int?>(idFuncao),
      'funcaoNome': serializer.toJson<String?>(funcaoNome),
      'funcaoDescricao': serializer.toJson<String?>(funcaoDescricao),
      'idPapelFuncao': serializer.toJson<int?>(idPapelFuncao),
      'habilitado': serializer.toJson<String?>(habilitado),
      'podeInserir': serializer.toJson<String?>(podeInserir),
      'podeAlterar': serializer.toJson<String?>(podeAlterar),
      'podeExcluir': serializer.toJson<String?>(podeExcluir),
    };
  }

  ViewControleAcesso copyWith({
    Value<int?> id = const Value.absent(),
    Value<int?> idPessoa = const Value.absent(),
    Value<String?> pessoaNome = const Value.absent(),
    Value<int?> idColaborador = const Value.absent(),
    Value<int?> idUsuario = const Value.absent(),
    Value<String?> administrador = const Value.absent(),
    Value<int?> idPapel = const Value.absent(),
    Value<String?> papelNome = const Value.absent(),
    Value<String?> papelDescricao = const Value.absent(),
    Value<int?> idFuncao = const Value.absent(),
    Value<String?> funcaoNome = const Value.absent(),
    Value<String?> funcaoDescricao = const Value.absent(),
    Value<int?> idPapelFuncao = const Value.absent(),
    Value<String?> habilitado = const Value.absent(),
    Value<String?> podeInserir = const Value.absent(),
    Value<String?> podeAlterar = const Value.absent(),
    Value<String?> podeExcluir = const Value.absent(),
  }) => ViewControleAcesso(
    id: id.present ? id.value : this.id,
    idPessoa: idPessoa.present ? idPessoa.value : this.idPessoa,
    pessoaNome: pessoaNome.present ? pessoaNome.value : this.pessoaNome,
    idColaborador:
        idColaborador.present ? idColaborador.value : this.idColaborador,
    idUsuario: idUsuario.present ? idUsuario.value : this.idUsuario,
    administrador:
        administrador.present ? administrador.value : this.administrador,
    idPapel: idPapel.present ? idPapel.value : this.idPapel,
    papelNome: papelNome.present ? papelNome.value : this.papelNome,
    papelDescricao:
        papelDescricao.present ? papelDescricao.value : this.papelDescricao,
    idFuncao: idFuncao.present ? idFuncao.value : this.idFuncao,
    funcaoNome: funcaoNome.present ? funcaoNome.value : this.funcaoNome,
    funcaoDescricao:
        funcaoDescricao.present ? funcaoDescricao.value : this.funcaoDescricao,
    idPapelFuncao:
        idPapelFuncao.present ? idPapelFuncao.value : this.idPapelFuncao,
    habilitado: habilitado.present ? habilitado.value : this.habilitado,
    podeInserir: podeInserir.present ? podeInserir.value : this.podeInserir,
    podeAlterar: podeAlterar.present ? podeAlterar.value : this.podeAlterar,
    podeExcluir: podeExcluir.present ? podeExcluir.value : this.podeExcluir,
  );
  ViewControleAcesso copyWithCompanion(ViewControleAcessosCompanion data) {
    return ViewControleAcesso(
      id: data.id.present ? data.id.value : this.id,
      idPessoa: data.idPessoa.present ? data.idPessoa.value : this.idPessoa,
      pessoaNome:
          data.pessoaNome.present ? data.pessoaNome.value : this.pessoaNome,
      idColaborador:
          data.idColaborador.present
              ? data.idColaborador.value
              : this.idColaborador,
      idUsuario: data.idUsuario.present ? data.idUsuario.value : this.idUsuario,
      administrador:
          data.administrador.present
              ? data.administrador.value
              : this.administrador,
      idPapel: data.idPapel.present ? data.idPapel.value : this.idPapel,
      papelNome: data.papelNome.present ? data.papelNome.value : this.papelNome,
      papelDescricao:
          data.papelDescricao.present
              ? data.papelDescricao.value
              : this.papelDescricao,
      idFuncao: data.idFuncao.present ? data.idFuncao.value : this.idFuncao,
      funcaoNome:
          data.funcaoNome.present ? data.funcaoNome.value : this.funcaoNome,
      funcaoDescricao:
          data.funcaoDescricao.present
              ? data.funcaoDescricao.value
              : this.funcaoDescricao,
      idPapelFuncao:
          data.idPapelFuncao.present
              ? data.idPapelFuncao.value
              : this.idPapelFuncao,
      habilitado:
          data.habilitado.present ? data.habilitado.value : this.habilitado,
      podeInserir:
          data.podeInserir.present ? data.podeInserir.value : this.podeInserir,
      podeAlterar:
          data.podeAlterar.present ? data.podeAlterar.value : this.podeAlterar,
      podeExcluir:
          data.podeExcluir.present ? data.podeExcluir.value : this.podeExcluir,
    );
  }

  @override
  String toString() {
    return (StringBuffer('ViewControleAcesso(')
          ..write('id: $id, ')
          ..write('idPessoa: $idPessoa, ')
          ..write('pessoaNome: $pessoaNome, ')
          ..write('idColaborador: $idColaborador, ')
          ..write('idUsuario: $idUsuario, ')
          ..write('administrador: $administrador, ')
          ..write('idPapel: $idPapel, ')
          ..write('papelNome: $papelNome, ')
          ..write('papelDescricao: $papelDescricao, ')
          ..write('idFuncao: $idFuncao, ')
          ..write('funcaoNome: $funcaoNome, ')
          ..write('funcaoDescricao: $funcaoDescricao, ')
          ..write('idPapelFuncao: $idPapelFuncao, ')
          ..write('habilitado: $habilitado, ')
          ..write('podeInserir: $podeInserir, ')
          ..write('podeAlterar: $podeAlterar, ')
          ..write('podeExcluir: $podeExcluir')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(
    id,
    idPessoa,
    pessoaNome,
    idColaborador,
    idUsuario,
    administrador,
    idPapel,
    papelNome,
    papelDescricao,
    idFuncao,
    funcaoNome,
    funcaoDescricao,
    idPapelFuncao,
    habilitado,
    podeInserir,
    podeAlterar,
    podeExcluir,
  );
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is ViewControleAcesso &&
          other.id == this.id &&
          other.idPessoa == this.idPessoa &&
          other.pessoaNome == this.pessoaNome &&
          other.idColaborador == this.idColaborador &&
          other.idUsuario == this.idUsuario &&
          other.administrador == this.administrador &&
          other.idPapel == this.idPapel &&
          other.papelNome == this.papelNome &&
          other.papelDescricao == this.papelDescricao &&
          other.idFuncao == this.idFuncao &&
          other.funcaoNome == this.funcaoNome &&
          other.funcaoDescricao == this.funcaoDescricao &&
          other.idPapelFuncao == this.idPapelFuncao &&
          other.habilitado == this.habilitado &&
          other.podeInserir == this.podeInserir &&
          other.podeAlterar == this.podeAlterar &&
          other.podeExcluir == this.podeExcluir);
}

class ViewControleAcessosCompanion extends UpdateCompanion<ViewControleAcesso> {
  final Value<int?> id;
  final Value<int?> idPessoa;
  final Value<String?> pessoaNome;
  final Value<int?> idColaborador;
  final Value<int?> idUsuario;
  final Value<String?> administrador;
  final Value<int?> idPapel;
  final Value<String?> papelNome;
  final Value<String?> papelDescricao;
  final Value<int?> idFuncao;
  final Value<String?> funcaoNome;
  final Value<String?> funcaoDescricao;
  final Value<int?> idPapelFuncao;
  final Value<String?> habilitado;
  final Value<String?> podeInserir;
  final Value<String?> podeAlterar;
  final Value<String?> podeExcluir;
  const ViewControleAcessosCompanion({
    this.id = const Value.absent(),
    this.idPessoa = const Value.absent(),
    this.pessoaNome = const Value.absent(),
    this.idColaborador = const Value.absent(),
    this.idUsuario = const Value.absent(),
    this.administrador = const Value.absent(),
    this.idPapel = const Value.absent(),
    this.papelNome = const Value.absent(),
    this.papelDescricao = const Value.absent(),
    this.idFuncao = const Value.absent(),
    this.funcaoNome = const Value.absent(),
    this.funcaoDescricao = const Value.absent(),
    this.idPapelFuncao = const Value.absent(),
    this.habilitado = const Value.absent(),
    this.podeInserir = const Value.absent(),
    this.podeAlterar = const Value.absent(),
    this.podeExcluir = const Value.absent(),
  });
  ViewControleAcessosCompanion.insert({
    this.id = const Value.absent(),
    this.idPessoa = const Value.absent(),
    this.pessoaNome = const Value.absent(),
    this.idColaborador = const Value.absent(),
    this.idUsuario = const Value.absent(),
    this.administrador = const Value.absent(),
    this.idPapel = const Value.absent(),
    this.papelNome = const Value.absent(),
    this.papelDescricao = const Value.absent(),
    this.idFuncao = const Value.absent(),
    this.funcaoNome = const Value.absent(),
    this.funcaoDescricao = const Value.absent(),
    this.idPapelFuncao = const Value.absent(),
    this.habilitado = const Value.absent(),
    this.podeInserir = const Value.absent(),
    this.podeAlterar = const Value.absent(),
    this.podeExcluir = const Value.absent(),
  });
  static Insertable<ViewControleAcesso> custom({
    Expression<int>? id,
    Expression<int>? idPessoa,
    Expression<String>? pessoaNome,
    Expression<int>? idColaborador,
    Expression<int>? idUsuario,
    Expression<String>? administrador,
    Expression<int>? idPapel,
    Expression<String>? papelNome,
    Expression<String>? papelDescricao,
    Expression<int>? idFuncao,
    Expression<String>? funcaoNome,
    Expression<String>? funcaoDescricao,
    Expression<int>? idPapelFuncao,
    Expression<String>? habilitado,
    Expression<String>? podeInserir,
    Expression<String>? podeAlterar,
    Expression<String>? podeExcluir,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (idPessoa != null) 'id_pessoa': idPessoa,
      if (pessoaNome != null) 'pessoa_nome': pessoaNome,
      if (idColaborador != null) 'id_colaborador': idColaborador,
      if (idUsuario != null) 'id_usuario': idUsuario,
      if (administrador != null) 'administrador': administrador,
      if (idPapel != null) 'id_papel': idPapel,
      if (papelNome != null) 'papel_nome': papelNome,
      if (papelDescricao != null) 'papel_descricao': papelDescricao,
      if (idFuncao != null) 'id_funcao': idFuncao,
      if (funcaoNome != null) 'funcao_nome': funcaoNome,
      if (funcaoDescricao != null) 'funcao_descricao': funcaoDescricao,
      if (idPapelFuncao != null) 'id_papel_funcao': idPapelFuncao,
      if (habilitado != null) 'habilitado': habilitado,
      if (podeInserir != null) 'pode_inserir': podeInserir,
      if (podeAlterar != null) 'pode_alterar': podeAlterar,
      if (podeExcluir != null) 'pode_excluir': podeExcluir,
    });
  }

  ViewControleAcessosCompanion copyWith({
    Value<int?>? id,
    Value<int?>? idPessoa,
    Value<String?>? pessoaNome,
    Value<int?>? idColaborador,
    Value<int?>? idUsuario,
    Value<String?>? administrador,
    Value<int?>? idPapel,
    Value<String?>? papelNome,
    Value<String?>? papelDescricao,
    Value<int?>? idFuncao,
    Value<String?>? funcaoNome,
    Value<String?>? funcaoDescricao,
    Value<int?>? idPapelFuncao,
    Value<String?>? habilitado,
    Value<String?>? podeInserir,
    Value<String?>? podeAlterar,
    Value<String?>? podeExcluir,
  }) {
    return ViewControleAcessosCompanion(
      id: id ?? this.id,
      idPessoa: idPessoa ?? this.idPessoa,
      pessoaNome: pessoaNome ?? this.pessoaNome,
      idColaborador: idColaborador ?? this.idColaborador,
      idUsuario: idUsuario ?? this.idUsuario,
      administrador: administrador ?? this.administrador,
      idPapel: idPapel ?? this.idPapel,
      papelNome: papelNome ?? this.papelNome,
      papelDescricao: papelDescricao ?? this.papelDescricao,
      idFuncao: idFuncao ?? this.idFuncao,
      funcaoNome: funcaoNome ?? this.funcaoNome,
      funcaoDescricao: funcaoDescricao ?? this.funcaoDescricao,
      idPapelFuncao: idPapelFuncao ?? this.idPapelFuncao,
      habilitado: habilitado ?? this.habilitado,
      podeInserir: podeInserir ?? this.podeInserir,
      podeAlterar: podeAlterar ?? this.podeAlterar,
      podeExcluir: podeExcluir ?? this.podeExcluir,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (idPessoa.present) {
      map['id_pessoa'] = Variable<int>(idPessoa.value);
    }
    if (pessoaNome.present) {
      map['pessoa_nome'] = Variable<String>(pessoaNome.value);
    }
    if (idColaborador.present) {
      map['id_colaborador'] = Variable<int>(idColaborador.value);
    }
    if (idUsuario.present) {
      map['id_usuario'] = Variable<int>(idUsuario.value);
    }
    if (administrador.present) {
      map['administrador'] = Variable<String>(administrador.value);
    }
    if (idPapel.present) {
      map['id_papel'] = Variable<int>(idPapel.value);
    }
    if (papelNome.present) {
      map['papel_nome'] = Variable<String>(papelNome.value);
    }
    if (papelDescricao.present) {
      map['papel_descricao'] = Variable<String>(papelDescricao.value);
    }
    if (idFuncao.present) {
      map['id_funcao'] = Variable<int>(idFuncao.value);
    }
    if (funcaoNome.present) {
      map['funcao_nome'] = Variable<String>(funcaoNome.value);
    }
    if (funcaoDescricao.present) {
      map['funcao_descricao'] = Variable<String>(funcaoDescricao.value);
    }
    if (idPapelFuncao.present) {
      map['id_papel_funcao'] = Variable<int>(idPapelFuncao.value);
    }
    if (habilitado.present) {
      map['habilitado'] = Variable<String>(habilitado.value);
    }
    if (podeInserir.present) {
      map['pode_inserir'] = Variable<String>(podeInserir.value);
    }
    if (podeAlterar.present) {
      map['pode_alterar'] = Variable<String>(podeAlterar.value);
    }
    if (podeExcluir.present) {
      map['pode_excluir'] = Variable<String>(podeExcluir.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('ViewControleAcessosCompanion(')
          ..write('id: $id, ')
          ..write('idPessoa: $idPessoa, ')
          ..write('pessoaNome: $pessoaNome, ')
          ..write('idColaborador: $idColaborador, ')
          ..write('idUsuario: $idUsuario, ')
          ..write('administrador: $administrador, ')
          ..write('idPapel: $idPapel, ')
          ..write('papelNome: $papelNome, ')
          ..write('papelDescricao: $papelDescricao, ')
          ..write('idFuncao: $idFuncao, ')
          ..write('funcaoNome: $funcaoNome, ')
          ..write('funcaoDescricao: $funcaoDescricao, ')
          ..write('idPapelFuncao: $idPapelFuncao, ')
          ..write('habilitado: $habilitado, ')
          ..write('podeInserir: $podeInserir, ')
          ..write('podeAlterar: $podeAlterar, ')
          ..write('podeExcluir: $podeExcluir')
          ..write(')'))
        .toString();
  }
}

class $ViewPessoaUsuariosTable extends ViewPessoaUsuarios
    with TableInfo<$ViewPessoaUsuariosTable, ViewPessoaUsuario> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $ViewPessoaUsuariosTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
    'id',
    aliasedName,
    true,
    type: DriftSqlType.int,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _idPessoaMeta = const VerificationMeta(
    'idPessoa',
  );
  @override
  late final GeneratedColumn<int> idPessoa = GeneratedColumn<int>(
    'id_pessoa',
    aliasedName,
    true,
    type: DriftSqlType.int,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _pessoaNomeMeta = const VerificationMeta(
    'pessoaNome',
  );
  @override
  late final GeneratedColumn<String> pessoaNome = GeneratedColumn<String>(
    'pessoa_nome',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 450,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _tipoMeta = const VerificationMeta('tipo');
  @override
  late final GeneratedColumn<String> tipo = GeneratedColumn<String>(
    'tipo',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 3,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _emailMeta = const VerificationMeta('email');
  @override
  late final GeneratedColumn<String> email = GeneratedColumn<String>(
    'email',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 750,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _idColaboradorMeta = const VerificationMeta(
    'idColaborador',
  );
  @override
  late final GeneratedColumn<int> idColaborador = GeneratedColumn<int>(
    'id_colaborador',
    aliasedName,
    true,
    type: DriftSqlType.int,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _idUsuarioMeta = const VerificationMeta(
    'idUsuario',
  );
  @override
  late final GeneratedColumn<int> idUsuario = GeneratedColumn<int>(
    'id_usuario',
    aliasedName,
    true,
    type: DriftSqlType.int,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _loginMeta = const VerificationMeta('login');
  @override
  late final GeneratedColumn<String> login = GeneratedColumn<String>(
    'login',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 150,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _senhaMeta = const VerificationMeta('senha');
  @override
  late final GeneratedColumn<String> senha = GeneratedColumn<String>(
    'senha',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 150,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _dataCadastroMeta = const VerificationMeta(
    'dataCadastro',
  );
  @override
  late final GeneratedColumn<DateTime> dataCadastro = GeneratedColumn<DateTime>(
    'data_cadastro',
    aliasedName,
    true,
    type: DriftSqlType.dateTime,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _administradorMeta = const VerificationMeta(
    'administrador',
  );
  @override
  late final GeneratedColumn<String> administrador = GeneratedColumn<String>(
    'administrador',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 3,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  @override
  List<GeneratedColumn> get $columns => [
    id,
    idPessoa,
    pessoaNome,
    tipo,
    email,
    idColaborador,
    idUsuario,
    login,
    senha,
    dataCadastro,
    administrador,
  ];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'view_pessoa_usuario';
  @override
  VerificationContext validateIntegrity(
    Insertable<ViewPessoaUsuario> instance, {
    bool isInserting = false,
  }) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('id_pessoa')) {
      context.handle(
        _idPessoaMeta,
        idPessoa.isAcceptableOrUnknown(data['id_pessoa']!, _idPessoaMeta),
      );
    }
    if (data.containsKey('pessoa_nome')) {
      context.handle(
        _pessoaNomeMeta,
        pessoaNome.isAcceptableOrUnknown(data['pessoa_nome']!, _pessoaNomeMeta),
      );
    }
    if (data.containsKey('tipo')) {
      context.handle(
        _tipoMeta,
        tipo.isAcceptableOrUnknown(data['tipo']!, _tipoMeta),
      );
    }
    if (data.containsKey('email')) {
      context.handle(
        _emailMeta,
        email.isAcceptableOrUnknown(data['email']!, _emailMeta),
      );
    }
    if (data.containsKey('id_colaborador')) {
      context.handle(
        _idColaboradorMeta,
        idColaborador.isAcceptableOrUnknown(
          data['id_colaborador']!,
          _idColaboradorMeta,
        ),
      );
    }
    if (data.containsKey('id_usuario')) {
      context.handle(
        _idUsuarioMeta,
        idUsuario.isAcceptableOrUnknown(data['id_usuario']!, _idUsuarioMeta),
      );
    }
    if (data.containsKey('login')) {
      context.handle(
        _loginMeta,
        login.isAcceptableOrUnknown(data['login']!, _loginMeta),
      );
    }
    if (data.containsKey('senha')) {
      context.handle(
        _senhaMeta,
        senha.isAcceptableOrUnknown(data['senha']!, _senhaMeta),
      );
    }
    if (data.containsKey('data_cadastro')) {
      context.handle(
        _dataCadastroMeta,
        dataCadastro.isAcceptableOrUnknown(
          data['data_cadastro']!,
          _dataCadastroMeta,
        ),
      );
    }
    if (data.containsKey('administrador')) {
      context.handle(
        _administradorMeta,
        administrador.isAcceptableOrUnknown(
          data['administrador']!,
          _administradorMeta,
        ),
      );
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  ViewPessoaUsuario map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return ViewPessoaUsuario(
      id: attachedDatabase.typeMapping.read(
        DriftSqlType.int,
        data['${effectivePrefix}id'],
      ),
      idPessoa: attachedDatabase.typeMapping.read(
        DriftSqlType.int,
        data['${effectivePrefix}id_pessoa'],
      ),
      pessoaNome: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}pessoa_nome'],
      ),
      tipo: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}tipo'],
      ),
      email: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}email'],
      ),
      idColaborador: attachedDatabase.typeMapping.read(
        DriftSqlType.int,
        data['${effectivePrefix}id_colaborador'],
      ),
      idUsuario: attachedDatabase.typeMapping.read(
        DriftSqlType.int,
        data['${effectivePrefix}id_usuario'],
      ),
      login: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}login'],
      ),
      senha: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}senha'],
      ),
      dataCadastro: attachedDatabase.typeMapping.read(
        DriftSqlType.dateTime,
        data['${effectivePrefix}data_cadastro'],
      ),
      administrador: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}administrador'],
      ),
    );
  }

  @override
  $ViewPessoaUsuariosTable createAlias(String alias) {
    return $ViewPessoaUsuariosTable(attachedDatabase, alias);
  }
}

class ViewPessoaUsuario extends DataClass
    implements Insertable<ViewPessoaUsuario> {
  final int? id;
  final int? idPessoa;
  final String? pessoaNome;
  final String? tipo;
  final String? email;
  final int? idColaborador;
  final int? idUsuario;
  final String? login;
  final String? senha;
  final DateTime? dataCadastro;
  final String? administrador;
  const ViewPessoaUsuario({
    this.id,
    this.idPessoa,
    this.pessoaNome,
    this.tipo,
    this.email,
    this.idColaborador,
    this.idUsuario,
    this.login,
    this.senha,
    this.dataCadastro,
    this.administrador,
  });
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || idPessoa != null) {
      map['id_pessoa'] = Variable<int>(idPessoa);
    }
    if (!nullToAbsent || pessoaNome != null) {
      map['pessoa_nome'] = Variable<String>(pessoaNome);
    }
    if (!nullToAbsent || tipo != null) {
      map['tipo'] = Variable<String>(tipo);
    }
    if (!nullToAbsent || email != null) {
      map['email'] = Variable<String>(email);
    }
    if (!nullToAbsent || idColaborador != null) {
      map['id_colaborador'] = Variable<int>(idColaborador);
    }
    if (!nullToAbsent || idUsuario != null) {
      map['id_usuario'] = Variable<int>(idUsuario);
    }
    if (!nullToAbsent || login != null) {
      map['login'] = Variable<String>(login);
    }
    if (!nullToAbsent || senha != null) {
      map['senha'] = Variable<String>(senha);
    }
    if (!nullToAbsent || dataCadastro != null) {
      map['data_cadastro'] = Variable<DateTime>(dataCadastro);
    }
    if (!nullToAbsent || administrador != null) {
      map['administrador'] = Variable<String>(administrador);
    }
    return map;
  }

  factory ViewPessoaUsuario.fromJson(
    Map<String, dynamic> json, {
    ValueSerializer? serializer,
  }) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return ViewPessoaUsuario(
      id: serializer.fromJson<int?>(json['id']),
      idPessoa: serializer.fromJson<int?>(json['idPessoa']),
      pessoaNome: serializer.fromJson<String?>(json['pessoaNome']),
      tipo: serializer.fromJson<String?>(json['tipo']),
      email: serializer.fromJson<String?>(json['email']),
      idColaborador: serializer.fromJson<int?>(json['idColaborador']),
      idUsuario: serializer.fromJson<int?>(json['idUsuario']),
      login: serializer.fromJson<String?>(json['login']),
      senha: serializer.fromJson<String?>(json['senha']),
      dataCadastro: serializer.fromJson<DateTime?>(json['dataCadastro']),
      administrador: serializer.fromJson<String?>(json['administrador']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'idPessoa': serializer.toJson<int?>(idPessoa),
      'pessoaNome': serializer.toJson<String?>(pessoaNome),
      'tipo': serializer.toJson<String?>(tipo),
      'email': serializer.toJson<String?>(email),
      'idColaborador': serializer.toJson<int?>(idColaborador),
      'idUsuario': serializer.toJson<int?>(idUsuario),
      'login': serializer.toJson<String?>(login),
      'senha': serializer.toJson<String?>(senha),
      'dataCadastro': serializer.toJson<DateTime?>(dataCadastro),
      'administrador': serializer.toJson<String?>(administrador),
    };
  }

  ViewPessoaUsuario copyWith({
    Value<int?> id = const Value.absent(),
    Value<int?> idPessoa = const Value.absent(),
    Value<String?> pessoaNome = const Value.absent(),
    Value<String?> tipo = const Value.absent(),
    Value<String?> email = const Value.absent(),
    Value<int?> idColaborador = const Value.absent(),
    Value<int?> idUsuario = const Value.absent(),
    Value<String?> login = const Value.absent(),
    Value<String?> senha = const Value.absent(),
    Value<DateTime?> dataCadastro = const Value.absent(),
    Value<String?> administrador = const Value.absent(),
  }) => ViewPessoaUsuario(
    id: id.present ? id.value : this.id,
    idPessoa: idPessoa.present ? idPessoa.value : this.idPessoa,
    pessoaNome: pessoaNome.present ? pessoaNome.value : this.pessoaNome,
    tipo: tipo.present ? tipo.value : this.tipo,
    email: email.present ? email.value : this.email,
    idColaborador:
        idColaborador.present ? idColaborador.value : this.idColaborador,
    idUsuario: idUsuario.present ? idUsuario.value : this.idUsuario,
    login: login.present ? login.value : this.login,
    senha: senha.present ? senha.value : this.senha,
    dataCadastro: dataCadastro.present ? dataCadastro.value : this.dataCadastro,
    administrador:
        administrador.present ? administrador.value : this.administrador,
  );
  ViewPessoaUsuario copyWithCompanion(ViewPessoaUsuariosCompanion data) {
    return ViewPessoaUsuario(
      id: data.id.present ? data.id.value : this.id,
      idPessoa: data.idPessoa.present ? data.idPessoa.value : this.idPessoa,
      pessoaNome:
          data.pessoaNome.present ? data.pessoaNome.value : this.pessoaNome,
      tipo: data.tipo.present ? data.tipo.value : this.tipo,
      email: data.email.present ? data.email.value : this.email,
      idColaborador:
          data.idColaborador.present
              ? data.idColaborador.value
              : this.idColaborador,
      idUsuario: data.idUsuario.present ? data.idUsuario.value : this.idUsuario,
      login: data.login.present ? data.login.value : this.login,
      senha: data.senha.present ? data.senha.value : this.senha,
      dataCadastro:
          data.dataCadastro.present
              ? data.dataCadastro.value
              : this.dataCadastro,
      administrador:
          data.administrador.present
              ? data.administrador.value
              : this.administrador,
    );
  }

  @override
  String toString() {
    return (StringBuffer('ViewPessoaUsuario(')
          ..write('id: $id, ')
          ..write('idPessoa: $idPessoa, ')
          ..write('pessoaNome: $pessoaNome, ')
          ..write('tipo: $tipo, ')
          ..write('email: $email, ')
          ..write('idColaborador: $idColaborador, ')
          ..write('idUsuario: $idUsuario, ')
          ..write('login: $login, ')
          ..write('senha: $senha, ')
          ..write('dataCadastro: $dataCadastro, ')
          ..write('administrador: $administrador')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(
    id,
    idPessoa,
    pessoaNome,
    tipo,
    email,
    idColaborador,
    idUsuario,
    login,
    senha,
    dataCadastro,
    administrador,
  );
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is ViewPessoaUsuario &&
          other.id == this.id &&
          other.idPessoa == this.idPessoa &&
          other.pessoaNome == this.pessoaNome &&
          other.tipo == this.tipo &&
          other.email == this.email &&
          other.idColaborador == this.idColaborador &&
          other.idUsuario == this.idUsuario &&
          other.login == this.login &&
          other.senha == this.senha &&
          other.dataCadastro == this.dataCadastro &&
          other.administrador == this.administrador);
}

class ViewPessoaUsuariosCompanion extends UpdateCompanion<ViewPessoaUsuario> {
  final Value<int?> id;
  final Value<int?> idPessoa;
  final Value<String?> pessoaNome;
  final Value<String?> tipo;
  final Value<String?> email;
  final Value<int?> idColaborador;
  final Value<int?> idUsuario;
  final Value<String?> login;
  final Value<String?> senha;
  final Value<DateTime?> dataCadastro;
  final Value<String?> administrador;
  const ViewPessoaUsuariosCompanion({
    this.id = const Value.absent(),
    this.idPessoa = const Value.absent(),
    this.pessoaNome = const Value.absent(),
    this.tipo = const Value.absent(),
    this.email = const Value.absent(),
    this.idColaborador = const Value.absent(),
    this.idUsuario = const Value.absent(),
    this.login = const Value.absent(),
    this.senha = const Value.absent(),
    this.dataCadastro = const Value.absent(),
    this.administrador = const Value.absent(),
  });
  ViewPessoaUsuariosCompanion.insert({
    this.id = const Value.absent(),
    this.idPessoa = const Value.absent(),
    this.pessoaNome = const Value.absent(),
    this.tipo = const Value.absent(),
    this.email = const Value.absent(),
    this.idColaborador = const Value.absent(),
    this.idUsuario = const Value.absent(),
    this.login = const Value.absent(),
    this.senha = const Value.absent(),
    this.dataCadastro = const Value.absent(),
    this.administrador = const Value.absent(),
  });
  static Insertable<ViewPessoaUsuario> custom({
    Expression<int>? id,
    Expression<int>? idPessoa,
    Expression<String>? pessoaNome,
    Expression<String>? tipo,
    Expression<String>? email,
    Expression<int>? idColaborador,
    Expression<int>? idUsuario,
    Expression<String>? login,
    Expression<String>? senha,
    Expression<DateTime>? dataCadastro,
    Expression<String>? administrador,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (idPessoa != null) 'id_pessoa': idPessoa,
      if (pessoaNome != null) 'pessoa_nome': pessoaNome,
      if (tipo != null) 'tipo': tipo,
      if (email != null) 'email': email,
      if (idColaborador != null) 'id_colaborador': idColaborador,
      if (idUsuario != null) 'id_usuario': idUsuario,
      if (login != null) 'login': login,
      if (senha != null) 'senha': senha,
      if (dataCadastro != null) 'data_cadastro': dataCadastro,
      if (administrador != null) 'administrador': administrador,
    });
  }

  ViewPessoaUsuariosCompanion copyWith({
    Value<int?>? id,
    Value<int?>? idPessoa,
    Value<String?>? pessoaNome,
    Value<String?>? tipo,
    Value<String?>? email,
    Value<int?>? idColaborador,
    Value<int?>? idUsuario,
    Value<String?>? login,
    Value<String?>? senha,
    Value<DateTime?>? dataCadastro,
    Value<String?>? administrador,
  }) {
    return ViewPessoaUsuariosCompanion(
      id: id ?? this.id,
      idPessoa: idPessoa ?? this.idPessoa,
      pessoaNome: pessoaNome ?? this.pessoaNome,
      tipo: tipo ?? this.tipo,
      email: email ?? this.email,
      idColaborador: idColaborador ?? this.idColaborador,
      idUsuario: idUsuario ?? this.idUsuario,
      login: login ?? this.login,
      senha: senha ?? this.senha,
      dataCadastro: dataCadastro ?? this.dataCadastro,
      administrador: administrador ?? this.administrador,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (idPessoa.present) {
      map['id_pessoa'] = Variable<int>(idPessoa.value);
    }
    if (pessoaNome.present) {
      map['pessoa_nome'] = Variable<String>(pessoaNome.value);
    }
    if (tipo.present) {
      map['tipo'] = Variable<String>(tipo.value);
    }
    if (email.present) {
      map['email'] = Variable<String>(email.value);
    }
    if (idColaborador.present) {
      map['id_colaborador'] = Variable<int>(idColaborador.value);
    }
    if (idUsuario.present) {
      map['id_usuario'] = Variable<int>(idUsuario.value);
    }
    if (login.present) {
      map['login'] = Variable<String>(login.value);
    }
    if (senha.present) {
      map['senha'] = Variable<String>(senha.value);
    }
    if (dataCadastro.present) {
      map['data_cadastro'] = Variable<DateTime>(dataCadastro.value);
    }
    if (administrador.present) {
      map['administrador'] = Variable<String>(administrador.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('ViewPessoaUsuariosCompanion(')
          ..write('id: $id, ')
          ..write('idPessoa: $idPessoa, ')
          ..write('pessoaNome: $pessoaNome, ')
          ..write('tipo: $tipo, ')
          ..write('email: $email, ')
          ..write('idColaborador: $idColaborador, ')
          ..write('idUsuario: $idUsuario, ')
          ..write('login: $login, ')
          ..write('senha: $senha, ')
          ..write('dataCadastro: $dataCadastro, ')
          ..write('administrador: $administrador')
          ..write(')'))
        .toString();
  }
}

class $ViewPessoaColaboradorsTable extends ViewPessoaColaboradors
    with TableInfo<$ViewPessoaColaboradorsTable, ViewPessoaColaborador> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $ViewPessoaColaboradorsTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
    'id',
    aliasedName,
    true,
    type: DriftSqlType.int,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _nomeMeta = const VerificationMeta('nome');
  @override
  late final GeneratedColumn<String> nome = GeneratedColumn<String>(
    'nome',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 450,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _tipoMeta = const VerificationMeta('tipo');
  @override
  late final GeneratedColumn<String> tipo = GeneratedColumn<String>(
    'tipo',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 3,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _emailMeta = const VerificationMeta('email');
  @override
  late final GeneratedColumn<String> email = GeneratedColumn<String>(
    'email',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 750,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _siteMeta = const VerificationMeta('site');
  @override
  late final GeneratedColumn<String> site = GeneratedColumn<String>(
    'site',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 450,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _cpfCnpjMeta = const VerificationMeta(
    'cpfCnpj',
  );
  @override
  late final GeneratedColumn<String> cpfCnpj = GeneratedColumn<String>(
    'cpf_cnpj',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 20,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _rgIeMeta = const VerificationMeta('rgIe');
  @override
  late final GeneratedColumn<String> rgIe = GeneratedColumn<String>(
    'rg_ie',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 20,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _matriculaMeta = const VerificationMeta(
    'matricula',
  );
  @override
  late final GeneratedColumn<String> matricula = GeneratedColumn<String>(
    'matricula',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 50,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _dataCadastroMeta = const VerificationMeta(
    'dataCadastro',
  );
  @override
  late final GeneratedColumn<DateTime> dataCadastro = GeneratedColumn<DateTime>(
    'data_cadastro',
    aliasedName,
    true,
    type: DriftSqlType.dateTime,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _dataAdmissaoMeta = const VerificationMeta(
    'dataAdmissao',
  );
  @override
  late final GeneratedColumn<DateTime> dataAdmissao = GeneratedColumn<DateTime>(
    'data_admissao',
    aliasedName,
    true,
    type: DriftSqlType.dateTime,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _dataDemissaoMeta = const VerificationMeta(
    'dataDemissao',
  );
  @override
  late final GeneratedColumn<DateTime> dataDemissao = GeneratedColumn<DateTime>(
    'data_demissao',
    aliasedName,
    true,
    type: DriftSqlType.dateTime,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _ctpsNumeroMeta = const VerificationMeta(
    'ctpsNumero',
  );
  @override
  late final GeneratedColumn<String> ctpsNumero = GeneratedColumn<String>(
    'ctps_numero',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 20,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _ctpsSerieMeta = const VerificationMeta(
    'ctpsSerie',
  );
  @override
  late final GeneratedColumn<String> ctpsSerie = GeneratedColumn<String>(
    'ctps_serie',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 10,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _ctpsDataExpedicaoMeta = const VerificationMeta(
    'ctpsDataExpedicao',
  );
  @override
  late final GeneratedColumn<DateTime> ctpsDataExpedicao =
      GeneratedColumn<DateTime>(
        'ctps_data_expedicao',
        aliasedName,
        true,
        type: DriftSqlType.dateTime,
        requiredDuringInsert: false,
      );
  static const VerificationMeta _ctpsUfMeta = const VerificationMeta('ctpsUf');
  @override
  late final GeneratedColumn<String> ctpsUf = GeneratedColumn<String>(
    'ctps_uf',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 2,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _observacaoMeta = const VerificationMeta(
    'observacao',
  );
  @override
  late final GeneratedColumn<String> observacao = GeneratedColumn<String>(
    'observacao',
    aliasedName,
    true,
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _logradouroMeta = const VerificationMeta(
    'logradouro',
  );
  @override
  late final GeneratedColumn<String> logradouro = GeneratedColumn<String>(
    'logradouro',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 450,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _numeroMeta = const VerificationMeta('numero');
  @override
  late final GeneratedColumn<String> numero = GeneratedColumn<String>(
    'numero',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 20,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _complementoMeta = const VerificationMeta(
    'complemento',
  );
  @override
  late final GeneratedColumn<String> complemento = GeneratedColumn<String>(
    'complemento',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 450,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _bairroMeta = const VerificationMeta('bairro');
  @override
  late final GeneratedColumn<String> bairro = GeneratedColumn<String>(
    'bairro',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 150,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _cidadeMeta = const VerificationMeta('cidade');
  @override
  late final GeneratedColumn<String> cidade = GeneratedColumn<String>(
    'cidade',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 150,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _cepMeta = const VerificationMeta('cep');
  @override
  late final GeneratedColumn<String> cep = GeneratedColumn<String>(
    'cep',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 10,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _municipioIbgeMeta = const VerificationMeta(
    'municipioIbge',
  );
  @override
  late final GeneratedColumn<String> municipioIbge = GeneratedColumn<String>(
    'municipio_ibge',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 10,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _ufMeta = const VerificationMeta('uf');
  @override
  late final GeneratedColumn<String> uf = GeneratedColumn<String>(
    'uf',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 2,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _idPessoaMeta = const VerificationMeta(
    'idPessoa',
  );
  @override
  late final GeneratedColumn<int> idPessoa = GeneratedColumn<int>(
    'id_pessoa',
    aliasedName,
    true,
    type: DriftSqlType.int,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _idCargoMeta = const VerificationMeta(
    'idCargo',
  );
  @override
  late final GeneratedColumn<int> idCargo = GeneratedColumn<int>(
    'id_cargo',
    aliasedName,
    true,
    type: DriftSqlType.int,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _idSetorMeta = const VerificationMeta(
    'idSetor',
  );
  @override
  late final GeneratedColumn<int> idSetor = GeneratedColumn<int>(
    'id_setor',
    aliasedName,
    true,
    type: DriftSqlType.int,
    requiredDuringInsert: false,
  );
  @override
  List<GeneratedColumn> get $columns => [
    id,
    nome,
    tipo,
    email,
    site,
    cpfCnpj,
    rgIe,
    matricula,
    dataCadastro,
    dataAdmissao,
    dataDemissao,
    ctpsNumero,
    ctpsSerie,
    ctpsDataExpedicao,
    ctpsUf,
    observacao,
    logradouro,
    numero,
    complemento,
    bairro,
    cidade,
    cep,
    municipioIbge,
    uf,
    idPessoa,
    idCargo,
    idSetor,
  ];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'view_pessoa_colaborador';
  @override
  VerificationContext validateIntegrity(
    Insertable<ViewPessoaColaborador> instance, {
    bool isInserting = false,
  }) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('nome')) {
      context.handle(
        _nomeMeta,
        nome.isAcceptableOrUnknown(data['nome']!, _nomeMeta),
      );
    }
    if (data.containsKey('tipo')) {
      context.handle(
        _tipoMeta,
        tipo.isAcceptableOrUnknown(data['tipo']!, _tipoMeta),
      );
    }
    if (data.containsKey('email')) {
      context.handle(
        _emailMeta,
        email.isAcceptableOrUnknown(data['email']!, _emailMeta),
      );
    }
    if (data.containsKey('site')) {
      context.handle(
        _siteMeta,
        site.isAcceptableOrUnknown(data['site']!, _siteMeta),
      );
    }
    if (data.containsKey('cpf_cnpj')) {
      context.handle(
        _cpfCnpjMeta,
        cpfCnpj.isAcceptableOrUnknown(data['cpf_cnpj']!, _cpfCnpjMeta),
      );
    }
    if (data.containsKey('rg_ie')) {
      context.handle(
        _rgIeMeta,
        rgIe.isAcceptableOrUnknown(data['rg_ie']!, _rgIeMeta),
      );
    }
    if (data.containsKey('matricula')) {
      context.handle(
        _matriculaMeta,
        matricula.isAcceptableOrUnknown(data['matricula']!, _matriculaMeta),
      );
    }
    if (data.containsKey('data_cadastro')) {
      context.handle(
        _dataCadastroMeta,
        dataCadastro.isAcceptableOrUnknown(
          data['data_cadastro']!,
          _dataCadastroMeta,
        ),
      );
    }
    if (data.containsKey('data_admissao')) {
      context.handle(
        _dataAdmissaoMeta,
        dataAdmissao.isAcceptableOrUnknown(
          data['data_admissao']!,
          _dataAdmissaoMeta,
        ),
      );
    }
    if (data.containsKey('data_demissao')) {
      context.handle(
        _dataDemissaoMeta,
        dataDemissao.isAcceptableOrUnknown(
          data['data_demissao']!,
          _dataDemissaoMeta,
        ),
      );
    }
    if (data.containsKey('ctps_numero')) {
      context.handle(
        _ctpsNumeroMeta,
        ctpsNumero.isAcceptableOrUnknown(data['ctps_numero']!, _ctpsNumeroMeta),
      );
    }
    if (data.containsKey('ctps_serie')) {
      context.handle(
        _ctpsSerieMeta,
        ctpsSerie.isAcceptableOrUnknown(data['ctps_serie']!, _ctpsSerieMeta),
      );
    }
    if (data.containsKey('ctps_data_expedicao')) {
      context.handle(
        _ctpsDataExpedicaoMeta,
        ctpsDataExpedicao.isAcceptableOrUnknown(
          data['ctps_data_expedicao']!,
          _ctpsDataExpedicaoMeta,
        ),
      );
    }
    if (data.containsKey('ctps_uf')) {
      context.handle(
        _ctpsUfMeta,
        ctpsUf.isAcceptableOrUnknown(data['ctps_uf']!, _ctpsUfMeta),
      );
    }
    if (data.containsKey('observacao')) {
      context.handle(
        _observacaoMeta,
        observacao.isAcceptableOrUnknown(data['observacao']!, _observacaoMeta),
      );
    }
    if (data.containsKey('logradouro')) {
      context.handle(
        _logradouroMeta,
        logradouro.isAcceptableOrUnknown(data['logradouro']!, _logradouroMeta),
      );
    }
    if (data.containsKey('numero')) {
      context.handle(
        _numeroMeta,
        numero.isAcceptableOrUnknown(data['numero']!, _numeroMeta),
      );
    }
    if (data.containsKey('complemento')) {
      context.handle(
        _complementoMeta,
        complemento.isAcceptableOrUnknown(
          data['complemento']!,
          _complementoMeta,
        ),
      );
    }
    if (data.containsKey('bairro')) {
      context.handle(
        _bairroMeta,
        bairro.isAcceptableOrUnknown(data['bairro']!, _bairroMeta),
      );
    }
    if (data.containsKey('cidade')) {
      context.handle(
        _cidadeMeta,
        cidade.isAcceptableOrUnknown(data['cidade']!, _cidadeMeta),
      );
    }
    if (data.containsKey('cep')) {
      context.handle(
        _cepMeta,
        cep.isAcceptableOrUnknown(data['cep']!, _cepMeta),
      );
    }
    if (data.containsKey('municipio_ibge')) {
      context.handle(
        _municipioIbgeMeta,
        municipioIbge.isAcceptableOrUnknown(
          data['municipio_ibge']!,
          _municipioIbgeMeta,
        ),
      );
    }
    if (data.containsKey('uf')) {
      context.handle(_ufMeta, uf.isAcceptableOrUnknown(data['uf']!, _ufMeta));
    }
    if (data.containsKey('id_pessoa')) {
      context.handle(
        _idPessoaMeta,
        idPessoa.isAcceptableOrUnknown(data['id_pessoa']!, _idPessoaMeta),
      );
    }
    if (data.containsKey('id_cargo')) {
      context.handle(
        _idCargoMeta,
        idCargo.isAcceptableOrUnknown(data['id_cargo']!, _idCargoMeta),
      );
    }
    if (data.containsKey('id_setor')) {
      context.handle(
        _idSetorMeta,
        idSetor.isAcceptableOrUnknown(data['id_setor']!, _idSetorMeta),
      );
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  ViewPessoaColaborador map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return ViewPessoaColaborador(
      id: attachedDatabase.typeMapping.read(
        DriftSqlType.int,
        data['${effectivePrefix}id'],
      ),
      nome: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}nome'],
      ),
      tipo: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}tipo'],
      ),
      email: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}email'],
      ),
      site: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}site'],
      ),
      cpfCnpj: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}cpf_cnpj'],
      ),
      rgIe: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}rg_ie'],
      ),
      matricula: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}matricula'],
      ),
      dataCadastro: attachedDatabase.typeMapping.read(
        DriftSqlType.dateTime,
        data['${effectivePrefix}data_cadastro'],
      ),
      dataAdmissao: attachedDatabase.typeMapping.read(
        DriftSqlType.dateTime,
        data['${effectivePrefix}data_admissao'],
      ),
      dataDemissao: attachedDatabase.typeMapping.read(
        DriftSqlType.dateTime,
        data['${effectivePrefix}data_demissao'],
      ),
      ctpsNumero: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}ctps_numero'],
      ),
      ctpsSerie: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}ctps_serie'],
      ),
      ctpsDataExpedicao: attachedDatabase.typeMapping.read(
        DriftSqlType.dateTime,
        data['${effectivePrefix}ctps_data_expedicao'],
      ),
      ctpsUf: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}ctps_uf'],
      ),
      observacao: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}observacao'],
      ),
      logradouro: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}logradouro'],
      ),
      numero: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}numero'],
      ),
      complemento: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}complemento'],
      ),
      bairro: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}bairro'],
      ),
      cidade: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}cidade'],
      ),
      cep: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}cep'],
      ),
      municipioIbge: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}municipio_ibge'],
      ),
      uf: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}uf'],
      ),
      idPessoa: attachedDatabase.typeMapping.read(
        DriftSqlType.int,
        data['${effectivePrefix}id_pessoa'],
      ),
      idCargo: attachedDatabase.typeMapping.read(
        DriftSqlType.int,
        data['${effectivePrefix}id_cargo'],
      ),
      idSetor: attachedDatabase.typeMapping.read(
        DriftSqlType.int,
        data['${effectivePrefix}id_setor'],
      ),
    );
  }

  @override
  $ViewPessoaColaboradorsTable createAlias(String alias) {
    return $ViewPessoaColaboradorsTable(attachedDatabase, alias);
  }
}

class ViewPessoaColaborador extends DataClass
    implements Insertable<ViewPessoaColaborador> {
  final int? id;
  final String? nome;
  final String? tipo;
  final String? email;
  final String? site;
  final String? cpfCnpj;
  final String? rgIe;
  final String? matricula;
  final DateTime? dataCadastro;
  final DateTime? dataAdmissao;
  final DateTime? dataDemissao;
  final String? ctpsNumero;
  final String? ctpsSerie;
  final DateTime? ctpsDataExpedicao;
  final String? ctpsUf;
  final String? observacao;
  final String? logradouro;
  final String? numero;
  final String? complemento;
  final String? bairro;
  final String? cidade;
  final String? cep;
  final String? municipioIbge;
  final String? uf;
  final int? idPessoa;
  final int? idCargo;
  final int? idSetor;
  const ViewPessoaColaborador({
    this.id,
    this.nome,
    this.tipo,
    this.email,
    this.site,
    this.cpfCnpj,
    this.rgIe,
    this.matricula,
    this.dataCadastro,
    this.dataAdmissao,
    this.dataDemissao,
    this.ctpsNumero,
    this.ctpsSerie,
    this.ctpsDataExpedicao,
    this.ctpsUf,
    this.observacao,
    this.logradouro,
    this.numero,
    this.complemento,
    this.bairro,
    this.cidade,
    this.cep,
    this.municipioIbge,
    this.uf,
    this.idPessoa,
    this.idCargo,
    this.idSetor,
  });
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || nome != null) {
      map['nome'] = Variable<String>(nome);
    }
    if (!nullToAbsent || tipo != null) {
      map['tipo'] = Variable<String>(tipo);
    }
    if (!nullToAbsent || email != null) {
      map['email'] = Variable<String>(email);
    }
    if (!nullToAbsent || site != null) {
      map['site'] = Variable<String>(site);
    }
    if (!nullToAbsent || cpfCnpj != null) {
      map['cpf_cnpj'] = Variable<String>(cpfCnpj);
    }
    if (!nullToAbsent || rgIe != null) {
      map['rg_ie'] = Variable<String>(rgIe);
    }
    if (!nullToAbsent || matricula != null) {
      map['matricula'] = Variable<String>(matricula);
    }
    if (!nullToAbsent || dataCadastro != null) {
      map['data_cadastro'] = Variable<DateTime>(dataCadastro);
    }
    if (!nullToAbsent || dataAdmissao != null) {
      map['data_admissao'] = Variable<DateTime>(dataAdmissao);
    }
    if (!nullToAbsent || dataDemissao != null) {
      map['data_demissao'] = Variable<DateTime>(dataDemissao);
    }
    if (!nullToAbsent || ctpsNumero != null) {
      map['ctps_numero'] = Variable<String>(ctpsNumero);
    }
    if (!nullToAbsent || ctpsSerie != null) {
      map['ctps_serie'] = Variable<String>(ctpsSerie);
    }
    if (!nullToAbsent || ctpsDataExpedicao != null) {
      map['ctps_data_expedicao'] = Variable<DateTime>(ctpsDataExpedicao);
    }
    if (!nullToAbsent || ctpsUf != null) {
      map['ctps_uf'] = Variable<String>(ctpsUf);
    }
    if (!nullToAbsent || observacao != null) {
      map['observacao'] = Variable<String>(observacao);
    }
    if (!nullToAbsent || logradouro != null) {
      map['logradouro'] = Variable<String>(logradouro);
    }
    if (!nullToAbsent || numero != null) {
      map['numero'] = Variable<String>(numero);
    }
    if (!nullToAbsent || complemento != null) {
      map['complemento'] = Variable<String>(complemento);
    }
    if (!nullToAbsent || bairro != null) {
      map['bairro'] = Variable<String>(bairro);
    }
    if (!nullToAbsent || cidade != null) {
      map['cidade'] = Variable<String>(cidade);
    }
    if (!nullToAbsent || cep != null) {
      map['cep'] = Variable<String>(cep);
    }
    if (!nullToAbsent || municipioIbge != null) {
      map['municipio_ibge'] = Variable<String>(municipioIbge);
    }
    if (!nullToAbsent || uf != null) {
      map['uf'] = Variable<String>(uf);
    }
    if (!nullToAbsent || idPessoa != null) {
      map['id_pessoa'] = Variable<int>(idPessoa);
    }
    if (!nullToAbsent || idCargo != null) {
      map['id_cargo'] = Variable<int>(idCargo);
    }
    if (!nullToAbsent || idSetor != null) {
      map['id_setor'] = Variable<int>(idSetor);
    }
    return map;
  }

  factory ViewPessoaColaborador.fromJson(
    Map<String, dynamic> json, {
    ValueSerializer? serializer,
  }) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return ViewPessoaColaborador(
      id: serializer.fromJson<int?>(json['id']),
      nome: serializer.fromJson<String?>(json['nome']),
      tipo: serializer.fromJson<String?>(json['tipo']),
      email: serializer.fromJson<String?>(json['email']),
      site: serializer.fromJson<String?>(json['site']),
      cpfCnpj: serializer.fromJson<String?>(json['cpfCnpj']),
      rgIe: serializer.fromJson<String?>(json['rgIe']),
      matricula: serializer.fromJson<String?>(json['matricula']),
      dataCadastro: serializer.fromJson<DateTime?>(json['dataCadastro']),
      dataAdmissao: serializer.fromJson<DateTime?>(json['dataAdmissao']),
      dataDemissao: serializer.fromJson<DateTime?>(json['dataDemissao']),
      ctpsNumero: serializer.fromJson<String?>(json['ctpsNumero']),
      ctpsSerie: serializer.fromJson<String?>(json['ctpsSerie']),
      ctpsDataExpedicao: serializer.fromJson<DateTime?>(
        json['ctpsDataExpedicao'],
      ),
      ctpsUf: serializer.fromJson<String?>(json['ctpsUf']),
      observacao: serializer.fromJson<String?>(json['observacao']),
      logradouro: serializer.fromJson<String?>(json['logradouro']),
      numero: serializer.fromJson<String?>(json['numero']),
      complemento: serializer.fromJson<String?>(json['complemento']),
      bairro: serializer.fromJson<String?>(json['bairro']),
      cidade: serializer.fromJson<String?>(json['cidade']),
      cep: serializer.fromJson<String?>(json['cep']),
      municipioIbge: serializer.fromJson<String?>(json['municipioIbge']),
      uf: serializer.fromJson<String?>(json['uf']),
      idPessoa: serializer.fromJson<int?>(json['idPessoa']),
      idCargo: serializer.fromJson<int?>(json['idCargo']),
      idSetor: serializer.fromJson<int?>(json['idSetor']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'nome': serializer.toJson<String?>(nome),
      'tipo': serializer.toJson<String?>(tipo),
      'email': serializer.toJson<String?>(email),
      'site': serializer.toJson<String?>(site),
      'cpfCnpj': serializer.toJson<String?>(cpfCnpj),
      'rgIe': serializer.toJson<String?>(rgIe),
      'matricula': serializer.toJson<String?>(matricula),
      'dataCadastro': serializer.toJson<DateTime?>(dataCadastro),
      'dataAdmissao': serializer.toJson<DateTime?>(dataAdmissao),
      'dataDemissao': serializer.toJson<DateTime?>(dataDemissao),
      'ctpsNumero': serializer.toJson<String?>(ctpsNumero),
      'ctpsSerie': serializer.toJson<String?>(ctpsSerie),
      'ctpsDataExpedicao': serializer.toJson<DateTime?>(ctpsDataExpedicao),
      'ctpsUf': serializer.toJson<String?>(ctpsUf),
      'observacao': serializer.toJson<String?>(observacao),
      'logradouro': serializer.toJson<String?>(logradouro),
      'numero': serializer.toJson<String?>(numero),
      'complemento': serializer.toJson<String?>(complemento),
      'bairro': serializer.toJson<String?>(bairro),
      'cidade': serializer.toJson<String?>(cidade),
      'cep': serializer.toJson<String?>(cep),
      'municipioIbge': serializer.toJson<String?>(municipioIbge),
      'uf': serializer.toJson<String?>(uf),
      'idPessoa': serializer.toJson<int?>(idPessoa),
      'idCargo': serializer.toJson<int?>(idCargo),
      'idSetor': serializer.toJson<int?>(idSetor),
    };
  }

  ViewPessoaColaborador copyWith({
    Value<int?> id = const Value.absent(),
    Value<String?> nome = const Value.absent(),
    Value<String?> tipo = const Value.absent(),
    Value<String?> email = const Value.absent(),
    Value<String?> site = const Value.absent(),
    Value<String?> cpfCnpj = const Value.absent(),
    Value<String?> rgIe = const Value.absent(),
    Value<String?> matricula = const Value.absent(),
    Value<DateTime?> dataCadastro = const Value.absent(),
    Value<DateTime?> dataAdmissao = const Value.absent(),
    Value<DateTime?> dataDemissao = const Value.absent(),
    Value<String?> ctpsNumero = const Value.absent(),
    Value<String?> ctpsSerie = const Value.absent(),
    Value<DateTime?> ctpsDataExpedicao = const Value.absent(),
    Value<String?> ctpsUf = const Value.absent(),
    Value<String?> observacao = const Value.absent(),
    Value<String?> logradouro = const Value.absent(),
    Value<String?> numero = const Value.absent(),
    Value<String?> complemento = const Value.absent(),
    Value<String?> bairro = const Value.absent(),
    Value<String?> cidade = const Value.absent(),
    Value<String?> cep = const Value.absent(),
    Value<String?> municipioIbge = const Value.absent(),
    Value<String?> uf = const Value.absent(),
    Value<int?> idPessoa = const Value.absent(),
    Value<int?> idCargo = const Value.absent(),
    Value<int?> idSetor = const Value.absent(),
  }) => ViewPessoaColaborador(
    id: id.present ? id.value : this.id,
    nome: nome.present ? nome.value : this.nome,
    tipo: tipo.present ? tipo.value : this.tipo,
    email: email.present ? email.value : this.email,
    site: site.present ? site.value : this.site,
    cpfCnpj: cpfCnpj.present ? cpfCnpj.value : this.cpfCnpj,
    rgIe: rgIe.present ? rgIe.value : this.rgIe,
    matricula: matricula.present ? matricula.value : this.matricula,
    dataCadastro: dataCadastro.present ? dataCadastro.value : this.dataCadastro,
    dataAdmissao: dataAdmissao.present ? dataAdmissao.value : this.dataAdmissao,
    dataDemissao: dataDemissao.present ? dataDemissao.value : this.dataDemissao,
    ctpsNumero: ctpsNumero.present ? ctpsNumero.value : this.ctpsNumero,
    ctpsSerie: ctpsSerie.present ? ctpsSerie.value : this.ctpsSerie,
    ctpsDataExpedicao:
        ctpsDataExpedicao.present
            ? ctpsDataExpedicao.value
            : this.ctpsDataExpedicao,
    ctpsUf: ctpsUf.present ? ctpsUf.value : this.ctpsUf,
    observacao: observacao.present ? observacao.value : this.observacao,
    logradouro: logradouro.present ? logradouro.value : this.logradouro,
    numero: numero.present ? numero.value : this.numero,
    complemento: complemento.present ? complemento.value : this.complemento,
    bairro: bairro.present ? bairro.value : this.bairro,
    cidade: cidade.present ? cidade.value : this.cidade,
    cep: cep.present ? cep.value : this.cep,
    municipioIbge:
        municipioIbge.present ? municipioIbge.value : this.municipioIbge,
    uf: uf.present ? uf.value : this.uf,
    idPessoa: idPessoa.present ? idPessoa.value : this.idPessoa,
    idCargo: idCargo.present ? idCargo.value : this.idCargo,
    idSetor: idSetor.present ? idSetor.value : this.idSetor,
  );
  ViewPessoaColaborador copyWithCompanion(
    ViewPessoaColaboradorsCompanion data,
  ) {
    return ViewPessoaColaborador(
      id: data.id.present ? data.id.value : this.id,
      nome: data.nome.present ? data.nome.value : this.nome,
      tipo: data.tipo.present ? data.tipo.value : this.tipo,
      email: data.email.present ? data.email.value : this.email,
      site: data.site.present ? data.site.value : this.site,
      cpfCnpj: data.cpfCnpj.present ? data.cpfCnpj.value : this.cpfCnpj,
      rgIe: data.rgIe.present ? data.rgIe.value : this.rgIe,
      matricula: data.matricula.present ? data.matricula.value : this.matricula,
      dataCadastro:
          data.dataCadastro.present
              ? data.dataCadastro.value
              : this.dataCadastro,
      dataAdmissao:
          data.dataAdmissao.present
              ? data.dataAdmissao.value
              : this.dataAdmissao,
      dataDemissao:
          data.dataDemissao.present
              ? data.dataDemissao.value
              : this.dataDemissao,
      ctpsNumero:
          data.ctpsNumero.present ? data.ctpsNumero.value : this.ctpsNumero,
      ctpsSerie: data.ctpsSerie.present ? data.ctpsSerie.value : this.ctpsSerie,
      ctpsDataExpedicao:
          data.ctpsDataExpedicao.present
              ? data.ctpsDataExpedicao.value
              : this.ctpsDataExpedicao,
      ctpsUf: data.ctpsUf.present ? data.ctpsUf.value : this.ctpsUf,
      observacao:
          data.observacao.present ? data.observacao.value : this.observacao,
      logradouro:
          data.logradouro.present ? data.logradouro.value : this.logradouro,
      numero: data.numero.present ? data.numero.value : this.numero,
      complemento:
          data.complemento.present ? data.complemento.value : this.complemento,
      bairro: data.bairro.present ? data.bairro.value : this.bairro,
      cidade: data.cidade.present ? data.cidade.value : this.cidade,
      cep: data.cep.present ? data.cep.value : this.cep,
      municipioIbge:
          data.municipioIbge.present
              ? data.municipioIbge.value
              : this.municipioIbge,
      uf: data.uf.present ? data.uf.value : this.uf,
      idPessoa: data.idPessoa.present ? data.idPessoa.value : this.idPessoa,
      idCargo: data.idCargo.present ? data.idCargo.value : this.idCargo,
      idSetor: data.idSetor.present ? data.idSetor.value : this.idSetor,
    );
  }

  @override
  String toString() {
    return (StringBuffer('ViewPessoaColaborador(')
          ..write('id: $id, ')
          ..write('nome: $nome, ')
          ..write('tipo: $tipo, ')
          ..write('email: $email, ')
          ..write('site: $site, ')
          ..write('cpfCnpj: $cpfCnpj, ')
          ..write('rgIe: $rgIe, ')
          ..write('matricula: $matricula, ')
          ..write('dataCadastro: $dataCadastro, ')
          ..write('dataAdmissao: $dataAdmissao, ')
          ..write('dataDemissao: $dataDemissao, ')
          ..write('ctpsNumero: $ctpsNumero, ')
          ..write('ctpsSerie: $ctpsSerie, ')
          ..write('ctpsDataExpedicao: $ctpsDataExpedicao, ')
          ..write('ctpsUf: $ctpsUf, ')
          ..write('observacao: $observacao, ')
          ..write('logradouro: $logradouro, ')
          ..write('numero: $numero, ')
          ..write('complemento: $complemento, ')
          ..write('bairro: $bairro, ')
          ..write('cidade: $cidade, ')
          ..write('cep: $cep, ')
          ..write('municipioIbge: $municipioIbge, ')
          ..write('uf: $uf, ')
          ..write('idPessoa: $idPessoa, ')
          ..write('idCargo: $idCargo, ')
          ..write('idSetor: $idSetor')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hashAll([
    id,
    nome,
    tipo,
    email,
    site,
    cpfCnpj,
    rgIe,
    matricula,
    dataCadastro,
    dataAdmissao,
    dataDemissao,
    ctpsNumero,
    ctpsSerie,
    ctpsDataExpedicao,
    ctpsUf,
    observacao,
    logradouro,
    numero,
    complemento,
    bairro,
    cidade,
    cep,
    municipioIbge,
    uf,
    idPessoa,
    idCargo,
    idSetor,
  ]);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is ViewPessoaColaborador &&
          other.id == this.id &&
          other.nome == this.nome &&
          other.tipo == this.tipo &&
          other.email == this.email &&
          other.site == this.site &&
          other.cpfCnpj == this.cpfCnpj &&
          other.rgIe == this.rgIe &&
          other.matricula == this.matricula &&
          other.dataCadastro == this.dataCadastro &&
          other.dataAdmissao == this.dataAdmissao &&
          other.dataDemissao == this.dataDemissao &&
          other.ctpsNumero == this.ctpsNumero &&
          other.ctpsSerie == this.ctpsSerie &&
          other.ctpsDataExpedicao == this.ctpsDataExpedicao &&
          other.ctpsUf == this.ctpsUf &&
          other.observacao == this.observacao &&
          other.logradouro == this.logradouro &&
          other.numero == this.numero &&
          other.complemento == this.complemento &&
          other.bairro == this.bairro &&
          other.cidade == this.cidade &&
          other.cep == this.cep &&
          other.municipioIbge == this.municipioIbge &&
          other.uf == this.uf &&
          other.idPessoa == this.idPessoa &&
          other.idCargo == this.idCargo &&
          other.idSetor == this.idSetor);
}

class ViewPessoaColaboradorsCompanion
    extends UpdateCompanion<ViewPessoaColaborador> {
  final Value<int?> id;
  final Value<String?> nome;
  final Value<String?> tipo;
  final Value<String?> email;
  final Value<String?> site;
  final Value<String?> cpfCnpj;
  final Value<String?> rgIe;
  final Value<String?> matricula;
  final Value<DateTime?> dataCadastro;
  final Value<DateTime?> dataAdmissao;
  final Value<DateTime?> dataDemissao;
  final Value<String?> ctpsNumero;
  final Value<String?> ctpsSerie;
  final Value<DateTime?> ctpsDataExpedicao;
  final Value<String?> ctpsUf;
  final Value<String?> observacao;
  final Value<String?> logradouro;
  final Value<String?> numero;
  final Value<String?> complemento;
  final Value<String?> bairro;
  final Value<String?> cidade;
  final Value<String?> cep;
  final Value<String?> municipioIbge;
  final Value<String?> uf;
  final Value<int?> idPessoa;
  final Value<int?> idCargo;
  final Value<int?> idSetor;
  const ViewPessoaColaboradorsCompanion({
    this.id = const Value.absent(),
    this.nome = const Value.absent(),
    this.tipo = const Value.absent(),
    this.email = const Value.absent(),
    this.site = const Value.absent(),
    this.cpfCnpj = const Value.absent(),
    this.rgIe = const Value.absent(),
    this.matricula = const Value.absent(),
    this.dataCadastro = const Value.absent(),
    this.dataAdmissao = const Value.absent(),
    this.dataDemissao = const Value.absent(),
    this.ctpsNumero = const Value.absent(),
    this.ctpsSerie = const Value.absent(),
    this.ctpsDataExpedicao = const Value.absent(),
    this.ctpsUf = const Value.absent(),
    this.observacao = const Value.absent(),
    this.logradouro = const Value.absent(),
    this.numero = const Value.absent(),
    this.complemento = const Value.absent(),
    this.bairro = const Value.absent(),
    this.cidade = const Value.absent(),
    this.cep = const Value.absent(),
    this.municipioIbge = const Value.absent(),
    this.uf = const Value.absent(),
    this.idPessoa = const Value.absent(),
    this.idCargo = const Value.absent(),
    this.idSetor = const Value.absent(),
  });
  ViewPessoaColaboradorsCompanion.insert({
    this.id = const Value.absent(),
    this.nome = const Value.absent(),
    this.tipo = const Value.absent(),
    this.email = const Value.absent(),
    this.site = const Value.absent(),
    this.cpfCnpj = const Value.absent(),
    this.rgIe = const Value.absent(),
    this.matricula = const Value.absent(),
    this.dataCadastro = const Value.absent(),
    this.dataAdmissao = const Value.absent(),
    this.dataDemissao = const Value.absent(),
    this.ctpsNumero = const Value.absent(),
    this.ctpsSerie = const Value.absent(),
    this.ctpsDataExpedicao = const Value.absent(),
    this.ctpsUf = const Value.absent(),
    this.observacao = const Value.absent(),
    this.logradouro = const Value.absent(),
    this.numero = const Value.absent(),
    this.complemento = const Value.absent(),
    this.bairro = const Value.absent(),
    this.cidade = const Value.absent(),
    this.cep = const Value.absent(),
    this.municipioIbge = const Value.absent(),
    this.uf = const Value.absent(),
    this.idPessoa = const Value.absent(),
    this.idCargo = const Value.absent(),
    this.idSetor = const Value.absent(),
  });
  static Insertable<ViewPessoaColaborador> custom({
    Expression<int>? id,
    Expression<String>? nome,
    Expression<String>? tipo,
    Expression<String>? email,
    Expression<String>? site,
    Expression<String>? cpfCnpj,
    Expression<String>? rgIe,
    Expression<String>? matricula,
    Expression<DateTime>? dataCadastro,
    Expression<DateTime>? dataAdmissao,
    Expression<DateTime>? dataDemissao,
    Expression<String>? ctpsNumero,
    Expression<String>? ctpsSerie,
    Expression<DateTime>? ctpsDataExpedicao,
    Expression<String>? ctpsUf,
    Expression<String>? observacao,
    Expression<String>? logradouro,
    Expression<String>? numero,
    Expression<String>? complemento,
    Expression<String>? bairro,
    Expression<String>? cidade,
    Expression<String>? cep,
    Expression<String>? municipioIbge,
    Expression<String>? uf,
    Expression<int>? idPessoa,
    Expression<int>? idCargo,
    Expression<int>? idSetor,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (nome != null) 'nome': nome,
      if (tipo != null) 'tipo': tipo,
      if (email != null) 'email': email,
      if (site != null) 'site': site,
      if (cpfCnpj != null) 'cpf_cnpj': cpfCnpj,
      if (rgIe != null) 'rg_ie': rgIe,
      if (matricula != null) 'matricula': matricula,
      if (dataCadastro != null) 'data_cadastro': dataCadastro,
      if (dataAdmissao != null) 'data_admissao': dataAdmissao,
      if (dataDemissao != null) 'data_demissao': dataDemissao,
      if (ctpsNumero != null) 'ctps_numero': ctpsNumero,
      if (ctpsSerie != null) 'ctps_serie': ctpsSerie,
      if (ctpsDataExpedicao != null) 'ctps_data_expedicao': ctpsDataExpedicao,
      if (ctpsUf != null) 'ctps_uf': ctpsUf,
      if (observacao != null) 'observacao': observacao,
      if (logradouro != null) 'logradouro': logradouro,
      if (numero != null) 'numero': numero,
      if (complemento != null) 'complemento': complemento,
      if (bairro != null) 'bairro': bairro,
      if (cidade != null) 'cidade': cidade,
      if (cep != null) 'cep': cep,
      if (municipioIbge != null) 'municipio_ibge': municipioIbge,
      if (uf != null) 'uf': uf,
      if (idPessoa != null) 'id_pessoa': idPessoa,
      if (idCargo != null) 'id_cargo': idCargo,
      if (idSetor != null) 'id_setor': idSetor,
    });
  }

  ViewPessoaColaboradorsCompanion copyWith({
    Value<int?>? id,
    Value<String?>? nome,
    Value<String?>? tipo,
    Value<String?>? email,
    Value<String?>? site,
    Value<String?>? cpfCnpj,
    Value<String?>? rgIe,
    Value<String?>? matricula,
    Value<DateTime?>? dataCadastro,
    Value<DateTime?>? dataAdmissao,
    Value<DateTime?>? dataDemissao,
    Value<String?>? ctpsNumero,
    Value<String?>? ctpsSerie,
    Value<DateTime?>? ctpsDataExpedicao,
    Value<String?>? ctpsUf,
    Value<String?>? observacao,
    Value<String?>? logradouro,
    Value<String?>? numero,
    Value<String?>? complemento,
    Value<String?>? bairro,
    Value<String?>? cidade,
    Value<String?>? cep,
    Value<String?>? municipioIbge,
    Value<String?>? uf,
    Value<int?>? idPessoa,
    Value<int?>? idCargo,
    Value<int?>? idSetor,
  }) {
    return ViewPessoaColaboradorsCompanion(
      id: id ?? this.id,
      nome: nome ?? this.nome,
      tipo: tipo ?? this.tipo,
      email: email ?? this.email,
      site: site ?? this.site,
      cpfCnpj: cpfCnpj ?? this.cpfCnpj,
      rgIe: rgIe ?? this.rgIe,
      matricula: matricula ?? this.matricula,
      dataCadastro: dataCadastro ?? this.dataCadastro,
      dataAdmissao: dataAdmissao ?? this.dataAdmissao,
      dataDemissao: dataDemissao ?? this.dataDemissao,
      ctpsNumero: ctpsNumero ?? this.ctpsNumero,
      ctpsSerie: ctpsSerie ?? this.ctpsSerie,
      ctpsDataExpedicao: ctpsDataExpedicao ?? this.ctpsDataExpedicao,
      ctpsUf: ctpsUf ?? this.ctpsUf,
      observacao: observacao ?? this.observacao,
      logradouro: logradouro ?? this.logradouro,
      numero: numero ?? this.numero,
      complemento: complemento ?? this.complemento,
      bairro: bairro ?? this.bairro,
      cidade: cidade ?? this.cidade,
      cep: cep ?? this.cep,
      municipioIbge: municipioIbge ?? this.municipioIbge,
      uf: uf ?? this.uf,
      idPessoa: idPessoa ?? this.idPessoa,
      idCargo: idCargo ?? this.idCargo,
      idSetor: idSetor ?? this.idSetor,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (nome.present) {
      map['nome'] = Variable<String>(nome.value);
    }
    if (tipo.present) {
      map['tipo'] = Variable<String>(tipo.value);
    }
    if (email.present) {
      map['email'] = Variable<String>(email.value);
    }
    if (site.present) {
      map['site'] = Variable<String>(site.value);
    }
    if (cpfCnpj.present) {
      map['cpf_cnpj'] = Variable<String>(cpfCnpj.value);
    }
    if (rgIe.present) {
      map['rg_ie'] = Variable<String>(rgIe.value);
    }
    if (matricula.present) {
      map['matricula'] = Variable<String>(matricula.value);
    }
    if (dataCadastro.present) {
      map['data_cadastro'] = Variable<DateTime>(dataCadastro.value);
    }
    if (dataAdmissao.present) {
      map['data_admissao'] = Variable<DateTime>(dataAdmissao.value);
    }
    if (dataDemissao.present) {
      map['data_demissao'] = Variable<DateTime>(dataDemissao.value);
    }
    if (ctpsNumero.present) {
      map['ctps_numero'] = Variable<String>(ctpsNumero.value);
    }
    if (ctpsSerie.present) {
      map['ctps_serie'] = Variable<String>(ctpsSerie.value);
    }
    if (ctpsDataExpedicao.present) {
      map['ctps_data_expedicao'] = Variable<DateTime>(ctpsDataExpedicao.value);
    }
    if (ctpsUf.present) {
      map['ctps_uf'] = Variable<String>(ctpsUf.value);
    }
    if (observacao.present) {
      map['observacao'] = Variable<String>(observacao.value);
    }
    if (logradouro.present) {
      map['logradouro'] = Variable<String>(logradouro.value);
    }
    if (numero.present) {
      map['numero'] = Variable<String>(numero.value);
    }
    if (complemento.present) {
      map['complemento'] = Variable<String>(complemento.value);
    }
    if (bairro.present) {
      map['bairro'] = Variable<String>(bairro.value);
    }
    if (cidade.present) {
      map['cidade'] = Variable<String>(cidade.value);
    }
    if (cep.present) {
      map['cep'] = Variable<String>(cep.value);
    }
    if (municipioIbge.present) {
      map['municipio_ibge'] = Variable<String>(municipioIbge.value);
    }
    if (uf.present) {
      map['uf'] = Variable<String>(uf.value);
    }
    if (idPessoa.present) {
      map['id_pessoa'] = Variable<int>(idPessoa.value);
    }
    if (idCargo.present) {
      map['id_cargo'] = Variable<int>(idCargo.value);
    }
    if (idSetor.present) {
      map['id_setor'] = Variable<int>(idSetor.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('ViewPessoaColaboradorsCompanion(')
          ..write('id: $id, ')
          ..write('nome: $nome, ')
          ..write('tipo: $tipo, ')
          ..write('email: $email, ')
          ..write('site: $site, ')
          ..write('cpfCnpj: $cpfCnpj, ')
          ..write('rgIe: $rgIe, ')
          ..write('matricula: $matricula, ')
          ..write('dataCadastro: $dataCadastro, ')
          ..write('dataAdmissao: $dataAdmissao, ')
          ..write('dataDemissao: $dataDemissao, ')
          ..write('ctpsNumero: $ctpsNumero, ')
          ..write('ctpsSerie: $ctpsSerie, ')
          ..write('ctpsDataExpedicao: $ctpsDataExpedicao, ')
          ..write('ctpsUf: $ctpsUf, ')
          ..write('observacao: $observacao, ')
          ..write('logradouro: $logradouro, ')
          ..write('numero: $numero, ')
          ..write('complemento: $complemento, ')
          ..write('bairro: $bairro, ')
          ..write('cidade: $cidade, ')
          ..write('cep: $cep, ')
          ..write('municipioIbge: $municipioIbge, ')
          ..write('uf: $uf, ')
          ..write('idPessoa: $idPessoa, ')
          ..write('idCargo: $idCargo, ')
          ..write('idSetor: $idSetor')
          ..write(')'))
        .toString();
  }
}

abstract class _$AppDatabase extends GeneratedDatabase {
  _$AppDatabase(QueryExecutor e) : super(e);
  $AppDatabaseManager get managers => $AppDatabaseManager(this);
  late final $PcpOpDetalhesTable pcpOpDetalhes = $PcpOpDetalhesTable(this);
  late final $PcpServicoColaboradorsTable pcpServicoColaboradors =
      $PcpServicoColaboradorsTable(this);
  late final $PcpInstrucaoOpsTable pcpInstrucaoOps = $PcpInstrucaoOpsTable(
    this,
  );
  late final $PcpServicoEquipamentosTable pcpServicoEquipamentos =
      $PcpServicoEquipamentosTable(this);
  late final $PcpOpCabecalhosTable pcpOpCabecalhos = $PcpOpCabecalhosTable(
    this,
  );
  late final $PcpServicosTable pcpServicos = $PcpServicosTable(this);
  late final $ProdutosTable produtos = $ProdutosTable(this);
  late final $PatrimBemsTable patrimBems = $PatrimBemsTable(this);
  late final $PcpInstrucaosTable pcpInstrucaos = $PcpInstrucaosTable(this);
  late final $ViewControleAcessosTable viewControleAcessos =
      $ViewControleAcessosTable(this);
  late final $ViewPessoaUsuariosTable viewPessoaUsuarios =
      $ViewPessoaUsuariosTable(this);
  late final $ViewPessoaColaboradorsTable viewPessoaColaboradors =
      $ViewPessoaColaboradorsTable(this);
  late final PcpOpCabecalhoDao pcpOpCabecalhoDao = PcpOpCabecalhoDao(
    this as AppDatabase,
  );
  late final PcpServicoDao pcpServicoDao = PcpServicoDao(this as AppDatabase);
  late final ProdutoDao produtoDao = ProdutoDao(this as AppDatabase);
  late final PatrimBemDao patrimBemDao = PatrimBemDao(this as AppDatabase);
  late final PcpInstrucaoDao pcpInstrucaoDao = PcpInstrucaoDao(
    this as AppDatabase,
  );
  late final ViewControleAcessoDao viewControleAcessoDao =
      ViewControleAcessoDao(this as AppDatabase);
  late final ViewPessoaUsuarioDao viewPessoaUsuarioDao = ViewPessoaUsuarioDao(
    this as AppDatabase,
  );
  late final ViewPessoaColaboradorDao viewPessoaColaboradorDao =
      ViewPessoaColaboradorDao(this as AppDatabase);
  @override
  Iterable<TableInfo<Table, Object?>> get allTables =>
      allSchemaEntities.whereType<TableInfo<Table, Object?>>();
  @override
  List<DatabaseSchemaEntity> get allSchemaEntities => [
    pcpOpDetalhes,
    pcpServicoColaboradors,
    pcpInstrucaoOps,
    pcpServicoEquipamentos,
    pcpOpCabecalhos,
    pcpServicos,
    produtos,
    patrimBems,
    pcpInstrucaos,
    viewControleAcessos,
    viewPessoaUsuarios,
    viewPessoaColaboradors,
  ];
}

typedef $$PcpOpDetalhesTableCreateCompanionBuilder =
    PcpOpDetalhesCompanion Function({
      Value<int?> id,
      Value<int?> idPcpOpCabecalho,
      Value<int?> idProduto,
      Value<double?> quantidadeProduzir,
      Value<double?> quantidadeProduzida,
      Value<double?> quantidadeEntregue,
      Value<double?> custoPrevisto,
      Value<double?> custoRealizado,
    });
typedef $$PcpOpDetalhesTableUpdateCompanionBuilder =
    PcpOpDetalhesCompanion Function({
      Value<int?> id,
      Value<int?> idPcpOpCabecalho,
      Value<int?> idProduto,
      Value<double?> quantidadeProduzir,
      Value<double?> quantidadeProduzida,
      Value<double?> quantidadeEntregue,
      Value<double?> custoPrevisto,
      Value<double?> custoRealizado,
    });

class $$PcpOpDetalhesTableFilterComposer
    extends Composer<_$AppDatabase, $PcpOpDetalhesTable> {
  $$PcpOpDetalhesTableFilterComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnFilters<int> get id => $composableBuilder(
    column: $table.id,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<int> get idPcpOpCabecalho => $composableBuilder(
    column: $table.idPcpOpCabecalho,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<int> get idProduto => $composableBuilder(
    column: $table.idProduto,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<double> get quantidadeProduzir => $composableBuilder(
    column: $table.quantidadeProduzir,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<double> get quantidadeProduzida => $composableBuilder(
    column: $table.quantidadeProduzida,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<double> get quantidadeEntregue => $composableBuilder(
    column: $table.quantidadeEntregue,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<double> get custoPrevisto => $composableBuilder(
    column: $table.custoPrevisto,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<double> get custoRealizado => $composableBuilder(
    column: $table.custoRealizado,
    builder: (column) => ColumnFilters(column),
  );
}

class $$PcpOpDetalhesTableOrderingComposer
    extends Composer<_$AppDatabase, $PcpOpDetalhesTable> {
  $$PcpOpDetalhesTableOrderingComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnOrderings<int> get id => $composableBuilder(
    column: $table.id,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<int> get idPcpOpCabecalho => $composableBuilder(
    column: $table.idPcpOpCabecalho,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<int> get idProduto => $composableBuilder(
    column: $table.idProduto,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<double> get quantidadeProduzir => $composableBuilder(
    column: $table.quantidadeProduzir,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<double> get quantidadeProduzida => $composableBuilder(
    column: $table.quantidadeProduzida,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<double> get quantidadeEntregue => $composableBuilder(
    column: $table.quantidadeEntregue,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<double> get custoPrevisto => $composableBuilder(
    column: $table.custoPrevisto,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<double> get custoRealizado => $composableBuilder(
    column: $table.custoRealizado,
    builder: (column) => ColumnOrderings(column),
  );
}

class $$PcpOpDetalhesTableAnnotationComposer
    extends Composer<_$AppDatabase, $PcpOpDetalhesTable> {
  $$PcpOpDetalhesTableAnnotationComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  GeneratedColumn<int> get id =>
      $composableBuilder(column: $table.id, builder: (column) => column);

  GeneratedColumn<int> get idPcpOpCabecalho => $composableBuilder(
    column: $table.idPcpOpCabecalho,
    builder: (column) => column,
  );

  GeneratedColumn<int> get idProduto =>
      $composableBuilder(column: $table.idProduto, builder: (column) => column);

  GeneratedColumn<double> get quantidadeProduzir => $composableBuilder(
    column: $table.quantidadeProduzir,
    builder: (column) => column,
  );

  GeneratedColumn<double> get quantidadeProduzida => $composableBuilder(
    column: $table.quantidadeProduzida,
    builder: (column) => column,
  );

  GeneratedColumn<double> get quantidadeEntregue => $composableBuilder(
    column: $table.quantidadeEntregue,
    builder: (column) => column,
  );

  GeneratedColumn<double> get custoPrevisto => $composableBuilder(
    column: $table.custoPrevisto,
    builder: (column) => column,
  );

  GeneratedColumn<double> get custoRealizado => $composableBuilder(
    column: $table.custoRealizado,
    builder: (column) => column,
  );
}

class $$PcpOpDetalhesTableTableManager
    extends
        RootTableManager<
          _$AppDatabase,
          $PcpOpDetalhesTable,
          PcpOpDetalhe,
          $$PcpOpDetalhesTableFilterComposer,
          $$PcpOpDetalhesTableOrderingComposer,
          $$PcpOpDetalhesTableAnnotationComposer,
          $$PcpOpDetalhesTableCreateCompanionBuilder,
          $$PcpOpDetalhesTableUpdateCompanionBuilder,
          (
            PcpOpDetalhe,
            BaseReferences<_$AppDatabase, $PcpOpDetalhesTable, PcpOpDetalhe>,
          ),
          PcpOpDetalhe,
          PrefetchHooks Function()
        > {
  $$PcpOpDetalhesTableTableManager(_$AppDatabase db, $PcpOpDetalhesTable table)
    : super(
        TableManagerState(
          db: db,
          table: table,
          createFilteringComposer:
              () => $$PcpOpDetalhesTableFilterComposer($db: db, $table: table),
          createOrderingComposer:
              () =>
                  $$PcpOpDetalhesTableOrderingComposer($db: db, $table: table),
          createComputedFieldComposer:
              () => $$PcpOpDetalhesTableAnnotationComposer(
                $db: db,
                $table: table,
              ),
          updateCompanionCallback:
              ({
                Value<int?> id = const Value.absent(),
                Value<int?> idPcpOpCabecalho = const Value.absent(),
                Value<int?> idProduto = const Value.absent(),
                Value<double?> quantidadeProduzir = const Value.absent(),
                Value<double?> quantidadeProduzida = const Value.absent(),
                Value<double?> quantidadeEntregue = const Value.absent(),
                Value<double?> custoPrevisto = const Value.absent(),
                Value<double?> custoRealizado = const Value.absent(),
              }) => PcpOpDetalhesCompanion(
                id: id,
                idPcpOpCabecalho: idPcpOpCabecalho,
                idProduto: idProduto,
                quantidadeProduzir: quantidadeProduzir,
                quantidadeProduzida: quantidadeProduzida,
                quantidadeEntregue: quantidadeEntregue,
                custoPrevisto: custoPrevisto,
                custoRealizado: custoRealizado,
              ),
          createCompanionCallback:
              ({
                Value<int?> id = const Value.absent(),
                Value<int?> idPcpOpCabecalho = const Value.absent(),
                Value<int?> idProduto = const Value.absent(),
                Value<double?> quantidadeProduzir = const Value.absent(),
                Value<double?> quantidadeProduzida = const Value.absent(),
                Value<double?> quantidadeEntregue = const Value.absent(),
                Value<double?> custoPrevisto = const Value.absent(),
                Value<double?> custoRealizado = const Value.absent(),
              }) => PcpOpDetalhesCompanion.insert(
                id: id,
                idPcpOpCabecalho: idPcpOpCabecalho,
                idProduto: idProduto,
                quantidadeProduzir: quantidadeProduzir,
                quantidadeProduzida: quantidadeProduzida,
                quantidadeEntregue: quantidadeEntregue,
                custoPrevisto: custoPrevisto,
                custoRealizado: custoRealizado,
              ),
          withReferenceMapper:
              (p0) =>
                  p0
                      .map(
                        (e) => (
                          e.readTable(table),
                          BaseReferences(db, table, e),
                        ),
                      )
                      .toList(),
          prefetchHooksCallback: null,
        ),
      );
}

typedef $$PcpOpDetalhesTableProcessedTableManager =
    ProcessedTableManager<
      _$AppDatabase,
      $PcpOpDetalhesTable,
      PcpOpDetalhe,
      $$PcpOpDetalhesTableFilterComposer,
      $$PcpOpDetalhesTableOrderingComposer,
      $$PcpOpDetalhesTableAnnotationComposer,
      $$PcpOpDetalhesTableCreateCompanionBuilder,
      $$PcpOpDetalhesTableUpdateCompanionBuilder,
      (
        PcpOpDetalhe,
        BaseReferences<_$AppDatabase, $PcpOpDetalhesTable, PcpOpDetalhe>,
      ),
      PcpOpDetalhe,
      PrefetchHooks Function()
    >;
typedef $$PcpServicoColaboradorsTableCreateCompanionBuilder =
    PcpServicoColaboradorsCompanion Function({
      Value<int?> id,
      Value<int?> idColaborador,
      Value<int?> idPcpServico,
    });
typedef $$PcpServicoColaboradorsTableUpdateCompanionBuilder =
    PcpServicoColaboradorsCompanion Function({
      Value<int?> id,
      Value<int?> idColaborador,
      Value<int?> idPcpServico,
    });

class $$PcpServicoColaboradorsTableFilterComposer
    extends Composer<_$AppDatabase, $PcpServicoColaboradorsTable> {
  $$PcpServicoColaboradorsTableFilterComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnFilters<int> get id => $composableBuilder(
    column: $table.id,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<int> get idColaborador => $composableBuilder(
    column: $table.idColaborador,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<int> get idPcpServico => $composableBuilder(
    column: $table.idPcpServico,
    builder: (column) => ColumnFilters(column),
  );
}

class $$PcpServicoColaboradorsTableOrderingComposer
    extends Composer<_$AppDatabase, $PcpServicoColaboradorsTable> {
  $$PcpServicoColaboradorsTableOrderingComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnOrderings<int> get id => $composableBuilder(
    column: $table.id,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<int> get idColaborador => $composableBuilder(
    column: $table.idColaborador,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<int> get idPcpServico => $composableBuilder(
    column: $table.idPcpServico,
    builder: (column) => ColumnOrderings(column),
  );
}

class $$PcpServicoColaboradorsTableAnnotationComposer
    extends Composer<_$AppDatabase, $PcpServicoColaboradorsTable> {
  $$PcpServicoColaboradorsTableAnnotationComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  GeneratedColumn<int> get id =>
      $composableBuilder(column: $table.id, builder: (column) => column);

  GeneratedColumn<int> get idColaborador => $composableBuilder(
    column: $table.idColaborador,
    builder: (column) => column,
  );

  GeneratedColumn<int> get idPcpServico => $composableBuilder(
    column: $table.idPcpServico,
    builder: (column) => column,
  );
}

class $$PcpServicoColaboradorsTableTableManager
    extends
        RootTableManager<
          _$AppDatabase,
          $PcpServicoColaboradorsTable,
          PcpServicoColaborador,
          $$PcpServicoColaboradorsTableFilterComposer,
          $$PcpServicoColaboradorsTableOrderingComposer,
          $$PcpServicoColaboradorsTableAnnotationComposer,
          $$PcpServicoColaboradorsTableCreateCompanionBuilder,
          $$PcpServicoColaboradorsTableUpdateCompanionBuilder,
          (
            PcpServicoColaborador,
            BaseReferences<
              _$AppDatabase,
              $PcpServicoColaboradorsTable,
              PcpServicoColaborador
            >,
          ),
          PcpServicoColaborador,
          PrefetchHooks Function()
        > {
  $$PcpServicoColaboradorsTableTableManager(
    _$AppDatabase db,
    $PcpServicoColaboradorsTable table,
  ) : super(
        TableManagerState(
          db: db,
          table: table,
          createFilteringComposer:
              () => $$PcpServicoColaboradorsTableFilterComposer(
                $db: db,
                $table: table,
              ),
          createOrderingComposer:
              () => $$PcpServicoColaboradorsTableOrderingComposer(
                $db: db,
                $table: table,
              ),
          createComputedFieldComposer:
              () => $$PcpServicoColaboradorsTableAnnotationComposer(
                $db: db,
                $table: table,
              ),
          updateCompanionCallback:
              ({
                Value<int?> id = const Value.absent(),
                Value<int?> idColaborador = const Value.absent(),
                Value<int?> idPcpServico = const Value.absent(),
              }) => PcpServicoColaboradorsCompanion(
                id: id,
                idColaborador: idColaborador,
                idPcpServico: idPcpServico,
              ),
          createCompanionCallback:
              ({
                Value<int?> id = const Value.absent(),
                Value<int?> idColaborador = const Value.absent(),
                Value<int?> idPcpServico = const Value.absent(),
              }) => PcpServicoColaboradorsCompanion.insert(
                id: id,
                idColaborador: idColaborador,
                idPcpServico: idPcpServico,
              ),
          withReferenceMapper:
              (p0) =>
                  p0
                      .map(
                        (e) => (
                          e.readTable(table),
                          BaseReferences(db, table, e),
                        ),
                      )
                      .toList(),
          prefetchHooksCallback: null,
        ),
      );
}

typedef $$PcpServicoColaboradorsTableProcessedTableManager =
    ProcessedTableManager<
      _$AppDatabase,
      $PcpServicoColaboradorsTable,
      PcpServicoColaborador,
      $$PcpServicoColaboradorsTableFilterComposer,
      $$PcpServicoColaboradorsTableOrderingComposer,
      $$PcpServicoColaboradorsTableAnnotationComposer,
      $$PcpServicoColaboradorsTableCreateCompanionBuilder,
      $$PcpServicoColaboradorsTableUpdateCompanionBuilder,
      (
        PcpServicoColaborador,
        BaseReferences<
          _$AppDatabase,
          $PcpServicoColaboradorsTable,
          PcpServicoColaborador
        >,
      ),
      PcpServicoColaborador,
      PrefetchHooks Function()
    >;
typedef $$PcpInstrucaoOpsTableCreateCompanionBuilder =
    PcpInstrucaoOpsCompanion Function({
      Value<int?> id,
      Value<int?> idPcpInstrucao,
      Value<int?> idPcpOpCabecalho,
    });
typedef $$PcpInstrucaoOpsTableUpdateCompanionBuilder =
    PcpInstrucaoOpsCompanion Function({
      Value<int?> id,
      Value<int?> idPcpInstrucao,
      Value<int?> idPcpOpCabecalho,
    });

class $$PcpInstrucaoOpsTableFilterComposer
    extends Composer<_$AppDatabase, $PcpInstrucaoOpsTable> {
  $$PcpInstrucaoOpsTableFilterComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnFilters<int> get id => $composableBuilder(
    column: $table.id,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<int> get idPcpInstrucao => $composableBuilder(
    column: $table.idPcpInstrucao,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<int> get idPcpOpCabecalho => $composableBuilder(
    column: $table.idPcpOpCabecalho,
    builder: (column) => ColumnFilters(column),
  );
}

class $$PcpInstrucaoOpsTableOrderingComposer
    extends Composer<_$AppDatabase, $PcpInstrucaoOpsTable> {
  $$PcpInstrucaoOpsTableOrderingComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnOrderings<int> get id => $composableBuilder(
    column: $table.id,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<int> get idPcpInstrucao => $composableBuilder(
    column: $table.idPcpInstrucao,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<int> get idPcpOpCabecalho => $composableBuilder(
    column: $table.idPcpOpCabecalho,
    builder: (column) => ColumnOrderings(column),
  );
}

class $$PcpInstrucaoOpsTableAnnotationComposer
    extends Composer<_$AppDatabase, $PcpInstrucaoOpsTable> {
  $$PcpInstrucaoOpsTableAnnotationComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  GeneratedColumn<int> get id =>
      $composableBuilder(column: $table.id, builder: (column) => column);

  GeneratedColumn<int> get idPcpInstrucao => $composableBuilder(
    column: $table.idPcpInstrucao,
    builder: (column) => column,
  );

  GeneratedColumn<int> get idPcpOpCabecalho => $composableBuilder(
    column: $table.idPcpOpCabecalho,
    builder: (column) => column,
  );
}

class $$PcpInstrucaoOpsTableTableManager
    extends
        RootTableManager<
          _$AppDatabase,
          $PcpInstrucaoOpsTable,
          PcpInstrucaoOp,
          $$PcpInstrucaoOpsTableFilterComposer,
          $$PcpInstrucaoOpsTableOrderingComposer,
          $$PcpInstrucaoOpsTableAnnotationComposer,
          $$PcpInstrucaoOpsTableCreateCompanionBuilder,
          $$PcpInstrucaoOpsTableUpdateCompanionBuilder,
          (
            PcpInstrucaoOp,
            BaseReferences<
              _$AppDatabase,
              $PcpInstrucaoOpsTable,
              PcpInstrucaoOp
            >,
          ),
          PcpInstrucaoOp,
          PrefetchHooks Function()
        > {
  $$PcpInstrucaoOpsTableTableManager(
    _$AppDatabase db,
    $PcpInstrucaoOpsTable table,
  ) : super(
        TableManagerState(
          db: db,
          table: table,
          createFilteringComposer:
              () =>
                  $$PcpInstrucaoOpsTableFilterComposer($db: db, $table: table),
          createOrderingComposer:
              () => $$PcpInstrucaoOpsTableOrderingComposer(
                $db: db,
                $table: table,
              ),
          createComputedFieldComposer:
              () => $$PcpInstrucaoOpsTableAnnotationComposer(
                $db: db,
                $table: table,
              ),
          updateCompanionCallback:
              ({
                Value<int?> id = const Value.absent(),
                Value<int?> idPcpInstrucao = const Value.absent(),
                Value<int?> idPcpOpCabecalho = const Value.absent(),
              }) => PcpInstrucaoOpsCompanion(
                id: id,
                idPcpInstrucao: idPcpInstrucao,
                idPcpOpCabecalho: idPcpOpCabecalho,
              ),
          createCompanionCallback:
              ({
                Value<int?> id = const Value.absent(),
                Value<int?> idPcpInstrucao = const Value.absent(),
                Value<int?> idPcpOpCabecalho = const Value.absent(),
              }) => PcpInstrucaoOpsCompanion.insert(
                id: id,
                idPcpInstrucao: idPcpInstrucao,
                idPcpOpCabecalho: idPcpOpCabecalho,
              ),
          withReferenceMapper:
              (p0) =>
                  p0
                      .map(
                        (e) => (
                          e.readTable(table),
                          BaseReferences(db, table, e),
                        ),
                      )
                      .toList(),
          prefetchHooksCallback: null,
        ),
      );
}

typedef $$PcpInstrucaoOpsTableProcessedTableManager =
    ProcessedTableManager<
      _$AppDatabase,
      $PcpInstrucaoOpsTable,
      PcpInstrucaoOp,
      $$PcpInstrucaoOpsTableFilterComposer,
      $$PcpInstrucaoOpsTableOrderingComposer,
      $$PcpInstrucaoOpsTableAnnotationComposer,
      $$PcpInstrucaoOpsTableCreateCompanionBuilder,
      $$PcpInstrucaoOpsTableUpdateCompanionBuilder,
      (
        PcpInstrucaoOp,
        BaseReferences<_$AppDatabase, $PcpInstrucaoOpsTable, PcpInstrucaoOp>,
      ),
      PcpInstrucaoOp,
      PrefetchHooks Function()
    >;
typedef $$PcpServicoEquipamentosTableCreateCompanionBuilder =
    PcpServicoEquipamentosCompanion Function({
      Value<int?> id,
      Value<int?> idPcpServico,
      Value<int?> idPatrimBem,
    });
typedef $$PcpServicoEquipamentosTableUpdateCompanionBuilder =
    PcpServicoEquipamentosCompanion Function({
      Value<int?> id,
      Value<int?> idPcpServico,
      Value<int?> idPatrimBem,
    });

class $$PcpServicoEquipamentosTableFilterComposer
    extends Composer<_$AppDatabase, $PcpServicoEquipamentosTable> {
  $$PcpServicoEquipamentosTableFilterComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnFilters<int> get id => $composableBuilder(
    column: $table.id,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<int> get idPcpServico => $composableBuilder(
    column: $table.idPcpServico,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<int> get idPatrimBem => $composableBuilder(
    column: $table.idPatrimBem,
    builder: (column) => ColumnFilters(column),
  );
}

class $$PcpServicoEquipamentosTableOrderingComposer
    extends Composer<_$AppDatabase, $PcpServicoEquipamentosTable> {
  $$PcpServicoEquipamentosTableOrderingComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnOrderings<int> get id => $composableBuilder(
    column: $table.id,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<int> get idPcpServico => $composableBuilder(
    column: $table.idPcpServico,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<int> get idPatrimBem => $composableBuilder(
    column: $table.idPatrimBem,
    builder: (column) => ColumnOrderings(column),
  );
}

class $$PcpServicoEquipamentosTableAnnotationComposer
    extends Composer<_$AppDatabase, $PcpServicoEquipamentosTable> {
  $$PcpServicoEquipamentosTableAnnotationComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  GeneratedColumn<int> get id =>
      $composableBuilder(column: $table.id, builder: (column) => column);

  GeneratedColumn<int> get idPcpServico => $composableBuilder(
    column: $table.idPcpServico,
    builder: (column) => column,
  );

  GeneratedColumn<int> get idPatrimBem => $composableBuilder(
    column: $table.idPatrimBem,
    builder: (column) => column,
  );
}

class $$PcpServicoEquipamentosTableTableManager
    extends
        RootTableManager<
          _$AppDatabase,
          $PcpServicoEquipamentosTable,
          PcpServicoEquipamento,
          $$PcpServicoEquipamentosTableFilterComposer,
          $$PcpServicoEquipamentosTableOrderingComposer,
          $$PcpServicoEquipamentosTableAnnotationComposer,
          $$PcpServicoEquipamentosTableCreateCompanionBuilder,
          $$PcpServicoEquipamentosTableUpdateCompanionBuilder,
          (
            PcpServicoEquipamento,
            BaseReferences<
              _$AppDatabase,
              $PcpServicoEquipamentosTable,
              PcpServicoEquipamento
            >,
          ),
          PcpServicoEquipamento,
          PrefetchHooks Function()
        > {
  $$PcpServicoEquipamentosTableTableManager(
    _$AppDatabase db,
    $PcpServicoEquipamentosTable table,
  ) : super(
        TableManagerState(
          db: db,
          table: table,
          createFilteringComposer:
              () => $$PcpServicoEquipamentosTableFilterComposer(
                $db: db,
                $table: table,
              ),
          createOrderingComposer:
              () => $$PcpServicoEquipamentosTableOrderingComposer(
                $db: db,
                $table: table,
              ),
          createComputedFieldComposer:
              () => $$PcpServicoEquipamentosTableAnnotationComposer(
                $db: db,
                $table: table,
              ),
          updateCompanionCallback:
              ({
                Value<int?> id = const Value.absent(),
                Value<int?> idPcpServico = const Value.absent(),
                Value<int?> idPatrimBem = const Value.absent(),
              }) => PcpServicoEquipamentosCompanion(
                id: id,
                idPcpServico: idPcpServico,
                idPatrimBem: idPatrimBem,
              ),
          createCompanionCallback:
              ({
                Value<int?> id = const Value.absent(),
                Value<int?> idPcpServico = const Value.absent(),
                Value<int?> idPatrimBem = const Value.absent(),
              }) => PcpServicoEquipamentosCompanion.insert(
                id: id,
                idPcpServico: idPcpServico,
                idPatrimBem: idPatrimBem,
              ),
          withReferenceMapper:
              (p0) =>
                  p0
                      .map(
                        (e) => (
                          e.readTable(table),
                          BaseReferences(db, table, e),
                        ),
                      )
                      .toList(),
          prefetchHooksCallback: null,
        ),
      );
}

typedef $$PcpServicoEquipamentosTableProcessedTableManager =
    ProcessedTableManager<
      _$AppDatabase,
      $PcpServicoEquipamentosTable,
      PcpServicoEquipamento,
      $$PcpServicoEquipamentosTableFilterComposer,
      $$PcpServicoEquipamentosTableOrderingComposer,
      $$PcpServicoEquipamentosTableAnnotationComposer,
      $$PcpServicoEquipamentosTableCreateCompanionBuilder,
      $$PcpServicoEquipamentosTableUpdateCompanionBuilder,
      (
        PcpServicoEquipamento,
        BaseReferences<
          _$AppDatabase,
          $PcpServicoEquipamentosTable,
          PcpServicoEquipamento
        >,
      ),
      PcpServicoEquipamento,
      PrefetchHooks Function()
    >;
typedef $$PcpOpCabecalhosTableCreateCompanionBuilder =
    PcpOpCabecalhosCompanion Function({
      Value<int?> id,
      Value<DateTime?> dataInicio,
      Value<DateTime?> dataPrevisaoEntrega,
      Value<DateTime?> dataTermino,
      Value<double?> custoTotalPrevisto,
      Value<double?> custoTotalRealizado,
      Value<double?> porcentoVenda,
      Value<double?> porcentoEstoque,
    });
typedef $$PcpOpCabecalhosTableUpdateCompanionBuilder =
    PcpOpCabecalhosCompanion Function({
      Value<int?> id,
      Value<DateTime?> dataInicio,
      Value<DateTime?> dataPrevisaoEntrega,
      Value<DateTime?> dataTermino,
      Value<double?> custoTotalPrevisto,
      Value<double?> custoTotalRealizado,
      Value<double?> porcentoVenda,
      Value<double?> porcentoEstoque,
    });

class $$PcpOpCabecalhosTableFilterComposer
    extends Composer<_$AppDatabase, $PcpOpCabecalhosTable> {
  $$PcpOpCabecalhosTableFilterComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnFilters<int> get id => $composableBuilder(
    column: $table.id,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<DateTime> get dataInicio => $composableBuilder(
    column: $table.dataInicio,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<DateTime> get dataPrevisaoEntrega => $composableBuilder(
    column: $table.dataPrevisaoEntrega,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<DateTime> get dataTermino => $composableBuilder(
    column: $table.dataTermino,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<double> get custoTotalPrevisto => $composableBuilder(
    column: $table.custoTotalPrevisto,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<double> get custoTotalRealizado => $composableBuilder(
    column: $table.custoTotalRealizado,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<double> get porcentoVenda => $composableBuilder(
    column: $table.porcentoVenda,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<double> get porcentoEstoque => $composableBuilder(
    column: $table.porcentoEstoque,
    builder: (column) => ColumnFilters(column),
  );
}

class $$PcpOpCabecalhosTableOrderingComposer
    extends Composer<_$AppDatabase, $PcpOpCabecalhosTable> {
  $$PcpOpCabecalhosTableOrderingComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnOrderings<int> get id => $composableBuilder(
    column: $table.id,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<DateTime> get dataInicio => $composableBuilder(
    column: $table.dataInicio,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<DateTime> get dataPrevisaoEntrega => $composableBuilder(
    column: $table.dataPrevisaoEntrega,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<DateTime> get dataTermino => $composableBuilder(
    column: $table.dataTermino,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<double> get custoTotalPrevisto => $composableBuilder(
    column: $table.custoTotalPrevisto,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<double> get custoTotalRealizado => $composableBuilder(
    column: $table.custoTotalRealizado,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<double> get porcentoVenda => $composableBuilder(
    column: $table.porcentoVenda,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<double> get porcentoEstoque => $composableBuilder(
    column: $table.porcentoEstoque,
    builder: (column) => ColumnOrderings(column),
  );
}

class $$PcpOpCabecalhosTableAnnotationComposer
    extends Composer<_$AppDatabase, $PcpOpCabecalhosTable> {
  $$PcpOpCabecalhosTableAnnotationComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  GeneratedColumn<int> get id =>
      $composableBuilder(column: $table.id, builder: (column) => column);

  GeneratedColumn<DateTime> get dataInicio => $composableBuilder(
    column: $table.dataInicio,
    builder: (column) => column,
  );

  GeneratedColumn<DateTime> get dataPrevisaoEntrega => $composableBuilder(
    column: $table.dataPrevisaoEntrega,
    builder: (column) => column,
  );

  GeneratedColumn<DateTime> get dataTermino => $composableBuilder(
    column: $table.dataTermino,
    builder: (column) => column,
  );

  GeneratedColumn<double> get custoTotalPrevisto => $composableBuilder(
    column: $table.custoTotalPrevisto,
    builder: (column) => column,
  );

  GeneratedColumn<double> get custoTotalRealizado => $composableBuilder(
    column: $table.custoTotalRealizado,
    builder: (column) => column,
  );

  GeneratedColumn<double> get porcentoVenda => $composableBuilder(
    column: $table.porcentoVenda,
    builder: (column) => column,
  );

  GeneratedColumn<double> get porcentoEstoque => $composableBuilder(
    column: $table.porcentoEstoque,
    builder: (column) => column,
  );
}

class $$PcpOpCabecalhosTableTableManager
    extends
        RootTableManager<
          _$AppDatabase,
          $PcpOpCabecalhosTable,
          PcpOpCabecalho,
          $$PcpOpCabecalhosTableFilterComposer,
          $$PcpOpCabecalhosTableOrderingComposer,
          $$PcpOpCabecalhosTableAnnotationComposer,
          $$PcpOpCabecalhosTableCreateCompanionBuilder,
          $$PcpOpCabecalhosTableUpdateCompanionBuilder,
          (
            PcpOpCabecalho,
            BaseReferences<
              _$AppDatabase,
              $PcpOpCabecalhosTable,
              PcpOpCabecalho
            >,
          ),
          PcpOpCabecalho,
          PrefetchHooks Function()
        > {
  $$PcpOpCabecalhosTableTableManager(
    _$AppDatabase db,
    $PcpOpCabecalhosTable table,
  ) : super(
        TableManagerState(
          db: db,
          table: table,
          createFilteringComposer:
              () =>
                  $$PcpOpCabecalhosTableFilterComposer($db: db, $table: table),
          createOrderingComposer:
              () => $$PcpOpCabecalhosTableOrderingComposer(
                $db: db,
                $table: table,
              ),
          createComputedFieldComposer:
              () => $$PcpOpCabecalhosTableAnnotationComposer(
                $db: db,
                $table: table,
              ),
          updateCompanionCallback:
              ({
                Value<int?> id = const Value.absent(),
                Value<DateTime?> dataInicio = const Value.absent(),
                Value<DateTime?> dataPrevisaoEntrega = const Value.absent(),
                Value<DateTime?> dataTermino = const Value.absent(),
                Value<double?> custoTotalPrevisto = const Value.absent(),
                Value<double?> custoTotalRealizado = const Value.absent(),
                Value<double?> porcentoVenda = const Value.absent(),
                Value<double?> porcentoEstoque = const Value.absent(),
              }) => PcpOpCabecalhosCompanion(
                id: id,
                dataInicio: dataInicio,
                dataPrevisaoEntrega: dataPrevisaoEntrega,
                dataTermino: dataTermino,
                custoTotalPrevisto: custoTotalPrevisto,
                custoTotalRealizado: custoTotalRealizado,
                porcentoVenda: porcentoVenda,
                porcentoEstoque: porcentoEstoque,
              ),
          createCompanionCallback:
              ({
                Value<int?> id = const Value.absent(),
                Value<DateTime?> dataInicio = const Value.absent(),
                Value<DateTime?> dataPrevisaoEntrega = const Value.absent(),
                Value<DateTime?> dataTermino = const Value.absent(),
                Value<double?> custoTotalPrevisto = const Value.absent(),
                Value<double?> custoTotalRealizado = const Value.absent(),
                Value<double?> porcentoVenda = const Value.absent(),
                Value<double?> porcentoEstoque = const Value.absent(),
              }) => PcpOpCabecalhosCompanion.insert(
                id: id,
                dataInicio: dataInicio,
                dataPrevisaoEntrega: dataPrevisaoEntrega,
                dataTermino: dataTermino,
                custoTotalPrevisto: custoTotalPrevisto,
                custoTotalRealizado: custoTotalRealizado,
                porcentoVenda: porcentoVenda,
                porcentoEstoque: porcentoEstoque,
              ),
          withReferenceMapper:
              (p0) =>
                  p0
                      .map(
                        (e) => (
                          e.readTable(table),
                          BaseReferences(db, table, e),
                        ),
                      )
                      .toList(),
          prefetchHooksCallback: null,
        ),
      );
}

typedef $$PcpOpCabecalhosTableProcessedTableManager =
    ProcessedTableManager<
      _$AppDatabase,
      $PcpOpCabecalhosTable,
      PcpOpCabecalho,
      $$PcpOpCabecalhosTableFilterComposer,
      $$PcpOpCabecalhosTableOrderingComposer,
      $$PcpOpCabecalhosTableAnnotationComposer,
      $$PcpOpCabecalhosTableCreateCompanionBuilder,
      $$PcpOpCabecalhosTableUpdateCompanionBuilder,
      (
        PcpOpCabecalho,
        BaseReferences<_$AppDatabase, $PcpOpCabecalhosTable, PcpOpCabecalho>,
      ),
      PcpOpCabecalho,
      PrefetchHooks Function()
    >;
typedef $$PcpServicosTableCreateCompanionBuilder =
    PcpServicosCompanion Function({
      Value<int?> id,
      Value<int?> idPcpOpDetalhe,
      Value<DateTime?> inicioPrevisto,
      Value<DateTime?> terminoPrevisto,
      Value<int?> horasPrevisto,
      Value<int?> minutosPrevisto,
      Value<int?> segundosPrevisto,
      Value<double?> custoPrevisto,
      Value<DateTime?> inicioRealizado,
      Value<DateTime?> terminoRealizado,
      Value<int?> horasRealizado,
      Value<int?> minutosRealizado,
      Value<int?> segundosRealizado,
      Value<double?> custoRealizado,
    });
typedef $$PcpServicosTableUpdateCompanionBuilder =
    PcpServicosCompanion Function({
      Value<int?> id,
      Value<int?> idPcpOpDetalhe,
      Value<DateTime?> inicioPrevisto,
      Value<DateTime?> terminoPrevisto,
      Value<int?> horasPrevisto,
      Value<int?> minutosPrevisto,
      Value<int?> segundosPrevisto,
      Value<double?> custoPrevisto,
      Value<DateTime?> inicioRealizado,
      Value<DateTime?> terminoRealizado,
      Value<int?> horasRealizado,
      Value<int?> minutosRealizado,
      Value<int?> segundosRealizado,
      Value<double?> custoRealizado,
    });

class $$PcpServicosTableFilterComposer
    extends Composer<_$AppDatabase, $PcpServicosTable> {
  $$PcpServicosTableFilterComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnFilters<int> get id => $composableBuilder(
    column: $table.id,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<int> get idPcpOpDetalhe => $composableBuilder(
    column: $table.idPcpOpDetalhe,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<DateTime> get inicioPrevisto => $composableBuilder(
    column: $table.inicioPrevisto,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<DateTime> get terminoPrevisto => $composableBuilder(
    column: $table.terminoPrevisto,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<int> get horasPrevisto => $composableBuilder(
    column: $table.horasPrevisto,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<int> get minutosPrevisto => $composableBuilder(
    column: $table.minutosPrevisto,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<int> get segundosPrevisto => $composableBuilder(
    column: $table.segundosPrevisto,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<double> get custoPrevisto => $composableBuilder(
    column: $table.custoPrevisto,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<DateTime> get inicioRealizado => $composableBuilder(
    column: $table.inicioRealizado,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<DateTime> get terminoRealizado => $composableBuilder(
    column: $table.terminoRealizado,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<int> get horasRealizado => $composableBuilder(
    column: $table.horasRealizado,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<int> get minutosRealizado => $composableBuilder(
    column: $table.minutosRealizado,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<int> get segundosRealizado => $composableBuilder(
    column: $table.segundosRealizado,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<double> get custoRealizado => $composableBuilder(
    column: $table.custoRealizado,
    builder: (column) => ColumnFilters(column),
  );
}

class $$PcpServicosTableOrderingComposer
    extends Composer<_$AppDatabase, $PcpServicosTable> {
  $$PcpServicosTableOrderingComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnOrderings<int> get id => $composableBuilder(
    column: $table.id,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<int> get idPcpOpDetalhe => $composableBuilder(
    column: $table.idPcpOpDetalhe,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<DateTime> get inicioPrevisto => $composableBuilder(
    column: $table.inicioPrevisto,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<DateTime> get terminoPrevisto => $composableBuilder(
    column: $table.terminoPrevisto,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<int> get horasPrevisto => $composableBuilder(
    column: $table.horasPrevisto,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<int> get minutosPrevisto => $composableBuilder(
    column: $table.minutosPrevisto,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<int> get segundosPrevisto => $composableBuilder(
    column: $table.segundosPrevisto,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<double> get custoPrevisto => $composableBuilder(
    column: $table.custoPrevisto,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<DateTime> get inicioRealizado => $composableBuilder(
    column: $table.inicioRealizado,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<DateTime> get terminoRealizado => $composableBuilder(
    column: $table.terminoRealizado,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<int> get horasRealizado => $composableBuilder(
    column: $table.horasRealizado,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<int> get minutosRealizado => $composableBuilder(
    column: $table.minutosRealizado,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<int> get segundosRealizado => $composableBuilder(
    column: $table.segundosRealizado,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<double> get custoRealizado => $composableBuilder(
    column: $table.custoRealizado,
    builder: (column) => ColumnOrderings(column),
  );
}

class $$PcpServicosTableAnnotationComposer
    extends Composer<_$AppDatabase, $PcpServicosTable> {
  $$PcpServicosTableAnnotationComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  GeneratedColumn<int> get id =>
      $composableBuilder(column: $table.id, builder: (column) => column);

  GeneratedColumn<int> get idPcpOpDetalhe => $composableBuilder(
    column: $table.idPcpOpDetalhe,
    builder: (column) => column,
  );

  GeneratedColumn<DateTime> get inicioPrevisto => $composableBuilder(
    column: $table.inicioPrevisto,
    builder: (column) => column,
  );

  GeneratedColumn<DateTime> get terminoPrevisto => $composableBuilder(
    column: $table.terminoPrevisto,
    builder: (column) => column,
  );

  GeneratedColumn<int> get horasPrevisto => $composableBuilder(
    column: $table.horasPrevisto,
    builder: (column) => column,
  );

  GeneratedColumn<int> get minutosPrevisto => $composableBuilder(
    column: $table.minutosPrevisto,
    builder: (column) => column,
  );

  GeneratedColumn<int> get segundosPrevisto => $composableBuilder(
    column: $table.segundosPrevisto,
    builder: (column) => column,
  );

  GeneratedColumn<double> get custoPrevisto => $composableBuilder(
    column: $table.custoPrevisto,
    builder: (column) => column,
  );

  GeneratedColumn<DateTime> get inicioRealizado => $composableBuilder(
    column: $table.inicioRealizado,
    builder: (column) => column,
  );

  GeneratedColumn<DateTime> get terminoRealizado => $composableBuilder(
    column: $table.terminoRealizado,
    builder: (column) => column,
  );

  GeneratedColumn<int> get horasRealizado => $composableBuilder(
    column: $table.horasRealizado,
    builder: (column) => column,
  );

  GeneratedColumn<int> get minutosRealizado => $composableBuilder(
    column: $table.minutosRealizado,
    builder: (column) => column,
  );

  GeneratedColumn<int> get segundosRealizado => $composableBuilder(
    column: $table.segundosRealizado,
    builder: (column) => column,
  );

  GeneratedColumn<double> get custoRealizado => $composableBuilder(
    column: $table.custoRealizado,
    builder: (column) => column,
  );
}

class $$PcpServicosTableTableManager
    extends
        RootTableManager<
          _$AppDatabase,
          $PcpServicosTable,
          PcpServico,
          $$PcpServicosTableFilterComposer,
          $$PcpServicosTableOrderingComposer,
          $$PcpServicosTableAnnotationComposer,
          $$PcpServicosTableCreateCompanionBuilder,
          $$PcpServicosTableUpdateCompanionBuilder,
          (
            PcpServico,
            BaseReferences<_$AppDatabase, $PcpServicosTable, PcpServico>,
          ),
          PcpServico,
          PrefetchHooks Function()
        > {
  $$PcpServicosTableTableManager(_$AppDatabase db, $PcpServicosTable table)
    : super(
        TableManagerState(
          db: db,
          table: table,
          createFilteringComposer:
              () => $$PcpServicosTableFilterComposer($db: db, $table: table),
          createOrderingComposer:
              () => $$PcpServicosTableOrderingComposer($db: db, $table: table),
          createComputedFieldComposer:
              () =>
                  $$PcpServicosTableAnnotationComposer($db: db, $table: table),
          updateCompanionCallback:
              ({
                Value<int?> id = const Value.absent(),
                Value<int?> idPcpOpDetalhe = const Value.absent(),
                Value<DateTime?> inicioPrevisto = const Value.absent(),
                Value<DateTime?> terminoPrevisto = const Value.absent(),
                Value<int?> horasPrevisto = const Value.absent(),
                Value<int?> minutosPrevisto = const Value.absent(),
                Value<int?> segundosPrevisto = const Value.absent(),
                Value<double?> custoPrevisto = const Value.absent(),
                Value<DateTime?> inicioRealizado = const Value.absent(),
                Value<DateTime?> terminoRealizado = const Value.absent(),
                Value<int?> horasRealizado = const Value.absent(),
                Value<int?> minutosRealizado = const Value.absent(),
                Value<int?> segundosRealizado = const Value.absent(),
                Value<double?> custoRealizado = const Value.absent(),
              }) => PcpServicosCompanion(
                id: id,
                idPcpOpDetalhe: idPcpOpDetalhe,
                inicioPrevisto: inicioPrevisto,
                terminoPrevisto: terminoPrevisto,
                horasPrevisto: horasPrevisto,
                minutosPrevisto: minutosPrevisto,
                segundosPrevisto: segundosPrevisto,
                custoPrevisto: custoPrevisto,
                inicioRealizado: inicioRealizado,
                terminoRealizado: terminoRealizado,
                horasRealizado: horasRealizado,
                minutosRealizado: minutosRealizado,
                segundosRealizado: segundosRealizado,
                custoRealizado: custoRealizado,
              ),
          createCompanionCallback:
              ({
                Value<int?> id = const Value.absent(),
                Value<int?> idPcpOpDetalhe = const Value.absent(),
                Value<DateTime?> inicioPrevisto = const Value.absent(),
                Value<DateTime?> terminoPrevisto = const Value.absent(),
                Value<int?> horasPrevisto = const Value.absent(),
                Value<int?> minutosPrevisto = const Value.absent(),
                Value<int?> segundosPrevisto = const Value.absent(),
                Value<double?> custoPrevisto = const Value.absent(),
                Value<DateTime?> inicioRealizado = const Value.absent(),
                Value<DateTime?> terminoRealizado = const Value.absent(),
                Value<int?> horasRealizado = const Value.absent(),
                Value<int?> minutosRealizado = const Value.absent(),
                Value<int?> segundosRealizado = const Value.absent(),
                Value<double?> custoRealizado = const Value.absent(),
              }) => PcpServicosCompanion.insert(
                id: id,
                idPcpOpDetalhe: idPcpOpDetalhe,
                inicioPrevisto: inicioPrevisto,
                terminoPrevisto: terminoPrevisto,
                horasPrevisto: horasPrevisto,
                minutosPrevisto: minutosPrevisto,
                segundosPrevisto: segundosPrevisto,
                custoPrevisto: custoPrevisto,
                inicioRealizado: inicioRealizado,
                terminoRealizado: terminoRealizado,
                horasRealizado: horasRealizado,
                minutosRealizado: minutosRealizado,
                segundosRealizado: segundosRealizado,
                custoRealizado: custoRealizado,
              ),
          withReferenceMapper:
              (p0) =>
                  p0
                      .map(
                        (e) => (
                          e.readTable(table),
                          BaseReferences(db, table, e),
                        ),
                      )
                      .toList(),
          prefetchHooksCallback: null,
        ),
      );
}

typedef $$PcpServicosTableProcessedTableManager =
    ProcessedTableManager<
      _$AppDatabase,
      $PcpServicosTable,
      PcpServico,
      $$PcpServicosTableFilterComposer,
      $$PcpServicosTableOrderingComposer,
      $$PcpServicosTableAnnotationComposer,
      $$PcpServicosTableCreateCompanionBuilder,
      $$PcpServicosTableUpdateCompanionBuilder,
      (
        PcpServico,
        BaseReferences<_$AppDatabase, $PcpServicosTable, PcpServico>,
      ),
      PcpServico,
      PrefetchHooks Function()
    >;
typedef $$ProdutosTableCreateCompanionBuilder =
    ProdutosCompanion Function({
      Value<int?> id,
      Value<int?> idTributIcmsCustomCab,
      Value<int?> idTributGrupoTributario,
      Value<String?> nome,
      Value<String?> descricao,
      Value<String?> gtin,
      Value<String?> codigoInterno,
      Value<double?> valorCompra,
      Value<double?> valorVenda,
      Value<String?> codigoNcm,
      Value<double?> estoqueMinimo,
      Value<double?> estoqueMaximo,
      Value<double?> quantidadeEstoque,
      Value<DateTime?> dataCadastro,
    });
typedef $$ProdutosTableUpdateCompanionBuilder =
    ProdutosCompanion Function({
      Value<int?> id,
      Value<int?> idTributIcmsCustomCab,
      Value<int?> idTributGrupoTributario,
      Value<String?> nome,
      Value<String?> descricao,
      Value<String?> gtin,
      Value<String?> codigoInterno,
      Value<double?> valorCompra,
      Value<double?> valorVenda,
      Value<String?> codigoNcm,
      Value<double?> estoqueMinimo,
      Value<double?> estoqueMaximo,
      Value<double?> quantidadeEstoque,
      Value<DateTime?> dataCadastro,
    });

class $$ProdutosTableFilterComposer
    extends Composer<_$AppDatabase, $ProdutosTable> {
  $$ProdutosTableFilterComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnFilters<int> get id => $composableBuilder(
    column: $table.id,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<int> get idTributIcmsCustomCab => $composableBuilder(
    column: $table.idTributIcmsCustomCab,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<int> get idTributGrupoTributario => $composableBuilder(
    column: $table.idTributGrupoTributario,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get nome => $composableBuilder(
    column: $table.nome,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get descricao => $composableBuilder(
    column: $table.descricao,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get gtin => $composableBuilder(
    column: $table.gtin,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get codigoInterno => $composableBuilder(
    column: $table.codigoInterno,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<double> get valorCompra => $composableBuilder(
    column: $table.valorCompra,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<double> get valorVenda => $composableBuilder(
    column: $table.valorVenda,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get codigoNcm => $composableBuilder(
    column: $table.codigoNcm,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<double> get estoqueMinimo => $composableBuilder(
    column: $table.estoqueMinimo,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<double> get estoqueMaximo => $composableBuilder(
    column: $table.estoqueMaximo,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<double> get quantidadeEstoque => $composableBuilder(
    column: $table.quantidadeEstoque,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<DateTime> get dataCadastro => $composableBuilder(
    column: $table.dataCadastro,
    builder: (column) => ColumnFilters(column),
  );
}

class $$ProdutosTableOrderingComposer
    extends Composer<_$AppDatabase, $ProdutosTable> {
  $$ProdutosTableOrderingComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnOrderings<int> get id => $composableBuilder(
    column: $table.id,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<int> get idTributIcmsCustomCab => $composableBuilder(
    column: $table.idTributIcmsCustomCab,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<int> get idTributGrupoTributario => $composableBuilder(
    column: $table.idTributGrupoTributario,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get nome => $composableBuilder(
    column: $table.nome,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get descricao => $composableBuilder(
    column: $table.descricao,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get gtin => $composableBuilder(
    column: $table.gtin,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get codigoInterno => $composableBuilder(
    column: $table.codigoInterno,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<double> get valorCompra => $composableBuilder(
    column: $table.valorCompra,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<double> get valorVenda => $composableBuilder(
    column: $table.valorVenda,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get codigoNcm => $composableBuilder(
    column: $table.codigoNcm,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<double> get estoqueMinimo => $composableBuilder(
    column: $table.estoqueMinimo,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<double> get estoqueMaximo => $composableBuilder(
    column: $table.estoqueMaximo,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<double> get quantidadeEstoque => $composableBuilder(
    column: $table.quantidadeEstoque,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<DateTime> get dataCadastro => $composableBuilder(
    column: $table.dataCadastro,
    builder: (column) => ColumnOrderings(column),
  );
}

class $$ProdutosTableAnnotationComposer
    extends Composer<_$AppDatabase, $ProdutosTable> {
  $$ProdutosTableAnnotationComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  GeneratedColumn<int> get id =>
      $composableBuilder(column: $table.id, builder: (column) => column);

  GeneratedColumn<int> get idTributIcmsCustomCab => $composableBuilder(
    column: $table.idTributIcmsCustomCab,
    builder: (column) => column,
  );

  GeneratedColumn<int> get idTributGrupoTributario => $composableBuilder(
    column: $table.idTributGrupoTributario,
    builder: (column) => column,
  );

  GeneratedColumn<String> get nome =>
      $composableBuilder(column: $table.nome, builder: (column) => column);

  GeneratedColumn<String> get descricao =>
      $composableBuilder(column: $table.descricao, builder: (column) => column);

  GeneratedColumn<String> get gtin =>
      $composableBuilder(column: $table.gtin, builder: (column) => column);

  GeneratedColumn<String> get codigoInterno => $composableBuilder(
    column: $table.codigoInterno,
    builder: (column) => column,
  );

  GeneratedColumn<double> get valorCompra => $composableBuilder(
    column: $table.valorCompra,
    builder: (column) => column,
  );

  GeneratedColumn<double> get valorVenda => $composableBuilder(
    column: $table.valorVenda,
    builder: (column) => column,
  );

  GeneratedColumn<String> get codigoNcm =>
      $composableBuilder(column: $table.codigoNcm, builder: (column) => column);

  GeneratedColumn<double> get estoqueMinimo => $composableBuilder(
    column: $table.estoqueMinimo,
    builder: (column) => column,
  );

  GeneratedColumn<double> get estoqueMaximo => $composableBuilder(
    column: $table.estoqueMaximo,
    builder: (column) => column,
  );

  GeneratedColumn<double> get quantidadeEstoque => $composableBuilder(
    column: $table.quantidadeEstoque,
    builder: (column) => column,
  );

  GeneratedColumn<DateTime> get dataCadastro => $composableBuilder(
    column: $table.dataCadastro,
    builder: (column) => column,
  );
}

class $$ProdutosTableTableManager
    extends
        RootTableManager<
          _$AppDatabase,
          $ProdutosTable,
          Produto,
          $$ProdutosTableFilterComposer,
          $$ProdutosTableOrderingComposer,
          $$ProdutosTableAnnotationComposer,
          $$ProdutosTableCreateCompanionBuilder,
          $$ProdutosTableUpdateCompanionBuilder,
          (Produto, BaseReferences<_$AppDatabase, $ProdutosTable, Produto>),
          Produto,
          PrefetchHooks Function()
        > {
  $$ProdutosTableTableManager(_$AppDatabase db, $ProdutosTable table)
    : super(
        TableManagerState(
          db: db,
          table: table,
          createFilteringComposer:
              () => $$ProdutosTableFilterComposer($db: db, $table: table),
          createOrderingComposer:
              () => $$ProdutosTableOrderingComposer($db: db, $table: table),
          createComputedFieldComposer:
              () => $$ProdutosTableAnnotationComposer($db: db, $table: table),
          updateCompanionCallback:
              ({
                Value<int?> id = const Value.absent(),
                Value<int?> idTributIcmsCustomCab = const Value.absent(),
                Value<int?> idTributGrupoTributario = const Value.absent(),
                Value<String?> nome = const Value.absent(),
                Value<String?> descricao = const Value.absent(),
                Value<String?> gtin = const Value.absent(),
                Value<String?> codigoInterno = const Value.absent(),
                Value<double?> valorCompra = const Value.absent(),
                Value<double?> valorVenda = const Value.absent(),
                Value<String?> codigoNcm = const Value.absent(),
                Value<double?> estoqueMinimo = const Value.absent(),
                Value<double?> estoqueMaximo = const Value.absent(),
                Value<double?> quantidadeEstoque = const Value.absent(),
                Value<DateTime?> dataCadastro = const Value.absent(),
              }) => ProdutosCompanion(
                id: id,
                idTributIcmsCustomCab: idTributIcmsCustomCab,
                idTributGrupoTributario: idTributGrupoTributario,
                nome: nome,
                descricao: descricao,
                gtin: gtin,
                codigoInterno: codigoInterno,
                valorCompra: valorCompra,
                valorVenda: valorVenda,
                codigoNcm: codigoNcm,
                estoqueMinimo: estoqueMinimo,
                estoqueMaximo: estoqueMaximo,
                quantidadeEstoque: quantidadeEstoque,
                dataCadastro: dataCadastro,
              ),
          createCompanionCallback:
              ({
                Value<int?> id = const Value.absent(),
                Value<int?> idTributIcmsCustomCab = const Value.absent(),
                Value<int?> idTributGrupoTributario = const Value.absent(),
                Value<String?> nome = const Value.absent(),
                Value<String?> descricao = const Value.absent(),
                Value<String?> gtin = const Value.absent(),
                Value<String?> codigoInterno = const Value.absent(),
                Value<double?> valorCompra = const Value.absent(),
                Value<double?> valorVenda = const Value.absent(),
                Value<String?> codigoNcm = const Value.absent(),
                Value<double?> estoqueMinimo = const Value.absent(),
                Value<double?> estoqueMaximo = const Value.absent(),
                Value<double?> quantidadeEstoque = const Value.absent(),
                Value<DateTime?> dataCadastro = const Value.absent(),
              }) => ProdutosCompanion.insert(
                id: id,
                idTributIcmsCustomCab: idTributIcmsCustomCab,
                idTributGrupoTributario: idTributGrupoTributario,
                nome: nome,
                descricao: descricao,
                gtin: gtin,
                codigoInterno: codigoInterno,
                valorCompra: valorCompra,
                valorVenda: valorVenda,
                codigoNcm: codigoNcm,
                estoqueMinimo: estoqueMinimo,
                estoqueMaximo: estoqueMaximo,
                quantidadeEstoque: quantidadeEstoque,
                dataCadastro: dataCadastro,
              ),
          withReferenceMapper:
              (p0) =>
                  p0
                      .map(
                        (e) => (
                          e.readTable(table),
                          BaseReferences(db, table, e),
                        ),
                      )
                      .toList(),
          prefetchHooksCallback: null,
        ),
      );
}

typedef $$ProdutosTableProcessedTableManager =
    ProcessedTableManager<
      _$AppDatabase,
      $ProdutosTable,
      Produto,
      $$ProdutosTableFilterComposer,
      $$ProdutosTableOrderingComposer,
      $$ProdutosTableAnnotationComposer,
      $$ProdutosTableCreateCompanionBuilder,
      $$ProdutosTableUpdateCompanionBuilder,
      (Produto, BaseReferences<_$AppDatabase, $ProdutosTable, Produto>),
      Produto,
      PrefetchHooks Function()
    >;
typedef $$PatrimBemsTableCreateCompanionBuilder =
    PatrimBemsCompanion Function({
      Value<int?> id,
      Value<int?> idCentroResultado,
      Value<int?> idPatrimTipoAquisicaoBem,
      Value<int?> idPatrimEstadoConservacao,
      Value<int?> idPatrimGrupoBem,
      Value<int?> idFornecedor,
      Value<int?> idSetor,
      Value<String?> numeroNb,
      Value<String?> nome,
      Value<String?> descricao,
      Value<String?> numeroSerie,
      Value<DateTime?> dataAquisicao,
      Value<DateTime?> dataAceite,
      Value<DateTime?> dataCadastro,
      Value<DateTime?> dataContabilizado,
      Value<DateTime?> dataVistoria,
      Value<DateTime?> dataMarcacao,
      Value<DateTime?> dataBaixa,
      Value<DateTime?> vencimentoGarantia,
      Value<String?> numeroNotaFiscal,
      Value<String?> chaveNfe,
      Value<double?> valorOriginal,
      Value<double?> valorCompra,
      Value<double?> valorAtualizado,
      Value<double?> valorBaixa,
      Value<String?> deprecia,
      Value<String?> metodoDepreciacao,
      Value<DateTime?> inicioDepreciacao,
      Value<DateTime?> ultimaDepreciacao,
      Value<String?> tipoDepreciacao,
      Value<double?> taxaAnualDepreciacao,
      Value<double?> taxaMensalDepreciacao,
      Value<double?> taxaDepreciacaoAcelerada,
      Value<double?> taxaDepreciacaoIncentivada,
      Value<String?> funcao,
    });
typedef $$PatrimBemsTableUpdateCompanionBuilder =
    PatrimBemsCompanion Function({
      Value<int?> id,
      Value<int?> idCentroResultado,
      Value<int?> idPatrimTipoAquisicaoBem,
      Value<int?> idPatrimEstadoConservacao,
      Value<int?> idPatrimGrupoBem,
      Value<int?> idFornecedor,
      Value<int?> idSetor,
      Value<String?> numeroNb,
      Value<String?> nome,
      Value<String?> descricao,
      Value<String?> numeroSerie,
      Value<DateTime?> dataAquisicao,
      Value<DateTime?> dataAceite,
      Value<DateTime?> dataCadastro,
      Value<DateTime?> dataContabilizado,
      Value<DateTime?> dataVistoria,
      Value<DateTime?> dataMarcacao,
      Value<DateTime?> dataBaixa,
      Value<DateTime?> vencimentoGarantia,
      Value<String?> numeroNotaFiscal,
      Value<String?> chaveNfe,
      Value<double?> valorOriginal,
      Value<double?> valorCompra,
      Value<double?> valorAtualizado,
      Value<double?> valorBaixa,
      Value<String?> deprecia,
      Value<String?> metodoDepreciacao,
      Value<DateTime?> inicioDepreciacao,
      Value<DateTime?> ultimaDepreciacao,
      Value<String?> tipoDepreciacao,
      Value<double?> taxaAnualDepreciacao,
      Value<double?> taxaMensalDepreciacao,
      Value<double?> taxaDepreciacaoAcelerada,
      Value<double?> taxaDepreciacaoIncentivada,
      Value<String?> funcao,
    });

class $$PatrimBemsTableFilterComposer
    extends Composer<_$AppDatabase, $PatrimBemsTable> {
  $$PatrimBemsTableFilterComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnFilters<int> get id => $composableBuilder(
    column: $table.id,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<int> get idCentroResultado => $composableBuilder(
    column: $table.idCentroResultado,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<int> get idPatrimTipoAquisicaoBem => $composableBuilder(
    column: $table.idPatrimTipoAquisicaoBem,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<int> get idPatrimEstadoConservacao => $composableBuilder(
    column: $table.idPatrimEstadoConservacao,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<int> get idPatrimGrupoBem => $composableBuilder(
    column: $table.idPatrimGrupoBem,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<int> get idFornecedor => $composableBuilder(
    column: $table.idFornecedor,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<int> get idSetor => $composableBuilder(
    column: $table.idSetor,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get numeroNb => $composableBuilder(
    column: $table.numeroNb,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get nome => $composableBuilder(
    column: $table.nome,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get descricao => $composableBuilder(
    column: $table.descricao,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get numeroSerie => $composableBuilder(
    column: $table.numeroSerie,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<DateTime> get dataAquisicao => $composableBuilder(
    column: $table.dataAquisicao,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<DateTime> get dataAceite => $composableBuilder(
    column: $table.dataAceite,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<DateTime> get dataCadastro => $composableBuilder(
    column: $table.dataCadastro,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<DateTime> get dataContabilizado => $composableBuilder(
    column: $table.dataContabilizado,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<DateTime> get dataVistoria => $composableBuilder(
    column: $table.dataVistoria,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<DateTime> get dataMarcacao => $composableBuilder(
    column: $table.dataMarcacao,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<DateTime> get dataBaixa => $composableBuilder(
    column: $table.dataBaixa,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<DateTime> get vencimentoGarantia => $composableBuilder(
    column: $table.vencimentoGarantia,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get numeroNotaFiscal => $composableBuilder(
    column: $table.numeroNotaFiscal,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get chaveNfe => $composableBuilder(
    column: $table.chaveNfe,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<double> get valorOriginal => $composableBuilder(
    column: $table.valorOriginal,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<double> get valorCompra => $composableBuilder(
    column: $table.valorCompra,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<double> get valorAtualizado => $composableBuilder(
    column: $table.valorAtualizado,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<double> get valorBaixa => $composableBuilder(
    column: $table.valorBaixa,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get deprecia => $composableBuilder(
    column: $table.deprecia,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get metodoDepreciacao => $composableBuilder(
    column: $table.metodoDepreciacao,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<DateTime> get inicioDepreciacao => $composableBuilder(
    column: $table.inicioDepreciacao,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<DateTime> get ultimaDepreciacao => $composableBuilder(
    column: $table.ultimaDepreciacao,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get tipoDepreciacao => $composableBuilder(
    column: $table.tipoDepreciacao,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<double> get taxaAnualDepreciacao => $composableBuilder(
    column: $table.taxaAnualDepreciacao,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<double> get taxaMensalDepreciacao => $composableBuilder(
    column: $table.taxaMensalDepreciacao,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<double> get taxaDepreciacaoAcelerada => $composableBuilder(
    column: $table.taxaDepreciacaoAcelerada,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<double> get taxaDepreciacaoIncentivada => $composableBuilder(
    column: $table.taxaDepreciacaoIncentivada,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get funcao => $composableBuilder(
    column: $table.funcao,
    builder: (column) => ColumnFilters(column),
  );
}

class $$PatrimBemsTableOrderingComposer
    extends Composer<_$AppDatabase, $PatrimBemsTable> {
  $$PatrimBemsTableOrderingComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnOrderings<int> get id => $composableBuilder(
    column: $table.id,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<int> get idCentroResultado => $composableBuilder(
    column: $table.idCentroResultado,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<int> get idPatrimTipoAquisicaoBem => $composableBuilder(
    column: $table.idPatrimTipoAquisicaoBem,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<int> get idPatrimEstadoConservacao => $composableBuilder(
    column: $table.idPatrimEstadoConservacao,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<int> get idPatrimGrupoBem => $composableBuilder(
    column: $table.idPatrimGrupoBem,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<int> get idFornecedor => $composableBuilder(
    column: $table.idFornecedor,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<int> get idSetor => $composableBuilder(
    column: $table.idSetor,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get numeroNb => $composableBuilder(
    column: $table.numeroNb,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get nome => $composableBuilder(
    column: $table.nome,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get descricao => $composableBuilder(
    column: $table.descricao,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get numeroSerie => $composableBuilder(
    column: $table.numeroSerie,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<DateTime> get dataAquisicao => $composableBuilder(
    column: $table.dataAquisicao,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<DateTime> get dataAceite => $composableBuilder(
    column: $table.dataAceite,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<DateTime> get dataCadastro => $composableBuilder(
    column: $table.dataCadastro,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<DateTime> get dataContabilizado => $composableBuilder(
    column: $table.dataContabilizado,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<DateTime> get dataVistoria => $composableBuilder(
    column: $table.dataVistoria,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<DateTime> get dataMarcacao => $composableBuilder(
    column: $table.dataMarcacao,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<DateTime> get dataBaixa => $composableBuilder(
    column: $table.dataBaixa,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<DateTime> get vencimentoGarantia => $composableBuilder(
    column: $table.vencimentoGarantia,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get numeroNotaFiscal => $composableBuilder(
    column: $table.numeroNotaFiscal,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get chaveNfe => $composableBuilder(
    column: $table.chaveNfe,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<double> get valorOriginal => $composableBuilder(
    column: $table.valorOriginal,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<double> get valorCompra => $composableBuilder(
    column: $table.valorCompra,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<double> get valorAtualizado => $composableBuilder(
    column: $table.valorAtualizado,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<double> get valorBaixa => $composableBuilder(
    column: $table.valorBaixa,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get deprecia => $composableBuilder(
    column: $table.deprecia,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get metodoDepreciacao => $composableBuilder(
    column: $table.metodoDepreciacao,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<DateTime> get inicioDepreciacao => $composableBuilder(
    column: $table.inicioDepreciacao,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<DateTime> get ultimaDepreciacao => $composableBuilder(
    column: $table.ultimaDepreciacao,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get tipoDepreciacao => $composableBuilder(
    column: $table.tipoDepreciacao,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<double> get taxaAnualDepreciacao => $composableBuilder(
    column: $table.taxaAnualDepreciacao,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<double> get taxaMensalDepreciacao => $composableBuilder(
    column: $table.taxaMensalDepreciacao,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<double> get taxaDepreciacaoAcelerada => $composableBuilder(
    column: $table.taxaDepreciacaoAcelerada,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<double> get taxaDepreciacaoIncentivada => $composableBuilder(
    column: $table.taxaDepreciacaoIncentivada,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get funcao => $composableBuilder(
    column: $table.funcao,
    builder: (column) => ColumnOrderings(column),
  );
}

class $$PatrimBemsTableAnnotationComposer
    extends Composer<_$AppDatabase, $PatrimBemsTable> {
  $$PatrimBemsTableAnnotationComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  GeneratedColumn<int> get id =>
      $composableBuilder(column: $table.id, builder: (column) => column);

  GeneratedColumn<int> get idCentroResultado => $composableBuilder(
    column: $table.idCentroResultado,
    builder: (column) => column,
  );

  GeneratedColumn<int> get idPatrimTipoAquisicaoBem => $composableBuilder(
    column: $table.idPatrimTipoAquisicaoBem,
    builder: (column) => column,
  );

  GeneratedColumn<int> get idPatrimEstadoConservacao => $composableBuilder(
    column: $table.idPatrimEstadoConservacao,
    builder: (column) => column,
  );

  GeneratedColumn<int> get idPatrimGrupoBem => $composableBuilder(
    column: $table.idPatrimGrupoBem,
    builder: (column) => column,
  );

  GeneratedColumn<int> get idFornecedor => $composableBuilder(
    column: $table.idFornecedor,
    builder: (column) => column,
  );

  GeneratedColumn<int> get idSetor =>
      $composableBuilder(column: $table.idSetor, builder: (column) => column);

  GeneratedColumn<String> get numeroNb =>
      $composableBuilder(column: $table.numeroNb, builder: (column) => column);

  GeneratedColumn<String> get nome =>
      $composableBuilder(column: $table.nome, builder: (column) => column);

  GeneratedColumn<String> get descricao =>
      $composableBuilder(column: $table.descricao, builder: (column) => column);

  GeneratedColumn<String> get numeroSerie => $composableBuilder(
    column: $table.numeroSerie,
    builder: (column) => column,
  );

  GeneratedColumn<DateTime> get dataAquisicao => $composableBuilder(
    column: $table.dataAquisicao,
    builder: (column) => column,
  );

  GeneratedColumn<DateTime> get dataAceite => $composableBuilder(
    column: $table.dataAceite,
    builder: (column) => column,
  );

  GeneratedColumn<DateTime> get dataCadastro => $composableBuilder(
    column: $table.dataCadastro,
    builder: (column) => column,
  );

  GeneratedColumn<DateTime> get dataContabilizado => $composableBuilder(
    column: $table.dataContabilizado,
    builder: (column) => column,
  );

  GeneratedColumn<DateTime> get dataVistoria => $composableBuilder(
    column: $table.dataVistoria,
    builder: (column) => column,
  );

  GeneratedColumn<DateTime> get dataMarcacao => $composableBuilder(
    column: $table.dataMarcacao,
    builder: (column) => column,
  );

  GeneratedColumn<DateTime> get dataBaixa =>
      $composableBuilder(column: $table.dataBaixa, builder: (column) => column);

  GeneratedColumn<DateTime> get vencimentoGarantia => $composableBuilder(
    column: $table.vencimentoGarantia,
    builder: (column) => column,
  );

  GeneratedColumn<String> get numeroNotaFiscal => $composableBuilder(
    column: $table.numeroNotaFiscal,
    builder: (column) => column,
  );

  GeneratedColumn<String> get chaveNfe =>
      $composableBuilder(column: $table.chaveNfe, builder: (column) => column);

  GeneratedColumn<double> get valorOriginal => $composableBuilder(
    column: $table.valorOriginal,
    builder: (column) => column,
  );

  GeneratedColumn<double> get valorCompra => $composableBuilder(
    column: $table.valorCompra,
    builder: (column) => column,
  );

  GeneratedColumn<double> get valorAtualizado => $composableBuilder(
    column: $table.valorAtualizado,
    builder: (column) => column,
  );

  GeneratedColumn<double> get valorBaixa => $composableBuilder(
    column: $table.valorBaixa,
    builder: (column) => column,
  );

  GeneratedColumn<String> get deprecia =>
      $composableBuilder(column: $table.deprecia, builder: (column) => column);

  GeneratedColumn<String> get metodoDepreciacao => $composableBuilder(
    column: $table.metodoDepreciacao,
    builder: (column) => column,
  );

  GeneratedColumn<DateTime> get inicioDepreciacao => $composableBuilder(
    column: $table.inicioDepreciacao,
    builder: (column) => column,
  );

  GeneratedColumn<DateTime> get ultimaDepreciacao => $composableBuilder(
    column: $table.ultimaDepreciacao,
    builder: (column) => column,
  );

  GeneratedColumn<String> get tipoDepreciacao => $composableBuilder(
    column: $table.tipoDepreciacao,
    builder: (column) => column,
  );

  GeneratedColumn<double> get taxaAnualDepreciacao => $composableBuilder(
    column: $table.taxaAnualDepreciacao,
    builder: (column) => column,
  );

  GeneratedColumn<double> get taxaMensalDepreciacao => $composableBuilder(
    column: $table.taxaMensalDepreciacao,
    builder: (column) => column,
  );

  GeneratedColumn<double> get taxaDepreciacaoAcelerada => $composableBuilder(
    column: $table.taxaDepreciacaoAcelerada,
    builder: (column) => column,
  );

  GeneratedColumn<double> get taxaDepreciacaoIncentivada => $composableBuilder(
    column: $table.taxaDepreciacaoIncentivada,
    builder: (column) => column,
  );

  GeneratedColumn<String> get funcao =>
      $composableBuilder(column: $table.funcao, builder: (column) => column);
}

class $$PatrimBemsTableTableManager
    extends
        RootTableManager<
          _$AppDatabase,
          $PatrimBemsTable,
          PatrimBem,
          $$PatrimBemsTableFilterComposer,
          $$PatrimBemsTableOrderingComposer,
          $$PatrimBemsTableAnnotationComposer,
          $$PatrimBemsTableCreateCompanionBuilder,
          $$PatrimBemsTableUpdateCompanionBuilder,
          (
            PatrimBem,
            BaseReferences<_$AppDatabase, $PatrimBemsTable, PatrimBem>,
          ),
          PatrimBem,
          PrefetchHooks Function()
        > {
  $$PatrimBemsTableTableManager(_$AppDatabase db, $PatrimBemsTable table)
    : super(
        TableManagerState(
          db: db,
          table: table,
          createFilteringComposer:
              () => $$PatrimBemsTableFilterComposer($db: db, $table: table),
          createOrderingComposer:
              () => $$PatrimBemsTableOrderingComposer($db: db, $table: table),
          createComputedFieldComposer:
              () => $$PatrimBemsTableAnnotationComposer($db: db, $table: table),
          updateCompanionCallback:
              ({
                Value<int?> id = const Value.absent(),
                Value<int?> idCentroResultado = const Value.absent(),
                Value<int?> idPatrimTipoAquisicaoBem = const Value.absent(),
                Value<int?> idPatrimEstadoConservacao = const Value.absent(),
                Value<int?> idPatrimGrupoBem = const Value.absent(),
                Value<int?> idFornecedor = const Value.absent(),
                Value<int?> idSetor = const Value.absent(),
                Value<String?> numeroNb = const Value.absent(),
                Value<String?> nome = const Value.absent(),
                Value<String?> descricao = const Value.absent(),
                Value<String?> numeroSerie = const Value.absent(),
                Value<DateTime?> dataAquisicao = const Value.absent(),
                Value<DateTime?> dataAceite = const Value.absent(),
                Value<DateTime?> dataCadastro = const Value.absent(),
                Value<DateTime?> dataContabilizado = const Value.absent(),
                Value<DateTime?> dataVistoria = const Value.absent(),
                Value<DateTime?> dataMarcacao = const Value.absent(),
                Value<DateTime?> dataBaixa = const Value.absent(),
                Value<DateTime?> vencimentoGarantia = const Value.absent(),
                Value<String?> numeroNotaFiscal = const Value.absent(),
                Value<String?> chaveNfe = const Value.absent(),
                Value<double?> valorOriginal = const Value.absent(),
                Value<double?> valorCompra = const Value.absent(),
                Value<double?> valorAtualizado = const Value.absent(),
                Value<double?> valorBaixa = const Value.absent(),
                Value<String?> deprecia = const Value.absent(),
                Value<String?> metodoDepreciacao = const Value.absent(),
                Value<DateTime?> inicioDepreciacao = const Value.absent(),
                Value<DateTime?> ultimaDepreciacao = const Value.absent(),
                Value<String?> tipoDepreciacao = const Value.absent(),
                Value<double?> taxaAnualDepreciacao = const Value.absent(),
                Value<double?> taxaMensalDepreciacao = const Value.absent(),
                Value<double?> taxaDepreciacaoAcelerada = const Value.absent(),
                Value<double?> taxaDepreciacaoIncentivada =
                    const Value.absent(),
                Value<String?> funcao = const Value.absent(),
              }) => PatrimBemsCompanion(
                id: id,
                idCentroResultado: idCentroResultado,
                idPatrimTipoAquisicaoBem: idPatrimTipoAquisicaoBem,
                idPatrimEstadoConservacao: idPatrimEstadoConservacao,
                idPatrimGrupoBem: idPatrimGrupoBem,
                idFornecedor: idFornecedor,
                idSetor: idSetor,
                numeroNb: numeroNb,
                nome: nome,
                descricao: descricao,
                numeroSerie: numeroSerie,
                dataAquisicao: dataAquisicao,
                dataAceite: dataAceite,
                dataCadastro: dataCadastro,
                dataContabilizado: dataContabilizado,
                dataVistoria: dataVistoria,
                dataMarcacao: dataMarcacao,
                dataBaixa: dataBaixa,
                vencimentoGarantia: vencimentoGarantia,
                numeroNotaFiscal: numeroNotaFiscal,
                chaveNfe: chaveNfe,
                valorOriginal: valorOriginal,
                valorCompra: valorCompra,
                valorAtualizado: valorAtualizado,
                valorBaixa: valorBaixa,
                deprecia: deprecia,
                metodoDepreciacao: metodoDepreciacao,
                inicioDepreciacao: inicioDepreciacao,
                ultimaDepreciacao: ultimaDepreciacao,
                tipoDepreciacao: tipoDepreciacao,
                taxaAnualDepreciacao: taxaAnualDepreciacao,
                taxaMensalDepreciacao: taxaMensalDepreciacao,
                taxaDepreciacaoAcelerada: taxaDepreciacaoAcelerada,
                taxaDepreciacaoIncentivada: taxaDepreciacaoIncentivada,
                funcao: funcao,
              ),
          createCompanionCallback:
              ({
                Value<int?> id = const Value.absent(),
                Value<int?> idCentroResultado = const Value.absent(),
                Value<int?> idPatrimTipoAquisicaoBem = const Value.absent(),
                Value<int?> idPatrimEstadoConservacao = const Value.absent(),
                Value<int?> idPatrimGrupoBem = const Value.absent(),
                Value<int?> idFornecedor = const Value.absent(),
                Value<int?> idSetor = const Value.absent(),
                Value<String?> numeroNb = const Value.absent(),
                Value<String?> nome = const Value.absent(),
                Value<String?> descricao = const Value.absent(),
                Value<String?> numeroSerie = const Value.absent(),
                Value<DateTime?> dataAquisicao = const Value.absent(),
                Value<DateTime?> dataAceite = const Value.absent(),
                Value<DateTime?> dataCadastro = const Value.absent(),
                Value<DateTime?> dataContabilizado = const Value.absent(),
                Value<DateTime?> dataVistoria = const Value.absent(),
                Value<DateTime?> dataMarcacao = const Value.absent(),
                Value<DateTime?> dataBaixa = const Value.absent(),
                Value<DateTime?> vencimentoGarantia = const Value.absent(),
                Value<String?> numeroNotaFiscal = const Value.absent(),
                Value<String?> chaveNfe = const Value.absent(),
                Value<double?> valorOriginal = const Value.absent(),
                Value<double?> valorCompra = const Value.absent(),
                Value<double?> valorAtualizado = const Value.absent(),
                Value<double?> valorBaixa = const Value.absent(),
                Value<String?> deprecia = const Value.absent(),
                Value<String?> metodoDepreciacao = const Value.absent(),
                Value<DateTime?> inicioDepreciacao = const Value.absent(),
                Value<DateTime?> ultimaDepreciacao = const Value.absent(),
                Value<String?> tipoDepreciacao = const Value.absent(),
                Value<double?> taxaAnualDepreciacao = const Value.absent(),
                Value<double?> taxaMensalDepreciacao = const Value.absent(),
                Value<double?> taxaDepreciacaoAcelerada = const Value.absent(),
                Value<double?> taxaDepreciacaoIncentivada =
                    const Value.absent(),
                Value<String?> funcao = const Value.absent(),
              }) => PatrimBemsCompanion.insert(
                id: id,
                idCentroResultado: idCentroResultado,
                idPatrimTipoAquisicaoBem: idPatrimTipoAquisicaoBem,
                idPatrimEstadoConservacao: idPatrimEstadoConservacao,
                idPatrimGrupoBem: idPatrimGrupoBem,
                idFornecedor: idFornecedor,
                idSetor: idSetor,
                numeroNb: numeroNb,
                nome: nome,
                descricao: descricao,
                numeroSerie: numeroSerie,
                dataAquisicao: dataAquisicao,
                dataAceite: dataAceite,
                dataCadastro: dataCadastro,
                dataContabilizado: dataContabilizado,
                dataVistoria: dataVistoria,
                dataMarcacao: dataMarcacao,
                dataBaixa: dataBaixa,
                vencimentoGarantia: vencimentoGarantia,
                numeroNotaFiscal: numeroNotaFiscal,
                chaveNfe: chaveNfe,
                valorOriginal: valorOriginal,
                valorCompra: valorCompra,
                valorAtualizado: valorAtualizado,
                valorBaixa: valorBaixa,
                deprecia: deprecia,
                metodoDepreciacao: metodoDepreciacao,
                inicioDepreciacao: inicioDepreciacao,
                ultimaDepreciacao: ultimaDepreciacao,
                tipoDepreciacao: tipoDepreciacao,
                taxaAnualDepreciacao: taxaAnualDepreciacao,
                taxaMensalDepreciacao: taxaMensalDepreciacao,
                taxaDepreciacaoAcelerada: taxaDepreciacaoAcelerada,
                taxaDepreciacaoIncentivada: taxaDepreciacaoIncentivada,
                funcao: funcao,
              ),
          withReferenceMapper:
              (p0) =>
                  p0
                      .map(
                        (e) => (
                          e.readTable(table),
                          BaseReferences(db, table, e),
                        ),
                      )
                      .toList(),
          prefetchHooksCallback: null,
        ),
      );
}

typedef $$PatrimBemsTableProcessedTableManager =
    ProcessedTableManager<
      _$AppDatabase,
      $PatrimBemsTable,
      PatrimBem,
      $$PatrimBemsTableFilterComposer,
      $$PatrimBemsTableOrderingComposer,
      $$PatrimBemsTableAnnotationComposer,
      $$PatrimBemsTableCreateCompanionBuilder,
      $$PatrimBemsTableUpdateCompanionBuilder,
      (PatrimBem, BaseReferences<_$AppDatabase, $PatrimBemsTable, PatrimBem>),
      PatrimBem,
      PrefetchHooks Function()
    >;
typedef $$PcpInstrucaosTableCreateCompanionBuilder =
    PcpInstrucaosCompanion Function({
      Value<int?> id,
      Value<String?> codigo,
      Value<String?> descricao,
    });
typedef $$PcpInstrucaosTableUpdateCompanionBuilder =
    PcpInstrucaosCompanion Function({
      Value<int?> id,
      Value<String?> codigo,
      Value<String?> descricao,
    });

class $$PcpInstrucaosTableFilterComposer
    extends Composer<_$AppDatabase, $PcpInstrucaosTable> {
  $$PcpInstrucaosTableFilterComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnFilters<int> get id => $composableBuilder(
    column: $table.id,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get codigo => $composableBuilder(
    column: $table.codigo,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get descricao => $composableBuilder(
    column: $table.descricao,
    builder: (column) => ColumnFilters(column),
  );
}

class $$PcpInstrucaosTableOrderingComposer
    extends Composer<_$AppDatabase, $PcpInstrucaosTable> {
  $$PcpInstrucaosTableOrderingComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnOrderings<int> get id => $composableBuilder(
    column: $table.id,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get codigo => $composableBuilder(
    column: $table.codigo,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get descricao => $composableBuilder(
    column: $table.descricao,
    builder: (column) => ColumnOrderings(column),
  );
}

class $$PcpInstrucaosTableAnnotationComposer
    extends Composer<_$AppDatabase, $PcpInstrucaosTable> {
  $$PcpInstrucaosTableAnnotationComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  GeneratedColumn<int> get id =>
      $composableBuilder(column: $table.id, builder: (column) => column);

  GeneratedColumn<String> get codigo =>
      $composableBuilder(column: $table.codigo, builder: (column) => column);

  GeneratedColumn<String> get descricao =>
      $composableBuilder(column: $table.descricao, builder: (column) => column);
}

class $$PcpInstrucaosTableTableManager
    extends
        RootTableManager<
          _$AppDatabase,
          $PcpInstrucaosTable,
          PcpInstrucao,
          $$PcpInstrucaosTableFilterComposer,
          $$PcpInstrucaosTableOrderingComposer,
          $$PcpInstrucaosTableAnnotationComposer,
          $$PcpInstrucaosTableCreateCompanionBuilder,
          $$PcpInstrucaosTableUpdateCompanionBuilder,
          (
            PcpInstrucao,
            BaseReferences<_$AppDatabase, $PcpInstrucaosTable, PcpInstrucao>,
          ),
          PcpInstrucao,
          PrefetchHooks Function()
        > {
  $$PcpInstrucaosTableTableManager(_$AppDatabase db, $PcpInstrucaosTable table)
    : super(
        TableManagerState(
          db: db,
          table: table,
          createFilteringComposer:
              () => $$PcpInstrucaosTableFilterComposer($db: db, $table: table),
          createOrderingComposer:
              () =>
                  $$PcpInstrucaosTableOrderingComposer($db: db, $table: table),
          createComputedFieldComposer:
              () => $$PcpInstrucaosTableAnnotationComposer(
                $db: db,
                $table: table,
              ),
          updateCompanionCallback:
              ({
                Value<int?> id = const Value.absent(),
                Value<String?> codigo = const Value.absent(),
                Value<String?> descricao = const Value.absent(),
              }) => PcpInstrucaosCompanion(
                id: id,
                codigo: codigo,
                descricao: descricao,
              ),
          createCompanionCallback:
              ({
                Value<int?> id = const Value.absent(),
                Value<String?> codigo = const Value.absent(),
                Value<String?> descricao = const Value.absent(),
              }) => PcpInstrucaosCompanion.insert(
                id: id,
                codigo: codigo,
                descricao: descricao,
              ),
          withReferenceMapper:
              (p0) =>
                  p0
                      .map(
                        (e) => (
                          e.readTable(table),
                          BaseReferences(db, table, e),
                        ),
                      )
                      .toList(),
          prefetchHooksCallback: null,
        ),
      );
}

typedef $$PcpInstrucaosTableProcessedTableManager =
    ProcessedTableManager<
      _$AppDatabase,
      $PcpInstrucaosTable,
      PcpInstrucao,
      $$PcpInstrucaosTableFilterComposer,
      $$PcpInstrucaosTableOrderingComposer,
      $$PcpInstrucaosTableAnnotationComposer,
      $$PcpInstrucaosTableCreateCompanionBuilder,
      $$PcpInstrucaosTableUpdateCompanionBuilder,
      (
        PcpInstrucao,
        BaseReferences<_$AppDatabase, $PcpInstrucaosTable, PcpInstrucao>,
      ),
      PcpInstrucao,
      PrefetchHooks Function()
    >;
typedef $$ViewControleAcessosTableCreateCompanionBuilder =
    ViewControleAcessosCompanion Function({
      Value<int?> id,
      Value<int?> idPessoa,
      Value<String?> pessoaNome,
      Value<int?> idColaborador,
      Value<int?> idUsuario,
      Value<String?> administrador,
      Value<int?> idPapel,
      Value<String?> papelNome,
      Value<String?> papelDescricao,
      Value<int?> idFuncao,
      Value<String?> funcaoNome,
      Value<String?> funcaoDescricao,
      Value<int?> idPapelFuncao,
      Value<String?> habilitado,
      Value<String?> podeInserir,
      Value<String?> podeAlterar,
      Value<String?> podeExcluir,
    });
typedef $$ViewControleAcessosTableUpdateCompanionBuilder =
    ViewControleAcessosCompanion Function({
      Value<int?> id,
      Value<int?> idPessoa,
      Value<String?> pessoaNome,
      Value<int?> idColaborador,
      Value<int?> idUsuario,
      Value<String?> administrador,
      Value<int?> idPapel,
      Value<String?> papelNome,
      Value<String?> papelDescricao,
      Value<int?> idFuncao,
      Value<String?> funcaoNome,
      Value<String?> funcaoDescricao,
      Value<int?> idPapelFuncao,
      Value<String?> habilitado,
      Value<String?> podeInserir,
      Value<String?> podeAlterar,
      Value<String?> podeExcluir,
    });

class $$ViewControleAcessosTableFilterComposer
    extends Composer<_$AppDatabase, $ViewControleAcessosTable> {
  $$ViewControleAcessosTableFilterComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnFilters<int> get id => $composableBuilder(
    column: $table.id,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<int> get idPessoa => $composableBuilder(
    column: $table.idPessoa,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get pessoaNome => $composableBuilder(
    column: $table.pessoaNome,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<int> get idColaborador => $composableBuilder(
    column: $table.idColaborador,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<int> get idUsuario => $composableBuilder(
    column: $table.idUsuario,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get administrador => $composableBuilder(
    column: $table.administrador,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<int> get idPapel => $composableBuilder(
    column: $table.idPapel,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get papelNome => $composableBuilder(
    column: $table.papelNome,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get papelDescricao => $composableBuilder(
    column: $table.papelDescricao,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<int> get idFuncao => $composableBuilder(
    column: $table.idFuncao,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get funcaoNome => $composableBuilder(
    column: $table.funcaoNome,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get funcaoDescricao => $composableBuilder(
    column: $table.funcaoDescricao,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<int> get idPapelFuncao => $composableBuilder(
    column: $table.idPapelFuncao,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get habilitado => $composableBuilder(
    column: $table.habilitado,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get podeInserir => $composableBuilder(
    column: $table.podeInserir,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get podeAlterar => $composableBuilder(
    column: $table.podeAlterar,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get podeExcluir => $composableBuilder(
    column: $table.podeExcluir,
    builder: (column) => ColumnFilters(column),
  );
}

class $$ViewControleAcessosTableOrderingComposer
    extends Composer<_$AppDatabase, $ViewControleAcessosTable> {
  $$ViewControleAcessosTableOrderingComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnOrderings<int> get id => $composableBuilder(
    column: $table.id,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<int> get idPessoa => $composableBuilder(
    column: $table.idPessoa,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get pessoaNome => $composableBuilder(
    column: $table.pessoaNome,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<int> get idColaborador => $composableBuilder(
    column: $table.idColaborador,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<int> get idUsuario => $composableBuilder(
    column: $table.idUsuario,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get administrador => $composableBuilder(
    column: $table.administrador,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<int> get idPapel => $composableBuilder(
    column: $table.idPapel,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get papelNome => $composableBuilder(
    column: $table.papelNome,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get papelDescricao => $composableBuilder(
    column: $table.papelDescricao,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<int> get idFuncao => $composableBuilder(
    column: $table.idFuncao,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get funcaoNome => $composableBuilder(
    column: $table.funcaoNome,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get funcaoDescricao => $composableBuilder(
    column: $table.funcaoDescricao,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<int> get idPapelFuncao => $composableBuilder(
    column: $table.idPapelFuncao,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get habilitado => $composableBuilder(
    column: $table.habilitado,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get podeInserir => $composableBuilder(
    column: $table.podeInserir,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get podeAlterar => $composableBuilder(
    column: $table.podeAlterar,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get podeExcluir => $composableBuilder(
    column: $table.podeExcluir,
    builder: (column) => ColumnOrderings(column),
  );
}

class $$ViewControleAcessosTableAnnotationComposer
    extends Composer<_$AppDatabase, $ViewControleAcessosTable> {
  $$ViewControleAcessosTableAnnotationComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  GeneratedColumn<int> get id =>
      $composableBuilder(column: $table.id, builder: (column) => column);

  GeneratedColumn<int> get idPessoa =>
      $composableBuilder(column: $table.idPessoa, builder: (column) => column);

  GeneratedColumn<String> get pessoaNome => $composableBuilder(
    column: $table.pessoaNome,
    builder: (column) => column,
  );

  GeneratedColumn<int> get idColaborador => $composableBuilder(
    column: $table.idColaborador,
    builder: (column) => column,
  );

  GeneratedColumn<int> get idUsuario =>
      $composableBuilder(column: $table.idUsuario, builder: (column) => column);

  GeneratedColumn<String> get administrador => $composableBuilder(
    column: $table.administrador,
    builder: (column) => column,
  );

  GeneratedColumn<int> get idPapel =>
      $composableBuilder(column: $table.idPapel, builder: (column) => column);

  GeneratedColumn<String> get papelNome =>
      $composableBuilder(column: $table.papelNome, builder: (column) => column);

  GeneratedColumn<String> get papelDescricao => $composableBuilder(
    column: $table.papelDescricao,
    builder: (column) => column,
  );

  GeneratedColumn<int> get idFuncao =>
      $composableBuilder(column: $table.idFuncao, builder: (column) => column);

  GeneratedColumn<String> get funcaoNome => $composableBuilder(
    column: $table.funcaoNome,
    builder: (column) => column,
  );

  GeneratedColumn<String> get funcaoDescricao => $composableBuilder(
    column: $table.funcaoDescricao,
    builder: (column) => column,
  );

  GeneratedColumn<int> get idPapelFuncao => $composableBuilder(
    column: $table.idPapelFuncao,
    builder: (column) => column,
  );

  GeneratedColumn<String> get habilitado => $composableBuilder(
    column: $table.habilitado,
    builder: (column) => column,
  );

  GeneratedColumn<String> get podeInserir => $composableBuilder(
    column: $table.podeInserir,
    builder: (column) => column,
  );

  GeneratedColumn<String> get podeAlterar => $composableBuilder(
    column: $table.podeAlterar,
    builder: (column) => column,
  );

  GeneratedColumn<String> get podeExcluir => $composableBuilder(
    column: $table.podeExcluir,
    builder: (column) => column,
  );
}

class $$ViewControleAcessosTableTableManager
    extends
        RootTableManager<
          _$AppDatabase,
          $ViewControleAcessosTable,
          ViewControleAcesso,
          $$ViewControleAcessosTableFilterComposer,
          $$ViewControleAcessosTableOrderingComposer,
          $$ViewControleAcessosTableAnnotationComposer,
          $$ViewControleAcessosTableCreateCompanionBuilder,
          $$ViewControleAcessosTableUpdateCompanionBuilder,
          (
            ViewControleAcesso,
            BaseReferences<
              _$AppDatabase,
              $ViewControleAcessosTable,
              ViewControleAcesso
            >,
          ),
          ViewControleAcesso,
          PrefetchHooks Function()
        > {
  $$ViewControleAcessosTableTableManager(
    _$AppDatabase db,
    $ViewControleAcessosTable table,
  ) : super(
        TableManagerState(
          db: db,
          table: table,
          createFilteringComposer:
              () => $$ViewControleAcessosTableFilterComposer(
                $db: db,
                $table: table,
              ),
          createOrderingComposer:
              () => $$ViewControleAcessosTableOrderingComposer(
                $db: db,
                $table: table,
              ),
          createComputedFieldComposer:
              () => $$ViewControleAcessosTableAnnotationComposer(
                $db: db,
                $table: table,
              ),
          updateCompanionCallback:
              ({
                Value<int?> id = const Value.absent(),
                Value<int?> idPessoa = const Value.absent(),
                Value<String?> pessoaNome = const Value.absent(),
                Value<int?> idColaborador = const Value.absent(),
                Value<int?> idUsuario = const Value.absent(),
                Value<String?> administrador = const Value.absent(),
                Value<int?> idPapel = const Value.absent(),
                Value<String?> papelNome = const Value.absent(),
                Value<String?> papelDescricao = const Value.absent(),
                Value<int?> idFuncao = const Value.absent(),
                Value<String?> funcaoNome = const Value.absent(),
                Value<String?> funcaoDescricao = const Value.absent(),
                Value<int?> idPapelFuncao = const Value.absent(),
                Value<String?> habilitado = const Value.absent(),
                Value<String?> podeInserir = const Value.absent(),
                Value<String?> podeAlterar = const Value.absent(),
                Value<String?> podeExcluir = const Value.absent(),
              }) => ViewControleAcessosCompanion(
                id: id,
                idPessoa: idPessoa,
                pessoaNome: pessoaNome,
                idColaborador: idColaborador,
                idUsuario: idUsuario,
                administrador: administrador,
                idPapel: idPapel,
                papelNome: papelNome,
                papelDescricao: papelDescricao,
                idFuncao: idFuncao,
                funcaoNome: funcaoNome,
                funcaoDescricao: funcaoDescricao,
                idPapelFuncao: idPapelFuncao,
                habilitado: habilitado,
                podeInserir: podeInserir,
                podeAlterar: podeAlterar,
                podeExcluir: podeExcluir,
              ),
          createCompanionCallback:
              ({
                Value<int?> id = const Value.absent(),
                Value<int?> idPessoa = const Value.absent(),
                Value<String?> pessoaNome = const Value.absent(),
                Value<int?> idColaborador = const Value.absent(),
                Value<int?> idUsuario = const Value.absent(),
                Value<String?> administrador = const Value.absent(),
                Value<int?> idPapel = const Value.absent(),
                Value<String?> papelNome = const Value.absent(),
                Value<String?> papelDescricao = const Value.absent(),
                Value<int?> idFuncao = const Value.absent(),
                Value<String?> funcaoNome = const Value.absent(),
                Value<String?> funcaoDescricao = const Value.absent(),
                Value<int?> idPapelFuncao = const Value.absent(),
                Value<String?> habilitado = const Value.absent(),
                Value<String?> podeInserir = const Value.absent(),
                Value<String?> podeAlterar = const Value.absent(),
                Value<String?> podeExcluir = const Value.absent(),
              }) => ViewControleAcessosCompanion.insert(
                id: id,
                idPessoa: idPessoa,
                pessoaNome: pessoaNome,
                idColaborador: idColaborador,
                idUsuario: idUsuario,
                administrador: administrador,
                idPapel: idPapel,
                papelNome: papelNome,
                papelDescricao: papelDescricao,
                idFuncao: idFuncao,
                funcaoNome: funcaoNome,
                funcaoDescricao: funcaoDescricao,
                idPapelFuncao: idPapelFuncao,
                habilitado: habilitado,
                podeInserir: podeInserir,
                podeAlterar: podeAlterar,
                podeExcluir: podeExcluir,
              ),
          withReferenceMapper:
              (p0) =>
                  p0
                      .map(
                        (e) => (
                          e.readTable(table),
                          BaseReferences(db, table, e),
                        ),
                      )
                      .toList(),
          prefetchHooksCallback: null,
        ),
      );
}

typedef $$ViewControleAcessosTableProcessedTableManager =
    ProcessedTableManager<
      _$AppDatabase,
      $ViewControleAcessosTable,
      ViewControleAcesso,
      $$ViewControleAcessosTableFilterComposer,
      $$ViewControleAcessosTableOrderingComposer,
      $$ViewControleAcessosTableAnnotationComposer,
      $$ViewControleAcessosTableCreateCompanionBuilder,
      $$ViewControleAcessosTableUpdateCompanionBuilder,
      (
        ViewControleAcesso,
        BaseReferences<
          _$AppDatabase,
          $ViewControleAcessosTable,
          ViewControleAcesso
        >,
      ),
      ViewControleAcesso,
      PrefetchHooks Function()
    >;
typedef $$ViewPessoaUsuariosTableCreateCompanionBuilder =
    ViewPessoaUsuariosCompanion Function({
      Value<int?> id,
      Value<int?> idPessoa,
      Value<String?> pessoaNome,
      Value<String?> tipo,
      Value<String?> email,
      Value<int?> idColaborador,
      Value<int?> idUsuario,
      Value<String?> login,
      Value<String?> senha,
      Value<DateTime?> dataCadastro,
      Value<String?> administrador,
    });
typedef $$ViewPessoaUsuariosTableUpdateCompanionBuilder =
    ViewPessoaUsuariosCompanion Function({
      Value<int?> id,
      Value<int?> idPessoa,
      Value<String?> pessoaNome,
      Value<String?> tipo,
      Value<String?> email,
      Value<int?> idColaborador,
      Value<int?> idUsuario,
      Value<String?> login,
      Value<String?> senha,
      Value<DateTime?> dataCadastro,
      Value<String?> administrador,
    });

class $$ViewPessoaUsuariosTableFilterComposer
    extends Composer<_$AppDatabase, $ViewPessoaUsuariosTable> {
  $$ViewPessoaUsuariosTableFilterComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnFilters<int> get id => $composableBuilder(
    column: $table.id,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<int> get idPessoa => $composableBuilder(
    column: $table.idPessoa,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get pessoaNome => $composableBuilder(
    column: $table.pessoaNome,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get tipo => $composableBuilder(
    column: $table.tipo,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get email => $composableBuilder(
    column: $table.email,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<int> get idColaborador => $composableBuilder(
    column: $table.idColaborador,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<int> get idUsuario => $composableBuilder(
    column: $table.idUsuario,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get login => $composableBuilder(
    column: $table.login,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get senha => $composableBuilder(
    column: $table.senha,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<DateTime> get dataCadastro => $composableBuilder(
    column: $table.dataCadastro,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get administrador => $composableBuilder(
    column: $table.administrador,
    builder: (column) => ColumnFilters(column),
  );
}

class $$ViewPessoaUsuariosTableOrderingComposer
    extends Composer<_$AppDatabase, $ViewPessoaUsuariosTable> {
  $$ViewPessoaUsuariosTableOrderingComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnOrderings<int> get id => $composableBuilder(
    column: $table.id,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<int> get idPessoa => $composableBuilder(
    column: $table.idPessoa,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get pessoaNome => $composableBuilder(
    column: $table.pessoaNome,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get tipo => $composableBuilder(
    column: $table.tipo,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get email => $composableBuilder(
    column: $table.email,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<int> get idColaborador => $composableBuilder(
    column: $table.idColaborador,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<int> get idUsuario => $composableBuilder(
    column: $table.idUsuario,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get login => $composableBuilder(
    column: $table.login,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get senha => $composableBuilder(
    column: $table.senha,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<DateTime> get dataCadastro => $composableBuilder(
    column: $table.dataCadastro,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get administrador => $composableBuilder(
    column: $table.administrador,
    builder: (column) => ColumnOrderings(column),
  );
}

class $$ViewPessoaUsuariosTableAnnotationComposer
    extends Composer<_$AppDatabase, $ViewPessoaUsuariosTable> {
  $$ViewPessoaUsuariosTableAnnotationComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  GeneratedColumn<int> get id =>
      $composableBuilder(column: $table.id, builder: (column) => column);

  GeneratedColumn<int> get idPessoa =>
      $composableBuilder(column: $table.idPessoa, builder: (column) => column);

  GeneratedColumn<String> get pessoaNome => $composableBuilder(
    column: $table.pessoaNome,
    builder: (column) => column,
  );

  GeneratedColumn<String> get tipo =>
      $composableBuilder(column: $table.tipo, builder: (column) => column);

  GeneratedColumn<String> get email =>
      $composableBuilder(column: $table.email, builder: (column) => column);

  GeneratedColumn<int> get idColaborador => $composableBuilder(
    column: $table.idColaborador,
    builder: (column) => column,
  );

  GeneratedColumn<int> get idUsuario =>
      $composableBuilder(column: $table.idUsuario, builder: (column) => column);

  GeneratedColumn<String> get login =>
      $composableBuilder(column: $table.login, builder: (column) => column);

  GeneratedColumn<String> get senha =>
      $composableBuilder(column: $table.senha, builder: (column) => column);

  GeneratedColumn<DateTime> get dataCadastro => $composableBuilder(
    column: $table.dataCadastro,
    builder: (column) => column,
  );

  GeneratedColumn<String> get administrador => $composableBuilder(
    column: $table.administrador,
    builder: (column) => column,
  );
}

class $$ViewPessoaUsuariosTableTableManager
    extends
        RootTableManager<
          _$AppDatabase,
          $ViewPessoaUsuariosTable,
          ViewPessoaUsuario,
          $$ViewPessoaUsuariosTableFilterComposer,
          $$ViewPessoaUsuariosTableOrderingComposer,
          $$ViewPessoaUsuariosTableAnnotationComposer,
          $$ViewPessoaUsuariosTableCreateCompanionBuilder,
          $$ViewPessoaUsuariosTableUpdateCompanionBuilder,
          (
            ViewPessoaUsuario,
            BaseReferences<
              _$AppDatabase,
              $ViewPessoaUsuariosTable,
              ViewPessoaUsuario
            >,
          ),
          ViewPessoaUsuario,
          PrefetchHooks Function()
        > {
  $$ViewPessoaUsuariosTableTableManager(
    _$AppDatabase db,
    $ViewPessoaUsuariosTable table,
  ) : super(
        TableManagerState(
          db: db,
          table: table,
          createFilteringComposer:
              () => $$ViewPessoaUsuariosTableFilterComposer(
                $db: db,
                $table: table,
              ),
          createOrderingComposer:
              () => $$ViewPessoaUsuariosTableOrderingComposer(
                $db: db,
                $table: table,
              ),
          createComputedFieldComposer:
              () => $$ViewPessoaUsuariosTableAnnotationComposer(
                $db: db,
                $table: table,
              ),
          updateCompanionCallback:
              ({
                Value<int?> id = const Value.absent(),
                Value<int?> idPessoa = const Value.absent(),
                Value<String?> pessoaNome = const Value.absent(),
                Value<String?> tipo = const Value.absent(),
                Value<String?> email = const Value.absent(),
                Value<int?> idColaborador = const Value.absent(),
                Value<int?> idUsuario = const Value.absent(),
                Value<String?> login = const Value.absent(),
                Value<String?> senha = const Value.absent(),
                Value<DateTime?> dataCadastro = const Value.absent(),
                Value<String?> administrador = const Value.absent(),
              }) => ViewPessoaUsuariosCompanion(
                id: id,
                idPessoa: idPessoa,
                pessoaNome: pessoaNome,
                tipo: tipo,
                email: email,
                idColaborador: idColaborador,
                idUsuario: idUsuario,
                login: login,
                senha: senha,
                dataCadastro: dataCadastro,
                administrador: administrador,
              ),
          createCompanionCallback:
              ({
                Value<int?> id = const Value.absent(),
                Value<int?> idPessoa = const Value.absent(),
                Value<String?> pessoaNome = const Value.absent(),
                Value<String?> tipo = const Value.absent(),
                Value<String?> email = const Value.absent(),
                Value<int?> idColaborador = const Value.absent(),
                Value<int?> idUsuario = const Value.absent(),
                Value<String?> login = const Value.absent(),
                Value<String?> senha = const Value.absent(),
                Value<DateTime?> dataCadastro = const Value.absent(),
                Value<String?> administrador = const Value.absent(),
              }) => ViewPessoaUsuariosCompanion.insert(
                id: id,
                idPessoa: idPessoa,
                pessoaNome: pessoaNome,
                tipo: tipo,
                email: email,
                idColaborador: idColaborador,
                idUsuario: idUsuario,
                login: login,
                senha: senha,
                dataCadastro: dataCadastro,
                administrador: administrador,
              ),
          withReferenceMapper:
              (p0) =>
                  p0
                      .map(
                        (e) => (
                          e.readTable(table),
                          BaseReferences(db, table, e),
                        ),
                      )
                      .toList(),
          prefetchHooksCallback: null,
        ),
      );
}

typedef $$ViewPessoaUsuariosTableProcessedTableManager =
    ProcessedTableManager<
      _$AppDatabase,
      $ViewPessoaUsuariosTable,
      ViewPessoaUsuario,
      $$ViewPessoaUsuariosTableFilterComposer,
      $$ViewPessoaUsuariosTableOrderingComposer,
      $$ViewPessoaUsuariosTableAnnotationComposer,
      $$ViewPessoaUsuariosTableCreateCompanionBuilder,
      $$ViewPessoaUsuariosTableUpdateCompanionBuilder,
      (
        ViewPessoaUsuario,
        BaseReferences<
          _$AppDatabase,
          $ViewPessoaUsuariosTable,
          ViewPessoaUsuario
        >,
      ),
      ViewPessoaUsuario,
      PrefetchHooks Function()
    >;
typedef $$ViewPessoaColaboradorsTableCreateCompanionBuilder =
    ViewPessoaColaboradorsCompanion Function({
      Value<int?> id,
      Value<String?> nome,
      Value<String?> tipo,
      Value<String?> email,
      Value<String?> site,
      Value<String?> cpfCnpj,
      Value<String?> rgIe,
      Value<String?> matricula,
      Value<DateTime?> dataCadastro,
      Value<DateTime?> dataAdmissao,
      Value<DateTime?> dataDemissao,
      Value<String?> ctpsNumero,
      Value<String?> ctpsSerie,
      Value<DateTime?> ctpsDataExpedicao,
      Value<String?> ctpsUf,
      Value<String?> observacao,
      Value<String?> logradouro,
      Value<String?> numero,
      Value<String?> complemento,
      Value<String?> bairro,
      Value<String?> cidade,
      Value<String?> cep,
      Value<String?> municipioIbge,
      Value<String?> uf,
      Value<int?> idPessoa,
      Value<int?> idCargo,
      Value<int?> idSetor,
    });
typedef $$ViewPessoaColaboradorsTableUpdateCompanionBuilder =
    ViewPessoaColaboradorsCompanion Function({
      Value<int?> id,
      Value<String?> nome,
      Value<String?> tipo,
      Value<String?> email,
      Value<String?> site,
      Value<String?> cpfCnpj,
      Value<String?> rgIe,
      Value<String?> matricula,
      Value<DateTime?> dataCadastro,
      Value<DateTime?> dataAdmissao,
      Value<DateTime?> dataDemissao,
      Value<String?> ctpsNumero,
      Value<String?> ctpsSerie,
      Value<DateTime?> ctpsDataExpedicao,
      Value<String?> ctpsUf,
      Value<String?> observacao,
      Value<String?> logradouro,
      Value<String?> numero,
      Value<String?> complemento,
      Value<String?> bairro,
      Value<String?> cidade,
      Value<String?> cep,
      Value<String?> municipioIbge,
      Value<String?> uf,
      Value<int?> idPessoa,
      Value<int?> idCargo,
      Value<int?> idSetor,
    });

class $$ViewPessoaColaboradorsTableFilterComposer
    extends Composer<_$AppDatabase, $ViewPessoaColaboradorsTable> {
  $$ViewPessoaColaboradorsTableFilterComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnFilters<int> get id => $composableBuilder(
    column: $table.id,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get nome => $composableBuilder(
    column: $table.nome,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get tipo => $composableBuilder(
    column: $table.tipo,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get email => $composableBuilder(
    column: $table.email,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get site => $composableBuilder(
    column: $table.site,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get cpfCnpj => $composableBuilder(
    column: $table.cpfCnpj,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get rgIe => $composableBuilder(
    column: $table.rgIe,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get matricula => $composableBuilder(
    column: $table.matricula,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<DateTime> get dataCadastro => $composableBuilder(
    column: $table.dataCadastro,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<DateTime> get dataAdmissao => $composableBuilder(
    column: $table.dataAdmissao,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<DateTime> get dataDemissao => $composableBuilder(
    column: $table.dataDemissao,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get ctpsNumero => $composableBuilder(
    column: $table.ctpsNumero,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get ctpsSerie => $composableBuilder(
    column: $table.ctpsSerie,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<DateTime> get ctpsDataExpedicao => $composableBuilder(
    column: $table.ctpsDataExpedicao,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get ctpsUf => $composableBuilder(
    column: $table.ctpsUf,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get observacao => $composableBuilder(
    column: $table.observacao,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get logradouro => $composableBuilder(
    column: $table.logradouro,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get numero => $composableBuilder(
    column: $table.numero,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get complemento => $composableBuilder(
    column: $table.complemento,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get bairro => $composableBuilder(
    column: $table.bairro,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get cidade => $composableBuilder(
    column: $table.cidade,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get cep => $composableBuilder(
    column: $table.cep,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get municipioIbge => $composableBuilder(
    column: $table.municipioIbge,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get uf => $composableBuilder(
    column: $table.uf,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<int> get idPessoa => $composableBuilder(
    column: $table.idPessoa,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<int> get idCargo => $composableBuilder(
    column: $table.idCargo,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<int> get idSetor => $composableBuilder(
    column: $table.idSetor,
    builder: (column) => ColumnFilters(column),
  );
}

class $$ViewPessoaColaboradorsTableOrderingComposer
    extends Composer<_$AppDatabase, $ViewPessoaColaboradorsTable> {
  $$ViewPessoaColaboradorsTableOrderingComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnOrderings<int> get id => $composableBuilder(
    column: $table.id,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get nome => $composableBuilder(
    column: $table.nome,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get tipo => $composableBuilder(
    column: $table.tipo,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get email => $composableBuilder(
    column: $table.email,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get site => $composableBuilder(
    column: $table.site,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get cpfCnpj => $composableBuilder(
    column: $table.cpfCnpj,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get rgIe => $composableBuilder(
    column: $table.rgIe,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get matricula => $composableBuilder(
    column: $table.matricula,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<DateTime> get dataCadastro => $composableBuilder(
    column: $table.dataCadastro,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<DateTime> get dataAdmissao => $composableBuilder(
    column: $table.dataAdmissao,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<DateTime> get dataDemissao => $composableBuilder(
    column: $table.dataDemissao,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get ctpsNumero => $composableBuilder(
    column: $table.ctpsNumero,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get ctpsSerie => $composableBuilder(
    column: $table.ctpsSerie,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<DateTime> get ctpsDataExpedicao => $composableBuilder(
    column: $table.ctpsDataExpedicao,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get ctpsUf => $composableBuilder(
    column: $table.ctpsUf,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get observacao => $composableBuilder(
    column: $table.observacao,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get logradouro => $composableBuilder(
    column: $table.logradouro,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get numero => $composableBuilder(
    column: $table.numero,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get complemento => $composableBuilder(
    column: $table.complemento,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get bairro => $composableBuilder(
    column: $table.bairro,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get cidade => $composableBuilder(
    column: $table.cidade,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get cep => $composableBuilder(
    column: $table.cep,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get municipioIbge => $composableBuilder(
    column: $table.municipioIbge,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get uf => $composableBuilder(
    column: $table.uf,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<int> get idPessoa => $composableBuilder(
    column: $table.idPessoa,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<int> get idCargo => $composableBuilder(
    column: $table.idCargo,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<int> get idSetor => $composableBuilder(
    column: $table.idSetor,
    builder: (column) => ColumnOrderings(column),
  );
}

class $$ViewPessoaColaboradorsTableAnnotationComposer
    extends Composer<_$AppDatabase, $ViewPessoaColaboradorsTable> {
  $$ViewPessoaColaboradorsTableAnnotationComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  GeneratedColumn<int> get id =>
      $composableBuilder(column: $table.id, builder: (column) => column);

  GeneratedColumn<String> get nome =>
      $composableBuilder(column: $table.nome, builder: (column) => column);

  GeneratedColumn<String> get tipo =>
      $composableBuilder(column: $table.tipo, builder: (column) => column);

  GeneratedColumn<String> get email =>
      $composableBuilder(column: $table.email, builder: (column) => column);

  GeneratedColumn<String> get site =>
      $composableBuilder(column: $table.site, builder: (column) => column);

  GeneratedColumn<String> get cpfCnpj =>
      $composableBuilder(column: $table.cpfCnpj, builder: (column) => column);

  GeneratedColumn<String> get rgIe =>
      $composableBuilder(column: $table.rgIe, builder: (column) => column);

  GeneratedColumn<String> get matricula =>
      $composableBuilder(column: $table.matricula, builder: (column) => column);

  GeneratedColumn<DateTime> get dataCadastro => $composableBuilder(
    column: $table.dataCadastro,
    builder: (column) => column,
  );

  GeneratedColumn<DateTime> get dataAdmissao => $composableBuilder(
    column: $table.dataAdmissao,
    builder: (column) => column,
  );

  GeneratedColumn<DateTime> get dataDemissao => $composableBuilder(
    column: $table.dataDemissao,
    builder: (column) => column,
  );

  GeneratedColumn<String> get ctpsNumero => $composableBuilder(
    column: $table.ctpsNumero,
    builder: (column) => column,
  );

  GeneratedColumn<String> get ctpsSerie =>
      $composableBuilder(column: $table.ctpsSerie, builder: (column) => column);

  GeneratedColumn<DateTime> get ctpsDataExpedicao => $composableBuilder(
    column: $table.ctpsDataExpedicao,
    builder: (column) => column,
  );

  GeneratedColumn<String> get ctpsUf =>
      $composableBuilder(column: $table.ctpsUf, builder: (column) => column);

  GeneratedColumn<String> get observacao => $composableBuilder(
    column: $table.observacao,
    builder: (column) => column,
  );

  GeneratedColumn<String> get logradouro => $composableBuilder(
    column: $table.logradouro,
    builder: (column) => column,
  );

  GeneratedColumn<String> get numero =>
      $composableBuilder(column: $table.numero, builder: (column) => column);

  GeneratedColumn<String> get complemento => $composableBuilder(
    column: $table.complemento,
    builder: (column) => column,
  );

  GeneratedColumn<String> get bairro =>
      $composableBuilder(column: $table.bairro, builder: (column) => column);

  GeneratedColumn<String> get cidade =>
      $composableBuilder(column: $table.cidade, builder: (column) => column);

  GeneratedColumn<String> get cep =>
      $composableBuilder(column: $table.cep, builder: (column) => column);

  GeneratedColumn<String> get municipioIbge => $composableBuilder(
    column: $table.municipioIbge,
    builder: (column) => column,
  );

  GeneratedColumn<String> get uf =>
      $composableBuilder(column: $table.uf, builder: (column) => column);

  GeneratedColumn<int> get idPessoa =>
      $composableBuilder(column: $table.idPessoa, builder: (column) => column);

  GeneratedColumn<int> get idCargo =>
      $composableBuilder(column: $table.idCargo, builder: (column) => column);

  GeneratedColumn<int> get idSetor =>
      $composableBuilder(column: $table.idSetor, builder: (column) => column);
}

class $$ViewPessoaColaboradorsTableTableManager
    extends
        RootTableManager<
          _$AppDatabase,
          $ViewPessoaColaboradorsTable,
          ViewPessoaColaborador,
          $$ViewPessoaColaboradorsTableFilterComposer,
          $$ViewPessoaColaboradorsTableOrderingComposer,
          $$ViewPessoaColaboradorsTableAnnotationComposer,
          $$ViewPessoaColaboradorsTableCreateCompanionBuilder,
          $$ViewPessoaColaboradorsTableUpdateCompanionBuilder,
          (
            ViewPessoaColaborador,
            BaseReferences<
              _$AppDatabase,
              $ViewPessoaColaboradorsTable,
              ViewPessoaColaborador
            >,
          ),
          ViewPessoaColaborador,
          PrefetchHooks Function()
        > {
  $$ViewPessoaColaboradorsTableTableManager(
    _$AppDatabase db,
    $ViewPessoaColaboradorsTable table,
  ) : super(
        TableManagerState(
          db: db,
          table: table,
          createFilteringComposer:
              () => $$ViewPessoaColaboradorsTableFilterComposer(
                $db: db,
                $table: table,
              ),
          createOrderingComposer:
              () => $$ViewPessoaColaboradorsTableOrderingComposer(
                $db: db,
                $table: table,
              ),
          createComputedFieldComposer:
              () => $$ViewPessoaColaboradorsTableAnnotationComposer(
                $db: db,
                $table: table,
              ),
          updateCompanionCallback:
              ({
                Value<int?> id = const Value.absent(),
                Value<String?> nome = const Value.absent(),
                Value<String?> tipo = const Value.absent(),
                Value<String?> email = const Value.absent(),
                Value<String?> site = const Value.absent(),
                Value<String?> cpfCnpj = const Value.absent(),
                Value<String?> rgIe = const Value.absent(),
                Value<String?> matricula = const Value.absent(),
                Value<DateTime?> dataCadastro = const Value.absent(),
                Value<DateTime?> dataAdmissao = const Value.absent(),
                Value<DateTime?> dataDemissao = const Value.absent(),
                Value<String?> ctpsNumero = const Value.absent(),
                Value<String?> ctpsSerie = const Value.absent(),
                Value<DateTime?> ctpsDataExpedicao = const Value.absent(),
                Value<String?> ctpsUf = const Value.absent(),
                Value<String?> observacao = const Value.absent(),
                Value<String?> logradouro = const Value.absent(),
                Value<String?> numero = const Value.absent(),
                Value<String?> complemento = const Value.absent(),
                Value<String?> bairro = const Value.absent(),
                Value<String?> cidade = const Value.absent(),
                Value<String?> cep = const Value.absent(),
                Value<String?> municipioIbge = const Value.absent(),
                Value<String?> uf = const Value.absent(),
                Value<int?> idPessoa = const Value.absent(),
                Value<int?> idCargo = const Value.absent(),
                Value<int?> idSetor = const Value.absent(),
              }) => ViewPessoaColaboradorsCompanion(
                id: id,
                nome: nome,
                tipo: tipo,
                email: email,
                site: site,
                cpfCnpj: cpfCnpj,
                rgIe: rgIe,
                matricula: matricula,
                dataCadastro: dataCadastro,
                dataAdmissao: dataAdmissao,
                dataDemissao: dataDemissao,
                ctpsNumero: ctpsNumero,
                ctpsSerie: ctpsSerie,
                ctpsDataExpedicao: ctpsDataExpedicao,
                ctpsUf: ctpsUf,
                observacao: observacao,
                logradouro: logradouro,
                numero: numero,
                complemento: complemento,
                bairro: bairro,
                cidade: cidade,
                cep: cep,
                municipioIbge: municipioIbge,
                uf: uf,
                idPessoa: idPessoa,
                idCargo: idCargo,
                idSetor: idSetor,
              ),
          createCompanionCallback:
              ({
                Value<int?> id = const Value.absent(),
                Value<String?> nome = const Value.absent(),
                Value<String?> tipo = const Value.absent(),
                Value<String?> email = const Value.absent(),
                Value<String?> site = const Value.absent(),
                Value<String?> cpfCnpj = const Value.absent(),
                Value<String?> rgIe = const Value.absent(),
                Value<String?> matricula = const Value.absent(),
                Value<DateTime?> dataCadastro = const Value.absent(),
                Value<DateTime?> dataAdmissao = const Value.absent(),
                Value<DateTime?> dataDemissao = const Value.absent(),
                Value<String?> ctpsNumero = const Value.absent(),
                Value<String?> ctpsSerie = const Value.absent(),
                Value<DateTime?> ctpsDataExpedicao = const Value.absent(),
                Value<String?> ctpsUf = const Value.absent(),
                Value<String?> observacao = const Value.absent(),
                Value<String?> logradouro = const Value.absent(),
                Value<String?> numero = const Value.absent(),
                Value<String?> complemento = const Value.absent(),
                Value<String?> bairro = const Value.absent(),
                Value<String?> cidade = const Value.absent(),
                Value<String?> cep = const Value.absent(),
                Value<String?> municipioIbge = const Value.absent(),
                Value<String?> uf = const Value.absent(),
                Value<int?> idPessoa = const Value.absent(),
                Value<int?> idCargo = const Value.absent(),
                Value<int?> idSetor = const Value.absent(),
              }) => ViewPessoaColaboradorsCompanion.insert(
                id: id,
                nome: nome,
                tipo: tipo,
                email: email,
                site: site,
                cpfCnpj: cpfCnpj,
                rgIe: rgIe,
                matricula: matricula,
                dataCadastro: dataCadastro,
                dataAdmissao: dataAdmissao,
                dataDemissao: dataDemissao,
                ctpsNumero: ctpsNumero,
                ctpsSerie: ctpsSerie,
                ctpsDataExpedicao: ctpsDataExpedicao,
                ctpsUf: ctpsUf,
                observacao: observacao,
                logradouro: logradouro,
                numero: numero,
                complemento: complemento,
                bairro: bairro,
                cidade: cidade,
                cep: cep,
                municipioIbge: municipioIbge,
                uf: uf,
                idPessoa: idPessoa,
                idCargo: idCargo,
                idSetor: idSetor,
              ),
          withReferenceMapper:
              (p0) =>
                  p0
                      .map(
                        (e) => (
                          e.readTable(table),
                          BaseReferences(db, table, e),
                        ),
                      )
                      .toList(),
          prefetchHooksCallback: null,
        ),
      );
}

typedef $$ViewPessoaColaboradorsTableProcessedTableManager =
    ProcessedTableManager<
      _$AppDatabase,
      $ViewPessoaColaboradorsTable,
      ViewPessoaColaborador,
      $$ViewPessoaColaboradorsTableFilterComposer,
      $$ViewPessoaColaboradorsTableOrderingComposer,
      $$ViewPessoaColaboradorsTableAnnotationComposer,
      $$ViewPessoaColaboradorsTableCreateCompanionBuilder,
      $$ViewPessoaColaboradorsTableUpdateCompanionBuilder,
      (
        ViewPessoaColaborador,
        BaseReferences<
          _$AppDatabase,
          $ViewPessoaColaboradorsTable,
          ViewPessoaColaborador
        >,
      ),
      ViewPessoaColaborador,
      PrefetchHooks Function()
    >;

class $AppDatabaseManager {
  final _$AppDatabase _db;
  $AppDatabaseManager(this._db);
  $$PcpOpDetalhesTableTableManager get pcpOpDetalhes =>
      $$PcpOpDetalhesTableTableManager(_db, _db.pcpOpDetalhes);
  $$PcpServicoColaboradorsTableTableManager get pcpServicoColaboradors =>
      $$PcpServicoColaboradorsTableTableManager(
        _db,
        _db.pcpServicoColaboradors,
      );
  $$PcpInstrucaoOpsTableTableManager get pcpInstrucaoOps =>
      $$PcpInstrucaoOpsTableTableManager(_db, _db.pcpInstrucaoOps);
  $$PcpServicoEquipamentosTableTableManager get pcpServicoEquipamentos =>
      $$PcpServicoEquipamentosTableTableManager(
        _db,
        _db.pcpServicoEquipamentos,
      );
  $$PcpOpCabecalhosTableTableManager get pcpOpCabecalhos =>
      $$PcpOpCabecalhosTableTableManager(_db, _db.pcpOpCabecalhos);
  $$PcpServicosTableTableManager get pcpServicos =>
      $$PcpServicosTableTableManager(_db, _db.pcpServicos);
  $$ProdutosTableTableManager get produtos =>
      $$ProdutosTableTableManager(_db, _db.produtos);
  $$PatrimBemsTableTableManager get patrimBems =>
      $$PatrimBemsTableTableManager(_db, _db.patrimBems);
  $$PcpInstrucaosTableTableManager get pcpInstrucaos =>
      $$PcpInstrucaosTableTableManager(_db, _db.pcpInstrucaos);
  $$ViewControleAcessosTableTableManager get viewControleAcessos =>
      $$ViewControleAcessosTableTableManager(_db, _db.viewControleAcessos);
  $$ViewPessoaUsuariosTableTableManager get viewPessoaUsuarios =>
      $$ViewPessoaUsuariosTableTableManager(_db, _db.viewPessoaUsuarios);
  $$ViewPessoaColaboradorsTableTableManager get viewPessoaColaboradors =>
      $$ViewPessoaColaboradorsTableTableManager(
        _db,
        _db.viewPessoaColaboradors,
      );
}
