import 'package:pcp/app/data/provider/api/api_provider_base.dart';
import 'package:pcp/app/data/model/model_imports.dart';

class PcpServicoApiProvider extends ApiProviderBase {
  static const _path = '/pcp-servico';

  Future<List<PcpServicoModel>?> getList({Filter? filter}) {
    return super.getListBase(
      '$_path/',
      (json) => PcpServicoModel.fromJson(json),
      filter: filter,
    );
  }

  Future<PcpServicoModel?> getObject(dynamic pk) {
    return super.getObjectBase(
      _path,
      pk,
      (json) => PcpServicoModel.fromJson(json),
    );
  }

  Future<PcpServicoModel?>? insert(PcpServicoModel model) {
    return super.insertBase(
      _path,
      model,
      (json) => PcpServicoModel.fromJson(json),
    );
  }

  Future<PcpServicoModel?>? update(PcpServicoModel model) {
    return super.updateBase(
      _path,
      model,
      (json) => PcpServicoModel.fromJson(json),
    );
  }

  Future<bool?> delete(dynamic pk) {
    return super.deleteBase(_path, pk);
  }
}
