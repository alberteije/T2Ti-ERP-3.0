import 'package:flutter/material.dart';
import 'dart:math';
import 'package:get/get.dart';
import 'package:extended_masked_text/extended_masked_text.dart';
import 'package:pcp/app/page/shared_widget/input/input_imports.dart';

import 'package:pcp/app/infra/infra_imports.dart';
import 'package:pcp/app/page/page_imports.dart';
import 'package:pcp/app/page/shared_widget/message_dialog.dart';
import 'package:pcp/app/page/grid_columns/grid_columns_imports.dart';
import 'package:pcp/app/routes/app_routes.dart';
import 'package:pcp/app/controller/controller_imports.dart';
import 'package:pcp/app/data/model/model_imports.dart';
import 'package:pluto_grid/pluto_grid.dart';

class PcpServicoController extends ControllerBase<PcpServicoModel, void> with GetSingleTickerProviderStateMixin {

  PcpServicoController() : super(repository: null) {
    dbColumns = PcpServicoModel.dbColumns;
    aliasColumns = PcpServicoModel.aliasColumns;
    gridColumns = pcpServicoGridColumns();
    functionName = "pcp_servico";
    screenTitle = "Serviços";
  }

  final _pcpServicoModel = PcpServicoModel().obs;
  PcpServicoModel get pcpServicoModel => _pcpServicoModel.value;
  set pcpServicoModel(value) => _pcpServicoModel.value = value ?? PcpServicoModel();

  List<PcpServicoModel> get pcpServicoModelList => Get.find<PcpOpDetalheController>().pcpOpDetalheModel.pcpServicoModelList ?? [];

  final pcpServicoScaffoldKey = GlobalKey<ScaffoldState>();
  final pcpServicoTabPageScaffoldKey = GlobalKey<ScaffoldState>();
  final pcpServicoFormKey = GlobalKey<FormState>();
  late TabController tabController;
  String? mandatoryMessage;

  @override
  PcpServicoModel createNewModel() => PcpServicoModel();

  @override
  final standardFieldForFilter = PcpServicoModel.aliasColumns[PcpServicoModel.dbColumns.indexOf('inicio_realizado')];

  final pcpOpDetalheModelController = TextEditingController();
  final inicioRealizadoController = DatePickerItemController(null);
  final terminoRealizadoController = DatePickerItemController(null);
  final horasRealizadoController = MoneyMaskedTextController(precision: 0, decimalSeparator: '', thousandSeparator: '');
  final minutosRealizadoController = MoneyMaskedTextController(precision: 0, decimalSeparator: '', thousandSeparator: '');
  final segundosRealizadoController = MoneyMaskedTextController(precision: 0, decimalSeparator: '', thousandSeparator: '');
  final custoRealizadoController = MoneyMaskedTextController();
  final inicioPrevistoController = DatePickerItemController(null);
  final terminoPrevistoController = DatePickerItemController(null);
  final horasPrevistoController = MoneyMaskedTextController(precision: 0, decimalSeparator: '', thousandSeparator: '');
  final minutosPrevistoController = MoneyMaskedTextController(precision: 0, decimalSeparator: '', thousandSeparator: '');
  final segundosPrevistoController = MoneyMaskedTextController(precision: 0, decimalSeparator: '', thousandSeparator: '');
  final custoPrevistoController = MoneyMaskedTextController();

  final Map<String, dynamic> mobileConfig = {
    'primaryColumns': ['inicio_realizado'],
    'secondaryColumns': ['termino_realizado'],
  };

  List<Map<String, dynamic>> get mobileItems {
    return modelList.map((pcpServico) => pcpServico.toJson).toList();
  }

  @override
  List<PlutoRow> plutoRows() => List<PlutoRow>.from(pcpServicoModelList.map((model) => model.toPlutoRow()));

  @override
  Future<void> getList({Filter? filter}) async {}

  @override
  void prepareForInsert() {
    isNewRecord = true;
    pcpServicoModel = createNewModel();
    _resetForm();
    tabController.animateTo(0);
    updateControllersFromModel();
    Get.toNamed(Routes.pcpServicoTabPage);
  }

  void _resetForm() {
    formWasChanged = false;
    pcpOpDetalheModelController.text = '';
    inicioRealizadoController.date = null;
    terminoRealizadoController.date = null;
    horasRealizadoController.updateValue(0);
    minutosRealizadoController.updateValue(0);
    segundosRealizadoController.updateValue(0);
    custoRealizadoController.updateValue(0);
    inicioPrevistoController.date = null;
    terminoPrevistoController.date = null;
    horasPrevistoController.updateValue(0);
    minutosPrevistoController.updateValue(0);
    segundosPrevistoController.updateValue(0);
    custoPrevistoController.updateValue(0);
  }

  @override
  void selectRowForEditing(PlutoRow? row) async {
    if (row == null) {
      showInfoSnackBar(message: 'message_select_one_to_edited'.tr);
      return;
    }

    selectRowForEditingByTempId(row.cells['tempId']?.value);
  }

  @override
  void selectRowForEditingById(int id) {}

  void selectRowForEditingByTempId(String tempId) {
		isNewRecord = false;
    final model = pcpServicoModelList.firstWhere((m) => m.tempId == tempId);
    pcpServicoModel = model.clone();
		pcpServicoModel.tempId = model.tempId;
    updateControllersFromModel();
    Get.to(() => PcpServicoTabPage());
  }

  _configureChildrenControllers() {
    //Colaboradores
		Get.put<PcpServicoColaboradorController>(PcpServicoColaboradorController()); 

    //Equipamentos
		Get.put<PcpServicoEquipamentoController>(PcpServicoEquipamentoController()); 

  }
	
	_releaseChildrenControllers() {
    //Colaboradores
		Get.delete<PcpServicoColaboradorController>(); 

    //Equipamentos
		Get.delete<PcpServicoEquipamentoController>(); 

	}
  
  void updateControllersFromModel() {
    inicioRealizadoController.date = pcpServicoModel.inicioRealizado;
    terminoRealizadoController.date = pcpServicoModel.terminoRealizado;
    horasRealizadoController.updateValue((pcpServicoModel.horasRealizado ?? 0).toDouble());
    minutosRealizadoController.updateValue((pcpServicoModel.minutosRealizado ?? 0).toDouble());
    segundosRealizadoController.updateValue((pcpServicoModel.segundosRealizado ?? 0).toDouble());
    custoRealizadoController.updateValue(pcpServicoModel.custoRealizado ?? 0);
    inicioPrevistoController.date = pcpServicoModel.inicioPrevisto;
    terminoPrevistoController.date = pcpServicoModel.terminoPrevisto;
    horasPrevistoController.updateValue((pcpServicoModel.horasPrevisto ?? 0).toDouble());
    minutosPrevistoController.updateValue((pcpServicoModel.minutosPrevisto ?? 0).toDouble());
    segundosPrevistoController.updateValue((pcpServicoModel.segundosPrevisto ?? 0).toDouble());
    custoPrevistoController.updateValue(pcpServicoModel.custoPrevisto ?? 0);

    formWasChanged = false;
    _updateChildrenControllersFromModel();
  }

  void _updateChildrenControllersFromModel() {
    //Colaboradores
		final pcpServicoColaboradorController = Get.find<PcpServicoColaboradorController>(); 
		pcpServicoColaboradorController.userMadeChanges = false; 

    //Equipamentos
		final pcpServicoEquipamentoController = Get.find<PcpServicoEquipamentoController>(); 
		pcpServicoEquipamentoController.userMadeChanges = false; 

  }

  @override
  Future<void> save() async {
    if (!validateCurrentForm()) return;

    if (validateForms()) {
      if (userMadeChanges()) {
        if (isNewRecord) {
          pcpServicoModelList.insert(0, pcpServicoModel.clone());
        } else {
          final index = pcpServicoModelList.indexWhere((m) => m.tempId == pcpServicoModel.tempId);
          if (index >= 0) {
            pcpServicoModelList[index] = pcpServicoModel.clone();
          }
        }
        loadData();
        Get.back(result: true);
      }
    } else {
      Get.back();
    }
  }

  List<Tab> tabItems = [
    Tab( 
			icon: Icon(iconDataList[Random().nextInt(10)]), 
			text: 'Serviços', 
		),
    Tab( 
			icon: Icon(iconDataList[Random().nextInt(10)]), 
			text: 'Colaboradores', 
		),
    Tab( 
			icon: Icon(iconDataList[Random().nextInt(10)]), 
			text: 'Equipamentos', 
		),
  ];

  List<Widget> tabPages() {
    return [
      PcpServicoEditPage(),
      const PcpServicoColaboradorListPage(),
      const PcpServicoEquipamentoListPage(),
    ];
  }

  @override
  void preventDataLoss() {
    if (userMadeChanges()) {
      showQuestionDialog('message_data_loss'.tr, () { 
        Get.back(); 
      });
    } else {
      Get.back();
    }
  }  

  bool userMadeChanges() {
    return
    formWasChanged 
    || 
		Get.find<PcpServicoColaboradorController>().userMadeChanges
    || 
		Get.find<PcpServicoEquipamentoController>().userMadeChanges
    ;
  }

  void tabChange(int index) {
    validateCurrentForm();
  }

  bool validateCurrentForm() {
    return true;
  }

  bool validateForms() {
    return true;
  }

  @override
  void onInit() {
    super.onInit();
    tabController = TabController(vsync: this, length: tabItems.length);
    _configureChildrenControllers();
  }
	
  @override
  void onClose() {
    tabController.dispose();
    pcpOpDetalheModelController.dispose();
    inicioRealizadoController.dispose();
    terminoRealizadoController.dispose();
    horasRealizadoController.dispose();
    minutosRealizadoController.dispose();
    segundosRealizadoController.dispose();
    custoRealizadoController.dispose();
    inicioPrevistoController.dispose();
    terminoPrevistoController.dispose();
    horasPrevistoController.dispose();
    minutosPrevistoController.dispose();
    segundosPrevistoController.dispose();
    custoPrevistoController.dispose();
    _releaseChildrenControllers();
  }	
}