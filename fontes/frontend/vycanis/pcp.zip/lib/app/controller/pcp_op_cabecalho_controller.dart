import 'package:flutter/material.dart';
import 'dart:math';
import 'package:get/get.dart';
import 'package:extended_masked_text/extended_masked_text.dart';
import 'package:pcp/app/page/shared_widget/input/input_imports.dart';

import 'package:pcp/app/infra/infra_imports.dart';
import 'package:pcp/app/page/page_imports.dart';
import 'package:pcp/app/page/shared_widget/message_dialog.dart';
import 'package:pcp/app/page/grid_columns/grid_columns_imports.dart';
import 'package:pcp/app/routes/app_routes.dart';
import 'package:pcp/app/controller/controller_imports.dart';
import 'package:pcp/app/data/model/model_imports.dart';
import 'package:pcp/app/data/repository/pcp_op_cabecalho_repository.dart';

class PcpOpCabecalhoController extends ControllerBase<PcpOpCabecalhoModel, PcpOpCabecalhoRepository> 
with GetSingleTickerProviderStateMixin {

  PcpOpCabecalhoController({required super.repository}) {
    dbColumns = PcpOpCabecalhoModel.dbColumns;
    aliasColumns = PcpOpCabecalhoModel.aliasColumns;
    gridColumns = pcpOpCabecalhoGridColumns();
    functionName = "pcp_op_cabecalho";
    screenTitle = "Ordem de Produção";
  }

  final pcpOpCabecalhoScaffoldKey = GlobalKey<ScaffoldState>();
  final pcpOpCabecalhoTabPageScaffoldKey = GlobalKey<ScaffoldState>();
  final pcpOpCabecalhoFormKey = GlobalKey<FormState>();
  late TabController tabController;
  String? mandatoryMessage;  

  @override
  PcpOpCabecalhoModel createNewModel() => PcpOpCabecalhoModel();

  @override
  final standardFieldForFilter = PcpOpCabecalhoModel.aliasColumns[PcpOpCabecalhoModel.dbColumns.indexOf('data_inicio')];

  final dataInicioController = DatePickerItemController(null);
  final dataPrevisaoEntregaController = DatePickerItemController(null);
  final dataTerminoController = DatePickerItemController(null);
  final custoTotalPrevistoController = MoneyMaskedTextController();
  final custoTotalRealizadoController = MoneyMaskedTextController();
  final porcentoVendaController = MoneyMaskedTextController();
  final porcentoEstoqueController = MoneyMaskedTextController();

  final Map<String, dynamic> mobileConfig = {
    'primaryColumns': ['data_inicio'],
    'secondaryColumns': ['data_previsao_entrega'],
  };

  List<Map<String, dynamic>> get mobileItems {
    return modelList.map((pcpOpCabecalho) => pcpOpCabecalho.toJson).toList();
  }

  @override
  void prepareForInsert() {
    isNewRecord = true;
    currentModel = createNewModel();
    _resetForm();
    tabController.animateTo(0);
    updateControllersFromModel();
    Get.toNamed(Routes.pcpOpCabecalhoTabPage);
  }

  void _resetForm() {
    formWasChanged = false;
    dataInicioController.date = null;
    dataPrevisaoEntregaController.date = null;
    dataTerminoController.date = null;
    custoTotalPrevistoController.updateValue(0);
    custoTotalRealizadoController.updateValue(0);
    porcentoVendaController.updateValue(0);
    porcentoEstoqueController.updateValue(0);
  }

  @override
  void selectRowForEditingById(int id) {
    final model = modelList.firstWhere((m) => m.id == id);
    currentModel = model.clone();
    updateControllersFromModel();
    tabController.animateTo(0);
    Get.toNamed(Routes.pcpOpCabecalhoTabPage);
  }

  _configureChildrenControllers() {
    //Itens
		Get.put<PcpOpDetalheController>(PcpOpDetalheController()); 

    //Instruções
		Get.put<PcpInstrucaoOpController>(PcpInstrucaoOpController()); 

  }
	
	_releaseChildrenControllers() {
    //Itens
		Get.delete<PcpOpDetalheController>(); 

    //Instruções
		Get.delete<PcpInstrucaoOpController>(); 

	}
  
  void updateControllersFromModel() {
    dataInicioController.date = currentModel.dataInicio;
    dataPrevisaoEntregaController.date = currentModel.dataPrevisaoEntrega;
    dataTerminoController.date = currentModel.dataTermino;
    custoTotalPrevistoController.updateValue(currentModel.custoTotalPrevisto ?? 0);
    custoTotalRealizadoController.updateValue(currentModel.custoTotalRealizado ?? 0);
    porcentoVendaController.updateValue(currentModel.porcentoVenda ?? 0);
    porcentoEstoqueController.updateValue(currentModel.porcentoEstoque ?? 0);

    formWasChanged = false;
    _updateChildrenControllersFromModel();
  }

  void _updateChildrenControllersFromModel() {
    //Itens
		final pcpOpDetalheController = Get.find<PcpOpDetalheController>(); 
		pcpOpDetalheController.userMadeChanges = false; 

    //Instruções
		final pcpInstrucaoOpController = Get.find<PcpInstrucaoOpController>(); 
		pcpInstrucaoOpController.userMadeChanges = false; 

  }

  @override
  Future<void> save() async {
    if (!validateCurrentForm()) return;
    if (validateForms()) {
      if (userMadeChanges()) {
        final existingIndex = modelList.indexWhere((m) => m.id == currentModel.id);

        if (existingIndex >= 0) {
          modelList[existingIndex] = currentModel.clone();
        }

        final result = await repository.save(pcpOpCabecalhoModel: currentModel);
        if (result == null) return;

        if (existingIndex >= 0) {
          modelList[existingIndex] = result;
        } else {
          modelList.insert(0, result);
        }

        if (!GetPlatform.isMobile) {
          updateGridRow(result);
        }

        Get.back(result: true);
      } else {
        Get.back();
      }
    } 
  }


  List<Tab> tabItems = [
    Tab( 
			icon: Icon(iconDataList[Random().nextInt(10)]), 
			text: 'Ordem de Produção', 
		),
    Tab( 
			icon: Icon(iconDataList[Random().nextInt(10)]), 
			text: 'Itens', 
		),
    Tab( 
			icon: Icon(iconDataList[Random().nextInt(10)]), 
			text: 'Instruções', 
		),
  ];

  List<Widget> tabPages() {
    return [
      PcpOpCabecalhoEditPage(),
      const PcpOpDetalheListPage(),
      const PcpInstrucaoOpListPage(),
    ];
  }

  @override
  void preventDataLoss() {
    if (userMadeChanges()) {
      showQuestionDialog('message_data_loss'.tr, () { 
        Get.back(); 
      });
    } else {
      Get.back();
    }
  }  

  bool userMadeChanges() {
    return
    formWasChanged 
    || 
		Get.find<PcpOpDetalheController>().userMadeChanges
    || 
		Get.find<PcpInstrucaoOpController>().userMadeChanges
    ;
  }

  void tabChange(int index) {
    validateCurrentForm();
  }

  bool validateCurrentForm() {
    return true;
  }

  bool validateForms() {
    return true;
  }

  @override
  void onInit() {
    super.onInit();
    tabController = TabController(vsync: this, length: tabItems.length);
    _configureChildrenControllers();
  }
	
  @override
  void onClose() {
    tabController.dispose();
    dataInicioController.dispose();
    dataPrevisaoEntregaController.dispose();
    dataTerminoController.dispose();
    custoTotalPrevistoController.dispose();
    custoTotalRealizadoController.dispose();
    porcentoVendaController.dispose();
    porcentoEstoqueController.dispose();
    _releaseChildrenControllers();
    super.onClose();
  }	
}