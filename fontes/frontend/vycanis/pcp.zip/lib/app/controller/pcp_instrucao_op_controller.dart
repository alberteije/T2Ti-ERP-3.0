import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:pluto_grid/pluto_grid.dart';
import 'package:pcp/app/routes/app_routes.dart';

import 'package:pcp/app/page/page_imports.dart';
import 'package:pcp/app/page/shared_widget/message_dialog.dart';
import 'package:pcp/app/page/grid_columns/grid_columns_imports.dart';
import 'package:pcp/app/controller/controller_imports.dart';
import 'package:pcp/app/data/model/model_imports.dart';

class PcpInstrucaoOpController extends ControllerBase<PcpInstrucaoOpModel, void> {

  PcpInstrucaoOpController() : super(repository: null) {
    dbColumns = PcpInstrucaoOpModel.dbColumns;
    aliasColumns = PcpInstrucaoOpModel.aliasColumns;
    gridColumns = pcpInstrucaoOpGridColumns();
    functionName = "pcp_instrucao_op";
    screenTitle = "Instruções";
  }

  final _pcpInstrucaoOpModel = PcpInstrucaoOpModel().obs;
  PcpInstrucaoOpModel get pcpInstrucaoOpModel => _pcpInstrucaoOpModel.value;
  set pcpInstrucaoOpModel(value) => _pcpInstrucaoOpModel.value = value ?? PcpInstrucaoOpModel();

  List<PcpInstrucaoOpModel> get pcpInstrucaoOpModelList => Get.find<PcpOpCabecalhoController>().currentModel.pcpInstrucaoOpModelList ?? [];

  final _userMadeChanges = false.obs;
  get userMadeChanges => _userMadeChanges.value;
  set userMadeChanges(value) => _userMadeChanges.value = value;

  final _formWasChangedDetail = false.obs;
  bool get formWasChangedDetail => _formWasChangedDetail.value;
  set formWasChangedDetail(value) => _formWasChangedDetail.value = value;

  late PlutoGridStateManager _plutoGridStateManager;
  @override
  PlutoGridStateManager get plutoGridStateManager => _plutoGridStateManager;
  @override
  set plutoGridStateManager(value) => _plutoGridStateManager = value;

  final pcpInstrucaoOpScaffoldKey = GlobalKey<ScaffoldState>();
  final pcpInstrucaoOpFormKey = GlobalKey<FormState>();

  @override
  PcpInstrucaoOpModel createNewModel() => PcpInstrucaoOpModel();

  @override
  final standardFieldForFilter = PcpInstrucaoOpModel.aliasColumns[PcpInstrucaoOpModel.dbColumns.indexOf('id')];

  final pcpInstrucaoModelController = TextEditingController();

  final Map<String, dynamic> mobileConfig = {
    'primaryColumns': [],
    'secondaryColumns': [],
  };

  List<Map<String, dynamic>> get mobileItems {
    return modelList.map((pcpInstrucaoOp) => pcpInstrucaoOp.toJson).toList();
  }

  @override
  List<PlutoRow> plutoRows() => List<PlutoRow>.from(pcpInstrucaoOpModelList.map((model) => model.toPlutoRow()));

  @override
  Future<void> getList({Filter? filter}) async {}

  @override
  void prepareForInsert() {
    isNewRecord = true;
    pcpInstrucaoOpModel = createNewModel();
    _resetForm();
    Get.to(() => PcpInstrucaoOpEditPage());
  }

  void _resetForm() {
    formWasChangedDetail = false;
    pcpInstrucaoModelController.text = '';
  }

  @override
  void selectRowForEditing(PlutoRow? row) async {
    if (row == null) {
      showInfoSnackBar(message: 'message_select_one_to_edited'.tr);
      return;
    }

    selectRowForEditingByTempId(row.cells['tempId']?.value);
  }

  @override
  void selectRowForEditingById(int id) {}

  void selectRowForEditingByTempId(String tempId) {
		isNewRecord = false;
    final model = pcpInstrucaoOpModelList.firstWhere((m) => m.tempId == tempId);
    pcpInstrucaoOpModel = model.clone();
		pcpInstrucaoOpModel.tempId = model.tempId;
    updateControllersFromModel();
    Get.to(() => PcpInstrucaoOpEditPage());
  }

  void updateControllersFromModel() {
    pcpInstrucaoModelController.text = pcpInstrucaoOpModel.pcpInstrucaoModel?.descricao?.toString() ?? '';
    formWasChangedDetail = false;
  }

  @override
  Future<void> save() async {
    if (!pcpInstrucaoOpFormKey.currentState!.validate()) {
      showErrorSnackBar(message: 'validator_form_message'.tr);
      return;
    }

    if (formWasChangedDetail) {
      if (isNewRecord) {
        pcpInstrucaoOpModelList.insert(0, pcpInstrucaoOpModel.clone());
      } else {
        final index = pcpInstrucaoOpModelList.indexWhere((m) => m.tempId == pcpInstrucaoOpModel.tempId);
        if (index >= 0) {
          pcpInstrucaoOpModelList[index] = pcpInstrucaoOpModel.clone();
        }
      }

      userMadeChanges = true;
      loadData();
      Get.back(result: true);
    } else {
      Get.back();
    }
  }

  Future callPcpInstrucaoLookup() async { 
		final lookupController = Get.find<LookupController>(); 
		lookupController.refreshItems(standardValue: '%'); 
		lookupController.title = '${'lookup_page_title'.tr} [Instrucao]'; 
		lookupController.route = '/pcp-instrucao/'; 
		lookupController.gridColumns = pcpInstrucaoGridColumns(isForLookup: true); 
		lookupController.aliasColumns = PcpInstrucaoModel.aliasColumns; 
		lookupController.dbColumns = PcpInstrucaoModel.dbColumns; 
		lookupController.standardColumn = PcpInstrucaoModel.aliasColumns[PcpInstrucaoModel.dbColumns.indexOf('descricao')]; 

		final plutoRowResult = await Get.toNamed(Routes.lookupPage); 
		if (plutoRowResult != null) { 
			pcpInstrucaoOpModel.idPcpInstrucao = plutoRowResult.cells['id']!.value; 
			pcpInstrucaoOpModel.pcpInstrucaoModel = PcpInstrucaoModel.fromPlutoRow(plutoRowResult); 
			pcpInstrucaoModelController.text = pcpInstrucaoOpModel.pcpInstrucaoModel?.descricao ?? ''; 
			formWasChangedDetail = true; 
		}
	}


  @override
  Future deleteSelected() async {
    final currentRow = plutoGridStateManager.currentRow;
    if (currentRow == null) {
      showInfoSnackBar(message: 'message_select_one_to_delete'.tr);
      return null;
    }
    showDeleteDialog(() async {
      final id = currentRow.cells['id']?.value;
      final tempId = currentRow.cells['tempId']?.value;
      pcpInstrucaoOpModelList.removeWhere((model) => (id != 0 && model.id == id) || (id == 0 && model.tempId == tempId));
      plutoGridStateManager.removeCurrentRow();
      userMadeChanges = true;
    });
  }

  @override
  void preventDataLoss() {
    if (formWasChangedDetail) {
      showQuestionDialog('message_data_loss'.tr, () => Get.back());
    } else {
      formWasChangedDetail = false;
      Get.back();
    }
  }

  @override
  void onClose() {
    pcpInstrucaoModelController.dispose();
  }

}