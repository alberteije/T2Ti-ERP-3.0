import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:pluto_grid/pluto_grid.dart';
import 'package:pcp/app/routes/app_routes.dart';

import 'package:pcp/app/page/page_imports.dart';
import 'package:pcp/app/page/shared_widget/message_dialog.dart';
import 'package:pcp/app/page/grid_columns/grid_columns_imports.dart';
import 'package:pcp/app/controller/controller_imports.dart';
import 'package:pcp/app/data/model/model_imports.dart';

class PcpServicoColaboradorController extends ControllerBase<PcpServicoColaboradorModel, void> {

  PcpServicoColaboradorController() : super(repository: null) {
    dbColumns = PcpServicoColaboradorModel.dbColumns;
    aliasColumns = PcpServicoColaboradorModel.aliasColumns;
    gridColumns = pcpServicoColaboradorGridColumns();
    functionName = "pcp_servico_colaborador";
    screenTitle = "Colaboradores";
  }

  final _pcpServicoColaboradorModel = PcpServicoColaboradorModel().obs;
  PcpServicoColaboradorModel get pcpServicoColaboradorModel => _pcpServicoColaboradorModel.value;
  set pcpServicoColaboradorModel(value) => _pcpServicoColaboradorModel.value = value ?? PcpServicoColaboradorModel();

  List<PcpServicoColaboradorModel> get pcpServicoColaboradorModelList => Get.find<PcpServicoController>().pcpServicoModel.pcpServicoColaboradorModelList ?? [];

  final _userMadeChanges = false.obs;
  get userMadeChanges => _userMadeChanges.value;
  set userMadeChanges(value) => _userMadeChanges.value = value;

  final _formWasChangedDetail = false.obs;
  bool get formWasChangedDetail => _formWasChangedDetail.value;
  set formWasChangedDetail(value) => _formWasChangedDetail.value = value;

  late PlutoGridStateManager _plutoGridStateManager;
  @override
  PlutoGridStateManager get plutoGridStateManager => _plutoGridStateManager;
  @override
  set plutoGridStateManager(value) => _plutoGridStateManager = value;

  final pcpServicoColaboradorScaffoldKey = GlobalKey<ScaffoldState>();
  final pcpServicoColaboradorFormKey = GlobalKey<FormState>();

  @override
  PcpServicoColaboradorModel createNewModel() => PcpServicoColaboradorModel();

  @override
  final standardFieldForFilter = PcpServicoColaboradorModel.aliasColumns[PcpServicoColaboradorModel.dbColumns.indexOf('id')];

  final viewPessoaColaboradorModelController = TextEditingController();

  final Map<String, dynamic> mobileConfig = {
    'primaryColumns': [],
    'secondaryColumns': [],
  };

  List<Map<String, dynamic>> get mobileItems {
    return modelList.map((pcpServicoColaborador) => pcpServicoColaborador.toJson).toList();
  }

  @override
  List<PlutoRow> plutoRows() => List<PlutoRow>.from(pcpServicoColaboradorModelList.map((model) => model.toPlutoRow()));

  @override
  Future<void> getList({Filter? filter}) async {}

  @override
  void prepareForInsert() {
    isNewRecord = true;
    pcpServicoColaboradorModel = createNewModel();
    _resetForm();
    Get.to(() => PcpServicoColaboradorEditPage());
  }

  void _resetForm() {
    formWasChangedDetail = false;
    viewPessoaColaboradorModelController.text = '';
  }

  @override
  void selectRowForEditing(PlutoRow? row) async {
    if (row == null) {
      showInfoSnackBar(message: 'message_select_one_to_edited'.tr);
      return;
    }

    selectRowForEditingByTempId(row.cells['tempId']?.value);
  }

  @override
  void selectRowForEditingById(int id) {}

  void selectRowForEditingByTempId(String tempId) {
		isNewRecord = false;
    final model = pcpServicoColaboradorModelList.firstWhere((m) => m.tempId == tempId);
    pcpServicoColaboradorModel = model.clone();
		pcpServicoColaboradorModel.tempId = model.tempId;
    updateControllersFromModel();
    Get.to(() => PcpServicoColaboradorEditPage());
  }

  void updateControllersFromModel() {
    viewPessoaColaboradorModelController.text = pcpServicoColaboradorModel.viewPessoaColaboradorModel?.nome?.toString() ?? '';
    formWasChangedDetail = false;
  }

  @override
  Future<void> save() async {
    if (!pcpServicoColaboradorFormKey.currentState!.validate()) {
      showErrorSnackBar(message: 'validator_form_message'.tr);
      return;
    }

    if (formWasChangedDetail) {
      if (isNewRecord) {
        pcpServicoColaboradorModelList.insert(0, pcpServicoColaboradorModel.clone());
      } else {
        final index = pcpServicoColaboradorModelList.indexWhere((m) => m.tempId == pcpServicoColaboradorModel.tempId);
        if (index >= 0) {
          pcpServicoColaboradorModelList[index] = pcpServicoColaboradorModel.clone();
        }
      }

      userMadeChanges = true;
      loadData();
      Get.back(result: true);
    } else {
      Get.back();
    }
  }

  Future callViewPessoaColaboradorLookup() async { 
		final lookupController = Get.find<LookupController>(); 
		lookupController.refreshItems(standardValue: '%'); 
		lookupController.title = '${'lookup_page_title'.tr} [Colaborador]'; 
		lookupController.route = '/view-pessoa-colaborador/'; 
		lookupController.gridColumns = viewPessoaColaboradorGridColumns(isForLookup: true); 
		lookupController.aliasColumns = ViewPessoaColaboradorModel.aliasColumns; 
		lookupController.dbColumns = ViewPessoaColaboradorModel.dbColumns; 
		lookupController.standardColumn = ViewPessoaColaboradorModel.aliasColumns[ViewPessoaColaboradorModel.dbColumns.indexOf('nome')]; 

		final plutoRowResult = await Get.toNamed(Routes.lookupPage); 
		if (plutoRowResult != null) { 
			pcpServicoColaboradorModel.idColaborador = plutoRowResult.cells['id']!.value; 
			pcpServicoColaboradorModel.viewPessoaColaboradorModel = ViewPessoaColaboradorModel.fromPlutoRow(plutoRowResult); 
			viewPessoaColaboradorModelController.text = pcpServicoColaboradorModel.viewPessoaColaboradorModel?.nome ?? ''; 
			formWasChangedDetail = true; 
		}
	}


  @override
  Future deleteSelected() async {
    final currentRow = plutoGridStateManager.currentRow;
    if (currentRow == null) {
      showInfoSnackBar(message: 'message_select_one_to_delete'.tr);
      return null;
    }
    showDeleteDialog(() async {
      final id = currentRow.cells['id']?.value;
      final tempId = currentRow.cells['tempId']?.value;
      pcpServicoColaboradorModelList.removeWhere((model) => (id != 0 && model.id == id) || (id == 0 && model.tempId == tempId));
      plutoGridStateManager.removeCurrentRow();
      userMadeChanges = true;
    });
  }

  @override
  void preventDataLoss() {
    if (formWasChangedDetail) {
      showQuestionDialog('message_data_loss'.tr, () => Get.back());
    } else {
      formWasChangedDetail = false;
      Get.back();
    }
  }

  @override
  void onClose() {
    viewPessoaColaboradorModelController.dispose();
  }

}