import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:pluto_grid/pluto_grid.dart';
import 'package:extended_masked_text/extended_masked_text.dart';
import 'package:pcp/app/routes/app_routes.dart';

import 'package:pcp/app/page/page_imports.dart';
import 'package:pcp/app/page/shared_widget/message_dialog.dart';
import 'package:pcp/app/page/grid_columns/grid_columns_imports.dart';
import 'package:pcp/app/controller/controller_imports.dart';
import 'package:pcp/app/data/model/model_imports.dart';

class PcpOpDetalheController extends ControllerBase<PcpOpDetalheModel, void> {

  PcpOpDetalheController() : super(repository: null) {
    dbColumns = PcpOpDetalheModel.dbColumns;
    aliasColumns = PcpOpDetalheModel.aliasColumns;
    gridColumns = pcpOpDetalheGridColumns();
    functionName = "pcp_op_detalhe";
    screenTitle = "Itens";
  }

  final _pcpOpDetalheModel = PcpOpDetalheModel().obs;
  PcpOpDetalheModel get pcpOpDetalheModel => _pcpOpDetalheModel.value;
  set pcpOpDetalheModel(value) => _pcpOpDetalheModel.value = value ?? PcpOpDetalheModel();

  List<PcpOpDetalheModel> get pcpOpDetalheModelList => Get.find<PcpOpCabecalhoController>().currentModel.pcpOpDetalheModelList ?? [];

  final _userMadeChanges = false.obs;
  get userMadeChanges => _userMadeChanges.value;
  set userMadeChanges(value) => _userMadeChanges.value = value;

  final _formWasChangedDetail = false.obs;
  bool get formWasChangedDetail => _formWasChangedDetail.value;
  set formWasChangedDetail(value) => _formWasChangedDetail.value = value;

  late PlutoGridStateManager _plutoGridStateManager;
  @override
  PlutoGridStateManager get plutoGridStateManager => _plutoGridStateManager;
  @override
  set plutoGridStateManager(value) => _plutoGridStateManager = value;

  final pcpOpDetalheScaffoldKey = GlobalKey<ScaffoldState>();
  final pcpOpDetalheFormKey = GlobalKey<FormState>();

  @override
  PcpOpDetalheModel createNewModel() => PcpOpDetalheModel();

  @override
  final standardFieldForFilter = PcpOpDetalheModel.aliasColumns[PcpOpDetalheModel.dbColumns.indexOf('quantidade_produzir')];

  final produtoModelController = TextEditingController();
  final quantidadeProduzirController = MoneyMaskedTextController();
  final quantidadeProduzidaController = MoneyMaskedTextController();
  final quantidadeEntregueController = MoneyMaskedTextController();
  final custoPrevistoController = MoneyMaskedTextController();
  final custoRealizadoController = MoneyMaskedTextController();

  final Map<String, dynamic> mobileConfig = {
    'primaryColumns': ['quantidade_produzir'],
    'secondaryColumns': ['quantidade_produzida'],
  };

  List<Map<String, dynamic>> get mobileItems {
    return modelList.map((pcpOpDetalhe) => pcpOpDetalhe.toJson).toList();
  }

  @override
  List<PlutoRow> plutoRows() => List<PlutoRow>.from(pcpOpDetalheModelList.map((model) => model.toPlutoRow()));

  @override
  Future<void> getList({Filter? filter}) async {}

  @override
  void prepareForInsert() {
    isNewRecord = true;
    pcpOpDetalheModel = createNewModel();
    _resetForm();
    Get.to(() => PcpOpDetalheEditPage());
  }

  void _resetForm() {
    formWasChangedDetail = false;
    produtoModelController.text = '';
    quantidadeProduzirController.updateValue(0);
    quantidadeProduzidaController.updateValue(0);
    quantidadeEntregueController.updateValue(0);
    custoPrevistoController.updateValue(0);
    custoRealizadoController.updateValue(0);
  }

  @override
  void selectRowForEditing(PlutoRow? row) async {
    if (row == null) {
      showInfoSnackBar(message: 'message_select_one_to_edited'.tr);
      return;
    }

    selectRowForEditingByTempId(row.cells['tempId']?.value);
  }

  @override
  void selectRowForEditingById(int id) {}

  void selectRowForEditingByTempId(String tempId) {
		isNewRecord = false;
    final model = pcpOpDetalheModelList.firstWhere((m) => m.tempId == tempId);
    pcpOpDetalheModel = model.clone();
		pcpOpDetalheModel.tempId = model.tempId;
    updateControllersFromModel();
    Get.to(() => PcpOpDetalheEditPage());
  }

  _configureChildrenControllers() {
    //Serviços
		Get.put<PcpServicoController>(PcpServicoController());
  }

  _releaseChildrenControllers() {
    //Serviços
		Get.delete<PcpServicoController>();
  }

  void updateControllersFromModel() {
    produtoModelController.text = pcpOpDetalheModel.produtoModel?.nome?.toString() ?? '';
    quantidadeProduzirController.updateValue(pcpOpDetalheModel.quantidadeProduzir ?? 0);
    quantidadeProduzidaController.updateValue(pcpOpDetalheModel.quantidadeProduzida ?? 0);
    quantidadeEntregueController.updateValue(pcpOpDetalheModel.quantidadeEntregue ?? 0);
    custoPrevistoController.updateValue(pcpOpDetalheModel.custoPrevisto ?? 0);
    custoRealizadoController.updateValue(pcpOpDetalheModel.custoRealizado ?? 0);
    formWasChangedDetail = false;
    _updateChildrenControllersFromModel();
  }

  void _updateChildrenControllersFromModel() {
    //Serviços
		final pcpServicoController = Get.find<PcpServicoController>(); 
    pcpServicoController.updateControllersFromModel();
  }

  @override
  Future<void> save() async {
    if (!pcpOpDetalheFormKey.currentState!.validate()) {
      showErrorSnackBar(message: 'validator_form_message'.tr);
      return;
    }

    if (formWasChangedDetail) {
      if (isNewRecord) {
        pcpOpDetalheModelList.insert(0, pcpOpDetalheModel.clone());
      } else {
        final index = pcpOpDetalheModelList.indexWhere((m) => m.tempId == pcpOpDetalheModel.tempId);
        if (index >= 0) {
          pcpOpDetalheModelList[index] = pcpOpDetalheModel.clone();
        }
      }

      userMadeChanges = true;
      loadData();
      Get.back(result: true);
    } else {
      Get.back();
    }
  }

  Future callProdutoLookup() async { 
		final lookupController = Get.find<LookupController>(); 
		lookupController.refreshItems(standardValue: '%'); 
		lookupController.title = '${'lookup_page_title'.tr} [Produto]'; 
		lookupController.route = '/produto/'; 
		lookupController.gridColumns = produtoGridColumns(isForLookup: true); 
		lookupController.aliasColumns = ProdutoModel.aliasColumns; 
		lookupController.dbColumns = ProdutoModel.dbColumns; 
		lookupController.standardColumn = ProdutoModel.aliasColumns[ProdutoModel.dbColumns.indexOf('nome')]; 

		final plutoRowResult = await Get.toNamed(Routes.lookupPage); 
		if (plutoRowResult != null) { 
			pcpOpDetalheModel.idProduto = plutoRowResult.cells['id']!.value; 
			pcpOpDetalheModel.produtoModel = ProdutoModel.fromPlutoRow(plutoRowResult); 
			produtoModelController.text = pcpOpDetalheModel.produtoModel?.nome ?? ''; 
			formWasChangedDetail = true; 
		}
	}


  @override
  Future deleteSelected() async {
    final currentRow = plutoGridStateManager.currentRow;
    if (currentRow == null) {
      showInfoSnackBar(message: 'message_select_one_to_delete'.tr);
      return null;
    }
    showDeleteDialog(() async {
      final id = currentRow.cells['id']?.value;
      final tempId = currentRow.cells['tempId']?.value;
      pcpOpDetalheModelList.removeWhere((model) => (id != 0 && model.id == id) || (id == 0 && model.tempId == tempId));
      plutoGridStateManager.removeCurrentRow();
      userMadeChanges = true;
    });
  }

  void callServicoPage() {
		Get.dialog(
      const AlertDialog(
        content: PcpServicoListPage(
        ),
      ),
    );
  }

  @override
  void preventDataLoss() {
    if (formWasChangedDetail) {
      showQuestionDialog('message_data_loss'.tr, () => Get.back());
    } else {
      formWasChangedDetail = false;
      Get.back();
    }
  }

  @override
  void onInit() {
    super.onInit();
    _configureChildrenControllers();
  }

  @override
  void onClose() {
    produtoModelController.dispose();
    quantidadeProduzirController.dispose();
    quantidadeProduzidaController.dispose();
    quantidadeEntregueController.dispose();
    custoPrevistoController.dispose();
    custoRealizadoController.dispose();
    _releaseChildrenControllers();
  }

}