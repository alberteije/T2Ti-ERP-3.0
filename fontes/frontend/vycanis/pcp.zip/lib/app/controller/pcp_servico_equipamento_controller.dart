import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:pluto_grid/pluto_grid.dart';
import 'package:pcp/app/routes/app_routes.dart';

import 'package:pcp/app/page/page_imports.dart';
import 'package:pcp/app/page/shared_widget/message_dialog.dart';
import 'package:pcp/app/page/grid_columns/grid_columns_imports.dart';
import 'package:pcp/app/controller/controller_imports.dart';
import 'package:pcp/app/data/model/model_imports.dart';

class PcpServicoEquipamentoController extends ControllerBase<PcpServicoEquipamentoModel, void> {

  PcpServicoEquipamentoController() : super(repository: null) {
    dbColumns = PcpServicoEquipamentoModel.dbColumns;
    aliasColumns = PcpServicoEquipamentoModel.aliasColumns;
    gridColumns = pcpServicoEquipamentoGridColumns();
    functionName = "pcp_servico_equipamento";
    screenTitle = "Equipamentos";
  }

  final _pcpServicoEquipamentoModel = PcpServicoEquipamentoModel().obs;
  PcpServicoEquipamentoModel get pcpServicoEquipamentoModel => _pcpServicoEquipamentoModel.value;
  set pcpServicoEquipamentoModel(value) => _pcpServicoEquipamentoModel.value = value ?? PcpServicoEquipamentoModel();

  List<PcpServicoEquipamentoModel> get pcpServicoEquipamentoModelList => Get.find<PcpServicoController>().pcpServicoModel.pcpServicoEquipamentoModelList ?? [];

  final _userMadeChanges = false.obs;
  get userMadeChanges => _userMadeChanges.value;
  set userMadeChanges(value) => _userMadeChanges.value = value;

  final _formWasChangedDetail = false.obs;
  bool get formWasChangedDetail => _formWasChangedDetail.value;
  set formWasChangedDetail(value) => _formWasChangedDetail.value = value;

  late PlutoGridStateManager _plutoGridStateManager;
  @override
  PlutoGridStateManager get plutoGridStateManager => _plutoGridStateManager;
  @override
  set plutoGridStateManager(value) => _plutoGridStateManager = value;

  final pcpServicoEquipamentoScaffoldKey = GlobalKey<ScaffoldState>();
  final pcpServicoEquipamentoFormKey = GlobalKey<FormState>();

  @override
  PcpServicoEquipamentoModel createNewModel() => PcpServicoEquipamentoModel();

  @override
  final standardFieldForFilter = PcpServicoEquipamentoModel.aliasColumns[PcpServicoEquipamentoModel.dbColumns.indexOf('id')];

  final patrimBemModelController = TextEditingController();

  final Map<String, dynamic> mobileConfig = {
    'primaryColumns': [],
    'secondaryColumns': [],
  };

  List<Map<String, dynamic>> get mobileItems {
    return modelList.map((pcpServicoEquipamento) => pcpServicoEquipamento.toJson).toList();
  }

  @override
  List<PlutoRow> plutoRows() => List<PlutoRow>.from(pcpServicoEquipamentoModelList.map((model) => model.toPlutoRow()));

  @override
  Future<void> getList({Filter? filter}) async {}

  @override
  void prepareForInsert() {
    isNewRecord = true;
    pcpServicoEquipamentoModel = createNewModel();
    _resetForm();
    Get.to(() => PcpServicoEquipamentoEditPage());
  }

  void _resetForm() {
    formWasChangedDetail = false;
    patrimBemModelController.text = '';
  }

  @override
  void selectRowForEditing(PlutoRow? row) async {
    if (row == null) {
      showInfoSnackBar(message: 'message_select_one_to_edited'.tr);
      return;
    }

    selectRowForEditingByTempId(row.cells['tempId']?.value);
  }

  @override
  void selectRowForEditingById(int id) {}

  void selectRowForEditingByTempId(String tempId) {
		isNewRecord = false;
    final model = pcpServicoEquipamentoModelList.firstWhere((m) => m.tempId == tempId);
    pcpServicoEquipamentoModel = model.clone();
		pcpServicoEquipamentoModel.tempId = model.tempId;
    updateControllersFromModel();
    Get.to(() => PcpServicoEquipamentoEditPage());
  }

  void updateControllersFromModel() {
    patrimBemModelController.text = pcpServicoEquipamentoModel.patrimBemModel?.nome?.toString() ?? '';
    formWasChangedDetail = false;
  }

  @override
  Future<void> save() async {
    if (!pcpServicoEquipamentoFormKey.currentState!.validate()) {
      showErrorSnackBar(message: 'validator_form_message'.tr);
      return;
    }

    if (formWasChangedDetail) {
      if (isNewRecord) {
        pcpServicoEquipamentoModelList.insert(0, pcpServicoEquipamentoModel.clone());
      } else {
        final index = pcpServicoEquipamentoModelList.indexWhere((m) => m.tempId == pcpServicoEquipamentoModel.tempId);
        if (index >= 0) {
          pcpServicoEquipamentoModelList[index] = pcpServicoEquipamentoModel.clone();
        }
      }

      userMadeChanges = true;
      loadData();
      Get.back(result: true);
    } else {
      Get.back();
    }
  }

  Future callPatrimBemLookup() async { 
		final lookupController = Get.find<LookupController>(); 
		lookupController.refreshItems(standardValue: '%'); 
		lookupController.title = '${'lookup_page_title'.tr} [Equipamento]'; 
		lookupController.route = '/patrim-bem/'; 
		lookupController.gridColumns = patrimBemGridColumns(isForLookup: true); 
		lookupController.aliasColumns = PatrimBemModel.aliasColumns; 
		lookupController.dbColumns = PatrimBemModel.dbColumns; 
		lookupController.standardColumn = PatrimBemModel.aliasColumns[PatrimBemModel.dbColumns.indexOf('nome')]; 

		final plutoRowResult = await Get.toNamed(Routes.lookupPage); 
		if (plutoRowResult != null) { 
			pcpServicoEquipamentoModel.idPatrimBem = plutoRowResult.cells['id']!.value; 
			pcpServicoEquipamentoModel.patrimBemModel = PatrimBemModel.fromPlutoRow(plutoRowResult); 
			patrimBemModelController.text = pcpServicoEquipamentoModel.patrimBemModel?.nome ?? ''; 
			formWasChangedDetail = true; 
		}
	}


  @override
  Future deleteSelected() async {
    final currentRow = plutoGridStateManager.currentRow;
    if (currentRow == null) {
      showInfoSnackBar(message: 'message_select_one_to_delete'.tr);
      return null;
    }
    showDeleteDialog(() async {
      final id = currentRow.cells['id']?.value;
      final tempId = currentRow.cells['tempId']?.value;
      pcpServicoEquipamentoModelList.removeWhere((model) => (id != 0 && model.id == id) || (id == 0 && model.tempId == tempId));
      plutoGridStateManager.removeCurrentRow();
      userMadeChanges = true;
    });
  }

  @override
  void preventDataLoss() {
    if (formWasChangedDetail) {
      showQuestionDialog('message_data_loss'.tr, () => Get.back());
    } else {
      formWasChangedDetail = false;
      Get.back();
    }
  }

  @override
  void onClose() {
    patrimBemModelController.dispose();
  }

}