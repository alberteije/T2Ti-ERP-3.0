import 'package:flutter/material.dart';
import 'package:pcp/app/controller/pcp_instrucao_controller.dart';
import 'package:pcp/app/page/shared_page/list_page_base.dart';

class PcpInstrucaoListPage extends ListPageBase<PcpInstrucaoController> {
  const PcpInstrucaoListPage({Key? key}) : super(key: key);

  @override
  List<Map<String, dynamic>> get mobileItems => controller.mobileItems;

  @override
  Map<String, dynamic> get mobileConfig => controller.mobileConfig;

  @override
  String get standardFieldForFilter => controller.standardFieldForFilter;
}