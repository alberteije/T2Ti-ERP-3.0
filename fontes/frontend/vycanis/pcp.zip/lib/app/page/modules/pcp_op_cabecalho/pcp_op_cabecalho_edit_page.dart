import 'package:flutter/material.dart';
import 'package:flutter_bootstrap/flutter_bootstrap.dart';
import 'package:get/get.dart';
import 'package:pcp/app/controller/pcp_op_cabecalho_controller.dart';
import 'package:pcp/app/infra/infra_imports.dart';
import 'package:pcp/app/page/shared_widget/input/input_imports.dart';

class PcpOpCabecalhoEditPage extends StatelessWidget {
	PcpOpCabecalhoEditPage({Key? key}) : super(key: key);
	final pcpOpCabecalhoController = Get.find<PcpOpCabecalhoController>();

	@override
	Widget build(BuildContext context) {
			return Scaffold(
				key: pcpOpCabecalhoController.pcpOpCabecalhoScaffoldKey,
				body: SafeArea(
					top: false,
					bottom: false,
					child: Form(
						key: pcpOpCabecalhoController.pcpOpCabecalhoFormKey,
						autovalidateMode: AutovalidateMode.always,
						child: Scrollbar(
							controller: pcpOpCabecalhoController.scrollController,
							child: SingleChildScrollView(
								controller: pcpOpCabecalhoController.scrollController,
								child: BootstrapContainer(
									fluid: true,
									padding: const EdgeInsets.all(10),
									children: <Widget>[
										const Divider(
											color: Colors.transparent,
										),
										BootstrapRow(
											height: 60,
											children: <BootstrapCol>[
												BootstrapCol(
													sizes: 'col-12 col-md-4',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: InputDecorator(
															decoration: inputDecoration(
																hintText: 'Fill with the Data Inicio',
																labelText: 'Data Inicio',
																usePadding: true,
															),
															isEmpty: false,
															child: DatePickerItem(
																controller: pcpOpCabecalhoController.dataInicioController,
																firstDate: DateTime.parse('1000-01-01'),
																lastDate: DateTime.parse('5000-01-01'),
																onChanged: (DateTime? value) {
																	pcpOpCabecalhoController.currentModel.dataInicio = value;
																	pcpOpCabecalhoController.formWasChanged = true;
																},
															),
														),
													),
												),
												BootstrapCol(
													sizes: 'col-12 col-md-4',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: InputDecorator(
															decoration: inputDecoration(
																hintText: 'Fill with the Data Previsao Entrega',
																labelText: 'Data Previsao Entrega',
																usePadding: true,
															),
															isEmpty: false,
															child: DatePickerItem(
																controller: pcpOpCabecalhoController.dataPrevisaoEntregaController,
																firstDate: DateTime.parse('1000-01-01'),
																lastDate: DateTime.parse('5000-01-01'),
																onChanged: (DateTime? value) {
																	pcpOpCabecalhoController.currentModel.dataPrevisaoEntrega = value;
																	pcpOpCabecalhoController.formWasChanged = true;
																},
															),
														),
													),
												),
												BootstrapCol(
													sizes: 'col-12 col-md-4',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: InputDecorator(
															decoration: inputDecoration(
																hintText: 'Fill with the Data Termino',
																labelText: 'Data Termino',
																usePadding: true,
															),
															isEmpty: false,
															child: DatePickerItem(
																controller: pcpOpCabecalhoController.dataTerminoController,
																firstDate: DateTime.parse('1000-01-01'),
																lastDate: DateTime.parse('5000-01-01'),
																onChanged: (DateTime? value) {
																	pcpOpCabecalhoController.currentModel.dataTermino = value;
																	pcpOpCabecalhoController.formWasChanged = true;
																},
															),
														),
													),
												),
											],
										),
										const Divider(
											color: Colors.transparent,
										),
										BootstrapRow(
											height: 60,
											children: <BootstrapCol>[
												BootstrapCol(
													sizes: 'col-12 col-md-3',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: TextFormField(
															autofocus: true,
															controller: pcpOpCabecalhoController.custoTotalPrevistoController,
															decoration: inputDecoration(
																hintText: 'Informe os dados para o campo Custo Total Previsto',
																labelText: 'Custo Total Previsto',
																usePadding: true,
															),
															onSaved: (String? value) {},
															onChanged: (text) {
																pcpOpCabecalhoController.currentModel.custoTotalPrevisto = pcpOpCabecalhoController.custoTotalPrevistoController.numberValue;
																pcpOpCabecalhoController.formWasChanged = true;
															},
														),
													),
												),
												BootstrapCol(
													sizes: 'col-12 col-md-3',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: TextFormField(
															autofocus: true,
															controller: pcpOpCabecalhoController.custoTotalRealizadoController,
															decoration: inputDecoration(
																hintText: 'Informe os dados para o campo Custo Total Realizado',
																labelText: 'Custo Total Realizado',
																usePadding: true,
															),
															onSaved: (String? value) {},
															onChanged: (text) {
																pcpOpCabecalhoController.currentModel.custoTotalRealizado = pcpOpCabecalhoController.custoTotalRealizadoController.numberValue;
																pcpOpCabecalhoController.formWasChanged = true;
															},
														),
													),
												),
												BootstrapCol(
													sizes: 'col-12 col-md-3',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: TextFormField(
															autofocus: true,
															controller: pcpOpCabecalhoController.porcentoVendaController,
															decoration: inputDecoration(
																hintText: 'Informe os dados para o campo Porcento Venda',
																labelText: 'Porcento Venda',
																usePadding: true,
															),
															onSaved: (String? value) {},
															onChanged: (text) {
																pcpOpCabecalhoController.currentModel.porcentoVenda = pcpOpCabecalhoController.porcentoVendaController.numberValue;
																pcpOpCabecalhoController.formWasChanged = true;
															},
														),
													),
												),
												BootstrapCol(
													sizes: 'col-12 col-md-3',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: TextFormField(
															autofocus: true,
															controller: pcpOpCabecalhoController.porcentoEstoqueController,
															decoration: inputDecoration(
																hintText: 'Informe os dados para o campo Porcento Estoque',
																labelText: 'Porcento Estoque',
																usePadding: true,
															),
															onSaved: (String? value) {},
															onChanged: (text) {
																pcpOpCabecalhoController.currentModel.porcentoEstoque = pcpOpCabecalhoController.porcentoEstoqueController.numberValue;
																pcpOpCabecalhoController.formWasChanged = true;
															},
														),
													),
												),
											],
										),
										const Divider(
											indent: 10,
											endIndent: 10,
											thickness: 2,
										),
										BootstrapRow(
											height: 60,
											children: <BootstrapCol>[
												BootstrapCol(
													sizes: 'col-12',
													child: Text(
														'field_is_mandatory'.tr,
														style: Theme.of(context).textTheme.bodySmall,
													),
												),
											],
										),
										const SizedBox(height: 10.0),
									],
								),
							),
						),
					),
				),
			);
	}
}
