abstract class Routes{
	
	static const splashPage = '/splashPage';
	static const loginPage = '/loginPage';
	static const homePage = '/homePage';
	static const filterPage = '/filterPage';
	static const lookupPage = '/lookupPage';
  static const menuModulesPage = '/menuModulesPage';
		
	static const crmSacCabecalhoListPage = '/crmSacCabecalhoListPage'; 
	static const crmSacCabecalhoTabPage = '/crmSacCabecalhoTabPage';
	static const crmCarteiraClientePerfilListPage = '/crmCarteiraClientePerfilListPage'; 
	static const crmCarteiraClientePerfilTabPage = '/crmCarteiraClientePerfilTabPage';
	static const crmCampanhaListPage = '/crmCampanhaListPage'; 
	static const crmCampanhaTabPage = '/crmCampanhaTabPage';
	static const crmBuscasClienteListPage = '/crmBuscasClienteListPage'; 
	static const crmBuscasClienteEditPage = '/crmBuscasClienteEditPage';
	static const crmContatoListPage = '/crmContatoListPage'; 
	static const crmContatoEditPage = '/crmContatoEditPage';
	static const crmOportunidadeListPage = '/crmOportunidadeListPage'; 
	static const crmOportunidadeEditPage = '/crmOportunidadeEditPage';
	static const crmTarefaListPage = '/crmTarefaListPage'; 
	static const crmTarefaEditPage = '/crmTarefaEditPage';
}