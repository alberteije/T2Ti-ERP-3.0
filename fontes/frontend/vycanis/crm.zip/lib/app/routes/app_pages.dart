import 'package:get/get.dart';
import 'package:crm/app/page/shared_widget/shared_widget_imports.dart';
import 'package:crm/app/routes/app_routes.dart';
import 'package:crm/app/page/login/login_page.dart';
import 'package:crm/app/page/shared_page/splash_screen_page.dart';
import 'package:crm/app/bindings/bindings_imports.dart';
import 'package:crm/app/page/shared_page/shared_page_imports.dart';
import 'package:crm/app/page/page_imports.dart';

class AppPages {
	
	static final pages = [
		GetPage(name: Routes.splashPage, page:()=> const SplashScreenPage()),
		GetPage(name: Routes.loginPage, page:()=> const LoginPage(), binding: LoginBindings()),
		GetPage(name: Routes.homePage, page:()=> HomePage()),
		GetPage(name: Routes.filterPage, page:()=> const FilterPage()),
		GetPage(name: Routes.lookupPage, page:()=> const LookupPage()),
    GetPage(name: Routes.menuModulesPage, page:()=> const MenuModulesPage()),
		
		GetPage(name: Routes.crmSacCabecalhoListPage, page:()=> const CrmSacCabecalhoListPage(), binding: CrmSacCabecalhoBindings()), 
		GetPage(name: Routes.crmSacCabecalhoTabPage, page:()=> CrmSacCabecalhoTabPage()),
		GetPage(name: Routes.crmCarteiraClientePerfilListPage, page:()=> const CrmCarteiraClientePerfilListPage(), binding: CrmCarteiraClientePerfilBindings()), 
		GetPage(name: Routes.crmCarteiraClientePerfilTabPage, page:()=> CrmCarteiraClientePerfilTabPage()),
		GetPage(name: Routes.crmCampanhaListPage, page:()=> const CrmCampanhaListPage(), binding: CrmCampanhaBindings()), 
		GetPage(name: Routes.crmCampanhaTabPage, page:()=> CrmCampanhaTabPage()),
		GetPage(name: Routes.crmBuscasClienteListPage, page:()=> const CrmBuscasClienteListPage(), binding: CrmBuscasClienteBindings()), 
		GetPage(name: Routes.crmBuscasClienteEditPage, page:()=> CrmBuscasClienteEditPage()),
		GetPage(name: Routes.crmContatoListPage, page:()=> const CrmContatoListPage(), binding: CrmContatoBindings()), 
		GetPage(name: Routes.crmContatoEditPage, page:()=> CrmContatoEditPage()),
		GetPage(name: Routes.crmOportunidadeListPage, page:()=> const CrmOportunidadeListPage(), binding: CrmOportunidadeBindings()), 
		GetPage(name: Routes.crmOportunidadeEditPage, page:()=> CrmOportunidadeEditPage()),
		GetPage(name: Routes.crmTarefaListPage, page:()=> const CrmTarefaListPage(), binding: CrmTarefaBindings()), 
		GetPage(name: Routes.crmTarefaEditPage, page:()=> CrmTarefaEditPage()),
	];
}