import 'package:flutter/material.dart';
import 'package:flutter_bootstrap/flutter_bootstrap.dart';
import 'package:get/get.dart';
import 'package:crm/app/page/shared_widget/shared_widget_imports.dart';
import 'package:crm/app/data/domain/domain_imports.dart';
import 'package:crm/app/controller/crm_campanha_cliente_controller.dart';
import 'package:crm/app/infra/infra_imports.dart';
import 'package:crm/app/page/shared_widget/input/input_imports.dart';

class CrmCampanhaClienteEditPage extends StatelessWidget {
	CrmCampanhaClienteEditPage({Key? key}) : super(key: key);
	final crmCampanhaClienteController = Get.find<CrmCampanhaClienteController>();

	@override
	Widget build(BuildContext context) {
			return Scaffold(
				key: crmCampanhaClienteController.crmCampanhaClienteScaffoldKey,	
				appBar: AppBar(
					automaticallyImplyLeading: false,
					title: Text('${ crmCampanhaClienteController.screenTitle } - ${ crmCampanhaClienteController.isNewRecord ? 'inserting'.tr : 'editing'.tr }',),
					actions: [
						saveButton(onPressed: crmCampanhaClienteController.save),
						cancelAndExitButton(onPressed: crmCampanhaClienteController.preventDataLoss),
					]
				),
				body: SafeArea(
					top: false,
					bottom: false,
					child: Form(
						key: crmCampanhaClienteController.crmCampanhaClienteFormKey,
						autovalidateMode: AutovalidateMode.always,
						child: Scrollbar(
							controller: crmCampanhaClienteController.scrollController,
							child: SingleChildScrollView(
								controller: crmCampanhaClienteController.scrollController,
								child: BootstrapContainer(
									fluid: true,
									padding: const EdgeInsets.all(10.0),
									children: <Widget>[
										const Divider(
											color: Colors.transparent,
										),
										BootstrapRow(
											height: 60,
											children: <BootstrapCol>[
												BootstrapCol(
													sizes: 'col-12',
													child: Row(
														children: <Widget>[
															Expanded(
																flex: 1,
																child: SizedBox(
																	child: TextFormField(
																		controller: crmCampanhaClienteController.viewPessoaClienteModelController,
																		validator: ValidateFormField.validateMandatory,
																		readOnly: true,
																		decoration: inputDecoration(
																			hintText: 'Informe os dados para o campo Cliente',
																			labelText: 'Cliente *',
																			usePadding: true,
																		),
																		onSaved: (String? value) {},
																		onChanged: (text) {},
																	),
																),
															),
															Expanded(
																flex: 0,
																child: lookupButton(onPressed: crmCampanhaClienteController.callViewPessoaClienteLookup),
															),
														],
													),
												),
											],
										),
										const Divider(
											color: Colors.transparent,
										),
										BootstrapRow(
											height: 60,
											children: <BootstrapCol>[
												BootstrapCol(
													sizes: 'col-12 col-md-6',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: InputDecorator(
															decoration: inputDecoration(
																hintText: 'Informe os dados para o campo Data Inscricao',
																labelText: 'Data Inscricao',
																usePadding: true,
															),
															isEmpty: false,
															child: DatePickerItem(
																controller: crmCampanhaClienteController.dataInscricaoController,
																firstDate: DateTime.parse('1000-01-01'),
																lastDate: DateTime.parse('5000-01-01'),
																onChanged: (DateTime? value) {
																	crmCampanhaClienteController.crmCampanhaClienteModel.dataInscricao = value;
																	crmCampanhaClienteController.formWasChangedDetail = true;
																},
															),
														),
													),
												),
												BootstrapCol(
													sizes: 'col-12 col-md-6',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: CustomDropdownButton(
															controller: crmCampanhaClienteController.statusController,
															labelText: 'Status',
															hintText: 'Informe os dados para o campo Status',
															items: CrmCampanhaClienteDomain.statusListDropdown,
															onChanged: (dynamic newValue) {
																crmCampanhaClienteController.crmCampanhaClienteModel.status = newValue;
																crmCampanhaClienteController.formWasChangedDetail = true;
															},
														),
													),
												),
											],
										),
										const Divider(
											color: Colors.transparent,
										),
										BootstrapRow(
											height: 60,
											children: <BootstrapCol>[
												BootstrapCol(
													sizes: 'col-12',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: TextFormField(
															autofocus: true,
															maxLines: 3,
															controller: crmCampanhaClienteController.observacoesController,
															decoration: inputDecoration(
																hintText: 'Informe os dados para o campo Observacoes',
																labelText: 'Observacoes',
																usePadding: true,
															),
															onSaved: (String? value) {},
															onChanged: (text) {
																crmCampanhaClienteController.crmCampanhaClienteModel.observacoes = text;
																crmCampanhaClienteController.formWasChangedDetail = true;
															},
														),
													),
												),
											],
										),
										const Divider(
											indent: 10,
											endIndent: 10,
											thickness: 2,
										),
										BootstrapRow(
											height: 60,
											children: <BootstrapCol>[
												BootstrapCol(
													sizes: 'col-12',
													child: Text(
														'field_is_mandatory'.tr,
														style: Theme.of(context).textTheme.bodySmall,
													),
												),
											],
										),
										const SizedBox(height: 10.0),
									],
								),
							),
						),
					),
				),
			);
	}
}
