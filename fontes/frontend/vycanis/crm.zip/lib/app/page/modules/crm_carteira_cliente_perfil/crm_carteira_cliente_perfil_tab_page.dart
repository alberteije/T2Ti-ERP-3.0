import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:buttons_tabbar/buttons_tabbar.dart';
import 'package:get/get.dart';
import 'package:crm/app/controller/crm_carteira_cliente_perfil_controller.dart';
import 'package:crm/app/page/shared_widget/shared_widget_imports.dart';

class CrmCarteiraClientePerfilTabPage extends StatelessWidget {
  CrmCarteiraClientePerfilTabPage({Key? key}) : super(key: key);
  final crmCarteiraClientePerfilController = Get.find<CrmCarteiraClientePerfilController>();

  @override
  Widget build(BuildContext context) {
		return KeyboardListener(
			autofocus: false,
			focusNode: FocusNode(),
			onKeyEvent: (event) {
				if (event.logicalKey == LogicalKeyboardKey.escape) {
          crmCarteiraClientePerfilController.preventDataLoss();
        }
      },
      child: Scaffold(
        key: crmCarteiraClientePerfilController.crmCarteiraClientePerfilTabPageScaffoldKey,
        appBar: AppBar(
					automaticallyImplyLeading: false, 
					title: Text('${ crmCarteiraClientePerfilController.screenTitle } - ${ crmCarteiraClientePerfilController.isNewRecord ? 'inserting'.tr : 'editing'.tr }',),
					actions: [
						saveButton(onPressed: crmCarteiraClientePerfilController.save),
						cancelAndExitButton(onPressed: crmCarteiraClientePerfilController.preventDataLoss),
					]
				),
        body: SafeArea(
          child: Column(
            children: <Widget>[
              Expanded(
                child: TabBarView(
                  controller: crmCarteiraClientePerfilController.tabController,
                  children: crmCarteiraClientePerfilController.tabPages(),
                ),
              ),
              ButtonsTabBar(
                controller: crmCarteiraClientePerfilController.tabController,
                onTap: crmCarteiraClientePerfilController.tabChange,
                height: 40,
                elevation: 2,
                borderWidth: 0,
                backgroundColor: Colors.blueGrey,
                unselectedBackgroundColor: Colors.grey[300],
                unselectedLabelStyle: const TextStyle(color: Colors.black),
                labelStyle: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold),
                tabs: crmCarteiraClientePerfilController.tabItems,
              ),
              const SizedBox(
                height: 10,
              ),
            ],
          ),
        ),
      ),
    );
  }
}
