import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_bootstrap/flutter_bootstrap.dart';
import 'package:get/get.dart';
import 'package:crm/app/page/shared_widget/shared_widget_imports.dart';
import 'package:crm/app/data/domain/domain_imports.dart';
import 'package:crm/app/controller/crm_oportunidade_controller.dart';
import 'package:crm/app/infra/infra_imports.dart';
import 'package:crm/app/page/shared_widget/input/input_imports.dart';

class CrmOportunidadeEditPage extends StatelessWidget {
	CrmOportunidadeEditPage({Key? key}) : super(key: key);
	final crmOportunidadeController = Get.find<CrmOportunidadeController>();

	@override
	Widget build(BuildContext context) {
		return KeyboardListener(
			autofocus: false,
			focusNode: FocusNode(),
			onKeyEvent: (event) {
				if (event.logicalKey == LogicalKeyboardKey.escape) {
					crmOportunidadeController.preventDataLoss();
				}
			},
			child: Scaffold(
				key: crmOportunidadeController.scaffoldKey,
				appBar: AppBar(
					automaticallyImplyLeading: false,
					title: Text('${ crmOportunidadeController.screenTitle } - ${ crmOportunidadeController.isNewRecord ? 'inserting'.tr : 'editing'.tr }',),
					actions: [
						saveButton(onPressed: crmOportunidadeController.save),
						cancelAndExitButton(onPressed: crmOportunidadeController.preventDataLoss),
					]
				),
				body: SafeArea(
					top: false,
					bottom: false,
					child: Form(
						key: crmOportunidadeController.formKey,
						autovalidateMode: AutovalidateMode.always,
						child: Scrollbar(
							controller: crmOportunidadeController.scrollController,
							child: SingleChildScrollView(
								controller: crmOportunidadeController.scrollController,
								child: BootstrapContainer(
									fluid: true,
									padding: const EdgeInsets.fromLTRB(10.0, 10.0, 10.0, 10.0),
									children: <Widget>[
										const Divider(
											color: Colors.transparent,
										),
										BootstrapRow(
											height: 60,
											children: <BootstrapCol>[
												BootstrapCol(
													sizes: 'col-12',
													child: Row(
														children: <Widget>[
															Expanded(
																flex: 1,
																child: SizedBox(
																	child: TextFormField(
																		controller: crmOportunidadeController.viewPessoaClienteModelController,
																		validator: ValidateFormField.validateMandatory,
																		readOnly: true,
																		decoration: inputDecoration(
																			hintText: 'Informe os dados para o campo Id Cliente',
																			labelText: 'Cliente *',
																			usePadding: true,
																		),
																		onSaved: (String? value) {},
																		onChanged: (text) {},
																	),
																),
															),
															Expanded(
																flex: 0,
																child: lookupButton(onPressed: crmOportunidadeController.callViewPessoaClienteLookup),
															),
														],
													),
												),
											],
										),
										const Divider(
											color: Colors.transparent,
										),
										BootstrapRow(
											height: 60,
											children: <BootstrapCol>[
												BootstrapCol(
													sizes: 'col-12',
													child: Row(
														children: <Widget>[
															Expanded(
																flex: 1,
																child: SizedBox(
																	child: TextFormField(
																		controller: crmOportunidadeController.viewPessoaColaboradorModelController,
																		validator: ValidateFormField.validateMandatory,
																		readOnly: true,
																		decoration: inputDecoration(
																			hintText: 'Importar Colaborador',
																			labelText: 'Colaborador *',
																			usePadding: true,
																		),
																		onSaved: (String? value) {},
																		onChanged: (text) {},
																	),
																),
															),
															Expanded(
																flex: 0,
																child: lookupButton(onPressed: crmOportunidadeController.callViewPessoaColaboradorLookup),
															),
														],
													),
												),
											],
										),
										const Divider(
											color: Colors.transparent,
										),
										BootstrapRow(
											height: 60,
											children: <BootstrapCol>[
												BootstrapCol(
													sizes: 'col-12',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: TextFormField(
															autofocus: true,
															maxLength: 200,
															controller: crmOportunidadeController.tituloController,
															decoration: inputDecoration(
																hintText: 'Informe os dados para o campo Titulo',
																labelText: 'Titulo',
																usePadding: true,
															),
															onSaved: (String? value) {},
															onChanged: (text) {
																crmOportunidadeController.currentModel.titulo = text;
																crmOportunidadeController.formWasChanged = true;
															},
														),
													),
												),
											],
										),
										const Divider(
											color: Colors.transparent,
										),
										BootstrapRow(
											height: 60,
											children: <BootstrapCol>[
												BootstrapCol(
													sizes: 'col-12',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: TextFormField(
															autofocus: true,
															maxLines: 3,
															controller: crmOportunidadeController.descricaoController,
															decoration: inputDecoration(
																hintText: 'Informe os dados para o campo Descricao',
																labelText: 'Descricao',
																usePadding: true,
															),
															onSaved: (String? value) {},
															onChanged: (text) {
																crmOportunidadeController.currentModel.descricao = text;
																crmOportunidadeController.formWasChanged = true;
															},
														),
													),
												),
											],
										),
										const Divider(
											color: Colors.transparent,
										),
										BootstrapRow(
											height: 60,
											children: <BootstrapCol>[
												BootstrapCol(
													sizes: 'col-12 col-md-3',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: TextFormField(
															autofocus: true,
															controller: crmOportunidadeController.valorEstimadoController,
															decoration: inputDecoration(
																hintText: 'Informe os dados para o campo Valor Estimado',
																labelText: 'Valor Estimado',
																usePadding: true,
															),
															onSaved: (String? value) {},
															onChanged: (text) {
																crmOportunidadeController.currentModel.valorEstimado = crmOportunidadeController.valorEstimadoController.numberValue;
																crmOportunidadeController.formWasChanged = true;
															},
														),
													),
												),
												BootstrapCol(
													sizes: 'col-12 col-md-3',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: InputDecorator(
															decoration: inputDecoration(
																hintText: 'Informe os dados para o campo Data Abertura',
																labelText: 'Data Abertura',
																usePadding: true,
															),
															isEmpty: false,
															child: DatePickerItem(
																controller: crmOportunidadeController.dataAberturaController,
																firstDate: DateTime.parse('1000-01-01'),
																lastDate: DateTime.parse('5000-01-01'),
																onChanged: (DateTime? value) {
																	crmOportunidadeController.currentModel.dataAbertura = value;
																	crmOportunidadeController.formWasChanged = true;
																},
															),
														),
													),
												),
												BootstrapCol(
													sizes: 'col-12 col-md-3',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: InputDecorator(
															decoration: inputDecoration(
																hintText: 'Informe os dados para o campo Data Fechamento Previsto',
																labelText: 'Data Fechamento Previsto',
																usePadding: true,
															),
															isEmpty: false,
															child: DatePickerItem(
																controller: crmOportunidadeController.dataFechamentoPrevistoController,
																firstDate: DateTime.parse('1000-01-01'),
																lastDate: DateTime.parse('5000-01-01'),
																onChanged: (DateTime? value) {
																	crmOportunidadeController.currentModel.dataFechamentoPrevisto = value;
																	crmOportunidadeController.formWasChanged = true;
																},
															),
														),
													),
												),
												BootstrapCol(
													sizes: 'col-12 col-md-3',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: InputDecorator(
															decoration: inputDecoration(
																hintText: 'Informe os dados para o campo Data Fechamento Real',
																labelText: 'Data Fechamento Real',
																usePadding: true,
															),
															isEmpty: false,
															child: DatePickerItem(
																controller: crmOportunidadeController.dataFechamentoRealController,
																firstDate: DateTime.parse('1000-01-01'),
																lastDate: DateTime.parse('5000-01-01'),
																onChanged: (DateTime? value) {
																	crmOportunidadeController.currentModel.dataFechamentoReal = value;
																	crmOportunidadeController.formWasChanged = true;
																},
															),
														),
													),
												),
											],
										),
										const Divider(
											color: Colors.transparent,
										),
										BootstrapRow(
											height: 60,
											children: <BootstrapCol>[
												BootstrapCol(
													sizes: 'col-12 col-md-4',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: CustomDropdownButton(
															controller: crmOportunidadeController.statusController,
															labelText: 'Status',
															hintText: 'Informe os dados para o campo Status',
															items: CrmOportunidadeDomain.statusListDropdown,
															onChanged: (dynamic newValue) {
																crmOportunidadeController.currentModel.status = newValue;
																crmOportunidadeController.formWasChanged = true;
															},
														),
													),
												),
												BootstrapCol(
													sizes: 'col-12 col-md-4',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: CustomDropdownButton(
															controller: crmOportunidadeController.motivoFechamentoController,
															labelText: 'Motivo Fechamento',
															hintText: 'Informe os dados para o campo Motivo Fechamento',
															items: CrmOportunidadeDomain.motivoFechamentoListDropdown,
															onChanged: (dynamic newValue) {
																crmOportunidadeController.currentModel.motivoFechamento = newValue;
																crmOportunidadeController.formWasChanged = true;
															},
														),
													),
												),
												BootstrapCol(
													sizes: 'col-12 col-md-4',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: TextFormField(
															keyboardType: TextInputType.number,
															autofocus: true,
															controller: crmOportunidadeController.probabilidadeController,
															decoration: inputDecoration(
																hintText: 'Informe os dados para o campo Probabilidade',
																labelText: 'Probabilidade',
																usePadding: true,
															),
															onSaved: (String? value) {},
															onChanged: (text) {
																crmOportunidadeController.currentModel.probabilidade = int.tryParse(text);
																crmOportunidadeController.formWasChanged = true;
															},
														),
													),
												),
											],
										),
										const Divider(
											indent: 10,
											endIndent: 10,
											thickness: 2,
										),
										BootstrapRow(
											height: 60,
											children: <BootstrapCol>[
												BootstrapCol(
													sizes: 'col-12',
													child: Text(
														'field_is_mandatory'.tr,
														style: Theme.of(context).textTheme.bodySmall,
													),
												),
											],
										),
										const SizedBox(height: 10.0),
									],
								),
							),
						),
					),
				),
			),
		);
	}
}
