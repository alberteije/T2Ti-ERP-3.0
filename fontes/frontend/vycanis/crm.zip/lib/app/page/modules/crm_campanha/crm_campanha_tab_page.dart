import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:buttons_tabbar/buttons_tabbar.dart';
import 'package:get/get.dart';
import 'package:crm/app/controller/crm_campanha_controller.dart';
import 'package:crm/app/page/shared_widget/shared_widget_imports.dart';

class CrmCampanhaTabPage extends StatelessWidget {
  CrmCampanhaTabPage({Key? key}) : super(key: key);
  final crmCampanhaController = Get.find<CrmCampanhaController>();

  @override
  Widget build(BuildContext context) {
		return KeyboardListener(
			autofocus: false,
			focusNode: FocusNode(),
			onKeyEvent: (event) {
				if (event.logicalKey == LogicalKeyboardKey.escape) {
          crmCampanhaController.preventDataLoss();
        }
      },
      child: Scaffold(
        key: crmCampanhaController.crmCampanhaTabPageScaffoldKey,
        appBar: AppBar(
					automaticallyImplyLeading: false, 
					title: Text('${ crmCampanhaController.screenTitle } - ${ crmCampanhaController.isNewRecord ? 'inserting'.tr : 'editing'.tr }',),
					actions: [
						saveButton(onPressed: crmCampanhaController.save),
						cancelAndExitButton(onPressed: crmCampanhaController.preventDataLoss),
					]
				),
        body: SafeArea(
          child: Column(
            children: <Widget>[
              Expanded(
                child: TabBarView(
                  controller: crmCampanhaController.tabController,
                  children: crmCampanhaController.tabPages(),
                ),
              ),
              ButtonsTabBar(
                controller: crmCampanhaController.tabController,
                onTap: crmCampanhaController.tabChange,
                height: 40,
                elevation: 2,
                borderWidth: 0,
                backgroundColor: Colors.blueGrey,
                unselectedBackgroundColor: Colors.grey[300],
                unselectedLabelStyle: const TextStyle(color: Colors.black),
                labelStyle: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold),
                tabs: crmCampanhaController.tabItems,
              ),
              const SizedBox(
                height: 10,
              ),
            ],
          ),
        ),
      ),
    );
  }
}
