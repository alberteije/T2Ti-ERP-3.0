import 'package:flutter/material.dart';
import 'package:crm/app/controller/crm_campanha_controller.dart';
import 'package:crm/app/page/shared_page/list_page_base.dart';

class CrmCampanhaListPage extends ListPageBase<CrmCampanhaController> {
  const CrmCampanhaListPage({Key? key}) : super(key: key);

  @override
  List<Map<String, dynamic>> get mobileItems => controller.mobileItems;

  @override
  Map<String, dynamic> get mobileConfig => controller.mobileConfig;

  @override
  String get standardFieldForFilter => controller.standardFieldForFilter;
}