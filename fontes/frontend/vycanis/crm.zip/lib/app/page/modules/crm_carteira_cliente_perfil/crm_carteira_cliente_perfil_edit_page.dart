import 'package:flutter/material.dart';
import 'package:flutter_bootstrap/flutter_bootstrap.dart';
import 'package:get/get.dart';
import 'package:crm/app/controller/crm_carteira_cliente_perfil_controller.dart';
import 'package:crm/app/infra/infra_imports.dart';
import 'package:crm/app/page/shared_widget/input/input_imports.dart';

class CrmCarteiraClientePerfilEditPage extends StatelessWidget {
	CrmCarteiraClientePerfilEditPage({Key? key}) : super(key: key);
	final crmCarteiraClientePerfilController = Get.find<CrmCarteiraClientePerfilController>();

	@override
	Widget build(BuildContext context) {
			return Scaffold(
				key: crmCarteiraClientePerfilController.crmCarteiraClientePerfilScaffoldKey,
				body: SafeArea(
					top: false,
					bottom: false,
					child: Form(
						key: crmCarteiraClientePerfilController.crmCarteiraClientePerfilFormKey,
						autovalidateMode: AutovalidateMode.always,
						child: Scrollbar(
							controller: crmCarteiraClientePerfilController.scrollController,
							child: SingleChildScrollView(
								controller: crmCarteiraClientePerfilController.scrollController,
								child: BootstrapContainer(
									fluid: true,
									padding: const EdgeInsets.all(10),
									children: <Widget>[
										const Divider(
											color: Colors.transparent,
										),
										BootstrapRow(
											height: 60,
											children: <BootstrapCol>[
												BootstrapCol(
													sizes: 'col-12 col-md-3',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: TextFormField(
															autofocus: true,
															maxLength: 2,
															controller: crmCarteiraClientePerfilController.codigoController,
															decoration: inputDecoration(
																hintText: 'Informe os dados para o campo Codigo',
																labelText: 'Codigo',
																usePadding: true,
															),
															onSaved: (String? value) {},
															onChanged: (text) {
																crmCarteiraClientePerfilController.currentModel.codigo = text;
																crmCarteiraClientePerfilController.formWasChanged = true;
															},
														),
													),
												),
												BootstrapCol(
													sizes: 'col-12 col-md-9',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: TextFormField(
															autofocus: true,
															maxLength: 100,
															controller: crmCarteiraClientePerfilController.nomeController,
															decoration: inputDecoration(
																hintText: 'Informe os dados para o campo Nome',
																labelText: 'Nome',
																usePadding: true,
															),
															onSaved: (String? value) {},
															onChanged: (text) {
																crmCarteiraClientePerfilController.currentModel.nome = text;
																crmCarteiraClientePerfilController.formWasChanged = true;
															},
														),
													),
												),
											],
										),
										const Divider(
											indent: 10,
											endIndent: 10,
											thickness: 2,
										),
										BootstrapRow(
											height: 60,
											children: <BootstrapCol>[
												BootstrapCol(
													sizes: 'col-12',
													child: Text(
														'field_is_mandatory'.tr,
														style: Theme.of(context).textTheme.bodySmall,
													),
												),
											],
										),
										const SizedBox(height: 10.0),
									],
								),
							),
						),
					),
				),
			);
	}
}
