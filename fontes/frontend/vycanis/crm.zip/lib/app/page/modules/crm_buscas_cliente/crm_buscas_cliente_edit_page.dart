import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_bootstrap/flutter_bootstrap.dart';
import 'package:get/get.dart';
import 'package:crm/app/page/shared_widget/shared_widget_imports.dart';
import 'package:crm/app/controller/crm_buscas_cliente_controller.dart';
import 'package:crm/app/infra/infra_imports.dart';
import 'package:crm/app/page/shared_widget/input/input_imports.dart';

class CrmBuscasClienteEditPage extends StatelessWidget {
	CrmBuscasClienteEditPage({Key? key}) : super(key: key);
	final crmBuscasClienteController = Get.find<CrmBuscasClienteController>();

	@override
	Widget build(BuildContext context) {
		return KeyboardListener(
			autofocus: false,
			focusNode: FocusNode(),
			onKeyEvent: (event) {
				if (event.logicalKey == LogicalKeyboardKey.escape) {
					crmBuscasClienteController.preventDataLoss();
				}
			},
			child: Scaffold(
				key: crmBuscasClienteController.scaffoldKey,
				appBar: AppBar(
					automaticallyImplyLeading: false,
					title: Text('${ crmBuscasClienteController.screenTitle } - ${ crmBuscasClienteController.isNewRecord ? 'inserting'.tr : 'editing'.tr }',),
					actions: [
						saveButton(onPressed: crmBuscasClienteController.save),
						cancelAndExitButton(onPressed: crmBuscasClienteController.preventDataLoss),
					]
				),
				body: SafeArea(
					top: false,
					bottom: false,
					child: Form(
						key: crmBuscasClienteController.formKey,
						autovalidateMode: AutovalidateMode.always,
						child: Scrollbar(
							controller: crmBuscasClienteController.scrollController,
							child: SingleChildScrollView(
								controller: crmBuscasClienteController.scrollController,
								child: BootstrapContainer(
									fluid: true,
									padding: const EdgeInsets.fromLTRB(10.0, 10.0, 10.0, 10.0),
									children: <Widget>[
										const Divider(
											color: Colors.transparent,
										),
										BootstrapRow(
											height: 60,
											children: <BootstrapCol>[
												BootstrapCol(
													sizes: 'col-12',
													child: Row(
														children: <Widget>[
															Expanded(
																flex: 1,
																child: SizedBox(
																	child: TextFormField(
																		controller: crmBuscasClienteController.viewPessoaClienteModelController,
																		validator: ValidateFormField.validateMandatory,
																		readOnly: true,
																		decoration: inputDecoration(
																			hintText: 'Informe os dados para o campo Cliente',
																			labelText: 'Cliente',
																			usePadding: true,
																		),
																		onSaved: (String? value) {},
																		onChanged: (text) {},
																	),
																),
															),
														],
													),
												),
											],
										),
										const Divider(
											color: Colors.transparent,
										),
										BootstrapRow(
											height: 60,
											children: <BootstrapCol>[
												BootstrapCol(
													sizes: 'col-12 col-md-6',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: InputDecorator(
															decoration: inputDecoration(
																hintText: 'Informe os dados para o campo Data Busca',
																labelText: 'Data Busca',
																usePadding: true,
															),
															isEmpty: false,
															child: DatePickerItem(
                                readOnly: true,
																controller: crmBuscasClienteController.dataBuscaController,
																firstDate: DateTime.parse('1000-01-01'),
																lastDate: DateTime.parse('5000-01-01'),
																onChanged: (DateTime? value) {
																	crmBuscasClienteController.currentModel.dataBusca = value;
																	crmBuscasClienteController.formWasChanged = true;
																},
															),
														),
													),
												),
												BootstrapCol(
													sizes: 'col-12 col-md-6',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: TextFormField(
                              readOnly: true,
															autofocus: true,
															controller: crmBuscasClienteController.horaBuscaController,
															decoration: inputDecoration(
																hintText: 'Informe os dados para o campo Hora Busca',
																labelText: 'Hora Busca',
																usePadding: true,
															),
															onSaved: (String? value) {},
															onChanged: (text) {
																crmBuscasClienteController.currentModel.horaBusca = text;
																crmBuscasClienteController.formWasChanged = true;
															},
														),
													),
												),
											],
										),
										const Divider(
											color: Colors.transparent,
										),
										BootstrapRow(
											height: 60,
											children: <BootstrapCol>[
												BootstrapCol(
													sizes: 'col-12',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: TextFormField(
                              readOnly: true,
															autofocus: true,
															maxLines: 3,
															controller: crmBuscasClienteController.detalhesController,
															decoration: inputDecoration(
																hintText: 'Informe os dados para o campo Detalhes',
																labelText: 'Detalhes',
																usePadding: true,
															),
															onSaved: (String? value) {},
															onChanged: (text) {
																crmBuscasClienteController.currentModel.detalhes = text;
																crmBuscasClienteController.formWasChanged = true;
															},
														),
													),
												),
											],
										),
										const Divider(
											indent: 10,
											endIndent: 10,
											thickness: 2,
										),
										BootstrapRow(
											height: 60,
											children: <BootstrapCol>[
												BootstrapCol(
													sizes: 'col-12',
													child: Text(
														'field_is_mandatory'.tr,
														style: Theme.of(context).textTheme.bodySmall,
													),
												),
											],
										),
										const SizedBox(height: 10.0),
									],
								),
							),
						),
					),
				),
			),
		);
	}
}
