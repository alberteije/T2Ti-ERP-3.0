import 'package:flutter/material.dart';
import 'package:flutter_bootstrap/flutter_bootstrap.dart';
import 'package:get/get.dart';
import 'package:crm/app/page/shared_widget/shared_widget_imports.dart';
import 'package:crm/app/data/domain/domain_imports.dart';
import 'package:crm/app/controller/crm_sac_cabecalho_controller.dart';
import 'package:crm/app/infra/infra_imports.dart';
import 'package:crm/app/page/shared_widget/input/input_imports.dart';

class CrmSacCabecalhoEditPage extends StatelessWidget {
	CrmSacCabecalhoEditPage({Key? key}) : super(key: key);
	final crmSacCabecalhoController = Get.find<CrmSacCabecalhoController>();

	@override
	Widget build(BuildContext context) {
			return Scaffold(
				key: crmSacCabecalhoController.crmSacCabecalhoScaffoldKey,
				body: SafeArea(
					top: false,
					bottom: false,
					child: Form(
						key: crmSacCabecalhoController.crmSacCabecalhoFormKey,
						autovalidateMode: AutovalidateMode.always,
						child: Scrollbar(
							controller: crmSacCabecalhoController.scrollController,
							child: SingleChildScrollView(
								controller: crmSacCabecalhoController.scrollController,
								child: BootstrapContainer(
									fluid: true,
									padding: const EdgeInsets.all(10),
									children: <Widget>[
										const Divider(
											color: Colors.transparent,
										),
										BootstrapRow(
											height: 60,
											children: <BootstrapCol>[
												BootstrapCol(
													sizes: 'col-12',
													child: Row(
														children: <Widget>[
															Expanded(
																flex: 1,
																child: SizedBox(
																	child: TextFormField(
																		controller: crmSacCabecalhoController.viewPessoaClienteModelController,
																		validator: ValidateFormField.validateMandatory,
																		readOnly: true,
																		decoration: inputDecoration(
																			hintText: 'Cliente',
																			labelText: 'Cliente *',
																			usePadding: true,
																		),
																		onSaved: (String? value) {},
																		onChanged: (text) {},
																	),
																),
															),
															Expanded(
																flex: 0,
																child: lookupButton(onPressed: crmSacCabecalhoController.callViewPessoaClienteLookup),
															),
														],
													),
												),
											],
										),
										const Divider(
											color: Colors.transparent,
										),
										BootstrapRow(
											height: 60,
											children: <BootstrapCol>[
												BootstrapCol(
													sizes: 'col-12 col-md-4',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: InputDecorator(
															decoration: inputDecoration(
																hintText: 'Informe os dados para o campo Data Abertura',
																labelText: 'Data Abertura',
																usePadding: true,
															),
															isEmpty: false,
															child: DatePickerItem(
																controller: crmSacCabecalhoController.dataAberturaController,
																firstDate: DateTime.parse('1000-01-01'),
																lastDate: DateTime.parse('5000-01-01'),
																onChanged: (DateTime? value) {
																	crmSacCabecalhoController.currentModel.dataAbertura = value;
																	crmSacCabecalhoController.formWasChanged = true;
																},
															),
														),
													),
												),
												BootstrapCol(
													sizes: 'col-12 col-md-4',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: TextFormField(
															autofocus: true,
															controller: crmSacCabecalhoController.horaAberturaController,
															decoration: inputDecoration(
																hintText: 'Informe os dados para o campo Hora Abertura',
																labelText: 'Hora Abertura',
																usePadding: true,
															),
															onSaved: (String? value) {},
															onChanged: (text) {
																crmSacCabecalhoController.currentModel.horaAbertura = text;
																crmSacCabecalhoController.formWasChanged = true;
															},
														),
													),
												),
												BootstrapCol(
													sizes: 'col-12 col-md-4',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: CustomDropdownButton(
															controller: crmSacCabecalhoController.nivelReclamacaoController,
															labelText: 'Nivel Reclamacao',
															hintText: 'Informe os dados para o campo Nivel Reclamacao',
															items: CrmSacCabecalhoDomain.nivelReclamacaoListDropdown,
															onChanged: (dynamic newValue) {
																crmSacCabecalhoController.currentModel.nivelReclamacao = newValue;
																crmSacCabecalhoController.formWasChanged = true;
															},
														),
													),
												),
											],
										),
										const Divider(
											color: Colors.transparent,
										),
										BootstrapRow(
											height: 60,
											children: <BootstrapCol>[
												BootstrapCol(
													sizes: 'col-12',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: TextFormField(
															autofocus: true,
															maxLength: 100,
															controller: crmSacCabecalhoController.numeroProtocoloController,
															decoration: inputDecoration(
																hintText: 'Informe os dados para o campo Numero Protocolo',
																labelText: 'Numero Protocolo',
																usePadding: true,
															),
															onSaved: (String? value) {},
															onChanged: (text) {
																crmSacCabecalhoController.currentModel.numeroProtocolo = text;
																crmSacCabecalhoController.formWasChanged = true;
															},
														),
													),
												),
											],
										),
										const Divider(
											indent: 10,
											endIndent: 10,
											thickness: 2,
										),
										BootstrapRow(
											height: 60,
											children: <BootstrapCol>[
												BootstrapCol(
													sizes: 'col-12',
													child: Text(
														'field_is_mandatory'.tr,
														style: Theme.of(context).textTheme.bodySmall,
													),
												),
											],
										),
										const SizedBox(height: 10.0),
									],
								),
							),
						),
					),
				),
			);
	}
}
