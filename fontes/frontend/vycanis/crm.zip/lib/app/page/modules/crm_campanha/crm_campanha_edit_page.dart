import 'package:flutter/material.dart';
import 'package:flutter_bootstrap/flutter_bootstrap.dart';
import 'package:get/get.dart';
import 'package:crm/app/data/domain/domain_imports.dart';
import 'package:crm/app/controller/crm_campanha_controller.dart';
import 'package:crm/app/infra/infra_imports.dart';
import 'package:crm/app/page/shared_widget/input/input_imports.dart';

class CrmCampanhaEditPage extends StatelessWidget {
	CrmCampanhaEditPage({Key? key}) : super(key: key);
	final crmCampanhaController = Get.find<CrmCampanhaController>();

	@override
	Widget build(BuildContext context) {
			return Scaffold(
				key: crmCampanhaController.crmCampanhaScaffoldKey,
				body: SafeArea(
					top: false,
					bottom: false,
					child: Form(
						key: crmCampanhaController.crmCampanhaFormKey,
						autovalidateMode: AutovalidateMode.always,
						child: Scrollbar(
							controller: crmCampanhaController.scrollController,
							child: SingleChildScrollView(
								controller: crmCampanhaController.scrollController,
								child: BootstrapContainer(
									fluid: true,
									padding: const EdgeInsets.all(10),
									children: <Widget>[
										const Divider(
											color: Colors.transparent,
										),
										BootstrapRow(
											height: 60,
											children: <BootstrapCol>[
												BootstrapCol(
													sizes: 'col-12',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: TextFormField(
															autofocus: true,
															maxLength: 200,
															controller: crmCampanhaController.nomeController,
															decoration: inputDecoration(
																hintText: 'Informe os dados para o campo Nome',
																labelText: 'Nome',
																usePadding: true,
															),
															onSaved: (String? value) {},
															onChanged: (text) {
																crmCampanhaController.currentModel.nome = text;
																crmCampanhaController.formWasChanged = true;
															},
														),
													),
												),
											],
										),
										const Divider(
											color: Colors.transparent,
										),
										BootstrapRow(
											height: 60,
											children: <BootstrapCol>[
												BootstrapCol(
													sizes: 'col-12',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: TextFormField(
															autofocus: true,
															maxLines: 3,
															controller: crmCampanhaController.descricaoController,
															decoration: inputDecoration(
																hintText: 'Informe os dados para o campo Descricao',
																labelText: 'Descricao',
																usePadding: true,
															),
															onSaved: (String? value) {},
															onChanged: (text) {
																crmCampanhaController.currentModel.descricao = text;
																crmCampanhaController.formWasChanged = true;
															},
														),
													),
												),
											],
										),
										const Divider(
											color: Colors.transparent,
										),
										BootstrapRow(
											height: 60,
											children: <BootstrapCol>[
												BootstrapCol(
													sizes: 'col-12 col-md-4',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: CustomDropdownButton(
															controller: crmCampanhaController.tipoController,
															labelText: 'Tipo',
															hintText: 'Informe os dados para o campo Tipo',
															items: CrmCampanhaDomain.tipoListDropdown,
															onChanged: (dynamic newValue) {
																crmCampanhaController.currentModel.tipo = newValue;
																crmCampanhaController.formWasChanged = true;
															},
														),
													),
												),
												BootstrapCol(
													sizes: 'col-12 col-md-4',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: InputDecorator(
															decoration: inputDecoration(
																hintText: 'Informe os dados para o campo Data Inicio',
																labelText: 'Data Inicio',
																usePadding: true,
															),
															isEmpty: false,
															child: DatePickerItem(
																controller: crmCampanhaController.dataInicioController,
																firstDate: DateTime.parse('1000-01-01'),
																lastDate: DateTime.parse('5000-01-01'),
																onChanged: (DateTime? value) {
																	crmCampanhaController.currentModel.dataInicio = value;
																	crmCampanhaController.formWasChanged = true;
																},
															),
														),
													),
												),
												BootstrapCol(
													sizes: 'col-12 col-md-4',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: InputDecorator(
															decoration: inputDecoration(
																hintText: 'Informe os dados para o campo Data Fim',
																labelText: 'Data Fim',
																usePadding: true,
															),
															isEmpty: false,
															child: DatePickerItem(
																controller: crmCampanhaController.dataFimController,
																firstDate: DateTime.parse('1000-01-01'),
																lastDate: DateTime.parse('5000-01-01'),
																onChanged: (DateTime? value) {
																	crmCampanhaController.currentModel.dataFim = value;
																	crmCampanhaController.formWasChanged = true;
																},
															),
														),
													),
												),
											],
										),
										const Divider(
											color: Colors.transparent,
										),
										BootstrapRow(
											height: 60,
											children: <BootstrapCol>[
												BootstrapCol(
													sizes: 'col-12 col-md-6',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: TextFormField(
															autofocus: true,
															controller: crmCampanhaController.orcamentoController,
															decoration: inputDecoration(
																hintText: 'Informe os dados para o campo Orcamento',
																labelText: 'Orcamento',
																usePadding: true,
															),
															onSaved: (String? value) {},
															onChanged: (text) {
																crmCampanhaController.currentModel.orcamento = crmCampanhaController.orcamentoController.numberValue;
																crmCampanhaController.formWasChanged = true;
															},
														),
													),
												),
												BootstrapCol(
													sizes: 'col-12 col-md-6',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: CustomDropdownButton(
															controller: crmCampanhaController.statusController,
															labelText: 'Status',
															hintText: 'Informe os dados para o campo Status',
															items: CrmCampanhaDomain.statusListDropdown,
															onChanged: (dynamic newValue) {
																crmCampanhaController.currentModel.status = newValue;
																crmCampanhaController.formWasChanged = true;
															},
														),
													),
												),
											],
										),
										const Divider(
											indent: 10,
											endIndent: 10,
											thickness: 2,
										),
										BootstrapRow(
											height: 60,
											children: <BootstrapCol>[
												BootstrapCol(
													sizes: 'col-12',
													child: Text(
														'field_is_mandatory'.tr,
														style: Theme.of(context).textTheme.bodySmall,
													),
												),
											],
										),
										const SizedBox(height: 10.0),
									],
								),
							),
						),
					),
				),
			);
	}
}
