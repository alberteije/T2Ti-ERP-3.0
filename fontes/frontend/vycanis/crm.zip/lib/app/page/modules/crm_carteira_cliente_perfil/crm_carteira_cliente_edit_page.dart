import 'package:flutter/material.dart';
import 'package:flutter_bootstrap/flutter_bootstrap.dart';
import 'package:get/get.dart';
import 'package:crm/app/page/shared_widget/shared_widget_imports.dart';
import 'package:crm/app/controller/crm_carteira_cliente_controller.dart';
import 'package:crm/app/infra/infra_imports.dart';
import 'package:crm/app/page/shared_widget/input/input_imports.dart';

class CrmCarteiraClienteEditPage extends StatelessWidget {
	CrmCarteiraClienteEditPage({Key? key}) : super(key: key);
	final crmCarteiraClienteController = Get.find<CrmCarteiraClienteController>();

	@override
	Widget build(BuildContext context) {
			return Scaffold(
				key: crmCarteiraClienteController.crmCarteiraClienteScaffoldKey,	
				appBar: AppBar(
					automaticallyImplyLeading: false,
					title: Text('${ crmCarteiraClienteController.screenTitle } - ${ crmCarteiraClienteController.isNewRecord ? 'inserting'.tr : 'editing'.tr }',),
					actions: [
						saveButton(onPressed: crmCarteiraClienteController.save),
						cancelAndExitButton(onPressed: crmCarteiraClienteController.preventDataLoss),
					]
				),
				body: SafeArea(
					top: false,
					bottom: false,
					child: Form(
						key: crmCarteiraClienteController.crmCarteiraClienteFormKey,
						autovalidateMode: AutovalidateMode.always,
						child: Scrollbar(
							controller: crmCarteiraClienteController.scrollController,
							child: SingleChildScrollView(
								controller: crmCarteiraClienteController.scrollController,
								child: BootstrapContainer(
									fluid: true,
									padding: const EdgeInsets.all(10.0),
									children: <Widget>[
										const Divider(
											color: Colors.transparent,
										),
										BootstrapRow(
											height: 60,
											children: <BootstrapCol>[
												BootstrapCol(
													sizes: 'col-12',
													child: Row(
														children: <Widget>[
															Expanded(
																flex: 1,
																child: SizedBox(
																	child: TextFormField(
																		controller: crmCarteiraClienteController.viewPessoaClienteModelController,
																		validator: ValidateFormField.validateMandatory,
																		readOnly: true,
																		decoration: inputDecoration(
																			hintText: 'Cliente',
																			labelText: 'Cliente *',
																			usePadding: true,
																		),
																		onSaved: (String? value) {},
																		onChanged: (text) {},
																	),
																),
															),
															Expanded(
																flex: 0,
																child: lookupButton(onPressed: crmCarteiraClienteController.callViewPessoaClienteLookup),
															),
														],
													),
												),
											],
										),
										const Divider(
											indent: 10,
											endIndent: 10,
											thickness: 2,
										),
										BootstrapRow(
											height: 60,
											children: <BootstrapCol>[
												BootstrapCol(
													sizes: 'col-12',
													child: Text(
														'field_is_mandatory'.tr,
														style: Theme.of(context).textTheme.bodySmall,
													),
												),
											],
										),
										const SizedBox(height: 10.0),
									],
								),
							),
						),
					),
				),
			);
	}
}
