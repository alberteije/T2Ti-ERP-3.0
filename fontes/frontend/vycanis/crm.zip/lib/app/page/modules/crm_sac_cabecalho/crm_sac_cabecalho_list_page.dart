import 'package:flutter/material.dart';
import 'package:crm/app/controller/crm_sac_cabecalho_controller.dart';
import 'package:crm/app/page/shared_page/list_page_base.dart';

class CrmSacCabecalhoListPage extends ListPageBase<CrmSacCabecalhoController> {
  const CrmSacCabecalhoListPage({Key? key}) : super(key: key);

  @override
  List<Map<String, dynamic>> get mobileItems => controller.mobileItems;

  @override
  Map<String, dynamic> get mobileConfig => controller.mobileConfig;

  @override
  String get standardFieldForFilter => controller.standardFieldForFilter;
}