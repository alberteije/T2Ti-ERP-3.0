import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:buttons_tabbar/buttons_tabbar.dart';
import 'package:get/get.dart';
import 'package:crm/app/controller/crm_sac_cabecalho_controller.dart';
import 'package:crm/app/page/shared_widget/shared_widget_imports.dart';

class CrmSacCabecalhoTabPage extends StatelessWidget {
  CrmSacCabecalhoTabPage({Key? key}) : super(key: key);
  final crmSacCabecalhoController = Get.find<CrmSacCabecalhoController>();

  @override
  Widget build(BuildContext context) {
		return KeyboardListener(
			autofocus: false,
			focusNode: FocusNode(),
			onKeyEvent: (event) {
				if (event.logicalKey == LogicalKeyboardKey.escape) {
          crmSacCabecalhoController.preventDataLoss();
        }
      },
      child: Scaffold(
        key: crmSacCabecalhoController.crmSacCabecalhoTabPageScaffoldKey,
        appBar: AppBar(
					automaticallyImplyLeading: false, 
					title: Text('${ crmSacCabecalhoController.screenTitle } - ${ crmSacCabecalhoController.isNewRecord ? 'inserting'.tr : 'editing'.tr }',),
					actions: [
						saveButton(onPressed: crmSacCabecalhoController.save),
						cancelAndExitButton(onPressed: crmSacCabecalhoController.preventDataLoss),
					]
				),
        body: SafeArea(
          child: Column(
            children: <Widget>[
              Expanded(
                child: TabBarView(
                  controller: crmSacCabecalhoController.tabController,
                  children: crmSacCabecalhoController.tabPages(),
                ),
              ),
              ButtonsTabBar(
                controller: crmSacCabecalhoController.tabController,
                onTap: crmSacCabecalhoController.tabChange,
                height: 40,
                elevation: 2,
                borderWidth: 0,
                backgroundColor: Colors.blueGrey,
                unselectedBackgroundColor: Colors.grey[300],
                unselectedLabelStyle: const TextStyle(color: Colors.black),
                labelStyle: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold),
                tabs: crmSacCabecalhoController.tabItems,
              ),
              const SizedBox(
                height: 10,
              ),
            ],
          ),
        ),
      ),
    );
  }
}
