import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:extended_masked_text/extended_masked_text.dart';
import 'package:crm/app/page/shared_widget/input/input_imports.dart';

import 'package:crm/app/page/shared_widget/message_dialog.dart';
import 'package:crm/app/page/grid_columns/grid_columns_imports.dart';
import 'package:crm/app/routes/app_routes.dart';
import 'package:crm/app/controller/controller_imports.dart';
import 'package:crm/app/data/model/model_imports.dart';
import 'package:crm/app/data/repository/crm_oportunidade_repository.dart';

class CrmOportunidadeController extends ControllerBase<CrmOportunidadeModel, CrmOportunidadeRepository> {

  CrmOportunidadeController({required super.repository}) {
    dbColumns = CrmOportunidadeModel.dbColumns;
    aliasColumns = CrmOportunidadeModel.aliasColumns;
    gridColumns = crmOportunidadeGridColumns();
    functionName = "crm_oportunidade";
    screenTitle = "Oportunidades";
  }

  @override
  CrmOportunidadeModel createNewModel() => CrmOportunidadeModel();

  @override
  final standardFieldForFilter = CrmOportunidadeModel.aliasColumns[CrmOportunidadeModel.dbColumns.indexOf('titulo')];

  final viewPessoaClienteModelController = TextEditingController();
  final viewPessoaColaboradorModelController = TextEditingController();
  final tituloController = TextEditingController();
  final descricaoController = TextEditingController();
  final valorEstimadoController = MoneyMaskedTextController();
  final dataAberturaController = DatePickerItemController(null);
  final dataFechamentoPrevistoController = DatePickerItemController(null);
  final dataFechamentoRealController = DatePickerItemController(null);
  final statusController = CustomDropdownButtonController('Prospecção');
  final motivoFechamentoController = CustomDropdownButtonController('Ganha');
  final probabilidadeController = MoneyMaskedTextController(precision: 0, decimalSeparator: '', thousandSeparator: '');

  final Map<String, dynamic> mobileConfig = {
    'primaryColumns': ['titulo'],
    'secondaryColumns': ['descricao'],
  };

  List<Map<String, dynamic>> get mobileItems {
    return modelList.map((crmOportunidade) => crmOportunidade.toJson).toList();
  }

  @override
  void prepareForInsert() {
    isNewRecord = true;
    currentModel = createNewModel();
    _resetForm();
    Get.toNamed(Routes.crmOportunidadeEditPage);
  }

  void _resetForm() {
    formWasChanged = false;
    viewPessoaClienteModelController.text = '';
    viewPessoaColaboradorModelController.text = '';
    tituloController.text = '';
    descricaoController.text = '';
    valorEstimadoController.updateValue(0);
    dataAberturaController.date = null;
    dataFechamentoPrevistoController.date = null;
    dataFechamentoRealController.date = null;
    statusController.selected = 'Prospecção';
    motivoFechamentoController.selected = 'Ganha';
    probabilidadeController.updateValue(0);
  }

  @override
  void selectRowForEditingById(int id) {
    final model = modelList.firstWhere((m) => m.id == id);
    currentModel = model.clone();
    updateControllersFromModel();
    Get.toNamed(Routes.crmOportunidadeEditPage);
  }

  void updateControllersFromModel() {
    viewPessoaClienteModelController.text = currentModel.viewPessoaClienteModel?.nome?.toString() ?? '';
    viewPessoaColaboradorModelController.text = currentModel.viewPessoaColaboradorModel?.nome?.toString() ?? '';
    tituloController.text = currentModel.titulo ?? '';
    descricaoController.text = currentModel.descricao ?? '';
    valorEstimadoController.updateValue(currentModel.valorEstimado ?? 0);
    dataAberturaController.date = currentModel.dataAbertura;
    dataFechamentoPrevistoController.date = currentModel.dataFechamentoPrevisto;
    dataFechamentoRealController.date = currentModel.dataFechamentoReal;
    statusController.selected = currentModel.status ?? 'Prospecção';
    motivoFechamentoController.selected = currentModel.motivoFechamento ?? 'Ganha';
    probabilidadeController.updateValue((currentModel.probabilidade ?? 0).toDouble());
    formWasChanged = false;
  }

  @override
  Future<void> save() async {
    if (!formKey.currentState!.validate()) {
      showErrorSnackBar(message: 'validator_form_message'.tr);
      return;
    }

    final existingIndex = modelList.indexWhere((m) => m.id == currentModel.id);

    if (existingIndex >= 0) {
      modelList[existingIndex] = currentModel.clone();
    }

    final result = await repository.save(crmOportunidadeModel: currentModel);
    if (result == null) return;

    if (existingIndex >= 0) {
      modelList[existingIndex] = result;
    } else {
      modelList.insert(0, result);
    }

    if (!GetPlatform.isMobile) {
      updateGridRow(result);
    }

    Get.back(result: true);
  }

  Future callViewPessoaClienteLookup() async { 
		final lookupController = Get.find<LookupController>(); 
		lookupController.refreshItems(standardValue: '%'); 
		lookupController.title = '${'lookup_page_title'.tr} [Cliente]'; 
		lookupController.route = '/view-pessoa-cliente/'; 
		lookupController.gridColumns = viewPessoaClienteGridColumns(isForLookup: true); 
		lookupController.aliasColumns = ViewPessoaClienteModel.aliasColumns; 
		lookupController.dbColumns = ViewPessoaClienteModel.dbColumns; 
		lookupController.standardColumn = ViewPessoaClienteModel.aliasColumns[ViewPessoaClienteModel.dbColumns.indexOf('nome')]; 

		final plutoRowResult = await Get.toNamed(Routes.lookupPage); 
		if (plutoRowResult != null) { 
			currentModel.idCliente = plutoRowResult.cells['id']!.value; 
			currentModel.viewPessoaClienteModel = ViewPessoaClienteModel.fromPlutoRow(plutoRowResult); 
			viewPessoaClienteModelController.text = currentModel.viewPessoaClienteModel?.nome ?? ''; 
			formWasChanged = true; 
		}
	}

  Future callViewPessoaColaboradorLookup() async { 
		final lookupController = Get.find<LookupController>(); 
		lookupController.refreshItems(standardValue: '%'); 
		lookupController.title = '${'lookup_page_title'.tr} [Colaborador]'; 
		lookupController.route = '/view-pessoa-colaborador/'; 
		lookupController.gridColumns = viewPessoaColaboradorGridColumns(isForLookup: true); 
		lookupController.aliasColumns = ViewPessoaColaboradorModel.aliasColumns; 
		lookupController.dbColumns = ViewPessoaColaboradorModel.dbColumns; 
		lookupController.standardColumn = ViewPessoaColaboradorModel.aliasColumns[ViewPessoaColaboradorModel.dbColumns.indexOf('nome')]; 

		final plutoRowResult = await Get.toNamed(Routes.lookupPage); 
		if (plutoRowResult != null) { 
			currentModel.idViewPessoaColaborador = plutoRowResult.cells['id']!.value; 
			currentModel.viewPessoaColaboradorModel = ViewPessoaColaboradorModel.fromPlutoRow(plutoRowResult); 
			viewPessoaColaboradorModelController.text = currentModel.viewPessoaColaboradorModel?.nome ?? ''; 
			formWasChanged = true; 
		}
	}


  @override
  void onClose() {
    viewPessoaClienteModelController.dispose();
    viewPessoaColaboradorModelController.dispose();
    tituloController.dispose();
    descricaoController.dispose();
    valorEstimadoController.dispose();
    dataAberturaController.dispose();
    dataFechamentoPrevistoController.dispose();
    dataFechamentoRealController.dispose();
    statusController.dispose();
    motivoFechamentoController.dispose();
    probabilidadeController.dispose();
    super.onClose();
  }

}