import 'package:flutter/material.dart';
import 'dart:math';
import 'package:get/get.dart';

import 'package:crm/app/infra/infra_imports.dart';
import 'package:crm/app/page/page_imports.dart';
import 'package:crm/app/page/shared_widget/message_dialog.dart';
import 'package:crm/app/page/grid_columns/grid_columns_imports.dart';
import 'package:crm/app/routes/app_routes.dart';
import 'package:crm/app/controller/controller_imports.dart';
import 'package:crm/app/data/model/model_imports.dart';
import 'package:crm/app/data/repository/crm_carteira_cliente_perfil_repository.dart';

class CrmCarteiraClientePerfilController extends ControllerBase<CrmCarteiraClientePerfilModel, CrmCarteiraClientePerfilRepository> 
with GetSingleTickerProviderStateMixin {

  CrmCarteiraClientePerfilController({required super.repository}) {
    dbColumns = CrmCarteiraClientePerfilModel.dbColumns;
    aliasColumns = CrmCarteiraClientePerfilModel.aliasColumns;
    gridColumns = crmCarteiraClientePerfilGridColumns();
    functionName = "crm_carteira_cliente_perfil";
    screenTitle = "Perfil Carteira";
  }

  final crmCarteiraClientePerfilScaffoldKey = GlobalKey<ScaffoldState>();
  final crmCarteiraClientePerfilTabPageScaffoldKey = GlobalKey<ScaffoldState>();
  final crmCarteiraClientePerfilFormKey = GlobalKey<FormState>();
  late TabController tabController;
  String? mandatoryMessage;  

  @override
  CrmCarteiraClientePerfilModel createNewModel() => CrmCarteiraClientePerfilModel();

  @override
  final standardFieldForFilter = CrmCarteiraClientePerfilModel.aliasColumns[CrmCarteiraClientePerfilModel.dbColumns.indexOf('codigo')];

  final codigoController = TextEditingController();
  final nomeController = TextEditingController();

  final Map<String, dynamic> mobileConfig = {
    'primaryColumns': ['codigo'],
    'secondaryColumns': ['nome'],
  };

  List<Map<String, dynamic>> get mobileItems {
    return modelList.map((crmCarteiraClientePerfil) => crmCarteiraClientePerfil.toJson).toList();
  }

  @override
  void prepareForInsert() {
    isNewRecord = true;
    currentModel = createNewModel();
    _resetForm();
    tabController.animateTo(0);
    updateControllersFromModel();
    Get.toNamed(Routes.crmCarteiraClientePerfilTabPage);
  }

  void _resetForm() {
    formWasChanged = false;
    codigoController.text = '';
    nomeController.text = '';
  }

  @override
  void selectRowForEditingById(int id) {
    final model = modelList.firstWhere((m) => m.id == id);
    currentModel = model.clone();
    updateControllersFromModel();
    tabController.animateTo(0);
    Get.toNamed(Routes.crmCarteiraClientePerfilTabPage);
  }

  _configureChildrenControllers() {
    //Clientes
		Get.put<CrmCarteiraClienteController>(CrmCarteiraClienteController()); 

  }
	
	_releaseChildrenControllers() {
    //Clientes
		Get.delete<CrmCarteiraClienteController>(); 

	}
  
  void updateControllersFromModel() {
    codigoController.text = currentModel.codigo ?? '';
    nomeController.text = currentModel.nome ?? '';

    formWasChanged = false;
    _updateChildrenControllersFromModel();
  }

  void _updateChildrenControllersFromModel() {
    //Clientes
		final crmCarteiraClienteController = Get.find<CrmCarteiraClienteController>(); 
		crmCarteiraClienteController.userMadeChanges = false; 

  }

  @override
  Future<void> save() async {
    if (!validateCurrentForm()) return;
    if (validateForms()) {
      if (userMadeChanges()) {
        final existingIndex = modelList.indexWhere((m) => m.id == currentModel.id);

        if (existingIndex >= 0) {
          modelList[existingIndex] = currentModel.clone();
        }

        final result = await repository.save(crmCarteiraClientePerfilModel: currentModel);
        if (result == null) return;

        if (existingIndex >= 0) {
          modelList[existingIndex] = result;
        } else {
          modelList.insert(0, result);
        }

        if (!GetPlatform.isMobile) {
          updateGridRow(result);
        }

        Get.back(result: true);
      } else {
        Get.back();
      }
    } 
  }


  List<Tab> tabItems = [
    Tab( 
			icon: Icon(iconDataList[Random().nextInt(10)]), 
			text: 'Perfil Carteira', 
		),
    Tab( 
			icon: Icon(iconDataList[Random().nextInt(10)]), 
			text: 'Clientes', 
		),
  ];

  List<Widget> tabPages() {
    return [
      CrmCarteiraClientePerfilEditPage(),
      const CrmCarteiraClienteListPage(),
    ];
  }

  @override
  void preventDataLoss() {
    if (userMadeChanges()) {
      showQuestionDialog('message_data_loss'.tr, () { 
        Get.back(); 
      });
    } else {
      Get.back();
    }
  }  

  bool userMadeChanges() {
    return
    formWasChanged 
    || 
		Get.find<CrmCarteiraClienteController>().userMadeChanges
    ;
  }

  void tabChange(int index) {
    validateCurrentForm();
  }

  bool validateCurrentForm() {
    return true;
  }

  bool validateForms() {
    return true;
  }

  @override
  void onInit() {
    super.onInit();
    tabController = TabController(vsync: this, length: tabItems.length);
    _configureChildrenControllers();
  }
	
  @override
  void onClose() {
    tabController.dispose();
    codigoController.dispose();
    nomeController.dispose();
    _releaseChildrenControllers();
    super.onClose();
  }	
}