import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:extended_masked_text/extended_masked_text.dart';
import 'package:crm/app/page/shared_widget/input/input_imports.dart';

import 'package:crm/app/page/shared_widget/message_dialog.dart';
import 'package:crm/app/page/grid_columns/grid_columns_imports.dart';
import 'package:crm/app/routes/app_routes.dart';
import 'package:crm/app/controller/controller_imports.dart';
import 'package:crm/app/data/model/model_imports.dart';
import 'package:crm/app/data/repository/crm_contato_repository.dart';

class CrmContatoController extends ControllerBase<CrmContatoModel, CrmContatoRepository> {

  CrmContatoController({required super.repository}) {
    dbColumns = CrmContatoModel.dbColumns;
    aliasColumns = CrmContatoModel.aliasColumns;
    gridColumns = crmContatoGridColumns();
    functionName = "crm_contato";
    screenTitle = "Contatos com o Cliente";
  }

  @override
  CrmContatoModel createNewModel() => CrmContatoModel();

  @override
  final standardFieldForFilter = CrmContatoModel.aliasColumns[CrmContatoModel.dbColumns.indexOf('tipo_contato')];

  final viewPessoaClienteModelController = TextEditingController();
  final viewPessoaColaboradorModelController = TextEditingController();
  final tipoContatoController = CustomDropdownButtonController('Telefone');
  final horaContatoController = MaskedTextController(mask: '00:00:00',);
  final assuntoController = TextEditingController();
  final descricaoController = TextEditingController();
  final resultadoController = CustomDropdownButtonController('Pendente');
  final proximaDataController = DatePickerItemController(null);
  final proximaAcaoController = TextEditingController();

  final Map<String, dynamic> mobileConfig = {
    'primaryColumns': ['tipo_contato'],
    'secondaryColumns': ['hora_contato'],
  };

  List<Map<String, dynamic>> get mobileItems {
    return modelList.map((crmContato) => crmContato.toJson).toList();
  }

  @override
  void prepareForInsert() {
    isNewRecord = true;
    currentModel = createNewModel();
    _resetForm();
    Get.toNamed(Routes.crmContatoEditPage);
  }

  void _resetForm() {
    formWasChanged = false;
    viewPessoaClienteModelController.text = '';
    viewPessoaColaboradorModelController.text = '';
    tipoContatoController.selected = 'Telefone';
    horaContatoController.text = '';
    assuntoController.text = '';
    descricaoController.text = '';
    resultadoController.selected = 'Pendente';
    proximaDataController.date = null;
    proximaAcaoController.text = '';
  }

  @override
  void selectRowForEditingById(int id) {
    final model = modelList.firstWhere((m) => m.id == id);
    currentModel = model.clone();
    updateControllersFromModel();
    Get.toNamed(Routes.crmContatoEditPage);
  }

  void updateControllersFromModel() {
    viewPessoaClienteModelController.text = currentModel.viewPessoaClienteModel?.nome?.toString() ?? '';
    viewPessoaColaboradorModelController.text = currentModel.viewPessoaColaboradorModel?.nome?.toString() ?? '';
    tipoContatoController.selected = currentModel.tipoContato ?? 'Telefone';
    horaContatoController.text = currentModel.horaContato ?? '';
    assuntoController.text = currentModel.assunto ?? '';
    descricaoController.text = currentModel.descricao ?? '';
    resultadoController.selected = currentModel.resultado ?? 'Pendente';
    proximaDataController.date = currentModel.proximaData;
    proximaAcaoController.text = currentModel.proximaAcao ?? '';
    formWasChanged = false;
  }

  @override
  Future<void> save() async {
    if (!formKey.currentState!.validate()) {
      showErrorSnackBar(message: 'validator_form_message'.tr);
      return;
    }

    final existingIndex = modelList.indexWhere((m) => m.id == currentModel.id);

    if (existingIndex >= 0) {
      modelList[existingIndex] = currentModel.clone();
    }

    final result = await repository.save(crmContatoModel: currentModel);
    if (result == null) return;

    if (existingIndex >= 0) {
      modelList[existingIndex] = result;
    } else {
      modelList.insert(0, result);
    }

    if (!GetPlatform.isMobile) {
      updateGridRow(result);
    }

    Get.back(result: true);
  }

  Future callViewPessoaClienteLookup() async { 
		final lookupController = Get.find<LookupController>(); 
		lookupController.refreshItems(standardValue: '%'); 
		lookupController.title = '${'lookup_page_title'.tr} [Cliente]'; 
		lookupController.route = '/view-pessoa-cliente/'; 
		lookupController.gridColumns = viewPessoaClienteGridColumns(isForLookup: true); 
		lookupController.aliasColumns = ViewPessoaClienteModel.aliasColumns; 
		lookupController.dbColumns = ViewPessoaClienteModel.dbColumns; 
		lookupController.standardColumn = ViewPessoaClienteModel.aliasColumns[ViewPessoaClienteModel.dbColumns.indexOf('nome')]; 

		final plutoRowResult = await Get.toNamed(Routes.lookupPage); 
		if (plutoRowResult != null) { 
			currentModel.idCliente = plutoRowResult.cells['id']!.value; 
			currentModel.viewPessoaClienteModel = ViewPessoaClienteModel.fromPlutoRow(plutoRowResult); 
			viewPessoaClienteModelController.text = currentModel.viewPessoaClienteModel?.nome ?? ''; 
			formWasChanged = true; 
		}
	}

  Future callViewPessoaColaboradorLookup() async { 
		final lookupController = Get.find<LookupController>(); 
		lookupController.refreshItems(standardValue: '%'); 
		lookupController.title = '${'lookup_page_title'.tr} [Id View Pessoa Colaborador]'; 
		lookupController.route = '/view-pessoa-colaborador/'; 
		lookupController.gridColumns = viewPessoaColaboradorGridColumns(isForLookup: true); 
		lookupController.aliasColumns = ViewPessoaColaboradorModel.aliasColumns; 
		lookupController.dbColumns = ViewPessoaColaboradorModel.dbColumns; 
		lookupController.standardColumn = ViewPessoaColaboradorModel.aliasColumns[ViewPessoaColaboradorModel.dbColumns.indexOf('nome')]; 

		final plutoRowResult = await Get.toNamed(Routes.lookupPage); 
		if (plutoRowResult != null) { 
			currentModel.idViewPessoaColaborador = plutoRowResult.cells['id']!.value; 
			currentModel.viewPessoaColaboradorModel = ViewPessoaColaboradorModel.fromPlutoRow(plutoRowResult); 
			viewPessoaColaboradorModelController.text = currentModel.viewPessoaColaboradorModel?.nome ?? ''; 
			formWasChanged = true; 
		}
	}


  @override
  void onClose() {
    viewPessoaClienteModelController.dispose();
    viewPessoaColaboradorModelController.dispose();
    tipoContatoController.dispose();
    horaContatoController.dispose();
    assuntoController.dispose();
    descricaoController.dispose();
    resultadoController.dispose();
    proximaDataController.dispose();
    proximaAcaoController.dispose();
    super.onClose();
  }

}