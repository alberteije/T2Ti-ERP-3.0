import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:pluto_grid/pluto_grid.dart';
import 'package:crm/app/page/shared_widget/input/input_imports.dart';
import 'package:crm/app/routes/app_routes.dart';

import 'package:crm/app/page/page_imports.dart';
import 'package:crm/app/page/shared_widget/message_dialog.dart';
import 'package:crm/app/page/grid_columns/grid_columns_imports.dart';
import 'package:crm/app/controller/controller_imports.dart';
import 'package:crm/app/data/model/model_imports.dart';

class CrmCampanhaClienteController extends ControllerBase<CrmCampanhaClienteModel, void> {

  CrmCampanhaClienteController() : super(repository: null) {
    dbColumns = CrmCampanhaClienteModel.dbColumns;
    aliasColumns = CrmCampanhaClienteModel.aliasColumns;
    gridColumns = crmCampanhaClienteGridColumns();
    functionName = "crm_campanha_cliente";
    screenTitle = "Clientes";
  }

  final _crmCampanhaClienteModel = CrmCampanhaClienteModel().obs;
  CrmCampanhaClienteModel get crmCampanhaClienteModel => _crmCampanhaClienteModel.value;
  set crmCampanhaClienteModel(value) => _crmCampanhaClienteModel.value = value ?? CrmCampanhaClienteModel();

  List<CrmCampanhaClienteModel> get crmCampanhaClienteModelList => Get.find<CrmCampanhaController>().currentModel.crmCampanhaClienteModelList ?? [];

  final _userMadeChanges = false.obs;
  get userMadeChanges => _userMadeChanges.value;
  set userMadeChanges(value) => _userMadeChanges.value = value;

  final _formWasChangedDetail = false.obs;
  bool get formWasChangedDetail => _formWasChangedDetail.value;
  set formWasChangedDetail(value) => _formWasChangedDetail.value = value;

  late PlutoGridStateManager _plutoGridStateManager;
  @override
  PlutoGridStateManager get plutoGridStateManager => _plutoGridStateManager;
  @override
  set plutoGridStateManager(value) => _plutoGridStateManager = value;

  final crmCampanhaClienteScaffoldKey = GlobalKey<ScaffoldState>();
  final crmCampanhaClienteFormKey = GlobalKey<FormState>();

  @override
  CrmCampanhaClienteModel createNewModel() => CrmCampanhaClienteModel();

  @override
  final standardFieldForFilter = CrmCampanhaClienteModel.aliasColumns[CrmCampanhaClienteModel.dbColumns.indexOf('data_inscricao')];

  final viewPessoaClienteModelController = TextEditingController();
  final dataInscricaoController = DatePickerItemController(null);
  final statusController = CustomDropdownButtonController('Inscrito');
  final observacoesController = TextEditingController();

  final Map<String, dynamic> mobileConfig = {
    'primaryColumns': ['data_inscricao'],
    'secondaryColumns': ['status'],
  };

  List<Map<String, dynamic>> get mobileItems {
    return modelList.map((crmCampanhaCliente) => crmCampanhaCliente.toJson).toList();
  }

  @override
  List<PlutoRow> plutoRows() => List<PlutoRow>.from(crmCampanhaClienteModelList.map((model) => model.toPlutoRow()));

  @override
  Future<void> getList({Filter? filter}) async {}

  @override
  void prepareForInsert() {
    isNewRecord = true;
    crmCampanhaClienteModel = createNewModel();
    _resetForm();
    Get.to(() => CrmCampanhaClienteEditPage());
  }

  void _resetForm() {
    formWasChangedDetail = false;
    viewPessoaClienteModelController.text = '';
    dataInscricaoController.date = null;
    statusController.selected = 'Inscrito';
    observacoesController.text = '';
  }

  @override
  void selectRowForEditing(PlutoRow? row) async {
    if (row == null) {
      showInfoSnackBar(message: 'message_select_one_to_edited'.tr);
      return;
    }

    selectRowForEditingByTempId(row.cells['tempId']?.value);
  }

  @override
  void selectRowForEditingById(int id) {}

  void selectRowForEditingByTempId(String tempId) {
		isNewRecord = false;
    final model = crmCampanhaClienteModelList.firstWhere((m) => m.tempId == tempId);
    crmCampanhaClienteModel = model.clone();
		crmCampanhaClienteModel.tempId = model.tempId;
    updateControllersFromModel();
    Get.to(() => CrmCampanhaClienteEditPage());
  }

  void updateControllersFromModel() {
    viewPessoaClienteModelController.text = crmCampanhaClienteModel.viewPessoaClienteModel?.nome?.toString() ?? '';
    dataInscricaoController.date = crmCampanhaClienteModel.dataInscricao;
    statusController.selected = crmCampanhaClienteModel.status ?? 'Inscrito';
    observacoesController.text = crmCampanhaClienteModel.observacoes ?? '';
    formWasChangedDetail = false;
  }

  @override
  Future<void> save() async {
    if (!crmCampanhaClienteFormKey.currentState!.validate()) {
      showErrorSnackBar(message: 'validator_form_message'.tr);
      return;
    }

    if (formWasChangedDetail) {
      if (isNewRecord) {
        crmCampanhaClienteModelList.insert(0, crmCampanhaClienteModel.clone());
      } else {
        final index = crmCampanhaClienteModelList.indexWhere((m) => m.tempId == crmCampanhaClienteModel.tempId);
        if (index >= 0) {
          crmCampanhaClienteModelList[index] = crmCampanhaClienteModel.clone();
        }
      }

      userMadeChanges = true;
      loadData();
      Get.back(result: true);
    } else {
      Get.back();
    }
  }

  Future callViewPessoaClienteLookup() async { 
		final lookupController = Get.find<LookupController>(); 
		lookupController.refreshItems(standardValue: '%'); 
		lookupController.title = '${'lookup_page_title'.tr} [Id Cliente]'; 
		lookupController.route = '/view-pessoa-cliente/'; 
		lookupController.gridColumns = viewPessoaClienteGridColumns(isForLookup: true); 
		lookupController.aliasColumns = ViewPessoaClienteModel.aliasColumns; 
		lookupController.dbColumns = ViewPessoaClienteModel.dbColumns; 
		lookupController.standardColumn = ViewPessoaClienteModel.aliasColumns[ViewPessoaClienteModel.dbColumns.indexOf('nome')]; 

		final plutoRowResult = await Get.toNamed(Routes.lookupPage); 
		if (plutoRowResult != null) { 
			crmCampanhaClienteModel.idCliente = plutoRowResult.cells['id']!.value; 
			crmCampanhaClienteModel.viewPessoaClienteModel = ViewPessoaClienteModel.fromPlutoRow(plutoRowResult); 
			viewPessoaClienteModelController.text = crmCampanhaClienteModel.viewPessoaClienteModel?.nome ?? ''; 
			formWasChangedDetail = true; 
		}
	}


  @override
  Future deleteSelected() async {
    final currentRow = plutoGridStateManager.currentRow;
    if (currentRow == null) {
      showInfoSnackBar(message: 'message_select_one_to_delete'.tr);
      return null;
    }
    showDeleteDialog(() async {
      final id = currentRow.cells['id']?.value;
      final tempId = currentRow.cells['tempId']?.value;
      crmCampanhaClienteModelList.removeWhere((model) => (id != 0 && model.id == id) || (id == 0 && model.tempId == tempId));
      plutoGridStateManager.removeCurrentRow();
      userMadeChanges = true;
    });
  }

  @override
  void preventDataLoss() {
    if (formWasChangedDetail) {
      showQuestionDialog('message_data_loss'.tr, () => Get.back());
    } else {
      formWasChangedDetail = false;
      Get.back();
    }
  }

  @override
  void onClose() {
    viewPessoaClienteModelController.dispose();
    dataInscricaoController.dispose();
    statusController.dispose();
    observacoesController.dispose();
  }

}