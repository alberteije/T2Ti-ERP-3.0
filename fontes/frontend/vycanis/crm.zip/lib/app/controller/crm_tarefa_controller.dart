import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:crm/app/page/shared_widget/input/input_imports.dart';

import 'package:crm/app/page/shared_widget/message_dialog.dart';
import 'package:crm/app/page/grid_columns/grid_columns_imports.dart';
import 'package:crm/app/routes/app_routes.dart';
import 'package:crm/app/controller/controller_imports.dart';
import 'package:crm/app/data/model/model_imports.dart';
import 'package:crm/app/data/repository/crm_tarefa_repository.dart';

class CrmTarefaController extends ControllerBase<CrmTarefaModel, CrmTarefaRepository> {

  CrmTarefaController({required super.repository}) {
    dbColumns = CrmTarefaModel.dbColumns;
    aliasColumns = CrmTarefaModel.aliasColumns;
    gridColumns = crmTarefaGridColumns();
    functionName = "crm_tarefa";
    screenTitle = "Tarefas";
  }

  @override
  CrmTarefaModel createNewModel() => CrmTarefaModel();

  @override
  final standardFieldForFilter = CrmTarefaModel.aliasColumns[CrmTarefaModel.dbColumns.indexOf('titulo')];

  final viewPessoaClienteModelController = TextEditingController();
  final crmOportunidadeModelController = TextEditingController();
  final tituloController = TextEditingController();
  final descricaoController = TextEditingController();
  final prioridadeController = CustomDropdownButtonController('Alta');
  final dataCriacaoController = DatePickerItemController(null);
  final dataVencimentoController = DatePickerItemController(null);
  final dataConclusaoController = DatePickerItemController(null);
  final statusController = CustomDropdownButtonController('Pendente');

  final Map<String, dynamic> mobileConfig = {
    'primaryColumns': ['titulo'],
    'secondaryColumns': ['descricao'],
  };

  List<Map<String, dynamic>> get mobileItems {
    return modelList.map((crmTarefa) => crmTarefa.toJson).toList();
  }

  @override
  void prepareForInsert() {
    isNewRecord = true;
    currentModel = createNewModel();
    _resetForm();
    Get.toNamed(Routes.crmTarefaEditPage);
  }

  void _resetForm() {
    formWasChanged = false;
    viewPessoaClienteModelController.text = '';
    crmOportunidadeModelController.text = '';
    tituloController.text = '';
    descricaoController.text = '';
    prioridadeController.selected = 'Alta';
    dataCriacaoController.date = null;
    dataVencimentoController.date = null;
    dataConclusaoController.date = null;
    statusController.selected = 'Pendente';
  }

  @override
  void selectRowForEditingById(int id) {
    final model = modelList.firstWhere((m) => m.id == id);
    currentModel = model.clone();
    updateControllersFromModel();
    Get.toNamed(Routes.crmTarefaEditPage);
  }

  void updateControllersFromModel() {
    viewPessoaClienteModelController.text = currentModel.viewPessoaClienteModel?.nome?.toString() ?? '';
    crmOportunidadeModelController.text = currentModel.crmOportunidadeModel?.titulo?.toString() ?? '';
    tituloController.text = currentModel.titulo ?? '';
    descricaoController.text = currentModel.descricao ?? '';
    prioridadeController.selected = currentModel.prioridade ?? 'Alta';
    dataCriacaoController.date = currentModel.dataCriacao;
    dataVencimentoController.date = currentModel.dataVencimento;
    dataConclusaoController.date = currentModel.dataConclusao;
    statusController.selected = currentModel.status ?? 'Pendente';
    formWasChanged = false;
  }

  @override
  Future<void> save() async {
    if (!formKey.currentState!.validate()) {
      showErrorSnackBar(message: 'validator_form_message'.tr);
      return;
    }

    final existingIndex = modelList.indexWhere((m) => m.id == currentModel.id);

    if (existingIndex >= 0) {
      modelList[existingIndex] = currentModel.clone();
    }

    final result = await repository.save(crmTarefaModel: currentModel);
    if (result == null) return;

    if (existingIndex >= 0) {
      modelList[existingIndex] = result;
    } else {
      modelList.insert(0, result);
    }

    if (!GetPlatform.isMobile) {
      updateGridRow(result);
    }

    Get.back(result: true);
  }

  Future callViewPessoaClienteLookup() async { 
		final lookupController = Get.find<LookupController>(); 
		lookupController.refreshItems(standardValue: '%'); 
		lookupController.title = '${'lookup_page_title'.tr} [Cliente]'; 
		lookupController.route = '/view-pessoa-cliente/'; 
		lookupController.gridColumns = viewPessoaClienteGridColumns(isForLookup: true); 
		lookupController.aliasColumns = ViewPessoaClienteModel.aliasColumns; 
		lookupController.dbColumns = ViewPessoaClienteModel.dbColumns; 
		lookupController.standardColumn = ViewPessoaClienteModel.aliasColumns[ViewPessoaClienteModel.dbColumns.indexOf('nome')]; 

		final plutoRowResult = await Get.toNamed(Routes.lookupPage); 
		if (plutoRowResult != null) { 
			currentModel.idCliente = plutoRowResult.cells['id']!.value; 
			currentModel.viewPessoaClienteModel = ViewPessoaClienteModel.fromPlutoRow(plutoRowResult); 
			viewPessoaClienteModelController.text = currentModel.viewPessoaClienteModel?.nome ?? ''; 
			formWasChanged = true; 
		}
	}

  Future callCrmOportunidadeLookup() async { 
		final lookupController = Get.find<LookupController>(); 
		lookupController.refreshItems(standardValue: '%'); 
		lookupController.title = '${'lookup_page_title'.tr} [Oportunidade]'; 
		lookupController.route = '/crm-oportunidade/'; 
		lookupController.gridColumns = crmOportunidadeGridColumns(isForLookup: true); 
		lookupController.aliasColumns = CrmOportunidadeModel.aliasColumns; 
		lookupController.dbColumns = CrmOportunidadeModel.dbColumns; 
		lookupController.standardColumn = CrmOportunidadeModel.aliasColumns[CrmOportunidadeModel.dbColumns.indexOf('titulo')]; 

		final plutoRowResult = await Get.toNamed(Routes.lookupPage); 
		if (plutoRowResult != null) { 
			currentModel.idOportunidade = plutoRowResult.cells['id']!.value; 
			currentModel.crmOportunidadeModel = CrmOportunidadeModel.fromPlutoRow(plutoRowResult); 
			crmOportunidadeModelController.text = currentModel.crmOportunidadeModel?.titulo ?? ''; 
			formWasChanged = true; 
		}
	}


  @override
  void onClose() {
    viewPessoaClienteModelController.dispose();
    crmOportunidadeModelController.dispose();
    tituloController.dispose();
    descricaoController.dispose();
    prioridadeController.dispose();
    dataCriacaoController.dispose();
    dataVencimentoController.dispose();
    dataConclusaoController.dispose();
    statusController.dispose();
    super.onClose();
  }

}