import 'package:flutter/material.dart';
import 'dart:math';
import 'package:get/get.dart';
import 'package:extended_masked_text/extended_masked_text.dart';
import 'package:crm/app/page/shared_widget/input/input_imports.dart';

import 'package:crm/app/infra/infra_imports.dart';
import 'package:crm/app/page/page_imports.dart';
import 'package:crm/app/page/shared_widget/message_dialog.dart';
import 'package:crm/app/page/grid_columns/grid_columns_imports.dart';
import 'package:crm/app/routes/app_routes.dart';
import 'package:crm/app/controller/controller_imports.dart';
import 'package:crm/app/data/model/model_imports.dart';
import 'package:crm/app/data/repository/crm_campanha_repository.dart';

class CrmCampanhaController extends ControllerBase<CrmCampanhaModel, CrmCampanhaRepository> 
with GetSingleTickerProviderStateMixin {

  CrmCampanhaController({required super.repository}) {
    dbColumns = CrmCampanhaModel.dbColumns;
    aliasColumns = CrmCampanhaModel.aliasColumns;
    gridColumns = crmCampanhaGridColumns();
    functionName = "crm_campanha";
    screenTitle = "Campanha";
  }

  final crmCampanhaScaffoldKey = GlobalKey<ScaffoldState>();
  final crmCampanhaTabPageScaffoldKey = GlobalKey<ScaffoldState>();
  final crmCampanhaFormKey = GlobalKey<FormState>();
  late TabController tabController;
  String? mandatoryMessage;  

  @override
  CrmCampanhaModel createNewModel() => CrmCampanhaModel();

  @override
  final standardFieldForFilter = CrmCampanhaModel.aliasColumns[CrmCampanhaModel.dbColumns.indexOf('nome')];

  final nomeController = TextEditingController();
  final descricaoController = TextEditingController();
  final tipoController = CustomDropdownButtonController('EMail');
  final dataInicioController = DatePickerItemController(null);
  final dataFimController = DatePickerItemController(null);
  final orcamentoController = MoneyMaskedTextController();
  final statusController = CustomDropdownButtonController('Planejada');

  final Map<String, dynamic> mobileConfig = {
    'primaryColumns': ['nome'],
    'secondaryColumns': ['descricao'],
  };

  List<Map<String, dynamic>> get mobileItems {
    return modelList.map((crmCampanha) => crmCampanha.toJson).toList();
  }

  @override
  void prepareForInsert() {
    isNewRecord = true;
    currentModel = createNewModel();
    _resetForm();
    tabController.animateTo(0);
    updateControllersFromModel();
    Get.toNamed(Routes.crmCampanhaTabPage);
  }

  void _resetForm() {
    formWasChanged = false;
    nomeController.text = '';
    descricaoController.text = '';
    tipoController.selected = 'EMail';
    dataInicioController.date = null;
    dataFimController.date = null;
    orcamentoController.updateValue(0);
    statusController.selected = 'Planejada';
  }

  @override
  void selectRowForEditingById(int id) {
    final model = modelList.firstWhere((m) => m.id == id);
    currentModel = model.clone();
    updateControllersFromModel();
    tabController.animateTo(0);
    Get.toNamed(Routes.crmCampanhaTabPage);
  }

  _configureChildrenControllers() {
    //Clientes
		Get.put<CrmCampanhaClienteController>(CrmCampanhaClienteController()); 

  }
	
	_releaseChildrenControllers() {
    //Clientes
		Get.delete<CrmCampanhaClienteController>(); 

	}
  
  void updateControllersFromModel() {
    nomeController.text = currentModel.nome ?? '';
    descricaoController.text = currentModel.descricao ?? '';
    tipoController.selected = currentModel.tipo ?? 'EMail';
    dataInicioController.date = currentModel.dataInicio;
    dataFimController.date = currentModel.dataFim;
    orcamentoController.updateValue(currentModel.orcamento ?? 0);
    statusController.selected = currentModel.status ?? 'Planejada';

    formWasChanged = false;
    _updateChildrenControllersFromModel();
  }

  void _updateChildrenControllersFromModel() {
    //Clientes
		final crmCampanhaClienteController = Get.find<CrmCampanhaClienteController>(); 
		crmCampanhaClienteController.userMadeChanges = false; 

  }

  @override
  Future<void> save() async {
    if (!validateCurrentForm()) return;
    if (validateForms()) {
      if (userMadeChanges()) {
        final existingIndex = modelList.indexWhere((m) => m.id == currentModel.id);

        if (existingIndex >= 0) {
          modelList[existingIndex] = currentModel.clone();
        }

        final result = await repository.save(crmCampanhaModel: currentModel);
        if (result == null) return;

        if (existingIndex >= 0) {
          modelList[existingIndex] = result;
        } else {
          modelList.insert(0, result);
        }

        if (!GetPlatform.isMobile) {
          updateGridRow(result);
        }

        Get.back(result: true);
      } else {
        Get.back();
      }
    } 
  }


  List<Tab> tabItems = [
    Tab( 
			icon: Icon(iconDataList[Random().nextInt(10)]), 
			text: 'Campanha', 
		),
    Tab( 
			icon: Icon(iconDataList[Random().nextInt(10)]), 
			text: 'Clientes', 
		),
  ];

  List<Widget> tabPages() {
    return [
      CrmCampanhaEditPage(),
      const CrmCampanhaClienteListPage(),
    ];
  }

  @override
  void preventDataLoss() {
    if (userMadeChanges()) {
      showQuestionDialog('message_data_loss'.tr, () { 
        Get.back(); 
      });
    } else {
      Get.back();
    }
  }  

  bool userMadeChanges() {
    return
    formWasChanged 
    || 
		Get.find<CrmCampanhaClienteController>().userMadeChanges
    ;
  }

  void tabChange(int index) {
    validateCurrentForm();
  }

  bool validateCurrentForm() {
    return true;
  }

  bool validateForms() {
    return true;
  }

  @override
  void onInit() {
    super.onInit();
    tabController = TabController(vsync: this, length: tabItems.length);
    _configureChildrenControllers();
  }
	
  @override
  void onClose() {
    tabController.dispose();
    nomeController.dispose();
    descricaoController.dispose();
    tipoController.dispose();
    dataInicioController.dispose();
    dataFimController.dispose();
    orcamentoController.dispose();
    statusController.dispose();
    _releaseChildrenControllers();
    super.onClose();
  }	
}