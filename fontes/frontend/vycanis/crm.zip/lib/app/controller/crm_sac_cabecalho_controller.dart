import 'package:flutter/material.dart';
import 'dart:math';
import 'package:get/get.dart';
import 'package:extended_masked_text/extended_masked_text.dart';
import 'package:crm/app/page/shared_widget/input/input_imports.dart';

import 'package:crm/app/infra/infra_imports.dart';
import 'package:crm/app/page/page_imports.dart';
import 'package:crm/app/page/shared_widget/message_dialog.dart';
import 'package:crm/app/page/grid_columns/grid_columns_imports.dart';
import 'package:crm/app/routes/app_routes.dart';
import 'package:crm/app/controller/controller_imports.dart';
import 'package:crm/app/data/model/model_imports.dart';
import 'package:crm/app/data/repository/crm_sac_cabecalho_repository.dart';

class CrmSacCabecalhoController extends ControllerBase<CrmSacCabecalhoModel, CrmSacCabecalhoRepository> 
with GetSingleTickerProviderStateMixin {

  CrmSacCabecalhoController({required super.repository}) {
    dbColumns = CrmSacCabecalhoModel.dbColumns;
    aliasColumns = CrmSacCabecalhoModel.aliasColumns;
    gridColumns = crmSacCabecalhoGridColumns();
    functionName = "crm_sac_cabecalho";
    screenTitle = "SAC";
  }

  final crmSacCabecalhoScaffoldKey = GlobalKey<ScaffoldState>();
  final crmSacCabecalhoTabPageScaffoldKey = GlobalKey<ScaffoldState>();
  final crmSacCabecalhoFormKey = GlobalKey<FormState>();
  late TabController tabController;
  String? mandatoryMessage;  

  @override
  CrmSacCabecalhoModel createNewModel() => CrmSacCabecalhoModel();

  @override
  final standardFieldForFilter = CrmSacCabecalhoModel.aliasColumns[CrmSacCabecalhoModel.dbColumns.indexOf('data_abertura')];

  final viewPessoaClienteModelController = TextEditingController();
  final dataAberturaController = DatePickerItemController(null);
  final horaAberturaController = MaskedTextController(mask: '00:00:00',);
  final nivelReclamacaoController = CustomDropdownButtonController('Normal');
  final numeroProtocoloController = TextEditingController();

  final Map<String, dynamic> mobileConfig = {
    'primaryColumns': ['data_abertura'],
    'secondaryColumns': ['hora_abertura'],
  };

  List<Map<String, dynamic>> get mobileItems {
    return modelList.map((crmSacCabecalho) => crmSacCabecalho.toJson).toList();
  }

  @override
  void prepareForInsert() {
    isNewRecord = true;
    currentModel = createNewModel();
    _resetForm();
    tabController.animateTo(0);
    updateControllersFromModel();
    Get.toNamed(Routes.crmSacCabecalhoTabPage);
  }

  void _resetForm() {
    formWasChanged = false;
    viewPessoaClienteModelController.text = '';
    dataAberturaController.date = null;
    horaAberturaController.text = '';
    nivelReclamacaoController.selected = 'Normal';
    numeroProtocoloController.text = '';
  }

  @override
  void selectRowForEditingById(int id) {
    final model = modelList.firstWhere((m) => m.id == id);
    currentModel = model.clone();
    updateControllersFromModel();
    tabController.animateTo(0);
    Get.toNamed(Routes.crmSacCabecalhoTabPage);
  }

  _configureChildrenControllers() {
    //Detalhes
		Get.put<CrmSacDetalheController>(CrmSacDetalheController()); 

  }
	
	_releaseChildrenControllers() {
    //Detalhes
		Get.delete<CrmSacDetalheController>(); 

	}
  
  void updateControllersFromModel() {
    viewPessoaClienteModelController.text = currentModel.viewPessoaClienteModel?.nome?.toString() ?? '';
    dataAberturaController.date = currentModel.dataAbertura;
    horaAberturaController.text = currentModel.horaAbertura ?? '';
    nivelReclamacaoController.selected = currentModel.nivelReclamacao ?? 'Normal';
    numeroProtocoloController.text = currentModel.numeroProtocolo ?? '';

    formWasChanged = false;
    _updateChildrenControllersFromModel();
  }

  void _updateChildrenControllersFromModel() {
    //Detalhes
		final crmSacDetalheController = Get.find<CrmSacDetalheController>(); 
		crmSacDetalheController.userMadeChanges = false; 

  }

  @override
  Future<void> save() async {
    if (!validateCurrentForm()) return;
    if (validateForms()) {
      if (userMadeChanges()) {
        final existingIndex = modelList.indexWhere((m) => m.id == currentModel.id);

        if (existingIndex >= 0) {
          modelList[existingIndex] = currentModel.clone();
        }

        final result = await repository.save(crmSacCabecalhoModel: currentModel);
        if (result == null) return;

        if (existingIndex >= 0) {
          modelList[existingIndex] = result;
        } else {
          modelList.insert(0, result);
        }

        if (!GetPlatform.isMobile) {
          updateGridRow(result);
        }

        Get.back(result: true);
      } else {
        Get.back();
      }
    } 
  }

  Future callViewPessoaClienteLookup() async { 
		final lookupController = Get.find<LookupController>(); 
		lookupController.refreshItems(standardValue: '%'); 
		lookupController.title = '${'lookup_page_title'.tr} [Id Cliente]'; 
		lookupController.route = '/view-pessoa-cliente/'; 
		lookupController.gridColumns = viewPessoaClienteGridColumns(isForLookup: true); 
		lookupController.aliasColumns = ViewPessoaClienteModel.aliasColumns; 
		lookupController.dbColumns = ViewPessoaClienteModel.dbColumns; 
		lookupController.standardColumn = ViewPessoaClienteModel.aliasColumns[ViewPessoaClienteModel.dbColumns.indexOf('nome')]; 

		final plutoRowResult = await Get.toNamed(Routes.lookupPage); 
		if (plutoRowResult != null) { 
			currentModel.idCliente = plutoRowResult.cells['id']!.value; 
			currentModel.viewPessoaClienteModel = ViewPessoaClienteModel.fromPlutoRow(plutoRowResult); 
			viewPessoaClienteModelController.text = currentModel.viewPessoaClienteModel?.nome ?? ''; 
			formWasChanged = true; 
		}
	}


  List<Tab> tabItems = [
    Tab( 
			icon: Icon(iconDataList[Random().nextInt(10)]), 
			text: 'SAC', 
		),
    Tab( 
			icon: Icon(iconDataList[Random().nextInt(10)]), 
			text: 'Detalhes', 
		),
  ];

  List<Widget> tabPages() {
    return [
      CrmSacCabecalhoEditPage(),
      const CrmSacDetalheListPage(),
    ];
  }

  @override
  void preventDataLoss() {
    if (userMadeChanges()) {
      showQuestionDialog('message_data_loss'.tr, () { 
        Get.back(); 
      });
    } else {
      Get.back();
    }
  }  

  bool userMadeChanges() {
    return
    formWasChanged 
    || 
		Get.find<CrmSacDetalheController>().userMadeChanges
    ;
  }

  void tabChange(int index) {
    validateCurrentForm();
  }

  bool validateCurrentForm() {
    mandatoryMessage = ValidateFormField.validateMandatory(currentModel.viewPessoaClienteModel?.nome); 
		if (mandatoryMessage != null) { 
			tabController.animateTo(0); 
			showErrorSnackBar(message: '$mandatoryMessage [Id Cliente]'); 
			return false; 
		}
    return true;
  }

  bool validateForms() {
    return true;
  }

  @override
  void onInit() {
    super.onInit();
    tabController = TabController(vsync: this, length: tabItems.length);
    _configureChildrenControllers();
  }
	
  @override
  void onClose() {
    tabController.dispose();
    viewPessoaClienteModelController.dispose();
    dataAberturaController.dispose();
    horaAberturaController.dispose();
    nivelReclamacaoController.dispose();
    numeroProtocoloController.dispose();
    _releaseChildrenControllers();
    super.onClose();
  }	
}