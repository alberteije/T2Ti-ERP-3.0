import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:extended_masked_text/extended_masked_text.dart';
import 'package:crm/app/page/shared_widget/input/input_imports.dart';

import 'package:crm/app/page/shared_widget/message_dialog.dart';
import 'package:crm/app/page/grid_columns/grid_columns_imports.dart';
import 'package:crm/app/routes/app_routes.dart';
import 'package:crm/app/controller/controller_imports.dart';
import 'package:crm/app/data/model/model_imports.dart';
import 'package:crm/app/data/repository/crm_buscas_cliente_repository.dart';

class CrmBuscasClienteController extends ControllerBase<CrmBuscasClienteModel, CrmBuscasClienteRepository> {

  CrmBuscasClienteController({required super.repository}) {
    dbColumns = CrmBuscasClienteModel.dbColumns;
    aliasColumns = CrmBuscasClienteModel.aliasColumns;
    gridColumns = crmBuscasClienteGridColumns();
    functionName = "crm_buscas_cliente";
    screenTitle = "Buscas do Cliente";
  }

  @override
  CrmBuscasClienteModel createNewModel() => CrmBuscasClienteModel();

  @override
  final standardFieldForFilter = CrmBuscasClienteModel.aliasColumns[CrmBuscasClienteModel.dbColumns.indexOf('data_busca')];

  final viewPessoaClienteModelController = TextEditingController();
  final dataBuscaController = DatePickerItemController(null);
  final horaBuscaController = MaskedTextController(mask: '00:00:00',);
  final detalhesController = TextEditingController();

  final Map<String, dynamic> mobileConfig = {
    'primaryColumns': ['data_busca'],
    'secondaryColumns': ['hora_busca'],
  };

  List<Map<String, dynamic>> get mobileItems {
    return modelList.map((crmBuscasCliente) => crmBuscasCliente.toJson).toList();
  }

  @override
  void prepareForInsert() {
    isNewRecord = true;
    currentModel = createNewModel();
    _resetForm();
    Get.toNamed(Routes.crmBuscasClienteEditPage);
  }

  void _resetForm() {
    formWasChanged = false;
    viewPessoaClienteModelController.text = '';
    dataBuscaController.date = null;
    horaBuscaController.text = '';
    detalhesController.text = '';
  }

  @override
  void selectRowForEditingById(int id) {
    final model = modelList.firstWhere((m) => m.id == id);
    currentModel = model.clone();
    updateControllersFromModel();
    Get.toNamed(Routes.crmBuscasClienteEditPage);
  }

  void updateControllersFromModel() {
    viewPessoaClienteModelController.text = currentModel.viewPessoaClienteModel?.nome?.toString() ?? '';
    dataBuscaController.date = currentModel.dataBusca;
    horaBuscaController.text = currentModel.horaBusca ?? '';
    detalhesController.text = currentModel.detalhes ?? '';
    formWasChanged = false;
  }

  @override
  Future<void> save() async {
    if (!formKey.currentState!.validate()) {
      showErrorSnackBar(message: 'validator_form_message'.tr);
      return;
    }

    final existingIndex = modelList.indexWhere((m) => m.id == currentModel.id);

    if (existingIndex >= 0) {
      modelList[existingIndex] = currentModel.clone();
    }

    final result = await repository.save(crmBuscasClienteModel: currentModel);
    if (result == null) return;

    if (existingIndex >= 0) {
      modelList[existingIndex] = result;
    } else {
      modelList.insert(0, result);
    }

    if (!GetPlatform.isMobile) {
      updateGridRow(result);
    }

    Get.back(result: true);
  }

  Future callViewPessoaClienteLookup() async { 
		final lookupController = Get.find<LookupController>(); 
		lookupController.refreshItems(standardValue: '%'); 
		lookupController.title = '${'lookup_page_title'.tr} [Cliente]'; 
		lookupController.route = '/view-pessoa-cliente/'; 
		lookupController.gridColumns = viewPessoaClienteGridColumns(isForLookup: true); 
		lookupController.aliasColumns = ViewPessoaClienteModel.aliasColumns; 
		lookupController.dbColumns = ViewPessoaClienteModel.dbColumns; 
		lookupController.standardColumn = ViewPessoaClienteModel.aliasColumns[ViewPessoaClienteModel.dbColumns.indexOf('nome')]; 

		final plutoRowResult = await Get.toNamed(Routes.lookupPage); 
		if (plutoRowResult != null) { 
			currentModel.idCliente = plutoRowResult.cells['id']!.value; 
			currentModel.viewPessoaClienteModel = ViewPessoaClienteModel.fromPlutoRow(plutoRowResult); 
			viewPessoaClienteModelController.text = currentModel.viewPessoaClienteModel?.nome ?? ''; 
			formWasChanged = true; 
		}
	}


  @override
  void onClose() {
    viewPessoaClienteModelController.dispose();
    dataBuscaController.dispose();
    horaBuscaController.dispose();
    detalhesController.dispose();
    super.onClose();
  }

}