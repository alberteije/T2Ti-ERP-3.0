import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:pluto_grid/pluto_grid.dart';
import 'package:crm/app/routes/app_routes.dart';

import 'package:crm/app/page/page_imports.dart';
import 'package:crm/app/page/shared_widget/message_dialog.dart';
import 'package:crm/app/page/grid_columns/grid_columns_imports.dart';
import 'package:crm/app/controller/controller_imports.dart';
import 'package:crm/app/data/model/model_imports.dart';

class CrmCarteiraClienteController extends ControllerBase<CrmCarteiraClienteModel, void> {

  CrmCarteiraClienteController() : super(repository: null) {
    dbColumns = CrmCarteiraClienteModel.dbColumns;
    aliasColumns = CrmCarteiraClienteModel.aliasColumns;
    gridColumns = crmCarteiraClienteGridColumns();
    functionName = "crm_carteira_cliente";
    screenTitle = "Clientes";
  }

  final _crmCarteiraClienteModel = CrmCarteiraClienteModel().obs;
  CrmCarteiraClienteModel get crmCarteiraClienteModel => _crmCarteiraClienteModel.value;
  set crmCarteiraClienteModel(value) => _crmCarteiraClienteModel.value = value ?? CrmCarteiraClienteModel();

  List<CrmCarteiraClienteModel> get crmCarteiraClienteModelList => Get.find<CrmCarteiraClientePerfilController>().currentModel.crmCarteiraClienteModelList ?? [];

  final _userMadeChanges = false.obs;
  get userMadeChanges => _userMadeChanges.value;
  set userMadeChanges(value) => _userMadeChanges.value = value;

  final _formWasChangedDetail = false.obs;
  bool get formWasChangedDetail => _formWasChangedDetail.value;
  set formWasChangedDetail(value) => _formWasChangedDetail.value = value;

  late PlutoGridStateManager _plutoGridStateManager;
  @override
  PlutoGridStateManager get plutoGridStateManager => _plutoGridStateManager;
  @override
  set plutoGridStateManager(value) => _plutoGridStateManager = value;

  final crmCarteiraClienteScaffoldKey = GlobalKey<ScaffoldState>();
  final crmCarteiraClienteFormKey = GlobalKey<FormState>();

  @override
  CrmCarteiraClienteModel createNewModel() => CrmCarteiraClienteModel();

  @override
  final standardFieldForFilter = CrmCarteiraClienteModel.aliasColumns[CrmCarteiraClienteModel.dbColumns.indexOf('id')];

  final viewPessoaClienteModelController = TextEditingController();

  final Map<String, dynamic> mobileConfig = {
    'primaryColumns': [],
    'secondaryColumns': [],
  };

  List<Map<String, dynamic>> get mobileItems {
    return modelList.map((crmCarteiraCliente) => crmCarteiraCliente.toJson).toList();
  }

  @override
  List<PlutoRow> plutoRows() => List<PlutoRow>.from(crmCarteiraClienteModelList.map((model) => model.toPlutoRow()));

  @override
  Future<void> getList({Filter? filter}) async {}

  @override
  void prepareForInsert() {
    isNewRecord = true;
    crmCarteiraClienteModel = createNewModel();
    _resetForm();
    Get.to(() => CrmCarteiraClienteEditPage());
  }

  void _resetForm() {
    formWasChangedDetail = false;
    viewPessoaClienteModelController.text = '';
  }

  @override
  void selectRowForEditing(PlutoRow? row) async {
    if (row == null) {
      showInfoSnackBar(message: 'message_select_one_to_edited'.tr);
      return;
    }

    selectRowForEditingByTempId(row.cells['tempId']?.value);
  }

  @override
  void selectRowForEditingById(int id) {}

  void selectRowForEditingByTempId(String tempId) {
		isNewRecord = false;
    final model = crmCarteiraClienteModelList.firstWhere((m) => m.tempId == tempId);
    crmCarteiraClienteModel = model.clone();
		crmCarteiraClienteModel.tempId = model.tempId;
    updateControllersFromModel();
    Get.to(() => CrmCarteiraClienteEditPage());
  }

  void updateControllersFromModel() {
    viewPessoaClienteModelController.text = crmCarteiraClienteModel.viewPessoaClienteModel?.nome?.toString() ?? '';
    formWasChangedDetail = false;
  }

  @override
  Future<void> save() async {
    if (!crmCarteiraClienteFormKey.currentState!.validate()) {
      showErrorSnackBar(message: 'validator_form_message'.tr);
      return;
    }

    if (formWasChangedDetail) {
      if (isNewRecord) {
        crmCarteiraClienteModelList.insert(0, crmCarteiraClienteModel.clone());
      } else {
        final index = crmCarteiraClienteModelList.indexWhere((m) => m.tempId == crmCarteiraClienteModel.tempId);
        if (index >= 0) {
          crmCarteiraClienteModelList[index] = crmCarteiraClienteModel.clone();
        }
      }

      userMadeChanges = true;
      loadData();
      Get.back(result: true);
    } else {
      Get.back();
    }
  }

  Future callViewPessoaClienteLookup() async { 
		final lookupController = Get.find<LookupController>(); 
		lookupController.refreshItems(standardValue: '%'); 
		lookupController.title = '${'lookup_page_title'.tr} [Cliente]'; 
		lookupController.route = '/view-pessoa-cliente/'; 
		lookupController.gridColumns = viewPessoaClienteGridColumns(isForLookup: true); 
		lookupController.aliasColumns = ViewPessoaClienteModel.aliasColumns; 
		lookupController.dbColumns = ViewPessoaClienteModel.dbColumns; 
		lookupController.standardColumn = ViewPessoaClienteModel.aliasColumns[ViewPessoaClienteModel.dbColumns.indexOf('nome')]; 

		final plutoRowResult = await Get.toNamed(Routes.lookupPage); 
		if (plutoRowResult != null) { 
			crmCarteiraClienteModel.idCliente = plutoRowResult.cells['id']!.value; 
			crmCarteiraClienteModel.viewPessoaClienteModel = ViewPessoaClienteModel.fromPlutoRow(plutoRowResult); 
			viewPessoaClienteModelController.text = crmCarteiraClienteModel.viewPessoaClienteModel?.nome ?? ''; 
			formWasChangedDetail = true; 
		}
	}


  @override
  Future deleteSelected() async {
    final currentRow = plutoGridStateManager.currentRow;
    if (currentRow == null) {
      showInfoSnackBar(message: 'message_select_one_to_delete'.tr);
      return null;
    }
    showDeleteDialog(() async {
      final id = currentRow.cells['id']?.value;
      final tempId = currentRow.cells['tempId']?.value;
      crmCarteiraClienteModelList.removeWhere((model) => (id != 0 && model.id == id) || (id == 0 && model.tempId == tempId));
      plutoGridStateManager.removeCurrentRow();
      userMadeChanges = true;
    });
  }

  @override
  void preventDataLoss() {
    if (formWasChangedDetail) {
      showQuestionDialog('message_data_loss'.tr, () => Get.back());
    } else {
      formWasChangedDetail = false;
      Get.back();
    }
  }

  @override
  void onClose() {
    viewPessoaClienteModelController.dispose();
  }

}