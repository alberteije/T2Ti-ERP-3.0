import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:pluto_grid/pluto_grid.dart';
import 'package:extended_masked_text/extended_masked_text.dart';
import 'package:crm/app/page/shared_widget/input/input_imports.dart';
import 'package:crm/app/routes/app_routes.dart';

import 'package:crm/app/page/page_imports.dart';
import 'package:crm/app/page/shared_widget/message_dialog.dart';
import 'package:crm/app/page/grid_columns/grid_columns_imports.dart';
import 'package:crm/app/controller/controller_imports.dart';
import 'package:crm/app/data/model/model_imports.dart';

class CrmSacDetalheController extends ControllerBase<CrmSacDetalheModel, void> {

  CrmSacDetalheController() : super(repository: null) {
    dbColumns = CrmSacDetalheModel.dbColumns;
    aliasColumns = CrmSacDetalheModel.aliasColumns;
    gridColumns = crmSacDetalheGridColumns();
    functionName = "crm_sac_detalhe";
    screenTitle = "Detalhes";
  }

  final _crmSacDetalheModel = CrmSacDetalheModel().obs;
  CrmSacDetalheModel get crmSacDetalheModel => _crmSacDetalheModel.value;
  set crmSacDetalheModel(value) => _crmSacDetalheModel.value = value ?? CrmSacDetalheModel();

  List<CrmSacDetalheModel> get crmSacDetalheModelList => Get.find<CrmSacCabecalhoController>().currentModel.crmSacDetalheModelList ?? [];

  final _userMadeChanges = false.obs;
  get userMadeChanges => _userMadeChanges.value;
  set userMadeChanges(value) => _userMadeChanges.value = value;

  final _formWasChangedDetail = false.obs;
  bool get formWasChangedDetail => _formWasChangedDetail.value;
  set formWasChangedDetail(value) => _formWasChangedDetail.value = value;

  late PlutoGridStateManager _plutoGridStateManager;
  @override
  PlutoGridStateManager get plutoGridStateManager => _plutoGridStateManager;
  @override
  set plutoGridStateManager(value) => _plutoGridStateManager = value;

  final crmSacDetalheScaffoldKey = GlobalKey<ScaffoldState>();
  final crmSacDetalheFormKey = GlobalKey<FormState>();

  @override
  CrmSacDetalheModel createNewModel() => CrmSacDetalheModel();

  @override
  final standardFieldForFilter = CrmSacDetalheModel.aliasColumns[CrmSacDetalheModel.dbColumns.indexOf('data_registro')];

  final viewPessoaColaboradorModelController = TextEditingController();
  final dataRegistroController = DatePickerItemController(null);
  final horaRegistroController = MaskedTextController(mask: '00:00:00',);
  final historicoController = TextEditingController();

  final Map<String, dynamic> mobileConfig = {
    'primaryColumns': ['data_registro'],
    'secondaryColumns': ['hora_registro'],
  };

  List<Map<String, dynamic>> get mobileItems {
    return modelList.map((crmSacDetalhe) => crmSacDetalhe.toJson).toList();
  }

  @override
  List<PlutoRow> plutoRows() => List<PlutoRow>.from(crmSacDetalheModelList.map((model) => model.toPlutoRow()));

  @override
  Future<void> getList({Filter? filter}) async {}

  @override
  void prepareForInsert() {
    isNewRecord = true;
    crmSacDetalheModel = createNewModel();
    _resetForm();
    Get.to(() => CrmSacDetalheEditPage());
  }

  void _resetForm() {
    formWasChangedDetail = false;
    viewPessoaColaboradorModelController.text = '';
    dataRegistroController.date = null;
    horaRegistroController.text = '';
    historicoController.text = '';
  }

  @override
  void selectRowForEditing(PlutoRow? row) async {
    if (row == null) {
      showInfoSnackBar(message: 'message_select_one_to_edited'.tr);
      return;
    }

    selectRowForEditingByTempId(row.cells['tempId']?.value);
  }

  @override
  void selectRowForEditingById(int id) {}

  void selectRowForEditingByTempId(String tempId) {
		isNewRecord = false;
    final model = crmSacDetalheModelList.firstWhere((m) => m.tempId == tempId);
    crmSacDetalheModel = model.clone();
		crmSacDetalheModel.tempId = model.tempId;
    updateControllersFromModel();
    Get.to(() => CrmSacDetalheEditPage());
  }

  void updateControllersFromModel() {
    viewPessoaColaboradorModelController.text = crmSacDetalheModel.viewPessoaColaboradorModel?.nome?.toString() ?? '';
    dataRegistroController.date = crmSacDetalheModel.dataRegistro;
    horaRegistroController.text = crmSacDetalheModel.horaRegistro ?? '';
    historicoController.text = crmSacDetalheModel.historico ?? '';
    formWasChangedDetail = false;
  }

  @override
  Future<void> save() async {
    if (!crmSacDetalheFormKey.currentState!.validate()) {
      showErrorSnackBar(message: 'validator_form_message'.tr);
      return;
    }

    if (formWasChangedDetail) {
      if (isNewRecord) {
        crmSacDetalheModelList.insert(0, crmSacDetalheModel.clone());
      } else {
        final index = crmSacDetalheModelList.indexWhere((m) => m.tempId == crmSacDetalheModel.tempId);
        if (index >= 0) {
          crmSacDetalheModelList[index] = crmSacDetalheModel.clone();
        }
      }

      userMadeChanges = true;
      loadData();
      Get.back(result: true);
    } else {
      Get.back();
    }
  }

  Future callViewPessoaColaboradorLookup() async { 
		final lookupController = Get.find<LookupController>(); 
		lookupController.refreshItems(standardValue: '%'); 
		lookupController.title = '${'lookup_page_title'.tr} [Atendente]'; 
		lookupController.route = '/view-pessoa-colaborador/'; 
		lookupController.gridColumns = viewPessoaColaboradorGridColumns(isForLookup: true); 
		lookupController.aliasColumns = ViewPessoaColaboradorModel.aliasColumns; 
		lookupController.dbColumns = ViewPessoaColaboradorModel.dbColumns; 
		lookupController.standardColumn = ViewPessoaColaboradorModel.aliasColumns[ViewPessoaColaboradorModel.dbColumns.indexOf('nome')]; 

		final plutoRowResult = await Get.toNamed(Routes.lookupPage); 
		if (plutoRowResult != null) { 
			crmSacDetalheModel.idViewPessoaColaborador = plutoRowResult.cells['id']!.value; 
			crmSacDetalheModel.viewPessoaColaboradorModel = ViewPessoaColaboradorModel.fromPlutoRow(plutoRowResult); 
			viewPessoaColaboradorModelController.text = crmSacDetalheModel.viewPessoaColaboradorModel?.nome ?? ''; 
			formWasChangedDetail = true; 
		}
	}


  @override
  Future deleteSelected() async {
    final currentRow = plutoGridStateManager.currentRow;
    if (currentRow == null) {
      showInfoSnackBar(message: 'message_select_one_to_delete'.tr);
      return null;
    }
    showDeleteDialog(() async {
      final id = currentRow.cells['id']?.value;
      final tempId = currentRow.cells['tempId']?.value;
      crmSacDetalheModelList.removeWhere((model) => (id != 0 && model.id == id) || (id == 0 && model.tempId == tempId));
      plutoGridStateManager.removeCurrentRow();
      userMadeChanges = true;
    });
  }

  @override
  void preventDataLoss() {
    if (formWasChangedDetail) {
      showQuestionDialog('message_data_loss'.tr, () => Get.back());
    } else {
      formWasChangedDetail = false;
      Get.back();
    }
  }

  @override
  void onClose() {
    viewPessoaColaboradorModelController.dispose();
    dataRegistroController.dispose();
    horaRegistroController.dispose();
    historicoController.dispose();
  }

}