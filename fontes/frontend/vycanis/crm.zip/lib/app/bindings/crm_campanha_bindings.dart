import 'package:get/get.dart';
import 'package:crm/app/controller/crm_campanha_controller.dart';
import 'package:crm/app/data/provider/api/crm_campanha_api_provider.dart';
import 'package:crm/app/data/provider/drift/crm_campanha_drift_provider.dart';
import 'package:crm/app/data/repository/crm_campanha_repository.dart';

class CrmCampanhaBindings implements Binding {
	@override
	List<Bind> dependencies() {
		return [
			Bind.lazyPut<CrmCampanhaController>(() => CrmCampanhaController(
					repository: CrmCampanhaRepository(crmCampanhaApiProvider: CrmCampanhaApiProvider(), crmCampanhaDriftProvider: CrmCampanhaDriftProvider()))),
		];
	}
}
