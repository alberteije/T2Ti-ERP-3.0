import 'package:get/get.dart';
import 'package:crm/app/controller/crm_contato_controller.dart';
import 'package:crm/app/data/provider/api/crm_contato_api_provider.dart';
import 'package:crm/app/data/provider/drift/crm_contato_drift_provider.dart';
import 'package:crm/app/data/repository/crm_contato_repository.dart';

class CrmContatoBindings implements Binding {
	@override
	List<Bind> dependencies() {
		return [
			Bind.lazyPut<CrmContatoController>(() => CrmContatoController(
					repository: CrmContatoRepository(crmContatoApiProvider: CrmContatoApiProvider(), crmContatoDriftProvider: CrmContatoDriftProvider()))),
		];
	}
}
