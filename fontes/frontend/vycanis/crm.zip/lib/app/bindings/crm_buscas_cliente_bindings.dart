import 'package:get/get.dart';
import 'package:crm/app/controller/crm_buscas_cliente_controller.dart';
import 'package:crm/app/data/provider/api/crm_buscas_cliente_api_provider.dart';
import 'package:crm/app/data/provider/drift/crm_buscas_cliente_drift_provider.dart';
import 'package:crm/app/data/repository/crm_buscas_cliente_repository.dart';

class CrmBuscasClienteBindings implements Binding {
	@override
	List<Bind> dependencies() {
		return [
			Bind.lazyPut<CrmBuscasClienteController>(() => CrmBuscasClienteController(
					repository: CrmBuscasClienteRepository(crmBuscasClienteApiProvider: CrmBuscasClienteApiProvider(), crmBuscasClienteDriftProvider: CrmBuscasClienteDriftProvider()))),
		];
	}
}
