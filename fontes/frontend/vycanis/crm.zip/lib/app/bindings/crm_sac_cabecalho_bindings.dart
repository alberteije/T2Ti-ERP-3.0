import 'package:get/get.dart';
import 'package:crm/app/controller/crm_sac_cabecalho_controller.dart';
import 'package:crm/app/data/provider/api/crm_sac_cabecalho_api_provider.dart';
import 'package:crm/app/data/provider/drift/crm_sac_cabecalho_drift_provider.dart';
import 'package:crm/app/data/repository/crm_sac_cabecalho_repository.dart';

class CrmSacCabecalhoBindings implements Binding {
	@override
	List<Bind> dependencies() {
		return [
			Bind.lazyPut<CrmSacCabecalhoController>(() => CrmSacCabecalhoController(
					repository: CrmSacCabecalhoRepository(crmSacCabecalhoApiProvider: CrmSacCabecalhoApiProvider(), crmSacCabecalhoDriftProvider: CrmSacCabecalhoDriftProvider()))),
		];
	}
}
