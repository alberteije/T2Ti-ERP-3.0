import 'package:get/get.dart';
import 'package:crm/app/controller/crm_carteira_cliente_perfil_controller.dart';
import 'package:crm/app/data/provider/api/crm_carteira_cliente_perfil_api_provider.dart';
import 'package:crm/app/data/provider/drift/crm_carteira_cliente_perfil_drift_provider.dart';
import 'package:crm/app/data/repository/crm_carteira_cliente_perfil_repository.dart';

class CrmCarteiraClientePerfilBindings implements Binding {
	@override
	List<Bind> dependencies() {
		return [
			Bind.lazyPut<CrmCarteiraClientePerfilController>(() => CrmCarteiraClientePerfilController(
					repository: CrmCarteiraClientePerfilRepository(crmCarteiraClientePerfilApiProvider: CrmCarteiraClientePerfilApiProvider(), crmCarteiraClientePerfilDriftProvider: CrmCarteiraClientePerfilDriftProvider()))),
		];
	}
}
