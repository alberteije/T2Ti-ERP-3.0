import 'package:get/get.dart';
import 'package:crm/app/controller/crm_oportunidade_controller.dart';
import 'package:crm/app/data/provider/api/crm_oportunidade_api_provider.dart';
import 'package:crm/app/data/provider/drift/crm_oportunidade_drift_provider.dart';
import 'package:crm/app/data/repository/crm_oportunidade_repository.dart';

class CrmOportunidadeBindings implements Binding {
	@override
	List<Bind> dependencies() {
		return [
			Bind.lazyPut<CrmOportunidadeController>(() => CrmOportunidadeController(
					repository: CrmOportunidadeRepository(crmOportunidadeApiProvider: CrmOportunidadeApiProvider(), crmOportunidadeDriftProvider: CrmOportunidadeDriftProvider()))),
		];
	}
}
