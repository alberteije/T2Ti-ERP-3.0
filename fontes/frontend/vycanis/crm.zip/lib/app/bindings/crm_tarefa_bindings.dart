import 'package:get/get.dart';
import 'package:crm/app/controller/crm_tarefa_controller.dart';
import 'package:crm/app/data/provider/api/crm_tarefa_api_provider.dart';
import 'package:crm/app/data/provider/drift/crm_tarefa_drift_provider.dart';
import 'package:crm/app/data/repository/crm_tarefa_repository.dart';

class CrmTarefaBindings implements Binding {
	@override
	List<Bind> dependencies() {
		return [
			Bind.lazyPut<CrmTarefaController>(() => CrmTarefaController(
					repository: CrmTarefaRepository(crmTarefaApiProvider: CrmTarefaApiProvider(), crmTarefaDriftProvider: CrmTarefaDriftProvider()))),
		];
	}
}
