import 'dart:convert';
import 'package:pluto_grid/pluto_grid.dart';
import 'package:crm/app/data/model/model_imports.dart';

import 'package:crm/app/infra/infra_imports.dart';
import 'package:intl/intl.dart';

class CrmBuscasClienteModel extends ModelBase {
  int? id;
  int? idCliente;
  DateTime? dataBusca;
  String? horaBusca;
  String? detalhes;
  ViewPessoaClienteModel? viewPessoaClienteModel;

  CrmBuscasClienteModel({
    this.id,
    this.idCliente,
    this.dataBusca,
    this.horaBusca,
    this.detalhes,
    ViewPessoaClienteModel? viewPessoaClienteModel,
  }) {
    this.viewPessoaClienteModel = viewPessoaClienteModel ?? ViewPessoaClienteModel();
  }

  static List<String> dbColumns = <String>[
    'id',
    'data_busca',
    'hora_busca',
    'detalhes',
  ];

  static List<String> aliasColumns = <String>[
    'Id',
    'Data Busca',
    'Hora Busca',
    'Detalhes',
  ];

  CrmBuscasClienteModel.fromJson(Map<String, dynamic> jsonData) {
    id = jsonData['id'];
    idCliente = jsonData['idCliente'];
    dataBusca = jsonData['dataBusca'] != null ? DateTime.tryParse(jsonData['dataBusca']) : null;
    horaBusca = jsonData['horaBusca'];
    detalhes = jsonData['detalhes'];
    viewPessoaClienteModel = jsonData['viewPessoaClienteModel'] == null ? ViewPessoaClienteModel() : ViewPessoaClienteModel.fromJson(jsonData['viewPessoaClienteModel']);
  }

  Map<String, dynamic> get toJson {
    Map<String, dynamic> jsonData = <String, dynamic>{};

    jsonData['id'] = id != 0 ? id : null;
    jsonData['idCliente'] = idCliente != 0 ? idCliente : null;
    jsonData['dataBusca'] = dataBusca != null ? DateFormat('yyyy-MM-ddT00:00:00').format(dataBusca!) : null;
    jsonData['horaBusca'] = Util.removeMask(horaBusca);
    jsonData['detalhes'] = detalhes;
    jsonData['viewPessoaClienteModel'] = viewPessoaClienteModel?.toJson;
    jsonData['viewPessoaCliente'] = viewPessoaClienteModel?.nome ?? '';

    return jsonData;
  }

  String objectEncodeJson() {
    final jsonData = toJson;
    return json.encode(jsonData);
  }

  static CrmBuscasClienteModel fromPlutoRow(PlutoRow row) {
    return CrmBuscasClienteModel(
      id: row.cells['id']?.value,
      idCliente: row.cells['idCliente']?.value,
      dataBusca: Util.stringToDate(row.cells['dataBusca']?.value),
      horaBusca: row.cells['horaBusca']?.value,
      detalhes: row.cells['detalhes']?.value,
    );
  }

  PlutoRow toPlutoRow() {
    return PlutoRow(
      cells: {
        'tempId': PlutoCell(value: tempId),
        'id': PlutoCell(value: id ?? 0),
        'idCliente': PlutoCell(value: idCliente ?? 0),
        'dataBusca': PlutoCell(value: dataBusca),
        'horaBusca': PlutoCell(value: horaBusca ?? ''),
        'detalhes': PlutoCell(value: detalhes ?? ''),
        'viewPessoaCliente': PlutoCell(value: viewPessoaClienteModel?.nome ?? ''),
      },
    );
  }

  CrmBuscasClienteModel clone() {
    return CrmBuscasClienteModel(
      id: id,
      idCliente: idCliente,
      dataBusca: dataBusca,
      horaBusca: horaBusca,
      detalhes: detalhes,
      viewPessoaClienteModel: viewPessoaClienteModel?.clone(),
    );
  }


}