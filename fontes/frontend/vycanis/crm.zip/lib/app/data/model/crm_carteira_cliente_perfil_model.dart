import 'dart:convert';
import 'package:pluto_grid/pluto_grid.dart';
import 'package:crm/app/data/model/model_imports.dart';


class CrmCarteiraClientePerfilModel extends ModelBase {
  int? id;
  String? codigo;
  String? nome;
  List<CrmCarteiraClienteModel>? crmCarteiraClienteModelList;

  CrmCarteiraClientePerfilModel({
    this.id,
    this.codigo,
    this.nome,
    List<CrmCarteiraClienteModel>? crmCarteiraClienteModelList,
  }) {
    this.crmCarteiraClienteModelList = crmCarteiraClienteModelList?.toList(growable: true) ?? [];
  }

  static List<String> dbColumns = <String>[
    'id',
    'codigo',
    'nome',
  ];

  static List<String> aliasColumns = <String>[
    'Id',
    'Codigo',
    'Nome',
  ];

  CrmCarteiraClientePerfilModel.fromJson(Map<String, dynamic> jsonData) {
    id = jsonData['id'];
    codigo = jsonData['codigo'];
    nome = jsonData['nome'];
    crmCarteiraClienteModelList = (jsonData['crmCarteiraClienteModelList'] as Iterable?)?.map((m) => CrmCarteiraClienteModel.fromJson(m)).toList() ?? [];
  }

  Map<String, dynamic> get toJson {
    Map<String, dynamic> jsonData = <String, dynamic>{};

    jsonData['id'] = id != 0 ? id : null;
    jsonData['codigo'] = codigo;
    jsonData['nome'] = nome;
    
		var crmCarteiraClienteModelLocalList = []; 
		for (CrmCarteiraClienteModel object in crmCarteiraClienteModelList ?? []) { 
			crmCarteiraClienteModelLocalList.add(object.toJson); 
		}
		jsonData['crmCarteiraClienteModelList'] = crmCarteiraClienteModelLocalList;

    return jsonData;
  }

  String objectEncodeJson() {
    final jsonData = toJson;
    return json.encode(jsonData);
  }

  static CrmCarteiraClientePerfilModel fromPlutoRow(PlutoRow row) {
    return CrmCarteiraClientePerfilModel(
      id: row.cells['id']?.value,
      codigo: row.cells['codigo']?.value,
      nome: row.cells['nome']?.value,
    );
  }

  PlutoRow toPlutoRow() {
    return PlutoRow(
      cells: {
        'tempId': PlutoCell(value: tempId),
        'id': PlutoCell(value: id ?? 0),
        'codigo': PlutoCell(value: codigo ?? ''),
        'nome': PlutoCell(value: nome ?? ''),
      },
    );
  }

  CrmCarteiraClientePerfilModel clone() {
    return CrmCarteiraClientePerfilModel(
      id: id,
      codigo: codigo,
      nome: nome,
      crmCarteiraClienteModelList: crmCarteiraClienteModelListClone(crmCarteiraClienteModelList!),
    );
  }

  crmCarteiraClienteModelListClone(List<CrmCarteiraClienteModel> crmCarteiraClienteModelList) { 
		List<CrmCarteiraClienteModel> resultList = [];
		for (var crmCarteiraClienteModel in crmCarteiraClienteModelList) {
			resultList.add(crmCarteiraClienteModel.clone());
		}
		return resultList;
	}


}