import 'dart:convert';
import 'package:pluto_grid/pluto_grid.dart';
import 'package:crm/app/data/model/model_imports.dart';


class CrmCarteiraClienteModel extends ModelBase {
  int? id;
  int? idCrmCarteiraClientePerfil;
  int? idCliente;
  ViewPessoaClienteModel? viewPessoaClienteModel;

  CrmCarteiraClienteModel({
    this.id,
    this.idCrmCarteiraClientePerfil,
    this.idCliente,
    ViewPessoaClienteModel? viewPessoaClienteModel,
  }) {
    this.viewPessoaClienteModel = viewPessoaClienteModel ?? ViewPessoaClienteModel();
  }

  static List<String> dbColumns = <String>[
    'id',
  ];

  static List<String> aliasColumns = <String>[
    'Id',
  ];

  CrmCarteiraClienteModel.fromJson(Map<String, dynamic> jsonData) {
    id = jsonData['id'];
    idCrmCarteiraClientePerfil = jsonData['idCrmCarteiraClientePerfil'];
    idCliente = jsonData['idCliente'];
    viewPessoaClienteModel = jsonData['viewPessoaClienteModel'] == null ? ViewPessoaClienteModel() : ViewPessoaClienteModel.fromJson(jsonData['viewPessoaClienteModel']);
  }

  Map<String, dynamic> get toJson {
    Map<String, dynamic> jsonData = <String, dynamic>{};

    jsonData['id'] = id != 0 ? id : null;
    jsonData['idCrmCarteiraClientePerfil'] = idCrmCarteiraClientePerfil != 0 ? idCrmCarteiraClientePerfil : null;
    jsonData['idCliente'] = idCliente != 0 ? idCliente : null;
    jsonData['viewPessoaClienteModel'] = viewPessoaClienteModel?.toJson;
    jsonData['viewPessoaCliente'] = viewPessoaClienteModel?.nome ?? '';

    return jsonData;
  }

  String objectEncodeJson() {
    final jsonData = toJson;
    return json.encode(jsonData);
  }

  static CrmCarteiraClienteModel fromPlutoRow(PlutoRow row) {
    return CrmCarteiraClienteModel(
      id: row.cells['id']?.value,
      idCrmCarteiraClientePerfil: row.cells['idCrmCarteiraClientePerfil']?.value,
      idCliente: row.cells['idCliente']?.value,
    );
  }

  PlutoRow toPlutoRow() {
    return PlutoRow(
      cells: {
        'tempId': PlutoCell(value: tempId),
        'id': PlutoCell(value: id ?? 0),
        'idCrmCarteiraClientePerfil': PlutoCell(value: idCrmCarteiraClientePerfil ?? 0),
        'idCliente': PlutoCell(value: idCliente ?? 0),
        'viewPessoaCliente': PlutoCell(value: viewPessoaClienteModel?.nome ?? ''),
      },
    );
  }

  CrmCarteiraClienteModel clone() {
    return CrmCarteiraClienteModel(
      id: id,
      idCrmCarteiraClientePerfil: idCrmCarteiraClientePerfil,
      idCliente: idCliente,
      viewPessoaClienteModel: viewPessoaClienteModel?.clone(),
    );
  }


}