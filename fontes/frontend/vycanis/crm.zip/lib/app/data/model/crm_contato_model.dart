import 'dart:convert';
import 'package:pluto_grid/pluto_grid.dart';
import 'package:crm/app/data/model/model_imports.dart';

import 'package:crm/app/infra/infra_imports.dart';
import 'package:intl/intl.dart';
import 'package:crm/app/data/domain/domain_imports.dart';

class CrmContatoModel extends ModelBase {
  int? id;
  int? idCliente;
  int? idViewPessoaColaborador;
  String? tipoContato;
  String? horaContato;
  String? assunto;
  String? descricao;
  String? resultado;
  DateTime? proximaData;
  String? proximaAcao;
  ViewPessoaClienteModel? viewPessoaClienteModel;
  ViewPessoaColaboradorModel? viewPessoaColaboradorModel;

  CrmContatoModel({
    this.id,
    this.idCliente,
    this.idViewPessoaColaborador,
    this.tipoContato = 'Telefone',
    this.horaContato,
    this.assunto,
    this.descricao,
    this.resultado = 'Pendente',
    this.proximaData,
    this.proximaAcao,
    ViewPessoaClienteModel? viewPessoaClienteModel,
    ViewPessoaColaboradorModel? viewPessoaColaboradorModel,
  }) {
    this.viewPessoaClienteModel = viewPessoaClienteModel ?? ViewPessoaClienteModel();
    this.viewPessoaColaboradorModel = viewPessoaColaboradorModel ?? ViewPessoaColaboradorModel();
  }

  static List<String> dbColumns = <String>[
    'id',
    'tipo_contato',
    'hora_contato',
    'assunto',
    'descricao',
    'resultado',
    'proxima_data',
    'proxima_acao',
  ];

  static List<String> aliasColumns = <String>[
    'Id',
    'Tipo Contato',
    'Hora Contato',
    'Assunto',
    'Descricao',
    'Resultado',
    'Proxima Data',
    'Proxima Acao',
  ];

  CrmContatoModel.fromJson(Map<String, dynamic> jsonData) {
    id = jsonData['id'];
    idCliente = jsonData['idCliente'];
    idViewPessoaColaborador = jsonData['idViewPessoaColaborador'];
    tipoContato = CrmContatoDomain.getTipoContato(jsonData['tipoContato']);
    horaContato = jsonData['horaContato'];
    assunto = jsonData['assunto'];
    descricao = jsonData['descricao'];
    resultado = CrmContatoDomain.getResultado(jsonData['resultado']);
    proximaData = jsonData['proximaData'] != null ? DateTime.tryParse(jsonData['proximaData']) : null;
    proximaAcao = jsonData['proximaAcao'];
    viewPessoaClienteModel = jsonData['viewPessoaClienteModel'] == null ? ViewPessoaClienteModel() : ViewPessoaClienteModel.fromJson(jsonData['viewPessoaClienteModel']);
    viewPessoaColaboradorModel = jsonData['viewPessoaColaboradorModel'] == null ? ViewPessoaColaboradorModel() : ViewPessoaColaboradorModel.fromJson(jsonData['viewPessoaColaboradorModel']);
  }

  Map<String, dynamic> get toJson {
    Map<String, dynamic> jsonData = <String, dynamic>{};

    jsonData['id'] = id != 0 ? id : null;
    jsonData['idCliente'] = idCliente != 0 ? idCliente : null;
    jsonData['idViewPessoaColaborador'] = idViewPessoaColaborador != 0 ? idViewPessoaColaborador : null;
    jsonData['tipoContato'] = CrmContatoDomain.setTipoContato(tipoContato);
    jsonData['horaContato'] = Util.removeMask(horaContato);
    jsonData['assunto'] = assunto;
    jsonData['descricao'] = descricao;
    jsonData['resultado'] = CrmContatoDomain.setResultado(resultado);
    jsonData['proximaData'] = proximaData != null ? DateFormat('yyyy-MM-ddT00:00:00').format(proximaData!) : null;
    jsonData['proximaAcao'] = proximaAcao;
    jsonData['viewPessoaClienteModel'] = viewPessoaClienteModel?.toJson;
    jsonData['viewPessoaCliente'] = viewPessoaClienteModel?.nome ?? '';
    jsonData['viewPessoaColaboradorModel'] = viewPessoaColaboradorModel?.toJson;
    jsonData['viewPessoaColaborador'] = viewPessoaColaboradorModel?.nome ?? '';

    return jsonData;
  }

  String objectEncodeJson() {
    final jsonData = toJson;
    return json.encode(jsonData);
  }

  static CrmContatoModel fromPlutoRow(PlutoRow row) {
    return CrmContatoModel(
      id: row.cells['id']?.value,
      idCliente: row.cells['idCliente']?.value,
      idViewPessoaColaborador: row.cells['idViewPessoaColaborador']?.value,
      tipoContato: row.cells['tipoContato']?.value,
      horaContato: row.cells['horaContato']?.value,
      assunto: row.cells['assunto']?.value,
      descricao: row.cells['descricao']?.value,
      resultado: row.cells['resultado']?.value,
      proximaData: Util.stringToDate(row.cells['proximaData']?.value),
      proximaAcao: row.cells['proximaAcao']?.value,
    );
  }

  PlutoRow toPlutoRow() {
    return PlutoRow(
      cells: {
        'tempId': PlutoCell(value: tempId),
        'id': PlutoCell(value: id ?? 0),
        'idCliente': PlutoCell(value: idCliente ?? 0),
        'idViewPessoaColaborador': PlutoCell(value: idViewPessoaColaborador ?? 0),
        'tipoContato': PlutoCell(value: tipoContato ?? ''),
        'horaContato': PlutoCell(value: horaContato ?? ''),
        'assunto': PlutoCell(value: assunto ?? ''),
        'descricao': PlutoCell(value: descricao ?? ''),
        'resultado': PlutoCell(value: resultado ?? ''),
        'proximaData': PlutoCell(value: proximaData),
        'proximaAcao': PlutoCell(value: proximaAcao ?? ''),
        'viewPessoaCliente': PlutoCell(value: viewPessoaClienteModel?.nome ?? ''),
        'viewPessoaColaborador': PlutoCell(value: viewPessoaColaboradorModel?.nome ?? ''),
      },
    );
  }

  CrmContatoModel clone() {
    return CrmContatoModel(
      id: id,
      idCliente: idCliente,
      idViewPessoaColaborador: idViewPessoaColaborador,
      tipoContato: tipoContato,
      horaContato: horaContato,
      assunto: assunto,
      descricao: descricao,
      resultado: resultado,
      proximaData: proximaData,
      proximaAcao: proximaAcao,
      viewPessoaClienteModel: viewPessoaClienteModel?.clone(),
      viewPessoaColaboradorModel: viewPessoaColaboradorModel?.clone(),
    );
  }


}