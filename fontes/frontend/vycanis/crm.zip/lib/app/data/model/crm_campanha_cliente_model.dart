import 'dart:convert';
import 'package:pluto_grid/pluto_grid.dart';
import 'package:crm/app/data/model/model_imports.dart';

import 'package:crm/app/infra/infra_imports.dart';
import 'package:intl/intl.dart';
import 'package:crm/app/data/domain/domain_imports.dart';

class CrmCampanhaClienteModel extends ModelBase {
  int? id;
  int? idCampanha;
  int? idCliente;
  DateTime? dataInscricao;
  String? status;
  String? observacoes;
  ViewPessoaClienteModel? viewPessoaClienteModel;

  CrmCampanhaClienteModel({
    this.id,
    this.idCampanha,
    this.idCliente,
    this.dataInscricao,
    this.status = 'Inscrito',
    this.observacoes,
    ViewPessoaClienteModel? viewPessoaClienteModel,
  }) {
    this.viewPessoaClienteModel = viewPessoaClienteModel ?? ViewPessoaClienteModel();
  }

  static List<String> dbColumns = <String>[
    'id',
    'data_inscricao',
    'status',
    'observacoes',
  ];

  static List<String> aliasColumns = <String>[
    'Id',
    'Data Inscricao',
    'Status',
    'Observacoes',
  ];

  CrmCampanhaClienteModel.fromJson(Map<String, dynamic> jsonData) {
    id = jsonData['id'];
    idCampanha = jsonData['idCampanha'];
    idCliente = jsonData['idCliente'];
    dataInscricao = jsonData['dataInscricao'] != null ? DateTime.tryParse(jsonData['dataInscricao']) : null;
    status = CrmCampanhaClienteDomain.getStatus(jsonData['status']);
    observacoes = jsonData['observacoes'];
    viewPessoaClienteModel = jsonData['viewPessoaClienteModel'] == null ? ViewPessoaClienteModel() : ViewPessoaClienteModel.fromJson(jsonData['viewPessoaClienteModel']);
  }

  Map<String, dynamic> get toJson {
    Map<String, dynamic> jsonData = <String, dynamic>{};

    jsonData['id'] = id != 0 ? id : null;
    jsonData['idCampanha'] = idCampanha != 0 ? idCampanha : null;
    jsonData['idCliente'] = idCliente != 0 ? idCliente : null;
    jsonData['dataInscricao'] = dataInscricao != null ? DateFormat('yyyy-MM-ddT00:00:00').format(dataInscricao!) : null;
    jsonData['status'] = CrmCampanhaClienteDomain.setStatus(status);
    jsonData['observacoes'] = observacoes;
    jsonData['viewPessoaClienteModel'] = viewPessoaClienteModel?.toJson;
    jsonData['viewPessoaCliente'] = viewPessoaClienteModel?.nome ?? '';

    return jsonData;
  }

  String objectEncodeJson() {
    final jsonData = toJson;
    return json.encode(jsonData);
  }

  static CrmCampanhaClienteModel fromPlutoRow(PlutoRow row) {
    return CrmCampanhaClienteModel(
      id: row.cells['id']?.value,
      idCampanha: row.cells['idCampanha']?.value,
      idCliente: row.cells['idCliente']?.value,
      dataInscricao: Util.stringToDate(row.cells['dataInscricao']?.value),
      status: row.cells['status']?.value,
      observacoes: row.cells['observacoes']?.value,
    );
  }

  PlutoRow toPlutoRow() {
    return PlutoRow(
      cells: {
        'tempId': PlutoCell(value: tempId),
        'id': PlutoCell(value: id ?? 0),
        'idCampanha': PlutoCell(value: idCampanha ?? 0),
        'idCliente': PlutoCell(value: idCliente ?? 0),
        'dataInscricao': PlutoCell(value: dataInscricao),
        'status': PlutoCell(value: status ?? ''),
        'observacoes': PlutoCell(value: observacoes ?? ''),
        'viewPessoaCliente': PlutoCell(value: viewPessoaClienteModel?.nome ?? ''),
      },
    );
  }

  CrmCampanhaClienteModel clone() {
    return CrmCampanhaClienteModel(
      id: id,
      idCampanha: idCampanha,
      idCliente: idCliente,
      dataInscricao: dataInscricao,
      status: status,
      observacoes: observacoes,
      viewPessoaClienteModel: viewPessoaClienteModel?.clone(),
    );
  }


}