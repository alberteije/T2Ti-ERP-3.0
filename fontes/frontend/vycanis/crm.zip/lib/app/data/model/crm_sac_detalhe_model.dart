import 'dart:convert';
import 'package:pluto_grid/pluto_grid.dart';
import 'package:crm/app/data/model/model_imports.dart';

import 'package:crm/app/infra/infra_imports.dart';
import 'package:intl/intl.dart';

class CrmSacDetalheModel extends ModelBase {
  int? id;
  int? idCrmSacCabecalho;
  int? idViewPessoaColaborador;
  DateTime? dataRegistro;
  String? horaRegistro;
  String? historico;
  ViewPessoaColaboradorModel? viewPessoaColaboradorModel;

  CrmSacDetalheModel({
    this.id,
    this.idCrmSacCabecalho,
    this.idViewPessoaColaborador,
    this.dataRegistro,
    this.horaRegistro,
    this.historico,
    ViewPessoaColaboradorModel? viewPessoaColaboradorModel,
  }) {
    this.viewPessoaColaboradorModel = viewPessoaColaboradorModel ?? ViewPessoaColaboradorModel();
  }

  static List<String> dbColumns = <String>[
    'id',
    'data_registro',
    'hora_registro',
    'historico',
  ];

  static List<String> aliasColumns = <String>[
    'Id',
    'Data Registro',
    'Hora Registro',
    'Historico',
  ];

  CrmSacDetalheModel.fromJson(Map<String, dynamic> jsonData) {
    id = jsonData['id'];
    idCrmSacCabecalho = jsonData['idCrmSacCabecalho'];
    idViewPessoaColaborador = jsonData['idViewPessoaColaborador'];
    dataRegistro = jsonData['dataRegistro'] != null ? DateTime.tryParse(jsonData['dataRegistro']) : null;
    horaRegistro = jsonData['horaRegistro'];
    historico = jsonData['historico'];
    viewPessoaColaboradorModel = jsonData['viewPessoaColaboradorModel'] == null ? ViewPessoaColaboradorModel() : ViewPessoaColaboradorModel.fromJson(jsonData['viewPessoaColaboradorModel']);
  }

  Map<String, dynamic> get toJson {
    Map<String, dynamic> jsonData = <String, dynamic>{};

    jsonData['id'] = id != 0 ? id : null;
    jsonData['idCrmSacCabecalho'] = idCrmSacCabecalho != 0 ? idCrmSacCabecalho : null;
    jsonData['idViewPessoaColaborador'] = idViewPessoaColaborador != 0 ? idViewPessoaColaborador : null;
    jsonData['dataRegistro'] = dataRegistro != null ? DateFormat('yyyy-MM-ddT00:00:00').format(dataRegistro!) : null;
    jsonData['horaRegistro'] = Util.removeMask(horaRegistro);
    jsonData['historico'] = historico;
    jsonData['viewPessoaColaboradorModel'] = viewPessoaColaboradorModel?.toJson;
    jsonData['viewPessoaColaborador'] = viewPessoaColaboradorModel?.nome ?? '';

    return jsonData;
  }

  String objectEncodeJson() {
    final jsonData = toJson;
    return json.encode(jsonData);
  }

  static CrmSacDetalheModel fromPlutoRow(PlutoRow row) {
    return CrmSacDetalheModel(
      id: row.cells['id']?.value,
      idCrmSacCabecalho: row.cells['idCrmSacCabecalho']?.value,
      idViewPessoaColaborador: row.cells['idViewPessoaColaborador']?.value,
      dataRegistro: Util.stringToDate(row.cells['dataRegistro']?.value),
      horaRegistro: row.cells['horaRegistro']?.value,
      historico: row.cells['historico']?.value,
    );
  }

  PlutoRow toPlutoRow() {
    return PlutoRow(
      cells: {
        'tempId': PlutoCell(value: tempId),
        'id': PlutoCell(value: id ?? 0),
        'idCrmSacCabecalho': PlutoCell(value: idCrmSacCabecalho ?? 0),
        'idViewPessoaColaborador': PlutoCell(value: idViewPessoaColaborador ?? 0),
        'dataRegistro': PlutoCell(value: dataRegistro),
        'horaRegistro': PlutoCell(value: horaRegistro ?? ''),
        'historico': PlutoCell(value: historico ?? ''),
        'viewPessoaColaborador': PlutoCell(value: viewPessoaColaboradorModel?.nome ?? ''),
      },
    );
  }

  CrmSacDetalheModel clone() {
    return CrmSacDetalheModel(
      id: id,
      idCrmSacCabecalho: idCrmSacCabecalho,
      idViewPessoaColaborador: idViewPessoaColaborador,
      dataRegistro: dataRegistro,
      horaRegistro: horaRegistro,
      historico: historico,
      viewPessoaColaboradorModel: viewPessoaColaboradorModel?.clone(),
    );
  }


}