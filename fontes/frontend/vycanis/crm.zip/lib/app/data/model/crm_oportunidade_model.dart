import 'dart:convert';
import 'package:pluto_grid/pluto_grid.dart';
import 'package:crm/app/data/model/model_imports.dart';

import 'package:crm/app/infra/infra_imports.dart';
import 'package:intl/intl.dart';
import 'package:crm/app/data/domain/domain_imports.dart';

class CrmOportunidadeModel extends ModelBase {
  int? id;
  int? idCliente;
  int? idViewPessoaColaborador;
  String? titulo;
  String? descricao;
  double? valorEstimado;
  DateTime? dataAbertura;
  DateTime? dataFechamentoPrevisto;
  DateTime? dataFechamentoReal;
  String? status;
  String? motivoFechamento;
  int? probabilidade;
  ViewPessoaClienteModel? viewPessoaClienteModel;
  ViewPessoaColaboradorModel? viewPessoaColaboradorModel;

  CrmOportunidadeModel({
    this.id,
    this.idCliente,
    this.idViewPessoaColaborador,
    this.titulo,
    this.descricao,
    this.valorEstimado,
    this.dataAbertura,
    this.dataFechamentoPrevisto,
    this.dataFechamentoReal,
    this.status = 'Prospecção',
    this.motivoFechamento = 'Ganha',
    this.probabilidade,
    ViewPessoaClienteModel? viewPessoaClienteModel,
    ViewPessoaColaboradorModel? viewPessoaColaboradorModel,
  }) {
    this.viewPessoaClienteModel = viewPessoaClienteModel ?? ViewPessoaClienteModel();
    this.viewPessoaColaboradorModel = viewPessoaColaboradorModel ?? ViewPessoaColaboradorModel();
  }

  static List<String> dbColumns = <String>[
    'id',
    'titulo',
    'descricao',
    'valor_estimado',
    'data_abertura',
    'data_fechamento_previsto',
    'data_fechamento_real',
    'status',
    'motivo_fechamento',
    'probabilidade',
  ];

  static List<String> aliasColumns = <String>[
    'Id',
    'Titulo',
    'Descricao',
    'Valor Estimado',
    'Data Abertura',
    'Data Fechamento Previsto',
    'Data Fechamento Real',
    'Status',
    'Motivo Fechamento',
    'Probabilidade',
  ];

  CrmOportunidadeModel.fromJson(Map<String, dynamic> jsonData) {
    id = jsonData['id'];
    idCliente = jsonData['idCliente'];
    idViewPessoaColaborador = jsonData['idViewPessoaColaborador'];
    titulo = jsonData['titulo'];
    descricao = jsonData['descricao'];
    valorEstimado = jsonData['valorEstimado']?.toDouble();
    dataAbertura = jsonData['dataAbertura'] != null ? DateTime.tryParse(jsonData['dataAbertura']) : null;
    dataFechamentoPrevisto = jsonData['dataFechamentoPrevisto'] != null ? DateTime.tryParse(jsonData['dataFechamentoPrevisto']) : null;
    dataFechamentoReal = jsonData['dataFechamentoReal'] != null ? DateTime.tryParse(jsonData['dataFechamentoReal']) : null;
    status = CrmOportunidadeDomain.getStatus(jsonData['status']);
    motivoFechamento = CrmOportunidadeDomain.getMotivoFechamento(jsonData['motivoFechamento']);
    probabilidade = jsonData['probabilidade'];
    viewPessoaClienteModel = jsonData['viewPessoaClienteModel'] == null ? ViewPessoaClienteModel() : ViewPessoaClienteModel.fromJson(jsonData['viewPessoaClienteModel']);
    viewPessoaColaboradorModel = jsonData['viewPessoaColaboradorModel'] == null ? ViewPessoaColaboradorModel() : ViewPessoaColaboradorModel.fromJson(jsonData['viewPessoaColaboradorModel']);
  }

  Map<String, dynamic> get toJson {
    Map<String, dynamic> jsonData = <String, dynamic>{};

    jsonData['id'] = id != 0 ? id : null;
    jsonData['idCliente'] = idCliente != 0 ? idCliente : null;
    jsonData['idViewPessoaColaborador'] = idViewPessoaColaborador != 0 ? idViewPessoaColaborador : null;
    jsonData['titulo'] = titulo;
    jsonData['descricao'] = descricao;
    jsonData['valorEstimado'] = valorEstimado;
    jsonData['dataAbertura'] = dataAbertura != null ? DateFormat('yyyy-MM-ddT00:00:00').format(dataAbertura!) : null;
    jsonData['dataFechamentoPrevisto'] = dataFechamentoPrevisto != null ? DateFormat('yyyy-MM-ddT00:00:00').format(dataFechamentoPrevisto!) : null;
    jsonData['dataFechamentoReal'] = dataFechamentoReal != null ? DateFormat('yyyy-MM-ddT00:00:00').format(dataFechamentoReal!) : null;
    jsonData['status'] = CrmOportunidadeDomain.setStatus(status);
    jsonData['motivoFechamento'] = CrmOportunidadeDomain.setMotivoFechamento(motivoFechamento);
    jsonData['probabilidade'] = probabilidade;
    jsonData['viewPessoaClienteModel'] = viewPessoaClienteModel?.toJson;
    jsonData['viewPessoaCliente'] = viewPessoaClienteModel?.nome ?? '';
    jsonData['viewPessoaColaboradorModel'] = viewPessoaColaboradorModel?.toJson;
    jsonData['viewPessoaColaborador'] = viewPessoaColaboradorModel?.nome ?? '';

    return jsonData;
  }

  String objectEncodeJson() {
    final jsonData = toJson;
    return json.encode(jsonData);
  }

  static CrmOportunidadeModel fromPlutoRow(PlutoRow row) {
    return CrmOportunidadeModel(
      id: row.cells['id']?.value,
      idCliente: row.cells['idCliente']?.value,
      idViewPessoaColaborador: row.cells['idViewPessoaColaborador']?.value,
      titulo: row.cells['titulo']?.value,
      descricao: row.cells['descricao']?.value,
      valorEstimado: row.cells['valorEstimado']?.value,
      dataAbertura: Util.stringToDate(row.cells['dataAbertura']?.value),
      dataFechamentoPrevisto: Util.stringToDate(row.cells['dataFechamentoPrevisto']?.value),
      dataFechamentoReal: Util.stringToDate(row.cells['dataFechamentoReal']?.value),
      status: row.cells['status']?.value,
      motivoFechamento: row.cells['motivoFechamento']?.value,
      probabilidade: row.cells['probabilidade']?.value,
    );
  }

  PlutoRow toPlutoRow() {
    return PlutoRow(
      cells: {
        'tempId': PlutoCell(value: tempId),
        'id': PlutoCell(value: id ?? 0),
        'idCliente': PlutoCell(value: idCliente ?? 0),
        'idViewPessoaColaborador': PlutoCell(value: idViewPessoaColaborador ?? 0),
        'titulo': PlutoCell(value: titulo ?? ''),
        'descricao': PlutoCell(value: descricao ?? ''),
        'valorEstimado': PlutoCell(value: valorEstimado ?? 0.0),
        'dataAbertura': PlutoCell(value: dataAbertura),
        'dataFechamentoPrevisto': PlutoCell(value: dataFechamentoPrevisto),
        'dataFechamentoReal': PlutoCell(value: dataFechamentoReal),
        'status': PlutoCell(value: status ?? ''),
        'motivoFechamento': PlutoCell(value: motivoFechamento ?? ''),
        'probabilidade': PlutoCell(value: probabilidade ?? 0),
        'viewPessoaCliente': PlutoCell(value: viewPessoaClienteModel?.nome ?? ''),
        'viewPessoaColaborador': PlutoCell(value: viewPessoaColaboradorModel?.nome ?? ''),
      },
    );
  }

  CrmOportunidadeModel clone() {
    return CrmOportunidadeModel(
      id: id,
      idCliente: idCliente,
      idViewPessoaColaborador: idViewPessoaColaborador,
      titulo: titulo,
      descricao: descricao,
      valorEstimado: valorEstimado,
      dataAbertura: dataAbertura,
      dataFechamentoPrevisto: dataFechamentoPrevisto,
      dataFechamentoReal: dataFechamentoReal,
      status: status,
      motivoFechamento: motivoFechamento,
      probabilidade: probabilidade,
      viewPessoaClienteModel: viewPessoaClienteModel?.clone(),
      viewPessoaColaboradorModel: viewPessoaColaboradorModel?.clone(),
    );
  }


}