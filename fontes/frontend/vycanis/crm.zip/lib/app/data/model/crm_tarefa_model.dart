import 'dart:convert';
import 'package:pluto_grid/pluto_grid.dart';
import 'package:crm/app/data/model/model_imports.dart';

import 'package:crm/app/infra/infra_imports.dart';
import 'package:intl/intl.dart';
import 'package:crm/app/data/domain/domain_imports.dart';

class CrmTarefaModel extends ModelBase {
  int? id;
  int? idCliente;
  int? idOportunidade;
  String? titulo;
  String? descricao;
  String? prioridade;
  DateTime? dataCriacao;
  DateTime? dataVencimento;
  DateTime? dataConclusao;
  String? status;
  ViewPessoaClienteModel? viewPessoaClienteModel;
  CrmOportunidadeModel? crmOportunidadeModel;

  CrmTarefaModel({
    this.id,
    this.idCliente,
    this.idOportunidade,
    this.titulo,
    this.descricao,
    this.prioridade = 'Alta',
    this.dataCriacao,
    this.dataVencimento,
    this.dataConclusao,
    this.status = 'Pendente',
    ViewPessoaClienteModel? viewPessoaClienteModel,
    CrmOportunidadeModel? crmOportunidadeModel,
  }) {
    this.viewPessoaClienteModel = viewPessoaClienteModel ?? ViewPessoaClienteModel();
    this.crmOportunidadeModel = crmOportunidadeModel ?? CrmOportunidadeModel();
  }

  static List<String> dbColumns = <String>[
    'id',
    'titulo',
    'descricao',
    'prioridade',
    'data_criacao',
    'data_vencimento',
    'data_conclusao',
    'status',
  ];

  static List<String> aliasColumns = <String>[
    'Id',
    'Titulo',
    'Descricao',
    'Prioridade',
    'Data Criacao',
    'Data Vencimento',
    'Data Conclusao',
    'Status',
  ];

  CrmTarefaModel.fromJson(Map<String, dynamic> jsonData) {
    id = jsonData['id'];
    idCliente = jsonData['idCliente'];
    idOportunidade = jsonData['idOportunidade'];
    titulo = jsonData['titulo'];
    descricao = jsonData['descricao'];
    prioridade = CrmTarefaDomain.getPrioridade(jsonData['prioridade']);
    dataCriacao = jsonData['dataCriacao'] != null ? DateTime.tryParse(jsonData['dataCriacao']) : null;
    dataVencimento = jsonData['dataVencimento'] != null ? DateTime.tryParse(jsonData['dataVencimento']) : null;
    dataConclusao = jsonData['dataConclusao'] != null ? DateTime.tryParse(jsonData['dataConclusao']) : null;
    status = CrmTarefaDomain.getStatus(jsonData['status']);
    viewPessoaClienteModel = jsonData['viewPessoaClienteModel'] == null ? ViewPessoaClienteModel() : ViewPessoaClienteModel.fromJson(jsonData['viewPessoaClienteModel']);
    crmOportunidadeModel = jsonData['crmOportunidadeModel'] == null ? CrmOportunidadeModel() : CrmOportunidadeModel.fromJson(jsonData['crmOportunidadeModel']);
  }

  Map<String, dynamic> get toJson {
    Map<String, dynamic> jsonData = <String, dynamic>{};

    jsonData['id'] = id != 0 ? id : null;
    jsonData['idCliente'] = idCliente != 0 ? idCliente : null;
    jsonData['idOportunidade'] = idOportunidade != 0 ? idOportunidade : null;
    jsonData['titulo'] = titulo;
    jsonData['descricao'] = descricao;
    jsonData['prioridade'] = CrmTarefaDomain.setPrioridade(prioridade);
    jsonData['dataCriacao'] = dataCriacao != null ? DateFormat('yyyy-MM-ddT00:00:00').format(dataCriacao!) : null;
    jsonData['dataVencimento'] = dataVencimento != null ? DateFormat('yyyy-MM-ddT00:00:00').format(dataVencimento!) : null;
    jsonData['dataConclusao'] = dataConclusao != null ? DateFormat('yyyy-MM-ddT00:00:00').format(dataConclusao!) : null;
    jsonData['status'] = CrmTarefaDomain.setStatus(status);
    jsonData['viewPessoaClienteModel'] = viewPessoaClienteModel?.toJson;
    jsonData['viewPessoaCliente'] = viewPessoaClienteModel?.nome ?? '';
    jsonData['crmOportunidadeModel'] = crmOportunidadeModel?.toJson;
    jsonData['crmOportunidade'] = crmOportunidadeModel?.titulo ?? '';

    return jsonData;
  }

  String objectEncodeJson() {
    final jsonData = toJson;
    return json.encode(jsonData);
  }

  static CrmTarefaModel fromPlutoRow(PlutoRow row) {
    return CrmTarefaModel(
      id: row.cells['id']?.value,
      idCliente: row.cells['idCliente']?.value,
      idOportunidade: row.cells['idOportunidade']?.value,
      titulo: row.cells['titulo']?.value,
      descricao: row.cells['descricao']?.value,
      prioridade: row.cells['prioridade']?.value,
      dataCriacao: Util.stringToDate(row.cells['dataCriacao']?.value),
      dataVencimento: Util.stringToDate(row.cells['dataVencimento']?.value),
      dataConclusao: Util.stringToDate(row.cells['dataConclusao']?.value),
      status: row.cells['status']?.value,
    );
  }

  PlutoRow toPlutoRow() {
    return PlutoRow(
      cells: {
        'tempId': PlutoCell(value: tempId),
        'id': PlutoCell(value: id ?? 0),
        'idCliente': PlutoCell(value: idCliente ?? 0),
        'idOportunidade': PlutoCell(value: idOportunidade ?? 0),
        'titulo': PlutoCell(value: titulo ?? ''),
        'descricao': PlutoCell(value: descricao ?? ''),
        'prioridade': PlutoCell(value: prioridade ?? ''),
        'dataCriacao': PlutoCell(value: dataCriacao),
        'dataVencimento': PlutoCell(value: dataVencimento),
        'dataConclusao': PlutoCell(value: dataConclusao),
        'status': PlutoCell(value: status ?? ''),
        'viewPessoaCliente': PlutoCell(value: viewPessoaClienteModel?.nome ?? ''),
        'crmOportunidade': PlutoCell(value: crmOportunidadeModel?.titulo ?? ''),
      },
    );
  }

  CrmTarefaModel clone() {
    return CrmTarefaModel(
      id: id,
      idCliente: idCliente,
      idOportunidade: idOportunidade,
      titulo: titulo,
      descricao: descricao,
      prioridade: prioridade,
      dataCriacao: dataCriacao,
      dataVencimento: dataVencimento,
      dataConclusao: dataConclusao,
      status: status,
      viewPessoaClienteModel: viewPessoaClienteModel?.clone(),
      crmOportunidadeModel: crmOportunidadeModel?.clone(),
    );
  }


}