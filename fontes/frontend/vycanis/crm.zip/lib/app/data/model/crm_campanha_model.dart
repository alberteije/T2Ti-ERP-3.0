import 'dart:convert';
import 'package:pluto_grid/pluto_grid.dart';
import 'package:crm/app/data/model/model_imports.dart';

import 'package:crm/app/infra/infra_imports.dart';
import 'package:intl/intl.dart';
import 'package:crm/app/data/domain/domain_imports.dart';

class CrmCampanhaModel extends ModelBase {
  int? id;
  String? nome;
  String? descricao;
  String? tipo;
  DateTime? dataInicio;
  DateTime? dataFim;
  double? orcamento;
  String? status;
  List<CrmCampanhaClienteModel>? crmCampanhaClienteModelList;

  CrmCampanhaModel({
    this.id,
    this.nome,
    this.descricao,
    this.tipo = 'EMail',
    this.dataInicio,
    this.dataFim,
    this.orcamento,
    this.status = 'Planejada',
    List<CrmCampanhaClienteModel>? crmCampanhaClienteModelList,
  }) {
    this.crmCampanhaClienteModelList = crmCampanhaClienteModelList?.toList(growable: true) ?? [];
  }

  static List<String> dbColumns = <String>[
    'id',
    'nome',
    'descricao',
    'tipo',
    'data_inicio',
    'data_fim',
    'orcamento',
    'status',
  ];

  static List<String> aliasColumns = <String>[
    'Id',
    'Nome',
    'Descricao',
    'Tipo',
    'Data Inicio',
    'Data Fim',
    'Orcamento',
    'Status',
  ];

  CrmCampanhaModel.fromJson(Map<String, dynamic> jsonData) {
    id = jsonData['id'];
    nome = jsonData['nome'];
    descricao = jsonData['descricao'];
    tipo = CrmCampanhaDomain.getTipo(jsonData['tipo']);
    dataInicio = jsonData['dataInicio'] != null ? DateTime.tryParse(jsonData['dataInicio']) : null;
    dataFim = jsonData['dataFim'] != null ? DateTime.tryParse(jsonData['dataFim']) : null;
    orcamento = jsonData['orcamento']?.toDouble();
    status = CrmCampanhaDomain.getStatus(jsonData['status']);
    crmCampanhaClienteModelList = (jsonData['crmCampanhaClienteModelList'] as Iterable?)?.map((m) => CrmCampanhaClienteModel.fromJson(m)).toList() ?? [];
  }

  Map<String, dynamic> get toJson {
    Map<String, dynamic> jsonData = <String, dynamic>{};

    jsonData['id'] = id != 0 ? id : null;
    jsonData['nome'] = nome;
    jsonData['descricao'] = descricao;
    jsonData['tipo'] = CrmCampanhaDomain.setTipo(tipo);
    jsonData['dataInicio'] = dataInicio != null ? DateFormat('yyyy-MM-ddT00:00:00').format(dataInicio!) : null;
    jsonData['dataFim'] = dataFim != null ? DateFormat('yyyy-MM-ddT00:00:00').format(dataFim!) : null;
    jsonData['orcamento'] = orcamento;
    jsonData['status'] = CrmCampanhaDomain.setStatus(status);
    
		var crmCampanhaClienteModelLocalList = []; 
		for (CrmCampanhaClienteModel object in crmCampanhaClienteModelList ?? []) { 
			crmCampanhaClienteModelLocalList.add(object.toJson); 
		}
		jsonData['crmCampanhaClienteModelList'] = crmCampanhaClienteModelLocalList;

    return jsonData;
  }

  String objectEncodeJson() {
    final jsonData = toJson;
    return json.encode(jsonData);
  }

  static CrmCampanhaModel fromPlutoRow(PlutoRow row) {
    return CrmCampanhaModel(
      id: row.cells['id']?.value,
      nome: row.cells['nome']?.value,
      descricao: row.cells['descricao']?.value,
      tipo: row.cells['tipo']?.value,
      dataInicio: Util.stringToDate(row.cells['dataInicio']?.value),
      dataFim: Util.stringToDate(row.cells['dataFim']?.value),
      orcamento: row.cells['orcamento']?.value,
      status: row.cells['status']?.value,
    );
  }

  PlutoRow toPlutoRow() {
    return PlutoRow(
      cells: {
        'tempId': PlutoCell(value: tempId),
        'id': PlutoCell(value: id ?? 0),
        'nome': PlutoCell(value: nome ?? ''),
        'descricao': PlutoCell(value: descricao ?? ''),
        'tipo': PlutoCell(value: tipo ?? ''),
        'dataInicio': PlutoCell(value: dataInicio),
        'dataFim': PlutoCell(value: dataFim),
        'orcamento': PlutoCell(value: orcamento ?? 0.0),
        'status': PlutoCell(value: status ?? ''),
      },
    );
  }

  CrmCampanhaModel clone() {
    return CrmCampanhaModel(
      id: id,
      nome: nome,
      descricao: descricao,
      tipo: tipo,
      dataInicio: dataInicio,
      dataFim: dataFim,
      orcamento: orcamento,
      status: status,
      crmCampanhaClienteModelList: crmCampanhaClienteModelListClone(crmCampanhaClienteModelList!),
    );
  }

  crmCampanhaClienteModelListClone(List<CrmCampanhaClienteModel> crmCampanhaClienteModelList) { 
		List<CrmCampanhaClienteModel> resultList = [];
		for (var crmCampanhaClienteModel in crmCampanhaClienteModelList) {
			resultList.add(crmCampanhaClienteModel.clone());
		}
		return resultList;
	}


}