import 'dart:convert';
import 'package:pluto_grid/pluto_grid.dart';
import 'package:crm/app/data/model/model_imports.dart';

import 'package:crm/app/infra/infra_imports.dart';
import 'package:intl/intl.dart';
import 'package:crm/app/data/domain/domain_imports.dart';

class CrmSacCabecalhoModel extends ModelBase {
  int? id;
  int? idCliente;
  DateTime? dataAbertura;
  String? horaAbertura;
  String? nivelReclamacao;
  String? numeroProtocolo;
  List<CrmSacDetalheModel>? crmSacDetalheModelList;
  ViewPessoaClienteModel? viewPessoaClienteModel;

  CrmSacCabecalhoModel({
    this.id,
    this.idCliente,
    this.dataAbertura,
    this.horaAbertura,
    this.nivelReclamacao = 'Normal',
    this.numeroProtocolo,
    List<CrmSacDetalheModel>? crmSacDetalheModelList,
    ViewPessoaClienteModel? viewPessoaClienteModel,
  }) {
    this.crmSacDetalheModelList = crmSacDetalheModelList?.toList(growable: true) ?? [];
    this.viewPessoaClienteModel = viewPessoaClienteModel ?? ViewPessoaClienteModel();
  }

  static List<String> dbColumns = <String>[
    'id',
    'data_abertura',
    'hora_abertura',
    'nivel_reclamacao',
    'numero_protocolo',
  ];

  static List<String> aliasColumns = <String>[
    'Id',
    'Data Abertura',
    'Hora Abertura',
    'Nivel Reclamacao',
    'Numero Protocolo',
  ];

  CrmSacCabecalhoModel.fromJson(Map<String, dynamic> jsonData) {
    id = jsonData['id'];
    idCliente = jsonData['idCliente'];
    dataAbertura = jsonData['dataAbertura'] != null ? DateTime.tryParse(jsonData['dataAbertura']) : null;
    horaAbertura = jsonData['horaAbertura'];
    nivelReclamacao = CrmSacCabecalhoDomain.getNivelReclamacao(jsonData['nivelReclamacao']);
    numeroProtocolo = jsonData['numeroProtocolo'];
    crmSacDetalheModelList = (jsonData['crmSacDetalheModelList'] as Iterable?)?.map((m) => CrmSacDetalheModel.fromJson(m)).toList() ?? [];
    viewPessoaClienteModel = jsonData['viewPessoaClienteModel'] == null ? ViewPessoaClienteModel() : ViewPessoaClienteModel.fromJson(jsonData['viewPessoaClienteModel']);
  }

  Map<String, dynamic> get toJson {
    Map<String, dynamic> jsonData = <String, dynamic>{};

    jsonData['id'] = id != 0 ? id : null;
    jsonData['idCliente'] = idCliente != 0 ? idCliente : null;
    jsonData['dataAbertura'] = dataAbertura != null ? DateFormat('yyyy-MM-ddT00:00:00').format(dataAbertura!) : null;
    jsonData['horaAbertura'] = Util.removeMask(horaAbertura);
    jsonData['nivelReclamacao'] = CrmSacCabecalhoDomain.setNivelReclamacao(nivelReclamacao);
    jsonData['numeroProtocolo'] = numeroProtocolo;
    
		var crmSacDetalheModelLocalList = []; 
		for (CrmSacDetalheModel object in crmSacDetalheModelList ?? []) { 
			crmSacDetalheModelLocalList.add(object.toJson); 
		}
		jsonData['crmSacDetalheModelList'] = crmSacDetalheModelLocalList;
    jsonData['viewPessoaClienteModel'] = viewPessoaClienteModel?.toJson;
    jsonData['viewPessoaCliente'] = viewPessoaClienteModel?.nome ?? '';

    return jsonData;
  }

  String objectEncodeJson() {
    final jsonData = toJson;
    return json.encode(jsonData);
  }

  static CrmSacCabecalhoModel fromPlutoRow(PlutoRow row) {
    return CrmSacCabecalhoModel(
      id: row.cells['id']?.value,
      idCliente: row.cells['idCliente']?.value,
      dataAbertura: Util.stringToDate(row.cells['dataAbertura']?.value),
      horaAbertura: row.cells['horaAbertura']?.value,
      nivelReclamacao: row.cells['nivelReclamacao']?.value,
      numeroProtocolo: row.cells['numeroProtocolo']?.value,
    );
  }

  PlutoRow toPlutoRow() {
    return PlutoRow(
      cells: {
        'tempId': PlutoCell(value: tempId),
        'id': PlutoCell(value: id ?? 0),
        'idCliente': PlutoCell(value: idCliente ?? 0),
        'dataAbertura': PlutoCell(value: dataAbertura),
        'horaAbertura': PlutoCell(value: horaAbertura ?? ''),
        'nivelReclamacao': PlutoCell(value: nivelReclamacao ?? ''),
        'numeroProtocolo': PlutoCell(value: numeroProtocolo ?? ''),
        'viewPessoaCliente': PlutoCell(value: viewPessoaClienteModel?.nome ?? ''),
      },
    );
  }

  CrmSacCabecalhoModel clone() {
    return CrmSacCabecalhoModel(
      id: id,
      idCliente: idCliente,
      dataAbertura: dataAbertura,
      horaAbertura: horaAbertura,
      nivelReclamacao: nivelReclamacao,
      numeroProtocolo: numeroProtocolo,
      crmSacDetalheModelList: crmSacDetalheModelListClone(crmSacDetalheModelList!),
      viewPessoaClienteModel: viewPessoaClienteModel?.clone(),
    );
  }

  crmSacDetalheModelListClone(List<CrmSacDetalheModel> crmSacDetalheModelList) { 
		List<CrmSacDetalheModel> resultList = [];
		for (var crmSacDetalheModel in crmSacDetalheModelList) {
			resultList.add(crmSacDetalheModel.clone());
		}
		return resultList;
	}


}