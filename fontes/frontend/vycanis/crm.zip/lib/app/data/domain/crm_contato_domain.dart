class CrmContatoDomain {
  CrmContatoDomain._();

  static getTipoContato(String? tipoContato) { 
		switch (tipoContato) { 
			case '': 
			case 'T': 
				return 'Telefone'; 
			case 'E': 
				return 'Email'; 
			case 'W': 
				return 'Whatsapp'; 
			case 'P': 
				return 'Presencial'; 
			default: 
				return null; 
		} 
	} 

  static setTipoContato(String? tipoContato) { 
		switch (tipoContato) { 
			case 'Telefone': 
				return 'T'; 
			case 'Email': 
				return 'E'; 
			case 'Whatsapp': 
				return 'W'; 
			case 'Presencial': 
				return 'P'; 
			default: 
				return null; 
		} 
	}

  static getResultado(String? resultado) { 
		switch (resultado) { 
			case '': 
			case 'P': 
				return 'Pendente'; 
			case 'S': 
				return 'Sucesso'; 
			case 'C': 
				return 'Cancelado'; 
			default: 
				return null; 
		} 
	} 

  static setResultado(String? resultado) { 
		switch (resultado) { 
			case 'Pendente': 
				return 'P'; 
			case 'Sucesso': 
				return 'S'; 
			case 'Cancelado': 
				return 'C'; 
			default: 
				return null; 
		} 
	}


  static final tipoContatoListDropdown = ['Telefone','Email','Whatsapp','Presencial'];
  static final resultadoListDropdown = ['Pendente','Sucesso','Cancelado'];

}