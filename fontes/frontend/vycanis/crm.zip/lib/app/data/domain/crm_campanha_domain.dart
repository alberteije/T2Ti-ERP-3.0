class CrmCampanhaDomain {
  CrmCampanhaDomain._();

  static getTipo(String? tipo) { 
		switch (tipo) { 
			case '': 
			case 'E': 
				return 'EMail'; 
			case 'S': 
				return 'SMS'; 
			case 'W': 
				return 'WhatsApp'; 
			case 'V': 
				return 'Evento'; 
			default: 
				return null; 
		} 
	} 

  static setTipo(String? tipo) { 
		switch (tipo) { 
			case 'EMail': 
				return 'E'; 
			case 'SMS': 
				return 'S'; 
			case 'WhatsApp': 
				return 'W'; 
			case 'Evento': 
				return 'V'; 
			default: 
				return null; 
		} 
	}

  static getStatus(String? status) { 
		switch (status) { 
			case '': 
			case '0': 
				return 'Planejada'; 
			case '1': 
				return 'Ativa'; 
			case '2': 
				return 'Concluída'; 
			case '3': 
				return 'Cancelada'; 
			default: 
				return null; 
		} 
	} 

  static setStatus(String? status) { 
		switch (status) { 
			case 'Planejada': 
				return '0'; 
			case 'Ativa': 
				return '1'; 
			case 'Concluída': 
				return '2'; 
			case 'Cancelada': 
				return '3'; 
			default: 
				return null; 
		} 
	}


  static final tipoListDropdown = ['EMail','SMS','WhatsApp','Evento'];
  static final statusListDropdown = ['Planejada','Ativa','Concluída','Cancelada'];

}