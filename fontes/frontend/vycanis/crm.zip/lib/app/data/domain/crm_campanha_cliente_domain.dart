class CrmCampanhaClienteDomain {
  CrmCampanhaClienteDomain._();

  static getStatus(String? status) { 
		switch (status) { 
			case '': 
			case '0': 
				return 'Inscrito'; 
			case '1': 
				return 'Contatato'; 
			case '2': 
				return 'Convertido'; 
			default: 
				return null; 
		} 
	} 

  static setStatus(String? status) { 
		switch (status) { 
			case 'Inscrito': 
				return '0'; 
			case 'Contatato': 
				return '1'; 
			case 'Convertido': 
				return '2'; 
			default: 
				return null; 
		} 
	}


  static final statusListDropdown = ['Inscrito','Contatato','Convertido'];

}