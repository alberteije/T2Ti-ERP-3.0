class CrmTarefaDomain {
  CrmTarefaDomain._();

  static getPrioridade(String? prioridade) { 
		switch (prioridade) { 
			case '': 
			case 'A': 
				return 'Alta'; 
			case 'M': 
				return 'Média'; 
			case 'B': 
				return 'Baixa'; 
			default: 
				return null; 
		} 
	} 

  static setPrioridade(String? prioridade) { 
		switch (prioridade) { 
			case 'Alta': 
				return 'A'; 
			case 'Média': 
				return 'M'; 
			case 'Baixa': 
				return 'B'; 
			default: 
				return null; 
		} 
	}

  static getStatus(String? status) { 
		switch (status) { 
			case '': 
			case '0': 
				return 'Pendente'; 
			case '1': 
				return 'Em Andamento'; 
			case '2': 
				return 'Concluída'; 
			case '3': 
				return 'Cancelada'; 
			default: 
				return null; 
		} 
	} 

  static setStatus(String? status) { 
		switch (status) { 
			case 'Pendente': 
				return '0'; 
			case 'Em Andamento': 
				return '1'; 
			case 'Concluída': 
				return '2'; 
			case 'Cancelada': 
				return '3'; 
			default: 
				return null; 
		} 
	}


  static final prioridadeListDropdown = ['Alta','Média','Baixa'];
  static final statusListDropdown = ['Pendente','Em Andamento','Concluída','Cancelada'];

}