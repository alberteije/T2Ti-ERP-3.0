class CrmSacCabecalhoDomain {
  CrmSacCabecalhoDomain._();

  static getNivelReclamacao(String? nivelReclamacao) { 
		switch (nivelReclamacao) { 
			case '': 
			case 'N': 
				return 'Normal'; 
			case 'M': 
				return 'Média'; 
			case 'A': 
				return 'Alta'; 
			case 'C': 
				return 'Crítica'; 
			default: 
				return null; 
		} 
	} 

  static setNivelReclamacao(String? nivelReclamacao) { 
		switch (nivelReclamacao) { 
			case 'Normal': 
				return 'N'; 
			case 'Média': 
				return 'M'; 
			case 'Alta': 
				return 'A'; 
			case 'Crítica': 
				return 'C'; 
			default: 
				return null; 
		} 
	}


  static final nivelReclamacaoListDropdown = ['Normal','Média','Alta','Crítica'];

}