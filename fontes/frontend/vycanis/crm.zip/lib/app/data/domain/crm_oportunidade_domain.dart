class CrmOportunidadeDomain {
  CrmOportunidadeDomain._();

  static getStatus(String? status) { 
		switch (status) { 
			case '': 
			case '0': 
				return 'Prospecção'; 
			case '1': 
				return 'Qualificação'; 
			case '2': 
				return 'Proposta'; 
			case '3': 
				return 'Negociação'; 
			case '4': 
				return 'Fechada'; 
			default: 
				return null; 
		} 
	} 

  static setStatus(String? status) { 
		switch (status) { 
			case 'Prospecção': 
				return '0'; 
			case 'Qualificação': 
				return '1'; 
			case 'Proposta': 
				return '2'; 
			case 'Negociação': 
				return '3'; 
			case 'Fechada': 
				return '4'; 
			default: 
				return null; 
		} 
	}

  static getMotivoFechamento(String? motivoFechamento) { 
		switch (motivoFechamento) { 
			case '': 
			case 'G': 
				return 'Ganha'; 
			case 'P': 
				return 'Perdida'; 
			case 'C': 
				return 'Cancelada'; 
			default: 
				return null; 
		} 
	} 

  static setMotivoFechamento(String? motivoFechamento) { 
		switch (motivoFechamento) { 
			case 'Ganha': 
				return 'G'; 
			case 'Perdida': 
				return 'P'; 
			case 'Cancelada': 
				return 'C'; 
			default: 
				return null; 
		} 
	}


  static final statusListDropdown = ['Prospecção','Qualificação','Proposta','Negociação','Fechada'];
  static final motivoFechamentoListDropdown = ['Ganha','Perdida','Cancelada'];

}