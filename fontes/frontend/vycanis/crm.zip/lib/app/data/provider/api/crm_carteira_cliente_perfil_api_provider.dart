import 'package:crm/app/data/provider/api/api_provider_base.dart';
import 'package:crm/app/data/model/model_imports.dart';

class CrmCarteiraClientePerfilApiProvider extends ApiProviderBase {
  static const _path = '/crm-carteira-cliente-perfil';

  Future<List<CrmCarteiraClientePerfilModel>?> getList({Filter? filter}) {
    return super.getListBase(
      '$_path/',
      (json) => CrmCarteiraClientePerfilModel.fromJson(json),
      filter: filter,
    );
  }

  Future<CrmCarteiraClientePerfilModel?> getObject(dynamic pk) {
    return super.getObjectBase(
      _path,
      pk,
      (json) => CrmCarteiraClientePerfilModel.fromJson(json),
    );
  }

  Future<CrmCarteiraClientePerfilModel?>? insert(CrmCarteiraClientePerfilModel model) {
    return super.insertBase(
      _path,
      model,
      (json) => CrmCarteiraClientePerfilModel.fromJson(json),
    );
  }

  Future<CrmCarteiraClientePerfilModel?>? update(CrmCarteiraClientePerfilModel model) {
    return super.updateBase(
      _path,
      model,
      (json) => CrmCarteiraClientePerfilModel.fromJson(json),
    );
  }

  Future<bool?> delete(dynamic pk) {
    return super.deleteBase(_path, pk);
  }
}
