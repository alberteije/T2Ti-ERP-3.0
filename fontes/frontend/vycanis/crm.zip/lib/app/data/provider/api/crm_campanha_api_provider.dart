import 'package:crm/app/data/provider/api/api_provider_base.dart';
import 'package:crm/app/data/model/model_imports.dart';

class CrmCampanhaApiProvider extends ApiProviderBase {
  static const _path = '/crm-campanha';

  Future<List<CrmCampanhaModel>?> getList({Filter? filter}) {
    return super.getListBase(
      '$_path/',
      (json) => CrmCampanhaModel.fromJson(json),
      filter: filter,
    );
  }

  Future<CrmCampanhaModel?> getObject(dynamic pk) {
    return super.getObjectBase(
      _path,
      pk,
      (json) => CrmCampanhaModel.fromJson(json),
    );
  }

  Future<CrmCampanhaModel?>? insert(CrmCampanhaModel model) {
    return super.insertBase(
      _path,
      model,
      (json) => CrmCampanhaModel.fromJson(json),
    );
  }

  Future<CrmCampanhaModel?>? update(CrmCampanhaModel model) {
    return super.updateBase(
      _path,
      model,
      (json) => CrmCampanhaModel.fromJson(json),
    );
  }

  Future<bool?> delete(dynamic pk) {
    return super.deleteBase(_path, pk);
  }
}
