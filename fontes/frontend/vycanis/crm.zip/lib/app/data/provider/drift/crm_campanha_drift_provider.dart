import 'package:crm/app/data/provider/drift/database/database_imports.dart';
import 'package:crm/app/infra/infra_imports.dart';
import 'package:crm/app/data/provider/provider_base.dart';
import 'package:crm/app/data/provider/drift/database/database.dart';
import 'package:crm/app/data/model/model_imports.dart';
import 'package:crm/app/data/domain/domain_imports.dart';

class CrmCampanhaDriftProvider extends ProviderBase {

	Future<List<CrmCampanhaModel>?> getList({Filter? filter}) async {
		List<CrmCampanhaGrouped> crmCampanhaDriftList = [];

		try {
			if (filter != null && filter.field != null) {
				crmCampanhaDriftList = await Session.database.crmCampanhaDao.getGroupedList(field: filter.field, value: filter.value!);
			} else {
				crmCampanhaDriftList = await Session.database.crmCampanhaDao.getGroupedList(); 
			}
			if (crmCampanhaDriftList.isNotEmpty) {
				return toListModel(crmCampanhaDriftList);
			} else {
				return [];
			}			 
		} catch (e) {
			handleResultError(null, null, exception: e);
			return null;
		}
	}

	Future<CrmCampanhaModel?> getObject(dynamic pk) async {
		try {
			final result = await Session.database.crmCampanhaDao.getObjectGrouped(field: 'id', value: pk);
			return toModel(result);
		} catch (e) {
			handleResultError(null, null, exception: e);
		}
		return null;
	}

	Future<CrmCampanhaModel?>? insert(CrmCampanhaModel crmCampanhaModel) async {
		try {
			final lastPk = await Session.database.crmCampanhaDao.insertObject(toDrift(crmCampanhaModel));
			crmCampanhaModel.id = lastPk;
			return crmCampanhaModel;
		} catch (e) {
			handleResultError(null, null, exception: e);
		}
		return null;
	}

	Future<CrmCampanhaModel?>? update(CrmCampanhaModel crmCampanhaModel) async {
		try {
			await Session.database.crmCampanhaDao.updateObject(toDrift(crmCampanhaModel));
			return crmCampanhaModel;
		} catch (e) {
			handleResultError(null, null, exception: e);
		}
		return null;
	}

	Future<bool?> delete(dynamic pk) async {
		try {
			await Session.database.crmCampanhaDao.deleteObject(toDrift(CrmCampanhaModel(id: pk)));
			return true;
		} catch (e) {
			handleResultError(null, null, exception: e);
		}
		return null;
	}	

	List<CrmCampanhaModel> toListModel(List<CrmCampanhaGrouped> crmCampanhaDriftList) {
		List<CrmCampanhaModel> listModel = [];
		for (var crmCampanhaDrift in crmCampanhaDriftList) {
			listModel.add(toModel(crmCampanhaDrift)!);
		}
		return listModel;
	}	

	CrmCampanhaModel? toModel(CrmCampanhaGrouped? crmCampanhaDrift) {
		if (crmCampanhaDrift != null) {
			return CrmCampanhaModel(
				id: crmCampanhaDrift.crmCampanha?.id,
				nome: crmCampanhaDrift.crmCampanha?.nome,
				descricao: crmCampanhaDrift.crmCampanha?.descricao,
				tipo: CrmCampanhaDomain.getTipo(crmCampanhaDrift.crmCampanha?.tipo),
				dataInicio: crmCampanhaDrift.crmCampanha?.dataInicio,
				dataFim: crmCampanhaDrift.crmCampanha?.dataFim,
				orcamento: crmCampanhaDrift.crmCampanha?.orcamento,
				status: CrmCampanhaDomain.getStatus(crmCampanhaDrift.crmCampanha?.status),
				crmCampanhaClienteModelList: crmCampanhaClienteDriftToModel(crmCampanhaDrift.crmCampanhaClienteGroupedList),
			);
		} else {
			return null;
		}
	}

	List<CrmCampanhaClienteModel> crmCampanhaClienteDriftToModel(List<CrmCampanhaClienteGrouped>? crmCampanhaClienteDriftList) { 
		List<CrmCampanhaClienteModel> crmCampanhaClienteModelList = [];
		if (crmCampanhaClienteDriftList != null) {
			for (var crmCampanhaClienteGrouped in crmCampanhaClienteDriftList) {
				crmCampanhaClienteModelList.add(
					CrmCampanhaClienteModel(
						id: crmCampanhaClienteGrouped.crmCampanhaCliente?.id,
						idCampanha: crmCampanhaClienteGrouped.crmCampanhaCliente?.idCampanha,
						idCliente: crmCampanhaClienteGrouped.crmCampanhaCliente?.idCliente,
						viewPessoaClienteModel: ViewPessoaClienteModel(
							id: crmCampanhaClienteGrouped.viewPessoaCliente?.id,
							nome: crmCampanhaClienteGrouped.viewPessoaCliente?.nome,
							tipo: crmCampanhaClienteGrouped.viewPessoaCliente?.tipo,
							email: crmCampanhaClienteGrouped.viewPessoaCliente?.email,
							site: crmCampanhaClienteGrouped.viewPessoaCliente?.site,
							cpfCnpj: crmCampanhaClienteGrouped.viewPessoaCliente?.cpfCnpj,
							rgIe: crmCampanhaClienteGrouped.viewPessoaCliente?.rgIe,
							desde: crmCampanhaClienteGrouped.viewPessoaCliente?.desde,
							taxaDesconto: crmCampanhaClienteGrouped.viewPessoaCliente?.taxaDesconto,
							limiteCredito: crmCampanhaClienteGrouped.viewPessoaCliente?.limiteCredito,
							dataCadastro: crmCampanhaClienteGrouped.viewPessoaCliente?.dataCadastro,
							observacao: crmCampanhaClienteGrouped.viewPessoaCliente?.observacao,
							idPessoa: crmCampanhaClienteGrouped.viewPessoaCliente?.idPessoa,
						),
						dataInscricao: crmCampanhaClienteGrouped.crmCampanhaCliente?.dataInscricao,
						status: CrmCampanhaClienteDomain.getStatus(crmCampanhaClienteGrouped.crmCampanhaCliente?.status),
						observacoes: crmCampanhaClienteGrouped.crmCampanhaCliente?.observacoes,
					)
				);
			}
			return crmCampanhaClienteModelList;
		}
		return [];
	}


	CrmCampanhaGrouped toDrift(CrmCampanhaModel crmCampanhaModel) {
		return CrmCampanhaGrouped(
			crmCampanha: CrmCampanha(
				id: crmCampanhaModel.id,
				nome: crmCampanhaModel.nome,
				descricao: crmCampanhaModel.descricao,
				tipo: CrmCampanhaDomain.setTipo(crmCampanhaModel.tipo),
				dataInicio: crmCampanhaModel.dataInicio,
				dataFim: crmCampanhaModel.dataFim,
				orcamento: crmCampanhaModel.orcamento,
				status: CrmCampanhaDomain.setStatus(crmCampanhaModel.status),
			),
			crmCampanhaClienteGroupedList: crmCampanhaClienteModelToDrift(crmCampanhaModel.crmCampanhaClienteModelList),
		);
	}

	List<CrmCampanhaClienteGrouped> crmCampanhaClienteModelToDrift(List<CrmCampanhaClienteModel>? crmCampanhaClienteModelList) { 
		List<CrmCampanhaClienteGrouped> crmCampanhaClienteGroupedList = [];
		if (crmCampanhaClienteModelList != null) {
			for (var crmCampanhaClienteModel in crmCampanhaClienteModelList) {
				crmCampanhaClienteGroupedList.add(
					CrmCampanhaClienteGrouped(
						crmCampanhaCliente: CrmCampanhaCliente(
							id: crmCampanhaClienteModel.id,
							idCampanha: crmCampanhaClienteModel.idCampanha,
							idCliente: crmCampanhaClienteModel.idCliente,
							dataInscricao: crmCampanhaClienteModel.dataInscricao,
							status: CrmCampanhaClienteDomain.setStatus(crmCampanhaClienteModel.status),
							observacoes: crmCampanhaClienteModel.observacoes,
						),
					),
				);
			}
			return crmCampanhaClienteGroupedList;
		}
		return [];
	}

		
}
