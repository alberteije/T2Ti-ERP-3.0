import 'package:drift/drift.dart';
import 'package:crm/app/data/provider/drift/database/database_imports.dart';

part 'database.g.dart';

@DriftDatabase(
	tables: [
		CrmSacDetalhes,
		CrmCarteiraClientes,
		CrmCampanhaClientes,
		CrmSacCabecalhos,
		CrmCarteiraClientePerfils,
		CrmCampanhas,
		CrmBuscasClientes,
		ViewControleAcessos,
		ViewPessoaUsuarios,
		ViewPessoaClientes,
		ViewPessoaColaboradors,
		CrmContatos,
		CrmOportunidades,
		CrmTarefas,
 ], 
	daos: [
		CrmSacCabecalhoDao,
		CrmCarteiraClientePerfilDao,
		CrmCampanhaDao,
		CrmBuscasClienteDao,
		ViewControleAcessoDao,
		ViewPessoaUsuarioDao,
		ViewPessoaClienteDao,
		ViewPessoaColaboradorDao,
		CrmContatoDao,
		CrmOportunidadeDao,
		CrmTarefaDao,
	],
)

class AppDatabase extends _$AppDatabase {
	AppDatabase(QueryExecutor executor) : super(executor);

	@override
	int get schemaVersion => 1;

	@override
	MigrationStrategy get migration => MigrationStrategy(
		onCreate: (Migrator m) async {
			await m.createAll();
			await _populateDatabase(this);
		},		
	);	
}

Future<void> _populateDatabase(db) async {
	await db.customStatement("CREATE TABLE HIDDEN_SETTINGS("
				"ID INTEGER PRIMARY KEY,"
				"APP_THEME TEXT"
			")");
	await db.customStatement("INSERT INTO HIDDEN_SETTINGS (ID, APP_THEME) VALUES (1, 'ThemeMode.light')");
	await db.customStatement("INSERT INTO VIEW_PESSOA_CLIENTE (ID, NOME) VALUES (1, 'Cliente 01')");
	await db.customStatement("INSERT INTO VIEW_PESSOA_CLIENTE (ID, NOME) VALUES (2, 'Cliente 02')");
	await db.customStatement("INSERT INTO VIEW_PESSOA_COLABORADOR (ID, NOME) VALUES (1, 'Colaborador 01')");
	await db.customStatement("INSERT INTO VIEW_PESSOA_COLABORADOR (ID, NOME) VALUES (2, 'Colaborador 02')");
}
