import 'package:drift/drift.dart';
import 'package:crm/app/data/provider/drift/database/database.dart';
import 'package:crm/app/data/provider/drift/database/database_imports.dart';

part 'crm_contato_dao.g.dart';

@DriftAccessor(tables: [
	CrmContatos,
	ViewPessoaClientes,
	ViewPessoaColaboradors,
])
class CrmContatoDao extends DatabaseAccessor<AppDatabase> with _$CrmContatoDaoMixin {
	final AppDatabase db;

	List<CrmContato> crmContatoList = []; 
	List<CrmContatoGrouped> crmContatoGroupedList = []; 

	CrmContatoDao(this.db) : super(db);

	Future<List<CrmContato>> getList() async {
		crmContatoList = await select(crmContatos).get();
		return crmContatoList;
	}

	Future<List<CrmContato>> getListFilter(String field, String value) async {
		final query = " $field like '%$value%'";
		final expression = CustomExpression<bool>(query);
		crmContatoList = await (select(crmContatos)..where((t) => expression)).get();
		return crmContatoList;	 
	}

	Future<List<CrmContatoGrouped>> getGroupedList({String? field, dynamic value}) async {
		final query = select(crmContatos)
			.join([ 
				leftOuterJoin(viewPessoaClientes, viewPessoaClientes.id.equalsExp(crmContatos.idCliente)), 
			]).join([ 
				leftOuterJoin(viewPessoaColaboradors, viewPessoaColaboradors.id.equalsExp(crmContatos.idViewPessoaColaborador)), 
			]);

		if (field != null && field != '') { 
			final column = crmContatos.$columns.where(((column) => column.$name == field)).first;
			if (column is TextColumn) {
				query.where((column as TextColumn).like('%$value%'));
			} else if (column is IntColumn) {
				query.where(column.equals(int.tryParse(value) as Object));
			} else if (column is RealColumn) {
				query.where(column.equals(double.tryParse(value) as Object));
			}
		}

		crmContatoGroupedList = await query.map((row) {
			final crmContato = row.readTableOrNull(crmContatos); 
			final viewPessoaCliente = row.readTableOrNull(viewPessoaClientes); 
			final viewPessoaColaborador = row.readTableOrNull(viewPessoaColaboradors); 

			return CrmContatoGrouped(
				crmContato: crmContato, 
				viewPessoaCliente: viewPessoaCliente, 
				viewPessoaColaborador: viewPessoaColaborador, 

			);
		}).get();

		// fill internal lists
		//dynamic expression;
		//for (var crmContatoGrouped in crmContatoGroupedList) {
		//}		

		return crmContatoGroupedList;	
	}

	Future<CrmContato?> getObject(dynamic pk) async {
		return await (select(crmContatos)..where((t) => t.id.equals(pk))).getSingleOrNull();
	} 

	Future<CrmContato?> getObjectFilter(String field, String value) async {
		final query = "SELECT * FROM crm_contato WHERE $field like '%$value%'";
		return (await customSelect(query).getSingleOrNull()) as CrmContato;		 
	} 

	Future<CrmContatoGrouped?> getObjectGrouped({String? field, dynamic value}) async {
		final result = await getGroupedList(field: field, value: value);

		if (result.length != 1) {
			return null;
		} else {
			return result[0];
		} 
	}

	Future<int> insertObject(CrmContatoGrouped object) {
		return transaction(() async {
			final maxPk = await lastPk();
			object.crmContato = object.crmContato!.copyWith(id: Value(maxPk + 1));
			final pkInserted = await into(crmContatos).insert(object.crmContato!);
			object.crmContato = object.crmContato!.copyWith(id: Value(pkInserted));			 
			await insertChildren(object);
			return pkInserted;
		});		
	}	 

	Future<bool> updateObject(CrmContatoGrouped object) {
		return transaction(() async {
			await deleteChildren(object);
			await insertChildren(object);
			return update(crmContatos).replace(object.crmContato!);
		});	 
	} 

	Future<int> deleteObject(CrmContatoGrouped object) {
		return transaction(() async {
			await deleteChildren(object);
			return delete(crmContatos).delete(object.crmContato!);
		});		
	}

	Future<void> insertChildren(CrmContatoGrouped object) async {
	}
	
	Future<void> deleteChildren(CrmContatoGrouped object) async {
	}

	Future<int> lastPk() async {
		final result = await customSelect("select MAX(id) as LAST from crm_contato").getSingleOrNull();
		return result?.data["LAST"] ?? 0;
	} 
}