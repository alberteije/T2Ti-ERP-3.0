// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'database.dart';

// ignore_for_file: type=lint
class $CrmSacDetalhesTable extends CrmSacDetalhes
    with TableInfo<$CrmSacDetalhesTable, CrmSacDetalhe> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $CrmSacDetalhesTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
    'id',
    aliasedName,
    true,
    type: DriftSqlType.int,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _idCrmSacCabecalhoMeta = const VerificationMeta(
    'idCrmSacCabecalho',
  );
  @override
  late final GeneratedColumn<int> idCrmSacCabecalho = GeneratedColumn<int>(
    'id_crm_sac_cabecalho',
    aliasedName,
    true,
    type: DriftSqlType.int,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _idViewPessoaColaboradorMeta =
      const VerificationMeta('idViewPessoaColaborador');
  @override
  late final GeneratedColumn<int> idViewPessoaColaborador =
      GeneratedColumn<int>(
        'id_view_pessoa_colaborador',
        aliasedName,
        true,
        type: DriftSqlType.int,
        requiredDuringInsert: false,
      );
  static const VerificationMeta _dataRegistroMeta = const VerificationMeta(
    'dataRegistro',
  );
  @override
  late final GeneratedColumn<DateTime> dataRegistro = GeneratedColumn<DateTime>(
    'data_registro',
    aliasedName,
    true,
    type: DriftSqlType.dateTime,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _horaRegistroMeta = const VerificationMeta(
    'horaRegistro',
  );
  @override
  late final GeneratedColumn<String> horaRegistro = GeneratedColumn<String>(
    'hora_registro',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 8,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _historicoMeta = const VerificationMeta(
    'historico',
  );
  @override
  late final GeneratedColumn<String> historico = GeneratedColumn<String>(
    'historico',
    aliasedName,
    true,
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  @override
  List<GeneratedColumn> get $columns => [
    id,
    idCrmSacCabecalho,
    idViewPessoaColaborador,
    dataRegistro,
    horaRegistro,
    historico,
  ];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'crm_sac_detalhe';
  @override
  VerificationContext validateIntegrity(
    Insertable<CrmSacDetalhe> instance, {
    bool isInserting = false,
  }) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('id_crm_sac_cabecalho')) {
      context.handle(
        _idCrmSacCabecalhoMeta,
        idCrmSacCabecalho.isAcceptableOrUnknown(
          data['id_crm_sac_cabecalho']!,
          _idCrmSacCabecalhoMeta,
        ),
      );
    }
    if (data.containsKey('id_view_pessoa_colaborador')) {
      context.handle(
        _idViewPessoaColaboradorMeta,
        idViewPessoaColaborador.isAcceptableOrUnknown(
          data['id_view_pessoa_colaborador']!,
          _idViewPessoaColaboradorMeta,
        ),
      );
    }
    if (data.containsKey('data_registro')) {
      context.handle(
        _dataRegistroMeta,
        dataRegistro.isAcceptableOrUnknown(
          data['data_registro']!,
          _dataRegistroMeta,
        ),
      );
    }
    if (data.containsKey('hora_registro')) {
      context.handle(
        _horaRegistroMeta,
        horaRegistro.isAcceptableOrUnknown(
          data['hora_registro']!,
          _horaRegistroMeta,
        ),
      );
    }
    if (data.containsKey('historico')) {
      context.handle(
        _historicoMeta,
        historico.isAcceptableOrUnknown(data['historico']!, _historicoMeta),
      );
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  CrmSacDetalhe map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return CrmSacDetalhe(
      id: attachedDatabase.typeMapping.read(
        DriftSqlType.int,
        data['${effectivePrefix}id'],
      ),
      idCrmSacCabecalho: attachedDatabase.typeMapping.read(
        DriftSqlType.int,
        data['${effectivePrefix}id_crm_sac_cabecalho'],
      ),
      idViewPessoaColaborador: attachedDatabase.typeMapping.read(
        DriftSqlType.int,
        data['${effectivePrefix}id_view_pessoa_colaborador'],
      ),
      dataRegistro: attachedDatabase.typeMapping.read(
        DriftSqlType.dateTime,
        data['${effectivePrefix}data_registro'],
      ),
      horaRegistro: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}hora_registro'],
      ),
      historico: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}historico'],
      ),
    );
  }

  @override
  $CrmSacDetalhesTable createAlias(String alias) {
    return $CrmSacDetalhesTable(attachedDatabase, alias);
  }
}

class CrmSacDetalhe extends DataClass implements Insertable<CrmSacDetalhe> {
  final int? id;
  final int? idCrmSacCabecalho;
  final int? idViewPessoaColaborador;
  final DateTime? dataRegistro;
  final String? horaRegistro;
  final String? historico;
  const CrmSacDetalhe({
    this.id,
    this.idCrmSacCabecalho,
    this.idViewPessoaColaborador,
    this.dataRegistro,
    this.horaRegistro,
    this.historico,
  });
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || idCrmSacCabecalho != null) {
      map['id_crm_sac_cabecalho'] = Variable<int>(idCrmSacCabecalho);
    }
    if (!nullToAbsent || idViewPessoaColaborador != null) {
      map['id_view_pessoa_colaborador'] = Variable<int>(
        idViewPessoaColaborador,
      );
    }
    if (!nullToAbsent || dataRegistro != null) {
      map['data_registro'] = Variable<DateTime>(dataRegistro);
    }
    if (!nullToAbsent || horaRegistro != null) {
      map['hora_registro'] = Variable<String>(horaRegistro);
    }
    if (!nullToAbsent || historico != null) {
      map['historico'] = Variable<String>(historico);
    }
    return map;
  }

  factory CrmSacDetalhe.fromJson(
    Map<String, dynamic> json, {
    ValueSerializer? serializer,
  }) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return CrmSacDetalhe(
      id: serializer.fromJson<int?>(json['id']),
      idCrmSacCabecalho: serializer.fromJson<int?>(json['idCrmSacCabecalho']),
      idViewPessoaColaborador: serializer.fromJson<int?>(
        json['idViewPessoaColaborador'],
      ),
      dataRegistro: serializer.fromJson<DateTime?>(json['dataRegistro']),
      horaRegistro: serializer.fromJson<String?>(json['horaRegistro']),
      historico: serializer.fromJson<String?>(json['historico']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'idCrmSacCabecalho': serializer.toJson<int?>(idCrmSacCabecalho),
      'idViewPessoaColaborador': serializer.toJson<int?>(
        idViewPessoaColaborador,
      ),
      'dataRegistro': serializer.toJson<DateTime?>(dataRegistro),
      'horaRegistro': serializer.toJson<String?>(horaRegistro),
      'historico': serializer.toJson<String?>(historico),
    };
  }

  CrmSacDetalhe copyWith({
    Value<int?> id = const Value.absent(),
    Value<int?> idCrmSacCabecalho = const Value.absent(),
    Value<int?> idViewPessoaColaborador = const Value.absent(),
    Value<DateTime?> dataRegistro = const Value.absent(),
    Value<String?> horaRegistro = const Value.absent(),
    Value<String?> historico = const Value.absent(),
  }) => CrmSacDetalhe(
    id: id.present ? id.value : this.id,
    idCrmSacCabecalho:
        idCrmSacCabecalho.present
            ? idCrmSacCabecalho.value
            : this.idCrmSacCabecalho,
    idViewPessoaColaborador:
        idViewPessoaColaborador.present
            ? idViewPessoaColaborador.value
            : this.idViewPessoaColaborador,
    dataRegistro: dataRegistro.present ? dataRegistro.value : this.dataRegistro,
    horaRegistro: horaRegistro.present ? horaRegistro.value : this.horaRegistro,
    historico: historico.present ? historico.value : this.historico,
  );
  CrmSacDetalhe copyWithCompanion(CrmSacDetalhesCompanion data) {
    return CrmSacDetalhe(
      id: data.id.present ? data.id.value : this.id,
      idCrmSacCabecalho:
          data.idCrmSacCabecalho.present
              ? data.idCrmSacCabecalho.value
              : this.idCrmSacCabecalho,
      idViewPessoaColaborador:
          data.idViewPessoaColaborador.present
              ? data.idViewPessoaColaborador.value
              : this.idViewPessoaColaborador,
      dataRegistro:
          data.dataRegistro.present
              ? data.dataRegistro.value
              : this.dataRegistro,
      horaRegistro:
          data.horaRegistro.present
              ? data.horaRegistro.value
              : this.horaRegistro,
      historico: data.historico.present ? data.historico.value : this.historico,
    );
  }

  @override
  String toString() {
    return (StringBuffer('CrmSacDetalhe(')
          ..write('id: $id, ')
          ..write('idCrmSacCabecalho: $idCrmSacCabecalho, ')
          ..write('idViewPessoaColaborador: $idViewPessoaColaborador, ')
          ..write('dataRegistro: $dataRegistro, ')
          ..write('horaRegistro: $horaRegistro, ')
          ..write('historico: $historico')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(
    id,
    idCrmSacCabecalho,
    idViewPessoaColaborador,
    dataRegistro,
    horaRegistro,
    historico,
  );
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is CrmSacDetalhe &&
          other.id == this.id &&
          other.idCrmSacCabecalho == this.idCrmSacCabecalho &&
          other.idViewPessoaColaborador == this.idViewPessoaColaborador &&
          other.dataRegistro == this.dataRegistro &&
          other.horaRegistro == this.horaRegistro &&
          other.historico == this.historico);
}

class CrmSacDetalhesCompanion extends UpdateCompanion<CrmSacDetalhe> {
  final Value<int?> id;
  final Value<int?> idCrmSacCabecalho;
  final Value<int?> idViewPessoaColaborador;
  final Value<DateTime?> dataRegistro;
  final Value<String?> horaRegistro;
  final Value<String?> historico;
  const CrmSacDetalhesCompanion({
    this.id = const Value.absent(),
    this.idCrmSacCabecalho = const Value.absent(),
    this.idViewPessoaColaborador = const Value.absent(),
    this.dataRegistro = const Value.absent(),
    this.horaRegistro = const Value.absent(),
    this.historico = const Value.absent(),
  });
  CrmSacDetalhesCompanion.insert({
    this.id = const Value.absent(),
    this.idCrmSacCabecalho = const Value.absent(),
    this.idViewPessoaColaborador = const Value.absent(),
    this.dataRegistro = const Value.absent(),
    this.horaRegistro = const Value.absent(),
    this.historico = const Value.absent(),
  });
  static Insertable<CrmSacDetalhe> custom({
    Expression<int>? id,
    Expression<int>? idCrmSacCabecalho,
    Expression<int>? idViewPessoaColaborador,
    Expression<DateTime>? dataRegistro,
    Expression<String>? horaRegistro,
    Expression<String>? historico,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (idCrmSacCabecalho != null) 'id_crm_sac_cabecalho': idCrmSacCabecalho,
      if (idViewPessoaColaborador != null)
        'id_view_pessoa_colaborador': idViewPessoaColaborador,
      if (dataRegistro != null) 'data_registro': dataRegistro,
      if (horaRegistro != null) 'hora_registro': horaRegistro,
      if (historico != null) 'historico': historico,
    });
  }

  CrmSacDetalhesCompanion copyWith({
    Value<int?>? id,
    Value<int?>? idCrmSacCabecalho,
    Value<int?>? idViewPessoaColaborador,
    Value<DateTime?>? dataRegistro,
    Value<String?>? horaRegistro,
    Value<String?>? historico,
  }) {
    return CrmSacDetalhesCompanion(
      id: id ?? this.id,
      idCrmSacCabecalho: idCrmSacCabecalho ?? this.idCrmSacCabecalho,
      idViewPessoaColaborador:
          idViewPessoaColaborador ?? this.idViewPessoaColaborador,
      dataRegistro: dataRegistro ?? this.dataRegistro,
      horaRegistro: horaRegistro ?? this.horaRegistro,
      historico: historico ?? this.historico,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (idCrmSacCabecalho.present) {
      map['id_crm_sac_cabecalho'] = Variable<int>(idCrmSacCabecalho.value);
    }
    if (idViewPessoaColaborador.present) {
      map['id_view_pessoa_colaborador'] = Variable<int>(
        idViewPessoaColaborador.value,
      );
    }
    if (dataRegistro.present) {
      map['data_registro'] = Variable<DateTime>(dataRegistro.value);
    }
    if (horaRegistro.present) {
      map['hora_registro'] = Variable<String>(horaRegistro.value);
    }
    if (historico.present) {
      map['historico'] = Variable<String>(historico.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('CrmSacDetalhesCompanion(')
          ..write('id: $id, ')
          ..write('idCrmSacCabecalho: $idCrmSacCabecalho, ')
          ..write('idViewPessoaColaborador: $idViewPessoaColaborador, ')
          ..write('dataRegistro: $dataRegistro, ')
          ..write('horaRegistro: $horaRegistro, ')
          ..write('historico: $historico')
          ..write(')'))
        .toString();
  }
}

class $CrmCarteiraClientesTable extends CrmCarteiraClientes
    with TableInfo<$CrmCarteiraClientesTable, CrmCarteiraCliente> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $CrmCarteiraClientesTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
    'id',
    aliasedName,
    true,
    type: DriftSqlType.int,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _idClienteMeta = const VerificationMeta(
    'idCliente',
  );
  @override
  late final GeneratedColumn<int> idCliente = GeneratedColumn<int>(
    'id_cliente',
    aliasedName,
    true,
    type: DriftSqlType.int,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _idCrmCarteiraClientePerfilMeta =
      const VerificationMeta('idCrmCarteiraClientePerfil');
  @override
  late final GeneratedColumn<int> idCrmCarteiraClientePerfil =
      GeneratedColumn<int>(
        'id_crm_carteira_cliente_perfil',
        aliasedName,
        true,
        type: DriftSqlType.int,
        requiredDuringInsert: false,
      );
  @override
  List<GeneratedColumn> get $columns => [
    id,
    idCliente,
    idCrmCarteiraClientePerfil,
  ];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'crm_carteira_cliente';
  @override
  VerificationContext validateIntegrity(
    Insertable<CrmCarteiraCliente> instance, {
    bool isInserting = false,
  }) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('id_cliente')) {
      context.handle(
        _idClienteMeta,
        idCliente.isAcceptableOrUnknown(data['id_cliente']!, _idClienteMeta),
      );
    }
    if (data.containsKey('id_crm_carteira_cliente_perfil')) {
      context.handle(
        _idCrmCarteiraClientePerfilMeta,
        idCrmCarteiraClientePerfil.isAcceptableOrUnknown(
          data['id_crm_carteira_cliente_perfil']!,
          _idCrmCarteiraClientePerfilMeta,
        ),
      );
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  CrmCarteiraCliente map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return CrmCarteiraCliente(
      id: attachedDatabase.typeMapping.read(
        DriftSqlType.int,
        data['${effectivePrefix}id'],
      ),
      idCliente: attachedDatabase.typeMapping.read(
        DriftSqlType.int,
        data['${effectivePrefix}id_cliente'],
      ),
      idCrmCarteiraClientePerfil: attachedDatabase.typeMapping.read(
        DriftSqlType.int,
        data['${effectivePrefix}id_crm_carteira_cliente_perfil'],
      ),
    );
  }

  @override
  $CrmCarteiraClientesTable createAlias(String alias) {
    return $CrmCarteiraClientesTable(attachedDatabase, alias);
  }
}

class CrmCarteiraCliente extends DataClass
    implements Insertable<CrmCarteiraCliente> {
  final int? id;
  final int? idCliente;
  final int? idCrmCarteiraClientePerfil;
  const CrmCarteiraCliente({
    this.id,
    this.idCliente,
    this.idCrmCarteiraClientePerfil,
  });
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || idCliente != null) {
      map['id_cliente'] = Variable<int>(idCliente);
    }
    if (!nullToAbsent || idCrmCarteiraClientePerfil != null) {
      map['id_crm_carteira_cliente_perfil'] = Variable<int>(
        idCrmCarteiraClientePerfil,
      );
    }
    return map;
  }

  factory CrmCarteiraCliente.fromJson(
    Map<String, dynamic> json, {
    ValueSerializer? serializer,
  }) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return CrmCarteiraCliente(
      id: serializer.fromJson<int?>(json['id']),
      idCliente: serializer.fromJson<int?>(json['idCliente']),
      idCrmCarteiraClientePerfil: serializer.fromJson<int?>(
        json['idCrmCarteiraClientePerfil'],
      ),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'idCliente': serializer.toJson<int?>(idCliente),
      'idCrmCarteiraClientePerfil': serializer.toJson<int?>(
        idCrmCarteiraClientePerfil,
      ),
    };
  }

  CrmCarteiraCliente copyWith({
    Value<int?> id = const Value.absent(),
    Value<int?> idCliente = const Value.absent(),
    Value<int?> idCrmCarteiraClientePerfil = const Value.absent(),
  }) => CrmCarteiraCliente(
    id: id.present ? id.value : this.id,
    idCliente: idCliente.present ? idCliente.value : this.idCliente,
    idCrmCarteiraClientePerfil:
        idCrmCarteiraClientePerfil.present
            ? idCrmCarteiraClientePerfil.value
            : this.idCrmCarteiraClientePerfil,
  );
  CrmCarteiraCliente copyWithCompanion(CrmCarteiraClientesCompanion data) {
    return CrmCarteiraCliente(
      id: data.id.present ? data.id.value : this.id,
      idCliente: data.idCliente.present ? data.idCliente.value : this.idCliente,
      idCrmCarteiraClientePerfil:
          data.idCrmCarteiraClientePerfil.present
              ? data.idCrmCarteiraClientePerfil.value
              : this.idCrmCarteiraClientePerfil,
    );
  }

  @override
  String toString() {
    return (StringBuffer('CrmCarteiraCliente(')
          ..write('id: $id, ')
          ..write('idCliente: $idCliente, ')
          ..write('idCrmCarteiraClientePerfil: $idCrmCarteiraClientePerfil')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(id, idCliente, idCrmCarteiraClientePerfil);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is CrmCarteiraCliente &&
          other.id == this.id &&
          other.idCliente == this.idCliente &&
          other.idCrmCarteiraClientePerfil == this.idCrmCarteiraClientePerfil);
}

class CrmCarteiraClientesCompanion extends UpdateCompanion<CrmCarteiraCliente> {
  final Value<int?> id;
  final Value<int?> idCliente;
  final Value<int?> idCrmCarteiraClientePerfil;
  const CrmCarteiraClientesCompanion({
    this.id = const Value.absent(),
    this.idCliente = const Value.absent(),
    this.idCrmCarteiraClientePerfil = const Value.absent(),
  });
  CrmCarteiraClientesCompanion.insert({
    this.id = const Value.absent(),
    this.idCliente = const Value.absent(),
    this.idCrmCarteiraClientePerfil = const Value.absent(),
  });
  static Insertable<CrmCarteiraCliente> custom({
    Expression<int>? id,
    Expression<int>? idCliente,
    Expression<int>? idCrmCarteiraClientePerfil,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (idCliente != null) 'id_cliente': idCliente,
      if (idCrmCarteiraClientePerfil != null)
        'id_crm_carteira_cliente_perfil': idCrmCarteiraClientePerfil,
    });
  }

  CrmCarteiraClientesCompanion copyWith({
    Value<int?>? id,
    Value<int?>? idCliente,
    Value<int?>? idCrmCarteiraClientePerfil,
  }) {
    return CrmCarteiraClientesCompanion(
      id: id ?? this.id,
      idCliente: idCliente ?? this.idCliente,
      idCrmCarteiraClientePerfil:
          idCrmCarteiraClientePerfil ?? this.idCrmCarteiraClientePerfil,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (idCliente.present) {
      map['id_cliente'] = Variable<int>(idCliente.value);
    }
    if (idCrmCarteiraClientePerfil.present) {
      map['id_crm_carteira_cliente_perfil'] = Variable<int>(
        idCrmCarteiraClientePerfil.value,
      );
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('CrmCarteiraClientesCompanion(')
          ..write('id: $id, ')
          ..write('idCliente: $idCliente, ')
          ..write('idCrmCarteiraClientePerfil: $idCrmCarteiraClientePerfil')
          ..write(')'))
        .toString();
  }
}

class $CrmCampanhaClientesTable extends CrmCampanhaClientes
    with TableInfo<$CrmCampanhaClientesTable, CrmCampanhaCliente> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $CrmCampanhaClientesTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
    'id',
    aliasedName,
    true,
    type: DriftSqlType.int,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _idCampanhaMeta = const VerificationMeta(
    'idCampanha',
  );
  @override
  late final GeneratedColumn<int> idCampanha = GeneratedColumn<int>(
    'id_campanha',
    aliasedName,
    true,
    type: DriftSqlType.int,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _idClienteMeta = const VerificationMeta(
    'idCliente',
  );
  @override
  late final GeneratedColumn<int> idCliente = GeneratedColumn<int>(
    'id_cliente',
    aliasedName,
    true,
    type: DriftSqlType.int,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _dataInscricaoMeta = const VerificationMeta(
    'dataInscricao',
  );
  @override
  late final GeneratedColumn<DateTime> dataInscricao =
      GeneratedColumn<DateTime>(
        'data_inscricao',
        aliasedName,
        true,
        type: DriftSqlType.dateTime,
        requiredDuringInsert: false,
      );
  static const VerificationMeta _statusMeta = const VerificationMeta('status');
  @override
  late final GeneratedColumn<String> status = GeneratedColumn<String>(
    'status',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 1,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _observacoesMeta = const VerificationMeta(
    'observacoes',
  );
  @override
  late final GeneratedColumn<String> observacoes = GeneratedColumn<String>(
    'observacoes',
    aliasedName,
    true,
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  @override
  List<GeneratedColumn> get $columns => [
    id,
    idCampanha,
    idCliente,
    dataInscricao,
    status,
    observacoes,
  ];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'crm_campanha_cliente';
  @override
  VerificationContext validateIntegrity(
    Insertable<CrmCampanhaCliente> instance, {
    bool isInserting = false,
  }) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('id_campanha')) {
      context.handle(
        _idCampanhaMeta,
        idCampanha.isAcceptableOrUnknown(data['id_campanha']!, _idCampanhaMeta),
      );
    }
    if (data.containsKey('id_cliente')) {
      context.handle(
        _idClienteMeta,
        idCliente.isAcceptableOrUnknown(data['id_cliente']!, _idClienteMeta),
      );
    }
    if (data.containsKey('data_inscricao')) {
      context.handle(
        _dataInscricaoMeta,
        dataInscricao.isAcceptableOrUnknown(
          data['data_inscricao']!,
          _dataInscricaoMeta,
        ),
      );
    }
    if (data.containsKey('status')) {
      context.handle(
        _statusMeta,
        status.isAcceptableOrUnknown(data['status']!, _statusMeta),
      );
    }
    if (data.containsKey('observacoes')) {
      context.handle(
        _observacoesMeta,
        observacoes.isAcceptableOrUnknown(
          data['observacoes']!,
          _observacoesMeta,
        ),
      );
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  CrmCampanhaCliente map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return CrmCampanhaCliente(
      id: attachedDatabase.typeMapping.read(
        DriftSqlType.int,
        data['${effectivePrefix}id'],
      ),
      idCampanha: attachedDatabase.typeMapping.read(
        DriftSqlType.int,
        data['${effectivePrefix}id_campanha'],
      ),
      idCliente: attachedDatabase.typeMapping.read(
        DriftSqlType.int,
        data['${effectivePrefix}id_cliente'],
      ),
      dataInscricao: attachedDatabase.typeMapping.read(
        DriftSqlType.dateTime,
        data['${effectivePrefix}data_inscricao'],
      ),
      status: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}status'],
      ),
      observacoes: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}observacoes'],
      ),
    );
  }

  @override
  $CrmCampanhaClientesTable createAlias(String alias) {
    return $CrmCampanhaClientesTable(attachedDatabase, alias);
  }
}

class CrmCampanhaCliente extends DataClass
    implements Insertable<CrmCampanhaCliente> {
  final int? id;
  final int? idCampanha;
  final int? idCliente;
  final DateTime? dataInscricao;
  final String? status;
  final String? observacoes;
  const CrmCampanhaCliente({
    this.id,
    this.idCampanha,
    this.idCliente,
    this.dataInscricao,
    this.status,
    this.observacoes,
  });
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || idCampanha != null) {
      map['id_campanha'] = Variable<int>(idCampanha);
    }
    if (!nullToAbsent || idCliente != null) {
      map['id_cliente'] = Variable<int>(idCliente);
    }
    if (!nullToAbsent || dataInscricao != null) {
      map['data_inscricao'] = Variable<DateTime>(dataInscricao);
    }
    if (!nullToAbsent || status != null) {
      map['status'] = Variable<String>(status);
    }
    if (!nullToAbsent || observacoes != null) {
      map['observacoes'] = Variable<String>(observacoes);
    }
    return map;
  }

  factory CrmCampanhaCliente.fromJson(
    Map<String, dynamic> json, {
    ValueSerializer? serializer,
  }) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return CrmCampanhaCliente(
      id: serializer.fromJson<int?>(json['id']),
      idCampanha: serializer.fromJson<int?>(json['idCampanha']),
      idCliente: serializer.fromJson<int?>(json['idCliente']),
      dataInscricao: serializer.fromJson<DateTime?>(json['dataInscricao']),
      status: serializer.fromJson<String?>(json['status']),
      observacoes: serializer.fromJson<String?>(json['observacoes']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'idCampanha': serializer.toJson<int?>(idCampanha),
      'idCliente': serializer.toJson<int?>(idCliente),
      'dataInscricao': serializer.toJson<DateTime?>(dataInscricao),
      'status': serializer.toJson<String?>(status),
      'observacoes': serializer.toJson<String?>(observacoes),
    };
  }

  CrmCampanhaCliente copyWith({
    Value<int?> id = const Value.absent(),
    Value<int?> idCampanha = const Value.absent(),
    Value<int?> idCliente = const Value.absent(),
    Value<DateTime?> dataInscricao = const Value.absent(),
    Value<String?> status = const Value.absent(),
    Value<String?> observacoes = const Value.absent(),
  }) => CrmCampanhaCliente(
    id: id.present ? id.value : this.id,
    idCampanha: idCampanha.present ? idCampanha.value : this.idCampanha,
    idCliente: idCliente.present ? idCliente.value : this.idCliente,
    dataInscricao:
        dataInscricao.present ? dataInscricao.value : this.dataInscricao,
    status: status.present ? status.value : this.status,
    observacoes: observacoes.present ? observacoes.value : this.observacoes,
  );
  CrmCampanhaCliente copyWithCompanion(CrmCampanhaClientesCompanion data) {
    return CrmCampanhaCliente(
      id: data.id.present ? data.id.value : this.id,
      idCampanha:
          data.idCampanha.present ? data.idCampanha.value : this.idCampanha,
      idCliente: data.idCliente.present ? data.idCliente.value : this.idCliente,
      dataInscricao:
          data.dataInscricao.present
              ? data.dataInscricao.value
              : this.dataInscricao,
      status: data.status.present ? data.status.value : this.status,
      observacoes:
          data.observacoes.present ? data.observacoes.value : this.observacoes,
    );
  }

  @override
  String toString() {
    return (StringBuffer('CrmCampanhaCliente(')
          ..write('id: $id, ')
          ..write('idCampanha: $idCampanha, ')
          ..write('idCliente: $idCliente, ')
          ..write('dataInscricao: $dataInscricao, ')
          ..write('status: $status, ')
          ..write('observacoes: $observacoes')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(
    id,
    idCampanha,
    idCliente,
    dataInscricao,
    status,
    observacoes,
  );
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is CrmCampanhaCliente &&
          other.id == this.id &&
          other.idCampanha == this.idCampanha &&
          other.idCliente == this.idCliente &&
          other.dataInscricao == this.dataInscricao &&
          other.status == this.status &&
          other.observacoes == this.observacoes);
}

class CrmCampanhaClientesCompanion extends UpdateCompanion<CrmCampanhaCliente> {
  final Value<int?> id;
  final Value<int?> idCampanha;
  final Value<int?> idCliente;
  final Value<DateTime?> dataInscricao;
  final Value<String?> status;
  final Value<String?> observacoes;
  const CrmCampanhaClientesCompanion({
    this.id = const Value.absent(),
    this.idCampanha = const Value.absent(),
    this.idCliente = const Value.absent(),
    this.dataInscricao = const Value.absent(),
    this.status = const Value.absent(),
    this.observacoes = const Value.absent(),
  });
  CrmCampanhaClientesCompanion.insert({
    this.id = const Value.absent(),
    this.idCampanha = const Value.absent(),
    this.idCliente = const Value.absent(),
    this.dataInscricao = const Value.absent(),
    this.status = const Value.absent(),
    this.observacoes = const Value.absent(),
  });
  static Insertable<CrmCampanhaCliente> custom({
    Expression<int>? id,
    Expression<int>? idCampanha,
    Expression<int>? idCliente,
    Expression<DateTime>? dataInscricao,
    Expression<String>? status,
    Expression<String>? observacoes,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (idCampanha != null) 'id_campanha': idCampanha,
      if (idCliente != null) 'id_cliente': idCliente,
      if (dataInscricao != null) 'data_inscricao': dataInscricao,
      if (status != null) 'status': status,
      if (observacoes != null) 'observacoes': observacoes,
    });
  }

  CrmCampanhaClientesCompanion copyWith({
    Value<int?>? id,
    Value<int?>? idCampanha,
    Value<int?>? idCliente,
    Value<DateTime?>? dataInscricao,
    Value<String?>? status,
    Value<String?>? observacoes,
  }) {
    return CrmCampanhaClientesCompanion(
      id: id ?? this.id,
      idCampanha: idCampanha ?? this.idCampanha,
      idCliente: idCliente ?? this.idCliente,
      dataInscricao: dataInscricao ?? this.dataInscricao,
      status: status ?? this.status,
      observacoes: observacoes ?? this.observacoes,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (idCampanha.present) {
      map['id_campanha'] = Variable<int>(idCampanha.value);
    }
    if (idCliente.present) {
      map['id_cliente'] = Variable<int>(idCliente.value);
    }
    if (dataInscricao.present) {
      map['data_inscricao'] = Variable<DateTime>(dataInscricao.value);
    }
    if (status.present) {
      map['status'] = Variable<String>(status.value);
    }
    if (observacoes.present) {
      map['observacoes'] = Variable<String>(observacoes.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('CrmCampanhaClientesCompanion(')
          ..write('id: $id, ')
          ..write('idCampanha: $idCampanha, ')
          ..write('idCliente: $idCliente, ')
          ..write('dataInscricao: $dataInscricao, ')
          ..write('status: $status, ')
          ..write('observacoes: $observacoes')
          ..write(')'))
        .toString();
  }
}

class $CrmSacCabecalhosTable extends CrmSacCabecalhos
    with TableInfo<$CrmSacCabecalhosTable, CrmSacCabecalho> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $CrmSacCabecalhosTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
    'id',
    aliasedName,
    true,
    type: DriftSqlType.int,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _idClienteMeta = const VerificationMeta(
    'idCliente',
  );
  @override
  late final GeneratedColumn<int> idCliente = GeneratedColumn<int>(
    'id_cliente',
    aliasedName,
    true,
    type: DriftSqlType.int,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _dataAberturaMeta = const VerificationMeta(
    'dataAbertura',
  );
  @override
  late final GeneratedColumn<DateTime> dataAbertura = GeneratedColumn<DateTime>(
    'data_abertura',
    aliasedName,
    true,
    type: DriftSqlType.dateTime,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _horaAberturaMeta = const VerificationMeta(
    'horaAbertura',
  );
  @override
  late final GeneratedColumn<String> horaAbertura = GeneratedColumn<String>(
    'hora_abertura',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 8,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _nivelReclamacaoMeta = const VerificationMeta(
    'nivelReclamacao',
  );
  @override
  late final GeneratedColumn<String> nivelReclamacao = GeneratedColumn<String>(
    'nivel_reclamacao',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 1,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _numeroProtocoloMeta = const VerificationMeta(
    'numeroProtocolo',
  );
  @override
  late final GeneratedColumn<String> numeroProtocolo = GeneratedColumn<String>(
    'numero_protocolo',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 100,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  @override
  List<GeneratedColumn> get $columns => [
    id,
    idCliente,
    dataAbertura,
    horaAbertura,
    nivelReclamacao,
    numeroProtocolo,
  ];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'crm_sac_cabecalho';
  @override
  VerificationContext validateIntegrity(
    Insertable<CrmSacCabecalho> instance, {
    bool isInserting = false,
  }) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('id_cliente')) {
      context.handle(
        _idClienteMeta,
        idCliente.isAcceptableOrUnknown(data['id_cliente']!, _idClienteMeta),
      );
    }
    if (data.containsKey('data_abertura')) {
      context.handle(
        _dataAberturaMeta,
        dataAbertura.isAcceptableOrUnknown(
          data['data_abertura']!,
          _dataAberturaMeta,
        ),
      );
    }
    if (data.containsKey('hora_abertura')) {
      context.handle(
        _horaAberturaMeta,
        horaAbertura.isAcceptableOrUnknown(
          data['hora_abertura']!,
          _horaAberturaMeta,
        ),
      );
    }
    if (data.containsKey('nivel_reclamacao')) {
      context.handle(
        _nivelReclamacaoMeta,
        nivelReclamacao.isAcceptableOrUnknown(
          data['nivel_reclamacao']!,
          _nivelReclamacaoMeta,
        ),
      );
    }
    if (data.containsKey('numero_protocolo')) {
      context.handle(
        _numeroProtocoloMeta,
        numeroProtocolo.isAcceptableOrUnknown(
          data['numero_protocolo']!,
          _numeroProtocoloMeta,
        ),
      );
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  CrmSacCabecalho map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return CrmSacCabecalho(
      id: attachedDatabase.typeMapping.read(
        DriftSqlType.int,
        data['${effectivePrefix}id'],
      ),
      idCliente: attachedDatabase.typeMapping.read(
        DriftSqlType.int,
        data['${effectivePrefix}id_cliente'],
      ),
      dataAbertura: attachedDatabase.typeMapping.read(
        DriftSqlType.dateTime,
        data['${effectivePrefix}data_abertura'],
      ),
      horaAbertura: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}hora_abertura'],
      ),
      nivelReclamacao: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}nivel_reclamacao'],
      ),
      numeroProtocolo: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}numero_protocolo'],
      ),
    );
  }

  @override
  $CrmSacCabecalhosTable createAlias(String alias) {
    return $CrmSacCabecalhosTable(attachedDatabase, alias);
  }
}

class CrmSacCabecalho extends DataClass implements Insertable<CrmSacCabecalho> {
  final int? id;
  final int? idCliente;
  final DateTime? dataAbertura;
  final String? horaAbertura;
  final String? nivelReclamacao;
  final String? numeroProtocolo;
  const CrmSacCabecalho({
    this.id,
    this.idCliente,
    this.dataAbertura,
    this.horaAbertura,
    this.nivelReclamacao,
    this.numeroProtocolo,
  });
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || idCliente != null) {
      map['id_cliente'] = Variable<int>(idCliente);
    }
    if (!nullToAbsent || dataAbertura != null) {
      map['data_abertura'] = Variable<DateTime>(dataAbertura);
    }
    if (!nullToAbsent || horaAbertura != null) {
      map['hora_abertura'] = Variable<String>(horaAbertura);
    }
    if (!nullToAbsent || nivelReclamacao != null) {
      map['nivel_reclamacao'] = Variable<String>(nivelReclamacao);
    }
    if (!nullToAbsent || numeroProtocolo != null) {
      map['numero_protocolo'] = Variable<String>(numeroProtocolo);
    }
    return map;
  }

  factory CrmSacCabecalho.fromJson(
    Map<String, dynamic> json, {
    ValueSerializer? serializer,
  }) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return CrmSacCabecalho(
      id: serializer.fromJson<int?>(json['id']),
      idCliente: serializer.fromJson<int?>(json['idCliente']),
      dataAbertura: serializer.fromJson<DateTime?>(json['dataAbertura']),
      horaAbertura: serializer.fromJson<String?>(json['horaAbertura']),
      nivelReclamacao: serializer.fromJson<String?>(json['nivelReclamacao']),
      numeroProtocolo: serializer.fromJson<String?>(json['numeroProtocolo']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'idCliente': serializer.toJson<int?>(idCliente),
      'dataAbertura': serializer.toJson<DateTime?>(dataAbertura),
      'horaAbertura': serializer.toJson<String?>(horaAbertura),
      'nivelReclamacao': serializer.toJson<String?>(nivelReclamacao),
      'numeroProtocolo': serializer.toJson<String?>(numeroProtocolo),
    };
  }

  CrmSacCabecalho copyWith({
    Value<int?> id = const Value.absent(),
    Value<int?> idCliente = const Value.absent(),
    Value<DateTime?> dataAbertura = const Value.absent(),
    Value<String?> horaAbertura = const Value.absent(),
    Value<String?> nivelReclamacao = const Value.absent(),
    Value<String?> numeroProtocolo = const Value.absent(),
  }) => CrmSacCabecalho(
    id: id.present ? id.value : this.id,
    idCliente: idCliente.present ? idCliente.value : this.idCliente,
    dataAbertura: dataAbertura.present ? dataAbertura.value : this.dataAbertura,
    horaAbertura: horaAbertura.present ? horaAbertura.value : this.horaAbertura,
    nivelReclamacao:
        nivelReclamacao.present ? nivelReclamacao.value : this.nivelReclamacao,
    numeroProtocolo:
        numeroProtocolo.present ? numeroProtocolo.value : this.numeroProtocolo,
  );
  CrmSacCabecalho copyWithCompanion(CrmSacCabecalhosCompanion data) {
    return CrmSacCabecalho(
      id: data.id.present ? data.id.value : this.id,
      idCliente: data.idCliente.present ? data.idCliente.value : this.idCliente,
      dataAbertura:
          data.dataAbertura.present
              ? data.dataAbertura.value
              : this.dataAbertura,
      horaAbertura:
          data.horaAbertura.present
              ? data.horaAbertura.value
              : this.horaAbertura,
      nivelReclamacao:
          data.nivelReclamacao.present
              ? data.nivelReclamacao.value
              : this.nivelReclamacao,
      numeroProtocolo:
          data.numeroProtocolo.present
              ? data.numeroProtocolo.value
              : this.numeroProtocolo,
    );
  }

  @override
  String toString() {
    return (StringBuffer('CrmSacCabecalho(')
          ..write('id: $id, ')
          ..write('idCliente: $idCliente, ')
          ..write('dataAbertura: $dataAbertura, ')
          ..write('horaAbertura: $horaAbertura, ')
          ..write('nivelReclamacao: $nivelReclamacao, ')
          ..write('numeroProtocolo: $numeroProtocolo')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(
    id,
    idCliente,
    dataAbertura,
    horaAbertura,
    nivelReclamacao,
    numeroProtocolo,
  );
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is CrmSacCabecalho &&
          other.id == this.id &&
          other.idCliente == this.idCliente &&
          other.dataAbertura == this.dataAbertura &&
          other.horaAbertura == this.horaAbertura &&
          other.nivelReclamacao == this.nivelReclamacao &&
          other.numeroProtocolo == this.numeroProtocolo);
}

class CrmSacCabecalhosCompanion extends UpdateCompanion<CrmSacCabecalho> {
  final Value<int?> id;
  final Value<int?> idCliente;
  final Value<DateTime?> dataAbertura;
  final Value<String?> horaAbertura;
  final Value<String?> nivelReclamacao;
  final Value<String?> numeroProtocolo;
  const CrmSacCabecalhosCompanion({
    this.id = const Value.absent(),
    this.idCliente = const Value.absent(),
    this.dataAbertura = const Value.absent(),
    this.horaAbertura = const Value.absent(),
    this.nivelReclamacao = const Value.absent(),
    this.numeroProtocolo = const Value.absent(),
  });
  CrmSacCabecalhosCompanion.insert({
    this.id = const Value.absent(),
    this.idCliente = const Value.absent(),
    this.dataAbertura = const Value.absent(),
    this.horaAbertura = const Value.absent(),
    this.nivelReclamacao = const Value.absent(),
    this.numeroProtocolo = const Value.absent(),
  });
  static Insertable<CrmSacCabecalho> custom({
    Expression<int>? id,
    Expression<int>? idCliente,
    Expression<DateTime>? dataAbertura,
    Expression<String>? horaAbertura,
    Expression<String>? nivelReclamacao,
    Expression<String>? numeroProtocolo,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (idCliente != null) 'id_cliente': idCliente,
      if (dataAbertura != null) 'data_abertura': dataAbertura,
      if (horaAbertura != null) 'hora_abertura': horaAbertura,
      if (nivelReclamacao != null) 'nivel_reclamacao': nivelReclamacao,
      if (numeroProtocolo != null) 'numero_protocolo': numeroProtocolo,
    });
  }

  CrmSacCabecalhosCompanion copyWith({
    Value<int?>? id,
    Value<int?>? idCliente,
    Value<DateTime?>? dataAbertura,
    Value<String?>? horaAbertura,
    Value<String?>? nivelReclamacao,
    Value<String?>? numeroProtocolo,
  }) {
    return CrmSacCabecalhosCompanion(
      id: id ?? this.id,
      idCliente: idCliente ?? this.idCliente,
      dataAbertura: dataAbertura ?? this.dataAbertura,
      horaAbertura: horaAbertura ?? this.horaAbertura,
      nivelReclamacao: nivelReclamacao ?? this.nivelReclamacao,
      numeroProtocolo: numeroProtocolo ?? this.numeroProtocolo,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (idCliente.present) {
      map['id_cliente'] = Variable<int>(idCliente.value);
    }
    if (dataAbertura.present) {
      map['data_abertura'] = Variable<DateTime>(dataAbertura.value);
    }
    if (horaAbertura.present) {
      map['hora_abertura'] = Variable<String>(horaAbertura.value);
    }
    if (nivelReclamacao.present) {
      map['nivel_reclamacao'] = Variable<String>(nivelReclamacao.value);
    }
    if (numeroProtocolo.present) {
      map['numero_protocolo'] = Variable<String>(numeroProtocolo.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('CrmSacCabecalhosCompanion(')
          ..write('id: $id, ')
          ..write('idCliente: $idCliente, ')
          ..write('dataAbertura: $dataAbertura, ')
          ..write('horaAbertura: $horaAbertura, ')
          ..write('nivelReclamacao: $nivelReclamacao, ')
          ..write('numeroProtocolo: $numeroProtocolo')
          ..write(')'))
        .toString();
  }
}

class $CrmCarteiraClientePerfilsTable extends CrmCarteiraClientePerfils
    with TableInfo<$CrmCarteiraClientePerfilsTable, CrmCarteiraClientePerfil> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $CrmCarteiraClientePerfilsTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
    'id',
    aliasedName,
    true,
    type: DriftSqlType.int,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _codigoMeta = const VerificationMeta('codigo');
  @override
  late final GeneratedColumn<String> codigo = GeneratedColumn<String>(
    'codigo',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 2,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _nomeMeta = const VerificationMeta('nome');
  @override
  late final GeneratedColumn<String> nome = GeneratedColumn<String>(
    'nome',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 100,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  @override
  List<GeneratedColumn> get $columns => [id, codigo, nome];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'crm_carteira_cliente_perfil';
  @override
  VerificationContext validateIntegrity(
    Insertable<CrmCarteiraClientePerfil> instance, {
    bool isInserting = false,
  }) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('codigo')) {
      context.handle(
        _codigoMeta,
        codigo.isAcceptableOrUnknown(data['codigo']!, _codigoMeta),
      );
    }
    if (data.containsKey('nome')) {
      context.handle(
        _nomeMeta,
        nome.isAcceptableOrUnknown(data['nome']!, _nomeMeta),
      );
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  CrmCarteiraClientePerfil map(
    Map<String, dynamic> data, {
    String? tablePrefix,
  }) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return CrmCarteiraClientePerfil(
      id: attachedDatabase.typeMapping.read(
        DriftSqlType.int,
        data['${effectivePrefix}id'],
      ),
      codigo: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}codigo'],
      ),
      nome: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}nome'],
      ),
    );
  }

  @override
  $CrmCarteiraClientePerfilsTable createAlias(String alias) {
    return $CrmCarteiraClientePerfilsTable(attachedDatabase, alias);
  }
}

class CrmCarteiraClientePerfil extends DataClass
    implements Insertable<CrmCarteiraClientePerfil> {
  final int? id;
  final String? codigo;
  final String? nome;
  const CrmCarteiraClientePerfil({this.id, this.codigo, this.nome});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || codigo != null) {
      map['codigo'] = Variable<String>(codigo);
    }
    if (!nullToAbsent || nome != null) {
      map['nome'] = Variable<String>(nome);
    }
    return map;
  }

  factory CrmCarteiraClientePerfil.fromJson(
    Map<String, dynamic> json, {
    ValueSerializer? serializer,
  }) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return CrmCarteiraClientePerfil(
      id: serializer.fromJson<int?>(json['id']),
      codigo: serializer.fromJson<String?>(json['codigo']),
      nome: serializer.fromJson<String?>(json['nome']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'codigo': serializer.toJson<String?>(codigo),
      'nome': serializer.toJson<String?>(nome),
    };
  }

  CrmCarteiraClientePerfil copyWith({
    Value<int?> id = const Value.absent(),
    Value<String?> codigo = const Value.absent(),
    Value<String?> nome = const Value.absent(),
  }) => CrmCarteiraClientePerfil(
    id: id.present ? id.value : this.id,
    codigo: codigo.present ? codigo.value : this.codigo,
    nome: nome.present ? nome.value : this.nome,
  );
  CrmCarteiraClientePerfil copyWithCompanion(
    CrmCarteiraClientePerfilsCompanion data,
  ) {
    return CrmCarteiraClientePerfil(
      id: data.id.present ? data.id.value : this.id,
      codigo: data.codigo.present ? data.codigo.value : this.codigo,
      nome: data.nome.present ? data.nome.value : this.nome,
    );
  }

  @override
  String toString() {
    return (StringBuffer('CrmCarteiraClientePerfil(')
          ..write('id: $id, ')
          ..write('codigo: $codigo, ')
          ..write('nome: $nome')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(id, codigo, nome);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is CrmCarteiraClientePerfil &&
          other.id == this.id &&
          other.codigo == this.codigo &&
          other.nome == this.nome);
}

class CrmCarteiraClientePerfilsCompanion
    extends UpdateCompanion<CrmCarteiraClientePerfil> {
  final Value<int?> id;
  final Value<String?> codigo;
  final Value<String?> nome;
  const CrmCarteiraClientePerfilsCompanion({
    this.id = const Value.absent(),
    this.codigo = const Value.absent(),
    this.nome = const Value.absent(),
  });
  CrmCarteiraClientePerfilsCompanion.insert({
    this.id = const Value.absent(),
    this.codigo = const Value.absent(),
    this.nome = const Value.absent(),
  });
  static Insertable<CrmCarteiraClientePerfil> custom({
    Expression<int>? id,
    Expression<String>? codigo,
    Expression<String>? nome,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (codigo != null) 'codigo': codigo,
      if (nome != null) 'nome': nome,
    });
  }

  CrmCarteiraClientePerfilsCompanion copyWith({
    Value<int?>? id,
    Value<String?>? codigo,
    Value<String?>? nome,
  }) {
    return CrmCarteiraClientePerfilsCompanion(
      id: id ?? this.id,
      codigo: codigo ?? this.codigo,
      nome: nome ?? this.nome,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (codigo.present) {
      map['codigo'] = Variable<String>(codigo.value);
    }
    if (nome.present) {
      map['nome'] = Variable<String>(nome.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('CrmCarteiraClientePerfilsCompanion(')
          ..write('id: $id, ')
          ..write('codigo: $codigo, ')
          ..write('nome: $nome')
          ..write(')'))
        .toString();
  }
}

class $CrmCampanhasTable extends CrmCampanhas
    with TableInfo<$CrmCampanhasTable, CrmCampanha> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $CrmCampanhasTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
    'id',
    aliasedName,
    true,
    type: DriftSqlType.int,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _nomeMeta = const VerificationMeta('nome');
  @override
  late final GeneratedColumn<String> nome = GeneratedColumn<String>(
    'nome',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 200,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _descricaoMeta = const VerificationMeta(
    'descricao',
  );
  @override
  late final GeneratedColumn<String> descricao = GeneratedColumn<String>(
    'descricao',
    aliasedName,
    true,
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _tipoMeta = const VerificationMeta('tipo');
  @override
  late final GeneratedColumn<String> tipo = GeneratedColumn<String>(
    'tipo',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 1,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _dataInicioMeta = const VerificationMeta(
    'dataInicio',
  );
  @override
  late final GeneratedColumn<DateTime> dataInicio = GeneratedColumn<DateTime>(
    'data_inicio',
    aliasedName,
    true,
    type: DriftSqlType.dateTime,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _dataFimMeta = const VerificationMeta(
    'dataFim',
  );
  @override
  late final GeneratedColumn<DateTime> dataFim = GeneratedColumn<DateTime>(
    'data_fim',
    aliasedName,
    true,
    type: DriftSqlType.dateTime,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _orcamentoMeta = const VerificationMeta(
    'orcamento',
  );
  @override
  late final GeneratedColumn<double> orcamento = GeneratedColumn<double>(
    'orcamento',
    aliasedName,
    true,
    type: DriftSqlType.double,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _statusMeta = const VerificationMeta('status');
  @override
  late final GeneratedColumn<String> status = GeneratedColumn<String>(
    'status',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 1,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  @override
  List<GeneratedColumn> get $columns => [
    id,
    nome,
    descricao,
    tipo,
    dataInicio,
    dataFim,
    orcamento,
    status,
  ];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'crm_campanha';
  @override
  VerificationContext validateIntegrity(
    Insertable<CrmCampanha> instance, {
    bool isInserting = false,
  }) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('nome')) {
      context.handle(
        _nomeMeta,
        nome.isAcceptableOrUnknown(data['nome']!, _nomeMeta),
      );
    }
    if (data.containsKey('descricao')) {
      context.handle(
        _descricaoMeta,
        descricao.isAcceptableOrUnknown(data['descricao']!, _descricaoMeta),
      );
    }
    if (data.containsKey('tipo')) {
      context.handle(
        _tipoMeta,
        tipo.isAcceptableOrUnknown(data['tipo']!, _tipoMeta),
      );
    }
    if (data.containsKey('data_inicio')) {
      context.handle(
        _dataInicioMeta,
        dataInicio.isAcceptableOrUnknown(data['data_inicio']!, _dataInicioMeta),
      );
    }
    if (data.containsKey('data_fim')) {
      context.handle(
        _dataFimMeta,
        dataFim.isAcceptableOrUnknown(data['data_fim']!, _dataFimMeta),
      );
    }
    if (data.containsKey('orcamento')) {
      context.handle(
        _orcamentoMeta,
        orcamento.isAcceptableOrUnknown(data['orcamento']!, _orcamentoMeta),
      );
    }
    if (data.containsKey('status')) {
      context.handle(
        _statusMeta,
        status.isAcceptableOrUnknown(data['status']!, _statusMeta),
      );
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  CrmCampanha map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return CrmCampanha(
      id: attachedDatabase.typeMapping.read(
        DriftSqlType.int,
        data['${effectivePrefix}id'],
      ),
      nome: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}nome'],
      ),
      descricao: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}descricao'],
      ),
      tipo: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}tipo'],
      ),
      dataInicio: attachedDatabase.typeMapping.read(
        DriftSqlType.dateTime,
        data['${effectivePrefix}data_inicio'],
      ),
      dataFim: attachedDatabase.typeMapping.read(
        DriftSqlType.dateTime,
        data['${effectivePrefix}data_fim'],
      ),
      orcamento: attachedDatabase.typeMapping.read(
        DriftSqlType.double,
        data['${effectivePrefix}orcamento'],
      ),
      status: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}status'],
      ),
    );
  }

  @override
  $CrmCampanhasTable createAlias(String alias) {
    return $CrmCampanhasTable(attachedDatabase, alias);
  }
}

class CrmCampanha extends DataClass implements Insertable<CrmCampanha> {
  final int? id;
  final String? nome;
  final String? descricao;
  final String? tipo;
  final DateTime? dataInicio;
  final DateTime? dataFim;
  final double? orcamento;
  final String? status;
  const CrmCampanha({
    this.id,
    this.nome,
    this.descricao,
    this.tipo,
    this.dataInicio,
    this.dataFim,
    this.orcamento,
    this.status,
  });
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || nome != null) {
      map['nome'] = Variable<String>(nome);
    }
    if (!nullToAbsent || descricao != null) {
      map['descricao'] = Variable<String>(descricao);
    }
    if (!nullToAbsent || tipo != null) {
      map['tipo'] = Variable<String>(tipo);
    }
    if (!nullToAbsent || dataInicio != null) {
      map['data_inicio'] = Variable<DateTime>(dataInicio);
    }
    if (!nullToAbsent || dataFim != null) {
      map['data_fim'] = Variable<DateTime>(dataFim);
    }
    if (!nullToAbsent || orcamento != null) {
      map['orcamento'] = Variable<double>(orcamento);
    }
    if (!nullToAbsent || status != null) {
      map['status'] = Variable<String>(status);
    }
    return map;
  }

  factory CrmCampanha.fromJson(
    Map<String, dynamic> json, {
    ValueSerializer? serializer,
  }) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return CrmCampanha(
      id: serializer.fromJson<int?>(json['id']),
      nome: serializer.fromJson<String?>(json['nome']),
      descricao: serializer.fromJson<String?>(json['descricao']),
      tipo: serializer.fromJson<String?>(json['tipo']),
      dataInicio: serializer.fromJson<DateTime?>(json['dataInicio']),
      dataFim: serializer.fromJson<DateTime?>(json['dataFim']),
      orcamento: serializer.fromJson<double?>(json['orcamento']),
      status: serializer.fromJson<String?>(json['status']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'nome': serializer.toJson<String?>(nome),
      'descricao': serializer.toJson<String?>(descricao),
      'tipo': serializer.toJson<String?>(tipo),
      'dataInicio': serializer.toJson<DateTime?>(dataInicio),
      'dataFim': serializer.toJson<DateTime?>(dataFim),
      'orcamento': serializer.toJson<double?>(orcamento),
      'status': serializer.toJson<String?>(status),
    };
  }

  CrmCampanha copyWith({
    Value<int?> id = const Value.absent(),
    Value<String?> nome = const Value.absent(),
    Value<String?> descricao = const Value.absent(),
    Value<String?> tipo = const Value.absent(),
    Value<DateTime?> dataInicio = const Value.absent(),
    Value<DateTime?> dataFim = const Value.absent(),
    Value<double?> orcamento = const Value.absent(),
    Value<String?> status = const Value.absent(),
  }) => CrmCampanha(
    id: id.present ? id.value : this.id,
    nome: nome.present ? nome.value : this.nome,
    descricao: descricao.present ? descricao.value : this.descricao,
    tipo: tipo.present ? tipo.value : this.tipo,
    dataInicio: dataInicio.present ? dataInicio.value : this.dataInicio,
    dataFim: dataFim.present ? dataFim.value : this.dataFim,
    orcamento: orcamento.present ? orcamento.value : this.orcamento,
    status: status.present ? status.value : this.status,
  );
  CrmCampanha copyWithCompanion(CrmCampanhasCompanion data) {
    return CrmCampanha(
      id: data.id.present ? data.id.value : this.id,
      nome: data.nome.present ? data.nome.value : this.nome,
      descricao: data.descricao.present ? data.descricao.value : this.descricao,
      tipo: data.tipo.present ? data.tipo.value : this.tipo,
      dataInicio:
          data.dataInicio.present ? data.dataInicio.value : this.dataInicio,
      dataFim: data.dataFim.present ? data.dataFim.value : this.dataFim,
      orcamento: data.orcamento.present ? data.orcamento.value : this.orcamento,
      status: data.status.present ? data.status.value : this.status,
    );
  }

  @override
  String toString() {
    return (StringBuffer('CrmCampanha(')
          ..write('id: $id, ')
          ..write('nome: $nome, ')
          ..write('descricao: $descricao, ')
          ..write('tipo: $tipo, ')
          ..write('dataInicio: $dataInicio, ')
          ..write('dataFim: $dataFim, ')
          ..write('orcamento: $orcamento, ')
          ..write('status: $status')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(
    id,
    nome,
    descricao,
    tipo,
    dataInicio,
    dataFim,
    orcamento,
    status,
  );
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is CrmCampanha &&
          other.id == this.id &&
          other.nome == this.nome &&
          other.descricao == this.descricao &&
          other.tipo == this.tipo &&
          other.dataInicio == this.dataInicio &&
          other.dataFim == this.dataFim &&
          other.orcamento == this.orcamento &&
          other.status == this.status);
}

class CrmCampanhasCompanion extends UpdateCompanion<CrmCampanha> {
  final Value<int?> id;
  final Value<String?> nome;
  final Value<String?> descricao;
  final Value<String?> tipo;
  final Value<DateTime?> dataInicio;
  final Value<DateTime?> dataFim;
  final Value<double?> orcamento;
  final Value<String?> status;
  const CrmCampanhasCompanion({
    this.id = const Value.absent(),
    this.nome = const Value.absent(),
    this.descricao = const Value.absent(),
    this.tipo = const Value.absent(),
    this.dataInicio = const Value.absent(),
    this.dataFim = const Value.absent(),
    this.orcamento = const Value.absent(),
    this.status = const Value.absent(),
  });
  CrmCampanhasCompanion.insert({
    this.id = const Value.absent(),
    this.nome = const Value.absent(),
    this.descricao = const Value.absent(),
    this.tipo = const Value.absent(),
    this.dataInicio = const Value.absent(),
    this.dataFim = const Value.absent(),
    this.orcamento = const Value.absent(),
    this.status = const Value.absent(),
  });
  static Insertable<CrmCampanha> custom({
    Expression<int>? id,
    Expression<String>? nome,
    Expression<String>? descricao,
    Expression<String>? tipo,
    Expression<DateTime>? dataInicio,
    Expression<DateTime>? dataFim,
    Expression<double>? orcamento,
    Expression<String>? status,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (nome != null) 'nome': nome,
      if (descricao != null) 'descricao': descricao,
      if (tipo != null) 'tipo': tipo,
      if (dataInicio != null) 'data_inicio': dataInicio,
      if (dataFim != null) 'data_fim': dataFim,
      if (orcamento != null) 'orcamento': orcamento,
      if (status != null) 'status': status,
    });
  }

  CrmCampanhasCompanion copyWith({
    Value<int?>? id,
    Value<String?>? nome,
    Value<String?>? descricao,
    Value<String?>? tipo,
    Value<DateTime?>? dataInicio,
    Value<DateTime?>? dataFim,
    Value<double?>? orcamento,
    Value<String?>? status,
  }) {
    return CrmCampanhasCompanion(
      id: id ?? this.id,
      nome: nome ?? this.nome,
      descricao: descricao ?? this.descricao,
      tipo: tipo ?? this.tipo,
      dataInicio: dataInicio ?? this.dataInicio,
      dataFim: dataFim ?? this.dataFim,
      orcamento: orcamento ?? this.orcamento,
      status: status ?? this.status,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (nome.present) {
      map['nome'] = Variable<String>(nome.value);
    }
    if (descricao.present) {
      map['descricao'] = Variable<String>(descricao.value);
    }
    if (tipo.present) {
      map['tipo'] = Variable<String>(tipo.value);
    }
    if (dataInicio.present) {
      map['data_inicio'] = Variable<DateTime>(dataInicio.value);
    }
    if (dataFim.present) {
      map['data_fim'] = Variable<DateTime>(dataFim.value);
    }
    if (orcamento.present) {
      map['orcamento'] = Variable<double>(orcamento.value);
    }
    if (status.present) {
      map['status'] = Variable<String>(status.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('CrmCampanhasCompanion(')
          ..write('id: $id, ')
          ..write('nome: $nome, ')
          ..write('descricao: $descricao, ')
          ..write('tipo: $tipo, ')
          ..write('dataInicio: $dataInicio, ')
          ..write('dataFim: $dataFim, ')
          ..write('orcamento: $orcamento, ')
          ..write('status: $status')
          ..write(')'))
        .toString();
  }
}

class $CrmBuscasClientesTable extends CrmBuscasClientes
    with TableInfo<$CrmBuscasClientesTable, CrmBuscasCliente> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $CrmBuscasClientesTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
    'id',
    aliasedName,
    true,
    type: DriftSqlType.int,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _idClienteMeta = const VerificationMeta(
    'idCliente',
  );
  @override
  late final GeneratedColumn<int> idCliente = GeneratedColumn<int>(
    'id_cliente',
    aliasedName,
    true,
    type: DriftSqlType.int,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _dataBuscaMeta = const VerificationMeta(
    'dataBusca',
  );
  @override
  late final GeneratedColumn<DateTime> dataBusca = GeneratedColumn<DateTime>(
    'data_busca',
    aliasedName,
    true,
    type: DriftSqlType.dateTime,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _horaBuscaMeta = const VerificationMeta(
    'horaBusca',
  );
  @override
  late final GeneratedColumn<String> horaBusca = GeneratedColumn<String>(
    'hora_busca',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 8,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _detalhesMeta = const VerificationMeta(
    'detalhes',
  );
  @override
  late final GeneratedColumn<String> detalhes = GeneratedColumn<String>(
    'detalhes',
    aliasedName,
    true,
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  @override
  List<GeneratedColumn> get $columns => [
    id,
    idCliente,
    dataBusca,
    horaBusca,
    detalhes,
  ];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'crm_buscas_cliente';
  @override
  VerificationContext validateIntegrity(
    Insertable<CrmBuscasCliente> instance, {
    bool isInserting = false,
  }) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('id_cliente')) {
      context.handle(
        _idClienteMeta,
        idCliente.isAcceptableOrUnknown(data['id_cliente']!, _idClienteMeta),
      );
    }
    if (data.containsKey('data_busca')) {
      context.handle(
        _dataBuscaMeta,
        dataBusca.isAcceptableOrUnknown(data['data_busca']!, _dataBuscaMeta),
      );
    }
    if (data.containsKey('hora_busca')) {
      context.handle(
        _horaBuscaMeta,
        horaBusca.isAcceptableOrUnknown(data['hora_busca']!, _horaBuscaMeta),
      );
    }
    if (data.containsKey('detalhes')) {
      context.handle(
        _detalhesMeta,
        detalhes.isAcceptableOrUnknown(data['detalhes']!, _detalhesMeta),
      );
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  CrmBuscasCliente map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return CrmBuscasCliente(
      id: attachedDatabase.typeMapping.read(
        DriftSqlType.int,
        data['${effectivePrefix}id'],
      ),
      idCliente: attachedDatabase.typeMapping.read(
        DriftSqlType.int,
        data['${effectivePrefix}id_cliente'],
      ),
      dataBusca: attachedDatabase.typeMapping.read(
        DriftSqlType.dateTime,
        data['${effectivePrefix}data_busca'],
      ),
      horaBusca: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}hora_busca'],
      ),
      detalhes: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}detalhes'],
      ),
    );
  }

  @override
  $CrmBuscasClientesTable createAlias(String alias) {
    return $CrmBuscasClientesTable(attachedDatabase, alias);
  }
}

class CrmBuscasCliente extends DataClass
    implements Insertable<CrmBuscasCliente> {
  final int? id;
  final int? idCliente;
  final DateTime? dataBusca;
  final String? horaBusca;
  final String? detalhes;
  const CrmBuscasCliente({
    this.id,
    this.idCliente,
    this.dataBusca,
    this.horaBusca,
    this.detalhes,
  });
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || idCliente != null) {
      map['id_cliente'] = Variable<int>(idCliente);
    }
    if (!nullToAbsent || dataBusca != null) {
      map['data_busca'] = Variable<DateTime>(dataBusca);
    }
    if (!nullToAbsent || horaBusca != null) {
      map['hora_busca'] = Variable<String>(horaBusca);
    }
    if (!nullToAbsent || detalhes != null) {
      map['detalhes'] = Variable<String>(detalhes);
    }
    return map;
  }

  factory CrmBuscasCliente.fromJson(
    Map<String, dynamic> json, {
    ValueSerializer? serializer,
  }) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return CrmBuscasCliente(
      id: serializer.fromJson<int?>(json['id']),
      idCliente: serializer.fromJson<int?>(json['idCliente']),
      dataBusca: serializer.fromJson<DateTime?>(json['dataBusca']),
      horaBusca: serializer.fromJson<String?>(json['horaBusca']),
      detalhes: serializer.fromJson<String?>(json['detalhes']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'idCliente': serializer.toJson<int?>(idCliente),
      'dataBusca': serializer.toJson<DateTime?>(dataBusca),
      'horaBusca': serializer.toJson<String?>(horaBusca),
      'detalhes': serializer.toJson<String?>(detalhes),
    };
  }

  CrmBuscasCliente copyWith({
    Value<int?> id = const Value.absent(),
    Value<int?> idCliente = const Value.absent(),
    Value<DateTime?> dataBusca = const Value.absent(),
    Value<String?> horaBusca = const Value.absent(),
    Value<String?> detalhes = const Value.absent(),
  }) => CrmBuscasCliente(
    id: id.present ? id.value : this.id,
    idCliente: idCliente.present ? idCliente.value : this.idCliente,
    dataBusca: dataBusca.present ? dataBusca.value : this.dataBusca,
    horaBusca: horaBusca.present ? horaBusca.value : this.horaBusca,
    detalhes: detalhes.present ? detalhes.value : this.detalhes,
  );
  CrmBuscasCliente copyWithCompanion(CrmBuscasClientesCompanion data) {
    return CrmBuscasCliente(
      id: data.id.present ? data.id.value : this.id,
      idCliente: data.idCliente.present ? data.idCliente.value : this.idCliente,
      dataBusca: data.dataBusca.present ? data.dataBusca.value : this.dataBusca,
      horaBusca: data.horaBusca.present ? data.horaBusca.value : this.horaBusca,
      detalhes: data.detalhes.present ? data.detalhes.value : this.detalhes,
    );
  }

  @override
  String toString() {
    return (StringBuffer('CrmBuscasCliente(')
          ..write('id: $id, ')
          ..write('idCliente: $idCliente, ')
          ..write('dataBusca: $dataBusca, ')
          ..write('horaBusca: $horaBusca, ')
          ..write('detalhes: $detalhes')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode =>
      Object.hash(id, idCliente, dataBusca, horaBusca, detalhes);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is CrmBuscasCliente &&
          other.id == this.id &&
          other.idCliente == this.idCliente &&
          other.dataBusca == this.dataBusca &&
          other.horaBusca == this.horaBusca &&
          other.detalhes == this.detalhes);
}

class CrmBuscasClientesCompanion extends UpdateCompanion<CrmBuscasCliente> {
  final Value<int?> id;
  final Value<int?> idCliente;
  final Value<DateTime?> dataBusca;
  final Value<String?> horaBusca;
  final Value<String?> detalhes;
  const CrmBuscasClientesCompanion({
    this.id = const Value.absent(),
    this.idCliente = const Value.absent(),
    this.dataBusca = const Value.absent(),
    this.horaBusca = const Value.absent(),
    this.detalhes = const Value.absent(),
  });
  CrmBuscasClientesCompanion.insert({
    this.id = const Value.absent(),
    this.idCliente = const Value.absent(),
    this.dataBusca = const Value.absent(),
    this.horaBusca = const Value.absent(),
    this.detalhes = const Value.absent(),
  });
  static Insertable<CrmBuscasCliente> custom({
    Expression<int>? id,
    Expression<int>? idCliente,
    Expression<DateTime>? dataBusca,
    Expression<String>? horaBusca,
    Expression<String>? detalhes,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (idCliente != null) 'id_cliente': idCliente,
      if (dataBusca != null) 'data_busca': dataBusca,
      if (horaBusca != null) 'hora_busca': horaBusca,
      if (detalhes != null) 'detalhes': detalhes,
    });
  }

  CrmBuscasClientesCompanion copyWith({
    Value<int?>? id,
    Value<int?>? idCliente,
    Value<DateTime?>? dataBusca,
    Value<String?>? horaBusca,
    Value<String?>? detalhes,
  }) {
    return CrmBuscasClientesCompanion(
      id: id ?? this.id,
      idCliente: idCliente ?? this.idCliente,
      dataBusca: dataBusca ?? this.dataBusca,
      horaBusca: horaBusca ?? this.horaBusca,
      detalhes: detalhes ?? this.detalhes,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (idCliente.present) {
      map['id_cliente'] = Variable<int>(idCliente.value);
    }
    if (dataBusca.present) {
      map['data_busca'] = Variable<DateTime>(dataBusca.value);
    }
    if (horaBusca.present) {
      map['hora_busca'] = Variable<String>(horaBusca.value);
    }
    if (detalhes.present) {
      map['detalhes'] = Variable<String>(detalhes.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('CrmBuscasClientesCompanion(')
          ..write('id: $id, ')
          ..write('idCliente: $idCliente, ')
          ..write('dataBusca: $dataBusca, ')
          ..write('horaBusca: $horaBusca, ')
          ..write('detalhes: $detalhes')
          ..write(')'))
        .toString();
  }
}

class $ViewControleAcessosTable extends ViewControleAcessos
    with TableInfo<$ViewControleAcessosTable, ViewControleAcesso> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $ViewControleAcessosTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
    'id',
    aliasedName,
    true,
    type: DriftSqlType.int,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _idPessoaMeta = const VerificationMeta(
    'idPessoa',
  );
  @override
  late final GeneratedColumn<int> idPessoa = GeneratedColumn<int>(
    'id_pessoa',
    aliasedName,
    true,
    type: DriftSqlType.int,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _pessoaNomeMeta = const VerificationMeta(
    'pessoaNome',
  );
  @override
  late final GeneratedColumn<String> pessoaNome = GeneratedColumn<String>(
    'pessoa_nome',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 450,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _idColaboradorMeta = const VerificationMeta(
    'idColaborador',
  );
  @override
  late final GeneratedColumn<int> idColaborador = GeneratedColumn<int>(
    'id_colaborador',
    aliasedName,
    true,
    type: DriftSqlType.int,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _idUsuarioMeta = const VerificationMeta(
    'idUsuario',
  );
  @override
  late final GeneratedColumn<int> idUsuario = GeneratedColumn<int>(
    'id_usuario',
    aliasedName,
    true,
    type: DriftSqlType.int,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _administradorMeta = const VerificationMeta(
    'administrador',
  );
  @override
  late final GeneratedColumn<String> administrador = GeneratedColumn<String>(
    'administrador',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 3,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _idPapelMeta = const VerificationMeta(
    'idPapel',
  );
  @override
  late final GeneratedColumn<int> idPapel = GeneratedColumn<int>(
    'id_papel',
    aliasedName,
    true,
    type: DriftSqlType.int,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _papelNomeMeta = const VerificationMeta(
    'papelNome',
  );
  @override
  late final GeneratedColumn<String> papelNome = GeneratedColumn<String>(
    'papel_nome',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 300,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _papelDescricaoMeta = const VerificationMeta(
    'papelDescricao',
  );
  @override
  late final GeneratedColumn<String> papelDescricao = GeneratedColumn<String>(
    'papel_descricao',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 750,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _idFuncaoMeta = const VerificationMeta(
    'idFuncao',
  );
  @override
  late final GeneratedColumn<int> idFuncao = GeneratedColumn<int>(
    'id_funcao',
    aliasedName,
    true,
    type: DriftSqlType.int,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _funcaoNomeMeta = const VerificationMeta(
    'funcaoNome',
  );
  @override
  late final GeneratedColumn<String> funcaoNome = GeneratedColumn<String>(
    'funcao_nome',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 300,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _funcaoDescricaoMeta = const VerificationMeta(
    'funcaoDescricao',
  );
  @override
  late final GeneratedColumn<String> funcaoDescricao = GeneratedColumn<String>(
    'funcao_descricao',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 750,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _idPapelFuncaoMeta = const VerificationMeta(
    'idPapelFuncao',
  );
  @override
  late final GeneratedColumn<int> idPapelFuncao = GeneratedColumn<int>(
    'id_papel_funcao',
    aliasedName,
    true,
    type: DriftSqlType.int,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _habilitadoMeta = const VerificationMeta(
    'habilitado',
  );
  @override
  late final GeneratedColumn<String> habilitado = GeneratedColumn<String>(
    'habilitado',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 3,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _podeInserirMeta = const VerificationMeta(
    'podeInserir',
  );
  @override
  late final GeneratedColumn<String> podeInserir = GeneratedColumn<String>(
    'pode_inserir',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 3,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _podeAlterarMeta = const VerificationMeta(
    'podeAlterar',
  );
  @override
  late final GeneratedColumn<String> podeAlterar = GeneratedColumn<String>(
    'pode_alterar',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 3,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _podeExcluirMeta = const VerificationMeta(
    'podeExcluir',
  );
  @override
  late final GeneratedColumn<String> podeExcluir = GeneratedColumn<String>(
    'pode_excluir',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 3,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  @override
  List<GeneratedColumn> get $columns => [
    id,
    idPessoa,
    pessoaNome,
    idColaborador,
    idUsuario,
    administrador,
    idPapel,
    papelNome,
    papelDescricao,
    idFuncao,
    funcaoNome,
    funcaoDescricao,
    idPapelFuncao,
    habilitado,
    podeInserir,
    podeAlterar,
    podeExcluir,
  ];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'view_controle_acesso';
  @override
  VerificationContext validateIntegrity(
    Insertable<ViewControleAcesso> instance, {
    bool isInserting = false,
  }) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('id_pessoa')) {
      context.handle(
        _idPessoaMeta,
        idPessoa.isAcceptableOrUnknown(data['id_pessoa']!, _idPessoaMeta),
      );
    }
    if (data.containsKey('pessoa_nome')) {
      context.handle(
        _pessoaNomeMeta,
        pessoaNome.isAcceptableOrUnknown(data['pessoa_nome']!, _pessoaNomeMeta),
      );
    }
    if (data.containsKey('id_colaborador')) {
      context.handle(
        _idColaboradorMeta,
        idColaborador.isAcceptableOrUnknown(
          data['id_colaborador']!,
          _idColaboradorMeta,
        ),
      );
    }
    if (data.containsKey('id_usuario')) {
      context.handle(
        _idUsuarioMeta,
        idUsuario.isAcceptableOrUnknown(data['id_usuario']!, _idUsuarioMeta),
      );
    }
    if (data.containsKey('administrador')) {
      context.handle(
        _administradorMeta,
        administrador.isAcceptableOrUnknown(
          data['administrador']!,
          _administradorMeta,
        ),
      );
    }
    if (data.containsKey('id_papel')) {
      context.handle(
        _idPapelMeta,
        idPapel.isAcceptableOrUnknown(data['id_papel']!, _idPapelMeta),
      );
    }
    if (data.containsKey('papel_nome')) {
      context.handle(
        _papelNomeMeta,
        papelNome.isAcceptableOrUnknown(data['papel_nome']!, _papelNomeMeta),
      );
    }
    if (data.containsKey('papel_descricao')) {
      context.handle(
        _papelDescricaoMeta,
        papelDescricao.isAcceptableOrUnknown(
          data['papel_descricao']!,
          _papelDescricaoMeta,
        ),
      );
    }
    if (data.containsKey('id_funcao')) {
      context.handle(
        _idFuncaoMeta,
        idFuncao.isAcceptableOrUnknown(data['id_funcao']!, _idFuncaoMeta),
      );
    }
    if (data.containsKey('funcao_nome')) {
      context.handle(
        _funcaoNomeMeta,
        funcaoNome.isAcceptableOrUnknown(data['funcao_nome']!, _funcaoNomeMeta),
      );
    }
    if (data.containsKey('funcao_descricao')) {
      context.handle(
        _funcaoDescricaoMeta,
        funcaoDescricao.isAcceptableOrUnknown(
          data['funcao_descricao']!,
          _funcaoDescricaoMeta,
        ),
      );
    }
    if (data.containsKey('id_papel_funcao')) {
      context.handle(
        _idPapelFuncaoMeta,
        idPapelFuncao.isAcceptableOrUnknown(
          data['id_papel_funcao']!,
          _idPapelFuncaoMeta,
        ),
      );
    }
    if (data.containsKey('habilitado')) {
      context.handle(
        _habilitadoMeta,
        habilitado.isAcceptableOrUnknown(data['habilitado']!, _habilitadoMeta),
      );
    }
    if (data.containsKey('pode_inserir')) {
      context.handle(
        _podeInserirMeta,
        podeInserir.isAcceptableOrUnknown(
          data['pode_inserir']!,
          _podeInserirMeta,
        ),
      );
    }
    if (data.containsKey('pode_alterar')) {
      context.handle(
        _podeAlterarMeta,
        podeAlterar.isAcceptableOrUnknown(
          data['pode_alterar']!,
          _podeAlterarMeta,
        ),
      );
    }
    if (data.containsKey('pode_excluir')) {
      context.handle(
        _podeExcluirMeta,
        podeExcluir.isAcceptableOrUnknown(
          data['pode_excluir']!,
          _podeExcluirMeta,
        ),
      );
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  ViewControleAcesso map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return ViewControleAcesso(
      id: attachedDatabase.typeMapping.read(
        DriftSqlType.int,
        data['${effectivePrefix}id'],
      ),
      idPessoa: attachedDatabase.typeMapping.read(
        DriftSqlType.int,
        data['${effectivePrefix}id_pessoa'],
      ),
      pessoaNome: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}pessoa_nome'],
      ),
      idColaborador: attachedDatabase.typeMapping.read(
        DriftSqlType.int,
        data['${effectivePrefix}id_colaborador'],
      ),
      idUsuario: attachedDatabase.typeMapping.read(
        DriftSqlType.int,
        data['${effectivePrefix}id_usuario'],
      ),
      administrador: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}administrador'],
      ),
      idPapel: attachedDatabase.typeMapping.read(
        DriftSqlType.int,
        data['${effectivePrefix}id_papel'],
      ),
      papelNome: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}papel_nome'],
      ),
      papelDescricao: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}papel_descricao'],
      ),
      idFuncao: attachedDatabase.typeMapping.read(
        DriftSqlType.int,
        data['${effectivePrefix}id_funcao'],
      ),
      funcaoNome: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}funcao_nome'],
      ),
      funcaoDescricao: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}funcao_descricao'],
      ),
      idPapelFuncao: attachedDatabase.typeMapping.read(
        DriftSqlType.int,
        data['${effectivePrefix}id_papel_funcao'],
      ),
      habilitado: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}habilitado'],
      ),
      podeInserir: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}pode_inserir'],
      ),
      podeAlterar: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}pode_alterar'],
      ),
      podeExcluir: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}pode_excluir'],
      ),
    );
  }

  @override
  $ViewControleAcessosTable createAlias(String alias) {
    return $ViewControleAcessosTable(attachedDatabase, alias);
  }
}

class ViewControleAcesso extends DataClass
    implements Insertable<ViewControleAcesso> {
  final int? id;
  final int? idPessoa;
  final String? pessoaNome;
  final int? idColaborador;
  final int? idUsuario;
  final String? administrador;
  final int? idPapel;
  final String? papelNome;
  final String? papelDescricao;
  final int? idFuncao;
  final String? funcaoNome;
  final String? funcaoDescricao;
  final int? idPapelFuncao;
  final String? habilitado;
  final String? podeInserir;
  final String? podeAlterar;
  final String? podeExcluir;
  const ViewControleAcesso({
    this.id,
    this.idPessoa,
    this.pessoaNome,
    this.idColaborador,
    this.idUsuario,
    this.administrador,
    this.idPapel,
    this.papelNome,
    this.papelDescricao,
    this.idFuncao,
    this.funcaoNome,
    this.funcaoDescricao,
    this.idPapelFuncao,
    this.habilitado,
    this.podeInserir,
    this.podeAlterar,
    this.podeExcluir,
  });
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || idPessoa != null) {
      map['id_pessoa'] = Variable<int>(idPessoa);
    }
    if (!nullToAbsent || pessoaNome != null) {
      map['pessoa_nome'] = Variable<String>(pessoaNome);
    }
    if (!nullToAbsent || idColaborador != null) {
      map['id_colaborador'] = Variable<int>(idColaborador);
    }
    if (!nullToAbsent || idUsuario != null) {
      map['id_usuario'] = Variable<int>(idUsuario);
    }
    if (!nullToAbsent || administrador != null) {
      map['administrador'] = Variable<String>(administrador);
    }
    if (!nullToAbsent || idPapel != null) {
      map['id_papel'] = Variable<int>(idPapel);
    }
    if (!nullToAbsent || papelNome != null) {
      map['papel_nome'] = Variable<String>(papelNome);
    }
    if (!nullToAbsent || papelDescricao != null) {
      map['papel_descricao'] = Variable<String>(papelDescricao);
    }
    if (!nullToAbsent || idFuncao != null) {
      map['id_funcao'] = Variable<int>(idFuncao);
    }
    if (!nullToAbsent || funcaoNome != null) {
      map['funcao_nome'] = Variable<String>(funcaoNome);
    }
    if (!nullToAbsent || funcaoDescricao != null) {
      map['funcao_descricao'] = Variable<String>(funcaoDescricao);
    }
    if (!nullToAbsent || idPapelFuncao != null) {
      map['id_papel_funcao'] = Variable<int>(idPapelFuncao);
    }
    if (!nullToAbsent || habilitado != null) {
      map['habilitado'] = Variable<String>(habilitado);
    }
    if (!nullToAbsent || podeInserir != null) {
      map['pode_inserir'] = Variable<String>(podeInserir);
    }
    if (!nullToAbsent || podeAlterar != null) {
      map['pode_alterar'] = Variable<String>(podeAlterar);
    }
    if (!nullToAbsent || podeExcluir != null) {
      map['pode_excluir'] = Variable<String>(podeExcluir);
    }
    return map;
  }

  factory ViewControleAcesso.fromJson(
    Map<String, dynamic> json, {
    ValueSerializer? serializer,
  }) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return ViewControleAcesso(
      id: serializer.fromJson<int?>(json['id']),
      idPessoa: serializer.fromJson<int?>(json['idPessoa']),
      pessoaNome: serializer.fromJson<String?>(json['pessoaNome']),
      idColaborador: serializer.fromJson<int?>(json['idColaborador']),
      idUsuario: serializer.fromJson<int?>(json['idUsuario']),
      administrador: serializer.fromJson<String?>(json['administrador']),
      idPapel: serializer.fromJson<int?>(json['idPapel']),
      papelNome: serializer.fromJson<String?>(json['papelNome']),
      papelDescricao: serializer.fromJson<String?>(json['papelDescricao']),
      idFuncao: serializer.fromJson<int?>(json['idFuncao']),
      funcaoNome: serializer.fromJson<String?>(json['funcaoNome']),
      funcaoDescricao: serializer.fromJson<String?>(json['funcaoDescricao']),
      idPapelFuncao: serializer.fromJson<int?>(json['idPapelFuncao']),
      habilitado: serializer.fromJson<String?>(json['habilitado']),
      podeInserir: serializer.fromJson<String?>(json['podeInserir']),
      podeAlterar: serializer.fromJson<String?>(json['podeAlterar']),
      podeExcluir: serializer.fromJson<String?>(json['podeExcluir']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'idPessoa': serializer.toJson<int?>(idPessoa),
      'pessoaNome': serializer.toJson<String?>(pessoaNome),
      'idColaborador': serializer.toJson<int?>(idColaborador),
      'idUsuario': serializer.toJson<int?>(idUsuario),
      'administrador': serializer.toJson<String?>(administrador),
      'idPapel': serializer.toJson<int?>(idPapel),
      'papelNome': serializer.toJson<String?>(papelNome),
      'papelDescricao': serializer.toJson<String?>(papelDescricao),
      'idFuncao': serializer.toJson<int?>(idFuncao),
      'funcaoNome': serializer.toJson<String?>(funcaoNome),
      'funcaoDescricao': serializer.toJson<String?>(funcaoDescricao),
      'idPapelFuncao': serializer.toJson<int?>(idPapelFuncao),
      'habilitado': serializer.toJson<String?>(habilitado),
      'podeInserir': serializer.toJson<String?>(podeInserir),
      'podeAlterar': serializer.toJson<String?>(podeAlterar),
      'podeExcluir': serializer.toJson<String?>(podeExcluir),
    };
  }

  ViewControleAcesso copyWith({
    Value<int?> id = const Value.absent(),
    Value<int?> idPessoa = const Value.absent(),
    Value<String?> pessoaNome = const Value.absent(),
    Value<int?> idColaborador = const Value.absent(),
    Value<int?> idUsuario = const Value.absent(),
    Value<String?> administrador = const Value.absent(),
    Value<int?> idPapel = const Value.absent(),
    Value<String?> papelNome = const Value.absent(),
    Value<String?> papelDescricao = const Value.absent(),
    Value<int?> idFuncao = const Value.absent(),
    Value<String?> funcaoNome = const Value.absent(),
    Value<String?> funcaoDescricao = const Value.absent(),
    Value<int?> idPapelFuncao = const Value.absent(),
    Value<String?> habilitado = const Value.absent(),
    Value<String?> podeInserir = const Value.absent(),
    Value<String?> podeAlterar = const Value.absent(),
    Value<String?> podeExcluir = const Value.absent(),
  }) => ViewControleAcesso(
    id: id.present ? id.value : this.id,
    idPessoa: idPessoa.present ? idPessoa.value : this.idPessoa,
    pessoaNome: pessoaNome.present ? pessoaNome.value : this.pessoaNome,
    idColaborador:
        idColaborador.present ? idColaborador.value : this.idColaborador,
    idUsuario: idUsuario.present ? idUsuario.value : this.idUsuario,
    administrador:
        administrador.present ? administrador.value : this.administrador,
    idPapel: idPapel.present ? idPapel.value : this.idPapel,
    papelNome: papelNome.present ? papelNome.value : this.papelNome,
    papelDescricao:
        papelDescricao.present ? papelDescricao.value : this.papelDescricao,
    idFuncao: idFuncao.present ? idFuncao.value : this.idFuncao,
    funcaoNome: funcaoNome.present ? funcaoNome.value : this.funcaoNome,
    funcaoDescricao:
        funcaoDescricao.present ? funcaoDescricao.value : this.funcaoDescricao,
    idPapelFuncao:
        idPapelFuncao.present ? idPapelFuncao.value : this.idPapelFuncao,
    habilitado: habilitado.present ? habilitado.value : this.habilitado,
    podeInserir: podeInserir.present ? podeInserir.value : this.podeInserir,
    podeAlterar: podeAlterar.present ? podeAlterar.value : this.podeAlterar,
    podeExcluir: podeExcluir.present ? podeExcluir.value : this.podeExcluir,
  );
  ViewControleAcesso copyWithCompanion(ViewControleAcessosCompanion data) {
    return ViewControleAcesso(
      id: data.id.present ? data.id.value : this.id,
      idPessoa: data.idPessoa.present ? data.idPessoa.value : this.idPessoa,
      pessoaNome:
          data.pessoaNome.present ? data.pessoaNome.value : this.pessoaNome,
      idColaborador:
          data.idColaborador.present
              ? data.idColaborador.value
              : this.idColaborador,
      idUsuario: data.idUsuario.present ? data.idUsuario.value : this.idUsuario,
      administrador:
          data.administrador.present
              ? data.administrador.value
              : this.administrador,
      idPapel: data.idPapel.present ? data.idPapel.value : this.idPapel,
      papelNome: data.papelNome.present ? data.papelNome.value : this.papelNome,
      papelDescricao:
          data.papelDescricao.present
              ? data.papelDescricao.value
              : this.papelDescricao,
      idFuncao: data.idFuncao.present ? data.idFuncao.value : this.idFuncao,
      funcaoNome:
          data.funcaoNome.present ? data.funcaoNome.value : this.funcaoNome,
      funcaoDescricao:
          data.funcaoDescricao.present
              ? data.funcaoDescricao.value
              : this.funcaoDescricao,
      idPapelFuncao:
          data.idPapelFuncao.present
              ? data.idPapelFuncao.value
              : this.idPapelFuncao,
      habilitado:
          data.habilitado.present ? data.habilitado.value : this.habilitado,
      podeInserir:
          data.podeInserir.present ? data.podeInserir.value : this.podeInserir,
      podeAlterar:
          data.podeAlterar.present ? data.podeAlterar.value : this.podeAlterar,
      podeExcluir:
          data.podeExcluir.present ? data.podeExcluir.value : this.podeExcluir,
    );
  }

  @override
  String toString() {
    return (StringBuffer('ViewControleAcesso(')
          ..write('id: $id, ')
          ..write('idPessoa: $idPessoa, ')
          ..write('pessoaNome: $pessoaNome, ')
          ..write('idColaborador: $idColaborador, ')
          ..write('idUsuario: $idUsuario, ')
          ..write('administrador: $administrador, ')
          ..write('idPapel: $idPapel, ')
          ..write('papelNome: $papelNome, ')
          ..write('papelDescricao: $papelDescricao, ')
          ..write('idFuncao: $idFuncao, ')
          ..write('funcaoNome: $funcaoNome, ')
          ..write('funcaoDescricao: $funcaoDescricao, ')
          ..write('idPapelFuncao: $idPapelFuncao, ')
          ..write('habilitado: $habilitado, ')
          ..write('podeInserir: $podeInserir, ')
          ..write('podeAlterar: $podeAlterar, ')
          ..write('podeExcluir: $podeExcluir')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(
    id,
    idPessoa,
    pessoaNome,
    idColaborador,
    idUsuario,
    administrador,
    idPapel,
    papelNome,
    papelDescricao,
    idFuncao,
    funcaoNome,
    funcaoDescricao,
    idPapelFuncao,
    habilitado,
    podeInserir,
    podeAlterar,
    podeExcluir,
  );
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is ViewControleAcesso &&
          other.id == this.id &&
          other.idPessoa == this.idPessoa &&
          other.pessoaNome == this.pessoaNome &&
          other.idColaborador == this.idColaborador &&
          other.idUsuario == this.idUsuario &&
          other.administrador == this.administrador &&
          other.idPapel == this.idPapel &&
          other.papelNome == this.papelNome &&
          other.papelDescricao == this.papelDescricao &&
          other.idFuncao == this.idFuncao &&
          other.funcaoNome == this.funcaoNome &&
          other.funcaoDescricao == this.funcaoDescricao &&
          other.idPapelFuncao == this.idPapelFuncao &&
          other.habilitado == this.habilitado &&
          other.podeInserir == this.podeInserir &&
          other.podeAlterar == this.podeAlterar &&
          other.podeExcluir == this.podeExcluir);
}

class ViewControleAcessosCompanion extends UpdateCompanion<ViewControleAcesso> {
  final Value<int?> id;
  final Value<int?> idPessoa;
  final Value<String?> pessoaNome;
  final Value<int?> idColaborador;
  final Value<int?> idUsuario;
  final Value<String?> administrador;
  final Value<int?> idPapel;
  final Value<String?> papelNome;
  final Value<String?> papelDescricao;
  final Value<int?> idFuncao;
  final Value<String?> funcaoNome;
  final Value<String?> funcaoDescricao;
  final Value<int?> idPapelFuncao;
  final Value<String?> habilitado;
  final Value<String?> podeInserir;
  final Value<String?> podeAlterar;
  final Value<String?> podeExcluir;
  const ViewControleAcessosCompanion({
    this.id = const Value.absent(),
    this.idPessoa = const Value.absent(),
    this.pessoaNome = const Value.absent(),
    this.idColaborador = const Value.absent(),
    this.idUsuario = const Value.absent(),
    this.administrador = const Value.absent(),
    this.idPapel = const Value.absent(),
    this.papelNome = const Value.absent(),
    this.papelDescricao = const Value.absent(),
    this.idFuncao = const Value.absent(),
    this.funcaoNome = const Value.absent(),
    this.funcaoDescricao = const Value.absent(),
    this.idPapelFuncao = const Value.absent(),
    this.habilitado = const Value.absent(),
    this.podeInserir = const Value.absent(),
    this.podeAlterar = const Value.absent(),
    this.podeExcluir = const Value.absent(),
  });
  ViewControleAcessosCompanion.insert({
    this.id = const Value.absent(),
    this.idPessoa = const Value.absent(),
    this.pessoaNome = const Value.absent(),
    this.idColaborador = const Value.absent(),
    this.idUsuario = const Value.absent(),
    this.administrador = const Value.absent(),
    this.idPapel = const Value.absent(),
    this.papelNome = const Value.absent(),
    this.papelDescricao = const Value.absent(),
    this.idFuncao = const Value.absent(),
    this.funcaoNome = const Value.absent(),
    this.funcaoDescricao = const Value.absent(),
    this.idPapelFuncao = const Value.absent(),
    this.habilitado = const Value.absent(),
    this.podeInserir = const Value.absent(),
    this.podeAlterar = const Value.absent(),
    this.podeExcluir = const Value.absent(),
  });
  static Insertable<ViewControleAcesso> custom({
    Expression<int>? id,
    Expression<int>? idPessoa,
    Expression<String>? pessoaNome,
    Expression<int>? idColaborador,
    Expression<int>? idUsuario,
    Expression<String>? administrador,
    Expression<int>? idPapel,
    Expression<String>? papelNome,
    Expression<String>? papelDescricao,
    Expression<int>? idFuncao,
    Expression<String>? funcaoNome,
    Expression<String>? funcaoDescricao,
    Expression<int>? idPapelFuncao,
    Expression<String>? habilitado,
    Expression<String>? podeInserir,
    Expression<String>? podeAlterar,
    Expression<String>? podeExcluir,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (idPessoa != null) 'id_pessoa': idPessoa,
      if (pessoaNome != null) 'pessoa_nome': pessoaNome,
      if (idColaborador != null) 'id_colaborador': idColaborador,
      if (idUsuario != null) 'id_usuario': idUsuario,
      if (administrador != null) 'administrador': administrador,
      if (idPapel != null) 'id_papel': idPapel,
      if (papelNome != null) 'papel_nome': papelNome,
      if (papelDescricao != null) 'papel_descricao': papelDescricao,
      if (idFuncao != null) 'id_funcao': idFuncao,
      if (funcaoNome != null) 'funcao_nome': funcaoNome,
      if (funcaoDescricao != null) 'funcao_descricao': funcaoDescricao,
      if (idPapelFuncao != null) 'id_papel_funcao': idPapelFuncao,
      if (habilitado != null) 'habilitado': habilitado,
      if (podeInserir != null) 'pode_inserir': podeInserir,
      if (podeAlterar != null) 'pode_alterar': podeAlterar,
      if (podeExcluir != null) 'pode_excluir': podeExcluir,
    });
  }

  ViewControleAcessosCompanion copyWith({
    Value<int?>? id,
    Value<int?>? idPessoa,
    Value<String?>? pessoaNome,
    Value<int?>? idColaborador,
    Value<int?>? idUsuario,
    Value<String?>? administrador,
    Value<int?>? idPapel,
    Value<String?>? papelNome,
    Value<String?>? papelDescricao,
    Value<int?>? idFuncao,
    Value<String?>? funcaoNome,
    Value<String?>? funcaoDescricao,
    Value<int?>? idPapelFuncao,
    Value<String?>? habilitado,
    Value<String?>? podeInserir,
    Value<String?>? podeAlterar,
    Value<String?>? podeExcluir,
  }) {
    return ViewControleAcessosCompanion(
      id: id ?? this.id,
      idPessoa: idPessoa ?? this.idPessoa,
      pessoaNome: pessoaNome ?? this.pessoaNome,
      idColaborador: idColaborador ?? this.idColaborador,
      idUsuario: idUsuario ?? this.idUsuario,
      administrador: administrador ?? this.administrador,
      idPapel: idPapel ?? this.idPapel,
      papelNome: papelNome ?? this.papelNome,
      papelDescricao: papelDescricao ?? this.papelDescricao,
      idFuncao: idFuncao ?? this.idFuncao,
      funcaoNome: funcaoNome ?? this.funcaoNome,
      funcaoDescricao: funcaoDescricao ?? this.funcaoDescricao,
      idPapelFuncao: idPapelFuncao ?? this.idPapelFuncao,
      habilitado: habilitado ?? this.habilitado,
      podeInserir: podeInserir ?? this.podeInserir,
      podeAlterar: podeAlterar ?? this.podeAlterar,
      podeExcluir: podeExcluir ?? this.podeExcluir,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (idPessoa.present) {
      map['id_pessoa'] = Variable<int>(idPessoa.value);
    }
    if (pessoaNome.present) {
      map['pessoa_nome'] = Variable<String>(pessoaNome.value);
    }
    if (idColaborador.present) {
      map['id_colaborador'] = Variable<int>(idColaborador.value);
    }
    if (idUsuario.present) {
      map['id_usuario'] = Variable<int>(idUsuario.value);
    }
    if (administrador.present) {
      map['administrador'] = Variable<String>(administrador.value);
    }
    if (idPapel.present) {
      map['id_papel'] = Variable<int>(idPapel.value);
    }
    if (papelNome.present) {
      map['papel_nome'] = Variable<String>(papelNome.value);
    }
    if (papelDescricao.present) {
      map['papel_descricao'] = Variable<String>(papelDescricao.value);
    }
    if (idFuncao.present) {
      map['id_funcao'] = Variable<int>(idFuncao.value);
    }
    if (funcaoNome.present) {
      map['funcao_nome'] = Variable<String>(funcaoNome.value);
    }
    if (funcaoDescricao.present) {
      map['funcao_descricao'] = Variable<String>(funcaoDescricao.value);
    }
    if (idPapelFuncao.present) {
      map['id_papel_funcao'] = Variable<int>(idPapelFuncao.value);
    }
    if (habilitado.present) {
      map['habilitado'] = Variable<String>(habilitado.value);
    }
    if (podeInserir.present) {
      map['pode_inserir'] = Variable<String>(podeInserir.value);
    }
    if (podeAlterar.present) {
      map['pode_alterar'] = Variable<String>(podeAlterar.value);
    }
    if (podeExcluir.present) {
      map['pode_excluir'] = Variable<String>(podeExcluir.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('ViewControleAcessosCompanion(')
          ..write('id: $id, ')
          ..write('idPessoa: $idPessoa, ')
          ..write('pessoaNome: $pessoaNome, ')
          ..write('idColaborador: $idColaborador, ')
          ..write('idUsuario: $idUsuario, ')
          ..write('administrador: $administrador, ')
          ..write('idPapel: $idPapel, ')
          ..write('papelNome: $papelNome, ')
          ..write('papelDescricao: $papelDescricao, ')
          ..write('idFuncao: $idFuncao, ')
          ..write('funcaoNome: $funcaoNome, ')
          ..write('funcaoDescricao: $funcaoDescricao, ')
          ..write('idPapelFuncao: $idPapelFuncao, ')
          ..write('habilitado: $habilitado, ')
          ..write('podeInserir: $podeInserir, ')
          ..write('podeAlterar: $podeAlterar, ')
          ..write('podeExcluir: $podeExcluir')
          ..write(')'))
        .toString();
  }
}

class $ViewPessoaUsuariosTable extends ViewPessoaUsuarios
    with TableInfo<$ViewPessoaUsuariosTable, ViewPessoaUsuario> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $ViewPessoaUsuariosTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
    'id',
    aliasedName,
    true,
    type: DriftSqlType.int,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _idPessoaMeta = const VerificationMeta(
    'idPessoa',
  );
  @override
  late final GeneratedColumn<int> idPessoa = GeneratedColumn<int>(
    'id_pessoa',
    aliasedName,
    true,
    type: DriftSqlType.int,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _pessoaNomeMeta = const VerificationMeta(
    'pessoaNome',
  );
  @override
  late final GeneratedColumn<String> pessoaNome = GeneratedColumn<String>(
    'pessoa_nome',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 450,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _tipoMeta = const VerificationMeta('tipo');
  @override
  late final GeneratedColumn<String> tipo = GeneratedColumn<String>(
    'tipo',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 3,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _emailMeta = const VerificationMeta('email');
  @override
  late final GeneratedColumn<String> email = GeneratedColumn<String>(
    'email',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 750,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _idColaboradorMeta = const VerificationMeta(
    'idColaborador',
  );
  @override
  late final GeneratedColumn<int> idColaborador = GeneratedColumn<int>(
    'id_colaborador',
    aliasedName,
    true,
    type: DriftSqlType.int,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _idUsuarioMeta = const VerificationMeta(
    'idUsuario',
  );
  @override
  late final GeneratedColumn<int> idUsuario = GeneratedColumn<int>(
    'id_usuario',
    aliasedName,
    true,
    type: DriftSqlType.int,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _loginMeta = const VerificationMeta('login');
  @override
  late final GeneratedColumn<String> login = GeneratedColumn<String>(
    'login',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 150,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _senhaMeta = const VerificationMeta('senha');
  @override
  late final GeneratedColumn<String> senha = GeneratedColumn<String>(
    'senha',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 150,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _dataCadastroMeta = const VerificationMeta(
    'dataCadastro',
  );
  @override
  late final GeneratedColumn<DateTime> dataCadastro = GeneratedColumn<DateTime>(
    'data_cadastro',
    aliasedName,
    true,
    type: DriftSqlType.dateTime,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _administradorMeta = const VerificationMeta(
    'administrador',
  );
  @override
  late final GeneratedColumn<String> administrador = GeneratedColumn<String>(
    'administrador',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 3,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  @override
  List<GeneratedColumn> get $columns => [
    id,
    idPessoa,
    pessoaNome,
    tipo,
    email,
    idColaborador,
    idUsuario,
    login,
    senha,
    dataCadastro,
    administrador,
  ];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'view_pessoa_usuario';
  @override
  VerificationContext validateIntegrity(
    Insertable<ViewPessoaUsuario> instance, {
    bool isInserting = false,
  }) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('id_pessoa')) {
      context.handle(
        _idPessoaMeta,
        idPessoa.isAcceptableOrUnknown(data['id_pessoa']!, _idPessoaMeta),
      );
    }
    if (data.containsKey('pessoa_nome')) {
      context.handle(
        _pessoaNomeMeta,
        pessoaNome.isAcceptableOrUnknown(data['pessoa_nome']!, _pessoaNomeMeta),
      );
    }
    if (data.containsKey('tipo')) {
      context.handle(
        _tipoMeta,
        tipo.isAcceptableOrUnknown(data['tipo']!, _tipoMeta),
      );
    }
    if (data.containsKey('email')) {
      context.handle(
        _emailMeta,
        email.isAcceptableOrUnknown(data['email']!, _emailMeta),
      );
    }
    if (data.containsKey('id_colaborador')) {
      context.handle(
        _idColaboradorMeta,
        idColaborador.isAcceptableOrUnknown(
          data['id_colaborador']!,
          _idColaboradorMeta,
        ),
      );
    }
    if (data.containsKey('id_usuario')) {
      context.handle(
        _idUsuarioMeta,
        idUsuario.isAcceptableOrUnknown(data['id_usuario']!, _idUsuarioMeta),
      );
    }
    if (data.containsKey('login')) {
      context.handle(
        _loginMeta,
        login.isAcceptableOrUnknown(data['login']!, _loginMeta),
      );
    }
    if (data.containsKey('senha')) {
      context.handle(
        _senhaMeta,
        senha.isAcceptableOrUnknown(data['senha']!, _senhaMeta),
      );
    }
    if (data.containsKey('data_cadastro')) {
      context.handle(
        _dataCadastroMeta,
        dataCadastro.isAcceptableOrUnknown(
          data['data_cadastro']!,
          _dataCadastroMeta,
        ),
      );
    }
    if (data.containsKey('administrador')) {
      context.handle(
        _administradorMeta,
        administrador.isAcceptableOrUnknown(
          data['administrador']!,
          _administradorMeta,
        ),
      );
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  ViewPessoaUsuario map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return ViewPessoaUsuario(
      id: attachedDatabase.typeMapping.read(
        DriftSqlType.int,
        data['${effectivePrefix}id'],
      ),
      idPessoa: attachedDatabase.typeMapping.read(
        DriftSqlType.int,
        data['${effectivePrefix}id_pessoa'],
      ),
      pessoaNome: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}pessoa_nome'],
      ),
      tipo: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}tipo'],
      ),
      email: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}email'],
      ),
      idColaborador: attachedDatabase.typeMapping.read(
        DriftSqlType.int,
        data['${effectivePrefix}id_colaborador'],
      ),
      idUsuario: attachedDatabase.typeMapping.read(
        DriftSqlType.int,
        data['${effectivePrefix}id_usuario'],
      ),
      login: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}login'],
      ),
      senha: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}senha'],
      ),
      dataCadastro: attachedDatabase.typeMapping.read(
        DriftSqlType.dateTime,
        data['${effectivePrefix}data_cadastro'],
      ),
      administrador: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}administrador'],
      ),
    );
  }

  @override
  $ViewPessoaUsuariosTable createAlias(String alias) {
    return $ViewPessoaUsuariosTable(attachedDatabase, alias);
  }
}

class ViewPessoaUsuario extends DataClass
    implements Insertable<ViewPessoaUsuario> {
  final int? id;
  final int? idPessoa;
  final String? pessoaNome;
  final String? tipo;
  final String? email;
  final int? idColaborador;
  final int? idUsuario;
  final String? login;
  final String? senha;
  final DateTime? dataCadastro;
  final String? administrador;
  const ViewPessoaUsuario({
    this.id,
    this.idPessoa,
    this.pessoaNome,
    this.tipo,
    this.email,
    this.idColaborador,
    this.idUsuario,
    this.login,
    this.senha,
    this.dataCadastro,
    this.administrador,
  });
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || idPessoa != null) {
      map['id_pessoa'] = Variable<int>(idPessoa);
    }
    if (!nullToAbsent || pessoaNome != null) {
      map['pessoa_nome'] = Variable<String>(pessoaNome);
    }
    if (!nullToAbsent || tipo != null) {
      map['tipo'] = Variable<String>(tipo);
    }
    if (!nullToAbsent || email != null) {
      map['email'] = Variable<String>(email);
    }
    if (!nullToAbsent || idColaborador != null) {
      map['id_colaborador'] = Variable<int>(idColaborador);
    }
    if (!nullToAbsent || idUsuario != null) {
      map['id_usuario'] = Variable<int>(idUsuario);
    }
    if (!nullToAbsent || login != null) {
      map['login'] = Variable<String>(login);
    }
    if (!nullToAbsent || senha != null) {
      map['senha'] = Variable<String>(senha);
    }
    if (!nullToAbsent || dataCadastro != null) {
      map['data_cadastro'] = Variable<DateTime>(dataCadastro);
    }
    if (!nullToAbsent || administrador != null) {
      map['administrador'] = Variable<String>(administrador);
    }
    return map;
  }

  factory ViewPessoaUsuario.fromJson(
    Map<String, dynamic> json, {
    ValueSerializer? serializer,
  }) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return ViewPessoaUsuario(
      id: serializer.fromJson<int?>(json['id']),
      idPessoa: serializer.fromJson<int?>(json['idPessoa']),
      pessoaNome: serializer.fromJson<String?>(json['pessoaNome']),
      tipo: serializer.fromJson<String?>(json['tipo']),
      email: serializer.fromJson<String?>(json['email']),
      idColaborador: serializer.fromJson<int?>(json['idColaborador']),
      idUsuario: serializer.fromJson<int?>(json['idUsuario']),
      login: serializer.fromJson<String?>(json['login']),
      senha: serializer.fromJson<String?>(json['senha']),
      dataCadastro: serializer.fromJson<DateTime?>(json['dataCadastro']),
      administrador: serializer.fromJson<String?>(json['administrador']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'idPessoa': serializer.toJson<int?>(idPessoa),
      'pessoaNome': serializer.toJson<String?>(pessoaNome),
      'tipo': serializer.toJson<String?>(tipo),
      'email': serializer.toJson<String?>(email),
      'idColaborador': serializer.toJson<int?>(idColaborador),
      'idUsuario': serializer.toJson<int?>(idUsuario),
      'login': serializer.toJson<String?>(login),
      'senha': serializer.toJson<String?>(senha),
      'dataCadastro': serializer.toJson<DateTime?>(dataCadastro),
      'administrador': serializer.toJson<String?>(administrador),
    };
  }

  ViewPessoaUsuario copyWith({
    Value<int?> id = const Value.absent(),
    Value<int?> idPessoa = const Value.absent(),
    Value<String?> pessoaNome = const Value.absent(),
    Value<String?> tipo = const Value.absent(),
    Value<String?> email = const Value.absent(),
    Value<int?> idColaborador = const Value.absent(),
    Value<int?> idUsuario = const Value.absent(),
    Value<String?> login = const Value.absent(),
    Value<String?> senha = const Value.absent(),
    Value<DateTime?> dataCadastro = const Value.absent(),
    Value<String?> administrador = const Value.absent(),
  }) => ViewPessoaUsuario(
    id: id.present ? id.value : this.id,
    idPessoa: idPessoa.present ? idPessoa.value : this.idPessoa,
    pessoaNome: pessoaNome.present ? pessoaNome.value : this.pessoaNome,
    tipo: tipo.present ? tipo.value : this.tipo,
    email: email.present ? email.value : this.email,
    idColaborador:
        idColaborador.present ? idColaborador.value : this.idColaborador,
    idUsuario: idUsuario.present ? idUsuario.value : this.idUsuario,
    login: login.present ? login.value : this.login,
    senha: senha.present ? senha.value : this.senha,
    dataCadastro: dataCadastro.present ? dataCadastro.value : this.dataCadastro,
    administrador:
        administrador.present ? administrador.value : this.administrador,
  );
  ViewPessoaUsuario copyWithCompanion(ViewPessoaUsuariosCompanion data) {
    return ViewPessoaUsuario(
      id: data.id.present ? data.id.value : this.id,
      idPessoa: data.idPessoa.present ? data.idPessoa.value : this.idPessoa,
      pessoaNome:
          data.pessoaNome.present ? data.pessoaNome.value : this.pessoaNome,
      tipo: data.tipo.present ? data.tipo.value : this.tipo,
      email: data.email.present ? data.email.value : this.email,
      idColaborador:
          data.idColaborador.present
              ? data.idColaborador.value
              : this.idColaborador,
      idUsuario: data.idUsuario.present ? data.idUsuario.value : this.idUsuario,
      login: data.login.present ? data.login.value : this.login,
      senha: data.senha.present ? data.senha.value : this.senha,
      dataCadastro:
          data.dataCadastro.present
              ? data.dataCadastro.value
              : this.dataCadastro,
      administrador:
          data.administrador.present
              ? data.administrador.value
              : this.administrador,
    );
  }

  @override
  String toString() {
    return (StringBuffer('ViewPessoaUsuario(')
          ..write('id: $id, ')
          ..write('idPessoa: $idPessoa, ')
          ..write('pessoaNome: $pessoaNome, ')
          ..write('tipo: $tipo, ')
          ..write('email: $email, ')
          ..write('idColaborador: $idColaborador, ')
          ..write('idUsuario: $idUsuario, ')
          ..write('login: $login, ')
          ..write('senha: $senha, ')
          ..write('dataCadastro: $dataCadastro, ')
          ..write('administrador: $administrador')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(
    id,
    idPessoa,
    pessoaNome,
    tipo,
    email,
    idColaborador,
    idUsuario,
    login,
    senha,
    dataCadastro,
    administrador,
  );
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is ViewPessoaUsuario &&
          other.id == this.id &&
          other.idPessoa == this.idPessoa &&
          other.pessoaNome == this.pessoaNome &&
          other.tipo == this.tipo &&
          other.email == this.email &&
          other.idColaborador == this.idColaborador &&
          other.idUsuario == this.idUsuario &&
          other.login == this.login &&
          other.senha == this.senha &&
          other.dataCadastro == this.dataCadastro &&
          other.administrador == this.administrador);
}

class ViewPessoaUsuariosCompanion extends UpdateCompanion<ViewPessoaUsuario> {
  final Value<int?> id;
  final Value<int?> idPessoa;
  final Value<String?> pessoaNome;
  final Value<String?> tipo;
  final Value<String?> email;
  final Value<int?> idColaborador;
  final Value<int?> idUsuario;
  final Value<String?> login;
  final Value<String?> senha;
  final Value<DateTime?> dataCadastro;
  final Value<String?> administrador;
  const ViewPessoaUsuariosCompanion({
    this.id = const Value.absent(),
    this.idPessoa = const Value.absent(),
    this.pessoaNome = const Value.absent(),
    this.tipo = const Value.absent(),
    this.email = const Value.absent(),
    this.idColaborador = const Value.absent(),
    this.idUsuario = const Value.absent(),
    this.login = const Value.absent(),
    this.senha = const Value.absent(),
    this.dataCadastro = const Value.absent(),
    this.administrador = const Value.absent(),
  });
  ViewPessoaUsuariosCompanion.insert({
    this.id = const Value.absent(),
    this.idPessoa = const Value.absent(),
    this.pessoaNome = const Value.absent(),
    this.tipo = const Value.absent(),
    this.email = const Value.absent(),
    this.idColaborador = const Value.absent(),
    this.idUsuario = const Value.absent(),
    this.login = const Value.absent(),
    this.senha = const Value.absent(),
    this.dataCadastro = const Value.absent(),
    this.administrador = const Value.absent(),
  });
  static Insertable<ViewPessoaUsuario> custom({
    Expression<int>? id,
    Expression<int>? idPessoa,
    Expression<String>? pessoaNome,
    Expression<String>? tipo,
    Expression<String>? email,
    Expression<int>? idColaborador,
    Expression<int>? idUsuario,
    Expression<String>? login,
    Expression<String>? senha,
    Expression<DateTime>? dataCadastro,
    Expression<String>? administrador,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (idPessoa != null) 'id_pessoa': idPessoa,
      if (pessoaNome != null) 'pessoa_nome': pessoaNome,
      if (tipo != null) 'tipo': tipo,
      if (email != null) 'email': email,
      if (idColaborador != null) 'id_colaborador': idColaborador,
      if (idUsuario != null) 'id_usuario': idUsuario,
      if (login != null) 'login': login,
      if (senha != null) 'senha': senha,
      if (dataCadastro != null) 'data_cadastro': dataCadastro,
      if (administrador != null) 'administrador': administrador,
    });
  }

  ViewPessoaUsuariosCompanion copyWith({
    Value<int?>? id,
    Value<int?>? idPessoa,
    Value<String?>? pessoaNome,
    Value<String?>? tipo,
    Value<String?>? email,
    Value<int?>? idColaborador,
    Value<int?>? idUsuario,
    Value<String?>? login,
    Value<String?>? senha,
    Value<DateTime?>? dataCadastro,
    Value<String?>? administrador,
  }) {
    return ViewPessoaUsuariosCompanion(
      id: id ?? this.id,
      idPessoa: idPessoa ?? this.idPessoa,
      pessoaNome: pessoaNome ?? this.pessoaNome,
      tipo: tipo ?? this.tipo,
      email: email ?? this.email,
      idColaborador: idColaborador ?? this.idColaborador,
      idUsuario: idUsuario ?? this.idUsuario,
      login: login ?? this.login,
      senha: senha ?? this.senha,
      dataCadastro: dataCadastro ?? this.dataCadastro,
      administrador: administrador ?? this.administrador,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (idPessoa.present) {
      map['id_pessoa'] = Variable<int>(idPessoa.value);
    }
    if (pessoaNome.present) {
      map['pessoa_nome'] = Variable<String>(pessoaNome.value);
    }
    if (tipo.present) {
      map['tipo'] = Variable<String>(tipo.value);
    }
    if (email.present) {
      map['email'] = Variable<String>(email.value);
    }
    if (idColaborador.present) {
      map['id_colaborador'] = Variable<int>(idColaborador.value);
    }
    if (idUsuario.present) {
      map['id_usuario'] = Variable<int>(idUsuario.value);
    }
    if (login.present) {
      map['login'] = Variable<String>(login.value);
    }
    if (senha.present) {
      map['senha'] = Variable<String>(senha.value);
    }
    if (dataCadastro.present) {
      map['data_cadastro'] = Variable<DateTime>(dataCadastro.value);
    }
    if (administrador.present) {
      map['administrador'] = Variable<String>(administrador.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('ViewPessoaUsuariosCompanion(')
          ..write('id: $id, ')
          ..write('idPessoa: $idPessoa, ')
          ..write('pessoaNome: $pessoaNome, ')
          ..write('tipo: $tipo, ')
          ..write('email: $email, ')
          ..write('idColaborador: $idColaborador, ')
          ..write('idUsuario: $idUsuario, ')
          ..write('login: $login, ')
          ..write('senha: $senha, ')
          ..write('dataCadastro: $dataCadastro, ')
          ..write('administrador: $administrador')
          ..write(')'))
        .toString();
  }
}

class $ViewPessoaClientesTable extends ViewPessoaClientes
    with TableInfo<$ViewPessoaClientesTable, ViewPessoaCliente> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $ViewPessoaClientesTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
    'id',
    aliasedName,
    true,
    type: DriftSqlType.int,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _nomeMeta = const VerificationMeta('nome');
  @override
  late final GeneratedColumn<String> nome = GeneratedColumn<String>(
    'nome',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 150,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _tipoMeta = const VerificationMeta('tipo');
  @override
  late final GeneratedColumn<String> tipo = GeneratedColumn<String>(
    'tipo',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 3,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _emailMeta = const VerificationMeta('email');
  @override
  late final GeneratedColumn<String> email = GeneratedColumn<String>(
    'email',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 750,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _siteMeta = const VerificationMeta('site');
  @override
  late final GeneratedColumn<String> site = GeneratedColumn<String>(
    'site',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 450,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _cpfCnpjMeta = const VerificationMeta(
    'cpfCnpj',
  );
  @override
  late final GeneratedColumn<String> cpfCnpj = GeneratedColumn<String>(
    'cpf_cnpj',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 20,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _rgIeMeta = const VerificationMeta('rgIe');
  @override
  late final GeneratedColumn<String> rgIe = GeneratedColumn<String>(
    'rg_ie',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 20,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _desdeMeta = const VerificationMeta('desde');
  @override
  late final GeneratedColumn<DateTime> desde = GeneratedColumn<DateTime>(
    'desde',
    aliasedName,
    true,
    type: DriftSqlType.dateTime,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _taxaDescontoMeta = const VerificationMeta(
    'taxaDesconto',
  );
  @override
  late final GeneratedColumn<double> taxaDesconto = GeneratedColumn<double>(
    'taxa_desconto',
    aliasedName,
    true,
    type: DriftSqlType.double,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _limiteCreditoMeta = const VerificationMeta(
    'limiteCredito',
  );
  @override
  late final GeneratedColumn<double> limiteCredito = GeneratedColumn<double>(
    'limite_credito',
    aliasedName,
    true,
    type: DriftSqlType.double,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _dataCadastroMeta = const VerificationMeta(
    'dataCadastro',
  );
  @override
  late final GeneratedColumn<DateTime> dataCadastro = GeneratedColumn<DateTime>(
    'data_cadastro',
    aliasedName,
    true,
    type: DriftSqlType.dateTime,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _observacaoMeta = const VerificationMeta(
    'observacao',
  );
  @override
  late final GeneratedColumn<String> observacao = GeneratedColumn<String>(
    'observacao',
    aliasedName,
    true,
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _idPessoaMeta = const VerificationMeta(
    'idPessoa',
  );
  @override
  late final GeneratedColumn<int> idPessoa = GeneratedColumn<int>(
    'id_pessoa',
    aliasedName,
    true,
    type: DriftSqlType.int,
    requiredDuringInsert: false,
  );
  @override
  List<GeneratedColumn> get $columns => [
    id,
    nome,
    tipo,
    email,
    site,
    cpfCnpj,
    rgIe,
    desde,
    taxaDesconto,
    limiteCredito,
    dataCadastro,
    observacao,
    idPessoa,
  ];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'view_pessoa_cliente';
  @override
  VerificationContext validateIntegrity(
    Insertable<ViewPessoaCliente> instance, {
    bool isInserting = false,
  }) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('nome')) {
      context.handle(
        _nomeMeta,
        nome.isAcceptableOrUnknown(data['nome']!, _nomeMeta),
      );
    }
    if (data.containsKey('tipo')) {
      context.handle(
        _tipoMeta,
        tipo.isAcceptableOrUnknown(data['tipo']!, _tipoMeta),
      );
    }
    if (data.containsKey('email')) {
      context.handle(
        _emailMeta,
        email.isAcceptableOrUnknown(data['email']!, _emailMeta),
      );
    }
    if (data.containsKey('site')) {
      context.handle(
        _siteMeta,
        site.isAcceptableOrUnknown(data['site']!, _siteMeta),
      );
    }
    if (data.containsKey('cpf_cnpj')) {
      context.handle(
        _cpfCnpjMeta,
        cpfCnpj.isAcceptableOrUnknown(data['cpf_cnpj']!, _cpfCnpjMeta),
      );
    }
    if (data.containsKey('rg_ie')) {
      context.handle(
        _rgIeMeta,
        rgIe.isAcceptableOrUnknown(data['rg_ie']!, _rgIeMeta),
      );
    }
    if (data.containsKey('desde')) {
      context.handle(
        _desdeMeta,
        desde.isAcceptableOrUnknown(data['desde']!, _desdeMeta),
      );
    }
    if (data.containsKey('taxa_desconto')) {
      context.handle(
        _taxaDescontoMeta,
        taxaDesconto.isAcceptableOrUnknown(
          data['taxa_desconto']!,
          _taxaDescontoMeta,
        ),
      );
    }
    if (data.containsKey('limite_credito')) {
      context.handle(
        _limiteCreditoMeta,
        limiteCredito.isAcceptableOrUnknown(
          data['limite_credito']!,
          _limiteCreditoMeta,
        ),
      );
    }
    if (data.containsKey('data_cadastro')) {
      context.handle(
        _dataCadastroMeta,
        dataCadastro.isAcceptableOrUnknown(
          data['data_cadastro']!,
          _dataCadastroMeta,
        ),
      );
    }
    if (data.containsKey('observacao')) {
      context.handle(
        _observacaoMeta,
        observacao.isAcceptableOrUnknown(data['observacao']!, _observacaoMeta),
      );
    }
    if (data.containsKey('id_pessoa')) {
      context.handle(
        _idPessoaMeta,
        idPessoa.isAcceptableOrUnknown(data['id_pessoa']!, _idPessoaMeta),
      );
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  ViewPessoaCliente map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return ViewPessoaCliente(
      id: attachedDatabase.typeMapping.read(
        DriftSqlType.int,
        data['${effectivePrefix}id'],
      ),
      nome: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}nome'],
      ),
      tipo: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}tipo'],
      ),
      email: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}email'],
      ),
      site: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}site'],
      ),
      cpfCnpj: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}cpf_cnpj'],
      ),
      rgIe: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}rg_ie'],
      ),
      desde: attachedDatabase.typeMapping.read(
        DriftSqlType.dateTime,
        data['${effectivePrefix}desde'],
      ),
      taxaDesconto: attachedDatabase.typeMapping.read(
        DriftSqlType.double,
        data['${effectivePrefix}taxa_desconto'],
      ),
      limiteCredito: attachedDatabase.typeMapping.read(
        DriftSqlType.double,
        data['${effectivePrefix}limite_credito'],
      ),
      dataCadastro: attachedDatabase.typeMapping.read(
        DriftSqlType.dateTime,
        data['${effectivePrefix}data_cadastro'],
      ),
      observacao: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}observacao'],
      ),
      idPessoa: attachedDatabase.typeMapping.read(
        DriftSqlType.int,
        data['${effectivePrefix}id_pessoa'],
      ),
    );
  }

  @override
  $ViewPessoaClientesTable createAlias(String alias) {
    return $ViewPessoaClientesTable(attachedDatabase, alias);
  }
}

class ViewPessoaCliente extends DataClass
    implements Insertable<ViewPessoaCliente> {
  final int? id;
  final String? nome;
  final String? tipo;
  final String? email;
  final String? site;
  final String? cpfCnpj;
  final String? rgIe;
  final DateTime? desde;
  final double? taxaDesconto;
  final double? limiteCredito;
  final DateTime? dataCadastro;
  final String? observacao;
  final int? idPessoa;
  const ViewPessoaCliente({
    this.id,
    this.nome,
    this.tipo,
    this.email,
    this.site,
    this.cpfCnpj,
    this.rgIe,
    this.desde,
    this.taxaDesconto,
    this.limiteCredito,
    this.dataCadastro,
    this.observacao,
    this.idPessoa,
  });
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || nome != null) {
      map['nome'] = Variable<String>(nome);
    }
    if (!nullToAbsent || tipo != null) {
      map['tipo'] = Variable<String>(tipo);
    }
    if (!nullToAbsent || email != null) {
      map['email'] = Variable<String>(email);
    }
    if (!nullToAbsent || site != null) {
      map['site'] = Variable<String>(site);
    }
    if (!nullToAbsent || cpfCnpj != null) {
      map['cpf_cnpj'] = Variable<String>(cpfCnpj);
    }
    if (!nullToAbsent || rgIe != null) {
      map['rg_ie'] = Variable<String>(rgIe);
    }
    if (!nullToAbsent || desde != null) {
      map['desde'] = Variable<DateTime>(desde);
    }
    if (!nullToAbsent || taxaDesconto != null) {
      map['taxa_desconto'] = Variable<double>(taxaDesconto);
    }
    if (!nullToAbsent || limiteCredito != null) {
      map['limite_credito'] = Variable<double>(limiteCredito);
    }
    if (!nullToAbsent || dataCadastro != null) {
      map['data_cadastro'] = Variable<DateTime>(dataCadastro);
    }
    if (!nullToAbsent || observacao != null) {
      map['observacao'] = Variable<String>(observacao);
    }
    if (!nullToAbsent || idPessoa != null) {
      map['id_pessoa'] = Variable<int>(idPessoa);
    }
    return map;
  }

  factory ViewPessoaCliente.fromJson(
    Map<String, dynamic> json, {
    ValueSerializer? serializer,
  }) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return ViewPessoaCliente(
      id: serializer.fromJson<int?>(json['id']),
      nome: serializer.fromJson<String?>(json['nome']),
      tipo: serializer.fromJson<String?>(json['tipo']),
      email: serializer.fromJson<String?>(json['email']),
      site: serializer.fromJson<String?>(json['site']),
      cpfCnpj: serializer.fromJson<String?>(json['cpfCnpj']),
      rgIe: serializer.fromJson<String?>(json['rgIe']),
      desde: serializer.fromJson<DateTime?>(json['desde']),
      taxaDesconto: serializer.fromJson<double?>(json['taxaDesconto']),
      limiteCredito: serializer.fromJson<double?>(json['limiteCredito']),
      dataCadastro: serializer.fromJson<DateTime?>(json['dataCadastro']),
      observacao: serializer.fromJson<String?>(json['observacao']),
      idPessoa: serializer.fromJson<int?>(json['idPessoa']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'nome': serializer.toJson<String?>(nome),
      'tipo': serializer.toJson<String?>(tipo),
      'email': serializer.toJson<String?>(email),
      'site': serializer.toJson<String?>(site),
      'cpfCnpj': serializer.toJson<String?>(cpfCnpj),
      'rgIe': serializer.toJson<String?>(rgIe),
      'desde': serializer.toJson<DateTime?>(desde),
      'taxaDesconto': serializer.toJson<double?>(taxaDesconto),
      'limiteCredito': serializer.toJson<double?>(limiteCredito),
      'dataCadastro': serializer.toJson<DateTime?>(dataCadastro),
      'observacao': serializer.toJson<String?>(observacao),
      'idPessoa': serializer.toJson<int?>(idPessoa),
    };
  }

  ViewPessoaCliente copyWith({
    Value<int?> id = const Value.absent(),
    Value<String?> nome = const Value.absent(),
    Value<String?> tipo = const Value.absent(),
    Value<String?> email = const Value.absent(),
    Value<String?> site = const Value.absent(),
    Value<String?> cpfCnpj = const Value.absent(),
    Value<String?> rgIe = const Value.absent(),
    Value<DateTime?> desde = const Value.absent(),
    Value<double?> taxaDesconto = const Value.absent(),
    Value<double?> limiteCredito = const Value.absent(),
    Value<DateTime?> dataCadastro = const Value.absent(),
    Value<String?> observacao = const Value.absent(),
    Value<int?> idPessoa = const Value.absent(),
  }) => ViewPessoaCliente(
    id: id.present ? id.value : this.id,
    nome: nome.present ? nome.value : this.nome,
    tipo: tipo.present ? tipo.value : this.tipo,
    email: email.present ? email.value : this.email,
    site: site.present ? site.value : this.site,
    cpfCnpj: cpfCnpj.present ? cpfCnpj.value : this.cpfCnpj,
    rgIe: rgIe.present ? rgIe.value : this.rgIe,
    desde: desde.present ? desde.value : this.desde,
    taxaDesconto: taxaDesconto.present ? taxaDesconto.value : this.taxaDesconto,
    limiteCredito:
        limiteCredito.present ? limiteCredito.value : this.limiteCredito,
    dataCadastro: dataCadastro.present ? dataCadastro.value : this.dataCadastro,
    observacao: observacao.present ? observacao.value : this.observacao,
    idPessoa: idPessoa.present ? idPessoa.value : this.idPessoa,
  );
  ViewPessoaCliente copyWithCompanion(ViewPessoaClientesCompanion data) {
    return ViewPessoaCliente(
      id: data.id.present ? data.id.value : this.id,
      nome: data.nome.present ? data.nome.value : this.nome,
      tipo: data.tipo.present ? data.tipo.value : this.tipo,
      email: data.email.present ? data.email.value : this.email,
      site: data.site.present ? data.site.value : this.site,
      cpfCnpj: data.cpfCnpj.present ? data.cpfCnpj.value : this.cpfCnpj,
      rgIe: data.rgIe.present ? data.rgIe.value : this.rgIe,
      desde: data.desde.present ? data.desde.value : this.desde,
      taxaDesconto:
          data.taxaDesconto.present
              ? data.taxaDesconto.value
              : this.taxaDesconto,
      limiteCredito:
          data.limiteCredito.present
              ? data.limiteCredito.value
              : this.limiteCredito,
      dataCadastro:
          data.dataCadastro.present
              ? data.dataCadastro.value
              : this.dataCadastro,
      observacao:
          data.observacao.present ? data.observacao.value : this.observacao,
      idPessoa: data.idPessoa.present ? data.idPessoa.value : this.idPessoa,
    );
  }

  @override
  String toString() {
    return (StringBuffer('ViewPessoaCliente(')
          ..write('id: $id, ')
          ..write('nome: $nome, ')
          ..write('tipo: $tipo, ')
          ..write('email: $email, ')
          ..write('site: $site, ')
          ..write('cpfCnpj: $cpfCnpj, ')
          ..write('rgIe: $rgIe, ')
          ..write('desde: $desde, ')
          ..write('taxaDesconto: $taxaDesconto, ')
          ..write('limiteCredito: $limiteCredito, ')
          ..write('dataCadastro: $dataCadastro, ')
          ..write('observacao: $observacao, ')
          ..write('idPessoa: $idPessoa')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(
    id,
    nome,
    tipo,
    email,
    site,
    cpfCnpj,
    rgIe,
    desde,
    taxaDesconto,
    limiteCredito,
    dataCadastro,
    observacao,
    idPessoa,
  );
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is ViewPessoaCliente &&
          other.id == this.id &&
          other.nome == this.nome &&
          other.tipo == this.tipo &&
          other.email == this.email &&
          other.site == this.site &&
          other.cpfCnpj == this.cpfCnpj &&
          other.rgIe == this.rgIe &&
          other.desde == this.desde &&
          other.taxaDesconto == this.taxaDesconto &&
          other.limiteCredito == this.limiteCredito &&
          other.dataCadastro == this.dataCadastro &&
          other.observacao == this.observacao &&
          other.idPessoa == this.idPessoa);
}

class ViewPessoaClientesCompanion extends UpdateCompanion<ViewPessoaCliente> {
  final Value<int?> id;
  final Value<String?> nome;
  final Value<String?> tipo;
  final Value<String?> email;
  final Value<String?> site;
  final Value<String?> cpfCnpj;
  final Value<String?> rgIe;
  final Value<DateTime?> desde;
  final Value<double?> taxaDesconto;
  final Value<double?> limiteCredito;
  final Value<DateTime?> dataCadastro;
  final Value<String?> observacao;
  final Value<int?> idPessoa;
  const ViewPessoaClientesCompanion({
    this.id = const Value.absent(),
    this.nome = const Value.absent(),
    this.tipo = const Value.absent(),
    this.email = const Value.absent(),
    this.site = const Value.absent(),
    this.cpfCnpj = const Value.absent(),
    this.rgIe = const Value.absent(),
    this.desde = const Value.absent(),
    this.taxaDesconto = const Value.absent(),
    this.limiteCredito = const Value.absent(),
    this.dataCadastro = const Value.absent(),
    this.observacao = const Value.absent(),
    this.idPessoa = const Value.absent(),
  });
  ViewPessoaClientesCompanion.insert({
    this.id = const Value.absent(),
    this.nome = const Value.absent(),
    this.tipo = const Value.absent(),
    this.email = const Value.absent(),
    this.site = const Value.absent(),
    this.cpfCnpj = const Value.absent(),
    this.rgIe = const Value.absent(),
    this.desde = const Value.absent(),
    this.taxaDesconto = const Value.absent(),
    this.limiteCredito = const Value.absent(),
    this.dataCadastro = const Value.absent(),
    this.observacao = const Value.absent(),
    this.idPessoa = const Value.absent(),
  });
  static Insertable<ViewPessoaCliente> custom({
    Expression<int>? id,
    Expression<String>? nome,
    Expression<String>? tipo,
    Expression<String>? email,
    Expression<String>? site,
    Expression<String>? cpfCnpj,
    Expression<String>? rgIe,
    Expression<DateTime>? desde,
    Expression<double>? taxaDesconto,
    Expression<double>? limiteCredito,
    Expression<DateTime>? dataCadastro,
    Expression<String>? observacao,
    Expression<int>? idPessoa,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (nome != null) 'nome': nome,
      if (tipo != null) 'tipo': tipo,
      if (email != null) 'email': email,
      if (site != null) 'site': site,
      if (cpfCnpj != null) 'cpf_cnpj': cpfCnpj,
      if (rgIe != null) 'rg_ie': rgIe,
      if (desde != null) 'desde': desde,
      if (taxaDesconto != null) 'taxa_desconto': taxaDesconto,
      if (limiteCredito != null) 'limite_credito': limiteCredito,
      if (dataCadastro != null) 'data_cadastro': dataCadastro,
      if (observacao != null) 'observacao': observacao,
      if (idPessoa != null) 'id_pessoa': idPessoa,
    });
  }

  ViewPessoaClientesCompanion copyWith({
    Value<int?>? id,
    Value<String?>? nome,
    Value<String?>? tipo,
    Value<String?>? email,
    Value<String?>? site,
    Value<String?>? cpfCnpj,
    Value<String?>? rgIe,
    Value<DateTime?>? desde,
    Value<double?>? taxaDesconto,
    Value<double?>? limiteCredito,
    Value<DateTime?>? dataCadastro,
    Value<String?>? observacao,
    Value<int?>? idPessoa,
  }) {
    return ViewPessoaClientesCompanion(
      id: id ?? this.id,
      nome: nome ?? this.nome,
      tipo: tipo ?? this.tipo,
      email: email ?? this.email,
      site: site ?? this.site,
      cpfCnpj: cpfCnpj ?? this.cpfCnpj,
      rgIe: rgIe ?? this.rgIe,
      desde: desde ?? this.desde,
      taxaDesconto: taxaDesconto ?? this.taxaDesconto,
      limiteCredito: limiteCredito ?? this.limiteCredito,
      dataCadastro: dataCadastro ?? this.dataCadastro,
      observacao: observacao ?? this.observacao,
      idPessoa: idPessoa ?? this.idPessoa,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (nome.present) {
      map['nome'] = Variable<String>(nome.value);
    }
    if (tipo.present) {
      map['tipo'] = Variable<String>(tipo.value);
    }
    if (email.present) {
      map['email'] = Variable<String>(email.value);
    }
    if (site.present) {
      map['site'] = Variable<String>(site.value);
    }
    if (cpfCnpj.present) {
      map['cpf_cnpj'] = Variable<String>(cpfCnpj.value);
    }
    if (rgIe.present) {
      map['rg_ie'] = Variable<String>(rgIe.value);
    }
    if (desde.present) {
      map['desde'] = Variable<DateTime>(desde.value);
    }
    if (taxaDesconto.present) {
      map['taxa_desconto'] = Variable<double>(taxaDesconto.value);
    }
    if (limiteCredito.present) {
      map['limite_credito'] = Variable<double>(limiteCredito.value);
    }
    if (dataCadastro.present) {
      map['data_cadastro'] = Variable<DateTime>(dataCadastro.value);
    }
    if (observacao.present) {
      map['observacao'] = Variable<String>(observacao.value);
    }
    if (idPessoa.present) {
      map['id_pessoa'] = Variable<int>(idPessoa.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('ViewPessoaClientesCompanion(')
          ..write('id: $id, ')
          ..write('nome: $nome, ')
          ..write('tipo: $tipo, ')
          ..write('email: $email, ')
          ..write('site: $site, ')
          ..write('cpfCnpj: $cpfCnpj, ')
          ..write('rgIe: $rgIe, ')
          ..write('desde: $desde, ')
          ..write('taxaDesconto: $taxaDesconto, ')
          ..write('limiteCredito: $limiteCredito, ')
          ..write('dataCadastro: $dataCadastro, ')
          ..write('observacao: $observacao, ')
          ..write('idPessoa: $idPessoa')
          ..write(')'))
        .toString();
  }
}

class $ViewPessoaColaboradorsTable extends ViewPessoaColaboradors
    with TableInfo<$ViewPessoaColaboradorsTable, ViewPessoaColaborador> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $ViewPessoaColaboradorsTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
    'id',
    aliasedName,
    true,
    type: DriftSqlType.int,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _nomeMeta = const VerificationMeta('nome');
  @override
  late final GeneratedColumn<String> nome = GeneratedColumn<String>(
    'nome',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 150,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _tipoMeta = const VerificationMeta('tipo');
  @override
  late final GeneratedColumn<String> tipo = GeneratedColumn<String>(
    'tipo',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 3,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _emailMeta = const VerificationMeta('email');
  @override
  late final GeneratedColumn<String> email = GeneratedColumn<String>(
    'email',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 250,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _siteMeta = const VerificationMeta('site');
  @override
  late final GeneratedColumn<String> site = GeneratedColumn<String>(
    'site',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 150,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _cpfCnpjMeta = const VerificationMeta(
    'cpfCnpj',
  );
  @override
  late final GeneratedColumn<String> cpfCnpj = GeneratedColumn<String>(
    'cpf_cnpj',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 20,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _rgIeMeta = const VerificationMeta('rgIe');
  @override
  late final GeneratedColumn<String> rgIe = GeneratedColumn<String>(
    'rg_ie',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 20,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _matriculaMeta = const VerificationMeta(
    'matricula',
  );
  @override
  late final GeneratedColumn<String> matricula = GeneratedColumn<String>(
    'matricula',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 50,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _dataCadastroMeta = const VerificationMeta(
    'dataCadastro',
  );
  @override
  late final GeneratedColumn<DateTime> dataCadastro = GeneratedColumn<DateTime>(
    'data_cadastro',
    aliasedName,
    true,
    type: DriftSqlType.dateTime,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _dataAdmissaoMeta = const VerificationMeta(
    'dataAdmissao',
  );
  @override
  late final GeneratedColumn<DateTime> dataAdmissao = GeneratedColumn<DateTime>(
    'data_admissao',
    aliasedName,
    true,
    type: DriftSqlType.dateTime,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _dataDemissaoMeta = const VerificationMeta(
    'dataDemissao',
  );
  @override
  late final GeneratedColumn<DateTime> dataDemissao = GeneratedColumn<DateTime>(
    'data_demissao',
    aliasedName,
    true,
    type: DriftSqlType.dateTime,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _ctpsNumeroMeta = const VerificationMeta(
    'ctpsNumero',
  );
  @override
  late final GeneratedColumn<String> ctpsNumero = GeneratedColumn<String>(
    'ctps_numero',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 20,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _ctpsSerieMeta = const VerificationMeta(
    'ctpsSerie',
  );
  @override
  late final GeneratedColumn<String> ctpsSerie = GeneratedColumn<String>(
    'ctps_serie',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 10,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _ctpsDataExpedicaoMeta = const VerificationMeta(
    'ctpsDataExpedicao',
  );
  @override
  late final GeneratedColumn<DateTime> ctpsDataExpedicao =
      GeneratedColumn<DateTime>(
        'ctps_data_expedicao',
        aliasedName,
        true,
        type: DriftSqlType.dateTime,
        requiredDuringInsert: false,
      );
  static const VerificationMeta _ctpsUfMeta = const VerificationMeta('ctpsUf');
  @override
  late final GeneratedColumn<String> ctpsUf = GeneratedColumn<String>(
    'ctps_uf',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 2,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _observacaoMeta = const VerificationMeta(
    'observacao',
  );
  @override
  late final GeneratedColumn<String> observacao = GeneratedColumn<String>(
    'observacao',
    aliasedName,
    true,
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _logradouroMeta = const VerificationMeta(
    'logradouro',
  );
  @override
  late final GeneratedColumn<String> logradouro = GeneratedColumn<String>(
    'logradouro',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 150,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _numeroMeta = const VerificationMeta('numero');
  @override
  late final GeneratedColumn<String> numero = GeneratedColumn<String>(
    'numero',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 20,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _complementoMeta = const VerificationMeta(
    'complemento',
  );
  @override
  late final GeneratedColumn<String> complemento = GeneratedColumn<String>(
    'complemento',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 150,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _bairroMeta = const VerificationMeta('bairro');
  @override
  late final GeneratedColumn<String> bairro = GeneratedColumn<String>(
    'bairro',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 150,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _cidadeMeta = const VerificationMeta('cidade');
  @override
  late final GeneratedColumn<String> cidade = GeneratedColumn<String>(
    'cidade',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 150,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _cepMeta = const VerificationMeta('cep');
  @override
  late final GeneratedColumn<String> cep = GeneratedColumn<String>(
    'cep',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 10,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _municipioIbgeMeta = const VerificationMeta(
    'municipioIbge',
  );
  @override
  late final GeneratedColumn<String> municipioIbge = GeneratedColumn<String>(
    'municipio_ibge',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 10,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _ufMeta = const VerificationMeta('uf');
  @override
  late final GeneratedColumn<String> uf = GeneratedColumn<String>(
    'uf',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 2,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _idPessoaMeta = const VerificationMeta(
    'idPessoa',
  );
  @override
  late final GeneratedColumn<int> idPessoa = GeneratedColumn<int>(
    'id_pessoa',
    aliasedName,
    true,
    type: DriftSqlType.int,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _idCargoMeta = const VerificationMeta(
    'idCargo',
  );
  @override
  late final GeneratedColumn<int> idCargo = GeneratedColumn<int>(
    'id_cargo',
    aliasedName,
    true,
    type: DriftSqlType.int,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _idSetorMeta = const VerificationMeta(
    'idSetor',
  );
  @override
  late final GeneratedColumn<int> idSetor = GeneratedColumn<int>(
    'id_setor',
    aliasedName,
    true,
    type: DriftSqlType.int,
    requiredDuringInsert: false,
  );
  @override
  List<GeneratedColumn> get $columns => [
    id,
    nome,
    tipo,
    email,
    site,
    cpfCnpj,
    rgIe,
    matricula,
    dataCadastro,
    dataAdmissao,
    dataDemissao,
    ctpsNumero,
    ctpsSerie,
    ctpsDataExpedicao,
    ctpsUf,
    observacao,
    logradouro,
    numero,
    complemento,
    bairro,
    cidade,
    cep,
    municipioIbge,
    uf,
    idPessoa,
    idCargo,
    idSetor,
  ];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'view_pessoa_colaborador';
  @override
  VerificationContext validateIntegrity(
    Insertable<ViewPessoaColaborador> instance, {
    bool isInserting = false,
  }) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('nome')) {
      context.handle(
        _nomeMeta,
        nome.isAcceptableOrUnknown(data['nome']!, _nomeMeta),
      );
    }
    if (data.containsKey('tipo')) {
      context.handle(
        _tipoMeta,
        tipo.isAcceptableOrUnknown(data['tipo']!, _tipoMeta),
      );
    }
    if (data.containsKey('email')) {
      context.handle(
        _emailMeta,
        email.isAcceptableOrUnknown(data['email']!, _emailMeta),
      );
    }
    if (data.containsKey('site')) {
      context.handle(
        _siteMeta,
        site.isAcceptableOrUnknown(data['site']!, _siteMeta),
      );
    }
    if (data.containsKey('cpf_cnpj')) {
      context.handle(
        _cpfCnpjMeta,
        cpfCnpj.isAcceptableOrUnknown(data['cpf_cnpj']!, _cpfCnpjMeta),
      );
    }
    if (data.containsKey('rg_ie')) {
      context.handle(
        _rgIeMeta,
        rgIe.isAcceptableOrUnknown(data['rg_ie']!, _rgIeMeta),
      );
    }
    if (data.containsKey('matricula')) {
      context.handle(
        _matriculaMeta,
        matricula.isAcceptableOrUnknown(data['matricula']!, _matriculaMeta),
      );
    }
    if (data.containsKey('data_cadastro')) {
      context.handle(
        _dataCadastroMeta,
        dataCadastro.isAcceptableOrUnknown(
          data['data_cadastro']!,
          _dataCadastroMeta,
        ),
      );
    }
    if (data.containsKey('data_admissao')) {
      context.handle(
        _dataAdmissaoMeta,
        dataAdmissao.isAcceptableOrUnknown(
          data['data_admissao']!,
          _dataAdmissaoMeta,
        ),
      );
    }
    if (data.containsKey('data_demissao')) {
      context.handle(
        _dataDemissaoMeta,
        dataDemissao.isAcceptableOrUnknown(
          data['data_demissao']!,
          _dataDemissaoMeta,
        ),
      );
    }
    if (data.containsKey('ctps_numero')) {
      context.handle(
        _ctpsNumeroMeta,
        ctpsNumero.isAcceptableOrUnknown(data['ctps_numero']!, _ctpsNumeroMeta),
      );
    }
    if (data.containsKey('ctps_serie')) {
      context.handle(
        _ctpsSerieMeta,
        ctpsSerie.isAcceptableOrUnknown(data['ctps_serie']!, _ctpsSerieMeta),
      );
    }
    if (data.containsKey('ctps_data_expedicao')) {
      context.handle(
        _ctpsDataExpedicaoMeta,
        ctpsDataExpedicao.isAcceptableOrUnknown(
          data['ctps_data_expedicao']!,
          _ctpsDataExpedicaoMeta,
        ),
      );
    }
    if (data.containsKey('ctps_uf')) {
      context.handle(
        _ctpsUfMeta,
        ctpsUf.isAcceptableOrUnknown(data['ctps_uf']!, _ctpsUfMeta),
      );
    }
    if (data.containsKey('observacao')) {
      context.handle(
        _observacaoMeta,
        observacao.isAcceptableOrUnknown(data['observacao']!, _observacaoMeta),
      );
    }
    if (data.containsKey('logradouro')) {
      context.handle(
        _logradouroMeta,
        logradouro.isAcceptableOrUnknown(data['logradouro']!, _logradouroMeta),
      );
    }
    if (data.containsKey('numero')) {
      context.handle(
        _numeroMeta,
        numero.isAcceptableOrUnknown(data['numero']!, _numeroMeta),
      );
    }
    if (data.containsKey('complemento')) {
      context.handle(
        _complementoMeta,
        complemento.isAcceptableOrUnknown(
          data['complemento']!,
          _complementoMeta,
        ),
      );
    }
    if (data.containsKey('bairro')) {
      context.handle(
        _bairroMeta,
        bairro.isAcceptableOrUnknown(data['bairro']!, _bairroMeta),
      );
    }
    if (data.containsKey('cidade')) {
      context.handle(
        _cidadeMeta,
        cidade.isAcceptableOrUnknown(data['cidade']!, _cidadeMeta),
      );
    }
    if (data.containsKey('cep')) {
      context.handle(
        _cepMeta,
        cep.isAcceptableOrUnknown(data['cep']!, _cepMeta),
      );
    }
    if (data.containsKey('municipio_ibge')) {
      context.handle(
        _municipioIbgeMeta,
        municipioIbge.isAcceptableOrUnknown(
          data['municipio_ibge']!,
          _municipioIbgeMeta,
        ),
      );
    }
    if (data.containsKey('uf')) {
      context.handle(_ufMeta, uf.isAcceptableOrUnknown(data['uf']!, _ufMeta));
    }
    if (data.containsKey('id_pessoa')) {
      context.handle(
        _idPessoaMeta,
        idPessoa.isAcceptableOrUnknown(data['id_pessoa']!, _idPessoaMeta),
      );
    }
    if (data.containsKey('id_cargo')) {
      context.handle(
        _idCargoMeta,
        idCargo.isAcceptableOrUnknown(data['id_cargo']!, _idCargoMeta),
      );
    }
    if (data.containsKey('id_setor')) {
      context.handle(
        _idSetorMeta,
        idSetor.isAcceptableOrUnknown(data['id_setor']!, _idSetorMeta),
      );
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  ViewPessoaColaborador map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return ViewPessoaColaborador(
      id: attachedDatabase.typeMapping.read(
        DriftSqlType.int,
        data['${effectivePrefix}id'],
      ),
      nome: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}nome'],
      ),
      tipo: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}tipo'],
      ),
      email: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}email'],
      ),
      site: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}site'],
      ),
      cpfCnpj: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}cpf_cnpj'],
      ),
      rgIe: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}rg_ie'],
      ),
      matricula: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}matricula'],
      ),
      dataCadastro: attachedDatabase.typeMapping.read(
        DriftSqlType.dateTime,
        data['${effectivePrefix}data_cadastro'],
      ),
      dataAdmissao: attachedDatabase.typeMapping.read(
        DriftSqlType.dateTime,
        data['${effectivePrefix}data_admissao'],
      ),
      dataDemissao: attachedDatabase.typeMapping.read(
        DriftSqlType.dateTime,
        data['${effectivePrefix}data_demissao'],
      ),
      ctpsNumero: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}ctps_numero'],
      ),
      ctpsSerie: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}ctps_serie'],
      ),
      ctpsDataExpedicao: attachedDatabase.typeMapping.read(
        DriftSqlType.dateTime,
        data['${effectivePrefix}ctps_data_expedicao'],
      ),
      ctpsUf: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}ctps_uf'],
      ),
      observacao: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}observacao'],
      ),
      logradouro: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}logradouro'],
      ),
      numero: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}numero'],
      ),
      complemento: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}complemento'],
      ),
      bairro: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}bairro'],
      ),
      cidade: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}cidade'],
      ),
      cep: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}cep'],
      ),
      municipioIbge: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}municipio_ibge'],
      ),
      uf: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}uf'],
      ),
      idPessoa: attachedDatabase.typeMapping.read(
        DriftSqlType.int,
        data['${effectivePrefix}id_pessoa'],
      ),
      idCargo: attachedDatabase.typeMapping.read(
        DriftSqlType.int,
        data['${effectivePrefix}id_cargo'],
      ),
      idSetor: attachedDatabase.typeMapping.read(
        DriftSqlType.int,
        data['${effectivePrefix}id_setor'],
      ),
    );
  }

  @override
  $ViewPessoaColaboradorsTable createAlias(String alias) {
    return $ViewPessoaColaboradorsTable(attachedDatabase, alias);
  }
}

class ViewPessoaColaborador extends DataClass
    implements Insertable<ViewPessoaColaborador> {
  final int? id;
  final String? nome;
  final String? tipo;
  final String? email;
  final String? site;
  final String? cpfCnpj;
  final String? rgIe;
  final String? matricula;
  final DateTime? dataCadastro;
  final DateTime? dataAdmissao;
  final DateTime? dataDemissao;
  final String? ctpsNumero;
  final String? ctpsSerie;
  final DateTime? ctpsDataExpedicao;
  final String? ctpsUf;
  final String? observacao;
  final String? logradouro;
  final String? numero;
  final String? complemento;
  final String? bairro;
  final String? cidade;
  final String? cep;
  final String? municipioIbge;
  final String? uf;
  final int? idPessoa;
  final int? idCargo;
  final int? idSetor;
  const ViewPessoaColaborador({
    this.id,
    this.nome,
    this.tipo,
    this.email,
    this.site,
    this.cpfCnpj,
    this.rgIe,
    this.matricula,
    this.dataCadastro,
    this.dataAdmissao,
    this.dataDemissao,
    this.ctpsNumero,
    this.ctpsSerie,
    this.ctpsDataExpedicao,
    this.ctpsUf,
    this.observacao,
    this.logradouro,
    this.numero,
    this.complemento,
    this.bairro,
    this.cidade,
    this.cep,
    this.municipioIbge,
    this.uf,
    this.idPessoa,
    this.idCargo,
    this.idSetor,
  });
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || nome != null) {
      map['nome'] = Variable<String>(nome);
    }
    if (!nullToAbsent || tipo != null) {
      map['tipo'] = Variable<String>(tipo);
    }
    if (!nullToAbsent || email != null) {
      map['email'] = Variable<String>(email);
    }
    if (!nullToAbsent || site != null) {
      map['site'] = Variable<String>(site);
    }
    if (!nullToAbsent || cpfCnpj != null) {
      map['cpf_cnpj'] = Variable<String>(cpfCnpj);
    }
    if (!nullToAbsent || rgIe != null) {
      map['rg_ie'] = Variable<String>(rgIe);
    }
    if (!nullToAbsent || matricula != null) {
      map['matricula'] = Variable<String>(matricula);
    }
    if (!nullToAbsent || dataCadastro != null) {
      map['data_cadastro'] = Variable<DateTime>(dataCadastro);
    }
    if (!nullToAbsent || dataAdmissao != null) {
      map['data_admissao'] = Variable<DateTime>(dataAdmissao);
    }
    if (!nullToAbsent || dataDemissao != null) {
      map['data_demissao'] = Variable<DateTime>(dataDemissao);
    }
    if (!nullToAbsent || ctpsNumero != null) {
      map['ctps_numero'] = Variable<String>(ctpsNumero);
    }
    if (!nullToAbsent || ctpsSerie != null) {
      map['ctps_serie'] = Variable<String>(ctpsSerie);
    }
    if (!nullToAbsent || ctpsDataExpedicao != null) {
      map['ctps_data_expedicao'] = Variable<DateTime>(ctpsDataExpedicao);
    }
    if (!nullToAbsent || ctpsUf != null) {
      map['ctps_uf'] = Variable<String>(ctpsUf);
    }
    if (!nullToAbsent || observacao != null) {
      map['observacao'] = Variable<String>(observacao);
    }
    if (!nullToAbsent || logradouro != null) {
      map['logradouro'] = Variable<String>(logradouro);
    }
    if (!nullToAbsent || numero != null) {
      map['numero'] = Variable<String>(numero);
    }
    if (!nullToAbsent || complemento != null) {
      map['complemento'] = Variable<String>(complemento);
    }
    if (!nullToAbsent || bairro != null) {
      map['bairro'] = Variable<String>(bairro);
    }
    if (!nullToAbsent || cidade != null) {
      map['cidade'] = Variable<String>(cidade);
    }
    if (!nullToAbsent || cep != null) {
      map['cep'] = Variable<String>(cep);
    }
    if (!nullToAbsent || municipioIbge != null) {
      map['municipio_ibge'] = Variable<String>(municipioIbge);
    }
    if (!nullToAbsent || uf != null) {
      map['uf'] = Variable<String>(uf);
    }
    if (!nullToAbsent || idPessoa != null) {
      map['id_pessoa'] = Variable<int>(idPessoa);
    }
    if (!nullToAbsent || idCargo != null) {
      map['id_cargo'] = Variable<int>(idCargo);
    }
    if (!nullToAbsent || idSetor != null) {
      map['id_setor'] = Variable<int>(idSetor);
    }
    return map;
  }

  factory ViewPessoaColaborador.fromJson(
    Map<String, dynamic> json, {
    ValueSerializer? serializer,
  }) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return ViewPessoaColaborador(
      id: serializer.fromJson<int?>(json['id']),
      nome: serializer.fromJson<String?>(json['nome']),
      tipo: serializer.fromJson<String?>(json['tipo']),
      email: serializer.fromJson<String?>(json['email']),
      site: serializer.fromJson<String?>(json['site']),
      cpfCnpj: serializer.fromJson<String?>(json['cpfCnpj']),
      rgIe: serializer.fromJson<String?>(json['rgIe']),
      matricula: serializer.fromJson<String?>(json['matricula']),
      dataCadastro: serializer.fromJson<DateTime?>(json['dataCadastro']),
      dataAdmissao: serializer.fromJson<DateTime?>(json['dataAdmissao']),
      dataDemissao: serializer.fromJson<DateTime?>(json['dataDemissao']),
      ctpsNumero: serializer.fromJson<String?>(json['ctpsNumero']),
      ctpsSerie: serializer.fromJson<String?>(json['ctpsSerie']),
      ctpsDataExpedicao: serializer.fromJson<DateTime?>(
        json['ctpsDataExpedicao'],
      ),
      ctpsUf: serializer.fromJson<String?>(json['ctpsUf']),
      observacao: serializer.fromJson<String?>(json['observacao']),
      logradouro: serializer.fromJson<String?>(json['logradouro']),
      numero: serializer.fromJson<String?>(json['numero']),
      complemento: serializer.fromJson<String?>(json['complemento']),
      bairro: serializer.fromJson<String?>(json['bairro']),
      cidade: serializer.fromJson<String?>(json['cidade']),
      cep: serializer.fromJson<String?>(json['cep']),
      municipioIbge: serializer.fromJson<String?>(json['municipioIbge']),
      uf: serializer.fromJson<String?>(json['uf']),
      idPessoa: serializer.fromJson<int?>(json['idPessoa']),
      idCargo: serializer.fromJson<int?>(json['idCargo']),
      idSetor: serializer.fromJson<int?>(json['idSetor']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'nome': serializer.toJson<String?>(nome),
      'tipo': serializer.toJson<String?>(tipo),
      'email': serializer.toJson<String?>(email),
      'site': serializer.toJson<String?>(site),
      'cpfCnpj': serializer.toJson<String?>(cpfCnpj),
      'rgIe': serializer.toJson<String?>(rgIe),
      'matricula': serializer.toJson<String?>(matricula),
      'dataCadastro': serializer.toJson<DateTime?>(dataCadastro),
      'dataAdmissao': serializer.toJson<DateTime?>(dataAdmissao),
      'dataDemissao': serializer.toJson<DateTime?>(dataDemissao),
      'ctpsNumero': serializer.toJson<String?>(ctpsNumero),
      'ctpsSerie': serializer.toJson<String?>(ctpsSerie),
      'ctpsDataExpedicao': serializer.toJson<DateTime?>(ctpsDataExpedicao),
      'ctpsUf': serializer.toJson<String?>(ctpsUf),
      'observacao': serializer.toJson<String?>(observacao),
      'logradouro': serializer.toJson<String?>(logradouro),
      'numero': serializer.toJson<String?>(numero),
      'complemento': serializer.toJson<String?>(complemento),
      'bairro': serializer.toJson<String?>(bairro),
      'cidade': serializer.toJson<String?>(cidade),
      'cep': serializer.toJson<String?>(cep),
      'municipioIbge': serializer.toJson<String?>(municipioIbge),
      'uf': serializer.toJson<String?>(uf),
      'idPessoa': serializer.toJson<int?>(idPessoa),
      'idCargo': serializer.toJson<int?>(idCargo),
      'idSetor': serializer.toJson<int?>(idSetor),
    };
  }

  ViewPessoaColaborador copyWith({
    Value<int?> id = const Value.absent(),
    Value<String?> nome = const Value.absent(),
    Value<String?> tipo = const Value.absent(),
    Value<String?> email = const Value.absent(),
    Value<String?> site = const Value.absent(),
    Value<String?> cpfCnpj = const Value.absent(),
    Value<String?> rgIe = const Value.absent(),
    Value<String?> matricula = const Value.absent(),
    Value<DateTime?> dataCadastro = const Value.absent(),
    Value<DateTime?> dataAdmissao = const Value.absent(),
    Value<DateTime?> dataDemissao = const Value.absent(),
    Value<String?> ctpsNumero = const Value.absent(),
    Value<String?> ctpsSerie = const Value.absent(),
    Value<DateTime?> ctpsDataExpedicao = const Value.absent(),
    Value<String?> ctpsUf = const Value.absent(),
    Value<String?> observacao = const Value.absent(),
    Value<String?> logradouro = const Value.absent(),
    Value<String?> numero = const Value.absent(),
    Value<String?> complemento = const Value.absent(),
    Value<String?> bairro = const Value.absent(),
    Value<String?> cidade = const Value.absent(),
    Value<String?> cep = const Value.absent(),
    Value<String?> municipioIbge = const Value.absent(),
    Value<String?> uf = const Value.absent(),
    Value<int?> idPessoa = const Value.absent(),
    Value<int?> idCargo = const Value.absent(),
    Value<int?> idSetor = const Value.absent(),
  }) => ViewPessoaColaborador(
    id: id.present ? id.value : this.id,
    nome: nome.present ? nome.value : this.nome,
    tipo: tipo.present ? tipo.value : this.tipo,
    email: email.present ? email.value : this.email,
    site: site.present ? site.value : this.site,
    cpfCnpj: cpfCnpj.present ? cpfCnpj.value : this.cpfCnpj,
    rgIe: rgIe.present ? rgIe.value : this.rgIe,
    matricula: matricula.present ? matricula.value : this.matricula,
    dataCadastro: dataCadastro.present ? dataCadastro.value : this.dataCadastro,
    dataAdmissao: dataAdmissao.present ? dataAdmissao.value : this.dataAdmissao,
    dataDemissao: dataDemissao.present ? dataDemissao.value : this.dataDemissao,
    ctpsNumero: ctpsNumero.present ? ctpsNumero.value : this.ctpsNumero,
    ctpsSerie: ctpsSerie.present ? ctpsSerie.value : this.ctpsSerie,
    ctpsDataExpedicao:
        ctpsDataExpedicao.present
            ? ctpsDataExpedicao.value
            : this.ctpsDataExpedicao,
    ctpsUf: ctpsUf.present ? ctpsUf.value : this.ctpsUf,
    observacao: observacao.present ? observacao.value : this.observacao,
    logradouro: logradouro.present ? logradouro.value : this.logradouro,
    numero: numero.present ? numero.value : this.numero,
    complemento: complemento.present ? complemento.value : this.complemento,
    bairro: bairro.present ? bairro.value : this.bairro,
    cidade: cidade.present ? cidade.value : this.cidade,
    cep: cep.present ? cep.value : this.cep,
    municipioIbge:
        municipioIbge.present ? municipioIbge.value : this.municipioIbge,
    uf: uf.present ? uf.value : this.uf,
    idPessoa: idPessoa.present ? idPessoa.value : this.idPessoa,
    idCargo: idCargo.present ? idCargo.value : this.idCargo,
    idSetor: idSetor.present ? idSetor.value : this.idSetor,
  );
  ViewPessoaColaborador copyWithCompanion(
    ViewPessoaColaboradorsCompanion data,
  ) {
    return ViewPessoaColaborador(
      id: data.id.present ? data.id.value : this.id,
      nome: data.nome.present ? data.nome.value : this.nome,
      tipo: data.tipo.present ? data.tipo.value : this.tipo,
      email: data.email.present ? data.email.value : this.email,
      site: data.site.present ? data.site.value : this.site,
      cpfCnpj: data.cpfCnpj.present ? data.cpfCnpj.value : this.cpfCnpj,
      rgIe: data.rgIe.present ? data.rgIe.value : this.rgIe,
      matricula: data.matricula.present ? data.matricula.value : this.matricula,
      dataCadastro:
          data.dataCadastro.present
              ? data.dataCadastro.value
              : this.dataCadastro,
      dataAdmissao:
          data.dataAdmissao.present
              ? data.dataAdmissao.value
              : this.dataAdmissao,
      dataDemissao:
          data.dataDemissao.present
              ? data.dataDemissao.value
              : this.dataDemissao,
      ctpsNumero:
          data.ctpsNumero.present ? data.ctpsNumero.value : this.ctpsNumero,
      ctpsSerie: data.ctpsSerie.present ? data.ctpsSerie.value : this.ctpsSerie,
      ctpsDataExpedicao:
          data.ctpsDataExpedicao.present
              ? data.ctpsDataExpedicao.value
              : this.ctpsDataExpedicao,
      ctpsUf: data.ctpsUf.present ? data.ctpsUf.value : this.ctpsUf,
      observacao:
          data.observacao.present ? data.observacao.value : this.observacao,
      logradouro:
          data.logradouro.present ? data.logradouro.value : this.logradouro,
      numero: data.numero.present ? data.numero.value : this.numero,
      complemento:
          data.complemento.present ? data.complemento.value : this.complemento,
      bairro: data.bairro.present ? data.bairro.value : this.bairro,
      cidade: data.cidade.present ? data.cidade.value : this.cidade,
      cep: data.cep.present ? data.cep.value : this.cep,
      municipioIbge:
          data.municipioIbge.present
              ? data.municipioIbge.value
              : this.municipioIbge,
      uf: data.uf.present ? data.uf.value : this.uf,
      idPessoa: data.idPessoa.present ? data.idPessoa.value : this.idPessoa,
      idCargo: data.idCargo.present ? data.idCargo.value : this.idCargo,
      idSetor: data.idSetor.present ? data.idSetor.value : this.idSetor,
    );
  }

  @override
  String toString() {
    return (StringBuffer('ViewPessoaColaborador(')
          ..write('id: $id, ')
          ..write('nome: $nome, ')
          ..write('tipo: $tipo, ')
          ..write('email: $email, ')
          ..write('site: $site, ')
          ..write('cpfCnpj: $cpfCnpj, ')
          ..write('rgIe: $rgIe, ')
          ..write('matricula: $matricula, ')
          ..write('dataCadastro: $dataCadastro, ')
          ..write('dataAdmissao: $dataAdmissao, ')
          ..write('dataDemissao: $dataDemissao, ')
          ..write('ctpsNumero: $ctpsNumero, ')
          ..write('ctpsSerie: $ctpsSerie, ')
          ..write('ctpsDataExpedicao: $ctpsDataExpedicao, ')
          ..write('ctpsUf: $ctpsUf, ')
          ..write('observacao: $observacao, ')
          ..write('logradouro: $logradouro, ')
          ..write('numero: $numero, ')
          ..write('complemento: $complemento, ')
          ..write('bairro: $bairro, ')
          ..write('cidade: $cidade, ')
          ..write('cep: $cep, ')
          ..write('municipioIbge: $municipioIbge, ')
          ..write('uf: $uf, ')
          ..write('idPessoa: $idPessoa, ')
          ..write('idCargo: $idCargo, ')
          ..write('idSetor: $idSetor')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hashAll([
    id,
    nome,
    tipo,
    email,
    site,
    cpfCnpj,
    rgIe,
    matricula,
    dataCadastro,
    dataAdmissao,
    dataDemissao,
    ctpsNumero,
    ctpsSerie,
    ctpsDataExpedicao,
    ctpsUf,
    observacao,
    logradouro,
    numero,
    complemento,
    bairro,
    cidade,
    cep,
    municipioIbge,
    uf,
    idPessoa,
    idCargo,
    idSetor,
  ]);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is ViewPessoaColaborador &&
          other.id == this.id &&
          other.nome == this.nome &&
          other.tipo == this.tipo &&
          other.email == this.email &&
          other.site == this.site &&
          other.cpfCnpj == this.cpfCnpj &&
          other.rgIe == this.rgIe &&
          other.matricula == this.matricula &&
          other.dataCadastro == this.dataCadastro &&
          other.dataAdmissao == this.dataAdmissao &&
          other.dataDemissao == this.dataDemissao &&
          other.ctpsNumero == this.ctpsNumero &&
          other.ctpsSerie == this.ctpsSerie &&
          other.ctpsDataExpedicao == this.ctpsDataExpedicao &&
          other.ctpsUf == this.ctpsUf &&
          other.observacao == this.observacao &&
          other.logradouro == this.logradouro &&
          other.numero == this.numero &&
          other.complemento == this.complemento &&
          other.bairro == this.bairro &&
          other.cidade == this.cidade &&
          other.cep == this.cep &&
          other.municipioIbge == this.municipioIbge &&
          other.uf == this.uf &&
          other.idPessoa == this.idPessoa &&
          other.idCargo == this.idCargo &&
          other.idSetor == this.idSetor);
}

class ViewPessoaColaboradorsCompanion
    extends UpdateCompanion<ViewPessoaColaborador> {
  final Value<int?> id;
  final Value<String?> nome;
  final Value<String?> tipo;
  final Value<String?> email;
  final Value<String?> site;
  final Value<String?> cpfCnpj;
  final Value<String?> rgIe;
  final Value<String?> matricula;
  final Value<DateTime?> dataCadastro;
  final Value<DateTime?> dataAdmissao;
  final Value<DateTime?> dataDemissao;
  final Value<String?> ctpsNumero;
  final Value<String?> ctpsSerie;
  final Value<DateTime?> ctpsDataExpedicao;
  final Value<String?> ctpsUf;
  final Value<String?> observacao;
  final Value<String?> logradouro;
  final Value<String?> numero;
  final Value<String?> complemento;
  final Value<String?> bairro;
  final Value<String?> cidade;
  final Value<String?> cep;
  final Value<String?> municipioIbge;
  final Value<String?> uf;
  final Value<int?> idPessoa;
  final Value<int?> idCargo;
  final Value<int?> idSetor;
  const ViewPessoaColaboradorsCompanion({
    this.id = const Value.absent(),
    this.nome = const Value.absent(),
    this.tipo = const Value.absent(),
    this.email = const Value.absent(),
    this.site = const Value.absent(),
    this.cpfCnpj = const Value.absent(),
    this.rgIe = const Value.absent(),
    this.matricula = const Value.absent(),
    this.dataCadastro = const Value.absent(),
    this.dataAdmissao = const Value.absent(),
    this.dataDemissao = const Value.absent(),
    this.ctpsNumero = const Value.absent(),
    this.ctpsSerie = const Value.absent(),
    this.ctpsDataExpedicao = const Value.absent(),
    this.ctpsUf = const Value.absent(),
    this.observacao = const Value.absent(),
    this.logradouro = const Value.absent(),
    this.numero = const Value.absent(),
    this.complemento = const Value.absent(),
    this.bairro = const Value.absent(),
    this.cidade = const Value.absent(),
    this.cep = const Value.absent(),
    this.municipioIbge = const Value.absent(),
    this.uf = const Value.absent(),
    this.idPessoa = const Value.absent(),
    this.idCargo = const Value.absent(),
    this.idSetor = const Value.absent(),
  });
  ViewPessoaColaboradorsCompanion.insert({
    this.id = const Value.absent(),
    this.nome = const Value.absent(),
    this.tipo = const Value.absent(),
    this.email = const Value.absent(),
    this.site = const Value.absent(),
    this.cpfCnpj = const Value.absent(),
    this.rgIe = const Value.absent(),
    this.matricula = const Value.absent(),
    this.dataCadastro = const Value.absent(),
    this.dataAdmissao = const Value.absent(),
    this.dataDemissao = const Value.absent(),
    this.ctpsNumero = const Value.absent(),
    this.ctpsSerie = const Value.absent(),
    this.ctpsDataExpedicao = const Value.absent(),
    this.ctpsUf = const Value.absent(),
    this.observacao = const Value.absent(),
    this.logradouro = const Value.absent(),
    this.numero = const Value.absent(),
    this.complemento = const Value.absent(),
    this.bairro = const Value.absent(),
    this.cidade = const Value.absent(),
    this.cep = const Value.absent(),
    this.municipioIbge = const Value.absent(),
    this.uf = const Value.absent(),
    this.idPessoa = const Value.absent(),
    this.idCargo = const Value.absent(),
    this.idSetor = const Value.absent(),
  });
  static Insertable<ViewPessoaColaborador> custom({
    Expression<int>? id,
    Expression<String>? nome,
    Expression<String>? tipo,
    Expression<String>? email,
    Expression<String>? site,
    Expression<String>? cpfCnpj,
    Expression<String>? rgIe,
    Expression<String>? matricula,
    Expression<DateTime>? dataCadastro,
    Expression<DateTime>? dataAdmissao,
    Expression<DateTime>? dataDemissao,
    Expression<String>? ctpsNumero,
    Expression<String>? ctpsSerie,
    Expression<DateTime>? ctpsDataExpedicao,
    Expression<String>? ctpsUf,
    Expression<String>? observacao,
    Expression<String>? logradouro,
    Expression<String>? numero,
    Expression<String>? complemento,
    Expression<String>? bairro,
    Expression<String>? cidade,
    Expression<String>? cep,
    Expression<String>? municipioIbge,
    Expression<String>? uf,
    Expression<int>? idPessoa,
    Expression<int>? idCargo,
    Expression<int>? idSetor,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (nome != null) 'nome': nome,
      if (tipo != null) 'tipo': tipo,
      if (email != null) 'email': email,
      if (site != null) 'site': site,
      if (cpfCnpj != null) 'cpf_cnpj': cpfCnpj,
      if (rgIe != null) 'rg_ie': rgIe,
      if (matricula != null) 'matricula': matricula,
      if (dataCadastro != null) 'data_cadastro': dataCadastro,
      if (dataAdmissao != null) 'data_admissao': dataAdmissao,
      if (dataDemissao != null) 'data_demissao': dataDemissao,
      if (ctpsNumero != null) 'ctps_numero': ctpsNumero,
      if (ctpsSerie != null) 'ctps_serie': ctpsSerie,
      if (ctpsDataExpedicao != null) 'ctps_data_expedicao': ctpsDataExpedicao,
      if (ctpsUf != null) 'ctps_uf': ctpsUf,
      if (observacao != null) 'observacao': observacao,
      if (logradouro != null) 'logradouro': logradouro,
      if (numero != null) 'numero': numero,
      if (complemento != null) 'complemento': complemento,
      if (bairro != null) 'bairro': bairro,
      if (cidade != null) 'cidade': cidade,
      if (cep != null) 'cep': cep,
      if (municipioIbge != null) 'municipio_ibge': municipioIbge,
      if (uf != null) 'uf': uf,
      if (idPessoa != null) 'id_pessoa': idPessoa,
      if (idCargo != null) 'id_cargo': idCargo,
      if (idSetor != null) 'id_setor': idSetor,
    });
  }

  ViewPessoaColaboradorsCompanion copyWith({
    Value<int?>? id,
    Value<String?>? nome,
    Value<String?>? tipo,
    Value<String?>? email,
    Value<String?>? site,
    Value<String?>? cpfCnpj,
    Value<String?>? rgIe,
    Value<String?>? matricula,
    Value<DateTime?>? dataCadastro,
    Value<DateTime?>? dataAdmissao,
    Value<DateTime?>? dataDemissao,
    Value<String?>? ctpsNumero,
    Value<String?>? ctpsSerie,
    Value<DateTime?>? ctpsDataExpedicao,
    Value<String?>? ctpsUf,
    Value<String?>? observacao,
    Value<String?>? logradouro,
    Value<String?>? numero,
    Value<String?>? complemento,
    Value<String?>? bairro,
    Value<String?>? cidade,
    Value<String?>? cep,
    Value<String?>? municipioIbge,
    Value<String?>? uf,
    Value<int?>? idPessoa,
    Value<int?>? idCargo,
    Value<int?>? idSetor,
  }) {
    return ViewPessoaColaboradorsCompanion(
      id: id ?? this.id,
      nome: nome ?? this.nome,
      tipo: tipo ?? this.tipo,
      email: email ?? this.email,
      site: site ?? this.site,
      cpfCnpj: cpfCnpj ?? this.cpfCnpj,
      rgIe: rgIe ?? this.rgIe,
      matricula: matricula ?? this.matricula,
      dataCadastro: dataCadastro ?? this.dataCadastro,
      dataAdmissao: dataAdmissao ?? this.dataAdmissao,
      dataDemissao: dataDemissao ?? this.dataDemissao,
      ctpsNumero: ctpsNumero ?? this.ctpsNumero,
      ctpsSerie: ctpsSerie ?? this.ctpsSerie,
      ctpsDataExpedicao: ctpsDataExpedicao ?? this.ctpsDataExpedicao,
      ctpsUf: ctpsUf ?? this.ctpsUf,
      observacao: observacao ?? this.observacao,
      logradouro: logradouro ?? this.logradouro,
      numero: numero ?? this.numero,
      complemento: complemento ?? this.complemento,
      bairro: bairro ?? this.bairro,
      cidade: cidade ?? this.cidade,
      cep: cep ?? this.cep,
      municipioIbge: municipioIbge ?? this.municipioIbge,
      uf: uf ?? this.uf,
      idPessoa: idPessoa ?? this.idPessoa,
      idCargo: idCargo ?? this.idCargo,
      idSetor: idSetor ?? this.idSetor,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (nome.present) {
      map['nome'] = Variable<String>(nome.value);
    }
    if (tipo.present) {
      map['tipo'] = Variable<String>(tipo.value);
    }
    if (email.present) {
      map['email'] = Variable<String>(email.value);
    }
    if (site.present) {
      map['site'] = Variable<String>(site.value);
    }
    if (cpfCnpj.present) {
      map['cpf_cnpj'] = Variable<String>(cpfCnpj.value);
    }
    if (rgIe.present) {
      map['rg_ie'] = Variable<String>(rgIe.value);
    }
    if (matricula.present) {
      map['matricula'] = Variable<String>(matricula.value);
    }
    if (dataCadastro.present) {
      map['data_cadastro'] = Variable<DateTime>(dataCadastro.value);
    }
    if (dataAdmissao.present) {
      map['data_admissao'] = Variable<DateTime>(dataAdmissao.value);
    }
    if (dataDemissao.present) {
      map['data_demissao'] = Variable<DateTime>(dataDemissao.value);
    }
    if (ctpsNumero.present) {
      map['ctps_numero'] = Variable<String>(ctpsNumero.value);
    }
    if (ctpsSerie.present) {
      map['ctps_serie'] = Variable<String>(ctpsSerie.value);
    }
    if (ctpsDataExpedicao.present) {
      map['ctps_data_expedicao'] = Variable<DateTime>(ctpsDataExpedicao.value);
    }
    if (ctpsUf.present) {
      map['ctps_uf'] = Variable<String>(ctpsUf.value);
    }
    if (observacao.present) {
      map['observacao'] = Variable<String>(observacao.value);
    }
    if (logradouro.present) {
      map['logradouro'] = Variable<String>(logradouro.value);
    }
    if (numero.present) {
      map['numero'] = Variable<String>(numero.value);
    }
    if (complemento.present) {
      map['complemento'] = Variable<String>(complemento.value);
    }
    if (bairro.present) {
      map['bairro'] = Variable<String>(bairro.value);
    }
    if (cidade.present) {
      map['cidade'] = Variable<String>(cidade.value);
    }
    if (cep.present) {
      map['cep'] = Variable<String>(cep.value);
    }
    if (municipioIbge.present) {
      map['municipio_ibge'] = Variable<String>(municipioIbge.value);
    }
    if (uf.present) {
      map['uf'] = Variable<String>(uf.value);
    }
    if (idPessoa.present) {
      map['id_pessoa'] = Variable<int>(idPessoa.value);
    }
    if (idCargo.present) {
      map['id_cargo'] = Variable<int>(idCargo.value);
    }
    if (idSetor.present) {
      map['id_setor'] = Variable<int>(idSetor.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('ViewPessoaColaboradorsCompanion(')
          ..write('id: $id, ')
          ..write('nome: $nome, ')
          ..write('tipo: $tipo, ')
          ..write('email: $email, ')
          ..write('site: $site, ')
          ..write('cpfCnpj: $cpfCnpj, ')
          ..write('rgIe: $rgIe, ')
          ..write('matricula: $matricula, ')
          ..write('dataCadastro: $dataCadastro, ')
          ..write('dataAdmissao: $dataAdmissao, ')
          ..write('dataDemissao: $dataDemissao, ')
          ..write('ctpsNumero: $ctpsNumero, ')
          ..write('ctpsSerie: $ctpsSerie, ')
          ..write('ctpsDataExpedicao: $ctpsDataExpedicao, ')
          ..write('ctpsUf: $ctpsUf, ')
          ..write('observacao: $observacao, ')
          ..write('logradouro: $logradouro, ')
          ..write('numero: $numero, ')
          ..write('complemento: $complemento, ')
          ..write('bairro: $bairro, ')
          ..write('cidade: $cidade, ')
          ..write('cep: $cep, ')
          ..write('municipioIbge: $municipioIbge, ')
          ..write('uf: $uf, ')
          ..write('idPessoa: $idPessoa, ')
          ..write('idCargo: $idCargo, ')
          ..write('idSetor: $idSetor')
          ..write(')'))
        .toString();
  }
}

class $CrmContatosTable extends CrmContatos
    with TableInfo<$CrmContatosTable, CrmContato> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $CrmContatosTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
    'id',
    aliasedName,
    true,
    type: DriftSqlType.int,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _idClienteMeta = const VerificationMeta(
    'idCliente',
  );
  @override
  late final GeneratedColumn<int> idCliente = GeneratedColumn<int>(
    'id_cliente',
    aliasedName,
    true,
    type: DriftSqlType.int,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _idViewPessoaColaboradorMeta =
      const VerificationMeta('idViewPessoaColaborador');
  @override
  late final GeneratedColumn<int> idViewPessoaColaborador =
      GeneratedColumn<int>(
        'id_view_pessoa_colaborador',
        aliasedName,
        true,
        type: DriftSqlType.int,
        requiredDuringInsert: false,
      );
  static const VerificationMeta _tipoContatoMeta = const VerificationMeta(
    'tipoContato',
  );
  @override
  late final GeneratedColumn<String> tipoContato = GeneratedColumn<String>(
    'tipo_contato',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 1,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _horaContatoMeta = const VerificationMeta(
    'horaContato',
  );
  @override
  late final GeneratedColumn<String> horaContato = GeneratedColumn<String>(
    'hora_contato',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 8,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _assuntoMeta = const VerificationMeta(
    'assunto',
  );
  @override
  late final GeneratedColumn<String> assunto = GeneratedColumn<String>(
    'assunto',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 200,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _descricaoMeta = const VerificationMeta(
    'descricao',
  );
  @override
  late final GeneratedColumn<String> descricao = GeneratedColumn<String>(
    'descricao',
    aliasedName,
    true,
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _resultadoMeta = const VerificationMeta(
    'resultado',
  );
  @override
  late final GeneratedColumn<String> resultado = GeneratedColumn<String>(
    'resultado',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 1,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _proximaDataMeta = const VerificationMeta(
    'proximaData',
  );
  @override
  late final GeneratedColumn<DateTime> proximaData = GeneratedColumn<DateTime>(
    'proxima_data',
    aliasedName,
    true,
    type: DriftSqlType.dateTime,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _proximaAcaoMeta = const VerificationMeta(
    'proximaAcao',
  );
  @override
  late final GeneratedColumn<String> proximaAcao = GeneratedColumn<String>(
    'proxima_acao',
    aliasedName,
    true,
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  @override
  List<GeneratedColumn> get $columns => [
    id,
    idCliente,
    idViewPessoaColaborador,
    tipoContato,
    horaContato,
    assunto,
    descricao,
    resultado,
    proximaData,
    proximaAcao,
  ];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'crm_contato';
  @override
  VerificationContext validateIntegrity(
    Insertable<CrmContato> instance, {
    bool isInserting = false,
  }) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('id_cliente')) {
      context.handle(
        _idClienteMeta,
        idCliente.isAcceptableOrUnknown(data['id_cliente']!, _idClienteMeta),
      );
    }
    if (data.containsKey('id_view_pessoa_colaborador')) {
      context.handle(
        _idViewPessoaColaboradorMeta,
        idViewPessoaColaborador.isAcceptableOrUnknown(
          data['id_view_pessoa_colaborador']!,
          _idViewPessoaColaboradorMeta,
        ),
      );
    }
    if (data.containsKey('tipo_contato')) {
      context.handle(
        _tipoContatoMeta,
        tipoContato.isAcceptableOrUnknown(
          data['tipo_contato']!,
          _tipoContatoMeta,
        ),
      );
    }
    if (data.containsKey('hora_contato')) {
      context.handle(
        _horaContatoMeta,
        horaContato.isAcceptableOrUnknown(
          data['hora_contato']!,
          _horaContatoMeta,
        ),
      );
    }
    if (data.containsKey('assunto')) {
      context.handle(
        _assuntoMeta,
        assunto.isAcceptableOrUnknown(data['assunto']!, _assuntoMeta),
      );
    }
    if (data.containsKey('descricao')) {
      context.handle(
        _descricaoMeta,
        descricao.isAcceptableOrUnknown(data['descricao']!, _descricaoMeta),
      );
    }
    if (data.containsKey('resultado')) {
      context.handle(
        _resultadoMeta,
        resultado.isAcceptableOrUnknown(data['resultado']!, _resultadoMeta),
      );
    }
    if (data.containsKey('proxima_data')) {
      context.handle(
        _proximaDataMeta,
        proximaData.isAcceptableOrUnknown(
          data['proxima_data']!,
          _proximaDataMeta,
        ),
      );
    }
    if (data.containsKey('proxima_acao')) {
      context.handle(
        _proximaAcaoMeta,
        proximaAcao.isAcceptableOrUnknown(
          data['proxima_acao']!,
          _proximaAcaoMeta,
        ),
      );
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  CrmContato map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return CrmContato(
      id: attachedDatabase.typeMapping.read(
        DriftSqlType.int,
        data['${effectivePrefix}id'],
      ),
      idCliente: attachedDatabase.typeMapping.read(
        DriftSqlType.int,
        data['${effectivePrefix}id_cliente'],
      ),
      idViewPessoaColaborador: attachedDatabase.typeMapping.read(
        DriftSqlType.int,
        data['${effectivePrefix}id_view_pessoa_colaborador'],
      ),
      tipoContato: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}tipo_contato'],
      ),
      horaContato: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}hora_contato'],
      ),
      assunto: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}assunto'],
      ),
      descricao: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}descricao'],
      ),
      resultado: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}resultado'],
      ),
      proximaData: attachedDatabase.typeMapping.read(
        DriftSqlType.dateTime,
        data['${effectivePrefix}proxima_data'],
      ),
      proximaAcao: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}proxima_acao'],
      ),
    );
  }

  @override
  $CrmContatosTable createAlias(String alias) {
    return $CrmContatosTable(attachedDatabase, alias);
  }
}

class CrmContato extends DataClass implements Insertable<CrmContato> {
  final int? id;
  final int? idCliente;
  final int? idViewPessoaColaborador;
  final String? tipoContato;
  final String? horaContato;
  final String? assunto;
  final String? descricao;
  final String? resultado;
  final DateTime? proximaData;
  final String? proximaAcao;
  const CrmContato({
    this.id,
    this.idCliente,
    this.idViewPessoaColaborador,
    this.tipoContato,
    this.horaContato,
    this.assunto,
    this.descricao,
    this.resultado,
    this.proximaData,
    this.proximaAcao,
  });
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || idCliente != null) {
      map['id_cliente'] = Variable<int>(idCliente);
    }
    if (!nullToAbsent || idViewPessoaColaborador != null) {
      map['id_view_pessoa_colaborador'] = Variable<int>(
        idViewPessoaColaborador,
      );
    }
    if (!nullToAbsent || tipoContato != null) {
      map['tipo_contato'] = Variable<String>(tipoContato);
    }
    if (!nullToAbsent || horaContato != null) {
      map['hora_contato'] = Variable<String>(horaContato);
    }
    if (!nullToAbsent || assunto != null) {
      map['assunto'] = Variable<String>(assunto);
    }
    if (!nullToAbsent || descricao != null) {
      map['descricao'] = Variable<String>(descricao);
    }
    if (!nullToAbsent || resultado != null) {
      map['resultado'] = Variable<String>(resultado);
    }
    if (!nullToAbsent || proximaData != null) {
      map['proxima_data'] = Variable<DateTime>(proximaData);
    }
    if (!nullToAbsent || proximaAcao != null) {
      map['proxima_acao'] = Variable<String>(proximaAcao);
    }
    return map;
  }

  factory CrmContato.fromJson(
    Map<String, dynamic> json, {
    ValueSerializer? serializer,
  }) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return CrmContato(
      id: serializer.fromJson<int?>(json['id']),
      idCliente: serializer.fromJson<int?>(json['idCliente']),
      idViewPessoaColaborador: serializer.fromJson<int?>(
        json['idViewPessoaColaborador'],
      ),
      tipoContato: serializer.fromJson<String?>(json['tipoContato']),
      horaContato: serializer.fromJson<String?>(json['horaContato']),
      assunto: serializer.fromJson<String?>(json['assunto']),
      descricao: serializer.fromJson<String?>(json['descricao']),
      resultado: serializer.fromJson<String?>(json['resultado']),
      proximaData: serializer.fromJson<DateTime?>(json['proximaData']),
      proximaAcao: serializer.fromJson<String?>(json['proximaAcao']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'idCliente': serializer.toJson<int?>(idCliente),
      'idViewPessoaColaborador': serializer.toJson<int?>(
        idViewPessoaColaborador,
      ),
      'tipoContato': serializer.toJson<String?>(tipoContato),
      'horaContato': serializer.toJson<String?>(horaContato),
      'assunto': serializer.toJson<String?>(assunto),
      'descricao': serializer.toJson<String?>(descricao),
      'resultado': serializer.toJson<String?>(resultado),
      'proximaData': serializer.toJson<DateTime?>(proximaData),
      'proximaAcao': serializer.toJson<String?>(proximaAcao),
    };
  }

  CrmContato copyWith({
    Value<int?> id = const Value.absent(),
    Value<int?> idCliente = const Value.absent(),
    Value<int?> idViewPessoaColaborador = const Value.absent(),
    Value<String?> tipoContato = const Value.absent(),
    Value<String?> horaContato = const Value.absent(),
    Value<String?> assunto = const Value.absent(),
    Value<String?> descricao = const Value.absent(),
    Value<String?> resultado = const Value.absent(),
    Value<DateTime?> proximaData = const Value.absent(),
    Value<String?> proximaAcao = const Value.absent(),
  }) => CrmContato(
    id: id.present ? id.value : this.id,
    idCliente: idCliente.present ? idCliente.value : this.idCliente,
    idViewPessoaColaborador:
        idViewPessoaColaborador.present
            ? idViewPessoaColaborador.value
            : this.idViewPessoaColaborador,
    tipoContato: tipoContato.present ? tipoContato.value : this.tipoContato,
    horaContato: horaContato.present ? horaContato.value : this.horaContato,
    assunto: assunto.present ? assunto.value : this.assunto,
    descricao: descricao.present ? descricao.value : this.descricao,
    resultado: resultado.present ? resultado.value : this.resultado,
    proximaData: proximaData.present ? proximaData.value : this.proximaData,
    proximaAcao: proximaAcao.present ? proximaAcao.value : this.proximaAcao,
  );
  CrmContato copyWithCompanion(CrmContatosCompanion data) {
    return CrmContato(
      id: data.id.present ? data.id.value : this.id,
      idCliente: data.idCliente.present ? data.idCliente.value : this.idCliente,
      idViewPessoaColaborador:
          data.idViewPessoaColaborador.present
              ? data.idViewPessoaColaborador.value
              : this.idViewPessoaColaborador,
      tipoContato:
          data.tipoContato.present ? data.tipoContato.value : this.tipoContato,
      horaContato:
          data.horaContato.present ? data.horaContato.value : this.horaContato,
      assunto: data.assunto.present ? data.assunto.value : this.assunto,
      descricao: data.descricao.present ? data.descricao.value : this.descricao,
      resultado: data.resultado.present ? data.resultado.value : this.resultado,
      proximaData:
          data.proximaData.present ? data.proximaData.value : this.proximaData,
      proximaAcao:
          data.proximaAcao.present ? data.proximaAcao.value : this.proximaAcao,
    );
  }

  @override
  String toString() {
    return (StringBuffer('CrmContato(')
          ..write('id: $id, ')
          ..write('idCliente: $idCliente, ')
          ..write('idViewPessoaColaborador: $idViewPessoaColaborador, ')
          ..write('tipoContato: $tipoContato, ')
          ..write('horaContato: $horaContato, ')
          ..write('assunto: $assunto, ')
          ..write('descricao: $descricao, ')
          ..write('resultado: $resultado, ')
          ..write('proximaData: $proximaData, ')
          ..write('proximaAcao: $proximaAcao')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(
    id,
    idCliente,
    idViewPessoaColaborador,
    tipoContato,
    horaContato,
    assunto,
    descricao,
    resultado,
    proximaData,
    proximaAcao,
  );
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is CrmContato &&
          other.id == this.id &&
          other.idCliente == this.idCliente &&
          other.idViewPessoaColaborador == this.idViewPessoaColaborador &&
          other.tipoContato == this.tipoContato &&
          other.horaContato == this.horaContato &&
          other.assunto == this.assunto &&
          other.descricao == this.descricao &&
          other.resultado == this.resultado &&
          other.proximaData == this.proximaData &&
          other.proximaAcao == this.proximaAcao);
}

class CrmContatosCompanion extends UpdateCompanion<CrmContato> {
  final Value<int?> id;
  final Value<int?> idCliente;
  final Value<int?> idViewPessoaColaborador;
  final Value<String?> tipoContato;
  final Value<String?> horaContato;
  final Value<String?> assunto;
  final Value<String?> descricao;
  final Value<String?> resultado;
  final Value<DateTime?> proximaData;
  final Value<String?> proximaAcao;
  const CrmContatosCompanion({
    this.id = const Value.absent(),
    this.idCliente = const Value.absent(),
    this.idViewPessoaColaborador = const Value.absent(),
    this.tipoContato = const Value.absent(),
    this.horaContato = const Value.absent(),
    this.assunto = const Value.absent(),
    this.descricao = const Value.absent(),
    this.resultado = const Value.absent(),
    this.proximaData = const Value.absent(),
    this.proximaAcao = const Value.absent(),
  });
  CrmContatosCompanion.insert({
    this.id = const Value.absent(),
    this.idCliente = const Value.absent(),
    this.idViewPessoaColaborador = const Value.absent(),
    this.tipoContato = const Value.absent(),
    this.horaContato = const Value.absent(),
    this.assunto = const Value.absent(),
    this.descricao = const Value.absent(),
    this.resultado = const Value.absent(),
    this.proximaData = const Value.absent(),
    this.proximaAcao = const Value.absent(),
  });
  static Insertable<CrmContato> custom({
    Expression<int>? id,
    Expression<int>? idCliente,
    Expression<int>? idViewPessoaColaborador,
    Expression<String>? tipoContato,
    Expression<String>? horaContato,
    Expression<String>? assunto,
    Expression<String>? descricao,
    Expression<String>? resultado,
    Expression<DateTime>? proximaData,
    Expression<String>? proximaAcao,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (idCliente != null) 'id_cliente': idCliente,
      if (idViewPessoaColaborador != null)
        'id_view_pessoa_colaborador': idViewPessoaColaborador,
      if (tipoContato != null) 'tipo_contato': tipoContato,
      if (horaContato != null) 'hora_contato': horaContato,
      if (assunto != null) 'assunto': assunto,
      if (descricao != null) 'descricao': descricao,
      if (resultado != null) 'resultado': resultado,
      if (proximaData != null) 'proxima_data': proximaData,
      if (proximaAcao != null) 'proxima_acao': proximaAcao,
    });
  }

  CrmContatosCompanion copyWith({
    Value<int?>? id,
    Value<int?>? idCliente,
    Value<int?>? idViewPessoaColaborador,
    Value<String?>? tipoContato,
    Value<String?>? horaContato,
    Value<String?>? assunto,
    Value<String?>? descricao,
    Value<String?>? resultado,
    Value<DateTime?>? proximaData,
    Value<String?>? proximaAcao,
  }) {
    return CrmContatosCompanion(
      id: id ?? this.id,
      idCliente: idCliente ?? this.idCliente,
      idViewPessoaColaborador:
          idViewPessoaColaborador ?? this.idViewPessoaColaborador,
      tipoContato: tipoContato ?? this.tipoContato,
      horaContato: horaContato ?? this.horaContato,
      assunto: assunto ?? this.assunto,
      descricao: descricao ?? this.descricao,
      resultado: resultado ?? this.resultado,
      proximaData: proximaData ?? this.proximaData,
      proximaAcao: proximaAcao ?? this.proximaAcao,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (idCliente.present) {
      map['id_cliente'] = Variable<int>(idCliente.value);
    }
    if (idViewPessoaColaborador.present) {
      map['id_view_pessoa_colaborador'] = Variable<int>(
        idViewPessoaColaborador.value,
      );
    }
    if (tipoContato.present) {
      map['tipo_contato'] = Variable<String>(tipoContato.value);
    }
    if (horaContato.present) {
      map['hora_contato'] = Variable<String>(horaContato.value);
    }
    if (assunto.present) {
      map['assunto'] = Variable<String>(assunto.value);
    }
    if (descricao.present) {
      map['descricao'] = Variable<String>(descricao.value);
    }
    if (resultado.present) {
      map['resultado'] = Variable<String>(resultado.value);
    }
    if (proximaData.present) {
      map['proxima_data'] = Variable<DateTime>(proximaData.value);
    }
    if (proximaAcao.present) {
      map['proxima_acao'] = Variable<String>(proximaAcao.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('CrmContatosCompanion(')
          ..write('id: $id, ')
          ..write('idCliente: $idCliente, ')
          ..write('idViewPessoaColaborador: $idViewPessoaColaborador, ')
          ..write('tipoContato: $tipoContato, ')
          ..write('horaContato: $horaContato, ')
          ..write('assunto: $assunto, ')
          ..write('descricao: $descricao, ')
          ..write('resultado: $resultado, ')
          ..write('proximaData: $proximaData, ')
          ..write('proximaAcao: $proximaAcao')
          ..write(')'))
        .toString();
  }
}

class $CrmOportunidadesTable extends CrmOportunidades
    with TableInfo<$CrmOportunidadesTable, CrmOportunidade> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $CrmOportunidadesTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
    'id',
    aliasedName,
    true,
    type: DriftSqlType.int,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _idClienteMeta = const VerificationMeta(
    'idCliente',
  );
  @override
  late final GeneratedColumn<int> idCliente = GeneratedColumn<int>(
    'id_cliente',
    aliasedName,
    true,
    type: DriftSqlType.int,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _idViewPessoaColaboradorMeta =
      const VerificationMeta('idViewPessoaColaborador');
  @override
  late final GeneratedColumn<int> idViewPessoaColaborador =
      GeneratedColumn<int>(
        'id_view_pessoa_colaborador',
        aliasedName,
        true,
        type: DriftSqlType.int,
        requiredDuringInsert: false,
      );
  static const VerificationMeta _tituloMeta = const VerificationMeta('titulo');
  @override
  late final GeneratedColumn<String> titulo = GeneratedColumn<String>(
    'titulo',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 200,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _descricaoMeta = const VerificationMeta(
    'descricao',
  );
  @override
  late final GeneratedColumn<String> descricao = GeneratedColumn<String>(
    'descricao',
    aliasedName,
    true,
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _valorEstimadoMeta = const VerificationMeta(
    'valorEstimado',
  );
  @override
  late final GeneratedColumn<double> valorEstimado = GeneratedColumn<double>(
    'valor_estimado',
    aliasedName,
    true,
    type: DriftSqlType.double,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _dataAberturaMeta = const VerificationMeta(
    'dataAbertura',
  );
  @override
  late final GeneratedColumn<DateTime> dataAbertura = GeneratedColumn<DateTime>(
    'data_abertura',
    aliasedName,
    true,
    type: DriftSqlType.dateTime,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _dataFechamentoPrevistoMeta =
      const VerificationMeta('dataFechamentoPrevisto');
  @override
  late final GeneratedColumn<DateTime> dataFechamentoPrevisto =
      GeneratedColumn<DateTime>(
        'data_fechamento_previsto',
        aliasedName,
        true,
        type: DriftSqlType.dateTime,
        requiredDuringInsert: false,
      );
  static const VerificationMeta _dataFechamentoRealMeta =
      const VerificationMeta('dataFechamentoReal');
  @override
  late final GeneratedColumn<DateTime> dataFechamentoReal =
      GeneratedColumn<DateTime>(
        'data_fechamento_real',
        aliasedName,
        true,
        type: DriftSqlType.dateTime,
        requiredDuringInsert: false,
      );
  static const VerificationMeta _statusMeta = const VerificationMeta('status');
  @override
  late final GeneratedColumn<String> status = GeneratedColumn<String>(
    'status',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 1,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _motivoFechamentoMeta = const VerificationMeta(
    'motivoFechamento',
  );
  @override
  late final GeneratedColumn<String> motivoFechamento = GeneratedColumn<String>(
    'motivo_fechamento',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 1,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _probabilidadeMeta = const VerificationMeta(
    'probabilidade',
  );
  @override
  late final GeneratedColumn<int> probabilidade = GeneratedColumn<int>(
    'probabilidade',
    aliasedName,
    true,
    type: DriftSqlType.int,
    requiredDuringInsert: false,
  );
  @override
  List<GeneratedColumn> get $columns => [
    id,
    idCliente,
    idViewPessoaColaborador,
    titulo,
    descricao,
    valorEstimado,
    dataAbertura,
    dataFechamentoPrevisto,
    dataFechamentoReal,
    status,
    motivoFechamento,
    probabilidade,
  ];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'crm_oportunidade';
  @override
  VerificationContext validateIntegrity(
    Insertable<CrmOportunidade> instance, {
    bool isInserting = false,
  }) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('id_cliente')) {
      context.handle(
        _idClienteMeta,
        idCliente.isAcceptableOrUnknown(data['id_cliente']!, _idClienteMeta),
      );
    }
    if (data.containsKey('id_view_pessoa_colaborador')) {
      context.handle(
        _idViewPessoaColaboradorMeta,
        idViewPessoaColaborador.isAcceptableOrUnknown(
          data['id_view_pessoa_colaborador']!,
          _idViewPessoaColaboradorMeta,
        ),
      );
    }
    if (data.containsKey('titulo')) {
      context.handle(
        _tituloMeta,
        titulo.isAcceptableOrUnknown(data['titulo']!, _tituloMeta),
      );
    }
    if (data.containsKey('descricao')) {
      context.handle(
        _descricaoMeta,
        descricao.isAcceptableOrUnknown(data['descricao']!, _descricaoMeta),
      );
    }
    if (data.containsKey('valor_estimado')) {
      context.handle(
        _valorEstimadoMeta,
        valorEstimado.isAcceptableOrUnknown(
          data['valor_estimado']!,
          _valorEstimadoMeta,
        ),
      );
    }
    if (data.containsKey('data_abertura')) {
      context.handle(
        _dataAberturaMeta,
        dataAbertura.isAcceptableOrUnknown(
          data['data_abertura']!,
          _dataAberturaMeta,
        ),
      );
    }
    if (data.containsKey('data_fechamento_previsto')) {
      context.handle(
        _dataFechamentoPrevistoMeta,
        dataFechamentoPrevisto.isAcceptableOrUnknown(
          data['data_fechamento_previsto']!,
          _dataFechamentoPrevistoMeta,
        ),
      );
    }
    if (data.containsKey('data_fechamento_real')) {
      context.handle(
        _dataFechamentoRealMeta,
        dataFechamentoReal.isAcceptableOrUnknown(
          data['data_fechamento_real']!,
          _dataFechamentoRealMeta,
        ),
      );
    }
    if (data.containsKey('status')) {
      context.handle(
        _statusMeta,
        status.isAcceptableOrUnknown(data['status']!, _statusMeta),
      );
    }
    if (data.containsKey('motivo_fechamento')) {
      context.handle(
        _motivoFechamentoMeta,
        motivoFechamento.isAcceptableOrUnknown(
          data['motivo_fechamento']!,
          _motivoFechamentoMeta,
        ),
      );
    }
    if (data.containsKey('probabilidade')) {
      context.handle(
        _probabilidadeMeta,
        probabilidade.isAcceptableOrUnknown(
          data['probabilidade']!,
          _probabilidadeMeta,
        ),
      );
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  CrmOportunidade map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return CrmOportunidade(
      id: attachedDatabase.typeMapping.read(
        DriftSqlType.int,
        data['${effectivePrefix}id'],
      ),
      idCliente: attachedDatabase.typeMapping.read(
        DriftSqlType.int,
        data['${effectivePrefix}id_cliente'],
      ),
      idViewPessoaColaborador: attachedDatabase.typeMapping.read(
        DriftSqlType.int,
        data['${effectivePrefix}id_view_pessoa_colaborador'],
      ),
      titulo: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}titulo'],
      ),
      descricao: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}descricao'],
      ),
      valorEstimado: attachedDatabase.typeMapping.read(
        DriftSqlType.double,
        data['${effectivePrefix}valor_estimado'],
      ),
      dataAbertura: attachedDatabase.typeMapping.read(
        DriftSqlType.dateTime,
        data['${effectivePrefix}data_abertura'],
      ),
      dataFechamentoPrevisto: attachedDatabase.typeMapping.read(
        DriftSqlType.dateTime,
        data['${effectivePrefix}data_fechamento_previsto'],
      ),
      dataFechamentoReal: attachedDatabase.typeMapping.read(
        DriftSqlType.dateTime,
        data['${effectivePrefix}data_fechamento_real'],
      ),
      status: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}status'],
      ),
      motivoFechamento: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}motivo_fechamento'],
      ),
      probabilidade: attachedDatabase.typeMapping.read(
        DriftSqlType.int,
        data['${effectivePrefix}probabilidade'],
      ),
    );
  }

  @override
  $CrmOportunidadesTable createAlias(String alias) {
    return $CrmOportunidadesTable(attachedDatabase, alias);
  }
}

class CrmOportunidade extends DataClass implements Insertable<CrmOportunidade> {
  final int? id;
  final int? idCliente;
  final int? idViewPessoaColaborador;
  final String? titulo;
  final String? descricao;
  final double? valorEstimado;
  final DateTime? dataAbertura;
  final DateTime? dataFechamentoPrevisto;
  final DateTime? dataFechamentoReal;
  final String? status;
  final String? motivoFechamento;
  final int? probabilidade;
  const CrmOportunidade({
    this.id,
    this.idCliente,
    this.idViewPessoaColaborador,
    this.titulo,
    this.descricao,
    this.valorEstimado,
    this.dataAbertura,
    this.dataFechamentoPrevisto,
    this.dataFechamentoReal,
    this.status,
    this.motivoFechamento,
    this.probabilidade,
  });
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || idCliente != null) {
      map['id_cliente'] = Variable<int>(idCliente);
    }
    if (!nullToAbsent || idViewPessoaColaborador != null) {
      map['id_view_pessoa_colaborador'] = Variable<int>(
        idViewPessoaColaborador,
      );
    }
    if (!nullToAbsent || titulo != null) {
      map['titulo'] = Variable<String>(titulo);
    }
    if (!nullToAbsent || descricao != null) {
      map['descricao'] = Variable<String>(descricao);
    }
    if (!nullToAbsent || valorEstimado != null) {
      map['valor_estimado'] = Variable<double>(valorEstimado);
    }
    if (!nullToAbsent || dataAbertura != null) {
      map['data_abertura'] = Variable<DateTime>(dataAbertura);
    }
    if (!nullToAbsent || dataFechamentoPrevisto != null) {
      map['data_fechamento_previsto'] = Variable<DateTime>(
        dataFechamentoPrevisto,
      );
    }
    if (!nullToAbsent || dataFechamentoReal != null) {
      map['data_fechamento_real'] = Variable<DateTime>(dataFechamentoReal);
    }
    if (!nullToAbsent || status != null) {
      map['status'] = Variable<String>(status);
    }
    if (!nullToAbsent || motivoFechamento != null) {
      map['motivo_fechamento'] = Variable<String>(motivoFechamento);
    }
    if (!nullToAbsent || probabilidade != null) {
      map['probabilidade'] = Variable<int>(probabilidade);
    }
    return map;
  }

  factory CrmOportunidade.fromJson(
    Map<String, dynamic> json, {
    ValueSerializer? serializer,
  }) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return CrmOportunidade(
      id: serializer.fromJson<int?>(json['id']),
      idCliente: serializer.fromJson<int?>(json['idCliente']),
      idViewPessoaColaborador: serializer.fromJson<int?>(
        json['idViewPessoaColaborador'],
      ),
      titulo: serializer.fromJson<String?>(json['titulo']),
      descricao: serializer.fromJson<String?>(json['descricao']),
      valorEstimado: serializer.fromJson<double?>(json['valorEstimado']),
      dataAbertura: serializer.fromJson<DateTime?>(json['dataAbertura']),
      dataFechamentoPrevisto: serializer.fromJson<DateTime?>(
        json['dataFechamentoPrevisto'],
      ),
      dataFechamentoReal: serializer.fromJson<DateTime?>(
        json['dataFechamentoReal'],
      ),
      status: serializer.fromJson<String?>(json['status']),
      motivoFechamento: serializer.fromJson<String?>(json['motivoFechamento']),
      probabilidade: serializer.fromJson<int?>(json['probabilidade']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'idCliente': serializer.toJson<int?>(idCliente),
      'idViewPessoaColaborador': serializer.toJson<int?>(
        idViewPessoaColaborador,
      ),
      'titulo': serializer.toJson<String?>(titulo),
      'descricao': serializer.toJson<String?>(descricao),
      'valorEstimado': serializer.toJson<double?>(valorEstimado),
      'dataAbertura': serializer.toJson<DateTime?>(dataAbertura),
      'dataFechamentoPrevisto': serializer.toJson<DateTime?>(
        dataFechamentoPrevisto,
      ),
      'dataFechamentoReal': serializer.toJson<DateTime?>(dataFechamentoReal),
      'status': serializer.toJson<String?>(status),
      'motivoFechamento': serializer.toJson<String?>(motivoFechamento),
      'probabilidade': serializer.toJson<int?>(probabilidade),
    };
  }

  CrmOportunidade copyWith({
    Value<int?> id = const Value.absent(),
    Value<int?> idCliente = const Value.absent(),
    Value<int?> idViewPessoaColaborador = const Value.absent(),
    Value<String?> titulo = const Value.absent(),
    Value<String?> descricao = const Value.absent(),
    Value<double?> valorEstimado = const Value.absent(),
    Value<DateTime?> dataAbertura = const Value.absent(),
    Value<DateTime?> dataFechamentoPrevisto = const Value.absent(),
    Value<DateTime?> dataFechamentoReal = const Value.absent(),
    Value<String?> status = const Value.absent(),
    Value<String?> motivoFechamento = const Value.absent(),
    Value<int?> probabilidade = const Value.absent(),
  }) => CrmOportunidade(
    id: id.present ? id.value : this.id,
    idCliente: idCliente.present ? idCliente.value : this.idCliente,
    idViewPessoaColaborador:
        idViewPessoaColaborador.present
            ? idViewPessoaColaborador.value
            : this.idViewPessoaColaborador,
    titulo: titulo.present ? titulo.value : this.titulo,
    descricao: descricao.present ? descricao.value : this.descricao,
    valorEstimado:
        valorEstimado.present ? valorEstimado.value : this.valorEstimado,
    dataAbertura: dataAbertura.present ? dataAbertura.value : this.dataAbertura,
    dataFechamentoPrevisto:
        dataFechamentoPrevisto.present
            ? dataFechamentoPrevisto.value
            : this.dataFechamentoPrevisto,
    dataFechamentoReal:
        dataFechamentoReal.present
            ? dataFechamentoReal.value
            : this.dataFechamentoReal,
    status: status.present ? status.value : this.status,
    motivoFechamento:
        motivoFechamento.present
            ? motivoFechamento.value
            : this.motivoFechamento,
    probabilidade:
        probabilidade.present ? probabilidade.value : this.probabilidade,
  );
  CrmOportunidade copyWithCompanion(CrmOportunidadesCompanion data) {
    return CrmOportunidade(
      id: data.id.present ? data.id.value : this.id,
      idCliente: data.idCliente.present ? data.idCliente.value : this.idCliente,
      idViewPessoaColaborador:
          data.idViewPessoaColaborador.present
              ? data.idViewPessoaColaborador.value
              : this.idViewPessoaColaborador,
      titulo: data.titulo.present ? data.titulo.value : this.titulo,
      descricao: data.descricao.present ? data.descricao.value : this.descricao,
      valorEstimado:
          data.valorEstimado.present
              ? data.valorEstimado.value
              : this.valorEstimado,
      dataAbertura:
          data.dataAbertura.present
              ? data.dataAbertura.value
              : this.dataAbertura,
      dataFechamentoPrevisto:
          data.dataFechamentoPrevisto.present
              ? data.dataFechamentoPrevisto.value
              : this.dataFechamentoPrevisto,
      dataFechamentoReal:
          data.dataFechamentoReal.present
              ? data.dataFechamentoReal.value
              : this.dataFechamentoReal,
      status: data.status.present ? data.status.value : this.status,
      motivoFechamento:
          data.motivoFechamento.present
              ? data.motivoFechamento.value
              : this.motivoFechamento,
      probabilidade:
          data.probabilidade.present
              ? data.probabilidade.value
              : this.probabilidade,
    );
  }

  @override
  String toString() {
    return (StringBuffer('CrmOportunidade(')
          ..write('id: $id, ')
          ..write('idCliente: $idCliente, ')
          ..write('idViewPessoaColaborador: $idViewPessoaColaborador, ')
          ..write('titulo: $titulo, ')
          ..write('descricao: $descricao, ')
          ..write('valorEstimado: $valorEstimado, ')
          ..write('dataAbertura: $dataAbertura, ')
          ..write('dataFechamentoPrevisto: $dataFechamentoPrevisto, ')
          ..write('dataFechamentoReal: $dataFechamentoReal, ')
          ..write('status: $status, ')
          ..write('motivoFechamento: $motivoFechamento, ')
          ..write('probabilidade: $probabilidade')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(
    id,
    idCliente,
    idViewPessoaColaborador,
    titulo,
    descricao,
    valorEstimado,
    dataAbertura,
    dataFechamentoPrevisto,
    dataFechamentoReal,
    status,
    motivoFechamento,
    probabilidade,
  );
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is CrmOportunidade &&
          other.id == this.id &&
          other.idCliente == this.idCliente &&
          other.idViewPessoaColaborador == this.idViewPessoaColaborador &&
          other.titulo == this.titulo &&
          other.descricao == this.descricao &&
          other.valorEstimado == this.valorEstimado &&
          other.dataAbertura == this.dataAbertura &&
          other.dataFechamentoPrevisto == this.dataFechamentoPrevisto &&
          other.dataFechamentoReal == this.dataFechamentoReal &&
          other.status == this.status &&
          other.motivoFechamento == this.motivoFechamento &&
          other.probabilidade == this.probabilidade);
}

class CrmOportunidadesCompanion extends UpdateCompanion<CrmOportunidade> {
  final Value<int?> id;
  final Value<int?> idCliente;
  final Value<int?> idViewPessoaColaborador;
  final Value<String?> titulo;
  final Value<String?> descricao;
  final Value<double?> valorEstimado;
  final Value<DateTime?> dataAbertura;
  final Value<DateTime?> dataFechamentoPrevisto;
  final Value<DateTime?> dataFechamentoReal;
  final Value<String?> status;
  final Value<String?> motivoFechamento;
  final Value<int?> probabilidade;
  const CrmOportunidadesCompanion({
    this.id = const Value.absent(),
    this.idCliente = const Value.absent(),
    this.idViewPessoaColaborador = const Value.absent(),
    this.titulo = const Value.absent(),
    this.descricao = const Value.absent(),
    this.valorEstimado = const Value.absent(),
    this.dataAbertura = const Value.absent(),
    this.dataFechamentoPrevisto = const Value.absent(),
    this.dataFechamentoReal = const Value.absent(),
    this.status = const Value.absent(),
    this.motivoFechamento = const Value.absent(),
    this.probabilidade = const Value.absent(),
  });
  CrmOportunidadesCompanion.insert({
    this.id = const Value.absent(),
    this.idCliente = const Value.absent(),
    this.idViewPessoaColaborador = const Value.absent(),
    this.titulo = const Value.absent(),
    this.descricao = const Value.absent(),
    this.valorEstimado = const Value.absent(),
    this.dataAbertura = const Value.absent(),
    this.dataFechamentoPrevisto = const Value.absent(),
    this.dataFechamentoReal = const Value.absent(),
    this.status = const Value.absent(),
    this.motivoFechamento = const Value.absent(),
    this.probabilidade = const Value.absent(),
  });
  static Insertable<CrmOportunidade> custom({
    Expression<int>? id,
    Expression<int>? idCliente,
    Expression<int>? idViewPessoaColaborador,
    Expression<String>? titulo,
    Expression<String>? descricao,
    Expression<double>? valorEstimado,
    Expression<DateTime>? dataAbertura,
    Expression<DateTime>? dataFechamentoPrevisto,
    Expression<DateTime>? dataFechamentoReal,
    Expression<String>? status,
    Expression<String>? motivoFechamento,
    Expression<int>? probabilidade,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (idCliente != null) 'id_cliente': idCliente,
      if (idViewPessoaColaborador != null)
        'id_view_pessoa_colaborador': idViewPessoaColaborador,
      if (titulo != null) 'titulo': titulo,
      if (descricao != null) 'descricao': descricao,
      if (valorEstimado != null) 'valor_estimado': valorEstimado,
      if (dataAbertura != null) 'data_abertura': dataAbertura,
      if (dataFechamentoPrevisto != null)
        'data_fechamento_previsto': dataFechamentoPrevisto,
      if (dataFechamentoReal != null)
        'data_fechamento_real': dataFechamentoReal,
      if (status != null) 'status': status,
      if (motivoFechamento != null) 'motivo_fechamento': motivoFechamento,
      if (probabilidade != null) 'probabilidade': probabilidade,
    });
  }

  CrmOportunidadesCompanion copyWith({
    Value<int?>? id,
    Value<int?>? idCliente,
    Value<int?>? idViewPessoaColaborador,
    Value<String?>? titulo,
    Value<String?>? descricao,
    Value<double?>? valorEstimado,
    Value<DateTime?>? dataAbertura,
    Value<DateTime?>? dataFechamentoPrevisto,
    Value<DateTime?>? dataFechamentoReal,
    Value<String?>? status,
    Value<String?>? motivoFechamento,
    Value<int?>? probabilidade,
  }) {
    return CrmOportunidadesCompanion(
      id: id ?? this.id,
      idCliente: idCliente ?? this.idCliente,
      idViewPessoaColaborador:
          idViewPessoaColaborador ?? this.idViewPessoaColaborador,
      titulo: titulo ?? this.titulo,
      descricao: descricao ?? this.descricao,
      valorEstimado: valorEstimado ?? this.valorEstimado,
      dataAbertura: dataAbertura ?? this.dataAbertura,
      dataFechamentoPrevisto:
          dataFechamentoPrevisto ?? this.dataFechamentoPrevisto,
      dataFechamentoReal: dataFechamentoReal ?? this.dataFechamentoReal,
      status: status ?? this.status,
      motivoFechamento: motivoFechamento ?? this.motivoFechamento,
      probabilidade: probabilidade ?? this.probabilidade,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (idCliente.present) {
      map['id_cliente'] = Variable<int>(idCliente.value);
    }
    if (idViewPessoaColaborador.present) {
      map['id_view_pessoa_colaborador'] = Variable<int>(
        idViewPessoaColaborador.value,
      );
    }
    if (titulo.present) {
      map['titulo'] = Variable<String>(titulo.value);
    }
    if (descricao.present) {
      map['descricao'] = Variable<String>(descricao.value);
    }
    if (valorEstimado.present) {
      map['valor_estimado'] = Variable<double>(valorEstimado.value);
    }
    if (dataAbertura.present) {
      map['data_abertura'] = Variable<DateTime>(dataAbertura.value);
    }
    if (dataFechamentoPrevisto.present) {
      map['data_fechamento_previsto'] = Variable<DateTime>(
        dataFechamentoPrevisto.value,
      );
    }
    if (dataFechamentoReal.present) {
      map['data_fechamento_real'] = Variable<DateTime>(
        dataFechamentoReal.value,
      );
    }
    if (status.present) {
      map['status'] = Variable<String>(status.value);
    }
    if (motivoFechamento.present) {
      map['motivo_fechamento'] = Variable<String>(motivoFechamento.value);
    }
    if (probabilidade.present) {
      map['probabilidade'] = Variable<int>(probabilidade.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('CrmOportunidadesCompanion(')
          ..write('id: $id, ')
          ..write('idCliente: $idCliente, ')
          ..write('idViewPessoaColaborador: $idViewPessoaColaborador, ')
          ..write('titulo: $titulo, ')
          ..write('descricao: $descricao, ')
          ..write('valorEstimado: $valorEstimado, ')
          ..write('dataAbertura: $dataAbertura, ')
          ..write('dataFechamentoPrevisto: $dataFechamentoPrevisto, ')
          ..write('dataFechamentoReal: $dataFechamentoReal, ')
          ..write('status: $status, ')
          ..write('motivoFechamento: $motivoFechamento, ')
          ..write('probabilidade: $probabilidade')
          ..write(')'))
        .toString();
  }
}

class $CrmTarefasTable extends CrmTarefas
    with TableInfo<$CrmTarefasTable, CrmTarefa> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $CrmTarefasTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
    'id',
    aliasedName,
    true,
    type: DriftSqlType.int,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _idClienteMeta = const VerificationMeta(
    'idCliente',
  );
  @override
  late final GeneratedColumn<int> idCliente = GeneratedColumn<int>(
    'id_cliente',
    aliasedName,
    true,
    type: DriftSqlType.int,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _idOportunidadeMeta = const VerificationMeta(
    'idOportunidade',
  );
  @override
  late final GeneratedColumn<int> idOportunidade = GeneratedColumn<int>(
    'id_oportunidade',
    aliasedName,
    true,
    type: DriftSqlType.int,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _tituloMeta = const VerificationMeta('titulo');
  @override
  late final GeneratedColumn<String> titulo = GeneratedColumn<String>(
    'titulo',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 200,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _descricaoMeta = const VerificationMeta(
    'descricao',
  );
  @override
  late final GeneratedColumn<String> descricao = GeneratedColumn<String>(
    'descricao',
    aliasedName,
    true,
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _prioridadeMeta = const VerificationMeta(
    'prioridade',
  );
  @override
  late final GeneratedColumn<String> prioridade = GeneratedColumn<String>(
    'prioridade',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 1,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _dataCriacaoMeta = const VerificationMeta(
    'dataCriacao',
  );
  @override
  late final GeneratedColumn<DateTime> dataCriacao = GeneratedColumn<DateTime>(
    'data_criacao',
    aliasedName,
    true,
    type: DriftSqlType.dateTime,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _dataVencimentoMeta = const VerificationMeta(
    'dataVencimento',
  );
  @override
  late final GeneratedColumn<DateTime> dataVencimento =
      GeneratedColumn<DateTime>(
        'data_vencimento',
        aliasedName,
        true,
        type: DriftSqlType.dateTime,
        requiredDuringInsert: false,
      );
  static const VerificationMeta _dataConclusaoMeta = const VerificationMeta(
    'dataConclusao',
  );
  @override
  late final GeneratedColumn<DateTime> dataConclusao =
      GeneratedColumn<DateTime>(
        'data_conclusao',
        aliasedName,
        true,
        type: DriftSqlType.dateTime,
        requiredDuringInsert: false,
      );
  static const VerificationMeta _statusMeta = const VerificationMeta('status');
  @override
  late final GeneratedColumn<String> status = GeneratedColumn<String>(
    'status',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 1,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  @override
  List<GeneratedColumn> get $columns => [
    id,
    idCliente,
    idOportunidade,
    titulo,
    descricao,
    prioridade,
    dataCriacao,
    dataVencimento,
    dataConclusao,
    status,
  ];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'crm_tarefa';
  @override
  VerificationContext validateIntegrity(
    Insertable<CrmTarefa> instance, {
    bool isInserting = false,
  }) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('id_cliente')) {
      context.handle(
        _idClienteMeta,
        idCliente.isAcceptableOrUnknown(data['id_cliente']!, _idClienteMeta),
      );
    }
    if (data.containsKey('id_oportunidade')) {
      context.handle(
        _idOportunidadeMeta,
        idOportunidade.isAcceptableOrUnknown(
          data['id_oportunidade']!,
          _idOportunidadeMeta,
        ),
      );
    }
    if (data.containsKey('titulo')) {
      context.handle(
        _tituloMeta,
        titulo.isAcceptableOrUnknown(data['titulo']!, _tituloMeta),
      );
    }
    if (data.containsKey('descricao')) {
      context.handle(
        _descricaoMeta,
        descricao.isAcceptableOrUnknown(data['descricao']!, _descricaoMeta),
      );
    }
    if (data.containsKey('prioridade')) {
      context.handle(
        _prioridadeMeta,
        prioridade.isAcceptableOrUnknown(data['prioridade']!, _prioridadeMeta),
      );
    }
    if (data.containsKey('data_criacao')) {
      context.handle(
        _dataCriacaoMeta,
        dataCriacao.isAcceptableOrUnknown(
          data['data_criacao']!,
          _dataCriacaoMeta,
        ),
      );
    }
    if (data.containsKey('data_vencimento')) {
      context.handle(
        _dataVencimentoMeta,
        dataVencimento.isAcceptableOrUnknown(
          data['data_vencimento']!,
          _dataVencimentoMeta,
        ),
      );
    }
    if (data.containsKey('data_conclusao')) {
      context.handle(
        _dataConclusaoMeta,
        dataConclusao.isAcceptableOrUnknown(
          data['data_conclusao']!,
          _dataConclusaoMeta,
        ),
      );
    }
    if (data.containsKey('status')) {
      context.handle(
        _statusMeta,
        status.isAcceptableOrUnknown(data['status']!, _statusMeta),
      );
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  CrmTarefa map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return CrmTarefa(
      id: attachedDatabase.typeMapping.read(
        DriftSqlType.int,
        data['${effectivePrefix}id'],
      ),
      idCliente: attachedDatabase.typeMapping.read(
        DriftSqlType.int,
        data['${effectivePrefix}id_cliente'],
      ),
      idOportunidade: attachedDatabase.typeMapping.read(
        DriftSqlType.int,
        data['${effectivePrefix}id_oportunidade'],
      ),
      titulo: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}titulo'],
      ),
      descricao: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}descricao'],
      ),
      prioridade: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}prioridade'],
      ),
      dataCriacao: attachedDatabase.typeMapping.read(
        DriftSqlType.dateTime,
        data['${effectivePrefix}data_criacao'],
      ),
      dataVencimento: attachedDatabase.typeMapping.read(
        DriftSqlType.dateTime,
        data['${effectivePrefix}data_vencimento'],
      ),
      dataConclusao: attachedDatabase.typeMapping.read(
        DriftSqlType.dateTime,
        data['${effectivePrefix}data_conclusao'],
      ),
      status: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}status'],
      ),
    );
  }

  @override
  $CrmTarefasTable createAlias(String alias) {
    return $CrmTarefasTable(attachedDatabase, alias);
  }
}

class CrmTarefa extends DataClass implements Insertable<CrmTarefa> {
  final int? id;
  final int? idCliente;
  final int? idOportunidade;
  final String? titulo;
  final String? descricao;
  final String? prioridade;
  final DateTime? dataCriacao;
  final DateTime? dataVencimento;
  final DateTime? dataConclusao;
  final String? status;
  const CrmTarefa({
    this.id,
    this.idCliente,
    this.idOportunidade,
    this.titulo,
    this.descricao,
    this.prioridade,
    this.dataCriacao,
    this.dataVencimento,
    this.dataConclusao,
    this.status,
  });
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || idCliente != null) {
      map['id_cliente'] = Variable<int>(idCliente);
    }
    if (!nullToAbsent || idOportunidade != null) {
      map['id_oportunidade'] = Variable<int>(idOportunidade);
    }
    if (!nullToAbsent || titulo != null) {
      map['titulo'] = Variable<String>(titulo);
    }
    if (!nullToAbsent || descricao != null) {
      map['descricao'] = Variable<String>(descricao);
    }
    if (!nullToAbsent || prioridade != null) {
      map['prioridade'] = Variable<String>(prioridade);
    }
    if (!nullToAbsent || dataCriacao != null) {
      map['data_criacao'] = Variable<DateTime>(dataCriacao);
    }
    if (!nullToAbsent || dataVencimento != null) {
      map['data_vencimento'] = Variable<DateTime>(dataVencimento);
    }
    if (!nullToAbsent || dataConclusao != null) {
      map['data_conclusao'] = Variable<DateTime>(dataConclusao);
    }
    if (!nullToAbsent || status != null) {
      map['status'] = Variable<String>(status);
    }
    return map;
  }

  factory CrmTarefa.fromJson(
    Map<String, dynamic> json, {
    ValueSerializer? serializer,
  }) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return CrmTarefa(
      id: serializer.fromJson<int?>(json['id']),
      idCliente: serializer.fromJson<int?>(json['idCliente']),
      idOportunidade: serializer.fromJson<int?>(json['idOportunidade']),
      titulo: serializer.fromJson<String?>(json['titulo']),
      descricao: serializer.fromJson<String?>(json['descricao']),
      prioridade: serializer.fromJson<String?>(json['prioridade']),
      dataCriacao: serializer.fromJson<DateTime?>(json['dataCriacao']),
      dataVencimento: serializer.fromJson<DateTime?>(json['dataVencimento']),
      dataConclusao: serializer.fromJson<DateTime?>(json['dataConclusao']),
      status: serializer.fromJson<String?>(json['status']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'idCliente': serializer.toJson<int?>(idCliente),
      'idOportunidade': serializer.toJson<int?>(idOportunidade),
      'titulo': serializer.toJson<String?>(titulo),
      'descricao': serializer.toJson<String?>(descricao),
      'prioridade': serializer.toJson<String?>(prioridade),
      'dataCriacao': serializer.toJson<DateTime?>(dataCriacao),
      'dataVencimento': serializer.toJson<DateTime?>(dataVencimento),
      'dataConclusao': serializer.toJson<DateTime?>(dataConclusao),
      'status': serializer.toJson<String?>(status),
    };
  }

  CrmTarefa copyWith({
    Value<int?> id = const Value.absent(),
    Value<int?> idCliente = const Value.absent(),
    Value<int?> idOportunidade = const Value.absent(),
    Value<String?> titulo = const Value.absent(),
    Value<String?> descricao = const Value.absent(),
    Value<String?> prioridade = const Value.absent(),
    Value<DateTime?> dataCriacao = const Value.absent(),
    Value<DateTime?> dataVencimento = const Value.absent(),
    Value<DateTime?> dataConclusao = const Value.absent(),
    Value<String?> status = const Value.absent(),
  }) => CrmTarefa(
    id: id.present ? id.value : this.id,
    idCliente: idCliente.present ? idCliente.value : this.idCliente,
    idOportunidade:
        idOportunidade.present ? idOportunidade.value : this.idOportunidade,
    titulo: titulo.present ? titulo.value : this.titulo,
    descricao: descricao.present ? descricao.value : this.descricao,
    prioridade: prioridade.present ? prioridade.value : this.prioridade,
    dataCriacao: dataCriacao.present ? dataCriacao.value : this.dataCriacao,
    dataVencimento:
        dataVencimento.present ? dataVencimento.value : this.dataVencimento,
    dataConclusao:
        dataConclusao.present ? dataConclusao.value : this.dataConclusao,
    status: status.present ? status.value : this.status,
  );
  CrmTarefa copyWithCompanion(CrmTarefasCompanion data) {
    return CrmTarefa(
      id: data.id.present ? data.id.value : this.id,
      idCliente: data.idCliente.present ? data.idCliente.value : this.idCliente,
      idOportunidade:
          data.idOportunidade.present
              ? data.idOportunidade.value
              : this.idOportunidade,
      titulo: data.titulo.present ? data.titulo.value : this.titulo,
      descricao: data.descricao.present ? data.descricao.value : this.descricao,
      prioridade:
          data.prioridade.present ? data.prioridade.value : this.prioridade,
      dataCriacao:
          data.dataCriacao.present ? data.dataCriacao.value : this.dataCriacao,
      dataVencimento:
          data.dataVencimento.present
              ? data.dataVencimento.value
              : this.dataVencimento,
      dataConclusao:
          data.dataConclusao.present
              ? data.dataConclusao.value
              : this.dataConclusao,
      status: data.status.present ? data.status.value : this.status,
    );
  }

  @override
  String toString() {
    return (StringBuffer('CrmTarefa(')
          ..write('id: $id, ')
          ..write('idCliente: $idCliente, ')
          ..write('idOportunidade: $idOportunidade, ')
          ..write('titulo: $titulo, ')
          ..write('descricao: $descricao, ')
          ..write('prioridade: $prioridade, ')
          ..write('dataCriacao: $dataCriacao, ')
          ..write('dataVencimento: $dataVencimento, ')
          ..write('dataConclusao: $dataConclusao, ')
          ..write('status: $status')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(
    id,
    idCliente,
    idOportunidade,
    titulo,
    descricao,
    prioridade,
    dataCriacao,
    dataVencimento,
    dataConclusao,
    status,
  );
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is CrmTarefa &&
          other.id == this.id &&
          other.idCliente == this.idCliente &&
          other.idOportunidade == this.idOportunidade &&
          other.titulo == this.titulo &&
          other.descricao == this.descricao &&
          other.prioridade == this.prioridade &&
          other.dataCriacao == this.dataCriacao &&
          other.dataVencimento == this.dataVencimento &&
          other.dataConclusao == this.dataConclusao &&
          other.status == this.status);
}

class CrmTarefasCompanion extends UpdateCompanion<CrmTarefa> {
  final Value<int?> id;
  final Value<int?> idCliente;
  final Value<int?> idOportunidade;
  final Value<String?> titulo;
  final Value<String?> descricao;
  final Value<String?> prioridade;
  final Value<DateTime?> dataCriacao;
  final Value<DateTime?> dataVencimento;
  final Value<DateTime?> dataConclusao;
  final Value<String?> status;
  const CrmTarefasCompanion({
    this.id = const Value.absent(),
    this.idCliente = const Value.absent(),
    this.idOportunidade = const Value.absent(),
    this.titulo = const Value.absent(),
    this.descricao = const Value.absent(),
    this.prioridade = const Value.absent(),
    this.dataCriacao = const Value.absent(),
    this.dataVencimento = const Value.absent(),
    this.dataConclusao = const Value.absent(),
    this.status = const Value.absent(),
  });
  CrmTarefasCompanion.insert({
    this.id = const Value.absent(),
    this.idCliente = const Value.absent(),
    this.idOportunidade = const Value.absent(),
    this.titulo = const Value.absent(),
    this.descricao = const Value.absent(),
    this.prioridade = const Value.absent(),
    this.dataCriacao = const Value.absent(),
    this.dataVencimento = const Value.absent(),
    this.dataConclusao = const Value.absent(),
    this.status = const Value.absent(),
  });
  static Insertable<CrmTarefa> custom({
    Expression<int>? id,
    Expression<int>? idCliente,
    Expression<int>? idOportunidade,
    Expression<String>? titulo,
    Expression<String>? descricao,
    Expression<String>? prioridade,
    Expression<DateTime>? dataCriacao,
    Expression<DateTime>? dataVencimento,
    Expression<DateTime>? dataConclusao,
    Expression<String>? status,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (idCliente != null) 'id_cliente': idCliente,
      if (idOportunidade != null) 'id_oportunidade': idOportunidade,
      if (titulo != null) 'titulo': titulo,
      if (descricao != null) 'descricao': descricao,
      if (prioridade != null) 'prioridade': prioridade,
      if (dataCriacao != null) 'data_criacao': dataCriacao,
      if (dataVencimento != null) 'data_vencimento': dataVencimento,
      if (dataConclusao != null) 'data_conclusao': dataConclusao,
      if (status != null) 'status': status,
    });
  }

  CrmTarefasCompanion copyWith({
    Value<int?>? id,
    Value<int?>? idCliente,
    Value<int?>? idOportunidade,
    Value<String?>? titulo,
    Value<String?>? descricao,
    Value<String?>? prioridade,
    Value<DateTime?>? dataCriacao,
    Value<DateTime?>? dataVencimento,
    Value<DateTime?>? dataConclusao,
    Value<String?>? status,
  }) {
    return CrmTarefasCompanion(
      id: id ?? this.id,
      idCliente: idCliente ?? this.idCliente,
      idOportunidade: idOportunidade ?? this.idOportunidade,
      titulo: titulo ?? this.titulo,
      descricao: descricao ?? this.descricao,
      prioridade: prioridade ?? this.prioridade,
      dataCriacao: dataCriacao ?? this.dataCriacao,
      dataVencimento: dataVencimento ?? this.dataVencimento,
      dataConclusao: dataConclusao ?? this.dataConclusao,
      status: status ?? this.status,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (idCliente.present) {
      map['id_cliente'] = Variable<int>(idCliente.value);
    }
    if (idOportunidade.present) {
      map['id_oportunidade'] = Variable<int>(idOportunidade.value);
    }
    if (titulo.present) {
      map['titulo'] = Variable<String>(titulo.value);
    }
    if (descricao.present) {
      map['descricao'] = Variable<String>(descricao.value);
    }
    if (prioridade.present) {
      map['prioridade'] = Variable<String>(prioridade.value);
    }
    if (dataCriacao.present) {
      map['data_criacao'] = Variable<DateTime>(dataCriacao.value);
    }
    if (dataVencimento.present) {
      map['data_vencimento'] = Variable<DateTime>(dataVencimento.value);
    }
    if (dataConclusao.present) {
      map['data_conclusao'] = Variable<DateTime>(dataConclusao.value);
    }
    if (status.present) {
      map['status'] = Variable<String>(status.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('CrmTarefasCompanion(')
          ..write('id: $id, ')
          ..write('idCliente: $idCliente, ')
          ..write('idOportunidade: $idOportunidade, ')
          ..write('titulo: $titulo, ')
          ..write('descricao: $descricao, ')
          ..write('prioridade: $prioridade, ')
          ..write('dataCriacao: $dataCriacao, ')
          ..write('dataVencimento: $dataVencimento, ')
          ..write('dataConclusao: $dataConclusao, ')
          ..write('status: $status')
          ..write(')'))
        .toString();
  }
}

abstract class _$AppDatabase extends GeneratedDatabase {
  _$AppDatabase(QueryExecutor e) : super(e);
  $AppDatabaseManager get managers => $AppDatabaseManager(this);
  late final $CrmSacDetalhesTable crmSacDetalhes = $CrmSacDetalhesTable(this);
  late final $CrmCarteiraClientesTable crmCarteiraClientes =
      $CrmCarteiraClientesTable(this);
  late final $CrmCampanhaClientesTable crmCampanhaClientes =
      $CrmCampanhaClientesTable(this);
  late final $CrmSacCabecalhosTable crmSacCabecalhos = $CrmSacCabecalhosTable(
    this,
  );
  late final $CrmCarteiraClientePerfilsTable crmCarteiraClientePerfils =
      $CrmCarteiraClientePerfilsTable(this);
  late final $CrmCampanhasTable crmCampanhas = $CrmCampanhasTable(this);
  late final $CrmBuscasClientesTable crmBuscasClientes =
      $CrmBuscasClientesTable(this);
  late final $ViewControleAcessosTable viewControleAcessos =
      $ViewControleAcessosTable(this);
  late final $ViewPessoaUsuariosTable viewPessoaUsuarios =
      $ViewPessoaUsuariosTable(this);
  late final $ViewPessoaClientesTable viewPessoaClientes =
      $ViewPessoaClientesTable(this);
  late final $ViewPessoaColaboradorsTable viewPessoaColaboradors =
      $ViewPessoaColaboradorsTable(this);
  late final $CrmContatosTable crmContatos = $CrmContatosTable(this);
  late final $CrmOportunidadesTable crmOportunidades = $CrmOportunidadesTable(
    this,
  );
  late final $CrmTarefasTable crmTarefas = $CrmTarefasTable(this);
  late final CrmSacCabecalhoDao crmSacCabecalhoDao = CrmSacCabecalhoDao(
    this as AppDatabase,
  );
  late final CrmCarteiraClientePerfilDao crmCarteiraClientePerfilDao =
      CrmCarteiraClientePerfilDao(this as AppDatabase);
  late final CrmCampanhaDao crmCampanhaDao = CrmCampanhaDao(
    this as AppDatabase,
  );
  late final CrmBuscasClienteDao crmBuscasClienteDao = CrmBuscasClienteDao(
    this as AppDatabase,
  );
  late final ViewControleAcessoDao viewControleAcessoDao =
      ViewControleAcessoDao(this as AppDatabase);
  late final ViewPessoaUsuarioDao viewPessoaUsuarioDao = ViewPessoaUsuarioDao(
    this as AppDatabase,
  );
  late final ViewPessoaClienteDao viewPessoaClienteDao = ViewPessoaClienteDao(
    this as AppDatabase,
  );
  late final ViewPessoaColaboradorDao viewPessoaColaboradorDao =
      ViewPessoaColaboradorDao(this as AppDatabase);
  late final CrmContatoDao crmContatoDao = CrmContatoDao(this as AppDatabase);
  late final CrmOportunidadeDao crmOportunidadeDao = CrmOportunidadeDao(
    this as AppDatabase,
  );
  late final CrmTarefaDao crmTarefaDao = CrmTarefaDao(this as AppDatabase);
  @override
  Iterable<TableInfo<Table, Object?>> get allTables =>
      allSchemaEntities.whereType<TableInfo<Table, Object?>>();
  @override
  List<DatabaseSchemaEntity> get allSchemaEntities => [
    crmSacDetalhes,
    crmCarteiraClientes,
    crmCampanhaClientes,
    crmSacCabecalhos,
    crmCarteiraClientePerfils,
    crmCampanhas,
    crmBuscasClientes,
    viewControleAcessos,
    viewPessoaUsuarios,
    viewPessoaClientes,
    viewPessoaColaboradors,
    crmContatos,
    crmOportunidades,
    crmTarefas,
  ];
}

typedef $$CrmSacDetalhesTableCreateCompanionBuilder =
    CrmSacDetalhesCompanion Function({
      Value<int?> id,
      Value<int?> idCrmSacCabecalho,
      Value<int?> idViewPessoaColaborador,
      Value<DateTime?> dataRegistro,
      Value<String?> horaRegistro,
      Value<String?> historico,
    });
typedef $$CrmSacDetalhesTableUpdateCompanionBuilder =
    CrmSacDetalhesCompanion Function({
      Value<int?> id,
      Value<int?> idCrmSacCabecalho,
      Value<int?> idViewPessoaColaborador,
      Value<DateTime?> dataRegistro,
      Value<String?> horaRegistro,
      Value<String?> historico,
    });

class $$CrmSacDetalhesTableFilterComposer
    extends Composer<_$AppDatabase, $CrmSacDetalhesTable> {
  $$CrmSacDetalhesTableFilterComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnFilters<int> get id => $composableBuilder(
    column: $table.id,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<int> get idCrmSacCabecalho => $composableBuilder(
    column: $table.idCrmSacCabecalho,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<int> get idViewPessoaColaborador => $composableBuilder(
    column: $table.idViewPessoaColaborador,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<DateTime> get dataRegistro => $composableBuilder(
    column: $table.dataRegistro,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get horaRegistro => $composableBuilder(
    column: $table.horaRegistro,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get historico => $composableBuilder(
    column: $table.historico,
    builder: (column) => ColumnFilters(column),
  );
}

class $$CrmSacDetalhesTableOrderingComposer
    extends Composer<_$AppDatabase, $CrmSacDetalhesTable> {
  $$CrmSacDetalhesTableOrderingComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnOrderings<int> get id => $composableBuilder(
    column: $table.id,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<int> get idCrmSacCabecalho => $composableBuilder(
    column: $table.idCrmSacCabecalho,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<int> get idViewPessoaColaborador => $composableBuilder(
    column: $table.idViewPessoaColaborador,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<DateTime> get dataRegistro => $composableBuilder(
    column: $table.dataRegistro,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get horaRegistro => $composableBuilder(
    column: $table.horaRegistro,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get historico => $composableBuilder(
    column: $table.historico,
    builder: (column) => ColumnOrderings(column),
  );
}

class $$CrmSacDetalhesTableAnnotationComposer
    extends Composer<_$AppDatabase, $CrmSacDetalhesTable> {
  $$CrmSacDetalhesTableAnnotationComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  GeneratedColumn<int> get id =>
      $composableBuilder(column: $table.id, builder: (column) => column);

  GeneratedColumn<int> get idCrmSacCabecalho => $composableBuilder(
    column: $table.idCrmSacCabecalho,
    builder: (column) => column,
  );

  GeneratedColumn<int> get idViewPessoaColaborador => $composableBuilder(
    column: $table.idViewPessoaColaborador,
    builder: (column) => column,
  );

  GeneratedColumn<DateTime> get dataRegistro => $composableBuilder(
    column: $table.dataRegistro,
    builder: (column) => column,
  );

  GeneratedColumn<String> get horaRegistro => $composableBuilder(
    column: $table.horaRegistro,
    builder: (column) => column,
  );

  GeneratedColumn<String> get historico =>
      $composableBuilder(column: $table.historico, builder: (column) => column);
}

class $$CrmSacDetalhesTableTableManager
    extends
        RootTableManager<
          _$AppDatabase,
          $CrmSacDetalhesTable,
          CrmSacDetalhe,
          $$CrmSacDetalhesTableFilterComposer,
          $$CrmSacDetalhesTableOrderingComposer,
          $$CrmSacDetalhesTableAnnotationComposer,
          $$CrmSacDetalhesTableCreateCompanionBuilder,
          $$CrmSacDetalhesTableUpdateCompanionBuilder,
          (
            CrmSacDetalhe,
            BaseReferences<_$AppDatabase, $CrmSacDetalhesTable, CrmSacDetalhe>,
          ),
          CrmSacDetalhe,
          PrefetchHooks Function()
        > {
  $$CrmSacDetalhesTableTableManager(
    _$AppDatabase db,
    $CrmSacDetalhesTable table,
  ) : super(
        TableManagerState(
          db: db,
          table: table,
          createFilteringComposer:
              () => $$CrmSacDetalhesTableFilterComposer($db: db, $table: table),
          createOrderingComposer:
              () =>
                  $$CrmSacDetalhesTableOrderingComposer($db: db, $table: table),
          createComputedFieldComposer:
              () => $$CrmSacDetalhesTableAnnotationComposer(
                $db: db,
                $table: table,
              ),
          updateCompanionCallback:
              ({
                Value<int?> id = const Value.absent(),
                Value<int?> idCrmSacCabecalho = const Value.absent(),
                Value<int?> idViewPessoaColaborador = const Value.absent(),
                Value<DateTime?> dataRegistro = const Value.absent(),
                Value<String?> horaRegistro = const Value.absent(),
                Value<String?> historico = const Value.absent(),
              }) => CrmSacDetalhesCompanion(
                id: id,
                idCrmSacCabecalho: idCrmSacCabecalho,
                idViewPessoaColaborador: idViewPessoaColaborador,
                dataRegistro: dataRegistro,
                horaRegistro: horaRegistro,
                historico: historico,
              ),
          createCompanionCallback:
              ({
                Value<int?> id = const Value.absent(),
                Value<int?> idCrmSacCabecalho = const Value.absent(),
                Value<int?> idViewPessoaColaborador = const Value.absent(),
                Value<DateTime?> dataRegistro = const Value.absent(),
                Value<String?> horaRegistro = const Value.absent(),
                Value<String?> historico = const Value.absent(),
              }) => CrmSacDetalhesCompanion.insert(
                id: id,
                idCrmSacCabecalho: idCrmSacCabecalho,
                idViewPessoaColaborador: idViewPessoaColaborador,
                dataRegistro: dataRegistro,
                horaRegistro: horaRegistro,
                historico: historico,
              ),
          withReferenceMapper:
              (p0) =>
                  p0
                      .map(
                        (e) => (
                          e.readTable(table),
                          BaseReferences(db, table, e),
                        ),
                      )
                      .toList(),
          prefetchHooksCallback: null,
        ),
      );
}

typedef $$CrmSacDetalhesTableProcessedTableManager =
    ProcessedTableManager<
      _$AppDatabase,
      $CrmSacDetalhesTable,
      CrmSacDetalhe,
      $$CrmSacDetalhesTableFilterComposer,
      $$CrmSacDetalhesTableOrderingComposer,
      $$CrmSacDetalhesTableAnnotationComposer,
      $$CrmSacDetalhesTableCreateCompanionBuilder,
      $$CrmSacDetalhesTableUpdateCompanionBuilder,
      (
        CrmSacDetalhe,
        BaseReferences<_$AppDatabase, $CrmSacDetalhesTable, CrmSacDetalhe>,
      ),
      CrmSacDetalhe,
      PrefetchHooks Function()
    >;
typedef $$CrmCarteiraClientesTableCreateCompanionBuilder =
    CrmCarteiraClientesCompanion Function({
      Value<int?> id,
      Value<int?> idCliente,
      Value<int?> idCrmCarteiraClientePerfil,
    });
typedef $$CrmCarteiraClientesTableUpdateCompanionBuilder =
    CrmCarteiraClientesCompanion Function({
      Value<int?> id,
      Value<int?> idCliente,
      Value<int?> idCrmCarteiraClientePerfil,
    });

class $$CrmCarteiraClientesTableFilterComposer
    extends Composer<_$AppDatabase, $CrmCarteiraClientesTable> {
  $$CrmCarteiraClientesTableFilterComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnFilters<int> get id => $composableBuilder(
    column: $table.id,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<int> get idCliente => $composableBuilder(
    column: $table.idCliente,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<int> get idCrmCarteiraClientePerfil => $composableBuilder(
    column: $table.idCrmCarteiraClientePerfil,
    builder: (column) => ColumnFilters(column),
  );
}

class $$CrmCarteiraClientesTableOrderingComposer
    extends Composer<_$AppDatabase, $CrmCarteiraClientesTable> {
  $$CrmCarteiraClientesTableOrderingComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnOrderings<int> get id => $composableBuilder(
    column: $table.id,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<int> get idCliente => $composableBuilder(
    column: $table.idCliente,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<int> get idCrmCarteiraClientePerfil => $composableBuilder(
    column: $table.idCrmCarteiraClientePerfil,
    builder: (column) => ColumnOrderings(column),
  );
}

class $$CrmCarteiraClientesTableAnnotationComposer
    extends Composer<_$AppDatabase, $CrmCarteiraClientesTable> {
  $$CrmCarteiraClientesTableAnnotationComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  GeneratedColumn<int> get id =>
      $composableBuilder(column: $table.id, builder: (column) => column);

  GeneratedColumn<int> get idCliente =>
      $composableBuilder(column: $table.idCliente, builder: (column) => column);

  GeneratedColumn<int> get idCrmCarteiraClientePerfil => $composableBuilder(
    column: $table.idCrmCarteiraClientePerfil,
    builder: (column) => column,
  );
}

class $$CrmCarteiraClientesTableTableManager
    extends
        RootTableManager<
          _$AppDatabase,
          $CrmCarteiraClientesTable,
          CrmCarteiraCliente,
          $$CrmCarteiraClientesTableFilterComposer,
          $$CrmCarteiraClientesTableOrderingComposer,
          $$CrmCarteiraClientesTableAnnotationComposer,
          $$CrmCarteiraClientesTableCreateCompanionBuilder,
          $$CrmCarteiraClientesTableUpdateCompanionBuilder,
          (
            CrmCarteiraCliente,
            BaseReferences<
              _$AppDatabase,
              $CrmCarteiraClientesTable,
              CrmCarteiraCliente
            >,
          ),
          CrmCarteiraCliente,
          PrefetchHooks Function()
        > {
  $$CrmCarteiraClientesTableTableManager(
    _$AppDatabase db,
    $CrmCarteiraClientesTable table,
  ) : super(
        TableManagerState(
          db: db,
          table: table,
          createFilteringComposer:
              () => $$CrmCarteiraClientesTableFilterComposer(
                $db: db,
                $table: table,
              ),
          createOrderingComposer:
              () => $$CrmCarteiraClientesTableOrderingComposer(
                $db: db,
                $table: table,
              ),
          createComputedFieldComposer:
              () => $$CrmCarteiraClientesTableAnnotationComposer(
                $db: db,
                $table: table,
              ),
          updateCompanionCallback:
              ({
                Value<int?> id = const Value.absent(),
                Value<int?> idCliente = const Value.absent(),
                Value<int?> idCrmCarteiraClientePerfil = const Value.absent(),
              }) => CrmCarteiraClientesCompanion(
                id: id,
                idCliente: idCliente,
                idCrmCarteiraClientePerfil: idCrmCarteiraClientePerfil,
              ),
          createCompanionCallback:
              ({
                Value<int?> id = const Value.absent(),
                Value<int?> idCliente = const Value.absent(),
                Value<int?> idCrmCarteiraClientePerfil = const Value.absent(),
              }) => CrmCarteiraClientesCompanion.insert(
                id: id,
                idCliente: idCliente,
                idCrmCarteiraClientePerfil: idCrmCarteiraClientePerfil,
              ),
          withReferenceMapper:
              (p0) =>
                  p0
                      .map(
                        (e) => (
                          e.readTable(table),
                          BaseReferences(db, table, e),
                        ),
                      )
                      .toList(),
          prefetchHooksCallback: null,
        ),
      );
}

typedef $$CrmCarteiraClientesTableProcessedTableManager =
    ProcessedTableManager<
      _$AppDatabase,
      $CrmCarteiraClientesTable,
      CrmCarteiraCliente,
      $$CrmCarteiraClientesTableFilterComposer,
      $$CrmCarteiraClientesTableOrderingComposer,
      $$CrmCarteiraClientesTableAnnotationComposer,
      $$CrmCarteiraClientesTableCreateCompanionBuilder,
      $$CrmCarteiraClientesTableUpdateCompanionBuilder,
      (
        CrmCarteiraCliente,
        BaseReferences<
          _$AppDatabase,
          $CrmCarteiraClientesTable,
          CrmCarteiraCliente
        >,
      ),
      CrmCarteiraCliente,
      PrefetchHooks Function()
    >;
typedef $$CrmCampanhaClientesTableCreateCompanionBuilder =
    CrmCampanhaClientesCompanion Function({
      Value<int?> id,
      Value<int?> idCampanha,
      Value<int?> idCliente,
      Value<DateTime?> dataInscricao,
      Value<String?> status,
      Value<String?> observacoes,
    });
typedef $$CrmCampanhaClientesTableUpdateCompanionBuilder =
    CrmCampanhaClientesCompanion Function({
      Value<int?> id,
      Value<int?> idCampanha,
      Value<int?> idCliente,
      Value<DateTime?> dataInscricao,
      Value<String?> status,
      Value<String?> observacoes,
    });

class $$CrmCampanhaClientesTableFilterComposer
    extends Composer<_$AppDatabase, $CrmCampanhaClientesTable> {
  $$CrmCampanhaClientesTableFilterComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnFilters<int> get id => $composableBuilder(
    column: $table.id,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<int> get idCampanha => $composableBuilder(
    column: $table.idCampanha,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<int> get idCliente => $composableBuilder(
    column: $table.idCliente,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<DateTime> get dataInscricao => $composableBuilder(
    column: $table.dataInscricao,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get status => $composableBuilder(
    column: $table.status,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get observacoes => $composableBuilder(
    column: $table.observacoes,
    builder: (column) => ColumnFilters(column),
  );
}

class $$CrmCampanhaClientesTableOrderingComposer
    extends Composer<_$AppDatabase, $CrmCampanhaClientesTable> {
  $$CrmCampanhaClientesTableOrderingComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnOrderings<int> get id => $composableBuilder(
    column: $table.id,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<int> get idCampanha => $composableBuilder(
    column: $table.idCampanha,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<int> get idCliente => $composableBuilder(
    column: $table.idCliente,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<DateTime> get dataInscricao => $composableBuilder(
    column: $table.dataInscricao,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get status => $composableBuilder(
    column: $table.status,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get observacoes => $composableBuilder(
    column: $table.observacoes,
    builder: (column) => ColumnOrderings(column),
  );
}

class $$CrmCampanhaClientesTableAnnotationComposer
    extends Composer<_$AppDatabase, $CrmCampanhaClientesTable> {
  $$CrmCampanhaClientesTableAnnotationComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  GeneratedColumn<int> get id =>
      $composableBuilder(column: $table.id, builder: (column) => column);

  GeneratedColumn<int> get idCampanha => $composableBuilder(
    column: $table.idCampanha,
    builder: (column) => column,
  );

  GeneratedColumn<int> get idCliente =>
      $composableBuilder(column: $table.idCliente, builder: (column) => column);

  GeneratedColumn<DateTime> get dataInscricao => $composableBuilder(
    column: $table.dataInscricao,
    builder: (column) => column,
  );

  GeneratedColumn<String> get status =>
      $composableBuilder(column: $table.status, builder: (column) => column);

  GeneratedColumn<String> get observacoes => $composableBuilder(
    column: $table.observacoes,
    builder: (column) => column,
  );
}

class $$CrmCampanhaClientesTableTableManager
    extends
        RootTableManager<
          _$AppDatabase,
          $CrmCampanhaClientesTable,
          CrmCampanhaCliente,
          $$CrmCampanhaClientesTableFilterComposer,
          $$CrmCampanhaClientesTableOrderingComposer,
          $$CrmCampanhaClientesTableAnnotationComposer,
          $$CrmCampanhaClientesTableCreateCompanionBuilder,
          $$CrmCampanhaClientesTableUpdateCompanionBuilder,
          (
            CrmCampanhaCliente,
            BaseReferences<
              _$AppDatabase,
              $CrmCampanhaClientesTable,
              CrmCampanhaCliente
            >,
          ),
          CrmCampanhaCliente,
          PrefetchHooks Function()
        > {
  $$CrmCampanhaClientesTableTableManager(
    _$AppDatabase db,
    $CrmCampanhaClientesTable table,
  ) : super(
        TableManagerState(
          db: db,
          table: table,
          createFilteringComposer:
              () => $$CrmCampanhaClientesTableFilterComposer(
                $db: db,
                $table: table,
              ),
          createOrderingComposer:
              () => $$CrmCampanhaClientesTableOrderingComposer(
                $db: db,
                $table: table,
              ),
          createComputedFieldComposer:
              () => $$CrmCampanhaClientesTableAnnotationComposer(
                $db: db,
                $table: table,
              ),
          updateCompanionCallback:
              ({
                Value<int?> id = const Value.absent(),
                Value<int?> idCampanha = const Value.absent(),
                Value<int?> idCliente = const Value.absent(),
                Value<DateTime?> dataInscricao = const Value.absent(),
                Value<String?> status = const Value.absent(),
                Value<String?> observacoes = const Value.absent(),
              }) => CrmCampanhaClientesCompanion(
                id: id,
                idCampanha: idCampanha,
                idCliente: idCliente,
                dataInscricao: dataInscricao,
                status: status,
                observacoes: observacoes,
              ),
          createCompanionCallback:
              ({
                Value<int?> id = const Value.absent(),
                Value<int?> idCampanha = const Value.absent(),
                Value<int?> idCliente = const Value.absent(),
                Value<DateTime?> dataInscricao = const Value.absent(),
                Value<String?> status = const Value.absent(),
                Value<String?> observacoes = const Value.absent(),
              }) => CrmCampanhaClientesCompanion.insert(
                id: id,
                idCampanha: idCampanha,
                idCliente: idCliente,
                dataInscricao: dataInscricao,
                status: status,
                observacoes: observacoes,
              ),
          withReferenceMapper:
              (p0) =>
                  p0
                      .map(
                        (e) => (
                          e.readTable(table),
                          BaseReferences(db, table, e),
                        ),
                      )
                      .toList(),
          prefetchHooksCallback: null,
        ),
      );
}

typedef $$CrmCampanhaClientesTableProcessedTableManager =
    ProcessedTableManager<
      _$AppDatabase,
      $CrmCampanhaClientesTable,
      CrmCampanhaCliente,
      $$CrmCampanhaClientesTableFilterComposer,
      $$CrmCampanhaClientesTableOrderingComposer,
      $$CrmCampanhaClientesTableAnnotationComposer,
      $$CrmCampanhaClientesTableCreateCompanionBuilder,
      $$CrmCampanhaClientesTableUpdateCompanionBuilder,
      (
        CrmCampanhaCliente,
        BaseReferences<
          _$AppDatabase,
          $CrmCampanhaClientesTable,
          CrmCampanhaCliente
        >,
      ),
      CrmCampanhaCliente,
      PrefetchHooks Function()
    >;
typedef $$CrmSacCabecalhosTableCreateCompanionBuilder =
    CrmSacCabecalhosCompanion Function({
      Value<int?> id,
      Value<int?> idCliente,
      Value<DateTime?> dataAbertura,
      Value<String?> horaAbertura,
      Value<String?> nivelReclamacao,
      Value<String?> numeroProtocolo,
    });
typedef $$CrmSacCabecalhosTableUpdateCompanionBuilder =
    CrmSacCabecalhosCompanion Function({
      Value<int?> id,
      Value<int?> idCliente,
      Value<DateTime?> dataAbertura,
      Value<String?> horaAbertura,
      Value<String?> nivelReclamacao,
      Value<String?> numeroProtocolo,
    });

class $$CrmSacCabecalhosTableFilterComposer
    extends Composer<_$AppDatabase, $CrmSacCabecalhosTable> {
  $$CrmSacCabecalhosTableFilterComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnFilters<int> get id => $composableBuilder(
    column: $table.id,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<int> get idCliente => $composableBuilder(
    column: $table.idCliente,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<DateTime> get dataAbertura => $composableBuilder(
    column: $table.dataAbertura,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get horaAbertura => $composableBuilder(
    column: $table.horaAbertura,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get nivelReclamacao => $composableBuilder(
    column: $table.nivelReclamacao,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get numeroProtocolo => $composableBuilder(
    column: $table.numeroProtocolo,
    builder: (column) => ColumnFilters(column),
  );
}

class $$CrmSacCabecalhosTableOrderingComposer
    extends Composer<_$AppDatabase, $CrmSacCabecalhosTable> {
  $$CrmSacCabecalhosTableOrderingComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnOrderings<int> get id => $composableBuilder(
    column: $table.id,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<int> get idCliente => $composableBuilder(
    column: $table.idCliente,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<DateTime> get dataAbertura => $composableBuilder(
    column: $table.dataAbertura,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get horaAbertura => $composableBuilder(
    column: $table.horaAbertura,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get nivelReclamacao => $composableBuilder(
    column: $table.nivelReclamacao,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get numeroProtocolo => $composableBuilder(
    column: $table.numeroProtocolo,
    builder: (column) => ColumnOrderings(column),
  );
}

class $$CrmSacCabecalhosTableAnnotationComposer
    extends Composer<_$AppDatabase, $CrmSacCabecalhosTable> {
  $$CrmSacCabecalhosTableAnnotationComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  GeneratedColumn<int> get id =>
      $composableBuilder(column: $table.id, builder: (column) => column);

  GeneratedColumn<int> get idCliente =>
      $composableBuilder(column: $table.idCliente, builder: (column) => column);

  GeneratedColumn<DateTime> get dataAbertura => $composableBuilder(
    column: $table.dataAbertura,
    builder: (column) => column,
  );

  GeneratedColumn<String> get horaAbertura => $composableBuilder(
    column: $table.horaAbertura,
    builder: (column) => column,
  );

  GeneratedColumn<String> get nivelReclamacao => $composableBuilder(
    column: $table.nivelReclamacao,
    builder: (column) => column,
  );

  GeneratedColumn<String> get numeroProtocolo => $composableBuilder(
    column: $table.numeroProtocolo,
    builder: (column) => column,
  );
}

class $$CrmSacCabecalhosTableTableManager
    extends
        RootTableManager<
          _$AppDatabase,
          $CrmSacCabecalhosTable,
          CrmSacCabecalho,
          $$CrmSacCabecalhosTableFilterComposer,
          $$CrmSacCabecalhosTableOrderingComposer,
          $$CrmSacCabecalhosTableAnnotationComposer,
          $$CrmSacCabecalhosTableCreateCompanionBuilder,
          $$CrmSacCabecalhosTableUpdateCompanionBuilder,
          (
            CrmSacCabecalho,
            BaseReferences<
              _$AppDatabase,
              $CrmSacCabecalhosTable,
              CrmSacCabecalho
            >,
          ),
          CrmSacCabecalho,
          PrefetchHooks Function()
        > {
  $$CrmSacCabecalhosTableTableManager(
    _$AppDatabase db,
    $CrmSacCabecalhosTable table,
  ) : super(
        TableManagerState(
          db: db,
          table: table,
          createFilteringComposer:
              () =>
                  $$CrmSacCabecalhosTableFilterComposer($db: db, $table: table),
          createOrderingComposer:
              () => $$CrmSacCabecalhosTableOrderingComposer(
                $db: db,
                $table: table,
              ),
          createComputedFieldComposer:
              () => $$CrmSacCabecalhosTableAnnotationComposer(
                $db: db,
                $table: table,
              ),
          updateCompanionCallback:
              ({
                Value<int?> id = const Value.absent(),
                Value<int?> idCliente = const Value.absent(),
                Value<DateTime?> dataAbertura = const Value.absent(),
                Value<String?> horaAbertura = const Value.absent(),
                Value<String?> nivelReclamacao = const Value.absent(),
                Value<String?> numeroProtocolo = const Value.absent(),
              }) => CrmSacCabecalhosCompanion(
                id: id,
                idCliente: idCliente,
                dataAbertura: dataAbertura,
                horaAbertura: horaAbertura,
                nivelReclamacao: nivelReclamacao,
                numeroProtocolo: numeroProtocolo,
              ),
          createCompanionCallback:
              ({
                Value<int?> id = const Value.absent(),
                Value<int?> idCliente = const Value.absent(),
                Value<DateTime?> dataAbertura = const Value.absent(),
                Value<String?> horaAbertura = const Value.absent(),
                Value<String?> nivelReclamacao = const Value.absent(),
                Value<String?> numeroProtocolo = const Value.absent(),
              }) => CrmSacCabecalhosCompanion.insert(
                id: id,
                idCliente: idCliente,
                dataAbertura: dataAbertura,
                horaAbertura: horaAbertura,
                nivelReclamacao: nivelReclamacao,
                numeroProtocolo: numeroProtocolo,
              ),
          withReferenceMapper:
              (p0) =>
                  p0
                      .map(
                        (e) => (
                          e.readTable(table),
                          BaseReferences(db, table, e),
                        ),
                      )
                      .toList(),
          prefetchHooksCallback: null,
        ),
      );
}

typedef $$CrmSacCabecalhosTableProcessedTableManager =
    ProcessedTableManager<
      _$AppDatabase,
      $CrmSacCabecalhosTable,
      CrmSacCabecalho,
      $$CrmSacCabecalhosTableFilterComposer,
      $$CrmSacCabecalhosTableOrderingComposer,
      $$CrmSacCabecalhosTableAnnotationComposer,
      $$CrmSacCabecalhosTableCreateCompanionBuilder,
      $$CrmSacCabecalhosTableUpdateCompanionBuilder,
      (
        CrmSacCabecalho,
        BaseReferences<_$AppDatabase, $CrmSacCabecalhosTable, CrmSacCabecalho>,
      ),
      CrmSacCabecalho,
      PrefetchHooks Function()
    >;
typedef $$CrmCarteiraClientePerfilsTableCreateCompanionBuilder =
    CrmCarteiraClientePerfilsCompanion Function({
      Value<int?> id,
      Value<String?> codigo,
      Value<String?> nome,
    });
typedef $$CrmCarteiraClientePerfilsTableUpdateCompanionBuilder =
    CrmCarteiraClientePerfilsCompanion Function({
      Value<int?> id,
      Value<String?> codigo,
      Value<String?> nome,
    });

class $$CrmCarteiraClientePerfilsTableFilterComposer
    extends Composer<_$AppDatabase, $CrmCarteiraClientePerfilsTable> {
  $$CrmCarteiraClientePerfilsTableFilterComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnFilters<int> get id => $composableBuilder(
    column: $table.id,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get codigo => $composableBuilder(
    column: $table.codigo,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get nome => $composableBuilder(
    column: $table.nome,
    builder: (column) => ColumnFilters(column),
  );
}

class $$CrmCarteiraClientePerfilsTableOrderingComposer
    extends Composer<_$AppDatabase, $CrmCarteiraClientePerfilsTable> {
  $$CrmCarteiraClientePerfilsTableOrderingComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnOrderings<int> get id => $composableBuilder(
    column: $table.id,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get codigo => $composableBuilder(
    column: $table.codigo,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get nome => $composableBuilder(
    column: $table.nome,
    builder: (column) => ColumnOrderings(column),
  );
}

class $$CrmCarteiraClientePerfilsTableAnnotationComposer
    extends Composer<_$AppDatabase, $CrmCarteiraClientePerfilsTable> {
  $$CrmCarteiraClientePerfilsTableAnnotationComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  GeneratedColumn<int> get id =>
      $composableBuilder(column: $table.id, builder: (column) => column);

  GeneratedColumn<String> get codigo =>
      $composableBuilder(column: $table.codigo, builder: (column) => column);

  GeneratedColumn<String> get nome =>
      $composableBuilder(column: $table.nome, builder: (column) => column);
}

class $$CrmCarteiraClientePerfilsTableTableManager
    extends
        RootTableManager<
          _$AppDatabase,
          $CrmCarteiraClientePerfilsTable,
          CrmCarteiraClientePerfil,
          $$CrmCarteiraClientePerfilsTableFilterComposer,
          $$CrmCarteiraClientePerfilsTableOrderingComposer,
          $$CrmCarteiraClientePerfilsTableAnnotationComposer,
          $$CrmCarteiraClientePerfilsTableCreateCompanionBuilder,
          $$CrmCarteiraClientePerfilsTableUpdateCompanionBuilder,
          (
            CrmCarteiraClientePerfil,
            BaseReferences<
              _$AppDatabase,
              $CrmCarteiraClientePerfilsTable,
              CrmCarteiraClientePerfil
            >,
          ),
          CrmCarteiraClientePerfil,
          PrefetchHooks Function()
        > {
  $$CrmCarteiraClientePerfilsTableTableManager(
    _$AppDatabase db,
    $CrmCarteiraClientePerfilsTable table,
  ) : super(
        TableManagerState(
          db: db,
          table: table,
          createFilteringComposer:
              () => $$CrmCarteiraClientePerfilsTableFilterComposer(
                $db: db,
                $table: table,
              ),
          createOrderingComposer:
              () => $$CrmCarteiraClientePerfilsTableOrderingComposer(
                $db: db,
                $table: table,
              ),
          createComputedFieldComposer:
              () => $$CrmCarteiraClientePerfilsTableAnnotationComposer(
                $db: db,
                $table: table,
              ),
          updateCompanionCallback:
              ({
                Value<int?> id = const Value.absent(),
                Value<String?> codigo = const Value.absent(),
                Value<String?> nome = const Value.absent(),
              }) => CrmCarteiraClientePerfilsCompanion(
                id: id,
                codigo: codigo,
                nome: nome,
              ),
          createCompanionCallback:
              ({
                Value<int?> id = const Value.absent(),
                Value<String?> codigo = const Value.absent(),
                Value<String?> nome = const Value.absent(),
              }) => CrmCarteiraClientePerfilsCompanion.insert(
                id: id,
                codigo: codigo,
                nome: nome,
              ),
          withReferenceMapper:
              (p0) =>
                  p0
                      .map(
                        (e) => (
                          e.readTable(table),
                          BaseReferences(db, table, e),
                        ),
                      )
                      .toList(),
          prefetchHooksCallback: null,
        ),
      );
}

typedef $$CrmCarteiraClientePerfilsTableProcessedTableManager =
    ProcessedTableManager<
      _$AppDatabase,
      $CrmCarteiraClientePerfilsTable,
      CrmCarteiraClientePerfil,
      $$CrmCarteiraClientePerfilsTableFilterComposer,
      $$CrmCarteiraClientePerfilsTableOrderingComposer,
      $$CrmCarteiraClientePerfilsTableAnnotationComposer,
      $$CrmCarteiraClientePerfilsTableCreateCompanionBuilder,
      $$CrmCarteiraClientePerfilsTableUpdateCompanionBuilder,
      (
        CrmCarteiraClientePerfil,
        BaseReferences<
          _$AppDatabase,
          $CrmCarteiraClientePerfilsTable,
          CrmCarteiraClientePerfil
        >,
      ),
      CrmCarteiraClientePerfil,
      PrefetchHooks Function()
    >;
typedef $$CrmCampanhasTableCreateCompanionBuilder =
    CrmCampanhasCompanion Function({
      Value<int?> id,
      Value<String?> nome,
      Value<String?> descricao,
      Value<String?> tipo,
      Value<DateTime?> dataInicio,
      Value<DateTime?> dataFim,
      Value<double?> orcamento,
      Value<String?> status,
    });
typedef $$CrmCampanhasTableUpdateCompanionBuilder =
    CrmCampanhasCompanion Function({
      Value<int?> id,
      Value<String?> nome,
      Value<String?> descricao,
      Value<String?> tipo,
      Value<DateTime?> dataInicio,
      Value<DateTime?> dataFim,
      Value<double?> orcamento,
      Value<String?> status,
    });

class $$CrmCampanhasTableFilterComposer
    extends Composer<_$AppDatabase, $CrmCampanhasTable> {
  $$CrmCampanhasTableFilterComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnFilters<int> get id => $composableBuilder(
    column: $table.id,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get nome => $composableBuilder(
    column: $table.nome,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get descricao => $composableBuilder(
    column: $table.descricao,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get tipo => $composableBuilder(
    column: $table.tipo,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<DateTime> get dataInicio => $composableBuilder(
    column: $table.dataInicio,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<DateTime> get dataFim => $composableBuilder(
    column: $table.dataFim,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<double> get orcamento => $composableBuilder(
    column: $table.orcamento,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get status => $composableBuilder(
    column: $table.status,
    builder: (column) => ColumnFilters(column),
  );
}

class $$CrmCampanhasTableOrderingComposer
    extends Composer<_$AppDatabase, $CrmCampanhasTable> {
  $$CrmCampanhasTableOrderingComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnOrderings<int> get id => $composableBuilder(
    column: $table.id,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get nome => $composableBuilder(
    column: $table.nome,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get descricao => $composableBuilder(
    column: $table.descricao,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get tipo => $composableBuilder(
    column: $table.tipo,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<DateTime> get dataInicio => $composableBuilder(
    column: $table.dataInicio,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<DateTime> get dataFim => $composableBuilder(
    column: $table.dataFim,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<double> get orcamento => $composableBuilder(
    column: $table.orcamento,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get status => $composableBuilder(
    column: $table.status,
    builder: (column) => ColumnOrderings(column),
  );
}

class $$CrmCampanhasTableAnnotationComposer
    extends Composer<_$AppDatabase, $CrmCampanhasTable> {
  $$CrmCampanhasTableAnnotationComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  GeneratedColumn<int> get id =>
      $composableBuilder(column: $table.id, builder: (column) => column);

  GeneratedColumn<String> get nome =>
      $composableBuilder(column: $table.nome, builder: (column) => column);

  GeneratedColumn<String> get descricao =>
      $composableBuilder(column: $table.descricao, builder: (column) => column);

  GeneratedColumn<String> get tipo =>
      $composableBuilder(column: $table.tipo, builder: (column) => column);

  GeneratedColumn<DateTime> get dataInicio => $composableBuilder(
    column: $table.dataInicio,
    builder: (column) => column,
  );

  GeneratedColumn<DateTime> get dataFim =>
      $composableBuilder(column: $table.dataFim, builder: (column) => column);

  GeneratedColumn<double> get orcamento =>
      $composableBuilder(column: $table.orcamento, builder: (column) => column);

  GeneratedColumn<String> get status =>
      $composableBuilder(column: $table.status, builder: (column) => column);
}

class $$CrmCampanhasTableTableManager
    extends
        RootTableManager<
          _$AppDatabase,
          $CrmCampanhasTable,
          CrmCampanha,
          $$CrmCampanhasTableFilterComposer,
          $$CrmCampanhasTableOrderingComposer,
          $$CrmCampanhasTableAnnotationComposer,
          $$CrmCampanhasTableCreateCompanionBuilder,
          $$CrmCampanhasTableUpdateCompanionBuilder,
          (
            CrmCampanha,
            BaseReferences<_$AppDatabase, $CrmCampanhasTable, CrmCampanha>,
          ),
          CrmCampanha,
          PrefetchHooks Function()
        > {
  $$CrmCampanhasTableTableManager(_$AppDatabase db, $CrmCampanhasTable table)
    : super(
        TableManagerState(
          db: db,
          table: table,
          createFilteringComposer:
              () => $$CrmCampanhasTableFilterComposer($db: db, $table: table),
          createOrderingComposer:
              () => $$CrmCampanhasTableOrderingComposer($db: db, $table: table),
          createComputedFieldComposer:
              () =>
                  $$CrmCampanhasTableAnnotationComposer($db: db, $table: table),
          updateCompanionCallback:
              ({
                Value<int?> id = const Value.absent(),
                Value<String?> nome = const Value.absent(),
                Value<String?> descricao = const Value.absent(),
                Value<String?> tipo = const Value.absent(),
                Value<DateTime?> dataInicio = const Value.absent(),
                Value<DateTime?> dataFim = const Value.absent(),
                Value<double?> orcamento = const Value.absent(),
                Value<String?> status = const Value.absent(),
              }) => CrmCampanhasCompanion(
                id: id,
                nome: nome,
                descricao: descricao,
                tipo: tipo,
                dataInicio: dataInicio,
                dataFim: dataFim,
                orcamento: orcamento,
                status: status,
              ),
          createCompanionCallback:
              ({
                Value<int?> id = const Value.absent(),
                Value<String?> nome = const Value.absent(),
                Value<String?> descricao = const Value.absent(),
                Value<String?> tipo = const Value.absent(),
                Value<DateTime?> dataInicio = const Value.absent(),
                Value<DateTime?> dataFim = const Value.absent(),
                Value<double?> orcamento = const Value.absent(),
                Value<String?> status = const Value.absent(),
              }) => CrmCampanhasCompanion.insert(
                id: id,
                nome: nome,
                descricao: descricao,
                tipo: tipo,
                dataInicio: dataInicio,
                dataFim: dataFim,
                orcamento: orcamento,
                status: status,
              ),
          withReferenceMapper:
              (p0) =>
                  p0
                      .map(
                        (e) => (
                          e.readTable(table),
                          BaseReferences(db, table, e),
                        ),
                      )
                      .toList(),
          prefetchHooksCallback: null,
        ),
      );
}

typedef $$CrmCampanhasTableProcessedTableManager =
    ProcessedTableManager<
      _$AppDatabase,
      $CrmCampanhasTable,
      CrmCampanha,
      $$CrmCampanhasTableFilterComposer,
      $$CrmCampanhasTableOrderingComposer,
      $$CrmCampanhasTableAnnotationComposer,
      $$CrmCampanhasTableCreateCompanionBuilder,
      $$CrmCampanhasTableUpdateCompanionBuilder,
      (
        CrmCampanha,
        BaseReferences<_$AppDatabase, $CrmCampanhasTable, CrmCampanha>,
      ),
      CrmCampanha,
      PrefetchHooks Function()
    >;
typedef $$CrmBuscasClientesTableCreateCompanionBuilder =
    CrmBuscasClientesCompanion Function({
      Value<int?> id,
      Value<int?> idCliente,
      Value<DateTime?> dataBusca,
      Value<String?> horaBusca,
      Value<String?> detalhes,
    });
typedef $$CrmBuscasClientesTableUpdateCompanionBuilder =
    CrmBuscasClientesCompanion Function({
      Value<int?> id,
      Value<int?> idCliente,
      Value<DateTime?> dataBusca,
      Value<String?> horaBusca,
      Value<String?> detalhes,
    });

class $$CrmBuscasClientesTableFilterComposer
    extends Composer<_$AppDatabase, $CrmBuscasClientesTable> {
  $$CrmBuscasClientesTableFilterComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnFilters<int> get id => $composableBuilder(
    column: $table.id,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<int> get idCliente => $composableBuilder(
    column: $table.idCliente,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<DateTime> get dataBusca => $composableBuilder(
    column: $table.dataBusca,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get horaBusca => $composableBuilder(
    column: $table.horaBusca,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get detalhes => $composableBuilder(
    column: $table.detalhes,
    builder: (column) => ColumnFilters(column),
  );
}

class $$CrmBuscasClientesTableOrderingComposer
    extends Composer<_$AppDatabase, $CrmBuscasClientesTable> {
  $$CrmBuscasClientesTableOrderingComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnOrderings<int> get id => $composableBuilder(
    column: $table.id,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<int> get idCliente => $composableBuilder(
    column: $table.idCliente,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<DateTime> get dataBusca => $composableBuilder(
    column: $table.dataBusca,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get horaBusca => $composableBuilder(
    column: $table.horaBusca,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get detalhes => $composableBuilder(
    column: $table.detalhes,
    builder: (column) => ColumnOrderings(column),
  );
}

class $$CrmBuscasClientesTableAnnotationComposer
    extends Composer<_$AppDatabase, $CrmBuscasClientesTable> {
  $$CrmBuscasClientesTableAnnotationComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  GeneratedColumn<int> get id =>
      $composableBuilder(column: $table.id, builder: (column) => column);

  GeneratedColumn<int> get idCliente =>
      $composableBuilder(column: $table.idCliente, builder: (column) => column);

  GeneratedColumn<DateTime> get dataBusca =>
      $composableBuilder(column: $table.dataBusca, builder: (column) => column);

  GeneratedColumn<String> get horaBusca =>
      $composableBuilder(column: $table.horaBusca, builder: (column) => column);

  GeneratedColumn<String> get detalhes =>
      $composableBuilder(column: $table.detalhes, builder: (column) => column);
}

class $$CrmBuscasClientesTableTableManager
    extends
        RootTableManager<
          _$AppDatabase,
          $CrmBuscasClientesTable,
          CrmBuscasCliente,
          $$CrmBuscasClientesTableFilterComposer,
          $$CrmBuscasClientesTableOrderingComposer,
          $$CrmBuscasClientesTableAnnotationComposer,
          $$CrmBuscasClientesTableCreateCompanionBuilder,
          $$CrmBuscasClientesTableUpdateCompanionBuilder,
          (
            CrmBuscasCliente,
            BaseReferences<
              _$AppDatabase,
              $CrmBuscasClientesTable,
              CrmBuscasCliente
            >,
          ),
          CrmBuscasCliente,
          PrefetchHooks Function()
        > {
  $$CrmBuscasClientesTableTableManager(
    _$AppDatabase db,
    $CrmBuscasClientesTable table,
  ) : super(
        TableManagerState(
          db: db,
          table: table,
          createFilteringComposer:
              () => $$CrmBuscasClientesTableFilterComposer(
                $db: db,
                $table: table,
              ),
          createOrderingComposer:
              () => $$CrmBuscasClientesTableOrderingComposer(
                $db: db,
                $table: table,
              ),
          createComputedFieldComposer:
              () => $$CrmBuscasClientesTableAnnotationComposer(
                $db: db,
                $table: table,
              ),
          updateCompanionCallback:
              ({
                Value<int?> id = const Value.absent(),
                Value<int?> idCliente = const Value.absent(),
                Value<DateTime?> dataBusca = const Value.absent(),
                Value<String?> horaBusca = const Value.absent(),
                Value<String?> detalhes = const Value.absent(),
              }) => CrmBuscasClientesCompanion(
                id: id,
                idCliente: idCliente,
                dataBusca: dataBusca,
                horaBusca: horaBusca,
                detalhes: detalhes,
              ),
          createCompanionCallback:
              ({
                Value<int?> id = const Value.absent(),
                Value<int?> idCliente = const Value.absent(),
                Value<DateTime?> dataBusca = const Value.absent(),
                Value<String?> horaBusca = const Value.absent(),
                Value<String?> detalhes = const Value.absent(),
              }) => CrmBuscasClientesCompanion.insert(
                id: id,
                idCliente: idCliente,
                dataBusca: dataBusca,
                horaBusca: horaBusca,
                detalhes: detalhes,
              ),
          withReferenceMapper:
              (p0) =>
                  p0
                      .map(
                        (e) => (
                          e.readTable(table),
                          BaseReferences(db, table, e),
                        ),
                      )
                      .toList(),
          prefetchHooksCallback: null,
        ),
      );
}

typedef $$CrmBuscasClientesTableProcessedTableManager =
    ProcessedTableManager<
      _$AppDatabase,
      $CrmBuscasClientesTable,
      CrmBuscasCliente,
      $$CrmBuscasClientesTableFilterComposer,
      $$CrmBuscasClientesTableOrderingComposer,
      $$CrmBuscasClientesTableAnnotationComposer,
      $$CrmBuscasClientesTableCreateCompanionBuilder,
      $$CrmBuscasClientesTableUpdateCompanionBuilder,
      (
        CrmBuscasCliente,
        BaseReferences<
          _$AppDatabase,
          $CrmBuscasClientesTable,
          CrmBuscasCliente
        >,
      ),
      CrmBuscasCliente,
      PrefetchHooks Function()
    >;
typedef $$ViewControleAcessosTableCreateCompanionBuilder =
    ViewControleAcessosCompanion Function({
      Value<int?> id,
      Value<int?> idPessoa,
      Value<String?> pessoaNome,
      Value<int?> idColaborador,
      Value<int?> idUsuario,
      Value<String?> administrador,
      Value<int?> idPapel,
      Value<String?> papelNome,
      Value<String?> papelDescricao,
      Value<int?> idFuncao,
      Value<String?> funcaoNome,
      Value<String?> funcaoDescricao,
      Value<int?> idPapelFuncao,
      Value<String?> habilitado,
      Value<String?> podeInserir,
      Value<String?> podeAlterar,
      Value<String?> podeExcluir,
    });
typedef $$ViewControleAcessosTableUpdateCompanionBuilder =
    ViewControleAcessosCompanion Function({
      Value<int?> id,
      Value<int?> idPessoa,
      Value<String?> pessoaNome,
      Value<int?> idColaborador,
      Value<int?> idUsuario,
      Value<String?> administrador,
      Value<int?> idPapel,
      Value<String?> papelNome,
      Value<String?> papelDescricao,
      Value<int?> idFuncao,
      Value<String?> funcaoNome,
      Value<String?> funcaoDescricao,
      Value<int?> idPapelFuncao,
      Value<String?> habilitado,
      Value<String?> podeInserir,
      Value<String?> podeAlterar,
      Value<String?> podeExcluir,
    });

class $$ViewControleAcessosTableFilterComposer
    extends Composer<_$AppDatabase, $ViewControleAcessosTable> {
  $$ViewControleAcessosTableFilterComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnFilters<int> get id => $composableBuilder(
    column: $table.id,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<int> get idPessoa => $composableBuilder(
    column: $table.idPessoa,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get pessoaNome => $composableBuilder(
    column: $table.pessoaNome,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<int> get idColaborador => $composableBuilder(
    column: $table.idColaborador,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<int> get idUsuario => $composableBuilder(
    column: $table.idUsuario,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get administrador => $composableBuilder(
    column: $table.administrador,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<int> get idPapel => $composableBuilder(
    column: $table.idPapel,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get papelNome => $composableBuilder(
    column: $table.papelNome,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get papelDescricao => $composableBuilder(
    column: $table.papelDescricao,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<int> get idFuncao => $composableBuilder(
    column: $table.idFuncao,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get funcaoNome => $composableBuilder(
    column: $table.funcaoNome,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get funcaoDescricao => $composableBuilder(
    column: $table.funcaoDescricao,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<int> get idPapelFuncao => $composableBuilder(
    column: $table.idPapelFuncao,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get habilitado => $composableBuilder(
    column: $table.habilitado,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get podeInserir => $composableBuilder(
    column: $table.podeInserir,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get podeAlterar => $composableBuilder(
    column: $table.podeAlterar,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get podeExcluir => $composableBuilder(
    column: $table.podeExcluir,
    builder: (column) => ColumnFilters(column),
  );
}

class $$ViewControleAcessosTableOrderingComposer
    extends Composer<_$AppDatabase, $ViewControleAcessosTable> {
  $$ViewControleAcessosTableOrderingComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnOrderings<int> get id => $composableBuilder(
    column: $table.id,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<int> get idPessoa => $composableBuilder(
    column: $table.idPessoa,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get pessoaNome => $composableBuilder(
    column: $table.pessoaNome,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<int> get idColaborador => $composableBuilder(
    column: $table.idColaborador,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<int> get idUsuario => $composableBuilder(
    column: $table.idUsuario,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get administrador => $composableBuilder(
    column: $table.administrador,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<int> get idPapel => $composableBuilder(
    column: $table.idPapel,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get papelNome => $composableBuilder(
    column: $table.papelNome,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get papelDescricao => $composableBuilder(
    column: $table.papelDescricao,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<int> get idFuncao => $composableBuilder(
    column: $table.idFuncao,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get funcaoNome => $composableBuilder(
    column: $table.funcaoNome,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get funcaoDescricao => $composableBuilder(
    column: $table.funcaoDescricao,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<int> get idPapelFuncao => $composableBuilder(
    column: $table.idPapelFuncao,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get habilitado => $composableBuilder(
    column: $table.habilitado,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get podeInserir => $composableBuilder(
    column: $table.podeInserir,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get podeAlterar => $composableBuilder(
    column: $table.podeAlterar,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get podeExcluir => $composableBuilder(
    column: $table.podeExcluir,
    builder: (column) => ColumnOrderings(column),
  );
}

class $$ViewControleAcessosTableAnnotationComposer
    extends Composer<_$AppDatabase, $ViewControleAcessosTable> {
  $$ViewControleAcessosTableAnnotationComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  GeneratedColumn<int> get id =>
      $composableBuilder(column: $table.id, builder: (column) => column);

  GeneratedColumn<int> get idPessoa =>
      $composableBuilder(column: $table.idPessoa, builder: (column) => column);

  GeneratedColumn<String> get pessoaNome => $composableBuilder(
    column: $table.pessoaNome,
    builder: (column) => column,
  );

  GeneratedColumn<int> get idColaborador => $composableBuilder(
    column: $table.idColaborador,
    builder: (column) => column,
  );

  GeneratedColumn<int> get idUsuario =>
      $composableBuilder(column: $table.idUsuario, builder: (column) => column);

  GeneratedColumn<String> get administrador => $composableBuilder(
    column: $table.administrador,
    builder: (column) => column,
  );

  GeneratedColumn<int> get idPapel =>
      $composableBuilder(column: $table.idPapel, builder: (column) => column);

  GeneratedColumn<String> get papelNome =>
      $composableBuilder(column: $table.papelNome, builder: (column) => column);

  GeneratedColumn<String> get papelDescricao => $composableBuilder(
    column: $table.papelDescricao,
    builder: (column) => column,
  );

  GeneratedColumn<int> get idFuncao =>
      $composableBuilder(column: $table.idFuncao, builder: (column) => column);

  GeneratedColumn<String> get funcaoNome => $composableBuilder(
    column: $table.funcaoNome,
    builder: (column) => column,
  );

  GeneratedColumn<String> get funcaoDescricao => $composableBuilder(
    column: $table.funcaoDescricao,
    builder: (column) => column,
  );

  GeneratedColumn<int> get idPapelFuncao => $composableBuilder(
    column: $table.idPapelFuncao,
    builder: (column) => column,
  );

  GeneratedColumn<String> get habilitado => $composableBuilder(
    column: $table.habilitado,
    builder: (column) => column,
  );

  GeneratedColumn<String> get podeInserir => $composableBuilder(
    column: $table.podeInserir,
    builder: (column) => column,
  );

  GeneratedColumn<String> get podeAlterar => $composableBuilder(
    column: $table.podeAlterar,
    builder: (column) => column,
  );

  GeneratedColumn<String> get podeExcluir => $composableBuilder(
    column: $table.podeExcluir,
    builder: (column) => column,
  );
}

class $$ViewControleAcessosTableTableManager
    extends
        RootTableManager<
          _$AppDatabase,
          $ViewControleAcessosTable,
          ViewControleAcesso,
          $$ViewControleAcessosTableFilterComposer,
          $$ViewControleAcessosTableOrderingComposer,
          $$ViewControleAcessosTableAnnotationComposer,
          $$ViewControleAcessosTableCreateCompanionBuilder,
          $$ViewControleAcessosTableUpdateCompanionBuilder,
          (
            ViewControleAcesso,
            BaseReferences<
              _$AppDatabase,
              $ViewControleAcessosTable,
              ViewControleAcesso
            >,
          ),
          ViewControleAcesso,
          PrefetchHooks Function()
        > {
  $$ViewControleAcessosTableTableManager(
    _$AppDatabase db,
    $ViewControleAcessosTable table,
  ) : super(
        TableManagerState(
          db: db,
          table: table,
          createFilteringComposer:
              () => $$ViewControleAcessosTableFilterComposer(
                $db: db,
                $table: table,
              ),
          createOrderingComposer:
              () => $$ViewControleAcessosTableOrderingComposer(
                $db: db,
                $table: table,
              ),
          createComputedFieldComposer:
              () => $$ViewControleAcessosTableAnnotationComposer(
                $db: db,
                $table: table,
              ),
          updateCompanionCallback:
              ({
                Value<int?> id = const Value.absent(),
                Value<int?> idPessoa = const Value.absent(),
                Value<String?> pessoaNome = const Value.absent(),
                Value<int?> idColaborador = const Value.absent(),
                Value<int?> idUsuario = const Value.absent(),
                Value<String?> administrador = const Value.absent(),
                Value<int?> idPapel = const Value.absent(),
                Value<String?> papelNome = const Value.absent(),
                Value<String?> papelDescricao = const Value.absent(),
                Value<int?> idFuncao = const Value.absent(),
                Value<String?> funcaoNome = const Value.absent(),
                Value<String?> funcaoDescricao = const Value.absent(),
                Value<int?> idPapelFuncao = const Value.absent(),
                Value<String?> habilitado = const Value.absent(),
                Value<String?> podeInserir = const Value.absent(),
                Value<String?> podeAlterar = const Value.absent(),
                Value<String?> podeExcluir = const Value.absent(),
              }) => ViewControleAcessosCompanion(
                id: id,
                idPessoa: idPessoa,
                pessoaNome: pessoaNome,
                idColaborador: idColaborador,
                idUsuario: idUsuario,
                administrador: administrador,
                idPapel: idPapel,
                papelNome: papelNome,
                papelDescricao: papelDescricao,
                idFuncao: idFuncao,
                funcaoNome: funcaoNome,
                funcaoDescricao: funcaoDescricao,
                idPapelFuncao: idPapelFuncao,
                habilitado: habilitado,
                podeInserir: podeInserir,
                podeAlterar: podeAlterar,
                podeExcluir: podeExcluir,
              ),
          createCompanionCallback:
              ({
                Value<int?> id = const Value.absent(),
                Value<int?> idPessoa = const Value.absent(),
                Value<String?> pessoaNome = const Value.absent(),
                Value<int?> idColaborador = const Value.absent(),
                Value<int?> idUsuario = const Value.absent(),
                Value<String?> administrador = const Value.absent(),
                Value<int?> idPapel = const Value.absent(),
                Value<String?> papelNome = const Value.absent(),
                Value<String?> papelDescricao = const Value.absent(),
                Value<int?> idFuncao = const Value.absent(),
                Value<String?> funcaoNome = const Value.absent(),
                Value<String?> funcaoDescricao = const Value.absent(),
                Value<int?> idPapelFuncao = const Value.absent(),
                Value<String?> habilitado = const Value.absent(),
                Value<String?> podeInserir = const Value.absent(),
                Value<String?> podeAlterar = const Value.absent(),
                Value<String?> podeExcluir = const Value.absent(),
              }) => ViewControleAcessosCompanion.insert(
                id: id,
                idPessoa: idPessoa,
                pessoaNome: pessoaNome,
                idColaborador: idColaborador,
                idUsuario: idUsuario,
                administrador: administrador,
                idPapel: idPapel,
                papelNome: papelNome,
                papelDescricao: papelDescricao,
                idFuncao: idFuncao,
                funcaoNome: funcaoNome,
                funcaoDescricao: funcaoDescricao,
                idPapelFuncao: idPapelFuncao,
                habilitado: habilitado,
                podeInserir: podeInserir,
                podeAlterar: podeAlterar,
                podeExcluir: podeExcluir,
              ),
          withReferenceMapper:
              (p0) =>
                  p0
                      .map(
                        (e) => (
                          e.readTable(table),
                          BaseReferences(db, table, e),
                        ),
                      )
                      .toList(),
          prefetchHooksCallback: null,
        ),
      );
}

typedef $$ViewControleAcessosTableProcessedTableManager =
    ProcessedTableManager<
      _$AppDatabase,
      $ViewControleAcessosTable,
      ViewControleAcesso,
      $$ViewControleAcessosTableFilterComposer,
      $$ViewControleAcessosTableOrderingComposer,
      $$ViewControleAcessosTableAnnotationComposer,
      $$ViewControleAcessosTableCreateCompanionBuilder,
      $$ViewControleAcessosTableUpdateCompanionBuilder,
      (
        ViewControleAcesso,
        BaseReferences<
          _$AppDatabase,
          $ViewControleAcessosTable,
          ViewControleAcesso
        >,
      ),
      ViewControleAcesso,
      PrefetchHooks Function()
    >;
typedef $$ViewPessoaUsuariosTableCreateCompanionBuilder =
    ViewPessoaUsuariosCompanion Function({
      Value<int?> id,
      Value<int?> idPessoa,
      Value<String?> pessoaNome,
      Value<String?> tipo,
      Value<String?> email,
      Value<int?> idColaborador,
      Value<int?> idUsuario,
      Value<String?> login,
      Value<String?> senha,
      Value<DateTime?> dataCadastro,
      Value<String?> administrador,
    });
typedef $$ViewPessoaUsuariosTableUpdateCompanionBuilder =
    ViewPessoaUsuariosCompanion Function({
      Value<int?> id,
      Value<int?> idPessoa,
      Value<String?> pessoaNome,
      Value<String?> tipo,
      Value<String?> email,
      Value<int?> idColaborador,
      Value<int?> idUsuario,
      Value<String?> login,
      Value<String?> senha,
      Value<DateTime?> dataCadastro,
      Value<String?> administrador,
    });

class $$ViewPessoaUsuariosTableFilterComposer
    extends Composer<_$AppDatabase, $ViewPessoaUsuariosTable> {
  $$ViewPessoaUsuariosTableFilterComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnFilters<int> get id => $composableBuilder(
    column: $table.id,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<int> get idPessoa => $composableBuilder(
    column: $table.idPessoa,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get pessoaNome => $composableBuilder(
    column: $table.pessoaNome,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get tipo => $composableBuilder(
    column: $table.tipo,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get email => $composableBuilder(
    column: $table.email,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<int> get idColaborador => $composableBuilder(
    column: $table.idColaborador,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<int> get idUsuario => $composableBuilder(
    column: $table.idUsuario,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get login => $composableBuilder(
    column: $table.login,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get senha => $composableBuilder(
    column: $table.senha,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<DateTime> get dataCadastro => $composableBuilder(
    column: $table.dataCadastro,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get administrador => $composableBuilder(
    column: $table.administrador,
    builder: (column) => ColumnFilters(column),
  );
}

class $$ViewPessoaUsuariosTableOrderingComposer
    extends Composer<_$AppDatabase, $ViewPessoaUsuariosTable> {
  $$ViewPessoaUsuariosTableOrderingComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnOrderings<int> get id => $composableBuilder(
    column: $table.id,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<int> get idPessoa => $composableBuilder(
    column: $table.idPessoa,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get pessoaNome => $composableBuilder(
    column: $table.pessoaNome,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get tipo => $composableBuilder(
    column: $table.tipo,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get email => $composableBuilder(
    column: $table.email,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<int> get idColaborador => $composableBuilder(
    column: $table.idColaborador,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<int> get idUsuario => $composableBuilder(
    column: $table.idUsuario,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get login => $composableBuilder(
    column: $table.login,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get senha => $composableBuilder(
    column: $table.senha,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<DateTime> get dataCadastro => $composableBuilder(
    column: $table.dataCadastro,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get administrador => $composableBuilder(
    column: $table.administrador,
    builder: (column) => ColumnOrderings(column),
  );
}

class $$ViewPessoaUsuariosTableAnnotationComposer
    extends Composer<_$AppDatabase, $ViewPessoaUsuariosTable> {
  $$ViewPessoaUsuariosTableAnnotationComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  GeneratedColumn<int> get id =>
      $composableBuilder(column: $table.id, builder: (column) => column);

  GeneratedColumn<int> get idPessoa =>
      $composableBuilder(column: $table.idPessoa, builder: (column) => column);

  GeneratedColumn<String> get pessoaNome => $composableBuilder(
    column: $table.pessoaNome,
    builder: (column) => column,
  );

  GeneratedColumn<String> get tipo =>
      $composableBuilder(column: $table.tipo, builder: (column) => column);

  GeneratedColumn<String> get email =>
      $composableBuilder(column: $table.email, builder: (column) => column);

  GeneratedColumn<int> get idColaborador => $composableBuilder(
    column: $table.idColaborador,
    builder: (column) => column,
  );

  GeneratedColumn<int> get idUsuario =>
      $composableBuilder(column: $table.idUsuario, builder: (column) => column);

  GeneratedColumn<String> get login =>
      $composableBuilder(column: $table.login, builder: (column) => column);

  GeneratedColumn<String> get senha =>
      $composableBuilder(column: $table.senha, builder: (column) => column);

  GeneratedColumn<DateTime> get dataCadastro => $composableBuilder(
    column: $table.dataCadastro,
    builder: (column) => column,
  );

  GeneratedColumn<String> get administrador => $composableBuilder(
    column: $table.administrador,
    builder: (column) => column,
  );
}

class $$ViewPessoaUsuariosTableTableManager
    extends
        RootTableManager<
          _$AppDatabase,
          $ViewPessoaUsuariosTable,
          ViewPessoaUsuario,
          $$ViewPessoaUsuariosTableFilterComposer,
          $$ViewPessoaUsuariosTableOrderingComposer,
          $$ViewPessoaUsuariosTableAnnotationComposer,
          $$ViewPessoaUsuariosTableCreateCompanionBuilder,
          $$ViewPessoaUsuariosTableUpdateCompanionBuilder,
          (
            ViewPessoaUsuario,
            BaseReferences<
              _$AppDatabase,
              $ViewPessoaUsuariosTable,
              ViewPessoaUsuario
            >,
          ),
          ViewPessoaUsuario,
          PrefetchHooks Function()
        > {
  $$ViewPessoaUsuariosTableTableManager(
    _$AppDatabase db,
    $ViewPessoaUsuariosTable table,
  ) : super(
        TableManagerState(
          db: db,
          table: table,
          createFilteringComposer:
              () => $$ViewPessoaUsuariosTableFilterComposer(
                $db: db,
                $table: table,
              ),
          createOrderingComposer:
              () => $$ViewPessoaUsuariosTableOrderingComposer(
                $db: db,
                $table: table,
              ),
          createComputedFieldComposer:
              () => $$ViewPessoaUsuariosTableAnnotationComposer(
                $db: db,
                $table: table,
              ),
          updateCompanionCallback:
              ({
                Value<int?> id = const Value.absent(),
                Value<int?> idPessoa = const Value.absent(),
                Value<String?> pessoaNome = const Value.absent(),
                Value<String?> tipo = const Value.absent(),
                Value<String?> email = const Value.absent(),
                Value<int?> idColaborador = const Value.absent(),
                Value<int?> idUsuario = const Value.absent(),
                Value<String?> login = const Value.absent(),
                Value<String?> senha = const Value.absent(),
                Value<DateTime?> dataCadastro = const Value.absent(),
                Value<String?> administrador = const Value.absent(),
              }) => ViewPessoaUsuariosCompanion(
                id: id,
                idPessoa: idPessoa,
                pessoaNome: pessoaNome,
                tipo: tipo,
                email: email,
                idColaborador: idColaborador,
                idUsuario: idUsuario,
                login: login,
                senha: senha,
                dataCadastro: dataCadastro,
                administrador: administrador,
              ),
          createCompanionCallback:
              ({
                Value<int?> id = const Value.absent(),
                Value<int?> idPessoa = const Value.absent(),
                Value<String?> pessoaNome = const Value.absent(),
                Value<String?> tipo = const Value.absent(),
                Value<String?> email = const Value.absent(),
                Value<int?> idColaborador = const Value.absent(),
                Value<int?> idUsuario = const Value.absent(),
                Value<String?> login = const Value.absent(),
                Value<String?> senha = const Value.absent(),
                Value<DateTime?> dataCadastro = const Value.absent(),
                Value<String?> administrador = const Value.absent(),
              }) => ViewPessoaUsuariosCompanion.insert(
                id: id,
                idPessoa: idPessoa,
                pessoaNome: pessoaNome,
                tipo: tipo,
                email: email,
                idColaborador: idColaborador,
                idUsuario: idUsuario,
                login: login,
                senha: senha,
                dataCadastro: dataCadastro,
                administrador: administrador,
              ),
          withReferenceMapper:
              (p0) =>
                  p0
                      .map(
                        (e) => (
                          e.readTable(table),
                          BaseReferences(db, table, e),
                        ),
                      )
                      .toList(),
          prefetchHooksCallback: null,
        ),
      );
}

typedef $$ViewPessoaUsuariosTableProcessedTableManager =
    ProcessedTableManager<
      _$AppDatabase,
      $ViewPessoaUsuariosTable,
      ViewPessoaUsuario,
      $$ViewPessoaUsuariosTableFilterComposer,
      $$ViewPessoaUsuariosTableOrderingComposer,
      $$ViewPessoaUsuariosTableAnnotationComposer,
      $$ViewPessoaUsuariosTableCreateCompanionBuilder,
      $$ViewPessoaUsuariosTableUpdateCompanionBuilder,
      (
        ViewPessoaUsuario,
        BaseReferences<
          _$AppDatabase,
          $ViewPessoaUsuariosTable,
          ViewPessoaUsuario
        >,
      ),
      ViewPessoaUsuario,
      PrefetchHooks Function()
    >;
typedef $$ViewPessoaClientesTableCreateCompanionBuilder =
    ViewPessoaClientesCompanion Function({
      Value<int?> id,
      Value<String?> nome,
      Value<String?> tipo,
      Value<String?> email,
      Value<String?> site,
      Value<String?> cpfCnpj,
      Value<String?> rgIe,
      Value<DateTime?> desde,
      Value<double?> taxaDesconto,
      Value<double?> limiteCredito,
      Value<DateTime?> dataCadastro,
      Value<String?> observacao,
      Value<int?> idPessoa,
    });
typedef $$ViewPessoaClientesTableUpdateCompanionBuilder =
    ViewPessoaClientesCompanion Function({
      Value<int?> id,
      Value<String?> nome,
      Value<String?> tipo,
      Value<String?> email,
      Value<String?> site,
      Value<String?> cpfCnpj,
      Value<String?> rgIe,
      Value<DateTime?> desde,
      Value<double?> taxaDesconto,
      Value<double?> limiteCredito,
      Value<DateTime?> dataCadastro,
      Value<String?> observacao,
      Value<int?> idPessoa,
    });

class $$ViewPessoaClientesTableFilterComposer
    extends Composer<_$AppDatabase, $ViewPessoaClientesTable> {
  $$ViewPessoaClientesTableFilterComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnFilters<int> get id => $composableBuilder(
    column: $table.id,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get nome => $composableBuilder(
    column: $table.nome,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get tipo => $composableBuilder(
    column: $table.tipo,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get email => $composableBuilder(
    column: $table.email,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get site => $composableBuilder(
    column: $table.site,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get cpfCnpj => $composableBuilder(
    column: $table.cpfCnpj,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get rgIe => $composableBuilder(
    column: $table.rgIe,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<DateTime> get desde => $composableBuilder(
    column: $table.desde,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<double> get taxaDesconto => $composableBuilder(
    column: $table.taxaDesconto,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<double> get limiteCredito => $composableBuilder(
    column: $table.limiteCredito,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<DateTime> get dataCadastro => $composableBuilder(
    column: $table.dataCadastro,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get observacao => $composableBuilder(
    column: $table.observacao,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<int> get idPessoa => $composableBuilder(
    column: $table.idPessoa,
    builder: (column) => ColumnFilters(column),
  );
}

class $$ViewPessoaClientesTableOrderingComposer
    extends Composer<_$AppDatabase, $ViewPessoaClientesTable> {
  $$ViewPessoaClientesTableOrderingComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnOrderings<int> get id => $composableBuilder(
    column: $table.id,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get nome => $composableBuilder(
    column: $table.nome,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get tipo => $composableBuilder(
    column: $table.tipo,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get email => $composableBuilder(
    column: $table.email,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get site => $composableBuilder(
    column: $table.site,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get cpfCnpj => $composableBuilder(
    column: $table.cpfCnpj,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get rgIe => $composableBuilder(
    column: $table.rgIe,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<DateTime> get desde => $composableBuilder(
    column: $table.desde,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<double> get taxaDesconto => $composableBuilder(
    column: $table.taxaDesconto,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<double> get limiteCredito => $composableBuilder(
    column: $table.limiteCredito,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<DateTime> get dataCadastro => $composableBuilder(
    column: $table.dataCadastro,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get observacao => $composableBuilder(
    column: $table.observacao,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<int> get idPessoa => $composableBuilder(
    column: $table.idPessoa,
    builder: (column) => ColumnOrderings(column),
  );
}

class $$ViewPessoaClientesTableAnnotationComposer
    extends Composer<_$AppDatabase, $ViewPessoaClientesTable> {
  $$ViewPessoaClientesTableAnnotationComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  GeneratedColumn<int> get id =>
      $composableBuilder(column: $table.id, builder: (column) => column);

  GeneratedColumn<String> get nome =>
      $composableBuilder(column: $table.nome, builder: (column) => column);

  GeneratedColumn<String> get tipo =>
      $composableBuilder(column: $table.tipo, builder: (column) => column);

  GeneratedColumn<String> get email =>
      $composableBuilder(column: $table.email, builder: (column) => column);

  GeneratedColumn<String> get site =>
      $composableBuilder(column: $table.site, builder: (column) => column);

  GeneratedColumn<String> get cpfCnpj =>
      $composableBuilder(column: $table.cpfCnpj, builder: (column) => column);

  GeneratedColumn<String> get rgIe =>
      $composableBuilder(column: $table.rgIe, builder: (column) => column);

  GeneratedColumn<DateTime> get desde =>
      $composableBuilder(column: $table.desde, builder: (column) => column);

  GeneratedColumn<double> get taxaDesconto => $composableBuilder(
    column: $table.taxaDesconto,
    builder: (column) => column,
  );

  GeneratedColumn<double> get limiteCredito => $composableBuilder(
    column: $table.limiteCredito,
    builder: (column) => column,
  );

  GeneratedColumn<DateTime> get dataCadastro => $composableBuilder(
    column: $table.dataCadastro,
    builder: (column) => column,
  );

  GeneratedColumn<String> get observacao => $composableBuilder(
    column: $table.observacao,
    builder: (column) => column,
  );

  GeneratedColumn<int> get idPessoa =>
      $composableBuilder(column: $table.idPessoa, builder: (column) => column);
}

class $$ViewPessoaClientesTableTableManager
    extends
        RootTableManager<
          _$AppDatabase,
          $ViewPessoaClientesTable,
          ViewPessoaCliente,
          $$ViewPessoaClientesTableFilterComposer,
          $$ViewPessoaClientesTableOrderingComposer,
          $$ViewPessoaClientesTableAnnotationComposer,
          $$ViewPessoaClientesTableCreateCompanionBuilder,
          $$ViewPessoaClientesTableUpdateCompanionBuilder,
          (
            ViewPessoaCliente,
            BaseReferences<
              _$AppDatabase,
              $ViewPessoaClientesTable,
              ViewPessoaCliente
            >,
          ),
          ViewPessoaCliente,
          PrefetchHooks Function()
        > {
  $$ViewPessoaClientesTableTableManager(
    _$AppDatabase db,
    $ViewPessoaClientesTable table,
  ) : super(
        TableManagerState(
          db: db,
          table: table,
          createFilteringComposer:
              () => $$ViewPessoaClientesTableFilterComposer(
                $db: db,
                $table: table,
              ),
          createOrderingComposer:
              () => $$ViewPessoaClientesTableOrderingComposer(
                $db: db,
                $table: table,
              ),
          createComputedFieldComposer:
              () => $$ViewPessoaClientesTableAnnotationComposer(
                $db: db,
                $table: table,
              ),
          updateCompanionCallback:
              ({
                Value<int?> id = const Value.absent(),
                Value<String?> nome = const Value.absent(),
                Value<String?> tipo = const Value.absent(),
                Value<String?> email = const Value.absent(),
                Value<String?> site = const Value.absent(),
                Value<String?> cpfCnpj = const Value.absent(),
                Value<String?> rgIe = const Value.absent(),
                Value<DateTime?> desde = const Value.absent(),
                Value<double?> taxaDesconto = const Value.absent(),
                Value<double?> limiteCredito = const Value.absent(),
                Value<DateTime?> dataCadastro = const Value.absent(),
                Value<String?> observacao = const Value.absent(),
                Value<int?> idPessoa = const Value.absent(),
              }) => ViewPessoaClientesCompanion(
                id: id,
                nome: nome,
                tipo: tipo,
                email: email,
                site: site,
                cpfCnpj: cpfCnpj,
                rgIe: rgIe,
                desde: desde,
                taxaDesconto: taxaDesconto,
                limiteCredito: limiteCredito,
                dataCadastro: dataCadastro,
                observacao: observacao,
                idPessoa: idPessoa,
              ),
          createCompanionCallback:
              ({
                Value<int?> id = const Value.absent(),
                Value<String?> nome = const Value.absent(),
                Value<String?> tipo = const Value.absent(),
                Value<String?> email = const Value.absent(),
                Value<String?> site = const Value.absent(),
                Value<String?> cpfCnpj = const Value.absent(),
                Value<String?> rgIe = const Value.absent(),
                Value<DateTime?> desde = const Value.absent(),
                Value<double?> taxaDesconto = const Value.absent(),
                Value<double?> limiteCredito = const Value.absent(),
                Value<DateTime?> dataCadastro = const Value.absent(),
                Value<String?> observacao = const Value.absent(),
                Value<int?> idPessoa = const Value.absent(),
              }) => ViewPessoaClientesCompanion.insert(
                id: id,
                nome: nome,
                tipo: tipo,
                email: email,
                site: site,
                cpfCnpj: cpfCnpj,
                rgIe: rgIe,
                desde: desde,
                taxaDesconto: taxaDesconto,
                limiteCredito: limiteCredito,
                dataCadastro: dataCadastro,
                observacao: observacao,
                idPessoa: idPessoa,
              ),
          withReferenceMapper:
              (p0) =>
                  p0
                      .map(
                        (e) => (
                          e.readTable(table),
                          BaseReferences(db, table, e),
                        ),
                      )
                      .toList(),
          prefetchHooksCallback: null,
        ),
      );
}

typedef $$ViewPessoaClientesTableProcessedTableManager =
    ProcessedTableManager<
      _$AppDatabase,
      $ViewPessoaClientesTable,
      ViewPessoaCliente,
      $$ViewPessoaClientesTableFilterComposer,
      $$ViewPessoaClientesTableOrderingComposer,
      $$ViewPessoaClientesTableAnnotationComposer,
      $$ViewPessoaClientesTableCreateCompanionBuilder,
      $$ViewPessoaClientesTableUpdateCompanionBuilder,
      (
        ViewPessoaCliente,
        BaseReferences<
          _$AppDatabase,
          $ViewPessoaClientesTable,
          ViewPessoaCliente
        >,
      ),
      ViewPessoaCliente,
      PrefetchHooks Function()
    >;
typedef $$ViewPessoaColaboradorsTableCreateCompanionBuilder =
    ViewPessoaColaboradorsCompanion Function({
      Value<int?> id,
      Value<String?> nome,
      Value<String?> tipo,
      Value<String?> email,
      Value<String?> site,
      Value<String?> cpfCnpj,
      Value<String?> rgIe,
      Value<String?> matricula,
      Value<DateTime?> dataCadastro,
      Value<DateTime?> dataAdmissao,
      Value<DateTime?> dataDemissao,
      Value<String?> ctpsNumero,
      Value<String?> ctpsSerie,
      Value<DateTime?> ctpsDataExpedicao,
      Value<String?> ctpsUf,
      Value<String?> observacao,
      Value<String?> logradouro,
      Value<String?> numero,
      Value<String?> complemento,
      Value<String?> bairro,
      Value<String?> cidade,
      Value<String?> cep,
      Value<String?> municipioIbge,
      Value<String?> uf,
      Value<int?> idPessoa,
      Value<int?> idCargo,
      Value<int?> idSetor,
    });
typedef $$ViewPessoaColaboradorsTableUpdateCompanionBuilder =
    ViewPessoaColaboradorsCompanion Function({
      Value<int?> id,
      Value<String?> nome,
      Value<String?> tipo,
      Value<String?> email,
      Value<String?> site,
      Value<String?> cpfCnpj,
      Value<String?> rgIe,
      Value<String?> matricula,
      Value<DateTime?> dataCadastro,
      Value<DateTime?> dataAdmissao,
      Value<DateTime?> dataDemissao,
      Value<String?> ctpsNumero,
      Value<String?> ctpsSerie,
      Value<DateTime?> ctpsDataExpedicao,
      Value<String?> ctpsUf,
      Value<String?> observacao,
      Value<String?> logradouro,
      Value<String?> numero,
      Value<String?> complemento,
      Value<String?> bairro,
      Value<String?> cidade,
      Value<String?> cep,
      Value<String?> municipioIbge,
      Value<String?> uf,
      Value<int?> idPessoa,
      Value<int?> idCargo,
      Value<int?> idSetor,
    });

class $$ViewPessoaColaboradorsTableFilterComposer
    extends Composer<_$AppDatabase, $ViewPessoaColaboradorsTable> {
  $$ViewPessoaColaboradorsTableFilterComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnFilters<int> get id => $composableBuilder(
    column: $table.id,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get nome => $composableBuilder(
    column: $table.nome,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get tipo => $composableBuilder(
    column: $table.tipo,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get email => $composableBuilder(
    column: $table.email,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get site => $composableBuilder(
    column: $table.site,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get cpfCnpj => $composableBuilder(
    column: $table.cpfCnpj,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get rgIe => $composableBuilder(
    column: $table.rgIe,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get matricula => $composableBuilder(
    column: $table.matricula,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<DateTime> get dataCadastro => $composableBuilder(
    column: $table.dataCadastro,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<DateTime> get dataAdmissao => $composableBuilder(
    column: $table.dataAdmissao,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<DateTime> get dataDemissao => $composableBuilder(
    column: $table.dataDemissao,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get ctpsNumero => $composableBuilder(
    column: $table.ctpsNumero,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get ctpsSerie => $composableBuilder(
    column: $table.ctpsSerie,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<DateTime> get ctpsDataExpedicao => $composableBuilder(
    column: $table.ctpsDataExpedicao,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get ctpsUf => $composableBuilder(
    column: $table.ctpsUf,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get observacao => $composableBuilder(
    column: $table.observacao,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get logradouro => $composableBuilder(
    column: $table.logradouro,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get numero => $composableBuilder(
    column: $table.numero,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get complemento => $composableBuilder(
    column: $table.complemento,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get bairro => $composableBuilder(
    column: $table.bairro,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get cidade => $composableBuilder(
    column: $table.cidade,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get cep => $composableBuilder(
    column: $table.cep,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get municipioIbge => $composableBuilder(
    column: $table.municipioIbge,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get uf => $composableBuilder(
    column: $table.uf,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<int> get idPessoa => $composableBuilder(
    column: $table.idPessoa,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<int> get idCargo => $composableBuilder(
    column: $table.idCargo,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<int> get idSetor => $composableBuilder(
    column: $table.idSetor,
    builder: (column) => ColumnFilters(column),
  );
}

class $$ViewPessoaColaboradorsTableOrderingComposer
    extends Composer<_$AppDatabase, $ViewPessoaColaboradorsTable> {
  $$ViewPessoaColaboradorsTableOrderingComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnOrderings<int> get id => $composableBuilder(
    column: $table.id,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get nome => $composableBuilder(
    column: $table.nome,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get tipo => $composableBuilder(
    column: $table.tipo,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get email => $composableBuilder(
    column: $table.email,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get site => $composableBuilder(
    column: $table.site,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get cpfCnpj => $composableBuilder(
    column: $table.cpfCnpj,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get rgIe => $composableBuilder(
    column: $table.rgIe,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get matricula => $composableBuilder(
    column: $table.matricula,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<DateTime> get dataCadastro => $composableBuilder(
    column: $table.dataCadastro,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<DateTime> get dataAdmissao => $composableBuilder(
    column: $table.dataAdmissao,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<DateTime> get dataDemissao => $composableBuilder(
    column: $table.dataDemissao,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get ctpsNumero => $composableBuilder(
    column: $table.ctpsNumero,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get ctpsSerie => $composableBuilder(
    column: $table.ctpsSerie,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<DateTime> get ctpsDataExpedicao => $composableBuilder(
    column: $table.ctpsDataExpedicao,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get ctpsUf => $composableBuilder(
    column: $table.ctpsUf,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get observacao => $composableBuilder(
    column: $table.observacao,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get logradouro => $composableBuilder(
    column: $table.logradouro,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get numero => $composableBuilder(
    column: $table.numero,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get complemento => $composableBuilder(
    column: $table.complemento,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get bairro => $composableBuilder(
    column: $table.bairro,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get cidade => $composableBuilder(
    column: $table.cidade,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get cep => $composableBuilder(
    column: $table.cep,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get municipioIbge => $composableBuilder(
    column: $table.municipioIbge,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get uf => $composableBuilder(
    column: $table.uf,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<int> get idPessoa => $composableBuilder(
    column: $table.idPessoa,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<int> get idCargo => $composableBuilder(
    column: $table.idCargo,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<int> get idSetor => $composableBuilder(
    column: $table.idSetor,
    builder: (column) => ColumnOrderings(column),
  );
}

class $$ViewPessoaColaboradorsTableAnnotationComposer
    extends Composer<_$AppDatabase, $ViewPessoaColaboradorsTable> {
  $$ViewPessoaColaboradorsTableAnnotationComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  GeneratedColumn<int> get id =>
      $composableBuilder(column: $table.id, builder: (column) => column);

  GeneratedColumn<String> get nome =>
      $composableBuilder(column: $table.nome, builder: (column) => column);

  GeneratedColumn<String> get tipo =>
      $composableBuilder(column: $table.tipo, builder: (column) => column);

  GeneratedColumn<String> get email =>
      $composableBuilder(column: $table.email, builder: (column) => column);

  GeneratedColumn<String> get site =>
      $composableBuilder(column: $table.site, builder: (column) => column);

  GeneratedColumn<String> get cpfCnpj =>
      $composableBuilder(column: $table.cpfCnpj, builder: (column) => column);

  GeneratedColumn<String> get rgIe =>
      $composableBuilder(column: $table.rgIe, builder: (column) => column);

  GeneratedColumn<String> get matricula =>
      $composableBuilder(column: $table.matricula, builder: (column) => column);

  GeneratedColumn<DateTime> get dataCadastro => $composableBuilder(
    column: $table.dataCadastro,
    builder: (column) => column,
  );

  GeneratedColumn<DateTime> get dataAdmissao => $composableBuilder(
    column: $table.dataAdmissao,
    builder: (column) => column,
  );

  GeneratedColumn<DateTime> get dataDemissao => $composableBuilder(
    column: $table.dataDemissao,
    builder: (column) => column,
  );

  GeneratedColumn<String> get ctpsNumero => $composableBuilder(
    column: $table.ctpsNumero,
    builder: (column) => column,
  );

  GeneratedColumn<String> get ctpsSerie =>
      $composableBuilder(column: $table.ctpsSerie, builder: (column) => column);

  GeneratedColumn<DateTime> get ctpsDataExpedicao => $composableBuilder(
    column: $table.ctpsDataExpedicao,
    builder: (column) => column,
  );

  GeneratedColumn<String> get ctpsUf =>
      $composableBuilder(column: $table.ctpsUf, builder: (column) => column);

  GeneratedColumn<String> get observacao => $composableBuilder(
    column: $table.observacao,
    builder: (column) => column,
  );

  GeneratedColumn<String> get logradouro => $composableBuilder(
    column: $table.logradouro,
    builder: (column) => column,
  );

  GeneratedColumn<String> get numero =>
      $composableBuilder(column: $table.numero, builder: (column) => column);

  GeneratedColumn<String> get complemento => $composableBuilder(
    column: $table.complemento,
    builder: (column) => column,
  );

  GeneratedColumn<String> get bairro =>
      $composableBuilder(column: $table.bairro, builder: (column) => column);

  GeneratedColumn<String> get cidade =>
      $composableBuilder(column: $table.cidade, builder: (column) => column);

  GeneratedColumn<String> get cep =>
      $composableBuilder(column: $table.cep, builder: (column) => column);

  GeneratedColumn<String> get municipioIbge => $composableBuilder(
    column: $table.municipioIbge,
    builder: (column) => column,
  );

  GeneratedColumn<String> get uf =>
      $composableBuilder(column: $table.uf, builder: (column) => column);

  GeneratedColumn<int> get idPessoa =>
      $composableBuilder(column: $table.idPessoa, builder: (column) => column);

  GeneratedColumn<int> get idCargo =>
      $composableBuilder(column: $table.idCargo, builder: (column) => column);

  GeneratedColumn<int> get idSetor =>
      $composableBuilder(column: $table.idSetor, builder: (column) => column);
}

class $$ViewPessoaColaboradorsTableTableManager
    extends
        RootTableManager<
          _$AppDatabase,
          $ViewPessoaColaboradorsTable,
          ViewPessoaColaborador,
          $$ViewPessoaColaboradorsTableFilterComposer,
          $$ViewPessoaColaboradorsTableOrderingComposer,
          $$ViewPessoaColaboradorsTableAnnotationComposer,
          $$ViewPessoaColaboradorsTableCreateCompanionBuilder,
          $$ViewPessoaColaboradorsTableUpdateCompanionBuilder,
          (
            ViewPessoaColaborador,
            BaseReferences<
              _$AppDatabase,
              $ViewPessoaColaboradorsTable,
              ViewPessoaColaborador
            >,
          ),
          ViewPessoaColaborador,
          PrefetchHooks Function()
        > {
  $$ViewPessoaColaboradorsTableTableManager(
    _$AppDatabase db,
    $ViewPessoaColaboradorsTable table,
  ) : super(
        TableManagerState(
          db: db,
          table: table,
          createFilteringComposer:
              () => $$ViewPessoaColaboradorsTableFilterComposer(
                $db: db,
                $table: table,
              ),
          createOrderingComposer:
              () => $$ViewPessoaColaboradorsTableOrderingComposer(
                $db: db,
                $table: table,
              ),
          createComputedFieldComposer:
              () => $$ViewPessoaColaboradorsTableAnnotationComposer(
                $db: db,
                $table: table,
              ),
          updateCompanionCallback:
              ({
                Value<int?> id = const Value.absent(),
                Value<String?> nome = const Value.absent(),
                Value<String?> tipo = const Value.absent(),
                Value<String?> email = const Value.absent(),
                Value<String?> site = const Value.absent(),
                Value<String?> cpfCnpj = const Value.absent(),
                Value<String?> rgIe = const Value.absent(),
                Value<String?> matricula = const Value.absent(),
                Value<DateTime?> dataCadastro = const Value.absent(),
                Value<DateTime?> dataAdmissao = const Value.absent(),
                Value<DateTime?> dataDemissao = const Value.absent(),
                Value<String?> ctpsNumero = const Value.absent(),
                Value<String?> ctpsSerie = const Value.absent(),
                Value<DateTime?> ctpsDataExpedicao = const Value.absent(),
                Value<String?> ctpsUf = const Value.absent(),
                Value<String?> observacao = const Value.absent(),
                Value<String?> logradouro = const Value.absent(),
                Value<String?> numero = const Value.absent(),
                Value<String?> complemento = const Value.absent(),
                Value<String?> bairro = const Value.absent(),
                Value<String?> cidade = const Value.absent(),
                Value<String?> cep = const Value.absent(),
                Value<String?> municipioIbge = const Value.absent(),
                Value<String?> uf = const Value.absent(),
                Value<int?> idPessoa = const Value.absent(),
                Value<int?> idCargo = const Value.absent(),
                Value<int?> idSetor = const Value.absent(),
              }) => ViewPessoaColaboradorsCompanion(
                id: id,
                nome: nome,
                tipo: tipo,
                email: email,
                site: site,
                cpfCnpj: cpfCnpj,
                rgIe: rgIe,
                matricula: matricula,
                dataCadastro: dataCadastro,
                dataAdmissao: dataAdmissao,
                dataDemissao: dataDemissao,
                ctpsNumero: ctpsNumero,
                ctpsSerie: ctpsSerie,
                ctpsDataExpedicao: ctpsDataExpedicao,
                ctpsUf: ctpsUf,
                observacao: observacao,
                logradouro: logradouro,
                numero: numero,
                complemento: complemento,
                bairro: bairro,
                cidade: cidade,
                cep: cep,
                municipioIbge: municipioIbge,
                uf: uf,
                idPessoa: idPessoa,
                idCargo: idCargo,
                idSetor: idSetor,
              ),
          createCompanionCallback:
              ({
                Value<int?> id = const Value.absent(),
                Value<String?> nome = const Value.absent(),
                Value<String?> tipo = const Value.absent(),
                Value<String?> email = const Value.absent(),
                Value<String?> site = const Value.absent(),
                Value<String?> cpfCnpj = const Value.absent(),
                Value<String?> rgIe = const Value.absent(),
                Value<String?> matricula = const Value.absent(),
                Value<DateTime?> dataCadastro = const Value.absent(),
                Value<DateTime?> dataAdmissao = const Value.absent(),
                Value<DateTime?> dataDemissao = const Value.absent(),
                Value<String?> ctpsNumero = const Value.absent(),
                Value<String?> ctpsSerie = const Value.absent(),
                Value<DateTime?> ctpsDataExpedicao = const Value.absent(),
                Value<String?> ctpsUf = const Value.absent(),
                Value<String?> observacao = const Value.absent(),
                Value<String?> logradouro = const Value.absent(),
                Value<String?> numero = const Value.absent(),
                Value<String?> complemento = const Value.absent(),
                Value<String?> bairro = const Value.absent(),
                Value<String?> cidade = const Value.absent(),
                Value<String?> cep = const Value.absent(),
                Value<String?> municipioIbge = const Value.absent(),
                Value<String?> uf = const Value.absent(),
                Value<int?> idPessoa = const Value.absent(),
                Value<int?> idCargo = const Value.absent(),
                Value<int?> idSetor = const Value.absent(),
              }) => ViewPessoaColaboradorsCompanion.insert(
                id: id,
                nome: nome,
                tipo: tipo,
                email: email,
                site: site,
                cpfCnpj: cpfCnpj,
                rgIe: rgIe,
                matricula: matricula,
                dataCadastro: dataCadastro,
                dataAdmissao: dataAdmissao,
                dataDemissao: dataDemissao,
                ctpsNumero: ctpsNumero,
                ctpsSerie: ctpsSerie,
                ctpsDataExpedicao: ctpsDataExpedicao,
                ctpsUf: ctpsUf,
                observacao: observacao,
                logradouro: logradouro,
                numero: numero,
                complemento: complemento,
                bairro: bairro,
                cidade: cidade,
                cep: cep,
                municipioIbge: municipioIbge,
                uf: uf,
                idPessoa: idPessoa,
                idCargo: idCargo,
                idSetor: idSetor,
              ),
          withReferenceMapper:
              (p0) =>
                  p0
                      .map(
                        (e) => (
                          e.readTable(table),
                          BaseReferences(db, table, e),
                        ),
                      )
                      .toList(),
          prefetchHooksCallback: null,
        ),
      );
}

typedef $$ViewPessoaColaboradorsTableProcessedTableManager =
    ProcessedTableManager<
      _$AppDatabase,
      $ViewPessoaColaboradorsTable,
      ViewPessoaColaborador,
      $$ViewPessoaColaboradorsTableFilterComposer,
      $$ViewPessoaColaboradorsTableOrderingComposer,
      $$ViewPessoaColaboradorsTableAnnotationComposer,
      $$ViewPessoaColaboradorsTableCreateCompanionBuilder,
      $$ViewPessoaColaboradorsTableUpdateCompanionBuilder,
      (
        ViewPessoaColaborador,
        BaseReferences<
          _$AppDatabase,
          $ViewPessoaColaboradorsTable,
          ViewPessoaColaborador
        >,
      ),
      ViewPessoaColaborador,
      PrefetchHooks Function()
    >;
typedef $$CrmContatosTableCreateCompanionBuilder =
    CrmContatosCompanion Function({
      Value<int?> id,
      Value<int?> idCliente,
      Value<int?> idViewPessoaColaborador,
      Value<String?> tipoContato,
      Value<String?> horaContato,
      Value<String?> assunto,
      Value<String?> descricao,
      Value<String?> resultado,
      Value<DateTime?> proximaData,
      Value<String?> proximaAcao,
    });
typedef $$CrmContatosTableUpdateCompanionBuilder =
    CrmContatosCompanion Function({
      Value<int?> id,
      Value<int?> idCliente,
      Value<int?> idViewPessoaColaborador,
      Value<String?> tipoContato,
      Value<String?> horaContato,
      Value<String?> assunto,
      Value<String?> descricao,
      Value<String?> resultado,
      Value<DateTime?> proximaData,
      Value<String?> proximaAcao,
    });

class $$CrmContatosTableFilterComposer
    extends Composer<_$AppDatabase, $CrmContatosTable> {
  $$CrmContatosTableFilterComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnFilters<int> get id => $composableBuilder(
    column: $table.id,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<int> get idCliente => $composableBuilder(
    column: $table.idCliente,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<int> get idViewPessoaColaborador => $composableBuilder(
    column: $table.idViewPessoaColaborador,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get tipoContato => $composableBuilder(
    column: $table.tipoContato,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get horaContato => $composableBuilder(
    column: $table.horaContato,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get assunto => $composableBuilder(
    column: $table.assunto,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get descricao => $composableBuilder(
    column: $table.descricao,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get resultado => $composableBuilder(
    column: $table.resultado,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<DateTime> get proximaData => $composableBuilder(
    column: $table.proximaData,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get proximaAcao => $composableBuilder(
    column: $table.proximaAcao,
    builder: (column) => ColumnFilters(column),
  );
}

class $$CrmContatosTableOrderingComposer
    extends Composer<_$AppDatabase, $CrmContatosTable> {
  $$CrmContatosTableOrderingComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnOrderings<int> get id => $composableBuilder(
    column: $table.id,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<int> get idCliente => $composableBuilder(
    column: $table.idCliente,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<int> get idViewPessoaColaborador => $composableBuilder(
    column: $table.idViewPessoaColaborador,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get tipoContato => $composableBuilder(
    column: $table.tipoContato,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get horaContato => $composableBuilder(
    column: $table.horaContato,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get assunto => $composableBuilder(
    column: $table.assunto,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get descricao => $composableBuilder(
    column: $table.descricao,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get resultado => $composableBuilder(
    column: $table.resultado,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<DateTime> get proximaData => $composableBuilder(
    column: $table.proximaData,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get proximaAcao => $composableBuilder(
    column: $table.proximaAcao,
    builder: (column) => ColumnOrderings(column),
  );
}

class $$CrmContatosTableAnnotationComposer
    extends Composer<_$AppDatabase, $CrmContatosTable> {
  $$CrmContatosTableAnnotationComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  GeneratedColumn<int> get id =>
      $composableBuilder(column: $table.id, builder: (column) => column);

  GeneratedColumn<int> get idCliente =>
      $composableBuilder(column: $table.idCliente, builder: (column) => column);

  GeneratedColumn<int> get idViewPessoaColaborador => $composableBuilder(
    column: $table.idViewPessoaColaborador,
    builder: (column) => column,
  );

  GeneratedColumn<String> get tipoContato => $composableBuilder(
    column: $table.tipoContato,
    builder: (column) => column,
  );

  GeneratedColumn<String> get horaContato => $composableBuilder(
    column: $table.horaContato,
    builder: (column) => column,
  );

  GeneratedColumn<String> get assunto =>
      $composableBuilder(column: $table.assunto, builder: (column) => column);

  GeneratedColumn<String> get descricao =>
      $composableBuilder(column: $table.descricao, builder: (column) => column);

  GeneratedColumn<String> get resultado =>
      $composableBuilder(column: $table.resultado, builder: (column) => column);

  GeneratedColumn<DateTime> get proximaData => $composableBuilder(
    column: $table.proximaData,
    builder: (column) => column,
  );

  GeneratedColumn<String> get proximaAcao => $composableBuilder(
    column: $table.proximaAcao,
    builder: (column) => column,
  );
}

class $$CrmContatosTableTableManager
    extends
        RootTableManager<
          _$AppDatabase,
          $CrmContatosTable,
          CrmContato,
          $$CrmContatosTableFilterComposer,
          $$CrmContatosTableOrderingComposer,
          $$CrmContatosTableAnnotationComposer,
          $$CrmContatosTableCreateCompanionBuilder,
          $$CrmContatosTableUpdateCompanionBuilder,
          (
            CrmContato,
            BaseReferences<_$AppDatabase, $CrmContatosTable, CrmContato>,
          ),
          CrmContato,
          PrefetchHooks Function()
        > {
  $$CrmContatosTableTableManager(_$AppDatabase db, $CrmContatosTable table)
    : super(
        TableManagerState(
          db: db,
          table: table,
          createFilteringComposer:
              () => $$CrmContatosTableFilterComposer($db: db, $table: table),
          createOrderingComposer:
              () => $$CrmContatosTableOrderingComposer($db: db, $table: table),
          createComputedFieldComposer:
              () =>
                  $$CrmContatosTableAnnotationComposer($db: db, $table: table),
          updateCompanionCallback:
              ({
                Value<int?> id = const Value.absent(),
                Value<int?> idCliente = const Value.absent(),
                Value<int?> idViewPessoaColaborador = const Value.absent(),
                Value<String?> tipoContato = const Value.absent(),
                Value<String?> horaContato = const Value.absent(),
                Value<String?> assunto = const Value.absent(),
                Value<String?> descricao = const Value.absent(),
                Value<String?> resultado = const Value.absent(),
                Value<DateTime?> proximaData = const Value.absent(),
                Value<String?> proximaAcao = const Value.absent(),
              }) => CrmContatosCompanion(
                id: id,
                idCliente: idCliente,
                idViewPessoaColaborador: idViewPessoaColaborador,
                tipoContato: tipoContato,
                horaContato: horaContato,
                assunto: assunto,
                descricao: descricao,
                resultado: resultado,
                proximaData: proximaData,
                proximaAcao: proximaAcao,
              ),
          createCompanionCallback:
              ({
                Value<int?> id = const Value.absent(),
                Value<int?> idCliente = const Value.absent(),
                Value<int?> idViewPessoaColaborador = const Value.absent(),
                Value<String?> tipoContato = const Value.absent(),
                Value<String?> horaContato = const Value.absent(),
                Value<String?> assunto = const Value.absent(),
                Value<String?> descricao = const Value.absent(),
                Value<String?> resultado = const Value.absent(),
                Value<DateTime?> proximaData = const Value.absent(),
                Value<String?> proximaAcao = const Value.absent(),
              }) => CrmContatosCompanion.insert(
                id: id,
                idCliente: idCliente,
                idViewPessoaColaborador: idViewPessoaColaborador,
                tipoContato: tipoContato,
                horaContato: horaContato,
                assunto: assunto,
                descricao: descricao,
                resultado: resultado,
                proximaData: proximaData,
                proximaAcao: proximaAcao,
              ),
          withReferenceMapper:
              (p0) =>
                  p0
                      .map(
                        (e) => (
                          e.readTable(table),
                          BaseReferences(db, table, e),
                        ),
                      )
                      .toList(),
          prefetchHooksCallback: null,
        ),
      );
}

typedef $$CrmContatosTableProcessedTableManager =
    ProcessedTableManager<
      _$AppDatabase,
      $CrmContatosTable,
      CrmContato,
      $$CrmContatosTableFilterComposer,
      $$CrmContatosTableOrderingComposer,
      $$CrmContatosTableAnnotationComposer,
      $$CrmContatosTableCreateCompanionBuilder,
      $$CrmContatosTableUpdateCompanionBuilder,
      (
        CrmContato,
        BaseReferences<_$AppDatabase, $CrmContatosTable, CrmContato>,
      ),
      CrmContato,
      PrefetchHooks Function()
    >;
typedef $$CrmOportunidadesTableCreateCompanionBuilder =
    CrmOportunidadesCompanion Function({
      Value<int?> id,
      Value<int?> idCliente,
      Value<int?> idViewPessoaColaborador,
      Value<String?> titulo,
      Value<String?> descricao,
      Value<double?> valorEstimado,
      Value<DateTime?> dataAbertura,
      Value<DateTime?> dataFechamentoPrevisto,
      Value<DateTime?> dataFechamentoReal,
      Value<String?> status,
      Value<String?> motivoFechamento,
      Value<int?> probabilidade,
    });
typedef $$CrmOportunidadesTableUpdateCompanionBuilder =
    CrmOportunidadesCompanion Function({
      Value<int?> id,
      Value<int?> idCliente,
      Value<int?> idViewPessoaColaborador,
      Value<String?> titulo,
      Value<String?> descricao,
      Value<double?> valorEstimado,
      Value<DateTime?> dataAbertura,
      Value<DateTime?> dataFechamentoPrevisto,
      Value<DateTime?> dataFechamentoReal,
      Value<String?> status,
      Value<String?> motivoFechamento,
      Value<int?> probabilidade,
    });

class $$CrmOportunidadesTableFilterComposer
    extends Composer<_$AppDatabase, $CrmOportunidadesTable> {
  $$CrmOportunidadesTableFilterComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnFilters<int> get id => $composableBuilder(
    column: $table.id,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<int> get idCliente => $composableBuilder(
    column: $table.idCliente,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<int> get idViewPessoaColaborador => $composableBuilder(
    column: $table.idViewPessoaColaborador,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get titulo => $composableBuilder(
    column: $table.titulo,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get descricao => $composableBuilder(
    column: $table.descricao,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<double> get valorEstimado => $composableBuilder(
    column: $table.valorEstimado,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<DateTime> get dataAbertura => $composableBuilder(
    column: $table.dataAbertura,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<DateTime> get dataFechamentoPrevisto => $composableBuilder(
    column: $table.dataFechamentoPrevisto,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<DateTime> get dataFechamentoReal => $composableBuilder(
    column: $table.dataFechamentoReal,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get status => $composableBuilder(
    column: $table.status,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get motivoFechamento => $composableBuilder(
    column: $table.motivoFechamento,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<int> get probabilidade => $composableBuilder(
    column: $table.probabilidade,
    builder: (column) => ColumnFilters(column),
  );
}

class $$CrmOportunidadesTableOrderingComposer
    extends Composer<_$AppDatabase, $CrmOportunidadesTable> {
  $$CrmOportunidadesTableOrderingComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnOrderings<int> get id => $composableBuilder(
    column: $table.id,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<int> get idCliente => $composableBuilder(
    column: $table.idCliente,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<int> get idViewPessoaColaborador => $composableBuilder(
    column: $table.idViewPessoaColaborador,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get titulo => $composableBuilder(
    column: $table.titulo,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get descricao => $composableBuilder(
    column: $table.descricao,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<double> get valorEstimado => $composableBuilder(
    column: $table.valorEstimado,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<DateTime> get dataAbertura => $composableBuilder(
    column: $table.dataAbertura,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<DateTime> get dataFechamentoPrevisto => $composableBuilder(
    column: $table.dataFechamentoPrevisto,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<DateTime> get dataFechamentoReal => $composableBuilder(
    column: $table.dataFechamentoReal,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get status => $composableBuilder(
    column: $table.status,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get motivoFechamento => $composableBuilder(
    column: $table.motivoFechamento,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<int> get probabilidade => $composableBuilder(
    column: $table.probabilidade,
    builder: (column) => ColumnOrderings(column),
  );
}

class $$CrmOportunidadesTableAnnotationComposer
    extends Composer<_$AppDatabase, $CrmOportunidadesTable> {
  $$CrmOportunidadesTableAnnotationComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  GeneratedColumn<int> get id =>
      $composableBuilder(column: $table.id, builder: (column) => column);

  GeneratedColumn<int> get idCliente =>
      $composableBuilder(column: $table.idCliente, builder: (column) => column);

  GeneratedColumn<int> get idViewPessoaColaborador => $composableBuilder(
    column: $table.idViewPessoaColaborador,
    builder: (column) => column,
  );

  GeneratedColumn<String> get titulo =>
      $composableBuilder(column: $table.titulo, builder: (column) => column);

  GeneratedColumn<String> get descricao =>
      $composableBuilder(column: $table.descricao, builder: (column) => column);

  GeneratedColumn<double> get valorEstimado => $composableBuilder(
    column: $table.valorEstimado,
    builder: (column) => column,
  );

  GeneratedColumn<DateTime> get dataAbertura => $composableBuilder(
    column: $table.dataAbertura,
    builder: (column) => column,
  );

  GeneratedColumn<DateTime> get dataFechamentoPrevisto => $composableBuilder(
    column: $table.dataFechamentoPrevisto,
    builder: (column) => column,
  );

  GeneratedColumn<DateTime> get dataFechamentoReal => $composableBuilder(
    column: $table.dataFechamentoReal,
    builder: (column) => column,
  );

  GeneratedColumn<String> get status =>
      $composableBuilder(column: $table.status, builder: (column) => column);

  GeneratedColumn<String> get motivoFechamento => $composableBuilder(
    column: $table.motivoFechamento,
    builder: (column) => column,
  );

  GeneratedColumn<int> get probabilidade => $composableBuilder(
    column: $table.probabilidade,
    builder: (column) => column,
  );
}

class $$CrmOportunidadesTableTableManager
    extends
        RootTableManager<
          _$AppDatabase,
          $CrmOportunidadesTable,
          CrmOportunidade,
          $$CrmOportunidadesTableFilterComposer,
          $$CrmOportunidadesTableOrderingComposer,
          $$CrmOportunidadesTableAnnotationComposer,
          $$CrmOportunidadesTableCreateCompanionBuilder,
          $$CrmOportunidadesTableUpdateCompanionBuilder,
          (
            CrmOportunidade,
            BaseReferences<
              _$AppDatabase,
              $CrmOportunidadesTable,
              CrmOportunidade
            >,
          ),
          CrmOportunidade,
          PrefetchHooks Function()
        > {
  $$CrmOportunidadesTableTableManager(
    _$AppDatabase db,
    $CrmOportunidadesTable table,
  ) : super(
        TableManagerState(
          db: db,
          table: table,
          createFilteringComposer:
              () =>
                  $$CrmOportunidadesTableFilterComposer($db: db, $table: table),
          createOrderingComposer:
              () => $$CrmOportunidadesTableOrderingComposer(
                $db: db,
                $table: table,
              ),
          createComputedFieldComposer:
              () => $$CrmOportunidadesTableAnnotationComposer(
                $db: db,
                $table: table,
              ),
          updateCompanionCallback:
              ({
                Value<int?> id = const Value.absent(),
                Value<int?> idCliente = const Value.absent(),
                Value<int?> idViewPessoaColaborador = const Value.absent(),
                Value<String?> titulo = const Value.absent(),
                Value<String?> descricao = const Value.absent(),
                Value<double?> valorEstimado = const Value.absent(),
                Value<DateTime?> dataAbertura = const Value.absent(),
                Value<DateTime?> dataFechamentoPrevisto = const Value.absent(),
                Value<DateTime?> dataFechamentoReal = const Value.absent(),
                Value<String?> status = const Value.absent(),
                Value<String?> motivoFechamento = const Value.absent(),
                Value<int?> probabilidade = const Value.absent(),
              }) => CrmOportunidadesCompanion(
                id: id,
                idCliente: idCliente,
                idViewPessoaColaborador: idViewPessoaColaborador,
                titulo: titulo,
                descricao: descricao,
                valorEstimado: valorEstimado,
                dataAbertura: dataAbertura,
                dataFechamentoPrevisto: dataFechamentoPrevisto,
                dataFechamentoReal: dataFechamentoReal,
                status: status,
                motivoFechamento: motivoFechamento,
                probabilidade: probabilidade,
              ),
          createCompanionCallback:
              ({
                Value<int?> id = const Value.absent(),
                Value<int?> idCliente = const Value.absent(),
                Value<int?> idViewPessoaColaborador = const Value.absent(),
                Value<String?> titulo = const Value.absent(),
                Value<String?> descricao = const Value.absent(),
                Value<double?> valorEstimado = const Value.absent(),
                Value<DateTime?> dataAbertura = const Value.absent(),
                Value<DateTime?> dataFechamentoPrevisto = const Value.absent(),
                Value<DateTime?> dataFechamentoReal = const Value.absent(),
                Value<String?> status = const Value.absent(),
                Value<String?> motivoFechamento = const Value.absent(),
                Value<int?> probabilidade = const Value.absent(),
              }) => CrmOportunidadesCompanion.insert(
                id: id,
                idCliente: idCliente,
                idViewPessoaColaborador: idViewPessoaColaborador,
                titulo: titulo,
                descricao: descricao,
                valorEstimado: valorEstimado,
                dataAbertura: dataAbertura,
                dataFechamentoPrevisto: dataFechamentoPrevisto,
                dataFechamentoReal: dataFechamentoReal,
                status: status,
                motivoFechamento: motivoFechamento,
                probabilidade: probabilidade,
              ),
          withReferenceMapper:
              (p0) =>
                  p0
                      .map(
                        (e) => (
                          e.readTable(table),
                          BaseReferences(db, table, e),
                        ),
                      )
                      .toList(),
          prefetchHooksCallback: null,
        ),
      );
}

typedef $$CrmOportunidadesTableProcessedTableManager =
    ProcessedTableManager<
      _$AppDatabase,
      $CrmOportunidadesTable,
      CrmOportunidade,
      $$CrmOportunidadesTableFilterComposer,
      $$CrmOportunidadesTableOrderingComposer,
      $$CrmOportunidadesTableAnnotationComposer,
      $$CrmOportunidadesTableCreateCompanionBuilder,
      $$CrmOportunidadesTableUpdateCompanionBuilder,
      (
        CrmOportunidade,
        BaseReferences<_$AppDatabase, $CrmOportunidadesTable, CrmOportunidade>,
      ),
      CrmOportunidade,
      PrefetchHooks Function()
    >;
typedef $$CrmTarefasTableCreateCompanionBuilder =
    CrmTarefasCompanion Function({
      Value<int?> id,
      Value<int?> idCliente,
      Value<int?> idOportunidade,
      Value<String?> titulo,
      Value<String?> descricao,
      Value<String?> prioridade,
      Value<DateTime?> dataCriacao,
      Value<DateTime?> dataVencimento,
      Value<DateTime?> dataConclusao,
      Value<String?> status,
    });
typedef $$CrmTarefasTableUpdateCompanionBuilder =
    CrmTarefasCompanion Function({
      Value<int?> id,
      Value<int?> idCliente,
      Value<int?> idOportunidade,
      Value<String?> titulo,
      Value<String?> descricao,
      Value<String?> prioridade,
      Value<DateTime?> dataCriacao,
      Value<DateTime?> dataVencimento,
      Value<DateTime?> dataConclusao,
      Value<String?> status,
    });

class $$CrmTarefasTableFilterComposer
    extends Composer<_$AppDatabase, $CrmTarefasTable> {
  $$CrmTarefasTableFilterComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnFilters<int> get id => $composableBuilder(
    column: $table.id,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<int> get idCliente => $composableBuilder(
    column: $table.idCliente,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<int> get idOportunidade => $composableBuilder(
    column: $table.idOportunidade,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get titulo => $composableBuilder(
    column: $table.titulo,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get descricao => $composableBuilder(
    column: $table.descricao,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get prioridade => $composableBuilder(
    column: $table.prioridade,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<DateTime> get dataCriacao => $composableBuilder(
    column: $table.dataCriacao,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<DateTime> get dataVencimento => $composableBuilder(
    column: $table.dataVencimento,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<DateTime> get dataConclusao => $composableBuilder(
    column: $table.dataConclusao,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get status => $composableBuilder(
    column: $table.status,
    builder: (column) => ColumnFilters(column),
  );
}

class $$CrmTarefasTableOrderingComposer
    extends Composer<_$AppDatabase, $CrmTarefasTable> {
  $$CrmTarefasTableOrderingComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnOrderings<int> get id => $composableBuilder(
    column: $table.id,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<int> get idCliente => $composableBuilder(
    column: $table.idCliente,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<int> get idOportunidade => $composableBuilder(
    column: $table.idOportunidade,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get titulo => $composableBuilder(
    column: $table.titulo,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get descricao => $composableBuilder(
    column: $table.descricao,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get prioridade => $composableBuilder(
    column: $table.prioridade,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<DateTime> get dataCriacao => $composableBuilder(
    column: $table.dataCriacao,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<DateTime> get dataVencimento => $composableBuilder(
    column: $table.dataVencimento,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<DateTime> get dataConclusao => $composableBuilder(
    column: $table.dataConclusao,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get status => $composableBuilder(
    column: $table.status,
    builder: (column) => ColumnOrderings(column),
  );
}

class $$CrmTarefasTableAnnotationComposer
    extends Composer<_$AppDatabase, $CrmTarefasTable> {
  $$CrmTarefasTableAnnotationComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  GeneratedColumn<int> get id =>
      $composableBuilder(column: $table.id, builder: (column) => column);

  GeneratedColumn<int> get idCliente =>
      $composableBuilder(column: $table.idCliente, builder: (column) => column);

  GeneratedColumn<int> get idOportunidade => $composableBuilder(
    column: $table.idOportunidade,
    builder: (column) => column,
  );

  GeneratedColumn<String> get titulo =>
      $composableBuilder(column: $table.titulo, builder: (column) => column);

  GeneratedColumn<String> get descricao =>
      $composableBuilder(column: $table.descricao, builder: (column) => column);

  GeneratedColumn<String> get prioridade => $composableBuilder(
    column: $table.prioridade,
    builder: (column) => column,
  );

  GeneratedColumn<DateTime> get dataCriacao => $composableBuilder(
    column: $table.dataCriacao,
    builder: (column) => column,
  );

  GeneratedColumn<DateTime> get dataVencimento => $composableBuilder(
    column: $table.dataVencimento,
    builder: (column) => column,
  );

  GeneratedColumn<DateTime> get dataConclusao => $composableBuilder(
    column: $table.dataConclusao,
    builder: (column) => column,
  );

  GeneratedColumn<String> get status =>
      $composableBuilder(column: $table.status, builder: (column) => column);
}

class $$CrmTarefasTableTableManager
    extends
        RootTableManager<
          _$AppDatabase,
          $CrmTarefasTable,
          CrmTarefa,
          $$CrmTarefasTableFilterComposer,
          $$CrmTarefasTableOrderingComposer,
          $$CrmTarefasTableAnnotationComposer,
          $$CrmTarefasTableCreateCompanionBuilder,
          $$CrmTarefasTableUpdateCompanionBuilder,
          (
            CrmTarefa,
            BaseReferences<_$AppDatabase, $CrmTarefasTable, CrmTarefa>,
          ),
          CrmTarefa,
          PrefetchHooks Function()
        > {
  $$CrmTarefasTableTableManager(_$AppDatabase db, $CrmTarefasTable table)
    : super(
        TableManagerState(
          db: db,
          table: table,
          createFilteringComposer:
              () => $$CrmTarefasTableFilterComposer($db: db, $table: table),
          createOrderingComposer:
              () => $$CrmTarefasTableOrderingComposer($db: db, $table: table),
          createComputedFieldComposer:
              () => $$CrmTarefasTableAnnotationComposer($db: db, $table: table),
          updateCompanionCallback:
              ({
                Value<int?> id = const Value.absent(),
                Value<int?> idCliente = const Value.absent(),
                Value<int?> idOportunidade = const Value.absent(),
                Value<String?> titulo = const Value.absent(),
                Value<String?> descricao = const Value.absent(),
                Value<String?> prioridade = const Value.absent(),
                Value<DateTime?> dataCriacao = const Value.absent(),
                Value<DateTime?> dataVencimento = const Value.absent(),
                Value<DateTime?> dataConclusao = const Value.absent(),
                Value<String?> status = const Value.absent(),
              }) => CrmTarefasCompanion(
                id: id,
                idCliente: idCliente,
                idOportunidade: idOportunidade,
                titulo: titulo,
                descricao: descricao,
                prioridade: prioridade,
                dataCriacao: dataCriacao,
                dataVencimento: dataVencimento,
                dataConclusao: dataConclusao,
                status: status,
              ),
          createCompanionCallback:
              ({
                Value<int?> id = const Value.absent(),
                Value<int?> idCliente = const Value.absent(),
                Value<int?> idOportunidade = const Value.absent(),
                Value<String?> titulo = const Value.absent(),
                Value<String?> descricao = const Value.absent(),
                Value<String?> prioridade = const Value.absent(),
                Value<DateTime?> dataCriacao = const Value.absent(),
                Value<DateTime?> dataVencimento = const Value.absent(),
                Value<DateTime?> dataConclusao = const Value.absent(),
                Value<String?> status = const Value.absent(),
              }) => CrmTarefasCompanion.insert(
                id: id,
                idCliente: idCliente,
                idOportunidade: idOportunidade,
                titulo: titulo,
                descricao: descricao,
                prioridade: prioridade,
                dataCriacao: dataCriacao,
                dataVencimento: dataVencimento,
                dataConclusao: dataConclusao,
                status: status,
              ),
          withReferenceMapper:
              (p0) =>
                  p0
                      .map(
                        (e) => (
                          e.readTable(table),
                          BaseReferences(db, table, e),
                        ),
                      )
                      .toList(),
          prefetchHooksCallback: null,
        ),
      );
}

typedef $$CrmTarefasTableProcessedTableManager =
    ProcessedTableManager<
      _$AppDatabase,
      $CrmTarefasTable,
      CrmTarefa,
      $$CrmTarefasTableFilterComposer,
      $$CrmTarefasTableOrderingComposer,
      $$CrmTarefasTableAnnotationComposer,
      $$CrmTarefasTableCreateCompanionBuilder,
      $$CrmTarefasTableUpdateCompanionBuilder,
      (CrmTarefa, BaseReferences<_$AppDatabase, $CrmTarefasTable, CrmTarefa>),
      CrmTarefa,
      PrefetchHooks Function()
    >;

class $AppDatabaseManager {
  final _$AppDatabase _db;
  $AppDatabaseManager(this._db);
  $$CrmSacDetalhesTableTableManager get crmSacDetalhes =>
      $$CrmSacDetalhesTableTableManager(_db, _db.crmSacDetalhes);
  $$CrmCarteiraClientesTableTableManager get crmCarteiraClientes =>
      $$CrmCarteiraClientesTableTableManager(_db, _db.crmCarteiraClientes);
  $$CrmCampanhaClientesTableTableManager get crmCampanhaClientes =>
      $$CrmCampanhaClientesTableTableManager(_db, _db.crmCampanhaClientes);
  $$CrmSacCabecalhosTableTableManager get crmSacCabecalhos =>
      $$CrmSacCabecalhosTableTableManager(_db, _db.crmSacCabecalhos);
  $$CrmCarteiraClientePerfilsTableTableManager get crmCarteiraClientePerfils =>
      $$CrmCarteiraClientePerfilsTableTableManager(
        _db,
        _db.crmCarteiraClientePerfils,
      );
  $$CrmCampanhasTableTableManager get crmCampanhas =>
      $$CrmCampanhasTableTableManager(_db, _db.crmCampanhas);
  $$CrmBuscasClientesTableTableManager get crmBuscasClientes =>
      $$CrmBuscasClientesTableTableManager(_db, _db.crmBuscasClientes);
  $$ViewControleAcessosTableTableManager get viewControleAcessos =>
      $$ViewControleAcessosTableTableManager(_db, _db.viewControleAcessos);
  $$ViewPessoaUsuariosTableTableManager get viewPessoaUsuarios =>
      $$ViewPessoaUsuariosTableTableManager(_db, _db.viewPessoaUsuarios);
  $$ViewPessoaClientesTableTableManager get viewPessoaClientes =>
      $$ViewPessoaClientesTableTableManager(_db, _db.viewPessoaClientes);
  $$ViewPessoaColaboradorsTableTableManager get viewPessoaColaboradors =>
      $$ViewPessoaColaboradorsTableTableManager(
        _db,
        _db.viewPessoaColaboradors,
      );
  $$CrmContatosTableTableManager get crmContatos =>
      $$CrmContatosTableTableManager(_db, _db.crmContatos);
  $$CrmOportunidadesTableTableManager get crmOportunidades =>
      $$CrmOportunidadesTableTableManager(_db, _db.crmOportunidades);
  $$CrmTarefasTableTableManager get crmTarefas =>
      $$CrmTarefasTableTableManager(_db, _db.crmTarefas);
}
