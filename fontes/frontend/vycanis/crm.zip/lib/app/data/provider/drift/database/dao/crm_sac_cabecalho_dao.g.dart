// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'crm_sac_cabecalho_dao.dart';

// ignore_for_file: type=lint
mixin _$CrmSacCabecalhoDaoMixin on DatabaseAccessor<AppDatabase> {
  $CrmSacCabecalhosTable get crmSacCabecalhos =>
      attachedDatabase.crmSacCabecalhos;
  $CrmSacDetalhesTable get crmSacDetalhes => attachedDatabase.crmSacDetalhes;
  $ViewPessoaColaboradorsTable get viewPessoaColaboradors =>
      attachedDatabase.viewPessoaColaboradors;
  $ViewPessoaClientesTable get viewPessoaClientes =>
      attachedDatabase.viewPessoaClientes;
}
