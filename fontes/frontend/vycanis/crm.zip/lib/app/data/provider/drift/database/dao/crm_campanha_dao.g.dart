// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'crm_campanha_dao.dart';

// ignore_for_file: type=lint
mixin _$CrmCampanhaDaoMixin on DatabaseAccessor<AppDatabase> {
  $CrmCampanhasTable get crmCampanhas => attachedDatabase.crmCampanhas;
  $CrmCampanhaClientesTable get crmCampanhaClientes =>
      attachedDatabase.crmCampanhaClientes;
  $ViewPessoaClientesTable get viewPessoaClientes =>
      attachedDatabase.viewPessoaClientes;
}
