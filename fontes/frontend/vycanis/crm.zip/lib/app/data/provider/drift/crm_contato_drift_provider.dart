import 'package:crm/app/data/provider/drift/database/database_imports.dart';
import 'package:crm/app/infra/infra_imports.dart';
import 'package:crm/app/data/provider/provider_base.dart';
import 'package:crm/app/data/provider/drift/database/database.dart';
import 'package:crm/app/data/model/model_imports.dart';
import 'package:crm/app/data/domain/domain_imports.dart';

class CrmContatoDriftProvider extends ProviderBase {

	Future<List<CrmContatoModel>?> getList({Filter? filter}) async {
		List<CrmContatoGrouped> crmContatoDriftList = [];

		try {
			if (filter != null && filter.field != null) {
				crmContatoDriftList = await Session.database.crmContatoDao.getGroupedList(field: filter.field, value: filter.value!);
			} else {
				crmContatoDriftList = await Session.database.crmContatoDao.getGroupedList(); 
			}
			if (crmContatoDriftList.isNotEmpty) {
				return toListModel(crmContatoDriftList);
			} else {
				return [];
			}			 
		} catch (e) {
			handleResultError(null, null, exception: e);
			return null;
		}
	}

	Future<CrmContatoModel?> getObject(dynamic pk) async {
		try {
			final result = await Session.database.crmContatoDao.getObjectGrouped(field: 'id', value: pk);
			return toModel(result);
		} catch (e) {
			handleResultError(null, null, exception: e);
		}
		return null;
	}

	Future<CrmContatoModel?>? insert(CrmContatoModel crmContatoModel) async {
		try {
			final lastPk = await Session.database.crmContatoDao.insertObject(toDrift(crmContatoModel));
			crmContatoModel.id = lastPk;
			return crmContatoModel;
		} catch (e) {
			handleResultError(null, null, exception: e);
		}
		return null;
	}

	Future<CrmContatoModel?>? update(CrmContatoModel crmContatoModel) async {
		try {
			await Session.database.crmContatoDao.updateObject(toDrift(crmContatoModel));
			return crmContatoModel;
		} catch (e) {
			handleResultError(null, null, exception: e);
		}
		return null;
	}

	Future<bool?> delete(dynamic pk) async {
		try {
			await Session.database.crmContatoDao.deleteObject(toDrift(CrmContatoModel(id: pk)));
			return true;
		} catch (e) {
			handleResultError(null, null, exception: e);
		}
		return null;
	}	

	List<CrmContatoModel> toListModel(List<CrmContatoGrouped> crmContatoDriftList) {
		List<CrmContatoModel> listModel = [];
		for (var crmContatoDrift in crmContatoDriftList) {
			listModel.add(toModel(crmContatoDrift)!);
		}
		return listModel;
	}	

	CrmContatoModel? toModel(CrmContatoGrouped? crmContatoDrift) {
		if (crmContatoDrift != null) {
			return CrmContatoModel(
				id: crmContatoDrift.crmContato?.id,
				idCliente: crmContatoDrift.crmContato?.idCliente,
				idViewPessoaColaborador: crmContatoDrift.crmContato?.idViewPessoaColaborador,
				tipoContato: CrmContatoDomain.getTipoContato(crmContatoDrift.crmContato?.tipoContato),
				horaContato: crmContatoDrift.crmContato?.horaContato,
				assunto: crmContatoDrift.crmContato?.assunto,
				descricao: crmContatoDrift.crmContato?.descricao,
				resultado: CrmContatoDomain.getResultado(crmContatoDrift.crmContato?.resultado),
				proximaData: crmContatoDrift.crmContato?.proximaData,
				proximaAcao: crmContatoDrift.crmContato?.proximaAcao,
				viewPessoaClienteModel: ViewPessoaClienteModel(
					id: crmContatoDrift.viewPessoaCliente?.id,
					nome: crmContatoDrift.viewPessoaCliente?.nome,
					tipo: crmContatoDrift.viewPessoaCliente?.tipo,
					email: crmContatoDrift.viewPessoaCliente?.email,
					site: crmContatoDrift.viewPessoaCliente?.site,
					cpfCnpj: crmContatoDrift.viewPessoaCliente?.cpfCnpj,
					rgIe: crmContatoDrift.viewPessoaCliente?.rgIe,
					desde: crmContatoDrift.viewPessoaCliente?.desde,
					taxaDesconto: crmContatoDrift.viewPessoaCliente?.taxaDesconto,
					limiteCredito: crmContatoDrift.viewPessoaCliente?.limiteCredito,
					dataCadastro: crmContatoDrift.viewPessoaCliente?.dataCadastro,
					observacao: crmContatoDrift.viewPessoaCliente?.observacao,
					idPessoa: crmContatoDrift.viewPessoaCliente?.idPessoa,
				),
				viewPessoaColaboradorModel: ViewPessoaColaboradorModel(
					id: crmContatoDrift.viewPessoaColaborador?.id,
					nome: crmContatoDrift.viewPessoaColaborador?.nome,
					tipo: crmContatoDrift.viewPessoaColaborador?.tipo,
					email: crmContatoDrift.viewPessoaColaborador?.email,
					site: crmContatoDrift.viewPessoaColaborador?.site,
					cpfCnpj: crmContatoDrift.viewPessoaColaborador?.cpfCnpj,
					rgIe: crmContatoDrift.viewPessoaColaborador?.rgIe,
					matricula: crmContatoDrift.viewPessoaColaborador?.matricula,
					dataCadastro: crmContatoDrift.viewPessoaColaborador?.dataCadastro,
					dataAdmissao: crmContatoDrift.viewPessoaColaborador?.dataAdmissao,
					dataDemissao: crmContatoDrift.viewPessoaColaborador?.dataDemissao,
					ctpsNumero: crmContatoDrift.viewPessoaColaborador?.ctpsNumero,
					ctpsSerie: crmContatoDrift.viewPessoaColaborador?.ctpsSerie,
					ctpsDataExpedicao: crmContatoDrift.viewPessoaColaborador?.ctpsDataExpedicao,
					ctpsUf: crmContatoDrift.viewPessoaColaborador?.ctpsUf,
					observacao: crmContatoDrift.viewPessoaColaborador?.observacao,
					logradouro: crmContatoDrift.viewPessoaColaborador?.logradouro,
					numero: crmContatoDrift.viewPessoaColaborador?.numero,
					complemento: crmContatoDrift.viewPessoaColaborador?.complemento,
					bairro: crmContatoDrift.viewPessoaColaborador?.bairro,
					cidade: crmContatoDrift.viewPessoaColaborador?.cidade,
					cep: crmContatoDrift.viewPessoaColaborador?.cep,
					municipioIbge: crmContatoDrift.viewPessoaColaborador?.municipioIbge,
					uf: crmContatoDrift.viewPessoaColaborador?.uf,
					idPessoa: crmContatoDrift.viewPessoaColaborador?.idPessoa,
					idCargo: crmContatoDrift.viewPessoaColaborador?.idCargo,
					idSetor: crmContatoDrift.viewPessoaColaborador?.idSetor,
				),
			);
		} else {
			return null;
		}
	}


	CrmContatoGrouped toDrift(CrmContatoModel crmContatoModel) {
		return CrmContatoGrouped(
			crmContato: CrmContato(
				id: crmContatoModel.id,
				idCliente: crmContatoModel.idCliente,
				idViewPessoaColaborador: crmContatoModel.idViewPessoaColaborador,
				tipoContato: CrmContatoDomain.setTipoContato(crmContatoModel.tipoContato),
				horaContato: Util.removeMask(crmContatoModel.horaContato),
				assunto: crmContatoModel.assunto,
				descricao: crmContatoModel.descricao,
				resultado: CrmContatoDomain.setResultado(crmContatoModel.resultado),
				proximaData: crmContatoModel.proximaData,
				proximaAcao: crmContatoModel.proximaAcao,
			),
		);
	}

		
}
