import 'package:drift/drift.dart';
import 'package:crm/app/data/provider/drift/database/database.dart';
import 'package:crm/app/data/provider/drift/database/database_imports.dart';

part 'crm_oportunidade_dao.g.dart';

@DriftAccessor(tables: [
	CrmOportunidades,
	ViewPessoaClientes,
	ViewPessoaColaboradors,
])
class CrmOportunidadeDao extends DatabaseAccessor<AppDatabase> with _$CrmOportunidadeDaoMixin {
	final AppDatabase db;

	List<CrmOportunidade> crmOportunidadeList = []; 
	List<CrmOportunidadeGrouped> crmOportunidadeGroupedList = []; 

	CrmOportunidadeDao(this.db) : super(db);

	Future<List<CrmOportunidade>> getList() async {
		crmOportunidadeList = await select(crmOportunidades).get();
		return crmOportunidadeList;
	}

	Future<List<CrmOportunidade>> getListFilter(String field, String value) async {
		final query = " $field like '%$value%'";
		final expression = CustomExpression<bool>(query);
		crmOportunidadeList = await (select(crmOportunidades)..where((t) => expression)).get();
		return crmOportunidadeList;	 
	}

	Future<List<CrmOportunidadeGrouped>> getGroupedList({String? field, dynamic value}) async {
		final query = select(crmOportunidades)
			.join([ 
				leftOuterJoin(viewPessoaClientes, viewPessoaClientes.id.equalsExp(crmOportunidades.idCliente)), 
			]).join([ 
				leftOuterJoin(viewPessoaColaboradors, viewPessoaColaboradors.id.equalsExp(crmOportunidades.idViewPessoaColaborador)), 
			]);

		if (field != null && field != '') { 
			final column = crmOportunidades.$columns.where(((column) => column.$name == field)).first;
			if (column is TextColumn) {
				query.where((column as TextColumn).like('%$value%'));
			} else if (column is IntColumn) {
				query.where(column.equals(int.tryParse(value) as Object));
			} else if (column is RealColumn) {
				query.where(column.equals(double.tryParse(value) as Object));
			}
		}

		crmOportunidadeGroupedList = await query.map((row) {
			final crmOportunidade = row.readTableOrNull(crmOportunidades); 
			final viewPessoaCliente = row.readTableOrNull(viewPessoaClientes); 
			final viewPessoaColaborador = row.readTableOrNull(viewPessoaColaboradors); 

			return CrmOportunidadeGrouped(
				crmOportunidade: crmOportunidade, 
				viewPessoaCliente: viewPessoaCliente, 
				viewPessoaColaborador: viewPessoaColaborador, 

			);
		}).get();

		// fill internal lists
		//dynamic expression;
		//for (var crmOportunidadeGrouped in crmOportunidadeGroupedList) {
		//}		

		return crmOportunidadeGroupedList;	
	}

	Future<CrmOportunidade?> getObject(dynamic pk) async {
		return await (select(crmOportunidades)..where((t) => t.id.equals(pk))).getSingleOrNull();
	} 

	Future<CrmOportunidade?> getObjectFilter(String field, String value) async {
		final query = "SELECT * FROM crm_oportunidade WHERE $field like '%$value%'";
		return (await customSelect(query).getSingleOrNull()) as CrmOportunidade;		 
	} 

	Future<CrmOportunidadeGrouped?> getObjectGrouped({String? field, dynamic value}) async {
		final result = await getGroupedList(field: field, value: value);

		if (result.length != 1) {
			return null;
		} else {
			return result[0];
		} 
	}

	Future<int> insertObject(CrmOportunidadeGrouped object) {
		return transaction(() async {
			final maxPk = await lastPk();
			object.crmOportunidade = object.crmOportunidade!.copyWith(id: Value(maxPk + 1));
			final pkInserted = await into(crmOportunidades).insert(object.crmOportunidade!);
			object.crmOportunidade = object.crmOportunidade!.copyWith(id: Value(pkInserted));			 
			await insertChildren(object);
			return pkInserted;
		});		
	}	 

	Future<bool> updateObject(CrmOportunidadeGrouped object) {
		return transaction(() async {
			await deleteChildren(object);
			await insertChildren(object);
			return update(crmOportunidades).replace(object.crmOportunidade!);
		});	 
	} 

	Future<int> deleteObject(CrmOportunidadeGrouped object) {
		return transaction(() async {
			await deleteChildren(object);
			return delete(crmOportunidades).delete(object.crmOportunidade!);
		});		
	}

	Future<void> insertChildren(CrmOportunidadeGrouped object) async {
	}
	
	Future<void> deleteChildren(CrmOportunidadeGrouped object) async {
	}

	Future<int> lastPk() async {
		final result = await customSelect("select MAX(id) as LAST from crm_oportunidade").getSingleOrNull();
		return result?.data["LAST"] ?? 0;
	} 
}