import 'package:crm/app/data/provider/drift/database/database_imports.dart';
import 'package:crm/app/infra/infra_imports.dart';
import 'package:crm/app/data/provider/provider_base.dart';
import 'package:crm/app/data/provider/drift/database/database.dart';
import 'package:crm/app/data/model/model_imports.dart';

class CrmBuscasClienteDriftProvider extends ProviderBase {

	Future<List<CrmBuscasClienteModel>?> getList({Filter? filter}) async {
		List<CrmBuscasClienteGrouped> crmBuscasClienteDriftList = [];

		try {
			if (filter != null && filter.field != null) {
				crmBuscasClienteDriftList = await Session.database.crmBuscasClienteDao.getGroupedList(field: filter.field, value: filter.value!);
			} else {
				crmBuscasClienteDriftList = await Session.database.crmBuscasClienteDao.getGroupedList(); 
			}
			if (crmBuscasClienteDriftList.isNotEmpty) {
				return toListModel(crmBuscasClienteDriftList);
			} else {
				return [];
			}			 
		} catch (e) {
			handleResultError(null, null, exception: e);
			return null;
		}
	}

	Future<CrmBuscasClienteModel?> getObject(dynamic pk) async {
		try {
			final result = await Session.database.crmBuscasClienteDao.getObjectGrouped(field: 'id', value: pk);
			return toModel(result);
		} catch (e) {
			handleResultError(null, null, exception: e);
		}
		return null;
	}

	Future<CrmBuscasClienteModel?>? insert(CrmBuscasClienteModel crmBuscasClienteModel) async {
		try {
			final lastPk = await Session.database.crmBuscasClienteDao.insertObject(toDrift(crmBuscasClienteModel));
			crmBuscasClienteModel.id = lastPk;
			return crmBuscasClienteModel;
		} catch (e) {
			handleResultError(null, null, exception: e);
		}
		return null;
	}

	Future<CrmBuscasClienteModel?>? update(CrmBuscasClienteModel crmBuscasClienteModel) async {
		try {
			await Session.database.crmBuscasClienteDao.updateObject(toDrift(crmBuscasClienteModel));
			return crmBuscasClienteModel;
		} catch (e) {
			handleResultError(null, null, exception: e);
		}
		return null;
	}

	Future<bool?> delete(dynamic pk) async {
		try {
			await Session.database.crmBuscasClienteDao.deleteObject(toDrift(CrmBuscasClienteModel(id: pk)));
			return true;
		} catch (e) {
			handleResultError(null, null, exception: e);
		}
		return null;
	}	

	List<CrmBuscasClienteModel> toListModel(List<CrmBuscasClienteGrouped> crmBuscasClienteDriftList) {
		List<CrmBuscasClienteModel> listModel = [];
		for (var crmBuscasClienteDrift in crmBuscasClienteDriftList) {
			listModel.add(toModel(crmBuscasClienteDrift)!);
		}
		return listModel;
	}	

	CrmBuscasClienteModel? toModel(CrmBuscasClienteGrouped? crmBuscasClienteDrift) {
		if (crmBuscasClienteDrift != null) {
			return CrmBuscasClienteModel(
				id: crmBuscasClienteDrift.crmBuscasCliente?.id,
				idCliente: crmBuscasClienteDrift.crmBuscasCliente?.idCliente,
				dataBusca: crmBuscasClienteDrift.crmBuscasCliente?.dataBusca,
				horaBusca: crmBuscasClienteDrift.crmBuscasCliente?.horaBusca,
				detalhes: crmBuscasClienteDrift.crmBuscasCliente?.detalhes,
				viewPessoaClienteModel: ViewPessoaClienteModel(
					id: crmBuscasClienteDrift.viewPessoaCliente?.id,
					nome: crmBuscasClienteDrift.viewPessoaCliente?.nome,
					tipo: crmBuscasClienteDrift.viewPessoaCliente?.tipo,
					email: crmBuscasClienteDrift.viewPessoaCliente?.email,
					site: crmBuscasClienteDrift.viewPessoaCliente?.site,
					cpfCnpj: crmBuscasClienteDrift.viewPessoaCliente?.cpfCnpj,
					rgIe: crmBuscasClienteDrift.viewPessoaCliente?.rgIe,
					desde: crmBuscasClienteDrift.viewPessoaCliente?.desde,
					taxaDesconto: crmBuscasClienteDrift.viewPessoaCliente?.taxaDesconto,
					limiteCredito: crmBuscasClienteDrift.viewPessoaCliente?.limiteCredito,
					dataCadastro: crmBuscasClienteDrift.viewPessoaCliente?.dataCadastro,
					observacao: crmBuscasClienteDrift.viewPessoaCliente?.observacao,
					idPessoa: crmBuscasClienteDrift.viewPessoaCliente?.idPessoa,
				),
			);
		} else {
			return null;
		}
	}


	CrmBuscasClienteGrouped toDrift(CrmBuscasClienteModel crmBuscasClienteModel) {
		return CrmBuscasClienteGrouped(
			crmBuscasCliente: CrmBuscasCliente(
				id: crmBuscasClienteModel.id,
				idCliente: crmBuscasClienteModel.idCliente,
				dataBusca: crmBuscasClienteModel.dataBusca,
				horaBusca: Util.removeMask(crmBuscasClienteModel.horaBusca),
				detalhes: crmBuscasClienteModel.detalhes,
			),
		);
	}

		
}
