// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'crm_tarefa_dao.dart';

// ignore_for_file: type=lint
mixin _$CrmTarefaDaoMixin on DatabaseAccessor<AppDatabase> {
  $CrmTarefasTable get crmTarefas => attachedDatabase.crmTarefas;
  $ViewPessoaClientesTable get viewPessoaClientes =>
      attachedDatabase.viewPessoaClientes;
  $CrmOportunidadesTable get crmOportunidades =>
      attachedDatabase.crmOportunidades;
}
