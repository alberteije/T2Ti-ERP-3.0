import 'package:crm/app/data/provider/drift/database/database_imports.dart';
import 'package:crm/app/infra/infra_imports.dart';
import 'package:crm/app/data/provider/provider_base.dart';
import 'package:crm/app/data/provider/drift/database/database.dart';
import 'package:crm/app/data/model/model_imports.dart';
import 'package:crm/app/data/domain/domain_imports.dart';

class CrmTarefaDriftProvider extends ProviderBase {

	Future<List<CrmTarefaModel>?> getList({Filter? filter}) async {
		List<CrmTarefaGrouped> crmTarefaDriftList = [];

		try {
			if (filter != null && filter.field != null) {
				crmTarefaDriftList = await Session.database.crmTarefaDao.getGroupedList(field: filter.field, value: filter.value!);
			} else {
				crmTarefaDriftList = await Session.database.crmTarefaDao.getGroupedList(); 
			}
			if (crmTarefaDriftList.isNotEmpty) {
				return toListModel(crmTarefaDriftList);
			} else {
				return [];
			}			 
		} catch (e) {
			handleResultError(null, null, exception: e);
			return null;
		}
	}

	Future<CrmTarefaModel?> getObject(dynamic pk) async {
		try {
			final result = await Session.database.crmTarefaDao.getObjectGrouped(field: 'id', value: pk);
			return toModel(result);
		} catch (e) {
			handleResultError(null, null, exception: e);
		}
		return null;
	}

	Future<CrmTarefaModel?>? insert(CrmTarefaModel crmTarefaModel) async {
		try {
			final lastPk = await Session.database.crmTarefaDao.insertObject(toDrift(crmTarefaModel));
			crmTarefaModel.id = lastPk;
			return crmTarefaModel;
		} catch (e) {
			handleResultError(null, null, exception: e);
		}
		return null;
	}

	Future<CrmTarefaModel?>? update(CrmTarefaModel crmTarefaModel) async {
		try {
			await Session.database.crmTarefaDao.updateObject(toDrift(crmTarefaModel));
			return crmTarefaModel;
		} catch (e) {
			handleResultError(null, null, exception: e);
		}
		return null;
	}

	Future<bool?> delete(dynamic pk) async {
		try {
			await Session.database.crmTarefaDao.deleteObject(toDrift(CrmTarefaModel(id: pk)));
			return true;
		} catch (e) {
			handleResultError(null, null, exception: e);
		}
		return null;
	}	

	List<CrmTarefaModel> toListModel(List<CrmTarefaGrouped> crmTarefaDriftList) {
		List<CrmTarefaModel> listModel = [];
		for (var crmTarefaDrift in crmTarefaDriftList) {
			listModel.add(toModel(crmTarefaDrift)!);
		}
		return listModel;
	}	

	CrmTarefaModel? toModel(CrmTarefaGrouped? crmTarefaDrift) {
		if (crmTarefaDrift != null) {
			return CrmTarefaModel(
				id: crmTarefaDrift.crmTarefa?.id,
				idCliente: crmTarefaDrift.crmTarefa?.idCliente,
				idOportunidade: crmTarefaDrift.crmTarefa?.idOportunidade,
				titulo: crmTarefaDrift.crmTarefa?.titulo,
				descricao: crmTarefaDrift.crmTarefa?.descricao,
				prioridade: CrmTarefaDomain.getPrioridade(crmTarefaDrift.crmTarefa?.prioridade),
				dataCriacao: crmTarefaDrift.crmTarefa?.dataCriacao,
				dataVencimento: crmTarefaDrift.crmTarefa?.dataVencimento,
				dataConclusao: crmTarefaDrift.crmTarefa?.dataConclusao,
				status: CrmTarefaDomain.getStatus(crmTarefaDrift.crmTarefa?.status),
				viewPessoaClienteModel: ViewPessoaClienteModel(
					id: crmTarefaDrift.viewPessoaCliente?.id,
					nome: crmTarefaDrift.viewPessoaCliente?.nome,
					tipo: crmTarefaDrift.viewPessoaCliente?.tipo,
					email: crmTarefaDrift.viewPessoaCliente?.email,
					site: crmTarefaDrift.viewPessoaCliente?.site,
					cpfCnpj: crmTarefaDrift.viewPessoaCliente?.cpfCnpj,
					rgIe: crmTarefaDrift.viewPessoaCliente?.rgIe,
					desde: crmTarefaDrift.viewPessoaCliente?.desde,
					taxaDesconto: crmTarefaDrift.viewPessoaCliente?.taxaDesconto,
					limiteCredito: crmTarefaDrift.viewPessoaCliente?.limiteCredito,
					dataCadastro: crmTarefaDrift.viewPessoaCliente?.dataCadastro,
					observacao: crmTarefaDrift.viewPessoaCliente?.observacao,
					idPessoa: crmTarefaDrift.viewPessoaCliente?.idPessoa,
				),
				crmOportunidadeModel: CrmOportunidadeModel(
					id: crmTarefaDrift.crmOportunidade?.id,
					idCliente: crmTarefaDrift.crmOportunidade?.idCliente,
					idViewPessoaColaborador: crmTarefaDrift.crmOportunidade?.idViewPessoaColaborador,
					titulo: crmTarefaDrift.crmOportunidade?.titulo,
					descricao: crmTarefaDrift.crmOportunidade?.descricao,
					valorEstimado: crmTarefaDrift.crmOportunidade?.valorEstimado,
					dataAbertura: crmTarefaDrift.crmOportunidade?.dataAbertura,
					dataFechamentoPrevisto: crmTarefaDrift.crmOportunidade?.dataFechamentoPrevisto,
					dataFechamentoReal: crmTarefaDrift.crmOportunidade?.dataFechamentoReal,
					status: crmTarefaDrift.crmOportunidade?.status,
					motivoFechamento: crmTarefaDrift.crmOportunidade?.motivoFechamento,
					probabilidade: crmTarefaDrift.crmOportunidade?.probabilidade,
				),
			);
		} else {
			return null;
		}
	}


	CrmTarefaGrouped toDrift(CrmTarefaModel crmTarefaModel) {
		return CrmTarefaGrouped(
			crmTarefa: CrmTarefa(
				id: crmTarefaModel.id,
				idCliente: crmTarefaModel.idCliente,
				idOportunidade: crmTarefaModel.idOportunidade,
				titulo: crmTarefaModel.titulo,
				descricao: crmTarefaModel.descricao,
				prioridade: CrmTarefaDomain.setPrioridade(crmTarefaModel.prioridade),
				dataCriacao: crmTarefaModel.dataCriacao,
				dataVencimento: crmTarefaModel.dataVencimento,
				dataConclusao: crmTarefaModel.dataConclusao,
				status: CrmTarefaDomain.setStatus(crmTarefaModel.status),
			),
		);
	}

		
}
