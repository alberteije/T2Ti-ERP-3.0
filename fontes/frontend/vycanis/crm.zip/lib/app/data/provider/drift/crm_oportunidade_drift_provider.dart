import 'package:crm/app/data/provider/drift/database/database_imports.dart';
import 'package:crm/app/infra/infra_imports.dart';
import 'package:crm/app/data/provider/provider_base.dart';
import 'package:crm/app/data/provider/drift/database/database.dart';
import 'package:crm/app/data/model/model_imports.dart';
import 'package:crm/app/data/domain/domain_imports.dart';

class CrmOportunidadeDriftProvider extends ProviderBase {

	Future<List<CrmOportunidadeModel>?> getList({Filter? filter}) async {
		List<CrmOportunidadeGrouped> crmOportunidadeDriftList = [];

		try {
			if (filter != null && filter.field != null) {
				crmOportunidadeDriftList = await Session.database.crmOportunidadeDao.getGroupedList(field: filter.field, value: filter.value!);
			} else {
				crmOportunidadeDriftList = await Session.database.crmOportunidadeDao.getGroupedList(); 
			}
			if (crmOportunidadeDriftList.isNotEmpty) {
				return toListModel(crmOportunidadeDriftList);
			} else {
				return [];
			}			 
		} catch (e) {
			handleResultError(null, null, exception: e);
			return null;
		}
	}

	Future<CrmOportunidadeModel?> getObject(dynamic pk) async {
		try {
			final result = await Session.database.crmOportunidadeDao.getObjectGrouped(field: 'id', value: pk);
			return toModel(result);
		} catch (e) {
			handleResultError(null, null, exception: e);
		}
		return null;
	}

	Future<CrmOportunidadeModel?>? insert(CrmOportunidadeModel crmOportunidadeModel) async {
		try {
			final lastPk = await Session.database.crmOportunidadeDao.insertObject(toDrift(crmOportunidadeModel));
			crmOportunidadeModel.id = lastPk;
			return crmOportunidadeModel;
		} catch (e) {
			handleResultError(null, null, exception: e);
		}
		return null;
	}

	Future<CrmOportunidadeModel?>? update(CrmOportunidadeModel crmOportunidadeModel) async {
		try {
			await Session.database.crmOportunidadeDao.updateObject(toDrift(crmOportunidadeModel));
			return crmOportunidadeModel;
		} catch (e) {
			handleResultError(null, null, exception: e);
		}
		return null;
	}

	Future<bool?> delete(dynamic pk) async {
		try {
			await Session.database.crmOportunidadeDao.deleteObject(toDrift(CrmOportunidadeModel(id: pk)));
			return true;
		} catch (e) {
			handleResultError(null, null, exception: e);
		}
		return null;
	}	

	List<CrmOportunidadeModel> toListModel(List<CrmOportunidadeGrouped> crmOportunidadeDriftList) {
		List<CrmOportunidadeModel> listModel = [];
		for (var crmOportunidadeDrift in crmOportunidadeDriftList) {
			listModel.add(toModel(crmOportunidadeDrift)!);
		}
		return listModel;
	}	

	CrmOportunidadeModel? toModel(CrmOportunidadeGrouped? crmOportunidadeDrift) {
		if (crmOportunidadeDrift != null) {
			return CrmOportunidadeModel(
				id: crmOportunidadeDrift.crmOportunidade?.id,
				idCliente: crmOportunidadeDrift.crmOportunidade?.idCliente,
				idViewPessoaColaborador: crmOportunidadeDrift.crmOportunidade?.idViewPessoaColaborador,
				titulo: crmOportunidadeDrift.crmOportunidade?.titulo,
				descricao: crmOportunidadeDrift.crmOportunidade?.descricao,
				valorEstimado: crmOportunidadeDrift.crmOportunidade?.valorEstimado,
				dataAbertura: crmOportunidadeDrift.crmOportunidade?.dataAbertura,
				dataFechamentoPrevisto: crmOportunidadeDrift.crmOportunidade?.dataFechamentoPrevisto,
				dataFechamentoReal: crmOportunidadeDrift.crmOportunidade?.dataFechamentoReal,
				status: CrmOportunidadeDomain.getStatus(crmOportunidadeDrift.crmOportunidade?.status),
				motivoFechamento: CrmOportunidadeDomain.getMotivoFechamento(crmOportunidadeDrift.crmOportunidade?.motivoFechamento),
				probabilidade: crmOportunidadeDrift.crmOportunidade?.probabilidade,
				viewPessoaClienteModel: ViewPessoaClienteModel(
					id: crmOportunidadeDrift.viewPessoaCliente?.id,
					nome: crmOportunidadeDrift.viewPessoaCliente?.nome,
					tipo: crmOportunidadeDrift.viewPessoaCliente?.tipo,
					email: crmOportunidadeDrift.viewPessoaCliente?.email,
					site: crmOportunidadeDrift.viewPessoaCliente?.site,
					cpfCnpj: crmOportunidadeDrift.viewPessoaCliente?.cpfCnpj,
					rgIe: crmOportunidadeDrift.viewPessoaCliente?.rgIe,
					desde: crmOportunidadeDrift.viewPessoaCliente?.desde,
					taxaDesconto: crmOportunidadeDrift.viewPessoaCliente?.taxaDesconto,
					limiteCredito: crmOportunidadeDrift.viewPessoaCliente?.limiteCredito,
					dataCadastro: crmOportunidadeDrift.viewPessoaCliente?.dataCadastro,
					observacao: crmOportunidadeDrift.viewPessoaCliente?.observacao,
					idPessoa: crmOportunidadeDrift.viewPessoaCliente?.idPessoa,
				),
				viewPessoaColaboradorModel: ViewPessoaColaboradorModel(
					id: crmOportunidadeDrift.viewPessoaColaborador?.id,
					nome: crmOportunidadeDrift.viewPessoaColaborador?.nome,
					tipo: crmOportunidadeDrift.viewPessoaColaborador?.tipo,
					email: crmOportunidadeDrift.viewPessoaColaborador?.email,
					site: crmOportunidadeDrift.viewPessoaColaborador?.site,
					cpfCnpj: crmOportunidadeDrift.viewPessoaColaborador?.cpfCnpj,
					rgIe: crmOportunidadeDrift.viewPessoaColaborador?.rgIe,
					matricula: crmOportunidadeDrift.viewPessoaColaborador?.matricula,
					dataCadastro: crmOportunidadeDrift.viewPessoaColaborador?.dataCadastro,
					dataAdmissao: crmOportunidadeDrift.viewPessoaColaborador?.dataAdmissao,
					dataDemissao: crmOportunidadeDrift.viewPessoaColaborador?.dataDemissao,
					ctpsNumero: crmOportunidadeDrift.viewPessoaColaborador?.ctpsNumero,
					ctpsSerie: crmOportunidadeDrift.viewPessoaColaborador?.ctpsSerie,
					ctpsDataExpedicao: crmOportunidadeDrift.viewPessoaColaborador?.ctpsDataExpedicao,
					ctpsUf: crmOportunidadeDrift.viewPessoaColaborador?.ctpsUf,
					observacao: crmOportunidadeDrift.viewPessoaColaborador?.observacao,
					logradouro: crmOportunidadeDrift.viewPessoaColaborador?.logradouro,
					numero: crmOportunidadeDrift.viewPessoaColaborador?.numero,
					complemento: crmOportunidadeDrift.viewPessoaColaborador?.complemento,
					bairro: crmOportunidadeDrift.viewPessoaColaborador?.bairro,
					cidade: crmOportunidadeDrift.viewPessoaColaborador?.cidade,
					cep: crmOportunidadeDrift.viewPessoaColaborador?.cep,
					municipioIbge: crmOportunidadeDrift.viewPessoaColaborador?.municipioIbge,
					uf: crmOportunidadeDrift.viewPessoaColaborador?.uf,
					idPessoa: crmOportunidadeDrift.viewPessoaColaborador?.idPessoa,
					idCargo: crmOportunidadeDrift.viewPessoaColaborador?.idCargo,
					idSetor: crmOportunidadeDrift.viewPessoaColaborador?.idSetor,
				),
			);
		} else {
			return null;
		}
	}


	CrmOportunidadeGrouped toDrift(CrmOportunidadeModel crmOportunidadeModel) {
		return CrmOportunidadeGrouped(
			crmOportunidade: CrmOportunidade(
				id: crmOportunidadeModel.id,
				idCliente: crmOportunidadeModel.idCliente,
				idViewPessoaColaborador: crmOportunidadeModel.idViewPessoaColaborador,
				titulo: crmOportunidadeModel.titulo,
				descricao: crmOportunidadeModel.descricao,
				valorEstimado: crmOportunidadeModel.valorEstimado,
				dataAbertura: crmOportunidadeModel.dataAbertura,
				dataFechamentoPrevisto: crmOportunidadeModel.dataFechamentoPrevisto,
				dataFechamentoReal: crmOportunidadeModel.dataFechamentoReal,
				status: CrmOportunidadeDomain.setStatus(crmOportunidadeModel.status),
				motivoFechamento: CrmOportunidadeDomain.setMotivoFechamento(crmOportunidadeModel.motivoFechamento),
				probabilidade: crmOportunidadeModel.probabilidade,
			),
		);
	}

		
}
