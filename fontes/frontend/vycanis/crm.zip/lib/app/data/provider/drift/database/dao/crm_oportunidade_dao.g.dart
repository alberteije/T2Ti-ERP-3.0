// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'crm_oportunidade_dao.dart';

// ignore_for_file: type=lint
mixin _$CrmOportunidadeDaoMixin on DatabaseAccessor<AppDatabase> {
  $CrmOportunidadesTable get crmOportunidades =>
      attachedDatabase.crmOportunidades;
  $ViewPessoaClientesTable get viewPessoaClientes =>
      attachedDatabase.viewPessoaClientes;
  $ViewPessoaColaboradorsTable get viewPessoaColaboradors =>
      attachedDatabase.viewPessoaColaboradors;
}
