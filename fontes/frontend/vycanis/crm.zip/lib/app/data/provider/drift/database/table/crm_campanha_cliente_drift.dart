import 'package:drift/drift.dart';
import 'package:crm/app/data/provider/drift/database/database.dart';

@DataClassName("CrmCampanhaCliente")
class CrmCampanhaClientes extends Table {
	@override
	String get tableName => 'crm_campanha_cliente';

	IntColumn get id => integer().named('id').nullable()();
	IntColumn get idCampanha => integer().named('id_campanha').nullable()();
	IntColumn get idCliente => integer().named('id_cliente').nullable()();
	DateTimeColumn get dataInscricao => dateTime().named('data_inscricao').nullable()();
	TextColumn get status => text().named('status').withLength(min: 0, max: 1).nullable()();
	TextColumn get observacoes => text().named('observacoes').nullable()();

	@override
	Set<Column> get primaryKey => { id };	
	
}

class CrmCampanhaClienteGrouped {
	CrmCampanhaCliente? crmCampanhaCliente; 
	ViewPessoaCliente? viewPessoaCliente; 

  CrmCampanhaClienteGrouped({
		this.crmCampanhaCliente, 
		this.viewPessoaCliente, 

  });
}
