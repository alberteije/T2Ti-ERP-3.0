import 'package:crm/app/data/provider/api/api_provider_base.dart';
import 'package:crm/app/data/model/model_imports.dart';

class CrmTarefaApiProvider extends ApiProviderBase {
  static const _path = '/crm-tarefa';

  Future<List<CrmTarefaModel>?> getList({Filter? filter}) {
    return super.getListBase(
      '$_path/',
      (json) => CrmTarefaModel.fromJson(json),
      filter: filter,
    );
  }

  Future<CrmTarefaModel?> getObject(dynamic pk) {
    return super.getObjectBase(
      _path,
      pk,
      (json) => CrmTarefaModel.fromJson(json),
    );
  }

  Future<CrmTarefaModel?>? insert(CrmTarefaModel model) {
    return super.insertBase(
      _path,
      model,
      (json) => CrmTarefaModel.fromJson(json),
    );
  }

  Future<CrmTarefaModel?>? update(CrmTarefaModel model) {
    return super.updateBase(
      _path,
      model,
      (json) => CrmTarefaModel.fromJson(json),
    );
  }

  Future<bool?> delete(dynamic pk) {
    return super.deleteBase(_path, pk);
  }
}
