import 'package:drift/drift.dart';
import 'package:crm/app/data/provider/drift/database/database.dart';

@DataClassName("CrmTarefa")
class CrmTarefas extends Table {
	@override
	String get tableName => 'crm_tarefa';

	IntColumn get id => integer().named('id').nullable()();
	IntColumn get idCliente => integer().named('id_cliente').nullable()();
	IntColumn get idOportunidade => integer().named('id_oportunidade').nullable()();
	TextColumn get titulo => text().named('titulo').withLength(min: 0, max: 200).nullable()();
	TextColumn get descricao => text().named('descricao').nullable()();
	TextColumn get prioridade => text().named('prioridade').withLength(min: 0, max: 1).nullable()();
	DateTimeColumn get dataCriacao => dateTime().named('data_criacao').nullable()();
	DateTimeColumn get dataVencimento => dateTime().named('data_vencimento').nullable()();
	DateTimeColumn get dataConclusao => dateTime().named('data_conclusao').nullable()();
	TextColumn get status => text().named('status').withLength(min: 0, max: 1).nullable()();

	@override
	Set<Column> get primaryKey => { id };	
	
}

class CrmTarefaGrouped {
	CrmTarefa? crmTarefa; 
	ViewPessoaCliente? viewPessoaCliente; 
	CrmOportunidade? crmOportunidade; 

  CrmTarefaGrouped({
		this.crmTarefa, 
		this.viewPessoaCliente, 
		this.crmOportunidade, 

  });
}
