import 'package:crm/app/data/provider/api/api_provider_base.dart';
import 'package:crm/app/data/model/model_imports.dart';

class CrmContatoApiProvider extends ApiProviderBase {
  static const _path = '/crm-contato';

  Future<List<CrmContatoModel>?> getList({Filter? filter}) {
    return super.getListBase(
      '$_path/',
      (json) => CrmContatoModel.fromJson(json),
      filter: filter,
    );
  }

  Future<CrmContatoModel?> getObject(dynamic pk) {
    return super.getObjectBase(
      _path,
      pk,
      (json) => CrmContatoModel.fromJson(json),
    );
  }

  Future<CrmContatoModel?>? insert(CrmContatoModel model) {
    return super.insertBase(
      _path,
      model,
      (json) => CrmContatoModel.fromJson(json),
    );
  }

  Future<CrmContatoModel?>? update(CrmContatoModel model) {
    return super.updateBase(
      _path,
      model,
      (json) => CrmContatoModel.fromJson(json),
    );
  }

  Future<bool?> delete(dynamic pk) {
    return super.deleteBase(_path, pk);
  }
}
