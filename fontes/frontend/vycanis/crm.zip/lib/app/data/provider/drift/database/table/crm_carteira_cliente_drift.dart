import 'package:drift/drift.dart';
import 'package:crm/app/data/provider/drift/database/database.dart';

@DataClassName("CrmCarteiraCliente")
class CrmCarteiraClientes extends Table {
	@override
	String get tableName => 'crm_carteira_cliente';

	IntColumn get id => integer().named('id').nullable()();
	IntColumn get idCliente => integer().named('id_cliente').nullable()();
	IntColumn get idCrmCarteiraClientePerfil => integer().named('id_crm_carteira_cliente_perfil').nullable()();

	@override
	Set<Column> get primaryKey => { id };	
	
}

class CrmCarteiraClienteGrouped {
	CrmCarteiraCliente? crmCarteiraCliente; 
	ViewPessoaCliente? viewPessoaCliente; 

  CrmCarteiraClienteGrouped({
		this.crmCarteiraCliente, 
		this.viewPessoaCliente, 

  });
}
