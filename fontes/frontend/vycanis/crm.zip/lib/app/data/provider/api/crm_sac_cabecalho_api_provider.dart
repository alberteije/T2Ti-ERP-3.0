import 'package:crm/app/data/provider/api/api_provider_base.dart';
import 'package:crm/app/data/model/model_imports.dart';

class CrmSacCabecalhoApiProvider extends ApiProviderBase {
  static const _path = '/crm-sac-cabecalho';

  Future<List<CrmSacCabecalhoModel>?> getList({Filter? filter}) {
    return super.getListBase(
      '$_path/',
      (json) => CrmSacCabecalhoModel.fromJson(json),
      filter: filter,
    );
  }

  Future<CrmSacCabecalhoModel?> getObject(dynamic pk) {
    return super.getObjectBase(
      _path,
      pk,
      (json) => CrmSacCabecalhoModel.fromJson(json),
    );
  }

  Future<CrmSacCabecalhoModel?>? insert(CrmSacCabecalhoModel model) {
    return super.insertBase(
      _path,
      model,
      (json) => CrmSacCabecalhoModel.fromJson(json),
    );
  }

  Future<CrmSacCabecalhoModel?>? update(CrmSacCabecalhoModel model) {
    return super.updateBase(
      _path,
      model,
      (json) => CrmSacCabecalhoModel.fromJson(json),
    );
  }

  Future<bool?> delete(dynamic pk) {
    return super.deleteBase(_path, pk);
  }
}
