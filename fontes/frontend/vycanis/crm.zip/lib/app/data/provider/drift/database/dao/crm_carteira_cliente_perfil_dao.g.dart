// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'crm_carteira_cliente_perfil_dao.dart';

// ignore_for_file: type=lint
mixin _$CrmCarteiraClientePerfilDaoMixin on DatabaseAccessor<AppDatabase> {
  $CrmCarteiraClientePerfilsTable get crmCarteiraClientePerfils =>
      attachedDatabase.crmCarteiraClientePerfils;
  $CrmCarteiraClientesTable get crmCarteiraClientes =>
      attachedDatabase.crmCarteiraClientes;
  $ViewPessoaClientesTable get viewPessoaClientes =>
      attachedDatabase.viewPessoaClientes;
}
