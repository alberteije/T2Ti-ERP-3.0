import 'package:drift/drift.dart';
import 'package:crm/app/data/provider/drift/database/database.dart';
import 'package:crm/app/data/provider/drift/database/database_imports.dart';

@DataClassName("CrmSacCabecalho")
class CrmSacCabecalhos extends Table {
	@override
	String get tableName => 'crm_sac_cabecalho';

	IntColumn get id => integer().named('id').nullable()();
	IntColumn get idCliente => integer().named('id_cliente').nullable()();
	DateTimeColumn get dataAbertura => dateTime().named('data_abertura').nullable()();
	TextColumn get horaAbertura => text().named('hora_abertura').withLength(min: 0, max: 8).nullable()();
	TextColumn get nivelReclamacao => text().named('nivel_reclamacao').withLength(min: 0, max: 1).nullable()();
	TextColumn get numeroProtocolo => text().named('numero_protocolo').withLength(min: 0, max: 100).nullable()();

	@override
	Set<Column> get primaryKey => { id };	
	
}

class CrmSacCabecalhoGrouped {
	CrmSacCabecalho? crmSacCabecalho; 
	List<CrmSacDetalheGrouped>? crmSacDetalheGroupedList; 
	ViewPessoaCliente? viewPessoaCliente; 

  CrmSacCabecalhoGrouped({
		this.crmSacCabecalho, 
		this.crmSacDetalheGroupedList, 
		this.viewPessoaCliente, 

  });
}
