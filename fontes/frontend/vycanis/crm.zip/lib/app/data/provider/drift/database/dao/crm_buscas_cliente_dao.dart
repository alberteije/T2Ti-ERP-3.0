import 'package:drift/drift.dart';
import 'package:crm/app/data/provider/drift/database/database.dart';
import 'package:crm/app/data/provider/drift/database/database_imports.dart';

part 'crm_buscas_cliente_dao.g.dart';

@DriftAccessor(tables: [
	CrmBuscasClientes,
	ViewPessoaClientes,
])
class CrmBuscasClienteDao extends DatabaseAccessor<AppDatabase> with _$CrmBuscasClienteDaoMixin {
	final AppDatabase db;

	List<CrmBuscasCliente> crmBuscasClienteList = []; 
	List<CrmBuscasClienteGrouped> crmBuscasClienteGroupedList = []; 

	CrmBuscasClienteDao(this.db) : super(db);

	Future<List<CrmBuscasCliente>> getList() async {
		crmBuscasClienteList = await select(crmBuscasClientes).get();
		return crmBuscasClienteList;
	}

	Future<List<CrmBuscasCliente>> getListFilter(String field, String value) async {
		final query = " $field like '%$value%'";
		final expression = CustomExpression<bool>(query);
		crmBuscasClienteList = await (select(crmBuscasClientes)..where((t) => expression)).get();
		return crmBuscasClienteList;	 
	}

	Future<List<CrmBuscasClienteGrouped>> getGroupedList({String? field, dynamic value}) async {
		final query = select(crmBuscasClientes)
			.join([ 
				leftOuterJoin(viewPessoaClientes, viewPessoaClientes.id.equalsExp(crmBuscasClientes.idCliente)), 
			]);

		if (field != null && field != '') { 
			final column = crmBuscasClientes.$columns.where(((column) => column.$name == field)).first;
			if (column is TextColumn) {
				query.where((column as TextColumn).like('%$value%'));
			} else if (column is IntColumn) {
				query.where(column.equals(int.tryParse(value) as Object));
			} else if (column is RealColumn) {
				query.where(column.equals(double.tryParse(value) as Object));
			}
		}

		crmBuscasClienteGroupedList = await query.map((row) {
			final crmBuscasCliente = row.readTableOrNull(crmBuscasClientes); 
			final viewPessoaCliente = row.readTableOrNull(viewPessoaClientes); 

			return CrmBuscasClienteGrouped(
				crmBuscasCliente: crmBuscasCliente, 
				viewPessoaCliente: viewPessoaCliente, 

			);
		}).get();

		// fill internal lists
		//dynamic expression;
		//for (var crmBuscasClienteGrouped in crmBuscasClienteGroupedList) {
		//}		

		return crmBuscasClienteGroupedList;	
	}

	Future<CrmBuscasCliente?> getObject(dynamic pk) async {
		return await (select(crmBuscasClientes)..where((t) => t.id.equals(pk))).getSingleOrNull();
	} 

	Future<CrmBuscasCliente?> getObjectFilter(String field, String value) async {
		final query = "SELECT * FROM crm_buscas_cliente WHERE $field like '%$value%'";
		return (await customSelect(query).getSingleOrNull()) as CrmBuscasCliente;		 
	} 

	Future<CrmBuscasClienteGrouped?> getObjectGrouped({String? field, dynamic value}) async {
		final result = await getGroupedList(field: field, value: value);

		if (result.length != 1) {
			return null;
		} else {
			return result[0];
		} 
	}

	Future<int> insertObject(CrmBuscasClienteGrouped object) {
		return transaction(() async {
			final maxPk = await lastPk();
			object.crmBuscasCliente = object.crmBuscasCliente!.copyWith(id: Value(maxPk + 1));
			final pkInserted = await into(crmBuscasClientes).insert(object.crmBuscasCliente!);
			object.crmBuscasCliente = object.crmBuscasCliente!.copyWith(id: Value(pkInserted));			 
			await insertChildren(object);
			return pkInserted;
		});		
	}	 

	Future<bool> updateObject(CrmBuscasClienteGrouped object) {
		return transaction(() async {
			await deleteChildren(object);
			await insertChildren(object);
			return update(crmBuscasClientes).replace(object.crmBuscasCliente!);
		});	 
	} 

	Future<int> deleteObject(CrmBuscasClienteGrouped object) {
		return transaction(() async {
			await deleteChildren(object);
			return delete(crmBuscasClientes).delete(object.crmBuscasCliente!);
		});		
	}

	Future<void> insertChildren(CrmBuscasClienteGrouped object) async {
	}
	
	Future<void> deleteChildren(CrmBuscasClienteGrouped object) async {
	}

	Future<int> lastPk() async {
		final result = await customSelect("select MAX(id) as LAST from crm_buscas_cliente").getSingleOrNull();
		return result?.data["LAST"] ?? 0;
	} 
}