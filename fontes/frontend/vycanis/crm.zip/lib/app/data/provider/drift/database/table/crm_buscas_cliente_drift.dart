import 'package:drift/drift.dart';
import 'package:crm/app/data/provider/drift/database/database.dart';

@DataClassName("CrmBuscasCliente")
class CrmBuscasClientes extends Table {
	@override
	String get tableName => 'crm_buscas_cliente';

	IntColumn get id => integer().named('id').nullable()();
	IntColumn get idCliente => integer().named('id_cliente').nullable()();
	DateTimeColumn get dataBusca => dateTime().named('data_busca').nullable()();
	TextColumn get horaBusca => text().named('hora_busca').withLength(min: 0, max: 8).nullable()();
	TextColumn get detalhes => text().named('detalhes').nullable()();

	@override
	Set<Column> get primaryKey => { id };	
	
}

class CrmBuscasClienteGrouped {
	CrmBuscasCliente? crmBuscasCliente; 
	ViewPessoaCliente? viewPessoaCliente; 

  CrmBuscasClienteGrouped({
		this.crmBuscasCliente, 
		this.viewPessoaCliente, 

  });
}
