import 'package:crm/app/data/provider/drift/database/database_imports.dart';
import 'package:crm/app/infra/infra_imports.dart';
import 'package:crm/app/data/provider/provider_base.dart';
import 'package:crm/app/data/provider/drift/database/database.dart';
import 'package:crm/app/data/model/model_imports.dart';
import 'package:crm/app/data/domain/domain_imports.dart';

class CrmSacCabecalhoDriftProvider extends ProviderBase {

	Future<List<CrmSacCabecalhoModel>?> getList({Filter? filter}) async {
		List<CrmSacCabecalhoGrouped> crmSacCabecalhoDriftList = [];

		try {
			if (filter != null && filter.field != null) {
				crmSacCabecalhoDriftList = await Session.database.crmSacCabecalhoDao.getGroupedList(field: filter.field, value: filter.value!);
			} else {
				crmSacCabecalhoDriftList = await Session.database.crmSacCabecalhoDao.getGroupedList(); 
			}
			if (crmSacCabecalhoDriftList.isNotEmpty) {
				return toListModel(crmSacCabecalhoDriftList);
			} else {
				return [];
			}			 
		} catch (e) {
			handleResultError(null, null, exception: e);
			return null;
		}
	}

	Future<CrmSacCabecalhoModel?> getObject(dynamic pk) async {
		try {
			final result = await Session.database.crmSacCabecalhoDao.getObjectGrouped(field: 'id', value: pk);
			return toModel(result);
		} catch (e) {
			handleResultError(null, null, exception: e);
		}
		return null;
	}

	Future<CrmSacCabecalhoModel?>? insert(CrmSacCabecalhoModel crmSacCabecalhoModel) async {
		try {
			final lastPk = await Session.database.crmSacCabecalhoDao.insertObject(toDrift(crmSacCabecalhoModel));
			crmSacCabecalhoModel.id = lastPk;
			return crmSacCabecalhoModel;
		} catch (e) {
			handleResultError(null, null, exception: e);
		}
		return null;
	}

	Future<CrmSacCabecalhoModel?>? update(CrmSacCabecalhoModel crmSacCabecalhoModel) async {
		try {
			await Session.database.crmSacCabecalhoDao.updateObject(toDrift(crmSacCabecalhoModel));
			return crmSacCabecalhoModel;
		} catch (e) {
			handleResultError(null, null, exception: e);
		}
		return null;
	}

	Future<bool?> delete(dynamic pk) async {
		try {
			await Session.database.crmSacCabecalhoDao.deleteObject(toDrift(CrmSacCabecalhoModel(id: pk)));
			return true;
		} catch (e) {
			handleResultError(null, null, exception: e);
		}
		return null;
	}	

	List<CrmSacCabecalhoModel> toListModel(List<CrmSacCabecalhoGrouped> crmSacCabecalhoDriftList) {
		List<CrmSacCabecalhoModel> listModel = [];
		for (var crmSacCabecalhoDrift in crmSacCabecalhoDriftList) {
			listModel.add(toModel(crmSacCabecalhoDrift)!);
		}
		return listModel;
	}	

	CrmSacCabecalhoModel? toModel(CrmSacCabecalhoGrouped? crmSacCabecalhoDrift) {
		if (crmSacCabecalhoDrift != null) {
			return CrmSacCabecalhoModel(
				id: crmSacCabecalhoDrift.crmSacCabecalho?.id,
				idCliente: crmSacCabecalhoDrift.crmSacCabecalho?.idCliente,
				dataAbertura: crmSacCabecalhoDrift.crmSacCabecalho?.dataAbertura,
				horaAbertura: crmSacCabecalhoDrift.crmSacCabecalho?.horaAbertura,
				nivelReclamacao: CrmSacCabecalhoDomain.getNivelReclamacao(crmSacCabecalhoDrift.crmSacCabecalho?.nivelReclamacao),
				numeroProtocolo: crmSacCabecalhoDrift.crmSacCabecalho?.numeroProtocolo,
				crmSacDetalheModelList: crmSacDetalheDriftToModel(crmSacCabecalhoDrift.crmSacDetalheGroupedList),
				viewPessoaClienteModel: ViewPessoaClienteModel(
					id: crmSacCabecalhoDrift.viewPessoaCliente?.id,
					nome: crmSacCabecalhoDrift.viewPessoaCliente?.nome,
					tipo: crmSacCabecalhoDrift.viewPessoaCliente?.tipo,
					email: crmSacCabecalhoDrift.viewPessoaCliente?.email,
					site: crmSacCabecalhoDrift.viewPessoaCliente?.site,
					cpfCnpj: crmSacCabecalhoDrift.viewPessoaCliente?.cpfCnpj,
					rgIe: crmSacCabecalhoDrift.viewPessoaCliente?.rgIe,
					desde: crmSacCabecalhoDrift.viewPessoaCliente?.desde,
					taxaDesconto: crmSacCabecalhoDrift.viewPessoaCliente?.taxaDesconto,
					limiteCredito: crmSacCabecalhoDrift.viewPessoaCliente?.limiteCredito,
					dataCadastro: crmSacCabecalhoDrift.viewPessoaCliente?.dataCadastro,
					observacao: crmSacCabecalhoDrift.viewPessoaCliente?.observacao,
					idPessoa: crmSacCabecalhoDrift.viewPessoaCliente?.idPessoa,
				),
			);
		} else {
			return null;
		}
	}

	List<CrmSacDetalheModel> crmSacDetalheDriftToModel(List<CrmSacDetalheGrouped>? crmSacDetalheDriftList) { 
		List<CrmSacDetalheModel> crmSacDetalheModelList = [];
		if (crmSacDetalheDriftList != null) {
			for (var crmSacDetalheGrouped in crmSacDetalheDriftList) {
				crmSacDetalheModelList.add(
					CrmSacDetalheModel(
						id: crmSacDetalheGrouped.crmSacDetalhe?.id,
						idCrmSacCabecalho: crmSacDetalheGrouped.crmSacDetalhe?.idCrmSacCabecalho,
						idViewPessoaColaborador: crmSacDetalheGrouped.crmSacDetalhe?.idViewPessoaColaborador,
						viewPessoaColaboradorModel: ViewPessoaColaboradorModel(
							id: crmSacDetalheGrouped.viewPessoaColaborador?.id,
							nome: crmSacDetalheGrouped.viewPessoaColaborador?.nome,
							tipo: crmSacDetalheGrouped.viewPessoaColaborador?.tipo,
							email: crmSacDetalheGrouped.viewPessoaColaborador?.email,
							site: crmSacDetalheGrouped.viewPessoaColaborador?.site,
							cpfCnpj: crmSacDetalheGrouped.viewPessoaColaborador?.cpfCnpj,
							rgIe: crmSacDetalheGrouped.viewPessoaColaborador?.rgIe,
							matricula: crmSacDetalheGrouped.viewPessoaColaborador?.matricula,
							dataCadastro: crmSacDetalheGrouped.viewPessoaColaborador?.dataCadastro,
							dataAdmissao: crmSacDetalheGrouped.viewPessoaColaborador?.dataAdmissao,
							dataDemissao: crmSacDetalheGrouped.viewPessoaColaborador?.dataDemissao,
							ctpsNumero: crmSacDetalheGrouped.viewPessoaColaborador?.ctpsNumero,
							ctpsSerie: crmSacDetalheGrouped.viewPessoaColaborador?.ctpsSerie,
							ctpsDataExpedicao: crmSacDetalheGrouped.viewPessoaColaborador?.ctpsDataExpedicao,
							ctpsUf: crmSacDetalheGrouped.viewPessoaColaborador?.ctpsUf,
							observacao: crmSacDetalheGrouped.viewPessoaColaborador?.observacao,
							logradouro: crmSacDetalheGrouped.viewPessoaColaborador?.logradouro,
							numero: crmSacDetalheGrouped.viewPessoaColaborador?.numero,
							complemento: crmSacDetalheGrouped.viewPessoaColaborador?.complemento,
							bairro: crmSacDetalheGrouped.viewPessoaColaborador?.bairro,
							cidade: crmSacDetalheGrouped.viewPessoaColaborador?.cidade,
							cep: crmSacDetalheGrouped.viewPessoaColaborador?.cep,
							municipioIbge: crmSacDetalheGrouped.viewPessoaColaborador?.municipioIbge,
							uf: crmSacDetalheGrouped.viewPessoaColaborador?.uf,
							idPessoa: crmSacDetalheGrouped.viewPessoaColaborador?.idPessoa,
							idCargo: crmSacDetalheGrouped.viewPessoaColaborador?.idCargo,
							idSetor: crmSacDetalheGrouped.viewPessoaColaborador?.idSetor,
						),
						dataRegistro: crmSacDetalheGrouped.crmSacDetalhe?.dataRegistro,
						horaRegistro: crmSacDetalheGrouped.crmSacDetalhe?.horaRegistro,
						historico: crmSacDetalheGrouped.crmSacDetalhe?.historico,
					)
				);
			}
			return crmSacDetalheModelList;
		}
		return [];
	}


	CrmSacCabecalhoGrouped toDrift(CrmSacCabecalhoModel crmSacCabecalhoModel) {
		return CrmSacCabecalhoGrouped(
			crmSacCabecalho: CrmSacCabecalho(
				id: crmSacCabecalhoModel.id,
				idCliente: crmSacCabecalhoModel.idCliente,
				dataAbertura: crmSacCabecalhoModel.dataAbertura,
				horaAbertura: Util.removeMask(crmSacCabecalhoModel.horaAbertura),
				nivelReclamacao: CrmSacCabecalhoDomain.setNivelReclamacao(crmSacCabecalhoModel.nivelReclamacao),
				numeroProtocolo: crmSacCabecalhoModel.numeroProtocolo,
			),
			crmSacDetalheGroupedList: crmSacDetalheModelToDrift(crmSacCabecalhoModel.crmSacDetalheModelList),
		);
	}

	List<CrmSacDetalheGrouped> crmSacDetalheModelToDrift(List<CrmSacDetalheModel>? crmSacDetalheModelList) { 
		List<CrmSacDetalheGrouped> crmSacDetalheGroupedList = [];
		if (crmSacDetalheModelList != null) {
			for (var crmSacDetalheModel in crmSacDetalheModelList) {
				crmSacDetalheGroupedList.add(
					CrmSacDetalheGrouped(
						crmSacDetalhe: CrmSacDetalhe(
							id: crmSacDetalheModel.id,
							idCrmSacCabecalho: crmSacDetalheModel.idCrmSacCabecalho,
							idViewPessoaColaborador: crmSacDetalheModel.idViewPessoaColaborador,
							dataRegistro: crmSacDetalheModel.dataRegistro,
							horaRegistro: Util.removeMask(crmSacDetalheModel.horaRegistro),
							historico: crmSacDetalheModel.historico,
						),
					),
				);
			}
			return crmSacDetalheGroupedList;
		}
		return [];
	}

		
}
