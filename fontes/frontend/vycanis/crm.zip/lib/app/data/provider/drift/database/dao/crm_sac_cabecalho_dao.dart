import 'package:drift/drift.dart';
import 'package:crm/app/data/provider/drift/database/database.dart';
import 'package:crm/app/data/provider/drift/database/database_imports.dart';

part 'crm_sac_cabecalho_dao.g.dart';

@DriftAccessor(tables: [
	CrmSacCabecalhos,
	CrmSacDetalhes,
	ViewPessoaColaboradors,
	ViewPessoaClientes,
])
class CrmSacCabecalhoDao extends DatabaseAccessor<AppDatabase> with _$CrmSacCabecalhoDaoMixin {
	final AppDatabase db;

	List<CrmSacCabecalho> crmSacCabecalhoList = []; 
	List<CrmSacCabecalhoGrouped> crmSacCabecalhoGroupedList = []; 

	CrmSacCabecalhoDao(this.db) : super(db);

	Future<List<CrmSacCabecalho>> getList() async {
		crmSacCabecalhoList = await select(crmSacCabecalhos).get();
		return crmSacCabecalhoList;
	}

	Future<List<CrmSacCabecalho>> getListFilter(String field, String value) async {
		final query = " $field like '%$value%'";
		final expression = CustomExpression<bool>(query);
		crmSacCabecalhoList = await (select(crmSacCabecalhos)..where((t) => expression)).get();
		return crmSacCabecalhoList;	 
	}

	Future<List<CrmSacCabecalhoGrouped>> getGroupedList({String? field, dynamic value}) async {
		final query = select(crmSacCabecalhos)
			.join([ 
				leftOuterJoin(viewPessoaClientes, viewPessoaClientes.id.equalsExp(crmSacCabecalhos.idCliente)), 
			]);

		if (field != null && field != '') { 
			final column = crmSacCabecalhos.$columns.where(((column) => column.$name == field)).first;
			if (column is TextColumn) {
				query.where((column as TextColumn).like('%$value%'));
			} else if (column is IntColumn) {
				query.where(column.equals(int.tryParse(value) as Object));
			} else if (column is RealColumn) {
				query.where(column.equals(double.tryParse(value) as Object));
			}
		}

		crmSacCabecalhoGroupedList = await query.map((row) {
			final crmSacCabecalho = row.readTableOrNull(crmSacCabecalhos); 
			final viewPessoaCliente = row.readTableOrNull(viewPessoaClientes); 

			return CrmSacCabecalhoGrouped(
				crmSacCabecalho: crmSacCabecalho, 
				viewPessoaCliente: viewPessoaCliente, 

			);
		}).get();

		// fill internal lists
		dynamic expression;
		for (var crmSacCabecalhoGrouped in crmSacCabecalhoGroupedList) {
			crmSacCabecalhoGrouped.crmSacDetalheGroupedList = [];
			final queryCrmSacDetalhe = ' id_crm_sac_cabecalho = ${crmSacCabecalhoGrouped.crmSacCabecalho!.id}';
			expression = CustomExpression<bool>(queryCrmSacDetalhe);
			final crmSacDetalheList = await (select(crmSacDetalhes)..where((t) => expression)).get();
			for (var crmSacDetalhe in crmSacDetalheList) {
				CrmSacDetalheGrouped crmSacDetalheGrouped = CrmSacDetalheGrouped(
					crmSacDetalhe: crmSacDetalhe,
					viewPessoaColaborador: await (select(viewPessoaColaboradors)..where((t) => t.id.equals(crmSacDetalhe.idViewPessoaColaborador!))).getSingleOrNull(),
				);
				crmSacCabecalhoGrouped.crmSacDetalheGroupedList!.add(crmSacDetalheGrouped);
			}

		}		

		return crmSacCabecalhoGroupedList;	
	}

	Future<CrmSacCabecalho?> getObject(dynamic pk) async {
		return await (select(crmSacCabecalhos)..where((t) => t.id.equals(pk))).getSingleOrNull();
	} 

	Future<CrmSacCabecalho?> getObjectFilter(String field, String value) async {
		final query = "SELECT * FROM crm_sac_cabecalho WHERE $field like '%$value%'";
		return (await customSelect(query).getSingleOrNull()) as CrmSacCabecalho;		 
	} 

	Future<CrmSacCabecalhoGrouped?> getObjectGrouped({String? field, dynamic value}) async {
		final result = await getGroupedList(field: field, value: value);

		if (result.length != 1) {
			return null;
		} else {
			return result[0];
		} 
	}

	Future<int> insertObject(CrmSacCabecalhoGrouped object) {
		return transaction(() async {
			final maxPk = await lastPk();
			object.crmSacCabecalho = object.crmSacCabecalho!.copyWith(id: Value(maxPk + 1));
			final pkInserted = await into(crmSacCabecalhos).insert(object.crmSacCabecalho!);
			object.crmSacCabecalho = object.crmSacCabecalho!.copyWith(id: Value(pkInserted));			 
			await insertChildren(object);
			return pkInserted;
		});		
	}	 

	Future<bool> updateObject(CrmSacCabecalhoGrouped object) {
		return transaction(() async {
			await deleteChildren(object);
			await insertChildren(object);
			return update(crmSacCabecalhos).replace(object.crmSacCabecalho!);
		});	 
	} 

	Future<int> deleteObject(CrmSacCabecalhoGrouped object) {
		return transaction(() async {
			await deleteChildren(object);
			return delete(crmSacCabecalhos).delete(object.crmSacCabecalho!);
		});		
	}

	Future<void> insertChildren(CrmSacCabecalhoGrouped object) async {
		for (var crmSacDetalheGrouped in object.crmSacDetalheGroupedList!) {
			crmSacDetalheGrouped.crmSacDetalhe = crmSacDetalheGrouped.crmSacDetalhe?.copyWith(
				id: const Value(null),
				idCrmSacCabecalho: Value(object.crmSacCabecalho!.id),
			);
			await into(crmSacDetalhes).insert(crmSacDetalheGrouped.crmSacDetalhe!);
		}
	}
	
	Future<void> deleteChildren(CrmSacCabecalhoGrouped object) async {
		await (delete(crmSacDetalhes)..where((t) => t.idCrmSacCabecalho.equals(object.crmSacCabecalho!.id!))).go();
	}

	Future<int> lastPk() async {
		final result = await customSelect("select MAX(id) as LAST from crm_sac_cabecalho").getSingleOrNull();
		return result?.data["LAST"] ?? 0;
	} 
}