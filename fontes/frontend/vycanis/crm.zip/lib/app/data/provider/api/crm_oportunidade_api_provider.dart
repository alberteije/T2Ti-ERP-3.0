import 'package:crm/app/data/provider/api/api_provider_base.dart';
import 'package:crm/app/data/model/model_imports.dart';

class CrmOportunidadeApiProvider extends ApiProviderBase {
  static const _path = '/crm-oportunidade';

  Future<List<CrmOportunidadeModel>?> getList({Filter? filter}) {
    return super.getListBase(
      '$_path/',
      (json) => CrmOportunidadeModel.fromJson(json),
      filter: filter,
    );
  }

  Future<CrmOportunidadeModel?> getObject(dynamic pk) {
    return super.getObjectBase(
      _path,
      pk,
      (json) => CrmOportunidadeModel.fromJson(json),
    );
  }

  Future<CrmOportunidadeModel?>? insert(CrmOportunidadeModel model) {
    return super.insertBase(
      _path,
      model,
      (json) => CrmOportunidadeModel.fromJson(json),
    );
  }

  Future<CrmOportunidadeModel?>? update(CrmOportunidadeModel model) {
    return super.updateBase(
      _path,
      model,
      (json) => CrmOportunidadeModel.fromJson(json),
    );
  }

  Future<bool?> delete(dynamic pk) {
    return super.deleteBase(_path, pk);
  }
}
