import 'package:drift/drift.dart';
import 'package:crm/app/data/provider/drift/database/database.dart';
import 'package:crm/app/data/provider/drift/database/database_imports.dart';

@DataClassName("CrmCampanha")
class CrmCampanhas extends Table {
	@override
	String get tableName => 'crm_campanha';

	IntColumn get id => integer().named('id').nullable()();
	TextColumn get nome => text().named('nome').withLength(min: 0, max: 200).nullable()();
	TextColumn get descricao => text().named('descricao').nullable()();
	TextColumn get tipo => text().named('tipo').withLength(min: 0, max: 1).nullable()();
	DateTimeColumn get dataInicio => dateTime().named('data_inicio').nullable()();
	DateTimeColumn get dataFim => dateTime().named('data_fim').nullable()();
	RealColumn get orcamento => real().named('orcamento').nullable()();
	TextColumn get status => text().named('status').withLength(min: 0, max: 1).nullable()();

	@override
	Set<Column> get primaryKey => { id };	
	
}

class CrmCampanhaGrouped {
	CrmCampanha? crmCampanha; 
	List<CrmCampanhaClienteGrouped>? crmCampanhaClienteGroupedList; 

  CrmCampanhaGrouped({
		this.crmCampanha, 
		this.crmCampanhaClienteGroupedList, 

  });
}
