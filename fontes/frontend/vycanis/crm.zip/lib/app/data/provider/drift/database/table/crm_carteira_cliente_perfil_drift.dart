import 'package:drift/drift.dart';
import 'package:crm/app/data/provider/drift/database/database.dart';
import 'package:crm/app/data/provider/drift/database/database_imports.dart';

@DataClassName("CrmCarteiraClientePerfil")
class CrmCarteiraClientePerfils extends Table {
	@override
	String get tableName => 'crm_carteira_cliente_perfil';

	IntColumn get id => integer().named('id').nullable()();
	TextColumn get codigo => text().named('codigo').withLength(min: 0, max: 2).nullable()();
	TextColumn get nome => text().named('nome').withLength(min: 0, max: 100).nullable()();

	@override
	Set<Column> get primaryKey => { id };	
	
}

class CrmCarteiraClientePerfilGrouped {
	CrmCarteiraClientePerfil? crmCarteiraClientePerfil; 
	List<CrmCarteiraClienteGrouped>? crmCarteiraClienteGroupedList; 

  CrmCarteiraClientePerfilGrouped({
		this.crmCarteiraClientePerfil, 
		this.crmCarteiraClienteGroupedList, 

  });
}
