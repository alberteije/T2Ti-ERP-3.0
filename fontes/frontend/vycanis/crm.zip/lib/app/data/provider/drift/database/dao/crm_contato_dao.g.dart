// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'crm_contato_dao.dart';

// ignore_for_file: type=lint
mixin _$CrmContatoDaoMixin on DatabaseAccessor<AppDatabase> {
  $CrmContatosTable get crmContatos => attachedDatabase.crmContatos;
  $ViewPessoaClientesTable get viewPessoaClientes =>
      attachedDatabase.viewPessoaClientes;
  $ViewPessoaColaboradorsTable get viewPessoaColaboradors =>
      attachedDatabase.viewPessoaColaboradors;
}
