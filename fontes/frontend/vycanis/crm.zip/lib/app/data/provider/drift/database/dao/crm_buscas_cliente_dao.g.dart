// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'crm_buscas_cliente_dao.dart';

// ignore_for_file: type=lint
mixin _$CrmBuscasClienteDaoMixin on DatabaseAccessor<AppDatabase> {
  $CrmBuscasClientesTable get crmBuscasClientes =>
      attachedDatabase.crmBuscasClientes;
  $ViewPessoaClientesTable get viewPessoaClientes =>
      attachedDatabase.viewPessoaClientes;
}
