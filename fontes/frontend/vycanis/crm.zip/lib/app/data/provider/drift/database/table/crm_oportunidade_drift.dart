import 'package:drift/drift.dart';
import 'package:crm/app/data/provider/drift/database/database.dart';

@DataClassName("CrmOportunidade")
class CrmOportunidades extends Table {
	@override
	String get tableName => 'crm_oportunidade';

	IntColumn get id => integer().named('id').nullable()();
	IntColumn get idCliente => integer().named('id_cliente').nullable()();
	IntColumn get idViewPessoaColaborador => integer().named('id_view_pessoa_colaborador').nullable()();
	TextColumn get titulo => text().named('titulo').withLength(min: 0, max: 200).nullable()();
	TextColumn get descricao => text().named('descricao').nullable()();
	RealColumn get valorEstimado => real().named('valor_estimado').nullable()();
	DateTimeColumn get dataAbertura => dateTime().named('data_abertura').nullable()();
	DateTimeColumn get dataFechamentoPrevisto => dateTime().named('data_fechamento_previsto').nullable()();
	DateTimeColumn get dataFechamentoReal => dateTime().named('data_fechamento_real').nullable()();
	TextColumn get status => text().named('status').withLength(min: 0, max: 1).nullable()();
	TextColumn get motivoFechamento => text().named('motivo_fechamento').withLength(min: 0, max: 1).nullable()();
	IntColumn get probabilidade => integer().named('probabilidade').nullable()();

	@override
	Set<Column> get primaryKey => { id };	
	
}

class CrmOportunidadeGrouped {
	CrmOportunidade? crmOportunidade; 
	ViewPessoaCliente? viewPessoaCliente; 
	ViewPessoaColaborador? viewPessoaColaborador; 

  CrmOportunidadeGrouped({
		this.crmOportunidade, 
		this.viewPessoaCliente, 
		this.viewPessoaColaborador, 

  });
}
