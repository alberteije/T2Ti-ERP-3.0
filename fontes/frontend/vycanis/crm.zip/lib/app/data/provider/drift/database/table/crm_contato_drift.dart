import 'package:drift/drift.dart';
import 'package:crm/app/data/provider/drift/database/database.dart';

@DataClassName("CrmContato")
class CrmContatos extends Table {
	@override
	String get tableName => 'crm_contato';

	IntColumn get id => integer().named('id').nullable()();
	IntColumn get idCliente => integer().named('id_cliente').nullable()();
	IntColumn get idViewPessoaColaborador => integer().named('id_view_pessoa_colaborador').nullable()();
	TextColumn get tipoContato => text().named('tipo_contato').withLength(min: 0, max: 1).nullable()();
	TextColumn get horaContato => text().named('hora_contato').withLength(min: 0, max: 8).nullable()();
	TextColumn get assunto => text().named('assunto').withLength(min: 0, max: 200).nullable()();
	TextColumn get descricao => text().named('descricao').nullable()();
	TextColumn get resultado => text().named('resultado').withLength(min: 0, max: 1).nullable()();
	DateTimeColumn get proximaData => dateTime().named('proxima_data').nullable()();
	TextColumn get proximaAcao => text().named('proxima_acao').nullable()();

	@override
	Set<Column> get primaryKey => { id };	
	
}

class CrmContatoGrouped {
	CrmContato? crmContato; 
	ViewPessoaCliente? viewPessoaCliente; 
	ViewPessoaColaborador? viewPessoaColaborador; 

  CrmContatoGrouped({
		this.crmContato, 
		this.viewPessoaCliente, 
		this.viewPessoaColaborador, 

  });
}
