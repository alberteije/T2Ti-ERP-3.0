import 'package:drift/drift.dart';
import 'package:crm/app/data/provider/drift/database/database.dart';
import 'package:crm/app/data/provider/drift/database/database_imports.dart';

part 'crm_tarefa_dao.g.dart';

@DriftAccessor(tables: [
	CrmTarefas,
	ViewPessoaClientes,
	CrmOportunidades,
])
class CrmTarefaDao extends DatabaseAccessor<AppDatabase> with _$CrmTarefaDaoMixin {
	final AppDatabase db;

	List<CrmTarefa> crmTarefaList = []; 
	List<CrmTarefaGrouped> crmTarefaGroupedList = []; 

	CrmTarefaDao(this.db) : super(db);

	Future<List<CrmTarefa>> getList() async {
		crmTarefaList = await select(crmTarefas).get();
		return crmTarefaList;
	}

	Future<List<CrmTarefa>> getListFilter(String field, String value) async {
		final query = " $field like '%$value%'";
		final expression = CustomExpression<bool>(query);
		crmTarefaList = await (select(crmTarefas)..where((t) => expression)).get();
		return crmTarefaList;	 
	}

	Future<List<CrmTarefaGrouped>> getGroupedList({String? field, dynamic value}) async {
		final query = select(crmTarefas)
			.join([ 
				leftOuterJoin(viewPessoaClientes, viewPessoaClientes.id.equalsExp(crmTarefas.idCliente)), 
			]).join([ 
				leftOuterJoin(crmOportunidades, crmOportunidades.id.equalsExp(crmTarefas.idOportunidade)), 
			]);

		if (field != null && field != '') { 
			final column = crmTarefas.$columns.where(((column) => column.$name == field)).first;
			if (column is TextColumn) {
				query.where((column as TextColumn).like('%$value%'));
			} else if (column is IntColumn) {
				query.where(column.equals(int.tryParse(value) as Object));
			} else if (column is RealColumn) {
				query.where(column.equals(double.tryParse(value) as Object));
			}
		}

		crmTarefaGroupedList = await query.map((row) {
			final crmTarefa = row.readTableOrNull(crmTarefas); 
			final viewPessoaCliente = row.readTableOrNull(viewPessoaClientes); 
			final crmOportunidade = row.readTableOrNull(crmOportunidades); 

			return CrmTarefaGrouped(
				crmTarefa: crmTarefa, 
				viewPessoaCliente: viewPessoaCliente, 
				crmOportunidade: crmOportunidade, 

			);
		}).get();

		// fill internal lists
		//dynamic expression;
		//for (var crmTarefaGrouped in crmTarefaGroupedList) {
		//}		

		return crmTarefaGroupedList;	
	}

	Future<CrmTarefa?> getObject(dynamic pk) async {
		return await (select(crmTarefas)..where((t) => t.id.equals(pk))).getSingleOrNull();
	} 

	Future<CrmTarefa?> getObjectFilter(String field, String value) async {
		final query = "SELECT * FROM crm_tarefa WHERE $field like '%$value%'";
		return (await customSelect(query).getSingleOrNull()) as CrmTarefa;		 
	} 

	Future<CrmTarefaGrouped?> getObjectGrouped({String? field, dynamic value}) async {
		final result = await getGroupedList(field: field, value: value);

		if (result.length != 1) {
			return null;
		} else {
			return result[0];
		} 
	}

	Future<int> insertObject(CrmTarefaGrouped object) {
		return transaction(() async {
			final maxPk = await lastPk();
			object.crmTarefa = object.crmTarefa!.copyWith(id: Value(maxPk + 1));
			final pkInserted = await into(crmTarefas).insert(object.crmTarefa!);
			object.crmTarefa = object.crmTarefa!.copyWith(id: Value(pkInserted));			 
			await insertChildren(object);
			return pkInserted;
		});		
	}	 

	Future<bool> updateObject(CrmTarefaGrouped object) {
		return transaction(() async {
			await deleteChildren(object);
			await insertChildren(object);
			return update(crmTarefas).replace(object.crmTarefa!);
		});	 
	} 

	Future<int> deleteObject(CrmTarefaGrouped object) {
		return transaction(() async {
			await deleteChildren(object);
			return delete(crmTarefas).delete(object.crmTarefa!);
		});		
	}

	Future<void> insertChildren(CrmTarefaGrouped object) async {
	}
	
	Future<void> deleteChildren(CrmTarefaGrouped object) async {
	}

	Future<int> lastPk() async {
		final result = await customSelect("select MAX(id) as LAST from crm_tarefa").getSingleOrNull();
		return result?.data["LAST"] ?? 0;
	} 
}