import 'package:drift/drift.dart';
import 'package:crm/app/data/provider/drift/database/database.dart';

@DataClassName("CrmSacDetalhe")
class CrmSacDetalhes extends Table {
	@override
	String get tableName => 'crm_sac_detalhe';

	IntColumn get id => integer().named('id').nullable()();
	IntColumn get idCrmSacCabecalho => integer().named('id_crm_sac_cabecalho').nullable()();
	IntColumn get idViewPessoaColaborador => integer().named('id_view_pessoa_colaborador').nullable()();
	DateTimeColumn get dataRegistro => dateTime().named('data_registro').nullable()();
	TextColumn get horaRegistro => text().named('hora_registro').withLength(min: 0, max: 8).nullable()();
	TextColumn get historico => text().named('historico').nullable()();

	@override
	Set<Column> get primaryKey => { id };	
	
}

class CrmSacDetalheGrouped {
	CrmSacDetalhe? crmSacDetalhe; 
	ViewPessoaColaborador? viewPessoaColaborador; 

  CrmSacDetalheGrouped({
		this.crmSacDetalhe, 
		this.viewPessoaColaborador, 

  });
}
