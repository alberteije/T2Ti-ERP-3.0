import 'package:crm/app/data/provider/drift/database/database_imports.dart';
import 'package:crm/app/infra/infra_imports.dart';
import 'package:crm/app/data/provider/provider_base.dart';
import 'package:crm/app/data/provider/drift/database/database.dart';
import 'package:crm/app/data/model/model_imports.dart';

class CrmCarteiraClientePerfilDriftProvider extends ProviderBase {

	Future<List<CrmCarteiraClientePerfilModel>?> getList({Filter? filter}) async {
		List<CrmCarteiraClientePerfilGrouped> crmCarteiraClientePerfilDriftList = [];

		try {
			if (filter != null && filter.field != null) {
				crmCarteiraClientePerfilDriftList = await Session.database.crmCarteiraClientePerfilDao.getGroupedList(field: filter.field, value: filter.value!);
			} else {
				crmCarteiraClientePerfilDriftList = await Session.database.crmCarteiraClientePerfilDao.getGroupedList(); 
			}
			if (crmCarteiraClientePerfilDriftList.isNotEmpty) {
				return toListModel(crmCarteiraClientePerfilDriftList);
			} else {
				return [];
			}			 
		} catch (e) {
			handleResultError(null, null, exception: e);
			return null;
		}
	}

	Future<CrmCarteiraClientePerfilModel?> getObject(dynamic pk) async {
		try {
			final result = await Session.database.crmCarteiraClientePerfilDao.getObjectGrouped(field: 'id', value: pk);
			return toModel(result);
		} catch (e) {
			handleResultError(null, null, exception: e);
		}
		return null;
	}

	Future<CrmCarteiraClientePerfilModel?>? insert(CrmCarteiraClientePerfilModel crmCarteiraClientePerfilModel) async {
		try {
			final lastPk = await Session.database.crmCarteiraClientePerfilDao.insertObject(toDrift(crmCarteiraClientePerfilModel));
			crmCarteiraClientePerfilModel.id = lastPk;
			return crmCarteiraClientePerfilModel;
		} catch (e) {
			handleResultError(null, null, exception: e);
		}
		return null;
	}

	Future<CrmCarteiraClientePerfilModel?>? update(CrmCarteiraClientePerfilModel crmCarteiraClientePerfilModel) async {
		try {
			await Session.database.crmCarteiraClientePerfilDao.updateObject(toDrift(crmCarteiraClientePerfilModel));
			return crmCarteiraClientePerfilModel;
		} catch (e) {
			handleResultError(null, null, exception: e);
		}
		return null;
	}

	Future<bool?> delete(dynamic pk) async {
		try {
			await Session.database.crmCarteiraClientePerfilDao.deleteObject(toDrift(CrmCarteiraClientePerfilModel(id: pk)));
			return true;
		} catch (e) {
			handleResultError(null, null, exception: e);
		}
		return null;
	}	

	List<CrmCarteiraClientePerfilModel> toListModel(List<CrmCarteiraClientePerfilGrouped> crmCarteiraClientePerfilDriftList) {
		List<CrmCarteiraClientePerfilModel> listModel = [];
		for (var crmCarteiraClientePerfilDrift in crmCarteiraClientePerfilDriftList) {
			listModel.add(toModel(crmCarteiraClientePerfilDrift)!);
		}
		return listModel;
	}	

	CrmCarteiraClientePerfilModel? toModel(CrmCarteiraClientePerfilGrouped? crmCarteiraClientePerfilDrift) {
		if (crmCarteiraClientePerfilDrift != null) {
			return CrmCarteiraClientePerfilModel(
				id: crmCarteiraClientePerfilDrift.crmCarteiraClientePerfil?.id,
				codigo: crmCarteiraClientePerfilDrift.crmCarteiraClientePerfil?.codigo,
				nome: crmCarteiraClientePerfilDrift.crmCarteiraClientePerfil?.nome,
				crmCarteiraClienteModelList: crmCarteiraClienteDriftToModel(crmCarteiraClientePerfilDrift.crmCarteiraClienteGroupedList),
			);
		} else {
			return null;
		}
	}

	List<CrmCarteiraClienteModel> crmCarteiraClienteDriftToModel(List<CrmCarteiraClienteGrouped>? crmCarteiraClienteDriftList) { 
		List<CrmCarteiraClienteModel> crmCarteiraClienteModelList = [];
		if (crmCarteiraClienteDriftList != null) {
			for (var crmCarteiraClienteGrouped in crmCarteiraClienteDriftList) {
				crmCarteiraClienteModelList.add(
					CrmCarteiraClienteModel(
						id: crmCarteiraClienteGrouped.crmCarteiraCliente?.id,
						idCliente: crmCarteiraClienteGrouped.crmCarteiraCliente?.idCliente,
						viewPessoaClienteModel: ViewPessoaClienteModel(
							id: crmCarteiraClienteGrouped.viewPessoaCliente?.id,
							nome: crmCarteiraClienteGrouped.viewPessoaCliente?.nome,
							tipo: crmCarteiraClienteGrouped.viewPessoaCliente?.tipo,
							email: crmCarteiraClienteGrouped.viewPessoaCliente?.email,
							site: crmCarteiraClienteGrouped.viewPessoaCliente?.site,
							cpfCnpj: crmCarteiraClienteGrouped.viewPessoaCliente?.cpfCnpj,
							rgIe: crmCarteiraClienteGrouped.viewPessoaCliente?.rgIe,
							desde: crmCarteiraClienteGrouped.viewPessoaCliente?.desde,
							taxaDesconto: crmCarteiraClienteGrouped.viewPessoaCliente?.taxaDesconto,
							limiteCredito: crmCarteiraClienteGrouped.viewPessoaCliente?.limiteCredito,
							dataCadastro: crmCarteiraClienteGrouped.viewPessoaCliente?.dataCadastro,
							observacao: crmCarteiraClienteGrouped.viewPessoaCliente?.observacao,
							idPessoa: crmCarteiraClienteGrouped.viewPessoaCliente?.idPessoa,
						),
						idCrmCarteiraClientePerfil: crmCarteiraClienteGrouped.crmCarteiraCliente?.idCrmCarteiraClientePerfil,
					)
				);
			}
			return crmCarteiraClienteModelList;
		}
		return [];
	}


	CrmCarteiraClientePerfilGrouped toDrift(CrmCarteiraClientePerfilModel crmCarteiraClientePerfilModel) {
		return CrmCarteiraClientePerfilGrouped(
			crmCarteiraClientePerfil: CrmCarteiraClientePerfil(
				id: crmCarteiraClientePerfilModel.id,
				codigo: crmCarteiraClientePerfilModel.codigo,
				nome: crmCarteiraClientePerfilModel.nome,
			),
			crmCarteiraClienteGroupedList: crmCarteiraClienteModelToDrift(crmCarteiraClientePerfilModel.crmCarteiraClienteModelList),
		);
	}

	List<CrmCarteiraClienteGrouped> crmCarteiraClienteModelToDrift(List<CrmCarteiraClienteModel>? crmCarteiraClienteModelList) { 
		List<CrmCarteiraClienteGrouped> crmCarteiraClienteGroupedList = [];
		if (crmCarteiraClienteModelList != null) {
			for (var crmCarteiraClienteModel in crmCarteiraClienteModelList) {
				crmCarteiraClienteGroupedList.add(
					CrmCarteiraClienteGrouped(
						crmCarteiraCliente: CrmCarteiraCliente(
							id: crmCarteiraClienteModel.id,
							idCliente: crmCarteiraClienteModel.idCliente,
							idCrmCarteiraClientePerfil: crmCarteiraClienteModel.idCrmCarteiraClientePerfil,
						),
					),
				);
			}
			return crmCarteiraClienteGroupedList;
		}
		return [];
	}

		
}
