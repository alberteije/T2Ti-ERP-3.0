import 'package:crm/app/data/provider/api/api_provider_base.dart';
import 'package:crm/app/data/model/model_imports.dart';

class CrmBuscasClienteApiProvider extends ApiProviderBase {
  static const _path = '/crm-buscas-cliente';

  Future<List<CrmBuscasClienteModel>?> getList({Filter? filter}) {
    return super.getListBase(
      '$_path/',
      (json) => CrmBuscasClienteModel.fromJson(json),
      filter: filter,
    );
  }

  Future<CrmBuscasClienteModel?> getObject(dynamic pk) {
    return super.getObjectBase(
      _path,
      pk,
      (json) => CrmBuscasClienteModel.fromJson(json),
    );
  }

  Future<CrmBuscasClienteModel?>? insert(CrmBuscasClienteModel model) {
    return super.insertBase(
      _path,
      model,
      (json) => CrmBuscasClienteModel.fromJson(json),
    );
  }

  Future<CrmBuscasClienteModel?>? update(CrmBuscasClienteModel model) {
    return super.updateBase(
      _path,
      model,
      (json) => CrmBuscasClienteModel.fromJson(json),
    );
  }

  Future<bool?> delete(dynamic pk) {
    return super.deleteBase(_path, pk);
  }
}
