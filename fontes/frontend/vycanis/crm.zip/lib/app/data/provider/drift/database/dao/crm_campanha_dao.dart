import 'package:drift/drift.dart';
import 'package:crm/app/data/provider/drift/database/database.dart';
import 'package:crm/app/data/provider/drift/database/database_imports.dart';

part 'crm_campanha_dao.g.dart';

@DriftAccessor(tables: [
	CrmCampanhas,
	CrmCampanhaClientes,
	ViewPessoaClientes,
])
class CrmCampanhaDao extends DatabaseAccessor<AppDatabase> with _$CrmCampanhaDaoMixin {
	final AppDatabase db;

	List<CrmCampanha> crmCampanhaList = []; 
	List<CrmCampanhaGrouped> crmCampanhaGroupedList = []; 

	CrmCampanhaDao(this.db) : super(db);

	Future<List<CrmCampanha>> getList() async {
		crmCampanhaList = await select(crmCampanhas).get();
		return crmCampanhaList;
	}

	Future<List<CrmCampanha>> getListFilter(String field, String value) async {
		final query = " $field like '%$value%'";
		final expression = CustomExpression<bool>(query);
		crmCampanhaList = await (select(crmCampanhas)..where((t) => expression)).get();
		return crmCampanhaList;	 
	}

	Future<List<CrmCampanhaGrouped>> getGroupedList({String? field, dynamic value}) async {
		final query = select(crmCampanhas)
			.join([]);

		if (field != null && field != '') { 
			final column = crmCampanhas.$columns.where(((column) => column.$name == field)).first;
			if (column is TextColumn) {
				query.where((column as TextColumn).like('%$value%'));
			} else if (column is IntColumn) {
				query.where(column.equals(int.tryParse(value) as Object));
			} else if (column is RealColumn) {
				query.where(column.equals(double.tryParse(value) as Object));
			}
		}

		crmCampanhaGroupedList = await query.map((row) {
			final crmCampanha = row.readTableOrNull(crmCampanhas); 

			return CrmCampanhaGrouped(
				crmCampanha: crmCampanha, 

			);
		}).get();

		// fill internal lists
		dynamic expression;
		for (var crmCampanhaGrouped in crmCampanhaGroupedList) {
			crmCampanhaGrouped.crmCampanhaClienteGroupedList = [];
			final queryCrmCampanhaCliente = ' id_campanha = ${crmCampanhaGrouped.crmCampanha!.id}';
			expression = CustomExpression<bool>(queryCrmCampanhaCliente);
			final crmCampanhaClienteList = await (select(crmCampanhaClientes)..where((t) => expression)).get();
			for (var crmCampanhaCliente in crmCampanhaClienteList) {
				CrmCampanhaClienteGrouped crmCampanhaClienteGrouped = CrmCampanhaClienteGrouped(
					crmCampanhaCliente: crmCampanhaCliente,
					viewPessoaCliente: await (select(viewPessoaClientes)..where((t) => t.id.equals(crmCampanhaCliente.idCliente!))).getSingleOrNull(),
				);
				crmCampanhaGrouped.crmCampanhaClienteGroupedList!.add(crmCampanhaClienteGrouped);
			}

		}		

		return crmCampanhaGroupedList;	
	}

	Future<CrmCampanha?> getObject(dynamic pk) async {
		return await (select(crmCampanhas)..where((t) => t.id.equals(pk))).getSingleOrNull();
	} 

	Future<CrmCampanha?> getObjectFilter(String field, String value) async {
		final query = "SELECT * FROM crm_campanha WHERE $field like '%$value%'";
		return (await customSelect(query).getSingleOrNull()) as CrmCampanha;		 
	} 

	Future<CrmCampanhaGrouped?> getObjectGrouped({String? field, dynamic value}) async {
		final result = await getGroupedList(field: field, value: value);

		if (result.length != 1) {
			return null;
		} else {
			return result[0];
		} 
	}

	Future<int> insertObject(CrmCampanhaGrouped object) {
		return transaction(() async {
			final maxPk = await lastPk();
			object.crmCampanha = object.crmCampanha!.copyWith(id: Value(maxPk + 1));
			final pkInserted = await into(crmCampanhas).insert(object.crmCampanha!);
			object.crmCampanha = object.crmCampanha!.copyWith(id: Value(pkInserted));			 
			await insertChildren(object);
			return pkInserted;
		});		
	}	 

	Future<bool> updateObject(CrmCampanhaGrouped object) {
		return transaction(() async {
			await deleteChildren(object);
			await insertChildren(object);
			return update(crmCampanhas).replace(object.crmCampanha!);
		});	 
	} 

	Future<int> deleteObject(CrmCampanhaGrouped object) {
		return transaction(() async {
			await deleteChildren(object);
			return delete(crmCampanhas).delete(object.crmCampanha!);
		});		
	}

	Future<void> insertChildren(CrmCampanhaGrouped object) async {
		for (var crmCampanhaClienteGrouped in object.crmCampanhaClienteGroupedList!) {
			crmCampanhaClienteGrouped.crmCampanhaCliente = crmCampanhaClienteGrouped.crmCampanhaCliente?.copyWith(
				id: const Value(null),
				idCampanha: Value(object.crmCampanha!.id),
			);
			await into(crmCampanhaClientes).insert(crmCampanhaClienteGrouped.crmCampanhaCliente!);
		}
	}
	
	Future<void> deleteChildren(CrmCampanhaGrouped object) async {
		await (delete(crmCampanhaClientes)..where((t) => t.idCampanha.equals(object.crmCampanha!.id!))).go();
	}

	Future<int> lastPk() async {
		final result = await customSelect("select MAX(id) as LAST from crm_campanha").getSingleOrNull();
		return result?.data["LAST"] ?? 0;
	} 
}