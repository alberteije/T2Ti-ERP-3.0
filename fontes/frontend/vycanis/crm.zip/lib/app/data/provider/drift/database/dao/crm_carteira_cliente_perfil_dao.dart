import 'package:drift/drift.dart';
import 'package:crm/app/data/provider/drift/database/database.dart';
import 'package:crm/app/data/provider/drift/database/database_imports.dart';

part 'crm_carteira_cliente_perfil_dao.g.dart';

@DriftAccessor(tables: [
	CrmCarteiraClientePerfils,
	CrmCarteiraClientes,
	ViewPessoaClientes,
])
class CrmCarteiraClientePerfilDao extends DatabaseAccessor<AppDatabase> with _$CrmCarteiraClientePerfilDaoMixin {
	final AppDatabase db;

	List<CrmCarteiraClientePerfil> crmCarteiraClientePerfilList = []; 
	List<CrmCarteiraClientePerfilGrouped> crmCarteiraClientePerfilGroupedList = []; 

	CrmCarteiraClientePerfilDao(this.db) : super(db);

	Future<List<CrmCarteiraClientePerfil>> getList() async {
		crmCarteiraClientePerfilList = await select(crmCarteiraClientePerfils).get();
		return crmCarteiraClientePerfilList;
	}

	Future<List<CrmCarteiraClientePerfil>> getListFilter(String field, String value) async {
		final query = " $field like '%$value%'";
		final expression = CustomExpression<bool>(query);
		crmCarteiraClientePerfilList = await (select(crmCarteiraClientePerfils)..where((t) => expression)).get();
		return crmCarteiraClientePerfilList;	 
	}

	Future<List<CrmCarteiraClientePerfilGrouped>> getGroupedList({String? field, dynamic value}) async {
		final query = select(crmCarteiraClientePerfils)
			.join([]);

		if (field != null && field != '') { 
			final column = crmCarteiraClientePerfils.$columns.where(((column) => column.$name == field)).first;
			if (column is TextColumn) {
				query.where((column as TextColumn).like('%$value%'));
			} else if (column is IntColumn) {
				query.where(column.equals(int.tryParse(value) as Object));
			} else if (column is RealColumn) {
				query.where(column.equals(double.tryParse(value) as Object));
			}
		}

		crmCarteiraClientePerfilGroupedList = await query.map((row) {
			final crmCarteiraClientePerfil = row.readTableOrNull(crmCarteiraClientePerfils); 

			return CrmCarteiraClientePerfilGrouped(
				crmCarteiraClientePerfil: crmCarteiraClientePerfil, 

			);
		}).get();

		// fill internal lists
		dynamic expression;
		for (var crmCarteiraClientePerfilGrouped in crmCarteiraClientePerfilGroupedList) {
			crmCarteiraClientePerfilGrouped.crmCarteiraClienteGroupedList = [];
			final queryCrmCarteiraCliente = ' id_crm_carteira_cliente_perfil = ${crmCarteiraClientePerfilGrouped.crmCarteiraClientePerfil!.id}';
			expression = CustomExpression<bool>(queryCrmCarteiraCliente);
			final crmCarteiraClienteList = await (select(crmCarteiraClientes)..where((t) => expression)).get();
			for (var crmCarteiraCliente in crmCarteiraClienteList) {
				CrmCarteiraClienteGrouped crmCarteiraClienteGrouped = CrmCarteiraClienteGrouped(
					crmCarteiraCliente: crmCarteiraCliente,
					viewPessoaCliente: await (select(viewPessoaClientes)..where((t) => t.id.equals(crmCarteiraCliente.idCliente!))).getSingleOrNull(),
				);
				crmCarteiraClientePerfilGrouped.crmCarteiraClienteGroupedList!.add(crmCarteiraClienteGrouped);
			}

		}		

		return crmCarteiraClientePerfilGroupedList;	
	}

	Future<CrmCarteiraClientePerfil?> getObject(dynamic pk) async {
		return await (select(crmCarteiraClientePerfils)..where((t) => t.id.equals(pk))).getSingleOrNull();
	} 

	Future<CrmCarteiraClientePerfil?> getObjectFilter(String field, String value) async {
		final query = "SELECT * FROM crm_carteira_cliente_perfil WHERE $field like '%$value%'";
		return (await customSelect(query).getSingleOrNull()) as CrmCarteiraClientePerfil;		 
	} 

	Future<CrmCarteiraClientePerfilGrouped?> getObjectGrouped({String? field, dynamic value}) async {
		final result = await getGroupedList(field: field, value: value);

		if (result.length != 1) {
			return null;
		} else {
			return result[0];
		} 
	}

	Future<int> insertObject(CrmCarteiraClientePerfilGrouped object) {
		return transaction(() async {
			final maxPk = await lastPk();
			object.crmCarteiraClientePerfil = object.crmCarteiraClientePerfil!.copyWith(id: Value(maxPk + 1));
			final pkInserted = await into(crmCarteiraClientePerfils).insert(object.crmCarteiraClientePerfil!);
			object.crmCarteiraClientePerfil = object.crmCarteiraClientePerfil!.copyWith(id: Value(pkInserted));			 
			await insertChildren(object);
			return pkInserted;
		});		
	}	 

	Future<bool> updateObject(CrmCarteiraClientePerfilGrouped object) {
		return transaction(() async {
			await deleteChildren(object);
			await insertChildren(object);
			return update(crmCarteiraClientePerfils).replace(object.crmCarteiraClientePerfil!);
		});	 
	} 

	Future<int> deleteObject(CrmCarteiraClientePerfilGrouped object) {
		return transaction(() async {
			await deleteChildren(object);
			return delete(crmCarteiraClientePerfils).delete(object.crmCarteiraClientePerfil!);
		});		
	}

	Future<void> insertChildren(CrmCarteiraClientePerfilGrouped object) async {
		for (var crmCarteiraClienteGrouped in object.crmCarteiraClienteGroupedList!) {
			crmCarteiraClienteGrouped.crmCarteiraCliente = crmCarteiraClienteGrouped.crmCarteiraCliente?.copyWith(
				id: const Value(null),
				idCrmCarteiraClientePerfil: Value(object.crmCarteiraClientePerfil!.id),
			);
			await into(crmCarteiraClientes).insert(crmCarteiraClienteGrouped.crmCarteiraCliente!);
		}
	}
	
	Future<void> deleteChildren(CrmCarteiraClientePerfilGrouped object) async {
		await (delete(crmCarteiraClientes)..where((t) => t.idCrmCarteiraClientePerfil.equals(object.crmCarteiraClientePerfil!.id!))).go();
	}

	Future<int> lastPk() async {
		final result = await customSelect("select MAX(id) as LAST from crm_carteira_cliente_perfil").getSingleOrNull();
		return result?.data["LAST"] ?? 0;
	} 
}