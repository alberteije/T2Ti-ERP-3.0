import 'package:crm/app/infra/constants.dart';
import 'package:crm/app/data/provider/api/crm_campanha_api_provider.dart';
import 'package:crm/app/data/provider/drift/crm_campanha_drift_provider.dart';
import 'package:crm/app/data/model/model_imports.dart';

class CrmCampanhaRepository {
  final CrmCampanhaApiProvider crmCampanhaApiProvider;
  final CrmCampanhaDriftProvider crmCampanhaDriftProvider;

  CrmCampanhaRepository({required this.crmCampanhaApiProvider, required this.crmCampanhaDriftProvider});

  Future getList({Filter? filter}) async {
    if (Constants.usingLocalDatabase) {
      return await crmCampanhaDriftProvider.getList(filter: filter);
    } else {
      return await crmCampanhaApiProvider.getList(filter: filter);
    }
  }

  Future<CrmCampanhaModel?>? save({required CrmCampanhaModel crmCampanhaModel}) async {
    if (crmCampanhaModel.id != null) {
      if (Constants.usingLocalDatabase) {
        return await crmCampanhaDriftProvider.update(crmCampanhaModel);
      } else {
        return await crmCampanhaApiProvider.update(crmCampanhaModel);
      }
    } else {
      if (Constants.usingLocalDatabase) {
        return await crmCampanhaDriftProvider.insert(crmCampanhaModel);
      } else {
        return await crmCampanhaApiProvider.insert(crmCampanhaModel);
      }
    }   
  }

  Future<bool> delete({required int id}) async {
    if (Constants.usingLocalDatabase) {
      return await crmCampanhaDriftProvider.delete(id) ?? false;
    } else {
      return await crmCampanhaApiProvider.delete(id) ?? false;
    }
  }
}