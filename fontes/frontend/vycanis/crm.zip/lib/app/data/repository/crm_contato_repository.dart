import 'package:crm/app/infra/constants.dart';
import 'package:crm/app/data/provider/api/crm_contato_api_provider.dart';
import 'package:crm/app/data/provider/drift/crm_contato_drift_provider.dart';
import 'package:crm/app/data/model/model_imports.dart';

class CrmContatoRepository {
  final CrmContatoApiProvider crmContatoApiProvider;
  final CrmContatoDriftProvider crmContatoDriftProvider;

  CrmContatoRepository({required this.crmContatoApiProvider, required this.crmContatoDriftProvider});

  Future getList({Filter? filter}) async {
    if (Constants.usingLocalDatabase) {
      return await crmContatoDriftProvider.getList(filter: filter);
    } else {
      return await crmContatoApiProvider.getList(filter: filter);
    }
  }

  Future<CrmContatoModel?>? save({required CrmContatoModel crmContatoModel}) async {
    if (crmContatoModel.id != null) {
      if (Constants.usingLocalDatabase) {
        return await crmContatoDriftProvider.update(crmContatoModel);
      } else {
        return await crmContatoApiProvider.update(crmContatoModel);
      }
    } else {
      if (Constants.usingLocalDatabase) {
        return await crmContatoDriftProvider.insert(crmContatoModel);
      } else {
        return await crmContatoApiProvider.insert(crmContatoModel);
      }
    }   
  }

  Future<bool> delete({required int id}) async {
    if (Constants.usingLocalDatabase) {
      return await crmContatoDriftProvider.delete(id) ?? false;
    } else {
      return await crmContatoApiProvider.delete(id) ?? false;
    }
  }
}