import 'package:crm/app/infra/constants.dart';
import 'package:crm/app/data/provider/api/crm_buscas_cliente_api_provider.dart';
import 'package:crm/app/data/provider/drift/crm_buscas_cliente_drift_provider.dart';
import 'package:crm/app/data/model/model_imports.dart';

class CrmBuscasClienteRepository {
  final CrmBuscasClienteApiProvider crmBuscasClienteApiProvider;
  final CrmBuscasClienteDriftProvider crmBuscasClienteDriftProvider;

  CrmBuscasClienteRepository({required this.crmBuscasClienteApiProvider, required this.crmBuscasClienteDriftProvider});

  Future getList({Filter? filter}) async {
    if (Constants.usingLocalDatabase) {
      return await crmBuscasClienteDriftProvider.getList(filter: filter);
    } else {
      return await crmBuscasClienteApiProvider.getList(filter: filter);
    }
  }

  Future<CrmBuscasClienteModel?>? save({required CrmBuscasClienteModel crmBuscasClienteModel}) async {
    if (crmBuscasClienteModel.id != null) {
      if (Constants.usingLocalDatabase) {
        return await crmBuscasClienteDriftProvider.update(crmBuscasClienteModel);
      } else {
        return await crmBuscasClienteApiProvider.update(crmBuscasClienteModel);
      }
    } else {
      if (Constants.usingLocalDatabase) {
        return await crmBuscasClienteDriftProvider.insert(crmBuscasClienteModel);
      } else {
        return await crmBuscasClienteApiProvider.insert(crmBuscasClienteModel);
      }
    }   
  }

  Future<bool> delete({required int id}) async {
    if (Constants.usingLocalDatabase) {
      return await crmBuscasClienteDriftProvider.delete(id) ?? false;
    } else {
      return await crmBuscasClienteApiProvider.delete(id) ?? false;
    }
  }
}