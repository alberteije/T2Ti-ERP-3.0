import 'package:crm/app/infra/constants.dart';
import 'package:crm/app/data/provider/api/crm_carteira_cliente_perfil_api_provider.dart';
import 'package:crm/app/data/provider/drift/crm_carteira_cliente_perfil_drift_provider.dart';
import 'package:crm/app/data/model/model_imports.dart';

class CrmCarteiraClientePerfilRepository {
  final CrmCarteiraClientePerfilApiProvider crmCarteiraClientePerfilApiProvider;
  final CrmCarteiraClientePerfilDriftProvider crmCarteiraClientePerfilDriftProvider;

  CrmCarteiraClientePerfilRepository({required this.crmCarteiraClientePerfilApiProvider, required this.crmCarteiraClientePerfilDriftProvider});

  Future getList({Filter? filter}) async {
    if (Constants.usingLocalDatabase) {
      return await crmCarteiraClientePerfilDriftProvider.getList(filter: filter);
    } else {
      return await crmCarteiraClientePerfilApiProvider.getList(filter: filter);
    }
  }

  Future<CrmCarteiraClientePerfilModel?>? save({required CrmCarteiraClientePerfilModel crmCarteiraClientePerfilModel}) async {
    if (crmCarteiraClientePerfilModel.id != null) {
      if (Constants.usingLocalDatabase) {
        return await crmCarteiraClientePerfilDriftProvider.update(crmCarteiraClientePerfilModel);
      } else {
        return await crmCarteiraClientePerfilApiProvider.update(crmCarteiraClientePerfilModel);
      }
    } else {
      if (Constants.usingLocalDatabase) {
        return await crmCarteiraClientePerfilDriftProvider.insert(crmCarteiraClientePerfilModel);
      } else {
        return await crmCarteiraClientePerfilApiProvider.insert(crmCarteiraClientePerfilModel);
      }
    }   
  }

  Future<bool> delete({required int id}) async {
    if (Constants.usingLocalDatabase) {
      return await crmCarteiraClientePerfilDriftProvider.delete(id) ?? false;
    } else {
      return await crmCarteiraClientePerfilApiProvider.delete(id) ?? false;
    }
  }
}