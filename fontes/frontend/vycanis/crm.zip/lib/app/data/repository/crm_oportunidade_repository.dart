import 'package:crm/app/infra/constants.dart';
import 'package:crm/app/data/provider/api/crm_oportunidade_api_provider.dart';
import 'package:crm/app/data/provider/drift/crm_oportunidade_drift_provider.dart';
import 'package:crm/app/data/model/model_imports.dart';

class CrmOportunidadeRepository {
  final CrmOportunidadeApiProvider crmOportunidadeApiProvider;
  final CrmOportunidadeDriftProvider crmOportunidadeDriftProvider;

  CrmOportunidadeRepository({required this.crmOportunidadeApiProvider, required this.crmOportunidadeDriftProvider});

  Future getList({Filter? filter}) async {
    if (Constants.usingLocalDatabase) {
      return await crmOportunidadeDriftProvider.getList(filter: filter);
    } else {
      return await crmOportunidadeApiProvider.getList(filter: filter);
    }
  }

  Future<CrmOportunidadeModel?>? save({required CrmOportunidadeModel crmOportunidadeModel}) async {
    if (crmOportunidadeModel.id != null) {
      if (Constants.usingLocalDatabase) {
        return await crmOportunidadeDriftProvider.update(crmOportunidadeModel);
      } else {
        return await crmOportunidadeApiProvider.update(crmOportunidadeModel);
      }
    } else {
      if (Constants.usingLocalDatabase) {
        return await crmOportunidadeDriftProvider.insert(crmOportunidadeModel);
      } else {
        return await crmOportunidadeApiProvider.insert(crmOportunidadeModel);
      }
    }   
  }

  Future<bool> delete({required int id}) async {
    if (Constants.usingLocalDatabase) {
      return await crmOportunidadeDriftProvider.delete(id) ?? false;
    } else {
      return await crmOportunidadeApiProvider.delete(id) ?? false;
    }
  }
}