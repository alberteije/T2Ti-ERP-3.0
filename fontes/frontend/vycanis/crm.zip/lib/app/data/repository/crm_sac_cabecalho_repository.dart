import 'package:crm/app/infra/constants.dart';
import 'package:crm/app/data/provider/api/crm_sac_cabecalho_api_provider.dart';
import 'package:crm/app/data/provider/drift/crm_sac_cabecalho_drift_provider.dart';
import 'package:crm/app/data/model/model_imports.dart';

class CrmSacCabecalhoRepository {
  final CrmSacCabecalhoApiProvider crmSacCabecalhoApiProvider;
  final CrmSacCabecalhoDriftProvider crmSacCabecalhoDriftProvider;

  CrmSacCabecalhoRepository({required this.crmSacCabecalhoApiProvider, required this.crmSacCabecalhoDriftProvider});

  Future getList({Filter? filter}) async {
    if (Constants.usingLocalDatabase) {
      return await crmSacCabecalhoDriftProvider.getList(filter: filter);
    } else {
      return await crmSacCabecalhoApiProvider.getList(filter: filter);
    }
  }

  Future<CrmSacCabecalhoModel?>? save({required CrmSacCabecalhoModel crmSacCabecalhoModel}) async {
    if (crmSacCabecalhoModel.id != null) {
      if (Constants.usingLocalDatabase) {
        return await crmSacCabecalhoDriftProvider.update(crmSacCabecalhoModel);
      } else {
        return await crmSacCabecalhoApiProvider.update(crmSacCabecalhoModel);
      }
    } else {
      if (Constants.usingLocalDatabase) {
        return await crmSacCabecalhoDriftProvider.insert(crmSacCabecalhoModel);
      } else {
        return await crmSacCabecalhoApiProvider.insert(crmSacCabecalhoModel);
      }
    }   
  }

  Future<bool> delete({required int id}) async {
    if (Constants.usingLocalDatabase) {
      return await crmSacCabecalhoDriftProvider.delete(id) ?? false;
    } else {
      return await crmSacCabecalhoApiProvider.delete(id) ?? false;
    }
  }
}