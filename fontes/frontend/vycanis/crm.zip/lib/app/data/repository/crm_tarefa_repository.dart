import 'package:crm/app/infra/constants.dart';
import 'package:crm/app/data/provider/api/crm_tarefa_api_provider.dart';
import 'package:crm/app/data/provider/drift/crm_tarefa_drift_provider.dart';
import 'package:crm/app/data/model/model_imports.dart';

class CrmTarefaRepository {
  final CrmTarefaApiProvider crmTarefaApiProvider;
  final CrmTarefaDriftProvider crmTarefaDriftProvider;

  CrmTarefaRepository({required this.crmTarefaApiProvider, required this.crmTarefaDriftProvider});

  Future getList({Filter? filter}) async {
    if (Constants.usingLocalDatabase) {
      return await crmTarefaDriftProvider.getList(filter: filter);
    } else {
      return await crmTarefaApiProvider.getList(filter: filter);
    }
  }

  Future<CrmTarefaModel?>? save({required CrmTarefaModel crmTarefaModel}) async {
    if (crmTarefaModel.id != null) {
      if (Constants.usingLocalDatabase) {
        return await crmTarefaDriftProvider.update(crmTarefaModel);
      } else {
        return await crmTarefaApiProvider.update(crmTarefaModel);
      }
    } else {
      if (Constants.usingLocalDatabase) {
        return await crmTarefaDriftProvider.insert(crmTarefaModel);
      } else {
        return await crmTarefaApiProvider.insert(crmTarefaModel);
      }
    }   
  }

  Future<bool> delete({required int id}) async {
    if (Constants.usingLocalDatabase) {
      return await crmTarefaDriftProvider.delete(id) ?? false;
    } else {
      return await crmTarefaApiProvider.delete(id) ?? false;
    }
  }
}