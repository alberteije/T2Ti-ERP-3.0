import 'package:flutter/material.dart';
import 'package:cadastros/app/controller/banco_conta_caixa_controller.dart';
import 'package:cadastros/app/page/shared_page/list_page_base.dart';

class BancoContaCaixaListPage extends ListPageBase<BancoContaCaixaController> {
  const BancoContaCaixaListPage({Key? key}) : super(key: key);

  @override
  List<Map<String, dynamic>> get mobileItems => controller.mobileItems;

  @override
  Map<String, dynamic> get mobileConfig => controller.mobileConfig;

  @override
  String get standardFieldForFilter => controller.standardFieldForFilter;
}