import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:extended_masked_text/extended_masked_text.dart';
import 'package:cadastros/app/page/grid_columns/grid_columns_imports.dart';
import 'package:cadastros/app/page/shared_widget/message_dialog.dart';
import 'package:cadastros/app/routes/app_routes.dart';
import 'package:cadastros/app/infra/infra_imports.dart';
import 'package:cadastros/app/controller/controller_imports.dart';
import 'package:cadastros/app/data/model/model_imports.dart';

class ClienteController extends ControllerBase<ClienteModel, void> {

  ClienteController() : super(repository: null) {
    dbColumns = ClienteModel.dbColumns;
    aliasColumns = ClienteModel.aliasColumns;
    functionName = "cliente";
    screenTitle = "Cliente";
  }

	String? mandatoryMessage;

  final _clienteModel = ClienteModel().obs;
  ClienteModel get clienteModel => Get.find<PessoaController>().currentModel.clienteModel ?? ClienteModel();
  set clienteModel(value) => _clienteModel.value = value ?? ClienteModel();

  final _formWasChangedDetail = false.obs;
  bool get formWasChangedDetail => _formWasChangedDetail.value;
  set formWasChangedDetail(value) => _formWasChangedDetail.value = value;

  final clienteScaffoldKey = GlobalKey<ScaffoldState>();
  final clienteFormKey = GlobalKey<FormState>();

  @override
  ClienteModel createNewModel() => ClienteModel();

  @override
  final standardFieldForFilter = "";

  final tabelaPrecoModelController = TextEditingController();
  final taxaDescontoController = MoneyMaskedTextController();
  final limiteCreditoController = MoneyMaskedTextController();
  final observacaoController = TextEditingController();

  final Map<String, dynamic> mobileConfig = {};

  List<Map<String, dynamic>> get mobileItems {
    return modelList.map((cliente) => cliente.toJson).toList();
  }

  @override
  Future<void> getList({Filter? filter}) async {}

  @override
  Future<void> loadData() async {}

  @override
  void prepareForInsert() {}

  @override
  void selectRowForEditingById(int id) {}

  void _resetForm() {
    formWasChangedDetail = false;
    tabelaPrecoModelController.text = '';
    taxaDescontoController.updateValue(0);
    limiteCreditoController.updateValue(0);
    observacaoController.text = '';
  }

  void updateControllersFromModel() {
		_resetForm();
    tabelaPrecoModelController.text = clienteModel.tabelaPrecoModel?.nome?.toString() ?? '';
    taxaDescontoController.updateValue(clienteModel.taxaDesconto ?? 0);
    limiteCreditoController.updateValue(clienteModel.limiteCredito ?? 0);
    observacaoController.text = clienteModel.observacao ?? '';
  }

  @override
  Future<void> save() async {}

	bool validateForm() {
    mandatoryMessage = ValidateFormField.validateMandatory(clienteModel.tabelaPrecoModel?.nome); 
		if (mandatoryMessage != null) { 
			showErrorSnackBar(message: '$mandatoryMessage [Tabela Preco]'); 
			return false; 
		}
    return true;
	}

  Future callTabelaPrecoLookup() async { 
		final lookupController = Get.find<LookupController>(); 
		lookupController.refreshItems(standardValue: '%'); 
		lookupController.title = '${'lookup_page_title'.tr} [Tabela Preco]'; 
		lookupController.route = '/tabela-preco/'; 
		lookupController.gridColumns = tabelaPrecoGridColumns(isForLookup: true); 
		lookupController.aliasColumns = TabelaPrecoModel.aliasColumns; 
		lookupController.dbColumns = TabelaPrecoModel.dbColumns; 
		lookupController.standardColumn = TabelaPrecoModel.aliasColumns[TabelaPrecoModel.dbColumns.indexOf('nome')]; 

		final plutoRowResult = await Get.toNamed(Routes.lookupPage); 
		if (plutoRowResult != null) { 
			clienteModel.idTabelaPreco = plutoRowResult.cells['id']!.value; 
			clienteModel.tabelaPrecoModel = TabelaPrecoModel.fromPlutoRow(plutoRowResult); 
			tabelaPrecoModelController.text = clienteModel.tabelaPrecoModel?.nome ?? ''; 
			formWasChanged = true; 
		}
	}


  @override
  void onClose() {
    tabelaPrecoModelController.dispose();
    taxaDescontoController.dispose();
    limiteCreditoController.dispose();
    observacaoController.dispose();
  }

}