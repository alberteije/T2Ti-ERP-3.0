import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:extended_masked_text/extended_masked_text.dart';

import 'package:cadastros/app/page/shared_widget/message_dialog.dart';
import 'package:cadastros/app/page/grid_columns/grid_columns_imports.dart';
import 'package:cadastros/app/routes/app_routes.dart';
import 'package:cadastros/app/controller/controller_imports.dart';
import 'package:cadastros/app/data/model/model_imports.dart';
import 'package:cadastros/app/data/repository/pais_repository.dart';

class PaisController extends ControllerBase<PaisModel, PaisRepository> {

  PaisController({required super.repository}) {
    dbColumns = PaisModel.dbColumns;
    aliasColumns = PaisModel.aliasColumns;
    gridColumns = paisGridColumns();
    functionName = "pais";
    screenTitle = "País";
  }

  @override
  PaisModel createNewModel() => PaisModel();

  @override
  final standardFieldForFilter = PaisModel.aliasColumns[PaisModel.dbColumns.indexOf('nome_ptbr')];

  final nomePtbrController = TextEditingController();
  final nomeEnController = TextEditingController();
  final codigoController = MoneyMaskedTextController(precision: 0, decimalSeparator: '', thousandSeparator: '');
  final sigla2Controller = TextEditingController();
  final sigla3Controller = TextEditingController();
  final codigoBacenController = MoneyMaskedTextController(precision: 0, decimalSeparator: '', thousandSeparator: '');

  final Map<String, dynamic> mobileConfig = {
    'primaryColumns': ['nome_ptbr'],
    'secondaryColumns': ['nome_en'],
  };

  List<Map<String, dynamic>> get mobileItems {
    return modelList.map((pais) => pais.toJson).toList();
  }

  @override
  void prepareForInsert() {
    isNewRecord = true;
    currentModel = createNewModel();
    _resetForm();
    Get.toNamed(Routes.paisEditPage);
  }

  void _resetForm() {
    formWasChanged = false;
    nomePtbrController.text = '';
    nomeEnController.text = '';
    codigoController.updateValue(0);
    sigla2Controller.text = '';
    sigla3Controller.text = '';
    codigoBacenController.updateValue(0);
  }

  @override
  void selectRowForEditingById(int id) {
    final model = modelList.firstWhere((m) => m.id == id);
    currentModel = model.clone();
    updateControllersFromModel();
    Get.toNamed(Routes.paisEditPage);
  }

  void updateControllersFromModel() {
    nomePtbrController.text = currentModel.nomePtbr ?? '';
    nomeEnController.text = currentModel.nomeEn ?? '';
    codigoController.updateValue((currentModel.codigo ?? 0).toDouble());
    sigla2Controller.text = currentModel.sigla2 ?? '';
    sigla3Controller.text = currentModel.sigla3 ?? '';
    codigoBacenController.updateValue((currentModel.codigoBacen ?? 0).toDouble());
    formWasChanged = false;
  }

  @override
  Future<void> save() async {
    if (!formKey.currentState!.validate()) {
      showErrorSnackBar(message: 'validator_form_message'.tr);
      return;
    }

    final existingIndex = modelList.indexWhere((m) => m.id == currentModel.id);

    if (existingIndex >= 0) {
      modelList[existingIndex] = currentModel.clone();
    }

    final result = await repository.save(paisModel: currentModel);
    if (result == null) return;

    if (existingIndex >= 0) {
      modelList[existingIndex] = result;
    } else {
      modelList.insert(0, result);
    }

    if (!GetPlatform.isMobile) {
      updateGridRow(result);
    }

    Get.back(result: true);
  }


  @override
  void onClose() {
    nomePtbrController.dispose();
    nomeEnController.dispose();
    codigoController.dispose();
    sigla2Controller.dispose();
    sigla3Controller.dispose();
    codigoBacenController.dispose();
    super.onClose();
  }

}