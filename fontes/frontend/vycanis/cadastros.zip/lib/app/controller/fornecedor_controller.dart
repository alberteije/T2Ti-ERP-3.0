import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:cadastros/app/controller/controller_imports.dart';
import 'package:cadastros/app/data/model/model_imports.dart';

class FornecedorController extends ControllerBase<FornecedorModel, void> {

  FornecedorController() : super(repository: null) {
    dbColumns = FornecedorModel.dbColumns;
    aliasColumns = FornecedorModel.aliasColumns;
    functionName = "fornecedor";
    screenTitle = "Fornecedor";
  }

	String? mandatoryMessage;

  final _fornecedorModel = FornecedorModel().obs;
  FornecedorModel get fornecedorModel => Get.find<PessoaController>().currentModel.fornecedorModel ?? FornecedorModel();
  set fornecedorModel(value) => _fornecedorModel.value = value ?? FornecedorModel();

  final _formWasChangedDetail = false.obs;
  bool get formWasChangedDetail => _formWasChangedDetail.value;
  set formWasChangedDetail(value) => _formWasChangedDetail.value = value;

  final fornecedorScaffoldKey = GlobalKey<ScaffoldState>();
  final fornecedorFormKey = GlobalKey<FormState>();

  @override
  FornecedorModel createNewModel() => FornecedorModel();

  @override
  final standardFieldForFilter = "";

  final observacaoController = TextEditingController();

  final Map<String, dynamic> mobileConfig = {};

  List<Map<String, dynamic>> get mobileItems {
    return modelList.map((fornecedor) => fornecedor.toJson).toList();
  }

  @override
  Future<void> getList({Filter? filter}) async {}

  @override
  Future<void> loadData() async {}

  @override
  void prepareForInsert() {}

  @override
  void selectRowForEditingById(int id) {}

  void _resetForm() {
    formWasChangedDetail = false;
    observacaoController.text = '';
  }

  void updateControllersFromModel() {
		_resetForm();
    observacaoController.text = fornecedorModel.observacao ?? '';
  }

  @override
  Future<void> save() async {}

	bool validateForm() {
    return true;
	}


  @override
  void onClose() {
    observacaoController.dispose();
  }

}