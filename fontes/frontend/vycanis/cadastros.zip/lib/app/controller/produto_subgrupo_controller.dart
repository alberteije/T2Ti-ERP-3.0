import 'package:flutter/material.dart';
import 'package:get/get.dart';

import 'package:cadastros/app/page/shared_widget/message_dialog.dart';
import 'package:cadastros/app/page/grid_columns/grid_columns_imports.dart';
import 'package:cadastros/app/routes/app_routes.dart';
import 'package:cadastros/app/controller/controller_imports.dart';
import 'package:cadastros/app/data/model/model_imports.dart';
import 'package:cadastros/app/data/repository/produto_subgrupo_repository.dart';

class ProdutoSubgrupoController extends ControllerBase<ProdutoSubgrupoModel, ProdutoSubgrupoRepository> {

  ProdutoSubgrupoController({required super.repository}) {
    dbColumns = ProdutoSubgrupoModel.dbColumns;
    aliasColumns = ProdutoSubgrupoModel.aliasColumns;
    gridColumns = produtoSubgrupoGridColumns();
    functionName = "produto_subgrupo";
    screenTitle = "Subgrupo Produto";
  }

  @override
  ProdutoSubgrupoModel createNewModel() => ProdutoSubgrupoModel();

  @override
  final standardFieldForFilter = ProdutoSubgrupoModel.aliasColumns[ProdutoSubgrupoModel.dbColumns.indexOf('nome')];

  final produtoGrupoModelController = TextEditingController();
  final nomeController = TextEditingController();
  final descricaoController = TextEditingController();

  final Map<String, dynamic> mobileConfig = {
    'primaryColumns': ['nome'],
    'secondaryColumns': ['descricao'],
  };

  List<Map<String, dynamic>> get mobileItems {
    return modelList.map((produtoSubgrupo) => produtoSubgrupo.toJson).toList();
  }

  @override
  void prepareForInsert() {
    isNewRecord = true;
    currentModel = createNewModel();
    _resetForm();
    Get.toNamed(Routes.produtoSubgrupoEditPage);
  }

  void _resetForm() {
    formWasChanged = false;
    produtoGrupoModelController.text = '';
    nomeController.text = '';
    descricaoController.text = '';
  }

  @override
  void selectRowForEditingById(int id) {
    final model = modelList.firstWhere((m) => m.id == id);
    currentModel = model.clone();
    updateControllersFromModel();
    Get.toNamed(Routes.produtoSubgrupoEditPage);
  }

  void updateControllersFromModel() {
    produtoGrupoModelController.text = currentModel.produtoGrupoModel?.nome?.toString() ?? '';
    nomeController.text = currentModel.nome ?? '';
    descricaoController.text = currentModel.descricao ?? '';
    formWasChanged = false;
  }

  @override
  Future<void> save() async {
    if (!formKey.currentState!.validate()) {
      showErrorSnackBar(message: 'validator_form_message'.tr);
      return;
    }

    final existingIndex = modelList.indexWhere((m) => m.id == currentModel.id);

    if (existingIndex >= 0) {
      modelList[existingIndex] = currentModel.clone();
    }

    final result = await repository.save(produtoSubgrupoModel: currentModel);
    if (result == null) return;

    if (existingIndex >= 0) {
      modelList[existingIndex] = result;
    } else {
      modelList.insert(0, result);
    }

    if (!GetPlatform.isMobile) {
      updateGridRow(result);
    }

    Get.back(result: true);
  }

  Future callProdutoGrupoLookup() async { 
		final lookupController = Get.find<LookupController>(); 
		lookupController.refreshItems(standardValue: '%'); 
		lookupController.title = '${'lookup_page_title'.tr} [Grupo]'; 
		lookupController.route = '/produto-grupo/'; 
		lookupController.gridColumns = produtoGrupoGridColumns(isForLookup: true); 
		lookupController.aliasColumns = ProdutoGrupoModel.aliasColumns; 
		lookupController.dbColumns = ProdutoGrupoModel.dbColumns; 
		lookupController.standardColumn = ProdutoGrupoModel.aliasColumns[ProdutoGrupoModel.dbColumns.indexOf('nome')]; 

		final plutoRowResult = await Get.toNamed(Routes.lookupPage); 
		if (plutoRowResult != null) { 
			currentModel.idProdutoGrupo = plutoRowResult.cells['id']!.value; 
			currentModel.produtoGrupoModel = ProdutoGrupoModel.fromPlutoRow(plutoRowResult); 
			produtoGrupoModelController.text = currentModel.produtoGrupoModel?.nome ?? ''; 
			formWasChanged = true; 
		}
	}


  @override
  void onClose() {
    produtoGrupoModelController.dispose();
    nomeController.dispose();
    descricaoController.dispose();
    super.onClose();
  }

}