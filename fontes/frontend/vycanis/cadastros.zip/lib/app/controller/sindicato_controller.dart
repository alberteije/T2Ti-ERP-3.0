import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:extended_masked_text/extended_masked_text.dart';

import 'package:cadastros/app/page/shared_widget/message_dialog.dart';
import 'package:cadastros/app/page/grid_columns/grid_columns_imports.dart';
import 'package:cadastros/app/routes/app_routes.dart';
import 'package:cadastros/app/controller/controller_imports.dart';
import 'package:cadastros/app/data/model/model_imports.dart';
import 'package:cadastros/app/data/repository/sindicato_repository.dart';

class SindicatoController extends ControllerBase<SindicatoModel, SindicatoRepository> {

  SindicatoController({required super.repository}) {
    dbColumns = SindicatoModel.dbColumns;
    aliasColumns = SindicatoModel.aliasColumns;
    gridColumns = sindicatoGridColumns();
    functionName = "sindicato";
    screenTitle = "Sindicato";
  }

  @override
  SindicatoModel createNewModel() => SindicatoModel();

  @override
  final standardFieldForFilter = SindicatoModel.aliasColumns[SindicatoModel.dbColumns.indexOf('nome')];

  final nomeController = TextEditingController();
  final codigoBancoController = MoneyMaskedTextController(precision: 0, decimalSeparator: '', thousandSeparator: '');
  final codigoAgenciaController = MoneyMaskedTextController(precision: 0, decimalSeparator: '', thousandSeparator: '');
  final contaBancoController = TextEditingController();
  final codigoCedenteController = TextEditingController();
  final logradouroController = TextEditingController();
  final numeroController = TextEditingController();
  final bairroController = TextEditingController();
  final municipioIbgeController = MoneyMaskedTextController(precision: 0, decimalSeparator: '', thousandSeparator: '');
  final fone1Controller = MaskedTextController(mask: '(00)00000-0000',);
  final fone2Controller = MaskedTextController(mask: '(00)00000-0000',);
  final emailController = TextEditingController();
  final pisoSalarialController = MoneyMaskedTextController();
  final cnpjController = MaskedTextController(mask: '00.000.000/0000-00',);
  final classificacaoContabilContaController = TextEditingController();

  final Map<String, dynamic> mobileConfig = {
    'primaryColumns': ['nome'],
    'secondaryColumns': ['codigo_banco'],
  };

  List<Map<String, dynamic>> get mobileItems {
    return modelList.map((sindicato) => sindicato.toJson).toList();
  }

  @override
  void prepareForInsert() {
    isNewRecord = true;
    currentModel = createNewModel();
    _resetForm();
    Get.toNamed(Routes.sindicatoEditPage);
  }

  void _resetForm() {
    formWasChanged = false;
    nomeController.text = '';
    codigoBancoController.updateValue(0);
    codigoAgenciaController.updateValue(0);
    contaBancoController.text = '';
    codigoCedenteController.text = '';
    logradouroController.text = '';
    numeroController.text = '';
    bairroController.text = '';
    municipioIbgeController.updateValue(0);
    fone1Controller.text = '';
    fone2Controller.text = '';
    emailController.text = '';
    pisoSalarialController.updateValue(0);
    cnpjController.text = '';
    classificacaoContabilContaController.text = '';
  }

  @override
  void selectRowForEditingById(int id) {
    final model = modelList.firstWhere((m) => m.id == id);
    currentModel = model.clone();
    updateControllersFromModel();
    Get.toNamed(Routes.sindicatoEditPage);
  }

  void updateControllersFromModel() {
    nomeController.text = currentModel.nome ?? '';
    codigoBancoController.updateValue((currentModel.codigoBanco ?? 0).toDouble());
    codigoAgenciaController.updateValue((currentModel.codigoAgencia ?? 0).toDouble());
    contaBancoController.text = currentModel.contaBanco ?? '';
    codigoCedenteController.text = currentModel.codigoCedente ?? '';
    logradouroController.text = currentModel.logradouro ?? '';
    numeroController.text = currentModel.numero ?? '';
    bairroController.text = currentModel.bairro ?? '';
    municipioIbgeController.updateValue((currentModel.municipioIbge ?? 0).toDouble());
    fone1Controller.text = currentModel.fone1 ?? '';
    fone2Controller.text = currentModel.fone2 ?? '';
    emailController.text = currentModel.email ?? '';
    pisoSalarialController.updateValue(currentModel.pisoSalarial ?? 0);
    cnpjController.text = currentModel.cnpj ?? '';
    classificacaoContabilContaController.text = currentModel.classificacaoContabilConta ?? '';
    formWasChanged = false;
  }

  @override
  Future<void> save() async {
    if (!formKey.currentState!.validate()) {
      showErrorSnackBar(message: 'validator_form_message'.tr);
      return;
    }

    final existingIndex = modelList.indexWhere((m) => m.id == currentModel.id);

    if (existingIndex >= 0) {
      modelList[existingIndex] = currentModel.clone();
    }

    final result = await repository.save(sindicatoModel: currentModel);
    if (result == null) return;

    if (existingIndex >= 0) {
      modelList[existingIndex] = result;
    } else {
      modelList.insert(0, result);
    }

    if (!GetPlatform.isMobile) {
      updateGridRow(result);
    }

    Get.back(result: true);
  }


  @override
  void onClose() {
    nomeController.dispose();
    codigoBancoController.dispose();
    codigoAgenciaController.dispose();
    contaBancoController.dispose();
    codigoCedenteController.dispose();
    logradouroController.dispose();
    numeroController.dispose();
    bairroController.dispose();
    municipioIbgeController.dispose();
    fone1Controller.dispose();
    fone2Controller.dispose();
    emailController.dispose();
    pisoSalarialController.dispose();
    cnpjController.dispose();
    classificacaoContabilContaController.dispose();
    super.onClose();
  }

}