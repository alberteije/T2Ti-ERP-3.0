import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:extended_masked_text/extended_masked_text.dart';

import 'package:cadastros/app/page/shared_widget/message_dialog.dart';
import 'package:cadastros/app/page/grid_columns/grid_columns_imports.dart';
import 'package:cadastros/app/routes/app_routes.dart';
import 'package:cadastros/app/controller/controller_imports.dart';
import 'package:cadastros/app/data/model/model_imports.dart';
import 'package:cadastros/app/data/repository/uf_repository.dart';

class UfController extends ControllerBase<UfModel, UfRepository> {

  UfController({required super.repository}) {
    dbColumns = UfModel.dbColumns;
    aliasColumns = UfModel.aliasColumns;
    gridColumns = ufGridColumns();
    functionName = "uf";
    screenTitle = "UF";
  }

  @override
  UfModel createNewModel() => UfModel();

  @override
  final standardFieldForFilter = UfModel.aliasColumns[UfModel.dbColumns.indexOf('nome')];

  final nomeController = TextEditingController();
  final siglaController = TextEditingController();
  final codigoIbgeController = MoneyMaskedTextController(precision: 0, decimalSeparator: '', thousandSeparator: '');

  final Map<String, dynamic> mobileConfig = {
    'primaryColumns': ['nome'],
    'secondaryColumns': ['sigla'],
  };

  List<Map<String, dynamic>> get mobileItems {
    return modelList.map((uf) => uf.toJson).toList();
  }

  @override
  void prepareForInsert() {
    isNewRecord = true;
    currentModel = createNewModel();
    _resetForm();
    Get.toNamed(Routes.ufEditPage);
  }

  void _resetForm() {
    formWasChanged = false;
    nomeController.text = '';
    siglaController.text = '';
    codigoIbgeController.updateValue(0);
  }

  @override
  void selectRowForEditingById(int id) {
    final model = modelList.firstWhere((m) => m.id == id);
    currentModel = model.clone();
    updateControllersFromModel();
    Get.toNamed(Routes.ufEditPage);
  }

  void updateControllersFromModel() {
    nomeController.text = currentModel.nome ?? '';
    siglaController.text = currentModel.sigla ?? '';
    codigoIbgeController.updateValue((currentModel.codigoIbge ?? 0).toDouble());
    formWasChanged = false;
  }

  @override
  Future<void> save() async {
    if (!formKey.currentState!.validate()) {
      showErrorSnackBar(message: 'validator_form_message'.tr);
      return;
    }

    final existingIndex = modelList.indexWhere((m) => m.id == currentModel.id);

    if (existingIndex >= 0) {
      modelList[existingIndex] = currentModel.clone();
    }

    final result = await repository.save(ufModel: currentModel);
    if (result == null) return;

    if (existingIndex >= 0) {
      modelList[existingIndex] = result;
    } else {
      modelList.insert(0, result);
    }

    if (!GetPlatform.isMobile) {
      updateGridRow(result);
    }

    Get.back(result: true);
  }


  @override
  void onClose() {
    nomeController.dispose();
    siglaController.dispose();
    codigoIbgeController.dispose();
    super.onClose();
  }

}