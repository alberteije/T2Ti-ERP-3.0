import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:pluto_grid/pluto_grid.dart';

import 'package:cadastros/app/page/page_imports.dart';
import 'package:cadastros/app/page/shared_widget/message_dialog.dart';
import 'package:cadastros/app/page/grid_columns/grid_columns_imports.dart';
import 'package:cadastros/app/controller/controller_imports.dart';
import 'package:cadastros/app/data/model/model_imports.dart';

class PessoaContatoController extends ControllerBase<PessoaContatoModel, void> {

  PessoaContatoController() : super(repository: null) {
    dbColumns = PessoaContatoModel.dbColumns;
    aliasColumns = PessoaContatoModel.aliasColumns;
    gridColumns = pessoaContatoGridColumns();
    functionName = "pessoa_contato";
    screenTitle = "Contatos";
  }

  final _pessoaContatoModel = PessoaContatoModel().obs;
  PessoaContatoModel get pessoaContatoModel => _pessoaContatoModel.value;
  set pessoaContatoModel(value) => _pessoaContatoModel.value = value ?? PessoaContatoModel();

  List<PessoaContatoModel> get pessoaContatoModelList => Get.find<PessoaController>().currentModel.pessoaContatoModelList ?? [];

  final _userMadeChanges = false.obs;
  get userMadeChanges => _userMadeChanges.value;
  set userMadeChanges(value) => _userMadeChanges.value = value;

  final _formWasChangedDetail = false.obs;
  bool get formWasChangedDetail => _formWasChangedDetail.value;
  set formWasChangedDetail(value) => _formWasChangedDetail.value = value;

  late PlutoGridStateManager _plutoGridStateManager;
  @override
  PlutoGridStateManager get plutoGridStateManager => _plutoGridStateManager;
  @override
  set plutoGridStateManager(value) => _plutoGridStateManager = value;

  final pessoaContatoScaffoldKey = GlobalKey<ScaffoldState>();
  final pessoaContatoFormKey = GlobalKey<FormState>();

  @override
  PessoaContatoModel createNewModel() => PessoaContatoModel();

  @override
  final standardFieldForFilter = PessoaContatoModel.aliasColumns[PessoaContatoModel.dbColumns.indexOf('nome')];

  final nomeController = TextEditingController();
  final emailController = TextEditingController();
  final observacaoController = TextEditingController();

  final Map<String, dynamic> mobileConfig = {
    'primaryColumns': ['nome'],
    'secondaryColumns': ['email'],
  };

  List<Map<String, dynamic>> get mobileItems {
    return modelList.map((pessoaContato) => pessoaContato.toJson).toList();
  }

  @override
  List<PlutoRow> plutoRows() => List<PlutoRow>.from(pessoaContatoModelList.map((model) => model.toPlutoRow()));

  @override
  Future<void> getList({Filter? filter}) async {}

  @override
  void prepareForInsert() {
    isNewRecord = true;
    pessoaContatoModel = createNewModel();
    _resetForm();
    Get.to(() => PessoaContatoEditPage());
  }

  void _resetForm() {
    formWasChangedDetail = false;
    nomeController.text = '';
    emailController.text = '';
    observacaoController.text = '';
  }

  @override
  void selectRowForEditing(PlutoRow? row) async {
    if (row == null) {
      showInfoSnackBar(message: 'message_select_one_to_edited'.tr);
      return;
    }

    selectRowForEditingByTempId(row.cells['tempId']?.value);
  }

  @override
  void selectRowForEditingById(int id) {}

  void selectRowForEditingByTempId(String tempId) {
		isNewRecord = false;
    final model = pessoaContatoModelList.firstWhere((m) => m.tempId == tempId);
    pessoaContatoModel = model.clone();
		pessoaContatoModel.tempId = model.tempId;
    updateControllersFromModel();
    Get.to(() => PessoaContatoEditPage());
  }

  void updateControllersFromModel() {
    nomeController.text = pessoaContatoModel.nome ?? '';
    emailController.text = pessoaContatoModel.email ?? '';
    observacaoController.text = pessoaContatoModel.observacao ?? '';
    formWasChangedDetail = false;
  }

  @override
  Future<void> save() async {
    if (!pessoaContatoFormKey.currentState!.validate()) {
      showErrorSnackBar(message: 'validator_form_message'.tr);
      return;
    }

    if (formWasChangedDetail) {
      if (isNewRecord) {
        pessoaContatoModelList.insert(0, pessoaContatoModel.clone());
      } else {
        final index = pessoaContatoModelList.indexWhere((m) => m.tempId == pessoaContatoModel.tempId);
        if (index >= 0) {
          pessoaContatoModelList[index] = pessoaContatoModel.clone();
        }
      }

      userMadeChanges = true;
      loadData();
      Get.back(result: true);
    } else {
      Get.back();
    }
  }


  @override
  Future deleteSelected() async {
    final currentRow = plutoGridStateManager.currentRow;
    if (currentRow == null) {
      showInfoSnackBar(message: 'message_select_one_to_delete'.tr);
      return null;
    }
    showDeleteDialog(() async {
      final id = currentRow.cells['id']?.value;
      final tempId = currentRow.cells['tempId']?.value;
      pessoaContatoModelList.removeWhere((model) => (id != 0 && model.id == id) || (id == 0 && model.tempId == tempId));
      plutoGridStateManager.removeCurrentRow();
      userMadeChanges = true;
    });
  }

  @override
  void preventDataLoss() {
    if (formWasChangedDetail) {
      showQuestionDialog('message_data_loss'.tr, () => Get.back());
    } else {
      formWasChangedDetail = false;
      Get.back();
    }
  }

  @override
  void onClose() {
    nomeController.dispose();
    emailController.dispose();
    observacaoController.dispose();
  }

}