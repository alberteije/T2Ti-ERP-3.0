import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:cadastros/app/controller/controller_imports.dart';
import 'package:cadastros/app/data/model/model_imports.dart';

class ContadorController extends ControllerBase<ContadorModel, void> {

  ContadorController() : super(repository: null) {
    dbColumns = ContadorModel.dbColumns;
    aliasColumns = ContadorModel.aliasColumns;
    functionName = "contador";
    screenTitle = "Contador";
  }

	String? mandatoryMessage;

  final _contadorModel = ContadorModel().obs;
  ContadorModel get contadorModel => Get.find<PessoaController>().currentModel.contadorModel ?? ContadorModel();
  set contadorModel(value) => _contadorModel.value = value ?? ContadorModel();

  final _formWasChangedDetail = false.obs;
  bool get formWasChangedDetail => _formWasChangedDetail.value;
  set formWasChangedDetail(value) => _formWasChangedDetail.value = value;

  final contadorScaffoldKey = GlobalKey<ScaffoldState>();
  final contadorFormKey = GlobalKey<FormState>();

  @override
  ContadorModel createNewModel() => ContadorModel();

  @override
  final standardFieldForFilter = "";

  final crcInscricaoController = TextEditingController();

  final Map<String, dynamic> mobileConfig = {};

  List<Map<String, dynamic>> get mobileItems {
    return modelList.map((contador) => contador.toJson).toList();
  }

  @override
  Future<void> getList({Filter? filter}) async {}

  @override
  Future<void> loadData() async {}

  @override
  void prepareForInsert() {}

  @override
  void selectRowForEditingById(int id) {}

  void _resetForm() {
    formWasChangedDetail = false;
    crcInscricaoController.text = '';
  }

  void updateControllersFromModel() {
		_resetForm();
    crcInscricaoController.text = contadorModel.crcInscricao ?? '';
  }

  @override
  Future<void> save() async {}

	bool validateForm() {
    return true;
	}


  @override
  void onClose() {
    crcInscricaoController.dispose();
  }

}