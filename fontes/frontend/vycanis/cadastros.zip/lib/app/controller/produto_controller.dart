import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:extended_masked_text/extended_masked_text.dart';

import 'package:cadastros/app/page/shared_widget/message_dialog.dart';
import 'package:cadastros/app/page/grid_columns/grid_columns_imports.dart';
import 'package:cadastros/app/routes/app_routes.dart';
import 'package:cadastros/app/controller/controller_imports.dart';
import 'package:cadastros/app/data/model/model_imports.dart';
import 'package:cadastros/app/data/repository/produto_repository.dart';

class ProdutoController extends ControllerBase<ProdutoModel, ProdutoRepository> {

  ProdutoController({required super.repository}) {
    dbColumns = ProdutoModel.dbColumns;
    aliasColumns = ProdutoModel.aliasColumns;
    gridColumns = produtoGridColumns();
    functionName = "produto";
    screenTitle = "Produto";
  }

  @override
  ProdutoModel createNewModel() => ProdutoModel();

  @override
  final standardFieldForFilter = ProdutoModel.aliasColumns[ProdutoModel.dbColumns.indexOf('nome')];

  final produtoSubgrupoModelController = TextEditingController();
  final produtoMarcaModelController = TextEditingController();
  final produtoUnidadeModelController = TextEditingController();
  final tributIcmsCustomCabModelController = TextEditingController();
  final tributGrupoTributarioModelController = TextEditingController();
  final nomeController = TextEditingController();
  final descricaoController = TextEditingController();
  final gtinController = TextEditingController();
  final codigoInternoController = TextEditingController();
  final valorCompraController = MoneyMaskedTextController();
  final valorVendaController = MoneyMaskedTextController();
  final codigoNcmController = TextEditingController();
  final estoqueMinimoController = MoneyMaskedTextController();
  final estoqueMaximoController = MoneyMaskedTextController();
  final quantidadeEstoqueController = MoneyMaskedTextController();

  final Map<String, dynamic> mobileConfig = {
    'primaryColumns': ['nome'],
    'secondaryColumns': ['descricao'],
  };

  List<Map<String, dynamic>> get mobileItems {
    return modelList.map((produto) => produto.toJson).toList();
  }

  @override
  void prepareForInsert() {
    isNewRecord = true;
    currentModel = createNewModel();
    _resetForm();
    Get.toNamed(Routes.produtoEditPage);
  }

  void _resetForm() {
    formWasChanged = false;
    produtoSubgrupoModelController.text = '';
    produtoMarcaModelController.text = '';
    produtoUnidadeModelController.text = '';
    tributIcmsCustomCabModelController.text = '';
    tributGrupoTributarioModelController.text = '';
    nomeController.text = '';
    descricaoController.text = '';
    gtinController.text = '';
    codigoInternoController.text = '';
    valorCompraController.updateValue(0);
    valorVendaController.updateValue(0);
    codigoNcmController.text = '';
    estoqueMinimoController.updateValue(0);
    estoqueMaximoController.updateValue(0);
    quantidadeEstoqueController.updateValue(0);
  }

  @override
  void selectRowForEditingById(int id) {
    final model = modelList.firstWhere((m) => m.id == id);
    currentModel = model.clone();
    updateControllersFromModel();
    Get.toNamed(Routes.produtoEditPage);
  }

  void updateControllersFromModel() {
    produtoSubgrupoModelController.text = currentModel.produtoSubgrupoModel?.nome?.toString() ?? '';
    produtoMarcaModelController.text = currentModel.produtoMarcaModel?.nome?.toString() ?? '';
    produtoUnidadeModelController.text = currentModel.produtoUnidadeModel?.sigla?.toString() ?? '';
    tributIcmsCustomCabModelController.text = currentModel.tributIcmsCustomCabModel?.descricao?.toString() ?? '';
    tributGrupoTributarioModelController.text = currentModel.tributGrupoTributarioModel?.descricao?.toString() ?? '';
    nomeController.text = currentModel.nome ?? '';
    descricaoController.text = currentModel.descricao ?? '';
    gtinController.text = currentModel.gtin ?? '';
    codigoInternoController.text = currentModel.codigoInterno ?? '';
    valorCompraController.updateValue(currentModel.valorCompra ?? 0);
    valorVendaController.updateValue(currentModel.valorVenda ?? 0);
    codigoNcmController.text = currentModel.codigoNcm ?? '';
    estoqueMinimoController.updateValue(currentModel.estoqueMinimo ?? 0);
    estoqueMaximoController.updateValue(currentModel.estoqueMaximo ?? 0);
    quantidadeEstoqueController.updateValue(currentModel.quantidadeEstoque ?? 0);
    formWasChanged = false;
  }

  @override
  Future<void> save() async {
    if (!formKey.currentState!.validate()) {
      showErrorSnackBar(message: 'validator_form_message'.tr);
      return;
    }

    final existingIndex = modelList.indexWhere((m) => m.id == currentModel.id);

    if (existingIndex >= 0) {
      modelList[existingIndex] = currentModel.clone();
    }

    final result = await repository.save(produtoModel: currentModel);
    if (result == null) return;

    if (existingIndex >= 0) {
      modelList[existingIndex] = result;
    } else {
      modelList.insert(0, result);
    }

    if (!GetPlatform.isMobile) {
      updateGridRow(result);
    }

    Get.back(result: true);
  }

  Future callProdutoSubgrupoLookup() async { 
		final lookupController = Get.find<LookupController>(); 
		lookupController.refreshItems(standardValue: '%'); 
		lookupController.title = '${'lookup_page_title'.tr} [Subgrupo]'; 
		lookupController.route = '/produto-subgrupo/'; 
		lookupController.gridColumns = produtoSubgrupoGridColumns(isForLookup: true); 
		lookupController.aliasColumns = ProdutoSubgrupoModel.aliasColumns; 
		lookupController.dbColumns = ProdutoSubgrupoModel.dbColumns; 
		lookupController.standardColumn = ProdutoSubgrupoModel.aliasColumns[ProdutoSubgrupoModel.dbColumns.indexOf('nome')]; 

		final plutoRowResult = await Get.toNamed(Routes.lookupPage); 
		if (plutoRowResult != null) { 
			currentModel.idProdutoSubgrupo = plutoRowResult.cells['id']!.value; 
			currentModel.produtoSubgrupoModel = ProdutoSubgrupoModel.fromPlutoRow(plutoRowResult); 
			produtoSubgrupoModelController.text = currentModel.produtoSubgrupoModel?.nome ?? ''; 
			formWasChanged = true; 
		}
	}

  Future callProdutoMarcaLookup() async { 
		final lookupController = Get.find<LookupController>(); 
		lookupController.refreshItems(standardValue: '%'); 
		lookupController.title = '${'lookup_page_title'.tr} [Marca]'; 
		lookupController.route = '/produto-marca/'; 
		lookupController.gridColumns = produtoMarcaGridColumns(isForLookup: true); 
		lookupController.aliasColumns = ProdutoMarcaModel.aliasColumns; 
		lookupController.dbColumns = ProdutoMarcaModel.dbColumns; 
		lookupController.standardColumn = ProdutoMarcaModel.aliasColumns[ProdutoMarcaModel.dbColumns.indexOf('nome')]; 

		final plutoRowResult = await Get.toNamed(Routes.lookupPage); 
		if (plutoRowResult != null) { 
			currentModel.idProdutoMarca = plutoRowResult.cells['id']!.value; 
			currentModel.produtoMarcaModel = ProdutoMarcaModel.fromPlutoRow(plutoRowResult); 
			produtoMarcaModelController.text = currentModel.produtoMarcaModel?.nome ?? ''; 
			formWasChanged = true; 
		}
	}

  Future callProdutoUnidadeLookup() async { 
		final lookupController = Get.find<LookupController>(); 
		lookupController.refreshItems(standardValue: '%'); 
		lookupController.title = '${'lookup_page_title'.tr} [Unidade]'; 
		lookupController.route = '/produto-unidade/'; 
		lookupController.gridColumns = produtoUnidadeGridColumns(isForLookup: true); 
		lookupController.aliasColumns = ProdutoUnidadeModel.aliasColumns; 
		lookupController.dbColumns = ProdutoUnidadeModel.dbColumns; 
		lookupController.standardColumn = ProdutoUnidadeModel.aliasColumns[ProdutoUnidadeModel.dbColumns.indexOf('sigla')]; 

		final plutoRowResult = await Get.toNamed(Routes.lookupPage); 
		if (plutoRowResult != null) { 
			currentModel.idProdutoUnidade = plutoRowResult.cells['id']!.value; 
			currentModel.produtoUnidadeModel = ProdutoUnidadeModel.fromPlutoRow(plutoRowResult); 
			produtoUnidadeModelController.text = currentModel.produtoUnidadeModel?.sigla ?? ''; 
			formWasChanged = true; 
		}
	}

  Future callTributIcmsCustomCabLookup() async { 
		final lookupController = Get.find<LookupController>(); 
		lookupController.refreshItems(standardValue: '%'); 
		lookupController.title = '${'lookup_page_title'.tr} [Tributação Customizada]'; 
		lookupController.route = '/tribut-icms-custom-cab/'; 
		lookupController.gridColumns = tributIcmsCustomCabGridColumns(isForLookup: true); 
		lookupController.aliasColumns = TributIcmsCustomCabModel.aliasColumns; 
		lookupController.dbColumns = TributIcmsCustomCabModel.dbColumns; 
		lookupController.standardColumn = TributIcmsCustomCabModel.aliasColumns[TributIcmsCustomCabModel.dbColumns.indexOf('descricao')]; 

		final plutoRowResult = await Get.toNamed(Routes.lookupPage); 
		if (plutoRowResult != null) { 
			currentModel.idTributIcmsCustomCab = plutoRowResult.cells['id']!.value; 
			currentModel.tributIcmsCustomCabModel = TributIcmsCustomCabModel.fromPlutoRow(plutoRowResult); 
			tributIcmsCustomCabModelController.text = currentModel.tributIcmsCustomCabModel?.descricao ?? ''; 
			formWasChanged = true; 
		}
	}

  Future callTributGrupoTributarioLookup() async { 
		final lookupController = Get.find<LookupController>(); 
		lookupController.refreshItems(standardValue: '%'); 
		lookupController.title = '${'lookup_page_title'.tr} [Grupo Tributário]'; 
		lookupController.route = '/tribut-grupo-tributario/'; 
		lookupController.gridColumns = tributGrupoTributarioGridColumns(isForLookup: true); 
		lookupController.aliasColumns = TributGrupoTributarioModel.aliasColumns; 
		lookupController.dbColumns = TributGrupoTributarioModel.dbColumns; 
		lookupController.standardColumn = TributGrupoTributarioModel.aliasColumns[TributGrupoTributarioModel.dbColumns.indexOf('descricao')]; 

		final plutoRowResult = await Get.toNamed(Routes.lookupPage); 
		if (plutoRowResult != null) { 
			currentModel.idTributGrupoTributario = plutoRowResult.cells['id']!.value; 
			currentModel.tributGrupoTributarioModel = TributGrupoTributarioModel.fromPlutoRow(plutoRowResult); 
			tributGrupoTributarioModelController.text = currentModel.tributGrupoTributarioModel?.descricao ?? ''; 
			formWasChanged = true; 
		}
	}


  @override
  void onClose() {
    produtoSubgrupoModelController.dispose();
    produtoMarcaModelController.dispose();
    produtoUnidadeModelController.dispose();
    tributIcmsCustomCabModelController.dispose();
    tributGrupoTributarioModelController.dispose();
    nomeController.dispose();
    descricaoController.dispose();
    gtinController.dispose();
    codigoInternoController.dispose();
    valorCompraController.dispose();
    valorVendaController.dispose();
    codigoNcmController.dispose();
    estoqueMinimoController.dispose();
    estoqueMaximoController.dispose();
    quantidadeEstoqueController.dispose();
    super.onClose();
  }

}