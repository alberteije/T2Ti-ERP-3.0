import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:pluto_grid/pluto_grid.dart';
import 'package:extended_masked_text/extended_masked_text.dart';

import 'package:cadastros/app/page/page_imports.dart';
import 'package:cadastros/app/page/shared_widget/message_dialog.dart';
import 'package:cadastros/app/page/grid_columns/grid_columns_imports.dart';
import 'package:cadastros/app/controller/controller_imports.dart';
import 'package:cadastros/app/data/model/model_imports.dart';

class PessoaEnderecoController extends ControllerBase<PessoaEnderecoModel, void> {

  PessoaEnderecoController() : super(repository: null) {
    dbColumns = PessoaEnderecoModel.dbColumns;
    aliasColumns = PessoaEnderecoModel.aliasColumns;
    gridColumns = pessoaEnderecoGridColumns();
    functionName = "pessoa_endereco";
    screenTitle = "Endereços";
  }

  final _pessoaEnderecoModel = PessoaEnderecoModel().obs;
  PessoaEnderecoModel get pessoaEnderecoModel => _pessoaEnderecoModel.value;
  set pessoaEnderecoModel(value) => _pessoaEnderecoModel.value = value ?? PessoaEnderecoModel();

  List<PessoaEnderecoModel> get pessoaEnderecoModelList => Get.find<PessoaController>().currentModel.pessoaEnderecoModelList ?? [];

  final _userMadeChanges = false.obs;
  get userMadeChanges => _userMadeChanges.value;
  set userMadeChanges(value) => _userMadeChanges.value = value;

  final _formWasChangedDetail = false.obs;
  bool get formWasChangedDetail => _formWasChangedDetail.value;
  set formWasChangedDetail(value) => _formWasChangedDetail.value = value;

  late PlutoGridStateManager _plutoGridStateManager;
  @override
  PlutoGridStateManager get plutoGridStateManager => _plutoGridStateManager;
  @override
  set plutoGridStateManager(value) => _plutoGridStateManager = value;

  final pessoaEnderecoScaffoldKey = GlobalKey<ScaffoldState>();
  final pessoaEnderecoFormKey = GlobalKey<FormState>();

  @override
  PessoaEnderecoModel createNewModel() => PessoaEnderecoModel();

  @override
  final standardFieldForFilter = PessoaEnderecoModel.aliasColumns[PessoaEnderecoModel.dbColumns.indexOf('logradouro')];

  final logradouroController = TextEditingController();
  final numeroController = TextEditingController();
  final complementoController = TextEditingController();
  final bairroController = TextEditingController();
  final cidadeController = TextEditingController();
  final cepController = MaskedTextController(mask: '00000-000',);
  final municipioIbgeController = MoneyMaskedTextController(precision: 0, decimalSeparator: '', thousandSeparator: '');

  final Map<String, dynamic> mobileConfig = {
    'primaryColumns': ['logradouro'],
    'secondaryColumns': ['numero'],
  };

  List<Map<String, dynamic>> get mobileItems {
    return modelList.map((pessoaEndereco) => pessoaEndereco.toJson).toList();
  }

  @override
  List<PlutoRow> plutoRows() => List<PlutoRow>.from(pessoaEnderecoModelList.map((model) => model.toPlutoRow()));

  @override
  Future<void> getList({Filter? filter}) async {}

  @override
  void prepareForInsert() {
    isNewRecord = true;
    pessoaEnderecoModel = createNewModel();
    _resetForm();
    Get.to(() => PessoaEnderecoEditPage());
  }

  void _resetForm() {
    formWasChangedDetail = false;
    logradouroController.text = '';
    numeroController.text = '';
    complementoController.text = '';
    bairroController.text = '';
    cidadeController.text = '';
    cepController.text = '';
    municipioIbgeController.updateValue(0);
  }

  @override
  void selectRowForEditing(PlutoRow? row) async {
    if (row == null) {
      showInfoSnackBar(message: 'message_select_one_to_edited'.tr);
      return;
    }

    selectRowForEditingByTempId(row.cells['tempId']?.value);
  }

  @override
  void selectRowForEditingById(int id) {}

  void selectRowForEditingByTempId(String tempId) {
		isNewRecord = false;
    final model = pessoaEnderecoModelList.firstWhere((m) => m.tempId == tempId);
    pessoaEnderecoModel = model.clone();
		pessoaEnderecoModel.tempId = model.tempId;
    updateControllersFromModel();
    Get.to(() => PessoaEnderecoEditPage());
  }

  void updateControllersFromModel() {
    logradouroController.text = pessoaEnderecoModel.logradouro ?? '';
    numeroController.text = pessoaEnderecoModel.numero ?? '';
    complementoController.text = pessoaEnderecoModel.complemento ?? '';
    bairroController.text = pessoaEnderecoModel.bairro ?? '';
    cidadeController.text = pessoaEnderecoModel.cidade ?? '';
    cepController.text = pessoaEnderecoModel.cep ?? '';
    municipioIbgeController.updateValue((pessoaEnderecoModel.municipioIbge ?? 0).toDouble());
    formWasChangedDetail = false;
  }

  @override
  Future<void> save() async {
    if (!pessoaEnderecoFormKey.currentState!.validate()) {
      showErrorSnackBar(message: 'validator_form_message'.tr);
      return;
    }

    if (formWasChangedDetail) {
      if (isNewRecord) {
        pessoaEnderecoModelList.insert(0, pessoaEnderecoModel.clone());
      } else {
        final index = pessoaEnderecoModelList.indexWhere((m) => m.tempId == pessoaEnderecoModel.tempId);
        if (index >= 0) {
          pessoaEnderecoModelList[index] = pessoaEnderecoModel.clone();
        }
      }

      userMadeChanges = true;
      loadData();
      Get.back(result: true);
    } else {
      Get.back();
    }
  }


  @override
  Future deleteSelected() async {
    final currentRow = plutoGridStateManager.currentRow;
    if (currentRow == null) {
      showInfoSnackBar(message: 'message_select_one_to_delete'.tr);
      return null;
    }
    showDeleteDialog(() async {
      final id = currentRow.cells['id']?.value;
      final tempId = currentRow.cells['tempId']?.value;
      pessoaEnderecoModelList.removeWhere((model) => (id != 0 && model.id == id) || (id == 0 && model.tempId == tempId));
      plutoGridStateManager.removeCurrentRow();
      userMadeChanges = true;
    });
  }

  @override
  void preventDataLoss() {
    if (formWasChangedDetail) {
      showQuestionDialog('message_data_loss'.tr, () => Get.back());
    } else {
      formWasChangedDetail = false;
      Get.back();
    }
  }

  @override
  void onClose() {
    logradouroController.dispose();
    numeroController.dispose();
    complementoController.dispose();
    bairroController.dispose();
    cidadeController.dispose();
    cepController.dispose();
    municipioIbgeController.dispose();
  }

}