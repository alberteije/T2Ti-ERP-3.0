import 'package:flutter/material.dart';
import 'package:get/get.dart';

import 'package:cadastros/app/page/shared_widget/message_dialog.dart';
import 'package:cadastros/app/page/grid_columns/grid_columns_imports.dart';
import 'package:cadastros/app/routes/app_routes.dart';
import 'package:cadastros/app/controller/controller_imports.dart';
import 'package:cadastros/app/data/model/model_imports.dart';
import 'package:cadastros/app/data/repository/cnae_repository.dart';

class CnaeController extends ControllerBase<CnaeModel, CnaeRepository> {

  CnaeController({required super.repository}) {
    dbColumns = CnaeModel.dbColumns;
    aliasColumns = CnaeModel.aliasColumns;
    gridColumns = cnaeGridColumns();
    functionName = "cnae";
    screenTitle = "CNAE";
  }

  @override
  CnaeModel createNewModel() => CnaeModel();

  @override
  final standardFieldForFilter = CnaeModel.aliasColumns[CnaeModel.dbColumns.indexOf('codigo')];

  final codigoController = TextEditingController();
  final denominacaoController = TextEditingController();

  final Map<String, dynamic> mobileConfig = {
    'primaryColumns': ['codigo'],
    'secondaryColumns': ['denominacao'],
  };

  List<Map<String, dynamic>> get mobileItems {
    return modelList.map((cnae) => cnae.toJson).toList();
  }

  @override
  void prepareForInsert() {
    isNewRecord = true;
    currentModel = createNewModel();
    _resetForm();
    Get.toNamed(Routes.cnaeEditPage);
  }

  void _resetForm() {
    formWasChanged = false;
    codigoController.text = '';
    denominacaoController.text = '';
  }

  @override
  void selectRowForEditingById(int id) {
    final model = modelList.firstWhere((m) => m.id == id);
    currentModel = model.clone();
    updateControllersFromModel();
    Get.toNamed(Routes.cnaeEditPage);
  }

  void updateControllersFromModel() {
    codigoController.text = currentModel.codigo ?? '';
    denominacaoController.text = currentModel.denominacao ?? '';
    formWasChanged = false;
  }

  @override
  Future<void> save() async {
    if (!formKey.currentState!.validate()) {
      showErrorSnackBar(message: 'validator_form_message'.tr);
      return;
    }

    final existingIndex = modelList.indexWhere((m) => m.id == currentModel.id);

    if (existingIndex >= 0) {
      modelList[existingIndex] = currentModel.clone();
    }

    final result = await repository.save(cnaeModel: currentModel);
    if (result == null) return;

    if (existingIndex >= 0) {
      modelList[existingIndex] = result;
    } else {
      modelList.insert(0, result);
    }

    if (!GetPlatform.isMobile) {
      updateGridRow(result);
    }

    Get.back(result: true);
  }


  @override
  void onClose() {
    codigoController.dispose();
    denominacaoController.dispose();
    super.onClose();
  }

}