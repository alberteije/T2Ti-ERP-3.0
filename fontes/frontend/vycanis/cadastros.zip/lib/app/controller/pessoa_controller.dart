import 'package:flutter/material.dart';
import 'dart:math';
import 'package:get/get.dart';

import 'package:cadastros/app/infra/infra_imports.dart';
import 'package:cadastros/app/page/page_imports.dart';
import 'package:cadastros/app/page/shared_widget/message_dialog.dart';
import 'package:cadastros/app/page/grid_columns/grid_columns_imports.dart';
import 'package:cadastros/app/routes/app_routes.dart';
import 'package:cadastros/app/controller/controller_imports.dart';
import 'package:cadastros/app/data/model/model_imports.dart';
import 'package:cadastros/app/data/repository/pessoa_repository.dart';

class PessoaController extends ControllerBase<PessoaModel, PessoaRepository> 
with GetSingleTickerProviderStateMixin {

  PessoaController({required super.repository}) {
    dbColumns = PessoaModel.dbColumns;
    aliasColumns = PessoaModel.aliasColumns;
    gridColumns = pessoaGridColumns();
    functionName = "pessoa";
    screenTitle = "Pessoa";
  }

  final pessoaScaffoldKey = GlobalKey<ScaffoldState>();
  final pessoaTabPageScaffoldKey = GlobalKey<ScaffoldState>();
  final pessoaFormKey = GlobalKey<FormState>();
  late TabController tabController;
  String? mandatoryMessage;  

  @override
  PessoaModel createNewModel() => PessoaModel();

  @override
  final standardFieldForFilter = PessoaModel.aliasColumns[PessoaModel.dbColumns.indexOf('nome')];

  final nomeController = TextEditingController();
  final siteController = TextEditingController();
  final emailController = TextEditingController();

  final Map<String, dynamic> mobileConfig = {
    'primaryColumns': ['nome'],
    'secondaryColumns': ['tipo'],
  };

  List<Map<String, dynamic>> get mobileItems {
    return modelList.map((pessoa) => pessoa.toJson).toList();
  }

  @override
  void prepareForInsert() {
    isNewRecord = true;
    currentModel = createNewModel();
    _resetForm();
    tabController.animateTo(0);
    _configureChildrenControllers();
    Get.toNamed(Routes.pessoaTabPage);
  }

  void _resetForm() {
    formWasChanged = false;
    nomeController.text = '';
    siteController.text = '';
    emailController.text = '';
  }

  @override
  void selectRowForEditingById(int id) {
    final model = modelList.firstWhere((m) => m.id == id);
    currentModel = model.clone();
    updateControllersFromModel();

    tabController.animateTo(0);
    _configureChildrenControllers();
    Get.toNamed(Routes.pessoaTabPage);
  }

  _configureChildrenControllers() {
    //Pessoa Jurídica
		Get.put<PessoaJuridicaController>(PessoaJuridicaController()); 
		final pessoaJuridicaController = Get.find<PessoaJuridicaController>(); 
		pessoaJuridicaController.updateControllersFromModel(); 

    //Fornecedor
		Get.put<FornecedorController>(FornecedorController()); 
		final fornecedorController = Get.find<FornecedorController>(); 
		fornecedorController.updateControllersFromModel(); 

    //Cliente
		Get.put<ClienteController>(ClienteController()); 
		final clienteController = Get.find<ClienteController>(); 
		clienteController.updateControllersFromModel(); 

    //Pessoa Física
		Get.put<PessoaFisicaController>(PessoaFisicaController()); 
		final pessoaFisicaController = Get.find<PessoaFisicaController>(); 
		pessoaFisicaController.updateControllersFromModel(); 

    //Transportadora
		Get.put<TransportadoraController>(TransportadoraController()); 
		final transportadoraController = Get.find<TransportadoraController>(); 
		transportadoraController.updateControllersFromModel(); 

    //Contador
		Get.put<ContadorController>(ContadorController()); 
		final contadorController = Get.find<ContadorController>(); 
		contadorController.updateControllersFromModel(); 

    //Contatos
		Get.put<PessoaContatoController>(PessoaContatoController()); 
		final pessoaContatoController = Get.find<PessoaContatoController>(); 
		pessoaContatoController.userMadeChanges = false; 

    //Telefones
		Get.put<PessoaTelefoneController>(PessoaTelefoneController()); 
		final pessoaTelefoneController = Get.find<PessoaTelefoneController>(); 
		pessoaTelefoneController.userMadeChanges = false; 

    //Endereços
		Get.put<PessoaEnderecoController>(PessoaEnderecoController()); 
		final pessoaEnderecoController = Get.find<PessoaEnderecoController>(); 
		pessoaEnderecoController.userMadeChanges = false; 

  }
  
  void updateControllersFromModel() {
    nomeController.text = currentModel.nome ?? '';
    siteController.text = currentModel.site ?? '';
    emailController.text = currentModel.email ?? '';
    formWasChanged = false;
  }

  @override
  Future<void> save() async {
    if (!validateCurrentForm()) return;
    if (validateForms()) {
      if (userMadeChanges()) {
        final existingIndex = modelList.indexWhere((m) => m.id == currentModel.id);

        if (existingIndex >= 0) {
          modelList[existingIndex] = currentModel.clone();
        }

        final result = await repository.save(pessoaModel: currentModel);
        if (result == null) return;

        if (existingIndex >= 0) {
          modelList[existingIndex] = result;
        } else {
          modelList.insert(0, result);
        }

        if (!GetPlatform.isMobile) {
          updateGridRow(result);
        }

        Get.back(result: true);
      } else {
        Get.back();
      }
    } 
  }


  List<Tab> tabItems = [
    Tab( 
			icon: Icon(iconDataList[Random().nextInt(10)]), 
			text: 'Pessoa', 
		),
    Tab( 
			icon: Icon(iconDataList[Random().nextInt(10)]), 
			text: 'Pessoa Jurídica', 
		),
    Tab( 
			icon: Icon(iconDataList[Random().nextInt(10)]), 
			text: 'Fornecedor', 
		),
    Tab( 
			icon: Icon(iconDataList[Random().nextInt(10)]), 
			text: 'Cliente', 
		),
    Tab( 
			icon: Icon(iconDataList[Random().nextInt(10)]), 
			text: 'Pessoa Física', 
		),
    Tab( 
			icon: Icon(iconDataList[Random().nextInt(10)]), 
			text: 'Transportadora', 
		),
    Tab( 
			icon: Icon(iconDataList[Random().nextInt(10)]), 
			text: 'Contador', 
		),
    Tab( 
			icon: Icon(iconDataList[Random().nextInt(10)]), 
			text: 'Contatos', 
		),
    Tab( 
			icon: Icon(iconDataList[Random().nextInt(10)]), 
			text: 'Telefones', 
		),
    Tab( 
			icon: Icon(iconDataList[Random().nextInt(10)]), 
			text: 'Endereços', 
		),
  ];

  List<Widget> tabPages() {
    return [
      PessoaEditPage(),
      PessoaJuridicaEditPage(),
      FornecedorEditPage(),
      ClienteEditPage(),
      PessoaFisicaEditPage(),
      TransportadoraEditPage(),
      ContadorEditPage(),
      const PessoaContatoListPage(),
      const PessoaTelefoneListPage(),
      const PessoaEnderecoListPage(),
    ];
  }

  @override
  void preventDataLoss() {
    if (userMadeChanges()) {
      showQuestionDialog('message_data_loss'.tr, () { 
        Get.back(); 
      });
    } else {
      Get.back();
    }
  }  

  bool userMadeChanges() {
    return
    formWasChanged 
    || 
		Get.find<PessoaJuridicaController>().formWasChangedDetail
    || 
		Get.find<FornecedorController>().formWasChangedDetail
    || 
		Get.find<ClienteController>().formWasChangedDetail
    || 
		Get.find<PessoaFisicaController>().formWasChangedDetail
    || 
		Get.find<TransportadoraController>().formWasChangedDetail
    || 
		Get.find<ContadorController>().formWasChangedDetail
    || 
		Get.find<PessoaContatoController>().userMadeChanges
    || 
		Get.find<PessoaTelefoneController>().userMadeChanges
    || 
		Get.find<PessoaEnderecoController>().userMadeChanges
    ;
  }

  void tabChange(int index) {
    validateCurrentForm();
  }

  bool validateCurrentForm() {
    final emailValidationMessage = ValidateFormField.validateEmail(currentModel.email); 
		if (emailValidationMessage != null) { 
			tabController.animateTo(0); 
			showErrorSnackBar(message: emailValidationMessage); 
			return false; 
		}
    return true;
  }

  bool validateForms() {
    final resultPessoaJuridica = Get.find<PessoaJuridicaController>().validateForm(); 
		if (!resultPessoaJuridica) { 
			tabController.animateTo(1); 
			return false; 
		}
    final resultFornecedor = Get.find<FornecedorController>().validateForm(); 
		if (!resultFornecedor) { 
			tabController.animateTo(2); 
			return false; 
		}
    final resultCliente = Get.find<ClienteController>().validateForm(); 
		if (!resultCliente) { 
			tabController.animateTo(3); 
			return false; 
		}
    final resultPessoaFisica = Get.find<PessoaFisicaController>().validateForm(); 
		if (!resultPessoaFisica) { 
			tabController.animateTo(4); 
			return false; 
		}
    final resultTransportadora = Get.find<TransportadoraController>().validateForm(); 
		if (!resultTransportadora) { 
			tabController.animateTo(5); 
			return false; 
		}
    final resultContador = Get.find<ContadorController>().validateForm(); 
		if (!resultContador) { 
			tabController.animateTo(6); 
			return false; 
		}
    return true;
  }

  @override
  void onInit() {
    super.onInit();
    tabController = TabController(vsync: this, length: tabItems.length);
  }
	
  @override
  void onClose() {
    tabController.dispose();
    nomeController.dispose();
    siteController.dispose();
    emailController.dispose();
    super.onClose();
  }	
}