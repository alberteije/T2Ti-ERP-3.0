import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:extended_masked_text/extended_masked_text.dart';

import 'package:cadastros/app/page/shared_widget/message_dialog.dart';
import 'package:cadastros/app/page/grid_columns/grid_columns_imports.dart';
import 'package:cadastros/app/routes/app_routes.dart';
import 'package:cadastros/app/controller/controller_imports.dart';
import 'package:cadastros/app/data/model/model_imports.dart';
import 'package:cadastros/app/data/repository/municipio_repository.dart';

class MunicipioController extends ControllerBase<MunicipioModel, MunicipioRepository> {

  MunicipioController({required super.repository}) {
    dbColumns = MunicipioModel.dbColumns;
    aliasColumns = MunicipioModel.aliasColumns;
    gridColumns = municipioGridColumns();
    functionName = "municipio";
    screenTitle = "Município";
  }

  @override
  MunicipioModel createNewModel() => MunicipioModel();

  @override
  final standardFieldForFilter = MunicipioModel.aliasColumns[MunicipioModel.dbColumns.indexOf('nome')];

  final ufModelController = TextEditingController();
  final nomeController = TextEditingController();
  final codigoIbgeController = MoneyMaskedTextController(precision: 0, decimalSeparator: '', thousandSeparator: '');
  final codigoReceitaFederalController = MoneyMaskedTextController(precision: 0, decimalSeparator: '', thousandSeparator: '');
  final codigoEstadualController = MoneyMaskedTextController(precision: 0, decimalSeparator: '', thousandSeparator: '');

  final Map<String, dynamic> mobileConfig = {
    'primaryColumns': ['nome'],
    'secondaryColumns': ['codigo_ibge'],
  };

  List<Map<String, dynamic>> get mobileItems {
    return modelList.map((municipio) => municipio.toJson).toList();
  }

  @override
  void prepareForInsert() {
    isNewRecord = true;
    currentModel = createNewModel();
    _resetForm();
    Get.toNamed(Routes.municipioEditPage);
  }

  void _resetForm() {
    formWasChanged = false;
    ufModelController.text = '';
    nomeController.text = '';
    codigoIbgeController.updateValue(0);
    codigoReceitaFederalController.updateValue(0);
    codigoEstadualController.updateValue(0);
  }

  @override
  void selectRowForEditingById(int id) {
    final model = modelList.firstWhere((m) => m.id == id);
    currentModel = model.clone();
    updateControllersFromModel();
    Get.toNamed(Routes.municipioEditPage);
  }

  void updateControllersFromModel() {
    ufModelController.text = currentModel.ufModel?.sigla?.toString() ?? '';
    nomeController.text = currentModel.nome ?? '';
    codigoIbgeController.updateValue((currentModel.codigoIbge ?? 0).toDouble());
    codigoReceitaFederalController.updateValue((currentModel.codigoReceitaFederal ?? 0).toDouble());
    codigoEstadualController.updateValue((currentModel.codigoEstadual ?? 0).toDouble());
    formWasChanged = false;
  }

  @override
  Future<void> save() async {
    if (!formKey.currentState!.validate()) {
      showErrorSnackBar(message: 'validator_form_message'.tr);
      return;
    }

    final existingIndex = modelList.indexWhere((m) => m.id == currentModel.id);

    if (existingIndex >= 0) {
      modelList[existingIndex] = currentModel.clone();
    }

    final result = await repository.save(municipioModel: currentModel);
    if (result == null) return;

    if (existingIndex >= 0) {
      modelList[existingIndex] = result;
    } else {
      modelList.insert(0, result);
    }

    if (!GetPlatform.isMobile) {
      updateGridRow(result);
    }

    Get.back(result: true);
  }

  Future callUfLookup() async { 
		final lookupController = Get.find<LookupController>(); 
		lookupController.refreshItems(standardValue: '%'); 
		lookupController.title = '${'lookup_page_title'.tr} [UF]'; 
		lookupController.route = '/uf/'; 
		lookupController.gridColumns = ufGridColumns(isForLookup: true); 
		lookupController.aliasColumns = UfModel.aliasColumns; 
		lookupController.dbColumns = UfModel.dbColumns; 
		lookupController.standardColumn = UfModel.aliasColumns[UfModel.dbColumns.indexOf('sigla')]; 

		final plutoRowResult = await Get.toNamed(Routes.lookupPage); 
		if (plutoRowResult != null) { 
			currentModel.idUf = plutoRowResult.cells['id']!.value; 
			currentModel.ufModel = UfModel.fromPlutoRow(plutoRowResult); 
			ufModelController.text = currentModel.ufModel?.sigla ?? ''; 
			formWasChanged = true; 
		}
	}


  @override
  void onClose() {
    ufModelController.dispose();
    nomeController.dispose();
    codigoIbgeController.dispose();
    codigoReceitaFederalController.dispose();
    codigoEstadualController.dispose();
    super.onClose();
  }

}