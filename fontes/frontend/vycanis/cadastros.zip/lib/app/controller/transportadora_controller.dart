import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:cadastros/app/controller/controller_imports.dart';
import 'package:cadastros/app/data/model/model_imports.dart';

class TransportadoraController extends ControllerBase<TransportadoraModel, void> {

  TransportadoraController() : super(repository: null) {
    dbColumns = TransportadoraModel.dbColumns;
    aliasColumns = TransportadoraModel.aliasColumns;
    functionName = "transportadora";
    screenTitle = "Transportadora";
  }

	String? mandatoryMessage;

  final _transportadoraModel = TransportadoraModel().obs;
  TransportadoraModel get transportadoraModel => Get.find<PessoaController>().currentModel.transportadoraModel ?? TransportadoraModel();
  set transportadoraModel(value) => _transportadoraModel.value = value ?? TransportadoraModel();

  final _formWasChangedDetail = false.obs;
  bool get formWasChangedDetail => _formWasChangedDetail.value;
  set formWasChangedDetail(value) => _formWasChangedDetail.value = value;

  final transportadoraScaffoldKey = GlobalKey<ScaffoldState>();
  final transportadoraFormKey = GlobalKey<FormState>();

  @override
  TransportadoraModel createNewModel() => TransportadoraModel();

  @override
  final standardFieldForFilter = "";

  final observacaoController = TextEditingController();

  final Map<String, dynamic> mobileConfig = {};

  List<Map<String, dynamic>> get mobileItems {
    return modelList.map((transportadora) => transportadora.toJson).toList();
  }

  @override
  Future<void> getList({Filter? filter}) async {}

  @override
  Future<void> loadData() async {}

  @override
  void prepareForInsert() {}

  @override
  void selectRowForEditingById(int id) {}

  void _resetForm() {
    formWasChangedDetail = false;
    observacaoController.text = '';
  }

  void updateControllersFromModel() {
		_resetForm();
    observacaoController.text = transportadoraModel.observacao ?? '';
  }

  @override
  Future<void> save() async {}

	bool validateForm() {
    return true;
	}


  @override
  void onClose() {
    observacaoController.dispose();
  }

}