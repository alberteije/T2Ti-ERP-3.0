import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:extended_masked_text/extended_masked_text.dart';
import 'package:cadastros/app/controller/controller_imports.dart';
import 'package:cadastros/app/data/model/model_imports.dart';

class PessoaJuridicaController extends ControllerBase<PessoaJuridicaModel, void> {

  PessoaJuridicaController() : super(repository: null) {
    dbColumns = PessoaJuridicaModel.dbColumns;
    aliasColumns = PessoaJuridicaModel.aliasColumns;
    functionName = "pessoa_juridica";
    screenTitle = "Pessoa Jurídica";
  }

	String? mandatoryMessage;

  final _pessoaJuridicaModel = PessoaJuridicaModel().obs;
  PessoaJuridicaModel get pessoaJuridicaModel => Get.find<PessoaController>().currentModel.pessoaJuridicaModel ?? PessoaJuridicaModel();
  set pessoaJuridicaModel(value) => _pessoaJuridicaModel.value = value ?? PessoaJuridicaModel();

  final _formWasChangedDetail = false.obs;
  bool get formWasChangedDetail => _formWasChangedDetail.value;
  set formWasChangedDetail(value) => _formWasChangedDetail.value = value;

  final pessoaJuridicaScaffoldKey = GlobalKey<ScaffoldState>();
  final pessoaJuridicaFormKey = GlobalKey<FormState>();

  @override
  PessoaJuridicaModel createNewModel() => PessoaJuridicaModel();

  @override
  final standardFieldForFilter = "";

  final cnpjController = MaskedTextController(mask: '00.000.000/0000-00',);
  final nomeFantasiaController = TextEditingController();
  final inscricaoEstadualController = TextEditingController();
  final inscricaoMunicipalController = TextEditingController();

  final Map<String, dynamic> mobileConfig = {};

  List<Map<String, dynamic>> get mobileItems {
    return modelList.map((pessoaJuridica) => pessoaJuridica.toJson).toList();
  }

  @override
  Future<void> getList({Filter? filter}) async {}

  @override
  Future<void> loadData() async {}

  @override
  void prepareForInsert() {}

  @override
  void selectRowForEditingById(int id) {}

  void _resetForm() {
    formWasChangedDetail = false;
    cnpjController.text = '';
    nomeFantasiaController.text = '';
    inscricaoEstadualController.text = '';
    inscricaoMunicipalController.text = '';
  }

  void updateControllersFromModel() {
		_resetForm();
    cnpjController.text = pessoaJuridicaModel.cnpj ?? '';
    nomeFantasiaController.text = pessoaJuridicaModel.nomeFantasia ?? '';
    inscricaoEstadualController.text = pessoaJuridicaModel.inscricaoEstadual ?? '';
    inscricaoMunicipalController.text = pessoaJuridicaModel.inscricaoMunicipal ?? '';
  }

  @override
  Future<void> save() async {}

	bool validateForm() {
    return true;
	}


  @override
  void onClose() {
    cnpjController.dispose();
    nomeFantasiaController.dispose();
    inscricaoEstadualController.dispose();
    inscricaoMunicipalController.dispose();
  }

}