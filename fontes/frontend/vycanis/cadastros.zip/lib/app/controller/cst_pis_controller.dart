import 'package:flutter/material.dart';
import 'package:get/get.dart';

import 'package:cadastros/app/page/shared_widget/message_dialog.dart';
import 'package:cadastros/app/page/grid_columns/grid_columns_imports.dart';
import 'package:cadastros/app/routes/app_routes.dart';
import 'package:cadastros/app/controller/controller_imports.dart';
import 'package:cadastros/app/data/model/model_imports.dart';
import 'package:cadastros/app/data/repository/cst_pis_repository.dart';

class CstPisController extends ControllerBase<CstPisModel, CstPisRepository> {

  CstPisController({required super.repository}) {
    dbColumns = CstPisModel.dbColumns;
    aliasColumns = CstPisModel.aliasColumns;
    gridColumns = cstPisGridColumns();
    functionName = "cst_pis";
    screenTitle = "CST PIS";
  }

  @override
  CstPisModel createNewModel() => CstPisModel();

  @override
  final standardFieldForFilter = CstPisModel.aliasColumns[CstPisModel.dbColumns.indexOf('codigo')];

  final codigoController = TextEditingController();
  final descricaoController = TextEditingController();
  final observacaoController = TextEditingController();

  final Map<String, dynamic> mobileConfig = {
    'primaryColumns': ['codigo'],
    'secondaryColumns': ['descricao'],
  };

  List<Map<String, dynamic>> get mobileItems {
    return modelList.map((cstPis) => cstPis.toJson).toList();
  }

  @override
  void prepareForInsert() {
    isNewRecord = true;
    currentModel = createNewModel();
    _resetForm();
    Get.toNamed(Routes.cstPisEditPage);
  }

  void _resetForm() {
    formWasChanged = false;
    codigoController.text = '';
    descricaoController.text = '';
    observacaoController.text = '';
  }

  @override
  void selectRowForEditingById(int id) {
    final model = modelList.firstWhere((m) => m.id == id);
    currentModel = model.clone();
    updateControllersFromModel();
    Get.toNamed(Routes.cstPisEditPage);
  }

  void updateControllersFromModel() {
    codigoController.text = currentModel.codigo ?? '';
    descricaoController.text = currentModel.descricao ?? '';
    observacaoController.text = currentModel.observacao ?? '';
    formWasChanged = false;
  }

  @override
  Future<void> save() async {
    if (!formKey.currentState!.validate()) {
      showErrorSnackBar(message: 'validator_form_message'.tr);
      return;
    }

    final existingIndex = modelList.indexWhere((m) => m.id == currentModel.id);

    if (existingIndex >= 0) {
      modelList[existingIndex] = currentModel.clone();
    }

    final result = await repository.save(cstPisModel: currentModel);
    if (result == null) return;

    if (existingIndex >= 0) {
      modelList[existingIndex] = result;
    } else {
      modelList.insert(0, result);
    }

    if (!GetPlatform.isMobile) {
      updateGridRow(result);
    }

    Get.back(result: true);
  }


  @override
  void onClose() {
    codigoController.dispose();
    descricaoController.dispose();
    observacaoController.dispose();
    super.onClose();
  }

}