import 'package:flutter/material.dart';
import 'dart:math';
import 'package:get/get.dart';

import 'package:cadastros/app/infra/infra_imports.dart';
import 'package:cadastros/app/page/page_imports.dart';
import 'package:cadastros/app/page/shared_widget/message_dialog.dart';
import 'package:cadastros/app/page/grid_columns/grid_columns_imports.dart';
import 'package:cadastros/app/routes/app_routes.dart';
import 'package:cadastros/app/controller/controller_imports.dart';
import 'package:cadastros/app/data/model/model_imports.dart';
import 'package:cadastros/app/data/repository/colaborador_repository.dart';

class ColaboradorController extends ControllerBase<ColaboradorModel, ColaboradorRepository> 
with GetSingleTickerProviderStateMixin {

  ColaboradorController({required super.repository}) {
    dbColumns = ColaboradorModel.dbColumns;
    aliasColumns = ColaboradorModel.aliasColumns;
    gridColumns = colaboradorGridColumns();
    functionName = "colaborador";
    screenTitle = "Colaborador";
  }

  final colaboradorScaffoldKey = GlobalKey<ScaffoldState>();
  final colaboradorTabPageScaffoldKey = GlobalKey<ScaffoldState>();
  final colaboradorFormKey = GlobalKey<FormState>();
  late TabController tabController;
  String? mandatoryMessage;  

  @override
  ColaboradorModel createNewModel() => ColaboradorModel();

  @override
  final standardFieldForFilter = ColaboradorModel.aliasColumns[ColaboradorModel.dbColumns.indexOf('matricula')];

  final pessoaModelController = TextEditingController();
  final cargoModelController = TextEditingController();
  final setorModelController = TextEditingController();
  final colaboradorSituacaoModelController = TextEditingController();
  final tipoAdmissaoModelController = TextEditingController();
  final colaboradorTipoModelController = TextEditingController();
  final sindicatoModelController = TextEditingController();
  final matriculaController = TextEditingController();
  final ctpsNumeroController = TextEditingController();
  final ctpsSerieController = TextEditingController();
  final observacaoController = TextEditingController();

  final Map<String, dynamic> mobileConfig = {
    'primaryColumns': ['matricula'],
    'secondaryColumns': ['data_cadastro'],
  };

  List<Map<String, dynamic>> get mobileItems {
    return modelList.map((colaborador) => colaborador.toJson).toList();
  }

  @override
  void prepareForInsert() {
    isNewRecord = true;
    currentModel = createNewModel();
    _resetForm();
    tabController.animateTo(0);
    _configureChildrenControllers();
    Get.toNamed(Routes.colaboradorTabPage);
  }

  void _resetForm() {
    formWasChanged = false;
    pessoaModelController.text = '';
    cargoModelController.text = '';
    setorModelController.text = '';
    colaboradorSituacaoModelController.text = '';
    tipoAdmissaoModelController.text = '';
    colaboradorTipoModelController.text = '';
    sindicatoModelController.text = '';
    matriculaController.text = '';
    ctpsNumeroController.text = '';
    ctpsSerieController.text = '';
    observacaoController.text = '';
  }

  @override
  void selectRowForEditingById(int id) {
    final model = modelList.firstWhere((m) => m.id == id);
    currentModel = model.clone();
    updateControllersFromModel();

    tabController.animateTo(0);
    _configureChildrenControllers();
    Get.toNamed(Routes.colaboradorTabPage);
  }

  _configureChildrenControllers() {
    //Vendedor
		Get.put<VendedorController>(VendedorController()); 
		final vendedorController = Get.find<VendedorController>(); 
		vendedorController.updateControllersFromModel(); 

    //Relacionamentos
		Get.put<ColaboradorRelacionamentoController>(ColaboradorRelacionamentoController()); 
		final colaboradorRelacionamentoController = Get.find<ColaboradorRelacionamentoController>(); 
		colaboradorRelacionamentoController.userMadeChanges = false; 

  }
  
  void updateControllersFromModel() {
    pessoaModelController.text = currentModel.pessoaModel?.nome?.toString() ?? '';
    cargoModelController.text = currentModel.cargoModel?.nome?.toString() ?? '';
    setorModelController.text = currentModel.setorModel?.nome?.toString() ?? '';
    colaboradorSituacaoModelController.text = currentModel.colaboradorSituacaoModel?.nome?.toString() ?? '';
    tipoAdmissaoModelController.text = currentModel.tipoAdmissaoModel?.nome?.toString() ?? '';
    colaboradorTipoModelController.text = currentModel.colaboradorTipoModel?.nome?.toString() ?? '';
    sindicatoModelController.text = currentModel.sindicatoModel?.nome?.toString() ?? '';
    matriculaController.text = currentModel.matricula ?? '';
    ctpsNumeroController.text = currentModel.ctpsNumero ?? '';
    ctpsSerieController.text = currentModel.ctpsSerie ?? '';
    observacaoController.text = currentModel.observacao ?? '';
    formWasChanged = false;
  }

  @override
  Future<void> save() async {
    if (!validateCurrentForm()) return;
    if (validateForms()) {
      if (userMadeChanges()) {
        final existingIndex = modelList.indexWhere((m) => m.id == currentModel.id);

        if (existingIndex >= 0) {
          modelList[existingIndex] = currentModel.clone();
        }

        final result = await repository.save(colaboradorModel: currentModel);
        if (result == null) return;

        if (existingIndex >= 0) {
          modelList[existingIndex] = result;
        } else {
          modelList.insert(0, result);
        }

        if (!GetPlatform.isMobile) {
          updateGridRow(result);
        }

        Get.back(result: true);
      } else {
        Get.back();
      }
    } 
  }

  Future callPessoaLookup() async { 
		final lookupController = Get.find<LookupController>(); 
		lookupController.refreshItems(standardValue: '%'); 
		lookupController.title = '${'lookup_page_title'.tr} [Pessoa]'; 
		lookupController.route = '/pessoa/'; 
		lookupController.gridColumns = pessoaGridColumns(isForLookup: true); 
		lookupController.aliasColumns = PessoaModel.aliasColumns; 
		lookupController.dbColumns = PessoaModel.dbColumns; 
		lookupController.standardColumn = PessoaModel.aliasColumns[PessoaModel.dbColumns.indexOf('nome')]; 

		final plutoRowResult = await Get.toNamed(Routes.lookupPage); 
		if (plutoRowResult != null) { 
			currentModel.idPessoa = plutoRowResult.cells['id']!.value; 
			currentModel.pessoaModel = PessoaModel.fromPlutoRow(plutoRowResult); 
			pessoaModelController.text = currentModel.pessoaModel?.nome ?? ''; 
			formWasChanged = true; 
		}
	}

  Future callCargoLookup() async { 
		final lookupController = Get.find<LookupController>(); 
		lookupController.refreshItems(standardValue: '%'); 
		lookupController.title = '${'lookup_page_title'.tr} [Cargo]'; 
		lookupController.route = '/cargo/'; 
		lookupController.gridColumns = cargoGridColumns(isForLookup: true); 
		lookupController.aliasColumns = CargoModel.aliasColumns; 
		lookupController.dbColumns = CargoModel.dbColumns; 
		lookupController.standardColumn = CargoModel.aliasColumns[CargoModel.dbColumns.indexOf('nome')]; 

		final plutoRowResult = await Get.toNamed(Routes.lookupPage); 
		if (plutoRowResult != null) { 
			currentModel.idCargo = plutoRowResult.cells['id']!.value; 
			currentModel.cargoModel = CargoModel.fromPlutoRow(plutoRowResult); 
			cargoModelController.text = currentModel.cargoModel?.nome ?? ''; 
			formWasChanged = true; 
		}
	}

  Future callSetorLookup() async { 
		final lookupController = Get.find<LookupController>(); 
		lookupController.refreshItems(standardValue: '%'); 
		lookupController.title = '${'lookup_page_title'.tr} [Setor]'; 
		lookupController.route = '/setor/'; 
		lookupController.gridColumns = setorGridColumns(isForLookup: true); 
		lookupController.aliasColumns = SetorModel.aliasColumns; 
		lookupController.dbColumns = SetorModel.dbColumns; 
		lookupController.standardColumn = SetorModel.aliasColumns[SetorModel.dbColumns.indexOf('nome')]; 

		final plutoRowResult = await Get.toNamed(Routes.lookupPage); 
		if (plutoRowResult != null) { 
			currentModel.idSetor = plutoRowResult.cells['id']!.value; 
			currentModel.setorModel = SetorModel.fromPlutoRow(plutoRowResult); 
			setorModelController.text = currentModel.setorModel?.nome ?? ''; 
			formWasChanged = true; 
		}
	}

  Future callColaboradorSituacaoLookup() async { 
		final lookupController = Get.find<LookupController>(); 
		lookupController.refreshItems(standardValue: '%'); 
		lookupController.title = '${'lookup_page_title'.tr} [Situação]'; 
		lookupController.route = '/colaborador-situacao/'; 
		lookupController.gridColumns = colaboradorSituacaoGridColumns(isForLookup: true); 
		lookupController.aliasColumns = ColaboradorSituacaoModel.aliasColumns; 
		lookupController.dbColumns = ColaboradorSituacaoModel.dbColumns; 
		lookupController.standardColumn = ColaboradorSituacaoModel.aliasColumns[ColaboradorSituacaoModel.dbColumns.indexOf('nome')]; 

		final plutoRowResult = await Get.toNamed(Routes.lookupPage); 
		if (plutoRowResult != null) { 
			currentModel.idColaboradorSituacao = plutoRowResult.cells['id']!.value; 
			currentModel.colaboradorSituacaoModel = ColaboradorSituacaoModel.fromPlutoRow(plutoRowResult); 
			colaboradorSituacaoModelController.text = currentModel.colaboradorSituacaoModel?.nome ?? ''; 
			formWasChanged = true; 
		}
	}

  Future callTipoAdmissaoLookup() async { 
		final lookupController = Get.find<LookupController>(); 
		lookupController.refreshItems(standardValue: '%'); 
		lookupController.title = '${'lookup_page_title'.tr} [Tipo Admissao]'; 
		lookupController.route = '/tipo-admissao/'; 
		lookupController.gridColumns = tipoAdmissaoGridColumns(isForLookup: true); 
		lookupController.aliasColumns = TipoAdmissaoModel.aliasColumns; 
		lookupController.dbColumns = TipoAdmissaoModel.dbColumns; 
		lookupController.standardColumn = TipoAdmissaoModel.aliasColumns[TipoAdmissaoModel.dbColumns.indexOf('nome')]; 

		final plutoRowResult = await Get.toNamed(Routes.lookupPage); 
		if (plutoRowResult != null) { 
			currentModel.idTipoAdmissao = plutoRowResult.cells['id']!.value; 
			currentModel.tipoAdmissaoModel = TipoAdmissaoModel.fromPlutoRow(plutoRowResult); 
			tipoAdmissaoModelController.text = currentModel.tipoAdmissaoModel?.nome ?? ''; 
			formWasChanged = true; 
		}
	}

  Future callColaboradorTipoLookup() async { 
		final lookupController = Get.find<LookupController>(); 
		lookupController.refreshItems(standardValue: '%'); 
		lookupController.title = '${'lookup_page_title'.tr} [Tipo Colaborador]'; 
		lookupController.route = '/colaborador-tipo/'; 
		lookupController.gridColumns = colaboradorTipoGridColumns(isForLookup: true); 
		lookupController.aliasColumns = ColaboradorTipoModel.aliasColumns; 
		lookupController.dbColumns = ColaboradorTipoModel.dbColumns; 
		lookupController.standardColumn = ColaboradorTipoModel.aliasColumns[ColaboradorTipoModel.dbColumns.indexOf('nome')]; 

		final plutoRowResult = await Get.toNamed(Routes.lookupPage); 
		if (plutoRowResult != null) { 
			currentModel.idColaboradorTipo = plutoRowResult.cells['id']!.value; 
			currentModel.colaboradorTipoModel = ColaboradorTipoModel.fromPlutoRow(plutoRowResult); 
			colaboradorTipoModelController.text = currentModel.colaboradorTipoModel?.nome ?? ''; 
			formWasChanged = true; 
		}
	}

  Future callSindicatoLookup() async { 
		final lookupController = Get.find<LookupController>(); 
		lookupController.refreshItems(standardValue: '%'); 
		lookupController.title = '${'lookup_page_title'.tr} [Sindicato]'; 
		lookupController.route = '/sindicato/'; 
		lookupController.gridColumns = sindicatoGridColumns(isForLookup: true); 
		lookupController.aliasColumns = SindicatoModel.aliasColumns; 
		lookupController.dbColumns = SindicatoModel.dbColumns; 
		lookupController.standardColumn = SindicatoModel.aliasColumns[SindicatoModel.dbColumns.indexOf('nome')]; 

		final plutoRowResult = await Get.toNamed(Routes.lookupPage); 
		if (plutoRowResult != null) { 
			currentModel.idSindicato = plutoRowResult.cells['id']!.value; 
			currentModel.sindicatoModel = SindicatoModel.fromPlutoRow(plutoRowResult); 
			sindicatoModelController.text = currentModel.sindicatoModel?.nome ?? ''; 
			formWasChanged = true; 
		}
	}


  List<Tab> tabItems = [
    Tab( 
			icon: Icon(iconDataList[Random().nextInt(10)]), 
			text: 'Colaborador', 
		),
    Tab( 
			icon: Icon(iconDataList[Random().nextInt(10)]), 
			text: 'Vendedor', 
		),
    Tab( 
			icon: Icon(iconDataList[Random().nextInt(10)]), 
			text: 'Relacionamentos', 
		),
  ];

  List<Widget> tabPages() {
    return [
      ColaboradorEditPage(),
      VendedorEditPage(),
      const ColaboradorRelacionamentoListPage(),
    ];
  }

  @override
  void preventDataLoss() {
    if (userMadeChanges()) {
      showQuestionDialog('message_data_loss'.tr, () { 
        Get.back(); 
      });
    } else {
      Get.back();
    }
  }  

  bool userMadeChanges() {
    return
    formWasChanged 
    || 
		Get.find<VendedorController>().formWasChangedDetail
    || 
		Get.find<ColaboradorRelacionamentoController>().userMadeChanges
    ;
  }

  void tabChange(int index) {
    validateCurrentForm();
  }

  bool validateCurrentForm() {
    mandatoryMessage = ValidateFormField.validateMandatory(currentModel.pessoaModel?.nome); 
		if (mandatoryMessage != null) { 
			tabController.animateTo(0); 
			showErrorSnackBar(message: '$mandatoryMessage [Pessoa]'); 
			return false; 
		}
    mandatoryMessage = ValidateFormField.validateMandatory(currentModel.sindicatoModel?.nome); 
		if (mandatoryMessage != null) { 
			tabController.animateTo(0); 
			showErrorSnackBar(message: '$mandatoryMessage [Sindicato]'); 
			return false; 
		}
    return true;
  }

  bool validateForms() {
    final resultVendedor = Get.find<VendedorController>().validateForm(); 
		if (!resultVendedor) { 
			tabController.animateTo(1); 
			return false; 
		}
    return true;
  }

  @override
  void onInit() {
    super.onInit();
    tabController = TabController(vsync: this, length: tabItems.length);
  }
	
  @override
  void onClose() {
    tabController.dispose();
    pessoaModelController.dispose();
    cargoModelController.dispose();
    setorModelController.dispose();
    colaboradorSituacaoModelController.dispose();
    tipoAdmissaoModelController.dispose();
    colaboradorTipoModelController.dispose();
    sindicatoModelController.dispose();
    matriculaController.dispose();
    ctpsNumeroController.dispose();
    ctpsSerieController.dispose();
    observacaoController.dispose();
    super.onClose();
  }	
}