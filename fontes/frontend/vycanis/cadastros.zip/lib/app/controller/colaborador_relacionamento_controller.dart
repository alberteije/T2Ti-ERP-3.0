import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:pluto_grid/pluto_grid.dart';
import 'package:extended_masked_text/extended_masked_text.dart';
import 'package:cadastros/app/routes/app_routes.dart';

import 'package:cadastros/app/page/page_imports.dart';
import 'package:cadastros/app/page/shared_widget/message_dialog.dart';
import 'package:cadastros/app/page/grid_columns/grid_columns_imports.dart';
import 'package:cadastros/app/controller/controller_imports.dart';
import 'package:cadastros/app/data/model/model_imports.dart';

class ColaboradorRelacionamentoController extends ControllerBase<ColaboradorRelacionamentoModel, void> {

  ColaboradorRelacionamentoController() : super(repository: null) {
    dbColumns = ColaboradorRelacionamentoModel.dbColumns;
    aliasColumns = ColaboradorRelacionamentoModel.aliasColumns;
    gridColumns = colaboradorRelacionamentoGridColumns();
    functionName = "colaborador_relacionamento";
    screenTitle = "Relacionamentos";
  }

  final _colaboradorRelacionamentoModel = ColaboradorRelacionamentoModel().obs;
  ColaboradorRelacionamentoModel get colaboradorRelacionamentoModel => _colaboradorRelacionamentoModel.value;
  set colaboradorRelacionamentoModel(value) => _colaboradorRelacionamentoModel.value = value ?? ColaboradorRelacionamentoModel();

  List<ColaboradorRelacionamentoModel> get colaboradorRelacionamentoModelList => Get.find<ColaboradorController>().currentModel.colaboradorRelacionamentoModelList ?? [];

  final _userMadeChanges = false.obs;
  get userMadeChanges => _userMadeChanges.value;
  set userMadeChanges(value) => _userMadeChanges.value = value;

  final _formWasChangedDetail = false.obs;
  bool get formWasChangedDetail => _formWasChangedDetail.value;
  set formWasChangedDetail(value) => _formWasChangedDetail.value = value;

  late PlutoGridStateManager _plutoGridStateManager;
  @override
  PlutoGridStateManager get plutoGridStateManager => _plutoGridStateManager;
  @override
  set plutoGridStateManager(value) => _plutoGridStateManager = value;

  final colaboradorRelacionamentoScaffoldKey = GlobalKey<ScaffoldState>();
  final colaboradorRelacionamentoFormKey = GlobalKey<FormState>();

  @override
  ColaboradorRelacionamentoModel createNewModel() => ColaboradorRelacionamentoModel();

  @override
  final standardFieldForFilter = ColaboradorRelacionamentoModel.aliasColumns[ColaboradorRelacionamentoModel.dbColumns.indexOf('nome')];

  final tipoRelacionamentoModelController = TextEditingController();
  final nomeController = TextEditingController();
  final cpfController = MaskedTextController(mask: '000.000.000-00',);
  final registroMatriculaController = TextEditingController();
  final registroCartorioController = TextEditingController();
  final registroCartorioNumeroController = TextEditingController();
  final registroNumeroLivroController = TextEditingController();
  final registroNumeroFolhaController = TextEditingController();
  final salarioFamiliaIdadeLimiteController = MoneyMaskedTextController(precision: 0, decimalSeparator: '', thousandSeparator: '');
  final impostoRendaIdadeLimiteController = MoneyMaskedTextController(precision: 0, decimalSeparator: '', thousandSeparator: '');
  final impostoRendaDataFimController = MoneyMaskedTextController(precision: 0, decimalSeparator: '', thousandSeparator: '');

  final Map<String, dynamic> mobileConfig = {
    'primaryColumns': ['nome'],
    'secondaryColumns': ['data_nascimento'],
  };

  List<Map<String, dynamic>> get mobileItems {
    return modelList.map((colaboradorRelacionamento) => colaboradorRelacionamento.toJson).toList();
  }

  @override
  List<PlutoRow> plutoRows() => List<PlutoRow>.from(colaboradorRelacionamentoModelList.map((model) => model.toPlutoRow()));

  @override
  Future<void> getList({Filter? filter}) async {}

  @override
  void prepareForInsert() {
    isNewRecord = true;
    colaboradorRelacionamentoModel = createNewModel();
    _resetForm();
    Get.to(() => ColaboradorRelacionamentoEditPage());
  }

  void _resetForm() {
    formWasChangedDetail = false;
    tipoRelacionamentoModelController.text = '';
    nomeController.text = '';
    cpfController.text = '';
    registroMatriculaController.text = '';
    registroCartorioController.text = '';
    registroCartorioNumeroController.text = '';
    registroNumeroLivroController.text = '';
    registroNumeroFolhaController.text = '';
    salarioFamiliaIdadeLimiteController.updateValue(0);
    impostoRendaIdadeLimiteController.updateValue(0);
    impostoRendaDataFimController.updateValue(0);
  }

  @override
  void selectRowForEditing(PlutoRow? row) async {
    if (row == null) {
      showInfoSnackBar(message: 'message_select_one_to_edited'.tr);
      return;
    }

    selectRowForEditingByTempId(row.cells['tempId']?.value);
  }

  @override
  void selectRowForEditingById(int id) {}

  void selectRowForEditingByTempId(String tempId) {
		isNewRecord = false;
    final model = colaboradorRelacionamentoModelList.firstWhere((m) => m.tempId == tempId);
    colaboradorRelacionamentoModel = model.clone();
		colaboradorRelacionamentoModel.tempId = model.tempId;
    updateControllersFromModel();
    Get.to(() => ColaboradorRelacionamentoEditPage());
  }

  void updateControllersFromModel() {
    tipoRelacionamentoModelController.text = colaboradorRelacionamentoModel.tipoRelacionamentoModel?.nome?.toString() ?? '';
    nomeController.text = colaboradorRelacionamentoModel.nome ?? '';
    cpfController.text = colaboradorRelacionamentoModel.cpf ?? '';
    registroMatriculaController.text = colaboradorRelacionamentoModel.registroMatricula ?? '';
    registroCartorioController.text = colaboradorRelacionamentoModel.registroCartorio ?? '';
    registroCartorioNumeroController.text = colaboradorRelacionamentoModel.registroCartorioNumero ?? '';
    registroNumeroLivroController.text = colaboradorRelacionamentoModel.registroNumeroLivro ?? '';
    registroNumeroFolhaController.text = colaboradorRelacionamentoModel.registroNumeroFolha ?? '';
    salarioFamiliaIdadeLimiteController.updateValue((colaboradorRelacionamentoModel.salarioFamiliaIdadeLimite ?? 0).toDouble());
    impostoRendaIdadeLimiteController.updateValue((colaboradorRelacionamentoModel.impostoRendaIdadeLimite ?? 0).toDouble());
    impostoRendaDataFimController.updateValue((colaboradorRelacionamentoModel.impostoRendaDataFim ?? 0).toDouble());
    formWasChangedDetail = false;
  }

  @override
  Future<void> save() async {
    if (!colaboradorRelacionamentoFormKey.currentState!.validate()) {
      showErrorSnackBar(message: 'validator_form_message'.tr);
      return;
    }

    if (formWasChangedDetail) {
      if (isNewRecord) {
        colaboradorRelacionamentoModelList.insert(0, colaboradorRelacionamentoModel.clone());
      } else {
        final index = colaboradorRelacionamentoModelList.indexWhere((m) => m.tempId == colaboradorRelacionamentoModel.tempId);
        if (index >= 0) {
          colaboradorRelacionamentoModelList[index] = colaboradorRelacionamentoModel.clone();
        }
      }

      userMadeChanges = true;
      loadData();
      Get.back(result: true);
    } else {
      Get.back();
    }
  }

  Future callTipoRelacionamentoLookup() async { 
		final lookupController = Get.find<LookupController>(); 
		lookupController.refreshItems(standardValue: '%'); 
		lookupController.title = '${'lookup_page_title'.tr} [Tipo Relacionamento]'; 
		lookupController.route = '/tipo-relacionamento/'; 
		lookupController.gridColumns = tipoRelacionamentoGridColumns(isForLookup: true); 
		lookupController.aliasColumns = TipoRelacionamentoModel.aliasColumns; 
		lookupController.dbColumns = TipoRelacionamentoModel.dbColumns; 
		lookupController.standardColumn = TipoRelacionamentoModel.aliasColumns[TipoRelacionamentoModel.dbColumns.indexOf('nome')]; 

		final plutoRowResult = await Get.toNamed(Routes.lookupPage); 
		if (plutoRowResult != null) { 
			colaboradorRelacionamentoModel.idTipoRelacionamento = plutoRowResult.cells['id']!.value; 
			colaboradorRelacionamentoModel.tipoRelacionamentoModel = TipoRelacionamentoModel.fromPlutoRow(plutoRowResult); 
			tipoRelacionamentoModelController.text = colaboradorRelacionamentoModel.tipoRelacionamentoModel?.nome ?? ''; 
			formWasChanged = true; 
		}
	}


  @override
  Future deleteSelected() async {
    final currentRow = plutoGridStateManager.currentRow;
    if (currentRow == null) {
      showInfoSnackBar(message: 'message_select_one_to_delete'.tr);
      return null;
    }
    showDeleteDialog(() async {
      final id = currentRow.cells['id']?.value;
      final tempId = currentRow.cells['tempId']?.value;
      colaboradorRelacionamentoModelList.removeWhere((model) => (id != 0 && model.id == id) || (id == 0 && model.tempId == tempId));
      plutoGridStateManager.removeCurrentRow();
      userMadeChanges = true;
    });
  }

  @override
  void preventDataLoss() {
    if (formWasChangedDetail) {
      showQuestionDialog('message_data_loss'.tr, () => Get.back());
    } else {
      formWasChangedDetail = false;
      Get.back();
    }
  }

  @override
  void onClose() {
    tipoRelacionamentoModelController.dispose();
    nomeController.dispose();
    cpfController.dispose();
    registroMatriculaController.dispose();
    registroCartorioController.dispose();
    registroCartorioNumeroController.dispose();
    registroNumeroLivroController.dispose();
    registroNumeroFolhaController.dispose();
    salarioFamiliaIdadeLimiteController.dispose();
    impostoRendaIdadeLimiteController.dispose();
    impostoRendaDataFimController.dispose();
  }

}