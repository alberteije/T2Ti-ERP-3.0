import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:extended_masked_text/extended_masked_text.dart';
import 'package:cadastros/app/page/grid_columns/grid_columns_imports.dart';
import 'package:cadastros/app/page/shared_widget/message_dialog.dart';
import 'package:cadastros/app/routes/app_routes.dart';
import 'package:cadastros/app/infra/infra_imports.dart';
import 'package:cadastros/app/controller/controller_imports.dart';
import 'package:cadastros/app/data/model/model_imports.dart';

class PessoaFisicaController extends ControllerBase<PessoaFisicaModel, void> {

  PessoaFisicaController() : super(repository: null) {
    dbColumns = PessoaFisicaModel.dbColumns;
    aliasColumns = PessoaFisicaModel.aliasColumns;
    functionName = "pessoa_fisica";
    screenTitle = "Pessoa Física";
  }

	String? mandatoryMessage;

  final _pessoaFisicaModel = PessoaFisicaModel().obs;
  PessoaFisicaModel get pessoaFisicaModel => Get.find<PessoaController>().currentModel.pessoaFisicaModel ?? PessoaFisicaModel();
  set pessoaFisicaModel(value) => _pessoaFisicaModel.value = value ?? PessoaFisicaModel();

  final _formWasChangedDetail = false.obs;
  bool get formWasChangedDetail => _formWasChangedDetail.value;
  set formWasChangedDetail(value) => _formWasChangedDetail.value = value;

  final pessoaFisicaScaffoldKey = GlobalKey<ScaffoldState>();
  final pessoaFisicaFormKey = GlobalKey<FormState>();

  @override
  PessoaFisicaModel createNewModel() => PessoaFisicaModel();

  @override
  final standardFieldForFilter = "";

  final nivelFormacaoModelController = TextEditingController();
  final estadoCivilModelController = TextEditingController();
  final cpfController = MaskedTextController(mask: '000.000.000-00',);
  final rgController = TextEditingController();
  final orgaoRgController = TextEditingController();
  final nacionalidadeController = TextEditingController();
  final naturalidadeController = TextEditingController();
  final nomePaiController = TextEditingController();
  final nomeMaeController = TextEditingController();

  final Map<String, dynamic> mobileConfig = {};

  List<Map<String, dynamic>> get mobileItems {
    return modelList.map((pessoaFisica) => pessoaFisica.toJson).toList();
  }

  @override
  Future<void> getList({Filter? filter}) async {}

  @override
  Future<void> loadData() async {}

  @override
  void prepareForInsert() {}

  @override
  void selectRowForEditingById(int id) {}

  void _resetForm() {
    formWasChangedDetail = false;
    nivelFormacaoModelController.text = '';
    estadoCivilModelController.text = '';
    cpfController.text = '';
    rgController.text = '';
    orgaoRgController.text = '';
    nacionalidadeController.text = '';
    naturalidadeController.text = '';
    nomePaiController.text = '';
    nomeMaeController.text = '';
  }

  void updateControllersFromModel() {
		_resetForm();
    nivelFormacaoModelController.text = pessoaFisicaModel.nivelFormacaoModel?.nome?.toString() ?? '';
    estadoCivilModelController.text = pessoaFisicaModel.estadoCivilModel?.nome?.toString() ?? '';
    cpfController.text = pessoaFisicaModel.cpf ?? '';
    rgController.text = pessoaFisicaModel.rg ?? '';
    orgaoRgController.text = pessoaFisicaModel.orgaoRg ?? '';
    nacionalidadeController.text = pessoaFisicaModel.nacionalidade ?? '';
    naturalidadeController.text = pessoaFisicaModel.naturalidade ?? '';
    nomePaiController.text = pessoaFisicaModel.nomePai ?? '';
    nomeMaeController.text = pessoaFisicaModel.nomeMae ?? '';
  }

  @override
  Future<void> save() async {}

	bool validateForm() {
    mandatoryMessage = ValidateFormField.validateMandatory(pessoaFisicaModel.nivelFormacaoModel?.nome); 
		if (mandatoryMessage != null) { 
			showErrorSnackBar(message: '$mandatoryMessage [Nivel Formacao]'); 
			return false; 
		}
    mandatoryMessage = ValidateFormField.validateMandatory(pessoaFisicaModel.estadoCivilModel?.nome); 
		if (mandatoryMessage != null) { 
			showErrorSnackBar(message: '$mandatoryMessage [Estado Civil]'); 
			return false; 
		}
    return true;
	}

  Future callNivelFormacaoLookup() async { 
		final lookupController = Get.find<LookupController>(); 
		lookupController.refreshItems(standardValue: '%'); 
		lookupController.title = '${'lookup_page_title'.tr} [Nivel Formacao]'; 
		lookupController.route = '/nivel-formacao/'; 
		lookupController.gridColumns = nivelFormacaoGridColumns(isForLookup: true); 
		lookupController.aliasColumns = NivelFormacaoModel.aliasColumns; 
		lookupController.dbColumns = NivelFormacaoModel.dbColumns; 
		lookupController.standardColumn = NivelFormacaoModel.aliasColumns[NivelFormacaoModel.dbColumns.indexOf('nome')]; 

		final plutoRowResult = await Get.toNamed(Routes.lookupPage); 
		if (plutoRowResult != null) { 
			pessoaFisicaModel.idNivelFormacao = plutoRowResult.cells['id']!.value; 
			pessoaFisicaModel.nivelFormacaoModel = NivelFormacaoModel.fromPlutoRow(plutoRowResult); 
			nivelFormacaoModelController.text = pessoaFisicaModel.nivelFormacaoModel?.nome ?? ''; 
			formWasChanged = true; 
		}
	}

  Future callEstadoCivilLookup() async { 
		final lookupController = Get.find<LookupController>(); 
		lookupController.refreshItems(standardValue: '%'); 
		lookupController.title = '${'lookup_page_title'.tr} [Estado Civil]'; 
		lookupController.route = '/estado-civil/'; 
		lookupController.gridColumns = estadoCivilGridColumns(isForLookup: true); 
		lookupController.aliasColumns = EstadoCivilModel.aliasColumns; 
		lookupController.dbColumns = EstadoCivilModel.dbColumns; 
		lookupController.standardColumn = EstadoCivilModel.aliasColumns[EstadoCivilModel.dbColumns.indexOf('nome')]; 

		final plutoRowResult = await Get.toNamed(Routes.lookupPage); 
		if (plutoRowResult != null) { 
			pessoaFisicaModel.idEstadoCivil = plutoRowResult.cells['id']!.value; 
			pessoaFisicaModel.estadoCivilModel = EstadoCivilModel.fromPlutoRow(plutoRowResult); 
			estadoCivilModelController.text = pessoaFisicaModel.estadoCivilModel?.nome ?? ''; 
			formWasChanged = true; 
		}
	}


  @override
  void onClose() {
    nivelFormacaoModelController.dispose();
    estadoCivilModelController.dispose();
    cpfController.dispose();
    rgController.dispose();
    orgaoRgController.dispose();
    nacionalidadeController.dispose();
    naturalidadeController.dispose();
    nomePaiController.dispose();
    nomeMaeController.dispose();
  }

}