import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:extended_masked_text/extended_masked_text.dart';

import 'package:cadastros/app/page/shared_widget/message_dialog.dart';
import 'package:cadastros/app/page/grid_columns/grid_columns_imports.dart';
import 'package:cadastros/app/routes/app_routes.dart';
import 'package:cadastros/app/controller/controller_imports.dart';
import 'package:cadastros/app/data/model/model_imports.dart';
import 'package:cadastros/app/data/repository/banco_agencia_repository.dart';

class BancoAgenciaController extends ControllerBase<BancoAgenciaModel, BancoAgenciaRepository> {

  BancoAgenciaController({required super.repository}) {
    dbColumns = BancoAgenciaModel.dbColumns;
    aliasColumns = BancoAgenciaModel.aliasColumns;
    gridColumns = bancoAgenciaGridColumns();
    functionName = "banco_agencia";
    screenTitle = "Agência";
  }

  @override
  BancoAgenciaModel createNewModel() => BancoAgenciaModel();

  @override
  final standardFieldForFilter = BancoAgenciaModel.aliasColumns[BancoAgenciaModel.dbColumns.indexOf('nome')];

  final bancoModelController = TextEditingController();
  final nomeController = TextEditingController();
  final numeroController = TextEditingController();
  final digitoController = TextEditingController();
  final telefoneController = MaskedTextController(mask: '(00)00000-0000',);
  final contatoController = TextEditingController();
  final gerenteController = TextEditingController();
  final observacaoController = TextEditingController();

  final Map<String, dynamic> mobileConfig = {
    'primaryColumns': ['nome'],
    'secondaryColumns': ['numero'],
  };

  List<Map<String, dynamic>> get mobileItems {
    return modelList.map((bancoAgencia) => bancoAgencia.toJson).toList();
  }

  @override
  void prepareForInsert() {
    isNewRecord = true;
    currentModel = createNewModel();
    _resetForm();
    Get.toNamed(Routes.bancoAgenciaEditPage);
  }

  void _resetForm() {
    formWasChanged = false;
    bancoModelController.text = '';
    nomeController.text = '';
    numeroController.text = '';
    digitoController.text = '';
    telefoneController.text = '';
    contatoController.text = '';
    gerenteController.text = '';
    observacaoController.text = '';
  }

  @override
  void selectRowForEditingById(int id) {
    final model = modelList.firstWhere((m) => m.id == id);
    currentModel = model.clone();
    updateControllersFromModel();
    Get.toNamed(Routes.bancoAgenciaEditPage);
  }

  void updateControllersFromModel() {
    bancoModelController.text = currentModel.bancoModel?.nome?.toString() ?? '';
    nomeController.text = currentModel.nome ?? '';
    numeroController.text = currentModel.numero ?? '';
    digitoController.text = currentModel.digito ?? '';
    telefoneController.text = currentModel.telefone ?? '';
    contatoController.text = currentModel.contato ?? '';
    gerenteController.text = currentModel.gerente ?? '';
    observacaoController.text = currentModel.observacao ?? '';
    formWasChanged = false;
  }

  @override
  Future<void> save() async {
    if (!formKey.currentState!.validate()) {
      showErrorSnackBar(message: 'validator_form_message'.tr);
      return;
    }

    final existingIndex = modelList.indexWhere((m) => m.id == currentModel.id);

    if (existingIndex >= 0) {
      modelList[existingIndex] = currentModel.clone();
    }

    final result = await repository.save(bancoAgenciaModel: currentModel);
    if (result == null) return;

    if (existingIndex >= 0) {
      modelList[existingIndex] = result;
    } else {
      modelList.insert(0, result);
    }

    if (!GetPlatform.isMobile) {
      updateGridRow(result);
    }

    Get.back(result: true);
  }

  Future callBancoLookup() async { 
		final lookupController = Get.find<LookupController>(); 
		lookupController.refreshItems(standardValue: '%'); 
		lookupController.title = '${'lookup_page_title'.tr} [Banco]'; 
		lookupController.route = '/banco/'; 
		lookupController.gridColumns = bancoGridColumns(isForLookup: true); 
		lookupController.aliasColumns = BancoModel.aliasColumns; 
		lookupController.dbColumns = BancoModel.dbColumns; 
		lookupController.standardColumn = BancoModel.aliasColumns[BancoModel.dbColumns.indexOf('nome')]; 

		final plutoRowResult = await Get.toNamed(Routes.lookupPage); 
		if (plutoRowResult != null) { 
			currentModel.idBanco = plutoRowResult.cells['id']!.value; 
			currentModel.bancoModel = BancoModel.fromPlutoRow(plutoRowResult); 
			bancoModelController.text = currentModel.bancoModel?.nome ?? ''; 
			formWasChanged = true; 
		}
	}


  @override
  void onClose() {
    bancoModelController.dispose();
    nomeController.dispose();
    numeroController.dispose();
    digitoController.dispose();
    telefoneController.dispose();
    contatoController.dispose();
    gerenteController.dispose();
    observacaoController.dispose();
    super.onClose();
  }

}