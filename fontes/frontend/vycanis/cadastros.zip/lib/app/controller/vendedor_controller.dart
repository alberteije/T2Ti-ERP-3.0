import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:extended_masked_text/extended_masked_text.dart';
import 'package:cadastros/app/page/grid_columns/grid_columns_imports.dart';
import 'package:cadastros/app/page/shared_widget/message_dialog.dart';
import 'package:cadastros/app/routes/app_routes.dart';
import 'package:cadastros/app/infra/infra_imports.dart';
import 'package:cadastros/app/controller/controller_imports.dart';
import 'package:cadastros/app/data/model/model_imports.dart';

class VendedorController extends ControllerBase<VendedorModel, void> {

  VendedorController() : super(repository: null) {
    dbColumns = VendedorModel.dbColumns;
    aliasColumns = VendedorModel.aliasColumns;
    functionName = "vendedor";
    screenTitle = "Vendedor";
  }

	String? mandatoryMessage;

  final _vendedorModel = VendedorModel().obs;
  VendedorModel get vendedorModel => Get.find<ColaboradorController>().currentModel.vendedorModel ?? VendedorModel();
  set vendedorModel(value) => _vendedorModel.value = value ?? VendedorModel();

  final _formWasChangedDetail = false.obs;
  bool get formWasChangedDetail => _formWasChangedDetail.value;
  set formWasChangedDetail(value) => _formWasChangedDetail.value = value;

  final vendedorScaffoldKey = GlobalKey<ScaffoldState>();
  final vendedorFormKey = GlobalKey<FormState>();

  @override
  VendedorModel createNewModel() => VendedorModel();

  @override
  final standardFieldForFilter = "";

  final comissaoPerfilModelController = TextEditingController();
  final comissaoController = MoneyMaskedTextController();
  final metaVendaController = MoneyMaskedTextController();

  final Map<String, dynamic> mobileConfig = {};

  List<Map<String, dynamic>> get mobileItems {
    return modelList.map((vendedor) => vendedor.toJson).toList();
  }

  @override
  Future<void> getList({Filter? filter}) async {}

  @override
  Future<void> loadData() async {}

  @override
  void prepareForInsert() {}

  @override
  void selectRowForEditingById(int id) {}

  void _resetForm() {
    formWasChangedDetail = false;
    comissaoPerfilModelController.text = '';
    comissaoController.updateValue(0);
    metaVendaController.updateValue(0);
  }

  void updateControllersFromModel() {
		_resetForm();
    comissaoPerfilModelController.text = vendedorModel.comissaoPerfilModel?.nome?.toString() ?? '';
    comissaoController.updateValue(vendedorModel.comissao ?? 0);
    metaVendaController.updateValue(vendedorModel.metaVenda ?? 0);
  }

  @override
  Future<void> save() async {}

	bool validateForm() {
    mandatoryMessage = ValidateFormField.validateMandatory(vendedorModel.comissaoPerfilModel?.nome); 
		if (mandatoryMessage != null) { 
			showErrorSnackBar(message: '$mandatoryMessage [Perfil Comissão]'); 
			return false; 
		}
    return true;
	}

  Future callComissaoPerfilLookup() async { 
		final lookupController = Get.find<LookupController>(); 
		lookupController.refreshItems(standardValue: '%'); 
		lookupController.title = '${'lookup_page_title'.tr} [Perfil Comissão]'; 
		lookupController.route = '/comissao-perfil/'; 
		lookupController.gridColumns = comissaoPerfilGridColumns(isForLookup: true); 
		lookupController.aliasColumns = ComissaoPerfilModel.aliasColumns; 
		lookupController.dbColumns = ComissaoPerfilModel.dbColumns; 
		lookupController.standardColumn = ComissaoPerfilModel.aliasColumns[ComissaoPerfilModel.dbColumns.indexOf('nome')]; 

		final plutoRowResult = await Get.toNamed(Routes.lookupPage); 
		if (plutoRowResult != null) { 
			vendedorModel.idComissaoPerfil = plutoRowResult.cells['id']!.value; 
			vendedorModel.comissaoPerfilModel = ComissaoPerfilModel.fromPlutoRow(plutoRowResult); 
			comissaoPerfilModelController.text = vendedorModel.comissaoPerfilModel?.nome ?? ''; 
			formWasChanged = true; 
		}
	}


  @override
  void onClose() {
    comissaoPerfilModelController.dispose();
    comissaoController.dispose();
    metaVendaController.dispose();
  }

}