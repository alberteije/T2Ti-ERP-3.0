class BancoDomain {
	BancoDomain._();

	static getParticipaCompe(String? participaCompe) { 
		switch (participaCompe) { 
			case '': 
			case 'S': 
				return 'Sim'; 
			case 'N': 
				return 'Não'; 
			default: 
				return null; 
		} 
	} 

	static setParticipaCompe(String? participaCompe) { 
		switch (participaCompe) { 
			case 'Sim': 
				return 'S'; 
			case 'Não': 
				return 'N'; 
			default: 
				return null; 
		} 
	}

}