// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'cfop_dao.dart';

// ignore_for_file: type=lint
mixin _$CfopDaoMixin on DatabaseAccessor<AppDatabase> {
  $CfopsTable get cfops => attachedDatabase.cfops;
}
