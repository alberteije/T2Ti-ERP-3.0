// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'nivel_formacao_dao.dart';

// ignore_for_file: type=lint
mixin _$NivelFormacaoDaoMixin on DatabaseAccessor<AppDatabase> {
  $NivelFormacaosTable get nivelFormacaos => attachedDatabase.nivelFormacaos;
}
