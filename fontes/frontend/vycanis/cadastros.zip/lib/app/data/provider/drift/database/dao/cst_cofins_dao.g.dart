// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'cst_cofins_dao.dart';

// ignore_for_file: type=lint
mixin _$CstCofinsDaoMixin on DatabaseAccessor<AppDatabase> {
  $CstCofinssTable get cstCofinss => attachedDatabase.cstCofinss;
}
