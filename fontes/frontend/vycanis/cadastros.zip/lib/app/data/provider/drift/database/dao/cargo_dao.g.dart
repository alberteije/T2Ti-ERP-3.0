// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'cargo_dao.dart';

// ignore_for_file: type=lint
mixin _$CargoDaoMixin on DatabaseAccessor<AppDatabase> {
  $CargosTable get cargos => attachedDatabase.cargos;
}
