// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'setor_dao.dart';

// ignore_for_file: type=lint
mixin _$SetorDaoMixin on DatabaseAccessor<AppDatabase> {
  $SetorsTable get setors => attachedDatabase.setors;
}
