// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'sindicato_dao.dart';

// ignore_for_file: type=lint
mixin _$SindicatoDaoMixin on DatabaseAccessor<AppDatabase> {
  $SindicatosTable get sindicatos => attachedDatabase.sindicatos;
}
