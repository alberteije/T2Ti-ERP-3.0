// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'banco_agencia_dao.dart';

// ignore_for_file: type=lint
mixin _$BancoAgenciaDaoMixin on DatabaseAccessor<AppDatabase> {
  $BancoAgenciasTable get bancoAgencias => attachedDatabase.bancoAgencias;
  $BancosTable get bancos => attachedDatabase.bancos;
}
