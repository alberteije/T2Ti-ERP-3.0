// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'cst_ipi_dao.dart';

// ignore_for_file: type=lint
mixin _$CstIpiDaoMixin on DatabaseAccessor<AppDatabase> {
  $CstIpisTable get cstIpis => attachedDatabase.cstIpis;
}
