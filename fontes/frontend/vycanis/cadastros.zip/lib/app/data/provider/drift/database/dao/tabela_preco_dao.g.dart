// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'tabela_preco_dao.dart';

// ignore_for_file: type=lint
mixin _$TabelaPrecoDaoMixin on DatabaseAccessor<AppDatabase> {
  $TabelaPrecosTable get tabelaPrecos => attachedDatabase.tabelaPrecos;
}
