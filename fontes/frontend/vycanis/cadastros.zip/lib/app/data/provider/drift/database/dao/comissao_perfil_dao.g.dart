// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'comissao_perfil_dao.dart';

// ignore_for_file: type=lint
mixin _$ComissaoPerfilDaoMixin on DatabaseAccessor<AppDatabase> {
  $ComissaoPerfilsTable get comissaoPerfils => attachedDatabase.comissaoPerfils;
}
