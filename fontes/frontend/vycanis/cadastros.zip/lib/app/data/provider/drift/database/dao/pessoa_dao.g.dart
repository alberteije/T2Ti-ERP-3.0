// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'pessoa_dao.dart';

// ignore_for_file: type=lint
mixin _$PessoaDaoMixin on DatabaseAccessor<AppDatabase> {
  $PessoasTable get pessoas => attachedDatabase.pessoas;
  $PessoaJuridicasTable get pessoaJuridicas => attachedDatabase.pessoaJuridicas;
  $FornecedorsTable get fornecedors => attachedDatabase.fornecedors;
  $ClientesTable get clientes => attachedDatabase.clientes;
  $TabelaPrecosTable get tabelaPrecos => attachedDatabase.tabelaPrecos;
  $PessoaFisicasTable get pessoaFisicas => attachedDatabase.pessoaFisicas;
  $EstadoCivilsTable get estadoCivils => attachedDatabase.estadoCivils;
  $NivelFormacaosTable get nivelFormacaos => attachedDatabase.nivelFormacaos;
  $TransportadorasTable get transportadoras => attachedDatabase.transportadoras;
  $ContadorsTable get contadors => attachedDatabase.contadors;
  $PessoaContatosTable get pessoaContatos => attachedDatabase.pessoaContatos;
  $PessoaTelefonesTable get pessoaTelefones => attachedDatabase.pessoaTelefones;
  $PessoaEnderecosTable get pessoaEnderecos => attachedDatabase.pessoaEnderecos;
}
