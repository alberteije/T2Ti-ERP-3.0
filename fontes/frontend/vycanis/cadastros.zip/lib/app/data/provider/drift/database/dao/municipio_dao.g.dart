// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'municipio_dao.dart';

// ignore_for_file: type=lint
mixin _$MunicipioDaoMixin on DatabaseAccessor<AppDatabase> {
  $MunicipiosTable get municipios => attachedDatabase.municipios;
  $UfsTable get ufs => attachedDatabase.ufs;
}
