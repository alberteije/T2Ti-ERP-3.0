// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'tipo_relacionamento_dao.dart';

// ignore_for_file: type=lint
mixin _$TipoRelacionamentoDaoMixin on DatabaseAccessor<AppDatabase> {
  $TipoRelacionamentosTable get tipoRelacionamentos =>
      attachedDatabase.tipoRelacionamentos;
}
