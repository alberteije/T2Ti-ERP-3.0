// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'cst_pis_dao.dart';

// ignore_for_file: type=lint
mixin _$CstPisDaoMixin on DatabaseAccessor<AppDatabase> {
  $CstPissTable get cstPiss => attachedDatabase.cstPiss;
}
