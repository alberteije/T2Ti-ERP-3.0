// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'ncm_dao.dart';

// ignore_for_file: type=lint
mixin _$NcmDaoMixin on DatabaseAccessor<AppDatabase> {
  $NcmsTable get ncms => attachedDatabase.ncms;
}
