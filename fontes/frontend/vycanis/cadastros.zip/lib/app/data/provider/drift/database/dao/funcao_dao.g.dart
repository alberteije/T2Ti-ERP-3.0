// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'funcao_dao.dart';

// ignore_for_file: type=lint
mixin _$FuncaoDaoMixin on DatabaseAccessor<AppDatabase> {
  $FuncaosTable get funcaos => attachedDatabase.funcaos;
  $PapelFuncaosTable get papelFuncaos => attachedDatabase.papelFuncaos;
}
