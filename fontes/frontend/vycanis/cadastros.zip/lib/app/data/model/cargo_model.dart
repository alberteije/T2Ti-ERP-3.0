import 'dart:convert';
import 'package:pluto_grid/pluto_grid.dart';
import 'package:cadastros/app/data/model/model_imports.dart';


class CargoModel extends ModelBase {
  int? id;
  String? nome;
  String? descricao;
  double? salario;
  String? cbo1994;
  String? cbo2002;

  CargoModel({
    this.id,
    this.nome,
    this.descricao,
    this.salario,
    this.cbo1994,
    this.cbo2002,
  });

  static List<String> dbColumns = <String>[
    'id',
    'nome',
    'descricao',
    'salario',
    'cbo_1994',
    'cbo_2002',
  ];

  static List<String> aliasColumns = <String>[
    'Id',
    'Nome',
    'Descricao',
    'Salario',
    'Cbo 1994',
    'Cbo 2002',
  ];

  CargoModel.fromJson(Map<String, dynamic> jsonData) {
    id = jsonData['id'];
    nome = jsonData['nome'];
    descricao = jsonData['descricao'];
    salario = jsonData['salario']?.toDouble();
    cbo1994 = jsonData['cbo1994'];
    cbo2002 = jsonData['cbo2002'];
  }

  Map<String, dynamic> get toJson {
    Map<String, dynamic> jsonData = <String, dynamic>{};

    jsonData['id'] = id != 0 ? id : null;
    jsonData['nome'] = nome;
    jsonData['descricao'] = descricao;
    jsonData['salario'] = salario;
    jsonData['cbo1994'] = cbo1994;
    jsonData['cbo2002'] = cbo2002;

    return jsonData;
  }

  String objectEncodeJson() {
    final jsonData = toJson;
    return json.encode(jsonData);
  }

  static CargoModel fromPlutoRow(PlutoRow row) {
    return CargoModel(
      id: row.cells['id']?.value,
      nome: row.cells['nome']?.value,
      descricao: row.cells['descricao']?.value,
      salario: row.cells['salario']?.value,
      cbo1994: row.cells['cbo1994']?.value,
      cbo2002: row.cells['cbo2002']?.value,
    );
  }

  PlutoRow toPlutoRow() {
    return PlutoRow(
      cells: {
        'tempId': PlutoCell(value: tempId),
        'id': PlutoCell(value: id ?? 0),
        'nome': PlutoCell(value: nome ?? ''),
        'descricao': PlutoCell(value: descricao ?? ''),
        'salario': PlutoCell(value: salario ?? 0.0),
        'cbo1994': PlutoCell(value: cbo1994 ?? ''),
        'cbo2002': PlutoCell(value: cbo2002 ?? ''),
      },
    );
  }

  CargoModel clone() {
    return CargoModel(
      id: id,
      nome: nome,
      descricao: descricao,
      salario: salario,
      cbo1994: cbo1994,
      cbo2002: cbo2002,
    );
  }

  static CargoModel cloneFrom(CargoModel? model) {
    return CargoModel(
      id: model?.id,
      nome: model?.nome,
      descricao: model?.descricao,
      salario: model?.salario,
      cbo1994: model?.cbo1994,
      cbo2002: model?.cbo2002,
    );
  }


}