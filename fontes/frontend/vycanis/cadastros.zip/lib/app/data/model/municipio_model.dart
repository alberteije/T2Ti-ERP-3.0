import 'dart:convert';
import 'package:pluto_grid/pluto_grid.dart';
import 'package:cadastros/app/data/model/model_imports.dart';


class MunicipioModel extends ModelBase {
  int? id;
  int? idUf;
  String? nome;
  int? codigoIbge;
  int? codigoReceitaFederal;
  int? codigoEstadual;
  UfModel? ufModel;

  MunicipioModel({
    this.id,
    this.idUf,
    this.nome,
    this.codigoIbge,
    this.codigoReceitaFederal,
    this.codigoEstadual,
    UfModel? ufModel,
  }) {
    this.ufModel = ufModel ?? UfModel();
  }

  static List<String> dbColumns = <String>[
    'id',
    'nome',
    'codigo_ibge',
    'codigo_receita_federal',
    'codigo_estadual',
  ];

  static List<String> aliasColumns = <String>[
    'Id',
    'Nome',
    'Codigo Ibge',
    'Codigo Receita Federal',
    'Codigo Estadual',
  ];

  MunicipioModel.fromJson(Map<String, dynamic> jsonData) {
    id = jsonData['id'];
    idUf = jsonData['idUf'];
    nome = jsonData['nome'];
    codigoIbge = jsonData['codigoIbge'];
    codigoReceitaFederal = jsonData['codigoReceitaFederal'];
    codigoEstadual = jsonData['codigoEstadual'];
    ufModel = jsonData['ufModel'] == null ? UfModel() : UfModel.fromJson(jsonData['ufModel']);
  }

  Map<String, dynamic> get toJson {
    Map<String, dynamic> jsonData = <String, dynamic>{};

    jsonData['id'] = id != 0 ? id : null;
    jsonData['idUf'] = idUf != 0 ? idUf : null;
    jsonData['nome'] = nome;
    jsonData['codigoIbge'] = codigoIbge;
    jsonData['codigoReceitaFederal'] = codigoReceitaFederal;
    jsonData['codigoEstadual'] = codigoEstadual;
    jsonData['ufModel'] = ufModel?.toJson;
    jsonData['uf'] = ufModel?.sigla ?? '';

    return jsonData;
  }

  String objectEncodeJson() {
    final jsonData = toJson;
    return json.encode(jsonData);
  }

  static MunicipioModel fromPlutoRow(PlutoRow row) {
    return MunicipioModel(
      id: row.cells['id']?.value,
      idUf: row.cells['idUf']?.value,
      nome: row.cells['nome']?.value,
      codigoIbge: row.cells['codigoIbge']?.value,
      codigoReceitaFederal: row.cells['codigoReceitaFederal']?.value,
      codigoEstadual: row.cells['codigoEstadual']?.value,
    );
  }

  PlutoRow toPlutoRow() {
    return PlutoRow(
      cells: {
        'tempId': PlutoCell(value: tempId),
        'id': PlutoCell(value: id ?? 0),
        'idUf': PlutoCell(value: idUf ?? 0),
        'nome': PlutoCell(value: nome ?? ''),
        'codigoIbge': PlutoCell(value: codigoIbge ?? 0),
        'codigoReceitaFederal': PlutoCell(value: codigoReceitaFederal ?? 0),
        'codigoEstadual': PlutoCell(value: codigoEstadual ?? 0),
        'uf': PlutoCell(value: ufModel?.sigla ?? ''),
      },
    );
  }

  MunicipioModel clone() {
    return MunicipioModel(
      id: id,
      idUf: idUf,
      nome: nome,
      codigoIbge: codigoIbge,
      codigoReceitaFederal: codigoReceitaFederal,
      codigoEstadual: codigoEstadual,
      ufModel: UfModel.cloneFrom(ufModel),
    );
  }

  static MunicipioModel cloneFrom(MunicipioModel? model) {
    return MunicipioModel(
      id: model?.id,
      idUf: model?.idUf,
      nome: model?.nome,
      codigoIbge: model?.codigoIbge,
      codigoReceitaFederal: model?.codigoReceitaFederal,
      codigoEstadual: model?.codigoEstadual,
      ufModel: UfModel.cloneFrom(model?.ufModel),
    );
  }


}