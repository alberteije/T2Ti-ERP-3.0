import 'dart:convert';
import 'package:pluto_grid/pluto_grid.dart';
import 'package:cadastros/app/data/model/model_imports.dart';

import 'package:cadastros/app/infra/infra_imports.dart';
import 'package:intl/intl.dart';
import 'package:cadastros/app/data/domain/domain_imports.dart';

class ColaboradorRelacionamentoModel extends ModelBase {
  int? id;
  int? idColaborador;
  int? idTipoRelacionamento;
  String? nome;
  DateTime? dataNascimento;
  String? cpf;
  String? registroMatricula;
  String? registroCartorio;
  String? registroCartorioNumero;
  String? registroNumeroLivro;
  String? registroNumeroFolha;
  DateTime? dataEntregaDocumento;
  String? salarioFamilia;
  int? salarioFamiliaIdadeLimite;
  DateTime? salarioFamiliaDataFim;
  int? impostoRendaIdadeLimite;
  int? impostoRendaDataFim;
  TipoRelacionamentoModel? tipoRelacionamentoModel;

  ColaboradorRelacionamentoModel({
    this.id,
    this.idColaborador,
    this.idTipoRelacionamento,
    this.nome,
    this.dataNascimento,
    this.cpf,
    this.registroMatricula,
    this.registroCartorio,
    this.registroCartorioNumero,
    this.registroNumeroLivro,
    this.registroNumeroFolha,
    this.dataEntregaDocumento,
    this.salarioFamilia = 'Sim',
    this.salarioFamiliaIdadeLimite,
    this.salarioFamiliaDataFim,
    this.impostoRendaIdadeLimite,
    this.impostoRendaDataFim,
    TipoRelacionamentoModel? tipoRelacionamentoModel,
  }) {
    this.tipoRelacionamentoModel = tipoRelacionamentoModel ?? TipoRelacionamentoModel();
  }

  static List<String> dbColumns = <String>[
    'id',
    'nome',
    'data_nascimento',
    'cpf',
    'registro_matricula',
    'registro_cartorio',
    'registro_cartorio_numero',
    'registro_numero_livro',
    'registro_numero_folha',
    'data_entrega_documento',
    'salario_familia',
    'salario_familia_idade_limite',
    'salario_familia_data_fim',
    'imposto_renda_idade_limite',
    'imposto_renda_data_fim',
  ];

  static List<String> aliasColumns = <String>[
    'Id',
    'Nome',
    'Data Nascimento',
    'Cpf',
    'Registro Matricula',
    'Registro Cartorio',
    'Registro Cartorio Numero',
    'Registro Numero Livro',
    'Registro Numero Folha',
    'Data Entrega Documento',
    'Salario Familia',
    'Salario Familia Idade Limite',
    'Salario Familia Data Fim',
    'Imposto Renda Idade Limite',
    'Imposto Renda Data Fim',
  ];

  ColaboradorRelacionamentoModel.fromJson(Map<String, dynamic> jsonData) {
    id = jsonData['id'];
    idColaborador = jsonData['idColaborador'];
    idTipoRelacionamento = jsonData['idTipoRelacionamento'];
    nome = jsonData['nome'];
    dataNascimento = jsonData['dataNascimento'] != null ? DateTime.tryParse(jsonData['dataNascimento']) : null;
    cpf = jsonData['cpf'];
    registroMatricula = jsonData['registroMatricula'];
    registroCartorio = jsonData['registroCartorio'];
    registroCartorioNumero = jsonData['registroCartorioNumero'];
    registroNumeroLivro = jsonData['registroNumeroLivro'];
    registroNumeroFolha = jsonData['registroNumeroFolha'];
    dataEntregaDocumento = jsonData['dataEntregaDocumento'] != null ? DateTime.tryParse(jsonData['dataEntregaDocumento']) : null;
    salarioFamilia = ColaboradorRelacionamentoDomain.getSalarioFamilia(jsonData['salarioFamilia']);
    salarioFamiliaIdadeLimite = jsonData['salarioFamiliaIdadeLimite'];
    salarioFamiliaDataFim = jsonData['salarioFamiliaDataFim'] != null ? DateTime.tryParse(jsonData['salarioFamiliaDataFim']) : null;
    impostoRendaIdadeLimite = jsonData['impostoRendaIdadeLimite'];
    impostoRendaDataFim = jsonData['impostoRendaDataFim'];
    tipoRelacionamentoModel = jsonData['tipoRelacionamentoModel'] == null ? TipoRelacionamentoModel() : TipoRelacionamentoModel.fromJson(jsonData['tipoRelacionamentoModel']);
  }

  Map<String, dynamic> get toJson {
    Map<String, dynamic> jsonData = <String, dynamic>{};

    jsonData['id'] = id != 0 ? id : null;
    jsonData['idColaborador'] = idColaborador != 0 ? idColaborador : null;
    jsonData['idTipoRelacionamento'] = idTipoRelacionamento != 0 ? idTipoRelacionamento : null;
    jsonData['nome'] = nome;
    jsonData['dataNascimento'] = dataNascimento != null ? DateFormat('yyyy-MM-ddT00:00:00').format(dataNascimento!) : null;
    jsonData['cpf'] = Util.removeMask(cpf);
    jsonData['registroMatricula'] = registroMatricula;
    jsonData['registroCartorio'] = registroCartorio;
    jsonData['registroCartorioNumero'] = registroCartorioNumero;
    jsonData['registroNumeroLivro'] = registroNumeroLivro;
    jsonData['registroNumeroFolha'] = registroNumeroFolha;
    jsonData['dataEntregaDocumento'] = dataEntregaDocumento != null ? DateFormat('yyyy-MM-ddT00:00:00').format(dataEntregaDocumento!) : null;
    jsonData['salarioFamilia'] = ColaboradorRelacionamentoDomain.setSalarioFamilia(salarioFamilia);
    jsonData['salarioFamiliaIdadeLimite'] = salarioFamiliaIdadeLimite;
    jsonData['salarioFamiliaDataFim'] = salarioFamiliaDataFim != null ? DateFormat('yyyy-MM-ddT00:00:00').format(salarioFamiliaDataFim!) : null;
    jsonData['impostoRendaIdadeLimite'] = impostoRendaIdadeLimite;
    jsonData['impostoRendaDataFim'] = impostoRendaDataFim;
    jsonData['tipoRelacionamentoModel'] = tipoRelacionamentoModel?.toJson;
    jsonData['tipoRelacionamento'] = tipoRelacionamentoModel?.nome ?? '';

    return jsonData;
  }

  String objectEncodeJson() {
    final jsonData = toJson;
    return json.encode(jsonData);
  }

  static ColaboradorRelacionamentoModel fromPlutoRow(PlutoRow row) {
    return ColaboradorRelacionamentoModel(
      id: row.cells['id']?.value,
      idColaborador: row.cells['idColaborador']?.value,
      idTipoRelacionamento: row.cells['idTipoRelacionamento']?.value,
      nome: row.cells['nome']?.value,
      dataNascimento: Util.stringToDate(row.cells['dataNascimento']?.value),
      cpf: row.cells['cpf']?.value,
      registroMatricula: row.cells['registroMatricula']?.value,
      registroCartorio: row.cells['registroCartorio']?.value,
      registroCartorioNumero: row.cells['registroCartorioNumero']?.value,
      registroNumeroLivro: row.cells['registroNumeroLivro']?.value,
      registroNumeroFolha: row.cells['registroNumeroFolha']?.value,
      dataEntregaDocumento: Util.stringToDate(row.cells['dataEntregaDocumento']?.value),
      salarioFamilia: row.cells['salarioFamilia']?.value,
      salarioFamiliaIdadeLimite: row.cells['salarioFamiliaIdadeLimite']?.value,
      salarioFamiliaDataFim: Util.stringToDate(row.cells['salarioFamiliaDataFim']?.value),
      impostoRendaIdadeLimite: row.cells['impostoRendaIdadeLimite']?.value,
      impostoRendaDataFim: row.cells['impostoRendaDataFim']?.value,
    );
  }

  PlutoRow toPlutoRow() {
    return PlutoRow(
      cells: {
        'tempId': PlutoCell(value: tempId),
        'id': PlutoCell(value: id ?? 0),
        'idColaborador': PlutoCell(value: idColaborador ?? 0),
        'idTipoRelacionamento': PlutoCell(value: idTipoRelacionamento ?? 0),
        'nome': PlutoCell(value: nome ?? ''),
        'dataNascimento': PlutoCell(value: dataNascimento),
        'cpf': PlutoCell(value: cpf ?? ''),
        'registroMatricula': PlutoCell(value: registroMatricula ?? ''),
        'registroCartorio': PlutoCell(value: registroCartorio ?? ''),
        'registroCartorioNumero': PlutoCell(value: registroCartorioNumero ?? ''),
        'registroNumeroLivro': PlutoCell(value: registroNumeroLivro ?? ''),
        'registroNumeroFolha': PlutoCell(value: registroNumeroFolha ?? ''),
        'dataEntregaDocumento': PlutoCell(value: dataEntregaDocumento),
        'salarioFamilia': PlutoCell(value: salarioFamilia ?? ''),
        'salarioFamiliaIdadeLimite': PlutoCell(value: salarioFamiliaIdadeLimite ?? 0),
        'salarioFamiliaDataFim': PlutoCell(value: salarioFamiliaDataFim),
        'impostoRendaIdadeLimite': PlutoCell(value: impostoRendaIdadeLimite ?? 0),
        'impostoRendaDataFim': PlutoCell(value: impostoRendaDataFim ?? 0),
        'tipoRelacionamento': PlutoCell(value: tipoRelacionamentoModel?.nome ?? ''),
      },
    );
  }

  ColaboradorRelacionamentoModel clone() {
    return ColaboradorRelacionamentoModel(
      id: id,
      idColaborador: idColaborador,
      idTipoRelacionamento: idTipoRelacionamento,
      nome: nome,
      dataNascimento: dataNascimento,
      cpf: cpf,
      registroMatricula: registroMatricula,
      registroCartorio: registroCartorio,
      registroCartorioNumero: registroCartorioNumero,
      registroNumeroLivro: registroNumeroLivro,
      registroNumeroFolha: registroNumeroFolha,
      dataEntregaDocumento: dataEntregaDocumento,
      salarioFamilia: salarioFamilia,
      salarioFamiliaIdadeLimite: salarioFamiliaIdadeLimite,
      salarioFamiliaDataFim: salarioFamiliaDataFim,
      impostoRendaIdadeLimite: impostoRendaIdadeLimite,
      impostoRendaDataFim: impostoRendaDataFim,
      tipoRelacionamentoModel: TipoRelacionamentoModel.cloneFrom(tipoRelacionamentoModel),
    );
  }

  static ColaboradorRelacionamentoModel cloneFrom(ColaboradorRelacionamentoModel? model) {
    return ColaboradorRelacionamentoModel(
      id: model?.id,
      idColaborador: model?.idColaborador,
      idTipoRelacionamento: model?.idTipoRelacionamento,
      nome: model?.nome,
      dataNascimento: model?.dataNascimento,
      cpf: model?.cpf,
      registroMatricula: model?.registroMatricula,
      registroCartorio: model?.registroCartorio,
      registroCartorioNumero: model?.registroCartorioNumero,
      registroNumeroLivro: model?.registroNumeroLivro,
      registroNumeroFolha: model?.registroNumeroFolha,
      dataEntregaDocumento: model?.dataEntregaDocumento,
      salarioFamilia: model?.salarioFamilia,
      salarioFamiliaIdadeLimite: model?.salarioFamiliaIdadeLimite,
      salarioFamiliaDataFim: model?.salarioFamiliaDataFim,
      impostoRendaIdadeLimite: model?.impostoRendaIdadeLimite,
      impostoRendaDataFim: model?.impostoRendaDataFim,
      tipoRelacionamentoModel: TipoRelacionamentoModel.cloneFrom(model?.tipoRelacionamentoModel),
    );
  }


}