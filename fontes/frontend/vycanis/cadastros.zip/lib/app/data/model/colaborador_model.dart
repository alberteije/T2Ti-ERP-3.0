import 'dart:convert';
import 'package:pluto_grid/pluto_grid.dart';
import 'package:cadastros/app/data/model/model_imports.dart';

import 'package:cadastros/app/infra/infra_imports.dart';
import 'package:intl/intl.dart';
import 'package:cadastros/app/data/domain/domain_imports.dart';

class ColaboradorModel extends ModelBase {
  int? id;
  int? idPessoa;
  int? idCargo;
  int? idSetor;
  int? idColaboradorSituacao;
  int? idTipoAdmissao;
  int? idColaboradorTipo;
  int? idSindicato;
  String? matricula;
  DateTime? dataCadastro;
  DateTime? dataAdmissao;
  DateTime? dataDemissao;
  String? ctpsNumero;
  String? ctpsSerie;
  DateTime? ctpsDataExpedicao;
  String? ctpsUf;
  String? observacao;
  VendedorModel? vendedorModel;
  PessoaModel? pessoaModel;
  ColaboradorSituacaoModel? colaboradorSituacaoModel;
  ColaboradorTipoModel? colaboradorTipoModel;
  SetorModel? setorModel;
  CargoModel? cargoModel;
  TipoAdmissaoModel? tipoAdmissaoModel;
  List<ColaboradorRelacionamentoModel>? colaboradorRelacionamentoModelList;
  SindicatoModel? sindicatoModel;

  ColaboradorModel({
    this.id,
    this.idPessoa,
    this.idCargo,
    this.idSetor,
    this.idColaboradorSituacao,
    this.idTipoAdmissao,
    this.idColaboradorTipo,
    this.idSindicato,
    this.matricula,
    this.dataCadastro,
    this.dataAdmissao,
    this.dataDemissao,
    this.ctpsNumero,
    this.ctpsSerie,
    this.ctpsDataExpedicao,
    this.ctpsUf = 'AC',
    this.observacao,
    VendedorModel? vendedorModel,
    PessoaModel? pessoaModel,
    ColaboradorSituacaoModel? colaboradorSituacaoModel,
    ColaboradorTipoModel? colaboradorTipoModel,
    SetorModel? setorModel,
    CargoModel? cargoModel,
    TipoAdmissaoModel? tipoAdmissaoModel,
    List<ColaboradorRelacionamentoModel>? colaboradorRelacionamentoModelList,
    SindicatoModel? sindicatoModel,
  }) {
    this.vendedorModel = vendedorModel ?? VendedorModel();
    this.pessoaModel = pessoaModel ?? PessoaModel();
    this.colaboradorSituacaoModel = colaboradorSituacaoModel ?? ColaboradorSituacaoModel();
    this.colaboradorTipoModel = colaboradorTipoModel ?? ColaboradorTipoModel();
    this.setorModel = setorModel ?? SetorModel();
    this.cargoModel = cargoModel ?? CargoModel();
    this.tipoAdmissaoModel = tipoAdmissaoModel ?? TipoAdmissaoModel();
    this.colaboradorRelacionamentoModelList = colaboradorRelacionamentoModelList?.toList(growable: true) ?? [];
    this.sindicatoModel = sindicatoModel ?? SindicatoModel();
  }

  static List<String> dbColumns = <String>[
    'id',
    'matricula',
    'data_cadastro',
    'data_admissao',
    'data_demissao',
    'ctps_numero',
    'ctps_serie',
    'ctps_data_expedicao',
    'ctps_uf',
    'observacao',
  ];

  static List<String> aliasColumns = <String>[
    'Id',
    'Matricula',
    'Data Cadastro',
    'Data Admissao',
    'Data Demissao',
    'Ctps Numero',
    'Ctps Serie',
    'Ctps Data Expedicao',
    'Ctps Uf',
    'Observacao',
  ];

  ColaboradorModel.fromJson(Map<String, dynamic> jsonData) {
    id = jsonData['id'];
    idPessoa = jsonData['idPessoa'];
    idCargo = jsonData['idCargo'];
    idSetor = jsonData['idSetor'];
    idColaboradorSituacao = jsonData['idColaboradorSituacao'];
    idTipoAdmissao = jsonData['idTipoAdmissao'];
    idColaboradorTipo = jsonData['idColaboradorTipo'];
    idSindicato = jsonData['idSindicato'];
    matricula = jsonData['matricula'];
    dataCadastro = jsonData['dataCadastro'] != null ? DateTime.tryParse(jsonData['dataCadastro']) : null;
    dataAdmissao = jsonData['dataAdmissao'] != null ? DateTime.tryParse(jsonData['dataAdmissao']) : null;
    dataDemissao = jsonData['dataDemissao'] != null ? DateTime.tryParse(jsonData['dataDemissao']) : null;
    ctpsNumero = jsonData['ctpsNumero'];
    ctpsSerie = jsonData['ctpsSerie'];
    ctpsDataExpedicao = jsonData['ctpsDataExpedicao'] != null ? DateTime.tryParse(jsonData['ctpsDataExpedicao']) : null;
    ctpsUf = ColaboradorDomain.getCtpsUf(jsonData['ctpsUf']);
    observacao = jsonData['observacao'];
    vendedorModel = jsonData['vendedorModel'] == null ? VendedorModel(comissaoPerfilModel: ComissaoPerfilModel(), ) : VendedorModel.fromJson(jsonData['vendedorModel']);
    pessoaModel = jsonData['pessoaModel'] == null ? PessoaModel() : PessoaModel.fromJson(jsonData['pessoaModel']);
    colaboradorSituacaoModel = jsonData['colaboradorSituacaoModel'] == null ? ColaboradorSituacaoModel() : ColaboradorSituacaoModel.fromJson(jsonData['colaboradorSituacaoModel']);
    colaboradorTipoModel = jsonData['colaboradorTipoModel'] == null ? ColaboradorTipoModel() : ColaboradorTipoModel.fromJson(jsonData['colaboradorTipoModel']);
    setorModel = jsonData['setorModel'] == null ? SetorModel() : SetorModel.fromJson(jsonData['setorModel']);
    cargoModel = jsonData['cargoModel'] == null ? CargoModel() : CargoModel.fromJson(jsonData['cargoModel']);
    tipoAdmissaoModel = jsonData['tipoAdmissaoModel'] == null ? TipoAdmissaoModel() : TipoAdmissaoModel.fromJson(jsonData['tipoAdmissaoModel']);
    colaboradorRelacionamentoModelList = (jsonData['colaboradorRelacionamentoModelList'] as Iterable?)?.map((m) => ColaboradorRelacionamentoModel.fromJson(m)).toList() ?? [];
    sindicatoModel = jsonData['sindicatoModel'] == null ? SindicatoModel() : SindicatoModel.fromJson(jsonData['sindicatoModel']);
  }

  Map<String, dynamic> get toJson {
    Map<String, dynamic> jsonData = <String, dynamic>{};

    jsonData['id'] = id != 0 ? id : null;
    jsonData['idPessoa'] = idPessoa != 0 ? idPessoa : null;
    jsonData['idCargo'] = idCargo != 0 ? idCargo : null;
    jsonData['idSetor'] = idSetor != 0 ? idSetor : null;
    jsonData['idColaboradorSituacao'] = idColaboradorSituacao != 0 ? idColaboradorSituacao : null;
    jsonData['idTipoAdmissao'] = idTipoAdmissao != 0 ? idTipoAdmissao : null;
    jsonData['idColaboradorTipo'] = idColaboradorTipo != 0 ? idColaboradorTipo : null;
    jsonData['idSindicato'] = idSindicato != 0 ? idSindicato : null;
    jsonData['matricula'] = matricula;
    jsonData['dataCadastro'] = dataCadastro != null ? DateFormat('yyyy-MM-ddT00:00:00').format(dataCadastro!) : null;
    jsonData['dataAdmissao'] = dataAdmissao != null ? DateFormat('yyyy-MM-ddT00:00:00').format(dataAdmissao!) : null;
    jsonData['dataDemissao'] = dataDemissao != null ? DateFormat('yyyy-MM-ddT00:00:00').format(dataDemissao!) : null;
    jsonData['ctpsNumero'] = ctpsNumero;
    jsonData['ctpsSerie'] = ctpsSerie;
    jsonData['ctpsDataExpedicao'] = ctpsDataExpedicao != null ? DateFormat('yyyy-MM-ddT00:00:00').format(ctpsDataExpedicao!) : null;
    jsonData['ctpsUf'] = ColaboradorDomain.setCtpsUf(ctpsUf);
    jsonData['observacao'] = observacao;
    jsonData['vendedorModel'] = vendedorModel?.toJson;
    jsonData['pessoaModel'] = pessoaModel?.toJson;
    jsonData['pessoa'] = pessoaModel?.nome ?? '';
    jsonData['colaboradorSituacaoModel'] = colaboradorSituacaoModel?.toJson;
    jsonData['colaboradorSituacao'] = colaboradorSituacaoModel?.nome ?? '';
    jsonData['colaboradorTipoModel'] = colaboradorTipoModel?.toJson;
    jsonData['colaboradorTipo'] = colaboradorTipoModel?.nome ?? '';
    jsonData['setorModel'] = setorModel?.toJson;
    jsonData['setor'] = setorModel?.nome ?? '';
    jsonData['cargoModel'] = cargoModel?.toJson;
    jsonData['cargo'] = cargoModel?.nome ?? '';
    jsonData['tipoAdmissaoModel'] = tipoAdmissaoModel?.toJson;
    jsonData['tipoAdmissao'] = tipoAdmissaoModel?.nome ?? '';
    
		var colaboradorRelacionamentoModelLocalList = []; 
		for (ColaboradorRelacionamentoModel object in colaboradorRelacionamentoModelList ?? []) { 
			colaboradorRelacionamentoModelLocalList.add(object.toJson); 
		}
		jsonData['colaboradorRelacionamentoModelList'] = colaboradorRelacionamentoModelLocalList;
    jsonData['sindicatoModel'] = sindicatoModel?.toJson;
    jsonData['sindicato'] = sindicatoModel?.nome ?? '';

    return jsonData;
  }

  String objectEncodeJson() {
    final jsonData = toJson;
    return json.encode(jsonData);
  }

  static ColaboradorModel fromPlutoRow(PlutoRow row) {
    return ColaboradorModel(
      id: row.cells['id']?.value,
      idPessoa: row.cells['idPessoa']?.value,
      idCargo: row.cells['idCargo']?.value,
      idSetor: row.cells['idSetor']?.value,
      idColaboradorSituacao: row.cells['idColaboradorSituacao']?.value,
      idTipoAdmissao: row.cells['idTipoAdmissao']?.value,
      idColaboradorTipo: row.cells['idColaboradorTipo']?.value,
      idSindicato: row.cells['idSindicato']?.value,
      matricula: row.cells['matricula']?.value,
      dataCadastro: Util.stringToDate(row.cells['dataCadastro']?.value),
      dataAdmissao: Util.stringToDate(row.cells['dataAdmissao']?.value),
      dataDemissao: Util.stringToDate(row.cells['dataDemissao']?.value),
      ctpsNumero: row.cells['ctpsNumero']?.value,
      ctpsSerie: row.cells['ctpsSerie']?.value,
      ctpsDataExpedicao: Util.stringToDate(row.cells['ctpsDataExpedicao']?.value),
      ctpsUf: row.cells['ctpsUf']?.value,
      observacao: row.cells['observacao']?.value,
    );
  }

  PlutoRow toPlutoRow() {
    return PlutoRow(
      cells: {
        'tempId': PlutoCell(value: tempId),
        'id': PlutoCell(value: id ?? 0),
        'idPessoa': PlutoCell(value: idPessoa ?? 0),
        'idCargo': PlutoCell(value: idCargo ?? 0),
        'idSetor': PlutoCell(value: idSetor ?? 0),
        'idColaboradorSituacao': PlutoCell(value: idColaboradorSituacao ?? 0),
        'idTipoAdmissao': PlutoCell(value: idTipoAdmissao ?? 0),
        'idColaboradorTipo': PlutoCell(value: idColaboradorTipo ?? 0),
        'idSindicato': PlutoCell(value: idSindicato ?? 0),
        'matricula': PlutoCell(value: matricula ?? ''),
        'dataCadastro': PlutoCell(value: dataCadastro),
        'dataAdmissao': PlutoCell(value: dataAdmissao),
        'dataDemissao': PlutoCell(value: dataDemissao),
        'ctpsNumero': PlutoCell(value: ctpsNumero ?? ''),
        'ctpsSerie': PlutoCell(value: ctpsSerie ?? ''),
        'ctpsDataExpedicao': PlutoCell(value: ctpsDataExpedicao),
        'ctpsUf': PlutoCell(value: ctpsUf ?? ''),
        'observacao': PlutoCell(value: observacao ?? ''),
        'pessoa': PlutoCell(value: pessoaModel?.nome ?? ''),
        'colaboradorSituacao': PlutoCell(value: colaboradorSituacaoModel?.nome ?? ''),
        'colaboradorTipo': PlutoCell(value: colaboradorTipoModel?.nome ?? ''),
        'setor': PlutoCell(value: setorModel?.nome ?? ''),
        'cargo': PlutoCell(value: cargoModel?.nome ?? ''),
        'tipoAdmissao': PlutoCell(value: tipoAdmissaoModel?.nome ?? ''),
        'sindicato': PlutoCell(value: sindicatoModel?.nome ?? ''),
      },
    );
  }

  ColaboradorModel clone() {
    return ColaboradorModel(
      id: id,
      idPessoa: idPessoa,
      idCargo: idCargo,
      idSetor: idSetor,
      idColaboradorSituacao: idColaboradorSituacao,
      idTipoAdmissao: idTipoAdmissao,
      idColaboradorTipo: idColaboradorTipo,
      idSindicato: idSindicato,
      matricula: matricula,
      dataCadastro: dataCadastro,
      dataAdmissao: dataAdmissao,
      dataDemissao: dataDemissao,
      ctpsNumero: ctpsNumero,
      ctpsSerie: ctpsSerie,
      ctpsDataExpedicao: ctpsDataExpedicao,
      ctpsUf: ctpsUf,
      observacao: observacao,
      vendedorModel: VendedorModel.cloneFrom(vendedorModel),
      pessoaModel: PessoaModel.cloneFrom(pessoaModel),
      colaboradorSituacaoModel: ColaboradorSituacaoModel.cloneFrom(colaboradorSituacaoModel),
      colaboradorTipoModel: ColaboradorTipoModel.cloneFrom(colaboradorTipoModel),
      setorModel: SetorModel.cloneFrom(setorModel),
      cargoModel: CargoModel.cloneFrom(cargoModel),
      tipoAdmissaoModel: TipoAdmissaoModel.cloneFrom(tipoAdmissaoModel),
      colaboradorRelacionamentoModelList: colaboradorRelacionamentoModelListClone(colaboradorRelacionamentoModelList!),
      sindicatoModel: SindicatoModel.cloneFrom(sindicatoModel),
    );
  }

  static ColaboradorModel cloneFrom(ColaboradorModel? model) {
    return ColaboradorModel(
      id: model?.id,
      idPessoa: model?.idPessoa,
      idCargo: model?.idCargo,
      idSetor: model?.idSetor,
      idColaboradorSituacao: model?.idColaboradorSituacao,
      idTipoAdmissao: model?.idTipoAdmissao,
      idColaboradorTipo: model?.idColaboradorTipo,
      idSindicato: model?.idSindicato,
      matricula: model?.matricula,
      dataCadastro: model?.dataCadastro,
      dataAdmissao: model?.dataAdmissao,
      dataDemissao: model?.dataDemissao,
      ctpsNumero: model?.ctpsNumero,
      ctpsSerie: model?.ctpsSerie,
      ctpsDataExpedicao: model?.ctpsDataExpedicao,
      ctpsUf: model?.ctpsUf,
      observacao: model?.observacao,
      vendedorModel: VendedorModel.cloneFrom(model?.vendedorModel),
      pessoaModel: PessoaModel.cloneFrom(model?.pessoaModel),
      colaboradorSituacaoModel: ColaboradorSituacaoModel.cloneFrom(model?.colaboradorSituacaoModel),
      colaboradorTipoModel: ColaboradorTipoModel.cloneFrom(model?.colaboradorTipoModel),
      setorModel: SetorModel.cloneFrom(model?.setorModel),
      cargoModel: CargoModel.cloneFrom(model?.cargoModel),
      tipoAdmissaoModel: TipoAdmissaoModel.cloneFrom(model?.tipoAdmissaoModel),
      sindicatoModel: SindicatoModel.cloneFrom(model?.sindicatoModel),
    );
  }

  colaboradorRelacionamentoModelListClone(List<ColaboradorRelacionamentoModel> colaboradorRelacionamentoModelList) { 
		List<ColaboradorRelacionamentoModel> resultList = [];
		for (var colaboradorRelacionamentoModel in colaboradorRelacionamentoModelList) {
			resultList.add(ColaboradorRelacionamentoModel.cloneFrom(colaboradorRelacionamentoModel));
		}
		return resultList;
	}


}