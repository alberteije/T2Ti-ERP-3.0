import 'dart:convert';
import 'package:pluto_grid/pluto_grid.dart';
import 'package:cadastros/app/data/model/model_imports.dart';

import 'package:cadastros/app/infra/infra_imports.dart';
import 'package:intl/intl.dart';
import 'package:cadastros/app/data/domain/domain_imports.dart';

class SindicatoModel extends ModelBase {
  int? id;
  String? nome;
  int? codigoBanco;
  int? codigoAgencia;
  String? contaBanco;
  String? codigoCedente;
  String? logradouro;
  String? numero;
  String? bairro;
  int? municipioIbge;
  String? uf;
  String? fone1;
  String? fone2;
  String? email;
  String? tipoSindicato;
  DateTime? dataBase;
  double? pisoSalarial;
  String? cnpj;
  String? classificacaoContabilConta;

  SindicatoModel({
    this.id,
    this.nome,
    this.codigoBanco,
    this.codigoAgencia,
    this.contaBanco,
    this.codigoCedente,
    this.logradouro,
    this.numero,
    this.bairro,
    this.municipioIbge,
    this.uf = 'AC',
    this.fone1,
    this.fone2,
    this.email,
    this.tipoSindicato = 'Patronal',
    this.dataBase,
    this.pisoSalarial,
    this.cnpj,
    this.classificacaoContabilConta,
  });

  static List<String> dbColumns = <String>[
    'id',
    'nome',
    'codigo_banco',
    'codigo_agencia',
    'conta_banco',
    'codigo_cedente',
    'logradouro',
    'numero',
    'bairro',
    'municipio_ibge',
    'uf',
    'fone1',
    'fone2',
    'email',
    'tipo_sindicato',
    'data_base',
    'piso_salarial',
    'cnpj',
    'classificacao_contabil_conta',
  ];

  static List<String> aliasColumns = <String>[
    'Id',
    'Nome',
    'Codigo Banco',
    'Codigo Agencia',
    'Conta Banco',
    'Codigo Cedente',
    'Logradouro',
    'Numero',
    'Bairro',
    'Municipio Ibge',
    'Uf',
    'Fone1',
    'Fone2',
    'Email',
    'Tipo Sindicato',
    'Data Base',
    'Piso Salarial',
    'Cnpj',
    'Classificacao Contabil Conta',
  ];

  SindicatoModel.fromJson(Map<String, dynamic> jsonData) {
    id = jsonData['id'];
    nome = jsonData['nome'];
    codigoBanco = jsonData['codigoBanco'];
    codigoAgencia = jsonData['codigoAgencia'];
    contaBanco = jsonData['contaBanco'];
    codigoCedente = jsonData['codigoCedente'];
    logradouro = jsonData['logradouro'];
    numero = jsonData['numero'];
    bairro = jsonData['bairro'];
    municipioIbge = jsonData['municipioIbge'];
    uf = SindicatoDomain.getUf(jsonData['uf']);
    fone1 = jsonData['fone1'];
    fone2 = jsonData['fone2'];
    email = jsonData['email'];
    tipoSindicato = SindicatoDomain.getTipoSindicato(jsonData['tipoSindicato']);
    dataBase = jsonData['dataBase'] != null ? DateTime.tryParse(jsonData['dataBase']) : null;
    pisoSalarial = jsonData['pisoSalarial']?.toDouble();
    cnpj = jsonData['cnpj'];
    classificacaoContabilConta = jsonData['classificacaoContabilConta'];
  }

  Map<String, dynamic> get toJson {
    Map<String, dynamic> jsonData = <String, dynamic>{};

    jsonData['id'] = id != 0 ? id : null;
    jsonData['nome'] = nome;
    jsonData['codigoBanco'] = codigoBanco;
    jsonData['codigoAgencia'] = codigoAgencia;
    jsonData['contaBanco'] = contaBanco;
    jsonData['codigoCedente'] = codigoCedente;
    jsonData['logradouro'] = logradouro;
    jsonData['numero'] = numero;
    jsonData['bairro'] = bairro;
    jsonData['municipioIbge'] = municipioIbge;
    jsonData['uf'] = SindicatoDomain.setUf(uf);
    jsonData['fone1'] = Util.removeMask(fone1);
    jsonData['fone2'] = Util.removeMask(fone2);
    jsonData['email'] = email;
    jsonData['tipoSindicato'] = SindicatoDomain.setTipoSindicato(tipoSindicato);
    jsonData['dataBase'] = dataBase != null ? DateFormat('yyyy-MM-ddT00:00:00').format(dataBase!) : null;
    jsonData['pisoSalarial'] = pisoSalarial;
    jsonData['cnpj'] = Util.removeMask(cnpj);
    jsonData['classificacaoContabilConta'] = classificacaoContabilConta;

    return jsonData;
  }

  String objectEncodeJson() {
    final jsonData = toJson;
    return json.encode(jsonData);
  }

  static SindicatoModel fromPlutoRow(PlutoRow row) {
    return SindicatoModel(
      id: row.cells['id']?.value,
      nome: row.cells['nome']?.value,
      codigoBanco: row.cells['codigoBanco']?.value,
      codigoAgencia: row.cells['codigoAgencia']?.value,
      contaBanco: row.cells['contaBanco']?.value,
      codigoCedente: row.cells['codigoCedente']?.value,
      logradouro: row.cells['logradouro']?.value,
      numero: row.cells['numero']?.value,
      bairro: row.cells['bairro']?.value,
      municipioIbge: row.cells['municipioIbge']?.value,
      uf: row.cells['uf']?.value,
      fone1: row.cells['fone1']?.value,
      fone2: row.cells['fone2']?.value,
      email: row.cells['email']?.value,
      tipoSindicato: row.cells['tipoSindicato']?.value,
      dataBase: Util.stringToDate(row.cells['dataBase']?.value),
      pisoSalarial: row.cells['pisoSalarial']?.value,
      cnpj: row.cells['cnpj']?.value,
      classificacaoContabilConta: row.cells['classificacaoContabilConta']?.value,
    );
  }

  PlutoRow toPlutoRow() {
    return PlutoRow(
      cells: {
        'tempId': PlutoCell(value: tempId),
        'id': PlutoCell(value: id ?? 0),
        'nome': PlutoCell(value: nome ?? ''),
        'codigoBanco': PlutoCell(value: codigoBanco ?? 0),
        'codigoAgencia': PlutoCell(value: codigoAgencia ?? 0),
        'contaBanco': PlutoCell(value: contaBanco ?? ''),
        'codigoCedente': PlutoCell(value: codigoCedente ?? ''),
        'logradouro': PlutoCell(value: logradouro ?? ''),
        'numero': PlutoCell(value: numero ?? ''),
        'bairro': PlutoCell(value: bairro ?? ''),
        'municipioIbge': PlutoCell(value: municipioIbge ?? 0),
        'uf': PlutoCell(value: uf ?? ''),
        'fone1': PlutoCell(value: fone1 ?? ''),
        'fone2': PlutoCell(value: fone2 ?? ''),
        'email': PlutoCell(value: email ?? ''),
        'tipoSindicato': PlutoCell(value: tipoSindicato ?? ''),
        'dataBase': PlutoCell(value: dataBase),
        'pisoSalarial': PlutoCell(value: pisoSalarial ?? 0.0),
        'cnpj': PlutoCell(value: cnpj ?? ''),
        'classificacaoContabilConta': PlutoCell(value: classificacaoContabilConta ?? ''),
      },
    );
  }

  SindicatoModel clone() {
    return SindicatoModel(
      id: id,
      nome: nome,
      codigoBanco: codigoBanco,
      codigoAgencia: codigoAgencia,
      contaBanco: contaBanco,
      codigoCedente: codigoCedente,
      logradouro: logradouro,
      numero: numero,
      bairro: bairro,
      municipioIbge: municipioIbge,
      uf: uf,
      fone1: fone1,
      fone2: fone2,
      email: email,
      tipoSindicato: tipoSindicato,
      dataBase: dataBase,
      pisoSalarial: pisoSalarial,
      cnpj: cnpj,
      classificacaoContabilConta: classificacaoContabilConta,
    );
  }

  static SindicatoModel cloneFrom(SindicatoModel? model) {
    return SindicatoModel(
      id: model?.id,
      nome: model?.nome,
      codigoBanco: model?.codigoBanco,
      codigoAgencia: model?.codigoAgencia,
      contaBanco: model?.contaBanco,
      codigoCedente: model?.codigoCedente,
      logradouro: model?.logradouro,
      numero: model?.numero,
      bairro: model?.bairro,
      municipioIbge: model?.municipioIbge,
      uf: model?.uf,
      fone1: model?.fone1,
      fone2: model?.fone2,
      email: model?.email,
      tipoSindicato: model?.tipoSindicato,
      dataBase: model?.dataBase,
      pisoSalarial: model?.pisoSalarial,
      cnpj: model?.cnpj,
      classificacaoContabilConta: model?.classificacaoContabilConta,
    );
  }


}