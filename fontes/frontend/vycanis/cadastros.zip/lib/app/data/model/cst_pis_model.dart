import 'dart:convert';
import 'package:pluto_grid/pluto_grid.dart';
import 'package:cadastros/app/data/model/model_imports.dart';


class CstPisModel extends ModelBase {
  int? id;
  String? codigo;
  String? descricao;
  String? observacao;

  CstPisModel({
    this.id,
    this.codigo,
    this.descricao,
    this.observacao,
  });

  static List<String> dbColumns = <String>[
    'id',
    'codigo',
    'descricao',
    'observacao',
  ];

  static List<String> aliasColumns = <String>[
    'Id',
    'Codigo',
    'Descricao',
    'Observacao',
  ];

  CstPisModel.fromJson(Map<String, dynamic> jsonData) {
    id = jsonData['id'];
    codigo = jsonData['codigo'];
    descricao = jsonData['descricao'];
    observacao = jsonData['observacao'];
  }

  Map<String, dynamic> get toJson {
    Map<String, dynamic> jsonData = <String, dynamic>{};

    jsonData['id'] = id != 0 ? id : null;
    jsonData['codigo'] = codigo;
    jsonData['descricao'] = descricao;
    jsonData['observacao'] = observacao;

    return jsonData;
  }

  String objectEncodeJson() {
    final jsonData = toJson;
    return json.encode(jsonData);
  }

  static CstPisModel fromPlutoRow(PlutoRow row) {
    return CstPisModel(
      id: row.cells['id']?.value,
      codigo: row.cells['codigo']?.value,
      descricao: row.cells['descricao']?.value,
      observacao: row.cells['observacao']?.value,
    );
  }

  PlutoRow toPlutoRow() {
    return PlutoRow(
      cells: {
        'tempId': PlutoCell(value: tempId),
        'id': PlutoCell(value: id ?? 0),
        'codigo': PlutoCell(value: codigo ?? ''),
        'descricao': PlutoCell(value: descricao ?? ''),
        'observacao': PlutoCell(value: observacao ?? ''),
      },
    );
  }

  CstPisModel clone() {
    return CstPisModel(
      id: id,
      codigo: codigo,
      descricao: descricao,
      observacao: observacao,
    );
  }

  static CstPisModel cloneFrom(CstPisModel? model) {
    return CstPisModel(
      id: model?.id,
      codigo: model?.codigo,
      descricao: model?.descricao,
      observacao: model?.observacao,
    );
  }


}