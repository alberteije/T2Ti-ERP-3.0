import 'dart:convert';
import 'package:pluto_grid/pluto_grid.dart';
import 'package:cadastros/app/data/model/model_imports.dart';

import 'package:cadastros/app/infra/infra_imports.dart';
import 'package:intl/intl.dart';
import 'package:cadastros/app/data/domain/domain_imports.dart';

class PessoaFisicaModel extends ModelBase {
  int? id;
  int? idPessoa;
  int? idNivelFormacao;
  int? idEstadoCivil;
  String? cpf;
  String? rg;
  String? orgaoRg;
  DateTime? dataEmissaoRg;
  DateTime? dataNascimento;
  String? sexo;
  String? raca;
  String? nacionalidade;
  String? naturalidade;
  String? nomePai;
  String? nomeMae;
  EstadoCivilModel? estadoCivilModel;
  NivelFormacaoModel? nivelFormacaoModel;

  PessoaFisicaModel({
    this.id,
    this.idPessoa,
    this.idNivelFormacao,
    this.idEstadoCivil,
    this.cpf,
    this.rg,
    this.orgaoRg,
    this.dataEmissaoRg,
    this.dataNascimento,
    this.sexo = 'Masculino',
    this.raca = 'Branco',
    this.nacionalidade,
    this.naturalidade,
    this.nomePai,
    this.nomeMae,
    EstadoCivilModel? estadoCivilModel,
    NivelFormacaoModel? nivelFormacaoModel,
  }) {
    this.estadoCivilModel = estadoCivilModel ?? EstadoCivilModel();
    this.nivelFormacaoModel = nivelFormacaoModel ?? NivelFormacaoModel();
  }

  static List<String> dbColumns = <String>[
    'id',
    'cpf',
    'rg',
    'orgao_rg',
    'data_emissao_rg',
    'data_nascimento',
    'sexo',
    'raca',
    'nacionalidade',
    'naturalidade',
    'nome_pai',
    'nome_mae',
  ];

  static List<String> aliasColumns = <String>[
    'Id',
    'Cpf',
    'Rg',
    'Orgao Rg',
    'Data Emissao Rg',
    'Data Nascimento',
    'Sexo',
    'Raca',
    'Nacionalidade',
    'Naturalidade',
    'Nome Pai',
    'Nome Mae',
  ];

  PessoaFisicaModel.fromJson(Map<String, dynamic> jsonData) {
    id = jsonData['id'];
    idPessoa = jsonData['idPessoa'];
    idNivelFormacao = jsonData['idNivelFormacao'];
    idEstadoCivil = jsonData['idEstadoCivil'];
    cpf = jsonData['cpf'];
    rg = jsonData['rg'];
    orgaoRg = jsonData['orgaoRg'];
    dataEmissaoRg = jsonData['dataEmissaoRg'] != null ? DateTime.tryParse(jsonData['dataEmissaoRg']) : null;
    dataNascimento = jsonData['dataNascimento'] != null ? DateTime.tryParse(jsonData['dataNascimento']) : null;
    sexo = PessoaFisicaDomain.getSexo(jsonData['sexo']);
    raca = PessoaFisicaDomain.getRaca(jsonData['raca']);
    nacionalidade = jsonData['nacionalidade'];
    naturalidade = jsonData['naturalidade'];
    nomePai = jsonData['nomePai'];
    nomeMae = jsonData['nomeMae'];
    estadoCivilModel = jsonData['estadoCivilModel'] == null ? EstadoCivilModel() : EstadoCivilModel.fromJson(jsonData['estadoCivilModel']);
    nivelFormacaoModel = jsonData['nivelFormacaoModel'] == null ? NivelFormacaoModel() : NivelFormacaoModel.fromJson(jsonData['nivelFormacaoModel']);
  }

  Map<String, dynamic> get toJson {
    Map<String, dynamic> jsonData = <String, dynamic>{};

    jsonData['id'] = id != 0 ? id : null;
    jsonData['idPessoa'] = idPessoa != 0 ? idPessoa : null;
    jsonData['idNivelFormacao'] = idNivelFormacao != 0 ? idNivelFormacao : null;
    jsonData['idEstadoCivil'] = idEstadoCivil != 0 ? idEstadoCivil : null;
    jsonData['cpf'] = Util.removeMask(cpf);
    jsonData['rg'] = rg;
    jsonData['orgaoRg'] = orgaoRg;
    jsonData['dataEmissaoRg'] = dataEmissaoRg != null ? DateFormat('yyyy-MM-ddT00:00:00').format(dataEmissaoRg!) : null;
    jsonData['dataNascimento'] = dataNascimento != null ? DateFormat('yyyy-MM-ddT00:00:00').format(dataNascimento!) : null;
    jsonData['sexo'] = PessoaFisicaDomain.setSexo(sexo);
    jsonData['raca'] = PessoaFisicaDomain.setRaca(raca);
    jsonData['nacionalidade'] = nacionalidade;
    jsonData['naturalidade'] = naturalidade;
    jsonData['nomePai'] = nomePai;
    jsonData['nomeMae'] = nomeMae;
    jsonData['estadoCivilModel'] = estadoCivilModel?.toJson;
    jsonData['estadoCivil'] = estadoCivilModel?.nome ?? '';
    jsonData['nivelFormacaoModel'] = nivelFormacaoModel?.toJson;
    jsonData['nivelFormacao'] = nivelFormacaoModel?.nome ?? '';

    return jsonData;
  }

  String objectEncodeJson() {
    final jsonData = toJson;
    return json.encode(jsonData);
  }

  static PessoaFisicaModel fromPlutoRow(PlutoRow row) {
    return PessoaFisicaModel(
      id: row.cells['id']?.value,
      idPessoa: row.cells['idPessoa']?.value,
      idNivelFormacao: row.cells['idNivelFormacao']?.value,
      idEstadoCivil: row.cells['idEstadoCivil']?.value,
      cpf: row.cells['cpf']?.value,
      rg: row.cells['rg']?.value,
      orgaoRg: row.cells['orgaoRg']?.value,
      dataEmissaoRg: Util.stringToDate(row.cells['dataEmissaoRg']?.value),
      dataNascimento: Util.stringToDate(row.cells['dataNascimento']?.value),
      sexo: row.cells['sexo']?.value,
      raca: row.cells['raca']?.value,
      nacionalidade: row.cells['nacionalidade']?.value,
      naturalidade: row.cells['naturalidade']?.value,
      nomePai: row.cells['nomePai']?.value,
      nomeMae: row.cells['nomeMae']?.value,
    );
  }

  PlutoRow toPlutoRow() {
    return PlutoRow(
      cells: {
        'tempId': PlutoCell(value: tempId),
        'id': PlutoCell(value: id ?? 0),
        'idPessoa': PlutoCell(value: idPessoa ?? 0),
        'idNivelFormacao': PlutoCell(value: idNivelFormacao ?? 0),
        'idEstadoCivil': PlutoCell(value: idEstadoCivil ?? 0),
        'cpf': PlutoCell(value: cpf ?? ''),
        'rg': PlutoCell(value: rg ?? ''),
        'orgaoRg': PlutoCell(value: orgaoRg ?? ''),
        'dataEmissaoRg': PlutoCell(value: dataEmissaoRg),
        'dataNascimento': PlutoCell(value: dataNascimento),
        'sexo': PlutoCell(value: sexo ?? ''),
        'raca': PlutoCell(value: raca ?? ''),
        'nacionalidade': PlutoCell(value: nacionalidade ?? ''),
        'naturalidade': PlutoCell(value: naturalidade ?? ''),
        'nomePai': PlutoCell(value: nomePai ?? ''),
        'nomeMae': PlutoCell(value: nomeMae ?? ''),
        'estadoCivil': PlutoCell(value: estadoCivilModel?.nome ?? ''),
        'nivelFormacao': PlutoCell(value: nivelFormacaoModel?.nome ?? ''),
      },
    );
  }

  PessoaFisicaModel clone() {
    return PessoaFisicaModel(
      id: id,
      idPessoa: idPessoa,
      idNivelFormacao: idNivelFormacao,
      idEstadoCivil: idEstadoCivil,
      cpf: cpf,
      rg: rg,
      orgaoRg: orgaoRg,
      dataEmissaoRg: dataEmissaoRg,
      dataNascimento: dataNascimento,
      sexo: sexo,
      raca: raca,
      nacionalidade: nacionalidade,
      naturalidade: naturalidade,
      nomePai: nomePai,
      nomeMae: nomeMae,
      estadoCivilModel: EstadoCivilModel.cloneFrom(estadoCivilModel),
      nivelFormacaoModel: NivelFormacaoModel.cloneFrom(nivelFormacaoModel),
    );
  }

  static PessoaFisicaModel cloneFrom(PessoaFisicaModel? model) {
    return PessoaFisicaModel(
      id: model?.id,
      idPessoa: model?.idPessoa,
      idNivelFormacao: model?.idNivelFormacao,
      idEstadoCivil: model?.idEstadoCivil,
      cpf: model?.cpf,
      rg: model?.rg,
      orgaoRg: model?.orgaoRg,
      dataEmissaoRg: model?.dataEmissaoRg,
      dataNascimento: model?.dataNascimento,
      sexo: model?.sexo,
      raca: model?.raca,
      nacionalidade: model?.nacionalidade,
      naturalidade: model?.naturalidade,
      nomePai: model?.nomePai,
      nomeMae: model?.nomeMae,
      estadoCivilModel: EstadoCivilModel.cloneFrom(model?.estadoCivilModel),
      nivelFormacaoModel: NivelFormacaoModel.cloneFrom(model?.nivelFormacaoModel),
    );
  }


}