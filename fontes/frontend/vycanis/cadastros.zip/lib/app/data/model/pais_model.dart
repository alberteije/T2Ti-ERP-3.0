import 'dart:convert';
import 'package:pluto_grid/pluto_grid.dart';
import 'package:cadastros/app/data/model/model_imports.dart';


class PaisModel extends ModelBase {
  int? id;
  String? nomePtbr;
  String? nomeEn;
  int? codigo;
  String? sigla2;
  String? sigla3;
  int? codigoBacen;

  PaisModel({
    this.id,
    this.nomePtbr,
    this.nomeEn,
    this.codigo,
    this.sigla2,
    this.sigla3,
    this.codigoBacen,
  });

  static List<String> dbColumns = <String>[
    'id',
    'nome_ptbr',
    'nome_en',
    'codigo',
    'sigla2',
    'sigla3',
    'codigo_bacen',
  ];

  static List<String> aliasColumns = <String>[
    'Id',
    'Nome Ptbr',
    'Nome En',
    'Codigo',
    'Sigla2',
    'Sigla3',
    'Codigo Bacen',
  ];

  PaisModel.fromJson(Map<String, dynamic> jsonData) {
    id = jsonData['id'];
    nomePtbr = jsonData['nomePtbr'];
    nomeEn = jsonData['nomeEn'];
    codigo = jsonData['codigo'];
    sigla2 = jsonData['sigla2'];
    sigla3 = jsonData['sigla3'];
    codigoBacen = jsonData['codigoBacen'];
  }

  Map<String, dynamic> get toJson {
    Map<String, dynamic> jsonData = <String, dynamic>{};

    jsonData['id'] = id != 0 ? id : null;
    jsonData['nomePtbr'] = nomePtbr;
    jsonData['nomeEn'] = nomeEn;
    jsonData['codigo'] = codigo;
    jsonData['sigla2'] = sigla2;
    jsonData['sigla3'] = sigla3;
    jsonData['codigoBacen'] = codigoBacen;

    return jsonData;
  }

  String objectEncodeJson() {
    final jsonData = toJson;
    return json.encode(jsonData);
  }

  static PaisModel fromPlutoRow(PlutoRow row) {
    return PaisModel(
      id: row.cells['id']?.value,
      nomePtbr: row.cells['nomePtbr']?.value,
      nomeEn: row.cells['nomeEn']?.value,
      codigo: row.cells['codigo']?.value,
      sigla2: row.cells['sigla2']?.value,
      sigla3: row.cells['sigla3']?.value,
      codigoBacen: row.cells['codigoBacen']?.value,
    );
  }

  PlutoRow toPlutoRow() {
    return PlutoRow(
      cells: {
        'tempId': PlutoCell(value: tempId),
        'id': PlutoCell(value: id ?? 0),
        'nomePtbr': PlutoCell(value: nomePtbr ?? ''),
        'nomeEn': PlutoCell(value: nomeEn ?? ''),
        'codigo': PlutoCell(value: codigo ?? 0),
        'sigla2': PlutoCell(value: sigla2 ?? ''),
        'sigla3': PlutoCell(value: sigla3 ?? ''),
        'codigoBacen': PlutoCell(value: codigoBacen ?? 0),
      },
    );
  }

  PaisModel clone() {
    return PaisModel(
      id: id,
      nomePtbr: nomePtbr,
      nomeEn: nomeEn,
      codigo: codigo,
      sigla2: sigla2,
      sigla3: sigla3,
      codigoBacen: codigoBacen,
    );
  }

  static PaisModel cloneFrom(PaisModel? model) {
    return PaisModel(
      id: model?.id,
      nomePtbr: model?.nomePtbr,
      nomeEn: model?.nomeEn,
      codigo: model?.codigo,
      sigla2: model?.sigla2,
      sigla3: model?.sigla3,
      codigoBacen: model?.codigoBacen,
    );
  }


}