import 'dart:convert';
import 'package:pluto_grid/pluto_grid.dart';
import 'package:cadastros/app/data/model/model_imports.dart';

import 'package:cadastros/app/data/domain/domain_imports.dart';

class TributGrupoTributarioModel extends ModelBase {
  int? id;
  String? descricao;
  String? origemMercadoria;
  String? observacao;

  TributGrupoTributarioModel({
    this.id,
    this.descricao,
    this.origemMercadoria = 'AAA',
    this.observacao,
  });

  static List<String> dbColumns = <String>[
    'id',
    'descricao',
    'origem_mercadoria',
    'observacao',
  ];

  static List<String> aliasColumns = <String>[
    'Id',
    'Descricao',
    'Origem Mercadoria',
    'Observacao',
  ];

  TributGrupoTributarioModel.fromJson(Map<String, dynamic> jsonData) {
    id = jsonData['id'];
    descricao = jsonData['descricao'];
    origemMercadoria = TributGrupoTributarioDomain.getOrigemMercadoria(jsonData['origemMercadoria']);
    observacao = jsonData['observacao'];
  }

  Map<String, dynamic> get toJson {
    Map<String, dynamic> jsonData = <String, dynamic>{};

    jsonData['id'] = id != 0 ? id : null;
    jsonData['descricao'] = descricao;
    jsonData['origemMercadoria'] = TributGrupoTributarioDomain.setOrigemMercadoria(origemMercadoria);
    jsonData['observacao'] = observacao;

    return jsonData;
  }

  String objectEncodeJson() {
    final jsonData = toJson;
    return json.encode(jsonData);
  }

  static TributGrupoTributarioModel fromPlutoRow(PlutoRow row) {
    return TributGrupoTributarioModel(
      id: row.cells['id']?.value,
      descricao: row.cells['descricao']?.value,
      origemMercadoria: row.cells['origemMercadoria']?.value,
      observacao: row.cells['observacao']?.value,
    );
  }

  PlutoRow toPlutoRow() {
    return PlutoRow(
      cells: {
        'tempId': PlutoCell(value: tempId),
        'id': PlutoCell(value: id ?? 0),
        'descricao': PlutoCell(value: descricao ?? ''),
        'origemMercadoria': PlutoCell(value: origemMercadoria ?? ''),
        'observacao': PlutoCell(value: observacao ?? ''),
      },
    );
  }

  TributGrupoTributarioModel clone() {
    return TributGrupoTributarioModel(
      id: id,
      descricao: descricao,
      origemMercadoria: origemMercadoria,
      observacao: observacao,
    );
  }

  static TributGrupoTributarioModel cloneFrom(TributGrupoTributarioModel? model) {
    return TributGrupoTributarioModel(
      id: model?.id,
      descricao: model?.descricao,
      origemMercadoria: model?.origemMercadoria,
      observacao: model?.observacao,
    );
  }


}