import 'dart:convert';
import 'package:pluto_grid/pluto_grid.dart';
import 'package:cadastros/app/data/model/model_imports.dart';

import 'package:cadastros/app/infra/infra_imports.dart';
import 'package:cadastros/app/data/domain/domain_imports.dart';

class PessoaEnderecoModel extends ModelBase {
  int? id;
  int? idPessoa;
  String? logradouro;
  String? numero;
  String? complemento;
  String? bairro;
  String? cidade;
  String? uf;
  String? cep;
  int? municipioIbge;
  String? principal;
  String? entrega;
  String? cobranca;
  String? correspondencia;

  PessoaEnderecoModel({
    this.id,
    this.idPessoa,
    this.logradouro,
    this.numero,
    this.complemento,
    this.bairro,
    this.cidade,
    this.uf = 'AC',
    this.cep,
    this.municipioIbge,
    this.principal = 'Sim',
    this.entrega = 'Sim',
    this.cobranca = 'Sim',
    this.correspondencia = 'Sim',
  });

  static List<String> dbColumns = <String>[
    'id',
    'logradouro',
    'numero',
    'complemento',
    'bairro',
    'cidade',
    'uf',
    'cep',
    'municipio_ibge',
    'principal',
    'entrega',
    'cobranca',
    'correspondencia',
  ];

  static List<String> aliasColumns = <String>[
    'Id',
    'Logradouro',
    'Numero',
    'Complemento',
    'Bairro',
    'Cidade',
    'Uf',
    'Cep',
    'Municipio Ibge',
    'Principal',
    'Entrega',
    'Cobranca',
    'Correspondencia',
  ];

  PessoaEnderecoModel.fromJson(Map<String, dynamic> jsonData) {
    id = jsonData['id'];
    idPessoa = jsonData['idPessoa'];
    logradouro = jsonData['logradouro'];
    numero = jsonData['numero'];
    complemento = jsonData['complemento'];
    bairro = jsonData['bairro'];
    cidade = jsonData['cidade'];
    uf = PessoaEnderecoDomain.getUf(jsonData['uf']);
    cep = jsonData['cep'];
    municipioIbge = jsonData['municipioIbge'];
    principal = PessoaEnderecoDomain.getPrincipal(jsonData['principal']);
    entrega = PessoaEnderecoDomain.getEntrega(jsonData['entrega']);
    cobranca = PessoaEnderecoDomain.getCobranca(jsonData['cobranca']);
    correspondencia = PessoaEnderecoDomain.getCorrespondencia(jsonData['correspondencia']);
  }

  Map<String, dynamic> get toJson {
    Map<String, dynamic> jsonData = <String, dynamic>{};

    jsonData['id'] = id != 0 ? id : null;
    jsonData['idPessoa'] = idPessoa != 0 ? idPessoa : null;
    jsonData['logradouro'] = logradouro;
    jsonData['numero'] = numero;
    jsonData['complemento'] = complemento;
    jsonData['bairro'] = bairro;
    jsonData['cidade'] = cidade;
    jsonData['uf'] = PessoaEnderecoDomain.setUf(uf);
    jsonData['cep'] = Util.removeMask(cep);
    jsonData['municipioIbge'] = municipioIbge;
    jsonData['principal'] = PessoaEnderecoDomain.setPrincipal(principal);
    jsonData['entrega'] = PessoaEnderecoDomain.setEntrega(entrega);
    jsonData['cobranca'] = PessoaEnderecoDomain.setCobranca(cobranca);
    jsonData['correspondencia'] = PessoaEnderecoDomain.setCorrespondencia(correspondencia);

    return jsonData;
  }

  String objectEncodeJson() {
    final jsonData = toJson;
    return json.encode(jsonData);
  }

  static PessoaEnderecoModel fromPlutoRow(PlutoRow row) {
    return PessoaEnderecoModel(
      id: row.cells['id']?.value,
      idPessoa: row.cells['idPessoa']?.value,
      logradouro: row.cells['logradouro']?.value,
      numero: row.cells['numero']?.value,
      complemento: row.cells['complemento']?.value,
      bairro: row.cells['bairro']?.value,
      cidade: row.cells['cidade']?.value,
      uf: row.cells['uf']?.value,
      cep: row.cells['cep']?.value,
      municipioIbge: row.cells['municipioIbge']?.value,
      principal: row.cells['principal']?.value,
      entrega: row.cells['entrega']?.value,
      cobranca: row.cells['cobranca']?.value,
      correspondencia: row.cells['correspondencia']?.value,
    );
  }

  PlutoRow toPlutoRow() {
    return PlutoRow(
      cells: {
        'tempId': PlutoCell(value: tempId),
        'id': PlutoCell(value: id ?? 0),
        'idPessoa': PlutoCell(value: idPessoa ?? 0),
        'logradouro': PlutoCell(value: logradouro ?? ''),
        'numero': PlutoCell(value: numero ?? ''),
        'complemento': PlutoCell(value: complemento ?? ''),
        'bairro': PlutoCell(value: bairro ?? ''),
        'cidade': PlutoCell(value: cidade ?? ''),
        'uf': PlutoCell(value: uf ?? ''),
        'cep': PlutoCell(value: cep ?? ''),
        'municipioIbge': PlutoCell(value: municipioIbge ?? 0),
        'principal': PlutoCell(value: principal ?? ''),
        'entrega': PlutoCell(value: entrega ?? ''),
        'cobranca': PlutoCell(value: cobranca ?? ''),
        'correspondencia': PlutoCell(value: correspondencia ?? ''),
      },
    );
  }

  PessoaEnderecoModel clone() {
    return PessoaEnderecoModel(
      id: id,
      idPessoa: idPessoa,
      logradouro: logradouro,
      numero: numero,
      complemento: complemento,
      bairro: bairro,
      cidade: cidade,
      uf: uf,
      cep: cep,
      municipioIbge: municipioIbge,
      principal: principal,
      entrega: entrega,
      cobranca: cobranca,
      correspondencia: correspondencia,
    );
  }

  static PessoaEnderecoModel cloneFrom(PessoaEnderecoModel? model) {
    return PessoaEnderecoModel(
      id: model?.id,
      idPessoa: model?.idPessoa,
      logradouro: model?.logradouro,
      numero: model?.numero,
      complemento: model?.complemento,
      bairro: model?.bairro,
      cidade: model?.cidade,
      uf: model?.uf,
      cep: model?.cep,
      municipioIbge: model?.municipioIbge,
      principal: model?.principal,
      entrega: model?.entrega,
      cobranca: model?.cobranca,
      correspondencia: model?.correspondencia,
    );
  }


}