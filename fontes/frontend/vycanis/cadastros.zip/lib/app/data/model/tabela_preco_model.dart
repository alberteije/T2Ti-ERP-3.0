import 'dart:convert';
import 'package:pluto_grid/pluto_grid.dart';
import 'package:cadastros/app/data/model/model_imports.dart';

import 'package:cadastros/app/data/domain/domain_imports.dart';

class TabelaPrecoModel extends ModelBase {
  int? id;
  String? nome;
  String? principal;
  double? coeficiente;

  TabelaPrecoModel({
    this.id,
    this.nome,
    this.principal = 'Sim',
    this.coeficiente,
  });

  static List<String> dbColumns = <String>[
    'id',
    'nome',
    'principal',
    'coeficiente',
  ];

  static List<String> aliasColumns = <String>[
    'Id',
    'Nome',
    'Principal',
    'Coeficiente',
  ];

  TabelaPrecoModel.fromJson(Map<String, dynamic> jsonData) {
    id = jsonData['id'];
    nome = jsonData['nome'];
    principal = TabelaPrecoDomain.getPrincipal(jsonData['principal']);
    coeficiente = jsonData['coeficiente']?.toDouble();
  }

  Map<String, dynamic> get toJson {
    Map<String, dynamic> jsonData = <String, dynamic>{};

    jsonData['id'] = id != 0 ? id : null;
    jsonData['nome'] = nome;
    jsonData['principal'] = TabelaPrecoDomain.setPrincipal(principal);
    jsonData['coeficiente'] = coeficiente;

    return jsonData;
  }

  String objectEncodeJson() {
    final jsonData = toJson;
    return json.encode(jsonData);
  }

  static TabelaPrecoModel fromPlutoRow(PlutoRow row) {
    return TabelaPrecoModel(
      id: row.cells['id']?.value,
      nome: row.cells['nome']?.value,
      principal: row.cells['principal']?.value,
      coeficiente: row.cells['coeficiente']?.value,
    );
  }

  PlutoRow toPlutoRow() {
    return PlutoRow(
      cells: {
        'tempId': PlutoCell(value: tempId),
        'id': PlutoCell(value: id ?? 0),
        'nome': PlutoCell(value: nome ?? ''),
        'principal': PlutoCell(value: principal ?? ''),
        'coeficiente': PlutoCell(value: coeficiente ?? 0.0),
      },
    );
  }

  TabelaPrecoModel clone() {
    return TabelaPrecoModel(
      id: id,
      nome: nome,
      principal: principal,
      coeficiente: coeficiente,
    );
  }

  static TabelaPrecoModel cloneFrom(TabelaPrecoModel? model) {
    return TabelaPrecoModel(
      id: model?.id,
      nome: model?.nome,
      principal: model?.principal,
      coeficiente: model?.coeficiente,
    );
  }


}