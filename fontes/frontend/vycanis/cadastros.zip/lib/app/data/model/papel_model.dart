import 'dart:convert';
import 'package:pluto_grid/pluto_grid.dart';
import 'package:cadastros/app/data/model/model_imports.dart';


class PapelModel extends ModelBase {
  int? id;
  String? nome;
  String? descrica;
  List<PapelFuncaoModel>? papelFuncaoModelList;
  List<UsuarioModel>? usuarioModelList;

  PapelModel({
    this.id,
    this.nome,
    this.descrica,
    List<PapelFuncaoModel>? papelFuncaoModelList,
    List<UsuarioModel>? usuarioModelList,
  }) {
    this.papelFuncaoModelList = papelFuncaoModelList?.toList(growable: true) ?? [];
    this.usuarioModelList = usuarioModelList?.toList(growable: true) ?? [];
  }

  static List<String> dbColumns = <String>[
    'id',
    'nome',
    'descrica',
  ];

  static List<String> aliasColumns = <String>[
    'Id',
    'Nome',
    'Descrica',
  ];

  PapelModel.fromJson(Map<String, dynamic> jsonData) {
    id = jsonData['id'];
    nome = jsonData['nome'];
    descrica = jsonData['descrica'];
    papelFuncaoModelList = (jsonData['papelFuncaoModelList'] as Iterable?)?.map((m) => PapelFuncaoModel.fromJson(m)).toList() ?? [];
    usuarioModelList = (jsonData['usuarioModelList'] as Iterable?)?.map((m) => UsuarioModel.fromJson(m)).toList() ?? [];
  }

  Map<String, dynamic> get toJson {
    Map<String, dynamic> jsonData = <String, dynamic>{};

    jsonData['id'] = id != 0 ? id : null;
    jsonData['nome'] = nome;
    jsonData['descrica'] = descrica;
    
		var papelFuncaoModelLocalList = []; 
		for (PapelFuncaoModel object in papelFuncaoModelList ?? []) { 
			papelFuncaoModelLocalList.add(object.toJson); 
		}
		jsonData['papelFuncaoModelList'] = papelFuncaoModelLocalList;
    
		var usuarioModelLocalList = []; 
		for (UsuarioModel object in usuarioModelList ?? []) { 
			usuarioModelLocalList.add(object.toJson); 
		}
		jsonData['usuarioModelList'] = usuarioModelLocalList;

    return jsonData;
  }

  String objectEncodeJson() {
    final jsonData = toJson;
    return json.encode(jsonData);
  }

  static PapelModel fromPlutoRow(PlutoRow row) {
    return PapelModel(
      id: row.cells['id']?.value,
      nome: row.cells['nome']?.value,
      descrica: row.cells['descrica']?.value,
    );
  }

  PlutoRow toPlutoRow() {
    return PlutoRow(
      cells: {
        'tempId': PlutoCell(value: tempId),
        'id': PlutoCell(value: id ?? 0),
        'nome': PlutoCell(value: nome ?? ''),
        'descrica': PlutoCell(value: descrica ?? ''),
      },
    );
  }

  PapelModel clone() {
    return PapelModel(
      id: id,
      nome: nome,
      descrica: descrica,
      papelFuncaoModelList: papelFuncaoModelListClone(papelFuncaoModelList!),
      usuarioModelList: usuarioModelListClone(usuarioModelList!),
    );
  }

  static PapelModel cloneFrom(PapelModel? model) {
    return PapelModel(
      id: model?.id,
      nome: model?.nome,
      descrica: model?.descrica,
    );
  }

  papelFuncaoModelListClone(List<PapelFuncaoModel> papelFuncaoModelList) { 
		List<PapelFuncaoModel> resultList = [];
		for (var papelFuncaoModel in papelFuncaoModelList) {
			resultList.add(PapelFuncaoModel.cloneFrom(papelFuncaoModel));
		}
		return resultList;
	}

  usuarioModelListClone(List<UsuarioModel> usuarioModelList) { 
		List<UsuarioModel> resultList = [];
		for (var usuarioModel in usuarioModelList) {
			resultList.add(UsuarioModel.cloneFrom(usuarioModel));
		}
		return resultList;
	}


}