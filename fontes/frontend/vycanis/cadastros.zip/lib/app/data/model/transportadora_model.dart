import 'dart:convert';
import 'package:pluto_grid/pluto_grid.dart';
import 'package:cadastros/app/data/model/model_imports.dart';

import 'package:cadastros/app/infra/infra_imports.dart';
import 'package:intl/intl.dart';

class TransportadoraModel extends ModelBase {
  int? id;
  int? idPessoa;
  DateTime? dataCadastro;
  String? observacao;

  TransportadoraModel({
    this.id,
    this.idPessoa,
    this.dataCadastro,
    this.observacao,
  });

  static List<String> dbColumns = <String>[
    'id',
    'data_cadastro',
    'observacao',
  ];

  static List<String> aliasColumns = <String>[
    'Id',
    'Data Cadastro',
    'Observacao',
  ];

  TransportadoraModel.fromJson(Map<String, dynamic> jsonData) {
    id = jsonData['id'];
    idPessoa = jsonData['idPessoa'];
    dataCadastro = jsonData['dataCadastro'] != null ? DateTime.tryParse(jsonData['dataCadastro']) : null;
    observacao = jsonData['observacao'];
  }

  Map<String, dynamic> get toJson {
    Map<String, dynamic> jsonData = <String, dynamic>{};

    jsonData['id'] = id != 0 ? id : null;
    jsonData['idPessoa'] = idPessoa != 0 ? idPessoa : null;
    jsonData['dataCadastro'] = dataCadastro != null ? DateFormat('yyyy-MM-ddT00:00:00').format(dataCadastro!) : null;
    jsonData['observacao'] = observacao;

    return jsonData;
  }

  String objectEncodeJson() {
    final jsonData = toJson;
    return json.encode(jsonData);
  }

  static TransportadoraModel fromPlutoRow(PlutoRow row) {
    return TransportadoraModel(
      id: row.cells['id']?.value,
      idPessoa: row.cells['idPessoa']?.value,
      dataCadastro: Util.stringToDate(row.cells['dataCadastro']?.value),
      observacao: row.cells['observacao']?.value,
    );
  }

  PlutoRow toPlutoRow() {
    return PlutoRow(
      cells: {
        'tempId': PlutoCell(value: tempId),
        'id': PlutoCell(value: id ?? 0),
        'idPessoa': PlutoCell(value: idPessoa ?? 0),
        'dataCadastro': PlutoCell(value: dataCadastro),
        'observacao': PlutoCell(value: observacao ?? ''),
      },
    );
  }

  TransportadoraModel clone() {
    return TransportadoraModel(
      id: id,
      idPessoa: idPessoa,
      dataCadastro: dataCadastro,
      observacao: observacao,
    );
  }

  static TransportadoraModel cloneFrom(TransportadoraModel? model) {
    return TransportadoraModel(
      id: model?.id,
      idPessoa: model?.idPessoa,
      dataCadastro: model?.dataCadastro,
      observacao: model?.observacao,
    );
  }


}