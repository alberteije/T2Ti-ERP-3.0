import 'dart:convert';
import 'package:pluto_grid/pluto_grid.dart';
import 'package:cadastros/app/data/model/model_imports.dart';

import 'package:cadastros/app/data/domain/domain_imports.dart';

class ProdutoUnidadeModel extends ModelBase {
  int? id;
  String? sigla;
  String? podeFracionar;
  String? descricao;

  ProdutoUnidadeModel({
    this.id,
    this.sigla,
    this.podeFracionar = 'Sim',
    this.descricao,
  });

  static List<String> dbColumns = <String>[
    'id',
    'sigla',
    'pode_fracionar',
    'descricao',
  ];

  static List<String> aliasColumns = <String>[
    'Id',
    'Sigla',
    'Pode Fracionar',
    'Descricao',
  ];

  ProdutoUnidadeModel.fromJson(Map<String, dynamic> jsonData) {
    id = jsonData['id'];
    sigla = jsonData['sigla'];
    podeFracionar = ProdutoUnidadeDomain.getPodeFracionar(jsonData['podeFracionar']);
    descricao = jsonData['descricao'];
  }

  Map<String, dynamic> get toJson {
    Map<String, dynamic> jsonData = <String, dynamic>{};

    jsonData['id'] = id != 0 ? id : null;
    jsonData['sigla'] = sigla;
    jsonData['podeFracionar'] = ProdutoUnidadeDomain.setPodeFracionar(podeFracionar);
    jsonData['descricao'] = descricao;

    return jsonData;
  }

  String objectEncodeJson() {
    final jsonData = toJson;
    return json.encode(jsonData);
  }

  static ProdutoUnidadeModel fromPlutoRow(PlutoRow row) {
    return ProdutoUnidadeModel(
      id: row.cells['id']?.value,
      sigla: row.cells['sigla']?.value,
      podeFracionar: row.cells['podeFracionar']?.value,
      descricao: row.cells['descricao']?.value,
    );
  }

  PlutoRow toPlutoRow() {
    return PlutoRow(
      cells: {
        'tempId': PlutoCell(value: tempId),
        'id': PlutoCell(value: id ?? 0),
        'sigla': PlutoCell(value: sigla ?? ''),
        'podeFracionar': PlutoCell(value: podeFracionar ?? ''),
        'descricao': PlutoCell(value: descricao ?? ''),
      },
    );
  }

  ProdutoUnidadeModel clone() {
    return ProdutoUnidadeModel(
      id: id,
      sigla: sigla,
      podeFracionar: podeFracionar,
      descricao: descricao,
    );
  }

  static ProdutoUnidadeModel cloneFrom(ProdutoUnidadeModel? model) {
    return ProdutoUnidadeModel(
      id: model?.id,
      sigla: model?.sigla,
      podeFracionar: model?.podeFracionar,
      descricao: model?.descricao,
    );
  }


}