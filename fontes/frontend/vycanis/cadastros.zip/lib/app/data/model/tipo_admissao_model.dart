import 'dart:convert';
import 'package:pluto_grid/pluto_grid.dart';
import 'package:cadastros/app/data/model/model_imports.dart';


class TipoAdmissaoModel extends ModelBase {
  int? id;
  String? codigo;
  String? nome;
  String? descricao;

  TipoAdmissaoModel({
    this.id,
    this.codigo,
    this.nome,
    this.descricao,
  });

  static List<String> dbColumns = <String>[
    'id',
    'codigo',
    'nome',
    'descricao',
  ];

  static List<String> aliasColumns = <String>[
    'Id',
    'Codigo',
    'Nome',
    'Descricao',
  ];

  TipoAdmissaoModel.fromJson(Map<String, dynamic> jsonData) {
    id = jsonData['id'];
    codigo = jsonData['codigo'];
    nome = jsonData['nome'];
    descricao = jsonData['descricao'];
  }

  Map<String, dynamic> get toJson {
    Map<String, dynamic> jsonData = <String, dynamic>{};

    jsonData['id'] = id != 0 ? id : null;
    jsonData['codigo'] = codigo;
    jsonData['nome'] = nome;
    jsonData['descricao'] = descricao;

    return jsonData;
  }

  String objectEncodeJson() {
    final jsonData = toJson;
    return json.encode(jsonData);
  }

  static TipoAdmissaoModel fromPlutoRow(PlutoRow row) {
    return TipoAdmissaoModel(
      id: row.cells['id']?.value,
      codigo: row.cells['codigo']?.value,
      nome: row.cells['nome']?.value,
      descricao: row.cells['descricao']?.value,
    );
  }

  PlutoRow toPlutoRow() {
    return PlutoRow(
      cells: {
        'tempId': PlutoCell(value: tempId),
        'id': PlutoCell(value: id ?? 0),
        'codigo': PlutoCell(value: codigo ?? ''),
        'nome': PlutoCell(value: nome ?? ''),
        'descricao': PlutoCell(value: descricao ?? ''),
      },
    );
  }

  TipoAdmissaoModel clone() {
    return TipoAdmissaoModel(
      id: id,
      codigo: codigo,
      nome: nome,
      descricao: descricao,
    );
  }

  static TipoAdmissaoModel cloneFrom(TipoAdmissaoModel? model) {
    return TipoAdmissaoModel(
      id: model?.id,
      codigo: model?.codigo,
      nome: model?.nome,
      descricao: model?.descricao,
    );
  }


}