import 'dart:convert';
import 'package:pluto_grid/pluto_grid.dart';
import 'package:cadastros/app/data/model/model_imports.dart';

import 'package:cadastros/app/data/domain/domain_imports.dart';

class CepModel extends ModelBase {
  int? id;
  String? numero;
  String? logradouro;
  String? complemento;
  String? bairro;
  String? municipio;
  String? uf;
  int? codigoIbgeMunicipio;

  CepModel({
    this.id,
    this.numero,
    this.logradouro,
    this.complemento,
    this.bairro,
    this.municipio,
    this.uf = 'AC',
    this.codigoIbgeMunicipio,
  });

  static List<String> dbColumns = <String>[
    'id',
    'numero',
    'logradouro',
    'complemento',
    'bairro',
    'municipio',
    'uf',
    'codigo_ibge_municipio',
  ];

  static List<String> aliasColumns = <String>[
    'Id',
    'Numero',
    'Logradouro',
    'Complemento',
    'Bairro',
    'Municipio',
    'Uf',
    'Codigo Ibge Municipio',
  ];

  CepModel.fromJson(Map<String, dynamic> jsonData) {
    id = jsonData['id'];
    numero = jsonData['numero'];
    logradouro = jsonData['logradouro'];
    complemento = jsonData['complemento'];
    bairro = jsonData['bairro'];
    municipio = jsonData['municipio'];
    uf = CepDomain.getUf(jsonData['uf']);
    codigoIbgeMunicipio = jsonData['codigoIbgeMunicipio'];
  }

  Map<String, dynamic> get toJson {
    Map<String, dynamic> jsonData = <String, dynamic>{};

    jsonData['id'] = id != 0 ? id : null;
    jsonData['numero'] = numero;
    jsonData['logradouro'] = logradouro;
    jsonData['complemento'] = complemento;
    jsonData['bairro'] = bairro;
    jsonData['municipio'] = municipio;
    jsonData['uf'] = CepDomain.setUf(uf);
    jsonData['codigoIbgeMunicipio'] = codigoIbgeMunicipio;

    return jsonData;
  }

  String objectEncodeJson() {
    final jsonData = toJson;
    return json.encode(jsonData);
  }

  static CepModel fromPlutoRow(PlutoRow row) {
    return CepModel(
      id: row.cells['id']?.value,
      numero: row.cells['numero']?.value,
      logradouro: row.cells['logradouro']?.value,
      complemento: row.cells['complemento']?.value,
      bairro: row.cells['bairro']?.value,
      municipio: row.cells['municipio']?.value,
      uf: row.cells['uf']?.value,
      codigoIbgeMunicipio: row.cells['codigoIbgeMunicipio']?.value,
    );
  }

  PlutoRow toPlutoRow() {
    return PlutoRow(
      cells: {
        'tempId': PlutoCell(value: tempId),
        'id': PlutoCell(value: id ?? 0),
        'numero': PlutoCell(value: numero ?? ''),
        'logradouro': PlutoCell(value: logradouro ?? ''),
        'complemento': PlutoCell(value: complemento ?? ''),
        'bairro': PlutoCell(value: bairro ?? ''),
        'municipio': PlutoCell(value: municipio ?? ''),
        'uf': PlutoCell(value: uf ?? ''),
        'codigoIbgeMunicipio': PlutoCell(value: codigoIbgeMunicipio ?? 0),
      },
    );
  }

  CepModel clone() {
    return CepModel(
      id: id,
      numero: numero,
      logradouro: logradouro,
      complemento: complemento,
      bairro: bairro,
      municipio: municipio,
      uf: uf,
      codigoIbgeMunicipio: codigoIbgeMunicipio,
    );
  }

  static CepModel cloneFrom(CepModel? model) {
    return CepModel(
      id: model?.id,
      numero: model?.numero,
      logradouro: model?.logradouro,
      complemento: model?.complemento,
      bairro: model?.bairro,
      municipio: model?.municipio,
      uf: model?.uf,
      codigoIbgeMunicipio: model?.codigoIbgeMunicipio,
    );
  }


}