import 'dart:convert';
import 'package:pluto_grid/pluto_grid.dart';
import 'package:cadastros/app/data/model/model_imports.dart';


class UfModel extends ModelBase {
  int? id;
  String? nome;
  String? sigla;
  int? codigoIbge;

  UfModel({
    this.id,
    this.nome,
    this.sigla,
    this.codigoIbge,
  });

  static List<String> dbColumns = <String>[
    'id',
    'nome',
    'sigla',
    'codigo_ibge',
  ];

  static List<String> aliasColumns = <String>[
    'Id',
    'Nome',
    'Sigla',
    'Codigo Ibge',
  ];

  UfModel.fromJson(Map<String, dynamic> jsonData) {
    id = jsonData['id'];
    nome = jsonData['nome'];
    sigla = jsonData['sigla'];
    codigoIbge = jsonData['codigoIbge'];
  }

  Map<String, dynamic> get toJson {
    Map<String, dynamic> jsonData = <String, dynamic>{};

    jsonData['id'] = id != 0 ? id : null;
    jsonData['nome'] = nome;
    jsonData['sigla'] = sigla;
    jsonData['codigoIbge'] = codigoIbge;

    return jsonData;
  }

  String objectEncodeJson() {
    final jsonData = toJson;
    return json.encode(jsonData);
  }

  static UfModel fromPlutoRow(PlutoRow row) {
    return UfModel(
      id: row.cells['id']?.value,
      nome: row.cells['nome']?.value,
      sigla: row.cells['sigla']?.value,
      codigoIbge: row.cells['codigoIbge']?.value,
    );
  }

  PlutoRow toPlutoRow() {
    return PlutoRow(
      cells: {
        'tempId': PlutoCell(value: tempId),
        'id': PlutoCell(value: id ?? 0),
        'nome': PlutoCell(value: nome ?? ''),
        'sigla': PlutoCell(value: sigla ?? ''),
        'codigoIbge': PlutoCell(value: codigoIbge ?? 0),
      },
    );
  }

  UfModel clone() {
    return UfModel(
      id: id,
      nome: nome,
      sigla: sigla,
      codigoIbge: codigoIbge,
    );
  }

  static UfModel cloneFrom(UfModel? model) {
    return UfModel(
      id: model?.id,
      nome: model?.nome,
      sigla: model?.sigla,
      codigoIbge: model?.codigoIbge,
    );
  }


}