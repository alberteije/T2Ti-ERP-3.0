import 'dart:convert';
import 'package:pluto_grid/pluto_grid.dart';
import 'package:cadastros/app/data/model/model_imports.dart';


class PessoaContatoModel extends ModelBase {
  int? id;
  int? idPessoa;
  String? nome;
  String? email;
  String? observacao;

  PessoaContatoModel({
    this.id,
    this.idPessoa,
    this.nome,
    this.email,
    this.observacao,
  });

  static List<String> dbColumns = <String>[
    'id',
    'nome',
    'email',
    'observacao',
  ];

  static List<String> aliasColumns = <String>[
    'Id',
    'Nome',
    'Email',
    'Observacao',
  ];

  PessoaContatoModel.fromJson(Map<String, dynamic> jsonData) {
    id = jsonData['id'];
    idPessoa = jsonData['idPessoa'];
    nome = jsonData['nome'];
    email = jsonData['email'];
    observacao = jsonData['observacao'];
  }

  Map<String, dynamic> get toJson {
    Map<String, dynamic> jsonData = <String, dynamic>{};

    jsonData['id'] = id != 0 ? id : null;
    jsonData['idPessoa'] = idPessoa != 0 ? idPessoa : null;
    jsonData['nome'] = nome;
    jsonData['email'] = email;
    jsonData['observacao'] = observacao;

    return jsonData;
  }

  String objectEncodeJson() {
    final jsonData = toJson;
    return json.encode(jsonData);
  }

  static PessoaContatoModel fromPlutoRow(PlutoRow row) {
    return PessoaContatoModel(
      id: row.cells['id']?.value,
      idPessoa: row.cells['idPessoa']?.value,
      nome: row.cells['nome']?.value,
      email: row.cells['email']?.value,
      observacao: row.cells['observacao']?.value,
    );
  }

  PlutoRow toPlutoRow() {
    return PlutoRow(
      cells: {
        'tempId': PlutoCell(value: tempId),
        'id': PlutoCell(value: id ?? 0),
        'idPessoa': PlutoCell(value: idPessoa ?? 0),
        'nome': PlutoCell(value: nome ?? ''),
        'email': PlutoCell(value: email ?? ''),
        'observacao': PlutoCell(value: observacao ?? ''),
      },
    );
  }

  PessoaContatoModel clone() {
    return PessoaContatoModel(
      id: id,
      idPessoa: idPessoa,
      nome: nome,
      email: email,
      observacao: observacao,
    );
  }

  static PessoaContatoModel cloneFrom(PessoaContatoModel? model) {
    return PessoaContatoModel(
      id: model?.id,
      idPessoa: model?.idPessoa,
      nome: model?.nome,
      email: model?.email,
      observacao: model?.observacao,
    );
  }


}