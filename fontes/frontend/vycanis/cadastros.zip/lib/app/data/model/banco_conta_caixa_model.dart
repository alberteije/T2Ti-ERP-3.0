import 'dart:convert';
import 'package:pluto_grid/pluto_grid.dart';
import 'package:cadastros/app/data/model/model_imports.dart';

import 'package:cadastros/app/data/domain/domain_imports.dart';

class BancoContaCaixaModel extends ModelBase {
  int? id;
  int? idBancoAgencia;
  String? numero;
  String? digito;
  String? nome;
  String? tipo;
  String? descricao;
  BancoAgenciaModel? bancoAgenciaModel;

  BancoContaCaixaModel({
    this.id,
    this.idBancoAgencia,
    this.numero,
    this.digito,
    this.nome,
    this.tipo = 'Corrente',
    this.descricao,
    BancoAgenciaModel? bancoAgenciaModel,
  }) {
    this.bancoAgenciaModel = bancoAgenciaModel ?? BancoAgenciaModel();
  }

  static List<String> dbColumns = <String>[
    'id',
    'numero',
    'digito',
    'nome',
    'tipo',
    'descricao',
  ];

  static List<String> aliasColumns = <String>[
    'Id',
    'Numero',
    'Digito',
    'Nome',
    'Tipo',
    'Descricao',
  ];

  BancoContaCaixaModel.fromJson(Map<String, dynamic> jsonData) {
    id = jsonData['id'];
    idBancoAgencia = jsonData['idBancoAgencia'];
    numero = jsonData['numero'];
    digito = jsonData['digito'];
    nome = jsonData['nome'];
    tipo = BancoContaCaixaDomain.getTipo(jsonData['tipo']);
    descricao = jsonData['descricao'];
    bancoAgenciaModel = jsonData['bancoAgenciaModel'] == null ? BancoAgenciaModel() : BancoAgenciaModel.fromJson(jsonData['bancoAgenciaModel']);
  }

  Map<String, dynamic> get toJson {
    Map<String, dynamic> jsonData = <String, dynamic>{};

    jsonData['id'] = id != 0 ? id : null;
    jsonData['idBancoAgencia'] = idBancoAgencia != 0 ? idBancoAgencia : null;
    jsonData['numero'] = numero;
    jsonData['digito'] = digito;
    jsonData['nome'] = nome;
    jsonData['tipo'] = BancoContaCaixaDomain.setTipo(tipo);
    jsonData['descricao'] = descricao;
    jsonData['bancoAgenciaModel'] = bancoAgenciaModel?.toJson;
    jsonData['bancoAgencia'] = bancoAgenciaModel?.nome ?? '';

    return jsonData;
  }

  String objectEncodeJson() {
    final jsonData = toJson;
    return json.encode(jsonData);
  }

  static BancoContaCaixaModel fromPlutoRow(PlutoRow row) {
    return BancoContaCaixaModel(
      id: row.cells['id']?.value,
      idBancoAgencia: row.cells['idBancoAgencia']?.value,
      numero: row.cells['numero']?.value,
      digito: row.cells['digito']?.value,
      nome: row.cells['nome']?.value,
      tipo: row.cells['tipo']?.value,
      descricao: row.cells['descricao']?.value,
    );
  }

  PlutoRow toPlutoRow() {
    return PlutoRow(
      cells: {
        'tempId': PlutoCell(value: tempId),
        'id': PlutoCell(value: id ?? 0),
        'idBancoAgencia': PlutoCell(value: idBancoAgencia ?? 0),
        'numero': PlutoCell(value: numero ?? ''),
        'digito': PlutoCell(value: digito ?? ''),
        'nome': PlutoCell(value: nome ?? ''),
        'tipo': PlutoCell(value: tipo ?? ''),
        'descricao': PlutoCell(value: descricao ?? ''),
        'bancoAgencia': PlutoCell(value: bancoAgenciaModel?.nome ?? ''),
      },
    );
  }

  BancoContaCaixaModel clone() {
    return BancoContaCaixaModel(
      id: id,
      idBancoAgencia: idBancoAgencia,
      numero: numero,
      digito: digito,
      nome: nome,
      tipo: tipo,
      descricao: descricao,
      bancoAgenciaModel: BancoAgenciaModel.cloneFrom(bancoAgenciaModel),
    );
  }

  static BancoContaCaixaModel cloneFrom(BancoContaCaixaModel? model) {
    return BancoContaCaixaModel(
      id: model?.id,
      idBancoAgencia: model?.idBancoAgencia,
      numero: model?.numero,
      digito: model?.digito,
      nome: model?.nome,
      tipo: model?.tipo,
      descricao: model?.descricao,
      bancoAgenciaModel: BancoAgenciaModel.cloneFrom(model?.bancoAgenciaModel),
    );
  }


}