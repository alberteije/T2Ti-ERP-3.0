import 'dart:convert';
import 'package:pluto_grid/pluto_grid.dart';
import 'package:cadastros/app/data/model/model_imports.dart';


class CfopModel extends ModelBase {
  int? id;
  int? codigo;
  String? descricao;
  String? aplicacao;

  CfopModel({
    this.id,
    this.codigo,
    this.descricao,
    this.aplicacao,
  });

  static List<String> dbColumns = <String>[
    'id',
    'codigo',
    'descricao',
    'aplicacao',
  ];

  static List<String> aliasColumns = <String>[
    'Id',
    'Codigo',
    'Descricao',
    'Aplicacao',
  ];

  CfopModel.fromJson(Map<String, dynamic> jsonData) {
    id = jsonData['id'];
    codigo = jsonData['codigo'];
    descricao = jsonData['descricao'];
    aplicacao = jsonData['aplicacao'];
  }

  Map<String, dynamic> get toJson {
    Map<String, dynamic> jsonData = <String, dynamic>{};

    jsonData['id'] = id != 0 ? id : null;
    jsonData['codigo'] = codigo;
    jsonData['descricao'] = descricao;
    jsonData['aplicacao'] = aplicacao;

    return jsonData;
  }

  String objectEncodeJson() {
    final jsonData = toJson;
    return json.encode(jsonData);
  }

  static CfopModel fromPlutoRow(PlutoRow row) {
    return CfopModel(
      id: row.cells['id']?.value,
      codigo: row.cells['codigo']?.value,
      descricao: row.cells['descricao']?.value,
      aplicacao: row.cells['aplicacao']?.value,
    );
  }

  PlutoRow toPlutoRow() {
    return PlutoRow(
      cells: {
        'tempId': PlutoCell(value: tempId),
        'id': PlutoCell(value: id ?? 0),
        'codigo': PlutoCell(value: codigo ?? 0),
        'descricao': PlutoCell(value: descricao ?? ''),
        'aplicacao': PlutoCell(value: aplicacao ?? ''),
      },
    );
  }

  CfopModel clone() {
    return CfopModel(
      id: id,
      codigo: codigo,
      descricao: descricao,
      aplicacao: aplicacao,
    );
  }

  static CfopModel cloneFrom(CfopModel? model) {
    return CfopModel(
      id: model?.id,
      codigo: model?.codigo,
      descricao: model?.descricao,
      aplicacao: model?.aplicacao,
    );
  }


}