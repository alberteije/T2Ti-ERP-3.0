import 'dart:convert';
import 'package:pluto_grid/pluto_grid.dart';
import 'package:cadastros/app/data/model/model_imports.dart';

import 'package:cadastros/app/data/domain/domain_imports.dart';

class BancoModel extends ModelBase {
  int? id;
  String? codigo;
  String? nome;
  String? url;
  String? ispb;
  String? participaCompe;

  BancoModel({
    this.id,
    this.codigo,
    this.nome,
    this.url,
    this.ispb,
    this.participaCompe = 'Sim',
  });

  static List<String> dbColumns = <String>[
    'id',
    'codigo',
    'nome',
    'url',
    'ispb',
    'participa_compe',
  ];

  static List<String> aliasColumns = <String>[
    'Id',
    'Codigo',
    'Nome',
    'Url',
    'Ispb',
    'Participa Compe',
  ];

  BancoModel.fromJson(Map<String, dynamic> jsonData) {
    id = jsonData['id'];
    codigo = jsonData['codigo'];
    nome = jsonData['nome'];
    url = jsonData['url'];
    ispb = jsonData['ispb'];
    participaCompe = BancoDomain.getParticipaCompe(jsonData['participaCompe']);
  }

  Map<String, dynamic> get toJson {
    Map<String, dynamic> jsonData = <String, dynamic>{};

    jsonData['id'] = id != 0 ? id : null;
    jsonData['codigo'] = codigo;
    jsonData['nome'] = nome;
    jsonData['url'] = url;
    jsonData['ispb'] = ispb;
    jsonData['participaCompe'] = BancoDomain.setParticipaCompe(participaCompe);

    return jsonData;
  }

  String objectEncodeJson() {
    final jsonData = toJson;
    return json.encode(jsonData);
  }

  static BancoModel fromPlutoRow(PlutoRow row) {
    return BancoModel(
      id: row.cells['id']?.value,
      codigo: row.cells['codigo']?.value,
      nome: row.cells['nome']?.value,
      url: row.cells['url']?.value,
      ispb: row.cells['ispb']?.value,
      participaCompe: row.cells['participaCompe']?.value,
    );
  }

  PlutoRow toPlutoRow() {
    return PlutoRow(
      cells: {
        'tempId': PlutoCell(value: tempId),
        'id': PlutoCell(value: id ?? 0),
        'codigo': PlutoCell(value: codigo ?? ''),
        'nome': PlutoCell(value: nome ?? ''),
        'url': PlutoCell(value: url ?? ''),
        'ispb': PlutoCell(value: ispb ?? ''),
        'participaCompe': PlutoCell(value: participaCompe ?? ''),
      },
    );
  }

  BancoModel clone() {
    return BancoModel(
      id: id,
      codigo: codigo,
      nome: nome,
      url: url,
      ispb: ispb,
      participaCompe: participaCompe,
    );
  }

  static BancoModel cloneFrom(BancoModel? model) {
    return BancoModel(
      id: model?.id,
      codigo: model?.codigo,
      nome: model?.nome,
      url: model?.url,
      ispb: model?.ispb,
      participaCompe: model?.participaCompe,
    );
  }


}