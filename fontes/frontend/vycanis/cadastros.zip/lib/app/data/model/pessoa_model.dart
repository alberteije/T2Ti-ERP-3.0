import 'dart:convert';
import 'package:pluto_grid/pluto_grid.dart';
import 'package:cadastros/app/data/model/model_imports.dart';

import 'package:cadastros/app/data/domain/domain_imports.dart';

class PessoaModel extends ModelBase {
  int? id;
  String? nome;
  String? tipo;
  String? site;
  String? email;
  String? ehCliente;
  String? ehFornecedor;
  String? ehTransportadora;
  String? ehColaborador;
  String? ehContador;
  PessoaJuridicaModel? pessoaJuridicaModel;
  FornecedorModel? fornecedorModel;
  ClienteModel? clienteModel;
  PessoaFisicaModel? pessoaFisicaModel;
  TransportadoraModel? transportadoraModel;
  ContadorModel? contadorModel;
  List<PessoaContatoModel>? pessoaContatoModelList;
  List<PessoaTelefoneModel>? pessoaTelefoneModelList;
  List<PessoaEnderecoModel>? pessoaEnderecoModelList;

  PessoaModel({
    this.id,
    this.nome,
    this.tipo = 'Física',
    this.site,
    this.email,
    this.ehCliente = 'Sim',
    this.ehFornecedor = 'Sim',
    this.ehTransportadora = 'Sim',
    this.ehColaborador = 'Sim',
    this.ehContador = 'Sim',
    PessoaJuridicaModel? pessoaJuridicaModel,
    FornecedorModel? fornecedorModel,
    ClienteModel? clienteModel,
    PessoaFisicaModel? pessoaFisicaModel,
    TransportadoraModel? transportadoraModel,
    ContadorModel? contadorModel,
    List<PessoaContatoModel>? pessoaContatoModelList,
    List<PessoaTelefoneModel>? pessoaTelefoneModelList,
    List<PessoaEnderecoModel>? pessoaEnderecoModelList,
  }) {
    this.pessoaJuridicaModel = pessoaJuridicaModel ?? PessoaJuridicaModel();
    this.fornecedorModel = fornecedorModel ?? FornecedorModel();
    this.clienteModel = clienteModel ?? ClienteModel();
    this.pessoaFisicaModel = pessoaFisicaModel ?? PessoaFisicaModel();
    this.transportadoraModel = transportadoraModel ?? TransportadoraModel();
    this.contadorModel = contadorModel ?? ContadorModel();
    this.pessoaContatoModelList = pessoaContatoModelList?.toList(growable: true) ?? [];
    this.pessoaTelefoneModelList = pessoaTelefoneModelList?.toList(growable: true) ?? [];
    this.pessoaEnderecoModelList = pessoaEnderecoModelList?.toList(growable: true) ?? [];
  }

  static List<String> dbColumns = <String>[
    'id',
    'nome',
    'tipo',
    'site',
    'email',
    'eh_cliente',
    'eh_fornecedor',
    'eh_transportadora',
    'eh_colaborador',
    'eh_contador',
  ];

  static List<String> aliasColumns = <String>[
    'Id',
    'Nome',
    'Tipo',
    'Site',
    'Email',
    'Eh Cliente',
    'Eh Fornecedor',
    'Eh Transportadora',
    'Eh Colaborador',
    'Eh Contador',
  ];

  PessoaModel.fromJson(Map<String, dynamic> jsonData) {
    id = jsonData['id'];
    nome = jsonData['nome'];
    tipo = PessoaDomain.getTipo(jsonData['tipo']);
    site = jsonData['site'];
    email = jsonData['email'];
    ehCliente = PessoaDomain.getEhCliente(jsonData['ehCliente']);
    ehFornecedor = PessoaDomain.getEhFornecedor(jsonData['ehFornecedor']);
    ehTransportadora = PessoaDomain.getEhTransportadora(jsonData['ehTransportadora']);
    ehColaborador = PessoaDomain.getEhColaborador(jsonData['ehColaborador']);
    ehContador = PessoaDomain.getEhContador(jsonData['ehContador']);
    pessoaJuridicaModel = jsonData['pessoaJuridicaModel'] == null ? PessoaJuridicaModel() : PessoaJuridicaModel.fromJson(jsonData['pessoaJuridicaModel']);
    fornecedorModel = jsonData['fornecedorModel'] == null ? FornecedorModel() : FornecedorModel.fromJson(jsonData['fornecedorModel']);
    clienteModel = jsonData['clienteModel'] == null ? ClienteModel(tabelaPrecoModel: TabelaPrecoModel(), ) : ClienteModel.fromJson(jsonData['clienteModel']);
    pessoaFisicaModel = jsonData['pessoaFisicaModel'] == null ? PessoaFisicaModel(estadoCivilModel: EstadoCivilModel(), nivelFormacaoModel: NivelFormacaoModel(), ) : PessoaFisicaModel.fromJson(jsonData['pessoaFisicaModel']);
    transportadoraModel = jsonData['transportadoraModel'] == null ? TransportadoraModel() : TransportadoraModel.fromJson(jsonData['transportadoraModel']);
    contadorModel = jsonData['contadorModel'] == null ? ContadorModel() : ContadorModel.fromJson(jsonData['contadorModel']);
    pessoaContatoModelList = (jsonData['pessoaContatoModelList'] as Iterable?)?.map((m) => PessoaContatoModel.fromJson(m)).toList() ?? [];
    pessoaTelefoneModelList = (jsonData['pessoaTelefoneModelList'] as Iterable?)?.map((m) => PessoaTelefoneModel.fromJson(m)).toList() ?? [];
    pessoaEnderecoModelList = (jsonData['pessoaEnderecoModelList'] as Iterable?)?.map((m) => PessoaEnderecoModel.fromJson(m)).toList() ?? [];
  }

  Map<String, dynamic> get toJson {
    Map<String, dynamic> jsonData = <String, dynamic>{};

    jsonData['id'] = id != 0 ? id : null;
    jsonData['nome'] = nome;
    jsonData['tipo'] = PessoaDomain.setTipo(tipo);
    jsonData['site'] = site;
    jsonData['email'] = email;
    jsonData['ehCliente'] = PessoaDomain.setEhCliente(ehCliente);
    jsonData['ehFornecedor'] = PessoaDomain.setEhFornecedor(ehFornecedor);
    jsonData['ehTransportadora'] = PessoaDomain.setEhTransportadora(ehTransportadora);
    jsonData['ehColaborador'] = PessoaDomain.setEhColaborador(ehColaborador);
    jsonData['ehContador'] = PessoaDomain.setEhContador(ehContador);
    jsonData['pessoaJuridicaModel'] = pessoaJuridicaModel?.toJson;
    jsonData['fornecedorModel'] = fornecedorModel?.toJson;
    jsonData['clienteModel'] = clienteModel?.toJson;
    jsonData['pessoaFisicaModel'] = pessoaFisicaModel?.toJson;
    jsonData['transportadoraModel'] = transportadoraModel?.toJson;
    jsonData['contadorModel'] = contadorModel?.toJson;
    
		var pessoaContatoModelLocalList = []; 
		for (PessoaContatoModel object in pessoaContatoModelList ?? []) { 
			pessoaContatoModelLocalList.add(object.toJson); 
		}
		jsonData['pessoaContatoModelList'] = pessoaContatoModelLocalList;
    
		var pessoaTelefoneModelLocalList = []; 
		for (PessoaTelefoneModel object in pessoaTelefoneModelList ?? []) { 
			pessoaTelefoneModelLocalList.add(object.toJson); 
		}
		jsonData['pessoaTelefoneModelList'] = pessoaTelefoneModelLocalList;
    
		var pessoaEnderecoModelLocalList = []; 
		for (PessoaEnderecoModel object in pessoaEnderecoModelList ?? []) { 
			pessoaEnderecoModelLocalList.add(object.toJson); 
		}
		jsonData['pessoaEnderecoModelList'] = pessoaEnderecoModelLocalList;

    return jsonData;
  }

  String objectEncodeJson() {
    final jsonData = toJson;
    return json.encode(jsonData);
  }

  static PessoaModel fromPlutoRow(PlutoRow row) {
    return PessoaModel(
      id: row.cells['id']?.value,
      nome: row.cells['nome']?.value,
      tipo: row.cells['tipo']?.value,
      site: row.cells['site']?.value,
      email: row.cells['email']?.value,
      ehCliente: row.cells['ehCliente']?.value,
      ehFornecedor: row.cells['ehFornecedor']?.value,
      ehTransportadora: row.cells['ehTransportadora']?.value,
      ehColaborador: row.cells['ehColaborador']?.value,
      ehContador: row.cells['ehContador']?.value,
    );
  }

  PlutoRow toPlutoRow() {
    return PlutoRow(
      cells: {
        'tempId': PlutoCell(value: tempId),
        'id': PlutoCell(value: id ?? 0),
        'nome': PlutoCell(value: nome ?? ''),
        'tipo': PlutoCell(value: tipo ?? ''),
        'site': PlutoCell(value: site ?? ''),
        'email': PlutoCell(value: email ?? ''),
        'ehCliente': PlutoCell(value: ehCliente ?? ''),
        'ehFornecedor': PlutoCell(value: ehFornecedor ?? ''),
        'ehTransportadora': PlutoCell(value: ehTransportadora ?? ''),
        'ehColaborador': PlutoCell(value: ehColaborador ?? ''),
        'ehContador': PlutoCell(value: ehContador ?? ''),
      },
    );
  }

  PessoaModel clone() {
    return PessoaModel(
      id: id,
      nome: nome,
      tipo: tipo,
      site: site,
      email: email,
      ehCliente: ehCliente,
      ehFornecedor: ehFornecedor,
      ehTransportadora: ehTransportadora,
      ehColaborador: ehColaborador,
      ehContador: ehContador,
      pessoaJuridicaModel: PessoaJuridicaModel.cloneFrom(pessoaJuridicaModel),
      fornecedorModel: FornecedorModel.cloneFrom(fornecedorModel),
      clienteModel: ClienteModel.cloneFrom(clienteModel),
      pessoaFisicaModel: PessoaFisicaModel.cloneFrom(pessoaFisicaModel),
      transportadoraModel: TransportadoraModel.cloneFrom(transportadoraModel),
      contadorModel: ContadorModel.cloneFrom(contadorModel),
      pessoaContatoModelList: pessoaContatoModelListClone(pessoaContatoModelList!),
      pessoaTelefoneModelList: pessoaTelefoneModelListClone(pessoaTelefoneModelList!),
      pessoaEnderecoModelList: pessoaEnderecoModelListClone(pessoaEnderecoModelList!),
    );
  }

  static PessoaModel cloneFrom(PessoaModel? model) {
    return PessoaModel(
      id: model?.id,
      nome: model?.nome,
      tipo: model?.tipo,
      site: model?.site,
      email: model?.email,
      ehCliente: model?.ehCliente,
      ehFornecedor: model?.ehFornecedor,
      ehTransportadora: model?.ehTransportadora,
      ehColaborador: model?.ehColaborador,
      ehContador: model?.ehContador,
      pessoaJuridicaModel: PessoaJuridicaModel.cloneFrom(model?.pessoaJuridicaModel),
      fornecedorModel: FornecedorModel.cloneFrom(model?.fornecedorModel),
      clienteModel: ClienteModel.cloneFrom(model?.clienteModel),
      pessoaFisicaModel: PessoaFisicaModel.cloneFrom(model?.pessoaFisicaModel),
      transportadoraModel: TransportadoraModel.cloneFrom(model?.transportadoraModel),
      contadorModel: ContadorModel.cloneFrom(model?.contadorModel),
    );
  }

  pessoaContatoModelListClone(List<PessoaContatoModel> pessoaContatoModelList) { 
		List<PessoaContatoModel> resultList = [];
		for (var pessoaContatoModel in pessoaContatoModelList) {
			resultList.add(PessoaContatoModel.cloneFrom(pessoaContatoModel));
		}
		return resultList;
	}

  pessoaTelefoneModelListClone(List<PessoaTelefoneModel> pessoaTelefoneModelList) { 
		List<PessoaTelefoneModel> resultList = [];
		for (var pessoaTelefoneModel in pessoaTelefoneModelList) {
			resultList.add(PessoaTelefoneModel.cloneFrom(pessoaTelefoneModel));
		}
		return resultList;
	}

  pessoaEnderecoModelListClone(List<PessoaEnderecoModel> pessoaEnderecoModelList) { 
		List<PessoaEnderecoModel> resultList = [];
		for (var pessoaEnderecoModel in pessoaEnderecoModelList) {
			resultList.add(PessoaEnderecoModel.cloneFrom(pessoaEnderecoModel));
		}
		return resultList;
	}


}