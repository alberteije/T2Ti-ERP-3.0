import 'dart:convert';
import 'package:pluto_grid/pluto_grid.dart';
import 'package:cadastros/app/data/model/model_imports.dart';

import 'package:cadastros/app/infra/infra_imports.dart';
import 'package:intl/intl.dart';

class ProdutoModel extends ModelBase {
  int? id;
  int? idProdutoSubgrupo;
  int? idProdutoMarca;
  int? idProdutoUnidade;
  int? idTributIcmsCustomCab;
  int? idTributGrupoTributario;
  String? nome;
  String? descricao;
  String? gtin;
  String? codigoInterno;
  double? valorCompra;
  double? valorVenda;
  String? codigoNcm;
  DateTime? dataCadastro;
  double? estoqueMinimo;
  double? estoqueMaximo;
  double? quantidadeEstoque;
  ProdutoMarcaModel? produtoMarcaModel;
  ProdutoUnidadeModel? produtoUnidadeModel;
  ProdutoSubgrupoModel? produtoSubgrupoModel;
  TributIcmsCustomCabModel? tributIcmsCustomCabModel;
  TributGrupoTributarioModel? tributGrupoTributarioModel;

  ProdutoModel({
    this.id,
    this.idProdutoSubgrupo,
    this.idProdutoMarca,
    this.idProdutoUnidade,
    this.idTributIcmsCustomCab,
    this.idTributGrupoTributario,
    this.nome,
    this.descricao,
    this.gtin,
    this.codigoInterno,
    this.valorCompra,
    this.valorVenda,
    this.codigoNcm,
    this.dataCadastro,
    this.estoqueMinimo,
    this.estoqueMaximo,
    this.quantidadeEstoque,
    ProdutoMarcaModel? produtoMarcaModel,
    ProdutoUnidadeModel? produtoUnidadeModel,
    ProdutoSubgrupoModel? produtoSubgrupoModel,
    TributIcmsCustomCabModel? tributIcmsCustomCabModel,
    TributGrupoTributarioModel? tributGrupoTributarioModel,
  }) {
    this.produtoMarcaModel = produtoMarcaModel ?? ProdutoMarcaModel();
    this.produtoUnidadeModel = produtoUnidadeModel ?? ProdutoUnidadeModel();
    this.produtoSubgrupoModel = produtoSubgrupoModel ?? ProdutoSubgrupoModel();
    this.tributIcmsCustomCabModel = tributIcmsCustomCabModel ?? TributIcmsCustomCabModel();
    this.tributGrupoTributarioModel = tributGrupoTributarioModel ?? TributGrupoTributarioModel();
  }

  static List<String> dbColumns = <String>[
    'id',
    'nome',
    'descricao',
    'gtin',
    'codigo_interno',
    'valor_compra',
    'valor_venda',
    'codigo_ncm',
    'data_cadastro',
    'estoque_minimo',
    'estoque_maximo',
    'quantidade_estoque',
  ];

  static List<String> aliasColumns = <String>[
    'Id',
    'Nome',
    'Descricao',
    'Gtin',
    'Codigo Interno',
    'Valor Compra',
    'Valor Venda',
    'Codigo Ncm',
    'Data Cadastro',
    'Estoque Minimo',
    'Estoque Maximo',
    'Quantidade Estoque',
  ];

  ProdutoModel.fromJson(Map<String, dynamic> jsonData) {
    id = jsonData['id'];
    idProdutoSubgrupo = jsonData['idProdutoSubgrupo'];
    idProdutoMarca = jsonData['idProdutoMarca'];
    idProdutoUnidade = jsonData['idProdutoUnidade'];
    idTributIcmsCustomCab = jsonData['idTributIcmsCustomCab'];
    idTributGrupoTributario = jsonData['idTributGrupoTributario'];
    nome = jsonData['nome'];
    descricao = jsonData['descricao'];
    gtin = jsonData['gtin'];
    codigoInterno = jsonData['codigoInterno'];
    valorCompra = jsonData['valorCompra']?.toDouble();
    valorVenda = jsonData['valorVenda']?.toDouble();
    codigoNcm = jsonData['codigoNcm'];
    dataCadastro = jsonData['dataCadastro'] != null ? DateTime.tryParse(jsonData['dataCadastro']) : null;
    estoqueMinimo = jsonData['estoqueMinimo']?.toDouble();
    estoqueMaximo = jsonData['estoqueMaximo']?.toDouble();
    quantidadeEstoque = jsonData['quantidadeEstoque']?.toDouble();
    produtoMarcaModel = jsonData['produtoMarcaModel'] == null ? ProdutoMarcaModel() : ProdutoMarcaModel.fromJson(jsonData['produtoMarcaModel']);
    produtoUnidadeModel = jsonData['produtoUnidadeModel'] == null ? ProdutoUnidadeModel() : ProdutoUnidadeModel.fromJson(jsonData['produtoUnidadeModel']);
    produtoSubgrupoModel = jsonData['produtoSubgrupoModel'] == null ? ProdutoSubgrupoModel() : ProdutoSubgrupoModel.fromJson(jsonData['produtoSubgrupoModel']);
    tributIcmsCustomCabModel = jsonData['tributIcmsCustomCabModel'] == null ? TributIcmsCustomCabModel() : TributIcmsCustomCabModel.fromJson(jsonData['tributIcmsCustomCabModel']);
    tributGrupoTributarioModel = jsonData['tributGrupoTributarioModel'] == null ? TributGrupoTributarioModel() : TributGrupoTributarioModel.fromJson(jsonData['tributGrupoTributarioModel']);
  }

  Map<String, dynamic> get toJson {
    Map<String, dynamic> jsonData = <String, dynamic>{};

    jsonData['id'] = id != 0 ? id : null;
    jsonData['idProdutoSubgrupo'] = idProdutoSubgrupo != 0 ? idProdutoSubgrupo : null;
    jsonData['idProdutoMarca'] = idProdutoMarca != 0 ? idProdutoMarca : null;
    jsonData['idProdutoUnidade'] = idProdutoUnidade != 0 ? idProdutoUnidade : null;
    jsonData['idTributIcmsCustomCab'] = idTributIcmsCustomCab != 0 ? idTributIcmsCustomCab : null;
    jsonData['idTributGrupoTributario'] = idTributGrupoTributario != 0 ? idTributGrupoTributario : null;
    jsonData['nome'] = nome;
    jsonData['descricao'] = descricao;
    jsonData['gtin'] = gtin;
    jsonData['codigoInterno'] = codigoInterno;
    jsonData['valorCompra'] = valorCompra;
    jsonData['valorVenda'] = valorVenda;
    jsonData['codigoNcm'] = codigoNcm;
    jsonData['dataCadastro'] = dataCadastro != null ? DateFormat('yyyy-MM-ddT00:00:00').format(dataCadastro!) : null;
    jsonData['estoqueMinimo'] = estoqueMinimo;
    jsonData['estoqueMaximo'] = estoqueMaximo;
    jsonData['quantidadeEstoque'] = quantidadeEstoque;
    jsonData['produtoMarcaModel'] = produtoMarcaModel?.toJson;
    jsonData['produtoMarca'] = produtoMarcaModel?.nome ?? '';
    jsonData['produtoUnidadeModel'] = produtoUnidadeModel?.toJson;
    jsonData['produtoUnidade'] = produtoUnidadeModel?.sigla ?? '';
    jsonData['produtoSubgrupoModel'] = produtoSubgrupoModel?.toJson;
    jsonData['produtoSubgrupo'] = produtoSubgrupoModel?.nome ?? '';
    jsonData['tributIcmsCustomCabModel'] = tributIcmsCustomCabModel?.toJson;
    jsonData['tributIcmsCustomCab'] = tributIcmsCustomCabModel?.descricao ?? '';
    jsonData['tributGrupoTributarioModel'] = tributGrupoTributarioModel?.toJson;
    jsonData['tributGrupoTributario'] = tributGrupoTributarioModel?.descricao ?? '';

    return jsonData;
  }

  String objectEncodeJson() {
    final jsonData = toJson;
    return json.encode(jsonData);
  }

  static ProdutoModel fromPlutoRow(PlutoRow row) {
    return ProdutoModel(
      id: row.cells['id']?.value,
      idProdutoSubgrupo: row.cells['idProdutoSubgrupo']?.value,
      idProdutoMarca: row.cells['idProdutoMarca']?.value,
      idProdutoUnidade: row.cells['idProdutoUnidade']?.value,
      idTributIcmsCustomCab: row.cells['idTributIcmsCustomCab']?.value,
      idTributGrupoTributario: row.cells['idTributGrupoTributario']?.value,
      nome: row.cells['nome']?.value,
      descricao: row.cells['descricao']?.value,
      gtin: row.cells['gtin']?.value,
      codigoInterno: row.cells['codigoInterno']?.value,
      valorCompra: row.cells['valorCompra']?.value,
      valorVenda: row.cells['valorVenda']?.value,
      codigoNcm: row.cells['codigoNcm']?.value,
      dataCadastro: Util.stringToDate(row.cells['dataCadastro']?.value),
      estoqueMinimo: row.cells['estoqueMinimo']?.value,
      estoqueMaximo: row.cells['estoqueMaximo']?.value,
      quantidadeEstoque: row.cells['quantidadeEstoque']?.value,
    );
  }

  PlutoRow toPlutoRow() {
    return PlutoRow(
      cells: {
        'tempId': PlutoCell(value: tempId),
        'id': PlutoCell(value: id ?? 0),
        'idProdutoSubgrupo': PlutoCell(value: idProdutoSubgrupo ?? 0),
        'idProdutoMarca': PlutoCell(value: idProdutoMarca ?? 0),
        'idProdutoUnidade': PlutoCell(value: idProdutoUnidade ?? 0),
        'idTributIcmsCustomCab': PlutoCell(value: idTributIcmsCustomCab ?? 0),
        'idTributGrupoTributario': PlutoCell(value: idTributGrupoTributario ?? 0),
        'nome': PlutoCell(value: nome ?? ''),
        'descricao': PlutoCell(value: descricao ?? ''),
        'gtin': PlutoCell(value: gtin ?? ''),
        'codigoInterno': PlutoCell(value: codigoInterno ?? ''),
        'valorCompra': PlutoCell(value: valorCompra ?? 0.0),
        'valorVenda': PlutoCell(value: valorVenda ?? 0.0),
        'codigoNcm': PlutoCell(value: codigoNcm ?? ''),
        'dataCadastro': PlutoCell(value: dataCadastro),
        'estoqueMinimo': PlutoCell(value: estoqueMinimo ?? 0.0),
        'estoqueMaximo': PlutoCell(value: estoqueMaximo ?? 0.0),
        'quantidadeEstoque': PlutoCell(value: quantidadeEstoque ?? 0.0),
        'produtoMarca': PlutoCell(value: produtoMarcaModel?.nome ?? ''),
        'produtoUnidade': PlutoCell(value: produtoUnidadeModel?.sigla ?? ''),
        'produtoSubgrupo': PlutoCell(value: produtoSubgrupoModel?.nome ?? ''),
        'tributIcmsCustomCab': PlutoCell(value: tributIcmsCustomCabModel?.descricao ?? ''),
        'tributGrupoTributario': PlutoCell(value: tributGrupoTributarioModel?.descricao ?? ''),
      },
    );
  }

  ProdutoModel clone() {
    return ProdutoModel(
      id: id,
      idProdutoSubgrupo: idProdutoSubgrupo,
      idProdutoMarca: idProdutoMarca,
      idProdutoUnidade: idProdutoUnidade,
      idTributIcmsCustomCab: idTributIcmsCustomCab,
      idTributGrupoTributario: idTributGrupoTributario,
      nome: nome,
      descricao: descricao,
      gtin: gtin,
      codigoInterno: codigoInterno,
      valorCompra: valorCompra,
      valorVenda: valorVenda,
      codigoNcm: codigoNcm,
      dataCadastro: dataCadastro,
      estoqueMinimo: estoqueMinimo,
      estoqueMaximo: estoqueMaximo,
      quantidadeEstoque: quantidadeEstoque,
      produtoMarcaModel: ProdutoMarcaModel.cloneFrom(produtoMarcaModel),
      produtoUnidadeModel: ProdutoUnidadeModel.cloneFrom(produtoUnidadeModel),
      produtoSubgrupoModel: ProdutoSubgrupoModel.cloneFrom(produtoSubgrupoModel),
      tributIcmsCustomCabModel: TributIcmsCustomCabModel.cloneFrom(tributIcmsCustomCabModel),
      tributGrupoTributarioModel: TributGrupoTributarioModel.cloneFrom(tributGrupoTributarioModel),
    );
  }

  static ProdutoModel cloneFrom(ProdutoModel? model) {
    return ProdutoModel(
      id: model?.id,
      idProdutoSubgrupo: model?.idProdutoSubgrupo,
      idProdutoMarca: model?.idProdutoMarca,
      idProdutoUnidade: model?.idProdutoUnidade,
      idTributIcmsCustomCab: model?.idTributIcmsCustomCab,
      idTributGrupoTributario: model?.idTributGrupoTributario,
      nome: model?.nome,
      descricao: model?.descricao,
      gtin: model?.gtin,
      codigoInterno: model?.codigoInterno,
      valorCompra: model?.valorCompra,
      valorVenda: model?.valorVenda,
      codigoNcm: model?.codigoNcm,
      dataCadastro: model?.dataCadastro,
      estoqueMinimo: model?.estoqueMinimo,
      estoqueMaximo: model?.estoqueMaximo,
      quantidadeEstoque: model?.quantidadeEstoque,
      produtoMarcaModel: ProdutoMarcaModel.cloneFrom(model?.produtoMarcaModel),
      produtoUnidadeModel: ProdutoUnidadeModel.cloneFrom(model?.produtoUnidadeModel),
      produtoSubgrupoModel: ProdutoSubgrupoModel.cloneFrom(model?.produtoSubgrupoModel),
      tributIcmsCustomCabModel: TributIcmsCustomCabModel.cloneFrom(model?.tributIcmsCustomCabModel),
      tributGrupoTributarioModel: TributGrupoTributarioModel.cloneFrom(model?.tributGrupoTributarioModel),
    );
  }


}