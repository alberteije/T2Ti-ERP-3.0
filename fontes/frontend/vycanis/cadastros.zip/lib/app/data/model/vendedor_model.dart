import 'dart:convert';
import 'package:pluto_grid/pluto_grid.dart';
import 'package:cadastros/app/data/model/model_imports.dart';


class VendedorModel extends ModelBase {
  int? id;
  int? idColaborador;
  int? idComissaoPerfil;
  double? comissao;
  double? metaVenda;
  ComissaoPerfilModel? comissaoPerfilModel;

  VendedorModel({
    this.id,
    this.idColaborador,
    this.idComissaoPerfil,
    this.comissao,
    this.metaVenda,
    ComissaoPerfilModel? comissaoPerfilModel,
  }) {
    this.comissaoPerfilModel = comissaoPerfilModel ?? ComissaoPerfilModel();
  }

  static List<String> dbColumns = <String>[
    'id',
    'comissao',
    'meta_venda',
  ];

  static List<String> aliasColumns = <String>[
    'Id',
    'Comissao',
    'Meta Venda',
  ];

  VendedorModel.fromJson(Map<String, dynamic> jsonData) {
    id = jsonData['id'];
    idColaborador = jsonData['idColaborador'];
    idComissaoPerfil = jsonData['idComissaoPerfil'];
    comissao = jsonData['comissao']?.toDouble();
    metaVenda = jsonData['metaVenda']?.toDouble();
    comissaoPerfilModel = jsonData['comissaoPerfilModel'] == null ? ComissaoPerfilModel() : ComissaoPerfilModel.fromJson(jsonData['comissaoPerfilModel']);
  }

  Map<String, dynamic> get toJson {
    Map<String, dynamic> jsonData = <String, dynamic>{};

    jsonData['id'] = id != 0 ? id : null;
    jsonData['idColaborador'] = idColaborador != 0 ? idColaborador : null;
    jsonData['idComissaoPerfil'] = idComissaoPerfil != 0 ? idComissaoPerfil : null;
    jsonData['comissao'] = comissao;
    jsonData['metaVenda'] = metaVenda;
    jsonData['comissaoPerfilModel'] = comissaoPerfilModel?.toJson;
    jsonData['comissaoPerfil'] = comissaoPerfilModel?.nome ?? '';

    return jsonData;
  }

  String objectEncodeJson() {
    final jsonData = toJson;
    return json.encode(jsonData);
  }

  static VendedorModel fromPlutoRow(PlutoRow row) {
    return VendedorModel(
      id: row.cells['id']?.value,
      idColaborador: row.cells['idColaborador']?.value,
      idComissaoPerfil: row.cells['idComissaoPerfil']?.value,
      comissao: row.cells['comissao']?.value,
      metaVenda: row.cells['metaVenda']?.value,
    );
  }

  PlutoRow toPlutoRow() {
    return PlutoRow(
      cells: {
        'tempId': PlutoCell(value: tempId),
        'id': PlutoCell(value: id ?? 0),
        'idColaborador': PlutoCell(value: idColaborador ?? 0),
        'idComissaoPerfil': PlutoCell(value: idComissaoPerfil ?? 0),
        'comissao': PlutoCell(value: comissao ?? 0.0),
        'metaVenda': PlutoCell(value: metaVenda ?? 0.0),
        'comissaoPerfil': PlutoCell(value: comissaoPerfilModel?.nome ?? ''),
      },
    );
  }

  VendedorModel clone() {
    return VendedorModel(
      id: id,
      idColaborador: idColaborador,
      idComissaoPerfil: idComissaoPerfil,
      comissao: comissao,
      metaVenda: metaVenda,
      comissaoPerfilModel: ComissaoPerfilModel.cloneFrom(comissaoPerfilModel),
    );
  }

  static VendedorModel cloneFrom(VendedorModel? model) {
    return VendedorModel(
      id: model?.id,
      idColaborador: model?.idColaborador,
      idComissaoPerfil: model?.idComissaoPerfil,
      comissao: model?.comissao,
      metaVenda: model?.metaVenda,
      comissaoPerfilModel: ComissaoPerfilModel.cloneFrom(model?.comissaoPerfilModel),
    );
  }


}