import 'dart:convert';
import 'package:pluto_grid/pluto_grid.dart';
import 'package:cadastros/app/data/model/model_imports.dart';

import 'package:cadastros/app/infra/infra_imports.dart';
import 'package:intl/intl.dart';
import 'package:cadastros/app/data/domain/domain_imports.dart';

class PessoaJuridicaModel extends ModelBase {
  int? id;
  int? idPessoa;
  String? cnpj;
  String? nomeFantasia;
  String? inscricaoEstadual;
  String? inscricaoMunicipal;
  DateTime? dataConstituicao;
  String? tipoRegime;
  String? crt;

  PessoaJuridicaModel({
    this.id,
    this.idPessoa,
    this.cnpj,
    this.nomeFantasia,
    this.inscricaoEstadual,
    this.inscricaoMunicipal,
    this.dataConstituicao,
    this.tipoRegime = '1-Lucro Real',
    this.crt = '1-Simples Nacional',
  });

  static List<String> dbColumns = <String>[
    'id',
    'cnpj',
    'nome_fantasia',
    'inscricao_estadual',
    'inscricao_municipal',
    'data_constituicao',
    'tipo_regime',
    'crt',
  ];

  static List<String> aliasColumns = <String>[
    'Id',
    'Cnpj',
    'Nome Fantasia',
    'Inscricao Estadual',
    'Inscricao Municipal',
    'Data Constituicao',
    'Tipo Regime',
    'Crt',
  ];

  PessoaJuridicaModel.fromJson(Map<String, dynamic> jsonData) {
    id = jsonData['id'];
    idPessoa = jsonData['idPessoa'];
    cnpj = jsonData['cnpj'];
    nomeFantasia = jsonData['nomeFantasia'];
    inscricaoEstadual = jsonData['inscricaoEstadual'];
    inscricaoMunicipal = jsonData['inscricaoMunicipal'];
    dataConstituicao = jsonData['dataConstituicao'] != null ? DateTime.tryParse(jsonData['dataConstituicao']) : null;
    tipoRegime = PessoaJuridicaDomain.getTipoRegime(jsonData['tipoRegime']);
    crt = PessoaJuridicaDomain.getCrt(jsonData['crt']);
  }

  Map<String, dynamic> get toJson {
    Map<String, dynamic> jsonData = <String, dynamic>{};

    jsonData['id'] = id != 0 ? id : null;
    jsonData['idPessoa'] = idPessoa != 0 ? idPessoa : null;
    jsonData['cnpj'] = Util.removeMask(cnpj);
    jsonData['nomeFantasia'] = nomeFantasia;
    jsonData['inscricaoEstadual'] = inscricaoEstadual;
    jsonData['inscricaoMunicipal'] = inscricaoMunicipal;
    jsonData['dataConstituicao'] = dataConstituicao != null ? DateFormat('yyyy-MM-ddT00:00:00').format(dataConstituicao!) : null;
    jsonData['tipoRegime'] = PessoaJuridicaDomain.setTipoRegime(tipoRegime);
    jsonData['crt'] = PessoaJuridicaDomain.setCrt(crt);

    return jsonData;
  }

  String objectEncodeJson() {
    final jsonData = toJson;
    return json.encode(jsonData);
  }

  static PessoaJuridicaModel fromPlutoRow(PlutoRow row) {
    return PessoaJuridicaModel(
      id: row.cells['id']?.value,
      idPessoa: row.cells['idPessoa']?.value,
      cnpj: row.cells['cnpj']?.value,
      nomeFantasia: row.cells['nomeFantasia']?.value,
      inscricaoEstadual: row.cells['inscricaoEstadual']?.value,
      inscricaoMunicipal: row.cells['inscricaoMunicipal']?.value,
      dataConstituicao: Util.stringToDate(row.cells['dataConstituicao']?.value),
      tipoRegime: row.cells['tipoRegime']?.value,
      crt: row.cells['crt']?.value,
    );
  }

  PlutoRow toPlutoRow() {
    return PlutoRow(
      cells: {
        'tempId': PlutoCell(value: tempId),
        'id': PlutoCell(value: id ?? 0),
        'idPessoa': PlutoCell(value: idPessoa ?? 0),
        'cnpj': PlutoCell(value: cnpj ?? ''),
        'nomeFantasia': PlutoCell(value: nomeFantasia ?? ''),
        'inscricaoEstadual': PlutoCell(value: inscricaoEstadual ?? ''),
        'inscricaoMunicipal': PlutoCell(value: inscricaoMunicipal ?? ''),
        'dataConstituicao': PlutoCell(value: dataConstituicao),
        'tipoRegime': PlutoCell(value: tipoRegime ?? ''),
        'crt': PlutoCell(value: crt ?? ''),
      },
    );
  }

  PessoaJuridicaModel clone() {
    return PessoaJuridicaModel(
      id: id,
      idPessoa: idPessoa,
      cnpj: cnpj,
      nomeFantasia: nomeFantasia,
      inscricaoEstadual: inscricaoEstadual,
      inscricaoMunicipal: inscricaoMunicipal,
      dataConstituicao: dataConstituicao,
      tipoRegime: tipoRegime,
      crt: crt,
    );
  }

  static PessoaJuridicaModel cloneFrom(PessoaJuridicaModel? model) {
    return PessoaJuridicaModel(
      id: model?.id,
      idPessoa: model?.idPessoa,
      cnpj: model?.cnpj,
      nomeFantasia: model?.nomeFantasia,
      inscricaoEstadual: model?.inscricaoEstadual,
      inscricaoMunicipal: model?.inscricaoMunicipal,
      dataConstituicao: model?.dataConstituicao,
      tipoRegime: model?.tipoRegime,
      crt: model?.crt,
    );
  }


}