import 'dart:convert';
import 'package:pluto_grid/pluto_grid.dart';
import 'package:cadastros/app/data/model/model_imports.dart';

import 'package:cadastros/app/infra/infra_imports.dart';
import 'package:intl/intl.dart';

class ClienteModel extends ModelBase {
  int? id;
  int? idPessoa;
  int? idTabelaPreco;
  DateTime? desde;
  DateTime? dataCadastro;
  double? taxaDesconto;
  double? limiteCredito;
  String? observacao;
  TabelaPrecoModel? tabelaPrecoModel;

  ClienteModel({
    this.id,
    this.idPessoa,
    this.idTabelaPreco,
    this.desde,
    this.dataCadastro,
    this.taxaDesconto,
    this.limiteCredito,
    this.observacao,
    TabelaPrecoModel? tabelaPrecoModel,
  }) {
    this.tabelaPrecoModel = tabelaPrecoModel ?? TabelaPrecoModel();
  }

  static List<String> dbColumns = <String>[
    'id',
    'desde',
    'data_cadastro',
    'taxa_desconto',
    'limite_credito',
    'observacao',
  ];

  static List<String> aliasColumns = <String>[
    'Id',
    'Desde',
    'Data Cadastro',
    'Taxa Desconto',
    'Limite Credito',
    'Observacao',
  ];

  ClienteModel.fromJson(Map<String, dynamic> jsonData) {
    id = jsonData['id'];
    idPessoa = jsonData['idPessoa'];
    idTabelaPreco = jsonData['idTabelaPreco'];
    desde = jsonData['desde'] != null ? DateTime.tryParse(jsonData['desde']) : null;
    dataCadastro = jsonData['dataCadastro'] != null ? DateTime.tryParse(jsonData['dataCadastro']) : null;
    taxaDesconto = jsonData['taxaDesconto']?.toDouble();
    limiteCredito = jsonData['limiteCredito']?.toDouble();
    observacao = jsonData['observacao'];
    tabelaPrecoModel = jsonData['tabelaPrecoModel'] == null ? TabelaPrecoModel() : TabelaPrecoModel.fromJson(jsonData['tabelaPrecoModel']);
  }

  Map<String, dynamic> get toJson {
    Map<String, dynamic> jsonData = <String, dynamic>{};

    jsonData['id'] = id != 0 ? id : null;
    jsonData['idPessoa'] = idPessoa != 0 ? idPessoa : null;
    jsonData['idTabelaPreco'] = idTabelaPreco != 0 ? idTabelaPreco : null;
    jsonData['desde'] = desde != null ? DateFormat('yyyy-MM-ddT00:00:00').format(desde!) : null;
    jsonData['dataCadastro'] = dataCadastro != null ? DateFormat('yyyy-MM-ddT00:00:00').format(dataCadastro!) : null;
    jsonData['taxaDesconto'] = taxaDesconto;
    jsonData['limiteCredito'] = limiteCredito;
    jsonData['observacao'] = observacao;
    jsonData['tabelaPrecoModel'] = tabelaPrecoModel?.toJson;
    jsonData['tabelaPreco'] = tabelaPrecoModel?.nome ?? '';

    return jsonData;
  }

  String objectEncodeJson() {
    final jsonData = toJson;
    return json.encode(jsonData);
  }

  static ClienteModel fromPlutoRow(PlutoRow row) {
    return ClienteModel(
      id: row.cells['id']?.value,
      idPessoa: row.cells['idPessoa']?.value,
      idTabelaPreco: row.cells['idTabelaPreco']?.value,
      desde: Util.stringToDate(row.cells['desde']?.value),
      dataCadastro: Util.stringToDate(row.cells['dataCadastro']?.value),
      taxaDesconto: row.cells['taxaDesconto']?.value,
      limiteCredito: row.cells['limiteCredito']?.value,
      observacao: row.cells['observacao']?.value,
    );
  }

  PlutoRow toPlutoRow() {
    return PlutoRow(
      cells: {
        'tempId': PlutoCell(value: tempId),
        'id': PlutoCell(value: id ?? 0),
        'idPessoa': PlutoCell(value: idPessoa ?? 0),
        'idTabelaPreco': PlutoCell(value: idTabelaPreco ?? 0),
        'desde': PlutoCell(value: desde),
        'dataCadastro': PlutoCell(value: dataCadastro),
        'taxaDesconto': PlutoCell(value: taxaDesconto ?? 0.0),
        'limiteCredito': PlutoCell(value: limiteCredito ?? 0.0),
        'observacao': PlutoCell(value: observacao ?? ''),
        'tabelaPreco': PlutoCell(value: tabelaPrecoModel?.nome ?? ''),
      },
    );
  }

  ClienteModel clone() {
    return ClienteModel(
      id: id,
      idPessoa: idPessoa,
      idTabelaPreco: idTabelaPreco,
      desde: desde,
      dataCadastro: dataCadastro,
      taxaDesconto: taxaDesconto,
      limiteCredito: limiteCredito,
      observacao: observacao,
      tabelaPrecoModel: TabelaPrecoModel.cloneFrom(tabelaPrecoModel),
    );
  }

  static ClienteModel cloneFrom(ClienteModel? model) {
    return ClienteModel(
      id: model?.id,
      idPessoa: model?.idPessoa,
      idTabelaPreco: model?.idTabelaPreco,
      desde: model?.desde,
      dataCadastro: model?.dataCadastro,
      taxaDesconto: model?.taxaDesconto,
      limiteCredito: model?.limiteCredito,
      observacao: model?.observacao,
      tabelaPrecoModel: TabelaPrecoModel.cloneFrom(model?.tabelaPrecoModel),
    );
  }


}