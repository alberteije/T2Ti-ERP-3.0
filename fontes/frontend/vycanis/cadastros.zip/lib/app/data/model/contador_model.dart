import 'dart:convert';
import 'package:pluto_grid/pluto_grid.dart';
import 'package:cadastros/app/data/model/model_imports.dart';

import 'package:cadastros/app/data/domain/domain_imports.dart';

class ContadorModel extends ModelBase {
  int? id;
  int? idPessoa;
  String? crcInscricao;
  String? crcUf;

  ContadorModel({
    this.id,
    this.idPessoa,
    this.crcInscricao,
    this.crcUf = 'AC',
  });

  static List<String> dbColumns = <String>[
    'id',
    'crc_inscricao',
    'crc_uf',
  ];

  static List<String> aliasColumns = <String>[
    'Id',
    'Crc Inscricao',
    'Crc Uf',
  ];

  ContadorModel.fromJson(Map<String, dynamic> jsonData) {
    id = jsonData['id'];
    idPessoa = jsonData['idPessoa'];
    crcInscricao = jsonData['crcInscricao'];
    crcUf = ContadorDomain.getCrcUf(jsonData['crcUf']);
  }

  Map<String, dynamic> get toJson {
    Map<String, dynamic> jsonData = <String, dynamic>{};

    jsonData['id'] = id != 0 ? id : null;
    jsonData['idPessoa'] = idPessoa != 0 ? idPessoa : null;
    jsonData['crcInscricao'] = crcInscricao;
    jsonData['crcUf'] = ContadorDomain.setCrcUf(crcUf);

    return jsonData;
  }

  String objectEncodeJson() {
    final jsonData = toJson;
    return json.encode(jsonData);
  }

  static ContadorModel fromPlutoRow(PlutoRow row) {
    return ContadorModel(
      id: row.cells['id']?.value,
      idPessoa: row.cells['idPessoa']?.value,
      crcInscricao: row.cells['crcInscricao']?.value,
      crcUf: row.cells['crcUf']?.value,
    );
  }

  PlutoRow toPlutoRow() {
    return PlutoRow(
      cells: {
        'tempId': PlutoCell(value: tempId),
        'id': PlutoCell(value: id ?? 0),
        'idPessoa': PlutoCell(value: idPessoa ?? 0),
        'crcInscricao': PlutoCell(value: crcInscricao ?? ''),
        'crcUf': PlutoCell(value: crcUf ?? ''),
      },
    );
  }

  ContadorModel clone() {
    return ContadorModel(
      id: id,
      idPessoa: idPessoa,
      crcInscricao: crcInscricao,
      crcUf: crcUf,
    );
  }

  static ContadorModel cloneFrom(ContadorModel? model) {
    return ContadorModel(
      id: model?.id,
      idPessoa: model?.idPessoa,
      crcInscricao: model?.crcInscricao,
      crcUf: model?.crcUf,
    );
  }


}