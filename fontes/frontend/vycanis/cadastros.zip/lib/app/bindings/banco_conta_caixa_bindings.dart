import 'package:get/get.dart';
import 'package:cadastros/app/controller/banco_conta_caixa_controller.dart';
import 'package:cadastros/app/data/provider/api/banco_conta_caixa_api_provider.dart';
import 'package:cadastros/app/data/provider/drift/banco_conta_caixa_drift_provider.dart';
import 'package:cadastros/app/data/repository/banco_conta_caixa_repository.dart';

class BancoContaCaixaBindings implements Binding {
	@override
	List<Bind> dependencies() {
		return [
			Bind.lazyPut<BancoContaCaixaController>(() => BancoContaCaixaController(
					repository: BancoContaCaixaRepository(bancoContaCaixaApiProvider: BancoContaCaixaApiProvider(), bancoContaCaixaDriftProvider: BancoContaCaixaDriftProvider()))),
		];
	}
}
