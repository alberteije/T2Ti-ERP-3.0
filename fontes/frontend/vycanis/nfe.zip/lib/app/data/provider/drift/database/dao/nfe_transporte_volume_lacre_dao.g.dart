// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'nfe_transporte_volume_lacre_dao.dart';

// ignore_for_file: type=lint
mixin _$NfeTransporteVolumeLacreDaoMixin on DatabaseAccessor<AppDatabase> {
  $NfeTransporteVolumeLacresTable get nfeTransporteVolumeLacres =>
      attachedDatabase.nfeTransporteVolumeLacres;
  $NfeTransporteVolumesTable get nfeTransporteVolumes =>
      attachedDatabase.nfeTransporteVolumes;
}
