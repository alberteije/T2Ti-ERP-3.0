// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'nfe_cana_fornecimento_diario_dao.dart';

// ignore_for_file: type=lint
mixin _$NfeCanaFornecimentoDiarioDaoMixin on DatabaseAccessor<AppDatabase> {
  $NfeCanaFornecimentoDiariosTable get nfeCanaFornecimentoDiarios =>
      attachedDatabase.nfeCanaFornecimentoDiarios;
  $NfeCanasTable get nfeCanas => attachedDatabase.nfeCanas;
}
