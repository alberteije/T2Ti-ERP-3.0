// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'nfe_fatura_dao.dart';

// ignore_for_file: type=lint
mixin _$NfeFaturaDaoMixin on DatabaseAccessor<AppDatabase> {
  $NfeFaturasTable get nfeFaturas => attachedDatabase.nfeFaturas;
  $NfeDuplicatasTable get nfeDuplicatas => attachedDatabase.nfeDuplicatas;
}
