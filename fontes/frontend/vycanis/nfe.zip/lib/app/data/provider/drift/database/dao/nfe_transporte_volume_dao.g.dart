// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'nfe_transporte_volume_dao.dart';

// ignore_for_file: type=lint
mixin _$NfeTransporteVolumeDaoMixin on DatabaseAccessor<AppDatabase> {
  $NfeTransporteVolumesTable get nfeTransporteVolumes =>
      attachedDatabase.nfeTransporteVolumes;
  $NfeTransportesTable get nfeTransportes => attachedDatabase.nfeTransportes;
  $NfeTransporteVolumeLacresTable get nfeTransporteVolumeLacres =>
      attachedDatabase.nfeTransporteVolumeLacres;
}
