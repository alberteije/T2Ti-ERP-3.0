// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'venda_cabecalho_dao.dart';

// ignore_for_file: type=lint
mixin _$VendaCabecalhoDaoMixin on DatabaseAccessor<AppDatabase> {
  $VendaCabecalhosTable get vendaCabecalhos => attachedDatabase.vendaCabecalhos;
}
