// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'nfe_numero_dao.dart';

// ignore_for_file: type=lint
mixin _$NfeNumeroDaoMixin on DatabaseAccessor<AppDatabase> {
  $NfeNumerosTable get nfeNumeros => attachedDatabase.nfeNumeros;
}
