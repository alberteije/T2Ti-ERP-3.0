// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'nfe_transporte_dao.dart';

// ignore_for_file: type=lint
mixin _$NfeTransporteDaoMixin on DatabaseAccessor<AppDatabase> {
  $NfeTransportesTable get nfeTransportes => attachedDatabase.nfeTransportes;
  $NfeTransporteReboquesTable get nfeTransporteReboques =>
      attachedDatabase.nfeTransporteReboques;
}
