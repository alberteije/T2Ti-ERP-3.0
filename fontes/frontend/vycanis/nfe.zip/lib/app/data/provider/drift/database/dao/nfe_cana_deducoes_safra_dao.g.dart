// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'nfe_cana_deducoes_safra_dao.dart';

// ignore_for_file: type=lint
mixin _$NfeCanaDeducoesSafraDaoMixin on DatabaseAccessor<AppDatabase> {
  $NfeCanaDeducoesSafrasTable get nfeCanaDeducoesSafras =>
      attachedDatabase.nfeCanaDeducoesSafras;
  $NfeCanasTable get nfeCanas => attachedDatabase.nfeCanas;
}
