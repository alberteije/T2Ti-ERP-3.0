// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'nfe_det_especifico_combustivel_dao.dart';

// ignore_for_file: type=lint
mixin _$NfeDetEspecificoCombustivelDaoMixin on DatabaseAccessor<AppDatabase> {
  $NfeDetEspecificoCombustivelsTable get nfeDetEspecificoCombustivels =>
      attachedDatabase.nfeDetEspecificoCombustivels;
  $NfeDetCombustivelOrigemsTable get nfeDetCombustivelOrigems =>
      attachedDatabase.nfeDetCombustivelOrigems;
}
