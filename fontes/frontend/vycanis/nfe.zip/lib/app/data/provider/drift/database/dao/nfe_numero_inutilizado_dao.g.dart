// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'nfe_numero_inutilizado_dao.dart';

// ignore_for_file: type=lint
mixin _$NfeNumeroInutilizadoDaoMixin on DatabaseAccessor<AppDatabase> {
  $NfeNumeroInutilizadosTable get nfeNumeroInutilizados =>
      attachedDatabase.nfeNumeroInutilizados;
}
