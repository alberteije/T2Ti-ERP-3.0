// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'nfe_cana_dao.dart';

// ignore_for_file: type=lint
mixin _$NfeCanaDaoMixin on DatabaseAccessor<AppDatabase> {
  $NfeCanasTable get nfeCanas => attachedDatabase.nfeCanas;
  $NfeCanaFornecimentoDiariosTable get nfeCanaFornecimentoDiarios =>
      attachedDatabase.nfeCanaFornecimentoDiarios;
  $NfeCanaDeducoesSafrasTable get nfeCanaDeducoesSafras =>
      attachedDatabase.nfeCanaDeducoesSafras;
}
