class NfeCanaFornecimentoDiarioDomain {
	NfeCanaFornecimentoDiarioDomain._();

	static getDia(String? dia) { 
		switch (dia) { 
			case '': 
			case '0': 
				return 'AAA'; 
			case '1': 
				return 'BBB'; 
			case '2': 
				return 'CCC'; 
			default: 
				return null; 
		} 
	} 

	static setDia(String? dia) { 
		switch (dia) { 
			case 'AAA': 
				return '0'; 
			case 'BBB': 
				return '1'; 
			case 'CCC': 
				return '2'; 
			default: 
				return null; 
		} 
	}

}