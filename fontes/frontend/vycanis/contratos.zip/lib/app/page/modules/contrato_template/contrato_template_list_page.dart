import 'package:flutter/material.dart';
import 'package:contratos/app/controller/contrato_template_controller.dart';
import 'package:contratos/app/page/shared_page/list_page_base.dart';

class ContratoTemplateListPage extends ListPageBase<ContratoTemplateController> {
  const ContratoTemplateListPage({Key? key}) : super(key: key);

  @override
  List<Map<String, dynamic>> get mobileItems => controller.mobileItems;

  @override
  Map<String, dynamic> get mobileConfig => controller.mobileConfig;

  @override
  String get standardFieldForFilter => controller.standardFieldForFilter;
}