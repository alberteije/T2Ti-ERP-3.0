import 'package:flutter/material.dart';
import 'package:contratos/app/controller/contrato_solicitacao_servico_controller.dart';
import 'package:contratos/app/page/shared_page/list_page_base.dart';

class ContratoSolicitacaoServicoListPage extends ListPageBase<ContratoSolicitacaoServicoController> {
  const ContratoSolicitacaoServicoListPage({Key? key}) : super(key: key);

  @override
  List<Map<String, dynamic>> get mobileItems => controller.mobileItems;

  @override
  Map<String, dynamic> get mobileConfig => controller.mobileConfig;

  @override
  String get standardFieldForFilter => controller.standardFieldForFilter;
}