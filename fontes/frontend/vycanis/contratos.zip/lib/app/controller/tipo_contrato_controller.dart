import 'package:flutter/material.dart';
import 'package:get/get.dart';

import 'package:contratos/app/page/shared_widget/message_dialog.dart';
import 'package:contratos/app/page/grid_columns/grid_columns_imports.dart';
import 'package:contratos/app/routes/app_routes.dart';
import 'package:contratos/app/controller/controller_imports.dart';
import 'package:contratos/app/data/model/model_imports.dart';
import 'package:contratos/app/data/repository/tipo_contrato_repository.dart';

class TipoContratoController extends ControllerBase<TipoContratoModel, TipoContratoRepository> {

  TipoContratoController({required super.repository}) {
    dbColumns = TipoContratoModel.dbColumns;
    aliasColumns = TipoContratoModel.aliasColumns;
    gridColumns = tipoContratoGridColumns();
    functionName = "tipo_contrato";
    screenTitle = "Tipo de Contrato";
  }

  @override
  TipoContratoModel createNewModel() => TipoContratoModel();

  @override
  final standardFieldForFilter = TipoContratoModel.aliasColumns[TipoContratoModel.dbColumns.indexOf('nome')];

  final nomeController = TextEditingController();
  final descricaoController = TextEditingController();

  final Map<String, dynamic> mobileConfig = {
    'primaryColumns': ['nome'],
    'secondaryColumns': ['descricao'],
  };

  List<Map<String, dynamic>> get mobileItems {
    return modelList.map((tipoContrato) => tipoContrato.toJson).toList();
  }

  @override
  void prepareForInsert() {
    isNewRecord = true;
    currentModel = createNewModel();
    _resetForm();
    Get.toNamed(Routes.tipoContratoEditPage);
  }

  void _resetForm() {
    formWasChanged = false;
    nomeController.text = '';
    descricaoController.text = '';
  }

  @override
  void selectRowForEditingById(int id) {
    final model = modelList.firstWhere((m) => m.id == id);
    currentModel = model.clone();
    updateControllersFromModel();
    Get.toNamed(Routes.tipoContratoEditPage);
  }

  void updateControllersFromModel() {
    nomeController.text = currentModel.nome ?? '';
    descricaoController.text = currentModel.descricao ?? '';
    formWasChanged = false;
  }

  @override
  Future<void> save() async {
    if (!formKey.currentState!.validate()) {
      showErrorSnackBar(message: 'validator_form_message'.tr);
      return;
    }

    final existingIndex = modelList.indexWhere((m) => m.id == currentModel.id);

    if (existingIndex >= 0) {
      modelList[existingIndex] = currentModel.clone();
    }

    final result = await repository.save(tipoContratoModel: currentModel);
    if (result == null) return;

    if (existingIndex >= 0) {
      modelList[existingIndex] = result;
    } else {
      modelList.insert(0, result);
    }

    if (!GetPlatform.isMobile) {
      updateGridRow(result);
    }

    Get.back(result: true);
  }


  @override
  void onClose() {
    nomeController.dispose();
    descricaoController.dispose();
    super.onClose();
  }

}