import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:pluto_grid/pluto_grid.dart';
import 'package:extended_masked_text/extended_masked_text.dart';
import 'package:contratos/app/page/shared_widget/input/input_imports.dart';

import 'package:contratos/app/page/page_imports.dart';
import 'package:contratos/app/page/shared_widget/message_dialog.dart';
import 'package:contratos/app/page/grid_columns/grid_columns_imports.dart';
import 'package:contratos/app/controller/controller_imports.dart';
import 'package:contratos/app/data/model/model_imports.dart';

class ContratoHistoricoReajusteController extends ControllerBase<ContratoHistoricoReajusteModel, void> {

  ContratoHistoricoReajusteController() : super(repository: null) {
    dbColumns = ContratoHistoricoReajusteModel.dbColumns;
    aliasColumns = ContratoHistoricoReajusteModel.aliasColumns;
    gridColumns = contratoHistoricoReajusteGridColumns();
    functionName = "contrato_historico_reajuste";
    screenTitle = "Histórico de Reajustes";
  }

  final _contratoHistoricoReajusteModel = ContratoHistoricoReajusteModel().obs;
  ContratoHistoricoReajusteModel get contratoHistoricoReajusteModel => _contratoHistoricoReajusteModel.value;
  set contratoHistoricoReajusteModel(value) => _contratoHistoricoReajusteModel.value = value ?? ContratoHistoricoReajusteModel();

  List<ContratoHistoricoReajusteModel> get contratoHistoricoReajusteModelList => Get.find<ContratoController>().currentModel.contratoHistoricoReajusteModelList ?? [];

  final _userMadeChanges = false.obs;
  get userMadeChanges => _userMadeChanges.value;
  set userMadeChanges(value) => _userMadeChanges.value = value;

  final _formWasChangedDetail = false.obs;
  bool get formWasChangedDetail => _formWasChangedDetail.value;
  set formWasChangedDetail(value) => _formWasChangedDetail.value = value;

  late PlutoGridStateManager _plutoGridStateManager;
  @override
  PlutoGridStateManager get plutoGridStateManager => _plutoGridStateManager;
  @override
  set plutoGridStateManager(value) => _plutoGridStateManager = value;

  final contratoHistoricoReajusteScaffoldKey = GlobalKey<ScaffoldState>();
  final contratoHistoricoReajusteFormKey = GlobalKey<FormState>();

  @override
  ContratoHistoricoReajusteModel createNewModel() => ContratoHistoricoReajusteModel();

  @override
  final standardFieldForFilter = ContratoHistoricoReajusteModel.aliasColumns[ContratoHistoricoReajusteModel.dbColumns.indexOf('indice')];

  final indiceController = MoneyMaskedTextController();
  final valorAnteriorController = MoneyMaskedTextController();
  final valorAtualController = MoneyMaskedTextController();
  final dataReajusteController = DatePickerItemController(null);
  final observacaoController = TextEditingController();

  final Map<String, dynamic> mobileConfig = {
    'primaryColumns': ['indice'],
    'secondaryColumns': ['valor_anterior'],
  };

  List<Map<String, dynamic>> get mobileItems {
    return modelList.map((contratoHistoricoReajuste) => contratoHistoricoReajuste.toJson).toList();
  }

  @override
  List<PlutoRow> plutoRows() => List<PlutoRow>.from(contratoHistoricoReajusteModelList.map((model) => model.toPlutoRow()));

  @override
  Future<void> getList({Filter? filter}) async {}

  @override
  void prepareForInsert() {
    isNewRecord = true;
    contratoHistoricoReajusteModel = createNewModel();
    _resetForm();
    Get.to(() => ContratoHistoricoReajusteEditPage());
  }

  void _resetForm() {
    formWasChangedDetail = false;
    indiceController.updateValue(0);
    valorAnteriorController.updateValue(0);
    valorAtualController.updateValue(0);
    dataReajusteController.date = null;
    observacaoController.text = '';
  }

  @override
  void selectRowForEditing(PlutoRow? row) async {
    if (row == null) {
      showInfoSnackBar(message: 'message_select_one_to_edited'.tr);
      return;
    }

    selectRowForEditingByTempId(row.cells['tempId']?.value);
  }

  @override
  void selectRowForEditingById(int id) {}

  void selectRowForEditingByTempId(String tempId) {
		isNewRecord = false;
    final model = contratoHistoricoReajusteModelList.firstWhere((m) => m.tempId == tempId);
    contratoHistoricoReajusteModel = model.clone();
		contratoHistoricoReajusteModel.tempId = model.tempId;
    updateControllersFromModel();
    Get.to(() => ContratoHistoricoReajusteEditPage());
  }

  void updateControllersFromModel() {
    indiceController.updateValue(contratoHistoricoReajusteModel.indice ?? 0);
    valorAnteriorController.updateValue(contratoHistoricoReajusteModel.valorAnterior ?? 0);
    valorAtualController.updateValue(contratoHistoricoReajusteModel.valorAtual ?? 0);
    dataReajusteController.date = contratoHistoricoReajusteModel.dataReajuste;
    observacaoController.text = contratoHistoricoReajusteModel.observacao ?? '';
    formWasChangedDetail = false;
  }

  @override
  Future<void> save() async {
    if (!contratoHistoricoReajusteFormKey.currentState!.validate()) {
      showErrorSnackBar(message: 'validator_form_message'.tr);
      return;
    }

    if (formWasChangedDetail) {
      if (isNewRecord) {
        contratoHistoricoReajusteModelList.insert(0, contratoHistoricoReajusteModel.clone());
      } else {
        final index = contratoHistoricoReajusteModelList.indexWhere((m) => m.tempId == contratoHistoricoReajusteModel.tempId);
        if (index >= 0) {
          contratoHistoricoReajusteModelList[index] = contratoHistoricoReajusteModel.clone();
        }
      }

      userMadeChanges = true;
      loadData();
      Get.back(result: true);
    } else {
      Get.back();
    }
  }


  @override
  Future deleteSelected() async {
    final currentRow = plutoGridStateManager.currentRow;
    if (currentRow == null) {
      showInfoSnackBar(message: 'message_select_one_to_delete'.tr);
      return null;
    }
    showDeleteDialog(() async {
      final id = currentRow.cells['id']?.value;
      final tempId = currentRow.cells['tempId']?.value;
      contratoHistoricoReajusteModelList.removeWhere((model) => (id != 0 && model.id == id) || (id == 0 && model.tempId == tempId));
      plutoGridStateManager.removeCurrentRow();
      userMadeChanges = true;
    });
  }

  @override
  void preventDataLoss() {
    if (formWasChangedDetail) {
      showQuestionDialog('message_data_loss'.tr, () => Get.back());
    } else {
      formWasChangedDetail = false;
      Get.back();
    }
  }

  @override
  void onClose() {
    indiceController.dispose();
    valorAnteriorController.dispose();
    valorAtualController.dispose();
    dataReajusteController.dispose();
    observacaoController.dispose();
  }

}