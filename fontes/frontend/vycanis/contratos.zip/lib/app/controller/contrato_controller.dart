import 'dart:convert';
import 'dart:io';

import 'package:archive/archive.dart';
import 'package:flutter/material.dart';
import 'dart:math';
import 'package:get/get.dart';
import 'package:extended_masked_text/extended_masked_text.dart';
import 'package:contratos/app/page/shared_widget/input/input_imports.dart';

import 'package:contratos/app/infra/infra_imports.dart';
import 'package:contratos/app/page/page_imports.dart';
import 'package:contratos/app/page/shared_widget/message_dialog.dart';
import 'package:contratos/app/page/grid_columns/grid_columns_imports.dart';
import 'package:contratos/app/routes/app_routes.dart';
import 'package:contratos/app/controller/controller_imports.dart';
import 'package:contratos/app/data/model/model_imports.dart';
import 'package:contratos/app/data/repository/contrato_repository.dart';
import 'package:open_filex/open_filex.dart';

class ContratoController extends ControllerBase<ContratoModel, ContratoRepository> 
with GetSingleTickerProviderStateMixin {

  ContratoController({required super.repository}) {
    dbColumns = ContratoModel.dbColumns;
    aliasColumns = ContratoModel.aliasColumns;
    gridColumns = contratoGridColumns();
    functionName = "contrato";
    screenTitle = "Contrato";
  }

  final contratoScaffoldKey = GlobalKey<ScaffoldState>();
  final contratoTabPageScaffoldKey = GlobalKey<ScaffoldState>();
  final contratoFormKey = GlobalKey<FormState>();
  late TabController tabController;
  String? mandatoryMessage;  

  @override
  ContratoModel createNewModel() => ContratoModel();

  @override
  final standardFieldForFilter = ContratoModel.aliasColumns[ContratoModel.dbColumns.indexOf('numero')];

  final contratoSolicitacaoServicoModelController = TextEditingController();
  final tipoContratoModelController = TextEditingController();
  final numeroController = TextEditingController();
  final nomeController = TextEditingController();
  final descricaoController = TextEditingController();
  final dataCadastroController = DatePickerItemController(null);
  final dataInicioVigenciaController = DatePickerItemController(null);
  final dataFimVigenciaController = DatePickerItemController(null);
  final diaFaturamentoController = TextEditingController();
  final valorController = MoneyMaskedTextController();
  final quantidadeParcelasController = MoneyMaskedTextController(precision: 0, decimalSeparator: '', thousandSeparator: '');
  final intervaloEntreParcelasController = MoneyMaskedTextController(precision: 0, decimalSeparator: '', thousandSeparator: '');
  final classificacaoContabilContaController = TextEditingController();
  final observacaoController = TextEditingController();

  final Map<String, dynamic> mobileConfig = {
    'primaryColumns': ['numero'],
    'secondaryColumns': ['nome'],
  };

  List<Map<String, dynamic>> get mobileItems {
    return modelList.map((contrato) => contrato.toJson).toList();
  }

  @override
  void prepareForInsert() {
    isNewRecord = true;
    currentModel = createNewModel();
    _resetForm();
    tabController.animateTo(0);
    updateControllersFromModel();
    Get.toNamed(Routes.contratoTabPage);
  }

  void _resetForm() {
    formWasChanged = false;
    contratoSolicitacaoServicoModelController.text = '';
    tipoContratoModelController.text = '';
    numeroController.text = '';
    nomeController.text = '';
    descricaoController.text = '';
    dataCadastroController.date = null;
    dataInicioVigenciaController.date = null;
    dataFimVigenciaController.date = null;
    diaFaturamentoController.text = '';
    valorController.updateValue(0);
    quantidadeParcelasController.updateValue(0);
    intervaloEntreParcelasController.updateValue(0);
    classificacaoContabilContaController.text = '';
    observacaoController.text = '';
  }

  @override
  void selectRowForEditingById(int id) {
    final model = modelList.firstWhere((m) => m.id == id);
    currentModel = model.clone();
    updateControllersFromModel();
    tabController.animateTo(0);
    Get.toNamed(Routes.contratoTabPage);
  }

  _configureChildrenControllers() {
    //Histórico de Reajustes
		Get.put<ContratoHistoricoReajusteController>(ContratoHistoricoReajusteController()); 

    //Previsão de Faturamento
		Get.put<ContratoPrevFaturamentoController>(ContratoPrevFaturamentoController()); 

    //Histórico de Faturamento
		Get.put<ContratoHistFaturamentoController>(ContratoHistFaturamentoController()); 

  }
	
	_releaseChildrenControllers() {
    //Histórico de Reajustes
		Get.delete<ContratoHistoricoReajusteController>(); 

    //Previsão de Faturamento
		Get.delete<ContratoPrevFaturamentoController>(); 

    //Histórico de Faturamento
		Get.delete<ContratoHistFaturamentoController>(); 

	}
  
  void updateControllersFromModel() {
    contratoSolicitacaoServicoModelController.text = currentModel.contratoSolicitacaoServicoModel?.descricao?.toString() ?? '';
    tipoContratoModelController.text = currentModel.tipoContratoModel?.nome?.toString() ?? '';
    numeroController.text = currentModel.numero ?? '';
    nomeController.text = currentModel.nome ?? '';
    descricaoController.text = currentModel.descricao ?? '';
    dataCadastroController.date = currentModel.dataCadastro;
    dataInicioVigenciaController.date = currentModel.dataInicioVigencia;
    dataFimVigenciaController.date = currentModel.dataFimVigencia;
    diaFaturamentoController.text = currentModel.diaFaturamento ?? '';
    valorController.updateValue(currentModel.valor ?? 0);
    quantidadeParcelasController.updateValue((currentModel.quantidadeParcelas ?? 0).toDouble());
    intervaloEntreParcelasController.updateValue((currentModel.intervaloEntreParcelas ?? 0).toDouble());
    classificacaoContabilContaController.text = currentModel.classificacaoContabilConta ?? '';
    observacaoController.text = currentModel.observacao ?? '';

    formWasChanged = false;
    _updateChildrenControllersFromModel();
  }

  void _updateChildrenControllersFromModel() {
    //Histórico de Reajustes
		final contratoHistoricoReajusteController = Get.find<ContratoHistoricoReajusteController>(); 
		contratoHistoricoReajusteController.userMadeChanges = false; 

    //Previsão de Faturamento
		final contratoPrevFaturamentoController = Get.find<ContratoPrevFaturamentoController>(); 
		contratoPrevFaturamentoController.userMadeChanges = false; 

    //Histórico de Faturamento
		final contratoHistFaturamentoController = Get.find<ContratoHistFaturamentoController>(); 
		contratoHistFaturamentoController.userMadeChanges = false; 

  }

  @override
  Future<void> save() async {
    if (!validateCurrentForm()) return;
    if (validateForms()) {
      if (userMadeChanges()) {
        final existingIndex = modelList.indexWhere((m) => m.id == currentModel.id);

        if (existingIndex >= 0) {
          modelList[existingIndex] = currentModel.clone();
        }

        final result = await repository.save(contratoModel: currentModel);
        if (result == null) return;

        if (existingIndex >= 0) {
          modelList[existingIndex] = result;
        } else {
          modelList.insert(0, result);
        }

        if (!GetPlatform.isMobile) {
          updateGridRow(result);
        }

        Get.back(result: true);
      } else {
        Get.back();
      }
    } 
  }

  Future callContratoSolicitacaoServicoLookup() async { 
		final lookupController = Get.find<LookupController>(); 
		lookupController.refreshItems(standardValue: '%'); 
		lookupController.title = '${'lookup_page_title'.tr} [Solicitacao Servico]'; 
		lookupController.route = '/contrato-solicitacao-servico/'; 
		lookupController.gridColumns = contratoSolicitacaoServicoGridColumns(isForLookup: true); 
		lookupController.aliasColumns = ContratoSolicitacaoServicoModel.aliasColumns; 
		lookupController.dbColumns = ContratoSolicitacaoServicoModel.dbColumns; 
		lookupController.standardColumn = ContratoSolicitacaoServicoModel.aliasColumns[ContratoSolicitacaoServicoModel.dbColumns.indexOf('descricao')]; 

		final plutoRowResult = await Get.toNamed(Routes.lookupPage); 
		if (plutoRowResult != null) { 
			currentModel.idSolicitacaoServico = plutoRowResult.cells['id']!.value; 
			currentModel.contratoSolicitacaoServicoModel = ContratoSolicitacaoServicoModel.fromPlutoRow(plutoRowResult); 
			contratoSolicitacaoServicoModelController.text = currentModel.contratoSolicitacaoServicoModel?.descricao ?? ''; 
			formWasChanged = true; 
		}
	}

  Future callTipoContratoLookup() async { 
		final lookupController = Get.find<LookupController>(); 
		lookupController.refreshItems(standardValue: '%'); 
		lookupController.title = '${'lookup_page_title'.tr} [Tipo Contrato]'; 
		lookupController.route = '/tipo-contrato/'; 
		lookupController.gridColumns = tipoContratoGridColumns(isForLookup: true); 
		lookupController.aliasColumns = TipoContratoModel.aliasColumns; 
		lookupController.dbColumns = TipoContratoModel.dbColumns; 
		lookupController.standardColumn = TipoContratoModel.aliasColumns[TipoContratoModel.dbColumns.indexOf('nome')]; 

		final plutoRowResult = await Get.toNamed(Routes.lookupPage); 
		if (plutoRowResult != null) { 
			currentModel.idTipoContrato = plutoRowResult.cells['id']!.value; 
			currentModel.tipoContratoModel = TipoContratoModel.fromPlutoRow(plutoRowResult); 
			tipoContratoModelController.text = currentModel.tipoContratoModel?.nome ?? ''; 
			formWasChanged = true; 
		}
	}


  List<Tab> tabItems = [
    Tab( 
			icon: Icon(iconDataList[Random().nextInt(10)]), 
			text: 'Contrato', 
		),
    Tab( 
			icon: Icon(iconDataList[Random().nextInt(10)]), 
			text: 'Histórico de Reajustes', 
		),
    Tab( 
			icon: Icon(iconDataList[Random().nextInt(10)]), 
			text: 'Previsão de Faturamento', 
		),
    Tab( 
			icon: Icon(iconDataList[Random().nextInt(10)]), 
			text: 'Histórico de Faturamento', 
		),
  ];

  List<Widget> tabPages() {
    return [
      ContratoEditPage(),
      const ContratoHistoricoReajusteListPage(),
      const ContratoPrevFaturamentoListPage(),
      const ContratoHistFaturamentoListPage(),
    ];
  }

  @override
  void preventDataLoss() {
    if (userMadeChanges()) {
      showQuestionDialog('message_data_loss'.tr, () { 
        Get.back(); 
      });
    } else {
      Get.back();
    }
  }  

  bool userMadeChanges() {
    return
    formWasChanged 
    || 
		Get.find<ContratoHistoricoReajusteController>().userMadeChanges
    || 
		Get.find<ContratoPrevFaturamentoController>().userMadeChanges
    || 
		Get.find<ContratoHistFaturamentoController>().userMadeChanges
    ;
  }

  void tabChange(int index) {
    validateCurrentForm();
  }

  bool validateCurrentForm() {
    mandatoryMessage = ValidateFormField.validateMandatory(currentModel.contratoSolicitacaoServicoModel?.descricao); 
		if (mandatoryMessage != null) { 
			tabController.animateTo(0); 
			showErrorSnackBar(message: '$mandatoryMessage [Solicitacao Servico]'); 
			return false; 
		}
    mandatoryMessage = ValidateFormField.validateMandatory(currentModel.tipoContratoModel?.nome); 
		if (mandatoryMessage != null) { 
			tabController.animateTo(0); 
			showErrorSnackBar(message: '$mandatoryMessage [Tipo Contrato]'); 
			return false; 
		}
    return true;
  }

  bool validateForms() {
    return true;
  }


  Future<void> gerarContrato() async {
    const templatePath = r'C:\t2ti\contratos\templates\1.docx'; // TODO: deixe o usuário selecionar o template
    final numeroContrato = (currentModel.numero ?? '${currentModel.id}').replaceAll('/', '-');
    final outDir = Directory(r'C:\t2ti\contratos\contratos');
    await outDir.create(recursive: true);
    final outputPath = '${outDir.path}\\$numeroContrato.docx';

    final r = <String, String>{
      '{{NOME_FORNECEDOR}}': currentModel.contratoSolicitacaoServicoModel?.viewPessoaFornecedorModel?.nome ?? '',
      '{{CNPJ_FORNECEDOR}}': currentModel.contratoSolicitacaoServicoModel?.viewPessoaFornecedorModel?.cpfCnpj ?? '',
      '{{ENDERECO_FORNECEDOR}}': currentModel.contratoSolicitacaoServicoModel?.viewPessoaFornecedorModel?.observacao ?? '',
      '{{NOME_CLIENTE}}': currentModel.contratoSolicitacaoServicoModel?.viewPessoaClienteModel?.nome ?? '',
      '{{CNPJ_CLIENTE}}': currentModel.contratoSolicitacaoServicoModel?.viewPessoaClienteModel?.cpfCnpj ?? '',
      '{{ENDERECO_CLIENTE}}': currentModel.contratoSolicitacaoServicoModel?.viewPessoaClienteModel?.observacao ?? '',
      '{{VALOR_CONTRATO}}': Util.decimalFormat(currentModel.valor),
      '{{PRAZO_CONTRATO}}': '${Util.formatDate(currentModel.dataInicioVigencia)} a ${Util.formatDate(currentModel.dataFimVigencia)}',
      '{{PRAZO_AVISO_PREVIO}}': '30',
      '{{CIDADE_FORO}}': 'São Paulo',
      '{{CIDADE_ASSINATURA}}': 'São Paulo',
      '{{DATA_ASSINATURA}}': Util.formatDate(currentModel.dataCadastro),
    };

    // Lê e decodifica o .docx (zip)
    final inputBytes = await File(templatePath).readAsBytes();
    final inZip = ZipDecoder().decodeBytes(inputBytes);

    // Cria novo zip de saída (evita modificar lista interna do archive)
    final outZip = Archive();

    for (final f in inZip) {
      if (!f.isFile) {
        // Pastas/dirs
        outZip.addFile(ArchiveFile.noCompress(f.name, 0, const []));
        continue;
      }

      final name = f.name;
      final contentBytes = f.content as List<int>;

      bool isDocXml = name == 'word/document.xml';
      bool isHeader = name.startsWith('word/header') && name.endsWith('.xml');
      bool isFooter = name.startsWith('word/footer') && name.endsWith('.xml');

      if (isDocXml || isHeader || isFooter) {
        var xml = utf8.decode(contentBytes);
        r.forEach((k, v) {
          xml = xml.replaceAll(k, Util.escapeXml(v));
        });
        final newBytes = utf8.encode(xml);
        outZip.addFile(ArchiveFile(name, newBytes.length, newBytes));
      } else {
        outZip.addFile(ArchiveFile(name, contentBytes.length, contentBytes));
      }
    }

    // Re-empacota como .docx
    final encoded = ZipEncoder().encode(outZip);
    await File(outputPath).writeAsBytes(encoded);

    // Abre no app padrão do Windows (Word/LibreOffice)
    await OpenFilex.open(outputPath);
  }

  @override
  void onInit() {
    super.onInit();
    tabController = TabController(vsync: this, length: tabItems.length);
    _configureChildrenControllers();
  }

  @override
  void onClose() {
    tabController.dispose();
    contratoSolicitacaoServicoModelController.dispose();
    tipoContratoModelController.dispose();
    numeroController.dispose();
    nomeController.dispose();
    descricaoController.dispose();
    dataCadastroController.dispose();
    dataInicioVigenciaController.dispose();
    dataFimVigenciaController.dispose();
    diaFaturamentoController.dispose();
    valorController.dispose();
    quantidadeParcelasController.dispose();
    intervaloEntreParcelasController.dispose();
    classificacaoContabilContaController.dispose();
    observacaoController.dispose();
    _releaseChildrenControllers();
    super.onClose();
  }
}