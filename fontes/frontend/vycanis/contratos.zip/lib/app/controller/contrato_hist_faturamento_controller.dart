import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:pluto_grid/pluto_grid.dart';
import 'package:extended_masked_text/extended_masked_text.dart';
import 'package:contratos/app/page/shared_widget/input/input_imports.dart';

import 'package:contratos/app/page/page_imports.dart';
import 'package:contratos/app/page/shared_widget/message_dialog.dart';
import 'package:contratos/app/page/grid_columns/grid_columns_imports.dart';
import 'package:contratos/app/controller/controller_imports.dart';
import 'package:contratos/app/data/model/model_imports.dart';

class ContratoHistFaturamentoController extends ControllerBase<ContratoHistFaturamentoModel, void> {

  ContratoHistFaturamentoController() : super(repository: null) {
    dbColumns = ContratoHistFaturamentoModel.dbColumns;
    aliasColumns = ContratoHistFaturamentoModel.aliasColumns;
    gridColumns = contratoHistFaturamentoGridColumns();
    functionName = "contrato_hist_faturamento";
    screenTitle = "Histórico de Faturamento";
  }

  final _contratoHistFaturamentoModel = ContratoHistFaturamentoModel().obs;
  ContratoHistFaturamentoModel get contratoHistFaturamentoModel => _contratoHistFaturamentoModel.value;
  set contratoHistFaturamentoModel(value) => _contratoHistFaturamentoModel.value = value ?? ContratoHistFaturamentoModel();

  List<ContratoHistFaturamentoModel> get contratoHistFaturamentoModelList => Get.find<ContratoController>().currentModel.contratoHistFaturamentoModelList ?? [];

  final _userMadeChanges = false.obs;
  get userMadeChanges => _userMadeChanges.value;
  set userMadeChanges(value) => _userMadeChanges.value = value;

  final _formWasChangedDetail = false.obs;
  bool get formWasChangedDetail => _formWasChangedDetail.value;
  set formWasChangedDetail(value) => _formWasChangedDetail.value = value;

  late PlutoGridStateManager _plutoGridStateManager;
  @override
  PlutoGridStateManager get plutoGridStateManager => _plutoGridStateManager;
  @override
  set plutoGridStateManager(value) => _plutoGridStateManager = value;

  final contratoHistFaturamentoScaffoldKey = GlobalKey<ScaffoldState>();
  final contratoHistFaturamentoFormKey = GlobalKey<FormState>();

  @override
  ContratoHistFaturamentoModel createNewModel() => ContratoHistFaturamentoModel();

  @override
  final standardFieldForFilter = ContratoHistFaturamentoModel.aliasColumns[ContratoHistFaturamentoModel.dbColumns.indexOf('data_fatura')];

  final dataFaturaController = DatePickerItemController(null);
  final valorController = MoneyMaskedTextController();

  final Map<String, dynamic> mobileConfig = {
    'primaryColumns': ['data_fatura'],
    'secondaryColumns': ['valor'],
  };

  List<Map<String, dynamic>> get mobileItems {
    return modelList.map((contratoHistFaturamento) => contratoHistFaturamento.toJson).toList();
  }

  @override
  List<PlutoRow> plutoRows() => List<PlutoRow>.from(contratoHistFaturamentoModelList.map((model) => model.toPlutoRow()));

  @override
  Future<void> getList({Filter? filter}) async {}

  @override
  void prepareForInsert() {
    isNewRecord = true;
    contratoHistFaturamentoModel = createNewModel();
    _resetForm();
    Get.to(() => ContratoHistFaturamentoEditPage());
  }

  void _resetForm() {
    formWasChangedDetail = false;
    dataFaturaController.date = null;
    valorController.updateValue(0);
  }

  @override
  void selectRowForEditing(PlutoRow? row) async {
    if (row == null) {
      showInfoSnackBar(message: 'message_select_one_to_edited'.tr);
      return;
    }

    selectRowForEditingByTempId(row.cells['tempId']?.value);
  }

  @override
  void selectRowForEditingById(int id) {}

  void selectRowForEditingByTempId(String tempId) {
		isNewRecord = false;
    final model = contratoHistFaturamentoModelList.firstWhere((m) => m.tempId == tempId);
    contratoHistFaturamentoModel = model.clone();
		contratoHistFaturamentoModel.tempId = model.tempId;
    updateControllersFromModel();
    Get.to(() => ContratoHistFaturamentoEditPage());
  }

  void updateControllersFromModel() {
    dataFaturaController.date = contratoHistFaturamentoModel.dataFatura;
    valorController.updateValue(contratoHistFaturamentoModel.valor ?? 0);
    formWasChangedDetail = false;
  }

  @override
  Future<void> save() async {
    if (!contratoHistFaturamentoFormKey.currentState!.validate()) {
      showErrorSnackBar(message: 'validator_form_message'.tr);
      return;
    }

    if (formWasChangedDetail) {
      if (isNewRecord) {
        contratoHistFaturamentoModelList.insert(0, contratoHistFaturamentoModel.clone());
      } else {
        final index = contratoHistFaturamentoModelList.indexWhere((m) => m.tempId == contratoHistFaturamentoModel.tempId);
        if (index >= 0) {
          contratoHistFaturamentoModelList[index] = contratoHistFaturamentoModel.clone();
        }
      }

      userMadeChanges = true;
      loadData();
      Get.back(result: true);
    } else {
      Get.back();
    }
  }


  @override
  Future deleteSelected() async {
    final currentRow = plutoGridStateManager.currentRow;
    if (currentRow == null) {
      showInfoSnackBar(message: 'message_select_one_to_delete'.tr);
      return null;
    }
    showDeleteDialog(() async {
      final id = currentRow.cells['id']?.value;
      final tempId = currentRow.cells['tempId']?.value;
      contratoHistFaturamentoModelList.removeWhere((model) => (id != 0 && model.id == id) || (id == 0 && model.tempId == tempId));
      plutoGridStateManager.removeCurrentRow();
      userMadeChanges = true;
    });
  }

  @override
  void preventDataLoss() {
    if (formWasChangedDetail) {
      showQuestionDialog('message_data_loss'.tr, () => Get.back());
    } else {
      formWasChangedDetail = false;
      Get.back();
    }
  }

  @override
  void onClose() {
    dataFaturaController.dispose();
    valorController.dispose();
  }

}