import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:contratos/app/page/shared_widget/input/input_imports.dart';

import 'package:contratos/app/page/shared_widget/message_dialog.dart';
import 'package:contratos/app/page/grid_columns/grid_columns_imports.dart';
import 'package:contratos/app/routes/app_routes.dart';
import 'package:contratos/app/controller/controller_imports.dart';
import 'package:contratos/app/data/model/model_imports.dart';
import 'package:contratos/app/data/repository/contrato_solicitacao_servico_repository.dart';

class ContratoSolicitacaoServicoController extends ControllerBase<ContratoSolicitacaoServicoModel, ContratoSolicitacaoServicoRepository> {

  ContratoSolicitacaoServicoController({required super.repository}) {
    dbColumns = ContratoSolicitacaoServicoModel.dbColumns;
    aliasColumns = ContratoSolicitacaoServicoModel.aliasColumns;
    gridColumns = contratoSolicitacaoServicoGridColumns();
    functionName = "contrato_solicitacao_servico";
    screenTitle = "Solicitação de Serviço";
  }

  @override
  ContratoSolicitacaoServicoModel createNewModel() => ContratoSolicitacaoServicoModel();

  @override
  final standardFieldForFilter = ContratoSolicitacaoServicoModel.aliasColumns[ContratoSolicitacaoServicoModel.dbColumns.indexOf('data_solicitacao')];

  final contratoTipoServicoModelController = TextEditingController();
  final setorModelController = TextEditingController();
  final viewPessoaColaboradorModelController = TextEditingController();
  final viewPessoaClienteModelController = TextEditingController();
  final viewPessoaFornecedorModelController = TextEditingController();
  final dataSolicitacaoController = DatePickerItemController(null);
  final dataDesejadaInicioController = DatePickerItemController(null);
  final urgenteController = CustomDropdownButtonController('S');
  final statusSolicitacaoController = CustomDropdownButtonController('Aguardando');
  final descricaoController = TextEditingController();

  final Map<String, dynamic> mobileConfig = {
    'primaryColumns': ['data_solicitacao'],
    'secondaryColumns': ['data_desejada_inicio'],
  };

  List<Map<String, dynamic>> get mobileItems {
    return modelList.map((contratoSolicitacaoServico) => contratoSolicitacaoServico.toJson).toList();
  }

  @override
  void prepareForInsert() {
    isNewRecord = true;
    currentModel = createNewModel();
    _resetForm();
    Get.toNamed(Routes.contratoSolicitacaoServicoEditPage);
  }

  void _resetForm() {
    formWasChanged = false;
    contratoTipoServicoModelController.text = '';
    setorModelController.text = '';
    viewPessoaColaboradorModelController.text = '';
    viewPessoaClienteModelController.text = '';
    viewPessoaFornecedorModelController.text = '';
    dataSolicitacaoController.date = null;
    dataDesejadaInicioController.date = null;
    urgenteController.selected = 'S';
    statusSolicitacaoController.selected = 'Aguardando';
    descricaoController.text = '';
  }

  @override
  void selectRowForEditingById(int id) {
    final model = modelList.firstWhere((m) => m.id == id);
    currentModel = model.clone();
    updateControllersFromModel();
    Get.toNamed(Routes.contratoSolicitacaoServicoEditPage);
  }

  void updateControllersFromModel() {
    contratoTipoServicoModelController.text = currentModel.contratoTipoServicoModel?.nome?.toString() ?? '';
    setorModelController.text = currentModel.setorModel?.nome?.toString() ?? '';
    viewPessoaColaboradorModelController.text = currentModel.viewPessoaColaboradorModel?.nome?.toString() ?? '';
    viewPessoaClienteModelController.text = currentModel.viewPessoaClienteModel?.nome?.toString() ?? '';
    viewPessoaFornecedorModelController.text = currentModel.viewPessoaFornecedorModel?.nome?.toString() ?? '';
    dataSolicitacaoController.date = currentModel.dataSolicitacao;
    dataDesejadaInicioController.date = currentModel.dataDesejadaInicio;
    urgenteController.selected = currentModel.urgente ?? 'S';
    statusSolicitacaoController.selected = currentModel.statusSolicitacao ?? 'Aguardando';
    descricaoController.text = currentModel.descricao ?? '';
    formWasChanged = false;
  }

  @override
  Future<void> save() async {
    if (!formKey.currentState!.validate()) {
      showErrorSnackBar(message: 'validator_form_message'.tr);
      return;
    }

    final existingIndex = modelList.indexWhere((m) => m.id == currentModel.id);

    if (existingIndex >= 0) {
      modelList[existingIndex] = currentModel.clone();
    }

    final result = await repository.save(contratoSolicitacaoServicoModel: currentModel);
    if (result == null) return;

    if (existingIndex >= 0) {
      modelList[existingIndex] = result;
    } else {
      modelList.insert(0, result);
    }

    if (!GetPlatform.isMobile) {
      updateGridRow(result);
    }

    Get.back(result: true);
  }

  Future callContratoTipoServicoLookup() async { 
		final lookupController = Get.find<LookupController>(); 
		lookupController.refreshItems(standardValue: '%'); 
		lookupController.title = '${'lookup_page_title'.tr} [Tipo Servico]'; 
		lookupController.route = '/contrato-tipo-servico/'; 
		lookupController.gridColumns = contratoTipoServicoGridColumns(isForLookup: true); 
		lookupController.aliasColumns = ContratoTipoServicoModel.aliasColumns; 
		lookupController.dbColumns = ContratoTipoServicoModel.dbColumns; 
		lookupController.standardColumn = ContratoTipoServicoModel.aliasColumns[ContratoTipoServicoModel.dbColumns.indexOf('nome')]; 

		final plutoRowResult = await Get.toNamed(Routes.lookupPage); 
		if (plutoRowResult != null) { 
			currentModel.idContratoTipoServico = plutoRowResult.cells['id']!.value; 
			currentModel.contratoTipoServicoModel = ContratoTipoServicoModel.fromPlutoRow(plutoRowResult); 
			contratoTipoServicoModelController.text = currentModel.contratoTipoServicoModel?.nome ?? ''; 
			formWasChanged = true; 
		}
	}

  Future callSetorLookup() async { 
		final lookupController = Get.find<LookupController>(); 
		lookupController.refreshItems(standardValue: '%'); 
		lookupController.title = '${'lookup_page_title'.tr} [Setor]'; 
		lookupController.route = '/setor/'; 
		lookupController.gridColumns = setorGridColumns(isForLookup: true); 
		lookupController.aliasColumns = SetorModel.aliasColumns; 
		lookupController.dbColumns = SetorModel.dbColumns; 
		lookupController.standardColumn = SetorModel.aliasColumns[SetorModel.dbColumns.indexOf('nome')]; 

		final plutoRowResult = await Get.toNamed(Routes.lookupPage); 
		if (plutoRowResult != null) { 
			currentModel.idSetor = plutoRowResult.cells['id']!.value; 
			currentModel.setorModel = SetorModel.fromPlutoRow(plutoRowResult); 
			setorModelController.text = currentModel.setorModel?.nome ?? ''; 
			formWasChanged = true; 
		}
	}

  Future callViewPessoaColaboradorLookup() async { 
		final lookupController = Get.find<LookupController>(); 
		lookupController.refreshItems(standardValue: '%'); 
		lookupController.title = '${'lookup_page_title'.tr} [Colaborador]'; 
		lookupController.route = '/view-pessoa-colaborador/'; 
		lookupController.gridColumns = viewPessoaColaboradorGridColumns(isForLookup: true); 
		lookupController.aliasColumns = ViewPessoaColaboradorModel.aliasColumns; 
		lookupController.dbColumns = ViewPessoaColaboradorModel.dbColumns; 
		lookupController.standardColumn = ViewPessoaColaboradorModel.aliasColumns[ViewPessoaColaboradorModel.dbColumns.indexOf('nome')]; 

		final plutoRowResult = await Get.toNamed(Routes.lookupPage); 
		if (plutoRowResult != null) { 
			currentModel.idColaborador = plutoRowResult.cells['id']!.value; 
			currentModel.viewPessoaColaboradorModel = ViewPessoaColaboradorModel.fromPlutoRow(plutoRowResult); 
			viewPessoaColaboradorModelController.text = currentModel.viewPessoaColaboradorModel?.nome ?? ''; 
			formWasChanged = true; 
		}
	}

  Future callViewPessoaClienteLookup() async { 
		final lookupController = Get.find<LookupController>(); 
		lookupController.refreshItems(standardValue: '%'); 
		lookupController.title = '${'lookup_page_title'.tr} [Cliente]'; 
		lookupController.route = '/view-pessoa-cliente/'; 
		lookupController.gridColumns = viewPessoaClienteGridColumns(isForLookup: true); 
		lookupController.aliasColumns = ViewPessoaClienteModel.aliasColumns; 
		lookupController.dbColumns = ViewPessoaClienteModel.dbColumns; 
		lookupController.standardColumn = ViewPessoaClienteModel.aliasColumns[ViewPessoaClienteModel.dbColumns.indexOf('nome')]; 

		final plutoRowResult = await Get.toNamed(Routes.lookupPage); 
		if (plutoRowResult != null) { 
			currentModel.idCliente = plutoRowResult.cells['id']!.value; 
			currentModel.viewPessoaClienteModel = ViewPessoaClienteModel.fromPlutoRow(plutoRowResult); 
			viewPessoaClienteModelController.text = currentModel.viewPessoaClienteModel?.nome ?? ''; 
			formWasChanged = true; 
		}
	}

  Future callViewPessoaFornecedorLookup() async { 
		final lookupController = Get.find<LookupController>(); 
		lookupController.refreshItems(standardValue: '%'); 
		lookupController.title = '${'lookup_page_title'.tr} [Fornecedor]'; 
		lookupController.route = '/view-pessoa-fornecedor/'; 
		lookupController.gridColumns = viewPessoaFornecedorGridColumns(isForLookup: true); 
		lookupController.aliasColumns = ViewPessoaFornecedorModel.aliasColumns; 
		lookupController.dbColumns = ViewPessoaFornecedorModel.dbColumns; 
		lookupController.standardColumn = ViewPessoaFornecedorModel.aliasColumns[ViewPessoaFornecedorModel.dbColumns.indexOf('nome')]; 

		final plutoRowResult = await Get.toNamed(Routes.lookupPage); 
		if (plutoRowResult != null) { 
			currentModel.idFornecedor = plutoRowResult.cells['id']!.value; 
			currentModel.viewPessoaFornecedorModel = ViewPessoaFornecedorModel.fromPlutoRow(plutoRowResult); 
			viewPessoaFornecedorModelController.text = currentModel.viewPessoaFornecedorModel?.nome ?? ''; 
			formWasChanged = true; 
		}
	}


  @override
  void onClose() {
    contratoTipoServicoModelController.dispose();
    setorModelController.dispose();
    viewPessoaColaboradorModelController.dispose();
    viewPessoaClienteModelController.dispose();
    viewPessoaFornecedorModelController.dispose();
    dataSolicitacaoController.dispose();
    dataDesejadaInicioController.dispose();
    urgenteController.dispose();
    statusSolicitacaoController.dispose();
    descricaoController.dispose();
    super.onClose();
  }

}