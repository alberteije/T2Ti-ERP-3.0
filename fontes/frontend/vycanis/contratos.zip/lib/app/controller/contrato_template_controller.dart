import 'dart:io';

import 'package:flutter/material.dart';
import 'package:get/get.dart';

import 'package:contratos/app/page/shared_widget/message_dialog.dart';
import 'package:contratos/app/page/grid_columns/grid_columns_imports.dart';
import 'package:contratos/app/routes/app_routes.dart';
import 'package:contratos/app/controller/controller_imports.dart';
import 'package:contratos/app/data/model/model_imports.dart';
import 'package:contratos/app/data/repository/contrato_template_repository.dart';
import 'package:open_filex/open_filex.dart';

class ContratoTemplateController extends ControllerBase<ContratoTemplateModel, ContratoTemplateRepository> {

  ContratoTemplateController({required super.repository}) {
    dbColumns = ContratoTemplateModel.dbColumns;
    aliasColumns = ContratoTemplateModel.aliasColumns;
    gridColumns = contratoTemplateGridColumns();
    functionName = "contrato_template";
    screenTitle = "Template";
  }

  @override
  ContratoTemplateModel createNewModel() => ContratoTemplateModel();

  @override
  final standardFieldForFilter = ContratoTemplateModel.aliasColumns[ContratoTemplateModel.dbColumns.indexOf('nome')];

  final nomeController = TextEditingController();
  final descricaoController = TextEditingController();

  final Map<String, dynamic> mobileConfig = {
    'primaryColumns': ['nome'],
    'secondaryColumns': ['descricao'],
  };

  List<Map<String, dynamic>> get mobileItems {
    return modelList.map((contratoTemplate) => contratoTemplate.toJson).toList();
  }

  @override
  void prepareForInsert() {
    isNewRecord = true;
    currentModel = createNewModel();
    _resetForm();
    Get.toNamed(Routes.contratoTemplateEditPage);
  }

  void _resetForm() {
    formWasChanged = false;
    nomeController.text = '';
    descricaoController.text = '';
  }

  @override
  void selectRowForEditingById(int id) {
    final model = modelList.firstWhere((m) => m.id == id);
    currentModel = model.clone();
    updateControllersFromModel();
    Get.toNamed(Routes.contratoTemplateEditPage);
  }

  void updateControllersFromModel() {
    nomeController.text = currentModel.nome ?? '';
    descricaoController.text = currentModel.descricao ?? '';
    formWasChanged = false;
  }

  @override
  Future<void> save() async {
    if (!formKey.currentState!.validate()) {
      showErrorSnackBar(message: 'validator_form_message'.tr);
      return;
    }

    final existingIndex = modelList.indexWhere((m) => m.id == currentModel.id);

    if (existingIndex >= 0) {
      modelList[existingIndex] = currentModel.clone();
    }

    final result = await repository.save(contratoTemplateModel: currentModel);
    if (result == null) return;

    if (existingIndex >= 0) {
      modelList[existingIndex] = result;
    } else {
      modelList.insert(0, result);
    }

    if (!GetPlatform.isMobile) {
      updateGridRow(result);
    }

    Get.back(result: true);
  }

  Future<void> editarArquivo() async {
    // Monta o caminho do arquivo com base no ID
    final id = currentModel.id;
    final caminho = "C:\\t2ti\\contratos\\templates\\$id.docx"; // TODO: altere o caminho ou baixe do servidor como no GED

    // Verifica se o arquivo existe
    final arquivo = File(caminho);
    if (await arquivo.exists()) {
      await OpenFilex.open(caminho); // Abre no editor padrão do sistema
    } else {
      // Se não existir, cria o arquivo
      await arquivo.create(recursive: true);

      // Opcional: escrever algum conteúdo inicial
      await arquivo.writeAsBytes(
        [], // vazio (Word/LibreOffice abre um docx em branco, mas pode dar warning dependendo do programa)
        mode: FileMode.write,
      );

      // Abre o novo arquivo
      await OpenFilex.open(caminho);
    }
  }

  @override
  void onClose() {
    nomeController.dispose();
    descricaoController.dispose();
    super.onClose();
  }

}