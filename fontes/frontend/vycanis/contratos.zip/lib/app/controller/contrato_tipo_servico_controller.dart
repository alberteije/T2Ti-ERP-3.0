import 'package:flutter/material.dart';
import 'package:get/get.dart';

import 'package:contratos/app/page/shared_widget/message_dialog.dart';
import 'package:contratos/app/page/grid_columns/grid_columns_imports.dart';
import 'package:contratos/app/routes/app_routes.dart';
import 'package:contratos/app/controller/controller_imports.dart';
import 'package:contratos/app/data/model/model_imports.dart';
import 'package:contratos/app/data/repository/contrato_tipo_servico_repository.dart';

class ContratoTipoServicoController extends ControllerBase<ContratoTipoServicoModel, ContratoTipoServicoRepository> {

  ContratoTipoServicoController({required super.repository}) {
    dbColumns = ContratoTipoServicoModel.dbColumns;
    aliasColumns = ContratoTipoServicoModel.aliasColumns;
    gridColumns = contratoTipoServicoGridColumns();
    functionName = "contrato_tipo_servico";
    screenTitle = "Tipo de Serviço";
  }

  @override
  ContratoTipoServicoModel createNewModel() => ContratoTipoServicoModel();

  @override
  final standardFieldForFilter = ContratoTipoServicoModel.aliasColumns[ContratoTipoServicoModel.dbColumns.indexOf('nome')];

  final nomeController = TextEditingController();
  final descricaoController = TextEditingController();

  final Map<String, dynamic> mobileConfig = {
    'primaryColumns': ['nome'],
    'secondaryColumns': ['descricao'],
  };

  List<Map<String, dynamic>> get mobileItems {
    return modelList.map((contratoTipoServico) => contratoTipoServico.toJson).toList();
  }

  @override
  void prepareForInsert() {
    isNewRecord = true;
    currentModel = createNewModel();
    _resetForm();
    Get.toNamed(Routes.contratoTipoServicoEditPage);
  }

  void _resetForm() {
    formWasChanged = false;
    nomeController.text = '';
    descricaoController.text = '';
  }

  @override
  void selectRowForEditingById(int id) {
    final model = modelList.firstWhere((m) => m.id == id);
    currentModel = model.clone();
    updateControllersFromModel();
    Get.toNamed(Routes.contratoTipoServicoEditPage);
  }

  void updateControllersFromModel() {
    nomeController.text = currentModel.nome ?? '';
    descricaoController.text = currentModel.descricao ?? '';
    formWasChanged = false;
  }

  @override
  Future<void> save() async {
    if (!formKey.currentState!.validate()) {
      showErrorSnackBar(message: 'validator_form_message'.tr);
      return;
    }

    final existingIndex = modelList.indexWhere((m) => m.id == currentModel.id);

    if (existingIndex >= 0) {
      modelList[existingIndex] = currentModel.clone();
    }

    final result = await repository.save(contratoTipoServicoModel: currentModel);
    if (result == null) return;

    if (existingIndex >= 0) {
      modelList[existingIndex] = result;
    } else {
      modelList.insert(0, result);
    }

    if (!GetPlatform.isMobile) {
      updateGridRow(result);
    }

    Get.back(result: true);
  }


  @override
  void onClose() {
    nomeController.dispose();
    descricaoController.dispose();
    super.onClose();
  }

}