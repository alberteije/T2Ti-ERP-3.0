// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'tipo_contrato_dao.dart';

// ignore_for_file: type=lint
mixin _$TipoContratoDaoMixin on DatabaseAccessor<AppDatabase> {
  $TipoContratosTable get tipoContratos => attachedDatabase.tipoContratos;
}
