// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'contrato_tipo_servico_dao.dart';

// ignore_for_file: type=lint
mixin _$ContratoTipoServicoDaoMixin on DatabaseAccessor<AppDatabase> {
  $ContratoTipoServicosTable get contratoTipoServicos =>
      attachedDatabase.contratoTipoServicos;
}
