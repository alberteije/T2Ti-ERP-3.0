// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'database.dart';

// ignore_for_file: type=lint
class $ContratoHistoricoReajustesTable extends ContratoHistoricoReajustes
    with
        TableInfo<$ContratoHistoricoReajustesTable, ContratoHistoricoReajuste> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $ContratoHistoricoReajustesTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
      'id', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _idContratoMeta =
      const VerificationMeta('idContrato');
  @override
  late final GeneratedColumn<int> idContrato = GeneratedColumn<int>(
      'id_contrato', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _indiceMeta = const VerificationMeta('indice');
  @override
  late final GeneratedColumn<double> indice = GeneratedColumn<double>(
      'indice', aliasedName, true,
      type: DriftSqlType.double, requiredDuringInsert: false);
  static const VerificationMeta _valorAnteriorMeta =
      const VerificationMeta('valorAnterior');
  @override
  late final GeneratedColumn<double> valorAnterior = GeneratedColumn<double>(
      'valor_anterior', aliasedName, true,
      type: DriftSqlType.double, requiredDuringInsert: false);
  static const VerificationMeta _valorAtualMeta =
      const VerificationMeta('valorAtual');
  @override
  late final GeneratedColumn<double> valorAtual = GeneratedColumn<double>(
      'valor_atual', aliasedName, true,
      type: DriftSqlType.double, requiredDuringInsert: false);
  static const VerificationMeta _dataReajusteMeta =
      const VerificationMeta('dataReajuste');
  @override
  late final GeneratedColumn<DateTime> dataReajuste = GeneratedColumn<DateTime>(
      'data_reajuste', aliasedName, true,
      type: DriftSqlType.dateTime, requiredDuringInsert: false);
  static const VerificationMeta _observacaoMeta =
      const VerificationMeta('observacao');
  @override
  late final GeneratedColumn<String> observacao = GeneratedColumn<String>(
      'observacao', aliasedName, true,
      type: DriftSqlType.string, requiredDuringInsert: false);
  @override
  List<GeneratedColumn> get $columns => [
        id,
        idContrato,
        indice,
        valorAnterior,
        valorAtual,
        dataReajuste,
        observacao
      ];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'contrato_historico_reajuste';
  @override
  VerificationContext validateIntegrity(
      Insertable<ContratoHistoricoReajuste> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('id_contrato')) {
      context.handle(
          _idContratoMeta,
          idContrato.isAcceptableOrUnknown(
              data['id_contrato']!, _idContratoMeta));
    }
    if (data.containsKey('indice')) {
      context.handle(_indiceMeta,
          indice.isAcceptableOrUnknown(data['indice']!, _indiceMeta));
    }
    if (data.containsKey('valor_anterior')) {
      context.handle(
          _valorAnteriorMeta,
          valorAnterior.isAcceptableOrUnknown(
              data['valor_anterior']!, _valorAnteriorMeta));
    }
    if (data.containsKey('valor_atual')) {
      context.handle(
          _valorAtualMeta,
          valorAtual.isAcceptableOrUnknown(
              data['valor_atual']!, _valorAtualMeta));
    }
    if (data.containsKey('data_reajuste')) {
      context.handle(
          _dataReajusteMeta,
          dataReajuste.isAcceptableOrUnknown(
              data['data_reajuste']!, _dataReajusteMeta));
    }
    if (data.containsKey('observacao')) {
      context.handle(
          _observacaoMeta,
          observacao.isAcceptableOrUnknown(
              data['observacao']!, _observacaoMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  ContratoHistoricoReajuste map(Map<String, dynamic> data,
      {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return ContratoHistoricoReajuste(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id']),
      idContrato: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id_contrato']),
      indice: attachedDatabase.typeMapping
          .read(DriftSqlType.double, data['${effectivePrefix}indice']),
      valorAnterior: attachedDatabase.typeMapping
          .read(DriftSqlType.double, data['${effectivePrefix}valor_anterior']),
      valorAtual: attachedDatabase.typeMapping
          .read(DriftSqlType.double, data['${effectivePrefix}valor_atual']),
      dataReajuste: attachedDatabase.typeMapping
          .read(DriftSqlType.dateTime, data['${effectivePrefix}data_reajuste']),
      observacao: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}observacao']),
    );
  }

  @override
  $ContratoHistoricoReajustesTable createAlias(String alias) {
    return $ContratoHistoricoReajustesTable(attachedDatabase, alias);
  }
}

class ContratoHistoricoReajuste extends DataClass
    implements Insertable<ContratoHistoricoReajuste> {
  final int? id;
  final int? idContrato;
  final double? indice;
  final double? valorAnterior;
  final double? valorAtual;
  final DateTime? dataReajuste;
  final String? observacao;
  const ContratoHistoricoReajuste(
      {this.id,
      this.idContrato,
      this.indice,
      this.valorAnterior,
      this.valorAtual,
      this.dataReajuste,
      this.observacao});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || idContrato != null) {
      map['id_contrato'] = Variable<int>(idContrato);
    }
    if (!nullToAbsent || indice != null) {
      map['indice'] = Variable<double>(indice);
    }
    if (!nullToAbsent || valorAnterior != null) {
      map['valor_anterior'] = Variable<double>(valorAnterior);
    }
    if (!nullToAbsent || valorAtual != null) {
      map['valor_atual'] = Variable<double>(valorAtual);
    }
    if (!nullToAbsent || dataReajuste != null) {
      map['data_reajuste'] = Variable<DateTime>(dataReajuste);
    }
    if (!nullToAbsent || observacao != null) {
      map['observacao'] = Variable<String>(observacao);
    }
    return map;
  }

  factory ContratoHistoricoReajuste.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return ContratoHistoricoReajuste(
      id: serializer.fromJson<int?>(json['id']),
      idContrato: serializer.fromJson<int?>(json['idContrato']),
      indice: serializer.fromJson<double?>(json['indice']),
      valorAnterior: serializer.fromJson<double?>(json['valorAnterior']),
      valorAtual: serializer.fromJson<double?>(json['valorAtual']),
      dataReajuste: serializer.fromJson<DateTime?>(json['dataReajuste']),
      observacao: serializer.fromJson<String?>(json['observacao']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'idContrato': serializer.toJson<int?>(idContrato),
      'indice': serializer.toJson<double?>(indice),
      'valorAnterior': serializer.toJson<double?>(valorAnterior),
      'valorAtual': serializer.toJson<double?>(valorAtual),
      'dataReajuste': serializer.toJson<DateTime?>(dataReajuste),
      'observacao': serializer.toJson<String?>(observacao),
    };
  }

  ContratoHistoricoReajuste copyWith(
          {Value<int?> id = const Value.absent(),
          Value<int?> idContrato = const Value.absent(),
          Value<double?> indice = const Value.absent(),
          Value<double?> valorAnterior = const Value.absent(),
          Value<double?> valorAtual = const Value.absent(),
          Value<DateTime?> dataReajuste = const Value.absent(),
          Value<String?> observacao = const Value.absent()}) =>
      ContratoHistoricoReajuste(
        id: id.present ? id.value : this.id,
        idContrato: idContrato.present ? idContrato.value : this.idContrato,
        indice: indice.present ? indice.value : this.indice,
        valorAnterior:
            valorAnterior.present ? valorAnterior.value : this.valorAnterior,
        valorAtual: valorAtual.present ? valorAtual.value : this.valorAtual,
        dataReajuste:
            dataReajuste.present ? dataReajuste.value : this.dataReajuste,
        observacao: observacao.present ? observacao.value : this.observacao,
      );
  ContratoHistoricoReajuste copyWithCompanion(
      ContratoHistoricoReajustesCompanion data) {
    return ContratoHistoricoReajuste(
      id: data.id.present ? data.id.value : this.id,
      idContrato:
          data.idContrato.present ? data.idContrato.value : this.idContrato,
      indice: data.indice.present ? data.indice.value : this.indice,
      valorAnterior: data.valorAnterior.present
          ? data.valorAnterior.value
          : this.valorAnterior,
      valorAtual:
          data.valorAtual.present ? data.valorAtual.value : this.valorAtual,
      dataReajuste: data.dataReajuste.present
          ? data.dataReajuste.value
          : this.dataReajuste,
      observacao:
          data.observacao.present ? data.observacao.value : this.observacao,
    );
  }

  @override
  String toString() {
    return (StringBuffer('ContratoHistoricoReajuste(')
          ..write('id: $id, ')
          ..write('idContrato: $idContrato, ')
          ..write('indice: $indice, ')
          ..write('valorAnterior: $valorAnterior, ')
          ..write('valorAtual: $valorAtual, ')
          ..write('dataReajuste: $dataReajuste, ')
          ..write('observacao: $observacao')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(id, idContrato, indice, valorAnterior,
      valorAtual, dataReajuste, observacao);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is ContratoHistoricoReajuste &&
          other.id == this.id &&
          other.idContrato == this.idContrato &&
          other.indice == this.indice &&
          other.valorAnterior == this.valorAnterior &&
          other.valorAtual == this.valorAtual &&
          other.dataReajuste == this.dataReajuste &&
          other.observacao == this.observacao);
}

class ContratoHistoricoReajustesCompanion
    extends UpdateCompanion<ContratoHistoricoReajuste> {
  final Value<int?> id;
  final Value<int?> idContrato;
  final Value<double?> indice;
  final Value<double?> valorAnterior;
  final Value<double?> valorAtual;
  final Value<DateTime?> dataReajuste;
  final Value<String?> observacao;
  const ContratoHistoricoReajustesCompanion({
    this.id = const Value.absent(),
    this.idContrato = const Value.absent(),
    this.indice = const Value.absent(),
    this.valorAnterior = const Value.absent(),
    this.valorAtual = const Value.absent(),
    this.dataReajuste = const Value.absent(),
    this.observacao = const Value.absent(),
  });
  ContratoHistoricoReajustesCompanion.insert({
    this.id = const Value.absent(),
    this.idContrato = const Value.absent(),
    this.indice = const Value.absent(),
    this.valorAnterior = const Value.absent(),
    this.valorAtual = const Value.absent(),
    this.dataReajuste = const Value.absent(),
    this.observacao = const Value.absent(),
  });
  static Insertable<ContratoHistoricoReajuste> custom({
    Expression<int>? id,
    Expression<int>? idContrato,
    Expression<double>? indice,
    Expression<double>? valorAnterior,
    Expression<double>? valorAtual,
    Expression<DateTime>? dataReajuste,
    Expression<String>? observacao,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (idContrato != null) 'id_contrato': idContrato,
      if (indice != null) 'indice': indice,
      if (valorAnterior != null) 'valor_anterior': valorAnterior,
      if (valorAtual != null) 'valor_atual': valorAtual,
      if (dataReajuste != null) 'data_reajuste': dataReajuste,
      if (observacao != null) 'observacao': observacao,
    });
  }

  ContratoHistoricoReajustesCompanion copyWith(
      {Value<int?>? id,
      Value<int?>? idContrato,
      Value<double?>? indice,
      Value<double?>? valorAnterior,
      Value<double?>? valorAtual,
      Value<DateTime?>? dataReajuste,
      Value<String?>? observacao}) {
    return ContratoHistoricoReajustesCompanion(
      id: id ?? this.id,
      idContrato: idContrato ?? this.idContrato,
      indice: indice ?? this.indice,
      valorAnterior: valorAnterior ?? this.valorAnterior,
      valorAtual: valorAtual ?? this.valorAtual,
      dataReajuste: dataReajuste ?? this.dataReajuste,
      observacao: observacao ?? this.observacao,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (idContrato.present) {
      map['id_contrato'] = Variable<int>(idContrato.value);
    }
    if (indice.present) {
      map['indice'] = Variable<double>(indice.value);
    }
    if (valorAnterior.present) {
      map['valor_anterior'] = Variable<double>(valorAnterior.value);
    }
    if (valorAtual.present) {
      map['valor_atual'] = Variable<double>(valorAtual.value);
    }
    if (dataReajuste.present) {
      map['data_reajuste'] = Variable<DateTime>(dataReajuste.value);
    }
    if (observacao.present) {
      map['observacao'] = Variable<String>(observacao.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('ContratoHistoricoReajustesCompanion(')
          ..write('id: $id, ')
          ..write('idContrato: $idContrato, ')
          ..write('indice: $indice, ')
          ..write('valorAnterior: $valorAnterior, ')
          ..write('valorAtual: $valorAtual, ')
          ..write('dataReajuste: $dataReajuste, ')
          ..write('observacao: $observacao')
          ..write(')'))
        .toString();
  }
}

class $ContratoPrevFaturamentosTable extends ContratoPrevFaturamentos
    with TableInfo<$ContratoPrevFaturamentosTable, ContratoPrevFaturamento> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $ContratoPrevFaturamentosTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
      'id', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _idContratoMeta =
      const VerificationMeta('idContrato');
  @override
  late final GeneratedColumn<int> idContrato = GeneratedColumn<int>(
      'id_contrato', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _dataPrevistaMeta =
      const VerificationMeta('dataPrevista');
  @override
  late final GeneratedColumn<DateTime> dataPrevista = GeneratedColumn<DateTime>(
      'data_prevista', aliasedName, true,
      type: DriftSqlType.dateTime, requiredDuringInsert: false);
  static const VerificationMeta _valorMeta = const VerificationMeta('valor');
  @override
  late final GeneratedColumn<double> valor = GeneratedColumn<double>(
      'valor', aliasedName, true,
      type: DriftSqlType.double, requiredDuringInsert: false);
  @override
  List<GeneratedColumn> get $columns => [id, idContrato, dataPrevista, valor];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'contrato_prev_faturamento';
  @override
  VerificationContext validateIntegrity(
      Insertable<ContratoPrevFaturamento> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('id_contrato')) {
      context.handle(
          _idContratoMeta,
          idContrato.isAcceptableOrUnknown(
              data['id_contrato']!, _idContratoMeta));
    }
    if (data.containsKey('data_prevista')) {
      context.handle(
          _dataPrevistaMeta,
          dataPrevista.isAcceptableOrUnknown(
              data['data_prevista']!, _dataPrevistaMeta));
    }
    if (data.containsKey('valor')) {
      context.handle(
          _valorMeta, valor.isAcceptableOrUnknown(data['valor']!, _valorMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  ContratoPrevFaturamento map(Map<String, dynamic> data,
      {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return ContratoPrevFaturamento(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id']),
      idContrato: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id_contrato']),
      dataPrevista: attachedDatabase.typeMapping
          .read(DriftSqlType.dateTime, data['${effectivePrefix}data_prevista']),
      valor: attachedDatabase.typeMapping
          .read(DriftSqlType.double, data['${effectivePrefix}valor']),
    );
  }

  @override
  $ContratoPrevFaturamentosTable createAlias(String alias) {
    return $ContratoPrevFaturamentosTable(attachedDatabase, alias);
  }
}

class ContratoPrevFaturamento extends DataClass
    implements Insertable<ContratoPrevFaturamento> {
  final int? id;
  final int? idContrato;
  final DateTime? dataPrevista;
  final double? valor;
  const ContratoPrevFaturamento(
      {this.id, this.idContrato, this.dataPrevista, this.valor});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || idContrato != null) {
      map['id_contrato'] = Variable<int>(idContrato);
    }
    if (!nullToAbsent || dataPrevista != null) {
      map['data_prevista'] = Variable<DateTime>(dataPrevista);
    }
    if (!nullToAbsent || valor != null) {
      map['valor'] = Variable<double>(valor);
    }
    return map;
  }

  factory ContratoPrevFaturamento.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return ContratoPrevFaturamento(
      id: serializer.fromJson<int?>(json['id']),
      idContrato: serializer.fromJson<int?>(json['idContrato']),
      dataPrevista: serializer.fromJson<DateTime?>(json['dataPrevista']),
      valor: serializer.fromJson<double?>(json['valor']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'idContrato': serializer.toJson<int?>(idContrato),
      'dataPrevista': serializer.toJson<DateTime?>(dataPrevista),
      'valor': serializer.toJson<double?>(valor),
    };
  }

  ContratoPrevFaturamento copyWith(
          {Value<int?> id = const Value.absent(),
          Value<int?> idContrato = const Value.absent(),
          Value<DateTime?> dataPrevista = const Value.absent(),
          Value<double?> valor = const Value.absent()}) =>
      ContratoPrevFaturamento(
        id: id.present ? id.value : this.id,
        idContrato: idContrato.present ? idContrato.value : this.idContrato,
        dataPrevista:
            dataPrevista.present ? dataPrevista.value : this.dataPrevista,
        valor: valor.present ? valor.value : this.valor,
      );
  ContratoPrevFaturamento copyWithCompanion(
      ContratoPrevFaturamentosCompanion data) {
    return ContratoPrevFaturamento(
      id: data.id.present ? data.id.value : this.id,
      idContrato:
          data.idContrato.present ? data.idContrato.value : this.idContrato,
      dataPrevista: data.dataPrevista.present
          ? data.dataPrevista.value
          : this.dataPrevista,
      valor: data.valor.present ? data.valor.value : this.valor,
    );
  }

  @override
  String toString() {
    return (StringBuffer('ContratoPrevFaturamento(')
          ..write('id: $id, ')
          ..write('idContrato: $idContrato, ')
          ..write('dataPrevista: $dataPrevista, ')
          ..write('valor: $valor')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(id, idContrato, dataPrevista, valor);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is ContratoPrevFaturamento &&
          other.id == this.id &&
          other.idContrato == this.idContrato &&
          other.dataPrevista == this.dataPrevista &&
          other.valor == this.valor);
}

class ContratoPrevFaturamentosCompanion
    extends UpdateCompanion<ContratoPrevFaturamento> {
  final Value<int?> id;
  final Value<int?> idContrato;
  final Value<DateTime?> dataPrevista;
  final Value<double?> valor;
  const ContratoPrevFaturamentosCompanion({
    this.id = const Value.absent(),
    this.idContrato = const Value.absent(),
    this.dataPrevista = const Value.absent(),
    this.valor = const Value.absent(),
  });
  ContratoPrevFaturamentosCompanion.insert({
    this.id = const Value.absent(),
    this.idContrato = const Value.absent(),
    this.dataPrevista = const Value.absent(),
    this.valor = const Value.absent(),
  });
  static Insertable<ContratoPrevFaturamento> custom({
    Expression<int>? id,
    Expression<int>? idContrato,
    Expression<DateTime>? dataPrevista,
    Expression<double>? valor,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (idContrato != null) 'id_contrato': idContrato,
      if (dataPrevista != null) 'data_prevista': dataPrevista,
      if (valor != null) 'valor': valor,
    });
  }

  ContratoPrevFaturamentosCompanion copyWith(
      {Value<int?>? id,
      Value<int?>? idContrato,
      Value<DateTime?>? dataPrevista,
      Value<double?>? valor}) {
    return ContratoPrevFaturamentosCompanion(
      id: id ?? this.id,
      idContrato: idContrato ?? this.idContrato,
      dataPrevista: dataPrevista ?? this.dataPrevista,
      valor: valor ?? this.valor,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (idContrato.present) {
      map['id_contrato'] = Variable<int>(idContrato.value);
    }
    if (dataPrevista.present) {
      map['data_prevista'] = Variable<DateTime>(dataPrevista.value);
    }
    if (valor.present) {
      map['valor'] = Variable<double>(valor.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('ContratoPrevFaturamentosCompanion(')
          ..write('id: $id, ')
          ..write('idContrato: $idContrato, ')
          ..write('dataPrevista: $dataPrevista, ')
          ..write('valor: $valor')
          ..write(')'))
        .toString();
  }
}

class $ContratoHistFaturamentosTable extends ContratoHistFaturamentos
    with TableInfo<$ContratoHistFaturamentosTable, ContratoHistFaturamento> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $ContratoHistFaturamentosTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
      'id', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _idContratoMeta =
      const VerificationMeta('idContrato');
  @override
  late final GeneratedColumn<int> idContrato = GeneratedColumn<int>(
      'id_contrato', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _dataFaturaMeta =
      const VerificationMeta('dataFatura');
  @override
  late final GeneratedColumn<DateTime> dataFatura = GeneratedColumn<DateTime>(
      'data_fatura', aliasedName, true,
      type: DriftSqlType.dateTime, requiredDuringInsert: false);
  static const VerificationMeta _valorMeta = const VerificationMeta('valor');
  @override
  late final GeneratedColumn<double> valor = GeneratedColumn<double>(
      'valor', aliasedName, true,
      type: DriftSqlType.double, requiredDuringInsert: false);
  @override
  List<GeneratedColumn> get $columns => [id, idContrato, dataFatura, valor];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'contrato_hist_faturamento';
  @override
  VerificationContext validateIntegrity(
      Insertable<ContratoHistFaturamento> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('id_contrato')) {
      context.handle(
          _idContratoMeta,
          idContrato.isAcceptableOrUnknown(
              data['id_contrato']!, _idContratoMeta));
    }
    if (data.containsKey('data_fatura')) {
      context.handle(
          _dataFaturaMeta,
          dataFatura.isAcceptableOrUnknown(
              data['data_fatura']!, _dataFaturaMeta));
    }
    if (data.containsKey('valor')) {
      context.handle(
          _valorMeta, valor.isAcceptableOrUnknown(data['valor']!, _valorMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  ContratoHistFaturamento map(Map<String, dynamic> data,
      {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return ContratoHistFaturamento(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id']),
      idContrato: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id_contrato']),
      dataFatura: attachedDatabase.typeMapping
          .read(DriftSqlType.dateTime, data['${effectivePrefix}data_fatura']),
      valor: attachedDatabase.typeMapping
          .read(DriftSqlType.double, data['${effectivePrefix}valor']),
    );
  }

  @override
  $ContratoHistFaturamentosTable createAlias(String alias) {
    return $ContratoHistFaturamentosTable(attachedDatabase, alias);
  }
}

class ContratoHistFaturamento extends DataClass
    implements Insertable<ContratoHistFaturamento> {
  final int? id;
  final int? idContrato;
  final DateTime? dataFatura;
  final double? valor;
  const ContratoHistFaturamento(
      {this.id, this.idContrato, this.dataFatura, this.valor});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || idContrato != null) {
      map['id_contrato'] = Variable<int>(idContrato);
    }
    if (!nullToAbsent || dataFatura != null) {
      map['data_fatura'] = Variable<DateTime>(dataFatura);
    }
    if (!nullToAbsent || valor != null) {
      map['valor'] = Variable<double>(valor);
    }
    return map;
  }

  factory ContratoHistFaturamento.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return ContratoHistFaturamento(
      id: serializer.fromJson<int?>(json['id']),
      idContrato: serializer.fromJson<int?>(json['idContrato']),
      dataFatura: serializer.fromJson<DateTime?>(json['dataFatura']),
      valor: serializer.fromJson<double?>(json['valor']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'idContrato': serializer.toJson<int?>(idContrato),
      'dataFatura': serializer.toJson<DateTime?>(dataFatura),
      'valor': serializer.toJson<double?>(valor),
    };
  }

  ContratoHistFaturamento copyWith(
          {Value<int?> id = const Value.absent(),
          Value<int?> idContrato = const Value.absent(),
          Value<DateTime?> dataFatura = const Value.absent(),
          Value<double?> valor = const Value.absent()}) =>
      ContratoHistFaturamento(
        id: id.present ? id.value : this.id,
        idContrato: idContrato.present ? idContrato.value : this.idContrato,
        dataFatura: dataFatura.present ? dataFatura.value : this.dataFatura,
        valor: valor.present ? valor.value : this.valor,
      );
  ContratoHistFaturamento copyWithCompanion(
      ContratoHistFaturamentosCompanion data) {
    return ContratoHistFaturamento(
      id: data.id.present ? data.id.value : this.id,
      idContrato:
          data.idContrato.present ? data.idContrato.value : this.idContrato,
      dataFatura:
          data.dataFatura.present ? data.dataFatura.value : this.dataFatura,
      valor: data.valor.present ? data.valor.value : this.valor,
    );
  }

  @override
  String toString() {
    return (StringBuffer('ContratoHistFaturamento(')
          ..write('id: $id, ')
          ..write('idContrato: $idContrato, ')
          ..write('dataFatura: $dataFatura, ')
          ..write('valor: $valor')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(id, idContrato, dataFatura, valor);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is ContratoHistFaturamento &&
          other.id == this.id &&
          other.idContrato == this.idContrato &&
          other.dataFatura == this.dataFatura &&
          other.valor == this.valor);
}

class ContratoHistFaturamentosCompanion
    extends UpdateCompanion<ContratoHistFaturamento> {
  final Value<int?> id;
  final Value<int?> idContrato;
  final Value<DateTime?> dataFatura;
  final Value<double?> valor;
  const ContratoHistFaturamentosCompanion({
    this.id = const Value.absent(),
    this.idContrato = const Value.absent(),
    this.dataFatura = const Value.absent(),
    this.valor = const Value.absent(),
  });
  ContratoHistFaturamentosCompanion.insert({
    this.id = const Value.absent(),
    this.idContrato = const Value.absent(),
    this.dataFatura = const Value.absent(),
    this.valor = const Value.absent(),
  });
  static Insertable<ContratoHistFaturamento> custom({
    Expression<int>? id,
    Expression<int>? idContrato,
    Expression<DateTime>? dataFatura,
    Expression<double>? valor,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (idContrato != null) 'id_contrato': idContrato,
      if (dataFatura != null) 'data_fatura': dataFatura,
      if (valor != null) 'valor': valor,
    });
  }

  ContratoHistFaturamentosCompanion copyWith(
      {Value<int?>? id,
      Value<int?>? idContrato,
      Value<DateTime?>? dataFatura,
      Value<double?>? valor}) {
    return ContratoHistFaturamentosCompanion(
      id: id ?? this.id,
      idContrato: idContrato ?? this.idContrato,
      dataFatura: dataFatura ?? this.dataFatura,
      valor: valor ?? this.valor,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (idContrato.present) {
      map['id_contrato'] = Variable<int>(idContrato.value);
    }
    if (dataFatura.present) {
      map['data_fatura'] = Variable<DateTime>(dataFatura.value);
    }
    if (valor.present) {
      map['valor'] = Variable<double>(valor.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('ContratoHistFaturamentosCompanion(')
          ..write('id: $id, ')
          ..write('idContrato: $idContrato, ')
          ..write('dataFatura: $dataFatura, ')
          ..write('valor: $valor')
          ..write(')'))
        .toString();
  }
}

class $ContratosTable extends Contratos
    with TableInfo<$ContratosTable, Contrato> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $ContratosTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
      'id', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _idSolicitacaoServicoMeta =
      const VerificationMeta('idSolicitacaoServico');
  @override
  late final GeneratedColumn<int> idSolicitacaoServico = GeneratedColumn<int>(
      'id_solicitacao_servico', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _idTipoContratoMeta =
      const VerificationMeta('idTipoContrato');
  @override
  late final GeneratedColumn<int> idTipoContrato = GeneratedColumn<int>(
      'id_tipo_contrato', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _numeroMeta = const VerificationMeta('numero');
  @override
  late final GeneratedColumn<String> numero = GeneratedColumn<String>(
      'numero', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 50),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _nomeMeta = const VerificationMeta('nome');
  @override
  late final GeneratedColumn<String> nome = GeneratedColumn<String>(
      'nome', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 100),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _descricaoMeta =
      const VerificationMeta('descricao');
  @override
  late final GeneratedColumn<String> descricao = GeneratedColumn<String>(
      'descricao', aliasedName, true,
      type: DriftSqlType.string, requiredDuringInsert: false);
  static const VerificationMeta _dataCadastroMeta =
      const VerificationMeta('dataCadastro');
  @override
  late final GeneratedColumn<DateTime> dataCadastro = GeneratedColumn<DateTime>(
      'data_cadastro', aliasedName, true,
      type: DriftSqlType.dateTime, requiredDuringInsert: false);
  static const VerificationMeta _dataInicioVigenciaMeta =
      const VerificationMeta('dataInicioVigencia');
  @override
  late final GeneratedColumn<DateTime> dataInicioVigencia =
      GeneratedColumn<DateTime>('data_inicio_vigencia', aliasedName, true,
          type: DriftSqlType.dateTime, requiredDuringInsert: false);
  static const VerificationMeta _dataFimVigenciaMeta =
      const VerificationMeta('dataFimVigencia');
  @override
  late final GeneratedColumn<DateTime> dataFimVigencia =
      GeneratedColumn<DateTime>('data_fim_vigencia', aliasedName, true,
          type: DriftSqlType.dateTime, requiredDuringInsert: false);
  static const VerificationMeta _diaFaturamentoMeta =
      const VerificationMeta('diaFaturamento');
  @override
  late final GeneratedColumn<String> diaFaturamento = GeneratedColumn<String>(
      'dia_faturamento', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 2),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _valorMeta = const VerificationMeta('valor');
  @override
  late final GeneratedColumn<double> valor = GeneratedColumn<double>(
      'valor', aliasedName, true,
      type: DriftSqlType.double, requiredDuringInsert: false);
  static const VerificationMeta _quantidadeParcelasMeta =
      const VerificationMeta('quantidadeParcelas');
  @override
  late final GeneratedColumn<int> quantidadeParcelas = GeneratedColumn<int>(
      'quantidade_parcelas', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _intervaloEntreParcelasMeta =
      const VerificationMeta('intervaloEntreParcelas');
  @override
  late final GeneratedColumn<int> intervaloEntreParcelas = GeneratedColumn<int>(
      'intervalo_entre_parcelas', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _classificacaoContabilContaMeta =
      const VerificationMeta('classificacaoContabilConta');
  @override
  late final GeneratedColumn<String> classificacaoContabilConta =
      GeneratedColumn<String>('classificacao_contabil_conta', aliasedName, true,
          additionalChecks: GeneratedColumn.checkTextLength(
              minTextLength: 0, maxTextLength: 30),
          type: DriftSqlType.string,
          requiredDuringInsert: false);
  static const VerificationMeta _observacaoMeta =
      const VerificationMeta('observacao');
  @override
  late final GeneratedColumn<String> observacao = GeneratedColumn<String>(
      'observacao', aliasedName, true,
      type: DriftSqlType.string, requiredDuringInsert: false);
  @override
  List<GeneratedColumn> get $columns => [
        id,
        idSolicitacaoServico,
        idTipoContrato,
        numero,
        nome,
        descricao,
        dataCadastro,
        dataInicioVigencia,
        dataFimVigencia,
        diaFaturamento,
        valor,
        quantidadeParcelas,
        intervaloEntreParcelas,
        classificacaoContabilConta,
        observacao
      ];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'contrato';
  @override
  VerificationContext validateIntegrity(Insertable<Contrato> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('id_solicitacao_servico')) {
      context.handle(
          _idSolicitacaoServicoMeta,
          idSolicitacaoServico.isAcceptableOrUnknown(
              data['id_solicitacao_servico']!, _idSolicitacaoServicoMeta));
    }
    if (data.containsKey('id_tipo_contrato')) {
      context.handle(
          _idTipoContratoMeta,
          idTipoContrato.isAcceptableOrUnknown(
              data['id_tipo_contrato']!, _idTipoContratoMeta));
    }
    if (data.containsKey('numero')) {
      context.handle(_numeroMeta,
          numero.isAcceptableOrUnknown(data['numero']!, _numeroMeta));
    }
    if (data.containsKey('nome')) {
      context.handle(
          _nomeMeta, nome.isAcceptableOrUnknown(data['nome']!, _nomeMeta));
    }
    if (data.containsKey('descricao')) {
      context.handle(_descricaoMeta,
          descricao.isAcceptableOrUnknown(data['descricao']!, _descricaoMeta));
    }
    if (data.containsKey('data_cadastro')) {
      context.handle(
          _dataCadastroMeta,
          dataCadastro.isAcceptableOrUnknown(
              data['data_cadastro']!, _dataCadastroMeta));
    }
    if (data.containsKey('data_inicio_vigencia')) {
      context.handle(
          _dataInicioVigenciaMeta,
          dataInicioVigencia.isAcceptableOrUnknown(
              data['data_inicio_vigencia']!, _dataInicioVigenciaMeta));
    }
    if (data.containsKey('data_fim_vigencia')) {
      context.handle(
          _dataFimVigenciaMeta,
          dataFimVigencia.isAcceptableOrUnknown(
              data['data_fim_vigencia']!, _dataFimVigenciaMeta));
    }
    if (data.containsKey('dia_faturamento')) {
      context.handle(
          _diaFaturamentoMeta,
          diaFaturamento.isAcceptableOrUnknown(
              data['dia_faturamento']!, _diaFaturamentoMeta));
    }
    if (data.containsKey('valor')) {
      context.handle(
          _valorMeta, valor.isAcceptableOrUnknown(data['valor']!, _valorMeta));
    }
    if (data.containsKey('quantidade_parcelas')) {
      context.handle(
          _quantidadeParcelasMeta,
          quantidadeParcelas.isAcceptableOrUnknown(
              data['quantidade_parcelas']!, _quantidadeParcelasMeta));
    }
    if (data.containsKey('intervalo_entre_parcelas')) {
      context.handle(
          _intervaloEntreParcelasMeta,
          intervaloEntreParcelas.isAcceptableOrUnknown(
              data['intervalo_entre_parcelas']!, _intervaloEntreParcelasMeta));
    }
    if (data.containsKey('classificacao_contabil_conta')) {
      context.handle(
          _classificacaoContabilContaMeta,
          classificacaoContabilConta.isAcceptableOrUnknown(
              data['classificacao_contabil_conta']!,
              _classificacaoContabilContaMeta));
    }
    if (data.containsKey('observacao')) {
      context.handle(
          _observacaoMeta,
          observacao.isAcceptableOrUnknown(
              data['observacao']!, _observacaoMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  Contrato map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return Contrato(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id']),
      idSolicitacaoServico: attachedDatabase.typeMapping.read(
          DriftSqlType.int, data['${effectivePrefix}id_solicitacao_servico']),
      idTipoContrato: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id_tipo_contrato']),
      numero: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}numero']),
      nome: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}nome']),
      descricao: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}descricao']),
      dataCadastro: attachedDatabase.typeMapping
          .read(DriftSqlType.dateTime, data['${effectivePrefix}data_cadastro']),
      dataInicioVigencia: attachedDatabase.typeMapping.read(
          DriftSqlType.dateTime,
          data['${effectivePrefix}data_inicio_vigencia']),
      dataFimVigencia: attachedDatabase.typeMapping.read(
          DriftSqlType.dateTime, data['${effectivePrefix}data_fim_vigencia']),
      diaFaturamento: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}dia_faturamento']),
      valor: attachedDatabase.typeMapping
          .read(DriftSqlType.double, data['${effectivePrefix}valor']),
      quantidadeParcelas: attachedDatabase.typeMapping.read(
          DriftSqlType.int, data['${effectivePrefix}quantidade_parcelas']),
      intervaloEntreParcelas: attachedDatabase.typeMapping.read(
          DriftSqlType.int, data['${effectivePrefix}intervalo_entre_parcelas']),
      classificacaoContabilConta: attachedDatabase.typeMapping.read(
          DriftSqlType.string,
          data['${effectivePrefix}classificacao_contabil_conta']),
      observacao: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}observacao']),
    );
  }

  @override
  $ContratosTable createAlias(String alias) {
    return $ContratosTable(attachedDatabase, alias);
  }
}

class Contrato extends DataClass implements Insertable<Contrato> {
  final int? id;
  final int? idSolicitacaoServico;
  final int? idTipoContrato;
  final String? numero;
  final String? nome;
  final String? descricao;
  final DateTime? dataCadastro;
  final DateTime? dataInicioVigencia;
  final DateTime? dataFimVigencia;
  final String? diaFaturamento;
  final double? valor;
  final int? quantidadeParcelas;
  final int? intervaloEntreParcelas;
  final String? classificacaoContabilConta;
  final String? observacao;
  const Contrato(
      {this.id,
      this.idSolicitacaoServico,
      this.idTipoContrato,
      this.numero,
      this.nome,
      this.descricao,
      this.dataCadastro,
      this.dataInicioVigencia,
      this.dataFimVigencia,
      this.diaFaturamento,
      this.valor,
      this.quantidadeParcelas,
      this.intervaloEntreParcelas,
      this.classificacaoContabilConta,
      this.observacao});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || idSolicitacaoServico != null) {
      map['id_solicitacao_servico'] = Variable<int>(idSolicitacaoServico);
    }
    if (!nullToAbsent || idTipoContrato != null) {
      map['id_tipo_contrato'] = Variable<int>(idTipoContrato);
    }
    if (!nullToAbsent || numero != null) {
      map['numero'] = Variable<String>(numero);
    }
    if (!nullToAbsent || nome != null) {
      map['nome'] = Variable<String>(nome);
    }
    if (!nullToAbsent || descricao != null) {
      map['descricao'] = Variable<String>(descricao);
    }
    if (!nullToAbsent || dataCadastro != null) {
      map['data_cadastro'] = Variable<DateTime>(dataCadastro);
    }
    if (!nullToAbsent || dataInicioVigencia != null) {
      map['data_inicio_vigencia'] = Variable<DateTime>(dataInicioVigencia);
    }
    if (!nullToAbsent || dataFimVigencia != null) {
      map['data_fim_vigencia'] = Variable<DateTime>(dataFimVigencia);
    }
    if (!nullToAbsent || diaFaturamento != null) {
      map['dia_faturamento'] = Variable<String>(diaFaturamento);
    }
    if (!nullToAbsent || valor != null) {
      map['valor'] = Variable<double>(valor);
    }
    if (!nullToAbsent || quantidadeParcelas != null) {
      map['quantidade_parcelas'] = Variable<int>(quantidadeParcelas);
    }
    if (!nullToAbsent || intervaloEntreParcelas != null) {
      map['intervalo_entre_parcelas'] = Variable<int>(intervaloEntreParcelas);
    }
    if (!nullToAbsent || classificacaoContabilConta != null) {
      map['classificacao_contabil_conta'] =
          Variable<String>(classificacaoContabilConta);
    }
    if (!nullToAbsent || observacao != null) {
      map['observacao'] = Variable<String>(observacao);
    }
    return map;
  }

  factory Contrato.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return Contrato(
      id: serializer.fromJson<int?>(json['id']),
      idSolicitacaoServico:
          serializer.fromJson<int?>(json['idSolicitacaoServico']),
      idTipoContrato: serializer.fromJson<int?>(json['idTipoContrato']),
      numero: serializer.fromJson<String?>(json['numero']),
      nome: serializer.fromJson<String?>(json['nome']),
      descricao: serializer.fromJson<String?>(json['descricao']),
      dataCadastro: serializer.fromJson<DateTime?>(json['dataCadastro']),
      dataInicioVigencia:
          serializer.fromJson<DateTime?>(json['dataInicioVigencia']),
      dataFimVigencia: serializer.fromJson<DateTime?>(json['dataFimVigencia']),
      diaFaturamento: serializer.fromJson<String?>(json['diaFaturamento']),
      valor: serializer.fromJson<double?>(json['valor']),
      quantidadeParcelas: serializer.fromJson<int?>(json['quantidadeParcelas']),
      intervaloEntreParcelas:
          serializer.fromJson<int?>(json['intervaloEntreParcelas']),
      classificacaoContabilConta:
          serializer.fromJson<String?>(json['classificacaoContabilConta']),
      observacao: serializer.fromJson<String?>(json['observacao']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'idSolicitacaoServico': serializer.toJson<int?>(idSolicitacaoServico),
      'idTipoContrato': serializer.toJson<int?>(idTipoContrato),
      'numero': serializer.toJson<String?>(numero),
      'nome': serializer.toJson<String?>(nome),
      'descricao': serializer.toJson<String?>(descricao),
      'dataCadastro': serializer.toJson<DateTime?>(dataCadastro),
      'dataInicioVigencia': serializer.toJson<DateTime?>(dataInicioVigencia),
      'dataFimVigencia': serializer.toJson<DateTime?>(dataFimVigencia),
      'diaFaturamento': serializer.toJson<String?>(diaFaturamento),
      'valor': serializer.toJson<double?>(valor),
      'quantidadeParcelas': serializer.toJson<int?>(quantidadeParcelas),
      'intervaloEntreParcelas': serializer.toJson<int?>(intervaloEntreParcelas),
      'classificacaoContabilConta':
          serializer.toJson<String?>(classificacaoContabilConta),
      'observacao': serializer.toJson<String?>(observacao),
    };
  }

  Contrato copyWith(
          {Value<int?> id = const Value.absent(),
          Value<int?> idSolicitacaoServico = const Value.absent(),
          Value<int?> idTipoContrato = const Value.absent(),
          Value<String?> numero = const Value.absent(),
          Value<String?> nome = const Value.absent(),
          Value<String?> descricao = const Value.absent(),
          Value<DateTime?> dataCadastro = const Value.absent(),
          Value<DateTime?> dataInicioVigencia = const Value.absent(),
          Value<DateTime?> dataFimVigencia = const Value.absent(),
          Value<String?> diaFaturamento = const Value.absent(),
          Value<double?> valor = const Value.absent(),
          Value<int?> quantidadeParcelas = const Value.absent(),
          Value<int?> intervaloEntreParcelas = const Value.absent(),
          Value<String?> classificacaoContabilConta = const Value.absent(),
          Value<String?> observacao = const Value.absent()}) =>
      Contrato(
        id: id.present ? id.value : this.id,
        idSolicitacaoServico: idSolicitacaoServico.present
            ? idSolicitacaoServico.value
            : this.idSolicitacaoServico,
        idTipoContrato:
            idTipoContrato.present ? idTipoContrato.value : this.idTipoContrato,
        numero: numero.present ? numero.value : this.numero,
        nome: nome.present ? nome.value : this.nome,
        descricao: descricao.present ? descricao.value : this.descricao,
        dataCadastro:
            dataCadastro.present ? dataCadastro.value : this.dataCadastro,
        dataInicioVigencia: dataInicioVigencia.present
            ? dataInicioVigencia.value
            : this.dataInicioVigencia,
        dataFimVigencia: dataFimVigencia.present
            ? dataFimVigencia.value
            : this.dataFimVigencia,
        diaFaturamento:
            diaFaturamento.present ? diaFaturamento.value : this.diaFaturamento,
        valor: valor.present ? valor.value : this.valor,
        quantidadeParcelas: quantidadeParcelas.present
            ? quantidadeParcelas.value
            : this.quantidadeParcelas,
        intervaloEntreParcelas: intervaloEntreParcelas.present
            ? intervaloEntreParcelas.value
            : this.intervaloEntreParcelas,
        classificacaoContabilConta: classificacaoContabilConta.present
            ? classificacaoContabilConta.value
            : this.classificacaoContabilConta,
        observacao: observacao.present ? observacao.value : this.observacao,
      );
  Contrato copyWithCompanion(ContratosCompanion data) {
    return Contrato(
      id: data.id.present ? data.id.value : this.id,
      idSolicitacaoServico: data.idSolicitacaoServico.present
          ? data.idSolicitacaoServico.value
          : this.idSolicitacaoServico,
      idTipoContrato: data.idTipoContrato.present
          ? data.idTipoContrato.value
          : this.idTipoContrato,
      numero: data.numero.present ? data.numero.value : this.numero,
      nome: data.nome.present ? data.nome.value : this.nome,
      descricao: data.descricao.present ? data.descricao.value : this.descricao,
      dataCadastro: data.dataCadastro.present
          ? data.dataCadastro.value
          : this.dataCadastro,
      dataInicioVigencia: data.dataInicioVigencia.present
          ? data.dataInicioVigencia.value
          : this.dataInicioVigencia,
      dataFimVigencia: data.dataFimVigencia.present
          ? data.dataFimVigencia.value
          : this.dataFimVigencia,
      diaFaturamento: data.diaFaturamento.present
          ? data.diaFaturamento.value
          : this.diaFaturamento,
      valor: data.valor.present ? data.valor.value : this.valor,
      quantidadeParcelas: data.quantidadeParcelas.present
          ? data.quantidadeParcelas.value
          : this.quantidadeParcelas,
      intervaloEntreParcelas: data.intervaloEntreParcelas.present
          ? data.intervaloEntreParcelas.value
          : this.intervaloEntreParcelas,
      classificacaoContabilConta: data.classificacaoContabilConta.present
          ? data.classificacaoContabilConta.value
          : this.classificacaoContabilConta,
      observacao:
          data.observacao.present ? data.observacao.value : this.observacao,
    );
  }

  @override
  String toString() {
    return (StringBuffer('Contrato(')
          ..write('id: $id, ')
          ..write('idSolicitacaoServico: $idSolicitacaoServico, ')
          ..write('idTipoContrato: $idTipoContrato, ')
          ..write('numero: $numero, ')
          ..write('nome: $nome, ')
          ..write('descricao: $descricao, ')
          ..write('dataCadastro: $dataCadastro, ')
          ..write('dataInicioVigencia: $dataInicioVigencia, ')
          ..write('dataFimVigencia: $dataFimVigencia, ')
          ..write('diaFaturamento: $diaFaturamento, ')
          ..write('valor: $valor, ')
          ..write('quantidadeParcelas: $quantidadeParcelas, ')
          ..write('intervaloEntreParcelas: $intervaloEntreParcelas, ')
          ..write('classificacaoContabilConta: $classificacaoContabilConta, ')
          ..write('observacao: $observacao')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(
      id,
      idSolicitacaoServico,
      idTipoContrato,
      numero,
      nome,
      descricao,
      dataCadastro,
      dataInicioVigencia,
      dataFimVigencia,
      diaFaturamento,
      valor,
      quantidadeParcelas,
      intervaloEntreParcelas,
      classificacaoContabilConta,
      observacao);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is Contrato &&
          other.id == this.id &&
          other.idSolicitacaoServico == this.idSolicitacaoServico &&
          other.idTipoContrato == this.idTipoContrato &&
          other.numero == this.numero &&
          other.nome == this.nome &&
          other.descricao == this.descricao &&
          other.dataCadastro == this.dataCadastro &&
          other.dataInicioVigencia == this.dataInicioVigencia &&
          other.dataFimVigencia == this.dataFimVigencia &&
          other.diaFaturamento == this.diaFaturamento &&
          other.valor == this.valor &&
          other.quantidadeParcelas == this.quantidadeParcelas &&
          other.intervaloEntreParcelas == this.intervaloEntreParcelas &&
          other.classificacaoContabilConta == this.classificacaoContabilConta &&
          other.observacao == this.observacao);
}

class ContratosCompanion extends UpdateCompanion<Contrato> {
  final Value<int?> id;
  final Value<int?> idSolicitacaoServico;
  final Value<int?> idTipoContrato;
  final Value<String?> numero;
  final Value<String?> nome;
  final Value<String?> descricao;
  final Value<DateTime?> dataCadastro;
  final Value<DateTime?> dataInicioVigencia;
  final Value<DateTime?> dataFimVigencia;
  final Value<String?> diaFaturamento;
  final Value<double?> valor;
  final Value<int?> quantidadeParcelas;
  final Value<int?> intervaloEntreParcelas;
  final Value<String?> classificacaoContabilConta;
  final Value<String?> observacao;
  const ContratosCompanion({
    this.id = const Value.absent(),
    this.idSolicitacaoServico = const Value.absent(),
    this.idTipoContrato = const Value.absent(),
    this.numero = const Value.absent(),
    this.nome = const Value.absent(),
    this.descricao = const Value.absent(),
    this.dataCadastro = const Value.absent(),
    this.dataInicioVigencia = const Value.absent(),
    this.dataFimVigencia = const Value.absent(),
    this.diaFaturamento = const Value.absent(),
    this.valor = const Value.absent(),
    this.quantidadeParcelas = const Value.absent(),
    this.intervaloEntreParcelas = const Value.absent(),
    this.classificacaoContabilConta = const Value.absent(),
    this.observacao = const Value.absent(),
  });
  ContratosCompanion.insert({
    this.id = const Value.absent(),
    this.idSolicitacaoServico = const Value.absent(),
    this.idTipoContrato = const Value.absent(),
    this.numero = const Value.absent(),
    this.nome = const Value.absent(),
    this.descricao = const Value.absent(),
    this.dataCadastro = const Value.absent(),
    this.dataInicioVigencia = const Value.absent(),
    this.dataFimVigencia = const Value.absent(),
    this.diaFaturamento = const Value.absent(),
    this.valor = const Value.absent(),
    this.quantidadeParcelas = const Value.absent(),
    this.intervaloEntreParcelas = const Value.absent(),
    this.classificacaoContabilConta = const Value.absent(),
    this.observacao = const Value.absent(),
  });
  static Insertable<Contrato> custom({
    Expression<int>? id,
    Expression<int>? idSolicitacaoServico,
    Expression<int>? idTipoContrato,
    Expression<String>? numero,
    Expression<String>? nome,
    Expression<String>? descricao,
    Expression<DateTime>? dataCadastro,
    Expression<DateTime>? dataInicioVigencia,
    Expression<DateTime>? dataFimVigencia,
    Expression<String>? diaFaturamento,
    Expression<double>? valor,
    Expression<int>? quantidadeParcelas,
    Expression<int>? intervaloEntreParcelas,
    Expression<String>? classificacaoContabilConta,
    Expression<String>? observacao,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (idSolicitacaoServico != null)
        'id_solicitacao_servico': idSolicitacaoServico,
      if (idTipoContrato != null) 'id_tipo_contrato': idTipoContrato,
      if (numero != null) 'numero': numero,
      if (nome != null) 'nome': nome,
      if (descricao != null) 'descricao': descricao,
      if (dataCadastro != null) 'data_cadastro': dataCadastro,
      if (dataInicioVigencia != null)
        'data_inicio_vigencia': dataInicioVigencia,
      if (dataFimVigencia != null) 'data_fim_vigencia': dataFimVigencia,
      if (diaFaturamento != null) 'dia_faturamento': diaFaturamento,
      if (valor != null) 'valor': valor,
      if (quantidadeParcelas != null) 'quantidade_parcelas': quantidadeParcelas,
      if (intervaloEntreParcelas != null)
        'intervalo_entre_parcelas': intervaloEntreParcelas,
      if (classificacaoContabilConta != null)
        'classificacao_contabil_conta': classificacaoContabilConta,
      if (observacao != null) 'observacao': observacao,
    });
  }

  ContratosCompanion copyWith(
      {Value<int?>? id,
      Value<int?>? idSolicitacaoServico,
      Value<int?>? idTipoContrato,
      Value<String?>? numero,
      Value<String?>? nome,
      Value<String?>? descricao,
      Value<DateTime?>? dataCadastro,
      Value<DateTime?>? dataInicioVigencia,
      Value<DateTime?>? dataFimVigencia,
      Value<String?>? diaFaturamento,
      Value<double?>? valor,
      Value<int?>? quantidadeParcelas,
      Value<int?>? intervaloEntreParcelas,
      Value<String?>? classificacaoContabilConta,
      Value<String?>? observacao}) {
    return ContratosCompanion(
      id: id ?? this.id,
      idSolicitacaoServico: idSolicitacaoServico ?? this.idSolicitacaoServico,
      idTipoContrato: idTipoContrato ?? this.idTipoContrato,
      numero: numero ?? this.numero,
      nome: nome ?? this.nome,
      descricao: descricao ?? this.descricao,
      dataCadastro: dataCadastro ?? this.dataCadastro,
      dataInicioVigencia: dataInicioVigencia ?? this.dataInicioVigencia,
      dataFimVigencia: dataFimVigencia ?? this.dataFimVigencia,
      diaFaturamento: diaFaturamento ?? this.diaFaturamento,
      valor: valor ?? this.valor,
      quantidadeParcelas: quantidadeParcelas ?? this.quantidadeParcelas,
      intervaloEntreParcelas:
          intervaloEntreParcelas ?? this.intervaloEntreParcelas,
      classificacaoContabilConta:
          classificacaoContabilConta ?? this.classificacaoContabilConta,
      observacao: observacao ?? this.observacao,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (idSolicitacaoServico.present) {
      map['id_solicitacao_servico'] = Variable<int>(idSolicitacaoServico.value);
    }
    if (idTipoContrato.present) {
      map['id_tipo_contrato'] = Variable<int>(idTipoContrato.value);
    }
    if (numero.present) {
      map['numero'] = Variable<String>(numero.value);
    }
    if (nome.present) {
      map['nome'] = Variable<String>(nome.value);
    }
    if (descricao.present) {
      map['descricao'] = Variable<String>(descricao.value);
    }
    if (dataCadastro.present) {
      map['data_cadastro'] = Variable<DateTime>(dataCadastro.value);
    }
    if (dataInicioVigencia.present) {
      map['data_inicio_vigencia'] =
          Variable<DateTime>(dataInicioVigencia.value);
    }
    if (dataFimVigencia.present) {
      map['data_fim_vigencia'] = Variable<DateTime>(dataFimVigencia.value);
    }
    if (diaFaturamento.present) {
      map['dia_faturamento'] = Variable<String>(diaFaturamento.value);
    }
    if (valor.present) {
      map['valor'] = Variable<double>(valor.value);
    }
    if (quantidadeParcelas.present) {
      map['quantidade_parcelas'] = Variable<int>(quantidadeParcelas.value);
    }
    if (intervaloEntreParcelas.present) {
      map['intervalo_entre_parcelas'] =
          Variable<int>(intervaloEntreParcelas.value);
    }
    if (classificacaoContabilConta.present) {
      map['classificacao_contabil_conta'] =
          Variable<String>(classificacaoContabilConta.value);
    }
    if (observacao.present) {
      map['observacao'] = Variable<String>(observacao.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('ContratosCompanion(')
          ..write('id: $id, ')
          ..write('idSolicitacaoServico: $idSolicitacaoServico, ')
          ..write('idTipoContrato: $idTipoContrato, ')
          ..write('numero: $numero, ')
          ..write('nome: $nome, ')
          ..write('descricao: $descricao, ')
          ..write('dataCadastro: $dataCadastro, ')
          ..write('dataInicioVigencia: $dataInicioVigencia, ')
          ..write('dataFimVigencia: $dataFimVigencia, ')
          ..write('diaFaturamento: $diaFaturamento, ')
          ..write('valor: $valor, ')
          ..write('quantidadeParcelas: $quantidadeParcelas, ')
          ..write('intervaloEntreParcelas: $intervaloEntreParcelas, ')
          ..write('classificacaoContabilConta: $classificacaoContabilConta, ')
          ..write('observacao: $observacao')
          ..write(')'))
        .toString();
  }
}

class $SetorsTable extends Setors with TableInfo<$SetorsTable, Setor> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $SetorsTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
      'id', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _nomeMeta = const VerificationMeta('nome');
  @override
  late final GeneratedColumn<String> nome = GeneratedColumn<String>(
      'nome', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 100),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _descricaoMeta =
      const VerificationMeta('descricao');
  @override
  late final GeneratedColumn<String> descricao = GeneratedColumn<String>(
      'descricao', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 250),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  @override
  List<GeneratedColumn> get $columns => [id, nome, descricao];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'setor';
  @override
  VerificationContext validateIntegrity(Insertable<Setor> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('nome')) {
      context.handle(
          _nomeMeta, nome.isAcceptableOrUnknown(data['nome']!, _nomeMeta));
    }
    if (data.containsKey('descricao')) {
      context.handle(_descricaoMeta,
          descricao.isAcceptableOrUnknown(data['descricao']!, _descricaoMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  Setor map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return Setor(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id']),
      nome: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}nome']),
      descricao: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}descricao']),
    );
  }

  @override
  $SetorsTable createAlias(String alias) {
    return $SetorsTable(attachedDatabase, alias);
  }
}

class Setor extends DataClass implements Insertable<Setor> {
  final int? id;
  final String? nome;
  final String? descricao;
  const Setor({this.id, this.nome, this.descricao});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || nome != null) {
      map['nome'] = Variable<String>(nome);
    }
    if (!nullToAbsent || descricao != null) {
      map['descricao'] = Variable<String>(descricao);
    }
    return map;
  }

  factory Setor.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return Setor(
      id: serializer.fromJson<int?>(json['id']),
      nome: serializer.fromJson<String?>(json['nome']),
      descricao: serializer.fromJson<String?>(json['descricao']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'nome': serializer.toJson<String?>(nome),
      'descricao': serializer.toJson<String?>(descricao),
    };
  }

  Setor copyWith(
          {Value<int?> id = const Value.absent(),
          Value<String?> nome = const Value.absent(),
          Value<String?> descricao = const Value.absent()}) =>
      Setor(
        id: id.present ? id.value : this.id,
        nome: nome.present ? nome.value : this.nome,
        descricao: descricao.present ? descricao.value : this.descricao,
      );
  Setor copyWithCompanion(SetorsCompanion data) {
    return Setor(
      id: data.id.present ? data.id.value : this.id,
      nome: data.nome.present ? data.nome.value : this.nome,
      descricao: data.descricao.present ? data.descricao.value : this.descricao,
    );
  }

  @override
  String toString() {
    return (StringBuffer('Setor(')
          ..write('id: $id, ')
          ..write('nome: $nome, ')
          ..write('descricao: $descricao')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(id, nome, descricao);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is Setor &&
          other.id == this.id &&
          other.nome == this.nome &&
          other.descricao == this.descricao);
}

class SetorsCompanion extends UpdateCompanion<Setor> {
  final Value<int?> id;
  final Value<String?> nome;
  final Value<String?> descricao;
  const SetorsCompanion({
    this.id = const Value.absent(),
    this.nome = const Value.absent(),
    this.descricao = const Value.absent(),
  });
  SetorsCompanion.insert({
    this.id = const Value.absent(),
    this.nome = const Value.absent(),
    this.descricao = const Value.absent(),
  });
  static Insertable<Setor> custom({
    Expression<int>? id,
    Expression<String>? nome,
    Expression<String>? descricao,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (nome != null) 'nome': nome,
      if (descricao != null) 'descricao': descricao,
    });
  }

  SetorsCompanion copyWith(
      {Value<int?>? id, Value<String?>? nome, Value<String?>? descricao}) {
    return SetorsCompanion(
      id: id ?? this.id,
      nome: nome ?? this.nome,
      descricao: descricao ?? this.descricao,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (nome.present) {
      map['nome'] = Variable<String>(nome.value);
    }
    if (descricao.present) {
      map['descricao'] = Variable<String>(descricao.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('SetorsCompanion(')
          ..write('id: $id, ')
          ..write('nome: $nome, ')
          ..write('descricao: $descricao')
          ..write(')'))
        .toString();
  }
}

class $TipoContratosTable extends TipoContratos
    with TableInfo<$TipoContratosTable, TipoContrato> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $TipoContratosTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
      'id', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _nomeMeta = const VerificationMeta('nome');
  @override
  late final GeneratedColumn<String> nome = GeneratedColumn<String>(
      'nome', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 50),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _descricaoMeta =
      const VerificationMeta('descricao');
  @override
  late final GeneratedColumn<String> descricao = GeneratedColumn<String>(
      'descricao', aliasedName, true,
      type: DriftSqlType.string, requiredDuringInsert: false);
  @override
  List<GeneratedColumn> get $columns => [id, nome, descricao];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'tipo_contrato';
  @override
  VerificationContext validateIntegrity(Insertable<TipoContrato> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('nome')) {
      context.handle(
          _nomeMeta, nome.isAcceptableOrUnknown(data['nome']!, _nomeMeta));
    }
    if (data.containsKey('descricao')) {
      context.handle(_descricaoMeta,
          descricao.isAcceptableOrUnknown(data['descricao']!, _descricaoMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  TipoContrato map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return TipoContrato(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id']),
      nome: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}nome']),
      descricao: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}descricao']),
    );
  }

  @override
  $TipoContratosTable createAlias(String alias) {
    return $TipoContratosTable(attachedDatabase, alias);
  }
}

class TipoContrato extends DataClass implements Insertable<TipoContrato> {
  final int? id;
  final String? nome;
  final String? descricao;
  const TipoContrato({this.id, this.nome, this.descricao});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || nome != null) {
      map['nome'] = Variable<String>(nome);
    }
    if (!nullToAbsent || descricao != null) {
      map['descricao'] = Variable<String>(descricao);
    }
    return map;
  }

  factory TipoContrato.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return TipoContrato(
      id: serializer.fromJson<int?>(json['id']),
      nome: serializer.fromJson<String?>(json['nome']),
      descricao: serializer.fromJson<String?>(json['descricao']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'nome': serializer.toJson<String?>(nome),
      'descricao': serializer.toJson<String?>(descricao),
    };
  }

  TipoContrato copyWith(
          {Value<int?> id = const Value.absent(),
          Value<String?> nome = const Value.absent(),
          Value<String?> descricao = const Value.absent()}) =>
      TipoContrato(
        id: id.present ? id.value : this.id,
        nome: nome.present ? nome.value : this.nome,
        descricao: descricao.present ? descricao.value : this.descricao,
      );
  TipoContrato copyWithCompanion(TipoContratosCompanion data) {
    return TipoContrato(
      id: data.id.present ? data.id.value : this.id,
      nome: data.nome.present ? data.nome.value : this.nome,
      descricao: data.descricao.present ? data.descricao.value : this.descricao,
    );
  }

  @override
  String toString() {
    return (StringBuffer('TipoContrato(')
          ..write('id: $id, ')
          ..write('nome: $nome, ')
          ..write('descricao: $descricao')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(id, nome, descricao);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is TipoContrato &&
          other.id == this.id &&
          other.nome == this.nome &&
          other.descricao == this.descricao);
}

class TipoContratosCompanion extends UpdateCompanion<TipoContrato> {
  final Value<int?> id;
  final Value<String?> nome;
  final Value<String?> descricao;
  const TipoContratosCompanion({
    this.id = const Value.absent(),
    this.nome = const Value.absent(),
    this.descricao = const Value.absent(),
  });
  TipoContratosCompanion.insert({
    this.id = const Value.absent(),
    this.nome = const Value.absent(),
    this.descricao = const Value.absent(),
  });
  static Insertable<TipoContrato> custom({
    Expression<int>? id,
    Expression<String>? nome,
    Expression<String>? descricao,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (nome != null) 'nome': nome,
      if (descricao != null) 'descricao': descricao,
    });
  }

  TipoContratosCompanion copyWith(
      {Value<int?>? id, Value<String?>? nome, Value<String?>? descricao}) {
    return TipoContratosCompanion(
      id: id ?? this.id,
      nome: nome ?? this.nome,
      descricao: descricao ?? this.descricao,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (nome.present) {
      map['nome'] = Variable<String>(nome.value);
    }
    if (descricao.present) {
      map['descricao'] = Variable<String>(descricao.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('TipoContratosCompanion(')
          ..write('id: $id, ')
          ..write('nome: $nome, ')
          ..write('descricao: $descricao')
          ..write(')'))
        .toString();
  }
}

class $ContratoTipoServicosTable extends ContratoTipoServicos
    with TableInfo<$ContratoTipoServicosTable, ContratoTipoServico> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $ContratoTipoServicosTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
      'id', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _nomeMeta = const VerificationMeta('nome');
  @override
  late final GeneratedColumn<String> nome = GeneratedColumn<String>(
      'nome', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 50),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _descricaoMeta =
      const VerificationMeta('descricao');
  @override
  late final GeneratedColumn<String> descricao = GeneratedColumn<String>(
      'descricao', aliasedName, true,
      type: DriftSqlType.string, requiredDuringInsert: false);
  @override
  List<GeneratedColumn> get $columns => [id, nome, descricao];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'contrato_tipo_servico';
  @override
  VerificationContext validateIntegrity(
      Insertable<ContratoTipoServico> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('nome')) {
      context.handle(
          _nomeMeta, nome.isAcceptableOrUnknown(data['nome']!, _nomeMeta));
    }
    if (data.containsKey('descricao')) {
      context.handle(_descricaoMeta,
          descricao.isAcceptableOrUnknown(data['descricao']!, _descricaoMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  ContratoTipoServico map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return ContratoTipoServico(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id']),
      nome: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}nome']),
      descricao: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}descricao']),
    );
  }

  @override
  $ContratoTipoServicosTable createAlias(String alias) {
    return $ContratoTipoServicosTable(attachedDatabase, alias);
  }
}

class ContratoTipoServico extends DataClass
    implements Insertable<ContratoTipoServico> {
  final int? id;
  final String? nome;
  final String? descricao;
  const ContratoTipoServico({this.id, this.nome, this.descricao});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || nome != null) {
      map['nome'] = Variable<String>(nome);
    }
    if (!nullToAbsent || descricao != null) {
      map['descricao'] = Variable<String>(descricao);
    }
    return map;
  }

  factory ContratoTipoServico.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return ContratoTipoServico(
      id: serializer.fromJson<int?>(json['id']),
      nome: serializer.fromJson<String?>(json['nome']),
      descricao: serializer.fromJson<String?>(json['descricao']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'nome': serializer.toJson<String?>(nome),
      'descricao': serializer.toJson<String?>(descricao),
    };
  }

  ContratoTipoServico copyWith(
          {Value<int?> id = const Value.absent(),
          Value<String?> nome = const Value.absent(),
          Value<String?> descricao = const Value.absent()}) =>
      ContratoTipoServico(
        id: id.present ? id.value : this.id,
        nome: nome.present ? nome.value : this.nome,
        descricao: descricao.present ? descricao.value : this.descricao,
      );
  ContratoTipoServico copyWithCompanion(ContratoTipoServicosCompanion data) {
    return ContratoTipoServico(
      id: data.id.present ? data.id.value : this.id,
      nome: data.nome.present ? data.nome.value : this.nome,
      descricao: data.descricao.present ? data.descricao.value : this.descricao,
    );
  }

  @override
  String toString() {
    return (StringBuffer('ContratoTipoServico(')
          ..write('id: $id, ')
          ..write('nome: $nome, ')
          ..write('descricao: $descricao')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(id, nome, descricao);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is ContratoTipoServico &&
          other.id == this.id &&
          other.nome == this.nome &&
          other.descricao == this.descricao);
}

class ContratoTipoServicosCompanion
    extends UpdateCompanion<ContratoTipoServico> {
  final Value<int?> id;
  final Value<String?> nome;
  final Value<String?> descricao;
  const ContratoTipoServicosCompanion({
    this.id = const Value.absent(),
    this.nome = const Value.absent(),
    this.descricao = const Value.absent(),
  });
  ContratoTipoServicosCompanion.insert({
    this.id = const Value.absent(),
    this.nome = const Value.absent(),
    this.descricao = const Value.absent(),
  });
  static Insertable<ContratoTipoServico> custom({
    Expression<int>? id,
    Expression<String>? nome,
    Expression<String>? descricao,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (nome != null) 'nome': nome,
      if (descricao != null) 'descricao': descricao,
    });
  }

  ContratoTipoServicosCompanion copyWith(
      {Value<int?>? id, Value<String?>? nome, Value<String?>? descricao}) {
    return ContratoTipoServicosCompanion(
      id: id ?? this.id,
      nome: nome ?? this.nome,
      descricao: descricao ?? this.descricao,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (nome.present) {
      map['nome'] = Variable<String>(nome.value);
    }
    if (descricao.present) {
      map['descricao'] = Variable<String>(descricao.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('ContratoTipoServicosCompanion(')
          ..write('id: $id, ')
          ..write('nome: $nome, ')
          ..write('descricao: $descricao')
          ..write(')'))
        .toString();
  }
}

class $ContratoSolicitacaoServicosTable extends ContratoSolicitacaoServicos
    with
        TableInfo<$ContratoSolicitacaoServicosTable,
            ContratoSolicitacaoServico> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $ContratoSolicitacaoServicosTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
      'id', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _idContratoTipoServicoMeta =
      const VerificationMeta('idContratoTipoServico');
  @override
  late final GeneratedColumn<int> idContratoTipoServico = GeneratedColumn<int>(
      'id_contrato_tipo_servico', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _idSetorMeta =
      const VerificationMeta('idSetor');
  @override
  late final GeneratedColumn<int> idSetor = GeneratedColumn<int>(
      'id_setor', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _idColaboradorMeta =
      const VerificationMeta('idColaborador');
  @override
  late final GeneratedColumn<int> idColaborador = GeneratedColumn<int>(
      'id_colaborador', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _idClienteMeta =
      const VerificationMeta('idCliente');
  @override
  late final GeneratedColumn<int> idCliente = GeneratedColumn<int>(
      'id_cliente', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _idFornecedorMeta =
      const VerificationMeta('idFornecedor');
  @override
  late final GeneratedColumn<int> idFornecedor = GeneratedColumn<int>(
      'id_fornecedor', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _dataSolicitacaoMeta =
      const VerificationMeta('dataSolicitacao');
  @override
  late final GeneratedColumn<DateTime> dataSolicitacao =
      GeneratedColumn<DateTime>('data_solicitacao', aliasedName, true,
          type: DriftSqlType.dateTime, requiredDuringInsert: false);
  static const VerificationMeta _dataDesejadaInicioMeta =
      const VerificationMeta('dataDesejadaInicio');
  @override
  late final GeneratedColumn<DateTime> dataDesejadaInicio =
      GeneratedColumn<DateTime>('data_desejada_inicio', aliasedName, true,
          type: DriftSqlType.dateTime, requiredDuringInsert: false);
  static const VerificationMeta _urgenteMeta =
      const VerificationMeta('urgente');
  @override
  late final GeneratedColumn<String> urgente = GeneratedColumn<String>(
      'urgente', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 1),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _statusSolicitacaoMeta =
      const VerificationMeta('statusSolicitacao');
  @override
  late final GeneratedColumn<String> statusSolicitacao =
      GeneratedColumn<String>('status_solicitacao', aliasedName, true,
          additionalChecks: GeneratedColumn.checkTextLength(
              minTextLength: 0, maxTextLength: 1),
          type: DriftSqlType.string,
          requiredDuringInsert: false);
  static const VerificationMeta _descricaoMeta =
      const VerificationMeta('descricao');
  @override
  late final GeneratedColumn<String> descricao = GeneratedColumn<String>(
      'descricao', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 100),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  @override
  List<GeneratedColumn> get $columns => [
        id,
        idContratoTipoServico,
        idSetor,
        idColaborador,
        idCliente,
        idFornecedor,
        dataSolicitacao,
        dataDesejadaInicio,
        urgente,
        statusSolicitacao,
        descricao
      ];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'contrato_solicitacao_servico';
  @override
  VerificationContext validateIntegrity(
      Insertable<ContratoSolicitacaoServico> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('id_contrato_tipo_servico')) {
      context.handle(
          _idContratoTipoServicoMeta,
          idContratoTipoServico.isAcceptableOrUnknown(
              data['id_contrato_tipo_servico']!, _idContratoTipoServicoMeta));
    }
    if (data.containsKey('id_setor')) {
      context.handle(_idSetorMeta,
          idSetor.isAcceptableOrUnknown(data['id_setor']!, _idSetorMeta));
    }
    if (data.containsKey('id_colaborador')) {
      context.handle(
          _idColaboradorMeta,
          idColaborador.isAcceptableOrUnknown(
              data['id_colaborador']!, _idColaboradorMeta));
    }
    if (data.containsKey('id_cliente')) {
      context.handle(_idClienteMeta,
          idCliente.isAcceptableOrUnknown(data['id_cliente']!, _idClienteMeta));
    }
    if (data.containsKey('id_fornecedor')) {
      context.handle(
          _idFornecedorMeta,
          idFornecedor.isAcceptableOrUnknown(
              data['id_fornecedor']!, _idFornecedorMeta));
    }
    if (data.containsKey('data_solicitacao')) {
      context.handle(
          _dataSolicitacaoMeta,
          dataSolicitacao.isAcceptableOrUnknown(
              data['data_solicitacao']!, _dataSolicitacaoMeta));
    }
    if (data.containsKey('data_desejada_inicio')) {
      context.handle(
          _dataDesejadaInicioMeta,
          dataDesejadaInicio.isAcceptableOrUnknown(
              data['data_desejada_inicio']!, _dataDesejadaInicioMeta));
    }
    if (data.containsKey('urgente')) {
      context.handle(_urgenteMeta,
          urgente.isAcceptableOrUnknown(data['urgente']!, _urgenteMeta));
    }
    if (data.containsKey('status_solicitacao')) {
      context.handle(
          _statusSolicitacaoMeta,
          statusSolicitacao.isAcceptableOrUnknown(
              data['status_solicitacao']!, _statusSolicitacaoMeta));
    }
    if (data.containsKey('descricao')) {
      context.handle(_descricaoMeta,
          descricao.isAcceptableOrUnknown(data['descricao']!, _descricaoMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  ContratoSolicitacaoServico map(Map<String, dynamic> data,
      {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return ContratoSolicitacaoServico(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id']),
      idContratoTipoServico: attachedDatabase.typeMapping.read(
          DriftSqlType.int, data['${effectivePrefix}id_contrato_tipo_servico']),
      idSetor: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id_setor']),
      idColaborador: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id_colaborador']),
      idCliente: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id_cliente']),
      idFornecedor: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id_fornecedor']),
      dataSolicitacao: attachedDatabase.typeMapping.read(
          DriftSqlType.dateTime, data['${effectivePrefix}data_solicitacao']),
      dataDesejadaInicio: attachedDatabase.typeMapping.read(
          DriftSqlType.dateTime,
          data['${effectivePrefix}data_desejada_inicio']),
      urgente: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}urgente']),
      statusSolicitacao: attachedDatabase.typeMapping.read(
          DriftSqlType.string, data['${effectivePrefix}status_solicitacao']),
      descricao: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}descricao']),
    );
  }

  @override
  $ContratoSolicitacaoServicosTable createAlias(String alias) {
    return $ContratoSolicitacaoServicosTable(attachedDatabase, alias);
  }
}

class ContratoSolicitacaoServico extends DataClass
    implements Insertable<ContratoSolicitacaoServico> {
  final int? id;
  final int? idContratoTipoServico;
  final int? idSetor;
  final int? idColaborador;
  final int? idCliente;
  final int? idFornecedor;
  final DateTime? dataSolicitacao;
  final DateTime? dataDesejadaInicio;
  final String? urgente;
  final String? statusSolicitacao;
  final String? descricao;
  const ContratoSolicitacaoServico(
      {this.id,
      this.idContratoTipoServico,
      this.idSetor,
      this.idColaborador,
      this.idCliente,
      this.idFornecedor,
      this.dataSolicitacao,
      this.dataDesejadaInicio,
      this.urgente,
      this.statusSolicitacao,
      this.descricao});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || idContratoTipoServico != null) {
      map['id_contrato_tipo_servico'] = Variable<int>(idContratoTipoServico);
    }
    if (!nullToAbsent || idSetor != null) {
      map['id_setor'] = Variable<int>(idSetor);
    }
    if (!nullToAbsent || idColaborador != null) {
      map['id_colaborador'] = Variable<int>(idColaborador);
    }
    if (!nullToAbsent || idCliente != null) {
      map['id_cliente'] = Variable<int>(idCliente);
    }
    if (!nullToAbsent || idFornecedor != null) {
      map['id_fornecedor'] = Variable<int>(idFornecedor);
    }
    if (!nullToAbsent || dataSolicitacao != null) {
      map['data_solicitacao'] = Variable<DateTime>(dataSolicitacao);
    }
    if (!nullToAbsent || dataDesejadaInicio != null) {
      map['data_desejada_inicio'] = Variable<DateTime>(dataDesejadaInicio);
    }
    if (!nullToAbsent || urgente != null) {
      map['urgente'] = Variable<String>(urgente);
    }
    if (!nullToAbsent || statusSolicitacao != null) {
      map['status_solicitacao'] = Variable<String>(statusSolicitacao);
    }
    if (!nullToAbsent || descricao != null) {
      map['descricao'] = Variable<String>(descricao);
    }
    return map;
  }

  factory ContratoSolicitacaoServico.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return ContratoSolicitacaoServico(
      id: serializer.fromJson<int?>(json['id']),
      idContratoTipoServico:
          serializer.fromJson<int?>(json['idContratoTipoServico']),
      idSetor: serializer.fromJson<int?>(json['idSetor']),
      idColaborador: serializer.fromJson<int?>(json['idColaborador']),
      idCliente: serializer.fromJson<int?>(json['idCliente']),
      idFornecedor: serializer.fromJson<int?>(json['idFornecedor']),
      dataSolicitacao: serializer.fromJson<DateTime?>(json['dataSolicitacao']),
      dataDesejadaInicio:
          serializer.fromJson<DateTime?>(json['dataDesejadaInicio']),
      urgente: serializer.fromJson<String?>(json['urgente']),
      statusSolicitacao:
          serializer.fromJson<String?>(json['statusSolicitacao']),
      descricao: serializer.fromJson<String?>(json['descricao']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'idContratoTipoServico': serializer.toJson<int?>(idContratoTipoServico),
      'idSetor': serializer.toJson<int?>(idSetor),
      'idColaborador': serializer.toJson<int?>(idColaborador),
      'idCliente': serializer.toJson<int?>(idCliente),
      'idFornecedor': serializer.toJson<int?>(idFornecedor),
      'dataSolicitacao': serializer.toJson<DateTime?>(dataSolicitacao),
      'dataDesejadaInicio': serializer.toJson<DateTime?>(dataDesejadaInicio),
      'urgente': serializer.toJson<String?>(urgente),
      'statusSolicitacao': serializer.toJson<String?>(statusSolicitacao),
      'descricao': serializer.toJson<String?>(descricao),
    };
  }

  ContratoSolicitacaoServico copyWith(
          {Value<int?> id = const Value.absent(),
          Value<int?> idContratoTipoServico = const Value.absent(),
          Value<int?> idSetor = const Value.absent(),
          Value<int?> idColaborador = const Value.absent(),
          Value<int?> idCliente = const Value.absent(),
          Value<int?> idFornecedor = const Value.absent(),
          Value<DateTime?> dataSolicitacao = const Value.absent(),
          Value<DateTime?> dataDesejadaInicio = const Value.absent(),
          Value<String?> urgente = const Value.absent(),
          Value<String?> statusSolicitacao = const Value.absent(),
          Value<String?> descricao = const Value.absent()}) =>
      ContratoSolicitacaoServico(
        id: id.present ? id.value : this.id,
        idContratoTipoServico: idContratoTipoServico.present
            ? idContratoTipoServico.value
            : this.idContratoTipoServico,
        idSetor: idSetor.present ? idSetor.value : this.idSetor,
        idColaborador:
            idColaborador.present ? idColaborador.value : this.idColaborador,
        idCliente: idCliente.present ? idCliente.value : this.idCliente,
        idFornecedor:
            idFornecedor.present ? idFornecedor.value : this.idFornecedor,
        dataSolicitacao: dataSolicitacao.present
            ? dataSolicitacao.value
            : this.dataSolicitacao,
        dataDesejadaInicio: dataDesejadaInicio.present
            ? dataDesejadaInicio.value
            : this.dataDesejadaInicio,
        urgente: urgente.present ? urgente.value : this.urgente,
        statusSolicitacao: statusSolicitacao.present
            ? statusSolicitacao.value
            : this.statusSolicitacao,
        descricao: descricao.present ? descricao.value : this.descricao,
      );
  ContratoSolicitacaoServico copyWithCompanion(
      ContratoSolicitacaoServicosCompanion data) {
    return ContratoSolicitacaoServico(
      id: data.id.present ? data.id.value : this.id,
      idContratoTipoServico: data.idContratoTipoServico.present
          ? data.idContratoTipoServico.value
          : this.idContratoTipoServico,
      idSetor: data.idSetor.present ? data.idSetor.value : this.idSetor,
      idColaborador: data.idColaborador.present
          ? data.idColaborador.value
          : this.idColaborador,
      idCliente: data.idCliente.present ? data.idCliente.value : this.idCliente,
      idFornecedor: data.idFornecedor.present
          ? data.idFornecedor.value
          : this.idFornecedor,
      dataSolicitacao: data.dataSolicitacao.present
          ? data.dataSolicitacao.value
          : this.dataSolicitacao,
      dataDesejadaInicio: data.dataDesejadaInicio.present
          ? data.dataDesejadaInicio.value
          : this.dataDesejadaInicio,
      urgente: data.urgente.present ? data.urgente.value : this.urgente,
      statusSolicitacao: data.statusSolicitacao.present
          ? data.statusSolicitacao.value
          : this.statusSolicitacao,
      descricao: data.descricao.present ? data.descricao.value : this.descricao,
    );
  }

  @override
  String toString() {
    return (StringBuffer('ContratoSolicitacaoServico(')
          ..write('id: $id, ')
          ..write('idContratoTipoServico: $idContratoTipoServico, ')
          ..write('idSetor: $idSetor, ')
          ..write('idColaborador: $idColaborador, ')
          ..write('idCliente: $idCliente, ')
          ..write('idFornecedor: $idFornecedor, ')
          ..write('dataSolicitacao: $dataSolicitacao, ')
          ..write('dataDesejadaInicio: $dataDesejadaInicio, ')
          ..write('urgente: $urgente, ')
          ..write('statusSolicitacao: $statusSolicitacao, ')
          ..write('descricao: $descricao')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(
      id,
      idContratoTipoServico,
      idSetor,
      idColaborador,
      idCliente,
      idFornecedor,
      dataSolicitacao,
      dataDesejadaInicio,
      urgente,
      statusSolicitacao,
      descricao);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is ContratoSolicitacaoServico &&
          other.id == this.id &&
          other.idContratoTipoServico == this.idContratoTipoServico &&
          other.idSetor == this.idSetor &&
          other.idColaborador == this.idColaborador &&
          other.idCliente == this.idCliente &&
          other.idFornecedor == this.idFornecedor &&
          other.dataSolicitacao == this.dataSolicitacao &&
          other.dataDesejadaInicio == this.dataDesejadaInicio &&
          other.urgente == this.urgente &&
          other.statusSolicitacao == this.statusSolicitacao &&
          other.descricao == this.descricao);
}

class ContratoSolicitacaoServicosCompanion
    extends UpdateCompanion<ContratoSolicitacaoServico> {
  final Value<int?> id;
  final Value<int?> idContratoTipoServico;
  final Value<int?> idSetor;
  final Value<int?> idColaborador;
  final Value<int?> idCliente;
  final Value<int?> idFornecedor;
  final Value<DateTime?> dataSolicitacao;
  final Value<DateTime?> dataDesejadaInicio;
  final Value<String?> urgente;
  final Value<String?> statusSolicitacao;
  final Value<String?> descricao;
  const ContratoSolicitacaoServicosCompanion({
    this.id = const Value.absent(),
    this.idContratoTipoServico = const Value.absent(),
    this.idSetor = const Value.absent(),
    this.idColaborador = const Value.absent(),
    this.idCliente = const Value.absent(),
    this.idFornecedor = const Value.absent(),
    this.dataSolicitacao = const Value.absent(),
    this.dataDesejadaInicio = const Value.absent(),
    this.urgente = const Value.absent(),
    this.statusSolicitacao = const Value.absent(),
    this.descricao = const Value.absent(),
  });
  ContratoSolicitacaoServicosCompanion.insert({
    this.id = const Value.absent(),
    this.idContratoTipoServico = const Value.absent(),
    this.idSetor = const Value.absent(),
    this.idColaborador = const Value.absent(),
    this.idCliente = const Value.absent(),
    this.idFornecedor = const Value.absent(),
    this.dataSolicitacao = const Value.absent(),
    this.dataDesejadaInicio = const Value.absent(),
    this.urgente = const Value.absent(),
    this.statusSolicitacao = const Value.absent(),
    this.descricao = const Value.absent(),
  });
  static Insertable<ContratoSolicitacaoServico> custom({
    Expression<int>? id,
    Expression<int>? idContratoTipoServico,
    Expression<int>? idSetor,
    Expression<int>? idColaborador,
    Expression<int>? idCliente,
    Expression<int>? idFornecedor,
    Expression<DateTime>? dataSolicitacao,
    Expression<DateTime>? dataDesejadaInicio,
    Expression<String>? urgente,
    Expression<String>? statusSolicitacao,
    Expression<String>? descricao,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (idContratoTipoServico != null)
        'id_contrato_tipo_servico': idContratoTipoServico,
      if (idSetor != null) 'id_setor': idSetor,
      if (idColaborador != null) 'id_colaborador': idColaborador,
      if (idCliente != null) 'id_cliente': idCliente,
      if (idFornecedor != null) 'id_fornecedor': idFornecedor,
      if (dataSolicitacao != null) 'data_solicitacao': dataSolicitacao,
      if (dataDesejadaInicio != null)
        'data_desejada_inicio': dataDesejadaInicio,
      if (urgente != null) 'urgente': urgente,
      if (statusSolicitacao != null) 'status_solicitacao': statusSolicitacao,
      if (descricao != null) 'descricao': descricao,
    });
  }

  ContratoSolicitacaoServicosCompanion copyWith(
      {Value<int?>? id,
      Value<int?>? idContratoTipoServico,
      Value<int?>? idSetor,
      Value<int?>? idColaborador,
      Value<int?>? idCliente,
      Value<int?>? idFornecedor,
      Value<DateTime?>? dataSolicitacao,
      Value<DateTime?>? dataDesejadaInicio,
      Value<String?>? urgente,
      Value<String?>? statusSolicitacao,
      Value<String?>? descricao}) {
    return ContratoSolicitacaoServicosCompanion(
      id: id ?? this.id,
      idContratoTipoServico:
          idContratoTipoServico ?? this.idContratoTipoServico,
      idSetor: idSetor ?? this.idSetor,
      idColaborador: idColaborador ?? this.idColaborador,
      idCliente: idCliente ?? this.idCliente,
      idFornecedor: idFornecedor ?? this.idFornecedor,
      dataSolicitacao: dataSolicitacao ?? this.dataSolicitacao,
      dataDesejadaInicio: dataDesejadaInicio ?? this.dataDesejadaInicio,
      urgente: urgente ?? this.urgente,
      statusSolicitacao: statusSolicitacao ?? this.statusSolicitacao,
      descricao: descricao ?? this.descricao,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (idContratoTipoServico.present) {
      map['id_contrato_tipo_servico'] =
          Variable<int>(idContratoTipoServico.value);
    }
    if (idSetor.present) {
      map['id_setor'] = Variable<int>(idSetor.value);
    }
    if (idColaborador.present) {
      map['id_colaborador'] = Variable<int>(idColaborador.value);
    }
    if (idCliente.present) {
      map['id_cliente'] = Variable<int>(idCliente.value);
    }
    if (idFornecedor.present) {
      map['id_fornecedor'] = Variable<int>(idFornecedor.value);
    }
    if (dataSolicitacao.present) {
      map['data_solicitacao'] = Variable<DateTime>(dataSolicitacao.value);
    }
    if (dataDesejadaInicio.present) {
      map['data_desejada_inicio'] =
          Variable<DateTime>(dataDesejadaInicio.value);
    }
    if (urgente.present) {
      map['urgente'] = Variable<String>(urgente.value);
    }
    if (statusSolicitacao.present) {
      map['status_solicitacao'] = Variable<String>(statusSolicitacao.value);
    }
    if (descricao.present) {
      map['descricao'] = Variable<String>(descricao.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('ContratoSolicitacaoServicosCompanion(')
          ..write('id: $id, ')
          ..write('idContratoTipoServico: $idContratoTipoServico, ')
          ..write('idSetor: $idSetor, ')
          ..write('idColaborador: $idColaborador, ')
          ..write('idCliente: $idCliente, ')
          ..write('idFornecedor: $idFornecedor, ')
          ..write('dataSolicitacao: $dataSolicitacao, ')
          ..write('dataDesejadaInicio: $dataDesejadaInicio, ')
          ..write('urgente: $urgente, ')
          ..write('statusSolicitacao: $statusSolicitacao, ')
          ..write('descricao: $descricao')
          ..write(')'))
        .toString();
  }
}

class $ContratoTemplatesTable extends ContratoTemplates
    with TableInfo<$ContratoTemplatesTable, ContratoTemplate> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $ContratoTemplatesTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
      'id', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _nomeMeta = const VerificationMeta('nome');
  @override
  late final GeneratedColumn<String> nome = GeneratedColumn<String>(
      'nome', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 100),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _descricaoMeta =
      const VerificationMeta('descricao');
  @override
  late final GeneratedColumn<String> descricao = GeneratedColumn<String>(
      'descricao', aliasedName, true,
      type: DriftSqlType.string, requiredDuringInsert: false);
  @override
  List<GeneratedColumn> get $columns => [id, nome, descricao];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'contrato_template';
  @override
  VerificationContext validateIntegrity(Insertable<ContratoTemplate> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('nome')) {
      context.handle(
          _nomeMeta, nome.isAcceptableOrUnknown(data['nome']!, _nomeMeta));
    }
    if (data.containsKey('descricao')) {
      context.handle(_descricaoMeta,
          descricao.isAcceptableOrUnknown(data['descricao']!, _descricaoMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  ContratoTemplate map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return ContratoTemplate(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id']),
      nome: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}nome']),
      descricao: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}descricao']),
    );
  }

  @override
  $ContratoTemplatesTable createAlias(String alias) {
    return $ContratoTemplatesTable(attachedDatabase, alias);
  }
}

class ContratoTemplate extends DataClass
    implements Insertable<ContratoTemplate> {
  final int? id;
  final String? nome;
  final String? descricao;
  const ContratoTemplate({this.id, this.nome, this.descricao});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || nome != null) {
      map['nome'] = Variable<String>(nome);
    }
    if (!nullToAbsent || descricao != null) {
      map['descricao'] = Variable<String>(descricao);
    }
    return map;
  }

  factory ContratoTemplate.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return ContratoTemplate(
      id: serializer.fromJson<int?>(json['id']),
      nome: serializer.fromJson<String?>(json['nome']),
      descricao: serializer.fromJson<String?>(json['descricao']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'nome': serializer.toJson<String?>(nome),
      'descricao': serializer.toJson<String?>(descricao),
    };
  }

  ContratoTemplate copyWith(
          {Value<int?> id = const Value.absent(),
          Value<String?> nome = const Value.absent(),
          Value<String?> descricao = const Value.absent()}) =>
      ContratoTemplate(
        id: id.present ? id.value : this.id,
        nome: nome.present ? nome.value : this.nome,
        descricao: descricao.present ? descricao.value : this.descricao,
      );
  ContratoTemplate copyWithCompanion(ContratoTemplatesCompanion data) {
    return ContratoTemplate(
      id: data.id.present ? data.id.value : this.id,
      nome: data.nome.present ? data.nome.value : this.nome,
      descricao: data.descricao.present ? data.descricao.value : this.descricao,
    );
  }

  @override
  String toString() {
    return (StringBuffer('ContratoTemplate(')
          ..write('id: $id, ')
          ..write('nome: $nome, ')
          ..write('descricao: $descricao')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(id, nome, descricao);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is ContratoTemplate &&
          other.id == this.id &&
          other.nome == this.nome &&
          other.descricao == this.descricao);
}

class ContratoTemplatesCompanion extends UpdateCompanion<ContratoTemplate> {
  final Value<int?> id;
  final Value<String?> nome;
  final Value<String?> descricao;
  const ContratoTemplatesCompanion({
    this.id = const Value.absent(),
    this.nome = const Value.absent(),
    this.descricao = const Value.absent(),
  });
  ContratoTemplatesCompanion.insert({
    this.id = const Value.absent(),
    this.nome = const Value.absent(),
    this.descricao = const Value.absent(),
  });
  static Insertable<ContratoTemplate> custom({
    Expression<int>? id,
    Expression<String>? nome,
    Expression<String>? descricao,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (nome != null) 'nome': nome,
      if (descricao != null) 'descricao': descricao,
    });
  }

  ContratoTemplatesCompanion copyWith(
      {Value<int?>? id, Value<String?>? nome, Value<String?>? descricao}) {
    return ContratoTemplatesCompanion(
      id: id ?? this.id,
      nome: nome ?? this.nome,
      descricao: descricao ?? this.descricao,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (nome.present) {
      map['nome'] = Variable<String>(nome.value);
    }
    if (descricao.present) {
      map['descricao'] = Variable<String>(descricao.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('ContratoTemplatesCompanion(')
          ..write('id: $id, ')
          ..write('nome: $nome, ')
          ..write('descricao: $descricao')
          ..write(')'))
        .toString();
  }
}

class $ViewControleAcessosTable extends ViewControleAcessos
    with TableInfo<$ViewControleAcessosTable, ViewControleAcesso> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $ViewControleAcessosTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
      'id', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _idPessoaMeta =
      const VerificationMeta('idPessoa');
  @override
  late final GeneratedColumn<int> idPessoa = GeneratedColumn<int>(
      'id_pessoa', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _pessoaNomeMeta =
      const VerificationMeta('pessoaNome');
  @override
  late final GeneratedColumn<String> pessoaNome = GeneratedColumn<String>(
      'pessoa_nome', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 450),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _idColaboradorMeta =
      const VerificationMeta('idColaborador');
  @override
  late final GeneratedColumn<int> idColaborador = GeneratedColumn<int>(
      'id_colaborador', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _idUsuarioMeta =
      const VerificationMeta('idUsuario');
  @override
  late final GeneratedColumn<int> idUsuario = GeneratedColumn<int>(
      'id_usuario', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _administradorMeta =
      const VerificationMeta('administrador');
  @override
  late final GeneratedColumn<String> administrador = GeneratedColumn<String>(
      'administrador', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 3),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _idPapelMeta =
      const VerificationMeta('idPapel');
  @override
  late final GeneratedColumn<int> idPapel = GeneratedColumn<int>(
      'id_papel', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _papelNomeMeta =
      const VerificationMeta('papelNome');
  @override
  late final GeneratedColumn<String> papelNome = GeneratedColumn<String>(
      'papel_nome', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 300),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _papelDescricaoMeta =
      const VerificationMeta('papelDescricao');
  @override
  late final GeneratedColumn<String> papelDescricao = GeneratedColumn<String>(
      'papel_descricao', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 750),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _idFuncaoMeta =
      const VerificationMeta('idFuncao');
  @override
  late final GeneratedColumn<int> idFuncao = GeneratedColumn<int>(
      'id_funcao', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _funcaoNomeMeta =
      const VerificationMeta('funcaoNome');
  @override
  late final GeneratedColumn<String> funcaoNome = GeneratedColumn<String>(
      'funcao_nome', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 300),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _funcaoDescricaoMeta =
      const VerificationMeta('funcaoDescricao');
  @override
  late final GeneratedColumn<String> funcaoDescricao = GeneratedColumn<String>(
      'funcao_descricao', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 750),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _idPapelFuncaoMeta =
      const VerificationMeta('idPapelFuncao');
  @override
  late final GeneratedColumn<int> idPapelFuncao = GeneratedColumn<int>(
      'id_papel_funcao', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _habilitadoMeta =
      const VerificationMeta('habilitado');
  @override
  late final GeneratedColumn<String> habilitado = GeneratedColumn<String>(
      'habilitado', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 3),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _podeInserirMeta =
      const VerificationMeta('podeInserir');
  @override
  late final GeneratedColumn<String> podeInserir = GeneratedColumn<String>(
      'pode_inserir', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 3),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _podeAlterarMeta =
      const VerificationMeta('podeAlterar');
  @override
  late final GeneratedColumn<String> podeAlterar = GeneratedColumn<String>(
      'pode_alterar', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 3),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _podeExcluirMeta =
      const VerificationMeta('podeExcluir');
  @override
  late final GeneratedColumn<String> podeExcluir = GeneratedColumn<String>(
      'pode_excluir', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 3),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  @override
  List<GeneratedColumn> get $columns => [
        id,
        idPessoa,
        pessoaNome,
        idColaborador,
        idUsuario,
        administrador,
        idPapel,
        papelNome,
        papelDescricao,
        idFuncao,
        funcaoNome,
        funcaoDescricao,
        idPapelFuncao,
        habilitado,
        podeInserir,
        podeAlterar,
        podeExcluir
      ];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'view_controle_acesso';
  @override
  VerificationContext validateIntegrity(Insertable<ViewControleAcesso> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('id_pessoa')) {
      context.handle(_idPessoaMeta,
          idPessoa.isAcceptableOrUnknown(data['id_pessoa']!, _idPessoaMeta));
    }
    if (data.containsKey('pessoa_nome')) {
      context.handle(
          _pessoaNomeMeta,
          pessoaNome.isAcceptableOrUnknown(
              data['pessoa_nome']!, _pessoaNomeMeta));
    }
    if (data.containsKey('id_colaborador')) {
      context.handle(
          _idColaboradorMeta,
          idColaborador.isAcceptableOrUnknown(
              data['id_colaborador']!, _idColaboradorMeta));
    }
    if (data.containsKey('id_usuario')) {
      context.handle(_idUsuarioMeta,
          idUsuario.isAcceptableOrUnknown(data['id_usuario']!, _idUsuarioMeta));
    }
    if (data.containsKey('administrador')) {
      context.handle(
          _administradorMeta,
          administrador.isAcceptableOrUnknown(
              data['administrador']!, _administradorMeta));
    }
    if (data.containsKey('id_papel')) {
      context.handle(_idPapelMeta,
          idPapel.isAcceptableOrUnknown(data['id_papel']!, _idPapelMeta));
    }
    if (data.containsKey('papel_nome')) {
      context.handle(_papelNomeMeta,
          papelNome.isAcceptableOrUnknown(data['papel_nome']!, _papelNomeMeta));
    }
    if (data.containsKey('papel_descricao')) {
      context.handle(
          _papelDescricaoMeta,
          papelDescricao.isAcceptableOrUnknown(
              data['papel_descricao']!, _papelDescricaoMeta));
    }
    if (data.containsKey('id_funcao')) {
      context.handle(_idFuncaoMeta,
          idFuncao.isAcceptableOrUnknown(data['id_funcao']!, _idFuncaoMeta));
    }
    if (data.containsKey('funcao_nome')) {
      context.handle(
          _funcaoNomeMeta,
          funcaoNome.isAcceptableOrUnknown(
              data['funcao_nome']!, _funcaoNomeMeta));
    }
    if (data.containsKey('funcao_descricao')) {
      context.handle(
          _funcaoDescricaoMeta,
          funcaoDescricao.isAcceptableOrUnknown(
              data['funcao_descricao']!, _funcaoDescricaoMeta));
    }
    if (data.containsKey('id_papel_funcao')) {
      context.handle(
          _idPapelFuncaoMeta,
          idPapelFuncao.isAcceptableOrUnknown(
              data['id_papel_funcao']!, _idPapelFuncaoMeta));
    }
    if (data.containsKey('habilitado')) {
      context.handle(
          _habilitadoMeta,
          habilitado.isAcceptableOrUnknown(
              data['habilitado']!, _habilitadoMeta));
    }
    if (data.containsKey('pode_inserir')) {
      context.handle(
          _podeInserirMeta,
          podeInserir.isAcceptableOrUnknown(
              data['pode_inserir']!, _podeInserirMeta));
    }
    if (data.containsKey('pode_alterar')) {
      context.handle(
          _podeAlterarMeta,
          podeAlterar.isAcceptableOrUnknown(
              data['pode_alterar']!, _podeAlterarMeta));
    }
    if (data.containsKey('pode_excluir')) {
      context.handle(
          _podeExcluirMeta,
          podeExcluir.isAcceptableOrUnknown(
              data['pode_excluir']!, _podeExcluirMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  ViewControleAcesso map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return ViewControleAcesso(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id']),
      idPessoa: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id_pessoa']),
      pessoaNome: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}pessoa_nome']),
      idColaborador: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id_colaborador']),
      idUsuario: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id_usuario']),
      administrador: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}administrador']),
      idPapel: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id_papel']),
      papelNome: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}papel_nome']),
      papelDescricao: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}papel_descricao']),
      idFuncao: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id_funcao']),
      funcaoNome: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}funcao_nome']),
      funcaoDescricao: attachedDatabase.typeMapping.read(
          DriftSqlType.string, data['${effectivePrefix}funcao_descricao']),
      idPapelFuncao: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id_papel_funcao']),
      habilitado: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}habilitado']),
      podeInserir: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}pode_inserir']),
      podeAlterar: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}pode_alterar']),
      podeExcluir: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}pode_excluir']),
    );
  }

  @override
  $ViewControleAcessosTable createAlias(String alias) {
    return $ViewControleAcessosTable(attachedDatabase, alias);
  }
}

class ViewControleAcesso extends DataClass
    implements Insertable<ViewControleAcesso> {
  final int? id;
  final int? idPessoa;
  final String? pessoaNome;
  final int? idColaborador;
  final int? idUsuario;
  final String? administrador;
  final int? idPapel;
  final String? papelNome;
  final String? papelDescricao;
  final int? idFuncao;
  final String? funcaoNome;
  final String? funcaoDescricao;
  final int? idPapelFuncao;
  final String? habilitado;
  final String? podeInserir;
  final String? podeAlterar;
  final String? podeExcluir;
  const ViewControleAcesso(
      {this.id,
      this.idPessoa,
      this.pessoaNome,
      this.idColaborador,
      this.idUsuario,
      this.administrador,
      this.idPapel,
      this.papelNome,
      this.papelDescricao,
      this.idFuncao,
      this.funcaoNome,
      this.funcaoDescricao,
      this.idPapelFuncao,
      this.habilitado,
      this.podeInserir,
      this.podeAlterar,
      this.podeExcluir});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || idPessoa != null) {
      map['id_pessoa'] = Variable<int>(idPessoa);
    }
    if (!nullToAbsent || pessoaNome != null) {
      map['pessoa_nome'] = Variable<String>(pessoaNome);
    }
    if (!nullToAbsent || idColaborador != null) {
      map['id_colaborador'] = Variable<int>(idColaborador);
    }
    if (!nullToAbsent || idUsuario != null) {
      map['id_usuario'] = Variable<int>(idUsuario);
    }
    if (!nullToAbsent || administrador != null) {
      map['administrador'] = Variable<String>(administrador);
    }
    if (!nullToAbsent || idPapel != null) {
      map['id_papel'] = Variable<int>(idPapel);
    }
    if (!nullToAbsent || papelNome != null) {
      map['papel_nome'] = Variable<String>(papelNome);
    }
    if (!nullToAbsent || papelDescricao != null) {
      map['papel_descricao'] = Variable<String>(papelDescricao);
    }
    if (!nullToAbsent || idFuncao != null) {
      map['id_funcao'] = Variable<int>(idFuncao);
    }
    if (!nullToAbsent || funcaoNome != null) {
      map['funcao_nome'] = Variable<String>(funcaoNome);
    }
    if (!nullToAbsent || funcaoDescricao != null) {
      map['funcao_descricao'] = Variable<String>(funcaoDescricao);
    }
    if (!nullToAbsent || idPapelFuncao != null) {
      map['id_papel_funcao'] = Variable<int>(idPapelFuncao);
    }
    if (!nullToAbsent || habilitado != null) {
      map['habilitado'] = Variable<String>(habilitado);
    }
    if (!nullToAbsent || podeInserir != null) {
      map['pode_inserir'] = Variable<String>(podeInserir);
    }
    if (!nullToAbsent || podeAlterar != null) {
      map['pode_alterar'] = Variable<String>(podeAlterar);
    }
    if (!nullToAbsent || podeExcluir != null) {
      map['pode_excluir'] = Variable<String>(podeExcluir);
    }
    return map;
  }

  factory ViewControleAcesso.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return ViewControleAcesso(
      id: serializer.fromJson<int?>(json['id']),
      idPessoa: serializer.fromJson<int?>(json['idPessoa']),
      pessoaNome: serializer.fromJson<String?>(json['pessoaNome']),
      idColaborador: serializer.fromJson<int?>(json['idColaborador']),
      idUsuario: serializer.fromJson<int?>(json['idUsuario']),
      administrador: serializer.fromJson<String?>(json['administrador']),
      idPapel: serializer.fromJson<int?>(json['idPapel']),
      papelNome: serializer.fromJson<String?>(json['papelNome']),
      papelDescricao: serializer.fromJson<String?>(json['papelDescricao']),
      idFuncao: serializer.fromJson<int?>(json['idFuncao']),
      funcaoNome: serializer.fromJson<String?>(json['funcaoNome']),
      funcaoDescricao: serializer.fromJson<String?>(json['funcaoDescricao']),
      idPapelFuncao: serializer.fromJson<int?>(json['idPapelFuncao']),
      habilitado: serializer.fromJson<String?>(json['habilitado']),
      podeInserir: serializer.fromJson<String?>(json['podeInserir']),
      podeAlterar: serializer.fromJson<String?>(json['podeAlterar']),
      podeExcluir: serializer.fromJson<String?>(json['podeExcluir']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'idPessoa': serializer.toJson<int?>(idPessoa),
      'pessoaNome': serializer.toJson<String?>(pessoaNome),
      'idColaborador': serializer.toJson<int?>(idColaborador),
      'idUsuario': serializer.toJson<int?>(idUsuario),
      'administrador': serializer.toJson<String?>(administrador),
      'idPapel': serializer.toJson<int?>(idPapel),
      'papelNome': serializer.toJson<String?>(papelNome),
      'papelDescricao': serializer.toJson<String?>(papelDescricao),
      'idFuncao': serializer.toJson<int?>(idFuncao),
      'funcaoNome': serializer.toJson<String?>(funcaoNome),
      'funcaoDescricao': serializer.toJson<String?>(funcaoDescricao),
      'idPapelFuncao': serializer.toJson<int?>(idPapelFuncao),
      'habilitado': serializer.toJson<String?>(habilitado),
      'podeInserir': serializer.toJson<String?>(podeInserir),
      'podeAlterar': serializer.toJson<String?>(podeAlterar),
      'podeExcluir': serializer.toJson<String?>(podeExcluir),
    };
  }

  ViewControleAcesso copyWith(
          {Value<int?> id = const Value.absent(),
          Value<int?> idPessoa = const Value.absent(),
          Value<String?> pessoaNome = const Value.absent(),
          Value<int?> idColaborador = const Value.absent(),
          Value<int?> idUsuario = const Value.absent(),
          Value<String?> administrador = const Value.absent(),
          Value<int?> idPapel = const Value.absent(),
          Value<String?> papelNome = const Value.absent(),
          Value<String?> papelDescricao = const Value.absent(),
          Value<int?> idFuncao = const Value.absent(),
          Value<String?> funcaoNome = const Value.absent(),
          Value<String?> funcaoDescricao = const Value.absent(),
          Value<int?> idPapelFuncao = const Value.absent(),
          Value<String?> habilitado = const Value.absent(),
          Value<String?> podeInserir = const Value.absent(),
          Value<String?> podeAlterar = const Value.absent(),
          Value<String?> podeExcluir = const Value.absent()}) =>
      ViewControleAcesso(
        id: id.present ? id.value : this.id,
        idPessoa: idPessoa.present ? idPessoa.value : this.idPessoa,
        pessoaNome: pessoaNome.present ? pessoaNome.value : this.pessoaNome,
        idColaborador:
            idColaborador.present ? idColaborador.value : this.idColaborador,
        idUsuario: idUsuario.present ? idUsuario.value : this.idUsuario,
        administrador:
            administrador.present ? administrador.value : this.administrador,
        idPapel: idPapel.present ? idPapel.value : this.idPapel,
        papelNome: papelNome.present ? papelNome.value : this.papelNome,
        papelDescricao:
            papelDescricao.present ? papelDescricao.value : this.papelDescricao,
        idFuncao: idFuncao.present ? idFuncao.value : this.idFuncao,
        funcaoNome: funcaoNome.present ? funcaoNome.value : this.funcaoNome,
        funcaoDescricao: funcaoDescricao.present
            ? funcaoDescricao.value
            : this.funcaoDescricao,
        idPapelFuncao:
            idPapelFuncao.present ? idPapelFuncao.value : this.idPapelFuncao,
        habilitado: habilitado.present ? habilitado.value : this.habilitado,
        podeInserir: podeInserir.present ? podeInserir.value : this.podeInserir,
        podeAlterar: podeAlterar.present ? podeAlterar.value : this.podeAlterar,
        podeExcluir: podeExcluir.present ? podeExcluir.value : this.podeExcluir,
      );
  ViewControleAcesso copyWithCompanion(ViewControleAcessosCompanion data) {
    return ViewControleAcesso(
      id: data.id.present ? data.id.value : this.id,
      idPessoa: data.idPessoa.present ? data.idPessoa.value : this.idPessoa,
      pessoaNome:
          data.pessoaNome.present ? data.pessoaNome.value : this.pessoaNome,
      idColaborador: data.idColaborador.present
          ? data.idColaborador.value
          : this.idColaborador,
      idUsuario: data.idUsuario.present ? data.idUsuario.value : this.idUsuario,
      administrador: data.administrador.present
          ? data.administrador.value
          : this.administrador,
      idPapel: data.idPapel.present ? data.idPapel.value : this.idPapel,
      papelNome: data.papelNome.present ? data.papelNome.value : this.papelNome,
      papelDescricao: data.papelDescricao.present
          ? data.papelDescricao.value
          : this.papelDescricao,
      idFuncao: data.idFuncao.present ? data.idFuncao.value : this.idFuncao,
      funcaoNome:
          data.funcaoNome.present ? data.funcaoNome.value : this.funcaoNome,
      funcaoDescricao: data.funcaoDescricao.present
          ? data.funcaoDescricao.value
          : this.funcaoDescricao,
      idPapelFuncao: data.idPapelFuncao.present
          ? data.idPapelFuncao.value
          : this.idPapelFuncao,
      habilitado:
          data.habilitado.present ? data.habilitado.value : this.habilitado,
      podeInserir:
          data.podeInserir.present ? data.podeInserir.value : this.podeInserir,
      podeAlterar:
          data.podeAlterar.present ? data.podeAlterar.value : this.podeAlterar,
      podeExcluir:
          data.podeExcluir.present ? data.podeExcluir.value : this.podeExcluir,
    );
  }

  @override
  String toString() {
    return (StringBuffer('ViewControleAcesso(')
          ..write('id: $id, ')
          ..write('idPessoa: $idPessoa, ')
          ..write('pessoaNome: $pessoaNome, ')
          ..write('idColaborador: $idColaborador, ')
          ..write('idUsuario: $idUsuario, ')
          ..write('administrador: $administrador, ')
          ..write('idPapel: $idPapel, ')
          ..write('papelNome: $papelNome, ')
          ..write('papelDescricao: $papelDescricao, ')
          ..write('idFuncao: $idFuncao, ')
          ..write('funcaoNome: $funcaoNome, ')
          ..write('funcaoDescricao: $funcaoDescricao, ')
          ..write('idPapelFuncao: $idPapelFuncao, ')
          ..write('habilitado: $habilitado, ')
          ..write('podeInserir: $podeInserir, ')
          ..write('podeAlterar: $podeAlterar, ')
          ..write('podeExcluir: $podeExcluir')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(
      id,
      idPessoa,
      pessoaNome,
      idColaborador,
      idUsuario,
      administrador,
      idPapel,
      papelNome,
      papelDescricao,
      idFuncao,
      funcaoNome,
      funcaoDescricao,
      idPapelFuncao,
      habilitado,
      podeInserir,
      podeAlterar,
      podeExcluir);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is ViewControleAcesso &&
          other.id == this.id &&
          other.idPessoa == this.idPessoa &&
          other.pessoaNome == this.pessoaNome &&
          other.idColaborador == this.idColaborador &&
          other.idUsuario == this.idUsuario &&
          other.administrador == this.administrador &&
          other.idPapel == this.idPapel &&
          other.papelNome == this.papelNome &&
          other.papelDescricao == this.papelDescricao &&
          other.idFuncao == this.idFuncao &&
          other.funcaoNome == this.funcaoNome &&
          other.funcaoDescricao == this.funcaoDescricao &&
          other.idPapelFuncao == this.idPapelFuncao &&
          other.habilitado == this.habilitado &&
          other.podeInserir == this.podeInserir &&
          other.podeAlterar == this.podeAlterar &&
          other.podeExcluir == this.podeExcluir);
}

class ViewControleAcessosCompanion extends UpdateCompanion<ViewControleAcesso> {
  final Value<int?> id;
  final Value<int?> idPessoa;
  final Value<String?> pessoaNome;
  final Value<int?> idColaborador;
  final Value<int?> idUsuario;
  final Value<String?> administrador;
  final Value<int?> idPapel;
  final Value<String?> papelNome;
  final Value<String?> papelDescricao;
  final Value<int?> idFuncao;
  final Value<String?> funcaoNome;
  final Value<String?> funcaoDescricao;
  final Value<int?> idPapelFuncao;
  final Value<String?> habilitado;
  final Value<String?> podeInserir;
  final Value<String?> podeAlterar;
  final Value<String?> podeExcluir;
  const ViewControleAcessosCompanion({
    this.id = const Value.absent(),
    this.idPessoa = const Value.absent(),
    this.pessoaNome = const Value.absent(),
    this.idColaborador = const Value.absent(),
    this.idUsuario = const Value.absent(),
    this.administrador = const Value.absent(),
    this.idPapel = const Value.absent(),
    this.papelNome = const Value.absent(),
    this.papelDescricao = const Value.absent(),
    this.idFuncao = const Value.absent(),
    this.funcaoNome = const Value.absent(),
    this.funcaoDescricao = const Value.absent(),
    this.idPapelFuncao = const Value.absent(),
    this.habilitado = const Value.absent(),
    this.podeInserir = const Value.absent(),
    this.podeAlterar = const Value.absent(),
    this.podeExcluir = const Value.absent(),
  });
  ViewControleAcessosCompanion.insert({
    this.id = const Value.absent(),
    this.idPessoa = const Value.absent(),
    this.pessoaNome = const Value.absent(),
    this.idColaborador = const Value.absent(),
    this.idUsuario = const Value.absent(),
    this.administrador = const Value.absent(),
    this.idPapel = const Value.absent(),
    this.papelNome = const Value.absent(),
    this.papelDescricao = const Value.absent(),
    this.idFuncao = const Value.absent(),
    this.funcaoNome = const Value.absent(),
    this.funcaoDescricao = const Value.absent(),
    this.idPapelFuncao = const Value.absent(),
    this.habilitado = const Value.absent(),
    this.podeInserir = const Value.absent(),
    this.podeAlterar = const Value.absent(),
    this.podeExcluir = const Value.absent(),
  });
  static Insertable<ViewControleAcesso> custom({
    Expression<int>? id,
    Expression<int>? idPessoa,
    Expression<String>? pessoaNome,
    Expression<int>? idColaborador,
    Expression<int>? idUsuario,
    Expression<String>? administrador,
    Expression<int>? idPapel,
    Expression<String>? papelNome,
    Expression<String>? papelDescricao,
    Expression<int>? idFuncao,
    Expression<String>? funcaoNome,
    Expression<String>? funcaoDescricao,
    Expression<int>? idPapelFuncao,
    Expression<String>? habilitado,
    Expression<String>? podeInserir,
    Expression<String>? podeAlterar,
    Expression<String>? podeExcluir,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (idPessoa != null) 'id_pessoa': idPessoa,
      if (pessoaNome != null) 'pessoa_nome': pessoaNome,
      if (idColaborador != null) 'id_colaborador': idColaborador,
      if (idUsuario != null) 'id_usuario': idUsuario,
      if (administrador != null) 'administrador': administrador,
      if (idPapel != null) 'id_papel': idPapel,
      if (papelNome != null) 'papel_nome': papelNome,
      if (papelDescricao != null) 'papel_descricao': papelDescricao,
      if (idFuncao != null) 'id_funcao': idFuncao,
      if (funcaoNome != null) 'funcao_nome': funcaoNome,
      if (funcaoDescricao != null) 'funcao_descricao': funcaoDescricao,
      if (idPapelFuncao != null) 'id_papel_funcao': idPapelFuncao,
      if (habilitado != null) 'habilitado': habilitado,
      if (podeInserir != null) 'pode_inserir': podeInserir,
      if (podeAlterar != null) 'pode_alterar': podeAlterar,
      if (podeExcluir != null) 'pode_excluir': podeExcluir,
    });
  }

  ViewControleAcessosCompanion copyWith(
      {Value<int?>? id,
      Value<int?>? idPessoa,
      Value<String?>? pessoaNome,
      Value<int?>? idColaborador,
      Value<int?>? idUsuario,
      Value<String?>? administrador,
      Value<int?>? idPapel,
      Value<String?>? papelNome,
      Value<String?>? papelDescricao,
      Value<int?>? idFuncao,
      Value<String?>? funcaoNome,
      Value<String?>? funcaoDescricao,
      Value<int?>? idPapelFuncao,
      Value<String?>? habilitado,
      Value<String?>? podeInserir,
      Value<String?>? podeAlterar,
      Value<String?>? podeExcluir}) {
    return ViewControleAcessosCompanion(
      id: id ?? this.id,
      idPessoa: idPessoa ?? this.idPessoa,
      pessoaNome: pessoaNome ?? this.pessoaNome,
      idColaborador: idColaborador ?? this.idColaborador,
      idUsuario: idUsuario ?? this.idUsuario,
      administrador: administrador ?? this.administrador,
      idPapel: idPapel ?? this.idPapel,
      papelNome: papelNome ?? this.papelNome,
      papelDescricao: papelDescricao ?? this.papelDescricao,
      idFuncao: idFuncao ?? this.idFuncao,
      funcaoNome: funcaoNome ?? this.funcaoNome,
      funcaoDescricao: funcaoDescricao ?? this.funcaoDescricao,
      idPapelFuncao: idPapelFuncao ?? this.idPapelFuncao,
      habilitado: habilitado ?? this.habilitado,
      podeInserir: podeInserir ?? this.podeInserir,
      podeAlterar: podeAlterar ?? this.podeAlterar,
      podeExcluir: podeExcluir ?? this.podeExcluir,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (idPessoa.present) {
      map['id_pessoa'] = Variable<int>(idPessoa.value);
    }
    if (pessoaNome.present) {
      map['pessoa_nome'] = Variable<String>(pessoaNome.value);
    }
    if (idColaborador.present) {
      map['id_colaborador'] = Variable<int>(idColaborador.value);
    }
    if (idUsuario.present) {
      map['id_usuario'] = Variable<int>(idUsuario.value);
    }
    if (administrador.present) {
      map['administrador'] = Variable<String>(administrador.value);
    }
    if (idPapel.present) {
      map['id_papel'] = Variable<int>(idPapel.value);
    }
    if (papelNome.present) {
      map['papel_nome'] = Variable<String>(papelNome.value);
    }
    if (papelDescricao.present) {
      map['papel_descricao'] = Variable<String>(papelDescricao.value);
    }
    if (idFuncao.present) {
      map['id_funcao'] = Variable<int>(idFuncao.value);
    }
    if (funcaoNome.present) {
      map['funcao_nome'] = Variable<String>(funcaoNome.value);
    }
    if (funcaoDescricao.present) {
      map['funcao_descricao'] = Variable<String>(funcaoDescricao.value);
    }
    if (idPapelFuncao.present) {
      map['id_papel_funcao'] = Variable<int>(idPapelFuncao.value);
    }
    if (habilitado.present) {
      map['habilitado'] = Variable<String>(habilitado.value);
    }
    if (podeInserir.present) {
      map['pode_inserir'] = Variable<String>(podeInserir.value);
    }
    if (podeAlterar.present) {
      map['pode_alterar'] = Variable<String>(podeAlterar.value);
    }
    if (podeExcluir.present) {
      map['pode_excluir'] = Variable<String>(podeExcluir.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('ViewControleAcessosCompanion(')
          ..write('id: $id, ')
          ..write('idPessoa: $idPessoa, ')
          ..write('pessoaNome: $pessoaNome, ')
          ..write('idColaborador: $idColaborador, ')
          ..write('idUsuario: $idUsuario, ')
          ..write('administrador: $administrador, ')
          ..write('idPapel: $idPapel, ')
          ..write('papelNome: $papelNome, ')
          ..write('papelDescricao: $papelDescricao, ')
          ..write('idFuncao: $idFuncao, ')
          ..write('funcaoNome: $funcaoNome, ')
          ..write('funcaoDescricao: $funcaoDescricao, ')
          ..write('idPapelFuncao: $idPapelFuncao, ')
          ..write('habilitado: $habilitado, ')
          ..write('podeInserir: $podeInserir, ')
          ..write('podeAlterar: $podeAlterar, ')
          ..write('podeExcluir: $podeExcluir')
          ..write(')'))
        .toString();
  }
}

class $ViewPessoaUsuariosTable extends ViewPessoaUsuarios
    with TableInfo<$ViewPessoaUsuariosTable, ViewPessoaUsuario> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $ViewPessoaUsuariosTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
      'id', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _idPessoaMeta =
      const VerificationMeta('idPessoa');
  @override
  late final GeneratedColumn<int> idPessoa = GeneratedColumn<int>(
      'id_pessoa', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _pessoaNomeMeta =
      const VerificationMeta('pessoaNome');
  @override
  late final GeneratedColumn<String> pessoaNome = GeneratedColumn<String>(
      'pessoa_nome', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 450),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _tipoMeta = const VerificationMeta('tipo');
  @override
  late final GeneratedColumn<String> tipo = GeneratedColumn<String>(
      'tipo', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 3),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _emailMeta = const VerificationMeta('email');
  @override
  late final GeneratedColumn<String> email = GeneratedColumn<String>(
      'email', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 750),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _idColaboradorMeta =
      const VerificationMeta('idColaborador');
  @override
  late final GeneratedColumn<int> idColaborador = GeneratedColumn<int>(
      'id_colaborador', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _idUsuarioMeta =
      const VerificationMeta('idUsuario');
  @override
  late final GeneratedColumn<int> idUsuario = GeneratedColumn<int>(
      'id_usuario', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _loginMeta = const VerificationMeta('login');
  @override
  late final GeneratedColumn<String> login = GeneratedColumn<String>(
      'login', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 150),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _senhaMeta = const VerificationMeta('senha');
  @override
  late final GeneratedColumn<String> senha = GeneratedColumn<String>(
      'senha', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 150),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _dataCadastroMeta =
      const VerificationMeta('dataCadastro');
  @override
  late final GeneratedColumn<DateTime> dataCadastro = GeneratedColumn<DateTime>(
      'data_cadastro', aliasedName, true,
      type: DriftSqlType.dateTime, requiredDuringInsert: false);
  static const VerificationMeta _administradorMeta =
      const VerificationMeta('administrador');
  @override
  late final GeneratedColumn<String> administrador = GeneratedColumn<String>(
      'administrador', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 3),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  @override
  List<GeneratedColumn> get $columns => [
        id,
        idPessoa,
        pessoaNome,
        tipo,
        email,
        idColaborador,
        idUsuario,
        login,
        senha,
        dataCadastro,
        administrador
      ];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'view_pessoa_usuario';
  @override
  VerificationContext validateIntegrity(Insertable<ViewPessoaUsuario> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('id_pessoa')) {
      context.handle(_idPessoaMeta,
          idPessoa.isAcceptableOrUnknown(data['id_pessoa']!, _idPessoaMeta));
    }
    if (data.containsKey('pessoa_nome')) {
      context.handle(
          _pessoaNomeMeta,
          pessoaNome.isAcceptableOrUnknown(
              data['pessoa_nome']!, _pessoaNomeMeta));
    }
    if (data.containsKey('tipo')) {
      context.handle(
          _tipoMeta, tipo.isAcceptableOrUnknown(data['tipo']!, _tipoMeta));
    }
    if (data.containsKey('email')) {
      context.handle(
          _emailMeta, email.isAcceptableOrUnknown(data['email']!, _emailMeta));
    }
    if (data.containsKey('id_colaborador')) {
      context.handle(
          _idColaboradorMeta,
          idColaborador.isAcceptableOrUnknown(
              data['id_colaborador']!, _idColaboradorMeta));
    }
    if (data.containsKey('id_usuario')) {
      context.handle(_idUsuarioMeta,
          idUsuario.isAcceptableOrUnknown(data['id_usuario']!, _idUsuarioMeta));
    }
    if (data.containsKey('login')) {
      context.handle(
          _loginMeta, login.isAcceptableOrUnknown(data['login']!, _loginMeta));
    }
    if (data.containsKey('senha')) {
      context.handle(
          _senhaMeta, senha.isAcceptableOrUnknown(data['senha']!, _senhaMeta));
    }
    if (data.containsKey('data_cadastro')) {
      context.handle(
          _dataCadastroMeta,
          dataCadastro.isAcceptableOrUnknown(
              data['data_cadastro']!, _dataCadastroMeta));
    }
    if (data.containsKey('administrador')) {
      context.handle(
          _administradorMeta,
          administrador.isAcceptableOrUnknown(
              data['administrador']!, _administradorMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  ViewPessoaUsuario map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return ViewPessoaUsuario(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id']),
      idPessoa: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id_pessoa']),
      pessoaNome: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}pessoa_nome']),
      tipo: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}tipo']),
      email: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}email']),
      idColaborador: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id_colaborador']),
      idUsuario: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id_usuario']),
      login: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}login']),
      senha: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}senha']),
      dataCadastro: attachedDatabase.typeMapping
          .read(DriftSqlType.dateTime, data['${effectivePrefix}data_cadastro']),
      administrador: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}administrador']),
    );
  }

  @override
  $ViewPessoaUsuariosTable createAlias(String alias) {
    return $ViewPessoaUsuariosTable(attachedDatabase, alias);
  }
}

class ViewPessoaUsuario extends DataClass
    implements Insertable<ViewPessoaUsuario> {
  final int? id;
  final int? idPessoa;
  final String? pessoaNome;
  final String? tipo;
  final String? email;
  final int? idColaborador;
  final int? idUsuario;
  final String? login;
  final String? senha;
  final DateTime? dataCadastro;
  final String? administrador;
  const ViewPessoaUsuario(
      {this.id,
      this.idPessoa,
      this.pessoaNome,
      this.tipo,
      this.email,
      this.idColaborador,
      this.idUsuario,
      this.login,
      this.senha,
      this.dataCadastro,
      this.administrador});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || idPessoa != null) {
      map['id_pessoa'] = Variable<int>(idPessoa);
    }
    if (!nullToAbsent || pessoaNome != null) {
      map['pessoa_nome'] = Variable<String>(pessoaNome);
    }
    if (!nullToAbsent || tipo != null) {
      map['tipo'] = Variable<String>(tipo);
    }
    if (!nullToAbsent || email != null) {
      map['email'] = Variable<String>(email);
    }
    if (!nullToAbsent || idColaborador != null) {
      map['id_colaborador'] = Variable<int>(idColaborador);
    }
    if (!nullToAbsent || idUsuario != null) {
      map['id_usuario'] = Variable<int>(idUsuario);
    }
    if (!nullToAbsent || login != null) {
      map['login'] = Variable<String>(login);
    }
    if (!nullToAbsent || senha != null) {
      map['senha'] = Variable<String>(senha);
    }
    if (!nullToAbsent || dataCadastro != null) {
      map['data_cadastro'] = Variable<DateTime>(dataCadastro);
    }
    if (!nullToAbsent || administrador != null) {
      map['administrador'] = Variable<String>(administrador);
    }
    return map;
  }

  factory ViewPessoaUsuario.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return ViewPessoaUsuario(
      id: serializer.fromJson<int?>(json['id']),
      idPessoa: serializer.fromJson<int?>(json['idPessoa']),
      pessoaNome: serializer.fromJson<String?>(json['pessoaNome']),
      tipo: serializer.fromJson<String?>(json['tipo']),
      email: serializer.fromJson<String?>(json['email']),
      idColaborador: serializer.fromJson<int?>(json['idColaborador']),
      idUsuario: serializer.fromJson<int?>(json['idUsuario']),
      login: serializer.fromJson<String?>(json['login']),
      senha: serializer.fromJson<String?>(json['senha']),
      dataCadastro: serializer.fromJson<DateTime?>(json['dataCadastro']),
      administrador: serializer.fromJson<String?>(json['administrador']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'idPessoa': serializer.toJson<int?>(idPessoa),
      'pessoaNome': serializer.toJson<String?>(pessoaNome),
      'tipo': serializer.toJson<String?>(tipo),
      'email': serializer.toJson<String?>(email),
      'idColaborador': serializer.toJson<int?>(idColaborador),
      'idUsuario': serializer.toJson<int?>(idUsuario),
      'login': serializer.toJson<String?>(login),
      'senha': serializer.toJson<String?>(senha),
      'dataCadastro': serializer.toJson<DateTime?>(dataCadastro),
      'administrador': serializer.toJson<String?>(administrador),
    };
  }

  ViewPessoaUsuario copyWith(
          {Value<int?> id = const Value.absent(),
          Value<int?> idPessoa = const Value.absent(),
          Value<String?> pessoaNome = const Value.absent(),
          Value<String?> tipo = const Value.absent(),
          Value<String?> email = const Value.absent(),
          Value<int?> idColaborador = const Value.absent(),
          Value<int?> idUsuario = const Value.absent(),
          Value<String?> login = const Value.absent(),
          Value<String?> senha = const Value.absent(),
          Value<DateTime?> dataCadastro = const Value.absent(),
          Value<String?> administrador = const Value.absent()}) =>
      ViewPessoaUsuario(
        id: id.present ? id.value : this.id,
        idPessoa: idPessoa.present ? idPessoa.value : this.idPessoa,
        pessoaNome: pessoaNome.present ? pessoaNome.value : this.pessoaNome,
        tipo: tipo.present ? tipo.value : this.tipo,
        email: email.present ? email.value : this.email,
        idColaborador:
            idColaborador.present ? idColaborador.value : this.idColaborador,
        idUsuario: idUsuario.present ? idUsuario.value : this.idUsuario,
        login: login.present ? login.value : this.login,
        senha: senha.present ? senha.value : this.senha,
        dataCadastro:
            dataCadastro.present ? dataCadastro.value : this.dataCadastro,
        administrador:
            administrador.present ? administrador.value : this.administrador,
      );
  ViewPessoaUsuario copyWithCompanion(ViewPessoaUsuariosCompanion data) {
    return ViewPessoaUsuario(
      id: data.id.present ? data.id.value : this.id,
      idPessoa: data.idPessoa.present ? data.idPessoa.value : this.idPessoa,
      pessoaNome:
          data.pessoaNome.present ? data.pessoaNome.value : this.pessoaNome,
      tipo: data.tipo.present ? data.tipo.value : this.tipo,
      email: data.email.present ? data.email.value : this.email,
      idColaborador: data.idColaborador.present
          ? data.idColaborador.value
          : this.idColaborador,
      idUsuario: data.idUsuario.present ? data.idUsuario.value : this.idUsuario,
      login: data.login.present ? data.login.value : this.login,
      senha: data.senha.present ? data.senha.value : this.senha,
      dataCadastro: data.dataCadastro.present
          ? data.dataCadastro.value
          : this.dataCadastro,
      administrador: data.administrador.present
          ? data.administrador.value
          : this.administrador,
    );
  }

  @override
  String toString() {
    return (StringBuffer('ViewPessoaUsuario(')
          ..write('id: $id, ')
          ..write('idPessoa: $idPessoa, ')
          ..write('pessoaNome: $pessoaNome, ')
          ..write('tipo: $tipo, ')
          ..write('email: $email, ')
          ..write('idColaborador: $idColaborador, ')
          ..write('idUsuario: $idUsuario, ')
          ..write('login: $login, ')
          ..write('senha: $senha, ')
          ..write('dataCadastro: $dataCadastro, ')
          ..write('administrador: $administrador')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(id, idPessoa, pessoaNome, tipo, email,
      idColaborador, idUsuario, login, senha, dataCadastro, administrador);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is ViewPessoaUsuario &&
          other.id == this.id &&
          other.idPessoa == this.idPessoa &&
          other.pessoaNome == this.pessoaNome &&
          other.tipo == this.tipo &&
          other.email == this.email &&
          other.idColaborador == this.idColaborador &&
          other.idUsuario == this.idUsuario &&
          other.login == this.login &&
          other.senha == this.senha &&
          other.dataCadastro == this.dataCadastro &&
          other.administrador == this.administrador);
}

class ViewPessoaUsuariosCompanion extends UpdateCompanion<ViewPessoaUsuario> {
  final Value<int?> id;
  final Value<int?> idPessoa;
  final Value<String?> pessoaNome;
  final Value<String?> tipo;
  final Value<String?> email;
  final Value<int?> idColaborador;
  final Value<int?> idUsuario;
  final Value<String?> login;
  final Value<String?> senha;
  final Value<DateTime?> dataCadastro;
  final Value<String?> administrador;
  const ViewPessoaUsuariosCompanion({
    this.id = const Value.absent(),
    this.idPessoa = const Value.absent(),
    this.pessoaNome = const Value.absent(),
    this.tipo = const Value.absent(),
    this.email = const Value.absent(),
    this.idColaborador = const Value.absent(),
    this.idUsuario = const Value.absent(),
    this.login = const Value.absent(),
    this.senha = const Value.absent(),
    this.dataCadastro = const Value.absent(),
    this.administrador = const Value.absent(),
  });
  ViewPessoaUsuariosCompanion.insert({
    this.id = const Value.absent(),
    this.idPessoa = const Value.absent(),
    this.pessoaNome = const Value.absent(),
    this.tipo = const Value.absent(),
    this.email = const Value.absent(),
    this.idColaborador = const Value.absent(),
    this.idUsuario = const Value.absent(),
    this.login = const Value.absent(),
    this.senha = const Value.absent(),
    this.dataCadastro = const Value.absent(),
    this.administrador = const Value.absent(),
  });
  static Insertable<ViewPessoaUsuario> custom({
    Expression<int>? id,
    Expression<int>? idPessoa,
    Expression<String>? pessoaNome,
    Expression<String>? tipo,
    Expression<String>? email,
    Expression<int>? idColaborador,
    Expression<int>? idUsuario,
    Expression<String>? login,
    Expression<String>? senha,
    Expression<DateTime>? dataCadastro,
    Expression<String>? administrador,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (idPessoa != null) 'id_pessoa': idPessoa,
      if (pessoaNome != null) 'pessoa_nome': pessoaNome,
      if (tipo != null) 'tipo': tipo,
      if (email != null) 'email': email,
      if (idColaborador != null) 'id_colaborador': idColaborador,
      if (idUsuario != null) 'id_usuario': idUsuario,
      if (login != null) 'login': login,
      if (senha != null) 'senha': senha,
      if (dataCadastro != null) 'data_cadastro': dataCadastro,
      if (administrador != null) 'administrador': administrador,
    });
  }

  ViewPessoaUsuariosCompanion copyWith(
      {Value<int?>? id,
      Value<int?>? idPessoa,
      Value<String?>? pessoaNome,
      Value<String?>? tipo,
      Value<String?>? email,
      Value<int?>? idColaborador,
      Value<int?>? idUsuario,
      Value<String?>? login,
      Value<String?>? senha,
      Value<DateTime?>? dataCadastro,
      Value<String?>? administrador}) {
    return ViewPessoaUsuariosCompanion(
      id: id ?? this.id,
      idPessoa: idPessoa ?? this.idPessoa,
      pessoaNome: pessoaNome ?? this.pessoaNome,
      tipo: tipo ?? this.tipo,
      email: email ?? this.email,
      idColaborador: idColaborador ?? this.idColaborador,
      idUsuario: idUsuario ?? this.idUsuario,
      login: login ?? this.login,
      senha: senha ?? this.senha,
      dataCadastro: dataCadastro ?? this.dataCadastro,
      administrador: administrador ?? this.administrador,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (idPessoa.present) {
      map['id_pessoa'] = Variable<int>(idPessoa.value);
    }
    if (pessoaNome.present) {
      map['pessoa_nome'] = Variable<String>(pessoaNome.value);
    }
    if (tipo.present) {
      map['tipo'] = Variable<String>(tipo.value);
    }
    if (email.present) {
      map['email'] = Variable<String>(email.value);
    }
    if (idColaborador.present) {
      map['id_colaborador'] = Variable<int>(idColaborador.value);
    }
    if (idUsuario.present) {
      map['id_usuario'] = Variable<int>(idUsuario.value);
    }
    if (login.present) {
      map['login'] = Variable<String>(login.value);
    }
    if (senha.present) {
      map['senha'] = Variable<String>(senha.value);
    }
    if (dataCadastro.present) {
      map['data_cadastro'] = Variable<DateTime>(dataCadastro.value);
    }
    if (administrador.present) {
      map['administrador'] = Variable<String>(administrador.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('ViewPessoaUsuariosCompanion(')
          ..write('id: $id, ')
          ..write('idPessoa: $idPessoa, ')
          ..write('pessoaNome: $pessoaNome, ')
          ..write('tipo: $tipo, ')
          ..write('email: $email, ')
          ..write('idColaborador: $idColaborador, ')
          ..write('idUsuario: $idUsuario, ')
          ..write('login: $login, ')
          ..write('senha: $senha, ')
          ..write('dataCadastro: $dataCadastro, ')
          ..write('administrador: $administrador')
          ..write(')'))
        .toString();
  }
}

class $ViewPessoaClientesTable extends ViewPessoaClientes
    with TableInfo<$ViewPessoaClientesTable, ViewPessoaCliente> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $ViewPessoaClientesTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
      'id', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _nomeMeta = const VerificationMeta('nome');
  @override
  late final GeneratedColumn<String> nome = GeneratedColumn<String>(
      'nome', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 450),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _tipoMeta = const VerificationMeta('tipo');
  @override
  late final GeneratedColumn<String> tipo = GeneratedColumn<String>(
      'tipo', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 3),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _emailMeta = const VerificationMeta('email');
  @override
  late final GeneratedColumn<String> email = GeneratedColumn<String>(
      'email', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 750),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _siteMeta = const VerificationMeta('site');
  @override
  late final GeneratedColumn<String> site = GeneratedColumn<String>(
      'site', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 450),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _cpfCnpjMeta =
      const VerificationMeta('cpfCnpj');
  @override
  late final GeneratedColumn<String> cpfCnpj = GeneratedColumn<String>(
      'cpf_cnpj', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 20),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _rgIeMeta = const VerificationMeta('rgIe');
  @override
  late final GeneratedColumn<String> rgIe = GeneratedColumn<String>(
      'rg_ie', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 20),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _desdeMeta = const VerificationMeta('desde');
  @override
  late final GeneratedColumn<DateTime> desde = GeneratedColumn<DateTime>(
      'desde', aliasedName, true,
      type: DriftSqlType.dateTime, requiredDuringInsert: false);
  static const VerificationMeta _taxaDescontoMeta =
      const VerificationMeta('taxaDesconto');
  @override
  late final GeneratedColumn<double> taxaDesconto = GeneratedColumn<double>(
      'taxa_desconto', aliasedName, true,
      type: DriftSqlType.double, requiredDuringInsert: false);
  static const VerificationMeta _limiteCreditoMeta =
      const VerificationMeta('limiteCredito');
  @override
  late final GeneratedColumn<double> limiteCredito = GeneratedColumn<double>(
      'limite_credito', aliasedName, true,
      type: DriftSqlType.double, requiredDuringInsert: false);
  static const VerificationMeta _dataCadastroMeta =
      const VerificationMeta('dataCadastro');
  @override
  late final GeneratedColumn<DateTime> dataCadastro = GeneratedColumn<DateTime>(
      'data_cadastro', aliasedName, true,
      type: DriftSqlType.dateTime, requiredDuringInsert: false);
  static const VerificationMeta _observacaoMeta =
      const VerificationMeta('observacao');
  @override
  late final GeneratedColumn<String> observacao = GeneratedColumn<String>(
      'observacao', aliasedName, true,
      type: DriftSqlType.string, requiredDuringInsert: false);
  static const VerificationMeta _idPessoaMeta =
      const VerificationMeta('idPessoa');
  @override
  late final GeneratedColumn<int> idPessoa = GeneratedColumn<int>(
      'id_pessoa', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  @override
  List<GeneratedColumn> get $columns => [
        id,
        nome,
        tipo,
        email,
        site,
        cpfCnpj,
        rgIe,
        desde,
        taxaDesconto,
        limiteCredito,
        dataCadastro,
        observacao,
        idPessoa
      ];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'view_pessoa_cliente';
  @override
  VerificationContext validateIntegrity(Insertable<ViewPessoaCliente> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('nome')) {
      context.handle(
          _nomeMeta, nome.isAcceptableOrUnknown(data['nome']!, _nomeMeta));
    }
    if (data.containsKey('tipo')) {
      context.handle(
          _tipoMeta, tipo.isAcceptableOrUnknown(data['tipo']!, _tipoMeta));
    }
    if (data.containsKey('email')) {
      context.handle(
          _emailMeta, email.isAcceptableOrUnknown(data['email']!, _emailMeta));
    }
    if (data.containsKey('site')) {
      context.handle(
          _siteMeta, site.isAcceptableOrUnknown(data['site']!, _siteMeta));
    }
    if (data.containsKey('cpf_cnpj')) {
      context.handle(_cpfCnpjMeta,
          cpfCnpj.isAcceptableOrUnknown(data['cpf_cnpj']!, _cpfCnpjMeta));
    }
    if (data.containsKey('rg_ie')) {
      context.handle(
          _rgIeMeta, rgIe.isAcceptableOrUnknown(data['rg_ie']!, _rgIeMeta));
    }
    if (data.containsKey('desde')) {
      context.handle(
          _desdeMeta, desde.isAcceptableOrUnknown(data['desde']!, _desdeMeta));
    }
    if (data.containsKey('taxa_desconto')) {
      context.handle(
          _taxaDescontoMeta,
          taxaDesconto.isAcceptableOrUnknown(
              data['taxa_desconto']!, _taxaDescontoMeta));
    }
    if (data.containsKey('limite_credito')) {
      context.handle(
          _limiteCreditoMeta,
          limiteCredito.isAcceptableOrUnknown(
              data['limite_credito']!, _limiteCreditoMeta));
    }
    if (data.containsKey('data_cadastro')) {
      context.handle(
          _dataCadastroMeta,
          dataCadastro.isAcceptableOrUnknown(
              data['data_cadastro']!, _dataCadastroMeta));
    }
    if (data.containsKey('observacao')) {
      context.handle(
          _observacaoMeta,
          observacao.isAcceptableOrUnknown(
              data['observacao']!, _observacaoMeta));
    }
    if (data.containsKey('id_pessoa')) {
      context.handle(_idPessoaMeta,
          idPessoa.isAcceptableOrUnknown(data['id_pessoa']!, _idPessoaMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  ViewPessoaCliente map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return ViewPessoaCliente(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id']),
      nome: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}nome']),
      tipo: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}tipo']),
      email: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}email']),
      site: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}site']),
      cpfCnpj: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}cpf_cnpj']),
      rgIe: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}rg_ie']),
      desde: attachedDatabase.typeMapping
          .read(DriftSqlType.dateTime, data['${effectivePrefix}desde']),
      taxaDesconto: attachedDatabase.typeMapping
          .read(DriftSqlType.double, data['${effectivePrefix}taxa_desconto']),
      limiteCredito: attachedDatabase.typeMapping
          .read(DriftSqlType.double, data['${effectivePrefix}limite_credito']),
      dataCadastro: attachedDatabase.typeMapping
          .read(DriftSqlType.dateTime, data['${effectivePrefix}data_cadastro']),
      observacao: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}observacao']),
      idPessoa: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id_pessoa']),
    );
  }

  @override
  $ViewPessoaClientesTable createAlias(String alias) {
    return $ViewPessoaClientesTable(attachedDatabase, alias);
  }
}

class ViewPessoaCliente extends DataClass
    implements Insertable<ViewPessoaCliente> {
  final int? id;
  final String? nome;
  final String? tipo;
  final String? email;
  final String? site;
  final String? cpfCnpj;
  final String? rgIe;
  final DateTime? desde;
  final double? taxaDesconto;
  final double? limiteCredito;
  final DateTime? dataCadastro;
  final String? observacao;
  final int? idPessoa;
  const ViewPessoaCliente(
      {this.id,
      this.nome,
      this.tipo,
      this.email,
      this.site,
      this.cpfCnpj,
      this.rgIe,
      this.desde,
      this.taxaDesconto,
      this.limiteCredito,
      this.dataCadastro,
      this.observacao,
      this.idPessoa});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || nome != null) {
      map['nome'] = Variable<String>(nome);
    }
    if (!nullToAbsent || tipo != null) {
      map['tipo'] = Variable<String>(tipo);
    }
    if (!nullToAbsent || email != null) {
      map['email'] = Variable<String>(email);
    }
    if (!nullToAbsent || site != null) {
      map['site'] = Variable<String>(site);
    }
    if (!nullToAbsent || cpfCnpj != null) {
      map['cpf_cnpj'] = Variable<String>(cpfCnpj);
    }
    if (!nullToAbsent || rgIe != null) {
      map['rg_ie'] = Variable<String>(rgIe);
    }
    if (!nullToAbsent || desde != null) {
      map['desde'] = Variable<DateTime>(desde);
    }
    if (!nullToAbsent || taxaDesconto != null) {
      map['taxa_desconto'] = Variable<double>(taxaDesconto);
    }
    if (!nullToAbsent || limiteCredito != null) {
      map['limite_credito'] = Variable<double>(limiteCredito);
    }
    if (!nullToAbsent || dataCadastro != null) {
      map['data_cadastro'] = Variable<DateTime>(dataCadastro);
    }
    if (!nullToAbsent || observacao != null) {
      map['observacao'] = Variable<String>(observacao);
    }
    if (!nullToAbsent || idPessoa != null) {
      map['id_pessoa'] = Variable<int>(idPessoa);
    }
    return map;
  }

  factory ViewPessoaCliente.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return ViewPessoaCliente(
      id: serializer.fromJson<int?>(json['id']),
      nome: serializer.fromJson<String?>(json['nome']),
      tipo: serializer.fromJson<String?>(json['tipo']),
      email: serializer.fromJson<String?>(json['email']),
      site: serializer.fromJson<String?>(json['site']),
      cpfCnpj: serializer.fromJson<String?>(json['cpfCnpj']),
      rgIe: serializer.fromJson<String?>(json['rgIe']),
      desde: serializer.fromJson<DateTime?>(json['desde']),
      taxaDesconto: serializer.fromJson<double?>(json['taxaDesconto']),
      limiteCredito: serializer.fromJson<double?>(json['limiteCredito']),
      dataCadastro: serializer.fromJson<DateTime?>(json['dataCadastro']),
      observacao: serializer.fromJson<String?>(json['observacao']),
      idPessoa: serializer.fromJson<int?>(json['idPessoa']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'nome': serializer.toJson<String?>(nome),
      'tipo': serializer.toJson<String?>(tipo),
      'email': serializer.toJson<String?>(email),
      'site': serializer.toJson<String?>(site),
      'cpfCnpj': serializer.toJson<String?>(cpfCnpj),
      'rgIe': serializer.toJson<String?>(rgIe),
      'desde': serializer.toJson<DateTime?>(desde),
      'taxaDesconto': serializer.toJson<double?>(taxaDesconto),
      'limiteCredito': serializer.toJson<double?>(limiteCredito),
      'dataCadastro': serializer.toJson<DateTime?>(dataCadastro),
      'observacao': serializer.toJson<String?>(observacao),
      'idPessoa': serializer.toJson<int?>(idPessoa),
    };
  }

  ViewPessoaCliente copyWith(
          {Value<int?> id = const Value.absent(),
          Value<String?> nome = const Value.absent(),
          Value<String?> tipo = const Value.absent(),
          Value<String?> email = const Value.absent(),
          Value<String?> site = const Value.absent(),
          Value<String?> cpfCnpj = const Value.absent(),
          Value<String?> rgIe = const Value.absent(),
          Value<DateTime?> desde = const Value.absent(),
          Value<double?> taxaDesconto = const Value.absent(),
          Value<double?> limiteCredito = const Value.absent(),
          Value<DateTime?> dataCadastro = const Value.absent(),
          Value<String?> observacao = const Value.absent(),
          Value<int?> idPessoa = const Value.absent()}) =>
      ViewPessoaCliente(
        id: id.present ? id.value : this.id,
        nome: nome.present ? nome.value : this.nome,
        tipo: tipo.present ? tipo.value : this.tipo,
        email: email.present ? email.value : this.email,
        site: site.present ? site.value : this.site,
        cpfCnpj: cpfCnpj.present ? cpfCnpj.value : this.cpfCnpj,
        rgIe: rgIe.present ? rgIe.value : this.rgIe,
        desde: desde.present ? desde.value : this.desde,
        taxaDesconto:
            taxaDesconto.present ? taxaDesconto.value : this.taxaDesconto,
        limiteCredito:
            limiteCredito.present ? limiteCredito.value : this.limiteCredito,
        dataCadastro:
            dataCadastro.present ? dataCadastro.value : this.dataCadastro,
        observacao: observacao.present ? observacao.value : this.observacao,
        idPessoa: idPessoa.present ? idPessoa.value : this.idPessoa,
      );
  ViewPessoaCliente copyWithCompanion(ViewPessoaClientesCompanion data) {
    return ViewPessoaCliente(
      id: data.id.present ? data.id.value : this.id,
      nome: data.nome.present ? data.nome.value : this.nome,
      tipo: data.tipo.present ? data.tipo.value : this.tipo,
      email: data.email.present ? data.email.value : this.email,
      site: data.site.present ? data.site.value : this.site,
      cpfCnpj: data.cpfCnpj.present ? data.cpfCnpj.value : this.cpfCnpj,
      rgIe: data.rgIe.present ? data.rgIe.value : this.rgIe,
      desde: data.desde.present ? data.desde.value : this.desde,
      taxaDesconto: data.taxaDesconto.present
          ? data.taxaDesconto.value
          : this.taxaDesconto,
      limiteCredito: data.limiteCredito.present
          ? data.limiteCredito.value
          : this.limiteCredito,
      dataCadastro: data.dataCadastro.present
          ? data.dataCadastro.value
          : this.dataCadastro,
      observacao:
          data.observacao.present ? data.observacao.value : this.observacao,
      idPessoa: data.idPessoa.present ? data.idPessoa.value : this.idPessoa,
    );
  }

  @override
  String toString() {
    return (StringBuffer('ViewPessoaCliente(')
          ..write('id: $id, ')
          ..write('nome: $nome, ')
          ..write('tipo: $tipo, ')
          ..write('email: $email, ')
          ..write('site: $site, ')
          ..write('cpfCnpj: $cpfCnpj, ')
          ..write('rgIe: $rgIe, ')
          ..write('desde: $desde, ')
          ..write('taxaDesconto: $taxaDesconto, ')
          ..write('limiteCredito: $limiteCredito, ')
          ..write('dataCadastro: $dataCadastro, ')
          ..write('observacao: $observacao, ')
          ..write('idPessoa: $idPessoa')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(id, nome, tipo, email, site, cpfCnpj, rgIe,
      desde, taxaDesconto, limiteCredito, dataCadastro, observacao, idPessoa);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is ViewPessoaCliente &&
          other.id == this.id &&
          other.nome == this.nome &&
          other.tipo == this.tipo &&
          other.email == this.email &&
          other.site == this.site &&
          other.cpfCnpj == this.cpfCnpj &&
          other.rgIe == this.rgIe &&
          other.desde == this.desde &&
          other.taxaDesconto == this.taxaDesconto &&
          other.limiteCredito == this.limiteCredito &&
          other.dataCadastro == this.dataCadastro &&
          other.observacao == this.observacao &&
          other.idPessoa == this.idPessoa);
}

class ViewPessoaClientesCompanion extends UpdateCompanion<ViewPessoaCliente> {
  final Value<int?> id;
  final Value<String?> nome;
  final Value<String?> tipo;
  final Value<String?> email;
  final Value<String?> site;
  final Value<String?> cpfCnpj;
  final Value<String?> rgIe;
  final Value<DateTime?> desde;
  final Value<double?> taxaDesconto;
  final Value<double?> limiteCredito;
  final Value<DateTime?> dataCadastro;
  final Value<String?> observacao;
  final Value<int?> idPessoa;
  const ViewPessoaClientesCompanion({
    this.id = const Value.absent(),
    this.nome = const Value.absent(),
    this.tipo = const Value.absent(),
    this.email = const Value.absent(),
    this.site = const Value.absent(),
    this.cpfCnpj = const Value.absent(),
    this.rgIe = const Value.absent(),
    this.desde = const Value.absent(),
    this.taxaDesconto = const Value.absent(),
    this.limiteCredito = const Value.absent(),
    this.dataCadastro = const Value.absent(),
    this.observacao = const Value.absent(),
    this.idPessoa = const Value.absent(),
  });
  ViewPessoaClientesCompanion.insert({
    this.id = const Value.absent(),
    this.nome = const Value.absent(),
    this.tipo = const Value.absent(),
    this.email = const Value.absent(),
    this.site = const Value.absent(),
    this.cpfCnpj = const Value.absent(),
    this.rgIe = const Value.absent(),
    this.desde = const Value.absent(),
    this.taxaDesconto = const Value.absent(),
    this.limiteCredito = const Value.absent(),
    this.dataCadastro = const Value.absent(),
    this.observacao = const Value.absent(),
    this.idPessoa = const Value.absent(),
  });
  static Insertable<ViewPessoaCliente> custom({
    Expression<int>? id,
    Expression<String>? nome,
    Expression<String>? tipo,
    Expression<String>? email,
    Expression<String>? site,
    Expression<String>? cpfCnpj,
    Expression<String>? rgIe,
    Expression<DateTime>? desde,
    Expression<double>? taxaDesconto,
    Expression<double>? limiteCredito,
    Expression<DateTime>? dataCadastro,
    Expression<String>? observacao,
    Expression<int>? idPessoa,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (nome != null) 'nome': nome,
      if (tipo != null) 'tipo': tipo,
      if (email != null) 'email': email,
      if (site != null) 'site': site,
      if (cpfCnpj != null) 'cpf_cnpj': cpfCnpj,
      if (rgIe != null) 'rg_ie': rgIe,
      if (desde != null) 'desde': desde,
      if (taxaDesconto != null) 'taxa_desconto': taxaDesconto,
      if (limiteCredito != null) 'limite_credito': limiteCredito,
      if (dataCadastro != null) 'data_cadastro': dataCadastro,
      if (observacao != null) 'observacao': observacao,
      if (idPessoa != null) 'id_pessoa': idPessoa,
    });
  }

  ViewPessoaClientesCompanion copyWith(
      {Value<int?>? id,
      Value<String?>? nome,
      Value<String?>? tipo,
      Value<String?>? email,
      Value<String?>? site,
      Value<String?>? cpfCnpj,
      Value<String?>? rgIe,
      Value<DateTime?>? desde,
      Value<double?>? taxaDesconto,
      Value<double?>? limiteCredito,
      Value<DateTime?>? dataCadastro,
      Value<String?>? observacao,
      Value<int?>? idPessoa}) {
    return ViewPessoaClientesCompanion(
      id: id ?? this.id,
      nome: nome ?? this.nome,
      tipo: tipo ?? this.tipo,
      email: email ?? this.email,
      site: site ?? this.site,
      cpfCnpj: cpfCnpj ?? this.cpfCnpj,
      rgIe: rgIe ?? this.rgIe,
      desde: desde ?? this.desde,
      taxaDesconto: taxaDesconto ?? this.taxaDesconto,
      limiteCredito: limiteCredito ?? this.limiteCredito,
      dataCadastro: dataCadastro ?? this.dataCadastro,
      observacao: observacao ?? this.observacao,
      idPessoa: idPessoa ?? this.idPessoa,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (nome.present) {
      map['nome'] = Variable<String>(nome.value);
    }
    if (tipo.present) {
      map['tipo'] = Variable<String>(tipo.value);
    }
    if (email.present) {
      map['email'] = Variable<String>(email.value);
    }
    if (site.present) {
      map['site'] = Variable<String>(site.value);
    }
    if (cpfCnpj.present) {
      map['cpf_cnpj'] = Variable<String>(cpfCnpj.value);
    }
    if (rgIe.present) {
      map['rg_ie'] = Variable<String>(rgIe.value);
    }
    if (desde.present) {
      map['desde'] = Variable<DateTime>(desde.value);
    }
    if (taxaDesconto.present) {
      map['taxa_desconto'] = Variable<double>(taxaDesconto.value);
    }
    if (limiteCredito.present) {
      map['limite_credito'] = Variable<double>(limiteCredito.value);
    }
    if (dataCadastro.present) {
      map['data_cadastro'] = Variable<DateTime>(dataCadastro.value);
    }
    if (observacao.present) {
      map['observacao'] = Variable<String>(observacao.value);
    }
    if (idPessoa.present) {
      map['id_pessoa'] = Variable<int>(idPessoa.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('ViewPessoaClientesCompanion(')
          ..write('id: $id, ')
          ..write('nome: $nome, ')
          ..write('tipo: $tipo, ')
          ..write('email: $email, ')
          ..write('site: $site, ')
          ..write('cpfCnpj: $cpfCnpj, ')
          ..write('rgIe: $rgIe, ')
          ..write('desde: $desde, ')
          ..write('taxaDesconto: $taxaDesconto, ')
          ..write('limiteCredito: $limiteCredito, ')
          ..write('dataCadastro: $dataCadastro, ')
          ..write('observacao: $observacao, ')
          ..write('idPessoa: $idPessoa')
          ..write(')'))
        .toString();
  }
}

class $ViewPessoaFornecedorsTable extends ViewPessoaFornecedors
    with TableInfo<$ViewPessoaFornecedorsTable, ViewPessoaFornecedor> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $ViewPessoaFornecedorsTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
      'id', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _nomeMeta = const VerificationMeta('nome');
  @override
  late final GeneratedColumn<String> nome = GeneratedColumn<String>(
      'nome', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 450),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _tipoMeta = const VerificationMeta('tipo');
  @override
  late final GeneratedColumn<String> tipo = GeneratedColumn<String>(
      'tipo', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 3),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _emailMeta = const VerificationMeta('email');
  @override
  late final GeneratedColumn<String> email = GeneratedColumn<String>(
      'email', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 750),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _siteMeta = const VerificationMeta('site');
  @override
  late final GeneratedColumn<String> site = GeneratedColumn<String>(
      'site', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 450),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _cpfCnpjMeta =
      const VerificationMeta('cpfCnpj');
  @override
  late final GeneratedColumn<String> cpfCnpj = GeneratedColumn<String>(
      'cpf_cnpj', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 20),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _rgIeMeta = const VerificationMeta('rgIe');
  @override
  late final GeneratedColumn<String> rgIe = GeneratedColumn<String>(
      'rg_ie', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 20),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _desdeMeta = const VerificationMeta('desde');
  @override
  late final GeneratedColumn<DateTime> desde = GeneratedColumn<DateTime>(
      'desde', aliasedName, true,
      type: DriftSqlType.dateTime, requiredDuringInsert: false);
  static const VerificationMeta _dataCadastroMeta =
      const VerificationMeta('dataCadastro');
  @override
  late final GeneratedColumn<DateTime> dataCadastro = GeneratedColumn<DateTime>(
      'data_cadastro', aliasedName, true,
      type: DriftSqlType.dateTime, requiredDuringInsert: false);
  static const VerificationMeta _observacaoMeta =
      const VerificationMeta('observacao');
  @override
  late final GeneratedColumn<String> observacao = GeneratedColumn<String>(
      'observacao', aliasedName, true,
      type: DriftSqlType.string, requiredDuringInsert: false);
  static const VerificationMeta _idPessoaMeta =
      const VerificationMeta('idPessoa');
  @override
  late final GeneratedColumn<int> idPessoa = GeneratedColumn<int>(
      'id_pessoa', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  @override
  List<GeneratedColumn> get $columns => [
        id,
        nome,
        tipo,
        email,
        site,
        cpfCnpj,
        rgIe,
        desde,
        dataCadastro,
        observacao,
        idPessoa
      ];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'view_pessoa_fornecedor';
  @override
  VerificationContext validateIntegrity(
      Insertable<ViewPessoaFornecedor> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('nome')) {
      context.handle(
          _nomeMeta, nome.isAcceptableOrUnknown(data['nome']!, _nomeMeta));
    }
    if (data.containsKey('tipo')) {
      context.handle(
          _tipoMeta, tipo.isAcceptableOrUnknown(data['tipo']!, _tipoMeta));
    }
    if (data.containsKey('email')) {
      context.handle(
          _emailMeta, email.isAcceptableOrUnknown(data['email']!, _emailMeta));
    }
    if (data.containsKey('site')) {
      context.handle(
          _siteMeta, site.isAcceptableOrUnknown(data['site']!, _siteMeta));
    }
    if (data.containsKey('cpf_cnpj')) {
      context.handle(_cpfCnpjMeta,
          cpfCnpj.isAcceptableOrUnknown(data['cpf_cnpj']!, _cpfCnpjMeta));
    }
    if (data.containsKey('rg_ie')) {
      context.handle(
          _rgIeMeta, rgIe.isAcceptableOrUnknown(data['rg_ie']!, _rgIeMeta));
    }
    if (data.containsKey('desde')) {
      context.handle(
          _desdeMeta, desde.isAcceptableOrUnknown(data['desde']!, _desdeMeta));
    }
    if (data.containsKey('data_cadastro')) {
      context.handle(
          _dataCadastroMeta,
          dataCadastro.isAcceptableOrUnknown(
              data['data_cadastro']!, _dataCadastroMeta));
    }
    if (data.containsKey('observacao')) {
      context.handle(
          _observacaoMeta,
          observacao.isAcceptableOrUnknown(
              data['observacao']!, _observacaoMeta));
    }
    if (data.containsKey('id_pessoa')) {
      context.handle(_idPessoaMeta,
          idPessoa.isAcceptableOrUnknown(data['id_pessoa']!, _idPessoaMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  ViewPessoaFornecedor map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return ViewPessoaFornecedor(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id']),
      nome: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}nome']),
      tipo: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}tipo']),
      email: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}email']),
      site: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}site']),
      cpfCnpj: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}cpf_cnpj']),
      rgIe: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}rg_ie']),
      desde: attachedDatabase.typeMapping
          .read(DriftSqlType.dateTime, data['${effectivePrefix}desde']),
      dataCadastro: attachedDatabase.typeMapping
          .read(DriftSqlType.dateTime, data['${effectivePrefix}data_cadastro']),
      observacao: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}observacao']),
      idPessoa: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id_pessoa']),
    );
  }

  @override
  $ViewPessoaFornecedorsTable createAlias(String alias) {
    return $ViewPessoaFornecedorsTable(attachedDatabase, alias);
  }
}

class ViewPessoaFornecedor extends DataClass
    implements Insertable<ViewPessoaFornecedor> {
  final int? id;
  final String? nome;
  final String? tipo;
  final String? email;
  final String? site;
  final String? cpfCnpj;
  final String? rgIe;
  final DateTime? desde;
  final DateTime? dataCadastro;
  final String? observacao;
  final int? idPessoa;
  const ViewPessoaFornecedor(
      {this.id,
      this.nome,
      this.tipo,
      this.email,
      this.site,
      this.cpfCnpj,
      this.rgIe,
      this.desde,
      this.dataCadastro,
      this.observacao,
      this.idPessoa});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || nome != null) {
      map['nome'] = Variable<String>(nome);
    }
    if (!nullToAbsent || tipo != null) {
      map['tipo'] = Variable<String>(tipo);
    }
    if (!nullToAbsent || email != null) {
      map['email'] = Variable<String>(email);
    }
    if (!nullToAbsent || site != null) {
      map['site'] = Variable<String>(site);
    }
    if (!nullToAbsent || cpfCnpj != null) {
      map['cpf_cnpj'] = Variable<String>(cpfCnpj);
    }
    if (!nullToAbsent || rgIe != null) {
      map['rg_ie'] = Variable<String>(rgIe);
    }
    if (!nullToAbsent || desde != null) {
      map['desde'] = Variable<DateTime>(desde);
    }
    if (!nullToAbsent || dataCadastro != null) {
      map['data_cadastro'] = Variable<DateTime>(dataCadastro);
    }
    if (!nullToAbsent || observacao != null) {
      map['observacao'] = Variable<String>(observacao);
    }
    if (!nullToAbsent || idPessoa != null) {
      map['id_pessoa'] = Variable<int>(idPessoa);
    }
    return map;
  }

  factory ViewPessoaFornecedor.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return ViewPessoaFornecedor(
      id: serializer.fromJson<int?>(json['id']),
      nome: serializer.fromJson<String?>(json['nome']),
      tipo: serializer.fromJson<String?>(json['tipo']),
      email: serializer.fromJson<String?>(json['email']),
      site: serializer.fromJson<String?>(json['site']),
      cpfCnpj: serializer.fromJson<String?>(json['cpfCnpj']),
      rgIe: serializer.fromJson<String?>(json['rgIe']),
      desde: serializer.fromJson<DateTime?>(json['desde']),
      dataCadastro: serializer.fromJson<DateTime?>(json['dataCadastro']),
      observacao: serializer.fromJson<String?>(json['observacao']),
      idPessoa: serializer.fromJson<int?>(json['idPessoa']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'nome': serializer.toJson<String?>(nome),
      'tipo': serializer.toJson<String?>(tipo),
      'email': serializer.toJson<String?>(email),
      'site': serializer.toJson<String?>(site),
      'cpfCnpj': serializer.toJson<String?>(cpfCnpj),
      'rgIe': serializer.toJson<String?>(rgIe),
      'desde': serializer.toJson<DateTime?>(desde),
      'dataCadastro': serializer.toJson<DateTime?>(dataCadastro),
      'observacao': serializer.toJson<String?>(observacao),
      'idPessoa': serializer.toJson<int?>(idPessoa),
    };
  }

  ViewPessoaFornecedor copyWith(
          {Value<int?> id = const Value.absent(),
          Value<String?> nome = const Value.absent(),
          Value<String?> tipo = const Value.absent(),
          Value<String?> email = const Value.absent(),
          Value<String?> site = const Value.absent(),
          Value<String?> cpfCnpj = const Value.absent(),
          Value<String?> rgIe = const Value.absent(),
          Value<DateTime?> desde = const Value.absent(),
          Value<DateTime?> dataCadastro = const Value.absent(),
          Value<String?> observacao = const Value.absent(),
          Value<int?> idPessoa = const Value.absent()}) =>
      ViewPessoaFornecedor(
        id: id.present ? id.value : this.id,
        nome: nome.present ? nome.value : this.nome,
        tipo: tipo.present ? tipo.value : this.tipo,
        email: email.present ? email.value : this.email,
        site: site.present ? site.value : this.site,
        cpfCnpj: cpfCnpj.present ? cpfCnpj.value : this.cpfCnpj,
        rgIe: rgIe.present ? rgIe.value : this.rgIe,
        desde: desde.present ? desde.value : this.desde,
        dataCadastro:
            dataCadastro.present ? dataCadastro.value : this.dataCadastro,
        observacao: observacao.present ? observacao.value : this.observacao,
        idPessoa: idPessoa.present ? idPessoa.value : this.idPessoa,
      );
  ViewPessoaFornecedor copyWithCompanion(ViewPessoaFornecedorsCompanion data) {
    return ViewPessoaFornecedor(
      id: data.id.present ? data.id.value : this.id,
      nome: data.nome.present ? data.nome.value : this.nome,
      tipo: data.tipo.present ? data.tipo.value : this.tipo,
      email: data.email.present ? data.email.value : this.email,
      site: data.site.present ? data.site.value : this.site,
      cpfCnpj: data.cpfCnpj.present ? data.cpfCnpj.value : this.cpfCnpj,
      rgIe: data.rgIe.present ? data.rgIe.value : this.rgIe,
      desde: data.desde.present ? data.desde.value : this.desde,
      dataCadastro: data.dataCadastro.present
          ? data.dataCadastro.value
          : this.dataCadastro,
      observacao:
          data.observacao.present ? data.observacao.value : this.observacao,
      idPessoa: data.idPessoa.present ? data.idPessoa.value : this.idPessoa,
    );
  }

  @override
  String toString() {
    return (StringBuffer('ViewPessoaFornecedor(')
          ..write('id: $id, ')
          ..write('nome: $nome, ')
          ..write('tipo: $tipo, ')
          ..write('email: $email, ')
          ..write('site: $site, ')
          ..write('cpfCnpj: $cpfCnpj, ')
          ..write('rgIe: $rgIe, ')
          ..write('desde: $desde, ')
          ..write('dataCadastro: $dataCadastro, ')
          ..write('observacao: $observacao, ')
          ..write('idPessoa: $idPessoa')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(id, nome, tipo, email, site, cpfCnpj, rgIe,
      desde, dataCadastro, observacao, idPessoa);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is ViewPessoaFornecedor &&
          other.id == this.id &&
          other.nome == this.nome &&
          other.tipo == this.tipo &&
          other.email == this.email &&
          other.site == this.site &&
          other.cpfCnpj == this.cpfCnpj &&
          other.rgIe == this.rgIe &&
          other.desde == this.desde &&
          other.dataCadastro == this.dataCadastro &&
          other.observacao == this.observacao &&
          other.idPessoa == this.idPessoa);
}

class ViewPessoaFornecedorsCompanion
    extends UpdateCompanion<ViewPessoaFornecedor> {
  final Value<int?> id;
  final Value<String?> nome;
  final Value<String?> tipo;
  final Value<String?> email;
  final Value<String?> site;
  final Value<String?> cpfCnpj;
  final Value<String?> rgIe;
  final Value<DateTime?> desde;
  final Value<DateTime?> dataCadastro;
  final Value<String?> observacao;
  final Value<int?> idPessoa;
  const ViewPessoaFornecedorsCompanion({
    this.id = const Value.absent(),
    this.nome = const Value.absent(),
    this.tipo = const Value.absent(),
    this.email = const Value.absent(),
    this.site = const Value.absent(),
    this.cpfCnpj = const Value.absent(),
    this.rgIe = const Value.absent(),
    this.desde = const Value.absent(),
    this.dataCadastro = const Value.absent(),
    this.observacao = const Value.absent(),
    this.idPessoa = const Value.absent(),
  });
  ViewPessoaFornecedorsCompanion.insert({
    this.id = const Value.absent(),
    this.nome = const Value.absent(),
    this.tipo = const Value.absent(),
    this.email = const Value.absent(),
    this.site = const Value.absent(),
    this.cpfCnpj = const Value.absent(),
    this.rgIe = const Value.absent(),
    this.desde = const Value.absent(),
    this.dataCadastro = const Value.absent(),
    this.observacao = const Value.absent(),
    this.idPessoa = const Value.absent(),
  });
  static Insertable<ViewPessoaFornecedor> custom({
    Expression<int>? id,
    Expression<String>? nome,
    Expression<String>? tipo,
    Expression<String>? email,
    Expression<String>? site,
    Expression<String>? cpfCnpj,
    Expression<String>? rgIe,
    Expression<DateTime>? desde,
    Expression<DateTime>? dataCadastro,
    Expression<String>? observacao,
    Expression<int>? idPessoa,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (nome != null) 'nome': nome,
      if (tipo != null) 'tipo': tipo,
      if (email != null) 'email': email,
      if (site != null) 'site': site,
      if (cpfCnpj != null) 'cpf_cnpj': cpfCnpj,
      if (rgIe != null) 'rg_ie': rgIe,
      if (desde != null) 'desde': desde,
      if (dataCadastro != null) 'data_cadastro': dataCadastro,
      if (observacao != null) 'observacao': observacao,
      if (idPessoa != null) 'id_pessoa': idPessoa,
    });
  }

  ViewPessoaFornecedorsCompanion copyWith(
      {Value<int?>? id,
      Value<String?>? nome,
      Value<String?>? tipo,
      Value<String?>? email,
      Value<String?>? site,
      Value<String?>? cpfCnpj,
      Value<String?>? rgIe,
      Value<DateTime?>? desde,
      Value<DateTime?>? dataCadastro,
      Value<String?>? observacao,
      Value<int?>? idPessoa}) {
    return ViewPessoaFornecedorsCompanion(
      id: id ?? this.id,
      nome: nome ?? this.nome,
      tipo: tipo ?? this.tipo,
      email: email ?? this.email,
      site: site ?? this.site,
      cpfCnpj: cpfCnpj ?? this.cpfCnpj,
      rgIe: rgIe ?? this.rgIe,
      desde: desde ?? this.desde,
      dataCadastro: dataCadastro ?? this.dataCadastro,
      observacao: observacao ?? this.observacao,
      idPessoa: idPessoa ?? this.idPessoa,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (nome.present) {
      map['nome'] = Variable<String>(nome.value);
    }
    if (tipo.present) {
      map['tipo'] = Variable<String>(tipo.value);
    }
    if (email.present) {
      map['email'] = Variable<String>(email.value);
    }
    if (site.present) {
      map['site'] = Variable<String>(site.value);
    }
    if (cpfCnpj.present) {
      map['cpf_cnpj'] = Variable<String>(cpfCnpj.value);
    }
    if (rgIe.present) {
      map['rg_ie'] = Variable<String>(rgIe.value);
    }
    if (desde.present) {
      map['desde'] = Variable<DateTime>(desde.value);
    }
    if (dataCadastro.present) {
      map['data_cadastro'] = Variable<DateTime>(dataCadastro.value);
    }
    if (observacao.present) {
      map['observacao'] = Variable<String>(observacao.value);
    }
    if (idPessoa.present) {
      map['id_pessoa'] = Variable<int>(idPessoa.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('ViewPessoaFornecedorsCompanion(')
          ..write('id: $id, ')
          ..write('nome: $nome, ')
          ..write('tipo: $tipo, ')
          ..write('email: $email, ')
          ..write('site: $site, ')
          ..write('cpfCnpj: $cpfCnpj, ')
          ..write('rgIe: $rgIe, ')
          ..write('desde: $desde, ')
          ..write('dataCadastro: $dataCadastro, ')
          ..write('observacao: $observacao, ')
          ..write('idPessoa: $idPessoa')
          ..write(')'))
        .toString();
  }
}

class $ViewPessoaColaboradorsTable extends ViewPessoaColaboradors
    with TableInfo<$ViewPessoaColaboradorsTable, ViewPessoaColaborador> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $ViewPessoaColaboradorsTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
      'id', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _nomeMeta = const VerificationMeta('nome');
  @override
  late final GeneratedColumn<String> nome = GeneratedColumn<String>(
      'nome', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 450),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _tipoMeta = const VerificationMeta('tipo');
  @override
  late final GeneratedColumn<String> tipo = GeneratedColumn<String>(
      'tipo', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 3),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _emailMeta = const VerificationMeta('email');
  @override
  late final GeneratedColumn<String> email = GeneratedColumn<String>(
      'email', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 750),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _siteMeta = const VerificationMeta('site');
  @override
  late final GeneratedColumn<String> site = GeneratedColumn<String>(
      'site', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 450),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _cpfCnpjMeta =
      const VerificationMeta('cpfCnpj');
  @override
  late final GeneratedColumn<String> cpfCnpj = GeneratedColumn<String>(
      'cpf_cnpj', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 20),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _rgIeMeta = const VerificationMeta('rgIe');
  @override
  late final GeneratedColumn<String> rgIe = GeneratedColumn<String>(
      'rg_ie', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 20),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _matriculaMeta =
      const VerificationMeta('matricula');
  @override
  late final GeneratedColumn<String> matricula = GeneratedColumn<String>(
      'matricula', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 50),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _dataCadastroMeta =
      const VerificationMeta('dataCadastro');
  @override
  late final GeneratedColumn<DateTime> dataCadastro = GeneratedColumn<DateTime>(
      'data_cadastro', aliasedName, true,
      type: DriftSqlType.dateTime, requiredDuringInsert: false);
  static const VerificationMeta _dataAdmissaoMeta =
      const VerificationMeta('dataAdmissao');
  @override
  late final GeneratedColumn<DateTime> dataAdmissao = GeneratedColumn<DateTime>(
      'data_admissao', aliasedName, true,
      type: DriftSqlType.dateTime, requiredDuringInsert: false);
  static const VerificationMeta _dataDemissaoMeta =
      const VerificationMeta('dataDemissao');
  @override
  late final GeneratedColumn<DateTime> dataDemissao = GeneratedColumn<DateTime>(
      'data_demissao', aliasedName, true,
      type: DriftSqlType.dateTime, requiredDuringInsert: false);
  static const VerificationMeta _ctpsNumeroMeta =
      const VerificationMeta('ctpsNumero');
  @override
  late final GeneratedColumn<String> ctpsNumero = GeneratedColumn<String>(
      'ctps_numero', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 20),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _ctpsSerieMeta =
      const VerificationMeta('ctpsSerie');
  @override
  late final GeneratedColumn<String> ctpsSerie = GeneratedColumn<String>(
      'ctps_serie', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 10),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _ctpsDataExpedicaoMeta =
      const VerificationMeta('ctpsDataExpedicao');
  @override
  late final GeneratedColumn<DateTime> ctpsDataExpedicao =
      GeneratedColumn<DateTime>('ctps_data_expedicao', aliasedName, true,
          type: DriftSqlType.dateTime, requiredDuringInsert: false);
  static const VerificationMeta _ctpsUfMeta = const VerificationMeta('ctpsUf');
  @override
  late final GeneratedColumn<String> ctpsUf = GeneratedColumn<String>(
      'ctps_uf', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 2),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _observacaoMeta =
      const VerificationMeta('observacao');
  @override
  late final GeneratedColumn<String> observacao = GeneratedColumn<String>(
      'observacao', aliasedName, true,
      type: DriftSqlType.string, requiredDuringInsert: false);
  static const VerificationMeta _logradouroMeta =
      const VerificationMeta('logradouro');
  @override
  late final GeneratedColumn<String> logradouro = GeneratedColumn<String>(
      'logradouro', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 450),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _numeroMeta = const VerificationMeta('numero');
  @override
  late final GeneratedColumn<String> numero = GeneratedColumn<String>(
      'numero', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 20),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _complementoMeta =
      const VerificationMeta('complemento');
  @override
  late final GeneratedColumn<String> complemento = GeneratedColumn<String>(
      'complemento', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 450),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _bairroMeta = const VerificationMeta('bairro');
  @override
  late final GeneratedColumn<String> bairro = GeneratedColumn<String>(
      'bairro', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 150),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _cidadeMeta = const VerificationMeta('cidade');
  @override
  late final GeneratedColumn<String> cidade = GeneratedColumn<String>(
      'cidade', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 150),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _cepMeta = const VerificationMeta('cep');
  @override
  late final GeneratedColumn<String> cep = GeneratedColumn<String>(
      'cep', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 10),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _municipioIbgeMeta =
      const VerificationMeta('municipioIbge');
  @override
  late final GeneratedColumn<String> municipioIbge = GeneratedColumn<String>(
      'municipio_ibge', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 10),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _ufMeta = const VerificationMeta('uf');
  @override
  late final GeneratedColumn<String> uf = GeneratedColumn<String>(
      'uf', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 2),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _idPessoaMeta =
      const VerificationMeta('idPessoa');
  @override
  late final GeneratedColumn<int> idPessoa = GeneratedColumn<int>(
      'id_pessoa', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _idCargoMeta =
      const VerificationMeta('idCargo');
  @override
  late final GeneratedColumn<int> idCargo = GeneratedColumn<int>(
      'id_cargo', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _idSetorMeta =
      const VerificationMeta('idSetor');
  @override
  late final GeneratedColumn<int> idSetor = GeneratedColumn<int>(
      'id_setor', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  @override
  List<GeneratedColumn> get $columns => [
        id,
        nome,
        tipo,
        email,
        site,
        cpfCnpj,
        rgIe,
        matricula,
        dataCadastro,
        dataAdmissao,
        dataDemissao,
        ctpsNumero,
        ctpsSerie,
        ctpsDataExpedicao,
        ctpsUf,
        observacao,
        logradouro,
        numero,
        complemento,
        bairro,
        cidade,
        cep,
        municipioIbge,
        uf,
        idPessoa,
        idCargo,
        idSetor
      ];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'view_pessoa_colaborador';
  @override
  VerificationContext validateIntegrity(
      Insertable<ViewPessoaColaborador> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('nome')) {
      context.handle(
          _nomeMeta, nome.isAcceptableOrUnknown(data['nome']!, _nomeMeta));
    }
    if (data.containsKey('tipo')) {
      context.handle(
          _tipoMeta, tipo.isAcceptableOrUnknown(data['tipo']!, _tipoMeta));
    }
    if (data.containsKey('email')) {
      context.handle(
          _emailMeta, email.isAcceptableOrUnknown(data['email']!, _emailMeta));
    }
    if (data.containsKey('site')) {
      context.handle(
          _siteMeta, site.isAcceptableOrUnknown(data['site']!, _siteMeta));
    }
    if (data.containsKey('cpf_cnpj')) {
      context.handle(_cpfCnpjMeta,
          cpfCnpj.isAcceptableOrUnknown(data['cpf_cnpj']!, _cpfCnpjMeta));
    }
    if (data.containsKey('rg_ie')) {
      context.handle(
          _rgIeMeta, rgIe.isAcceptableOrUnknown(data['rg_ie']!, _rgIeMeta));
    }
    if (data.containsKey('matricula')) {
      context.handle(_matriculaMeta,
          matricula.isAcceptableOrUnknown(data['matricula']!, _matriculaMeta));
    }
    if (data.containsKey('data_cadastro')) {
      context.handle(
          _dataCadastroMeta,
          dataCadastro.isAcceptableOrUnknown(
              data['data_cadastro']!, _dataCadastroMeta));
    }
    if (data.containsKey('data_admissao')) {
      context.handle(
          _dataAdmissaoMeta,
          dataAdmissao.isAcceptableOrUnknown(
              data['data_admissao']!, _dataAdmissaoMeta));
    }
    if (data.containsKey('data_demissao')) {
      context.handle(
          _dataDemissaoMeta,
          dataDemissao.isAcceptableOrUnknown(
              data['data_demissao']!, _dataDemissaoMeta));
    }
    if (data.containsKey('ctps_numero')) {
      context.handle(
          _ctpsNumeroMeta,
          ctpsNumero.isAcceptableOrUnknown(
              data['ctps_numero']!, _ctpsNumeroMeta));
    }
    if (data.containsKey('ctps_serie')) {
      context.handle(_ctpsSerieMeta,
          ctpsSerie.isAcceptableOrUnknown(data['ctps_serie']!, _ctpsSerieMeta));
    }
    if (data.containsKey('ctps_data_expedicao')) {
      context.handle(
          _ctpsDataExpedicaoMeta,
          ctpsDataExpedicao.isAcceptableOrUnknown(
              data['ctps_data_expedicao']!, _ctpsDataExpedicaoMeta));
    }
    if (data.containsKey('ctps_uf')) {
      context.handle(_ctpsUfMeta,
          ctpsUf.isAcceptableOrUnknown(data['ctps_uf']!, _ctpsUfMeta));
    }
    if (data.containsKey('observacao')) {
      context.handle(
          _observacaoMeta,
          observacao.isAcceptableOrUnknown(
              data['observacao']!, _observacaoMeta));
    }
    if (data.containsKey('logradouro')) {
      context.handle(
          _logradouroMeta,
          logradouro.isAcceptableOrUnknown(
              data['logradouro']!, _logradouroMeta));
    }
    if (data.containsKey('numero')) {
      context.handle(_numeroMeta,
          numero.isAcceptableOrUnknown(data['numero']!, _numeroMeta));
    }
    if (data.containsKey('complemento')) {
      context.handle(
          _complementoMeta,
          complemento.isAcceptableOrUnknown(
              data['complemento']!, _complementoMeta));
    }
    if (data.containsKey('bairro')) {
      context.handle(_bairroMeta,
          bairro.isAcceptableOrUnknown(data['bairro']!, _bairroMeta));
    }
    if (data.containsKey('cidade')) {
      context.handle(_cidadeMeta,
          cidade.isAcceptableOrUnknown(data['cidade']!, _cidadeMeta));
    }
    if (data.containsKey('cep')) {
      context.handle(
          _cepMeta, cep.isAcceptableOrUnknown(data['cep']!, _cepMeta));
    }
    if (data.containsKey('municipio_ibge')) {
      context.handle(
          _municipioIbgeMeta,
          municipioIbge.isAcceptableOrUnknown(
              data['municipio_ibge']!, _municipioIbgeMeta));
    }
    if (data.containsKey('uf')) {
      context.handle(_ufMeta, uf.isAcceptableOrUnknown(data['uf']!, _ufMeta));
    }
    if (data.containsKey('id_pessoa')) {
      context.handle(_idPessoaMeta,
          idPessoa.isAcceptableOrUnknown(data['id_pessoa']!, _idPessoaMeta));
    }
    if (data.containsKey('id_cargo')) {
      context.handle(_idCargoMeta,
          idCargo.isAcceptableOrUnknown(data['id_cargo']!, _idCargoMeta));
    }
    if (data.containsKey('id_setor')) {
      context.handle(_idSetorMeta,
          idSetor.isAcceptableOrUnknown(data['id_setor']!, _idSetorMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  ViewPessoaColaborador map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return ViewPessoaColaborador(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id']),
      nome: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}nome']),
      tipo: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}tipo']),
      email: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}email']),
      site: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}site']),
      cpfCnpj: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}cpf_cnpj']),
      rgIe: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}rg_ie']),
      matricula: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}matricula']),
      dataCadastro: attachedDatabase.typeMapping
          .read(DriftSqlType.dateTime, data['${effectivePrefix}data_cadastro']),
      dataAdmissao: attachedDatabase.typeMapping
          .read(DriftSqlType.dateTime, data['${effectivePrefix}data_admissao']),
      dataDemissao: attachedDatabase.typeMapping
          .read(DriftSqlType.dateTime, data['${effectivePrefix}data_demissao']),
      ctpsNumero: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}ctps_numero']),
      ctpsSerie: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}ctps_serie']),
      ctpsDataExpedicao: attachedDatabase.typeMapping.read(
          DriftSqlType.dateTime, data['${effectivePrefix}ctps_data_expedicao']),
      ctpsUf: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}ctps_uf']),
      observacao: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}observacao']),
      logradouro: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}logradouro']),
      numero: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}numero']),
      complemento: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}complemento']),
      bairro: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}bairro']),
      cidade: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}cidade']),
      cep: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}cep']),
      municipioIbge: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}municipio_ibge']),
      uf: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}uf']),
      idPessoa: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id_pessoa']),
      idCargo: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id_cargo']),
      idSetor: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id_setor']),
    );
  }

  @override
  $ViewPessoaColaboradorsTable createAlias(String alias) {
    return $ViewPessoaColaboradorsTable(attachedDatabase, alias);
  }
}

class ViewPessoaColaborador extends DataClass
    implements Insertable<ViewPessoaColaborador> {
  final int? id;
  final String? nome;
  final String? tipo;
  final String? email;
  final String? site;
  final String? cpfCnpj;
  final String? rgIe;
  final String? matricula;
  final DateTime? dataCadastro;
  final DateTime? dataAdmissao;
  final DateTime? dataDemissao;
  final String? ctpsNumero;
  final String? ctpsSerie;
  final DateTime? ctpsDataExpedicao;
  final String? ctpsUf;
  final String? observacao;
  final String? logradouro;
  final String? numero;
  final String? complemento;
  final String? bairro;
  final String? cidade;
  final String? cep;
  final String? municipioIbge;
  final String? uf;
  final int? idPessoa;
  final int? idCargo;
  final int? idSetor;
  const ViewPessoaColaborador(
      {this.id,
      this.nome,
      this.tipo,
      this.email,
      this.site,
      this.cpfCnpj,
      this.rgIe,
      this.matricula,
      this.dataCadastro,
      this.dataAdmissao,
      this.dataDemissao,
      this.ctpsNumero,
      this.ctpsSerie,
      this.ctpsDataExpedicao,
      this.ctpsUf,
      this.observacao,
      this.logradouro,
      this.numero,
      this.complemento,
      this.bairro,
      this.cidade,
      this.cep,
      this.municipioIbge,
      this.uf,
      this.idPessoa,
      this.idCargo,
      this.idSetor});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || nome != null) {
      map['nome'] = Variable<String>(nome);
    }
    if (!nullToAbsent || tipo != null) {
      map['tipo'] = Variable<String>(tipo);
    }
    if (!nullToAbsent || email != null) {
      map['email'] = Variable<String>(email);
    }
    if (!nullToAbsent || site != null) {
      map['site'] = Variable<String>(site);
    }
    if (!nullToAbsent || cpfCnpj != null) {
      map['cpf_cnpj'] = Variable<String>(cpfCnpj);
    }
    if (!nullToAbsent || rgIe != null) {
      map['rg_ie'] = Variable<String>(rgIe);
    }
    if (!nullToAbsent || matricula != null) {
      map['matricula'] = Variable<String>(matricula);
    }
    if (!nullToAbsent || dataCadastro != null) {
      map['data_cadastro'] = Variable<DateTime>(dataCadastro);
    }
    if (!nullToAbsent || dataAdmissao != null) {
      map['data_admissao'] = Variable<DateTime>(dataAdmissao);
    }
    if (!nullToAbsent || dataDemissao != null) {
      map['data_demissao'] = Variable<DateTime>(dataDemissao);
    }
    if (!nullToAbsent || ctpsNumero != null) {
      map['ctps_numero'] = Variable<String>(ctpsNumero);
    }
    if (!nullToAbsent || ctpsSerie != null) {
      map['ctps_serie'] = Variable<String>(ctpsSerie);
    }
    if (!nullToAbsent || ctpsDataExpedicao != null) {
      map['ctps_data_expedicao'] = Variable<DateTime>(ctpsDataExpedicao);
    }
    if (!nullToAbsent || ctpsUf != null) {
      map['ctps_uf'] = Variable<String>(ctpsUf);
    }
    if (!nullToAbsent || observacao != null) {
      map['observacao'] = Variable<String>(observacao);
    }
    if (!nullToAbsent || logradouro != null) {
      map['logradouro'] = Variable<String>(logradouro);
    }
    if (!nullToAbsent || numero != null) {
      map['numero'] = Variable<String>(numero);
    }
    if (!nullToAbsent || complemento != null) {
      map['complemento'] = Variable<String>(complemento);
    }
    if (!nullToAbsent || bairro != null) {
      map['bairro'] = Variable<String>(bairro);
    }
    if (!nullToAbsent || cidade != null) {
      map['cidade'] = Variable<String>(cidade);
    }
    if (!nullToAbsent || cep != null) {
      map['cep'] = Variable<String>(cep);
    }
    if (!nullToAbsent || municipioIbge != null) {
      map['municipio_ibge'] = Variable<String>(municipioIbge);
    }
    if (!nullToAbsent || uf != null) {
      map['uf'] = Variable<String>(uf);
    }
    if (!nullToAbsent || idPessoa != null) {
      map['id_pessoa'] = Variable<int>(idPessoa);
    }
    if (!nullToAbsent || idCargo != null) {
      map['id_cargo'] = Variable<int>(idCargo);
    }
    if (!nullToAbsent || idSetor != null) {
      map['id_setor'] = Variable<int>(idSetor);
    }
    return map;
  }

  factory ViewPessoaColaborador.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return ViewPessoaColaborador(
      id: serializer.fromJson<int?>(json['id']),
      nome: serializer.fromJson<String?>(json['nome']),
      tipo: serializer.fromJson<String?>(json['tipo']),
      email: serializer.fromJson<String?>(json['email']),
      site: serializer.fromJson<String?>(json['site']),
      cpfCnpj: serializer.fromJson<String?>(json['cpfCnpj']),
      rgIe: serializer.fromJson<String?>(json['rgIe']),
      matricula: serializer.fromJson<String?>(json['matricula']),
      dataCadastro: serializer.fromJson<DateTime?>(json['dataCadastro']),
      dataAdmissao: serializer.fromJson<DateTime?>(json['dataAdmissao']),
      dataDemissao: serializer.fromJson<DateTime?>(json['dataDemissao']),
      ctpsNumero: serializer.fromJson<String?>(json['ctpsNumero']),
      ctpsSerie: serializer.fromJson<String?>(json['ctpsSerie']),
      ctpsDataExpedicao:
          serializer.fromJson<DateTime?>(json['ctpsDataExpedicao']),
      ctpsUf: serializer.fromJson<String?>(json['ctpsUf']),
      observacao: serializer.fromJson<String?>(json['observacao']),
      logradouro: serializer.fromJson<String?>(json['logradouro']),
      numero: serializer.fromJson<String?>(json['numero']),
      complemento: serializer.fromJson<String?>(json['complemento']),
      bairro: serializer.fromJson<String?>(json['bairro']),
      cidade: serializer.fromJson<String?>(json['cidade']),
      cep: serializer.fromJson<String?>(json['cep']),
      municipioIbge: serializer.fromJson<String?>(json['municipioIbge']),
      uf: serializer.fromJson<String?>(json['uf']),
      idPessoa: serializer.fromJson<int?>(json['idPessoa']),
      idCargo: serializer.fromJson<int?>(json['idCargo']),
      idSetor: serializer.fromJson<int?>(json['idSetor']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'nome': serializer.toJson<String?>(nome),
      'tipo': serializer.toJson<String?>(tipo),
      'email': serializer.toJson<String?>(email),
      'site': serializer.toJson<String?>(site),
      'cpfCnpj': serializer.toJson<String?>(cpfCnpj),
      'rgIe': serializer.toJson<String?>(rgIe),
      'matricula': serializer.toJson<String?>(matricula),
      'dataCadastro': serializer.toJson<DateTime?>(dataCadastro),
      'dataAdmissao': serializer.toJson<DateTime?>(dataAdmissao),
      'dataDemissao': serializer.toJson<DateTime?>(dataDemissao),
      'ctpsNumero': serializer.toJson<String?>(ctpsNumero),
      'ctpsSerie': serializer.toJson<String?>(ctpsSerie),
      'ctpsDataExpedicao': serializer.toJson<DateTime?>(ctpsDataExpedicao),
      'ctpsUf': serializer.toJson<String?>(ctpsUf),
      'observacao': serializer.toJson<String?>(observacao),
      'logradouro': serializer.toJson<String?>(logradouro),
      'numero': serializer.toJson<String?>(numero),
      'complemento': serializer.toJson<String?>(complemento),
      'bairro': serializer.toJson<String?>(bairro),
      'cidade': serializer.toJson<String?>(cidade),
      'cep': serializer.toJson<String?>(cep),
      'municipioIbge': serializer.toJson<String?>(municipioIbge),
      'uf': serializer.toJson<String?>(uf),
      'idPessoa': serializer.toJson<int?>(idPessoa),
      'idCargo': serializer.toJson<int?>(idCargo),
      'idSetor': serializer.toJson<int?>(idSetor),
    };
  }

  ViewPessoaColaborador copyWith(
          {Value<int?> id = const Value.absent(),
          Value<String?> nome = const Value.absent(),
          Value<String?> tipo = const Value.absent(),
          Value<String?> email = const Value.absent(),
          Value<String?> site = const Value.absent(),
          Value<String?> cpfCnpj = const Value.absent(),
          Value<String?> rgIe = const Value.absent(),
          Value<String?> matricula = const Value.absent(),
          Value<DateTime?> dataCadastro = const Value.absent(),
          Value<DateTime?> dataAdmissao = const Value.absent(),
          Value<DateTime?> dataDemissao = const Value.absent(),
          Value<String?> ctpsNumero = const Value.absent(),
          Value<String?> ctpsSerie = const Value.absent(),
          Value<DateTime?> ctpsDataExpedicao = const Value.absent(),
          Value<String?> ctpsUf = const Value.absent(),
          Value<String?> observacao = const Value.absent(),
          Value<String?> logradouro = const Value.absent(),
          Value<String?> numero = const Value.absent(),
          Value<String?> complemento = const Value.absent(),
          Value<String?> bairro = const Value.absent(),
          Value<String?> cidade = const Value.absent(),
          Value<String?> cep = const Value.absent(),
          Value<String?> municipioIbge = const Value.absent(),
          Value<String?> uf = const Value.absent(),
          Value<int?> idPessoa = const Value.absent(),
          Value<int?> idCargo = const Value.absent(),
          Value<int?> idSetor = const Value.absent()}) =>
      ViewPessoaColaborador(
        id: id.present ? id.value : this.id,
        nome: nome.present ? nome.value : this.nome,
        tipo: tipo.present ? tipo.value : this.tipo,
        email: email.present ? email.value : this.email,
        site: site.present ? site.value : this.site,
        cpfCnpj: cpfCnpj.present ? cpfCnpj.value : this.cpfCnpj,
        rgIe: rgIe.present ? rgIe.value : this.rgIe,
        matricula: matricula.present ? matricula.value : this.matricula,
        dataCadastro:
            dataCadastro.present ? dataCadastro.value : this.dataCadastro,
        dataAdmissao:
            dataAdmissao.present ? dataAdmissao.value : this.dataAdmissao,
        dataDemissao:
            dataDemissao.present ? dataDemissao.value : this.dataDemissao,
        ctpsNumero: ctpsNumero.present ? ctpsNumero.value : this.ctpsNumero,
        ctpsSerie: ctpsSerie.present ? ctpsSerie.value : this.ctpsSerie,
        ctpsDataExpedicao: ctpsDataExpedicao.present
            ? ctpsDataExpedicao.value
            : this.ctpsDataExpedicao,
        ctpsUf: ctpsUf.present ? ctpsUf.value : this.ctpsUf,
        observacao: observacao.present ? observacao.value : this.observacao,
        logradouro: logradouro.present ? logradouro.value : this.logradouro,
        numero: numero.present ? numero.value : this.numero,
        complemento: complemento.present ? complemento.value : this.complemento,
        bairro: bairro.present ? bairro.value : this.bairro,
        cidade: cidade.present ? cidade.value : this.cidade,
        cep: cep.present ? cep.value : this.cep,
        municipioIbge:
            municipioIbge.present ? municipioIbge.value : this.municipioIbge,
        uf: uf.present ? uf.value : this.uf,
        idPessoa: idPessoa.present ? idPessoa.value : this.idPessoa,
        idCargo: idCargo.present ? idCargo.value : this.idCargo,
        idSetor: idSetor.present ? idSetor.value : this.idSetor,
      );
  ViewPessoaColaborador copyWithCompanion(
      ViewPessoaColaboradorsCompanion data) {
    return ViewPessoaColaborador(
      id: data.id.present ? data.id.value : this.id,
      nome: data.nome.present ? data.nome.value : this.nome,
      tipo: data.tipo.present ? data.tipo.value : this.tipo,
      email: data.email.present ? data.email.value : this.email,
      site: data.site.present ? data.site.value : this.site,
      cpfCnpj: data.cpfCnpj.present ? data.cpfCnpj.value : this.cpfCnpj,
      rgIe: data.rgIe.present ? data.rgIe.value : this.rgIe,
      matricula: data.matricula.present ? data.matricula.value : this.matricula,
      dataCadastro: data.dataCadastro.present
          ? data.dataCadastro.value
          : this.dataCadastro,
      dataAdmissao: data.dataAdmissao.present
          ? data.dataAdmissao.value
          : this.dataAdmissao,
      dataDemissao: data.dataDemissao.present
          ? data.dataDemissao.value
          : this.dataDemissao,
      ctpsNumero:
          data.ctpsNumero.present ? data.ctpsNumero.value : this.ctpsNumero,
      ctpsSerie: data.ctpsSerie.present ? data.ctpsSerie.value : this.ctpsSerie,
      ctpsDataExpedicao: data.ctpsDataExpedicao.present
          ? data.ctpsDataExpedicao.value
          : this.ctpsDataExpedicao,
      ctpsUf: data.ctpsUf.present ? data.ctpsUf.value : this.ctpsUf,
      observacao:
          data.observacao.present ? data.observacao.value : this.observacao,
      logradouro:
          data.logradouro.present ? data.logradouro.value : this.logradouro,
      numero: data.numero.present ? data.numero.value : this.numero,
      complemento:
          data.complemento.present ? data.complemento.value : this.complemento,
      bairro: data.bairro.present ? data.bairro.value : this.bairro,
      cidade: data.cidade.present ? data.cidade.value : this.cidade,
      cep: data.cep.present ? data.cep.value : this.cep,
      municipioIbge: data.municipioIbge.present
          ? data.municipioIbge.value
          : this.municipioIbge,
      uf: data.uf.present ? data.uf.value : this.uf,
      idPessoa: data.idPessoa.present ? data.idPessoa.value : this.idPessoa,
      idCargo: data.idCargo.present ? data.idCargo.value : this.idCargo,
      idSetor: data.idSetor.present ? data.idSetor.value : this.idSetor,
    );
  }

  @override
  String toString() {
    return (StringBuffer('ViewPessoaColaborador(')
          ..write('id: $id, ')
          ..write('nome: $nome, ')
          ..write('tipo: $tipo, ')
          ..write('email: $email, ')
          ..write('site: $site, ')
          ..write('cpfCnpj: $cpfCnpj, ')
          ..write('rgIe: $rgIe, ')
          ..write('matricula: $matricula, ')
          ..write('dataCadastro: $dataCadastro, ')
          ..write('dataAdmissao: $dataAdmissao, ')
          ..write('dataDemissao: $dataDemissao, ')
          ..write('ctpsNumero: $ctpsNumero, ')
          ..write('ctpsSerie: $ctpsSerie, ')
          ..write('ctpsDataExpedicao: $ctpsDataExpedicao, ')
          ..write('ctpsUf: $ctpsUf, ')
          ..write('observacao: $observacao, ')
          ..write('logradouro: $logradouro, ')
          ..write('numero: $numero, ')
          ..write('complemento: $complemento, ')
          ..write('bairro: $bairro, ')
          ..write('cidade: $cidade, ')
          ..write('cep: $cep, ')
          ..write('municipioIbge: $municipioIbge, ')
          ..write('uf: $uf, ')
          ..write('idPessoa: $idPessoa, ')
          ..write('idCargo: $idCargo, ')
          ..write('idSetor: $idSetor')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hashAll([
        id,
        nome,
        tipo,
        email,
        site,
        cpfCnpj,
        rgIe,
        matricula,
        dataCadastro,
        dataAdmissao,
        dataDemissao,
        ctpsNumero,
        ctpsSerie,
        ctpsDataExpedicao,
        ctpsUf,
        observacao,
        logradouro,
        numero,
        complemento,
        bairro,
        cidade,
        cep,
        municipioIbge,
        uf,
        idPessoa,
        idCargo,
        idSetor
      ]);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is ViewPessoaColaborador &&
          other.id == this.id &&
          other.nome == this.nome &&
          other.tipo == this.tipo &&
          other.email == this.email &&
          other.site == this.site &&
          other.cpfCnpj == this.cpfCnpj &&
          other.rgIe == this.rgIe &&
          other.matricula == this.matricula &&
          other.dataCadastro == this.dataCadastro &&
          other.dataAdmissao == this.dataAdmissao &&
          other.dataDemissao == this.dataDemissao &&
          other.ctpsNumero == this.ctpsNumero &&
          other.ctpsSerie == this.ctpsSerie &&
          other.ctpsDataExpedicao == this.ctpsDataExpedicao &&
          other.ctpsUf == this.ctpsUf &&
          other.observacao == this.observacao &&
          other.logradouro == this.logradouro &&
          other.numero == this.numero &&
          other.complemento == this.complemento &&
          other.bairro == this.bairro &&
          other.cidade == this.cidade &&
          other.cep == this.cep &&
          other.municipioIbge == this.municipioIbge &&
          other.uf == this.uf &&
          other.idPessoa == this.idPessoa &&
          other.idCargo == this.idCargo &&
          other.idSetor == this.idSetor);
}

class ViewPessoaColaboradorsCompanion
    extends UpdateCompanion<ViewPessoaColaborador> {
  final Value<int?> id;
  final Value<String?> nome;
  final Value<String?> tipo;
  final Value<String?> email;
  final Value<String?> site;
  final Value<String?> cpfCnpj;
  final Value<String?> rgIe;
  final Value<String?> matricula;
  final Value<DateTime?> dataCadastro;
  final Value<DateTime?> dataAdmissao;
  final Value<DateTime?> dataDemissao;
  final Value<String?> ctpsNumero;
  final Value<String?> ctpsSerie;
  final Value<DateTime?> ctpsDataExpedicao;
  final Value<String?> ctpsUf;
  final Value<String?> observacao;
  final Value<String?> logradouro;
  final Value<String?> numero;
  final Value<String?> complemento;
  final Value<String?> bairro;
  final Value<String?> cidade;
  final Value<String?> cep;
  final Value<String?> municipioIbge;
  final Value<String?> uf;
  final Value<int?> idPessoa;
  final Value<int?> idCargo;
  final Value<int?> idSetor;
  const ViewPessoaColaboradorsCompanion({
    this.id = const Value.absent(),
    this.nome = const Value.absent(),
    this.tipo = const Value.absent(),
    this.email = const Value.absent(),
    this.site = const Value.absent(),
    this.cpfCnpj = const Value.absent(),
    this.rgIe = const Value.absent(),
    this.matricula = const Value.absent(),
    this.dataCadastro = const Value.absent(),
    this.dataAdmissao = const Value.absent(),
    this.dataDemissao = const Value.absent(),
    this.ctpsNumero = const Value.absent(),
    this.ctpsSerie = const Value.absent(),
    this.ctpsDataExpedicao = const Value.absent(),
    this.ctpsUf = const Value.absent(),
    this.observacao = const Value.absent(),
    this.logradouro = const Value.absent(),
    this.numero = const Value.absent(),
    this.complemento = const Value.absent(),
    this.bairro = const Value.absent(),
    this.cidade = const Value.absent(),
    this.cep = const Value.absent(),
    this.municipioIbge = const Value.absent(),
    this.uf = const Value.absent(),
    this.idPessoa = const Value.absent(),
    this.idCargo = const Value.absent(),
    this.idSetor = const Value.absent(),
  });
  ViewPessoaColaboradorsCompanion.insert({
    this.id = const Value.absent(),
    this.nome = const Value.absent(),
    this.tipo = const Value.absent(),
    this.email = const Value.absent(),
    this.site = const Value.absent(),
    this.cpfCnpj = const Value.absent(),
    this.rgIe = const Value.absent(),
    this.matricula = const Value.absent(),
    this.dataCadastro = const Value.absent(),
    this.dataAdmissao = const Value.absent(),
    this.dataDemissao = const Value.absent(),
    this.ctpsNumero = const Value.absent(),
    this.ctpsSerie = const Value.absent(),
    this.ctpsDataExpedicao = const Value.absent(),
    this.ctpsUf = const Value.absent(),
    this.observacao = const Value.absent(),
    this.logradouro = const Value.absent(),
    this.numero = const Value.absent(),
    this.complemento = const Value.absent(),
    this.bairro = const Value.absent(),
    this.cidade = const Value.absent(),
    this.cep = const Value.absent(),
    this.municipioIbge = const Value.absent(),
    this.uf = const Value.absent(),
    this.idPessoa = const Value.absent(),
    this.idCargo = const Value.absent(),
    this.idSetor = const Value.absent(),
  });
  static Insertable<ViewPessoaColaborador> custom({
    Expression<int>? id,
    Expression<String>? nome,
    Expression<String>? tipo,
    Expression<String>? email,
    Expression<String>? site,
    Expression<String>? cpfCnpj,
    Expression<String>? rgIe,
    Expression<String>? matricula,
    Expression<DateTime>? dataCadastro,
    Expression<DateTime>? dataAdmissao,
    Expression<DateTime>? dataDemissao,
    Expression<String>? ctpsNumero,
    Expression<String>? ctpsSerie,
    Expression<DateTime>? ctpsDataExpedicao,
    Expression<String>? ctpsUf,
    Expression<String>? observacao,
    Expression<String>? logradouro,
    Expression<String>? numero,
    Expression<String>? complemento,
    Expression<String>? bairro,
    Expression<String>? cidade,
    Expression<String>? cep,
    Expression<String>? municipioIbge,
    Expression<String>? uf,
    Expression<int>? idPessoa,
    Expression<int>? idCargo,
    Expression<int>? idSetor,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (nome != null) 'nome': nome,
      if (tipo != null) 'tipo': tipo,
      if (email != null) 'email': email,
      if (site != null) 'site': site,
      if (cpfCnpj != null) 'cpf_cnpj': cpfCnpj,
      if (rgIe != null) 'rg_ie': rgIe,
      if (matricula != null) 'matricula': matricula,
      if (dataCadastro != null) 'data_cadastro': dataCadastro,
      if (dataAdmissao != null) 'data_admissao': dataAdmissao,
      if (dataDemissao != null) 'data_demissao': dataDemissao,
      if (ctpsNumero != null) 'ctps_numero': ctpsNumero,
      if (ctpsSerie != null) 'ctps_serie': ctpsSerie,
      if (ctpsDataExpedicao != null) 'ctps_data_expedicao': ctpsDataExpedicao,
      if (ctpsUf != null) 'ctps_uf': ctpsUf,
      if (observacao != null) 'observacao': observacao,
      if (logradouro != null) 'logradouro': logradouro,
      if (numero != null) 'numero': numero,
      if (complemento != null) 'complemento': complemento,
      if (bairro != null) 'bairro': bairro,
      if (cidade != null) 'cidade': cidade,
      if (cep != null) 'cep': cep,
      if (municipioIbge != null) 'municipio_ibge': municipioIbge,
      if (uf != null) 'uf': uf,
      if (idPessoa != null) 'id_pessoa': idPessoa,
      if (idCargo != null) 'id_cargo': idCargo,
      if (idSetor != null) 'id_setor': idSetor,
    });
  }

  ViewPessoaColaboradorsCompanion copyWith(
      {Value<int?>? id,
      Value<String?>? nome,
      Value<String?>? tipo,
      Value<String?>? email,
      Value<String?>? site,
      Value<String?>? cpfCnpj,
      Value<String?>? rgIe,
      Value<String?>? matricula,
      Value<DateTime?>? dataCadastro,
      Value<DateTime?>? dataAdmissao,
      Value<DateTime?>? dataDemissao,
      Value<String?>? ctpsNumero,
      Value<String?>? ctpsSerie,
      Value<DateTime?>? ctpsDataExpedicao,
      Value<String?>? ctpsUf,
      Value<String?>? observacao,
      Value<String?>? logradouro,
      Value<String?>? numero,
      Value<String?>? complemento,
      Value<String?>? bairro,
      Value<String?>? cidade,
      Value<String?>? cep,
      Value<String?>? municipioIbge,
      Value<String?>? uf,
      Value<int?>? idPessoa,
      Value<int?>? idCargo,
      Value<int?>? idSetor}) {
    return ViewPessoaColaboradorsCompanion(
      id: id ?? this.id,
      nome: nome ?? this.nome,
      tipo: tipo ?? this.tipo,
      email: email ?? this.email,
      site: site ?? this.site,
      cpfCnpj: cpfCnpj ?? this.cpfCnpj,
      rgIe: rgIe ?? this.rgIe,
      matricula: matricula ?? this.matricula,
      dataCadastro: dataCadastro ?? this.dataCadastro,
      dataAdmissao: dataAdmissao ?? this.dataAdmissao,
      dataDemissao: dataDemissao ?? this.dataDemissao,
      ctpsNumero: ctpsNumero ?? this.ctpsNumero,
      ctpsSerie: ctpsSerie ?? this.ctpsSerie,
      ctpsDataExpedicao: ctpsDataExpedicao ?? this.ctpsDataExpedicao,
      ctpsUf: ctpsUf ?? this.ctpsUf,
      observacao: observacao ?? this.observacao,
      logradouro: logradouro ?? this.logradouro,
      numero: numero ?? this.numero,
      complemento: complemento ?? this.complemento,
      bairro: bairro ?? this.bairro,
      cidade: cidade ?? this.cidade,
      cep: cep ?? this.cep,
      municipioIbge: municipioIbge ?? this.municipioIbge,
      uf: uf ?? this.uf,
      idPessoa: idPessoa ?? this.idPessoa,
      idCargo: idCargo ?? this.idCargo,
      idSetor: idSetor ?? this.idSetor,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (nome.present) {
      map['nome'] = Variable<String>(nome.value);
    }
    if (tipo.present) {
      map['tipo'] = Variable<String>(tipo.value);
    }
    if (email.present) {
      map['email'] = Variable<String>(email.value);
    }
    if (site.present) {
      map['site'] = Variable<String>(site.value);
    }
    if (cpfCnpj.present) {
      map['cpf_cnpj'] = Variable<String>(cpfCnpj.value);
    }
    if (rgIe.present) {
      map['rg_ie'] = Variable<String>(rgIe.value);
    }
    if (matricula.present) {
      map['matricula'] = Variable<String>(matricula.value);
    }
    if (dataCadastro.present) {
      map['data_cadastro'] = Variable<DateTime>(dataCadastro.value);
    }
    if (dataAdmissao.present) {
      map['data_admissao'] = Variable<DateTime>(dataAdmissao.value);
    }
    if (dataDemissao.present) {
      map['data_demissao'] = Variable<DateTime>(dataDemissao.value);
    }
    if (ctpsNumero.present) {
      map['ctps_numero'] = Variable<String>(ctpsNumero.value);
    }
    if (ctpsSerie.present) {
      map['ctps_serie'] = Variable<String>(ctpsSerie.value);
    }
    if (ctpsDataExpedicao.present) {
      map['ctps_data_expedicao'] = Variable<DateTime>(ctpsDataExpedicao.value);
    }
    if (ctpsUf.present) {
      map['ctps_uf'] = Variable<String>(ctpsUf.value);
    }
    if (observacao.present) {
      map['observacao'] = Variable<String>(observacao.value);
    }
    if (logradouro.present) {
      map['logradouro'] = Variable<String>(logradouro.value);
    }
    if (numero.present) {
      map['numero'] = Variable<String>(numero.value);
    }
    if (complemento.present) {
      map['complemento'] = Variable<String>(complemento.value);
    }
    if (bairro.present) {
      map['bairro'] = Variable<String>(bairro.value);
    }
    if (cidade.present) {
      map['cidade'] = Variable<String>(cidade.value);
    }
    if (cep.present) {
      map['cep'] = Variable<String>(cep.value);
    }
    if (municipioIbge.present) {
      map['municipio_ibge'] = Variable<String>(municipioIbge.value);
    }
    if (uf.present) {
      map['uf'] = Variable<String>(uf.value);
    }
    if (idPessoa.present) {
      map['id_pessoa'] = Variable<int>(idPessoa.value);
    }
    if (idCargo.present) {
      map['id_cargo'] = Variable<int>(idCargo.value);
    }
    if (idSetor.present) {
      map['id_setor'] = Variable<int>(idSetor.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('ViewPessoaColaboradorsCompanion(')
          ..write('id: $id, ')
          ..write('nome: $nome, ')
          ..write('tipo: $tipo, ')
          ..write('email: $email, ')
          ..write('site: $site, ')
          ..write('cpfCnpj: $cpfCnpj, ')
          ..write('rgIe: $rgIe, ')
          ..write('matricula: $matricula, ')
          ..write('dataCadastro: $dataCadastro, ')
          ..write('dataAdmissao: $dataAdmissao, ')
          ..write('dataDemissao: $dataDemissao, ')
          ..write('ctpsNumero: $ctpsNumero, ')
          ..write('ctpsSerie: $ctpsSerie, ')
          ..write('ctpsDataExpedicao: $ctpsDataExpedicao, ')
          ..write('ctpsUf: $ctpsUf, ')
          ..write('observacao: $observacao, ')
          ..write('logradouro: $logradouro, ')
          ..write('numero: $numero, ')
          ..write('complemento: $complemento, ')
          ..write('bairro: $bairro, ')
          ..write('cidade: $cidade, ')
          ..write('cep: $cep, ')
          ..write('municipioIbge: $municipioIbge, ')
          ..write('uf: $uf, ')
          ..write('idPessoa: $idPessoa, ')
          ..write('idCargo: $idCargo, ')
          ..write('idSetor: $idSetor')
          ..write(')'))
        .toString();
  }
}

abstract class _$AppDatabase extends GeneratedDatabase {
  _$AppDatabase(QueryExecutor e) : super(e);
  $AppDatabaseManager get managers => $AppDatabaseManager(this);
  late final $ContratoHistoricoReajustesTable contratoHistoricoReajustes =
      $ContratoHistoricoReajustesTable(this);
  late final $ContratoPrevFaturamentosTable contratoPrevFaturamentos =
      $ContratoPrevFaturamentosTable(this);
  late final $ContratoHistFaturamentosTable contratoHistFaturamentos =
      $ContratoHistFaturamentosTable(this);
  late final $ContratosTable contratos = $ContratosTable(this);
  late final $SetorsTable setors = $SetorsTable(this);
  late final $TipoContratosTable tipoContratos = $TipoContratosTable(this);
  late final $ContratoTipoServicosTable contratoTipoServicos =
      $ContratoTipoServicosTable(this);
  late final $ContratoSolicitacaoServicosTable contratoSolicitacaoServicos =
      $ContratoSolicitacaoServicosTable(this);
  late final $ContratoTemplatesTable contratoTemplates =
      $ContratoTemplatesTable(this);
  late final $ViewControleAcessosTable viewControleAcessos =
      $ViewControleAcessosTable(this);
  late final $ViewPessoaUsuariosTable viewPessoaUsuarios =
      $ViewPessoaUsuariosTable(this);
  late final $ViewPessoaClientesTable viewPessoaClientes =
      $ViewPessoaClientesTable(this);
  late final $ViewPessoaFornecedorsTable viewPessoaFornecedors =
      $ViewPessoaFornecedorsTable(this);
  late final $ViewPessoaColaboradorsTable viewPessoaColaboradors =
      $ViewPessoaColaboradorsTable(this);
  late final ContratoDao contratoDao = ContratoDao(this as AppDatabase);
  late final SetorDao setorDao = SetorDao(this as AppDatabase);
  late final TipoContratoDao tipoContratoDao =
      TipoContratoDao(this as AppDatabase);
  late final ContratoTipoServicoDao contratoTipoServicoDao =
      ContratoTipoServicoDao(this as AppDatabase);
  late final ContratoSolicitacaoServicoDao contratoSolicitacaoServicoDao =
      ContratoSolicitacaoServicoDao(this as AppDatabase);
  late final ContratoTemplateDao contratoTemplateDao =
      ContratoTemplateDao(this as AppDatabase);
  late final ViewControleAcessoDao viewControleAcessoDao =
      ViewControleAcessoDao(this as AppDatabase);
  late final ViewPessoaUsuarioDao viewPessoaUsuarioDao =
      ViewPessoaUsuarioDao(this as AppDatabase);
  late final ViewPessoaClienteDao viewPessoaClienteDao =
      ViewPessoaClienteDao(this as AppDatabase);
  late final ViewPessoaFornecedorDao viewPessoaFornecedorDao =
      ViewPessoaFornecedorDao(this as AppDatabase);
  late final ViewPessoaColaboradorDao viewPessoaColaboradorDao =
      ViewPessoaColaboradorDao(this as AppDatabase);
  @override
  Iterable<TableInfo<Table, Object?>> get allTables =>
      allSchemaEntities.whereType<TableInfo<Table, Object?>>();
  @override
  List<DatabaseSchemaEntity> get allSchemaEntities => [
        contratoHistoricoReajustes,
        contratoPrevFaturamentos,
        contratoHistFaturamentos,
        contratos,
        setors,
        tipoContratos,
        contratoTipoServicos,
        contratoSolicitacaoServicos,
        contratoTemplates,
        viewControleAcessos,
        viewPessoaUsuarios,
        viewPessoaClientes,
        viewPessoaFornecedors,
        viewPessoaColaboradors
      ];
}

typedef $$ContratoHistoricoReajustesTableCreateCompanionBuilder
    = ContratoHistoricoReajustesCompanion Function({
  Value<int?> id,
  Value<int?> idContrato,
  Value<double?> indice,
  Value<double?> valorAnterior,
  Value<double?> valorAtual,
  Value<DateTime?> dataReajuste,
  Value<String?> observacao,
});
typedef $$ContratoHistoricoReajustesTableUpdateCompanionBuilder
    = ContratoHistoricoReajustesCompanion Function({
  Value<int?> id,
  Value<int?> idContrato,
  Value<double?> indice,
  Value<double?> valorAnterior,
  Value<double?> valorAtual,
  Value<DateTime?> dataReajuste,
  Value<String?> observacao,
});

class $$ContratoHistoricoReajustesTableTableManager extends RootTableManager<
    _$AppDatabase,
    $ContratoHistoricoReajustesTable,
    ContratoHistoricoReajuste,
    $$ContratoHistoricoReajustesTableFilterComposer,
    $$ContratoHistoricoReajustesTableOrderingComposer,
    $$ContratoHistoricoReajustesTableCreateCompanionBuilder,
    $$ContratoHistoricoReajustesTableUpdateCompanionBuilder> {
  $$ContratoHistoricoReajustesTableTableManager(
      _$AppDatabase db, $ContratoHistoricoReajustesTable table)
      : super(TableManagerState(
          db: db,
          table: table,
          filteringComposer: $$ContratoHistoricoReajustesTableFilterComposer(
              ComposerState(db, table)),
          orderingComposer: $$ContratoHistoricoReajustesTableOrderingComposer(
              ComposerState(db, table)),
          updateCompanionCallback: ({
            Value<int?> id = const Value.absent(),
            Value<int?> idContrato = const Value.absent(),
            Value<double?> indice = const Value.absent(),
            Value<double?> valorAnterior = const Value.absent(),
            Value<double?> valorAtual = const Value.absent(),
            Value<DateTime?> dataReajuste = const Value.absent(),
            Value<String?> observacao = const Value.absent(),
          }) =>
              ContratoHistoricoReajustesCompanion(
            id: id,
            idContrato: idContrato,
            indice: indice,
            valorAnterior: valorAnterior,
            valorAtual: valorAtual,
            dataReajuste: dataReajuste,
            observacao: observacao,
          ),
          createCompanionCallback: ({
            Value<int?> id = const Value.absent(),
            Value<int?> idContrato = const Value.absent(),
            Value<double?> indice = const Value.absent(),
            Value<double?> valorAnterior = const Value.absent(),
            Value<double?> valorAtual = const Value.absent(),
            Value<DateTime?> dataReajuste = const Value.absent(),
            Value<String?> observacao = const Value.absent(),
          }) =>
              ContratoHistoricoReajustesCompanion.insert(
            id: id,
            idContrato: idContrato,
            indice: indice,
            valorAnterior: valorAnterior,
            valorAtual: valorAtual,
            dataReajuste: dataReajuste,
            observacao: observacao,
          ),
        ));
}

class $$ContratoHistoricoReajustesTableFilterComposer
    extends FilterComposer<_$AppDatabase, $ContratoHistoricoReajustesTable> {
  $$ContratoHistoricoReajustesTableFilterComposer(super.$state);
  ColumnFilters<int> get id => $state.composableBuilder(
      column: $state.table.id,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<int> get idContrato => $state.composableBuilder(
      column: $state.table.idContrato,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<double> get indice => $state.composableBuilder(
      column: $state.table.indice,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<double> get valorAnterior => $state.composableBuilder(
      column: $state.table.valorAnterior,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<double> get valorAtual => $state.composableBuilder(
      column: $state.table.valorAtual,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<DateTime> get dataReajuste => $state.composableBuilder(
      column: $state.table.dataReajuste,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get observacao => $state.composableBuilder(
      column: $state.table.observacao,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));
}

class $$ContratoHistoricoReajustesTableOrderingComposer
    extends OrderingComposer<_$AppDatabase, $ContratoHistoricoReajustesTable> {
  $$ContratoHistoricoReajustesTableOrderingComposer(super.$state);
  ColumnOrderings<int> get id => $state.composableBuilder(
      column: $state.table.id,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<int> get idContrato => $state.composableBuilder(
      column: $state.table.idContrato,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<double> get indice => $state.composableBuilder(
      column: $state.table.indice,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<double> get valorAnterior => $state.composableBuilder(
      column: $state.table.valorAnterior,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<double> get valorAtual => $state.composableBuilder(
      column: $state.table.valorAtual,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<DateTime> get dataReajuste => $state.composableBuilder(
      column: $state.table.dataReajuste,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get observacao => $state.composableBuilder(
      column: $state.table.observacao,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));
}

typedef $$ContratoPrevFaturamentosTableCreateCompanionBuilder
    = ContratoPrevFaturamentosCompanion Function({
  Value<int?> id,
  Value<int?> idContrato,
  Value<DateTime?> dataPrevista,
  Value<double?> valor,
});
typedef $$ContratoPrevFaturamentosTableUpdateCompanionBuilder
    = ContratoPrevFaturamentosCompanion Function({
  Value<int?> id,
  Value<int?> idContrato,
  Value<DateTime?> dataPrevista,
  Value<double?> valor,
});

class $$ContratoPrevFaturamentosTableTableManager extends RootTableManager<
    _$AppDatabase,
    $ContratoPrevFaturamentosTable,
    ContratoPrevFaturamento,
    $$ContratoPrevFaturamentosTableFilterComposer,
    $$ContratoPrevFaturamentosTableOrderingComposer,
    $$ContratoPrevFaturamentosTableCreateCompanionBuilder,
    $$ContratoPrevFaturamentosTableUpdateCompanionBuilder> {
  $$ContratoPrevFaturamentosTableTableManager(
      _$AppDatabase db, $ContratoPrevFaturamentosTable table)
      : super(TableManagerState(
          db: db,
          table: table,
          filteringComposer: $$ContratoPrevFaturamentosTableFilterComposer(
              ComposerState(db, table)),
          orderingComposer: $$ContratoPrevFaturamentosTableOrderingComposer(
              ComposerState(db, table)),
          updateCompanionCallback: ({
            Value<int?> id = const Value.absent(),
            Value<int?> idContrato = const Value.absent(),
            Value<DateTime?> dataPrevista = const Value.absent(),
            Value<double?> valor = const Value.absent(),
          }) =>
              ContratoPrevFaturamentosCompanion(
            id: id,
            idContrato: idContrato,
            dataPrevista: dataPrevista,
            valor: valor,
          ),
          createCompanionCallback: ({
            Value<int?> id = const Value.absent(),
            Value<int?> idContrato = const Value.absent(),
            Value<DateTime?> dataPrevista = const Value.absent(),
            Value<double?> valor = const Value.absent(),
          }) =>
              ContratoPrevFaturamentosCompanion.insert(
            id: id,
            idContrato: idContrato,
            dataPrevista: dataPrevista,
            valor: valor,
          ),
        ));
}

class $$ContratoPrevFaturamentosTableFilterComposer
    extends FilterComposer<_$AppDatabase, $ContratoPrevFaturamentosTable> {
  $$ContratoPrevFaturamentosTableFilterComposer(super.$state);
  ColumnFilters<int> get id => $state.composableBuilder(
      column: $state.table.id,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<int> get idContrato => $state.composableBuilder(
      column: $state.table.idContrato,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<DateTime> get dataPrevista => $state.composableBuilder(
      column: $state.table.dataPrevista,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<double> get valor => $state.composableBuilder(
      column: $state.table.valor,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));
}

class $$ContratoPrevFaturamentosTableOrderingComposer
    extends OrderingComposer<_$AppDatabase, $ContratoPrevFaturamentosTable> {
  $$ContratoPrevFaturamentosTableOrderingComposer(super.$state);
  ColumnOrderings<int> get id => $state.composableBuilder(
      column: $state.table.id,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<int> get idContrato => $state.composableBuilder(
      column: $state.table.idContrato,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<DateTime> get dataPrevista => $state.composableBuilder(
      column: $state.table.dataPrevista,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<double> get valor => $state.composableBuilder(
      column: $state.table.valor,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));
}

typedef $$ContratoHistFaturamentosTableCreateCompanionBuilder
    = ContratoHistFaturamentosCompanion Function({
  Value<int?> id,
  Value<int?> idContrato,
  Value<DateTime?> dataFatura,
  Value<double?> valor,
});
typedef $$ContratoHistFaturamentosTableUpdateCompanionBuilder
    = ContratoHistFaturamentosCompanion Function({
  Value<int?> id,
  Value<int?> idContrato,
  Value<DateTime?> dataFatura,
  Value<double?> valor,
});

class $$ContratoHistFaturamentosTableTableManager extends RootTableManager<
    _$AppDatabase,
    $ContratoHistFaturamentosTable,
    ContratoHistFaturamento,
    $$ContratoHistFaturamentosTableFilterComposer,
    $$ContratoHistFaturamentosTableOrderingComposer,
    $$ContratoHistFaturamentosTableCreateCompanionBuilder,
    $$ContratoHistFaturamentosTableUpdateCompanionBuilder> {
  $$ContratoHistFaturamentosTableTableManager(
      _$AppDatabase db, $ContratoHistFaturamentosTable table)
      : super(TableManagerState(
          db: db,
          table: table,
          filteringComposer: $$ContratoHistFaturamentosTableFilterComposer(
              ComposerState(db, table)),
          orderingComposer: $$ContratoHistFaturamentosTableOrderingComposer(
              ComposerState(db, table)),
          updateCompanionCallback: ({
            Value<int?> id = const Value.absent(),
            Value<int?> idContrato = const Value.absent(),
            Value<DateTime?> dataFatura = const Value.absent(),
            Value<double?> valor = const Value.absent(),
          }) =>
              ContratoHistFaturamentosCompanion(
            id: id,
            idContrato: idContrato,
            dataFatura: dataFatura,
            valor: valor,
          ),
          createCompanionCallback: ({
            Value<int?> id = const Value.absent(),
            Value<int?> idContrato = const Value.absent(),
            Value<DateTime?> dataFatura = const Value.absent(),
            Value<double?> valor = const Value.absent(),
          }) =>
              ContratoHistFaturamentosCompanion.insert(
            id: id,
            idContrato: idContrato,
            dataFatura: dataFatura,
            valor: valor,
          ),
        ));
}

class $$ContratoHistFaturamentosTableFilterComposer
    extends FilterComposer<_$AppDatabase, $ContratoHistFaturamentosTable> {
  $$ContratoHistFaturamentosTableFilterComposer(super.$state);
  ColumnFilters<int> get id => $state.composableBuilder(
      column: $state.table.id,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<int> get idContrato => $state.composableBuilder(
      column: $state.table.idContrato,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<DateTime> get dataFatura => $state.composableBuilder(
      column: $state.table.dataFatura,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<double> get valor => $state.composableBuilder(
      column: $state.table.valor,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));
}

class $$ContratoHistFaturamentosTableOrderingComposer
    extends OrderingComposer<_$AppDatabase, $ContratoHistFaturamentosTable> {
  $$ContratoHistFaturamentosTableOrderingComposer(super.$state);
  ColumnOrderings<int> get id => $state.composableBuilder(
      column: $state.table.id,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<int> get idContrato => $state.composableBuilder(
      column: $state.table.idContrato,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<DateTime> get dataFatura => $state.composableBuilder(
      column: $state.table.dataFatura,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<double> get valor => $state.composableBuilder(
      column: $state.table.valor,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));
}

typedef $$ContratosTableCreateCompanionBuilder = ContratosCompanion Function({
  Value<int?> id,
  Value<int?> idSolicitacaoServico,
  Value<int?> idTipoContrato,
  Value<String?> numero,
  Value<String?> nome,
  Value<String?> descricao,
  Value<DateTime?> dataCadastro,
  Value<DateTime?> dataInicioVigencia,
  Value<DateTime?> dataFimVigencia,
  Value<String?> diaFaturamento,
  Value<double?> valor,
  Value<int?> quantidadeParcelas,
  Value<int?> intervaloEntreParcelas,
  Value<String?> classificacaoContabilConta,
  Value<String?> observacao,
});
typedef $$ContratosTableUpdateCompanionBuilder = ContratosCompanion Function({
  Value<int?> id,
  Value<int?> idSolicitacaoServico,
  Value<int?> idTipoContrato,
  Value<String?> numero,
  Value<String?> nome,
  Value<String?> descricao,
  Value<DateTime?> dataCadastro,
  Value<DateTime?> dataInicioVigencia,
  Value<DateTime?> dataFimVigencia,
  Value<String?> diaFaturamento,
  Value<double?> valor,
  Value<int?> quantidadeParcelas,
  Value<int?> intervaloEntreParcelas,
  Value<String?> classificacaoContabilConta,
  Value<String?> observacao,
});

class $$ContratosTableTableManager extends RootTableManager<
    _$AppDatabase,
    $ContratosTable,
    Contrato,
    $$ContratosTableFilterComposer,
    $$ContratosTableOrderingComposer,
    $$ContratosTableCreateCompanionBuilder,
    $$ContratosTableUpdateCompanionBuilder> {
  $$ContratosTableTableManager(_$AppDatabase db, $ContratosTable table)
      : super(TableManagerState(
          db: db,
          table: table,
          filteringComposer:
              $$ContratosTableFilterComposer(ComposerState(db, table)),
          orderingComposer:
              $$ContratosTableOrderingComposer(ComposerState(db, table)),
          updateCompanionCallback: ({
            Value<int?> id = const Value.absent(),
            Value<int?> idSolicitacaoServico = const Value.absent(),
            Value<int?> idTipoContrato = const Value.absent(),
            Value<String?> numero = const Value.absent(),
            Value<String?> nome = const Value.absent(),
            Value<String?> descricao = const Value.absent(),
            Value<DateTime?> dataCadastro = const Value.absent(),
            Value<DateTime?> dataInicioVigencia = const Value.absent(),
            Value<DateTime?> dataFimVigencia = const Value.absent(),
            Value<String?> diaFaturamento = const Value.absent(),
            Value<double?> valor = const Value.absent(),
            Value<int?> quantidadeParcelas = const Value.absent(),
            Value<int?> intervaloEntreParcelas = const Value.absent(),
            Value<String?> classificacaoContabilConta = const Value.absent(),
            Value<String?> observacao = const Value.absent(),
          }) =>
              ContratosCompanion(
            id: id,
            idSolicitacaoServico: idSolicitacaoServico,
            idTipoContrato: idTipoContrato,
            numero: numero,
            nome: nome,
            descricao: descricao,
            dataCadastro: dataCadastro,
            dataInicioVigencia: dataInicioVigencia,
            dataFimVigencia: dataFimVigencia,
            diaFaturamento: diaFaturamento,
            valor: valor,
            quantidadeParcelas: quantidadeParcelas,
            intervaloEntreParcelas: intervaloEntreParcelas,
            classificacaoContabilConta: classificacaoContabilConta,
            observacao: observacao,
          ),
          createCompanionCallback: ({
            Value<int?> id = const Value.absent(),
            Value<int?> idSolicitacaoServico = const Value.absent(),
            Value<int?> idTipoContrato = const Value.absent(),
            Value<String?> numero = const Value.absent(),
            Value<String?> nome = const Value.absent(),
            Value<String?> descricao = const Value.absent(),
            Value<DateTime?> dataCadastro = const Value.absent(),
            Value<DateTime?> dataInicioVigencia = const Value.absent(),
            Value<DateTime?> dataFimVigencia = const Value.absent(),
            Value<String?> diaFaturamento = const Value.absent(),
            Value<double?> valor = const Value.absent(),
            Value<int?> quantidadeParcelas = const Value.absent(),
            Value<int?> intervaloEntreParcelas = const Value.absent(),
            Value<String?> classificacaoContabilConta = const Value.absent(),
            Value<String?> observacao = const Value.absent(),
          }) =>
              ContratosCompanion.insert(
            id: id,
            idSolicitacaoServico: idSolicitacaoServico,
            idTipoContrato: idTipoContrato,
            numero: numero,
            nome: nome,
            descricao: descricao,
            dataCadastro: dataCadastro,
            dataInicioVigencia: dataInicioVigencia,
            dataFimVigencia: dataFimVigencia,
            diaFaturamento: diaFaturamento,
            valor: valor,
            quantidadeParcelas: quantidadeParcelas,
            intervaloEntreParcelas: intervaloEntreParcelas,
            classificacaoContabilConta: classificacaoContabilConta,
            observacao: observacao,
          ),
        ));
}

class $$ContratosTableFilterComposer
    extends FilterComposer<_$AppDatabase, $ContratosTable> {
  $$ContratosTableFilterComposer(super.$state);
  ColumnFilters<int> get id => $state.composableBuilder(
      column: $state.table.id,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<int> get idSolicitacaoServico => $state.composableBuilder(
      column: $state.table.idSolicitacaoServico,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<int> get idTipoContrato => $state.composableBuilder(
      column: $state.table.idTipoContrato,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get numero => $state.composableBuilder(
      column: $state.table.numero,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get nome => $state.composableBuilder(
      column: $state.table.nome,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get descricao => $state.composableBuilder(
      column: $state.table.descricao,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<DateTime> get dataCadastro => $state.composableBuilder(
      column: $state.table.dataCadastro,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<DateTime> get dataInicioVigencia => $state.composableBuilder(
      column: $state.table.dataInicioVigencia,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<DateTime> get dataFimVigencia => $state.composableBuilder(
      column: $state.table.dataFimVigencia,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get diaFaturamento => $state.composableBuilder(
      column: $state.table.diaFaturamento,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<double> get valor => $state.composableBuilder(
      column: $state.table.valor,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<int> get quantidadeParcelas => $state.composableBuilder(
      column: $state.table.quantidadeParcelas,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<int> get intervaloEntreParcelas => $state.composableBuilder(
      column: $state.table.intervaloEntreParcelas,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get classificacaoContabilConta =>
      $state.composableBuilder(
          column: $state.table.classificacaoContabilConta,
          builder: (column, joinBuilders) =>
              ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get observacao => $state.composableBuilder(
      column: $state.table.observacao,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));
}

class $$ContratosTableOrderingComposer
    extends OrderingComposer<_$AppDatabase, $ContratosTable> {
  $$ContratosTableOrderingComposer(super.$state);
  ColumnOrderings<int> get id => $state.composableBuilder(
      column: $state.table.id,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<int> get idSolicitacaoServico => $state.composableBuilder(
      column: $state.table.idSolicitacaoServico,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<int> get idTipoContrato => $state.composableBuilder(
      column: $state.table.idTipoContrato,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get numero => $state.composableBuilder(
      column: $state.table.numero,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get nome => $state.composableBuilder(
      column: $state.table.nome,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get descricao => $state.composableBuilder(
      column: $state.table.descricao,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<DateTime> get dataCadastro => $state.composableBuilder(
      column: $state.table.dataCadastro,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<DateTime> get dataInicioVigencia => $state.composableBuilder(
      column: $state.table.dataInicioVigencia,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<DateTime> get dataFimVigencia => $state.composableBuilder(
      column: $state.table.dataFimVigencia,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get diaFaturamento => $state.composableBuilder(
      column: $state.table.diaFaturamento,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<double> get valor => $state.composableBuilder(
      column: $state.table.valor,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<int> get quantidadeParcelas => $state.composableBuilder(
      column: $state.table.quantidadeParcelas,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<int> get intervaloEntreParcelas => $state.composableBuilder(
      column: $state.table.intervaloEntreParcelas,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get classificacaoContabilConta =>
      $state.composableBuilder(
          column: $state.table.classificacaoContabilConta,
          builder: (column, joinBuilders) =>
              ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get observacao => $state.composableBuilder(
      column: $state.table.observacao,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));
}

typedef $$SetorsTableCreateCompanionBuilder = SetorsCompanion Function({
  Value<int?> id,
  Value<String?> nome,
  Value<String?> descricao,
});
typedef $$SetorsTableUpdateCompanionBuilder = SetorsCompanion Function({
  Value<int?> id,
  Value<String?> nome,
  Value<String?> descricao,
});

class $$SetorsTableTableManager extends RootTableManager<
    _$AppDatabase,
    $SetorsTable,
    Setor,
    $$SetorsTableFilterComposer,
    $$SetorsTableOrderingComposer,
    $$SetorsTableCreateCompanionBuilder,
    $$SetorsTableUpdateCompanionBuilder> {
  $$SetorsTableTableManager(_$AppDatabase db, $SetorsTable table)
      : super(TableManagerState(
          db: db,
          table: table,
          filteringComposer:
              $$SetorsTableFilterComposer(ComposerState(db, table)),
          orderingComposer:
              $$SetorsTableOrderingComposer(ComposerState(db, table)),
          updateCompanionCallback: ({
            Value<int?> id = const Value.absent(),
            Value<String?> nome = const Value.absent(),
            Value<String?> descricao = const Value.absent(),
          }) =>
              SetorsCompanion(
            id: id,
            nome: nome,
            descricao: descricao,
          ),
          createCompanionCallback: ({
            Value<int?> id = const Value.absent(),
            Value<String?> nome = const Value.absent(),
            Value<String?> descricao = const Value.absent(),
          }) =>
              SetorsCompanion.insert(
            id: id,
            nome: nome,
            descricao: descricao,
          ),
        ));
}

class $$SetorsTableFilterComposer
    extends FilterComposer<_$AppDatabase, $SetorsTable> {
  $$SetorsTableFilterComposer(super.$state);
  ColumnFilters<int> get id => $state.composableBuilder(
      column: $state.table.id,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get nome => $state.composableBuilder(
      column: $state.table.nome,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get descricao => $state.composableBuilder(
      column: $state.table.descricao,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));
}

class $$SetorsTableOrderingComposer
    extends OrderingComposer<_$AppDatabase, $SetorsTable> {
  $$SetorsTableOrderingComposer(super.$state);
  ColumnOrderings<int> get id => $state.composableBuilder(
      column: $state.table.id,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get nome => $state.composableBuilder(
      column: $state.table.nome,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get descricao => $state.composableBuilder(
      column: $state.table.descricao,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));
}

typedef $$TipoContratosTableCreateCompanionBuilder = TipoContratosCompanion
    Function({
  Value<int?> id,
  Value<String?> nome,
  Value<String?> descricao,
});
typedef $$TipoContratosTableUpdateCompanionBuilder = TipoContratosCompanion
    Function({
  Value<int?> id,
  Value<String?> nome,
  Value<String?> descricao,
});

class $$TipoContratosTableTableManager extends RootTableManager<
    _$AppDatabase,
    $TipoContratosTable,
    TipoContrato,
    $$TipoContratosTableFilterComposer,
    $$TipoContratosTableOrderingComposer,
    $$TipoContratosTableCreateCompanionBuilder,
    $$TipoContratosTableUpdateCompanionBuilder> {
  $$TipoContratosTableTableManager(_$AppDatabase db, $TipoContratosTable table)
      : super(TableManagerState(
          db: db,
          table: table,
          filteringComposer:
              $$TipoContratosTableFilterComposer(ComposerState(db, table)),
          orderingComposer:
              $$TipoContratosTableOrderingComposer(ComposerState(db, table)),
          updateCompanionCallback: ({
            Value<int?> id = const Value.absent(),
            Value<String?> nome = const Value.absent(),
            Value<String?> descricao = const Value.absent(),
          }) =>
              TipoContratosCompanion(
            id: id,
            nome: nome,
            descricao: descricao,
          ),
          createCompanionCallback: ({
            Value<int?> id = const Value.absent(),
            Value<String?> nome = const Value.absent(),
            Value<String?> descricao = const Value.absent(),
          }) =>
              TipoContratosCompanion.insert(
            id: id,
            nome: nome,
            descricao: descricao,
          ),
        ));
}

class $$TipoContratosTableFilterComposer
    extends FilterComposer<_$AppDatabase, $TipoContratosTable> {
  $$TipoContratosTableFilterComposer(super.$state);
  ColumnFilters<int> get id => $state.composableBuilder(
      column: $state.table.id,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get nome => $state.composableBuilder(
      column: $state.table.nome,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get descricao => $state.composableBuilder(
      column: $state.table.descricao,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));
}

class $$TipoContratosTableOrderingComposer
    extends OrderingComposer<_$AppDatabase, $TipoContratosTable> {
  $$TipoContratosTableOrderingComposer(super.$state);
  ColumnOrderings<int> get id => $state.composableBuilder(
      column: $state.table.id,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get nome => $state.composableBuilder(
      column: $state.table.nome,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get descricao => $state.composableBuilder(
      column: $state.table.descricao,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));
}

typedef $$ContratoTipoServicosTableCreateCompanionBuilder
    = ContratoTipoServicosCompanion Function({
  Value<int?> id,
  Value<String?> nome,
  Value<String?> descricao,
});
typedef $$ContratoTipoServicosTableUpdateCompanionBuilder
    = ContratoTipoServicosCompanion Function({
  Value<int?> id,
  Value<String?> nome,
  Value<String?> descricao,
});

class $$ContratoTipoServicosTableTableManager extends RootTableManager<
    _$AppDatabase,
    $ContratoTipoServicosTable,
    ContratoTipoServico,
    $$ContratoTipoServicosTableFilterComposer,
    $$ContratoTipoServicosTableOrderingComposer,
    $$ContratoTipoServicosTableCreateCompanionBuilder,
    $$ContratoTipoServicosTableUpdateCompanionBuilder> {
  $$ContratoTipoServicosTableTableManager(
      _$AppDatabase db, $ContratoTipoServicosTable table)
      : super(TableManagerState(
          db: db,
          table: table,
          filteringComposer: $$ContratoTipoServicosTableFilterComposer(
              ComposerState(db, table)),
          orderingComposer: $$ContratoTipoServicosTableOrderingComposer(
              ComposerState(db, table)),
          updateCompanionCallback: ({
            Value<int?> id = const Value.absent(),
            Value<String?> nome = const Value.absent(),
            Value<String?> descricao = const Value.absent(),
          }) =>
              ContratoTipoServicosCompanion(
            id: id,
            nome: nome,
            descricao: descricao,
          ),
          createCompanionCallback: ({
            Value<int?> id = const Value.absent(),
            Value<String?> nome = const Value.absent(),
            Value<String?> descricao = const Value.absent(),
          }) =>
              ContratoTipoServicosCompanion.insert(
            id: id,
            nome: nome,
            descricao: descricao,
          ),
        ));
}

class $$ContratoTipoServicosTableFilterComposer
    extends FilterComposer<_$AppDatabase, $ContratoTipoServicosTable> {
  $$ContratoTipoServicosTableFilterComposer(super.$state);
  ColumnFilters<int> get id => $state.composableBuilder(
      column: $state.table.id,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get nome => $state.composableBuilder(
      column: $state.table.nome,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get descricao => $state.composableBuilder(
      column: $state.table.descricao,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));
}

class $$ContratoTipoServicosTableOrderingComposer
    extends OrderingComposer<_$AppDatabase, $ContratoTipoServicosTable> {
  $$ContratoTipoServicosTableOrderingComposer(super.$state);
  ColumnOrderings<int> get id => $state.composableBuilder(
      column: $state.table.id,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get nome => $state.composableBuilder(
      column: $state.table.nome,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get descricao => $state.composableBuilder(
      column: $state.table.descricao,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));
}

typedef $$ContratoSolicitacaoServicosTableCreateCompanionBuilder
    = ContratoSolicitacaoServicosCompanion Function({
  Value<int?> id,
  Value<int?> idContratoTipoServico,
  Value<int?> idSetor,
  Value<int?> idColaborador,
  Value<int?> idCliente,
  Value<int?> idFornecedor,
  Value<DateTime?> dataSolicitacao,
  Value<DateTime?> dataDesejadaInicio,
  Value<String?> urgente,
  Value<String?> statusSolicitacao,
  Value<String?> descricao,
});
typedef $$ContratoSolicitacaoServicosTableUpdateCompanionBuilder
    = ContratoSolicitacaoServicosCompanion Function({
  Value<int?> id,
  Value<int?> idContratoTipoServico,
  Value<int?> idSetor,
  Value<int?> idColaborador,
  Value<int?> idCliente,
  Value<int?> idFornecedor,
  Value<DateTime?> dataSolicitacao,
  Value<DateTime?> dataDesejadaInicio,
  Value<String?> urgente,
  Value<String?> statusSolicitacao,
  Value<String?> descricao,
});

class $$ContratoSolicitacaoServicosTableTableManager extends RootTableManager<
    _$AppDatabase,
    $ContratoSolicitacaoServicosTable,
    ContratoSolicitacaoServico,
    $$ContratoSolicitacaoServicosTableFilterComposer,
    $$ContratoSolicitacaoServicosTableOrderingComposer,
    $$ContratoSolicitacaoServicosTableCreateCompanionBuilder,
    $$ContratoSolicitacaoServicosTableUpdateCompanionBuilder> {
  $$ContratoSolicitacaoServicosTableTableManager(
      _$AppDatabase db, $ContratoSolicitacaoServicosTable table)
      : super(TableManagerState(
          db: db,
          table: table,
          filteringComposer: $$ContratoSolicitacaoServicosTableFilterComposer(
              ComposerState(db, table)),
          orderingComposer: $$ContratoSolicitacaoServicosTableOrderingComposer(
              ComposerState(db, table)),
          updateCompanionCallback: ({
            Value<int?> id = const Value.absent(),
            Value<int?> idContratoTipoServico = const Value.absent(),
            Value<int?> idSetor = const Value.absent(),
            Value<int?> idColaborador = const Value.absent(),
            Value<int?> idCliente = const Value.absent(),
            Value<int?> idFornecedor = const Value.absent(),
            Value<DateTime?> dataSolicitacao = const Value.absent(),
            Value<DateTime?> dataDesejadaInicio = const Value.absent(),
            Value<String?> urgente = const Value.absent(),
            Value<String?> statusSolicitacao = const Value.absent(),
            Value<String?> descricao = const Value.absent(),
          }) =>
              ContratoSolicitacaoServicosCompanion(
            id: id,
            idContratoTipoServico: idContratoTipoServico,
            idSetor: idSetor,
            idColaborador: idColaborador,
            idCliente: idCliente,
            idFornecedor: idFornecedor,
            dataSolicitacao: dataSolicitacao,
            dataDesejadaInicio: dataDesejadaInicio,
            urgente: urgente,
            statusSolicitacao: statusSolicitacao,
            descricao: descricao,
          ),
          createCompanionCallback: ({
            Value<int?> id = const Value.absent(),
            Value<int?> idContratoTipoServico = const Value.absent(),
            Value<int?> idSetor = const Value.absent(),
            Value<int?> idColaborador = const Value.absent(),
            Value<int?> idCliente = const Value.absent(),
            Value<int?> idFornecedor = const Value.absent(),
            Value<DateTime?> dataSolicitacao = const Value.absent(),
            Value<DateTime?> dataDesejadaInicio = const Value.absent(),
            Value<String?> urgente = const Value.absent(),
            Value<String?> statusSolicitacao = const Value.absent(),
            Value<String?> descricao = const Value.absent(),
          }) =>
              ContratoSolicitacaoServicosCompanion.insert(
            id: id,
            idContratoTipoServico: idContratoTipoServico,
            idSetor: idSetor,
            idColaborador: idColaborador,
            idCliente: idCliente,
            idFornecedor: idFornecedor,
            dataSolicitacao: dataSolicitacao,
            dataDesejadaInicio: dataDesejadaInicio,
            urgente: urgente,
            statusSolicitacao: statusSolicitacao,
            descricao: descricao,
          ),
        ));
}

class $$ContratoSolicitacaoServicosTableFilterComposer
    extends FilterComposer<_$AppDatabase, $ContratoSolicitacaoServicosTable> {
  $$ContratoSolicitacaoServicosTableFilterComposer(super.$state);
  ColumnFilters<int> get id => $state.composableBuilder(
      column: $state.table.id,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<int> get idContratoTipoServico => $state.composableBuilder(
      column: $state.table.idContratoTipoServico,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<int> get idSetor => $state.composableBuilder(
      column: $state.table.idSetor,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<int> get idColaborador => $state.composableBuilder(
      column: $state.table.idColaborador,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<int> get idCliente => $state.composableBuilder(
      column: $state.table.idCliente,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<int> get idFornecedor => $state.composableBuilder(
      column: $state.table.idFornecedor,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<DateTime> get dataSolicitacao => $state.composableBuilder(
      column: $state.table.dataSolicitacao,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<DateTime> get dataDesejadaInicio => $state.composableBuilder(
      column: $state.table.dataDesejadaInicio,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get urgente => $state.composableBuilder(
      column: $state.table.urgente,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get statusSolicitacao => $state.composableBuilder(
      column: $state.table.statusSolicitacao,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get descricao => $state.composableBuilder(
      column: $state.table.descricao,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));
}

class $$ContratoSolicitacaoServicosTableOrderingComposer
    extends OrderingComposer<_$AppDatabase, $ContratoSolicitacaoServicosTable> {
  $$ContratoSolicitacaoServicosTableOrderingComposer(super.$state);
  ColumnOrderings<int> get id => $state.composableBuilder(
      column: $state.table.id,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<int> get idContratoTipoServico => $state.composableBuilder(
      column: $state.table.idContratoTipoServico,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<int> get idSetor => $state.composableBuilder(
      column: $state.table.idSetor,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<int> get idColaborador => $state.composableBuilder(
      column: $state.table.idColaborador,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<int> get idCliente => $state.composableBuilder(
      column: $state.table.idCliente,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<int> get idFornecedor => $state.composableBuilder(
      column: $state.table.idFornecedor,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<DateTime> get dataSolicitacao => $state.composableBuilder(
      column: $state.table.dataSolicitacao,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<DateTime> get dataDesejadaInicio => $state.composableBuilder(
      column: $state.table.dataDesejadaInicio,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get urgente => $state.composableBuilder(
      column: $state.table.urgente,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get statusSolicitacao => $state.composableBuilder(
      column: $state.table.statusSolicitacao,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get descricao => $state.composableBuilder(
      column: $state.table.descricao,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));
}

typedef $$ContratoTemplatesTableCreateCompanionBuilder
    = ContratoTemplatesCompanion Function({
  Value<int?> id,
  Value<String?> nome,
  Value<String?> descricao,
});
typedef $$ContratoTemplatesTableUpdateCompanionBuilder
    = ContratoTemplatesCompanion Function({
  Value<int?> id,
  Value<String?> nome,
  Value<String?> descricao,
});

class $$ContratoTemplatesTableTableManager extends RootTableManager<
    _$AppDatabase,
    $ContratoTemplatesTable,
    ContratoTemplate,
    $$ContratoTemplatesTableFilterComposer,
    $$ContratoTemplatesTableOrderingComposer,
    $$ContratoTemplatesTableCreateCompanionBuilder,
    $$ContratoTemplatesTableUpdateCompanionBuilder> {
  $$ContratoTemplatesTableTableManager(
      _$AppDatabase db, $ContratoTemplatesTable table)
      : super(TableManagerState(
          db: db,
          table: table,
          filteringComposer:
              $$ContratoTemplatesTableFilterComposer(ComposerState(db, table)),
          orderingComposer: $$ContratoTemplatesTableOrderingComposer(
              ComposerState(db, table)),
          updateCompanionCallback: ({
            Value<int?> id = const Value.absent(),
            Value<String?> nome = const Value.absent(),
            Value<String?> descricao = const Value.absent(),
          }) =>
              ContratoTemplatesCompanion(
            id: id,
            nome: nome,
            descricao: descricao,
          ),
          createCompanionCallback: ({
            Value<int?> id = const Value.absent(),
            Value<String?> nome = const Value.absent(),
            Value<String?> descricao = const Value.absent(),
          }) =>
              ContratoTemplatesCompanion.insert(
            id: id,
            nome: nome,
            descricao: descricao,
          ),
        ));
}

class $$ContratoTemplatesTableFilterComposer
    extends FilterComposer<_$AppDatabase, $ContratoTemplatesTable> {
  $$ContratoTemplatesTableFilterComposer(super.$state);
  ColumnFilters<int> get id => $state.composableBuilder(
      column: $state.table.id,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get nome => $state.composableBuilder(
      column: $state.table.nome,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get descricao => $state.composableBuilder(
      column: $state.table.descricao,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));
}

class $$ContratoTemplatesTableOrderingComposer
    extends OrderingComposer<_$AppDatabase, $ContratoTemplatesTable> {
  $$ContratoTemplatesTableOrderingComposer(super.$state);
  ColumnOrderings<int> get id => $state.composableBuilder(
      column: $state.table.id,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get nome => $state.composableBuilder(
      column: $state.table.nome,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get descricao => $state.composableBuilder(
      column: $state.table.descricao,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));
}

typedef $$ViewControleAcessosTableCreateCompanionBuilder
    = ViewControleAcessosCompanion Function({
  Value<int?> id,
  Value<int?> idPessoa,
  Value<String?> pessoaNome,
  Value<int?> idColaborador,
  Value<int?> idUsuario,
  Value<String?> administrador,
  Value<int?> idPapel,
  Value<String?> papelNome,
  Value<String?> papelDescricao,
  Value<int?> idFuncao,
  Value<String?> funcaoNome,
  Value<String?> funcaoDescricao,
  Value<int?> idPapelFuncao,
  Value<String?> habilitado,
  Value<String?> podeInserir,
  Value<String?> podeAlterar,
  Value<String?> podeExcluir,
});
typedef $$ViewControleAcessosTableUpdateCompanionBuilder
    = ViewControleAcessosCompanion Function({
  Value<int?> id,
  Value<int?> idPessoa,
  Value<String?> pessoaNome,
  Value<int?> idColaborador,
  Value<int?> idUsuario,
  Value<String?> administrador,
  Value<int?> idPapel,
  Value<String?> papelNome,
  Value<String?> papelDescricao,
  Value<int?> idFuncao,
  Value<String?> funcaoNome,
  Value<String?> funcaoDescricao,
  Value<int?> idPapelFuncao,
  Value<String?> habilitado,
  Value<String?> podeInserir,
  Value<String?> podeAlterar,
  Value<String?> podeExcluir,
});

class $$ViewControleAcessosTableTableManager extends RootTableManager<
    _$AppDatabase,
    $ViewControleAcessosTable,
    ViewControleAcesso,
    $$ViewControleAcessosTableFilterComposer,
    $$ViewControleAcessosTableOrderingComposer,
    $$ViewControleAcessosTableCreateCompanionBuilder,
    $$ViewControleAcessosTableUpdateCompanionBuilder> {
  $$ViewControleAcessosTableTableManager(
      _$AppDatabase db, $ViewControleAcessosTable table)
      : super(TableManagerState(
          db: db,
          table: table,
          filteringComposer: $$ViewControleAcessosTableFilterComposer(
              ComposerState(db, table)),
          orderingComposer: $$ViewControleAcessosTableOrderingComposer(
              ComposerState(db, table)),
          updateCompanionCallback: ({
            Value<int?> id = const Value.absent(),
            Value<int?> idPessoa = const Value.absent(),
            Value<String?> pessoaNome = const Value.absent(),
            Value<int?> idColaborador = const Value.absent(),
            Value<int?> idUsuario = const Value.absent(),
            Value<String?> administrador = const Value.absent(),
            Value<int?> idPapel = const Value.absent(),
            Value<String?> papelNome = const Value.absent(),
            Value<String?> papelDescricao = const Value.absent(),
            Value<int?> idFuncao = const Value.absent(),
            Value<String?> funcaoNome = const Value.absent(),
            Value<String?> funcaoDescricao = const Value.absent(),
            Value<int?> idPapelFuncao = const Value.absent(),
            Value<String?> habilitado = const Value.absent(),
            Value<String?> podeInserir = const Value.absent(),
            Value<String?> podeAlterar = const Value.absent(),
            Value<String?> podeExcluir = const Value.absent(),
          }) =>
              ViewControleAcessosCompanion(
            id: id,
            idPessoa: idPessoa,
            pessoaNome: pessoaNome,
            idColaborador: idColaborador,
            idUsuario: idUsuario,
            administrador: administrador,
            idPapel: idPapel,
            papelNome: papelNome,
            papelDescricao: papelDescricao,
            idFuncao: idFuncao,
            funcaoNome: funcaoNome,
            funcaoDescricao: funcaoDescricao,
            idPapelFuncao: idPapelFuncao,
            habilitado: habilitado,
            podeInserir: podeInserir,
            podeAlterar: podeAlterar,
            podeExcluir: podeExcluir,
          ),
          createCompanionCallback: ({
            Value<int?> id = const Value.absent(),
            Value<int?> idPessoa = const Value.absent(),
            Value<String?> pessoaNome = const Value.absent(),
            Value<int?> idColaborador = const Value.absent(),
            Value<int?> idUsuario = const Value.absent(),
            Value<String?> administrador = const Value.absent(),
            Value<int?> idPapel = const Value.absent(),
            Value<String?> papelNome = const Value.absent(),
            Value<String?> papelDescricao = const Value.absent(),
            Value<int?> idFuncao = const Value.absent(),
            Value<String?> funcaoNome = const Value.absent(),
            Value<String?> funcaoDescricao = const Value.absent(),
            Value<int?> idPapelFuncao = const Value.absent(),
            Value<String?> habilitado = const Value.absent(),
            Value<String?> podeInserir = const Value.absent(),
            Value<String?> podeAlterar = const Value.absent(),
            Value<String?> podeExcluir = const Value.absent(),
          }) =>
              ViewControleAcessosCompanion.insert(
            id: id,
            idPessoa: idPessoa,
            pessoaNome: pessoaNome,
            idColaborador: idColaborador,
            idUsuario: idUsuario,
            administrador: administrador,
            idPapel: idPapel,
            papelNome: papelNome,
            papelDescricao: papelDescricao,
            idFuncao: idFuncao,
            funcaoNome: funcaoNome,
            funcaoDescricao: funcaoDescricao,
            idPapelFuncao: idPapelFuncao,
            habilitado: habilitado,
            podeInserir: podeInserir,
            podeAlterar: podeAlterar,
            podeExcluir: podeExcluir,
          ),
        ));
}

class $$ViewControleAcessosTableFilterComposer
    extends FilterComposer<_$AppDatabase, $ViewControleAcessosTable> {
  $$ViewControleAcessosTableFilterComposer(super.$state);
  ColumnFilters<int> get id => $state.composableBuilder(
      column: $state.table.id,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<int> get idPessoa => $state.composableBuilder(
      column: $state.table.idPessoa,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get pessoaNome => $state.composableBuilder(
      column: $state.table.pessoaNome,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<int> get idColaborador => $state.composableBuilder(
      column: $state.table.idColaborador,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<int> get idUsuario => $state.composableBuilder(
      column: $state.table.idUsuario,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get administrador => $state.composableBuilder(
      column: $state.table.administrador,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<int> get idPapel => $state.composableBuilder(
      column: $state.table.idPapel,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get papelNome => $state.composableBuilder(
      column: $state.table.papelNome,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get papelDescricao => $state.composableBuilder(
      column: $state.table.papelDescricao,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<int> get idFuncao => $state.composableBuilder(
      column: $state.table.idFuncao,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get funcaoNome => $state.composableBuilder(
      column: $state.table.funcaoNome,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get funcaoDescricao => $state.composableBuilder(
      column: $state.table.funcaoDescricao,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<int> get idPapelFuncao => $state.composableBuilder(
      column: $state.table.idPapelFuncao,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get habilitado => $state.composableBuilder(
      column: $state.table.habilitado,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get podeInserir => $state.composableBuilder(
      column: $state.table.podeInserir,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get podeAlterar => $state.composableBuilder(
      column: $state.table.podeAlterar,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get podeExcluir => $state.composableBuilder(
      column: $state.table.podeExcluir,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));
}

class $$ViewControleAcessosTableOrderingComposer
    extends OrderingComposer<_$AppDatabase, $ViewControleAcessosTable> {
  $$ViewControleAcessosTableOrderingComposer(super.$state);
  ColumnOrderings<int> get id => $state.composableBuilder(
      column: $state.table.id,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<int> get idPessoa => $state.composableBuilder(
      column: $state.table.idPessoa,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get pessoaNome => $state.composableBuilder(
      column: $state.table.pessoaNome,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<int> get idColaborador => $state.composableBuilder(
      column: $state.table.idColaborador,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<int> get idUsuario => $state.composableBuilder(
      column: $state.table.idUsuario,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get administrador => $state.composableBuilder(
      column: $state.table.administrador,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<int> get idPapel => $state.composableBuilder(
      column: $state.table.idPapel,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get papelNome => $state.composableBuilder(
      column: $state.table.papelNome,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get papelDescricao => $state.composableBuilder(
      column: $state.table.papelDescricao,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<int> get idFuncao => $state.composableBuilder(
      column: $state.table.idFuncao,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get funcaoNome => $state.composableBuilder(
      column: $state.table.funcaoNome,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get funcaoDescricao => $state.composableBuilder(
      column: $state.table.funcaoDescricao,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<int> get idPapelFuncao => $state.composableBuilder(
      column: $state.table.idPapelFuncao,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get habilitado => $state.composableBuilder(
      column: $state.table.habilitado,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get podeInserir => $state.composableBuilder(
      column: $state.table.podeInserir,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get podeAlterar => $state.composableBuilder(
      column: $state.table.podeAlterar,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get podeExcluir => $state.composableBuilder(
      column: $state.table.podeExcluir,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));
}

typedef $$ViewPessoaUsuariosTableCreateCompanionBuilder
    = ViewPessoaUsuariosCompanion Function({
  Value<int?> id,
  Value<int?> idPessoa,
  Value<String?> pessoaNome,
  Value<String?> tipo,
  Value<String?> email,
  Value<int?> idColaborador,
  Value<int?> idUsuario,
  Value<String?> login,
  Value<String?> senha,
  Value<DateTime?> dataCadastro,
  Value<String?> administrador,
});
typedef $$ViewPessoaUsuariosTableUpdateCompanionBuilder
    = ViewPessoaUsuariosCompanion Function({
  Value<int?> id,
  Value<int?> idPessoa,
  Value<String?> pessoaNome,
  Value<String?> tipo,
  Value<String?> email,
  Value<int?> idColaborador,
  Value<int?> idUsuario,
  Value<String?> login,
  Value<String?> senha,
  Value<DateTime?> dataCadastro,
  Value<String?> administrador,
});

class $$ViewPessoaUsuariosTableTableManager extends RootTableManager<
    _$AppDatabase,
    $ViewPessoaUsuariosTable,
    ViewPessoaUsuario,
    $$ViewPessoaUsuariosTableFilterComposer,
    $$ViewPessoaUsuariosTableOrderingComposer,
    $$ViewPessoaUsuariosTableCreateCompanionBuilder,
    $$ViewPessoaUsuariosTableUpdateCompanionBuilder> {
  $$ViewPessoaUsuariosTableTableManager(
      _$AppDatabase db, $ViewPessoaUsuariosTable table)
      : super(TableManagerState(
          db: db,
          table: table,
          filteringComposer:
              $$ViewPessoaUsuariosTableFilterComposer(ComposerState(db, table)),
          orderingComposer: $$ViewPessoaUsuariosTableOrderingComposer(
              ComposerState(db, table)),
          updateCompanionCallback: ({
            Value<int?> id = const Value.absent(),
            Value<int?> idPessoa = const Value.absent(),
            Value<String?> pessoaNome = const Value.absent(),
            Value<String?> tipo = const Value.absent(),
            Value<String?> email = const Value.absent(),
            Value<int?> idColaborador = const Value.absent(),
            Value<int?> idUsuario = const Value.absent(),
            Value<String?> login = const Value.absent(),
            Value<String?> senha = const Value.absent(),
            Value<DateTime?> dataCadastro = const Value.absent(),
            Value<String?> administrador = const Value.absent(),
          }) =>
              ViewPessoaUsuariosCompanion(
            id: id,
            idPessoa: idPessoa,
            pessoaNome: pessoaNome,
            tipo: tipo,
            email: email,
            idColaborador: idColaborador,
            idUsuario: idUsuario,
            login: login,
            senha: senha,
            dataCadastro: dataCadastro,
            administrador: administrador,
          ),
          createCompanionCallback: ({
            Value<int?> id = const Value.absent(),
            Value<int?> idPessoa = const Value.absent(),
            Value<String?> pessoaNome = const Value.absent(),
            Value<String?> tipo = const Value.absent(),
            Value<String?> email = const Value.absent(),
            Value<int?> idColaborador = const Value.absent(),
            Value<int?> idUsuario = const Value.absent(),
            Value<String?> login = const Value.absent(),
            Value<String?> senha = const Value.absent(),
            Value<DateTime?> dataCadastro = const Value.absent(),
            Value<String?> administrador = const Value.absent(),
          }) =>
              ViewPessoaUsuariosCompanion.insert(
            id: id,
            idPessoa: idPessoa,
            pessoaNome: pessoaNome,
            tipo: tipo,
            email: email,
            idColaborador: idColaborador,
            idUsuario: idUsuario,
            login: login,
            senha: senha,
            dataCadastro: dataCadastro,
            administrador: administrador,
          ),
        ));
}

class $$ViewPessoaUsuariosTableFilterComposer
    extends FilterComposer<_$AppDatabase, $ViewPessoaUsuariosTable> {
  $$ViewPessoaUsuariosTableFilterComposer(super.$state);
  ColumnFilters<int> get id => $state.composableBuilder(
      column: $state.table.id,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<int> get idPessoa => $state.composableBuilder(
      column: $state.table.idPessoa,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get pessoaNome => $state.composableBuilder(
      column: $state.table.pessoaNome,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get tipo => $state.composableBuilder(
      column: $state.table.tipo,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get email => $state.composableBuilder(
      column: $state.table.email,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<int> get idColaborador => $state.composableBuilder(
      column: $state.table.idColaborador,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<int> get idUsuario => $state.composableBuilder(
      column: $state.table.idUsuario,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get login => $state.composableBuilder(
      column: $state.table.login,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get senha => $state.composableBuilder(
      column: $state.table.senha,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<DateTime> get dataCadastro => $state.composableBuilder(
      column: $state.table.dataCadastro,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get administrador => $state.composableBuilder(
      column: $state.table.administrador,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));
}

class $$ViewPessoaUsuariosTableOrderingComposer
    extends OrderingComposer<_$AppDatabase, $ViewPessoaUsuariosTable> {
  $$ViewPessoaUsuariosTableOrderingComposer(super.$state);
  ColumnOrderings<int> get id => $state.composableBuilder(
      column: $state.table.id,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<int> get idPessoa => $state.composableBuilder(
      column: $state.table.idPessoa,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get pessoaNome => $state.composableBuilder(
      column: $state.table.pessoaNome,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get tipo => $state.composableBuilder(
      column: $state.table.tipo,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get email => $state.composableBuilder(
      column: $state.table.email,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<int> get idColaborador => $state.composableBuilder(
      column: $state.table.idColaborador,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<int> get idUsuario => $state.composableBuilder(
      column: $state.table.idUsuario,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get login => $state.composableBuilder(
      column: $state.table.login,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get senha => $state.composableBuilder(
      column: $state.table.senha,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<DateTime> get dataCadastro => $state.composableBuilder(
      column: $state.table.dataCadastro,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get administrador => $state.composableBuilder(
      column: $state.table.administrador,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));
}

typedef $$ViewPessoaClientesTableCreateCompanionBuilder
    = ViewPessoaClientesCompanion Function({
  Value<int?> id,
  Value<String?> nome,
  Value<String?> tipo,
  Value<String?> email,
  Value<String?> site,
  Value<String?> cpfCnpj,
  Value<String?> rgIe,
  Value<DateTime?> desde,
  Value<double?> taxaDesconto,
  Value<double?> limiteCredito,
  Value<DateTime?> dataCadastro,
  Value<String?> observacao,
  Value<int?> idPessoa,
});
typedef $$ViewPessoaClientesTableUpdateCompanionBuilder
    = ViewPessoaClientesCompanion Function({
  Value<int?> id,
  Value<String?> nome,
  Value<String?> tipo,
  Value<String?> email,
  Value<String?> site,
  Value<String?> cpfCnpj,
  Value<String?> rgIe,
  Value<DateTime?> desde,
  Value<double?> taxaDesconto,
  Value<double?> limiteCredito,
  Value<DateTime?> dataCadastro,
  Value<String?> observacao,
  Value<int?> idPessoa,
});

class $$ViewPessoaClientesTableTableManager extends RootTableManager<
    _$AppDatabase,
    $ViewPessoaClientesTable,
    ViewPessoaCliente,
    $$ViewPessoaClientesTableFilterComposer,
    $$ViewPessoaClientesTableOrderingComposer,
    $$ViewPessoaClientesTableCreateCompanionBuilder,
    $$ViewPessoaClientesTableUpdateCompanionBuilder> {
  $$ViewPessoaClientesTableTableManager(
      _$AppDatabase db, $ViewPessoaClientesTable table)
      : super(TableManagerState(
          db: db,
          table: table,
          filteringComposer:
              $$ViewPessoaClientesTableFilterComposer(ComposerState(db, table)),
          orderingComposer: $$ViewPessoaClientesTableOrderingComposer(
              ComposerState(db, table)),
          updateCompanionCallback: ({
            Value<int?> id = const Value.absent(),
            Value<String?> nome = const Value.absent(),
            Value<String?> tipo = const Value.absent(),
            Value<String?> email = const Value.absent(),
            Value<String?> site = const Value.absent(),
            Value<String?> cpfCnpj = const Value.absent(),
            Value<String?> rgIe = const Value.absent(),
            Value<DateTime?> desde = const Value.absent(),
            Value<double?> taxaDesconto = const Value.absent(),
            Value<double?> limiteCredito = const Value.absent(),
            Value<DateTime?> dataCadastro = const Value.absent(),
            Value<String?> observacao = const Value.absent(),
            Value<int?> idPessoa = const Value.absent(),
          }) =>
              ViewPessoaClientesCompanion(
            id: id,
            nome: nome,
            tipo: tipo,
            email: email,
            site: site,
            cpfCnpj: cpfCnpj,
            rgIe: rgIe,
            desde: desde,
            taxaDesconto: taxaDesconto,
            limiteCredito: limiteCredito,
            dataCadastro: dataCadastro,
            observacao: observacao,
            idPessoa: idPessoa,
          ),
          createCompanionCallback: ({
            Value<int?> id = const Value.absent(),
            Value<String?> nome = const Value.absent(),
            Value<String?> tipo = const Value.absent(),
            Value<String?> email = const Value.absent(),
            Value<String?> site = const Value.absent(),
            Value<String?> cpfCnpj = const Value.absent(),
            Value<String?> rgIe = const Value.absent(),
            Value<DateTime?> desde = const Value.absent(),
            Value<double?> taxaDesconto = const Value.absent(),
            Value<double?> limiteCredito = const Value.absent(),
            Value<DateTime?> dataCadastro = const Value.absent(),
            Value<String?> observacao = const Value.absent(),
            Value<int?> idPessoa = const Value.absent(),
          }) =>
              ViewPessoaClientesCompanion.insert(
            id: id,
            nome: nome,
            tipo: tipo,
            email: email,
            site: site,
            cpfCnpj: cpfCnpj,
            rgIe: rgIe,
            desde: desde,
            taxaDesconto: taxaDesconto,
            limiteCredito: limiteCredito,
            dataCadastro: dataCadastro,
            observacao: observacao,
            idPessoa: idPessoa,
          ),
        ));
}

class $$ViewPessoaClientesTableFilterComposer
    extends FilterComposer<_$AppDatabase, $ViewPessoaClientesTable> {
  $$ViewPessoaClientesTableFilterComposer(super.$state);
  ColumnFilters<int> get id => $state.composableBuilder(
      column: $state.table.id,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get nome => $state.composableBuilder(
      column: $state.table.nome,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get tipo => $state.composableBuilder(
      column: $state.table.tipo,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get email => $state.composableBuilder(
      column: $state.table.email,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get site => $state.composableBuilder(
      column: $state.table.site,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get cpfCnpj => $state.composableBuilder(
      column: $state.table.cpfCnpj,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get rgIe => $state.composableBuilder(
      column: $state.table.rgIe,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<DateTime> get desde => $state.composableBuilder(
      column: $state.table.desde,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<double> get taxaDesconto => $state.composableBuilder(
      column: $state.table.taxaDesconto,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<double> get limiteCredito => $state.composableBuilder(
      column: $state.table.limiteCredito,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<DateTime> get dataCadastro => $state.composableBuilder(
      column: $state.table.dataCadastro,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get observacao => $state.composableBuilder(
      column: $state.table.observacao,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<int> get idPessoa => $state.composableBuilder(
      column: $state.table.idPessoa,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));
}

class $$ViewPessoaClientesTableOrderingComposer
    extends OrderingComposer<_$AppDatabase, $ViewPessoaClientesTable> {
  $$ViewPessoaClientesTableOrderingComposer(super.$state);
  ColumnOrderings<int> get id => $state.composableBuilder(
      column: $state.table.id,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get nome => $state.composableBuilder(
      column: $state.table.nome,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get tipo => $state.composableBuilder(
      column: $state.table.tipo,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get email => $state.composableBuilder(
      column: $state.table.email,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get site => $state.composableBuilder(
      column: $state.table.site,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get cpfCnpj => $state.composableBuilder(
      column: $state.table.cpfCnpj,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get rgIe => $state.composableBuilder(
      column: $state.table.rgIe,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<DateTime> get desde => $state.composableBuilder(
      column: $state.table.desde,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<double> get taxaDesconto => $state.composableBuilder(
      column: $state.table.taxaDesconto,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<double> get limiteCredito => $state.composableBuilder(
      column: $state.table.limiteCredito,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<DateTime> get dataCadastro => $state.composableBuilder(
      column: $state.table.dataCadastro,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get observacao => $state.composableBuilder(
      column: $state.table.observacao,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<int> get idPessoa => $state.composableBuilder(
      column: $state.table.idPessoa,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));
}

typedef $$ViewPessoaFornecedorsTableCreateCompanionBuilder
    = ViewPessoaFornecedorsCompanion Function({
  Value<int?> id,
  Value<String?> nome,
  Value<String?> tipo,
  Value<String?> email,
  Value<String?> site,
  Value<String?> cpfCnpj,
  Value<String?> rgIe,
  Value<DateTime?> desde,
  Value<DateTime?> dataCadastro,
  Value<String?> observacao,
  Value<int?> idPessoa,
});
typedef $$ViewPessoaFornecedorsTableUpdateCompanionBuilder
    = ViewPessoaFornecedorsCompanion Function({
  Value<int?> id,
  Value<String?> nome,
  Value<String?> tipo,
  Value<String?> email,
  Value<String?> site,
  Value<String?> cpfCnpj,
  Value<String?> rgIe,
  Value<DateTime?> desde,
  Value<DateTime?> dataCadastro,
  Value<String?> observacao,
  Value<int?> idPessoa,
});

class $$ViewPessoaFornecedorsTableTableManager extends RootTableManager<
    _$AppDatabase,
    $ViewPessoaFornecedorsTable,
    ViewPessoaFornecedor,
    $$ViewPessoaFornecedorsTableFilterComposer,
    $$ViewPessoaFornecedorsTableOrderingComposer,
    $$ViewPessoaFornecedorsTableCreateCompanionBuilder,
    $$ViewPessoaFornecedorsTableUpdateCompanionBuilder> {
  $$ViewPessoaFornecedorsTableTableManager(
      _$AppDatabase db, $ViewPessoaFornecedorsTable table)
      : super(TableManagerState(
          db: db,
          table: table,
          filteringComposer: $$ViewPessoaFornecedorsTableFilterComposer(
              ComposerState(db, table)),
          orderingComposer: $$ViewPessoaFornecedorsTableOrderingComposer(
              ComposerState(db, table)),
          updateCompanionCallback: ({
            Value<int?> id = const Value.absent(),
            Value<String?> nome = const Value.absent(),
            Value<String?> tipo = const Value.absent(),
            Value<String?> email = const Value.absent(),
            Value<String?> site = const Value.absent(),
            Value<String?> cpfCnpj = const Value.absent(),
            Value<String?> rgIe = const Value.absent(),
            Value<DateTime?> desde = const Value.absent(),
            Value<DateTime?> dataCadastro = const Value.absent(),
            Value<String?> observacao = const Value.absent(),
            Value<int?> idPessoa = const Value.absent(),
          }) =>
              ViewPessoaFornecedorsCompanion(
            id: id,
            nome: nome,
            tipo: tipo,
            email: email,
            site: site,
            cpfCnpj: cpfCnpj,
            rgIe: rgIe,
            desde: desde,
            dataCadastro: dataCadastro,
            observacao: observacao,
            idPessoa: idPessoa,
          ),
          createCompanionCallback: ({
            Value<int?> id = const Value.absent(),
            Value<String?> nome = const Value.absent(),
            Value<String?> tipo = const Value.absent(),
            Value<String?> email = const Value.absent(),
            Value<String?> site = const Value.absent(),
            Value<String?> cpfCnpj = const Value.absent(),
            Value<String?> rgIe = const Value.absent(),
            Value<DateTime?> desde = const Value.absent(),
            Value<DateTime?> dataCadastro = const Value.absent(),
            Value<String?> observacao = const Value.absent(),
            Value<int?> idPessoa = const Value.absent(),
          }) =>
              ViewPessoaFornecedorsCompanion.insert(
            id: id,
            nome: nome,
            tipo: tipo,
            email: email,
            site: site,
            cpfCnpj: cpfCnpj,
            rgIe: rgIe,
            desde: desde,
            dataCadastro: dataCadastro,
            observacao: observacao,
            idPessoa: idPessoa,
          ),
        ));
}

class $$ViewPessoaFornecedorsTableFilterComposer
    extends FilterComposer<_$AppDatabase, $ViewPessoaFornecedorsTable> {
  $$ViewPessoaFornecedorsTableFilterComposer(super.$state);
  ColumnFilters<int> get id => $state.composableBuilder(
      column: $state.table.id,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get nome => $state.composableBuilder(
      column: $state.table.nome,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get tipo => $state.composableBuilder(
      column: $state.table.tipo,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get email => $state.composableBuilder(
      column: $state.table.email,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get site => $state.composableBuilder(
      column: $state.table.site,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get cpfCnpj => $state.composableBuilder(
      column: $state.table.cpfCnpj,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get rgIe => $state.composableBuilder(
      column: $state.table.rgIe,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<DateTime> get desde => $state.composableBuilder(
      column: $state.table.desde,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<DateTime> get dataCadastro => $state.composableBuilder(
      column: $state.table.dataCadastro,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get observacao => $state.composableBuilder(
      column: $state.table.observacao,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<int> get idPessoa => $state.composableBuilder(
      column: $state.table.idPessoa,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));
}

class $$ViewPessoaFornecedorsTableOrderingComposer
    extends OrderingComposer<_$AppDatabase, $ViewPessoaFornecedorsTable> {
  $$ViewPessoaFornecedorsTableOrderingComposer(super.$state);
  ColumnOrderings<int> get id => $state.composableBuilder(
      column: $state.table.id,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get nome => $state.composableBuilder(
      column: $state.table.nome,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get tipo => $state.composableBuilder(
      column: $state.table.tipo,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get email => $state.composableBuilder(
      column: $state.table.email,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get site => $state.composableBuilder(
      column: $state.table.site,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get cpfCnpj => $state.composableBuilder(
      column: $state.table.cpfCnpj,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get rgIe => $state.composableBuilder(
      column: $state.table.rgIe,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<DateTime> get desde => $state.composableBuilder(
      column: $state.table.desde,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<DateTime> get dataCadastro => $state.composableBuilder(
      column: $state.table.dataCadastro,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get observacao => $state.composableBuilder(
      column: $state.table.observacao,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<int> get idPessoa => $state.composableBuilder(
      column: $state.table.idPessoa,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));
}

typedef $$ViewPessoaColaboradorsTableCreateCompanionBuilder
    = ViewPessoaColaboradorsCompanion Function({
  Value<int?> id,
  Value<String?> nome,
  Value<String?> tipo,
  Value<String?> email,
  Value<String?> site,
  Value<String?> cpfCnpj,
  Value<String?> rgIe,
  Value<String?> matricula,
  Value<DateTime?> dataCadastro,
  Value<DateTime?> dataAdmissao,
  Value<DateTime?> dataDemissao,
  Value<String?> ctpsNumero,
  Value<String?> ctpsSerie,
  Value<DateTime?> ctpsDataExpedicao,
  Value<String?> ctpsUf,
  Value<String?> observacao,
  Value<String?> logradouro,
  Value<String?> numero,
  Value<String?> complemento,
  Value<String?> bairro,
  Value<String?> cidade,
  Value<String?> cep,
  Value<String?> municipioIbge,
  Value<String?> uf,
  Value<int?> idPessoa,
  Value<int?> idCargo,
  Value<int?> idSetor,
});
typedef $$ViewPessoaColaboradorsTableUpdateCompanionBuilder
    = ViewPessoaColaboradorsCompanion Function({
  Value<int?> id,
  Value<String?> nome,
  Value<String?> tipo,
  Value<String?> email,
  Value<String?> site,
  Value<String?> cpfCnpj,
  Value<String?> rgIe,
  Value<String?> matricula,
  Value<DateTime?> dataCadastro,
  Value<DateTime?> dataAdmissao,
  Value<DateTime?> dataDemissao,
  Value<String?> ctpsNumero,
  Value<String?> ctpsSerie,
  Value<DateTime?> ctpsDataExpedicao,
  Value<String?> ctpsUf,
  Value<String?> observacao,
  Value<String?> logradouro,
  Value<String?> numero,
  Value<String?> complemento,
  Value<String?> bairro,
  Value<String?> cidade,
  Value<String?> cep,
  Value<String?> municipioIbge,
  Value<String?> uf,
  Value<int?> idPessoa,
  Value<int?> idCargo,
  Value<int?> idSetor,
});

class $$ViewPessoaColaboradorsTableTableManager extends RootTableManager<
    _$AppDatabase,
    $ViewPessoaColaboradorsTable,
    ViewPessoaColaborador,
    $$ViewPessoaColaboradorsTableFilterComposer,
    $$ViewPessoaColaboradorsTableOrderingComposer,
    $$ViewPessoaColaboradorsTableCreateCompanionBuilder,
    $$ViewPessoaColaboradorsTableUpdateCompanionBuilder> {
  $$ViewPessoaColaboradorsTableTableManager(
      _$AppDatabase db, $ViewPessoaColaboradorsTable table)
      : super(TableManagerState(
          db: db,
          table: table,
          filteringComposer: $$ViewPessoaColaboradorsTableFilterComposer(
              ComposerState(db, table)),
          orderingComposer: $$ViewPessoaColaboradorsTableOrderingComposer(
              ComposerState(db, table)),
          updateCompanionCallback: ({
            Value<int?> id = const Value.absent(),
            Value<String?> nome = const Value.absent(),
            Value<String?> tipo = const Value.absent(),
            Value<String?> email = const Value.absent(),
            Value<String?> site = const Value.absent(),
            Value<String?> cpfCnpj = const Value.absent(),
            Value<String?> rgIe = const Value.absent(),
            Value<String?> matricula = const Value.absent(),
            Value<DateTime?> dataCadastro = const Value.absent(),
            Value<DateTime?> dataAdmissao = const Value.absent(),
            Value<DateTime?> dataDemissao = const Value.absent(),
            Value<String?> ctpsNumero = const Value.absent(),
            Value<String?> ctpsSerie = const Value.absent(),
            Value<DateTime?> ctpsDataExpedicao = const Value.absent(),
            Value<String?> ctpsUf = const Value.absent(),
            Value<String?> observacao = const Value.absent(),
            Value<String?> logradouro = const Value.absent(),
            Value<String?> numero = const Value.absent(),
            Value<String?> complemento = const Value.absent(),
            Value<String?> bairro = const Value.absent(),
            Value<String?> cidade = const Value.absent(),
            Value<String?> cep = const Value.absent(),
            Value<String?> municipioIbge = const Value.absent(),
            Value<String?> uf = const Value.absent(),
            Value<int?> idPessoa = const Value.absent(),
            Value<int?> idCargo = const Value.absent(),
            Value<int?> idSetor = const Value.absent(),
          }) =>
              ViewPessoaColaboradorsCompanion(
            id: id,
            nome: nome,
            tipo: tipo,
            email: email,
            site: site,
            cpfCnpj: cpfCnpj,
            rgIe: rgIe,
            matricula: matricula,
            dataCadastro: dataCadastro,
            dataAdmissao: dataAdmissao,
            dataDemissao: dataDemissao,
            ctpsNumero: ctpsNumero,
            ctpsSerie: ctpsSerie,
            ctpsDataExpedicao: ctpsDataExpedicao,
            ctpsUf: ctpsUf,
            observacao: observacao,
            logradouro: logradouro,
            numero: numero,
            complemento: complemento,
            bairro: bairro,
            cidade: cidade,
            cep: cep,
            municipioIbge: municipioIbge,
            uf: uf,
            idPessoa: idPessoa,
            idCargo: idCargo,
            idSetor: idSetor,
          ),
          createCompanionCallback: ({
            Value<int?> id = const Value.absent(),
            Value<String?> nome = const Value.absent(),
            Value<String?> tipo = const Value.absent(),
            Value<String?> email = const Value.absent(),
            Value<String?> site = const Value.absent(),
            Value<String?> cpfCnpj = const Value.absent(),
            Value<String?> rgIe = const Value.absent(),
            Value<String?> matricula = const Value.absent(),
            Value<DateTime?> dataCadastro = const Value.absent(),
            Value<DateTime?> dataAdmissao = const Value.absent(),
            Value<DateTime?> dataDemissao = const Value.absent(),
            Value<String?> ctpsNumero = const Value.absent(),
            Value<String?> ctpsSerie = const Value.absent(),
            Value<DateTime?> ctpsDataExpedicao = const Value.absent(),
            Value<String?> ctpsUf = const Value.absent(),
            Value<String?> observacao = const Value.absent(),
            Value<String?> logradouro = const Value.absent(),
            Value<String?> numero = const Value.absent(),
            Value<String?> complemento = const Value.absent(),
            Value<String?> bairro = const Value.absent(),
            Value<String?> cidade = const Value.absent(),
            Value<String?> cep = const Value.absent(),
            Value<String?> municipioIbge = const Value.absent(),
            Value<String?> uf = const Value.absent(),
            Value<int?> idPessoa = const Value.absent(),
            Value<int?> idCargo = const Value.absent(),
            Value<int?> idSetor = const Value.absent(),
          }) =>
              ViewPessoaColaboradorsCompanion.insert(
            id: id,
            nome: nome,
            tipo: tipo,
            email: email,
            site: site,
            cpfCnpj: cpfCnpj,
            rgIe: rgIe,
            matricula: matricula,
            dataCadastro: dataCadastro,
            dataAdmissao: dataAdmissao,
            dataDemissao: dataDemissao,
            ctpsNumero: ctpsNumero,
            ctpsSerie: ctpsSerie,
            ctpsDataExpedicao: ctpsDataExpedicao,
            ctpsUf: ctpsUf,
            observacao: observacao,
            logradouro: logradouro,
            numero: numero,
            complemento: complemento,
            bairro: bairro,
            cidade: cidade,
            cep: cep,
            municipioIbge: municipioIbge,
            uf: uf,
            idPessoa: idPessoa,
            idCargo: idCargo,
            idSetor: idSetor,
          ),
        ));
}

class $$ViewPessoaColaboradorsTableFilterComposer
    extends FilterComposer<_$AppDatabase, $ViewPessoaColaboradorsTable> {
  $$ViewPessoaColaboradorsTableFilterComposer(super.$state);
  ColumnFilters<int> get id => $state.composableBuilder(
      column: $state.table.id,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get nome => $state.composableBuilder(
      column: $state.table.nome,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get tipo => $state.composableBuilder(
      column: $state.table.tipo,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get email => $state.composableBuilder(
      column: $state.table.email,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get site => $state.composableBuilder(
      column: $state.table.site,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get cpfCnpj => $state.composableBuilder(
      column: $state.table.cpfCnpj,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get rgIe => $state.composableBuilder(
      column: $state.table.rgIe,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get matricula => $state.composableBuilder(
      column: $state.table.matricula,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<DateTime> get dataCadastro => $state.composableBuilder(
      column: $state.table.dataCadastro,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<DateTime> get dataAdmissao => $state.composableBuilder(
      column: $state.table.dataAdmissao,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<DateTime> get dataDemissao => $state.composableBuilder(
      column: $state.table.dataDemissao,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get ctpsNumero => $state.composableBuilder(
      column: $state.table.ctpsNumero,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get ctpsSerie => $state.composableBuilder(
      column: $state.table.ctpsSerie,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<DateTime> get ctpsDataExpedicao => $state.composableBuilder(
      column: $state.table.ctpsDataExpedicao,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get ctpsUf => $state.composableBuilder(
      column: $state.table.ctpsUf,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get observacao => $state.composableBuilder(
      column: $state.table.observacao,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get logradouro => $state.composableBuilder(
      column: $state.table.logradouro,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get numero => $state.composableBuilder(
      column: $state.table.numero,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get complemento => $state.composableBuilder(
      column: $state.table.complemento,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get bairro => $state.composableBuilder(
      column: $state.table.bairro,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get cidade => $state.composableBuilder(
      column: $state.table.cidade,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get cep => $state.composableBuilder(
      column: $state.table.cep,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get municipioIbge => $state.composableBuilder(
      column: $state.table.municipioIbge,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get uf => $state.composableBuilder(
      column: $state.table.uf,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<int> get idPessoa => $state.composableBuilder(
      column: $state.table.idPessoa,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<int> get idCargo => $state.composableBuilder(
      column: $state.table.idCargo,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<int> get idSetor => $state.composableBuilder(
      column: $state.table.idSetor,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));
}

class $$ViewPessoaColaboradorsTableOrderingComposer
    extends OrderingComposer<_$AppDatabase, $ViewPessoaColaboradorsTable> {
  $$ViewPessoaColaboradorsTableOrderingComposer(super.$state);
  ColumnOrderings<int> get id => $state.composableBuilder(
      column: $state.table.id,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get nome => $state.composableBuilder(
      column: $state.table.nome,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get tipo => $state.composableBuilder(
      column: $state.table.tipo,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get email => $state.composableBuilder(
      column: $state.table.email,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get site => $state.composableBuilder(
      column: $state.table.site,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get cpfCnpj => $state.composableBuilder(
      column: $state.table.cpfCnpj,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get rgIe => $state.composableBuilder(
      column: $state.table.rgIe,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get matricula => $state.composableBuilder(
      column: $state.table.matricula,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<DateTime> get dataCadastro => $state.composableBuilder(
      column: $state.table.dataCadastro,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<DateTime> get dataAdmissao => $state.composableBuilder(
      column: $state.table.dataAdmissao,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<DateTime> get dataDemissao => $state.composableBuilder(
      column: $state.table.dataDemissao,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get ctpsNumero => $state.composableBuilder(
      column: $state.table.ctpsNumero,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get ctpsSerie => $state.composableBuilder(
      column: $state.table.ctpsSerie,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<DateTime> get ctpsDataExpedicao => $state.composableBuilder(
      column: $state.table.ctpsDataExpedicao,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get ctpsUf => $state.composableBuilder(
      column: $state.table.ctpsUf,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get observacao => $state.composableBuilder(
      column: $state.table.observacao,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get logradouro => $state.composableBuilder(
      column: $state.table.logradouro,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get numero => $state.composableBuilder(
      column: $state.table.numero,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get complemento => $state.composableBuilder(
      column: $state.table.complemento,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get bairro => $state.composableBuilder(
      column: $state.table.bairro,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get cidade => $state.composableBuilder(
      column: $state.table.cidade,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get cep => $state.composableBuilder(
      column: $state.table.cep,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get municipioIbge => $state.composableBuilder(
      column: $state.table.municipioIbge,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get uf => $state.composableBuilder(
      column: $state.table.uf,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<int> get idPessoa => $state.composableBuilder(
      column: $state.table.idPessoa,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<int> get idCargo => $state.composableBuilder(
      column: $state.table.idCargo,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<int> get idSetor => $state.composableBuilder(
      column: $state.table.idSetor,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));
}

class $AppDatabaseManager {
  final _$AppDatabase _db;
  $AppDatabaseManager(this._db);
  $$ContratoHistoricoReajustesTableTableManager
      get contratoHistoricoReajustes =>
          $$ContratoHistoricoReajustesTableTableManager(
              _db, _db.contratoHistoricoReajustes);
  $$ContratoPrevFaturamentosTableTableManager get contratoPrevFaturamentos =>
      $$ContratoPrevFaturamentosTableTableManager(
          _db, _db.contratoPrevFaturamentos);
  $$ContratoHistFaturamentosTableTableManager get contratoHistFaturamentos =>
      $$ContratoHistFaturamentosTableTableManager(
          _db, _db.contratoHistFaturamentos);
  $$ContratosTableTableManager get contratos =>
      $$ContratosTableTableManager(_db, _db.contratos);
  $$SetorsTableTableManager get setors =>
      $$SetorsTableTableManager(_db, _db.setors);
  $$TipoContratosTableTableManager get tipoContratos =>
      $$TipoContratosTableTableManager(_db, _db.tipoContratos);
  $$ContratoTipoServicosTableTableManager get contratoTipoServicos =>
      $$ContratoTipoServicosTableTableManager(_db, _db.contratoTipoServicos);
  $$ContratoSolicitacaoServicosTableTableManager
      get contratoSolicitacaoServicos =>
          $$ContratoSolicitacaoServicosTableTableManager(
              _db, _db.contratoSolicitacaoServicos);
  $$ContratoTemplatesTableTableManager get contratoTemplates =>
      $$ContratoTemplatesTableTableManager(_db, _db.contratoTemplates);
  $$ViewControleAcessosTableTableManager get viewControleAcessos =>
      $$ViewControleAcessosTableTableManager(_db, _db.viewControleAcessos);
  $$ViewPessoaUsuariosTableTableManager get viewPessoaUsuarios =>
      $$ViewPessoaUsuariosTableTableManager(_db, _db.viewPessoaUsuarios);
  $$ViewPessoaClientesTableTableManager get viewPessoaClientes =>
      $$ViewPessoaClientesTableTableManager(_db, _db.viewPessoaClientes);
  $$ViewPessoaFornecedorsTableTableManager get viewPessoaFornecedors =>
      $$ViewPessoaFornecedorsTableTableManager(_db, _db.viewPessoaFornecedors);
  $$ViewPessoaColaboradorsTableTableManager get viewPessoaColaboradors =>
      $$ViewPessoaColaboradorsTableTableManager(
          _db, _db.viewPessoaColaboradors);
}
