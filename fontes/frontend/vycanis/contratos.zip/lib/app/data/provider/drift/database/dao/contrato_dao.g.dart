// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'contrato_dao.dart';

// ignore_for_file: type=lint
mixin _$ContratoDaoMixin on DatabaseAccessor<AppDatabase> {
  $ContratosTable get contratos => attachedDatabase.contratos;
  $ContratoHistoricoReajustesTable get contratoHistoricoReajustes =>
      attachedDatabase.contratoHistoricoReajustes;
  $ContratoPrevFaturamentosTable get contratoPrevFaturamentos =>
      attachedDatabase.contratoPrevFaturamentos;
  $ContratoHistFaturamentosTable get contratoHistFaturamentos =>
      attachedDatabase.contratoHistFaturamentos;
  $TipoContratosTable get tipoContratos => attachedDatabase.tipoContratos;
  $ContratoSolicitacaoServicosTable get contratoSolicitacaoServicos =>
      attachedDatabase.contratoSolicitacaoServicos;
}
