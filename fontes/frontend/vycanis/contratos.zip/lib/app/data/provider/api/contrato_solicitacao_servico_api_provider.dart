import 'package:contratos/app/data/provider/api/api_provider_base.dart';
import 'package:contratos/app/data/model/model_imports.dart';

class ContratoSolicitacaoServicoApiProvider extends ApiProviderBase {
  static const _path = '/contrato-solicitacao-servico';

  Future<List<ContratoSolicitacaoServicoModel>?> getList({Filter? filter}) {
    return super.getListBase(
      '$_path/',
      (json) => ContratoSolicitacaoServicoModel.fromJson(json),
      filter: filter,
    );
  }

  Future<ContratoSolicitacaoServicoModel?> getObject(dynamic pk) {
    return super.getObjectBase(
      _path,
      pk,
      (json) => ContratoSolicitacaoServicoModel.fromJson(json),
    );
  }

  Future<ContratoSolicitacaoServicoModel?>? insert(ContratoSolicitacaoServicoModel model) {
    return super.insertBase(
      _path,
      model,
      (json) => ContratoSolicitacaoServicoModel.fromJson(json),
    );
  }

  Future<ContratoSolicitacaoServicoModel?>? update(ContratoSolicitacaoServicoModel model) {
    return super.updateBase(
      _path,
      model,
      (json) => ContratoSolicitacaoServicoModel.fromJson(json),
    );
  }

  Future<bool?> delete(dynamic pk) {
    return super.deleteBase(_path, pk);
  }
}
