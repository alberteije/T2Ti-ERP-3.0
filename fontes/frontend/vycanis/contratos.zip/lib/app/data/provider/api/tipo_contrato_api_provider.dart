import 'package:contratos/app/data/provider/api/api_provider_base.dart';
import 'package:contratos/app/data/model/model_imports.dart';

class TipoContratoApiProvider extends ApiProviderBase {
  static const _path = '/tipo-contrato';

  Future<List<TipoContratoModel>?> getList({Filter? filter}) {
    return super.getListBase(
      '$_path/',
      (json) => TipoContratoModel.fromJson(json),
      filter: filter,
    );
  }

  Future<TipoContratoModel?> getObject(dynamic pk) {
    return super.getObjectBase(
      _path,
      pk,
      (json) => TipoContratoModel.fromJson(json),
    );
  }

  Future<TipoContratoModel?>? insert(TipoContratoModel model) {
    return super.insertBase(
      _path,
      model,
      (json) => TipoContratoModel.fromJson(json),
    );
  }

  Future<TipoContratoModel?>? update(TipoContratoModel model) {
    return super.updateBase(
      _path,
      model,
      (json) => TipoContratoModel.fromJson(json),
    );
  }

  Future<bool?> delete(dynamic pk) {
    return super.deleteBase(_path, pk);
  }
}
