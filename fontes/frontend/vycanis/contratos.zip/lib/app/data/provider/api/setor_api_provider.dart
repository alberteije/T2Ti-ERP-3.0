import 'package:contratos/app/data/provider/api/api_provider_base.dart';
import 'package:contratos/app/data/model/model_imports.dart';

class SetorApiProvider extends ApiProviderBase {
  static const _path = '/setor';

  Future<List<SetorModel>?> getList({Filter? filter}) {
    return super.getListBase(
      '$_path/',
      (json) => SetorModel.fromJson(json),
      filter: filter,
    );
  }

  Future<SetorModel?> getObject(dynamic pk) {
    return super.getObjectBase(
      _path,
      pk,
      (json) => SetorModel.fromJson(json),
    );
  }

  Future<SetorModel?>? insert(SetorModel model) {
    return super.insertBase(
      _path,
      model,
      (json) => SetorModel.fromJson(json),
    );
  }

  Future<SetorModel?>? update(SetorModel model) {
    return super.updateBase(
      _path,
      model,
      (json) => SetorModel.fromJson(json),
    );
  }

  Future<bool?> delete(dynamic pk) {
    return super.deleteBase(_path, pk);
  }
}
