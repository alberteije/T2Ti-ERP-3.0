import 'package:contratos/app/data/provider/api/api_provider_base.dart';
import 'package:contratos/app/data/model/model_imports.dart';

class ContratoApiProvider extends ApiProviderBase {
  static const _path = '/contrato';

  Future<List<ContratoModel>?> getList({Filter? filter}) {
    return super.getListBase(
      '$_path/',
      (json) => ContratoModel.fromJson(json),
      filter: filter,
    );
  }

  Future<ContratoModel?> getObject(dynamic pk) {
    return super.getObjectBase(
      _path,
      pk,
      (json) => ContratoModel.fromJson(json),
    );
  }

  Future<ContratoModel?>? insert(ContratoModel model) {
    return super.insertBase(
      _path,
      model,
      (json) => ContratoModel.fromJson(json),
    );
  }

  Future<ContratoModel?>? update(ContratoModel model) {
    return super.updateBase(
      _path,
      model,
      (json) => ContratoModel.fromJson(json),
    );
  }

  Future<bool?> delete(dynamic pk) {
    return super.deleteBase(_path, pk);
  }
}
