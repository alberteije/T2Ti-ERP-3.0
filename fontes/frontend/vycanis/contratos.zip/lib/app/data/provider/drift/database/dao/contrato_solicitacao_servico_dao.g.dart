// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'contrato_solicitacao_servico_dao.dart';

// ignore_for_file: type=lint
mixin _$ContratoSolicitacaoServicoDaoMixin on DatabaseAccessor<AppDatabase> {
  $ContratoSolicitacaoServicosTable get contratoSolicitacaoServicos =>
      attachedDatabase.contratoSolicitacaoServicos;
  $ViewPessoaColaboradorsTable get viewPessoaColaboradors =>
      attachedDatabase.viewPessoaColaboradors;
  $ViewPessoaClientesTable get viewPessoaClientes =>
      attachedDatabase.viewPessoaClientes;
  $ViewPessoaFornecedorsTable get viewPessoaFornecedors =>
      attachedDatabase.viewPessoaFornecedors;
  $SetorsTable get setors => attachedDatabase.setors;
  $ContratoTipoServicosTable get contratoTipoServicos =>
      attachedDatabase.contratoTipoServicos;
}
