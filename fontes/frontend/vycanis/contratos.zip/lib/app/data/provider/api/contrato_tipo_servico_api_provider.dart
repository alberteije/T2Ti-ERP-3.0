import 'package:contratos/app/data/provider/api/api_provider_base.dart';
import 'package:contratos/app/data/model/model_imports.dart';

class ContratoTipoServicoApiProvider extends ApiProviderBase {
  static const _path = '/contrato-tipo-servico';

  Future<List<ContratoTipoServicoModel>?> getList({Filter? filter}) {
    return super.getListBase(
      '$_path/',
      (json) => ContratoTipoServicoModel.fromJson(json),
      filter: filter,
    );
  }

  Future<ContratoTipoServicoModel?> getObject(dynamic pk) {
    return super.getObjectBase(
      _path,
      pk,
      (json) => ContratoTipoServicoModel.fromJson(json),
    );
  }

  Future<ContratoTipoServicoModel?>? insert(ContratoTipoServicoModel model) {
    return super.insertBase(
      _path,
      model,
      (json) => ContratoTipoServicoModel.fromJson(json),
    );
  }

  Future<ContratoTipoServicoModel?>? update(ContratoTipoServicoModel model) {
    return super.updateBase(
      _path,
      model,
      (json) => ContratoTipoServicoModel.fromJson(json),
    );
  }

  Future<bool?> delete(dynamic pk) {
    return super.deleteBase(_path, pk);
  }
}
