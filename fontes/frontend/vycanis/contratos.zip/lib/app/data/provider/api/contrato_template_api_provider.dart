import 'package:contratos/app/data/provider/api/api_provider_base.dart';
import 'package:contratos/app/data/model/model_imports.dart';

class ContratoTemplateApiProvider extends ApiProviderBase {
  static const _path = '/contrato-template';

  Future<List<ContratoTemplateModel>?> getList({Filter? filter}) {
    return super.getListBase(
      '$_path/',
      (json) => ContratoTemplateModel.fromJson(json),
      filter: filter,
    );
  }

  Future<ContratoTemplateModel?> getObject(dynamic pk) {
    return super.getObjectBase(
      _path,
      pk,
      (json) => ContratoTemplateModel.fromJson(json),
    );
  }

  Future<ContratoTemplateModel?>? insert(ContratoTemplateModel model) {
    return super.insertBase(
      _path,
      model,
      (json) => ContratoTemplateModel.fromJson(json),
    );
  }

  Future<ContratoTemplateModel?>? update(ContratoTemplateModel model) {
    return super.updateBase(
      _path,
      model,
      (json) => ContratoTemplateModel.fromJson(json),
    );
  }

  Future<bool?> delete(dynamic pk) {
    return super.deleteBase(_path, pk);
  }
}
