import 'dart:convert';
import 'package:pluto_grid/pluto_grid.dart';
import 'package:contratos/app/data/model/model_imports.dart';

import 'package:contratos/app/infra/infra_imports.dart';
import 'package:intl/intl.dart';

class ContratoModel extends ModelBase {
  int? id;
  int? idSolicitacaoServico;
  int? idTipoContrato;
  String? numero;
  String? nome;
  String? descricao;
  DateTime? dataCadastro;
  DateTime? dataInicioVigencia;
  DateTime? dataFimVigencia;
  String? diaFaturamento;
  double? valor;
  int? quantidadeParcelas;
  int? intervaloEntreParcelas;
  String? classificacaoContabilConta;
  String? observacao;
  List<ContratoHistoricoReajusteModel>? contratoHistoricoReajusteModelList;
  List<ContratoPrevFaturamentoModel>? contratoPrevFaturamentoModelList;
  List<ContratoHistFaturamentoModel>? contratoHistFaturamentoModelList;
  TipoContratoModel? tipoContratoModel;
  ContratoSolicitacaoServicoModel? contratoSolicitacaoServicoModel;

  ContratoModel({
    this.id,
    this.idSolicitacaoServico,
    this.idTipoContrato,
    this.numero,
    this.nome,
    this.descricao,
    this.dataCadastro,
    this.dataInicioVigencia,
    this.dataFimVigencia,
    this.diaFaturamento,
    this.valor,
    this.quantidadeParcelas,
    this.intervaloEntreParcelas,
    this.classificacaoContabilConta,
    this.observacao,
    List<ContratoHistoricoReajusteModel>? contratoHistoricoReajusteModelList,
    List<ContratoPrevFaturamentoModel>? contratoPrevFaturamentoModelList,
    List<ContratoHistFaturamentoModel>? contratoHistFaturamentoModelList,
    TipoContratoModel? tipoContratoModel,
    ContratoSolicitacaoServicoModel? contratoSolicitacaoServicoModel,
  }) {
    this.contratoHistoricoReajusteModelList = contratoHistoricoReajusteModelList?.toList(growable: true) ?? [];
    this.contratoPrevFaturamentoModelList = contratoPrevFaturamentoModelList?.toList(growable: true) ?? [];
    this.contratoHistFaturamentoModelList = contratoHistFaturamentoModelList?.toList(growable: true) ?? [];
    this.tipoContratoModel = tipoContratoModel ?? TipoContratoModel();
    this.contratoSolicitacaoServicoModel = contratoSolicitacaoServicoModel ?? ContratoSolicitacaoServicoModel();
  }

  static List<String> dbColumns = <String>[
    'id',
    'numero',
    'nome',
    'descricao',
    'data_cadastro',
    'data_inicio_vigencia',
    'data_fim_vigencia',
    'dia_faturamento',
    'valor',
    'quantidade_parcelas',
    'intervalo_entre_parcelas',
    'classificacao_contabil_conta',
    'observacao',
  ];

  static List<String> aliasColumns = <String>[
    'Id',
    'Numero',
    'Nome',
    'Descricao',
    'Data Cadastro',
    'Data Inicio Vigencia',
    'Data Fim Vigencia',
    'Dia Faturamento',
    'Valor',
    'Quantidade Parcelas',
    'Intervalo Entre Parcelas',
    'Classificacao Contabil Conta',
    'Observacao',
  ];

  ContratoModel.fromJson(Map<String, dynamic> jsonData) {
    id = jsonData['id'];
    idSolicitacaoServico = jsonData['idSolicitacaoServico'];
    idTipoContrato = jsonData['idTipoContrato'];
    numero = jsonData['numero'];
    nome = jsonData['nome'];
    descricao = jsonData['descricao'];
    dataCadastro = jsonData['dataCadastro'] != null ? DateTime.tryParse(jsonData['dataCadastro']) : null;
    dataInicioVigencia = jsonData['dataInicioVigencia'] != null ? DateTime.tryParse(jsonData['dataInicioVigencia']) : null;
    dataFimVigencia = jsonData['dataFimVigencia'] != null ? DateTime.tryParse(jsonData['dataFimVigencia']) : null;
    diaFaturamento = jsonData['diaFaturamento'];
    valor = jsonData['valor']?.toDouble();
    quantidadeParcelas = jsonData['quantidadeParcelas'];
    intervaloEntreParcelas = jsonData['intervaloEntreParcelas'];
    classificacaoContabilConta = jsonData['classificacaoContabilConta'];
    observacao = jsonData['observacao'];
    contratoHistoricoReajusteModelList = (jsonData['contratoHistoricoReajusteModelList'] as Iterable?)?.map((m) => ContratoHistoricoReajusteModel.fromJson(m)).toList() ?? [];
    contratoPrevFaturamentoModelList = (jsonData['contratoPrevFaturamentoModelList'] as Iterable?)?.map((m) => ContratoPrevFaturamentoModel.fromJson(m)).toList() ?? [];
    contratoHistFaturamentoModelList = (jsonData['contratoHistFaturamentoModelList'] as Iterable?)?.map((m) => ContratoHistFaturamentoModel.fromJson(m)).toList() ?? [];
    tipoContratoModel = jsonData['tipoContratoModel'] == null ? TipoContratoModel() : TipoContratoModel.fromJson(jsonData['tipoContratoModel']);
    contratoSolicitacaoServicoModel = jsonData['contratoSolicitacaoServicoModel'] == null ? ContratoSolicitacaoServicoModel() : ContratoSolicitacaoServicoModel.fromJson(jsonData['contratoSolicitacaoServicoModel']);
  }

  Map<String, dynamic> get toJson {
    Map<String, dynamic> jsonData = <String, dynamic>{};

    jsonData['id'] = id != 0 ? id : null;
    jsonData['idSolicitacaoServico'] = idSolicitacaoServico != 0 ? idSolicitacaoServico : null;
    jsonData['idTipoContrato'] = idTipoContrato != 0 ? idTipoContrato : null;
    jsonData['numero'] = numero;
    jsonData['nome'] = nome;
    jsonData['descricao'] = descricao;
    jsonData['dataCadastro'] = dataCadastro != null ? DateFormat('yyyy-MM-ddT00:00:00').format(dataCadastro!) : null;
    jsonData['dataInicioVigencia'] = dataInicioVigencia != null ? DateFormat('yyyy-MM-ddT00:00:00').format(dataInicioVigencia!) : null;
    jsonData['dataFimVigencia'] = dataFimVigencia != null ? DateFormat('yyyy-MM-ddT00:00:00').format(dataFimVigencia!) : null;
    jsonData['diaFaturamento'] = diaFaturamento;
    jsonData['valor'] = valor;
    jsonData['quantidadeParcelas'] = quantidadeParcelas;
    jsonData['intervaloEntreParcelas'] = intervaloEntreParcelas;
    jsonData['classificacaoContabilConta'] = classificacaoContabilConta;
    jsonData['observacao'] = observacao;
    
		var contratoHistoricoReajusteModelLocalList = []; 
		for (ContratoHistoricoReajusteModel object in contratoHistoricoReajusteModelList ?? []) { 
			contratoHistoricoReajusteModelLocalList.add(object.toJson); 
		}
		jsonData['contratoHistoricoReajusteModelList'] = contratoHistoricoReajusteModelLocalList;
    
		var contratoPrevFaturamentoModelLocalList = []; 
		for (ContratoPrevFaturamentoModel object in contratoPrevFaturamentoModelList ?? []) { 
			contratoPrevFaturamentoModelLocalList.add(object.toJson); 
		}
		jsonData['contratoPrevFaturamentoModelList'] = contratoPrevFaturamentoModelLocalList;
    
		var contratoHistFaturamentoModelLocalList = []; 
		for (ContratoHistFaturamentoModel object in contratoHistFaturamentoModelList ?? []) { 
			contratoHistFaturamentoModelLocalList.add(object.toJson); 
		}
		jsonData['contratoHistFaturamentoModelList'] = contratoHistFaturamentoModelLocalList;
    jsonData['tipoContratoModel'] = tipoContratoModel?.toJson;
    jsonData['tipoContrato'] = tipoContratoModel?.nome ?? '';
    jsonData['contratoSolicitacaoServicoModel'] = contratoSolicitacaoServicoModel?.toJson;
    jsonData['contratoSolicitacaoServico'] = contratoSolicitacaoServicoModel?.descricao ?? '';

    return jsonData;
  }

  String objectEncodeJson() {
    final jsonData = toJson;
    return json.encode(jsonData);
  }

  static ContratoModel fromPlutoRow(PlutoRow row) {
    return ContratoModel(
      id: row.cells['id']?.value,
      idSolicitacaoServico: row.cells['idSolicitacaoServico']?.value,
      idTipoContrato: row.cells['idTipoContrato']?.value,
      numero: row.cells['numero']?.value,
      nome: row.cells['nome']?.value,
      descricao: row.cells['descricao']?.value,
      dataCadastro: Util.stringToDate(row.cells['dataCadastro']?.value),
      dataInicioVigencia: Util.stringToDate(row.cells['dataInicioVigencia']?.value),
      dataFimVigencia: Util.stringToDate(row.cells['dataFimVigencia']?.value),
      diaFaturamento: row.cells['diaFaturamento']?.value,
      valor: row.cells['valor']?.value,
      quantidadeParcelas: row.cells['quantidadeParcelas']?.value,
      intervaloEntreParcelas: row.cells['intervaloEntreParcelas']?.value,
      classificacaoContabilConta: row.cells['classificacaoContabilConta']?.value,
      observacao: row.cells['observacao']?.value,
    );
  }

  PlutoRow toPlutoRow() {
    return PlutoRow(
      cells: {
        'tempId': PlutoCell(value: tempId),
        'id': PlutoCell(value: id ?? 0),
        'idSolicitacaoServico': PlutoCell(value: idSolicitacaoServico ?? 0),
        'idTipoContrato': PlutoCell(value: idTipoContrato ?? 0),
        'numero': PlutoCell(value: numero ?? ''),
        'nome': PlutoCell(value: nome ?? ''),
        'descricao': PlutoCell(value: descricao ?? ''),
        'dataCadastro': PlutoCell(value: dataCadastro),
        'dataInicioVigencia': PlutoCell(value: dataInicioVigencia),
        'dataFimVigencia': PlutoCell(value: dataFimVigencia),
        'diaFaturamento': PlutoCell(value: diaFaturamento ?? ''),
        'valor': PlutoCell(value: valor ?? 0.0),
        'quantidadeParcelas': PlutoCell(value: quantidadeParcelas ?? 0),
        'intervaloEntreParcelas': PlutoCell(value: intervaloEntreParcelas ?? 0),
        'classificacaoContabilConta': PlutoCell(value: classificacaoContabilConta ?? ''),
        'observacao': PlutoCell(value: observacao ?? ''),
        'tipoContrato': PlutoCell(value: tipoContratoModel?.nome ?? ''),
        'contratoSolicitacaoServico': PlutoCell(value: contratoSolicitacaoServicoModel?.descricao ?? ''),
      },
    );
  }

  ContratoModel clone() {
    return ContratoModel(
      id: id,
      idSolicitacaoServico: idSolicitacaoServico,
      idTipoContrato: idTipoContrato,
      numero: numero,
      nome: nome,
      descricao: descricao,
      dataCadastro: dataCadastro,
      dataInicioVigencia: dataInicioVigencia,
      dataFimVigencia: dataFimVigencia,
      diaFaturamento: diaFaturamento,
      valor: valor,
      quantidadeParcelas: quantidadeParcelas,
      intervaloEntreParcelas: intervaloEntreParcelas,
      classificacaoContabilConta: classificacaoContabilConta,
      observacao: observacao,
      contratoHistoricoReajusteModelList: contratoHistoricoReajusteModelListClone(contratoHistoricoReajusteModelList!),
      contratoPrevFaturamentoModelList: contratoPrevFaturamentoModelListClone(contratoPrevFaturamentoModelList!),
      contratoHistFaturamentoModelList: contratoHistFaturamentoModelListClone(contratoHistFaturamentoModelList!),
      tipoContratoModel: tipoContratoModel?.clone(),
      contratoSolicitacaoServicoModel: contratoSolicitacaoServicoModel?.clone(),
    );
  }

  contratoHistoricoReajusteModelListClone(List<ContratoHistoricoReajusteModel> contratoHistoricoReajusteModelList) { 
		List<ContratoHistoricoReajusteModel> resultList = [];
		for (var contratoHistoricoReajusteModel in contratoHistoricoReajusteModelList) {
			resultList.add(contratoHistoricoReajusteModel.clone());
		}
		return resultList;
	}

  contratoPrevFaturamentoModelListClone(List<ContratoPrevFaturamentoModel> contratoPrevFaturamentoModelList) { 
		List<ContratoPrevFaturamentoModel> resultList = [];
		for (var contratoPrevFaturamentoModel in contratoPrevFaturamentoModelList) {
			resultList.add(contratoPrevFaturamentoModel.clone());
		}
		return resultList;
	}

  contratoHistFaturamentoModelListClone(List<ContratoHistFaturamentoModel> contratoHistFaturamentoModelList) { 
		List<ContratoHistFaturamentoModel> resultList = [];
		for (var contratoHistFaturamentoModel in contratoHistFaturamentoModelList) {
			resultList.add(contratoHistFaturamentoModel.clone());
		}
		return resultList;
	}


}