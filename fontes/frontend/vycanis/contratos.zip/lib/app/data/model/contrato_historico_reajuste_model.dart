import 'dart:convert';
import 'package:pluto_grid/pluto_grid.dart';
import 'package:contratos/app/data/model/model_imports.dart';

import 'package:contratos/app/infra/infra_imports.dart';
import 'package:intl/intl.dart';

class ContratoHistoricoReajusteModel extends ModelBase {
  int? id;
  int? idContrato;
  double? indice;
  double? valorAnterior;
  double? valorAtual;
  DateTime? dataReajuste;
  String? observacao;

  ContratoHistoricoReajusteModel({
    this.id,
    this.idContrato,
    this.indice,
    this.valorAnterior,
    this.valorAtual,
    this.dataReajuste,
    this.observacao,
  });

  static List<String> dbColumns = <String>[
    'id',
    'indice',
    'valor_anterior',
    'valor_atual',
    'data_reajuste',
    'observacao',
  ];

  static List<String> aliasColumns = <String>[
    'Id',
    'Indice',
    'Valor Anterior',
    'Valor Atual',
    'Data Reajuste',
    'Observacao',
  ];

  ContratoHistoricoReajusteModel.fromJson(Map<String, dynamic> jsonData) {
    id = jsonData['id'];
    idContrato = jsonData['idContrato'];
    indice = jsonData['indice']?.toDouble();
    valorAnterior = jsonData['valorAnterior']?.toDouble();
    valorAtual = jsonData['valorAtual']?.toDouble();
    dataReajuste = jsonData['dataReajuste'] != null ? DateTime.tryParse(jsonData['dataReajuste']) : null;
    observacao = jsonData['observacao'];
  }

  Map<String, dynamic> get toJson {
    Map<String, dynamic> jsonData = <String, dynamic>{};

    jsonData['id'] = id != 0 ? id : null;
    jsonData['idContrato'] = idContrato != 0 ? idContrato : null;
    jsonData['indice'] = indice;
    jsonData['valorAnterior'] = valorAnterior;
    jsonData['valorAtual'] = valorAtual;
    jsonData['dataReajuste'] = dataReajuste != null ? DateFormat('yyyy-MM-ddT00:00:00').format(dataReajuste!) : null;
    jsonData['observacao'] = observacao;

    return jsonData;
  }

  String objectEncodeJson() {
    final jsonData = toJson;
    return json.encode(jsonData);
  }

  static ContratoHistoricoReajusteModel fromPlutoRow(PlutoRow row) {
    return ContratoHistoricoReajusteModel(
      id: row.cells['id']?.value,
      idContrato: row.cells['idContrato']?.value,
      indice: row.cells['indice']?.value,
      valorAnterior: row.cells['valorAnterior']?.value,
      valorAtual: row.cells['valorAtual']?.value,
      dataReajuste: Util.stringToDate(row.cells['dataReajuste']?.value),
      observacao: row.cells['observacao']?.value,
    );
  }

  PlutoRow toPlutoRow() {
    return PlutoRow(
      cells: {
        'tempId': PlutoCell(value: tempId),
        'id': PlutoCell(value: id ?? 0),
        'idContrato': PlutoCell(value: idContrato ?? 0),
        'indice': PlutoCell(value: indice ?? 0.0),
        'valorAnterior': PlutoCell(value: valorAnterior ?? 0.0),
        'valorAtual': PlutoCell(value: valorAtual ?? 0.0),
        'dataReajuste': PlutoCell(value: dataReajuste),
        'observacao': PlutoCell(value: observacao ?? ''),
      },
    );
  }

  ContratoHistoricoReajusteModel clone() {
    return ContratoHistoricoReajusteModel(
      id: id,
      idContrato: idContrato,
      indice: indice,
      valorAnterior: valorAnterior,
      valorAtual: valorAtual,
      dataReajuste: dataReajuste,
      observacao: observacao,
    );
  }


}