import 'dart:convert';
import 'package:pluto_grid/pluto_grid.dart';
import 'package:contratos/app/data/model/model_imports.dart';


class TipoContratoModel extends ModelBase {
  int? id;
  String? nome;
  String? descricao;

  TipoContratoModel({
    this.id,
    this.nome,
    this.descricao,
  });

  static List<String> dbColumns = <String>[
    'id',
    'nome',
    'descricao',
  ];

  static List<String> aliasColumns = <String>[
    'Id',
    'Nome',
    'Descricao',
  ];

  TipoContratoModel.fromJson(Map<String, dynamic> jsonData) {
    id = jsonData['id'];
    nome = jsonData['nome'];
    descricao = jsonData['descricao'];
  }

  Map<String, dynamic> get toJson {
    Map<String, dynamic> jsonData = <String, dynamic>{};

    jsonData['id'] = id != 0 ? id : null;
    jsonData['nome'] = nome;
    jsonData['descricao'] = descricao;

    return jsonData;
  }

  String objectEncodeJson() {
    final jsonData = toJson;
    return json.encode(jsonData);
  }

  static TipoContratoModel fromPlutoRow(PlutoRow row) {
    return TipoContratoModel(
      id: row.cells['id']?.value,
      nome: row.cells['nome']?.value,
      descricao: row.cells['descricao']?.value,
    );
  }

  PlutoRow toPlutoRow() {
    return PlutoRow(
      cells: {
        'tempId': PlutoCell(value: tempId),
        'id': PlutoCell(value: id ?? 0),
        'nome': PlutoCell(value: nome ?? ''),
        'descricao': PlutoCell(value: descricao ?? ''),
      },
    );
  }

  TipoContratoModel clone() {
    return TipoContratoModel(
      id: id,
      nome: nome,
      descricao: descricao,
    );
  }


}