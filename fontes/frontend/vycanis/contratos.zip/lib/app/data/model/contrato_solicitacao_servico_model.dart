import 'dart:convert';
import 'package:pluto_grid/pluto_grid.dart';
import 'package:contratos/app/data/model/model_imports.dart';

import 'package:contratos/app/infra/infra_imports.dart';
import 'package:intl/intl.dart';
import 'package:contratos/app/data/domain/domain_imports.dart';

class ContratoSolicitacaoServicoModel extends ModelBase {
  int? id;
  int? idContratoTipoServico;
  int? idSetor;
  int? idColaborador;
  int? idCliente;
  int? idFornecedor;
  DateTime? dataSolicitacao;
  DateTime? dataDesejadaInicio;
  String? urgente;
  String? statusSolicitacao;
  String? descricao;
  ViewPessoaColaboradorModel? viewPessoaColaboradorModel;
  ViewPessoaClienteModel? viewPessoaClienteModel;
  ViewPessoaFornecedorModel? viewPessoaFornecedorModel;
  SetorModel? setorModel;
  ContratoTipoServicoModel? contratoTipoServicoModel;

  ContratoSolicitacaoServicoModel({
    this.id,
    this.idContratoTipoServico,
    this.idSetor,
    this.idColaborador,
    this.idCliente,
    this.idFornecedor,
    this.dataSolicitacao,
    this.dataDesejadaInicio,
    this.urgente = 'S',
    this.statusSolicitacao = 'Aguardando',
    this.descricao,
    ViewPessoaColaboradorModel? viewPessoaColaboradorModel,
    ViewPessoaClienteModel? viewPessoaClienteModel,
    ViewPessoaFornecedorModel? viewPessoaFornecedorModel,
    SetorModel? setorModel,
    ContratoTipoServicoModel? contratoTipoServicoModel,
  }) {
    this.viewPessoaColaboradorModel = viewPessoaColaboradorModel ?? ViewPessoaColaboradorModel();
    this.viewPessoaClienteModel = viewPessoaClienteModel ?? ViewPessoaClienteModel();
    this.viewPessoaFornecedorModel = viewPessoaFornecedorModel ?? ViewPessoaFornecedorModel();
    this.setorModel = setorModel ?? SetorModel();
    this.contratoTipoServicoModel = contratoTipoServicoModel ?? ContratoTipoServicoModel();
  }

  static List<String> dbColumns = <String>[
    'id',
    'data_solicitacao',
    'data_desejada_inicio',
    'urgente',
    'status_solicitacao',
    'descricao',
  ];

  static List<String> aliasColumns = <String>[
    'Id',
    'Data Solicitacao',
    'Data Desejada Inicio',
    'Urgente',
    'Status Solicitacao',
    'Descricao',
  ];

  ContratoSolicitacaoServicoModel.fromJson(Map<String, dynamic> jsonData) {
    id = jsonData['id'];
    idContratoTipoServico = jsonData['idContratoTipoServico'];
    idSetor = jsonData['idSetor'];
    idColaborador = jsonData['idColaborador'];
    idCliente = jsonData['idCliente'];
    idFornecedor = jsonData['idFornecedor'];
    dataSolicitacao = jsonData['dataSolicitacao'] != null ? DateTime.tryParse(jsonData['dataSolicitacao']) : null;
    dataDesejadaInicio = jsonData['dataDesejadaInicio'] != null ? DateTime.tryParse(jsonData['dataDesejadaInicio']) : null;
    urgente = ContratoSolicitacaoServicoDomain.getUrgente(jsonData['urgente']);
    statusSolicitacao = ContratoSolicitacaoServicoDomain.getStatusSolicitacao(jsonData['statusSolicitacao']);
    descricao = jsonData['descricao'];
    viewPessoaColaboradorModel = jsonData['viewPessoaColaboradorModel'] == null ? ViewPessoaColaboradorModel() : ViewPessoaColaboradorModel.fromJson(jsonData['viewPessoaColaboradorModel']);
    viewPessoaClienteModel = jsonData['viewPessoaClienteModel'] == null ? ViewPessoaClienteModel() : ViewPessoaClienteModel.fromJson(jsonData['viewPessoaClienteModel']);
    viewPessoaFornecedorModel = jsonData['viewPessoaFornecedorModel'] == null ? ViewPessoaFornecedorModel() : ViewPessoaFornecedorModel.fromJson(jsonData['viewPessoaFornecedorModel']);
    setorModel = jsonData['setorModel'] == null ? SetorModel() : SetorModel.fromJson(jsonData['setorModel']);
    contratoTipoServicoModel = jsonData['contratoTipoServicoModel'] == null ? ContratoTipoServicoModel() : ContratoTipoServicoModel.fromJson(jsonData['contratoTipoServicoModel']);
  }

  Map<String, dynamic> get toJson {
    Map<String, dynamic> jsonData = <String, dynamic>{};

    jsonData['id'] = id != 0 ? id : null;
    jsonData['idContratoTipoServico'] = idContratoTipoServico != 0 ? idContratoTipoServico : null;
    jsonData['idSetor'] = idSetor != 0 ? idSetor : null;
    jsonData['idColaborador'] = idColaborador != 0 ? idColaborador : null;
    jsonData['idCliente'] = idCliente != 0 ? idCliente : null;
    jsonData['idFornecedor'] = idFornecedor != 0 ? idFornecedor : null;
    jsonData['dataSolicitacao'] = dataSolicitacao != null ? DateFormat('yyyy-MM-ddT00:00:00').format(dataSolicitacao!) : null;
    jsonData['dataDesejadaInicio'] = dataDesejadaInicio != null ? DateFormat('yyyy-MM-ddT00:00:00').format(dataDesejadaInicio!) : null;
    jsonData['urgente'] = ContratoSolicitacaoServicoDomain.setUrgente(urgente);
    jsonData['statusSolicitacao'] = ContratoSolicitacaoServicoDomain.setStatusSolicitacao(statusSolicitacao);
    jsonData['descricao'] = descricao;
    jsonData['viewPessoaColaboradorModel'] = viewPessoaColaboradorModel?.toJson;
    jsonData['viewPessoaColaborador'] = viewPessoaColaboradorModel?.nome ?? '';
    jsonData['viewPessoaClienteModel'] = viewPessoaClienteModel?.toJson;
    jsonData['viewPessoaCliente'] = viewPessoaClienteModel?.nome ?? '';
    jsonData['viewPessoaFornecedorModel'] = viewPessoaFornecedorModel?.toJson;
    jsonData['viewPessoaFornecedor'] = viewPessoaFornecedorModel?.nome ?? '';
    jsonData['setorModel'] = setorModel?.toJson;
    jsonData['setor'] = setorModel?.nome ?? '';
    jsonData['contratoTipoServicoModel'] = contratoTipoServicoModel?.toJson;
    jsonData['contratoTipoServico'] = contratoTipoServicoModel?.nome ?? '';

    return jsonData;
  }

  String objectEncodeJson() {
    final jsonData = toJson;
    return json.encode(jsonData);
  }

  static ContratoSolicitacaoServicoModel fromPlutoRow(PlutoRow row) {
    return ContratoSolicitacaoServicoModel(
      id: row.cells['id']?.value,
      idContratoTipoServico: row.cells['idContratoTipoServico']?.value,
      idSetor: row.cells['idSetor']?.value,
      idColaborador: row.cells['idColaborador']?.value,
      idCliente: row.cells['idCliente']?.value,
      idFornecedor: row.cells['idFornecedor']?.value,
      dataSolicitacao: Util.stringToDate(row.cells['dataSolicitacao']?.value),
      dataDesejadaInicio: Util.stringToDate(row.cells['dataDesejadaInicio']?.value),
      urgente: row.cells['urgente']?.value,
      statusSolicitacao: row.cells['statusSolicitacao']?.value,
      descricao: row.cells['descricao']?.value,
    );
  }

  PlutoRow toPlutoRow() {
    return PlutoRow(
      cells: {
        'tempId': PlutoCell(value: tempId),
        'id': PlutoCell(value: id ?? 0),
        'idContratoTipoServico': PlutoCell(value: idContratoTipoServico ?? 0),
        'idSetor': PlutoCell(value: idSetor ?? 0),
        'idColaborador': PlutoCell(value: idColaborador ?? 0),
        'idCliente': PlutoCell(value: idCliente ?? 0),
        'idFornecedor': PlutoCell(value: idFornecedor ?? 0),
        'dataSolicitacao': PlutoCell(value: dataSolicitacao),
        'dataDesejadaInicio': PlutoCell(value: dataDesejadaInicio),
        'urgente': PlutoCell(value: urgente ?? ''),
        'statusSolicitacao': PlutoCell(value: statusSolicitacao ?? ''),
        'descricao': PlutoCell(value: descricao ?? ''),
        'viewPessoaColaborador': PlutoCell(value: viewPessoaColaboradorModel?.nome ?? ''),
        'viewPessoaCliente': PlutoCell(value: viewPessoaClienteModel?.nome ?? ''),
        'viewPessoaFornecedor': PlutoCell(value: viewPessoaFornecedorModel?.nome ?? ''),
        'setor': PlutoCell(value: setorModel?.nome ?? ''),
        'contratoTipoServico': PlutoCell(value: contratoTipoServicoModel?.nome ?? ''),
      },
    );
  }

  ContratoSolicitacaoServicoModel clone() {
    return ContratoSolicitacaoServicoModel(
      id: id,
      idContratoTipoServico: idContratoTipoServico,
      idSetor: idSetor,
      idColaborador: idColaborador,
      idCliente: idCliente,
      idFornecedor: idFornecedor,
      dataSolicitacao: dataSolicitacao,
      dataDesejadaInicio: dataDesejadaInicio,
      urgente: urgente,
      statusSolicitacao: statusSolicitacao,
      descricao: descricao,
      viewPessoaColaboradorModel: viewPessoaColaboradorModel?.clone(),
      viewPessoaClienteModel: viewPessoaClienteModel?.clone(),
      viewPessoaFornecedorModel: viewPessoaFornecedorModel?.clone(),
      setorModel: setorModel?.clone(),
      contratoTipoServicoModel: contratoTipoServicoModel?.clone(),
    );
  }


}