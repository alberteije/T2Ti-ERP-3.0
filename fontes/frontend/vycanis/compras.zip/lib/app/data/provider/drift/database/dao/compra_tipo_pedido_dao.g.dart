// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'compra_tipo_pedido_dao.dart';

// ignore_for_file: type=lint
mixin _$CompraTipoPedidoDaoMixin on DatabaseAccessor<AppDatabase> {
  $CompraTipoPedidosTable get compraTipoPedidos =>
      attachedDatabase.compraTipoPedidos;
}
