// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'tribut_grupo_tributario_dao.dart';

// ignore_for_file: type=lint
mixin _$TributGrupoTributarioDaoMixin on DatabaseAccessor<AppDatabase> {
  $TributGrupoTributariosTable get tributGrupoTributarios =>
      attachedDatabase.tributGrupoTributarios;
}
