// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'produto_dao.dart';

// ignore_for_file: type=lint
mixin _$ProdutoDaoMixin on DatabaseAccessor<AppDatabase> {
  $ProdutosTable get produtos => attachedDatabase.produtos;
  $ProdutoMarcasTable get produtoMarcas => attachedDatabase.produtoMarcas;
  $TributIcmsCustomCabsTable get tributIcmsCustomCabs =>
      attachedDatabase.tributIcmsCustomCabs;
  $TributGrupoTributariosTable get tributGrupoTributarios =>
      attachedDatabase.tributGrupoTributarios;
  $ProdutoUnidadesTable get produtoUnidades => attachedDatabase.produtoUnidades;
  $ProdutoSubgruposTable get produtoSubgrupos =>
      attachedDatabase.produtoSubgrupos;
}
