// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'compra_pedido_dao.dart';

// ignore_for_file: type=lint
mixin _$CompraPedidoDaoMixin on DatabaseAccessor<AppDatabase> {
  $CompraPedidosTable get compraPedidos => attachedDatabase.compraPedidos;
  $CompraPedidoDetalhesTable get compraPedidoDetalhes =>
      attachedDatabase.compraPedidoDetalhes;
  $ProdutosTable get produtos => attachedDatabase.produtos;
  $CompraTipoPedidosTable get compraTipoPedidos =>
      attachedDatabase.compraTipoPedidos;
  $ViewPessoaColaboradorsTable get viewPessoaColaboradors =>
      attachedDatabase.viewPessoaColaboradors;
  $ViewPessoaFornecedorsTable get viewPessoaFornecedors =>
      attachedDatabase.viewPessoaFornecedors;
}
