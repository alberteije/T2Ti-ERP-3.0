// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'compra_cotacao_dao.dart';

// ignore_for_file: type=lint
mixin _$CompraCotacaoDaoMixin on DatabaseAccessor<AppDatabase> {
  $CompraCotacaosTable get compraCotacaos => attachedDatabase.compraCotacaos;
  $CompraFornecedorCotacaosTable get compraFornecedorCotacaos =>
      attachedDatabase.compraFornecedorCotacaos;
  $ViewPessoaFornecedorsTable get viewPessoaFornecedors =>
      attachedDatabase.viewPessoaFornecedors;
  $CompraRequisicaosTable get compraRequisicaos =>
      attachedDatabase.compraRequisicaos;
  $CompraCotacaoDetalhesTable get compraCotacaoDetalhes =>
      attachedDatabase.compraCotacaoDetalhes;
  $ProdutosTable get produtos => attachedDatabase.produtos;
}
