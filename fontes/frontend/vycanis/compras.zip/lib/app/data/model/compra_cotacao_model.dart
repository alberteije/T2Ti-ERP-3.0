import 'dart:convert';
import 'package:pluto_grid/pluto_grid.dart';
import 'package:compras/app/data/model/model_imports.dart';

import 'package:compras/app/infra/infra_imports.dart';
import 'package:intl/intl.dart';

class CompraCotacaoModel extends ModelBase {
  int? id;
  int? idCompraRequisicao;
  DateTime? dataCotacao;
  String? descricao;
  List<CompraFornecedorCotacaoModel>? compraFornecedorCotacaoModelList;
  CompraRequisicaoModel? compraRequisicaoModel;
  List<CompraCotacaoDetalheModel>? compraCotacaoDetalheModelList;

  CompraCotacaoModel({
    this.id,
    this.idCompraRequisicao,
    this.dataCotacao,
    this.descricao,
    List<CompraFornecedorCotacaoModel>? compraFornecedorCotacaoModelList,
    CompraRequisicaoModel? compraRequisicaoModel,
    List<CompraCotacaoDetalheModel>? compraCotacaoDetalheModelList,
  }) {
    this.compraFornecedorCotacaoModelList = compraFornecedorCotacaoModelList?.toList(growable: true) ?? [];
    this.compraRequisicaoModel = compraRequisicaoModel ?? CompraRequisicaoModel();
    this.compraCotacaoDetalheModelList = compraCotacaoDetalheModelList?.toList(growable: true) ?? [];
  }

  static List<String> dbColumns = <String>[
    'id',
    'data_cotacao',
    'descricao',
  ];

  static List<String> aliasColumns = <String>[
    'Id',
    'Data Cotacao',
    'Descricao',
  ];

  CompraCotacaoModel.fromJson(Map<String, dynamic> jsonData) {
    id = jsonData['id'];
    idCompraRequisicao = jsonData['idCompraRequisicao'];
    dataCotacao = jsonData['dataCotacao'] != null ? DateTime.tryParse(jsonData['dataCotacao']) : null;
    descricao = jsonData['descricao'];
    compraFornecedorCotacaoModelList = (jsonData['compraFornecedorCotacaoModelList'] as Iterable?)?.map((m) => CompraFornecedorCotacaoModel.fromJson(m)).toList() ?? [];
    compraRequisicaoModel = jsonData['compraRequisicaoModel'] == null ? CompraRequisicaoModel() : CompraRequisicaoModel.fromJson(jsonData['compraRequisicaoModel']);
    compraCotacaoDetalheModelList = (jsonData['compraCotacaoDetalheModelList'] as Iterable?)?.map((m) => CompraCotacaoDetalheModel.fromJson(m)).toList() ?? [];
  }

  Map<String, dynamic> get toJson {
    Map<String, dynamic> jsonData = <String, dynamic>{};

    jsonData['id'] = id != 0 ? id : null;
    jsonData['idCompraRequisicao'] = idCompraRequisicao != 0 ? idCompraRequisicao : null;
    jsonData['dataCotacao'] = dataCotacao != null ? DateFormat('yyyy-MM-ddT00:00:00').format(dataCotacao!) : null;
    jsonData['descricao'] = descricao;
    
		var compraFornecedorCotacaoModelLocalList = []; 
		for (CompraFornecedorCotacaoModel object in compraFornecedorCotacaoModelList ?? []) { 
			compraFornecedorCotacaoModelLocalList.add(object.toJson); 
		}
		jsonData['compraFornecedorCotacaoModelList'] = compraFornecedorCotacaoModelLocalList;
    jsonData['compraRequisicaoModel'] = compraRequisicaoModel?.toJson;
    jsonData['compraRequisicao'] = compraRequisicaoModel?.descricao ?? '';
    
		var compraCotacaoDetalheModelLocalList = []; 
		for (CompraCotacaoDetalheModel object in compraCotacaoDetalheModelList ?? []) { 
			compraCotacaoDetalheModelLocalList.add(object.toJson); 
		}
		jsonData['compraCotacaoDetalheModelList'] = compraCotacaoDetalheModelLocalList;

    return jsonData;
  }

  String objectEncodeJson() {
    final jsonData = toJson;
    return json.encode(jsonData);
  }

  static CompraCotacaoModel fromPlutoRow(PlutoRow row) {
    return CompraCotacaoModel(
      id: row.cells['id']?.value,
      idCompraRequisicao: row.cells['idCompraRequisicao']?.value,
      dataCotacao: Util.stringToDate(row.cells['dataCotacao']?.value),
      descricao: row.cells['descricao']?.value,
    );
  }

  PlutoRow toPlutoRow() {
    return PlutoRow(
      cells: {
        'tempId': PlutoCell(value: tempId),
        'id': PlutoCell(value: id ?? 0),
        'idCompraRequisicao': PlutoCell(value: idCompraRequisicao ?? 0),
        'dataCotacao': PlutoCell(value: dataCotacao),
        'descricao': PlutoCell(value: descricao ?? ''),
        'compraRequisicao': PlutoCell(value: compraRequisicaoModel?.descricao ?? ''),
      },
    );
  }

  CompraCotacaoModel clone() {
    return CompraCotacaoModel(
      id: id,
      idCompraRequisicao: idCompraRequisicao,
      dataCotacao: dataCotacao,
      descricao: descricao,
      compraFornecedorCotacaoModelList: compraFornecedorCotacaoModelListClone(compraFornecedorCotacaoModelList!),
      compraRequisicaoModel: CompraRequisicaoModel.cloneFrom(compraRequisicaoModel),
      compraCotacaoDetalheModelList: compraCotacaoDetalheModelListClone(compraCotacaoDetalheModelList!),
    );
  }

  static CompraCotacaoModel cloneFrom(CompraCotacaoModel? model) {
    return CompraCotacaoModel(
      id: model?.id,
      idCompraRequisicao: model?.idCompraRequisicao,
      dataCotacao: model?.dataCotacao,
      descricao: model?.descricao,
      compraRequisicaoModel: CompraRequisicaoModel.cloneFrom(model?.compraRequisicaoModel),
    );
  }

  compraFornecedorCotacaoModelListClone(List<CompraFornecedorCotacaoModel> compraFornecedorCotacaoModelList) { 
		List<CompraFornecedorCotacaoModel> resultList = [];
		for (var compraFornecedorCotacaoModel in compraFornecedorCotacaoModelList) {
			resultList.add(CompraFornecedorCotacaoModel.cloneFrom(compraFornecedorCotacaoModel));
		}
		return resultList;
	}

  compraCotacaoDetalheModelListClone(List<CompraCotacaoDetalheModel> compraCotacaoDetalheModelList) { 
		List<CompraCotacaoDetalheModel> resultList = [];
		for (var compraCotacaoDetalheModel in compraCotacaoDetalheModelList) {
			resultList.add(CompraCotacaoDetalheModel.cloneFrom(compraCotacaoDetalheModel));
		}
		return resultList;
	}


}