import 'dart:convert';
import 'package:pluto_grid/pluto_grid.dart';
import 'package:compras/app/data/model/model_imports.dart';


class CompraCotacaoDetalheModel extends ModelBase {
  int? id;
  int? idProduto;
  double? quantidade;
  double? valorUnitario;
  double? valorSubtotal;
  double? taxaDesconto;
  double? valorDesconto;
  double? valorTotal;
  int? idCompraCotacao;
  ProdutoModel? produtoModel;

  CompraCotacaoDetalheModel({
    this.id,
    this.idProduto,
    this.quantidade,
    this.valorUnitario,
    this.valorSubtotal,
    this.taxaDesconto,
    this.valorDesconto,
    this.valorTotal,
    this.idCompraCotacao,
    ProdutoModel? produtoModel,
  }) {
    this.produtoModel = produtoModel ?? ProdutoModel();
  }

  static List<String> dbColumns = <String>[
    'id',
    'quantidade',
    'valor_unitario',
    'valor_subtotal',
    'taxa_desconto',
    'valor_desconto',
    'valor_total',
  ];

  static List<String> aliasColumns = <String>[
    'Id',
    'Quantidade',
    'Valor Unitario',
    'Valor Subtotal',
    'Taxa Desconto',
    'Valor Desconto',
    'Valor Total',
  ];

  CompraCotacaoDetalheModel.fromJson(Map<String, dynamic> jsonData) {
    id = jsonData['id'];
    idProduto = jsonData['idProduto'];
    quantidade = jsonData['quantidade']?.toDouble();
    valorUnitario = jsonData['valorUnitario']?.toDouble();
    valorSubtotal = jsonData['valorSubtotal']?.toDouble();
    taxaDesconto = jsonData['taxaDesconto']?.toDouble();
    valorDesconto = jsonData['valorDesconto']?.toDouble();
    valorTotal = jsonData['valorTotal']?.toDouble();
    idCompraCotacao = jsonData['idCompraCotacao'];
    produtoModel = jsonData['produtoModel'] == null ? ProdutoModel() : ProdutoModel.fromJson(jsonData['produtoModel']);
  }

  Map<String, dynamic> get toJson {
    Map<String, dynamic> jsonData = <String, dynamic>{};

    jsonData['id'] = id != 0 ? id : null;
    jsonData['idProduto'] = idProduto != 0 ? idProduto : null;
    jsonData['quantidade'] = quantidade;
    jsonData['valorUnitario'] = valorUnitario;
    jsonData['valorSubtotal'] = valorSubtotal;
    jsonData['taxaDesconto'] = taxaDesconto;
    jsonData['valorDesconto'] = valorDesconto;
    jsonData['valorTotal'] = valorTotal;
    jsonData['idCompraCotacao'] = idCompraCotacao != 0 ? idCompraCotacao : null;
    jsonData['produtoModel'] = produtoModel?.toJson;
    jsonData['produto'] = produtoModel?.nome ?? '';

    return jsonData;
  }

  String objectEncodeJson() {
    final jsonData = toJson;
    return json.encode(jsonData);
  }

  static CompraCotacaoDetalheModel fromPlutoRow(PlutoRow row) {
    return CompraCotacaoDetalheModel(
      id: row.cells['id']?.value,
      idProduto: row.cells['idProduto']?.value,
      quantidade: row.cells['quantidade']?.value,
      valorUnitario: row.cells['valorUnitario']?.value,
      valorSubtotal: row.cells['valorSubtotal']?.value,
      taxaDesconto: row.cells['taxaDesconto']?.value,
      valorDesconto: row.cells['valorDesconto']?.value,
      valorTotal: row.cells['valorTotal']?.value,
      idCompraCotacao: row.cells['idCompraCotacao']?.value,
    );
  }

  PlutoRow toPlutoRow() {
    return PlutoRow(
      cells: {
        'tempId': PlutoCell(value: tempId),
        'id': PlutoCell(value: id ?? 0),
        'idProduto': PlutoCell(value: idProduto ?? 0),
        'quantidade': PlutoCell(value: quantidade ?? 0.0),
        'valorUnitario': PlutoCell(value: valorUnitario ?? 0.0),
        'valorSubtotal': PlutoCell(value: valorSubtotal ?? 0.0),
        'taxaDesconto': PlutoCell(value: taxaDesconto ?? 0.0),
        'valorDesconto': PlutoCell(value: valorDesconto ?? 0.0),
        'valorTotal': PlutoCell(value: valorTotal ?? 0.0),
        'idCompraCotacao': PlutoCell(value: idCompraCotacao ?? 0),
        'produto': PlutoCell(value: produtoModel?.nome ?? ''),
      },
    );
  }

  CompraCotacaoDetalheModel clone() {
    return CompraCotacaoDetalheModel(
      id: id,
      idProduto: idProduto,
      quantidade: quantidade,
      valorUnitario: valorUnitario,
      valorSubtotal: valorSubtotal,
      taxaDesconto: taxaDesconto,
      valorDesconto: valorDesconto,
      valorTotal: valorTotal,
      idCompraCotacao: idCompraCotacao,
      produtoModel: ProdutoModel.cloneFrom(produtoModel),
    );
  }

  static CompraCotacaoDetalheModel cloneFrom(CompraCotacaoDetalheModel? model) {
    return CompraCotacaoDetalheModel(
      id: model?.id,
      idProduto: model?.idProduto,
      quantidade: model?.quantidade,
      valorUnitario: model?.valorUnitario,
      valorSubtotal: model?.valorSubtotal,
      taxaDesconto: model?.taxaDesconto,
      valorDesconto: model?.valorDesconto,
      valorTotal: model?.valorTotal,
      idCompraCotacao: model?.idCompraCotacao,
      produtoModel: ProdutoModel.cloneFrom(model?.produtoModel),
    );
  }


}