import 'dart:convert';
import 'package:pluto_grid/pluto_grid.dart';
import 'package:compras/app/data/model/model_imports.dart';

import 'package:compras/app/data/domain/domain_imports.dart';

class TributIcmsCustomCabModel extends ModelBase {
  int? id;
  String? descricao;
  String? origemMercadoria;

  TributIcmsCustomCabModel({
    this.id,
    this.descricao,
    this.origemMercadoria = 'AAA',
  });

  static List<String> dbColumns = <String>[
    'id',
    'descricao',
    'origem_mercadoria',
  ];

  static List<String> aliasColumns = <String>[
    'Id',
    'Descricao',
    'Origem Mercadoria',
  ];

  TributIcmsCustomCabModel.fromJson(Map<String, dynamic> jsonData) {
    id = jsonData['id'];
    descricao = jsonData['descricao'];
    origemMercadoria = TributIcmsCustomCabDomain.getOrigemMercadoria(jsonData['origemMercadoria']);
  }

  Map<String, dynamic> get toJson {
    Map<String, dynamic> jsonData = <String, dynamic>{};

    jsonData['id'] = id != 0 ? id : null;
    jsonData['descricao'] = descricao;
    jsonData['origemMercadoria'] = TributIcmsCustomCabDomain.setOrigemMercadoria(origemMercadoria);

    return jsonData;
  }

  String objectEncodeJson() {
    final jsonData = toJson;
    return json.encode(jsonData);
  }

  static TributIcmsCustomCabModel fromPlutoRow(PlutoRow row) {
    return TributIcmsCustomCabModel(
      id: row.cells['id']?.value,
      descricao: row.cells['descricao']?.value,
      origemMercadoria: row.cells['origemMercadoria']?.value,
    );
  }

  PlutoRow toPlutoRow() {
    return PlutoRow(
      cells: {
        'tempId': PlutoCell(value: tempId),
        'id': PlutoCell(value: id ?? 0),
        'descricao': PlutoCell(value: descricao ?? ''),
        'origemMercadoria': PlutoCell(value: origemMercadoria ?? ''),
      },
    );
  }

  TributIcmsCustomCabModel clone() {
    return TributIcmsCustomCabModel(
      id: id,
      descricao: descricao,
      origemMercadoria: origemMercadoria,
    );
  }

  static TributIcmsCustomCabModel cloneFrom(TributIcmsCustomCabModel? model) {
    return TributIcmsCustomCabModel(
      id: model?.id,
      descricao: model?.descricao,
      origemMercadoria: model?.origemMercadoria,
    );
  }


}