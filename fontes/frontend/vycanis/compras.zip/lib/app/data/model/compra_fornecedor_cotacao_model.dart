import 'dart:convert';
import 'package:pluto_grid/pluto_grid.dart';
import 'package:compras/app/data/model/model_imports.dart';


class CompraFornecedorCotacaoModel extends ModelBase {
  int? id;
  int? idCompraCotacao;
  int? idFornecedor;
  String? codigo;
  String? prazoEntrega;
  String? vendaCondicoesPagamento;
  double? valorSubtotal;
  double? taxaDesconto;
  double? valorDesconto;
  double? valorTotal;
  ViewPessoaFornecedorModel? viewPessoaFornecedorModel;

  CompraFornecedorCotacaoModel({
    this.id,
    this.idCompraCotacao,
    this.idFornecedor,
    this.codigo,
    this.prazoEntrega,
    this.vendaCondicoesPagamento,
    this.valorSubtotal,
    this.taxaDesconto,
    this.valorDesconto,
    this.valorTotal,
    ViewPessoaFornecedorModel? viewPessoaFornecedorModel,
  }) {
    this.viewPessoaFornecedorModel = viewPessoaFornecedorModel ?? ViewPessoaFornecedorModel();
  }

  static List<String> dbColumns = <String>[
    'id',
    'codigo',
    'prazo_entrega',
    'venda_condicoes_pagamento',
    'valor_subtotal',
    'taxa_desconto',
    'valor_desconto',
    'valor_total',
  ];

  static List<String> aliasColumns = <String>[
    'Id',
    'Codigo',
    'Prazo Entrega',
    'Venda Condicoes Pagamento',
    'Valor Subtotal',
    'Taxa Desconto',
    'Valor Desconto',
    'Valor Total',
  ];

  CompraFornecedorCotacaoModel.fromJson(Map<String, dynamic> jsonData) {
    id = jsonData['id'];
    idCompraCotacao = jsonData['idCompraCotacao'];
    idFornecedor = jsonData['idFornecedor'];
    codigo = jsonData['codigo'];
    prazoEntrega = jsonData['prazoEntrega'];
    vendaCondicoesPagamento = jsonData['vendaCondicoesPagamento'];
    valorSubtotal = jsonData['valorSubtotal']?.toDouble();
    taxaDesconto = jsonData['taxaDesconto']?.toDouble();
    valorDesconto = jsonData['valorDesconto']?.toDouble();
    valorTotal = jsonData['valorTotal']?.toDouble();
    viewPessoaFornecedorModel = jsonData['viewPessoaFornecedorModel'] == null ? ViewPessoaFornecedorModel() : ViewPessoaFornecedorModel.fromJson(jsonData['viewPessoaFornecedorModel']);
  }

  Map<String, dynamic> get toJson {
    Map<String, dynamic> jsonData = <String, dynamic>{};

    jsonData['id'] = id != 0 ? id : null;
    jsonData['idCompraCotacao'] = idCompraCotacao != 0 ? idCompraCotacao : null;
    jsonData['idFornecedor'] = idFornecedor != 0 ? idFornecedor : null;
    jsonData['codigo'] = codigo;
    jsonData['prazoEntrega'] = prazoEntrega;
    jsonData['vendaCondicoesPagamento'] = vendaCondicoesPagamento;
    jsonData['valorSubtotal'] = valorSubtotal;
    jsonData['taxaDesconto'] = taxaDesconto;
    jsonData['valorDesconto'] = valorDesconto;
    jsonData['valorTotal'] = valorTotal;
    jsonData['viewPessoaFornecedorModel'] = viewPessoaFornecedorModel?.toJson;
    jsonData['viewPessoaFornecedor'] = viewPessoaFornecedorModel?.nome ?? '';

    return jsonData;
  }

  String objectEncodeJson() {
    final jsonData = toJson;
    return json.encode(jsonData);
  }

  static CompraFornecedorCotacaoModel fromPlutoRow(PlutoRow row) {
    return CompraFornecedorCotacaoModel(
      id: row.cells['id']?.value,
      idCompraCotacao: row.cells['idCompraCotacao']?.value,
      idFornecedor: row.cells['idFornecedor']?.value,
      codigo: row.cells['codigo']?.value,
      prazoEntrega: row.cells['prazoEntrega']?.value,
      vendaCondicoesPagamento: row.cells['vendaCondicoesPagamento']?.value,
      valorSubtotal: row.cells['valorSubtotal']?.value,
      taxaDesconto: row.cells['taxaDesconto']?.value,
      valorDesconto: row.cells['valorDesconto']?.value,
      valorTotal: row.cells['valorTotal']?.value,
    );
  }

  PlutoRow toPlutoRow() {
    return PlutoRow(
      cells: {
        'tempId': PlutoCell(value: tempId),
        'id': PlutoCell(value: id ?? 0),
        'idCompraCotacao': PlutoCell(value: idCompraCotacao ?? 0),
        'idFornecedor': PlutoCell(value: idFornecedor ?? 0),
        'codigo': PlutoCell(value: codigo ?? ''),
        'prazoEntrega': PlutoCell(value: prazoEntrega ?? ''),
        'vendaCondicoesPagamento': PlutoCell(value: vendaCondicoesPagamento ?? ''),
        'valorSubtotal': PlutoCell(value: valorSubtotal ?? 0.0),
        'taxaDesconto': PlutoCell(value: taxaDesconto ?? 0.0),
        'valorDesconto': PlutoCell(value: valorDesconto ?? 0.0),
        'valorTotal': PlutoCell(value: valorTotal ?? 0.0),
        'viewPessoaFornecedor': PlutoCell(value: viewPessoaFornecedorModel?.nome ?? ''),
      },
    );
  }

  CompraFornecedorCotacaoModel clone() {
    return CompraFornecedorCotacaoModel(
      id: id,
      idCompraCotacao: idCompraCotacao,
      idFornecedor: idFornecedor,
      codigo: codigo,
      prazoEntrega: prazoEntrega,
      vendaCondicoesPagamento: vendaCondicoesPagamento,
      valorSubtotal: valorSubtotal,
      taxaDesconto: taxaDesconto,
      valorDesconto: valorDesconto,
      valorTotal: valorTotal,
      viewPessoaFornecedorModel: ViewPessoaFornecedorModel.cloneFrom(viewPessoaFornecedorModel),
    );
  }

  static CompraFornecedorCotacaoModel cloneFrom(CompraFornecedorCotacaoModel? model) {
    return CompraFornecedorCotacaoModel(
      id: model?.id,
      idCompraCotacao: model?.idCompraCotacao,
      idFornecedor: model?.idFornecedor,
      codigo: model?.codigo,
      prazoEntrega: model?.prazoEntrega,
      vendaCondicoesPagamento: model?.vendaCondicoesPagamento,
      valorSubtotal: model?.valorSubtotal,
      taxaDesconto: model?.taxaDesconto,
      valorDesconto: model?.valorDesconto,
      valorTotal: model?.valorTotal,
      viewPessoaFornecedorModel: ViewPessoaFornecedorModel.cloneFrom(model?.viewPessoaFornecedorModel),
    );
  }


}