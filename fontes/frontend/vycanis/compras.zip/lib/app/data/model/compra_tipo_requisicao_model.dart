import 'dart:convert';
import 'package:pluto_grid/pluto_grid.dart';
import 'package:compras/app/data/model/model_imports.dart';


class CompraTipoRequisicaoModel extends ModelBase {
  int? id;
  String? codigo;
  String? nome;
  String? descricao;

  CompraTipoRequisicaoModel({
    this.id,
    this.codigo,
    this.nome,
    this.descricao,
  });

  static List<String> dbColumns = <String>[
    'id',
    'codigo',
    'nome',
    'descricao',
  ];

  static List<String> aliasColumns = <String>[
    'Id',
    'Codigo',
    'Nome',
    'Descricao',
  ];

  CompraTipoRequisicaoModel.fromJson(Map<String, dynamic> jsonData) {
    id = jsonData['id'];
    codigo = jsonData['codigo'];
    nome = jsonData['nome'];
    descricao = jsonData['descricao'];
  }

  Map<String, dynamic> get toJson {
    Map<String, dynamic> jsonData = <String, dynamic>{};

    jsonData['id'] = id != 0 ? id : null;
    jsonData['codigo'] = codigo;
    jsonData['nome'] = nome;
    jsonData['descricao'] = descricao;

    return jsonData;
  }

  String objectEncodeJson() {
    final jsonData = toJson;
    return json.encode(jsonData);
  }

  static CompraTipoRequisicaoModel fromPlutoRow(PlutoRow row) {
    return CompraTipoRequisicaoModel(
      id: row.cells['id']?.value,
      codigo: row.cells['codigo']?.value,
      nome: row.cells['nome']?.value,
      descricao: row.cells['descricao']?.value,
    );
  }

  PlutoRow toPlutoRow() {
    return PlutoRow(
      cells: {
        'tempId': PlutoCell(value: tempId),
        'id': PlutoCell(value: id ?? 0),
        'codigo': PlutoCell(value: codigo ?? ''),
        'nome': PlutoCell(value: nome ?? ''),
        'descricao': PlutoCell(value: descricao ?? ''),
      },
    );
  }

  CompraTipoRequisicaoModel clone() {
    return CompraTipoRequisicaoModel(
      id: id,
      codigo: codigo,
      nome: nome,
      descricao: descricao,
    );
  }

  static CompraTipoRequisicaoModel cloneFrom(CompraTipoRequisicaoModel? model) {
    return CompraTipoRequisicaoModel(
      id: model?.id,
      codigo: model?.codigo,
      nome: model?.nome,
      descricao: model?.descricao,
    );
  }


}