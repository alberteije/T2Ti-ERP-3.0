import 'dart:convert';
import 'package:pluto_grid/pluto_grid.dart';
import 'package:compras/app/data/model/model_imports.dart';

import 'package:compras/app/infra/infra_imports.dart';
import 'package:intl/intl.dart';

class CompraRequisicaoModel extends ModelBase {
  int? id;
  int? idCompraTipoRequisicao;
  int? idColaborador;
  String? descricao;
  DateTime? dataRequisicao;
  String? observacao;
  List<CompraRequisicaoDetalheModel>? compraRequisicaoDetalheModelList;
  ViewPessoaColaboradorModel? viewPessoaColaboradorModel;
  CompraTipoRequisicaoModel? compraTipoRequisicaoModel;

  CompraRequisicaoModel({
    this.id,
    this.idCompraTipoRequisicao,
    this.idColaborador,
    this.descricao,
    this.dataRequisicao,
    this.observacao,
    List<CompraRequisicaoDetalheModel>? compraRequisicaoDetalheModelList,
    ViewPessoaColaboradorModel? viewPessoaColaboradorModel,
    CompraTipoRequisicaoModel? compraTipoRequisicaoModel,
  }) {
    this.compraRequisicaoDetalheModelList = compraRequisicaoDetalheModelList?.toList(growable: true) ?? [];
    this.viewPessoaColaboradorModel = viewPessoaColaboradorModel ?? ViewPessoaColaboradorModel();
    this.compraTipoRequisicaoModel = compraTipoRequisicaoModel ?? CompraTipoRequisicaoModel();
  }

  static List<String> dbColumns = <String>[
    'id',
    'descricao',
    'data_requisicao',
    'observacao',
  ];

  static List<String> aliasColumns = <String>[
    'Id',
    'Descricao',
    'Data Requisicao',
    'Observacao',
  ];

  CompraRequisicaoModel.fromJson(Map<String, dynamic> jsonData) {
    id = jsonData['id'];
    idCompraTipoRequisicao = jsonData['idCompraTipoRequisicao'];
    idColaborador = jsonData['idColaborador'];
    descricao = jsonData['descricao'];
    dataRequisicao = jsonData['dataRequisicao'] != null ? DateTime.tryParse(jsonData['dataRequisicao']) : null;
    observacao = jsonData['observacao'];
    compraRequisicaoDetalheModelList = (jsonData['compraRequisicaoDetalheModelList'] as Iterable?)?.map((m) => CompraRequisicaoDetalheModel.fromJson(m)).toList() ?? [];
    viewPessoaColaboradorModel = jsonData['viewPessoaColaboradorModel'] == null ? ViewPessoaColaboradorModel() : ViewPessoaColaboradorModel.fromJson(jsonData['viewPessoaColaboradorModel']);
    compraTipoRequisicaoModel = jsonData['compraTipoRequisicaoModel'] == null ? CompraTipoRequisicaoModel() : CompraTipoRequisicaoModel.fromJson(jsonData['compraTipoRequisicaoModel']);
  }

  Map<String, dynamic> get toJson {
    Map<String, dynamic> jsonData = <String, dynamic>{};

    jsonData['id'] = id != 0 ? id : null;
    jsonData['idCompraTipoRequisicao'] = idCompraTipoRequisicao != 0 ? idCompraTipoRequisicao : null;
    jsonData['idColaborador'] = idColaborador != 0 ? idColaborador : null;
    jsonData['descricao'] = descricao;
    jsonData['dataRequisicao'] = dataRequisicao != null ? DateFormat('yyyy-MM-ddT00:00:00').format(dataRequisicao!) : null;
    jsonData['observacao'] = observacao;
    
		var compraRequisicaoDetalheModelLocalList = []; 
		for (CompraRequisicaoDetalheModel object in compraRequisicaoDetalheModelList ?? []) { 
			compraRequisicaoDetalheModelLocalList.add(object.toJson); 
		}
		jsonData['compraRequisicaoDetalheModelList'] = compraRequisicaoDetalheModelLocalList;
    jsonData['viewPessoaColaboradorModel'] = viewPessoaColaboradorModel?.toJson;
    jsonData['viewPessoaColaborador'] = viewPessoaColaboradorModel?.nome ?? '';
    jsonData['compraTipoRequisicaoModel'] = compraTipoRequisicaoModel?.toJson;
    jsonData['compraTipoRequisicao'] = compraTipoRequisicaoModel?.nome ?? '';

    return jsonData;
  }

  String objectEncodeJson() {
    final jsonData = toJson;
    return json.encode(jsonData);
  }

  static CompraRequisicaoModel fromPlutoRow(PlutoRow row) {
    return CompraRequisicaoModel(
      id: row.cells['id']?.value,
      idCompraTipoRequisicao: row.cells['idCompraTipoRequisicao']?.value,
      idColaborador: row.cells['idColaborador']?.value,
      descricao: row.cells['descricao']?.value,
      dataRequisicao: Util.stringToDate(row.cells['dataRequisicao']?.value),
      observacao: row.cells['observacao']?.value,
    );
  }

  PlutoRow toPlutoRow() {
    return PlutoRow(
      cells: {
        'tempId': PlutoCell(value: tempId),
        'id': PlutoCell(value: id ?? 0),
        'idCompraTipoRequisicao': PlutoCell(value: idCompraTipoRequisicao ?? 0),
        'idColaborador': PlutoCell(value: idColaborador ?? 0),
        'descricao': PlutoCell(value: descricao ?? ''),
        'dataRequisicao': PlutoCell(value: dataRequisicao),
        'observacao': PlutoCell(value: observacao ?? ''),
        'viewPessoaColaborador': PlutoCell(value: viewPessoaColaboradorModel?.nome ?? ''),
        'compraTipoRequisicao': PlutoCell(value: compraTipoRequisicaoModel?.nome ?? ''),
      },
    );
  }

  CompraRequisicaoModel clone() {
    return CompraRequisicaoModel(
      id: id,
      idCompraTipoRequisicao: idCompraTipoRequisicao,
      idColaborador: idColaborador,
      descricao: descricao,
      dataRequisicao: dataRequisicao,
      observacao: observacao,
      compraRequisicaoDetalheModelList: compraRequisicaoDetalheModelListClone(compraRequisicaoDetalheModelList!),
      viewPessoaColaboradorModel: ViewPessoaColaboradorModel.cloneFrom(viewPessoaColaboradorModel),
      compraTipoRequisicaoModel: CompraTipoRequisicaoModel.cloneFrom(compraTipoRequisicaoModel),
    );
  }

  static CompraRequisicaoModel cloneFrom(CompraRequisicaoModel? model) {
    return CompraRequisicaoModel(
      id: model?.id,
      idCompraTipoRequisicao: model?.idCompraTipoRequisicao,
      idColaborador: model?.idColaborador,
      descricao: model?.descricao,
      dataRequisicao: model?.dataRequisicao,
      observacao: model?.observacao,
      viewPessoaColaboradorModel: ViewPessoaColaboradorModel.cloneFrom(model?.viewPessoaColaboradorModel),
      compraTipoRequisicaoModel: CompraTipoRequisicaoModel.cloneFrom(model?.compraTipoRequisicaoModel),
    );
  }

  compraRequisicaoDetalheModelListClone(List<CompraRequisicaoDetalheModel> compraRequisicaoDetalheModelList) { 
		List<CompraRequisicaoDetalheModel> resultList = [];
		for (var compraRequisicaoDetalheModel in compraRequisicaoDetalheModelList) {
			resultList.add(CompraRequisicaoDetalheModel.cloneFrom(compraRequisicaoDetalheModel));
		}
		return resultList;
	}


}