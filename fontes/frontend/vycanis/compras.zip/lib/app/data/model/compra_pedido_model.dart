import 'dart:convert';
import 'package:pluto_grid/pluto_grid.dart';
import 'package:compras/app/data/model/model_imports.dart';

import 'package:compras/app/infra/infra_imports.dart';
import 'package:intl/intl.dart';
import 'package:compras/app/data/domain/domain_imports.dart';

class CompraPedidoModel extends ModelBase {
  int? id;
  int? idCompraTipoPedido;
  int? idColaborador;
  int? idFornecedor;
  String? codigoCotacao;
  DateTime? dataPedido;
  DateTime? dataPrevistaEntrega;
  DateTime? dataPrevisaoPagamento;
  String? localEntrega;
  String? localCobranca;
  String? contato;
  double? valorSubtotal;
  double? taxaDesconto;
  double? valorDesconto;
  double? valorTotal;
  String? tipoFrete;
  String? formaPagamento;
  double? baseCalculoIcms;
  double? valorIcms;
  double? baseCalculoIcmsSt;
  double? valorIcmsSt;
  double? valorTotalProdutos;
  double? valorFrete;
  double? valorSeguro;
  double? valorOutrasDespesas;
  double? valorIpi;
  double? valorTotalNf;
  int? quantidadeParcelas;
  String? diaPrimeiroVencimento;
  int? intervaloEntreParcelas;
  String? diaFixoParcela;
  List<CompraPedidoDetalheModel>? compraPedidoDetalheModelList;
  CompraTipoPedidoModel? compraTipoPedidoModel;
  ViewPessoaColaboradorModel? viewPessoaColaboradorModel;
  ViewPessoaFornecedorModel? viewPessoaFornecedorModel;

  CompraPedidoModel({
    this.id,
    this.idCompraTipoPedido,
    this.idColaborador,
    this.idFornecedor,
    this.codigoCotacao,
    this.dataPedido,
    this.dataPrevistaEntrega,
    this.dataPrevisaoPagamento,
    this.localEntrega,
    this.localCobranca,
    this.contato,
    this.valorSubtotal,
    this.taxaDesconto,
    this.valorDesconto,
    this.valorTotal,
    this.tipoFrete = 'CIF',
    this.formaPagamento = 'Vista',
    this.baseCalculoIcms,
    this.valorIcms,
    this.baseCalculoIcmsSt,
    this.valorIcmsSt,
    this.valorTotalProdutos,
    this.valorFrete,
    this.valorSeguro,
    this.valorOutrasDespesas,
    this.valorIpi,
    this.valorTotalNf,
    this.quantidadeParcelas,
    this.diaPrimeiroVencimento,
    this.intervaloEntreParcelas,
    this.diaFixoParcela,
    List<CompraPedidoDetalheModel>? compraPedidoDetalheModelList,
    CompraTipoPedidoModel? compraTipoPedidoModel,
    ViewPessoaColaboradorModel? viewPessoaColaboradorModel,
    ViewPessoaFornecedorModel? viewPessoaFornecedorModel,
  }) {
    this.compraPedidoDetalheModelList = compraPedidoDetalheModelList?.toList(growable: true) ?? [];
    this.compraTipoPedidoModel = compraTipoPedidoModel ?? CompraTipoPedidoModel();
    this.viewPessoaColaboradorModel = viewPessoaColaboradorModel ?? ViewPessoaColaboradorModel();
    this.viewPessoaFornecedorModel = viewPessoaFornecedorModel ?? ViewPessoaFornecedorModel();
  }

  static List<String> dbColumns = <String>[
    'id',
    'codigo_cotacao',
    'data_pedido',
    'data_prevista_entrega',
    'data_previsao_pagamento',
    'local_entrega',
    'local_cobranca',
    'contato',
    'valor_subtotal',
    'taxa_desconto',
    'valor_desconto',
    'valor_total',
    'tipo_frete',
    'forma_pagamento',
    'base_calculo_icms',
    'valor_icms',
    'base_calculo_icms_st',
    'valor_icms_st',
    'valor_total_produtos',
    'valor_frete',
    'valor_seguro',
    'valor_outras_despesas',
    'valor_ipi',
    'valor_total_nf',
    'quantidade_parcelas',
    'dia_primeiro_vencimento',
    'intervalo_entre_parcelas',
    'dia_fixo_parcela',
  ];

  static List<String> aliasColumns = <String>[
    'Id',
    'Codigo Cotacao',
    'Data Pedido',
    'Data Prevista Entrega',
    'Data Previsao Pagamento',
    'Local Entrega',
    'Local Cobranca',
    'Contato',
    'Valor Subtotal',
    'Taxa Desconto',
    'Valor Desconto',
    'Valor Total',
    'Tipo Frete',
    'Forma Pagamento',
    'Base Calculo Icms',
    'Valor Icms',
    'Base Calculo Icms St',
    'Valor Icms St',
    'Valor Total Produtos',
    'Valor Frete',
    'Valor Seguro',
    'Valor Outras Despesas',
    'Valor Ipi',
    'Valor Total Nf',
    'Quantidade Parcelas',
    'Dia Primeiro Vencimento',
    'Intervalo Entre Parcelas',
    'Dia Fixo Parcela',
  ];

  CompraPedidoModel.fromJson(Map<String, dynamic> jsonData) {
    id = jsonData['id'];
    idCompraTipoPedido = jsonData['idCompraTipoPedido'];
    idColaborador = jsonData['idColaborador'];
    idFornecedor = jsonData['idFornecedor'];
    codigoCotacao = jsonData['codigoCotacao'];
    dataPedido = jsonData['dataPedido'] != null ? DateTime.tryParse(jsonData['dataPedido']) : null;
    dataPrevistaEntrega = jsonData['dataPrevistaEntrega'] != null ? DateTime.tryParse(jsonData['dataPrevistaEntrega']) : null;
    dataPrevisaoPagamento = jsonData['dataPrevisaoPagamento'] != null ? DateTime.tryParse(jsonData['dataPrevisaoPagamento']) : null;
    localEntrega = jsonData['localEntrega'];
    localCobranca = jsonData['localCobranca'];
    contato = jsonData['contato'];
    valorSubtotal = jsonData['valorSubtotal']?.toDouble();
    taxaDesconto = jsonData['taxaDesconto']?.toDouble();
    valorDesconto = jsonData['valorDesconto']?.toDouble();
    valorTotal = jsonData['valorTotal']?.toDouble();
    tipoFrete = CompraPedidoDomain.getTipoFrete(jsonData['tipoFrete']);
    formaPagamento = CompraPedidoDomain.getFormaPagamento(jsonData['formaPagamento']);
    baseCalculoIcms = jsonData['baseCalculoIcms']?.toDouble();
    valorIcms = jsonData['valorIcms']?.toDouble();
    baseCalculoIcmsSt = jsonData['baseCalculoIcmsSt']?.toDouble();
    valorIcmsSt = jsonData['valorIcmsSt']?.toDouble();
    valorTotalProdutos = jsonData['valorTotalProdutos']?.toDouble();
    valorFrete = jsonData['valorFrete']?.toDouble();
    valorSeguro = jsonData['valorSeguro']?.toDouble();
    valorOutrasDespesas = jsonData['valorOutrasDespesas']?.toDouble();
    valorIpi = jsonData['valorIpi']?.toDouble();
    valorTotalNf = jsonData['valorTotalNf']?.toDouble();
    quantidadeParcelas = jsonData['quantidadeParcelas'];
    diaPrimeiroVencimento = jsonData['diaPrimeiroVencimento'];
    intervaloEntreParcelas = jsonData['intervaloEntreParcelas'];
    diaFixoParcela = jsonData['diaFixoParcela'];
    compraPedidoDetalheModelList = (jsonData['compraPedidoDetalheModelList'] as Iterable?)?.map((m) => CompraPedidoDetalheModel.fromJson(m)).toList() ?? [];
    compraTipoPedidoModel = jsonData['compraTipoPedidoModel'] == null ? CompraTipoPedidoModel() : CompraTipoPedidoModel.fromJson(jsonData['compraTipoPedidoModel']);
    viewPessoaColaboradorModel = jsonData['viewPessoaColaboradorModel'] == null ? ViewPessoaColaboradorModel() : ViewPessoaColaboradorModel.fromJson(jsonData['viewPessoaColaboradorModel']);
    viewPessoaFornecedorModel = jsonData['viewPessoaFornecedorModel'] == null ? ViewPessoaFornecedorModel() : ViewPessoaFornecedorModel.fromJson(jsonData['viewPessoaFornecedorModel']);
  }

  Map<String, dynamic> get toJson {
    Map<String, dynamic> jsonData = <String, dynamic>{};

    jsonData['id'] = id != 0 ? id : null;
    jsonData['idCompraTipoPedido'] = idCompraTipoPedido != 0 ? idCompraTipoPedido : null;
    jsonData['idColaborador'] = idColaborador != 0 ? idColaborador : null;
    jsonData['idFornecedor'] = idFornecedor != 0 ? idFornecedor : null;
    jsonData['codigoCotacao'] = codigoCotacao;
    jsonData['dataPedido'] = dataPedido != null ? DateFormat('yyyy-MM-ddT00:00:00').format(dataPedido!) : null;
    jsonData['dataPrevistaEntrega'] = dataPrevistaEntrega != null ? DateFormat('yyyy-MM-ddT00:00:00').format(dataPrevistaEntrega!) : null;
    jsonData['dataPrevisaoPagamento'] = dataPrevisaoPagamento != null ? DateFormat('yyyy-MM-ddT00:00:00').format(dataPrevisaoPagamento!) : null;
    jsonData['localEntrega'] = localEntrega;
    jsonData['localCobranca'] = localCobranca;
    jsonData['contato'] = contato;
    jsonData['valorSubtotal'] = valorSubtotal;
    jsonData['taxaDesconto'] = taxaDesconto;
    jsonData['valorDesconto'] = valorDesconto;
    jsonData['valorTotal'] = valorTotal;
    jsonData['tipoFrete'] = CompraPedidoDomain.setTipoFrete(tipoFrete);
    jsonData['formaPagamento'] = CompraPedidoDomain.setFormaPagamento(formaPagamento);
    jsonData['baseCalculoIcms'] = baseCalculoIcms;
    jsonData['valorIcms'] = valorIcms;
    jsonData['baseCalculoIcmsSt'] = baseCalculoIcmsSt;
    jsonData['valorIcmsSt'] = valorIcmsSt;
    jsonData['valorTotalProdutos'] = valorTotalProdutos;
    jsonData['valorFrete'] = valorFrete;
    jsonData['valorSeguro'] = valorSeguro;
    jsonData['valorOutrasDespesas'] = valorOutrasDespesas;
    jsonData['valorIpi'] = valorIpi;
    jsonData['valorTotalNf'] = valorTotalNf;
    jsonData['quantidadeParcelas'] = quantidadeParcelas;
    jsonData['diaPrimeiroVencimento'] = diaPrimeiroVencimento;
    jsonData['intervaloEntreParcelas'] = intervaloEntreParcelas;
    jsonData['diaFixoParcela'] = diaFixoParcela;
    
		var compraPedidoDetalheModelLocalList = []; 
		for (CompraPedidoDetalheModel object in compraPedidoDetalheModelList ?? []) { 
			compraPedidoDetalheModelLocalList.add(object.toJson); 
		}
		jsonData['compraPedidoDetalheModelList'] = compraPedidoDetalheModelLocalList;
    jsonData['compraTipoPedidoModel'] = compraTipoPedidoModel?.toJson;
    jsonData['compraTipoPedido'] = compraTipoPedidoModel?.nome ?? '';
    jsonData['viewPessoaColaboradorModel'] = viewPessoaColaboradorModel?.toJson;
    jsonData['viewPessoaColaborador'] = viewPessoaColaboradorModel?.nome ?? '';
    jsonData['viewPessoaFornecedorModel'] = viewPessoaFornecedorModel?.toJson;
    jsonData['viewPessoaFornecedor'] = viewPessoaFornecedorModel?.nome ?? '';

    return jsonData;
  }

  String objectEncodeJson() {
    final jsonData = toJson;
    return json.encode(jsonData);
  }

  static CompraPedidoModel fromPlutoRow(PlutoRow row) {
    return CompraPedidoModel(
      id: row.cells['id']?.value,
      idCompraTipoPedido: row.cells['idCompraTipoPedido']?.value,
      idColaborador: row.cells['idColaborador']?.value,
      idFornecedor: row.cells['idFornecedor']?.value,
      codigoCotacao: row.cells['codigoCotacao']?.value,
      dataPedido: Util.stringToDate(row.cells['dataPedido']?.value),
      dataPrevistaEntrega: Util.stringToDate(row.cells['dataPrevistaEntrega']?.value),
      dataPrevisaoPagamento: Util.stringToDate(row.cells['dataPrevisaoPagamento']?.value),
      localEntrega: row.cells['localEntrega']?.value,
      localCobranca: row.cells['localCobranca']?.value,
      contato: row.cells['contato']?.value,
      valorSubtotal: row.cells['valorSubtotal']?.value,
      taxaDesconto: row.cells['taxaDesconto']?.value,
      valorDesconto: row.cells['valorDesconto']?.value,
      valorTotal: row.cells['valorTotal']?.value,
      tipoFrete: row.cells['tipoFrete']?.value,
      formaPagamento: row.cells['formaPagamento']?.value,
      baseCalculoIcms: row.cells['baseCalculoIcms']?.value,
      valorIcms: row.cells['valorIcms']?.value,
      baseCalculoIcmsSt: row.cells['baseCalculoIcmsSt']?.value,
      valorIcmsSt: row.cells['valorIcmsSt']?.value,
      valorTotalProdutos: row.cells['valorTotalProdutos']?.value,
      valorFrete: row.cells['valorFrete']?.value,
      valorSeguro: row.cells['valorSeguro']?.value,
      valorOutrasDespesas: row.cells['valorOutrasDespesas']?.value,
      valorIpi: row.cells['valorIpi']?.value,
      valorTotalNf: row.cells['valorTotalNf']?.value,
      quantidadeParcelas: row.cells['quantidadeParcelas']?.value,
      diaPrimeiroVencimento: row.cells['diaPrimeiroVencimento']?.value,
      intervaloEntreParcelas: row.cells['intervaloEntreParcelas']?.value,
      diaFixoParcela: row.cells['diaFixoParcela']?.value,
    );
  }

  PlutoRow toPlutoRow() {
    return PlutoRow(
      cells: {
        'tempId': PlutoCell(value: tempId),
        'id': PlutoCell(value: id ?? 0),
        'idCompraTipoPedido': PlutoCell(value: idCompraTipoPedido ?? 0),
        'idColaborador': PlutoCell(value: idColaborador ?? 0),
        'idFornecedor': PlutoCell(value: idFornecedor ?? 0),
        'codigoCotacao': PlutoCell(value: codigoCotacao ?? ''),
        'dataPedido': PlutoCell(value: dataPedido),
        'dataPrevistaEntrega': PlutoCell(value: dataPrevistaEntrega),
        'dataPrevisaoPagamento': PlutoCell(value: dataPrevisaoPagamento),
        'localEntrega': PlutoCell(value: localEntrega ?? ''),
        'localCobranca': PlutoCell(value: localCobranca ?? ''),
        'contato': PlutoCell(value: contato ?? ''),
        'valorSubtotal': PlutoCell(value: valorSubtotal ?? 0.0),
        'taxaDesconto': PlutoCell(value: taxaDesconto ?? 0.0),
        'valorDesconto': PlutoCell(value: valorDesconto ?? 0.0),
        'valorTotal': PlutoCell(value: valorTotal ?? 0.0),
        'tipoFrete': PlutoCell(value: tipoFrete ?? ''),
        'formaPagamento': PlutoCell(value: formaPagamento ?? ''),
        'baseCalculoIcms': PlutoCell(value: baseCalculoIcms ?? 0.0),
        'valorIcms': PlutoCell(value: valorIcms ?? 0.0),
        'baseCalculoIcmsSt': PlutoCell(value: baseCalculoIcmsSt ?? 0.0),
        'valorIcmsSt': PlutoCell(value: valorIcmsSt ?? 0.0),
        'valorTotalProdutos': PlutoCell(value: valorTotalProdutos ?? 0.0),
        'valorFrete': PlutoCell(value: valorFrete ?? 0.0),
        'valorSeguro': PlutoCell(value: valorSeguro ?? 0.0),
        'valorOutrasDespesas': PlutoCell(value: valorOutrasDespesas ?? 0.0),
        'valorIpi': PlutoCell(value: valorIpi ?? 0.0),
        'valorTotalNf': PlutoCell(value: valorTotalNf ?? 0.0),
        'quantidadeParcelas': PlutoCell(value: quantidadeParcelas ?? 0),
        'diaPrimeiroVencimento': PlutoCell(value: diaPrimeiroVencimento ?? ''),
        'intervaloEntreParcelas': PlutoCell(value: intervaloEntreParcelas ?? 0),
        'diaFixoParcela': PlutoCell(value: diaFixoParcela ?? ''),
        'compraTipoPedido': PlutoCell(value: compraTipoPedidoModel?.nome ?? ''),
        'viewPessoaColaborador': PlutoCell(value: viewPessoaColaboradorModel?.nome ?? ''),
        'viewPessoaFornecedor': PlutoCell(value: viewPessoaFornecedorModel?.nome ?? ''),
      },
    );
  }

  CompraPedidoModel clone() {
    return CompraPedidoModel(
      id: id,
      idCompraTipoPedido: idCompraTipoPedido,
      idColaborador: idColaborador,
      idFornecedor: idFornecedor,
      codigoCotacao: codigoCotacao,
      dataPedido: dataPedido,
      dataPrevistaEntrega: dataPrevistaEntrega,
      dataPrevisaoPagamento: dataPrevisaoPagamento,
      localEntrega: localEntrega,
      localCobranca: localCobranca,
      contato: contato,
      valorSubtotal: valorSubtotal,
      taxaDesconto: taxaDesconto,
      valorDesconto: valorDesconto,
      valorTotal: valorTotal,
      tipoFrete: tipoFrete,
      formaPagamento: formaPagamento,
      baseCalculoIcms: baseCalculoIcms,
      valorIcms: valorIcms,
      baseCalculoIcmsSt: baseCalculoIcmsSt,
      valorIcmsSt: valorIcmsSt,
      valorTotalProdutos: valorTotalProdutos,
      valorFrete: valorFrete,
      valorSeguro: valorSeguro,
      valorOutrasDespesas: valorOutrasDespesas,
      valorIpi: valorIpi,
      valorTotalNf: valorTotalNf,
      quantidadeParcelas: quantidadeParcelas,
      diaPrimeiroVencimento: diaPrimeiroVencimento,
      intervaloEntreParcelas: intervaloEntreParcelas,
      diaFixoParcela: diaFixoParcela,
      compraPedidoDetalheModelList: compraPedidoDetalheModelListClone(compraPedidoDetalheModelList!),
      compraTipoPedidoModel: CompraTipoPedidoModel.cloneFrom(compraTipoPedidoModel),
      viewPessoaColaboradorModel: ViewPessoaColaboradorModel.cloneFrom(viewPessoaColaboradorModel),
      viewPessoaFornecedorModel: ViewPessoaFornecedorModel.cloneFrom(viewPessoaFornecedorModel),
    );
  }

  static CompraPedidoModel cloneFrom(CompraPedidoModel? model) {
    return CompraPedidoModel(
      id: model?.id,
      idCompraTipoPedido: model?.idCompraTipoPedido,
      idColaborador: model?.idColaborador,
      idFornecedor: model?.idFornecedor,
      codigoCotacao: model?.codigoCotacao,
      dataPedido: model?.dataPedido,
      dataPrevistaEntrega: model?.dataPrevistaEntrega,
      dataPrevisaoPagamento: model?.dataPrevisaoPagamento,
      localEntrega: model?.localEntrega,
      localCobranca: model?.localCobranca,
      contato: model?.contato,
      valorSubtotal: model?.valorSubtotal,
      taxaDesconto: model?.taxaDesconto,
      valorDesconto: model?.valorDesconto,
      valorTotal: model?.valorTotal,
      tipoFrete: model?.tipoFrete,
      formaPagamento: model?.formaPagamento,
      baseCalculoIcms: model?.baseCalculoIcms,
      valorIcms: model?.valorIcms,
      baseCalculoIcmsSt: model?.baseCalculoIcmsSt,
      valorIcmsSt: model?.valorIcmsSt,
      valorTotalProdutos: model?.valorTotalProdutos,
      valorFrete: model?.valorFrete,
      valorSeguro: model?.valorSeguro,
      valorOutrasDespesas: model?.valorOutrasDespesas,
      valorIpi: model?.valorIpi,
      valorTotalNf: model?.valorTotalNf,
      quantidadeParcelas: model?.quantidadeParcelas,
      diaPrimeiroVencimento: model?.diaPrimeiroVencimento,
      intervaloEntreParcelas: model?.intervaloEntreParcelas,
      diaFixoParcela: model?.diaFixoParcela,
      compraTipoPedidoModel: CompraTipoPedidoModel.cloneFrom(model?.compraTipoPedidoModel),
      viewPessoaColaboradorModel: ViewPessoaColaboradorModel.cloneFrom(model?.viewPessoaColaboradorModel),
      viewPessoaFornecedorModel: ViewPessoaFornecedorModel.cloneFrom(model?.viewPessoaFornecedorModel),
    );
  }

  compraPedidoDetalheModelListClone(List<CompraPedidoDetalheModel> compraPedidoDetalheModelList) { 
		List<CompraPedidoDetalheModel> resultList = [];
		for (var compraPedidoDetalheModel in compraPedidoDetalheModelList) {
			resultList.add(CompraPedidoDetalheModel.cloneFrom(compraPedidoDetalheModel));
		}
		return resultList;
	}


}