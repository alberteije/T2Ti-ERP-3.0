import 'dart:convert';
import 'package:pluto_grid/pluto_grid.dart';
import 'package:compras/app/data/model/model_imports.dart';


class CompraRequisicaoDetalheModel extends ModelBase {
  int? id;
  int? idCompraRequisicao;
  int? idProduto;
  double? quantidade;
  ProdutoModel? produtoModel;

  CompraRequisicaoDetalheModel({
    this.id,
    this.idCompraRequisicao,
    this.idProduto,
    this.quantidade,
    ProdutoModel? produtoModel,
  }) {
    this.produtoModel = produtoModel ?? ProdutoModel();
  }

  static List<String> dbColumns = <String>[
    'id',
    'quantidade',
  ];

  static List<String> aliasColumns = <String>[
    'Id',
    'Quantidade',
  ];

  CompraRequisicaoDetalheModel.fromJson(Map<String, dynamic> jsonData) {
    id = jsonData['id'];
    idCompraRequisicao = jsonData['idCompraRequisicao'];
    idProduto = jsonData['idProduto'];
    quantidade = jsonData['quantidade']?.toDouble();
    produtoModel = jsonData['produtoModel'] == null ? ProdutoModel() : ProdutoModel.fromJson(jsonData['produtoModel']);
  }

  Map<String, dynamic> get toJson {
    Map<String, dynamic> jsonData = <String, dynamic>{};

    jsonData['id'] = id != 0 ? id : null;
    jsonData['idCompraRequisicao'] = idCompraRequisicao != 0 ? idCompraRequisicao : null;
    jsonData['idProduto'] = idProduto != 0 ? idProduto : null;
    jsonData['quantidade'] = quantidade;
    jsonData['produtoModel'] = produtoModel?.toJson;
    jsonData['produto'] = produtoModel?.nome ?? '';

    return jsonData;
  }

  String objectEncodeJson() {
    final jsonData = toJson;
    return json.encode(jsonData);
  }

  static CompraRequisicaoDetalheModel fromPlutoRow(PlutoRow row) {
    return CompraRequisicaoDetalheModel(
      id: row.cells['id']?.value,
      idCompraRequisicao: row.cells['idCompraRequisicao']?.value,
      idProduto: row.cells['idProduto']?.value,
      quantidade: row.cells['quantidade']?.value,
    );
  }

  PlutoRow toPlutoRow() {
    return PlutoRow(
      cells: {
        'tempId': PlutoCell(value: tempId),
        'id': PlutoCell(value: id ?? 0),
        'idCompraRequisicao': PlutoCell(value: idCompraRequisicao ?? 0),
        'idProduto': PlutoCell(value: idProduto ?? 0),
        'quantidade': PlutoCell(value: quantidade ?? 0.0),
        'produto': PlutoCell(value: produtoModel?.nome ?? ''),
      },
    );
  }

  CompraRequisicaoDetalheModel clone() {
    return CompraRequisicaoDetalheModel(
      id: id,
      idCompraRequisicao: idCompraRequisicao,
      idProduto: idProduto,
      quantidade: quantidade,
      produtoModel: ProdutoModel.cloneFrom(produtoModel),
    );
  }

  static CompraRequisicaoDetalheModel cloneFrom(CompraRequisicaoDetalheModel? model) {
    return CompraRequisicaoDetalheModel(
      id: model?.id,
      idCompraRequisicao: model?.idCompraRequisicao,
      idProduto: model?.idProduto,
      quantidade: model?.quantidade,
      produtoModel: ProdutoModel.cloneFrom(model?.produtoModel),
    );
  }


}