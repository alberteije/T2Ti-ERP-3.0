import 'package:flutter/material.dart';
import 'dart:math';
import 'package:get/get.dart';

import 'package:compras/app/infra/infra_imports.dart';
import 'package:compras/app/page/page_imports.dart';
import 'package:compras/app/page/shared_widget/message_dialog.dart';
import 'package:compras/app/page/grid_columns/grid_columns_imports.dart';
import 'package:compras/app/routes/app_routes.dart';
import 'package:compras/app/controller/controller_imports.dart';
import 'package:compras/app/data/model/model_imports.dart';
import 'package:compras/app/data/repository/compra_cotacao_repository.dart';

class CompraCotacaoController extends ControllerBase<CompraCotacaoModel, CompraCotacaoRepository> 
with GetSingleTickerProviderStateMixin {

  CompraCotacaoController({required super.repository}) {
    dbColumns = CompraCotacaoModel.dbColumns;
    aliasColumns = CompraCotacaoModel.aliasColumns;
    gridColumns = compraCotacaoGridColumns();
    functionName = "compra_cotacao";
    screenTitle = "Cotação";
  }

  final compraCotacaoScaffoldKey = GlobalKey<ScaffoldState>();
  final compraCotacaoTabPageScaffoldKey = GlobalKey<ScaffoldState>();
  final compraCotacaoFormKey = GlobalKey<FormState>();
  late TabController tabController;
  String? mandatoryMessage;  

  @override
  CompraCotacaoModel createNewModel() => CompraCotacaoModel();

  @override
  final standardFieldForFilter = CompraCotacaoModel.aliasColumns[CompraCotacaoModel.dbColumns.indexOf('data_cotacao')];

  final compraRequisicaoModelController = TextEditingController();
  final descricaoController = TextEditingController();

  final Map<String, dynamic> mobileConfig = {
    'primaryColumns': ['data_cotacao'],
    'secondaryColumns': ['descricao'],
  };

  List<Map<String, dynamic>> get mobileItems {
    return modelList.map((compraCotacao) => compraCotacao.toJson).toList();
  }

  @override
  void prepareForInsert() {
    isNewRecord = true;
    currentModel = createNewModel();
    _resetForm();
    tabController.animateTo(0);
    _configureChildrenControllers();
    Get.toNamed(Routes.compraCotacaoTabPage);
  }

  void _resetForm() {
    formWasChanged = false;
    compraRequisicaoModelController.text = '';
    descricaoController.text = '';
  }

  @override
  void selectRowForEditingById(int id) {
    final model = modelList.firstWhere((m) => m.id == id);
    currentModel = model.clone();
    updateControllersFromModel();

    tabController.animateTo(0);
    _configureChildrenControllers();
    Get.toNamed(Routes.compraCotacaoTabPage);
  }

  _configureChildrenControllers() {
    //Fornecedores
		Get.put<CompraFornecedorCotacaoController>(CompraFornecedorCotacaoController()); 
		final compraFornecedorCotacaoController = Get.find<CompraFornecedorCotacaoController>(); 
		compraFornecedorCotacaoController.userMadeChanges = false; 

    //Itens Cotação
		Get.put<CompraCotacaoDetalheController>(CompraCotacaoDetalheController()); 
		final compraCotacaoDetalheController = Get.find<CompraCotacaoDetalheController>(); 
		compraCotacaoDetalheController.userMadeChanges = false; 

  }
  
  void updateControllersFromModel() {
    compraRequisicaoModelController.text = currentModel.compraRequisicaoModel?.descricao?.toString() ?? '';
    descricaoController.text = currentModel.descricao ?? '';
    formWasChanged = false;
  }

  @override
  Future<void> save() async {
    if (!validateCurrentForm()) return;
    if (validateForms()) {
      if (userMadeChanges()) {
        final existingIndex = modelList.indexWhere((m) => m.id == currentModel.id);

        if (existingIndex >= 0) {
          modelList[existingIndex] = currentModel.clone();
        }

        final result = await repository.save(compraCotacaoModel: currentModel);
        if (result == null) return;

        if (existingIndex >= 0) {
          modelList[existingIndex] = result;
        } else {
          modelList.insert(0, result);
        }

        if (!GetPlatform.isMobile) {
          updateGridRow(result);
        }

        Get.back(result: true);
      } else {
        Get.back();
      }
    } 
  }

  Future callCompraRequisicaoLookup() async { 
		final lookupController = Get.find<LookupController>(); 
		lookupController.refreshItems(standardValue: '%'); 
		lookupController.title = '${'lookup_page_title'.tr} [Requisicao]'; 
		lookupController.route = '/compra-requisicao/'; 
		lookupController.gridColumns = compraRequisicaoGridColumns(isForLookup: true); 
		lookupController.aliasColumns = CompraRequisicaoModel.aliasColumns; 
		lookupController.dbColumns = CompraRequisicaoModel.dbColumns; 
		lookupController.standardColumn = CompraRequisicaoModel.aliasColumns[CompraRequisicaoModel.dbColumns.indexOf('descricao')]; 

		final plutoRowResult = await Get.toNamed(Routes.lookupPage); 
		if (plutoRowResult != null) { 
			currentModel.idCompraRequisicao = plutoRowResult.cells['id']!.value; 
			currentModel.compraRequisicaoModel = CompraRequisicaoModel.fromPlutoRow(plutoRowResult); 
			compraRequisicaoModelController.text = currentModel.compraRequisicaoModel?.descricao ?? ''; 
			formWasChanged = true; 
		}
	}


  List<Tab> tabItems = [
    Tab( 
			icon: Icon(iconDataList[Random().nextInt(10)]), 
			text: 'Cotação', 
		),
    Tab( 
			icon: Icon(iconDataList[Random().nextInt(10)]), 
			text: 'Fornecedores', 
		),
    Tab( 
			icon: Icon(iconDataList[Random().nextInt(10)]), 
			text: 'Itens Cotação', 
		),
  ];

  List<Widget> tabPages() {
    return [
      CompraCotacaoEditPage(),
      const CompraFornecedorCotacaoListPage(),
      const CompraCotacaoDetalheListPage(),
    ];
  }

  @override
  void preventDataLoss() {
    if (userMadeChanges()) {
      showQuestionDialog('message_data_loss'.tr, () { 
        Get.back(); 
      });
    } else {
      Get.back();
    }
  }  

  bool userMadeChanges() {
    return
    formWasChanged 
    || 
		Get.find<CompraFornecedorCotacaoController>().userMadeChanges
    || 
		Get.find<CompraCotacaoDetalheController>().userMadeChanges
    ;
  }

  void tabChange(int index) {
    validateCurrentForm();
  }

  bool validateCurrentForm() {
    mandatoryMessage = ValidateFormField.validateMandatory(currentModel.compraRequisicaoModel?.descricao); 
		if (mandatoryMessage != null) { 
			tabController.animateTo(0); 
			showErrorSnackBar(message: '$mandatoryMessage [Requisicao]'); 
			return false; 
		}
    return true;
  }

  bool validateForms() {
    return true;
  }

  @override
  void onInit() {
    super.onInit();
    tabController = TabController(vsync: this, length: tabItems.length);
  }
	
  @override
  void onClose() {
    tabController.dispose();
    compraRequisicaoModelController.dispose();
    descricaoController.dispose();
    super.onClose();
  }	
}