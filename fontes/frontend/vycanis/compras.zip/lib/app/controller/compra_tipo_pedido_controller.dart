import 'package:flutter/material.dart';
import 'package:get/get.dart';

import 'package:compras/app/page/shared_widget/message_dialog.dart';
import 'package:compras/app/page/grid_columns/grid_columns_imports.dart';
import 'package:compras/app/routes/app_routes.dart';
import 'package:compras/app/controller/controller_imports.dart';
import 'package:compras/app/data/model/model_imports.dart';
import 'package:compras/app/data/repository/compra_tipo_pedido_repository.dart';

class CompraTipoPedidoController extends ControllerBase<CompraTipoPedidoModel, CompraTipoPedidoRepository> {

  CompraTipoPedidoController({required super.repository}) {
    dbColumns = CompraTipoPedidoModel.dbColumns;
    aliasColumns = CompraTipoPedidoModel.aliasColumns;
    gridColumns = compraTipoPedidoGridColumns();
    functionName = "compra_tipo_pedido";
    screenTitle = "Tipo Pedido";
  }

  @override
  CompraTipoPedidoModel createNewModel() => CompraTipoPedidoModel();

  @override
  final standardFieldForFilter = CompraTipoPedidoModel.aliasColumns[CompraTipoPedidoModel.dbColumns.indexOf('codigo')];

  final codigoController = TextEditingController();
  final nomeController = TextEditingController();
  final descricaoController = TextEditingController();

  final Map<String, dynamic> mobileConfig = {
    'primaryColumns': ['codigo'],
    'secondaryColumns': ['nome'],
  };

  List<Map<String, dynamic>> get mobileItems {
    return modelList.map((compraTipoPedido) => compraTipoPedido.toJson).toList();
  }

  @override
  void prepareForInsert() {
    isNewRecord = true;
    currentModel = createNewModel();
    _resetForm();
    Get.toNamed(Routes.compraTipoPedidoEditPage);
  }

  void _resetForm() {
    formWasChanged = false;
    codigoController.text = '';
    nomeController.text = '';
    descricaoController.text = '';
  }

  @override
  void selectRowForEditingById(int id) {
    final model = modelList.firstWhere((m) => m.id == id);
    currentModel = model.clone();
    updateControllersFromModel();
    Get.toNamed(Routes.compraTipoPedidoEditPage);
  }

  void updateControllersFromModel() {
    codigoController.text = currentModel.codigo ?? '';
    nomeController.text = currentModel.nome ?? '';
    descricaoController.text = currentModel.descricao ?? '';
    formWasChanged = false;
  }

  @override
  Future<void> save() async {
    if (!formKey.currentState!.validate()) {
      showErrorSnackBar(message: 'validator_form_message'.tr);
      return;
    }

    final existingIndex = modelList.indexWhere((m) => m.id == currentModel.id);

    if (existingIndex >= 0) {
      modelList[existingIndex] = currentModel.clone();
    }

    final result = await repository.save(compraTipoPedidoModel: currentModel);
    if (result == null) return;

    if (existingIndex >= 0) {
      modelList[existingIndex] = result;
    } else {
      modelList.insert(0, result);
    }

    if (!GetPlatform.isMobile) {
      updateGridRow(result);
    }

    Get.back(result: true);
  }


  @override
  void onClose() {
    codigoController.dispose();
    nomeController.dispose();
    descricaoController.dispose();
    super.onClose();
  }

}