import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:pluto_grid/pluto_grid.dart';
import 'package:extended_masked_text/extended_masked_text.dart';
import 'package:compras/app/routes/app_routes.dart';

import 'package:compras/app/page/page_imports.dart';
import 'package:compras/app/page/shared_widget/message_dialog.dart';
import 'package:compras/app/page/grid_columns/grid_columns_imports.dart';
import 'package:compras/app/controller/controller_imports.dart';
import 'package:compras/app/data/model/model_imports.dart';

class CompraFornecedorCotacaoController extends ControllerBase<CompraFornecedorCotacaoModel, void> {

  CompraFornecedorCotacaoController() : super(repository: null) {
    dbColumns = CompraFornecedorCotacaoModel.dbColumns;
    aliasColumns = CompraFornecedorCotacaoModel.aliasColumns;
    gridColumns = compraFornecedorCotacaoGridColumns();
    functionName = "compra_fornecedor_cotacao";
    screenTitle = "Fornecedores";
  }

  final _compraFornecedorCotacaoModel = CompraFornecedorCotacaoModel().obs;
  CompraFornecedorCotacaoModel get compraFornecedorCotacaoModel => _compraFornecedorCotacaoModel.value;
  set compraFornecedorCotacaoModel(value) => _compraFornecedorCotacaoModel.value = value ?? CompraFornecedorCotacaoModel();

  List<CompraFornecedorCotacaoModel> get compraFornecedorCotacaoModelList => Get.find<CompraCotacaoController>().currentModel.compraFornecedorCotacaoModelList ?? [];

  final _userMadeChanges = false.obs;
  get userMadeChanges => _userMadeChanges.value;
  set userMadeChanges(value) => _userMadeChanges.value = value;

  final _formWasChangedDetail = false.obs;
  bool get formWasChangedDetail => _formWasChangedDetail.value;
  set formWasChangedDetail(value) => _formWasChangedDetail.value = value;

  late PlutoGridStateManager _plutoGridStateManager;
  @override
  PlutoGridStateManager get plutoGridStateManager => _plutoGridStateManager;
  @override
  set plutoGridStateManager(value) => _plutoGridStateManager = value;

  final compraFornecedorCotacaoScaffoldKey = GlobalKey<ScaffoldState>();
  final compraFornecedorCotacaoFormKey = GlobalKey<FormState>();

  @override
  CompraFornecedorCotacaoModel createNewModel() => CompraFornecedorCotacaoModel();

  @override
  final standardFieldForFilter = CompraFornecedorCotacaoModel.aliasColumns[CompraFornecedorCotacaoModel.dbColumns.indexOf('codigo')];

  final viewPessoaFornecedorModelController = TextEditingController();
  final codigoController = TextEditingController();
  final prazoEntregaController = TextEditingController();
  final vendaCondicoesPagamentoController = TextEditingController();
  final valorSubtotalController = MoneyMaskedTextController();
  final taxaDescontoController = MoneyMaskedTextController();
  final valorDescontoController = MoneyMaskedTextController();
  final valorTotalController = MoneyMaskedTextController();

  final Map<String, dynamic> mobileConfig = {
    'primaryColumns': ['codigo'],
    'secondaryColumns': ['prazo_entrega'],
  };

  List<Map<String, dynamic>> get mobileItems {
    return modelList.map((compraFornecedorCotacao) => compraFornecedorCotacao.toJson).toList();
  }

  @override
  List<PlutoRow> plutoRows() => List<PlutoRow>.from(compraFornecedorCotacaoModelList.map((model) => model.toPlutoRow()));

  @override
  Future<void> getList({Filter? filter}) async {}

  @override
  void prepareForInsert() {
    isNewRecord = true;
    compraFornecedorCotacaoModel = createNewModel();
    _resetForm();
    Get.to(() => CompraFornecedorCotacaoEditPage());
  }

  void _resetForm() {
    formWasChangedDetail = false;
    viewPessoaFornecedorModelController.text = '';
    codigoController.text = '';
    prazoEntregaController.text = '';
    vendaCondicoesPagamentoController.text = '';
    valorSubtotalController.updateValue(0);
    taxaDescontoController.updateValue(0);
    valorDescontoController.updateValue(0);
    valorTotalController.updateValue(0);
  }

  @override
  void selectRowForEditing(PlutoRow? row) async {
    if (row == null) {
      showInfoSnackBar(message: 'message_select_one_to_edited'.tr);
      return;
    }

    selectRowForEditingByTempId(row.cells['tempId']?.value);
  }

  @override
  void selectRowForEditingById(int id) {}

  void selectRowForEditingByTempId(String tempId) {
		isNewRecord = false;
    final model = compraFornecedorCotacaoModelList.firstWhere((m) => m.tempId == tempId);
    compraFornecedorCotacaoModel = model.clone();
		compraFornecedorCotacaoModel.tempId = model.tempId;
    updateControllersFromModel();
    Get.to(() => CompraFornecedorCotacaoEditPage());
  }

  void updateControllersFromModel() {
    viewPessoaFornecedorModelController.text = compraFornecedorCotacaoModel.viewPessoaFornecedorModel?.nome?.toString() ?? '';
    codigoController.text = compraFornecedorCotacaoModel.codigo ?? '';
    prazoEntregaController.text = compraFornecedorCotacaoModel.prazoEntrega ?? '';
    vendaCondicoesPagamentoController.text = compraFornecedorCotacaoModel.vendaCondicoesPagamento ?? '';
    valorSubtotalController.updateValue(compraFornecedorCotacaoModel.valorSubtotal ?? 0);
    taxaDescontoController.updateValue(compraFornecedorCotacaoModel.taxaDesconto ?? 0);
    valorDescontoController.updateValue(compraFornecedorCotacaoModel.valorDesconto ?? 0);
    valorTotalController.updateValue(compraFornecedorCotacaoModel.valorTotal ?? 0);
    formWasChangedDetail = false;
  }

  @override
  Future<void> save() async {
    if (!compraFornecedorCotacaoFormKey.currentState!.validate()) {
      showErrorSnackBar(message: 'validator_form_message'.tr);
      return;
    }

    if (formWasChangedDetail) {
      if (isNewRecord) {
        compraFornecedorCotacaoModelList.insert(0, compraFornecedorCotacaoModel.clone());
      } else {
        final index = compraFornecedorCotacaoModelList.indexWhere((m) => m.tempId == compraFornecedorCotacaoModel.tempId);
        if (index >= 0) {
          compraFornecedorCotacaoModelList[index] = compraFornecedorCotacaoModel.clone();
        }
      }

      userMadeChanges = true;
      loadData();
      Get.back(result: true);
    } else {
      Get.back();
    }
  }

  Future callViewPessoaFornecedorLookup() async { 
		final lookupController = Get.find<LookupController>(); 
		lookupController.refreshItems(standardValue: '%'); 
		lookupController.title = '${'lookup_page_title'.tr} [Fornecedor]'; 
		lookupController.route = '/view-pessoa-fornecedor/'; 
		lookupController.gridColumns = viewPessoaFornecedorGridColumns(isForLookup: true); 
		lookupController.aliasColumns = ViewPessoaFornecedorModel.aliasColumns; 
		lookupController.dbColumns = ViewPessoaFornecedorModel.dbColumns; 
		lookupController.standardColumn = ViewPessoaFornecedorModel.aliasColumns[ViewPessoaFornecedorModel.dbColumns.indexOf('nome')]; 

		final plutoRowResult = await Get.toNamed(Routes.lookupPage); 
		if (plutoRowResult != null) { 
			compraFornecedorCotacaoModel.idFornecedor = plutoRowResult.cells['id']!.value; 
			compraFornecedorCotacaoModel.viewPessoaFornecedorModel = ViewPessoaFornecedorModel.fromPlutoRow(plutoRowResult); 
			viewPessoaFornecedorModelController.text = compraFornecedorCotacaoModel.viewPessoaFornecedorModel?.nome ?? ''; 
			formWasChanged = true; 
		}
	}


  @override
  Future deleteSelected() async {
    final currentRow = plutoGridStateManager.currentRow;
    if (currentRow == null) {
      showInfoSnackBar(message: 'message_select_one_to_delete'.tr);
      return null;
    }
    showDeleteDialog(() async {
      final id = currentRow.cells['id']?.value;
      final tempId = currentRow.cells['tempId']?.value;
      compraFornecedorCotacaoModelList.removeWhere((model) => (id != 0 && model.id == id) || (id == 0 && model.tempId == tempId));
      plutoGridStateManager.removeCurrentRow();
      userMadeChanges = true;
    });
  }

  @override
  void preventDataLoss() {
    if (formWasChangedDetail) {
      showQuestionDialog('message_data_loss'.tr, () => Get.back());
    } else {
      formWasChangedDetail = false;
      Get.back();
    }
  }

  @override
  void onClose() {
    viewPessoaFornecedorModelController.dispose();
    codigoController.dispose();
    prazoEntregaController.dispose();
    vendaCondicoesPagamentoController.dispose();
    valorSubtotalController.dispose();
    taxaDescontoController.dispose();
    valorDescontoController.dispose();
    valorTotalController.dispose();
  }

}