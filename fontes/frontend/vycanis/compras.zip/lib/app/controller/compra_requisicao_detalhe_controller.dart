import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:pluto_grid/pluto_grid.dart';
import 'package:extended_masked_text/extended_masked_text.dart';
import 'package:compras/app/routes/app_routes.dart';

import 'package:compras/app/page/page_imports.dart';
import 'package:compras/app/page/shared_widget/message_dialog.dart';
import 'package:compras/app/page/grid_columns/grid_columns_imports.dart';
import 'package:compras/app/controller/controller_imports.dart';
import 'package:compras/app/data/model/model_imports.dart';

class CompraRequisicaoDetalheController extends ControllerBase<CompraRequisicaoDetalheModel, void> {

  CompraRequisicaoDetalheController() : super(repository: null) {
    dbColumns = CompraRequisicaoDetalheModel.dbColumns;
    aliasColumns = CompraRequisicaoDetalheModel.aliasColumns;
    gridColumns = compraRequisicaoDetalheGridColumns();
    functionName = "compra_requisicao_detalhe";
    screenTitle = "Itens Requisição";
  }

  final _compraRequisicaoDetalheModel = CompraRequisicaoDetalheModel().obs;
  CompraRequisicaoDetalheModel get compraRequisicaoDetalheModel => _compraRequisicaoDetalheModel.value;
  set compraRequisicaoDetalheModel(value) => _compraRequisicaoDetalheModel.value = value ?? CompraRequisicaoDetalheModel();

  List<CompraRequisicaoDetalheModel> get compraRequisicaoDetalheModelList => Get.find<CompraRequisicaoController>().currentModel.compraRequisicaoDetalheModelList ?? [];

  final _userMadeChanges = false.obs;
  get userMadeChanges => _userMadeChanges.value;
  set userMadeChanges(value) => _userMadeChanges.value = value;

  final _formWasChangedDetail = false.obs;
  bool get formWasChangedDetail => _formWasChangedDetail.value;
  set formWasChangedDetail(value) => _formWasChangedDetail.value = value;

  late PlutoGridStateManager _plutoGridStateManager;
  @override
  PlutoGridStateManager get plutoGridStateManager => _plutoGridStateManager;
  @override
  set plutoGridStateManager(value) => _plutoGridStateManager = value;

  final compraRequisicaoDetalheScaffoldKey = GlobalKey<ScaffoldState>();
  final compraRequisicaoDetalheFormKey = GlobalKey<FormState>();

  @override
  CompraRequisicaoDetalheModel createNewModel() => CompraRequisicaoDetalheModel();

  @override
  final standardFieldForFilter = CompraRequisicaoDetalheModel.aliasColumns[CompraRequisicaoDetalheModel.dbColumns.indexOf('quantidade')];

  final produtoModelController = TextEditingController();
  final quantidadeController = MoneyMaskedTextController();

  final Map<String, dynamic> mobileConfig = {
    'primaryColumns': ['quantidade'],
    'secondaryColumns': [],
  };

  List<Map<String, dynamic>> get mobileItems {
    return modelList.map((compraRequisicaoDetalhe) => compraRequisicaoDetalhe.toJson).toList();
  }

  @override
  List<PlutoRow> plutoRows() => List<PlutoRow>.from(compraRequisicaoDetalheModelList.map((model) => model.toPlutoRow()));

  @override
  Future<void> getList({Filter? filter}) async {}

  @override
  void prepareForInsert() {
    isNewRecord = true;
    compraRequisicaoDetalheModel = createNewModel();
    _resetForm();
    Get.to(() => CompraRequisicaoDetalheEditPage());
  }

  void _resetForm() {
    formWasChangedDetail = false;
    produtoModelController.text = '';
    quantidadeController.updateValue(0);
  }

  @override
  void selectRowForEditing(PlutoRow? row) async {
    if (row == null) {
      showInfoSnackBar(message: 'message_select_one_to_edited'.tr);
      return;
    }

    selectRowForEditingByTempId(row.cells['tempId']?.value);
  }

  @override
  void selectRowForEditingById(int id) {}

  void selectRowForEditingByTempId(String tempId) {
		isNewRecord = false;
    final model = compraRequisicaoDetalheModelList.firstWhere((m) => m.tempId == tempId);
    compraRequisicaoDetalheModel = model.clone();
		compraRequisicaoDetalheModel.tempId = model.tempId;
    updateControllersFromModel();
    Get.to(() => CompraRequisicaoDetalheEditPage());
  }

  void updateControllersFromModel() {
    produtoModelController.text = compraRequisicaoDetalheModel.produtoModel?.nome?.toString() ?? '';
    quantidadeController.updateValue(compraRequisicaoDetalheModel.quantidade ?? 0);
    formWasChangedDetail = false;
  }

  @override
  Future<void> save() async {
    if (!compraRequisicaoDetalheFormKey.currentState!.validate()) {
      showErrorSnackBar(message: 'validator_form_message'.tr);
      return;
    }

    if (formWasChangedDetail) {
      if (isNewRecord) {
        compraRequisicaoDetalheModelList.insert(0, compraRequisicaoDetalheModel.clone());
      } else {
        final index = compraRequisicaoDetalheModelList.indexWhere((m) => m.tempId == compraRequisicaoDetalheModel.tempId);
        if (index >= 0) {
          compraRequisicaoDetalheModelList[index] = compraRequisicaoDetalheModel.clone();
        }
      }

      userMadeChanges = true;
      loadData();
      Get.back(result: true);
    } else {
      Get.back();
    }
  }

  Future callProdutoLookup() async { 
		final lookupController = Get.find<LookupController>(); 
		lookupController.refreshItems(standardValue: '%'); 
		lookupController.title = '${'lookup_page_title'.tr} [Produto]'; 
		lookupController.route = '/produto/'; 
		lookupController.gridColumns = produtoGridColumns(isForLookup: true); 
		lookupController.aliasColumns = ProdutoModel.aliasColumns; 
		lookupController.dbColumns = ProdutoModel.dbColumns; 
		lookupController.standardColumn = ProdutoModel.aliasColumns[ProdutoModel.dbColumns.indexOf('nome')]; 

		final plutoRowResult = await Get.toNamed(Routes.lookupPage); 
		if (plutoRowResult != null) { 
			compraRequisicaoDetalheModel.idProduto = plutoRowResult.cells['id']!.value; 
			compraRequisicaoDetalheModel.produtoModel = ProdutoModel.fromPlutoRow(plutoRowResult); 
			produtoModelController.text = compraRequisicaoDetalheModel.produtoModel?.nome ?? ''; 
			formWasChanged = true; 
		}
	}


  @override
  Future deleteSelected() async {
    final currentRow = plutoGridStateManager.currentRow;
    if (currentRow == null) {
      showInfoSnackBar(message: 'message_select_one_to_delete'.tr);
      return null;
    }
    showDeleteDialog(() async {
      final id = currentRow.cells['id']?.value;
      final tempId = currentRow.cells['tempId']?.value;
      compraRequisicaoDetalheModelList.removeWhere((model) => (id != 0 && model.id == id) || (id == 0 && model.tempId == tempId));
      plutoGridStateManager.removeCurrentRow();
      userMadeChanges = true;
    });
  }

  @override
  void preventDataLoss() {
    if (formWasChangedDetail) {
      showQuestionDialog('message_data_loss'.tr, () => Get.back());
    } else {
      formWasChangedDetail = false;
      Get.back();
    }
  }

  @override
  void onClose() {
    produtoModelController.dispose();
    quantidadeController.dispose();
  }

}