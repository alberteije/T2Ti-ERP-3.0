import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:pluto_grid/pluto_grid.dart';
import 'package:extended_masked_text/extended_masked_text.dart';
import 'package:compras/app/routes/app_routes.dart';

import 'package:compras/app/page/page_imports.dart';
import 'package:compras/app/page/shared_widget/message_dialog.dart';
import 'package:compras/app/page/grid_columns/grid_columns_imports.dart';
import 'package:compras/app/controller/controller_imports.dart';
import 'package:compras/app/data/model/model_imports.dart';

class CompraCotacaoDetalheController extends ControllerBase<CompraCotacaoDetalheModel, void> {

  CompraCotacaoDetalheController() : super(repository: null) {
    dbColumns = CompraCotacaoDetalheModel.dbColumns;
    aliasColumns = CompraCotacaoDetalheModel.aliasColumns;
    gridColumns = compraCotacaoDetalheGridColumns();
    functionName = "compra_cotacao_detalhe";
    screenTitle = "Itens Cotação";
  }

  final _compraCotacaoDetalheModel = CompraCotacaoDetalheModel().obs;
  CompraCotacaoDetalheModel get compraCotacaoDetalheModel => _compraCotacaoDetalheModel.value;
  set compraCotacaoDetalheModel(value) => _compraCotacaoDetalheModel.value = value ?? CompraCotacaoDetalheModel();

  List<CompraCotacaoDetalheModel> get compraCotacaoDetalheModelList => Get.find<CompraCotacaoController>().currentModel.compraCotacaoDetalheModelList ?? [];

  final _userMadeChanges = false.obs;
  get userMadeChanges => _userMadeChanges.value;
  set userMadeChanges(value) => _userMadeChanges.value = value;

  final _formWasChangedDetail = false.obs;
  bool get formWasChangedDetail => _formWasChangedDetail.value;
  set formWasChangedDetail(value) => _formWasChangedDetail.value = value;

  late PlutoGridStateManager _plutoGridStateManager;
  @override
  PlutoGridStateManager get plutoGridStateManager => _plutoGridStateManager;
  @override
  set plutoGridStateManager(value) => _plutoGridStateManager = value;

  final compraCotacaoDetalheScaffoldKey = GlobalKey<ScaffoldState>();
  final compraCotacaoDetalheFormKey = GlobalKey<FormState>();

  @override
  CompraCotacaoDetalheModel createNewModel() => CompraCotacaoDetalheModel();

  @override
  final standardFieldForFilter = CompraCotacaoDetalheModel.aliasColumns[CompraCotacaoDetalheModel.dbColumns.indexOf('quantidade')];

  final produtoModelController = TextEditingController();
  final quantidadeController = MoneyMaskedTextController();
  final valorUnitarioController = MoneyMaskedTextController();
  final valorSubtotalController = MoneyMaskedTextController();
  final taxaDescontoController = MoneyMaskedTextController();
  final valorDescontoController = MoneyMaskedTextController();
  final valorTotalController = MoneyMaskedTextController();

  final Map<String, dynamic> mobileConfig = {
    'primaryColumns': ['quantidade'],
    'secondaryColumns': ['valor_unitario'],
  };

  List<Map<String, dynamic>> get mobileItems {
    return modelList.map((compraCotacaoDetalhe) => compraCotacaoDetalhe.toJson).toList();
  }

  @override
  List<PlutoRow> plutoRows() => List<PlutoRow>.from(compraCotacaoDetalheModelList.map((model) => model.toPlutoRow()));

  @override
  Future<void> getList({Filter? filter}) async {}

  @override
  void prepareForInsert() {
    isNewRecord = true;
    compraCotacaoDetalheModel = createNewModel();
    _resetForm();
    Get.to(() => CompraCotacaoDetalheEditPage());
  }

  void _resetForm() {
    formWasChangedDetail = false;
    produtoModelController.text = '';
    quantidadeController.updateValue(0);
    valorUnitarioController.updateValue(0);
    valorSubtotalController.updateValue(0);
    taxaDescontoController.updateValue(0);
    valorDescontoController.updateValue(0);
    valorTotalController.updateValue(0);
  }

  @override
  void selectRowForEditing(PlutoRow? row) async {
    if (row == null) {
      showInfoSnackBar(message: 'message_select_one_to_edited'.tr);
      return;
    }

    selectRowForEditingByTempId(row.cells['tempId']?.value);
  }

  @override
  void selectRowForEditingById(int id) {}

  void selectRowForEditingByTempId(String tempId) {
		isNewRecord = false;
    final model = compraCotacaoDetalheModelList.firstWhere((m) => m.tempId == tempId);
    compraCotacaoDetalheModel = model.clone();
		compraCotacaoDetalheModel.tempId = model.tempId;
    updateControllersFromModel();
    Get.to(() => CompraCotacaoDetalheEditPage());
  }

  void updateControllersFromModel() {
    produtoModelController.text = compraCotacaoDetalheModel.produtoModel?.nome?.toString() ?? '';
    quantidadeController.updateValue(compraCotacaoDetalheModel.quantidade ?? 0);
    valorUnitarioController.updateValue(compraCotacaoDetalheModel.valorUnitario ?? 0);
    valorSubtotalController.updateValue(compraCotacaoDetalheModel.valorSubtotal ?? 0);
    taxaDescontoController.updateValue(compraCotacaoDetalheModel.taxaDesconto ?? 0);
    valorDescontoController.updateValue(compraCotacaoDetalheModel.valorDesconto ?? 0);
    valorTotalController.updateValue(compraCotacaoDetalheModel.valorTotal ?? 0);
    formWasChangedDetail = false;
  }

  @override
  Future<void> save() async {
    if (!compraCotacaoDetalheFormKey.currentState!.validate()) {
      showErrorSnackBar(message: 'validator_form_message'.tr);
      return;
    }

    if (formWasChangedDetail) {
      if (isNewRecord) {
        compraCotacaoDetalheModelList.insert(0, compraCotacaoDetalheModel.clone());
      } else {
        final index = compraCotacaoDetalheModelList.indexWhere((m) => m.tempId == compraCotacaoDetalheModel.tempId);
        if (index >= 0) {
          compraCotacaoDetalheModelList[index] = compraCotacaoDetalheModel.clone();
        }
      }

      userMadeChanges = true;
      loadData();
      Get.back(result: true);
    } else {
      Get.back();
    }
  }

  Future callProdutoLookup() async { 
		final lookupController = Get.find<LookupController>(); 
		lookupController.refreshItems(standardValue: '%'); 
		lookupController.title = '${'lookup_page_title'.tr} [Produto]'; 
		lookupController.route = '/produto/'; 
		lookupController.gridColumns = produtoGridColumns(isForLookup: true); 
		lookupController.aliasColumns = ProdutoModel.aliasColumns; 
		lookupController.dbColumns = ProdutoModel.dbColumns; 
		lookupController.standardColumn = ProdutoModel.aliasColumns[ProdutoModel.dbColumns.indexOf('nome')]; 

		final plutoRowResult = await Get.toNamed(Routes.lookupPage); 
		if (plutoRowResult != null) { 
			compraCotacaoDetalheModel.idProduto = plutoRowResult.cells['id']!.value; 
			compraCotacaoDetalheModel.produtoModel = ProdutoModel.fromPlutoRow(plutoRowResult); 
			produtoModelController.text = compraCotacaoDetalheModel.produtoModel?.nome ?? ''; 
			formWasChanged = true; 
		}
	}


  @override
  Future deleteSelected() async {
    final currentRow = plutoGridStateManager.currentRow;
    if (currentRow == null) {
      showInfoSnackBar(message: 'message_select_one_to_delete'.tr);
      return null;
    }
    showDeleteDialog(() async {
      final id = currentRow.cells['id']?.value;
      final tempId = currentRow.cells['tempId']?.value;
      compraCotacaoDetalheModelList.removeWhere((model) => (id != 0 && model.id == id) || (id == 0 && model.tempId == tempId));
      plutoGridStateManager.removeCurrentRow();
      userMadeChanges = true;
    });
  }

  @override
  void preventDataLoss() {
    if (formWasChangedDetail) {
      showQuestionDialog('message_data_loss'.tr, () => Get.back());
    } else {
      formWasChangedDetail = false;
      Get.back();
    }
  }

  @override
  void onClose() {
    produtoModelController.dispose();
    quantidadeController.dispose();
    valorUnitarioController.dispose();
    valorSubtotalController.dispose();
    taxaDescontoController.dispose();
    valorDescontoController.dispose();
    valorTotalController.dispose();
  }

}