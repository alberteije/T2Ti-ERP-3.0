import 'package:flutter/material.dart';
import 'dart:math';
import 'package:get/get.dart';
import 'package:extended_masked_text/extended_masked_text.dart';

import 'package:compras/app/infra/infra_imports.dart';
import 'package:compras/app/page/page_imports.dart';
import 'package:compras/app/page/shared_widget/message_dialog.dart';
import 'package:compras/app/page/grid_columns/grid_columns_imports.dart';
import 'package:compras/app/routes/app_routes.dart';
import 'package:compras/app/controller/controller_imports.dart';
import 'package:compras/app/data/model/model_imports.dart';
import 'package:compras/app/data/repository/compra_pedido_repository.dart';

class CompraPedidoController extends ControllerBase<CompraPedidoModel, CompraPedidoRepository> 
with GetSingleTickerProviderStateMixin {

  CompraPedidoController({required super.repository}) {
    dbColumns = CompraPedidoModel.dbColumns;
    aliasColumns = CompraPedidoModel.aliasColumns;
    gridColumns = compraPedidoGridColumns();
    functionName = "compra_pedido";
    screenTitle = "Pedido";
  }

  final compraPedidoScaffoldKey = GlobalKey<ScaffoldState>();
  final compraPedidoTabPageScaffoldKey = GlobalKey<ScaffoldState>();
  final compraPedidoFormKey = GlobalKey<FormState>();
  late TabController tabController;
  String? mandatoryMessage;  

  @override
  CompraPedidoModel createNewModel() => CompraPedidoModel();

  @override
  final standardFieldForFilter = CompraPedidoModel.aliasColumns[CompraPedidoModel.dbColumns.indexOf('codigo_cotacao')];

  final compraTipoPedidoModelController = TextEditingController();
  final viewPessoaColaboradorModelController = TextEditingController();
  final viewPessoaFornecedorModelController = TextEditingController();
  final codigoCotacaoController = TextEditingController();
  final localEntregaController = TextEditingController();
  final localCobrancaController = TextEditingController();
  final contatoController = TextEditingController();
  final valorSubtotalController = MoneyMaskedTextController();
  final taxaDescontoController = MoneyMaskedTextController();
  final valorDescontoController = MoneyMaskedTextController();
  final valorTotalController = MoneyMaskedTextController();
  final baseCalculoIcmsController = MoneyMaskedTextController();
  final valorIcmsController = MoneyMaskedTextController();
  final baseCalculoIcmsStController = MoneyMaskedTextController();
  final valorIcmsStController = MoneyMaskedTextController();
  final valorTotalProdutosController = MoneyMaskedTextController();
  final valorFreteController = MoneyMaskedTextController();
  final valorSeguroController = MoneyMaskedTextController();
  final valorOutrasDespesasController = MoneyMaskedTextController();
  final valorIpiController = MoneyMaskedTextController();
  final valorTotalNfController = MoneyMaskedTextController();
  final quantidadeParcelasController = MoneyMaskedTextController(precision: 0, decimalSeparator: '', thousandSeparator: '');
  final diaPrimeiroVencimentoController = TextEditingController();
  final intervaloEntreParcelasController = MoneyMaskedTextController(precision: 0, decimalSeparator: '', thousandSeparator: '');
  final diaFixoParcelaController = TextEditingController();

  final Map<String, dynamic> mobileConfig = {
    'primaryColumns': ['codigo_cotacao'],
    'secondaryColumns': ['data_pedido'],
  };

  List<Map<String, dynamic>> get mobileItems {
    return modelList.map((compraPedido) => compraPedido.toJson).toList();
  }

  @override
  void prepareForInsert() {
    isNewRecord = true;
    currentModel = createNewModel();
    _resetForm();
    tabController.animateTo(0);
    _configureChildrenControllers();
    Get.toNamed(Routes.compraPedidoTabPage);
  }

  void _resetForm() {
    formWasChanged = false;
    compraTipoPedidoModelController.text = '';
    viewPessoaColaboradorModelController.text = '';
    viewPessoaFornecedorModelController.text = '';
    codigoCotacaoController.text = '';
    localEntregaController.text = '';
    localCobrancaController.text = '';
    contatoController.text = '';
    valorSubtotalController.updateValue(0);
    taxaDescontoController.updateValue(0);
    valorDescontoController.updateValue(0);
    valorTotalController.updateValue(0);
    baseCalculoIcmsController.updateValue(0);
    valorIcmsController.updateValue(0);
    baseCalculoIcmsStController.updateValue(0);
    valorIcmsStController.updateValue(0);
    valorTotalProdutosController.updateValue(0);
    valorFreteController.updateValue(0);
    valorSeguroController.updateValue(0);
    valorOutrasDespesasController.updateValue(0);
    valorIpiController.updateValue(0);
    valorTotalNfController.updateValue(0);
    quantidadeParcelasController.updateValue(0);
    diaPrimeiroVencimentoController.text = '';
    intervaloEntreParcelasController.updateValue(0);
    diaFixoParcelaController.text = '';
  }

  @override
  void selectRowForEditingById(int id) {
    final model = modelList.firstWhere((m) => m.id == id);
    currentModel = model.clone();
    updateControllersFromModel();

    tabController.animateTo(0);
    _configureChildrenControllers();
    Get.toNamed(Routes.compraPedidoTabPage);
  }

  _configureChildrenControllers() {
    //Itens Pedido
		Get.put<CompraPedidoDetalheController>(CompraPedidoDetalheController()); 
		final compraPedidoDetalheController = Get.find<CompraPedidoDetalheController>(); 
		compraPedidoDetalheController.userMadeChanges = false; 

  }
  
  void updateControllersFromModel() {
    compraTipoPedidoModelController.text = currentModel.compraTipoPedidoModel?.nome?.toString() ?? '';
    viewPessoaColaboradorModelController.text = currentModel.viewPessoaColaboradorModel?.nome?.toString() ?? '';
    viewPessoaFornecedorModelController.text = currentModel.viewPessoaFornecedorModel?.nome?.toString() ?? '';
    codigoCotacaoController.text = currentModel.codigoCotacao ?? '';
    localEntregaController.text = currentModel.localEntrega ?? '';
    localCobrancaController.text = currentModel.localCobranca ?? '';
    contatoController.text = currentModel.contato ?? '';
    valorSubtotalController.updateValue(currentModel.valorSubtotal ?? 0);
    taxaDescontoController.updateValue(currentModel.taxaDesconto ?? 0);
    valorDescontoController.updateValue(currentModel.valorDesconto ?? 0);
    valorTotalController.updateValue(currentModel.valorTotal ?? 0);
    baseCalculoIcmsController.updateValue(currentModel.baseCalculoIcms ?? 0);
    valorIcmsController.updateValue(currentModel.valorIcms ?? 0);
    baseCalculoIcmsStController.updateValue(currentModel.baseCalculoIcmsSt ?? 0);
    valorIcmsStController.updateValue(currentModel.valorIcmsSt ?? 0);
    valorTotalProdutosController.updateValue(currentModel.valorTotalProdutos ?? 0);
    valorFreteController.updateValue(currentModel.valorFrete ?? 0);
    valorSeguroController.updateValue(currentModel.valorSeguro ?? 0);
    valorOutrasDespesasController.updateValue(currentModel.valorOutrasDespesas ?? 0);
    valorIpiController.updateValue(currentModel.valorIpi ?? 0);
    valorTotalNfController.updateValue(currentModel.valorTotalNf ?? 0);
    quantidadeParcelasController.updateValue((currentModel.quantidadeParcelas ?? 0).toDouble());
    diaPrimeiroVencimentoController.text = currentModel.diaPrimeiroVencimento ?? '';
    intervaloEntreParcelasController.updateValue((currentModel.intervaloEntreParcelas ?? 0).toDouble());
    diaFixoParcelaController.text = currentModel.diaFixoParcela ?? '';
    formWasChanged = false;
  }

  @override
  Future<void> save() async {
    if (!validateCurrentForm()) return;
    if (validateForms()) {
      if (userMadeChanges()) {
        final existingIndex = modelList.indexWhere((m) => m.id == currentModel.id);

        if (existingIndex >= 0) {
          modelList[existingIndex] = currentModel.clone();
        }

        final result = await repository.save(compraPedidoModel: currentModel);
        if (result == null) return;

        if (existingIndex >= 0) {
          modelList[existingIndex] = result;
        } else {
          modelList.insert(0, result);
        }

        if (!GetPlatform.isMobile) {
          updateGridRow(result);
        }

        Get.back(result: true);
      } else {
        Get.back();
      }
    } 
  }

  Future callCompraTipoPedidoLookup() async { 
		final lookupController = Get.find<LookupController>(); 
		lookupController.refreshItems(standardValue: '%'); 
		lookupController.title = '${'lookup_page_title'.tr} [Tipo Pedido]'; 
		lookupController.route = '/compra-tipo-pedido/'; 
		lookupController.gridColumns = compraTipoPedidoGridColumns(isForLookup: true); 
		lookupController.aliasColumns = CompraTipoPedidoModel.aliasColumns; 
		lookupController.dbColumns = CompraTipoPedidoModel.dbColumns; 
		lookupController.standardColumn = CompraTipoPedidoModel.aliasColumns[CompraTipoPedidoModel.dbColumns.indexOf('nome')]; 

		final plutoRowResult = await Get.toNamed(Routes.lookupPage); 
		if (plutoRowResult != null) { 
			currentModel.idCompraTipoPedido = plutoRowResult.cells['id']!.value; 
			currentModel.compraTipoPedidoModel = CompraTipoPedidoModel.fromPlutoRow(plutoRowResult); 
			compraTipoPedidoModelController.text = currentModel.compraTipoPedidoModel?.nome ?? ''; 
			formWasChanged = true; 
		}
	}

  Future callViewPessoaColaboradorLookup() async { 
		final lookupController = Get.find<LookupController>(); 
		lookupController.refreshItems(standardValue: '%'); 
		lookupController.title = '${'lookup_page_title'.tr} [Colaborador]'; 
		lookupController.route = '/view-pessoa-colaborador/'; 
		lookupController.gridColumns = viewPessoaColaboradorGridColumns(isForLookup: true); 
		lookupController.aliasColumns = ViewPessoaColaboradorModel.aliasColumns; 
		lookupController.dbColumns = ViewPessoaColaboradorModel.dbColumns; 
		lookupController.standardColumn = ViewPessoaColaboradorModel.aliasColumns[ViewPessoaColaboradorModel.dbColumns.indexOf('nome')]; 

		final plutoRowResult = await Get.toNamed(Routes.lookupPage); 
		if (plutoRowResult != null) { 
			currentModel.idColaborador = plutoRowResult.cells['id']!.value; 
			currentModel.viewPessoaColaboradorModel = ViewPessoaColaboradorModel.fromPlutoRow(plutoRowResult); 
			viewPessoaColaboradorModelController.text = currentModel.viewPessoaColaboradorModel?.nome ?? ''; 
			formWasChanged = true; 
		}
	}

  Future callViewPessoaFornecedorLookup() async { 
		final lookupController = Get.find<LookupController>(); 
		lookupController.refreshItems(standardValue: '%'); 
		lookupController.title = '${'lookup_page_title'.tr} [Fornecedor]'; 
		lookupController.route = '/view-pessoa-fornecedor/'; 
		lookupController.gridColumns = viewPessoaFornecedorGridColumns(isForLookup: true); 
		lookupController.aliasColumns = ViewPessoaFornecedorModel.aliasColumns; 
		lookupController.dbColumns = ViewPessoaFornecedorModel.dbColumns; 
		lookupController.standardColumn = ViewPessoaFornecedorModel.aliasColumns[ViewPessoaFornecedorModel.dbColumns.indexOf('nome')]; 

		final plutoRowResult = await Get.toNamed(Routes.lookupPage); 
		if (plutoRowResult != null) { 
			currentModel.idFornecedor = plutoRowResult.cells['id']!.value; 
			currentModel.viewPessoaFornecedorModel = ViewPessoaFornecedorModel.fromPlutoRow(plutoRowResult); 
			viewPessoaFornecedorModelController.text = currentModel.viewPessoaFornecedorModel?.nome ?? ''; 
			formWasChanged = true; 
		}
	}


  List<Tab> tabItems = [
    Tab( 
			icon: Icon(iconDataList[Random().nextInt(10)]), 
			text: 'Pedido', 
		),
    Tab( 
			icon: Icon(iconDataList[Random().nextInt(10)]), 
			text: 'Itens Pedido', 
		),
  ];

  List<Widget> tabPages() {
    return [
      CompraPedidoEditPage(),
      const CompraPedidoDetalheListPage(),
    ];
  }

  @override
  void preventDataLoss() {
    if (userMadeChanges()) {
      showQuestionDialog('message_data_loss'.tr, () { 
        Get.back(); 
      });
    } else {
      Get.back();
    }
  }  

  bool userMadeChanges() {
    return
    formWasChanged 
    || 
		Get.find<CompraPedidoDetalheController>().userMadeChanges
    ;
  }

  void tabChange(int index) {
    validateCurrentForm();
  }

  bool validateCurrentForm() {
    mandatoryMessage = ValidateFormField.validateMandatory(currentModel.compraTipoPedidoModel?.nome); 
		if (mandatoryMessage != null) { 
			tabController.animateTo(0); 
			showErrorSnackBar(message: '$mandatoryMessage [Tipo Pedido]'); 
			return false; 
		}
    mandatoryMessage = ValidateFormField.validateMandatory(currentModel.viewPessoaColaboradorModel?.nome); 
		if (mandatoryMessage != null) { 
			tabController.animateTo(0); 
			showErrorSnackBar(message: '$mandatoryMessage [Colaborador]'); 
			return false; 
		}
    mandatoryMessage = ValidateFormField.validateMandatory(currentModel.viewPessoaFornecedorModel?.nome); 
		if (mandatoryMessage != null) { 
			tabController.animateTo(0); 
			showErrorSnackBar(message: '$mandatoryMessage [Fornecedor]'); 
			return false; 
		}
    return true;
  }

  bool validateForms() {
    return true;
  }

  @override
  void onInit() {
    super.onInit();
    tabController = TabController(vsync: this, length: tabItems.length);
  }
	
  @override
  void onClose() {
    tabController.dispose();
    compraTipoPedidoModelController.dispose();
    viewPessoaColaboradorModelController.dispose();
    viewPessoaFornecedorModelController.dispose();
    codigoCotacaoController.dispose();
    localEntregaController.dispose();
    localCobrancaController.dispose();
    contatoController.dispose();
    valorSubtotalController.dispose();
    taxaDescontoController.dispose();
    valorDescontoController.dispose();
    valorTotalController.dispose();
    baseCalculoIcmsController.dispose();
    valorIcmsController.dispose();
    baseCalculoIcmsStController.dispose();
    valorIcmsStController.dispose();
    valorTotalProdutosController.dispose();
    valorFreteController.dispose();
    valorSeguroController.dispose();
    valorOutrasDespesasController.dispose();
    valorIpiController.dispose();
    valorTotalNfController.dispose();
    quantidadeParcelasController.dispose();
    diaPrimeiroVencimentoController.dispose();
    intervaloEntreParcelasController.dispose();
    diaFixoParcelaController.dispose();
    super.onClose();
  }	
}