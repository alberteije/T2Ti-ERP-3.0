import 'package:flutter/material.dart';
import 'dart:math';
import 'package:get/get.dart';

import 'package:compras/app/infra/infra_imports.dart';
import 'package:compras/app/page/page_imports.dart';
import 'package:compras/app/page/shared_widget/message_dialog.dart';
import 'package:compras/app/page/grid_columns/grid_columns_imports.dart';
import 'package:compras/app/routes/app_routes.dart';
import 'package:compras/app/controller/controller_imports.dart';
import 'package:compras/app/data/model/model_imports.dart';
import 'package:compras/app/data/repository/compra_requisicao_repository.dart';

class CompraRequisicaoController extends ControllerBase<CompraRequisicaoModel, CompraRequisicaoRepository> 
with GetSingleTickerProviderStateMixin {

  CompraRequisicaoController({required super.repository}) {
    dbColumns = CompraRequisicaoModel.dbColumns;
    aliasColumns = CompraRequisicaoModel.aliasColumns;
    gridColumns = compraRequisicaoGridColumns();
    functionName = "compra_requisicao";
    screenTitle = "Requisição";
  }

  final compraRequisicaoScaffoldKey = GlobalKey<ScaffoldState>();
  final compraRequisicaoTabPageScaffoldKey = GlobalKey<ScaffoldState>();
  final compraRequisicaoFormKey = GlobalKey<FormState>();
  late TabController tabController;
  String? mandatoryMessage;  

  @override
  CompraRequisicaoModel createNewModel() => CompraRequisicaoModel();

  @override
  final standardFieldForFilter = CompraRequisicaoModel.aliasColumns[CompraRequisicaoModel.dbColumns.indexOf('descricao')];

  final compraTipoRequisicaoModelController = TextEditingController();
  final viewPessoaColaboradorModelController = TextEditingController();
  final descricaoController = TextEditingController();
  final observacaoController = TextEditingController();

  final Map<String, dynamic> mobileConfig = {
    'primaryColumns': ['descricao'],
    'secondaryColumns': ['data_requisicao'],
  };

  List<Map<String, dynamic>> get mobileItems {
    return modelList.map((compraRequisicao) => compraRequisicao.toJson).toList();
  }

  @override
  void prepareForInsert() {
    isNewRecord = true;
    currentModel = createNewModel();
    _resetForm();
    tabController.animateTo(0);
    _configureChildrenControllers();
    Get.toNamed(Routes.compraRequisicaoTabPage);
  }

  void _resetForm() {
    formWasChanged = false;
    compraTipoRequisicaoModelController.text = '';
    viewPessoaColaboradorModelController.text = '';
    descricaoController.text = '';
    observacaoController.text = '';
  }

  @override
  void selectRowForEditingById(int id) {
    final model = modelList.firstWhere((m) => m.id == id);
    currentModel = model.clone();
    updateControllersFromModel();

    tabController.animateTo(0);
    _configureChildrenControllers();
    Get.toNamed(Routes.compraRequisicaoTabPage);
  }

  _configureChildrenControllers() {
    //Itens Requisição
		Get.put<CompraRequisicaoDetalheController>(CompraRequisicaoDetalheController()); 
		final compraRequisicaoDetalheController = Get.find<CompraRequisicaoDetalheController>(); 
		compraRequisicaoDetalheController.userMadeChanges = false; 

  }
  
  void updateControllersFromModel() {
    compraTipoRequisicaoModelController.text = currentModel.compraTipoRequisicaoModel?.nome?.toString() ?? '';
    viewPessoaColaboradorModelController.text = currentModel.viewPessoaColaboradorModel?.nome?.toString() ?? '';
    descricaoController.text = currentModel.descricao ?? '';
    observacaoController.text = currentModel.observacao ?? '';
    formWasChanged = false;
  }

  @override
  Future<void> save() async {
    if (!validateCurrentForm()) return;
    if (validateForms()) {
      if (userMadeChanges()) {
        final existingIndex = modelList.indexWhere((m) => m.id == currentModel.id);

        if (existingIndex >= 0) {
          modelList[existingIndex] = currentModel.clone();
        }

        final result = await repository.save(compraRequisicaoModel: currentModel);
        if (result == null) return;

        if (existingIndex >= 0) {
          modelList[existingIndex] = result;
        } else {
          modelList.insert(0, result);
        }

        if (!GetPlatform.isMobile) {
          updateGridRow(result);
        }

        Get.back(result: true);
      } else {
        Get.back();
      }
    } 
  }

  Future callCompraTipoRequisicaoLookup() async { 
		final lookupController = Get.find<LookupController>(); 
		lookupController.refreshItems(standardValue: '%'); 
		lookupController.title = '${'lookup_page_title'.tr} [Tipo Requisicao]'; 
		lookupController.route = '/compra-tipo-requisicao/'; 
		lookupController.gridColumns = compraTipoRequisicaoGridColumns(isForLookup: true); 
		lookupController.aliasColumns = CompraTipoRequisicaoModel.aliasColumns; 
		lookupController.dbColumns = CompraTipoRequisicaoModel.dbColumns; 
		lookupController.standardColumn = CompraTipoRequisicaoModel.aliasColumns[CompraTipoRequisicaoModel.dbColumns.indexOf('nome')]; 

		final plutoRowResult = await Get.toNamed(Routes.lookupPage); 
		if (plutoRowResult != null) { 
			currentModel.idCompraTipoRequisicao = plutoRowResult.cells['id']!.value; 
			currentModel.compraTipoRequisicaoModel = CompraTipoRequisicaoModel.fromPlutoRow(plutoRowResult); 
			compraTipoRequisicaoModelController.text = currentModel.compraTipoRequisicaoModel?.nome ?? ''; 
			formWasChanged = true; 
		}
	}

  Future callViewPessoaColaboradorLookup() async { 
		final lookupController = Get.find<LookupController>(); 
		lookupController.refreshItems(standardValue: '%'); 
		lookupController.title = '${'lookup_page_title'.tr} [Colaborador]'; 
		lookupController.route = '/view-pessoa-colaborador/'; 
		lookupController.gridColumns = viewPessoaColaboradorGridColumns(isForLookup: true); 
		lookupController.aliasColumns = ViewPessoaColaboradorModel.aliasColumns; 
		lookupController.dbColumns = ViewPessoaColaboradorModel.dbColumns; 
		lookupController.standardColumn = ViewPessoaColaboradorModel.aliasColumns[ViewPessoaColaboradorModel.dbColumns.indexOf('nome')]; 

		final plutoRowResult = await Get.toNamed(Routes.lookupPage); 
		if (plutoRowResult != null) { 
			currentModel.idColaborador = plutoRowResult.cells['id']!.value; 
			currentModel.viewPessoaColaboradorModel = ViewPessoaColaboradorModel.fromPlutoRow(plutoRowResult); 
			viewPessoaColaboradorModelController.text = currentModel.viewPessoaColaboradorModel?.nome ?? ''; 
			formWasChanged = true; 
		}
	}


  List<Tab> tabItems = [
    Tab( 
			icon: Icon(iconDataList[Random().nextInt(10)]), 
			text: 'Requisição', 
		),
    Tab( 
			icon: Icon(iconDataList[Random().nextInt(10)]), 
			text: 'Itens Requisição', 
		),
  ];

  List<Widget> tabPages() {
    return [
      CompraRequisicaoEditPage(),
      const CompraRequisicaoDetalheListPage(),
    ];
  }

  @override
  void preventDataLoss() {
    if (userMadeChanges()) {
      showQuestionDialog('message_data_loss'.tr, () { 
        Get.back(); 
      });
    } else {
      Get.back();
    }
  }  

  bool userMadeChanges() {
    return
    formWasChanged 
    || 
		Get.find<CompraRequisicaoDetalheController>().userMadeChanges
    ;
  }

  void tabChange(int index) {
    validateCurrentForm();
  }

  bool validateCurrentForm() {
    mandatoryMessage = ValidateFormField.validateMandatory(currentModel.compraTipoRequisicaoModel?.nome); 
		if (mandatoryMessage != null) { 
			tabController.animateTo(0); 
			showErrorSnackBar(message: '$mandatoryMessage [Tipo Requisicao]'); 
			return false; 
		}
    mandatoryMessage = ValidateFormField.validateMandatory(currentModel.viewPessoaColaboradorModel?.nome); 
		if (mandatoryMessage != null) { 
			tabController.animateTo(0); 
			showErrorSnackBar(message: '$mandatoryMessage [Colaborador]'); 
			return false; 
		}
    return true;
  }

  bool validateForms() {
    return true;
  }

  @override
  void onInit() {
    super.onInit();
    tabController = TabController(vsync: this, length: tabItems.length);
  }
	
  @override
  void onClose() {
    tabController.dispose();
    compraTipoRequisicaoModelController.dispose();
    viewPessoaColaboradorModelController.dispose();
    descricaoController.dispose();
    observacaoController.dispose();
    super.onClose();
  }	
}