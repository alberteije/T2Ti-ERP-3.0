import 'package:flutter/material.dart';
import 'package:compras/app/controller/compra_tipo_pedido_controller.dart';
import 'package:compras/app/page/shared_page/list_page_base.dart';

class CompraTipoPedidoListPage extends ListPageBase<CompraTipoPedidoController> {
  const CompraTipoPedidoListPage({Key? key}) : super(key: key);

  @override
  List<Map<String, dynamic>> get mobileItems => controller.mobileItems;

  @override
  Map<String, dynamic> get mobileConfig => controller.mobileConfig;

  @override
  String get standardFieldForFilter => controller.standardFieldForFilter;
}