import 'package:flutter/material.dart';
import 'package:compras/app/controller/compra_tipo_requisicao_controller.dart';
import 'package:compras/app/page/shared_page/list_page_base.dart';

class CompraTipoRequisicaoListPage extends ListPageBase<CompraTipoRequisicaoController> {
  const CompraTipoRequisicaoListPage({Key? key}) : super(key: key);

  @override
  List<Map<String, dynamic>> get mobileItems => controller.mobileItems;

  @override
  Map<String, dynamic> get mobileConfig => controller.mobileConfig;

  @override
  String get standardFieldForFilter => controller.standardFieldForFilter;
}