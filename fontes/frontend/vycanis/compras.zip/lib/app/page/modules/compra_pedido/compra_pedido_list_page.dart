import 'package:flutter/material.dart';
import 'package:compras/app/controller/compra_pedido_controller.dart';
import 'package:compras/app/page/shared_page/list_page_base.dart';

class CompraPedidoListPage extends ListPageBase<CompraPedidoController> {
  const CompraPedidoListPage({Key? key}) : super(key: key);

  @override
  List<Map<String, dynamic>> get mobileItems => controller.mobileItems;

  @override
  Map<String, dynamic> get mobileConfig => controller.mobileConfig;

  @override
  String get standardFieldForFilter => controller.standardFieldForFilter;
}