import 'package:flutter/material.dart';
import 'package:get/get.dart';

import 'package:ordem_servico/app/page/shared_widget/message_dialog.dart';
import 'package:ordem_servico/app/page/grid_columns/grid_columns_imports.dart';
import 'package:ordem_servico/app/routes/app_routes.dart';
import 'package:ordem_servico/app/controller/controller_imports.dart';
import 'package:ordem_servico/app/data/model/model_imports.dart';
import 'package:ordem_servico/app/data/repository/os_equipamento_repository.dart';

class OsEquipamentoController extends ControllerBase<OsEquipamentoModel, OsEquipamentoRepository> {

  OsEquipamentoController({required super.repository}) {
    dbColumns = OsEquipamentoModel.dbColumns;
    aliasColumns = OsEquipamentoModel.aliasColumns;
    gridColumns = osEquipamentoGridColumns();
    functionName = "os_equipamento";
    screenTitle = "Equipamentos";
  }

  @override
  OsEquipamentoModel createNewModel() => OsEquipamentoModel();

  @override
  final standardFieldForFilter = OsEquipamentoModel.aliasColumns[OsEquipamentoModel.dbColumns.indexOf('nome')];

  final nomeController = TextEditingController();
  final descricaoController = TextEditingController();

  final Map<String, dynamic> mobileConfig = {
    'primaryColumns': ['nome'],
    'secondaryColumns': ['descricao'],
  };

  List<Map<String, dynamic>> get mobileItems {
    return modelList.map((osEquipamento) => osEquipamento.toJson).toList();
  }

  @override
  void prepareForInsert() {
    isNewRecord = true;
    currentModel = createNewModel();
    _resetForm();
    Get.toNamed(Routes.osEquipamentoEditPage);
  }

  void _resetForm() {
    formWasChanged = false;
    nomeController.text = '';
    descricaoController.text = '';
  }

  @override
  void selectRowForEditingById(int id) {
    final model = modelList.firstWhere((m) => m.id == id);
    currentModel = model.clone();
    updateControllersFromModel();
    Get.toNamed(Routes.osEquipamentoEditPage);
  }

  void updateControllersFromModel() {
    nomeController.text = currentModel.nome ?? '';
    descricaoController.text = currentModel.descricao ?? '';
    formWasChanged = false;
  }

  @override
  Future<void> save() async {
    if (!formKey.currentState!.validate()) {
      showErrorSnackBar(message: 'validator_form_message'.tr);
      return;
    }

    final existingIndex = modelList.indexWhere((m) => m.id == currentModel.id);

    if (existingIndex >= 0) {
      modelList[existingIndex] = currentModel.clone();
    }

    final result = await repository.save(osEquipamentoModel: currentModel);
    if (result == null) return;

    if (existingIndex >= 0) {
      modelList[existingIndex] = result;
    } else {
      modelList.insert(0, result);
    }

    if (!GetPlatform.isMobile) {
      updateGridRow(result);
    }

    Get.back(result: true);
  }


  @override
  void onClose() {
    nomeController.dispose();
    descricaoController.dispose();
    super.onClose();
  }

}