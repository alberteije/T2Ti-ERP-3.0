import 'package:flutter/material.dart';
import 'dart:math';
import 'package:get/get.dart';
import 'package:extended_masked_text/extended_masked_text.dart';

import 'package:ordem_servico/app/infra/infra_imports.dart';
import 'package:ordem_servico/app/page/page_imports.dart';
import 'package:ordem_servico/app/page/shared_widget/message_dialog.dart';
import 'package:ordem_servico/app/page/grid_columns/grid_columns_imports.dart';
import 'package:ordem_servico/app/routes/app_routes.dart';
import 'package:ordem_servico/app/controller/controller_imports.dart';
import 'package:ordem_servico/app/data/model/model_imports.dart';
import 'package:ordem_servico/app/data/repository/os_abertura_repository.dart';

class OsAberturaController extends ControllerBase<OsAberturaModel, OsAberturaRepository> 
with GetSingleTickerProviderStateMixin {

  OsAberturaController({required super.repository}) {
    dbColumns = OsAberturaModel.dbColumns;
    aliasColumns = OsAberturaModel.aliasColumns;
    gridColumns = osAberturaGridColumns();
    functionName = "os_abertura";
    screenTitle = "Abertura OS";
  }

  final osAberturaScaffoldKey = GlobalKey<ScaffoldState>();
  final osAberturaTabPageScaffoldKey = GlobalKey<ScaffoldState>();
  final osAberturaFormKey = GlobalKey<FormState>();
  late TabController tabController;
  String? mandatoryMessage;  

  @override
  OsAberturaModel createNewModel() => OsAberturaModel();

  @override
  final standardFieldForFilter = OsAberturaModel.aliasColumns[OsAberturaModel.dbColumns.indexOf('numero')];

  final osStatusModelController = TextEditingController();
  final viewPessoaColaboradorModelController = TextEditingController();
  final viewPessoaClienteModelController = TextEditingController();
  final numeroController = TextEditingController();
  final horaInicioController = TextEditingController();
  final horaPrevisaoController = MaskedTextController(mask: '00:00:00',);
  final horaFimController = MaskedTextController(mask: '00:00:00',);
  final nomeContatoController = TextEditingController();
  final foneContatoController = MaskedTextController(mask: '(00)00000-0000',);
  final observacaoClienteController = TextEditingController();
  final observacaoAberturaController = TextEditingController();

  final Map<String, dynamic> mobileConfig = {
    'primaryColumns': ['numero'],
    'secondaryColumns': ['data_inicio'],
  };

  List<Map<String, dynamic>> get mobileItems {
    return modelList.map((osAbertura) => osAbertura.toJson).toList();
  }

  @override
  void prepareForInsert() {
    isNewRecord = true;
    currentModel = createNewModel();
    _resetForm();
    tabController.animateTo(0);
    _configureChildrenControllers();
    Get.toNamed(Routes.osAberturaTabPage);
  }

  void _resetForm() {
    formWasChanged = false;
    osStatusModelController.text = '';
    viewPessoaColaboradorModelController.text = '';
    viewPessoaClienteModelController.text = '';
    numeroController.text = '';
    horaInicioController.text = '';
    horaPrevisaoController.text = '';
    horaFimController.text = '';
    nomeContatoController.text = '';
    foneContatoController.text = '';
    observacaoClienteController.text = '';
    observacaoAberturaController.text = '';
  }

  @override
  void selectRowForEditingById(int id) {
    final model = modelList.firstWhere((m) => m.id == id);
    currentModel = model.clone();
    updateControllersFromModel();

    tabController.animateTo(0);
    _configureChildrenControllers();
    Get.toNamed(Routes.osAberturaTabPage);
  }

  _configureChildrenControllers() {
    //Equipamentos
		Get.put<OsAberturaEquipamentoController>(OsAberturaEquipamentoController()); 
		final osAberturaEquipamentoController = Get.find<OsAberturaEquipamentoController>(); 
		osAberturaEquipamentoController.userMadeChanges = false; 

    //Produto ou Serviço
		Get.put<OsProdutoServicoController>(OsProdutoServicoController()); 
		final osProdutoServicoController = Get.find<OsProdutoServicoController>(); 
		osProdutoServicoController.userMadeChanges = false; 

    //Evolução
		Get.put<OsEvolucaoController>(OsEvolucaoController()); 
		final osEvolucaoController = Get.find<OsEvolucaoController>(); 
		osEvolucaoController.userMadeChanges = false; 

  }
  
  void updateControllersFromModel() {
    osStatusModelController.text = currentModel.osStatusModel?.nome?.toString() ?? '';
    viewPessoaColaboradorModelController.text = currentModel.viewPessoaColaboradorModel?.nome?.toString() ?? '';
    viewPessoaClienteModelController.text = currentModel.viewPessoaClienteModel?.nome?.toString() ?? '';
    numeroController.text = currentModel.numero ?? '';
    horaInicioController.text = currentModel.horaInicio ?? '';
    horaPrevisaoController.text = currentModel.horaPrevisao ?? '';
    horaFimController.text = currentModel.horaFim ?? '';
    nomeContatoController.text = currentModel.nomeContato ?? '';
    foneContatoController.text = currentModel.foneContato ?? '';
    observacaoClienteController.text = currentModel.observacaoCliente ?? '';
    observacaoAberturaController.text = currentModel.observacaoAbertura ?? '';
    formWasChanged = false;
  }

  @override
  Future<void> save() async {
    if (!validateCurrentForm()) return;
    if (validateForms()) {
      if (userMadeChanges()) {
        final existingIndex = modelList.indexWhere((m) => m.id == currentModel.id);

        if (existingIndex >= 0) {
          modelList[existingIndex] = currentModel.clone();
        }

        final result = await repository.save(osAberturaModel: currentModel);
        if (result == null) return;

        if (existingIndex >= 0) {
          modelList[existingIndex] = result;
        } else {
          modelList.insert(0, result);
        }

        if (!GetPlatform.isMobile) {
          updateGridRow(result);
        }

        Get.back(result: true);
      } else {
        Get.back();
      }
    } 
  }

  Future callOsStatusLookup() async { 
		final lookupController = Get.find<LookupController>(); 
		lookupController.refreshItems(standardValue: '%'); 
		lookupController.title = '${'lookup_page_title'.tr} [Status]'; 
		lookupController.route = '/os-status/'; 
		lookupController.gridColumns = osStatusGridColumns(isForLookup: true); 
		lookupController.aliasColumns = OsStatusModel.aliasColumns; 
		lookupController.dbColumns = OsStatusModel.dbColumns; 
		lookupController.standardColumn = OsStatusModel.aliasColumns[OsStatusModel.dbColumns.indexOf('nome')]; 

		final plutoRowResult = await Get.toNamed(Routes.lookupPage); 
		if (plutoRowResult != null) { 
			currentModel.idOsStatus = plutoRowResult.cells['id']!.value; 
			currentModel.osStatusModel = OsStatusModel.fromPlutoRow(plutoRowResult); 
			osStatusModelController.text = currentModel.osStatusModel?.nome ?? ''; 
			formWasChanged = true; 
		}
	}

  Future callViewPessoaColaboradorLookup() async { 
		final lookupController = Get.find<LookupController>(); 
		lookupController.refreshItems(standardValue: '%'); 
		lookupController.title = '${'lookup_page_title'.tr} [Colaborador]'; 
		lookupController.route = '/view-pessoa-colaborador/'; 
		lookupController.gridColumns = viewPessoaColaboradorGridColumns(isForLookup: true); 
		lookupController.aliasColumns = ViewPessoaColaboradorModel.aliasColumns; 
		lookupController.dbColumns = ViewPessoaColaboradorModel.dbColumns; 
		lookupController.standardColumn = ViewPessoaColaboradorModel.aliasColumns[ViewPessoaColaboradorModel.dbColumns.indexOf('nome')]; 

		final plutoRowResult = await Get.toNamed(Routes.lookupPage); 
		if (plutoRowResult != null) { 
			currentModel.idColaborador = plutoRowResult.cells['id']!.value; 
			currentModel.viewPessoaColaboradorModel = ViewPessoaColaboradorModel.fromPlutoRow(plutoRowResult); 
			viewPessoaColaboradorModelController.text = currentModel.viewPessoaColaboradorModel?.nome ?? ''; 
			formWasChanged = true; 
		}
	}

  Future callViewPessoaClienteLookup() async { 
		final lookupController = Get.find<LookupController>(); 
		lookupController.refreshItems(standardValue: '%'); 
		lookupController.title = '${'lookup_page_title'.tr} [Cliente]'; 
		lookupController.route = '/view-pessoa-cliente/'; 
		lookupController.gridColumns = viewPessoaClienteGridColumns(isForLookup: true); 
		lookupController.aliasColumns = ViewPessoaClienteModel.aliasColumns; 
		lookupController.dbColumns = ViewPessoaClienteModel.dbColumns; 
		lookupController.standardColumn = ViewPessoaClienteModel.aliasColumns[ViewPessoaClienteModel.dbColumns.indexOf('nome')]; 

		final plutoRowResult = await Get.toNamed(Routes.lookupPage); 
		if (plutoRowResult != null) { 
			currentModel.idCliente = plutoRowResult.cells['id']!.value; 
			currentModel.viewPessoaClienteModel = ViewPessoaClienteModel.fromPlutoRow(plutoRowResult); 
			viewPessoaClienteModelController.text = currentModel.viewPessoaClienteModel?.nome ?? ''; 
			formWasChanged = true; 
		}
	}


  List<Tab> tabItems = [
    Tab( 
			icon: Icon(iconDataList[Random().nextInt(10)]), 
			text: 'Abertura OS', 
		),
    Tab( 
			icon: Icon(iconDataList[Random().nextInt(10)]), 
			text: 'Equipamentos', 
		),
    Tab( 
			icon: Icon(iconDataList[Random().nextInt(10)]), 
			text: 'Produto ou Serviço', 
		),
    Tab( 
			icon: Icon(iconDataList[Random().nextInt(10)]), 
			text: 'Evolução', 
		),
  ];

  List<Widget> tabPages() {
    return [
      OsAberturaEditPage(),
      const OsAberturaEquipamentoListPage(),
      const OsProdutoServicoListPage(),
      const OsEvolucaoListPage(),
    ];
  }

  @override
  void preventDataLoss() {
    if (userMadeChanges()) {
      showQuestionDialog('message_data_loss'.tr, () { 
        Get.back(); 
      });
    } else {
      Get.back();
    }
  }  

  bool userMadeChanges() {
    return
    formWasChanged 
    || 
		Get.find<OsAberturaEquipamentoController>().userMadeChanges
    || 
		Get.find<OsProdutoServicoController>().userMadeChanges
    || 
		Get.find<OsEvolucaoController>().userMadeChanges
    ;
  }

  void tabChange(int index) {
    validateCurrentForm();
  }

  bool validateCurrentForm() {
    mandatoryMessage = ValidateFormField.validateMandatory(currentModel.osStatusModel?.nome); 
		if (mandatoryMessage != null) { 
			tabController.animateTo(0); 
			showErrorSnackBar(message: '$mandatoryMessage [Status]'); 
			return false; 
		}
    mandatoryMessage = ValidateFormField.validateMandatory(currentModel.viewPessoaColaboradorModel?.nome); 
		if (mandatoryMessage != null) { 
			tabController.animateTo(0); 
			showErrorSnackBar(message: '$mandatoryMessage [Colaborador]'); 
			return false; 
		}
    mandatoryMessage = ValidateFormField.validateMandatory(currentModel.viewPessoaClienteModel?.nome); 
		if (mandatoryMessage != null) { 
			tabController.animateTo(0); 
			showErrorSnackBar(message: '$mandatoryMessage [Cliente]'); 
			return false; 
		}
    return true;
  }

  bool validateForms() {
    return true;
  }

  @override
  void onInit() {
    super.onInit();
    tabController = TabController(vsync: this, length: tabItems.length);
  }
	
  @override
  void onClose() {
    tabController.dispose();
    osStatusModelController.dispose();
    viewPessoaColaboradorModelController.dispose();
    viewPessoaClienteModelController.dispose();
    numeroController.dispose();
    horaInicioController.dispose();
    horaPrevisaoController.dispose();
    horaFimController.dispose();
    nomeContatoController.dispose();
    foneContatoController.dispose();
    observacaoClienteController.dispose();
    observacaoAberturaController.dispose();
    super.onClose();
  }	
}