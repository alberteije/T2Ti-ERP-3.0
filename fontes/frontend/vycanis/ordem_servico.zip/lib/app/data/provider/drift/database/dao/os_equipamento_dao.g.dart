// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'os_equipamento_dao.dart';

// ignore_for_file: type=lint
mixin _$OsEquipamentoDaoMixin on DatabaseAccessor<AppDatabase> {
  $OsEquipamentosTable get osEquipamentos => attachedDatabase.osEquipamentos;
}
