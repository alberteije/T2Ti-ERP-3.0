// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'os_abertura_dao.dart';

// ignore_for_file: type=lint
mixin _$OsAberturaDaoMixin on DatabaseAccessor<AppDatabase> {
  $OsAberturasTable get osAberturas => attachedDatabase.osAberturas;
  $OsAberturaEquipamentosTable get osAberturaEquipamentos =>
      attachedDatabase.osAberturaEquipamentos;
  $OsEquipamentosTable get osEquipamentos => attachedDatabase.osEquipamentos;
  $OsProdutoServicosTable get osProdutoServicos =>
      attachedDatabase.osProdutoServicos;
  $ProdutosTable get produtos => attachedDatabase.produtos;
  $OsEvolucaosTable get osEvolucaos => attachedDatabase.osEvolucaos;
  $ViewPessoaClientesTable get viewPessoaClientes =>
      attachedDatabase.viewPessoaClientes;
  $ViewPessoaColaboradorsTable get viewPessoaColaboradors =>
      attachedDatabase.viewPessoaColaboradors;
  $OsStatussTable get osStatuss => attachedDatabase.osStatuss;
}
