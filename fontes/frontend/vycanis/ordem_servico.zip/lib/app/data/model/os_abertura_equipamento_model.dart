import 'dart:convert';
import 'package:pluto_grid/pluto_grid.dart';
import 'package:ordem_servico/app/data/model/model_imports.dart';

import 'package:ordem_servico/app/data/domain/domain_imports.dart';

class OsAberturaEquipamentoModel extends ModelBase {
  int? id;
  int? idOsAbertura;
  int? idOsEquipamento;
  String? tipoCobertura;
  String? numeroSerie;
  OsEquipamentoModel? osEquipamentoModel;

  OsAberturaEquipamentoModel({
    this.id,
    this.idOsAbertura,
    this.idOsEquipamento,
    this.tipoCobertura = 'Nenhum',
    this.numeroSerie,
    OsEquipamentoModel? osEquipamentoModel,
  }) {
    this.osEquipamentoModel = osEquipamentoModel ?? OsEquipamentoModel();
  }

  static List<String> dbColumns = <String>[
    'id',
    'tipo_cobertura',
    'numero_serie',
  ];

  static List<String> aliasColumns = <String>[
    'Id',
    'Tipo Cobertura',
    'Numero Serie',
  ];

  OsAberturaEquipamentoModel.fromJson(Map<String, dynamic> jsonData) {
    id = jsonData['id'];
    idOsAbertura = jsonData['idOsAbertura'];
    idOsEquipamento = jsonData['idOsEquipamento'];
    tipoCobertura = OsAberturaEquipamentoDomain.getTipoCobertura(jsonData['tipoCobertura']);
    numeroSerie = jsonData['numeroSerie'];
    osEquipamentoModel = jsonData['osEquipamentoModel'] == null ? OsEquipamentoModel() : OsEquipamentoModel.fromJson(jsonData['osEquipamentoModel']);
  }

  Map<String, dynamic> get toJson {
    Map<String, dynamic> jsonData = <String, dynamic>{};

    jsonData['id'] = id != 0 ? id : null;
    jsonData['idOsAbertura'] = idOsAbertura != 0 ? idOsAbertura : null;
    jsonData['idOsEquipamento'] = idOsEquipamento != 0 ? idOsEquipamento : null;
    jsonData['tipoCobertura'] = OsAberturaEquipamentoDomain.setTipoCobertura(tipoCobertura);
    jsonData['numeroSerie'] = numeroSerie;
    jsonData['osEquipamentoModel'] = osEquipamentoModel?.toJson;
    jsonData['osEquipamento'] = osEquipamentoModel?.nome ?? '';

    return jsonData;
  }

  String objectEncodeJson() {
    final jsonData = toJson;
    return json.encode(jsonData);
  }

  static OsAberturaEquipamentoModel fromPlutoRow(PlutoRow row) {
    return OsAberturaEquipamentoModel(
      id: row.cells['id']?.value,
      idOsAbertura: row.cells['idOsAbertura']?.value,
      idOsEquipamento: row.cells['idOsEquipamento']?.value,
      tipoCobertura: row.cells['tipoCobertura']?.value,
      numeroSerie: row.cells['numeroSerie']?.value,
    );
  }

  PlutoRow toPlutoRow() {
    return PlutoRow(
      cells: {
        'tempId': PlutoCell(value: tempId),
        'id': PlutoCell(value: id ?? 0),
        'idOsAbertura': PlutoCell(value: idOsAbertura ?? 0),
        'idOsEquipamento': PlutoCell(value: idOsEquipamento ?? 0),
        'tipoCobertura': PlutoCell(value: tipoCobertura ?? ''),
        'numeroSerie': PlutoCell(value: numeroSerie ?? ''),
        'osEquipamento': PlutoCell(value: osEquipamentoModel?.nome ?? ''),
      },
    );
  }

  OsAberturaEquipamentoModel clone() {
    return OsAberturaEquipamentoModel(
      id: id,
      idOsAbertura: idOsAbertura,
      idOsEquipamento: idOsEquipamento,
      tipoCobertura: tipoCobertura,
      numeroSerie: numeroSerie,
      osEquipamentoModel: OsEquipamentoModel.cloneFrom(osEquipamentoModel),
    );
  }

  static OsAberturaEquipamentoModel cloneFrom(OsAberturaEquipamentoModel? model) {
    return OsAberturaEquipamentoModel(
      id: model?.id,
      idOsAbertura: model?.idOsAbertura,
      idOsEquipamento: model?.idOsEquipamento,
      tipoCobertura: model?.tipoCobertura,
      numeroSerie: model?.numeroSerie,
      osEquipamentoModel: OsEquipamentoModel.cloneFrom(model?.osEquipamentoModel),
    );
  }


}