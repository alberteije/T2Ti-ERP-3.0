import 'dart:convert';
import 'package:pluto_grid/pluto_grid.dart';
import 'package:ordem_servico/app/data/model/model_imports.dart';

import 'package:ordem_servico/app/infra/infra_imports.dart';
import 'package:intl/intl.dart';

class OsAberturaModel extends ModelBase {
  int? id;
  int? idOsStatus;
  int? idColaborador;
  int? idCliente;
  String? numero;
  DateTime? dataInicio;
  String? horaInicio;
  DateTime? dataPrevisao;
  String? horaPrevisao;
  DateTime? dataFim;
  String? horaFim;
  String? nomeContato;
  String? foneContato;
  String? observacaoCliente;
  String? observacaoAbertura;
  List<OsAberturaEquipamentoModel>? osAberturaEquipamentoModelList;
  List<OsProdutoServicoModel>? osProdutoServicoModelList;
  List<OsEvolucaoModel>? osEvolucaoModelList;
  ViewPessoaClienteModel? viewPessoaClienteModel;
  ViewPessoaColaboradorModel? viewPessoaColaboradorModel;
  OsStatusModel? osStatusModel;

  OsAberturaModel({
    this.id,
    this.idOsStatus,
    this.idColaborador,
    this.idCliente,
    this.numero,
    this.dataInicio,
    this.horaInicio,
    this.dataPrevisao,
    this.horaPrevisao,
    this.dataFim,
    this.horaFim,
    this.nomeContato,
    this.foneContato,
    this.observacaoCliente,
    this.observacaoAbertura,
    List<OsAberturaEquipamentoModel>? osAberturaEquipamentoModelList,
    List<OsProdutoServicoModel>? osProdutoServicoModelList,
    List<OsEvolucaoModel>? osEvolucaoModelList,
    ViewPessoaClienteModel? viewPessoaClienteModel,
    ViewPessoaColaboradorModel? viewPessoaColaboradorModel,
    OsStatusModel? osStatusModel,
  }) {
    this.osAberturaEquipamentoModelList = osAberturaEquipamentoModelList?.toList(growable: true) ?? [];
    this.osProdutoServicoModelList = osProdutoServicoModelList?.toList(growable: true) ?? [];
    this.osEvolucaoModelList = osEvolucaoModelList?.toList(growable: true) ?? [];
    this.viewPessoaClienteModel = viewPessoaClienteModel ?? ViewPessoaClienteModel();
    this.viewPessoaColaboradorModel = viewPessoaColaboradorModel ?? ViewPessoaColaboradorModel();
    this.osStatusModel = osStatusModel ?? OsStatusModel();
  }

  static List<String> dbColumns = <String>[
    'id',
    'numero',
    'data_inicio',
    'hora_inicio',
    'data_previsao',
    'hora_previsao',
    'data_fim',
    'hora_fim',
    'nome_contato',
    'fone_contato',
    'observacao_cliente',
    'observacao_abertura',
  ];

  static List<String> aliasColumns = <String>[
    'Id',
    'Numero',
    'Data Inicio',
    'Hora Inicio',
    'Data Previsao',
    'Hora Previsao',
    'Data Fim',
    'Hora Fim',
    'Nome Contato',
    'Fone Contato',
    'Observacao Cliente',
    'Observacao Abertura',
  ];

  OsAberturaModel.fromJson(Map<String, dynamic> jsonData) {
    id = jsonData['id'];
    idOsStatus = jsonData['idOsStatus'];
    idColaborador = jsonData['idColaborador'];
    idCliente = jsonData['idCliente'];
    numero = jsonData['numero'];
    dataInicio = jsonData['dataInicio'] != null ? DateTime.tryParse(jsonData['dataInicio']) : null;
    horaInicio = jsonData['horaInicio'];
    dataPrevisao = jsonData['dataPrevisao'] != null ? DateTime.tryParse(jsonData['dataPrevisao']) : null;
    horaPrevisao = jsonData['horaPrevisao'];
    dataFim = jsonData['dataFim'] != null ? DateTime.tryParse(jsonData['dataFim']) : null;
    horaFim = jsonData['horaFim'];
    nomeContato = jsonData['nomeContato'];
    foneContato = jsonData['foneContato'];
    observacaoCliente = jsonData['observacaoCliente'];
    observacaoAbertura = jsonData['observacaoAbertura'];
    osAberturaEquipamentoModelList = (jsonData['osAberturaEquipamentoModelList'] as Iterable?)?.map((m) => OsAberturaEquipamentoModel.fromJson(m)).toList() ?? [];
    osProdutoServicoModelList = (jsonData['osProdutoServicoModelList'] as Iterable?)?.map((m) => OsProdutoServicoModel.fromJson(m)).toList() ?? [];
    osEvolucaoModelList = (jsonData['osEvolucaoModelList'] as Iterable?)?.map((m) => OsEvolucaoModel.fromJson(m)).toList() ?? [];
    viewPessoaClienteModel = jsonData['viewPessoaClienteModel'] == null ? ViewPessoaClienteModel() : ViewPessoaClienteModel.fromJson(jsonData['viewPessoaClienteModel']);
    viewPessoaColaboradorModel = jsonData['viewPessoaColaboradorModel'] == null ? ViewPessoaColaboradorModel() : ViewPessoaColaboradorModel.fromJson(jsonData['viewPessoaColaboradorModel']);
    osStatusModel = jsonData['osStatusModel'] == null ? OsStatusModel() : OsStatusModel.fromJson(jsonData['osStatusModel']);
  }

  Map<String, dynamic> get toJson {
    Map<String, dynamic> jsonData = <String, dynamic>{};

    jsonData['id'] = id != 0 ? id : null;
    jsonData['idOsStatus'] = idOsStatus != 0 ? idOsStatus : null;
    jsonData['idColaborador'] = idColaborador != 0 ? idColaborador : null;
    jsonData['idCliente'] = idCliente != 0 ? idCliente : null;
    jsonData['numero'] = numero;
    jsonData['dataInicio'] = dataInicio != null ? DateFormat('yyyy-MM-ddT00:00:00').format(dataInicio!) : null;
    jsonData['horaInicio'] = horaInicio;
    jsonData['dataPrevisao'] = dataPrevisao != null ? DateFormat('yyyy-MM-ddT00:00:00').format(dataPrevisao!) : null;
    jsonData['horaPrevisao'] = Util.removeMask(horaPrevisao);
    jsonData['dataFim'] = dataFim != null ? DateFormat('yyyy-MM-ddT00:00:00').format(dataFim!) : null;
    jsonData['horaFim'] = Util.removeMask(horaFim);
    jsonData['nomeContato'] = nomeContato;
    jsonData['foneContato'] = Util.removeMask(foneContato);
    jsonData['observacaoCliente'] = observacaoCliente;
    jsonData['observacaoAbertura'] = observacaoAbertura;
    
		var osAberturaEquipamentoModelLocalList = []; 
		for (OsAberturaEquipamentoModel object in osAberturaEquipamentoModelList ?? []) { 
			osAberturaEquipamentoModelLocalList.add(object.toJson); 
		}
		jsonData['osAberturaEquipamentoModelList'] = osAberturaEquipamentoModelLocalList;
    
		var osProdutoServicoModelLocalList = []; 
		for (OsProdutoServicoModel object in osProdutoServicoModelList ?? []) { 
			osProdutoServicoModelLocalList.add(object.toJson); 
		}
		jsonData['osProdutoServicoModelList'] = osProdutoServicoModelLocalList;
    
		var osEvolucaoModelLocalList = []; 
		for (OsEvolucaoModel object in osEvolucaoModelList ?? []) { 
			osEvolucaoModelLocalList.add(object.toJson); 
		}
		jsonData['osEvolucaoModelList'] = osEvolucaoModelLocalList;
    jsonData['viewPessoaClienteModel'] = viewPessoaClienteModel?.toJson;
    jsonData['viewPessoaCliente'] = viewPessoaClienteModel?.nome ?? '';
    jsonData['viewPessoaColaboradorModel'] = viewPessoaColaboradorModel?.toJson;
    jsonData['viewPessoaColaborador'] = viewPessoaColaboradorModel?.nome ?? '';
    jsonData['osStatusModel'] = osStatusModel?.toJson;
    jsonData['osStatus'] = osStatusModel?.nome ?? '';

    return jsonData;
  }

  String objectEncodeJson() {
    final jsonData = toJson;
    return json.encode(jsonData);
  }

  static OsAberturaModel fromPlutoRow(PlutoRow row) {
    return OsAberturaModel(
      id: row.cells['id']?.value,
      idOsStatus: row.cells['idOsStatus']?.value,
      idColaborador: row.cells['idColaborador']?.value,
      idCliente: row.cells['idCliente']?.value,
      numero: row.cells['numero']?.value,
      dataInicio: Util.stringToDate(row.cells['dataInicio']?.value),
      horaInicio: row.cells['horaInicio']?.value,
      dataPrevisao: Util.stringToDate(row.cells['dataPrevisao']?.value),
      horaPrevisao: row.cells['horaPrevisao']?.value,
      dataFim: Util.stringToDate(row.cells['dataFim']?.value),
      horaFim: row.cells['horaFim']?.value,
      nomeContato: row.cells['nomeContato']?.value,
      foneContato: row.cells['foneContato']?.value,
      observacaoCliente: row.cells['observacaoCliente']?.value,
      observacaoAbertura: row.cells['observacaoAbertura']?.value,
    );
  }

  PlutoRow toPlutoRow() {
    return PlutoRow(
      cells: {
        'tempId': PlutoCell(value: tempId),
        'id': PlutoCell(value: id ?? 0),
        'idOsStatus': PlutoCell(value: idOsStatus ?? 0),
        'idColaborador': PlutoCell(value: idColaborador ?? 0),
        'idCliente': PlutoCell(value: idCliente ?? 0),
        'numero': PlutoCell(value: numero ?? ''),
        'dataInicio': PlutoCell(value: dataInicio),
        'horaInicio': PlutoCell(value: horaInicio ?? ''),
        'dataPrevisao': PlutoCell(value: dataPrevisao),
        'horaPrevisao': PlutoCell(value: horaPrevisao ?? ''),
        'dataFim': PlutoCell(value: dataFim),
        'horaFim': PlutoCell(value: horaFim ?? ''),
        'nomeContato': PlutoCell(value: nomeContato ?? ''),
        'foneContato': PlutoCell(value: foneContato ?? ''),
        'observacaoCliente': PlutoCell(value: observacaoCliente ?? ''),
        'observacaoAbertura': PlutoCell(value: observacaoAbertura ?? ''),
        'viewPessoaCliente': PlutoCell(value: viewPessoaClienteModel?.nome ?? ''),
        'viewPessoaColaborador': PlutoCell(value: viewPessoaColaboradorModel?.nome ?? ''),
        'osStatus': PlutoCell(value: osStatusModel?.nome ?? ''),
      },
    );
  }

  OsAberturaModel clone() {
    return OsAberturaModel(
      id: id,
      idOsStatus: idOsStatus,
      idColaborador: idColaborador,
      idCliente: idCliente,
      numero: numero,
      dataInicio: dataInicio,
      horaInicio: horaInicio,
      dataPrevisao: dataPrevisao,
      horaPrevisao: horaPrevisao,
      dataFim: dataFim,
      horaFim: horaFim,
      nomeContato: nomeContato,
      foneContato: foneContato,
      observacaoCliente: observacaoCliente,
      observacaoAbertura: observacaoAbertura,
      osAberturaEquipamentoModelList: osAberturaEquipamentoModelListClone(osAberturaEquipamentoModelList!),
      osProdutoServicoModelList: osProdutoServicoModelListClone(osProdutoServicoModelList!),
      osEvolucaoModelList: osEvolucaoModelListClone(osEvolucaoModelList!),
      viewPessoaClienteModel: ViewPessoaClienteModel.cloneFrom(viewPessoaClienteModel),
      viewPessoaColaboradorModel: ViewPessoaColaboradorModel.cloneFrom(viewPessoaColaboradorModel),
      osStatusModel: OsStatusModel.cloneFrom(osStatusModel),
    );
  }

  static OsAberturaModel cloneFrom(OsAberturaModel? model) {
    return OsAberturaModel(
      id: model?.id,
      idOsStatus: model?.idOsStatus,
      idColaborador: model?.idColaborador,
      idCliente: model?.idCliente,
      numero: model?.numero,
      dataInicio: model?.dataInicio,
      horaInicio: model?.horaInicio,
      dataPrevisao: model?.dataPrevisao,
      horaPrevisao: model?.horaPrevisao,
      dataFim: model?.dataFim,
      horaFim: model?.horaFim,
      nomeContato: model?.nomeContato,
      foneContato: model?.foneContato,
      observacaoCliente: model?.observacaoCliente,
      observacaoAbertura: model?.observacaoAbertura,
      viewPessoaClienteModel: ViewPessoaClienteModel.cloneFrom(model?.viewPessoaClienteModel),
      viewPessoaColaboradorModel: ViewPessoaColaboradorModel.cloneFrom(model?.viewPessoaColaboradorModel),
      osStatusModel: OsStatusModel.cloneFrom(model?.osStatusModel),
    );
  }

  osAberturaEquipamentoModelListClone(List<OsAberturaEquipamentoModel> osAberturaEquipamentoModelList) { 
		List<OsAberturaEquipamentoModel> resultList = [];
		for (var osAberturaEquipamentoModel in osAberturaEquipamentoModelList) {
			resultList.add(OsAberturaEquipamentoModel.cloneFrom(osAberturaEquipamentoModel));
		}
		return resultList;
	}

  osProdutoServicoModelListClone(List<OsProdutoServicoModel> osProdutoServicoModelList) { 
		List<OsProdutoServicoModel> resultList = [];
		for (var osProdutoServicoModel in osProdutoServicoModelList) {
			resultList.add(OsProdutoServicoModel.cloneFrom(osProdutoServicoModel));
		}
		return resultList;
	}

  osEvolucaoModelListClone(List<OsEvolucaoModel> osEvolucaoModelList) { 
		List<OsEvolucaoModel> resultList = [];
		for (var osEvolucaoModel in osEvolucaoModelList) {
			resultList.add(OsEvolucaoModel.cloneFrom(osEvolucaoModel));
		}
		return resultList;
	}


}