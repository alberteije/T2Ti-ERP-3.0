import 'dart:convert';
import 'package:pluto_grid/pluto_grid.dart';
import 'package:ordem_servico/app/data/model/model_imports.dart';

import 'package:ordem_servico/app/data/domain/domain_imports.dart';

class OsProdutoServicoModel extends ModelBase {
  int? id;
  int? idOsAbertura;
  int? idProduto;
  String? tipo;
  String? complemento;
  double? quantidade;
  double? valorUnitario;
  double? valorSubtotal;
  double? taxaDesconto;
  double? valorDesconto;
  double? valorTotal;
  ProdutoModel? produtoModel;

  OsProdutoServicoModel({
    this.id,
    this.idOsAbertura,
    this.idProduto,
    this.tipo = 'Produto',
    this.complemento,
    this.quantidade,
    this.valorUnitario,
    this.valorSubtotal,
    this.taxaDesconto,
    this.valorDesconto,
    this.valorTotal,
    ProdutoModel? produtoModel,
  }) {
    this.produtoModel = produtoModel ?? ProdutoModel();
  }

  static List<String> dbColumns = <String>[
    'id',
    'tipo',
    'complemento',
    'quantidade',
    'valor_unitario',
    'valor_subtotal',
    'taxa_desconto',
    'valor_desconto',
    'valor_total',
  ];

  static List<String> aliasColumns = <String>[
    'Id',
    'Tipo',
    'Complemento',
    'Quantidade',
    'Valor Unitario',
    'Valor Subtotal',
    'Taxa Desconto',
    'Valor Desconto',
    'Valor Total',
  ];

  OsProdutoServicoModel.fromJson(Map<String, dynamic> jsonData) {
    id = jsonData['id'];
    idOsAbertura = jsonData['idOsAbertura'];
    idProduto = jsonData['idProduto'];
    tipo = OsProdutoServicoDomain.getTipo(jsonData['tipo']);
    complemento = jsonData['complemento'];
    quantidade = jsonData['quantidade']?.toDouble();
    valorUnitario = jsonData['valorUnitario']?.toDouble();
    valorSubtotal = jsonData['valorSubtotal']?.toDouble();
    taxaDesconto = jsonData['taxaDesconto']?.toDouble();
    valorDesconto = jsonData['valorDesconto']?.toDouble();
    valorTotal = jsonData['valorTotal']?.toDouble();
    produtoModel = jsonData['produtoModel'] == null ? ProdutoModel() : ProdutoModel.fromJson(jsonData['produtoModel']);
  }

  Map<String, dynamic> get toJson {
    Map<String, dynamic> jsonData = <String, dynamic>{};

    jsonData['id'] = id != 0 ? id : null;
    jsonData['idOsAbertura'] = idOsAbertura != 0 ? idOsAbertura : null;
    jsonData['idProduto'] = idProduto != 0 ? idProduto : null;
    jsonData['tipo'] = OsProdutoServicoDomain.setTipo(tipo);
    jsonData['complemento'] = complemento;
    jsonData['quantidade'] = quantidade;
    jsonData['valorUnitario'] = valorUnitario;
    jsonData['valorSubtotal'] = valorSubtotal;
    jsonData['taxaDesconto'] = taxaDesconto;
    jsonData['valorDesconto'] = valorDesconto;
    jsonData['valorTotal'] = valorTotal;
    jsonData['produtoModel'] = produtoModel?.toJson;
    jsonData['produto'] = produtoModel?.nome ?? '';

    return jsonData;
  }

  String objectEncodeJson() {
    final jsonData = toJson;
    return json.encode(jsonData);
  }

  static OsProdutoServicoModel fromPlutoRow(PlutoRow row) {
    return OsProdutoServicoModel(
      id: row.cells['id']?.value,
      idOsAbertura: row.cells['idOsAbertura']?.value,
      idProduto: row.cells['idProduto']?.value,
      tipo: row.cells['tipo']?.value,
      complemento: row.cells['complemento']?.value,
      quantidade: row.cells['quantidade']?.value,
      valorUnitario: row.cells['valorUnitario']?.value,
      valorSubtotal: row.cells['valorSubtotal']?.value,
      taxaDesconto: row.cells['taxaDesconto']?.value,
      valorDesconto: row.cells['valorDesconto']?.value,
      valorTotal: row.cells['valorTotal']?.value,
    );
  }

  PlutoRow toPlutoRow() {
    return PlutoRow(
      cells: {
        'tempId': PlutoCell(value: tempId),
        'id': PlutoCell(value: id ?? 0),
        'idOsAbertura': PlutoCell(value: idOsAbertura ?? 0),
        'idProduto': PlutoCell(value: idProduto ?? 0),
        'tipo': PlutoCell(value: tipo ?? ''),
        'complemento': PlutoCell(value: complemento ?? ''),
        'quantidade': PlutoCell(value: quantidade ?? 0.0),
        'valorUnitario': PlutoCell(value: valorUnitario ?? 0.0),
        'valorSubtotal': PlutoCell(value: valorSubtotal ?? 0.0),
        'taxaDesconto': PlutoCell(value: taxaDesconto ?? 0.0),
        'valorDesconto': PlutoCell(value: valorDesconto ?? 0.0),
        'valorTotal': PlutoCell(value: valorTotal ?? 0.0),
        'produto': PlutoCell(value: produtoModel?.nome ?? ''),
      },
    );
  }

  OsProdutoServicoModel clone() {
    return OsProdutoServicoModel(
      id: id,
      idOsAbertura: idOsAbertura,
      idProduto: idProduto,
      tipo: tipo,
      complemento: complemento,
      quantidade: quantidade,
      valorUnitario: valorUnitario,
      valorSubtotal: valorSubtotal,
      taxaDesconto: taxaDesconto,
      valorDesconto: valorDesconto,
      valorTotal: valorTotal,
      produtoModel: ProdutoModel.cloneFrom(produtoModel),
    );
  }

  static OsProdutoServicoModel cloneFrom(OsProdutoServicoModel? model) {
    return OsProdutoServicoModel(
      id: model?.id,
      idOsAbertura: model?.idOsAbertura,
      idProduto: model?.idProduto,
      tipo: model?.tipo,
      complemento: model?.complemento,
      quantidade: model?.quantidade,
      valorUnitario: model?.valorUnitario,
      valorSubtotal: model?.valorSubtotal,
      taxaDesconto: model?.taxaDesconto,
      valorDesconto: model?.valorDesconto,
      valorTotal: model?.valorTotal,
      produtoModel: ProdutoModel.cloneFrom(model?.produtoModel),
    );
  }


}