import 'package:flutter/material.dart';
import 'package:ordem_servico/app/controller/os_equipamento_controller.dart';
import 'package:ordem_servico/app/page/shared_page/list_page_base.dart';

class OsEquipamentoListPage extends ListPageBase<OsEquipamentoController> {
  const OsEquipamentoListPage({Key? key}) : super(key: key);

  @override
  List<Map<String, dynamic>> get mobileItems => controller.mobileItems;

  @override
  Map<String, dynamic> get mobileConfig => controller.mobileConfig;

  @override
  String get standardFieldForFilter => controller.standardFieldForFilter;
}