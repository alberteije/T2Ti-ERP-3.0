import 'package:flutter/material.dart';
import 'package:ordem_servico/app/controller/os_status_controller.dart';
import 'package:ordem_servico/app/page/shared_page/list_page_base.dart';

class OsStatusListPage extends ListPageBase<OsStatusController> {
  const OsStatusListPage({Key? key}) : super(key: key);

  @override
  List<Map<String, dynamic>> get mobileItems => controller.mobileItems;

  @override
  Map<String, dynamic> get mobileConfig => controller.mobileConfig;

  @override
  String get standardFieldForFilter => controller.standardFieldForFilter;
}