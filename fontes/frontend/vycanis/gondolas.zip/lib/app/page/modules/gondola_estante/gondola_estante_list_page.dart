import 'package:flutter/material.dart';
import 'package:gondolas/app/controller/gondola_estante_controller.dart';
import 'package:gondolas/app/page/shared_page/list_page_base.dart';

class GondolaEstanteListPage extends ListPageBase<GondolaEstanteController> {
  const GondolaEstanteListPage({Key? key}) : super(key: key);

  @override
  List<Map<String, dynamic>> get mobileItems => controller.mobileItems;

  @override
  Map<String, dynamic> get mobileConfig => controller.mobileConfig;

  @override
  String get standardFieldForFilter => controller.standardFieldForFilter;
}