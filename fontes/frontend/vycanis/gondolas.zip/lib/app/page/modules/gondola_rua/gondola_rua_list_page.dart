import 'package:flutter/material.dart';
import 'package:gondolas/app/controller/gondola_rua_controller.dart';
import 'package:gondolas/app/page/shared_page/list_page_base.dart';

class GondolaRuaListPage extends ListPageBase<GondolaRuaController> {
  const GondolaRuaListPage({Key? key}) : super(key: key);

  @override
  List<Map<String, dynamic>> get mobileItems => controller.mobileItems;

  @override
  Map<String, dynamic> get mobileConfig => controller.mobileConfig;

  @override
  String get standardFieldForFilter => controller.standardFieldForFilter;
}