import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:extended_masked_text/extended_masked_text.dart';

import 'package:gondolas/app/page/shared_widget/message_dialog.dart';
import 'package:gondolas/app/page/grid_columns/grid_columns_imports.dart';
import 'package:gondolas/app/routes/app_routes.dart';
import 'package:gondolas/app/controller/controller_imports.dart';
import 'package:gondolas/app/data/model/model_imports.dart';
import 'package:gondolas/app/data/repository/gondola_rua_repository.dart';

class GondolaRuaController extends ControllerBase<GondolaRuaModel, GondolaRuaRepository> {

  GondolaRuaController({required super.repository}) {
    dbColumns = GondolaRuaModel.dbColumns;
    aliasColumns = GondolaRuaModel.aliasColumns;
    gridColumns = gondolaRuaGridColumns();
    functionName = "gondola_rua";
    screenTitle = "Rua";
  }

  @override
  GondolaRuaModel createNewModel() => GondolaRuaModel();

  @override
  final standardFieldForFilter = GondolaRuaModel.aliasColumns[GondolaRuaModel.dbColumns.indexOf('codigo')];

  final codigoController = TextEditingController();
  final quantidadeEstanteController = MoneyMaskedTextController(precision: 0, decimalSeparator: '', thousandSeparator: '');
  final nomeController = TextEditingController();

  final Map<String, dynamic> mobileConfig = {
    'primaryColumns': ['codigo'],
    'secondaryColumns': ['quantidade_estante'],
  };

  List<Map<String, dynamic>> get mobileItems {
    return modelList.map((gondolaRua) => gondolaRua.toJson).toList();
  }

  @override
  void prepareForInsert() {
    isNewRecord = true;
    currentModel = createNewModel();
    _resetForm();
    Get.toNamed(Routes.gondolaRuaEditPage);
  }

  void _resetForm() {
    formWasChanged = false;
    codigoController.text = '';
    quantidadeEstanteController.updateValue(0);
    nomeController.text = '';
  }

  @override
  void selectRowForEditingById(int id) {
    final model = modelList.firstWhere((m) => m.id == id);
    currentModel = model.clone();
    updateControllersFromModel();
    Get.toNamed(Routes.gondolaRuaEditPage);
  }

  void updateControllersFromModel() {
    codigoController.text = currentModel.codigo ?? '';
    quantidadeEstanteController.updateValue((currentModel.quantidadeEstante ?? 0).toDouble());
    nomeController.text = currentModel.nome ?? '';
    formWasChanged = false;
  }

  @override
  Future<void> save() async {
    if (!formKey.currentState!.validate()) {
      showErrorSnackBar(message: 'validator_form_message'.tr);
      return;
    }

    final existingIndex = modelList.indexWhere((m) => m.id == currentModel.id);

    if (existingIndex >= 0) {
      modelList[existingIndex] = currentModel.clone();
    }

    final result = await repository.save(gondolaRuaModel: currentModel);
    if (result == null) return;

    if (existingIndex >= 0) {
      modelList[existingIndex] = result;
    } else {
      modelList.insert(0, result);
    }

    if (!GetPlatform.isMobile) {
      updateGridRow(result);
    }

    Get.back(result: true);
  }


  @override
  void onClose() {
    codigoController.dispose();
    quantidadeEstanteController.dispose();
    nomeController.dispose();
    super.onClose();
  }

}