import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:extended_masked_text/extended_masked_text.dart';

import 'package:gondolas/app/page/shared_widget/message_dialog.dart';
import 'package:gondolas/app/page/grid_columns/grid_columns_imports.dart';
import 'package:gondolas/app/routes/app_routes.dart';
import 'package:gondolas/app/controller/controller_imports.dart';
import 'package:gondolas/app/data/model/model_imports.dart';
import 'package:gondolas/app/data/repository/gondola_estante_repository.dart';

class GondolaEstanteController extends ControllerBase<GondolaEstanteModel, GondolaEstanteRepository> {

  GondolaEstanteController({required super.repository}) {
    dbColumns = GondolaEstanteModel.dbColumns;
    aliasColumns = GondolaEstanteModel.aliasColumns;
    gridColumns = gondolaEstanteGridColumns();
    functionName = "gondola_estante";
    screenTitle = "Estante";
  }

  @override
  GondolaEstanteModel createNewModel() => GondolaEstanteModel();

  @override
  final standardFieldForFilter = GondolaEstanteModel.aliasColumns[GondolaEstanteModel.dbColumns.indexOf('codigo')];

  final gondolaRuaModelController = TextEditingController();
  final codigoController = TextEditingController();
  final quantidadeCaixaController = MoneyMaskedTextController(precision: 0, decimalSeparator: '', thousandSeparator: '');

  final Map<String, dynamic> mobileConfig = {
    'primaryColumns': ['codigo'],
    'secondaryColumns': ['quantidade_caixa'],
  };

  List<Map<String, dynamic>> get mobileItems {
    return modelList.map((gondolaEstante) => gondolaEstante.toJson).toList();
  }

  @override
  void prepareForInsert() {
    isNewRecord = true;
    currentModel = createNewModel();
    _resetForm();
    Get.toNamed(Routes.gondolaEstanteEditPage);
  }

  void _resetForm() {
    formWasChanged = false;
    gondolaRuaModelController.text = '';
    codigoController.text = '';
    quantidadeCaixaController.updateValue(0);
  }

  @override
  void selectRowForEditingById(int id) {
    final model = modelList.firstWhere((m) => m.id == id);
    currentModel = model.clone();
    updateControllersFromModel();
    Get.toNamed(Routes.gondolaEstanteEditPage);
  }

  void updateControllersFromModel() {
    gondolaRuaModelController.text = currentModel.gondolaRuaModel?.nome?.toString() ?? '';
    codigoController.text = currentModel.codigo ?? '';
    quantidadeCaixaController.updateValue((currentModel.quantidadeCaixa ?? 0).toDouble());
    formWasChanged = false;
  }

  @override
  Future<void> save() async {
    if (!formKey.currentState!.validate()) {
      showErrorSnackBar(message: 'validator_form_message'.tr);
      return;
    }

    final existingIndex = modelList.indexWhere((m) => m.id == currentModel.id);

    if (existingIndex >= 0) {
      modelList[existingIndex] = currentModel.clone();
    }

    final result = await repository.save(gondolaEstanteModel: currentModel);
    if (result == null) return;

    if (existingIndex >= 0) {
      modelList[existingIndex] = result;
    } else {
      modelList.insert(0, result);
    }

    if (!GetPlatform.isMobile) {
      updateGridRow(result);
    }

    Get.back(result: true);
  }

  Future callGondolaRuaLookup() async { 
		final lookupController = Get.find<LookupController>(); 
		lookupController.refreshItems(standardValue: '%'); 
		lookupController.title = '${'lookup_page_title'.tr} [Rua]'; 
		lookupController.route = '/gondola-rua/'; 
		lookupController.gridColumns = gondolaRuaGridColumns(isForLookup: true); 
		lookupController.aliasColumns = GondolaRuaModel.aliasColumns; 
		lookupController.dbColumns = GondolaRuaModel.dbColumns; 
		lookupController.standardColumn = GondolaRuaModel.aliasColumns[GondolaRuaModel.dbColumns.indexOf('nome')]; 

		final plutoRowResult = await Get.toNamed(Routes.lookupPage); 
		if (plutoRowResult != null) { 
			currentModel.idGondolaRua = plutoRowResult.cells['id']!.value; 
			currentModel.gondolaRuaModel = GondolaRuaModel.fromPlutoRow(plutoRowResult); 
			gondolaRuaModelController.text = currentModel.gondolaRuaModel?.nome ?? ''; 
			formWasChanged = true; 
		}
	}


  @override
  void onClose() {
    gondolaRuaModelController.dispose();
    codigoController.dispose();
    quantidadeCaixaController.dispose();
    super.onClose();
  }

}