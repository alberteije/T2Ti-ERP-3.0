import 'package:flutter/material.dart';
import 'dart:math';
import 'package:get/get.dart';
import 'package:extended_masked_text/extended_masked_text.dart';

import 'package:gondolas/app/infra/infra_imports.dart';
import 'package:gondolas/app/page/page_imports.dart';
import 'package:gondolas/app/page/shared_widget/message_dialog.dart';
import 'package:gondolas/app/page/grid_columns/grid_columns_imports.dart';
import 'package:gondolas/app/routes/app_routes.dart';
import 'package:gondolas/app/controller/controller_imports.dart';
import 'package:gondolas/app/data/model/model_imports.dart';
import 'package:gondolas/app/data/repository/gondola_caixa_repository.dart';

class GondolaCaixaController extends ControllerBase<GondolaCaixaModel, GondolaCaixaRepository> 
with GetSingleTickerProviderStateMixin {

  GondolaCaixaController({required super.repository}) {
    dbColumns = GondolaCaixaModel.dbColumns;
    aliasColumns = GondolaCaixaModel.aliasColumns;
    gridColumns = gondolaCaixaGridColumns();
    functionName = "gondola_caixa";
    screenTitle = "Caixa";
  }

  final gondolaCaixaScaffoldKey = GlobalKey<ScaffoldState>();
  final gondolaCaixaTabPageScaffoldKey = GlobalKey<ScaffoldState>();
  final gondolaCaixaFormKey = GlobalKey<FormState>();
  late TabController tabController;
  String? mandatoryMessage;  

  @override
  GondolaCaixaModel createNewModel() => GondolaCaixaModel();

  @override
  final standardFieldForFilter = GondolaCaixaModel.aliasColumns[GondolaCaixaModel.dbColumns.indexOf('codigo')];

  final gondolaEstanteModelController = TextEditingController();
  final codigoController = TextEditingController();
  final alturaController = MoneyMaskedTextController(precision: 0, decimalSeparator: '', thousandSeparator: '');
  final larguraController = MoneyMaskedTextController(precision: 0, decimalSeparator: '', thousandSeparator: '');
  final profundidadeController = MoneyMaskedTextController(precision: 0, decimalSeparator: '', thousandSeparator: '');

  final Map<String, dynamic> mobileConfig = {
    'primaryColumns': ['codigo'],
    'secondaryColumns': ['altura'],
  };

  List<Map<String, dynamic>> get mobileItems {
    return modelList.map((gondolaCaixa) => gondolaCaixa.toJson).toList();
  }

  @override
  void prepareForInsert() {
    isNewRecord = true;
    currentModel = createNewModel();
    _resetForm();
    tabController.animateTo(0);
    updateControllersFromModel();
    Get.toNamed(Routes.gondolaCaixaTabPage);
  }

  void _resetForm() {
    formWasChanged = false;
    gondolaEstanteModelController.text = '';
    codigoController.text = '';
    alturaController.updateValue(0);
    larguraController.updateValue(0);
    profundidadeController.updateValue(0);
  }

  @override
  void selectRowForEditingById(int id) {
    final model = modelList.firstWhere((m) => m.id == id);
    currentModel = model.clone();
    updateControllersFromModel();
    tabController.animateTo(0);
    Get.toNamed(Routes.gondolaCaixaTabPage);
  }

  _configureChildrenControllers() {
    //Armazenamento
		Get.put<GondolaArmazenamentoController>(GondolaArmazenamentoController()); 

  }
	
	_releaseChildrenControllers() {
    //Armazenamento
		Get.delete<GondolaArmazenamentoController>(); 

	}
  
  void updateControllersFromModel() {
    gondolaEstanteModelController.text = currentModel.gondolaEstanteModel?.codigo?.toString() ?? '';
    codigoController.text = currentModel.codigo ?? '';
    alturaController.updateValue((currentModel.altura ?? 0).toDouble());
    larguraController.updateValue((currentModel.largura ?? 0).toDouble());
    profundidadeController.updateValue((currentModel.profundidade ?? 0).toDouble());

    formWasChanged = false;
    _updateChildrenControllersFromModel();
  }

  void _updateChildrenControllersFromModel() {
    //Armazenamento
		final gondolaArmazenamentoController = Get.find<GondolaArmazenamentoController>(); 
		gondolaArmazenamentoController.userMadeChanges = false; 

  }

  @override
  Future<void> save() async {
    if (!validateCurrentForm()) return;
    if (validateForms()) {
      if (userMadeChanges()) {
        final existingIndex = modelList.indexWhere((m) => m.id == currentModel.id);

        if (existingIndex >= 0) {
          modelList[existingIndex] = currentModel.clone();
        }

        final result = await repository.save(gondolaCaixaModel: currentModel);
        if (result == null) return;

        if (existingIndex >= 0) {
          modelList[existingIndex] = result;
        } else {
          modelList.insert(0, result);
        }

        if (!GetPlatform.isMobile) {
          updateGridRow(result);
        }

        Get.back(result: true);
      } else {
        Get.back();
      }
    } 
  }

  Future callGondolaEstanteLookup() async { 
		final lookupController = Get.find<LookupController>(); 
		lookupController.refreshItems(standardValue: '%'); 
		lookupController.title = '${'lookup_page_title'.tr} [Estante]'; 
		lookupController.route = '/gondola-estante/'; 
		lookupController.gridColumns = gondolaEstanteGridColumns(isForLookup: true); 
		lookupController.aliasColumns = GondolaEstanteModel.aliasColumns; 
		lookupController.dbColumns = GondolaEstanteModel.dbColumns; 
		lookupController.standardColumn = GondolaEstanteModel.aliasColumns[GondolaEstanteModel.dbColumns.indexOf('codigo')]; 

		final plutoRowResult = await Get.toNamed(Routes.lookupPage); 
		if (plutoRowResult != null) { 
			currentModel.idGondolaEstante = plutoRowResult.cells['id']!.value; 
			currentModel.gondolaEstanteModel = GondolaEstanteModel.fromPlutoRow(plutoRowResult); 
			gondolaEstanteModelController.text = currentModel.gondolaEstanteModel?.codigo ?? ''; 
			formWasChanged = true; 
		}
	}


  List<Tab> tabItems = [
    Tab( 
			icon: Icon(iconDataList[Random().nextInt(10)]), 
			text: 'Caixa', 
		),
    Tab( 
			icon: Icon(iconDataList[Random().nextInt(10)]), 
			text: 'Armazenamento', 
		),
  ];

  List<Widget> tabPages() {
    return [
      GondolaCaixaEditPage(),
      const GondolaArmazenamentoListPage(),
    ];
  }

  @override
  void preventDataLoss() {
    if (userMadeChanges()) {
      showQuestionDialog('message_data_loss'.tr, () { 
        Get.back(); 
      });
    } else {
      Get.back();
    }
  }  

  bool userMadeChanges() {
    return
    formWasChanged 
    || 
		Get.find<GondolaArmazenamentoController>().userMadeChanges
    ;
  }

  void tabChange(int index) {
    validateCurrentForm();
  }

  bool validateCurrentForm() {
    mandatoryMessage = ValidateFormField.validateMandatory(currentModel.gondolaEstanteModel?.codigo); 
		if (mandatoryMessage != null) { 
			tabController.animateTo(0); 
			showErrorSnackBar(message: '$mandatoryMessage [Estante]'); 
			return false; 
		}
    return true;
  }

  bool validateForms() {
    return true;
  }

  @override
  void onInit() {
    super.onInit();
    tabController = TabController(vsync: this, length: tabItems.length);
    _configureChildrenControllers();
  }
	
  @override
  void onClose() {
    tabController.dispose();
    gondolaEstanteModelController.dispose();
    codigoController.dispose();
    alturaController.dispose();
    larguraController.dispose();
    profundidadeController.dispose();
    _releaseChildrenControllers();
    super.onClose();
  }	
}