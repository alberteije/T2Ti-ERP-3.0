import 'package:gondolas/app/data/provider/api/api_provider_base.dart';
import 'package:gondolas/app/data/model/model_imports.dart';

class ProdutoApiProvider extends ApiProviderBase {
  static const _path = '/produto';

  Future<List<ProdutoModel>?> getList({Filter? filter}) {
    return super.getListBase(
      '$_path/',
      (json) => ProdutoModel.fromJson(json),
      filter: filter,
    );
  }

  Future<ProdutoModel?> getObject(dynamic pk) {
    return super.getObjectBase(
      _path,
      pk,
      (json) => ProdutoModel.fromJson(json),
    );
  }

  Future<ProdutoModel?>? insert(ProdutoModel model) {
    return super.insertBase(
      _path,
      model,
      (json) => ProdutoModel.fromJson(json),
    );
  }

  Future<ProdutoModel?>? update(ProdutoModel model) {
    return super.updateBase(
      _path,
      model,
      (json) => ProdutoModel.fromJson(json),
    );
  }

  Future<bool?> delete(dynamic pk) {
    return super.deleteBase(_path, pk);
  }
}
