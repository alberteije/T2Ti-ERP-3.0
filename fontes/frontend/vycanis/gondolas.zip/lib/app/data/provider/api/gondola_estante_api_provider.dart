import 'package:gondolas/app/data/provider/api/api_provider_base.dart';
import 'package:gondolas/app/data/model/model_imports.dart';

class GondolaEstanteApiProvider extends ApiProviderBase {
  static const _path = '/gondola-estante';

  Future<List<GondolaEstanteModel>?> getList({Filter? filter}) {
    return super.getListBase(
      '$_path/',
      (json) => GondolaEstanteModel.fromJson(json),
      filter: filter,
    );
  }

  Future<GondolaEstanteModel?> getObject(dynamic pk) {
    return super.getObjectBase(
      _path,
      pk,
      (json) => GondolaEstanteModel.fromJson(json),
    );
  }

  Future<GondolaEstanteModel?>? insert(GondolaEstanteModel model) {
    return super.insertBase(
      _path,
      model,
      (json) => GondolaEstanteModel.fromJson(json),
    );
  }

  Future<GondolaEstanteModel?>? update(GondolaEstanteModel model) {
    return super.updateBase(
      _path,
      model,
      (json) => GondolaEstanteModel.fromJson(json),
    );
  }

  Future<bool?> delete(dynamic pk) {
    return super.deleteBase(_path, pk);
  }
}
