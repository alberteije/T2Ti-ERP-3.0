// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'gondola_estante_dao.dart';

// ignore_for_file: type=lint
mixin _$GondolaEstanteDaoMixin on DatabaseAccessor<AppDatabase> {
  $GondolaEstantesTable get gondolaEstantes => attachedDatabase.gondolaEstantes;
  $GondolaRuasTable get gondolaRuas => attachedDatabase.gondolaRuas;
}
