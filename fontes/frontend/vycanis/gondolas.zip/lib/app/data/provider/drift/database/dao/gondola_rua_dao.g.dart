// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'gondola_rua_dao.dart';

// ignore_for_file: type=lint
mixin _$GondolaRuaDaoMixin on DatabaseAccessor<AppDatabase> {
  $GondolaRuasTable get gondolaRuas => attachedDatabase.gondolaRuas;
}
