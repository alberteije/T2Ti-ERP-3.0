import 'package:gondolas/app/data/provider/api/api_provider_base.dart';
import 'package:gondolas/app/data/model/model_imports.dart';

class GondolaRuaApiProvider extends ApiProviderBase {
  static const _path = '/gondola-rua';

  Future<List<GondolaRuaModel>?> getList({Filter? filter}) {
    return super.getListBase(
      '$_path/',
      (json) => GondolaRuaModel.fromJson(json),
      filter: filter,
    );
  }

  Future<GondolaRuaModel?> getObject(dynamic pk) {
    return super.getObjectBase(
      _path,
      pk,
      (json) => GondolaRuaModel.fromJson(json),
    );
  }

  Future<GondolaRuaModel?>? insert(GondolaRuaModel model) {
    return super.insertBase(
      _path,
      model,
      (json) => GondolaRuaModel.fromJson(json),
    );
  }

  Future<GondolaRuaModel?>? update(GondolaRuaModel model) {
    return super.updateBase(
      _path,
      model,
      (json) => GondolaRuaModel.fromJson(json),
    );
  }

  Future<bool?> delete(dynamic pk) {
    return super.deleteBase(_path, pk);
  }
}
