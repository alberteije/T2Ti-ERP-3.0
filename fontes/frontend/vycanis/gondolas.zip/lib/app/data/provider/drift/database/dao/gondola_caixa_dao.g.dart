// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'gondola_caixa_dao.dart';

// ignore_for_file: type=lint
mixin _$GondolaCaixaDaoMixin on DatabaseAccessor<AppDatabase> {
  $GondolaCaixasTable get gondolaCaixas => attachedDatabase.gondolaCaixas;
  $GondolaArmazenamentosTable get gondolaArmazenamentos =>
      attachedDatabase.gondolaArmazenamentos;
  $ProdutosTable get produtos => attachedDatabase.produtos;
  $GondolaEstantesTable get gondolaEstantes => attachedDatabase.gondolaEstantes;
}
