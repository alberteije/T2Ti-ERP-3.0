import 'dart:convert';
import 'package:pluto_grid/pluto_grid.dart';
import 'package:gondolas/app/data/model/model_imports.dart';


class GondolaCaixaModel extends ModelBase {
  int? id;
  int? idGondolaEstante;
  String? codigo;
  int? altura;
  int? largura;
  int? profundidade;
  List<GondolaArmazenamentoModel>? gondolaArmazenamentoModelList;
  GondolaEstanteModel? gondolaEstanteModel;

  GondolaCaixaModel({
    this.id,
    this.idGondolaEstante,
    this.codigo,
    this.altura,
    this.largura,
    this.profundidade,
    List<GondolaArmazenamentoModel>? gondolaArmazenamentoModelList,
    GondolaEstanteModel? gondolaEstanteModel,
  }) {
    this.gondolaArmazenamentoModelList = gondolaArmazenamentoModelList?.toList(growable: true) ?? [];
    this.gondolaEstanteModel = gondolaEstanteModel ?? GondolaEstanteModel();
  }

  static List<String> dbColumns = <String>[
    'id',
    'codigo',
    'altura',
    'largura',
    'profundidade',
  ];

  static List<String> aliasColumns = <String>[
    'Id',
    'Codigo',
    'Altura',
    'Largura',
    'Profundidade',
  ];

  GondolaCaixaModel.fromJson(Map<String, dynamic> jsonData) {
    id = jsonData['id'];
    idGondolaEstante = jsonData['idGondolaEstante'];
    codigo = jsonData['codigo'];
    altura = jsonData['altura'];
    largura = jsonData['largura'];
    profundidade = jsonData['profundidade'];
    gondolaArmazenamentoModelList = (jsonData['gondolaArmazenamentoModelList'] as Iterable?)?.map((m) => GondolaArmazenamentoModel.fromJson(m)).toList() ?? [];
    gondolaEstanteModel = jsonData['gondolaEstanteModel'] == null ? GondolaEstanteModel() : GondolaEstanteModel.fromJson(jsonData['gondolaEstanteModel']);
  }

  Map<String, dynamic> get toJson {
    Map<String, dynamic> jsonData = <String, dynamic>{};

    jsonData['id'] = id != 0 ? id : null;
    jsonData['idGondolaEstante'] = idGondolaEstante != 0 ? idGondolaEstante : null;
    jsonData['codigo'] = codigo;
    jsonData['altura'] = altura;
    jsonData['largura'] = largura;
    jsonData['profundidade'] = profundidade;
    
		var gondolaArmazenamentoModelLocalList = []; 
		for (GondolaArmazenamentoModel object in gondolaArmazenamentoModelList ?? []) { 
			gondolaArmazenamentoModelLocalList.add(object.toJson); 
		}
		jsonData['gondolaArmazenamentoModelList'] = gondolaArmazenamentoModelLocalList;
    jsonData['gondolaEstanteModel'] = gondolaEstanteModel?.toJson;
    jsonData['gondolaEstante'] = gondolaEstanteModel?.codigo ?? '';

    return jsonData;
  }

  String objectEncodeJson() {
    final jsonData = toJson;
    return json.encode(jsonData);
  }

  static GondolaCaixaModel fromPlutoRow(PlutoRow row) {
    return GondolaCaixaModel(
      id: row.cells['id']?.value,
      idGondolaEstante: row.cells['idGondolaEstante']?.value,
      codigo: row.cells['codigo']?.value,
      altura: row.cells['altura']?.value,
      largura: row.cells['largura']?.value,
      profundidade: row.cells['profundidade']?.value,
    );
  }

  PlutoRow toPlutoRow() {
    return PlutoRow(
      cells: {
        'tempId': PlutoCell(value: tempId),
        'id': PlutoCell(value: id ?? 0),
        'idGondolaEstante': PlutoCell(value: idGondolaEstante ?? 0),
        'codigo': PlutoCell(value: codigo ?? ''),
        'altura': PlutoCell(value: altura ?? 0),
        'largura': PlutoCell(value: largura ?? 0),
        'profundidade': PlutoCell(value: profundidade ?? 0),
        'gondolaEstante': PlutoCell(value: gondolaEstanteModel?.codigo ?? ''),
      },
    );
  }

  GondolaCaixaModel clone() {
    return GondolaCaixaModel(
      id: id,
      idGondolaEstante: idGondolaEstante,
      codigo: codigo,
      altura: altura,
      largura: largura,
      profundidade: profundidade,
      gondolaArmazenamentoModelList: gondolaArmazenamentoModelListClone(gondolaArmazenamentoModelList!),
      gondolaEstanteModel: gondolaEstanteModel?.clone(),
    );
  }

  gondolaArmazenamentoModelListClone(List<GondolaArmazenamentoModel> gondolaArmazenamentoModelList) { 
		List<GondolaArmazenamentoModel> resultList = [];
		for (var gondolaArmazenamentoModel in gondolaArmazenamentoModelList) {
			resultList.add(gondolaArmazenamentoModel.clone());
		}
		return resultList;
	}


}