import 'dart:convert';
import 'package:pluto_grid/pluto_grid.dart';
import 'package:gerador_arquivos/app/data/model/model_imports.dart';

import 'package:gerador_arquivos/app/infra/infra_imports.dart';
import 'package:intl/intl.dart';
import 'package:gerador_arquivos/app/data/domain/domain_imports.dart';

class GeraEfdReinfModel extends ModelBase {
  int? id;
  DateTime? dataEmissao;
  DateTime? periodoInicial;
  DateTime? periodoFinal;
  String? tipoEvento;
  String? ambiente;
  int? idEmpresa;
  int? idContador;

  GeraEfdReinfModel({
    this.id,
    this.dataEmissao,
    this.periodoInicial,
    this.periodoFinal,
    this.tipoEvento = 'Todos',
    this.ambiente = '1-Produção',
    this.idEmpresa,
    this.idContador,
  });

  static List<String> dbColumns = <String>[
    'id',
    'data_emissao',
    'periodo_inicial',
    'periodo_final',
    'tipo_evento',
    'ambiente',
    'id_empresa',
    'id_contador',
  ];

  static List<String> aliasColumns = <String>[
    'Id',
    'Data Emissao',
    'Periodo Inicial',
    'Periodo Final',
    'Tipo Evento',
    'Ambiente',
    'Id Empresa',
    'Id Contador',
  ];

  GeraEfdReinfModel.fromJson(Map<String, dynamic> jsonData) {
    id = jsonData['id'];
    dataEmissao = jsonData['dataEmissao'] != null ? DateTime.tryParse(jsonData['dataEmissao']) : null;
    periodoInicial = jsonData['periodoInicial'] != null ? DateTime.tryParse(jsonData['periodoInicial']) : null;
    periodoFinal = jsonData['periodoFinal'] != null ? DateTime.tryParse(jsonData['periodoFinal']) : null;
    tipoEvento = GeraEfdReinfDomain.getTipoEvento(jsonData['tipoEvento']);
    ambiente = GeraEfdReinfDomain.getAmbiente(jsonData['ambiente']);
    idEmpresa = jsonData['idEmpresa'];
    idContador = jsonData['idContador'];
  }

  Map<String, dynamic> get toJson {
    Map<String, dynamic> jsonData = <String, dynamic>{};

    jsonData['id'] = id != 0 ? id : null;
    jsonData['dataEmissao'] = dataEmissao != null ? DateFormat('yyyy-MM-ddT00:00:00').format(dataEmissao!) : null;
    jsonData['periodoInicial'] = periodoInicial != null ? Util.formatAmericanDate(periodoInicial!) : null;
    jsonData['periodoFinal'] = periodoFinal != null ? Util.formatAmericanDate(periodoFinal!) : null;
    jsonData['tipoEvento'] = GeraEfdReinfDomain.setTipoEvento(tipoEvento);
    jsonData['ambiente'] = GeraEfdReinfDomain.setAmbiente(ambiente);
    jsonData['idEmpresa'] = '1';
    jsonData['idContador'] = '1';

    return jsonData;
  }

  String objectEncodeJson() {
    final jsonData = toJson;
    return json.encode(jsonData);
  }

  static GeraEfdReinfModel fromPlutoRow(PlutoRow row) {
    return GeraEfdReinfModel(
      id: row.cells['id']?.value,
      dataEmissao: Util.stringToDate(row.cells['dataEmissao']?.value),
      periodoInicial: Util.stringToDate(row.cells['periodoInicial']?.value),
      periodoFinal: Util.stringToDate(row.cells['periodoFinal']?.value),
      tipoEvento: row.cells['tipoEvento']?.value,
      ambiente: row.cells['ambiente']?.value,
      idEmpresa: row.cells['idEmpresa']?.value,
      idContador: row.cells['idContador']?.value,
    );
  }

  PlutoRow toPlutoRow() {
    return PlutoRow(
      cells: {
        'tempId': PlutoCell(value: tempId),
        'id': PlutoCell(value: id ?? 0),
        'dataEmissao': PlutoCell(value: dataEmissao),
        'periodoInicial': PlutoCell(value: periodoInicial),
        'periodoFinal': PlutoCell(value: periodoFinal),
        'tipoEvento': PlutoCell(value: tipoEvento ?? ''),
        'ambiente': PlutoCell(value: ambiente ?? ''),
        'idEmpresa': PlutoCell(value: idEmpresa ?? 0),
        'idContador': PlutoCell(value: idContador ?? 0),
      },
    );
  }

  GeraEfdReinfModel clone() {
    return GeraEfdReinfModel(
      id: id,
      dataEmissao: dataEmissao,
      periodoInicial: periodoInicial,
      periodoFinal: periodoFinal,
      tipoEvento: tipoEvento,
      ambiente: ambiente,
      idEmpresa: idEmpresa,
      idContador: idContador,
    );
  }


}