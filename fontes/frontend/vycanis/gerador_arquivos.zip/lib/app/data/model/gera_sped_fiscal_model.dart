import 'dart:convert';
import 'package:pluto_grid/pluto_grid.dart';
import 'package:gerador_arquivos/app/data/model/model_imports.dart';

import 'package:gerador_arquivos/app/infra/infra_imports.dart';
import 'package:intl/intl.dart';
import 'package:gerador_arquivos/app/data/domain/domain_imports.dart';

class GeraSpedFiscalModel extends ModelBase {
  int? id;
  DateTime? dataEmissao;
  DateTime? periodoInicial;
  DateTime? periodoFinal;
  String? versaoLayout;
  String? finalidadeArquivo;
  String? perfilApresentacao;
  String? inventario;
  int? idEmpresa;
  int? idContador;

  GeraSpedFiscalModel({
    this.id,
    this.dataEmissao,
    this.periodoInicial,
    this.periodoFinal,
    this.versaoLayout,
    this.finalidadeArquivo = '0-Remessa do arquivo original',
    this.perfilApresentacao = 'A',
    this.inventario = 'Sem Dados',
    this.idEmpresa,
    this.idContador,
  });

  static List<String> dbColumns = <String>[
    'id',
    'data_emissao',
    'periodo_inicial',
    'periodo_final',
    'versao_layout',
    'finalidade_arquivo',
    'perfil_apresentacao',
    'inventario',
    'id_empresa',
    'id_contador',
  ];

  static List<String> aliasColumns = <String>[
    'Id',
    'Data Emissao',
    'Periodo Inicial',
    'Periodo Final',
    'Versao Layout',
    'Finalidade Arquivo',
    'Perfil Apresentacao',
    'Inventario',
    'Id Empresa',
    'Id Contador',
  ];

  GeraSpedFiscalModel.fromJson(Map<String, dynamic> jsonData) {
    id = jsonData['id'];
    dataEmissao = jsonData['dataEmissao'] != null ? DateTime.tryParse(jsonData['dataEmissao']) : null;
    periodoInicial = jsonData['periodoInicial'] != null ? DateTime.tryParse(jsonData['periodoInicial']) : null;
    periodoFinal = jsonData['periodoFinal'] != null ? DateTime.tryParse(jsonData['periodoFinal']) : null;
    versaoLayout = jsonData['versaoLayout'];
    finalidadeArquivo = GeraSpedFiscalDomain.getFinalidadeArquivo(jsonData['finalidadeArquivo']);
    perfilApresentacao = GeraSpedFiscalDomain.getPerfilApresentacao(jsonData['perfilApresentacao']);
    inventario = GeraSpedFiscalDomain.getInventario(jsonData['inventario']);
    idEmpresa = jsonData['idEmpresa'];
    idContador = jsonData['idContador'];
  }

  Map<String, dynamic> get toJson {
    Map<String, dynamic> jsonData = <String, dynamic>{};

    jsonData['id'] = id != 0 ? id : null;
    jsonData['dataEmissao'] = dataEmissao != null ? DateFormat('yyyy-MM-ddT00:00:00').format(dataEmissao!) : null;
    jsonData['periodoInicial'] = periodoInicial != null ? Util.formatAmericanDate(periodoInicial!) : null;
    jsonData['periodoFinal'] = periodoFinal != null ? Util.formatAmericanDate(periodoFinal!) : null;
    jsonData['versaoLayout'] = versaoLayout;
    jsonData['finalidadeArquivo'] = GeraSpedFiscalDomain.setFinalidadeArquivo(finalidadeArquivo);
    jsonData['perfilApresentacao'] = GeraSpedFiscalDomain.setPerfilApresentacao(perfilApresentacao);
    jsonData['inventario'] = GeraSpedFiscalDomain.setInventario(inventario);
    jsonData['idEmpresa'] = '1';
    jsonData['idContador'] = '1';

    return jsonData;
  }

  String objectEncodeJson() {
    final jsonData = toJson;
    return json.encode(jsonData);
  }

  static GeraSpedFiscalModel fromPlutoRow(PlutoRow row) {
    return GeraSpedFiscalModel(
      id: row.cells['id']?.value,
      dataEmissao: Util.stringToDate(row.cells['dataEmissao']?.value),
      periodoInicial: Util.stringToDate(row.cells['periodoInicial']?.value),
      periodoFinal: Util.stringToDate(row.cells['periodoFinal']?.value),
      versaoLayout: row.cells['versaoLayout']?.value,
      finalidadeArquivo: row.cells['finalidadeArquivo']?.value,
      perfilApresentacao: row.cells['perfilApresentacao']?.value,
      inventario: row.cells['inventario']?.value,
      idEmpresa: row.cells['idEmpresa']?.value,
      idContador: row.cells['idContador']?.value,
    );
  }

  PlutoRow toPlutoRow() {
    return PlutoRow(
      cells: {
        'tempId': PlutoCell(value: tempId),
        'id': PlutoCell(value: id ?? 0),
        'dataEmissao': PlutoCell(value: dataEmissao),
        'periodoInicial': PlutoCell(value: periodoInicial),
        'periodoFinal': PlutoCell(value: periodoFinal),
        'versaoLayout': PlutoCell(value: versaoLayout ?? ''),
        'finalidadeArquivo': PlutoCell(value: finalidadeArquivo ?? ''),
        'perfilApresentacao': PlutoCell(value: perfilApresentacao ?? ''),
        'inventario': PlutoCell(value: inventario ?? ''),
        'idEmpresa': PlutoCell(value: idEmpresa ?? 0),
        'idContador': PlutoCell(value: idContador ?? 0),
      },
    );
  }

  GeraSpedFiscalModel clone() {
    return GeraSpedFiscalModel(
      id: id,
      dataEmissao: dataEmissao,
      periodoInicial: periodoInicial,
      periodoFinal: periodoFinal,
      versaoLayout: versaoLayout,
      finalidadeArquivo: finalidadeArquivo,
      perfilApresentacao: perfilApresentacao,
      inventario: inventario,
      idEmpresa: idEmpresa,
      idContador: idContador,
    );
  }


}