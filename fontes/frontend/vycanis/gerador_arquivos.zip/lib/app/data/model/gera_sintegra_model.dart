import 'dart:convert';
import 'package:pluto_grid/pluto_grid.dart';
import 'package:gerador_arquivos/app/data/model/model_imports.dart';

import 'package:gerador_arquivos/app/infra/infra_imports.dart';
import 'package:intl/intl.dart';
import 'package:gerador_arquivos/app/data/domain/domain_imports.dart';

class GeraSintegraModel extends ModelBase {
  int? id;
  DateTime? dataEmissao;
  DateTime? periodoInicial;
  DateTime? periodoFinal;
  String? codigoConvenio;
  String? finalidadeArquivo;
  String? naturezaInformacoes;
  String? inventario;
  int? idEmpresa;
  int? idContador;

  GeraSintegraModel({
    this.id,
    this.dataEmissao,
    this.periodoInicial,
    this.periodoFinal,
    this.codigoConvenio = '1-57/95 na versão 31/99',
    this.finalidadeArquivo = '1-Normal',
    this.naturezaInformacoes = '1-Interestaduais somente operações sujeitas ao regime de substituição tributária',
    this.inventario = '0-Sem Inventário',
    this.idEmpresa,
    this.idContador,
  });

  static List<String> dbColumns = <String>[
    'id',
    'data_emissao',
    'periodo_inicial',
    'periodo_final',
    'codigo_convenio',
    'finalidade_arquivo',
    'natureza_informacoes',
    'inventario',
    'id_empresa',
    'id_contador',
  ];

  static List<String> aliasColumns = <String>[
    'Id',
    'Data Emissao',
    'Periodo Inicial',
    'Periodo Final',
    'Codigo Convenio',
    'Finalidade Arquivo',
    'Natureza Informacoes',
    'Inventario',
    'Id Empresa',
    'Id Contador',
  ];

  GeraSintegraModel.fromJson(Map<String, dynamic> jsonData) {
    id = jsonData['id'];
    dataEmissao = jsonData['dataEmissao'] != null ? DateTime.tryParse(jsonData['dataEmissao']) : null;
    periodoInicial = jsonData['periodoInicial'] != null ? DateTime.tryParse(jsonData['periodoInicial']) : null;
    periodoFinal = jsonData['periodoFinal'] != null ? DateTime.tryParse(jsonData['periodoFinal']) : null;
    codigoConvenio = GeraSintegraDomain.getCodigoConvenio(jsonData['codigoConvenio']);
    finalidadeArquivo = GeraSintegraDomain.getFinalidadeArquivo(jsonData['finalidadeArquivo']);
    naturezaInformacoes = GeraSintegraDomain.getNaturezaInformacoes(jsonData['naturezaInformacoes']);
    inventario = GeraSintegraDomain.getInventario(jsonData['inventario']);
    idEmpresa = jsonData['idEmpresa'];
    idContador = jsonData['idContador'];
  }

  Map<String, dynamic> get toJson {
    Map<String, dynamic> jsonData = <String, dynamic>{};

    jsonData['id'] = id != 0 ? id : null;
    jsonData['dataEmissao'] = dataEmissao != null ? DateFormat('yyyy-MM-ddT00:00:00').format(dataEmissao!) : null;
    jsonData['periodoInicial'] = periodoInicial != null ? Util.formatAmericanDate(periodoInicial!) : null;
    jsonData['periodoFinal'] = periodoFinal != null ? Util.formatAmericanDate(periodoFinal!) : null;
    jsonData['codigoConvenio'] = GeraSintegraDomain.setCodigoConvenio(codigoConvenio);
    jsonData['finalidadeArquivo'] = GeraSintegraDomain.setFinalidadeArquivo(finalidadeArquivo);
    jsonData['naturezaInformacoes'] = GeraSintegraDomain.setNaturezaInformacoes(naturezaInformacoes);
    jsonData['inventario'] = GeraSintegraDomain.setInventario(inventario);
    jsonData['idEmpresa'] = '1';
    jsonData['idContador'] = '1';

    return jsonData;
  }

  String objectEncodeJson() {
    final jsonData = toJson;
    return json.encode(jsonData);
  }

  static GeraSintegraModel fromPlutoRow(PlutoRow row) {
    return GeraSintegraModel(
      id: row.cells['id']?.value,
      dataEmissao: Util.stringToDate(row.cells['dataEmissao']?.value),
      periodoInicial: Util.stringToDate(row.cells['periodoInicial']?.value),
      periodoFinal: Util.stringToDate(row.cells['periodoFinal']?.value),
      codigoConvenio: row.cells['codigoConvenio']?.value,
      finalidadeArquivo: row.cells['finalidadeArquivo']?.value,
      naturezaInformacoes: row.cells['naturezaInformacoes']?.value,
      inventario: row.cells['inventario']?.value,
      idEmpresa: row.cells['idEmpresa']?.value,
      idContador: row.cells['idContador']?.value,
    );
  }

  PlutoRow toPlutoRow() {
    return PlutoRow(
      cells: {
        'tempId': PlutoCell(value: tempId),
        'id': PlutoCell(value: id ?? 0),
        'dataEmissao': PlutoCell(value: dataEmissao),
        'periodoInicial': PlutoCell(value: periodoInicial),
        'periodoFinal': PlutoCell(value: periodoFinal),
        'codigoConvenio': PlutoCell(value: codigoConvenio ?? ''),
        'finalidadeArquivo': PlutoCell(value: finalidadeArquivo ?? ''),
        'naturezaInformacoes': PlutoCell(value: naturezaInformacoes ?? ''),
        'inventario': PlutoCell(value: inventario ?? ''),
        'idEmpresa': PlutoCell(value: idEmpresa ?? 0),
        'idContador': PlutoCell(value: idContador ?? 0),
      },
    );
  }

  GeraSintegraModel clone() {
    return GeraSintegraModel(
      id: id,
      dataEmissao: dataEmissao,
      periodoInicial: periodoInicial,
      periodoFinal: periodoFinal,
      codigoConvenio: codigoConvenio,
      finalidadeArquivo: finalidadeArquivo,
      naturezaInformacoes: naturezaInformacoes,
      inventario: inventario,
      idEmpresa: idEmpresa,
      idContador: idContador,
    );
  }


}