import 'dart:convert';
import 'package:pluto_grid/pluto_grid.dart';
import 'package:gerador_arquivos/app/data/model/model_imports.dart';

import 'package:gerador_arquivos/app/infra/infra_imports.dart';
import 'package:intl/intl.dart';
import 'package:gerador_arquivos/app/data/domain/domain_imports.dart';

class GeraSpedContabilModel extends ModelBase {
  int? id;
  DateTime? dataEmissao;
  DateTime? periodoInicial;
  DateTime? periodoFinal;
  String? formaEscrituracao;
  String? versaoLayout;
  int? idEmpresa;
  int? idContador;

  GeraSpedContabilModel({
    this.id,
    this.dataEmissao,
    this.periodoInicial,
    this.periodoFinal,
    this.formaEscrituracao = 'G-Diário Geral',
    this.versaoLayout,
    this.idEmpresa,
    this.idContador,
  });

  static List<String> dbColumns = <String>[
    'id',
    'data_emissao',
    'periodo_inicial',
    'periodo_final',
    'forma_escrituracao',
    'versao_layout',
    'id_empresa',
    'id_contador',
  ];

  static List<String> aliasColumns = <String>[
    'Id',
    'Data Emissao',
    'Periodo Inicial',
    'Periodo Final',
    'Forma Escrituracao',
    'Versao Layout',
    'Id Empresa',
    'Id Contador',
  ];

  GeraSpedContabilModel.fromJson(Map<String, dynamic> jsonData) {
    id = jsonData['id'];
    dataEmissao = jsonData['dataEmissao'] != null ? DateTime.tryParse(jsonData['dataEmissao']) : null;
    periodoInicial = jsonData['periodoInicial'] != null ? DateTime.tryParse(jsonData['periodoInicial']) : null;
    periodoFinal = jsonData['periodoFinal'] != null ? DateTime.tryParse(jsonData['periodoFinal']) : null;
    formaEscrituracao = GeraSpedContabilDomain.getFormaEscrituracao(jsonData['formaEscrituracao']);
    versaoLayout = jsonData['versaoLayout'];
    idEmpresa = jsonData['idEmpresa'];
    idContador = jsonData['idContador'];
  }

  Map<String, dynamic> get toJson {
    Map<String, dynamic> jsonData = <String, dynamic>{};

    jsonData['id'] = id != 0 ? id : null;
    jsonData['dataEmissao'] = dataEmissao != null ? DateFormat('yyyy-MM-ddT00:00:00').format(dataEmissao!) : null;
    jsonData['periodoInicial'] = periodoInicial != null ? Util.formatAmericanDate(periodoInicial!) : null;
    jsonData['periodoFinal'] = periodoFinal != null ? Util.formatAmericanDate(periodoFinal!) : null;
    jsonData['formaEscrituracao'] = GeraSpedContabilDomain.setFormaEscrituracao(formaEscrituracao);
    jsonData['versaoLayout'] = versaoLayout;
    jsonData['idEmpresa'] = '1';
    jsonData['idContador'] = '1';

    return jsonData;
  }

  String objectEncodeJson() {
    final jsonData = toJson;
    return json.encode(jsonData);
  }

  static GeraSpedContabilModel fromPlutoRow(PlutoRow row) {
    return GeraSpedContabilModel(
      id: row.cells['id']?.value,
      dataEmissao: Util.stringToDate(row.cells['dataEmissao']?.value),
      periodoInicial: Util.stringToDate(row.cells['periodoInicial']?.value),
      periodoFinal: Util.stringToDate(row.cells['periodoFinal']?.value),
      formaEscrituracao: row.cells['formaEscrituracao']?.value,
      versaoLayout: row.cells['versaoLayout']?.value,
      idEmpresa: row.cells['idEmpresa']?.value,
      idContador: row.cells['idContador']?.value,
    );
  }

  PlutoRow toPlutoRow() {
    return PlutoRow(
      cells: {
        'tempId': PlutoCell(value: tempId),
        'id': PlutoCell(value: id ?? 0),
        'dataEmissao': PlutoCell(value: dataEmissao),
        'periodoInicial': PlutoCell(value: periodoInicial),
        'periodoFinal': PlutoCell(value: periodoFinal),
        'formaEscrituracao': PlutoCell(value: formaEscrituracao ?? ''),
        'versaoLayout': PlutoCell(value: versaoLayout ?? ''),
        'idEmpresa': PlutoCell(value: idEmpresa ?? 0),
        'idContador': PlutoCell(value: idContador ?? 0),
      },
    );
  }

  GeraSpedContabilModel clone() {
    return GeraSpedContabilModel(
      id: id,
      dataEmissao: dataEmissao,
      periodoInicial: periodoInicial,
      periodoFinal: periodoFinal,
      formaEscrituracao: formaEscrituracao,
      versaoLayout: versaoLayout,
      idEmpresa: idEmpresa,
      idContador: idContador,
    );
  }


}