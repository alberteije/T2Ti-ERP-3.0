import 'dart:convert';
import 'package:pluto_grid/pluto_grid.dart';
import 'package:gerador_arquivos/app/data/model/model_imports.dart';

import 'package:gerador_arquivos/app/infra/infra_imports.dart';
import 'package:intl/intl.dart';
import 'package:gerador_arquivos/app/data/domain/domain_imports.dart';

class GeraEfdContribuicoesModel extends ModelBase {
  int? id;
  DateTime? dataEmissao;
  DateTime? periodoInicial;
  DateTime? periodoFinal;
  String? versaoLayout;
  String? tipoEscrituracao;
  int? idEmpersa;
  int? idContador;

  GeraEfdContribuicoesModel({
    this.id,
    this.dataEmissao,
    this.periodoInicial,
    this.periodoFinal,
    this.versaoLayout,
    this.tipoEscrituracao = '0-Original',
    this.idEmpersa,
    this.idContador,
  });

  static List<String> dbColumns = <String>[
    'id',
    'data_emissao',
    'periodo_inicial',
    'periodo_final',
    'versao_layout',
    'tipo_escrituracao',
    'id_empersa',
    'id_contador',
  ];

  static List<String> aliasColumns = <String>[
    'Id',
    'Data Emissao',
    'Periodo Inicial',
    'Periodo Final',
    'Versao Layout',
    'Tipo Escrituracao',
    'Id Empersa',
    'Id Contador',
  ];

  GeraEfdContribuicoesModel.fromJson(Map<String, dynamic> jsonData) {
    id = jsonData['id'];
    dataEmissao = jsonData['dataEmissao'] != null ? DateTime.tryParse(jsonData['dataEmissao']) : null;
    periodoInicial = jsonData['periodoInicial'] != null ? DateTime.tryParse(jsonData['periodoInicial']) : null;
    periodoFinal = jsonData['periodoFinal'] != null ? DateTime.tryParse(jsonData['periodoFinal']) : null;
    versaoLayout = jsonData['versaoLayout'];
    tipoEscrituracao = GeraEfdContribuicoesDomain.getTipoEscrituracao(jsonData['tipoEscrituracao']);
    idEmpersa = jsonData['idEmpersa'];
    idContador = jsonData['idContador'];
  }

  Map<String, dynamic> get toJson {
    Map<String, dynamic> jsonData = <String, dynamic>{};

    jsonData['id'] = id != 0 ? id : null;
    jsonData['dataEmissao'] = dataEmissao != null ? DateFormat('yyyy-MM-ddT00:00:00').format(dataEmissao!) : null;
    jsonData['periodoInicial'] = periodoInicial != null ? Util.formatAmericanDate(periodoInicial!) : null;
    jsonData['periodoFinal'] = periodoFinal != null ? Util.formatAmericanDate(periodoFinal!) : null;
    jsonData['versaoLayout'] = versaoLayout;
    jsonData['tipoEscrituracao'] = GeraEfdContribuicoesDomain.setTipoEscrituracao(tipoEscrituracao);
    jsonData['idEmpresa'] = '1';
    jsonData['idContador'] = '1';

    return jsonData;
  }

  String objectEncodeJson() {
    final jsonData = toJson;
    return json.encode(jsonData);
  }

  static GeraEfdContribuicoesModel fromPlutoRow(PlutoRow row) {
    return GeraEfdContribuicoesModel(
      id: row.cells['id']?.value,
      dataEmissao: Util.stringToDate(row.cells['dataEmissao']?.value),
      periodoInicial: Util.stringToDate(row.cells['periodoInicial']?.value),
      periodoFinal: Util.stringToDate(row.cells['periodoFinal']?.value),
      versaoLayout: row.cells['versaoLayout']?.value,
      tipoEscrituracao: row.cells['tipoEscrituracao']?.value,
      idEmpersa: row.cells['idEmpersa']?.value,
      idContador: row.cells['idContador']?.value,
    );
  }

  PlutoRow toPlutoRow() {
    return PlutoRow(
      cells: {
        'tempId': PlutoCell(value: tempId),
        'id': PlutoCell(value: id ?? 0),
        'dataEmissao': PlutoCell(value: dataEmissao),
        'periodoInicial': PlutoCell(value: periodoInicial),
        'periodoFinal': PlutoCell(value: periodoFinal),
        'versaoLayout': PlutoCell(value: versaoLayout ?? ''),
        'tipoEscrituracao': PlutoCell(value: tipoEscrituracao ?? ''),
        'idEmpersa': PlutoCell(value: idEmpersa ?? 0),
        'idContador': PlutoCell(value: idContador ?? 0),
      },
    );
  }

  GeraEfdContribuicoesModel clone() {
    return GeraEfdContribuicoesModel(
      id: id,
      dataEmissao: dataEmissao,
      periodoInicial: periodoInicial,
      periodoFinal: periodoFinal,
      versaoLayout: versaoLayout,
      tipoEscrituracao: tipoEscrituracao,
      idEmpersa: idEmpersa,
      idContador: idContador,
    );
  }


}