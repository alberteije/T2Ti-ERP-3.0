import 'package:gerador_arquivos/app/infra/constants.dart';
import 'package:gerador_arquivos/app/data/provider/api/gera_sped_fiscal_api_provider.dart';
import 'package:gerador_arquivos/app/data/provider/drift/gera_sped_fiscal_drift_provider.dart';
import 'package:gerador_arquivos/app/data/model/model_imports.dart';

class GeraSpedFiscalRepository {
  final GeraSpedFiscalApiProvider geraSpedFiscalApiProvider;
  final GeraSpedFiscalDriftProvider geraSpedFiscalDriftProvider;

  GeraSpedFiscalRepository({required this.geraSpedFiscalApiProvider, required this.geraSpedFiscalDriftProvider});

  Future getList({Filter? filter}) async {
    if (Constants.usingLocalDatabase) {
      return await geraSpedFiscalDriftProvider.getList(filter: filter);
    } else {
      return await geraSpedFiscalApiProvider.getList(filter: filter);
    }
  }

  Future<GeraSpedFiscalModel?>? save({required GeraSpedFiscalModel geraSpedFiscalModel}) async {
    if (geraSpedFiscalModel.id != null) {
      if (Constants.usingLocalDatabase) {
        return await geraSpedFiscalDriftProvider.update(geraSpedFiscalModel);
      } else {
        return await geraSpedFiscalApiProvider.update(geraSpedFiscalModel);
      }
    } else {
      if (Constants.usingLocalDatabase) {
        return await geraSpedFiscalDriftProvider.insert(geraSpedFiscalModel);
      } else {
        return await geraSpedFiscalApiProvider.insert(geraSpedFiscalModel);
      }
    }   
  }

  Future<bool> delete({required int id}) async {
    if (Constants.usingLocalDatabase) {
      return await geraSpedFiscalDriftProvider.delete(id) ?? false;
    } else {
      return await geraSpedFiscalApiProvider.delete(id) ?? false;
    }
  }

  Future<dynamic> gerarArquivo({required GeraSpedFiscalModel geraSpedFiscalModel}) async {
    return await geraSpedFiscalApiProvider.gerarArquivo(geraSpedFiscalModel);
  }

}