import 'package:gerador_arquivos/app/infra/constants.dart';
import 'package:gerador_arquivos/app/data/provider/api/gera_efd_reinf_api_provider.dart';
import 'package:gerador_arquivos/app/data/provider/drift/gera_efd_reinf_drift_provider.dart';
import 'package:gerador_arquivos/app/data/model/model_imports.dart';

class GeraEfdReinfRepository {
  final GeraEfdReinfApiProvider geraEfdReinfApiProvider;
  final GeraEfdReinfDriftProvider geraEfdReinfDriftProvider;

  GeraEfdReinfRepository({required this.geraEfdReinfApiProvider, required this.geraEfdReinfDriftProvider});

  Future getList({Filter? filter}) async {
    if (Constants.usingLocalDatabase) {
      return await geraEfdReinfDriftProvider.getList(filter: filter);
    } else {
      return await geraEfdReinfApiProvider.getList(filter: filter);
    }
  }

  Future<GeraEfdReinfModel?>? save({required GeraEfdReinfModel geraEfdReinfModel}) async {
    if (geraEfdReinfModel.id != null) {
      if (Constants.usingLocalDatabase) {
        return await geraEfdReinfDriftProvider.update(geraEfdReinfModel);
      } else {
        return await geraEfdReinfApiProvider.update(geraEfdReinfModel);
      }
    } else {
      if (Constants.usingLocalDatabase) {
        return await geraEfdReinfDriftProvider.insert(geraEfdReinfModel);
      } else {
        return await geraEfdReinfApiProvider.insert(geraEfdReinfModel);
      }
    }   
  }

  Future<bool> delete({required int id}) async {
    if (Constants.usingLocalDatabase) {
      return await geraEfdReinfDriftProvider.delete(id) ?? false;
    } else {
      return await geraEfdReinfApiProvider.delete(id) ?? false;
    }
  }

  Future<dynamic> gerarArquivo({required GeraEfdReinfModel geraEfdReinfModel}) async {
    return await geraEfdReinfApiProvider.gerarArquivo(geraEfdReinfModel);
  }
}