import 'package:gerador_arquivos/app/infra/constants.dart';
import 'package:gerador_arquivos/app/data/provider/api/gera_esocial_api_provider.dart';
import 'package:gerador_arquivos/app/data/provider/drift/gera_esocial_drift_provider.dart';
import 'package:gerador_arquivos/app/data/model/model_imports.dart';

class GeraEsocialRepository {
  final GeraEsocialApiProvider geraEsocialApiProvider;
  final GeraEsocialDriftProvider geraEsocialDriftProvider;

  GeraEsocialRepository({required this.geraEsocialApiProvider, required this.geraEsocialDriftProvider});

  Future getList({Filter? filter}) async {
    if (Constants.usingLocalDatabase) {
      return await geraEsocialDriftProvider.getList(filter: filter);
    } else {
      return await geraEsocialApiProvider.getList(filter: filter);
    }
  }

  Future<GeraEsocialModel?>? save({required GeraEsocialModel geraEsocialModel}) async {
    if (geraEsocialModel.id != null) {
      if (Constants.usingLocalDatabase) {
        return await geraEsocialDriftProvider.update(geraEsocialModel);
      } else {
        return await geraEsocialApiProvider.update(geraEsocialModel);
      }
    } else {
      if (Constants.usingLocalDatabase) {
        return await geraEsocialDriftProvider.insert(geraEsocialModel);
      } else {
        return await geraEsocialApiProvider.insert(geraEsocialModel);
      }
    }   
  }

  Future<bool> delete({required int id}) async {
    if (Constants.usingLocalDatabase) {
      return await geraEsocialDriftProvider.delete(id) ?? false;
    } else {
      return await geraEsocialApiProvider.delete(id) ?? false;
    }
  }

  Future<dynamic> gerarArquivo({required GeraEsocialModel geraEsocialModel}) async {
    return await geraEsocialApiProvider.gerarArquivo(geraEsocialModel);
  }

}