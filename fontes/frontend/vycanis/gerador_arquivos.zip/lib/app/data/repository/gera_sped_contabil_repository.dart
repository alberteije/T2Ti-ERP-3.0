import 'package:gerador_arquivos/app/infra/constants.dart';
import 'package:gerador_arquivos/app/data/provider/api/gera_sped_contabil_api_provider.dart';
import 'package:gerador_arquivos/app/data/provider/drift/gera_sped_contabil_drift_provider.dart';
import 'package:gerador_arquivos/app/data/model/model_imports.dart';

class GeraSpedContabilRepository {
  final GeraSpedContabilApiProvider geraSpedContabilApiProvider;
  final GeraSpedContabilDriftProvider geraSpedContabilDriftProvider;

  GeraSpedContabilRepository({required this.geraSpedContabilApiProvider, required this.geraSpedContabilDriftProvider});

  Future getList({Filter? filter}) async {
    if (Constants.usingLocalDatabase) {
      return await geraSpedContabilDriftProvider.getList(filter: filter);
    } else {
      return await geraSpedContabilApiProvider.getList(filter: filter);
    }
  }

  Future<GeraSpedContabilModel?>? save({required GeraSpedContabilModel geraSpedContabilModel}) async {
    if (geraSpedContabilModel.id != null) {
      if (Constants.usingLocalDatabase) {
        return await geraSpedContabilDriftProvider.update(geraSpedContabilModel);
      } else {
        return await geraSpedContabilApiProvider.update(geraSpedContabilModel);
      }
    } else {
      if (Constants.usingLocalDatabase) {
        return await geraSpedContabilDriftProvider.insert(geraSpedContabilModel);
      } else {
        return await geraSpedContabilApiProvider.insert(geraSpedContabilModel);
      }
    }   
  }

  Future<bool> delete({required int id}) async {
    if (Constants.usingLocalDatabase) {
      return await geraSpedContabilDriftProvider.delete(id) ?? false;
    } else {
      return await geraSpedContabilApiProvider.delete(id) ?? false;
    }
  }

  Future<dynamic> gerarArquivo({required GeraSpedContabilModel geraSpedContabilModel}) async {
    return await geraSpedContabilApiProvider.gerarArquivo(geraSpedContabilModel);
  }

}