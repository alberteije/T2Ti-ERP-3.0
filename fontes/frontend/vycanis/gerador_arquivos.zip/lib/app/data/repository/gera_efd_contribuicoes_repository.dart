import 'package:gerador_arquivos/app/infra/constants.dart';
import 'package:gerador_arquivos/app/data/provider/api/gera_efd_contribuicoes_api_provider.dart';
import 'package:gerador_arquivos/app/data/provider/drift/gera_efd_contribuicoes_drift_provider.dart';
import 'package:gerador_arquivos/app/data/model/model_imports.dart';

class GeraEfdContribuicoesRepository {
  final GeraEfdContribuicoesApiProvider geraEfdContribuicoesApiProvider;
  final GeraEfdContribuicoesDriftProvider geraEfdContribuicoesDriftProvider;

  GeraEfdContribuicoesRepository({required this.geraEfdContribuicoesApiProvider, required this.geraEfdContribuicoesDriftProvider});

  Future getList({Filter? filter}) async {
    if (Constants.usingLocalDatabase) {
      return await geraEfdContribuicoesDriftProvider.getList(filter: filter);
    } else {
      return await geraEfdContribuicoesApiProvider.getList(filter: filter);
    }
  }

  Future<GeraEfdContribuicoesModel?>? save({required GeraEfdContribuicoesModel geraEfdContribuicoesModel}) async {
    if (geraEfdContribuicoesModel.id != null) {
      if (Constants.usingLocalDatabase) {
        return await geraEfdContribuicoesDriftProvider.update(geraEfdContribuicoesModel);
      } else {
        return await geraEfdContribuicoesApiProvider.update(geraEfdContribuicoesModel);
      }
    } else {
      if (Constants.usingLocalDatabase) {
        return await geraEfdContribuicoesDriftProvider.insert(geraEfdContribuicoesModel);
      } else {
        return await geraEfdContribuicoesApiProvider.insert(geraEfdContribuicoesModel);
      }
    }   
  }

  Future<bool> delete({required int id}) async {
    if (Constants.usingLocalDatabase) {
      return await geraEfdContribuicoesDriftProvider.delete(id) ?? false;
    } else {
      return await geraEfdContribuicoesApiProvider.delete(id) ?? false;
    }
  }

  Future<dynamic> gerarArquivo({required GeraEfdContribuicoesModel geraEfdContribuicoesModel}) async {
    return await geraEfdContribuicoesApiProvider.gerarArquivo(geraEfdContribuicoesModel);
  }

}