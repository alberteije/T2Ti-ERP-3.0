import 'package:gerador_arquivos/app/infra/constants.dart';
import 'package:gerador_arquivos/app/data/provider/api/gera_sintegra_api_provider.dart';
import 'package:gerador_arquivos/app/data/provider/drift/gera_sintegra_drift_provider.dart';
import 'package:gerador_arquivos/app/data/model/model_imports.dart';

class GeraSintegraRepository {
  final GeraSintegraApiProvider geraSintegraApiProvider;
  final GeraSintegraDriftProvider geraSintegraDriftProvider;

  GeraSintegraRepository({required this.geraSintegraApiProvider, required this.geraSintegraDriftProvider});

  Future getList({Filter? filter}) async {
    if (Constants.usingLocalDatabase) {
      return await geraSintegraDriftProvider.getList(filter: filter);
    } else {
      return await geraSintegraApiProvider.getList(filter: filter);
    }
  }

  Future<GeraSintegraModel?>? save({required GeraSintegraModel geraSintegraModel}) async {
    if (geraSintegraModel.id != null) {
      if (Constants.usingLocalDatabase) {
        return await geraSintegraDriftProvider.update(geraSintegraModel);
      } else {
        return await geraSintegraApiProvider.update(geraSintegraModel);
      }
    } else {
      if (Constants.usingLocalDatabase) {
        return await geraSintegraDriftProvider.insert(geraSintegraModel);
      } else {
        return await geraSintegraApiProvider.insert(geraSintegraModel);
      }
    }   
  }

  Future<bool> delete({required int id}) async {
    if (Constants.usingLocalDatabase) {
      return await geraSintegraDriftProvider.delete(id) ?? false;
    } else {
      return await geraSintegraApiProvider.delete(id) ?? false;
    }
  }

  Future<dynamic> gerarArquivo({required GeraSintegraModel geraSintegraModel}) async {
    return await geraSintegraApiProvider.gerarArquivo(geraSintegraModel);
  }

}