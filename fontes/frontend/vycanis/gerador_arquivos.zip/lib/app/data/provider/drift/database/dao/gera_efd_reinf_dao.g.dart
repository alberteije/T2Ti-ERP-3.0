// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'gera_efd_reinf_dao.dart';

// ignore_for_file: type=lint
mixin _$GeraEfdReinfDaoMixin on DatabaseAccessor<AppDatabase> {
  $GeraEfdReinfsTable get geraEfdReinfs => attachedDatabase.geraEfdReinfs;
}
