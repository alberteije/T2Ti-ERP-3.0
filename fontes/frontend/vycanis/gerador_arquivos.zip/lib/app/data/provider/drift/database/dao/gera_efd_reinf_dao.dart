import 'package:drift/drift.dart';
import 'package:gerador_arquivos/app/data/provider/drift/database/database.dart';
import 'package:gerador_arquivos/app/data/provider/drift/database/database_imports.dart';

part 'gera_efd_reinf_dao.g.dart';

@DriftAccessor(tables: [
	GeraEfdReinfs,
])
class GeraEfdReinfDao extends DatabaseAccessor<AppDatabase> with _$GeraEfdReinfDaoMixin {
	final AppDatabase db;

	List<GeraEfdReinf> geraEfdReinfList = []; 
	List<GeraEfdReinfGrouped> geraEfdReinfGroupedList = []; 

	GeraEfdReinfDao(this.db) : super(db);

	Future<List<GeraEfdReinf>> getList() async {
		geraEfdReinfList = await select(geraEfdReinfs).get();
		return geraEfdReinfList;
	}

	Future<List<GeraEfdReinf>> getListFilter(String field, String value) async {
		final query = " $field like '%$value%'";
		final expression = CustomExpression<bool>(query);
		geraEfdReinfList = await (select(geraEfdReinfs)..where((t) => expression)).get();
		return geraEfdReinfList;	 
	}

	Future<List<GeraEfdReinfGrouped>> getGroupedList({String? field, dynamic value}) async {
		final query = select(geraEfdReinfs)
			.join([]);

		if (field != null && field != '') { 
			final column = geraEfdReinfs.$columns.where(((column) => column.$name == field)).first;
			if (column is TextColumn) {
				query.where((column as TextColumn).like('%$value%'));
			} else if (column is IntColumn) {
				query.where(column.equals(int.tryParse(value) as Object));
			} else if (column is RealColumn) {
				query.where(column.equals(double.tryParse(value) as Object));
			}
		}

		geraEfdReinfGroupedList = await query.map((row) {
			final geraEfdReinf = row.readTableOrNull(geraEfdReinfs); 

			return GeraEfdReinfGrouped(
				geraEfdReinf: geraEfdReinf, 

			);
		}).get();

		// fill internal lists
		//dynamic expression;
		//for (var geraEfdReinfGrouped in geraEfdReinfGroupedList) {
		//}		

		return geraEfdReinfGroupedList;	
	}

	Future<GeraEfdReinf?> getObject(dynamic pk) async {
		return await (select(geraEfdReinfs)..where((t) => t.id.equals(pk))).getSingleOrNull();
	} 

	Future<GeraEfdReinf?> getObjectFilter(String field, String value) async {
		final query = "SELECT * FROM gera_efd_reinf WHERE $field like '%$value%'";
		return (await customSelect(query).getSingleOrNull()) as GeraEfdReinf;		 
	} 

	Future<GeraEfdReinfGrouped?> getObjectGrouped({String? field, dynamic value}) async {
		final result = await getGroupedList(field: field, value: value);

		if (result.length != 1) {
			return null;
		} else {
			return result[0];
		} 
	}

	Future<int> insertObject(GeraEfdReinfGrouped object) {
		return transaction(() async {
			final maxPk = await lastPk();
			object.geraEfdReinf = object.geraEfdReinf!.copyWith(id: Value(maxPk + 1));
			final pkInserted = await into(geraEfdReinfs).insert(object.geraEfdReinf!);
			object.geraEfdReinf = object.geraEfdReinf!.copyWith(id: Value(pkInserted));			 
			await insertChildren(object);
			return pkInserted;
		});		
	}	 

	Future<bool> updateObject(GeraEfdReinfGrouped object) {
		return transaction(() async {
			await deleteChildren(object);
			await insertChildren(object);
			return update(geraEfdReinfs).replace(object.geraEfdReinf!);
		});	 
	} 

	Future<int> deleteObject(GeraEfdReinfGrouped object) {
		return transaction(() async {
			await deleteChildren(object);
			return delete(geraEfdReinfs).delete(object.geraEfdReinf!);
		});		
	}

	Future<void> insertChildren(GeraEfdReinfGrouped object) async {
	}
	
	Future<void> deleteChildren(GeraEfdReinfGrouped object) async {
	}

	Future<int> lastPk() async {
		final result = await customSelect("select MAX(id) as LAST from gera_efd_reinf").getSingleOrNull();
		return result?.data["LAST"] ?? 0;
	} 
}