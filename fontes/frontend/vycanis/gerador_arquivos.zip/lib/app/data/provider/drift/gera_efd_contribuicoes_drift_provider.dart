import 'package:gerador_arquivos/app/data/provider/drift/database/database_imports.dart';
import 'package:gerador_arquivos/app/infra/infra_imports.dart';
import 'package:gerador_arquivos/app/data/provider/provider_base.dart';
import 'package:gerador_arquivos/app/data/provider/drift/database/database.dart';
import 'package:gerador_arquivos/app/data/model/model_imports.dart';
import 'package:gerador_arquivos/app/data/domain/domain_imports.dart';

class GeraEfdContribuicoesDriftProvider extends ProviderBase {

	Future<List<GeraEfdContribuicoesModel>?> getList({Filter? filter}) async {
		List<GeraEfdContribuicoesGrouped> geraEfdContribuicoesDriftList = [];

		try {
			if (filter != null && filter.field != null) {
				geraEfdContribuicoesDriftList = await Session.database.geraEfdContribuicoesDao.getGroupedList(field: filter.field, value: filter.value!);
			} else {
				geraEfdContribuicoesDriftList = await Session.database.geraEfdContribuicoesDao.getGroupedList(); 
			}
			if (geraEfdContribuicoesDriftList.isNotEmpty) {
				return toListModel(geraEfdContribuicoesDriftList);
			} else {
				return [];
			}			 
		} catch (e) {
			handleResultError(null, null, exception: e);
			return null;
		}
	}

	Future<GeraEfdContribuicoesModel?> getObject(dynamic pk) async {
		try {
			final result = await Session.database.geraEfdContribuicoesDao.getObjectGrouped(field: 'id', value: pk);
			return toModel(result);
		} catch (e) {
			handleResultError(null, null, exception: e);
		}
		return null;
	}

	Future<GeraEfdContribuicoesModel?>? insert(GeraEfdContribuicoesModel geraEfdContribuicoesModel) async {
		try {
			final lastPk = await Session.database.geraEfdContribuicoesDao.insertObject(toDrift(geraEfdContribuicoesModel));
			geraEfdContribuicoesModel.id = lastPk;
			return geraEfdContribuicoesModel;
		} catch (e) {
			handleResultError(null, null, exception: e);
		}
		return null;
	}

	Future<GeraEfdContribuicoesModel?>? update(GeraEfdContribuicoesModel geraEfdContribuicoesModel) async {
		try {
			await Session.database.geraEfdContribuicoesDao.updateObject(toDrift(geraEfdContribuicoesModel));
			return geraEfdContribuicoesModel;
		} catch (e) {
			handleResultError(null, null, exception: e);
		}
		return null;
	}

	Future<bool?> delete(dynamic pk) async {
		try {
			await Session.database.geraEfdContribuicoesDao.deleteObject(toDrift(GeraEfdContribuicoesModel(id: pk)));
			return true;
		} catch (e) {
			handleResultError(null, null, exception: e);
		}
		return null;
	}	

	List<GeraEfdContribuicoesModel> toListModel(List<GeraEfdContribuicoesGrouped> geraEfdContribuicoesDriftList) {
		List<GeraEfdContribuicoesModel> listModel = [];
		for (var geraEfdContribuicoesDrift in geraEfdContribuicoesDriftList) {
			listModel.add(toModel(geraEfdContribuicoesDrift)!);
		}
		return listModel;
	}	

	GeraEfdContribuicoesModel? toModel(GeraEfdContribuicoesGrouped? geraEfdContribuicoesDrift) {
		if (geraEfdContribuicoesDrift != null) {
			return GeraEfdContribuicoesModel(
				id: geraEfdContribuicoesDrift.geraEfdContribuicoes?.id,
				dataEmissao: geraEfdContribuicoesDrift.geraEfdContribuicoes?.dataEmissao,
				periodoInicial: geraEfdContribuicoesDrift.geraEfdContribuicoes?.periodoInicial,
				periodoFinal: geraEfdContribuicoesDrift.geraEfdContribuicoes?.periodoFinal,
				versaoLayout: geraEfdContribuicoesDrift.geraEfdContribuicoes?.versaoLayout,
				tipoEscrituracao: GeraEfdContribuicoesDomain.getTipoEscrituracao(geraEfdContribuicoesDrift.geraEfdContribuicoes?.tipoEscrituracao),
				idEmpersa: geraEfdContribuicoesDrift.geraEfdContribuicoes?.idEmpersa,
				idContador: geraEfdContribuicoesDrift.geraEfdContribuicoes?.idContador,
			);
		} else {
			return null;
		}
	}


	GeraEfdContribuicoesGrouped toDrift(GeraEfdContribuicoesModel geraEfdContribuicoesModel) {
		return GeraEfdContribuicoesGrouped(
			geraEfdContribuicoes: GeraEfdContribuicoes(
				id: geraEfdContribuicoesModel.id,
				dataEmissao: geraEfdContribuicoesModel.dataEmissao,
				periodoInicial: geraEfdContribuicoesModel.periodoInicial,
				periodoFinal: geraEfdContribuicoesModel.periodoFinal,
				versaoLayout: geraEfdContribuicoesModel.versaoLayout,
				tipoEscrituracao: GeraEfdContribuicoesDomain.setTipoEscrituracao(geraEfdContribuicoesModel.tipoEscrituracao),
				idEmpersa: geraEfdContribuicoesModel.idEmpersa,
				idContador: geraEfdContribuicoesModel.idContador,
			),
		);
	}

		
}
