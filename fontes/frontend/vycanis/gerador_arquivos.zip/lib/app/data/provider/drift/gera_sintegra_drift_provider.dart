import 'package:gerador_arquivos/app/data/provider/drift/database/database_imports.dart';
import 'package:gerador_arquivos/app/infra/infra_imports.dart';
import 'package:gerador_arquivos/app/data/provider/provider_base.dart';
import 'package:gerador_arquivos/app/data/provider/drift/database/database.dart';
import 'package:gerador_arquivos/app/data/model/model_imports.dart';
import 'package:gerador_arquivos/app/data/domain/domain_imports.dart';

class GeraSintegraDriftProvider extends ProviderBase {

	Future<List<GeraSintegraModel>?> getList({Filter? filter}) async {
		List<GeraSintegraGrouped> geraSintegraDriftList = [];

		try {
			if (filter != null && filter.field != null) {
				geraSintegraDriftList = await Session.database.geraSintegraDao.getGroupedList(field: filter.field, value: filter.value!);
			} else {
				geraSintegraDriftList = await Session.database.geraSintegraDao.getGroupedList(); 
			}
			if (geraSintegraDriftList.isNotEmpty) {
				return toListModel(geraSintegraDriftList);
			} else {
				return [];
			}			 
		} catch (e) {
			handleResultError(null, null, exception: e);
			return null;
		}
	}

	Future<GeraSintegraModel?> getObject(dynamic pk) async {
		try {
			final result = await Session.database.geraSintegraDao.getObjectGrouped(field: 'id', value: pk);
			return toModel(result);
		} catch (e) {
			handleResultError(null, null, exception: e);
		}
		return null;
	}

	Future<GeraSintegraModel?>? insert(GeraSintegraModel geraSintegraModel) async {
		try {
			final lastPk = await Session.database.geraSintegraDao.insertObject(toDrift(geraSintegraModel));
			geraSintegraModel.id = lastPk;
			return geraSintegraModel;
		} catch (e) {
			handleResultError(null, null, exception: e);
		}
		return null;
	}

	Future<GeraSintegraModel?>? update(GeraSintegraModel geraSintegraModel) async {
		try {
			await Session.database.geraSintegraDao.updateObject(toDrift(geraSintegraModel));
			return geraSintegraModel;
		} catch (e) {
			handleResultError(null, null, exception: e);
		}
		return null;
	}

	Future<bool?> delete(dynamic pk) async {
		try {
			await Session.database.geraSintegraDao.deleteObject(toDrift(GeraSintegraModel(id: pk)));
			return true;
		} catch (e) {
			handleResultError(null, null, exception: e);
		}
		return null;
	}	

	List<GeraSintegraModel> toListModel(List<GeraSintegraGrouped> geraSintegraDriftList) {
		List<GeraSintegraModel> listModel = [];
		for (var geraSintegraDrift in geraSintegraDriftList) {
			listModel.add(toModel(geraSintegraDrift)!);
		}
		return listModel;
	}	

	GeraSintegraModel? toModel(GeraSintegraGrouped? geraSintegraDrift) {
		if (geraSintegraDrift != null) {
			return GeraSintegraModel(
				id: geraSintegraDrift.geraSintegra?.id,
				dataEmissao: geraSintegraDrift.geraSintegra?.dataEmissao,
				periodoInicial: geraSintegraDrift.geraSintegra?.periodoInicial,
				periodoFinal: geraSintegraDrift.geraSintegra?.periodoFinal,
				codigoConvenio: GeraSintegraDomain.getCodigoConvenio(geraSintegraDrift.geraSintegra?.codigoConvenio),
				finalidadeArquivo: GeraSintegraDomain.getFinalidadeArquivo(geraSintegraDrift.geraSintegra?.finalidadeArquivo),
				naturezaInformacoes: GeraSintegraDomain.getNaturezaInformacoes(geraSintegraDrift.geraSintegra?.naturezaInformacoes),
				inventario: GeraSintegraDomain.getInventario(geraSintegraDrift.geraSintegra?.inventario),
				idEmpresa: geraSintegraDrift.geraSintegra?.idEmpresa,
				idContador: geraSintegraDrift.geraSintegra?.idContador,
			);
		} else {
			return null;
		}
	}


	GeraSintegraGrouped toDrift(GeraSintegraModel geraSintegraModel) {
		return GeraSintegraGrouped(
			geraSintegra: GeraSintegra(
				id: geraSintegraModel.id,
				dataEmissao: geraSintegraModel.dataEmissao,
				periodoInicial: geraSintegraModel.periodoInicial,
				periodoFinal: geraSintegraModel.periodoFinal,
				codigoConvenio: GeraSintegraDomain.setCodigoConvenio(geraSintegraModel.codigoConvenio),
				finalidadeArquivo: GeraSintegraDomain.setFinalidadeArquivo(geraSintegraModel.finalidadeArquivo),
				naturezaInformacoes: GeraSintegraDomain.setNaturezaInformacoes(geraSintegraModel.naturezaInformacoes),
				inventario: GeraSintegraDomain.setInventario(geraSintegraModel.inventario),
				idEmpresa: geraSintegraModel.idEmpresa,
				idContador: geraSintegraModel.idContador,
			),
		);
	}

		
}
