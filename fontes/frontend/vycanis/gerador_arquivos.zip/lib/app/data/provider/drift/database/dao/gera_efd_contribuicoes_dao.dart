import 'package:drift/drift.dart';
import 'package:gerador_arquivos/app/data/provider/drift/database/database.dart';
import 'package:gerador_arquivos/app/data/provider/drift/database/database_imports.dart';

part 'gera_efd_contribuicoes_dao.g.dart';

@DriftAccessor(tables: [
	GeraEfdContribuicoess,
])
class GeraEfdContribuicoesDao extends DatabaseAccessor<AppDatabase> with _$GeraEfdContribuicoesDaoMixin {
	final AppDatabase db;

	List<GeraEfdContribuicoes> geraEfdContribuicoesList = []; 
	List<GeraEfdContribuicoesGrouped> geraEfdContribuicoesGroupedList = []; 

	GeraEfdContribuicoesDao(this.db) : super(db);

	Future<List<GeraEfdContribuicoes>> getList() async {
		geraEfdContribuicoesList = await select(geraEfdContribuicoess).get();
		return geraEfdContribuicoesList;
	}

	Future<List<GeraEfdContribuicoes>> getListFilter(String field, String value) async {
		final query = " $field like '%$value%'";
		final expression = CustomExpression<bool>(query);
		geraEfdContribuicoesList = await (select(geraEfdContribuicoess)..where((t) => expression)).get();
		return geraEfdContribuicoesList;	 
	}

	Future<List<GeraEfdContribuicoesGrouped>> getGroupedList({String? field, dynamic value}) async {
		final query = select(geraEfdContribuicoess)
			.join([]);

		if (field != null && field != '') { 
			final column = geraEfdContribuicoess.$columns.where(((column) => column.$name == field)).first;
			if (column is TextColumn) {
				query.where((column as TextColumn).like('%$value%'));
			} else if (column is IntColumn) {
				query.where(column.equals(int.tryParse(value) as Object));
			} else if (column is RealColumn) {
				query.where(column.equals(double.tryParse(value) as Object));
			}
		}

		geraEfdContribuicoesGroupedList = await query.map((row) {
			final geraEfdContribuicoes = row.readTableOrNull(geraEfdContribuicoess); 

			return GeraEfdContribuicoesGrouped(
				geraEfdContribuicoes: geraEfdContribuicoes, 

			);
		}).get();

		// fill internal lists
		//dynamic expression;
		//for (var geraEfdContribuicoesGrouped in geraEfdContribuicoesGroupedList) {
		//}		

		return geraEfdContribuicoesGroupedList;	
	}

	Future<GeraEfdContribuicoes?> getObject(dynamic pk) async {
		return await (select(geraEfdContribuicoess)..where((t) => t.id.equals(pk))).getSingleOrNull();
	} 

	Future<GeraEfdContribuicoes?> getObjectFilter(String field, String value) async {
		final query = "SELECT * FROM gera_efd_contribuicoes WHERE $field like '%$value%'";
		return (await customSelect(query).getSingleOrNull()) as GeraEfdContribuicoes;		 
	} 

	Future<GeraEfdContribuicoesGrouped?> getObjectGrouped({String? field, dynamic value}) async {
		final result = await getGroupedList(field: field, value: value);

		if (result.length != 1) {
			return null;
		} else {
			return result[0];
		} 
	}

	Future<int> insertObject(GeraEfdContribuicoesGrouped object) {
		return transaction(() async {
			final maxPk = await lastPk();
			object.geraEfdContribuicoes = object.geraEfdContribuicoes!.copyWith(id: Value(maxPk + 1));
			final pkInserted = await into(geraEfdContribuicoess).insert(object.geraEfdContribuicoes!);
			object.geraEfdContribuicoes = object.geraEfdContribuicoes!.copyWith(id: Value(pkInserted));			 
			await insertChildren(object);
			return pkInserted;
		});		
	}	 

	Future<bool> updateObject(GeraEfdContribuicoesGrouped object) {
		return transaction(() async {
			await deleteChildren(object);
			await insertChildren(object);
			return update(geraEfdContribuicoess).replace(object.geraEfdContribuicoes!);
		});	 
	} 

	Future<int> deleteObject(GeraEfdContribuicoesGrouped object) {
		return transaction(() async {
			await deleteChildren(object);
			return delete(geraEfdContribuicoess).delete(object.geraEfdContribuicoes!);
		});		
	}

	Future<void> insertChildren(GeraEfdContribuicoesGrouped object) async {
	}
	
	Future<void> deleteChildren(GeraEfdContribuicoesGrouped object) async {
	}

	Future<int> lastPk() async {
		final result = await customSelect("select MAX(id) as LAST from gera_efd_contribuicoes").getSingleOrNull();
		return result?.data["LAST"] ?? 0;
	} 
}