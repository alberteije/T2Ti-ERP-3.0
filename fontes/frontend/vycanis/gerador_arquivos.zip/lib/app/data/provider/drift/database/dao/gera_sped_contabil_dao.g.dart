// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'gera_sped_contabil_dao.dart';

// ignore_for_file: type=lint
mixin _$GeraSpedContabilDaoMixin on DatabaseAccessor<AppDatabase> {
  $GeraSpedContabilsTable get geraSpedContabils =>
      attachedDatabase.geraSpedContabils;
}
