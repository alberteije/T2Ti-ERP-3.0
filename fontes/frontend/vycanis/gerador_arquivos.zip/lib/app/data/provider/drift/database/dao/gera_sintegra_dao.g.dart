// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'gera_sintegra_dao.dart';

// ignore_for_file: type=lint
mixin _$GeraSintegraDaoMixin on DatabaseAccessor<AppDatabase> {
  $GeraSintegrasTable get geraSintegras => attachedDatabase.geraSintegras;
}
