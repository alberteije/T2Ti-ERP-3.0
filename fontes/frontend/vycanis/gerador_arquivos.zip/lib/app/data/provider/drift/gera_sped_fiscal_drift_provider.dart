import 'package:gerador_arquivos/app/data/provider/drift/database/database_imports.dart';
import 'package:gerador_arquivos/app/infra/infra_imports.dart';
import 'package:gerador_arquivos/app/data/provider/provider_base.dart';
import 'package:gerador_arquivos/app/data/provider/drift/database/database.dart';
import 'package:gerador_arquivos/app/data/model/model_imports.dart';
import 'package:gerador_arquivos/app/data/domain/domain_imports.dart';

class GeraSpedFiscalDriftProvider extends ProviderBase {

	Future<List<GeraSpedFiscalModel>?> getList({Filter? filter}) async {
		List<GeraSpedFiscalGrouped> geraSpedFiscalDriftList = [];

		try {
			if (filter != null && filter.field != null) {
				geraSpedFiscalDriftList = await Session.database.geraSpedFiscalDao.getGroupedList(field: filter.field, value: filter.value!);
			} else {
				geraSpedFiscalDriftList = await Session.database.geraSpedFiscalDao.getGroupedList(); 
			}
			if (geraSpedFiscalDriftList.isNotEmpty) {
				return toListModel(geraSpedFiscalDriftList);
			} else {
				return [];
			}			 
		} catch (e) {
			handleResultError(null, null, exception: e);
			return null;
		}
	}

	Future<GeraSpedFiscalModel?> getObject(dynamic pk) async {
		try {
			final result = await Session.database.geraSpedFiscalDao.getObjectGrouped(field: 'id', value: pk);
			return toModel(result);
		} catch (e) {
			handleResultError(null, null, exception: e);
		}
		return null;
	}

	Future<GeraSpedFiscalModel?>? insert(GeraSpedFiscalModel geraSpedFiscalModel) async {
		try {
			final lastPk = await Session.database.geraSpedFiscalDao.insertObject(toDrift(geraSpedFiscalModel));
			geraSpedFiscalModel.id = lastPk;
			return geraSpedFiscalModel;
		} catch (e) {
			handleResultError(null, null, exception: e);
		}
		return null;
	}

	Future<GeraSpedFiscalModel?>? update(GeraSpedFiscalModel geraSpedFiscalModel) async {
		try {
			await Session.database.geraSpedFiscalDao.updateObject(toDrift(geraSpedFiscalModel));
			return geraSpedFiscalModel;
		} catch (e) {
			handleResultError(null, null, exception: e);
		}
		return null;
	}

	Future<bool?> delete(dynamic pk) async {
		try {
			await Session.database.geraSpedFiscalDao.deleteObject(toDrift(GeraSpedFiscalModel(id: pk)));
			return true;
		} catch (e) {
			handleResultError(null, null, exception: e);
		}
		return null;
	}	

	List<GeraSpedFiscalModel> toListModel(List<GeraSpedFiscalGrouped> geraSpedFiscalDriftList) {
		List<GeraSpedFiscalModel> listModel = [];
		for (var geraSpedFiscalDrift in geraSpedFiscalDriftList) {
			listModel.add(toModel(geraSpedFiscalDrift)!);
		}
		return listModel;
	}	

	GeraSpedFiscalModel? toModel(GeraSpedFiscalGrouped? geraSpedFiscalDrift) {
		if (geraSpedFiscalDrift != null) {
			return GeraSpedFiscalModel(
				id: geraSpedFiscalDrift.geraSpedFiscal?.id,
				dataEmissao: geraSpedFiscalDrift.geraSpedFiscal?.dataEmissao,
				periodoInicial: geraSpedFiscalDrift.geraSpedFiscal?.periodoInicial,
				periodoFinal: geraSpedFiscalDrift.geraSpedFiscal?.periodoFinal,
				versaoLayout: geraSpedFiscalDrift.geraSpedFiscal?.versaoLayout,
				finalidadeArquivo: GeraSpedFiscalDomain.getFinalidadeArquivo(geraSpedFiscalDrift.geraSpedFiscal?.finalidadeArquivo),
				perfilApresentacao: GeraSpedFiscalDomain.getPerfilApresentacao(geraSpedFiscalDrift.geraSpedFiscal?.perfilApresentacao),
				inventario: GeraSpedFiscalDomain.getInventario(geraSpedFiscalDrift.geraSpedFiscal?.inventario),
				idEmpresa: geraSpedFiscalDrift.geraSpedFiscal?.idEmpresa,
				idContador: geraSpedFiscalDrift.geraSpedFiscal?.idContador,
			);
		} else {
			return null;
		}
	}


	GeraSpedFiscalGrouped toDrift(GeraSpedFiscalModel geraSpedFiscalModel) {
		return GeraSpedFiscalGrouped(
			geraSpedFiscal: GeraSpedFiscal(
				id: geraSpedFiscalModel.id,
				dataEmissao: geraSpedFiscalModel.dataEmissao,
				periodoInicial: geraSpedFiscalModel.periodoInicial,
				periodoFinal: geraSpedFiscalModel.periodoFinal,
				versaoLayout: geraSpedFiscalModel.versaoLayout,
				finalidadeArquivo: GeraSpedFiscalDomain.setFinalidadeArquivo(geraSpedFiscalModel.finalidadeArquivo),
				perfilApresentacao: GeraSpedFiscalDomain.setPerfilApresentacao(geraSpedFiscalModel.perfilApresentacao),
				inventario: GeraSpedFiscalDomain.setInventario(geraSpedFiscalModel.inventario),
				idEmpresa: geraSpedFiscalModel.idEmpresa,
				idContador: geraSpedFiscalModel.idContador,
			),
		);
	}

		
}
