// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'gera_sped_fiscal_dao.dart';

// ignore_for_file: type=lint
mixin _$GeraSpedFiscalDaoMixin on DatabaseAccessor<AppDatabase> {
  $GeraSpedFiscalsTable get geraSpedFiscals => attachedDatabase.geraSpedFiscals;
}
