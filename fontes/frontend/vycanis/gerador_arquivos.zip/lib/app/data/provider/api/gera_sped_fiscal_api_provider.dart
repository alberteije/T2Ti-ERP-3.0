import 'dart:convert';

import 'package:gerador_arquivos/app/data/provider/api/api_provider_base.dart';
import 'package:gerador_arquivos/app/data/model/model_imports.dart';

class GeraSpedFiscalApiProvider extends ApiProviderBase {
  static const _path = '/gera-sped-fiscal';

  Future<List<GeraSpedFiscalModel>?> getList({Filter? filter}) {
    return super.getListBase(
      '$_path/',
      (json) => GeraSpedFiscalModel.fromJson(json),
      filter: filter,
    );
  }

  Future<GeraSpedFiscalModel?> getObject(dynamic pk) {
    return super.getObjectBase(
      _path,
      pk,
      (json) => GeraSpedFiscalModel.fromJson(json),
    );
  }

  Future<GeraSpedFiscalModel?>? insert(GeraSpedFiscalModel model) {
    return super.insertBase(
      _path,
      model,
      (json) => GeraSpedFiscalModel.fromJson(json),
    );
  }

  Future<GeraSpedFiscalModel?>? update(GeraSpedFiscalModel model) {
    return super.updateBase(
      _path,
      model,
      (json) => GeraSpedFiscalModel.fromJson(json),
    );
  }

  Future<bool?> delete(dynamic pk) {
    return super.deleteBase(_path, pk);
  }

  Future<dynamic> gerarArquivo(GeraSpedFiscalModel geraSpedFiscalModel) async {
    try {
      final response = await ApiProviderBase.httpClient.post(
        Uri.tryParse('http://localhost:9000/api/sped/fiscal')!,
				headers: ApiProviderBase.headerRequisition(),
				body: geraSpedFiscalModel.objectEncodeJson(),
      );

      if (response.statusCode == 200 || response.statusCode == 201) {
        if (response.headers["content-type"]!.contains("html")) {
          handleResultError(response.body, response.headers);
          return null;
        } else {
          final resposta = response.body;
          return json.decode(resposta)["arquivo"];
        }
      } else if (response.statusCode == 418) {
        return json.decode(response.body)["message"];
      } else {
        handleResultError(response.body, response.headers);
        return null;
      }
    } on Exception catch (e) {
      handleResultError(null, null, exception: e);
    }
    return null;
  }

}
