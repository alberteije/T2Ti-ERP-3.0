import 'package:gerador_arquivos/app/data/provider/drift/database/database_imports.dart';
import 'package:gerador_arquivos/app/infra/infra_imports.dart';
import 'package:gerador_arquivos/app/data/provider/provider_base.dart';
import 'package:gerador_arquivos/app/data/provider/drift/database/database.dart';
import 'package:gerador_arquivos/app/data/model/model_imports.dart';
import 'package:gerador_arquivos/app/data/domain/domain_imports.dart';

class GeraEfdReinfDriftProvider extends ProviderBase {

	Future<List<GeraEfdReinfModel>?> getList({Filter? filter}) async {
		List<GeraEfdReinfGrouped> geraEfdReinfDriftList = [];

		try {
			if (filter != null && filter.field != null) {
				geraEfdReinfDriftList = await Session.database.geraEfdReinfDao.getGroupedList(field: filter.field, value: filter.value!);
			} else {
				geraEfdReinfDriftList = await Session.database.geraEfdReinfDao.getGroupedList(); 
			}
			if (geraEfdReinfDriftList.isNotEmpty) {
				return toListModel(geraEfdReinfDriftList);
			} else {
				return [];
			}			 
		} catch (e) {
			handleResultError(null, null, exception: e);
			return null;
		}
	}

	Future<GeraEfdReinfModel?> getObject(dynamic pk) async {
		try {
			final result = await Session.database.geraEfdReinfDao.getObjectGrouped(field: 'id', value: pk);
			return toModel(result);
		} catch (e) {
			handleResultError(null, null, exception: e);
		}
		return null;
	}

	Future<GeraEfdReinfModel?>? insert(GeraEfdReinfModel geraEfdReinfModel) async {
		try {
			final lastPk = await Session.database.geraEfdReinfDao.insertObject(toDrift(geraEfdReinfModel));
			geraEfdReinfModel.id = lastPk;
			return geraEfdReinfModel;
		} catch (e) {
			handleResultError(null, null, exception: e);
		}
		return null;
	}

	Future<GeraEfdReinfModel?>? update(GeraEfdReinfModel geraEfdReinfModel) async {
		try {
			await Session.database.geraEfdReinfDao.updateObject(toDrift(geraEfdReinfModel));
			return geraEfdReinfModel;
		} catch (e) {
			handleResultError(null, null, exception: e);
		}
		return null;
	}

	Future<bool?> delete(dynamic pk) async {
		try {
			await Session.database.geraEfdReinfDao.deleteObject(toDrift(GeraEfdReinfModel(id: pk)));
			return true;
		} catch (e) {
			handleResultError(null, null, exception: e);
		}
		return null;
	}	

	List<GeraEfdReinfModel> toListModel(List<GeraEfdReinfGrouped> geraEfdReinfDriftList) {
		List<GeraEfdReinfModel> listModel = [];
		for (var geraEfdReinfDrift in geraEfdReinfDriftList) {
			listModel.add(toModel(geraEfdReinfDrift)!);
		}
		return listModel;
	}	

	GeraEfdReinfModel? toModel(GeraEfdReinfGrouped? geraEfdReinfDrift) {
		if (geraEfdReinfDrift != null) {
			return GeraEfdReinfModel(
				id: geraEfdReinfDrift.geraEfdReinf?.id,
				dataEmissao: geraEfdReinfDrift.geraEfdReinf?.dataEmissao,
				periodoInicial: geraEfdReinfDrift.geraEfdReinf?.periodoInicial,
				periodoFinal: geraEfdReinfDrift.geraEfdReinf?.periodoFinal,
				tipoEvento: GeraEfdReinfDomain.getTipoEvento(geraEfdReinfDrift.geraEfdReinf?.tipoEvento),
				ambiente: GeraEfdReinfDomain.getAmbiente(geraEfdReinfDrift.geraEfdReinf?.ambiente),
				idEmpresa: geraEfdReinfDrift.geraEfdReinf?.idEmpresa,
				idContador: geraEfdReinfDrift.geraEfdReinf?.idContador,
			);
		} else {
			return null;
		}
	}


	GeraEfdReinfGrouped toDrift(GeraEfdReinfModel geraEfdReinfModel) {
		return GeraEfdReinfGrouped(
			geraEfdReinf: GeraEfdReinf(
				id: geraEfdReinfModel.id,
				dataEmissao: geraEfdReinfModel.dataEmissao,
				periodoInicial: geraEfdReinfModel.periodoInicial,
				periodoFinal: geraEfdReinfModel.periodoFinal,
				tipoEvento: GeraEfdReinfDomain.setTipoEvento(geraEfdReinfModel.tipoEvento),
				ambiente: GeraEfdReinfDomain.setAmbiente(geraEfdReinfModel.ambiente),
				idEmpresa: geraEfdReinfModel.idEmpresa,
				idContador: geraEfdReinfModel.idContador,
			),
		);
	}

		
}
