import 'package:drift/drift.dart';
import 'package:gerador_arquivos/app/data/provider/drift/database/database.dart';

@DataClassName("GeraSintegra")
class GeraSintegras extends Table {
	@override
	String get tableName => 'gera_sintegra';

	IntColumn get id => integer().named('id').nullable()();
	DateTimeColumn get dataEmissao => dateTime().named('data_emissao').nullable()();
	DateTimeColumn get periodoInicial => dateTime().named('periodo_inicial').nullable()();
	DateTimeColumn get periodoFinal => dateTime().named('periodo_final').nullable()();
	TextColumn get codigoConvenio => text().named('codigo_convenio').withLength(min: 0, max: 1).nullable()();
	TextColumn get finalidadeArquivo => text().named('finalidade_arquivo').withLength(min: 0, max: 1).nullable()();
	TextColumn get naturezaInformacoes => text().named('natureza_informacoes').withLength(min: 0, max: 1).nullable()();
	TextColumn get inventario => text().named('inventario').withLength(min: 0, max: 1).nullable()();
	IntColumn get idEmpresa => integer().named('id_empresa').nullable()();
	IntColumn get idContador => integer().named('id_contador').nullable()();

	@override
	Set<Column> get primaryKey => { id };	
	
}

class GeraSintegraGrouped {
	GeraSintegra? geraSintegra; 

  GeraSintegraGrouped({
		this.geraSintegra, 

  });
}
