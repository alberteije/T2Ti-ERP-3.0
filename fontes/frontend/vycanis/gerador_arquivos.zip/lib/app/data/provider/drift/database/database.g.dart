// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'database.dart';

// ignore_for_file: type=lint
class $GeraSpedContabilsTable extends GeraSpedContabils
    with TableInfo<$GeraSpedContabilsTable, GeraSpedContabil> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $GeraSpedContabilsTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
    'id',
    aliasedName,
    true,
    type: DriftSqlType.int,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _dataEmissaoMeta = const VerificationMeta(
    'dataEmissao',
  );
  @override
  late final GeneratedColumn<DateTime> dataEmissao = GeneratedColumn<DateTime>(
    'data_emissao',
    aliasedName,
    true,
    type: DriftSqlType.dateTime,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _periodoInicialMeta = const VerificationMeta(
    'periodoInicial',
  );
  @override
  late final GeneratedColumn<DateTime> periodoInicial =
      GeneratedColumn<DateTime>(
        'periodo_inicial',
        aliasedName,
        true,
        type: DriftSqlType.dateTime,
        requiredDuringInsert: false,
      );
  static const VerificationMeta _periodoFinalMeta = const VerificationMeta(
    'periodoFinal',
  );
  @override
  late final GeneratedColumn<DateTime> periodoFinal = GeneratedColumn<DateTime>(
    'periodo_final',
    aliasedName,
    true,
    type: DriftSqlType.dateTime,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _formaEscrituracaoMeta = const VerificationMeta(
    'formaEscrituracao',
  );
  @override
  late final GeneratedColumn<String> formaEscrituracao =
      GeneratedColumn<String>(
        'forma_escrituracao',
        aliasedName,
        true,
        additionalChecks: GeneratedColumn.checkTextLength(
          minTextLength: 0,
          maxTextLength: 1,
        ),
        type: DriftSqlType.string,
        requiredDuringInsert: false,
      );
  static const VerificationMeta _versaoLayoutMeta = const VerificationMeta(
    'versaoLayout',
  );
  @override
  late final GeneratedColumn<String> versaoLayout = GeneratedColumn<String>(
    'versao_layout',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 3,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _idEmpresaMeta = const VerificationMeta(
    'idEmpresa',
  );
  @override
  late final GeneratedColumn<int> idEmpresa = GeneratedColumn<int>(
    'id_empresa',
    aliasedName,
    true,
    type: DriftSqlType.int,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _idContadorMeta = const VerificationMeta(
    'idContador',
  );
  @override
  late final GeneratedColumn<int> idContador = GeneratedColumn<int>(
    'id_contador',
    aliasedName,
    true,
    type: DriftSqlType.int,
    requiredDuringInsert: false,
  );
  @override
  List<GeneratedColumn> get $columns => [
    id,
    dataEmissao,
    periodoInicial,
    periodoFinal,
    formaEscrituracao,
    versaoLayout,
    idEmpresa,
    idContador,
  ];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'gera_sped_contabil';
  @override
  VerificationContext validateIntegrity(
    Insertable<GeraSpedContabil> instance, {
    bool isInserting = false,
  }) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('data_emissao')) {
      context.handle(
        _dataEmissaoMeta,
        dataEmissao.isAcceptableOrUnknown(
          data['data_emissao']!,
          _dataEmissaoMeta,
        ),
      );
    }
    if (data.containsKey('periodo_inicial')) {
      context.handle(
        _periodoInicialMeta,
        periodoInicial.isAcceptableOrUnknown(
          data['periodo_inicial']!,
          _periodoInicialMeta,
        ),
      );
    }
    if (data.containsKey('periodo_final')) {
      context.handle(
        _periodoFinalMeta,
        periodoFinal.isAcceptableOrUnknown(
          data['periodo_final']!,
          _periodoFinalMeta,
        ),
      );
    }
    if (data.containsKey('forma_escrituracao')) {
      context.handle(
        _formaEscrituracaoMeta,
        formaEscrituracao.isAcceptableOrUnknown(
          data['forma_escrituracao']!,
          _formaEscrituracaoMeta,
        ),
      );
    }
    if (data.containsKey('versao_layout')) {
      context.handle(
        _versaoLayoutMeta,
        versaoLayout.isAcceptableOrUnknown(
          data['versao_layout']!,
          _versaoLayoutMeta,
        ),
      );
    }
    if (data.containsKey('id_empresa')) {
      context.handle(
        _idEmpresaMeta,
        idEmpresa.isAcceptableOrUnknown(data['id_empresa']!, _idEmpresaMeta),
      );
    }
    if (data.containsKey('id_contador')) {
      context.handle(
        _idContadorMeta,
        idContador.isAcceptableOrUnknown(data['id_contador']!, _idContadorMeta),
      );
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  GeraSpedContabil map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return GeraSpedContabil(
      id: attachedDatabase.typeMapping.read(
        DriftSqlType.int,
        data['${effectivePrefix}id'],
      ),
      dataEmissao: attachedDatabase.typeMapping.read(
        DriftSqlType.dateTime,
        data['${effectivePrefix}data_emissao'],
      ),
      periodoInicial: attachedDatabase.typeMapping.read(
        DriftSqlType.dateTime,
        data['${effectivePrefix}periodo_inicial'],
      ),
      periodoFinal: attachedDatabase.typeMapping.read(
        DriftSqlType.dateTime,
        data['${effectivePrefix}periodo_final'],
      ),
      formaEscrituracao: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}forma_escrituracao'],
      ),
      versaoLayout: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}versao_layout'],
      ),
      idEmpresa: attachedDatabase.typeMapping.read(
        DriftSqlType.int,
        data['${effectivePrefix}id_empresa'],
      ),
      idContador: attachedDatabase.typeMapping.read(
        DriftSqlType.int,
        data['${effectivePrefix}id_contador'],
      ),
    );
  }

  @override
  $GeraSpedContabilsTable createAlias(String alias) {
    return $GeraSpedContabilsTable(attachedDatabase, alias);
  }
}

class GeraSpedContabil extends DataClass
    implements Insertable<GeraSpedContabil> {
  final int? id;
  final DateTime? dataEmissao;
  final DateTime? periodoInicial;
  final DateTime? periodoFinal;
  final String? formaEscrituracao;
  final String? versaoLayout;
  final int? idEmpresa;
  final int? idContador;
  const GeraSpedContabil({
    this.id,
    this.dataEmissao,
    this.periodoInicial,
    this.periodoFinal,
    this.formaEscrituracao,
    this.versaoLayout,
    this.idEmpresa,
    this.idContador,
  });
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || dataEmissao != null) {
      map['data_emissao'] = Variable<DateTime>(dataEmissao);
    }
    if (!nullToAbsent || periodoInicial != null) {
      map['periodo_inicial'] = Variable<DateTime>(periodoInicial);
    }
    if (!nullToAbsent || periodoFinal != null) {
      map['periodo_final'] = Variable<DateTime>(periodoFinal);
    }
    if (!nullToAbsent || formaEscrituracao != null) {
      map['forma_escrituracao'] = Variable<String>(formaEscrituracao);
    }
    if (!nullToAbsent || versaoLayout != null) {
      map['versao_layout'] = Variable<String>(versaoLayout);
    }
    if (!nullToAbsent || idEmpresa != null) {
      map['id_empresa'] = Variable<int>(idEmpresa);
    }
    if (!nullToAbsent || idContador != null) {
      map['id_contador'] = Variable<int>(idContador);
    }
    return map;
  }

  factory GeraSpedContabil.fromJson(
    Map<String, dynamic> json, {
    ValueSerializer? serializer,
  }) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return GeraSpedContabil(
      id: serializer.fromJson<int?>(json['id']),
      dataEmissao: serializer.fromJson<DateTime?>(json['dataEmissao']),
      periodoInicial: serializer.fromJson<DateTime?>(json['periodoInicial']),
      periodoFinal: serializer.fromJson<DateTime?>(json['periodoFinal']),
      formaEscrituracao: serializer.fromJson<String?>(
        json['formaEscrituracao'],
      ),
      versaoLayout: serializer.fromJson<String?>(json['versaoLayout']),
      idEmpresa: serializer.fromJson<int?>(json['idEmpresa']),
      idContador: serializer.fromJson<int?>(json['idContador']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'dataEmissao': serializer.toJson<DateTime?>(dataEmissao),
      'periodoInicial': serializer.toJson<DateTime?>(periodoInicial),
      'periodoFinal': serializer.toJson<DateTime?>(periodoFinal),
      'formaEscrituracao': serializer.toJson<String?>(formaEscrituracao),
      'versaoLayout': serializer.toJson<String?>(versaoLayout),
      'idEmpresa': serializer.toJson<int?>(idEmpresa),
      'idContador': serializer.toJson<int?>(idContador),
    };
  }

  GeraSpedContabil copyWith({
    Value<int?> id = const Value.absent(),
    Value<DateTime?> dataEmissao = const Value.absent(),
    Value<DateTime?> periodoInicial = const Value.absent(),
    Value<DateTime?> periodoFinal = const Value.absent(),
    Value<String?> formaEscrituracao = const Value.absent(),
    Value<String?> versaoLayout = const Value.absent(),
    Value<int?> idEmpresa = const Value.absent(),
    Value<int?> idContador = const Value.absent(),
  }) => GeraSpedContabil(
    id: id.present ? id.value : this.id,
    dataEmissao: dataEmissao.present ? dataEmissao.value : this.dataEmissao,
    periodoInicial:
        periodoInicial.present ? periodoInicial.value : this.periodoInicial,
    periodoFinal: periodoFinal.present ? periodoFinal.value : this.periodoFinal,
    formaEscrituracao:
        formaEscrituracao.present
            ? formaEscrituracao.value
            : this.formaEscrituracao,
    versaoLayout: versaoLayout.present ? versaoLayout.value : this.versaoLayout,
    idEmpresa: idEmpresa.present ? idEmpresa.value : this.idEmpresa,
    idContador: idContador.present ? idContador.value : this.idContador,
  );
  GeraSpedContabil copyWithCompanion(GeraSpedContabilsCompanion data) {
    return GeraSpedContabil(
      id: data.id.present ? data.id.value : this.id,
      dataEmissao:
          data.dataEmissao.present ? data.dataEmissao.value : this.dataEmissao,
      periodoInicial:
          data.periodoInicial.present
              ? data.periodoInicial.value
              : this.periodoInicial,
      periodoFinal:
          data.periodoFinal.present
              ? data.periodoFinal.value
              : this.periodoFinal,
      formaEscrituracao:
          data.formaEscrituracao.present
              ? data.formaEscrituracao.value
              : this.formaEscrituracao,
      versaoLayout:
          data.versaoLayout.present
              ? data.versaoLayout.value
              : this.versaoLayout,
      idEmpresa: data.idEmpresa.present ? data.idEmpresa.value : this.idEmpresa,
      idContador:
          data.idContador.present ? data.idContador.value : this.idContador,
    );
  }

  @override
  String toString() {
    return (StringBuffer('GeraSpedContabil(')
          ..write('id: $id, ')
          ..write('dataEmissao: $dataEmissao, ')
          ..write('periodoInicial: $periodoInicial, ')
          ..write('periodoFinal: $periodoFinal, ')
          ..write('formaEscrituracao: $formaEscrituracao, ')
          ..write('versaoLayout: $versaoLayout, ')
          ..write('idEmpresa: $idEmpresa, ')
          ..write('idContador: $idContador')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(
    id,
    dataEmissao,
    periodoInicial,
    periodoFinal,
    formaEscrituracao,
    versaoLayout,
    idEmpresa,
    idContador,
  );
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is GeraSpedContabil &&
          other.id == this.id &&
          other.dataEmissao == this.dataEmissao &&
          other.periodoInicial == this.periodoInicial &&
          other.periodoFinal == this.periodoFinal &&
          other.formaEscrituracao == this.formaEscrituracao &&
          other.versaoLayout == this.versaoLayout &&
          other.idEmpresa == this.idEmpresa &&
          other.idContador == this.idContador);
}

class GeraSpedContabilsCompanion extends UpdateCompanion<GeraSpedContabil> {
  final Value<int?> id;
  final Value<DateTime?> dataEmissao;
  final Value<DateTime?> periodoInicial;
  final Value<DateTime?> periodoFinal;
  final Value<String?> formaEscrituracao;
  final Value<String?> versaoLayout;
  final Value<int?> idEmpresa;
  final Value<int?> idContador;
  const GeraSpedContabilsCompanion({
    this.id = const Value.absent(),
    this.dataEmissao = const Value.absent(),
    this.periodoInicial = const Value.absent(),
    this.periodoFinal = const Value.absent(),
    this.formaEscrituracao = const Value.absent(),
    this.versaoLayout = const Value.absent(),
    this.idEmpresa = const Value.absent(),
    this.idContador = const Value.absent(),
  });
  GeraSpedContabilsCompanion.insert({
    this.id = const Value.absent(),
    this.dataEmissao = const Value.absent(),
    this.periodoInicial = const Value.absent(),
    this.periodoFinal = const Value.absent(),
    this.formaEscrituracao = const Value.absent(),
    this.versaoLayout = const Value.absent(),
    this.idEmpresa = const Value.absent(),
    this.idContador = const Value.absent(),
  });
  static Insertable<GeraSpedContabil> custom({
    Expression<int>? id,
    Expression<DateTime>? dataEmissao,
    Expression<DateTime>? periodoInicial,
    Expression<DateTime>? periodoFinal,
    Expression<String>? formaEscrituracao,
    Expression<String>? versaoLayout,
    Expression<int>? idEmpresa,
    Expression<int>? idContador,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (dataEmissao != null) 'data_emissao': dataEmissao,
      if (periodoInicial != null) 'periodo_inicial': periodoInicial,
      if (periodoFinal != null) 'periodo_final': periodoFinal,
      if (formaEscrituracao != null) 'forma_escrituracao': formaEscrituracao,
      if (versaoLayout != null) 'versao_layout': versaoLayout,
      if (idEmpresa != null) 'id_empresa': idEmpresa,
      if (idContador != null) 'id_contador': idContador,
    });
  }

  GeraSpedContabilsCompanion copyWith({
    Value<int?>? id,
    Value<DateTime?>? dataEmissao,
    Value<DateTime?>? periodoInicial,
    Value<DateTime?>? periodoFinal,
    Value<String?>? formaEscrituracao,
    Value<String?>? versaoLayout,
    Value<int?>? idEmpresa,
    Value<int?>? idContador,
  }) {
    return GeraSpedContabilsCompanion(
      id: id ?? this.id,
      dataEmissao: dataEmissao ?? this.dataEmissao,
      periodoInicial: periodoInicial ?? this.periodoInicial,
      periodoFinal: periodoFinal ?? this.periodoFinal,
      formaEscrituracao: formaEscrituracao ?? this.formaEscrituracao,
      versaoLayout: versaoLayout ?? this.versaoLayout,
      idEmpresa: idEmpresa ?? this.idEmpresa,
      idContador: idContador ?? this.idContador,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (dataEmissao.present) {
      map['data_emissao'] = Variable<DateTime>(dataEmissao.value);
    }
    if (periodoInicial.present) {
      map['periodo_inicial'] = Variable<DateTime>(periodoInicial.value);
    }
    if (periodoFinal.present) {
      map['periodo_final'] = Variable<DateTime>(periodoFinal.value);
    }
    if (formaEscrituracao.present) {
      map['forma_escrituracao'] = Variable<String>(formaEscrituracao.value);
    }
    if (versaoLayout.present) {
      map['versao_layout'] = Variable<String>(versaoLayout.value);
    }
    if (idEmpresa.present) {
      map['id_empresa'] = Variable<int>(idEmpresa.value);
    }
    if (idContador.present) {
      map['id_contador'] = Variable<int>(idContador.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('GeraSpedContabilsCompanion(')
          ..write('id: $id, ')
          ..write('dataEmissao: $dataEmissao, ')
          ..write('periodoInicial: $periodoInicial, ')
          ..write('periodoFinal: $periodoFinal, ')
          ..write('formaEscrituracao: $formaEscrituracao, ')
          ..write('versaoLayout: $versaoLayout, ')
          ..write('idEmpresa: $idEmpresa, ')
          ..write('idContador: $idContador')
          ..write(')'))
        .toString();
  }
}

class $ViewControleAcessosTable extends ViewControleAcessos
    with TableInfo<$ViewControleAcessosTable, ViewControleAcesso> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $ViewControleAcessosTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
    'id',
    aliasedName,
    true,
    type: DriftSqlType.int,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _idPessoaMeta = const VerificationMeta(
    'idPessoa',
  );
  @override
  late final GeneratedColumn<int> idPessoa = GeneratedColumn<int>(
    'id_pessoa',
    aliasedName,
    true,
    type: DriftSqlType.int,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _pessoaNomeMeta = const VerificationMeta(
    'pessoaNome',
  );
  @override
  late final GeneratedColumn<String> pessoaNome = GeneratedColumn<String>(
    'pessoa_nome',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 450,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _idColaboradorMeta = const VerificationMeta(
    'idColaborador',
  );
  @override
  late final GeneratedColumn<int> idColaborador = GeneratedColumn<int>(
    'id_colaborador',
    aliasedName,
    true,
    type: DriftSqlType.int,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _idUsuarioMeta = const VerificationMeta(
    'idUsuario',
  );
  @override
  late final GeneratedColumn<int> idUsuario = GeneratedColumn<int>(
    'id_usuario',
    aliasedName,
    true,
    type: DriftSqlType.int,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _administradorMeta = const VerificationMeta(
    'administrador',
  );
  @override
  late final GeneratedColumn<String> administrador = GeneratedColumn<String>(
    'administrador',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 3,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _idPapelMeta = const VerificationMeta(
    'idPapel',
  );
  @override
  late final GeneratedColumn<int> idPapel = GeneratedColumn<int>(
    'id_papel',
    aliasedName,
    true,
    type: DriftSqlType.int,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _papelNomeMeta = const VerificationMeta(
    'papelNome',
  );
  @override
  late final GeneratedColumn<String> papelNome = GeneratedColumn<String>(
    'papel_nome',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 300,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _papelDescricaoMeta = const VerificationMeta(
    'papelDescricao',
  );
  @override
  late final GeneratedColumn<String> papelDescricao = GeneratedColumn<String>(
    'papel_descricao',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 750,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _idFuncaoMeta = const VerificationMeta(
    'idFuncao',
  );
  @override
  late final GeneratedColumn<int> idFuncao = GeneratedColumn<int>(
    'id_funcao',
    aliasedName,
    true,
    type: DriftSqlType.int,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _funcaoNomeMeta = const VerificationMeta(
    'funcaoNome',
  );
  @override
  late final GeneratedColumn<String> funcaoNome = GeneratedColumn<String>(
    'funcao_nome',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 300,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _funcaoDescricaoMeta = const VerificationMeta(
    'funcaoDescricao',
  );
  @override
  late final GeneratedColumn<String> funcaoDescricao = GeneratedColumn<String>(
    'funcao_descricao',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 750,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _idPapelFuncaoMeta = const VerificationMeta(
    'idPapelFuncao',
  );
  @override
  late final GeneratedColumn<int> idPapelFuncao = GeneratedColumn<int>(
    'id_papel_funcao',
    aliasedName,
    true,
    type: DriftSqlType.int,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _habilitadoMeta = const VerificationMeta(
    'habilitado',
  );
  @override
  late final GeneratedColumn<String> habilitado = GeneratedColumn<String>(
    'habilitado',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 3,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _podeInserirMeta = const VerificationMeta(
    'podeInserir',
  );
  @override
  late final GeneratedColumn<String> podeInserir = GeneratedColumn<String>(
    'pode_inserir',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 3,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _podeAlterarMeta = const VerificationMeta(
    'podeAlterar',
  );
  @override
  late final GeneratedColumn<String> podeAlterar = GeneratedColumn<String>(
    'pode_alterar',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 3,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _podeExcluirMeta = const VerificationMeta(
    'podeExcluir',
  );
  @override
  late final GeneratedColumn<String> podeExcluir = GeneratedColumn<String>(
    'pode_excluir',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 3,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  @override
  List<GeneratedColumn> get $columns => [
    id,
    idPessoa,
    pessoaNome,
    idColaborador,
    idUsuario,
    administrador,
    idPapel,
    papelNome,
    papelDescricao,
    idFuncao,
    funcaoNome,
    funcaoDescricao,
    idPapelFuncao,
    habilitado,
    podeInserir,
    podeAlterar,
    podeExcluir,
  ];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'view_controle_acesso';
  @override
  VerificationContext validateIntegrity(
    Insertable<ViewControleAcesso> instance, {
    bool isInserting = false,
  }) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('id_pessoa')) {
      context.handle(
        _idPessoaMeta,
        idPessoa.isAcceptableOrUnknown(data['id_pessoa']!, _idPessoaMeta),
      );
    }
    if (data.containsKey('pessoa_nome')) {
      context.handle(
        _pessoaNomeMeta,
        pessoaNome.isAcceptableOrUnknown(data['pessoa_nome']!, _pessoaNomeMeta),
      );
    }
    if (data.containsKey('id_colaborador')) {
      context.handle(
        _idColaboradorMeta,
        idColaborador.isAcceptableOrUnknown(
          data['id_colaborador']!,
          _idColaboradorMeta,
        ),
      );
    }
    if (data.containsKey('id_usuario')) {
      context.handle(
        _idUsuarioMeta,
        idUsuario.isAcceptableOrUnknown(data['id_usuario']!, _idUsuarioMeta),
      );
    }
    if (data.containsKey('administrador')) {
      context.handle(
        _administradorMeta,
        administrador.isAcceptableOrUnknown(
          data['administrador']!,
          _administradorMeta,
        ),
      );
    }
    if (data.containsKey('id_papel')) {
      context.handle(
        _idPapelMeta,
        idPapel.isAcceptableOrUnknown(data['id_papel']!, _idPapelMeta),
      );
    }
    if (data.containsKey('papel_nome')) {
      context.handle(
        _papelNomeMeta,
        papelNome.isAcceptableOrUnknown(data['papel_nome']!, _papelNomeMeta),
      );
    }
    if (data.containsKey('papel_descricao')) {
      context.handle(
        _papelDescricaoMeta,
        papelDescricao.isAcceptableOrUnknown(
          data['papel_descricao']!,
          _papelDescricaoMeta,
        ),
      );
    }
    if (data.containsKey('id_funcao')) {
      context.handle(
        _idFuncaoMeta,
        idFuncao.isAcceptableOrUnknown(data['id_funcao']!, _idFuncaoMeta),
      );
    }
    if (data.containsKey('funcao_nome')) {
      context.handle(
        _funcaoNomeMeta,
        funcaoNome.isAcceptableOrUnknown(data['funcao_nome']!, _funcaoNomeMeta),
      );
    }
    if (data.containsKey('funcao_descricao')) {
      context.handle(
        _funcaoDescricaoMeta,
        funcaoDescricao.isAcceptableOrUnknown(
          data['funcao_descricao']!,
          _funcaoDescricaoMeta,
        ),
      );
    }
    if (data.containsKey('id_papel_funcao')) {
      context.handle(
        _idPapelFuncaoMeta,
        idPapelFuncao.isAcceptableOrUnknown(
          data['id_papel_funcao']!,
          _idPapelFuncaoMeta,
        ),
      );
    }
    if (data.containsKey('habilitado')) {
      context.handle(
        _habilitadoMeta,
        habilitado.isAcceptableOrUnknown(data['habilitado']!, _habilitadoMeta),
      );
    }
    if (data.containsKey('pode_inserir')) {
      context.handle(
        _podeInserirMeta,
        podeInserir.isAcceptableOrUnknown(
          data['pode_inserir']!,
          _podeInserirMeta,
        ),
      );
    }
    if (data.containsKey('pode_alterar')) {
      context.handle(
        _podeAlterarMeta,
        podeAlterar.isAcceptableOrUnknown(
          data['pode_alterar']!,
          _podeAlterarMeta,
        ),
      );
    }
    if (data.containsKey('pode_excluir')) {
      context.handle(
        _podeExcluirMeta,
        podeExcluir.isAcceptableOrUnknown(
          data['pode_excluir']!,
          _podeExcluirMeta,
        ),
      );
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  ViewControleAcesso map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return ViewControleAcesso(
      id: attachedDatabase.typeMapping.read(
        DriftSqlType.int,
        data['${effectivePrefix}id'],
      ),
      idPessoa: attachedDatabase.typeMapping.read(
        DriftSqlType.int,
        data['${effectivePrefix}id_pessoa'],
      ),
      pessoaNome: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}pessoa_nome'],
      ),
      idColaborador: attachedDatabase.typeMapping.read(
        DriftSqlType.int,
        data['${effectivePrefix}id_colaborador'],
      ),
      idUsuario: attachedDatabase.typeMapping.read(
        DriftSqlType.int,
        data['${effectivePrefix}id_usuario'],
      ),
      administrador: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}administrador'],
      ),
      idPapel: attachedDatabase.typeMapping.read(
        DriftSqlType.int,
        data['${effectivePrefix}id_papel'],
      ),
      papelNome: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}papel_nome'],
      ),
      papelDescricao: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}papel_descricao'],
      ),
      idFuncao: attachedDatabase.typeMapping.read(
        DriftSqlType.int,
        data['${effectivePrefix}id_funcao'],
      ),
      funcaoNome: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}funcao_nome'],
      ),
      funcaoDescricao: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}funcao_descricao'],
      ),
      idPapelFuncao: attachedDatabase.typeMapping.read(
        DriftSqlType.int,
        data['${effectivePrefix}id_papel_funcao'],
      ),
      habilitado: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}habilitado'],
      ),
      podeInserir: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}pode_inserir'],
      ),
      podeAlterar: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}pode_alterar'],
      ),
      podeExcluir: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}pode_excluir'],
      ),
    );
  }

  @override
  $ViewControleAcessosTable createAlias(String alias) {
    return $ViewControleAcessosTable(attachedDatabase, alias);
  }
}

class ViewControleAcesso extends DataClass
    implements Insertable<ViewControleAcesso> {
  final int? id;
  final int? idPessoa;
  final String? pessoaNome;
  final int? idColaborador;
  final int? idUsuario;
  final String? administrador;
  final int? idPapel;
  final String? papelNome;
  final String? papelDescricao;
  final int? idFuncao;
  final String? funcaoNome;
  final String? funcaoDescricao;
  final int? idPapelFuncao;
  final String? habilitado;
  final String? podeInserir;
  final String? podeAlterar;
  final String? podeExcluir;
  const ViewControleAcesso({
    this.id,
    this.idPessoa,
    this.pessoaNome,
    this.idColaborador,
    this.idUsuario,
    this.administrador,
    this.idPapel,
    this.papelNome,
    this.papelDescricao,
    this.idFuncao,
    this.funcaoNome,
    this.funcaoDescricao,
    this.idPapelFuncao,
    this.habilitado,
    this.podeInserir,
    this.podeAlterar,
    this.podeExcluir,
  });
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || idPessoa != null) {
      map['id_pessoa'] = Variable<int>(idPessoa);
    }
    if (!nullToAbsent || pessoaNome != null) {
      map['pessoa_nome'] = Variable<String>(pessoaNome);
    }
    if (!nullToAbsent || idColaborador != null) {
      map['id_colaborador'] = Variable<int>(idColaborador);
    }
    if (!nullToAbsent || idUsuario != null) {
      map['id_usuario'] = Variable<int>(idUsuario);
    }
    if (!nullToAbsent || administrador != null) {
      map['administrador'] = Variable<String>(administrador);
    }
    if (!nullToAbsent || idPapel != null) {
      map['id_papel'] = Variable<int>(idPapel);
    }
    if (!nullToAbsent || papelNome != null) {
      map['papel_nome'] = Variable<String>(papelNome);
    }
    if (!nullToAbsent || papelDescricao != null) {
      map['papel_descricao'] = Variable<String>(papelDescricao);
    }
    if (!nullToAbsent || idFuncao != null) {
      map['id_funcao'] = Variable<int>(idFuncao);
    }
    if (!nullToAbsent || funcaoNome != null) {
      map['funcao_nome'] = Variable<String>(funcaoNome);
    }
    if (!nullToAbsent || funcaoDescricao != null) {
      map['funcao_descricao'] = Variable<String>(funcaoDescricao);
    }
    if (!nullToAbsent || idPapelFuncao != null) {
      map['id_papel_funcao'] = Variable<int>(idPapelFuncao);
    }
    if (!nullToAbsent || habilitado != null) {
      map['habilitado'] = Variable<String>(habilitado);
    }
    if (!nullToAbsent || podeInserir != null) {
      map['pode_inserir'] = Variable<String>(podeInserir);
    }
    if (!nullToAbsent || podeAlterar != null) {
      map['pode_alterar'] = Variable<String>(podeAlterar);
    }
    if (!nullToAbsent || podeExcluir != null) {
      map['pode_excluir'] = Variable<String>(podeExcluir);
    }
    return map;
  }

  factory ViewControleAcesso.fromJson(
    Map<String, dynamic> json, {
    ValueSerializer? serializer,
  }) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return ViewControleAcesso(
      id: serializer.fromJson<int?>(json['id']),
      idPessoa: serializer.fromJson<int?>(json['idPessoa']),
      pessoaNome: serializer.fromJson<String?>(json['pessoaNome']),
      idColaborador: serializer.fromJson<int?>(json['idColaborador']),
      idUsuario: serializer.fromJson<int?>(json['idUsuario']),
      administrador: serializer.fromJson<String?>(json['administrador']),
      idPapel: serializer.fromJson<int?>(json['idPapel']),
      papelNome: serializer.fromJson<String?>(json['papelNome']),
      papelDescricao: serializer.fromJson<String?>(json['papelDescricao']),
      idFuncao: serializer.fromJson<int?>(json['idFuncao']),
      funcaoNome: serializer.fromJson<String?>(json['funcaoNome']),
      funcaoDescricao: serializer.fromJson<String?>(json['funcaoDescricao']),
      idPapelFuncao: serializer.fromJson<int?>(json['idPapelFuncao']),
      habilitado: serializer.fromJson<String?>(json['habilitado']),
      podeInserir: serializer.fromJson<String?>(json['podeInserir']),
      podeAlterar: serializer.fromJson<String?>(json['podeAlterar']),
      podeExcluir: serializer.fromJson<String?>(json['podeExcluir']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'idPessoa': serializer.toJson<int?>(idPessoa),
      'pessoaNome': serializer.toJson<String?>(pessoaNome),
      'idColaborador': serializer.toJson<int?>(idColaborador),
      'idUsuario': serializer.toJson<int?>(idUsuario),
      'administrador': serializer.toJson<String?>(administrador),
      'idPapel': serializer.toJson<int?>(idPapel),
      'papelNome': serializer.toJson<String?>(papelNome),
      'papelDescricao': serializer.toJson<String?>(papelDescricao),
      'idFuncao': serializer.toJson<int?>(idFuncao),
      'funcaoNome': serializer.toJson<String?>(funcaoNome),
      'funcaoDescricao': serializer.toJson<String?>(funcaoDescricao),
      'idPapelFuncao': serializer.toJson<int?>(idPapelFuncao),
      'habilitado': serializer.toJson<String?>(habilitado),
      'podeInserir': serializer.toJson<String?>(podeInserir),
      'podeAlterar': serializer.toJson<String?>(podeAlterar),
      'podeExcluir': serializer.toJson<String?>(podeExcluir),
    };
  }

  ViewControleAcesso copyWith({
    Value<int?> id = const Value.absent(),
    Value<int?> idPessoa = const Value.absent(),
    Value<String?> pessoaNome = const Value.absent(),
    Value<int?> idColaborador = const Value.absent(),
    Value<int?> idUsuario = const Value.absent(),
    Value<String?> administrador = const Value.absent(),
    Value<int?> idPapel = const Value.absent(),
    Value<String?> papelNome = const Value.absent(),
    Value<String?> papelDescricao = const Value.absent(),
    Value<int?> idFuncao = const Value.absent(),
    Value<String?> funcaoNome = const Value.absent(),
    Value<String?> funcaoDescricao = const Value.absent(),
    Value<int?> idPapelFuncao = const Value.absent(),
    Value<String?> habilitado = const Value.absent(),
    Value<String?> podeInserir = const Value.absent(),
    Value<String?> podeAlterar = const Value.absent(),
    Value<String?> podeExcluir = const Value.absent(),
  }) => ViewControleAcesso(
    id: id.present ? id.value : this.id,
    idPessoa: idPessoa.present ? idPessoa.value : this.idPessoa,
    pessoaNome: pessoaNome.present ? pessoaNome.value : this.pessoaNome,
    idColaborador:
        idColaborador.present ? idColaborador.value : this.idColaborador,
    idUsuario: idUsuario.present ? idUsuario.value : this.idUsuario,
    administrador:
        administrador.present ? administrador.value : this.administrador,
    idPapel: idPapel.present ? idPapel.value : this.idPapel,
    papelNome: papelNome.present ? papelNome.value : this.papelNome,
    papelDescricao:
        papelDescricao.present ? papelDescricao.value : this.papelDescricao,
    idFuncao: idFuncao.present ? idFuncao.value : this.idFuncao,
    funcaoNome: funcaoNome.present ? funcaoNome.value : this.funcaoNome,
    funcaoDescricao:
        funcaoDescricao.present ? funcaoDescricao.value : this.funcaoDescricao,
    idPapelFuncao:
        idPapelFuncao.present ? idPapelFuncao.value : this.idPapelFuncao,
    habilitado: habilitado.present ? habilitado.value : this.habilitado,
    podeInserir: podeInserir.present ? podeInserir.value : this.podeInserir,
    podeAlterar: podeAlterar.present ? podeAlterar.value : this.podeAlterar,
    podeExcluir: podeExcluir.present ? podeExcluir.value : this.podeExcluir,
  );
  ViewControleAcesso copyWithCompanion(ViewControleAcessosCompanion data) {
    return ViewControleAcesso(
      id: data.id.present ? data.id.value : this.id,
      idPessoa: data.idPessoa.present ? data.idPessoa.value : this.idPessoa,
      pessoaNome:
          data.pessoaNome.present ? data.pessoaNome.value : this.pessoaNome,
      idColaborador:
          data.idColaborador.present
              ? data.idColaborador.value
              : this.idColaborador,
      idUsuario: data.idUsuario.present ? data.idUsuario.value : this.idUsuario,
      administrador:
          data.administrador.present
              ? data.administrador.value
              : this.administrador,
      idPapel: data.idPapel.present ? data.idPapel.value : this.idPapel,
      papelNome: data.papelNome.present ? data.papelNome.value : this.papelNome,
      papelDescricao:
          data.papelDescricao.present
              ? data.papelDescricao.value
              : this.papelDescricao,
      idFuncao: data.idFuncao.present ? data.idFuncao.value : this.idFuncao,
      funcaoNome:
          data.funcaoNome.present ? data.funcaoNome.value : this.funcaoNome,
      funcaoDescricao:
          data.funcaoDescricao.present
              ? data.funcaoDescricao.value
              : this.funcaoDescricao,
      idPapelFuncao:
          data.idPapelFuncao.present
              ? data.idPapelFuncao.value
              : this.idPapelFuncao,
      habilitado:
          data.habilitado.present ? data.habilitado.value : this.habilitado,
      podeInserir:
          data.podeInserir.present ? data.podeInserir.value : this.podeInserir,
      podeAlterar:
          data.podeAlterar.present ? data.podeAlterar.value : this.podeAlterar,
      podeExcluir:
          data.podeExcluir.present ? data.podeExcluir.value : this.podeExcluir,
    );
  }

  @override
  String toString() {
    return (StringBuffer('ViewControleAcesso(')
          ..write('id: $id, ')
          ..write('idPessoa: $idPessoa, ')
          ..write('pessoaNome: $pessoaNome, ')
          ..write('idColaborador: $idColaborador, ')
          ..write('idUsuario: $idUsuario, ')
          ..write('administrador: $administrador, ')
          ..write('idPapel: $idPapel, ')
          ..write('papelNome: $papelNome, ')
          ..write('papelDescricao: $papelDescricao, ')
          ..write('idFuncao: $idFuncao, ')
          ..write('funcaoNome: $funcaoNome, ')
          ..write('funcaoDescricao: $funcaoDescricao, ')
          ..write('idPapelFuncao: $idPapelFuncao, ')
          ..write('habilitado: $habilitado, ')
          ..write('podeInserir: $podeInserir, ')
          ..write('podeAlterar: $podeAlterar, ')
          ..write('podeExcluir: $podeExcluir')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(
    id,
    idPessoa,
    pessoaNome,
    idColaborador,
    idUsuario,
    administrador,
    idPapel,
    papelNome,
    papelDescricao,
    idFuncao,
    funcaoNome,
    funcaoDescricao,
    idPapelFuncao,
    habilitado,
    podeInserir,
    podeAlterar,
    podeExcluir,
  );
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is ViewControleAcesso &&
          other.id == this.id &&
          other.idPessoa == this.idPessoa &&
          other.pessoaNome == this.pessoaNome &&
          other.idColaborador == this.idColaborador &&
          other.idUsuario == this.idUsuario &&
          other.administrador == this.administrador &&
          other.idPapel == this.idPapel &&
          other.papelNome == this.papelNome &&
          other.papelDescricao == this.papelDescricao &&
          other.idFuncao == this.idFuncao &&
          other.funcaoNome == this.funcaoNome &&
          other.funcaoDescricao == this.funcaoDescricao &&
          other.idPapelFuncao == this.idPapelFuncao &&
          other.habilitado == this.habilitado &&
          other.podeInserir == this.podeInserir &&
          other.podeAlterar == this.podeAlterar &&
          other.podeExcluir == this.podeExcluir);
}

class ViewControleAcessosCompanion extends UpdateCompanion<ViewControleAcesso> {
  final Value<int?> id;
  final Value<int?> idPessoa;
  final Value<String?> pessoaNome;
  final Value<int?> idColaborador;
  final Value<int?> idUsuario;
  final Value<String?> administrador;
  final Value<int?> idPapel;
  final Value<String?> papelNome;
  final Value<String?> papelDescricao;
  final Value<int?> idFuncao;
  final Value<String?> funcaoNome;
  final Value<String?> funcaoDescricao;
  final Value<int?> idPapelFuncao;
  final Value<String?> habilitado;
  final Value<String?> podeInserir;
  final Value<String?> podeAlterar;
  final Value<String?> podeExcluir;
  const ViewControleAcessosCompanion({
    this.id = const Value.absent(),
    this.idPessoa = const Value.absent(),
    this.pessoaNome = const Value.absent(),
    this.idColaborador = const Value.absent(),
    this.idUsuario = const Value.absent(),
    this.administrador = const Value.absent(),
    this.idPapel = const Value.absent(),
    this.papelNome = const Value.absent(),
    this.papelDescricao = const Value.absent(),
    this.idFuncao = const Value.absent(),
    this.funcaoNome = const Value.absent(),
    this.funcaoDescricao = const Value.absent(),
    this.idPapelFuncao = const Value.absent(),
    this.habilitado = const Value.absent(),
    this.podeInserir = const Value.absent(),
    this.podeAlterar = const Value.absent(),
    this.podeExcluir = const Value.absent(),
  });
  ViewControleAcessosCompanion.insert({
    this.id = const Value.absent(),
    this.idPessoa = const Value.absent(),
    this.pessoaNome = const Value.absent(),
    this.idColaborador = const Value.absent(),
    this.idUsuario = const Value.absent(),
    this.administrador = const Value.absent(),
    this.idPapel = const Value.absent(),
    this.papelNome = const Value.absent(),
    this.papelDescricao = const Value.absent(),
    this.idFuncao = const Value.absent(),
    this.funcaoNome = const Value.absent(),
    this.funcaoDescricao = const Value.absent(),
    this.idPapelFuncao = const Value.absent(),
    this.habilitado = const Value.absent(),
    this.podeInserir = const Value.absent(),
    this.podeAlterar = const Value.absent(),
    this.podeExcluir = const Value.absent(),
  });
  static Insertable<ViewControleAcesso> custom({
    Expression<int>? id,
    Expression<int>? idPessoa,
    Expression<String>? pessoaNome,
    Expression<int>? idColaborador,
    Expression<int>? idUsuario,
    Expression<String>? administrador,
    Expression<int>? idPapel,
    Expression<String>? papelNome,
    Expression<String>? papelDescricao,
    Expression<int>? idFuncao,
    Expression<String>? funcaoNome,
    Expression<String>? funcaoDescricao,
    Expression<int>? idPapelFuncao,
    Expression<String>? habilitado,
    Expression<String>? podeInserir,
    Expression<String>? podeAlterar,
    Expression<String>? podeExcluir,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (idPessoa != null) 'id_pessoa': idPessoa,
      if (pessoaNome != null) 'pessoa_nome': pessoaNome,
      if (idColaborador != null) 'id_colaborador': idColaborador,
      if (idUsuario != null) 'id_usuario': idUsuario,
      if (administrador != null) 'administrador': administrador,
      if (idPapel != null) 'id_papel': idPapel,
      if (papelNome != null) 'papel_nome': papelNome,
      if (papelDescricao != null) 'papel_descricao': papelDescricao,
      if (idFuncao != null) 'id_funcao': idFuncao,
      if (funcaoNome != null) 'funcao_nome': funcaoNome,
      if (funcaoDescricao != null) 'funcao_descricao': funcaoDescricao,
      if (idPapelFuncao != null) 'id_papel_funcao': idPapelFuncao,
      if (habilitado != null) 'habilitado': habilitado,
      if (podeInserir != null) 'pode_inserir': podeInserir,
      if (podeAlterar != null) 'pode_alterar': podeAlterar,
      if (podeExcluir != null) 'pode_excluir': podeExcluir,
    });
  }

  ViewControleAcessosCompanion copyWith({
    Value<int?>? id,
    Value<int?>? idPessoa,
    Value<String?>? pessoaNome,
    Value<int?>? idColaborador,
    Value<int?>? idUsuario,
    Value<String?>? administrador,
    Value<int?>? idPapel,
    Value<String?>? papelNome,
    Value<String?>? papelDescricao,
    Value<int?>? idFuncao,
    Value<String?>? funcaoNome,
    Value<String?>? funcaoDescricao,
    Value<int?>? idPapelFuncao,
    Value<String?>? habilitado,
    Value<String?>? podeInserir,
    Value<String?>? podeAlterar,
    Value<String?>? podeExcluir,
  }) {
    return ViewControleAcessosCompanion(
      id: id ?? this.id,
      idPessoa: idPessoa ?? this.idPessoa,
      pessoaNome: pessoaNome ?? this.pessoaNome,
      idColaborador: idColaborador ?? this.idColaborador,
      idUsuario: idUsuario ?? this.idUsuario,
      administrador: administrador ?? this.administrador,
      idPapel: idPapel ?? this.idPapel,
      papelNome: papelNome ?? this.papelNome,
      papelDescricao: papelDescricao ?? this.papelDescricao,
      idFuncao: idFuncao ?? this.idFuncao,
      funcaoNome: funcaoNome ?? this.funcaoNome,
      funcaoDescricao: funcaoDescricao ?? this.funcaoDescricao,
      idPapelFuncao: idPapelFuncao ?? this.idPapelFuncao,
      habilitado: habilitado ?? this.habilitado,
      podeInserir: podeInserir ?? this.podeInserir,
      podeAlterar: podeAlterar ?? this.podeAlterar,
      podeExcluir: podeExcluir ?? this.podeExcluir,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (idPessoa.present) {
      map['id_pessoa'] = Variable<int>(idPessoa.value);
    }
    if (pessoaNome.present) {
      map['pessoa_nome'] = Variable<String>(pessoaNome.value);
    }
    if (idColaborador.present) {
      map['id_colaborador'] = Variable<int>(idColaborador.value);
    }
    if (idUsuario.present) {
      map['id_usuario'] = Variable<int>(idUsuario.value);
    }
    if (administrador.present) {
      map['administrador'] = Variable<String>(administrador.value);
    }
    if (idPapel.present) {
      map['id_papel'] = Variable<int>(idPapel.value);
    }
    if (papelNome.present) {
      map['papel_nome'] = Variable<String>(papelNome.value);
    }
    if (papelDescricao.present) {
      map['papel_descricao'] = Variable<String>(papelDescricao.value);
    }
    if (idFuncao.present) {
      map['id_funcao'] = Variable<int>(idFuncao.value);
    }
    if (funcaoNome.present) {
      map['funcao_nome'] = Variable<String>(funcaoNome.value);
    }
    if (funcaoDescricao.present) {
      map['funcao_descricao'] = Variable<String>(funcaoDescricao.value);
    }
    if (idPapelFuncao.present) {
      map['id_papel_funcao'] = Variable<int>(idPapelFuncao.value);
    }
    if (habilitado.present) {
      map['habilitado'] = Variable<String>(habilitado.value);
    }
    if (podeInserir.present) {
      map['pode_inserir'] = Variable<String>(podeInserir.value);
    }
    if (podeAlterar.present) {
      map['pode_alterar'] = Variable<String>(podeAlterar.value);
    }
    if (podeExcluir.present) {
      map['pode_excluir'] = Variable<String>(podeExcluir.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('ViewControleAcessosCompanion(')
          ..write('id: $id, ')
          ..write('idPessoa: $idPessoa, ')
          ..write('pessoaNome: $pessoaNome, ')
          ..write('idColaborador: $idColaborador, ')
          ..write('idUsuario: $idUsuario, ')
          ..write('administrador: $administrador, ')
          ..write('idPapel: $idPapel, ')
          ..write('papelNome: $papelNome, ')
          ..write('papelDescricao: $papelDescricao, ')
          ..write('idFuncao: $idFuncao, ')
          ..write('funcaoNome: $funcaoNome, ')
          ..write('funcaoDescricao: $funcaoDescricao, ')
          ..write('idPapelFuncao: $idPapelFuncao, ')
          ..write('habilitado: $habilitado, ')
          ..write('podeInserir: $podeInserir, ')
          ..write('podeAlterar: $podeAlterar, ')
          ..write('podeExcluir: $podeExcluir')
          ..write(')'))
        .toString();
  }
}

class $ViewPessoaUsuariosTable extends ViewPessoaUsuarios
    with TableInfo<$ViewPessoaUsuariosTable, ViewPessoaUsuario> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $ViewPessoaUsuariosTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
    'id',
    aliasedName,
    true,
    type: DriftSqlType.int,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _idPessoaMeta = const VerificationMeta(
    'idPessoa',
  );
  @override
  late final GeneratedColumn<int> idPessoa = GeneratedColumn<int>(
    'id_pessoa',
    aliasedName,
    true,
    type: DriftSqlType.int,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _pessoaNomeMeta = const VerificationMeta(
    'pessoaNome',
  );
  @override
  late final GeneratedColumn<String> pessoaNome = GeneratedColumn<String>(
    'pessoa_nome',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 450,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _tipoMeta = const VerificationMeta('tipo');
  @override
  late final GeneratedColumn<String> tipo = GeneratedColumn<String>(
    'tipo',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 3,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _emailMeta = const VerificationMeta('email');
  @override
  late final GeneratedColumn<String> email = GeneratedColumn<String>(
    'email',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 750,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _idColaboradorMeta = const VerificationMeta(
    'idColaborador',
  );
  @override
  late final GeneratedColumn<int> idColaborador = GeneratedColumn<int>(
    'id_colaborador',
    aliasedName,
    true,
    type: DriftSqlType.int,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _idUsuarioMeta = const VerificationMeta(
    'idUsuario',
  );
  @override
  late final GeneratedColumn<int> idUsuario = GeneratedColumn<int>(
    'id_usuario',
    aliasedName,
    true,
    type: DriftSqlType.int,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _loginMeta = const VerificationMeta('login');
  @override
  late final GeneratedColumn<String> login = GeneratedColumn<String>(
    'login',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 150,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _senhaMeta = const VerificationMeta('senha');
  @override
  late final GeneratedColumn<String> senha = GeneratedColumn<String>(
    'senha',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 150,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _dataCadastroMeta = const VerificationMeta(
    'dataCadastro',
  );
  @override
  late final GeneratedColumn<DateTime> dataCadastro = GeneratedColumn<DateTime>(
    'data_cadastro',
    aliasedName,
    true,
    type: DriftSqlType.dateTime,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _administradorMeta = const VerificationMeta(
    'administrador',
  );
  @override
  late final GeneratedColumn<String> administrador = GeneratedColumn<String>(
    'administrador',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 3,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  @override
  List<GeneratedColumn> get $columns => [
    id,
    idPessoa,
    pessoaNome,
    tipo,
    email,
    idColaborador,
    idUsuario,
    login,
    senha,
    dataCadastro,
    administrador,
  ];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'view_pessoa_usuario';
  @override
  VerificationContext validateIntegrity(
    Insertable<ViewPessoaUsuario> instance, {
    bool isInserting = false,
  }) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('id_pessoa')) {
      context.handle(
        _idPessoaMeta,
        idPessoa.isAcceptableOrUnknown(data['id_pessoa']!, _idPessoaMeta),
      );
    }
    if (data.containsKey('pessoa_nome')) {
      context.handle(
        _pessoaNomeMeta,
        pessoaNome.isAcceptableOrUnknown(data['pessoa_nome']!, _pessoaNomeMeta),
      );
    }
    if (data.containsKey('tipo')) {
      context.handle(
        _tipoMeta,
        tipo.isAcceptableOrUnknown(data['tipo']!, _tipoMeta),
      );
    }
    if (data.containsKey('email')) {
      context.handle(
        _emailMeta,
        email.isAcceptableOrUnknown(data['email']!, _emailMeta),
      );
    }
    if (data.containsKey('id_colaborador')) {
      context.handle(
        _idColaboradorMeta,
        idColaborador.isAcceptableOrUnknown(
          data['id_colaborador']!,
          _idColaboradorMeta,
        ),
      );
    }
    if (data.containsKey('id_usuario')) {
      context.handle(
        _idUsuarioMeta,
        idUsuario.isAcceptableOrUnknown(data['id_usuario']!, _idUsuarioMeta),
      );
    }
    if (data.containsKey('login')) {
      context.handle(
        _loginMeta,
        login.isAcceptableOrUnknown(data['login']!, _loginMeta),
      );
    }
    if (data.containsKey('senha')) {
      context.handle(
        _senhaMeta,
        senha.isAcceptableOrUnknown(data['senha']!, _senhaMeta),
      );
    }
    if (data.containsKey('data_cadastro')) {
      context.handle(
        _dataCadastroMeta,
        dataCadastro.isAcceptableOrUnknown(
          data['data_cadastro']!,
          _dataCadastroMeta,
        ),
      );
    }
    if (data.containsKey('administrador')) {
      context.handle(
        _administradorMeta,
        administrador.isAcceptableOrUnknown(
          data['administrador']!,
          _administradorMeta,
        ),
      );
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  ViewPessoaUsuario map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return ViewPessoaUsuario(
      id: attachedDatabase.typeMapping.read(
        DriftSqlType.int,
        data['${effectivePrefix}id'],
      ),
      idPessoa: attachedDatabase.typeMapping.read(
        DriftSqlType.int,
        data['${effectivePrefix}id_pessoa'],
      ),
      pessoaNome: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}pessoa_nome'],
      ),
      tipo: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}tipo'],
      ),
      email: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}email'],
      ),
      idColaborador: attachedDatabase.typeMapping.read(
        DriftSqlType.int,
        data['${effectivePrefix}id_colaborador'],
      ),
      idUsuario: attachedDatabase.typeMapping.read(
        DriftSqlType.int,
        data['${effectivePrefix}id_usuario'],
      ),
      login: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}login'],
      ),
      senha: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}senha'],
      ),
      dataCadastro: attachedDatabase.typeMapping.read(
        DriftSqlType.dateTime,
        data['${effectivePrefix}data_cadastro'],
      ),
      administrador: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}administrador'],
      ),
    );
  }

  @override
  $ViewPessoaUsuariosTable createAlias(String alias) {
    return $ViewPessoaUsuariosTable(attachedDatabase, alias);
  }
}

class ViewPessoaUsuario extends DataClass
    implements Insertable<ViewPessoaUsuario> {
  final int? id;
  final int? idPessoa;
  final String? pessoaNome;
  final String? tipo;
  final String? email;
  final int? idColaborador;
  final int? idUsuario;
  final String? login;
  final String? senha;
  final DateTime? dataCadastro;
  final String? administrador;
  const ViewPessoaUsuario({
    this.id,
    this.idPessoa,
    this.pessoaNome,
    this.tipo,
    this.email,
    this.idColaborador,
    this.idUsuario,
    this.login,
    this.senha,
    this.dataCadastro,
    this.administrador,
  });
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || idPessoa != null) {
      map['id_pessoa'] = Variable<int>(idPessoa);
    }
    if (!nullToAbsent || pessoaNome != null) {
      map['pessoa_nome'] = Variable<String>(pessoaNome);
    }
    if (!nullToAbsent || tipo != null) {
      map['tipo'] = Variable<String>(tipo);
    }
    if (!nullToAbsent || email != null) {
      map['email'] = Variable<String>(email);
    }
    if (!nullToAbsent || idColaborador != null) {
      map['id_colaborador'] = Variable<int>(idColaborador);
    }
    if (!nullToAbsent || idUsuario != null) {
      map['id_usuario'] = Variable<int>(idUsuario);
    }
    if (!nullToAbsent || login != null) {
      map['login'] = Variable<String>(login);
    }
    if (!nullToAbsent || senha != null) {
      map['senha'] = Variable<String>(senha);
    }
    if (!nullToAbsent || dataCadastro != null) {
      map['data_cadastro'] = Variable<DateTime>(dataCadastro);
    }
    if (!nullToAbsent || administrador != null) {
      map['administrador'] = Variable<String>(administrador);
    }
    return map;
  }

  factory ViewPessoaUsuario.fromJson(
    Map<String, dynamic> json, {
    ValueSerializer? serializer,
  }) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return ViewPessoaUsuario(
      id: serializer.fromJson<int?>(json['id']),
      idPessoa: serializer.fromJson<int?>(json['idPessoa']),
      pessoaNome: serializer.fromJson<String?>(json['pessoaNome']),
      tipo: serializer.fromJson<String?>(json['tipo']),
      email: serializer.fromJson<String?>(json['email']),
      idColaborador: serializer.fromJson<int?>(json['idColaborador']),
      idUsuario: serializer.fromJson<int?>(json['idUsuario']),
      login: serializer.fromJson<String?>(json['login']),
      senha: serializer.fromJson<String?>(json['senha']),
      dataCadastro: serializer.fromJson<DateTime?>(json['dataCadastro']),
      administrador: serializer.fromJson<String?>(json['administrador']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'idPessoa': serializer.toJson<int?>(idPessoa),
      'pessoaNome': serializer.toJson<String?>(pessoaNome),
      'tipo': serializer.toJson<String?>(tipo),
      'email': serializer.toJson<String?>(email),
      'idColaborador': serializer.toJson<int?>(idColaborador),
      'idUsuario': serializer.toJson<int?>(idUsuario),
      'login': serializer.toJson<String?>(login),
      'senha': serializer.toJson<String?>(senha),
      'dataCadastro': serializer.toJson<DateTime?>(dataCadastro),
      'administrador': serializer.toJson<String?>(administrador),
    };
  }

  ViewPessoaUsuario copyWith({
    Value<int?> id = const Value.absent(),
    Value<int?> idPessoa = const Value.absent(),
    Value<String?> pessoaNome = const Value.absent(),
    Value<String?> tipo = const Value.absent(),
    Value<String?> email = const Value.absent(),
    Value<int?> idColaborador = const Value.absent(),
    Value<int?> idUsuario = const Value.absent(),
    Value<String?> login = const Value.absent(),
    Value<String?> senha = const Value.absent(),
    Value<DateTime?> dataCadastro = const Value.absent(),
    Value<String?> administrador = const Value.absent(),
  }) => ViewPessoaUsuario(
    id: id.present ? id.value : this.id,
    idPessoa: idPessoa.present ? idPessoa.value : this.idPessoa,
    pessoaNome: pessoaNome.present ? pessoaNome.value : this.pessoaNome,
    tipo: tipo.present ? tipo.value : this.tipo,
    email: email.present ? email.value : this.email,
    idColaborador:
        idColaborador.present ? idColaborador.value : this.idColaborador,
    idUsuario: idUsuario.present ? idUsuario.value : this.idUsuario,
    login: login.present ? login.value : this.login,
    senha: senha.present ? senha.value : this.senha,
    dataCadastro: dataCadastro.present ? dataCadastro.value : this.dataCadastro,
    administrador:
        administrador.present ? administrador.value : this.administrador,
  );
  ViewPessoaUsuario copyWithCompanion(ViewPessoaUsuariosCompanion data) {
    return ViewPessoaUsuario(
      id: data.id.present ? data.id.value : this.id,
      idPessoa: data.idPessoa.present ? data.idPessoa.value : this.idPessoa,
      pessoaNome:
          data.pessoaNome.present ? data.pessoaNome.value : this.pessoaNome,
      tipo: data.tipo.present ? data.tipo.value : this.tipo,
      email: data.email.present ? data.email.value : this.email,
      idColaborador:
          data.idColaborador.present
              ? data.idColaborador.value
              : this.idColaborador,
      idUsuario: data.idUsuario.present ? data.idUsuario.value : this.idUsuario,
      login: data.login.present ? data.login.value : this.login,
      senha: data.senha.present ? data.senha.value : this.senha,
      dataCadastro:
          data.dataCadastro.present
              ? data.dataCadastro.value
              : this.dataCadastro,
      administrador:
          data.administrador.present
              ? data.administrador.value
              : this.administrador,
    );
  }

  @override
  String toString() {
    return (StringBuffer('ViewPessoaUsuario(')
          ..write('id: $id, ')
          ..write('idPessoa: $idPessoa, ')
          ..write('pessoaNome: $pessoaNome, ')
          ..write('tipo: $tipo, ')
          ..write('email: $email, ')
          ..write('idColaborador: $idColaborador, ')
          ..write('idUsuario: $idUsuario, ')
          ..write('login: $login, ')
          ..write('senha: $senha, ')
          ..write('dataCadastro: $dataCadastro, ')
          ..write('administrador: $administrador')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(
    id,
    idPessoa,
    pessoaNome,
    tipo,
    email,
    idColaborador,
    idUsuario,
    login,
    senha,
    dataCadastro,
    administrador,
  );
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is ViewPessoaUsuario &&
          other.id == this.id &&
          other.idPessoa == this.idPessoa &&
          other.pessoaNome == this.pessoaNome &&
          other.tipo == this.tipo &&
          other.email == this.email &&
          other.idColaborador == this.idColaborador &&
          other.idUsuario == this.idUsuario &&
          other.login == this.login &&
          other.senha == this.senha &&
          other.dataCadastro == this.dataCadastro &&
          other.administrador == this.administrador);
}

class ViewPessoaUsuariosCompanion extends UpdateCompanion<ViewPessoaUsuario> {
  final Value<int?> id;
  final Value<int?> idPessoa;
  final Value<String?> pessoaNome;
  final Value<String?> tipo;
  final Value<String?> email;
  final Value<int?> idColaborador;
  final Value<int?> idUsuario;
  final Value<String?> login;
  final Value<String?> senha;
  final Value<DateTime?> dataCadastro;
  final Value<String?> administrador;
  const ViewPessoaUsuariosCompanion({
    this.id = const Value.absent(),
    this.idPessoa = const Value.absent(),
    this.pessoaNome = const Value.absent(),
    this.tipo = const Value.absent(),
    this.email = const Value.absent(),
    this.idColaborador = const Value.absent(),
    this.idUsuario = const Value.absent(),
    this.login = const Value.absent(),
    this.senha = const Value.absent(),
    this.dataCadastro = const Value.absent(),
    this.administrador = const Value.absent(),
  });
  ViewPessoaUsuariosCompanion.insert({
    this.id = const Value.absent(),
    this.idPessoa = const Value.absent(),
    this.pessoaNome = const Value.absent(),
    this.tipo = const Value.absent(),
    this.email = const Value.absent(),
    this.idColaborador = const Value.absent(),
    this.idUsuario = const Value.absent(),
    this.login = const Value.absent(),
    this.senha = const Value.absent(),
    this.dataCadastro = const Value.absent(),
    this.administrador = const Value.absent(),
  });
  static Insertable<ViewPessoaUsuario> custom({
    Expression<int>? id,
    Expression<int>? idPessoa,
    Expression<String>? pessoaNome,
    Expression<String>? tipo,
    Expression<String>? email,
    Expression<int>? idColaborador,
    Expression<int>? idUsuario,
    Expression<String>? login,
    Expression<String>? senha,
    Expression<DateTime>? dataCadastro,
    Expression<String>? administrador,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (idPessoa != null) 'id_pessoa': idPessoa,
      if (pessoaNome != null) 'pessoa_nome': pessoaNome,
      if (tipo != null) 'tipo': tipo,
      if (email != null) 'email': email,
      if (idColaborador != null) 'id_colaborador': idColaborador,
      if (idUsuario != null) 'id_usuario': idUsuario,
      if (login != null) 'login': login,
      if (senha != null) 'senha': senha,
      if (dataCadastro != null) 'data_cadastro': dataCadastro,
      if (administrador != null) 'administrador': administrador,
    });
  }

  ViewPessoaUsuariosCompanion copyWith({
    Value<int?>? id,
    Value<int?>? idPessoa,
    Value<String?>? pessoaNome,
    Value<String?>? tipo,
    Value<String?>? email,
    Value<int?>? idColaborador,
    Value<int?>? idUsuario,
    Value<String?>? login,
    Value<String?>? senha,
    Value<DateTime?>? dataCadastro,
    Value<String?>? administrador,
  }) {
    return ViewPessoaUsuariosCompanion(
      id: id ?? this.id,
      idPessoa: idPessoa ?? this.idPessoa,
      pessoaNome: pessoaNome ?? this.pessoaNome,
      tipo: tipo ?? this.tipo,
      email: email ?? this.email,
      idColaborador: idColaborador ?? this.idColaborador,
      idUsuario: idUsuario ?? this.idUsuario,
      login: login ?? this.login,
      senha: senha ?? this.senha,
      dataCadastro: dataCadastro ?? this.dataCadastro,
      administrador: administrador ?? this.administrador,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (idPessoa.present) {
      map['id_pessoa'] = Variable<int>(idPessoa.value);
    }
    if (pessoaNome.present) {
      map['pessoa_nome'] = Variable<String>(pessoaNome.value);
    }
    if (tipo.present) {
      map['tipo'] = Variable<String>(tipo.value);
    }
    if (email.present) {
      map['email'] = Variable<String>(email.value);
    }
    if (idColaborador.present) {
      map['id_colaborador'] = Variable<int>(idColaborador.value);
    }
    if (idUsuario.present) {
      map['id_usuario'] = Variable<int>(idUsuario.value);
    }
    if (login.present) {
      map['login'] = Variable<String>(login.value);
    }
    if (senha.present) {
      map['senha'] = Variable<String>(senha.value);
    }
    if (dataCadastro.present) {
      map['data_cadastro'] = Variable<DateTime>(dataCadastro.value);
    }
    if (administrador.present) {
      map['administrador'] = Variable<String>(administrador.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('ViewPessoaUsuariosCompanion(')
          ..write('id: $id, ')
          ..write('idPessoa: $idPessoa, ')
          ..write('pessoaNome: $pessoaNome, ')
          ..write('tipo: $tipo, ')
          ..write('email: $email, ')
          ..write('idColaborador: $idColaborador, ')
          ..write('idUsuario: $idUsuario, ')
          ..write('login: $login, ')
          ..write('senha: $senha, ')
          ..write('dataCadastro: $dataCadastro, ')
          ..write('administrador: $administrador')
          ..write(')'))
        .toString();
  }
}

class $GeraSpedFiscalsTable extends GeraSpedFiscals
    with TableInfo<$GeraSpedFiscalsTable, GeraSpedFiscal> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $GeraSpedFiscalsTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
    'id',
    aliasedName,
    true,
    type: DriftSqlType.int,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _dataEmissaoMeta = const VerificationMeta(
    'dataEmissao',
  );
  @override
  late final GeneratedColumn<DateTime> dataEmissao = GeneratedColumn<DateTime>(
    'data_emissao',
    aliasedName,
    true,
    type: DriftSqlType.dateTime,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _periodoInicialMeta = const VerificationMeta(
    'periodoInicial',
  );
  @override
  late final GeneratedColumn<DateTime> periodoInicial =
      GeneratedColumn<DateTime>(
        'periodo_inicial',
        aliasedName,
        true,
        type: DriftSqlType.dateTime,
        requiredDuringInsert: false,
      );
  static const VerificationMeta _periodoFinalMeta = const VerificationMeta(
    'periodoFinal',
  );
  @override
  late final GeneratedColumn<DateTime> periodoFinal = GeneratedColumn<DateTime>(
    'periodo_final',
    aliasedName,
    true,
    type: DriftSqlType.dateTime,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _versaoLayoutMeta = const VerificationMeta(
    'versaoLayout',
  );
  @override
  late final GeneratedColumn<String> versaoLayout = GeneratedColumn<String>(
    'versao_layout',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 3,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _finalidadeArquivoMeta = const VerificationMeta(
    'finalidadeArquivo',
  );
  @override
  late final GeneratedColumn<String> finalidadeArquivo =
      GeneratedColumn<String>(
        'finalidade_arquivo',
        aliasedName,
        true,
        additionalChecks: GeneratedColumn.checkTextLength(
          minTextLength: 0,
          maxTextLength: 1,
        ),
        type: DriftSqlType.string,
        requiredDuringInsert: false,
      );
  static const VerificationMeta _perfilApresentacaoMeta =
      const VerificationMeta('perfilApresentacao');
  @override
  late final GeneratedColumn<String> perfilApresentacao =
      GeneratedColumn<String>(
        'perfil_apresentacao',
        aliasedName,
        true,
        additionalChecks: GeneratedColumn.checkTextLength(
          minTextLength: 0,
          maxTextLength: 1,
        ),
        type: DriftSqlType.string,
        requiredDuringInsert: false,
      );
  static const VerificationMeta _inventarioMeta = const VerificationMeta(
    'inventario',
  );
  @override
  late final GeneratedColumn<String> inventario = GeneratedColumn<String>(
    'inventario',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 1,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _idEmpresaMeta = const VerificationMeta(
    'idEmpresa',
  );
  @override
  late final GeneratedColumn<int> idEmpresa = GeneratedColumn<int>(
    'id_empresa',
    aliasedName,
    true,
    type: DriftSqlType.int,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _idContadorMeta = const VerificationMeta(
    'idContador',
  );
  @override
  late final GeneratedColumn<int> idContador = GeneratedColumn<int>(
    'id_contador',
    aliasedName,
    true,
    type: DriftSqlType.int,
    requiredDuringInsert: false,
  );
  @override
  List<GeneratedColumn> get $columns => [
    id,
    dataEmissao,
    periodoInicial,
    periodoFinal,
    versaoLayout,
    finalidadeArquivo,
    perfilApresentacao,
    inventario,
    idEmpresa,
    idContador,
  ];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'gera_sped_fiscal';
  @override
  VerificationContext validateIntegrity(
    Insertable<GeraSpedFiscal> instance, {
    bool isInserting = false,
  }) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('data_emissao')) {
      context.handle(
        _dataEmissaoMeta,
        dataEmissao.isAcceptableOrUnknown(
          data['data_emissao']!,
          _dataEmissaoMeta,
        ),
      );
    }
    if (data.containsKey('periodo_inicial')) {
      context.handle(
        _periodoInicialMeta,
        periodoInicial.isAcceptableOrUnknown(
          data['periodo_inicial']!,
          _periodoInicialMeta,
        ),
      );
    }
    if (data.containsKey('periodo_final')) {
      context.handle(
        _periodoFinalMeta,
        periodoFinal.isAcceptableOrUnknown(
          data['periodo_final']!,
          _periodoFinalMeta,
        ),
      );
    }
    if (data.containsKey('versao_layout')) {
      context.handle(
        _versaoLayoutMeta,
        versaoLayout.isAcceptableOrUnknown(
          data['versao_layout']!,
          _versaoLayoutMeta,
        ),
      );
    }
    if (data.containsKey('finalidade_arquivo')) {
      context.handle(
        _finalidadeArquivoMeta,
        finalidadeArquivo.isAcceptableOrUnknown(
          data['finalidade_arquivo']!,
          _finalidadeArquivoMeta,
        ),
      );
    }
    if (data.containsKey('perfil_apresentacao')) {
      context.handle(
        _perfilApresentacaoMeta,
        perfilApresentacao.isAcceptableOrUnknown(
          data['perfil_apresentacao']!,
          _perfilApresentacaoMeta,
        ),
      );
    }
    if (data.containsKey('inventario')) {
      context.handle(
        _inventarioMeta,
        inventario.isAcceptableOrUnknown(data['inventario']!, _inventarioMeta),
      );
    }
    if (data.containsKey('id_empresa')) {
      context.handle(
        _idEmpresaMeta,
        idEmpresa.isAcceptableOrUnknown(data['id_empresa']!, _idEmpresaMeta),
      );
    }
    if (data.containsKey('id_contador')) {
      context.handle(
        _idContadorMeta,
        idContador.isAcceptableOrUnknown(data['id_contador']!, _idContadorMeta),
      );
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  GeraSpedFiscal map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return GeraSpedFiscal(
      id: attachedDatabase.typeMapping.read(
        DriftSqlType.int,
        data['${effectivePrefix}id'],
      ),
      dataEmissao: attachedDatabase.typeMapping.read(
        DriftSqlType.dateTime,
        data['${effectivePrefix}data_emissao'],
      ),
      periodoInicial: attachedDatabase.typeMapping.read(
        DriftSqlType.dateTime,
        data['${effectivePrefix}periodo_inicial'],
      ),
      periodoFinal: attachedDatabase.typeMapping.read(
        DriftSqlType.dateTime,
        data['${effectivePrefix}periodo_final'],
      ),
      versaoLayout: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}versao_layout'],
      ),
      finalidadeArquivo: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}finalidade_arquivo'],
      ),
      perfilApresentacao: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}perfil_apresentacao'],
      ),
      inventario: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}inventario'],
      ),
      idEmpresa: attachedDatabase.typeMapping.read(
        DriftSqlType.int,
        data['${effectivePrefix}id_empresa'],
      ),
      idContador: attachedDatabase.typeMapping.read(
        DriftSqlType.int,
        data['${effectivePrefix}id_contador'],
      ),
    );
  }

  @override
  $GeraSpedFiscalsTable createAlias(String alias) {
    return $GeraSpedFiscalsTable(attachedDatabase, alias);
  }
}

class GeraSpedFiscal extends DataClass implements Insertable<GeraSpedFiscal> {
  final int? id;
  final DateTime? dataEmissao;
  final DateTime? periodoInicial;
  final DateTime? periodoFinal;
  final String? versaoLayout;
  final String? finalidadeArquivo;
  final String? perfilApresentacao;
  final String? inventario;
  final int? idEmpresa;
  final int? idContador;
  const GeraSpedFiscal({
    this.id,
    this.dataEmissao,
    this.periodoInicial,
    this.periodoFinal,
    this.versaoLayout,
    this.finalidadeArquivo,
    this.perfilApresentacao,
    this.inventario,
    this.idEmpresa,
    this.idContador,
  });
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || dataEmissao != null) {
      map['data_emissao'] = Variable<DateTime>(dataEmissao);
    }
    if (!nullToAbsent || periodoInicial != null) {
      map['periodo_inicial'] = Variable<DateTime>(periodoInicial);
    }
    if (!nullToAbsent || periodoFinal != null) {
      map['periodo_final'] = Variable<DateTime>(periodoFinal);
    }
    if (!nullToAbsent || versaoLayout != null) {
      map['versao_layout'] = Variable<String>(versaoLayout);
    }
    if (!nullToAbsent || finalidadeArquivo != null) {
      map['finalidade_arquivo'] = Variable<String>(finalidadeArquivo);
    }
    if (!nullToAbsent || perfilApresentacao != null) {
      map['perfil_apresentacao'] = Variable<String>(perfilApresentacao);
    }
    if (!nullToAbsent || inventario != null) {
      map['inventario'] = Variable<String>(inventario);
    }
    if (!nullToAbsent || idEmpresa != null) {
      map['id_empresa'] = Variable<int>(idEmpresa);
    }
    if (!nullToAbsent || idContador != null) {
      map['id_contador'] = Variable<int>(idContador);
    }
    return map;
  }

  factory GeraSpedFiscal.fromJson(
    Map<String, dynamic> json, {
    ValueSerializer? serializer,
  }) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return GeraSpedFiscal(
      id: serializer.fromJson<int?>(json['id']),
      dataEmissao: serializer.fromJson<DateTime?>(json['dataEmissao']),
      periodoInicial: serializer.fromJson<DateTime?>(json['periodoInicial']),
      periodoFinal: serializer.fromJson<DateTime?>(json['periodoFinal']),
      versaoLayout: serializer.fromJson<String?>(json['versaoLayout']),
      finalidadeArquivo: serializer.fromJson<String?>(
        json['finalidadeArquivo'],
      ),
      perfilApresentacao: serializer.fromJson<String?>(
        json['perfilApresentacao'],
      ),
      inventario: serializer.fromJson<String?>(json['inventario']),
      idEmpresa: serializer.fromJson<int?>(json['idEmpresa']),
      idContador: serializer.fromJson<int?>(json['idContador']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'dataEmissao': serializer.toJson<DateTime?>(dataEmissao),
      'periodoInicial': serializer.toJson<DateTime?>(periodoInicial),
      'periodoFinal': serializer.toJson<DateTime?>(periodoFinal),
      'versaoLayout': serializer.toJson<String?>(versaoLayout),
      'finalidadeArquivo': serializer.toJson<String?>(finalidadeArquivo),
      'perfilApresentacao': serializer.toJson<String?>(perfilApresentacao),
      'inventario': serializer.toJson<String?>(inventario),
      'idEmpresa': serializer.toJson<int?>(idEmpresa),
      'idContador': serializer.toJson<int?>(idContador),
    };
  }

  GeraSpedFiscal copyWith({
    Value<int?> id = const Value.absent(),
    Value<DateTime?> dataEmissao = const Value.absent(),
    Value<DateTime?> periodoInicial = const Value.absent(),
    Value<DateTime?> periodoFinal = const Value.absent(),
    Value<String?> versaoLayout = const Value.absent(),
    Value<String?> finalidadeArquivo = const Value.absent(),
    Value<String?> perfilApresentacao = const Value.absent(),
    Value<String?> inventario = const Value.absent(),
    Value<int?> idEmpresa = const Value.absent(),
    Value<int?> idContador = const Value.absent(),
  }) => GeraSpedFiscal(
    id: id.present ? id.value : this.id,
    dataEmissao: dataEmissao.present ? dataEmissao.value : this.dataEmissao,
    periodoInicial:
        periodoInicial.present ? periodoInicial.value : this.periodoInicial,
    periodoFinal: periodoFinal.present ? periodoFinal.value : this.periodoFinal,
    versaoLayout: versaoLayout.present ? versaoLayout.value : this.versaoLayout,
    finalidadeArquivo:
        finalidadeArquivo.present
            ? finalidadeArquivo.value
            : this.finalidadeArquivo,
    perfilApresentacao:
        perfilApresentacao.present
            ? perfilApresentacao.value
            : this.perfilApresentacao,
    inventario: inventario.present ? inventario.value : this.inventario,
    idEmpresa: idEmpresa.present ? idEmpresa.value : this.idEmpresa,
    idContador: idContador.present ? idContador.value : this.idContador,
  );
  GeraSpedFiscal copyWithCompanion(GeraSpedFiscalsCompanion data) {
    return GeraSpedFiscal(
      id: data.id.present ? data.id.value : this.id,
      dataEmissao:
          data.dataEmissao.present ? data.dataEmissao.value : this.dataEmissao,
      periodoInicial:
          data.periodoInicial.present
              ? data.periodoInicial.value
              : this.periodoInicial,
      periodoFinal:
          data.periodoFinal.present
              ? data.periodoFinal.value
              : this.periodoFinal,
      versaoLayout:
          data.versaoLayout.present
              ? data.versaoLayout.value
              : this.versaoLayout,
      finalidadeArquivo:
          data.finalidadeArquivo.present
              ? data.finalidadeArquivo.value
              : this.finalidadeArquivo,
      perfilApresentacao:
          data.perfilApresentacao.present
              ? data.perfilApresentacao.value
              : this.perfilApresentacao,
      inventario:
          data.inventario.present ? data.inventario.value : this.inventario,
      idEmpresa: data.idEmpresa.present ? data.idEmpresa.value : this.idEmpresa,
      idContador:
          data.idContador.present ? data.idContador.value : this.idContador,
    );
  }

  @override
  String toString() {
    return (StringBuffer('GeraSpedFiscal(')
          ..write('id: $id, ')
          ..write('dataEmissao: $dataEmissao, ')
          ..write('periodoInicial: $periodoInicial, ')
          ..write('periodoFinal: $periodoFinal, ')
          ..write('versaoLayout: $versaoLayout, ')
          ..write('finalidadeArquivo: $finalidadeArquivo, ')
          ..write('perfilApresentacao: $perfilApresentacao, ')
          ..write('inventario: $inventario, ')
          ..write('idEmpresa: $idEmpresa, ')
          ..write('idContador: $idContador')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(
    id,
    dataEmissao,
    periodoInicial,
    periodoFinal,
    versaoLayout,
    finalidadeArquivo,
    perfilApresentacao,
    inventario,
    idEmpresa,
    idContador,
  );
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is GeraSpedFiscal &&
          other.id == this.id &&
          other.dataEmissao == this.dataEmissao &&
          other.periodoInicial == this.periodoInicial &&
          other.periodoFinal == this.periodoFinal &&
          other.versaoLayout == this.versaoLayout &&
          other.finalidadeArquivo == this.finalidadeArquivo &&
          other.perfilApresentacao == this.perfilApresentacao &&
          other.inventario == this.inventario &&
          other.idEmpresa == this.idEmpresa &&
          other.idContador == this.idContador);
}

class GeraSpedFiscalsCompanion extends UpdateCompanion<GeraSpedFiscal> {
  final Value<int?> id;
  final Value<DateTime?> dataEmissao;
  final Value<DateTime?> periodoInicial;
  final Value<DateTime?> periodoFinal;
  final Value<String?> versaoLayout;
  final Value<String?> finalidadeArquivo;
  final Value<String?> perfilApresentacao;
  final Value<String?> inventario;
  final Value<int?> idEmpresa;
  final Value<int?> idContador;
  const GeraSpedFiscalsCompanion({
    this.id = const Value.absent(),
    this.dataEmissao = const Value.absent(),
    this.periodoInicial = const Value.absent(),
    this.periodoFinal = const Value.absent(),
    this.versaoLayout = const Value.absent(),
    this.finalidadeArquivo = const Value.absent(),
    this.perfilApresentacao = const Value.absent(),
    this.inventario = const Value.absent(),
    this.idEmpresa = const Value.absent(),
    this.idContador = const Value.absent(),
  });
  GeraSpedFiscalsCompanion.insert({
    this.id = const Value.absent(),
    this.dataEmissao = const Value.absent(),
    this.periodoInicial = const Value.absent(),
    this.periodoFinal = const Value.absent(),
    this.versaoLayout = const Value.absent(),
    this.finalidadeArquivo = const Value.absent(),
    this.perfilApresentacao = const Value.absent(),
    this.inventario = const Value.absent(),
    this.idEmpresa = const Value.absent(),
    this.idContador = const Value.absent(),
  });
  static Insertable<GeraSpedFiscal> custom({
    Expression<int>? id,
    Expression<DateTime>? dataEmissao,
    Expression<DateTime>? periodoInicial,
    Expression<DateTime>? periodoFinal,
    Expression<String>? versaoLayout,
    Expression<String>? finalidadeArquivo,
    Expression<String>? perfilApresentacao,
    Expression<String>? inventario,
    Expression<int>? idEmpresa,
    Expression<int>? idContador,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (dataEmissao != null) 'data_emissao': dataEmissao,
      if (periodoInicial != null) 'periodo_inicial': periodoInicial,
      if (periodoFinal != null) 'periodo_final': periodoFinal,
      if (versaoLayout != null) 'versao_layout': versaoLayout,
      if (finalidadeArquivo != null) 'finalidade_arquivo': finalidadeArquivo,
      if (perfilApresentacao != null) 'perfil_apresentacao': perfilApresentacao,
      if (inventario != null) 'inventario': inventario,
      if (idEmpresa != null) 'id_empresa': idEmpresa,
      if (idContador != null) 'id_contador': idContador,
    });
  }

  GeraSpedFiscalsCompanion copyWith({
    Value<int?>? id,
    Value<DateTime?>? dataEmissao,
    Value<DateTime?>? periodoInicial,
    Value<DateTime?>? periodoFinal,
    Value<String?>? versaoLayout,
    Value<String?>? finalidadeArquivo,
    Value<String?>? perfilApresentacao,
    Value<String?>? inventario,
    Value<int?>? idEmpresa,
    Value<int?>? idContador,
  }) {
    return GeraSpedFiscalsCompanion(
      id: id ?? this.id,
      dataEmissao: dataEmissao ?? this.dataEmissao,
      periodoInicial: periodoInicial ?? this.periodoInicial,
      periodoFinal: periodoFinal ?? this.periodoFinal,
      versaoLayout: versaoLayout ?? this.versaoLayout,
      finalidadeArquivo: finalidadeArquivo ?? this.finalidadeArquivo,
      perfilApresentacao: perfilApresentacao ?? this.perfilApresentacao,
      inventario: inventario ?? this.inventario,
      idEmpresa: idEmpresa ?? this.idEmpresa,
      idContador: idContador ?? this.idContador,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (dataEmissao.present) {
      map['data_emissao'] = Variable<DateTime>(dataEmissao.value);
    }
    if (periodoInicial.present) {
      map['periodo_inicial'] = Variable<DateTime>(periodoInicial.value);
    }
    if (periodoFinal.present) {
      map['periodo_final'] = Variable<DateTime>(periodoFinal.value);
    }
    if (versaoLayout.present) {
      map['versao_layout'] = Variable<String>(versaoLayout.value);
    }
    if (finalidadeArquivo.present) {
      map['finalidade_arquivo'] = Variable<String>(finalidadeArquivo.value);
    }
    if (perfilApresentacao.present) {
      map['perfil_apresentacao'] = Variable<String>(perfilApresentacao.value);
    }
    if (inventario.present) {
      map['inventario'] = Variable<String>(inventario.value);
    }
    if (idEmpresa.present) {
      map['id_empresa'] = Variable<int>(idEmpresa.value);
    }
    if (idContador.present) {
      map['id_contador'] = Variable<int>(idContador.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('GeraSpedFiscalsCompanion(')
          ..write('id: $id, ')
          ..write('dataEmissao: $dataEmissao, ')
          ..write('periodoInicial: $periodoInicial, ')
          ..write('periodoFinal: $periodoFinal, ')
          ..write('versaoLayout: $versaoLayout, ')
          ..write('finalidadeArquivo: $finalidadeArquivo, ')
          ..write('perfilApresentacao: $perfilApresentacao, ')
          ..write('inventario: $inventario, ')
          ..write('idEmpresa: $idEmpresa, ')
          ..write('idContador: $idContador')
          ..write(')'))
        .toString();
  }
}

class $GeraSintegrasTable extends GeraSintegras
    with TableInfo<$GeraSintegrasTable, GeraSintegra> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $GeraSintegrasTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
    'id',
    aliasedName,
    true,
    type: DriftSqlType.int,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _dataEmissaoMeta = const VerificationMeta(
    'dataEmissao',
  );
  @override
  late final GeneratedColumn<DateTime> dataEmissao = GeneratedColumn<DateTime>(
    'data_emissao',
    aliasedName,
    true,
    type: DriftSqlType.dateTime,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _periodoInicialMeta = const VerificationMeta(
    'periodoInicial',
  );
  @override
  late final GeneratedColumn<DateTime> periodoInicial =
      GeneratedColumn<DateTime>(
        'periodo_inicial',
        aliasedName,
        true,
        type: DriftSqlType.dateTime,
        requiredDuringInsert: false,
      );
  static const VerificationMeta _periodoFinalMeta = const VerificationMeta(
    'periodoFinal',
  );
  @override
  late final GeneratedColumn<DateTime> periodoFinal = GeneratedColumn<DateTime>(
    'periodo_final',
    aliasedName,
    true,
    type: DriftSqlType.dateTime,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _codigoConvenioMeta = const VerificationMeta(
    'codigoConvenio',
  );
  @override
  late final GeneratedColumn<String> codigoConvenio = GeneratedColumn<String>(
    'codigo_convenio',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 1,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _finalidadeArquivoMeta = const VerificationMeta(
    'finalidadeArquivo',
  );
  @override
  late final GeneratedColumn<String> finalidadeArquivo =
      GeneratedColumn<String>(
        'finalidade_arquivo',
        aliasedName,
        true,
        additionalChecks: GeneratedColumn.checkTextLength(
          minTextLength: 0,
          maxTextLength: 1,
        ),
        type: DriftSqlType.string,
        requiredDuringInsert: false,
      );
  static const VerificationMeta _naturezaInformacoesMeta =
      const VerificationMeta('naturezaInformacoes');
  @override
  late final GeneratedColumn<String> naturezaInformacoes =
      GeneratedColumn<String>(
        'natureza_informacoes',
        aliasedName,
        true,
        additionalChecks: GeneratedColumn.checkTextLength(
          minTextLength: 0,
          maxTextLength: 1,
        ),
        type: DriftSqlType.string,
        requiredDuringInsert: false,
      );
  static const VerificationMeta _inventarioMeta = const VerificationMeta(
    'inventario',
  );
  @override
  late final GeneratedColumn<String> inventario = GeneratedColumn<String>(
    'inventario',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 1,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _idEmpresaMeta = const VerificationMeta(
    'idEmpresa',
  );
  @override
  late final GeneratedColumn<int> idEmpresa = GeneratedColumn<int>(
    'id_empresa',
    aliasedName,
    true,
    type: DriftSqlType.int,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _idContadorMeta = const VerificationMeta(
    'idContador',
  );
  @override
  late final GeneratedColumn<int> idContador = GeneratedColumn<int>(
    'id_contador',
    aliasedName,
    true,
    type: DriftSqlType.int,
    requiredDuringInsert: false,
  );
  @override
  List<GeneratedColumn> get $columns => [
    id,
    dataEmissao,
    periodoInicial,
    periodoFinal,
    codigoConvenio,
    finalidadeArquivo,
    naturezaInformacoes,
    inventario,
    idEmpresa,
    idContador,
  ];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'gera_sintegra';
  @override
  VerificationContext validateIntegrity(
    Insertable<GeraSintegra> instance, {
    bool isInserting = false,
  }) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('data_emissao')) {
      context.handle(
        _dataEmissaoMeta,
        dataEmissao.isAcceptableOrUnknown(
          data['data_emissao']!,
          _dataEmissaoMeta,
        ),
      );
    }
    if (data.containsKey('periodo_inicial')) {
      context.handle(
        _periodoInicialMeta,
        periodoInicial.isAcceptableOrUnknown(
          data['periodo_inicial']!,
          _periodoInicialMeta,
        ),
      );
    }
    if (data.containsKey('periodo_final')) {
      context.handle(
        _periodoFinalMeta,
        periodoFinal.isAcceptableOrUnknown(
          data['periodo_final']!,
          _periodoFinalMeta,
        ),
      );
    }
    if (data.containsKey('codigo_convenio')) {
      context.handle(
        _codigoConvenioMeta,
        codigoConvenio.isAcceptableOrUnknown(
          data['codigo_convenio']!,
          _codigoConvenioMeta,
        ),
      );
    }
    if (data.containsKey('finalidade_arquivo')) {
      context.handle(
        _finalidadeArquivoMeta,
        finalidadeArquivo.isAcceptableOrUnknown(
          data['finalidade_arquivo']!,
          _finalidadeArquivoMeta,
        ),
      );
    }
    if (data.containsKey('natureza_informacoes')) {
      context.handle(
        _naturezaInformacoesMeta,
        naturezaInformacoes.isAcceptableOrUnknown(
          data['natureza_informacoes']!,
          _naturezaInformacoesMeta,
        ),
      );
    }
    if (data.containsKey('inventario')) {
      context.handle(
        _inventarioMeta,
        inventario.isAcceptableOrUnknown(data['inventario']!, _inventarioMeta),
      );
    }
    if (data.containsKey('id_empresa')) {
      context.handle(
        _idEmpresaMeta,
        idEmpresa.isAcceptableOrUnknown(data['id_empresa']!, _idEmpresaMeta),
      );
    }
    if (data.containsKey('id_contador')) {
      context.handle(
        _idContadorMeta,
        idContador.isAcceptableOrUnknown(data['id_contador']!, _idContadorMeta),
      );
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  GeraSintegra map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return GeraSintegra(
      id: attachedDatabase.typeMapping.read(
        DriftSqlType.int,
        data['${effectivePrefix}id'],
      ),
      dataEmissao: attachedDatabase.typeMapping.read(
        DriftSqlType.dateTime,
        data['${effectivePrefix}data_emissao'],
      ),
      periodoInicial: attachedDatabase.typeMapping.read(
        DriftSqlType.dateTime,
        data['${effectivePrefix}periodo_inicial'],
      ),
      periodoFinal: attachedDatabase.typeMapping.read(
        DriftSqlType.dateTime,
        data['${effectivePrefix}periodo_final'],
      ),
      codigoConvenio: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}codigo_convenio'],
      ),
      finalidadeArquivo: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}finalidade_arquivo'],
      ),
      naturezaInformacoes: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}natureza_informacoes'],
      ),
      inventario: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}inventario'],
      ),
      idEmpresa: attachedDatabase.typeMapping.read(
        DriftSqlType.int,
        data['${effectivePrefix}id_empresa'],
      ),
      idContador: attachedDatabase.typeMapping.read(
        DriftSqlType.int,
        data['${effectivePrefix}id_contador'],
      ),
    );
  }

  @override
  $GeraSintegrasTable createAlias(String alias) {
    return $GeraSintegrasTable(attachedDatabase, alias);
  }
}

class GeraSintegra extends DataClass implements Insertable<GeraSintegra> {
  final int? id;
  final DateTime? dataEmissao;
  final DateTime? periodoInicial;
  final DateTime? periodoFinal;
  final String? codigoConvenio;
  final String? finalidadeArquivo;
  final String? naturezaInformacoes;
  final String? inventario;
  final int? idEmpresa;
  final int? idContador;
  const GeraSintegra({
    this.id,
    this.dataEmissao,
    this.periodoInicial,
    this.periodoFinal,
    this.codigoConvenio,
    this.finalidadeArquivo,
    this.naturezaInformacoes,
    this.inventario,
    this.idEmpresa,
    this.idContador,
  });
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || dataEmissao != null) {
      map['data_emissao'] = Variable<DateTime>(dataEmissao);
    }
    if (!nullToAbsent || periodoInicial != null) {
      map['periodo_inicial'] = Variable<DateTime>(periodoInicial);
    }
    if (!nullToAbsent || periodoFinal != null) {
      map['periodo_final'] = Variable<DateTime>(periodoFinal);
    }
    if (!nullToAbsent || codigoConvenio != null) {
      map['codigo_convenio'] = Variable<String>(codigoConvenio);
    }
    if (!nullToAbsent || finalidadeArquivo != null) {
      map['finalidade_arquivo'] = Variable<String>(finalidadeArquivo);
    }
    if (!nullToAbsent || naturezaInformacoes != null) {
      map['natureza_informacoes'] = Variable<String>(naturezaInformacoes);
    }
    if (!nullToAbsent || inventario != null) {
      map['inventario'] = Variable<String>(inventario);
    }
    if (!nullToAbsent || idEmpresa != null) {
      map['id_empresa'] = Variable<int>(idEmpresa);
    }
    if (!nullToAbsent || idContador != null) {
      map['id_contador'] = Variable<int>(idContador);
    }
    return map;
  }

  factory GeraSintegra.fromJson(
    Map<String, dynamic> json, {
    ValueSerializer? serializer,
  }) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return GeraSintegra(
      id: serializer.fromJson<int?>(json['id']),
      dataEmissao: serializer.fromJson<DateTime?>(json['dataEmissao']),
      periodoInicial: serializer.fromJson<DateTime?>(json['periodoInicial']),
      periodoFinal: serializer.fromJson<DateTime?>(json['periodoFinal']),
      codigoConvenio: serializer.fromJson<String?>(json['codigoConvenio']),
      finalidadeArquivo: serializer.fromJson<String?>(
        json['finalidadeArquivo'],
      ),
      naturezaInformacoes: serializer.fromJson<String?>(
        json['naturezaInformacoes'],
      ),
      inventario: serializer.fromJson<String?>(json['inventario']),
      idEmpresa: serializer.fromJson<int?>(json['idEmpresa']),
      idContador: serializer.fromJson<int?>(json['idContador']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'dataEmissao': serializer.toJson<DateTime?>(dataEmissao),
      'periodoInicial': serializer.toJson<DateTime?>(periodoInicial),
      'periodoFinal': serializer.toJson<DateTime?>(periodoFinal),
      'codigoConvenio': serializer.toJson<String?>(codigoConvenio),
      'finalidadeArquivo': serializer.toJson<String?>(finalidadeArquivo),
      'naturezaInformacoes': serializer.toJson<String?>(naturezaInformacoes),
      'inventario': serializer.toJson<String?>(inventario),
      'idEmpresa': serializer.toJson<int?>(idEmpresa),
      'idContador': serializer.toJson<int?>(idContador),
    };
  }

  GeraSintegra copyWith({
    Value<int?> id = const Value.absent(),
    Value<DateTime?> dataEmissao = const Value.absent(),
    Value<DateTime?> periodoInicial = const Value.absent(),
    Value<DateTime?> periodoFinal = const Value.absent(),
    Value<String?> codigoConvenio = const Value.absent(),
    Value<String?> finalidadeArquivo = const Value.absent(),
    Value<String?> naturezaInformacoes = const Value.absent(),
    Value<String?> inventario = const Value.absent(),
    Value<int?> idEmpresa = const Value.absent(),
    Value<int?> idContador = const Value.absent(),
  }) => GeraSintegra(
    id: id.present ? id.value : this.id,
    dataEmissao: dataEmissao.present ? dataEmissao.value : this.dataEmissao,
    periodoInicial:
        periodoInicial.present ? periodoInicial.value : this.periodoInicial,
    periodoFinal: periodoFinal.present ? periodoFinal.value : this.periodoFinal,
    codigoConvenio:
        codigoConvenio.present ? codigoConvenio.value : this.codigoConvenio,
    finalidadeArquivo:
        finalidadeArquivo.present
            ? finalidadeArquivo.value
            : this.finalidadeArquivo,
    naturezaInformacoes:
        naturezaInformacoes.present
            ? naturezaInformacoes.value
            : this.naturezaInformacoes,
    inventario: inventario.present ? inventario.value : this.inventario,
    idEmpresa: idEmpresa.present ? idEmpresa.value : this.idEmpresa,
    idContador: idContador.present ? idContador.value : this.idContador,
  );
  GeraSintegra copyWithCompanion(GeraSintegrasCompanion data) {
    return GeraSintegra(
      id: data.id.present ? data.id.value : this.id,
      dataEmissao:
          data.dataEmissao.present ? data.dataEmissao.value : this.dataEmissao,
      periodoInicial:
          data.periodoInicial.present
              ? data.periodoInicial.value
              : this.periodoInicial,
      periodoFinal:
          data.periodoFinal.present
              ? data.periodoFinal.value
              : this.periodoFinal,
      codigoConvenio:
          data.codigoConvenio.present
              ? data.codigoConvenio.value
              : this.codigoConvenio,
      finalidadeArquivo:
          data.finalidadeArquivo.present
              ? data.finalidadeArquivo.value
              : this.finalidadeArquivo,
      naturezaInformacoes:
          data.naturezaInformacoes.present
              ? data.naturezaInformacoes.value
              : this.naturezaInformacoes,
      inventario:
          data.inventario.present ? data.inventario.value : this.inventario,
      idEmpresa: data.idEmpresa.present ? data.idEmpresa.value : this.idEmpresa,
      idContador:
          data.idContador.present ? data.idContador.value : this.idContador,
    );
  }

  @override
  String toString() {
    return (StringBuffer('GeraSintegra(')
          ..write('id: $id, ')
          ..write('dataEmissao: $dataEmissao, ')
          ..write('periodoInicial: $periodoInicial, ')
          ..write('periodoFinal: $periodoFinal, ')
          ..write('codigoConvenio: $codigoConvenio, ')
          ..write('finalidadeArquivo: $finalidadeArquivo, ')
          ..write('naturezaInformacoes: $naturezaInformacoes, ')
          ..write('inventario: $inventario, ')
          ..write('idEmpresa: $idEmpresa, ')
          ..write('idContador: $idContador')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(
    id,
    dataEmissao,
    periodoInicial,
    periodoFinal,
    codigoConvenio,
    finalidadeArquivo,
    naturezaInformacoes,
    inventario,
    idEmpresa,
    idContador,
  );
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is GeraSintegra &&
          other.id == this.id &&
          other.dataEmissao == this.dataEmissao &&
          other.periodoInicial == this.periodoInicial &&
          other.periodoFinal == this.periodoFinal &&
          other.codigoConvenio == this.codigoConvenio &&
          other.finalidadeArquivo == this.finalidadeArquivo &&
          other.naturezaInformacoes == this.naturezaInformacoes &&
          other.inventario == this.inventario &&
          other.idEmpresa == this.idEmpresa &&
          other.idContador == this.idContador);
}

class GeraSintegrasCompanion extends UpdateCompanion<GeraSintegra> {
  final Value<int?> id;
  final Value<DateTime?> dataEmissao;
  final Value<DateTime?> periodoInicial;
  final Value<DateTime?> periodoFinal;
  final Value<String?> codigoConvenio;
  final Value<String?> finalidadeArquivo;
  final Value<String?> naturezaInformacoes;
  final Value<String?> inventario;
  final Value<int?> idEmpresa;
  final Value<int?> idContador;
  const GeraSintegrasCompanion({
    this.id = const Value.absent(),
    this.dataEmissao = const Value.absent(),
    this.periodoInicial = const Value.absent(),
    this.periodoFinal = const Value.absent(),
    this.codigoConvenio = const Value.absent(),
    this.finalidadeArquivo = const Value.absent(),
    this.naturezaInformacoes = const Value.absent(),
    this.inventario = const Value.absent(),
    this.idEmpresa = const Value.absent(),
    this.idContador = const Value.absent(),
  });
  GeraSintegrasCompanion.insert({
    this.id = const Value.absent(),
    this.dataEmissao = const Value.absent(),
    this.periodoInicial = const Value.absent(),
    this.periodoFinal = const Value.absent(),
    this.codigoConvenio = const Value.absent(),
    this.finalidadeArquivo = const Value.absent(),
    this.naturezaInformacoes = const Value.absent(),
    this.inventario = const Value.absent(),
    this.idEmpresa = const Value.absent(),
    this.idContador = const Value.absent(),
  });
  static Insertable<GeraSintegra> custom({
    Expression<int>? id,
    Expression<DateTime>? dataEmissao,
    Expression<DateTime>? periodoInicial,
    Expression<DateTime>? periodoFinal,
    Expression<String>? codigoConvenio,
    Expression<String>? finalidadeArquivo,
    Expression<String>? naturezaInformacoes,
    Expression<String>? inventario,
    Expression<int>? idEmpresa,
    Expression<int>? idContador,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (dataEmissao != null) 'data_emissao': dataEmissao,
      if (periodoInicial != null) 'periodo_inicial': periodoInicial,
      if (periodoFinal != null) 'periodo_final': periodoFinal,
      if (codigoConvenio != null) 'codigo_convenio': codigoConvenio,
      if (finalidadeArquivo != null) 'finalidade_arquivo': finalidadeArquivo,
      if (naturezaInformacoes != null)
        'natureza_informacoes': naturezaInformacoes,
      if (inventario != null) 'inventario': inventario,
      if (idEmpresa != null) 'id_empresa': idEmpresa,
      if (idContador != null) 'id_contador': idContador,
    });
  }

  GeraSintegrasCompanion copyWith({
    Value<int?>? id,
    Value<DateTime?>? dataEmissao,
    Value<DateTime?>? periodoInicial,
    Value<DateTime?>? periodoFinal,
    Value<String?>? codigoConvenio,
    Value<String?>? finalidadeArquivo,
    Value<String?>? naturezaInformacoes,
    Value<String?>? inventario,
    Value<int?>? idEmpresa,
    Value<int?>? idContador,
  }) {
    return GeraSintegrasCompanion(
      id: id ?? this.id,
      dataEmissao: dataEmissao ?? this.dataEmissao,
      periodoInicial: periodoInicial ?? this.periodoInicial,
      periodoFinal: periodoFinal ?? this.periodoFinal,
      codigoConvenio: codigoConvenio ?? this.codigoConvenio,
      finalidadeArquivo: finalidadeArquivo ?? this.finalidadeArquivo,
      naturezaInformacoes: naturezaInformacoes ?? this.naturezaInformacoes,
      inventario: inventario ?? this.inventario,
      idEmpresa: idEmpresa ?? this.idEmpresa,
      idContador: idContador ?? this.idContador,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (dataEmissao.present) {
      map['data_emissao'] = Variable<DateTime>(dataEmissao.value);
    }
    if (periodoInicial.present) {
      map['periodo_inicial'] = Variable<DateTime>(periodoInicial.value);
    }
    if (periodoFinal.present) {
      map['periodo_final'] = Variable<DateTime>(periodoFinal.value);
    }
    if (codigoConvenio.present) {
      map['codigo_convenio'] = Variable<String>(codigoConvenio.value);
    }
    if (finalidadeArquivo.present) {
      map['finalidade_arquivo'] = Variable<String>(finalidadeArquivo.value);
    }
    if (naturezaInformacoes.present) {
      map['natureza_informacoes'] = Variable<String>(naturezaInformacoes.value);
    }
    if (inventario.present) {
      map['inventario'] = Variable<String>(inventario.value);
    }
    if (idEmpresa.present) {
      map['id_empresa'] = Variable<int>(idEmpresa.value);
    }
    if (idContador.present) {
      map['id_contador'] = Variable<int>(idContador.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('GeraSintegrasCompanion(')
          ..write('id: $id, ')
          ..write('dataEmissao: $dataEmissao, ')
          ..write('periodoInicial: $periodoInicial, ')
          ..write('periodoFinal: $periodoFinal, ')
          ..write('codigoConvenio: $codigoConvenio, ')
          ..write('finalidadeArquivo: $finalidadeArquivo, ')
          ..write('naturezaInformacoes: $naturezaInformacoes, ')
          ..write('inventario: $inventario, ')
          ..write('idEmpresa: $idEmpresa, ')
          ..write('idContador: $idContador')
          ..write(')'))
        .toString();
  }
}

class $GeraEfdContribuicoessTable extends GeraEfdContribuicoess
    with TableInfo<$GeraEfdContribuicoessTable, GeraEfdContribuicoes> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $GeraEfdContribuicoessTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
    'id',
    aliasedName,
    true,
    type: DriftSqlType.int,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _dataEmissaoMeta = const VerificationMeta(
    'dataEmissao',
  );
  @override
  late final GeneratedColumn<DateTime> dataEmissao = GeneratedColumn<DateTime>(
    'data_emissao',
    aliasedName,
    true,
    type: DriftSqlType.dateTime,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _periodoInicialMeta = const VerificationMeta(
    'periodoInicial',
  );
  @override
  late final GeneratedColumn<DateTime> periodoInicial =
      GeneratedColumn<DateTime>(
        'periodo_inicial',
        aliasedName,
        true,
        type: DriftSqlType.dateTime,
        requiredDuringInsert: false,
      );
  static const VerificationMeta _periodoFinalMeta = const VerificationMeta(
    'periodoFinal',
  );
  @override
  late final GeneratedColumn<DateTime> periodoFinal = GeneratedColumn<DateTime>(
    'periodo_final',
    aliasedName,
    true,
    type: DriftSqlType.dateTime,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _versaoLayoutMeta = const VerificationMeta(
    'versaoLayout',
  );
  @override
  late final GeneratedColumn<String> versaoLayout = GeneratedColumn<String>(
    'versao_layout',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 3,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _tipoEscrituracaoMeta = const VerificationMeta(
    'tipoEscrituracao',
  );
  @override
  late final GeneratedColumn<String> tipoEscrituracao = GeneratedColumn<String>(
    'tipo_escrituracao',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 1,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _idEmpersaMeta = const VerificationMeta(
    'idEmpersa',
  );
  @override
  late final GeneratedColumn<int> idEmpersa = GeneratedColumn<int>(
    'id_empersa',
    aliasedName,
    true,
    type: DriftSqlType.int,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _idContadorMeta = const VerificationMeta(
    'idContador',
  );
  @override
  late final GeneratedColumn<int> idContador = GeneratedColumn<int>(
    'id_contador',
    aliasedName,
    true,
    type: DriftSqlType.int,
    requiredDuringInsert: false,
  );
  @override
  List<GeneratedColumn> get $columns => [
    id,
    dataEmissao,
    periodoInicial,
    periodoFinal,
    versaoLayout,
    tipoEscrituracao,
    idEmpersa,
    idContador,
  ];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'gera_efd_contribuicoes';
  @override
  VerificationContext validateIntegrity(
    Insertable<GeraEfdContribuicoes> instance, {
    bool isInserting = false,
  }) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('data_emissao')) {
      context.handle(
        _dataEmissaoMeta,
        dataEmissao.isAcceptableOrUnknown(
          data['data_emissao']!,
          _dataEmissaoMeta,
        ),
      );
    }
    if (data.containsKey('periodo_inicial')) {
      context.handle(
        _periodoInicialMeta,
        periodoInicial.isAcceptableOrUnknown(
          data['periodo_inicial']!,
          _periodoInicialMeta,
        ),
      );
    }
    if (data.containsKey('periodo_final')) {
      context.handle(
        _periodoFinalMeta,
        periodoFinal.isAcceptableOrUnknown(
          data['periodo_final']!,
          _periodoFinalMeta,
        ),
      );
    }
    if (data.containsKey('versao_layout')) {
      context.handle(
        _versaoLayoutMeta,
        versaoLayout.isAcceptableOrUnknown(
          data['versao_layout']!,
          _versaoLayoutMeta,
        ),
      );
    }
    if (data.containsKey('tipo_escrituracao')) {
      context.handle(
        _tipoEscrituracaoMeta,
        tipoEscrituracao.isAcceptableOrUnknown(
          data['tipo_escrituracao']!,
          _tipoEscrituracaoMeta,
        ),
      );
    }
    if (data.containsKey('id_empersa')) {
      context.handle(
        _idEmpersaMeta,
        idEmpersa.isAcceptableOrUnknown(data['id_empersa']!, _idEmpersaMeta),
      );
    }
    if (data.containsKey('id_contador')) {
      context.handle(
        _idContadorMeta,
        idContador.isAcceptableOrUnknown(data['id_contador']!, _idContadorMeta),
      );
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  GeraEfdContribuicoes map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return GeraEfdContribuicoes(
      id: attachedDatabase.typeMapping.read(
        DriftSqlType.int,
        data['${effectivePrefix}id'],
      ),
      dataEmissao: attachedDatabase.typeMapping.read(
        DriftSqlType.dateTime,
        data['${effectivePrefix}data_emissao'],
      ),
      periodoInicial: attachedDatabase.typeMapping.read(
        DriftSqlType.dateTime,
        data['${effectivePrefix}periodo_inicial'],
      ),
      periodoFinal: attachedDatabase.typeMapping.read(
        DriftSqlType.dateTime,
        data['${effectivePrefix}periodo_final'],
      ),
      versaoLayout: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}versao_layout'],
      ),
      tipoEscrituracao: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}tipo_escrituracao'],
      ),
      idEmpersa: attachedDatabase.typeMapping.read(
        DriftSqlType.int,
        data['${effectivePrefix}id_empersa'],
      ),
      idContador: attachedDatabase.typeMapping.read(
        DriftSqlType.int,
        data['${effectivePrefix}id_contador'],
      ),
    );
  }

  @override
  $GeraEfdContribuicoessTable createAlias(String alias) {
    return $GeraEfdContribuicoessTable(attachedDatabase, alias);
  }
}

class GeraEfdContribuicoes extends DataClass
    implements Insertable<GeraEfdContribuicoes> {
  final int? id;
  final DateTime? dataEmissao;
  final DateTime? periodoInicial;
  final DateTime? periodoFinal;
  final String? versaoLayout;
  final String? tipoEscrituracao;
  final int? idEmpersa;
  final int? idContador;
  const GeraEfdContribuicoes({
    this.id,
    this.dataEmissao,
    this.periodoInicial,
    this.periodoFinal,
    this.versaoLayout,
    this.tipoEscrituracao,
    this.idEmpersa,
    this.idContador,
  });
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || dataEmissao != null) {
      map['data_emissao'] = Variable<DateTime>(dataEmissao);
    }
    if (!nullToAbsent || periodoInicial != null) {
      map['periodo_inicial'] = Variable<DateTime>(periodoInicial);
    }
    if (!nullToAbsent || periodoFinal != null) {
      map['periodo_final'] = Variable<DateTime>(periodoFinal);
    }
    if (!nullToAbsent || versaoLayout != null) {
      map['versao_layout'] = Variable<String>(versaoLayout);
    }
    if (!nullToAbsent || tipoEscrituracao != null) {
      map['tipo_escrituracao'] = Variable<String>(tipoEscrituracao);
    }
    if (!nullToAbsent || idEmpersa != null) {
      map['id_empersa'] = Variable<int>(idEmpersa);
    }
    if (!nullToAbsent || idContador != null) {
      map['id_contador'] = Variable<int>(idContador);
    }
    return map;
  }

  factory GeraEfdContribuicoes.fromJson(
    Map<String, dynamic> json, {
    ValueSerializer? serializer,
  }) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return GeraEfdContribuicoes(
      id: serializer.fromJson<int?>(json['id']),
      dataEmissao: serializer.fromJson<DateTime?>(json['dataEmissao']),
      periodoInicial: serializer.fromJson<DateTime?>(json['periodoInicial']),
      periodoFinal: serializer.fromJson<DateTime?>(json['periodoFinal']),
      versaoLayout: serializer.fromJson<String?>(json['versaoLayout']),
      tipoEscrituracao: serializer.fromJson<String?>(json['tipoEscrituracao']),
      idEmpersa: serializer.fromJson<int?>(json['idEmpersa']),
      idContador: serializer.fromJson<int?>(json['idContador']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'dataEmissao': serializer.toJson<DateTime?>(dataEmissao),
      'periodoInicial': serializer.toJson<DateTime?>(periodoInicial),
      'periodoFinal': serializer.toJson<DateTime?>(periodoFinal),
      'versaoLayout': serializer.toJson<String?>(versaoLayout),
      'tipoEscrituracao': serializer.toJson<String?>(tipoEscrituracao),
      'idEmpersa': serializer.toJson<int?>(idEmpersa),
      'idContador': serializer.toJson<int?>(idContador),
    };
  }

  GeraEfdContribuicoes copyWith({
    Value<int?> id = const Value.absent(),
    Value<DateTime?> dataEmissao = const Value.absent(),
    Value<DateTime?> periodoInicial = const Value.absent(),
    Value<DateTime?> periodoFinal = const Value.absent(),
    Value<String?> versaoLayout = const Value.absent(),
    Value<String?> tipoEscrituracao = const Value.absent(),
    Value<int?> idEmpersa = const Value.absent(),
    Value<int?> idContador = const Value.absent(),
  }) => GeraEfdContribuicoes(
    id: id.present ? id.value : this.id,
    dataEmissao: dataEmissao.present ? dataEmissao.value : this.dataEmissao,
    periodoInicial:
        periodoInicial.present ? periodoInicial.value : this.periodoInicial,
    periodoFinal: periodoFinal.present ? periodoFinal.value : this.periodoFinal,
    versaoLayout: versaoLayout.present ? versaoLayout.value : this.versaoLayout,
    tipoEscrituracao:
        tipoEscrituracao.present
            ? tipoEscrituracao.value
            : this.tipoEscrituracao,
    idEmpersa: idEmpersa.present ? idEmpersa.value : this.idEmpersa,
    idContador: idContador.present ? idContador.value : this.idContador,
  );
  GeraEfdContribuicoes copyWithCompanion(GeraEfdContribuicoessCompanion data) {
    return GeraEfdContribuicoes(
      id: data.id.present ? data.id.value : this.id,
      dataEmissao:
          data.dataEmissao.present ? data.dataEmissao.value : this.dataEmissao,
      periodoInicial:
          data.periodoInicial.present
              ? data.periodoInicial.value
              : this.periodoInicial,
      periodoFinal:
          data.periodoFinal.present
              ? data.periodoFinal.value
              : this.periodoFinal,
      versaoLayout:
          data.versaoLayout.present
              ? data.versaoLayout.value
              : this.versaoLayout,
      tipoEscrituracao:
          data.tipoEscrituracao.present
              ? data.tipoEscrituracao.value
              : this.tipoEscrituracao,
      idEmpersa: data.idEmpersa.present ? data.idEmpersa.value : this.idEmpersa,
      idContador:
          data.idContador.present ? data.idContador.value : this.idContador,
    );
  }

  @override
  String toString() {
    return (StringBuffer('GeraEfdContribuicoes(')
          ..write('id: $id, ')
          ..write('dataEmissao: $dataEmissao, ')
          ..write('periodoInicial: $periodoInicial, ')
          ..write('periodoFinal: $periodoFinal, ')
          ..write('versaoLayout: $versaoLayout, ')
          ..write('tipoEscrituracao: $tipoEscrituracao, ')
          ..write('idEmpersa: $idEmpersa, ')
          ..write('idContador: $idContador')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(
    id,
    dataEmissao,
    periodoInicial,
    periodoFinal,
    versaoLayout,
    tipoEscrituracao,
    idEmpersa,
    idContador,
  );
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is GeraEfdContribuicoes &&
          other.id == this.id &&
          other.dataEmissao == this.dataEmissao &&
          other.periodoInicial == this.periodoInicial &&
          other.periodoFinal == this.periodoFinal &&
          other.versaoLayout == this.versaoLayout &&
          other.tipoEscrituracao == this.tipoEscrituracao &&
          other.idEmpersa == this.idEmpersa &&
          other.idContador == this.idContador);
}

class GeraEfdContribuicoessCompanion
    extends UpdateCompanion<GeraEfdContribuicoes> {
  final Value<int?> id;
  final Value<DateTime?> dataEmissao;
  final Value<DateTime?> periodoInicial;
  final Value<DateTime?> periodoFinal;
  final Value<String?> versaoLayout;
  final Value<String?> tipoEscrituracao;
  final Value<int?> idEmpersa;
  final Value<int?> idContador;
  const GeraEfdContribuicoessCompanion({
    this.id = const Value.absent(),
    this.dataEmissao = const Value.absent(),
    this.periodoInicial = const Value.absent(),
    this.periodoFinal = const Value.absent(),
    this.versaoLayout = const Value.absent(),
    this.tipoEscrituracao = const Value.absent(),
    this.idEmpersa = const Value.absent(),
    this.idContador = const Value.absent(),
  });
  GeraEfdContribuicoessCompanion.insert({
    this.id = const Value.absent(),
    this.dataEmissao = const Value.absent(),
    this.periodoInicial = const Value.absent(),
    this.periodoFinal = const Value.absent(),
    this.versaoLayout = const Value.absent(),
    this.tipoEscrituracao = const Value.absent(),
    this.idEmpersa = const Value.absent(),
    this.idContador = const Value.absent(),
  });
  static Insertable<GeraEfdContribuicoes> custom({
    Expression<int>? id,
    Expression<DateTime>? dataEmissao,
    Expression<DateTime>? periodoInicial,
    Expression<DateTime>? periodoFinal,
    Expression<String>? versaoLayout,
    Expression<String>? tipoEscrituracao,
    Expression<int>? idEmpersa,
    Expression<int>? idContador,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (dataEmissao != null) 'data_emissao': dataEmissao,
      if (periodoInicial != null) 'periodo_inicial': periodoInicial,
      if (periodoFinal != null) 'periodo_final': periodoFinal,
      if (versaoLayout != null) 'versao_layout': versaoLayout,
      if (tipoEscrituracao != null) 'tipo_escrituracao': tipoEscrituracao,
      if (idEmpersa != null) 'id_empersa': idEmpersa,
      if (idContador != null) 'id_contador': idContador,
    });
  }

  GeraEfdContribuicoessCompanion copyWith({
    Value<int?>? id,
    Value<DateTime?>? dataEmissao,
    Value<DateTime?>? periodoInicial,
    Value<DateTime?>? periodoFinal,
    Value<String?>? versaoLayout,
    Value<String?>? tipoEscrituracao,
    Value<int?>? idEmpersa,
    Value<int?>? idContador,
  }) {
    return GeraEfdContribuicoessCompanion(
      id: id ?? this.id,
      dataEmissao: dataEmissao ?? this.dataEmissao,
      periodoInicial: periodoInicial ?? this.periodoInicial,
      periodoFinal: periodoFinal ?? this.periodoFinal,
      versaoLayout: versaoLayout ?? this.versaoLayout,
      tipoEscrituracao: tipoEscrituracao ?? this.tipoEscrituracao,
      idEmpersa: idEmpersa ?? this.idEmpersa,
      idContador: idContador ?? this.idContador,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (dataEmissao.present) {
      map['data_emissao'] = Variable<DateTime>(dataEmissao.value);
    }
    if (periodoInicial.present) {
      map['periodo_inicial'] = Variable<DateTime>(periodoInicial.value);
    }
    if (periodoFinal.present) {
      map['periodo_final'] = Variable<DateTime>(periodoFinal.value);
    }
    if (versaoLayout.present) {
      map['versao_layout'] = Variable<String>(versaoLayout.value);
    }
    if (tipoEscrituracao.present) {
      map['tipo_escrituracao'] = Variable<String>(tipoEscrituracao.value);
    }
    if (idEmpersa.present) {
      map['id_empersa'] = Variable<int>(idEmpersa.value);
    }
    if (idContador.present) {
      map['id_contador'] = Variable<int>(idContador.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('GeraEfdContribuicoessCompanion(')
          ..write('id: $id, ')
          ..write('dataEmissao: $dataEmissao, ')
          ..write('periodoInicial: $periodoInicial, ')
          ..write('periodoFinal: $periodoFinal, ')
          ..write('versaoLayout: $versaoLayout, ')
          ..write('tipoEscrituracao: $tipoEscrituracao, ')
          ..write('idEmpersa: $idEmpersa, ')
          ..write('idContador: $idContador')
          ..write(')'))
        .toString();
  }
}

class $GeraEfdReinfsTable extends GeraEfdReinfs
    with TableInfo<$GeraEfdReinfsTable, GeraEfdReinf> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $GeraEfdReinfsTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
    'id',
    aliasedName,
    true,
    type: DriftSqlType.int,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _dataEmissaoMeta = const VerificationMeta(
    'dataEmissao',
  );
  @override
  late final GeneratedColumn<DateTime> dataEmissao = GeneratedColumn<DateTime>(
    'data_emissao',
    aliasedName,
    true,
    type: DriftSqlType.dateTime,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _periodoInicialMeta = const VerificationMeta(
    'periodoInicial',
  );
  @override
  late final GeneratedColumn<DateTime> periodoInicial =
      GeneratedColumn<DateTime>(
        'periodo_inicial',
        aliasedName,
        true,
        type: DriftSqlType.dateTime,
        requiredDuringInsert: false,
      );
  static const VerificationMeta _periodoFinalMeta = const VerificationMeta(
    'periodoFinal',
  );
  @override
  late final GeneratedColumn<DateTime> periodoFinal = GeneratedColumn<DateTime>(
    'periodo_final',
    aliasedName,
    true,
    type: DriftSqlType.dateTime,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _tipoEventoMeta = const VerificationMeta(
    'tipoEvento',
  );
  @override
  late final GeneratedColumn<String> tipoEvento = GeneratedColumn<String>(
    'tipo_evento',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 1,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _ambienteMeta = const VerificationMeta(
    'ambiente',
  );
  @override
  late final GeneratedColumn<String> ambiente = GeneratedColumn<String>(
    'ambiente',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 1,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _idEmpresaMeta = const VerificationMeta(
    'idEmpresa',
  );
  @override
  late final GeneratedColumn<int> idEmpresa = GeneratedColumn<int>(
    'id_empresa',
    aliasedName,
    true,
    type: DriftSqlType.int,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _idContadorMeta = const VerificationMeta(
    'idContador',
  );
  @override
  late final GeneratedColumn<int> idContador = GeneratedColumn<int>(
    'id_contador',
    aliasedName,
    true,
    type: DriftSqlType.int,
    requiredDuringInsert: false,
  );
  @override
  List<GeneratedColumn> get $columns => [
    id,
    dataEmissao,
    periodoInicial,
    periodoFinal,
    tipoEvento,
    ambiente,
    idEmpresa,
    idContador,
  ];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'gera_efd_reinf';
  @override
  VerificationContext validateIntegrity(
    Insertable<GeraEfdReinf> instance, {
    bool isInserting = false,
  }) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('data_emissao')) {
      context.handle(
        _dataEmissaoMeta,
        dataEmissao.isAcceptableOrUnknown(
          data['data_emissao']!,
          _dataEmissaoMeta,
        ),
      );
    }
    if (data.containsKey('periodo_inicial')) {
      context.handle(
        _periodoInicialMeta,
        periodoInicial.isAcceptableOrUnknown(
          data['periodo_inicial']!,
          _periodoInicialMeta,
        ),
      );
    }
    if (data.containsKey('periodo_final')) {
      context.handle(
        _periodoFinalMeta,
        periodoFinal.isAcceptableOrUnknown(
          data['periodo_final']!,
          _periodoFinalMeta,
        ),
      );
    }
    if (data.containsKey('tipo_evento')) {
      context.handle(
        _tipoEventoMeta,
        tipoEvento.isAcceptableOrUnknown(data['tipo_evento']!, _tipoEventoMeta),
      );
    }
    if (data.containsKey('ambiente')) {
      context.handle(
        _ambienteMeta,
        ambiente.isAcceptableOrUnknown(data['ambiente']!, _ambienteMeta),
      );
    }
    if (data.containsKey('id_empresa')) {
      context.handle(
        _idEmpresaMeta,
        idEmpresa.isAcceptableOrUnknown(data['id_empresa']!, _idEmpresaMeta),
      );
    }
    if (data.containsKey('id_contador')) {
      context.handle(
        _idContadorMeta,
        idContador.isAcceptableOrUnknown(data['id_contador']!, _idContadorMeta),
      );
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  GeraEfdReinf map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return GeraEfdReinf(
      id: attachedDatabase.typeMapping.read(
        DriftSqlType.int,
        data['${effectivePrefix}id'],
      ),
      dataEmissao: attachedDatabase.typeMapping.read(
        DriftSqlType.dateTime,
        data['${effectivePrefix}data_emissao'],
      ),
      periodoInicial: attachedDatabase.typeMapping.read(
        DriftSqlType.dateTime,
        data['${effectivePrefix}periodo_inicial'],
      ),
      periodoFinal: attachedDatabase.typeMapping.read(
        DriftSqlType.dateTime,
        data['${effectivePrefix}periodo_final'],
      ),
      tipoEvento: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}tipo_evento'],
      ),
      ambiente: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}ambiente'],
      ),
      idEmpresa: attachedDatabase.typeMapping.read(
        DriftSqlType.int,
        data['${effectivePrefix}id_empresa'],
      ),
      idContador: attachedDatabase.typeMapping.read(
        DriftSqlType.int,
        data['${effectivePrefix}id_contador'],
      ),
    );
  }

  @override
  $GeraEfdReinfsTable createAlias(String alias) {
    return $GeraEfdReinfsTable(attachedDatabase, alias);
  }
}

class GeraEfdReinf extends DataClass implements Insertable<GeraEfdReinf> {
  final int? id;
  final DateTime? dataEmissao;
  final DateTime? periodoInicial;
  final DateTime? periodoFinal;
  final String? tipoEvento;
  final String? ambiente;
  final int? idEmpresa;
  final int? idContador;
  const GeraEfdReinf({
    this.id,
    this.dataEmissao,
    this.periodoInicial,
    this.periodoFinal,
    this.tipoEvento,
    this.ambiente,
    this.idEmpresa,
    this.idContador,
  });
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || dataEmissao != null) {
      map['data_emissao'] = Variable<DateTime>(dataEmissao);
    }
    if (!nullToAbsent || periodoInicial != null) {
      map['periodo_inicial'] = Variable<DateTime>(periodoInicial);
    }
    if (!nullToAbsent || periodoFinal != null) {
      map['periodo_final'] = Variable<DateTime>(periodoFinal);
    }
    if (!nullToAbsent || tipoEvento != null) {
      map['tipo_evento'] = Variable<String>(tipoEvento);
    }
    if (!nullToAbsent || ambiente != null) {
      map['ambiente'] = Variable<String>(ambiente);
    }
    if (!nullToAbsent || idEmpresa != null) {
      map['id_empresa'] = Variable<int>(idEmpresa);
    }
    if (!nullToAbsent || idContador != null) {
      map['id_contador'] = Variable<int>(idContador);
    }
    return map;
  }

  factory GeraEfdReinf.fromJson(
    Map<String, dynamic> json, {
    ValueSerializer? serializer,
  }) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return GeraEfdReinf(
      id: serializer.fromJson<int?>(json['id']),
      dataEmissao: serializer.fromJson<DateTime?>(json['dataEmissao']),
      periodoInicial: serializer.fromJson<DateTime?>(json['periodoInicial']),
      periodoFinal: serializer.fromJson<DateTime?>(json['periodoFinal']),
      tipoEvento: serializer.fromJson<String?>(json['tipoEvento']),
      ambiente: serializer.fromJson<String?>(json['ambiente']),
      idEmpresa: serializer.fromJson<int?>(json['idEmpresa']),
      idContador: serializer.fromJson<int?>(json['idContador']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'dataEmissao': serializer.toJson<DateTime?>(dataEmissao),
      'periodoInicial': serializer.toJson<DateTime?>(periodoInicial),
      'periodoFinal': serializer.toJson<DateTime?>(periodoFinal),
      'tipoEvento': serializer.toJson<String?>(tipoEvento),
      'ambiente': serializer.toJson<String?>(ambiente),
      'idEmpresa': serializer.toJson<int?>(idEmpresa),
      'idContador': serializer.toJson<int?>(idContador),
    };
  }

  GeraEfdReinf copyWith({
    Value<int?> id = const Value.absent(),
    Value<DateTime?> dataEmissao = const Value.absent(),
    Value<DateTime?> periodoInicial = const Value.absent(),
    Value<DateTime?> periodoFinal = const Value.absent(),
    Value<String?> tipoEvento = const Value.absent(),
    Value<String?> ambiente = const Value.absent(),
    Value<int?> idEmpresa = const Value.absent(),
    Value<int?> idContador = const Value.absent(),
  }) => GeraEfdReinf(
    id: id.present ? id.value : this.id,
    dataEmissao: dataEmissao.present ? dataEmissao.value : this.dataEmissao,
    periodoInicial:
        periodoInicial.present ? periodoInicial.value : this.periodoInicial,
    periodoFinal: periodoFinal.present ? periodoFinal.value : this.periodoFinal,
    tipoEvento: tipoEvento.present ? tipoEvento.value : this.tipoEvento,
    ambiente: ambiente.present ? ambiente.value : this.ambiente,
    idEmpresa: idEmpresa.present ? idEmpresa.value : this.idEmpresa,
    idContador: idContador.present ? idContador.value : this.idContador,
  );
  GeraEfdReinf copyWithCompanion(GeraEfdReinfsCompanion data) {
    return GeraEfdReinf(
      id: data.id.present ? data.id.value : this.id,
      dataEmissao:
          data.dataEmissao.present ? data.dataEmissao.value : this.dataEmissao,
      periodoInicial:
          data.periodoInicial.present
              ? data.periodoInicial.value
              : this.periodoInicial,
      periodoFinal:
          data.periodoFinal.present
              ? data.periodoFinal.value
              : this.periodoFinal,
      tipoEvento:
          data.tipoEvento.present ? data.tipoEvento.value : this.tipoEvento,
      ambiente: data.ambiente.present ? data.ambiente.value : this.ambiente,
      idEmpresa: data.idEmpresa.present ? data.idEmpresa.value : this.idEmpresa,
      idContador:
          data.idContador.present ? data.idContador.value : this.idContador,
    );
  }

  @override
  String toString() {
    return (StringBuffer('GeraEfdReinf(')
          ..write('id: $id, ')
          ..write('dataEmissao: $dataEmissao, ')
          ..write('periodoInicial: $periodoInicial, ')
          ..write('periodoFinal: $periodoFinal, ')
          ..write('tipoEvento: $tipoEvento, ')
          ..write('ambiente: $ambiente, ')
          ..write('idEmpresa: $idEmpresa, ')
          ..write('idContador: $idContador')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(
    id,
    dataEmissao,
    periodoInicial,
    periodoFinal,
    tipoEvento,
    ambiente,
    idEmpresa,
    idContador,
  );
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is GeraEfdReinf &&
          other.id == this.id &&
          other.dataEmissao == this.dataEmissao &&
          other.periodoInicial == this.periodoInicial &&
          other.periodoFinal == this.periodoFinal &&
          other.tipoEvento == this.tipoEvento &&
          other.ambiente == this.ambiente &&
          other.idEmpresa == this.idEmpresa &&
          other.idContador == this.idContador);
}

class GeraEfdReinfsCompanion extends UpdateCompanion<GeraEfdReinf> {
  final Value<int?> id;
  final Value<DateTime?> dataEmissao;
  final Value<DateTime?> periodoInicial;
  final Value<DateTime?> periodoFinal;
  final Value<String?> tipoEvento;
  final Value<String?> ambiente;
  final Value<int?> idEmpresa;
  final Value<int?> idContador;
  const GeraEfdReinfsCompanion({
    this.id = const Value.absent(),
    this.dataEmissao = const Value.absent(),
    this.periodoInicial = const Value.absent(),
    this.periodoFinal = const Value.absent(),
    this.tipoEvento = const Value.absent(),
    this.ambiente = const Value.absent(),
    this.idEmpresa = const Value.absent(),
    this.idContador = const Value.absent(),
  });
  GeraEfdReinfsCompanion.insert({
    this.id = const Value.absent(),
    this.dataEmissao = const Value.absent(),
    this.periodoInicial = const Value.absent(),
    this.periodoFinal = const Value.absent(),
    this.tipoEvento = const Value.absent(),
    this.ambiente = const Value.absent(),
    this.idEmpresa = const Value.absent(),
    this.idContador = const Value.absent(),
  });
  static Insertable<GeraEfdReinf> custom({
    Expression<int>? id,
    Expression<DateTime>? dataEmissao,
    Expression<DateTime>? periodoInicial,
    Expression<DateTime>? periodoFinal,
    Expression<String>? tipoEvento,
    Expression<String>? ambiente,
    Expression<int>? idEmpresa,
    Expression<int>? idContador,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (dataEmissao != null) 'data_emissao': dataEmissao,
      if (periodoInicial != null) 'periodo_inicial': periodoInicial,
      if (periodoFinal != null) 'periodo_final': periodoFinal,
      if (tipoEvento != null) 'tipo_evento': tipoEvento,
      if (ambiente != null) 'ambiente': ambiente,
      if (idEmpresa != null) 'id_empresa': idEmpresa,
      if (idContador != null) 'id_contador': idContador,
    });
  }

  GeraEfdReinfsCompanion copyWith({
    Value<int?>? id,
    Value<DateTime?>? dataEmissao,
    Value<DateTime?>? periodoInicial,
    Value<DateTime?>? periodoFinal,
    Value<String?>? tipoEvento,
    Value<String?>? ambiente,
    Value<int?>? idEmpresa,
    Value<int?>? idContador,
  }) {
    return GeraEfdReinfsCompanion(
      id: id ?? this.id,
      dataEmissao: dataEmissao ?? this.dataEmissao,
      periodoInicial: periodoInicial ?? this.periodoInicial,
      periodoFinal: periodoFinal ?? this.periodoFinal,
      tipoEvento: tipoEvento ?? this.tipoEvento,
      ambiente: ambiente ?? this.ambiente,
      idEmpresa: idEmpresa ?? this.idEmpresa,
      idContador: idContador ?? this.idContador,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (dataEmissao.present) {
      map['data_emissao'] = Variable<DateTime>(dataEmissao.value);
    }
    if (periodoInicial.present) {
      map['periodo_inicial'] = Variable<DateTime>(periodoInicial.value);
    }
    if (periodoFinal.present) {
      map['periodo_final'] = Variable<DateTime>(periodoFinal.value);
    }
    if (tipoEvento.present) {
      map['tipo_evento'] = Variable<String>(tipoEvento.value);
    }
    if (ambiente.present) {
      map['ambiente'] = Variable<String>(ambiente.value);
    }
    if (idEmpresa.present) {
      map['id_empresa'] = Variable<int>(idEmpresa.value);
    }
    if (idContador.present) {
      map['id_contador'] = Variable<int>(idContador.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('GeraEfdReinfsCompanion(')
          ..write('id: $id, ')
          ..write('dataEmissao: $dataEmissao, ')
          ..write('periodoInicial: $periodoInicial, ')
          ..write('periodoFinal: $periodoFinal, ')
          ..write('tipoEvento: $tipoEvento, ')
          ..write('ambiente: $ambiente, ')
          ..write('idEmpresa: $idEmpresa, ')
          ..write('idContador: $idContador')
          ..write(')'))
        .toString();
  }
}

class $GeraEsocialsTable extends GeraEsocials
    with TableInfo<$GeraEsocialsTable, GeraEsocial> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $GeraEsocialsTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
    'id',
    aliasedName,
    true,
    type: DriftSqlType.int,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _dataEmissaoMeta = const VerificationMeta(
    'dataEmissao',
  );
  @override
  late final GeneratedColumn<DateTime> dataEmissao = GeneratedColumn<DateTime>(
    'data_emissao',
    aliasedName,
    true,
    type: DriftSqlType.dateTime,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _periodoInicialMeta = const VerificationMeta(
    'periodoInicial',
  );
  @override
  late final GeneratedColumn<DateTime> periodoInicial =
      GeneratedColumn<DateTime>(
        'periodo_inicial',
        aliasedName,
        true,
        type: DriftSqlType.dateTime,
        requiredDuringInsert: false,
      );
  static const VerificationMeta _periodoFinalMeta = const VerificationMeta(
    'periodoFinal',
  );
  @override
  late final GeneratedColumn<DateTime> periodoFinal = GeneratedColumn<DateTime>(
    'periodo_final',
    aliasedName,
    true,
    type: DriftSqlType.dateTime,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _competenciaMeta = const VerificationMeta(
    'competencia',
  );
  @override
  late final GeneratedColumn<String> competencia = GeneratedColumn<String>(
    'competencia',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 7,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _idEmpresaMeta = const VerificationMeta(
    'idEmpresa',
  );
  @override
  late final GeneratedColumn<int> idEmpresa = GeneratedColumn<int>(
    'id_empresa',
    aliasedName,
    true,
    type: DriftSqlType.int,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _idContadorMeta = const VerificationMeta(
    'idContador',
  );
  @override
  late final GeneratedColumn<int> idContador = GeneratedColumn<int>(
    'id_contador',
    aliasedName,
    true,
    type: DriftSqlType.int,
    requiredDuringInsert: false,
  );
  @override
  List<GeneratedColumn> get $columns => [
    id,
    dataEmissao,
    periodoInicial,
    periodoFinal,
    competencia,
    idEmpresa,
    idContador,
  ];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'gera_esocial';
  @override
  VerificationContext validateIntegrity(
    Insertable<GeraEsocial> instance, {
    bool isInserting = false,
  }) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('data_emissao')) {
      context.handle(
        _dataEmissaoMeta,
        dataEmissao.isAcceptableOrUnknown(
          data['data_emissao']!,
          _dataEmissaoMeta,
        ),
      );
    }
    if (data.containsKey('periodo_inicial')) {
      context.handle(
        _periodoInicialMeta,
        periodoInicial.isAcceptableOrUnknown(
          data['periodo_inicial']!,
          _periodoInicialMeta,
        ),
      );
    }
    if (data.containsKey('periodo_final')) {
      context.handle(
        _periodoFinalMeta,
        periodoFinal.isAcceptableOrUnknown(
          data['periodo_final']!,
          _periodoFinalMeta,
        ),
      );
    }
    if (data.containsKey('competencia')) {
      context.handle(
        _competenciaMeta,
        competencia.isAcceptableOrUnknown(
          data['competencia']!,
          _competenciaMeta,
        ),
      );
    }
    if (data.containsKey('id_empresa')) {
      context.handle(
        _idEmpresaMeta,
        idEmpresa.isAcceptableOrUnknown(data['id_empresa']!, _idEmpresaMeta),
      );
    }
    if (data.containsKey('id_contador')) {
      context.handle(
        _idContadorMeta,
        idContador.isAcceptableOrUnknown(data['id_contador']!, _idContadorMeta),
      );
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  GeraEsocial map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return GeraEsocial(
      id: attachedDatabase.typeMapping.read(
        DriftSqlType.int,
        data['${effectivePrefix}id'],
      ),
      dataEmissao: attachedDatabase.typeMapping.read(
        DriftSqlType.dateTime,
        data['${effectivePrefix}data_emissao'],
      ),
      periodoInicial: attachedDatabase.typeMapping.read(
        DriftSqlType.dateTime,
        data['${effectivePrefix}periodo_inicial'],
      ),
      periodoFinal: attachedDatabase.typeMapping.read(
        DriftSqlType.dateTime,
        data['${effectivePrefix}periodo_final'],
      ),
      competencia: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}competencia'],
      ),
      idEmpresa: attachedDatabase.typeMapping.read(
        DriftSqlType.int,
        data['${effectivePrefix}id_empresa'],
      ),
      idContador: attachedDatabase.typeMapping.read(
        DriftSqlType.int,
        data['${effectivePrefix}id_contador'],
      ),
    );
  }

  @override
  $GeraEsocialsTable createAlias(String alias) {
    return $GeraEsocialsTable(attachedDatabase, alias);
  }
}

class GeraEsocial extends DataClass implements Insertable<GeraEsocial> {
  final int? id;
  final DateTime? dataEmissao;
  final DateTime? periodoInicial;
  final DateTime? periodoFinal;
  final String? competencia;
  final int? idEmpresa;
  final int? idContador;
  const GeraEsocial({
    this.id,
    this.dataEmissao,
    this.periodoInicial,
    this.periodoFinal,
    this.competencia,
    this.idEmpresa,
    this.idContador,
  });
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || dataEmissao != null) {
      map['data_emissao'] = Variable<DateTime>(dataEmissao);
    }
    if (!nullToAbsent || periodoInicial != null) {
      map['periodo_inicial'] = Variable<DateTime>(periodoInicial);
    }
    if (!nullToAbsent || periodoFinal != null) {
      map['periodo_final'] = Variable<DateTime>(periodoFinal);
    }
    if (!nullToAbsent || competencia != null) {
      map['competencia'] = Variable<String>(competencia);
    }
    if (!nullToAbsent || idEmpresa != null) {
      map['id_empresa'] = Variable<int>(idEmpresa);
    }
    if (!nullToAbsent || idContador != null) {
      map['id_contador'] = Variable<int>(idContador);
    }
    return map;
  }

  factory GeraEsocial.fromJson(
    Map<String, dynamic> json, {
    ValueSerializer? serializer,
  }) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return GeraEsocial(
      id: serializer.fromJson<int?>(json['id']),
      dataEmissao: serializer.fromJson<DateTime?>(json['dataEmissao']),
      periodoInicial: serializer.fromJson<DateTime?>(json['periodoInicial']),
      periodoFinal: serializer.fromJson<DateTime?>(json['periodoFinal']),
      competencia: serializer.fromJson<String?>(json['competencia']),
      idEmpresa: serializer.fromJson<int?>(json['idEmpresa']),
      idContador: serializer.fromJson<int?>(json['idContador']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'dataEmissao': serializer.toJson<DateTime?>(dataEmissao),
      'periodoInicial': serializer.toJson<DateTime?>(periodoInicial),
      'periodoFinal': serializer.toJson<DateTime?>(periodoFinal),
      'competencia': serializer.toJson<String?>(competencia),
      'idEmpresa': serializer.toJson<int?>(idEmpresa),
      'idContador': serializer.toJson<int?>(idContador),
    };
  }

  GeraEsocial copyWith({
    Value<int?> id = const Value.absent(),
    Value<DateTime?> dataEmissao = const Value.absent(),
    Value<DateTime?> periodoInicial = const Value.absent(),
    Value<DateTime?> periodoFinal = const Value.absent(),
    Value<String?> competencia = const Value.absent(),
    Value<int?> idEmpresa = const Value.absent(),
    Value<int?> idContador = const Value.absent(),
  }) => GeraEsocial(
    id: id.present ? id.value : this.id,
    dataEmissao: dataEmissao.present ? dataEmissao.value : this.dataEmissao,
    periodoInicial:
        periodoInicial.present ? periodoInicial.value : this.periodoInicial,
    periodoFinal: periodoFinal.present ? periodoFinal.value : this.periodoFinal,
    competencia: competencia.present ? competencia.value : this.competencia,
    idEmpresa: idEmpresa.present ? idEmpresa.value : this.idEmpresa,
    idContador: idContador.present ? idContador.value : this.idContador,
  );
  GeraEsocial copyWithCompanion(GeraEsocialsCompanion data) {
    return GeraEsocial(
      id: data.id.present ? data.id.value : this.id,
      dataEmissao:
          data.dataEmissao.present ? data.dataEmissao.value : this.dataEmissao,
      periodoInicial:
          data.periodoInicial.present
              ? data.periodoInicial.value
              : this.periodoInicial,
      periodoFinal:
          data.periodoFinal.present
              ? data.periodoFinal.value
              : this.periodoFinal,
      competencia:
          data.competencia.present ? data.competencia.value : this.competencia,
      idEmpresa: data.idEmpresa.present ? data.idEmpresa.value : this.idEmpresa,
      idContador:
          data.idContador.present ? data.idContador.value : this.idContador,
    );
  }

  @override
  String toString() {
    return (StringBuffer('GeraEsocial(')
          ..write('id: $id, ')
          ..write('dataEmissao: $dataEmissao, ')
          ..write('periodoInicial: $periodoInicial, ')
          ..write('periodoFinal: $periodoFinal, ')
          ..write('competencia: $competencia, ')
          ..write('idEmpresa: $idEmpresa, ')
          ..write('idContador: $idContador')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(
    id,
    dataEmissao,
    periodoInicial,
    periodoFinal,
    competencia,
    idEmpresa,
    idContador,
  );
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is GeraEsocial &&
          other.id == this.id &&
          other.dataEmissao == this.dataEmissao &&
          other.periodoInicial == this.periodoInicial &&
          other.periodoFinal == this.periodoFinal &&
          other.competencia == this.competencia &&
          other.idEmpresa == this.idEmpresa &&
          other.idContador == this.idContador);
}

class GeraEsocialsCompanion extends UpdateCompanion<GeraEsocial> {
  final Value<int?> id;
  final Value<DateTime?> dataEmissao;
  final Value<DateTime?> periodoInicial;
  final Value<DateTime?> periodoFinal;
  final Value<String?> competencia;
  final Value<int?> idEmpresa;
  final Value<int?> idContador;
  const GeraEsocialsCompanion({
    this.id = const Value.absent(),
    this.dataEmissao = const Value.absent(),
    this.periodoInicial = const Value.absent(),
    this.periodoFinal = const Value.absent(),
    this.competencia = const Value.absent(),
    this.idEmpresa = const Value.absent(),
    this.idContador = const Value.absent(),
  });
  GeraEsocialsCompanion.insert({
    this.id = const Value.absent(),
    this.dataEmissao = const Value.absent(),
    this.periodoInicial = const Value.absent(),
    this.periodoFinal = const Value.absent(),
    this.competencia = const Value.absent(),
    this.idEmpresa = const Value.absent(),
    this.idContador = const Value.absent(),
  });
  static Insertable<GeraEsocial> custom({
    Expression<int>? id,
    Expression<DateTime>? dataEmissao,
    Expression<DateTime>? periodoInicial,
    Expression<DateTime>? periodoFinal,
    Expression<String>? competencia,
    Expression<int>? idEmpresa,
    Expression<int>? idContador,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (dataEmissao != null) 'data_emissao': dataEmissao,
      if (periodoInicial != null) 'periodo_inicial': periodoInicial,
      if (periodoFinal != null) 'periodo_final': periodoFinal,
      if (competencia != null) 'competencia': competencia,
      if (idEmpresa != null) 'id_empresa': idEmpresa,
      if (idContador != null) 'id_contador': idContador,
    });
  }

  GeraEsocialsCompanion copyWith({
    Value<int?>? id,
    Value<DateTime?>? dataEmissao,
    Value<DateTime?>? periodoInicial,
    Value<DateTime?>? periodoFinal,
    Value<String?>? competencia,
    Value<int?>? idEmpresa,
    Value<int?>? idContador,
  }) {
    return GeraEsocialsCompanion(
      id: id ?? this.id,
      dataEmissao: dataEmissao ?? this.dataEmissao,
      periodoInicial: periodoInicial ?? this.periodoInicial,
      periodoFinal: periodoFinal ?? this.periodoFinal,
      competencia: competencia ?? this.competencia,
      idEmpresa: idEmpresa ?? this.idEmpresa,
      idContador: idContador ?? this.idContador,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (dataEmissao.present) {
      map['data_emissao'] = Variable<DateTime>(dataEmissao.value);
    }
    if (periodoInicial.present) {
      map['periodo_inicial'] = Variable<DateTime>(periodoInicial.value);
    }
    if (periodoFinal.present) {
      map['periodo_final'] = Variable<DateTime>(periodoFinal.value);
    }
    if (competencia.present) {
      map['competencia'] = Variable<String>(competencia.value);
    }
    if (idEmpresa.present) {
      map['id_empresa'] = Variable<int>(idEmpresa.value);
    }
    if (idContador.present) {
      map['id_contador'] = Variable<int>(idContador.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('GeraEsocialsCompanion(')
          ..write('id: $id, ')
          ..write('dataEmissao: $dataEmissao, ')
          ..write('periodoInicial: $periodoInicial, ')
          ..write('periodoFinal: $periodoFinal, ')
          ..write('competencia: $competencia, ')
          ..write('idEmpresa: $idEmpresa, ')
          ..write('idContador: $idContador')
          ..write(')'))
        .toString();
  }
}

abstract class _$AppDatabase extends GeneratedDatabase {
  _$AppDatabase(QueryExecutor e) : super(e);
  $AppDatabaseManager get managers => $AppDatabaseManager(this);
  late final $GeraSpedContabilsTable geraSpedContabils =
      $GeraSpedContabilsTable(this);
  late final $ViewControleAcessosTable viewControleAcessos =
      $ViewControleAcessosTable(this);
  late final $ViewPessoaUsuariosTable viewPessoaUsuarios =
      $ViewPessoaUsuariosTable(this);
  late final $GeraSpedFiscalsTable geraSpedFiscals = $GeraSpedFiscalsTable(
    this,
  );
  late final $GeraSintegrasTable geraSintegras = $GeraSintegrasTable(this);
  late final $GeraEfdContribuicoessTable geraEfdContribuicoess =
      $GeraEfdContribuicoessTable(this);
  late final $GeraEfdReinfsTable geraEfdReinfs = $GeraEfdReinfsTable(this);
  late final $GeraEsocialsTable geraEsocials = $GeraEsocialsTable(this);
  late final GeraSpedContabilDao geraSpedContabilDao = GeraSpedContabilDao(
    this as AppDatabase,
  );
  late final ViewControleAcessoDao viewControleAcessoDao =
      ViewControleAcessoDao(this as AppDatabase);
  late final ViewPessoaUsuarioDao viewPessoaUsuarioDao = ViewPessoaUsuarioDao(
    this as AppDatabase,
  );
  late final GeraSpedFiscalDao geraSpedFiscalDao = GeraSpedFiscalDao(
    this as AppDatabase,
  );
  late final GeraSintegraDao geraSintegraDao = GeraSintegraDao(
    this as AppDatabase,
  );
  late final GeraEfdContribuicoesDao geraEfdContribuicoesDao =
      GeraEfdContribuicoesDao(this as AppDatabase);
  late final GeraEfdReinfDao geraEfdReinfDao = GeraEfdReinfDao(
    this as AppDatabase,
  );
  late final GeraEsocialDao geraEsocialDao = GeraEsocialDao(
    this as AppDatabase,
  );
  @override
  Iterable<TableInfo<Table, Object?>> get allTables =>
      allSchemaEntities.whereType<TableInfo<Table, Object?>>();
  @override
  List<DatabaseSchemaEntity> get allSchemaEntities => [
    geraSpedContabils,
    viewControleAcessos,
    viewPessoaUsuarios,
    geraSpedFiscals,
    geraSintegras,
    geraEfdContribuicoess,
    geraEfdReinfs,
    geraEsocials,
  ];
}

typedef $$GeraSpedContabilsTableCreateCompanionBuilder =
    GeraSpedContabilsCompanion Function({
      Value<int?> id,
      Value<DateTime?> dataEmissao,
      Value<DateTime?> periodoInicial,
      Value<DateTime?> periodoFinal,
      Value<String?> formaEscrituracao,
      Value<String?> versaoLayout,
      Value<int?> idEmpresa,
      Value<int?> idContador,
    });
typedef $$GeraSpedContabilsTableUpdateCompanionBuilder =
    GeraSpedContabilsCompanion Function({
      Value<int?> id,
      Value<DateTime?> dataEmissao,
      Value<DateTime?> periodoInicial,
      Value<DateTime?> periodoFinal,
      Value<String?> formaEscrituracao,
      Value<String?> versaoLayout,
      Value<int?> idEmpresa,
      Value<int?> idContador,
    });

class $$GeraSpedContabilsTableFilterComposer
    extends Composer<_$AppDatabase, $GeraSpedContabilsTable> {
  $$GeraSpedContabilsTableFilterComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnFilters<int> get id => $composableBuilder(
    column: $table.id,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<DateTime> get dataEmissao => $composableBuilder(
    column: $table.dataEmissao,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<DateTime> get periodoInicial => $composableBuilder(
    column: $table.periodoInicial,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<DateTime> get periodoFinal => $composableBuilder(
    column: $table.periodoFinal,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get formaEscrituracao => $composableBuilder(
    column: $table.formaEscrituracao,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get versaoLayout => $composableBuilder(
    column: $table.versaoLayout,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<int> get idEmpresa => $composableBuilder(
    column: $table.idEmpresa,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<int> get idContador => $composableBuilder(
    column: $table.idContador,
    builder: (column) => ColumnFilters(column),
  );
}

class $$GeraSpedContabilsTableOrderingComposer
    extends Composer<_$AppDatabase, $GeraSpedContabilsTable> {
  $$GeraSpedContabilsTableOrderingComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnOrderings<int> get id => $composableBuilder(
    column: $table.id,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<DateTime> get dataEmissao => $composableBuilder(
    column: $table.dataEmissao,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<DateTime> get periodoInicial => $composableBuilder(
    column: $table.periodoInicial,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<DateTime> get periodoFinal => $composableBuilder(
    column: $table.periodoFinal,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get formaEscrituracao => $composableBuilder(
    column: $table.formaEscrituracao,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get versaoLayout => $composableBuilder(
    column: $table.versaoLayout,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<int> get idEmpresa => $composableBuilder(
    column: $table.idEmpresa,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<int> get idContador => $composableBuilder(
    column: $table.idContador,
    builder: (column) => ColumnOrderings(column),
  );
}

class $$GeraSpedContabilsTableAnnotationComposer
    extends Composer<_$AppDatabase, $GeraSpedContabilsTable> {
  $$GeraSpedContabilsTableAnnotationComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  GeneratedColumn<int> get id =>
      $composableBuilder(column: $table.id, builder: (column) => column);

  GeneratedColumn<DateTime> get dataEmissao => $composableBuilder(
    column: $table.dataEmissao,
    builder: (column) => column,
  );

  GeneratedColumn<DateTime> get periodoInicial => $composableBuilder(
    column: $table.periodoInicial,
    builder: (column) => column,
  );

  GeneratedColumn<DateTime> get periodoFinal => $composableBuilder(
    column: $table.periodoFinal,
    builder: (column) => column,
  );

  GeneratedColumn<String> get formaEscrituracao => $composableBuilder(
    column: $table.formaEscrituracao,
    builder: (column) => column,
  );

  GeneratedColumn<String> get versaoLayout => $composableBuilder(
    column: $table.versaoLayout,
    builder: (column) => column,
  );

  GeneratedColumn<int> get idEmpresa =>
      $composableBuilder(column: $table.idEmpresa, builder: (column) => column);

  GeneratedColumn<int> get idContador => $composableBuilder(
    column: $table.idContador,
    builder: (column) => column,
  );
}

class $$GeraSpedContabilsTableTableManager
    extends
        RootTableManager<
          _$AppDatabase,
          $GeraSpedContabilsTable,
          GeraSpedContabil,
          $$GeraSpedContabilsTableFilterComposer,
          $$GeraSpedContabilsTableOrderingComposer,
          $$GeraSpedContabilsTableAnnotationComposer,
          $$GeraSpedContabilsTableCreateCompanionBuilder,
          $$GeraSpedContabilsTableUpdateCompanionBuilder,
          (
            GeraSpedContabil,
            BaseReferences<
              _$AppDatabase,
              $GeraSpedContabilsTable,
              GeraSpedContabil
            >,
          ),
          GeraSpedContabil,
          PrefetchHooks Function()
        > {
  $$GeraSpedContabilsTableTableManager(
    _$AppDatabase db,
    $GeraSpedContabilsTable table,
  ) : super(
        TableManagerState(
          db: db,
          table: table,
          createFilteringComposer:
              () => $$GeraSpedContabilsTableFilterComposer(
                $db: db,
                $table: table,
              ),
          createOrderingComposer:
              () => $$GeraSpedContabilsTableOrderingComposer(
                $db: db,
                $table: table,
              ),
          createComputedFieldComposer:
              () => $$GeraSpedContabilsTableAnnotationComposer(
                $db: db,
                $table: table,
              ),
          updateCompanionCallback:
              ({
                Value<int?> id = const Value.absent(),
                Value<DateTime?> dataEmissao = const Value.absent(),
                Value<DateTime?> periodoInicial = const Value.absent(),
                Value<DateTime?> periodoFinal = const Value.absent(),
                Value<String?> formaEscrituracao = const Value.absent(),
                Value<String?> versaoLayout = const Value.absent(),
                Value<int?> idEmpresa = const Value.absent(),
                Value<int?> idContador = const Value.absent(),
              }) => GeraSpedContabilsCompanion(
                id: id,
                dataEmissao: dataEmissao,
                periodoInicial: periodoInicial,
                periodoFinal: periodoFinal,
                formaEscrituracao: formaEscrituracao,
                versaoLayout: versaoLayout,
                idEmpresa: idEmpresa,
                idContador: idContador,
              ),
          createCompanionCallback:
              ({
                Value<int?> id = const Value.absent(),
                Value<DateTime?> dataEmissao = const Value.absent(),
                Value<DateTime?> periodoInicial = const Value.absent(),
                Value<DateTime?> periodoFinal = const Value.absent(),
                Value<String?> formaEscrituracao = const Value.absent(),
                Value<String?> versaoLayout = const Value.absent(),
                Value<int?> idEmpresa = const Value.absent(),
                Value<int?> idContador = const Value.absent(),
              }) => GeraSpedContabilsCompanion.insert(
                id: id,
                dataEmissao: dataEmissao,
                periodoInicial: periodoInicial,
                periodoFinal: periodoFinal,
                formaEscrituracao: formaEscrituracao,
                versaoLayout: versaoLayout,
                idEmpresa: idEmpresa,
                idContador: idContador,
              ),
          withReferenceMapper:
              (p0) =>
                  p0
                      .map(
                        (e) => (
                          e.readTable(table),
                          BaseReferences(db, table, e),
                        ),
                      )
                      .toList(),
          prefetchHooksCallback: null,
        ),
      );
}

typedef $$GeraSpedContabilsTableProcessedTableManager =
    ProcessedTableManager<
      _$AppDatabase,
      $GeraSpedContabilsTable,
      GeraSpedContabil,
      $$GeraSpedContabilsTableFilterComposer,
      $$GeraSpedContabilsTableOrderingComposer,
      $$GeraSpedContabilsTableAnnotationComposer,
      $$GeraSpedContabilsTableCreateCompanionBuilder,
      $$GeraSpedContabilsTableUpdateCompanionBuilder,
      (
        GeraSpedContabil,
        BaseReferences<
          _$AppDatabase,
          $GeraSpedContabilsTable,
          GeraSpedContabil
        >,
      ),
      GeraSpedContabil,
      PrefetchHooks Function()
    >;
typedef $$ViewControleAcessosTableCreateCompanionBuilder =
    ViewControleAcessosCompanion Function({
      Value<int?> id,
      Value<int?> idPessoa,
      Value<String?> pessoaNome,
      Value<int?> idColaborador,
      Value<int?> idUsuario,
      Value<String?> administrador,
      Value<int?> idPapel,
      Value<String?> papelNome,
      Value<String?> papelDescricao,
      Value<int?> idFuncao,
      Value<String?> funcaoNome,
      Value<String?> funcaoDescricao,
      Value<int?> idPapelFuncao,
      Value<String?> habilitado,
      Value<String?> podeInserir,
      Value<String?> podeAlterar,
      Value<String?> podeExcluir,
    });
typedef $$ViewControleAcessosTableUpdateCompanionBuilder =
    ViewControleAcessosCompanion Function({
      Value<int?> id,
      Value<int?> idPessoa,
      Value<String?> pessoaNome,
      Value<int?> idColaborador,
      Value<int?> idUsuario,
      Value<String?> administrador,
      Value<int?> idPapel,
      Value<String?> papelNome,
      Value<String?> papelDescricao,
      Value<int?> idFuncao,
      Value<String?> funcaoNome,
      Value<String?> funcaoDescricao,
      Value<int?> idPapelFuncao,
      Value<String?> habilitado,
      Value<String?> podeInserir,
      Value<String?> podeAlterar,
      Value<String?> podeExcluir,
    });

class $$ViewControleAcessosTableFilterComposer
    extends Composer<_$AppDatabase, $ViewControleAcessosTable> {
  $$ViewControleAcessosTableFilterComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnFilters<int> get id => $composableBuilder(
    column: $table.id,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<int> get idPessoa => $composableBuilder(
    column: $table.idPessoa,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get pessoaNome => $composableBuilder(
    column: $table.pessoaNome,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<int> get idColaborador => $composableBuilder(
    column: $table.idColaborador,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<int> get idUsuario => $composableBuilder(
    column: $table.idUsuario,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get administrador => $composableBuilder(
    column: $table.administrador,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<int> get idPapel => $composableBuilder(
    column: $table.idPapel,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get papelNome => $composableBuilder(
    column: $table.papelNome,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get papelDescricao => $composableBuilder(
    column: $table.papelDescricao,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<int> get idFuncao => $composableBuilder(
    column: $table.idFuncao,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get funcaoNome => $composableBuilder(
    column: $table.funcaoNome,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get funcaoDescricao => $composableBuilder(
    column: $table.funcaoDescricao,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<int> get idPapelFuncao => $composableBuilder(
    column: $table.idPapelFuncao,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get habilitado => $composableBuilder(
    column: $table.habilitado,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get podeInserir => $composableBuilder(
    column: $table.podeInserir,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get podeAlterar => $composableBuilder(
    column: $table.podeAlterar,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get podeExcluir => $composableBuilder(
    column: $table.podeExcluir,
    builder: (column) => ColumnFilters(column),
  );
}

class $$ViewControleAcessosTableOrderingComposer
    extends Composer<_$AppDatabase, $ViewControleAcessosTable> {
  $$ViewControleAcessosTableOrderingComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnOrderings<int> get id => $composableBuilder(
    column: $table.id,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<int> get idPessoa => $composableBuilder(
    column: $table.idPessoa,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get pessoaNome => $composableBuilder(
    column: $table.pessoaNome,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<int> get idColaborador => $composableBuilder(
    column: $table.idColaborador,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<int> get idUsuario => $composableBuilder(
    column: $table.idUsuario,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get administrador => $composableBuilder(
    column: $table.administrador,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<int> get idPapel => $composableBuilder(
    column: $table.idPapel,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get papelNome => $composableBuilder(
    column: $table.papelNome,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get papelDescricao => $composableBuilder(
    column: $table.papelDescricao,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<int> get idFuncao => $composableBuilder(
    column: $table.idFuncao,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get funcaoNome => $composableBuilder(
    column: $table.funcaoNome,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get funcaoDescricao => $composableBuilder(
    column: $table.funcaoDescricao,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<int> get idPapelFuncao => $composableBuilder(
    column: $table.idPapelFuncao,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get habilitado => $composableBuilder(
    column: $table.habilitado,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get podeInserir => $composableBuilder(
    column: $table.podeInserir,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get podeAlterar => $composableBuilder(
    column: $table.podeAlterar,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get podeExcluir => $composableBuilder(
    column: $table.podeExcluir,
    builder: (column) => ColumnOrderings(column),
  );
}

class $$ViewControleAcessosTableAnnotationComposer
    extends Composer<_$AppDatabase, $ViewControleAcessosTable> {
  $$ViewControleAcessosTableAnnotationComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  GeneratedColumn<int> get id =>
      $composableBuilder(column: $table.id, builder: (column) => column);

  GeneratedColumn<int> get idPessoa =>
      $composableBuilder(column: $table.idPessoa, builder: (column) => column);

  GeneratedColumn<String> get pessoaNome => $composableBuilder(
    column: $table.pessoaNome,
    builder: (column) => column,
  );

  GeneratedColumn<int> get idColaborador => $composableBuilder(
    column: $table.idColaborador,
    builder: (column) => column,
  );

  GeneratedColumn<int> get idUsuario =>
      $composableBuilder(column: $table.idUsuario, builder: (column) => column);

  GeneratedColumn<String> get administrador => $composableBuilder(
    column: $table.administrador,
    builder: (column) => column,
  );

  GeneratedColumn<int> get idPapel =>
      $composableBuilder(column: $table.idPapel, builder: (column) => column);

  GeneratedColumn<String> get papelNome =>
      $composableBuilder(column: $table.papelNome, builder: (column) => column);

  GeneratedColumn<String> get papelDescricao => $composableBuilder(
    column: $table.papelDescricao,
    builder: (column) => column,
  );

  GeneratedColumn<int> get idFuncao =>
      $composableBuilder(column: $table.idFuncao, builder: (column) => column);

  GeneratedColumn<String> get funcaoNome => $composableBuilder(
    column: $table.funcaoNome,
    builder: (column) => column,
  );

  GeneratedColumn<String> get funcaoDescricao => $composableBuilder(
    column: $table.funcaoDescricao,
    builder: (column) => column,
  );

  GeneratedColumn<int> get idPapelFuncao => $composableBuilder(
    column: $table.idPapelFuncao,
    builder: (column) => column,
  );

  GeneratedColumn<String> get habilitado => $composableBuilder(
    column: $table.habilitado,
    builder: (column) => column,
  );

  GeneratedColumn<String> get podeInserir => $composableBuilder(
    column: $table.podeInserir,
    builder: (column) => column,
  );

  GeneratedColumn<String> get podeAlterar => $composableBuilder(
    column: $table.podeAlterar,
    builder: (column) => column,
  );

  GeneratedColumn<String> get podeExcluir => $composableBuilder(
    column: $table.podeExcluir,
    builder: (column) => column,
  );
}

class $$ViewControleAcessosTableTableManager
    extends
        RootTableManager<
          _$AppDatabase,
          $ViewControleAcessosTable,
          ViewControleAcesso,
          $$ViewControleAcessosTableFilterComposer,
          $$ViewControleAcessosTableOrderingComposer,
          $$ViewControleAcessosTableAnnotationComposer,
          $$ViewControleAcessosTableCreateCompanionBuilder,
          $$ViewControleAcessosTableUpdateCompanionBuilder,
          (
            ViewControleAcesso,
            BaseReferences<
              _$AppDatabase,
              $ViewControleAcessosTable,
              ViewControleAcesso
            >,
          ),
          ViewControleAcesso,
          PrefetchHooks Function()
        > {
  $$ViewControleAcessosTableTableManager(
    _$AppDatabase db,
    $ViewControleAcessosTable table,
  ) : super(
        TableManagerState(
          db: db,
          table: table,
          createFilteringComposer:
              () => $$ViewControleAcessosTableFilterComposer(
                $db: db,
                $table: table,
              ),
          createOrderingComposer:
              () => $$ViewControleAcessosTableOrderingComposer(
                $db: db,
                $table: table,
              ),
          createComputedFieldComposer:
              () => $$ViewControleAcessosTableAnnotationComposer(
                $db: db,
                $table: table,
              ),
          updateCompanionCallback:
              ({
                Value<int?> id = const Value.absent(),
                Value<int?> idPessoa = const Value.absent(),
                Value<String?> pessoaNome = const Value.absent(),
                Value<int?> idColaborador = const Value.absent(),
                Value<int?> idUsuario = const Value.absent(),
                Value<String?> administrador = const Value.absent(),
                Value<int?> idPapel = const Value.absent(),
                Value<String?> papelNome = const Value.absent(),
                Value<String?> papelDescricao = const Value.absent(),
                Value<int?> idFuncao = const Value.absent(),
                Value<String?> funcaoNome = const Value.absent(),
                Value<String?> funcaoDescricao = const Value.absent(),
                Value<int?> idPapelFuncao = const Value.absent(),
                Value<String?> habilitado = const Value.absent(),
                Value<String?> podeInserir = const Value.absent(),
                Value<String?> podeAlterar = const Value.absent(),
                Value<String?> podeExcluir = const Value.absent(),
              }) => ViewControleAcessosCompanion(
                id: id,
                idPessoa: idPessoa,
                pessoaNome: pessoaNome,
                idColaborador: idColaborador,
                idUsuario: idUsuario,
                administrador: administrador,
                idPapel: idPapel,
                papelNome: papelNome,
                papelDescricao: papelDescricao,
                idFuncao: idFuncao,
                funcaoNome: funcaoNome,
                funcaoDescricao: funcaoDescricao,
                idPapelFuncao: idPapelFuncao,
                habilitado: habilitado,
                podeInserir: podeInserir,
                podeAlterar: podeAlterar,
                podeExcluir: podeExcluir,
              ),
          createCompanionCallback:
              ({
                Value<int?> id = const Value.absent(),
                Value<int?> idPessoa = const Value.absent(),
                Value<String?> pessoaNome = const Value.absent(),
                Value<int?> idColaborador = const Value.absent(),
                Value<int?> idUsuario = const Value.absent(),
                Value<String?> administrador = const Value.absent(),
                Value<int?> idPapel = const Value.absent(),
                Value<String?> papelNome = const Value.absent(),
                Value<String?> papelDescricao = const Value.absent(),
                Value<int?> idFuncao = const Value.absent(),
                Value<String?> funcaoNome = const Value.absent(),
                Value<String?> funcaoDescricao = const Value.absent(),
                Value<int?> idPapelFuncao = const Value.absent(),
                Value<String?> habilitado = const Value.absent(),
                Value<String?> podeInserir = const Value.absent(),
                Value<String?> podeAlterar = const Value.absent(),
                Value<String?> podeExcluir = const Value.absent(),
              }) => ViewControleAcessosCompanion.insert(
                id: id,
                idPessoa: idPessoa,
                pessoaNome: pessoaNome,
                idColaborador: idColaborador,
                idUsuario: idUsuario,
                administrador: administrador,
                idPapel: idPapel,
                papelNome: papelNome,
                papelDescricao: papelDescricao,
                idFuncao: idFuncao,
                funcaoNome: funcaoNome,
                funcaoDescricao: funcaoDescricao,
                idPapelFuncao: idPapelFuncao,
                habilitado: habilitado,
                podeInserir: podeInserir,
                podeAlterar: podeAlterar,
                podeExcluir: podeExcluir,
              ),
          withReferenceMapper:
              (p0) =>
                  p0
                      .map(
                        (e) => (
                          e.readTable(table),
                          BaseReferences(db, table, e),
                        ),
                      )
                      .toList(),
          prefetchHooksCallback: null,
        ),
      );
}

typedef $$ViewControleAcessosTableProcessedTableManager =
    ProcessedTableManager<
      _$AppDatabase,
      $ViewControleAcessosTable,
      ViewControleAcesso,
      $$ViewControleAcessosTableFilterComposer,
      $$ViewControleAcessosTableOrderingComposer,
      $$ViewControleAcessosTableAnnotationComposer,
      $$ViewControleAcessosTableCreateCompanionBuilder,
      $$ViewControleAcessosTableUpdateCompanionBuilder,
      (
        ViewControleAcesso,
        BaseReferences<
          _$AppDatabase,
          $ViewControleAcessosTable,
          ViewControleAcesso
        >,
      ),
      ViewControleAcesso,
      PrefetchHooks Function()
    >;
typedef $$ViewPessoaUsuariosTableCreateCompanionBuilder =
    ViewPessoaUsuariosCompanion Function({
      Value<int?> id,
      Value<int?> idPessoa,
      Value<String?> pessoaNome,
      Value<String?> tipo,
      Value<String?> email,
      Value<int?> idColaborador,
      Value<int?> idUsuario,
      Value<String?> login,
      Value<String?> senha,
      Value<DateTime?> dataCadastro,
      Value<String?> administrador,
    });
typedef $$ViewPessoaUsuariosTableUpdateCompanionBuilder =
    ViewPessoaUsuariosCompanion Function({
      Value<int?> id,
      Value<int?> idPessoa,
      Value<String?> pessoaNome,
      Value<String?> tipo,
      Value<String?> email,
      Value<int?> idColaborador,
      Value<int?> idUsuario,
      Value<String?> login,
      Value<String?> senha,
      Value<DateTime?> dataCadastro,
      Value<String?> administrador,
    });

class $$ViewPessoaUsuariosTableFilterComposer
    extends Composer<_$AppDatabase, $ViewPessoaUsuariosTable> {
  $$ViewPessoaUsuariosTableFilterComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnFilters<int> get id => $composableBuilder(
    column: $table.id,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<int> get idPessoa => $composableBuilder(
    column: $table.idPessoa,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get pessoaNome => $composableBuilder(
    column: $table.pessoaNome,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get tipo => $composableBuilder(
    column: $table.tipo,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get email => $composableBuilder(
    column: $table.email,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<int> get idColaborador => $composableBuilder(
    column: $table.idColaborador,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<int> get idUsuario => $composableBuilder(
    column: $table.idUsuario,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get login => $composableBuilder(
    column: $table.login,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get senha => $composableBuilder(
    column: $table.senha,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<DateTime> get dataCadastro => $composableBuilder(
    column: $table.dataCadastro,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get administrador => $composableBuilder(
    column: $table.administrador,
    builder: (column) => ColumnFilters(column),
  );
}

class $$ViewPessoaUsuariosTableOrderingComposer
    extends Composer<_$AppDatabase, $ViewPessoaUsuariosTable> {
  $$ViewPessoaUsuariosTableOrderingComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnOrderings<int> get id => $composableBuilder(
    column: $table.id,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<int> get idPessoa => $composableBuilder(
    column: $table.idPessoa,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get pessoaNome => $composableBuilder(
    column: $table.pessoaNome,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get tipo => $composableBuilder(
    column: $table.tipo,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get email => $composableBuilder(
    column: $table.email,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<int> get idColaborador => $composableBuilder(
    column: $table.idColaborador,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<int> get idUsuario => $composableBuilder(
    column: $table.idUsuario,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get login => $composableBuilder(
    column: $table.login,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get senha => $composableBuilder(
    column: $table.senha,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<DateTime> get dataCadastro => $composableBuilder(
    column: $table.dataCadastro,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get administrador => $composableBuilder(
    column: $table.administrador,
    builder: (column) => ColumnOrderings(column),
  );
}

class $$ViewPessoaUsuariosTableAnnotationComposer
    extends Composer<_$AppDatabase, $ViewPessoaUsuariosTable> {
  $$ViewPessoaUsuariosTableAnnotationComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  GeneratedColumn<int> get id =>
      $composableBuilder(column: $table.id, builder: (column) => column);

  GeneratedColumn<int> get idPessoa =>
      $composableBuilder(column: $table.idPessoa, builder: (column) => column);

  GeneratedColumn<String> get pessoaNome => $composableBuilder(
    column: $table.pessoaNome,
    builder: (column) => column,
  );

  GeneratedColumn<String> get tipo =>
      $composableBuilder(column: $table.tipo, builder: (column) => column);

  GeneratedColumn<String> get email =>
      $composableBuilder(column: $table.email, builder: (column) => column);

  GeneratedColumn<int> get idColaborador => $composableBuilder(
    column: $table.idColaborador,
    builder: (column) => column,
  );

  GeneratedColumn<int> get idUsuario =>
      $composableBuilder(column: $table.idUsuario, builder: (column) => column);

  GeneratedColumn<String> get login =>
      $composableBuilder(column: $table.login, builder: (column) => column);

  GeneratedColumn<String> get senha =>
      $composableBuilder(column: $table.senha, builder: (column) => column);

  GeneratedColumn<DateTime> get dataCadastro => $composableBuilder(
    column: $table.dataCadastro,
    builder: (column) => column,
  );

  GeneratedColumn<String> get administrador => $composableBuilder(
    column: $table.administrador,
    builder: (column) => column,
  );
}

class $$ViewPessoaUsuariosTableTableManager
    extends
        RootTableManager<
          _$AppDatabase,
          $ViewPessoaUsuariosTable,
          ViewPessoaUsuario,
          $$ViewPessoaUsuariosTableFilterComposer,
          $$ViewPessoaUsuariosTableOrderingComposer,
          $$ViewPessoaUsuariosTableAnnotationComposer,
          $$ViewPessoaUsuariosTableCreateCompanionBuilder,
          $$ViewPessoaUsuariosTableUpdateCompanionBuilder,
          (
            ViewPessoaUsuario,
            BaseReferences<
              _$AppDatabase,
              $ViewPessoaUsuariosTable,
              ViewPessoaUsuario
            >,
          ),
          ViewPessoaUsuario,
          PrefetchHooks Function()
        > {
  $$ViewPessoaUsuariosTableTableManager(
    _$AppDatabase db,
    $ViewPessoaUsuariosTable table,
  ) : super(
        TableManagerState(
          db: db,
          table: table,
          createFilteringComposer:
              () => $$ViewPessoaUsuariosTableFilterComposer(
                $db: db,
                $table: table,
              ),
          createOrderingComposer:
              () => $$ViewPessoaUsuariosTableOrderingComposer(
                $db: db,
                $table: table,
              ),
          createComputedFieldComposer:
              () => $$ViewPessoaUsuariosTableAnnotationComposer(
                $db: db,
                $table: table,
              ),
          updateCompanionCallback:
              ({
                Value<int?> id = const Value.absent(),
                Value<int?> idPessoa = const Value.absent(),
                Value<String?> pessoaNome = const Value.absent(),
                Value<String?> tipo = const Value.absent(),
                Value<String?> email = const Value.absent(),
                Value<int?> idColaborador = const Value.absent(),
                Value<int?> idUsuario = const Value.absent(),
                Value<String?> login = const Value.absent(),
                Value<String?> senha = const Value.absent(),
                Value<DateTime?> dataCadastro = const Value.absent(),
                Value<String?> administrador = const Value.absent(),
              }) => ViewPessoaUsuariosCompanion(
                id: id,
                idPessoa: idPessoa,
                pessoaNome: pessoaNome,
                tipo: tipo,
                email: email,
                idColaborador: idColaborador,
                idUsuario: idUsuario,
                login: login,
                senha: senha,
                dataCadastro: dataCadastro,
                administrador: administrador,
              ),
          createCompanionCallback:
              ({
                Value<int?> id = const Value.absent(),
                Value<int?> idPessoa = const Value.absent(),
                Value<String?> pessoaNome = const Value.absent(),
                Value<String?> tipo = const Value.absent(),
                Value<String?> email = const Value.absent(),
                Value<int?> idColaborador = const Value.absent(),
                Value<int?> idUsuario = const Value.absent(),
                Value<String?> login = const Value.absent(),
                Value<String?> senha = const Value.absent(),
                Value<DateTime?> dataCadastro = const Value.absent(),
                Value<String?> administrador = const Value.absent(),
              }) => ViewPessoaUsuariosCompanion.insert(
                id: id,
                idPessoa: idPessoa,
                pessoaNome: pessoaNome,
                tipo: tipo,
                email: email,
                idColaborador: idColaborador,
                idUsuario: idUsuario,
                login: login,
                senha: senha,
                dataCadastro: dataCadastro,
                administrador: administrador,
              ),
          withReferenceMapper:
              (p0) =>
                  p0
                      .map(
                        (e) => (
                          e.readTable(table),
                          BaseReferences(db, table, e),
                        ),
                      )
                      .toList(),
          prefetchHooksCallback: null,
        ),
      );
}

typedef $$ViewPessoaUsuariosTableProcessedTableManager =
    ProcessedTableManager<
      _$AppDatabase,
      $ViewPessoaUsuariosTable,
      ViewPessoaUsuario,
      $$ViewPessoaUsuariosTableFilterComposer,
      $$ViewPessoaUsuariosTableOrderingComposer,
      $$ViewPessoaUsuariosTableAnnotationComposer,
      $$ViewPessoaUsuariosTableCreateCompanionBuilder,
      $$ViewPessoaUsuariosTableUpdateCompanionBuilder,
      (
        ViewPessoaUsuario,
        BaseReferences<
          _$AppDatabase,
          $ViewPessoaUsuariosTable,
          ViewPessoaUsuario
        >,
      ),
      ViewPessoaUsuario,
      PrefetchHooks Function()
    >;
typedef $$GeraSpedFiscalsTableCreateCompanionBuilder =
    GeraSpedFiscalsCompanion Function({
      Value<int?> id,
      Value<DateTime?> dataEmissao,
      Value<DateTime?> periodoInicial,
      Value<DateTime?> periodoFinal,
      Value<String?> versaoLayout,
      Value<String?> finalidadeArquivo,
      Value<String?> perfilApresentacao,
      Value<String?> inventario,
      Value<int?> idEmpresa,
      Value<int?> idContador,
    });
typedef $$GeraSpedFiscalsTableUpdateCompanionBuilder =
    GeraSpedFiscalsCompanion Function({
      Value<int?> id,
      Value<DateTime?> dataEmissao,
      Value<DateTime?> periodoInicial,
      Value<DateTime?> periodoFinal,
      Value<String?> versaoLayout,
      Value<String?> finalidadeArquivo,
      Value<String?> perfilApresentacao,
      Value<String?> inventario,
      Value<int?> idEmpresa,
      Value<int?> idContador,
    });

class $$GeraSpedFiscalsTableFilterComposer
    extends Composer<_$AppDatabase, $GeraSpedFiscalsTable> {
  $$GeraSpedFiscalsTableFilterComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnFilters<int> get id => $composableBuilder(
    column: $table.id,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<DateTime> get dataEmissao => $composableBuilder(
    column: $table.dataEmissao,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<DateTime> get periodoInicial => $composableBuilder(
    column: $table.periodoInicial,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<DateTime> get periodoFinal => $composableBuilder(
    column: $table.periodoFinal,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get versaoLayout => $composableBuilder(
    column: $table.versaoLayout,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get finalidadeArquivo => $composableBuilder(
    column: $table.finalidadeArquivo,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get perfilApresentacao => $composableBuilder(
    column: $table.perfilApresentacao,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get inventario => $composableBuilder(
    column: $table.inventario,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<int> get idEmpresa => $composableBuilder(
    column: $table.idEmpresa,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<int> get idContador => $composableBuilder(
    column: $table.idContador,
    builder: (column) => ColumnFilters(column),
  );
}

class $$GeraSpedFiscalsTableOrderingComposer
    extends Composer<_$AppDatabase, $GeraSpedFiscalsTable> {
  $$GeraSpedFiscalsTableOrderingComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnOrderings<int> get id => $composableBuilder(
    column: $table.id,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<DateTime> get dataEmissao => $composableBuilder(
    column: $table.dataEmissao,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<DateTime> get periodoInicial => $composableBuilder(
    column: $table.periodoInicial,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<DateTime> get periodoFinal => $composableBuilder(
    column: $table.periodoFinal,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get versaoLayout => $composableBuilder(
    column: $table.versaoLayout,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get finalidadeArquivo => $composableBuilder(
    column: $table.finalidadeArquivo,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get perfilApresentacao => $composableBuilder(
    column: $table.perfilApresentacao,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get inventario => $composableBuilder(
    column: $table.inventario,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<int> get idEmpresa => $composableBuilder(
    column: $table.idEmpresa,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<int> get idContador => $composableBuilder(
    column: $table.idContador,
    builder: (column) => ColumnOrderings(column),
  );
}

class $$GeraSpedFiscalsTableAnnotationComposer
    extends Composer<_$AppDatabase, $GeraSpedFiscalsTable> {
  $$GeraSpedFiscalsTableAnnotationComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  GeneratedColumn<int> get id =>
      $composableBuilder(column: $table.id, builder: (column) => column);

  GeneratedColumn<DateTime> get dataEmissao => $composableBuilder(
    column: $table.dataEmissao,
    builder: (column) => column,
  );

  GeneratedColumn<DateTime> get periodoInicial => $composableBuilder(
    column: $table.periodoInicial,
    builder: (column) => column,
  );

  GeneratedColumn<DateTime> get periodoFinal => $composableBuilder(
    column: $table.periodoFinal,
    builder: (column) => column,
  );

  GeneratedColumn<String> get versaoLayout => $composableBuilder(
    column: $table.versaoLayout,
    builder: (column) => column,
  );

  GeneratedColumn<String> get finalidadeArquivo => $composableBuilder(
    column: $table.finalidadeArquivo,
    builder: (column) => column,
  );

  GeneratedColumn<String> get perfilApresentacao => $composableBuilder(
    column: $table.perfilApresentacao,
    builder: (column) => column,
  );

  GeneratedColumn<String> get inventario => $composableBuilder(
    column: $table.inventario,
    builder: (column) => column,
  );

  GeneratedColumn<int> get idEmpresa =>
      $composableBuilder(column: $table.idEmpresa, builder: (column) => column);

  GeneratedColumn<int> get idContador => $composableBuilder(
    column: $table.idContador,
    builder: (column) => column,
  );
}

class $$GeraSpedFiscalsTableTableManager
    extends
        RootTableManager<
          _$AppDatabase,
          $GeraSpedFiscalsTable,
          GeraSpedFiscal,
          $$GeraSpedFiscalsTableFilterComposer,
          $$GeraSpedFiscalsTableOrderingComposer,
          $$GeraSpedFiscalsTableAnnotationComposer,
          $$GeraSpedFiscalsTableCreateCompanionBuilder,
          $$GeraSpedFiscalsTableUpdateCompanionBuilder,
          (
            GeraSpedFiscal,
            BaseReferences<
              _$AppDatabase,
              $GeraSpedFiscalsTable,
              GeraSpedFiscal
            >,
          ),
          GeraSpedFiscal,
          PrefetchHooks Function()
        > {
  $$GeraSpedFiscalsTableTableManager(
    _$AppDatabase db,
    $GeraSpedFiscalsTable table,
  ) : super(
        TableManagerState(
          db: db,
          table: table,
          createFilteringComposer:
              () =>
                  $$GeraSpedFiscalsTableFilterComposer($db: db, $table: table),
          createOrderingComposer:
              () => $$GeraSpedFiscalsTableOrderingComposer(
                $db: db,
                $table: table,
              ),
          createComputedFieldComposer:
              () => $$GeraSpedFiscalsTableAnnotationComposer(
                $db: db,
                $table: table,
              ),
          updateCompanionCallback:
              ({
                Value<int?> id = const Value.absent(),
                Value<DateTime?> dataEmissao = const Value.absent(),
                Value<DateTime?> periodoInicial = const Value.absent(),
                Value<DateTime?> periodoFinal = const Value.absent(),
                Value<String?> versaoLayout = const Value.absent(),
                Value<String?> finalidadeArquivo = const Value.absent(),
                Value<String?> perfilApresentacao = const Value.absent(),
                Value<String?> inventario = const Value.absent(),
                Value<int?> idEmpresa = const Value.absent(),
                Value<int?> idContador = const Value.absent(),
              }) => GeraSpedFiscalsCompanion(
                id: id,
                dataEmissao: dataEmissao,
                periodoInicial: periodoInicial,
                periodoFinal: periodoFinal,
                versaoLayout: versaoLayout,
                finalidadeArquivo: finalidadeArquivo,
                perfilApresentacao: perfilApresentacao,
                inventario: inventario,
                idEmpresa: idEmpresa,
                idContador: idContador,
              ),
          createCompanionCallback:
              ({
                Value<int?> id = const Value.absent(),
                Value<DateTime?> dataEmissao = const Value.absent(),
                Value<DateTime?> periodoInicial = const Value.absent(),
                Value<DateTime?> periodoFinal = const Value.absent(),
                Value<String?> versaoLayout = const Value.absent(),
                Value<String?> finalidadeArquivo = const Value.absent(),
                Value<String?> perfilApresentacao = const Value.absent(),
                Value<String?> inventario = const Value.absent(),
                Value<int?> idEmpresa = const Value.absent(),
                Value<int?> idContador = const Value.absent(),
              }) => GeraSpedFiscalsCompanion.insert(
                id: id,
                dataEmissao: dataEmissao,
                periodoInicial: periodoInicial,
                periodoFinal: periodoFinal,
                versaoLayout: versaoLayout,
                finalidadeArquivo: finalidadeArquivo,
                perfilApresentacao: perfilApresentacao,
                inventario: inventario,
                idEmpresa: idEmpresa,
                idContador: idContador,
              ),
          withReferenceMapper:
              (p0) =>
                  p0
                      .map(
                        (e) => (
                          e.readTable(table),
                          BaseReferences(db, table, e),
                        ),
                      )
                      .toList(),
          prefetchHooksCallback: null,
        ),
      );
}

typedef $$GeraSpedFiscalsTableProcessedTableManager =
    ProcessedTableManager<
      _$AppDatabase,
      $GeraSpedFiscalsTable,
      GeraSpedFiscal,
      $$GeraSpedFiscalsTableFilterComposer,
      $$GeraSpedFiscalsTableOrderingComposer,
      $$GeraSpedFiscalsTableAnnotationComposer,
      $$GeraSpedFiscalsTableCreateCompanionBuilder,
      $$GeraSpedFiscalsTableUpdateCompanionBuilder,
      (
        GeraSpedFiscal,
        BaseReferences<_$AppDatabase, $GeraSpedFiscalsTable, GeraSpedFiscal>,
      ),
      GeraSpedFiscal,
      PrefetchHooks Function()
    >;
typedef $$GeraSintegrasTableCreateCompanionBuilder =
    GeraSintegrasCompanion Function({
      Value<int?> id,
      Value<DateTime?> dataEmissao,
      Value<DateTime?> periodoInicial,
      Value<DateTime?> periodoFinal,
      Value<String?> codigoConvenio,
      Value<String?> finalidadeArquivo,
      Value<String?> naturezaInformacoes,
      Value<String?> inventario,
      Value<int?> idEmpresa,
      Value<int?> idContador,
    });
typedef $$GeraSintegrasTableUpdateCompanionBuilder =
    GeraSintegrasCompanion Function({
      Value<int?> id,
      Value<DateTime?> dataEmissao,
      Value<DateTime?> periodoInicial,
      Value<DateTime?> periodoFinal,
      Value<String?> codigoConvenio,
      Value<String?> finalidadeArquivo,
      Value<String?> naturezaInformacoes,
      Value<String?> inventario,
      Value<int?> idEmpresa,
      Value<int?> idContador,
    });

class $$GeraSintegrasTableFilterComposer
    extends Composer<_$AppDatabase, $GeraSintegrasTable> {
  $$GeraSintegrasTableFilterComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnFilters<int> get id => $composableBuilder(
    column: $table.id,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<DateTime> get dataEmissao => $composableBuilder(
    column: $table.dataEmissao,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<DateTime> get periodoInicial => $composableBuilder(
    column: $table.periodoInicial,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<DateTime> get periodoFinal => $composableBuilder(
    column: $table.periodoFinal,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get codigoConvenio => $composableBuilder(
    column: $table.codigoConvenio,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get finalidadeArquivo => $composableBuilder(
    column: $table.finalidadeArquivo,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get naturezaInformacoes => $composableBuilder(
    column: $table.naturezaInformacoes,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get inventario => $composableBuilder(
    column: $table.inventario,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<int> get idEmpresa => $composableBuilder(
    column: $table.idEmpresa,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<int> get idContador => $composableBuilder(
    column: $table.idContador,
    builder: (column) => ColumnFilters(column),
  );
}

class $$GeraSintegrasTableOrderingComposer
    extends Composer<_$AppDatabase, $GeraSintegrasTable> {
  $$GeraSintegrasTableOrderingComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnOrderings<int> get id => $composableBuilder(
    column: $table.id,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<DateTime> get dataEmissao => $composableBuilder(
    column: $table.dataEmissao,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<DateTime> get periodoInicial => $composableBuilder(
    column: $table.periodoInicial,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<DateTime> get periodoFinal => $composableBuilder(
    column: $table.periodoFinal,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get codigoConvenio => $composableBuilder(
    column: $table.codigoConvenio,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get finalidadeArquivo => $composableBuilder(
    column: $table.finalidadeArquivo,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get naturezaInformacoes => $composableBuilder(
    column: $table.naturezaInformacoes,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get inventario => $composableBuilder(
    column: $table.inventario,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<int> get idEmpresa => $composableBuilder(
    column: $table.idEmpresa,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<int> get idContador => $composableBuilder(
    column: $table.idContador,
    builder: (column) => ColumnOrderings(column),
  );
}

class $$GeraSintegrasTableAnnotationComposer
    extends Composer<_$AppDatabase, $GeraSintegrasTable> {
  $$GeraSintegrasTableAnnotationComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  GeneratedColumn<int> get id =>
      $composableBuilder(column: $table.id, builder: (column) => column);

  GeneratedColumn<DateTime> get dataEmissao => $composableBuilder(
    column: $table.dataEmissao,
    builder: (column) => column,
  );

  GeneratedColumn<DateTime> get periodoInicial => $composableBuilder(
    column: $table.periodoInicial,
    builder: (column) => column,
  );

  GeneratedColumn<DateTime> get periodoFinal => $composableBuilder(
    column: $table.periodoFinal,
    builder: (column) => column,
  );

  GeneratedColumn<String> get codigoConvenio => $composableBuilder(
    column: $table.codigoConvenio,
    builder: (column) => column,
  );

  GeneratedColumn<String> get finalidadeArquivo => $composableBuilder(
    column: $table.finalidadeArquivo,
    builder: (column) => column,
  );

  GeneratedColumn<String> get naturezaInformacoes => $composableBuilder(
    column: $table.naturezaInformacoes,
    builder: (column) => column,
  );

  GeneratedColumn<String> get inventario => $composableBuilder(
    column: $table.inventario,
    builder: (column) => column,
  );

  GeneratedColumn<int> get idEmpresa =>
      $composableBuilder(column: $table.idEmpresa, builder: (column) => column);

  GeneratedColumn<int> get idContador => $composableBuilder(
    column: $table.idContador,
    builder: (column) => column,
  );
}

class $$GeraSintegrasTableTableManager
    extends
        RootTableManager<
          _$AppDatabase,
          $GeraSintegrasTable,
          GeraSintegra,
          $$GeraSintegrasTableFilterComposer,
          $$GeraSintegrasTableOrderingComposer,
          $$GeraSintegrasTableAnnotationComposer,
          $$GeraSintegrasTableCreateCompanionBuilder,
          $$GeraSintegrasTableUpdateCompanionBuilder,
          (
            GeraSintegra,
            BaseReferences<_$AppDatabase, $GeraSintegrasTable, GeraSintegra>,
          ),
          GeraSintegra,
          PrefetchHooks Function()
        > {
  $$GeraSintegrasTableTableManager(_$AppDatabase db, $GeraSintegrasTable table)
    : super(
        TableManagerState(
          db: db,
          table: table,
          createFilteringComposer:
              () => $$GeraSintegrasTableFilterComposer($db: db, $table: table),
          createOrderingComposer:
              () =>
                  $$GeraSintegrasTableOrderingComposer($db: db, $table: table),
          createComputedFieldComposer:
              () => $$GeraSintegrasTableAnnotationComposer(
                $db: db,
                $table: table,
              ),
          updateCompanionCallback:
              ({
                Value<int?> id = const Value.absent(),
                Value<DateTime?> dataEmissao = const Value.absent(),
                Value<DateTime?> periodoInicial = const Value.absent(),
                Value<DateTime?> periodoFinal = const Value.absent(),
                Value<String?> codigoConvenio = const Value.absent(),
                Value<String?> finalidadeArquivo = const Value.absent(),
                Value<String?> naturezaInformacoes = const Value.absent(),
                Value<String?> inventario = const Value.absent(),
                Value<int?> idEmpresa = const Value.absent(),
                Value<int?> idContador = const Value.absent(),
              }) => GeraSintegrasCompanion(
                id: id,
                dataEmissao: dataEmissao,
                periodoInicial: periodoInicial,
                periodoFinal: periodoFinal,
                codigoConvenio: codigoConvenio,
                finalidadeArquivo: finalidadeArquivo,
                naturezaInformacoes: naturezaInformacoes,
                inventario: inventario,
                idEmpresa: idEmpresa,
                idContador: idContador,
              ),
          createCompanionCallback:
              ({
                Value<int?> id = const Value.absent(),
                Value<DateTime?> dataEmissao = const Value.absent(),
                Value<DateTime?> periodoInicial = const Value.absent(),
                Value<DateTime?> periodoFinal = const Value.absent(),
                Value<String?> codigoConvenio = const Value.absent(),
                Value<String?> finalidadeArquivo = const Value.absent(),
                Value<String?> naturezaInformacoes = const Value.absent(),
                Value<String?> inventario = const Value.absent(),
                Value<int?> idEmpresa = const Value.absent(),
                Value<int?> idContador = const Value.absent(),
              }) => GeraSintegrasCompanion.insert(
                id: id,
                dataEmissao: dataEmissao,
                periodoInicial: periodoInicial,
                periodoFinal: periodoFinal,
                codigoConvenio: codigoConvenio,
                finalidadeArquivo: finalidadeArquivo,
                naturezaInformacoes: naturezaInformacoes,
                inventario: inventario,
                idEmpresa: idEmpresa,
                idContador: idContador,
              ),
          withReferenceMapper:
              (p0) =>
                  p0
                      .map(
                        (e) => (
                          e.readTable(table),
                          BaseReferences(db, table, e),
                        ),
                      )
                      .toList(),
          prefetchHooksCallback: null,
        ),
      );
}

typedef $$GeraSintegrasTableProcessedTableManager =
    ProcessedTableManager<
      _$AppDatabase,
      $GeraSintegrasTable,
      GeraSintegra,
      $$GeraSintegrasTableFilterComposer,
      $$GeraSintegrasTableOrderingComposer,
      $$GeraSintegrasTableAnnotationComposer,
      $$GeraSintegrasTableCreateCompanionBuilder,
      $$GeraSintegrasTableUpdateCompanionBuilder,
      (
        GeraSintegra,
        BaseReferences<_$AppDatabase, $GeraSintegrasTable, GeraSintegra>,
      ),
      GeraSintegra,
      PrefetchHooks Function()
    >;
typedef $$GeraEfdContribuicoessTableCreateCompanionBuilder =
    GeraEfdContribuicoessCompanion Function({
      Value<int?> id,
      Value<DateTime?> dataEmissao,
      Value<DateTime?> periodoInicial,
      Value<DateTime?> periodoFinal,
      Value<String?> versaoLayout,
      Value<String?> tipoEscrituracao,
      Value<int?> idEmpersa,
      Value<int?> idContador,
    });
typedef $$GeraEfdContribuicoessTableUpdateCompanionBuilder =
    GeraEfdContribuicoessCompanion Function({
      Value<int?> id,
      Value<DateTime?> dataEmissao,
      Value<DateTime?> periodoInicial,
      Value<DateTime?> periodoFinal,
      Value<String?> versaoLayout,
      Value<String?> tipoEscrituracao,
      Value<int?> idEmpersa,
      Value<int?> idContador,
    });

class $$GeraEfdContribuicoessTableFilterComposer
    extends Composer<_$AppDatabase, $GeraEfdContribuicoessTable> {
  $$GeraEfdContribuicoessTableFilterComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnFilters<int> get id => $composableBuilder(
    column: $table.id,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<DateTime> get dataEmissao => $composableBuilder(
    column: $table.dataEmissao,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<DateTime> get periodoInicial => $composableBuilder(
    column: $table.periodoInicial,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<DateTime> get periodoFinal => $composableBuilder(
    column: $table.periodoFinal,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get versaoLayout => $composableBuilder(
    column: $table.versaoLayout,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get tipoEscrituracao => $composableBuilder(
    column: $table.tipoEscrituracao,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<int> get idEmpersa => $composableBuilder(
    column: $table.idEmpersa,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<int> get idContador => $composableBuilder(
    column: $table.idContador,
    builder: (column) => ColumnFilters(column),
  );
}

class $$GeraEfdContribuicoessTableOrderingComposer
    extends Composer<_$AppDatabase, $GeraEfdContribuicoessTable> {
  $$GeraEfdContribuicoessTableOrderingComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnOrderings<int> get id => $composableBuilder(
    column: $table.id,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<DateTime> get dataEmissao => $composableBuilder(
    column: $table.dataEmissao,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<DateTime> get periodoInicial => $composableBuilder(
    column: $table.periodoInicial,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<DateTime> get periodoFinal => $composableBuilder(
    column: $table.periodoFinal,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get versaoLayout => $composableBuilder(
    column: $table.versaoLayout,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get tipoEscrituracao => $composableBuilder(
    column: $table.tipoEscrituracao,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<int> get idEmpersa => $composableBuilder(
    column: $table.idEmpersa,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<int> get idContador => $composableBuilder(
    column: $table.idContador,
    builder: (column) => ColumnOrderings(column),
  );
}

class $$GeraEfdContribuicoessTableAnnotationComposer
    extends Composer<_$AppDatabase, $GeraEfdContribuicoessTable> {
  $$GeraEfdContribuicoessTableAnnotationComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  GeneratedColumn<int> get id =>
      $composableBuilder(column: $table.id, builder: (column) => column);

  GeneratedColumn<DateTime> get dataEmissao => $composableBuilder(
    column: $table.dataEmissao,
    builder: (column) => column,
  );

  GeneratedColumn<DateTime> get periodoInicial => $composableBuilder(
    column: $table.periodoInicial,
    builder: (column) => column,
  );

  GeneratedColumn<DateTime> get periodoFinal => $composableBuilder(
    column: $table.periodoFinal,
    builder: (column) => column,
  );

  GeneratedColumn<String> get versaoLayout => $composableBuilder(
    column: $table.versaoLayout,
    builder: (column) => column,
  );

  GeneratedColumn<String> get tipoEscrituracao => $composableBuilder(
    column: $table.tipoEscrituracao,
    builder: (column) => column,
  );

  GeneratedColumn<int> get idEmpersa =>
      $composableBuilder(column: $table.idEmpersa, builder: (column) => column);

  GeneratedColumn<int> get idContador => $composableBuilder(
    column: $table.idContador,
    builder: (column) => column,
  );
}

class $$GeraEfdContribuicoessTableTableManager
    extends
        RootTableManager<
          _$AppDatabase,
          $GeraEfdContribuicoessTable,
          GeraEfdContribuicoes,
          $$GeraEfdContribuicoessTableFilterComposer,
          $$GeraEfdContribuicoessTableOrderingComposer,
          $$GeraEfdContribuicoessTableAnnotationComposer,
          $$GeraEfdContribuicoessTableCreateCompanionBuilder,
          $$GeraEfdContribuicoessTableUpdateCompanionBuilder,
          (
            GeraEfdContribuicoes,
            BaseReferences<
              _$AppDatabase,
              $GeraEfdContribuicoessTable,
              GeraEfdContribuicoes
            >,
          ),
          GeraEfdContribuicoes,
          PrefetchHooks Function()
        > {
  $$GeraEfdContribuicoessTableTableManager(
    _$AppDatabase db,
    $GeraEfdContribuicoessTable table,
  ) : super(
        TableManagerState(
          db: db,
          table: table,
          createFilteringComposer:
              () => $$GeraEfdContribuicoessTableFilterComposer(
                $db: db,
                $table: table,
              ),
          createOrderingComposer:
              () => $$GeraEfdContribuicoessTableOrderingComposer(
                $db: db,
                $table: table,
              ),
          createComputedFieldComposer:
              () => $$GeraEfdContribuicoessTableAnnotationComposer(
                $db: db,
                $table: table,
              ),
          updateCompanionCallback:
              ({
                Value<int?> id = const Value.absent(),
                Value<DateTime?> dataEmissao = const Value.absent(),
                Value<DateTime?> periodoInicial = const Value.absent(),
                Value<DateTime?> periodoFinal = const Value.absent(),
                Value<String?> versaoLayout = const Value.absent(),
                Value<String?> tipoEscrituracao = const Value.absent(),
                Value<int?> idEmpersa = const Value.absent(),
                Value<int?> idContador = const Value.absent(),
              }) => GeraEfdContribuicoessCompanion(
                id: id,
                dataEmissao: dataEmissao,
                periodoInicial: periodoInicial,
                periodoFinal: periodoFinal,
                versaoLayout: versaoLayout,
                tipoEscrituracao: tipoEscrituracao,
                idEmpersa: idEmpersa,
                idContador: idContador,
              ),
          createCompanionCallback:
              ({
                Value<int?> id = const Value.absent(),
                Value<DateTime?> dataEmissao = const Value.absent(),
                Value<DateTime?> periodoInicial = const Value.absent(),
                Value<DateTime?> periodoFinal = const Value.absent(),
                Value<String?> versaoLayout = const Value.absent(),
                Value<String?> tipoEscrituracao = const Value.absent(),
                Value<int?> idEmpersa = const Value.absent(),
                Value<int?> idContador = const Value.absent(),
              }) => GeraEfdContribuicoessCompanion.insert(
                id: id,
                dataEmissao: dataEmissao,
                periodoInicial: periodoInicial,
                periodoFinal: periodoFinal,
                versaoLayout: versaoLayout,
                tipoEscrituracao: tipoEscrituracao,
                idEmpersa: idEmpersa,
                idContador: idContador,
              ),
          withReferenceMapper:
              (p0) =>
                  p0
                      .map(
                        (e) => (
                          e.readTable(table),
                          BaseReferences(db, table, e),
                        ),
                      )
                      .toList(),
          prefetchHooksCallback: null,
        ),
      );
}

typedef $$GeraEfdContribuicoessTableProcessedTableManager =
    ProcessedTableManager<
      _$AppDatabase,
      $GeraEfdContribuicoessTable,
      GeraEfdContribuicoes,
      $$GeraEfdContribuicoessTableFilterComposer,
      $$GeraEfdContribuicoessTableOrderingComposer,
      $$GeraEfdContribuicoessTableAnnotationComposer,
      $$GeraEfdContribuicoessTableCreateCompanionBuilder,
      $$GeraEfdContribuicoessTableUpdateCompanionBuilder,
      (
        GeraEfdContribuicoes,
        BaseReferences<
          _$AppDatabase,
          $GeraEfdContribuicoessTable,
          GeraEfdContribuicoes
        >,
      ),
      GeraEfdContribuicoes,
      PrefetchHooks Function()
    >;
typedef $$GeraEfdReinfsTableCreateCompanionBuilder =
    GeraEfdReinfsCompanion Function({
      Value<int?> id,
      Value<DateTime?> dataEmissao,
      Value<DateTime?> periodoInicial,
      Value<DateTime?> periodoFinal,
      Value<String?> tipoEvento,
      Value<String?> ambiente,
      Value<int?> idEmpresa,
      Value<int?> idContador,
    });
typedef $$GeraEfdReinfsTableUpdateCompanionBuilder =
    GeraEfdReinfsCompanion Function({
      Value<int?> id,
      Value<DateTime?> dataEmissao,
      Value<DateTime?> periodoInicial,
      Value<DateTime?> periodoFinal,
      Value<String?> tipoEvento,
      Value<String?> ambiente,
      Value<int?> idEmpresa,
      Value<int?> idContador,
    });

class $$GeraEfdReinfsTableFilterComposer
    extends Composer<_$AppDatabase, $GeraEfdReinfsTable> {
  $$GeraEfdReinfsTableFilterComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnFilters<int> get id => $composableBuilder(
    column: $table.id,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<DateTime> get dataEmissao => $composableBuilder(
    column: $table.dataEmissao,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<DateTime> get periodoInicial => $composableBuilder(
    column: $table.periodoInicial,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<DateTime> get periodoFinal => $composableBuilder(
    column: $table.periodoFinal,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get tipoEvento => $composableBuilder(
    column: $table.tipoEvento,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get ambiente => $composableBuilder(
    column: $table.ambiente,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<int> get idEmpresa => $composableBuilder(
    column: $table.idEmpresa,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<int> get idContador => $composableBuilder(
    column: $table.idContador,
    builder: (column) => ColumnFilters(column),
  );
}

class $$GeraEfdReinfsTableOrderingComposer
    extends Composer<_$AppDatabase, $GeraEfdReinfsTable> {
  $$GeraEfdReinfsTableOrderingComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnOrderings<int> get id => $composableBuilder(
    column: $table.id,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<DateTime> get dataEmissao => $composableBuilder(
    column: $table.dataEmissao,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<DateTime> get periodoInicial => $composableBuilder(
    column: $table.periodoInicial,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<DateTime> get periodoFinal => $composableBuilder(
    column: $table.periodoFinal,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get tipoEvento => $composableBuilder(
    column: $table.tipoEvento,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get ambiente => $composableBuilder(
    column: $table.ambiente,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<int> get idEmpresa => $composableBuilder(
    column: $table.idEmpresa,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<int> get idContador => $composableBuilder(
    column: $table.idContador,
    builder: (column) => ColumnOrderings(column),
  );
}

class $$GeraEfdReinfsTableAnnotationComposer
    extends Composer<_$AppDatabase, $GeraEfdReinfsTable> {
  $$GeraEfdReinfsTableAnnotationComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  GeneratedColumn<int> get id =>
      $composableBuilder(column: $table.id, builder: (column) => column);

  GeneratedColumn<DateTime> get dataEmissao => $composableBuilder(
    column: $table.dataEmissao,
    builder: (column) => column,
  );

  GeneratedColumn<DateTime> get periodoInicial => $composableBuilder(
    column: $table.periodoInicial,
    builder: (column) => column,
  );

  GeneratedColumn<DateTime> get periodoFinal => $composableBuilder(
    column: $table.periodoFinal,
    builder: (column) => column,
  );

  GeneratedColumn<String> get tipoEvento => $composableBuilder(
    column: $table.tipoEvento,
    builder: (column) => column,
  );

  GeneratedColumn<String> get ambiente =>
      $composableBuilder(column: $table.ambiente, builder: (column) => column);

  GeneratedColumn<int> get idEmpresa =>
      $composableBuilder(column: $table.idEmpresa, builder: (column) => column);

  GeneratedColumn<int> get idContador => $composableBuilder(
    column: $table.idContador,
    builder: (column) => column,
  );
}

class $$GeraEfdReinfsTableTableManager
    extends
        RootTableManager<
          _$AppDatabase,
          $GeraEfdReinfsTable,
          GeraEfdReinf,
          $$GeraEfdReinfsTableFilterComposer,
          $$GeraEfdReinfsTableOrderingComposer,
          $$GeraEfdReinfsTableAnnotationComposer,
          $$GeraEfdReinfsTableCreateCompanionBuilder,
          $$GeraEfdReinfsTableUpdateCompanionBuilder,
          (
            GeraEfdReinf,
            BaseReferences<_$AppDatabase, $GeraEfdReinfsTable, GeraEfdReinf>,
          ),
          GeraEfdReinf,
          PrefetchHooks Function()
        > {
  $$GeraEfdReinfsTableTableManager(_$AppDatabase db, $GeraEfdReinfsTable table)
    : super(
        TableManagerState(
          db: db,
          table: table,
          createFilteringComposer:
              () => $$GeraEfdReinfsTableFilterComposer($db: db, $table: table),
          createOrderingComposer:
              () =>
                  $$GeraEfdReinfsTableOrderingComposer($db: db, $table: table),
          createComputedFieldComposer:
              () => $$GeraEfdReinfsTableAnnotationComposer(
                $db: db,
                $table: table,
              ),
          updateCompanionCallback:
              ({
                Value<int?> id = const Value.absent(),
                Value<DateTime?> dataEmissao = const Value.absent(),
                Value<DateTime?> periodoInicial = const Value.absent(),
                Value<DateTime?> periodoFinal = const Value.absent(),
                Value<String?> tipoEvento = const Value.absent(),
                Value<String?> ambiente = const Value.absent(),
                Value<int?> idEmpresa = const Value.absent(),
                Value<int?> idContador = const Value.absent(),
              }) => GeraEfdReinfsCompanion(
                id: id,
                dataEmissao: dataEmissao,
                periodoInicial: periodoInicial,
                periodoFinal: periodoFinal,
                tipoEvento: tipoEvento,
                ambiente: ambiente,
                idEmpresa: idEmpresa,
                idContador: idContador,
              ),
          createCompanionCallback:
              ({
                Value<int?> id = const Value.absent(),
                Value<DateTime?> dataEmissao = const Value.absent(),
                Value<DateTime?> periodoInicial = const Value.absent(),
                Value<DateTime?> periodoFinal = const Value.absent(),
                Value<String?> tipoEvento = const Value.absent(),
                Value<String?> ambiente = const Value.absent(),
                Value<int?> idEmpresa = const Value.absent(),
                Value<int?> idContador = const Value.absent(),
              }) => GeraEfdReinfsCompanion.insert(
                id: id,
                dataEmissao: dataEmissao,
                periodoInicial: periodoInicial,
                periodoFinal: periodoFinal,
                tipoEvento: tipoEvento,
                ambiente: ambiente,
                idEmpresa: idEmpresa,
                idContador: idContador,
              ),
          withReferenceMapper:
              (p0) =>
                  p0
                      .map(
                        (e) => (
                          e.readTable(table),
                          BaseReferences(db, table, e),
                        ),
                      )
                      .toList(),
          prefetchHooksCallback: null,
        ),
      );
}

typedef $$GeraEfdReinfsTableProcessedTableManager =
    ProcessedTableManager<
      _$AppDatabase,
      $GeraEfdReinfsTable,
      GeraEfdReinf,
      $$GeraEfdReinfsTableFilterComposer,
      $$GeraEfdReinfsTableOrderingComposer,
      $$GeraEfdReinfsTableAnnotationComposer,
      $$GeraEfdReinfsTableCreateCompanionBuilder,
      $$GeraEfdReinfsTableUpdateCompanionBuilder,
      (
        GeraEfdReinf,
        BaseReferences<_$AppDatabase, $GeraEfdReinfsTable, GeraEfdReinf>,
      ),
      GeraEfdReinf,
      PrefetchHooks Function()
    >;
typedef $$GeraEsocialsTableCreateCompanionBuilder =
    GeraEsocialsCompanion Function({
      Value<int?> id,
      Value<DateTime?> dataEmissao,
      Value<DateTime?> periodoInicial,
      Value<DateTime?> periodoFinal,
      Value<String?> competencia,
      Value<int?> idEmpresa,
      Value<int?> idContador,
    });
typedef $$GeraEsocialsTableUpdateCompanionBuilder =
    GeraEsocialsCompanion Function({
      Value<int?> id,
      Value<DateTime?> dataEmissao,
      Value<DateTime?> periodoInicial,
      Value<DateTime?> periodoFinal,
      Value<String?> competencia,
      Value<int?> idEmpresa,
      Value<int?> idContador,
    });

class $$GeraEsocialsTableFilterComposer
    extends Composer<_$AppDatabase, $GeraEsocialsTable> {
  $$GeraEsocialsTableFilterComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnFilters<int> get id => $composableBuilder(
    column: $table.id,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<DateTime> get dataEmissao => $composableBuilder(
    column: $table.dataEmissao,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<DateTime> get periodoInicial => $composableBuilder(
    column: $table.periodoInicial,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<DateTime> get periodoFinal => $composableBuilder(
    column: $table.periodoFinal,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get competencia => $composableBuilder(
    column: $table.competencia,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<int> get idEmpresa => $composableBuilder(
    column: $table.idEmpresa,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<int> get idContador => $composableBuilder(
    column: $table.idContador,
    builder: (column) => ColumnFilters(column),
  );
}

class $$GeraEsocialsTableOrderingComposer
    extends Composer<_$AppDatabase, $GeraEsocialsTable> {
  $$GeraEsocialsTableOrderingComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnOrderings<int> get id => $composableBuilder(
    column: $table.id,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<DateTime> get dataEmissao => $composableBuilder(
    column: $table.dataEmissao,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<DateTime> get periodoInicial => $composableBuilder(
    column: $table.periodoInicial,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<DateTime> get periodoFinal => $composableBuilder(
    column: $table.periodoFinal,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get competencia => $composableBuilder(
    column: $table.competencia,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<int> get idEmpresa => $composableBuilder(
    column: $table.idEmpresa,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<int> get idContador => $composableBuilder(
    column: $table.idContador,
    builder: (column) => ColumnOrderings(column),
  );
}

class $$GeraEsocialsTableAnnotationComposer
    extends Composer<_$AppDatabase, $GeraEsocialsTable> {
  $$GeraEsocialsTableAnnotationComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  GeneratedColumn<int> get id =>
      $composableBuilder(column: $table.id, builder: (column) => column);

  GeneratedColumn<DateTime> get dataEmissao => $composableBuilder(
    column: $table.dataEmissao,
    builder: (column) => column,
  );

  GeneratedColumn<DateTime> get periodoInicial => $composableBuilder(
    column: $table.periodoInicial,
    builder: (column) => column,
  );

  GeneratedColumn<DateTime> get periodoFinal => $composableBuilder(
    column: $table.periodoFinal,
    builder: (column) => column,
  );

  GeneratedColumn<String> get competencia => $composableBuilder(
    column: $table.competencia,
    builder: (column) => column,
  );

  GeneratedColumn<int> get idEmpresa =>
      $composableBuilder(column: $table.idEmpresa, builder: (column) => column);

  GeneratedColumn<int> get idContador => $composableBuilder(
    column: $table.idContador,
    builder: (column) => column,
  );
}

class $$GeraEsocialsTableTableManager
    extends
        RootTableManager<
          _$AppDatabase,
          $GeraEsocialsTable,
          GeraEsocial,
          $$GeraEsocialsTableFilterComposer,
          $$GeraEsocialsTableOrderingComposer,
          $$GeraEsocialsTableAnnotationComposer,
          $$GeraEsocialsTableCreateCompanionBuilder,
          $$GeraEsocialsTableUpdateCompanionBuilder,
          (
            GeraEsocial,
            BaseReferences<_$AppDatabase, $GeraEsocialsTable, GeraEsocial>,
          ),
          GeraEsocial,
          PrefetchHooks Function()
        > {
  $$GeraEsocialsTableTableManager(_$AppDatabase db, $GeraEsocialsTable table)
    : super(
        TableManagerState(
          db: db,
          table: table,
          createFilteringComposer:
              () => $$GeraEsocialsTableFilterComposer($db: db, $table: table),
          createOrderingComposer:
              () => $$GeraEsocialsTableOrderingComposer($db: db, $table: table),
          createComputedFieldComposer:
              () =>
                  $$GeraEsocialsTableAnnotationComposer($db: db, $table: table),
          updateCompanionCallback:
              ({
                Value<int?> id = const Value.absent(),
                Value<DateTime?> dataEmissao = const Value.absent(),
                Value<DateTime?> periodoInicial = const Value.absent(),
                Value<DateTime?> periodoFinal = const Value.absent(),
                Value<String?> competencia = const Value.absent(),
                Value<int?> idEmpresa = const Value.absent(),
                Value<int?> idContador = const Value.absent(),
              }) => GeraEsocialsCompanion(
                id: id,
                dataEmissao: dataEmissao,
                periodoInicial: periodoInicial,
                periodoFinal: periodoFinal,
                competencia: competencia,
                idEmpresa: idEmpresa,
                idContador: idContador,
              ),
          createCompanionCallback:
              ({
                Value<int?> id = const Value.absent(),
                Value<DateTime?> dataEmissao = const Value.absent(),
                Value<DateTime?> periodoInicial = const Value.absent(),
                Value<DateTime?> periodoFinal = const Value.absent(),
                Value<String?> competencia = const Value.absent(),
                Value<int?> idEmpresa = const Value.absent(),
                Value<int?> idContador = const Value.absent(),
              }) => GeraEsocialsCompanion.insert(
                id: id,
                dataEmissao: dataEmissao,
                periodoInicial: periodoInicial,
                periodoFinal: periodoFinal,
                competencia: competencia,
                idEmpresa: idEmpresa,
                idContador: idContador,
              ),
          withReferenceMapper:
              (p0) =>
                  p0
                      .map(
                        (e) => (
                          e.readTable(table),
                          BaseReferences(db, table, e),
                        ),
                      )
                      .toList(),
          prefetchHooksCallback: null,
        ),
      );
}

typedef $$GeraEsocialsTableProcessedTableManager =
    ProcessedTableManager<
      _$AppDatabase,
      $GeraEsocialsTable,
      GeraEsocial,
      $$GeraEsocialsTableFilterComposer,
      $$GeraEsocialsTableOrderingComposer,
      $$GeraEsocialsTableAnnotationComposer,
      $$GeraEsocialsTableCreateCompanionBuilder,
      $$GeraEsocialsTableUpdateCompanionBuilder,
      (
        GeraEsocial,
        BaseReferences<_$AppDatabase, $GeraEsocialsTable, GeraEsocial>,
      ),
      GeraEsocial,
      PrefetchHooks Function()
    >;

class $AppDatabaseManager {
  final _$AppDatabase _db;
  $AppDatabaseManager(this._db);
  $$GeraSpedContabilsTableTableManager get geraSpedContabils =>
      $$GeraSpedContabilsTableTableManager(_db, _db.geraSpedContabils);
  $$ViewControleAcessosTableTableManager get viewControleAcessos =>
      $$ViewControleAcessosTableTableManager(_db, _db.viewControleAcessos);
  $$ViewPessoaUsuariosTableTableManager get viewPessoaUsuarios =>
      $$ViewPessoaUsuariosTableTableManager(_db, _db.viewPessoaUsuarios);
  $$GeraSpedFiscalsTableTableManager get geraSpedFiscals =>
      $$GeraSpedFiscalsTableTableManager(_db, _db.geraSpedFiscals);
  $$GeraSintegrasTableTableManager get geraSintegras =>
      $$GeraSintegrasTableTableManager(_db, _db.geraSintegras);
  $$GeraEfdContribuicoessTableTableManager get geraEfdContribuicoess =>
      $$GeraEfdContribuicoessTableTableManager(_db, _db.geraEfdContribuicoess);
  $$GeraEfdReinfsTableTableManager get geraEfdReinfs =>
      $$GeraEfdReinfsTableTableManager(_db, _db.geraEfdReinfs);
  $$GeraEsocialsTableTableManager get geraEsocials =>
      $$GeraEsocialsTableTableManager(_db, _db.geraEsocials);
}
