import 'dart:convert';

import 'package:gerador_arquivos/app/data/provider/api/api_provider_base.dart';
import 'package:gerador_arquivos/app/data/model/model_imports.dart';

class GeraEsocialApiProvider extends ApiProviderBase {
  static const _path = '/gera-esocial';

  Future<List<GeraEsocialModel>?> getList({Filter? filter}) {
    return super.getListBase(
      '$_path/',
      (json) => GeraEsocialModel.fromJson(json),
      filter: filter,
    );
  }

  Future<GeraEsocialModel?> getObject(dynamic pk) {
    return super.getObjectBase(
      _path,
      pk,
      (json) => GeraEsocialModel.fromJson(json),
    );
  }

  Future<GeraEsocialModel?>? insert(GeraEsocialModel model) {
    return super.insertBase(
      _path,
      model,
      (json) => GeraEsocialModel.fromJson(json),
    );
  }

  Future<GeraEsocialModel?>? update(GeraEsocialModel model) {
    return super.updateBase(
      _path,
      model,
      (json) => GeraEsocialModel.fromJson(json),
    );
  }

  Future<bool?> delete(dynamic pk) {
    return super.deleteBase(_path, pk);
  }

  Future<dynamic> gerarArquivo(GeraEsocialModel geraEsocialModel) async {
    try {
      final response = await ApiProviderBase.httpClient.post(
        Uri.tryParse('http://localhost:9000/api/esocial')!,
				headers: ApiProviderBase.headerRequisition(),
				body: geraEsocialModel.objectEncodeJson(),
      );

      if (response.statusCode == 200 || response.statusCode == 201) {
        if (response.headers["content-type"]!.contains("html")) {
          handleResultError(response.body, response.headers);
          return null;
        } else {
          final resposta = response.body;
          return json.decode(resposta)["arquivo"];
        }
      } else if (response.statusCode == 418) {
        return json.decode(response.body)["message"];
      } else {
        handleResultError(response.body, response.headers);
        return null;
      }
    } on Exception catch (e) {
      handleResultError(null, null, exception: e);
    }
    return null;
  }

}
