import 'package:drift/drift.dart';
import 'package:gerador_arquivos/app/data/provider/drift/database/database.dart';
import 'package:gerador_arquivos/app/data/provider/drift/database/database_imports.dart';

part 'gera_sped_contabil_dao.g.dart';

@DriftAccessor(tables: [
	GeraSpedContabils,
])
class GeraSpedContabilDao extends DatabaseAccessor<AppDatabase> with _$GeraSpedContabilDaoMixin {
	final AppDatabase db;

	List<GeraSpedContabil> geraSpedContabilList = []; 
	List<GeraSpedContabilGrouped> geraSpedContabilGroupedList = []; 

	GeraSpedContabilDao(this.db) : super(db);

	Future<List<GeraSpedContabil>> getList() async {
		geraSpedContabilList = await select(geraSpedContabils).get();
		return geraSpedContabilList;
	}

	Future<List<GeraSpedContabil>> getListFilter(String field, String value) async {
		final query = " $field like '%$value%'";
		final expression = CustomExpression<bool>(query);
		geraSpedContabilList = await (select(geraSpedContabils)..where((t) => expression)).get();
		return geraSpedContabilList;	 
	}

	Future<List<GeraSpedContabilGrouped>> getGroupedList({String? field, dynamic value}) async {
		final query = select(geraSpedContabils)
			.join([]);

		if (field != null && field != '') { 
			final column = geraSpedContabils.$columns.where(((column) => column.$name == field)).first;
			if (column is TextColumn) {
				query.where((column as TextColumn).like('%$value%'));
			} else if (column is IntColumn) {
				query.where(column.equals(int.tryParse(value) as Object));
			} else if (column is RealColumn) {
				query.where(column.equals(double.tryParse(value) as Object));
			}
		}

		geraSpedContabilGroupedList = await query.map((row) {
			final geraSpedContabil = row.readTableOrNull(geraSpedContabils); 

			return GeraSpedContabilGrouped(
				geraSpedContabil: geraSpedContabil, 

			);
		}).get();

		// fill internal lists
		//dynamic expression;
		//for (var geraSpedContabilGrouped in geraSpedContabilGroupedList) {
		//}		

		return geraSpedContabilGroupedList;	
	}

	Future<GeraSpedContabil?> getObject(dynamic pk) async {
		return await (select(geraSpedContabils)..where((t) => t.id.equals(pk))).getSingleOrNull();
	} 

	Future<GeraSpedContabil?> getObjectFilter(String field, String value) async {
		final query = "SELECT * FROM gera_sped_contabil WHERE $field like '%$value%'";
		return (await customSelect(query).getSingleOrNull()) as GeraSpedContabil;		 
	} 

	Future<GeraSpedContabilGrouped?> getObjectGrouped({String? field, dynamic value}) async {
		final result = await getGroupedList(field: field, value: value);

		if (result.length != 1) {
			return null;
		} else {
			return result[0];
		} 
	}

	Future<int> insertObject(GeraSpedContabilGrouped object) {
		return transaction(() async {
			final maxPk = await lastPk();
			object.geraSpedContabil = object.geraSpedContabil!.copyWith(id: Value(maxPk + 1));
			final pkInserted = await into(geraSpedContabils).insert(object.geraSpedContabil!);
			object.geraSpedContabil = object.geraSpedContabil!.copyWith(id: Value(pkInserted));			 
			await insertChildren(object);
			return pkInserted;
		});		
	}	 

	Future<bool> updateObject(GeraSpedContabilGrouped object) {
		return transaction(() async {
			await deleteChildren(object);
			await insertChildren(object);
			return update(geraSpedContabils).replace(object.geraSpedContabil!);
		});	 
	} 

	Future<int> deleteObject(GeraSpedContabilGrouped object) {
		return transaction(() async {
			await deleteChildren(object);
			return delete(geraSpedContabils).delete(object.geraSpedContabil!);
		});		
	}

	Future<void> insertChildren(GeraSpedContabilGrouped object) async {
	}
	
	Future<void> deleteChildren(GeraSpedContabilGrouped object) async {
	}

	Future<int> lastPk() async {
		final result = await customSelect("select MAX(id) as LAST from gera_sped_contabil").getSingleOrNull();
		return result?.data["LAST"] ?? 0;
	} 
}