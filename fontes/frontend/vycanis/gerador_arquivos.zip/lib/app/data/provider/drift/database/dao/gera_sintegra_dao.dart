import 'package:drift/drift.dart';
import 'package:gerador_arquivos/app/data/provider/drift/database/database.dart';
import 'package:gerador_arquivos/app/data/provider/drift/database/database_imports.dart';

part 'gera_sintegra_dao.g.dart';

@DriftAccessor(tables: [
	GeraSintegras,
])
class GeraSintegraDao extends DatabaseAccessor<AppDatabase> with _$GeraSintegraDaoMixin {
	final AppDatabase db;

	List<GeraSintegra> geraSintegraList = []; 
	List<GeraSintegraGrouped> geraSintegraGroupedList = []; 

	GeraSintegraDao(this.db) : super(db);

	Future<List<GeraSintegra>> getList() async {
		geraSintegraList = await select(geraSintegras).get();
		return geraSintegraList;
	}

	Future<List<GeraSintegra>> getListFilter(String field, String value) async {
		final query = " $field like '%$value%'";
		final expression = CustomExpression<bool>(query);
		geraSintegraList = await (select(geraSintegras)..where((t) => expression)).get();
		return geraSintegraList;	 
	}

	Future<List<GeraSintegraGrouped>> getGroupedList({String? field, dynamic value}) async {
		final query = select(geraSintegras)
			.join([]);

		if (field != null && field != '') { 
			final column = geraSintegras.$columns.where(((column) => column.$name == field)).first;
			if (column is TextColumn) {
				query.where((column as TextColumn).like('%$value%'));
			} else if (column is IntColumn) {
				query.where(column.equals(int.tryParse(value) as Object));
			} else if (column is RealColumn) {
				query.where(column.equals(double.tryParse(value) as Object));
			}
		}

		geraSintegraGroupedList = await query.map((row) {
			final geraSintegra = row.readTableOrNull(geraSintegras); 

			return GeraSintegraGrouped(
				geraSintegra: geraSintegra, 

			);
		}).get();

		// fill internal lists
		//dynamic expression;
		//for (var geraSintegraGrouped in geraSintegraGroupedList) {
		//}		

		return geraSintegraGroupedList;	
	}

	Future<GeraSintegra?> getObject(dynamic pk) async {
		return await (select(geraSintegras)..where((t) => t.id.equals(pk))).getSingleOrNull();
	} 

	Future<GeraSintegra?> getObjectFilter(String field, String value) async {
		final query = "SELECT * FROM gera_sintegra WHERE $field like '%$value%'";
		return (await customSelect(query).getSingleOrNull()) as GeraSintegra;		 
	} 

	Future<GeraSintegraGrouped?> getObjectGrouped({String? field, dynamic value}) async {
		final result = await getGroupedList(field: field, value: value);

		if (result.length != 1) {
			return null;
		} else {
			return result[0];
		} 
	}

	Future<int> insertObject(GeraSintegraGrouped object) {
		return transaction(() async {
			final maxPk = await lastPk();
			object.geraSintegra = object.geraSintegra!.copyWith(id: Value(maxPk + 1));
			final pkInserted = await into(geraSintegras).insert(object.geraSintegra!);
			object.geraSintegra = object.geraSintegra!.copyWith(id: Value(pkInserted));			 
			await insertChildren(object);
			return pkInserted;
		});		
	}	 

	Future<bool> updateObject(GeraSintegraGrouped object) {
		return transaction(() async {
			await deleteChildren(object);
			await insertChildren(object);
			return update(geraSintegras).replace(object.geraSintegra!);
		});	 
	} 

	Future<int> deleteObject(GeraSintegraGrouped object) {
		return transaction(() async {
			await deleteChildren(object);
			return delete(geraSintegras).delete(object.geraSintegra!);
		});		
	}

	Future<void> insertChildren(GeraSintegraGrouped object) async {
	}
	
	Future<void> deleteChildren(GeraSintegraGrouped object) async {
	}

	Future<int> lastPk() async {
		final result = await customSelect("select MAX(id) as LAST from gera_sintegra").getSingleOrNull();
		return result?.data["LAST"] ?? 0;
	} 
}