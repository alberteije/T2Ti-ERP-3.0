import 'dart:convert';

import 'package:gerador_arquivos/app/data/provider/api/api_provider_base.dart';
import 'package:gerador_arquivos/app/data/model/model_imports.dart';

class GeraEfdReinfApiProvider extends ApiProviderBase {
  static const _path = '/gera-efd-reinf';

  Future<List<GeraEfdReinfModel>?> getList({Filter? filter}) {
    return super.getListBase(
      '$_path/',
      (json) => GeraEfdReinfModel.fromJson(json),
      filter: filter,
    );
  }

  Future<GeraEfdReinfModel?> getObject(dynamic pk) {
    return super.getObjectBase(
      _path,
      pk,
      (json) => GeraEfdReinfModel.fromJson(json),
    );
  }

  Future<GeraEfdReinfModel?>? insert(GeraEfdReinfModel model) {
    return super.insertBase(
      _path,
      model,
      (json) => GeraEfdReinfModel.fromJson(json),
    );
  }

  Future<GeraEfdReinfModel?>? update(GeraEfdReinfModel model) {
    return super.updateBase(
      _path,
      model,
      (json) => GeraEfdReinfModel.fromJson(json),
    );
  }

  Future<bool?> delete(dynamic pk) {
    return super.deleteBase(_path, pk);
  }

  Future<dynamic> gerarArquivo(GeraEfdReinfModel geraEfdReinfModel) async {
    try {
      final response = await ApiProviderBase.httpClient.post(
        Uri.tryParse('http://localhost:9000/api/reinf')!,
				headers: ApiProviderBase.headerRequisition(),
				body: geraEfdReinfModel.objectEncodeJson(),
      );

      if (response.statusCode == 200 || response.statusCode == 201) {
        if (response.headers["content-type"]!.contains("html")) {
          handleResultError(response.body, response.headers);
          return null;
        } else {
          final resposta = response.body;
          return json.decode(resposta)["arquivo"];
        }
      } else if (response.statusCode == 418) {
        return json.decode(response.body)["message"];
      } else {
        handleResultError(response.body, response.headers);
        return null;
      }
    } on Exception catch (e) {
      handleResultError(null, null, exception: e);
    }
    return null;
  }

}
