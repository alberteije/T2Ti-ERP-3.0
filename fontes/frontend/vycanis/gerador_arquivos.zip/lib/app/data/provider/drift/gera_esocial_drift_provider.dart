import 'package:gerador_arquivos/app/data/provider/drift/database/database_imports.dart';
import 'package:gerador_arquivos/app/infra/infra_imports.dart';
import 'package:gerador_arquivos/app/data/provider/provider_base.dart';
import 'package:gerador_arquivos/app/data/provider/drift/database/database.dart';
import 'package:gerador_arquivos/app/data/model/model_imports.dart';

class GeraEsocialDriftProvider extends ProviderBase {

	Future<List<GeraEsocialModel>?> getList({Filter? filter}) async {
		List<GeraEsocialGrouped> geraEsocialDriftList = [];

		try {
			if (filter != null && filter.field != null) {
				geraEsocialDriftList = await Session.database.geraEsocialDao.getGroupedList(field: filter.field, value: filter.value!);
			} else {
				geraEsocialDriftList = await Session.database.geraEsocialDao.getGroupedList(); 
			}
			if (geraEsocialDriftList.isNotEmpty) {
				return toListModel(geraEsocialDriftList);
			} else {
				return [];
			}			 
		} catch (e) {
			handleResultError(null, null, exception: e);
			return null;
		}
	}

	Future<GeraEsocialModel?> getObject(dynamic pk) async {
		try {
			final result = await Session.database.geraEsocialDao.getObjectGrouped(field: 'id', value: pk);
			return toModel(result);
		} catch (e) {
			handleResultError(null, null, exception: e);
		}
		return null;
	}

	Future<GeraEsocialModel?>? insert(GeraEsocialModel geraEsocialModel) async {
		try {
			final lastPk = await Session.database.geraEsocialDao.insertObject(toDrift(geraEsocialModel));
			geraEsocialModel.id = lastPk;
			return geraEsocialModel;
		} catch (e) {
			handleResultError(null, null, exception: e);
		}
		return null;
	}

	Future<GeraEsocialModel?>? update(GeraEsocialModel geraEsocialModel) async {
		try {
			await Session.database.geraEsocialDao.updateObject(toDrift(geraEsocialModel));
			return geraEsocialModel;
		} catch (e) {
			handleResultError(null, null, exception: e);
		}
		return null;
	}

	Future<bool?> delete(dynamic pk) async {
		try {
			await Session.database.geraEsocialDao.deleteObject(toDrift(GeraEsocialModel(id: pk)));
			return true;
		} catch (e) {
			handleResultError(null, null, exception: e);
		}
		return null;
	}	

	List<GeraEsocialModel> toListModel(List<GeraEsocialGrouped> geraEsocialDriftList) {
		List<GeraEsocialModel> listModel = [];
		for (var geraEsocialDrift in geraEsocialDriftList) {
			listModel.add(toModel(geraEsocialDrift)!);
		}
		return listModel;
	}	

	GeraEsocialModel? toModel(GeraEsocialGrouped? geraEsocialDrift) {
		if (geraEsocialDrift != null) {
			return GeraEsocialModel(
				id: geraEsocialDrift.geraEsocial?.id,
				dataEmissao: geraEsocialDrift.geraEsocial?.dataEmissao,
				periodoInicial: geraEsocialDrift.geraEsocial?.periodoInicial,
				periodoFinal: geraEsocialDrift.geraEsocial?.periodoFinal,
				competencia: geraEsocialDrift.geraEsocial?.competencia,
				idEmpresa: geraEsocialDrift.geraEsocial?.idEmpresa,
				idContador: geraEsocialDrift.geraEsocial?.idContador,
			);
		} else {
			return null;
		}
	}


	GeraEsocialGrouped toDrift(GeraEsocialModel geraEsocialModel) {
		return GeraEsocialGrouped(
			geraEsocial: GeraEsocial(
				id: geraEsocialModel.id,
				dataEmissao: geraEsocialModel.dataEmissao,
				periodoInicial: geraEsocialModel.periodoInicial,
				periodoFinal: geraEsocialModel.periodoFinal,
				competencia: Util.removeMask(geraEsocialModel.competencia),
				idEmpresa: geraEsocialModel.idEmpresa,
				idContador: geraEsocialModel.idContador,
			),
		);
	}

		
}
