import 'package:drift/drift.dart';
import 'package:gerador_arquivos/app/data/provider/drift/database/database.dart';

@DataClassName("GeraSpedFiscal")
class GeraSpedFiscals extends Table {
	@override
	String get tableName => 'gera_sped_fiscal';

	IntColumn get id => integer().named('id').nullable()();
	DateTimeColumn get dataEmissao => dateTime().named('data_emissao').nullable()();
	DateTimeColumn get periodoInicial => dateTime().named('periodo_inicial').nullable()();
	DateTimeColumn get periodoFinal => dateTime().named('periodo_final').nullable()();
	TextColumn get versaoLayout => text().named('versao_layout').withLength(min: 0, max: 3).nullable()();
	TextColumn get finalidadeArquivo => text().named('finalidade_arquivo').withLength(min: 0, max: 1).nullable()();
	TextColumn get perfilApresentacao => text().named('perfil_apresentacao').withLength(min: 0, max: 1).nullable()();
	TextColumn get inventario => text().named('inventario').withLength(min: 0, max: 1).nullable()();
	IntColumn get idEmpresa => integer().named('id_empresa').nullable()();
	IntColumn get idContador => integer().named('id_contador').nullable()();

	@override
	Set<Column> get primaryKey => { id };	
	
}

class GeraSpedFiscalGrouped {
	GeraSpedFiscal? geraSpedFiscal; 

  GeraSpedFiscalGrouped({
		this.geraSpedFiscal, 

  });
}
