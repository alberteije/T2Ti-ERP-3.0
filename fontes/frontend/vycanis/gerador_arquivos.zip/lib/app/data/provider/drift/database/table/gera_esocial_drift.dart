import 'package:drift/drift.dart';
import 'package:gerador_arquivos/app/data/provider/drift/database/database.dart';

@DataClassName("GeraEsocial")
class GeraEsocials extends Table {
	@override
	String get tableName => 'gera_esocial';

	IntColumn get id => integer().named('id').nullable()();
	DateTimeColumn get dataEmissao => dateTime().named('data_emissao').nullable()();
	DateTimeColumn get periodoInicial => dateTime().named('periodo_inicial').nullable()();
	DateTimeColumn get periodoFinal => dateTime().named('periodo_final').nullable()();
	TextColumn get competencia => text().named('competencia').withLength(min: 0, max: 7).nullable()();
	IntColumn get idEmpresa => integer().named('id_empresa').nullable()();
	IntColumn get idContador => integer().named('id_contador').nullable()();

	@override
	Set<Column> get primaryKey => { id };	
	
}

class GeraEsocialGrouped {
	GeraEsocial? geraEsocial; 

  GeraEsocialGrouped({
		this.geraEsocial, 

  });
}
