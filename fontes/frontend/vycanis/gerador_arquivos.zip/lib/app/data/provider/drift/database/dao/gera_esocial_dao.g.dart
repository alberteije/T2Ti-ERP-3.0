// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'gera_esocial_dao.dart';

// ignore_for_file: type=lint
mixin _$GeraEsocialDaoMixin on DatabaseAccessor<AppDatabase> {
  $GeraEsocialsTable get geraEsocials => attachedDatabase.geraEsocials;
}
