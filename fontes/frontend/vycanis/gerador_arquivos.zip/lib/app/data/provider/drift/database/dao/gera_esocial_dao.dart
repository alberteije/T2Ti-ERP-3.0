import 'package:drift/drift.dart';
import 'package:gerador_arquivos/app/data/provider/drift/database/database.dart';
import 'package:gerador_arquivos/app/data/provider/drift/database/database_imports.dart';

part 'gera_esocial_dao.g.dart';

@DriftAccessor(tables: [
	GeraEsocials,
])
class GeraEsocialDao extends DatabaseAccessor<AppDatabase> with _$GeraEsocialDaoMixin {
	final AppDatabase db;

	List<GeraEsocial> geraEsocialList = []; 
	List<GeraEsocialGrouped> geraEsocialGroupedList = []; 

	GeraEsocialDao(this.db) : super(db);

	Future<List<GeraEsocial>> getList() async {
		geraEsocialList = await select(geraEsocials).get();
		return geraEsocialList;
	}

	Future<List<GeraEsocial>> getListFilter(String field, String value) async {
		final query = " $field like '%$value%'";
		final expression = CustomExpression<bool>(query);
		geraEsocialList = await (select(geraEsocials)..where((t) => expression)).get();
		return geraEsocialList;	 
	}

	Future<List<GeraEsocialGrouped>> getGroupedList({String? field, dynamic value}) async {
		final query = select(geraEsocials)
			.join([]);

		if (field != null && field != '') { 
			final column = geraEsocials.$columns.where(((column) => column.$name == field)).first;
			if (column is TextColumn) {
				query.where((column as TextColumn).like('%$value%'));
			} else if (column is IntColumn) {
				query.where(column.equals(int.tryParse(value) as Object));
			} else if (column is RealColumn) {
				query.where(column.equals(double.tryParse(value) as Object));
			}
		}

		geraEsocialGroupedList = await query.map((row) {
			final geraEsocial = row.readTableOrNull(geraEsocials); 

			return GeraEsocialGrouped(
				geraEsocial: geraEsocial, 

			);
		}).get();

		// fill internal lists
		//dynamic expression;
		//for (var geraEsocialGrouped in geraEsocialGroupedList) {
		//}		

		return geraEsocialGroupedList;	
	}

	Future<GeraEsocial?> getObject(dynamic pk) async {
		return await (select(geraEsocials)..where((t) => t.id.equals(pk))).getSingleOrNull();
	} 

	Future<GeraEsocial?> getObjectFilter(String field, String value) async {
		final query = "SELECT * FROM gera_esocial WHERE $field like '%$value%'";
		return (await customSelect(query).getSingleOrNull()) as GeraEsocial;		 
	} 

	Future<GeraEsocialGrouped?> getObjectGrouped({String? field, dynamic value}) async {
		final result = await getGroupedList(field: field, value: value);

		if (result.length != 1) {
			return null;
		} else {
			return result[0];
		} 
	}

	Future<int> insertObject(GeraEsocialGrouped object) {
		return transaction(() async {
			final maxPk = await lastPk();
			object.geraEsocial = object.geraEsocial!.copyWith(id: Value(maxPk + 1));
			final pkInserted = await into(geraEsocials).insert(object.geraEsocial!);
			object.geraEsocial = object.geraEsocial!.copyWith(id: Value(pkInserted));			 
			await insertChildren(object);
			return pkInserted;
		});		
	}	 

	Future<bool> updateObject(GeraEsocialGrouped object) {
		return transaction(() async {
			await deleteChildren(object);
			await insertChildren(object);
			return update(geraEsocials).replace(object.geraEsocial!);
		});	 
	} 

	Future<int> deleteObject(GeraEsocialGrouped object) {
		return transaction(() async {
			await deleteChildren(object);
			return delete(geraEsocials).delete(object.geraEsocial!);
		});		
	}

	Future<void> insertChildren(GeraEsocialGrouped object) async {
	}
	
	Future<void> deleteChildren(GeraEsocialGrouped object) async {
	}

	Future<int> lastPk() async {
		final result = await customSelect("select MAX(id) as LAST from gera_esocial").getSingleOrNull();
		return result?.data["LAST"] ?? 0;
	} 
}