// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'gera_efd_contribuicoes_dao.dart';

// ignore_for_file: type=lint
mixin _$GeraEfdContribuicoesDaoMixin on DatabaseAccessor<AppDatabase> {
  $GeraEfdContribuicoessTable get geraEfdContribuicoess =>
      attachedDatabase.geraEfdContribuicoess;
}
