import 'package:gerador_arquivos/app/data/provider/drift/database/database_imports.dart';
import 'package:gerador_arquivos/app/infra/infra_imports.dart';
import 'package:gerador_arquivos/app/data/provider/provider_base.dart';
import 'package:gerador_arquivos/app/data/provider/drift/database/database.dart';
import 'package:gerador_arquivos/app/data/model/model_imports.dart';
import 'package:gerador_arquivos/app/data/domain/domain_imports.dart';

class GeraSpedContabilDriftProvider extends ProviderBase {

	Future<List<GeraSpedContabilModel>?> getList({Filter? filter}) async {
		List<GeraSpedContabilGrouped> geraSpedContabilDriftList = [];

		try {
			if (filter != null && filter.field != null) {
				geraSpedContabilDriftList = await Session.database.geraSpedContabilDao.getGroupedList(field: filter.field, value: filter.value!);
			} else {
				geraSpedContabilDriftList = await Session.database.geraSpedContabilDao.getGroupedList(); 
			}
			if (geraSpedContabilDriftList.isNotEmpty) {
				return toListModel(geraSpedContabilDriftList);
			} else {
				return [];
			}			 
		} catch (e) {
			handleResultError(null, null, exception: e);
			return null;
		}
	}

	Future<GeraSpedContabilModel?> getObject(dynamic pk) async {
		try {
			final result = await Session.database.geraSpedContabilDao.getObjectGrouped(field: 'id', value: pk);
			return toModel(result);
		} catch (e) {
			handleResultError(null, null, exception: e);
		}
		return null;
	}

	Future<GeraSpedContabilModel?>? insert(GeraSpedContabilModel geraSpedContabilModel) async {
		try {
			final lastPk = await Session.database.geraSpedContabilDao.insertObject(toDrift(geraSpedContabilModel));
			geraSpedContabilModel.id = lastPk;
			return geraSpedContabilModel;
		} catch (e) {
			handleResultError(null, null, exception: e);
		}
		return null;
	}

	Future<GeraSpedContabilModel?>? update(GeraSpedContabilModel geraSpedContabilModel) async {
		try {
			await Session.database.geraSpedContabilDao.updateObject(toDrift(geraSpedContabilModel));
			return geraSpedContabilModel;
		} catch (e) {
			handleResultError(null, null, exception: e);
		}
		return null;
	}

	Future<bool?> delete(dynamic pk) async {
		try {
			await Session.database.geraSpedContabilDao.deleteObject(toDrift(GeraSpedContabilModel(id: pk)));
			return true;
		} catch (e) {
			handleResultError(null, null, exception: e);
		}
		return null;
	}	

	List<GeraSpedContabilModel> toListModel(List<GeraSpedContabilGrouped> geraSpedContabilDriftList) {
		List<GeraSpedContabilModel> listModel = [];
		for (var geraSpedContabilDrift in geraSpedContabilDriftList) {
			listModel.add(toModel(geraSpedContabilDrift)!);
		}
		return listModel;
	}	

	GeraSpedContabilModel? toModel(GeraSpedContabilGrouped? geraSpedContabilDrift) {
		if (geraSpedContabilDrift != null) {
			return GeraSpedContabilModel(
				id: geraSpedContabilDrift.geraSpedContabil?.id,
				dataEmissao: geraSpedContabilDrift.geraSpedContabil?.dataEmissao,
				periodoInicial: geraSpedContabilDrift.geraSpedContabil?.periodoInicial,
				periodoFinal: geraSpedContabilDrift.geraSpedContabil?.periodoFinal,
				formaEscrituracao: GeraSpedContabilDomain.getFormaEscrituracao(geraSpedContabilDrift.geraSpedContabil?.formaEscrituracao),
				versaoLayout: geraSpedContabilDrift.geraSpedContabil?.versaoLayout,
				idEmpresa: geraSpedContabilDrift.geraSpedContabil?.idEmpresa,
				idContador: geraSpedContabilDrift.geraSpedContabil?.idContador,
			);
		} else {
			return null;
		}
	}


	GeraSpedContabilGrouped toDrift(GeraSpedContabilModel geraSpedContabilModel) {
		return GeraSpedContabilGrouped(
			geraSpedContabil: GeraSpedContabil(
				id: geraSpedContabilModel.id,
				dataEmissao: geraSpedContabilModel.dataEmissao,
				periodoInicial: geraSpedContabilModel.periodoInicial,
				periodoFinal: geraSpedContabilModel.periodoFinal,
				formaEscrituracao: GeraSpedContabilDomain.setFormaEscrituracao(geraSpedContabilModel.formaEscrituracao),
				versaoLayout: geraSpedContabilModel.versaoLayout,
				idEmpresa: geraSpedContabilModel.idEmpresa,
				idContador: geraSpedContabilModel.idContador,
			),
		);
	}

		
}
