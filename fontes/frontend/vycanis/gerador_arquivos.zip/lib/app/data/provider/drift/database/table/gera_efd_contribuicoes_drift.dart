import 'package:drift/drift.dart';
import 'package:gerador_arquivos/app/data/provider/drift/database/database.dart';

@DataClassName("GeraEfdContribuicoes")
class GeraEfdContribuicoess extends Table {
	@override
	String get tableName => 'gera_efd_contribuicoes';

	IntColumn get id => integer().named('id').nullable()();
	DateTimeColumn get dataEmissao => dateTime().named('data_emissao').nullable()();
	DateTimeColumn get periodoInicial => dateTime().named('periodo_inicial').nullable()();
	DateTimeColumn get periodoFinal => dateTime().named('periodo_final').nullable()();
	TextColumn get versaoLayout => text().named('versao_layout').withLength(min: 0, max: 3).nullable()();
	TextColumn get tipoEscrituracao => text().named('tipo_escrituracao').withLength(min: 0, max: 1).nullable()();
	IntColumn get idEmpersa => integer().named('id_empersa').nullable()();
	IntColumn get idContador => integer().named('id_contador').nullable()();

	@override
	Set<Column> get primaryKey => { id };	
	
}

class GeraEfdContribuicoesGrouped {
	GeraEfdContribuicoes? geraEfdContribuicoes; 

  GeraEfdContribuicoesGrouped({
		this.geraEfdContribuicoes, 

  });
}
