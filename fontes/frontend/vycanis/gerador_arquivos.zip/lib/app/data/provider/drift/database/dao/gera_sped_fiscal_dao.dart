import 'package:drift/drift.dart';
import 'package:gerador_arquivos/app/data/provider/drift/database/database.dart';
import 'package:gerador_arquivos/app/data/provider/drift/database/database_imports.dart';

part 'gera_sped_fiscal_dao.g.dart';

@DriftAccessor(tables: [
	GeraSpedFiscals,
])
class GeraSpedFiscalDao extends DatabaseAccessor<AppDatabase> with _$GeraSpedFiscalDaoMixin {
	final AppDatabase db;

	List<GeraSpedFiscal> geraSpedFiscalList = []; 
	List<GeraSpedFiscalGrouped> geraSpedFiscalGroupedList = []; 

	GeraSpedFiscalDao(this.db) : super(db);

	Future<List<GeraSpedFiscal>> getList() async {
		geraSpedFiscalList = await select(geraSpedFiscals).get();
		return geraSpedFiscalList;
	}

	Future<List<GeraSpedFiscal>> getListFilter(String field, String value) async {
		final query = " $field like '%$value%'";
		final expression = CustomExpression<bool>(query);
		geraSpedFiscalList = await (select(geraSpedFiscals)..where((t) => expression)).get();
		return geraSpedFiscalList;	 
	}

	Future<List<GeraSpedFiscalGrouped>> getGroupedList({String? field, dynamic value}) async {
		final query = select(geraSpedFiscals)
			.join([]);

		if (field != null && field != '') { 
			final column = geraSpedFiscals.$columns.where(((column) => column.$name == field)).first;
			if (column is TextColumn) {
				query.where((column as TextColumn).like('%$value%'));
			} else if (column is IntColumn) {
				query.where(column.equals(int.tryParse(value) as Object));
			} else if (column is RealColumn) {
				query.where(column.equals(double.tryParse(value) as Object));
			}
		}

		geraSpedFiscalGroupedList = await query.map((row) {
			final geraSpedFiscal = row.readTableOrNull(geraSpedFiscals); 

			return GeraSpedFiscalGrouped(
				geraSpedFiscal: geraSpedFiscal, 

			);
		}).get();

		// fill internal lists
		//dynamic expression;
		//for (var geraSpedFiscalGrouped in geraSpedFiscalGroupedList) {
		//}		

		return geraSpedFiscalGroupedList;	
	}

	Future<GeraSpedFiscal?> getObject(dynamic pk) async {
		return await (select(geraSpedFiscals)..where((t) => t.id.equals(pk))).getSingleOrNull();
	} 

	Future<GeraSpedFiscal?> getObjectFilter(String field, String value) async {
		final query = "SELECT * FROM gera_sped_fiscal WHERE $field like '%$value%'";
		return (await customSelect(query).getSingleOrNull()) as GeraSpedFiscal;		 
	} 

	Future<GeraSpedFiscalGrouped?> getObjectGrouped({String? field, dynamic value}) async {
		final result = await getGroupedList(field: field, value: value);

		if (result.length != 1) {
			return null;
		} else {
			return result[0];
		} 
	}

	Future<int> insertObject(GeraSpedFiscalGrouped object) {
		return transaction(() async {
			final maxPk = await lastPk();
			object.geraSpedFiscal = object.geraSpedFiscal!.copyWith(id: Value(maxPk + 1));
			final pkInserted = await into(geraSpedFiscals).insert(object.geraSpedFiscal!);
			object.geraSpedFiscal = object.geraSpedFiscal!.copyWith(id: Value(pkInserted));			 
			await insertChildren(object);
			return pkInserted;
		});		
	}	 

	Future<bool> updateObject(GeraSpedFiscalGrouped object) {
		return transaction(() async {
			await deleteChildren(object);
			await insertChildren(object);
			return update(geraSpedFiscals).replace(object.geraSpedFiscal!);
		});	 
	} 

	Future<int> deleteObject(GeraSpedFiscalGrouped object) {
		return transaction(() async {
			await deleteChildren(object);
			return delete(geraSpedFiscals).delete(object.geraSpedFiscal!);
		});		
	}

	Future<void> insertChildren(GeraSpedFiscalGrouped object) async {
	}
	
	Future<void> deleteChildren(GeraSpedFiscalGrouped object) async {
	}

	Future<int> lastPk() async {
		final result = await customSelect("select MAX(id) as LAST from gera_sped_fiscal").getSingleOrNull();
		return result?.data["LAST"] ?? 0;
	} 
}