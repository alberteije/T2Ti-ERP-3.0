import 'package:drift/drift.dart';
import 'package:gerador_arquivos/app/data/provider/drift/database/database.dart';

@DataClassName("GeraSpedContabil")
class GeraSpedContabils extends Table {
	@override
	String get tableName => 'gera_sped_contabil';

	IntColumn get id => integer().named('id').nullable()();
	DateTimeColumn get dataEmissao => dateTime().named('data_emissao').nullable()();
	DateTimeColumn get periodoInicial => dateTime().named('periodo_inicial').nullable()();
	DateTimeColumn get periodoFinal => dateTime().named('periodo_final').nullable()();
	TextColumn get formaEscrituracao => text().named('forma_escrituracao').withLength(min: 0, max: 1).nullable()();
	TextColumn get versaoLayout => text().named('versao_layout').withLength(min: 0, max: 3).nullable()();
	IntColumn get idEmpresa => integer().named('id_empresa').nullable()();
	IntColumn get idContador => integer().named('id_contador').nullable()();

	@override
	Set<Column> get primaryKey => { id };	
	
}

class GeraSpedContabilGrouped {
	GeraSpedContabil? geraSpedContabil; 

  GeraSpedContabilGrouped({
		this.geraSpedContabil, 

  });
}
