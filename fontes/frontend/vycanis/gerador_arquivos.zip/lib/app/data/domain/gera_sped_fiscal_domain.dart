class GeraSpedFiscalDomain {
  GeraSpedFiscalDomain._();

  static getFinalidadeArquivo(String? finalidadeArquivo) { 
		switch (finalidadeArquivo) { 
			case '': 
			case '0': 
				return '0-Remessa do arquivo original'; 
			case '1': 
				return '1-Remessa do arquivo substituto'; 
			default: 
				return null; 
		} 
	} 

  static setFinalidadeArquivo(String? finalidadeArquivo) { 
		switch (finalidadeArquivo) { 
			case '0-Remessa do arquivo original': 
				return '0'; 
			case '1-Remessa do arquivo substituto': 
				return '1'; 
			default: 
				return null; 
		} 
	}

  static getPerfilApresentacao(String? perfilApresentacao) { 
		switch (perfilApresentacao) { 
			case '': 
			case 'A': 
				return 'A'; 
			case 'B': 
				return 'B'; 
			case 'C': 
				return 'C'; 
			default: 
				return null; 
		} 
	} 

  static setPerfilApresentacao(String? perfilApresentacao) { 
		switch (perfilApresentacao) { 
			case 'A': 
				return '0'; 
			case 'B': 
				return '1'; 
			case 'C': 
				return '2'; 
			default: 
				return null; 
		} 
	}

  static getInventario(String? inventario) { 
		switch (inventario) { 
			case '': 
			case '0': 
				return 'Sem Dados'; 
			case '1': 
				return 'Com Dados'; 
			default: 
				return null; 
		} 
	} 

  static setInventario(String? inventario) { 
		switch (inventario) { 
			case 'Sem Dados': 
				return '0'; 
			case 'Com Dados': 
				return '1'; 
			default: 
				return null; 
		} 
	}


  static final finalidadeArquivoListDropdown = ['0-Remessa do arquivo original','1-Remessa do arquivo substituto'];
  static final perfilApresentacaoListDropdown = ['A','B','C'];
  static final inventarioListDropdown = ['Sem Dados','Com Dados'];

}