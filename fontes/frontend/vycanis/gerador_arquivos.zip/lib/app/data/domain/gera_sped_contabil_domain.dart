class GeraSpedContabilDomain {
  GeraSpedContabilDomain._();

  static getFormaEscrituracao(String? formaEscrituracao) { 
		switch (formaEscrituracao) { 
			case '': 
			case 'G': 
				return 'G-Diário Geral'; 
			case 'R': 
				return 'R-Diário com Escrituração Resumida'; 
			case 'A': 
				return 'A-Diário Auxiliar'; 
			case 'Z': 
				return 'Z-Razão Auxiliar'; 
			case 'B': 
				return 'B-Livro de Balancetes Diários e Balanços'; 
			default: 
				return null; 
		} 
	} 

  static setFormaEscrituracao(String? formaEscrituracao) { 
		switch (formaEscrituracao) { 
			case 'G-Diário Geral': 
				return '0'; 
			case 'R-Diário com Escrituração Resumida': 
				return '1'; 
			case 'A-Diário Auxiliar': 
				return '2'; 
			case 'Z-Razão Auxiliar': 
				return '3'; 
			case 'B-Livro de Balancetes Diários e Balanços': 
				return '4'; 
			default: 
				return null; 
		} 
	}


  static final formaEscrituracaoListDropdown = ['G-Diário Geral','R-Diário com Escrituração Resumida','A-Diário Auxiliar','Z-Razão Auxiliar','B-Livro de Balancetes Diários e Balanços'];

}