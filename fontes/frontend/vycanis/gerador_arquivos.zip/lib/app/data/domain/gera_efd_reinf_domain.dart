class GeraEfdReinfDomain {
  GeraEfdReinfDomain._();

  static getTipoEvento(String? tipoEvento) { 
		switch (tipoEvento) { 
			case '': 
			case '0': 
				return 'Todos'; 
			case '1': 
				return 'Informações do contribuinte'; 
			case '2': 
				return 'Serviços tomados'; 
			case '3': 
				return 'Serviços prestados'; 
			case '4': 
				return 'Tabela de processos'; 
			default: 
				return null; 
		} 
	} 

  static setTipoEvento(String? tipoEvento) { 
		switch (tipoEvento) { 
			case 'Todos': 
				return '0'; 
			case 'Informações do contribuinte': 
				return '1'; 
			case 'Serviços tomados': 
				return '2'; 
			case 'Serviços prestados': 
				return '3'; 
			case 'Tabela de processos': 
				return '4'; 
			default: 
				return null; 
		} 
	}

  static getAmbiente(String? ambiente) { 
		switch (ambiente) { 
			case '': 
			case '1': 
				return '1-Produção'; 
			case '2': 
				return '2-Homologação'; 
			default: 
				return null; 
		} 
	} 

  static setAmbiente(String? ambiente) { 
		switch (ambiente) { 
			case '1-Produção': 
				return '1'; 
			case '2-Homologação': 
				return '2'; 
			default: 
				return null; 
		} 
	}


  static final tipoEventoListDropdown = ['Todos','Informações do contribuinte','Serviços tomados','Serviços prestados','Tabela de processos'];
  static final ambienteListDropdown = ['1-Produção','2-Homologação'];

}