class GeraEfdContribuicoesDomain {
  GeraEfdContribuicoesDomain._();

  static getTipoEscrituracao(String? tipoEscrituracao) { 
		switch (tipoEscrituracao) { 
			case '': 
			case '0': 
				return '0-Original'; 
			case '1': 
				return '1-Retificadora'; 
			default: 
				return null; 
		} 
	} 

  static setTipoEscrituracao(String? tipoEscrituracao) { 
		switch (tipoEscrituracao) { 
			case '0-Original': 
				return '0'; 
			case '1-Retificadora': 
				return '1'; 
			default: 
				return null; 
		} 
	}


  static final tipoEscrituracaoListDropdown = ['0-Original','1-Retificadora'];

}