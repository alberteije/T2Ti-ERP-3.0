class GeraSintegraDomain {
  GeraSintegraDomain._();

  static getCodigoConvenio(String? codigoConvenio) { 
		switch (codigoConvenio) { 
			case '': 
			case '1': 
				return '1-57/95 na versão 31/99'; 
			case '2': 
				return '2-57/95 na versão atual'; 
			default: 
				return null; 
		} 
	} 

  static setCodigoConvenio(String? codigoConvenio) { 
		switch (codigoConvenio) { 
			case '1-57/95 na versão 31/99': 
				return '1'; 
			case '2-57/95 na versão atual': 
				return '2'; 
			default: 
				return null; 
		} 
	}

  static getFinalidadeArquivo(String? finalidadeArquivo) { 
		switch (finalidadeArquivo) { 
			case '': 
			case '1': 
				return '1-Normal'; 
			case '2': 
				return '2-Retificação total de arquivo'; 
			case '3': 
				return '3-Retificação aditiva de arquivo'; 
			case '5': 
				return '5-Desfazimento'; 
			default: 
				return null; 
		} 
	} 

  static setFinalidadeArquivo(String? finalidadeArquivo) { 
		switch (finalidadeArquivo) { 
			case '1-Normal': 
				return '1'; 
			case '2-Retificação total de arquivo': 
				return '2'; 
			case '3-Retificação aditiva de arquivo': 
				return '3'; 
			case '5-Desfazimento': 
				return '5'; 
			default: 
				return null; 
		} 
	}

  static getNaturezaInformacoes(String? naturezaInformacoes) { 
		switch (naturezaInformacoes) { 
			case '': 
			case '1': 
				return '1-Interestaduais somente operações sujeitas ao regime de substituição tributária'; 
			case '2': 
				return '2-Interestaduais - operações com ou sem substituição tributária'; 
			case '3': 
				return '3-Totalidade das operações do informantes'; 
			default: 
				return null; 
		} 
	} 

  static setNaturezaInformacoes(String? naturezaInformacoes) { 
		switch (naturezaInformacoes) { 
			case '1-Interestaduais somente operações sujeitas ao regime de substituição tributária': 
				return '1'; 
			case '2-Interestaduais - operações com ou sem substituição tributária': 
				return '2'; 
			case '3-Totalidade das operações do informantes': 
				return '3'; 
			default: 
				return null; 
		} 
	}

  static getInventario(String? inventario) { 
		switch (inventario) { 
			case '': 
			case '0': 
				return '0-Sem Inventário'; 
			case '1': 
				return '1-No final do período'; 
			case '2': 
				return '2-Na mudança da forma de tributação da mercadoria (ICMS)'; 
			case '3': 
				return '3-Na solicitação da baixa cadastral paralisação temporária e outras situações'; 
			case '4': 
				return '4-Na alteração do regime de pagamento - condição do contribuite'; 
			case '5': 
				return '5-Por determinação dos fiscos'; 
			default: 
				return null; 
		} 
	} 

  static setInventario(String? inventario) { 
		switch (inventario) { 
			case '0-Sem Inventário': 
				return '0'; 
			case '1-No final do período': 
				return '1'; 
			case '2-Na mudança da forma de tributação da mercadoria (ICMS)': 
				return '2'; 
			case '3-Na solicitação da baixa cadastral paralisação temporária e outras situações': 
				return '3'; 
			case '4-Na alteração do regime de pagamento - condição do contribuite': 
				return '4'; 
			case '5-Por determinação dos fiscos': 
				return '5'; 
			default: 
				return null; 
		} 
	}


  static final codigoConvenioListDropdown = ['1-57/95 na versão 31/99','2-57/95 na versão atual'];
  static final finalidadeArquivoListDropdown = ['1-Normal','2-Retificação total de arquivo','3-Retificação aditiva de arquivo','5-Desfazimento'];
  static final naturezaInformacoesListDropdown = ['1-Interestaduais somente operações sujeitas ao regime de substituição tributária','2-Interestaduais - operações com ou sem substituição tributária','3-Totalidade das operações do informantes'];
  static final inventarioListDropdown = ['0-Sem Inventário','1-No final do período','2-Na mudança da forma de tributação da mercadoria (ICMS)','3-Na solicitação da baixa cadastral paralisação temporária e outras situações','4-Na alteração do regime de pagamento - condição do contribuite','5-Por determinação dos fiscos'];

}