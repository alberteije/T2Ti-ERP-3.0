import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:extended_masked_text/extended_masked_text.dart';
import 'package:gerador_arquivos/app/page/shared_widget/input/input_imports.dart';

import 'package:gerador_arquivos/app/page/shared_widget/message_dialog.dart';
import 'package:gerador_arquivos/app/page/grid_columns/grid_columns_imports.dart';
import 'package:gerador_arquivos/app/routes/app_routes.dart';
import 'package:gerador_arquivos/app/controller/controller_imports.dart';
import 'package:gerador_arquivos/app/data/model/model_imports.dart';
import 'package:gerador_arquivos/app/data/repository/gera_sped_contabil_repository.dart';

class GeraSpedContabilController extends ControllerBase<GeraSpedContabilModel, GeraSpedContabilRepository> {

  GeraSpedContabilController({required super.repository}) {
    dbColumns = GeraSpedContabilModel.dbColumns;
    aliasColumns = GeraSpedContabilModel.aliasColumns;
    gridColumns = geraSpedContabilGridColumns();
    functionName = "gera_sped_contabil";
    screenTitle = "Sped Contábil";
  }

  @override
  GeraSpedContabilModel createNewModel() => GeraSpedContabilModel();

  @override
  final standardFieldForFilter = GeraSpedContabilModel.aliasColumns[GeraSpedContabilModel.dbColumns.indexOf('data_emissao')];

  final dataEmissaoController = DatePickerItemController(null);
  final periodoInicialController = DatePickerItemController(null);
  final periodoFinalController = DatePickerItemController(null);
  final formaEscrituracaoController = CustomDropdownButtonController('G-Diário Geral');
  final versaoLayoutController = TextEditingController();
  final idEmpresaController = MoneyMaskedTextController(precision: 0, decimalSeparator: '', thousandSeparator: '');
  final idContadorController = MoneyMaskedTextController(precision: 0, decimalSeparator: '', thousandSeparator: '');

  final Map<String, dynamic> mobileConfig = {
    'primaryColumns': ['data_emissao'],
    'secondaryColumns': ['periodo_inicial'],
  };

  List<Map<String, dynamic>> get mobileItems {
    return modelList.map((geraSpedContabil) => geraSpedContabil.toJson).toList();
  }

  @override
  void prepareForInsert() {
    isNewRecord = true;
    currentModel = createNewModel();
    _resetForm();
    Get.toNamed(Routes.geraSpedContabilEditPage);
  }

  void _resetForm() {
    formWasChanged = false;
    dataEmissaoController.date = null;
    periodoInicialController.date = null;
    periodoFinalController.date = null;
    formaEscrituracaoController.selected = 'G-Diário Geral';
    versaoLayoutController.text = '';
    idEmpresaController.updateValue(0);
    idContadorController.updateValue(0);
  }

  @override
  void selectRowForEditingById(int id) {
    final model = modelList.firstWhere((m) => m.id == id);
    currentModel = model.clone();
    updateControllersFromModel();
    Get.toNamed(Routes.geraSpedContabilEditPage);
  }

  void updateControllersFromModel() {
    dataEmissaoController.date = currentModel.dataEmissao;
    periodoInicialController.date = currentModel.periodoInicial;
    periodoFinalController.date = currentModel.periodoFinal;
    formaEscrituracaoController.selected = currentModel.formaEscrituracao ?? 'G-Diário Geral';
    versaoLayoutController.text = currentModel.versaoLayout ?? '';
    idEmpresaController.updateValue((currentModel.idEmpresa ?? 0).toDouble());
    idContadorController.updateValue((currentModel.idContador ?? 0).toDouble());
    formWasChanged = false;
  }

  @override
  Future<void> save() async {
    if (!formKey.currentState!.validate()) {
      showErrorSnackBar(message: 'validator_form_message'.tr);
      return;
    }

    currentModel.dataEmissao = DateTime.now();

    final existingIndex = modelList.indexWhere((m) => m.id == currentModel.id);

    if (existingIndex >= 0) {
      modelList[existingIndex] = currentModel.clone();
    }

    final result = await repository.save(geraSpedContabilModel: currentModel);
    if (result == null) return;

    if (existingIndex >= 0) {
      modelList[existingIndex] = result;
    } else {
      modelList.insert(0, result);
    }

    if (!GetPlatform.isMobile) {
      updateGridRow(result);
    }

    Get.back(result: true);
  }

  Future gerarArquivo() async {
    if (currentModel.id == null) {
      showErrorSnackBar(message: 'Primeiro salve os dados para então gerar o arquivo.');
      return;
    }

    showQuestionDialog('Deseja Gerar o Arquivo?', () async {
      try {
        final result = await repository.gerarArquivo(geraSpedContabilModel: currentModel);
        if (result == null) return;

        if (result is String) {
          showInfoSnackBar(message: 'Arquivo gerado com sucesso: \n$result');
        }
      } catch (e) {
        showErrorSnackBar(message: "Erro ao gerar arquivo: ${e.toString()}");
      }
    });
  }

  @override
  void onClose() {
    dataEmissaoController.dispose();
    periodoInicialController.dispose();
    periodoFinalController.dispose();
    formaEscrituracaoController.dispose();
    versaoLayoutController.dispose();
    idEmpresaController.dispose();
    idContadorController.dispose();
    super.onClose();
  }

}