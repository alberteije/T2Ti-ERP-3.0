import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:extended_masked_text/extended_masked_text.dart';
import 'package:gerador_arquivos/app/page/shared_widget/input/input_imports.dart';

import 'package:gerador_arquivos/app/page/shared_widget/message_dialog.dart';
import 'package:gerador_arquivos/app/page/grid_columns/grid_columns_imports.dart';
import 'package:gerador_arquivos/app/routes/app_routes.dart';
import 'package:gerador_arquivos/app/controller/controller_imports.dart';
import 'package:gerador_arquivos/app/data/model/model_imports.dart';
import 'package:gerador_arquivos/app/data/repository/gera_efd_contribuicoes_repository.dart';

class GeraEfdContribuicoesController extends ControllerBase<GeraEfdContribuicoesModel, GeraEfdContribuicoesRepository> {

  GeraEfdContribuicoesController({required super.repository}) {
    dbColumns = GeraEfdContribuicoesModel.dbColumns;
    aliasColumns = GeraEfdContribuicoesModel.aliasColumns;
    gridColumns = geraEfdContribuicoesGridColumns();
    functionName = "gera_efd_contribuicoes";
    screenTitle = "EFD Contribuições";
  }

  @override
  GeraEfdContribuicoesModel createNewModel() => GeraEfdContribuicoesModel();

  @override
  final standardFieldForFilter = GeraEfdContribuicoesModel.aliasColumns[GeraEfdContribuicoesModel.dbColumns.indexOf('data_emissao')];

  final dataEmissaoController = DatePickerItemController(null);
  final periodoInicialController = DatePickerItemController(null);
  final periodoFinalController = DatePickerItemController(null);
  final versaoLayoutController = TextEditingController();
  final tipoEscrituracaoController = CustomDropdownButtonController('0-Original');
  final idEmpersaController = MoneyMaskedTextController(precision: 0, decimalSeparator: '', thousandSeparator: '');
  final idContadorController = MoneyMaskedTextController(precision: 0, decimalSeparator: '', thousandSeparator: '');

  final Map<String, dynamic> mobileConfig = {
    'primaryColumns': ['data_emissao'],
    'secondaryColumns': ['periodo_inicial'],
  };

  List<Map<String, dynamic>> get mobileItems {
    return modelList.map((geraEfdContribuicoes) => geraEfdContribuicoes.toJson).toList();
  }

  @override
  void prepareForInsert() {
    isNewRecord = true;
    currentModel = createNewModel();
    _resetForm();
    Get.toNamed(Routes.geraEfdContribuicoesEditPage);
  }

  void _resetForm() {
    formWasChanged = false;
    dataEmissaoController.date = null;
    periodoInicialController.date = null;
    periodoFinalController.date = null;
    versaoLayoutController.text = '';
    tipoEscrituracaoController.selected = '0-Original';
    idEmpersaController.updateValue(0);
    idContadorController.updateValue(0);
  }

  @override
  void selectRowForEditingById(int id) {
    final model = modelList.firstWhere((m) => m.id == id);
    currentModel = model.clone();
    updateControllersFromModel();
    Get.toNamed(Routes.geraEfdContribuicoesEditPage);
  }

  void updateControllersFromModel() {
    dataEmissaoController.date = currentModel.dataEmissao;
    periodoInicialController.date = currentModel.periodoInicial;
    periodoFinalController.date = currentModel.periodoFinal;
    versaoLayoutController.text = currentModel.versaoLayout ?? '';
    tipoEscrituracaoController.selected = currentModel.tipoEscrituracao ?? '0-Original';
    idEmpersaController.updateValue((currentModel.idEmpersa ?? 0).toDouble());
    idContadorController.updateValue((currentModel.idContador ?? 0).toDouble());
    formWasChanged = false;
  }

  @override
  Future<void> save() async {
    if (!formKey.currentState!.validate()) {
      showErrorSnackBar(message: 'validator_form_message'.tr);
      return;
    }

    currentModel.dataEmissao = DateTime.now();

    final existingIndex = modelList.indexWhere((m) => m.id == currentModel.id);

    if (existingIndex >= 0) {
      modelList[existingIndex] = currentModel.clone();
    }

    final result = await repository.save(geraEfdContribuicoesModel: currentModel);
    if (result == null) return;

    if (existingIndex >= 0) {
      modelList[existingIndex] = result;
    } else {
      modelList.insert(0, result);
    }

    if (!GetPlatform.isMobile) {
      updateGridRow(result);
    }

    Get.back(result: true);
  }


  Future gerarArquivo() async {
    if (currentModel.id == null) {
      showErrorSnackBar(message: 'Primeiro salve os dados para então gerar o arquivo.');
      return;
    }

    showQuestionDialog('Deseja Gerar o Arquivo?', () async {
      try {
        final result = await repository.gerarArquivo(geraEfdContribuicoesModel: currentModel);
        if (result == null) return;

        if (result is String) {
          showInfoSnackBar(message: 'Arquivo gerado com sucesso: \n$result');
        }
      } catch (e) {
        showErrorSnackBar(message: "Erro ao gerar arquivo: ${e.toString()}");
      }
    });
  }

  @override
  void onClose() {
    dataEmissaoController.dispose();
    periodoInicialController.dispose();
    periodoFinalController.dispose();
    versaoLayoutController.dispose();
    tipoEscrituracaoController.dispose();
    idEmpersaController.dispose();
    idContadorController.dispose();
    super.onClose();
  }

}