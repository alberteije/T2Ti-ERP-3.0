import 'package:get/get.dart';
import 'package:extended_masked_text/extended_masked_text.dart';
import 'package:gerador_arquivos/app/page/shared_widget/input/input_imports.dart';

import 'package:gerador_arquivos/app/page/shared_widget/message_dialog.dart';
import 'package:gerador_arquivos/app/page/grid_columns/grid_columns_imports.dart';
import 'package:gerador_arquivos/app/routes/app_routes.dart';
import 'package:gerador_arquivos/app/controller/controller_imports.dart';
import 'package:gerador_arquivos/app/data/model/model_imports.dart';
import 'package:gerador_arquivos/app/data/repository/gera_esocial_repository.dart';

class GeraEsocialController extends ControllerBase<GeraEsocialModel, GeraEsocialRepository> {

  GeraEsocialController({required super.repository}) {
    dbColumns = GeraEsocialModel.dbColumns;
    aliasColumns = GeraEsocialModel.aliasColumns;
    gridColumns = geraEsocialGridColumns();
    functionName = "gera_esocial";
    screenTitle = "E-Social";
  }

  @override
  GeraEsocialModel createNewModel() => GeraEsocialModel();

  @override
  final standardFieldForFilter = GeraEsocialModel.aliasColumns[GeraEsocialModel.dbColumns.indexOf('data_emissao')];

  final dataEmissaoController = DatePickerItemController(null);
  final periodoInicialController = DatePickerItemController(null);
  final periodoFinalController = DatePickerItemController(null);
  final competenciaController = MaskedTextController(mask: '00/0000',);
  final idEmpresaController = MoneyMaskedTextController(precision: 0, decimalSeparator: '', thousandSeparator: '');
  final idContadorController = MoneyMaskedTextController(precision: 0, decimalSeparator: '', thousandSeparator: '');

  final Map<String, dynamic> mobileConfig = {
    'primaryColumns': ['data_emissao'],
    'secondaryColumns': ['periodo_inicial'],
  };

  List<Map<String, dynamic>> get mobileItems {
    return modelList.map((geraEsocial) => geraEsocial.toJson).toList();
  }

  @override
  void prepareForInsert() {
    isNewRecord = true;
    currentModel = createNewModel();
    _resetForm();
    Get.toNamed(Routes.geraEsocialEditPage);
  }

  void _resetForm() {
    formWasChanged = false;
    dataEmissaoController.date = null;
    periodoInicialController.date = null;
    periodoFinalController.date = null;
    competenciaController.text = '';
    idEmpresaController.updateValue(0);
    idContadorController.updateValue(0);
  }

  @override
  void selectRowForEditingById(int id) {
    final model = modelList.firstWhere((m) => m.id == id);
    currentModel = model.clone();
    updateControllersFromModel();
    Get.toNamed(Routes.geraEsocialEditPage);
  }

  void updateControllersFromModel() {
    dataEmissaoController.date = currentModel.dataEmissao;
    periodoInicialController.date = currentModel.periodoInicial;
    periodoFinalController.date = currentModel.periodoFinal;
    competenciaController.text = currentModel.competencia ?? '';
    idEmpresaController.updateValue((currentModel.idEmpresa ?? 0).toDouble());
    idContadorController.updateValue((currentModel.idContador ?? 0).toDouble());
    formWasChanged = false;
  }

  @override
  Future<void> save() async {
    if (!formKey.currentState!.validate()) {
      showErrorSnackBar(message: 'validator_form_message'.tr);
      return;
    }

    currentModel.dataEmissao = DateTime.now();

    final existingIndex = modelList.indexWhere((m) => m.id == currentModel.id);

    if (existingIndex >= 0) {
      modelList[existingIndex] = currentModel.clone();
    }

    final result = await repository.save(geraEsocialModel: currentModel);
    if (result == null) return;

    if (existingIndex >= 0) {
      modelList[existingIndex] = result;
    } else {
      modelList.insert(0, result);
    }

    if (!GetPlatform.isMobile) {
      updateGridRow(result);
    }

    Get.back(result: true);
  }

  Future gerarArquivo() async {
    if (currentModel.id == null) {
      showErrorSnackBar(message: 'Primeiro salve os dados para então gerar o arquivo.');
      return;
    }

    showQuestionDialog('Deseja Gerar o Arquivo?', () async {
      try {
        final result = await repository.gerarArquivo(geraEsocialModel: currentModel);
        if (result == null) return;

        if (result is String) {
          showInfoSnackBar(message: 'Arquivos gerados com sucesso!');
        }
      } catch (e) {
        showErrorSnackBar(message: "Erro ao gerar arquivos: ${e.toString()}");
      }
    });
  }

  @override
  void onClose() {
    dataEmissaoController.dispose();
    periodoInicialController.dispose();
    periodoFinalController.dispose();
    competenciaController.dispose();
    idEmpresaController.dispose();
    idContadorController.dispose();
    super.onClose();
  }

}