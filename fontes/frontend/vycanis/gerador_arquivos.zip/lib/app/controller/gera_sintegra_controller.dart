import 'package:get/get.dart';
import 'package:extended_masked_text/extended_masked_text.dart';
import 'package:gerador_arquivos/app/page/shared_widget/input/input_imports.dart';

import 'package:gerador_arquivos/app/page/shared_widget/message_dialog.dart';
import 'package:gerador_arquivos/app/page/grid_columns/grid_columns_imports.dart';
import 'package:gerador_arquivos/app/routes/app_routes.dart';
import 'package:gerador_arquivos/app/controller/controller_imports.dart';
import 'package:gerador_arquivos/app/data/model/model_imports.dart';
import 'package:gerador_arquivos/app/data/repository/gera_sintegra_repository.dart';

class GeraSintegraController extends ControllerBase<GeraSintegraModel, GeraSintegraRepository> {

  GeraSintegraController({required super.repository}) {
    dbColumns = GeraSintegraModel.dbColumns;
    aliasColumns = GeraSintegraModel.aliasColumns;
    gridColumns = geraSintegraGridColumns();
    functionName = "gera_sintegra";
    screenTitle = "Sintegra";
  }

  @override
  GeraSintegraModel createNewModel() => GeraSintegraModel();

  @override
  final standardFieldForFilter = GeraSintegraModel.aliasColumns[GeraSintegraModel.dbColumns.indexOf('data_emissao')];

  final dataEmissaoController = DatePickerItemController(null);
  final periodoInicialController = DatePickerItemController(null);
  final periodoFinalController = DatePickerItemController(null);
  final codigoConvenioController = CustomDropdownButtonController('1-57/95 na versão 31/99');
  final finalidadeArquivoController = CustomDropdownButtonController('1-Normal');
  final naturezaInformacoesController = CustomDropdownButtonController('1-Interestaduais somente operações sujeitas ao regime de substituição tributária');
  final inventarioController = CustomDropdownButtonController('0-Sem Inventário');
  final idEmpresaController = MoneyMaskedTextController(precision: 0, decimalSeparator: '', thousandSeparator: '');
  final idContadorController = MoneyMaskedTextController(precision: 0, decimalSeparator: '', thousandSeparator: '');

  final Map<String, dynamic> mobileConfig = {
    'primaryColumns': ['data_emissao'],
    'secondaryColumns': ['periodo_inicial'],
  };

  List<Map<String, dynamic>> get mobileItems {
    return modelList.map((geraSintegra) => geraSintegra.toJson).toList();
  }

  @override
  void prepareForInsert() {
    isNewRecord = true;
    currentModel = createNewModel();
    _resetForm();
    Get.toNamed(Routes.geraSintegraEditPage);
  }

  void _resetForm() {
    formWasChanged = false;
    dataEmissaoController.date = null;
    periodoInicialController.date = null;
    periodoFinalController.date = null;
    codigoConvenioController.selected = '1-57/95 na versão 31/99';
    finalidadeArquivoController.selected = '1-Normal';
    naturezaInformacoesController.selected = '1-Interestaduais somente operações sujeitas ao regime de substituição tributária';
    inventarioController.selected = '0-Sem Inventário';
    idEmpresaController.updateValue(0);
    idContadorController.updateValue(0);
  }

  @override
  void selectRowForEditingById(int id) {
    final model = modelList.firstWhere((m) => m.id == id);
    currentModel = model.clone();
    updateControllersFromModel();
    Get.toNamed(Routes.geraSintegraEditPage);
  }

  void updateControllersFromModel() {
    dataEmissaoController.date = currentModel.dataEmissao;
    periodoInicialController.date = currentModel.periodoInicial;
    periodoFinalController.date = currentModel.periodoFinal;
    codigoConvenioController.selected = currentModel.codigoConvenio ?? '1-57/95 na versão 31/99';
    finalidadeArquivoController.selected = currentModel.finalidadeArquivo ?? '1-Normal';
    naturezaInformacoesController.selected = currentModel.naturezaInformacoes ?? '1-Interestaduais somente operações sujeitas ao regime de substituição tributária';
    inventarioController.selected = currentModel.inventario ?? '0-Sem Inventário';
    idEmpresaController.updateValue((currentModel.idEmpresa ?? 0).toDouble());
    idContadorController.updateValue((currentModel.idContador ?? 0).toDouble());
    formWasChanged = false;
  }

  @override
  Future<void> save() async {
    if (!formKey.currentState!.validate()) {
      showErrorSnackBar(message: 'validator_form_message'.tr);
      return;
    }

    currentModel.dataEmissao = DateTime.now();

    final existingIndex = modelList.indexWhere((m) => m.id == currentModel.id);

    if (existingIndex >= 0) {
      modelList[existingIndex] = currentModel.clone();
    }

    final result = await repository.save(geraSintegraModel: currentModel);
    if (result == null) return;

    if (existingIndex >= 0) {
      modelList[existingIndex] = result;
    } else {
      modelList.insert(0, result);
    }

    if (!GetPlatform.isMobile) {
      updateGridRow(result);
    }

    Get.back(result: true);
  }

  Future gerarArquivo() async {
    if (currentModel.id == null) {
      showErrorSnackBar(message: 'Primeiro salve os dados para então gerar o arquivo.');
      return;
    }

    showQuestionDialog('Deseja Gerar o Arquivo?', () async {
      try {
        final result = await repository.gerarArquivo(geraSintegraModel: currentModel);
        if (result == null) return;

        if (result is String) {
          showInfoSnackBar(message: 'Arquivo gerado com sucesso: \n$result');
        }
      } catch (e) {
        showErrorSnackBar(message: "Erro ao gerar arquivo: ${e.toString()}");
      }
    });
  }

  @override
  void onClose() {
    dataEmissaoController.dispose();
    periodoInicialController.dispose();
    periodoFinalController.dispose();
    codigoConvenioController.dispose();
    finalidadeArquivoController.dispose();
    naturezaInformacoesController.dispose();
    inventarioController.dispose();
    idEmpresaController.dispose();
    idContadorController.dispose();
    super.onClose();
  }

}