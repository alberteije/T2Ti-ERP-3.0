import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_bootstrap/flutter_bootstrap.dart';
import 'package:get/get.dart';
import 'package:gerador_arquivos/app/page/shared_widget/shared_widget_imports.dart';
import 'package:gerador_arquivos/app/data/domain/domain_imports.dart';
import 'package:gerador_arquivos/app/controller/gera_efd_contribuicoes_controller.dart';
import 'package:gerador_arquivos/app/infra/infra_imports.dart';
import 'package:gerador_arquivos/app/page/shared_widget/input/input_imports.dart';

class GeraEfdContribuicoesEditPage extends StatelessWidget {
	GeraEfdContribuicoesEditPage({Key? key}) : super(key: key);
	final geraEfdContribuicoesController = Get.find<GeraEfdContribuicoesController>();

	@override
	Widget build(BuildContext context) {
		return KeyboardListener(
			autofocus: false,
			focusNode: FocusNode(),
			onKeyEvent: (event) {
				if (event.logicalKey == LogicalKeyboardKey.escape) {
					geraEfdContribuicoesController.preventDataLoss();
				}
			},
			child: Scaffold(
				key: geraEfdContribuicoesController.scaffoldKey,
				appBar: AppBar(
					automaticallyImplyLeading: false,
					title: Text('${ geraEfdContribuicoesController.screenTitle } - ${ geraEfdContribuicoesController.isNewRecord ? 'inserting'.tr : 'editing'.tr }',),
					actions: [
            IconButton(
              tooltip: 'Gerar Arquivo',
              icon: const Icon(Icons.cloud_upload, color: Colors.greenAccent),
              color: Colors.yellow,
              onPressed: geraEfdContribuicoesController.gerarArquivo,
            ),
						saveButton(onPressed: geraEfdContribuicoesController.save),
						cancelAndExitButton(onPressed: geraEfdContribuicoesController.preventDataLoss),
					]
				),
				body: SafeArea(
					top: false,
					bottom: false,
					child: Form(
						key: geraEfdContribuicoesController.formKey,
						autovalidateMode: AutovalidateMode.always,
						child: Scrollbar(
							controller: geraEfdContribuicoesController.scrollController,
							child: SingleChildScrollView(
								controller: geraEfdContribuicoesController.scrollController,
								child: BootstrapContainer(
									fluid: true,
									padding: const EdgeInsets.fromLTRB(10.0, 10.0, 10.0, 10.0),
									children: <Widget>[
										const Divider(
											color: Colors.transparent,
										),
										BootstrapRow(
											height: 60,
											children: <BootstrapCol>[
												// BootstrapCol(
												// 	sizes: 'col-12 col-md-4',
												// 	child: Padding(
												// 		padding: Util.distanceBetweenColumnsLineBreak(context)!,
												// 		child: InputDecorator(
												// 			decoration: inputDecoration(
												// 				hintText: 'Informe os dados para o campo Data Emissao',
												// 				labelText: 'Data Emissao',
												// 				usePadding: true,
												// 			),
												// 			isEmpty: false,
												// 			child: DatePickerItem(
												// 				controller: geraEfdContribuicoesController.dataEmissaoController,
												// 				firstDate: DateTime.parse('1000-01-01'),
												// 				lastDate: DateTime.parse('5000-01-01'),
												// 				onChanged: (DateTime? value) {
												// 					geraEfdContribuicoesController.currentModel.dataEmissao = value;
												// 					geraEfdContribuicoesController.formWasChanged = true;
												// 				},
												// 			),
												// 		),
												// 	),
												// ),
												BootstrapCol(
													sizes: 'col-12 col-md-6',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: InputDecorator(
															decoration: inputDecoration(
																hintText: 'Informe os dados para o campo Periodo Inicial',
																labelText: 'Periodo Inicial',
																usePadding: true,
															),
															isEmpty: false,
															child: DatePickerItem(
																controller: geraEfdContribuicoesController.periodoInicialController,
																firstDate: DateTime.parse('1000-01-01'),
																lastDate: DateTime.parse('5000-01-01'),
																onChanged: (DateTime? value) {
																	geraEfdContribuicoesController.currentModel.periodoInicial = value;
																	geraEfdContribuicoesController.formWasChanged = true;
																},
															),
														),
													),
												),
												BootstrapCol(
													sizes: 'col-12 col-md-6',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: InputDecorator(
															decoration: inputDecoration(
																hintText: 'Informe os dados para o campo Periodo Final',
																labelText: 'Periodo Final',
																usePadding: true,
															),
															isEmpty: false,
															child: DatePickerItem(
																controller: geraEfdContribuicoesController.periodoFinalController,
																firstDate: DateTime.parse('1000-01-01'),
																lastDate: DateTime.parse('5000-01-01'),
																onChanged: (DateTime? value) {
																	geraEfdContribuicoesController.currentModel.periodoFinal = value;
																	geraEfdContribuicoesController.formWasChanged = true;
																},
															),
														),
													),
												),
											],
										),
										const Divider(
											color: Colors.transparent,
										),
										BootstrapRow(
											height: 60,
											children: <BootstrapCol>[
												BootstrapCol(
													sizes: 'col-12',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: TextFormField(
															autofocus: true,
															maxLength: 3,
															controller: geraEfdContribuicoesController.versaoLayoutController,
															decoration: inputDecoration(
																hintText: 'Informe os dados para o campo Versao Layout',
																labelText: 'Versao Layout',
																usePadding: true,
															),
															onSaved: (String? value) {},
															onChanged: (text) {
																geraEfdContribuicoesController.currentModel.versaoLayout = text;
																geraEfdContribuicoesController.formWasChanged = true;
															},
														),
													),
												),
											],
										),
										const Divider(
											color: Colors.transparent,
										),
										BootstrapRow(
											height: 60,
											children: <BootstrapCol>[
												BootstrapCol(
													sizes: 'col-12',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: CustomDropdownButton(
															controller: geraEfdContribuicoesController.tipoEscrituracaoController,
															labelText: 'Tipo Escrituracao',
															hintText: 'Informe os dados para o campo Tipo Escrituracao',
															items: GeraEfdContribuicoesDomain.tipoEscrituracaoListDropdown,
															onChanged: (dynamic newValue) {
																geraEfdContribuicoesController.currentModel.tipoEscrituracao = newValue;
																geraEfdContribuicoesController.formWasChanged = true;
															},
														),
													),
												),
											],
										),
										// const Divider(
										// 	color: Colors.transparent,
										// ),
										// BootstrapRow(
										// 	height: 60,
										// 	children: <BootstrapCol>[
										// 		BootstrapCol(
										// 			sizes: 'col-12',
										// 			child: Padding(
										// 				padding: Util.distanceBetweenColumnsLineBreak(context)!,
										// 				child: TextFormField(
										// 					keyboardType: TextInputType.number,
										// 					autofocus: true,
										// 					controller: geraEfdContribuicoesController.idEmpersaController,
										// 					decoration: inputDecoration(
										// 						hintText: 'Informe os dados para o campo Id Empersa',
										// 						labelText: 'Id Empersa',
										// 						usePadding: true,
										// 					),
										// 					onSaved: (String? value) {},
										// 					onChanged: (text) {
										// 						geraEfdContribuicoesController.currentModel.idEmpersa = int.tryParse(text);
										// 						geraEfdContribuicoesController.formWasChanged = true;
										// 					},
										// 				),
										// 			),
										// 		),
										// 	],
										// ),
										// const Divider(
										// 	color: Colors.transparent,
										// ),
										// BootstrapRow(
										// 	height: 60,
										// 	children: <BootstrapCol>[
										// 		BootstrapCol(
										// 			sizes: 'col-12',
										// 			child: Padding(
										// 				padding: Util.distanceBetweenColumnsLineBreak(context)!,
										// 				child: TextFormField(
										// 					keyboardType: TextInputType.number,
										// 					autofocus: true,
										// 					controller: geraEfdContribuicoesController.idContadorController,
										// 					decoration: inputDecoration(
										// 						hintText: 'Informe os dados para o campo Id Contador',
										// 						labelText: 'Id Contador',
										// 						usePadding: true,
										// 					),
										// 					onSaved: (String? value) {},
										// 					onChanged: (text) {
										// 						geraEfdContribuicoesController.currentModel.idContador = int.tryParse(text);
										// 						geraEfdContribuicoesController.formWasChanged = true;
										// 					},
										// 				),
										// 			),
										// 		),
										// 	],
										// ),
										const Divider(
											indent: 10,
											endIndent: 10,
											thickness: 2,
										),
										BootstrapRow(
											height: 60,
											children: <BootstrapCol>[
												BootstrapCol(
													sizes: 'col-12',
													child: Text(
														'field_is_mandatory'.tr,
														style: Theme.of(context).textTheme.bodySmall,
													),
												),
											],
										),
										const SizedBox(height: 10.0),
									],
								),
							),
						),
					),
				),
			),
		);
	}
}
