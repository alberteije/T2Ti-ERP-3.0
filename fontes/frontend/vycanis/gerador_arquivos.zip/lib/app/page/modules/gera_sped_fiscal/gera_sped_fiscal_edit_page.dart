import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_bootstrap/flutter_bootstrap.dart';
import 'package:get/get.dart';
import 'package:gerador_arquivos/app/page/shared_widget/shared_widget_imports.dart';
import 'package:gerador_arquivos/app/data/domain/domain_imports.dart';
import 'package:gerador_arquivos/app/controller/gera_sped_fiscal_controller.dart';
import 'package:gerador_arquivos/app/infra/infra_imports.dart';
import 'package:gerador_arquivos/app/page/shared_widget/input/input_imports.dart';

class GeraSpedFiscalEditPage extends StatelessWidget {
	GeraSpedFiscalEditPage({Key? key}) : super(key: key);
	final geraSpedFiscalController = Get.find<GeraSpedFiscalController>();

	@override
	Widget build(BuildContext context) {
		return KeyboardListener(
			autofocus: false,
			focusNode: FocusNode(),
			onKeyEvent: (event) {
				if (event.logicalKey == LogicalKeyboardKey.escape) {
					geraSpedFiscalController.preventDataLoss();
				}
			},
			child: Scaffold(
				key: geraSpedFiscalController.scaffoldKey,
				appBar: AppBar(
					automaticallyImplyLeading: false,
					title: Text('${ geraSpedFiscalController.screenTitle } - ${ geraSpedFiscalController.isNewRecord ? 'inserting'.tr : 'editing'.tr }',),
					actions: [
            IconButton(
              tooltip: 'Gerar Arquivo',
              icon: const Icon(Icons.cloud_upload, color: Colors.greenAccent),
              color: Colors.yellow,
              onPressed: geraSpedFiscalController.gerarArquivo,
            ),
						saveButton(onPressed: geraSpedFiscalController.save),
						cancelAndExitButton(onPressed: geraSpedFiscalController.preventDataLoss),
					]
				),
				body: SafeArea(
					top: false,
					bottom: false,
					child: Form(
						key: geraSpedFiscalController.formKey,
						autovalidateMode: AutovalidateMode.always,
						child: Scrollbar(
							controller: geraSpedFiscalController.scrollController,
							child: SingleChildScrollView(
								controller: geraSpedFiscalController.scrollController,
								child: BootstrapContainer(
									fluid: true,
									padding: const EdgeInsets.fromLTRB(10.0, 10.0, 10.0, 10.0),
									children: <Widget>[
										const Divider(
											color: Colors.transparent,
										),
										BootstrapRow(
											height: 60,
											children: <BootstrapCol>[
												BootstrapCol(
													sizes: 'col-12 col-md-6',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: InputDecorator(
															decoration: inputDecoration(
																hintText: 'Informe os dados para o campo Periodo Inicial',
																labelText: 'Periodo Inicial',
																usePadding: true,
															),
															isEmpty: false,
															child: DatePickerItem(
																controller: geraSpedFiscalController.periodoInicialController,
																firstDate: DateTime.parse('1000-01-01'),
																lastDate: DateTime.parse('5000-01-01'),
																onChanged: (DateTime? value) {
																	geraSpedFiscalController.currentModel.periodoInicial = value;
																	geraSpedFiscalController.formWasChanged = true;
																},
															),
														),
													),
												),
												BootstrapCol(
													sizes: 'col-12 col-md-6',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: InputDecorator(
															decoration: inputDecoration(
																hintText: 'Informe os dados para o campo Periodo Final',
																labelText: 'Periodo Final',
																usePadding: true,
															),
															isEmpty: false,
															child: DatePickerItem(
																controller: geraSpedFiscalController.periodoFinalController,
																firstDate: DateTime.parse('1000-01-01'),
																lastDate: DateTime.parse('5000-01-01'),
																onChanged: (DateTime? value) {
																	geraSpedFiscalController.currentModel.periodoFinal = value;
																	geraSpedFiscalController.formWasChanged = true;
																},
															),
														),
													),
												),
											],
										),
										const Divider(
											color: Colors.transparent,
										),
										BootstrapRow(
											height: 60,
											children: <BootstrapCol>[
												BootstrapCol(
													sizes: 'col-12 col-md-6',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: TextFormField(
															autofocus: true,
															maxLength: 3,
															controller: geraSpedFiscalController.versaoLayoutController,
															decoration: inputDecoration(
																hintText: 'Informe os dados para o campo Versao Layout',
																labelText: 'Versao Layout',
																usePadding: true,
															),
															onSaved: (String? value) {},
															onChanged: (text) {
																geraSpedFiscalController.currentModel.versaoLayout = text;
																geraSpedFiscalController.formWasChanged = true;
															},
														),
													),
												),
												BootstrapCol(
													sizes: 'col-12 col-md-6',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: CustomDropdownButton(
															controller: geraSpedFiscalController.finalidadeArquivoController,
															labelText: 'Finalidade Arquivo',
															hintText: 'Informe os dados para o campo Finalidade Arquivo',
															items: GeraSpedFiscalDomain.finalidadeArquivoListDropdown,
															onChanged: (dynamic newValue) {
																geraSpedFiscalController.currentModel.finalidadeArquivo = newValue;
																geraSpedFiscalController.formWasChanged = true;
															},
														),
													),
												),
											],
										),
										const Divider(
											color: Colors.transparent,
										),
										BootstrapRow(
											height: 60,
											children: <BootstrapCol>[
												BootstrapCol(
													sizes: 'col-12 col-md-6',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: CustomDropdownButton(
															controller: geraSpedFiscalController.perfilApresentacaoController,
															labelText: 'Perfil Apresentacao',
															hintText: 'Informe os dados para o campo Perfil Apresentacao',
															items: GeraSpedFiscalDomain.perfilApresentacaoListDropdown,
															onChanged: (dynamic newValue) {
																geraSpedFiscalController.currentModel.perfilApresentacao = newValue;
																geraSpedFiscalController.formWasChanged = true;
															},
														),
													),
												),
												BootstrapCol(
													sizes: 'col-12 col-md-6',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: CustomDropdownButton(
															controller: geraSpedFiscalController.inventarioController,
															labelText: 'Inventario',
															hintText: 'Informe os dados para o campo Inventario',
															items: GeraSpedFiscalDomain.inventarioListDropdown,
															onChanged: (dynamic newValue) {
																geraSpedFiscalController.currentModel.inventario = newValue;
																geraSpedFiscalController.formWasChanged = true;
															},
														),
													),
												),
											],
										),
										// const Divider(
										// 	color: Colors.transparent,
										// ),
										// BootstrapRow(
										// 	height: 60,
										// 	children: <BootstrapCol>[
										// 		BootstrapCol(
										// 			sizes: 'col-12',
										// 			child: Padding(
										// 				padding: Util.distanceBetweenColumnsLineBreak(context)!,
										// 				child: TextFormField(
										// 					keyboardType: TextInputType.number,
										// 					autofocus: true,
										// 					controller: geraSpedFiscalController.idEmpresaController,
										// 					decoration: inputDecoration(
										// 						hintText: 'Informe os dados para o campo Id Empresa',
										// 						labelText: 'Id Empresa',
										// 						usePadding: true,
										// 					),
										// 					onSaved: (String? value) {},
										// 					onChanged: (text) {
										// 						geraSpedFiscalController.currentModel.idEmpresa = int.tryParse(text);
										// 						geraSpedFiscalController.formWasChanged = true;
										// 					},
										// 				),
										// 			),
										// 		),
										// 	],
										// ),
										// const Divider(
										// 	color: Colors.transparent,
										// ),
										// BootstrapRow(
										// 	height: 60,
										// 	children: <BootstrapCol>[
										// 		BootstrapCol(
										// 			sizes: 'col-12',
										// 			child: Padding(
										// 				padding: Util.distanceBetweenColumnsLineBreak(context)!,
										// 				child: TextFormField(
										// 					keyboardType: TextInputType.number,
										// 					autofocus: true,
										// 					controller: geraSpedFiscalController.idContadorController,
										// 					decoration: inputDecoration(
										// 						hintText: 'Informe os dados para o campo Id Contador',
										// 						labelText: 'Id Contador',
										// 						usePadding: true,
										// 					),
										// 					onSaved: (String? value) {},
										// 					onChanged: (text) {
										// 						geraSpedFiscalController.currentModel.idContador = int.tryParse(text);
										// 						geraSpedFiscalController.formWasChanged = true;
										// 					},
										// 				),
										// 			),
										// 		),
										// 	],
										// ),
										const Divider(
											indent: 10,
											endIndent: 10,
											thickness: 2,
										),
										BootstrapRow(
											height: 60,
											children: <BootstrapCol>[
												BootstrapCol(
													sizes: 'col-12',
													child: Text(
														'field_is_mandatory'.tr,
														style: Theme.of(context).textTheme.bodySmall,
													),
												),
											],
										),
										const SizedBox(height: 10.0),
									],
								),
							),
						),
					),
				),
			),
		);
	}
}
