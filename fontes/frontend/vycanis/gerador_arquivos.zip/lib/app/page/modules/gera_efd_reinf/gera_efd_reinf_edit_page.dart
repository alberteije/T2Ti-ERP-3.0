import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_bootstrap/flutter_bootstrap.dart';
import 'package:get/get.dart';
import 'package:gerador_arquivos/app/page/shared_widget/shared_widget_imports.dart';
import 'package:gerador_arquivos/app/data/domain/domain_imports.dart';
import 'package:gerador_arquivos/app/controller/gera_efd_reinf_controller.dart';
import 'package:gerador_arquivos/app/infra/infra_imports.dart';
import 'package:gerador_arquivos/app/page/shared_widget/input/input_imports.dart';

class GeraEfdReinfEditPage extends StatelessWidget {
	GeraEfdReinfEditPage({Key? key}) : super(key: key);
	final geraEfdReinfController = Get.find<GeraEfdReinfController>();

	@override
	Widget build(BuildContext context) {
		return KeyboardListener(
			autofocus: false,
			focusNode: FocusNode(),
			onKeyEvent: (event) {
				if (event.logicalKey == LogicalKeyboardKey.escape) {
					geraEfdReinfController.preventDataLoss();
				}
			},
			child: Scaffold(
				key: geraEfdReinfController.scaffoldKey,
				appBar: AppBar(
					automaticallyImplyLeading: false,
					title: Text('${ geraEfdReinfController.screenTitle } - ${ geraEfdReinfController.isNewRecord ? 'inserting'.tr : 'editing'.tr }',),
					actions: [
            IconButton(
              tooltip: 'Gerar Arquivo',
              icon: const Icon(Icons.cloud_upload, color: Colors.greenAccent),
              color: Colors.yellow,
              onPressed: geraEfdReinfController.gerarArquivo,
            ),
						saveButton(onPressed: geraEfdReinfController.save),
						cancelAndExitButton(onPressed: geraEfdReinfController.preventDataLoss),
					]
				),
				body: SafeArea(
					top: false,
					bottom: false,
					child: Form(
						key: geraEfdReinfController.formKey,
						autovalidateMode: AutovalidateMode.always,
						child: Scrollbar(
							controller: geraEfdReinfController.scrollController,
							child: SingleChildScrollView(
								controller: geraEfdReinfController.scrollController,
								child: BootstrapContainer(
									fluid: true,
									padding: const EdgeInsets.fromLTRB(10.0, 10.0, 10.0, 10.0),
									children: <Widget>[
										const Divider(
											color: Colors.transparent,
										),
										BootstrapRow(
											height: 60,
											children: <BootstrapCol>[
												BootstrapCol(
													sizes: 'col-12 col-md-6',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: InputDecorator(
															decoration: inputDecoration(
																hintText: 'Informe os dados para o campo Periodo Inicial',
																labelText: 'Periodo Inicial',
																usePadding: true,
															),
															isEmpty: false,
															child: DatePickerItem(
																controller: geraEfdReinfController.periodoInicialController,
																firstDate: DateTime.parse('1000-01-01'),
																lastDate: DateTime.parse('5000-01-01'),
																onChanged: (DateTime? value) {
																	geraEfdReinfController.currentModel.periodoInicial = value;
																	geraEfdReinfController.formWasChanged = true;
																},
															),
														),
													),
												),
												BootstrapCol(
													sizes: 'col-12 col-md-6',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: InputDecorator(
															decoration: inputDecoration(
																hintText: 'Informe os dados para o campo Periodo Final',
																labelText: 'Periodo Final',
																usePadding: true,
															),
															isEmpty: false,
															child: DatePickerItem(
																controller: geraEfdReinfController.periodoFinalController,
																firstDate: DateTime.parse('1000-01-01'),
																lastDate: DateTime.parse('5000-01-01'),
																onChanged: (DateTime? value) {
																	geraEfdReinfController.currentModel.periodoFinal = value;
																	geraEfdReinfController.formWasChanged = true;
																},
															),
														),
													),
												),
											],
										),
										const Divider(
											color: Colors.transparent,
										),
										BootstrapRow(
											height: 60,
											children: <BootstrapCol>[
												BootstrapCol(
													sizes: 'col-12 col-md-6',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: CustomDropdownButton(
															controller: geraEfdReinfController.tipoEventoController,
															labelText: 'Tipo Evento',
															hintText: 'Informe os dados para o campo Tipo Evento',
															items: GeraEfdReinfDomain.tipoEventoListDropdown,
															onChanged: (dynamic newValue) {
																geraEfdReinfController.currentModel.tipoEvento = newValue;
																geraEfdReinfController.formWasChanged = true;
															},
														),
													),
												),
												BootstrapCol(
													sizes: 'col-12 col-md-6',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: CustomDropdownButton(
															controller: geraEfdReinfController.ambienteController,
															labelText: 'Ambiente',
															hintText: 'Informe os dados para o campo Ambiente',
															items: GeraEfdReinfDomain.ambienteListDropdown,
															onChanged: (dynamic newValue) {
																geraEfdReinfController.currentModel.ambiente = newValue;
																geraEfdReinfController.formWasChanged = true;
															},
														),
													),
												),
											],
										),
										// const Divider(
										// 	color: Colors.transparent,
										// ),
										// BootstrapRow(
										// 	height: 60,
										// 	children: <BootstrapCol>[
										// 		BootstrapCol(
										// 			sizes: 'col-12',
										// 			child: Padding(
										// 				padding: Util.distanceBetweenColumnsLineBreak(context)!,
										// 				child: TextFormField(
										// 					keyboardType: TextInputType.number,
										// 					autofocus: true,
										// 					controller: geraEfdReinfController.idEmpresaController,
										// 					decoration: inputDecoration(
										// 						hintText: 'Informe os dados para o campo Id Empresa',
										// 						labelText: 'Id Empresa',
										// 						usePadding: true,
										// 					),
										// 					onSaved: (String? value) {},
										// 					onChanged: (text) {
										// 						geraEfdReinfController.currentModel.idEmpresa = int.tryParse(text);
										// 						geraEfdReinfController.formWasChanged = true;
										// 					},
										// 				),
										// 			),
										// 		),
										// 	],
										// ),
										// const Divider(
										// 	color: Colors.transparent,
										// ),
										// BootstrapRow(
										// 	height: 60,
										// 	children: <BootstrapCol>[
										// 		BootstrapCol(
										// 			sizes: 'col-12',
										// 			child: Padding(
										// 				padding: Util.distanceBetweenColumnsLineBreak(context)!,
										// 				child: TextFormField(
										// 					keyboardType: TextInputType.number,
										// 					autofocus: true,
										// 					controller: geraEfdReinfController.idContadorController,
										// 					decoration: inputDecoration(
										// 						hintText: 'Informe os dados para o campo Id Contador',
										// 						labelText: 'Id Contador',
										// 						usePadding: true,
										// 					),
										// 					onSaved: (String? value) {},
										// 					onChanged: (text) {
										// 						geraEfdReinfController.currentModel.idContador = int.tryParse(text);
										// 						geraEfdReinfController.formWasChanged = true;
										// 					},
										// 				),
										// 			),
										// 		),
										// 	],
										// ),
										const Divider(
											indent: 10,
											endIndent: 10,
											thickness: 2,
										),
										BootstrapRow(
											height: 60,
											children: <BootstrapCol>[
												BootstrapCol(
													sizes: 'col-12',
													child: Text(
														'field_is_mandatory'.tr,
														style: Theme.of(context).textTheme.bodySmall,
													),
												),
											],
										),
										const SizedBox(height: 10.0),
									],
								),
							),
						),
					),
				),
			),
		);
	}
}
