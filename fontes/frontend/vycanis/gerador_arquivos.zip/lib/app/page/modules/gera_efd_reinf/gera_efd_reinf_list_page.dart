import 'package:flutter/material.dart';
import 'package:gerador_arquivos/app/controller/gera_efd_reinf_controller.dart';
import 'package:gerador_arquivos/app/page/shared_page/list_page_base.dart';

class GeraEfdReinfListPage extends ListPageBase<GeraEfdReinfController> {
  const GeraEfdReinfListPage({Key? key}) : super(key: key);

  @override
  List<Map<String, dynamic>> get mobileItems => controller.mobileItems;

  @override
  Map<String, dynamic> get mobileConfig => controller.mobileConfig;

  @override
  String get standardFieldForFilter => controller.standardFieldForFilter;
}