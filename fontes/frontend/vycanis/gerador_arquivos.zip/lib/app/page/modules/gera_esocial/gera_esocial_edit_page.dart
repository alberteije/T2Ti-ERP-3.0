import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_bootstrap/flutter_bootstrap.dart';
import 'package:get/get.dart';
import 'package:gerador_arquivos/app/page/shared_widget/shared_widget_imports.dart';
import 'package:gerador_arquivos/app/controller/gera_esocial_controller.dart';
import 'package:gerador_arquivos/app/infra/infra_imports.dart';
import 'package:gerador_arquivos/app/page/shared_widget/input/input_imports.dart';

class GeraEsocialEditPage extends StatelessWidget {
	GeraEsocialEditPage({Key? key}) : super(key: key);
	final geraEsocialController = Get.find<GeraEsocialController>();

	@override
	Widget build(BuildContext context) {
		return KeyboardListener(
			autofocus: false,
			focusNode: FocusNode(),
			onKeyEvent: (event) {
				if (event.logicalKey == LogicalKeyboardKey.escape) {
					geraEsocialController.preventDataLoss();
				}
			},
			child: Scaffold(
				key: geraEsocialController.scaffoldKey,
				appBar: AppBar(
					automaticallyImplyLeading: false,
					title: Text('${ geraEsocialController.screenTitle } - ${ geraEsocialController.isNewRecord ? 'inserting'.tr : 'editing'.tr }',),
					actions: [
            IconButton(
              tooltip: 'Gerar Arquivo',
              icon: const Icon(Icons.cloud_upload, color: Colors.greenAccent),
              color: Colors.yellow,
              onPressed: geraEsocialController.gerarArquivo,
            ),
						saveButton(onPressed: geraEsocialController.save),
						cancelAndExitButton(onPressed: geraEsocialController.preventDataLoss),
					]
				),
				body: SafeArea(
					top: false,
					bottom: false,
					child: Form(
						key: geraEsocialController.formKey,
						autovalidateMode: AutovalidateMode.always,
						child: Scrollbar(
							controller: geraEsocialController.scrollController,
							child: SingleChildScrollView(
								controller: geraEsocialController.scrollController,
								child: BootstrapContainer(
									fluid: true,
									padding: const EdgeInsets.fromLTRB(10.0, 10.0, 10.0, 10.0),
									children: <Widget>[
										const Divider(
											color: Colors.transparent,
										),
										BootstrapRow(
											height: 60,
											children: <BootstrapCol>[
												BootstrapCol(
													sizes: 'col-12 col-md-4',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: InputDecorator(
															decoration: inputDecoration(
																hintText: 'Informe os dados para o campo Periodo Inicial',
																labelText: 'Periodo Inicial',
																usePadding: true,
															),
															isEmpty: false,
															child: DatePickerItem(
																controller: geraEsocialController.periodoInicialController,
																firstDate: DateTime.parse('1000-01-01'),
																lastDate: DateTime.parse('5000-01-01'),
																onChanged: (DateTime? value) {
																	geraEsocialController.currentModel.periodoInicial = value;
																	geraEsocialController.formWasChanged = true;
																},
															),
														),
													),
												),
												BootstrapCol(
													sizes: 'col-12 col-md-4',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: InputDecorator(
															decoration: inputDecoration(
																hintText: 'Informe os dados para o campo Periodo Final',
																labelText: 'Periodo Final',
																usePadding: true,
															),
															isEmpty: false,
															child: DatePickerItem(
																controller: geraEsocialController.periodoFinalController,
																firstDate: DateTime.parse('1000-01-01'),
																lastDate: DateTime.parse('5000-01-01'),
																onChanged: (DateTime? value) {
																	geraEsocialController.currentModel.periodoFinal = value;
																	geraEsocialController.formWasChanged = true;
																},
															),
														),
													),
												),
												BootstrapCol(
													sizes: 'col-12 col-md-4',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: TextFormField(
															autofocus: true,
															controller: geraEsocialController.competenciaController,
															decoration: inputDecoration(
																hintText: 'Informe os dados para o campo Competencia',
																labelText: 'Competencia',
																usePadding: true,
															),
															onSaved: (String? value) {},
															onChanged: (text) {
																geraEsocialController.currentModel.competencia = text;
																geraEsocialController.formWasChanged = true;
															},
														),
													),
												),
											],
										),
										// const Divider(
										// 	color: Colors.transparent,
										// ),
										// BootstrapRow(
										// 	height: 60,
										// 	children: <BootstrapCol>[
										// 		BootstrapCol(
										// 			sizes: 'col-12',
										// 			child: Padding(
										// 				padding: Util.distanceBetweenColumnsLineBreak(context)!,
										// 				child: TextFormField(
										// 					keyboardType: TextInputType.number,
										// 					autofocus: true,
										// 					controller: geraEsocialController.idEmpresaController,
										// 					decoration: inputDecoration(
										// 						hintText: 'Informe os dados para o campo Id Empresa',
										// 						labelText: 'Id Empresa',
										// 						usePadding: true,
										// 					),
										// 					onSaved: (String? value) {},
										// 					onChanged: (text) {
										// 						geraEsocialController.currentModel.idEmpresa = int.tryParse(text);
										// 						geraEsocialController.formWasChanged = true;
										// 					},
										// 				),
										// 			),
										// 		),
										// 	],
										// ),
										// const Divider(
										// 	color: Colors.transparent,
										// ),
										// BootstrapRow(
										// 	height: 60,
										// 	children: <BootstrapCol>[
										// 		BootstrapCol(
										// 			sizes: 'col-12',
										// 			child: Padding(
										// 				padding: Util.distanceBetweenColumnsLineBreak(context)!,
										// 				child: TextFormField(
										// 					keyboardType: TextInputType.number,
										// 					autofocus: true,
										// 					controller: geraEsocialController.idContadorController,
										// 					decoration: inputDecoration(
										// 						hintText: 'Informe os dados para o campo Id Contador',
										// 						labelText: 'Id Contador',
										// 						usePadding: true,
										// 					),
										// 					onSaved: (String? value) {},
										// 					onChanged: (text) {
										// 						geraEsocialController.currentModel.idContador = int.tryParse(text);
										// 						geraEsocialController.formWasChanged = true;
										// 					},
										// 				),
										// 			),
										// 		),
										// 	],
										// ),
										const Divider(
											indent: 10,
											endIndent: 10,
											thickness: 2,
										),
										BootstrapRow(
											height: 60,
											children: <BootstrapCol>[
												BootstrapCol(
													sizes: 'col-12',
													child: Text(
														'field_is_mandatory'.tr,
														style: Theme.of(context).textTheme.bodySmall,
													),
												),
											],
										),
										const SizedBox(height: 10.0),
									],
								),
							),
						),
					),
				),
			),
		);
	}
}
