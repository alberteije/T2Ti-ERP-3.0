import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_bootstrap/flutter_bootstrap.dart';
import 'package:get/get.dart';
import 'package:gerador_arquivos/app/page/shared_widget/shared_widget_imports.dart';
import 'package:gerador_arquivos/app/data/domain/domain_imports.dart';
import 'package:gerador_arquivos/app/controller/gera_sped_contabil_controller.dart';
import 'package:gerador_arquivos/app/infra/infra_imports.dart';
import 'package:gerador_arquivos/app/page/shared_widget/input/input_imports.dart';

class GeraSpedContabilEditPage extends StatelessWidget {
	GeraSpedContabilEditPage({Key? key}) : super(key: key);
	final geraSpedContabilController = Get.find<GeraSpedContabilController>();

	@override
	Widget build(BuildContext context) {
		return KeyboardListener(
			autofocus: false,
			focusNode: FocusNode(),
			onKeyEvent: (event) {
				if (event.logicalKey == LogicalKeyboardKey.escape) {
					geraSpedContabilController.preventDataLoss();
				}
			},
			child: Scaffold(
				key: geraSpedContabilController.scaffoldKey,
				appBar: AppBar(
					automaticallyImplyLeading: false,
					title: Text('${ geraSpedContabilController.screenTitle } - ${ geraSpedContabilController.isNewRecord ? 'inserting'.tr : 'editing'.tr }',),
					actions: [
            IconButton(
              tooltip: 'Gerar Arquivo',
              icon: const Icon(Icons.cloud_upload, color: Colors.greenAccent),
              color: Colors.yellow,
              onPressed: geraSpedContabilController.gerarArquivo,
            ),
						saveButton(onPressed: geraSpedContabilController.save),
						cancelAndExitButton(onPressed: geraSpedContabilController.preventDataLoss),
					]
				),
				body: SafeArea(
					top: false,
					bottom: false,
					child: Form(
						key: geraSpedContabilController.formKey,
						autovalidateMode: AutovalidateMode.always,
						child: Scrollbar(
							controller: geraSpedContabilController.scrollController,
							child: SingleChildScrollView(
								controller: geraSpedContabilController.scrollController,
								child: BootstrapContainer(
									fluid: true,
									padding: const EdgeInsets.fromLTRB(10.0, 10.0, 10.0, 10.0),
									children: <Widget>[
										const Divider(
											color: Colors.transparent,
										),
										BootstrapRow(
											height: 60,
											children: <BootstrapCol>[
												BootstrapCol(
													sizes: 'col-12 col-md-6',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: InputDecorator(
															decoration: inputDecoration(
																hintText: 'Informe os dados para o campo Periodo Inicial',
																labelText: 'Periodo Inicial',
																usePadding: true,
															),
															isEmpty: false,
															child: DatePickerItem(
																controller: geraSpedContabilController.periodoInicialController,
																firstDate: DateTime.parse('1000-01-01'),
																lastDate: DateTime.parse('5000-01-01'),
																onChanged: (DateTime? value) {
																	geraSpedContabilController.currentModel.periodoInicial = value;
																	geraSpedContabilController.formWasChanged = true;
																},
															),
														),
													),
												),
												BootstrapCol(
													sizes: 'col-12 col-md-6',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: InputDecorator(
															decoration: inputDecoration(
																hintText: 'Informe os dados para o campo Periodo Final',
																labelText: 'Periodo Final',
																usePadding: true,
															),
															isEmpty: false,
															child: DatePickerItem(
																controller: geraSpedContabilController.periodoFinalController,
																firstDate: DateTime.parse('1000-01-01'),
																lastDate: DateTime.parse('5000-01-01'),
																onChanged: (DateTime? value) {
																	geraSpedContabilController.currentModel.periodoFinal = value;
																	geraSpedContabilController.formWasChanged = true;
																},
															),
														),
													),
												),
											],
										),
										const Divider(
											color: Colors.transparent,
										),
										BootstrapRow(
											height: 60,
											children: <BootstrapCol>[
												BootstrapCol(
													sizes: 'col-12 col-md-6',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: CustomDropdownButton(
															controller: geraSpedContabilController.formaEscrituracaoController,
															labelText: 'Forma Escrituracao',
															hintText: 'Informe os dados para o campo Forma Escrituracao',
															items: GeraSpedContabilDomain.formaEscrituracaoListDropdown,
															onChanged: (dynamic newValue) {
																geraSpedContabilController.currentModel.formaEscrituracao = newValue;
																geraSpedContabilController.formWasChanged = true;
															},
														),
													),
												),
												BootstrapCol(
													sizes: 'col-12 col-md-6',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: TextFormField(
															autofocus: true,
															maxLength: 3,
															controller: geraSpedContabilController.versaoLayoutController,
															decoration: inputDecoration(
																hintText: 'Informe os dados para o campo Versao Layout',
																labelText: 'Versao Layout',
																usePadding: true,
															),
															onSaved: (String? value) {},
															onChanged: (text) {
																geraSpedContabilController.currentModel.versaoLayout = text;
																geraSpedContabilController.formWasChanged = true;
															},
														),
													),
												),
											],
										),
										// const Divider(
										// 	color: Colors.transparent,
										// ),
										// BootstrapRow(
										// 	height: 60,
										// 	children: <BootstrapCol>[
										// 		BootstrapCol(
										// 			sizes: 'col-12',
										// 			child: Padding(
										// 				padding: Util.distanceBetweenColumnsLineBreak(context)!,
										// 				child: TextFormField(
										// 					keyboardType: TextInputType.number,
										// 					autofocus: true,
										// 					controller: geraSpedContabilController.idEmpresaController,
										// 					decoration: inputDecoration(
										// 						hintText: 'Informe os dados para o campo Id Empresa',
										// 						labelText: 'Id Empresa',
										// 						usePadding: true,
										// 					),
										// 					onSaved: (String? value) {},
										// 					onChanged: (text) {
										// 						geraSpedContabilController.currentModel.idEmpresa = int.tryParse(text);
										// 						geraSpedContabilController.formWasChanged = true;
										// 					},
										// 				),
										// 			),
										// 		),
										// 	],
										// ),
										// const Divider(
										// 	color: Colors.transparent,
										// ),
										// BootstrapRow(
										// 	height: 60,
										// 	children: <BootstrapCol>[
										// 		BootstrapCol(
										// 			sizes: 'col-12',
										// 			child: Padding(
										// 				padding: Util.distanceBetweenColumnsLineBreak(context)!,
										// 				child: TextFormField(
										// 					keyboardType: TextInputType.number,
										// 					autofocus: true,
										// 					controller: geraSpedContabilController.idContadorController,
										// 					decoration: inputDecoration(
										// 						hintText: 'Informe os dados para o campo Id Contador',
										// 						labelText: 'Id Contador',
										// 						usePadding: true,
										// 					),
										// 					onSaved: (String? value) {},
										// 					onChanged: (text) {
										// 						geraSpedContabilController.currentModel.idContador = int.tryParse(text);
										// 						geraSpedContabilController.formWasChanged = true;
										// 					},
										// 				),
										// 			),
										// 		),
										// 	],
										// ),
										const Divider(
											indent: 10,
											endIndent: 10,
											thickness: 2,
										),
										BootstrapRow(
											height: 60,
											children: <BootstrapCol>[
												BootstrapCol(
													sizes: 'col-12',
													child: Text(
														'field_is_mandatory'.tr,
														style: Theme.of(context).textTheme.bodySmall,
													),
												),
											],
										),
										const SizedBox(height: 10.0),
									],
								),
							),
						),
					),
				),
			),
		);
	}
}
