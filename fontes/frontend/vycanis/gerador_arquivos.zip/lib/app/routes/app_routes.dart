abstract class Routes{
	
	static const splashPage = '/splashPage';
	static const loginPage = '/loginPage';
	static const homePage = '/homePage';
	static const filterPage = '/filterPage';
	static const lookupPage = '/lookupPage';
  static const menuModulesPage = '/menuModulesPage';
		
	static const geraSpedContabilListPage = '/geraSpedContabilListPage'; 
	static const geraSpedContabilEditPage = '/geraSpedContabilEditPage';
	static const geraSpedFiscalListPage = '/geraSpedFiscalListPage'; 
	static const geraSpedFiscalEditPage = '/geraSpedFiscalEditPage';
	static const geraSintegraListPage = '/geraSintegraListPage'; 
	static const geraSintegraEditPage = '/geraSintegraEditPage';
	static const geraEfdContribuicoesListPage = '/geraEfdContribuicoesListPage'; 
	static const geraEfdContribuicoesEditPage = '/geraEfdContribuicoesEditPage';
	static const geraEfdReinfListPage = '/geraEfdReinfListPage'; 
	static const geraEfdReinfEditPage = '/geraEfdReinfEditPage';
	static const geraEsocialListPage = '/geraEsocialListPage'; 
	static const geraEsocialEditPage = '/geraEsocialEditPage';
}