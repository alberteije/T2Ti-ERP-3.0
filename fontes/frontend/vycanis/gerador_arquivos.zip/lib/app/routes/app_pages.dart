import 'package:get/get.dart';
import 'package:gerador_arquivos/app/page/shared_widget/shared_widget_imports.dart';
import 'package:gerador_arquivos/app/routes/app_routes.dart';
import 'package:gerador_arquivos/app/page/login/login_page.dart';
import 'package:gerador_arquivos/app/page/shared_page/splash_screen_page.dart';
import 'package:gerador_arquivos/app/bindings/bindings_imports.dart';
import 'package:gerador_arquivos/app/page/shared_page/shared_page_imports.dart';
import 'package:gerador_arquivos/app/page/page_imports.dart';

class AppPages {
	
	static final pages = [
		GetPage(name: Routes.splashPage, page:()=> const SplashScreenPage()),
		GetPage(name: Routes.loginPage, page:()=> const LoginPage(), binding: LoginBindings()),
		GetPage(name: Routes.homePage, page:()=> HomePage()),
		GetPage(name: Routes.filterPage, page:()=> const FilterPage()),
		GetPage(name: Routes.lookupPage, page:()=> const LookupPage()),
    GetPage(name: Routes.menuModulesPage, page:()=> const MenuModulesPage()),
		
		GetPage(name: Routes.geraSpedContabilListPage, page:()=> const GeraSpedContabilListPage(), binding: GeraSpedContabilBindings()), 
		GetPage(name: Routes.geraSpedContabilEditPage, page:()=> GeraSpedContabilEditPage()),
		GetPage(name: Routes.geraSpedFiscalListPage, page:()=> const GeraSpedFiscalListPage(), binding: GeraSpedFiscalBindings()), 
		GetPage(name: Routes.geraSpedFiscalEditPage, page:()=> GeraSpedFiscalEditPage()),
		GetPage(name: Routes.geraSintegraListPage, page:()=> const GeraSintegraListPage(), binding: GeraSintegraBindings()), 
		GetPage(name: Routes.geraSintegraEditPage, page:()=> GeraSintegraEditPage()),
		GetPage(name: Routes.geraEfdContribuicoesListPage, page:()=> const GeraEfdContribuicoesListPage(), binding: GeraEfdContribuicoesBindings()), 
		GetPage(name: Routes.geraEfdContribuicoesEditPage, page:()=> GeraEfdContribuicoesEditPage()),
		GetPage(name: Routes.geraEfdReinfListPage, page:()=> const GeraEfdReinfListPage(), binding: GeraEfdReinfBindings()), 
		GetPage(name: Routes.geraEfdReinfEditPage, page:()=> GeraEfdReinfEditPage()),
		GetPage(name: Routes.geraEsocialListPage, page:()=> const GeraEsocialListPage(), binding: GeraEsocialBindings()), 
		GetPage(name: Routes.geraEsocialEditPage, page:()=> GeraEsocialEditPage()),
	];
}