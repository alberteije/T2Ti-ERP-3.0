import 'package:get/get.dart';
import 'package:gerador_arquivos/app/controller/gera_sped_fiscal_controller.dart';
import 'package:gerador_arquivos/app/data/provider/api/gera_sped_fiscal_api_provider.dart';
import 'package:gerador_arquivos/app/data/provider/drift/gera_sped_fiscal_drift_provider.dart';
import 'package:gerador_arquivos/app/data/repository/gera_sped_fiscal_repository.dart';

class GeraSpedFiscalBindings implements Binding {
	@override
	List<Bind> dependencies() {
		return [
			Bind.lazyPut<GeraSpedFiscalController>(() => GeraSpedFiscalController(
					repository: GeraSpedFiscalRepository(geraSpedFiscalApiProvider: GeraSpedFiscalApiProvider(), geraSpedFiscalDriftProvider: GeraSpedFiscalDriftProvider()))),
		];
	}
}
