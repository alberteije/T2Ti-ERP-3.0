import 'package:get/get.dart';
import 'package:gerador_arquivos/app/controller/gera_efd_contribuicoes_controller.dart';
import 'package:gerador_arquivos/app/data/provider/api/gera_efd_contribuicoes_api_provider.dart';
import 'package:gerador_arquivos/app/data/provider/drift/gera_efd_contribuicoes_drift_provider.dart';
import 'package:gerador_arquivos/app/data/repository/gera_efd_contribuicoes_repository.dart';

class GeraEfdContribuicoesBindings implements Binding {
	@override
	List<Bind> dependencies() {
		return [
			Bind.lazyPut<GeraEfdContribuicoesController>(() => GeraEfdContribuicoesController(
					repository: GeraEfdContribuicoesRepository(geraEfdContribuicoesApiProvider: GeraEfdContribuicoesApiProvider(), geraEfdContribuicoesDriftProvider: GeraEfdContribuicoesDriftProvider()))),
		];
	}
}
