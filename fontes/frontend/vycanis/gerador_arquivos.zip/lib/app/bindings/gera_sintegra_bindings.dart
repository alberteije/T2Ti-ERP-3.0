import 'package:get/get.dart';
import 'package:gerador_arquivos/app/controller/gera_sintegra_controller.dart';
import 'package:gerador_arquivos/app/data/provider/api/gera_sintegra_api_provider.dart';
import 'package:gerador_arquivos/app/data/provider/drift/gera_sintegra_drift_provider.dart';
import 'package:gerador_arquivos/app/data/repository/gera_sintegra_repository.dart';

class GeraSintegraBindings implements Binding {
	@override
	List<Bind> dependencies() {
		return [
			Bind.lazyPut<GeraSintegraController>(() => GeraSintegraController(
					repository: GeraSintegraRepository(geraSintegraApiProvider: GeraSintegraApiProvider(), geraSintegraDriftProvider: GeraSintegraDriftProvider()))),
		];
	}
}
