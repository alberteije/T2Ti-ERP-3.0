import 'package:get/get.dart';
import 'package:gerador_arquivos/app/controller/gera_efd_reinf_controller.dart';
import 'package:gerador_arquivos/app/data/provider/api/gera_efd_reinf_api_provider.dart';
import 'package:gerador_arquivos/app/data/provider/drift/gera_efd_reinf_drift_provider.dart';
import 'package:gerador_arquivos/app/data/repository/gera_efd_reinf_repository.dart';

class GeraEfdReinfBindings implements Binding {
	@override
	List<Bind> dependencies() {
		return [
			Bind.lazyPut<GeraEfdReinfController>(() => GeraEfdReinfController(
					repository: GeraEfdReinfRepository(geraEfdReinfApiProvider: GeraEfdReinfApiProvider(), geraEfdReinfDriftProvider: GeraEfdReinfDriftProvider()))),
		];
	}
}
