import 'package:get/get.dart';
import 'package:gerador_arquivos/app/controller/gera_esocial_controller.dart';
import 'package:gerador_arquivos/app/data/provider/api/gera_esocial_api_provider.dart';
import 'package:gerador_arquivos/app/data/provider/drift/gera_esocial_drift_provider.dart';
import 'package:gerador_arquivos/app/data/repository/gera_esocial_repository.dart';

class GeraEsocialBindings implements Binding {
	@override
	List<Bind> dependencies() {
		return [
			Bind.lazyPut<GeraEsocialController>(() => GeraEsocialController(
					repository: GeraEsocialRepository(geraEsocialApiProvider: GeraEsocialApiProvider(), geraEsocialDriftProvider: GeraEsocialDriftProvider()))),
		];
	}
}
