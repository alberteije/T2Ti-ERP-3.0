import 'package:get/get.dart';
import 'package:gerador_arquivos/app/controller/gera_sped_contabil_controller.dart';
import 'package:gerador_arquivos/app/data/provider/api/gera_sped_contabil_api_provider.dart';
import 'package:gerador_arquivos/app/data/provider/drift/gera_sped_contabil_drift_provider.dart';
import 'package:gerador_arquivos/app/data/repository/gera_sped_contabil_repository.dart';

class GeraSpedContabilBindings implements Binding {
	@override
	List<Bind> dependencies() {
		return [
			Bind.lazyPut<GeraSpedContabilController>(() => GeraSpedContabilController(
					repository: GeraSpedContabilRepository(geraSpedContabilApiProvider: GeraSpedContabilApiProvider(), geraSpedContabilDriftProvider: GeraSpedContabilDriftProvider()))),
		];
	}
}
