// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'sped_fiscal_dao.dart';

// ignore_for_file: type=lint
mixin _$SpedFiscalDaoMixin on DatabaseAccessor<AppDatabase> {
  $SpedFiscalsTable get spedFiscals => attachedDatabase.spedFiscals;
}
