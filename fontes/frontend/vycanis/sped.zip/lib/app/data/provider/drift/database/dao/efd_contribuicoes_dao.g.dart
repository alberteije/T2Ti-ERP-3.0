// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'efd_contribuicoes_dao.dart';

// ignore_for_file: type=lint
mixin _$EfdContribuicoesDaoMixin on DatabaseAccessor<AppDatabase> {
  $EfdContribuicoessTable get efdContribuicoess =>
      attachedDatabase.efdContribuicoess;
}
