// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'database.dart';

// ignore_for_file: type=lint
class $SpedContabilsTable extends SpedContabils
    with TableInfo<$SpedContabilsTable, SpedContabil> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $SpedContabilsTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
      'id', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _dataEmissaoMeta =
      const VerificationMeta('dataEmissao');
  @override
  late final GeneratedColumn<DateTime> dataEmissao = GeneratedColumn<DateTime>(
      'data_emissao', aliasedName, true,
      type: DriftSqlType.dateTime, requiredDuringInsert: false);
  static const VerificationMeta _periodoInicialMeta =
      const VerificationMeta('periodoInicial');
  @override
  late final GeneratedColumn<DateTime> periodoInicial =
      GeneratedColumn<DateTime>('periodo_inicial', aliasedName, true,
          type: DriftSqlType.dateTime, requiredDuringInsert: false);
  static const VerificationMeta _periodoFinalMeta =
      const VerificationMeta('periodoFinal');
  @override
  late final GeneratedColumn<DateTime> periodoFinal = GeneratedColumn<DateTime>(
      'periodo_final', aliasedName, true,
      type: DriftSqlType.dateTime, requiredDuringInsert: false);
  static const VerificationMeta _formaEscrituracaoMeta =
      const VerificationMeta('formaEscrituracao');
  @override
  late final GeneratedColumn<String> formaEscrituracao =
      GeneratedColumn<String>('forma_escrituracao', aliasedName, true,
          additionalChecks: GeneratedColumn.checkTextLength(
              minTextLength: 0, maxTextLength: 1),
          type: DriftSqlType.string,
          requiredDuringInsert: false);
  static const VerificationMeta _versaoLayoutMeta =
      const VerificationMeta('versaoLayout');
  @override
  late final GeneratedColumn<String> versaoLayout = GeneratedColumn<String>(
      'versao_layout', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 100),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  @override
  List<GeneratedColumn> get $columns => [
        id,
        dataEmissao,
        periodoInicial,
        periodoFinal,
        formaEscrituracao,
        versaoLayout
      ];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'sped_contabil';
  @override
  VerificationContext validateIntegrity(Insertable<SpedContabil> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('data_emissao')) {
      context.handle(
          _dataEmissaoMeta,
          dataEmissao.isAcceptableOrUnknown(
              data['data_emissao']!, _dataEmissaoMeta));
    }
    if (data.containsKey('periodo_inicial')) {
      context.handle(
          _periodoInicialMeta,
          periodoInicial.isAcceptableOrUnknown(
              data['periodo_inicial']!, _periodoInicialMeta));
    }
    if (data.containsKey('periodo_final')) {
      context.handle(
          _periodoFinalMeta,
          periodoFinal.isAcceptableOrUnknown(
              data['periodo_final']!, _periodoFinalMeta));
    }
    if (data.containsKey('forma_escrituracao')) {
      context.handle(
          _formaEscrituracaoMeta,
          formaEscrituracao.isAcceptableOrUnknown(
              data['forma_escrituracao']!, _formaEscrituracaoMeta));
    }
    if (data.containsKey('versao_layout')) {
      context.handle(
          _versaoLayoutMeta,
          versaoLayout.isAcceptableOrUnknown(
              data['versao_layout']!, _versaoLayoutMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  SpedContabil map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return SpedContabil(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id']),
      dataEmissao: attachedDatabase.typeMapping
          .read(DriftSqlType.dateTime, data['${effectivePrefix}data_emissao']),
      periodoInicial: attachedDatabase.typeMapping.read(
          DriftSqlType.dateTime, data['${effectivePrefix}periodo_inicial']),
      periodoFinal: attachedDatabase.typeMapping
          .read(DriftSqlType.dateTime, data['${effectivePrefix}periodo_final']),
      formaEscrituracao: attachedDatabase.typeMapping.read(
          DriftSqlType.string, data['${effectivePrefix}forma_escrituracao']),
      versaoLayout: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}versao_layout']),
    );
  }

  @override
  $SpedContabilsTable createAlias(String alias) {
    return $SpedContabilsTable(attachedDatabase, alias);
  }
}

class SpedContabil extends DataClass implements Insertable<SpedContabil> {
  final int? id;
  final DateTime? dataEmissao;
  final DateTime? periodoInicial;
  final DateTime? periodoFinal;
  final String? formaEscrituracao;
  final String? versaoLayout;
  const SpedContabil(
      {this.id,
      this.dataEmissao,
      this.periodoInicial,
      this.periodoFinal,
      this.formaEscrituracao,
      this.versaoLayout});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || dataEmissao != null) {
      map['data_emissao'] = Variable<DateTime>(dataEmissao);
    }
    if (!nullToAbsent || periodoInicial != null) {
      map['periodo_inicial'] = Variable<DateTime>(periodoInicial);
    }
    if (!nullToAbsent || periodoFinal != null) {
      map['periodo_final'] = Variable<DateTime>(periodoFinal);
    }
    if (!nullToAbsent || formaEscrituracao != null) {
      map['forma_escrituracao'] = Variable<String>(formaEscrituracao);
    }
    if (!nullToAbsent || versaoLayout != null) {
      map['versao_layout'] = Variable<String>(versaoLayout);
    }
    return map;
  }

  factory SpedContabil.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return SpedContabil(
      id: serializer.fromJson<int?>(json['id']),
      dataEmissao: serializer.fromJson<DateTime?>(json['dataEmissao']),
      periodoInicial: serializer.fromJson<DateTime?>(json['periodoInicial']),
      periodoFinal: serializer.fromJson<DateTime?>(json['periodoFinal']),
      formaEscrituracao:
          serializer.fromJson<String?>(json['formaEscrituracao']),
      versaoLayout: serializer.fromJson<String?>(json['versaoLayout']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'dataEmissao': serializer.toJson<DateTime?>(dataEmissao),
      'periodoInicial': serializer.toJson<DateTime?>(periodoInicial),
      'periodoFinal': serializer.toJson<DateTime?>(periodoFinal),
      'formaEscrituracao': serializer.toJson<String?>(formaEscrituracao),
      'versaoLayout': serializer.toJson<String?>(versaoLayout),
    };
  }

  SpedContabil copyWith(
          {Value<int?> id = const Value.absent(),
          Value<DateTime?> dataEmissao = const Value.absent(),
          Value<DateTime?> periodoInicial = const Value.absent(),
          Value<DateTime?> periodoFinal = const Value.absent(),
          Value<String?> formaEscrituracao = const Value.absent(),
          Value<String?> versaoLayout = const Value.absent()}) =>
      SpedContabil(
        id: id.present ? id.value : this.id,
        dataEmissao: dataEmissao.present ? dataEmissao.value : this.dataEmissao,
        periodoInicial:
            periodoInicial.present ? periodoInicial.value : this.periodoInicial,
        periodoFinal:
            periodoFinal.present ? periodoFinal.value : this.periodoFinal,
        formaEscrituracao: formaEscrituracao.present
            ? formaEscrituracao.value
            : this.formaEscrituracao,
        versaoLayout:
            versaoLayout.present ? versaoLayout.value : this.versaoLayout,
      );
  SpedContabil copyWithCompanion(SpedContabilsCompanion data) {
    return SpedContabil(
      id: data.id.present ? data.id.value : this.id,
      dataEmissao:
          data.dataEmissao.present ? data.dataEmissao.value : this.dataEmissao,
      periodoInicial: data.periodoInicial.present
          ? data.periodoInicial.value
          : this.periodoInicial,
      periodoFinal: data.periodoFinal.present
          ? data.periodoFinal.value
          : this.periodoFinal,
      formaEscrituracao: data.formaEscrituracao.present
          ? data.formaEscrituracao.value
          : this.formaEscrituracao,
      versaoLayout: data.versaoLayout.present
          ? data.versaoLayout.value
          : this.versaoLayout,
    );
  }

  @override
  String toString() {
    return (StringBuffer('SpedContabil(')
          ..write('id: $id, ')
          ..write('dataEmissao: $dataEmissao, ')
          ..write('periodoInicial: $periodoInicial, ')
          ..write('periodoFinal: $periodoFinal, ')
          ..write('formaEscrituracao: $formaEscrituracao, ')
          ..write('versaoLayout: $versaoLayout')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(id, dataEmissao, periodoInicial, periodoFinal,
      formaEscrituracao, versaoLayout);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is SpedContabil &&
          other.id == this.id &&
          other.dataEmissao == this.dataEmissao &&
          other.periodoInicial == this.periodoInicial &&
          other.periodoFinal == this.periodoFinal &&
          other.formaEscrituracao == this.formaEscrituracao &&
          other.versaoLayout == this.versaoLayout);
}

class SpedContabilsCompanion extends UpdateCompanion<SpedContabil> {
  final Value<int?> id;
  final Value<DateTime?> dataEmissao;
  final Value<DateTime?> periodoInicial;
  final Value<DateTime?> periodoFinal;
  final Value<String?> formaEscrituracao;
  final Value<String?> versaoLayout;
  const SpedContabilsCompanion({
    this.id = const Value.absent(),
    this.dataEmissao = const Value.absent(),
    this.periodoInicial = const Value.absent(),
    this.periodoFinal = const Value.absent(),
    this.formaEscrituracao = const Value.absent(),
    this.versaoLayout = const Value.absent(),
  });
  SpedContabilsCompanion.insert({
    this.id = const Value.absent(),
    this.dataEmissao = const Value.absent(),
    this.periodoInicial = const Value.absent(),
    this.periodoFinal = const Value.absent(),
    this.formaEscrituracao = const Value.absent(),
    this.versaoLayout = const Value.absent(),
  });
  static Insertable<SpedContabil> custom({
    Expression<int>? id,
    Expression<DateTime>? dataEmissao,
    Expression<DateTime>? periodoInicial,
    Expression<DateTime>? periodoFinal,
    Expression<String>? formaEscrituracao,
    Expression<String>? versaoLayout,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (dataEmissao != null) 'data_emissao': dataEmissao,
      if (periodoInicial != null) 'periodo_inicial': periodoInicial,
      if (periodoFinal != null) 'periodo_final': periodoFinal,
      if (formaEscrituracao != null) 'forma_escrituracao': formaEscrituracao,
      if (versaoLayout != null) 'versao_layout': versaoLayout,
    });
  }

  SpedContabilsCompanion copyWith(
      {Value<int?>? id,
      Value<DateTime?>? dataEmissao,
      Value<DateTime?>? periodoInicial,
      Value<DateTime?>? periodoFinal,
      Value<String?>? formaEscrituracao,
      Value<String?>? versaoLayout}) {
    return SpedContabilsCompanion(
      id: id ?? this.id,
      dataEmissao: dataEmissao ?? this.dataEmissao,
      periodoInicial: periodoInicial ?? this.periodoInicial,
      periodoFinal: periodoFinal ?? this.periodoFinal,
      formaEscrituracao: formaEscrituracao ?? this.formaEscrituracao,
      versaoLayout: versaoLayout ?? this.versaoLayout,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (dataEmissao.present) {
      map['data_emissao'] = Variable<DateTime>(dataEmissao.value);
    }
    if (periodoInicial.present) {
      map['periodo_inicial'] = Variable<DateTime>(periodoInicial.value);
    }
    if (periodoFinal.present) {
      map['periodo_final'] = Variable<DateTime>(periodoFinal.value);
    }
    if (formaEscrituracao.present) {
      map['forma_escrituracao'] = Variable<String>(formaEscrituracao.value);
    }
    if (versaoLayout.present) {
      map['versao_layout'] = Variable<String>(versaoLayout.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('SpedContabilsCompanion(')
          ..write('id: $id, ')
          ..write('dataEmissao: $dataEmissao, ')
          ..write('periodoInicial: $periodoInicial, ')
          ..write('periodoFinal: $periodoFinal, ')
          ..write('formaEscrituracao: $formaEscrituracao, ')
          ..write('versaoLayout: $versaoLayout')
          ..write(')'))
        .toString();
  }
}

class $ViewControleAcessosTable extends ViewControleAcessos
    with TableInfo<$ViewControleAcessosTable, ViewControleAcesso> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $ViewControleAcessosTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
      'id', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _idPessoaMeta =
      const VerificationMeta('idPessoa');
  @override
  late final GeneratedColumn<int> idPessoa = GeneratedColumn<int>(
      'id_pessoa', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _pessoaNomeMeta =
      const VerificationMeta('pessoaNome');
  @override
  late final GeneratedColumn<String> pessoaNome = GeneratedColumn<String>(
      'pessoa_nome', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 450),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _idColaboradorMeta =
      const VerificationMeta('idColaborador');
  @override
  late final GeneratedColumn<int> idColaborador = GeneratedColumn<int>(
      'id_colaborador', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _idUsuarioMeta =
      const VerificationMeta('idUsuario');
  @override
  late final GeneratedColumn<int> idUsuario = GeneratedColumn<int>(
      'id_usuario', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _administradorMeta =
      const VerificationMeta('administrador');
  @override
  late final GeneratedColumn<String> administrador = GeneratedColumn<String>(
      'administrador', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 3),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _idPapelMeta =
      const VerificationMeta('idPapel');
  @override
  late final GeneratedColumn<int> idPapel = GeneratedColumn<int>(
      'id_papel', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _papelNomeMeta =
      const VerificationMeta('papelNome');
  @override
  late final GeneratedColumn<String> papelNome = GeneratedColumn<String>(
      'papel_nome', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 300),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _papelDescricaoMeta =
      const VerificationMeta('papelDescricao');
  @override
  late final GeneratedColumn<String> papelDescricao = GeneratedColumn<String>(
      'papel_descricao', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 750),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _idFuncaoMeta =
      const VerificationMeta('idFuncao');
  @override
  late final GeneratedColumn<int> idFuncao = GeneratedColumn<int>(
      'id_funcao', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _funcaoNomeMeta =
      const VerificationMeta('funcaoNome');
  @override
  late final GeneratedColumn<String> funcaoNome = GeneratedColumn<String>(
      'funcao_nome', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 300),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _funcaoDescricaoMeta =
      const VerificationMeta('funcaoDescricao');
  @override
  late final GeneratedColumn<String> funcaoDescricao = GeneratedColumn<String>(
      'funcao_descricao', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 750),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _idPapelFuncaoMeta =
      const VerificationMeta('idPapelFuncao');
  @override
  late final GeneratedColumn<int> idPapelFuncao = GeneratedColumn<int>(
      'id_papel_funcao', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _habilitadoMeta =
      const VerificationMeta('habilitado');
  @override
  late final GeneratedColumn<String> habilitado = GeneratedColumn<String>(
      'habilitado', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 3),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _podeInserirMeta =
      const VerificationMeta('podeInserir');
  @override
  late final GeneratedColumn<String> podeInserir = GeneratedColumn<String>(
      'pode_inserir', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 3),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _podeAlterarMeta =
      const VerificationMeta('podeAlterar');
  @override
  late final GeneratedColumn<String> podeAlterar = GeneratedColumn<String>(
      'pode_alterar', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 3),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _podeExcluirMeta =
      const VerificationMeta('podeExcluir');
  @override
  late final GeneratedColumn<String> podeExcluir = GeneratedColumn<String>(
      'pode_excluir', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 3),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  @override
  List<GeneratedColumn> get $columns => [
        id,
        idPessoa,
        pessoaNome,
        idColaborador,
        idUsuario,
        administrador,
        idPapel,
        papelNome,
        papelDescricao,
        idFuncao,
        funcaoNome,
        funcaoDescricao,
        idPapelFuncao,
        habilitado,
        podeInserir,
        podeAlterar,
        podeExcluir
      ];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'view_controle_acesso';
  @override
  VerificationContext validateIntegrity(Insertable<ViewControleAcesso> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('id_pessoa')) {
      context.handle(_idPessoaMeta,
          idPessoa.isAcceptableOrUnknown(data['id_pessoa']!, _idPessoaMeta));
    }
    if (data.containsKey('pessoa_nome')) {
      context.handle(
          _pessoaNomeMeta,
          pessoaNome.isAcceptableOrUnknown(
              data['pessoa_nome']!, _pessoaNomeMeta));
    }
    if (data.containsKey('id_colaborador')) {
      context.handle(
          _idColaboradorMeta,
          idColaborador.isAcceptableOrUnknown(
              data['id_colaborador']!, _idColaboradorMeta));
    }
    if (data.containsKey('id_usuario')) {
      context.handle(_idUsuarioMeta,
          idUsuario.isAcceptableOrUnknown(data['id_usuario']!, _idUsuarioMeta));
    }
    if (data.containsKey('administrador')) {
      context.handle(
          _administradorMeta,
          administrador.isAcceptableOrUnknown(
              data['administrador']!, _administradorMeta));
    }
    if (data.containsKey('id_papel')) {
      context.handle(_idPapelMeta,
          idPapel.isAcceptableOrUnknown(data['id_papel']!, _idPapelMeta));
    }
    if (data.containsKey('papel_nome')) {
      context.handle(_papelNomeMeta,
          papelNome.isAcceptableOrUnknown(data['papel_nome']!, _papelNomeMeta));
    }
    if (data.containsKey('papel_descricao')) {
      context.handle(
          _papelDescricaoMeta,
          papelDescricao.isAcceptableOrUnknown(
              data['papel_descricao']!, _papelDescricaoMeta));
    }
    if (data.containsKey('id_funcao')) {
      context.handle(_idFuncaoMeta,
          idFuncao.isAcceptableOrUnknown(data['id_funcao']!, _idFuncaoMeta));
    }
    if (data.containsKey('funcao_nome')) {
      context.handle(
          _funcaoNomeMeta,
          funcaoNome.isAcceptableOrUnknown(
              data['funcao_nome']!, _funcaoNomeMeta));
    }
    if (data.containsKey('funcao_descricao')) {
      context.handle(
          _funcaoDescricaoMeta,
          funcaoDescricao.isAcceptableOrUnknown(
              data['funcao_descricao']!, _funcaoDescricaoMeta));
    }
    if (data.containsKey('id_papel_funcao')) {
      context.handle(
          _idPapelFuncaoMeta,
          idPapelFuncao.isAcceptableOrUnknown(
              data['id_papel_funcao']!, _idPapelFuncaoMeta));
    }
    if (data.containsKey('habilitado')) {
      context.handle(
          _habilitadoMeta,
          habilitado.isAcceptableOrUnknown(
              data['habilitado']!, _habilitadoMeta));
    }
    if (data.containsKey('pode_inserir')) {
      context.handle(
          _podeInserirMeta,
          podeInserir.isAcceptableOrUnknown(
              data['pode_inserir']!, _podeInserirMeta));
    }
    if (data.containsKey('pode_alterar')) {
      context.handle(
          _podeAlterarMeta,
          podeAlterar.isAcceptableOrUnknown(
              data['pode_alterar']!, _podeAlterarMeta));
    }
    if (data.containsKey('pode_excluir')) {
      context.handle(
          _podeExcluirMeta,
          podeExcluir.isAcceptableOrUnknown(
              data['pode_excluir']!, _podeExcluirMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  ViewControleAcesso map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return ViewControleAcesso(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id']),
      idPessoa: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id_pessoa']),
      pessoaNome: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}pessoa_nome']),
      idColaborador: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id_colaborador']),
      idUsuario: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id_usuario']),
      administrador: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}administrador']),
      idPapel: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id_papel']),
      papelNome: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}papel_nome']),
      papelDescricao: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}papel_descricao']),
      idFuncao: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id_funcao']),
      funcaoNome: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}funcao_nome']),
      funcaoDescricao: attachedDatabase.typeMapping.read(
          DriftSqlType.string, data['${effectivePrefix}funcao_descricao']),
      idPapelFuncao: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id_papel_funcao']),
      habilitado: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}habilitado']),
      podeInserir: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}pode_inserir']),
      podeAlterar: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}pode_alterar']),
      podeExcluir: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}pode_excluir']),
    );
  }

  @override
  $ViewControleAcessosTable createAlias(String alias) {
    return $ViewControleAcessosTable(attachedDatabase, alias);
  }
}

class ViewControleAcesso extends DataClass
    implements Insertable<ViewControleAcesso> {
  final int? id;
  final int? idPessoa;
  final String? pessoaNome;
  final int? idColaborador;
  final int? idUsuario;
  final String? administrador;
  final int? idPapel;
  final String? papelNome;
  final String? papelDescricao;
  final int? idFuncao;
  final String? funcaoNome;
  final String? funcaoDescricao;
  final int? idPapelFuncao;
  final String? habilitado;
  final String? podeInserir;
  final String? podeAlterar;
  final String? podeExcluir;
  const ViewControleAcesso(
      {this.id,
      this.idPessoa,
      this.pessoaNome,
      this.idColaborador,
      this.idUsuario,
      this.administrador,
      this.idPapel,
      this.papelNome,
      this.papelDescricao,
      this.idFuncao,
      this.funcaoNome,
      this.funcaoDescricao,
      this.idPapelFuncao,
      this.habilitado,
      this.podeInserir,
      this.podeAlterar,
      this.podeExcluir});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || idPessoa != null) {
      map['id_pessoa'] = Variable<int>(idPessoa);
    }
    if (!nullToAbsent || pessoaNome != null) {
      map['pessoa_nome'] = Variable<String>(pessoaNome);
    }
    if (!nullToAbsent || idColaborador != null) {
      map['id_colaborador'] = Variable<int>(idColaborador);
    }
    if (!nullToAbsent || idUsuario != null) {
      map['id_usuario'] = Variable<int>(idUsuario);
    }
    if (!nullToAbsent || administrador != null) {
      map['administrador'] = Variable<String>(administrador);
    }
    if (!nullToAbsent || idPapel != null) {
      map['id_papel'] = Variable<int>(idPapel);
    }
    if (!nullToAbsent || papelNome != null) {
      map['papel_nome'] = Variable<String>(papelNome);
    }
    if (!nullToAbsent || papelDescricao != null) {
      map['papel_descricao'] = Variable<String>(papelDescricao);
    }
    if (!nullToAbsent || idFuncao != null) {
      map['id_funcao'] = Variable<int>(idFuncao);
    }
    if (!nullToAbsent || funcaoNome != null) {
      map['funcao_nome'] = Variable<String>(funcaoNome);
    }
    if (!nullToAbsent || funcaoDescricao != null) {
      map['funcao_descricao'] = Variable<String>(funcaoDescricao);
    }
    if (!nullToAbsent || idPapelFuncao != null) {
      map['id_papel_funcao'] = Variable<int>(idPapelFuncao);
    }
    if (!nullToAbsent || habilitado != null) {
      map['habilitado'] = Variable<String>(habilitado);
    }
    if (!nullToAbsent || podeInserir != null) {
      map['pode_inserir'] = Variable<String>(podeInserir);
    }
    if (!nullToAbsent || podeAlterar != null) {
      map['pode_alterar'] = Variable<String>(podeAlterar);
    }
    if (!nullToAbsent || podeExcluir != null) {
      map['pode_excluir'] = Variable<String>(podeExcluir);
    }
    return map;
  }

  factory ViewControleAcesso.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return ViewControleAcesso(
      id: serializer.fromJson<int?>(json['id']),
      idPessoa: serializer.fromJson<int?>(json['idPessoa']),
      pessoaNome: serializer.fromJson<String?>(json['pessoaNome']),
      idColaborador: serializer.fromJson<int?>(json['idColaborador']),
      idUsuario: serializer.fromJson<int?>(json['idUsuario']),
      administrador: serializer.fromJson<String?>(json['administrador']),
      idPapel: serializer.fromJson<int?>(json['idPapel']),
      papelNome: serializer.fromJson<String?>(json['papelNome']),
      papelDescricao: serializer.fromJson<String?>(json['papelDescricao']),
      idFuncao: serializer.fromJson<int?>(json['idFuncao']),
      funcaoNome: serializer.fromJson<String?>(json['funcaoNome']),
      funcaoDescricao: serializer.fromJson<String?>(json['funcaoDescricao']),
      idPapelFuncao: serializer.fromJson<int?>(json['idPapelFuncao']),
      habilitado: serializer.fromJson<String?>(json['habilitado']),
      podeInserir: serializer.fromJson<String?>(json['podeInserir']),
      podeAlterar: serializer.fromJson<String?>(json['podeAlterar']),
      podeExcluir: serializer.fromJson<String?>(json['podeExcluir']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'idPessoa': serializer.toJson<int?>(idPessoa),
      'pessoaNome': serializer.toJson<String?>(pessoaNome),
      'idColaborador': serializer.toJson<int?>(idColaborador),
      'idUsuario': serializer.toJson<int?>(idUsuario),
      'administrador': serializer.toJson<String?>(administrador),
      'idPapel': serializer.toJson<int?>(idPapel),
      'papelNome': serializer.toJson<String?>(papelNome),
      'papelDescricao': serializer.toJson<String?>(papelDescricao),
      'idFuncao': serializer.toJson<int?>(idFuncao),
      'funcaoNome': serializer.toJson<String?>(funcaoNome),
      'funcaoDescricao': serializer.toJson<String?>(funcaoDescricao),
      'idPapelFuncao': serializer.toJson<int?>(idPapelFuncao),
      'habilitado': serializer.toJson<String?>(habilitado),
      'podeInserir': serializer.toJson<String?>(podeInserir),
      'podeAlterar': serializer.toJson<String?>(podeAlterar),
      'podeExcluir': serializer.toJson<String?>(podeExcluir),
    };
  }

  ViewControleAcesso copyWith(
          {Value<int?> id = const Value.absent(),
          Value<int?> idPessoa = const Value.absent(),
          Value<String?> pessoaNome = const Value.absent(),
          Value<int?> idColaborador = const Value.absent(),
          Value<int?> idUsuario = const Value.absent(),
          Value<String?> administrador = const Value.absent(),
          Value<int?> idPapel = const Value.absent(),
          Value<String?> papelNome = const Value.absent(),
          Value<String?> papelDescricao = const Value.absent(),
          Value<int?> idFuncao = const Value.absent(),
          Value<String?> funcaoNome = const Value.absent(),
          Value<String?> funcaoDescricao = const Value.absent(),
          Value<int?> idPapelFuncao = const Value.absent(),
          Value<String?> habilitado = const Value.absent(),
          Value<String?> podeInserir = const Value.absent(),
          Value<String?> podeAlterar = const Value.absent(),
          Value<String?> podeExcluir = const Value.absent()}) =>
      ViewControleAcesso(
        id: id.present ? id.value : this.id,
        idPessoa: idPessoa.present ? idPessoa.value : this.idPessoa,
        pessoaNome: pessoaNome.present ? pessoaNome.value : this.pessoaNome,
        idColaborador:
            idColaborador.present ? idColaborador.value : this.idColaborador,
        idUsuario: idUsuario.present ? idUsuario.value : this.idUsuario,
        administrador:
            administrador.present ? administrador.value : this.administrador,
        idPapel: idPapel.present ? idPapel.value : this.idPapel,
        papelNome: papelNome.present ? papelNome.value : this.papelNome,
        papelDescricao:
            papelDescricao.present ? papelDescricao.value : this.papelDescricao,
        idFuncao: idFuncao.present ? idFuncao.value : this.idFuncao,
        funcaoNome: funcaoNome.present ? funcaoNome.value : this.funcaoNome,
        funcaoDescricao: funcaoDescricao.present
            ? funcaoDescricao.value
            : this.funcaoDescricao,
        idPapelFuncao:
            idPapelFuncao.present ? idPapelFuncao.value : this.idPapelFuncao,
        habilitado: habilitado.present ? habilitado.value : this.habilitado,
        podeInserir: podeInserir.present ? podeInserir.value : this.podeInserir,
        podeAlterar: podeAlterar.present ? podeAlterar.value : this.podeAlterar,
        podeExcluir: podeExcluir.present ? podeExcluir.value : this.podeExcluir,
      );
  ViewControleAcesso copyWithCompanion(ViewControleAcessosCompanion data) {
    return ViewControleAcesso(
      id: data.id.present ? data.id.value : this.id,
      idPessoa: data.idPessoa.present ? data.idPessoa.value : this.idPessoa,
      pessoaNome:
          data.pessoaNome.present ? data.pessoaNome.value : this.pessoaNome,
      idColaborador: data.idColaborador.present
          ? data.idColaborador.value
          : this.idColaborador,
      idUsuario: data.idUsuario.present ? data.idUsuario.value : this.idUsuario,
      administrador: data.administrador.present
          ? data.administrador.value
          : this.administrador,
      idPapel: data.idPapel.present ? data.idPapel.value : this.idPapel,
      papelNome: data.papelNome.present ? data.papelNome.value : this.papelNome,
      papelDescricao: data.papelDescricao.present
          ? data.papelDescricao.value
          : this.papelDescricao,
      idFuncao: data.idFuncao.present ? data.idFuncao.value : this.idFuncao,
      funcaoNome:
          data.funcaoNome.present ? data.funcaoNome.value : this.funcaoNome,
      funcaoDescricao: data.funcaoDescricao.present
          ? data.funcaoDescricao.value
          : this.funcaoDescricao,
      idPapelFuncao: data.idPapelFuncao.present
          ? data.idPapelFuncao.value
          : this.idPapelFuncao,
      habilitado:
          data.habilitado.present ? data.habilitado.value : this.habilitado,
      podeInserir:
          data.podeInserir.present ? data.podeInserir.value : this.podeInserir,
      podeAlterar:
          data.podeAlterar.present ? data.podeAlterar.value : this.podeAlterar,
      podeExcluir:
          data.podeExcluir.present ? data.podeExcluir.value : this.podeExcluir,
    );
  }

  @override
  String toString() {
    return (StringBuffer('ViewControleAcesso(')
          ..write('id: $id, ')
          ..write('idPessoa: $idPessoa, ')
          ..write('pessoaNome: $pessoaNome, ')
          ..write('idColaborador: $idColaborador, ')
          ..write('idUsuario: $idUsuario, ')
          ..write('administrador: $administrador, ')
          ..write('idPapel: $idPapel, ')
          ..write('papelNome: $papelNome, ')
          ..write('papelDescricao: $papelDescricao, ')
          ..write('idFuncao: $idFuncao, ')
          ..write('funcaoNome: $funcaoNome, ')
          ..write('funcaoDescricao: $funcaoDescricao, ')
          ..write('idPapelFuncao: $idPapelFuncao, ')
          ..write('habilitado: $habilitado, ')
          ..write('podeInserir: $podeInserir, ')
          ..write('podeAlterar: $podeAlterar, ')
          ..write('podeExcluir: $podeExcluir')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(
      id,
      idPessoa,
      pessoaNome,
      idColaborador,
      idUsuario,
      administrador,
      idPapel,
      papelNome,
      papelDescricao,
      idFuncao,
      funcaoNome,
      funcaoDescricao,
      idPapelFuncao,
      habilitado,
      podeInserir,
      podeAlterar,
      podeExcluir);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is ViewControleAcesso &&
          other.id == this.id &&
          other.idPessoa == this.idPessoa &&
          other.pessoaNome == this.pessoaNome &&
          other.idColaborador == this.idColaborador &&
          other.idUsuario == this.idUsuario &&
          other.administrador == this.administrador &&
          other.idPapel == this.idPapel &&
          other.papelNome == this.papelNome &&
          other.papelDescricao == this.papelDescricao &&
          other.idFuncao == this.idFuncao &&
          other.funcaoNome == this.funcaoNome &&
          other.funcaoDescricao == this.funcaoDescricao &&
          other.idPapelFuncao == this.idPapelFuncao &&
          other.habilitado == this.habilitado &&
          other.podeInserir == this.podeInserir &&
          other.podeAlterar == this.podeAlterar &&
          other.podeExcluir == this.podeExcluir);
}

class ViewControleAcessosCompanion extends UpdateCompanion<ViewControleAcesso> {
  final Value<int?> id;
  final Value<int?> idPessoa;
  final Value<String?> pessoaNome;
  final Value<int?> idColaborador;
  final Value<int?> idUsuario;
  final Value<String?> administrador;
  final Value<int?> idPapel;
  final Value<String?> papelNome;
  final Value<String?> papelDescricao;
  final Value<int?> idFuncao;
  final Value<String?> funcaoNome;
  final Value<String?> funcaoDescricao;
  final Value<int?> idPapelFuncao;
  final Value<String?> habilitado;
  final Value<String?> podeInserir;
  final Value<String?> podeAlterar;
  final Value<String?> podeExcluir;
  const ViewControleAcessosCompanion({
    this.id = const Value.absent(),
    this.idPessoa = const Value.absent(),
    this.pessoaNome = const Value.absent(),
    this.idColaborador = const Value.absent(),
    this.idUsuario = const Value.absent(),
    this.administrador = const Value.absent(),
    this.idPapel = const Value.absent(),
    this.papelNome = const Value.absent(),
    this.papelDescricao = const Value.absent(),
    this.idFuncao = const Value.absent(),
    this.funcaoNome = const Value.absent(),
    this.funcaoDescricao = const Value.absent(),
    this.idPapelFuncao = const Value.absent(),
    this.habilitado = const Value.absent(),
    this.podeInserir = const Value.absent(),
    this.podeAlterar = const Value.absent(),
    this.podeExcluir = const Value.absent(),
  });
  ViewControleAcessosCompanion.insert({
    this.id = const Value.absent(),
    this.idPessoa = const Value.absent(),
    this.pessoaNome = const Value.absent(),
    this.idColaborador = const Value.absent(),
    this.idUsuario = const Value.absent(),
    this.administrador = const Value.absent(),
    this.idPapel = const Value.absent(),
    this.papelNome = const Value.absent(),
    this.papelDescricao = const Value.absent(),
    this.idFuncao = const Value.absent(),
    this.funcaoNome = const Value.absent(),
    this.funcaoDescricao = const Value.absent(),
    this.idPapelFuncao = const Value.absent(),
    this.habilitado = const Value.absent(),
    this.podeInserir = const Value.absent(),
    this.podeAlterar = const Value.absent(),
    this.podeExcluir = const Value.absent(),
  });
  static Insertable<ViewControleAcesso> custom({
    Expression<int>? id,
    Expression<int>? idPessoa,
    Expression<String>? pessoaNome,
    Expression<int>? idColaborador,
    Expression<int>? idUsuario,
    Expression<String>? administrador,
    Expression<int>? idPapel,
    Expression<String>? papelNome,
    Expression<String>? papelDescricao,
    Expression<int>? idFuncao,
    Expression<String>? funcaoNome,
    Expression<String>? funcaoDescricao,
    Expression<int>? idPapelFuncao,
    Expression<String>? habilitado,
    Expression<String>? podeInserir,
    Expression<String>? podeAlterar,
    Expression<String>? podeExcluir,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (idPessoa != null) 'id_pessoa': idPessoa,
      if (pessoaNome != null) 'pessoa_nome': pessoaNome,
      if (idColaborador != null) 'id_colaborador': idColaborador,
      if (idUsuario != null) 'id_usuario': idUsuario,
      if (administrador != null) 'administrador': administrador,
      if (idPapel != null) 'id_papel': idPapel,
      if (papelNome != null) 'papel_nome': papelNome,
      if (papelDescricao != null) 'papel_descricao': papelDescricao,
      if (idFuncao != null) 'id_funcao': idFuncao,
      if (funcaoNome != null) 'funcao_nome': funcaoNome,
      if (funcaoDescricao != null) 'funcao_descricao': funcaoDescricao,
      if (idPapelFuncao != null) 'id_papel_funcao': idPapelFuncao,
      if (habilitado != null) 'habilitado': habilitado,
      if (podeInserir != null) 'pode_inserir': podeInserir,
      if (podeAlterar != null) 'pode_alterar': podeAlterar,
      if (podeExcluir != null) 'pode_excluir': podeExcluir,
    });
  }

  ViewControleAcessosCompanion copyWith(
      {Value<int?>? id,
      Value<int?>? idPessoa,
      Value<String?>? pessoaNome,
      Value<int?>? idColaborador,
      Value<int?>? idUsuario,
      Value<String?>? administrador,
      Value<int?>? idPapel,
      Value<String?>? papelNome,
      Value<String?>? papelDescricao,
      Value<int?>? idFuncao,
      Value<String?>? funcaoNome,
      Value<String?>? funcaoDescricao,
      Value<int?>? idPapelFuncao,
      Value<String?>? habilitado,
      Value<String?>? podeInserir,
      Value<String?>? podeAlterar,
      Value<String?>? podeExcluir}) {
    return ViewControleAcessosCompanion(
      id: id ?? this.id,
      idPessoa: idPessoa ?? this.idPessoa,
      pessoaNome: pessoaNome ?? this.pessoaNome,
      idColaborador: idColaborador ?? this.idColaborador,
      idUsuario: idUsuario ?? this.idUsuario,
      administrador: administrador ?? this.administrador,
      idPapel: idPapel ?? this.idPapel,
      papelNome: papelNome ?? this.papelNome,
      papelDescricao: papelDescricao ?? this.papelDescricao,
      idFuncao: idFuncao ?? this.idFuncao,
      funcaoNome: funcaoNome ?? this.funcaoNome,
      funcaoDescricao: funcaoDescricao ?? this.funcaoDescricao,
      idPapelFuncao: idPapelFuncao ?? this.idPapelFuncao,
      habilitado: habilitado ?? this.habilitado,
      podeInserir: podeInserir ?? this.podeInserir,
      podeAlterar: podeAlterar ?? this.podeAlterar,
      podeExcluir: podeExcluir ?? this.podeExcluir,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (idPessoa.present) {
      map['id_pessoa'] = Variable<int>(idPessoa.value);
    }
    if (pessoaNome.present) {
      map['pessoa_nome'] = Variable<String>(pessoaNome.value);
    }
    if (idColaborador.present) {
      map['id_colaborador'] = Variable<int>(idColaborador.value);
    }
    if (idUsuario.present) {
      map['id_usuario'] = Variable<int>(idUsuario.value);
    }
    if (administrador.present) {
      map['administrador'] = Variable<String>(administrador.value);
    }
    if (idPapel.present) {
      map['id_papel'] = Variable<int>(idPapel.value);
    }
    if (papelNome.present) {
      map['papel_nome'] = Variable<String>(papelNome.value);
    }
    if (papelDescricao.present) {
      map['papel_descricao'] = Variable<String>(papelDescricao.value);
    }
    if (idFuncao.present) {
      map['id_funcao'] = Variable<int>(idFuncao.value);
    }
    if (funcaoNome.present) {
      map['funcao_nome'] = Variable<String>(funcaoNome.value);
    }
    if (funcaoDescricao.present) {
      map['funcao_descricao'] = Variable<String>(funcaoDescricao.value);
    }
    if (idPapelFuncao.present) {
      map['id_papel_funcao'] = Variable<int>(idPapelFuncao.value);
    }
    if (habilitado.present) {
      map['habilitado'] = Variable<String>(habilitado.value);
    }
    if (podeInserir.present) {
      map['pode_inserir'] = Variable<String>(podeInserir.value);
    }
    if (podeAlterar.present) {
      map['pode_alterar'] = Variable<String>(podeAlterar.value);
    }
    if (podeExcluir.present) {
      map['pode_excluir'] = Variable<String>(podeExcluir.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('ViewControleAcessosCompanion(')
          ..write('id: $id, ')
          ..write('idPessoa: $idPessoa, ')
          ..write('pessoaNome: $pessoaNome, ')
          ..write('idColaborador: $idColaborador, ')
          ..write('idUsuario: $idUsuario, ')
          ..write('administrador: $administrador, ')
          ..write('idPapel: $idPapel, ')
          ..write('papelNome: $papelNome, ')
          ..write('papelDescricao: $papelDescricao, ')
          ..write('idFuncao: $idFuncao, ')
          ..write('funcaoNome: $funcaoNome, ')
          ..write('funcaoDescricao: $funcaoDescricao, ')
          ..write('idPapelFuncao: $idPapelFuncao, ')
          ..write('habilitado: $habilitado, ')
          ..write('podeInserir: $podeInserir, ')
          ..write('podeAlterar: $podeAlterar, ')
          ..write('podeExcluir: $podeExcluir')
          ..write(')'))
        .toString();
  }
}

class $ViewPessoaUsuariosTable extends ViewPessoaUsuarios
    with TableInfo<$ViewPessoaUsuariosTable, ViewPessoaUsuario> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $ViewPessoaUsuariosTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
      'id', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _idPessoaMeta =
      const VerificationMeta('idPessoa');
  @override
  late final GeneratedColumn<int> idPessoa = GeneratedColumn<int>(
      'id_pessoa', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _pessoaNomeMeta =
      const VerificationMeta('pessoaNome');
  @override
  late final GeneratedColumn<String> pessoaNome = GeneratedColumn<String>(
      'pessoa_nome', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 450),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _tipoMeta = const VerificationMeta('tipo');
  @override
  late final GeneratedColumn<String> tipo = GeneratedColumn<String>(
      'tipo', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 3),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _emailMeta = const VerificationMeta('email');
  @override
  late final GeneratedColumn<String> email = GeneratedColumn<String>(
      'email', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 750),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _idColaboradorMeta =
      const VerificationMeta('idColaborador');
  @override
  late final GeneratedColumn<int> idColaborador = GeneratedColumn<int>(
      'id_colaborador', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _idUsuarioMeta =
      const VerificationMeta('idUsuario');
  @override
  late final GeneratedColumn<int> idUsuario = GeneratedColumn<int>(
      'id_usuario', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _loginMeta = const VerificationMeta('login');
  @override
  late final GeneratedColumn<String> login = GeneratedColumn<String>(
      'login', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 150),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _senhaMeta = const VerificationMeta('senha');
  @override
  late final GeneratedColumn<String> senha = GeneratedColumn<String>(
      'senha', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 150),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _dataCadastroMeta =
      const VerificationMeta('dataCadastro');
  @override
  late final GeneratedColumn<DateTime> dataCadastro = GeneratedColumn<DateTime>(
      'data_cadastro', aliasedName, true,
      type: DriftSqlType.dateTime, requiredDuringInsert: false);
  static const VerificationMeta _administradorMeta =
      const VerificationMeta('administrador');
  @override
  late final GeneratedColumn<String> administrador = GeneratedColumn<String>(
      'administrador', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 3),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  @override
  List<GeneratedColumn> get $columns => [
        id,
        idPessoa,
        pessoaNome,
        tipo,
        email,
        idColaborador,
        idUsuario,
        login,
        senha,
        dataCadastro,
        administrador
      ];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'view_pessoa_usuario';
  @override
  VerificationContext validateIntegrity(Insertable<ViewPessoaUsuario> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('id_pessoa')) {
      context.handle(_idPessoaMeta,
          idPessoa.isAcceptableOrUnknown(data['id_pessoa']!, _idPessoaMeta));
    }
    if (data.containsKey('pessoa_nome')) {
      context.handle(
          _pessoaNomeMeta,
          pessoaNome.isAcceptableOrUnknown(
              data['pessoa_nome']!, _pessoaNomeMeta));
    }
    if (data.containsKey('tipo')) {
      context.handle(
          _tipoMeta, tipo.isAcceptableOrUnknown(data['tipo']!, _tipoMeta));
    }
    if (data.containsKey('email')) {
      context.handle(
          _emailMeta, email.isAcceptableOrUnknown(data['email']!, _emailMeta));
    }
    if (data.containsKey('id_colaborador')) {
      context.handle(
          _idColaboradorMeta,
          idColaborador.isAcceptableOrUnknown(
              data['id_colaborador']!, _idColaboradorMeta));
    }
    if (data.containsKey('id_usuario')) {
      context.handle(_idUsuarioMeta,
          idUsuario.isAcceptableOrUnknown(data['id_usuario']!, _idUsuarioMeta));
    }
    if (data.containsKey('login')) {
      context.handle(
          _loginMeta, login.isAcceptableOrUnknown(data['login']!, _loginMeta));
    }
    if (data.containsKey('senha')) {
      context.handle(
          _senhaMeta, senha.isAcceptableOrUnknown(data['senha']!, _senhaMeta));
    }
    if (data.containsKey('data_cadastro')) {
      context.handle(
          _dataCadastroMeta,
          dataCadastro.isAcceptableOrUnknown(
              data['data_cadastro']!, _dataCadastroMeta));
    }
    if (data.containsKey('administrador')) {
      context.handle(
          _administradorMeta,
          administrador.isAcceptableOrUnknown(
              data['administrador']!, _administradorMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  ViewPessoaUsuario map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return ViewPessoaUsuario(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id']),
      idPessoa: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id_pessoa']),
      pessoaNome: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}pessoa_nome']),
      tipo: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}tipo']),
      email: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}email']),
      idColaborador: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id_colaborador']),
      idUsuario: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id_usuario']),
      login: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}login']),
      senha: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}senha']),
      dataCadastro: attachedDatabase.typeMapping
          .read(DriftSqlType.dateTime, data['${effectivePrefix}data_cadastro']),
      administrador: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}administrador']),
    );
  }

  @override
  $ViewPessoaUsuariosTable createAlias(String alias) {
    return $ViewPessoaUsuariosTable(attachedDatabase, alias);
  }
}

class ViewPessoaUsuario extends DataClass
    implements Insertable<ViewPessoaUsuario> {
  final int? id;
  final int? idPessoa;
  final String? pessoaNome;
  final String? tipo;
  final String? email;
  final int? idColaborador;
  final int? idUsuario;
  final String? login;
  final String? senha;
  final DateTime? dataCadastro;
  final String? administrador;
  const ViewPessoaUsuario(
      {this.id,
      this.idPessoa,
      this.pessoaNome,
      this.tipo,
      this.email,
      this.idColaborador,
      this.idUsuario,
      this.login,
      this.senha,
      this.dataCadastro,
      this.administrador});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || idPessoa != null) {
      map['id_pessoa'] = Variable<int>(idPessoa);
    }
    if (!nullToAbsent || pessoaNome != null) {
      map['pessoa_nome'] = Variable<String>(pessoaNome);
    }
    if (!nullToAbsent || tipo != null) {
      map['tipo'] = Variable<String>(tipo);
    }
    if (!nullToAbsent || email != null) {
      map['email'] = Variable<String>(email);
    }
    if (!nullToAbsent || idColaborador != null) {
      map['id_colaborador'] = Variable<int>(idColaborador);
    }
    if (!nullToAbsent || idUsuario != null) {
      map['id_usuario'] = Variable<int>(idUsuario);
    }
    if (!nullToAbsent || login != null) {
      map['login'] = Variable<String>(login);
    }
    if (!nullToAbsent || senha != null) {
      map['senha'] = Variable<String>(senha);
    }
    if (!nullToAbsent || dataCadastro != null) {
      map['data_cadastro'] = Variable<DateTime>(dataCadastro);
    }
    if (!nullToAbsent || administrador != null) {
      map['administrador'] = Variable<String>(administrador);
    }
    return map;
  }

  factory ViewPessoaUsuario.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return ViewPessoaUsuario(
      id: serializer.fromJson<int?>(json['id']),
      idPessoa: serializer.fromJson<int?>(json['idPessoa']),
      pessoaNome: serializer.fromJson<String?>(json['pessoaNome']),
      tipo: serializer.fromJson<String?>(json['tipo']),
      email: serializer.fromJson<String?>(json['email']),
      idColaborador: serializer.fromJson<int?>(json['idColaborador']),
      idUsuario: serializer.fromJson<int?>(json['idUsuario']),
      login: serializer.fromJson<String?>(json['login']),
      senha: serializer.fromJson<String?>(json['senha']),
      dataCadastro: serializer.fromJson<DateTime?>(json['dataCadastro']),
      administrador: serializer.fromJson<String?>(json['administrador']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'idPessoa': serializer.toJson<int?>(idPessoa),
      'pessoaNome': serializer.toJson<String?>(pessoaNome),
      'tipo': serializer.toJson<String?>(tipo),
      'email': serializer.toJson<String?>(email),
      'idColaborador': serializer.toJson<int?>(idColaborador),
      'idUsuario': serializer.toJson<int?>(idUsuario),
      'login': serializer.toJson<String?>(login),
      'senha': serializer.toJson<String?>(senha),
      'dataCadastro': serializer.toJson<DateTime?>(dataCadastro),
      'administrador': serializer.toJson<String?>(administrador),
    };
  }

  ViewPessoaUsuario copyWith(
          {Value<int?> id = const Value.absent(),
          Value<int?> idPessoa = const Value.absent(),
          Value<String?> pessoaNome = const Value.absent(),
          Value<String?> tipo = const Value.absent(),
          Value<String?> email = const Value.absent(),
          Value<int?> idColaborador = const Value.absent(),
          Value<int?> idUsuario = const Value.absent(),
          Value<String?> login = const Value.absent(),
          Value<String?> senha = const Value.absent(),
          Value<DateTime?> dataCadastro = const Value.absent(),
          Value<String?> administrador = const Value.absent()}) =>
      ViewPessoaUsuario(
        id: id.present ? id.value : this.id,
        idPessoa: idPessoa.present ? idPessoa.value : this.idPessoa,
        pessoaNome: pessoaNome.present ? pessoaNome.value : this.pessoaNome,
        tipo: tipo.present ? tipo.value : this.tipo,
        email: email.present ? email.value : this.email,
        idColaborador:
            idColaborador.present ? idColaborador.value : this.idColaborador,
        idUsuario: idUsuario.present ? idUsuario.value : this.idUsuario,
        login: login.present ? login.value : this.login,
        senha: senha.present ? senha.value : this.senha,
        dataCadastro:
            dataCadastro.present ? dataCadastro.value : this.dataCadastro,
        administrador:
            administrador.present ? administrador.value : this.administrador,
      );
  ViewPessoaUsuario copyWithCompanion(ViewPessoaUsuariosCompanion data) {
    return ViewPessoaUsuario(
      id: data.id.present ? data.id.value : this.id,
      idPessoa: data.idPessoa.present ? data.idPessoa.value : this.idPessoa,
      pessoaNome:
          data.pessoaNome.present ? data.pessoaNome.value : this.pessoaNome,
      tipo: data.tipo.present ? data.tipo.value : this.tipo,
      email: data.email.present ? data.email.value : this.email,
      idColaborador: data.idColaborador.present
          ? data.idColaborador.value
          : this.idColaborador,
      idUsuario: data.idUsuario.present ? data.idUsuario.value : this.idUsuario,
      login: data.login.present ? data.login.value : this.login,
      senha: data.senha.present ? data.senha.value : this.senha,
      dataCadastro: data.dataCadastro.present
          ? data.dataCadastro.value
          : this.dataCadastro,
      administrador: data.administrador.present
          ? data.administrador.value
          : this.administrador,
    );
  }

  @override
  String toString() {
    return (StringBuffer('ViewPessoaUsuario(')
          ..write('id: $id, ')
          ..write('idPessoa: $idPessoa, ')
          ..write('pessoaNome: $pessoaNome, ')
          ..write('tipo: $tipo, ')
          ..write('email: $email, ')
          ..write('idColaborador: $idColaborador, ')
          ..write('idUsuario: $idUsuario, ')
          ..write('login: $login, ')
          ..write('senha: $senha, ')
          ..write('dataCadastro: $dataCadastro, ')
          ..write('administrador: $administrador')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(id, idPessoa, pessoaNome, tipo, email,
      idColaborador, idUsuario, login, senha, dataCadastro, administrador);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is ViewPessoaUsuario &&
          other.id == this.id &&
          other.idPessoa == this.idPessoa &&
          other.pessoaNome == this.pessoaNome &&
          other.tipo == this.tipo &&
          other.email == this.email &&
          other.idColaborador == this.idColaborador &&
          other.idUsuario == this.idUsuario &&
          other.login == this.login &&
          other.senha == this.senha &&
          other.dataCadastro == this.dataCadastro &&
          other.administrador == this.administrador);
}

class ViewPessoaUsuariosCompanion extends UpdateCompanion<ViewPessoaUsuario> {
  final Value<int?> id;
  final Value<int?> idPessoa;
  final Value<String?> pessoaNome;
  final Value<String?> tipo;
  final Value<String?> email;
  final Value<int?> idColaborador;
  final Value<int?> idUsuario;
  final Value<String?> login;
  final Value<String?> senha;
  final Value<DateTime?> dataCadastro;
  final Value<String?> administrador;
  const ViewPessoaUsuariosCompanion({
    this.id = const Value.absent(),
    this.idPessoa = const Value.absent(),
    this.pessoaNome = const Value.absent(),
    this.tipo = const Value.absent(),
    this.email = const Value.absent(),
    this.idColaborador = const Value.absent(),
    this.idUsuario = const Value.absent(),
    this.login = const Value.absent(),
    this.senha = const Value.absent(),
    this.dataCadastro = const Value.absent(),
    this.administrador = const Value.absent(),
  });
  ViewPessoaUsuariosCompanion.insert({
    this.id = const Value.absent(),
    this.idPessoa = const Value.absent(),
    this.pessoaNome = const Value.absent(),
    this.tipo = const Value.absent(),
    this.email = const Value.absent(),
    this.idColaborador = const Value.absent(),
    this.idUsuario = const Value.absent(),
    this.login = const Value.absent(),
    this.senha = const Value.absent(),
    this.dataCadastro = const Value.absent(),
    this.administrador = const Value.absent(),
  });
  static Insertable<ViewPessoaUsuario> custom({
    Expression<int>? id,
    Expression<int>? idPessoa,
    Expression<String>? pessoaNome,
    Expression<String>? tipo,
    Expression<String>? email,
    Expression<int>? idColaborador,
    Expression<int>? idUsuario,
    Expression<String>? login,
    Expression<String>? senha,
    Expression<DateTime>? dataCadastro,
    Expression<String>? administrador,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (idPessoa != null) 'id_pessoa': idPessoa,
      if (pessoaNome != null) 'pessoa_nome': pessoaNome,
      if (tipo != null) 'tipo': tipo,
      if (email != null) 'email': email,
      if (idColaborador != null) 'id_colaborador': idColaborador,
      if (idUsuario != null) 'id_usuario': idUsuario,
      if (login != null) 'login': login,
      if (senha != null) 'senha': senha,
      if (dataCadastro != null) 'data_cadastro': dataCadastro,
      if (administrador != null) 'administrador': administrador,
    });
  }

  ViewPessoaUsuariosCompanion copyWith(
      {Value<int?>? id,
      Value<int?>? idPessoa,
      Value<String?>? pessoaNome,
      Value<String?>? tipo,
      Value<String?>? email,
      Value<int?>? idColaborador,
      Value<int?>? idUsuario,
      Value<String?>? login,
      Value<String?>? senha,
      Value<DateTime?>? dataCadastro,
      Value<String?>? administrador}) {
    return ViewPessoaUsuariosCompanion(
      id: id ?? this.id,
      idPessoa: idPessoa ?? this.idPessoa,
      pessoaNome: pessoaNome ?? this.pessoaNome,
      tipo: tipo ?? this.tipo,
      email: email ?? this.email,
      idColaborador: idColaborador ?? this.idColaborador,
      idUsuario: idUsuario ?? this.idUsuario,
      login: login ?? this.login,
      senha: senha ?? this.senha,
      dataCadastro: dataCadastro ?? this.dataCadastro,
      administrador: administrador ?? this.administrador,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (idPessoa.present) {
      map['id_pessoa'] = Variable<int>(idPessoa.value);
    }
    if (pessoaNome.present) {
      map['pessoa_nome'] = Variable<String>(pessoaNome.value);
    }
    if (tipo.present) {
      map['tipo'] = Variable<String>(tipo.value);
    }
    if (email.present) {
      map['email'] = Variable<String>(email.value);
    }
    if (idColaborador.present) {
      map['id_colaborador'] = Variable<int>(idColaborador.value);
    }
    if (idUsuario.present) {
      map['id_usuario'] = Variable<int>(idUsuario.value);
    }
    if (login.present) {
      map['login'] = Variable<String>(login.value);
    }
    if (senha.present) {
      map['senha'] = Variable<String>(senha.value);
    }
    if (dataCadastro.present) {
      map['data_cadastro'] = Variable<DateTime>(dataCadastro.value);
    }
    if (administrador.present) {
      map['administrador'] = Variable<String>(administrador.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('ViewPessoaUsuariosCompanion(')
          ..write('id: $id, ')
          ..write('idPessoa: $idPessoa, ')
          ..write('pessoaNome: $pessoaNome, ')
          ..write('tipo: $tipo, ')
          ..write('email: $email, ')
          ..write('idColaborador: $idColaborador, ')
          ..write('idUsuario: $idUsuario, ')
          ..write('login: $login, ')
          ..write('senha: $senha, ')
          ..write('dataCadastro: $dataCadastro, ')
          ..write('administrador: $administrador')
          ..write(')'))
        .toString();
  }
}

class $SpedFiscalsTable extends SpedFiscals
    with TableInfo<$SpedFiscalsTable, SpedFiscal> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $SpedFiscalsTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
      'id', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _dataEmissaoMeta =
      const VerificationMeta('dataEmissao');
  @override
  late final GeneratedColumn<DateTime> dataEmissao = GeneratedColumn<DateTime>(
      'data_emissao', aliasedName, true,
      type: DriftSqlType.dateTime, requiredDuringInsert: false);
  static const VerificationMeta _periodoInicialMeta =
      const VerificationMeta('periodoInicial');
  @override
  late final GeneratedColumn<DateTime> periodoInicial =
      GeneratedColumn<DateTime>('periodo_inicial', aliasedName, true,
          type: DriftSqlType.dateTime, requiredDuringInsert: false);
  static const VerificationMeta _periodoFinalMeta =
      const VerificationMeta('periodoFinal');
  @override
  late final GeneratedColumn<DateTime> periodoFinal = GeneratedColumn<DateTime>(
      'periodo_final', aliasedName, true,
      type: DriftSqlType.dateTime, requiredDuringInsert: false);
  static const VerificationMeta _perfilApresentacaoMeta =
      const VerificationMeta('perfilApresentacao');
  @override
  late final GeneratedColumn<String> perfilApresentacao =
      GeneratedColumn<String>('perfil_apresentacao', aliasedName, true,
          additionalChecks: GeneratedColumn.checkTextLength(
              minTextLength: 0, maxTextLength: 1),
          type: DriftSqlType.string,
          requiredDuringInsert: false);
  static const VerificationMeta _finalidadeArquivoMeta =
      const VerificationMeta('finalidadeArquivo');
  @override
  late final GeneratedColumn<String> finalidadeArquivo =
      GeneratedColumn<String>('finalidade_arquivo', aliasedName, true,
          additionalChecks: GeneratedColumn.checkTextLength(
              minTextLength: 0, maxTextLength: 100),
          type: DriftSqlType.string,
          requiredDuringInsert: false);
  static const VerificationMeta _versaoLayoutMeta =
      const VerificationMeta('versaoLayout');
  @override
  late final GeneratedColumn<String> versaoLayout = GeneratedColumn<String>(
      'versao_layout', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 100),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  @override
  List<GeneratedColumn> get $columns => [
        id,
        dataEmissao,
        periodoInicial,
        periodoFinal,
        perfilApresentacao,
        finalidadeArquivo,
        versaoLayout
      ];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'sped_fiscal';
  @override
  VerificationContext validateIntegrity(Insertable<SpedFiscal> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('data_emissao')) {
      context.handle(
          _dataEmissaoMeta,
          dataEmissao.isAcceptableOrUnknown(
              data['data_emissao']!, _dataEmissaoMeta));
    }
    if (data.containsKey('periodo_inicial')) {
      context.handle(
          _periodoInicialMeta,
          periodoInicial.isAcceptableOrUnknown(
              data['periodo_inicial']!, _periodoInicialMeta));
    }
    if (data.containsKey('periodo_final')) {
      context.handle(
          _periodoFinalMeta,
          periodoFinal.isAcceptableOrUnknown(
              data['periodo_final']!, _periodoFinalMeta));
    }
    if (data.containsKey('perfil_apresentacao')) {
      context.handle(
          _perfilApresentacaoMeta,
          perfilApresentacao.isAcceptableOrUnknown(
              data['perfil_apresentacao']!, _perfilApresentacaoMeta));
    }
    if (data.containsKey('finalidade_arquivo')) {
      context.handle(
          _finalidadeArquivoMeta,
          finalidadeArquivo.isAcceptableOrUnknown(
              data['finalidade_arquivo']!, _finalidadeArquivoMeta));
    }
    if (data.containsKey('versao_layout')) {
      context.handle(
          _versaoLayoutMeta,
          versaoLayout.isAcceptableOrUnknown(
              data['versao_layout']!, _versaoLayoutMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  SpedFiscal map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return SpedFiscal(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id']),
      dataEmissao: attachedDatabase.typeMapping
          .read(DriftSqlType.dateTime, data['${effectivePrefix}data_emissao']),
      periodoInicial: attachedDatabase.typeMapping.read(
          DriftSqlType.dateTime, data['${effectivePrefix}periodo_inicial']),
      periodoFinal: attachedDatabase.typeMapping
          .read(DriftSqlType.dateTime, data['${effectivePrefix}periodo_final']),
      perfilApresentacao: attachedDatabase.typeMapping.read(
          DriftSqlType.string, data['${effectivePrefix}perfil_apresentacao']),
      finalidadeArquivo: attachedDatabase.typeMapping.read(
          DriftSqlType.string, data['${effectivePrefix}finalidade_arquivo']),
      versaoLayout: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}versao_layout']),
    );
  }

  @override
  $SpedFiscalsTable createAlias(String alias) {
    return $SpedFiscalsTable(attachedDatabase, alias);
  }
}

class SpedFiscal extends DataClass implements Insertable<SpedFiscal> {
  final int? id;
  final DateTime? dataEmissao;
  final DateTime? periodoInicial;
  final DateTime? periodoFinal;
  final String? perfilApresentacao;
  final String? finalidadeArquivo;
  final String? versaoLayout;
  const SpedFiscal(
      {this.id,
      this.dataEmissao,
      this.periodoInicial,
      this.periodoFinal,
      this.perfilApresentacao,
      this.finalidadeArquivo,
      this.versaoLayout});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || dataEmissao != null) {
      map['data_emissao'] = Variable<DateTime>(dataEmissao);
    }
    if (!nullToAbsent || periodoInicial != null) {
      map['periodo_inicial'] = Variable<DateTime>(periodoInicial);
    }
    if (!nullToAbsent || periodoFinal != null) {
      map['periodo_final'] = Variable<DateTime>(periodoFinal);
    }
    if (!nullToAbsent || perfilApresentacao != null) {
      map['perfil_apresentacao'] = Variable<String>(perfilApresentacao);
    }
    if (!nullToAbsent || finalidadeArquivo != null) {
      map['finalidade_arquivo'] = Variable<String>(finalidadeArquivo);
    }
    if (!nullToAbsent || versaoLayout != null) {
      map['versao_layout'] = Variable<String>(versaoLayout);
    }
    return map;
  }

  factory SpedFiscal.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return SpedFiscal(
      id: serializer.fromJson<int?>(json['id']),
      dataEmissao: serializer.fromJson<DateTime?>(json['dataEmissao']),
      periodoInicial: serializer.fromJson<DateTime?>(json['periodoInicial']),
      periodoFinal: serializer.fromJson<DateTime?>(json['periodoFinal']),
      perfilApresentacao:
          serializer.fromJson<String?>(json['perfilApresentacao']),
      finalidadeArquivo:
          serializer.fromJson<String?>(json['finalidadeArquivo']),
      versaoLayout: serializer.fromJson<String?>(json['versaoLayout']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'dataEmissao': serializer.toJson<DateTime?>(dataEmissao),
      'periodoInicial': serializer.toJson<DateTime?>(periodoInicial),
      'periodoFinal': serializer.toJson<DateTime?>(periodoFinal),
      'perfilApresentacao': serializer.toJson<String?>(perfilApresentacao),
      'finalidadeArquivo': serializer.toJson<String?>(finalidadeArquivo),
      'versaoLayout': serializer.toJson<String?>(versaoLayout),
    };
  }

  SpedFiscal copyWith(
          {Value<int?> id = const Value.absent(),
          Value<DateTime?> dataEmissao = const Value.absent(),
          Value<DateTime?> periodoInicial = const Value.absent(),
          Value<DateTime?> periodoFinal = const Value.absent(),
          Value<String?> perfilApresentacao = const Value.absent(),
          Value<String?> finalidadeArquivo = const Value.absent(),
          Value<String?> versaoLayout = const Value.absent()}) =>
      SpedFiscal(
        id: id.present ? id.value : this.id,
        dataEmissao: dataEmissao.present ? dataEmissao.value : this.dataEmissao,
        periodoInicial:
            periodoInicial.present ? periodoInicial.value : this.periodoInicial,
        periodoFinal:
            periodoFinal.present ? periodoFinal.value : this.periodoFinal,
        perfilApresentacao: perfilApresentacao.present
            ? perfilApresentacao.value
            : this.perfilApresentacao,
        finalidadeArquivo: finalidadeArquivo.present
            ? finalidadeArquivo.value
            : this.finalidadeArquivo,
        versaoLayout:
            versaoLayout.present ? versaoLayout.value : this.versaoLayout,
      );
  SpedFiscal copyWithCompanion(SpedFiscalsCompanion data) {
    return SpedFiscal(
      id: data.id.present ? data.id.value : this.id,
      dataEmissao:
          data.dataEmissao.present ? data.dataEmissao.value : this.dataEmissao,
      periodoInicial: data.periodoInicial.present
          ? data.periodoInicial.value
          : this.periodoInicial,
      periodoFinal: data.periodoFinal.present
          ? data.periodoFinal.value
          : this.periodoFinal,
      perfilApresentacao: data.perfilApresentacao.present
          ? data.perfilApresentacao.value
          : this.perfilApresentacao,
      finalidadeArquivo: data.finalidadeArquivo.present
          ? data.finalidadeArquivo.value
          : this.finalidadeArquivo,
      versaoLayout: data.versaoLayout.present
          ? data.versaoLayout.value
          : this.versaoLayout,
    );
  }

  @override
  String toString() {
    return (StringBuffer('SpedFiscal(')
          ..write('id: $id, ')
          ..write('dataEmissao: $dataEmissao, ')
          ..write('periodoInicial: $periodoInicial, ')
          ..write('periodoFinal: $periodoFinal, ')
          ..write('perfilApresentacao: $perfilApresentacao, ')
          ..write('finalidadeArquivo: $finalidadeArquivo, ')
          ..write('versaoLayout: $versaoLayout')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(id, dataEmissao, periodoInicial, periodoFinal,
      perfilApresentacao, finalidadeArquivo, versaoLayout);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is SpedFiscal &&
          other.id == this.id &&
          other.dataEmissao == this.dataEmissao &&
          other.periodoInicial == this.periodoInicial &&
          other.periodoFinal == this.periodoFinal &&
          other.perfilApresentacao == this.perfilApresentacao &&
          other.finalidadeArquivo == this.finalidadeArquivo &&
          other.versaoLayout == this.versaoLayout);
}

class SpedFiscalsCompanion extends UpdateCompanion<SpedFiscal> {
  final Value<int?> id;
  final Value<DateTime?> dataEmissao;
  final Value<DateTime?> periodoInicial;
  final Value<DateTime?> periodoFinal;
  final Value<String?> perfilApresentacao;
  final Value<String?> finalidadeArquivo;
  final Value<String?> versaoLayout;
  const SpedFiscalsCompanion({
    this.id = const Value.absent(),
    this.dataEmissao = const Value.absent(),
    this.periodoInicial = const Value.absent(),
    this.periodoFinal = const Value.absent(),
    this.perfilApresentacao = const Value.absent(),
    this.finalidadeArquivo = const Value.absent(),
    this.versaoLayout = const Value.absent(),
  });
  SpedFiscalsCompanion.insert({
    this.id = const Value.absent(),
    this.dataEmissao = const Value.absent(),
    this.periodoInicial = const Value.absent(),
    this.periodoFinal = const Value.absent(),
    this.perfilApresentacao = const Value.absent(),
    this.finalidadeArquivo = const Value.absent(),
    this.versaoLayout = const Value.absent(),
  });
  static Insertable<SpedFiscal> custom({
    Expression<int>? id,
    Expression<DateTime>? dataEmissao,
    Expression<DateTime>? periodoInicial,
    Expression<DateTime>? periodoFinal,
    Expression<String>? perfilApresentacao,
    Expression<String>? finalidadeArquivo,
    Expression<String>? versaoLayout,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (dataEmissao != null) 'data_emissao': dataEmissao,
      if (periodoInicial != null) 'periodo_inicial': periodoInicial,
      if (periodoFinal != null) 'periodo_final': periodoFinal,
      if (perfilApresentacao != null) 'perfil_apresentacao': perfilApresentacao,
      if (finalidadeArquivo != null) 'finalidade_arquivo': finalidadeArquivo,
      if (versaoLayout != null) 'versao_layout': versaoLayout,
    });
  }

  SpedFiscalsCompanion copyWith(
      {Value<int?>? id,
      Value<DateTime?>? dataEmissao,
      Value<DateTime?>? periodoInicial,
      Value<DateTime?>? periodoFinal,
      Value<String?>? perfilApresentacao,
      Value<String?>? finalidadeArquivo,
      Value<String?>? versaoLayout}) {
    return SpedFiscalsCompanion(
      id: id ?? this.id,
      dataEmissao: dataEmissao ?? this.dataEmissao,
      periodoInicial: periodoInicial ?? this.periodoInicial,
      periodoFinal: periodoFinal ?? this.periodoFinal,
      perfilApresentacao: perfilApresentacao ?? this.perfilApresentacao,
      finalidadeArquivo: finalidadeArquivo ?? this.finalidadeArquivo,
      versaoLayout: versaoLayout ?? this.versaoLayout,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (dataEmissao.present) {
      map['data_emissao'] = Variable<DateTime>(dataEmissao.value);
    }
    if (periodoInicial.present) {
      map['periodo_inicial'] = Variable<DateTime>(periodoInicial.value);
    }
    if (periodoFinal.present) {
      map['periodo_final'] = Variable<DateTime>(periodoFinal.value);
    }
    if (perfilApresentacao.present) {
      map['perfil_apresentacao'] = Variable<String>(perfilApresentacao.value);
    }
    if (finalidadeArquivo.present) {
      map['finalidade_arquivo'] = Variable<String>(finalidadeArquivo.value);
    }
    if (versaoLayout.present) {
      map['versao_layout'] = Variable<String>(versaoLayout.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('SpedFiscalsCompanion(')
          ..write('id: $id, ')
          ..write('dataEmissao: $dataEmissao, ')
          ..write('periodoInicial: $periodoInicial, ')
          ..write('periodoFinal: $periodoFinal, ')
          ..write('perfilApresentacao: $perfilApresentacao, ')
          ..write('finalidadeArquivo: $finalidadeArquivo, ')
          ..write('versaoLayout: $versaoLayout')
          ..write(')'))
        .toString();
  }
}

class $SintegrasTable extends Sintegras
    with TableInfo<$SintegrasTable, Sintegra> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $SintegrasTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
      'id', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _dataEmissaoMeta =
      const VerificationMeta('dataEmissao');
  @override
  late final GeneratedColumn<DateTime> dataEmissao = GeneratedColumn<DateTime>(
      'data_emissao', aliasedName, true,
      type: DriftSqlType.dateTime, requiredDuringInsert: false);
  static const VerificationMeta _periodoInicialMeta =
      const VerificationMeta('periodoInicial');
  @override
  late final GeneratedColumn<DateTime> periodoInicial =
      GeneratedColumn<DateTime>('periodo_inicial', aliasedName, true,
          type: DriftSqlType.dateTime, requiredDuringInsert: false);
  static const VerificationMeta _periodoFinalMeta =
      const VerificationMeta('periodoFinal');
  @override
  late final GeneratedColumn<DateTime> periodoFinal = GeneratedColumn<DateTime>(
      'periodo_final', aliasedName, true,
      type: DriftSqlType.dateTime, requiredDuringInsert: false);
  static const VerificationMeta _codigoConvenioMeta =
      const VerificationMeta('codigoConvenio');
  @override
  late final GeneratedColumn<String> codigoConvenio = GeneratedColumn<String>(
      'codigo_convenio', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 1),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _finalidadeArquivoMeta =
      const VerificationMeta('finalidadeArquivo');
  @override
  late final GeneratedColumn<String> finalidadeArquivo =
      GeneratedColumn<String>('finalidade_arquivo', aliasedName, true,
          additionalChecks: GeneratedColumn.checkTextLength(
              minTextLength: 0, maxTextLength: 100),
          type: DriftSqlType.string,
          requiredDuringInsert: false);
  static const VerificationMeta _inventarioMeta =
      const VerificationMeta('inventario');
  @override
  late final GeneratedColumn<String> inventario = GeneratedColumn<String>(
      'inventario', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 1),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  @override
  List<GeneratedColumn> get $columns => [
        id,
        dataEmissao,
        periodoInicial,
        periodoFinal,
        codigoConvenio,
        finalidadeArquivo,
        inventario
      ];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'sintegra';
  @override
  VerificationContext validateIntegrity(Insertable<Sintegra> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('data_emissao')) {
      context.handle(
          _dataEmissaoMeta,
          dataEmissao.isAcceptableOrUnknown(
              data['data_emissao']!, _dataEmissaoMeta));
    }
    if (data.containsKey('periodo_inicial')) {
      context.handle(
          _periodoInicialMeta,
          periodoInicial.isAcceptableOrUnknown(
              data['periodo_inicial']!, _periodoInicialMeta));
    }
    if (data.containsKey('periodo_final')) {
      context.handle(
          _periodoFinalMeta,
          periodoFinal.isAcceptableOrUnknown(
              data['periodo_final']!, _periodoFinalMeta));
    }
    if (data.containsKey('codigo_convenio')) {
      context.handle(
          _codigoConvenioMeta,
          codigoConvenio.isAcceptableOrUnknown(
              data['codigo_convenio']!, _codigoConvenioMeta));
    }
    if (data.containsKey('finalidade_arquivo')) {
      context.handle(
          _finalidadeArquivoMeta,
          finalidadeArquivo.isAcceptableOrUnknown(
              data['finalidade_arquivo']!, _finalidadeArquivoMeta));
    }
    if (data.containsKey('inventario')) {
      context.handle(
          _inventarioMeta,
          inventario.isAcceptableOrUnknown(
              data['inventario']!, _inventarioMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  Sintegra map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return Sintegra(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id']),
      dataEmissao: attachedDatabase.typeMapping
          .read(DriftSqlType.dateTime, data['${effectivePrefix}data_emissao']),
      periodoInicial: attachedDatabase.typeMapping.read(
          DriftSqlType.dateTime, data['${effectivePrefix}periodo_inicial']),
      periodoFinal: attachedDatabase.typeMapping
          .read(DriftSqlType.dateTime, data['${effectivePrefix}periodo_final']),
      codigoConvenio: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}codigo_convenio']),
      finalidadeArquivo: attachedDatabase.typeMapping.read(
          DriftSqlType.string, data['${effectivePrefix}finalidade_arquivo']),
      inventario: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}inventario']),
    );
  }

  @override
  $SintegrasTable createAlias(String alias) {
    return $SintegrasTable(attachedDatabase, alias);
  }
}

class Sintegra extends DataClass implements Insertable<Sintegra> {
  final int? id;
  final DateTime? dataEmissao;
  final DateTime? periodoInicial;
  final DateTime? periodoFinal;
  final String? codigoConvenio;
  final String? finalidadeArquivo;
  final String? inventario;
  const Sintegra(
      {this.id,
      this.dataEmissao,
      this.periodoInicial,
      this.periodoFinal,
      this.codigoConvenio,
      this.finalidadeArquivo,
      this.inventario});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || dataEmissao != null) {
      map['data_emissao'] = Variable<DateTime>(dataEmissao);
    }
    if (!nullToAbsent || periodoInicial != null) {
      map['periodo_inicial'] = Variable<DateTime>(periodoInicial);
    }
    if (!nullToAbsent || periodoFinal != null) {
      map['periodo_final'] = Variable<DateTime>(periodoFinal);
    }
    if (!nullToAbsent || codigoConvenio != null) {
      map['codigo_convenio'] = Variable<String>(codigoConvenio);
    }
    if (!nullToAbsent || finalidadeArquivo != null) {
      map['finalidade_arquivo'] = Variable<String>(finalidadeArquivo);
    }
    if (!nullToAbsent || inventario != null) {
      map['inventario'] = Variable<String>(inventario);
    }
    return map;
  }

  factory Sintegra.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return Sintegra(
      id: serializer.fromJson<int?>(json['id']),
      dataEmissao: serializer.fromJson<DateTime?>(json['dataEmissao']),
      periodoInicial: serializer.fromJson<DateTime?>(json['periodoInicial']),
      periodoFinal: serializer.fromJson<DateTime?>(json['periodoFinal']),
      codigoConvenio: serializer.fromJson<String?>(json['codigoConvenio']),
      finalidadeArquivo:
          serializer.fromJson<String?>(json['finalidadeArquivo']),
      inventario: serializer.fromJson<String?>(json['inventario']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'dataEmissao': serializer.toJson<DateTime?>(dataEmissao),
      'periodoInicial': serializer.toJson<DateTime?>(periodoInicial),
      'periodoFinal': serializer.toJson<DateTime?>(periodoFinal),
      'codigoConvenio': serializer.toJson<String?>(codigoConvenio),
      'finalidadeArquivo': serializer.toJson<String?>(finalidadeArquivo),
      'inventario': serializer.toJson<String?>(inventario),
    };
  }

  Sintegra copyWith(
          {Value<int?> id = const Value.absent(),
          Value<DateTime?> dataEmissao = const Value.absent(),
          Value<DateTime?> periodoInicial = const Value.absent(),
          Value<DateTime?> periodoFinal = const Value.absent(),
          Value<String?> codigoConvenio = const Value.absent(),
          Value<String?> finalidadeArquivo = const Value.absent(),
          Value<String?> inventario = const Value.absent()}) =>
      Sintegra(
        id: id.present ? id.value : this.id,
        dataEmissao: dataEmissao.present ? dataEmissao.value : this.dataEmissao,
        periodoInicial:
            periodoInicial.present ? periodoInicial.value : this.periodoInicial,
        periodoFinal:
            periodoFinal.present ? periodoFinal.value : this.periodoFinal,
        codigoConvenio:
            codigoConvenio.present ? codigoConvenio.value : this.codigoConvenio,
        finalidadeArquivo: finalidadeArquivo.present
            ? finalidadeArquivo.value
            : this.finalidadeArquivo,
        inventario: inventario.present ? inventario.value : this.inventario,
      );
  Sintegra copyWithCompanion(SintegrasCompanion data) {
    return Sintegra(
      id: data.id.present ? data.id.value : this.id,
      dataEmissao:
          data.dataEmissao.present ? data.dataEmissao.value : this.dataEmissao,
      periodoInicial: data.periodoInicial.present
          ? data.periodoInicial.value
          : this.periodoInicial,
      periodoFinal: data.periodoFinal.present
          ? data.periodoFinal.value
          : this.periodoFinal,
      codigoConvenio: data.codigoConvenio.present
          ? data.codigoConvenio.value
          : this.codigoConvenio,
      finalidadeArquivo: data.finalidadeArquivo.present
          ? data.finalidadeArquivo.value
          : this.finalidadeArquivo,
      inventario:
          data.inventario.present ? data.inventario.value : this.inventario,
    );
  }

  @override
  String toString() {
    return (StringBuffer('Sintegra(')
          ..write('id: $id, ')
          ..write('dataEmissao: $dataEmissao, ')
          ..write('periodoInicial: $periodoInicial, ')
          ..write('periodoFinal: $periodoFinal, ')
          ..write('codigoConvenio: $codigoConvenio, ')
          ..write('finalidadeArquivo: $finalidadeArquivo, ')
          ..write('inventario: $inventario')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(id, dataEmissao, periodoInicial, periodoFinal,
      codigoConvenio, finalidadeArquivo, inventario);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is Sintegra &&
          other.id == this.id &&
          other.dataEmissao == this.dataEmissao &&
          other.periodoInicial == this.periodoInicial &&
          other.periodoFinal == this.periodoFinal &&
          other.codigoConvenio == this.codigoConvenio &&
          other.finalidadeArquivo == this.finalidadeArquivo &&
          other.inventario == this.inventario);
}

class SintegrasCompanion extends UpdateCompanion<Sintegra> {
  final Value<int?> id;
  final Value<DateTime?> dataEmissao;
  final Value<DateTime?> periodoInicial;
  final Value<DateTime?> periodoFinal;
  final Value<String?> codigoConvenio;
  final Value<String?> finalidadeArquivo;
  final Value<String?> inventario;
  const SintegrasCompanion({
    this.id = const Value.absent(),
    this.dataEmissao = const Value.absent(),
    this.periodoInicial = const Value.absent(),
    this.periodoFinal = const Value.absent(),
    this.codigoConvenio = const Value.absent(),
    this.finalidadeArquivo = const Value.absent(),
    this.inventario = const Value.absent(),
  });
  SintegrasCompanion.insert({
    this.id = const Value.absent(),
    this.dataEmissao = const Value.absent(),
    this.periodoInicial = const Value.absent(),
    this.periodoFinal = const Value.absent(),
    this.codigoConvenio = const Value.absent(),
    this.finalidadeArquivo = const Value.absent(),
    this.inventario = const Value.absent(),
  });
  static Insertable<Sintegra> custom({
    Expression<int>? id,
    Expression<DateTime>? dataEmissao,
    Expression<DateTime>? periodoInicial,
    Expression<DateTime>? periodoFinal,
    Expression<String>? codigoConvenio,
    Expression<String>? finalidadeArquivo,
    Expression<String>? inventario,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (dataEmissao != null) 'data_emissao': dataEmissao,
      if (periodoInicial != null) 'periodo_inicial': periodoInicial,
      if (periodoFinal != null) 'periodo_final': periodoFinal,
      if (codigoConvenio != null) 'codigo_convenio': codigoConvenio,
      if (finalidadeArquivo != null) 'finalidade_arquivo': finalidadeArquivo,
      if (inventario != null) 'inventario': inventario,
    });
  }

  SintegrasCompanion copyWith(
      {Value<int?>? id,
      Value<DateTime?>? dataEmissao,
      Value<DateTime?>? periodoInicial,
      Value<DateTime?>? periodoFinal,
      Value<String?>? codigoConvenio,
      Value<String?>? finalidadeArquivo,
      Value<String?>? inventario}) {
    return SintegrasCompanion(
      id: id ?? this.id,
      dataEmissao: dataEmissao ?? this.dataEmissao,
      periodoInicial: periodoInicial ?? this.periodoInicial,
      periodoFinal: periodoFinal ?? this.periodoFinal,
      codigoConvenio: codigoConvenio ?? this.codigoConvenio,
      finalidadeArquivo: finalidadeArquivo ?? this.finalidadeArquivo,
      inventario: inventario ?? this.inventario,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (dataEmissao.present) {
      map['data_emissao'] = Variable<DateTime>(dataEmissao.value);
    }
    if (periodoInicial.present) {
      map['periodo_inicial'] = Variable<DateTime>(periodoInicial.value);
    }
    if (periodoFinal.present) {
      map['periodo_final'] = Variable<DateTime>(periodoFinal.value);
    }
    if (codigoConvenio.present) {
      map['codigo_convenio'] = Variable<String>(codigoConvenio.value);
    }
    if (finalidadeArquivo.present) {
      map['finalidade_arquivo'] = Variable<String>(finalidadeArquivo.value);
    }
    if (inventario.present) {
      map['inventario'] = Variable<String>(inventario.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('SintegrasCompanion(')
          ..write('id: $id, ')
          ..write('dataEmissao: $dataEmissao, ')
          ..write('periodoInicial: $periodoInicial, ')
          ..write('periodoFinal: $periodoFinal, ')
          ..write('codigoConvenio: $codigoConvenio, ')
          ..write('finalidadeArquivo: $finalidadeArquivo, ')
          ..write('inventario: $inventario')
          ..write(')'))
        .toString();
  }
}

class $EfdContribuicoessTable extends EfdContribuicoess
    with TableInfo<$EfdContribuicoessTable, EfdContribuicoes> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $EfdContribuicoessTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
      'id', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _dataEmissaoMeta =
      const VerificationMeta('dataEmissao');
  @override
  late final GeneratedColumn<DateTime> dataEmissao = GeneratedColumn<DateTime>(
      'data_emissao', aliasedName, true,
      type: DriftSqlType.dateTime, requiredDuringInsert: false);
  static const VerificationMeta _periodoInicialMeta =
      const VerificationMeta('periodoInicial');
  @override
  late final GeneratedColumn<DateTime> periodoInicial =
      GeneratedColumn<DateTime>('periodo_inicial', aliasedName, true,
          type: DriftSqlType.dateTime, requiredDuringInsert: false);
  static const VerificationMeta _periodoFinalMeta =
      const VerificationMeta('periodoFinal');
  @override
  late final GeneratedColumn<DateTime> periodoFinal = GeneratedColumn<DateTime>(
      'periodo_final', aliasedName, true,
      type: DriftSqlType.dateTime, requiredDuringInsert: false);
  static const VerificationMeta _finalidadeArquivoMeta =
      const VerificationMeta('finalidadeArquivo');
  @override
  late final GeneratedColumn<String> finalidadeArquivo =
      GeneratedColumn<String>('finalidade_arquivo', aliasedName, true,
          additionalChecks: GeneratedColumn.checkTextLength(
              minTextLength: 0, maxTextLength: 100),
          type: DriftSqlType.string,
          requiredDuringInsert: false);
  @override
  List<GeneratedColumn> get $columns =>
      [id, dataEmissao, periodoInicial, periodoFinal, finalidadeArquivo];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'efd_contribuicoes';
  @override
  VerificationContext validateIntegrity(Insertable<EfdContribuicoes> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('data_emissao')) {
      context.handle(
          _dataEmissaoMeta,
          dataEmissao.isAcceptableOrUnknown(
              data['data_emissao']!, _dataEmissaoMeta));
    }
    if (data.containsKey('periodo_inicial')) {
      context.handle(
          _periodoInicialMeta,
          periodoInicial.isAcceptableOrUnknown(
              data['periodo_inicial']!, _periodoInicialMeta));
    }
    if (data.containsKey('periodo_final')) {
      context.handle(
          _periodoFinalMeta,
          periodoFinal.isAcceptableOrUnknown(
              data['periodo_final']!, _periodoFinalMeta));
    }
    if (data.containsKey('finalidade_arquivo')) {
      context.handle(
          _finalidadeArquivoMeta,
          finalidadeArquivo.isAcceptableOrUnknown(
              data['finalidade_arquivo']!, _finalidadeArquivoMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  EfdContribuicoes map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return EfdContribuicoes(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id']),
      dataEmissao: attachedDatabase.typeMapping
          .read(DriftSqlType.dateTime, data['${effectivePrefix}data_emissao']),
      periodoInicial: attachedDatabase.typeMapping.read(
          DriftSqlType.dateTime, data['${effectivePrefix}periodo_inicial']),
      periodoFinal: attachedDatabase.typeMapping
          .read(DriftSqlType.dateTime, data['${effectivePrefix}periodo_final']),
      finalidadeArquivo: attachedDatabase.typeMapping.read(
          DriftSqlType.string, data['${effectivePrefix}finalidade_arquivo']),
    );
  }

  @override
  $EfdContribuicoessTable createAlias(String alias) {
    return $EfdContribuicoessTable(attachedDatabase, alias);
  }
}

class EfdContribuicoes extends DataClass
    implements Insertable<EfdContribuicoes> {
  final int? id;
  final DateTime? dataEmissao;
  final DateTime? periodoInicial;
  final DateTime? periodoFinal;
  final String? finalidadeArquivo;
  const EfdContribuicoes(
      {this.id,
      this.dataEmissao,
      this.periodoInicial,
      this.periodoFinal,
      this.finalidadeArquivo});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || dataEmissao != null) {
      map['data_emissao'] = Variable<DateTime>(dataEmissao);
    }
    if (!nullToAbsent || periodoInicial != null) {
      map['periodo_inicial'] = Variable<DateTime>(periodoInicial);
    }
    if (!nullToAbsent || periodoFinal != null) {
      map['periodo_final'] = Variable<DateTime>(periodoFinal);
    }
    if (!nullToAbsent || finalidadeArquivo != null) {
      map['finalidade_arquivo'] = Variable<String>(finalidadeArquivo);
    }
    return map;
  }

  factory EfdContribuicoes.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return EfdContribuicoes(
      id: serializer.fromJson<int?>(json['id']),
      dataEmissao: serializer.fromJson<DateTime?>(json['dataEmissao']),
      periodoInicial: serializer.fromJson<DateTime?>(json['periodoInicial']),
      periodoFinal: serializer.fromJson<DateTime?>(json['periodoFinal']),
      finalidadeArquivo:
          serializer.fromJson<String?>(json['finalidadeArquivo']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'dataEmissao': serializer.toJson<DateTime?>(dataEmissao),
      'periodoInicial': serializer.toJson<DateTime?>(periodoInicial),
      'periodoFinal': serializer.toJson<DateTime?>(periodoFinal),
      'finalidadeArquivo': serializer.toJson<String?>(finalidadeArquivo),
    };
  }

  EfdContribuicoes copyWith(
          {Value<int?> id = const Value.absent(),
          Value<DateTime?> dataEmissao = const Value.absent(),
          Value<DateTime?> periodoInicial = const Value.absent(),
          Value<DateTime?> periodoFinal = const Value.absent(),
          Value<String?> finalidadeArquivo = const Value.absent()}) =>
      EfdContribuicoes(
        id: id.present ? id.value : this.id,
        dataEmissao: dataEmissao.present ? dataEmissao.value : this.dataEmissao,
        periodoInicial:
            periodoInicial.present ? periodoInicial.value : this.periodoInicial,
        periodoFinal:
            periodoFinal.present ? periodoFinal.value : this.periodoFinal,
        finalidadeArquivo: finalidadeArquivo.present
            ? finalidadeArquivo.value
            : this.finalidadeArquivo,
      );
  EfdContribuicoes copyWithCompanion(EfdContribuicoessCompanion data) {
    return EfdContribuicoes(
      id: data.id.present ? data.id.value : this.id,
      dataEmissao:
          data.dataEmissao.present ? data.dataEmissao.value : this.dataEmissao,
      periodoInicial: data.periodoInicial.present
          ? data.periodoInicial.value
          : this.periodoInicial,
      periodoFinal: data.periodoFinal.present
          ? data.periodoFinal.value
          : this.periodoFinal,
      finalidadeArquivo: data.finalidadeArquivo.present
          ? data.finalidadeArquivo.value
          : this.finalidadeArquivo,
    );
  }

  @override
  String toString() {
    return (StringBuffer('EfdContribuicoes(')
          ..write('id: $id, ')
          ..write('dataEmissao: $dataEmissao, ')
          ..write('periodoInicial: $periodoInicial, ')
          ..write('periodoFinal: $periodoFinal, ')
          ..write('finalidadeArquivo: $finalidadeArquivo')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(
      id, dataEmissao, periodoInicial, periodoFinal, finalidadeArquivo);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is EfdContribuicoes &&
          other.id == this.id &&
          other.dataEmissao == this.dataEmissao &&
          other.periodoInicial == this.periodoInicial &&
          other.periodoFinal == this.periodoFinal &&
          other.finalidadeArquivo == this.finalidadeArquivo);
}

class EfdContribuicoessCompanion extends UpdateCompanion<EfdContribuicoes> {
  final Value<int?> id;
  final Value<DateTime?> dataEmissao;
  final Value<DateTime?> periodoInicial;
  final Value<DateTime?> periodoFinal;
  final Value<String?> finalidadeArquivo;
  const EfdContribuicoessCompanion({
    this.id = const Value.absent(),
    this.dataEmissao = const Value.absent(),
    this.periodoInicial = const Value.absent(),
    this.periodoFinal = const Value.absent(),
    this.finalidadeArquivo = const Value.absent(),
  });
  EfdContribuicoessCompanion.insert({
    this.id = const Value.absent(),
    this.dataEmissao = const Value.absent(),
    this.periodoInicial = const Value.absent(),
    this.periodoFinal = const Value.absent(),
    this.finalidadeArquivo = const Value.absent(),
  });
  static Insertable<EfdContribuicoes> custom({
    Expression<int>? id,
    Expression<DateTime>? dataEmissao,
    Expression<DateTime>? periodoInicial,
    Expression<DateTime>? periodoFinal,
    Expression<String>? finalidadeArquivo,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (dataEmissao != null) 'data_emissao': dataEmissao,
      if (periodoInicial != null) 'periodo_inicial': periodoInicial,
      if (periodoFinal != null) 'periodo_final': periodoFinal,
      if (finalidadeArquivo != null) 'finalidade_arquivo': finalidadeArquivo,
    });
  }

  EfdContribuicoessCompanion copyWith(
      {Value<int?>? id,
      Value<DateTime?>? dataEmissao,
      Value<DateTime?>? periodoInicial,
      Value<DateTime?>? periodoFinal,
      Value<String?>? finalidadeArquivo}) {
    return EfdContribuicoessCompanion(
      id: id ?? this.id,
      dataEmissao: dataEmissao ?? this.dataEmissao,
      periodoInicial: periodoInicial ?? this.periodoInicial,
      periodoFinal: periodoFinal ?? this.periodoFinal,
      finalidadeArquivo: finalidadeArquivo ?? this.finalidadeArquivo,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (dataEmissao.present) {
      map['data_emissao'] = Variable<DateTime>(dataEmissao.value);
    }
    if (periodoInicial.present) {
      map['periodo_inicial'] = Variable<DateTime>(periodoInicial.value);
    }
    if (periodoFinal.present) {
      map['periodo_final'] = Variable<DateTime>(periodoFinal.value);
    }
    if (finalidadeArquivo.present) {
      map['finalidade_arquivo'] = Variable<String>(finalidadeArquivo.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('EfdContribuicoessCompanion(')
          ..write('id: $id, ')
          ..write('dataEmissao: $dataEmissao, ')
          ..write('periodoInicial: $periodoInicial, ')
          ..write('periodoFinal: $periodoFinal, ')
          ..write('finalidadeArquivo: $finalidadeArquivo')
          ..write(')'))
        .toString();
  }
}

class $EfdReinfsTable extends EfdReinfs
    with TableInfo<$EfdReinfsTable, EfdReinf> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $EfdReinfsTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
      'id', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _dataEmissaoMeta =
      const VerificationMeta('dataEmissao');
  @override
  late final GeneratedColumn<DateTime> dataEmissao = GeneratedColumn<DateTime>(
      'data_emissao', aliasedName, true,
      type: DriftSqlType.dateTime, requiredDuringInsert: false);
  static const VerificationMeta _periodoInicialMeta =
      const VerificationMeta('periodoInicial');
  @override
  late final GeneratedColumn<DateTime> periodoInicial =
      GeneratedColumn<DateTime>('periodo_inicial', aliasedName, true,
          type: DriftSqlType.dateTime, requiredDuringInsert: false);
  static const VerificationMeta _periodoFinalMeta =
      const VerificationMeta('periodoFinal');
  @override
  late final GeneratedColumn<DateTime> periodoFinal = GeneratedColumn<DateTime>(
      'periodo_final', aliasedName, true,
      type: DriftSqlType.dateTime, requiredDuringInsert: false);
  static const VerificationMeta _finalidadeArquivoMeta =
      const VerificationMeta('finalidadeArquivo');
  @override
  late final GeneratedColumn<String> finalidadeArquivo =
      GeneratedColumn<String>('finalidade_arquivo', aliasedName, true,
          additionalChecks: GeneratedColumn.checkTextLength(
              minTextLength: 0, maxTextLength: 100),
          type: DriftSqlType.string,
          requiredDuringInsert: false);
  @override
  List<GeneratedColumn> get $columns =>
      [id, dataEmissao, periodoInicial, periodoFinal, finalidadeArquivo];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'efd_reinf';
  @override
  VerificationContext validateIntegrity(Insertable<EfdReinf> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('data_emissao')) {
      context.handle(
          _dataEmissaoMeta,
          dataEmissao.isAcceptableOrUnknown(
              data['data_emissao']!, _dataEmissaoMeta));
    }
    if (data.containsKey('periodo_inicial')) {
      context.handle(
          _periodoInicialMeta,
          periodoInicial.isAcceptableOrUnknown(
              data['periodo_inicial']!, _periodoInicialMeta));
    }
    if (data.containsKey('periodo_final')) {
      context.handle(
          _periodoFinalMeta,
          periodoFinal.isAcceptableOrUnknown(
              data['periodo_final']!, _periodoFinalMeta));
    }
    if (data.containsKey('finalidade_arquivo')) {
      context.handle(
          _finalidadeArquivoMeta,
          finalidadeArquivo.isAcceptableOrUnknown(
              data['finalidade_arquivo']!, _finalidadeArquivoMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  EfdReinf map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return EfdReinf(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id']),
      dataEmissao: attachedDatabase.typeMapping
          .read(DriftSqlType.dateTime, data['${effectivePrefix}data_emissao']),
      periodoInicial: attachedDatabase.typeMapping.read(
          DriftSqlType.dateTime, data['${effectivePrefix}periodo_inicial']),
      periodoFinal: attachedDatabase.typeMapping
          .read(DriftSqlType.dateTime, data['${effectivePrefix}periodo_final']),
      finalidadeArquivo: attachedDatabase.typeMapping.read(
          DriftSqlType.string, data['${effectivePrefix}finalidade_arquivo']),
    );
  }

  @override
  $EfdReinfsTable createAlias(String alias) {
    return $EfdReinfsTable(attachedDatabase, alias);
  }
}

class EfdReinf extends DataClass implements Insertable<EfdReinf> {
  final int? id;
  final DateTime? dataEmissao;
  final DateTime? periodoInicial;
  final DateTime? periodoFinal;
  final String? finalidadeArquivo;
  const EfdReinf(
      {this.id,
      this.dataEmissao,
      this.periodoInicial,
      this.periodoFinal,
      this.finalidadeArquivo});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || dataEmissao != null) {
      map['data_emissao'] = Variable<DateTime>(dataEmissao);
    }
    if (!nullToAbsent || periodoInicial != null) {
      map['periodo_inicial'] = Variable<DateTime>(periodoInicial);
    }
    if (!nullToAbsent || periodoFinal != null) {
      map['periodo_final'] = Variable<DateTime>(periodoFinal);
    }
    if (!nullToAbsent || finalidadeArquivo != null) {
      map['finalidade_arquivo'] = Variable<String>(finalidadeArquivo);
    }
    return map;
  }

  factory EfdReinf.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return EfdReinf(
      id: serializer.fromJson<int?>(json['id']),
      dataEmissao: serializer.fromJson<DateTime?>(json['dataEmissao']),
      periodoInicial: serializer.fromJson<DateTime?>(json['periodoInicial']),
      periodoFinal: serializer.fromJson<DateTime?>(json['periodoFinal']),
      finalidadeArquivo:
          serializer.fromJson<String?>(json['finalidadeArquivo']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'dataEmissao': serializer.toJson<DateTime?>(dataEmissao),
      'periodoInicial': serializer.toJson<DateTime?>(periodoInicial),
      'periodoFinal': serializer.toJson<DateTime?>(periodoFinal),
      'finalidadeArquivo': serializer.toJson<String?>(finalidadeArquivo),
    };
  }

  EfdReinf copyWith(
          {Value<int?> id = const Value.absent(),
          Value<DateTime?> dataEmissao = const Value.absent(),
          Value<DateTime?> periodoInicial = const Value.absent(),
          Value<DateTime?> periodoFinal = const Value.absent(),
          Value<String?> finalidadeArquivo = const Value.absent()}) =>
      EfdReinf(
        id: id.present ? id.value : this.id,
        dataEmissao: dataEmissao.present ? dataEmissao.value : this.dataEmissao,
        periodoInicial:
            periodoInicial.present ? periodoInicial.value : this.periodoInicial,
        periodoFinal:
            periodoFinal.present ? periodoFinal.value : this.periodoFinal,
        finalidadeArquivo: finalidadeArquivo.present
            ? finalidadeArquivo.value
            : this.finalidadeArquivo,
      );
  EfdReinf copyWithCompanion(EfdReinfsCompanion data) {
    return EfdReinf(
      id: data.id.present ? data.id.value : this.id,
      dataEmissao:
          data.dataEmissao.present ? data.dataEmissao.value : this.dataEmissao,
      periodoInicial: data.periodoInicial.present
          ? data.periodoInicial.value
          : this.periodoInicial,
      periodoFinal: data.periodoFinal.present
          ? data.periodoFinal.value
          : this.periodoFinal,
      finalidadeArquivo: data.finalidadeArquivo.present
          ? data.finalidadeArquivo.value
          : this.finalidadeArquivo,
    );
  }

  @override
  String toString() {
    return (StringBuffer('EfdReinf(')
          ..write('id: $id, ')
          ..write('dataEmissao: $dataEmissao, ')
          ..write('periodoInicial: $periodoInicial, ')
          ..write('periodoFinal: $periodoFinal, ')
          ..write('finalidadeArquivo: $finalidadeArquivo')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(
      id, dataEmissao, periodoInicial, periodoFinal, finalidadeArquivo);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is EfdReinf &&
          other.id == this.id &&
          other.dataEmissao == this.dataEmissao &&
          other.periodoInicial == this.periodoInicial &&
          other.periodoFinal == this.periodoFinal &&
          other.finalidadeArquivo == this.finalidadeArquivo);
}

class EfdReinfsCompanion extends UpdateCompanion<EfdReinf> {
  final Value<int?> id;
  final Value<DateTime?> dataEmissao;
  final Value<DateTime?> periodoInicial;
  final Value<DateTime?> periodoFinal;
  final Value<String?> finalidadeArquivo;
  const EfdReinfsCompanion({
    this.id = const Value.absent(),
    this.dataEmissao = const Value.absent(),
    this.periodoInicial = const Value.absent(),
    this.periodoFinal = const Value.absent(),
    this.finalidadeArquivo = const Value.absent(),
  });
  EfdReinfsCompanion.insert({
    this.id = const Value.absent(),
    this.dataEmissao = const Value.absent(),
    this.periodoInicial = const Value.absent(),
    this.periodoFinal = const Value.absent(),
    this.finalidadeArquivo = const Value.absent(),
  });
  static Insertable<EfdReinf> custom({
    Expression<int>? id,
    Expression<DateTime>? dataEmissao,
    Expression<DateTime>? periodoInicial,
    Expression<DateTime>? periodoFinal,
    Expression<String>? finalidadeArquivo,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (dataEmissao != null) 'data_emissao': dataEmissao,
      if (periodoInicial != null) 'periodo_inicial': periodoInicial,
      if (periodoFinal != null) 'periodo_final': periodoFinal,
      if (finalidadeArquivo != null) 'finalidade_arquivo': finalidadeArquivo,
    });
  }

  EfdReinfsCompanion copyWith(
      {Value<int?>? id,
      Value<DateTime?>? dataEmissao,
      Value<DateTime?>? periodoInicial,
      Value<DateTime?>? periodoFinal,
      Value<String?>? finalidadeArquivo}) {
    return EfdReinfsCompanion(
      id: id ?? this.id,
      dataEmissao: dataEmissao ?? this.dataEmissao,
      periodoInicial: periodoInicial ?? this.periodoInicial,
      periodoFinal: periodoFinal ?? this.periodoFinal,
      finalidadeArquivo: finalidadeArquivo ?? this.finalidadeArquivo,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (dataEmissao.present) {
      map['data_emissao'] = Variable<DateTime>(dataEmissao.value);
    }
    if (periodoInicial.present) {
      map['periodo_inicial'] = Variable<DateTime>(periodoInicial.value);
    }
    if (periodoFinal.present) {
      map['periodo_final'] = Variable<DateTime>(periodoFinal.value);
    }
    if (finalidadeArquivo.present) {
      map['finalidade_arquivo'] = Variable<String>(finalidadeArquivo.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('EfdReinfsCompanion(')
          ..write('id: $id, ')
          ..write('dataEmissao: $dataEmissao, ')
          ..write('periodoInicial: $periodoInicial, ')
          ..write('periodoFinal: $periodoFinal, ')
          ..write('finalidadeArquivo: $finalidadeArquivo')
          ..write(')'))
        .toString();
  }
}

abstract class _$AppDatabase extends GeneratedDatabase {
  _$AppDatabase(QueryExecutor e) : super(e);
  $AppDatabaseManager get managers => $AppDatabaseManager(this);
  late final $SpedContabilsTable spedContabils = $SpedContabilsTable(this);
  late final $ViewControleAcessosTable viewControleAcessos =
      $ViewControleAcessosTable(this);
  late final $ViewPessoaUsuariosTable viewPessoaUsuarios =
      $ViewPessoaUsuariosTable(this);
  late final $SpedFiscalsTable spedFiscals = $SpedFiscalsTable(this);
  late final $SintegrasTable sintegras = $SintegrasTable(this);
  late final $EfdContribuicoessTable efdContribuicoess =
      $EfdContribuicoessTable(this);
  late final $EfdReinfsTable efdReinfs = $EfdReinfsTable(this);
  late final SpedContabilDao spedContabilDao =
      SpedContabilDao(this as AppDatabase);
  late final ViewControleAcessoDao viewControleAcessoDao =
      ViewControleAcessoDao(this as AppDatabase);
  late final ViewPessoaUsuarioDao viewPessoaUsuarioDao =
      ViewPessoaUsuarioDao(this as AppDatabase);
  late final SpedFiscalDao spedFiscalDao = SpedFiscalDao(this as AppDatabase);
  late final SintegraDao sintegraDao = SintegraDao(this as AppDatabase);
  late final EfdContribuicoesDao efdContribuicoesDao =
      EfdContribuicoesDao(this as AppDatabase);
  late final EfdReinfDao efdReinfDao = EfdReinfDao(this as AppDatabase);
  @override
  Iterable<TableInfo<Table, Object?>> get allTables =>
      allSchemaEntities.whereType<TableInfo<Table, Object?>>();
  @override
  List<DatabaseSchemaEntity> get allSchemaEntities => [
        spedContabils,
        viewControleAcessos,
        viewPessoaUsuarios,
        spedFiscals,
        sintegras,
        efdContribuicoess,
        efdReinfs
      ];
}

typedef $$SpedContabilsTableCreateCompanionBuilder = SpedContabilsCompanion
    Function({
  Value<int?> id,
  Value<DateTime?> dataEmissao,
  Value<DateTime?> periodoInicial,
  Value<DateTime?> periodoFinal,
  Value<String?> formaEscrituracao,
  Value<String?> versaoLayout,
});
typedef $$SpedContabilsTableUpdateCompanionBuilder = SpedContabilsCompanion
    Function({
  Value<int?> id,
  Value<DateTime?> dataEmissao,
  Value<DateTime?> periodoInicial,
  Value<DateTime?> periodoFinal,
  Value<String?> formaEscrituracao,
  Value<String?> versaoLayout,
});

class $$SpedContabilsTableTableManager extends RootTableManager<
    _$AppDatabase,
    $SpedContabilsTable,
    SpedContabil,
    $$SpedContabilsTableFilterComposer,
    $$SpedContabilsTableOrderingComposer,
    $$SpedContabilsTableCreateCompanionBuilder,
    $$SpedContabilsTableUpdateCompanionBuilder> {
  $$SpedContabilsTableTableManager(_$AppDatabase db, $SpedContabilsTable table)
      : super(TableManagerState(
          db: db,
          table: table,
          filteringComposer:
              $$SpedContabilsTableFilterComposer(ComposerState(db, table)),
          orderingComposer:
              $$SpedContabilsTableOrderingComposer(ComposerState(db, table)),
          updateCompanionCallback: ({
            Value<int?> id = const Value.absent(),
            Value<DateTime?> dataEmissao = const Value.absent(),
            Value<DateTime?> periodoInicial = const Value.absent(),
            Value<DateTime?> periodoFinal = const Value.absent(),
            Value<String?> formaEscrituracao = const Value.absent(),
            Value<String?> versaoLayout = const Value.absent(),
          }) =>
              SpedContabilsCompanion(
            id: id,
            dataEmissao: dataEmissao,
            periodoInicial: periodoInicial,
            periodoFinal: periodoFinal,
            formaEscrituracao: formaEscrituracao,
            versaoLayout: versaoLayout,
          ),
          createCompanionCallback: ({
            Value<int?> id = const Value.absent(),
            Value<DateTime?> dataEmissao = const Value.absent(),
            Value<DateTime?> periodoInicial = const Value.absent(),
            Value<DateTime?> periodoFinal = const Value.absent(),
            Value<String?> formaEscrituracao = const Value.absent(),
            Value<String?> versaoLayout = const Value.absent(),
          }) =>
              SpedContabilsCompanion.insert(
            id: id,
            dataEmissao: dataEmissao,
            periodoInicial: periodoInicial,
            periodoFinal: periodoFinal,
            formaEscrituracao: formaEscrituracao,
            versaoLayout: versaoLayout,
          ),
        ));
}

class $$SpedContabilsTableFilterComposer
    extends FilterComposer<_$AppDatabase, $SpedContabilsTable> {
  $$SpedContabilsTableFilterComposer(super.$state);
  ColumnFilters<int> get id => $state.composableBuilder(
      column: $state.table.id,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<DateTime> get dataEmissao => $state.composableBuilder(
      column: $state.table.dataEmissao,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<DateTime> get periodoInicial => $state.composableBuilder(
      column: $state.table.periodoInicial,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<DateTime> get periodoFinal => $state.composableBuilder(
      column: $state.table.periodoFinal,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get formaEscrituracao => $state.composableBuilder(
      column: $state.table.formaEscrituracao,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get versaoLayout => $state.composableBuilder(
      column: $state.table.versaoLayout,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));
}

class $$SpedContabilsTableOrderingComposer
    extends OrderingComposer<_$AppDatabase, $SpedContabilsTable> {
  $$SpedContabilsTableOrderingComposer(super.$state);
  ColumnOrderings<int> get id => $state.composableBuilder(
      column: $state.table.id,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<DateTime> get dataEmissao => $state.composableBuilder(
      column: $state.table.dataEmissao,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<DateTime> get periodoInicial => $state.composableBuilder(
      column: $state.table.periodoInicial,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<DateTime> get periodoFinal => $state.composableBuilder(
      column: $state.table.periodoFinal,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get formaEscrituracao => $state.composableBuilder(
      column: $state.table.formaEscrituracao,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get versaoLayout => $state.composableBuilder(
      column: $state.table.versaoLayout,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));
}

typedef $$ViewControleAcessosTableCreateCompanionBuilder
    = ViewControleAcessosCompanion Function({
  Value<int?> id,
  Value<int?> idPessoa,
  Value<String?> pessoaNome,
  Value<int?> idColaborador,
  Value<int?> idUsuario,
  Value<String?> administrador,
  Value<int?> idPapel,
  Value<String?> papelNome,
  Value<String?> papelDescricao,
  Value<int?> idFuncao,
  Value<String?> funcaoNome,
  Value<String?> funcaoDescricao,
  Value<int?> idPapelFuncao,
  Value<String?> habilitado,
  Value<String?> podeInserir,
  Value<String?> podeAlterar,
  Value<String?> podeExcluir,
});
typedef $$ViewControleAcessosTableUpdateCompanionBuilder
    = ViewControleAcessosCompanion Function({
  Value<int?> id,
  Value<int?> idPessoa,
  Value<String?> pessoaNome,
  Value<int?> idColaborador,
  Value<int?> idUsuario,
  Value<String?> administrador,
  Value<int?> idPapel,
  Value<String?> papelNome,
  Value<String?> papelDescricao,
  Value<int?> idFuncao,
  Value<String?> funcaoNome,
  Value<String?> funcaoDescricao,
  Value<int?> idPapelFuncao,
  Value<String?> habilitado,
  Value<String?> podeInserir,
  Value<String?> podeAlterar,
  Value<String?> podeExcluir,
});

class $$ViewControleAcessosTableTableManager extends RootTableManager<
    _$AppDatabase,
    $ViewControleAcessosTable,
    ViewControleAcesso,
    $$ViewControleAcessosTableFilterComposer,
    $$ViewControleAcessosTableOrderingComposer,
    $$ViewControleAcessosTableCreateCompanionBuilder,
    $$ViewControleAcessosTableUpdateCompanionBuilder> {
  $$ViewControleAcessosTableTableManager(
      _$AppDatabase db, $ViewControleAcessosTable table)
      : super(TableManagerState(
          db: db,
          table: table,
          filteringComposer: $$ViewControleAcessosTableFilterComposer(
              ComposerState(db, table)),
          orderingComposer: $$ViewControleAcessosTableOrderingComposer(
              ComposerState(db, table)),
          updateCompanionCallback: ({
            Value<int?> id = const Value.absent(),
            Value<int?> idPessoa = const Value.absent(),
            Value<String?> pessoaNome = const Value.absent(),
            Value<int?> idColaborador = const Value.absent(),
            Value<int?> idUsuario = const Value.absent(),
            Value<String?> administrador = const Value.absent(),
            Value<int?> idPapel = const Value.absent(),
            Value<String?> papelNome = const Value.absent(),
            Value<String?> papelDescricao = const Value.absent(),
            Value<int?> idFuncao = const Value.absent(),
            Value<String?> funcaoNome = const Value.absent(),
            Value<String?> funcaoDescricao = const Value.absent(),
            Value<int?> idPapelFuncao = const Value.absent(),
            Value<String?> habilitado = const Value.absent(),
            Value<String?> podeInserir = const Value.absent(),
            Value<String?> podeAlterar = const Value.absent(),
            Value<String?> podeExcluir = const Value.absent(),
          }) =>
              ViewControleAcessosCompanion(
            id: id,
            idPessoa: idPessoa,
            pessoaNome: pessoaNome,
            idColaborador: idColaborador,
            idUsuario: idUsuario,
            administrador: administrador,
            idPapel: idPapel,
            papelNome: papelNome,
            papelDescricao: papelDescricao,
            idFuncao: idFuncao,
            funcaoNome: funcaoNome,
            funcaoDescricao: funcaoDescricao,
            idPapelFuncao: idPapelFuncao,
            habilitado: habilitado,
            podeInserir: podeInserir,
            podeAlterar: podeAlterar,
            podeExcluir: podeExcluir,
          ),
          createCompanionCallback: ({
            Value<int?> id = const Value.absent(),
            Value<int?> idPessoa = const Value.absent(),
            Value<String?> pessoaNome = const Value.absent(),
            Value<int?> idColaborador = const Value.absent(),
            Value<int?> idUsuario = const Value.absent(),
            Value<String?> administrador = const Value.absent(),
            Value<int?> idPapel = const Value.absent(),
            Value<String?> papelNome = const Value.absent(),
            Value<String?> papelDescricao = const Value.absent(),
            Value<int?> idFuncao = const Value.absent(),
            Value<String?> funcaoNome = const Value.absent(),
            Value<String?> funcaoDescricao = const Value.absent(),
            Value<int?> idPapelFuncao = const Value.absent(),
            Value<String?> habilitado = const Value.absent(),
            Value<String?> podeInserir = const Value.absent(),
            Value<String?> podeAlterar = const Value.absent(),
            Value<String?> podeExcluir = const Value.absent(),
          }) =>
              ViewControleAcessosCompanion.insert(
            id: id,
            idPessoa: idPessoa,
            pessoaNome: pessoaNome,
            idColaborador: idColaborador,
            idUsuario: idUsuario,
            administrador: administrador,
            idPapel: idPapel,
            papelNome: papelNome,
            papelDescricao: papelDescricao,
            idFuncao: idFuncao,
            funcaoNome: funcaoNome,
            funcaoDescricao: funcaoDescricao,
            idPapelFuncao: idPapelFuncao,
            habilitado: habilitado,
            podeInserir: podeInserir,
            podeAlterar: podeAlterar,
            podeExcluir: podeExcluir,
          ),
        ));
}

class $$ViewControleAcessosTableFilterComposer
    extends FilterComposer<_$AppDatabase, $ViewControleAcessosTable> {
  $$ViewControleAcessosTableFilterComposer(super.$state);
  ColumnFilters<int> get id => $state.composableBuilder(
      column: $state.table.id,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<int> get idPessoa => $state.composableBuilder(
      column: $state.table.idPessoa,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get pessoaNome => $state.composableBuilder(
      column: $state.table.pessoaNome,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<int> get idColaborador => $state.composableBuilder(
      column: $state.table.idColaborador,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<int> get idUsuario => $state.composableBuilder(
      column: $state.table.idUsuario,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get administrador => $state.composableBuilder(
      column: $state.table.administrador,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<int> get idPapel => $state.composableBuilder(
      column: $state.table.idPapel,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get papelNome => $state.composableBuilder(
      column: $state.table.papelNome,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get papelDescricao => $state.composableBuilder(
      column: $state.table.papelDescricao,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<int> get idFuncao => $state.composableBuilder(
      column: $state.table.idFuncao,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get funcaoNome => $state.composableBuilder(
      column: $state.table.funcaoNome,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get funcaoDescricao => $state.composableBuilder(
      column: $state.table.funcaoDescricao,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<int> get idPapelFuncao => $state.composableBuilder(
      column: $state.table.idPapelFuncao,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get habilitado => $state.composableBuilder(
      column: $state.table.habilitado,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get podeInserir => $state.composableBuilder(
      column: $state.table.podeInserir,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get podeAlterar => $state.composableBuilder(
      column: $state.table.podeAlterar,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get podeExcluir => $state.composableBuilder(
      column: $state.table.podeExcluir,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));
}

class $$ViewControleAcessosTableOrderingComposer
    extends OrderingComposer<_$AppDatabase, $ViewControleAcessosTable> {
  $$ViewControleAcessosTableOrderingComposer(super.$state);
  ColumnOrderings<int> get id => $state.composableBuilder(
      column: $state.table.id,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<int> get idPessoa => $state.composableBuilder(
      column: $state.table.idPessoa,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get pessoaNome => $state.composableBuilder(
      column: $state.table.pessoaNome,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<int> get idColaborador => $state.composableBuilder(
      column: $state.table.idColaborador,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<int> get idUsuario => $state.composableBuilder(
      column: $state.table.idUsuario,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get administrador => $state.composableBuilder(
      column: $state.table.administrador,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<int> get idPapel => $state.composableBuilder(
      column: $state.table.idPapel,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get papelNome => $state.composableBuilder(
      column: $state.table.papelNome,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get papelDescricao => $state.composableBuilder(
      column: $state.table.papelDescricao,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<int> get idFuncao => $state.composableBuilder(
      column: $state.table.idFuncao,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get funcaoNome => $state.composableBuilder(
      column: $state.table.funcaoNome,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get funcaoDescricao => $state.composableBuilder(
      column: $state.table.funcaoDescricao,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<int> get idPapelFuncao => $state.composableBuilder(
      column: $state.table.idPapelFuncao,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get habilitado => $state.composableBuilder(
      column: $state.table.habilitado,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get podeInserir => $state.composableBuilder(
      column: $state.table.podeInserir,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get podeAlterar => $state.composableBuilder(
      column: $state.table.podeAlterar,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get podeExcluir => $state.composableBuilder(
      column: $state.table.podeExcluir,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));
}

typedef $$ViewPessoaUsuariosTableCreateCompanionBuilder
    = ViewPessoaUsuariosCompanion Function({
  Value<int?> id,
  Value<int?> idPessoa,
  Value<String?> pessoaNome,
  Value<String?> tipo,
  Value<String?> email,
  Value<int?> idColaborador,
  Value<int?> idUsuario,
  Value<String?> login,
  Value<String?> senha,
  Value<DateTime?> dataCadastro,
  Value<String?> administrador,
});
typedef $$ViewPessoaUsuariosTableUpdateCompanionBuilder
    = ViewPessoaUsuariosCompanion Function({
  Value<int?> id,
  Value<int?> idPessoa,
  Value<String?> pessoaNome,
  Value<String?> tipo,
  Value<String?> email,
  Value<int?> idColaborador,
  Value<int?> idUsuario,
  Value<String?> login,
  Value<String?> senha,
  Value<DateTime?> dataCadastro,
  Value<String?> administrador,
});

class $$ViewPessoaUsuariosTableTableManager extends RootTableManager<
    _$AppDatabase,
    $ViewPessoaUsuariosTable,
    ViewPessoaUsuario,
    $$ViewPessoaUsuariosTableFilterComposer,
    $$ViewPessoaUsuariosTableOrderingComposer,
    $$ViewPessoaUsuariosTableCreateCompanionBuilder,
    $$ViewPessoaUsuariosTableUpdateCompanionBuilder> {
  $$ViewPessoaUsuariosTableTableManager(
      _$AppDatabase db, $ViewPessoaUsuariosTable table)
      : super(TableManagerState(
          db: db,
          table: table,
          filteringComposer:
              $$ViewPessoaUsuariosTableFilterComposer(ComposerState(db, table)),
          orderingComposer: $$ViewPessoaUsuariosTableOrderingComposer(
              ComposerState(db, table)),
          updateCompanionCallback: ({
            Value<int?> id = const Value.absent(),
            Value<int?> idPessoa = const Value.absent(),
            Value<String?> pessoaNome = const Value.absent(),
            Value<String?> tipo = const Value.absent(),
            Value<String?> email = const Value.absent(),
            Value<int?> idColaborador = const Value.absent(),
            Value<int?> idUsuario = const Value.absent(),
            Value<String?> login = const Value.absent(),
            Value<String?> senha = const Value.absent(),
            Value<DateTime?> dataCadastro = const Value.absent(),
            Value<String?> administrador = const Value.absent(),
          }) =>
              ViewPessoaUsuariosCompanion(
            id: id,
            idPessoa: idPessoa,
            pessoaNome: pessoaNome,
            tipo: tipo,
            email: email,
            idColaborador: idColaborador,
            idUsuario: idUsuario,
            login: login,
            senha: senha,
            dataCadastro: dataCadastro,
            administrador: administrador,
          ),
          createCompanionCallback: ({
            Value<int?> id = const Value.absent(),
            Value<int?> idPessoa = const Value.absent(),
            Value<String?> pessoaNome = const Value.absent(),
            Value<String?> tipo = const Value.absent(),
            Value<String?> email = const Value.absent(),
            Value<int?> idColaborador = const Value.absent(),
            Value<int?> idUsuario = const Value.absent(),
            Value<String?> login = const Value.absent(),
            Value<String?> senha = const Value.absent(),
            Value<DateTime?> dataCadastro = const Value.absent(),
            Value<String?> administrador = const Value.absent(),
          }) =>
              ViewPessoaUsuariosCompanion.insert(
            id: id,
            idPessoa: idPessoa,
            pessoaNome: pessoaNome,
            tipo: tipo,
            email: email,
            idColaborador: idColaborador,
            idUsuario: idUsuario,
            login: login,
            senha: senha,
            dataCadastro: dataCadastro,
            administrador: administrador,
          ),
        ));
}

class $$ViewPessoaUsuariosTableFilterComposer
    extends FilterComposer<_$AppDatabase, $ViewPessoaUsuariosTable> {
  $$ViewPessoaUsuariosTableFilterComposer(super.$state);
  ColumnFilters<int> get id => $state.composableBuilder(
      column: $state.table.id,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<int> get idPessoa => $state.composableBuilder(
      column: $state.table.idPessoa,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get pessoaNome => $state.composableBuilder(
      column: $state.table.pessoaNome,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get tipo => $state.composableBuilder(
      column: $state.table.tipo,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get email => $state.composableBuilder(
      column: $state.table.email,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<int> get idColaborador => $state.composableBuilder(
      column: $state.table.idColaborador,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<int> get idUsuario => $state.composableBuilder(
      column: $state.table.idUsuario,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get login => $state.composableBuilder(
      column: $state.table.login,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get senha => $state.composableBuilder(
      column: $state.table.senha,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<DateTime> get dataCadastro => $state.composableBuilder(
      column: $state.table.dataCadastro,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get administrador => $state.composableBuilder(
      column: $state.table.administrador,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));
}

class $$ViewPessoaUsuariosTableOrderingComposer
    extends OrderingComposer<_$AppDatabase, $ViewPessoaUsuariosTable> {
  $$ViewPessoaUsuariosTableOrderingComposer(super.$state);
  ColumnOrderings<int> get id => $state.composableBuilder(
      column: $state.table.id,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<int> get idPessoa => $state.composableBuilder(
      column: $state.table.idPessoa,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get pessoaNome => $state.composableBuilder(
      column: $state.table.pessoaNome,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get tipo => $state.composableBuilder(
      column: $state.table.tipo,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get email => $state.composableBuilder(
      column: $state.table.email,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<int> get idColaborador => $state.composableBuilder(
      column: $state.table.idColaborador,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<int> get idUsuario => $state.composableBuilder(
      column: $state.table.idUsuario,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get login => $state.composableBuilder(
      column: $state.table.login,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get senha => $state.composableBuilder(
      column: $state.table.senha,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<DateTime> get dataCadastro => $state.composableBuilder(
      column: $state.table.dataCadastro,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get administrador => $state.composableBuilder(
      column: $state.table.administrador,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));
}

typedef $$SpedFiscalsTableCreateCompanionBuilder = SpedFiscalsCompanion
    Function({
  Value<int?> id,
  Value<DateTime?> dataEmissao,
  Value<DateTime?> periodoInicial,
  Value<DateTime?> periodoFinal,
  Value<String?> perfilApresentacao,
  Value<String?> finalidadeArquivo,
  Value<String?> versaoLayout,
});
typedef $$SpedFiscalsTableUpdateCompanionBuilder = SpedFiscalsCompanion
    Function({
  Value<int?> id,
  Value<DateTime?> dataEmissao,
  Value<DateTime?> periodoInicial,
  Value<DateTime?> periodoFinal,
  Value<String?> perfilApresentacao,
  Value<String?> finalidadeArquivo,
  Value<String?> versaoLayout,
});

class $$SpedFiscalsTableTableManager extends RootTableManager<
    _$AppDatabase,
    $SpedFiscalsTable,
    SpedFiscal,
    $$SpedFiscalsTableFilterComposer,
    $$SpedFiscalsTableOrderingComposer,
    $$SpedFiscalsTableCreateCompanionBuilder,
    $$SpedFiscalsTableUpdateCompanionBuilder> {
  $$SpedFiscalsTableTableManager(_$AppDatabase db, $SpedFiscalsTable table)
      : super(TableManagerState(
          db: db,
          table: table,
          filteringComposer:
              $$SpedFiscalsTableFilterComposer(ComposerState(db, table)),
          orderingComposer:
              $$SpedFiscalsTableOrderingComposer(ComposerState(db, table)),
          updateCompanionCallback: ({
            Value<int?> id = const Value.absent(),
            Value<DateTime?> dataEmissao = const Value.absent(),
            Value<DateTime?> periodoInicial = const Value.absent(),
            Value<DateTime?> periodoFinal = const Value.absent(),
            Value<String?> perfilApresentacao = const Value.absent(),
            Value<String?> finalidadeArquivo = const Value.absent(),
            Value<String?> versaoLayout = const Value.absent(),
          }) =>
              SpedFiscalsCompanion(
            id: id,
            dataEmissao: dataEmissao,
            periodoInicial: periodoInicial,
            periodoFinal: periodoFinal,
            perfilApresentacao: perfilApresentacao,
            finalidadeArquivo: finalidadeArquivo,
            versaoLayout: versaoLayout,
          ),
          createCompanionCallback: ({
            Value<int?> id = const Value.absent(),
            Value<DateTime?> dataEmissao = const Value.absent(),
            Value<DateTime?> periodoInicial = const Value.absent(),
            Value<DateTime?> periodoFinal = const Value.absent(),
            Value<String?> perfilApresentacao = const Value.absent(),
            Value<String?> finalidadeArquivo = const Value.absent(),
            Value<String?> versaoLayout = const Value.absent(),
          }) =>
              SpedFiscalsCompanion.insert(
            id: id,
            dataEmissao: dataEmissao,
            periodoInicial: periodoInicial,
            periodoFinal: periodoFinal,
            perfilApresentacao: perfilApresentacao,
            finalidadeArquivo: finalidadeArquivo,
            versaoLayout: versaoLayout,
          ),
        ));
}

class $$SpedFiscalsTableFilterComposer
    extends FilterComposer<_$AppDatabase, $SpedFiscalsTable> {
  $$SpedFiscalsTableFilterComposer(super.$state);
  ColumnFilters<int> get id => $state.composableBuilder(
      column: $state.table.id,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<DateTime> get dataEmissao => $state.composableBuilder(
      column: $state.table.dataEmissao,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<DateTime> get periodoInicial => $state.composableBuilder(
      column: $state.table.periodoInicial,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<DateTime> get periodoFinal => $state.composableBuilder(
      column: $state.table.periodoFinal,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get perfilApresentacao => $state.composableBuilder(
      column: $state.table.perfilApresentacao,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get finalidadeArquivo => $state.composableBuilder(
      column: $state.table.finalidadeArquivo,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get versaoLayout => $state.composableBuilder(
      column: $state.table.versaoLayout,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));
}

class $$SpedFiscalsTableOrderingComposer
    extends OrderingComposer<_$AppDatabase, $SpedFiscalsTable> {
  $$SpedFiscalsTableOrderingComposer(super.$state);
  ColumnOrderings<int> get id => $state.composableBuilder(
      column: $state.table.id,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<DateTime> get dataEmissao => $state.composableBuilder(
      column: $state.table.dataEmissao,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<DateTime> get periodoInicial => $state.composableBuilder(
      column: $state.table.periodoInicial,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<DateTime> get periodoFinal => $state.composableBuilder(
      column: $state.table.periodoFinal,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get perfilApresentacao => $state.composableBuilder(
      column: $state.table.perfilApresentacao,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get finalidadeArquivo => $state.composableBuilder(
      column: $state.table.finalidadeArquivo,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get versaoLayout => $state.composableBuilder(
      column: $state.table.versaoLayout,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));
}

typedef $$SintegrasTableCreateCompanionBuilder = SintegrasCompanion Function({
  Value<int?> id,
  Value<DateTime?> dataEmissao,
  Value<DateTime?> periodoInicial,
  Value<DateTime?> periodoFinal,
  Value<String?> codigoConvenio,
  Value<String?> finalidadeArquivo,
  Value<String?> inventario,
});
typedef $$SintegrasTableUpdateCompanionBuilder = SintegrasCompanion Function({
  Value<int?> id,
  Value<DateTime?> dataEmissao,
  Value<DateTime?> periodoInicial,
  Value<DateTime?> periodoFinal,
  Value<String?> codigoConvenio,
  Value<String?> finalidadeArquivo,
  Value<String?> inventario,
});

class $$SintegrasTableTableManager extends RootTableManager<
    _$AppDatabase,
    $SintegrasTable,
    Sintegra,
    $$SintegrasTableFilterComposer,
    $$SintegrasTableOrderingComposer,
    $$SintegrasTableCreateCompanionBuilder,
    $$SintegrasTableUpdateCompanionBuilder> {
  $$SintegrasTableTableManager(_$AppDatabase db, $SintegrasTable table)
      : super(TableManagerState(
          db: db,
          table: table,
          filteringComposer:
              $$SintegrasTableFilterComposer(ComposerState(db, table)),
          orderingComposer:
              $$SintegrasTableOrderingComposer(ComposerState(db, table)),
          updateCompanionCallback: ({
            Value<int?> id = const Value.absent(),
            Value<DateTime?> dataEmissao = const Value.absent(),
            Value<DateTime?> periodoInicial = const Value.absent(),
            Value<DateTime?> periodoFinal = const Value.absent(),
            Value<String?> codigoConvenio = const Value.absent(),
            Value<String?> finalidadeArquivo = const Value.absent(),
            Value<String?> inventario = const Value.absent(),
          }) =>
              SintegrasCompanion(
            id: id,
            dataEmissao: dataEmissao,
            periodoInicial: periodoInicial,
            periodoFinal: periodoFinal,
            codigoConvenio: codigoConvenio,
            finalidadeArquivo: finalidadeArquivo,
            inventario: inventario,
          ),
          createCompanionCallback: ({
            Value<int?> id = const Value.absent(),
            Value<DateTime?> dataEmissao = const Value.absent(),
            Value<DateTime?> periodoInicial = const Value.absent(),
            Value<DateTime?> periodoFinal = const Value.absent(),
            Value<String?> codigoConvenio = const Value.absent(),
            Value<String?> finalidadeArquivo = const Value.absent(),
            Value<String?> inventario = const Value.absent(),
          }) =>
              SintegrasCompanion.insert(
            id: id,
            dataEmissao: dataEmissao,
            periodoInicial: periodoInicial,
            periodoFinal: periodoFinal,
            codigoConvenio: codigoConvenio,
            finalidadeArquivo: finalidadeArquivo,
            inventario: inventario,
          ),
        ));
}

class $$SintegrasTableFilterComposer
    extends FilterComposer<_$AppDatabase, $SintegrasTable> {
  $$SintegrasTableFilterComposer(super.$state);
  ColumnFilters<int> get id => $state.composableBuilder(
      column: $state.table.id,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<DateTime> get dataEmissao => $state.composableBuilder(
      column: $state.table.dataEmissao,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<DateTime> get periodoInicial => $state.composableBuilder(
      column: $state.table.periodoInicial,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<DateTime> get periodoFinal => $state.composableBuilder(
      column: $state.table.periodoFinal,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get codigoConvenio => $state.composableBuilder(
      column: $state.table.codigoConvenio,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get finalidadeArquivo => $state.composableBuilder(
      column: $state.table.finalidadeArquivo,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get inventario => $state.composableBuilder(
      column: $state.table.inventario,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));
}

class $$SintegrasTableOrderingComposer
    extends OrderingComposer<_$AppDatabase, $SintegrasTable> {
  $$SintegrasTableOrderingComposer(super.$state);
  ColumnOrderings<int> get id => $state.composableBuilder(
      column: $state.table.id,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<DateTime> get dataEmissao => $state.composableBuilder(
      column: $state.table.dataEmissao,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<DateTime> get periodoInicial => $state.composableBuilder(
      column: $state.table.periodoInicial,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<DateTime> get periodoFinal => $state.composableBuilder(
      column: $state.table.periodoFinal,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get codigoConvenio => $state.composableBuilder(
      column: $state.table.codigoConvenio,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get finalidadeArquivo => $state.composableBuilder(
      column: $state.table.finalidadeArquivo,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get inventario => $state.composableBuilder(
      column: $state.table.inventario,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));
}

typedef $$EfdContribuicoessTableCreateCompanionBuilder
    = EfdContribuicoessCompanion Function({
  Value<int?> id,
  Value<DateTime?> dataEmissao,
  Value<DateTime?> periodoInicial,
  Value<DateTime?> periodoFinal,
  Value<String?> finalidadeArquivo,
});
typedef $$EfdContribuicoessTableUpdateCompanionBuilder
    = EfdContribuicoessCompanion Function({
  Value<int?> id,
  Value<DateTime?> dataEmissao,
  Value<DateTime?> periodoInicial,
  Value<DateTime?> periodoFinal,
  Value<String?> finalidadeArquivo,
});

class $$EfdContribuicoessTableTableManager extends RootTableManager<
    _$AppDatabase,
    $EfdContribuicoessTable,
    EfdContribuicoes,
    $$EfdContribuicoessTableFilterComposer,
    $$EfdContribuicoessTableOrderingComposer,
    $$EfdContribuicoessTableCreateCompanionBuilder,
    $$EfdContribuicoessTableUpdateCompanionBuilder> {
  $$EfdContribuicoessTableTableManager(
      _$AppDatabase db, $EfdContribuicoessTable table)
      : super(TableManagerState(
          db: db,
          table: table,
          filteringComposer:
              $$EfdContribuicoessTableFilterComposer(ComposerState(db, table)),
          orderingComposer: $$EfdContribuicoessTableOrderingComposer(
              ComposerState(db, table)),
          updateCompanionCallback: ({
            Value<int?> id = const Value.absent(),
            Value<DateTime?> dataEmissao = const Value.absent(),
            Value<DateTime?> periodoInicial = const Value.absent(),
            Value<DateTime?> periodoFinal = const Value.absent(),
            Value<String?> finalidadeArquivo = const Value.absent(),
          }) =>
              EfdContribuicoessCompanion(
            id: id,
            dataEmissao: dataEmissao,
            periodoInicial: periodoInicial,
            periodoFinal: periodoFinal,
            finalidadeArquivo: finalidadeArquivo,
          ),
          createCompanionCallback: ({
            Value<int?> id = const Value.absent(),
            Value<DateTime?> dataEmissao = const Value.absent(),
            Value<DateTime?> periodoInicial = const Value.absent(),
            Value<DateTime?> periodoFinal = const Value.absent(),
            Value<String?> finalidadeArquivo = const Value.absent(),
          }) =>
              EfdContribuicoessCompanion.insert(
            id: id,
            dataEmissao: dataEmissao,
            periodoInicial: periodoInicial,
            periodoFinal: periodoFinal,
            finalidadeArquivo: finalidadeArquivo,
          ),
        ));
}

class $$EfdContribuicoessTableFilterComposer
    extends FilterComposer<_$AppDatabase, $EfdContribuicoessTable> {
  $$EfdContribuicoessTableFilterComposer(super.$state);
  ColumnFilters<int> get id => $state.composableBuilder(
      column: $state.table.id,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<DateTime> get dataEmissao => $state.composableBuilder(
      column: $state.table.dataEmissao,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<DateTime> get periodoInicial => $state.composableBuilder(
      column: $state.table.periodoInicial,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<DateTime> get periodoFinal => $state.composableBuilder(
      column: $state.table.periodoFinal,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get finalidadeArquivo => $state.composableBuilder(
      column: $state.table.finalidadeArquivo,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));
}

class $$EfdContribuicoessTableOrderingComposer
    extends OrderingComposer<_$AppDatabase, $EfdContribuicoessTable> {
  $$EfdContribuicoessTableOrderingComposer(super.$state);
  ColumnOrderings<int> get id => $state.composableBuilder(
      column: $state.table.id,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<DateTime> get dataEmissao => $state.composableBuilder(
      column: $state.table.dataEmissao,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<DateTime> get periodoInicial => $state.composableBuilder(
      column: $state.table.periodoInicial,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<DateTime> get periodoFinal => $state.composableBuilder(
      column: $state.table.periodoFinal,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get finalidadeArquivo => $state.composableBuilder(
      column: $state.table.finalidadeArquivo,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));
}

typedef $$EfdReinfsTableCreateCompanionBuilder = EfdReinfsCompanion Function({
  Value<int?> id,
  Value<DateTime?> dataEmissao,
  Value<DateTime?> periodoInicial,
  Value<DateTime?> periodoFinal,
  Value<String?> finalidadeArquivo,
});
typedef $$EfdReinfsTableUpdateCompanionBuilder = EfdReinfsCompanion Function({
  Value<int?> id,
  Value<DateTime?> dataEmissao,
  Value<DateTime?> periodoInicial,
  Value<DateTime?> periodoFinal,
  Value<String?> finalidadeArquivo,
});

class $$EfdReinfsTableTableManager extends RootTableManager<
    _$AppDatabase,
    $EfdReinfsTable,
    EfdReinf,
    $$EfdReinfsTableFilterComposer,
    $$EfdReinfsTableOrderingComposer,
    $$EfdReinfsTableCreateCompanionBuilder,
    $$EfdReinfsTableUpdateCompanionBuilder> {
  $$EfdReinfsTableTableManager(_$AppDatabase db, $EfdReinfsTable table)
      : super(TableManagerState(
          db: db,
          table: table,
          filteringComposer:
              $$EfdReinfsTableFilterComposer(ComposerState(db, table)),
          orderingComposer:
              $$EfdReinfsTableOrderingComposer(ComposerState(db, table)),
          updateCompanionCallback: ({
            Value<int?> id = const Value.absent(),
            Value<DateTime?> dataEmissao = const Value.absent(),
            Value<DateTime?> periodoInicial = const Value.absent(),
            Value<DateTime?> periodoFinal = const Value.absent(),
            Value<String?> finalidadeArquivo = const Value.absent(),
          }) =>
              EfdReinfsCompanion(
            id: id,
            dataEmissao: dataEmissao,
            periodoInicial: periodoInicial,
            periodoFinal: periodoFinal,
            finalidadeArquivo: finalidadeArquivo,
          ),
          createCompanionCallback: ({
            Value<int?> id = const Value.absent(),
            Value<DateTime?> dataEmissao = const Value.absent(),
            Value<DateTime?> periodoInicial = const Value.absent(),
            Value<DateTime?> periodoFinal = const Value.absent(),
            Value<String?> finalidadeArquivo = const Value.absent(),
          }) =>
              EfdReinfsCompanion.insert(
            id: id,
            dataEmissao: dataEmissao,
            periodoInicial: periodoInicial,
            periodoFinal: periodoFinal,
            finalidadeArquivo: finalidadeArquivo,
          ),
        ));
}

class $$EfdReinfsTableFilterComposer
    extends FilterComposer<_$AppDatabase, $EfdReinfsTable> {
  $$EfdReinfsTableFilterComposer(super.$state);
  ColumnFilters<int> get id => $state.composableBuilder(
      column: $state.table.id,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<DateTime> get dataEmissao => $state.composableBuilder(
      column: $state.table.dataEmissao,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<DateTime> get periodoInicial => $state.composableBuilder(
      column: $state.table.periodoInicial,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<DateTime> get periodoFinal => $state.composableBuilder(
      column: $state.table.periodoFinal,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get finalidadeArquivo => $state.composableBuilder(
      column: $state.table.finalidadeArquivo,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));
}

class $$EfdReinfsTableOrderingComposer
    extends OrderingComposer<_$AppDatabase, $EfdReinfsTable> {
  $$EfdReinfsTableOrderingComposer(super.$state);
  ColumnOrderings<int> get id => $state.composableBuilder(
      column: $state.table.id,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<DateTime> get dataEmissao => $state.composableBuilder(
      column: $state.table.dataEmissao,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<DateTime> get periodoInicial => $state.composableBuilder(
      column: $state.table.periodoInicial,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<DateTime> get periodoFinal => $state.composableBuilder(
      column: $state.table.periodoFinal,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get finalidadeArquivo => $state.composableBuilder(
      column: $state.table.finalidadeArquivo,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));
}

class $AppDatabaseManager {
  final _$AppDatabase _db;
  $AppDatabaseManager(this._db);
  $$SpedContabilsTableTableManager get spedContabils =>
      $$SpedContabilsTableTableManager(_db, _db.spedContabils);
  $$ViewControleAcessosTableTableManager get viewControleAcessos =>
      $$ViewControleAcessosTableTableManager(_db, _db.viewControleAcessos);
  $$ViewPessoaUsuariosTableTableManager get viewPessoaUsuarios =>
      $$ViewPessoaUsuariosTableTableManager(_db, _db.viewPessoaUsuarios);
  $$SpedFiscalsTableTableManager get spedFiscals =>
      $$SpedFiscalsTableTableManager(_db, _db.spedFiscals);
  $$SintegrasTableTableManager get sintegras =>
      $$SintegrasTableTableManager(_db, _db.sintegras);
  $$EfdContribuicoessTableTableManager get efdContribuicoess =>
      $$EfdContribuicoessTableTableManager(_db, _db.efdContribuicoess);
  $$EfdReinfsTableTableManager get efdReinfs =>
      $$EfdReinfsTableTableManager(_db, _db.efdReinfs);
}
