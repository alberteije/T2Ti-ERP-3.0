// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'efd_reinf_dao.dart';

// ignore_for_file: type=lint
mixin _$EfdReinfDaoMixin on DatabaseAccessor<AppDatabase> {
  $EfdReinfsTable get efdReinfs => attachedDatabase.efdReinfs;
}
