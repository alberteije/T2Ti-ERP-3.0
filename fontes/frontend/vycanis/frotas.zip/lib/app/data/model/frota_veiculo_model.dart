import 'dart:convert';
import 'package:pluto_grid/pluto_grid.dart';
import 'package:frotas/app/data/model/model_imports.dart';

import 'package:frotas/app/data/domain/domain_imports.dart';

class FrotaVeiculoModel extends ModelBase {
  int? id;
  int? idFrotaVeiculoTipo;
  int? idFrotaCombustivelTipo;
  String? marca;
  String? modelo;
  String? modeloAno;
  String? placa;
  String? codigoFipe;
  String? renavam;
  String? ipvaMesVencimento;
  String? dpvatMesVencimento;
  List<FrotaIpvaControleModel>? frotaIpvaControleModelList;
  List<FrotaDpvatControleModel>? frotaDpvatControleModelList;
  List<FrotaVeiculoSinistroModel>? frotaVeiculoSinistroModelList;
  List<FrotaVeiculoMovimentacaoModel>? frotaVeiculoMovimentacaoModelList;
  List<FrotaVeiculoPneuModel>? frotaVeiculoPneuModelList;
  List<FrotaVeiculoManutencaoModel>? frotaVeiculoManutencaoModelList;
  List<FrotaMultaControleModel>? frotaMultaControleModelList;
  List<FrotaCombustivelControleModel>? frotaCombustivelControleModelList;
  FrotaVeiculoTipoModel? frotaVeiculoTipoModel;
  FrotaCombustivelTipoModel? frotaCombustivelTipoModel;

  FrotaVeiculoModel({
    this.id,
    this.idFrotaVeiculoTipo,
    this.idFrotaCombustivelTipo,
    this.marca,
    this.modelo,
    this.modeloAno,
    this.placa,
    this.codigoFipe,
    this.renavam,
    this.ipvaMesVencimento = '01',
    this.dpvatMesVencimento = '01',
    List<FrotaIpvaControleModel>? frotaIpvaControleModelList,
    List<FrotaDpvatControleModel>? frotaDpvatControleModelList,
    List<FrotaVeiculoSinistroModel>? frotaVeiculoSinistroModelList,
    List<FrotaVeiculoMovimentacaoModel>? frotaVeiculoMovimentacaoModelList,
    List<FrotaVeiculoPneuModel>? frotaVeiculoPneuModelList,
    List<FrotaVeiculoManutencaoModel>? frotaVeiculoManutencaoModelList,
    List<FrotaMultaControleModel>? frotaMultaControleModelList,
    List<FrotaCombustivelControleModel>? frotaCombustivelControleModelList,
    FrotaVeiculoTipoModel? frotaVeiculoTipoModel,
    FrotaCombustivelTipoModel? frotaCombustivelTipoModel,
  }) {
    this.frotaIpvaControleModelList = frotaIpvaControleModelList?.toList(growable: true) ?? [];
    this.frotaDpvatControleModelList = frotaDpvatControleModelList?.toList(growable: true) ?? [];
    this.frotaVeiculoSinistroModelList = frotaVeiculoSinistroModelList?.toList(growable: true) ?? [];
    this.frotaVeiculoMovimentacaoModelList = frotaVeiculoMovimentacaoModelList?.toList(growable: true) ?? [];
    this.frotaVeiculoPneuModelList = frotaVeiculoPneuModelList?.toList(growable: true) ?? [];
    this.frotaVeiculoManutencaoModelList = frotaVeiculoManutencaoModelList?.toList(growable: true) ?? [];
    this.frotaMultaControleModelList = frotaMultaControleModelList?.toList(growable: true) ?? [];
    this.frotaCombustivelControleModelList = frotaCombustivelControleModelList?.toList(growable: true) ?? [];
    this.frotaVeiculoTipoModel = frotaVeiculoTipoModel ?? FrotaVeiculoTipoModel();
    this.frotaCombustivelTipoModel = frotaCombustivelTipoModel ?? FrotaCombustivelTipoModel();
  }

  static List<String> dbColumns = <String>[
    'id',
    'marca',
    'modelo',
    'modelo_ano',
    'placa',
    'codigo_fipe',
    'renavam',
    'ipva_mes_vencimento',
    'dpvat_mes_vencimento',
  ];

  static List<String> aliasColumns = <String>[
    'Id',
    'Marca',
    'Modelo',
    'Modelo Ano',
    'Placa',
    'Codigo Fipe',
    'Renavam',
    'Ipva Mes Vencimento',
    'Dpvat Mes Vencimento',
  ];

  FrotaVeiculoModel.fromJson(Map<String, dynamic> jsonData) {
    id = jsonData['id'];
    idFrotaVeiculoTipo = jsonData['idFrotaVeiculoTipo'];
    idFrotaCombustivelTipo = jsonData['idFrotaCombustivelTipo'];
    marca = jsonData['marca'];
    modelo = jsonData['modelo'];
    modeloAno = jsonData['modeloAno'];
    placa = jsonData['placa'];
    codigoFipe = jsonData['codigoFipe'];
    renavam = jsonData['renavam'];
    ipvaMesVencimento = FrotaVeiculoDomain.getIpvaMesVencimento(jsonData['ipvaMesVencimento']);
    dpvatMesVencimento = FrotaVeiculoDomain.getDpvatMesVencimento(jsonData['dpvatMesVencimento']);
    frotaIpvaControleModelList = (jsonData['frotaIpvaControleModelList'] as Iterable?)?.map((m) => FrotaIpvaControleModel.fromJson(m)).toList() ?? [];
    frotaDpvatControleModelList = (jsonData['frotaDpvatControleModelList'] as Iterable?)?.map((m) => FrotaDpvatControleModel.fromJson(m)).toList() ?? [];
    frotaVeiculoSinistroModelList = (jsonData['frotaVeiculoSinistroModelList'] as Iterable?)?.map((m) => FrotaVeiculoSinistroModel.fromJson(m)).toList() ?? [];
    frotaVeiculoMovimentacaoModelList = (jsonData['frotaVeiculoMovimentacaoModelList'] as Iterable?)?.map((m) => FrotaVeiculoMovimentacaoModel.fromJson(m)).toList() ?? [];
    frotaVeiculoPneuModelList = (jsonData['frotaVeiculoPneuModelList'] as Iterable?)?.map((m) => FrotaVeiculoPneuModel.fromJson(m)).toList() ?? [];
    frotaVeiculoManutencaoModelList = (jsonData['frotaVeiculoManutencaoModelList'] as Iterable?)?.map((m) => FrotaVeiculoManutencaoModel.fromJson(m)).toList() ?? [];
    frotaMultaControleModelList = (jsonData['frotaMultaControleModelList'] as Iterable?)?.map((m) => FrotaMultaControleModel.fromJson(m)).toList() ?? [];
    frotaCombustivelControleModelList = (jsonData['frotaCombustivelControleModelList'] as Iterable?)?.map((m) => FrotaCombustivelControleModel.fromJson(m)).toList() ?? [];
    frotaVeiculoTipoModel = jsonData['frotaVeiculoTipoModel'] == null ? FrotaVeiculoTipoModel() : FrotaVeiculoTipoModel.fromJson(jsonData['frotaVeiculoTipoModel']);
    frotaCombustivelTipoModel = jsonData['frotaCombustivelTipoModel'] == null ? FrotaCombustivelTipoModel() : FrotaCombustivelTipoModel.fromJson(jsonData['frotaCombustivelTipoModel']);
  }

  Map<String, dynamic> get toJson {
    Map<String, dynamic> jsonData = <String, dynamic>{};

    jsonData['id'] = id != 0 ? id : null;
    jsonData['idFrotaVeiculoTipo'] = idFrotaVeiculoTipo != 0 ? idFrotaVeiculoTipo : null;
    jsonData['idFrotaCombustivelTipo'] = idFrotaCombustivelTipo != 0 ? idFrotaCombustivelTipo : null;
    jsonData['marca'] = marca;
    jsonData['modelo'] = modelo;
    jsonData['modeloAno'] = modeloAno;
    jsonData['placa'] = placa;
    jsonData['codigoFipe'] = codigoFipe;
    jsonData['renavam'] = renavam;
    jsonData['ipvaMesVencimento'] = FrotaVeiculoDomain.setIpvaMesVencimento(ipvaMesVencimento);
    jsonData['dpvatMesVencimento'] = FrotaVeiculoDomain.setDpvatMesVencimento(dpvatMesVencimento);
    
		var frotaIpvaControleModelLocalList = []; 
		for (FrotaIpvaControleModel object in frotaIpvaControleModelList ?? []) { 
			frotaIpvaControleModelLocalList.add(object.toJson); 
		}
		jsonData['frotaIpvaControleModelList'] = frotaIpvaControleModelLocalList;
    
		var frotaDpvatControleModelLocalList = []; 
		for (FrotaDpvatControleModel object in frotaDpvatControleModelList ?? []) { 
			frotaDpvatControleModelLocalList.add(object.toJson); 
		}
		jsonData['frotaDpvatControleModelList'] = frotaDpvatControleModelLocalList;
    
		var frotaVeiculoSinistroModelLocalList = []; 
		for (FrotaVeiculoSinistroModel object in frotaVeiculoSinistroModelList ?? []) { 
			frotaVeiculoSinistroModelLocalList.add(object.toJson); 
		}
		jsonData['frotaVeiculoSinistroModelList'] = frotaVeiculoSinistroModelLocalList;
    
		var frotaVeiculoMovimentacaoModelLocalList = []; 
		for (FrotaVeiculoMovimentacaoModel object in frotaVeiculoMovimentacaoModelList ?? []) { 
			frotaVeiculoMovimentacaoModelLocalList.add(object.toJson); 
		}
		jsonData['frotaVeiculoMovimentacaoModelList'] = frotaVeiculoMovimentacaoModelLocalList;
    
		var frotaVeiculoPneuModelLocalList = []; 
		for (FrotaVeiculoPneuModel object in frotaVeiculoPneuModelList ?? []) { 
			frotaVeiculoPneuModelLocalList.add(object.toJson); 
		}
		jsonData['frotaVeiculoPneuModelList'] = frotaVeiculoPneuModelLocalList;
    
		var frotaVeiculoManutencaoModelLocalList = []; 
		for (FrotaVeiculoManutencaoModel object in frotaVeiculoManutencaoModelList ?? []) { 
			frotaVeiculoManutencaoModelLocalList.add(object.toJson); 
		}
		jsonData['frotaVeiculoManutencaoModelList'] = frotaVeiculoManutencaoModelLocalList;
    
		var frotaMultaControleModelLocalList = []; 
		for (FrotaMultaControleModel object in frotaMultaControleModelList ?? []) { 
			frotaMultaControleModelLocalList.add(object.toJson); 
		}
		jsonData['frotaMultaControleModelList'] = frotaMultaControleModelLocalList;
    
		var frotaCombustivelControleModelLocalList = []; 
		for (FrotaCombustivelControleModel object in frotaCombustivelControleModelList ?? []) { 
			frotaCombustivelControleModelLocalList.add(object.toJson); 
		}
		jsonData['frotaCombustivelControleModelList'] = frotaCombustivelControleModelLocalList;
    jsonData['frotaVeiculoTipoModel'] = frotaVeiculoTipoModel?.toJson;
    jsonData['frotaVeiculoTipo'] = frotaVeiculoTipoModel?.nome ?? '';
    jsonData['frotaCombustivelTipoModel'] = frotaCombustivelTipoModel?.toJson;
    jsonData['frotaCombustivelTipo'] = frotaCombustivelTipoModel?.nome ?? '';

    return jsonData;
  }

  String objectEncodeJson() {
    final jsonData = toJson;
    return json.encode(jsonData);
  }

  static FrotaVeiculoModel fromPlutoRow(PlutoRow row) {
    return FrotaVeiculoModel(
      id: row.cells['id']?.value,
      idFrotaVeiculoTipo: row.cells['idFrotaVeiculoTipo']?.value,
      idFrotaCombustivelTipo: row.cells['idFrotaCombustivelTipo']?.value,
      marca: row.cells['marca']?.value,
      modelo: row.cells['modelo']?.value,
      modeloAno: row.cells['modeloAno']?.value,
      placa: row.cells['placa']?.value,
      codigoFipe: row.cells['codigoFipe']?.value,
      renavam: row.cells['renavam']?.value,
      ipvaMesVencimento: row.cells['ipvaMesVencimento']?.value,
      dpvatMesVencimento: row.cells['dpvatMesVencimento']?.value,
    );
  }

  PlutoRow toPlutoRow() {
    return PlutoRow(
      cells: {
        'tempId': PlutoCell(value: tempId),
        'id': PlutoCell(value: id ?? 0),
        'idFrotaVeiculoTipo': PlutoCell(value: idFrotaVeiculoTipo ?? 0),
        'idFrotaCombustivelTipo': PlutoCell(value: idFrotaCombustivelTipo ?? 0),
        'marca': PlutoCell(value: marca ?? ''),
        'modelo': PlutoCell(value: modelo ?? ''),
        'modeloAno': PlutoCell(value: modeloAno ?? ''),
        'placa': PlutoCell(value: placa ?? ''),
        'codigoFipe': PlutoCell(value: codigoFipe ?? ''),
        'renavam': PlutoCell(value: renavam ?? ''),
        'ipvaMesVencimento': PlutoCell(value: ipvaMesVencimento ?? ''),
        'dpvatMesVencimento': PlutoCell(value: dpvatMesVencimento ?? ''),
        'frotaVeiculoTipo': PlutoCell(value: frotaVeiculoTipoModel?.nome ?? ''),
        'frotaCombustivelTipo': PlutoCell(value: frotaCombustivelTipoModel?.nome ?? ''),
      },
    );
  }

  FrotaVeiculoModel clone() {
    return FrotaVeiculoModel(
      id: id,
      idFrotaVeiculoTipo: idFrotaVeiculoTipo,
      idFrotaCombustivelTipo: idFrotaCombustivelTipo,
      marca: marca,
      modelo: modelo,
      modeloAno: modeloAno,
      placa: placa,
      codigoFipe: codigoFipe,
      renavam: renavam,
      ipvaMesVencimento: ipvaMesVencimento,
      dpvatMesVencimento: dpvatMesVencimento,
      frotaIpvaControleModelList: frotaIpvaControleModelListClone(frotaIpvaControleModelList!),
      frotaDpvatControleModelList: frotaDpvatControleModelListClone(frotaDpvatControleModelList!),
      frotaVeiculoSinistroModelList: frotaVeiculoSinistroModelListClone(frotaVeiculoSinistroModelList!),
      frotaVeiculoMovimentacaoModelList: frotaVeiculoMovimentacaoModelListClone(frotaVeiculoMovimentacaoModelList!),
      frotaVeiculoPneuModelList: frotaVeiculoPneuModelListClone(frotaVeiculoPneuModelList!),
      frotaVeiculoManutencaoModelList: frotaVeiculoManutencaoModelListClone(frotaVeiculoManutencaoModelList!),
      frotaMultaControleModelList: frotaMultaControleModelListClone(frotaMultaControleModelList!),
      frotaCombustivelControleModelList: frotaCombustivelControleModelListClone(frotaCombustivelControleModelList!),
      frotaVeiculoTipoModel: frotaVeiculoTipoModel?.clone(),
      frotaCombustivelTipoModel: frotaCombustivelTipoModel?.clone(),
    );
  }

  frotaIpvaControleModelListClone(List<FrotaIpvaControleModel> frotaIpvaControleModelList) { 
		List<FrotaIpvaControleModel> resultList = [];
		for (var frotaIpvaControleModel in frotaIpvaControleModelList) {
			resultList.add(frotaIpvaControleModel.clone());
		}
		return resultList;
	}

  frotaDpvatControleModelListClone(List<FrotaDpvatControleModel> frotaDpvatControleModelList) { 
		List<FrotaDpvatControleModel> resultList = [];
		for (var frotaDpvatControleModel in frotaDpvatControleModelList) {
			resultList.add(frotaDpvatControleModel.clone());
		}
		return resultList;
	}

  frotaVeiculoSinistroModelListClone(List<FrotaVeiculoSinistroModel> frotaVeiculoSinistroModelList) { 
		List<FrotaVeiculoSinistroModel> resultList = [];
		for (var frotaVeiculoSinistroModel in frotaVeiculoSinistroModelList) {
			resultList.add(frotaVeiculoSinistroModel.clone());
		}
		return resultList;
	}

  frotaVeiculoMovimentacaoModelListClone(List<FrotaVeiculoMovimentacaoModel> frotaVeiculoMovimentacaoModelList) { 
		List<FrotaVeiculoMovimentacaoModel> resultList = [];
		for (var frotaVeiculoMovimentacaoModel in frotaVeiculoMovimentacaoModelList) {
			resultList.add(frotaVeiculoMovimentacaoModel.clone());
		}
		return resultList;
	}

  frotaVeiculoPneuModelListClone(List<FrotaVeiculoPneuModel> frotaVeiculoPneuModelList) { 
		List<FrotaVeiculoPneuModel> resultList = [];
		for (var frotaVeiculoPneuModel in frotaVeiculoPneuModelList) {
			resultList.add(frotaVeiculoPneuModel.clone());
		}
		return resultList;
	}

  frotaVeiculoManutencaoModelListClone(List<FrotaVeiculoManutencaoModel> frotaVeiculoManutencaoModelList) { 
		List<FrotaVeiculoManutencaoModel> resultList = [];
		for (var frotaVeiculoManutencaoModel in frotaVeiculoManutencaoModelList) {
			resultList.add(frotaVeiculoManutencaoModel.clone());
		}
		return resultList;
	}

  frotaMultaControleModelListClone(List<FrotaMultaControleModel> frotaMultaControleModelList) { 
		List<FrotaMultaControleModel> resultList = [];
		for (var frotaMultaControleModel in frotaMultaControleModelList) {
			resultList.add(frotaMultaControleModel.clone());
		}
		return resultList;
	}

  frotaCombustivelControleModelListClone(List<FrotaCombustivelControleModel> frotaCombustivelControleModelList) { 
		List<FrotaCombustivelControleModel> resultList = [];
		for (var frotaCombustivelControleModel in frotaCombustivelControleModelList) {
			resultList.add(frotaCombustivelControleModel.clone());
		}
		return resultList;
	}


}