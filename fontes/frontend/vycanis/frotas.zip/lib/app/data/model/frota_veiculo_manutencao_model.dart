import 'dart:convert';
import 'package:pluto_grid/pluto_grid.dart';
import 'package:frotas/app/data/model/model_imports.dart';

import 'package:frotas/app/infra/infra_imports.dart';
import 'package:intl/intl.dart';
import 'package:frotas/app/data/domain/domain_imports.dart';

class FrotaVeiculoManutencaoModel extends ModelBase {
  int? id;
  int? idFrotaVeiculo;
  String? tipo;
  DateTime? dataManutencao;
  double? valorManutencao;
  String? observacao;

  FrotaVeiculoManutencaoModel({
    this.id,
    this.idFrotaVeiculo,
    this.tipo = 'Preventiva',
    this.dataManutencao,
    this.valorManutencao,
    this.observacao,
  });

  static List<String> dbColumns = <String>[
    'id',
    'tipo',
    'data_manutencao',
    'valor_manutencao',
    'observacao',
  ];

  static List<String> aliasColumns = <String>[
    'Id',
    'Tipo',
    'Data Manutencao',
    'Valor Manutencao',
    'Observacao',
  ];

  FrotaVeiculoManutencaoModel.fromJson(Map<String, dynamic> jsonData) {
    id = jsonData['id'];
    idFrotaVeiculo = jsonData['idFrotaVeiculo'];
    tipo = FrotaVeiculoManutencaoDomain.getTipo(jsonData['tipo']);
    dataManutencao = jsonData['dataManutencao'] != null ? DateTime.tryParse(jsonData['dataManutencao']) : null;
    valorManutencao = jsonData['valorManutencao']?.toDouble();
    observacao = jsonData['observacao'];
  }

  Map<String, dynamic> get toJson {
    Map<String, dynamic> jsonData = <String, dynamic>{};

    jsonData['id'] = id != 0 ? id : null;
    jsonData['idFrotaVeiculo'] = idFrotaVeiculo != 0 ? idFrotaVeiculo : null;
    jsonData['tipo'] = FrotaVeiculoManutencaoDomain.setTipo(tipo);
    jsonData['dataManutencao'] = dataManutencao != null ? DateFormat('yyyy-MM-ddT00:00:00').format(dataManutencao!) : null;
    jsonData['valorManutencao'] = valorManutencao;
    jsonData['observacao'] = observacao;

    return jsonData;
  }

  String objectEncodeJson() {
    final jsonData = toJson;
    return json.encode(jsonData);
  }

  static FrotaVeiculoManutencaoModel fromPlutoRow(PlutoRow row) {
    return FrotaVeiculoManutencaoModel(
      id: row.cells['id']?.value,
      idFrotaVeiculo: row.cells['idFrotaVeiculo']?.value,
      tipo: row.cells['tipo']?.value,
      dataManutencao: Util.stringToDate(row.cells['dataManutencao']?.value),
      valorManutencao: row.cells['valorManutencao']?.value,
      observacao: row.cells['observacao']?.value,
    );
  }

  PlutoRow toPlutoRow() {
    return PlutoRow(
      cells: {
        'tempId': PlutoCell(value: tempId),
        'id': PlutoCell(value: id ?? 0),
        'idFrotaVeiculo': PlutoCell(value: idFrotaVeiculo ?? 0),
        'tipo': PlutoCell(value: tipo ?? ''),
        'dataManutencao': PlutoCell(value: dataManutencao),
        'valorManutencao': PlutoCell(value: valorManutencao ?? 0.0),
        'observacao': PlutoCell(value: observacao ?? ''),
      },
    );
  }

  FrotaVeiculoManutencaoModel clone() {
    return FrotaVeiculoManutencaoModel(
      id: id,
      idFrotaVeiculo: idFrotaVeiculo,
      tipo: tipo,
      dataManutencao: dataManutencao,
      valorManutencao: valorManutencao,
      observacao: observacao,
    );
  }


}