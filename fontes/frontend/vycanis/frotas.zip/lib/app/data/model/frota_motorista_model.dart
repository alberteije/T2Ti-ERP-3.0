import 'dart:convert';
import 'package:pluto_grid/pluto_grid.dart';
import 'package:frotas/app/data/model/model_imports.dart';

import 'package:frotas/app/data/domain/domain_imports.dart';

class FrotaMotoristaModel extends ModelBase {
  int? id;
  int? idColaborador;
  String? nome;
  String? numeroCnh;
  String? cnhCategoria;
  ViewPessoaColaboradorModel? viewPessoaColaboradorModel;

  FrotaMotoristaModel({
    this.id,
    this.idColaborador,
    this.nome,
    this.numeroCnh,
    this.cnhCategoria = 'A',
    ViewPessoaColaboradorModel? viewPessoaColaboradorModel,
  }) {
    this.viewPessoaColaboradorModel = viewPessoaColaboradorModel ?? ViewPessoaColaboradorModel();
  }

  static List<String> dbColumns = <String>[
    'id',
    'nome',
    'numero_cnh',
    'cnh_categoria',
  ];

  static List<String> aliasColumns = <String>[
    'Id',
    'Nome',
    'Numero Cnh',
    'Cnh Categoria',
  ];

  FrotaMotoristaModel.fromJson(Map<String, dynamic> jsonData) {
    id = jsonData['id'];
    idColaborador = jsonData['idColaborador'];
    nome = jsonData['nome'];
    numeroCnh = jsonData['numeroCnh'];
    cnhCategoria = FrotaMotoristaDomain.getCnhCategoria(jsonData['cnhCategoria']);
    viewPessoaColaboradorModel = jsonData['viewPessoaColaboradorModel'] == null ? ViewPessoaColaboradorModel() : ViewPessoaColaboradorModel.fromJson(jsonData['viewPessoaColaboradorModel']);
  }

  Map<String, dynamic> get toJson {
    Map<String, dynamic> jsonData = <String, dynamic>{};

    jsonData['id'] = id != 0 ? id : null;
    jsonData['idColaborador'] = idColaborador != 0 ? idColaborador : null;
    jsonData['nome'] = nome;
    jsonData['numeroCnh'] = numeroCnh;
    jsonData['cnhCategoria'] = FrotaMotoristaDomain.setCnhCategoria(cnhCategoria);
    jsonData['viewPessoaColaboradorModel'] = viewPessoaColaboradorModel?.toJson;
    jsonData['viewPessoaColaborador'] = viewPessoaColaboradorModel?.nome ?? '';

    return jsonData;
  }

  String objectEncodeJson() {
    final jsonData = toJson;
    return json.encode(jsonData);
  }

  static FrotaMotoristaModel fromPlutoRow(PlutoRow row) {
    return FrotaMotoristaModel(
      id: row.cells['id']?.value,
      idColaborador: row.cells['idColaborador']?.value,
      nome: row.cells['nome']?.value,
      numeroCnh: row.cells['numeroCnh']?.value,
      cnhCategoria: row.cells['cnhCategoria']?.value,
    );
  }

  PlutoRow toPlutoRow() {
    return PlutoRow(
      cells: {
        'tempId': PlutoCell(value: tempId),
        'id': PlutoCell(value: id ?? 0),
        'idColaborador': PlutoCell(value: idColaborador ?? 0),
        'nome': PlutoCell(value: nome ?? ''),
        'numeroCnh': PlutoCell(value: numeroCnh ?? ''),
        'cnhCategoria': PlutoCell(value: cnhCategoria ?? ''),
        'viewPessoaColaborador': PlutoCell(value: viewPessoaColaboradorModel?.nome ?? ''),
      },
    );
  }

  FrotaMotoristaModel clone() {
    return FrotaMotoristaModel(
      id: id,
      idColaborador: idColaborador,
      nome: nome,
      numeroCnh: numeroCnh,
      cnhCategoria: cnhCategoria,
      viewPessoaColaboradorModel: viewPessoaColaboradorModel?.clone(),
    );
  }


}