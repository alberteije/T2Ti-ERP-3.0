import 'package:frotas/app/data/provider/api/api_provider_base.dart';
import 'package:frotas/app/data/model/model_imports.dart';

class ViewPessoaColaboradorApiProvider extends ApiProviderBase {
  static const _path = '/view-pessoa-colaborador';

  Future<List<ViewPessoaColaboradorModel>?> getList({Filter? filter}) {
    return super.getListBase(
      '$_path/',
      (json) => ViewPessoaColaboradorModel.fromJson(json),
      filter: filter,
    );
  }

  Future<ViewPessoaColaboradorModel?> getObject(dynamic pk) {
    return super.getObjectBase(
      _path,
      pk,
      (json) => ViewPessoaColaboradorModel.fromJson(json),
    );
  }

  Future<ViewPessoaColaboradorModel?>? insert(ViewPessoaColaboradorModel model) {
    return super.insertBase(
      _path,
      model,
      (json) => ViewPessoaColaboradorModel.fromJson(json),
    );
  }

  Future<ViewPessoaColaboradorModel?>? update(ViewPessoaColaboradorModel model) {
    return super.updateBase(
      _path,
      model,
      (json) => ViewPessoaColaboradorModel.fromJson(json),
    );
  }

  Future<bool?> delete(dynamic pk) {
    return super.deleteBase(_path, pk);
  }
}
