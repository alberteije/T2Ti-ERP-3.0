import 'package:frotas/app/data/provider/api/api_provider_base.dart';
import 'package:frotas/app/data/model/model_imports.dart';

class FrotaVeiculoTipoApiProvider extends ApiProviderBase {
  static const _path = '/frota-veiculo-tipo';

  Future<List<FrotaVeiculoTipoModel>?> getList({Filter? filter}) {
    return super.getListBase(
      '$_path/',
      (json) => FrotaVeiculoTipoModel.fromJson(json),
      filter: filter,
    );
  }

  Future<FrotaVeiculoTipoModel?> getObject(dynamic pk) {
    return super.getObjectBase(
      _path,
      pk,
      (json) => FrotaVeiculoTipoModel.fromJson(json),
    );
  }

  Future<FrotaVeiculoTipoModel?>? insert(FrotaVeiculoTipoModel model) {
    return super.insertBase(
      _path,
      model,
      (json) => FrotaVeiculoTipoModel.fromJson(json),
    );
  }

  Future<FrotaVeiculoTipoModel?>? update(FrotaVeiculoTipoModel model) {
    return super.updateBase(
      _path,
      model,
      (json) => FrotaVeiculoTipoModel.fromJson(json),
    );
  }

  Future<bool?> delete(dynamic pk) {
    return super.deleteBase(_path, pk);
  }
}
