import 'package:frotas/app/infra/infra_imports.dart';
import 'package:frotas/app/page/shared_widget/message_dialog.dart';

class ProviderBase {
	Future handleResultError(String? body, Map<String, String>? headers, {Object? exception}) async {
		if (Session.waitDialogIsOpen) {
			closeWaitDialogBox();
		}

		String erro = 'Error: ${DateTime.now().toIso8601String()} - Exception: ${exception?.toString() ?? ''}';
		StackTrace stack = StackTrace.fromString('Message: ${body?.toString() ?? ''}');
		showErrorDialog('$erro\n\n$stack');
	}

}