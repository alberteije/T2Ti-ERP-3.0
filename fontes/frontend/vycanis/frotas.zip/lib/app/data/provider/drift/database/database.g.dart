// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'database.dart';

// ignore_for_file: type=lint
class $FrotaIpvaControlesTable extends FrotaIpvaControles
    with TableInfo<$FrotaIpvaControlesTable, FrotaIpvaControle> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $FrotaIpvaControlesTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
      'id', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _idFrotaVeiculoMeta =
      const VerificationMeta('idFrotaVeiculo');
  @override
  late final GeneratedColumn<int> idFrotaVeiculo = GeneratedColumn<int>(
      'id_frota_veiculo', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _anoMeta = const VerificationMeta('ano');
  @override
  late final GeneratedColumn<String> ano = GeneratedColumn<String>(
      'ano', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 4),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _parcelaMeta =
      const VerificationMeta('parcela');
  @override
  late final GeneratedColumn<String> parcela = GeneratedColumn<String>(
      'parcela', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 2),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _dataVencimentoMeta =
      const VerificationMeta('dataVencimento');
  @override
  late final GeneratedColumn<DateTime> dataVencimento =
      GeneratedColumn<DateTime>('data_vencimento', aliasedName, true,
          type: DriftSqlType.dateTime, requiredDuringInsert: false);
  static const VerificationMeta _dataPagamentoMeta =
      const VerificationMeta('dataPagamento');
  @override
  late final GeneratedColumn<DateTime> dataPagamento =
      GeneratedColumn<DateTime>('data_pagamento', aliasedName, true,
          type: DriftSqlType.dateTime, requiredDuringInsert: false);
  static const VerificationMeta _valorMeta = const VerificationMeta('valor');
  @override
  late final GeneratedColumn<double> valor = GeneratedColumn<double>(
      'valor', aliasedName, true,
      type: DriftSqlType.double, requiredDuringInsert: false);
  @override
  List<GeneratedColumn> get $columns =>
      [id, idFrotaVeiculo, ano, parcela, dataVencimento, dataPagamento, valor];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'frota_ipva_controle';
  @override
  VerificationContext validateIntegrity(Insertable<FrotaIpvaControle> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('id_frota_veiculo')) {
      context.handle(
          _idFrotaVeiculoMeta,
          idFrotaVeiculo.isAcceptableOrUnknown(
              data['id_frota_veiculo']!, _idFrotaVeiculoMeta));
    }
    if (data.containsKey('ano')) {
      context.handle(
          _anoMeta, ano.isAcceptableOrUnknown(data['ano']!, _anoMeta));
    }
    if (data.containsKey('parcela')) {
      context.handle(_parcelaMeta,
          parcela.isAcceptableOrUnknown(data['parcela']!, _parcelaMeta));
    }
    if (data.containsKey('data_vencimento')) {
      context.handle(
          _dataVencimentoMeta,
          dataVencimento.isAcceptableOrUnknown(
              data['data_vencimento']!, _dataVencimentoMeta));
    }
    if (data.containsKey('data_pagamento')) {
      context.handle(
          _dataPagamentoMeta,
          dataPagamento.isAcceptableOrUnknown(
              data['data_pagamento']!, _dataPagamentoMeta));
    }
    if (data.containsKey('valor')) {
      context.handle(
          _valorMeta, valor.isAcceptableOrUnknown(data['valor']!, _valorMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  FrotaIpvaControle map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return FrotaIpvaControle(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id']),
      idFrotaVeiculo: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id_frota_veiculo']),
      ano: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}ano']),
      parcela: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}parcela']),
      dataVencimento: attachedDatabase.typeMapping.read(
          DriftSqlType.dateTime, data['${effectivePrefix}data_vencimento']),
      dataPagamento: attachedDatabase.typeMapping.read(
          DriftSqlType.dateTime, data['${effectivePrefix}data_pagamento']),
      valor: attachedDatabase.typeMapping
          .read(DriftSqlType.double, data['${effectivePrefix}valor']),
    );
  }

  @override
  $FrotaIpvaControlesTable createAlias(String alias) {
    return $FrotaIpvaControlesTable(attachedDatabase, alias);
  }
}

class FrotaIpvaControle extends DataClass
    implements Insertable<FrotaIpvaControle> {
  final int? id;
  final int? idFrotaVeiculo;
  final String? ano;
  final String? parcela;
  final DateTime? dataVencimento;
  final DateTime? dataPagamento;
  final double? valor;
  const FrotaIpvaControle(
      {this.id,
      this.idFrotaVeiculo,
      this.ano,
      this.parcela,
      this.dataVencimento,
      this.dataPagamento,
      this.valor});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || idFrotaVeiculo != null) {
      map['id_frota_veiculo'] = Variable<int>(idFrotaVeiculo);
    }
    if (!nullToAbsent || ano != null) {
      map['ano'] = Variable<String>(ano);
    }
    if (!nullToAbsent || parcela != null) {
      map['parcela'] = Variable<String>(parcela);
    }
    if (!nullToAbsent || dataVencimento != null) {
      map['data_vencimento'] = Variable<DateTime>(dataVencimento);
    }
    if (!nullToAbsent || dataPagamento != null) {
      map['data_pagamento'] = Variable<DateTime>(dataPagamento);
    }
    if (!nullToAbsent || valor != null) {
      map['valor'] = Variable<double>(valor);
    }
    return map;
  }

  factory FrotaIpvaControle.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return FrotaIpvaControle(
      id: serializer.fromJson<int?>(json['id']),
      idFrotaVeiculo: serializer.fromJson<int?>(json['idFrotaVeiculo']),
      ano: serializer.fromJson<String?>(json['ano']),
      parcela: serializer.fromJson<String?>(json['parcela']),
      dataVencimento: serializer.fromJson<DateTime?>(json['dataVencimento']),
      dataPagamento: serializer.fromJson<DateTime?>(json['dataPagamento']),
      valor: serializer.fromJson<double?>(json['valor']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'idFrotaVeiculo': serializer.toJson<int?>(idFrotaVeiculo),
      'ano': serializer.toJson<String?>(ano),
      'parcela': serializer.toJson<String?>(parcela),
      'dataVencimento': serializer.toJson<DateTime?>(dataVencimento),
      'dataPagamento': serializer.toJson<DateTime?>(dataPagamento),
      'valor': serializer.toJson<double?>(valor),
    };
  }

  FrotaIpvaControle copyWith(
          {Value<int?> id = const Value.absent(),
          Value<int?> idFrotaVeiculo = const Value.absent(),
          Value<String?> ano = const Value.absent(),
          Value<String?> parcela = const Value.absent(),
          Value<DateTime?> dataVencimento = const Value.absent(),
          Value<DateTime?> dataPagamento = const Value.absent(),
          Value<double?> valor = const Value.absent()}) =>
      FrotaIpvaControle(
        id: id.present ? id.value : this.id,
        idFrotaVeiculo:
            idFrotaVeiculo.present ? idFrotaVeiculo.value : this.idFrotaVeiculo,
        ano: ano.present ? ano.value : this.ano,
        parcela: parcela.present ? parcela.value : this.parcela,
        dataVencimento:
            dataVencimento.present ? dataVencimento.value : this.dataVencimento,
        dataPagamento:
            dataPagamento.present ? dataPagamento.value : this.dataPagamento,
        valor: valor.present ? valor.value : this.valor,
      );
  FrotaIpvaControle copyWithCompanion(FrotaIpvaControlesCompanion data) {
    return FrotaIpvaControle(
      id: data.id.present ? data.id.value : this.id,
      idFrotaVeiculo: data.idFrotaVeiculo.present
          ? data.idFrotaVeiculo.value
          : this.idFrotaVeiculo,
      ano: data.ano.present ? data.ano.value : this.ano,
      parcela: data.parcela.present ? data.parcela.value : this.parcela,
      dataVencimento: data.dataVencimento.present
          ? data.dataVencimento.value
          : this.dataVencimento,
      dataPagamento: data.dataPagamento.present
          ? data.dataPagamento.value
          : this.dataPagamento,
      valor: data.valor.present ? data.valor.value : this.valor,
    );
  }

  @override
  String toString() {
    return (StringBuffer('FrotaIpvaControle(')
          ..write('id: $id, ')
          ..write('idFrotaVeiculo: $idFrotaVeiculo, ')
          ..write('ano: $ano, ')
          ..write('parcela: $parcela, ')
          ..write('dataVencimento: $dataVencimento, ')
          ..write('dataPagamento: $dataPagamento, ')
          ..write('valor: $valor')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(
      id, idFrotaVeiculo, ano, parcela, dataVencimento, dataPagamento, valor);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is FrotaIpvaControle &&
          other.id == this.id &&
          other.idFrotaVeiculo == this.idFrotaVeiculo &&
          other.ano == this.ano &&
          other.parcela == this.parcela &&
          other.dataVencimento == this.dataVencimento &&
          other.dataPagamento == this.dataPagamento &&
          other.valor == this.valor);
}

class FrotaIpvaControlesCompanion extends UpdateCompanion<FrotaIpvaControle> {
  final Value<int?> id;
  final Value<int?> idFrotaVeiculo;
  final Value<String?> ano;
  final Value<String?> parcela;
  final Value<DateTime?> dataVencimento;
  final Value<DateTime?> dataPagamento;
  final Value<double?> valor;
  const FrotaIpvaControlesCompanion({
    this.id = const Value.absent(),
    this.idFrotaVeiculo = const Value.absent(),
    this.ano = const Value.absent(),
    this.parcela = const Value.absent(),
    this.dataVencimento = const Value.absent(),
    this.dataPagamento = const Value.absent(),
    this.valor = const Value.absent(),
  });
  FrotaIpvaControlesCompanion.insert({
    this.id = const Value.absent(),
    this.idFrotaVeiculo = const Value.absent(),
    this.ano = const Value.absent(),
    this.parcela = const Value.absent(),
    this.dataVencimento = const Value.absent(),
    this.dataPagamento = const Value.absent(),
    this.valor = const Value.absent(),
  });
  static Insertable<FrotaIpvaControle> custom({
    Expression<int>? id,
    Expression<int>? idFrotaVeiculo,
    Expression<String>? ano,
    Expression<String>? parcela,
    Expression<DateTime>? dataVencimento,
    Expression<DateTime>? dataPagamento,
    Expression<double>? valor,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (idFrotaVeiculo != null) 'id_frota_veiculo': idFrotaVeiculo,
      if (ano != null) 'ano': ano,
      if (parcela != null) 'parcela': parcela,
      if (dataVencimento != null) 'data_vencimento': dataVencimento,
      if (dataPagamento != null) 'data_pagamento': dataPagamento,
      if (valor != null) 'valor': valor,
    });
  }

  FrotaIpvaControlesCompanion copyWith(
      {Value<int?>? id,
      Value<int?>? idFrotaVeiculo,
      Value<String?>? ano,
      Value<String?>? parcela,
      Value<DateTime?>? dataVencimento,
      Value<DateTime?>? dataPagamento,
      Value<double?>? valor}) {
    return FrotaIpvaControlesCompanion(
      id: id ?? this.id,
      idFrotaVeiculo: idFrotaVeiculo ?? this.idFrotaVeiculo,
      ano: ano ?? this.ano,
      parcela: parcela ?? this.parcela,
      dataVencimento: dataVencimento ?? this.dataVencimento,
      dataPagamento: dataPagamento ?? this.dataPagamento,
      valor: valor ?? this.valor,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (idFrotaVeiculo.present) {
      map['id_frota_veiculo'] = Variable<int>(idFrotaVeiculo.value);
    }
    if (ano.present) {
      map['ano'] = Variable<String>(ano.value);
    }
    if (parcela.present) {
      map['parcela'] = Variable<String>(parcela.value);
    }
    if (dataVencimento.present) {
      map['data_vencimento'] = Variable<DateTime>(dataVencimento.value);
    }
    if (dataPagamento.present) {
      map['data_pagamento'] = Variable<DateTime>(dataPagamento.value);
    }
    if (valor.present) {
      map['valor'] = Variable<double>(valor.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('FrotaIpvaControlesCompanion(')
          ..write('id: $id, ')
          ..write('idFrotaVeiculo: $idFrotaVeiculo, ')
          ..write('ano: $ano, ')
          ..write('parcela: $parcela, ')
          ..write('dataVencimento: $dataVencimento, ')
          ..write('dataPagamento: $dataPagamento, ')
          ..write('valor: $valor')
          ..write(')'))
        .toString();
  }
}

class $FrotaDpvatControlesTable extends FrotaDpvatControles
    with TableInfo<$FrotaDpvatControlesTable, FrotaDpvatControle> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $FrotaDpvatControlesTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
      'id', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _idFrotaVeiculoMeta =
      const VerificationMeta('idFrotaVeiculo');
  @override
  late final GeneratedColumn<int> idFrotaVeiculo = GeneratedColumn<int>(
      'id_frota_veiculo', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _anoMeta = const VerificationMeta('ano');
  @override
  late final GeneratedColumn<String> ano = GeneratedColumn<String>(
      'ano', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 4),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _parcelaMeta =
      const VerificationMeta('parcela');
  @override
  late final GeneratedColumn<String> parcela = GeneratedColumn<String>(
      'parcela', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 2),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _dataVencimentoMeta =
      const VerificationMeta('dataVencimento');
  @override
  late final GeneratedColumn<DateTime> dataVencimento =
      GeneratedColumn<DateTime>('data_vencimento', aliasedName, true,
          type: DriftSqlType.dateTime, requiredDuringInsert: false);
  static const VerificationMeta _dataPagamentoMeta =
      const VerificationMeta('dataPagamento');
  @override
  late final GeneratedColumn<DateTime> dataPagamento =
      GeneratedColumn<DateTime>('data_pagamento', aliasedName, true,
          type: DriftSqlType.dateTime, requiredDuringInsert: false);
  static const VerificationMeta _valorMeta = const VerificationMeta('valor');
  @override
  late final GeneratedColumn<double> valor = GeneratedColumn<double>(
      'valor', aliasedName, true,
      type: DriftSqlType.double, requiredDuringInsert: false);
  @override
  List<GeneratedColumn> get $columns =>
      [id, idFrotaVeiculo, ano, parcela, dataVencimento, dataPagamento, valor];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'frota_dpvat_controle';
  @override
  VerificationContext validateIntegrity(Insertable<FrotaDpvatControle> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('id_frota_veiculo')) {
      context.handle(
          _idFrotaVeiculoMeta,
          idFrotaVeiculo.isAcceptableOrUnknown(
              data['id_frota_veiculo']!, _idFrotaVeiculoMeta));
    }
    if (data.containsKey('ano')) {
      context.handle(
          _anoMeta, ano.isAcceptableOrUnknown(data['ano']!, _anoMeta));
    }
    if (data.containsKey('parcela')) {
      context.handle(_parcelaMeta,
          parcela.isAcceptableOrUnknown(data['parcela']!, _parcelaMeta));
    }
    if (data.containsKey('data_vencimento')) {
      context.handle(
          _dataVencimentoMeta,
          dataVencimento.isAcceptableOrUnknown(
              data['data_vencimento']!, _dataVencimentoMeta));
    }
    if (data.containsKey('data_pagamento')) {
      context.handle(
          _dataPagamentoMeta,
          dataPagamento.isAcceptableOrUnknown(
              data['data_pagamento']!, _dataPagamentoMeta));
    }
    if (data.containsKey('valor')) {
      context.handle(
          _valorMeta, valor.isAcceptableOrUnknown(data['valor']!, _valorMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  FrotaDpvatControle map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return FrotaDpvatControle(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id']),
      idFrotaVeiculo: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id_frota_veiculo']),
      ano: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}ano']),
      parcela: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}parcela']),
      dataVencimento: attachedDatabase.typeMapping.read(
          DriftSqlType.dateTime, data['${effectivePrefix}data_vencimento']),
      dataPagamento: attachedDatabase.typeMapping.read(
          DriftSqlType.dateTime, data['${effectivePrefix}data_pagamento']),
      valor: attachedDatabase.typeMapping
          .read(DriftSqlType.double, data['${effectivePrefix}valor']),
    );
  }

  @override
  $FrotaDpvatControlesTable createAlias(String alias) {
    return $FrotaDpvatControlesTable(attachedDatabase, alias);
  }
}

class FrotaDpvatControle extends DataClass
    implements Insertable<FrotaDpvatControle> {
  final int? id;
  final int? idFrotaVeiculo;
  final String? ano;
  final String? parcela;
  final DateTime? dataVencimento;
  final DateTime? dataPagamento;
  final double? valor;
  const FrotaDpvatControle(
      {this.id,
      this.idFrotaVeiculo,
      this.ano,
      this.parcela,
      this.dataVencimento,
      this.dataPagamento,
      this.valor});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || idFrotaVeiculo != null) {
      map['id_frota_veiculo'] = Variable<int>(idFrotaVeiculo);
    }
    if (!nullToAbsent || ano != null) {
      map['ano'] = Variable<String>(ano);
    }
    if (!nullToAbsent || parcela != null) {
      map['parcela'] = Variable<String>(parcela);
    }
    if (!nullToAbsent || dataVencimento != null) {
      map['data_vencimento'] = Variable<DateTime>(dataVencimento);
    }
    if (!nullToAbsent || dataPagamento != null) {
      map['data_pagamento'] = Variable<DateTime>(dataPagamento);
    }
    if (!nullToAbsent || valor != null) {
      map['valor'] = Variable<double>(valor);
    }
    return map;
  }

  factory FrotaDpvatControle.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return FrotaDpvatControle(
      id: serializer.fromJson<int?>(json['id']),
      idFrotaVeiculo: serializer.fromJson<int?>(json['idFrotaVeiculo']),
      ano: serializer.fromJson<String?>(json['ano']),
      parcela: serializer.fromJson<String?>(json['parcela']),
      dataVencimento: serializer.fromJson<DateTime?>(json['dataVencimento']),
      dataPagamento: serializer.fromJson<DateTime?>(json['dataPagamento']),
      valor: serializer.fromJson<double?>(json['valor']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'idFrotaVeiculo': serializer.toJson<int?>(idFrotaVeiculo),
      'ano': serializer.toJson<String?>(ano),
      'parcela': serializer.toJson<String?>(parcela),
      'dataVencimento': serializer.toJson<DateTime?>(dataVencimento),
      'dataPagamento': serializer.toJson<DateTime?>(dataPagamento),
      'valor': serializer.toJson<double?>(valor),
    };
  }

  FrotaDpvatControle copyWith(
          {Value<int?> id = const Value.absent(),
          Value<int?> idFrotaVeiculo = const Value.absent(),
          Value<String?> ano = const Value.absent(),
          Value<String?> parcela = const Value.absent(),
          Value<DateTime?> dataVencimento = const Value.absent(),
          Value<DateTime?> dataPagamento = const Value.absent(),
          Value<double?> valor = const Value.absent()}) =>
      FrotaDpvatControle(
        id: id.present ? id.value : this.id,
        idFrotaVeiculo:
            idFrotaVeiculo.present ? idFrotaVeiculo.value : this.idFrotaVeiculo,
        ano: ano.present ? ano.value : this.ano,
        parcela: parcela.present ? parcela.value : this.parcela,
        dataVencimento:
            dataVencimento.present ? dataVencimento.value : this.dataVencimento,
        dataPagamento:
            dataPagamento.present ? dataPagamento.value : this.dataPagamento,
        valor: valor.present ? valor.value : this.valor,
      );
  FrotaDpvatControle copyWithCompanion(FrotaDpvatControlesCompanion data) {
    return FrotaDpvatControle(
      id: data.id.present ? data.id.value : this.id,
      idFrotaVeiculo: data.idFrotaVeiculo.present
          ? data.idFrotaVeiculo.value
          : this.idFrotaVeiculo,
      ano: data.ano.present ? data.ano.value : this.ano,
      parcela: data.parcela.present ? data.parcela.value : this.parcela,
      dataVencimento: data.dataVencimento.present
          ? data.dataVencimento.value
          : this.dataVencimento,
      dataPagamento: data.dataPagamento.present
          ? data.dataPagamento.value
          : this.dataPagamento,
      valor: data.valor.present ? data.valor.value : this.valor,
    );
  }

  @override
  String toString() {
    return (StringBuffer('FrotaDpvatControle(')
          ..write('id: $id, ')
          ..write('idFrotaVeiculo: $idFrotaVeiculo, ')
          ..write('ano: $ano, ')
          ..write('parcela: $parcela, ')
          ..write('dataVencimento: $dataVencimento, ')
          ..write('dataPagamento: $dataPagamento, ')
          ..write('valor: $valor')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(
      id, idFrotaVeiculo, ano, parcela, dataVencimento, dataPagamento, valor);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is FrotaDpvatControle &&
          other.id == this.id &&
          other.idFrotaVeiculo == this.idFrotaVeiculo &&
          other.ano == this.ano &&
          other.parcela == this.parcela &&
          other.dataVencimento == this.dataVencimento &&
          other.dataPagamento == this.dataPagamento &&
          other.valor == this.valor);
}

class FrotaDpvatControlesCompanion extends UpdateCompanion<FrotaDpvatControle> {
  final Value<int?> id;
  final Value<int?> idFrotaVeiculo;
  final Value<String?> ano;
  final Value<String?> parcela;
  final Value<DateTime?> dataVencimento;
  final Value<DateTime?> dataPagamento;
  final Value<double?> valor;
  const FrotaDpvatControlesCompanion({
    this.id = const Value.absent(),
    this.idFrotaVeiculo = const Value.absent(),
    this.ano = const Value.absent(),
    this.parcela = const Value.absent(),
    this.dataVencimento = const Value.absent(),
    this.dataPagamento = const Value.absent(),
    this.valor = const Value.absent(),
  });
  FrotaDpvatControlesCompanion.insert({
    this.id = const Value.absent(),
    this.idFrotaVeiculo = const Value.absent(),
    this.ano = const Value.absent(),
    this.parcela = const Value.absent(),
    this.dataVencimento = const Value.absent(),
    this.dataPagamento = const Value.absent(),
    this.valor = const Value.absent(),
  });
  static Insertable<FrotaDpvatControle> custom({
    Expression<int>? id,
    Expression<int>? idFrotaVeiculo,
    Expression<String>? ano,
    Expression<String>? parcela,
    Expression<DateTime>? dataVencimento,
    Expression<DateTime>? dataPagamento,
    Expression<double>? valor,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (idFrotaVeiculo != null) 'id_frota_veiculo': idFrotaVeiculo,
      if (ano != null) 'ano': ano,
      if (parcela != null) 'parcela': parcela,
      if (dataVencimento != null) 'data_vencimento': dataVencimento,
      if (dataPagamento != null) 'data_pagamento': dataPagamento,
      if (valor != null) 'valor': valor,
    });
  }

  FrotaDpvatControlesCompanion copyWith(
      {Value<int?>? id,
      Value<int?>? idFrotaVeiculo,
      Value<String?>? ano,
      Value<String?>? parcela,
      Value<DateTime?>? dataVencimento,
      Value<DateTime?>? dataPagamento,
      Value<double?>? valor}) {
    return FrotaDpvatControlesCompanion(
      id: id ?? this.id,
      idFrotaVeiculo: idFrotaVeiculo ?? this.idFrotaVeiculo,
      ano: ano ?? this.ano,
      parcela: parcela ?? this.parcela,
      dataVencimento: dataVencimento ?? this.dataVencimento,
      dataPagamento: dataPagamento ?? this.dataPagamento,
      valor: valor ?? this.valor,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (idFrotaVeiculo.present) {
      map['id_frota_veiculo'] = Variable<int>(idFrotaVeiculo.value);
    }
    if (ano.present) {
      map['ano'] = Variable<String>(ano.value);
    }
    if (parcela.present) {
      map['parcela'] = Variable<String>(parcela.value);
    }
    if (dataVencimento.present) {
      map['data_vencimento'] = Variable<DateTime>(dataVencimento.value);
    }
    if (dataPagamento.present) {
      map['data_pagamento'] = Variable<DateTime>(dataPagamento.value);
    }
    if (valor.present) {
      map['valor'] = Variable<double>(valor.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('FrotaDpvatControlesCompanion(')
          ..write('id: $id, ')
          ..write('idFrotaVeiculo: $idFrotaVeiculo, ')
          ..write('ano: $ano, ')
          ..write('parcela: $parcela, ')
          ..write('dataVencimento: $dataVencimento, ')
          ..write('dataPagamento: $dataPagamento, ')
          ..write('valor: $valor')
          ..write(')'))
        .toString();
  }
}

class $FrotaVeiculoSinistrosTable extends FrotaVeiculoSinistros
    with TableInfo<$FrotaVeiculoSinistrosTable, FrotaVeiculoSinistro> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $FrotaVeiculoSinistrosTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
      'id', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _idFrotaVeiculoMeta =
      const VerificationMeta('idFrotaVeiculo');
  @override
  late final GeneratedColumn<int> idFrotaVeiculo = GeneratedColumn<int>(
      'id_frota_veiculo', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _dataSinistroMeta =
      const VerificationMeta('dataSinistro');
  @override
  late final GeneratedColumn<DateTime> dataSinistro = GeneratedColumn<DateTime>(
      'data_sinistro', aliasedName, true,
      type: DriftSqlType.dateTime, requiredDuringInsert: false);
  static const VerificationMeta _observacaoMeta =
      const VerificationMeta('observacao');
  @override
  late final GeneratedColumn<String> observacao = GeneratedColumn<String>(
      'observacao', aliasedName, true,
      type: DriftSqlType.string, requiredDuringInsert: false);
  @override
  List<GeneratedColumn> get $columns =>
      [id, idFrotaVeiculo, dataSinistro, observacao];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'frota_veiculo_sinistro';
  @override
  VerificationContext validateIntegrity(
      Insertable<FrotaVeiculoSinistro> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('id_frota_veiculo')) {
      context.handle(
          _idFrotaVeiculoMeta,
          idFrotaVeiculo.isAcceptableOrUnknown(
              data['id_frota_veiculo']!, _idFrotaVeiculoMeta));
    }
    if (data.containsKey('data_sinistro')) {
      context.handle(
          _dataSinistroMeta,
          dataSinistro.isAcceptableOrUnknown(
              data['data_sinistro']!, _dataSinistroMeta));
    }
    if (data.containsKey('observacao')) {
      context.handle(
          _observacaoMeta,
          observacao.isAcceptableOrUnknown(
              data['observacao']!, _observacaoMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  FrotaVeiculoSinistro map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return FrotaVeiculoSinistro(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id']),
      idFrotaVeiculo: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id_frota_veiculo']),
      dataSinistro: attachedDatabase.typeMapping
          .read(DriftSqlType.dateTime, data['${effectivePrefix}data_sinistro']),
      observacao: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}observacao']),
    );
  }

  @override
  $FrotaVeiculoSinistrosTable createAlias(String alias) {
    return $FrotaVeiculoSinistrosTable(attachedDatabase, alias);
  }
}

class FrotaVeiculoSinistro extends DataClass
    implements Insertable<FrotaVeiculoSinistro> {
  final int? id;
  final int? idFrotaVeiculo;
  final DateTime? dataSinistro;
  final String? observacao;
  const FrotaVeiculoSinistro(
      {this.id, this.idFrotaVeiculo, this.dataSinistro, this.observacao});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || idFrotaVeiculo != null) {
      map['id_frota_veiculo'] = Variable<int>(idFrotaVeiculo);
    }
    if (!nullToAbsent || dataSinistro != null) {
      map['data_sinistro'] = Variable<DateTime>(dataSinistro);
    }
    if (!nullToAbsent || observacao != null) {
      map['observacao'] = Variable<String>(observacao);
    }
    return map;
  }

  factory FrotaVeiculoSinistro.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return FrotaVeiculoSinistro(
      id: serializer.fromJson<int?>(json['id']),
      idFrotaVeiculo: serializer.fromJson<int?>(json['idFrotaVeiculo']),
      dataSinistro: serializer.fromJson<DateTime?>(json['dataSinistro']),
      observacao: serializer.fromJson<String?>(json['observacao']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'idFrotaVeiculo': serializer.toJson<int?>(idFrotaVeiculo),
      'dataSinistro': serializer.toJson<DateTime?>(dataSinistro),
      'observacao': serializer.toJson<String?>(observacao),
    };
  }

  FrotaVeiculoSinistro copyWith(
          {Value<int?> id = const Value.absent(),
          Value<int?> idFrotaVeiculo = const Value.absent(),
          Value<DateTime?> dataSinistro = const Value.absent(),
          Value<String?> observacao = const Value.absent()}) =>
      FrotaVeiculoSinistro(
        id: id.present ? id.value : this.id,
        idFrotaVeiculo:
            idFrotaVeiculo.present ? idFrotaVeiculo.value : this.idFrotaVeiculo,
        dataSinistro:
            dataSinistro.present ? dataSinistro.value : this.dataSinistro,
        observacao: observacao.present ? observacao.value : this.observacao,
      );
  FrotaVeiculoSinistro copyWithCompanion(FrotaVeiculoSinistrosCompanion data) {
    return FrotaVeiculoSinistro(
      id: data.id.present ? data.id.value : this.id,
      idFrotaVeiculo: data.idFrotaVeiculo.present
          ? data.idFrotaVeiculo.value
          : this.idFrotaVeiculo,
      dataSinistro: data.dataSinistro.present
          ? data.dataSinistro.value
          : this.dataSinistro,
      observacao:
          data.observacao.present ? data.observacao.value : this.observacao,
    );
  }

  @override
  String toString() {
    return (StringBuffer('FrotaVeiculoSinistro(')
          ..write('id: $id, ')
          ..write('idFrotaVeiculo: $idFrotaVeiculo, ')
          ..write('dataSinistro: $dataSinistro, ')
          ..write('observacao: $observacao')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(id, idFrotaVeiculo, dataSinistro, observacao);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is FrotaVeiculoSinistro &&
          other.id == this.id &&
          other.idFrotaVeiculo == this.idFrotaVeiculo &&
          other.dataSinistro == this.dataSinistro &&
          other.observacao == this.observacao);
}

class FrotaVeiculoSinistrosCompanion
    extends UpdateCompanion<FrotaVeiculoSinistro> {
  final Value<int?> id;
  final Value<int?> idFrotaVeiculo;
  final Value<DateTime?> dataSinistro;
  final Value<String?> observacao;
  const FrotaVeiculoSinistrosCompanion({
    this.id = const Value.absent(),
    this.idFrotaVeiculo = const Value.absent(),
    this.dataSinistro = const Value.absent(),
    this.observacao = const Value.absent(),
  });
  FrotaVeiculoSinistrosCompanion.insert({
    this.id = const Value.absent(),
    this.idFrotaVeiculo = const Value.absent(),
    this.dataSinistro = const Value.absent(),
    this.observacao = const Value.absent(),
  });
  static Insertable<FrotaVeiculoSinistro> custom({
    Expression<int>? id,
    Expression<int>? idFrotaVeiculo,
    Expression<DateTime>? dataSinistro,
    Expression<String>? observacao,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (idFrotaVeiculo != null) 'id_frota_veiculo': idFrotaVeiculo,
      if (dataSinistro != null) 'data_sinistro': dataSinistro,
      if (observacao != null) 'observacao': observacao,
    });
  }

  FrotaVeiculoSinistrosCompanion copyWith(
      {Value<int?>? id,
      Value<int?>? idFrotaVeiculo,
      Value<DateTime?>? dataSinistro,
      Value<String?>? observacao}) {
    return FrotaVeiculoSinistrosCompanion(
      id: id ?? this.id,
      idFrotaVeiculo: idFrotaVeiculo ?? this.idFrotaVeiculo,
      dataSinistro: dataSinistro ?? this.dataSinistro,
      observacao: observacao ?? this.observacao,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (idFrotaVeiculo.present) {
      map['id_frota_veiculo'] = Variable<int>(idFrotaVeiculo.value);
    }
    if (dataSinistro.present) {
      map['data_sinistro'] = Variable<DateTime>(dataSinistro.value);
    }
    if (observacao.present) {
      map['observacao'] = Variable<String>(observacao.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('FrotaVeiculoSinistrosCompanion(')
          ..write('id: $id, ')
          ..write('idFrotaVeiculo: $idFrotaVeiculo, ')
          ..write('dataSinistro: $dataSinistro, ')
          ..write('observacao: $observacao')
          ..write(')'))
        .toString();
  }
}

class $FrotaVeiculoMovimentacaosTable extends FrotaVeiculoMovimentacaos
    with TableInfo<$FrotaVeiculoMovimentacaosTable, FrotaVeiculoMovimentacao> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $FrotaVeiculoMovimentacaosTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
      'id', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _idFrotaVeiculoMeta =
      const VerificationMeta('idFrotaVeiculo');
  @override
  late final GeneratedColumn<int> idFrotaVeiculo = GeneratedColumn<int>(
      'id_frota_veiculo', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _idFrotaMotoristaMeta =
      const VerificationMeta('idFrotaMotorista');
  @override
  late final GeneratedColumn<int> idFrotaMotorista = GeneratedColumn<int>(
      'id_frota_motorista', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _dataSaidaMeta =
      const VerificationMeta('dataSaida');
  @override
  late final GeneratedColumn<DateTime> dataSaida = GeneratedColumn<DateTime>(
      'data_saida', aliasedName, true,
      type: DriftSqlType.dateTime, requiredDuringInsert: false);
  static const VerificationMeta _horaSaidaMeta =
      const VerificationMeta('horaSaida');
  @override
  late final GeneratedColumn<String> horaSaida = GeneratedColumn<String>(
      'hora_saida', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 8),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _dataEntradaMeta =
      const VerificationMeta('dataEntrada');
  @override
  late final GeneratedColumn<DateTime> dataEntrada = GeneratedColumn<DateTime>(
      'data_entrada', aliasedName, true,
      type: DriftSqlType.dateTime, requiredDuringInsert: false);
  static const VerificationMeta _horaEntradaMeta =
      const VerificationMeta('horaEntrada');
  @override
  late final GeneratedColumn<String> horaEntrada = GeneratedColumn<String>(
      'hora_entrada', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 8),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _observacaoMeta =
      const VerificationMeta('observacao');
  @override
  late final GeneratedColumn<String> observacao = GeneratedColumn<String>(
      'observacao', aliasedName, true,
      type: DriftSqlType.string, requiredDuringInsert: false);
  @override
  List<GeneratedColumn> get $columns => [
        id,
        idFrotaVeiculo,
        idFrotaMotorista,
        dataSaida,
        horaSaida,
        dataEntrada,
        horaEntrada,
        observacao
      ];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'frota_veiculo_movimentacao';
  @override
  VerificationContext validateIntegrity(
      Insertable<FrotaVeiculoMovimentacao> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('id_frota_veiculo')) {
      context.handle(
          _idFrotaVeiculoMeta,
          idFrotaVeiculo.isAcceptableOrUnknown(
              data['id_frota_veiculo']!, _idFrotaVeiculoMeta));
    }
    if (data.containsKey('id_frota_motorista')) {
      context.handle(
          _idFrotaMotoristaMeta,
          idFrotaMotorista.isAcceptableOrUnknown(
              data['id_frota_motorista']!, _idFrotaMotoristaMeta));
    }
    if (data.containsKey('data_saida')) {
      context.handle(_dataSaidaMeta,
          dataSaida.isAcceptableOrUnknown(data['data_saida']!, _dataSaidaMeta));
    }
    if (data.containsKey('hora_saida')) {
      context.handle(_horaSaidaMeta,
          horaSaida.isAcceptableOrUnknown(data['hora_saida']!, _horaSaidaMeta));
    }
    if (data.containsKey('data_entrada')) {
      context.handle(
          _dataEntradaMeta,
          dataEntrada.isAcceptableOrUnknown(
              data['data_entrada']!, _dataEntradaMeta));
    }
    if (data.containsKey('hora_entrada')) {
      context.handle(
          _horaEntradaMeta,
          horaEntrada.isAcceptableOrUnknown(
              data['hora_entrada']!, _horaEntradaMeta));
    }
    if (data.containsKey('observacao')) {
      context.handle(
          _observacaoMeta,
          observacao.isAcceptableOrUnknown(
              data['observacao']!, _observacaoMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  FrotaVeiculoMovimentacao map(Map<String, dynamic> data,
      {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return FrotaVeiculoMovimentacao(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id']),
      idFrotaVeiculo: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id_frota_veiculo']),
      idFrotaMotorista: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id_frota_motorista']),
      dataSaida: attachedDatabase.typeMapping
          .read(DriftSqlType.dateTime, data['${effectivePrefix}data_saida']),
      horaSaida: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}hora_saida']),
      dataEntrada: attachedDatabase.typeMapping
          .read(DriftSqlType.dateTime, data['${effectivePrefix}data_entrada']),
      horaEntrada: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}hora_entrada']),
      observacao: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}observacao']),
    );
  }

  @override
  $FrotaVeiculoMovimentacaosTable createAlias(String alias) {
    return $FrotaVeiculoMovimentacaosTable(attachedDatabase, alias);
  }
}

class FrotaVeiculoMovimentacao extends DataClass
    implements Insertable<FrotaVeiculoMovimentacao> {
  final int? id;
  final int? idFrotaVeiculo;
  final int? idFrotaMotorista;
  final DateTime? dataSaida;
  final String? horaSaida;
  final DateTime? dataEntrada;
  final String? horaEntrada;
  final String? observacao;
  const FrotaVeiculoMovimentacao(
      {this.id,
      this.idFrotaVeiculo,
      this.idFrotaMotorista,
      this.dataSaida,
      this.horaSaida,
      this.dataEntrada,
      this.horaEntrada,
      this.observacao});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || idFrotaVeiculo != null) {
      map['id_frota_veiculo'] = Variable<int>(idFrotaVeiculo);
    }
    if (!nullToAbsent || idFrotaMotorista != null) {
      map['id_frota_motorista'] = Variable<int>(idFrotaMotorista);
    }
    if (!nullToAbsent || dataSaida != null) {
      map['data_saida'] = Variable<DateTime>(dataSaida);
    }
    if (!nullToAbsent || horaSaida != null) {
      map['hora_saida'] = Variable<String>(horaSaida);
    }
    if (!nullToAbsent || dataEntrada != null) {
      map['data_entrada'] = Variable<DateTime>(dataEntrada);
    }
    if (!nullToAbsent || horaEntrada != null) {
      map['hora_entrada'] = Variable<String>(horaEntrada);
    }
    if (!nullToAbsent || observacao != null) {
      map['observacao'] = Variable<String>(observacao);
    }
    return map;
  }

  factory FrotaVeiculoMovimentacao.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return FrotaVeiculoMovimentacao(
      id: serializer.fromJson<int?>(json['id']),
      idFrotaVeiculo: serializer.fromJson<int?>(json['idFrotaVeiculo']),
      idFrotaMotorista: serializer.fromJson<int?>(json['idFrotaMotorista']),
      dataSaida: serializer.fromJson<DateTime?>(json['dataSaida']),
      horaSaida: serializer.fromJson<String?>(json['horaSaida']),
      dataEntrada: serializer.fromJson<DateTime?>(json['dataEntrada']),
      horaEntrada: serializer.fromJson<String?>(json['horaEntrada']),
      observacao: serializer.fromJson<String?>(json['observacao']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'idFrotaVeiculo': serializer.toJson<int?>(idFrotaVeiculo),
      'idFrotaMotorista': serializer.toJson<int?>(idFrotaMotorista),
      'dataSaida': serializer.toJson<DateTime?>(dataSaida),
      'horaSaida': serializer.toJson<String?>(horaSaida),
      'dataEntrada': serializer.toJson<DateTime?>(dataEntrada),
      'horaEntrada': serializer.toJson<String?>(horaEntrada),
      'observacao': serializer.toJson<String?>(observacao),
    };
  }

  FrotaVeiculoMovimentacao copyWith(
          {Value<int?> id = const Value.absent(),
          Value<int?> idFrotaVeiculo = const Value.absent(),
          Value<int?> idFrotaMotorista = const Value.absent(),
          Value<DateTime?> dataSaida = const Value.absent(),
          Value<String?> horaSaida = const Value.absent(),
          Value<DateTime?> dataEntrada = const Value.absent(),
          Value<String?> horaEntrada = const Value.absent(),
          Value<String?> observacao = const Value.absent()}) =>
      FrotaVeiculoMovimentacao(
        id: id.present ? id.value : this.id,
        idFrotaVeiculo:
            idFrotaVeiculo.present ? idFrotaVeiculo.value : this.idFrotaVeiculo,
        idFrotaMotorista: idFrotaMotorista.present
            ? idFrotaMotorista.value
            : this.idFrotaMotorista,
        dataSaida: dataSaida.present ? dataSaida.value : this.dataSaida,
        horaSaida: horaSaida.present ? horaSaida.value : this.horaSaida,
        dataEntrada: dataEntrada.present ? dataEntrada.value : this.dataEntrada,
        horaEntrada: horaEntrada.present ? horaEntrada.value : this.horaEntrada,
        observacao: observacao.present ? observacao.value : this.observacao,
      );
  FrotaVeiculoMovimentacao copyWithCompanion(
      FrotaVeiculoMovimentacaosCompanion data) {
    return FrotaVeiculoMovimentacao(
      id: data.id.present ? data.id.value : this.id,
      idFrotaVeiculo: data.idFrotaVeiculo.present
          ? data.idFrotaVeiculo.value
          : this.idFrotaVeiculo,
      idFrotaMotorista: data.idFrotaMotorista.present
          ? data.idFrotaMotorista.value
          : this.idFrotaMotorista,
      dataSaida: data.dataSaida.present ? data.dataSaida.value : this.dataSaida,
      horaSaida: data.horaSaida.present ? data.horaSaida.value : this.horaSaida,
      dataEntrada:
          data.dataEntrada.present ? data.dataEntrada.value : this.dataEntrada,
      horaEntrada:
          data.horaEntrada.present ? data.horaEntrada.value : this.horaEntrada,
      observacao:
          data.observacao.present ? data.observacao.value : this.observacao,
    );
  }

  @override
  String toString() {
    return (StringBuffer('FrotaVeiculoMovimentacao(')
          ..write('id: $id, ')
          ..write('idFrotaVeiculo: $idFrotaVeiculo, ')
          ..write('idFrotaMotorista: $idFrotaMotorista, ')
          ..write('dataSaida: $dataSaida, ')
          ..write('horaSaida: $horaSaida, ')
          ..write('dataEntrada: $dataEntrada, ')
          ..write('horaEntrada: $horaEntrada, ')
          ..write('observacao: $observacao')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(id, idFrotaVeiculo, idFrotaMotorista,
      dataSaida, horaSaida, dataEntrada, horaEntrada, observacao);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is FrotaVeiculoMovimentacao &&
          other.id == this.id &&
          other.idFrotaVeiculo == this.idFrotaVeiculo &&
          other.idFrotaMotorista == this.idFrotaMotorista &&
          other.dataSaida == this.dataSaida &&
          other.horaSaida == this.horaSaida &&
          other.dataEntrada == this.dataEntrada &&
          other.horaEntrada == this.horaEntrada &&
          other.observacao == this.observacao);
}

class FrotaVeiculoMovimentacaosCompanion
    extends UpdateCompanion<FrotaVeiculoMovimentacao> {
  final Value<int?> id;
  final Value<int?> idFrotaVeiculo;
  final Value<int?> idFrotaMotorista;
  final Value<DateTime?> dataSaida;
  final Value<String?> horaSaida;
  final Value<DateTime?> dataEntrada;
  final Value<String?> horaEntrada;
  final Value<String?> observacao;
  const FrotaVeiculoMovimentacaosCompanion({
    this.id = const Value.absent(),
    this.idFrotaVeiculo = const Value.absent(),
    this.idFrotaMotorista = const Value.absent(),
    this.dataSaida = const Value.absent(),
    this.horaSaida = const Value.absent(),
    this.dataEntrada = const Value.absent(),
    this.horaEntrada = const Value.absent(),
    this.observacao = const Value.absent(),
  });
  FrotaVeiculoMovimentacaosCompanion.insert({
    this.id = const Value.absent(),
    this.idFrotaVeiculo = const Value.absent(),
    this.idFrotaMotorista = const Value.absent(),
    this.dataSaida = const Value.absent(),
    this.horaSaida = const Value.absent(),
    this.dataEntrada = const Value.absent(),
    this.horaEntrada = const Value.absent(),
    this.observacao = const Value.absent(),
  });
  static Insertable<FrotaVeiculoMovimentacao> custom({
    Expression<int>? id,
    Expression<int>? idFrotaVeiculo,
    Expression<int>? idFrotaMotorista,
    Expression<DateTime>? dataSaida,
    Expression<String>? horaSaida,
    Expression<DateTime>? dataEntrada,
    Expression<String>? horaEntrada,
    Expression<String>? observacao,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (idFrotaVeiculo != null) 'id_frota_veiculo': idFrotaVeiculo,
      if (idFrotaMotorista != null) 'id_frota_motorista': idFrotaMotorista,
      if (dataSaida != null) 'data_saida': dataSaida,
      if (horaSaida != null) 'hora_saida': horaSaida,
      if (dataEntrada != null) 'data_entrada': dataEntrada,
      if (horaEntrada != null) 'hora_entrada': horaEntrada,
      if (observacao != null) 'observacao': observacao,
    });
  }

  FrotaVeiculoMovimentacaosCompanion copyWith(
      {Value<int?>? id,
      Value<int?>? idFrotaVeiculo,
      Value<int?>? idFrotaMotorista,
      Value<DateTime?>? dataSaida,
      Value<String?>? horaSaida,
      Value<DateTime?>? dataEntrada,
      Value<String?>? horaEntrada,
      Value<String?>? observacao}) {
    return FrotaVeiculoMovimentacaosCompanion(
      id: id ?? this.id,
      idFrotaVeiculo: idFrotaVeiculo ?? this.idFrotaVeiculo,
      idFrotaMotorista: idFrotaMotorista ?? this.idFrotaMotorista,
      dataSaida: dataSaida ?? this.dataSaida,
      horaSaida: horaSaida ?? this.horaSaida,
      dataEntrada: dataEntrada ?? this.dataEntrada,
      horaEntrada: horaEntrada ?? this.horaEntrada,
      observacao: observacao ?? this.observacao,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (idFrotaVeiculo.present) {
      map['id_frota_veiculo'] = Variable<int>(idFrotaVeiculo.value);
    }
    if (idFrotaMotorista.present) {
      map['id_frota_motorista'] = Variable<int>(idFrotaMotorista.value);
    }
    if (dataSaida.present) {
      map['data_saida'] = Variable<DateTime>(dataSaida.value);
    }
    if (horaSaida.present) {
      map['hora_saida'] = Variable<String>(horaSaida.value);
    }
    if (dataEntrada.present) {
      map['data_entrada'] = Variable<DateTime>(dataEntrada.value);
    }
    if (horaEntrada.present) {
      map['hora_entrada'] = Variable<String>(horaEntrada.value);
    }
    if (observacao.present) {
      map['observacao'] = Variable<String>(observacao.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('FrotaVeiculoMovimentacaosCompanion(')
          ..write('id: $id, ')
          ..write('idFrotaVeiculo: $idFrotaVeiculo, ')
          ..write('idFrotaMotorista: $idFrotaMotorista, ')
          ..write('dataSaida: $dataSaida, ')
          ..write('horaSaida: $horaSaida, ')
          ..write('dataEntrada: $dataEntrada, ')
          ..write('horaEntrada: $horaEntrada, ')
          ..write('observacao: $observacao')
          ..write(')'))
        .toString();
  }
}

class $FrotaVeiculoPneusTable extends FrotaVeiculoPneus
    with TableInfo<$FrotaVeiculoPneusTable, FrotaVeiculoPneu> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $FrotaVeiculoPneusTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
      'id', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _idFrotaVeiculoMeta =
      const VerificationMeta('idFrotaVeiculo');
  @override
  late final GeneratedColumn<int> idFrotaVeiculo = GeneratedColumn<int>(
      'id_frota_veiculo', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _dataTrocaMeta =
      const VerificationMeta('dataTroca');
  @override
  late final GeneratedColumn<DateTime> dataTroca = GeneratedColumn<DateTime>(
      'data_troca', aliasedName, true,
      type: DriftSqlType.dateTime, requiredDuringInsert: false);
  static const VerificationMeta _valorTrocaMeta =
      const VerificationMeta('valorTroca');
  @override
  late final GeneratedColumn<double> valorTroca = GeneratedColumn<double>(
      'valor_troca', aliasedName, true,
      type: DriftSqlType.double, requiredDuringInsert: false);
  static const VerificationMeta _posicaoPneuMeta =
      const VerificationMeta('posicaoPneu');
  @override
  late final GeneratedColumn<String> posicaoPneu = GeneratedColumn<String>(
      'posicao_pneu', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 100),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _marcaPneuMeta =
      const VerificationMeta('marcaPneu');
  @override
  late final GeneratedColumn<String> marcaPneu = GeneratedColumn<String>(
      'marca_pneu', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 100),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  @override
  List<GeneratedColumn> get $columns =>
      [id, idFrotaVeiculo, dataTroca, valorTroca, posicaoPneu, marcaPneu];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'frota_veiculo_pneu';
  @override
  VerificationContext validateIntegrity(Insertable<FrotaVeiculoPneu> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('id_frota_veiculo')) {
      context.handle(
          _idFrotaVeiculoMeta,
          idFrotaVeiculo.isAcceptableOrUnknown(
              data['id_frota_veiculo']!, _idFrotaVeiculoMeta));
    }
    if (data.containsKey('data_troca')) {
      context.handle(_dataTrocaMeta,
          dataTroca.isAcceptableOrUnknown(data['data_troca']!, _dataTrocaMeta));
    }
    if (data.containsKey('valor_troca')) {
      context.handle(
          _valorTrocaMeta,
          valorTroca.isAcceptableOrUnknown(
              data['valor_troca']!, _valorTrocaMeta));
    }
    if (data.containsKey('posicao_pneu')) {
      context.handle(
          _posicaoPneuMeta,
          posicaoPneu.isAcceptableOrUnknown(
              data['posicao_pneu']!, _posicaoPneuMeta));
    }
    if (data.containsKey('marca_pneu')) {
      context.handle(_marcaPneuMeta,
          marcaPneu.isAcceptableOrUnknown(data['marca_pneu']!, _marcaPneuMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  FrotaVeiculoPneu map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return FrotaVeiculoPneu(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id']),
      idFrotaVeiculo: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id_frota_veiculo']),
      dataTroca: attachedDatabase.typeMapping
          .read(DriftSqlType.dateTime, data['${effectivePrefix}data_troca']),
      valorTroca: attachedDatabase.typeMapping
          .read(DriftSqlType.double, data['${effectivePrefix}valor_troca']),
      posicaoPneu: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}posicao_pneu']),
      marcaPneu: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}marca_pneu']),
    );
  }

  @override
  $FrotaVeiculoPneusTable createAlias(String alias) {
    return $FrotaVeiculoPneusTable(attachedDatabase, alias);
  }
}

class FrotaVeiculoPneu extends DataClass
    implements Insertable<FrotaVeiculoPneu> {
  final int? id;
  final int? idFrotaVeiculo;
  final DateTime? dataTroca;
  final double? valorTroca;
  final String? posicaoPneu;
  final String? marcaPneu;
  const FrotaVeiculoPneu(
      {this.id,
      this.idFrotaVeiculo,
      this.dataTroca,
      this.valorTroca,
      this.posicaoPneu,
      this.marcaPneu});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || idFrotaVeiculo != null) {
      map['id_frota_veiculo'] = Variable<int>(idFrotaVeiculo);
    }
    if (!nullToAbsent || dataTroca != null) {
      map['data_troca'] = Variable<DateTime>(dataTroca);
    }
    if (!nullToAbsent || valorTroca != null) {
      map['valor_troca'] = Variable<double>(valorTroca);
    }
    if (!nullToAbsent || posicaoPneu != null) {
      map['posicao_pneu'] = Variable<String>(posicaoPneu);
    }
    if (!nullToAbsent || marcaPneu != null) {
      map['marca_pneu'] = Variable<String>(marcaPneu);
    }
    return map;
  }

  factory FrotaVeiculoPneu.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return FrotaVeiculoPneu(
      id: serializer.fromJson<int?>(json['id']),
      idFrotaVeiculo: serializer.fromJson<int?>(json['idFrotaVeiculo']),
      dataTroca: serializer.fromJson<DateTime?>(json['dataTroca']),
      valorTroca: serializer.fromJson<double?>(json['valorTroca']),
      posicaoPneu: serializer.fromJson<String?>(json['posicaoPneu']),
      marcaPneu: serializer.fromJson<String?>(json['marcaPneu']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'idFrotaVeiculo': serializer.toJson<int?>(idFrotaVeiculo),
      'dataTroca': serializer.toJson<DateTime?>(dataTroca),
      'valorTroca': serializer.toJson<double?>(valorTroca),
      'posicaoPneu': serializer.toJson<String?>(posicaoPneu),
      'marcaPneu': serializer.toJson<String?>(marcaPneu),
    };
  }

  FrotaVeiculoPneu copyWith(
          {Value<int?> id = const Value.absent(),
          Value<int?> idFrotaVeiculo = const Value.absent(),
          Value<DateTime?> dataTroca = const Value.absent(),
          Value<double?> valorTroca = const Value.absent(),
          Value<String?> posicaoPneu = const Value.absent(),
          Value<String?> marcaPneu = const Value.absent()}) =>
      FrotaVeiculoPneu(
        id: id.present ? id.value : this.id,
        idFrotaVeiculo:
            idFrotaVeiculo.present ? idFrotaVeiculo.value : this.idFrotaVeiculo,
        dataTroca: dataTroca.present ? dataTroca.value : this.dataTroca,
        valorTroca: valorTroca.present ? valorTroca.value : this.valorTroca,
        posicaoPneu: posicaoPneu.present ? posicaoPneu.value : this.posicaoPneu,
        marcaPneu: marcaPneu.present ? marcaPneu.value : this.marcaPneu,
      );
  FrotaVeiculoPneu copyWithCompanion(FrotaVeiculoPneusCompanion data) {
    return FrotaVeiculoPneu(
      id: data.id.present ? data.id.value : this.id,
      idFrotaVeiculo: data.idFrotaVeiculo.present
          ? data.idFrotaVeiculo.value
          : this.idFrotaVeiculo,
      dataTroca: data.dataTroca.present ? data.dataTroca.value : this.dataTroca,
      valorTroca:
          data.valorTroca.present ? data.valorTroca.value : this.valorTroca,
      posicaoPneu:
          data.posicaoPneu.present ? data.posicaoPneu.value : this.posicaoPneu,
      marcaPneu: data.marcaPneu.present ? data.marcaPneu.value : this.marcaPneu,
    );
  }

  @override
  String toString() {
    return (StringBuffer('FrotaVeiculoPneu(')
          ..write('id: $id, ')
          ..write('idFrotaVeiculo: $idFrotaVeiculo, ')
          ..write('dataTroca: $dataTroca, ')
          ..write('valorTroca: $valorTroca, ')
          ..write('posicaoPneu: $posicaoPneu, ')
          ..write('marcaPneu: $marcaPneu')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(
      id, idFrotaVeiculo, dataTroca, valorTroca, posicaoPneu, marcaPneu);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is FrotaVeiculoPneu &&
          other.id == this.id &&
          other.idFrotaVeiculo == this.idFrotaVeiculo &&
          other.dataTroca == this.dataTroca &&
          other.valorTroca == this.valorTroca &&
          other.posicaoPneu == this.posicaoPneu &&
          other.marcaPneu == this.marcaPneu);
}

class FrotaVeiculoPneusCompanion extends UpdateCompanion<FrotaVeiculoPneu> {
  final Value<int?> id;
  final Value<int?> idFrotaVeiculo;
  final Value<DateTime?> dataTroca;
  final Value<double?> valorTroca;
  final Value<String?> posicaoPneu;
  final Value<String?> marcaPneu;
  const FrotaVeiculoPneusCompanion({
    this.id = const Value.absent(),
    this.idFrotaVeiculo = const Value.absent(),
    this.dataTroca = const Value.absent(),
    this.valorTroca = const Value.absent(),
    this.posicaoPneu = const Value.absent(),
    this.marcaPneu = const Value.absent(),
  });
  FrotaVeiculoPneusCompanion.insert({
    this.id = const Value.absent(),
    this.idFrotaVeiculo = const Value.absent(),
    this.dataTroca = const Value.absent(),
    this.valorTroca = const Value.absent(),
    this.posicaoPneu = const Value.absent(),
    this.marcaPneu = const Value.absent(),
  });
  static Insertable<FrotaVeiculoPneu> custom({
    Expression<int>? id,
    Expression<int>? idFrotaVeiculo,
    Expression<DateTime>? dataTroca,
    Expression<double>? valorTroca,
    Expression<String>? posicaoPneu,
    Expression<String>? marcaPneu,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (idFrotaVeiculo != null) 'id_frota_veiculo': idFrotaVeiculo,
      if (dataTroca != null) 'data_troca': dataTroca,
      if (valorTroca != null) 'valor_troca': valorTroca,
      if (posicaoPneu != null) 'posicao_pneu': posicaoPneu,
      if (marcaPneu != null) 'marca_pneu': marcaPneu,
    });
  }

  FrotaVeiculoPneusCompanion copyWith(
      {Value<int?>? id,
      Value<int?>? idFrotaVeiculo,
      Value<DateTime?>? dataTroca,
      Value<double?>? valorTroca,
      Value<String?>? posicaoPneu,
      Value<String?>? marcaPneu}) {
    return FrotaVeiculoPneusCompanion(
      id: id ?? this.id,
      idFrotaVeiculo: idFrotaVeiculo ?? this.idFrotaVeiculo,
      dataTroca: dataTroca ?? this.dataTroca,
      valorTroca: valorTroca ?? this.valorTroca,
      posicaoPneu: posicaoPneu ?? this.posicaoPneu,
      marcaPneu: marcaPneu ?? this.marcaPneu,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (idFrotaVeiculo.present) {
      map['id_frota_veiculo'] = Variable<int>(idFrotaVeiculo.value);
    }
    if (dataTroca.present) {
      map['data_troca'] = Variable<DateTime>(dataTroca.value);
    }
    if (valorTroca.present) {
      map['valor_troca'] = Variable<double>(valorTroca.value);
    }
    if (posicaoPneu.present) {
      map['posicao_pneu'] = Variable<String>(posicaoPneu.value);
    }
    if (marcaPneu.present) {
      map['marca_pneu'] = Variable<String>(marcaPneu.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('FrotaVeiculoPneusCompanion(')
          ..write('id: $id, ')
          ..write('idFrotaVeiculo: $idFrotaVeiculo, ')
          ..write('dataTroca: $dataTroca, ')
          ..write('valorTroca: $valorTroca, ')
          ..write('posicaoPneu: $posicaoPneu, ')
          ..write('marcaPneu: $marcaPneu')
          ..write(')'))
        .toString();
  }
}

class $FrotaVeiculoManutencaosTable extends FrotaVeiculoManutencaos
    with TableInfo<$FrotaVeiculoManutencaosTable, FrotaVeiculoManutencao> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $FrotaVeiculoManutencaosTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
      'id', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _idFrotaVeiculoMeta =
      const VerificationMeta('idFrotaVeiculo');
  @override
  late final GeneratedColumn<int> idFrotaVeiculo = GeneratedColumn<int>(
      'id_frota_veiculo', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _tipoMeta = const VerificationMeta('tipo');
  @override
  late final GeneratedColumn<String> tipo = GeneratedColumn<String>(
      'tipo', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 1),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _dataManutencaoMeta =
      const VerificationMeta('dataManutencao');
  @override
  late final GeneratedColumn<DateTime> dataManutencao =
      GeneratedColumn<DateTime>('data_manutencao', aliasedName, true,
          type: DriftSqlType.dateTime, requiredDuringInsert: false);
  static const VerificationMeta _valorManutencaoMeta =
      const VerificationMeta('valorManutencao');
  @override
  late final GeneratedColumn<double> valorManutencao = GeneratedColumn<double>(
      'valor_manutencao', aliasedName, true,
      type: DriftSqlType.double, requiredDuringInsert: false);
  static const VerificationMeta _observacaoMeta =
      const VerificationMeta('observacao');
  @override
  late final GeneratedColumn<String> observacao = GeneratedColumn<String>(
      'observacao', aliasedName, true,
      type: DriftSqlType.string, requiredDuringInsert: false);
  @override
  List<GeneratedColumn> get $columns =>
      [id, idFrotaVeiculo, tipo, dataManutencao, valorManutencao, observacao];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'frota_veiculo_manutencao';
  @override
  VerificationContext validateIntegrity(
      Insertable<FrotaVeiculoManutencao> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('id_frota_veiculo')) {
      context.handle(
          _idFrotaVeiculoMeta,
          idFrotaVeiculo.isAcceptableOrUnknown(
              data['id_frota_veiculo']!, _idFrotaVeiculoMeta));
    }
    if (data.containsKey('tipo')) {
      context.handle(
          _tipoMeta, tipo.isAcceptableOrUnknown(data['tipo']!, _tipoMeta));
    }
    if (data.containsKey('data_manutencao')) {
      context.handle(
          _dataManutencaoMeta,
          dataManutencao.isAcceptableOrUnknown(
              data['data_manutencao']!, _dataManutencaoMeta));
    }
    if (data.containsKey('valor_manutencao')) {
      context.handle(
          _valorManutencaoMeta,
          valorManutencao.isAcceptableOrUnknown(
              data['valor_manutencao']!, _valorManutencaoMeta));
    }
    if (data.containsKey('observacao')) {
      context.handle(
          _observacaoMeta,
          observacao.isAcceptableOrUnknown(
              data['observacao']!, _observacaoMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  FrotaVeiculoManutencao map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return FrotaVeiculoManutencao(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id']),
      idFrotaVeiculo: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id_frota_veiculo']),
      tipo: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}tipo']),
      dataManutencao: attachedDatabase.typeMapping.read(
          DriftSqlType.dateTime, data['${effectivePrefix}data_manutencao']),
      valorManutencao: attachedDatabase.typeMapping.read(
          DriftSqlType.double, data['${effectivePrefix}valor_manutencao']),
      observacao: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}observacao']),
    );
  }

  @override
  $FrotaVeiculoManutencaosTable createAlias(String alias) {
    return $FrotaVeiculoManutencaosTable(attachedDatabase, alias);
  }
}

class FrotaVeiculoManutencao extends DataClass
    implements Insertable<FrotaVeiculoManutencao> {
  final int? id;
  final int? idFrotaVeiculo;
  final String? tipo;
  final DateTime? dataManutencao;
  final double? valorManutencao;
  final String? observacao;
  const FrotaVeiculoManutencao(
      {this.id,
      this.idFrotaVeiculo,
      this.tipo,
      this.dataManutencao,
      this.valorManutencao,
      this.observacao});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || idFrotaVeiculo != null) {
      map['id_frota_veiculo'] = Variable<int>(idFrotaVeiculo);
    }
    if (!nullToAbsent || tipo != null) {
      map['tipo'] = Variable<String>(tipo);
    }
    if (!nullToAbsent || dataManutencao != null) {
      map['data_manutencao'] = Variable<DateTime>(dataManutencao);
    }
    if (!nullToAbsent || valorManutencao != null) {
      map['valor_manutencao'] = Variable<double>(valorManutencao);
    }
    if (!nullToAbsent || observacao != null) {
      map['observacao'] = Variable<String>(observacao);
    }
    return map;
  }

  factory FrotaVeiculoManutencao.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return FrotaVeiculoManutencao(
      id: serializer.fromJson<int?>(json['id']),
      idFrotaVeiculo: serializer.fromJson<int?>(json['idFrotaVeiculo']),
      tipo: serializer.fromJson<String?>(json['tipo']),
      dataManutencao: serializer.fromJson<DateTime?>(json['dataManutencao']),
      valorManutencao: serializer.fromJson<double?>(json['valorManutencao']),
      observacao: serializer.fromJson<String?>(json['observacao']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'idFrotaVeiculo': serializer.toJson<int?>(idFrotaVeiculo),
      'tipo': serializer.toJson<String?>(tipo),
      'dataManutencao': serializer.toJson<DateTime?>(dataManutencao),
      'valorManutencao': serializer.toJson<double?>(valorManutencao),
      'observacao': serializer.toJson<String?>(observacao),
    };
  }

  FrotaVeiculoManutencao copyWith(
          {Value<int?> id = const Value.absent(),
          Value<int?> idFrotaVeiculo = const Value.absent(),
          Value<String?> tipo = const Value.absent(),
          Value<DateTime?> dataManutencao = const Value.absent(),
          Value<double?> valorManutencao = const Value.absent(),
          Value<String?> observacao = const Value.absent()}) =>
      FrotaVeiculoManutencao(
        id: id.present ? id.value : this.id,
        idFrotaVeiculo:
            idFrotaVeiculo.present ? idFrotaVeiculo.value : this.idFrotaVeiculo,
        tipo: tipo.present ? tipo.value : this.tipo,
        dataManutencao:
            dataManutencao.present ? dataManutencao.value : this.dataManutencao,
        valorManutencao: valorManutencao.present
            ? valorManutencao.value
            : this.valorManutencao,
        observacao: observacao.present ? observacao.value : this.observacao,
      );
  FrotaVeiculoManutencao copyWithCompanion(
      FrotaVeiculoManutencaosCompanion data) {
    return FrotaVeiculoManutencao(
      id: data.id.present ? data.id.value : this.id,
      idFrotaVeiculo: data.idFrotaVeiculo.present
          ? data.idFrotaVeiculo.value
          : this.idFrotaVeiculo,
      tipo: data.tipo.present ? data.tipo.value : this.tipo,
      dataManutencao: data.dataManutencao.present
          ? data.dataManutencao.value
          : this.dataManutencao,
      valorManutencao: data.valorManutencao.present
          ? data.valorManutencao.value
          : this.valorManutencao,
      observacao:
          data.observacao.present ? data.observacao.value : this.observacao,
    );
  }

  @override
  String toString() {
    return (StringBuffer('FrotaVeiculoManutencao(')
          ..write('id: $id, ')
          ..write('idFrotaVeiculo: $idFrotaVeiculo, ')
          ..write('tipo: $tipo, ')
          ..write('dataManutencao: $dataManutencao, ')
          ..write('valorManutencao: $valorManutencao, ')
          ..write('observacao: $observacao')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(
      id, idFrotaVeiculo, tipo, dataManutencao, valorManutencao, observacao);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is FrotaVeiculoManutencao &&
          other.id == this.id &&
          other.idFrotaVeiculo == this.idFrotaVeiculo &&
          other.tipo == this.tipo &&
          other.dataManutencao == this.dataManutencao &&
          other.valorManutencao == this.valorManutencao &&
          other.observacao == this.observacao);
}

class FrotaVeiculoManutencaosCompanion
    extends UpdateCompanion<FrotaVeiculoManutencao> {
  final Value<int?> id;
  final Value<int?> idFrotaVeiculo;
  final Value<String?> tipo;
  final Value<DateTime?> dataManutencao;
  final Value<double?> valorManutencao;
  final Value<String?> observacao;
  const FrotaVeiculoManutencaosCompanion({
    this.id = const Value.absent(),
    this.idFrotaVeiculo = const Value.absent(),
    this.tipo = const Value.absent(),
    this.dataManutencao = const Value.absent(),
    this.valorManutencao = const Value.absent(),
    this.observacao = const Value.absent(),
  });
  FrotaVeiculoManutencaosCompanion.insert({
    this.id = const Value.absent(),
    this.idFrotaVeiculo = const Value.absent(),
    this.tipo = const Value.absent(),
    this.dataManutencao = const Value.absent(),
    this.valorManutencao = const Value.absent(),
    this.observacao = const Value.absent(),
  });
  static Insertable<FrotaVeiculoManutencao> custom({
    Expression<int>? id,
    Expression<int>? idFrotaVeiculo,
    Expression<String>? tipo,
    Expression<DateTime>? dataManutencao,
    Expression<double>? valorManutencao,
    Expression<String>? observacao,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (idFrotaVeiculo != null) 'id_frota_veiculo': idFrotaVeiculo,
      if (tipo != null) 'tipo': tipo,
      if (dataManutencao != null) 'data_manutencao': dataManutencao,
      if (valorManutencao != null) 'valor_manutencao': valorManutencao,
      if (observacao != null) 'observacao': observacao,
    });
  }

  FrotaVeiculoManutencaosCompanion copyWith(
      {Value<int?>? id,
      Value<int?>? idFrotaVeiculo,
      Value<String?>? tipo,
      Value<DateTime?>? dataManutencao,
      Value<double?>? valorManutencao,
      Value<String?>? observacao}) {
    return FrotaVeiculoManutencaosCompanion(
      id: id ?? this.id,
      idFrotaVeiculo: idFrotaVeiculo ?? this.idFrotaVeiculo,
      tipo: tipo ?? this.tipo,
      dataManutencao: dataManutencao ?? this.dataManutencao,
      valorManutencao: valorManutencao ?? this.valorManutencao,
      observacao: observacao ?? this.observacao,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (idFrotaVeiculo.present) {
      map['id_frota_veiculo'] = Variable<int>(idFrotaVeiculo.value);
    }
    if (tipo.present) {
      map['tipo'] = Variable<String>(tipo.value);
    }
    if (dataManutencao.present) {
      map['data_manutencao'] = Variable<DateTime>(dataManutencao.value);
    }
    if (valorManutencao.present) {
      map['valor_manutencao'] = Variable<double>(valorManutencao.value);
    }
    if (observacao.present) {
      map['observacao'] = Variable<String>(observacao.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('FrotaVeiculoManutencaosCompanion(')
          ..write('id: $id, ')
          ..write('idFrotaVeiculo: $idFrotaVeiculo, ')
          ..write('tipo: $tipo, ')
          ..write('dataManutencao: $dataManutencao, ')
          ..write('valorManutencao: $valorManutencao, ')
          ..write('observacao: $observacao')
          ..write(')'))
        .toString();
  }
}

class $FrotaMultaControlesTable extends FrotaMultaControles
    with TableInfo<$FrotaMultaControlesTable, FrotaMultaControle> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $FrotaMultaControlesTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
      'id', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _idFrotaVeiculoMeta =
      const VerificationMeta('idFrotaVeiculo');
  @override
  late final GeneratedColumn<int> idFrotaVeiculo = GeneratedColumn<int>(
      'id_frota_veiculo', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _dataMultaMeta =
      const VerificationMeta('dataMulta');
  @override
  late final GeneratedColumn<DateTime> dataMulta = GeneratedColumn<DateTime>(
      'data_multa', aliasedName, true,
      type: DriftSqlType.dateTime, requiredDuringInsert: false);
  static const VerificationMeta _pontosMeta = const VerificationMeta('pontos');
  @override
  late final GeneratedColumn<int> pontos = GeneratedColumn<int>(
      'pontos', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _valorMeta = const VerificationMeta('valor');
  @override
  late final GeneratedColumn<double> valor = GeneratedColumn<double>(
      'valor', aliasedName, true,
      type: DriftSqlType.double, requiredDuringInsert: false);
  static const VerificationMeta _observacaoMeta =
      const VerificationMeta('observacao');
  @override
  late final GeneratedColumn<String> observacao = GeneratedColumn<String>(
      'observacao', aliasedName, true,
      type: DriftSqlType.string, requiredDuringInsert: false);
  @override
  List<GeneratedColumn> get $columns =>
      [id, idFrotaVeiculo, dataMulta, pontos, valor, observacao];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'frota_multa_controle';
  @override
  VerificationContext validateIntegrity(Insertable<FrotaMultaControle> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('id_frota_veiculo')) {
      context.handle(
          _idFrotaVeiculoMeta,
          idFrotaVeiculo.isAcceptableOrUnknown(
              data['id_frota_veiculo']!, _idFrotaVeiculoMeta));
    }
    if (data.containsKey('data_multa')) {
      context.handle(_dataMultaMeta,
          dataMulta.isAcceptableOrUnknown(data['data_multa']!, _dataMultaMeta));
    }
    if (data.containsKey('pontos')) {
      context.handle(_pontosMeta,
          pontos.isAcceptableOrUnknown(data['pontos']!, _pontosMeta));
    }
    if (data.containsKey('valor')) {
      context.handle(
          _valorMeta, valor.isAcceptableOrUnknown(data['valor']!, _valorMeta));
    }
    if (data.containsKey('observacao')) {
      context.handle(
          _observacaoMeta,
          observacao.isAcceptableOrUnknown(
              data['observacao']!, _observacaoMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  FrotaMultaControle map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return FrotaMultaControle(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id']),
      idFrotaVeiculo: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id_frota_veiculo']),
      dataMulta: attachedDatabase.typeMapping
          .read(DriftSqlType.dateTime, data['${effectivePrefix}data_multa']),
      pontos: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}pontos']),
      valor: attachedDatabase.typeMapping
          .read(DriftSqlType.double, data['${effectivePrefix}valor']),
      observacao: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}observacao']),
    );
  }

  @override
  $FrotaMultaControlesTable createAlias(String alias) {
    return $FrotaMultaControlesTable(attachedDatabase, alias);
  }
}

class FrotaMultaControle extends DataClass
    implements Insertable<FrotaMultaControle> {
  final int? id;
  final int? idFrotaVeiculo;
  final DateTime? dataMulta;
  final int? pontos;
  final double? valor;
  final String? observacao;
  const FrotaMultaControle(
      {this.id,
      this.idFrotaVeiculo,
      this.dataMulta,
      this.pontos,
      this.valor,
      this.observacao});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || idFrotaVeiculo != null) {
      map['id_frota_veiculo'] = Variable<int>(idFrotaVeiculo);
    }
    if (!nullToAbsent || dataMulta != null) {
      map['data_multa'] = Variable<DateTime>(dataMulta);
    }
    if (!nullToAbsent || pontos != null) {
      map['pontos'] = Variable<int>(pontos);
    }
    if (!nullToAbsent || valor != null) {
      map['valor'] = Variable<double>(valor);
    }
    if (!nullToAbsent || observacao != null) {
      map['observacao'] = Variable<String>(observacao);
    }
    return map;
  }

  factory FrotaMultaControle.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return FrotaMultaControle(
      id: serializer.fromJson<int?>(json['id']),
      idFrotaVeiculo: serializer.fromJson<int?>(json['idFrotaVeiculo']),
      dataMulta: serializer.fromJson<DateTime?>(json['dataMulta']),
      pontos: serializer.fromJson<int?>(json['pontos']),
      valor: serializer.fromJson<double?>(json['valor']),
      observacao: serializer.fromJson<String?>(json['observacao']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'idFrotaVeiculo': serializer.toJson<int?>(idFrotaVeiculo),
      'dataMulta': serializer.toJson<DateTime?>(dataMulta),
      'pontos': serializer.toJson<int?>(pontos),
      'valor': serializer.toJson<double?>(valor),
      'observacao': serializer.toJson<String?>(observacao),
    };
  }

  FrotaMultaControle copyWith(
          {Value<int?> id = const Value.absent(),
          Value<int?> idFrotaVeiculo = const Value.absent(),
          Value<DateTime?> dataMulta = const Value.absent(),
          Value<int?> pontos = const Value.absent(),
          Value<double?> valor = const Value.absent(),
          Value<String?> observacao = const Value.absent()}) =>
      FrotaMultaControle(
        id: id.present ? id.value : this.id,
        idFrotaVeiculo:
            idFrotaVeiculo.present ? idFrotaVeiculo.value : this.idFrotaVeiculo,
        dataMulta: dataMulta.present ? dataMulta.value : this.dataMulta,
        pontos: pontos.present ? pontos.value : this.pontos,
        valor: valor.present ? valor.value : this.valor,
        observacao: observacao.present ? observacao.value : this.observacao,
      );
  FrotaMultaControle copyWithCompanion(FrotaMultaControlesCompanion data) {
    return FrotaMultaControle(
      id: data.id.present ? data.id.value : this.id,
      idFrotaVeiculo: data.idFrotaVeiculo.present
          ? data.idFrotaVeiculo.value
          : this.idFrotaVeiculo,
      dataMulta: data.dataMulta.present ? data.dataMulta.value : this.dataMulta,
      pontos: data.pontos.present ? data.pontos.value : this.pontos,
      valor: data.valor.present ? data.valor.value : this.valor,
      observacao:
          data.observacao.present ? data.observacao.value : this.observacao,
    );
  }

  @override
  String toString() {
    return (StringBuffer('FrotaMultaControle(')
          ..write('id: $id, ')
          ..write('idFrotaVeiculo: $idFrotaVeiculo, ')
          ..write('dataMulta: $dataMulta, ')
          ..write('pontos: $pontos, ')
          ..write('valor: $valor, ')
          ..write('observacao: $observacao')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode =>
      Object.hash(id, idFrotaVeiculo, dataMulta, pontos, valor, observacao);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is FrotaMultaControle &&
          other.id == this.id &&
          other.idFrotaVeiculo == this.idFrotaVeiculo &&
          other.dataMulta == this.dataMulta &&
          other.pontos == this.pontos &&
          other.valor == this.valor &&
          other.observacao == this.observacao);
}

class FrotaMultaControlesCompanion extends UpdateCompanion<FrotaMultaControle> {
  final Value<int?> id;
  final Value<int?> idFrotaVeiculo;
  final Value<DateTime?> dataMulta;
  final Value<int?> pontos;
  final Value<double?> valor;
  final Value<String?> observacao;
  const FrotaMultaControlesCompanion({
    this.id = const Value.absent(),
    this.idFrotaVeiculo = const Value.absent(),
    this.dataMulta = const Value.absent(),
    this.pontos = const Value.absent(),
    this.valor = const Value.absent(),
    this.observacao = const Value.absent(),
  });
  FrotaMultaControlesCompanion.insert({
    this.id = const Value.absent(),
    this.idFrotaVeiculo = const Value.absent(),
    this.dataMulta = const Value.absent(),
    this.pontos = const Value.absent(),
    this.valor = const Value.absent(),
    this.observacao = const Value.absent(),
  });
  static Insertable<FrotaMultaControle> custom({
    Expression<int>? id,
    Expression<int>? idFrotaVeiculo,
    Expression<DateTime>? dataMulta,
    Expression<int>? pontos,
    Expression<double>? valor,
    Expression<String>? observacao,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (idFrotaVeiculo != null) 'id_frota_veiculo': idFrotaVeiculo,
      if (dataMulta != null) 'data_multa': dataMulta,
      if (pontos != null) 'pontos': pontos,
      if (valor != null) 'valor': valor,
      if (observacao != null) 'observacao': observacao,
    });
  }

  FrotaMultaControlesCompanion copyWith(
      {Value<int?>? id,
      Value<int?>? idFrotaVeiculo,
      Value<DateTime?>? dataMulta,
      Value<int?>? pontos,
      Value<double?>? valor,
      Value<String?>? observacao}) {
    return FrotaMultaControlesCompanion(
      id: id ?? this.id,
      idFrotaVeiculo: idFrotaVeiculo ?? this.idFrotaVeiculo,
      dataMulta: dataMulta ?? this.dataMulta,
      pontos: pontos ?? this.pontos,
      valor: valor ?? this.valor,
      observacao: observacao ?? this.observacao,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (idFrotaVeiculo.present) {
      map['id_frota_veiculo'] = Variable<int>(idFrotaVeiculo.value);
    }
    if (dataMulta.present) {
      map['data_multa'] = Variable<DateTime>(dataMulta.value);
    }
    if (pontos.present) {
      map['pontos'] = Variable<int>(pontos.value);
    }
    if (valor.present) {
      map['valor'] = Variable<double>(valor.value);
    }
    if (observacao.present) {
      map['observacao'] = Variable<String>(observacao.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('FrotaMultaControlesCompanion(')
          ..write('id: $id, ')
          ..write('idFrotaVeiculo: $idFrotaVeiculo, ')
          ..write('dataMulta: $dataMulta, ')
          ..write('pontos: $pontos, ')
          ..write('valor: $valor, ')
          ..write('observacao: $observacao')
          ..write(')'))
        .toString();
  }
}

class $FrotaCombustivelControlesTable extends FrotaCombustivelControles
    with TableInfo<$FrotaCombustivelControlesTable, FrotaCombustivelControle> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $FrotaCombustivelControlesTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
      'id', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _idFrotaVeiculoMeta =
      const VerificationMeta('idFrotaVeiculo');
  @override
  late final GeneratedColumn<int> idFrotaVeiculo = GeneratedColumn<int>(
      'id_frota_veiculo', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _dataAbastecimentoMeta =
      const VerificationMeta('dataAbastecimento');
  @override
  late final GeneratedColumn<DateTime> dataAbastecimento =
      GeneratedColumn<DateTime>('data_abastecimento', aliasedName, true,
          type: DriftSqlType.dateTime, requiredDuringInsert: false);
  static const VerificationMeta _horaAbastecimentoMeta =
      const VerificationMeta('horaAbastecimento');
  @override
  late final GeneratedColumn<String> horaAbastecimento =
      GeneratedColumn<String>('hora_abastecimento', aliasedName, true,
          additionalChecks: GeneratedColumn.checkTextLength(
              minTextLength: 0, maxTextLength: 8),
          type: DriftSqlType.string,
          requiredDuringInsert: false);
  static const VerificationMeta _valorAbastecimentoMeta =
      const VerificationMeta('valorAbastecimento');
  @override
  late final GeneratedColumn<double> valorAbastecimento =
      GeneratedColumn<double>('valor_abastecimento', aliasedName, true,
          type: DriftSqlType.double, requiredDuringInsert: false);
  @override
  List<GeneratedColumn> get $columns => [
        id,
        idFrotaVeiculo,
        dataAbastecimento,
        horaAbastecimento,
        valorAbastecimento
      ];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'frota_combustivel_controle';
  @override
  VerificationContext validateIntegrity(
      Insertable<FrotaCombustivelControle> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('id_frota_veiculo')) {
      context.handle(
          _idFrotaVeiculoMeta,
          idFrotaVeiculo.isAcceptableOrUnknown(
              data['id_frota_veiculo']!, _idFrotaVeiculoMeta));
    }
    if (data.containsKey('data_abastecimento')) {
      context.handle(
          _dataAbastecimentoMeta,
          dataAbastecimento.isAcceptableOrUnknown(
              data['data_abastecimento']!, _dataAbastecimentoMeta));
    }
    if (data.containsKey('hora_abastecimento')) {
      context.handle(
          _horaAbastecimentoMeta,
          horaAbastecimento.isAcceptableOrUnknown(
              data['hora_abastecimento']!, _horaAbastecimentoMeta));
    }
    if (data.containsKey('valor_abastecimento')) {
      context.handle(
          _valorAbastecimentoMeta,
          valorAbastecimento.isAcceptableOrUnknown(
              data['valor_abastecimento']!, _valorAbastecimentoMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  FrotaCombustivelControle map(Map<String, dynamic> data,
      {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return FrotaCombustivelControle(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id']),
      idFrotaVeiculo: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id_frota_veiculo']),
      dataAbastecimento: attachedDatabase.typeMapping.read(
          DriftSqlType.dateTime, data['${effectivePrefix}data_abastecimento']),
      horaAbastecimento: attachedDatabase.typeMapping.read(
          DriftSqlType.string, data['${effectivePrefix}hora_abastecimento']),
      valorAbastecimento: attachedDatabase.typeMapping.read(
          DriftSqlType.double, data['${effectivePrefix}valor_abastecimento']),
    );
  }

  @override
  $FrotaCombustivelControlesTable createAlias(String alias) {
    return $FrotaCombustivelControlesTable(attachedDatabase, alias);
  }
}

class FrotaCombustivelControle extends DataClass
    implements Insertable<FrotaCombustivelControle> {
  final int? id;
  final int? idFrotaVeiculo;
  final DateTime? dataAbastecimento;
  final String? horaAbastecimento;
  final double? valorAbastecimento;
  const FrotaCombustivelControle(
      {this.id,
      this.idFrotaVeiculo,
      this.dataAbastecimento,
      this.horaAbastecimento,
      this.valorAbastecimento});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || idFrotaVeiculo != null) {
      map['id_frota_veiculo'] = Variable<int>(idFrotaVeiculo);
    }
    if (!nullToAbsent || dataAbastecimento != null) {
      map['data_abastecimento'] = Variable<DateTime>(dataAbastecimento);
    }
    if (!nullToAbsent || horaAbastecimento != null) {
      map['hora_abastecimento'] = Variable<String>(horaAbastecimento);
    }
    if (!nullToAbsent || valorAbastecimento != null) {
      map['valor_abastecimento'] = Variable<double>(valorAbastecimento);
    }
    return map;
  }

  factory FrotaCombustivelControle.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return FrotaCombustivelControle(
      id: serializer.fromJson<int?>(json['id']),
      idFrotaVeiculo: serializer.fromJson<int?>(json['idFrotaVeiculo']),
      dataAbastecimento:
          serializer.fromJson<DateTime?>(json['dataAbastecimento']),
      horaAbastecimento:
          serializer.fromJson<String?>(json['horaAbastecimento']),
      valorAbastecimento:
          serializer.fromJson<double?>(json['valorAbastecimento']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'idFrotaVeiculo': serializer.toJson<int?>(idFrotaVeiculo),
      'dataAbastecimento': serializer.toJson<DateTime?>(dataAbastecimento),
      'horaAbastecimento': serializer.toJson<String?>(horaAbastecimento),
      'valorAbastecimento': serializer.toJson<double?>(valorAbastecimento),
    };
  }

  FrotaCombustivelControle copyWith(
          {Value<int?> id = const Value.absent(),
          Value<int?> idFrotaVeiculo = const Value.absent(),
          Value<DateTime?> dataAbastecimento = const Value.absent(),
          Value<String?> horaAbastecimento = const Value.absent(),
          Value<double?> valorAbastecimento = const Value.absent()}) =>
      FrotaCombustivelControle(
        id: id.present ? id.value : this.id,
        idFrotaVeiculo:
            idFrotaVeiculo.present ? idFrotaVeiculo.value : this.idFrotaVeiculo,
        dataAbastecimento: dataAbastecimento.present
            ? dataAbastecimento.value
            : this.dataAbastecimento,
        horaAbastecimento: horaAbastecimento.present
            ? horaAbastecimento.value
            : this.horaAbastecimento,
        valorAbastecimento: valorAbastecimento.present
            ? valorAbastecimento.value
            : this.valorAbastecimento,
      );
  FrotaCombustivelControle copyWithCompanion(
      FrotaCombustivelControlesCompanion data) {
    return FrotaCombustivelControle(
      id: data.id.present ? data.id.value : this.id,
      idFrotaVeiculo: data.idFrotaVeiculo.present
          ? data.idFrotaVeiculo.value
          : this.idFrotaVeiculo,
      dataAbastecimento: data.dataAbastecimento.present
          ? data.dataAbastecimento.value
          : this.dataAbastecimento,
      horaAbastecimento: data.horaAbastecimento.present
          ? data.horaAbastecimento.value
          : this.horaAbastecimento,
      valorAbastecimento: data.valorAbastecimento.present
          ? data.valorAbastecimento.value
          : this.valorAbastecimento,
    );
  }

  @override
  String toString() {
    return (StringBuffer('FrotaCombustivelControle(')
          ..write('id: $id, ')
          ..write('idFrotaVeiculo: $idFrotaVeiculo, ')
          ..write('dataAbastecimento: $dataAbastecimento, ')
          ..write('horaAbastecimento: $horaAbastecimento, ')
          ..write('valorAbastecimento: $valorAbastecimento')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(id, idFrotaVeiculo, dataAbastecimento,
      horaAbastecimento, valorAbastecimento);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is FrotaCombustivelControle &&
          other.id == this.id &&
          other.idFrotaVeiculo == this.idFrotaVeiculo &&
          other.dataAbastecimento == this.dataAbastecimento &&
          other.horaAbastecimento == this.horaAbastecimento &&
          other.valorAbastecimento == this.valorAbastecimento);
}

class FrotaCombustivelControlesCompanion
    extends UpdateCompanion<FrotaCombustivelControle> {
  final Value<int?> id;
  final Value<int?> idFrotaVeiculo;
  final Value<DateTime?> dataAbastecimento;
  final Value<String?> horaAbastecimento;
  final Value<double?> valorAbastecimento;
  const FrotaCombustivelControlesCompanion({
    this.id = const Value.absent(),
    this.idFrotaVeiculo = const Value.absent(),
    this.dataAbastecimento = const Value.absent(),
    this.horaAbastecimento = const Value.absent(),
    this.valorAbastecimento = const Value.absent(),
  });
  FrotaCombustivelControlesCompanion.insert({
    this.id = const Value.absent(),
    this.idFrotaVeiculo = const Value.absent(),
    this.dataAbastecimento = const Value.absent(),
    this.horaAbastecimento = const Value.absent(),
    this.valorAbastecimento = const Value.absent(),
  });
  static Insertable<FrotaCombustivelControle> custom({
    Expression<int>? id,
    Expression<int>? idFrotaVeiculo,
    Expression<DateTime>? dataAbastecimento,
    Expression<String>? horaAbastecimento,
    Expression<double>? valorAbastecimento,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (idFrotaVeiculo != null) 'id_frota_veiculo': idFrotaVeiculo,
      if (dataAbastecimento != null) 'data_abastecimento': dataAbastecimento,
      if (horaAbastecimento != null) 'hora_abastecimento': horaAbastecimento,
      if (valorAbastecimento != null) 'valor_abastecimento': valorAbastecimento,
    });
  }

  FrotaCombustivelControlesCompanion copyWith(
      {Value<int?>? id,
      Value<int?>? idFrotaVeiculo,
      Value<DateTime?>? dataAbastecimento,
      Value<String?>? horaAbastecimento,
      Value<double?>? valorAbastecimento}) {
    return FrotaCombustivelControlesCompanion(
      id: id ?? this.id,
      idFrotaVeiculo: idFrotaVeiculo ?? this.idFrotaVeiculo,
      dataAbastecimento: dataAbastecimento ?? this.dataAbastecimento,
      horaAbastecimento: horaAbastecimento ?? this.horaAbastecimento,
      valorAbastecimento: valorAbastecimento ?? this.valorAbastecimento,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (idFrotaVeiculo.present) {
      map['id_frota_veiculo'] = Variable<int>(idFrotaVeiculo.value);
    }
    if (dataAbastecimento.present) {
      map['data_abastecimento'] = Variable<DateTime>(dataAbastecimento.value);
    }
    if (horaAbastecimento.present) {
      map['hora_abastecimento'] = Variable<String>(horaAbastecimento.value);
    }
    if (valorAbastecimento.present) {
      map['valor_abastecimento'] = Variable<double>(valorAbastecimento.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('FrotaCombustivelControlesCompanion(')
          ..write('id: $id, ')
          ..write('idFrotaVeiculo: $idFrotaVeiculo, ')
          ..write('dataAbastecimento: $dataAbastecimento, ')
          ..write('horaAbastecimento: $horaAbastecimento, ')
          ..write('valorAbastecimento: $valorAbastecimento')
          ..write(')'))
        .toString();
  }
}

class $FrotaVeiculosTable extends FrotaVeiculos
    with TableInfo<$FrotaVeiculosTable, FrotaVeiculo> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $FrotaVeiculosTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
      'id', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _idFrotaVeiculoTipoMeta =
      const VerificationMeta('idFrotaVeiculoTipo');
  @override
  late final GeneratedColumn<int> idFrotaVeiculoTipo = GeneratedColumn<int>(
      'id_frota_veiculo_tipo', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _idFrotaCombustivelTipoMeta =
      const VerificationMeta('idFrotaCombustivelTipo');
  @override
  late final GeneratedColumn<int> idFrotaCombustivelTipo = GeneratedColumn<int>(
      'id_frota_combustivel_tipo', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _marcaMeta = const VerificationMeta('marca');
  @override
  late final GeneratedColumn<String> marca = GeneratedColumn<String>(
      'marca', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 100),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _modeloMeta = const VerificationMeta('modelo');
  @override
  late final GeneratedColumn<String> modelo = GeneratedColumn<String>(
      'modelo', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 100),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _modeloAnoMeta =
      const VerificationMeta('modeloAno');
  @override
  late final GeneratedColumn<String> modeloAno = GeneratedColumn<String>(
      'modelo_ano', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 4),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _placaMeta = const VerificationMeta('placa');
  @override
  late final GeneratedColumn<String> placa = GeneratedColumn<String>(
      'placa', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 7),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _codigoFipeMeta =
      const VerificationMeta('codigoFipe');
  @override
  late final GeneratedColumn<String> codigoFipe = GeneratedColumn<String>(
      'codigo_fipe', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 7),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _renavamMeta =
      const VerificationMeta('renavam');
  @override
  late final GeneratedColumn<String> renavam = GeneratedColumn<String>(
      'renavam', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 11),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _ipvaMesVencimentoMeta =
      const VerificationMeta('ipvaMesVencimento');
  @override
  late final GeneratedColumn<String> ipvaMesVencimento =
      GeneratedColumn<String>('ipva_mes_vencimento', aliasedName, true,
          additionalChecks: GeneratedColumn.checkTextLength(
              minTextLength: 0, maxTextLength: 2),
          type: DriftSqlType.string,
          requiredDuringInsert: false);
  static const VerificationMeta _dpvatMesVencimentoMeta =
      const VerificationMeta('dpvatMesVencimento');
  @override
  late final GeneratedColumn<String> dpvatMesVencimento =
      GeneratedColumn<String>('dpvat_mes_vencimento', aliasedName, true,
          additionalChecks: GeneratedColumn.checkTextLength(
              minTextLength: 0, maxTextLength: 2),
          type: DriftSqlType.string,
          requiredDuringInsert: false);
  @override
  List<GeneratedColumn> get $columns => [
        id,
        idFrotaVeiculoTipo,
        idFrotaCombustivelTipo,
        marca,
        modelo,
        modeloAno,
        placa,
        codigoFipe,
        renavam,
        ipvaMesVencimento,
        dpvatMesVencimento
      ];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'frota_veiculo';
  @override
  VerificationContext validateIntegrity(Insertable<FrotaVeiculo> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('id_frota_veiculo_tipo')) {
      context.handle(
          _idFrotaVeiculoTipoMeta,
          idFrotaVeiculoTipo.isAcceptableOrUnknown(
              data['id_frota_veiculo_tipo']!, _idFrotaVeiculoTipoMeta));
    }
    if (data.containsKey('id_frota_combustivel_tipo')) {
      context.handle(
          _idFrotaCombustivelTipoMeta,
          idFrotaCombustivelTipo.isAcceptableOrUnknown(
              data['id_frota_combustivel_tipo']!, _idFrotaCombustivelTipoMeta));
    }
    if (data.containsKey('marca')) {
      context.handle(
          _marcaMeta, marca.isAcceptableOrUnknown(data['marca']!, _marcaMeta));
    }
    if (data.containsKey('modelo')) {
      context.handle(_modeloMeta,
          modelo.isAcceptableOrUnknown(data['modelo']!, _modeloMeta));
    }
    if (data.containsKey('modelo_ano')) {
      context.handle(_modeloAnoMeta,
          modeloAno.isAcceptableOrUnknown(data['modelo_ano']!, _modeloAnoMeta));
    }
    if (data.containsKey('placa')) {
      context.handle(
          _placaMeta, placa.isAcceptableOrUnknown(data['placa']!, _placaMeta));
    }
    if (data.containsKey('codigo_fipe')) {
      context.handle(
          _codigoFipeMeta,
          codigoFipe.isAcceptableOrUnknown(
              data['codigo_fipe']!, _codigoFipeMeta));
    }
    if (data.containsKey('renavam')) {
      context.handle(_renavamMeta,
          renavam.isAcceptableOrUnknown(data['renavam']!, _renavamMeta));
    }
    if (data.containsKey('ipva_mes_vencimento')) {
      context.handle(
          _ipvaMesVencimentoMeta,
          ipvaMesVencimento.isAcceptableOrUnknown(
              data['ipva_mes_vencimento']!, _ipvaMesVencimentoMeta));
    }
    if (data.containsKey('dpvat_mes_vencimento')) {
      context.handle(
          _dpvatMesVencimentoMeta,
          dpvatMesVencimento.isAcceptableOrUnknown(
              data['dpvat_mes_vencimento']!, _dpvatMesVencimentoMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  FrotaVeiculo map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return FrotaVeiculo(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id']),
      idFrotaVeiculoTipo: attachedDatabase.typeMapping.read(
          DriftSqlType.int, data['${effectivePrefix}id_frota_veiculo_tipo']),
      idFrotaCombustivelTipo: attachedDatabase.typeMapping.read(
          DriftSqlType.int,
          data['${effectivePrefix}id_frota_combustivel_tipo']),
      marca: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}marca']),
      modelo: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}modelo']),
      modeloAno: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}modelo_ano']),
      placa: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}placa']),
      codigoFipe: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}codigo_fipe']),
      renavam: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}renavam']),
      ipvaMesVencimento: attachedDatabase.typeMapping.read(
          DriftSqlType.string, data['${effectivePrefix}ipva_mes_vencimento']),
      dpvatMesVencimento: attachedDatabase.typeMapping.read(
          DriftSqlType.string, data['${effectivePrefix}dpvat_mes_vencimento']),
    );
  }

  @override
  $FrotaVeiculosTable createAlias(String alias) {
    return $FrotaVeiculosTable(attachedDatabase, alias);
  }
}

class FrotaVeiculo extends DataClass implements Insertable<FrotaVeiculo> {
  final int? id;
  final int? idFrotaVeiculoTipo;
  final int? idFrotaCombustivelTipo;
  final String? marca;
  final String? modelo;
  final String? modeloAno;
  final String? placa;
  final String? codigoFipe;
  final String? renavam;
  final String? ipvaMesVencimento;
  final String? dpvatMesVencimento;
  const FrotaVeiculo(
      {this.id,
      this.idFrotaVeiculoTipo,
      this.idFrotaCombustivelTipo,
      this.marca,
      this.modelo,
      this.modeloAno,
      this.placa,
      this.codigoFipe,
      this.renavam,
      this.ipvaMesVencimento,
      this.dpvatMesVencimento});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || idFrotaVeiculoTipo != null) {
      map['id_frota_veiculo_tipo'] = Variable<int>(idFrotaVeiculoTipo);
    }
    if (!nullToAbsent || idFrotaCombustivelTipo != null) {
      map['id_frota_combustivel_tipo'] = Variable<int>(idFrotaCombustivelTipo);
    }
    if (!nullToAbsent || marca != null) {
      map['marca'] = Variable<String>(marca);
    }
    if (!nullToAbsent || modelo != null) {
      map['modelo'] = Variable<String>(modelo);
    }
    if (!nullToAbsent || modeloAno != null) {
      map['modelo_ano'] = Variable<String>(modeloAno);
    }
    if (!nullToAbsent || placa != null) {
      map['placa'] = Variable<String>(placa);
    }
    if (!nullToAbsent || codigoFipe != null) {
      map['codigo_fipe'] = Variable<String>(codigoFipe);
    }
    if (!nullToAbsent || renavam != null) {
      map['renavam'] = Variable<String>(renavam);
    }
    if (!nullToAbsent || ipvaMesVencimento != null) {
      map['ipva_mes_vencimento'] = Variable<String>(ipvaMesVencimento);
    }
    if (!nullToAbsent || dpvatMesVencimento != null) {
      map['dpvat_mes_vencimento'] = Variable<String>(dpvatMesVencimento);
    }
    return map;
  }

  factory FrotaVeiculo.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return FrotaVeiculo(
      id: serializer.fromJson<int?>(json['id']),
      idFrotaVeiculoTipo: serializer.fromJson<int?>(json['idFrotaVeiculoTipo']),
      idFrotaCombustivelTipo:
          serializer.fromJson<int?>(json['idFrotaCombustivelTipo']),
      marca: serializer.fromJson<String?>(json['marca']),
      modelo: serializer.fromJson<String?>(json['modelo']),
      modeloAno: serializer.fromJson<String?>(json['modeloAno']),
      placa: serializer.fromJson<String?>(json['placa']),
      codigoFipe: serializer.fromJson<String?>(json['codigoFipe']),
      renavam: serializer.fromJson<String?>(json['renavam']),
      ipvaMesVencimento:
          serializer.fromJson<String?>(json['ipvaMesVencimento']),
      dpvatMesVencimento:
          serializer.fromJson<String?>(json['dpvatMesVencimento']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'idFrotaVeiculoTipo': serializer.toJson<int?>(idFrotaVeiculoTipo),
      'idFrotaCombustivelTipo': serializer.toJson<int?>(idFrotaCombustivelTipo),
      'marca': serializer.toJson<String?>(marca),
      'modelo': serializer.toJson<String?>(modelo),
      'modeloAno': serializer.toJson<String?>(modeloAno),
      'placa': serializer.toJson<String?>(placa),
      'codigoFipe': serializer.toJson<String?>(codigoFipe),
      'renavam': serializer.toJson<String?>(renavam),
      'ipvaMesVencimento': serializer.toJson<String?>(ipvaMesVencimento),
      'dpvatMesVencimento': serializer.toJson<String?>(dpvatMesVencimento),
    };
  }

  FrotaVeiculo copyWith(
          {Value<int?> id = const Value.absent(),
          Value<int?> idFrotaVeiculoTipo = const Value.absent(),
          Value<int?> idFrotaCombustivelTipo = const Value.absent(),
          Value<String?> marca = const Value.absent(),
          Value<String?> modelo = const Value.absent(),
          Value<String?> modeloAno = const Value.absent(),
          Value<String?> placa = const Value.absent(),
          Value<String?> codigoFipe = const Value.absent(),
          Value<String?> renavam = const Value.absent(),
          Value<String?> ipvaMesVencimento = const Value.absent(),
          Value<String?> dpvatMesVencimento = const Value.absent()}) =>
      FrotaVeiculo(
        id: id.present ? id.value : this.id,
        idFrotaVeiculoTipo: idFrotaVeiculoTipo.present
            ? idFrotaVeiculoTipo.value
            : this.idFrotaVeiculoTipo,
        idFrotaCombustivelTipo: idFrotaCombustivelTipo.present
            ? idFrotaCombustivelTipo.value
            : this.idFrotaCombustivelTipo,
        marca: marca.present ? marca.value : this.marca,
        modelo: modelo.present ? modelo.value : this.modelo,
        modeloAno: modeloAno.present ? modeloAno.value : this.modeloAno,
        placa: placa.present ? placa.value : this.placa,
        codigoFipe: codigoFipe.present ? codigoFipe.value : this.codigoFipe,
        renavam: renavam.present ? renavam.value : this.renavam,
        ipvaMesVencimento: ipvaMesVencimento.present
            ? ipvaMesVencimento.value
            : this.ipvaMesVencimento,
        dpvatMesVencimento: dpvatMesVencimento.present
            ? dpvatMesVencimento.value
            : this.dpvatMesVencimento,
      );
  FrotaVeiculo copyWithCompanion(FrotaVeiculosCompanion data) {
    return FrotaVeiculo(
      id: data.id.present ? data.id.value : this.id,
      idFrotaVeiculoTipo: data.idFrotaVeiculoTipo.present
          ? data.idFrotaVeiculoTipo.value
          : this.idFrotaVeiculoTipo,
      idFrotaCombustivelTipo: data.idFrotaCombustivelTipo.present
          ? data.idFrotaCombustivelTipo.value
          : this.idFrotaCombustivelTipo,
      marca: data.marca.present ? data.marca.value : this.marca,
      modelo: data.modelo.present ? data.modelo.value : this.modelo,
      modeloAno: data.modeloAno.present ? data.modeloAno.value : this.modeloAno,
      placa: data.placa.present ? data.placa.value : this.placa,
      codigoFipe:
          data.codigoFipe.present ? data.codigoFipe.value : this.codigoFipe,
      renavam: data.renavam.present ? data.renavam.value : this.renavam,
      ipvaMesVencimento: data.ipvaMesVencimento.present
          ? data.ipvaMesVencimento.value
          : this.ipvaMesVencimento,
      dpvatMesVencimento: data.dpvatMesVencimento.present
          ? data.dpvatMesVencimento.value
          : this.dpvatMesVencimento,
    );
  }

  @override
  String toString() {
    return (StringBuffer('FrotaVeiculo(')
          ..write('id: $id, ')
          ..write('idFrotaVeiculoTipo: $idFrotaVeiculoTipo, ')
          ..write('idFrotaCombustivelTipo: $idFrotaCombustivelTipo, ')
          ..write('marca: $marca, ')
          ..write('modelo: $modelo, ')
          ..write('modeloAno: $modeloAno, ')
          ..write('placa: $placa, ')
          ..write('codigoFipe: $codigoFipe, ')
          ..write('renavam: $renavam, ')
          ..write('ipvaMesVencimento: $ipvaMesVencimento, ')
          ..write('dpvatMesVencimento: $dpvatMesVencimento')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(
      id,
      idFrotaVeiculoTipo,
      idFrotaCombustivelTipo,
      marca,
      modelo,
      modeloAno,
      placa,
      codigoFipe,
      renavam,
      ipvaMesVencimento,
      dpvatMesVencimento);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is FrotaVeiculo &&
          other.id == this.id &&
          other.idFrotaVeiculoTipo == this.idFrotaVeiculoTipo &&
          other.idFrotaCombustivelTipo == this.idFrotaCombustivelTipo &&
          other.marca == this.marca &&
          other.modelo == this.modelo &&
          other.modeloAno == this.modeloAno &&
          other.placa == this.placa &&
          other.codigoFipe == this.codigoFipe &&
          other.renavam == this.renavam &&
          other.ipvaMesVencimento == this.ipvaMesVencimento &&
          other.dpvatMesVencimento == this.dpvatMesVencimento);
}

class FrotaVeiculosCompanion extends UpdateCompanion<FrotaVeiculo> {
  final Value<int?> id;
  final Value<int?> idFrotaVeiculoTipo;
  final Value<int?> idFrotaCombustivelTipo;
  final Value<String?> marca;
  final Value<String?> modelo;
  final Value<String?> modeloAno;
  final Value<String?> placa;
  final Value<String?> codigoFipe;
  final Value<String?> renavam;
  final Value<String?> ipvaMesVencimento;
  final Value<String?> dpvatMesVencimento;
  const FrotaVeiculosCompanion({
    this.id = const Value.absent(),
    this.idFrotaVeiculoTipo = const Value.absent(),
    this.idFrotaCombustivelTipo = const Value.absent(),
    this.marca = const Value.absent(),
    this.modelo = const Value.absent(),
    this.modeloAno = const Value.absent(),
    this.placa = const Value.absent(),
    this.codigoFipe = const Value.absent(),
    this.renavam = const Value.absent(),
    this.ipvaMesVencimento = const Value.absent(),
    this.dpvatMesVencimento = const Value.absent(),
  });
  FrotaVeiculosCompanion.insert({
    this.id = const Value.absent(),
    this.idFrotaVeiculoTipo = const Value.absent(),
    this.idFrotaCombustivelTipo = const Value.absent(),
    this.marca = const Value.absent(),
    this.modelo = const Value.absent(),
    this.modeloAno = const Value.absent(),
    this.placa = const Value.absent(),
    this.codigoFipe = const Value.absent(),
    this.renavam = const Value.absent(),
    this.ipvaMesVencimento = const Value.absent(),
    this.dpvatMesVencimento = const Value.absent(),
  });
  static Insertable<FrotaVeiculo> custom({
    Expression<int>? id,
    Expression<int>? idFrotaVeiculoTipo,
    Expression<int>? idFrotaCombustivelTipo,
    Expression<String>? marca,
    Expression<String>? modelo,
    Expression<String>? modeloAno,
    Expression<String>? placa,
    Expression<String>? codigoFipe,
    Expression<String>? renavam,
    Expression<String>? ipvaMesVencimento,
    Expression<String>? dpvatMesVencimento,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (idFrotaVeiculoTipo != null)
        'id_frota_veiculo_tipo': idFrotaVeiculoTipo,
      if (idFrotaCombustivelTipo != null)
        'id_frota_combustivel_tipo': idFrotaCombustivelTipo,
      if (marca != null) 'marca': marca,
      if (modelo != null) 'modelo': modelo,
      if (modeloAno != null) 'modelo_ano': modeloAno,
      if (placa != null) 'placa': placa,
      if (codigoFipe != null) 'codigo_fipe': codigoFipe,
      if (renavam != null) 'renavam': renavam,
      if (ipvaMesVencimento != null) 'ipva_mes_vencimento': ipvaMesVencimento,
      if (dpvatMesVencimento != null)
        'dpvat_mes_vencimento': dpvatMesVencimento,
    });
  }

  FrotaVeiculosCompanion copyWith(
      {Value<int?>? id,
      Value<int?>? idFrotaVeiculoTipo,
      Value<int?>? idFrotaCombustivelTipo,
      Value<String?>? marca,
      Value<String?>? modelo,
      Value<String?>? modeloAno,
      Value<String?>? placa,
      Value<String?>? codigoFipe,
      Value<String?>? renavam,
      Value<String?>? ipvaMesVencimento,
      Value<String?>? dpvatMesVencimento}) {
    return FrotaVeiculosCompanion(
      id: id ?? this.id,
      idFrotaVeiculoTipo: idFrotaVeiculoTipo ?? this.idFrotaVeiculoTipo,
      idFrotaCombustivelTipo:
          idFrotaCombustivelTipo ?? this.idFrotaCombustivelTipo,
      marca: marca ?? this.marca,
      modelo: modelo ?? this.modelo,
      modeloAno: modeloAno ?? this.modeloAno,
      placa: placa ?? this.placa,
      codigoFipe: codigoFipe ?? this.codigoFipe,
      renavam: renavam ?? this.renavam,
      ipvaMesVencimento: ipvaMesVencimento ?? this.ipvaMesVencimento,
      dpvatMesVencimento: dpvatMesVencimento ?? this.dpvatMesVencimento,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (idFrotaVeiculoTipo.present) {
      map['id_frota_veiculo_tipo'] = Variable<int>(idFrotaVeiculoTipo.value);
    }
    if (idFrotaCombustivelTipo.present) {
      map['id_frota_combustivel_tipo'] =
          Variable<int>(idFrotaCombustivelTipo.value);
    }
    if (marca.present) {
      map['marca'] = Variable<String>(marca.value);
    }
    if (modelo.present) {
      map['modelo'] = Variable<String>(modelo.value);
    }
    if (modeloAno.present) {
      map['modelo_ano'] = Variable<String>(modeloAno.value);
    }
    if (placa.present) {
      map['placa'] = Variable<String>(placa.value);
    }
    if (codigoFipe.present) {
      map['codigo_fipe'] = Variable<String>(codigoFipe.value);
    }
    if (renavam.present) {
      map['renavam'] = Variable<String>(renavam.value);
    }
    if (ipvaMesVencimento.present) {
      map['ipva_mes_vencimento'] = Variable<String>(ipvaMesVencimento.value);
    }
    if (dpvatMesVencimento.present) {
      map['dpvat_mes_vencimento'] = Variable<String>(dpvatMesVencimento.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('FrotaVeiculosCompanion(')
          ..write('id: $id, ')
          ..write('idFrotaVeiculoTipo: $idFrotaVeiculoTipo, ')
          ..write('idFrotaCombustivelTipo: $idFrotaCombustivelTipo, ')
          ..write('marca: $marca, ')
          ..write('modelo: $modelo, ')
          ..write('modeloAno: $modeloAno, ')
          ..write('placa: $placa, ')
          ..write('codigoFipe: $codigoFipe, ')
          ..write('renavam: $renavam, ')
          ..write('ipvaMesVencimento: $ipvaMesVencimento, ')
          ..write('dpvatMesVencimento: $dpvatMesVencimento')
          ..write(')'))
        .toString();
  }
}

class $FrotaVeiculoTiposTable extends FrotaVeiculoTipos
    with TableInfo<$FrotaVeiculoTiposTable, FrotaVeiculoTipo> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $FrotaVeiculoTiposTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
      'id', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _codigoMeta = const VerificationMeta('codigo');
  @override
  late final GeneratedColumn<String> codigo = GeneratedColumn<String>(
      'codigo', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 2),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _nomeMeta = const VerificationMeta('nome');
  @override
  late final GeneratedColumn<String> nome = GeneratedColumn<String>(
      'nome', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 100),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  @override
  List<GeneratedColumn> get $columns => [id, codigo, nome];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'frota_veiculo_tipo';
  @override
  VerificationContext validateIntegrity(Insertable<FrotaVeiculoTipo> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('codigo')) {
      context.handle(_codigoMeta,
          codigo.isAcceptableOrUnknown(data['codigo']!, _codigoMeta));
    }
    if (data.containsKey('nome')) {
      context.handle(
          _nomeMeta, nome.isAcceptableOrUnknown(data['nome']!, _nomeMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  FrotaVeiculoTipo map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return FrotaVeiculoTipo(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id']),
      codigo: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}codigo']),
      nome: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}nome']),
    );
  }

  @override
  $FrotaVeiculoTiposTable createAlias(String alias) {
    return $FrotaVeiculoTiposTable(attachedDatabase, alias);
  }
}

class FrotaVeiculoTipo extends DataClass
    implements Insertable<FrotaVeiculoTipo> {
  final int? id;
  final String? codigo;
  final String? nome;
  const FrotaVeiculoTipo({this.id, this.codigo, this.nome});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || codigo != null) {
      map['codigo'] = Variable<String>(codigo);
    }
    if (!nullToAbsent || nome != null) {
      map['nome'] = Variable<String>(nome);
    }
    return map;
  }

  factory FrotaVeiculoTipo.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return FrotaVeiculoTipo(
      id: serializer.fromJson<int?>(json['id']),
      codigo: serializer.fromJson<String?>(json['codigo']),
      nome: serializer.fromJson<String?>(json['nome']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'codigo': serializer.toJson<String?>(codigo),
      'nome': serializer.toJson<String?>(nome),
    };
  }

  FrotaVeiculoTipo copyWith(
          {Value<int?> id = const Value.absent(),
          Value<String?> codigo = const Value.absent(),
          Value<String?> nome = const Value.absent()}) =>
      FrotaVeiculoTipo(
        id: id.present ? id.value : this.id,
        codigo: codigo.present ? codigo.value : this.codigo,
        nome: nome.present ? nome.value : this.nome,
      );
  FrotaVeiculoTipo copyWithCompanion(FrotaVeiculoTiposCompanion data) {
    return FrotaVeiculoTipo(
      id: data.id.present ? data.id.value : this.id,
      codigo: data.codigo.present ? data.codigo.value : this.codigo,
      nome: data.nome.present ? data.nome.value : this.nome,
    );
  }

  @override
  String toString() {
    return (StringBuffer('FrotaVeiculoTipo(')
          ..write('id: $id, ')
          ..write('codigo: $codigo, ')
          ..write('nome: $nome')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(id, codigo, nome);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is FrotaVeiculoTipo &&
          other.id == this.id &&
          other.codigo == this.codigo &&
          other.nome == this.nome);
}

class FrotaVeiculoTiposCompanion extends UpdateCompanion<FrotaVeiculoTipo> {
  final Value<int?> id;
  final Value<String?> codigo;
  final Value<String?> nome;
  const FrotaVeiculoTiposCompanion({
    this.id = const Value.absent(),
    this.codigo = const Value.absent(),
    this.nome = const Value.absent(),
  });
  FrotaVeiculoTiposCompanion.insert({
    this.id = const Value.absent(),
    this.codigo = const Value.absent(),
    this.nome = const Value.absent(),
  });
  static Insertable<FrotaVeiculoTipo> custom({
    Expression<int>? id,
    Expression<String>? codigo,
    Expression<String>? nome,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (codigo != null) 'codigo': codigo,
      if (nome != null) 'nome': nome,
    });
  }

  FrotaVeiculoTiposCompanion copyWith(
      {Value<int?>? id, Value<String?>? codigo, Value<String?>? nome}) {
    return FrotaVeiculoTiposCompanion(
      id: id ?? this.id,
      codigo: codigo ?? this.codigo,
      nome: nome ?? this.nome,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (codigo.present) {
      map['codigo'] = Variable<String>(codigo.value);
    }
    if (nome.present) {
      map['nome'] = Variable<String>(nome.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('FrotaVeiculoTiposCompanion(')
          ..write('id: $id, ')
          ..write('codigo: $codigo, ')
          ..write('nome: $nome')
          ..write(')'))
        .toString();
  }
}

class $FrotaCombustivelTiposTable extends FrotaCombustivelTipos
    with TableInfo<$FrotaCombustivelTiposTable, FrotaCombustivelTipo> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $FrotaCombustivelTiposTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
      'id', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _codigoMeta = const VerificationMeta('codigo');
  @override
  late final GeneratedColumn<String> codigo = GeneratedColumn<String>(
      'codigo', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 2),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _nomeMeta = const VerificationMeta('nome');
  @override
  late final GeneratedColumn<String> nome = GeneratedColumn<String>(
      'nome', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 100),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  @override
  List<GeneratedColumn> get $columns => [id, codigo, nome];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'frota_combustivel_tipo';
  @override
  VerificationContext validateIntegrity(
      Insertable<FrotaCombustivelTipo> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('codigo')) {
      context.handle(_codigoMeta,
          codigo.isAcceptableOrUnknown(data['codigo']!, _codigoMeta));
    }
    if (data.containsKey('nome')) {
      context.handle(
          _nomeMeta, nome.isAcceptableOrUnknown(data['nome']!, _nomeMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  FrotaCombustivelTipo map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return FrotaCombustivelTipo(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id']),
      codigo: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}codigo']),
      nome: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}nome']),
    );
  }

  @override
  $FrotaCombustivelTiposTable createAlias(String alias) {
    return $FrotaCombustivelTiposTable(attachedDatabase, alias);
  }
}

class FrotaCombustivelTipo extends DataClass
    implements Insertable<FrotaCombustivelTipo> {
  final int? id;
  final String? codigo;
  final String? nome;
  const FrotaCombustivelTipo({this.id, this.codigo, this.nome});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || codigo != null) {
      map['codigo'] = Variable<String>(codigo);
    }
    if (!nullToAbsent || nome != null) {
      map['nome'] = Variable<String>(nome);
    }
    return map;
  }

  factory FrotaCombustivelTipo.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return FrotaCombustivelTipo(
      id: serializer.fromJson<int?>(json['id']),
      codigo: serializer.fromJson<String?>(json['codigo']),
      nome: serializer.fromJson<String?>(json['nome']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'codigo': serializer.toJson<String?>(codigo),
      'nome': serializer.toJson<String?>(nome),
    };
  }

  FrotaCombustivelTipo copyWith(
          {Value<int?> id = const Value.absent(),
          Value<String?> codigo = const Value.absent(),
          Value<String?> nome = const Value.absent()}) =>
      FrotaCombustivelTipo(
        id: id.present ? id.value : this.id,
        codigo: codigo.present ? codigo.value : this.codigo,
        nome: nome.present ? nome.value : this.nome,
      );
  FrotaCombustivelTipo copyWithCompanion(FrotaCombustivelTiposCompanion data) {
    return FrotaCombustivelTipo(
      id: data.id.present ? data.id.value : this.id,
      codigo: data.codigo.present ? data.codigo.value : this.codigo,
      nome: data.nome.present ? data.nome.value : this.nome,
    );
  }

  @override
  String toString() {
    return (StringBuffer('FrotaCombustivelTipo(')
          ..write('id: $id, ')
          ..write('codigo: $codigo, ')
          ..write('nome: $nome')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(id, codigo, nome);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is FrotaCombustivelTipo &&
          other.id == this.id &&
          other.codigo == this.codigo &&
          other.nome == this.nome);
}

class FrotaCombustivelTiposCompanion
    extends UpdateCompanion<FrotaCombustivelTipo> {
  final Value<int?> id;
  final Value<String?> codigo;
  final Value<String?> nome;
  const FrotaCombustivelTiposCompanion({
    this.id = const Value.absent(),
    this.codigo = const Value.absent(),
    this.nome = const Value.absent(),
  });
  FrotaCombustivelTiposCompanion.insert({
    this.id = const Value.absent(),
    this.codigo = const Value.absent(),
    this.nome = const Value.absent(),
  });
  static Insertable<FrotaCombustivelTipo> custom({
    Expression<int>? id,
    Expression<String>? codigo,
    Expression<String>? nome,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (codigo != null) 'codigo': codigo,
      if (nome != null) 'nome': nome,
    });
  }

  FrotaCombustivelTiposCompanion copyWith(
      {Value<int?>? id, Value<String?>? codigo, Value<String?>? nome}) {
    return FrotaCombustivelTiposCompanion(
      id: id ?? this.id,
      codigo: codigo ?? this.codigo,
      nome: nome ?? this.nome,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (codigo.present) {
      map['codigo'] = Variable<String>(codigo.value);
    }
    if (nome.present) {
      map['nome'] = Variable<String>(nome.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('FrotaCombustivelTiposCompanion(')
          ..write('id: $id, ')
          ..write('codigo: $codigo, ')
          ..write('nome: $nome')
          ..write(')'))
        .toString();
  }
}

class $FrotaMotoristasTable extends FrotaMotoristas
    with TableInfo<$FrotaMotoristasTable, FrotaMotorista> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $FrotaMotoristasTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
      'id', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _idColaboradorMeta =
      const VerificationMeta('idColaborador');
  @override
  late final GeneratedColumn<int> idColaborador = GeneratedColumn<int>(
      'id_colaborador', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _nomeMeta = const VerificationMeta('nome');
  @override
  late final GeneratedColumn<String> nome = GeneratedColumn<String>(
      'nome', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 100),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _numeroCnhMeta =
      const VerificationMeta('numeroCnh');
  @override
  late final GeneratedColumn<String> numeroCnh = GeneratedColumn<String>(
      'numero_cnh', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 11),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _cnhCategoriaMeta =
      const VerificationMeta('cnhCategoria');
  @override
  late final GeneratedColumn<String> cnhCategoria = GeneratedColumn<String>(
      'cnh_categoria', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 1),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  @override
  List<GeneratedColumn> get $columns =>
      [id, idColaborador, nome, numeroCnh, cnhCategoria];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'frota_motorista';
  @override
  VerificationContext validateIntegrity(Insertable<FrotaMotorista> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('id_colaborador')) {
      context.handle(
          _idColaboradorMeta,
          idColaborador.isAcceptableOrUnknown(
              data['id_colaborador']!, _idColaboradorMeta));
    }
    if (data.containsKey('nome')) {
      context.handle(
          _nomeMeta, nome.isAcceptableOrUnknown(data['nome']!, _nomeMeta));
    }
    if (data.containsKey('numero_cnh')) {
      context.handle(_numeroCnhMeta,
          numeroCnh.isAcceptableOrUnknown(data['numero_cnh']!, _numeroCnhMeta));
    }
    if (data.containsKey('cnh_categoria')) {
      context.handle(
          _cnhCategoriaMeta,
          cnhCategoria.isAcceptableOrUnknown(
              data['cnh_categoria']!, _cnhCategoriaMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  FrotaMotorista map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return FrotaMotorista(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id']),
      idColaborador: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id_colaborador']),
      nome: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}nome']),
      numeroCnh: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}numero_cnh']),
      cnhCategoria: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}cnh_categoria']),
    );
  }

  @override
  $FrotaMotoristasTable createAlias(String alias) {
    return $FrotaMotoristasTable(attachedDatabase, alias);
  }
}

class FrotaMotorista extends DataClass implements Insertable<FrotaMotorista> {
  final int? id;
  final int? idColaborador;
  final String? nome;
  final String? numeroCnh;
  final String? cnhCategoria;
  const FrotaMotorista(
      {this.id,
      this.idColaborador,
      this.nome,
      this.numeroCnh,
      this.cnhCategoria});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || idColaborador != null) {
      map['id_colaborador'] = Variable<int>(idColaborador);
    }
    if (!nullToAbsent || nome != null) {
      map['nome'] = Variable<String>(nome);
    }
    if (!nullToAbsent || numeroCnh != null) {
      map['numero_cnh'] = Variable<String>(numeroCnh);
    }
    if (!nullToAbsent || cnhCategoria != null) {
      map['cnh_categoria'] = Variable<String>(cnhCategoria);
    }
    return map;
  }

  factory FrotaMotorista.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return FrotaMotorista(
      id: serializer.fromJson<int?>(json['id']),
      idColaborador: serializer.fromJson<int?>(json['idColaborador']),
      nome: serializer.fromJson<String?>(json['nome']),
      numeroCnh: serializer.fromJson<String?>(json['numeroCnh']),
      cnhCategoria: serializer.fromJson<String?>(json['cnhCategoria']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'idColaborador': serializer.toJson<int?>(idColaborador),
      'nome': serializer.toJson<String?>(nome),
      'numeroCnh': serializer.toJson<String?>(numeroCnh),
      'cnhCategoria': serializer.toJson<String?>(cnhCategoria),
    };
  }

  FrotaMotorista copyWith(
          {Value<int?> id = const Value.absent(),
          Value<int?> idColaborador = const Value.absent(),
          Value<String?> nome = const Value.absent(),
          Value<String?> numeroCnh = const Value.absent(),
          Value<String?> cnhCategoria = const Value.absent()}) =>
      FrotaMotorista(
        id: id.present ? id.value : this.id,
        idColaborador:
            idColaborador.present ? idColaborador.value : this.idColaborador,
        nome: nome.present ? nome.value : this.nome,
        numeroCnh: numeroCnh.present ? numeroCnh.value : this.numeroCnh,
        cnhCategoria:
            cnhCategoria.present ? cnhCategoria.value : this.cnhCategoria,
      );
  FrotaMotorista copyWithCompanion(FrotaMotoristasCompanion data) {
    return FrotaMotorista(
      id: data.id.present ? data.id.value : this.id,
      idColaborador: data.idColaborador.present
          ? data.idColaborador.value
          : this.idColaborador,
      nome: data.nome.present ? data.nome.value : this.nome,
      numeroCnh: data.numeroCnh.present ? data.numeroCnh.value : this.numeroCnh,
      cnhCategoria: data.cnhCategoria.present
          ? data.cnhCategoria.value
          : this.cnhCategoria,
    );
  }

  @override
  String toString() {
    return (StringBuffer('FrotaMotorista(')
          ..write('id: $id, ')
          ..write('idColaborador: $idColaborador, ')
          ..write('nome: $nome, ')
          ..write('numeroCnh: $numeroCnh, ')
          ..write('cnhCategoria: $cnhCategoria')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode =>
      Object.hash(id, idColaborador, nome, numeroCnh, cnhCategoria);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is FrotaMotorista &&
          other.id == this.id &&
          other.idColaborador == this.idColaborador &&
          other.nome == this.nome &&
          other.numeroCnh == this.numeroCnh &&
          other.cnhCategoria == this.cnhCategoria);
}

class FrotaMotoristasCompanion extends UpdateCompanion<FrotaMotorista> {
  final Value<int?> id;
  final Value<int?> idColaborador;
  final Value<String?> nome;
  final Value<String?> numeroCnh;
  final Value<String?> cnhCategoria;
  const FrotaMotoristasCompanion({
    this.id = const Value.absent(),
    this.idColaborador = const Value.absent(),
    this.nome = const Value.absent(),
    this.numeroCnh = const Value.absent(),
    this.cnhCategoria = const Value.absent(),
  });
  FrotaMotoristasCompanion.insert({
    this.id = const Value.absent(),
    this.idColaborador = const Value.absent(),
    this.nome = const Value.absent(),
    this.numeroCnh = const Value.absent(),
    this.cnhCategoria = const Value.absent(),
  });
  static Insertable<FrotaMotorista> custom({
    Expression<int>? id,
    Expression<int>? idColaborador,
    Expression<String>? nome,
    Expression<String>? numeroCnh,
    Expression<String>? cnhCategoria,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (idColaborador != null) 'id_colaborador': idColaborador,
      if (nome != null) 'nome': nome,
      if (numeroCnh != null) 'numero_cnh': numeroCnh,
      if (cnhCategoria != null) 'cnh_categoria': cnhCategoria,
    });
  }

  FrotaMotoristasCompanion copyWith(
      {Value<int?>? id,
      Value<int?>? idColaborador,
      Value<String?>? nome,
      Value<String?>? numeroCnh,
      Value<String?>? cnhCategoria}) {
    return FrotaMotoristasCompanion(
      id: id ?? this.id,
      idColaborador: idColaborador ?? this.idColaborador,
      nome: nome ?? this.nome,
      numeroCnh: numeroCnh ?? this.numeroCnh,
      cnhCategoria: cnhCategoria ?? this.cnhCategoria,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (idColaborador.present) {
      map['id_colaborador'] = Variable<int>(idColaborador.value);
    }
    if (nome.present) {
      map['nome'] = Variable<String>(nome.value);
    }
    if (numeroCnh.present) {
      map['numero_cnh'] = Variable<String>(numeroCnh.value);
    }
    if (cnhCategoria.present) {
      map['cnh_categoria'] = Variable<String>(cnhCategoria.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('FrotaMotoristasCompanion(')
          ..write('id: $id, ')
          ..write('idColaborador: $idColaborador, ')
          ..write('nome: $nome, ')
          ..write('numeroCnh: $numeroCnh, ')
          ..write('cnhCategoria: $cnhCategoria')
          ..write(')'))
        .toString();
  }
}

class $ViewControleAcessosTable extends ViewControleAcessos
    with TableInfo<$ViewControleAcessosTable, ViewControleAcesso> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $ViewControleAcessosTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
      'id', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _idPessoaMeta =
      const VerificationMeta('idPessoa');
  @override
  late final GeneratedColumn<int> idPessoa = GeneratedColumn<int>(
      'id_pessoa', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _pessoaNomeMeta =
      const VerificationMeta('pessoaNome');
  @override
  late final GeneratedColumn<String> pessoaNome = GeneratedColumn<String>(
      'pessoa_nome', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 450),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _idColaboradorMeta =
      const VerificationMeta('idColaborador');
  @override
  late final GeneratedColumn<int> idColaborador = GeneratedColumn<int>(
      'id_colaborador', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _idUsuarioMeta =
      const VerificationMeta('idUsuario');
  @override
  late final GeneratedColumn<int> idUsuario = GeneratedColumn<int>(
      'id_usuario', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _administradorMeta =
      const VerificationMeta('administrador');
  @override
  late final GeneratedColumn<String> administrador = GeneratedColumn<String>(
      'administrador', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 3),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _idPapelMeta =
      const VerificationMeta('idPapel');
  @override
  late final GeneratedColumn<int> idPapel = GeneratedColumn<int>(
      'id_papel', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _papelNomeMeta =
      const VerificationMeta('papelNome');
  @override
  late final GeneratedColumn<String> papelNome = GeneratedColumn<String>(
      'papel_nome', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 300),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _papelDescricaoMeta =
      const VerificationMeta('papelDescricao');
  @override
  late final GeneratedColumn<String> papelDescricao = GeneratedColumn<String>(
      'papel_descricao', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 750),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _idFuncaoMeta =
      const VerificationMeta('idFuncao');
  @override
  late final GeneratedColumn<int> idFuncao = GeneratedColumn<int>(
      'id_funcao', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _funcaoNomeMeta =
      const VerificationMeta('funcaoNome');
  @override
  late final GeneratedColumn<String> funcaoNome = GeneratedColumn<String>(
      'funcao_nome', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 300),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _funcaoDescricaoMeta =
      const VerificationMeta('funcaoDescricao');
  @override
  late final GeneratedColumn<String> funcaoDescricao = GeneratedColumn<String>(
      'funcao_descricao', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 750),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _idPapelFuncaoMeta =
      const VerificationMeta('idPapelFuncao');
  @override
  late final GeneratedColumn<int> idPapelFuncao = GeneratedColumn<int>(
      'id_papel_funcao', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _habilitadoMeta =
      const VerificationMeta('habilitado');
  @override
  late final GeneratedColumn<String> habilitado = GeneratedColumn<String>(
      'habilitado', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 3),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _podeInserirMeta =
      const VerificationMeta('podeInserir');
  @override
  late final GeneratedColumn<String> podeInserir = GeneratedColumn<String>(
      'pode_inserir', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 3),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _podeAlterarMeta =
      const VerificationMeta('podeAlterar');
  @override
  late final GeneratedColumn<String> podeAlterar = GeneratedColumn<String>(
      'pode_alterar', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 3),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _podeExcluirMeta =
      const VerificationMeta('podeExcluir');
  @override
  late final GeneratedColumn<String> podeExcluir = GeneratedColumn<String>(
      'pode_excluir', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 3),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  @override
  List<GeneratedColumn> get $columns => [
        id,
        idPessoa,
        pessoaNome,
        idColaborador,
        idUsuario,
        administrador,
        idPapel,
        papelNome,
        papelDescricao,
        idFuncao,
        funcaoNome,
        funcaoDescricao,
        idPapelFuncao,
        habilitado,
        podeInserir,
        podeAlterar,
        podeExcluir
      ];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'view_controle_acesso';
  @override
  VerificationContext validateIntegrity(Insertable<ViewControleAcesso> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('id_pessoa')) {
      context.handle(_idPessoaMeta,
          idPessoa.isAcceptableOrUnknown(data['id_pessoa']!, _idPessoaMeta));
    }
    if (data.containsKey('pessoa_nome')) {
      context.handle(
          _pessoaNomeMeta,
          pessoaNome.isAcceptableOrUnknown(
              data['pessoa_nome']!, _pessoaNomeMeta));
    }
    if (data.containsKey('id_colaborador')) {
      context.handle(
          _idColaboradorMeta,
          idColaborador.isAcceptableOrUnknown(
              data['id_colaborador']!, _idColaboradorMeta));
    }
    if (data.containsKey('id_usuario')) {
      context.handle(_idUsuarioMeta,
          idUsuario.isAcceptableOrUnknown(data['id_usuario']!, _idUsuarioMeta));
    }
    if (data.containsKey('administrador')) {
      context.handle(
          _administradorMeta,
          administrador.isAcceptableOrUnknown(
              data['administrador']!, _administradorMeta));
    }
    if (data.containsKey('id_papel')) {
      context.handle(_idPapelMeta,
          idPapel.isAcceptableOrUnknown(data['id_papel']!, _idPapelMeta));
    }
    if (data.containsKey('papel_nome')) {
      context.handle(_papelNomeMeta,
          papelNome.isAcceptableOrUnknown(data['papel_nome']!, _papelNomeMeta));
    }
    if (data.containsKey('papel_descricao')) {
      context.handle(
          _papelDescricaoMeta,
          papelDescricao.isAcceptableOrUnknown(
              data['papel_descricao']!, _papelDescricaoMeta));
    }
    if (data.containsKey('id_funcao')) {
      context.handle(_idFuncaoMeta,
          idFuncao.isAcceptableOrUnknown(data['id_funcao']!, _idFuncaoMeta));
    }
    if (data.containsKey('funcao_nome')) {
      context.handle(
          _funcaoNomeMeta,
          funcaoNome.isAcceptableOrUnknown(
              data['funcao_nome']!, _funcaoNomeMeta));
    }
    if (data.containsKey('funcao_descricao')) {
      context.handle(
          _funcaoDescricaoMeta,
          funcaoDescricao.isAcceptableOrUnknown(
              data['funcao_descricao']!, _funcaoDescricaoMeta));
    }
    if (data.containsKey('id_papel_funcao')) {
      context.handle(
          _idPapelFuncaoMeta,
          idPapelFuncao.isAcceptableOrUnknown(
              data['id_papel_funcao']!, _idPapelFuncaoMeta));
    }
    if (data.containsKey('habilitado')) {
      context.handle(
          _habilitadoMeta,
          habilitado.isAcceptableOrUnknown(
              data['habilitado']!, _habilitadoMeta));
    }
    if (data.containsKey('pode_inserir')) {
      context.handle(
          _podeInserirMeta,
          podeInserir.isAcceptableOrUnknown(
              data['pode_inserir']!, _podeInserirMeta));
    }
    if (data.containsKey('pode_alterar')) {
      context.handle(
          _podeAlterarMeta,
          podeAlterar.isAcceptableOrUnknown(
              data['pode_alterar']!, _podeAlterarMeta));
    }
    if (data.containsKey('pode_excluir')) {
      context.handle(
          _podeExcluirMeta,
          podeExcluir.isAcceptableOrUnknown(
              data['pode_excluir']!, _podeExcluirMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  ViewControleAcesso map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return ViewControleAcesso(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id']),
      idPessoa: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id_pessoa']),
      pessoaNome: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}pessoa_nome']),
      idColaborador: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id_colaborador']),
      idUsuario: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id_usuario']),
      administrador: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}administrador']),
      idPapel: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id_papel']),
      papelNome: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}papel_nome']),
      papelDescricao: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}papel_descricao']),
      idFuncao: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id_funcao']),
      funcaoNome: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}funcao_nome']),
      funcaoDescricao: attachedDatabase.typeMapping.read(
          DriftSqlType.string, data['${effectivePrefix}funcao_descricao']),
      idPapelFuncao: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id_papel_funcao']),
      habilitado: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}habilitado']),
      podeInserir: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}pode_inserir']),
      podeAlterar: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}pode_alterar']),
      podeExcluir: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}pode_excluir']),
    );
  }

  @override
  $ViewControleAcessosTable createAlias(String alias) {
    return $ViewControleAcessosTable(attachedDatabase, alias);
  }
}

class ViewControleAcesso extends DataClass
    implements Insertable<ViewControleAcesso> {
  final int? id;
  final int? idPessoa;
  final String? pessoaNome;
  final int? idColaborador;
  final int? idUsuario;
  final String? administrador;
  final int? idPapel;
  final String? papelNome;
  final String? papelDescricao;
  final int? idFuncao;
  final String? funcaoNome;
  final String? funcaoDescricao;
  final int? idPapelFuncao;
  final String? habilitado;
  final String? podeInserir;
  final String? podeAlterar;
  final String? podeExcluir;
  const ViewControleAcesso(
      {this.id,
      this.idPessoa,
      this.pessoaNome,
      this.idColaborador,
      this.idUsuario,
      this.administrador,
      this.idPapel,
      this.papelNome,
      this.papelDescricao,
      this.idFuncao,
      this.funcaoNome,
      this.funcaoDescricao,
      this.idPapelFuncao,
      this.habilitado,
      this.podeInserir,
      this.podeAlterar,
      this.podeExcluir});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || idPessoa != null) {
      map['id_pessoa'] = Variable<int>(idPessoa);
    }
    if (!nullToAbsent || pessoaNome != null) {
      map['pessoa_nome'] = Variable<String>(pessoaNome);
    }
    if (!nullToAbsent || idColaborador != null) {
      map['id_colaborador'] = Variable<int>(idColaborador);
    }
    if (!nullToAbsent || idUsuario != null) {
      map['id_usuario'] = Variable<int>(idUsuario);
    }
    if (!nullToAbsent || administrador != null) {
      map['administrador'] = Variable<String>(administrador);
    }
    if (!nullToAbsent || idPapel != null) {
      map['id_papel'] = Variable<int>(idPapel);
    }
    if (!nullToAbsent || papelNome != null) {
      map['papel_nome'] = Variable<String>(papelNome);
    }
    if (!nullToAbsent || papelDescricao != null) {
      map['papel_descricao'] = Variable<String>(papelDescricao);
    }
    if (!nullToAbsent || idFuncao != null) {
      map['id_funcao'] = Variable<int>(idFuncao);
    }
    if (!nullToAbsent || funcaoNome != null) {
      map['funcao_nome'] = Variable<String>(funcaoNome);
    }
    if (!nullToAbsent || funcaoDescricao != null) {
      map['funcao_descricao'] = Variable<String>(funcaoDescricao);
    }
    if (!nullToAbsent || idPapelFuncao != null) {
      map['id_papel_funcao'] = Variable<int>(idPapelFuncao);
    }
    if (!nullToAbsent || habilitado != null) {
      map['habilitado'] = Variable<String>(habilitado);
    }
    if (!nullToAbsent || podeInserir != null) {
      map['pode_inserir'] = Variable<String>(podeInserir);
    }
    if (!nullToAbsent || podeAlterar != null) {
      map['pode_alterar'] = Variable<String>(podeAlterar);
    }
    if (!nullToAbsent || podeExcluir != null) {
      map['pode_excluir'] = Variable<String>(podeExcluir);
    }
    return map;
  }

  factory ViewControleAcesso.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return ViewControleAcesso(
      id: serializer.fromJson<int?>(json['id']),
      idPessoa: serializer.fromJson<int?>(json['idPessoa']),
      pessoaNome: serializer.fromJson<String?>(json['pessoaNome']),
      idColaborador: serializer.fromJson<int?>(json['idColaborador']),
      idUsuario: serializer.fromJson<int?>(json['idUsuario']),
      administrador: serializer.fromJson<String?>(json['administrador']),
      idPapel: serializer.fromJson<int?>(json['idPapel']),
      papelNome: serializer.fromJson<String?>(json['papelNome']),
      papelDescricao: serializer.fromJson<String?>(json['papelDescricao']),
      idFuncao: serializer.fromJson<int?>(json['idFuncao']),
      funcaoNome: serializer.fromJson<String?>(json['funcaoNome']),
      funcaoDescricao: serializer.fromJson<String?>(json['funcaoDescricao']),
      idPapelFuncao: serializer.fromJson<int?>(json['idPapelFuncao']),
      habilitado: serializer.fromJson<String?>(json['habilitado']),
      podeInserir: serializer.fromJson<String?>(json['podeInserir']),
      podeAlterar: serializer.fromJson<String?>(json['podeAlterar']),
      podeExcluir: serializer.fromJson<String?>(json['podeExcluir']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'idPessoa': serializer.toJson<int?>(idPessoa),
      'pessoaNome': serializer.toJson<String?>(pessoaNome),
      'idColaborador': serializer.toJson<int?>(idColaborador),
      'idUsuario': serializer.toJson<int?>(idUsuario),
      'administrador': serializer.toJson<String?>(administrador),
      'idPapel': serializer.toJson<int?>(idPapel),
      'papelNome': serializer.toJson<String?>(papelNome),
      'papelDescricao': serializer.toJson<String?>(papelDescricao),
      'idFuncao': serializer.toJson<int?>(idFuncao),
      'funcaoNome': serializer.toJson<String?>(funcaoNome),
      'funcaoDescricao': serializer.toJson<String?>(funcaoDescricao),
      'idPapelFuncao': serializer.toJson<int?>(idPapelFuncao),
      'habilitado': serializer.toJson<String?>(habilitado),
      'podeInserir': serializer.toJson<String?>(podeInserir),
      'podeAlterar': serializer.toJson<String?>(podeAlterar),
      'podeExcluir': serializer.toJson<String?>(podeExcluir),
    };
  }

  ViewControleAcesso copyWith(
          {Value<int?> id = const Value.absent(),
          Value<int?> idPessoa = const Value.absent(),
          Value<String?> pessoaNome = const Value.absent(),
          Value<int?> idColaborador = const Value.absent(),
          Value<int?> idUsuario = const Value.absent(),
          Value<String?> administrador = const Value.absent(),
          Value<int?> idPapel = const Value.absent(),
          Value<String?> papelNome = const Value.absent(),
          Value<String?> papelDescricao = const Value.absent(),
          Value<int?> idFuncao = const Value.absent(),
          Value<String?> funcaoNome = const Value.absent(),
          Value<String?> funcaoDescricao = const Value.absent(),
          Value<int?> idPapelFuncao = const Value.absent(),
          Value<String?> habilitado = const Value.absent(),
          Value<String?> podeInserir = const Value.absent(),
          Value<String?> podeAlterar = const Value.absent(),
          Value<String?> podeExcluir = const Value.absent()}) =>
      ViewControleAcesso(
        id: id.present ? id.value : this.id,
        idPessoa: idPessoa.present ? idPessoa.value : this.idPessoa,
        pessoaNome: pessoaNome.present ? pessoaNome.value : this.pessoaNome,
        idColaborador:
            idColaborador.present ? idColaborador.value : this.idColaborador,
        idUsuario: idUsuario.present ? idUsuario.value : this.idUsuario,
        administrador:
            administrador.present ? administrador.value : this.administrador,
        idPapel: idPapel.present ? idPapel.value : this.idPapel,
        papelNome: papelNome.present ? papelNome.value : this.papelNome,
        papelDescricao:
            papelDescricao.present ? papelDescricao.value : this.papelDescricao,
        idFuncao: idFuncao.present ? idFuncao.value : this.idFuncao,
        funcaoNome: funcaoNome.present ? funcaoNome.value : this.funcaoNome,
        funcaoDescricao: funcaoDescricao.present
            ? funcaoDescricao.value
            : this.funcaoDescricao,
        idPapelFuncao:
            idPapelFuncao.present ? idPapelFuncao.value : this.idPapelFuncao,
        habilitado: habilitado.present ? habilitado.value : this.habilitado,
        podeInserir: podeInserir.present ? podeInserir.value : this.podeInserir,
        podeAlterar: podeAlterar.present ? podeAlterar.value : this.podeAlterar,
        podeExcluir: podeExcluir.present ? podeExcluir.value : this.podeExcluir,
      );
  ViewControleAcesso copyWithCompanion(ViewControleAcessosCompanion data) {
    return ViewControleAcesso(
      id: data.id.present ? data.id.value : this.id,
      idPessoa: data.idPessoa.present ? data.idPessoa.value : this.idPessoa,
      pessoaNome:
          data.pessoaNome.present ? data.pessoaNome.value : this.pessoaNome,
      idColaborador: data.idColaborador.present
          ? data.idColaborador.value
          : this.idColaborador,
      idUsuario: data.idUsuario.present ? data.idUsuario.value : this.idUsuario,
      administrador: data.administrador.present
          ? data.administrador.value
          : this.administrador,
      idPapel: data.idPapel.present ? data.idPapel.value : this.idPapel,
      papelNome: data.papelNome.present ? data.papelNome.value : this.papelNome,
      papelDescricao: data.papelDescricao.present
          ? data.papelDescricao.value
          : this.papelDescricao,
      idFuncao: data.idFuncao.present ? data.idFuncao.value : this.idFuncao,
      funcaoNome:
          data.funcaoNome.present ? data.funcaoNome.value : this.funcaoNome,
      funcaoDescricao: data.funcaoDescricao.present
          ? data.funcaoDescricao.value
          : this.funcaoDescricao,
      idPapelFuncao: data.idPapelFuncao.present
          ? data.idPapelFuncao.value
          : this.idPapelFuncao,
      habilitado:
          data.habilitado.present ? data.habilitado.value : this.habilitado,
      podeInserir:
          data.podeInserir.present ? data.podeInserir.value : this.podeInserir,
      podeAlterar:
          data.podeAlterar.present ? data.podeAlterar.value : this.podeAlterar,
      podeExcluir:
          data.podeExcluir.present ? data.podeExcluir.value : this.podeExcluir,
    );
  }

  @override
  String toString() {
    return (StringBuffer('ViewControleAcesso(')
          ..write('id: $id, ')
          ..write('idPessoa: $idPessoa, ')
          ..write('pessoaNome: $pessoaNome, ')
          ..write('idColaborador: $idColaborador, ')
          ..write('idUsuario: $idUsuario, ')
          ..write('administrador: $administrador, ')
          ..write('idPapel: $idPapel, ')
          ..write('papelNome: $papelNome, ')
          ..write('papelDescricao: $papelDescricao, ')
          ..write('idFuncao: $idFuncao, ')
          ..write('funcaoNome: $funcaoNome, ')
          ..write('funcaoDescricao: $funcaoDescricao, ')
          ..write('idPapelFuncao: $idPapelFuncao, ')
          ..write('habilitado: $habilitado, ')
          ..write('podeInserir: $podeInserir, ')
          ..write('podeAlterar: $podeAlterar, ')
          ..write('podeExcluir: $podeExcluir')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(
      id,
      idPessoa,
      pessoaNome,
      idColaborador,
      idUsuario,
      administrador,
      idPapel,
      papelNome,
      papelDescricao,
      idFuncao,
      funcaoNome,
      funcaoDescricao,
      idPapelFuncao,
      habilitado,
      podeInserir,
      podeAlterar,
      podeExcluir);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is ViewControleAcesso &&
          other.id == this.id &&
          other.idPessoa == this.idPessoa &&
          other.pessoaNome == this.pessoaNome &&
          other.idColaborador == this.idColaborador &&
          other.idUsuario == this.idUsuario &&
          other.administrador == this.administrador &&
          other.idPapel == this.idPapel &&
          other.papelNome == this.papelNome &&
          other.papelDescricao == this.papelDescricao &&
          other.idFuncao == this.idFuncao &&
          other.funcaoNome == this.funcaoNome &&
          other.funcaoDescricao == this.funcaoDescricao &&
          other.idPapelFuncao == this.idPapelFuncao &&
          other.habilitado == this.habilitado &&
          other.podeInserir == this.podeInserir &&
          other.podeAlterar == this.podeAlterar &&
          other.podeExcluir == this.podeExcluir);
}

class ViewControleAcessosCompanion extends UpdateCompanion<ViewControleAcesso> {
  final Value<int?> id;
  final Value<int?> idPessoa;
  final Value<String?> pessoaNome;
  final Value<int?> idColaborador;
  final Value<int?> idUsuario;
  final Value<String?> administrador;
  final Value<int?> idPapel;
  final Value<String?> papelNome;
  final Value<String?> papelDescricao;
  final Value<int?> idFuncao;
  final Value<String?> funcaoNome;
  final Value<String?> funcaoDescricao;
  final Value<int?> idPapelFuncao;
  final Value<String?> habilitado;
  final Value<String?> podeInserir;
  final Value<String?> podeAlterar;
  final Value<String?> podeExcluir;
  const ViewControleAcessosCompanion({
    this.id = const Value.absent(),
    this.idPessoa = const Value.absent(),
    this.pessoaNome = const Value.absent(),
    this.idColaborador = const Value.absent(),
    this.idUsuario = const Value.absent(),
    this.administrador = const Value.absent(),
    this.idPapel = const Value.absent(),
    this.papelNome = const Value.absent(),
    this.papelDescricao = const Value.absent(),
    this.idFuncao = const Value.absent(),
    this.funcaoNome = const Value.absent(),
    this.funcaoDescricao = const Value.absent(),
    this.idPapelFuncao = const Value.absent(),
    this.habilitado = const Value.absent(),
    this.podeInserir = const Value.absent(),
    this.podeAlterar = const Value.absent(),
    this.podeExcluir = const Value.absent(),
  });
  ViewControleAcessosCompanion.insert({
    this.id = const Value.absent(),
    this.idPessoa = const Value.absent(),
    this.pessoaNome = const Value.absent(),
    this.idColaborador = const Value.absent(),
    this.idUsuario = const Value.absent(),
    this.administrador = const Value.absent(),
    this.idPapel = const Value.absent(),
    this.papelNome = const Value.absent(),
    this.papelDescricao = const Value.absent(),
    this.idFuncao = const Value.absent(),
    this.funcaoNome = const Value.absent(),
    this.funcaoDescricao = const Value.absent(),
    this.idPapelFuncao = const Value.absent(),
    this.habilitado = const Value.absent(),
    this.podeInserir = const Value.absent(),
    this.podeAlterar = const Value.absent(),
    this.podeExcluir = const Value.absent(),
  });
  static Insertable<ViewControleAcesso> custom({
    Expression<int>? id,
    Expression<int>? idPessoa,
    Expression<String>? pessoaNome,
    Expression<int>? idColaborador,
    Expression<int>? idUsuario,
    Expression<String>? administrador,
    Expression<int>? idPapel,
    Expression<String>? papelNome,
    Expression<String>? papelDescricao,
    Expression<int>? idFuncao,
    Expression<String>? funcaoNome,
    Expression<String>? funcaoDescricao,
    Expression<int>? idPapelFuncao,
    Expression<String>? habilitado,
    Expression<String>? podeInserir,
    Expression<String>? podeAlterar,
    Expression<String>? podeExcluir,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (idPessoa != null) 'id_pessoa': idPessoa,
      if (pessoaNome != null) 'pessoa_nome': pessoaNome,
      if (idColaborador != null) 'id_colaborador': idColaborador,
      if (idUsuario != null) 'id_usuario': idUsuario,
      if (administrador != null) 'administrador': administrador,
      if (idPapel != null) 'id_papel': idPapel,
      if (papelNome != null) 'papel_nome': papelNome,
      if (papelDescricao != null) 'papel_descricao': papelDescricao,
      if (idFuncao != null) 'id_funcao': idFuncao,
      if (funcaoNome != null) 'funcao_nome': funcaoNome,
      if (funcaoDescricao != null) 'funcao_descricao': funcaoDescricao,
      if (idPapelFuncao != null) 'id_papel_funcao': idPapelFuncao,
      if (habilitado != null) 'habilitado': habilitado,
      if (podeInserir != null) 'pode_inserir': podeInserir,
      if (podeAlterar != null) 'pode_alterar': podeAlterar,
      if (podeExcluir != null) 'pode_excluir': podeExcluir,
    });
  }

  ViewControleAcessosCompanion copyWith(
      {Value<int?>? id,
      Value<int?>? idPessoa,
      Value<String?>? pessoaNome,
      Value<int?>? idColaborador,
      Value<int?>? idUsuario,
      Value<String?>? administrador,
      Value<int?>? idPapel,
      Value<String?>? papelNome,
      Value<String?>? papelDescricao,
      Value<int?>? idFuncao,
      Value<String?>? funcaoNome,
      Value<String?>? funcaoDescricao,
      Value<int?>? idPapelFuncao,
      Value<String?>? habilitado,
      Value<String?>? podeInserir,
      Value<String?>? podeAlterar,
      Value<String?>? podeExcluir}) {
    return ViewControleAcessosCompanion(
      id: id ?? this.id,
      idPessoa: idPessoa ?? this.idPessoa,
      pessoaNome: pessoaNome ?? this.pessoaNome,
      idColaborador: idColaborador ?? this.idColaborador,
      idUsuario: idUsuario ?? this.idUsuario,
      administrador: administrador ?? this.administrador,
      idPapel: idPapel ?? this.idPapel,
      papelNome: papelNome ?? this.papelNome,
      papelDescricao: papelDescricao ?? this.papelDescricao,
      idFuncao: idFuncao ?? this.idFuncao,
      funcaoNome: funcaoNome ?? this.funcaoNome,
      funcaoDescricao: funcaoDescricao ?? this.funcaoDescricao,
      idPapelFuncao: idPapelFuncao ?? this.idPapelFuncao,
      habilitado: habilitado ?? this.habilitado,
      podeInserir: podeInserir ?? this.podeInserir,
      podeAlterar: podeAlterar ?? this.podeAlterar,
      podeExcluir: podeExcluir ?? this.podeExcluir,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (idPessoa.present) {
      map['id_pessoa'] = Variable<int>(idPessoa.value);
    }
    if (pessoaNome.present) {
      map['pessoa_nome'] = Variable<String>(pessoaNome.value);
    }
    if (idColaborador.present) {
      map['id_colaborador'] = Variable<int>(idColaborador.value);
    }
    if (idUsuario.present) {
      map['id_usuario'] = Variable<int>(idUsuario.value);
    }
    if (administrador.present) {
      map['administrador'] = Variable<String>(administrador.value);
    }
    if (idPapel.present) {
      map['id_papel'] = Variable<int>(idPapel.value);
    }
    if (papelNome.present) {
      map['papel_nome'] = Variable<String>(papelNome.value);
    }
    if (papelDescricao.present) {
      map['papel_descricao'] = Variable<String>(papelDescricao.value);
    }
    if (idFuncao.present) {
      map['id_funcao'] = Variable<int>(idFuncao.value);
    }
    if (funcaoNome.present) {
      map['funcao_nome'] = Variable<String>(funcaoNome.value);
    }
    if (funcaoDescricao.present) {
      map['funcao_descricao'] = Variable<String>(funcaoDescricao.value);
    }
    if (idPapelFuncao.present) {
      map['id_papel_funcao'] = Variable<int>(idPapelFuncao.value);
    }
    if (habilitado.present) {
      map['habilitado'] = Variable<String>(habilitado.value);
    }
    if (podeInserir.present) {
      map['pode_inserir'] = Variable<String>(podeInserir.value);
    }
    if (podeAlterar.present) {
      map['pode_alterar'] = Variable<String>(podeAlterar.value);
    }
    if (podeExcluir.present) {
      map['pode_excluir'] = Variable<String>(podeExcluir.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('ViewControleAcessosCompanion(')
          ..write('id: $id, ')
          ..write('idPessoa: $idPessoa, ')
          ..write('pessoaNome: $pessoaNome, ')
          ..write('idColaborador: $idColaborador, ')
          ..write('idUsuario: $idUsuario, ')
          ..write('administrador: $administrador, ')
          ..write('idPapel: $idPapel, ')
          ..write('papelNome: $papelNome, ')
          ..write('papelDescricao: $papelDescricao, ')
          ..write('idFuncao: $idFuncao, ')
          ..write('funcaoNome: $funcaoNome, ')
          ..write('funcaoDescricao: $funcaoDescricao, ')
          ..write('idPapelFuncao: $idPapelFuncao, ')
          ..write('habilitado: $habilitado, ')
          ..write('podeInserir: $podeInserir, ')
          ..write('podeAlterar: $podeAlterar, ')
          ..write('podeExcluir: $podeExcluir')
          ..write(')'))
        .toString();
  }
}

class $ViewPessoaUsuariosTable extends ViewPessoaUsuarios
    with TableInfo<$ViewPessoaUsuariosTable, ViewPessoaUsuario> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $ViewPessoaUsuariosTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
      'id', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _idPessoaMeta =
      const VerificationMeta('idPessoa');
  @override
  late final GeneratedColumn<int> idPessoa = GeneratedColumn<int>(
      'id_pessoa', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _pessoaNomeMeta =
      const VerificationMeta('pessoaNome');
  @override
  late final GeneratedColumn<String> pessoaNome = GeneratedColumn<String>(
      'pessoa_nome', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 450),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _tipoMeta = const VerificationMeta('tipo');
  @override
  late final GeneratedColumn<String> tipo = GeneratedColumn<String>(
      'tipo', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 3),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _emailMeta = const VerificationMeta('email');
  @override
  late final GeneratedColumn<String> email = GeneratedColumn<String>(
      'email', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 750),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _idColaboradorMeta =
      const VerificationMeta('idColaborador');
  @override
  late final GeneratedColumn<int> idColaborador = GeneratedColumn<int>(
      'id_colaborador', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _idUsuarioMeta =
      const VerificationMeta('idUsuario');
  @override
  late final GeneratedColumn<int> idUsuario = GeneratedColumn<int>(
      'id_usuario', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _loginMeta = const VerificationMeta('login');
  @override
  late final GeneratedColumn<String> login = GeneratedColumn<String>(
      'login', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 150),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _senhaMeta = const VerificationMeta('senha');
  @override
  late final GeneratedColumn<String> senha = GeneratedColumn<String>(
      'senha', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 150),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _dataCadastroMeta =
      const VerificationMeta('dataCadastro');
  @override
  late final GeneratedColumn<DateTime> dataCadastro = GeneratedColumn<DateTime>(
      'data_cadastro', aliasedName, true,
      type: DriftSqlType.dateTime, requiredDuringInsert: false);
  static const VerificationMeta _administradorMeta =
      const VerificationMeta('administrador');
  @override
  late final GeneratedColumn<String> administrador = GeneratedColumn<String>(
      'administrador', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 3),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  @override
  List<GeneratedColumn> get $columns => [
        id,
        idPessoa,
        pessoaNome,
        tipo,
        email,
        idColaborador,
        idUsuario,
        login,
        senha,
        dataCadastro,
        administrador
      ];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'view_pessoa_usuario';
  @override
  VerificationContext validateIntegrity(Insertable<ViewPessoaUsuario> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('id_pessoa')) {
      context.handle(_idPessoaMeta,
          idPessoa.isAcceptableOrUnknown(data['id_pessoa']!, _idPessoaMeta));
    }
    if (data.containsKey('pessoa_nome')) {
      context.handle(
          _pessoaNomeMeta,
          pessoaNome.isAcceptableOrUnknown(
              data['pessoa_nome']!, _pessoaNomeMeta));
    }
    if (data.containsKey('tipo')) {
      context.handle(
          _tipoMeta, tipo.isAcceptableOrUnknown(data['tipo']!, _tipoMeta));
    }
    if (data.containsKey('email')) {
      context.handle(
          _emailMeta, email.isAcceptableOrUnknown(data['email']!, _emailMeta));
    }
    if (data.containsKey('id_colaborador')) {
      context.handle(
          _idColaboradorMeta,
          idColaborador.isAcceptableOrUnknown(
              data['id_colaborador']!, _idColaboradorMeta));
    }
    if (data.containsKey('id_usuario')) {
      context.handle(_idUsuarioMeta,
          idUsuario.isAcceptableOrUnknown(data['id_usuario']!, _idUsuarioMeta));
    }
    if (data.containsKey('login')) {
      context.handle(
          _loginMeta, login.isAcceptableOrUnknown(data['login']!, _loginMeta));
    }
    if (data.containsKey('senha')) {
      context.handle(
          _senhaMeta, senha.isAcceptableOrUnknown(data['senha']!, _senhaMeta));
    }
    if (data.containsKey('data_cadastro')) {
      context.handle(
          _dataCadastroMeta,
          dataCadastro.isAcceptableOrUnknown(
              data['data_cadastro']!, _dataCadastroMeta));
    }
    if (data.containsKey('administrador')) {
      context.handle(
          _administradorMeta,
          administrador.isAcceptableOrUnknown(
              data['administrador']!, _administradorMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  ViewPessoaUsuario map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return ViewPessoaUsuario(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id']),
      idPessoa: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id_pessoa']),
      pessoaNome: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}pessoa_nome']),
      tipo: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}tipo']),
      email: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}email']),
      idColaborador: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id_colaborador']),
      idUsuario: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id_usuario']),
      login: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}login']),
      senha: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}senha']),
      dataCadastro: attachedDatabase.typeMapping
          .read(DriftSqlType.dateTime, data['${effectivePrefix}data_cadastro']),
      administrador: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}administrador']),
    );
  }

  @override
  $ViewPessoaUsuariosTable createAlias(String alias) {
    return $ViewPessoaUsuariosTable(attachedDatabase, alias);
  }
}

class ViewPessoaUsuario extends DataClass
    implements Insertable<ViewPessoaUsuario> {
  final int? id;
  final int? idPessoa;
  final String? pessoaNome;
  final String? tipo;
  final String? email;
  final int? idColaborador;
  final int? idUsuario;
  final String? login;
  final String? senha;
  final DateTime? dataCadastro;
  final String? administrador;
  const ViewPessoaUsuario(
      {this.id,
      this.idPessoa,
      this.pessoaNome,
      this.tipo,
      this.email,
      this.idColaborador,
      this.idUsuario,
      this.login,
      this.senha,
      this.dataCadastro,
      this.administrador});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || idPessoa != null) {
      map['id_pessoa'] = Variable<int>(idPessoa);
    }
    if (!nullToAbsent || pessoaNome != null) {
      map['pessoa_nome'] = Variable<String>(pessoaNome);
    }
    if (!nullToAbsent || tipo != null) {
      map['tipo'] = Variable<String>(tipo);
    }
    if (!nullToAbsent || email != null) {
      map['email'] = Variable<String>(email);
    }
    if (!nullToAbsent || idColaborador != null) {
      map['id_colaborador'] = Variable<int>(idColaborador);
    }
    if (!nullToAbsent || idUsuario != null) {
      map['id_usuario'] = Variable<int>(idUsuario);
    }
    if (!nullToAbsent || login != null) {
      map['login'] = Variable<String>(login);
    }
    if (!nullToAbsent || senha != null) {
      map['senha'] = Variable<String>(senha);
    }
    if (!nullToAbsent || dataCadastro != null) {
      map['data_cadastro'] = Variable<DateTime>(dataCadastro);
    }
    if (!nullToAbsent || administrador != null) {
      map['administrador'] = Variable<String>(administrador);
    }
    return map;
  }

  factory ViewPessoaUsuario.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return ViewPessoaUsuario(
      id: serializer.fromJson<int?>(json['id']),
      idPessoa: serializer.fromJson<int?>(json['idPessoa']),
      pessoaNome: serializer.fromJson<String?>(json['pessoaNome']),
      tipo: serializer.fromJson<String?>(json['tipo']),
      email: serializer.fromJson<String?>(json['email']),
      idColaborador: serializer.fromJson<int?>(json['idColaborador']),
      idUsuario: serializer.fromJson<int?>(json['idUsuario']),
      login: serializer.fromJson<String?>(json['login']),
      senha: serializer.fromJson<String?>(json['senha']),
      dataCadastro: serializer.fromJson<DateTime?>(json['dataCadastro']),
      administrador: serializer.fromJson<String?>(json['administrador']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'idPessoa': serializer.toJson<int?>(idPessoa),
      'pessoaNome': serializer.toJson<String?>(pessoaNome),
      'tipo': serializer.toJson<String?>(tipo),
      'email': serializer.toJson<String?>(email),
      'idColaborador': serializer.toJson<int?>(idColaborador),
      'idUsuario': serializer.toJson<int?>(idUsuario),
      'login': serializer.toJson<String?>(login),
      'senha': serializer.toJson<String?>(senha),
      'dataCadastro': serializer.toJson<DateTime?>(dataCadastro),
      'administrador': serializer.toJson<String?>(administrador),
    };
  }

  ViewPessoaUsuario copyWith(
          {Value<int?> id = const Value.absent(),
          Value<int?> idPessoa = const Value.absent(),
          Value<String?> pessoaNome = const Value.absent(),
          Value<String?> tipo = const Value.absent(),
          Value<String?> email = const Value.absent(),
          Value<int?> idColaborador = const Value.absent(),
          Value<int?> idUsuario = const Value.absent(),
          Value<String?> login = const Value.absent(),
          Value<String?> senha = const Value.absent(),
          Value<DateTime?> dataCadastro = const Value.absent(),
          Value<String?> administrador = const Value.absent()}) =>
      ViewPessoaUsuario(
        id: id.present ? id.value : this.id,
        idPessoa: idPessoa.present ? idPessoa.value : this.idPessoa,
        pessoaNome: pessoaNome.present ? pessoaNome.value : this.pessoaNome,
        tipo: tipo.present ? tipo.value : this.tipo,
        email: email.present ? email.value : this.email,
        idColaborador:
            idColaborador.present ? idColaborador.value : this.idColaborador,
        idUsuario: idUsuario.present ? idUsuario.value : this.idUsuario,
        login: login.present ? login.value : this.login,
        senha: senha.present ? senha.value : this.senha,
        dataCadastro:
            dataCadastro.present ? dataCadastro.value : this.dataCadastro,
        administrador:
            administrador.present ? administrador.value : this.administrador,
      );
  ViewPessoaUsuario copyWithCompanion(ViewPessoaUsuariosCompanion data) {
    return ViewPessoaUsuario(
      id: data.id.present ? data.id.value : this.id,
      idPessoa: data.idPessoa.present ? data.idPessoa.value : this.idPessoa,
      pessoaNome:
          data.pessoaNome.present ? data.pessoaNome.value : this.pessoaNome,
      tipo: data.tipo.present ? data.tipo.value : this.tipo,
      email: data.email.present ? data.email.value : this.email,
      idColaborador: data.idColaborador.present
          ? data.idColaborador.value
          : this.idColaborador,
      idUsuario: data.idUsuario.present ? data.idUsuario.value : this.idUsuario,
      login: data.login.present ? data.login.value : this.login,
      senha: data.senha.present ? data.senha.value : this.senha,
      dataCadastro: data.dataCadastro.present
          ? data.dataCadastro.value
          : this.dataCadastro,
      administrador: data.administrador.present
          ? data.administrador.value
          : this.administrador,
    );
  }

  @override
  String toString() {
    return (StringBuffer('ViewPessoaUsuario(')
          ..write('id: $id, ')
          ..write('idPessoa: $idPessoa, ')
          ..write('pessoaNome: $pessoaNome, ')
          ..write('tipo: $tipo, ')
          ..write('email: $email, ')
          ..write('idColaborador: $idColaborador, ')
          ..write('idUsuario: $idUsuario, ')
          ..write('login: $login, ')
          ..write('senha: $senha, ')
          ..write('dataCadastro: $dataCadastro, ')
          ..write('administrador: $administrador')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(id, idPessoa, pessoaNome, tipo, email,
      idColaborador, idUsuario, login, senha, dataCadastro, administrador);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is ViewPessoaUsuario &&
          other.id == this.id &&
          other.idPessoa == this.idPessoa &&
          other.pessoaNome == this.pessoaNome &&
          other.tipo == this.tipo &&
          other.email == this.email &&
          other.idColaborador == this.idColaborador &&
          other.idUsuario == this.idUsuario &&
          other.login == this.login &&
          other.senha == this.senha &&
          other.dataCadastro == this.dataCadastro &&
          other.administrador == this.administrador);
}

class ViewPessoaUsuariosCompanion extends UpdateCompanion<ViewPessoaUsuario> {
  final Value<int?> id;
  final Value<int?> idPessoa;
  final Value<String?> pessoaNome;
  final Value<String?> tipo;
  final Value<String?> email;
  final Value<int?> idColaborador;
  final Value<int?> idUsuario;
  final Value<String?> login;
  final Value<String?> senha;
  final Value<DateTime?> dataCadastro;
  final Value<String?> administrador;
  const ViewPessoaUsuariosCompanion({
    this.id = const Value.absent(),
    this.idPessoa = const Value.absent(),
    this.pessoaNome = const Value.absent(),
    this.tipo = const Value.absent(),
    this.email = const Value.absent(),
    this.idColaborador = const Value.absent(),
    this.idUsuario = const Value.absent(),
    this.login = const Value.absent(),
    this.senha = const Value.absent(),
    this.dataCadastro = const Value.absent(),
    this.administrador = const Value.absent(),
  });
  ViewPessoaUsuariosCompanion.insert({
    this.id = const Value.absent(),
    this.idPessoa = const Value.absent(),
    this.pessoaNome = const Value.absent(),
    this.tipo = const Value.absent(),
    this.email = const Value.absent(),
    this.idColaborador = const Value.absent(),
    this.idUsuario = const Value.absent(),
    this.login = const Value.absent(),
    this.senha = const Value.absent(),
    this.dataCadastro = const Value.absent(),
    this.administrador = const Value.absent(),
  });
  static Insertable<ViewPessoaUsuario> custom({
    Expression<int>? id,
    Expression<int>? idPessoa,
    Expression<String>? pessoaNome,
    Expression<String>? tipo,
    Expression<String>? email,
    Expression<int>? idColaborador,
    Expression<int>? idUsuario,
    Expression<String>? login,
    Expression<String>? senha,
    Expression<DateTime>? dataCadastro,
    Expression<String>? administrador,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (idPessoa != null) 'id_pessoa': idPessoa,
      if (pessoaNome != null) 'pessoa_nome': pessoaNome,
      if (tipo != null) 'tipo': tipo,
      if (email != null) 'email': email,
      if (idColaborador != null) 'id_colaborador': idColaborador,
      if (idUsuario != null) 'id_usuario': idUsuario,
      if (login != null) 'login': login,
      if (senha != null) 'senha': senha,
      if (dataCadastro != null) 'data_cadastro': dataCadastro,
      if (administrador != null) 'administrador': administrador,
    });
  }

  ViewPessoaUsuariosCompanion copyWith(
      {Value<int?>? id,
      Value<int?>? idPessoa,
      Value<String?>? pessoaNome,
      Value<String?>? tipo,
      Value<String?>? email,
      Value<int?>? idColaborador,
      Value<int?>? idUsuario,
      Value<String?>? login,
      Value<String?>? senha,
      Value<DateTime?>? dataCadastro,
      Value<String?>? administrador}) {
    return ViewPessoaUsuariosCompanion(
      id: id ?? this.id,
      idPessoa: idPessoa ?? this.idPessoa,
      pessoaNome: pessoaNome ?? this.pessoaNome,
      tipo: tipo ?? this.tipo,
      email: email ?? this.email,
      idColaborador: idColaborador ?? this.idColaborador,
      idUsuario: idUsuario ?? this.idUsuario,
      login: login ?? this.login,
      senha: senha ?? this.senha,
      dataCadastro: dataCadastro ?? this.dataCadastro,
      administrador: administrador ?? this.administrador,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (idPessoa.present) {
      map['id_pessoa'] = Variable<int>(idPessoa.value);
    }
    if (pessoaNome.present) {
      map['pessoa_nome'] = Variable<String>(pessoaNome.value);
    }
    if (tipo.present) {
      map['tipo'] = Variable<String>(tipo.value);
    }
    if (email.present) {
      map['email'] = Variable<String>(email.value);
    }
    if (idColaborador.present) {
      map['id_colaborador'] = Variable<int>(idColaborador.value);
    }
    if (idUsuario.present) {
      map['id_usuario'] = Variable<int>(idUsuario.value);
    }
    if (login.present) {
      map['login'] = Variable<String>(login.value);
    }
    if (senha.present) {
      map['senha'] = Variable<String>(senha.value);
    }
    if (dataCadastro.present) {
      map['data_cadastro'] = Variable<DateTime>(dataCadastro.value);
    }
    if (administrador.present) {
      map['administrador'] = Variable<String>(administrador.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('ViewPessoaUsuariosCompanion(')
          ..write('id: $id, ')
          ..write('idPessoa: $idPessoa, ')
          ..write('pessoaNome: $pessoaNome, ')
          ..write('tipo: $tipo, ')
          ..write('email: $email, ')
          ..write('idColaborador: $idColaborador, ')
          ..write('idUsuario: $idUsuario, ')
          ..write('login: $login, ')
          ..write('senha: $senha, ')
          ..write('dataCadastro: $dataCadastro, ')
          ..write('administrador: $administrador')
          ..write(')'))
        .toString();
  }
}

class $ViewPessoaColaboradorsTable extends ViewPessoaColaboradors
    with TableInfo<$ViewPessoaColaboradorsTable, ViewPessoaColaborador> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $ViewPessoaColaboradorsTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
      'id', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _nomeMeta = const VerificationMeta('nome');
  @override
  late final GeneratedColumn<String> nome = GeneratedColumn<String>(
      'nome', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 450),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _tipoMeta = const VerificationMeta('tipo');
  @override
  late final GeneratedColumn<String> tipo = GeneratedColumn<String>(
      'tipo', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 3),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _emailMeta = const VerificationMeta('email');
  @override
  late final GeneratedColumn<String> email = GeneratedColumn<String>(
      'email', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 750),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _siteMeta = const VerificationMeta('site');
  @override
  late final GeneratedColumn<String> site = GeneratedColumn<String>(
      'site', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 450),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _cpfCnpjMeta =
      const VerificationMeta('cpfCnpj');
  @override
  late final GeneratedColumn<String> cpfCnpj = GeneratedColumn<String>(
      'cpf_cnpj', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 20),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _rgIeMeta = const VerificationMeta('rgIe');
  @override
  late final GeneratedColumn<String> rgIe = GeneratedColumn<String>(
      'rg_ie', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 20),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _matriculaMeta =
      const VerificationMeta('matricula');
  @override
  late final GeneratedColumn<String> matricula = GeneratedColumn<String>(
      'matricula', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 50),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _dataCadastroMeta =
      const VerificationMeta('dataCadastro');
  @override
  late final GeneratedColumn<DateTime> dataCadastro = GeneratedColumn<DateTime>(
      'data_cadastro', aliasedName, true,
      type: DriftSqlType.dateTime, requiredDuringInsert: false);
  static const VerificationMeta _dataAdmissaoMeta =
      const VerificationMeta('dataAdmissao');
  @override
  late final GeneratedColumn<DateTime> dataAdmissao = GeneratedColumn<DateTime>(
      'data_admissao', aliasedName, true,
      type: DriftSqlType.dateTime, requiredDuringInsert: false);
  static const VerificationMeta _dataDemissaoMeta =
      const VerificationMeta('dataDemissao');
  @override
  late final GeneratedColumn<DateTime> dataDemissao = GeneratedColumn<DateTime>(
      'data_demissao', aliasedName, true,
      type: DriftSqlType.dateTime, requiredDuringInsert: false);
  static const VerificationMeta _ctpsNumeroMeta =
      const VerificationMeta('ctpsNumero');
  @override
  late final GeneratedColumn<String> ctpsNumero = GeneratedColumn<String>(
      'ctps_numero', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 20),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _ctpsSerieMeta =
      const VerificationMeta('ctpsSerie');
  @override
  late final GeneratedColumn<String> ctpsSerie = GeneratedColumn<String>(
      'ctps_serie', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 10),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _ctpsDataExpedicaoMeta =
      const VerificationMeta('ctpsDataExpedicao');
  @override
  late final GeneratedColumn<DateTime> ctpsDataExpedicao =
      GeneratedColumn<DateTime>('ctps_data_expedicao', aliasedName, true,
          type: DriftSqlType.dateTime, requiredDuringInsert: false);
  static const VerificationMeta _ctpsUfMeta = const VerificationMeta('ctpsUf');
  @override
  late final GeneratedColumn<String> ctpsUf = GeneratedColumn<String>(
      'ctps_uf', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 2),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _observacaoMeta =
      const VerificationMeta('observacao');
  @override
  late final GeneratedColumn<String> observacao = GeneratedColumn<String>(
      'observacao', aliasedName, true,
      type: DriftSqlType.string, requiredDuringInsert: false);
  static const VerificationMeta _logradouroMeta =
      const VerificationMeta('logradouro');
  @override
  late final GeneratedColumn<String> logradouro = GeneratedColumn<String>(
      'logradouro', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 450),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _numeroMeta = const VerificationMeta('numero');
  @override
  late final GeneratedColumn<String> numero = GeneratedColumn<String>(
      'numero', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 20),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _complementoMeta =
      const VerificationMeta('complemento');
  @override
  late final GeneratedColumn<String> complemento = GeneratedColumn<String>(
      'complemento', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 450),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _bairroMeta = const VerificationMeta('bairro');
  @override
  late final GeneratedColumn<String> bairro = GeneratedColumn<String>(
      'bairro', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 150),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _cidadeMeta = const VerificationMeta('cidade');
  @override
  late final GeneratedColumn<String> cidade = GeneratedColumn<String>(
      'cidade', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 150),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _cepMeta = const VerificationMeta('cep');
  @override
  late final GeneratedColumn<String> cep = GeneratedColumn<String>(
      'cep', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 10),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _municipioIbgeMeta =
      const VerificationMeta('municipioIbge');
  @override
  late final GeneratedColumn<String> municipioIbge = GeneratedColumn<String>(
      'municipio_ibge', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 10),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _ufMeta = const VerificationMeta('uf');
  @override
  late final GeneratedColumn<String> uf = GeneratedColumn<String>(
      'uf', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 2),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _idPessoaMeta =
      const VerificationMeta('idPessoa');
  @override
  late final GeneratedColumn<int> idPessoa = GeneratedColumn<int>(
      'id_pessoa', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _idCargoMeta =
      const VerificationMeta('idCargo');
  @override
  late final GeneratedColumn<int> idCargo = GeneratedColumn<int>(
      'id_cargo', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _idSetorMeta =
      const VerificationMeta('idSetor');
  @override
  late final GeneratedColumn<int> idSetor = GeneratedColumn<int>(
      'id_setor', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  @override
  List<GeneratedColumn> get $columns => [
        id,
        nome,
        tipo,
        email,
        site,
        cpfCnpj,
        rgIe,
        matricula,
        dataCadastro,
        dataAdmissao,
        dataDemissao,
        ctpsNumero,
        ctpsSerie,
        ctpsDataExpedicao,
        ctpsUf,
        observacao,
        logradouro,
        numero,
        complemento,
        bairro,
        cidade,
        cep,
        municipioIbge,
        uf,
        idPessoa,
        idCargo,
        idSetor
      ];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'view_pessoa_colaborador';
  @override
  VerificationContext validateIntegrity(
      Insertable<ViewPessoaColaborador> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('nome')) {
      context.handle(
          _nomeMeta, nome.isAcceptableOrUnknown(data['nome']!, _nomeMeta));
    }
    if (data.containsKey('tipo')) {
      context.handle(
          _tipoMeta, tipo.isAcceptableOrUnknown(data['tipo']!, _tipoMeta));
    }
    if (data.containsKey('email')) {
      context.handle(
          _emailMeta, email.isAcceptableOrUnknown(data['email']!, _emailMeta));
    }
    if (data.containsKey('site')) {
      context.handle(
          _siteMeta, site.isAcceptableOrUnknown(data['site']!, _siteMeta));
    }
    if (data.containsKey('cpf_cnpj')) {
      context.handle(_cpfCnpjMeta,
          cpfCnpj.isAcceptableOrUnknown(data['cpf_cnpj']!, _cpfCnpjMeta));
    }
    if (data.containsKey('rg_ie')) {
      context.handle(
          _rgIeMeta, rgIe.isAcceptableOrUnknown(data['rg_ie']!, _rgIeMeta));
    }
    if (data.containsKey('matricula')) {
      context.handle(_matriculaMeta,
          matricula.isAcceptableOrUnknown(data['matricula']!, _matriculaMeta));
    }
    if (data.containsKey('data_cadastro')) {
      context.handle(
          _dataCadastroMeta,
          dataCadastro.isAcceptableOrUnknown(
              data['data_cadastro']!, _dataCadastroMeta));
    }
    if (data.containsKey('data_admissao')) {
      context.handle(
          _dataAdmissaoMeta,
          dataAdmissao.isAcceptableOrUnknown(
              data['data_admissao']!, _dataAdmissaoMeta));
    }
    if (data.containsKey('data_demissao')) {
      context.handle(
          _dataDemissaoMeta,
          dataDemissao.isAcceptableOrUnknown(
              data['data_demissao']!, _dataDemissaoMeta));
    }
    if (data.containsKey('ctps_numero')) {
      context.handle(
          _ctpsNumeroMeta,
          ctpsNumero.isAcceptableOrUnknown(
              data['ctps_numero']!, _ctpsNumeroMeta));
    }
    if (data.containsKey('ctps_serie')) {
      context.handle(_ctpsSerieMeta,
          ctpsSerie.isAcceptableOrUnknown(data['ctps_serie']!, _ctpsSerieMeta));
    }
    if (data.containsKey('ctps_data_expedicao')) {
      context.handle(
          _ctpsDataExpedicaoMeta,
          ctpsDataExpedicao.isAcceptableOrUnknown(
              data['ctps_data_expedicao']!, _ctpsDataExpedicaoMeta));
    }
    if (data.containsKey('ctps_uf')) {
      context.handle(_ctpsUfMeta,
          ctpsUf.isAcceptableOrUnknown(data['ctps_uf']!, _ctpsUfMeta));
    }
    if (data.containsKey('observacao')) {
      context.handle(
          _observacaoMeta,
          observacao.isAcceptableOrUnknown(
              data['observacao']!, _observacaoMeta));
    }
    if (data.containsKey('logradouro')) {
      context.handle(
          _logradouroMeta,
          logradouro.isAcceptableOrUnknown(
              data['logradouro']!, _logradouroMeta));
    }
    if (data.containsKey('numero')) {
      context.handle(_numeroMeta,
          numero.isAcceptableOrUnknown(data['numero']!, _numeroMeta));
    }
    if (data.containsKey('complemento')) {
      context.handle(
          _complementoMeta,
          complemento.isAcceptableOrUnknown(
              data['complemento']!, _complementoMeta));
    }
    if (data.containsKey('bairro')) {
      context.handle(_bairroMeta,
          bairro.isAcceptableOrUnknown(data['bairro']!, _bairroMeta));
    }
    if (data.containsKey('cidade')) {
      context.handle(_cidadeMeta,
          cidade.isAcceptableOrUnknown(data['cidade']!, _cidadeMeta));
    }
    if (data.containsKey('cep')) {
      context.handle(
          _cepMeta, cep.isAcceptableOrUnknown(data['cep']!, _cepMeta));
    }
    if (data.containsKey('municipio_ibge')) {
      context.handle(
          _municipioIbgeMeta,
          municipioIbge.isAcceptableOrUnknown(
              data['municipio_ibge']!, _municipioIbgeMeta));
    }
    if (data.containsKey('uf')) {
      context.handle(_ufMeta, uf.isAcceptableOrUnknown(data['uf']!, _ufMeta));
    }
    if (data.containsKey('id_pessoa')) {
      context.handle(_idPessoaMeta,
          idPessoa.isAcceptableOrUnknown(data['id_pessoa']!, _idPessoaMeta));
    }
    if (data.containsKey('id_cargo')) {
      context.handle(_idCargoMeta,
          idCargo.isAcceptableOrUnknown(data['id_cargo']!, _idCargoMeta));
    }
    if (data.containsKey('id_setor')) {
      context.handle(_idSetorMeta,
          idSetor.isAcceptableOrUnknown(data['id_setor']!, _idSetorMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  ViewPessoaColaborador map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return ViewPessoaColaborador(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id']),
      nome: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}nome']),
      tipo: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}tipo']),
      email: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}email']),
      site: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}site']),
      cpfCnpj: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}cpf_cnpj']),
      rgIe: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}rg_ie']),
      matricula: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}matricula']),
      dataCadastro: attachedDatabase.typeMapping
          .read(DriftSqlType.dateTime, data['${effectivePrefix}data_cadastro']),
      dataAdmissao: attachedDatabase.typeMapping
          .read(DriftSqlType.dateTime, data['${effectivePrefix}data_admissao']),
      dataDemissao: attachedDatabase.typeMapping
          .read(DriftSqlType.dateTime, data['${effectivePrefix}data_demissao']),
      ctpsNumero: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}ctps_numero']),
      ctpsSerie: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}ctps_serie']),
      ctpsDataExpedicao: attachedDatabase.typeMapping.read(
          DriftSqlType.dateTime, data['${effectivePrefix}ctps_data_expedicao']),
      ctpsUf: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}ctps_uf']),
      observacao: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}observacao']),
      logradouro: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}logradouro']),
      numero: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}numero']),
      complemento: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}complemento']),
      bairro: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}bairro']),
      cidade: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}cidade']),
      cep: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}cep']),
      municipioIbge: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}municipio_ibge']),
      uf: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}uf']),
      idPessoa: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id_pessoa']),
      idCargo: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id_cargo']),
      idSetor: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id_setor']),
    );
  }

  @override
  $ViewPessoaColaboradorsTable createAlias(String alias) {
    return $ViewPessoaColaboradorsTable(attachedDatabase, alias);
  }
}

class ViewPessoaColaborador extends DataClass
    implements Insertable<ViewPessoaColaborador> {
  final int? id;
  final String? nome;
  final String? tipo;
  final String? email;
  final String? site;
  final String? cpfCnpj;
  final String? rgIe;
  final String? matricula;
  final DateTime? dataCadastro;
  final DateTime? dataAdmissao;
  final DateTime? dataDemissao;
  final String? ctpsNumero;
  final String? ctpsSerie;
  final DateTime? ctpsDataExpedicao;
  final String? ctpsUf;
  final String? observacao;
  final String? logradouro;
  final String? numero;
  final String? complemento;
  final String? bairro;
  final String? cidade;
  final String? cep;
  final String? municipioIbge;
  final String? uf;
  final int? idPessoa;
  final int? idCargo;
  final int? idSetor;
  const ViewPessoaColaborador(
      {this.id,
      this.nome,
      this.tipo,
      this.email,
      this.site,
      this.cpfCnpj,
      this.rgIe,
      this.matricula,
      this.dataCadastro,
      this.dataAdmissao,
      this.dataDemissao,
      this.ctpsNumero,
      this.ctpsSerie,
      this.ctpsDataExpedicao,
      this.ctpsUf,
      this.observacao,
      this.logradouro,
      this.numero,
      this.complemento,
      this.bairro,
      this.cidade,
      this.cep,
      this.municipioIbge,
      this.uf,
      this.idPessoa,
      this.idCargo,
      this.idSetor});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || nome != null) {
      map['nome'] = Variable<String>(nome);
    }
    if (!nullToAbsent || tipo != null) {
      map['tipo'] = Variable<String>(tipo);
    }
    if (!nullToAbsent || email != null) {
      map['email'] = Variable<String>(email);
    }
    if (!nullToAbsent || site != null) {
      map['site'] = Variable<String>(site);
    }
    if (!nullToAbsent || cpfCnpj != null) {
      map['cpf_cnpj'] = Variable<String>(cpfCnpj);
    }
    if (!nullToAbsent || rgIe != null) {
      map['rg_ie'] = Variable<String>(rgIe);
    }
    if (!nullToAbsent || matricula != null) {
      map['matricula'] = Variable<String>(matricula);
    }
    if (!nullToAbsent || dataCadastro != null) {
      map['data_cadastro'] = Variable<DateTime>(dataCadastro);
    }
    if (!nullToAbsent || dataAdmissao != null) {
      map['data_admissao'] = Variable<DateTime>(dataAdmissao);
    }
    if (!nullToAbsent || dataDemissao != null) {
      map['data_demissao'] = Variable<DateTime>(dataDemissao);
    }
    if (!nullToAbsent || ctpsNumero != null) {
      map['ctps_numero'] = Variable<String>(ctpsNumero);
    }
    if (!nullToAbsent || ctpsSerie != null) {
      map['ctps_serie'] = Variable<String>(ctpsSerie);
    }
    if (!nullToAbsent || ctpsDataExpedicao != null) {
      map['ctps_data_expedicao'] = Variable<DateTime>(ctpsDataExpedicao);
    }
    if (!nullToAbsent || ctpsUf != null) {
      map['ctps_uf'] = Variable<String>(ctpsUf);
    }
    if (!nullToAbsent || observacao != null) {
      map['observacao'] = Variable<String>(observacao);
    }
    if (!nullToAbsent || logradouro != null) {
      map['logradouro'] = Variable<String>(logradouro);
    }
    if (!nullToAbsent || numero != null) {
      map['numero'] = Variable<String>(numero);
    }
    if (!nullToAbsent || complemento != null) {
      map['complemento'] = Variable<String>(complemento);
    }
    if (!nullToAbsent || bairro != null) {
      map['bairro'] = Variable<String>(bairro);
    }
    if (!nullToAbsent || cidade != null) {
      map['cidade'] = Variable<String>(cidade);
    }
    if (!nullToAbsent || cep != null) {
      map['cep'] = Variable<String>(cep);
    }
    if (!nullToAbsent || municipioIbge != null) {
      map['municipio_ibge'] = Variable<String>(municipioIbge);
    }
    if (!nullToAbsent || uf != null) {
      map['uf'] = Variable<String>(uf);
    }
    if (!nullToAbsent || idPessoa != null) {
      map['id_pessoa'] = Variable<int>(idPessoa);
    }
    if (!nullToAbsent || idCargo != null) {
      map['id_cargo'] = Variable<int>(idCargo);
    }
    if (!nullToAbsent || idSetor != null) {
      map['id_setor'] = Variable<int>(idSetor);
    }
    return map;
  }

  factory ViewPessoaColaborador.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return ViewPessoaColaborador(
      id: serializer.fromJson<int?>(json['id']),
      nome: serializer.fromJson<String?>(json['nome']),
      tipo: serializer.fromJson<String?>(json['tipo']),
      email: serializer.fromJson<String?>(json['email']),
      site: serializer.fromJson<String?>(json['site']),
      cpfCnpj: serializer.fromJson<String?>(json['cpfCnpj']),
      rgIe: serializer.fromJson<String?>(json['rgIe']),
      matricula: serializer.fromJson<String?>(json['matricula']),
      dataCadastro: serializer.fromJson<DateTime?>(json['dataCadastro']),
      dataAdmissao: serializer.fromJson<DateTime?>(json['dataAdmissao']),
      dataDemissao: serializer.fromJson<DateTime?>(json['dataDemissao']),
      ctpsNumero: serializer.fromJson<String?>(json['ctpsNumero']),
      ctpsSerie: serializer.fromJson<String?>(json['ctpsSerie']),
      ctpsDataExpedicao:
          serializer.fromJson<DateTime?>(json['ctpsDataExpedicao']),
      ctpsUf: serializer.fromJson<String?>(json['ctpsUf']),
      observacao: serializer.fromJson<String?>(json['observacao']),
      logradouro: serializer.fromJson<String?>(json['logradouro']),
      numero: serializer.fromJson<String?>(json['numero']),
      complemento: serializer.fromJson<String?>(json['complemento']),
      bairro: serializer.fromJson<String?>(json['bairro']),
      cidade: serializer.fromJson<String?>(json['cidade']),
      cep: serializer.fromJson<String?>(json['cep']),
      municipioIbge: serializer.fromJson<String?>(json['municipioIbge']),
      uf: serializer.fromJson<String?>(json['uf']),
      idPessoa: serializer.fromJson<int?>(json['idPessoa']),
      idCargo: serializer.fromJson<int?>(json['idCargo']),
      idSetor: serializer.fromJson<int?>(json['idSetor']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'nome': serializer.toJson<String?>(nome),
      'tipo': serializer.toJson<String?>(tipo),
      'email': serializer.toJson<String?>(email),
      'site': serializer.toJson<String?>(site),
      'cpfCnpj': serializer.toJson<String?>(cpfCnpj),
      'rgIe': serializer.toJson<String?>(rgIe),
      'matricula': serializer.toJson<String?>(matricula),
      'dataCadastro': serializer.toJson<DateTime?>(dataCadastro),
      'dataAdmissao': serializer.toJson<DateTime?>(dataAdmissao),
      'dataDemissao': serializer.toJson<DateTime?>(dataDemissao),
      'ctpsNumero': serializer.toJson<String?>(ctpsNumero),
      'ctpsSerie': serializer.toJson<String?>(ctpsSerie),
      'ctpsDataExpedicao': serializer.toJson<DateTime?>(ctpsDataExpedicao),
      'ctpsUf': serializer.toJson<String?>(ctpsUf),
      'observacao': serializer.toJson<String?>(observacao),
      'logradouro': serializer.toJson<String?>(logradouro),
      'numero': serializer.toJson<String?>(numero),
      'complemento': serializer.toJson<String?>(complemento),
      'bairro': serializer.toJson<String?>(bairro),
      'cidade': serializer.toJson<String?>(cidade),
      'cep': serializer.toJson<String?>(cep),
      'municipioIbge': serializer.toJson<String?>(municipioIbge),
      'uf': serializer.toJson<String?>(uf),
      'idPessoa': serializer.toJson<int?>(idPessoa),
      'idCargo': serializer.toJson<int?>(idCargo),
      'idSetor': serializer.toJson<int?>(idSetor),
    };
  }

  ViewPessoaColaborador copyWith(
          {Value<int?> id = const Value.absent(),
          Value<String?> nome = const Value.absent(),
          Value<String?> tipo = const Value.absent(),
          Value<String?> email = const Value.absent(),
          Value<String?> site = const Value.absent(),
          Value<String?> cpfCnpj = const Value.absent(),
          Value<String?> rgIe = const Value.absent(),
          Value<String?> matricula = const Value.absent(),
          Value<DateTime?> dataCadastro = const Value.absent(),
          Value<DateTime?> dataAdmissao = const Value.absent(),
          Value<DateTime?> dataDemissao = const Value.absent(),
          Value<String?> ctpsNumero = const Value.absent(),
          Value<String?> ctpsSerie = const Value.absent(),
          Value<DateTime?> ctpsDataExpedicao = const Value.absent(),
          Value<String?> ctpsUf = const Value.absent(),
          Value<String?> observacao = const Value.absent(),
          Value<String?> logradouro = const Value.absent(),
          Value<String?> numero = const Value.absent(),
          Value<String?> complemento = const Value.absent(),
          Value<String?> bairro = const Value.absent(),
          Value<String?> cidade = const Value.absent(),
          Value<String?> cep = const Value.absent(),
          Value<String?> municipioIbge = const Value.absent(),
          Value<String?> uf = const Value.absent(),
          Value<int?> idPessoa = const Value.absent(),
          Value<int?> idCargo = const Value.absent(),
          Value<int?> idSetor = const Value.absent()}) =>
      ViewPessoaColaborador(
        id: id.present ? id.value : this.id,
        nome: nome.present ? nome.value : this.nome,
        tipo: tipo.present ? tipo.value : this.tipo,
        email: email.present ? email.value : this.email,
        site: site.present ? site.value : this.site,
        cpfCnpj: cpfCnpj.present ? cpfCnpj.value : this.cpfCnpj,
        rgIe: rgIe.present ? rgIe.value : this.rgIe,
        matricula: matricula.present ? matricula.value : this.matricula,
        dataCadastro:
            dataCadastro.present ? dataCadastro.value : this.dataCadastro,
        dataAdmissao:
            dataAdmissao.present ? dataAdmissao.value : this.dataAdmissao,
        dataDemissao:
            dataDemissao.present ? dataDemissao.value : this.dataDemissao,
        ctpsNumero: ctpsNumero.present ? ctpsNumero.value : this.ctpsNumero,
        ctpsSerie: ctpsSerie.present ? ctpsSerie.value : this.ctpsSerie,
        ctpsDataExpedicao: ctpsDataExpedicao.present
            ? ctpsDataExpedicao.value
            : this.ctpsDataExpedicao,
        ctpsUf: ctpsUf.present ? ctpsUf.value : this.ctpsUf,
        observacao: observacao.present ? observacao.value : this.observacao,
        logradouro: logradouro.present ? logradouro.value : this.logradouro,
        numero: numero.present ? numero.value : this.numero,
        complemento: complemento.present ? complemento.value : this.complemento,
        bairro: bairro.present ? bairro.value : this.bairro,
        cidade: cidade.present ? cidade.value : this.cidade,
        cep: cep.present ? cep.value : this.cep,
        municipioIbge:
            municipioIbge.present ? municipioIbge.value : this.municipioIbge,
        uf: uf.present ? uf.value : this.uf,
        idPessoa: idPessoa.present ? idPessoa.value : this.idPessoa,
        idCargo: idCargo.present ? idCargo.value : this.idCargo,
        idSetor: idSetor.present ? idSetor.value : this.idSetor,
      );
  ViewPessoaColaborador copyWithCompanion(
      ViewPessoaColaboradorsCompanion data) {
    return ViewPessoaColaborador(
      id: data.id.present ? data.id.value : this.id,
      nome: data.nome.present ? data.nome.value : this.nome,
      tipo: data.tipo.present ? data.tipo.value : this.tipo,
      email: data.email.present ? data.email.value : this.email,
      site: data.site.present ? data.site.value : this.site,
      cpfCnpj: data.cpfCnpj.present ? data.cpfCnpj.value : this.cpfCnpj,
      rgIe: data.rgIe.present ? data.rgIe.value : this.rgIe,
      matricula: data.matricula.present ? data.matricula.value : this.matricula,
      dataCadastro: data.dataCadastro.present
          ? data.dataCadastro.value
          : this.dataCadastro,
      dataAdmissao: data.dataAdmissao.present
          ? data.dataAdmissao.value
          : this.dataAdmissao,
      dataDemissao: data.dataDemissao.present
          ? data.dataDemissao.value
          : this.dataDemissao,
      ctpsNumero:
          data.ctpsNumero.present ? data.ctpsNumero.value : this.ctpsNumero,
      ctpsSerie: data.ctpsSerie.present ? data.ctpsSerie.value : this.ctpsSerie,
      ctpsDataExpedicao: data.ctpsDataExpedicao.present
          ? data.ctpsDataExpedicao.value
          : this.ctpsDataExpedicao,
      ctpsUf: data.ctpsUf.present ? data.ctpsUf.value : this.ctpsUf,
      observacao:
          data.observacao.present ? data.observacao.value : this.observacao,
      logradouro:
          data.logradouro.present ? data.logradouro.value : this.logradouro,
      numero: data.numero.present ? data.numero.value : this.numero,
      complemento:
          data.complemento.present ? data.complemento.value : this.complemento,
      bairro: data.bairro.present ? data.bairro.value : this.bairro,
      cidade: data.cidade.present ? data.cidade.value : this.cidade,
      cep: data.cep.present ? data.cep.value : this.cep,
      municipioIbge: data.municipioIbge.present
          ? data.municipioIbge.value
          : this.municipioIbge,
      uf: data.uf.present ? data.uf.value : this.uf,
      idPessoa: data.idPessoa.present ? data.idPessoa.value : this.idPessoa,
      idCargo: data.idCargo.present ? data.idCargo.value : this.idCargo,
      idSetor: data.idSetor.present ? data.idSetor.value : this.idSetor,
    );
  }

  @override
  String toString() {
    return (StringBuffer('ViewPessoaColaborador(')
          ..write('id: $id, ')
          ..write('nome: $nome, ')
          ..write('tipo: $tipo, ')
          ..write('email: $email, ')
          ..write('site: $site, ')
          ..write('cpfCnpj: $cpfCnpj, ')
          ..write('rgIe: $rgIe, ')
          ..write('matricula: $matricula, ')
          ..write('dataCadastro: $dataCadastro, ')
          ..write('dataAdmissao: $dataAdmissao, ')
          ..write('dataDemissao: $dataDemissao, ')
          ..write('ctpsNumero: $ctpsNumero, ')
          ..write('ctpsSerie: $ctpsSerie, ')
          ..write('ctpsDataExpedicao: $ctpsDataExpedicao, ')
          ..write('ctpsUf: $ctpsUf, ')
          ..write('observacao: $observacao, ')
          ..write('logradouro: $logradouro, ')
          ..write('numero: $numero, ')
          ..write('complemento: $complemento, ')
          ..write('bairro: $bairro, ')
          ..write('cidade: $cidade, ')
          ..write('cep: $cep, ')
          ..write('municipioIbge: $municipioIbge, ')
          ..write('uf: $uf, ')
          ..write('idPessoa: $idPessoa, ')
          ..write('idCargo: $idCargo, ')
          ..write('idSetor: $idSetor')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hashAll([
        id,
        nome,
        tipo,
        email,
        site,
        cpfCnpj,
        rgIe,
        matricula,
        dataCadastro,
        dataAdmissao,
        dataDemissao,
        ctpsNumero,
        ctpsSerie,
        ctpsDataExpedicao,
        ctpsUf,
        observacao,
        logradouro,
        numero,
        complemento,
        bairro,
        cidade,
        cep,
        municipioIbge,
        uf,
        idPessoa,
        idCargo,
        idSetor
      ]);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is ViewPessoaColaborador &&
          other.id == this.id &&
          other.nome == this.nome &&
          other.tipo == this.tipo &&
          other.email == this.email &&
          other.site == this.site &&
          other.cpfCnpj == this.cpfCnpj &&
          other.rgIe == this.rgIe &&
          other.matricula == this.matricula &&
          other.dataCadastro == this.dataCadastro &&
          other.dataAdmissao == this.dataAdmissao &&
          other.dataDemissao == this.dataDemissao &&
          other.ctpsNumero == this.ctpsNumero &&
          other.ctpsSerie == this.ctpsSerie &&
          other.ctpsDataExpedicao == this.ctpsDataExpedicao &&
          other.ctpsUf == this.ctpsUf &&
          other.observacao == this.observacao &&
          other.logradouro == this.logradouro &&
          other.numero == this.numero &&
          other.complemento == this.complemento &&
          other.bairro == this.bairro &&
          other.cidade == this.cidade &&
          other.cep == this.cep &&
          other.municipioIbge == this.municipioIbge &&
          other.uf == this.uf &&
          other.idPessoa == this.idPessoa &&
          other.idCargo == this.idCargo &&
          other.idSetor == this.idSetor);
}

class ViewPessoaColaboradorsCompanion
    extends UpdateCompanion<ViewPessoaColaborador> {
  final Value<int?> id;
  final Value<String?> nome;
  final Value<String?> tipo;
  final Value<String?> email;
  final Value<String?> site;
  final Value<String?> cpfCnpj;
  final Value<String?> rgIe;
  final Value<String?> matricula;
  final Value<DateTime?> dataCadastro;
  final Value<DateTime?> dataAdmissao;
  final Value<DateTime?> dataDemissao;
  final Value<String?> ctpsNumero;
  final Value<String?> ctpsSerie;
  final Value<DateTime?> ctpsDataExpedicao;
  final Value<String?> ctpsUf;
  final Value<String?> observacao;
  final Value<String?> logradouro;
  final Value<String?> numero;
  final Value<String?> complemento;
  final Value<String?> bairro;
  final Value<String?> cidade;
  final Value<String?> cep;
  final Value<String?> municipioIbge;
  final Value<String?> uf;
  final Value<int?> idPessoa;
  final Value<int?> idCargo;
  final Value<int?> idSetor;
  const ViewPessoaColaboradorsCompanion({
    this.id = const Value.absent(),
    this.nome = const Value.absent(),
    this.tipo = const Value.absent(),
    this.email = const Value.absent(),
    this.site = const Value.absent(),
    this.cpfCnpj = const Value.absent(),
    this.rgIe = const Value.absent(),
    this.matricula = const Value.absent(),
    this.dataCadastro = const Value.absent(),
    this.dataAdmissao = const Value.absent(),
    this.dataDemissao = const Value.absent(),
    this.ctpsNumero = const Value.absent(),
    this.ctpsSerie = const Value.absent(),
    this.ctpsDataExpedicao = const Value.absent(),
    this.ctpsUf = const Value.absent(),
    this.observacao = const Value.absent(),
    this.logradouro = const Value.absent(),
    this.numero = const Value.absent(),
    this.complemento = const Value.absent(),
    this.bairro = const Value.absent(),
    this.cidade = const Value.absent(),
    this.cep = const Value.absent(),
    this.municipioIbge = const Value.absent(),
    this.uf = const Value.absent(),
    this.idPessoa = const Value.absent(),
    this.idCargo = const Value.absent(),
    this.idSetor = const Value.absent(),
  });
  ViewPessoaColaboradorsCompanion.insert({
    this.id = const Value.absent(),
    this.nome = const Value.absent(),
    this.tipo = const Value.absent(),
    this.email = const Value.absent(),
    this.site = const Value.absent(),
    this.cpfCnpj = const Value.absent(),
    this.rgIe = const Value.absent(),
    this.matricula = const Value.absent(),
    this.dataCadastro = const Value.absent(),
    this.dataAdmissao = const Value.absent(),
    this.dataDemissao = const Value.absent(),
    this.ctpsNumero = const Value.absent(),
    this.ctpsSerie = const Value.absent(),
    this.ctpsDataExpedicao = const Value.absent(),
    this.ctpsUf = const Value.absent(),
    this.observacao = const Value.absent(),
    this.logradouro = const Value.absent(),
    this.numero = const Value.absent(),
    this.complemento = const Value.absent(),
    this.bairro = const Value.absent(),
    this.cidade = const Value.absent(),
    this.cep = const Value.absent(),
    this.municipioIbge = const Value.absent(),
    this.uf = const Value.absent(),
    this.idPessoa = const Value.absent(),
    this.idCargo = const Value.absent(),
    this.idSetor = const Value.absent(),
  });
  static Insertable<ViewPessoaColaborador> custom({
    Expression<int>? id,
    Expression<String>? nome,
    Expression<String>? tipo,
    Expression<String>? email,
    Expression<String>? site,
    Expression<String>? cpfCnpj,
    Expression<String>? rgIe,
    Expression<String>? matricula,
    Expression<DateTime>? dataCadastro,
    Expression<DateTime>? dataAdmissao,
    Expression<DateTime>? dataDemissao,
    Expression<String>? ctpsNumero,
    Expression<String>? ctpsSerie,
    Expression<DateTime>? ctpsDataExpedicao,
    Expression<String>? ctpsUf,
    Expression<String>? observacao,
    Expression<String>? logradouro,
    Expression<String>? numero,
    Expression<String>? complemento,
    Expression<String>? bairro,
    Expression<String>? cidade,
    Expression<String>? cep,
    Expression<String>? municipioIbge,
    Expression<String>? uf,
    Expression<int>? idPessoa,
    Expression<int>? idCargo,
    Expression<int>? idSetor,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (nome != null) 'nome': nome,
      if (tipo != null) 'tipo': tipo,
      if (email != null) 'email': email,
      if (site != null) 'site': site,
      if (cpfCnpj != null) 'cpf_cnpj': cpfCnpj,
      if (rgIe != null) 'rg_ie': rgIe,
      if (matricula != null) 'matricula': matricula,
      if (dataCadastro != null) 'data_cadastro': dataCadastro,
      if (dataAdmissao != null) 'data_admissao': dataAdmissao,
      if (dataDemissao != null) 'data_demissao': dataDemissao,
      if (ctpsNumero != null) 'ctps_numero': ctpsNumero,
      if (ctpsSerie != null) 'ctps_serie': ctpsSerie,
      if (ctpsDataExpedicao != null) 'ctps_data_expedicao': ctpsDataExpedicao,
      if (ctpsUf != null) 'ctps_uf': ctpsUf,
      if (observacao != null) 'observacao': observacao,
      if (logradouro != null) 'logradouro': logradouro,
      if (numero != null) 'numero': numero,
      if (complemento != null) 'complemento': complemento,
      if (bairro != null) 'bairro': bairro,
      if (cidade != null) 'cidade': cidade,
      if (cep != null) 'cep': cep,
      if (municipioIbge != null) 'municipio_ibge': municipioIbge,
      if (uf != null) 'uf': uf,
      if (idPessoa != null) 'id_pessoa': idPessoa,
      if (idCargo != null) 'id_cargo': idCargo,
      if (idSetor != null) 'id_setor': idSetor,
    });
  }

  ViewPessoaColaboradorsCompanion copyWith(
      {Value<int?>? id,
      Value<String?>? nome,
      Value<String?>? tipo,
      Value<String?>? email,
      Value<String?>? site,
      Value<String?>? cpfCnpj,
      Value<String?>? rgIe,
      Value<String?>? matricula,
      Value<DateTime?>? dataCadastro,
      Value<DateTime?>? dataAdmissao,
      Value<DateTime?>? dataDemissao,
      Value<String?>? ctpsNumero,
      Value<String?>? ctpsSerie,
      Value<DateTime?>? ctpsDataExpedicao,
      Value<String?>? ctpsUf,
      Value<String?>? observacao,
      Value<String?>? logradouro,
      Value<String?>? numero,
      Value<String?>? complemento,
      Value<String?>? bairro,
      Value<String?>? cidade,
      Value<String?>? cep,
      Value<String?>? municipioIbge,
      Value<String?>? uf,
      Value<int?>? idPessoa,
      Value<int?>? idCargo,
      Value<int?>? idSetor}) {
    return ViewPessoaColaboradorsCompanion(
      id: id ?? this.id,
      nome: nome ?? this.nome,
      tipo: tipo ?? this.tipo,
      email: email ?? this.email,
      site: site ?? this.site,
      cpfCnpj: cpfCnpj ?? this.cpfCnpj,
      rgIe: rgIe ?? this.rgIe,
      matricula: matricula ?? this.matricula,
      dataCadastro: dataCadastro ?? this.dataCadastro,
      dataAdmissao: dataAdmissao ?? this.dataAdmissao,
      dataDemissao: dataDemissao ?? this.dataDemissao,
      ctpsNumero: ctpsNumero ?? this.ctpsNumero,
      ctpsSerie: ctpsSerie ?? this.ctpsSerie,
      ctpsDataExpedicao: ctpsDataExpedicao ?? this.ctpsDataExpedicao,
      ctpsUf: ctpsUf ?? this.ctpsUf,
      observacao: observacao ?? this.observacao,
      logradouro: logradouro ?? this.logradouro,
      numero: numero ?? this.numero,
      complemento: complemento ?? this.complemento,
      bairro: bairro ?? this.bairro,
      cidade: cidade ?? this.cidade,
      cep: cep ?? this.cep,
      municipioIbge: municipioIbge ?? this.municipioIbge,
      uf: uf ?? this.uf,
      idPessoa: idPessoa ?? this.idPessoa,
      idCargo: idCargo ?? this.idCargo,
      idSetor: idSetor ?? this.idSetor,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (nome.present) {
      map['nome'] = Variable<String>(nome.value);
    }
    if (tipo.present) {
      map['tipo'] = Variable<String>(tipo.value);
    }
    if (email.present) {
      map['email'] = Variable<String>(email.value);
    }
    if (site.present) {
      map['site'] = Variable<String>(site.value);
    }
    if (cpfCnpj.present) {
      map['cpf_cnpj'] = Variable<String>(cpfCnpj.value);
    }
    if (rgIe.present) {
      map['rg_ie'] = Variable<String>(rgIe.value);
    }
    if (matricula.present) {
      map['matricula'] = Variable<String>(matricula.value);
    }
    if (dataCadastro.present) {
      map['data_cadastro'] = Variable<DateTime>(dataCadastro.value);
    }
    if (dataAdmissao.present) {
      map['data_admissao'] = Variable<DateTime>(dataAdmissao.value);
    }
    if (dataDemissao.present) {
      map['data_demissao'] = Variable<DateTime>(dataDemissao.value);
    }
    if (ctpsNumero.present) {
      map['ctps_numero'] = Variable<String>(ctpsNumero.value);
    }
    if (ctpsSerie.present) {
      map['ctps_serie'] = Variable<String>(ctpsSerie.value);
    }
    if (ctpsDataExpedicao.present) {
      map['ctps_data_expedicao'] = Variable<DateTime>(ctpsDataExpedicao.value);
    }
    if (ctpsUf.present) {
      map['ctps_uf'] = Variable<String>(ctpsUf.value);
    }
    if (observacao.present) {
      map['observacao'] = Variable<String>(observacao.value);
    }
    if (logradouro.present) {
      map['logradouro'] = Variable<String>(logradouro.value);
    }
    if (numero.present) {
      map['numero'] = Variable<String>(numero.value);
    }
    if (complemento.present) {
      map['complemento'] = Variable<String>(complemento.value);
    }
    if (bairro.present) {
      map['bairro'] = Variable<String>(bairro.value);
    }
    if (cidade.present) {
      map['cidade'] = Variable<String>(cidade.value);
    }
    if (cep.present) {
      map['cep'] = Variable<String>(cep.value);
    }
    if (municipioIbge.present) {
      map['municipio_ibge'] = Variable<String>(municipioIbge.value);
    }
    if (uf.present) {
      map['uf'] = Variable<String>(uf.value);
    }
    if (idPessoa.present) {
      map['id_pessoa'] = Variable<int>(idPessoa.value);
    }
    if (idCargo.present) {
      map['id_cargo'] = Variable<int>(idCargo.value);
    }
    if (idSetor.present) {
      map['id_setor'] = Variable<int>(idSetor.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('ViewPessoaColaboradorsCompanion(')
          ..write('id: $id, ')
          ..write('nome: $nome, ')
          ..write('tipo: $tipo, ')
          ..write('email: $email, ')
          ..write('site: $site, ')
          ..write('cpfCnpj: $cpfCnpj, ')
          ..write('rgIe: $rgIe, ')
          ..write('matricula: $matricula, ')
          ..write('dataCadastro: $dataCadastro, ')
          ..write('dataAdmissao: $dataAdmissao, ')
          ..write('dataDemissao: $dataDemissao, ')
          ..write('ctpsNumero: $ctpsNumero, ')
          ..write('ctpsSerie: $ctpsSerie, ')
          ..write('ctpsDataExpedicao: $ctpsDataExpedicao, ')
          ..write('ctpsUf: $ctpsUf, ')
          ..write('observacao: $observacao, ')
          ..write('logradouro: $logradouro, ')
          ..write('numero: $numero, ')
          ..write('complemento: $complemento, ')
          ..write('bairro: $bairro, ')
          ..write('cidade: $cidade, ')
          ..write('cep: $cep, ')
          ..write('municipioIbge: $municipioIbge, ')
          ..write('uf: $uf, ')
          ..write('idPessoa: $idPessoa, ')
          ..write('idCargo: $idCargo, ')
          ..write('idSetor: $idSetor')
          ..write(')'))
        .toString();
  }
}

abstract class _$AppDatabase extends GeneratedDatabase {
  _$AppDatabase(QueryExecutor e) : super(e);
  $AppDatabaseManager get managers => $AppDatabaseManager(this);
  late final $FrotaIpvaControlesTable frotaIpvaControles =
      $FrotaIpvaControlesTable(this);
  late final $FrotaDpvatControlesTable frotaDpvatControles =
      $FrotaDpvatControlesTable(this);
  late final $FrotaVeiculoSinistrosTable frotaVeiculoSinistros =
      $FrotaVeiculoSinistrosTable(this);
  late final $FrotaVeiculoMovimentacaosTable frotaVeiculoMovimentacaos =
      $FrotaVeiculoMovimentacaosTable(this);
  late final $FrotaVeiculoPneusTable frotaVeiculoPneus =
      $FrotaVeiculoPneusTable(this);
  late final $FrotaVeiculoManutencaosTable frotaVeiculoManutencaos =
      $FrotaVeiculoManutencaosTable(this);
  late final $FrotaMultaControlesTable frotaMultaControles =
      $FrotaMultaControlesTable(this);
  late final $FrotaCombustivelControlesTable frotaCombustivelControles =
      $FrotaCombustivelControlesTable(this);
  late final $FrotaVeiculosTable frotaVeiculos = $FrotaVeiculosTable(this);
  late final $FrotaVeiculoTiposTable frotaVeiculoTipos =
      $FrotaVeiculoTiposTable(this);
  late final $FrotaCombustivelTiposTable frotaCombustivelTipos =
      $FrotaCombustivelTiposTable(this);
  late final $FrotaMotoristasTable frotaMotoristas =
      $FrotaMotoristasTable(this);
  late final $ViewControleAcessosTable viewControleAcessos =
      $ViewControleAcessosTable(this);
  late final $ViewPessoaUsuariosTable viewPessoaUsuarios =
      $ViewPessoaUsuariosTable(this);
  late final $ViewPessoaColaboradorsTable viewPessoaColaboradors =
      $ViewPessoaColaboradorsTable(this);
  late final FrotaVeiculoDao frotaVeiculoDao =
      FrotaVeiculoDao(this as AppDatabase);
  late final FrotaVeiculoTipoDao frotaVeiculoTipoDao =
      FrotaVeiculoTipoDao(this as AppDatabase);
  late final FrotaCombustivelTipoDao frotaCombustivelTipoDao =
      FrotaCombustivelTipoDao(this as AppDatabase);
  late final FrotaMotoristaDao frotaMotoristaDao =
      FrotaMotoristaDao(this as AppDatabase);
  late final ViewControleAcessoDao viewControleAcessoDao =
      ViewControleAcessoDao(this as AppDatabase);
  late final ViewPessoaUsuarioDao viewPessoaUsuarioDao =
      ViewPessoaUsuarioDao(this as AppDatabase);
  late final ViewPessoaColaboradorDao viewPessoaColaboradorDao =
      ViewPessoaColaboradorDao(this as AppDatabase);
  @override
  Iterable<TableInfo<Table, Object?>> get allTables =>
      allSchemaEntities.whereType<TableInfo<Table, Object?>>();
  @override
  List<DatabaseSchemaEntity> get allSchemaEntities => [
        frotaIpvaControles,
        frotaDpvatControles,
        frotaVeiculoSinistros,
        frotaVeiculoMovimentacaos,
        frotaVeiculoPneus,
        frotaVeiculoManutencaos,
        frotaMultaControles,
        frotaCombustivelControles,
        frotaVeiculos,
        frotaVeiculoTipos,
        frotaCombustivelTipos,
        frotaMotoristas,
        viewControleAcessos,
        viewPessoaUsuarios,
        viewPessoaColaboradors
      ];
}

typedef $$FrotaIpvaControlesTableCreateCompanionBuilder
    = FrotaIpvaControlesCompanion Function({
  Value<int?> id,
  Value<int?> idFrotaVeiculo,
  Value<String?> ano,
  Value<String?> parcela,
  Value<DateTime?> dataVencimento,
  Value<DateTime?> dataPagamento,
  Value<double?> valor,
});
typedef $$FrotaIpvaControlesTableUpdateCompanionBuilder
    = FrotaIpvaControlesCompanion Function({
  Value<int?> id,
  Value<int?> idFrotaVeiculo,
  Value<String?> ano,
  Value<String?> parcela,
  Value<DateTime?> dataVencimento,
  Value<DateTime?> dataPagamento,
  Value<double?> valor,
});

class $$FrotaIpvaControlesTableTableManager extends RootTableManager<
    _$AppDatabase,
    $FrotaIpvaControlesTable,
    FrotaIpvaControle,
    $$FrotaIpvaControlesTableFilterComposer,
    $$FrotaIpvaControlesTableOrderingComposer,
    $$FrotaIpvaControlesTableCreateCompanionBuilder,
    $$FrotaIpvaControlesTableUpdateCompanionBuilder> {
  $$FrotaIpvaControlesTableTableManager(
      _$AppDatabase db, $FrotaIpvaControlesTable table)
      : super(TableManagerState(
          db: db,
          table: table,
          filteringComposer:
              $$FrotaIpvaControlesTableFilterComposer(ComposerState(db, table)),
          orderingComposer: $$FrotaIpvaControlesTableOrderingComposer(
              ComposerState(db, table)),
          updateCompanionCallback: ({
            Value<int?> id = const Value.absent(),
            Value<int?> idFrotaVeiculo = const Value.absent(),
            Value<String?> ano = const Value.absent(),
            Value<String?> parcela = const Value.absent(),
            Value<DateTime?> dataVencimento = const Value.absent(),
            Value<DateTime?> dataPagamento = const Value.absent(),
            Value<double?> valor = const Value.absent(),
          }) =>
              FrotaIpvaControlesCompanion(
            id: id,
            idFrotaVeiculo: idFrotaVeiculo,
            ano: ano,
            parcela: parcela,
            dataVencimento: dataVencimento,
            dataPagamento: dataPagamento,
            valor: valor,
          ),
          createCompanionCallback: ({
            Value<int?> id = const Value.absent(),
            Value<int?> idFrotaVeiculo = const Value.absent(),
            Value<String?> ano = const Value.absent(),
            Value<String?> parcela = const Value.absent(),
            Value<DateTime?> dataVencimento = const Value.absent(),
            Value<DateTime?> dataPagamento = const Value.absent(),
            Value<double?> valor = const Value.absent(),
          }) =>
              FrotaIpvaControlesCompanion.insert(
            id: id,
            idFrotaVeiculo: idFrotaVeiculo,
            ano: ano,
            parcela: parcela,
            dataVencimento: dataVencimento,
            dataPagamento: dataPagamento,
            valor: valor,
          ),
        ));
}

class $$FrotaIpvaControlesTableFilterComposer
    extends FilterComposer<_$AppDatabase, $FrotaIpvaControlesTable> {
  $$FrotaIpvaControlesTableFilterComposer(super.$state);
  ColumnFilters<int> get id => $state.composableBuilder(
      column: $state.table.id,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<int> get idFrotaVeiculo => $state.composableBuilder(
      column: $state.table.idFrotaVeiculo,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get ano => $state.composableBuilder(
      column: $state.table.ano,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get parcela => $state.composableBuilder(
      column: $state.table.parcela,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<DateTime> get dataVencimento => $state.composableBuilder(
      column: $state.table.dataVencimento,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<DateTime> get dataPagamento => $state.composableBuilder(
      column: $state.table.dataPagamento,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<double> get valor => $state.composableBuilder(
      column: $state.table.valor,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));
}

class $$FrotaIpvaControlesTableOrderingComposer
    extends OrderingComposer<_$AppDatabase, $FrotaIpvaControlesTable> {
  $$FrotaIpvaControlesTableOrderingComposer(super.$state);
  ColumnOrderings<int> get id => $state.composableBuilder(
      column: $state.table.id,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<int> get idFrotaVeiculo => $state.composableBuilder(
      column: $state.table.idFrotaVeiculo,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get ano => $state.composableBuilder(
      column: $state.table.ano,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get parcela => $state.composableBuilder(
      column: $state.table.parcela,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<DateTime> get dataVencimento => $state.composableBuilder(
      column: $state.table.dataVencimento,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<DateTime> get dataPagamento => $state.composableBuilder(
      column: $state.table.dataPagamento,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<double> get valor => $state.composableBuilder(
      column: $state.table.valor,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));
}

typedef $$FrotaDpvatControlesTableCreateCompanionBuilder
    = FrotaDpvatControlesCompanion Function({
  Value<int?> id,
  Value<int?> idFrotaVeiculo,
  Value<String?> ano,
  Value<String?> parcela,
  Value<DateTime?> dataVencimento,
  Value<DateTime?> dataPagamento,
  Value<double?> valor,
});
typedef $$FrotaDpvatControlesTableUpdateCompanionBuilder
    = FrotaDpvatControlesCompanion Function({
  Value<int?> id,
  Value<int?> idFrotaVeiculo,
  Value<String?> ano,
  Value<String?> parcela,
  Value<DateTime?> dataVencimento,
  Value<DateTime?> dataPagamento,
  Value<double?> valor,
});

class $$FrotaDpvatControlesTableTableManager extends RootTableManager<
    _$AppDatabase,
    $FrotaDpvatControlesTable,
    FrotaDpvatControle,
    $$FrotaDpvatControlesTableFilterComposer,
    $$FrotaDpvatControlesTableOrderingComposer,
    $$FrotaDpvatControlesTableCreateCompanionBuilder,
    $$FrotaDpvatControlesTableUpdateCompanionBuilder> {
  $$FrotaDpvatControlesTableTableManager(
      _$AppDatabase db, $FrotaDpvatControlesTable table)
      : super(TableManagerState(
          db: db,
          table: table,
          filteringComposer: $$FrotaDpvatControlesTableFilterComposer(
              ComposerState(db, table)),
          orderingComposer: $$FrotaDpvatControlesTableOrderingComposer(
              ComposerState(db, table)),
          updateCompanionCallback: ({
            Value<int?> id = const Value.absent(),
            Value<int?> idFrotaVeiculo = const Value.absent(),
            Value<String?> ano = const Value.absent(),
            Value<String?> parcela = const Value.absent(),
            Value<DateTime?> dataVencimento = const Value.absent(),
            Value<DateTime?> dataPagamento = const Value.absent(),
            Value<double?> valor = const Value.absent(),
          }) =>
              FrotaDpvatControlesCompanion(
            id: id,
            idFrotaVeiculo: idFrotaVeiculo,
            ano: ano,
            parcela: parcela,
            dataVencimento: dataVencimento,
            dataPagamento: dataPagamento,
            valor: valor,
          ),
          createCompanionCallback: ({
            Value<int?> id = const Value.absent(),
            Value<int?> idFrotaVeiculo = const Value.absent(),
            Value<String?> ano = const Value.absent(),
            Value<String?> parcela = const Value.absent(),
            Value<DateTime?> dataVencimento = const Value.absent(),
            Value<DateTime?> dataPagamento = const Value.absent(),
            Value<double?> valor = const Value.absent(),
          }) =>
              FrotaDpvatControlesCompanion.insert(
            id: id,
            idFrotaVeiculo: idFrotaVeiculo,
            ano: ano,
            parcela: parcela,
            dataVencimento: dataVencimento,
            dataPagamento: dataPagamento,
            valor: valor,
          ),
        ));
}

class $$FrotaDpvatControlesTableFilterComposer
    extends FilterComposer<_$AppDatabase, $FrotaDpvatControlesTable> {
  $$FrotaDpvatControlesTableFilterComposer(super.$state);
  ColumnFilters<int> get id => $state.composableBuilder(
      column: $state.table.id,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<int> get idFrotaVeiculo => $state.composableBuilder(
      column: $state.table.idFrotaVeiculo,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get ano => $state.composableBuilder(
      column: $state.table.ano,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get parcela => $state.composableBuilder(
      column: $state.table.parcela,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<DateTime> get dataVencimento => $state.composableBuilder(
      column: $state.table.dataVencimento,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<DateTime> get dataPagamento => $state.composableBuilder(
      column: $state.table.dataPagamento,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<double> get valor => $state.composableBuilder(
      column: $state.table.valor,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));
}

class $$FrotaDpvatControlesTableOrderingComposer
    extends OrderingComposer<_$AppDatabase, $FrotaDpvatControlesTable> {
  $$FrotaDpvatControlesTableOrderingComposer(super.$state);
  ColumnOrderings<int> get id => $state.composableBuilder(
      column: $state.table.id,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<int> get idFrotaVeiculo => $state.composableBuilder(
      column: $state.table.idFrotaVeiculo,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get ano => $state.composableBuilder(
      column: $state.table.ano,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get parcela => $state.composableBuilder(
      column: $state.table.parcela,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<DateTime> get dataVencimento => $state.composableBuilder(
      column: $state.table.dataVencimento,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<DateTime> get dataPagamento => $state.composableBuilder(
      column: $state.table.dataPagamento,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<double> get valor => $state.composableBuilder(
      column: $state.table.valor,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));
}

typedef $$FrotaVeiculoSinistrosTableCreateCompanionBuilder
    = FrotaVeiculoSinistrosCompanion Function({
  Value<int?> id,
  Value<int?> idFrotaVeiculo,
  Value<DateTime?> dataSinistro,
  Value<String?> observacao,
});
typedef $$FrotaVeiculoSinistrosTableUpdateCompanionBuilder
    = FrotaVeiculoSinistrosCompanion Function({
  Value<int?> id,
  Value<int?> idFrotaVeiculo,
  Value<DateTime?> dataSinistro,
  Value<String?> observacao,
});

class $$FrotaVeiculoSinistrosTableTableManager extends RootTableManager<
    _$AppDatabase,
    $FrotaVeiculoSinistrosTable,
    FrotaVeiculoSinistro,
    $$FrotaVeiculoSinistrosTableFilterComposer,
    $$FrotaVeiculoSinistrosTableOrderingComposer,
    $$FrotaVeiculoSinistrosTableCreateCompanionBuilder,
    $$FrotaVeiculoSinistrosTableUpdateCompanionBuilder> {
  $$FrotaVeiculoSinistrosTableTableManager(
      _$AppDatabase db, $FrotaVeiculoSinistrosTable table)
      : super(TableManagerState(
          db: db,
          table: table,
          filteringComposer: $$FrotaVeiculoSinistrosTableFilterComposer(
              ComposerState(db, table)),
          orderingComposer: $$FrotaVeiculoSinistrosTableOrderingComposer(
              ComposerState(db, table)),
          updateCompanionCallback: ({
            Value<int?> id = const Value.absent(),
            Value<int?> idFrotaVeiculo = const Value.absent(),
            Value<DateTime?> dataSinistro = const Value.absent(),
            Value<String?> observacao = const Value.absent(),
          }) =>
              FrotaVeiculoSinistrosCompanion(
            id: id,
            idFrotaVeiculo: idFrotaVeiculo,
            dataSinistro: dataSinistro,
            observacao: observacao,
          ),
          createCompanionCallback: ({
            Value<int?> id = const Value.absent(),
            Value<int?> idFrotaVeiculo = const Value.absent(),
            Value<DateTime?> dataSinistro = const Value.absent(),
            Value<String?> observacao = const Value.absent(),
          }) =>
              FrotaVeiculoSinistrosCompanion.insert(
            id: id,
            idFrotaVeiculo: idFrotaVeiculo,
            dataSinistro: dataSinistro,
            observacao: observacao,
          ),
        ));
}

class $$FrotaVeiculoSinistrosTableFilterComposer
    extends FilterComposer<_$AppDatabase, $FrotaVeiculoSinistrosTable> {
  $$FrotaVeiculoSinistrosTableFilterComposer(super.$state);
  ColumnFilters<int> get id => $state.composableBuilder(
      column: $state.table.id,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<int> get idFrotaVeiculo => $state.composableBuilder(
      column: $state.table.idFrotaVeiculo,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<DateTime> get dataSinistro => $state.composableBuilder(
      column: $state.table.dataSinistro,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get observacao => $state.composableBuilder(
      column: $state.table.observacao,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));
}

class $$FrotaVeiculoSinistrosTableOrderingComposer
    extends OrderingComposer<_$AppDatabase, $FrotaVeiculoSinistrosTable> {
  $$FrotaVeiculoSinistrosTableOrderingComposer(super.$state);
  ColumnOrderings<int> get id => $state.composableBuilder(
      column: $state.table.id,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<int> get idFrotaVeiculo => $state.composableBuilder(
      column: $state.table.idFrotaVeiculo,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<DateTime> get dataSinistro => $state.composableBuilder(
      column: $state.table.dataSinistro,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get observacao => $state.composableBuilder(
      column: $state.table.observacao,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));
}

typedef $$FrotaVeiculoMovimentacaosTableCreateCompanionBuilder
    = FrotaVeiculoMovimentacaosCompanion Function({
  Value<int?> id,
  Value<int?> idFrotaVeiculo,
  Value<int?> idFrotaMotorista,
  Value<DateTime?> dataSaida,
  Value<String?> horaSaida,
  Value<DateTime?> dataEntrada,
  Value<String?> horaEntrada,
  Value<String?> observacao,
});
typedef $$FrotaVeiculoMovimentacaosTableUpdateCompanionBuilder
    = FrotaVeiculoMovimentacaosCompanion Function({
  Value<int?> id,
  Value<int?> idFrotaVeiculo,
  Value<int?> idFrotaMotorista,
  Value<DateTime?> dataSaida,
  Value<String?> horaSaida,
  Value<DateTime?> dataEntrada,
  Value<String?> horaEntrada,
  Value<String?> observacao,
});

class $$FrotaVeiculoMovimentacaosTableTableManager extends RootTableManager<
    _$AppDatabase,
    $FrotaVeiculoMovimentacaosTable,
    FrotaVeiculoMovimentacao,
    $$FrotaVeiculoMovimentacaosTableFilterComposer,
    $$FrotaVeiculoMovimentacaosTableOrderingComposer,
    $$FrotaVeiculoMovimentacaosTableCreateCompanionBuilder,
    $$FrotaVeiculoMovimentacaosTableUpdateCompanionBuilder> {
  $$FrotaVeiculoMovimentacaosTableTableManager(
      _$AppDatabase db, $FrotaVeiculoMovimentacaosTable table)
      : super(TableManagerState(
          db: db,
          table: table,
          filteringComposer: $$FrotaVeiculoMovimentacaosTableFilterComposer(
              ComposerState(db, table)),
          orderingComposer: $$FrotaVeiculoMovimentacaosTableOrderingComposer(
              ComposerState(db, table)),
          updateCompanionCallback: ({
            Value<int?> id = const Value.absent(),
            Value<int?> idFrotaVeiculo = const Value.absent(),
            Value<int?> idFrotaMotorista = const Value.absent(),
            Value<DateTime?> dataSaida = const Value.absent(),
            Value<String?> horaSaida = const Value.absent(),
            Value<DateTime?> dataEntrada = const Value.absent(),
            Value<String?> horaEntrada = const Value.absent(),
            Value<String?> observacao = const Value.absent(),
          }) =>
              FrotaVeiculoMovimentacaosCompanion(
            id: id,
            idFrotaVeiculo: idFrotaVeiculo,
            idFrotaMotorista: idFrotaMotorista,
            dataSaida: dataSaida,
            horaSaida: horaSaida,
            dataEntrada: dataEntrada,
            horaEntrada: horaEntrada,
            observacao: observacao,
          ),
          createCompanionCallback: ({
            Value<int?> id = const Value.absent(),
            Value<int?> idFrotaVeiculo = const Value.absent(),
            Value<int?> idFrotaMotorista = const Value.absent(),
            Value<DateTime?> dataSaida = const Value.absent(),
            Value<String?> horaSaida = const Value.absent(),
            Value<DateTime?> dataEntrada = const Value.absent(),
            Value<String?> horaEntrada = const Value.absent(),
            Value<String?> observacao = const Value.absent(),
          }) =>
              FrotaVeiculoMovimentacaosCompanion.insert(
            id: id,
            idFrotaVeiculo: idFrotaVeiculo,
            idFrotaMotorista: idFrotaMotorista,
            dataSaida: dataSaida,
            horaSaida: horaSaida,
            dataEntrada: dataEntrada,
            horaEntrada: horaEntrada,
            observacao: observacao,
          ),
        ));
}

class $$FrotaVeiculoMovimentacaosTableFilterComposer
    extends FilterComposer<_$AppDatabase, $FrotaVeiculoMovimentacaosTable> {
  $$FrotaVeiculoMovimentacaosTableFilterComposer(super.$state);
  ColumnFilters<int> get id => $state.composableBuilder(
      column: $state.table.id,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<int> get idFrotaVeiculo => $state.composableBuilder(
      column: $state.table.idFrotaVeiculo,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<int> get idFrotaMotorista => $state.composableBuilder(
      column: $state.table.idFrotaMotorista,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<DateTime> get dataSaida => $state.composableBuilder(
      column: $state.table.dataSaida,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get horaSaida => $state.composableBuilder(
      column: $state.table.horaSaida,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<DateTime> get dataEntrada => $state.composableBuilder(
      column: $state.table.dataEntrada,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get horaEntrada => $state.composableBuilder(
      column: $state.table.horaEntrada,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get observacao => $state.composableBuilder(
      column: $state.table.observacao,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));
}

class $$FrotaVeiculoMovimentacaosTableOrderingComposer
    extends OrderingComposer<_$AppDatabase, $FrotaVeiculoMovimentacaosTable> {
  $$FrotaVeiculoMovimentacaosTableOrderingComposer(super.$state);
  ColumnOrderings<int> get id => $state.composableBuilder(
      column: $state.table.id,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<int> get idFrotaVeiculo => $state.composableBuilder(
      column: $state.table.idFrotaVeiculo,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<int> get idFrotaMotorista => $state.composableBuilder(
      column: $state.table.idFrotaMotorista,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<DateTime> get dataSaida => $state.composableBuilder(
      column: $state.table.dataSaida,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get horaSaida => $state.composableBuilder(
      column: $state.table.horaSaida,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<DateTime> get dataEntrada => $state.composableBuilder(
      column: $state.table.dataEntrada,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get horaEntrada => $state.composableBuilder(
      column: $state.table.horaEntrada,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get observacao => $state.composableBuilder(
      column: $state.table.observacao,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));
}

typedef $$FrotaVeiculoPneusTableCreateCompanionBuilder
    = FrotaVeiculoPneusCompanion Function({
  Value<int?> id,
  Value<int?> idFrotaVeiculo,
  Value<DateTime?> dataTroca,
  Value<double?> valorTroca,
  Value<String?> posicaoPneu,
  Value<String?> marcaPneu,
});
typedef $$FrotaVeiculoPneusTableUpdateCompanionBuilder
    = FrotaVeiculoPneusCompanion Function({
  Value<int?> id,
  Value<int?> idFrotaVeiculo,
  Value<DateTime?> dataTroca,
  Value<double?> valorTroca,
  Value<String?> posicaoPneu,
  Value<String?> marcaPneu,
});

class $$FrotaVeiculoPneusTableTableManager extends RootTableManager<
    _$AppDatabase,
    $FrotaVeiculoPneusTable,
    FrotaVeiculoPneu,
    $$FrotaVeiculoPneusTableFilterComposer,
    $$FrotaVeiculoPneusTableOrderingComposer,
    $$FrotaVeiculoPneusTableCreateCompanionBuilder,
    $$FrotaVeiculoPneusTableUpdateCompanionBuilder> {
  $$FrotaVeiculoPneusTableTableManager(
      _$AppDatabase db, $FrotaVeiculoPneusTable table)
      : super(TableManagerState(
          db: db,
          table: table,
          filteringComposer:
              $$FrotaVeiculoPneusTableFilterComposer(ComposerState(db, table)),
          orderingComposer: $$FrotaVeiculoPneusTableOrderingComposer(
              ComposerState(db, table)),
          updateCompanionCallback: ({
            Value<int?> id = const Value.absent(),
            Value<int?> idFrotaVeiculo = const Value.absent(),
            Value<DateTime?> dataTroca = const Value.absent(),
            Value<double?> valorTroca = const Value.absent(),
            Value<String?> posicaoPneu = const Value.absent(),
            Value<String?> marcaPneu = const Value.absent(),
          }) =>
              FrotaVeiculoPneusCompanion(
            id: id,
            idFrotaVeiculo: idFrotaVeiculo,
            dataTroca: dataTroca,
            valorTroca: valorTroca,
            posicaoPneu: posicaoPneu,
            marcaPneu: marcaPneu,
          ),
          createCompanionCallback: ({
            Value<int?> id = const Value.absent(),
            Value<int?> idFrotaVeiculo = const Value.absent(),
            Value<DateTime?> dataTroca = const Value.absent(),
            Value<double?> valorTroca = const Value.absent(),
            Value<String?> posicaoPneu = const Value.absent(),
            Value<String?> marcaPneu = const Value.absent(),
          }) =>
              FrotaVeiculoPneusCompanion.insert(
            id: id,
            idFrotaVeiculo: idFrotaVeiculo,
            dataTroca: dataTroca,
            valorTroca: valorTroca,
            posicaoPneu: posicaoPneu,
            marcaPneu: marcaPneu,
          ),
        ));
}

class $$FrotaVeiculoPneusTableFilterComposer
    extends FilterComposer<_$AppDatabase, $FrotaVeiculoPneusTable> {
  $$FrotaVeiculoPneusTableFilterComposer(super.$state);
  ColumnFilters<int> get id => $state.composableBuilder(
      column: $state.table.id,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<int> get idFrotaVeiculo => $state.composableBuilder(
      column: $state.table.idFrotaVeiculo,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<DateTime> get dataTroca => $state.composableBuilder(
      column: $state.table.dataTroca,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<double> get valorTroca => $state.composableBuilder(
      column: $state.table.valorTroca,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get posicaoPneu => $state.composableBuilder(
      column: $state.table.posicaoPneu,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get marcaPneu => $state.composableBuilder(
      column: $state.table.marcaPneu,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));
}

class $$FrotaVeiculoPneusTableOrderingComposer
    extends OrderingComposer<_$AppDatabase, $FrotaVeiculoPneusTable> {
  $$FrotaVeiculoPneusTableOrderingComposer(super.$state);
  ColumnOrderings<int> get id => $state.composableBuilder(
      column: $state.table.id,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<int> get idFrotaVeiculo => $state.composableBuilder(
      column: $state.table.idFrotaVeiculo,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<DateTime> get dataTroca => $state.composableBuilder(
      column: $state.table.dataTroca,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<double> get valorTroca => $state.composableBuilder(
      column: $state.table.valorTroca,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get posicaoPneu => $state.composableBuilder(
      column: $state.table.posicaoPneu,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get marcaPneu => $state.composableBuilder(
      column: $state.table.marcaPneu,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));
}

typedef $$FrotaVeiculoManutencaosTableCreateCompanionBuilder
    = FrotaVeiculoManutencaosCompanion Function({
  Value<int?> id,
  Value<int?> idFrotaVeiculo,
  Value<String?> tipo,
  Value<DateTime?> dataManutencao,
  Value<double?> valorManutencao,
  Value<String?> observacao,
});
typedef $$FrotaVeiculoManutencaosTableUpdateCompanionBuilder
    = FrotaVeiculoManutencaosCompanion Function({
  Value<int?> id,
  Value<int?> idFrotaVeiculo,
  Value<String?> tipo,
  Value<DateTime?> dataManutencao,
  Value<double?> valorManutencao,
  Value<String?> observacao,
});

class $$FrotaVeiculoManutencaosTableTableManager extends RootTableManager<
    _$AppDatabase,
    $FrotaVeiculoManutencaosTable,
    FrotaVeiculoManutencao,
    $$FrotaVeiculoManutencaosTableFilterComposer,
    $$FrotaVeiculoManutencaosTableOrderingComposer,
    $$FrotaVeiculoManutencaosTableCreateCompanionBuilder,
    $$FrotaVeiculoManutencaosTableUpdateCompanionBuilder> {
  $$FrotaVeiculoManutencaosTableTableManager(
      _$AppDatabase db, $FrotaVeiculoManutencaosTable table)
      : super(TableManagerState(
          db: db,
          table: table,
          filteringComposer: $$FrotaVeiculoManutencaosTableFilterComposer(
              ComposerState(db, table)),
          orderingComposer: $$FrotaVeiculoManutencaosTableOrderingComposer(
              ComposerState(db, table)),
          updateCompanionCallback: ({
            Value<int?> id = const Value.absent(),
            Value<int?> idFrotaVeiculo = const Value.absent(),
            Value<String?> tipo = const Value.absent(),
            Value<DateTime?> dataManutencao = const Value.absent(),
            Value<double?> valorManutencao = const Value.absent(),
            Value<String?> observacao = const Value.absent(),
          }) =>
              FrotaVeiculoManutencaosCompanion(
            id: id,
            idFrotaVeiculo: idFrotaVeiculo,
            tipo: tipo,
            dataManutencao: dataManutencao,
            valorManutencao: valorManutencao,
            observacao: observacao,
          ),
          createCompanionCallback: ({
            Value<int?> id = const Value.absent(),
            Value<int?> idFrotaVeiculo = const Value.absent(),
            Value<String?> tipo = const Value.absent(),
            Value<DateTime?> dataManutencao = const Value.absent(),
            Value<double?> valorManutencao = const Value.absent(),
            Value<String?> observacao = const Value.absent(),
          }) =>
              FrotaVeiculoManutencaosCompanion.insert(
            id: id,
            idFrotaVeiculo: idFrotaVeiculo,
            tipo: tipo,
            dataManutencao: dataManutencao,
            valorManutencao: valorManutencao,
            observacao: observacao,
          ),
        ));
}

class $$FrotaVeiculoManutencaosTableFilterComposer
    extends FilterComposer<_$AppDatabase, $FrotaVeiculoManutencaosTable> {
  $$FrotaVeiculoManutencaosTableFilterComposer(super.$state);
  ColumnFilters<int> get id => $state.composableBuilder(
      column: $state.table.id,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<int> get idFrotaVeiculo => $state.composableBuilder(
      column: $state.table.idFrotaVeiculo,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get tipo => $state.composableBuilder(
      column: $state.table.tipo,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<DateTime> get dataManutencao => $state.composableBuilder(
      column: $state.table.dataManutencao,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<double> get valorManutencao => $state.composableBuilder(
      column: $state.table.valorManutencao,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get observacao => $state.composableBuilder(
      column: $state.table.observacao,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));
}

class $$FrotaVeiculoManutencaosTableOrderingComposer
    extends OrderingComposer<_$AppDatabase, $FrotaVeiculoManutencaosTable> {
  $$FrotaVeiculoManutencaosTableOrderingComposer(super.$state);
  ColumnOrderings<int> get id => $state.composableBuilder(
      column: $state.table.id,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<int> get idFrotaVeiculo => $state.composableBuilder(
      column: $state.table.idFrotaVeiculo,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get tipo => $state.composableBuilder(
      column: $state.table.tipo,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<DateTime> get dataManutencao => $state.composableBuilder(
      column: $state.table.dataManutencao,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<double> get valorManutencao => $state.composableBuilder(
      column: $state.table.valorManutencao,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get observacao => $state.composableBuilder(
      column: $state.table.observacao,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));
}

typedef $$FrotaMultaControlesTableCreateCompanionBuilder
    = FrotaMultaControlesCompanion Function({
  Value<int?> id,
  Value<int?> idFrotaVeiculo,
  Value<DateTime?> dataMulta,
  Value<int?> pontos,
  Value<double?> valor,
  Value<String?> observacao,
});
typedef $$FrotaMultaControlesTableUpdateCompanionBuilder
    = FrotaMultaControlesCompanion Function({
  Value<int?> id,
  Value<int?> idFrotaVeiculo,
  Value<DateTime?> dataMulta,
  Value<int?> pontos,
  Value<double?> valor,
  Value<String?> observacao,
});

class $$FrotaMultaControlesTableTableManager extends RootTableManager<
    _$AppDatabase,
    $FrotaMultaControlesTable,
    FrotaMultaControle,
    $$FrotaMultaControlesTableFilterComposer,
    $$FrotaMultaControlesTableOrderingComposer,
    $$FrotaMultaControlesTableCreateCompanionBuilder,
    $$FrotaMultaControlesTableUpdateCompanionBuilder> {
  $$FrotaMultaControlesTableTableManager(
      _$AppDatabase db, $FrotaMultaControlesTable table)
      : super(TableManagerState(
          db: db,
          table: table,
          filteringComposer: $$FrotaMultaControlesTableFilterComposer(
              ComposerState(db, table)),
          orderingComposer: $$FrotaMultaControlesTableOrderingComposer(
              ComposerState(db, table)),
          updateCompanionCallback: ({
            Value<int?> id = const Value.absent(),
            Value<int?> idFrotaVeiculo = const Value.absent(),
            Value<DateTime?> dataMulta = const Value.absent(),
            Value<int?> pontos = const Value.absent(),
            Value<double?> valor = const Value.absent(),
            Value<String?> observacao = const Value.absent(),
          }) =>
              FrotaMultaControlesCompanion(
            id: id,
            idFrotaVeiculo: idFrotaVeiculo,
            dataMulta: dataMulta,
            pontos: pontos,
            valor: valor,
            observacao: observacao,
          ),
          createCompanionCallback: ({
            Value<int?> id = const Value.absent(),
            Value<int?> idFrotaVeiculo = const Value.absent(),
            Value<DateTime?> dataMulta = const Value.absent(),
            Value<int?> pontos = const Value.absent(),
            Value<double?> valor = const Value.absent(),
            Value<String?> observacao = const Value.absent(),
          }) =>
              FrotaMultaControlesCompanion.insert(
            id: id,
            idFrotaVeiculo: idFrotaVeiculo,
            dataMulta: dataMulta,
            pontos: pontos,
            valor: valor,
            observacao: observacao,
          ),
        ));
}

class $$FrotaMultaControlesTableFilterComposer
    extends FilterComposer<_$AppDatabase, $FrotaMultaControlesTable> {
  $$FrotaMultaControlesTableFilterComposer(super.$state);
  ColumnFilters<int> get id => $state.composableBuilder(
      column: $state.table.id,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<int> get idFrotaVeiculo => $state.composableBuilder(
      column: $state.table.idFrotaVeiculo,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<DateTime> get dataMulta => $state.composableBuilder(
      column: $state.table.dataMulta,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<int> get pontos => $state.composableBuilder(
      column: $state.table.pontos,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<double> get valor => $state.composableBuilder(
      column: $state.table.valor,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get observacao => $state.composableBuilder(
      column: $state.table.observacao,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));
}

class $$FrotaMultaControlesTableOrderingComposer
    extends OrderingComposer<_$AppDatabase, $FrotaMultaControlesTable> {
  $$FrotaMultaControlesTableOrderingComposer(super.$state);
  ColumnOrderings<int> get id => $state.composableBuilder(
      column: $state.table.id,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<int> get idFrotaVeiculo => $state.composableBuilder(
      column: $state.table.idFrotaVeiculo,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<DateTime> get dataMulta => $state.composableBuilder(
      column: $state.table.dataMulta,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<int> get pontos => $state.composableBuilder(
      column: $state.table.pontos,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<double> get valor => $state.composableBuilder(
      column: $state.table.valor,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get observacao => $state.composableBuilder(
      column: $state.table.observacao,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));
}

typedef $$FrotaCombustivelControlesTableCreateCompanionBuilder
    = FrotaCombustivelControlesCompanion Function({
  Value<int?> id,
  Value<int?> idFrotaVeiculo,
  Value<DateTime?> dataAbastecimento,
  Value<String?> horaAbastecimento,
  Value<double?> valorAbastecimento,
});
typedef $$FrotaCombustivelControlesTableUpdateCompanionBuilder
    = FrotaCombustivelControlesCompanion Function({
  Value<int?> id,
  Value<int?> idFrotaVeiculo,
  Value<DateTime?> dataAbastecimento,
  Value<String?> horaAbastecimento,
  Value<double?> valorAbastecimento,
});

class $$FrotaCombustivelControlesTableTableManager extends RootTableManager<
    _$AppDatabase,
    $FrotaCombustivelControlesTable,
    FrotaCombustivelControle,
    $$FrotaCombustivelControlesTableFilterComposer,
    $$FrotaCombustivelControlesTableOrderingComposer,
    $$FrotaCombustivelControlesTableCreateCompanionBuilder,
    $$FrotaCombustivelControlesTableUpdateCompanionBuilder> {
  $$FrotaCombustivelControlesTableTableManager(
      _$AppDatabase db, $FrotaCombustivelControlesTable table)
      : super(TableManagerState(
          db: db,
          table: table,
          filteringComposer: $$FrotaCombustivelControlesTableFilterComposer(
              ComposerState(db, table)),
          orderingComposer: $$FrotaCombustivelControlesTableOrderingComposer(
              ComposerState(db, table)),
          updateCompanionCallback: ({
            Value<int?> id = const Value.absent(),
            Value<int?> idFrotaVeiculo = const Value.absent(),
            Value<DateTime?> dataAbastecimento = const Value.absent(),
            Value<String?> horaAbastecimento = const Value.absent(),
            Value<double?> valorAbastecimento = const Value.absent(),
          }) =>
              FrotaCombustivelControlesCompanion(
            id: id,
            idFrotaVeiculo: idFrotaVeiculo,
            dataAbastecimento: dataAbastecimento,
            horaAbastecimento: horaAbastecimento,
            valorAbastecimento: valorAbastecimento,
          ),
          createCompanionCallback: ({
            Value<int?> id = const Value.absent(),
            Value<int?> idFrotaVeiculo = const Value.absent(),
            Value<DateTime?> dataAbastecimento = const Value.absent(),
            Value<String?> horaAbastecimento = const Value.absent(),
            Value<double?> valorAbastecimento = const Value.absent(),
          }) =>
              FrotaCombustivelControlesCompanion.insert(
            id: id,
            idFrotaVeiculo: idFrotaVeiculo,
            dataAbastecimento: dataAbastecimento,
            horaAbastecimento: horaAbastecimento,
            valorAbastecimento: valorAbastecimento,
          ),
        ));
}

class $$FrotaCombustivelControlesTableFilterComposer
    extends FilterComposer<_$AppDatabase, $FrotaCombustivelControlesTable> {
  $$FrotaCombustivelControlesTableFilterComposer(super.$state);
  ColumnFilters<int> get id => $state.composableBuilder(
      column: $state.table.id,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<int> get idFrotaVeiculo => $state.composableBuilder(
      column: $state.table.idFrotaVeiculo,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<DateTime> get dataAbastecimento => $state.composableBuilder(
      column: $state.table.dataAbastecimento,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get horaAbastecimento => $state.composableBuilder(
      column: $state.table.horaAbastecimento,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<double> get valorAbastecimento => $state.composableBuilder(
      column: $state.table.valorAbastecimento,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));
}

class $$FrotaCombustivelControlesTableOrderingComposer
    extends OrderingComposer<_$AppDatabase, $FrotaCombustivelControlesTable> {
  $$FrotaCombustivelControlesTableOrderingComposer(super.$state);
  ColumnOrderings<int> get id => $state.composableBuilder(
      column: $state.table.id,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<int> get idFrotaVeiculo => $state.composableBuilder(
      column: $state.table.idFrotaVeiculo,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<DateTime> get dataAbastecimento => $state.composableBuilder(
      column: $state.table.dataAbastecimento,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get horaAbastecimento => $state.composableBuilder(
      column: $state.table.horaAbastecimento,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<double> get valorAbastecimento => $state.composableBuilder(
      column: $state.table.valorAbastecimento,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));
}

typedef $$FrotaVeiculosTableCreateCompanionBuilder = FrotaVeiculosCompanion
    Function({
  Value<int?> id,
  Value<int?> idFrotaVeiculoTipo,
  Value<int?> idFrotaCombustivelTipo,
  Value<String?> marca,
  Value<String?> modelo,
  Value<String?> modeloAno,
  Value<String?> placa,
  Value<String?> codigoFipe,
  Value<String?> renavam,
  Value<String?> ipvaMesVencimento,
  Value<String?> dpvatMesVencimento,
});
typedef $$FrotaVeiculosTableUpdateCompanionBuilder = FrotaVeiculosCompanion
    Function({
  Value<int?> id,
  Value<int?> idFrotaVeiculoTipo,
  Value<int?> idFrotaCombustivelTipo,
  Value<String?> marca,
  Value<String?> modelo,
  Value<String?> modeloAno,
  Value<String?> placa,
  Value<String?> codigoFipe,
  Value<String?> renavam,
  Value<String?> ipvaMesVencimento,
  Value<String?> dpvatMesVencimento,
});

class $$FrotaVeiculosTableTableManager extends RootTableManager<
    _$AppDatabase,
    $FrotaVeiculosTable,
    FrotaVeiculo,
    $$FrotaVeiculosTableFilterComposer,
    $$FrotaVeiculosTableOrderingComposer,
    $$FrotaVeiculosTableCreateCompanionBuilder,
    $$FrotaVeiculosTableUpdateCompanionBuilder> {
  $$FrotaVeiculosTableTableManager(_$AppDatabase db, $FrotaVeiculosTable table)
      : super(TableManagerState(
          db: db,
          table: table,
          filteringComposer:
              $$FrotaVeiculosTableFilterComposer(ComposerState(db, table)),
          orderingComposer:
              $$FrotaVeiculosTableOrderingComposer(ComposerState(db, table)),
          updateCompanionCallback: ({
            Value<int?> id = const Value.absent(),
            Value<int?> idFrotaVeiculoTipo = const Value.absent(),
            Value<int?> idFrotaCombustivelTipo = const Value.absent(),
            Value<String?> marca = const Value.absent(),
            Value<String?> modelo = const Value.absent(),
            Value<String?> modeloAno = const Value.absent(),
            Value<String?> placa = const Value.absent(),
            Value<String?> codigoFipe = const Value.absent(),
            Value<String?> renavam = const Value.absent(),
            Value<String?> ipvaMesVencimento = const Value.absent(),
            Value<String?> dpvatMesVencimento = const Value.absent(),
          }) =>
              FrotaVeiculosCompanion(
            id: id,
            idFrotaVeiculoTipo: idFrotaVeiculoTipo,
            idFrotaCombustivelTipo: idFrotaCombustivelTipo,
            marca: marca,
            modelo: modelo,
            modeloAno: modeloAno,
            placa: placa,
            codigoFipe: codigoFipe,
            renavam: renavam,
            ipvaMesVencimento: ipvaMesVencimento,
            dpvatMesVencimento: dpvatMesVencimento,
          ),
          createCompanionCallback: ({
            Value<int?> id = const Value.absent(),
            Value<int?> idFrotaVeiculoTipo = const Value.absent(),
            Value<int?> idFrotaCombustivelTipo = const Value.absent(),
            Value<String?> marca = const Value.absent(),
            Value<String?> modelo = const Value.absent(),
            Value<String?> modeloAno = const Value.absent(),
            Value<String?> placa = const Value.absent(),
            Value<String?> codigoFipe = const Value.absent(),
            Value<String?> renavam = const Value.absent(),
            Value<String?> ipvaMesVencimento = const Value.absent(),
            Value<String?> dpvatMesVencimento = const Value.absent(),
          }) =>
              FrotaVeiculosCompanion.insert(
            id: id,
            idFrotaVeiculoTipo: idFrotaVeiculoTipo,
            idFrotaCombustivelTipo: idFrotaCombustivelTipo,
            marca: marca,
            modelo: modelo,
            modeloAno: modeloAno,
            placa: placa,
            codigoFipe: codigoFipe,
            renavam: renavam,
            ipvaMesVencimento: ipvaMesVencimento,
            dpvatMesVencimento: dpvatMesVencimento,
          ),
        ));
}

class $$FrotaVeiculosTableFilterComposer
    extends FilterComposer<_$AppDatabase, $FrotaVeiculosTable> {
  $$FrotaVeiculosTableFilterComposer(super.$state);
  ColumnFilters<int> get id => $state.composableBuilder(
      column: $state.table.id,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<int> get idFrotaVeiculoTipo => $state.composableBuilder(
      column: $state.table.idFrotaVeiculoTipo,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<int> get idFrotaCombustivelTipo => $state.composableBuilder(
      column: $state.table.idFrotaCombustivelTipo,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get marca => $state.composableBuilder(
      column: $state.table.marca,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get modelo => $state.composableBuilder(
      column: $state.table.modelo,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get modeloAno => $state.composableBuilder(
      column: $state.table.modeloAno,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get placa => $state.composableBuilder(
      column: $state.table.placa,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get codigoFipe => $state.composableBuilder(
      column: $state.table.codigoFipe,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get renavam => $state.composableBuilder(
      column: $state.table.renavam,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get ipvaMesVencimento => $state.composableBuilder(
      column: $state.table.ipvaMesVencimento,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get dpvatMesVencimento => $state.composableBuilder(
      column: $state.table.dpvatMesVencimento,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));
}

class $$FrotaVeiculosTableOrderingComposer
    extends OrderingComposer<_$AppDatabase, $FrotaVeiculosTable> {
  $$FrotaVeiculosTableOrderingComposer(super.$state);
  ColumnOrderings<int> get id => $state.composableBuilder(
      column: $state.table.id,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<int> get idFrotaVeiculoTipo => $state.composableBuilder(
      column: $state.table.idFrotaVeiculoTipo,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<int> get idFrotaCombustivelTipo => $state.composableBuilder(
      column: $state.table.idFrotaCombustivelTipo,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get marca => $state.composableBuilder(
      column: $state.table.marca,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get modelo => $state.composableBuilder(
      column: $state.table.modelo,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get modeloAno => $state.composableBuilder(
      column: $state.table.modeloAno,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get placa => $state.composableBuilder(
      column: $state.table.placa,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get codigoFipe => $state.composableBuilder(
      column: $state.table.codigoFipe,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get renavam => $state.composableBuilder(
      column: $state.table.renavam,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get ipvaMesVencimento => $state.composableBuilder(
      column: $state.table.ipvaMesVencimento,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get dpvatMesVencimento => $state.composableBuilder(
      column: $state.table.dpvatMesVencimento,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));
}

typedef $$FrotaVeiculoTiposTableCreateCompanionBuilder
    = FrotaVeiculoTiposCompanion Function({
  Value<int?> id,
  Value<String?> codigo,
  Value<String?> nome,
});
typedef $$FrotaVeiculoTiposTableUpdateCompanionBuilder
    = FrotaVeiculoTiposCompanion Function({
  Value<int?> id,
  Value<String?> codigo,
  Value<String?> nome,
});

class $$FrotaVeiculoTiposTableTableManager extends RootTableManager<
    _$AppDatabase,
    $FrotaVeiculoTiposTable,
    FrotaVeiculoTipo,
    $$FrotaVeiculoTiposTableFilterComposer,
    $$FrotaVeiculoTiposTableOrderingComposer,
    $$FrotaVeiculoTiposTableCreateCompanionBuilder,
    $$FrotaVeiculoTiposTableUpdateCompanionBuilder> {
  $$FrotaVeiculoTiposTableTableManager(
      _$AppDatabase db, $FrotaVeiculoTiposTable table)
      : super(TableManagerState(
          db: db,
          table: table,
          filteringComposer:
              $$FrotaVeiculoTiposTableFilterComposer(ComposerState(db, table)),
          orderingComposer: $$FrotaVeiculoTiposTableOrderingComposer(
              ComposerState(db, table)),
          updateCompanionCallback: ({
            Value<int?> id = const Value.absent(),
            Value<String?> codigo = const Value.absent(),
            Value<String?> nome = const Value.absent(),
          }) =>
              FrotaVeiculoTiposCompanion(
            id: id,
            codigo: codigo,
            nome: nome,
          ),
          createCompanionCallback: ({
            Value<int?> id = const Value.absent(),
            Value<String?> codigo = const Value.absent(),
            Value<String?> nome = const Value.absent(),
          }) =>
              FrotaVeiculoTiposCompanion.insert(
            id: id,
            codigo: codigo,
            nome: nome,
          ),
        ));
}

class $$FrotaVeiculoTiposTableFilterComposer
    extends FilterComposer<_$AppDatabase, $FrotaVeiculoTiposTable> {
  $$FrotaVeiculoTiposTableFilterComposer(super.$state);
  ColumnFilters<int> get id => $state.composableBuilder(
      column: $state.table.id,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get codigo => $state.composableBuilder(
      column: $state.table.codigo,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get nome => $state.composableBuilder(
      column: $state.table.nome,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));
}

class $$FrotaVeiculoTiposTableOrderingComposer
    extends OrderingComposer<_$AppDatabase, $FrotaVeiculoTiposTable> {
  $$FrotaVeiculoTiposTableOrderingComposer(super.$state);
  ColumnOrderings<int> get id => $state.composableBuilder(
      column: $state.table.id,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get codigo => $state.composableBuilder(
      column: $state.table.codigo,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get nome => $state.composableBuilder(
      column: $state.table.nome,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));
}

typedef $$FrotaCombustivelTiposTableCreateCompanionBuilder
    = FrotaCombustivelTiposCompanion Function({
  Value<int?> id,
  Value<String?> codigo,
  Value<String?> nome,
});
typedef $$FrotaCombustivelTiposTableUpdateCompanionBuilder
    = FrotaCombustivelTiposCompanion Function({
  Value<int?> id,
  Value<String?> codigo,
  Value<String?> nome,
});

class $$FrotaCombustivelTiposTableTableManager extends RootTableManager<
    _$AppDatabase,
    $FrotaCombustivelTiposTable,
    FrotaCombustivelTipo,
    $$FrotaCombustivelTiposTableFilterComposer,
    $$FrotaCombustivelTiposTableOrderingComposer,
    $$FrotaCombustivelTiposTableCreateCompanionBuilder,
    $$FrotaCombustivelTiposTableUpdateCompanionBuilder> {
  $$FrotaCombustivelTiposTableTableManager(
      _$AppDatabase db, $FrotaCombustivelTiposTable table)
      : super(TableManagerState(
          db: db,
          table: table,
          filteringComposer: $$FrotaCombustivelTiposTableFilterComposer(
              ComposerState(db, table)),
          orderingComposer: $$FrotaCombustivelTiposTableOrderingComposer(
              ComposerState(db, table)),
          updateCompanionCallback: ({
            Value<int?> id = const Value.absent(),
            Value<String?> codigo = const Value.absent(),
            Value<String?> nome = const Value.absent(),
          }) =>
              FrotaCombustivelTiposCompanion(
            id: id,
            codigo: codigo,
            nome: nome,
          ),
          createCompanionCallback: ({
            Value<int?> id = const Value.absent(),
            Value<String?> codigo = const Value.absent(),
            Value<String?> nome = const Value.absent(),
          }) =>
              FrotaCombustivelTiposCompanion.insert(
            id: id,
            codigo: codigo,
            nome: nome,
          ),
        ));
}

class $$FrotaCombustivelTiposTableFilterComposer
    extends FilterComposer<_$AppDatabase, $FrotaCombustivelTiposTable> {
  $$FrotaCombustivelTiposTableFilterComposer(super.$state);
  ColumnFilters<int> get id => $state.composableBuilder(
      column: $state.table.id,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get codigo => $state.composableBuilder(
      column: $state.table.codigo,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get nome => $state.composableBuilder(
      column: $state.table.nome,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));
}

class $$FrotaCombustivelTiposTableOrderingComposer
    extends OrderingComposer<_$AppDatabase, $FrotaCombustivelTiposTable> {
  $$FrotaCombustivelTiposTableOrderingComposer(super.$state);
  ColumnOrderings<int> get id => $state.composableBuilder(
      column: $state.table.id,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get codigo => $state.composableBuilder(
      column: $state.table.codigo,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get nome => $state.composableBuilder(
      column: $state.table.nome,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));
}

typedef $$FrotaMotoristasTableCreateCompanionBuilder = FrotaMotoristasCompanion
    Function({
  Value<int?> id,
  Value<int?> idColaborador,
  Value<String?> nome,
  Value<String?> numeroCnh,
  Value<String?> cnhCategoria,
});
typedef $$FrotaMotoristasTableUpdateCompanionBuilder = FrotaMotoristasCompanion
    Function({
  Value<int?> id,
  Value<int?> idColaborador,
  Value<String?> nome,
  Value<String?> numeroCnh,
  Value<String?> cnhCategoria,
});

class $$FrotaMotoristasTableTableManager extends RootTableManager<
    _$AppDatabase,
    $FrotaMotoristasTable,
    FrotaMotorista,
    $$FrotaMotoristasTableFilterComposer,
    $$FrotaMotoristasTableOrderingComposer,
    $$FrotaMotoristasTableCreateCompanionBuilder,
    $$FrotaMotoristasTableUpdateCompanionBuilder> {
  $$FrotaMotoristasTableTableManager(
      _$AppDatabase db, $FrotaMotoristasTable table)
      : super(TableManagerState(
          db: db,
          table: table,
          filteringComposer:
              $$FrotaMotoristasTableFilterComposer(ComposerState(db, table)),
          orderingComposer:
              $$FrotaMotoristasTableOrderingComposer(ComposerState(db, table)),
          updateCompanionCallback: ({
            Value<int?> id = const Value.absent(),
            Value<int?> idColaborador = const Value.absent(),
            Value<String?> nome = const Value.absent(),
            Value<String?> numeroCnh = const Value.absent(),
            Value<String?> cnhCategoria = const Value.absent(),
          }) =>
              FrotaMotoristasCompanion(
            id: id,
            idColaborador: idColaborador,
            nome: nome,
            numeroCnh: numeroCnh,
            cnhCategoria: cnhCategoria,
          ),
          createCompanionCallback: ({
            Value<int?> id = const Value.absent(),
            Value<int?> idColaborador = const Value.absent(),
            Value<String?> nome = const Value.absent(),
            Value<String?> numeroCnh = const Value.absent(),
            Value<String?> cnhCategoria = const Value.absent(),
          }) =>
              FrotaMotoristasCompanion.insert(
            id: id,
            idColaborador: idColaborador,
            nome: nome,
            numeroCnh: numeroCnh,
            cnhCategoria: cnhCategoria,
          ),
        ));
}

class $$FrotaMotoristasTableFilterComposer
    extends FilterComposer<_$AppDatabase, $FrotaMotoristasTable> {
  $$FrotaMotoristasTableFilterComposer(super.$state);
  ColumnFilters<int> get id => $state.composableBuilder(
      column: $state.table.id,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<int> get idColaborador => $state.composableBuilder(
      column: $state.table.idColaborador,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get nome => $state.composableBuilder(
      column: $state.table.nome,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get numeroCnh => $state.composableBuilder(
      column: $state.table.numeroCnh,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get cnhCategoria => $state.composableBuilder(
      column: $state.table.cnhCategoria,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));
}

class $$FrotaMotoristasTableOrderingComposer
    extends OrderingComposer<_$AppDatabase, $FrotaMotoristasTable> {
  $$FrotaMotoristasTableOrderingComposer(super.$state);
  ColumnOrderings<int> get id => $state.composableBuilder(
      column: $state.table.id,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<int> get idColaborador => $state.composableBuilder(
      column: $state.table.idColaborador,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get nome => $state.composableBuilder(
      column: $state.table.nome,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get numeroCnh => $state.composableBuilder(
      column: $state.table.numeroCnh,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get cnhCategoria => $state.composableBuilder(
      column: $state.table.cnhCategoria,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));
}

typedef $$ViewControleAcessosTableCreateCompanionBuilder
    = ViewControleAcessosCompanion Function({
  Value<int?> id,
  Value<int?> idPessoa,
  Value<String?> pessoaNome,
  Value<int?> idColaborador,
  Value<int?> idUsuario,
  Value<String?> administrador,
  Value<int?> idPapel,
  Value<String?> papelNome,
  Value<String?> papelDescricao,
  Value<int?> idFuncao,
  Value<String?> funcaoNome,
  Value<String?> funcaoDescricao,
  Value<int?> idPapelFuncao,
  Value<String?> habilitado,
  Value<String?> podeInserir,
  Value<String?> podeAlterar,
  Value<String?> podeExcluir,
});
typedef $$ViewControleAcessosTableUpdateCompanionBuilder
    = ViewControleAcessosCompanion Function({
  Value<int?> id,
  Value<int?> idPessoa,
  Value<String?> pessoaNome,
  Value<int?> idColaborador,
  Value<int?> idUsuario,
  Value<String?> administrador,
  Value<int?> idPapel,
  Value<String?> papelNome,
  Value<String?> papelDescricao,
  Value<int?> idFuncao,
  Value<String?> funcaoNome,
  Value<String?> funcaoDescricao,
  Value<int?> idPapelFuncao,
  Value<String?> habilitado,
  Value<String?> podeInserir,
  Value<String?> podeAlterar,
  Value<String?> podeExcluir,
});

class $$ViewControleAcessosTableTableManager extends RootTableManager<
    _$AppDatabase,
    $ViewControleAcessosTable,
    ViewControleAcesso,
    $$ViewControleAcessosTableFilterComposer,
    $$ViewControleAcessosTableOrderingComposer,
    $$ViewControleAcessosTableCreateCompanionBuilder,
    $$ViewControleAcessosTableUpdateCompanionBuilder> {
  $$ViewControleAcessosTableTableManager(
      _$AppDatabase db, $ViewControleAcessosTable table)
      : super(TableManagerState(
          db: db,
          table: table,
          filteringComposer: $$ViewControleAcessosTableFilterComposer(
              ComposerState(db, table)),
          orderingComposer: $$ViewControleAcessosTableOrderingComposer(
              ComposerState(db, table)),
          updateCompanionCallback: ({
            Value<int?> id = const Value.absent(),
            Value<int?> idPessoa = const Value.absent(),
            Value<String?> pessoaNome = const Value.absent(),
            Value<int?> idColaborador = const Value.absent(),
            Value<int?> idUsuario = const Value.absent(),
            Value<String?> administrador = const Value.absent(),
            Value<int?> idPapel = const Value.absent(),
            Value<String?> papelNome = const Value.absent(),
            Value<String?> papelDescricao = const Value.absent(),
            Value<int?> idFuncao = const Value.absent(),
            Value<String?> funcaoNome = const Value.absent(),
            Value<String?> funcaoDescricao = const Value.absent(),
            Value<int?> idPapelFuncao = const Value.absent(),
            Value<String?> habilitado = const Value.absent(),
            Value<String?> podeInserir = const Value.absent(),
            Value<String?> podeAlterar = const Value.absent(),
            Value<String?> podeExcluir = const Value.absent(),
          }) =>
              ViewControleAcessosCompanion(
            id: id,
            idPessoa: idPessoa,
            pessoaNome: pessoaNome,
            idColaborador: idColaborador,
            idUsuario: idUsuario,
            administrador: administrador,
            idPapel: idPapel,
            papelNome: papelNome,
            papelDescricao: papelDescricao,
            idFuncao: idFuncao,
            funcaoNome: funcaoNome,
            funcaoDescricao: funcaoDescricao,
            idPapelFuncao: idPapelFuncao,
            habilitado: habilitado,
            podeInserir: podeInserir,
            podeAlterar: podeAlterar,
            podeExcluir: podeExcluir,
          ),
          createCompanionCallback: ({
            Value<int?> id = const Value.absent(),
            Value<int?> idPessoa = const Value.absent(),
            Value<String?> pessoaNome = const Value.absent(),
            Value<int?> idColaborador = const Value.absent(),
            Value<int?> idUsuario = const Value.absent(),
            Value<String?> administrador = const Value.absent(),
            Value<int?> idPapel = const Value.absent(),
            Value<String?> papelNome = const Value.absent(),
            Value<String?> papelDescricao = const Value.absent(),
            Value<int?> idFuncao = const Value.absent(),
            Value<String?> funcaoNome = const Value.absent(),
            Value<String?> funcaoDescricao = const Value.absent(),
            Value<int?> idPapelFuncao = const Value.absent(),
            Value<String?> habilitado = const Value.absent(),
            Value<String?> podeInserir = const Value.absent(),
            Value<String?> podeAlterar = const Value.absent(),
            Value<String?> podeExcluir = const Value.absent(),
          }) =>
              ViewControleAcessosCompanion.insert(
            id: id,
            idPessoa: idPessoa,
            pessoaNome: pessoaNome,
            idColaborador: idColaborador,
            idUsuario: idUsuario,
            administrador: administrador,
            idPapel: idPapel,
            papelNome: papelNome,
            papelDescricao: papelDescricao,
            idFuncao: idFuncao,
            funcaoNome: funcaoNome,
            funcaoDescricao: funcaoDescricao,
            idPapelFuncao: idPapelFuncao,
            habilitado: habilitado,
            podeInserir: podeInserir,
            podeAlterar: podeAlterar,
            podeExcluir: podeExcluir,
          ),
        ));
}

class $$ViewControleAcessosTableFilterComposer
    extends FilterComposer<_$AppDatabase, $ViewControleAcessosTable> {
  $$ViewControleAcessosTableFilterComposer(super.$state);
  ColumnFilters<int> get id => $state.composableBuilder(
      column: $state.table.id,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<int> get idPessoa => $state.composableBuilder(
      column: $state.table.idPessoa,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get pessoaNome => $state.composableBuilder(
      column: $state.table.pessoaNome,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<int> get idColaborador => $state.composableBuilder(
      column: $state.table.idColaborador,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<int> get idUsuario => $state.composableBuilder(
      column: $state.table.idUsuario,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get administrador => $state.composableBuilder(
      column: $state.table.administrador,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<int> get idPapel => $state.composableBuilder(
      column: $state.table.idPapel,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get papelNome => $state.composableBuilder(
      column: $state.table.papelNome,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get papelDescricao => $state.composableBuilder(
      column: $state.table.papelDescricao,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<int> get idFuncao => $state.composableBuilder(
      column: $state.table.idFuncao,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get funcaoNome => $state.composableBuilder(
      column: $state.table.funcaoNome,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get funcaoDescricao => $state.composableBuilder(
      column: $state.table.funcaoDescricao,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<int> get idPapelFuncao => $state.composableBuilder(
      column: $state.table.idPapelFuncao,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get habilitado => $state.composableBuilder(
      column: $state.table.habilitado,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get podeInserir => $state.composableBuilder(
      column: $state.table.podeInserir,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get podeAlterar => $state.composableBuilder(
      column: $state.table.podeAlterar,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get podeExcluir => $state.composableBuilder(
      column: $state.table.podeExcluir,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));
}

class $$ViewControleAcessosTableOrderingComposer
    extends OrderingComposer<_$AppDatabase, $ViewControleAcessosTable> {
  $$ViewControleAcessosTableOrderingComposer(super.$state);
  ColumnOrderings<int> get id => $state.composableBuilder(
      column: $state.table.id,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<int> get idPessoa => $state.composableBuilder(
      column: $state.table.idPessoa,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get pessoaNome => $state.composableBuilder(
      column: $state.table.pessoaNome,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<int> get idColaborador => $state.composableBuilder(
      column: $state.table.idColaborador,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<int> get idUsuario => $state.composableBuilder(
      column: $state.table.idUsuario,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get administrador => $state.composableBuilder(
      column: $state.table.administrador,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<int> get idPapel => $state.composableBuilder(
      column: $state.table.idPapel,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get papelNome => $state.composableBuilder(
      column: $state.table.papelNome,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get papelDescricao => $state.composableBuilder(
      column: $state.table.papelDescricao,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<int> get idFuncao => $state.composableBuilder(
      column: $state.table.idFuncao,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get funcaoNome => $state.composableBuilder(
      column: $state.table.funcaoNome,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get funcaoDescricao => $state.composableBuilder(
      column: $state.table.funcaoDescricao,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<int> get idPapelFuncao => $state.composableBuilder(
      column: $state.table.idPapelFuncao,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get habilitado => $state.composableBuilder(
      column: $state.table.habilitado,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get podeInserir => $state.composableBuilder(
      column: $state.table.podeInserir,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get podeAlterar => $state.composableBuilder(
      column: $state.table.podeAlterar,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get podeExcluir => $state.composableBuilder(
      column: $state.table.podeExcluir,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));
}

typedef $$ViewPessoaUsuariosTableCreateCompanionBuilder
    = ViewPessoaUsuariosCompanion Function({
  Value<int?> id,
  Value<int?> idPessoa,
  Value<String?> pessoaNome,
  Value<String?> tipo,
  Value<String?> email,
  Value<int?> idColaborador,
  Value<int?> idUsuario,
  Value<String?> login,
  Value<String?> senha,
  Value<DateTime?> dataCadastro,
  Value<String?> administrador,
});
typedef $$ViewPessoaUsuariosTableUpdateCompanionBuilder
    = ViewPessoaUsuariosCompanion Function({
  Value<int?> id,
  Value<int?> idPessoa,
  Value<String?> pessoaNome,
  Value<String?> tipo,
  Value<String?> email,
  Value<int?> idColaborador,
  Value<int?> idUsuario,
  Value<String?> login,
  Value<String?> senha,
  Value<DateTime?> dataCadastro,
  Value<String?> administrador,
});

class $$ViewPessoaUsuariosTableTableManager extends RootTableManager<
    _$AppDatabase,
    $ViewPessoaUsuariosTable,
    ViewPessoaUsuario,
    $$ViewPessoaUsuariosTableFilterComposer,
    $$ViewPessoaUsuariosTableOrderingComposer,
    $$ViewPessoaUsuariosTableCreateCompanionBuilder,
    $$ViewPessoaUsuariosTableUpdateCompanionBuilder> {
  $$ViewPessoaUsuariosTableTableManager(
      _$AppDatabase db, $ViewPessoaUsuariosTable table)
      : super(TableManagerState(
          db: db,
          table: table,
          filteringComposer:
              $$ViewPessoaUsuariosTableFilterComposer(ComposerState(db, table)),
          orderingComposer: $$ViewPessoaUsuariosTableOrderingComposer(
              ComposerState(db, table)),
          updateCompanionCallback: ({
            Value<int?> id = const Value.absent(),
            Value<int?> idPessoa = const Value.absent(),
            Value<String?> pessoaNome = const Value.absent(),
            Value<String?> tipo = const Value.absent(),
            Value<String?> email = const Value.absent(),
            Value<int?> idColaborador = const Value.absent(),
            Value<int?> idUsuario = const Value.absent(),
            Value<String?> login = const Value.absent(),
            Value<String?> senha = const Value.absent(),
            Value<DateTime?> dataCadastro = const Value.absent(),
            Value<String?> administrador = const Value.absent(),
          }) =>
              ViewPessoaUsuariosCompanion(
            id: id,
            idPessoa: idPessoa,
            pessoaNome: pessoaNome,
            tipo: tipo,
            email: email,
            idColaborador: idColaborador,
            idUsuario: idUsuario,
            login: login,
            senha: senha,
            dataCadastro: dataCadastro,
            administrador: administrador,
          ),
          createCompanionCallback: ({
            Value<int?> id = const Value.absent(),
            Value<int?> idPessoa = const Value.absent(),
            Value<String?> pessoaNome = const Value.absent(),
            Value<String?> tipo = const Value.absent(),
            Value<String?> email = const Value.absent(),
            Value<int?> idColaborador = const Value.absent(),
            Value<int?> idUsuario = const Value.absent(),
            Value<String?> login = const Value.absent(),
            Value<String?> senha = const Value.absent(),
            Value<DateTime?> dataCadastro = const Value.absent(),
            Value<String?> administrador = const Value.absent(),
          }) =>
              ViewPessoaUsuariosCompanion.insert(
            id: id,
            idPessoa: idPessoa,
            pessoaNome: pessoaNome,
            tipo: tipo,
            email: email,
            idColaborador: idColaborador,
            idUsuario: idUsuario,
            login: login,
            senha: senha,
            dataCadastro: dataCadastro,
            administrador: administrador,
          ),
        ));
}

class $$ViewPessoaUsuariosTableFilterComposer
    extends FilterComposer<_$AppDatabase, $ViewPessoaUsuariosTable> {
  $$ViewPessoaUsuariosTableFilterComposer(super.$state);
  ColumnFilters<int> get id => $state.composableBuilder(
      column: $state.table.id,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<int> get idPessoa => $state.composableBuilder(
      column: $state.table.idPessoa,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get pessoaNome => $state.composableBuilder(
      column: $state.table.pessoaNome,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get tipo => $state.composableBuilder(
      column: $state.table.tipo,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get email => $state.composableBuilder(
      column: $state.table.email,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<int> get idColaborador => $state.composableBuilder(
      column: $state.table.idColaborador,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<int> get idUsuario => $state.composableBuilder(
      column: $state.table.idUsuario,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get login => $state.composableBuilder(
      column: $state.table.login,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get senha => $state.composableBuilder(
      column: $state.table.senha,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<DateTime> get dataCadastro => $state.composableBuilder(
      column: $state.table.dataCadastro,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get administrador => $state.composableBuilder(
      column: $state.table.administrador,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));
}

class $$ViewPessoaUsuariosTableOrderingComposer
    extends OrderingComposer<_$AppDatabase, $ViewPessoaUsuariosTable> {
  $$ViewPessoaUsuariosTableOrderingComposer(super.$state);
  ColumnOrderings<int> get id => $state.composableBuilder(
      column: $state.table.id,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<int> get idPessoa => $state.composableBuilder(
      column: $state.table.idPessoa,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get pessoaNome => $state.composableBuilder(
      column: $state.table.pessoaNome,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get tipo => $state.composableBuilder(
      column: $state.table.tipo,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get email => $state.composableBuilder(
      column: $state.table.email,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<int> get idColaborador => $state.composableBuilder(
      column: $state.table.idColaborador,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<int> get idUsuario => $state.composableBuilder(
      column: $state.table.idUsuario,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get login => $state.composableBuilder(
      column: $state.table.login,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get senha => $state.composableBuilder(
      column: $state.table.senha,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<DateTime> get dataCadastro => $state.composableBuilder(
      column: $state.table.dataCadastro,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get administrador => $state.composableBuilder(
      column: $state.table.administrador,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));
}

typedef $$ViewPessoaColaboradorsTableCreateCompanionBuilder
    = ViewPessoaColaboradorsCompanion Function({
  Value<int?> id,
  Value<String?> nome,
  Value<String?> tipo,
  Value<String?> email,
  Value<String?> site,
  Value<String?> cpfCnpj,
  Value<String?> rgIe,
  Value<String?> matricula,
  Value<DateTime?> dataCadastro,
  Value<DateTime?> dataAdmissao,
  Value<DateTime?> dataDemissao,
  Value<String?> ctpsNumero,
  Value<String?> ctpsSerie,
  Value<DateTime?> ctpsDataExpedicao,
  Value<String?> ctpsUf,
  Value<String?> observacao,
  Value<String?> logradouro,
  Value<String?> numero,
  Value<String?> complemento,
  Value<String?> bairro,
  Value<String?> cidade,
  Value<String?> cep,
  Value<String?> municipioIbge,
  Value<String?> uf,
  Value<int?> idPessoa,
  Value<int?> idCargo,
  Value<int?> idSetor,
});
typedef $$ViewPessoaColaboradorsTableUpdateCompanionBuilder
    = ViewPessoaColaboradorsCompanion Function({
  Value<int?> id,
  Value<String?> nome,
  Value<String?> tipo,
  Value<String?> email,
  Value<String?> site,
  Value<String?> cpfCnpj,
  Value<String?> rgIe,
  Value<String?> matricula,
  Value<DateTime?> dataCadastro,
  Value<DateTime?> dataAdmissao,
  Value<DateTime?> dataDemissao,
  Value<String?> ctpsNumero,
  Value<String?> ctpsSerie,
  Value<DateTime?> ctpsDataExpedicao,
  Value<String?> ctpsUf,
  Value<String?> observacao,
  Value<String?> logradouro,
  Value<String?> numero,
  Value<String?> complemento,
  Value<String?> bairro,
  Value<String?> cidade,
  Value<String?> cep,
  Value<String?> municipioIbge,
  Value<String?> uf,
  Value<int?> idPessoa,
  Value<int?> idCargo,
  Value<int?> idSetor,
});

class $$ViewPessoaColaboradorsTableTableManager extends RootTableManager<
    _$AppDatabase,
    $ViewPessoaColaboradorsTable,
    ViewPessoaColaborador,
    $$ViewPessoaColaboradorsTableFilterComposer,
    $$ViewPessoaColaboradorsTableOrderingComposer,
    $$ViewPessoaColaboradorsTableCreateCompanionBuilder,
    $$ViewPessoaColaboradorsTableUpdateCompanionBuilder> {
  $$ViewPessoaColaboradorsTableTableManager(
      _$AppDatabase db, $ViewPessoaColaboradorsTable table)
      : super(TableManagerState(
          db: db,
          table: table,
          filteringComposer: $$ViewPessoaColaboradorsTableFilterComposer(
              ComposerState(db, table)),
          orderingComposer: $$ViewPessoaColaboradorsTableOrderingComposer(
              ComposerState(db, table)),
          updateCompanionCallback: ({
            Value<int?> id = const Value.absent(),
            Value<String?> nome = const Value.absent(),
            Value<String?> tipo = const Value.absent(),
            Value<String?> email = const Value.absent(),
            Value<String?> site = const Value.absent(),
            Value<String?> cpfCnpj = const Value.absent(),
            Value<String?> rgIe = const Value.absent(),
            Value<String?> matricula = const Value.absent(),
            Value<DateTime?> dataCadastro = const Value.absent(),
            Value<DateTime?> dataAdmissao = const Value.absent(),
            Value<DateTime?> dataDemissao = const Value.absent(),
            Value<String?> ctpsNumero = const Value.absent(),
            Value<String?> ctpsSerie = const Value.absent(),
            Value<DateTime?> ctpsDataExpedicao = const Value.absent(),
            Value<String?> ctpsUf = const Value.absent(),
            Value<String?> observacao = const Value.absent(),
            Value<String?> logradouro = const Value.absent(),
            Value<String?> numero = const Value.absent(),
            Value<String?> complemento = const Value.absent(),
            Value<String?> bairro = const Value.absent(),
            Value<String?> cidade = const Value.absent(),
            Value<String?> cep = const Value.absent(),
            Value<String?> municipioIbge = const Value.absent(),
            Value<String?> uf = const Value.absent(),
            Value<int?> idPessoa = const Value.absent(),
            Value<int?> idCargo = const Value.absent(),
            Value<int?> idSetor = const Value.absent(),
          }) =>
              ViewPessoaColaboradorsCompanion(
            id: id,
            nome: nome,
            tipo: tipo,
            email: email,
            site: site,
            cpfCnpj: cpfCnpj,
            rgIe: rgIe,
            matricula: matricula,
            dataCadastro: dataCadastro,
            dataAdmissao: dataAdmissao,
            dataDemissao: dataDemissao,
            ctpsNumero: ctpsNumero,
            ctpsSerie: ctpsSerie,
            ctpsDataExpedicao: ctpsDataExpedicao,
            ctpsUf: ctpsUf,
            observacao: observacao,
            logradouro: logradouro,
            numero: numero,
            complemento: complemento,
            bairro: bairro,
            cidade: cidade,
            cep: cep,
            municipioIbge: municipioIbge,
            uf: uf,
            idPessoa: idPessoa,
            idCargo: idCargo,
            idSetor: idSetor,
          ),
          createCompanionCallback: ({
            Value<int?> id = const Value.absent(),
            Value<String?> nome = const Value.absent(),
            Value<String?> tipo = const Value.absent(),
            Value<String?> email = const Value.absent(),
            Value<String?> site = const Value.absent(),
            Value<String?> cpfCnpj = const Value.absent(),
            Value<String?> rgIe = const Value.absent(),
            Value<String?> matricula = const Value.absent(),
            Value<DateTime?> dataCadastro = const Value.absent(),
            Value<DateTime?> dataAdmissao = const Value.absent(),
            Value<DateTime?> dataDemissao = const Value.absent(),
            Value<String?> ctpsNumero = const Value.absent(),
            Value<String?> ctpsSerie = const Value.absent(),
            Value<DateTime?> ctpsDataExpedicao = const Value.absent(),
            Value<String?> ctpsUf = const Value.absent(),
            Value<String?> observacao = const Value.absent(),
            Value<String?> logradouro = const Value.absent(),
            Value<String?> numero = const Value.absent(),
            Value<String?> complemento = const Value.absent(),
            Value<String?> bairro = const Value.absent(),
            Value<String?> cidade = const Value.absent(),
            Value<String?> cep = const Value.absent(),
            Value<String?> municipioIbge = const Value.absent(),
            Value<String?> uf = const Value.absent(),
            Value<int?> idPessoa = const Value.absent(),
            Value<int?> idCargo = const Value.absent(),
            Value<int?> idSetor = const Value.absent(),
          }) =>
              ViewPessoaColaboradorsCompanion.insert(
            id: id,
            nome: nome,
            tipo: tipo,
            email: email,
            site: site,
            cpfCnpj: cpfCnpj,
            rgIe: rgIe,
            matricula: matricula,
            dataCadastro: dataCadastro,
            dataAdmissao: dataAdmissao,
            dataDemissao: dataDemissao,
            ctpsNumero: ctpsNumero,
            ctpsSerie: ctpsSerie,
            ctpsDataExpedicao: ctpsDataExpedicao,
            ctpsUf: ctpsUf,
            observacao: observacao,
            logradouro: logradouro,
            numero: numero,
            complemento: complemento,
            bairro: bairro,
            cidade: cidade,
            cep: cep,
            municipioIbge: municipioIbge,
            uf: uf,
            idPessoa: idPessoa,
            idCargo: idCargo,
            idSetor: idSetor,
          ),
        ));
}

class $$ViewPessoaColaboradorsTableFilterComposer
    extends FilterComposer<_$AppDatabase, $ViewPessoaColaboradorsTable> {
  $$ViewPessoaColaboradorsTableFilterComposer(super.$state);
  ColumnFilters<int> get id => $state.composableBuilder(
      column: $state.table.id,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get nome => $state.composableBuilder(
      column: $state.table.nome,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get tipo => $state.composableBuilder(
      column: $state.table.tipo,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get email => $state.composableBuilder(
      column: $state.table.email,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get site => $state.composableBuilder(
      column: $state.table.site,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get cpfCnpj => $state.composableBuilder(
      column: $state.table.cpfCnpj,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get rgIe => $state.composableBuilder(
      column: $state.table.rgIe,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get matricula => $state.composableBuilder(
      column: $state.table.matricula,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<DateTime> get dataCadastro => $state.composableBuilder(
      column: $state.table.dataCadastro,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<DateTime> get dataAdmissao => $state.composableBuilder(
      column: $state.table.dataAdmissao,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<DateTime> get dataDemissao => $state.composableBuilder(
      column: $state.table.dataDemissao,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get ctpsNumero => $state.composableBuilder(
      column: $state.table.ctpsNumero,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get ctpsSerie => $state.composableBuilder(
      column: $state.table.ctpsSerie,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<DateTime> get ctpsDataExpedicao => $state.composableBuilder(
      column: $state.table.ctpsDataExpedicao,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get ctpsUf => $state.composableBuilder(
      column: $state.table.ctpsUf,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get observacao => $state.composableBuilder(
      column: $state.table.observacao,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get logradouro => $state.composableBuilder(
      column: $state.table.logradouro,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get numero => $state.composableBuilder(
      column: $state.table.numero,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get complemento => $state.composableBuilder(
      column: $state.table.complemento,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get bairro => $state.composableBuilder(
      column: $state.table.bairro,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get cidade => $state.composableBuilder(
      column: $state.table.cidade,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get cep => $state.composableBuilder(
      column: $state.table.cep,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get municipioIbge => $state.composableBuilder(
      column: $state.table.municipioIbge,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get uf => $state.composableBuilder(
      column: $state.table.uf,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<int> get idPessoa => $state.composableBuilder(
      column: $state.table.idPessoa,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<int> get idCargo => $state.composableBuilder(
      column: $state.table.idCargo,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<int> get idSetor => $state.composableBuilder(
      column: $state.table.idSetor,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));
}

class $$ViewPessoaColaboradorsTableOrderingComposer
    extends OrderingComposer<_$AppDatabase, $ViewPessoaColaboradorsTable> {
  $$ViewPessoaColaboradorsTableOrderingComposer(super.$state);
  ColumnOrderings<int> get id => $state.composableBuilder(
      column: $state.table.id,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get nome => $state.composableBuilder(
      column: $state.table.nome,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get tipo => $state.composableBuilder(
      column: $state.table.tipo,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get email => $state.composableBuilder(
      column: $state.table.email,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get site => $state.composableBuilder(
      column: $state.table.site,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get cpfCnpj => $state.composableBuilder(
      column: $state.table.cpfCnpj,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get rgIe => $state.composableBuilder(
      column: $state.table.rgIe,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get matricula => $state.composableBuilder(
      column: $state.table.matricula,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<DateTime> get dataCadastro => $state.composableBuilder(
      column: $state.table.dataCadastro,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<DateTime> get dataAdmissao => $state.composableBuilder(
      column: $state.table.dataAdmissao,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<DateTime> get dataDemissao => $state.composableBuilder(
      column: $state.table.dataDemissao,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get ctpsNumero => $state.composableBuilder(
      column: $state.table.ctpsNumero,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get ctpsSerie => $state.composableBuilder(
      column: $state.table.ctpsSerie,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<DateTime> get ctpsDataExpedicao => $state.composableBuilder(
      column: $state.table.ctpsDataExpedicao,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get ctpsUf => $state.composableBuilder(
      column: $state.table.ctpsUf,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get observacao => $state.composableBuilder(
      column: $state.table.observacao,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get logradouro => $state.composableBuilder(
      column: $state.table.logradouro,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get numero => $state.composableBuilder(
      column: $state.table.numero,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get complemento => $state.composableBuilder(
      column: $state.table.complemento,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get bairro => $state.composableBuilder(
      column: $state.table.bairro,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get cidade => $state.composableBuilder(
      column: $state.table.cidade,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get cep => $state.composableBuilder(
      column: $state.table.cep,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get municipioIbge => $state.composableBuilder(
      column: $state.table.municipioIbge,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get uf => $state.composableBuilder(
      column: $state.table.uf,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<int> get idPessoa => $state.composableBuilder(
      column: $state.table.idPessoa,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<int> get idCargo => $state.composableBuilder(
      column: $state.table.idCargo,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<int> get idSetor => $state.composableBuilder(
      column: $state.table.idSetor,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));
}

class $AppDatabaseManager {
  final _$AppDatabase _db;
  $AppDatabaseManager(this._db);
  $$FrotaIpvaControlesTableTableManager get frotaIpvaControles =>
      $$FrotaIpvaControlesTableTableManager(_db, _db.frotaIpvaControles);
  $$FrotaDpvatControlesTableTableManager get frotaDpvatControles =>
      $$FrotaDpvatControlesTableTableManager(_db, _db.frotaDpvatControles);
  $$FrotaVeiculoSinistrosTableTableManager get frotaVeiculoSinistros =>
      $$FrotaVeiculoSinistrosTableTableManager(_db, _db.frotaVeiculoSinistros);
  $$FrotaVeiculoMovimentacaosTableTableManager get frotaVeiculoMovimentacaos =>
      $$FrotaVeiculoMovimentacaosTableTableManager(
          _db, _db.frotaVeiculoMovimentacaos);
  $$FrotaVeiculoPneusTableTableManager get frotaVeiculoPneus =>
      $$FrotaVeiculoPneusTableTableManager(_db, _db.frotaVeiculoPneus);
  $$FrotaVeiculoManutencaosTableTableManager get frotaVeiculoManutencaos =>
      $$FrotaVeiculoManutencaosTableTableManager(
          _db, _db.frotaVeiculoManutencaos);
  $$FrotaMultaControlesTableTableManager get frotaMultaControles =>
      $$FrotaMultaControlesTableTableManager(_db, _db.frotaMultaControles);
  $$FrotaCombustivelControlesTableTableManager get frotaCombustivelControles =>
      $$FrotaCombustivelControlesTableTableManager(
          _db, _db.frotaCombustivelControles);
  $$FrotaVeiculosTableTableManager get frotaVeiculos =>
      $$FrotaVeiculosTableTableManager(_db, _db.frotaVeiculos);
  $$FrotaVeiculoTiposTableTableManager get frotaVeiculoTipos =>
      $$FrotaVeiculoTiposTableTableManager(_db, _db.frotaVeiculoTipos);
  $$FrotaCombustivelTiposTableTableManager get frotaCombustivelTipos =>
      $$FrotaCombustivelTiposTableTableManager(_db, _db.frotaCombustivelTipos);
  $$FrotaMotoristasTableTableManager get frotaMotoristas =>
      $$FrotaMotoristasTableTableManager(_db, _db.frotaMotoristas);
  $$ViewControleAcessosTableTableManager get viewControleAcessos =>
      $$ViewControleAcessosTableTableManager(_db, _db.viewControleAcessos);
  $$ViewPessoaUsuariosTableTableManager get viewPessoaUsuarios =>
      $$ViewPessoaUsuariosTableTableManager(_db, _db.viewPessoaUsuarios);
  $$ViewPessoaColaboradorsTableTableManager get viewPessoaColaboradors =>
      $$ViewPessoaColaboradorsTableTableManager(
          _db, _db.viewPessoaColaboradors);
}
