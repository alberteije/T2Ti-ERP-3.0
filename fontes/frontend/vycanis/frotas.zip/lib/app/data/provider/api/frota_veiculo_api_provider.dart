import 'package:frotas/app/data/provider/api/api_provider_base.dart';
import 'package:frotas/app/data/model/model_imports.dart';

class FrotaVeiculoApiProvider extends ApiProviderBase {
  static const _path = '/frota-veiculo';

  Future<List<FrotaVeiculoModel>?> getList({Filter? filter}) {
    return super.getListBase(
      '$_path/',
      (json) => FrotaVeiculoModel.fromJson(json),
      filter: filter,
    );
  }

  Future<FrotaVeiculoModel?> getObject(dynamic pk) {
    return super.getObjectBase(
      _path,
      pk,
      (json) => FrotaVeiculoModel.fromJson(json),
    );
  }

  Future<FrotaVeiculoModel?>? insert(FrotaVeiculoModel model) {
    return super.insertBase(
      _path,
      model,
      (json) => FrotaVeiculoModel.fromJson(json),
    );
  }

  Future<FrotaVeiculoModel?>? update(FrotaVeiculoModel model) {
    return super.updateBase(
      _path,
      model,
      (json) => FrotaVeiculoModel.fromJson(json),
    );
  }

  Future<bool?> delete(dynamic pk) {
    return super.deleteBase(_path, pk);
  }
}
