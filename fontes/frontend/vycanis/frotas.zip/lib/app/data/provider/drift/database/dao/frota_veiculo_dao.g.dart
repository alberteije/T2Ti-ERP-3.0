// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'frota_veiculo_dao.dart';

// ignore_for_file: type=lint
mixin _$FrotaVeiculoDaoMixin on DatabaseAccessor<AppDatabase> {
  $FrotaVeiculosTable get frotaVeiculos => attachedDatabase.frotaVeiculos;
  $FrotaIpvaControlesTable get frotaIpvaControles =>
      attachedDatabase.frotaIpvaControles;
  $FrotaDpvatControlesTable get frotaDpvatControles =>
      attachedDatabase.frotaDpvatControles;
  $FrotaVeiculoSinistrosTable get frotaVeiculoSinistros =>
      attachedDatabase.frotaVeiculoSinistros;
  $FrotaVeiculoMovimentacaosTable get frotaVeiculoMovimentacaos =>
      attachedDatabase.frotaVeiculoMovimentacaos;
  $FrotaMotoristasTable get frotaMotoristas => attachedDatabase.frotaMotoristas;
  $FrotaVeiculoPneusTable get frotaVeiculoPneus =>
      attachedDatabase.frotaVeiculoPneus;
  $FrotaVeiculoManutencaosTable get frotaVeiculoManutencaos =>
      attachedDatabase.frotaVeiculoManutencaos;
  $FrotaMultaControlesTable get frotaMultaControles =>
      attachedDatabase.frotaMultaControles;
  $FrotaCombustivelControlesTable get frotaCombustivelControles =>
      attachedDatabase.frotaCombustivelControles;
  $FrotaVeiculoTiposTable get frotaVeiculoTipos =>
      attachedDatabase.frotaVeiculoTipos;
  $FrotaCombustivelTiposTable get frotaCombustivelTipos =>
      attachedDatabase.frotaCombustivelTipos;
}
