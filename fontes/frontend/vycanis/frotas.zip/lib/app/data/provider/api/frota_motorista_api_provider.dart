import 'package:frotas/app/data/provider/api/api_provider_base.dart';
import 'package:frotas/app/data/model/model_imports.dart';

class FrotaMotoristaApiProvider extends ApiProviderBase {
  static const _path = '/frota-motorista';

  Future<List<FrotaMotoristaModel>?> getList({Filter? filter}) {
    return super.getListBase(
      '$_path/',
      (json) => FrotaMotoristaModel.fromJson(json),
      filter: filter,
    );
  }

  Future<FrotaMotoristaModel?> getObject(dynamic pk) {
    return super.getObjectBase(
      _path,
      pk,
      (json) => FrotaMotoristaModel.fromJson(json),
    );
  }

  Future<FrotaMotoristaModel?>? insert(FrotaMotoristaModel model) {
    return super.insertBase(
      _path,
      model,
      (json) => FrotaMotoristaModel.fromJson(json),
    );
  }

  Future<FrotaMotoristaModel?>? update(FrotaMotoristaModel model) {
    return super.updateBase(
      _path,
      model,
      (json) => FrotaMotoristaModel.fromJson(json),
    );
  }

  Future<bool?> delete(dynamic pk) {
    return super.deleteBase(_path, pk);
  }
}
