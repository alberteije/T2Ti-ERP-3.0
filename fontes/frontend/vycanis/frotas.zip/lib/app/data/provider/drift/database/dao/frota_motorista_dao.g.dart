// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'frota_motorista_dao.dart';

// ignore_for_file: type=lint
mixin _$FrotaMotoristaDaoMixin on DatabaseAccessor<AppDatabase> {
  $FrotaMotoristasTable get frotaMotoristas => attachedDatabase.frotaMotoristas;
  $ViewPessoaColaboradorsTable get viewPessoaColaboradors =>
      attachedDatabase.viewPessoaColaboradors;
}
