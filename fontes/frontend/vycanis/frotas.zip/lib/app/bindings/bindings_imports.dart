export 'login_bindings.dart';
export 'frota_veiculo_bindings.dart';
export 'frota_veiculo_tipo_bindings.dart';
export 'frota_combustivel_tipo_bindings.dart';
export 'frota_motorista_bindings.dart';