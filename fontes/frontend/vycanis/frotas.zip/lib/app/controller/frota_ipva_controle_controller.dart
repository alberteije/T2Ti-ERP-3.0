import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:pluto_grid/pluto_grid.dart';
import 'package:extended_masked_text/extended_masked_text.dart';
import 'package:frotas/app/page/shared_widget/input/input_imports.dart';

import 'package:frotas/app/page/page_imports.dart';
import 'package:frotas/app/page/shared_widget/message_dialog.dart';
import 'package:frotas/app/page/grid_columns/grid_columns_imports.dart';
import 'package:frotas/app/controller/controller_imports.dart';
import 'package:frotas/app/data/model/model_imports.dart';

class FrotaIpvaControleController extends ControllerBase<FrotaIpvaControleModel, void> {

  FrotaIpvaControleController() : super(repository: null) {
    dbColumns = FrotaIpvaControleModel.dbColumns;
    aliasColumns = FrotaIpvaControleModel.aliasColumns;
    gridColumns = frotaIpvaControleGridColumns();
    functionName = "frota_ipva_controle";
    screenTitle = "IPVA";
  }

  final _frotaIpvaControleModel = FrotaIpvaControleModel().obs;
  FrotaIpvaControleModel get frotaIpvaControleModel => _frotaIpvaControleModel.value;
  set frotaIpvaControleModel(value) => _frotaIpvaControleModel.value = value ?? FrotaIpvaControleModel();

  List<FrotaIpvaControleModel> get frotaIpvaControleModelList => Get.find<FrotaVeiculoController>().currentModel.frotaIpvaControleModelList ?? [];

  final _userMadeChanges = false.obs;
  get userMadeChanges => _userMadeChanges.value;
  set userMadeChanges(value) => _userMadeChanges.value = value;

  final _formWasChangedDetail = false.obs;
  bool get formWasChangedDetail => _formWasChangedDetail.value;
  set formWasChangedDetail(value) => _formWasChangedDetail.value = value;

  late PlutoGridStateManager _plutoGridStateManager;
  @override
  PlutoGridStateManager get plutoGridStateManager => _plutoGridStateManager;
  @override
  set plutoGridStateManager(value) => _plutoGridStateManager = value;

  final frotaIpvaControleScaffoldKey = GlobalKey<ScaffoldState>();
  final frotaIpvaControleFormKey = GlobalKey<FormState>();

  @override
  FrotaIpvaControleModel createNewModel() => FrotaIpvaControleModel();

  @override
  final standardFieldForFilter = FrotaIpvaControleModel.aliasColumns[FrotaIpvaControleModel.dbColumns.indexOf('ano')];

  final anoController = TextEditingController();
  final parcelaController = TextEditingController();
  final dataVencimentoController = DatePickerItemController(null);
  final dataPagamentoController = DatePickerItemController(null);
  final valorController = MoneyMaskedTextController();

  final Map<String, dynamic> mobileConfig = {
    'primaryColumns': ['ano'],
    'secondaryColumns': ['parcela'],
  };

  List<Map<String, dynamic>> get mobileItems {
    return modelList.map((frotaIpvaControle) => frotaIpvaControle.toJson).toList();
  }

  @override
  List<PlutoRow> plutoRows() => List<PlutoRow>.from(frotaIpvaControleModelList.map((model) => model.toPlutoRow()));

  @override
  Future<void> getList({Filter? filter}) async {}

  @override
  void prepareForInsert() {
    isNewRecord = true;
    frotaIpvaControleModel = createNewModel();
    _resetForm();
    Get.to(() => FrotaIpvaControleEditPage());
  }

  void _resetForm() {
    formWasChangedDetail = false;
    anoController.text = '';
    parcelaController.text = '';
    dataVencimentoController.date = null;
    dataPagamentoController.date = null;
    valorController.updateValue(0);
  }

  @override
  void selectRowForEditing(PlutoRow? row) async {
    if (row == null) {
      showInfoSnackBar(message: 'message_select_one_to_edited'.tr);
      return;
    }

    selectRowForEditingByTempId(row.cells['tempId']?.value);
  }

  @override
  void selectRowForEditingById(int id) {}

  void selectRowForEditingByTempId(String tempId) {
		isNewRecord = false;
    final model = frotaIpvaControleModelList.firstWhere((m) => m.tempId == tempId);
    frotaIpvaControleModel = model.clone();
		frotaIpvaControleModel.tempId = model.tempId;
    updateControllersFromModel();
    Get.to(() => FrotaIpvaControleEditPage());
  }

  void updateControllersFromModel() {
    anoController.text = frotaIpvaControleModel.ano ?? '';
    parcelaController.text = frotaIpvaControleModel.parcela ?? '';
    dataVencimentoController.date = frotaIpvaControleModel.dataVencimento;
    dataPagamentoController.date = frotaIpvaControleModel.dataPagamento;
    valorController.updateValue(frotaIpvaControleModel.valor ?? 0);
    formWasChangedDetail = false;
  }

  @override
  Future<void> save() async {
    if (!frotaIpvaControleFormKey.currentState!.validate()) {
      showErrorSnackBar(message: 'validator_form_message'.tr);
      return;
    }

    if (formWasChangedDetail) {
      if (isNewRecord) {
        frotaIpvaControleModelList.insert(0, frotaIpvaControleModel.clone());
      } else {
        final index = frotaIpvaControleModelList.indexWhere((m) => m.tempId == frotaIpvaControleModel.tempId);
        if (index >= 0) {
          frotaIpvaControleModelList[index] = frotaIpvaControleModel.clone();
        }
      }

      userMadeChanges = true;
      loadData();
      Get.back(result: true);
    } else {
      Get.back();
    }
  }


  @override
  Future deleteSelected() async {
    final currentRow = plutoGridStateManager.currentRow;
    if (currentRow == null) {
      showInfoSnackBar(message: 'message_select_one_to_delete'.tr);
      return null;
    }
    showDeleteDialog(() async {
      final id = currentRow.cells['id']?.value;
      final tempId = currentRow.cells['tempId']?.value;
      frotaIpvaControleModelList.removeWhere((model) => (id != 0 && model.id == id) || (id == 0 && model.tempId == tempId));
      plutoGridStateManager.removeCurrentRow();
      userMadeChanges = true;
    });
  }

  @override
  void preventDataLoss() {
    if (formWasChangedDetail) {
      showQuestionDialog('message_data_loss'.tr, () => Get.back());
    } else {
      formWasChangedDetail = false;
      Get.back();
    }
  }

  @override
  void onClose() {
    anoController.dispose();
    parcelaController.dispose();
    dataVencimentoController.dispose();
    dataPagamentoController.dispose();
    valorController.dispose();
  }

}