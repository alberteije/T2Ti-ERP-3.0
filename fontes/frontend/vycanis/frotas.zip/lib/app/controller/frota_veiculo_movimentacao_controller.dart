import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:pluto_grid/pluto_grid.dart';
import 'package:extended_masked_text/extended_masked_text.dart';
import 'package:frotas/app/page/shared_widget/input/input_imports.dart';
import 'package:frotas/app/routes/app_routes.dart';

import 'package:frotas/app/page/page_imports.dart';
import 'package:frotas/app/page/shared_widget/message_dialog.dart';
import 'package:frotas/app/page/grid_columns/grid_columns_imports.dart';
import 'package:frotas/app/controller/controller_imports.dart';
import 'package:frotas/app/data/model/model_imports.dart';

class FrotaVeiculoMovimentacaoController extends ControllerBase<FrotaVeiculoMovimentacaoModel, void> {

  FrotaVeiculoMovimentacaoController() : super(repository: null) {
    dbColumns = FrotaVeiculoMovimentacaoModel.dbColumns;
    aliasColumns = FrotaVeiculoMovimentacaoModel.aliasColumns;
    gridColumns = frotaVeiculoMovimentacaoGridColumns();
    functionName = "frota_veiculo_movimentacao";
    screenTitle = "Movimentação";
  }

  final _frotaVeiculoMovimentacaoModel = FrotaVeiculoMovimentacaoModel().obs;
  FrotaVeiculoMovimentacaoModel get frotaVeiculoMovimentacaoModel => _frotaVeiculoMovimentacaoModel.value;
  set frotaVeiculoMovimentacaoModel(value) => _frotaVeiculoMovimentacaoModel.value = value ?? FrotaVeiculoMovimentacaoModel();

  List<FrotaVeiculoMovimentacaoModel> get frotaVeiculoMovimentacaoModelList => Get.find<FrotaVeiculoController>().currentModel.frotaVeiculoMovimentacaoModelList ?? [];

  final _userMadeChanges = false.obs;
  get userMadeChanges => _userMadeChanges.value;
  set userMadeChanges(value) => _userMadeChanges.value = value;

  final _formWasChangedDetail = false.obs;
  bool get formWasChangedDetail => _formWasChangedDetail.value;
  set formWasChangedDetail(value) => _formWasChangedDetail.value = value;

  late PlutoGridStateManager _plutoGridStateManager;
  @override
  PlutoGridStateManager get plutoGridStateManager => _plutoGridStateManager;
  @override
  set plutoGridStateManager(value) => _plutoGridStateManager = value;

  final frotaVeiculoMovimentacaoScaffoldKey = GlobalKey<ScaffoldState>();
  final frotaVeiculoMovimentacaoFormKey = GlobalKey<FormState>();

  @override
  FrotaVeiculoMovimentacaoModel createNewModel() => FrotaVeiculoMovimentacaoModel();

  @override
  final standardFieldForFilter = FrotaVeiculoMovimentacaoModel.aliasColumns[FrotaVeiculoMovimentacaoModel.dbColumns.indexOf('data_saida')];

  final frotaMotoristaModelController = TextEditingController();
  final dataSaidaController = DatePickerItemController(null);
  final horaSaidaController = MaskedTextController(mask: '00:00:00',);
  final dataEntradaController = DatePickerItemController(null);
  final horaEntradaController = MaskedTextController(mask: '00:00:00',);
  final observacaoController = TextEditingController();

  final Map<String, dynamic> mobileConfig = {
    'primaryColumns': ['data_saida'],
    'secondaryColumns': ['hora_saida'],
  };

  List<Map<String, dynamic>> get mobileItems {
    return modelList.map((frotaVeiculoMovimentacao) => frotaVeiculoMovimentacao.toJson).toList();
  }

  @override
  List<PlutoRow> plutoRows() => List<PlutoRow>.from(frotaVeiculoMovimentacaoModelList.map((model) => model.toPlutoRow()));

  @override
  Future<void> getList({Filter? filter}) async {}

  @override
  void prepareForInsert() {
    isNewRecord = true;
    frotaVeiculoMovimentacaoModel = createNewModel();
    _resetForm();
    Get.to(() => FrotaVeiculoMovimentacaoEditPage());
  }

  void _resetForm() {
    formWasChangedDetail = false;
    frotaMotoristaModelController.text = '';
    dataSaidaController.date = null;
    horaSaidaController.text = '';
    dataEntradaController.date = null;
    horaEntradaController.text = '';
    observacaoController.text = '';
  }

  @override
  void selectRowForEditing(PlutoRow? row) async {
    if (row == null) {
      showInfoSnackBar(message: 'message_select_one_to_edited'.tr);
      return;
    }

    selectRowForEditingByTempId(row.cells['tempId']?.value);
  }

  @override
  void selectRowForEditingById(int id) {}

  void selectRowForEditingByTempId(String tempId) {
		isNewRecord = false;
    final model = frotaVeiculoMovimentacaoModelList.firstWhere((m) => m.tempId == tempId);
    frotaVeiculoMovimentacaoModel = model.clone();
		frotaVeiculoMovimentacaoModel.tempId = model.tempId;
    updateControllersFromModel();
    Get.to(() => FrotaVeiculoMovimentacaoEditPage());
  }

  void updateControllersFromModel() {
    frotaMotoristaModelController.text = frotaVeiculoMovimentacaoModel.frotaMotoristaModel?.nome?.toString() ?? '';
    dataSaidaController.date = frotaVeiculoMovimentacaoModel.dataSaida;
    horaSaidaController.text = frotaVeiculoMovimentacaoModel.horaSaida ?? '';
    dataEntradaController.date = frotaVeiculoMovimentacaoModel.dataEntrada;
    horaEntradaController.text = frotaVeiculoMovimentacaoModel.horaEntrada ?? '';
    observacaoController.text = frotaVeiculoMovimentacaoModel.observacao ?? '';
    formWasChangedDetail = false;
  }

  @override
  Future<void> save() async {
    if (!frotaVeiculoMovimentacaoFormKey.currentState!.validate()) {
      showErrorSnackBar(message: 'validator_form_message'.tr);
      return;
    }

    if (formWasChangedDetail) {
      if (isNewRecord) {
        frotaVeiculoMovimentacaoModelList.insert(0, frotaVeiculoMovimentacaoModel.clone());
      } else {
        final index = frotaVeiculoMovimentacaoModelList.indexWhere((m) => m.tempId == frotaVeiculoMovimentacaoModel.tempId);
        if (index >= 0) {
          frotaVeiculoMovimentacaoModelList[index] = frotaVeiculoMovimentacaoModel.clone();
        }
      }

      userMadeChanges = true;
      loadData();
      Get.back(result: true);
    } else {
      Get.back();
    }
  }

  Future callFrotaMotoristaLookup() async { 
		final lookupController = Get.find<LookupController>(); 
		lookupController.refreshItems(standardValue: '%'); 
		lookupController.title = '${'lookup_page_title'.tr} [Motorista]'; 
		lookupController.route = '/frota-motorista/'; 
		lookupController.gridColumns = frotaMotoristaGridColumns(isForLookup: true); 
		lookupController.aliasColumns = FrotaMotoristaModel.aliasColumns; 
		lookupController.dbColumns = FrotaMotoristaModel.dbColumns; 
		lookupController.standardColumn = FrotaMotoristaModel.aliasColumns[FrotaMotoristaModel.dbColumns.indexOf('nome')]; 

		final plutoRowResult = await Get.toNamed(Routes.lookupPage); 
		if (plutoRowResult != null) { 
			frotaVeiculoMovimentacaoModel.idFrotaMotorista = plutoRowResult.cells['id']!.value; 
			frotaVeiculoMovimentacaoModel.frotaMotoristaModel = FrotaMotoristaModel.fromPlutoRow(plutoRowResult); 
			frotaMotoristaModelController.text = frotaVeiculoMovimentacaoModel.frotaMotoristaModel?.nome ?? ''; 
			formWasChangedDetail = true; 
		}
	}


  @override
  Future deleteSelected() async {
    final currentRow = plutoGridStateManager.currentRow;
    if (currentRow == null) {
      showInfoSnackBar(message: 'message_select_one_to_delete'.tr);
      return null;
    }
    showDeleteDialog(() async {
      final id = currentRow.cells['id']?.value;
      final tempId = currentRow.cells['tempId']?.value;
      frotaVeiculoMovimentacaoModelList.removeWhere((model) => (id != 0 && model.id == id) || (id == 0 && model.tempId == tempId));
      plutoGridStateManager.removeCurrentRow();
      userMadeChanges = true;
    });
  }

  @override
  void preventDataLoss() {
    if (formWasChangedDetail) {
      showQuestionDialog('message_data_loss'.tr, () => Get.back());
    } else {
      formWasChangedDetail = false;
      Get.back();
    }
  }

  @override
  void onClose() {
    frotaMotoristaModelController.dispose();
    dataSaidaController.dispose();
    horaSaidaController.dispose();
    dataEntradaController.dispose();
    horaEntradaController.dispose();
    observacaoController.dispose();
  }

}