import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:pluto_grid/pluto_grid.dart';
import 'package:extended_masked_text/extended_masked_text.dart';
import 'package:frotas/app/page/shared_widget/input/input_imports.dart';

import 'package:frotas/app/page/page_imports.dart';
import 'package:frotas/app/page/shared_widget/message_dialog.dart';
import 'package:frotas/app/page/grid_columns/grid_columns_imports.dart';
import 'package:frotas/app/controller/controller_imports.dart';
import 'package:frotas/app/data/model/model_imports.dart';

class FrotaMultaControleController extends ControllerBase<FrotaMultaControleModel, void> {

  FrotaMultaControleController() : super(repository: null) {
    dbColumns = FrotaMultaControleModel.dbColumns;
    aliasColumns = FrotaMultaControleModel.aliasColumns;
    gridColumns = frotaMultaControleGridColumns();
    functionName = "frota_multa_controle";
    screenTitle = "Multas";
  }

  final _frotaMultaControleModel = FrotaMultaControleModel().obs;
  FrotaMultaControleModel get frotaMultaControleModel => _frotaMultaControleModel.value;
  set frotaMultaControleModel(value) => _frotaMultaControleModel.value = value ?? FrotaMultaControleModel();

  List<FrotaMultaControleModel> get frotaMultaControleModelList => Get.find<FrotaVeiculoController>().currentModel.frotaMultaControleModelList ?? [];

  final _userMadeChanges = false.obs;
  get userMadeChanges => _userMadeChanges.value;
  set userMadeChanges(value) => _userMadeChanges.value = value;

  final _formWasChangedDetail = false.obs;
  bool get formWasChangedDetail => _formWasChangedDetail.value;
  set formWasChangedDetail(value) => _formWasChangedDetail.value = value;

  late PlutoGridStateManager _plutoGridStateManager;
  @override
  PlutoGridStateManager get plutoGridStateManager => _plutoGridStateManager;
  @override
  set plutoGridStateManager(value) => _plutoGridStateManager = value;

  final frotaMultaControleScaffoldKey = GlobalKey<ScaffoldState>();
  final frotaMultaControleFormKey = GlobalKey<FormState>();

  @override
  FrotaMultaControleModel createNewModel() => FrotaMultaControleModel();

  @override
  final standardFieldForFilter = FrotaMultaControleModel.aliasColumns[FrotaMultaControleModel.dbColumns.indexOf('data_multa')];

  final dataMultaController = DatePickerItemController(null);
  final pontosController = MoneyMaskedTextController(precision: 0, decimalSeparator: '', thousandSeparator: '');
  final valorController = MoneyMaskedTextController();
  final observacaoController = TextEditingController();

  final Map<String, dynamic> mobileConfig = {
    'primaryColumns': ['data_multa'],
    'secondaryColumns': ['pontos'],
  };

  List<Map<String, dynamic>> get mobileItems {
    return modelList.map((frotaMultaControle) => frotaMultaControle.toJson).toList();
  }

  @override
  List<PlutoRow> plutoRows() => List<PlutoRow>.from(frotaMultaControleModelList.map((model) => model.toPlutoRow()));

  @override
  Future<void> getList({Filter? filter}) async {}

  @override
  void prepareForInsert() {
    isNewRecord = true;
    frotaMultaControleModel = createNewModel();
    _resetForm();
    Get.to(() => FrotaMultaControleEditPage());
  }

  void _resetForm() {
    formWasChangedDetail = false;
    dataMultaController.date = null;
    pontosController.updateValue(0);
    valorController.updateValue(0);
    observacaoController.text = '';
  }

  @override
  void selectRowForEditing(PlutoRow? row) async {
    if (row == null) {
      showInfoSnackBar(message: 'message_select_one_to_edited'.tr);
      return;
    }

    selectRowForEditingByTempId(row.cells['tempId']?.value);
  }

  @override
  void selectRowForEditingById(int id) {}

  void selectRowForEditingByTempId(String tempId) {
		isNewRecord = false;
    final model = frotaMultaControleModelList.firstWhere((m) => m.tempId == tempId);
    frotaMultaControleModel = model.clone();
		frotaMultaControleModel.tempId = model.tempId;
    updateControllersFromModel();
    Get.to(() => FrotaMultaControleEditPage());
  }

  void updateControllersFromModel() {
    dataMultaController.date = frotaMultaControleModel.dataMulta;
    pontosController.updateValue((frotaMultaControleModel.pontos ?? 0).toDouble());
    valorController.updateValue(frotaMultaControleModel.valor ?? 0);
    observacaoController.text = frotaMultaControleModel.observacao ?? '';
    formWasChangedDetail = false;
  }

  @override
  Future<void> save() async {
    if (!frotaMultaControleFormKey.currentState!.validate()) {
      showErrorSnackBar(message: 'validator_form_message'.tr);
      return;
    }

    if (formWasChangedDetail) {
      if (isNewRecord) {
        frotaMultaControleModelList.insert(0, frotaMultaControleModel.clone());
      } else {
        final index = frotaMultaControleModelList.indexWhere((m) => m.tempId == frotaMultaControleModel.tempId);
        if (index >= 0) {
          frotaMultaControleModelList[index] = frotaMultaControleModel.clone();
        }
      }

      userMadeChanges = true;
      loadData();
      Get.back(result: true);
    } else {
      Get.back();
    }
  }


  @override
  Future deleteSelected() async {
    final currentRow = plutoGridStateManager.currentRow;
    if (currentRow == null) {
      showInfoSnackBar(message: 'message_select_one_to_delete'.tr);
      return null;
    }
    showDeleteDialog(() async {
      final id = currentRow.cells['id']?.value;
      final tempId = currentRow.cells['tempId']?.value;
      frotaMultaControleModelList.removeWhere((model) => (id != 0 && model.id == id) || (id == 0 && model.tempId == tempId));
      plutoGridStateManager.removeCurrentRow();
      userMadeChanges = true;
    });
  }

  @override
  void preventDataLoss() {
    if (formWasChangedDetail) {
      showQuestionDialog('message_data_loss'.tr, () => Get.back());
    } else {
      formWasChangedDetail = false;
      Get.back();
    }
  }

  @override
  void onClose() {
    dataMultaController.dispose();
    pontosController.dispose();
    valorController.dispose();
    observacaoController.dispose();
  }

}