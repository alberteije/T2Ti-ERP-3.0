import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:pluto_grid/pluto_grid.dart';
import 'package:extended_masked_text/extended_masked_text.dart';
import 'package:frotas/app/page/shared_widget/input/input_imports.dart';

import 'package:frotas/app/page/page_imports.dart';
import 'package:frotas/app/page/shared_widget/message_dialog.dart';
import 'package:frotas/app/page/grid_columns/grid_columns_imports.dart';
import 'package:frotas/app/controller/controller_imports.dart';
import 'package:frotas/app/data/model/model_imports.dart';

class FrotaVeiculoPneuController extends ControllerBase<FrotaVeiculoPneuModel, void> {

  FrotaVeiculoPneuController() : super(repository: null) {
    dbColumns = FrotaVeiculoPneuModel.dbColumns;
    aliasColumns = FrotaVeiculoPneuModel.aliasColumns;
    gridColumns = frotaVeiculoPneuGridColumns();
    functionName = "frota_veiculo_pneu";
    screenTitle = "Pneus";
  }

  final _frotaVeiculoPneuModel = FrotaVeiculoPneuModel().obs;
  FrotaVeiculoPneuModel get frotaVeiculoPneuModel => _frotaVeiculoPneuModel.value;
  set frotaVeiculoPneuModel(value) => _frotaVeiculoPneuModel.value = value ?? FrotaVeiculoPneuModel();

  List<FrotaVeiculoPneuModel> get frotaVeiculoPneuModelList => Get.find<FrotaVeiculoController>().currentModel.frotaVeiculoPneuModelList ?? [];

  final _userMadeChanges = false.obs;
  get userMadeChanges => _userMadeChanges.value;
  set userMadeChanges(value) => _userMadeChanges.value = value;

  final _formWasChangedDetail = false.obs;
  bool get formWasChangedDetail => _formWasChangedDetail.value;
  set formWasChangedDetail(value) => _formWasChangedDetail.value = value;

  late PlutoGridStateManager _plutoGridStateManager;
  @override
  PlutoGridStateManager get plutoGridStateManager => _plutoGridStateManager;
  @override
  set plutoGridStateManager(value) => _plutoGridStateManager = value;

  final frotaVeiculoPneuScaffoldKey = GlobalKey<ScaffoldState>();
  final frotaVeiculoPneuFormKey = GlobalKey<FormState>();

  @override
  FrotaVeiculoPneuModel createNewModel() => FrotaVeiculoPneuModel();

  @override
  final standardFieldForFilter = FrotaVeiculoPneuModel.aliasColumns[FrotaVeiculoPneuModel.dbColumns.indexOf('data_troca')];

  final dataTrocaController = DatePickerItemController(null);
  final valorTrocaController = MoneyMaskedTextController();
  final posicaoPneuController = TextEditingController();
  final marcaPneuController = TextEditingController();

  final Map<String, dynamic> mobileConfig = {
    'primaryColumns': ['data_troca'],
    'secondaryColumns': ['valor_troca'],
  };

  List<Map<String, dynamic>> get mobileItems {
    return modelList.map((frotaVeiculoPneu) => frotaVeiculoPneu.toJson).toList();
  }

  @override
  List<PlutoRow> plutoRows() => List<PlutoRow>.from(frotaVeiculoPneuModelList.map((model) => model.toPlutoRow()));

  @override
  Future<void> getList({Filter? filter}) async {}

  @override
  void prepareForInsert() {
    isNewRecord = true;
    frotaVeiculoPneuModel = createNewModel();
    _resetForm();
    Get.to(() => FrotaVeiculoPneuEditPage());
  }

  void _resetForm() {
    formWasChangedDetail = false;
    dataTrocaController.date = null;
    valorTrocaController.updateValue(0);
    posicaoPneuController.text = '';
    marcaPneuController.text = '';
  }

  @override
  void selectRowForEditing(PlutoRow? row) async {
    if (row == null) {
      showInfoSnackBar(message: 'message_select_one_to_edited'.tr);
      return;
    }

    selectRowForEditingByTempId(row.cells['tempId']?.value);
  }

  @override
  void selectRowForEditingById(int id) {}

  void selectRowForEditingByTempId(String tempId) {
		isNewRecord = false;
    final model = frotaVeiculoPneuModelList.firstWhere((m) => m.tempId == tempId);
    frotaVeiculoPneuModel = model.clone();
		frotaVeiculoPneuModel.tempId = model.tempId;
    updateControllersFromModel();
    Get.to(() => FrotaVeiculoPneuEditPage());
  }

  void updateControllersFromModel() {
    dataTrocaController.date = frotaVeiculoPneuModel.dataTroca;
    valorTrocaController.updateValue(frotaVeiculoPneuModel.valorTroca ?? 0);
    posicaoPneuController.text = frotaVeiculoPneuModel.posicaoPneu ?? '';
    marcaPneuController.text = frotaVeiculoPneuModel.marcaPneu ?? '';
    formWasChangedDetail = false;
  }

  @override
  Future<void> save() async {
    if (!frotaVeiculoPneuFormKey.currentState!.validate()) {
      showErrorSnackBar(message: 'validator_form_message'.tr);
      return;
    }

    if (formWasChangedDetail) {
      if (isNewRecord) {
        frotaVeiculoPneuModelList.insert(0, frotaVeiculoPneuModel.clone());
      } else {
        final index = frotaVeiculoPneuModelList.indexWhere((m) => m.tempId == frotaVeiculoPneuModel.tempId);
        if (index >= 0) {
          frotaVeiculoPneuModelList[index] = frotaVeiculoPneuModel.clone();
        }
      }

      userMadeChanges = true;
      loadData();
      Get.back(result: true);
    } else {
      Get.back();
    }
  }


  @override
  Future deleteSelected() async {
    final currentRow = plutoGridStateManager.currentRow;
    if (currentRow == null) {
      showInfoSnackBar(message: 'message_select_one_to_delete'.tr);
      return null;
    }
    showDeleteDialog(() async {
      final id = currentRow.cells['id']?.value;
      final tempId = currentRow.cells['tempId']?.value;
      frotaVeiculoPneuModelList.removeWhere((model) => (id != 0 && model.id == id) || (id == 0 && model.tempId == tempId));
      plutoGridStateManager.removeCurrentRow();
      userMadeChanges = true;
    });
  }

  @override
  void preventDataLoss() {
    if (formWasChangedDetail) {
      showQuestionDialog('message_data_loss'.tr, () => Get.back());
    } else {
      formWasChangedDetail = false;
      Get.back();
    }
  }

  @override
  void onClose() {
    dataTrocaController.dispose();
    valorTrocaController.dispose();
    posicaoPneuController.dispose();
    marcaPneuController.dispose();
  }

}