import 'package:flutter/material.dart';
import 'package:get/get.dart';

import 'package:frotas/app/page/shared_widget/message_dialog.dart';
import 'package:frotas/app/page/grid_columns/grid_columns_imports.dart';
import 'package:frotas/app/routes/app_routes.dart';
import 'package:frotas/app/controller/controller_imports.dart';
import 'package:frotas/app/data/model/model_imports.dart';
import 'package:frotas/app/data/repository/frota_veiculo_tipo_repository.dart';

class FrotaVeiculoTipoController extends ControllerBase<FrotaVeiculoTipoModel, FrotaVeiculoTipoRepository> {

  FrotaVeiculoTipoController({required super.repository}) {
    dbColumns = FrotaVeiculoTipoModel.dbColumns;
    aliasColumns = FrotaVeiculoTipoModel.aliasColumns;
    gridColumns = frotaVeiculoTipoGridColumns();
    functionName = "frota_veiculo_tipo";
    screenTitle = "Tipo Veiculo";
  }

  @override
  FrotaVeiculoTipoModel createNewModel() => FrotaVeiculoTipoModel();

  @override
  final standardFieldForFilter = FrotaVeiculoTipoModel.aliasColumns[FrotaVeiculoTipoModel.dbColumns.indexOf('codigo')];

  final codigoController = TextEditingController();
  final nomeController = TextEditingController();

  final Map<String, dynamic> mobileConfig = {
    'primaryColumns': ['codigo'],
    'secondaryColumns': ['nome'],
  };

  List<Map<String, dynamic>> get mobileItems {
    return modelList.map((frotaVeiculoTipo) => frotaVeiculoTipo.toJson).toList();
  }

  @override
  void prepareForInsert() {
    isNewRecord = true;
    currentModel = createNewModel();
    _resetForm();
    Get.toNamed(Routes.frotaVeiculoTipoEditPage);
  }

  void _resetForm() {
    formWasChanged = false;
    codigoController.text = '';
    nomeController.text = '';
  }

  @override
  void selectRowForEditingById(int id) {
    final model = modelList.firstWhere((m) => m.id == id);
    currentModel = model.clone();
    updateControllersFromModel();
    Get.toNamed(Routes.frotaVeiculoTipoEditPage);
  }

  void updateControllersFromModel() {
    codigoController.text = currentModel.codigo ?? '';
    nomeController.text = currentModel.nome ?? '';
    formWasChanged = false;
  }

  @override
  Future<void> save() async {
    if (!formKey.currentState!.validate()) {
      showErrorSnackBar(message: 'validator_form_message'.tr);
      return;
    }

    final existingIndex = modelList.indexWhere((m) => m.id == currentModel.id);

    if (existingIndex >= 0) {
      modelList[existingIndex] = currentModel.clone();
    }

    final result = await repository.save(frotaVeiculoTipoModel: currentModel);
    if (result == null) return;

    if (existingIndex >= 0) {
      modelList[existingIndex] = result;
    } else {
      modelList.insert(0, result);
    }

    if (!GetPlatform.isMobile) {
      updateGridRow(result);
    }

    Get.back(result: true);
  }


  @override
  void onClose() {
    codigoController.dispose();
    nomeController.dispose();
    super.onClose();
  }

}