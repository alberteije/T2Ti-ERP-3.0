import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:frotas/app/page/shared_widget/input/input_imports.dart';

import 'package:frotas/app/page/shared_widget/message_dialog.dart';
import 'package:frotas/app/page/grid_columns/grid_columns_imports.dart';
import 'package:frotas/app/routes/app_routes.dart';
import 'package:frotas/app/controller/controller_imports.dart';
import 'package:frotas/app/data/model/model_imports.dart';
import 'package:frotas/app/data/repository/frota_motorista_repository.dart';

class FrotaMotoristaController extends ControllerBase<FrotaMotoristaModel, FrotaMotoristaRepository> {

  FrotaMotoristaController({required super.repository}) {
    dbColumns = FrotaMotoristaModel.dbColumns;
    aliasColumns = FrotaMotoristaModel.aliasColumns;
    gridColumns = frotaMotoristaGridColumns();
    functionName = "frota_motorista";
    screenTitle = "Motorista";
  }

  @override
  FrotaMotoristaModel createNewModel() => FrotaMotoristaModel();

  @override
  final standardFieldForFilter = FrotaMotoristaModel.aliasColumns[FrotaMotoristaModel.dbColumns.indexOf('nome')];

  final viewPessoaColaboradorModelController = TextEditingController();
  final nomeController = TextEditingController();
  final numeroCnhController = TextEditingController();
  final cnhCategoriaController = CustomDropdownButtonController('A');

  final Map<String, dynamic> mobileConfig = {
    'primaryColumns': ['nome'],
    'secondaryColumns': ['numero_cnh'],
  };

  List<Map<String, dynamic>> get mobileItems {
    return modelList.map((frotaMotorista) => frotaMotorista.toJson).toList();
  }

  @override
  void prepareForInsert() {
    isNewRecord = true;
    currentModel = createNewModel();
    _resetForm();
    Get.toNamed(Routes.frotaMotoristaEditPage);
  }

  void _resetForm() {
    formWasChanged = false;
    viewPessoaColaboradorModelController.text = '';
    nomeController.text = '';
    numeroCnhController.text = '';
    cnhCategoriaController.selected = 'A';
  }

  @override
  void selectRowForEditingById(int id) {
    final model = modelList.firstWhere((m) => m.id == id);
    currentModel = model.clone();
    updateControllersFromModel();
    Get.toNamed(Routes.frotaMotoristaEditPage);
  }

  void updateControllersFromModel() {
    viewPessoaColaboradorModelController.text = currentModel.viewPessoaColaboradorModel?.nome?.toString() ?? '';
    nomeController.text = currentModel.nome ?? '';
    numeroCnhController.text = currentModel.numeroCnh ?? '';
    cnhCategoriaController.selected = currentModel.cnhCategoria ?? 'A';
    formWasChanged = false;
  }

  @override
  Future<void> save() async {
    if (!formKey.currentState!.validate()) {
      showErrorSnackBar(message: 'validator_form_message'.tr);
      return;
    }

    final existingIndex = modelList.indexWhere((m) => m.id == currentModel.id);

    if (existingIndex >= 0) {
      modelList[existingIndex] = currentModel.clone();
    }

    final result = await repository.save(frotaMotoristaModel: currentModel);
    if (result == null) return;

    if (existingIndex >= 0) {
      modelList[existingIndex] = result;
    } else {
      modelList.insert(0, result);
    }

    if (!GetPlatform.isMobile) {
      updateGridRow(result);
    }

    Get.back(result: true);
  }

  Future callViewPessoaColaboradorLookup() async { 
		final lookupController = Get.find<LookupController>(); 
		lookupController.refreshItems(standardValue: '%'); 
		lookupController.title = '${'lookup_page_title'.tr} [Colaborador]'; 
		lookupController.route = '/view-pessoa-colaborador/'; 
		lookupController.gridColumns = viewPessoaColaboradorGridColumns(isForLookup: true); 
		lookupController.aliasColumns = ViewPessoaColaboradorModel.aliasColumns; 
		lookupController.dbColumns = ViewPessoaColaboradorModel.dbColumns; 
		lookupController.standardColumn = ViewPessoaColaboradorModel.aliasColumns[ViewPessoaColaboradorModel.dbColumns.indexOf('nome')]; 

		final plutoRowResult = await Get.toNamed(Routes.lookupPage); 
		if (plutoRowResult != null) { 
			currentModel.idColaborador = plutoRowResult.cells['id']!.value; 
			currentModel.viewPessoaColaboradorModel = ViewPessoaColaboradorModel.fromPlutoRow(plutoRowResult); 
			viewPessoaColaboradorModelController.text = currentModel.viewPessoaColaboradorModel?.nome ?? ''; 
			formWasChanged = true; 
		}
	}


  @override
  void onClose() {
    viewPessoaColaboradorModelController.dispose();
    nomeController.dispose();
    numeroCnhController.dispose();
    cnhCategoriaController.dispose();
    super.onClose();
  }

}