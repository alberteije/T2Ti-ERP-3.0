import 'package:flutter/material.dart';
import 'dart:math';
import 'package:get/get.dart';
import 'package:frotas/app/page/shared_widget/input/input_imports.dart';

import 'package:frotas/app/infra/infra_imports.dart';
import 'package:frotas/app/page/page_imports.dart';
import 'package:frotas/app/page/shared_widget/message_dialog.dart';
import 'package:frotas/app/page/grid_columns/grid_columns_imports.dart';
import 'package:frotas/app/routes/app_routes.dart';
import 'package:frotas/app/controller/controller_imports.dart';
import 'package:frotas/app/data/model/model_imports.dart';
import 'package:frotas/app/data/repository/frota_veiculo_repository.dart';

class FrotaVeiculoController extends ControllerBase<FrotaVeiculoModel, FrotaVeiculoRepository> 
with GetSingleTickerProviderStateMixin {

  FrotaVeiculoController({required super.repository}) {
    dbColumns = FrotaVeiculoModel.dbColumns;
    aliasColumns = FrotaVeiculoModel.aliasColumns;
    gridColumns = frotaVeiculoGridColumns();
    functionName = "frota_veiculo";
    screenTitle = "Frota Veiculo";
  }

  final frotaVeiculoScaffoldKey = GlobalKey<ScaffoldState>();
  final frotaVeiculoTabPageScaffoldKey = GlobalKey<ScaffoldState>();
  final frotaVeiculoFormKey = GlobalKey<FormState>();
  late TabController tabController;
  String? mandatoryMessage;  

  @override
  FrotaVeiculoModel createNewModel() => FrotaVeiculoModel();

  @override
  final standardFieldForFilter = FrotaVeiculoModel.aliasColumns[FrotaVeiculoModel.dbColumns.indexOf('marca')];

  final frotaVeiculoTipoModelController = TextEditingController();
  final frotaCombustivelTipoModelController = TextEditingController();
  final marcaController = TextEditingController();
  final modeloController = TextEditingController();
  final modeloAnoController = TextEditingController();
  final placaController = TextEditingController();
  final codigoFipeController = TextEditingController();
  final renavamController = TextEditingController();
  final ipvaMesVencimentoController = CustomDropdownButtonController('01');
  final dpvatMesVencimentoController = CustomDropdownButtonController('01');

  final Map<String, dynamic> mobileConfig = {
    'primaryColumns': ['marca'],
    'secondaryColumns': ['modelo'],
  };

  List<Map<String, dynamic>> get mobileItems {
    return modelList.map((frotaVeiculo) => frotaVeiculo.toJson).toList();
  }

  @override
  void prepareForInsert() {
    isNewRecord = true;
    currentModel = createNewModel();
    _resetForm();
    tabController.animateTo(0);
    updateControllersFromModel();
    Get.toNamed(Routes.frotaVeiculoTabPage);
  }

  void _resetForm() {
    formWasChanged = false;
    frotaVeiculoTipoModelController.text = '';
    frotaCombustivelTipoModelController.text = '';
    marcaController.text = '';
    modeloController.text = '';
    modeloAnoController.text = '';
    placaController.text = '';
    codigoFipeController.text = '';
    renavamController.text = '';
    ipvaMesVencimentoController.selected = '01';
    dpvatMesVencimentoController.selected = '01';
  }

  @override
  void selectRowForEditingById(int id) {
    final model = modelList.firstWhere((m) => m.id == id);
    currentModel = model.clone();
    updateControllersFromModel();
    tabController.animateTo(0);
    Get.toNamed(Routes.frotaVeiculoTabPage);
  }

  _configureChildrenControllers() {
    //IPVA
		Get.put<FrotaIpvaControleController>(FrotaIpvaControleController()); 

    //DPVAT
		Get.put<FrotaDpvatControleController>(FrotaDpvatControleController()); 

    //Sinistros
		Get.put<FrotaVeiculoSinistroController>(FrotaVeiculoSinistroController()); 

    //Movimentação
		Get.put<FrotaVeiculoMovimentacaoController>(FrotaVeiculoMovimentacaoController()); 

    //Pneus
		Get.put<FrotaVeiculoPneuController>(FrotaVeiculoPneuController()); 

    //Manutenção
		Get.put<FrotaVeiculoManutencaoController>(FrotaVeiculoManutencaoController()); 

    //Multas
		Get.put<FrotaMultaControleController>(FrotaMultaControleController()); 

    //Controle Combustível
		Get.put<FrotaCombustivelControleController>(FrotaCombustivelControleController()); 

  }
	
	_releaseChildrenControllers() {
    //IPVA
		Get.delete<FrotaIpvaControleController>(); 

    //DPVAT
		Get.delete<FrotaDpvatControleController>(); 

    //Sinistros
		Get.delete<FrotaVeiculoSinistroController>(); 

    //Movimentação
		Get.delete<FrotaVeiculoMovimentacaoController>(); 

    //Pneus
		Get.delete<FrotaVeiculoPneuController>(); 

    //Manutenção
		Get.delete<FrotaVeiculoManutencaoController>(); 

    //Multas
		Get.delete<FrotaMultaControleController>(); 

    //Controle Combustível
		Get.delete<FrotaCombustivelControleController>(); 

	}
  
  void updateControllersFromModel() {
    frotaVeiculoTipoModelController.text = currentModel.frotaVeiculoTipoModel?.nome?.toString() ?? '';
    frotaCombustivelTipoModelController.text = currentModel.frotaCombustivelTipoModel?.nome?.toString() ?? '';
    marcaController.text = currentModel.marca ?? '';
    modeloController.text = currentModel.modelo ?? '';
    modeloAnoController.text = currentModel.modeloAno ?? '';
    placaController.text = currentModel.placa ?? '';
    codigoFipeController.text = currentModel.codigoFipe ?? '';
    renavamController.text = currentModel.renavam ?? '';
    ipvaMesVencimentoController.selected = currentModel.ipvaMesVencimento ?? '01';
    dpvatMesVencimentoController.selected = currentModel.dpvatMesVencimento ?? '01';

    formWasChanged = false;
    _updateChildrenControllersFromModel();
  }

  void _updateChildrenControllersFromModel() {
    //IPVA
		final frotaIpvaControleController = Get.find<FrotaIpvaControleController>(); 
		frotaIpvaControleController.userMadeChanges = false; 

    //DPVAT
		final frotaDpvatControleController = Get.find<FrotaDpvatControleController>(); 
		frotaDpvatControleController.userMadeChanges = false; 

    //Sinistros
		final frotaVeiculoSinistroController = Get.find<FrotaVeiculoSinistroController>(); 
		frotaVeiculoSinistroController.userMadeChanges = false; 

    //Movimentação
		final frotaVeiculoMovimentacaoController = Get.find<FrotaVeiculoMovimentacaoController>(); 
		frotaVeiculoMovimentacaoController.userMadeChanges = false; 

    //Pneus
		final frotaVeiculoPneuController = Get.find<FrotaVeiculoPneuController>(); 
		frotaVeiculoPneuController.userMadeChanges = false; 

    //Manutenção
		final frotaVeiculoManutencaoController = Get.find<FrotaVeiculoManutencaoController>(); 
		frotaVeiculoManutencaoController.userMadeChanges = false; 

    //Multas
		final frotaMultaControleController = Get.find<FrotaMultaControleController>(); 
		frotaMultaControleController.userMadeChanges = false; 

    //Controle Combustível
		final frotaCombustivelControleController = Get.find<FrotaCombustivelControleController>(); 
		frotaCombustivelControleController.userMadeChanges = false; 

  }

  @override
  Future<void> save() async {
    if (!validateCurrentForm()) return;
    if (validateForms()) {
      if (userMadeChanges()) {
        final existingIndex = modelList.indexWhere((m) => m.id == currentModel.id);

        if (existingIndex >= 0) {
          modelList[existingIndex] = currentModel.clone();
        }

        final result = await repository.save(frotaVeiculoModel: currentModel);
        if (result == null) return;

        if (existingIndex >= 0) {
          modelList[existingIndex] = result;
        } else {
          modelList.insert(0, result);
        }

        if (!GetPlatform.isMobile) {
          updateGridRow(result);
        }

        Get.back(result: true);
      } else {
        Get.back();
      }
    } 
  }

  Future callFrotaVeiculoTipoLookup() async { 
		final lookupController = Get.find<LookupController>(); 
		lookupController.refreshItems(standardValue: '%'); 
		lookupController.title = '${'lookup_page_title'.tr} [Tipo]'; 
		lookupController.route = '/frota-veiculo-tipo/'; 
		lookupController.gridColumns = frotaVeiculoTipoGridColumns(isForLookup: true); 
		lookupController.aliasColumns = FrotaVeiculoTipoModel.aliasColumns; 
		lookupController.dbColumns = FrotaVeiculoTipoModel.dbColumns; 
		lookupController.standardColumn = FrotaVeiculoTipoModel.aliasColumns[FrotaVeiculoTipoModel.dbColumns.indexOf('nome')]; 

		final plutoRowResult = await Get.toNamed(Routes.lookupPage); 
		if (plutoRowResult != null) { 
			currentModel.idFrotaVeiculoTipo = plutoRowResult.cells['id']!.value; 
			currentModel.frotaVeiculoTipoModel = FrotaVeiculoTipoModel.fromPlutoRow(plutoRowResult); 
			frotaVeiculoTipoModelController.text = currentModel.frotaVeiculoTipoModel?.nome ?? ''; 
			formWasChanged = true; 
		}
	}

  Future callFrotaCombustivelTipoLookup() async { 
		final lookupController = Get.find<LookupController>(); 
		lookupController.refreshItems(standardValue: '%'); 
		lookupController.title = '${'lookup_page_title'.tr} [Combustivel]'; 
		lookupController.route = '/frota-combustivel-tipo/'; 
		lookupController.gridColumns = frotaCombustivelTipoGridColumns(isForLookup: true); 
		lookupController.aliasColumns = FrotaCombustivelTipoModel.aliasColumns; 
		lookupController.dbColumns = FrotaCombustivelTipoModel.dbColumns; 
		lookupController.standardColumn = FrotaCombustivelTipoModel.aliasColumns[FrotaCombustivelTipoModel.dbColumns.indexOf('nome')]; 

		final plutoRowResult = await Get.toNamed(Routes.lookupPage); 
		if (plutoRowResult != null) { 
			currentModel.idFrotaCombustivelTipo = plutoRowResult.cells['id']!.value; 
			currentModel.frotaCombustivelTipoModel = FrotaCombustivelTipoModel.fromPlutoRow(plutoRowResult); 
			frotaCombustivelTipoModelController.text = currentModel.frotaCombustivelTipoModel?.nome ?? ''; 
			formWasChanged = true; 
		}
	}


  List<Tab> tabItems = [
    Tab( 
			icon: Icon(iconDataList[Random().nextInt(10)]), 
			text: 'Frota Veiculo', 
		),
    Tab( 
			icon: Icon(iconDataList[Random().nextInt(10)]), 
			text: 'IPVA', 
		),
    Tab( 
			icon: Icon(iconDataList[Random().nextInt(10)]), 
			text: 'DPVAT', 
		),
    Tab( 
			icon: Icon(iconDataList[Random().nextInt(10)]), 
			text: 'Sinistros', 
		),
    Tab( 
			icon: Icon(iconDataList[Random().nextInt(10)]), 
			text: 'Movimentação', 
		),
    Tab( 
			icon: Icon(iconDataList[Random().nextInt(10)]), 
			text: 'Pneus', 
		),
    Tab( 
			icon: Icon(iconDataList[Random().nextInt(10)]), 
			text: 'Manutenção', 
		),
    Tab( 
			icon: Icon(iconDataList[Random().nextInt(10)]), 
			text: 'Multas', 
		),
    Tab( 
			icon: Icon(iconDataList[Random().nextInt(10)]), 
			text: 'Controle Combustível', 
		),
  ];

  List<Widget> tabPages() {
    return [
      FrotaVeiculoEditPage(),
      const FrotaIpvaControleListPage(),
      const FrotaDpvatControleListPage(),
      const FrotaVeiculoSinistroListPage(),
      const FrotaVeiculoMovimentacaoListPage(),
      const FrotaVeiculoPneuListPage(),
      const FrotaVeiculoManutencaoListPage(),
      const FrotaMultaControleListPage(),
      const FrotaCombustivelControleListPage(),
    ];
  }

  @override
  void preventDataLoss() {
    if (userMadeChanges()) {
      showQuestionDialog('message_data_loss'.tr, () { 
        Get.back(); 
      });
    } else {
      Get.back();
    }
  }  

  bool userMadeChanges() {
    return
    formWasChanged 
    || 
		Get.find<FrotaIpvaControleController>().userMadeChanges
    || 
		Get.find<FrotaDpvatControleController>().userMadeChanges
    || 
		Get.find<FrotaVeiculoSinistroController>().userMadeChanges
    || 
		Get.find<FrotaVeiculoMovimentacaoController>().userMadeChanges
    || 
		Get.find<FrotaVeiculoPneuController>().userMadeChanges
    || 
		Get.find<FrotaVeiculoManutencaoController>().userMadeChanges
    || 
		Get.find<FrotaMultaControleController>().userMadeChanges
    || 
		Get.find<FrotaCombustivelControleController>().userMadeChanges
    ;
  }

  void tabChange(int index) {
    validateCurrentForm();
  }

  bool validateCurrentForm() {
    mandatoryMessage = ValidateFormField.validateMandatory(currentModel.frotaVeiculoTipoModel?.nome); 
		if (mandatoryMessage != null) { 
			tabController.animateTo(0); 
			showErrorSnackBar(message: '$mandatoryMessage [Tipo]'); 
			return false; 
		}
    mandatoryMessage = ValidateFormField.validateMandatory(currentModel.frotaCombustivelTipoModel?.nome); 
		if (mandatoryMessage != null) { 
			tabController.animateTo(0); 
			showErrorSnackBar(message: '$mandatoryMessage [Combustivel]'); 
			return false; 
		}
    return true;
  }

  bool validateForms() {
    return true;
  }

  @override
  void onInit() {
    super.onInit();
    tabController = TabController(vsync: this, length: tabItems.length);
    _configureChildrenControllers();
  }
	
  @override
  void onClose() {
    tabController.dispose();
    frotaVeiculoTipoModelController.dispose();
    frotaCombustivelTipoModelController.dispose();
    marcaController.dispose();
    modeloController.dispose();
    modeloAnoController.dispose();
    placaController.dispose();
    codigoFipeController.dispose();
    renavamController.dispose();
    ipvaMesVencimentoController.dispose();
    dpvatMesVencimentoController.dispose();
    _releaseChildrenControllers();
    super.onClose();
  }	
}