import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:pluto_grid/pluto_grid.dart';
import 'package:extended_masked_text/extended_masked_text.dart';
import 'package:frotas/app/page/shared_widget/input/input_imports.dart';

import 'package:frotas/app/page/page_imports.dart';
import 'package:frotas/app/page/shared_widget/message_dialog.dart';
import 'package:frotas/app/page/grid_columns/grid_columns_imports.dart';
import 'package:frotas/app/controller/controller_imports.dart';
import 'package:frotas/app/data/model/model_imports.dart';

class FrotaVeiculoManutencaoController extends ControllerBase<FrotaVeiculoManutencaoModel, void> {

  FrotaVeiculoManutencaoController() : super(repository: null) {
    dbColumns = FrotaVeiculoManutencaoModel.dbColumns;
    aliasColumns = FrotaVeiculoManutencaoModel.aliasColumns;
    gridColumns = frotaVeiculoManutencaoGridColumns();
    functionName = "frota_veiculo_manutencao";
    screenTitle = "Manutenção";
  }

  final _frotaVeiculoManutencaoModel = FrotaVeiculoManutencaoModel().obs;
  FrotaVeiculoManutencaoModel get frotaVeiculoManutencaoModel => _frotaVeiculoManutencaoModel.value;
  set frotaVeiculoManutencaoModel(value) => _frotaVeiculoManutencaoModel.value = value ?? FrotaVeiculoManutencaoModel();

  List<FrotaVeiculoManutencaoModel> get frotaVeiculoManutencaoModelList => Get.find<FrotaVeiculoController>().currentModel.frotaVeiculoManutencaoModelList ?? [];

  final _userMadeChanges = false.obs;
  get userMadeChanges => _userMadeChanges.value;
  set userMadeChanges(value) => _userMadeChanges.value = value;

  final _formWasChangedDetail = false.obs;
  bool get formWasChangedDetail => _formWasChangedDetail.value;
  set formWasChangedDetail(value) => _formWasChangedDetail.value = value;

  late PlutoGridStateManager _plutoGridStateManager;
  @override
  PlutoGridStateManager get plutoGridStateManager => _plutoGridStateManager;
  @override
  set plutoGridStateManager(value) => _plutoGridStateManager = value;

  final frotaVeiculoManutencaoScaffoldKey = GlobalKey<ScaffoldState>();
  final frotaVeiculoManutencaoFormKey = GlobalKey<FormState>();

  @override
  FrotaVeiculoManutencaoModel createNewModel() => FrotaVeiculoManutencaoModel();

  @override
  final standardFieldForFilter = FrotaVeiculoManutencaoModel.aliasColumns[FrotaVeiculoManutencaoModel.dbColumns.indexOf('tipo')];

  final tipoController = CustomDropdownButtonController('Preventiva');
  final dataManutencaoController = DatePickerItemController(null);
  final valorManutencaoController = MoneyMaskedTextController();
  final observacaoController = TextEditingController();

  final Map<String, dynamic> mobileConfig = {
    'primaryColumns': ['tipo'],
    'secondaryColumns': ['data_manutencao'],
  };

  List<Map<String, dynamic>> get mobileItems {
    return modelList.map((frotaVeiculoManutencao) => frotaVeiculoManutencao.toJson).toList();
  }

  @override
  List<PlutoRow> plutoRows() => List<PlutoRow>.from(frotaVeiculoManutencaoModelList.map((model) => model.toPlutoRow()));

  @override
  Future<void> getList({Filter? filter}) async {}

  @override
  void prepareForInsert() {
    isNewRecord = true;
    frotaVeiculoManutencaoModel = createNewModel();
    _resetForm();
    Get.to(() => FrotaVeiculoManutencaoEditPage());
  }

  void _resetForm() {
    formWasChangedDetail = false;
    tipoController.selected = 'Preventiva';
    dataManutencaoController.date = null;
    valorManutencaoController.updateValue(0);
    observacaoController.text = '';
  }

  @override
  void selectRowForEditing(PlutoRow? row) async {
    if (row == null) {
      showInfoSnackBar(message: 'message_select_one_to_edited'.tr);
      return;
    }

    selectRowForEditingByTempId(row.cells['tempId']?.value);
  }

  @override
  void selectRowForEditingById(int id) {}

  void selectRowForEditingByTempId(String tempId) {
		isNewRecord = false;
    final model = frotaVeiculoManutencaoModelList.firstWhere((m) => m.tempId == tempId);
    frotaVeiculoManutencaoModel = model.clone();
		frotaVeiculoManutencaoModel.tempId = model.tempId;
    updateControllersFromModel();
    Get.to(() => FrotaVeiculoManutencaoEditPage());
  }

  void updateControllersFromModel() {
    tipoController.selected = frotaVeiculoManutencaoModel.tipo ?? 'Preventiva';
    dataManutencaoController.date = frotaVeiculoManutencaoModel.dataManutencao;
    valorManutencaoController.updateValue(frotaVeiculoManutencaoModel.valorManutencao ?? 0);
    observacaoController.text = frotaVeiculoManutencaoModel.observacao ?? '';
    formWasChangedDetail = false;
  }

  @override
  Future<void> save() async {
    if (!frotaVeiculoManutencaoFormKey.currentState!.validate()) {
      showErrorSnackBar(message: 'validator_form_message'.tr);
      return;
    }

    if (formWasChangedDetail) {
      if (isNewRecord) {
        frotaVeiculoManutencaoModelList.insert(0, frotaVeiculoManutencaoModel.clone());
      } else {
        final index = frotaVeiculoManutencaoModelList.indexWhere((m) => m.tempId == frotaVeiculoManutencaoModel.tempId);
        if (index >= 0) {
          frotaVeiculoManutencaoModelList[index] = frotaVeiculoManutencaoModel.clone();
        }
      }

      userMadeChanges = true;
      loadData();
      Get.back(result: true);
    } else {
      Get.back();
    }
  }


  @override
  Future deleteSelected() async {
    final currentRow = plutoGridStateManager.currentRow;
    if (currentRow == null) {
      showInfoSnackBar(message: 'message_select_one_to_delete'.tr);
      return null;
    }
    showDeleteDialog(() async {
      final id = currentRow.cells['id']?.value;
      final tempId = currentRow.cells['tempId']?.value;
      frotaVeiculoManutencaoModelList.removeWhere((model) => (id != 0 && model.id == id) || (id == 0 && model.tempId == tempId));
      plutoGridStateManager.removeCurrentRow();
      userMadeChanges = true;
    });
  }

  @override
  void preventDataLoss() {
    if (formWasChangedDetail) {
      showQuestionDialog('message_data_loss'.tr, () => Get.back());
    } else {
      formWasChangedDetail = false;
      Get.back();
    }
  }

  @override
  void onClose() {
    tipoController.dispose();
    dataManutencaoController.dispose();
    valorManutencaoController.dispose();
    observacaoController.dispose();
  }

}