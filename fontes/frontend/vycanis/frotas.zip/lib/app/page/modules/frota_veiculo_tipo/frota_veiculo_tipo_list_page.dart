import 'package:flutter/material.dart';
import 'package:frotas/app/controller/frota_veiculo_tipo_controller.dart';
import 'package:frotas/app/page/shared_page/list_page_base.dart';

class FrotaVeiculoTipoListPage extends ListPageBase<FrotaVeiculoTipoController> {
  const FrotaVeiculoTipoListPage({Key? key}) : super(key: key);

  @override
  List<Map<String, dynamic>> get mobileItems => controller.mobileItems;

  @override
  Map<String, dynamic> get mobileConfig => controller.mobileConfig;

  @override
  String get standardFieldForFilter => controller.standardFieldForFilter;
}