import 'package:wms/app/infra/constants.dart';
import 'package:wms/app/data/provider/api/wms_armazenamento_api_provider.dart';
import 'package:wms/app/data/provider/drift/wms_armazenamento_drift_provider.dart';
import 'package:wms/app/data/model/model_imports.dart';

class WmsArmazenamentoRepository {
  final WmsArmazenamentoApiProvider wmsArmazenamentoApiProvider;
  final WmsArmazenamentoDriftProvider wmsArmazenamentoDriftProvider;

  WmsArmazenamentoRepository({required this.wmsArmazenamentoApiProvider, required this.wmsArmazenamentoDriftProvider});

  Future getList({Filter? filter}) async {
    if (Constants.usingLocalDatabase) {
      return await wmsArmazenamentoDriftProvider.getList(filter: filter);
    } else {
      return await wmsArmazenamentoApiProvider.getList(filter: filter);
    }
  }

  Future<WmsArmazenamentoModel?>? save({required WmsArmazenamentoModel wmsArmazenamentoModel}) async {
    if (wmsArmazenamentoModel.id != null) {
      if (Constants.usingLocalDatabase) {
        return await wmsArmazenamentoDriftProvider.update(wmsArmazenamentoModel);
      } else {
        return await wmsArmazenamentoApiProvider.update(wmsArmazenamentoModel);
      }
    } else {
      if (Constants.usingLocalDatabase) {
        return await wmsArmazenamentoDriftProvider.insert(wmsArmazenamentoModel);
      } else {
        return await wmsArmazenamentoApiProvider.insert(wmsArmazenamentoModel);
      }
    }   
  }

  Future<bool> delete({required int id}) async {
    if (Constants.usingLocalDatabase) {
      return await wmsArmazenamentoDriftProvider.delete(id) ?? false;
    } else {
      return await wmsArmazenamentoApiProvider.delete(id) ?? false;
    }
  }
}