import 'package:wms/app/data/provider/drift/database/database_imports.dart';
import 'package:wms/app/infra/infra_imports.dart';
import 'package:wms/app/data/provider/provider_base.dart';
import 'package:wms/app/data/provider/drift/database/database.dart';
import 'package:wms/app/data/model/model_imports.dart';

class WmsArmazenamentoDriftProvider extends ProviderBase {

	Future<List<WmsArmazenamentoModel>?> getList({Filter? filter}) async {
		List<WmsArmazenamentoGrouped> wmsArmazenamentoDriftList = [];

		try {
			if (filter != null && filter.field != null) {
				wmsArmazenamentoDriftList = await Session.database.wmsArmazenamentoDao.getGroupedList(field: filter.field, value: filter.value!);
			} else {
				wmsArmazenamentoDriftList = await Session.database.wmsArmazenamentoDao.getGroupedList(); 
			}
			if (wmsArmazenamentoDriftList.isNotEmpty) {
				return toListModel(wmsArmazenamentoDriftList);
			} else {
				return [];
			}			 
		} catch (e) {
			handleResultError(null, null, exception: e);
			return null;
		}
	}

	Future<WmsArmazenamentoModel?> getObject(dynamic pk) async {
		try {
			final result = await Session.database.wmsArmazenamentoDao.getObjectGrouped(field: 'id', value: pk);
			return toModel(result);
		} catch (e) {
			handleResultError(null, null, exception: e);
		}
		return null;
	}

	Future<WmsArmazenamentoModel?>? insert(WmsArmazenamentoModel wmsArmazenamentoModel) async {
		try {
			final lastPk = await Session.database.wmsArmazenamentoDao.insertObject(toDrift(wmsArmazenamentoModel));
			wmsArmazenamentoModel.id = lastPk;
			return wmsArmazenamentoModel;
		} catch (e) {
			handleResultError(null, null, exception: e);
		}
		return null;
	}

	Future<WmsArmazenamentoModel?>? update(WmsArmazenamentoModel wmsArmazenamentoModel) async {
		try {
			await Session.database.wmsArmazenamentoDao.updateObject(toDrift(wmsArmazenamentoModel));
			return wmsArmazenamentoModel;
		} catch (e) {
			handleResultError(null, null, exception: e);
		}
		return null;
	}

	Future<bool?> delete(dynamic pk) async {
		try {
			await Session.database.wmsArmazenamentoDao.deleteObject(toDrift(WmsArmazenamentoModel(id: pk)));
			return true;
		} catch (e) {
			handleResultError(null, null, exception: e);
		}
		return null;
	}	

	List<WmsArmazenamentoModel> toListModel(List<WmsArmazenamentoGrouped> wmsArmazenamentoDriftList) {
		List<WmsArmazenamentoModel> listModel = [];
		for (var wmsArmazenamentoDrift in wmsArmazenamentoDriftList) {
			listModel.add(toModel(wmsArmazenamentoDrift)!);
		}
		return listModel;
	}	

	WmsArmazenamentoModel? toModel(WmsArmazenamentoGrouped? wmsArmazenamentoDrift) {
		if (wmsArmazenamentoDrift != null) {
			return WmsArmazenamentoModel(
				id: wmsArmazenamentoDrift.wmsArmazenamento?.id,
				idWmsRecebimentoCabecalho: wmsArmazenamentoDrift.wmsArmazenamento?.idWmsRecebimentoCabecalho,
				idProduto: wmsArmazenamentoDrift.wmsArmazenamento?.idProduto,
				idWmsCaixa: wmsArmazenamentoDrift.wmsArmazenamento?.idWmsCaixa,
				quantidade: wmsArmazenamentoDrift.wmsArmazenamento?.quantidade,
				dataArmazenagem: wmsArmazenamentoDrift.wmsArmazenamento?.dataArmazenagem,
				horaArmazenagem: wmsArmazenamentoDrift.wmsArmazenamento?.horaArmazenagem,
				wmsCaixaModel: WmsCaixaModel(
					id: wmsArmazenamentoDrift.wmsCaixa?.id,
					idWmsEstante: wmsArmazenamentoDrift.wmsCaixa?.idWmsEstante,
					codigo: wmsArmazenamentoDrift.wmsCaixa?.codigo,
					altura: wmsArmazenamentoDrift.wmsCaixa?.altura,
					largura: wmsArmazenamentoDrift.wmsCaixa?.largura,
					profundidade: wmsArmazenamentoDrift.wmsCaixa?.profundidade,
				),
				wmsRecebimentoCabecalhoModel: WmsRecebimentoCabecalhoModel(
					id: wmsArmazenamentoDrift.wmsRecebimentoCabecalho?.id,
					idWmsAgendamento: wmsArmazenamentoDrift.wmsRecebimentoCabecalho?.idWmsAgendamento,
					dataRecebimento: wmsArmazenamentoDrift.wmsRecebimentoCabecalho?.dataRecebimento,
					horaInicio: wmsArmazenamentoDrift.wmsRecebimentoCabecalho?.horaInicio,
					horaFim: wmsArmazenamentoDrift.wmsRecebimentoCabecalho?.horaFim,
					volumeRecebido: wmsArmazenamentoDrift.wmsRecebimentoCabecalho?.volumeRecebido,
					pesoRecebido: wmsArmazenamentoDrift.wmsRecebimentoCabecalho?.pesoRecebido,
					inconsistencia: wmsArmazenamentoDrift.wmsRecebimentoCabecalho?.inconsistencia,
					codigoRecebimento: wmsArmazenamentoDrift.wmsRecebimentoCabecalho?.codigoRecebimento,
					observacao: wmsArmazenamentoDrift.wmsRecebimentoCabecalho?.observacao,
				),
				produtoModel: ProdutoModel(
					id: wmsArmazenamentoDrift.produto?.id,
					idTributIcmsCustomCab: wmsArmazenamentoDrift.produto?.idTributIcmsCustomCab,
					idTributGrupoTributario: wmsArmazenamentoDrift.produto?.idTributGrupoTributario,
					nome: wmsArmazenamentoDrift.produto?.nome,
					descricao: wmsArmazenamentoDrift.produto?.descricao,
					gtin: wmsArmazenamentoDrift.produto?.gtin,
					codigoInterno: wmsArmazenamentoDrift.produto?.codigoInterno,
					valorCompra: wmsArmazenamentoDrift.produto?.valorCompra,
					valorVenda: wmsArmazenamentoDrift.produto?.valorVenda,
					codigoNcm: wmsArmazenamentoDrift.produto?.codigoNcm,
					estoqueMinimo: wmsArmazenamentoDrift.produto?.estoqueMinimo,
					estoqueMaximo: wmsArmazenamentoDrift.produto?.estoqueMaximo,
					quantidadeEstoque: wmsArmazenamentoDrift.produto?.quantidadeEstoque,
					dataCadastro: wmsArmazenamentoDrift.produto?.dataCadastro,
				),
			);
		} else {
			return null;
		}
	}


	WmsArmazenamentoGrouped toDrift(WmsArmazenamentoModel wmsArmazenamentoModel) {
		return WmsArmazenamentoGrouped(
			wmsArmazenamento: WmsArmazenamento(
				id: wmsArmazenamentoModel.id,
				idWmsRecebimentoCabecalho: wmsArmazenamentoModel.idWmsRecebimentoCabecalho,
				idProduto: wmsArmazenamentoModel.idProduto,
				idWmsCaixa: wmsArmazenamentoModel.idWmsCaixa,
				quantidade: wmsArmazenamentoModel.quantidade,
				dataArmazenagem: wmsArmazenamentoModel.dataArmazenagem,
				horaArmazenagem: Util.removeMask(wmsArmazenamentoModel.horaArmazenagem),
			),
		);
	}

		
}
