import 'package:wms/app/data/provider/api/api_provider_base.dart';
import 'package:wms/app/data/model/model_imports.dart';

class WmsArmazenamentoApiProvider extends ApiProviderBase {
  static const _path = '/wms-armazenamento';

  Future<List<WmsArmazenamentoModel>?> getList({Filter? filter}) {
    return super.getListBase(
      '$_path/',
      (json) => WmsArmazenamentoModel.fromJson(json),
      filter: filter,
    );
  }

  Future<WmsArmazenamentoModel?> getObject(dynamic pk) {
    return super.getObjectBase(
      _path,
      pk,
      (json) => WmsArmazenamentoModel.fromJson(json),
    );
  }

  Future<WmsArmazenamentoModel?>? insert(WmsArmazenamentoModel model) {
    return super.insertBase(
      _path,
      model,
      (json) => WmsArmazenamentoModel.fromJson(json),
    );
  }

  Future<WmsArmazenamentoModel?>? update(WmsArmazenamentoModel model) {
    return super.updateBase(
      _path,
      model,
      (json) => WmsArmazenamentoModel.fromJson(json),
    );
  }

  Future<bool?> delete(dynamic pk) {
    return super.deleteBase(_path, pk);
  }
}
