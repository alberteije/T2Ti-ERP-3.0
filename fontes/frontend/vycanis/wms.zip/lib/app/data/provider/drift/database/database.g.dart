// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'database.dart';

// ignore_for_file: type=lint
class $WmsRecebimentoDetalhesTable extends WmsRecebimentoDetalhes
    with TableInfo<$WmsRecebimentoDetalhesTable, WmsRecebimentoDetalhe> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $WmsRecebimentoDetalhesTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
    'id',
    aliasedName,
    true,
    type: DriftSqlType.int,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _idWmsRecebimentoCabecalhoMeta =
      const VerificationMeta('idWmsRecebimentoCabecalho');
  @override
  late final GeneratedColumn<int> idWmsRecebimentoCabecalho =
      GeneratedColumn<int>(
        'id_wms_recebimento_cabecalho',
        aliasedName,
        true,
        type: DriftSqlType.int,
        requiredDuringInsert: false,
      );
  static const VerificationMeta _idProdutoMeta = const VerificationMeta(
    'idProduto',
  );
  @override
  late final GeneratedColumn<int> idProduto = GeneratedColumn<int>(
    'id_produto',
    aliasedName,
    true,
    type: DriftSqlType.int,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _quantidadeVolumeMeta = const VerificationMeta(
    'quantidadeVolume',
  );
  @override
  late final GeneratedColumn<int> quantidadeVolume = GeneratedColumn<int>(
    'quantidade_volume',
    aliasedName,
    true,
    type: DriftSqlType.int,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _quantidadeItemPorVolumeMeta =
      const VerificationMeta('quantidadeItemPorVolume');
  @override
  late final GeneratedColumn<int> quantidadeItemPorVolume =
      GeneratedColumn<int>(
        'quantidade_item_por_volume',
        aliasedName,
        true,
        type: DriftSqlType.int,
        requiredDuringInsert: false,
      );
  static const VerificationMeta _quantidadeRecebidaMeta =
      const VerificationMeta('quantidadeRecebida');
  @override
  late final GeneratedColumn<int> quantidadeRecebida = GeneratedColumn<int>(
    'quantidade_recebida',
    aliasedName,
    true,
    type: DriftSqlType.int,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _destinoMeta = const VerificationMeta(
    'destino',
  );
  @override
  late final GeneratedColumn<String> destino = GeneratedColumn<String>(
    'destino',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 1,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  @override
  List<GeneratedColumn> get $columns => [
    id,
    idWmsRecebimentoCabecalho,
    idProduto,
    quantidadeVolume,
    quantidadeItemPorVolume,
    quantidadeRecebida,
    destino,
  ];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'wms_recebimento_detalhe';
  @override
  VerificationContext validateIntegrity(
    Insertable<WmsRecebimentoDetalhe> instance, {
    bool isInserting = false,
  }) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('id_wms_recebimento_cabecalho')) {
      context.handle(
        _idWmsRecebimentoCabecalhoMeta,
        idWmsRecebimentoCabecalho.isAcceptableOrUnknown(
          data['id_wms_recebimento_cabecalho']!,
          _idWmsRecebimentoCabecalhoMeta,
        ),
      );
    }
    if (data.containsKey('id_produto')) {
      context.handle(
        _idProdutoMeta,
        idProduto.isAcceptableOrUnknown(data['id_produto']!, _idProdutoMeta),
      );
    }
    if (data.containsKey('quantidade_volume')) {
      context.handle(
        _quantidadeVolumeMeta,
        quantidadeVolume.isAcceptableOrUnknown(
          data['quantidade_volume']!,
          _quantidadeVolumeMeta,
        ),
      );
    }
    if (data.containsKey('quantidade_item_por_volume')) {
      context.handle(
        _quantidadeItemPorVolumeMeta,
        quantidadeItemPorVolume.isAcceptableOrUnknown(
          data['quantidade_item_por_volume']!,
          _quantidadeItemPorVolumeMeta,
        ),
      );
    }
    if (data.containsKey('quantidade_recebida')) {
      context.handle(
        _quantidadeRecebidaMeta,
        quantidadeRecebida.isAcceptableOrUnknown(
          data['quantidade_recebida']!,
          _quantidadeRecebidaMeta,
        ),
      );
    }
    if (data.containsKey('destino')) {
      context.handle(
        _destinoMeta,
        destino.isAcceptableOrUnknown(data['destino']!, _destinoMeta),
      );
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  WmsRecebimentoDetalhe map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return WmsRecebimentoDetalhe(
      id: attachedDatabase.typeMapping.read(
        DriftSqlType.int,
        data['${effectivePrefix}id'],
      ),
      idWmsRecebimentoCabecalho: attachedDatabase.typeMapping.read(
        DriftSqlType.int,
        data['${effectivePrefix}id_wms_recebimento_cabecalho'],
      ),
      idProduto: attachedDatabase.typeMapping.read(
        DriftSqlType.int,
        data['${effectivePrefix}id_produto'],
      ),
      quantidadeVolume: attachedDatabase.typeMapping.read(
        DriftSqlType.int,
        data['${effectivePrefix}quantidade_volume'],
      ),
      quantidadeItemPorVolume: attachedDatabase.typeMapping.read(
        DriftSqlType.int,
        data['${effectivePrefix}quantidade_item_por_volume'],
      ),
      quantidadeRecebida: attachedDatabase.typeMapping.read(
        DriftSqlType.int,
        data['${effectivePrefix}quantidade_recebida'],
      ),
      destino: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}destino'],
      ),
    );
  }

  @override
  $WmsRecebimentoDetalhesTable createAlias(String alias) {
    return $WmsRecebimentoDetalhesTable(attachedDatabase, alias);
  }
}

class WmsRecebimentoDetalhe extends DataClass
    implements Insertable<WmsRecebimentoDetalhe> {
  final int? id;
  final int? idWmsRecebimentoCabecalho;
  final int? idProduto;
  final int? quantidadeVolume;
  final int? quantidadeItemPorVolume;
  final int? quantidadeRecebida;
  final String? destino;
  const WmsRecebimentoDetalhe({
    this.id,
    this.idWmsRecebimentoCabecalho,
    this.idProduto,
    this.quantidadeVolume,
    this.quantidadeItemPorVolume,
    this.quantidadeRecebida,
    this.destino,
  });
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || idWmsRecebimentoCabecalho != null) {
      map['id_wms_recebimento_cabecalho'] = Variable<int>(
        idWmsRecebimentoCabecalho,
      );
    }
    if (!nullToAbsent || idProduto != null) {
      map['id_produto'] = Variable<int>(idProduto);
    }
    if (!nullToAbsent || quantidadeVolume != null) {
      map['quantidade_volume'] = Variable<int>(quantidadeVolume);
    }
    if (!nullToAbsent || quantidadeItemPorVolume != null) {
      map['quantidade_item_por_volume'] = Variable<int>(
        quantidadeItemPorVolume,
      );
    }
    if (!nullToAbsent || quantidadeRecebida != null) {
      map['quantidade_recebida'] = Variable<int>(quantidadeRecebida);
    }
    if (!nullToAbsent || destino != null) {
      map['destino'] = Variable<String>(destino);
    }
    return map;
  }

  factory WmsRecebimentoDetalhe.fromJson(
    Map<String, dynamic> json, {
    ValueSerializer? serializer,
  }) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return WmsRecebimentoDetalhe(
      id: serializer.fromJson<int?>(json['id']),
      idWmsRecebimentoCabecalho: serializer.fromJson<int?>(
        json['idWmsRecebimentoCabecalho'],
      ),
      idProduto: serializer.fromJson<int?>(json['idProduto']),
      quantidadeVolume: serializer.fromJson<int?>(json['quantidadeVolume']),
      quantidadeItemPorVolume: serializer.fromJson<int?>(
        json['quantidadeItemPorVolume'],
      ),
      quantidadeRecebida: serializer.fromJson<int?>(json['quantidadeRecebida']),
      destino: serializer.fromJson<String?>(json['destino']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'idWmsRecebimentoCabecalho': serializer.toJson<int?>(
        idWmsRecebimentoCabecalho,
      ),
      'idProduto': serializer.toJson<int?>(idProduto),
      'quantidadeVolume': serializer.toJson<int?>(quantidadeVolume),
      'quantidadeItemPorVolume': serializer.toJson<int?>(
        quantidadeItemPorVolume,
      ),
      'quantidadeRecebida': serializer.toJson<int?>(quantidadeRecebida),
      'destino': serializer.toJson<String?>(destino),
    };
  }

  WmsRecebimentoDetalhe copyWith({
    Value<int?> id = const Value.absent(),
    Value<int?> idWmsRecebimentoCabecalho = const Value.absent(),
    Value<int?> idProduto = const Value.absent(),
    Value<int?> quantidadeVolume = const Value.absent(),
    Value<int?> quantidadeItemPorVolume = const Value.absent(),
    Value<int?> quantidadeRecebida = const Value.absent(),
    Value<String?> destino = const Value.absent(),
  }) => WmsRecebimentoDetalhe(
    id: id.present ? id.value : this.id,
    idWmsRecebimentoCabecalho:
        idWmsRecebimentoCabecalho.present
            ? idWmsRecebimentoCabecalho.value
            : this.idWmsRecebimentoCabecalho,
    idProduto: idProduto.present ? idProduto.value : this.idProduto,
    quantidadeVolume:
        quantidadeVolume.present
            ? quantidadeVolume.value
            : this.quantidadeVolume,
    quantidadeItemPorVolume:
        quantidadeItemPorVolume.present
            ? quantidadeItemPorVolume.value
            : this.quantidadeItemPorVolume,
    quantidadeRecebida:
        quantidadeRecebida.present
            ? quantidadeRecebida.value
            : this.quantidadeRecebida,
    destino: destino.present ? destino.value : this.destino,
  );
  WmsRecebimentoDetalhe copyWithCompanion(
    WmsRecebimentoDetalhesCompanion data,
  ) {
    return WmsRecebimentoDetalhe(
      id: data.id.present ? data.id.value : this.id,
      idWmsRecebimentoCabecalho:
          data.idWmsRecebimentoCabecalho.present
              ? data.idWmsRecebimentoCabecalho.value
              : this.idWmsRecebimentoCabecalho,
      idProduto: data.idProduto.present ? data.idProduto.value : this.idProduto,
      quantidadeVolume:
          data.quantidadeVolume.present
              ? data.quantidadeVolume.value
              : this.quantidadeVolume,
      quantidadeItemPorVolume:
          data.quantidadeItemPorVolume.present
              ? data.quantidadeItemPorVolume.value
              : this.quantidadeItemPorVolume,
      quantidadeRecebida:
          data.quantidadeRecebida.present
              ? data.quantidadeRecebida.value
              : this.quantidadeRecebida,
      destino: data.destino.present ? data.destino.value : this.destino,
    );
  }

  @override
  String toString() {
    return (StringBuffer('WmsRecebimentoDetalhe(')
          ..write('id: $id, ')
          ..write('idWmsRecebimentoCabecalho: $idWmsRecebimentoCabecalho, ')
          ..write('idProduto: $idProduto, ')
          ..write('quantidadeVolume: $quantidadeVolume, ')
          ..write('quantidadeItemPorVolume: $quantidadeItemPorVolume, ')
          ..write('quantidadeRecebida: $quantidadeRecebida, ')
          ..write('destino: $destino')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(
    id,
    idWmsRecebimentoCabecalho,
    idProduto,
    quantidadeVolume,
    quantidadeItemPorVolume,
    quantidadeRecebida,
    destino,
  );
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is WmsRecebimentoDetalhe &&
          other.id == this.id &&
          other.idWmsRecebimentoCabecalho == this.idWmsRecebimentoCabecalho &&
          other.idProduto == this.idProduto &&
          other.quantidadeVolume == this.quantidadeVolume &&
          other.quantidadeItemPorVolume == this.quantidadeItemPorVolume &&
          other.quantidadeRecebida == this.quantidadeRecebida &&
          other.destino == this.destino);
}

class WmsRecebimentoDetalhesCompanion
    extends UpdateCompanion<WmsRecebimentoDetalhe> {
  final Value<int?> id;
  final Value<int?> idWmsRecebimentoCabecalho;
  final Value<int?> idProduto;
  final Value<int?> quantidadeVolume;
  final Value<int?> quantidadeItemPorVolume;
  final Value<int?> quantidadeRecebida;
  final Value<String?> destino;
  const WmsRecebimentoDetalhesCompanion({
    this.id = const Value.absent(),
    this.idWmsRecebimentoCabecalho = const Value.absent(),
    this.idProduto = const Value.absent(),
    this.quantidadeVolume = const Value.absent(),
    this.quantidadeItemPorVolume = const Value.absent(),
    this.quantidadeRecebida = const Value.absent(),
    this.destino = const Value.absent(),
  });
  WmsRecebimentoDetalhesCompanion.insert({
    this.id = const Value.absent(),
    this.idWmsRecebimentoCabecalho = const Value.absent(),
    this.idProduto = const Value.absent(),
    this.quantidadeVolume = const Value.absent(),
    this.quantidadeItemPorVolume = const Value.absent(),
    this.quantidadeRecebida = const Value.absent(),
    this.destino = const Value.absent(),
  });
  static Insertable<WmsRecebimentoDetalhe> custom({
    Expression<int>? id,
    Expression<int>? idWmsRecebimentoCabecalho,
    Expression<int>? idProduto,
    Expression<int>? quantidadeVolume,
    Expression<int>? quantidadeItemPorVolume,
    Expression<int>? quantidadeRecebida,
    Expression<String>? destino,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (idWmsRecebimentoCabecalho != null)
        'id_wms_recebimento_cabecalho': idWmsRecebimentoCabecalho,
      if (idProduto != null) 'id_produto': idProduto,
      if (quantidadeVolume != null) 'quantidade_volume': quantidadeVolume,
      if (quantidadeItemPorVolume != null)
        'quantidade_item_por_volume': quantidadeItemPorVolume,
      if (quantidadeRecebida != null) 'quantidade_recebida': quantidadeRecebida,
      if (destino != null) 'destino': destino,
    });
  }

  WmsRecebimentoDetalhesCompanion copyWith({
    Value<int?>? id,
    Value<int?>? idWmsRecebimentoCabecalho,
    Value<int?>? idProduto,
    Value<int?>? quantidadeVolume,
    Value<int?>? quantidadeItemPorVolume,
    Value<int?>? quantidadeRecebida,
    Value<String?>? destino,
  }) {
    return WmsRecebimentoDetalhesCompanion(
      id: id ?? this.id,
      idWmsRecebimentoCabecalho:
          idWmsRecebimentoCabecalho ?? this.idWmsRecebimentoCabecalho,
      idProduto: idProduto ?? this.idProduto,
      quantidadeVolume: quantidadeVolume ?? this.quantidadeVolume,
      quantidadeItemPorVolume:
          quantidadeItemPorVolume ?? this.quantidadeItemPorVolume,
      quantidadeRecebida: quantidadeRecebida ?? this.quantidadeRecebida,
      destino: destino ?? this.destino,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (idWmsRecebimentoCabecalho.present) {
      map['id_wms_recebimento_cabecalho'] = Variable<int>(
        idWmsRecebimentoCabecalho.value,
      );
    }
    if (idProduto.present) {
      map['id_produto'] = Variable<int>(idProduto.value);
    }
    if (quantidadeVolume.present) {
      map['quantidade_volume'] = Variable<int>(quantidadeVolume.value);
    }
    if (quantidadeItemPorVolume.present) {
      map['quantidade_item_por_volume'] = Variable<int>(
        quantidadeItemPorVolume.value,
      );
    }
    if (quantidadeRecebida.present) {
      map['quantidade_recebida'] = Variable<int>(quantidadeRecebida.value);
    }
    if (destino.present) {
      map['destino'] = Variable<String>(destino.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('WmsRecebimentoDetalhesCompanion(')
          ..write('id: $id, ')
          ..write('idWmsRecebimentoCabecalho: $idWmsRecebimentoCabecalho, ')
          ..write('idProduto: $idProduto, ')
          ..write('quantidadeVolume: $quantidadeVolume, ')
          ..write('quantidadeItemPorVolume: $quantidadeItemPorVolume, ')
          ..write('quantidadeRecebida: $quantidadeRecebida, ')
          ..write('destino: $destino')
          ..write(')'))
        .toString();
  }
}

class $WmsCaixasTable extends WmsCaixas
    with TableInfo<$WmsCaixasTable, WmsCaixa> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $WmsCaixasTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
    'id',
    aliasedName,
    true,
    type: DriftSqlType.int,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _idWmsEstanteMeta = const VerificationMeta(
    'idWmsEstante',
  );
  @override
  late final GeneratedColumn<int> idWmsEstante = GeneratedColumn<int>(
    'id_wms_estante',
    aliasedName,
    true,
    type: DriftSqlType.int,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _codigoMeta = const VerificationMeta('codigo');
  @override
  late final GeneratedColumn<String> codigo = GeneratedColumn<String>(
    'codigo',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 10,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _alturaMeta = const VerificationMeta('altura');
  @override
  late final GeneratedColumn<int> altura = GeneratedColumn<int>(
    'altura',
    aliasedName,
    true,
    type: DriftSqlType.int,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _larguraMeta = const VerificationMeta(
    'largura',
  );
  @override
  late final GeneratedColumn<int> largura = GeneratedColumn<int>(
    'largura',
    aliasedName,
    true,
    type: DriftSqlType.int,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _profundidadeMeta = const VerificationMeta(
    'profundidade',
  );
  @override
  late final GeneratedColumn<int> profundidade = GeneratedColumn<int>(
    'profundidade',
    aliasedName,
    true,
    type: DriftSqlType.int,
    requiredDuringInsert: false,
  );
  @override
  List<GeneratedColumn> get $columns => [
    id,
    idWmsEstante,
    codigo,
    altura,
    largura,
    profundidade,
  ];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'wms_caixa';
  @override
  VerificationContext validateIntegrity(
    Insertable<WmsCaixa> instance, {
    bool isInserting = false,
  }) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('id_wms_estante')) {
      context.handle(
        _idWmsEstanteMeta,
        idWmsEstante.isAcceptableOrUnknown(
          data['id_wms_estante']!,
          _idWmsEstanteMeta,
        ),
      );
    }
    if (data.containsKey('codigo')) {
      context.handle(
        _codigoMeta,
        codigo.isAcceptableOrUnknown(data['codigo']!, _codigoMeta),
      );
    }
    if (data.containsKey('altura')) {
      context.handle(
        _alturaMeta,
        altura.isAcceptableOrUnknown(data['altura']!, _alturaMeta),
      );
    }
    if (data.containsKey('largura')) {
      context.handle(
        _larguraMeta,
        largura.isAcceptableOrUnknown(data['largura']!, _larguraMeta),
      );
    }
    if (data.containsKey('profundidade')) {
      context.handle(
        _profundidadeMeta,
        profundidade.isAcceptableOrUnknown(
          data['profundidade']!,
          _profundidadeMeta,
        ),
      );
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  WmsCaixa map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return WmsCaixa(
      id: attachedDatabase.typeMapping.read(
        DriftSqlType.int,
        data['${effectivePrefix}id'],
      ),
      idWmsEstante: attachedDatabase.typeMapping.read(
        DriftSqlType.int,
        data['${effectivePrefix}id_wms_estante'],
      ),
      codigo: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}codigo'],
      ),
      altura: attachedDatabase.typeMapping.read(
        DriftSqlType.int,
        data['${effectivePrefix}altura'],
      ),
      largura: attachedDatabase.typeMapping.read(
        DriftSqlType.int,
        data['${effectivePrefix}largura'],
      ),
      profundidade: attachedDatabase.typeMapping.read(
        DriftSqlType.int,
        data['${effectivePrefix}profundidade'],
      ),
    );
  }

  @override
  $WmsCaixasTable createAlias(String alias) {
    return $WmsCaixasTable(attachedDatabase, alias);
  }
}

class WmsCaixa extends DataClass implements Insertable<WmsCaixa> {
  final int? id;
  final int? idWmsEstante;
  final String? codigo;
  final int? altura;
  final int? largura;
  final int? profundidade;
  const WmsCaixa({
    this.id,
    this.idWmsEstante,
    this.codigo,
    this.altura,
    this.largura,
    this.profundidade,
  });
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || idWmsEstante != null) {
      map['id_wms_estante'] = Variable<int>(idWmsEstante);
    }
    if (!nullToAbsent || codigo != null) {
      map['codigo'] = Variable<String>(codigo);
    }
    if (!nullToAbsent || altura != null) {
      map['altura'] = Variable<int>(altura);
    }
    if (!nullToAbsent || largura != null) {
      map['largura'] = Variable<int>(largura);
    }
    if (!nullToAbsent || profundidade != null) {
      map['profundidade'] = Variable<int>(profundidade);
    }
    return map;
  }

  factory WmsCaixa.fromJson(
    Map<String, dynamic> json, {
    ValueSerializer? serializer,
  }) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return WmsCaixa(
      id: serializer.fromJson<int?>(json['id']),
      idWmsEstante: serializer.fromJson<int?>(json['idWmsEstante']),
      codigo: serializer.fromJson<String?>(json['codigo']),
      altura: serializer.fromJson<int?>(json['altura']),
      largura: serializer.fromJson<int?>(json['largura']),
      profundidade: serializer.fromJson<int?>(json['profundidade']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'idWmsEstante': serializer.toJson<int?>(idWmsEstante),
      'codigo': serializer.toJson<String?>(codigo),
      'altura': serializer.toJson<int?>(altura),
      'largura': serializer.toJson<int?>(largura),
      'profundidade': serializer.toJson<int?>(profundidade),
    };
  }

  WmsCaixa copyWith({
    Value<int?> id = const Value.absent(),
    Value<int?> idWmsEstante = const Value.absent(),
    Value<String?> codigo = const Value.absent(),
    Value<int?> altura = const Value.absent(),
    Value<int?> largura = const Value.absent(),
    Value<int?> profundidade = const Value.absent(),
  }) => WmsCaixa(
    id: id.present ? id.value : this.id,
    idWmsEstante: idWmsEstante.present ? idWmsEstante.value : this.idWmsEstante,
    codigo: codigo.present ? codigo.value : this.codigo,
    altura: altura.present ? altura.value : this.altura,
    largura: largura.present ? largura.value : this.largura,
    profundidade: profundidade.present ? profundidade.value : this.profundidade,
  );
  WmsCaixa copyWithCompanion(WmsCaixasCompanion data) {
    return WmsCaixa(
      id: data.id.present ? data.id.value : this.id,
      idWmsEstante:
          data.idWmsEstante.present
              ? data.idWmsEstante.value
              : this.idWmsEstante,
      codigo: data.codigo.present ? data.codigo.value : this.codigo,
      altura: data.altura.present ? data.altura.value : this.altura,
      largura: data.largura.present ? data.largura.value : this.largura,
      profundidade:
          data.profundidade.present
              ? data.profundidade.value
              : this.profundidade,
    );
  }

  @override
  String toString() {
    return (StringBuffer('WmsCaixa(')
          ..write('id: $id, ')
          ..write('idWmsEstante: $idWmsEstante, ')
          ..write('codigo: $codigo, ')
          ..write('altura: $altura, ')
          ..write('largura: $largura, ')
          ..write('profundidade: $profundidade')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode =>
      Object.hash(id, idWmsEstante, codigo, altura, largura, profundidade);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is WmsCaixa &&
          other.id == this.id &&
          other.idWmsEstante == this.idWmsEstante &&
          other.codigo == this.codigo &&
          other.altura == this.altura &&
          other.largura == this.largura &&
          other.profundidade == this.profundidade);
}

class WmsCaixasCompanion extends UpdateCompanion<WmsCaixa> {
  final Value<int?> id;
  final Value<int?> idWmsEstante;
  final Value<String?> codigo;
  final Value<int?> altura;
  final Value<int?> largura;
  final Value<int?> profundidade;
  const WmsCaixasCompanion({
    this.id = const Value.absent(),
    this.idWmsEstante = const Value.absent(),
    this.codigo = const Value.absent(),
    this.altura = const Value.absent(),
    this.largura = const Value.absent(),
    this.profundidade = const Value.absent(),
  });
  WmsCaixasCompanion.insert({
    this.id = const Value.absent(),
    this.idWmsEstante = const Value.absent(),
    this.codigo = const Value.absent(),
    this.altura = const Value.absent(),
    this.largura = const Value.absent(),
    this.profundidade = const Value.absent(),
  });
  static Insertable<WmsCaixa> custom({
    Expression<int>? id,
    Expression<int>? idWmsEstante,
    Expression<String>? codigo,
    Expression<int>? altura,
    Expression<int>? largura,
    Expression<int>? profundidade,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (idWmsEstante != null) 'id_wms_estante': idWmsEstante,
      if (codigo != null) 'codigo': codigo,
      if (altura != null) 'altura': altura,
      if (largura != null) 'largura': largura,
      if (profundidade != null) 'profundidade': profundidade,
    });
  }

  WmsCaixasCompanion copyWith({
    Value<int?>? id,
    Value<int?>? idWmsEstante,
    Value<String?>? codigo,
    Value<int?>? altura,
    Value<int?>? largura,
    Value<int?>? profundidade,
  }) {
    return WmsCaixasCompanion(
      id: id ?? this.id,
      idWmsEstante: idWmsEstante ?? this.idWmsEstante,
      codigo: codigo ?? this.codigo,
      altura: altura ?? this.altura,
      largura: largura ?? this.largura,
      profundidade: profundidade ?? this.profundidade,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (idWmsEstante.present) {
      map['id_wms_estante'] = Variable<int>(idWmsEstante.value);
    }
    if (codigo.present) {
      map['codigo'] = Variable<String>(codigo.value);
    }
    if (altura.present) {
      map['altura'] = Variable<int>(altura.value);
    }
    if (largura.present) {
      map['largura'] = Variable<int>(largura.value);
    }
    if (profundidade.present) {
      map['profundidade'] = Variable<int>(profundidade.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('WmsCaixasCompanion(')
          ..write('id: $id, ')
          ..write('idWmsEstante: $idWmsEstante, ')
          ..write('codigo: $codigo, ')
          ..write('altura: $altura, ')
          ..write('largura: $largura, ')
          ..write('profundidade: $profundidade')
          ..write(')'))
        .toString();
  }
}

class $WmsOrdemSeparacaoDetsTable extends WmsOrdemSeparacaoDets
    with TableInfo<$WmsOrdemSeparacaoDetsTable, WmsOrdemSeparacaoDet> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $WmsOrdemSeparacaoDetsTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
    'id',
    aliasedName,
    true,
    type: DriftSqlType.int,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _idWmsOrdemSeparacaoCabMeta =
      const VerificationMeta('idWmsOrdemSeparacaoCab');
  @override
  late final GeneratedColumn<int> idWmsOrdemSeparacaoCab = GeneratedColumn<int>(
    'id_wms_ordem_separacao_cab',
    aliasedName,
    true,
    type: DriftSqlType.int,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _idProdutoMeta = const VerificationMeta(
    'idProduto',
  );
  @override
  late final GeneratedColumn<int> idProduto = GeneratedColumn<int>(
    'id_produto',
    aliasedName,
    true,
    type: DriftSqlType.int,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _quantidadeMeta = const VerificationMeta(
    'quantidade',
  );
  @override
  late final GeneratedColumn<int> quantidade = GeneratedColumn<int>(
    'quantidade',
    aliasedName,
    true,
    type: DriftSqlType.int,
    requiredDuringInsert: false,
  );
  @override
  List<GeneratedColumn> get $columns => [
    id,
    idWmsOrdemSeparacaoCab,
    idProduto,
    quantidade,
  ];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'wms_ordem_separacao_det';
  @override
  VerificationContext validateIntegrity(
    Insertable<WmsOrdemSeparacaoDet> instance, {
    bool isInserting = false,
  }) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('id_wms_ordem_separacao_cab')) {
      context.handle(
        _idWmsOrdemSeparacaoCabMeta,
        idWmsOrdemSeparacaoCab.isAcceptableOrUnknown(
          data['id_wms_ordem_separacao_cab']!,
          _idWmsOrdemSeparacaoCabMeta,
        ),
      );
    }
    if (data.containsKey('id_produto')) {
      context.handle(
        _idProdutoMeta,
        idProduto.isAcceptableOrUnknown(data['id_produto']!, _idProdutoMeta),
      );
    }
    if (data.containsKey('quantidade')) {
      context.handle(
        _quantidadeMeta,
        quantidade.isAcceptableOrUnknown(data['quantidade']!, _quantidadeMeta),
      );
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  WmsOrdemSeparacaoDet map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return WmsOrdemSeparacaoDet(
      id: attachedDatabase.typeMapping.read(
        DriftSqlType.int,
        data['${effectivePrefix}id'],
      ),
      idWmsOrdemSeparacaoCab: attachedDatabase.typeMapping.read(
        DriftSqlType.int,
        data['${effectivePrefix}id_wms_ordem_separacao_cab'],
      ),
      idProduto: attachedDatabase.typeMapping.read(
        DriftSqlType.int,
        data['${effectivePrefix}id_produto'],
      ),
      quantidade: attachedDatabase.typeMapping.read(
        DriftSqlType.int,
        data['${effectivePrefix}quantidade'],
      ),
    );
  }

  @override
  $WmsOrdemSeparacaoDetsTable createAlias(String alias) {
    return $WmsOrdemSeparacaoDetsTable(attachedDatabase, alias);
  }
}

class WmsOrdemSeparacaoDet extends DataClass
    implements Insertable<WmsOrdemSeparacaoDet> {
  final int? id;
  final int? idWmsOrdemSeparacaoCab;
  final int? idProduto;
  final int? quantidade;
  const WmsOrdemSeparacaoDet({
    this.id,
    this.idWmsOrdemSeparacaoCab,
    this.idProduto,
    this.quantidade,
  });
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || idWmsOrdemSeparacaoCab != null) {
      map['id_wms_ordem_separacao_cab'] = Variable<int>(idWmsOrdemSeparacaoCab);
    }
    if (!nullToAbsent || idProduto != null) {
      map['id_produto'] = Variable<int>(idProduto);
    }
    if (!nullToAbsent || quantidade != null) {
      map['quantidade'] = Variable<int>(quantidade);
    }
    return map;
  }

  factory WmsOrdemSeparacaoDet.fromJson(
    Map<String, dynamic> json, {
    ValueSerializer? serializer,
  }) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return WmsOrdemSeparacaoDet(
      id: serializer.fromJson<int?>(json['id']),
      idWmsOrdemSeparacaoCab: serializer.fromJson<int?>(
        json['idWmsOrdemSeparacaoCab'],
      ),
      idProduto: serializer.fromJson<int?>(json['idProduto']),
      quantidade: serializer.fromJson<int?>(json['quantidade']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'idWmsOrdemSeparacaoCab': serializer.toJson<int?>(idWmsOrdemSeparacaoCab),
      'idProduto': serializer.toJson<int?>(idProduto),
      'quantidade': serializer.toJson<int?>(quantidade),
    };
  }

  WmsOrdemSeparacaoDet copyWith({
    Value<int?> id = const Value.absent(),
    Value<int?> idWmsOrdemSeparacaoCab = const Value.absent(),
    Value<int?> idProduto = const Value.absent(),
    Value<int?> quantidade = const Value.absent(),
  }) => WmsOrdemSeparacaoDet(
    id: id.present ? id.value : this.id,
    idWmsOrdemSeparacaoCab:
        idWmsOrdemSeparacaoCab.present
            ? idWmsOrdemSeparacaoCab.value
            : this.idWmsOrdemSeparacaoCab,
    idProduto: idProduto.present ? idProduto.value : this.idProduto,
    quantidade: quantidade.present ? quantidade.value : this.quantidade,
  );
  WmsOrdemSeparacaoDet copyWithCompanion(WmsOrdemSeparacaoDetsCompanion data) {
    return WmsOrdemSeparacaoDet(
      id: data.id.present ? data.id.value : this.id,
      idWmsOrdemSeparacaoCab:
          data.idWmsOrdemSeparacaoCab.present
              ? data.idWmsOrdemSeparacaoCab.value
              : this.idWmsOrdemSeparacaoCab,
      idProduto: data.idProduto.present ? data.idProduto.value : this.idProduto,
      quantidade:
          data.quantidade.present ? data.quantidade.value : this.quantidade,
    );
  }

  @override
  String toString() {
    return (StringBuffer('WmsOrdemSeparacaoDet(')
          ..write('id: $id, ')
          ..write('idWmsOrdemSeparacaoCab: $idWmsOrdemSeparacaoCab, ')
          ..write('idProduto: $idProduto, ')
          ..write('quantidade: $quantidade')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode =>
      Object.hash(id, idWmsOrdemSeparacaoCab, idProduto, quantidade);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is WmsOrdemSeparacaoDet &&
          other.id == this.id &&
          other.idWmsOrdemSeparacaoCab == this.idWmsOrdemSeparacaoCab &&
          other.idProduto == this.idProduto &&
          other.quantidade == this.quantidade);
}

class WmsOrdemSeparacaoDetsCompanion
    extends UpdateCompanion<WmsOrdemSeparacaoDet> {
  final Value<int?> id;
  final Value<int?> idWmsOrdemSeparacaoCab;
  final Value<int?> idProduto;
  final Value<int?> quantidade;
  const WmsOrdemSeparacaoDetsCompanion({
    this.id = const Value.absent(),
    this.idWmsOrdemSeparacaoCab = const Value.absent(),
    this.idProduto = const Value.absent(),
    this.quantidade = const Value.absent(),
  });
  WmsOrdemSeparacaoDetsCompanion.insert({
    this.id = const Value.absent(),
    this.idWmsOrdemSeparacaoCab = const Value.absent(),
    this.idProduto = const Value.absent(),
    this.quantidade = const Value.absent(),
  });
  static Insertable<WmsOrdemSeparacaoDet> custom({
    Expression<int>? id,
    Expression<int>? idWmsOrdemSeparacaoCab,
    Expression<int>? idProduto,
    Expression<int>? quantidade,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (idWmsOrdemSeparacaoCab != null)
        'id_wms_ordem_separacao_cab': idWmsOrdemSeparacaoCab,
      if (idProduto != null) 'id_produto': idProduto,
      if (quantidade != null) 'quantidade': quantidade,
    });
  }

  WmsOrdemSeparacaoDetsCompanion copyWith({
    Value<int?>? id,
    Value<int?>? idWmsOrdemSeparacaoCab,
    Value<int?>? idProduto,
    Value<int?>? quantidade,
  }) {
    return WmsOrdemSeparacaoDetsCompanion(
      id: id ?? this.id,
      idWmsOrdemSeparacaoCab:
          idWmsOrdemSeparacaoCab ?? this.idWmsOrdemSeparacaoCab,
      idProduto: idProduto ?? this.idProduto,
      quantidade: quantidade ?? this.quantidade,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (idWmsOrdemSeparacaoCab.present) {
      map['id_wms_ordem_separacao_cab'] = Variable<int>(
        idWmsOrdemSeparacaoCab.value,
      );
    }
    if (idProduto.present) {
      map['id_produto'] = Variable<int>(idProduto.value);
    }
    if (quantidade.present) {
      map['quantidade'] = Variable<int>(quantidade.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('WmsOrdemSeparacaoDetsCompanion(')
          ..write('id: $id, ')
          ..write('idWmsOrdemSeparacaoCab: $idWmsOrdemSeparacaoCab, ')
          ..write('idProduto: $idProduto, ')
          ..write('quantidade: $quantidade')
          ..write(')'))
        .toString();
  }
}

class $WmsRecebimentoCabecalhosTable extends WmsRecebimentoCabecalhos
    with TableInfo<$WmsRecebimentoCabecalhosTable, WmsRecebimentoCabecalho> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $WmsRecebimentoCabecalhosTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
    'id',
    aliasedName,
    true,
    type: DriftSqlType.int,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _idWmsAgendamentoMeta = const VerificationMeta(
    'idWmsAgendamento',
  );
  @override
  late final GeneratedColumn<int> idWmsAgendamento = GeneratedColumn<int>(
    'id_wms_agendamento',
    aliasedName,
    true,
    type: DriftSqlType.int,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _dataRecebimentoMeta = const VerificationMeta(
    'dataRecebimento',
  );
  @override
  late final GeneratedColumn<DateTime> dataRecebimento =
      GeneratedColumn<DateTime>(
        'data_recebimento',
        aliasedName,
        true,
        type: DriftSqlType.dateTime,
        requiredDuringInsert: false,
      );
  static const VerificationMeta _horaInicioMeta = const VerificationMeta(
    'horaInicio',
  );
  @override
  late final GeneratedColumn<String> horaInicio = GeneratedColumn<String>(
    'hora_inicio',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 8,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _horaFimMeta = const VerificationMeta(
    'horaFim',
  );
  @override
  late final GeneratedColumn<String> horaFim = GeneratedColumn<String>(
    'hora_fim',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 8,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _volumeRecebidoMeta = const VerificationMeta(
    'volumeRecebido',
  );
  @override
  late final GeneratedColumn<int> volumeRecebido = GeneratedColumn<int>(
    'volume_recebido',
    aliasedName,
    true,
    type: DriftSqlType.int,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _pesoRecebidoMeta = const VerificationMeta(
    'pesoRecebido',
  );
  @override
  late final GeneratedColumn<double> pesoRecebido = GeneratedColumn<double>(
    'peso_recebido',
    aliasedName,
    true,
    type: DriftSqlType.double,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _inconsistenciaMeta = const VerificationMeta(
    'inconsistencia',
  );
  @override
  late final GeneratedColumn<String> inconsistencia = GeneratedColumn<String>(
    'inconsistencia',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 1,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _codigoRecebimentoMeta = const VerificationMeta(
    'codigoRecebimento',
  );
  @override
  late final GeneratedColumn<String> codigoRecebimento =
      GeneratedColumn<String>(
        'codigo_recebimento',
        aliasedName,
        true,
        additionalChecks: GeneratedColumn.checkTextLength(
          minTextLength: 0,
          maxTextLength: 32,
        ),
        type: DriftSqlType.string,
        requiredDuringInsert: false,
      );
  static const VerificationMeta _observacaoMeta = const VerificationMeta(
    'observacao',
  );
  @override
  late final GeneratedColumn<String> observacao = GeneratedColumn<String>(
    'observacao',
    aliasedName,
    true,
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  @override
  List<GeneratedColumn> get $columns => [
    id,
    idWmsAgendamento,
    dataRecebimento,
    horaInicio,
    horaFim,
    volumeRecebido,
    pesoRecebido,
    inconsistencia,
    codigoRecebimento,
    observacao,
  ];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'wms_recebimento_cabecalho';
  @override
  VerificationContext validateIntegrity(
    Insertable<WmsRecebimentoCabecalho> instance, {
    bool isInserting = false,
  }) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('id_wms_agendamento')) {
      context.handle(
        _idWmsAgendamentoMeta,
        idWmsAgendamento.isAcceptableOrUnknown(
          data['id_wms_agendamento']!,
          _idWmsAgendamentoMeta,
        ),
      );
    }
    if (data.containsKey('data_recebimento')) {
      context.handle(
        _dataRecebimentoMeta,
        dataRecebimento.isAcceptableOrUnknown(
          data['data_recebimento']!,
          _dataRecebimentoMeta,
        ),
      );
    }
    if (data.containsKey('hora_inicio')) {
      context.handle(
        _horaInicioMeta,
        horaInicio.isAcceptableOrUnknown(data['hora_inicio']!, _horaInicioMeta),
      );
    }
    if (data.containsKey('hora_fim')) {
      context.handle(
        _horaFimMeta,
        horaFim.isAcceptableOrUnknown(data['hora_fim']!, _horaFimMeta),
      );
    }
    if (data.containsKey('volume_recebido')) {
      context.handle(
        _volumeRecebidoMeta,
        volumeRecebido.isAcceptableOrUnknown(
          data['volume_recebido']!,
          _volumeRecebidoMeta,
        ),
      );
    }
    if (data.containsKey('peso_recebido')) {
      context.handle(
        _pesoRecebidoMeta,
        pesoRecebido.isAcceptableOrUnknown(
          data['peso_recebido']!,
          _pesoRecebidoMeta,
        ),
      );
    }
    if (data.containsKey('inconsistencia')) {
      context.handle(
        _inconsistenciaMeta,
        inconsistencia.isAcceptableOrUnknown(
          data['inconsistencia']!,
          _inconsistenciaMeta,
        ),
      );
    }
    if (data.containsKey('codigo_recebimento')) {
      context.handle(
        _codigoRecebimentoMeta,
        codigoRecebimento.isAcceptableOrUnknown(
          data['codigo_recebimento']!,
          _codigoRecebimentoMeta,
        ),
      );
    }
    if (data.containsKey('observacao')) {
      context.handle(
        _observacaoMeta,
        observacao.isAcceptableOrUnknown(data['observacao']!, _observacaoMeta),
      );
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  WmsRecebimentoCabecalho map(
    Map<String, dynamic> data, {
    String? tablePrefix,
  }) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return WmsRecebimentoCabecalho(
      id: attachedDatabase.typeMapping.read(
        DriftSqlType.int,
        data['${effectivePrefix}id'],
      ),
      idWmsAgendamento: attachedDatabase.typeMapping.read(
        DriftSqlType.int,
        data['${effectivePrefix}id_wms_agendamento'],
      ),
      dataRecebimento: attachedDatabase.typeMapping.read(
        DriftSqlType.dateTime,
        data['${effectivePrefix}data_recebimento'],
      ),
      horaInicio: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}hora_inicio'],
      ),
      horaFim: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}hora_fim'],
      ),
      volumeRecebido: attachedDatabase.typeMapping.read(
        DriftSqlType.int,
        data['${effectivePrefix}volume_recebido'],
      ),
      pesoRecebido: attachedDatabase.typeMapping.read(
        DriftSqlType.double,
        data['${effectivePrefix}peso_recebido'],
      ),
      inconsistencia: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}inconsistencia'],
      ),
      codigoRecebimento: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}codigo_recebimento'],
      ),
      observacao: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}observacao'],
      ),
    );
  }

  @override
  $WmsRecebimentoCabecalhosTable createAlias(String alias) {
    return $WmsRecebimentoCabecalhosTable(attachedDatabase, alias);
  }
}

class WmsRecebimentoCabecalho extends DataClass
    implements Insertable<WmsRecebimentoCabecalho> {
  final int? id;
  final int? idWmsAgendamento;
  final DateTime? dataRecebimento;
  final String? horaInicio;
  final String? horaFim;
  final int? volumeRecebido;
  final double? pesoRecebido;
  final String? inconsistencia;
  final String? codigoRecebimento;
  final String? observacao;
  const WmsRecebimentoCabecalho({
    this.id,
    this.idWmsAgendamento,
    this.dataRecebimento,
    this.horaInicio,
    this.horaFim,
    this.volumeRecebido,
    this.pesoRecebido,
    this.inconsistencia,
    this.codigoRecebimento,
    this.observacao,
  });
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || idWmsAgendamento != null) {
      map['id_wms_agendamento'] = Variable<int>(idWmsAgendamento);
    }
    if (!nullToAbsent || dataRecebimento != null) {
      map['data_recebimento'] = Variable<DateTime>(dataRecebimento);
    }
    if (!nullToAbsent || horaInicio != null) {
      map['hora_inicio'] = Variable<String>(horaInicio);
    }
    if (!nullToAbsent || horaFim != null) {
      map['hora_fim'] = Variable<String>(horaFim);
    }
    if (!nullToAbsent || volumeRecebido != null) {
      map['volume_recebido'] = Variable<int>(volumeRecebido);
    }
    if (!nullToAbsent || pesoRecebido != null) {
      map['peso_recebido'] = Variable<double>(pesoRecebido);
    }
    if (!nullToAbsent || inconsistencia != null) {
      map['inconsistencia'] = Variable<String>(inconsistencia);
    }
    if (!nullToAbsent || codigoRecebimento != null) {
      map['codigo_recebimento'] = Variable<String>(codigoRecebimento);
    }
    if (!nullToAbsent || observacao != null) {
      map['observacao'] = Variable<String>(observacao);
    }
    return map;
  }

  factory WmsRecebimentoCabecalho.fromJson(
    Map<String, dynamic> json, {
    ValueSerializer? serializer,
  }) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return WmsRecebimentoCabecalho(
      id: serializer.fromJson<int?>(json['id']),
      idWmsAgendamento: serializer.fromJson<int?>(json['idWmsAgendamento']),
      dataRecebimento: serializer.fromJson<DateTime?>(json['dataRecebimento']),
      horaInicio: serializer.fromJson<String?>(json['horaInicio']),
      horaFim: serializer.fromJson<String?>(json['horaFim']),
      volumeRecebido: serializer.fromJson<int?>(json['volumeRecebido']),
      pesoRecebido: serializer.fromJson<double?>(json['pesoRecebido']),
      inconsistencia: serializer.fromJson<String?>(json['inconsistencia']),
      codigoRecebimento: serializer.fromJson<String?>(
        json['codigoRecebimento'],
      ),
      observacao: serializer.fromJson<String?>(json['observacao']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'idWmsAgendamento': serializer.toJson<int?>(idWmsAgendamento),
      'dataRecebimento': serializer.toJson<DateTime?>(dataRecebimento),
      'horaInicio': serializer.toJson<String?>(horaInicio),
      'horaFim': serializer.toJson<String?>(horaFim),
      'volumeRecebido': serializer.toJson<int?>(volumeRecebido),
      'pesoRecebido': serializer.toJson<double?>(pesoRecebido),
      'inconsistencia': serializer.toJson<String?>(inconsistencia),
      'codigoRecebimento': serializer.toJson<String?>(codigoRecebimento),
      'observacao': serializer.toJson<String?>(observacao),
    };
  }

  WmsRecebimentoCabecalho copyWith({
    Value<int?> id = const Value.absent(),
    Value<int?> idWmsAgendamento = const Value.absent(),
    Value<DateTime?> dataRecebimento = const Value.absent(),
    Value<String?> horaInicio = const Value.absent(),
    Value<String?> horaFim = const Value.absent(),
    Value<int?> volumeRecebido = const Value.absent(),
    Value<double?> pesoRecebido = const Value.absent(),
    Value<String?> inconsistencia = const Value.absent(),
    Value<String?> codigoRecebimento = const Value.absent(),
    Value<String?> observacao = const Value.absent(),
  }) => WmsRecebimentoCabecalho(
    id: id.present ? id.value : this.id,
    idWmsAgendamento:
        idWmsAgendamento.present
            ? idWmsAgendamento.value
            : this.idWmsAgendamento,
    dataRecebimento:
        dataRecebimento.present ? dataRecebimento.value : this.dataRecebimento,
    horaInicio: horaInicio.present ? horaInicio.value : this.horaInicio,
    horaFim: horaFim.present ? horaFim.value : this.horaFim,
    volumeRecebido:
        volumeRecebido.present ? volumeRecebido.value : this.volumeRecebido,
    pesoRecebido: pesoRecebido.present ? pesoRecebido.value : this.pesoRecebido,
    inconsistencia:
        inconsistencia.present ? inconsistencia.value : this.inconsistencia,
    codigoRecebimento:
        codigoRecebimento.present
            ? codigoRecebimento.value
            : this.codigoRecebimento,
    observacao: observacao.present ? observacao.value : this.observacao,
  );
  WmsRecebimentoCabecalho copyWithCompanion(
    WmsRecebimentoCabecalhosCompanion data,
  ) {
    return WmsRecebimentoCabecalho(
      id: data.id.present ? data.id.value : this.id,
      idWmsAgendamento:
          data.idWmsAgendamento.present
              ? data.idWmsAgendamento.value
              : this.idWmsAgendamento,
      dataRecebimento:
          data.dataRecebimento.present
              ? data.dataRecebimento.value
              : this.dataRecebimento,
      horaInicio:
          data.horaInicio.present ? data.horaInicio.value : this.horaInicio,
      horaFim: data.horaFim.present ? data.horaFim.value : this.horaFim,
      volumeRecebido:
          data.volumeRecebido.present
              ? data.volumeRecebido.value
              : this.volumeRecebido,
      pesoRecebido:
          data.pesoRecebido.present
              ? data.pesoRecebido.value
              : this.pesoRecebido,
      inconsistencia:
          data.inconsistencia.present
              ? data.inconsistencia.value
              : this.inconsistencia,
      codigoRecebimento:
          data.codigoRecebimento.present
              ? data.codigoRecebimento.value
              : this.codigoRecebimento,
      observacao:
          data.observacao.present ? data.observacao.value : this.observacao,
    );
  }

  @override
  String toString() {
    return (StringBuffer('WmsRecebimentoCabecalho(')
          ..write('id: $id, ')
          ..write('idWmsAgendamento: $idWmsAgendamento, ')
          ..write('dataRecebimento: $dataRecebimento, ')
          ..write('horaInicio: $horaInicio, ')
          ..write('horaFim: $horaFim, ')
          ..write('volumeRecebido: $volumeRecebido, ')
          ..write('pesoRecebido: $pesoRecebido, ')
          ..write('inconsistencia: $inconsistencia, ')
          ..write('codigoRecebimento: $codigoRecebimento, ')
          ..write('observacao: $observacao')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(
    id,
    idWmsAgendamento,
    dataRecebimento,
    horaInicio,
    horaFim,
    volumeRecebido,
    pesoRecebido,
    inconsistencia,
    codigoRecebimento,
    observacao,
  );
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is WmsRecebimentoCabecalho &&
          other.id == this.id &&
          other.idWmsAgendamento == this.idWmsAgendamento &&
          other.dataRecebimento == this.dataRecebimento &&
          other.horaInicio == this.horaInicio &&
          other.horaFim == this.horaFim &&
          other.volumeRecebido == this.volumeRecebido &&
          other.pesoRecebido == this.pesoRecebido &&
          other.inconsistencia == this.inconsistencia &&
          other.codigoRecebimento == this.codigoRecebimento &&
          other.observacao == this.observacao);
}

class WmsRecebimentoCabecalhosCompanion
    extends UpdateCompanion<WmsRecebimentoCabecalho> {
  final Value<int?> id;
  final Value<int?> idWmsAgendamento;
  final Value<DateTime?> dataRecebimento;
  final Value<String?> horaInicio;
  final Value<String?> horaFim;
  final Value<int?> volumeRecebido;
  final Value<double?> pesoRecebido;
  final Value<String?> inconsistencia;
  final Value<String?> codigoRecebimento;
  final Value<String?> observacao;
  const WmsRecebimentoCabecalhosCompanion({
    this.id = const Value.absent(),
    this.idWmsAgendamento = const Value.absent(),
    this.dataRecebimento = const Value.absent(),
    this.horaInicio = const Value.absent(),
    this.horaFim = const Value.absent(),
    this.volumeRecebido = const Value.absent(),
    this.pesoRecebido = const Value.absent(),
    this.inconsistencia = const Value.absent(),
    this.codigoRecebimento = const Value.absent(),
    this.observacao = const Value.absent(),
  });
  WmsRecebimentoCabecalhosCompanion.insert({
    this.id = const Value.absent(),
    this.idWmsAgendamento = const Value.absent(),
    this.dataRecebimento = const Value.absent(),
    this.horaInicio = const Value.absent(),
    this.horaFim = const Value.absent(),
    this.volumeRecebido = const Value.absent(),
    this.pesoRecebido = const Value.absent(),
    this.inconsistencia = const Value.absent(),
    this.codigoRecebimento = const Value.absent(),
    this.observacao = const Value.absent(),
  });
  static Insertable<WmsRecebimentoCabecalho> custom({
    Expression<int>? id,
    Expression<int>? idWmsAgendamento,
    Expression<DateTime>? dataRecebimento,
    Expression<String>? horaInicio,
    Expression<String>? horaFim,
    Expression<int>? volumeRecebido,
    Expression<double>? pesoRecebido,
    Expression<String>? inconsistencia,
    Expression<String>? codigoRecebimento,
    Expression<String>? observacao,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (idWmsAgendamento != null) 'id_wms_agendamento': idWmsAgendamento,
      if (dataRecebimento != null) 'data_recebimento': dataRecebimento,
      if (horaInicio != null) 'hora_inicio': horaInicio,
      if (horaFim != null) 'hora_fim': horaFim,
      if (volumeRecebido != null) 'volume_recebido': volumeRecebido,
      if (pesoRecebido != null) 'peso_recebido': pesoRecebido,
      if (inconsistencia != null) 'inconsistencia': inconsistencia,
      if (codigoRecebimento != null) 'codigo_recebimento': codigoRecebimento,
      if (observacao != null) 'observacao': observacao,
    });
  }

  WmsRecebimentoCabecalhosCompanion copyWith({
    Value<int?>? id,
    Value<int?>? idWmsAgendamento,
    Value<DateTime?>? dataRecebimento,
    Value<String?>? horaInicio,
    Value<String?>? horaFim,
    Value<int?>? volumeRecebido,
    Value<double?>? pesoRecebido,
    Value<String?>? inconsistencia,
    Value<String?>? codigoRecebimento,
    Value<String?>? observacao,
  }) {
    return WmsRecebimentoCabecalhosCompanion(
      id: id ?? this.id,
      idWmsAgendamento: idWmsAgendamento ?? this.idWmsAgendamento,
      dataRecebimento: dataRecebimento ?? this.dataRecebimento,
      horaInicio: horaInicio ?? this.horaInicio,
      horaFim: horaFim ?? this.horaFim,
      volumeRecebido: volumeRecebido ?? this.volumeRecebido,
      pesoRecebido: pesoRecebido ?? this.pesoRecebido,
      inconsistencia: inconsistencia ?? this.inconsistencia,
      codigoRecebimento: codigoRecebimento ?? this.codigoRecebimento,
      observacao: observacao ?? this.observacao,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (idWmsAgendamento.present) {
      map['id_wms_agendamento'] = Variable<int>(idWmsAgendamento.value);
    }
    if (dataRecebimento.present) {
      map['data_recebimento'] = Variable<DateTime>(dataRecebimento.value);
    }
    if (horaInicio.present) {
      map['hora_inicio'] = Variable<String>(horaInicio.value);
    }
    if (horaFim.present) {
      map['hora_fim'] = Variable<String>(horaFim.value);
    }
    if (volumeRecebido.present) {
      map['volume_recebido'] = Variable<int>(volumeRecebido.value);
    }
    if (pesoRecebido.present) {
      map['peso_recebido'] = Variable<double>(pesoRecebido.value);
    }
    if (inconsistencia.present) {
      map['inconsistencia'] = Variable<String>(inconsistencia.value);
    }
    if (codigoRecebimento.present) {
      map['codigo_recebimento'] = Variable<String>(codigoRecebimento.value);
    }
    if (observacao.present) {
      map['observacao'] = Variable<String>(observacao.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('WmsRecebimentoCabecalhosCompanion(')
          ..write('id: $id, ')
          ..write('idWmsAgendamento: $idWmsAgendamento, ')
          ..write('dataRecebimento: $dataRecebimento, ')
          ..write('horaInicio: $horaInicio, ')
          ..write('horaFim: $horaFim, ')
          ..write('volumeRecebido: $volumeRecebido, ')
          ..write('pesoRecebido: $pesoRecebido, ')
          ..write('inconsistencia: $inconsistencia, ')
          ..write('codigoRecebimento: $codigoRecebimento, ')
          ..write('observacao: $observacao')
          ..write(')'))
        .toString();
  }
}

class $WmsEstantesTable extends WmsEstantes
    with TableInfo<$WmsEstantesTable, WmsEstante> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $WmsEstantesTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
    'id',
    aliasedName,
    true,
    type: DriftSqlType.int,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _idWmsRuaMeta = const VerificationMeta(
    'idWmsRua',
  );
  @override
  late final GeneratedColumn<int> idWmsRua = GeneratedColumn<int>(
    'id_wms_rua',
    aliasedName,
    true,
    type: DriftSqlType.int,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _codigoMeta = const VerificationMeta('codigo');
  @override
  late final GeneratedColumn<String> codigo = GeneratedColumn<String>(
    'codigo',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 10,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _quantidadeCaixaMeta = const VerificationMeta(
    'quantidadeCaixa',
  );
  @override
  late final GeneratedColumn<int> quantidadeCaixa = GeneratedColumn<int>(
    'quantidade_caixa',
    aliasedName,
    true,
    type: DriftSqlType.int,
    requiredDuringInsert: false,
  );
  @override
  List<GeneratedColumn> get $columns => [id, idWmsRua, codigo, quantidadeCaixa];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'wms_estante';
  @override
  VerificationContext validateIntegrity(
    Insertable<WmsEstante> instance, {
    bool isInserting = false,
  }) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('id_wms_rua')) {
      context.handle(
        _idWmsRuaMeta,
        idWmsRua.isAcceptableOrUnknown(data['id_wms_rua']!, _idWmsRuaMeta),
      );
    }
    if (data.containsKey('codigo')) {
      context.handle(
        _codigoMeta,
        codigo.isAcceptableOrUnknown(data['codigo']!, _codigoMeta),
      );
    }
    if (data.containsKey('quantidade_caixa')) {
      context.handle(
        _quantidadeCaixaMeta,
        quantidadeCaixa.isAcceptableOrUnknown(
          data['quantidade_caixa']!,
          _quantidadeCaixaMeta,
        ),
      );
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  WmsEstante map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return WmsEstante(
      id: attachedDatabase.typeMapping.read(
        DriftSqlType.int,
        data['${effectivePrefix}id'],
      ),
      idWmsRua: attachedDatabase.typeMapping.read(
        DriftSqlType.int,
        data['${effectivePrefix}id_wms_rua'],
      ),
      codigo: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}codigo'],
      ),
      quantidadeCaixa: attachedDatabase.typeMapping.read(
        DriftSqlType.int,
        data['${effectivePrefix}quantidade_caixa'],
      ),
    );
  }

  @override
  $WmsEstantesTable createAlias(String alias) {
    return $WmsEstantesTable(attachedDatabase, alias);
  }
}

class WmsEstante extends DataClass implements Insertable<WmsEstante> {
  final int? id;
  final int? idWmsRua;
  final String? codigo;
  final int? quantidadeCaixa;
  const WmsEstante({this.id, this.idWmsRua, this.codigo, this.quantidadeCaixa});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || idWmsRua != null) {
      map['id_wms_rua'] = Variable<int>(idWmsRua);
    }
    if (!nullToAbsent || codigo != null) {
      map['codigo'] = Variable<String>(codigo);
    }
    if (!nullToAbsent || quantidadeCaixa != null) {
      map['quantidade_caixa'] = Variable<int>(quantidadeCaixa);
    }
    return map;
  }

  factory WmsEstante.fromJson(
    Map<String, dynamic> json, {
    ValueSerializer? serializer,
  }) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return WmsEstante(
      id: serializer.fromJson<int?>(json['id']),
      idWmsRua: serializer.fromJson<int?>(json['idWmsRua']),
      codigo: serializer.fromJson<String?>(json['codigo']),
      quantidadeCaixa: serializer.fromJson<int?>(json['quantidadeCaixa']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'idWmsRua': serializer.toJson<int?>(idWmsRua),
      'codigo': serializer.toJson<String?>(codigo),
      'quantidadeCaixa': serializer.toJson<int?>(quantidadeCaixa),
    };
  }

  WmsEstante copyWith({
    Value<int?> id = const Value.absent(),
    Value<int?> idWmsRua = const Value.absent(),
    Value<String?> codigo = const Value.absent(),
    Value<int?> quantidadeCaixa = const Value.absent(),
  }) => WmsEstante(
    id: id.present ? id.value : this.id,
    idWmsRua: idWmsRua.present ? idWmsRua.value : this.idWmsRua,
    codigo: codigo.present ? codigo.value : this.codigo,
    quantidadeCaixa:
        quantidadeCaixa.present ? quantidadeCaixa.value : this.quantidadeCaixa,
  );
  WmsEstante copyWithCompanion(WmsEstantesCompanion data) {
    return WmsEstante(
      id: data.id.present ? data.id.value : this.id,
      idWmsRua: data.idWmsRua.present ? data.idWmsRua.value : this.idWmsRua,
      codigo: data.codigo.present ? data.codigo.value : this.codigo,
      quantidadeCaixa:
          data.quantidadeCaixa.present
              ? data.quantidadeCaixa.value
              : this.quantidadeCaixa,
    );
  }

  @override
  String toString() {
    return (StringBuffer('WmsEstante(')
          ..write('id: $id, ')
          ..write('idWmsRua: $idWmsRua, ')
          ..write('codigo: $codigo, ')
          ..write('quantidadeCaixa: $quantidadeCaixa')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(id, idWmsRua, codigo, quantidadeCaixa);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is WmsEstante &&
          other.id == this.id &&
          other.idWmsRua == this.idWmsRua &&
          other.codigo == this.codigo &&
          other.quantidadeCaixa == this.quantidadeCaixa);
}

class WmsEstantesCompanion extends UpdateCompanion<WmsEstante> {
  final Value<int?> id;
  final Value<int?> idWmsRua;
  final Value<String?> codigo;
  final Value<int?> quantidadeCaixa;
  const WmsEstantesCompanion({
    this.id = const Value.absent(),
    this.idWmsRua = const Value.absent(),
    this.codigo = const Value.absent(),
    this.quantidadeCaixa = const Value.absent(),
  });
  WmsEstantesCompanion.insert({
    this.id = const Value.absent(),
    this.idWmsRua = const Value.absent(),
    this.codigo = const Value.absent(),
    this.quantidadeCaixa = const Value.absent(),
  });
  static Insertable<WmsEstante> custom({
    Expression<int>? id,
    Expression<int>? idWmsRua,
    Expression<String>? codigo,
    Expression<int>? quantidadeCaixa,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (idWmsRua != null) 'id_wms_rua': idWmsRua,
      if (codigo != null) 'codigo': codigo,
      if (quantidadeCaixa != null) 'quantidade_caixa': quantidadeCaixa,
    });
  }

  WmsEstantesCompanion copyWith({
    Value<int?>? id,
    Value<int?>? idWmsRua,
    Value<String?>? codigo,
    Value<int?>? quantidadeCaixa,
  }) {
    return WmsEstantesCompanion(
      id: id ?? this.id,
      idWmsRua: idWmsRua ?? this.idWmsRua,
      codigo: codigo ?? this.codigo,
      quantidadeCaixa: quantidadeCaixa ?? this.quantidadeCaixa,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (idWmsRua.present) {
      map['id_wms_rua'] = Variable<int>(idWmsRua.value);
    }
    if (codigo.present) {
      map['codigo'] = Variable<String>(codigo.value);
    }
    if (quantidadeCaixa.present) {
      map['quantidade_caixa'] = Variable<int>(quantidadeCaixa.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('WmsEstantesCompanion(')
          ..write('id: $id, ')
          ..write('idWmsRua: $idWmsRua, ')
          ..write('codigo: $codigo, ')
          ..write('quantidadeCaixa: $quantidadeCaixa')
          ..write(')'))
        .toString();
  }
}

class $WmsOrdemSeparacaoCabsTable extends WmsOrdemSeparacaoCabs
    with TableInfo<$WmsOrdemSeparacaoCabsTable, WmsOrdemSeparacaoCab> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $WmsOrdemSeparacaoCabsTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
    'id',
    aliasedName,
    true,
    type: DriftSqlType.int,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _origemMeta = const VerificationMeta('origem');
  @override
  late final GeneratedColumn<String> origem = GeneratedColumn<String>(
    'origem',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 1,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _dataSolicitacaoMeta = const VerificationMeta(
    'dataSolicitacao',
  );
  @override
  late final GeneratedColumn<DateTime> dataSolicitacao =
      GeneratedColumn<DateTime>(
        'data_solicitacao',
        aliasedName,
        true,
        type: DriftSqlType.dateTime,
        requiredDuringInsert: false,
      );
  static const VerificationMeta _dataLimiteMeta = const VerificationMeta(
    'dataLimite',
  );
  @override
  late final GeneratedColumn<DateTime> dataLimite = GeneratedColumn<DateTime>(
    'data_limite',
    aliasedName,
    true,
    type: DriftSqlType.dateTime,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _codigoSeparacaoMeta = const VerificationMeta(
    'codigoSeparacao',
  );
  @override
  late final GeneratedColumn<String> codigoSeparacao = GeneratedColumn<String>(
    'codigo_separacao',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 32,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  @override
  List<GeneratedColumn> get $columns => [
    id,
    origem,
    dataSolicitacao,
    dataLimite,
    codigoSeparacao,
  ];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'wms_ordem_separacao_cab';
  @override
  VerificationContext validateIntegrity(
    Insertable<WmsOrdemSeparacaoCab> instance, {
    bool isInserting = false,
  }) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('origem')) {
      context.handle(
        _origemMeta,
        origem.isAcceptableOrUnknown(data['origem']!, _origemMeta),
      );
    }
    if (data.containsKey('data_solicitacao')) {
      context.handle(
        _dataSolicitacaoMeta,
        dataSolicitacao.isAcceptableOrUnknown(
          data['data_solicitacao']!,
          _dataSolicitacaoMeta,
        ),
      );
    }
    if (data.containsKey('data_limite')) {
      context.handle(
        _dataLimiteMeta,
        dataLimite.isAcceptableOrUnknown(data['data_limite']!, _dataLimiteMeta),
      );
    }
    if (data.containsKey('codigo_separacao')) {
      context.handle(
        _codigoSeparacaoMeta,
        codigoSeparacao.isAcceptableOrUnknown(
          data['codigo_separacao']!,
          _codigoSeparacaoMeta,
        ),
      );
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  WmsOrdemSeparacaoCab map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return WmsOrdemSeparacaoCab(
      id: attachedDatabase.typeMapping.read(
        DriftSqlType.int,
        data['${effectivePrefix}id'],
      ),
      origem: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}origem'],
      ),
      dataSolicitacao: attachedDatabase.typeMapping.read(
        DriftSqlType.dateTime,
        data['${effectivePrefix}data_solicitacao'],
      ),
      dataLimite: attachedDatabase.typeMapping.read(
        DriftSqlType.dateTime,
        data['${effectivePrefix}data_limite'],
      ),
      codigoSeparacao: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}codigo_separacao'],
      ),
    );
  }

  @override
  $WmsOrdemSeparacaoCabsTable createAlias(String alias) {
    return $WmsOrdemSeparacaoCabsTable(attachedDatabase, alias);
  }
}

class WmsOrdemSeparacaoCab extends DataClass
    implements Insertable<WmsOrdemSeparacaoCab> {
  final int? id;
  final String? origem;
  final DateTime? dataSolicitacao;
  final DateTime? dataLimite;
  final String? codigoSeparacao;
  const WmsOrdemSeparacaoCab({
    this.id,
    this.origem,
    this.dataSolicitacao,
    this.dataLimite,
    this.codigoSeparacao,
  });
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || origem != null) {
      map['origem'] = Variable<String>(origem);
    }
    if (!nullToAbsent || dataSolicitacao != null) {
      map['data_solicitacao'] = Variable<DateTime>(dataSolicitacao);
    }
    if (!nullToAbsent || dataLimite != null) {
      map['data_limite'] = Variable<DateTime>(dataLimite);
    }
    if (!nullToAbsent || codigoSeparacao != null) {
      map['codigo_separacao'] = Variable<String>(codigoSeparacao);
    }
    return map;
  }

  factory WmsOrdemSeparacaoCab.fromJson(
    Map<String, dynamic> json, {
    ValueSerializer? serializer,
  }) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return WmsOrdemSeparacaoCab(
      id: serializer.fromJson<int?>(json['id']),
      origem: serializer.fromJson<String?>(json['origem']),
      dataSolicitacao: serializer.fromJson<DateTime?>(json['dataSolicitacao']),
      dataLimite: serializer.fromJson<DateTime?>(json['dataLimite']),
      codigoSeparacao: serializer.fromJson<String?>(json['codigoSeparacao']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'origem': serializer.toJson<String?>(origem),
      'dataSolicitacao': serializer.toJson<DateTime?>(dataSolicitacao),
      'dataLimite': serializer.toJson<DateTime?>(dataLimite),
      'codigoSeparacao': serializer.toJson<String?>(codigoSeparacao),
    };
  }

  WmsOrdemSeparacaoCab copyWith({
    Value<int?> id = const Value.absent(),
    Value<String?> origem = const Value.absent(),
    Value<DateTime?> dataSolicitacao = const Value.absent(),
    Value<DateTime?> dataLimite = const Value.absent(),
    Value<String?> codigoSeparacao = const Value.absent(),
  }) => WmsOrdemSeparacaoCab(
    id: id.present ? id.value : this.id,
    origem: origem.present ? origem.value : this.origem,
    dataSolicitacao:
        dataSolicitacao.present ? dataSolicitacao.value : this.dataSolicitacao,
    dataLimite: dataLimite.present ? dataLimite.value : this.dataLimite,
    codigoSeparacao:
        codigoSeparacao.present ? codigoSeparacao.value : this.codigoSeparacao,
  );
  WmsOrdemSeparacaoCab copyWithCompanion(WmsOrdemSeparacaoCabsCompanion data) {
    return WmsOrdemSeparacaoCab(
      id: data.id.present ? data.id.value : this.id,
      origem: data.origem.present ? data.origem.value : this.origem,
      dataSolicitacao:
          data.dataSolicitacao.present
              ? data.dataSolicitacao.value
              : this.dataSolicitacao,
      dataLimite:
          data.dataLimite.present ? data.dataLimite.value : this.dataLimite,
      codigoSeparacao:
          data.codigoSeparacao.present
              ? data.codigoSeparacao.value
              : this.codigoSeparacao,
    );
  }

  @override
  String toString() {
    return (StringBuffer('WmsOrdemSeparacaoCab(')
          ..write('id: $id, ')
          ..write('origem: $origem, ')
          ..write('dataSolicitacao: $dataSolicitacao, ')
          ..write('dataLimite: $dataLimite, ')
          ..write('codigoSeparacao: $codigoSeparacao')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode =>
      Object.hash(id, origem, dataSolicitacao, dataLimite, codigoSeparacao);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is WmsOrdemSeparacaoCab &&
          other.id == this.id &&
          other.origem == this.origem &&
          other.dataSolicitacao == this.dataSolicitacao &&
          other.dataLimite == this.dataLimite &&
          other.codigoSeparacao == this.codigoSeparacao);
}

class WmsOrdemSeparacaoCabsCompanion
    extends UpdateCompanion<WmsOrdemSeparacaoCab> {
  final Value<int?> id;
  final Value<String?> origem;
  final Value<DateTime?> dataSolicitacao;
  final Value<DateTime?> dataLimite;
  final Value<String?> codigoSeparacao;
  const WmsOrdemSeparacaoCabsCompanion({
    this.id = const Value.absent(),
    this.origem = const Value.absent(),
    this.dataSolicitacao = const Value.absent(),
    this.dataLimite = const Value.absent(),
    this.codigoSeparacao = const Value.absent(),
  });
  WmsOrdemSeparacaoCabsCompanion.insert({
    this.id = const Value.absent(),
    this.origem = const Value.absent(),
    this.dataSolicitacao = const Value.absent(),
    this.dataLimite = const Value.absent(),
    this.codigoSeparacao = const Value.absent(),
  });
  static Insertable<WmsOrdemSeparacaoCab> custom({
    Expression<int>? id,
    Expression<String>? origem,
    Expression<DateTime>? dataSolicitacao,
    Expression<DateTime>? dataLimite,
    Expression<String>? codigoSeparacao,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (origem != null) 'origem': origem,
      if (dataSolicitacao != null) 'data_solicitacao': dataSolicitacao,
      if (dataLimite != null) 'data_limite': dataLimite,
      if (codigoSeparacao != null) 'codigo_separacao': codigoSeparacao,
    });
  }

  WmsOrdemSeparacaoCabsCompanion copyWith({
    Value<int?>? id,
    Value<String?>? origem,
    Value<DateTime?>? dataSolicitacao,
    Value<DateTime?>? dataLimite,
    Value<String?>? codigoSeparacao,
  }) {
    return WmsOrdemSeparacaoCabsCompanion(
      id: id ?? this.id,
      origem: origem ?? this.origem,
      dataSolicitacao: dataSolicitacao ?? this.dataSolicitacao,
      dataLimite: dataLimite ?? this.dataLimite,
      codigoSeparacao: codigoSeparacao ?? this.codigoSeparacao,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (origem.present) {
      map['origem'] = Variable<String>(origem.value);
    }
    if (dataSolicitacao.present) {
      map['data_solicitacao'] = Variable<DateTime>(dataSolicitacao.value);
    }
    if (dataLimite.present) {
      map['data_limite'] = Variable<DateTime>(dataLimite.value);
    }
    if (codigoSeparacao.present) {
      map['codigo_separacao'] = Variable<String>(codigoSeparacao.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('WmsOrdemSeparacaoCabsCompanion(')
          ..write('id: $id, ')
          ..write('origem: $origem, ')
          ..write('dataSolicitacao: $dataSolicitacao, ')
          ..write('dataLimite: $dataLimite, ')
          ..write('codigoSeparacao: $codigoSeparacao')
          ..write(')'))
        .toString();
  }
}

class $ProdutosTable extends Produtos with TableInfo<$ProdutosTable, Produto> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $ProdutosTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
    'id',
    aliasedName,
    true,
    type: DriftSqlType.int,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _idTributIcmsCustomCabMeta =
      const VerificationMeta('idTributIcmsCustomCab');
  @override
  late final GeneratedColumn<int> idTributIcmsCustomCab = GeneratedColumn<int>(
    'id_tribut_icms_custom_cab',
    aliasedName,
    true,
    type: DriftSqlType.int,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _idTributGrupoTributarioMeta =
      const VerificationMeta('idTributGrupoTributario');
  @override
  late final GeneratedColumn<int> idTributGrupoTributario =
      GeneratedColumn<int>(
        'id_tribut_grupo_tributario',
        aliasedName,
        true,
        type: DriftSqlType.int,
        requiredDuringInsert: false,
      );
  static const VerificationMeta _nomeMeta = const VerificationMeta('nome');
  @override
  late final GeneratedColumn<String> nome = GeneratedColumn<String>(
    'nome',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 100,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _descricaoMeta = const VerificationMeta(
    'descricao',
  );
  @override
  late final GeneratedColumn<String> descricao = GeneratedColumn<String>(
    'descricao',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 250,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _gtinMeta = const VerificationMeta('gtin');
  @override
  late final GeneratedColumn<String> gtin = GeneratedColumn<String>(
    'gtin',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 14,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _codigoInternoMeta = const VerificationMeta(
    'codigoInterno',
  );
  @override
  late final GeneratedColumn<String> codigoInterno = GeneratedColumn<String>(
    'codigo_interno',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 50,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _valorCompraMeta = const VerificationMeta(
    'valorCompra',
  );
  @override
  late final GeneratedColumn<double> valorCompra = GeneratedColumn<double>(
    'valor_compra',
    aliasedName,
    true,
    type: DriftSqlType.double,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _valorVendaMeta = const VerificationMeta(
    'valorVenda',
  );
  @override
  late final GeneratedColumn<double> valorVenda = GeneratedColumn<double>(
    'valor_venda',
    aliasedName,
    true,
    type: DriftSqlType.double,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _codigoNcmMeta = const VerificationMeta(
    'codigoNcm',
  );
  @override
  late final GeneratedColumn<String> codigoNcm = GeneratedColumn<String>(
    'codigo_ncm',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 8,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _estoqueMinimoMeta = const VerificationMeta(
    'estoqueMinimo',
  );
  @override
  late final GeneratedColumn<double> estoqueMinimo = GeneratedColumn<double>(
    'estoque_minimo',
    aliasedName,
    true,
    type: DriftSqlType.double,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _estoqueMaximoMeta = const VerificationMeta(
    'estoqueMaximo',
  );
  @override
  late final GeneratedColumn<double> estoqueMaximo = GeneratedColumn<double>(
    'estoque_maximo',
    aliasedName,
    true,
    type: DriftSqlType.double,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _quantidadeEstoqueMeta = const VerificationMeta(
    'quantidadeEstoque',
  );
  @override
  late final GeneratedColumn<double> quantidadeEstoque =
      GeneratedColumn<double>(
        'quantidade_estoque',
        aliasedName,
        true,
        type: DriftSqlType.double,
        requiredDuringInsert: false,
      );
  static const VerificationMeta _dataCadastroMeta = const VerificationMeta(
    'dataCadastro',
  );
  @override
  late final GeneratedColumn<DateTime> dataCadastro = GeneratedColumn<DateTime>(
    'data_cadastro',
    aliasedName,
    true,
    type: DriftSqlType.dateTime,
    requiredDuringInsert: false,
  );
  @override
  List<GeneratedColumn> get $columns => [
    id,
    idTributIcmsCustomCab,
    idTributGrupoTributario,
    nome,
    descricao,
    gtin,
    codigoInterno,
    valorCompra,
    valorVenda,
    codigoNcm,
    estoqueMinimo,
    estoqueMaximo,
    quantidadeEstoque,
    dataCadastro,
  ];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'produto';
  @override
  VerificationContext validateIntegrity(
    Insertable<Produto> instance, {
    bool isInserting = false,
  }) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('id_tribut_icms_custom_cab')) {
      context.handle(
        _idTributIcmsCustomCabMeta,
        idTributIcmsCustomCab.isAcceptableOrUnknown(
          data['id_tribut_icms_custom_cab']!,
          _idTributIcmsCustomCabMeta,
        ),
      );
    }
    if (data.containsKey('id_tribut_grupo_tributario')) {
      context.handle(
        _idTributGrupoTributarioMeta,
        idTributGrupoTributario.isAcceptableOrUnknown(
          data['id_tribut_grupo_tributario']!,
          _idTributGrupoTributarioMeta,
        ),
      );
    }
    if (data.containsKey('nome')) {
      context.handle(
        _nomeMeta,
        nome.isAcceptableOrUnknown(data['nome']!, _nomeMeta),
      );
    }
    if (data.containsKey('descricao')) {
      context.handle(
        _descricaoMeta,
        descricao.isAcceptableOrUnknown(data['descricao']!, _descricaoMeta),
      );
    }
    if (data.containsKey('gtin')) {
      context.handle(
        _gtinMeta,
        gtin.isAcceptableOrUnknown(data['gtin']!, _gtinMeta),
      );
    }
    if (data.containsKey('codigo_interno')) {
      context.handle(
        _codigoInternoMeta,
        codigoInterno.isAcceptableOrUnknown(
          data['codigo_interno']!,
          _codigoInternoMeta,
        ),
      );
    }
    if (data.containsKey('valor_compra')) {
      context.handle(
        _valorCompraMeta,
        valorCompra.isAcceptableOrUnknown(
          data['valor_compra']!,
          _valorCompraMeta,
        ),
      );
    }
    if (data.containsKey('valor_venda')) {
      context.handle(
        _valorVendaMeta,
        valorVenda.isAcceptableOrUnknown(data['valor_venda']!, _valorVendaMeta),
      );
    }
    if (data.containsKey('codigo_ncm')) {
      context.handle(
        _codigoNcmMeta,
        codigoNcm.isAcceptableOrUnknown(data['codigo_ncm']!, _codigoNcmMeta),
      );
    }
    if (data.containsKey('estoque_minimo')) {
      context.handle(
        _estoqueMinimoMeta,
        estoqueMinimo.isAcceptableOrUnknown(
          data['estoque_minimo']!,
          _estoqueMinimoMeta,
        ),
      );
    }
    if (data.containsKey('estoque_maximo')) {
      context.handle(
        _estoqueMaximoMeta,
        estoqueMaximo.isAcceptableOrUnknown(
          data['estoque_maximo']!,
          _estoqueMaximoMeta,
        ),
      );
    }
    if (data.containsKey('quantidade_estoque')) {
      context.handle(
        _quantidadeEstoqueMeta,
        quantidadeEstoque.isAcceptableOrUnknown(
          data['quantidade_estoque']!,
          _quantidadeEstoqueMeta,
        ),
      );
    }
    if (data.containsKey('data_cadastro')) {
      context.handle(
        _dataCadastroMeta,
        dataCadastro.isAcceptableOrUnknown(
          data['data_cadastro']!,
          _dataCadastroMeta,
        ),
      );
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  Produto map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return Produto(
      id: attachedDatabase.typeMapping.read(
        DriftSqlType.int,
        data['${effectivePrefix}id'],
      ),
      idTributIcmsCustomCab: attachedDatabase.typeMapping.read(
        DriftSqlType.int,
        data['${effectivePrefix}id_tribut_icms_custom_cab'],
      ),
      idTributGrupoTributario: attachedDatabase.typeMapping.read(
        DriftSqlType.int,
        data['${effectivePrefix}id_tribut_grupo_tributario'],
      ),
      nome: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}nome'],
      ),
      descricao: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}descricao'],
      ),
      gtin: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}gtin'],
      ),
      codigoInterno: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}codigo_interno'],
      ),
      valorCompra: attachedDatabase.typeMapping.read(
        DriftSqlType.double,
        data['${effectivePrefix}valor_compra'],
      ),
      valorVenda: attachedDatabase.typeMapping.read(
        DriftSqlType.double,
        data['${effectivePrefix}valor_venda'],
      ),
      codigoNcm: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}codigo_ncm'],
      ),
      estoqueMinimo: attachedDatabase.typeMapping.read(
        DriftSqlType.double,
        data['${effectivePrefix}estoque_minimo'],
      ),
      estoqueMaximo: attachedDatabase.typeMapping.read(
        DriftSqlType.double,
        data['${effectivePrefix}estoque_maximo'],
      ),
      quantidadeEstoque: attachedDatabase.typeMapping.read(
        DriftSqlType.double,
        data['${effectivePrefix}quantidade_estoque'],
      ),
      dataCadastro: attachedDatabase.typeMapping.read(
        DriftSqlType.dateTime,
        data['${effectivePrefix}data_cadastro'],
      ),
    );
  }

  @override
  $ProdutosTable createAlias(String alias) {
    return $ProdutosTable(attachedDatabase, alias);
  }
}

class Produto extends DataClass implements Insertable<Produto> {
  final int? id;
  final int? idTributIcmsCustomCab;
  final int? idTributGrupoTributario;
  final String? nome;
  final String? descricao;
  final String? gtin;
  final String? codigoInterno;
  final double? valorCompra;
  final double? valorVenda;
  final String? codigoNcm;
  final double? estoqueMinimo;
  final double? estoqueMaximo;
  final double? quantidadeEstoque;
  final DateTime? dataCadastro;
  const Produto({
    this.id,
    this.idTributIcmsCustomCab,
    this.idTributGrupoTributario,
    this.nome,
    this.descricao,
    this.gtin,
    this.codigoInterno,
    this.valorCompra,
    this.valorVenda,
    this.codigoNcm,
    this.estoqueMinimo,
    this.estoqueMaximo,
    this.quantidadeEstoque,
    this.dataCadastro,
  });
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || idTributIcmsCustomCab != null) {
      map['id_tribut_icms_custom_cab'] = Variable<int>(idTributIcmsCustomCab);
    }
    if (!nullToAbsent || idTributGrupoTributario != null) {
      map['id_tribut_grupo_tributario'] = Variable<int>(
        idTributGrupoTributario,
      );
    }
    if (!nullToAbsent || nome != null) {
      map['nome'] = Variable<String>(nome);
    }
    if (!nullToAbsent || descricao != null) {
      map['descricao'] = Variable<String>(descricao);
    }
    if (!nullToAbsent || gtin != null) {
      map['gtin'] = Variable<String>(gtin);
    }
    if (!nullToAbsent || codigoInterno != null) {
      map['codigo_interno'] = Variable<String>(codigoInterno);
    }
    if (!nullToAbsent || valorCompra != null) {
      map['valor_compra'] = Variable<double>(valorCompra);
    }
    if (!nullToAbsent || valorVenda != null) {
      map['valor_venda'] = Variable<double>(valorVenda);
    }
    if (!nullToAbsent || codigoNcm != null) {
      map['codigo_ncm'] = Variable<String>(codigoNcm);
    }
    if (!nullToAbsent || estoqueMinimo != null) {
      map['estoque_minimo'] = Variable<double>(estoqueMinimo);
    }
    if (!nullToAbsent || estoqueMaximo != null) {
      map['estoque_maximo'] = Variable<double>(estoqueMaximo);
    }
    if (!nullToAbsent || quantidadeEstoque != null) {
      map['quantidade_estoque'] = Variable<double>(quantidadeEstoque);
    }
    if (!nullToAbsent || dataCadastro != null) {
      map['data_cadastro'] = Variable<DateTime>(dataCadastro);
    }
    return map;
  }

  factory Produto.fromJson(
    Map<String, dynamic> json, {
    ValueSerializer? serializer,
  }) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return Produto(
      id: serializer.fromJson<int?>(json['id']),
      idTributIcmsCustomCab: serializer.fromJson<int?>(
        json['idTributIcmsCustomCab'],
      ),
      idTributGrupoTributario: serializer.fromJson<int?>(
        json['idTributGrupoTributario'],
      ),
      nome: serializer.fromJson<String?>(json['nome']),
      descricao: serializer.fromJson<String?>(json['descricao']),
      gtin: serializer.fromJson<String?>(json['gtin']),
      codigoInterno: serializer.fromJson<String?>(json['codigoInterno']),
      valorCompra: serializer.fromJson<double?>(json['valorCompra']),
      valorVenda: serializer.fromJson<double?>(json['valorVenda']),
      codigoNcm: serializer.fromJson<String?>(json['codigoNcm']),
      estoqueMinimo: serializer.fromJson<double?>(json['estoqueMinimo']),
      estoqueMaximo: serializer.fromJson<double?>(json['estoqueMaximo']),
      quantidadeEstoque: serializer.fromJson<double?>(
        json['quantidadeEstoque'],
      ),
      dataCadastro: serializer.fromJson<DateTime?>(json['dataCadastro']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'idTributIcmsCustomCab': serializer.toJson<int?>(idTributIcmsCustomCab),
      'idTributGrupoTributario': serializer.toJson<int?>(
        idTributGrupoTributario,
      ),
      'nome': serializer.toJson<String?>(nome),
      'descricao': serializer.toJson<String?>(descricao),
      'gtin': serializer.toJson<String?>(gtin),
      'codigoInterno': serializer.toJson<String?>(codigoInterno),
      'valorCompra': serializer.toJson<double?>(valorCompra),
      'valorVenda': serializer.toJson<double?>(valorVenda),
      'codigoNcm': serializer.toJson<String?>(codigoNcm),
      'estoqueMinimo': serializer.toJson<double?>(estoqueMinimo),
      'estoqueMaximo': serializer.toJson<double?>(estoqueMaximo),
      'quantidadeEstoque': serializer.toJson<double?>(quantidadeEstoque),
      'dataCadastro': serializer.toJson<DateTime?>(dataCadastro),
    };
  }

  Produto copyWith({
    Value<int?> id = const Value.absent(),
    Value<int?> idTributIcmsCustomCab = const Value.absent(),
    Value<int?> idTributGrupoTributario = const Value.absent(),
    Value<String?> nome = const Value.absent(),
    Value<String?> descricao = const Value.absent(),
    Value<String?> gtin = const Value.absent(),
    Value<String?> codigoInterno = const Value.absent(),
    Value<double?> valorCompra = const Value.absent(),
    Value<double?> valorVenda = const Value.absent(),
    Value<String?> codigoNcm = const Value.absent(),
    Value<double?> estoqueMinimo = const Value.absent(),
    Value<double?> estoqueMaximo = const Value.absent(),
    Value<double?> quantidadeEstoque = const Value.absent(),
    Value<DateTime?> dataCadastro = const Value.absent(),
  }) => Produto(
    id: id.present ? id.value : this.id,
    idTributIcmsCustomCab:
        idTributIcmsCustomCab.present
            ? idTributIcmsCustomCab.value
            : this.idTributIcmsCustomCab,
    idTributGrupoTributario:
        idTributGrupoTributario.present
            ? idTributGrupoTributario.value
            : this.idTributGrupoTributario,
    nome: nome.present ? nome.value : this.nome,
    descricao: descricao.present ? descricao.value : this.descricao,
    gtin: gtin.present ? gtin.value : this.gtin,
    codigoInterno:
        codigoInterno.present ? codigoInterno.value : this.codigoInterno,
    valorCompra: valorCompra.present ? valorCompra.value : this.valorCompra,
    valorVenda: valorVenda.present ? valorVenda.value : this.valorVenda,
    codigoNcm: codigoNcm.present ? codigoNcm.value : this.codigoNcm,
    estoqueMinimo:
        estoqueMinimo.present ? estoqueMinimo.value : this.estoqueMinimo,
    estoqueMaximo:
        estoqueMaximo.present ? estoqueMaximo.value : this.estoqueMaximo,
    quantidadeEstoque:
        quantidadeEstoque.present
            ? quantidadeEstoque.value
            : this.quantidadeEstoque,
    dataCadastro: dataCadastro.present ? dataCadastro.value : this.dataCadastro,
  );
  Produto copyWithCompanion(ProdutosCompanion data) {
    return Produto(
      id: data.id.present ? data.id.value : this.id,
      idTributIcmsCustomCab:
          data.idTributIcmsCustomCab.present
              ? data.idTributIcmsCustomCab.value
              : this.idTributIcmsCustomCab,
      idTributGrupoTributario:
          data.idTributGrupoTributario.present
              ? data.idTributGrupoTributario.value
              : this.idTributGrupoTributario,
      nome: data.nome.present ? data.nome.value : this.nome,
      descricao: data.descricao.present ? data.descricao.value : this.descricao,
      gtin: data.gtin.present ? data.gtin.value : this.gtin,
      codigoInterno:
          data.codigoInterno.present
              ? data.codigoInterno.value
              : this.codigoInterno,
      valorCompra:
          data.valorCompra.present ? data.valorCompra.value : this.valorCompra,
      valorVenda:
          data.valorVenda.present ? data.valorVenda.value : this.valorVenda,
      codigoNcm: data.codigoNcm.present ? data.codigoNcm.value : this.codigoNcm,
      estoqueMinimo:
          data.estoqueMinimo.present
              ? data.estoqueMinimo.value
              : this.estoqueMinimo,
      estoqueMaximo:
          data.estoqueMaximo.present
              ? data.estoqueMaximo.value
              : this.estoqueMaximo,
      quantidadeEstoque:
          data.quantidadeEstoque.present
              ? data.quantidadeEstoque.value
              : this.quantidadeEstoque,
      dataCadastro:
          data.dataCadastro.present
              ? data.dataCadastro.value
              : this.dataCadastro,
    );
  }

  @override
  String toString() {
    return (StringBuffer('Produto(')
          ..write('id: $id, ')
          ..write('idTributIcmsCustomCab: $idTributIcmsCustomCab, ')
          ..write('idTributGrupoTributario: $idTributGrupoTributario, ')
          ..write('nome: $nome, ')
          ..write('descricao: $descricao, ')
          ..write('gtin: $gtin, ')
          ..write('codigoInterno: $codigoInterno, ')
          ..write('valorCompra: $valorCompra, ')
          ..write('valorVenda: $valorVenda, ')
          ..write('codigoNcm: $codigoNcm, ')
          ..write('estoqueMinimo: $estoqueMinimo, ')
          ..write('estoqueMaximo: $estoqueMaximo, ')
          ..write('quantidadeEstoque: $quantidadeEstoque, ')
          ..write('dataCadastro: $dataCadastro')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(
    id,
    idTributIcmsCustomCab,
    idTributGrupoTributario,
    nome,
    descricao,
    gtin,
    codigoInterno,
    valorCompra,
    valorVenda,
    codigoNcm,
    estoqueMinimo,
    estoqueMaximo,
    quantidadeEstoque,
    dataCadastro,
  );
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is Produto &&
          other.id == this.id &&
          other.idTributIcmsCustomCab == this.idTributIcmsCustomCab &&
          other.idTributGrupoTributario == this.idTributGrupoTributario &&
          other.nome == this.nome &&
          other.descricao == this.descricao &&
          other.gtin == this.gtin &&
          other.codigoInterno == this.codigoInterno &&
          other.valorCompra == this.valorCompra &&
          other.valorVenda == this.valorVenda &&
          other.codigoNcm == this.codigoNcm &&
          other.estoqueMinimo == this.estoqueMinimo &&
          other.estoqueMaximo == this.estoqueMaximo &&
          other.quantidadeEstoque == this.quantidadeEstoque &&
          other.dataCadastro == this.dataCadastro);
}

class ProdutosCompanion extends UpdateCompanion<Produto> {
  final Value<int?> id;
  final Value<int?> idTributIcmsCustomCab;
  final Value<int?> idTributGrupoTributario;
  final Value<String?> nome;
  final Value<String?> descricao;
  final Value<String?> gtin;
  final Value<String?> codigoInterno;
  final Value<double?> valorCompra;
  final Value<double?> valorVenda;
  final Value<String?> codigoNcm;
  final Value<double?> estoqueMinimo;
  final Value<double?> estoqueMaximo;
  final Value<double?> quantidadeEstoque;
  final Value<DateTime?> dataCadastro;
  const ProdutosCompanion({
    this.id = const Value.absent(),
    this.idTributIcmsCustomCab = const Value.absent(),
    this.idTributGrupoTributario = const Value.absent(),
    this.nome = const Value.absent(),
    this.descricao = const Value.absent(),
    this.gtin = const Value.absent(),
    this.codigoInterno = const Value.absent(),
    this.valorCompra = const Value.absent(),
    this.valorVenda = const Value.absent(),
    this.codigoNcm = const Value.absent(),
    this.estoqueMinimo = const Value.absent(),
    this.estoqueMaximo = const Value.absent(),
    this.quantidadeEstoque = const Value.absent(),
    this.dataCadastro = const Value.absent(),
  });
  ProdutosCompanion.insert({
    this.id = const Value.absent(),
    this.idTributIcmsCustomCab = const Value.absent(),
    this.idTributGrupoTributario = const Value.absent(),
    this.nome = const Value.absent(),
    this.descricao = const Value.absent(),
    this.gtin = const Value.absent(),
    this.codigoInterno = const Value.absent(),
    this.valorCompra = const Value.absent(),
    this.valorVenda = const Value.absent(),
    this.codigoNcm = const Value.absent(),
    this.estoqueMinimo = const Value.absent(),
    this.estoqueMaximo = const Value.absent(),
    this.quantidadeEstoque = const Value.absent(),
    this.dataCadastro = const Value.absent(),
  });
  static Insertable<Produto> custom({
    Expression<int>? id,
    Expression<int>? idTributIcmsCustomCab,
    Expression<int>? idTributGrupoTributario,
    Expression<String>? nome,
    Expression<String>? descricao,
    Expression<String>? gtin,
    Expression<String>? codigoInterno,
    Expression<double>? valorCompra,
    Expression<double>? valorVenda,
    Expression<String>? codigoNcm,
    Expression<double>? estoqueMinimo,
    Expression<double>? estoqueMaximo,
    Expression<double>? quantidadeEstoque,
    Expression<DateTime>? dataCadastro,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (idTributIcmsCustomCab != null)
        'id_tribut_icms_custom_cab': idTributIcmsCustomCab,
      if (idTributGrupoTributario != null)
        'id_tribut_grupo_tributario': idTributGrupoTributario,
      if (nome != null) 'nome': nome,
      if (descricao != null) 'descricao': descricao,
      if (gtin != null) 'gtin': gtin,
      if (codigoInterno != null) 'codigo_interno': codigoInterno,
      if (valorCompra != null) 'valor_compra': valorCompra,
      if (valorVenda != null) 'valor_venda': valorVenda,
      if (codigoNcm != null) 'codigo_ncm': codigoNcm,
      if (estoqueMinimo != null) 'estoque_minimo': estoqueMinimo,
      if (estoqueMaximo != null) 'estoque_maximo': estoqueMaximo,
      if (quantidadeEstoque != null) 'quantidade_estoque': quantidadeEstoque,
      if (dataCadastro != null) 'data_cadastro': dataCadastro,
    });
  }

  ProdutosCompanion copyWith({
    Value<int?>? id,
    Value<int?>? idTributIcmsCustomCab,
    Value<int?>? idTributGrupoTributario,
    Value<String?>? nome,
    Value<String?>? descricao,
    Value<String?>? gtin,
    Value<String?>? codigoInterno,
    Value<double?>? valorCompra,
    Value<double?>? valorVenda,
    Value<String?>? codigoNcm,
    Value<double?>? estoqueMinimo,
    Value<double?>? estoqueMaximo,
    Value<double?>? quantidadeEstoque,
    Value<DateTime?>? dataCadastro,
  }) {
    return ProdutosCompanion(
      id: id ?? this.id,
      idTributIcmsCustomCab:
          idTributIcmsCustomCab ?? this.idTributIcmsCustomCab,
      idTributGrupoTributario:
          idTributGrupoTributario ?? this.idTributGrupoTributario,
      nome: nome ?? this.nome,
      descricao: descricao ?? this.descricao,
      gtin: gtin ?? this.gtin,
      codigoInterno: codigoInterno ?? this.codigoInterno,
      valorCompra: valorCompra ?? this.valorCompra,
      valorVenda: valorVenda ?? this.valorVenda,
      codigoNcm: codigoNcm ?? this.codigoNcm,
      estoqueMinimo: estoqueMinimo ?? this.estoqueMinimo,
      estoqueMaximo: estoqueMaximo ?? this.estoqueMaximo,
      quantidadeEstoque: quantidadeEstoque ?? this.quantidadeEstoque,
      dataCadastro: dataCadastro ?? this.dataCadastro,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (idTributIcmsCustomCab.present) {
      map['id_tribut_icms_custom_cab'] = Variable<int>(
        idTributIcmsCustomCab.value,
      );
    }
    if (idTributGrupoTributario.present) {
      map['id_tribut_grupo_tributario'] = Variable<int>(
        idTributGrupoTributario.value,
      );
    }
    if (nome.present) {
      map['nome'] = Variable<String>(nome.value);
    }
    if (descricao.present) {
      map['descricao'] = Variable<String>(descricao.value);
    }
    if (gtin.present) {
      map['gtin'] = Variable<String>(gtin.value);
    }
    if (codigoInterno.present) {
      map['codigo_interno'] = Variable<String>(codigoInterno.value);
    }
    if (valorCompra.present) {
      map['valor_compra'] = Variable<double>(valorCompra.value);
    }
    if (valorVenda.present) {
      map['valor_venda'] = Variable<double>(valorVenda.value);
    }
    if (codigoNcm.present) {
      map['codigo_ncm'] = Variable<String>(codigoNcm.value);
    }
    if (estoqueMinimo.present) {
      map['estoque_minimo'] = Variable<double>(estoqueMinimo.value);
    }
    if (estoqueMaximo.present) {
      map['estoque_maximo'] = Variable<double>(estoqueMaximo.value);
    }
    if (quantidadeEstoque.present) {
      map['quantidade_estoque'] = Variable<double>(quantidadeEstoque.value);
    }
    if (dataCadastro.present) {
      map['data_cadastro'] = Variable<DateTime>(dataCadastro.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('ProdutosCompanion(')
          ..write('id: $id, ')
          ..write('idTributIcmsCustomCab: $idTributIcmsCustomCab, ')
          ..write('idTributGrupoTributario: $idTributGrupoTributario, ')
          ..write('nome: $nome, ')
          ..write('descricao: $descricao, ')
          ..write('gtin: $gtin, ')
          ..write('codigoInterno: $codigoInterno, ')
          ..write('valorCompra: $valorCompra, ')
          ..write('valorVenda: $valorVenda, ')
          ..write('codigoNcm: $codigoNcm, ')
          ..write('estoqueMinimo: $estoqueMinimo, ')
          ..write('estoqueMaximo: $estoqueMaximo, ')
          ..write('quantidadeEstoque: $quantidadeEstoque, ')
          ..write('dataCadastro: $dataCadastro')
          ..write(')'))
        .toString();
  }
}

class $WmsAgendamentosTable extends WmsAgendamentos
    with TableInfo<$WmsAgendamentosTable, WmsAgendamento> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $WmsAgendamentosTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
    'id',
    aliasedName,
    true,
    type: DriftSqlType.int,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _dataOperacaoMeta = const VerificationMeta(
    'dataOperacao',
  );
  @override
  late final GeneratedColumn<DateTime> dataOperacao = GeneratedColumn<DateTime>(
    'data_operacao',
    aliasedName,
    true,
    type: DriftSqlType.dateTime,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _horaOperacaoMeta = const VerificationMeta(
    'horaOperacao',
  );
  @override
  late final GeneratedColumn<String> horaOperacao = GeneratedColumn<String>(
    'hora_operacao',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 8,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _localOperacaoMeta = const VerificationMeta(
    'localOperacao',
  );
  @override
  late final GeneratedColumn<String> localOperacao = GeneratedColumn<String>(
    'local_operacao',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 100,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _quantidadeVolumeMeta = const VerificationMeta(
    'quantidadeVolume',
  );
  @override
  late final GeneratedColumn<int> quantidadeVolume = GeneratedColumn<int>(
    'quantidade_volume',
    aliasedName,
    true,
    type: DriftSqlType.int,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _pesoTotalVolumeMeta = const VerificationMeta(
    'pesoTotalVolume',
  );
  @override
  late final GeneratedColumn<double> pesoTotalVolume = GeneratedColumn<double>(
    'peso_total_volume',
    aliasedName,
    true,
    type: DriftSqlType.double,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _quantidadePessoaMeta = const VerificationMeta(
    'quantidadePessoa',
  );
  @override
  late final GeneratedColumn<int> quantidadePessoa = GeneratedColumn<int>(
    'quantidade_pessoa',
    aliasedName,
    true,
    type: DriftSqlType.int,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _quantidadeHoraMeta = const VerificationMeta(
    'quantidadeHora',
  );
  @override
  late final GeneratedColumn<int> quantidadeHora = GeneratedColumn<int>(
    'quantidade_hora',
    aliasedName,
    true,
    type: DriftSqlType.int,
    requiredDuringInsert: false,
  );
  @override
  List<GeneratedColumn> get $columns => [
    id,
    dataOperacao,
    horaOperacao,
    localOperacao,
    quantidadeVolume,
    pesoTotalVolume,
    quantidadePessoa,
    quantidadeHora,
  ];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'wms_agendamento';
  @override
  VerificationContext validateIntegrity(
    Insertable<WmsAgendamento> instance, {
    bool isInserting = false,
  }) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('data_operacao')) {
      context.handle(
        _dataOperacaoMeta,
        dataOperacao.isAcceptableOrUnknown(
          data['data_operacao']!,
          _dataOperacaoMeta,
        ),
      );
    }
    if (data.containsKey('hora_operacao')) {
      context.handle(
        _horaOperacaoMeta,
        horaOperacao.isAcceptableOrUnknown(
          data['hora_operacao']!,
          _horaOperacaoMeta,
        ),
      );
    }
    if (data.containsKey('local_operacao')) {
      context.handle(
        _localOperacaoMeta,
        localOperacao.isAcceptableOrUnknown(
          data['local_operacao']!,
          _localOperacaoMeta,
        ),
      );
    }
    if (data.containsKey('quantidade_volume')) {
      context.handle(
        _quantidadeVolumeMeta,
        quantidadeVolume.isAcceptableOrUnknown(
          data['quantidade_volume']!,
          _quantidadeVolumeMeta,
        ),
      );
    }
    if (data.containsKey('peso_total_volume')) {
      context.handle(
        _pesoTotalVolumeMeta,
        pesoTotalVolume.isAcceptableOrUnknown(
          data['peso_total_volume']!,
          _pesoTotalVolumeMeta,
        ),
      );
    }
    if (data.containsKey('quantidade_pessoa')) {
      context.handle(
        _quantidadePessoaMeta,
        quantidadePessoa.isAcceptableOrUnknown(
          data['quantidade_pessoa']!,
          _quantidadePessoaMeta,
        ),
      );
    }
    if (data.containsKey('quantidade_hora')) {
      context.handle(
        _quantidadeHoraMeta,
        quantidadeHora.isAcceptableOrUnknown(
          data['quantidade_hora']!,
          _quantidadeHoraMeta,
        ),
      );
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  WmsAgendamento map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return WmsAgendamento(
      id: attachedDatabase.typeMapping.read(
        DriftSqlType.int,
        data['${effectivePrefix}id'],
      ),
      dataOperacao: attachedDatabase.typeMapping.read(
        DriftSqlType.dateTime,
        data['${effectivePrefix}data_operacao'],
      ),
      horaOperacao: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}hora_operacao'],
      ),
      localOperacao: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}local_operacao'],
      ),
      quantidadeVolume: attachedDatabase.typeMapping.read(
        DriftSqlType.int,
        data['${effectivePrefix}quantidade_volume'],
      ),
      pesoTotalVolume: attachedDatabase.typeMapping.read(
        DriftSqlType.double,
        data['${effectivePrefix}peso_total_volume'],
      ),
      quantidadePessoa: attachedDatabase.typeMapping.read(
        DriftSqlType.int,
        data['${effectivePrefix}quantidade_pessoa'],
      ),
      quantidadeHora: attachedDatabase.typeMapping.read(
        DriftSqlType.int,
        data['${effectivePrefix}quantidade_hora'],
      ),
    );
  }

  @override
  $WmsAgendamentosTable createAlias(String alias) {
    return $WmsAgendamentosTable(attachedDatabase, alias);
  }
}

class WmsAgendamento extends DataClass implements Insertable<WmsAgendamento> {
  final int? id;
  final DateTime? dataOperacao;
  final String? horaOperacao;
  final String? localOperacao;
  final int? quantidadeVolume;
  final double? pesoTotalVolume;
  final int? quantidadePessoa;
  final int? quantidadeHora;
  const WmsAgendamento({
    this.id,
    this.dataOperacao,
    this.horaOperacao,
    this.localOperacao,
    this.quantidadeVolume,
    this.pesoTotalVolume,
    this.quantidadePessoa,
    this.quantidadeHora,
  });
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || dataOperacao != null) {
      map['data_operacao'] = Variable<DateTime>(dataOperacao);
    }
    if (!nullToAbsent || horaOperacao != null) {
      map['hora_operacao'] = Variable<String>(horaOperacao);
    }
    if (!nullToAbsent || localOperacao != null) {
      map['local_operacao'] = Variable<String>(localOperacao);
    }
    if (!nullToAbsent || quantidadeVolume != null) {
      map['quantidade_volume'] = Variable<int>(quantidadeVolume);
    }
    if (!nullToAbsent || pesoTotalVolume != null) {
      map['peso_total_volume'] = Variable<double>(pesoTotalVolume);
    }
    if (!nullToAbsent || quantidadePessoa != null) {
      map['quantidade_pessoa'] = Variable<int>(quantidadePessoa);
    }
    if (!nullToAbsent || quantidadeHora != null) {
      map['quantidade_hora'] = Variable<int>(quantidadeHora);
    }
    return map;
  }

  factory WmsAgendamento.fromJson(
    Map<String, dynamic> json, {
    ValueSerializer? serializer,
  }) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return WmsAgendamento(
      id: serializer.fromJson<int?>(json['id']),
      dataOperacao: serializer.fromJson<DateTime?>(json['dataOperacao']),
      horaOperacao: serializer.fromJson<String?>(json['horaOperacao']),
      localOperacao: serializer.fromJson<String?>(json['localOperacao']),
      quantidadeVolume: serializer.fromJson<int?>(json['quantidadeVolume']),
      pesoTotalVolume: serializer.fromJson<double?>(json['pesoTotalVolume']),
      quantidadePessoa: serializer.fromJson<int?>(json['quantidadePessoa']),
      quantidadeHora: serializer.fromJson<int?>(json['quantidadeHora']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'dataOperacao': serializer.toJson<DateTime?>(dataOperacao),
      'horaOperacao': serializer.toJson<String?>(horaOperacao),
      'localOperacao': serializer.toJson<String?>(localOperacao),
      'quantidadeVolume': serializer.toJson<int?>(quantidadeVolume),
      'pesoTotalVolume': serializer.toJson<double?>(pesoTotalVolume),
      'quantidadePessoa': serializer.toJson<int?>(quantidadePessoa),
      'quantidadeHora': serializer.toJson<int?>(quantidadeHora),
    };
  }

  WmsAgendamento copyWith({
    Value<int?> id = const Value.absent(),
    Value<DateTime?> dataOperacao = const Value.absent(),
    Value<String?> horaOperacao = const Value.absent(),
    Value<String?> localOperacao = const Value.absent(),
    Value<int?> quantidadeVolume = const Value.absent(),
    Value<double?> pesoTotalVolume = const Value.absent(),
    Value<int?> quantidadePessoa = const Value.absent(),
    Value<int?> quantidadeHora = const Value.absent(),
  }) => WmsAgendamento(
    id: id.present ? id.value : this.id,
    dataOperacao: dataOperacao.present ? dataOperacao.value : this.dataOperacao,
    horaOperacao: horaOperacao.present ? horaOperacao.value : this.horaOperacao,
    localOperacao:
        localOperacao.present ? localOperacao.value : this.localOperacao,
    quantidadeVolume:
        quantidadeVolume.present
            ? quantidadeVolume.value
            : this.quantidadeVolume,
    pesoTotalVolume:
        pesoTotalVolume.present ? pesoTotalVolume.value : this.pesoTotalVolume,
    quantidadePessoa:
        quantidadePessoa.present
            ? quantidadePessoa.value
            : this.quantidadePessoa,
    quantidadeHora:
        quantidadeHora.present ? quantidadeHora.value : this.quantidadeHora,
  );
  WmsAgendamento copyWithCompanion(WmsAgendamentosCompanion data) {
    return WmsAgendamento(
      id: data.id.present ? data.id.value : this.id,
      dataOperacao:
          data.dataOperacao.present
              ? data.dataOperacao.value
              : this.dataOperacao,
      horaOperacao:
          data.horaOperacao.present
              ? data.horaOperacao.value
              : this.horaOperacao,
      localOperacao:
          data.localOperacao.present
              ? data.localOperacao.value
              : this.localOperacao,
      quantidadeVolume:
          data.quantidadeVolume.present
              ? data.quantidadeVolume.value
              : this.quantidadeVolume,
      pesoTotalVolume:
          data.pesoTotalVolume.present
              ? data.pesoTotalVolume.value
              : this.pesoTotalVolume,
      quantidadePessoa:
          data.quantidadePessoa.present
              ? data.quantidadePessoa.value
              : this.quantidadePessoa,
      quantidadeHora:
          data.quantidadeHora.present
              ? data.quantidadeHora.value
              : this.quantidadeHora,
    );
  }

  @override
  String toString() {
    return (StringBuffer('WmsAgendamento(')
          ..write('id: $id, ')
          ..write('dataOperacao: $dataOperacao, ')
          ..write('horaOperacao: $horaOperacao, ')
          ..write('localOperacao: $localOperacao, ')
          ..write('quantidadeVolume: $quantidadeVolume, ')
          ..write('pesoTotalVolume: $pesoTotalVolume, ')
          ..write('quantidadePessoa: $quantidadePessoa, ')
          ..write('quantidadeHora: $quantidadeHora')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(
    id,
    dataOperacao,
    horaOperacao,
    localOperacao,
    quantidadeVolume,
    pesoTotalVolume,
    quantidadePessoa,
    quantidadeHora,
  );
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is WmsAgendamento &&
          other.id == this.id &&
          other.dataOperacao == this.dataOperacao &&
          other.horaOperacao == this.horaOperacao &&
          other.localOperacao == this.localOperacao &&
          other.quantidadeVolume == this.quantidadeVolume &&
          other.pesoTotalVolume == this.pesoTotalVolume &&
          other.quantidadePessoa == this.quantidadePessoa &&
          other.quantidadeHora == this.quantidadeHora);
}

class WmsAgendamentosCompanion extends UpdateCompanion<WmsAgendamento> {
  final Value<int?> id;
  final Value<DateTime?> dataOperacao;
  final Value<String?> horaOperacao;
  final Value<String?> localOperacao;
  final Value<int?> quantidadeVolume;
  final Value<double?> pesoTotalVolume;
  final Value<int?> quantidadePessoa;
  final Value<int?> quantidadeHora;
  const WmsAgendamentosCompanion({
    this.id = const Value.absent(),
    this.dataOperacao = const Value.absent(),
    this.horaOperacao = const Value.absent(),
    this.localOperacao = const Value.absent(),
    this.quantidadeVolume = const Value.absent(),
    this.pesoTotalVolume = const Value.absent(),
    this.quantidadePessoa = const Value.absent(),
    this.quantidadeHora = const Value.absent(),
  });
  WmsAgendamentosCompanion.insert({
    this.id = const Value.absent(),
    this.dataOperacao = const Value.absent(),
    this.horaOperacao = const Value.absent(),
    this.localOperacao = const Value.absent(),
    this.quantidadeVolume = const Value.absent(),
    this.pesoTotalVolume = const Value.absent(),
    this.quantidadePessoa = const Value.absent(),
    this.quantidadeHora = const Value.absent(),
  });
  static Insertable<WmsAgendamento> custom({
    Expression<int>? id,
    Expression<DateTime>? dataOperacao,
    Expression<String>? horaOperacao,
    Expression<String>? localOperacao,
    Expression<int>? quantidadeVolume,
    Expression<double>? pesoTotalVolume,
    Expression<int>? quantidadePessoa,
    Expression<int>? quantidadeHora,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (dataOperacao != null) 'data_operacao': dataOperacao,
      if (horaOperacao != null) 'hora_operacao': horaOperacao,
      if (localOperacao != null) 'local_operacao': localOperacao,
      if (quantidadeVolume != null) 'quantidade_volume': quantidadeVolume,
      if (pesoTotalVolume != null) 'peso_total_volume': pesoTotalVolume,
      if (quantidadePessoa != null) 'quantidade_pessoa': quantidadePessoa,
      if (quantidadeHora != null) 'quantidade_hora': quantidadeHora,
    });
  }

  WmsAgendamentosCompanion copyWith({
    Value<int?>? id,
    Value<DateTime?>? dataOperacao,
    Value<String?>? horaOperacao,
    Value<String?>? localOperacao,
    Value<int?>? quantidadeVolume,
    Value<double?>? pesoTotalVolume,
    Value<int?>? quantidadePessoa,
    Value<int?>? quantidadeHora,
  }) {
    return WmsAgendamentosCompanion(
      id: id ?? this.id,
      dataOperacao: dataOperacao ?? this.dataOperacao,
      horaOperacao: horaOperacao ?? this.horaOperacao,
      localOperacao: localOperacao ?? this.localOperacao,
      quantidadeVolume: quantidadeVolume ?? this.quantidadeVolume,
      pesoTotalVolume: pesoTotalVolume ?? this.pesoTotalVolume,
      quantidadePessoa: quantidadePessoa ?? this.quantidadePessoa,
      quantidadeHora: quantidadeHora ?? this.quantidadeHora,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (dataOperacao.present) {
      map['data_operacao'] = Variable<DateTime>(dataOperacao.value);
    }
    if (horaOperacao.present) {
      map['hora_operacao'] = Variable<String>(horaOperacao.value);
    }
    if (localOperacao.present) {
      map['local_operacao'] = Variable<String>(localOperacao.value);
    }
    if (quantidadeVolume.present) {
      map['quantidade_volume'] = Variable<int>(quantidadeVolume.value);
    }
    if (pesoTotalVolume.present) {
      map['peso_total_volume'] = Variable<double>(pesoTotalVolume.value);
    }
    if (quantidadePessoa.present) {
      map['quantidade_pessoa'] = Variable<int>(quantidadePessoa.value);
    }
    if (quantidadeHora.present) {
      map['quantidade_hora'] = Variable<int>(quantidadeHora.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('WmsAgendamentosCompanion(')
          ..write('id: $id, ')
          ..write('dataOperacao: $dataOperacao, ')
          ..write('horaOperacao: $horaOperacao, ')
          ..write('localOperacao: $localOperacao, ')
          ..write('quantidadeVolume: $quantidadeVolume, ')
          ..write('pesoTotalVolume: $pesoTotalVolume, ')
          ..write('quantidadePessoa: $quantidadePessoa, ')
          ..write('quantidadeHora: $quantidadeHora')
          ..write(')'))
        .toString();
  }
}

class $WmsParametrosTable extends WmsParametros
    with TableInfo<$WmsParametrosTable, WmsParametro> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $WmsParametrosTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
    'id',
    aliasedName,
    true,
    type: DriftSqlType.int,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _horaPorVolumeMeta = const VerificationMeta(
    'horaPorVolume',
  );
  @override
  late final GeneratedColumn<int> horaPorVolume = GeneratedColumn<int>(
    'hora_por_volume',
    aliasedName,
    true,
    type: DriftSqlType.int,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _pessoaPorVolumeMeta = const VerificationMeta(
    'pessoaPorVolume',
  );
  @override
  late final GeneratedColumn<int> pessoaPorVolume = GeneratedColumn<int>(
    'pessoa_por_volume',
    aliasedName,
    true,
    type: DriftSqlType.int,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _horaPorPesoMeta = const VerificationMeta(
    'horaPorPeso',
  );
  @override
  late final GeneratedColumn<int> horaPorPeso = GeneratedColumn<int>(
    'hora_por_peso',
    aliasedName,
    true,
    type: DriftSqlType.int,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _pessoaPorPesoMeta = const VerificationMeta(
    'pessoaPorPeso',
  );
  @override
  late final GeneratedColumn<int> pessoaPorPeso = GeneratedColumn<int>(
    'pessoa_por_peso',
    aliasedName,
    true,
    type: DriftSqlType.int,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _itemDiferenteCaixaMeta =
      const VerificationMeta('itemDiferenteCaixa');
  @override
  late final GeneratedColumn<String> itemDiferenteCaixa =
      GeneratedColumn<String>(
        'item_diferente_caixa',
        aliasedName,
        true,
        additionalChecks: GeneratedColumn.checkTextLength(
          minTextLength: 0,
          maxTextLength: 1,
        ),
        type: DriftSqlType.string,
        requiredDuringInsert: false,
      );
  @override
  List<GeneratedColumn> get $columns => [
    id,
    horaPorVolume,
    pessoaPorVolume,
    horaPorPeso,
    pessoaPorPeso,
    itemDiferenteCaixa,
  ];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'wms_parametro';
  @override
  VerificationContext validateIntegrity(
    Insertable<WmsParametro> instance, {
    bool isInserting = false,
  }) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('hora_por_volume')) {
      context.handle(
        _horaPorVolumeMeta,
        horaPorVolume.isAcceptableOrUnknown(
          data['hora_por_volume']!,
          _horaPorVolumeMeta,
        ),
      );
    }
    if (data.containsKey('pessoa_por_volume')) {
      context.handle(
        _pessoaPorVolumeMeta,
        pessoaPorVolume.isAcceptableOrUnknown(
          data['pessoa_por_volume']!,
          _pessoaPorVolumeMeta,
        ),
      );
    }
    if (data.containsKey('hora_por_peso')) {
      context.handle(
        _horaPorPesoMeta,
        horaPorPeso.isAcceptableOrUnknown(
          data['hora_por_peso']!,
          _horaPorPesoMeta,
        ),
      );
    }
    if (data.containsKey('pessoa_por_peso')) {
      context.handle(
        _pessoaPorPesoMeta,
        pessoaPorPeso.isAcceptableOrUnknown(
          data['pessoa_por_peso']!,
          _pessoaPorPesoMeta,
        ),
      );
    }
    if (data.containsKey('item_diferente_caixa')) {
      context.handle(
        _itemDiferenteCaixaMeta,
        itemDiferenteCaixa.isAcceptableOrUnknown(
          data['item_diferente_caixa']!,
          _itemDiferenteCaixaMeta,
        ),
      );
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  WmsParametro map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return WmsParametro(
      id: attachedDatabase.typeMapping.read(
        DriftSqlType.int,
        data['${effectivePrefix}id'],
      ),
      horaPorVolume: attachedDatabase.typeMapping.read(
        DriftSqlType.int,
        data['${effectivePrefix}hora_por_volume'],
      ),
      pessoaPorVolume: attachedDatabase.typeMapping.read(
        DriftSqlType.int,
        data['${effectivePrefix}pessoa_por_volume'],
      ),
      horaPorPeso: attachedDatabase.typeMapping.read(
        DriftSqlType.int,
        data['${effectivePrefix}hora_por_peso'],
      ),
      pessoaPorPeso: attachedDatabase.typeMapping.read(
        DriftSqlType.int,
        data['${effectivePrefix}pessoa_por_peso'],
      ),
      itemDiferenteCaixa: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}item_diferente_caixa'],
      ),
    );
  }

  @override
  $WmsParametrosTable createAlias(String alias) {
    return $WmsParametrosTable(attachedDatabase, alias);
  }
}

class WmsParametro extends DataClass implements Insertable<WmsParametro> {
  final int? id;
  final int? horaPorVolume;
  final int? pessoaPorVolume;
  final int? horaPorPeso;
  final int? pessoaPorPeso;
  final String? itemDiferenteCaixa;
  const WmsParametro({
    this.id,
    this.horaPorVolume,
    this.pessoaPorVolume,
    this.horaPorPeso,
    this.pessoaPorPeso,
    this.itemDiferenteCaixa,
  });
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || horaPorVolume != null) {
      map['hora_por_volume'] = Variable<int>(horaPorVolume);
    }
    if (!nullToAbsent || pessoaPorVolume != null) {
      map['pessoa_por_volume'] = Variable<int>(pessoaPorVolume);
    }
    if (!nullToAbsent || horaPorPeso != null) {
      map['hora_por_peso'] = Variable<int>(horaPorPeso);
    }
    if (!nullToAbsent || pessoaPorPeso != null) {
      map['pessoa_por_peso'] = Variable<int>(pessoaPorPeso);
    }
    if (!nullToAbsent || itemDiferenteCaixa != null) {
      map['item_diferente_caixa'] = Variable<String>(itemDiferenteCaixa);
    }
    return map;
  }

  factory WmsParametro.fromJson(
    Map<String, dynamic> json, {
    ValueSerializer? serializer,
  }) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return WmsParametro(
      id: serializer.fromJson<int?>(json['id']),
      horaPorVolume: serializer.fromJson<int?>(json['horaPorVolume']),
      pessoaPorVolume: serializer.fromJson<int?>(json['pessoaPorVolume']),
      horaPorPeso: serializer.fromJson<int?>(json['horaPorPeso']),
      pessoaPorPeso: serializer.fromJson<int?>(json['pessoaPorPeso']),
      itemDiferenteCaixa: serializer.fromJson<String?>(
        json['itemDiferenteCaixa'],
      ),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'horaPorVolume': serializer.toJson<int?>(horaPorVolume),
      'pessoaPorVolume': serializer.toJson<int?>(pessoaPorVolume),
      'horaPorPeso': serializer.toJson<int?>(horaPorPeso),
      'pessoaPorPeso': serializer.toJson<int?>(pessoaPorPeso),
      'itemDiferenteCaixa': serializer.toJson<String?>(itemDiferenteCaixa),
    };
  }

  WmsParametro copyWith({
    Value<int?> id = const Value.absent(),
    Value<int?> horaPorVolume = const Value.absent(),
    Value<int?> pessoaPorVolume = const Value.absent(),
    Value<int?> horaPorPeso = const Value.absent(),
    Value<int?> pessoaPorPeso = const Value.absent(),
    Value<String?> itemDiferenteCaixa = const Value.absent(),
  }) => WmsParametro(
    id: id.present ? id.value : this.id,
    horaPorVolume:
        horaPorVolume.present ? horaPorVolume.value : this.horaPorVolume,
    pessoaPorVolume:
        pessoaPorVolume.present ? pessoaPorVolume.value : this.pessoaPorVolume,
    horaPorPeso: horaPorPeso.present ? horaPorPeso.value : this.horaPorPeso,
    pessoaPorPeso:
        pessoaPorPeso.present ? pessoaPorPeso.value : this.pessoaPorPeso,
    itemDiferenteCaixa:
        itemDiferenteCaixa.present
            ? itemDiferenteCaixa.value
            : this.itemDiferenteCaixa,
  );
  WmsParametro copyWithCompanion(WmsParametrosCompanion data) {
    return WmsParametro(
      id: data.id.present ? data.id.value : this.id,
      horaPorVolume:
          data.horaPorVolume.present
              ? data.horaPorVolume.value
              : this.horaPorVolume,
      pessoaPorVolume:
          data.pessoaPorVolume.present
              ? data.pessoaPorVolume.value
              : this.pessoaPorVolume,
      horaPorPeso:
          data.horaPorPeso.present ? data.horaPorPeso.value : this.horaPorPeso,
      pessoaPorPeso:
          data.pessoaPorPeso.present
              ? data.pessoaPorPeso.value
              : this.pessoaPorPeso,
      itemDiferenteCaixa:
          data.itemDiferenteCaixa.present
              ? data.itemDiferenteCaixa.value
              : this.itemDiferenteCaixa,
    );
  }

  @override
  String toString() {
    return (StringBuffer('WmsParametro(')
          ..write('id: $id, ')
          ..write('horaPorVolume: $horaPorVolume, ')
          ..write('pessoaPorVolume: $pessoaPorVolume, ')
          ..write('horaPorPeso: $horaPorPeso, ')
          ..write('pessoaPorPeso: $pessoaPorPeso, ')
          ..write('itemDiferenteCaixa: $itemDiferenteCaixa')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(
    id,
    horaPorVolume,
    pessoaPorVolume,
    horaPorPeso,
    pessoaPorPeso,
    itemDiferenteCaixa,
  );
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is WmsParametro &&
          other.id == this.id &&
          other.horaPorVolume == this.horaPorVolume &&
          other.pessoaPorVolume == this.pessoaPorVolume &&
          other.horaPorPeso == this.horaPorPeso &&
          other.pessoaPorPeso == this.pessoaPorPeso &&
          other.itemDiferenteCaixa == this.itemDiferenteCaixa);
}

class WmsParametrosCompanion extends UpdateCompanion<WmsParametro> {
  final Value<int?> id;
  final Value<int?> horaPorVolume;
  final Value<int?> pessoaPorVolume;
  final Value<int?> horaPorPeso;
  final Value<int?> pessoaPorPeso;
  final Value<String?> itemDiferenteCaixa;
  const WmsParametrosCompanion({
    this.id = const Value.absent(),
    this.horaPorVolume = const Value.absent(),
    this.pessoaPorVolume = const Value.absent(),
    this.horaPorPeso = const Value.absent(),
    this.pessoaPorPeso = const Value.absent(),
    this.itemDiferenteCaixa = const Value.absent(),
  });
  WmsParametrosCompanion.insert({
    this.id = const Value.absent(),
    this.horaPorVolume = const Value.absent(),
    this.pessoaPorVolume = const Value.absent(),
    this.horaPorPeso = const Value.absent(),
    this.pessoaPorPeso = const Value.absent(),
    this.itemDiferenteCaixa = const Value.absent(),
  });
  static Insertable<WmsParametro> custom({
    Expression<int>? id,
    Expression<int>? horaPorVolume,
    Expression<int>? pessoaPorVolume,
    Expression<int>? horaPorPeso,
    Expression<int>? pessoaPorPeso,
    Expression<String>? itemDiferenteCaixa,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (horaPorVolume != null) 'hora_por_volume': horaPorVolume,
      if (pessoaPorVolume != null) 'pessoa_por_volume': pessoaPorVolume,
      if (horaPorPeso != null) 'hora_por_peso': horaPorPeso,
      if (pessoaPorPeso != null) 'pessoa_por_peso': pessoaPorPeso,
      if (itemDiferenteCaixa != null)
        'item_diferente_caixa': itemDiferenteCaixa,
    });
  }

  WmsParametrosCompanion copyWith({
    Value<int?>? id,
    Value<int?>? horaPorVolume,
    Value<int?>? pessoaPorVolume,
    Value<int?>? horaPorPeso,
    Value<int?>? pessoaPorPeso,
    Value<String?>? itemDiferenteCaixa,
  }) {
    return WmsParametrosCompanion(
      id: id ?? this.id,
      horaPorVolume: horaPorVolume ?? this.horaPorVolume,
      pessoaPorVolume: pessoaPorVolume ?? this.pessoaPorVolume,
      horaPorPeso: horaPorPeso ?? this.horaPorPeso,
      pessoaPorPeso: pessoaPorPeso ?? this.pessoaPorPeso,
      itemDiferenteCaixa: itemDiferenteCaixa ?? this.itemDiferenteCaixa,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (horaPorVolume.present) {
      map['hora_por_volume'] = Variable<int>(horaPorVolume.value);
    }
    if (pessoaPorVolume.present) {
      map['pessoa_por_volume'] = Variable<int>(pessoaPorVolume.value);
    }
    if (horaPorPeso.present) {
      map['hora_por_peso'] = Variable<int>(horaPorPeso.value);
    }
    if (pessoaPorPeso.present) {
      map['pessoa_por_peso'] = Variable<int>(pessoaPorPeso.value);
    }
    if (itemDiferenteCaixa.present) {
      map['item_diferente_caixa'] = Variable<String>(itemDiferenteCaixa.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('WmsParametrosCompanion(')
          ..write('id: $id, ')
          ..write('horaPorVolume: $horaPorVolume, ')
          ..write('pessoaPorVolume: $pessoaPorVolume, ')
          ..write('horaPorPeso: $horaPorPeso, ')
          ..write('pessoaPorPeso: $pessoaPorPeso, ')
          ..write('itemDiferenteCaixa: $itemDiferenteCaixa')
          ..write(')'))
        .toString();
  }
}

class $WmsRuasTable extends WmsRuas with TableInfo<$WmsRuasTable, WmsRua> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $WmsRuasTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
    'id',
    aliasedName,
    true,
    type: DriftSqlType.int,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _codigoMeta = const VerificationMeta('codigo');
  @override
  late final GeneratedColumn<String> codigo = GeneratedColumn<String>(
    'codigo',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 10,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _quantidadeEstanteMeta = const VerificationMeta(
    'quantidadeEstante',
  );
  @override
  late final GeneratedColumn<int> quantidadeEstante = GeneratedColumn<int>(
    'quantidade_estante',
    aliasedName,
    true,
    type: DriftSqlType.int,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _nomeMeta = const VerificationMeta('nome');
  @override
  late final GeneratedColumn<String> nome = GeneratedColumn<String>(
    'nome',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 100,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  @override
  List<GeneratedColumn> get $columns => [id, codigo, quantidadeEstante, nome];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'wms_rua';
  @override
  VerificationContext validateIntegrity(
    Insertable<WmsRua> instance, {
    bool isInserting = false,
  }) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('codigo')) {
      context.handle(
        _codigoMeta,
        codigo.isAcceptableOrUnknown(data['codigo']!, _codigoMeta),
      );
    }
    if (data.containsKey('quantidade_estante')) {
      context.handle(
        _quantidadeEstanteMeta,
        quantidadeEstante.isAcceptableOrUnknown(
          data['quantidade_estante']!,
          _quantidadeEstanteMeta,
        ),
      );
    }
    if (data.containsKey('nome')) {
      context.handle(
        _nomeMeta,
        nome.isAcceptableOrUnknown(data['nome']!, _nomeMeta),
      );
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  WmsRua map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return WmsRua(
      id: attachedDatabase.typeMapping.read(
        DriftSqlType.int,
        data['${effectivePrefix}id'],
      ),
      codigo: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}codigo'],
      ),
      quantidadeEstante: attachedDatabase.typeMapping.read(
        DriftSqlType.int,
        data['${effectivePrefix}quantidade_estante'],
      ),
      nome: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}nome'],
      ),
    );
  }

  @override
  $WmsRuasTable createAlias(String alias) {
    return $WmsRuasTable(attachedDatabase, alias);
  }
}

class WmsRua extends DataClass implements Insertable<WmsRua> {
  final int? id;
  final String? codigo;
  final int? quantidadeEstante;
  final String? nome;
  const WmsRua({this.id, this.codigo, this.quantidadeEstante, this.nome});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || codigo != null) {
      map['codigo'] = Variable<String>(codigo);
    }
    if (!nullToAbsent || quantidadeEstante != null) {
      map['quantidade_estante'] = Variable<int>(quantidadeEstante);
    }
    if (!nullToAbsent || nome != null) {
      map['nome'] = Variable<String>(nome);
    }
    return map;
  }

  factory WmsRua.fromJson(
    Map<String, dynamic> json, {
    ValueSerializer? serializer,
  }) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return WmsRua(
      id: serializer.fromJson<int?>(json['id']),
      codigo: serializer.fromJson<String?>(json['codigo']),
      quantidadeEstante: serializer.fromJson<int?>(json['quantidadeEstante']),
      nome: serializer.fromJson<String?>(json['nome']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'codigo': serializer.toJson<String?>(codigo),
      'quantidadeEstante': serializer.toJson<int?>(quantidadeEstante),
      'nome': serializer.toJson<String?>(nome),
    };
  }

  WmsRua copyWith({
    Value<int?> id = const Value.absent(),
    Value<String?> codigo = const Value.absent(),
    Value<int?> quantidadeEstante = const Value.absent(),
    Value<String?> nome = const Value.absent(),
  }) => WmsRua(
    id: id.present ? id.value : this.id,
    codigo: codigo.present ? codigo.value : this.codigo,
    quantidadeEstante:
        quantidadeEstante.present
            ? quantidadeEstante.value
            : this.quantidadeEstante,
    nome: nome.present ? nome.value : this.nome,
  );
  WmsRua copyWithCompanion(WmsRuasCompanion data) {
    return WmsRua(
      id: data.id.present ? data.id.value : this.id,
      codigo: data.codigo.present ? data.codigo.value : this.codigo,
      quantidadeEstante:
          data.quantidadeEstante.present
              ? data.quantidadeEstante.value
              : this.quantidadeEstante,
      nome: data.nome.present ? data.nome.value : this.nome,
    );
  }

  @override
  String toString() {
    return (StringBuffer('WmsRua(')
          ..write('id: $id, ')
          ..write('codigo: $codigo, ')
          ..write('quantidadeEstante: $quantidadeEstante, ')
          ..write('nome: $nome')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(id, codigo, quantidadeEstante, nome);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is WmsRua &&
          other.id == this.id &&
          other.codigo == this.codigo &&
          other.quantidadeEstante == this.quantidadeEstante &&
          other.nome == this.nome);
}

class WmsRuasCompanion extends UpdateCompanion<WmsRua> {
  final Value<int?> id;
  final Value<String?> codigo;
  final Value<int?> quantidadeEstante;
  final Value<String?> nome;
  const WmsRuasCompanion({
    this.id = const Value.absent(),
    this.codigo = const Value.absent(),
    this.quantidadeEstante = const Value.absent(),
    this.nome = const Value.absent(),
  });
  WmsRuasCompanion.insert({
    this.id = const Value.absent(),
    this.codigo = const Value.absent(),
    this.quantidadeEstante = const Value.absent(),
    this.nome = const Value.absent(),
  });
  static Insertable<WmsRua> custom({
    Expression<int>? id,
    Expression<String>? codigo,
    Expression<int>? quantidadeEstante,
    Expression<String>? nome,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (codigo != null) 'codigo': codigo,
      if (quantidadeEstante != null) 'quantidade_estante': quantidadeEstante,
      if (nome != null) 'nome': nome,
    });
  }

  WmsRuasCompanion copyWith({
    Value<int?>? id,
    Value<String?>? codigo,
    Value<int?>? quantidadeEstante,
    Value<String?>? nome,
  }) {
    return WmsRuasCompanion(
      id: id ?? this.id,
      codigo: codigo ?? this.codigo,
      quantidadeEstante: quantidadeEstante ?? this.quantidadeEstante,
      nome: nome ?? this.nome,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (codigo.present) {
      map['codigo'] = Variable<String>(codigo.value);
    }
    if (quantidadeEstante.present) {
      map['quantidade_estante'] = Variable<int>(quantidadeEstante.value);
    }
    if (nome.present) {
      map['nome'] = Variable<String>(nome.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('WmsRuasCompanion(')
          ..write('id: $id, ')
          ..write('codigo: $codigo, ')
          ..write('quantidadeEstante: $quantidadeEstante, ')
          ..write('nome: $nome')
          ..write(')'))
        .toString();
  }
}

class $WmsArmazenamentosTable extends WmsArmazenamentos
    with TableInfo<$WmsArmazenamentosTable, WmsArmazenamento> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $WmsArmazenamentosTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
    'id',
    aliasedName,
    true,
    type: DriftSqlType.int,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _idWmsRecebimentoCabecalhoMeta =
      const VerificationMeta('idWmsRecebimentoCabecalho');
  @override
  late final GeneratedColumn<int> idWmsRecebimentoCabecalho =
      GeneratedColumn<int>(
        'id_wms_recebimento_cabecalho',
        aliasedName,
        true,
        type: DriftSqlType.int,
        requiredDuringInsert: false,
      );
  static const VerificationMeta _idProdutoMeta = const VerificationMeta(
    'idProduto',
  );
  @override
  late final GeneratedColumn<int> idProduto = GeneratedColumn<int>(
    'id_produto',
    aliasedName,
    true,
    type: DriftSqlType.int,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _idWmsCaixaMeta = const VerificationMeta(
    'idWmsCaixa',
  );
  @override
  late final GeneratedColumn<int> idWmsCaixa = GeneratedColumn<int>(
    'id_wms_caixa',
    aliasedName,
    true,
    type: DriftSqlType.int,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _quantidadeMeta = const VerificationMeta(
    'quantidade',
  );
  @override
  late final GeneratedColumn<int> quantidade = GeneratedColumn<int>(
    'quantidade',
    aliasedName,
    true,
    type: DriftSqlType.int,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _dataArmazenagemMeta = const VerificationMeta(
    'dataArmazenagem',
  );
  @override
  late final GeneratedColumn<DateTime> dataArmazenagem =
      GeneratedColumn<DateTime>(
        'data_armazenagem',
        aliasedName,
        true,
        type: DriftSqlType.dateTime,
        requiredDuringInsert: false,
      );
  static const VerificationMeta _horaArmazenagemMeta = const VerificationMeta(
    'horaArmazenagem',
  );
  @override
  late final GeneratedColumn<String> horaArmazenagem = GeneratedColumn<String>(
    'hora_armazenagem',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 8,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  @override
  List<GeneratedColumn> get $columns => [
    id,
    idWmsRecebimentoCabecalho,
    idProduto,
    idWmsCaixa,
    quantidade,
    dataArmazenagem,
    horaArmazenagem,
  ];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'wms_armazenamento';
  @override
  VerificationContext validateIntegrity(
    Insertable<WmsArmazenamento> instance, {
    bool isInserting = false,
  }) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('id_wms_recebimento_cabecalho')) {
      context.handle(
        _idWmsRecebimentoCabecalhoMeta,
        idWmsRecebimentoCabecalho.isAcceptableOrUnknown(
          data['id_wms_recebimento_cabecalho']!,
          _idWmsRecebimentoCabecalhoMeta,
        ),
      );
    }
    if (data.containsKey('id_produto')) {
      context.handle(
        _idProdutoMeta,
        idProduto.isAcceptableOrUnknown(data['id_produto']!, _idProdutoMeta),
      );
    }
    if (data.containsKey('id_wms_caixa')) {
      context.handle(
        _idWmsCaixaMeta,
        idWmsCaixa.isAcceptableOrUnknown(
          data['id_wms_caixa']!,
          _idWmsCaixaMeta,
        ),
      );
    }
    if (data.containsKey('quantidade')) {
      context.handle(
        _quantidadeMeta,
        quantidade.isAcceptableOrUnknown(data['quantidade']!, _quantidadeMeta),
      );
    }
    if (data.containsKey('data_armazenagem')) {
      context.handle(
        _dataArmazenagemMeta,
        dataArmazenagem.isAcceptableOrUnknown(
          data['data_armazenagem']!,
          _dataArmazenagemMeta,
        ),
      );
    }
    if (data.containsKey('hora_armazenagem')) {
      context.handle(
        _horaArmazenagemMeta,
        horaArmazenagem.isAcceptableOrUnknown(
          data['hora_armazenagem']!,
          _horaArmazenagemMeta,
        ),
      );
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  WmsArmazenamento map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return WmsArmazenamento(
      id: attachedDatabase.typeMapping.read(
        DriftSqlType.int,
        data['${effectivePrefix}id'],
      ),
      idWmsRecebimentoCabecalho: attachedDatabase.typeMapping.read(
        DriftSqlType.int,
        data['${effectivePrefix}id_wms_recebimento_cabecalho'],
      ),
      idProduto: attachedDatabase.typeMapping.read(
        DriftSqlType.int,
        data['${effectivePrefix}id_produto'],
      ),
      idWmsCaixa: attachedDatabase.typeMapping.read(
        DriftSqlType.int,
        data['${effectivePrefix}id_wms_caixa'],
      ),
      quantidade: attachedDatabase.typeMapping.read(
        DriftSqlType.int,
        data['${effectivePrefix}quantidade'],
      ),
      dataArmazenagem: attachedDatabase.typeMapping.read(
        DriftSqlType.dateTime,
        data['${effectivePrefix}data_armazenagem'],
      ),
      horaArmazenagem: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}hora_armazenagem'],
      ),
    );
  }

  @override
  $WmsArmazenamentosTable createAlias(String alias) {
    return $WmsArmazenamentosTable(attachedDatabase, alias);
  }
}

class WmsArmazenamento extends DataClass
    implements Insertable<WmsArmazenamento> {
  final int? id;
  final int? idWmsRecebimentoCabecalho;
  final int? idProduto;
  final int? idWmsCaixa;
  final int? quantidade;
  final DateTime? dataArmazenagem;
  final String? horaArmazenagem;
  const WmsArmazenamento({
    this.id,
    this.idWmsRecebimentoCabecalho,
    this.idProduto,
    this.idWmsCaixa,
    this.quantidade,
    this.dataArmazenagem,
    this.horaArmazenagem,
  });
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || idWmsRecebimentoCabecalho != null) {
      map['id_wms_recebimento_cabecalho'] = Variable<int>(
        idWmsRecebimentoCabecalho,
      );
    }
    if (!nullToAbsent || idProduto != null) {
      map['id_produto'] = Variable<int>(idProduto);
    }
    if (!nullToAbsent || idWmsCaixa != null) {
      map['id_wms_caixa'] = Variable<int>(idWmsCaixa);
    }
    if (!nullToAbsent || quantidade != null) {
      map['quantidade'] = Variable<int>(quantidade);
    }
    if (!nullToAbsent || dataArmazenagem != null) {
      map['data_armazenagem'] = Variable<DateTime>(dataArmazenagem);
    }
    if (!nullToAbsent || horaArmazenagem != null) {
      map['hora_armazenagem'] = Variable<String>(horaArmazenagem);
    }
    return map;
  }

  factory WmsArmazenamento.fromJson(
    Map<String, dynamic> json, {
    ValueSerializer? serializer,
  }) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return WmsArmazenamento(
      id: serializer.fromJson<int?>(json['id']),
      idWmsRecebimentoCabecalho: serializer.fromJson<int?>(
        json['idWmsRecebimentoCabecalho'],
      ),
      idProduto: serializer.fromJson<int?>(json['idProduto']),
      idWmsCaixa: serializer.fromJson<int?>(json['idWmsCaixa']),
      quantidade: serializer.fromJson<int?>(json['quantidade']),
      dataArmazenagem: serializer.fromJson<DateTime?>(json['dataArmazenagem']),
      horaArmazenagem: serializer.fromJson<String?>(json['horaArmazenagem']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'idWmsRecebimentoCabecalho': serializer.toJson<int?>(
        idWmsRecebimentoCabecalho,
      ),
      'idProduto': serializer.toJson<int?>(idProduto),
      'idWmsCaixa': serializer.toJson<int?>(idWmsCaixa),
      'quantidade': serializer.toJson<int?>(quantidade),
      'dataArmazenagem': serializer.toJson<DateTime?>(dataArmazenagem),
      'horaArmazenagem': serializer.toJson<String?>(horaArmazenagem),
    };
  }

  WmsArmazenamento copyWith({
    Value<int?> id = const Value.absent(),
    Value<int?> idWmsRecebimentoCabecalho = const Value.absent(),
    Value<int?> idProduto = const Value.absent(),
    Value<int?> idWmsCaixa = const Value.absent(),
    Value<int?> quantidade = const Value.absent(),
    Value<DateTime?> dataArmazenagem = const Value.absent(),
    Value<String?> horaArmazenagem = const Value.absent(),
  }) => WmsArmazenamento(
    id: id.present ? id.value : this.id,
    idWmsRecebimentoCabecalho:
        idWmsRecebimentoCabecalho.present
            ? idWmsRecebimentoCabecalho.value
            : this.idWmsRecebimentoCabecalho,
    idProduto: idProduto.present ? idProduto.value : this.idProduto,
    idWmsCaixa: idWmsCaixa.present ? idWmsCaixa.value : this.idWmsCaixa,
    quantidade: quantidade.present ? quantidade.value : this.quantidade,
    dataArmazenagem:
        dataArmazenagem.present ? dataArmazenagem.value : this.dataArmazenagem,
    horaArmazenagem:
        horaArmazenagem.present ? horaArmazenagem.value : this.horaArmazenagem,
  );
  WmsArmazenamento copyWithCompanion(WmsArmazenamentosCompanion data) {
    return WmsArmazenamento(
      id: data.id.present ? data.id.value : this.id,
      idWmsRecebimentoCabecalho:
          data.idWmsRecebimentoCabecalho.present
              ? data.idWmsRecebimentoCabecalho.value
              : this.idWmsRecebimentoCabecalho,
      idProduto: data.idProduto.present ? data.idProduto.value : this.idProduto,
      idWmsCaixa:
          data.idWmsCaixa.present ? data.idWmsCaixa.value : this.idWmsCaixa,
      quantidade:
          data.quantidade.present ? data.quantidade.value : this.quantidade,
      dataArmazenagem:
          data.dataArmazenagem.present
              ? data.dataArmazenagem.value
              : this.dataArmazenagem,
      horaArmazenagem:
          data.horaArmazenagem.present
              ? data.horaArmazenagem.value
              : this.horaArmazenagem,
    );
  }

  @override
  String toString() {
    return (StringBuffer('WmsArmazenamento(')
          ..write('id: $id, ')
          ..write('idWmsRecebimentoCabecalho: $idWmsRecebimentoCabecalho, ')
          ..write('idProduto: $idProduto, ')
          ..write('idWmsCaixa: $idWmsCaixa, ')
          ..write('quantidade: $quantidade, ')
          ..write('dataArmazenagem: $dataArmazenagem, ')
          ..write('horaArmazenagem: $horaArmazenagem')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(
    id,
    idWmsRecebimentoCabecalho,
    idProduto,
    idWmsCaixa,
    quantidade,
    dataArmazenagem,
    horaArmazenagem,
  );
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is WmsArmazenamento &&
          other.id == this.id &&
          other.idWmsRecebimentoCabecalho == this.idWmsRecebimentoCabecalho &&
          other.idProduto == this.idProduto &&
          other.idWmsCaixa == this.idWmsCaixa &&
          other.quantidade == this.quantidade &&
          other.dataArmazenagem == this.dataArmazenagem &&
          other.horaArmazenagem == this.horaArmazenagem);
}

class WmsArmazenamentosCompanion extends UpdateCompanion<WmsArmazenamento> {
  final Value<int?> id;
  final Value<int?> idWmsRecebimentoCabecalho;
  final Value<int?> idProduto;
  final Value<int?> idWmsCaixa;
  final Value<int?> quantidade;
  final Value<DateTime?> dataArmazenagem;
  final Value<String?> horaArmazenagem;
  const WmsArmazenamentosCompanion({
    this.id = const Value.absent(),
    this.idWmsRecebimentoCabecalho = const Value.absent(),
    this.idProduto = const Value.absent(),
    this.idWmsCaixa = const Value.absent(),
    this.quantidade = const Value.absent(),
    this.dataArmazenagem = const Value.absent(),
    this.horaArmazenagem = const Value.absent(),
  });
  WmsArmazenamentosCompanion.insert({
    this.id = const Value.absent(),
    this.idWmsRecebimentoCabecalho = const Value.absent(),
    this.idProduto = const Value.absent(),
    this.idWmsCaixa = const Value.absent(),
    this.quantidade = const Value.absent(),
    this.dataArmazenagem = const Value.absent(),
    this.horaArmazenagem = const Value.absent(),
  });
  static Insertable<WmsArmazenamento> custom({
    Expression<int>? id,
    Expression<int>? idWmsRecebimentoCabecalho,
    Expression<int>? idProduto,
    Expression<int>? idWmsCaixa,
    Expression<int>? quantidade,
    Expression<DateTime>? dataArmazenagem,
    Expression<String>? horaArmazenagem,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (idWmsRecebimentoCabecalho != null)
        'id_wms_recebimento_cabecalho': idWmsRecebimentoCabecalho,
      if (idProduto != null) 'id_produto': idProduto,
      if (idWmsCaixa != null) 'id_wms_caixa': idWmsCaixa,
      if (quantidade != null) 'quantidade': quantidade,
      if (dataArmazenagem != null) 'data_armazenagem': dataArmazenagem,
      if (horaArmazenagem != null) 'hora_armazenagem': horaArmazenagem,
    });
  }

  WmsArmazenamentosCompanion copyWith({
    Value<int?>? id,
    Value<int?>? idWmsRecebimentoCabecalho,
    Value<int?>? idProduto,
    Value<int?>? idWmsCaixa,
    Value<int?>? quantidade,
    Value<DateTime?>? dataArmazenagem,
    Value<String?>? horaArmazenagem,
  }) {
    return WmsArmazenamentosCompanion(
      id: id ?? this.id,
      idWmsRecebimentoCabecalho:
          idWmsRecebimentoCabecalho ?? this.idWmsRecebimentoCabecalho,
      idProduto: idProduto ?? this.idProduto,
      idWmsCaixa: idWmsCaixa ?? this.idWmsCaixa,
      quantidade: quantidade ?? this.quantidade,
      dataArmazenagem: dataArmazenagem ?? this.dataArmazenagem,
      horaArmazenagem: horaArmazenagem ?? this.horaArmazenagem,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (idWmsRecebimentoCabecalho.present) {
      map['id_wms_recebimento_cabecalho'] = Variable<int>(
        idWmsRecebimentoCabecalho.value,
      );
    }
    if (idProduto.present) {
      map['id_produto'] = Variable<int>(idProduto.value);
    }
    if (idWmsCaixa.present) {
      map['id_wms_caixa'] = Variable<int>(idWmsCaixa.value);
    }
    if (quantidade.present) {
      map['quantidade'] = Variable<int>(quantidade.value);
    }
    if (dataArmazenagem.present) {
      map['data_armazenagem'] = Variable<DateTime>(dataArmazenagem.value);
    }
    if (horaArmazenagem.present) {
      map['hora_armazenagem'] = Variable<String>(horaArmazenagem.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('WmsArmazenamentosCompanion(')
          ..write('id: $id, ')
          ..write('idWmsRecebimentoCabecalho: $idWmsRecebimentoCabecalho, ')
          ..write('idProduto: $idProduto, ')
          ..write('idWmsCaixa: $idWmsCaixa, ')
          ..write('quantidade: $quantidade, ')
          ..write('dataArmazenagem: $dataArmazenagem, ')
          ..write('horaArmazenagem: $horaArmazenagem')
          ..write(')'))
        .toString();
  }
}

class $WmsExpedicaosTable extends WmsExpedicaos
    with TableInfo<$WmsExpedicaosTable, WmsExpedicao> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $WmsExpedicaosTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
    'id',
    aliasedName,
    true,
    type: DriftSqlType.int,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _idProdutoMeta = const VerificationMeta(
    'idProduto',
  );
  @override
  late final GeneratedColumn<int> idProduto = GeneratedColumn<int>(
    'id_produto',
    aliasedName,
    true,
    type: DriftSqlType.int,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _quantidadeMeta = const VerificationMeta(
    'quantidade',
  );
  @override
  late final GeneratedColumn<int> quantidade = GeneratedColumn<int>(
    'quantidade',
    aliasedName,
    true,
    type: DriftSqlType.int,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _dataSaidaMeta = const VerificationMeta(
    'dataSaida',
  );
  @override
  late final GeneratedColumn<DateTime> dataSaida = GeneratedColumn<DateTime>(
    'data_saida',
    aliasedName,
    true,
    type: DriftSqlType.dateTime,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _horaSaidaMeta = const VerificationMeta(
    'horaSaida',
  );
  @override
  late final GeneratedColumn<String> horaSaida = GeneratedColumn<String>(
    'hora_saida',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 8,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _veioDeOndeMeta = const VerificationMeta(
    'veioDeOnde',
  );
  @override
  late final GeneratedColumn<String> veioDeOnde = GeneratedColumn<String>(
    'veio_de_onde',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 1,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _codigoSeparacaoRecebimentoMeta =
      const VerificationMeta('codigoSeparacaoRecebimento');
  @override
  late final GeneratedColumn<String> codigoSeparacaoRecebimento =
      GeneratedColumn<String>(
        'codigo_separacao_recebimento',
        aliasedName,
        true,
        additionalChecks: GeneratedColumn.checkTextLength(
          minTextLength: 0,
          maxTextLength: 32,
        ),
        type: DriftSqlType.string,
        requiredDuringInsert: false,
      );
  @override
  List<GeneratedColumn> get $columns => [
    id,
    idProduto,
    quantidade,
    dataSaida,
    horaSaida,
    veioDeOnde,
    codigoSeparacaoRecebimento,
  ];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'wms_expedicao';
  @override
  VerificationContext validateIntegrity(
    Insertable<WmsExpedicao> instance, {
    bool isInserting = false,
  }) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('id_produto')) {
      context.handle(
        _idProdutoMeta,
        idProduto.isAcceptableOrUnknown(data['id_produto']!, _idProdutoMeta),
      );
    }
    if (data.containsKey('quantidade')) {
      context.handle(
        _quantidadeMeta,
        quantidade.isAcceptableOrUnknown(data['quantidade']!, _quantidadeMeta),
      );
    }
    if (data.containsKey('data_saida')) {
      context.handle(
        _dataSaidaMeta,
        dataSaida.isAcceptableOrUnknown(data['data_saida']!, _dataSaidaMeta),
      );
    }
    if (data.containsKey('hora_saida')) {
      context.handle(
        _horaSaidaMeta,
        horaSaida.isAcceptableOrUnknown(data['hora_saida']!, _horaSaidaMeta),
      );
    }
    if (data.containsKey('veio_de_onde')) {
      context.handle(
        _veioDeOndeMeta,
        veioDeOnde.isAcceptableOrUnknown(
          data['veio_de_onde']!,
          _veioDeOndeMeta,
        ),
      );
    }
    if (data.containsKey('codigo_separacao_recebimento')) {
      context.handle(
        _codigoSeparacaoRecebimentoMeta,
        codigoSeparacaoRecebimento.isAcceptableOrUnknown(
          data['codigo_separacao_recebimento']!,
          _codigoSeparacaoRecebimentoMeta,
        ),
      );
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  WmsExpedicao map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return WmsExpedicao(
      id: attachedDatabase.typeMapping.read(
        DriftSqlType.int,
        data['${effectivePrefix}id'],
      ),
      idProduto: attachedDatabase.typeMapping.read(
        DriftSqlType.int,
        data['${effectivePrefix}id_produto'],
      ),
      quantidade: attachedDatabase.typeMapping.read(
        DriftSqlType.int,
        data['${effectivePrefix}quantidade'],
      ),
      dataSaida: attachedDatabase.typeMapping.read(
        DriftSqlType.dateTime,
        data['${effectivePrefix}data_saida'],
      ),
      horaSaida: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}hora_saida'],
      ),
      veioDeOnde: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}veio_de_onde'],
      ),
      codigoSeparacaoRecebimento: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}codigo_separacao_recebimento'],
      ),
    );
  }

  @override
  $WmsExpedicaosTable createAlias(String alias) {
    return $WmsExpedicaosTable(attachedDatabase, alias);
  }
}

class WmsExpedicao extends DataClass implements Insertable<WmsExpedicao> {
  final int? id;
  final int? idProduto;
  final int? quantidade;
  final DateTime? dataSaida;
  final String? horaSaida;
  final String? veioDeOnde;
  final String? codigoSeparacaoRecebimento;
  const WmsExpedicao({
    this.id,
    this.idProduto,
    this.quantidade,
    this.dataSaida,
    this.horaSaida,
    this.veioDeOnde,
    this.codigoSeparacaoRecebimento,
  });
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || idProduto != null) {
      map['id_produto'] = Variable<int>(idProduto);
    }
    if (!nullToAbsent || quantidade != null) {
      map['quantidade'] = Variable<int>(quantidade);
    }
    if (!nullToAbsent || dataSaida != null) {
      map['data_saida'] = Variable<DateTime>(dataSaida);
    }
    if (!nullToAbsent || horaSaida != null) {
      map['hora_saida'] = Variable<String>(horaSaida);
    }
    if (!nullToAbsent || veioDeOnde != null) {
      map['veio_de_onde'] = Variable<String>(veioDeOnde);
    }
    if (!nullToAbsent || codigoSeparacaoRecebimento != null) {
      map['codigo_separacao_recebimento'] = Variable<String>(
        codigoSeparacaoRecebimento,
      );
    }
    return map;
  }

  factory WmsExpedicao.fromJson(
    Map<String, dynamic> json, {
    ValueSerializer? serializer,
  }) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return WmsExpedicao(
      id: serializer.fromJson<int?>(json['id']),
      idProduto: serializer.fromJson<int?>(json['idProduto']),
      quantidade: serializer.fromJson<int?>(json['quantidade']),
      dataSaida: serializer.fromJson<DateTime?>(json['dataSaida']),
      horaSaida: serializer.fromJson<String?>(json['horaSaida']),
      veioDeOnde: serializer.fromJson<String?>(json['veioDeOnde']),
      codigoSeparacaoRecebimento: serializer.fromJson<String?>(
        json['codigoSeparacaoRecebimento'],
      ),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'idProduto': serializer.toJson<int?>(idProduto),
      'quantidade': serializer.toJson<int?>(quantidade),
      'dataSaida': serializer.toJson<DateTime?>(dataSaida),
      'horaSaida': serializer.toJson<String?>(horaSaida),
      'veioDeOnde': serializer.toJson<String?>(veioDeOnde),
      'codigoSeparacaoRecebimento': serializer.toJson<String?>(
        codigoSeparacaoRecebimento,
      ),
    };
  }

  WmsExpedicao copyWith({
    Value<int?> id = const Value.absent(),
    Value<int?> idProduto = const Value.absent(),
    Value<int?> quantidade = const Value.absent(),
    Value<DateTime?> dataSaida = const Value.absent(),
    Value<String?> horaSaida = const Value.absent(),
    Value<String?> veioDeOnde = const Value.absent(),
    Value<String?> codigoSeparacaoRecebimento = const Value.absent(),
  }) => WmsExpedicao(
    id: id.present ? id.value : this.id,
    idProduto: idProduto.present ? idProduto.value : this.idProduto,
    quantidade: quantidade.present ? quantidade.value : this.quantidade,
    dataSaida: dataSaida.present ? dataSaida.value : this.dataSaida,
    horaSaida: horaSaida.present ? horaSaida.value : this.horaSaida,
    veioDeOnde: veioDeOnde.present ? veioDeOnde.value : this.veioDeOnde,
    codigoSeparacaoRecebimento:
        codigoSeparacaoRecebimento.present
            ? codigoSeparacaoRecebimento.value
            : this.codigoSeparacaoRecebimento,
  );
  WmsExpedicao copyWithCompanion(WmsExpedicaosCompanion data) {
    return WmsExpedicao(
      id: data.id.present ? data.id.value : this.id,
      idProduto: data.idProduto.present ? data.idProduto.value : this.idProduto,
      quantidade:
          data.quantidade.present ? data.quantidade.value : this.quantidade,
      dataSaida: data.dataSaida.present ? data.dataSaida.value : this.dataSaida,
      horaSaida: data.horaSaida.present ? data.horaSaida.value : this.horaSaida,
      veioDeOnde:
          data.veioDeOnde.present ? data.veioDeOnde.value : this.veioDeOnde,
      codigoSeparacaoRecebimento:
          data.codigoSeparacaoRecebimento.present
              ? data.codigoSeparacaoRecebimento.value
              : this.codigoSeparacaoRecebimento,
    );
  }

  @override
  String toString() {
    return (StringBuffer('WmsExpedicao(')
          ..write('id: $id, ')
          ..write('idProduto: $idProduto, ')
          ..write('quantidade: $quantidade, ')
          ..write('dataSaida: $dataSaida, ')
          ..write('horaSaida: $horaSaida, ')
          ..write('veioDeOnde: $veioDeOnde, ')
          ..write('codigoSeparacaoRecebimento: $codigoSeparacaoRecebimento')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(
    id,
    idProduto,
    quantidade,
    dataSaida,
    horaSaida,
    veioDeOnde,
    codigoSeparacaoRecebimento,
  );
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is WmsExpedicao &&
          other.id == this.id &&
          other.idProduto == this.idProduto &&
          other.quantidade == this.quantidade &&
          other.dataSaida == this.dataSaida &&
          other.horaSaida == this.horaSaida &&
          other.veioDeOnde == this.veioDeOnde &&
          other.codigoSeparacaoRecebimento == this.codigoSeparacaoRecebimento);
}

class WmsExpedicaosCompanion extends UpdateCompanion<WmsExpedicao> {
  final Value<int?> id;
  final Value<int?> idProduto;
  final Value<int?> quantidade;
  final Value<DateTime?> dataSaida;
  final Value<String?> horaSaida;
  final Value<String?> veioDeOnde;
  final Value<String?> codigoSeparacaoRecebimento;
  const WmsExpedicaosCompanion({
    this.id = const Value.absent(),
    this.idProduto = const Value.absent(),
    this.quantidade = const Value.absent(),
    this.dataSaida = const Value.absent(),
    this.horaSaida = const Value.absent(),
    this.veioDeOnde = const Value.absent(),
    this.codigoSeparacaoRecebimento = const Value.absent(),
  });
  WmsExpedicaosCompanion.insert({
    this.id = const Value.absent(),
    this.idProduto = const Value.absent(),
    this.quantidade = const Value.absent(),
    this.dataSaida = const Value.absent(),
    this.horaSaida = const Value.absent(),
    this.veioDeOnde = const Value.absent(),
    this.codigoSeparacaoRecebimento = const Value.absent(),
  });
  static Insertable<WmsExpedicao> custom({
    Expression<int>? id,
    Expression<int>? idProduto,
    Expression<int>? quantidade,
    Expression<DateTime>? dataSaida,
    Expression<String>? horaSaida,
    Expression<String>? veioDeOnde,
    Expression<String>? codigoSeparacaoRecebimento,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (idProduto != null) 'id_produto': idProduto,
      if (quantidade != null) 'quantidade': quantidade,
      if (dataSaida != null) 'data_saida': dataSaida,
      if (horaSaida != null) 'hora_saida': horaSaida,
      if (veioDeOnde != null) 'veio_de_onde': veioDeOnde,
      if (codigoSeparacaoRecebimento != null)
        'codigo_separacao_recebimento': codigoSeparacaoRecebimento,
    });
  }

  WmsExpedicaosCompanion copyWith({
    Value<int?>? id,
    Value<int?>? idProduto,
    Value<int?>? quantidade,
    Value<DateTime?>? dataSaida,
    Value<String?>? horaSaida,
    Value<String?>? veioDeOnde,
    Value<String?>? codigoSeparacaoRecebimento,
  }) {
    return WmsExpedicaosCompanion(
      id: id ?? this.id,
      idProduto: idProduto ?? this.idProduto,
      quantidade: quantidade ?? this.quantidade,
      dataSaida: dataSaida ?? this.dataSaida,
      horaSaida: horaSaida ?? this.horaSaida,
      veioDeOnde: veioDeOnde ?? this.veioDeOnde,
      codigoSeparacaoRecebimento:
          codigoSeparacaoRecebimento ?? this.codigoSeparacaoRecebimento,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (idProduto.present) {
      map['id_produto'] = Variable<int>(idProduto.value);
    }
    if (quantidade.present) {
      map['quantidade'] = Variable<int>(quantidade.value);
    }
    if (dataSaida.present) {
      map['data_saida'] = Variable<DateTime>(dataSaida.value);
    }
    if (horaSaida.present) {
      map['hora_saida'] = Variable<String>(horaSaida.value);
    }
    if (veioDeOnde.present) {
      map['veio_de_onde'] = Variable<String>(veioDeOnde.value);
    }
    if (codigoSeparacaoRecebimento.present) {
      map['codigo_separacao_recebimento'] = Variable<String>(
        codigoSeparacaoRecebimento.value,
      );
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('WmsExpedicaosCompanion(')
          ..write('id: $id, ')
          ..write('idProduto: $idProduto, ')
          ..write('quantidade: $quantidade, ')
          ..write('dataSaida: $dataSaida, ')
          ..write('horaSaida: $horaSaida, ')
          ..write('veioDeOnde: $veioDeOnde, ')
          ..write('codigoSeparacaoRecebimento: $codigoSeparacaoRecebimento')
          ..write(')'))
        .toString();
  }
}

class $ViewControleAcessosTable extends ViewControleAcessos
    with TableInfo<$ViewControleAcessosTable, ViewControleAcesso> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $ViewControleAcessosTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
    'id',
    aliasedName,
    true,
    type: DriftSqlType.int,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _idPessoaMeta = const VerificationMeta(
    'idPessoa',
  );
  @override
  late final GeneratedColumn<int> idPessoa = GeneratedColumn<int>(
    'id_pessoa',
    aliasedName,
    true,
    type: DriftSqlType.int,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _pessoaNomeMeta = const VerificationMeta(
    'pessoaNome',
  );
  @override
  late final GeneratedColumn<String> pessoaNome = GeneratedColumn<String>(
    'pessoa_nome',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 450,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _idColaboradorMeta = const VerificationMeta(
    'idColaborador',
  );
  @override
  late final GeneratedColumn<int> idColaborador = GeneratedColumn<int>(
    'id_colaborador',
    aliasedName,
    true,
    type: DriftSqlType.int,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _idUsuarioMeta = const VerificationMeta(
    'idUsuario',
  );
  @override
  late final GeneratedColumn<int> idUsuario = GeneratedColumn<int>(
    'id_usuario',
    aliasedName,
    true,
    type: DriftSqlType.int,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _administradorMeta = const VerificationMeta(
    'administrador',
  );
  @override
  late final GeneratedColumn<String> administrador = GeneratedColumn<String>(
    'administrador',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 3,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _idPapelMeta = const VerificationMeta(
    'idPapel',
  );
  @override
  late final GeneratedColumn<int> idPapel = GeneratedColumn<int>(
    'id_papel',
    aliasedName,
    true,
    type: DriftSqlType.int,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _papelNomeMeta = const VerificationMeta(
    'papelNome',
  );
  @override
  late final GeneratedColumn<String> papelNome = GeneratedColumn<String>(
    'papel_nome',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 300,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _papelDescricaoMeta = const VerificationMeta(
    'papelDescricao',
  );
  @override
  late final GeneratedColumn<String> papelDescricao = GeneratedColumn<String>(
    'papel_descricao',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 750,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _idFuncaoMeta = const VerificationMeta(
    'idFuncao',
  );
  @override
  late final GeneratedColumn<int> idFuncao = GeneratedColumn<int>(
    'id_funcao',
    aliasedName,
    true,
    type: DriftSqlType.int,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _funcaoNomeMeta = const VerificationMeta(
    'funcaoNome',
  );
  @override
  late final GeneratedColumn<String> funcaoNome = GeneratedColumn<String>(
    'funcao_nome',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 300,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _funcaoDescricaoMeta = const VerificationMeta(
    'funcaoDescricao',
  );
  @override
  late final GeneratedColumn<String> funcaoDescricao = GeneratedColumn<String>(
    'funcao_descricao',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 750,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _idPapelFuncaoMeta = const VerificationMeta(
    'idPapelFuncao',
  );
  @override
  late final GeneratedColumn<int> idPapelFuncao = GeneratedColumn<int>(
    'id_papel_funcao',
    aliasedName,
    true,
    type: DriftSqlType.int,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _habilitadoMeta = const VerificationMeta(
    'habilitado',
  );
  @override
  late final GeneratedColumn<String> habilitado = GeneratedColumn<String>(
    'habilitado',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 3,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _podeInserirMeta = const VerificationMeta(
    'podeInserir',
  );
  @override
  late final GeneratedColumn<String> podeInserir = GeneratedColumn<String>(
    'pode_inserir',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 3,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _podeAlterarMeta = const VerificationMeta(
    'podeAlterar',
  );
  @override
  late final GeneratedColumn<String> podeAlterar = GeneratedColumn<String>(
    'pode_alterar',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 3,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _podeExcluirMeta = const VerificationMeta(
    'podeExcluir',
  );
  @override
  late final GeneratedColumn<String> podeExcluir = GeneratedColumn<String>(
    'pode_excluir',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 3,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  @override
  List<GeneratedColumn> get $columns => [
    id,
    idPessoa,
    pessoaNome,
    idColaborador,
    idUsuario,
    administrador,
    idPapel,
    papelNome,
    papelDescricao,
    idFuncao,
    funcaoNome,
    funcaoDescricao,
    idPapelFuncao,
    habilitado,
    podeInserir,
    podeAlterar,
    podeExcluir,
  ];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'view_controle_acesso';
  @override
  VerificationContext validateIntegrity(
    Insertable<ViewControleAcesso> instance, {
    bool isInserting = false,
  }) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('id_pessoa')) {
      context.handle(
        _idPessoaMeta,
        idPessoa.isAcceptableOrUnknown(data['id_pessoa']!, _idPessoaMeta),
      );
    }
    if (data.containsKey('pessoa_nome')) {
      context.handle(
        _pessoaNomeMeta,
        pessoaNome.isAcceptableOrUnknown(data['pessoa_nome']!, _pessoaNomeMeta),
      );
    }
    if (data.containsKey('id_colaborador')) {
      context.handle(
        _idColaboradorMeta,
        idColaborador.isAcceptableOrUnknown(
          data['id_colaborador']!,
          _idColaboradorMeta,
        ),
      );
    }
    if (data.containsKey('id_usuario')) {
      context.handle(
        _idUsuarioMeta,
        idUsuario.isAcceptableOrUnknown(data['id_usuario']!, _idUsuarioMeta),
      );
    }
    if (data.containsKey('administrador')) {
      context.handle(
        _administradorMeta,
        administrador.isAcceptableOrUnknown(
          data['administrador']!,
          _administradorMeta,
        ),
      );
    }
    if (data.containsKey('id_papel')) {
      context.handle(
        _idPapelMeta,
        idPapel.isAcceptableOrUnknown(data['id_papel']!, _idPapelMeta),
      );
    }
    if (data.containsKey('papel_nome')) {
      context.handle(
        _papelNomeMeta,
        papelNome.isAcceptableOrUnknown(data['papel_nome']!, _papelNomeMeta),
      );
    }
    if (data.containsKey('papel_descricao')) {
      context.handle(
        _papelDescricaoMeta,
        papelDescricao.isAcceptableOrUnknown(
          data['papel_descricao']!,
          _papelDescricaoMeta,
        ),
      );
    }
    if (data.containsKey('id_funcao')) {
      context.handle(
        _idFuncaoMeta,
        idFuncao.isAcceptableOrUnknown(data['id_funcao']!, _idFuncaoMeta),
      );
    }
    if (data.containsKey('funcao_nome')) {
      context.handle(
        _funcaoNomeMeta,
        funcaoNome.isAcceptableOrUnknown(data['funcao_nome']!, _funcaoNomeMeta),
      );
    }
    if (data.containsKey('funcao_descricao')) {
      context.handle(
        _funcaoDescricaoMeta,
        funcaoDescricao.isAcceptableOrUnknown(
          data['funcao_descricao']!,
          _funcaoDescricaoMeta,
        ),
      );
    }
    if (data.containsKey('id_papel_funcao')) {
      context.handle(
        _idPapelFuncaoMeta,
        idPapelFuncao.isAcceptableOrUnknown(
          data['id_papel_funcao']!,
          _idPapelFuncaoMeta,
        ),
      );
    }
    if (data.containsKey('habilitado')) {
      context.handle(
        _habilitadoMeta,
        habilitado.isAcceptableOrUnknown(data['habilitado']!, _habilitadoMeta),
      );
    }
    if (data.containsKey('pode_inserir')) {
      context.handle(
        _podeInserirMeta,
        podeInserir.isAcceptableOrUnknown(
          data['pode_inserir']!,
          _podeInserirMeta,
        ),
      );
    }
    if (data.containsKey('pode_alterar')) {
      context.handle(
        _podeAlterarMeta,
        podeAlterar.isAcceptableOrUnknown(
          data['pode_alterar']!,
          _podeAlterarMeta,
        ),
      );
    }
    if (data.containsKey('pode_excluir')) {
      context.handle(
        _podeExcluirMeta,
        podeExcluir.isAcceptableOrUnknown(
          data['pode_excluir']!,
          _podeExcluirMeta,
        ),
      );
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  ViewControleAcesso map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return ViewControleAcesso(
      id: attachedDatabase.typeMapping.read(
        DriftSqlType.int,
        data['${effectivePrefix}id'],
      ),
      idPessoa: attachedDatabase.typeMapping.read(
        DriftSqlType.int,
        data['${effectivePrefix}id_pessoa'],
      ),
      pessoaNome: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}pessoa_nome'],
      ),
      idColaborador: attachedDatabase.typeMapping.read(
        DriftSqlType.int,
        data['${effectivePrefix}id_colaborador'],
      ),
      idUsuario: attachedDatabase.typeMapping.read(
        DriftSqlType.int,
        data['${effectivePrefix}id_usuario'],
      ),
      administrador: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}administrador'],
      ),
      idPapel: attachedDatabase.typeMapping.read(
        DriftSqlType.int,
        data['${effectivePrefix}id_papel'],
      ),
      papelNome: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}papel_nome'],
      ),
      papelDescricao: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}papel_descricao'],
      ),
      idFuncao: attachedDatabase.typeMapping.read(
        DriftSqlType.int,
        data['${effectivePrefix}id_funcao'],
      ),
      funcaoNome: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}funcao_nome'],
      ),
      funcaoDescricao: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}funcao_descricao'],
      ),
      idPapelFuncao: attachedDatabase.typeMapping.read(
        DriftSqlType.int,
        data['${effectivePrefix}id_papel_funcao'],
      ),
      habilitado: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}habilitado'],
      ),
      podeInserir: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}pode_inserir'],
      ),
      podeAlterar: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}pode_alterar'],
      ),
      podeExcluir: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}pode_excluir'],
      ),
    );
  }

  @override
  $ViewControleAcessosTable createAlias(String alias) {
    return $ViewControleAcessosTable(attachedDatabase, alias);
  }
}

class ViewControleAcesso extends DataClass
    implements Insertable<ViewControleAcesso> {
  final int? id;
  final int? idPessoa;
  final String? pessoaNome;
  final int? idColaborador;
  final int? idUsuario;
  final String? administrador;
  final int? idPapel;
  final String? papelNome;
  final String? papelDescricao;
  final int? idFuncao;
  final String? funcaoNome;
  final String? funcaoDescricao;
  final int? idPapelFuncao;
  final String? habilitado;
  final String? podeInserir;
  final String? podeAlterar;
  final String? podeExcluir;
  const ViewControleAcesso({
    this.id,
    this.idPessoa,
    this.pessoaNome,
    this.idColaborador,
    this.idUsuario,
    this.administrador,
    this.idPapel,
    this.papelNome,
    this.papelDescricao,
    this.idFuncao,
    this.funcaoNome,
    this.funcaoDescricao,
    this.idPapelFuncao,
    this.habilitado,
    this.podeInserir,
    this.podeAlterar,
    this.podeExcluir,
  });
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || idPessoa != null) {
      map['id_pessoa'] = Variable<int>(idPessoa);
    }
    if (!nullToAbsent || pessoaNome != null) {
      map['pessoa_nome'] = Variable<String>(pessoaNome);
    }
    if (!nullToAbsent || idColaborador != null) {
      map['id_colaborador'] = Variable<int>(idColaborador);
    }
    if (!nullToAbsent || idUsuario != null) {
      map['id_usuario'] = Variable<int>(idUsuario);
    }
    if (!nullToAbsent || administrador != null) {
      map['administrador'] = Variable<String>(administrador);
    }
    if (!nullToAbsent || idPapel != null) {
      map['id_papel'] = Variable<int>(idPapel);
    }
    if (!nullToAbsent || papelNome != null) {
      map['papel_nome'] = Variable<String>(papelNome);
    }
    if (!nullToAbsent || papelDescricao != null) {
      map['papel_descricao'] = Variable<String>(papelDescricao);
    }
    if (!nullToAbsent || idFuncao != null) {
      map['id_funcao'] = Variable<int>(idFuncao);
    }
    if (!nullToAbsent || funcaoNome != null) {
      map['funcao_nome'] = Variable<String>(funcaoNome);
    }
    if (!nullToAbsent || funcaoDescricao != null) {
      map['funcao_descricao'] = Variable<String>(funcaoDescricao);
    }
    if (!nullToAbsent || idPapelFuncao != null) {
      map['id_papel_funcao'] = Variable<int>(idPapelFuncao);
    }
    if (!nullToAbsent || habilitado != null) {
      map['habilitado'] = Variable<String>(habilitado);
    }
    if (!nullToAbsent || podeInserir != null) {
      map['pode_inserir'] = Variable<String>(podeInserir);
    }
    if (!nullToAbsent || podeAlterar != null) {
      map['pode_alterar'] = Variable<String>(podeAlterar);
    }
    if (!nullToAbsent || podeExcluir != null) {
      map['pode_excluir'] = Variable<String>(podeExcluir);
    }
    return map;
  }

  factory ViewControleAcesso.fromJson(
    Map<String, dynamic> json, {
    ValueSerializer? serializer,
  }) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return ViewControleAcesso(
      id: serializer.fromJson<int?>(json['id']),
      idPessoa: serializer.fromJson<int?>(json['idPessoa']),
      pessoaNome: serializer.fromJson<String?>(json['pessoaNome']),
      idColaborador: serializer.fromJson<int?>(json['idColaborador']),
      idUsuario: serializer.fromJson<int?>(json['idUsuario']),
      administrador: serializer.fromJson<String?>(json['administrador']),
      idPapel: serializer.fromJson<int?>(json['idPapel']),
      papelNome: serializer.fromJson<String?>(json['papelNome']),
      papelDescricao: serializer.fromJson<String?>(json['papelDescricao']),
      idFuncao: serializer.fromJson<int?>(json['idFuncao']),
      funcaoNome: serializer.fromJson<String?>(json['funcaoNome']),
      funcaoDescricao: serializer.fromJson<String?>(json['funcaoDescricao']),
      idPapelFuncao: serializer.fromJson<int?>(json['idPapelFuncao']),
      habilitado: serializer.fromJson<String?>(json['habilitado']),
      podeInserir: serializer.fromJson<String?>(json['podeInserir']),
      podeAlterar: serializer.fromJson<String?>(json['podeAlterar']),
      podeExcluir: serializer.fromJson<String?>(json['podeExcluir']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'idPessoa': serializer.toJson<int?>(idPessoa),
      'pessoaNome': serializer.toJson<String?>(pessoaNome),
      'idColaborador': serializer.toJson<int?>(idColaborador),
      'idUsuario': serializer.toJson<int?>(idUsuario),
      'administrador': serializer.toJson<String?>(administrador),
      'idPapel': serializer.toJson<int?>(idPapel),
      'papelNome': serializer.toJson<String?>(papelNome),
      'papelDescricao': serializer.toJson<String?>(papelDescricao),
      'idFuncao': serializer.toJson<int?>(idFuncao),
      'funcaoNome': serializer.toJson<String?>(funcaoNome),
      'funcaoDescricao': serializer.toJson<String?>(funcaoDescricao),
      'idPapelFuncao': serializer.toJson<int?>(idPapelFuncao),
      'habilitado': serializer.toJson<String?>(habilitado),
      'podeInserir': serializer.toJson<String?>(podeInserir),
      'podeAlterar': serializer.toJson<String?>(podeAlterar),
      'podeExcluir': serializer.toJson<String?>(podeExcluir),
    };
  }

  ViewControleAcesso copyWith({
    Value<int?> id = const Value.absent(),
    Value<int?> idPessoa = const Value.absent(),
    Value<String?> pessoaNome = const Value.absent(),
    Value<int?> idColaborador = const Value.absent(),
    Value<int?> idUsuario = const Value.absent(),
    Value<String?> administrador = const Value.absent(),
    Value<int?> idPapel = const Value.absent(),
    Value<String?> papelNome = const Value.absent(),
    Value<String?> papelDescricao = const Value.absent(),
    Value<int?> idFuncao = const Value.absent(),
    Value<String?> funcaoNome = const Value.absent(),
    Value<String?> funcaoDescricao = const Value.absent(),
    Value<int?> idPapelFuncao = const Value.absent(),
    Value<String?> habilitado = const Value.absent(),
    Value<String?> podeInserir = const Value.absent(),
    Value<String?> podeAlterar = const Value.absent(),
    Value<String?> podeExcluir = const Value.absent(),
  }) => ViewControleAcesso(
    id: id.present ? id.value : this.id,
    idPessoa: idPessoa.present ? idPessoa.value : this.idPessoa,
    pessoaNome: pessoaNome.present ? pessoaNome.value : this.pessoaNome,
    idColaborador:
        idColaborador.present ? idColaborador.value : this.idColaborador,
    idUsuario: idUsuario.present ? idUsuario.value : this.idUsuario,
    administrador:
        administrador.present ? administrador.value : this.administrador,
    idPapel: idPapel.present ? idPapel.value : this.idPapel,
    papelNome: papelNome.present ? papelNome.value : this.papelNome,
    papelDescricao:
        papelDescricao.present ? papelDescricao.value : this.papelDescricao,
    idFuncao: idFuncao.present ? idFuncao.value : this.idFuncao,
    funcaoNome: funcaoNome.present ? funcaoNome.value : this.funcaoNome,
    funcaoDescricao:
        funcaoDescricao.present ? funcaoDescricao.value : this.funcaoDescricao,
    idPapelFuncao:
        idPapelFuncao.present ? idPapelFuncao.value : this.idPapelFuncao,
    habilitado: habilitado.present ? habilitado.value : this.habilitado,
    podeInserir: podeInserir.present ? podeInserir.value : this.podeInserir,
    podeAlterar: podeAlterar.present ? podeAlterar.value : this.podeAlterar,
    podeExcluir: podeExcluir.present ? podeExcluir.value : this.podeExcluir,
  );
  ViewControleAcesso copyWithCompanion(ViewControleAcessosCompanion data) {
    return ViewControleAcesso(
      id: data.id.present ? data.id.value : this.id,
      idPessoa: data.idPessoa.present ? data.idPessoa.value : this.idPessoa,
      pessoaNome:
          data.pessoaNome.present ? data.pessoaNome.value : this.pessoaNome,
      idColaborador:
          data.idColaborador.present
              ? data.idColaborador.value
              : this.idColaborador,
      idUsuario: data.idUsuario.present ? data.idUsuario.value : this.idUsuario,
      administrador:
          data.administrador.present
              ? data.administrador.value
              : this.administrador,
      idPapel: data.idPapel.present ? data.idPapel.value : this.idPapel,
      papelNome: data.papelNome.present ? data.papelNome.value : this.papelNome,
      papelDescricao:
          data.papelDescricao.present
              ? data.papelDescricao.value
              : this.papelDescricao,
      idFuncao: data.idFuncao.present ? data.idFuncao.value : this.idFuncao,
      funcaoNome:
          data.funcaoNome.present ? data.funcaoNome.value : this.funcaoNome,
      funcaoDescricao:
          data.funcaoDescricao.present
              ? data.funcaoDescricao.value
              : this.funcaoDescricao,
      idPapelFuncao:
          data.idPapelFuncao.present
              ? data.idPapelFuncao.value
              : this.idPapelFuncao,
      habilitado:
          data.habilitado.present ? data.habilitado.value : this.habilitado,
      podeInserir:
          data.podeInserir.present ? data.podeInserir.value : this.podeInserir,
      podeAlterar:
          data.podeAlterar.present ? data.podeAlterar.value : this.podeAlterar,
      podeExcluir:
          data.podeExcluir.present ? data.podeExcluir.value : this.podeExcluir,
    );
  }

  @override
  String toString() {
    return (StringBuffer('ViewControleAcesso(')
          ..write('id: $id, ')
          ..write('idPessoa: $idPessoa, ')
          ..write('pessoaNome: $pessoaNome, ')
          ..write('idColaborador: $idColaborador, ')
          ..write('idUsuario: $idUsuario, ')
          ..write('administrador: $administrador, ')
          ..write('idPapel: $idPapel, ')
          ..write('papelNome: $papelNome, ')
          ..write('papelDescricao: $papelDescricao, ')
          ..write('idFuncao: $idFuncao, ')
          ..write('funcaoNome: $funcaoNome, ')
          ..write('funcaoDescricao: $funcaoDescricao, ')
          ..write('idPapelFuncao: $idPapelFuncao, ')
          ..write('habilitado: $habilitado, ')
          ..write('podeInserir: $podeInserir, ')
          ..write('podeAlterar: $podeAlterar, ')
          ..write('podeExcluir: $podeExcluir')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(
    id,
    idPessoa,
    pessoaNome,
    idColaborador,
    idUsuario,
    administrador,
    idPapel,
    papelNome,
    papelDescricao,
    idFuncao,
    funcaoNome,
    funcaoDescricao,
    idPapelFuncao,
    habilitado,
    podeInserir,
    podeAlterar,
    podeExcluir,
  );
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is ViewControleAcesso &&
          other.id == this.id &&
          other.idPessoa == this.idPessoa &&
          other.pessoaNome == this.pessoaNome &&
          other.idColaborador == this.idColaborador &&
          other.idUsuario == this.idUsuario &&
          other.administrador == this.administrador &&
          other.idPapel == this.idPapel &&
          other.papelNome == this.papelNome &&
          other.papelDescricao == this.papelDescricao &&
          other.idFuncao == this.idFuncao &&
          other.funcaoNome == this.funcaoNome &&
          other.funcaoDescricao == this.funcaoDescricao &&
          other.idPapelFuncao == this.idPapelFuncao &&
          other.habilitado == this.habilitado &&
          other.podeInserir == this.podeInserir &&
          other.podeAlterar == this.podeAlterar &&
          other.podeExcluir == this.podeExcluir);
}

class ViewControleAcessosCompanion extends UpdateCompanion<ViewControleAcesso> {
  final Value<int?> id;
  final Value<int?> idPessoa;
  final Value<String?> pessoaNome;
  final Value<int?> idColaborador;
  final Value<int?> idUsuario;
  final Value<String?> administrador;
  final Value<int?> idPapel;
  final Value<String?> papelNome;
  final Value<String?> papelDescricao;
  final Value<int?> idFuncao;
  final Value<String?> funcaoNome;
  final Value<String?> funcaoDescricao;
  final Value<int?> idPapelFuncao;
  final Value<String?> habilitado;
  final Value<String?> podeInserir;
  final Value<String?> podeAlterar;
  final Value<String?> podeExcluir;
  const ViewControleAcessosCompanion({
    this.id = const Value.absent(),
    this.idPessoa = const Value.absent(),
    this.pessoaNome = const Value.absent(),
    this.idColaborador = const Value.absent(),
    this.idUsuario = const Value.absent(),
    this.administrador = const Value.absent(),
    this.idPapel = const Value.absent(),
    this.papelNome = const Value.absent(),
    this.papelDescricao = const Value.absent(),
    this.idFuncao = const Value.absent(),
    this.funcaoNome = const Value.absent(),
    this.funcaoDescricao = const Value.absent(),
    this.idPapelFuncao = const Value.absent(),
    this.habilitado = const Value.absent(),
    this.podeInserir = const Value.absent(),
    this.podeAlterar = const Value.absent(),
    this.podeExcluir = const Value.absent(),
  });
  ViewControleAcessosCompanion.insert({
    this.id = const Value.absent(),
    this.idPessoa = const Value.absent(),
    this.pessoaNome = const Value.absent(),
    this.idColaborador = const Value.absent(),
    this.idUsuario = const Value.absent(),
    this.administrador = const Value.absent(),
    this.idPapel = const Value.absent(),
    this.papelNome = const Value.absent(),
    this.papelDescricao = const Value.absent(),
    this.idFuncao = const Value.absent(),
    this.funcaoNome = const Value.absent(),
    this.funcaoDescricao = const Value.absent(),
    this.idPapelFuncao = const Value.absent(),
    this.habilitado = const Value.absent(),
    this.podeInserir = const Value.absent(),
    this.podeAlterar = const Value.absent(),
    this.podeExcluir = const Value.absent(),
  });
  static Insertable<ViewControleAcesso> custom({
    Expression<int>? id,
    Expression<int>? idPessoa,
    Expression<String>? pessoaNome,
    Expression<int>? idColaborador,
    Expression<int>? idUsuario,
    Expression<String>? administrador,
    Expression<int>? idPapel,
    Expression<String>? papelNome,
    Expression<String>? papelDescricao,
    Expression<int>? idFuncao,
    Expression<String>? funcaoNome,
    Expression<String>? funcaoDescricao,
    Expression<int>? idPapelFuncao,
    Expression<String>? habilitado,
    Expression<String>? podeInserir,
    Expression<String>? podeAlterar,
    Expression<String>? podeExcluir,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (idPessoa != null) 'id_pessoa': idPessoa,
      if (pessoaNome != null) 'pessoa_nome': pessoaNome,
      if (idColaborador != null) 'id_colaborador': idColaborador,
      if (idUsuario != null) 'id_usuario': idUsuario,
      if (administrador != null) 'administrador': administrador,
      if (idPapel != null) 'id_papel': idPapel,
      if (papelNome != null) 'papel_nome': papelNome,
      if (papelDescricao != null) 'papel_descricao': papelDescricao,
      if (idFuncao != null) 'id_funcao': idFuncao,
      if (funcaoNome != null) 'funcao_nome': funcaoNome,
      if (funcaoDescricao != null) 'funcao_descricao': funcaoDescricao,
      if (idPapelFuncao != null) 'id_papel_funcao': idPapelFuncao,
      if (habilitado != null) 'habilitado': habilitado,
      if (podeInserir != null) 'pode_inserir': podeInserir,
      if (podeAlterar != null) 'pode_alterar': podeAlterar,
      if (podeExcluir != null) 'pode_excluir': podeExcluir,
    });
  }

  ViewControleAcessosCompanion copyWith({
    Value<int?>? id,
    Value<int?>? idPessoa,
    Value<String?>? pessoaNome,
    Value<int?>? idColaborador,
    Value<int?>? idUsuario,
    Value<String?>? administrador,
    Value<int?>? idPapel,
    Value<String?>? papelNome,
    Value<String?>? papelDescricao,
    Value<int?>? idFuncao,
    Value<String?>? funcaoNome,
    Value<String?>? funcaoDescricao,
    Value<int?>? idPapelFuncao,
    Value<String?>? habilitado,
    Value<String?>? podeInserir,
    Value<String?>? podeAlterar,
    Value<String?>? podeExcluir,
  }) {
    return ViewControleAcessosCompanion(
      id: id ?? this.id,
      idPessoa: idPessoa ?? this.idPessoa,
      pessoaNome: pessoaNome ?? this.pessoaNome,
      idColaborador: idColaborador ?? this.idColaborador,
      idUsuario: idUsuario ?? this.idUsuario,
      administrador: administrador ?? this.administrador,
      idPapel: idPapel ?? this.idPapel,
      papelNome: papelNome ?? this.papelNome,
      papelDescricao: papelDescricao ?? this.papelDescricao,
      idFuncao: idFuncao ?? this.idFuncao,
      funcaoNome: funcaoNome ?? this.funcaoNome,
      funcaoDescricao: funcaoDescricao ?? this.funcaoDescricao,
      idPapelFuncao: idPapelFuncao ?? this.idPapelFuncao,
      habilitado: habilitado ?? this.habilitado,
      podeInserir: podeInserir ?? this.podeInserir,
      podeAlterar: podeAlterar ?? this.podeAlterar,
      podeExcluir: podeExcluir ?? this.podeExcluir,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (idPessoa.present) {
      map['id_pessoa'] = Variable<int>(idPessoa.value);
    }
    if (pessoaNome.present) {
      map['pessoa_nome'] = Variable<String>(pessoaNome.value);
    }
    if (idColaborador.present) {
      map['id_colaborador'] = Variable<int>(idColaborador.value);
    }
    if (idUsuario.present) {
      map['id_usuario'] = Variable<int>(idUsuario.value);
    }
    if (administrador.present) {
      map['administrador'] = Variable<String>(administrador.value);
    }
    if (idPapel.present) {
      map['id_papel'] = Variable<int>(idPapel.value);
    }
    if (papelNome.present) {
      map['papel_nome'] = Variable<String>(papelNome.value);
    }
    if (papelDescricao.present) {
      map['papel_descricao'] = Variable<String>(papelDescricao.value);
    }
    if (idFuncao.present) {
      map['id_funcao'] = Variable<int>(idFuncao.value);
    }
    if (funcaoNome.present) {
      map['funcao_nome'] = Variable<String>(funcaoNome.value);
    }
    if (funcaoDescricao.present) {
      map['funcao_descricao'] = Variable<String>(funcaoDescricao.value);
    }
    if (idPapelFuncao.present) {
      map['id_papel_funcao'] = Variable<int>(idPapelFuncao.value);
    }
    if (habilitado.present) {
      map['habilitado'] = Variable<String>(habilitado.value);
    }
    if (podeInserir.present) {
      map['pode_inserir'] = Variable<String>(podeInserir.value);
    }
    if (podeAlterar.present) {
      map['pode_alterar'] = Variable<String>(podeAlterar.value);
    }
    if (podeExcluir.present) {
      map['pode_excluir'] = Variable<String>(podeExcluir.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('ViewControleAcessosCompanion(')
          ..write('id: $id, ')
          ..write('idPessoa: $idPessoa, ')
          ..write('pessoaNome: $pessoaNome, ')
          ..write('idColaborador: $idColaborador, ')
          ..write('idUsuario: $idUsuario, ')
          ..write('administrador: $administrador, ')
          ..write('idPapel: $idPapel, ')
          ..write('papelNome: $papelNome, ')
          ..write('papelDescricao: $papelDescricao, ')
          ..write('idFuncao: $idFuncao, ')
          ..write('funcaoNome: $funcaoNome, ')
          ..write('funcaoDescricao: $funcaoDescricao, ')
          ..write('idPapelFuncao: $idPapelFuncao, ')
          ..write('habilitado: $habilitado, ')
          ..write('podeInserir: $podeInserir, ')
          ..write('podeAlterar: $podeAlterar, ')
          ..write('podeExcluir: $podeExcluir')
          ..write(')'))
        .toString();
  }
}

class $ViewPessoaUsuariosTable extends ViewPessoaUsuarios
    with TableInfo<$ViewPessoaUsuariosTable, ViewPessoaUsuario> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $ViewPessoaUsuariosTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
    'id',
    aliasedName,
    true,
    type: DriftSqlType.int,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _idPessoaMeta = const VerificationMeta(
    'idPessoa',
  );
  @override
  late final GeneratedColumn<int> idPessoa = GeneratedColumn<int>(
    'id_pessoa',
    aliasedName,
    true,
    type: DriftSqlType.int,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _pessoaNomeMeta = const VerificationMeta(
    'pessoaNome',
  );
  @override
  late final GeneratedColumn<String> pessoaNome = GeneratedColumn<String>(
    'pessoa_nome',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 450,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _tipoMeta = const VerificationMeta('tipo');
  @override
  late final GeneratedColumn<String> tipo = GeneratedColumn<String>(
    'tipo',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 3,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _emailMeta = const VerificationMeta('email');
  @override
  late final GeneratedColumn<String> email = GeneratedColumn<String>(
    'email',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 750,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _idColaboradorMeta = const VerificationMeta(
    'idColaborador',
  );
  @override
  late final GeneratedColumn<int> idColaborador = GeneratedColumn<int>(
    'id_colaborador',
    aliasedName,
    true,
    type: DriftSqlType.int,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _idUsuarioMeta = const VerificationMeta(
    'idUsuario',
  );
  @override
  late final GeneratedColumn<int> idUsuario = GeneratedColumn<int>(
    'id_usuario',
    aliasedName,
    true,
    type: DriftSqlType.int,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _loginMeta = const VerificationMeta('login');
  @override
  late final GeneratedColumn<String> login = GeneratedColumn<String>(
    'login',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 150,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _senhaMeta = const VerificationMeta('senha');
  @override
  late final GeneratedColumn<String> senha = GeneratedColumn<String>(
    'senha',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 150,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _dataCadastroMeta = const VerificationMeta(
    'dataCadastro',
  );
  @override
  late final GeneratedColumn<DateTime> dataCadastro = GeneratedColumn<DateTime>(
    'data_cadastro',
    aliasedName,
    true,
    type: DriftSqlType.dateTime,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _administradorMeta = const VerificationMeta(
    'administrador',
  );
  @override
  late final GeneratedColumn<String> administrador = GeneratedColumn<String>(
    'administrador',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 3,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  @override
  List<GeneratedColumn> get $columns => [
    id,
    idPessoa,
    pessoaNome,
    tipo,
    email,
    idColaborador,
    idUsuario,
    login,
    senha,
    dataCadastro,
    administrador,
  ];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'view_pessoa_usuario';
  @override
  VerificationContext validateIntegrity(
    Insertable<ViewPessoaUsuario> instance, {
    bool isInserting = false,
  }) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('id_pessoa')) {
      context.handle(
        _idPessoaMeta,
        idPessoa.isAcceptableOrUnknown(data['id_pessoa']!, _idPessoaMeta),
      );
    }
    if (data.containsKey('pessoa_nome')) {
      context.handle(
        _pessoaNomeMeta,
        pessoaNome.isAcceptableOrUnknown(data['pessoa_nome']!, _pessoaNomeMeta),
      );
    }
    if (data.containsKey('tipo')) {
      context.handle(
        _tipoMeta,
        tipo.isAcceptableOrUnknown(data['tipo']!, _tipoMeta),
      );
    }
    if (data.containsKey('email')) {
      context.handle(
        _emailMeta,
        email.isAcceptableOrUnknown(data['email']!, _emailMeta),
      );
    }
    if (data.containsKey('id_colaborador')) {
      context.handle(
        _idColaboradorMeta,
        idColaborador.isAcceptableOrUnknown(
          data['id_colaborador']!,
          _idColaboradorMeta,
        ),
      );
    }
    if (data.containsKey('id_usuario')) {
      context.handle(
        _idUsuarioMeta,
        idUsuario.isAcceptableOrUnknown(data['id_usuario']!, _idUsuarioMeta),
      );
    }
    if (data.containsKey('login')) {
      context.handle(
        _loginMeta,
        login.isAcceptableOrUnknown(data['login']!, _loginMeta),
      );
    }
    if (data.containsKey('senha')) {
      context.handle(
        _senhaMeta,
        senha.isAcceptableOrUnknown(data['senha']!, _senhaMeta),
      );
    }
    if (data.containsKey('data_cadastro')) {
      context.handle(
        _dataCadastroMeta,
        dataCadastro.isAcceptableOrUnknown(
          data['data_cadastro']!,
          _dataCadastroMeta,
        ),
      );
    }
    if (data.containsKey('administrador')) {
      context.handle(
        _administradorMeta,
        administrador.isAcceptableOrUnknown(
          data['administrador']!,
          _administradorMeta,
        ),
      );
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  ViewPessoaUsuario map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return ViewPessoaUsuario(
      id: attachedDatabase.typeMapping.read(
        DriftSqlType.int,
        data['${effectivePrefix}id'],
      ),
      idPessoa: attachedDatabase.typeMapping.read(
        DriftSqlType.int,
        data['${effectivePrefix}id_pessoa'],
      ),
      pessoaNome: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}pessoa_nome'],
      ),
      tipo: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}tipo'],
      ),
      email: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}email'],
      ),
      idColaborador: attachedDatabase.typeMapping.read(
        DriftSqlType.int,
        data['${effectivePrefix}id_colaborador'],
      ),
      idUsuario: attachedDatabase.typeMapping.read(
        DriftSqlType.int,
        data['${effectivePrefix}id_usuario'],
      ),
      login: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}login'],
      ),
      senha: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}senha'],
      ),
      dataCadastro: attachedDatabase.typeMapping.read(
        DriftSqlType.dateTime,
        data['${effectivePrefix}data_cadastro'],
      ),
      administrador: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}administrador'],
      ),
    );
  }

  @override
  $ViewPessoaUsuariosTable createAlias(String alias) {
    return $ViewPessoaUsuariosTable(attachedDatabase, alias);
  }
}

class ViewPessoaUsuario extends DataClass
    implements Insertable<ViewPessoaUsuario> {
  final int? id;
  final int? idPessoa;
  final String? pessoaNome;
  final String? tipo;
  final String? email;
  final int? idColaborador;
  final int? idUsuario;
  final String? login;
  final String? senha;
  final DateTime? dataCadastro;
  final String? administrador;
  const ViewPessoaUsuario({
    this.id,
    this.idPessoa,
    this.pessoaNome,
    this.tipo,
    this.email,
    this.idColaborador,
    this.idUsuario,
    this.login,
    this.senha,
    this.dataCadastro,
    this.administrador,
  });
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || idPessoa != null) {
      map['id_pessoa'] = Variable<int>(idPessoa);
    }
    if (!nullToAbsent || pessoaNome != null) {
      map['pessoa_nome'] = Variable<String>(pessoaNome);
    }
    if (!nullToAbsent || tipo != null) {
      map['tipo'] = Variable<String>(tipo);
    }
    if (!nullToAbsent || email != null) {
      map['email'] = Variable<String>(email);
    }
    if (!nullToAbsent || idColaborador != null) {
      map['id_colaborador'] = Variable<int>(idColaborador);
    }
    if (!nullToAbsent || idUsuario != null) {
      map['id_usuario'] = Variable<int>(idUsuario);
    }
    if (!nullToAbsent || login != null) {
      map['login'] = Variable<String>(login);
    }
    if (!nullToAbsent || senha != null) {
      map['senha'] = Variable<String>(senha);
    }
    if (!nullToAbsent || dataCadastro != null) {
      map['data_cadastro'] = Variable<DateTime>(dataCadastro);
    }
    if (!nullToAbsent || administrador != null) {
      map['administrador'] = Variable<String>(administrador);
    }
    return map;
  }

  factory ViewPessoaUsuario.fromJson(
    Map<String, dynamic> json, {
    ValueSerializer? serializer,
  }) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return ViewPessoaUsuario(
      id: serializer.fromJson<int?>(json['id']),
      idPessoa: serializer.fromJson<int?>(json['idPessoa']),
      pessoaNome: serializer.fromJson<String?>(json['pessoaNome']),
      tipo: serializer.fromJson<String?>(json['tipo']),
      email: serializer.fromJson<String?>(json['email']),
      idColaborador: serializer.fromJson<int?>(json['idColaborador']),
      idUsuario: serializer.fromJson<int?>(json['idUsuario']),
      login: serializer.fromJson<String?>(json['login']),
      senha: serializer.fromJson<String?>(json['senha']),
      dataCadastro: serializer.fromJson<DateTime?>(json['dataCadastro']),
      administrador: serializer.fromJson<String?>(json['administrador']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'idPessoa': serializer.toJson<int?>(idPessoa),
      'pessoaNome': serializer.toJson<String?>(pessoaNome),
      'tipo': serializer.toJson<String?>(tipo),
      'email': serializer.toJson<String?>(email),
      'idColaborador': serializer.toJson<int?>(idColaborador),
      'idUsuario': serializer.toJson<int?>(idUsuario),
      'login': serializer.toJson<String?>(login),
      'senha': serializer.toJson<String?>(senha),
      'dataCadastro': serializer.toJson<DateTime?>(dataCadastro),
      'administrador': serializer.toJson<String?>(administrador),
    };
  }

  ViewPessoaUsuario copyWith({
    Value<int?> id = const Value.absent(),
    Value<int?> idPessoa = const Value.absent(),
    Value<String?> pessoaNome = const Value.absent(),
    Value<String?> tipo = const Value.absent(),
    Value<String?> email = const Value.absent(),
    Value<int?> idColaborador = const Value.absent(),
    Value<int?> idUsuario = const Value.absent(),
    Value<String?> login = const Value.absent(),
    Value<String?> senha = const Value.absent(),
    Value<DateTime?> dataCadastro = const Value.absent(),
    Value<String?> administrador = const Value.absent(),
  }) => ViewPessoaUsuario(
    id: id.present ? id.value : this.id,
    idPessoa: idPessoa.present ? idPessoa.value : this.idPessoa,
    pessoaNome: pessoaNome.present ? pessoaNome.value : this.pessoaNome,
    tipo: tipo.present ? tipo.value : this.tipo,
    email: email.present ? email.value : this.email,
    idColaborador:
        idColaborador.present ? idColaborador.value : this.idColaborador,
    idUsuario: idUsuario.present ? idUsuario.value : this.idUsuario,
    login: login.present ? login.value : this.login,
    senha: senha.present ? senha.value : this.senha,
    dataCadastro: dataCadastro.present ? dataCadastro.value : this.dataCadastro,
    administrador:
        administrador.present ? administrador.value : this.administrador,
  );
  ViewPessoaUsuario copyWithCompanion(ViewPessoaUsuariosCompanion data) {
    return ViewPessoaUsuario(
      id: data.id.present ? data.id.value : this.id,
      idPessoa: data.idPessoa.present ? data.idPessoa.value : this.idPessoa,
      pessoaNome:
          data.pessoaNome.present ? data.pessoaNome.value : this.pessoaNome,
      tipo: data.tipo.present ? data.tipo.value : this.tipo,
      email: data.email.present ? data.email.value : this.email,
      idColaborador:
          data.idColaborador.present
              ? data.idColaborador.value
              : this.idColaborador,
      idUsuario: data.idUsuario.present ? data.idUsuario.value : this.idUsuario,
      login: data.login.present ? data.login.value : this.login,
      senha: data.senha.present ? data.senha.value : this.senha,
      dataCadastro:
          data.dataCadastro.present
              ? data.dataCadastro.value
              : this.dataCadastro,
      administrador:
          data.administrador.present
              ? data.administrador.value
              : this.administrador,
    );
  }

  @override
  String toString() {
    return (StringBuffer('ViewPessoaUsuario(')
          ..write('id: $id, ')
          ..write('idPessoa: $idPessoa, ')
          ..write('pessoaNome: $pessoaNome, ')
          ..write('tipo: $tipo, ')
          ..write('email: $email, ')
          ..write('idColaborador: $idColaborador, ')
          ..write('idUsuario: $idUsuario, ')
          ..write('login: $login, ')
          ..write('senha: $senha, ')
          ..write('dataCadastro: $dataCadastro, ')
          ..write('administrador: $administrador')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(
    id,
    idPessoa,
    pessoaNome,
    tipo,
    email,
    idColaborador,
    idUsuario,
    login,
    senha,
    dataCadastro,
    administrador,
  );
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is ViewPessoaUsuario &&
          other.id == this.id &&
          other.idPessoa == this.idPessoa &&
          other.pessoaNome == this.pessoaNome &&
          other.tipo == this.tipo &&
          other.email == this.email &&
          other.idColaborador == this.idColaborador &&
          other.idUsuario == this.idUsuario &&
          other.login == this.login &&
          other.senha == this.senha &&
          other.dataCadastro == this.dataCadastro &&
          other.administrador == this.administrador);
}

class ViewPessoaUsuariosCompanion extends UpdateCompanion<ViewPessoaUsuario> {
  final Value<int?> id;
  final Value<int?> idPessoa;
  final Value<String?> pessoaNome;
  final Value<String?> tipo;
  final Value<String?> email;
  final Value<int?> idColaborador;
  final Value<int?> idUsuario;
  final Value<String?> login;
  final Value<String?> senha;
  final Value<DateTime?> dataCadastro;
  final Value<String?> administrador;
  const ViewPessoaUsuariosCompanion({
    this.id = const Value.absent(),
    this.idPessoa = const Value.absent(),
    this.pessoaNome = const Value.absent(),
    this.tipo = const Value.absent(),
    this.email = const Value.absent(),
    this.idColaborador = const Value.absent(),
    this.idUsuario = const Value.absent(),
    this.login = const Value.absent(),
    this.senha = const Value.absent(),
    this.dataCadastro = const Value.absent(),
    this.administrador = const Value.absent(),
  });
  ViewPessoaUsuariosCompanion.insert({
    this.id = const Value.absent(),
    this.idPessoa = const Value.absent(),
    this.pessoaNome = const Value.absent(),
    this.tipo = const Value.absent(),
    this.email = const Value.absent(),
    this.idColaborador = const Value.absent(),
    this.idUsuario = const Value.absent(),
    this.login = const Value.absent(),
    this.senha = const Value.absent(),
    this.dataCadastro = const Value.absent(),
    this.administrador = const Value.absent(),
  });
  static Insertable<ViewPessoaUsuario> custom({
    Expression<int>? id,
    Expression<int>? idPessoa,
    Expression<String>? pessoaNome,
    Expression<String>? tipo,
    Expression<String>? email,
    Expression<int>? idColaborador,
    Expression<int>? idUsuario,
    Expression<String>? login,
    Expression<String>? senha,
    Expression<DateTime>? dataCadastro,
    Expression<String>? administrador,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (idPessoa != null) 'id_pessoa': idPessoa,
      if (pessoaNome != null) 'pessoa_nome': pessoaNome,
      if (tipo != null) 'tipo': tipo,
      if (email != null) 'email': email,
      if (idColaborador != null) 'id_colaborador': idColaborador,
      if (idUsuario != null) 'id_usuario': idUsuario,
      if (login != null) 'login': login,
      if (senha != null) 'senha': senha,
      if (dataCadastro != null) 'data_cadastro': dataCadastro,
      if (administrador != null) 'administrador': administrador,
    });
  }

  ViewPessoaUsuariosCompanion copyWith({
    Value<int?>? id,
    Value<int?>? idPessoa,
    Value<String?>? pessoaNome,
    Value<String?>? tipo,
    Value<String?>? email,
    Value<int?>? idColaborador,
    Value<int?>? idUsuario,
    Value<String?>? login,
    Value<String?>? senha,
    Value<DateTime?>? dataCadastro,
    Value<String?>? administrador,
  }) {
    return ViewPessoaUsuariosCompanion(
      id: id ?? this.id,
      idPessoa: idPessoa ?? this.idPessoa,
      pessoaNome: pessoaNome ?? this.pessoaNome,
      tipo: tipo ?? this.tipo,
      email: email ?? this.email,
      idColaborador: idColaborador ?? this.idColaborador,
      idUsuario: idUsuario ?? this.idUsuario,
      login: login ?? this.login,
      senha: senha ?? this.senha,
      dataCadastro: dataCadastro ?? this.dataCadastro,
      administrador: administrador ?? this.administrador,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (idPessoa.present) {
      map['id_pessoa'] = Variable<int>(idPessoa.value);
    }
    if (pessoaNome.present) {
      map['pessoa_nome'] = Variable<String>(pessoaNome.value);
    }
    if (tipo.present) {
      map['tipo'] = Variable<String>(tipo.value);
    }
    if (email.present) {
      map['email'] = Variable<String>(email.value);
    }
    if (idColaborador.present) {
      map['id_colaborador'] = Variable<int>(idColaborador.value);
    }
    if (idUsuario.present) {
      map['id_usuario'] = Variable<int>(idUsuario.value);
    }
    if (login.present) {
      map['login'] = Variable<String>(login.value);
    }
    if (senha.present) {
      map['senha'] = Variable<String>(senha.value);
    }
    if (dataCadastro.present) {
      map['data_cadastro'] = Variable<DateTime>(dataCadastro.value);
    }
    if (administrador.present) {
      map['administrador'] = Variable<String>(administrador.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('ViewPessoaUsuariosCompanion(')
          ..write('id: $id, ')
          ..write('idPessoa: $idPessoa, ')
          ..write('pessoaNome: $pessoaNome, ')
          ..write('tipo: $tipo, ')
          ..write('email: $email, ')
          ..write('idColaborador: $idColaborador, ')
          ..write('idUsuario: $idUsuario, ')
          ..write('login: $login, ')
          ..write('senha: $senha, ')
          ..write('dataCadastro: $dataCadastro, ')
          ..write('administrador: $administrador')
          ..write(')'))
        .toString();
  }
}

abstract class _$AppDatabase extends GeneratedDatabase {
  _$AppDatabase(QueryExecutor e) : super(e);
  $AppDatabaseManager get managers => $AppDatabaseManager(this);
  late final $WmsRecebimentoDetalhesTable wmsRecebimentoDetalhes =
      $WmsRecebimentoDetalhesTable(this);
  late final $WmsCaixasTable wmsCaixas = $WmsCaixasTable(this);
  late final $WmsOrdemSeparacaoDetsTable wmsOrdemSeparacaoDets =
      $WmsOrdemSeparacaoDetsTable(this);
  late final $WmsRecebimentoCabecalhosTable wmsRecebimentoCabecalhos =
      $WmsRecebimentoCabecalhosTable(this);
  late final $WmsEstantesTable wmsEstantes = $WmsEstantesTable(this);
  late final $WmsOrdemSeparacaoCabsTable wmsOrdemSeparacaoCabs =
      $WmsOrdemSeparacaoCabsTable(this);
  late final $ProdutosTable produtos = $ProdutosTable(this);
  late final $WmsAgendamentosTable wmsAgendamentos = $WmsAgendamentosTable(
    this,
  );
  late final $WmsParametrosTable wmsParametros = $WmsParametrosTable(this);
  late final $WmsRuasTable wmsRuas = $WmsRuasTable(this);
  late final $WmsArmazenamentosTable wmsArmazenamentos =
      $WmsArmazenamentosTable(this);
  late final $WmsExpedicaosTable wmsExpedicaos = $WmsExpedicaosTable(this);
  late final $ViewControleAcessosTable viewControleAcessos =
      $ViewControleAcessosTable(this);
  late final $ViewPessoaUsuariosTable viewPessoaUsuarios =
      $ViewPessoaUsuariosTable(this);
  late final WmsRecebimentoCabecalhoDao wmsRecebimentoCabecalhoDao =
      WmsRecebimentoCabecalhoDao(this as AppDatabase);
  late final WmsEstanteDao wmsEstanteDao = WmsEstanteDao(this as AppDatabase);
  late final WmsOrdemSeparacaoCabDao wmsOrdemSeparacaoCabDao =
      WmsOrdemSeparacaoCabDao(this as AppDatabase);
  late final ProdutoDao produtoDao = ProdutoDao(this as AppDatabase);
  late final WmsAgendamentoDao wmsAgendamentoDao = WmsAgendamentoDao(
    this as AppDatabase,
  );
  late final WmsParametroDao wmsParametroDao = WmsParametroDao(
    this as AppDatabase,
  );
  late final WmsRuaDao wmsRuaDao = WmsRuaDao(this as AppDatabase);
  late final WmsArmazenamentoDao wmsArmazenamentoDao = WmsArmazenamentoDao(
    this as AppDatabase,
  );
  late final WmsExpedicaoDao wmsExpedicaoDao = WmsExpedicaoDao(
    this as AppDatabase,
  );
  late final ViewControleAcessoDao viewControleAcessoDao =
      ViewControleAcessoDao(this as AppDatabase);
  late final ViewPessoaUsuarioDao viewPessoaUsuarioDao = ViewPessoaUsuarioDao(
    this as AppDatabase,
  );
  @override
  Iterable<TableInfo<Table, Object?>> get allTables =>
      allSchemaEntities.whereType<TableInfo<Table, Object?>>();
  @override
  List<DatabaseSchemaEntity> get allSchemaEntities => [
    wmsRecebimentoDetalhes,
    wmsCaixas,
    wmsOrdemSeparacaoDets,
    wmsRecebimentoCabecalhos,
    wmsEstantes,
    wmsOrdemSeparacaoCabs,
    produtos,
    wmsAgendamentos,
    wmsParametros,
    wmsRuas,
    wmsArmazenamentos,
    wmsExpedicaos,
    viewControleAcessos,
    viewPessoaUsuarios,
  ];
}

typedef $$WmsRecebimentoDetalhesTableCreateCompanionBuilder =
    WmsRecebimentoDetalhesCompanion Function({
      Value<int?> id,
      Value<int?> idWmsRecebimentoCabecalho,
      Value<int?> idProduto,
      Value<int?> quantidadeVolume,
      Value<int?> quantidadeItemPorVolume,
      Value<int?> quantidadeRecebida,
      Value<String?> destino,
    });
typedef $$WmsRecebimentoDetalhesTableUpdateCompanionBuilder =
    WmsRecebimentoDetalhesCompanion Function({
      Value<int?> id,
      Value<int?> idWmsRecebimentoCabecalho,
      Value<int?> idProduto,
      Value<int?> quantidadeVolume,
      Value<int?> quantidadeItemPorVolume,
      Value<int?> quantidadeRecebida,
      Value<String?> destino,
    });

class $$WmsRecebimentoDetalhesTableFilterComposer
    extends Composer<_$AppDatabase, $WmsRecebimentoDetalhesTable> {
  $$WmsRecebimentoDetalhesTableFilterComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnFilters<int> get id => $composableBuilder(
    column: $table.id,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<int> get idWmsRecebimentoCabecalho => $composableBuilder(
    column: $table.idWmsRecebimentoCabecalho,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<int> get idProduto => $composableBuilder(
    column: $table.idProduto,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<int> get quantidadeVolume => $composableBuilder(
    column: $table.quantidadeVolume,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<int> get quantidadeItemPorVolume => $composableBuilder(
    column: $table.quantidadeItemPorVolume,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<int> get quantidadeRecebida => $composableBuilder(
    column: $table.quantidadeRecebida,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get destino => $composableBuilder(
    column: $table.destino,
    builder: (column) => ColumnFilters(column),
  );
}

class $$WmsRecebimentoDetalhesTableOrderingComposer
    extends Composer<_$AppDatabase, $WmsRecebimentoDetalhesTable> {
  $$WmsRecebimentoDetalhesTableOrderingComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnOrderings<int> get id => $composableBuilder(
    column: $table.id,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<int> get idWmsRecebimentoCabecalho => $composableBuilder(
    column: $table.idWmsRecebimentoCabecalho,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<int> get idProduto => $composableBuilder(
    column: $table.idProduto,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<int> get quantidadeVolume => $composableBuilder(
    column: $table.quantidadeVolume,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<int> get quantidadeItemPorVolume => $composableBuilder(
    column: $table.quantidadeItemPorVolume,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<int> get quantidadeRecebida => $composableBuilder(
    column: $table.quantidadeRecebida,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get destino => $composableBuilder(
    column: $table.destino,
    builder: (column) => ColumnOrderings(column),
  );
}

class $$WmsRecebimentoDetalhesTableAnnotationComposer
    extends Composer<_$AppDatabase, $WmsRecebimentoDetalhesTable> {
  $$WmsRecebimentoDetalhesTableAnnotationComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  GeneratedColumn<int> get id =>
      $composableBuilder(column: $table.id, builder: (column) => column);

  GeneratedColumn<int> get idWmsRecebimentoCabecalho => $composableBuilder(
    column: $table.idWmsRecebimentoCabecalho,
    builder: (column) => column,
  );

  GeneratedColumn<int> get idProduto =>
      $composableBuilder(column: $table.idProduto, builder: (column) => column);

  GeneratedColumn<int> get quantidadeVolume => $composableBuilder(
    column: $table.quantidadeVolume,
    builder: (column) => column,
  );

  GeneratedColumn<int> get quantidadeItemPorVolume => $composableBuilder(
    column: $table.quantidadeItemPorVolume,
    builder: (column) => column,
  );

  GeneratedColumn<int> get quantidadeRecebida => $composableBuilder(
    column: $table.quantidadeRecebida,
    builder: (column) => column,
  );

  GeneratedColumn<String> get destino =>
      $composableBuilder(column: $table.destino, builder: (column) => column);
}

class $$WmsRecebimentoDetalhesTableTableManager
    extends
        RootTableManager<
          _$AppDatabase,
          $WmsRecebimentoDetalhesTable,
          WmsRecebimentoDetalhe,
          $$WmsRecebimentoDetalhesTableFilterComposer,
          $$WmsRecebimentoDetalhesTableOrderingComposer,
          $$WmsRecebimentoDetalhesTableAnnotationComposer,
          $$WmsRecebimentoDetalhesTableCreateCompanionBuilder,
          $$WmsRecebimentoDetalhesTableUpdateCompanionBuilder,
          (
            WmsRecebimentoDetalhe,
            BaseReferences<
              _$AppDatabase,
              $WmsRecebimentoDetalhesTable,
              WmsRecebimentoDetalhe
            >,
          ),
          WmsRecebimentoDetalhe,
          PrefetchHooks Function()
        > {
  $$WmsRecebimentoDetalhesTableTableManager(
    _$AppDatabase db,
    $WmsRecebimentoDetalhesTable table,
  ) : super(
        TableManagerState(
          db: db,
          table: table,
          createFilteringComposer:
              () => $$WmsRecebimentoDetalhesTableFilterComposer(
                $db: db,
                $table: table,
              ),
          createOrderingComposer:
              () => $$WmsRecebimentoDetalhesTableOrderingComposer(
                $db: db,
                $table: table,
              ),
          createComputedFieldComposer:
              () => $$WmsRecebimentoDetalhesTableAnnotationComposer(
                $db: db,
                $table: table,
              ),
          updateCompanionCallback:
              ({
                Value<int?> id = const Value.absent(),
                Value<int?> idWmsRecebimentoCabecalho = const Value.absent(),
                Value<int?> idProduto = const Value.absent(),
                Value<int?> quantidadeVolume = const Value.absent(),
                Value<int?> quantidadeItemPorVolume = const Value.absent(),
                Value<int?> quantidadeRecebida = const Value.absent(),
                Value<String?> destino = const Value.absent(),
              }) => WmsRecebimentoDetalhesCompanion(
                id: id,
                idWmsRecebimentoCabecalho: idWmsRecebimentoCabecalho,
                idProduto: idProduto,
                quantidadeVolume: quantidadeVolume,
                quantidadeItemPorVolume: quantidadeItemPorVolume,
                quantidadeRecebida: quantidadeRecebida,
                destino: destino,
              ),
          createCompanionCallback:
              ({
                Value<int?> id = const Value.absent(),
                Value<int?> idWmsRecebimentoCabecalho = const Value.absent(),
                Value<int?> idProduto = const Value.absent(),
                Value<int?> quantidadeVolume = const Value.absent(),
                Value<int?> quantidadeItemPorVolume = const Value.absent(),
                Value<int?> quantidadeRecebida = const Value.absent(),
                Value<String?> destino = const Value.absent(),
              }) => WmsRecebimentoDetalhesCompanion.insert(
                id: id,
                idWmsRecebimentoCabecalho: idWmsRecebimentoCabecalho,
                idProduto: idProduto,
                quantidadeVolume: quantidadeVolume,
                quantidadeItemPorVolume: quantidadeItemPorVolume,
                quantidadeRecebida: quantidadeRecebida,
                destino: destino,
              ),
          withReferenceMapper:
              (p0) =>
                  p0
                      .map(
                        (e) => (
                          e.readTable(table),
                          BaseReferences(db, table, e),
                        ),
                      )
                      .toList(),
          prefetchHooksCallback: null,
        ),
      );
}

typedef $$WmsRecebimentoDetalhesTableProcessedTableManager =
    ProcessedTableManager<
      _$AppDatabase,
      $WmsRecebimentoDetalhesTable,
      WmsRecebimentoDetalhe,
      $$WmsRecebimentoDetalhesTableFilterComposer,
      $$WmsRecebimentoDetalhesTableOrderingComposer,
      $$WmsRecebimentoDetalhesTableAnnotationComposer,
      $$WmsRecebimentoDetalhesTableCreateCompanionBuilder,
      $$WmsRecebimentoDetalhesTableUpdateCompanionBuilder,
      (
        WmsRecebimentoDetalhe,
        BaseReferences<
          _$AppDatabase,
          $WmsRecebimentoDetalhesTable,
          WmsRecebimentoDetalhe
        >,
      ),
      WmsRecebimentoDetalhe,
      PrefetchHooks Function()
    >;
typedef $$WmsCaixasTableCreateCompanionBuilder =
    WmsCaixasCompanion Function({
      Value<int?> id,
      Value<int?> idWmsEstante,
      Value<String?> codigo,
      Value<int?> altura,
      Value<int?> largura,
      Value<int?> profundidade,
    });
typedef $$WmsCaixasTableUpdateCompanionBuilder =
    WmsCaixasCompanion Function({
      Value<int?> id,
      Value<int?> idWmsEstante,
      Value<String?> codigo,
      Value<int?> altura,
      Value<int?> largura,
      Value<int?> profundidade,
    });

class $$WmsCaixasTableFilterComposer
    extends Composer<_$AppDatabase, $WmsCaixasTable> {
  $$WmsCaixasTableFilterComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnFilters<int> get id => $composableBuilder(
    column: $table.id,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<int> get idWmsEstante => $composableBuilder(
    column: $table.idWmsEstante,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get codigo => $composableBuilder(
    column: $table.codigo,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<int> get altura => $composableBuilder(
    column: $table.altura,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<int> get largura => $composableBuilder(
    column: $table.largura,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<int> get profundidade => $composableBuilder(
    column: $table.profundidade,
    builder: (column) => ColumnFilters(column),
  );
}

class $$WmsCaixasTableOrderingComposer
    extends Composer<_$AppDatabase, $WmsCaixasTable> {
  $$WmsCaixasTableOrderingComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnOrderings<int> get id => $composableBuilder(
    column: $table.id,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<int> get idWmsEstante => $composableBuilder(
    column: $table.idWmsEstante,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get codigo => $composableBuilder(
    column: $table.codigo,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<int> get altura => $composableBuilder(
    column: $table.altura,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<int> get largura => $composableBuilder(
    column: $table.largura,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<int> get profundidade => $composableBuilder(
    column: $table.profundidade,
    builder: (column) => ColumnOrderings(column),
  );
}

class $$WmsCaixasTableAnnotationComposer
    extends Composer<_$AppDatabase, $WmsCaixasTable> {
  $$WmsCaixasTableAnnotationComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  GeneratedColumn<int> get id =>
      $composableBuilder(column: $table.id, builder: (column) => column);

  GeneratedColumn<int> get idWmsEstante => $composableBuilder(
    column: $table.idWmsEstante,
    builder: (column) => column,
  );

  GeneratedColumn<String> get codigo =>
      $composableBuilder(column: $table.codigo, builder: (column) => column);

  GeneratedColumn<int> get altura =>
      $composableBuilder(column: $table.altura, builder: (column) => column);

  GeneratedColumn<int> get largura =>
      $composableBuilder(column: $table.largura, builder: (column) => column);

  GeneratedColumn<int> get profundidade => $composableBuilder(
    column: $table.profundidade,
    builder: (column) => column,
  );
}

class $$WmsCaixasTableTableManager
    extends
        RootTableManager<
          _$AppDatabase,
          $WmsCaixasTable,
          WmsCaixa,
          $$WmsCaixasTableFilterComposer,
          $$WmsCaixasTableOrderingComposer,
          $$WmsCaixasTableAnnotationComposer,
          $$WmsCaixasTableCreateCompanionBuilder,
          $$WmsCaixasTableUpdateCompanionBuilder,
          (WmsCaixa, BaseReferences<_$AppDatabase, $WmsCaixasTable, WmsCaixa>),
          WmsCaixa,
          PrefetchHooks Function()
        > {
  $$WmsCaixasTableTableManager(_$AppDatabase db, $WmsCaixasTable table)
    : super(
        TableManagerState(
          db: db,
          table: table,
          createFilteringComposer:
              () => $$WmsCaixasTableFilterComposer($db: db, $table: table),
          createOrderingComposer:
              () => $$WmsCaixasTableOrderingComposer($db: db, $table: table),
          createComputedFieldComposer:
              () => $$WmsCaixasTableAnnotationComposer($db: db, $table: table),
          updateCompanionCallback:
              ({
                Value<int?> id = const Value.absent(),
                Value<int?> idWmsEstante = const Value.absent(),
                Value<String?> codigo = const Value.absent(),
                Value<int?> altura = const Value.absent(),
                Value<int?> largura = const Value.absent(),
                Value<int?> profundidade = const Value.absent(),
              }) => WmsCaixasCompanion(
                id: id,
                idWmsEstante: idWmsEstante,
                codigo: codigo,
                altura: altura,
                largura: largura,
                profundidade: profundidade,
              ),
          createCompanionCallback:
              ({
                Value<int?> id = const Value.absent(),
                Value<int?> idWmsEstante = const Value.absent(),
                Value<String?> codigo = const Value.absent(),
                Value<int?> altura = const Value.absent(),
                Value<int?> largura = const Value.absent(),
                Value<int?> profundidade = const Value.absent(),
              }) => WmsCaixasCompanion.insert(
                id: id,
                idWmsEstante: idWmsEstante,
                codigo: codigo,
                altura: altura,
                largura: largura,
                profundidade: profundidade,
              ),
          withReferenceMapper:
              (p0) =>
                  p0
                      .map(
                        (e) => (
                          e.readTable(table),
                          BaseReferences(db, table, e),
                        ),
                      )
                      .toList(),
          prefetchHooksCallback: null,
        ),
      );
}

typedef $$WmsCaixasTableProcessedTableManager =
    ProcessedTableManager<
      _$AppDatabase,
      $WmsCaixasTable,
      WmsCaixa,
      $$WmsCaixasTableFilterComposer,
      $$WmsCaixasTableOrderingComposer,
      $$WmsCaixasTableAnnotationComposer,
      $$WmsCaixasTableCreateCompanionBuilder,
      $$WmsCaixasTableUpdateCompanionBuilder,
      (WmsCaixa, BaseReferences<_$AppDatabase, $WmsCaixasTable, WmsCaixa>),
      WmsCaixa,
      PrefetchHooks Function()
    >;
typedef $$WmsOrdemSeparacaoDetsTableCreateCompanionBuilder =
    WmsOrdemSeparacaoDetsCompanion Function({
      Value<int?> id,
      Value<int?> idWmsOrdemSeparacaoCab,
      Value<int?> idProduto,
      Value<int?> quantidade,
    });
typedef $$WmsOrdemSeparacaoDetsTableUpdateCompanionBuilder =
    WmsOrdemSeparacaoDetsCompanion Function({
      Value<int?> id,
      Value<int?> idWmsOrdemSeparacaoCab,
      Value<int?> idProduto,
      Value<int?> quantidade,
    });

class $$WmsOrdemSeparacaoDetsTableFilterComposer
    extends Composer<_$AppDatabase, $WmsOrdemSeparacaoDetsTable> {
  $$WmsOrdemSeparacaoDetsTableFilterComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnFilters<int> get id => $composableBuilder(
    column: $table.id,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<int> get idWmsOrdemSeparacaoCab => $composableBuilder(
    column: $table.idWmsOrdemSeparacaoCab,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<int> get idProduto => $composableBuilder(
    column: $table.idProduto,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<int> get quantidade => $composableBuilder(
    column: $table.quantidade,
    builder: (column) => ColumnFilters(column),
  );
}

class $$WmsOrdemSeparacaoDetsTableOrderingComposer
    extends Composer<_$AppDatabase, $WmsOrdemSeparacaoDetsTable> {
  $$WmsOrdemSeparacaoDetsTableOrderingComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnOrderings<int> get id => $composableBuilder(
    column: $table.id,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<int> get idWmsOrdemSeparacaoCab => $composableBuilder(
    column: $table.idWmsOrdemSeparacaoCab,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<int> get idProduto => $composableBuilder(
    column: $table.idProduto,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<int> get quantidade => $composableBuilder(
    column: $table.quantidade,
    builder: (column) => ColumnOrderings(column),
  );
}

class $$WmsOrdemSeparacaoDetsTableAnnotationComposer
    extends Composer<_$AppDatabase, $WmsOrdemSeparacaoDetsTable> {
  $$WmsOrdemSeparacaoDetsTableAnnotationComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  GeneratedColumn<int> get id =>
      $composableBuilder(column: $table.id, builder: (column) => column);

  GeneratedColumn<int> get idWmsOrdemSeparacaoCab => $composableBuilder(
    column: $table.idWmsOrdemSeparacaoCab,
    builder: (column) => column,
  );

  GeneratedColumn<int> get idProduto =>
      $composableBuilder(column: $table.idProduto, builder: (column) => column);

  GeneratedColumn<int> get quantidade => $composableBuilder(
    column: $table.quantidade,
    builder: (column) => column,
  );
}

class $$WmsOrdemSeparacaoDetsTableTableManager
    extends
        RootTableManager<
          _$AppDatabase,
          $WmsOrdemSeparacaoDetsTable,
          WmsOrdemSeparacaoDet,
          $$WmsOrdemSeparacaoDetsTableFilterComposer,
          $$WmsOrdemSeparacaoDetsTableOrderingComposer,
          $$WmsOrdemSeparacaoDetsTableAnnotationComposer,
          $$WmsOrdemSeparacaoDetsTableCreateCompanionBuilder,
          $$WmsOrdemSeparacaoDetsTableUpdateCompanionBuilder,
          (
            WmsOrdemSeparacaoDet,
            BaseReferences<
              _$AppDatabase,
              $WmsOrdemSeparacaoDetsTable,
              WmsOrdemSeparacaoDet
            >,
          ),
          WmsOrdemSeparacaoDet,
          PrefetchHooks Function()
        > {
  $$WmsOrdemSeparacaoDetsTableTableManager(
    _$AppDatabase db,
    $WmsOrdemSeparacaoDetsTable table,
  ) : super(
        TableManagerState(
          db: db,
          table: table,
          createFilteringComposer:
              () => $$WmsOrdemSeparacaoDetsTableFilterComposer(
                $db: db,
                $table: table,
              ),
          createOrderingComposer:
              () => $$WmsOrdemSeparacaoDetsTableOrderingComposer(
                $db: db,
                $table: table,
              ),
          createComputedFieldComposer:
              () => $$WmsOrdemSeparacaoDetsTableAnnotationComposer(
                $db: db,
                $table: table,
              ),
          updateCompanionCallback:
              ({
                Value<int?> id = const Value.absent(),
                Value<int?> idWmsOrdemSeparacaoCab = const Value.absent(),
                Value<int?> idProduto = const Value.absent(),
                Value<int?> quantidade = const Value.absent(),
              }) => WmsOrdemSeparacaoDetsCompanion(
                id: id,
                idWmsOrdemSeparacaoCab: idWmsOrdemSeparacaoCab,
                idProduto: idProduto,
                quantidade: quantidade,
              ),
          createCompanionCallback:
              ({
                Value<int?> id = const Value.absent(),
                Value<int?> idWmsOrdemSeparacaoCab = const Value.absent(),
                Value<int?> idProduto = const Value.absent(),
                Value<int?> quantidade = const Value.absent(),
              }) => WmsOrdemSeparacaoDetsCompanion.insert(
                id: id,
                idWmsOrdemSeparacaoCab: idWmsOrdemSeparacaoCab,
                idProduto: idProduto,
                quantidade: quantidade,
              ),
          withReferenceMapper:
              (p0) =>
                  p0
                      .map(
                        (e) => (
                          e.readTable(table),
                          BaseReferences(db, table, e),
                        ),
                      )
                      .toList(),
          prefetchHooksCallback: null,
        ),
      );
}

typedef $$WmsOrdemSeparacaoDetsTableProcessedTableManager =
    ProcessedTableManager<
      _$AppDatabase,
      $WmsOrdemSeparacaoDetsTable,
      WmsOrdemSeparacaoDet,
      $$WmsOrdemSeparacaoDetsTableFilterComposer,
      $$WmsOrdemSeparacaoDetsTableOrderingComposer,
      $$WmsOrdemSeparacaoDetsTableAnnotationComposer,
      $$WmsOrdemSeparacaoDetsTableCreateCompanionBuilder,
      $$WmsOrdemSeparacaoDetsTableUpdateCompanionBuilder,
      (
        WmsOrdemSeparacaoDet,
        BaseReferences<
          _$AppDatabase,
          $WmsOrdemSeparacaoDetsTable,
          WmsOrdemSeparacaoDet
        >,
      ),
      WmsOrdemSeparacaoDet,
      PrefetchHooks Function()
    >;
typedef $$WmsRecebimentoCabecalhosTableCreateCompanionBuilder =
    WmsRecebimentoCabecalhosCompanion Function({
      Value<int?> id,
      Value<int?> idWmsAgendamento,
      Value<DateTime?> dataRecebimento,
      Value<String?> horaInicio,
      Value<String?> horaFim,
      Value<int?> volumeRecebido,
      Value<double?> pesoRecebido,
      Value<String?> inconsistencia,
      Value<String?> codigoRecebimento,
      Value<String?> observacao,
    });
typedef $$WmsRecebimentoCabecalhosTableUpdateCompanionBuilder =
    WmsRecebimentoCabecalhosCompanion Function({
      Value<int?> id,
      Value<int?> idWmsAgendamento,
      Value<DateTime?> dataRecebimento,
      Value<String?> horaInicio,
      Value<String?> horaFim,
      Value<int?> volumeRecebido,
      Value<double?> pesoRecebido,
      Value<String?> inconsistencia,
      Value<String?> codigoRecebimento,
      Value<String?> observacao,
    });

class $$WmsRecebimentoCabecalhosTableFilterComposer
    extends Composer<_$AppDatabase, $WmsRecebimentoCabecalhosTable> {
  $$WmsRecebimentoCabecalhosTableFilterComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnFilters<int> get id => $composableBuilder(
    column: $table.id,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<int> get idWmsAgendamento => $composableBuilder(
    column: $table.idWmsAgendamento,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<DateTime> get dataRecebimento => $composableBuilder(
    column: $table.dataRecebimento,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get horaInicio => $composableBuilder(
    column: $table.horaInicio,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get horaFim => $composableBuilder(
    column: $table.horaFim,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<int> get volumeRecebido => $composableBuilder(
    column: $table.volumeRecebido,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<double> get pesoRecebido => $composableBuilder(
    column: $table.pesoRecebido,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get inconsistencia => $composableBuilder(
    column: $table.inconsistencia,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get codigoRecebimento => $composableBuilder(
    column: $table.codigoRecebimento,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get observacao => $composableBuilder(
    column: $table.observacao,
    builder: (column) => ColumnFilters(column),
  );
}

class $$WmsRecebimentoCabecalhosTableOrderingComposer
    extends Composer<_$AppDatabase, $WmsRecebimentoCabecalhosTable> {
  $$WmsRecebimentoCabecalhosTableOrderingComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnOrderings<int> get id => $composableBuilder(
    column: $table.id,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<int> get idWmsAgendamento => $composableBuilder(
    column: $table.idWmsAgendamento,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<DateTime> get dataRecebimento => $composableBuilder(
    column: $table.dataRecebimento,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get horaInicio => $composableBuilder(
    column: $table.horaInicio,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get horaFim => $composableBuilder(
    column: $table.horaFim,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<int> get volumeRecebido => $composableBuilder(
    column: $table.volumeRecebido,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<double> get pesoRecebido => $composableBuilder(
    column: $table.pesoRecebido,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get inconsistencia => $composableBuilder(
    column: $table.inconsistencia,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get codigoRecebimento => $composableBuilder(
    column: $table.codigoRecebimento,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get observacao => $composableBuilder(
    column: $table.observacao,
    builder: (column) => ColumnOrderings(column),
  );
}

class $$WmsRecebimentoCabecalhosTableAnnotationComposer
    extends Composer<_$AppDatabase, $WmsRecebimentoCabecalhosTable> {
  $$WmsRecebimentoCabecalhosTableAnnotationComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  GeneratedColumn<int> get id =>
      $composableBuilder(column: $table.id, builder: (column) => column);

  GeneratedColumn<int> get idWmsAgendamento => $composableBuilder(
    column: $table.idWmsAgendamento,
    builder: (column) => column,
  );

  GeneratedColumn<DateTime> get dataRecebimento => $composableBuilder(
    column: $table.dataRecebimento,
    builder: (column) => column,
  );

  GeneratedColumn<String> get horaInicio => $composableBuilder(
    column: $table.horaInicio,
    builder: (column) => column,
  );

  GeneratedColumn<String> get horaFim =>
      $composableBuilder(column: $table.horaFim, builder: (column) => column);

  GeneratedColumn<int> get volumeRecebido => $composableBuilder(
    column: $table.volumeRecebido,
    builder: (column) => column,
  );

  GeneratedColumn<double> get pesoRecebido => $composableBuilder(
    column: $table.pesoRecebido,
    builder: (column) => column,
  );

  GeneratedColumn<String> get inconsistencia => $composableBuilder(
    column: $table.inconsistencia,
    builder: (column) => column,
  );

  GeneratedColumn<String> get codigoRecebimento => $composableBuilder(
    column: $table.codigoRecebimento,
    builder: (column) => column,
  );

  GeneratedColumn<String> get observacao => $composableBuilder(
    column: $table.observacao,
    builder: (column) => column,
  );
}

class $$WmsRecebimentoCabecalhosTableTableManager
    extends
        RootTableManager<
          _$AppDatabase,
          $WmsRecebimentoCabecalhosTable,
          WmsRecebimentoCabecalho,
          $$WmsRecebimentoCabecalhosTableFilterComposer,
          $$WmsRecebimentoCabecalhosTableOrderingComposer,
          $$WmsRecebimentoCabecalhosTableAnnotationComposer,
          $$WmsRecebimentoCabecalhosTableCreateCompanionBuilder,
          $$WmsRecebimentoCabecalhosTableUpdateCompanionBuilder,
          (
            WmsRecebimentoCabecalho,
            BaseReferences<
              _$AppDatabase,
              $WmsRecebimentoCabecalhosTable,
              WmsRecebimentoCabecalho
            >,
          ),
          WmsRecebimentoCabecalho,
          PrefetchHooks Function()
        > {
  $$WmsRecebimentoCabecalhosTableTableManager(
    _$AppDatabase db,
    $WmsRecebimentoCabecalhosTable table,
  ) : super(
        TableManagerState(
          db: db,
          table: table,
          createFilteringComposer:
              () => $$WmsRecebimentoCabecalhosTableFilterComposer(
                $db: db,
                $table: table,
              ),
          createOrderingComposer:
              () => $$WmsRecebimentoCabecalhosTableOrderingComposer(
                $db: db,
                $table: table,
              ),
          createComputedFieldComposer:
              () => $$WmsRecebimentoCabecalhosTableAnnotationComposer(
                $db: db,
                $table: table,
              ),
          updateCompanionCallback:
              ({
                Value<int?> id = const Value.absent(),
                Value<int?> idWmsAgendamento = const Value.absent(),
                Value<DateTime?> dataRecebimento = const Value.absent(),
                Value<String?> horaInicio = const Value.absent(),
                Value<String?> horaFim = const Value.absent(),
                Value<int?> volumeRecebido = const Value.absent(),
                Value<double?> pesoRecebido = const Value.absent(),
                Value<String?> inconsistencia = const Value.absent(),
                Value<String?> codigoRecebimento = const Value.absent(),
                Value<String?> observacao = const Value.absent(),
              }) => WmsRecebimentoCabecalhosCompanion(
                id: id,
                idWmsAgendamento: idWmsAgendamento,
                dataRecebimento: dataRecebimento,
                horaInicio: horaInicio,
                horaFim: horaFim,
                volumeRecebido: volumeRecebido,
                pesoRecebido: pesoRecebido,
                inconsistencia: inconsistencia,
                codigoRecebimento: codigoRecebimento,
                observacao: observacao,
              ),
          createCompanionCallback:
              ({
                Value<int?> id = const Value.absent(),
                Value<int?> idWmsAgendamento = const Value.absent(),
                Value<DateTime?> dataRecebimento = const Value.absent(),
                Value<String?> horaInicio = const Value.absent(),
                Value<String?> horaFim = const Value.absent(),
                Value<int?> volumeRecebido = const Value.absent(),
                Value<double?> pesoRecebido = const Value.absent(),
                Value<String?> inconsistencia = const Value.absent(),
                Value<String?> codigoRecebimento = const Value.absent(),
                Value<String?> observacao = const Value.absent(),
              }) => WmsRecebimentoCabecalhosCompanion.insert(
                id: id,
                idWmsAgendamento: idWmsAgendamento,
                dataRecebimento: dataRecebimento,
                horaInicio: horaInicio,
                horaFim: horaFim,
                volumeRecebido: volumeRecebido,
                pesoRecebido: pesoRecebido,
                inconsistencia: inconsistencia,
                codigoRecebimento: codigoRecebimento,
                observacao: observacao,
              ),
          withReferenceMapper:
              (p0) =>
                  p0
                      .map(
                        (e) => (
                          e.readTable(table),
                          BaseReferences(db, table, e),
                        ),
                      )
                      .toList(),
          prefetchHooksCallback: null,
        ),
      );
}

typedef $$WmsRecebimentoCabecalhosTableProcessedTableManager =
    ProcessedTableManager<
      _$AppDatabase,
      $WmsRecebimentoCabecalhosTable,
      WmsRecebimentoCabecalho,
      $$WmsRecebimentoCabecalhosTableFilterComposer,
      $$WmsRecebimentoCabecalhosTableOrderingComposer,
      $$WmsRecebimentoCabecalhosTableAnnotationComposer,
      $$WmsRecebimentoCabecalhosTableCreateCompanionBuilder,
      $$WmsRecebimentoCabecalhosTableUpdateCompanionBuilder,
      (
        WmsRecebimentoCabecalho,
        BaseReferences<
          _$AppDatabase,
          $WmsRecebimentoCabecalhosTable,
          WmsRecebimentoCabecalho
        >,
      ),
      WmsRecebimentoCabecalho,
      PrefetchHooks Function()
    >;
typedef $$WmsEstantesTableCreateCompanionBuilder =
    WmsEstantesCompanion Function({
      Value<int?> id,
      Value<int?> idWmsRua,
      Value<String?> codigo,
      Value<int?> quantidadeCaixa,
    });
typedef $$WmsEstantesTableUpdateCompanionBuilder =
    WmsEstantesCompanion Function({
      Value<int?> id,
      Value<int?> idWmsRua,
      Value<String?> codigo,
      Value<int?> quantidadeCaixa,
    });

class $$WmsEstantesTableFilterComposer
    extends Composer<_$AppDatabase, $WmsEstantesTable> {
  $$WmsEstantesTableFilterComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnFilters<int> get id => $composableBuilder(
    column: $table.id,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<int> get idWmsRua => $composableBuilder(
    column: $table.idWmsRua,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get codigo => $composableBuilder(
    column: $table.codigo,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<int> get quantidadeCaixa => $composableBuilder(
    column: $table.quantidadeCaixa,
    builder: (column) => ColumnFilters(column),
  );
}

class $$WmsEstantesTableOrderingComposer
    extends Composer<_$AppDatabase, $WmsEstantesTable> {
  $$WmsEstantesTableOrderingComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnOrderings<int> get id => $composableBuilder(
    column: $table.id,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<int> get idWmsRua => $composableBuilder(
    column: $table.idWmsRua,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get codigo => $composableBuilder(
    column: $table.codigo,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<int> get quantidadeCaixa => $composableBuilder(
    column: $table.quantidadeCaixa,
    builder: (column) => ColumnOrderings(column),
  );
}

class $$WmsEstantesTableAnnotationComposer
    extends Composer<_$AppDatabase, $WmsEstantesTable> {
  $$WmsEstantesTableAnnotationComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  GeneratedColumn<int> get id =>
      $composableBuilder(column: $table.id, builder: (column) => column);

  GeneratedColumn<int> get idWmsRua =>
      $composableBuilder(column: $table.idWmsRua, builder: (column) => column);

  GeneratedColumn<String> get codigo =>
      $composableBuilder(column: $table.codigo, builder: (column) => column);

  GeneratedColumn<int> get quantidadeCaixa => $composableBuilder(
    column: $table.quantidadeCaixa,
    builder: (column) => column,
  );
}

class $$WmsEstantesTableTableManager
    extends
        RootTableManager<
          _$AppDatabase,
          $WmsEstantesTable,
          WmsEstante,
          $$WmsEstantesTableFilterComposer,
          $$WmsEstantesTableOrderingComposer,
          $$WmsEstantesTableAnnotationComposer,
          $$WmsEstantesTableCreateCompanionBuilder,
          $$WmsEstantesTableUpdateCompanionBuilder,
          (
            WmsEstante,
            BaseReferences<_$AppDatabase, $WmsEstantesTable, WmsEstante>,
          ),
          WmsEstante,
          PrefetchHooks Function()
        > {
  $$WmsEstantesTableTableManager(_$AppDatabase db, $WmsEstantesTable table)
    : super(
        TableManagerState(
          db: db,
          table: table,
          createFilteringComposer:
              () => $$WmsEstantesTableFilterComposer($db: db, $table: table),
          createOrderingComposer:
              () => $$WmsEstantesTableOrderingComposer($db: db, $table: table),
          createComputedFieldComposer:
              () =>
                  $$WmsEstantesTableAnnotationComposer($db: db, $table: table),
          updateCompanionCallback:
              ({
                Value<int?> id = const Value.absent(),
                Value<int?> idWmsRua = const Value.absent(),
                Value<String?> codigo = const Value.absent(),
                Value<int?> quantidadeCaixa = const Value.absent(),
              }) => WmsEstantesCompanion(
                id: id,
                idWmsRua: idWmsRua,
                codigo: codigo,
                quantidadeCaixa: quantidadeCaixa,
              ),
          createCompanionCallback:
              ({
                Value<int?> id = const Value.absent(),
                Value<int?> idWmsRua = const Value.absent(),
                Value<String?> codigo = const Value.absent(),
                Value<int?> quantidadeCaixa = const Value.absent(),
              }) => WmsEstantesCompanion.insert(
                id: id,
                idWmsRua: idWmsRua,
                codigo: codigo,
                quantidadeCaixa: quantidadeCaixa,
              ),
          withReferenceMapper:
              (p0) =>
                  p0
                      .map(
                        (e) => (
                          e.readTable(table),
                          BaseReferences(db, table, e),
                        ),
                      )
                      .toList(),
          prefetchHooksCallback: null,
        ),
      );
}

typedef $$WmsEstantesTableProcessedTableManager =
    ProcessedTableManager<
      _$AppDatabase,
      $WmsEstantesTable,
      WmsEstante,
      $$WmsEstantesTableFilterComposer,
      $$WmsEstantesTableOrderingComposer,
      $$WmsEstantesTableAnnotationComposer,
      $$WmsEstantesTableCreateCompanionBuilder,
      $$WmsEstantesTableUpdateCompanionBuilder,
      (
        WmsEstante,
        BaseReferences<_$AppDatabase, $WmsEstantesTable, WmsEstante>,
      ),
      WmsEstante,
      PrefetchHooks Function()
    >;
typedef $$WmsOrdemSeparacaoCabsTableCreateCompanionBuilder =
    WmsOrdemSeparacaoCabsCompanion Function({
      Value<int?> id,
      Value<String?> origem,
      Value<DateTime?> dataSolicitacao,
      Value<DateTime?> dataLimite,
      Value<String?> codigoSeparacao,
    });
typedef $$WmsOrdemSeparacaoCabsTableUpdateCompanionBuilder =
    WmsOrdemSeparacaoCabsCompanion Function({
      Value<int?> id,
      Value<String?> origem,
      Value<DateTime?> dataSolicitacao,
      Value<DateTime?> dataLimite,
      Value<String?> codigoSeparacao,
    });

class $$WmsOrdemSeparacaoCabsTableFilterComposer
    extends Composer<_$AppDatabase, $WmsOrdemSeparacaoCabsTable> {
  $$WmsOrdemSeparacaoCabsTableFilterComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnFilters<int> get id => $composableBuilder(
    column: $table.id,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get origem => $composableBuilder(
    column: $table.origem,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<DateTime> get dataSolicitacao => $composableBuilder(
    column: $table.dataSolicitacao,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<DateTime> get dataLimite => $composableBuilder(
    column: $table.dataLimite,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get codigoSeparacao => $composableBuilder(
    column: $table.codigoSeparacao,
    builder: (column) => ColumnFilters(column),
  );
}

class $$WmsOrdemSeparacaoCabsTableOrderingComposer
    extends Composer<_$AppDatabase, $WmsOrdemSeparacaoCabsTable> {
  $$WmsOrdemSeparacaoCabsTableOrderingComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnOrderings<int> get id => $composableBuilder(
    column: $table.id,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get origem => $composableBuilder(
    column: $table.origem,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<DateTime> get dataSolicitacao => $composableBuilder(
    column: $table.dataSolicitacao,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<DateTime> get dataLimite => $composableBuilder(
    column: $table.dataLimite,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get codigoSeparacao => $composableBuilder(
    column: $table.codigoSeparacao,
    builder: (column) => ColumnOrderings(column),
  );
}

class $$WmsOrdemSeparacaoCabsTableAnnotationComposer
    extends Composer<_$AppDatabase, $WmsOrdemSeparacaoCabsTable> {
  $$WmsOrdemSeparacaoCabsTableAnnotationComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  GeneratedColumn<int> get id =>
      $composableBuilder(column: $table.id, builder: (column) => column);

  GeneratedColumn<String> get origem =>
      $composableBuilder(column: $table.origem, builder: (column) => column);

  GeneratedColumn<DateTime> get dataSolicitacao => $composableBuilder(
    column: $table.dataSolicitacao,
    builder: (column) => column,
  );

  GeneratedColumn<DateTime> get dataLimite => $composableBuilder(
    column: $table.dataLimite,
    builder: (column) => column,
  );

  GeneratedColumn<String> get codigoSeparacao => $composableBuilder(
    column: $table.codigoSeparacao,
    builder: (column) => column,
  );
}

class $$WmsOrdemSeparacaoCabsTableTableManager
    extends
        RootTableManager<
          _$AppDatabase,
          $WmsOrdemSeparacaoCabsTable,
          WmsOrdemSeparacaoCab,
          $$WmsOrdemSeparacaoCabsTableFilterComposer,
          $$WmsOrdemSeparacaoCabsTableOrderingComposer,
          $$WmsOrdemSeparacaoCabsTableAnnotationComposer,
          $$WmsOrdemSeparacaoCabsTableCreateCompanionBuilder,
          $$WmsOrdemSeparacaoCabsTableUpdateCompanionBuilder,
          (
            WmsOrdemSeparacaoCab,
            BaseReferences<
              _$AppDatabase,
              $WmsOrdemSeparacaoCabsTable,
              WmsOrdemSeparacaoCab
            >,
          ),
          WmsOrdemSeparacaoCab,
          PrefetchHooks Function()
        > {
  $$WmsOrdemSeparacaoCabsTableTableManager(
    _$AppDatabase db,
    $WmsOrdemSeparacaoCabsTable table,
  ) : super(
        TableManagerState(
          db: db,
          table: table,
          createFilteringComposer:
              () => $$WmsOrdemSeparacaoCabsTableFilterComposer(
                $db: db,
                $table: table,
              ),
          createOrderingComposer:
              () => $$WmsOrdemSeparacaoCabsTableOrderingComposer(
                $db: db,
                $table: table,
              ),
          createComputedFieldComposer:
              () => $$WmsOrdemSeparacaoCabsTableAnnotationComposer(
                $db: db,
                $table: table,
              ),
          updateCompanionCallback:
              ({
                Value<int?> id = const Value.absent(),
                Value<String?> origem = const Value.absent(),
                Value<DateTime?> dataSolicitacao = const Value.absent(),
                Value<DateTime?> dataLimite = const Value.absent(),
                Value<String?> codigoSeparacao = const Value.absent(),
              }) => WmsOrdemSeparacaoCabsCompanion(
                id: id,
                origem: origem,
                dataSolicitacao: dataSolicitacao,
                dataLimite: dataLimite,
                codigoSeparacao: codigoSeparacao,
              ),
          createCompanionCallback:
              ({
                Value<int?> id = const Value.absent(),
                Value<String?> origem = const Value.absent(),
                Value<DateTime?> dataSolicitacao = const Value.absent(),
                Value<DateTime?> dataLimite = const Value.absent(),
                Value<String?> codigoSeparacao = const Value.absent(),
              }) => WmsOrdemSeparacaoCabsCompanion.insert(
                id: id,
                origem: origem,
                dataSolicitacao: dataSolicitacao,
                dataLimite: dataLimite,
                codigoSeparacao: codigoSeparacao,
              ),
          withReferenceMapper:
              (p0) =>
                  p0
                      .map(
                        (e) => (
                          e.readTable(table),
                          BaseReferences(db, table, e),
                        ),
                      )
                      .toList(),
          prefetchHooksCallback: null,
        ),
      );
}

typedef $$WmsOrdemSeparacaoCabsTableProcessedTableManager =
    ProcessedTableManager<
      _$AppDatabase,
      $WmsOrdemSeparacaoCabsTable,
      WmsOrdemSeparacaoCab,
      $$WmsOrdemSeparacaoCabsTableFilterComposer,
      $$WmsOrdemSeparacaoCabsTableOrderingComposer,
      $$WmsOrdemSeparacaoCabsTableAnnotationComposer,
      $$WmsOrdemSeparacaoCabsTableCreateCompanionBuilder,
      $$WmsOrdemSeparacaoCabsTableUpdateCompanionBuilder,
      (
        WmsOrdemSeparacaoCab,
        BaseReferences<
          _$AppDatabase,
          $WmsOrdemSeparacaoCabsTable,
          WmsOrdemSeparacaoCab
        >,
      ),
      WmsOrdemSeparacaoCab,
      PrefetchHooks Function()
    >;
typedef $$ProdutosTableCreateCompanionBuilder =
    ProdutosCompanion Function({
      Value<int?> id,
      Value<int?> idTributIcmsCustomCab,
      Value<int?> idTributGrupoTributario,
      Value<String?> nome,
      Value<String?> descricao,
      Value<String?> gtin,
      Value<String?> codigoInterno,
      Value<double?> valorCompra,
      Value<double?> valorVenda,
      Value<String?> codigoNcm,
      Value<double?> estoqueMinimo,
      Value<double?> estoqueMaximo,
      Value<double?> quantidadeEstoque,
      Value<DateTime?> dataCadastro,
    });
typedef $$ProdutosTableUpdateCompanionBuilder =
    ProdutosCompanion Function({
      Value<int?> id,
      Value<int?> idTributIcmsCustomCab,
      Value<int?> idTributGrupoTributario,
      Value<String?> nome,
      Value<String?> descricao,
      Value<String?> gtin,
      Value<String?> codigoInterno,
      Value<double?> valorCompra,
      Value<double?> valorVenda,
      Value<String?> codigoNcm,
      Value<double?> estoqueMinimo,
      Value<double?> estoqueMaximo,
      Value<double?> quantidadeEstoque,
      Value<DateTime?> dataCadastro,
    });

class $$ProdutosTableFilterComposer
    extends Composer<_$AppDatabase, $ProdutosTable> {
  $$ProdutosTableFilterComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnFilters<int> get id => $composableBuilder(
    column: $table.id,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<int> get idTributIcmsCustomCab => $composableBuilder(
    column: $table.idTributIcmsCustomCab,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<int> get idTributGrupoTributario => $composableBuilder(
    column: $table.idTributGrupoTributario,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get nome => $composableBuilder(
    column: $table.nome,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get descricao => $composableBuilder(
    column: $table.descricao,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get gtin => $composableBuilder(
    column: $table.gtin,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get codigoInterno => $composableBuilder(
    column: $table.codigoInterno,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<double> get valorCompra => $composableBuilder(
    column: $table.valorCompra,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<double> get valorVenda => $composableBuilder(
    column: $table.valorVenda,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get codigoNcm => $composableBuilder(
    column: $table.codigoNcm,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<double> get estoqueMinimo => $composableBuilder(
    column: $table.estoqueMinimo,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<double> get estoqueMaximo => $composableBuilder(
    column: $table.estoqueMaximo,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<double> get quantidadeEstoque => $composableBuilder(
    column: $table.quantidadeEstoque,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<DateTime> get dataCadastro => $composableBuilder(
    column: $table.dataCadastro,
    builder: (column) => ColumnFilters(column),
  );
}

class $$ProdutosTableOrderingComposer
    extends Composer<_$AppDatabase, $ProdutosTable> {
  $$ProdutosTableOrderingComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnOrderings<int> get id => $composableBuilder(
    column: $table.id,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<int> get idTributIcmsCustomCab => $composableBuilder(
    column: $table.idTributIcmsCustomCab,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<int> get idTributGrupoTributario => $composableBuilder(
    column: $table.idTributGrupoTributario,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get nome => $composableBuilder(
    column: $table.nome,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get descricao => $composableBuilder(
    column: $table.descricao,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get gtin => $composableBuilder(
    column: $table.gtin,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get codigoInterno => $composableBuilder(
    column: $table.codigoInterno,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<double> get valorCompra => $composableBuilder(
    column: $table.valorCompra,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<double> get valorVenda => $composableBuilder(
    column: $table.valorVenda,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get codigoNcm => $composableBuilder(
    column: $table.codigoNcm,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<double> get estoqueMinimo => $composableBuilder(
    column: $table.estoqueMinimo,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<double> get estoqueMaximo => $composableBuilder(
    column: $table.estoqueMaximo,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<double> get quantidadeEstoque => $composableBuilder(
    column: $table.quantidadeEstoque,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<DateTime> get dataCadastro => $composableBuilder(
    column: $table.dataCadastro,
    builder: (column) => ColumnOrderings(column),
  );
}

class $$ProdutosTableAnnotationComposer
    extends Composer<_$AppDatabase, $ProdutosTable> {
  $$ProdutosTableAnnotationComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  GeneratedColumn<int> get id =>
      $composableBuilder(column: $table.id, builder: (column) => column);

  GeneratedColumn<int> get idTributIcmsCustomCab => $composableBuilder(
    column: $table.idTributIcmsCustomCab,
    builder: (column) => column,
  );

  GeneratedColumn<int> get idTributGrupoTributario => $composableBuilder(
    column: $table.idTributGrupoTributario,
    builder: (column) => column,
  );

  GeneratedColumn<String> get nome =>
      $composableBuilder(column: $table.nome, builder: (column) => column);

  GeneratedColumn<String> get descricao =>
      $composableBuilder(column: $table.descricao, builder: (column) => column);

  GeneratedColumn<String> get gtin =>
      $composableBuilder(column: $table.gtin, builder: (column) => column);

  GeneratedColumn<String> get codigoInterno => $composableBuilder(
    column: $table.codigoInterno,
    builder: (column) => column,
  );

  GeneratedColumn<double> get valorCompra => $composableBuilder(
    column: $table.valorCompra,
    builder: (column) => column,
  );

  GeneratedColumn<double> get valorVenda => $composableBuilder(
    column: $table.valorVenda,
    builder: (column) => column,
  );

  GeneratedColumn<String> get codigoNcm =>
      $composableBuilder(column: $table.codigoNcm, builder: (column) => column);

  GeneratedColumn<double> get estoqueMinimo => $composableBuilder(
    column: $table.estoqueMinimo,
    builder: (column) => column,
  );

  GeneratedColumn<double> get estoqueMaximo => $composableBuilder(
    column: $table.estoqueMaximo,
    builder: (column) => column,
  );

  GeneratedColumn<double> get quantidadeEstoque => $composableBuilder(
    column: $table.quantidadeEstoque,
    builder: (column) => column,
  );

  GeneratedColumn<DateTime> get dataCadastro => $composableBuilder(
    column: $table.dataCadastro,
    builder: (column) => column,
  );
}

class $$ProdutosTableTableManager
    extends
        RootTableManager<
          _$AppDatabase,
          $ProdutosTable,
          Produto,
          $$ProdutosTableFilterComposer,
          $$ProdutosTableOrderingComposer,
          $$ProdutosTableAnnotationComposer,
          $$ProdutosTableCreateCompanionBuilder,
          $$ProdutosTableUpdateCompanionBuilder,
          (Produto, BaseReferences<_$AppDatabase, $ProdutosTable, Produto>),
          Produto,
          PrefetchHooks Function()
        > {
  $$ProdutosTableTableManager(_$AppDatabase db, $ProdutosTable table)
    : super(
        TableManagerState(
          db: db,
          table: table,
          createFilteringComposer:
              () => $$ProdutosTableFilterComposer($db: db, $table: table),
          createOrderingComposer:
              () => $$ProdutosTableOrderingComposer($db: db, $table: table),
          createComputedFieldComposer:
              () => $$ProdutosTableAnnotationComposer($db: db, $table: table),
          updateCompanionCallback:
              ({
                Value<int?> id = const Value.absent(),
                Value<int?> idTributIcmsCustomCab = const Value.absent(),
                Value<int?> idTributGrupoTributario = const Value.absent(),
                Value<String?> nome = const Value.absent(),
                Value<String?> descricao = const Value.absent(),
                Value<String?> gtin = const Value.absent(),
                Value<String?> codigoInterno = const Value.absent(),
                Value<double?> valorCompra = const Value.absent(),
                Value<double?> valorVenda = const Value.absent(),
                Value<String?> codigoNcm = const Value.absent(),
                Value<double?> estoqueMinimo = const Value.absent(),
                Value<double?> estoqueMaximo = const Value.absent(),
                Value<double?> quantidadeEstoque = const Value.absent(),
                Value<DateTime?> dataCadastro = const Value.absent(),
              }) => ProdutosCompanion(
                id: id,
                idTributIcmsCustomCab: idTributIcmsCustomCab,
                idTributGrupoTributario: idTributGrupoTributario,
                nome: nome,
                descricao: descricao,
                gtin: gtin,
                codigoInterno: codigoInterno,
                valorCompra: valorCompra,
                valorVenda: valorVenda,
                codigoNcm: codigoNcm,
                estoqueMinimo: estoqueMinimo,
                estoqueMaximo: estoqueMaximo,
                quantidadeEstoque: quantidadeEstoque,
                dataCadastro: dataCadastro,
              ),
          createCompanionCallback:
              ({
                Value<int?> id = const Value.absent(),
                Value<int?> idTributIcmsCustomCab = const Value.absent(),
                Value<int?> idTributGrupoTributario = const Value.absent(),
                Value<String?> nome = const Value.absent(),
                Value<String?> descricao = const Value.absent(),
                Value<String?> gtin = const Value.absent(),
                Value<String?> codigoInterno = const Value.absent(),
                Value<double?> valorCompra = const Value.absent(),
                Value<double?> valorVenda = const Value.absent(),
                Value<String?> codigoNcm = const Value.absent(),
                Value<double?> estoqueMinimo = const Value.absent(),
                Value<double?> estoqueMaximo = const Value.absent(),
                Value<double?> quantidadeEstoque = const Value.absent(),
                Value<DateTime?> dataCadastro = const Value.absent(),
              }) => ProdutosCompanion.insert(
                id: id,
                idTributIcmsCustomCab: idTributIcmsCustomCab,
                idTributGrupoTributario: idTributGrupoTributario,
                nome: nome,
                descricao: descricao,
                gtin: gtin,
                codigoInterno: codigoInterno,
                valorCompra: valorCompra,
                valorVenda: valorVenda,
                codigoNcm: codigoNcm,
                estoqueMinimo: estoqueMinimo,
                estoqueMaximo: estoqueMaximo,
                quantidadeEstoque: quantidadeEstoque,
                dataCadastro: dataCadastro,
              ),
          withReferenceMapper:
              (p0) =>
                  p0
                      .map(
                        (e) => (
                          e.readTable(table),
                          BaseReferences(db, table, e),
                        ),
                      )
                      .toList(),
          prefetchHooksCallback: null,
        ),
      );
}

typedef $$ProdutosTableProcessedTableManager =
    ProcessedTableManager<
      _$AppDatabase,
      $ProdutosTable,
      Produto,
      $$ProdutosTableFilterComposer,
      $$ProdutosTableOrderingComposer,
      $$ProdutosTableAnnotationComposer,
      $$ProdutosTableCreateCompanionBuilder,
      $$ProdutosTableUpdateCompanionBuilder,
      (Produto, BaseReferences<_$AppDatabase, $ProdutosTable, Produto>),
      Produto,
      PrefetchHooks Function()
    >;
typedef $$WmsAgendamentosTableCreateCompanionBuilder =
    WmsAgendamentosCompanion Function({
      Value<int?> id,
      Value<DateTime?> dataOperacao,
      Value<String?> horaOperacao,
      Value<String?> localOperacao,
      Value<int?> quantidadeVolume,
      Value<double?> pesoTotalVolume,
      Value<int?> quantidadePessoa,
      Value<int?> quantidadeHora,
    });
typedef $$WmsAgendamentosTableUpdateCompanionBuilder =
    WmsAgendamentosCompanion Function({
      Value<int?> id,
      Value<DateTime?> dataOperacao,
      Value<String?> horaOperacao,
      Value<String?> localOperacao,
      Value<int?> quantidadeVolume,
      Value<double?> pesoTotalVolume,
      Value<int?> quantidadePessoa,
      Value<int?> quantidadeHora,
    });

class $$WmsAgendamentosTableFilterComposer
    extends Composer<_$AppDatabase, $WmsAgendamentosTable> {
  $$WmsAgendamentosTableFilterComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnFilters<int> get id => $composableBuilder(
    column: $table.id,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<DateTime> get dataOperacao => $composableBuilder(
    column: $table.dataOperacao,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get horaOperacao => $composableBuilder(
    column: $table.horaOperacao,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get localOperacao => $composableBuilder(
    column: $table.localOperacao,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<int> get quantidadeVolume => $composableBuilder(
    column: $table.quantidadeVolume,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<double> get pesoTotalVolume => $composableBuilder(
    column: $table.pesoTotalVolume,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<int> get quantidadePessoa => $composableBuilder(
    column: $table.quantidadePessoa,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<int> get quantidadeHora => $composableBuilder(
    column: $table.quantidadeHora,
    builder: (column) => ColumnFilters(column),
  );
}

class $$WmsAgendamentosTableOrderingComposer
    extends Composer<_$AppDatabase, $WmsAgendamentosTable> {
  $$WmsAgendamentosTableOrderingComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnOrderings<int> get id => $composableBuilder(
    column: $table.id,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<DateTime> get dataOperacao => $composableBuilder(
    column: $table.dataOperacao,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get horaOperacao => $composableBuilder(
    column: $table.horaOperacao,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get localOperacao => $composableBuilder(
    column: $table.localOperacao,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<int> get quantidadeVolume => $composableBuilder(
    column: $table.quantidadeVolume,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<double> get pesoTotalVolume => $composableBuilder(
    column: $table.pesoTotalVolume,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<int> get quantidadePessoa => $composableBuilder(
    column: $table.quantidadePessoa,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<int> get quantidadeHora => $composableBuilder(
    column: $table.quantidadeHora,
    builder: (column) => ColumnOrderings(column),
  );
}

class $$WmsAgendamentosTableAnnotationComposer
    extends Composer<_$AppDatabase, $WmsAgendamentosTable> {
  $$WmsAgendamentosTableAnnotationComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  GeneratedColumn<int> get id =>
      $composableBuilder(column: $table.id, builder: (column) => column);

  GeneratedColumn<DateTime> get dataOperacao => $composableBuilder(
    column: $table.dataOperacao,
    builder: (column) => column,
  );

  GeneratedColumn<String> get horaOperacao => $composableBuilder(
    column: $table.horaOperacao,
    builder: (column) => column,
  );

  GeneratedColumn<String> get localOperacao => $composableBuilder(
    column: $table.localOperacao,
    builder: (column) => column,
  );

  GeneratedColumn<int> get quantidadeVolume => $composableBuilder(
    column: $table.quantidadeVolume,
    builder: (column) => column,
  );

  GeneratedColumn<double> get pesoTotalVolume => $composableBuilder(
    column: $table.pesoTotalVolume,
    builder: (column) => column,
  );

  GeneratedColumn<int> get quantidadePessoa => $composableBuilder(
    column: $table.quantidadePessoa,
    builder: (column) => column,
  );

  GeneratedColumn<int> get quantidadeHora => $composableBuilder(
    column: $table.quantidadeHora,
    builder: (column) => column,
  );
}

class $$WmsAgendamentosTableTableManager
    extends
        RootTableManager<
          _$AppDatabase,
          $WmsAgendamentosTable,
          WmsAgendamento,
          $$WmsAgendamentosTableFilterComposer,
          $$WmsAgendamentosTableOrderingComposer,
          $$WmsAgendamentosTableAnnotationComposer,
          $$WmsAgendamentosTableCreateCompanionBuilder,
          $$WmsAgendamentosTableUpdateCompanionBuilder,
          (
            WmsAgendamento,
            BaseReferences<
              _$AppDatabase,
              $WmsAgendamentosTable,
              WmsAgendamento
            >,
          ),
          WmsAgendamento,
          PrefetchHooks Function()
        > {
  $$WmsAgendamentosTableTableManager(
    _$AppDatabase db,
    $WmsAgendamentosTable table,
  ) : super(
        TableManagerState(
          db: db,
          table: table,
          createFilteringComposer:
              () =>
                  $$WmsAgendamentosTableFilterComposer($db: db, $table: table),
          createOrderingComposer:
              () => $$WmsAgendamentosTableOrderingComposer(
                $db: db,
                $table: table,
              ),
          createComputedFieldComposer:
              () => $$WmsAgendamentosTableAnnotationComposer(
                $db: db,
                $table: table,
              ),
          updateCompanionCallback:
              ({
                Value<int?> id = const Value.absent(),
                Value<DateTime?> dataOperacao = const Value.absent(),
                Value<String?> horaOperacao = const Value.absent(),
                Value<String?> localOperacao = const Value.absent(),
                Value<int?> quantidadeVolume = const Value.absent(),
                Value<double?> pesoTotalVolume = const Value.absent(),
                Value<int?> quantidadePessoa = const Value.absent(),
                Value<int?> quantidadeHora = const Value.absent(),
              }) => WmsAgendamentosCompanion(
                id: id,
                dataOperacao: dataOperacao,
                horaOperacao: horaOperacao,
                localOperacao: localOperacao,
                quantidadeVolume: quantidadeVolume,
                pesoTotalVolume: pesoTotalVolume,
                quantidadePessoa: quantidadePessoa,
                quantidadeHora: quantidadeHora,
              ),
          createCompanionCallback:
              ({
                Value<int?> id = const Value.absent(),
                Value<DateTime?> dataOperacao = const Value.absent(),
                Value<String?> horaOperacao = const Value.absent(),
                Value<String?> localOperacao = const Value.absent(),
                Value<int?> quantidadeVolume = const Value.absent(),
                Value<double?> pesoTotalVolume = const Value.absent(),
                Value<int?> quantidadePessoa = const Value.absent(),
                Value<int?> quantidadeHora = const Value.absent(),
              }) => WmsAgendamentosCompanion.insert(
                id: id,
                dataOperacao: dataOperacao,
                horaOperacao: horaOperacao,
                localOperacao: localOperacao,
                quantidadeVolume: quantidadeVolume,
                pesoTotalVolume: pesoTotalVolume,
                quantidadePessoa: quantidadePessoa,
                quantidadeHora: quantidadeHora,
              ),
          withReferenceMapper:
              (p0) =>
                  p0
                      .map(
                        (e) => (
                          e.readTable(table),
                          BaseReferences(db, table, e),
                        ),
                      )
                      .toList(),
          prefetchHooksCallback: null,
        ),
      );
}

typedef $$WmsAgendamentosTableProcessedTableManager =
    ProcessedTableManager<
      _$AppDatabase,
      $WmsAgendamentosTable,
      WmsAgendamento,
      $$WmsAgendamentosTableFilterComposer,
      $$WmsAgendamentosTableOrderingComposer,
      $$WmsAgendamentosTableAnnotationComposer,
      $$WmsAgendamentosTableCreateCompanionBuilder,
      $$WmsAgendamentosTableUpdateCompanionBuilder,
      (
        WmsAgendamento,
        BaseReferences<_$AppDatabase, $WmsAgendamentosTable, WmsAgendamento>,
      ),
      WmsAgendamento,
      PrefetchHooks Function()
    >;
typedef $$WmsParametrosTableCreateCompanionBuilder =
    WmsParametrosCompanion Function({
      Value<int?> id,
      Value<int?> horaPorVolume,
      Value<int?> pessoaPorVolume,
      Value<int?> horaPorPeso,
      Value<int?> pessoaPorPeso,
      Value<String?> itemDiferenteCaixa,
    });
typedef $$WmsParametrosTableUpdateCompanionBuilder =
    WmsParametrosCompanion Function({
      Value<int?> id,
      Value<int?> horaPorVolume,
      Value<int?> pessoaPorVolume,
      Value<int?> horaPorPeso,
      Value<int?> pessoaPorPeso,
      Value<String?> itemDiferenteCaixa,
    });

class $$WmsParametrosTableFilterComposer
    extends Composer<_$AppDatabase, $WmsParametrosTable> {
  $$WmsParametrosTableFilterComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnFilters<int> get id => $composableBuilder(
    column: $table.id,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<int> get horaPorVolume => $composableBuilder(
    column: $table.horaPorVolume,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<int> get pessoaPorVolume => $composableBuilder(
    column: $table.pessoaPorVolume,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<int> get horaPorPeso => $composableBuilder(
    column: $table.horaPorPeso,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<int> get pessoaPorPeso => $composableBuilder(
    column: $table.pessoaPorPeso,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get itemDiferenteCaixa => $composableBuilder(
    column: $table.itemDiferenteCaixa,
    builder: (column) => ColumnFilters(column),
  );
}

class $$WmsParametrosTableOrderingComposer
    extends Composer<_$AppDatabase, $WmsParametrosTable> {
  $$WmsParametrosTableOrderingComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnOrderings<int> get id => $composableBuilder(
    column: $table.id,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<int> get horaPorVolume => $composableBuilder(
    column: $table.horaPorVolume,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<int> get pessoaPorVolume => $composableBuilder(
    column: $table.pessoaPorVolume,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<int> get horaPorPeso => $composableBuilder(
    column: $table.horaPorPeso,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<int> get pessoaPorPeso => $composableBuilder(
    column: $table.pessoaPorPeso,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get itemDiferenteCaixa => $composableBuilder(
    column: $table.itemDiferenteCaixa,
    builder: (column) => ColumnOrderings(column),
  );
}

class $$WmsParametrosTableAnnotationComposer
    extends Composer<_$AppDatabase, $WmsParametrosTable> {
  $$WmsParametrosTableAnnotationComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  GeneratedColumn<int> get id =>
      $composableBuilder(column: $table.id, builder: (column) => column);

  GeneratedColumn<int> get horaPorVolume => $composableBuilder(
    column: $table.horaPorVolume,
    builder: (column) => column,
  );

  GeneratedColumn<int> get pessoaPorVolume => $composableBuilder(
    column: $table.pessoaPorVolume,
    builder: (column) => column,
  );

  GeneratedColumn<int> get horaPorPeso => $composableBuilder(
    column: $table.horaPorPeso,
    builder: (column) => column,
  );

  GeneratedColumn<int> get pessoaPorPeso => $composableBuilder(
    column: $table.pessoaPorPeso,
    builder: (column) => column,
  );

  GeneratedColumn<String> get itemDiferenteCaixa => $composableBuilder(
    column: $table.itemDiferenteCaixa,
    builder: (column) => column,
  );
}

class $$WmsParametrosTableTableManager
    extends
        RootTableManager<
          _$AppDatabase,
          $WmsParametrosTable,
          WmsParametro,
          $$WmsParametrosTableFilterComposer,
          $$WmsParametrosTableOrderingComposer,
          $$WmsParametrosTableAnnotationComposer,
          $$WmsParametrosTableCreateCompanionBuilder,
          $$WmsParametrosTableUpdateCompanionBuilder,
          (
            WmsParametro,
            BaseReferences<_$AppDatabase, $WmsParametrosTable, WmsParametro>,
          ),
          WmsParametro,
          PrefetchHooks Function()
        > {
  $$WmsParametrosTableTableManager(_$AppDatabase db, $WmsParametrosTable table)
    : super(
        TableManagerState(
          db: db,
          table: table,
          createFilteringComposer:
              () => $$WmsParametrosTableFilterComposer($db: db, $table: table),
          createOrderingComposer:
              () =>
                  $$WmsParametrosTableOrderingComposer($db: db, $table: table),
          createComputedFieldComposer:
              () => $$WmsParametrosTableAnnotationComposer(
                $db: db,
                $table: table,
              ),
          updateCompanionCallback:
              ({
                Value<int?> id = const Value.absent(),
                Value<int?> horaPorVolume = const Value.absent(),
                Value<int?> pessoaPorVolume = const Value.absent(),
                Value<int?> horaPorPeso = const Value.absent(),
                Value<int?> pessoaPorPeso = const Value.absent(),
                Value<String?> itemDiferenteCaixa = const Value.absent(),
              }) => WmsParametrosCompanion(
                id: id,
                horaPorVolume: horaPorVolume,
                pessoaPorVolume: pessoaPorVolume,
                horaPorPeso: horaPorPeso,
                pessoaPorPeso: pessoaPorPeso,
                itemDiferenteCaixa: itemDiferenteCaixa,
              ),
          createCompanionCallback:
              ({
                Value<int?> id = const Value.absent(),
                Value<int?> horaPorVolume = const Value.absent(),
                Value<int?> pessoaPorVolume = const Value.absent(),
                Value<int?> horaPorPeso = const Value.absent(),
                Value<int?> pessoaPorPeso = const Value.absent(),
                Value<String?> itemDiferenteCaixa = const Value.absent(),
              }) => WmsParametrosCompanion.insert(
                id: id,
                horaPorVolume: horaPorVolume,
                pessoaPorVolume: pessoaPorVolume,
                horaPorPeso: horaPorPeso,
                pessoaPorPeso: pessoaPorPeso,
                itemDiferenteCaixa: itemDiferenteCaixa,
              ),
          withReferenceMapper:
              (p0) =>
                  p0
                      .map(
                        (e) => (
                          e.readTable(table),
                          BaseReferences(db, table, e),
                        ),
                      )
                      .toList(),
          prefetchHooksCallback: null,
        ),
      );
}

typedef $$WmsParametrosTableProcessedTableManager =
    ProcessedTableManager<
      _$AppDatabase,
      $WmsParametrosTable,
      WmsParametro,
      $$WmsParametrosTableFilterComposer,
      $$WmsParametrosTableOrderingComposer,
      $$WmsParametrosTableAnnotationComposer,
      $$WmsParametrosTableCreateCompanionBuilder,
      $$WmsParametrosTableUpdateCompanionBuilder,
      (
        WmsParametro,
        BaseReferences<_$AppDatabase, $WmsParametrosTable, WmsParametro>,
      ),
      WmsParametro,
      PrefetchHooks Function()
    >;
typedef $$WmsRuasTableCreateCompanionBuilder =
    WmsRuasCompanion Function({
      Value<int?> id,
      Value<String?> codigo,
      Value<int?> quantidadeEstante,
      Value<String?> nome,
    });
typedef $$WmsRuasTableUpdateCompanionBuilder =
    WmsRuasCompanion Function({
      Value<int?> id,
      Value<String?> codigo,
      Value<int?> quantidadeEstante,
      Value<String?> nome,
    });

class $$WmsRuasTableFilterComposer
    extends Composer<_$AppDatabase, $WmsRuasTable> {
  $$WmsRuasTableFilterComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnFilters<int> get id => $composableBuilder(
    column: $table.id,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get codigo => $composableBuilder(
    column: $table.codigo,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<int> get quantidadeEstante => $composableBuilder(
    column: $table.quantidadeEstante,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get nome => $composableBuilder(
    column: $table.nome,
    builder: (column) => ColumnFilters(column),
  );
}

class $$WmsRuasTableOrderingComposer
    extends Composer<_$AppDatabase, $WmsRuasTable> {
  $$WmsRuasTableOrderingComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnOrderings<int> get id => $composableBuilder(
    column: $table.id,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get codigo => $composableBuilder(
    column: $table.codigo,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<int> get quantidadeEstante => $composableBuilder(
    column: $table.quantidadeEstante,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get nome => $composableBuilder(
    column: $table.nome,
    builder: (column) => ColumnOrderings(column),
  );
}

class $$WmsRuasTableAnnotationComposer
    extends Composer<_$AppDatabase, $WmsRuasTable> {
  $$WmsRuasTableAnnotationComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  GeneratedColumn<int> get id =>
      $composableBuilder(column: $table.id, builder: (column) => column);

  GeneratedColumn<String> get codigo =>
      $composableBuilder(column: $table.codigo, builder: (column) => column);

  GeneratedColumn<int> get quantidadeEstante => $composableBuilder(
    column: $table.quantidadeEstante,
    builder: (column) => column,
  );

  GeneratedColumn<String> get nome =>
      $composableBuilder(column: $table.nome, builder: (column) => column);
}

class $$WmsRuasTableTableManager
    extends
        RootTableManager<
          _$AppDatabase,
          $WmsRuasTable,
          WmsRua,
          $$WmsRuasTableFilterComposer,
          $$WmsRuasTableOrderingComposer,
          $$WmsRuasTableAnnotationComposer,
          $$WmsRuasTableCreateCompanionBuilder,
          $$WmsRuasTableUpdateCompanionBuilder,
          (WmsRua, BaseReferences<_$AppDatabase, $WmsRuasTable, WmsRua>),
          WmsRua,
          PrefetchHooks Function()
        > {
  $$WmsRuasTableTableManager(_$AppDatabase db, $WmsRuasTable table)
    : super(
        TableManagerState(
          db: db,
          table: table,
          createFilteringComposer:
              () => $$WmsRuasTableFilterComposer($db: db, $table: table),
          createOrderingComposer:
              () => $$WmsRuasTableOrderingComposer($db: db, $table: table),
          createComputedFieldComposer:
              () => $$WmsRuasTableAnnotationComposer($db: db, $table: table),
          updateCompanionCallback:
              ({
                Value<int?> id = const Value.absent(),
                Value<String?> codigo = const Value.absent(),
                Value<int?> quantidadeEstante = const Value.absent(),
                Value<String?> nome = const Value.absent(),
              }) => WmsRuasCompanion(
                id: id,
                codigo: codigo,
                quantidadeEstante: quantidadeEstante,
                nome: nome,
              ),
          createCompanionCallback:
              ({
                Value<int?> id = const Value.absent(),
                Value<String?> codigo = const Value.absent(),
                Value<int?> quantidadeEstante = const Value.absent(),
                Value<String?> nome = const Value.absent(),
              }) => WmsRuasCompanion.insert(
                id: id,
                codigo: codigo,
                quantidadeEstante: quantidadeEstante,
                nome: nome,
              ),
          withReferenceMapper:
              (p0) =>
                  p0
                      .map(
                        (e) => (
                          e.readTable(table),
                          BaseReferences(db, table, e),
                        ),
                      )
                      .toList(),
          prefetchHooksCallback: null,
        ),
      );
}

typedef $$WmsRuasTableProcessedTableManager =
    ProcessedTableManager<
      _$AppDatabase,
      $WmsRuasTable,
      WmsRua,
      $$WmsRuasTableFilterComposer,
      $$WmsRuasTableOrderingComposer,
      $$WmsRuasTableAnnotationComposer,
      $$WmsRuasTableCreateCompanionBuilder,
      $$WmsRuasTableUpdateCompanionBuilder,
      (WmsRua, BaseReferences<_$AppDatabase, $WmsRuasTable, WmsRua>),
      WmsRua,
      PrefetchHooks Function()
    >;
typedef $$WmsArmazenamentosTableCreateCompanionBuilder =
    WmsArmazenamentosCompanion Function({
      Value<int?> id,
      Value<int?> idWmsRecebimentoCabecalho,
      Value<int?> idProduto,
      Value<int?> idWmsCaixa,
      Value<int?> quantidade,
      Value<DateTime?> dataArmazenagem,
      Value<String?> horaArmazenagem,
    });
typedef $$WmsArmazenamentosTableUpdateCompanionBuilder =
    WmsArmazenamentosCompanion Function({
      Value<int?> id,
      Value<int?> idWmsRecebimentoCabecalho,
      Value<int?> idProduto,
      Value<int?> idWmsCaixa,
      Value<int?> quantidade,
      Value<DateTime?> dataArmazenagem,
      Value<String?> horaArmazenagem,
    });

class $$WmsArmazenamentosTableFilterComposer
    extends Composer<_$AppDatabase, $WmsArmazenamentosTable> {
  $$WmsArmazenamentosTableFilterComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnFilters<int> get id => $composableBuilder(
    column: $table.id,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<int> get idWmsRecebimentoCabecalho => $composableBuilder(
    column: $table.idWmsRecebimentoCabecalho,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<int> get idProduto => $composableBuilder(
    column: $table.idProduto,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<int> get idWmsCaixa => $composableBuilder(
    column: $table.idWmsCaixa,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<int> get quantidade => $composableBuilder(
    column: $table.quantidade,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<DateTime> get dataArmazenagem => $composableBuilder(
    column: $table.dataArmazenagem,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get horaArmazenagem => $composableBuilder(
    column: $table.horaArmazenagem,
    builder: (column) => ColumnFilters(column),
  );
}

class $$WmsArmazenamentosTableOrderingComposer
    extends Composer<_$AppDatabase, $WmsArmazenamentosTable> {
  $$WmsArmazenamentosTableOrderingComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnOrderings<int> get id => $composableBuilder(
    column: $table.id,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<int> get idWmsRecebimentoCabecalho => $composableBuilder(
    column: $table.idWmsRecebimentoCabecalho,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<int> get idProduto => $composableBuilder(
    column: $table.idProduto,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<int> get idWmsCaixa => $composableBuilder(
    column: $table.idWmsCaixa,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<int> get quantidade => $composableBuilder(
    column: $table.quantidade,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<DateTime> get dataArmazenagem => $composableBuilder(
    column: $table.dataArmazenagem,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get horaArmazenagem => $composableBuilder(
    column: $table.horaArmazenagem,
    builder: (column) => ColumnOrderings(column),
  );
}

class $$WmsArmazenamentosTableAnnotationComposer
    extends Composer<_$AppDatabase, $WmsArmazenamentosTable> {
  $$WmsArmazenamentosTableAnnotationComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  GeneratedColumn<int> get id =>
      $composableBuilder(column: $table.id, builder: (column) => column);

  GeneratedColumn<int> get idWmsRecebimentoCabecalho => $composableBuilder(
    column: $table.idWmsRecebimentoCabecalho,
    builder: (column) => column,
  );

  GeneratedColumn<int> get idProduto =>
      $composableBuilder(column: $table.idProduto, builder: (column) => column);

  GeneratedColumn<int> get idWmsCaixa => $composableBuilder(
    column: $table.idWmsCaixa,
    builder: (column) => column,
  );

  GeneratedColumn<int> get quantidade => $composableBuilder(
    column: $table.quantidade,
    builder: (column) => column,
  );

  GeneratedColumn<DateTime> get dataArmazenagem => $composableBuilder(
    column: $table.dataArmazenagem,
    builder: (column) => column,
  );

  GeneratedColumn<String> get horaArmazenagem => $composableBuilder(
    column: $table.horaArmazenagem,
    builder: (column) => column,
  );
}

class $$WmsArmazenamentosTableTableManager
    extends
        RootTableManager<
          _$AppDatabase,
          $WmsArmazenamentosTable,
          WmsArmazenamento,
          $$WmsArmazenamentosTableFilterComposer,
          $$WmsArmazenamentosTableOrderingComposer,
          $$WmsArmazenamentosTableAnnotationComposer,
          $$WmsArmazenamentosTableCreateCompanionBuilder,
          $$WmsArmazenamentosTableUpdateCompanionBuilder,
          (
            WmsArmazenamento,
            BaseReferences<
              _$AppDatabase,
              $WmsArmazenamentosTable,
              WmsArmazenamento
            >,
          ),
          WmsArmazenamento,
          PrefetchHooks Function()
        > {
  $$WmsArmazenamentosTableTableManager(
    _$AppDatabase db,
    $WmsArmazenamentosTable table,
  ) : super(
        TableManagerState(
          db: db,
          table: table,
          createFilteringComposer:
              () => $$WmsArmazenamentosTableFilterComposer(
                $db: db,
                $table: table,
              ),
          createOrderingComposer:
              () => $$WmsArmazenamentosTableOrderingComposer(
                $db: db,
                $table: table,
              ),
          createComputedFieldComposer:
              () => $$WmsArmazenamentosTableAnnotationComposer(
                $db: db,
                $table: table,
              ),
          updateCompanionCallback:
              ({
                Value<int?> id = const Value.absent(),
                Value<int?> idWmsRecebimentoCabecalho = const Value.absent(),
                Value<int?> idProduto = const Value.absent(),
                Value<int?> idWmsCaixa = const Value.absent(),
                Value<int?> quantidade = const Value.absent(),
                Value<DateTime?> dataArmazenagem = const Value.absent(),
                Value<String?> horaArmazenagem = const Value.absent(),
              }) => WmsArmazenamentosCompanion(
                id: id,
                idWmsRecebimentoCabecalho: idWmsRecebimentoCabecalho,
                idProduto: idProduto,
                idWmsCaixa: idWmsCaixa,
                quantidade: quantidade,
                dataArmazenagem: dataArmazenagem,
                horaArmazenagem: horaArmazenagem,
              ),
          createCompanionCallback:
              ({
                Value<int?> id = const Value.absent(),
                Value<int?> idWmsRecebimentoCabecalho = const Value.absent(),
                Value<int?> idProduto = const Value.absent(),
                Value<int?> idWmsCaixa = const Value.absent(),
                Value<int?> quantidade = const Value.absent(),
                Value<DateTime?> dataArmazenagem = const Value.absent(),
                Value<String?> horaArmazenagem = const Value.absent(),
              }) => WmsArmazenamentosCompanion.insert(
                id: id,
                idWmsRecebimentoCabecalho: idWmsRecebimentoCabecalho,
                idProduto: idProduto,
                idWmsCaixa: idWmsCaixa,
                quantidade: quantidade,
                dataArmazenagem: dataArmazenagem,
                horaArmazenagem: horaArmazenagem,
              ),
          withReferenceMapper:
              (p0) =>
                  p0
                      .map(
                        (e) => (
                          e.readTable(table),
                          BaseReferences(db, table, e),
                        ),
                      )
                      .toList(),
          prefetchHooksCallback: null,
        ),
      );
}

typedef $$WmsArmazenamentosTableProcessedTableManager =
    ProcessedTableManager<
      _$AppDatabase,
      $WmsArmazenamentosTable,
      WmsArmazenamento,
      $$WmsArmazenamentosTableFilterComposer,
      $$WmsArmazenamentosTableOrderingComposer,
      $$WmsArmazenamentosTableAnnotationComposer,
      $$WmsArmazenamentosTableCreateCompanionBuilder,
      $$WmsArmazenamentosTableUpdateCompanionBuilder,
      (
        WmsArmazenamento,
        BaseReferences<
          _$AppDatabase,
          $WmsArmazenamentosTable,
          WmsArmazenamento
        >,
      ),
      WmsArmazenamento,
      PrefetchHooks Function()
    >;
typedef $$WmsExpedicaosTableCreateCompanionBuilder =
    WmsExpedicaosCompanion Function({
      Value<int?> id,
      Value<int?> idProduto,
      Value<int?> quantidade,
      Value<DateTime?> dataSaida,
      Value<String?> horaSaida,
      Value<String?> veioDeOnde,
      Value<String?> codigoSeparacaoRecebimento,
    });
typedef $$WmsExpedicaosTableUpdateCompanionBuilder =
    WmsExpedicaosCompanion Function({
      Value<int?> id,
      Value<int?> idProduto,
      Value<int?> quantidade,
      Value<DateTime?> dataSaida,
      Value<String?> horaSaida,
      Value<String?> veioDeOnde,
      Value<String?> codigoSeparacaoRecebimento,
    });

class $$WmsExpedicaosTableFilterComposer
    extends Composer<_$AppDatabase, $WmsExpedicaosTable> {
  $$WmsExpedicaosTableFilterComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnFilters<int> get id => $composableBuilder(
    column: $table.id,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<int> get idProduto => $composableBuilder(
    column: $table.idProduto,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<int> get quantidade => $composableBuilder(
    column: $table.quantidade,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<DateTime> get dataSaida => $composableBuilder(
    column: $table.dataSaida,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get horaSaida => $composableBuilder(
    column: $table.horaSaida,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get veioDeOnde => $composableBuilder(
    column: $table.veioDeOnde,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get codigoSeparacaoRecebimento => $composableBuilder(
    column: $table.codigoSeparacaoRecebimento,
    builder: (column) => ColumnFilters(column),
  );
}

class $$WmsExpedicaosTableOrderingComposer
    extends Composer<_$AppDatabase, $WmsExpedicaosTable> {
  $$WmsExpedicaosTableOrderingComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnOrderings<int> get id => $composableBuilder(
    column: $table.id,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<int> get idProduto => $composableBuilder(
    column: $table.idProduto,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<int> get quantidade => $composableBuilder(
    column: $table.quantidade,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<DateTime> get dataSaida => $composableBuilder(
    column: $table.dataSaida,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get horaSaida => $composableBuilder(
    column: $table.horaSaida,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get veioDeOnde => $composableBuilder(
    column: $table.veioDeOnde,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get codigoSeparacaoRecebimento => $composableBuilder(
    column: $table.codigoSeparacaoRecebimento,
    builder: (column) => ColumnOrderings(column),
  );
}

class $$WmsExpedicaosTableAnnotationComposer
    extends Composer<_$AppDatabase, $WmsExpedicaosTable> {
  $$WmsExpedicaosTableAnnotationComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  GeneratedColumn<int> get id =>
      $composableBuilder(column: $table.id, builder: (column) => column);

  GeneratedColumn<int> get idProduto =>
      $composableBuilder(column: $table.idProduto, builder: (column) => column);

  GeneratedColumn<int> get quantidade => $composableBuilder(
    column: $table.quantidade,
    builder: (column) => column,
  );

  GeneratedColumn<DateTime> get dataSaida =>
      $composableBuilder(column: $table.dataSaida, builder: (column) => column);

  GeneratedColumn<String> get horaSaida =>
      $composableBuilder(column: $table.horaSaida, builder: (column) => column);

  GeneratedColumn<String> get veioDeOnde => $composableBuilder(
    column: $table.veioDeOnde,
    builder: (column) => column,
  );

  GeneratedColumn<String> get codigoSeparacaoRecebimento => $composableBuilder(
    column: $table.codigoSeparacaoRecebimento,
    builder: (column) => column,
  );
}

class $$WmsExpedicaosTableTableManager
    extends
        RootTableManager<
          _$AppDatabase,
          $WmsExpedicaosTable,
          WmsExpedicao,
          $$WmsExpedicaosTableFilterComposer,
          $$WmsExpedicaosTableOrderingComposer,
          $$WmsExpedicaosTableAnnotationComposer,
          $$WmsExpedicaosTableCreateCompanionBuilder,
          $$WmsExpedicaosTableUpdateCompanionBuilder,
          (
            WmsExpedicao,
            BaseReferences<_$AppDatabase, $WmsExpedicaosTable, WmsExpedicao>,
          ),
          WmsExpedicao,
          PrefetchHooks Function()
        > {
  $$WmsExpedicaosTableTableManager(_$AppDatabase db, $WmsExpedicaosTable table)
    : super(
        TableManagerState(
          db: db,
          table: table,
          createFilteringComposer:
              () => $$WmsExpedicaosTableFilterComposer($db: db, $table: table),
          createOrderingComposer:
              () =>
                  $$WmsExpedicaosTableOrderingComposer($db: db, $table: table),
          createComputedFieldComposer:
              () => $$WmsExpedicaosTableAnnotationComposer(
                $db: db,
                $table: table,
              ),
          updateCompanionCallback:
              ({
                Value<int?> id = const Value.absent(),
                Value<int?> idProduto = const Value.absent(),
                Value<int?> quantidade = const Value.absent(),
                Value<DateTime?> dataSaida = const Value.absent(),
                Value<String?> horaSaida = const Value.absent(),
                Value<String?> veioDeOnde = const Value.absent(),
                Value<String?> codigoSeparacaoRecebimento =
                    const Value.absent(),
              }) => WmsExpedicaosCompanion(
                id: id,
                idProduto: idProduto,
                quantidade: quantidade,
                dataSaida: dataSaida,
                horaSaida: horaSaida,
                veioDeOnde: veioDeOnde,
                codigoSeparacaoRecebimento: codigoSeparacaoRecebimento,
              ),
          createCompanionCallback:
              ({
                Value<int?> id = const Value.absent(),
                Value<int?> idProduto = const Value.absent(),
                Value<int?> quantidade = const Value.absent(),
                Value<DateTime?> dataSaida = const Value.absent(),
                Value<String?> horaSaida = const Value.absent(),
                Value<String?> veioDeOnde = const Value.absent(),
                Value<String?> codigoSeparacaoRecebimento =
                    const Value.absent(),
              }) => WmsExpedicaosCompanion.insert(
                id: id,
                idProduto: idProduto,
                quantidade: quantidade,
                dataSaida: dataSaida,
                horaSaida: horaSaida,
                veioDeOnde: veioDeOnde,
                codigoSeparacaoRecebimento: codigoSeparacaoRecebimento,
              ),
          withReferenceMapper:
              (p0) =>
                  p0
                      .map(
                        (e) => (
                          e.readTable(table),
                          BaseReferences(db, table, e),
                        ),
                      )
                      .toList(),
          prefetchHooksCallback: null,
        ),
      );
}

typedef $$WmsExpedicaosTableProcessedTableManager =
    ProcessedTableManager<
      _$AppDatabase,
      $WmsExpedicaosTable,
      WmsExpedicao,
      $$WmsExpedicaosTableFilterComposer,
      $$WmsExpedicaosTableOrderingComposer,
      $$WmsExpedicaosTableAnnotationComposer,
      $$WmsExpedicaosTableCreateCompanionBuilder,
      $$WmsExpedicaosTableUpdateCompanionBuilder,
      (
        WmsExpedicao,
        BaseReferences<_$AppDatabase, $WmsExpedicaosTable, WmsExpedicao>,
      ),
      WmsExpedicao,
      PrefetchHooks Function()
    >;
typedef $$ViewControleAcessosTableCreateCompanionBuilder =
    ViewControleAcessosCompanion Function({
      Value<int?> id,
      Value<int?> idPessoa,
      Value<String?> pessoaNome,
      Value<int?> idColaborador,
      Value<int?> idUsuario,
      Value<String?> administrador,
      Value<int?> idPapel,
      Value<String?> papelNome,
      Value<String?> papelDescricao,
      Value<int?> idFuncao,
      Value<String?> funcaoNome,
      Value<String?> funcaoDescricao,
      Value<int?> idPapelFuncao,
      Value<String?> habilitado,
      Value<String?> podeInserir,
      Value<String?> podeAlterar,
      Value<String?> podeExcluir,
    });
typedef $$ViewControleAcessosTableUpdateCompanionBuilder =
    ViewControleAcessosCompanion Function({
      Value<int?> id,
      Value<int?> idPessoa,
      Value<String?> pessoaNome,
      Value<int?> idColaborador,
      Value<int?> idUsuario,
      Value<String?> administrador,
      Value<int?> idPapel,
      Value<String?> papelNome,
      Value<String?> papelDescricao,
      Value<int?> idFuncao,
      Value<String?> funcaoNome,
      Value<String?> funcaoDescricao,
      Value<int?> idPapelFuncao,
      Value<String?> habilitado,
      Value<String?> podeInserir,
      Value<String?> podeAlterar,
      Value<String?> podeExcluir,
    });

class $$ViewControleAcessosTableFilterComposer
    extends Composer<_$AppDatabase, $ViewControleAcessosTable> {
  $$ViewControleAcessosTableFilterComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnFilters<int> get id => $composableBuilder(
    column: $table.id,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<int> get idPessoa => $composableBuilder(
    column: $table.idPessoa,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get pessoaNome => $composableBuilder(
    column: $table.pessoaNome,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<int> get idColaborador => $composableBuilder(
    column: $table.idColaborador,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<int> get idUsuario => $composableBuilder(
    column: $table.idUsuario,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get administrador => $composableBuilder(
    column: $table.administrador,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<int> get idPapel => $composableBuilder(
    column: $table.idPapel,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get papelNome => $composableBuilder(
    column: $table.papelNome,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get papelDescricao => $composableBuilder(
    column: $table.papelDescricao,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<int> get idFuncao => $composableBuilder(
    column: $table.idFuncao,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get funcaoNome => $composableBuilder(
    column: $table.funcaoNome,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get funcaoDescricao => $composableBuilder(
    column: $table.funcaoDescricao,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<int> get idPapelFuncao => $composableBuilder(
    column: $table.idPapelFuncao,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get habilitado => $composableBuilder(
    column: $table.habilitado,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get podeInserir => $composableBuilder(
    column: $table.podeInserir,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get podeAlterar => $composableBuilder(
    column: $table.podeAlterar,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get podeExcluir => $composableBuilder(
    column: $table.podeExcluir,
    builder: (column) => ColumnFilters(column),
  );
}

class $$ViewControleAcessosTableOrderingComposer
    extends Composer<_$AppDatabase, $ViewControleAcessosTable> {
  $$ViewControleAcessosTableOrderingComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnOrderings<int> get id => $composableBuilder(
    column: $table.id,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<int> get idPessoa => $composableBuilder(
    column: $table.idPessoa,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get pessoaNome => $composableBuilder(
    column: $table.pessoaNome,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<int> get idColaborador => $composableBuilder(
    column: $table.idColaborador,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<int> get idUsuario => $composableBuilder(
    column: $table.idUsuario,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get administrador => $composableBuilder(
    column: $table.administrador,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<int> get idPapel => $composableBuilder(
    column: $table.idPapel,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get papelNome => $composableBuilder(
    column: $table.papelNome,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get papelDescricao => $composableBuilder(
    column: $table.papelDescricao,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<int> get idFuncao => $composableBuilder(
    column: $table.idFuncao,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get funcaoNome => $composableBuilder(
    column: $table.funcaoNome,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get funcaoDescricao => $composableBuilder(
    column: $table.funcaoDescricao,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<int> get idPapelFuncao => $composableBuilder(
    column: $table.idPapelFuncao,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get habilitado => $composableBuilder(
    column: $table.habilitado,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get podeInserir => $composableBuilder(
    column: $table.podeInserir,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get podeAlterar => $composableBuilder(
    column: $table.podeAlterar,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get podeExcluir => $composableBuilder(
    column: $table.podeExcluir,
    builder: (column) => ColumnOrderings(column),
  );
}

class $$ViewControleAcessosTableAnnotationComposer
    extends Composer<_$AppDatabase, $ViewControleAcessosTable> {
  $$ViewControleAcessosTableAnnotationComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  GeneratedColumn<int> get id =>
      $composableBuilder(column: $table.id, builder: (column) => column);

  GeneratedColumn<int> get idPessoa =>
      $composableBuilder(column: $table.idPessoa, builder: (column) => column);

  GeneratedColumn<String> get pessoaNome => $composableBuilder(
    column: $table.pessoaNome,
    builder: (column) => column,
  );

  GeneratedColumn<int> get idColaborador => $composableBuilder(
    column: $table.idColaborador,
    builder: (column) => column,
  );

  GeneratedColumn<int> get idUsuario =>
      $composableBuilder(column: $table.idUsuario, builder: (column) => column);

  GeneratedColumn<String> get administrador => $composableBuilder(
    column: $table.administrador,
    builder: (column) => column,
  );

  GeneratedColumn<int> get idPapel =>
      $composableBuilder(column: $table.idPapel, builder: (column) => column);

  GeneratedColumn<String> get papelNome =>
      $composableBuilder(column: $table.papelNome, builder: (column) => column);

  GeneratedColumn<String> get papelDescricao => $composableBuilder(
    column: $table.papelDescricao,
    builder: (column) => column,
  );

  GeneratedColumn<int> get idFuncao =>
      $composableBuilder(column: $table.idFuncao, builder: (column) => column);

  GeneratedColumn<String> get funcaoNome => $composableBuilder(
    column: $table.funcaoNome,
    builder: (column) => column,
  );

  GeneratedColumn<String> get funcaoDescricao => $composableBuilder(
    column: $table.funcaoDescricao,
    builder: (column) => column,
  );

  GeneratedColumn<int> get idPapelFuncao => $composableBuilder(
    column: $table.idPapelFuncao,
    builder: (column) => column,
  );

  GeneratedColumn<String> get habilitado => $composableBuilder(
    column: $table.habilitado,
    builder: (column) => column,
  );

  GeneratedColumn<String> get podeInserir => $composableBuilder(
    column: $table.podeInserir,
    builder: (column) => column,
  );

  GeneratedColumn<String> get podeAlterar => $composableBuilder(
    column: $table.podeAlterar,
    builder: (column) => column,
  );

  GeneratedColumn<String> get podeExcluir => $composableBuilder(
    column: $table.podeExcluir,
    builder: (column) => column,
  );
}

class $$ViewControleAcessosTableTableManager
    extends
        RootTableManager<
          _$AppDatabase,
          $ViewControleAcessosTable,
          ViewControleAcesso,
          $$ViewControleAcessosTableFilterComposer,
          $$ViewControleAcessosTableOrderingComposer,
          $$ViewControleAcessosTableAnnotationComposer,
          $$ViewControleAcessosTableCreateCompanionBuilder,
          $$ViewControleAcessosTableUpdateCompanionBuilder,
          (
            ViewControleAcesso,
            BaseReferences<
              _$AppDatabase,
              $ViewControleAcessosTable,
              ViewControleAcesso
            >,
          ),
          ViewControleAcesso,
          PrefetchHooks Function()
        > {
  $$ViewControleAcessosTableTableManager(
    _$AppDatabase db,
    $ViewControleAcessosTable table,
  ) : super(
        TableManagerState(
          db: db,
          table: table,
          createFilteringComposer:
              () => $$ViewControleAcessosTableFilterComposer(
                $db: db,
                $table: table,
              ),
          createOrderingComposer:
              () => $$ViewControleAcessosTableOrderingComposer(
                $db: db,
                $table: table,
              ),
          createComputedFieldComposer:
              () => $$ViewControleAcessosTableAnnotationComposer(
                $db: db,
                $table: table,
              ),
          updateCompanionCallback:
              ({
                Value<int?> id = const Value.absent(),
                Value<int?> idPessoa = const Value.absent(),
                Value<String?> pessoaNome = const Value.absent(),
                Value<int?> idColaborador = const Value.absent(),
                Value<int?> idUsuario = const Value.absent(),
                Value<String?> administrador = const Value.absent(),
                Value<int?> idPapel = const Value.absent(),
                Value<String?> papelNome = const Value.absent(),
                Value<String?> papelDescricao = const Value.absent(),
                Value<int?> idFuncao = const Value.absent(),
                Value<String?> funcaoNome = const Value.absent(),
                Value<String?> funcaoDescricao = const Value.absent(),
                Value<int?> idPapelFuncao = const Value.absent(),
                Value<String?> habilitado = const Value.absent(),
                Value<String?> podeInserir = const Value.absent(),
                Value<String?> podeAlterar = const Value.absent(),
                Value<String?> podeExcluir = const Value.absent(),
              }) => ViewControleAcessosCompanion(
                id: id,
                idPessoa: idPessoa,
                pessoaNome: pessoaNome,
                idColaborador: idColaborador,
                idUsuario: idUsuario,
                administrador: administrador,
                idPapel: idPapel,
                papelNome: papelNome,
                papelDescricao: papelDescricao,
                idFuncao: idFuncao,
                funcaoNome: funcaoNome,
                funcaoDescricao: funcaoDescricao,
                idPapelFuncao: idPapelFuncao,
                habilitado: habilitado,
                podeInserir: podeInserir,
                podeAlterar: podeAlterar,
                podeExcluir: podeExcluir,
              ),
          createCompanionCallback:
              ({
                Value<int?> id = const Value.absent(),
                Value<int?> idPessoa = const Value.absent(),
                Value<String?> pessoaNome = const Value.absent(),
                Value<int?> idColaborador = const Value.absent(),
                Value<int?> idUsuario = const Value.absent(),
                Value<String?> administrador = const Value.absent(),
                Value<int?> idPapel = const Value.absent(),
                Value<String?> papelNome = const Value.absent(),
                Value<String?> papelDescricao = const Value.absent(),
                Value<int?> idFuncao = const Value.absent(),
                Value<String?> funcaoNome = const Value.absent(),
                Value<String?> funcaoDescricao = const Value.absent(),
                Value<int?> idPapelFuncao = const Value.absent(),
                Value<String?> habilitado = const Value.absent(),
                Value<String?> podeInserir = const Value.absent(),
                Value<String?> podeAlterar = const Value.absent(),
                Value<String?> podeExcluir = const Value.absent(),
              }) => ViewControleAcessosCompanion.insert(
                id: id,
                idPessoa: idPessoa,
                pessoaNome: pessoaNome,
                idColaborador: idColaborador,
                idUsuario: idUsuario,
                administrador: administrador,
                idPapel: idPapel,
                papelNome: papelNome,
                papelDescricao: papelDescricao,
                idFuncao: idFuncao,
                funcaoNome: funcaoNome,
                funcaoDescricao: funcaoDescricao,
                idPapelFuncao: idPapelFuncao,
                habilitado: habilitado,
                podeInserir: podeInserir,
                podeAlterar: podeAlterar,
                podeExcluir: podeExcluir,
              ),
          withReferenceMapper:
              (p0) =>
                  p0
                      .map(
                        (e) => (
                          e.readTable(table),
                          BaseReferences(db, table, e),
                        ),
                      )
                      .toList(),
          prefetchHooksCallback: null,
        ),
      );
}

typedef $$ViewControleAcessosTableProcessedTableManager =
    ProcessedTableManager<
      _$AppDatabase,
      $ViewControleAcessosTable,
      ViewControleAcesso,
      $$ViewControleAcessosTableFilterComposer,
      $$ViewControleAcessosTableOrderingComposer,
      $$ViewControleAcessosTableAnnotationComposer,
      $$ViewControleAcessosTableCreateCompanionBuilder,
      $$ViewControleAcessosTableUpdateCompanionBuilder,
      (
        ViewControleAcesso,
        BaseReferences<
          _$AppDatabase,
          $ViewControleAcessosTable,
          ViewControleAcesso
        >,
      ),
      ViewControleAcesso,
      PrefetchHooks Function()
    >;
typedef $$ViewPessoaUsuariosTableCreateCompanionBuilder =
    ViewPessoaUsuariosCompanion Function({
      Value<int?> id,
      Value<int?> idPessoa,
      Value<String?> pessoaNome,
      Value<String?> tipo,
      Value<String?> email,
      Value<int?> idColaborador,
      Value<int?> idUsuario,
      Value<String?> login,
      Value<String?> senha,
      Value<DateTime?> dataCadastro,
      Value<String?> administrador,
    });
typedef $$ViewPessoaUsuariosTableUpdateCompanionBuilder =
    ViewPessoaUsuariosCompanion Function({
      Value<int?> id,
      Value<int?> idPessoa,
      Value<String?> pessoaNome,
      Value<String?> tipo,
      Value<String?> email,
      Value<int?> idColaborador,
      Value<int?> idUsuario,
      Value<String?> login,
      Value<String?> senha,
      Value<DateTime?> dataCadastro,
      Value<String?> administrador,
    });

class $$ViewPessoaUsuariosTableFilterComposer
    extends Composer<_$AppDatabase, $ViewPessoaUsuariosTable> {
  $$ViewPessoaUsuariosTableFilterComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnFilters<int> get id => $composableBuilder(
    column: $table.id,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<int> get idPessoa => $composableBuilder(
    column: $table.idPessoa,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get pessoaNome => $composableBuilder(
    column: $table.pessoaNome,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get tipo => $composableBuilder(
    column: $table.tipo,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get email => $composableBuilder(
    column: $table.email,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<int> get idColaborador => $composableBuilder(
    column: $table.idColaborador,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<int> get idUsuario => $composableBuilder(
    column: $table.idUsuario,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get login => $composableBuilder(
    column: $table.login,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get senha => $composableBuilder(
    column: $table.senha,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<DateTime> get dataCadastro => $composableBuilder(
    column: $table.dataCadastro,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get administrador => $composableBuilder(
    column: $table.administrador,
    builder: (column) => ColumnFilters(column),
  );
}

class $$ViewPessoaUsuariosTableOrderingComposer
    extends Composer<_$AppDatabase, $ViewPessoaUsuariosTable> {
  $$ViewPessoaUsuariosTableOrderingComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnOrderings<int> get id => $composableBuilder(
    column: $table.id,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<int> get idPessoa => $composableBuilder(
    column: $table.idPessoa,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get pessoaNome => $composableBuilder(
    column: $table.pessoaNome,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get tipo => $composableBuilder(
    column: $table.tipo,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get email => $composableBuilder(
    column: $table.email,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<int> get idColaborador => $composableBuilder(
    column: $table.idColaborador,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<int> get idUsuario => $composableBuilder(
    column: $table.idUsuario,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get login => $composableBuilder(
    column: $table.login,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get senha => $composableBuilder(
    column: $table.senha,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<DateTime> get dataCadastro => $composableBuilder(
    column: $table.dataCadastro,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get administrador => $composableBuilder(
    column: $table.administrador,
    builder: (column) => ColumnOrderings(column),
  );
}

class $$ViewPessoaUsuariosTableAnnotationComposer
    extends Composer<_$AppDatabase, $ViewPessoaUsuariosTable> {
  $$ViewPessoaUsuariosTableAnnotationComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  GeneratedColumn<int> get id =>
      $composableBuilder(column: $table.id, builder: (column) => column);

  GeneratedColumn<int> get idPessoa =>
      $composableBuilder(column: $table.idPessoa, builder: (column) => column);

  GeneratedColumn<String> get pessoaNome => $composableBuilder(
    column: $table.pessoaNome,
    builder: (column) => column,
  );

  GeneratedColumn<String> get tipo =>
      $composableBuilder(column: $table.tipo, builder: (column) => column);

  GeneratedColumn<String> get email =>
      $composableBuilder(column: $table.email, builder: (column) => column);

  GeneratedColumn<int> get idColaborador => $composableBuilder(
    column: $table.idColaborador,
    builder: (column) => column,
  );

  GeneratedColumn<int> get idUsuario =>
      $composableBuilder(column: $table.idUsuario, builder: (column) => column);

  GeneratedColumn<String> get login =>
      $composableBuilder(column: $table.login, builder: (column) => column);

  GeneratedColumn<String> get senha =>
      $composableBuilder(column: $table.senha, builder: (column) => column);

  GeneratedColumn<DateTime> get dataCadastro => $composableBuilder(
    column: $table.dataCadastro,
    builder: (column) => column,
  );

  GeneratedColumn<String> get administrador => $composableBuilder(
    column: $table.administrador,
    builder: (column) => column,
  );
}

class $$ViewPessoaUsuariosTableTableManager
    extends
        RootTableManager<
          _$AppDatabase,
          $ViewPessoaUsuariosTable,
          ViewPessoaUsuario,
          $$ViewPessoaUsuariosTableFilterComposer,
          $$ViewPessoaUsuariosTableOrderingComposer,
          $$ViewPessoaUsuariosTableAnnotationComposer,
          $$ViewPessoaUsuariosTableCreateCompanionBuilder,
          $$ViewPessoaUsuariosTableUpdateCompanionBuilder,
          (
            ViewPessoaUsuario,
            BaseReferences<
              _$AppDatabase,
              $ViewPessoaUsuariosTable,
              ViewPessoaUsuario
            >,
          ),
          ViewPessoaUsuario,
          PrefetchHooks Function()
        > {
  $$ViewPessoaUsuariosTableTableManager(
    _$AppDatabase db,
    $ViewPessoaUsuariosTable table,
  ) : super(
        TableManagerState(
          db: db,
          table: table,
          createFilteringComposer:
              () => $$ViewPessoaUsuariosTableFilterComposer(
                $db: db,
                $table: table,
              ),
          createOrderingComposer:
              () => $$ViewPessoaUsuariosTableOrderingComposer(
                $db: db,
                $table: table,
              ),
          createComputedFieldComposer:
              () => $$ViewPessoaUsuariosTableAnnotationComposer(
                $db: db,
                $table: table,
              ),
          updateCompanionCallback:
              ({
                Value<int?> id = const Value.absent(),
                Value<int?> idPessoa = const Value.absent(),
                Value<String?> pessoaNome = const Value.absent(),
                Value<String?> tipo = const Value.absent(),
                Value<String?> email = const Value.absent(),
                Value<int?> idColaborador = const Value.absent(),
                Value<int?> idUsuario = const Value.absent(),
                Value<String?> login = const Value.absent(),
                Value<String?> senha = const Value.absent(),
                Value<DateTime?> dataCadastro = const Value.absent(),
                Value<String?> administrador = const Value.absent(),
              }) => ViewPessoaUsuariosCompanion(
                id: id,
                idPessoa: idPessoa,
                pessoaNome: pessoaNome,
                tipo: tipo,
                email: email,
                idColaborador: idColaborador,
                idUsuario: idUsuario,
                login: login,
                senha: senha,
                dataCadastro: dataCadastro,
                administrador: administrador,
              ),
          createCompanionCallback:
              ({
                Value<int?> id = const Value.absent(),
                Value<int?> idPessoa = const Value.absent(),
                Value<String?> pessoaNome = const Value.absent(),
                Value<String?> tipo = const Value.absent(),
                Value<String?> email = const Value.absent(),
                Value<int?> idColaborador = const Value.absent(),
                Value<int?> idUsuario = const Value.absent(),
                Value<String?> login = const Value.absent(),
                Value<String?> senha = const Value.absent(),
                Value<DateTime?> dataCadastro = const Value.absent(),
                Value<String?> administrador = const Value.absent(),
              }) => ViewPessoaUsuariosCompanion.insert(
                id: id,
                idPessoa: idPessoa,
                pessoaNome: pessoaNome,
                tipo: tipo,
                email: email,
                idColaborador: idColaborador,
                idUsuario: idUsuario,
                login: login,
                senha: senha,
                dataCadastro: dataCadastro,
                administrador: administrador,
              ),
          withReferenceMapper:
              (p0) =>
                  p0
                      .map(
                        (e) => (
                          e.readTable(table),
                          BaseReferences(db, table, e),
                        ),
                      )
                      .toList(),
          prefetchHooksCallback: null,
        ),
      );
}

typedef $$ViewPessoaUsuariosTableProcessedTableManager =
    ProcessedTableManager<
      _$AppDatabase,
      $ViewPessoaUsuariosTable,
      ViewPessoaUsuario,
      $$ViewPessoaUsuariosTableFilterComposer,
      $$ViewPessoaUsuariosTableOrderingComposer,
      $$ViewPessoaUsuariosTableAnnotationComposer,
      $$ViewPessoaUsuariosTableCreateCompanionBuilder,
      $$ViewPessoaUsuariosTableUpdateCompanionBuilder,
      (
        ViewPessoaUsuario,
        BaseReferences<
          _$AppDatabase,
          $ViewPessoaUsuariosTable,
          ViewPessoaUsuario
        >,
      ),
      ViewPessoaUsuario,
      PrefetchHooks Function()
    >;

class $AppDatabaseManager {
  final _$AppDatabase _db;
  $AppDatabaseManager(this._db);
  $$WmsRecebimentoDetalhesTableTableManager get wmsRecebimentoDetalhes =>
      $$WmsRecebimentoDetalhesTableTableManager(
        _db,
        _db.wmsRecebimentoDetalhes,
      );
  $$WmsCaixasTableTableManager get wmsCaixas =>
      $$WmsCaixasTableTableManager(_db, _db.wmsCaixas);
  $$WmsOrdemSeparacaoDetsTableTableManager get wmsOrdemSeparacaoDets =>
      $$WmsOrdemSeparacaoDetsTableTableManager(_db, _db.wmsOrdemSeparacaoDets);
  $$WmsRecebimentoCabecalhosTableTableManager get wmsRecebimentoCabecalhos =>
      $$WmsRecebimentoCabecalhosTableTableManager(
        _db,
        _db.wmsRecebimentoCabecalhos,
      );
  $$WmsEstantesTableTableManager get wmsEstantes =>
      $$WmsEstantesTableTableManager(_db, _db.wmsEstantes);
  $$WmsOrdemSeparacaoCabsTableTableManager get wmsOrdemSeparacaoCabs =>
      $$WmsOrdemSeparacaoCabsTableTableManager(_db, _db.wmsOrdemSeparacaoCabs);
  $$ProdutosTableTableManager get produtos =>
      $$ProdutosTableTableManager(_db, _db.produtos);
  $$WmsAgendamentosTableTableManager get wmsAgendamentos =>
      $$WmsAgendamentosTableTableManager(_db, _db.wmsAgendamentos);
  $$WmsParametrosTableTableManager get wmsParametros =>
      $$WmsParametrosTableTableManager(_db, _db.wmsParametros);
  $$WmsRuasTableTableManager get wmsRuas =>
      $$WmsRuasTableTableManager(_db, _db.wmsRuas);
  $$WmsArmazenamentosTableTableManager get wmsArmazenamentos =>
      $$WmsArmazenamentosTableTableManager(_db, _db.wmsArmazenamentos);
  $$WmsExpedicaosTableTableManager get wmsExpedicaos =>
      $$WmsExpedicaosTableTableManager(_db, _db.wmsExpedicaos);
  $$ViewControleAcessosTableTableManager get viewControleAcessos =>
      $$ViewControleAcessosTableTableManager(_db, _db.viewControleAcessos);
  $$ViewPessoaUsuariosTableTableManager get viewPessoaUsuarios =>
      $$ViewPessoaUsuariosTableTableManager(_db, _db.viewPessoaUsuarios);
}
