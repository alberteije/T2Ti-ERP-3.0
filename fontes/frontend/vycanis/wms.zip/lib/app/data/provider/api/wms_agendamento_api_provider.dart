import 'package:wms/app/data/provider/api/api_provider_base.dart';
import 'package:wms/app/data/model/model_imports.dart';

class WmsAgendamentoApiProvider extends ApiProviderBase {
  static const _path = '/wms-agendamento';

  Future<List<WmsAgendamentoModel>?> getList({Filter? filter}) {
    return super.getListBase(
      '$_path/',
      (json) => WmsAgendamentoModel.fromJson(json),
      filter: filter,
    );
  }

  Future<WmsAgendamentoModel?> getObject(dynamic pk) {
    return super.getObjectBase(
      _path,
      pk,
      (json) => WmsAgendamentoModel.fromJson(json),
    );
  }

  Future<WmsAgendamentoModel?>? insert(WmsAgendamentoModel model) {
    return super.insertBase(
      _path,
      model,
      (json) => WmsAgendamentoModel.fromJson(json),
    );
  }

  Future<WmsAgendamentoModel?>? update(WmsAgendamentoModel model) {
    return super.updateBase(
      _path,
      model,
      (json) => WmsAgendamentoModel.fromJson(json),
    );
  }

  Future<bool?> delete(dynamic pk) {
    return super.deleteBase(_path, pk);
  }
}
