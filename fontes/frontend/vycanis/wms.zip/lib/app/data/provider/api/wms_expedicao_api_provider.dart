import 'package:wms/app/data/provider/api/api_provider_base.dart';
import 'package:wms/app/data/model/model_imports.dart';

class WmsExpedicaoApiProvider extends ApiProviderBase {
  static const _path = '/wms-expedicao';

  Future<List<WmsExpedicaoModel>?> getList({Filter? filter}) {
    return super.getListBase(
      '$_path/',
      (json) => WmsExpedicaoModel.fromJson(json),
      filter: filter,
    );
  }

  Future<WmsExpedicaoModel?> getObject(dynamic pk) {
    return super.getObjectBase(
      _path,
      pk,
      (json) => WmsExpedicaoModel.fromJson(json),
    );
  }

  Future<WmsExpedicaoModel?>? insert(WmsExpedicaoModel model) {
    return super.insertBase(
      _path,
      model,
      (json) => WmsExpedicaoModel.fromJson(json),
    );
  }

  Future<WmsExpedicaoModel?>? update(WmsExpedicaoModel model) {
    return super.updateBase(
      _path,
      model,
      (json) => WmsExpedicaoModel.fromJson(json),
    );
  }

  Future<bool?> delete(dynamic pk) {
    return super.deleteBase(_path, pk);
  }
}
