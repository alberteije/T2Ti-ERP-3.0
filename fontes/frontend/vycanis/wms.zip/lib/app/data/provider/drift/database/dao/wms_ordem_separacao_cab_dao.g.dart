// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'wms_ordem_separacao_cab_dao.dart';

// ignore_for_file: type=lint
mixin _$WmsOrdemSeparacaoCabDaoMixin on DatabaseAccessor<AppDatabase> {
  $WmsOrdemSeparacaoCabsTable get wmsOrdemSeparacaoCabs =>
      attachedDatabase.wmsOrdemSeparacaoCabs;
  $WmsOrdemSeparacaoDetsTable get wmsOrdemSeparacaoDets =>
      attachedDatabase.wmsOrdemSeparacaoDets;
  $ProdutosTable get produtos => attachedDatabase.produtos;
}
