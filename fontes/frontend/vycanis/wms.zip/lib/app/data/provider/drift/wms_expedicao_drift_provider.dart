import 'package:wms/app/data/provider/drift/database/database_imports.dart';
import 'package:wms/app/infra/infra_imports.dart';
import 'package:wms/app/data/provider/provider_base.dart';
import 'package:wms/app/data/provider/drift/database/database.dart';
import 'package:wms/app/data/model/model_imports.dart';
import 'package:wms/app/data/domain/domain_imports.dart';

class WmsExpedicaoDriftProvider extends ProviderBase {

	Future<List<WmsExpedicaoModel>?> getList({Filter? filter}) async {
		List<WmsExpedicaoGrouped> wmsExpedicaoDriftList = [];

		try {
			if (filter != null && filter.field != null) {
				wmsExpedicaoDriftList = await Session.database.wmsExpedicaoDao.getGroupedList(field: filter.field, value: filter.value!);
			} else {
				wmsExpedicaoDriftList = await Session.database.wmsExpedicaoDao.getGroupedList(); 
			}
			if (wmsExpedicaoDriftList.isNotEmpty) {
				return toListModel(wmsExpedicaoDriftList);
			} else {
				return [];
			}			 
		} catch (e) {
			handleResultError(null, null, exception: e);
			return null;
		}
	}

	Future<WmsExpedicaoModel?> getObject(dynamic pk) async {
		try {
			final result = await Session.database.wmsExpedicaoDao.getObjectGrouped(field: 'id', value: pk);
			return toModel(result);
		} catch (e) {
			handleResultError(null, null, exception: e);
		}
		return null;
	}

	Future<WmsExpedicaoModel?>? insert(WmsExpedicaoModel wmsExpedicaoModel) async {
		try {
			final lastPk = await Session.database.wmsExpedicaoDao.insertObject(toDrift(wmsExpedicaoModel));
			wmsExpedicaoModel.id = lastPk;
			return wmsExpedicaoModel;
		} catch (e) {
			handleResultError(null, null, exception: e);
		}
		return null;
	}

	Future<WmsExpedicaoModel?>? update(WmsExpedicaoModel wmsExpedicaoModel) async {
		try {
			await Session.database.wmsExpedicaoDao.updateObject(toDrift(wmsExpedicaoModel));
			return wmsExpedicaoModel;
		} catch (e) {
			handleResultError(null, null, exception: e);
		}
		return null;
	}

	Future<bool?> delete(dynamic pk) async {
		try {
			await Session.database.wmsExpedicaoDao.deleteObject(toDrift(WmsExpedicaoModel(id: pk)));
			return true;
		} catch (e) {
			handleResultError(null, null, exception: e);
		}
		return null;
	}	

	List<WmsExpedicaoModel> toListModel(List<WmsExpedicaoGrouped> wmsExpedicaoDriftList) {
		List<WmsExpedicaoModel> listModel = [];
		for (var wmsExpedicaoDrift in wmsExpedicaoDriftList) {
			listModel.add(toModel(wmsExpedicaoDrift)!);
		}
		return listModel;
	}	

	WmsExpedicaoModel? toModel(WmsExpedicaoGrouped? wmsExpedicaoDrift) {
		if (wmsExpedicaoDrift != null) {
			return WmsExpedicaoModel(
				id: wmsExpedicaoDrift.wmsExpedicao?.id,
				idProduto: wmsExpedicaoDrift.wmsExpedicao?.idProduto,
				quantidade: wmsExpedicaoDrift.wmsExpedicao?.quantidade,
				dataSaida: wmsExpedicaoDrift.wmsExpedicao?.dataSaida,
				horaSaida: wmsExpedicaoDrift.wmsExpedicao?.horaSaida,
				veioDeOnde: WmsExpedicaoDomain.getVeioDeOnde(wmsExpedicaoDrift.wmsExpedicao?.veioDeOnde),
				codigoSeparacaoRecebimento: wmsExpedicaoDrift.wmsExpedicao?.codigoSeparacaoRecebimento,
				produtoModel: ProdutoModel(
					id: wmsExpedicaoDrift.produto?.id,
					idTributIcmsCustomCab: wmsExpedicaoDrift.produto?.idTributIcmsCustomCab,
					idTributGrupoTributario: wmsExpedicaoDrift.produto?.idTributGrupoTributario,
					nome: wmsExpedicaoDrift.produto?.nome,
					descricao: wmsExpedicaoDrift.produto?.descricao,
					gtin: wmsExpedicaoDrift.produto?.gtin,
					codigoInterno: wmsExpedicaoDrift.produto?.codigoInterno,
					valorCompra: wmsExpedicaoDrift.produto?.valorCompra,
					valorVenda: wmsExpedicaoDrift.produto?.valorVenda,
					codigoNcm: wmsExpedicaoDrift.produto?.codigoNcm,
					estoqueMinimo: wmsExpedicaoDrift.produto?.estoqueMinimo,
					estoqueMaximo: wmsExpedicaoDrift.produto?.estoqueMaximo,
					quantidadeEstoque: wmsExpedicaoDrift.produto?.quantidadeEstoque,
					dataCadastro: wmsExpedicaoDrift.produto?.dataCadastro,
				),
			);
		} else {
			return null;
		}
	}


	WmsExpedicaoGrouped toDrift(WmsExpedicaoModel wmsExpedicaoModel) {
		return WmsExpedicaoGrouped(
			wmsExpedicao: WmsExpedicao(
				id: wmsExpedicaoModel.id,
				idProduto: wmsExpedicaoModel.idProduto,
				quantidade: wmsExpedicaoModel.quantidade,
				dataSaida: wmsExpedicaoModel.dataSaida,
				horaSaida: Util.removeMask(wmsExpedicaoModel.horaSaida),
				veioDeOnde: WmsExpedicaoDomain.setVeioDeOnde(wmsExpedicaoModel.veioDeOnde),
				codigoSeparacaoRecebimento: wmsExpedicaoModel.codigoSeparacaoRecebimento,
			),
		);
	}

		
}
