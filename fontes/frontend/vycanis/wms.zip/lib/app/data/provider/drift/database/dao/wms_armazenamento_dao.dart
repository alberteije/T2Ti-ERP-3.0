import 'package:drift/drift.dart';
import 'package:wms/app/data/provider/drift/database/database.dart';
import 'package:wms/app/data/provider/drift/database/database_imports.dart';

part 'wms_armazenamento_dao.g.dart';

@DriftAccessor(tables: [
	WmsArmazenamentos,
	WmsCaixas,
	WmsRecebimentoCabecalhos,
	Produtos,
])
class WmsArmazenamentoDao extends DatabaseAccessor<AppDatabase> with _$WmsArmazenamentoDaoMixin {
	final AppDatabase db;

	List<WmsArmazenamento> wmsArmazenamentoList = []; 
	List<WmsArmazenamentoGrouped> wmsArmazenamentoGroupedList = []; 

	WmsArmazenamentoDao(this.db) : super(db);

	Future<List<WmsArmazenamento>> getList() async {
		wmsArmazenamentoList = await select(wmsArmazenamentos).get();
		return wmsArmazenamentoList;
	}

	Future<List<WmsArmazenamento>> getListFilter(String field, String value) async {
		final query = " $field like '%$value%'";
		final expression = CustomExpression<bool>(query);
		wmsArmazenamentoList = await (select(wmsArmazenamentos)..where((t) => expression)).get();
		return wmsArmazenamentoList;	 
	}

	Future<List<WmsArmazenamentoGrouped>> getGroupedList({String? field, dynamic value}) async {
		final query = select(wmsArmazenamentos)
			.join([ 
				leftOuterJoin(wmsCaixas, wmsCaixas.id.equalsExp(wmsArmazenamentos.idWmsCaixa)), 
			]).join([ 
				leftOuterJoin(wmsRecebimentoCabecalhos, wmsRecebimentoCabecalhos.id.equalsExp(wmsArmazenamentos.idWmsRecebimentoCabecalho)), 
			]).join([ 
				leftOuterJoin(produtos, produtos.id.equalsExp(wmsArmazenamentos.idProduto)), 
			]);

		if (field != null && field != '') { 
			final column = wmsArmazenamentos.$columns.where(((column) => column.$name == field)).first;
			if (column is TextColumn) {
				query.where((column as TextColumn).like('%$value%'));
			} else if (column is IntColumn) {
				query.where(column.equals(int.tryParse(value) as Object));
			} else if (column is RealColumn) {
				query.where(column.equals(double.tryParse(value) as Object));
			}
		}

		wmsArmazenamentoGroupedList = await query.map((row) {
			final wmsArmazenamento = row.readTableOrNull(wmsArmazenamentos); 
			final wmsCaixa = row.readTableOrNull(wmsCaixas); 
			final wmsRecebimentoCabecalho = row.readTableOrNull(wmsRecebimentoCabecalhos); 
			final produto = row.readTableOrNull(produtos); 

			return WmsArmazenamentoGrouped(
				wmsArmazenamento: wmsArmazenamento, 
				wmsCaixa: wmsCaixa, 
				wmsRecebimentoCabecalho: wmsRecebimentoCabecalho, 
				produto: produto, 

			);
		}).get();

		// fill internal lists
		//dynamic expression;
		//for (var wmsArmazenamentoGrouped in wmsArmazenamentoGroupedList) {
		//}		

		return wmsArmazenamentoGroupedList;	
	}

	Future<WmsArmazenamento?> getObject(dynamic pk) async {
		return await (select(wmsArmazenamentos)..where((t) => t.id.equals(pk))).getSingleOrNull();
	} 

	Future<WmsArmazenamento?> getObjectFilter(String field, String value) async {
		final query = "SELECT * FROM wms_armazenamento WHERE $field like '%$value%'";
		return (await customSelect(query).getSingleOrNull()) as WmsArmazenamento;		 
	} 

	Future<WmsArmazenamentoGrouped?> getObjectGrouped({String? field, dynamic value}) async {
		final result = await getGroupedList(field: field, value: value);

		if (result.length != 1) {
			return null;
		} else {
			return result[0];
		} 
	}

	Future<int> insertObject(WmsArmazenamentoGrouped object) {
		return transaction(() async {
			final maxPk = await lastPk();
			object.wmsArmazenamento = object.wmsArmazenamento!.copyWith(id: Value(maxPk + 1));
			final pkInserted = await into(wmsArmazenamentos).insert(object.wmsArmazenamento!);
			object.wmsArmazenamento = object.wmsArmazenamento!.copyWith(id: Value(pkInserted));			 
			await insertChildren(object);
			return pkInserted;
		});		
	}	 

	Future<bool> updateObject(WmsArmazenamentoGrouped object) {
		return transaction(() async {
			await deleteChildren(object);
			await insertChildren(object);
			return update(wmsArmazenamentos).replace(object.wmsArmazenamento!);
		});	 
	} 

	Future<int> deleteObject(WmsArmazenamentoGrouped object) {
		return transaction(() async {
			await deleteChildren(object);
			return delete(wmsArmazenamentos).delete(object.wmsArmazenamento!);
		});		
	}

	Future<void> insertChildren(WmsArmazenamentoGrouped object) async {
	}
	
	Future<void> deleteChildren(WmsArmazenamentoGrouped object) async {
	}

	Future<int> lastPk() async {
		final result = await customSelect("select MAX(id) as LAST from wms_armazenamento").getSingleOrNull();
		return result?.data["LAST"] ?? 0;
	} 
}