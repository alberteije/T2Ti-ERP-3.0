import 'package:drift/drift.dart';
import 'package:wms/app/data/provider/drift/database/database.dart';

@DataClassName("WmsArmazenamento")
class WmsArmazenamentos extends Table {
	@override
	String get tableName => 'wms_armazenamento';

	IntColumn get id => integer().named('id').nullable()();
	IntColumn get idWmsRecebimentoCabecalho => integer().named('id_wms_recebimento_cabecalho').nullable()();
	IntColumn get idProduto => integer().named('id_produto').nullable()();
	IntColumn get idWmsCaixa => integer().named('id_wms_caixa').nullable()();
	IntColumn get quantidade => integer().named('quantidade').nullable()();
	DateTimeColumn get dataArmazenagem => dateTime().named('data_armazenagem').nullable()();
	TextColumn get horaArmazenagem => text().named('hora_armazenagem').withLength(min: 0, max: 8).nullable()();

	@override
	Set<Column> get primaryKey => { id };	
	
}

class WmsArmazenamentoGrouped {
	WmsArmazenamento? wmsArmazenamento; 
	WmsCaixa? wmsCaixa; 
	WmsRecebimentoCabecalho? wmsRecebimentoCabecalho; 
	Produto? produto; 

  WmsArmazenamentoGrouped({
		this.wmsArmazenamento, 
		this.wmsCaixa, 
		this.wmsRecebimentoCabecalho, 
		this.produto, 

  });
}
