import 'package:drift/drift.dart';
import 'package:wms/app/data/provider/drift/database/database.dart';

@DataClassName("WmsExpedicao")
class WmsExpedicaos extends Table {
	@override
	String get tableName => 'wms_expedicao';

	IntColumn get id => integer().named('id').nullable()();
	IntColumn get idProduto => integer().named('id_produto').nullable()();
	IntColumn get quantidade => integer().named('quantidade').nullable()();
	DateTimeColumn get dataSaida => dateTime().named('data_saida').nullable()();
	TextColumn get horaSaida => text().named('hora_saida').withLength(min: 0, max: 8).nullable()();
	TextColumn get veioDeOnde => text().named('veio_de_onde').withLength(min: 0, max: 1).nullable()();
	TextColumn get codigoSeparacaoRecebimento => text().named('codigo_separacao_recebimento').withLength(min: 0, max: 32).nullable()();

	@override
	Set<Column> get primaryKey => { id };	
	
}

class WmsExpedicaoGrouped {
	WmsExpedicao? wmsExpedicao; 
	Produto? produto; 

  WmsExpedicaoGrouped({
		this.wmsExpedicao, 
		this.produto, 

  });
}
