// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'wms_parametro_dao.dart';

// ignore_for_file: type=lint
mixin _$WmsParametroDaoMixin on DatabaseAccessor<AppDatabase> {
  $WmsParametrosTable get wmsParametros => attachedDatabase.wmsParametros;
}
