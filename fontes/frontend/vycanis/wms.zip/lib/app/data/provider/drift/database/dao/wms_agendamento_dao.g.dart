// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'wms_agendamento_dao.dart';

// ignore_for_file: type=lint
mixin _$WmsAgendamentoDaoMixin on DatabaseAccessor<AppDatabase> {
  $WmsAgendamentosTable get wmsAgendamentos => attachedDatabase.wmsAgendamentos;
}
