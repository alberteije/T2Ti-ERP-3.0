// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'wms_expedicao_dao.dart';

// ignore_for_file: type=lint
mixin _$WmsExpedicaoDaoMixin on DatabaseAccessor<AppDatabase> {
  $WmsExpedicaosTable get wmsExpedicaos => attachedDatabase.wmsExpedicaos;
  $ProdutosTable get produtos => attachedDatabase.produtos;
}
