// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'wms_armazenamento_dao.dart';

// ignore_for_file: type=lint
mixin _$WmsArmazenamentoDaoMixin on DatabaseAccessor<AppDatabase> {
  $WmsArmazenamentosTable get wmsArmazenamentos =>
      attachedDatabase.wmsArmazenamentos;
  $WmsCaixasTable get wmsCaixas => attachedDatabase.wmsCaixas;
  $WmsRecebimentoCabecalhosTable get wmsRecebimentoCabecalhos =>
      attachedDatabase.wmsRecebimentoCabecalhos;
  $ProdutosTable get produtos => attachedDatabase.produtos;
}
