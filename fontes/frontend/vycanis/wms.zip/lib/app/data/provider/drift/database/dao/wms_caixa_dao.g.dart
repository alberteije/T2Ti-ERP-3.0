// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'wms_caixa_dao.dart';

// ignore_for_file: type=lint
mixin _$WmsCaixaDaoMixin on DatabaseAccessor<AppDatabase> {
  $WmsCaixasTable get wmsCaixas => attachedDatabase.wmsCaixas;
  $WmsArmazenamentosTable get wmsArmazenamentos =>
      attachedDatabase.wmsArmazenamentos;
  $WmsRecebimentoDetalhesTable get wmsRecebimentoDetalhes =>
      attachedDatabase.wmsRecebimentoDetalhes;
  $WmsEstantesTable get wmsEstantes => attachedDatabase.wmsEstantes;
}
