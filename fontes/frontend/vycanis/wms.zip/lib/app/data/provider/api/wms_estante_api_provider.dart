import 'package:wms/app/data/provider/api/api_provider_base.dart';
import 'package:wms/app/data/model/model_imports.dart';

class WmsEstanteApiProvider extends ApiProviderBase {
  static const _path = '/wms-estante';

  Future<List<WmsEstanteModel>?> getList({Filter? filter}) {
    return super.getListBase(
      '$_path/',
      (json) => WmsEstanteModel.fromJson(json),
      filter: filter,
    );
  }

  Future<WmsEstanteModel?> getObject(dynamic pk) {
    return super.getObjectBase(
      _path,
      pk,
      (json) => WmsEstanteModel.fromJson(json),
    );
  }

  Future<WmsEstanteModel?>? insert(WmsEstanteModel model) {
    return super.insertBase(
      _path,
      model,
      (json) => WmsEstanteModel.fromJson(json),
    );
  }

  Future<WmsEstanteModel?>? update(WmsEstanteModel model) {
    return super.updateBase(
      _path,
      model,
      (json) => WmsEstanteModel.fromJson(json),
    );
  }

  Future<bool?> delete(dynamic pk) {
    return super.deleteBase(_path, pk);
  }
}
