// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'wms_rua_dao.dart';

// ignore_for_file: type=lint
mixin _$WmsRuaDaoMixin on DatabaseAccessor<AppDatabase> {
  $WmsRuasTable get wmsRuas => attachedDatabase.wmsRuas;
}
