import 'package:wms/app/data/provider/api/api_provider_base.dart';
import 'package:wms/app/data/model/model_imports.dart';

class WmsOrdemSeparacaoCabApiProvider extends ApiProviderBase {
  static const _path = '/wms-ordem-separacao-cab';

  Future<List<WmsOrdemSeparacaoCabModel>?> getList({Filter? filter}) {
    return super.getListBase(
      '$_path/',
      (json) => WmsOrdemSeparacaoCabModel.fromJson(json),
      filter: filter,
    );
  }

  Future<WmsOrdemSeparacaoCabModel?> getObject(dynamic pk) {
    return super.getObjectBase(
      _path,
      pk,
      (json) => WmsOrdemSeparacaoCabModel.fromJson(json),
    );
  }

  Future<WmsOrdemSeparacaoCabModel?>? insert(WmsOrdemSeparacaoCabModel model) {
    return super.insertBase(
      _path,
      model,
      (json) => WmsOrdemSeparacaoCabModel.fromJson(json),
    );
  }

  Future<WmsOrdemSeparacaoCabModel?>? update(WmsOrdemSeparacaoCabModel model) {
    return super.updateBase(
      _path,
      model,
      (json) => WmsOrdemSeparacaoCabModel.fromJson(json),
    );
  }

  Future<bool?> delete(dynamic pk) {
    return super.deleteBase(_path, pk);
  }
}
