import 'package:wms/app/data/provider/api/api_provider_base.dart';
import 'package:wms/app/data/model/model_imports.dart';

class WmsRuaApiProvider extends ApiProviderBase {
  static const _path = '/wms-rua';

  Future<List<WmsRuaModel>?> getList({Filter? filter}) {
    return super.getListBase(
      '$_path/',
      (json) => WmsRuaModel.fromJson(json),
      filter: filter,
    );
  }

  Future<WmsRuaModel?> getObject(dynamic pk) {
    return super.getObjectBase(
      _path,
      pk,
      (json) => WmsRuaModel.fromJson(json),
    );
  }

  Future<WmsRuaModel?>? insert(WmsRuaModel model) {
    return super.insertBase(
      _path,
      model,
      (json) => WmsRuaModel.fromJson(json),
    );
  }

  Future<WmsRuaModel?>? update(WmsRuaModel model) {
    return super.updateBase(
      _path,
      model,
      (json) => WmsRuaModel.fromJson(json),
    );
  }

  Future<bool?> delete(dynamic pk) {
    return super.deleteBase(_path, pk);
  }
}
