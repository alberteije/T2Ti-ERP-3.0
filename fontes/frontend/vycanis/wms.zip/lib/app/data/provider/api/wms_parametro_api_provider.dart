import 'package:wms/app/data/provider/api/api_provider_base.dart';
import 'package:wms/app/data/model/model_imports.dart';

class WmsParametroApiProvider extends ApiProviderBase {
  static const _path = '/wms-parametro';

  Future<List<WmsParametroModel>?> getList({Filter? filter}) {
    return super.getListBase(
      '$_path/',
      (json) => WmsParametroModel.fromJson(json),
      filter: filter,
    );
  }

  Future<WmsParametroModel?> getObject(dynamic pk) {
    return super.getObjectBase(
      _path,
      pk,
      (json) => WmsParametroModel.fromJson(json),
    );
  }

  Future<WmsParametroModel?>? insert(WmsParametroModel model) {
    return super.insertBase(
      _path,
      model,
      (json) => WmsParametroModel.fromJson(json),
    );
  }

  Future<WmsParametroModel?>? update(WmsParametroModel model) {
    return super.updateBase(
      _path,
      model,
      (json) => WmsParametroModel.fromJson(json),
    );
  }

  Future<bool?> delete(dynamic pk) {
    return super.deleteBase(_path, pk);
  }
}
