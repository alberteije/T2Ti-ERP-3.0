import 'package:wms/app/data/provider/api/api_provider_base.dart';
import 'package:wms/app/data/model/model_imports.dart';

class WmsRecebimentoCabecalhoApiProvider extends ApiProviderBase {
  static const _path = '/wms-recebimento-cabecalho';

  Future<List<WmsRecebimentoCabecalhoModel>?> getList({Filter? filter}) {
    return super.getListBase(
      '$_path/',
      (json) => WmsRecebimentoCabecalhoModel.fromJson(json),
      filter: filter,
    );
  }

  Future<WmsRecebimentoCabecalhoModel?> getObject(dynamic pk) {
    return super.getObjectBase(
      _path,
      pk,
      (json) => WmsRecebimentoCabecalhoModel.fromJson(json),
    );
  }

  Future<WmsRecebimentoCabecalhoModel?>? insert(WmsRecebimentoCabecalhoModel model) {
    return super.insertBase(
      _path,
      model,
      (json) => WmsRecebimentoCabecalhoModel.fromJson(json),
    );
  }

  Future<WmsRecebimentoCabecalhoModel?>? update(WmsRecebimentoCabecalhoModel model) {
    return super.updateBase(
      _path,
      model,
      (json) => WmsRecebimentoCabecalhoModel.fromJson(json),
    );
  }

  Future<bool?> delete(dynamic pk) {
    return super.deleteBase(_path, pk);
  }
}
