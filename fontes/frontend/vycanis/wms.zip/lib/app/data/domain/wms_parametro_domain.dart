class WmsParametroDomain {
  WmsParametroDomain._();

  static getItemDiferenteCaixa(String? itemDiferenteCaixa) { 
		switch (itemDiferenteCaixa) { 
			case '': 
			case 'S': 
				return 'Sim'; 
			case 'N': 
				return 'Não'; 
			default: 
				return null; 
		} 
	} 

  static setItemDiferenteCaixa(String? itemDiferenteCaixa) { 
		switch (itemDiferenteCaixa) { 
			case 'Sim': 
				return 'S'; 
			case 'Não': 
				return 'N'; 
			default: 
				return null; 
		} 
	}


  static final itemDiferenteCaixaListDropdown = ['Sim','Não'];

}