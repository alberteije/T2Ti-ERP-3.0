class WmsRecebimentoCabecalhoDomain {
  WmsRecebimentoCabecalhoDomain._();

  static getInconsistencia(String? inconsistencia) { 
		switch (inconsistencia) { 
			case '': 
			case 'S': 
				return 'Sim'; 
			case 'N': 
				return 'Não'; 
			default: 
				return null; 
		} 
	} 

  static setInconsistencia(String? inconsistencia) { 
		switch (inconsistencia) { 
			case 'Sim': 
				return 'S'; 
			case 'Não': 
				return 'N'; 
			default: 
				return null; 
		} 
	}


  static final inconsistenciaListDropdown = ['Sim','Não'];

}