class WmsExpedicaoDomain {
  WmsExpedicaoDomain._();

  static getVeioDeOnde(String? veioDeOnde) { 
		switch (veioDeOnde) { 
			case '': 
			case 'R': 
				return 'Recebimento'; 
			case 'S': 
				return 'Separação'; 
			default: 
				return null; 
		} 
	} 

  static setVeioDeOnde(String? veioDeOnde) { 
		switch (veioDeOnde) { 
			case 'Recebimento': 
				return 'R'; 
			case 'Separação': 
				return 'S'; 
			default: 
				return null; 
		} 
	}


  static final veioDeOndeListDropdown = ['Recebimento','Separação'];

}