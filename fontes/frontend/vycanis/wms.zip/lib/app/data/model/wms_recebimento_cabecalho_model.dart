import 'dart:convert';
import 'package:pluto_grid/pluto_grid.dart';
import 'package:wms/app/data/model/model_imports.dart';

import 'package:wms/app/infra/infra_imports.dart';
import 'package:intl/intl.dart';
import 'package:wms/app/data/domain/domain_imports.dart';

class WmsRecebimentoCabecalhoModel extends ModelBase {
  int? id;
  int? idWmsAgendamento;
  DateTime? dataRecebimento;
  String? horaInicio;
  String? horaFim;
  int? volumeRecebido;
  double? pesoRecebido;
  String? inconsistencia;
  String? codigoRecebimento;
  String? observacao;
  List<WmsRecebimentoDetalheModel>? wmsRecebimentoDetalheModelList;
  WmsAgendamentoModel? wmsAgendamentoModel;

  WmsRecebimentoCabecalhoModel({
    this.id,
    this.idWmsAgendamento,
    this.dataRecebimento,
    this.horaInicio,
    this.horaFim,
    this.volumeRecebido,
    this.pesoRecebido,
    this.inconsistencia = 'Sim',
    this.codigoRecebimento,
    this.observacao,
    List<WmsRecebimentoDetalheModel>? wmsRecebimentoDetalheModelList,
    WmsAgendamentoModel? wmsAgendamentoModel,
  }) {
    this.wmsRecebimentoDetalheModelList = wmsRecebimentoDetalheModelList?.toList(growable: true) ?? [];
    this.wmsAgendamentoModel = wmsAgendamentoModel ?? WmsAgendamentoModel();
  }

  static List<String> dbColumns = <String>[
    'id',
    'data_recebimento',
    'hora_inicio',
    'hora_fim',
    'volume_recebido',
    'peso_recebido',
    'inconsistencia',
    'codigo_recebimento',
    'observacao',
  ];

  static List<String> aliasColumns = <String>[
    'Id',
    'Data Recebimento',
    'Hora Inicio',
    'Hora Fim',
    'Volume Recebido',
    'Peso Recebido',
    'Inconsistencia',
    'Codigo Recebimento',
    'Observacao',
  ];

  WmsRecebimentoCabecalhoModel.fromJson(Map<String, dynamic> jsonData) {
    id = jsonData['id'];
    idWmsAgendamento = jsonData['idWmsAgendamento'];
    dataRecebimento = jsonData['dataRecebimento'] != null ? DateTime.tryParse(jsonData['dataRecebimento']) : null;
    horaInicio = jsonData['horaInicio'];
    horaFim = jsonData['horaFim'];
    volumeRecebido = jsonData['volumeRecebido'];
    pesoRecebido = jsonData['pesoRecebido']?.toDouble();
    inconsistencia = WmsRecebimentoCabecalhoDomain.getInconsistencia(jsonData['inconsistencia']);
    codigoRecebimento = jsonData['codigoRecebimento'];
    observacao = jsonData['observacao'];
    wmsRecebimentoDetalheModelList = (jsonData['wmsRecebimentoDetalheModelList'] as Iterable?)?.map((m) => WmsRecebimentoDetalheModel.fromJson(m)).toList() ?? [];
    wmsAgendamentoModel = jsonData['wmsAgendamentoModel'] == null ? WmsAgendamentoModel() : WmsAgendamentoModel.fromJson(jsonData['wmsAgendamentoModel']);
  }

  Map<String, dynamic> get toJson {
    Map<String, dynamic> jsonData = <String, dynamic>{};

    jsonData['id'] = id != 0 ? id : null;
    jsonData['idWmsAgendamento'] = idWmsAgendamento != 0 ? idWmsAgendamento : null;
    jsonData['dataRecebimento'] = dataRecebimento != null ? DateFormat('yyyy-MM-ddT00:00:00').format(dataRecebimento!) : null;
    jsonData['horaInicio'] = Util.removeMask(horaInicio);
    jsonData['horaFim'] = Util.removeMask(horaFim);
    jsonData['volumeRecebido'] = volumeRecebido;
    jsonData['pesoRecebido'] = pesoRecebido;
    jsonData['inconsistencia'] = WmsRecebimentoCabecalhoDomain.setInconsistencia(inconsistencia);
    jsonData['codigoRecebimento'] = codigoRecebimento;
    jsonData['observacao'] = observacao;
    
		var wmsRecebimentoDetalheModelLocalList = []; 
		for (WmsRecebimentoDetalheModel object in wmsRecebimentoDetalheModelList ?? []) { 
			wmsRecebimentoDetalheModelLocalList.add(object.toJson); 
		}
		jsonData['wmsRecebimentoDetalheModelList'] = wmsRecebimentoDetalheModelLocalList;
    jsonData['wmsAgendamentoModel'] = wmsAgendamentoModel?.toJson;
    jsonData['wmsAgendamento'] = wmsAgendamentoModel?.localOperacao ?? '';

    return jsonData;
  }

  String objectEncodeJson() {
    final jsonData = toJson;
    return json.encode(jsonData);
  }

  static WmsRecebimentoCabecalhoModel fromPlutoRow(PlutoRow row) {
    return WmsRecebimentoCabecalhoModel(
      id: row.cells['id']?.value,
      idWmsAgendamento: row.cells['idWmsAgendamento']?.value,
      dataRecebimento: Util.stringToDate(row.cells['dataRecebimento']?.value),
      horaInicio: row.cells['horaInicio']?.value,
      horaFim: row.cells['horaFim']?.value,
      volumeRecebido: row.cells['volumeRecebido']?.value,
      pesoRecebido: row.cells['pesoRecebido']?.value,
      inconsistencia: row.cells['inconsistencia']?.value,
      codigoRecebimento: row.cells['codigoRecebimento']?.value,
      observacao: row.cells['observacao']?.value,
    );
  }

  PlutoRow toPlutoRow() {
    return PlutoRow(
      cells: {
        'tempId': PlutoCell(value: tempId),
        'id': PlutoCell(value: id ?? 0),
        'idWmsAgendamento': PlutoCell(value: idWmsAgendamento ?? 0),
        'dataRecebimento': PlutoCell(value: dataRecebimento),
        'horaInicio': PlutoCell(value: horaInicio ?? ''),
        'horaFim': PlutoCell(value: horaFim ?? ''),
        'volumeRecebido': PlutoCell(value: volumeRecebido ?? 0),
        'pesoRecebido': PlutoCell(value: pesoRecebido ?? 0.0),
        'inconsistencia': PlutoCell(value: inconsistencia ?? ''),
        'codigoRecebimento': PlutoCell(value: codigoRecebimento ?? ''),
        'observacao': PlutoCell(value: observacao ?? ''),
        'wmsAgendamento': PlutoCell(value: wmsAgendamentoModel?.localOperacao ?? ''),
      },
    );
  }

  WmsRecebimentoCabecalhoModel clone() {
    return WmsRecebimentoCabecalhoModel(
      id: id,
      idWmsAgendamento: idWmsAgendamento,
      dataRecebimento: dataRecebimento,
      horaInicio: horaInicio,
      horaFim: horaFim,
      volumeRecebido: volumeRecebido,
      pesoRecebido: pesoRecebido,
      inconsistencia: inconsistencia,
      codigoRecebimento: codigoRecebimento,
      observacao: observacao,
      wmsRecebimentoDetalheModelList: wmsRecebimentoDetalheModelListClone(wmsRecebimentoDetalheModelList!),
      wmsAgendamentoModel: wmsAgendamentoModel?.clone(),
    );
  }

  wmsRecebimentoDetalheModelListClone(List<WmsRecebimentoDetalheModel> wmsRecebimentoDetalheModelList) { 
		List<WmsRecebimentoDetalheModel> resultList = [];
		for (var wmsRecebimentoDetalheModel in wmsRecebimentoDetalheModelList) {
			resultList.add(wmsRecebimentoDetalheModel.clone());
		}
		return resultList;
	}


}