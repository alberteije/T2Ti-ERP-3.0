import 'dart:convert';
import 'package:pluto_grid/pluto_grid.dart';
import 'package:wms/app/data/model/model_imports.dart';


class WmsCaixaModel extends ModelBase {
  int? id;
  int? idWmsEstante;
  String? codigo;
  int? altura;
  int? largura;
  int? profundidade;

  WmsCaixaModel({
    this.id,
    this.idWmsEstante,
    this.codigo,
    this.altura,
    this.largura,
    this.profundidade,
  });

  static List<String> dbColumns = <String>[
    'id',
    'codigo',
    'altura',
    'largura',
    'profundidade',
  ];

  static List<String> aliasColumns = <String>[
    'Id',
    'Codigo',
    'Altura',
    'Largura',
    'Profundidade',
  ];

  WmsCaixaModel.fromJson(Map<String, dynamic> jsonData) {
    id = jsonData['id'];
    idWmsEstante = jsonData['idWmsEstante'];
    codigo = jsonData['codigo'];
    altura = jsonData['altura'];
    largura = jsonData['largura'];
    profundidade = jsonData['profundidade'];
  }

  Map<String, dynamic> get toJson {
    Map<String, dynamic> jsonData = <String, dynamic>{};

    jsonData['id'] = id != 0 ? id : null;
    jsonData['idWmsEstante'] = idWmsEstante != 0 ? idWmsEstante : null;
    jsonData['codigo'] = codigo;
    jsonData['altura'] = altura;
    jsonData['largura'] = largura;
    jsonData['profundidade'] = profundidade;

    return jsonData;
  }

  String objectEncodeJson() {
    final jsonData = toJson;
    return json.encode(jsonData);
  }

  static WmsCaixaModel fromPlutoRow(PlutoRow row) {
    return WmsCaixaModel(
      id: row.cells['id']?.value,
      idWmsEstante: row.cells['idWmsEstante']?.value,
      codigo: row.cells['codigo']?.value,
      altura: row.cells['altura']?.value,
      largura: row.cells['largura']?.value,
      profundidade: row.cells['profundidade']?.value,
    );
  }

  PlutoRow toPlutoRow() {
    return PlutoRow(
      cells: {
        'tempId': PlutoCell(value: tempId),
        'id': PlutoCell(value: id ?? 0),
        'idWmsEstante': PlutoCell(value: idWmsEstante ?? 0),
        'codigo': PlutoCell(value: codigo ?? ''),
        'altura': PlutoCell(value: altura ?? 0),
        'largura': PlutoCell(value: largura ?? 0),
        'profundidade': PlutoCell(value: profundidade ?? 0),
      },
    );
  }

  WmsCaixaModel clone() {
    return WmsCaixaModel(
      id: id,
      idWmsEstante: idWmsEstante,
      codigo: codigo,
      altura: altura,
      largura: largura,
      profundidade: profundidade,
    );
  }


}