import 'dart:convert';
import 'package:pluto_grid/pluto_grid.dart';
import 'package:wms/app/data/model/model_imports.dart';

import 'package:wms/app/infra/infra_imports.dart';
import 'package:intl/intl.dart';
import 'package:wms/app/data/domain/domain_imports.dart';

class WmsExpedicaoModel extends ModelBase {
  int? id;
  int? idProduto;
  int? quantidade;
  DateTime? dataSaida;
  String? horaSaida;
  String? veioDeOnde;
  String? codigoSeparacaoRecebimento;
  ProdutoModel? produtoModel;

  WmsExpedicaoModel({
    this.id,
    this.idProduto,
    this.quantidade,
    this.dataSaida,
    this.horaSaida,
    this.veioDeOnde = 'Recebimento',
    this.codigoSeparacaoRecebimento,
    ProdutoModel? produtoModel,
  }) {
    this.produtoModel = produtoModel ?? ProdutoModel();
  }

  static List<String> dbColumns = <String>[
    'id',
    'quantidade',
    'data_saida',
    'hora_saida',
    'veio_de_onde',
    'codigo_separacao_recebimento',
  ];

  static List<String> aliasColumns = <String>[
    'Id',
    'Quantidade',
    'Data Saida',
    'Hora Saida',
    'Veio De Onde',
    'Codigo Separacao Recebimento',
  ];

  WmsExpedicaoModel.fromJson(Map<String, dynamic> jsonData) {
    id = jsonData['id'];
    idProduto = jsonData['idProduto'];
    quantidade = jsonData['quantidade'];
    dataSaida = jsonData['dataSaida'] != null ? DateTime.tryParse(jsonData['dataSaida']) : null;
    horaSaida = jsonData['horaSaida'];
    veioDeOnde = WmsExpedicaoDomain.getVeioDeOnde(jsonData['veioDeOnde']);
    codigoSeparacaoRecebimento = jsonData['codigoSeparacaoRecebimento'];
    produtoModel = jsonData['produtoModel'] == null ? ProdutoModel() : ProdutoModel.fromJson(jsonData['produtoModel']);
  }

  Map<String, dynamic> get toJson {
    Map<String, dynamic> jsonData = <String, dynamic>{};

    jsonData['id'] = id != 0 ? id : null;
    jsonData['idProduto'] = idProduto != 0 ? idProduto : null;
    jsonData['quantidade'] = quantidade;
    jsonData['dataSaida'] = dataSaida != null ? DateFormat('yyyy-MM-ddT00:00:00').format(dataSaida!) : null;
    jsonData['horaSaida'] = Util.removeMask(horaSaida);
    jsonData['veioDeOnde'] = WmsExpedicaoDomain.setVeioDeOnde(veioDeOnde);
    jsonData['codigoSeparacaoRecebimento'] = codigoSeparacaoRecebimento;
    jsonData['produtoModel'] = produtoModel?.toJson;
    jsonData['produto'] = produtoModel?.nome ?? '';

    return jsonData;
  }

  String objectEncodeJson() {
    final jsonData = toJson;
    return json.encode(jsonData);
  }

  static WmsExpedicaoModel fromPlutoRow(PlutoRow row) {
    return WmsExpedicaoModel(
      id: row.cells['id']?.value,
      idProduto: row.cells['idProduto']?.value,
      quantidade: row.cells['quantidade']?.value,
      dataSaida: Util.stringToDate(row.cells['dataSaida']?.value),
      horaSaida: row.cells['horaSaida']?.value,
      veioDeOnde: row.cells['veioDeOnde']?.value,
      codigoSeparacaoRecebimento: row.cells['codigoSeparacaoRecebimento']?.value,
    );
  }

  PlutoRow toPlutoRow() {
    return PlutoRow(
      cells: {
        'tempId': PlutoCell(value: tempId),
        'id': PlutoCell(value: id ?? 0),
        'idProduto': PlutoCell(value: idProduto ?? 0),
        'quantidade': PlutoCell(value: quantidade ?? 0),
        'dataSaida': PlutoCell(value: dataSaida),
        'horaSaida': PlutoCell(value: horaSaida ?? ''),
        'veioDeOnde': PlutoCell(value: veioDeOnde ?? ''),
        'codigoSeparacaoRecebimento': PlutoCell(value: codigoSeparacaoRecebimento ?? ''),
        'produto': PlutoCell(value: produtoModel?.nome ?? ''),
      },
    );
  }

  WmsExpedicaoModel clone() {
    return WmsExpedicaoModel(
      id: id,
      idProduto: idProduto,
      quantidade: quantidade,
      dataSaida: dataSaida,
      horaSaida: horaSaida,
      veioDeOnde: veioDeOnde,
      codigoSeparacaoRecebimento: codigoSeparacaoRecebimento,
      produtoModel: produtoModel?.clone(),
    );
  }


}