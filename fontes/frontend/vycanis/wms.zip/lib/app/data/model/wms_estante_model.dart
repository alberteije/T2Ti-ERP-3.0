import 'dart:convert';
import 'package:pluto_grid/pluto_grid.dart';
import 'package:wms/app/data/model/model_imports.dart';


class WmsEstanteModel extends ModelBase {
  int? id;
  int? idWmsRua;
  String? codigo;
  int? quantidadeCaixa;
  WmsRuaModel? wmsRuaModel;
  List<WmsCaixaModel>? wmsCaixaModelList;

  WmsEstanteModel({
    this.id,
    this.idWmsRua,
    this.codigo,
    this.quantidadeCaixa,
    WmsRuaModel? wmsRuaModel,
    List<WmsCaixaModel>? wmsCaixaModelList,
  }) {
    this.wmsRuaModel = wmsRuaModel ?? WmsRuaModel();
    this.wmsCaixaModelList = wmsCaixaModelList?.toList(growable: true) ?? [];
  }

  static List<String> dbColumns = <String>[
    'id',
    'codigo',
    'quantidade_caixa',
  ];

  static List<String> aliasColumns = <String>[
    'Id',
    'Codigo',
    'Quantidade Caixa',
  ];

  WmsEstanteModel.fromJson(Map<String, dynamic> jsonData) {
    id = jsonData['id'];
    idWmsRua = jsonData['idWmsRua'];
    codigo = jsonData['codigo'];
    quantidadeCaixa = jsonData['quantidadeCaixa'];
    wmsRuaModel = jsonData['wmsRuaModel'] == null ? WmsRuaModel() : WmsRuaModel.fromJson(jsonData['wmsRuaModel']);
    wmsCaixaModelList = (jsonData['wmsCaixaModelList'] as Iterable?)?.map((m) => WmsCaixaModel.fromJson(m)).toList() ?? [];
  }

  Map<String, dynamic> get toJson {
    Map<String, dynamic> jsonData = <String, dynamic>{};

    jsonData['id'] = id != 0 ? id : null;
    jsonData['idWmsRua'] = idWmsRua != 0 ? idWmsRua : null;
    jsonData['codigo'] = codigo;
    jsonData['quantidadeCaixa'] = quantidadeCaixa;
    jsonData['wmsRuaModel'] = wmsRuaModel?.toJson;
    jsonData['wmsRua'] = wmsRuaModel?.nome ?? '';
    
		var wmsCaixaModelLocalList = []; 
		for (WmsCaixaModel object in wmsCaixaModelList ?? []) { 
			wmsCaixaModelLocalList.add(object.toJson); 
		}
		jsonData['wmsCaixaModelList'] = wmsCaixaModelLocalList;

    return jsonData;
  }

  String objectEncodeJson() {
    final jsonData = toJson;
    return json.encode(jsonData);
  }

  static WmsEstanteModel fromPlutoRow(PlutoRow row) {
    return WmsEstanteModel(
      id: row.cells['id']?.value,
      idWmsRua: row.cells['idWmsRua']?.value,
      codigo: row.cells['codigo']?.value,
      quantidadeCaixa: row.cells['quantidadeCaixa']?.value,
    );
  }

  PlutoRow toPlutoRow() {
    return PlutoRow(
      cells: {
        'tempId': PlutoCell(value: tempId),
        'id': PlutoCell(value: id ?? 0),
        'idWmsRua': PlutoCell(value: idWmsRua ?? 0),
        'codigo': PlutoCell(value: codigo ?? ''),
        'quantidadeCaixa': PlutoCell(value: quantidadeCaixa ?? 0),
        'wmsRua': PlutoCell(value: wmsRuaModel?.nome ?? ''),
      },
    );
  }

  WmsEstanteModel clone() {
    return WmsEstanteModel(
      id: id,
      idWmsRua: idWmsRua,
      codigo: codigo,
      quantidadeCaixa: quantidadeCaixa,
      wmsRuaModel: wmsRuaModel?.clone(),
      wmsCaixaModelList: wmsCaixaModelListClone(wmsCaixaModelList!),
    );
  }

  wmsCaixaModelListClone(List<WmsCaixaModel> wmsCaixaModelList) { 
		List<WmsCaixaModel> resultList = [];
		for (var wmsCaixaModel in wmsCaixaModelList) {
			resultList.add(wmsCaixaModel.clone());
		}
		return resultList;
	}


}