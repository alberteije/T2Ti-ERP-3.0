import 'dart:convert';
import 'package:pluto_grid/pluto_grid.dart';
import 'package:wms/app/data/model/model_imports.dart';

import 'package:wms/app/data/domain/domain_imports.dart';

class WmsRecebimentoDetalheModel extends ModelBase {
  int? id;
  int? idWmsRecebimentoCabecalho;
  int? idProduto;
  int? quantidadeVolume;
  int? quantidadeItemPorVolume;
  int? quantidadeRecebida;
  String? destino;
  ProdutoModel? produtoModel;

  WmsRecebimentoDetalheModel({
    this.id,
    this.idWmsRecebimentoCabecalho,
    this.idProduto,
    this.quantidadeVolume,
    this.quantidadeItemPorVolume,
    this.quantidadeRecebida,
    this.destino = 'Armazenamento',
    ProdutoModel? produtoModel,
  }) {
    this.produtoModel = produtoModel ?? ProdutoModel();
  }

  static List<String> dbColumns = <String>[
    'id',
    'quantidade_volume',
    'quantidade_item_por_volume',
    'quantidade_recebida',
    'destino',
  ];

  static List<String> aliasColumns = <String>[
    'Id',
    'Quantidade Volume',
    'Quantidade Item Por Volume',
    'Quantidade Recebida',
    'Destino',
  ];

  WmsRecebimentoDetalheModel.fromJson(Map<String, dynamic> jsonData) {
    id = jsonData['id'];
    idWmsRecebimentoCabecalho = jsonData['idWmsRecebimentoCabecalho'];
    idProduto = jsonData['idProduto'];
    quantidadeVolume = jsonData['quantidadeVolume'];
    quantidadeItemPorVolume = jsonData['quantidadeItemPorVolume'];
    quantidadeRecebida = jsonData['quantidadeRecebida'];
    destino = WmsRecebimentoDetalheDomain.getDestino(jsonData['destino']);
    produtoModel = jsonData['produtoModel'] == null ? ProdutoModel() : ProdutoModel.fromJson(jsonData['produtoModel']);
  }

  Map<String, dynamic> get toJson {
    Map<String, dynamic> jsonData = <String, dynamic>{};

    jsonData['id'] = id != 0 ? id : null;
    jsonData['idWmsRecebimentoCabecalho'] = idWmsRecebimentoCabecalho != 0 ? idWmsRecebimentoCabecalho : null;
    jsonData['idProduto'] = idProduto != 0 ? idProduto : null;
    jsonData['quantidadeVolume'] = quantidadeVolume;
    jsonData['quantidadeItemPorVolume'] = quantidadeItemPorVolume;
    jsonData['quantidadeRecebida'] = quantidadeRecebida;
    jsonData['destino'] = WmsRecebimentoDetalheDomain.setDestino(destino);
    jsonData['produtoModel'] = produtoModel?.toJson;
    jsonData['produto'] = produtoModel?.nome ?? '';

    return jsonData;
  }

  String objectEncodeJson() {
    final jsonData = toJson;
    return json.encode(jsonData);
  }

  static WmsRecebimentoDetalheModel fromPlutoRow(PlutoRow row) {
    return WmsRecebimentoDetalheModel(
      id: row.cells['id']?.value,
      idWmsRecebimentoCabecalho: row.cells['idWmsRecebimentoCabecalho']?.value,
      idProduto: row.cells['idProduto']?.value,
      quantidadeVolume: row.cells['quantidadeVolume']?.value,
      quantidadeItemPorVolume: row.cells['quantidadeItemPorVolume']?.value,
      quantidadeRecebida: row.cells['quantidadeRecebida']?.value,
      destino: row.cells['destino']?.value,
    );
  }

  PlutoRow toPlutoRow() {
    return PlutoRow(
      cells: {
        'tempId': PlutoCell(value: tempId),
        'id': PlutoCell(value: id ?? 0),
        'idWmsRecebimentoCabecalho': PlutoCell(value: idWmsRecebimentoCabecalho ?? 0),
        'idProduto': PlutoCell(value: idProduto ?? 0),
        'quantidadeVolume': PlutoCell(value: quantidadeVolume ?? 0),
        'quantidadeItemPorVolume': PlutoCell(value: quantidadeItemPorVolume ?? 0),
        'quantidadeRecebida': PlutoCell(value: quantidadeRecebida ?? 0),
        'destino': PlutoCell(value: destino ?? ''),
        'produto': PlutoCell(value: produtoModel?.nome ?? ''),
      },
    );
  }

  WmsRecebimentoDetalheModel clone() {
    return WmsRecebimentoDetalheModel(
      id: id,
      idWmsRecebimentoCabecalho: idWmsRecebimentoCabecalho,
      idProduto: idProduto,
      quantidadeVolume: quantidadeVolume,
      quantidadeItemPorVolume: quantidadeItemPorVolume,
      quantidadeRecebida: quantidadeRecebida,
      destino: destino,
      produtoModel: produtoModel?.clone(),
    );
  }


}