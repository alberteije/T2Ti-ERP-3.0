import 'dart:convert';
import 'package:pluto_grid/pluto_grid.dart';
import 'package:wms/app/data/model/model_imports.dart';

import 'package:wms/app/infra/infra_imports.dart';
import 'package:intl/intl.dart';
import 'package:wms/app/data/domain/domain_imports.dart';

class WmsOrdemSeparacaoCabModel extends ModelBase {
  int? id;
  String? origem;
  DateTime? dataSolicitacao;
  DateTime? dataLimite;
  String? codigoSeparacao;
  List<WmsOrdemSeparacaoDetModel>? wmsOrdemSeparacaoDetModelList;

  WmsOrdemSeparacaoCabModel({
    this.id,
    this.origem = 'Produção',
    this.dataSolicitacao,
    this.dataLimite,
    this.codigoSeparacao,
    List<WmsOrdemSeparacaoDetModel>? wmsOrdemSeparacaoDetModelList,
  }) {
    this.wmsOrdemSeparacaoDetModelList = wmsOrdemSeparacaoDetModelList?.toList(growable: true) ?? [];
  }

  static List<String> dbColumns = <String>[
    'id',
    'origem',
    'data_solicitacao',
    'data_limite',
    'codigo_separacao',
  ];

  static List<String> aliasColumns = <String>[
    'Id',
    'Origem',
    'Data Solicitacao',
    'Data Limite',
    'Codigo Separacao',
  ];

  WmsOrdemSeparacaoCabModel.fromJson(Map<String, dynamic> jsonData) {
    id = jsonData['id'];
    origem = WmsOrdemSeparacaoCabDomain.getOrigem(jsonData['origem']);
    dataSolicitacao = jsonData['dataSolicitacao'] != null ? DateTime.tryParse(jsonData['dataSolicitacao']) : null;
    dataLimite = jsonData['dataLimite'] != null ? DateTime.tryParse(jsonData['dataLimite']) : null;
    codigoSeparacao = jsonData['codigoSeparacao'];
    wmsOrdemSeparacaoDetModelList = (jsonData['wmsOrdemSeparacaoDetModelList'] as Iterable?)?.map((m) => WmsOrdemSeparacaoDetModel.fromJson(m)).toList() ?? [];
  }

  Map<String, dynamic> get toJson {
    Map<String, dynamic> jsonData = <String, dynamic>{};

    jsonData['id'] = id != 0 ? id : null;
    jsonData['origem'] = WmsOrdemSeparacaoCabDomain.setOrigem(origem);
    jsonData['dataSolicitacao'] = dataSolicitacao != null ? DateFormat('yyyy-MM-ddT00:00:00').format(dataSolicitacao!) : null;
    jsonData['dataLimite'] = dataLimite != null ? DateFormat('yyyy-MM-ddT00:00:00').format(dataLimite!) : null;
    jsonData['codigoSeparacao'] = codigoSeparacao;
    
		var wmsOrdemSeparacaoDetModelLocalList = []; 
		for (WmsOrdemSeparacaoDetModel object in wmsOrdemSeparacaoDetModelList ?? []) { 
			wmsOrdemSeparacaoDetModelLocalList.add(object.toJson); 
		}
		jsonData['wmsOrdemSeparacaoDetModelList'] = wmsOrdemSeparacaoDetModelLocalList;

    return jsonData;
  }

  String objectEncodeJson() {
    final jsonData = toJson;
    return json.encode(jsonData);
  }

  static WmsOrdemSeparacaoCabModel fromPlutoRow(PlutoRow row) {
    return WmsOrdemSeparacaoCabModel(
      id: row.cells['id']?.value,
      origem: row.cells['origem']?.value,
      dataSolicitacao: Util.stringToDate(row.cells['dataSolicitacao']?.value),
      dataLimite: Util.stringToDate(row.cells['dataLimite']?.value),
      codigoSeparacao: row.cells['codigoSeparacao']?.value,
    );
  }

  PlutoRow toPlutoRow() {
    return PlutoRow(
      cells: {
        'tempId': PlutoCell(value: tempId),
        'id': PlutoCell(value: id ?? 0),
        'origem': PlutoCell(value: origem ?? ''),
        'dataSolicitacao': PlutoCell(value: dataSolicitacao),
        'dataLimite': PlutoCell(value: dataLimite),
        'codigoSeparacao': PlutoCell(value: codigoSeparacao ?? ''),
      },
    );
  }

  WmsOrdemSeparacaoCabModel clone() {
    return WmsOrdemSeparacaoCabModel(
      id: id,
      origem: origem,
      dataSolicitacao: dataSolicitacao,
      dataLimite: dataLimite,
      codigoSeparacao: codigoSeparacao,
      wmsOrdemSeparacaoDetModelList: wmsOrdemSeparacaoDetModelListClone(wmsOrdemSeparacaoDetModelList!),
    );
  }

  wmsOrdemSeparacaoDetModelListClone(List<WmsOrdemSeparacaoDetModel> wmsOrdemSeparacaoDetModelList) { 
		List<WmsOrdemSeparacaoDetModel> resultList = [];
		for (var wmsOrdemSeparacaoDetModel in wmsOrdemSeparacaoDetModelList) {
			resultList.add(wmsOrdemSeparacaoDetModel.clone());
		}
		return resultList;
	}


}