import 'dart:convert';
import 'package:pluto_grid/pluto_grid.dart';
import 'package:wms/app/data/model/model_imports.dart';


class WmsRuaModel extends ModelBase {
  int? id;
  String? codigo;
  int? quantidadeEstante;
  String? nome;

  WmsRuaModel({
    this.id,
    this.codigo,
    this.quantidadeEstante,
    this.nome,
  });

  static List<String> dbColumns = <String>[
    'id',
    'codigo',
    'quantidade_estante',
    'nome',
  ];

  static List<String> aliasColumns = <String>[
    'Id',
    'Codigo',
    'Quantidade Estante',
    'Nome',
  ];

  WmsRuaModel.fromJson(Map<String, dynamic> jsonData) {
    id = jsonData['id'];
    codigo = jsonData['codigo'];
    quantidadeEstante = jsonData['quantidadeEstante'];
    nome = jsonData['nome'];
  }

  Map<String, dynamic> get toJson {
    Map<String, dynamic> jsonData = <String, dynamic>{};

    jsonData['id'] = id != 0 ? id : null;
    jsonData['codigo'] = codigo;
    jsonData['quantidadeEstante'] = quantidadeEstante;
    jsonData['nome'] = nome;

    return jsonData;
  }

  String objectEncodeJson() {
    final jsonData = toJson;
    return json.encode(jsonData);
  }

  static WmsRuaModel fromPlutoRow(PlutoRow row) {
    return WmsRuaModel(
      id: row.cells['id']?.value,
      codigo: row.cells['codigo']?.value,
      quantidadeEstante: row.cells['quantidadeEstante']?.value,
      nome: row.cells['nome']?.value,
    );
  }

  PlutoRow toPlutoRow() {
    return PlutoRow(
      cells: {
        'tempId': PlutoCell(value: tempId),
        'id': PlutoCell(value: id ?? 0),
        'codigo': PlutoCell(value: codigo ?? ''),
        'quantidadeEstante': PlutoCell(value: quantidadeEstante ?? 0),
        'nome': PlutoCell(value: nome ?? ''),
      },
    );
  }

  WmsRuaModel clone() {
    return WmsRuaModel(
      id: id,
      codigo: codigo,
      quantidadeEstante: quantidadeEstante,
      nome: nome,
    );
  }


}