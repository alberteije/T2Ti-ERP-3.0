import 'dart:convert';
import 'package:pluto_grid/pluto_grid.dart';
import 'package:wms/app/data/model/model_imports.dart';

import 'package:wms/app/infra/infra_imports.dart';
import 'package:intl/intl.dart';

class WmsArmazenamentoModel extends ModelBase {
  int? id;
  int? idWmsRecebimentoCabecalho;
  int? idProduto;
  int? idWmsCaixa;
  int? quantidade;
  DateTime? dataArmazenagem;
  String? horaArmazenagem;
  WmsCaixaModel? wmsCaixaModel;
  WmsRecebimentoCabecalhoModel? wmsRecebimentoCabecalhoModel;
  ProdutoModel? produtoModel;

  WmsArmazenamentoModel({
    this.id,
    this.idWmsRecebimentoCabecalho,
    this.idProduto,
    this.idWmsCaixa,
    this.quantidade,
    this.dataArmazenagem,
    this.horaArmazenagem,
    WmsCaixaModel? wmsCaixaModel,
    WmsRecebimentoCabecalhoModel? wmsRecebimentoCabecalhoModel,
    ProdutoModel? produtoModel,
  }) {
    this.wmsCaixaModel = wmsCaixaModel ?? WmsCaixaModel();
    this.wmsRecebimentoCabecalhoModel = wmsRecebimentoCabecalhoModel ?? WmsRecebimentoCabecalhoModel();
    this.produtoModel = produtoModel ?? ProdutoModel();
  }

  static List<String> dbColumns = <String>[
    'id',
    'quantidade',
    'data_armazenagem',
    'hora_armazenagem',
  ];

  static List<String> aliasColumns = <String>[
    'Id',
    'Quantidade',
    'Data Armazenagem',
    'Hora Armazenagem',
  ];

  WmsArmazenamentoModel.fromJson(Map<String, dynamic> jsonData) {
    id = jsonData['id'];
    idWmsRecebimentoCabecalho = jsonData['idWmsRecebimentoCabecalho'];
    idProduto = jsonData['idProduto'];
    idWmsCaixa = jsonData['idWmsCaixa'];
    quantidade = jsonData['quantidade'];
    dataArmazenagem = jsonData['dataArmazenagem'] != null ? DateTime.tryParse(jsonData['dataArmazenagem']) : null;
    horaArmazenagem = jsonData['horaArmazenagem'];
    wmsCaixaModel = jsonData['wmsCaixaModel'] == null ? WmsCaixaModel() : WmsCaixaModel.fromJson(jsonData['wmsCaixaModel']);
    wmsRecebimentoCabecalhoModel = jsonData['wmsRecebimentoCabecalhoModel'] == null ? WmsRecebimentoCabecalhoModel() : WmsRecebimentoCabecalhoModel.fromJson(jsonData['wmsRecebimentoCabecalhoModel']);
    produtoModel = jsonData['produtoModel'] == null ? ProdutoModel() : ProdutoModel.fromJson(jsonData['produtoModel']);
  }

  Map<String, dynamic> get toJson {
    Map<String, dynamic> jsonData = <String, dynamic>{};

    jsonData['id'] = id != 0 ? id : null;
    jsonData['idWmsRecebimentoCabecalho'] = idWmsRecebimentoCabecalho != 0 ? idWmsRecebimentoCabecalho : null;
    jsonData['idProduto'] = idProduto != 0 ? idProduto : null;
    jsonData['idWmsCaixa'] = idWmsCaixa != 0 ? idWmsCaixa : null;
    jsonData['quantidade'] = quantidade;
    jsonData['dataArmazenagem'] = dataArmazenagem != null ? DateFormat('yyyy-MM-ddT00:00:00').format(dataArmazenagem!) : null;
    jsonData['horaArmazenagem'] = Util.removeMask(horaArmazenagem);
    jsonData['wmsCaixaModel'] = wmsCaixaModel?.toJson;
    jsonData['wmsCaixa'] = wmsCaixaModel?.codigo ?? '';
    jsonData['wmsRecebimentoCabecalhoModel'] = wmsRecebimentoCabecalhoModel?.toJson;
    jsonData['wmsRecebimentoCabecalho'] = wmsRecebimentoCabecalhoModel?.codigoRecebimento ?? '';
    jsonData['produtoModel'] = produtoModel?.toJson;
    jsonData['produto'] = produtoModel?.nome ?? '';

    return jsonData;
  }

  String objectEncodeJson() {
    final jsonData = toJson;
    return json.encode(jsonData);
  }

  static WmsArmazenamentoModel fromPlutoRow(PlutoRow row) {
    return WmsArmazenamentoModel(
      id: row.cells['id']?.value,
      idWmsRecebimentoCabecalho: row.cells['idWmsRecebimentoCabecalho']?.value,
      idProduto: row.cells['idProduto']?.value,
      idWmsCaixa: row.cells['idWmsCaixa']?.value,
      quantidade: row.cells['quantidade']?.value,
      dataArmazenagem: Util.stringToDate(row.cells['dataArmazenagem']?.value),
      horaArmazenagem: row.cells['horaArmazenagem']?.value,
    );
  }

  PlutoRow toPlutoRow() {
    return PlutoRow(
      cells: {
        'tempId': PlutoCell(value: tempId),
        'id': PlutoCell(value: id ?? 0),
        'idWmsRecebimentoCabecalho': PlutoCell(value: idWmsRecebimentoCabecalho ?? 0),
        'idProduto': PlutoCell(value: idProduto ?? 0),
        'idWmsCaixa': PlutoCell(value: idWmsCaixa ?? 0),
        'quantidade': PlutoCell(value: quantidade ?? 0),
        'dataArmazenagem': PlutoCell(value: dataArmazenagem),
        'horaArmazenagem': PlutoCell(value: horaArmazenagem ?? ''),
        'wmsCaixa': PlutoCell(value: wmsCaixaModel?.codigo ?? ''),
        'wmsRecebimentoCabecalho': PlutoCell(value: wmsRecebimentoCabecalhoModel?.codigoRecebimento ?? ''),
        'produto': PlutoCell(value: produtoModel?.nome ?? ''),
      },
    );
  }

  WmsArmazenamentoModel clone() {
    return WmsArmazenamentoModel(
      id: id,
      idWmsRecebimentoCabecalho: idWmsRecebimentoCabecalho,
      idProduto: idProduto,
      idWmsCaixa: idWmsCaixa,
      quantidade: quantidade,
      dataArmazenagem: dataArmazenagem,
      horaArmazenagem: horaArmazenagem,
      wmsCaixaModel: wmsCaixaModel?.clone(),
      wmsRecebimentoCabecalhoModel: wmsRecebimentoCabecalhoModel?.clone(),
      produtoModel: produtoModel?.clone(),
    );
  }


}