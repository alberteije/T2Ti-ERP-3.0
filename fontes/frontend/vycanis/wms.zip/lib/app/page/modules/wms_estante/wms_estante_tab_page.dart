import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:buttons_tabbar/buttons_tabbar.dart';
import 'package:get/get.dart';
import 'package:wms/app/controller/wms_estante_controller.dart';
import 'package:wms/app/page/shared_widget/shared_widget_imports.dart';

class WmsEstanteTabPage extends StatelessWidget {
  WmsEstanteTabPage({Key? key}) : super(key: key);
  final wmsEstanteController = Get.find<WmsEstanteController>();

  @override
  Widget build(BuildContext context) {
		return KeyboardListener(
			autofocus: false,
			focusNode: FocusNode(),
			onKeyEvent: (event) {
				if (event.logicalKey == LogicalKeyboardKey.escape) {
          wmsEstanteController.preventDataLoss();
        }
      },
      child: Scaffold(
        key: wmsEstanteController.wmsEstanteTabPageScaffoldKey,
        appBar: AppBar(
					automaticallyImplyLeading: false, 
					title: Text('${ wmsEstanteController.screenTitle } - ${ wmsEstanteController.isNewRecord ? 'inserting'.tr : 'editing'.tr }',),
					actions: [
						saveButton(onPressed: wmsEstanteController.save),
						cancelAndExitButton(onPressed: wmsEstanteController.preventDataLoss),
					]
				),
        body: SafeArea(
          child: Column(
            children: <Widget>[
              Expanded(
                child: TabBarView(
                  controller: wmsEstanteController.tabController,
                  children: wmsEstanteController.tabPages(),
                ),
              ),
              ButtonsTabBar(
                controller: wmsEstanteController.tabController,
                onTap: wmsEstanteController.tabChange,
                height: 40,
                elevation: 2,
                borderWidth: 0,
                backgroundColor: Colors.blueGrey,
                unselectedBackgroundColor: Colors.grey[300],
                unselectedLabelStyle: const TextStyle(color: Colors.black),
                labelStyle: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold),
                tabs: wmsEstanteController.tabItems,
              ),
              const SizedBox(
                height: 10,
              ),
            ],
          ),
        ),
      ),
    );
  }
}
