import 'package:flutter/material.dart';
import 'package:wms/app/controller/wms_ordem_separacao_cab_controller.dart';
import 'package:wms/app/page/shared_page/list_page_base.dart';

class WmsOrdemSeparacaoCabListPage extends ListPageBase<WmsOrdemSeparacaoCabController> {
  const WmsOrdemSeparacaoCabListPage({Key? key}) : super(key: key);

  @override
  List<Map<String, dynamic>> get mobileItems => controller.mobileItems;

  @override
  Map<String, dynamic> get mobileConfig => controller.mobileConfig;

  @override
  String get standardFieldForFilter => controller.standardFieldForFilter;
}