import 'package:flutter/material.dart';
import 'package:flutter_bootstrap/flutter_bootstrap.dart';
import 'package:get/get.dart';
import 'package:wms/app/data/domain/domain_imports.dart';
import 'package:wms/app/controller/wms_ordem_separacao_cab_controller.dart';
import 'package:wms/app/infra/infra_imports.dart';
import 'package:wms/app/page/shared_widget/input/input_imports.dart';

class WmsOrdemSeparacaoCabEditPage extends StatelessWidget {
	WmsOrdemSeparacaoCabEditPage({Key? key}) : super(key: key);
	final wmsOrdemSeparacaoCabController = Get.find<WmsOrdemSeparacaoCabController>();

	@override
	Widget build(BuildContext context) {
			return Scaffold(
				key: wmsOrdemSeparacaoCabController.wmsOrdemSeparacaoCabScaffoldKey,
				body: SafeArea(
					top: false,
					bottom: false,
					child: Form(
						key: wmsOrdemSeparacaoCabController.wmsOrdemSeparacaoCabFormKey,
						autovalidateMode: AutovalidateMode.always,
						child: Scrollbar(
							controller: wmsOrdemSeparacaoCabController.scrollController,
							child: SingleChildScrollView(
								controller: wmsOrdemSeparacaoCabController.scrollController,
								child: BootstrapContainer(
									fluid: true,
									padding: const EdgeInsets.all(10),
									children: <Widget>[
										const Divider(
											color: Colors.transparent,
										),
										BootstrapRow(
											height: 60,
											children: <BootstrapCol>[
												BootstrapCol(
													sizes: 'col-12 col-md-4',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: CustomDropdownButton(
															controller: wmsOrdemSeparacaoCabController.origemController,
															labelText: 'Origem',
															hintText: 'Informe os dados para o campo Origem',
															items: WmsOrdemSeparacaoCabDomain.origemListDropdown,
															onChanged: (dynamic newValue) {
																wmsOrdemSeparacaoCabController.currentModel.origem = newValue;
																wmsOrdemSeparacaoCabController.formWasChanged = true;
															},
														),
													),
												),
												BootstrapCol(
													sizes: 'col-12 col-md-4',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: InputDecorator(
															decoration: inputDecoration(
																hintText: 'Informe os dados para o campo Data Solicitação',
																labelText: 'Data Solicitacao',
																usePadding: true,
															),
															isEmpty: false,
															child: DatePickerItem(
																controller: wmsOrdemSeparacaoCabController.dataSolicitacaoController,
																firstDate: DateTime.parse('1000-01-01'),
																lastDate: DateTime.parse('5000-01-01'),
																onChanged: (DateTime? value) {
																	wmsOrdemSeparacaoCabController.currentModel.dataSolicitacao = value;
																	wmsOrdemSeparacaoCabController.formWasChanged = true;
																},
															),
														),
													),
												),
												BootstrapCol(
													sizes: 'col-12 col-md-4',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: InputDecorator(
															decoration: inputDecoration(
																hintText: 'Informe os dados para o campo Data Limite',
																labelText: 'Data Limite',
																usePadding: true,
															),
															isEmpty: false,
															child: DatePickerItem(
																controller: wmsOrdemSeparacaoCabController.dataLimiteController,
																firstDate: DateTime.parse('1000-01-01'),
																lastDate: DateTime.parse('5000-01-01'),
																onChanged: (DateTime? value) {
																	wmsOrdemSeparacaoCabController.currentModel.dataLimite = value;
																	wmsOrdemSeparacaoCabController.formWasChanged = true;
																},
															),
														),
													),
												),
											],
										),
										const Divider(
											color: Colors.transparent,
										),
										BootstrapRow(
											height: 60,
											children: <BootstrapCol>[
												BootstrapCol(
													sizes: 'col-12',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: TextFormField(
															autofocus: true,
															maxLength: 32,
															controller: wmsOrdemSeparacaoCabController.codigoSeparacaoController,
															decoration: inputDecoration(
																hintText: 'Informe os dados para o campo Codigo Separacao',
																labelText: 'Codigo Separacao',
																usePadding: true,
															),
															onSaved: (String? value) {},
															onChanged: (text) {
																wmsOrdemSeparacaoCabController.currentModel.codigoSeparacao = text;
																wmsOrdemSeparacaoCabController.formWasChanged = true;
															},
														),
													),
												),
											],
										),
										const Divider(
											indent: 10,
											endIndent: 10,
											thickness: 2,
										),
										BootstrapRow(
											height: 60,
											children: <BootstrapCol>[
												BootstrapCol(
													sizes: 'col-12',
													child: Text(
														'field_is_mandatory'.tr,
														style: Theme.of(context).textTheme.bodySmall,
													),
												),
											],
										),
										const SizedBox(height: 10.0),
									],
								),
							),
						),
					),
				),
			);
	}
}
