import 'package:flutter/material.dart';
import 'package:wms/app/controller/wms_expedicao_controller.dart';
import 'package:wms/app/page/shared_page/list_page_base.dart';

class WmsExpedicaoListPage extends ListPageBase<WmsExpedicaoController> {
  const WmsExpedicaoListPage({Key? key}) : super(key: key);

  @override
  List<Map<String, dynamic>> get mobileItems => controller.mobileItems;

  @override
  Map<String, dynamic> get mobileConfig => controller.mobileConfig;

  @override
  String get standardFieldForFilter => controller.standardFieldForFilter;
}