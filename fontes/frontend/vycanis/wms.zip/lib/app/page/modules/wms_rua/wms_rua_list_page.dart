import 'package:flutter/material.dart';
import 'package:wms/app/controller/wms_rua_controller.dart';
import 'package:wms/app/page/shared_page/list_page_base.dart';

class WmsRuaListPage extends ListPageBase<WmsRuaController> {
  const WmsRuaListPage({Key? key}) : super(key: key);

  @override
  List<Map<String, dynamic>> get mobileItems => controller.mobileItems;

  @override
  Map<String, dynamic> get mobileConfig => controller.mobileConfig;

  @override
  String get standardFieldForFilter => controller.standardFieldForFilter;
}