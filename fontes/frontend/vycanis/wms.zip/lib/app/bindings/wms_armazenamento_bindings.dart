import 'package:get/get.dart';
import 'package:wms/app/controller/wms_armazenamento_controller.dart';
import 'package:wms/app/data/provider/api/wms_armazenamento_api_provider.dart';
import 'package:wms/app/data/provider/drift/wms_armazenamento_drift_provider.dart';
import 'package:wms/app/data/repository/wms_armazenamento_repository.dart';

class WmsArmazenamentoBindings implements Binding {
	@override
	List<Bind> dependencies() {
		return [
			Bind.lazyPut<WmsArmazenamentoController>(() => WmsArmazenamentoController(
					repository: WmsArmazenamentoRepository(wmsArmazenamentoApiProvider: WmsArmazenamentoApiProvider(), wmsArmazenamentoDriftProvider: WmsArmazenamentoDriftProvider()))),
		];
	}
}
