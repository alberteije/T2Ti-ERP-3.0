import 'package:flutter/material.dart';
import 'dart:math';
import 'package:get/get.dart';
import 'package:wms/app/page/shared_widget/input/input_imports.dart';

import 'package:wms/app/infra/infra_imports.dart';
import 'package:wms/app/page/page_imports.dart';
import 'package:wms/app/page/shared_widget/message_dialog.dart';
import 'package:wms/app/page/grid_columns/grid_columns_imports.dart';
import 'package:wms/app/routes/app_routes.dart';
import 'package:wms/app/controller/controller_imports.dart';
import 'package:wms/app/data/model/model_imports.dart';
import 'package:wms/app/data/repository/wms_ordem_separacao_cab_repository.dart';

class WmsOrdemSeparacaoCabController extends ControllerBase<WmsOrdemSeparacaoCabModel, WmsOrdemSeparacaoCabRepository> 
with GetSingleTickerProviderStateMixin {

  WmsOrdemSeparacaoCabController({required super.repository}) {
    dbColumns = WmsOrdemSeparacaoCabModel.dbColumns;
    aliasColumns = WmsOrdemSeparacaoCabModel.aliasColumns;
    gridColumns = wmsOrdemSeparacaoCabGridColumns();
    functionName = "wms_ordem_separacao_cab";
    screenTitle = "Ordem Separação";
  }

  final wmsOrdemSeparacaoCabScaffoldKey = GlobalKey<ScaffoldState>();
  final wmsOrdemSeparacaoCabTabPageScaffoldKey = GlobalKey<ScaffoldState>();
  final wmsOrdemSeparacaoCabFormKey = GlobalKey<FormState>();
  late TabController tabController;
  String? mandatoryMessage;  

  @override
  WmsOrdemSeparacaoCabModel createNewModel() => WmsOrdemSeparacaoCabModel();

  @override
  final standardFieldForFilter = WmsOrdemSeparacaoCabModel.aliasColumns[WmsOrdemSeparacaoCabModel.dbColumns.indexOf('origem')];

  final origemController = CustomDropdownButtonController('Produção');
  final dataSolicitacaoController = DatePickerItemController(null);
  final dataLimiteController = DatePickerItemController(null);
  final codigoSeparacaoController = TextEditingController();

  final Map<String, dynamic> mobileConfig = {
    'primaryColumns': ['origem'],
    'secondaryColumns': ['data_solicitacao'],
  };

  List<Map<String, dynamic>> get mobileItems {
    return modelList.map((wmsOrdemSeparacaoCab) => wmsOrdemSeparacaoCab.toJson).toList();
  }

  @override
  void prepareForInsert() {
    isNewRecord = true;
    currentModel = createNewModel();
    _resetForm();
    tabController.animateTo(0);
    updateControllersFromModel();
    Get.toNamed(Routes.wmsOrdemSeparacaoCabTabPage);
  }

  void _resetForm() {
    formWasChanged = false;
    origemController.selected = 'Produção';
    dataSolicitacaoController.date = null;
    dataLimiteController.date = null;
    codigoSeparacaoController.text = '';
  }

  @override
  void selectRowForEditingById(int id) {
    final model = modelList.firstWhere((m) => m.id == id);
    currentModel = model.clone();
    updateControllersFromModel();
    tabController.animateTo(0);
    Get.toNamed(Routes.wmsOrdemSeparacaoCabTabPage);
  }

  _configureChildrenControllers() {
    //Itens
		Get.put<WmsOrdemSeparacaoDetController>(WmsOrdemSeparacaoDetController()); 

  }
	
	_releaseChildrenControllers() {
    //Itens
		Get.delete<WmsOrdemSeparacaoDetController>(); 

	}
  
  void updateControllersFromModel() {
    origemController.selected = currentModel.origem ?? 'Produção';
    dataSolicitacaoController.date = currentModel.dataSolicitacao;
    dataLimiteController.date = currentModel.dataLimite;
    codigoSeparacaoController.text = currentModel.codigoSeparacao ?? '';

    formWasChanged = false;
    _updateChildrenControllersFromModel();
  }

  void _updateChildrenControllersFromModel() {
    //Itens
		final wmsOrdemSeparacaoDetController = Get.find<WmsOrdemSeparacaoDetController>(); 
		wmsOrdemSeparacaoDetController.userMadeChanges = false; 

  }

  @override
  Future<void> save() async {
    if (!validateCurrentForm()) return;
    if (validateForms()) {
      if (userMadeChanges()) {
        final existingIndex = modelList.indexWhere((m) => m.id == currentModel.id);

        if (existingIndex >= 0) {
          modelList[existingIndex] = currentModel.clone();
        }

        final result = await repository.save(wmsOrdemSeparacaoCabModel: currentModel);
        if (result == null) return;

        if (existingIndex >= 0) {
          modelList[existingIndex] = result;
        } else {
          modelList.insert(0, result);
        }

        if (!GetPlatform.isMobile) {
          updateGridRow(result);
        }

        Get.back(result: true);
      } else {
        Get.back();
      }
    } 
  }


  List<Tab> tabItems = [
    Tab( 
			icon: Icon(iconDataList[Random().nextInt(10)]), 
			text: 'Ordem Separação', 
		),
    Tab( 
			icon: Icon(iconDataList[Random().nextInt(10)]), 
			text: 'Itens', 
		),
  ];

  List<Widget> tabPages() {
    return [
      WmsOrdemSeparacaoCabEditPage(),
      const WmsOrdemSeparacaoDetListPage(),
    ];
  }

  @override
  void preventDataLoss() {
    if (userMadeChanges()) {
      showQuestionDialog('message_data_loss'.tr, () { 
        Get.back(); 
      });
    } else {
      Get.back();
    }
  }  

  bool userMadeChanges() {
    return
    formWasChanged 
    || 
		Get.find<WmsOrdemSeparacaoDetController>().userMadeChanges
    ;
  }

  void tabChange(int index) {
    validateCurrentForm();
  }

  bool validateCurrentForm() {
    return true;
  }

  bool validateForms() {
    return true;
  }

  @override
  void onInit() {
    super.onInit();
    tabController = TabController(vsync: this, length: tabItems.length);
    _configureChildrenControllers();
  }
	
  @override
  void onClose() {
    tabController.dispose();
    origemController.dispose();
    dataSolicitacaoController.dispose();
    dataLimiteController.dispose();
    codigoSeparacaoController.dispose();
    _releaseChildrenControllers();
    super.onClose();
  }	
}