import 'package:get/get.dart';
import 'package:extended_masked_text/extended_masked_text.dart';
import 'package:wms/app/page/shared_widget/input/input_imports.dart';

import 'package:wms/app/page/shared_widget/message_dialog.dart';
import 'package:wms/app/page/grid_columns/grid_columns_imports.dart';
import 'package:wms/app/routes/app_routes.dart';
import 'package:wms/app/controller/controller_imports.dart';
import 'package:wms/app/data/model/model_imports.dart';
import 'package:wms/app/data/repository/wms_parametro_repository.dart';

class WmsParametroController extends ControllerBase<WmsParametroModel, WmsParametroRepository> {

  WmsParametroController({required super.repository}) {
    dbColumns = WmsParametroModel.dbColumns;
    aliasColumns = WmsParametroModel.aliasColumns;
    gridColumns = wmsParametroGridColumns();
    functionName = "wms_parametro";
    screenTitle = "Parâmetros";
  }

  @override
  WmsParametroModel createNewModel() => WmsParametroModel();

  @override
  final standardFieldForFilter = WmsParametroModel.aliasColumns[WmsParametroModel.dbColumns.indexOf('hora_por_volume')];

  final horaPorVolumeController = MoneyMaskedTextController(precision: 0, decimalSeparator: '', thousandSeparator: '');
  final pessoaPorVolumeController = MoneyMaskedTextController(precision: 0, decimalSeparator: '', thousandSeparator: '');
  final horaPorPesoController = MoneyMaskedTextController(precision: 0, decimalSeparator: '', thousandSeparator: '');
  final pessoaPorPesoController = MoneyMaskedTextController(precision: 0, decimalSeparator: '', thousandSeparator: '');
  final itemDiferenteCaixaController = CustomDropdownButtonController('Sim');

  final Map<String, dynamic> mobileConfig = {
    'primaryColumns': ['hora_por_volume'],
    'secondaryColumns': ['pessoa_por_volume'],
  };

  List<Map<String, dynamic>> get mobileItems {
    return modelList.map((wmsParametro) => wmsParametro.toJson).toList();
  }

  @override
  void prepareForInsert() {
    isNewRecord = true;
    currentModel = createNewModel();
    _resetForm();
    Get.toNamed(Routes.wmsParametroEditPage);
  }

  void _resetForm() {
    formWasChanged = false;
    horaPorVolumeController.updateValue(0);
    pessoaPorVolumeController.updateValue(0);
    horaPorPesoController.updateValue(0);
    pessoaPorPesoController.updateValue(0);
    itemDiferenteCaixaController.selected = 'Sim';
  }

  @override
  void selectRowForEditingById(int id) {
    final model = modelList.firstWhere((m) => m.id == id);
    currentModel = model.clone();
    updateControllersFromModel();
    Get.toNamed(Routes.wmsParametroEditPage);
  }

  void updateControllersFromModel() {
    horaPorVolumeController.updateValue((currentModel.horaPorVolume ?? 0).toDouble());
    pessoaPorVolumeController.updateValue((currentModel.pessoaPorVolume ?? 0).toDouble());
    horaPorPesoController.updateValue((currentModel.horaPorPeso ?? 0).toDouble());
    pessoaPorPesoController.updateValue((currentModel.pessoaPorPeso ?? 0).toDouble());
    itemDiferenteCaixaController.selected = currentModel.itemDiferenteCaixa ?? 'Sim';
    formWasChanged = false;
  }

  @override
  Future<void> save() async {
    if (!formKey.currentState!.validate()) {
      showErrorSnackBar(message: 'validator_form_message'.tr);
      return;
    }

    final existingIndex = modelList.indexWhere((m) => m.id == currentModel.id);

    if (existingIndex >= 0) {
      modelList[existingIndex] = currentModel.clone();
    }

    final result = await repository.save(wmsParametroModel: currentModel);
    if (result == null) return;

    if (existingIndex >= 0) {
      modelList[existingIndex] = result;
    } else {
      modelList.insert(0, result);
    }

    if (!GetPlatform.isMobile) {
      updateGridRow(result);
    }

    Get.back(result: true);
  }


  @override
  void onClose() {
    horaPorVolumeController.dispose();
    pessoaPorVolumeController.dispose();
    horaPorPesoController.dispose();
    pessoaPorPesoController.dispose();
    itemDiferenteCaixaController.dispose();
    super.onClose();
  }

}