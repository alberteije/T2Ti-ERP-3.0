import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:pluto_grid/pluto_grid.dart';
import 'package:extended_masked_text/extended_masked_text.dart';
import 'package:wms/app/routes/app_routes.dart';

import 'package:wms/app/page/page_imports.dart';
import 'package:wms/app/page/shared_widget/message_dialog.dart';
import 'package:wms/app/page/grid_columns/grid_columns_imports.dart';
import 'package:wms/app/controller/controller_imports.dart';
import 'package:wms/app/data/model/model_imports.dart';

class WmsOrdemSeparacaoDetController extends ControllerBase<WmsOrdemSeparacaoDetModel, void> {

  WmsOrdemSeparacaoDetController() : super(repository: null) {
    dbColumns = WmsOrdemSeparacaoDetModel.dbColumns;
    aliasColumns = WmsOrdemSeparacaoDetModel.aliasColumns;
    gridColumns = wmsOrdemSeparacaoDetGridColumns();
    functionName = "wms_ordem_separacao_det";
    screenTitle = "Itens";
  }

  final _wmsOrdemSeparacaoDetModel = WmsOrdemSeparacaoDetModel().obs;
  WmsOrdemSeparacaoDetModel get wmsOrdemSeparacaoDetModel => _wmsOrdemSeparacaoDetModel.value;
  set wmsOrdemSeparacaoDetModel(value) => _wmsOrdemSeparacaoDetModel.value = value ?? WmsOrdemSeparacaoDetModel();

  List<WmsOrdemSeparacaoDetModel> get wmsOrdemSeparacaoDetModelList => Get.find<WmsOrdemSeparacaoCabController>().currentModel.wmsOrdemSeparacaoDetModelList ?? [];

  final _userMadeChanges = false.obs;
  get userMadeChanges => _userMadeChanges.value;
  set userMadeChanges(value) => _userMadeChanges.value = value;

  final _formWasChangedDetail = false.obs;
  bool get formWasChangedDetail => _formWasChangedDetail.value;
  set formWasChangedDetail(value) => _formWasChangedDetail.value = value;

  late PlutoGridStateManager _plutoGridStateManager;
  @override
  PlutoGridStateManager get plutoGridStateManager => _plutoGridStateManager;
  @override
  set plutoGridStateManager(value) => _plutoGridStateManager = value;

  final wmsOrdemSeparacaoDetScaffoldKey = GlobalKey<ScaffoldState>();
  final wmsOrdemSeparacaoDetFormKey = GlobalKey<FormState>();

  @override
  WmsOrdemSeparacaoDetModel createNewModel() => WmsOrdemSeparacaoDetModel();

  @override
  final standardFieldForFilter = WmsOrdemSeparacaoDetModel.aliasColumns[WmsOrdemSeparacaoDetModel.dbColumns.indexOf('quantidade')];

  final produtoModelController = TextEditingController();
  final quantidadeController = MoneyMaskedTextController(precision: 0, decimalSeparator: '', thousandSeparator: '');

  final Map<String, dynamic> mobileConfig = {
    'primaryColumns': ['quantidade'],
    'secondaryColumns': [],
  };

  List<Map<String, dynamic>> get mobileItems {
    return modelList.map((wmsOrdemSeparacaoDet) => wmsOrdemSeparacaoDet.toJson).toList();
  }

  @override
  List<PlutoRow> plutoRows() => List<PlutoRow>.from(wmsOrdemSeparacaoDetModelList.map((model) => model.toPlutoRow()));

  @override
  Future<void> getList({Filter? filter}) async {}

  @override
  void prepareForInsert() {
    isNewRecord = true;
    wmsOrdemSeparacaoDetModel = createNewModel();
    _resetForm();
    Get.to(() => WmsOrdemSeparacaoDetEditPage());
  }

  void _resetForm() {
    formWasChangedDetail = false;
    produtoModelController.text = '';
    quantidadeController.updateValue(0);
  }

  @override
  void selectRowForEditing(PlutoRow? row) async {
    if (row == null) {
      showInfoSnackBar(message: 'message_select_one_to_edited'.tr);
      return;
    }

    selectRowForEditingByTempId(row.cells['tempId']?.value);
  }

  @override
  void selectRowForEditingById(int id) {}

  void selectRowForEditingByTempId(String tempId) {
		isNewRecord = false;
    final model = wmsOrdemSeparacaoDetModelList.firstWhere((m) => m.tempId == tempId);
    wmsOrdemSeparacaoDetModel = model.clone();
		wmsOrdemSeparacaoDetModel.tempId = model.tempId;
    updateControllersFromModel();
    Get.to(() => WmsOrdemSeparacaoDetEditPage());
  }

  void updateControllersFromModel() {
    produtoModelController.text = wmsOrdemSeparacaoDetModel.produtoModel?.nome?.toString() ?? '';
    quantidadeController.updateValue((wmsOrdemSeparacaoDetModel.quantidade ?? 0).toDouble());
    formWasChangedDetail = false;
  }

  @override
  Future<void> save() async {
    if (!wmsOrdemSeparacaoDetFormKey.currentState!.validate()) {
      showErrorSnackBar(message: 'validator_form_message'.tr);
      return;
    }

    if (formWasChangedDetail) {
      if (isNewRecord) {
        wmsOrdemSeparacaoDetModelList.insert(0, wmsOrdemSeparacaoDetModel.clone());
      } else {
        final index = wmsOrdemSeparacaoDetModelList.indexWhere((m) => m.tempId == wmsOrdemSeparacaoDetModel.tempId);
        if (index >= 0) {
          wmsOrdemSeparacaoDetModelList[index] = wmsOrdemSeparacaoDetModel.clone();
        }
      }

      userMadeChanges = true;
      loadData();
      Get.back(result: true);
    } else {
      Get.back();
    }
  }

  Future callProdutoLookup() async { 
		final lookupController = Get.find<LookupController>(); 
		lookupController.refreshItems(standardValue: '%'); 
		lookupController.title = '${'lookup_page_title'.tr} [Produto]'; 
		lookupController.route = '/produto/'; 
		lookupController.gridColumns = produtoGridColumns(isForLookup: true); 
		lookupController.aliasColumns = ProdutoModel.aliasColumns; 
		lookupController.dbColumns = ProdutoModel.dbColumns; 
		lookupController.standardColumn = ProdutoModel.aliasColumns[ProdutoModel.dbColumns.indexOf('nome')]; 

		final plutoRowResult = await Get.toNamed(Routes.lookupPage); 
		if (plutoRowResult != null) { 
			wmsOrdemSeparacaoDetModel.idProduto = plutoRowResult.cells['id']!.value; 
			wmsOrdemSeparacaoDetModel.produtoModel = ProdutoModel.fromPlutoRow(plutoRowResult); 
			produtoModelController.text = wmsOrdemSeparacaoDetModel.produtoModel?.nome ?? ''; 
			formWasChangedDetail = true; 
		}
	}


  @override
  Future deleteSelected() async {
    final currentRow = plutoGridStateManager.currentRow;
    if (currentRow == null) {
      showInfoSnackBar(message: 'message_select_one_to_delete'.tr);
      return null;
    }
    showDeleteDialog(() async {
      final id = currentRow.cells['id']?.value;
      final tempId = currentRow.cells['tempId']?.value;
      wmsOrdemSeparacaoDetModelList.removeWhere((model) => (id != 0 && model.id == id) || (id == 0 && model.tempId == tempId));
      plutoGridStateManager.removeCurrentRow();
      userMadeChanges = true;
    });
  }

  @override
  void preventDataLoss() {
    if (formWasChangedDetail) {
      showQuestionDialog('message_data_loss'.tr, () => Get.back());
    } else {
      formWasChangedDetail = false;
      Get.back();
    }
  }

  @override
  void onClose() {
    produtoModelController.dispose();
    quantidadeController.dispose();
  }

}