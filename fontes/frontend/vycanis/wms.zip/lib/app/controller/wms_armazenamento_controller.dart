import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:extended_masked_text/extended_masked_text.dart';
import 'package:wms/app/page/shared_widget/input/input_imports.dart';

import 'package:wms/app/page/shared_widget/message_dialog.dart';
import 'package:wms/app/page/grid_columns/grid_columns_imports.dart';
import 'package:wms/app/routes/app_routes.dart';
import 'package:wms/app/controller/controller_imports.dart';
import 'package:wms/app/data/model/model_imports.dart';
import 'package:wms/app/data/repository/wms_armazenamento_repository.dart';

class WmsArmazenamentoController extends ControllerBase<WmsArmazenamentoModel, WmsArmazenamentoRepository> {

  WmsArmazenamentoController({required super.repository}) {
    dbColumns = WmsArmazenamentoModel.dbColumns;
    aliasColumns = WmsArmazenamentoModel.aliasColumns;
    gridColumns = wmsArmazenamentoGridColumns();
    functionName = "wms_armazenamento";
    screenTitle = "Armazenamento";
  }

  @override
  WmsArmazenamentoModel createNewModel() => WmsArmazenamentoModel();

  @override
  final standardFieldForFilter = WmsArmazenamentoModel.aliasColumns[WmsArmazenamentoModel.dbColumns.indexOf('quantidade')];

  final wmsRecebimentoCabecalhoModelController = TextEditingController();
  final produtoModelController = TextEditingController();
  final wmsCaixaModelController = TextEditingController();
  final quantidadeController = MoneyMaskedTextController(precision: 0, decimalSeparator: '', thousandSeparator: '');
  final dataArmazenagemController = DatePickerItemController(null);
  final horaArmazenagemController = MaskedTextController(mask: '00:00:00',);

  final Map<String, dynamic> mobileConfig = {
    'primaryColumns': ['quantidade'],
    'secondaryColumns': ['data_armazenagem'],
  };

  List<Map<String, dynamic>> get mobileItems {
    return modelList.map((wmsArmazenamento) => wmsArmazenamento.toJson).toList();
  }

  @override
  void prepareForInsert() {
    isNewRecord = true;
    currentModel = createNewModel();
    _resetForm();
    Get.toNamed(Routes.wmsArmazenamentoEditPage);
  }

  void _resetForm() {
    formWasChanged = false;
    wmsRecebimentoCabecalhoModelController.text = '';
    produtoModelController.text = '';
    wmsCaixaModelController.text = '';
    quantidadeController.updateValue(0);
    dataArmazenagemController.date = null;
    horaArmazenagemController.text = '';
  }

  @override
  void selectRowForEditingById(int id) {
    final model = modelList.firstWhere((m) => m.id == id);
    currentModel = model.clone();
    updateControllersFromModel();
    Get.toNamed(Routes.wmsArmazenamentoEditPage);
  }

  void updateControllersFromModel() {
    wmsRecebimentoCabecalhoModelController.text = currentModel.wmsRecebimentoCabecalhoModel?.codigoRecebimento?.toString() ?? '';
    produtoModelController.text = currentModel.produtoModel?.nome?.toString() ?? '';
    wmsCaixaModelController.text = currentModel.wmsCaixaModel?.codigo?.toString() ?? '';
    quantidadeController.updateValue((currentModel.quantidade ?? 0).toDouble());
    dataArmazenagemController.date = currentModel.dataArmazenagem;
    horaArmazenagemController.text = currentModel.horaArmazenagem ?? '';
    formWasChanged = false;
  }

  @override
  Future<void> save() async {
    if (!formKey.currentState!.validate()) {
      showErrorSnackBar(message: 'validator_form_message'.tr);
      return;
    }

    final existingIndex = modelList.indexWhere((m) => m.id == currentModel.id);

    if (existingIndex >= 0) {
      modelList[existingIndex] = currentModel.clone();
    }

    final result = await repository.save(wmsArmazenamentoModel: currentModel);
    if (result == null) return;

    if (existingIndex >= 0) {
      modelList[existingIndex] = result;
    } else {
      modelList.insert(0, result);
    }

    if (!GetPlatform.isMobile) {
      updateGridRow(result);
    }

    Get.back(result: true);
  }

  Future callWmsRecebimentoCabecalhoLookup() async { 
		final lookupController = Get.find<LookupController>(); 
		lookupController.refreshItems(standardValue: '%'); 
		lookupController.title = '${'lookup_page_title'.tr} [Recebimento]'; 
		lookupController.route = '/wms-recebimento-cabecalho/'; 
		lookupController.gridColumns = wmsRecebimentoCabecalhoGridColumns(isForLookup: true); 
		lookupController.aliasColumns = WmsRecebimentoCabecalhoModel.aliasColumns; 
		lookupController.dbColumns = WmsRecebimentoCabecalhoModel.dbColumns; 
		lookupController.standardColumn = WmsRecebimentoCabecalhoModel.aliasColumns[WmsRecebimentoCabecalhoModel.dbColumns.indexOf('codigorecebimento')]; 

		final plutoRowResult = await Get.toNamed(Routes.lookupPage); 
		if (plutoRowResult != null) { 
			currentModel.idWmsRecebimentoCabecalho = plutoRowResult.cells['id']!.value; 
			currentModel.wmsRecebimentoCabecalhoModel = WmsRecebimentoCabecalhoModel.fromPlutoRow(plutoRowResult); 
			wmsRecebimentoCabecalhoModelController.text = currentModel.wmsRecebimentoCabecalhoModel?.codigoRecebimento ?? ''; 
			formWasChanged = true; 
		}
	}

  Future callProdutoLookup() async { 
		final lookupController = Get.find<LookupController>(); 
		lookupController.refreshItems(standardValue: '%'); 
		lookupController.title = '${'lookup_page_title'.tr} [Produto]'; 
		lookupController.route = '/produto/'; 
		lookupController.gridColumns = produtoGridColumns(isForLookup: true); 
		lookupController.aliasColumns = ProdutoModel.aliasColumns; 
		lookupController.dbColumns = ProdutoModel.dbColumns; 
		lookupController.standardColumn = ProdutoModel.aliasColumns[ProdutoModel.dbColumns.indexOf('nome')]; 

		final plutoRowResult = await Get.toNamed(Routes.lookupPage); 
		if (plutoRowResult != null) { 
			currentModel.idProduto = plutoRowResult.cells['id']!.value; 
			currentModel.produtoModel = ProdutoModel.fromPlutoRow(plutoRowResult); 
			produtoModelController.text = currentModel.produtoModel?.nome ?? ''; 
			formWasChanged = true; 
		}
	}

  Future callWmsCaixaLookup() async { 
		final lookupController = Get.find<LookupController>(); 
		lookupController.refreshItems(standardValue: '%'); 
		lookupController.title = '${'lookup_page_title'.tr} [Caixa]'; 
		lookupController.route = '/wms-caixa/'; 
		lookupController.gridColumns = wmsCaixaGridColumns(isForLookup: true); 
		lookupController.aliasColumns = WmsCaixaModel.aliasColumns; 
		lookupController.dbColumns = WmsCaixaModel.dbColumns; 
		lookupController.standardColumn = WmsCaixaModel.aliasColumns[WmsCaixaModel.dbColumns.indexOf('codigo')]; 

		final plutoRowResult = await Get.toNamed(Routes.lookupPage); 
		if (plutoRowResult != null) { 
			currentModel.idWmsCaixa = plutoRowResult.cells['id']!.value; 
			currentModel.wmsCaixaModel = WmsCaixaModel.fromPlutoRow(plutoRowResult); 
			wmsCaixaModelController.text = currentModel.wmsCaixaModel?.codigo ?? ''; 
			formWasChanged = true; 
		}
	}


  @override
  void onClose() {
    wmsRecebimentoCabecalhoModelController.dispose();
    produtoModelController.dispose();
    wmsCaixaModelController.dispose();
    quantidadeController.dispose();
    dataArmazenagemController.dispose();
    horaArmazenagemController.dispose();
    super.onClose();
  }

}