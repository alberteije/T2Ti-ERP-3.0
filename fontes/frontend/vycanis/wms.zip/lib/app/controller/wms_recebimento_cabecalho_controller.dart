import 'package:flutter/material.dart';
import 'dart:math';
import 'package:get/get.dart';
import 'package:extended_masked_text/extended_masked_text.dart';
import 'package:wms/app/page/shared_widget/input/input_imports.dart';

import 'package:wms/app/infra/infra_imports.dart';
import 'package:wms/app/page/page_imports.dart';
import 'package:wms/app/page/shared_widget/message_dialog.dart';
import 'package:wms/app/page/grid_columns/grid_columns_imports.dart';
import 'package:wms/app/routes/app_routes.dart';
import 'package:wms/app/controller/controller_imports.dart';
import 'package:wms/app/data/model/model_imports.dart';
import 'package:wms/app/data/repository/wms_recebimento_cabecalho_repository.dart';

class WmsRecebimentoCabecalhoController extends ControllerBase<WmsRecebimentoCabecalhoModel, WmsRecebimentoCabecalhoRepository> 
with GetSingleTickerProviderStateMixin {

  WmsRecebimentoCabecalhoController({required super.repository}) {
    dbColumns = WmsRecebimentoCabecalhoModel.dbColumns;
    aliasColumns = WmsRecebimentoCabecalhoModel.aliasColumns;
    gridColumns = wmsRecebimentoCabecalhoGridColumns();
    functionName = "wms_recebimento_cabecalho";
    screenTitle = "Recebimento";
  }

  final wmsRecebimentoCabecalhoScaffoldKey = GlobalKey<ScaffoldState>();
  final wmsRecebimentoCabecalhoTabPageScaffoldKey = GlobalKey<ScaffoldState>();
  final wmsRecebimentoCabecalhoFormKey = GlobalKey<FormState>();
  late TabController tabController;
  String? mandatoryMessage;  

  @override
  WmsRecebimentoCabecalhoModel createNewModel() => WmsRecebimentoCabecalhoModel();

  @override
  final standardFieldForFilter = WmsRecebimentoCabecalhoModel.aliasColumns[WmsRecebimentoCabecalhoModel.dbColumns.indexOf('data_recebimento')];

  final wmsAgendamentoModelController = TextEditingController();
  final dataRecebimentoController = DatePickerItemController(null);
  final horaInicioController = MaskedTextController(mask: '00:00:00',);
  final horaFimController = MaskedTextController(mask: '00:00:00',);
  final volumeRecebidoController = MoneyMaskedTextController(precision: 0, decimalSeparator: '', thousandSeparator: '');
  final pesoRecebidoController = MoneyMaskedTextController();
  final inconsistenciaController = CustomDropdownButtonController('Sim');
  final codigoRecebimentoController = TextEditingController();
  final observacaoController = TextEditingController();

  final Map<String, dynamic> mobileConfig = {
    'primaryColumns': ['data_recebimento'],
    'secondaryColumns': ['hora_inicio'],
  };

  List<Map<String, dynamic>> get mobileItems {
    return modelList.map((wmsRecebimentoCabecalho) => wmsRecebimentoCabecalho.toJson).toList();
  }

  @override
  void prepareForInsert() {
    isNewRecord = true;
    currentModel = createNewModel();
    _resetForm();
    tabController.animateTo(0);
    updateControllersFromModel();
    Get.toNamed(Routes.wmsRecebimentoCabecalhoTabPage);
  }

  void _resetForm() {
    formWasChanged = false;
    wmsAgendamentoModelController.text = '';
    dataRecebimentoController.date = null;
    horaInicioController.text = '';
    horaFimController.text = '';
    volumeRecebidoController.updateValue(0);
    pesoRecebidoController.updateValue(0);
    inconsistenciaController.selected = 'Sim';
    codigoRecebimentoController.text = '';
    observacaoController.text = '';
  }

  @override
  void selectRowForEditingById(int id) {
    final model = modelList.firstWhere((m) => m.id == id);
    currentModel = model.clone();
    updateControllersFromModel();
    tabController.animateTo(0);
    Get.toNamed(Routes.wmsRecebimentoCabecalhoTabPage);
  }

  _configureChildrenControllers() {
    //Itens
		Get.put<WmsRecebimentoDetalheController>(WmsRecebimentoDetalheController()); 

  }
	
	_releaseChildrenControllers() {
    //Itens
		Get.delete<WmsRecebimentoDetalheController>(); 

	}
  
  void updateControllersFromModel() {
    wmsAgendamentoModelController.text = currentModel.wmsAgendamentoModel?.localOperacao?.toString() ?? '';
    dataRecebimentoController.date = currentModel.dataRecebimento;
    horaInicioController.text = currentModel.horaInicio ?? '';
    horaFimController.text = currentModel.horaFim ?? '';
    volumeRecebidoController.updateValue((currentModel.volumeRecebido ?? 0).toDouble());
    pesoRecebidoController.updateValue(currentModel.pesoRecebido ?? 0);
    inconsistenciaController.selected = currentModel.inconsistencia ?? 'Sim';
    codigoRecebimentoController.text = currentModel.codigoRecebimento ?? '';
    observacaoController.text = currentModel.observacao ?? '';

    formWasChanged = false;
    _updateChildrenControllersFromModel();
  }

  void _updateChildrenControllersFromModel() {
    //Itens
		final wmsRecebimentoDetalheController = Get.find<WmsRecebimentoDetalheController>(); 
		wmsRecebimentoDetalheController.userMadeChanges = false; 

  }

  @override
  Future<void> save() async {
    if (!validateCurrentForm()) return;
    if (validateForms()) {
      if (userMadeChanges()) {
        final existingIndex = modelList.indexWhere((m) => m.id == currentModel.id);

        if (existingIndex >= 0) {
          modelList[existingIndex] = currentModel.clone();
        }

        final result = await repository.save(wmsRecebimentoCabecalhoModel: currentModel);
        if (result == null) return;

        if (existingIndex >= 0) {
          modelList[existingIndex] = result;
        } else {
          modelList.insert(0, result);
        }

        if (!GetPlatform.isMobile) {
          updateGridRow(result);
        }

        Get.back(result: true);
      } else {
        Get.back();
      }
    } 
  }

  Future callWmsAgendamentoLookup() async { 
		final lookupController = Get.find<LookupController>(); 
		lookupController.refreshItems(standardValue: '%'); 
		lookupController.title = '${'lookup_page_title'.tr} [Agendamento]'; 
		lookupController.route = '/wms-agendamento/'; 
		lookupController.gridColumns = wmsAgendamentoGridColumns(isForLookup: true); 
		lookupController.aliasColumns = WmsAgendamentoModel.aliasColumns; 
		lookupController.dbColumns = WmsAgendamentoModel.dbColumns; 
		lookupController.standardColumn = WmsAgendamentoModel.aliasColumns[WmsAgendamentoModel.dbColumns.indexOf('local_operacao')]; 

		final plutoRowResult = await Get.toNamed(Routes.lookupPage); 
		if (plutoRowResult != null) { 
			currentModel.idWmsAgendamento = plutoRowResult.cells['id']!.value; 
			currentModel.wmsAgendamentoModel = WmsAgendamentoModel.fromPlutoRow(plutoRowResult); 
			wmsAgendamentoModelController.text = currentModel.wmsAgendamentoModel?.localOperacao ?? ''; 
			formWasChanged = true; 
		}
	}


  List<Tab> tabItems = [
    Tab( 
			icon: Icon(iconDataList[Random().nextInt(10)]), 
			text: 'Recebimento', 
		),
    Tab( 
			icon: Icon(iconDataList[Random().nextInt(10)]), 
			text: 'Itens', 
		),
  ];

  List<Widget> tabPages() {
    return [
      WmsRecebimentoCabecalhoEditPage(),
      const WmsRecebimentoDetalheListPage(),
    ];
  }

  @override
  void preventDataLoss() {
    if (userMadeChanges()) {
      showQuestionDialog('message_data_loss'.tr, () { 
        Get.back(); 
      });
    } else {
      Get.back();
    }
  }  

  bool userMadeChanges() {
    return
    formWasChanged 
    || 
		Get.find<WmsRecebimentoDetalheController>().userMadeChanges
    ;
  }

  void tabChange(int index) {
    validateCurrentForm();
  }

  bool validateCurrentForm() {
    mandatoryMessage = ValidateFormField.validateMandatory(currentModel.wmsAgendamentoModel?.localOperacao); 
		if (mandatoryMessage != null) { 
			tabController.animateTo(0); 
			showErrorSnackBar(message: '$mandatoryMessage [Agendamento]'); 
			return false; 
		}
    return true;
  }

  bool validateForms() {
    return true;
  }

  @override
  void onInit() {
    super.onInit();
    tabController = TabController(vsync: this, length: tabItems.length);
    _configureChildrenControllers();
  }
	
  @override
  void onClose() {
    tabController.dispose();
    wmsAgendamentoModelController.dispose();
    dataRecebimentoController.dispose();
    horaInicioController.dispose();
    horaFimController.dispose();
    volumeRecebidoController.dispose();
    pesoRecebidoController.dispose();
    inconsistenciaController.dispose();
    codigoRecebimentoController.dispose();
    observacaoController.dispose();
    _releaseChildrenControllers();
    super.onClose();
  }	
}