import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:extended_masked_text/extended_masked_text.dart';

import 'package:wms/app/page/shared_widget/message_dialog.dart';
import 'package:wms/app/page/grid_columns/grid_columns_imports.dart';
import 'package:wms/app/routes/app_routes.dart';
import 'package:wms/app/controller/controller_imports.dart';
import 'package:wms/app/data/model/model_imports.dart';
import 'package:wms/app/data/repository/wms_rua_repository.dart';

class WmsRuaController extends ControllerBase<WmsRuaModel, WmsRuaRepository> {

  WmsRuaController({required super.repository}) {
    dbColumns = WmsRuaModel.dbColumns;
    aliasColumns = WmsRuaModel.aliasColumns;
    gridColumns = wmsRuaGridColumns();
    functionName = "wms_rua";
    screenTitle = "Rua";
  }

  @override
  WmsRuaModel createNewModel() => WmsRuaModel();

  @override
  final standardFieldForFilter = WmsRuaModel.aliasColumns[WmsRuaModel.dbColumns.indexOf('codigo')];

  final codigoController = TextEditingController();
  final quantidadeEstanteController = MoneyMaskedTextController(precision: 0, decimalSeparator: '', thousandSeparator: '');
  final nomeController = TextEditingController();

  final Map<String, dynamic> mobileConfig = {
    'primaryColumns': ['codigo'],
    'secondaryColumns': ['quantidade_estante'],
  };

  List<Map<String, dynamic>> get mobileItems {
    return modelList.map((wmsRua) => wmsRua.toJson).toList();
  }

  @override
  void prepareForInsert() {
    isNewRecord = true;
    currentModel = createNewModel();
    _resetForm();
    Get.toNamed(Routes.wmsRuaEditPage);
  }

  void _resetForm() {
    formWasChanged = false;
    codigoController.text = '';
    quantidadeEstanteController.updateValue(0);
    nomeController.text = '';
  }

  @override
  void selectRowForEditingById(int id) {
    final model = modelList.firstWhere((m) => m.id == id);
    currentModel = model.clone();
    updateControllersFromModel();
    Get.toNamed(Routes.wmsRuaEditPage);
  }

  void updateControllersFromModel() {
    codigoController.text = currentModel.codigo ?? '';
    quantidadeEstanteController.updateValue((currentModel.quantidadeEstante ?? 0).toDouble());
    nomeController.text = currentModel.nome ?? '';
    formWasChanged = false;
  }

  @override
  Future<void> save() async {
    if (!formKey.currentState!.validate()) {
      showErrorSnackBar(message: 'validator_form_message'.tr);
      return;
    }

    final existingIndex = modelList.indexWhere((m) => m.id == currentModel.id);

    if (existingIndex >= 0) {
      modelList[existingIndex] = currentModel.clone();
    }

    final result = await repository.save(wmsRuaModel: currentModel);
    if (result == null) return;

    if (existingIndex >= 0) {
      modelList[existingIndex] = result;
    } else {
      modelList.insert(0, result);
    }

    if (!GetPlatform.isMobile) {
      updateGridRow(result);
    }

    Get.back(result: true);
  }


  @override
  void onClose() {
    codigoController.dispose();
    quantidadeEstanteController.dispose();
    nomeController.dispose();
    super.onClose();
  }

}