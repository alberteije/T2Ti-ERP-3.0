import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:extended_masked_text/extended_masked_text.dart';
import 'package:wms/app/page/shared_widget/input/input_imports.dart';

import 'package:wms/app/page/shared_widget/message_dialog.dart';
import 'package:wms/app/page/grid_columns/grid_columns_imports.dart';
import 'package:wms/app/routes/app_routes.dart';
import 'package:wms/app/controller/controller_imports.dart';
import 'package:wms/app/data/model/model_imports.dart';
import 'package:wms/app/data/repository/wms_agendamento_repository.dart';

class WmsAgendamentoController extends ControllerBase<WmsAgendamentoModel, WmsAgendamentoRepository> {

  WmsAgendamentoController({required super.repository}) {
    dbColumns = WmsAgendamentoModel.dbColumns;
    aliasColumns = WmsAgendamentoModel.aliasColumns;
    gridColumns = wmsAgendamentoGridColumns();
    functionName = "wms_agendamento";
    screenTitle = "Agendamento";
  }

  @override
  WmsAgendamentoModel createNewModel() => WmsAgendamentoModel();

  @override
  final standardFieldForFilter = WmsAgendamentoModel.aliasColumns[WmsAgendamentoModel.dbColumns.indexOf('data_operacao')];

  final dataOperacaoController = DatePickerItemController(null);
  final horaOperacaoController = MaskedTextController(mask: '00:00:00',);
  final localOperacaoController = TextEditingController();
  final quantidadeVolumeController = MoneyMaskedTextController(precision: 0, decimalSeparator: '', thousandSeparator: '');
  final pesoTotalVolumeController = MoneyMaskedTextController();
  final quantidadePessoaController = MoneyMaskedTextController(precision: 0, decimalSeparator: '', thousandSeparator: '');
  final quantidadeHoraController = MoneyMaskedTextController(precision: 0, decimalSeparator: '', thousandSeparator: '');

  final Map<String, dynamic> mobileConfig = {
    'primaryColumns': ['data_operacao'],
    'secondaryColumns': ['hora_operacao'],
  };

  List<Map<String, dynamic>> get mobileItems {
    return modelList.map((wmsAgendamento) => wmsAgendamento.toJson).toList();
  }

  @override
  void prepareForInsert() {
    isNewRecord = true;
    currentModel = createNewModel();
    _resetForm();
    Get.toNamed(Routes.wmsAgendamentoEditPage);
  }

  void _resetForm() {
    formWasChanged = false;
    dataOperacaoController.date = null;
    horaOperacaoController.text = '';
    localOperacaoController.text = '';
    quantidadeVolumeController.updateValue(0);
    pesoTotalVolumeController.updateValue(0);
    quantidadePessoaController.updateValue(0);
    quantidadeHoraController.updateValue(0);
  }

  @override
  void selectRowForEditingById(int id) {
    final model = modelList.firstWhere((m) => m.id == id);
    currentModel = model.clone();
    updateControllersFromModel();
    Get.toNamed(Routes.wmsAgendamentoEditPage);
  }

  void updateControllersFromModel() {
    dataOperacaoController.date = currentModel.dataOperacao;
    horaOperacaoController.text = currentModel.horaOperacao ?? '';
    localOperacaoController.text = currentModel.localOperacao ?? '';
    quantidadeVolumeController.updateValue((currentModel.quantidadeVolume ?? 0).toDouble());
    pesoTotalVolumeController.updateValue(currentModel.pesoTotalVolume ?? 0);
    quantidadePessoaController.updateValue((currentModel.quantidadePessoa ?? 0).toDouble());
    quantidadeHoraController.updateValue((currentModel.quantidadeHora ?? 0).toDouble());
    formWasChanged = false;
  }

  @override
  Future<void> save() async {
    if (!formKey.currentState!.validate()) {
      showErrorSnackBar(message: 'validator_form_message'.tr);
      return;
    }

    final existingIndex = modelList.indexWhere((m) => m.id == currentModel.id);

    if (existingIndex >= 0) {
      modelList[existingIndex] = currentModel.clone();
    }

    final result = await repository.save(wmsAgendamentoModel: currentModel);
    if (result == null) return;

    if (existingIndex >= 0) {
      modelList[existingIndex] = result;
    } else {
      modelList.insert(0, result);
    }

    if (!GetPlatform.isMobile) {
      updateGridRow(result);
    }

    Get.back(result: true);
  }


  @override
  void onClose() {
    dataOperacaoController.dispose();
    horaOperacaoController.dispose();
    localOperacaoController.dispose();
    quantidadeVolumeController.dispose();
    pesoTotalVolumeController.dispose();
    quantidadePessoaController.dispose();
    quantidadeHoraController.dispose();
    super.onClose();
  }

}