import 'package:flutter/material.dart';
import 'dart:math';
import 'package:get/get.dart';
import 'package:extended_masked_text/extended_masked_text.dart';

import 'package:wms/app/infra/infra_imports.dart';
import 'package:wms/app/page/page_imports.dart';
import 'package:wms/app/page/shared_widget/message_dialog.dart';
import 'package:wms/app/page/grid_columns/grid_columns_imports.dart';
import 'package:wms/app/routes/app_routes.dart';
import 'package:wms/app/controller/controller_imports.dart';
import 'package:wms/app/data/model/model_imports.dart';
import 'package:wms/app/data/repository/wms_estante_repository.dart';

class WmsEstanteController extends ControllerBase<WmsEstanteModel, WmsEstanteRepository> 
with GetSingleTickerProviderStateMixin {

  WmsEstanteController({required super.repository}) {
    dbColumns = WmsEstanteModel.dbColumns;
    aliasColumns = WmsEstanteModel.aliasColumns;
    gridColumns = wmsEstanteGridColumns();
    functionName = "wms_estante";
    screenTitle = "Estante";
  }

  final wmsEstanteScaffoldKey = GlobalKey<ScaffoldState>();
  final wmsEstanteTabPageScaffoldKey = GlobalKey<ScaffoldState>();
  final wmsEstanteFormKey = GlobalKey<FormState>();
  late TabController tabController;
  String? mandatoryMessage;  

  @override
  WmsEstanteModel createNewModel() => WmsEstanteModel();

  @override
  final standardFieldForFilter = WmsEstanteModel.aliasColumns[WmsEstanteModel.dbColumns.indexOf('codigo')];

  final wmsRuaModelController = TextEditingController();
  final codigoController = TextEditingController();
  final quantidadeCaixaController = MoneyMaskedTextController(precision: 0, decimalSeparator: '', thousandSeparator: '');

  final Map<String, dynamic> mobileConfig = {
    'primaryColumns': ['codigo'],
    'secondaryColumns': ['quantidade_caixa'],
  };

  List<Map<String, dynamic>> get mobileItems {
    return modelList.map((wmsEstante) => wmsEstante.toJson).toList();
  }

  @override
  void prepareForInsert() {
    isNewRecord = true;
    currentModel = createNewModel();
    _resetForm();
    tabController.animateTo(0);
    updateControllersFromModel();
    Get.toNamed(Routes.wmsEstanteTabPage);
  }

  void _resetForm() {
    formWasChanged = false;
    wmsRuaModelController.text = '';
    codigoController.text = '';
    quantidadeCaixaController.updateValue(0);
  }

  @override
  void selectRowForEditingById(int id) {
    final model = modelList.firstWhere((m) => m.id == id);
    currentModel = model.clone();
    updateControllersFromModel();
    tabController.animateTo(0);
    Get.toNamed(Routes.wmsEstanteTabPage);
  }

  _configureChildrenControllers() {
    //Caixa
		Get.put<WmsCaixaController>(WmsCaixaController()); 

  }
	
	_releaseChildrenControllers() {
    //Caixa
		Get.delete<WmsCaixaController>(); 

	}
  
  void updateControllersFromModel() {
    wmsRuaModelController.text = currentModel.wmsRuaModel?.nome?.toString() ?? '';
    codigoController.text = currentModel.codigo ?? '';
    quantidadeCaixaController.updateValue((currentModel.quantidadeCaixa ?? 0).toDouble());

    formWasChanged = false;
    _updateChildrenControllersFromModel();
  }

  void _updateChildrenControllersFromModel() {
    //Caixa
		final wmsCaixaController = Get.find<WmsCaixaController>(); 
		wmsCaixaController.userMadeChanges = false; 

  }

  @override
  Future<void> save() async {
    if (!validateCurrentForm()) return;
    if (validateForms()) {
      if (userMadeChanges()) {
        final existingIndex = modelList.indexWhere((m) => m.id == currentModel.id);

        if (existingIndex >= 0) {
          modelList[existingIndex] = currentModel.clone();
        }

        final result = await repository.save(wmsEstanteModel: currentModel);
        if (result == null) return;

        if (existingIndex >= 0) {
          modelList[existingIndex] = result;
        } else {
          modelList.insert(0, result);
        }

        if (!GetPlatform.isMobile) {
          updateGridRow(result);
        }

        Get.back(result: true);
      } else {
        Get.back();
      }
    } 
  }

  Future callWmsRuaLookup() async { 
		final lookupController = Get.find<LookupController>(); 
		lookupController.refreshItems(standardValue: '%'); 
		lookupController.title = '${'lookup_page_title'.tr} [Rua]'; 
		lookupController.route = '/wms-rua/'; 
		lookupController.gridColumns = wmsRuaGridColumns(isForLookup: true); 
		lookupController.aliasColumns = WmsRuaModel.aliasColumns; 
		lookupController.dbColumns = WmsRuaModel.dbColumns; 
		lookupController.standardColumn = WmsRuaModel.aliasColumns[WmsRuaModel.dbColumns.indexOf('nome')]; 

		final plutoRowResult = await Get.toNamed(Routes.lookupPage); 
		if (plutoRowResult != null) { 
			currentModel.idWmsRua = plutoRowResult.cells['id']!.value; 
			currentModel.wmsRuaModel = WmsRuaModel.fromPlutoRow(plutoRowResult); 
			wmsRuaModelController.text = currentModel.wmsRuaModel?.nome ?? ''; 
			formWasChanged = true; 
		}
	}


  List<Tab> tabItems = [
    Tab( 
			icon: Icon(iconDataList[Random().nextInt(10)]), 
			text: 'Estante', 
		),
    Tab( 
			icon: Icon(iconDataList[Random().nextInt(10)]), 
			text: 'Caixa', 
		),
  ];

  List<Widget> tabPages() {
    return [
      WmsEstanteEditPage(),
      const WmsCaixaListPage(),
    ];
  }

  @override
  void preventDataLoss() {
    if (userMadeChanges()) {
      showQuestionDialog('message_data_loss'.tr, () { 
        Get.back(); 
      });
    } else {
      Get.back();
    }
  }  

  bool userMadeChanges() {
    return
    formWasChanged 
    || 
		Get.find<WmsCaixaController>().userMadeChanges
    ;
  }

  void tabChange(int index) {
    validateCurrentForm();
  }

  bool validateCurrentForm() {
    mandatoryMessage = ValidateFormField.validateMandatory(currentModel.wmsRuaModel?.nome); 
		if (mandatoryMessage != null) { 
			tabController.animateTo(0); 
			showErrorSnackBar(message: '$mandatoryMessage [Rua]'); 
			return false; 
		}
    return true;
  }

  bool validateForms() {
    return true;
  }

  @override
  void onInit() {
    super.onInit();
    tabController = TabController(vsync: this, length: tabItems.length);
    _configureChildrenControllers();
  }
	
  @override
  void onClose() {
    tabController.dispose();
    wmsRuaModelController.dispose();
    codigoController.dispose();
    quantidadeCaixaController.dispose();
    _releaseChildrenControllers();
    super.onClose();
  }	
}