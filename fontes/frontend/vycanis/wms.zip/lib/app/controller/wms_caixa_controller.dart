import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:pluto_grid/pluto_grid.dart';
import 'package:extended_masked_text/extended_masked_text.dart';

import 'package:wms/app/page/page_imports.dart';
import 'package:wms/app/page/shared_widget/message_dialog.dart';
import 'package:wms/app/page/grid_columns/grid_columns_imports.dart';
import 'package:wms/app/controller/controller_imports.dart';
import 'package:wms/app/data/model/model_imports.dart';

class WmsCaixaController extends ControllerBase<WmsCaixaModel, void> {

  WmsCaixaController() : super(repository: null) {
    dbColumns = WmsCaixaModel.dbColumns;
    aliasColumns = WmsCaixaModel.aliasColumns;
    gridColumns = wmsCaixaGridColumns();
    functionName = "wms_caixa";
    screenTitle = "Caixa";
  }

  final _wmsCaixaModel = WmsCaixaModel().obs;
  WmsCaixaModel get wmsCaixaModel => _wmsCaixaModel.value;
  set wmsCaixaModel(value) => _wmsCaixaModel.value = value ?? WmsCaixaModel();

  List<WmsCaixaModel> get wmsCaixaModelList => Get.find<WmsEstanteController>().currentModel.wmsCaixaModelList ?? [];

  final _userMadeChanges = false.obs;
  get userMadeChanges => _userMadeChanges.value;
  set userMadeChanges(value) => _userMadeChanges.value = value;

  final _formWasChangedDetail = false.obs;
  bool get formWasChangedDetail => _formWasChangedDetail.value;
  set formWasChangedDetail(value) => _formWasChangedDetail.value = value;

  late PlutoGridStateManager _plutoGridStateManager;
  @override
  PlutoGridStateManager get plutoGridStateManager => _plutoGridStateManager;
  @override
  set plutoGridStateManager(value) => _plutoGridStateManager = value;

  final wmsCaixaScaffoldKey = GlobalKey<ScaffoldState>();
  final wmsCaixaFormKey = GlobalKey<FormState>();

  @override
  WmsCaixaModel createNewModel() => WmsCaixaModel();

  @override
  final standardFieldForFilter = WmsCaixaModel.aliasColumns[WmsCaixaModel.dbColumns.indexOf('codigo')];

  final codigoController = TextEditingController();
  final alturaController = MoneyMaskedTextController(precision: 0, decimalSeparator: '', thousandSeparator: '');
  final larguraController = MoneyMaskedTextController(precision: 0, decimalSeparator: '', thousandSeparator: '');
  final profundidadeController = MoneyMaskedTextController(precision: 0, decimalSeparator: '', thousandSeparator: '');

  final Map<String, dynamic> mobileConfig = {
    'primaryColumns': ['codigo'],
    'secondaryColumns': ['altura'],
  };

  List<Map<String, dynamic>> get mobileItems {
    return modelList.map((wmsCaixa) => wmsCaixa.toJson).toList();
  }

  @override
  List<PlutoRow> plutoRows() => List<PlutoRow>.from(wmsCaixaModelList.map((model) => model.toPlutoRow()));

  @override
  Future<void> getList({Filter? filter}) async {}

  @override
  void prepareForInsert() {
    isNewRecord = true;
    wmsCaixaModel = createNewModel();
    _resetForm();
    Get.to(() => WmsCaixaEditPage());
  }

  void _resetForm() {
    formWasChangedDetail = false;
    codigoController.text = '';
    alturaController.updateValue(0);
    larguraController.updateValue(0);
    profundidadeController.updateValue(0);
  }

  @override
  void selectRowForEditing(PlutoRow? row) async {
    if (row == null) {
      showInfoSnackBar(message: 'message_select_one_to_edited'.tr);
      return;
    }

    selectRowForEditingByTempId(row.cells['tempId']?.value);
  }

  @override
  void selectRowForEditingById(int id) {}

  void selectRowForEditingByTempId(String tempId) {
		isNewRecord = false;
    final model = wmsCaixaModelList.firstWhere((m) => m.tempId == tempId);
    wmsCaixaModel = model.clone();
		wmsCaixaModel.tempId = model.tempId;
    updateControllersFromModel();
    Get.to(() => WmsCaixaEditPage());
  }

  void updateControllersFromModel() {
    codigoController.text = wmsCaixaModel.codigo ?? '';
    alturaController.updateValue((wmsCaixaModel.altura ?? 0).toDouble());
    larguraController.updateValue((wmsCaixaModel.largura ?? 0).toDouble());
    profundidadeController.updateValue((wmsCaixaModel.profundidade ?? 0).toDouble());
    formWasChangedDetail = false;
  }

  @override
  Future<void> save() async {
    if (!wmsCaixaFormKey.currentState!.validate()) {
      showErrorSnackBar(message: 'validator_form_message'.tr);
      return;
    }

    if (formWasChangedDetail) {
      if (isNewRecord) {
        wmsCaixaModelList.insert(0, wmsCaixaModel.clone());
      } else {
        final index = wmsCaixaModelList.indexWhere((m) => m.tempId == wmsCaixaModel.tempId);
        if (index >= 0) {
          wmsCaixaModelList[index] = wmsCaixaModel.clone();
        }
      }

      userMadeChanges = true;
      loadData();
      Get.back(result: true);
    } else {
      Get.back();
    }
  }


  @override
  Future deleteSelected() async {
    final currentRow = plutoGridStateManager.currentRow;
    if (currentRow == null) {
      showInfoSnackBar(message: 'message_select_one_to_delete'.tr);
      return null;
    }
    showDeleteDialog(() async {
      final id = currentRow.cells['id']?.value;
      final tempId = currentRow.cells['tempId']?.value;
      wmsCaixaModelList.removeWhere((model) => (id != 0 && model.id == id) || (id == 0 && model.tempId == tempId));
      plutoGridStateManager.removeCurrentRow();
      userMadeChanges = true;
    });
  }

  @override
  void preventDataLoss() {
    if (formWasChangedDetail) {
      showQuestionDialog('message_data_loss'.tr, () => Get.back());
    } else {
      formWasChangedDetail = false;
      Get.back();
    }
  }

  @override
  void onClose() {
    codigoController.dispose();
    alturaController.dispose();
    larguraController.dispose();
    profundidadeController.dispose();
  }

}