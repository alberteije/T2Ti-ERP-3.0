import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:pluto_grid/pluto_grid.dart';
import 'package:extended_masked_text/extended_masked_text.dart';
import 'package:wms/app/page/shared_widget/input/input_imports.dart';
import 'package:wms/app/routes/app_routes.dart';

import 'package:wms/app/page/page_imports.dart';
import 'package:wms/app/page/shared_widget/message_dialog.dart';
import 'package:wms/app/page/grid_columns/grid_columns_imports.dart';
import 'package:wms/app/controller/controller_imports.dart';
import 'package:wms/app/data/model/model_imports.dart';

class WmsRecebimentoDetalheController extends ControllerBase<WmsRecebimentoDetalheModel, void> {

  WmsRecebimentoDetalheController() : super(repository: null) {
    dbColumns = WmsRecebimentoDetalheModel.dbColumns;
    aliasColumns = WmsRecebimentoDetalheModel.aliasColumns;
    gridColumns = wmsRecebimentoDetalheGridColumns();
    functionName = "wms_recebimento_detalhe";
    screenTitle = "Itens";
  }

  final _wmsRecebimentoDetalheModel = WmsRecebimentoDetalheModel().obs;
  WmsRecebimentoDetalheModel get wmsRecebimentoDetalheModel => _wmsRecebimentoDetalheModel.value;
  set wmsRecebimentoDetalheModel(value) => _wmsRecebimentoDetalheModel.value = value ?? WmsRecebimentoDetalheModel();

  List<WmsRecebimentoDetalheModel> get wmsRecebimentoDetalheModelList => Get.find<WmsRecebimentoCabecalhoController>().currentModel.wmsRecebimentoDetalheModelList ?? [];

  final _userMadeChanges = false.obs;
  get userMadeChanges => _userMadeChanges.value;
  set userMadeChanges(value) => _userMadeChanges.value = value;

  final _formWasChangedDetail = false.obs;
  bool get formWasChangedDetail => _formWasChangedDetail.value;
  set formWasChangedDetail(value) => _formWasChangedDetail.value = value;

  late PlutoGridStateManager _plutoGridStateManager;
  @override
  PlutoGridStateManager get plutoGridStateManager => _plutoGridStateManager;
  @override
  set plutoGridStateManager(value) => _plutoGridStateManager = value;

  final wmsRecebimentoDetalheScaffoldKey = GlobalKey<ScaffoldState>();
  final wmsRecebimentoDetalheFormKey = GlobalKey<FormState>();

  @override
  WmsRecebimentoDetalheModel createNewModel() => WmsRecebimentoDetalheModel();

  @override
  final standardFieldForFilter = WmsRecebimentoDetalheModel.aliasColumns[WmsRecebimentoDetalheModel.dbColumns.indexOf('quantidade_volume')];

  final produtoModelController = TextEditingController();
  final quantidadeVolumeController = MoneyMaskedTextController(precision: 0, decimalSeparator: '', thousandSeparator: '');
  final quantidadeItemPorVolumeController = MoneyMaskedTextController(precision: 0, decimalSeparator: '', thousandSeparator: '');
  final quantidadeRecebidaController = MoneyMaskedTextController(precision: 0, decimalSeparator: '', thousandSeparator: '');
  final destinoController = CustomDropdownButtonController('Armazenamento');

  final Map<String, dynamic> mobileConfig = {
    'primaryColumns': ['quantidade_volume'],
    'secondaryColumns': ['quantidade_item_por_volume'],
  };

  List<Map<String, dynamic>> get mobileItems {
    return modelList.map((wmsRecebimentoDetalhe) => wmsRecebimentoDetalhe.toJson).toList();
  }

  @override
  List<PlutoRow> plutoRows() => List<PlutoRow>.from(wmsRecebimentoDetalheModelList.map((model) => model.toPlutoRow()));

  @override
  Future<void> getList({Filter? filter}) async {}

  @override
  void prepareForInsert() {
    isNewRecord = true;
    wmsRecebimentoDetalheModel = createNewModel();
    _resetForm();
    Get.to(() => WmsRecebimentoDetalheEditPage());
  }

  void _resetForm() {
    formWasChangedDetail = false;
    produtoModelController.text = '';
    quantidadeVolumeController.updateValue(0);
    quantidadeItemPorVolumeController.updateValue(0);
    quantidadeRecebidaController.updateValue(0);
    destinoController.selected = 'Armazenamento';
  }

  @override
  void selectRowForEditing(PlutoRow? row) async {
    if (row == null) {
      showInfoSnackBar(message: 'message_select_one_to_edited'.tr);
      return;
    }

    selectRowForEditingByTempId(row.cells['tempId']?.value);
  }

  @override
  void selectRowForEditingById(int id) {}

  void selectRowForEditingByTempId(String tempId) {
		isNewRecord = false;
    final model = wmsRecebimentoDetalheModelList.firstWhere((m) => m.tempId == tempId);
    wmsRecebimentoDetalheModel = model.clone();
		wmsRecebimentoDetalheModel.tempId = model.tempId;
    updateControllersFromModel();
    Get.to(() => WmsRecebimentoDetalheEditPage());
  }

  void updateControllersFromModel() {
    produtoModelController.text = wmsRecebimentoDetalheModel.produtoModel?.nome?.toString() ?? '';
    quantidadeVolumeController.updateValue((wmsRecebimentoDetalheModel.quantidadeVolume ?? 0).toDouble());
    quantidadeItemPorVolumeController.updateValue((wmsRecebimentoDetalheModel.quantidadeItemPorVolume ?? 0).toDouble());
    quantidadeRecebidaController.updateValue((wmsRecebimentoDetalheModel.quantidadeRecebida ?? 0).toDouble());
    destinoController.selected = wmsRecebimentoDetalheModel.destino ?? 'Armazenamento';
    formWasChangedDetail = false;
  }

  @override
  Future<void> save() async {
    if (!wmsRecebimentoDetalheFormKey.currentState!.validate()) {
      showErrorSnackBar(message: 'validator_form_message'.tr);
      return;
    }

    if (formWasChangedDetail) {
      if (isNewRecord) {
        wmsRecebimentoDetalheModelList.insert(0, wmsRecebimentoDetalheModel.clone());
      } else {
        final index = wmsRecebimentoDetalheModelList.indexWhere((m) => m.tempId == wmsRecebimentoDetalheModel.tempId);
        if (index >= 0) {
          wmsRecebimentoDetalheModelList[index] = wmsRecebimentoDetalheModel.clone();
        }
      }

      userMadeChanges = true;
      loadData();
      Get.back(result: true);
    } else {
      Get.back();
    }
  }

  Future callProdutoLookup() async { 
		final lookupController = Get.find<LookupController>(); 
		lookupController.refreshItems(standardValue: '%'); 
		lookupController.title = '${'lookup_page_title'.tr} [Produto]'; 
		lookupController.route = '/produto/'; 
		lookupController.gridColumns = produtoGridColumns(isForLookup: true); 
		lookupController.aliasColumns = ProdutoModel.aliasColumns; 
		lookupController.dbColumns = ProdutoModel.dbColumns; 
		lookupController.standardColumn = ProdutoModel.aliasColumns[ProdutoModel.dbColumns.indexOf('nome')]; 

		final plutoRowResult = await Get.toNamed(Routes.lookupPage); 
		if (plutoRowResult != null) { 
			wmsRecebimentoDetalheModel.idProduto = plutoRowResult.cells['id']!.value; 
			wmsRecebimentoDetalheModel.produtoModel = ProdutoModel.fromPlutoRow(plutoRowResult); 
			produtoModelController.text = wmsRecebimentoDetalheModel.produtoModel?.nome ?? ''; 
			formWasChangedDetail = true; 
		}
	}


  @override
  Future deleteSelected() async {
    final currentRow = plutoGridStateManager.currentRow;
    if (currentRow == null) {
      showInfoSnackBar(message: 'message_select_one_to_delete'.tr);
      return null;
    }
    showDeleteDialog(() async {
      final id = currentRow.cells['id']?.value;
      final tempId = currentRow.cells['tempId']?.value;
      wmsRecebimentoDetalheModelList.removeWhere((model) => (id != 0 && model.id == id) || (id == 0 && model.tempId == tempId));
      plutoGridStateManager.removeCurrentRow();
      userMadeChanges = true;
    });
  }

  @override
  void preventDataLoss() {
    if (formWasChangedDetail) {
      showQuestionDialog('message_data_loss'.tr, () => Get.back());
    } else {
      formWasChangedDetail = false;
      Get.back();
    }
  }

  @override
  void onClose() {
    produtoModelController.dispose();
    quantidadeVolumeController.dispose();
    quantidadeItemPorVolumeController.dispose();
    quantidadeRecebidaController.dispose();
    destinoController.dispose();
  }

}