import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:extended_masked_text/extended_masked_text.dart';
import 'package:wms/app/page/shared_widget/input/input_imports.dart';

import 'package:wms/app/page/shared_widget/message_dialog.dart';
import 'package:wms/app/page/grid_columns/grid_columns_imports.dart';
import 'package:wms/app/routes/app_routes.dart';
import 'package:wms/app/controller/controller_imports.dart';
import 'package:wms/app/data/model/model_imports.dart';
import 'package:wms/app/data/repository/wms_expedicao_repository.dart';

class WmsExpedicaoController extends ControllerBase<WmsExpedicaoModel, WmsExpedicaoRepository> {

  WmsExpedicaoController({required super.repository}) {
    dbColumns = WmsExpedicaoModel.dbColumns;
    aliasColumns = WmsExpedicaoModel.aliasColumns;
    gridColumns = wmsExpedicaoGridColumns();
    functionName = "wms_expedicao";
    screenTitle = "Expedição";
  }

  @override
  WmsExpedicaoModel createNewModel() => WmsExpedicaoModel();

  @override
  final standardFieldForFilter = WmsExpedicaoModel.aliasColumns[WmsExpedicaoModel.dbColumns.indexOf('quantidade')];

  final produtoModelController = TextEditingController();
  final quantidadeController = MoneyMaskedTextController(precision: 0, decimalSeparator: '', thousandSeparator: '');
  final dataSaidaController = DatePickerItemController(null);
  final horaSaidaController = MaskedTextController(mask: '00:00:00',);
  final veioDeOndeController = CustomDropdownButtonController('Recebimento');
  final codigoSeparacaoRecebimentoController = TextEditingController();

  final Map<String, dynamic> mobileConfig = {
    'primaryColumns': ['quantidade'],
    'secondaryColumns': ['data_saida'],
  };

  List<Map<String, dynamic>> get mobileItems {
    return modelList.map((wmsExpedicao) => wmsExpedicao.toJson).toList();
  }

  @override
  void prepareForInsert() {
    isNewRecord = true;
    currentModel = createNewModel();
    _resetForm();
    Get.toNamed(Routes.wmsExpedicaoEditPage);
  }

  void _resetForm() {
    formWasChanged = false;
    produtoModelController.text = '';
    quantidadeController.updateValue(0);
    dataSaidaController.date = null;
    horaSaidaController.text = '';
    veioDeOndeController.selected = 'Recebimento';
    codigoSeparacaoRecebimentoController.text = '';
  }

  @override
  void selectRowForEditingById(int id) {
    final model = modelList.firstWhere((m) => m.id == id);
    currentModel = model.clone();
    updateControllersFromModel();
    Get.toNamed(Routes.wmsExpedicaoEditPage);
  }

  void updateControllersFromModel() {
    produtoModelController.text = currentModel.produtoModel?.nome?.toString() ?? '';
    quantidadeController.updateValue((currentModel.quantidade ?? 0).toDouble());
    dataSaidaController.date = currentModel.dataSaida;
    horaSaidaController.text = currentModel.horaSaida ?? '';
    veioDeOndeController.selected = currentModel.veioDeOnde ?? 'Recebimento';
    codigoSeparacaoRecebimentoController.text = currentModel.codigoSeparacaoRecebimento ?? '';
    formWasChanged = false;
  }

  @override
  Future<void> save() async {
    if (!formKey.currentState!.validate()) {
      showErrorSnackBar(message: 'validator_form_message'.tr);
      return;
    }

    final existingIndex = modelList.indexWhere((m) => m.id == currentModel.id);

    if (existingIndex >= 0) {
      modelList[existingIndex] = currentModel.clone();
    }

    final result = await repository.save(wmsExpedicaoModel: currentModel);
    if (result == null) return;

    if (existingIndex >= 0) {
      modelList[existingIndex] = result;
    } else {
      modelList.insert(0, result);
    }

    if (!GetPlatform.isMobile) {
      updateGridRow(result);
    }

    Get.back(result: true);
  }

  Future callProdutoLookup() async { 
		final lookupController = Get.find<LookupController>(); 
		lookupController.refreshItems(standardValue: '%'); 
		lookupController.title = '${'lookup_page_title'.tr} [Produto]'; 
		lookupController.route = '/produto/'; 
		lookupController.gridColumns = produtoGridColumns(isForLookup: true); 
		lookupController.aliasColumns = ProdutoModel.aliasColumns; 
		lookupController.dbColumns = ProdutoModel.dbColumns; 
		lookupController.standardColumn = ProdutoModel.aliasColumns[ProdutoModel.dbColumns.indexOf('nome')]; 

		final plutoRowResult = await Get.toNamed(Routes.lookupPage); 
		if (plutoRowResult != null) { 
			currentModel.idProduto = plutoRowResult.cells['id']!.value; 
			currentModel.produtoModel = ProdutoModel.fromPlutoRow(plutoRowResult); 
			produtoModelController.text = currentModel.produtoModel?.nome ?? ''; 
			formWasChanged = true; 
		}
	}


  @override
  void onClose() {
    produtoModelController.dispose();
    quantidadeController.dispose();
    dataSaidaController.dispose();
    horaSaidaController.dispose();
    veioDeOndeController.dispose();
    codigoSeparacaoRecebimentoController.dispose();
    super.onClose();
  }

}