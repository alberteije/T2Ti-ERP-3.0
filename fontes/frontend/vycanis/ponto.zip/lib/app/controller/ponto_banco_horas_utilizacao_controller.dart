import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:pluto_grid/pluto_grid.dart';
import 'package:extended_masked_text/extended_masked_text.dart';
import 'package:ponto/app/page/shared_widget/input/input_imports.dart';

import 'package:ponto/app/page/page_imports.dart';
import 'package:ponto/app/page/shared_widget/message_dialog.dart';
import 'package:ponto/app/page/grid_columns/grid_columns_imports.dart';
import 'package:ponto/app/controller/controller_imports.dart';
import 'package:ponto/app/data/model/model_imports.dart';

class PontoBancoHorasUtilizacaoController extends ControllerBase<PontoBancoHorasUtilizacaoModel, void> {

  PontoBancoHorasUtilizacaoController() : super(repository: null) {
    dbColumns = PontoBancoHorasUtilizacaoModel.dbColumns;
    aliasColumns = PontoBancoHorasUtilizacaoModel.aliasColumns;
    gridColumns = pontoBancoHorasUtilizacaoGridColumns();
    functionName = "ponto_banco_horas_utilizacao";
    screenTitle = "Utilização";
  }

  final _pontoBancoHorasUtilizacaoModel = PontoBancoHorasUtilizacaoModel().obs;
  PontoBancoHorasUtilizacaoModel get pontoBancoHorasUtilizacaoModel => _pontoBancoHorasUtilizacaoModel.value;
  set pontoBancoHorasUtilizacaoModel(value) => _pontoBancoHorasUtilizacaoModel.value = value ?? PontoBancoHorasUtilizacaoModel();

  List<PontoBancoHorasUtilizacaoModel> get pontoBancoHorasUtilizacaoModelList => Get.find<PontoBancoHorasController>().currentModel.pontoBancoHorasUtilizacaoModelList ?? [];

  final _userMadeChanges = false.obs;
  get userMadeChanges => _userMadeChanges.value;
  set userMadeChanges(value) => _userMadeChanges.value = value;

  final _formWasChangedDetail = false.obs;
  bool get formWasChangedDetail => _formWasChangedDetail.value;
  set formWasChangedDetail(value) => _formWasChangedDetail.value = value;

  late PlutoGridStateManager _plutoGridStateManager;
  @override
  PlutoGridStateManager get plutoGridStateManager => _plutoGridStateManager;
  @override
  set plutoGridStateManager(value) => _plutoGridStateManager = value;

  final pontoBancoHorasUtilizacaoScaffoldKey = GlobalKey<ScaffoldState>();
  final pontoBancoHorasUtilizacaoFormKey = GlobalKey<FormState>();

  @override
  PontoBancoHorasUtilizacaoModel createNewModel() => PontoBancoHorasUtilizacaoModel();

  @override
  final standardFieldForFilter = PontoBancoHorasUtilizacaoModel.aliasColumns[PontoBancoHorasUtilizacaoModel.dbColumns.indexOf('data_utilizacao')];

  final dataUtilizacaoController = DatePickerItemController(null);
  final quantidadeUtilizadaController = MaskedTextController(mask: '00:00:00',);
  final observacaoController = TextEditingController();

  final Map<String, dynamic> mobileConfig = {
    'primaryColumns': ['data_utilizacao'],
    'secondaryColumns': ['quantidade_utilizada'],
  };

  List<Map<String, dynamic>> get mobileItems {
    return modelList.map((pontoBancoHorasUtilizacao) => pontoBancoHorasUtilizacao.toJson).toList();
  }

  @override
  List<PlutoRow> plutoRows() => List<PlutoRow>.from(pontoBancoHorasUtilizacaoModelList.map((model) => model.toPlutoRow()));

  @override
  Future<void> getList({Filter? filter}) async {}

  @override
  void prepareForInsert() {
    isNewRecord = true;
    pontoBancoHorasUtilizacaoModel = createNewModel();
    _resetForm();
    Get.to(() => PontoBancoHorasUtilizacaoEditPage());
  }

  void _resetForm() {
    formWasChangedDetail = false;
    dataUtilizacaoController.date = null;
    quantidadeUtilizadaController.text = '';
    observacaoController.text = '';
  }

  @override
  void selectRowForEditing(PlutoRow? row) async {
    if (row == null) {
      showInfoSnackBar(message: 'message_select_one_to_edited'.tr);
      return;
    }

    selectRowForEditingByTempId(row.cells['tempId']?.value);
  }

  @override
  void selectRowForEditingById(int id) {}

  void selectRowForEditingByTempId(String tempId) {
		isNewRecord = false;
    final model = pontoBancoHorasUtilizacaoModelList.firstWhere((m) => m.tempId == tempId);
    pontoBancoHorasUtilizacaoModel = model.clone();
		pontoBancoHorasUtilizacaoModel.tempId = model.tempId;
    updateControllersFromModel();
    Get.to(() => PontoBancoHorasUtilizacaoEditPage());
  }

  void updateControllersFromModel() {
    dataUtilizacaoController.date = pontoBancoHorasUtilizacaoModel.dataUtilizacao;
    quantidadeUtilizadaController.text = pontoBancoHorasUtilizacaoModel.quantidadeUtilizada ?? '';
    observacaoController.text = pontoBancoHorasUtilizacaoModel.observacao ?? '';
    formWasChangedDetail = false;
  }

  @override
  Future<void> save() async {
    if (!pontoBancoHorasUtilizacaoFormKey.currentState!.validate()) {
      showErrorSnackBar(message: 'validator_form_message'.tr);
      return;
    }

    if (formWasChangedDetail) {
      if (isNewRecord) {
        pontoBancoHorasUtilizacaoModelList.insert(0, pontoBancoHorasUtilizacaoModel.clone());
      } else {
        final index = pontoBancoHorasUtilizacaoModelList.indexWhere((m) => m.tempId == pontoBancoHorasUtilizacaoModel.tempId);
        if (index >= 0) {
          pontoBancoHorasUtilizacaoModelList[index] = pontoBancoHorasUtilizacaoModel.clone();
        }
      }

      userMadeChanges = true;
      loadData();
      Get.back(result: true);
    } else {
      Get.back();
    }
  }


  @override
  Future deleteSelected() async {
    final currentRow = plutoGridStateManager.currentRow;
    if (currentRow == null) {
      showInfoSnackBar(message: 'message_select_one_to_delete'.tr);
      return null;
    }
    showDeleteDialog(() async {
      final id = currentRow.cells['id']?.value;
      final tempId = currentRow.cells['tempId']?.value;
      pontoBancoHorasUtilizacaoModelList.removeWhere((model) => (id != 0 && model.id == id) || (id == 0 && model.tempId == tempId));
      plutoGridStateManager.removeCurrentRow();
      userMadeChanges = true;
    });
  }

  @override
  void preventDataLoss() {
    if (formWasChangedDetail) {
      showQuestionDialog('message_data_loss'.tr, () => Get.back());
    } else {
      formWasChangedDetail = false;
      Get.back();
    }
  }

  @override
  void onClose() {
    dataUtilizacaoController.dispose();
    quantidadeUtilizadaController.dispose();
    observacaoController.dispose();
  }

}