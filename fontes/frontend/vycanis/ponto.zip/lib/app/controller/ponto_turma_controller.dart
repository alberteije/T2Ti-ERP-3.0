import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:pluto_grid/pluto_grid.dart';

import 'package:ponto/app/page/page_imports.dart';
import 'package:ponto/app/page/shared_widget/message_dialog.dart';
import 'package:ponto/app/page/grid_columns/grid_columns_imports.dart';
import 'package:ponto/app/controller/controller_imports.dart';
import 'package:ponto/app/data/model/model_imports.dart';

class PontoTurmaController extends ControllerBase<PontoTurmaModel, void> {

  PontoTurmaController() : super(repository: null) {
    dbColumns = PontoTurmaModel.dbColumns;
    aliasColumns = PontoTurmaModel.aliasColumns;
    gridColumns = pontoTurmaGridColumns();
    functionName = "ponto_turma";
    screenTitle = "Turmas";
  }

  final _pontoTurmaModel = PontoTurmaModel().obs;
  PontoTurmaModel get pontoTurmaModel => _pontoTurmaModel.value;
  set pontoTurmaModel(value) => _pontoTurmaModel.value = value ?? PontoTurmaModel();

  List<PontoTurmaModel> get pontoTurmaModelList => Get.find<PontoEscalaController>().currentModel.pontoTurmaModelList ?? [];

  final _userMadeChanges = false.obs;
  get userMadeChanges => _userMadeChanges.value;
  set userMadeChanges(value) => _userMadeChanges.value = value;

  final _formWasChangedDetail = false.obs;
  bool get formWasChangedDetail => _formWasChangedDetail.value;
  set formWasChangedDetail(value) => _formWasChangedDetail.value = value;

  late PlutoGridStateManager _plutoGridStateManager;
  @override
  PlutoGridStateManager get plutoGridStateManager => _plutoGridStateManager;
  @override
  set plutoGridStateManager(value) => _plutoGridStateManager = value;

  final pontoTurmaScaffoldKey = GlobalKey<ScaffoldState>();
  final pontoTurmaFormKey = GlobalKey<FormState>();

  @override
  PontoTurmaModel createNewModel() => PontoTurmaModel();

  @override
  final standardFieldForFilter = PontoTurmaModel.aliasColumns[PontoTurmaModel.dbColumns.indexOf('codigo')];

  final codigoController = TextEditingController();
  final nomeController = TextEditingController();

  final Map<String, dynamic> mobileConfig = {
    'primaryColumns': ['codigo'],
    'secondaryColumns': ['nome'],
  };

  List<Map<String, dynamic>> get mobileItems {
    return modelList.map((pontoTurma) => pontoTurma.toJson).toList();
  }

  @override
  List<PlutoRow> plutoRows() => List<PlutoRow>.from(pontoTurmaModelList.map((model) => model.toPlutoRow()));

  @override
  Future<void> getList({Filter? filter}) async {}

  @override
  void prepareForInsert() {
    isNewRecord = true;
    pontoTurmaModel = createNewModel();
    _resetForm();
    Get.to(() => PontoTurmaEditPage());
  }

  void _resetForm() {
    formWasChangedDetail = false;
    codigoController.text = '';
    nomeController.text = '';
  }

  @override
  void selectRowForEditing(PlutoRow? row) async {
    if (row == null) {
      showInfoSnackBar(message: 'message_select_one_to_edited'.tr);
      return;
    }

    selectRowForEditingByTempId(row.cells['tempId']?.value);
  }

  @override
  void selectRowForEditingById(int id) {}

  void selectRowForEditingByTempId(String tempId) {
		isNewRecord = false;
    final model = pontoTurmaModelList.firstWhere((m) => m.tempId == tempId);
    pontoTurmaModel = model.clone();
		pontoTurmaModel.tempId = model.tempId;
    updateControllersFromModel();
    Get.to(() => PontoTurmaEditPage());
  }

  void updateControllersFromModel() {
    codigoController.text = pontoTurmaModel.codigo ?? '';
    nomeController.text = pontoTurmaModel.nome ?? '';
    formWasChangedDetail = false;
  }

  @override
  Future<void> save() async {
    if (!pontoTurmaFormKey.currentState!.validate()) {
      showErrorSnackBar(message: 'validator_form_message'.tr);
      return;
    }

    if (formWasChangedDetail) {
      if (isNewRecord) {
        pontoTurmaModelList.insert(0, pontoTurmaModel.clone());
      } else {
        final index = pontoTurmaModelList.indexWhere((m) => m.tempId == pontoTurmaModel.tempId);
        if (index >= 0) {
          pontoTurmaModelList[index] = pontoTurmaModel.clone();
        }
      }

      userMadeChanges = true;
      loadData();
      Get.back(result: true);
    } else {
      Get.back();
    }
  }


  @override
  Future deleteSelected() async {
    final currentRow = plutoGridStateManager.currentRow;
    if (currentRow == null) {
      showInfoSnackBar(message: 'message_select_one_to_delete'.tr);
      return null;
    }
    showDeleteDialog(() async {
      final id = currentRow.cells['id']?.value;
      final tempId = currentRow.cells['tempId']?.value;
      pontoTurmaModelList.removeWhere((model) => (id != 0 && model.id == id) || (id == 0 && model.tempId == tempId));
      plutoGridStateManager.removeCurrentRow();
      userMadeChanges = true;
    });
  }

  @override
  void preventDataLoss() {
    if (formWasChangedDetail) {
      showQuestionDialog('message_data_loss'.tr, () => Get.back());
    } else {
      formWasChangedDetail = false;
      Get.back();
    }
  }

  @override
  void onClose() {
    codigoController.dispose();
    nomeController.dispose();
  }

}