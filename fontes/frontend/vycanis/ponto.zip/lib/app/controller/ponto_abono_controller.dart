import 'package:flutter/material.dart';
import 'dart:math';
import 'package:get/get.dart';
import 'package:extended_masked_text/extended_masked_text.dart';
import 'package:ponto/app/page/shared_widget/input/input_imports.dart';

import 'package:ponto/app/infra/infra_imports.dart';
import 'package:ponto/app/page/page_imports.dart';
import 'package:ponto/app/page/shared_widget/message_dialog.dart';
import 'package:ponto/app/page/grid_columns/grid_columns_imports.dart';
import 'package:ponto/app/routes/app_routes.dart';
import 'package:ponto/app/controller/controller_imports.dart';
import 'package:ponto/app/data/model/model_imports.dart';
import 'package:ponto/app/data/repository/ponto_abono_repository.dart';

class PontoAbonoController extends ControllerBase<PontoAbonoModel, PontoAbonoRepository> 
with GetSingleTickerProviderStateMixin {

  PontoAbonoController({required super.repository}) {
    dbColumns = PontoAbonoModel.dbColumns;
    aliasColumns = PontoAbonoModel.aliasColumns;
    gridColumns = pontoAbonoGridColumns();
    functionName = "ponto_abono";
    screenTitle = "Abonos";
  }

  final pontoAbonoScaffoldKey = GlobalKey<ScaffoldState>();
  final pontoAbonoTabPageScaffoldKey = GlobalKey<ScaffoldState>();
  final pontoAbonoFormKey = GlobalKey<FormState>();
  late TabController tabController;
  String? mandatoryMessage;  

  @override
  PontoAbonoModel createNewModel() => PontoAbonoModel();

  @override
  final standardFieldForFilter = PontoAbonoModel.aliasColumns[PontoAbonoModel.dbColumns.indexOf('quantidade')];

  final viewPessoaColaboradorModelController = TextEditingController();
  final quantidadeController = MoneyMaskedTextController(precision: 0, decimalSeparator: '', thousandSeparator: '');
  final utilizadoController = MoneyMaskedTextController(precision: 0, decimalSeparator: '', thousandSeparator: '');
  final saldoController = MoneyMaskedTextController(precision: 0, decimalSeparator: '', thousandSeparator: '');
  final dataCadastroController = DatePickerItemController(null);
  final inicioUtilizacaoController = DatePickerItemController(null);
  final dataValidadeController = DatePickerItemController(null);
  final observacaoController = TextEditingController();

  final Map<String, dynamic> mobileConfig = {
    'primaryColumns': ['quantidade'],
    'secondaryColumns': ['utilizado'],
  };

  List<Map<String, dynamic>> get mobileItems {
    return modelList.map((pontoAbono) => pontoAbono.toJson).toList();
  }

  @override
  void prepareForInsert() {
    isNewRecord = true;
    currentModel = createNewModel();
    _resetForm();
    tabController.animateTo(0);
    updateControllersFromModel();
    Get.toNamed(Routes.pontoAbonoTabPage);
  }

  void _resetForm() {
    formWasChanged = false;
    viewPessoaColaboradorModelController.text = '';
    quantidadeController.updateValue(0);
    utilizadoController.updateValue(0);
    saldoController.updateValue(0);
    dataCadastroController.date = null;
    inicioUtilizacaoController.date = null;
    dataValidadeController.date = null;
    observacaoController.text = '';
  }

  @override
  void selectRowForEditingById(int id) {
    final model = modelList.firstWhere((m) => m.id == id);
    currentModel = model.clone();
    updateControllersFromModel();
    tabController.animateTo(0);
    Get.toNamed(Routes.pontoAbonoTabPage);
  }

  _configureChildrenControllers() {
    //Utilização
		Get.put<PontoAbonoUtilizacaoController>(PontoAbonoUtilizacaoController()); 

  }
	
	_releaseChildrenControllers() {
    //Utilização
		Get.delete<PontoAbonoUtilizacaoController>(); 

	}
  
  void updateControllersFromModel() {
    viewPessoaColaboradorModelController.text = currentModel.viewPessoaColaboradorModel?.nome?.toString() ?? '';
    quantidadeController.updateValue((currentModel.quantidade ?? 0).toDouble());
    utilizadoController.updateValue((currentModel.utilizado ?? 0).toDouble());
    saldoController.updateValue((currentModel.saldo ?? 0).toDouble());
    dataCadastroController.date = currentModel.dataCadastro;
    inicioUtilizacaoController.date = currentModel.inicioUtilizacao;
    dataValidadeController.date = currentModel.dataValidade;
    observacaoController.text = currentModel.observacao ?? '';

    formWasChanged = false;
    _updateChildrenControllersFromModel();
  }

  void _updateChildrenControllersFromModel() {
    //Utilização
		final pontoAbonoUtilizacaoController = Get.find<PontoAbonoUtilizacaoController>(); 
		pontoAbonoUtilizacaoController.userMadeChanges = false; 

  }

  @override
  Future<void> save() async {
    if (!validateCurrentForm()) return;
    if (validateForms()) {
      if (userMadeChanges()) {
        final existingIndex = modelList.indexWhere((m) => m.id == currentModel.id);

        if (existingIndex >= 0) {
          modelList[existingIndex] = currentModel.clone();
        }

        final result = await repository.save(pontoAbonoModel: currentModel);
        if (result == null) return;

        if (existingIndex >= 0) {
          modelList[existingIndex] = result;
        } else {
          modelList.insert(0, result);
        }

        if (!GetPlatform.isMobile) {
          updateGridRow(result);
        }

        Get.back(result: true);
      } else {
        Get.back();
      }
    } 
  }

  Future callViewPessoaColaboradorLookup() async { 
		final lookupController = Get.find<LookupController>(); 
		lookupController.refreshItems(standardValue: '%'); 
		lookupController.title = '${'lookup_page_title'.tr} [Colaborador]'; 
		lookupController.route = '/view-pessoa-colaborador/'; 
		lookupController.gridColumns = viewPessoaColaboradorGridColumns(isForLookup: true); 
		lookupController.aliasColumns = ViewPessoaColaboradorModel.aliasColumns; 
		lookupController.dbColumns = ViewPessoaColaboradorModel.dbColumns; 
		lookupController.standardColumn = ViewPessoaColaboradorModel.aliasColumns[ViewPessoaColaboradorModel.dbColumns.indexOf('nome')]; 

		final plutoRowResult = await Get.toNamed(Routes.lookupPage); 
		if (plutoRowResult != null) { 
			currentModel.idColaborador = plutoRowResult.cells['id']!.value; 
			currentModel.viewPessoaColaboradorModel = ViewPessoaColaboradorModel.fromPlutoRow(plutoRowResult); 
			viewPessoaColaboradorModelController.text = currentModel.viewPessoaColaboradorModel?.nome ?? ''; 
			formWasChanged = true; 
		}
	}


  List<Tab> tabItems = [
    Tab( 
			icon: Icon(iconDataList[Random().nextInt(10)]), 
			text: 'Abonos', 
		),
    Tab( 
			icon: Icon(iconDataList[Random().nextInt(10)]), 
			text: 'Utilização', 
		),
  ];

  List<Widget> tabPages() {
    return [
      PontoAbonoEditPage(),
      const PontoAbonoUtilizacaoListPage(),
    ];
  }

  @override
  void preventDataLoss() {
    if (userMadeChanges()) {
      showQuestionDialog('message_data_loss'.tr, () { 
        Get.back(); 
      });
    } else {
      Get.back();
    }
  }  

  bool userMadeChanges() {
    return
    formWasChanged 
    || 
		Get.find<PontoAbonoUtilizacaoController>().userMadeChanges
    ;
  }

  void tabChange(int index) {
    validateCurrentForm();
  }

  bool validateCurrentForm() {
    mandatoryMessage = ValidateFormField.validateMandatory(currentModel.viewPessoaColaboradorModel?.nome); 
		if (mandatoryMessage != null) { 
			tabController.animateTo(0); 
			showErrorSnackBar(message: '$mandatoryMessage [Colaborador]'); 
			return false; 
		}
    return true;
  }

  bool validateForms() {
    return true;
  }

  @override
  void onInit() {
    super.onInit();
    tabController = TabController(vsync: this, length: tabItems.length);
    _configureChildrenControllers();
  }
	
  @override
  void onClose() {
    tabController.dispose();
    viewPessoaColaboradorModelController.dispose();
    quantidadeController.dispose();
    utilizadoController.dispose();
    saldoController.dispose();
    dataCadastroController.dispose();
    inicioUtilizacaoController.dispose();
    dataValidadeController.dispose();
    observacaoController.dispose();
    _releaseChildrenControllers();
    super.onClose();
  }	
}