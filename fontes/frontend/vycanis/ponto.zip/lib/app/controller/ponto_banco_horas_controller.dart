import 'package:flutter/material.dart';
import 'dart:math';
import 'package:get/get.dart';
import 'package:ponto/app/page/shared_widget/input/input_imports.dart';

import 'package:ponto/app/infra/infra_imports.dart';
import 'package:ponto/app/page/page_imports.dart';
import 'package:ponto/app/page/shared_widget/message_dialog.dart';
import 'package:ponto/app/page/grid_columns/grid_columns_imports.dart';
import 'package:ponto/app/routes/app_routes.dart';
import 'package:ponto/app/controller/controller_imports.dart';
import 'package:ponto/app/data/model/model_imports.dart';
import 'package:ponto/app/data/repository/ponto_banco_horas_repository.dart';

class PontoBancoHorasController extends ControllerBase<PontoBancoHorasModel, PontoBancoHorasRepository> 
with GetSingleTickerProviderStateMixin {

  PontoBancoHorasController({required super.repository}) {
    dbColumns = PontoBancoHorasModel.dbColumns;
    aliasColumns = PontoBancoHorasModel.aliasColumns;
    gridColumns = pontoBancoHorasGridColumns();
    functionName = "ponto_banco_horas";
    screenTitle = "Banco de Horas";
  }

  final pontoBancoHorasScaffoldKey = GlobalKey<ScaffoldState>();
  final pontoBancoHorasTabPageScaffoldKey = GlobalKey<ScaffoldState>();
  final pontoBancoHorasFormKey = GlobalKey<FormState>();
  late TabController tabController;
  String? mandatoryMessage;  

  @override
  PontoBancoHorasModel createNewModel() => PontoBancoHorasModel();

  @override
  final standardFieldForFilter = PontoBancoHorasModel.aliasColumns[PontoBancoHorasModel.dbColumns.indexOf('data_trabalho')];

  final viewPessoaColaboradorModelController = TextEditingController();
  final dataTrabalhoController = DatePickerItemController(null);
  final quantidadeController = TextEditingController();
  final situacaoController = CustomDropdownButtonController('Não Utilizado');

  final Map<String, dynamic> mobileConfig = {
    'primaryColumns': ['data_trabalho'],
    'secondaryColumns': ['quantidade'],
  };

  List<Map<String, dynamic>> get mobileItems {
    return modelList.map((pontoBancoHoras) => pontoBancoHoras.toJson).toList();
  }

  @override
  void prepareForInsert() {
    isNewRecord = true;
    currentModel = createNewModel();
    _resetForm();
    tabController.animateTo(0);
    updateControllersFromModel();
    Get.toNamed(Routes.pontoBancoHorasTabPage);
  }

  void _resetForm() {
    formWasChanged = false;
    viewPessoaColaboradorModelController.text = '';
    dataTrabalhoController.date = null;
    quantidadeController.text = '';
    situacaoController.selected = 'Não Utilizado';
  }

  @override
  void selectRowForEditingById(int id) {
    final model = modelList.firstWhere((m) => m.id == id);
    currentModel = model.clone();
    updateControllersFromModel();
    tabController.animateTo(0);
    Get.toNamed(Routes.pontoBancoHorasTabPage);
  }

  _configureChildrenControllers() {
    //Utilização
		Get.put<PontoBancoHorasUtilizacaoController>(PontoBancoHorasUtilizacaoController()); 

  }
	
	_releaseChildrenControllers() {
    //Utilização
		Get.delete<PontoBancoHorasUtilizacaoController>(); 

	}
  
  void updateControllersFromModel() {
    viewPessoaColaboradorModelController.text = currentModel.viewPessoaColaboradorModel?.nome?.toString() ?? '';
    dataTrabalhoController.date = currentModel.dataTrabalho;
    quantidadeController.text = currentModel.quantidade ?? '';
    situacaoController.selected = currentModel.situacao ?? 'Não Utilizado';

    formWasChanged = false;
    _updateChildrenControllersFromModel();
  }

  void _updateChildrenControllersFromModel() {
    //Utilização
		final pontoBancoHorasUtilizacaoController = Get.find<PontoBancoHorasUtilizacaoController>(); 
		pontoBancoHorasUtilizacaoController.userMadeChanges = false; 

  }

  @override
  Future<void> save() async {
    if (!validateCurrentForm()) return;
    if (validateForms()) {
      if (userMadeChanges()) {
        final existingIndex = modelList.indexWhere((m) => m.id == currentModel.id);

        if (existingIndex >= 0) {
          modelList[existingIndex] = currentModel.clone();
        }

        final result = await repository.save(pontoBancoHorasModel: currentModel);
        if (result == null) return;

        if (existingIndex >= 0) {
          modelList[existingIndex] = result;
        } else {
          modelList.insert(0, result);
        }

        if (!GetPlatform.isMobile) {
          updateGridRow(result);
        }

        Get.back(result: true);
      } else {
        Get.back();
      }
    } 
  }

  Future callViewPessoaColaboradorLookup() async { 
		final lookupController = Get.find<LookupController>(); 
		lookupController.refreshItems(standardValue: '%'); 
		lookupController.title = '${'lookup_page_title'.tr} [Colaborador]'; 
		lookupController.route = '/view-pessoa-colaborador/'; 
		lookupController.gridColumns = viewPessoaColaboradorGridColumns(isForLookup: true); 
		lookupController.aliasColumns = ViewPessoaColaboradorModel.aliasColumns; 
		lookupController.dbColumns = ViewPessoaColaboradorModel.dbColumns; 
		lookupController.standardColumn = ViewPessoaColaboradorModel.aliasColumns[ViewPessoaColaboradorModel.dbColumns.indexOf('nome')]; 

		final plutoRowResult = await Get.toNamed(Routes.lookupPage); 
		if (plutoRowResult != null) { 
			currentModel.idColaborador = plutoRowResult.cells['id']!.value; 
			currentModel.viewPessoaColaboradorModel = ViewPessoaColaboradorModel.fromPlutoRow(plutoRowResult); 
			viewPessoaColaboradorModelController.text = currentModel.viewPessoaColaboradorModel?.nome ?? ''; 
			formWasChanged = true; 
		}
	}


  List<Tab> tabItems = [
    Tab( 
			icon: Icon(iconDataList[Random().nextInt(10)]), 
			text: 'Banco de Horas', 
		),
    Tab( 
			icon: Icon(iconDataList[Random().nextInt(10)]), 
			text: 'Utilização', 
		),
  ];

  List<Widget> tabPages() {
    return [
      PontoBancoHorasEditPage(),
      const PontoBancoHorasUtilizacaoListPage(),
    ];
  }

  @override
  void preventDataLoss() {
    if (userMadeChanges()) {
      showQuestionDialog('message_data_loss'.tr, () { 
        Get.back(); 
      });
    } else {
      Get.back();
    }
  }  

  bool userMadeChanges() {
    return
    formWasChanged 
    || 
		Get.find<PontoBancoHorasUtilizacaoController>().userMadeChanges
    ;
  }

  void tabChange(int index) {
    validateCurrentForm();
  }

  bool validateCurrentForm() {
    mandatoryMessage = ValidateFormField.validateMandatory(currentModel.viewPessoaColaboradorModel?.nome); 
		if (mandatoryMessage != null) { 
			tabController.animateTo(0); 
			showErrorSnackBar(message: '$mandatoryMessage [Colaborador]'); 
			return false; 
		}
    return true;
  }

  bool validateForms() {
    return true;
  }

  @override
  void onInit() {
    super.onInit();
    tabController = TabController(vsync: this, length: tabItems.length);
    _configureChildrenControllers();
  }
	
  @override
  void onClose() {
    tabController.dispose();
    viewPessoaColaboradorModelController.dispose();
    dataTrabalhoController.dispose();
    quantidadeController.dispose();
    situacaoController.dispose();
    _releaseChildrenControllers();
    super.onClose();
  }	
}