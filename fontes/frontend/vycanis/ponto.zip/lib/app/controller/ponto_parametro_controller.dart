import 'package:get/get.dart';
import 'package:extended_masked_text/extended_masked_text.dart';
import 'package:ponto/app/page/shared_widget/input/input_imports.dart';

import 'package:ponto/app/page/shared_widget/message_dialog.dart';
import 'package:ponto/app/page/grid_columns/grid_columns_imports.dart';
import 'package:ponto/app/routes/app_routes.dart';
import 'package:ponto/app/controller/controller_imports.dart';
import 'package:ponto/app/data/model/model_imports.dart';
import 'package:ponto/app/data/repository/ponto_parametro_repository.dart';

class PontoParametroController extends ControllerBase<PontoParametroModel, PontoParametroRepository> {

  PontoParametroController({required super.repository}) {
    dbColumns = PontoParametroModel.dbColumns;
    aliasColumns = PontoParametroModel.aliasColumns;
    gridColumns = pontoParametroGridColumns();
    functionName = "ponto_parametro";
    screenTitle = "Parâmetros";
  }

  @override
  PontoParametroModel createNewModel() => PontoParametroModel();

  @override
  final standardFieldForFilter = PontoParametroModel.aliasColumns[PontoParametroModel.dbColumns.indexOf('mes_ano')];

  final mesAnoController = MaskedTextController(mask: '00/0000',);
  final diaInicialApuracaoController = MoneyMaskedTextController(precision: 0, decimalSeparator: '', thousandSeparator: '');
  final horaNoturnaInicioController = MaskedTextController(mask: '00:00:00',);
  final horaNoturnaFimController = MaskedTextController(mask: '00:00:00',);
  final periodoMinimoInterjornadaController = MaskedTextController(mask: '00:00:00',);
  final percentualHeDiurnaController = MoneyMaskedTextController();
  final percentualHeNoturnaController = MoneyMaskedTextController();
  final duracaoHoraNoturnaController = MaskedTextController(mask: '00:00:00',);
  final tratamentoHoraMaisController = CustomDropdownButtonController('Extra');
  final tratamentoHoraMenosController = CustomDropdownButtonController('Falta');

  final Map<String, dynamic> mobileConfig = {
    'primaryColumns': ['mes_ano'],
    'secondaryColumns': ['dia_inicial_apuracao'],
  };

  List<Map<String, dynamic>> get mobileItems {
    return modelList.map((pontoParametro) => pontoParametro.toJson).toList();
  }

  @override
  void prepareForInsert() {
    isNewRecord = true;
    currentModel = createNewModel();
    _resetForm();
    Get.toNamed(Routes.pontoParametroEditPage);
  }

  void _resetForm() {
    formWasChanged = false;
    mesAnoController.text = '';
    diaInicialApuracaoController.updateValue(0);
    horaNoturnaInicioController.text = '';
    horaNoturnaFimController.text = '';
    periodoMinimoInterjornadaController.text = '';
    percentualHeDiurnaController.updateValue(0);
    percentualHeNoturnaController.updateValue(0);
    duracaoHoraNoturnaController.text = '';
    tratamentoHoraMaisController.selected = 'Extra';
    tratamentoHoraMenosController.selected = 'Falta';
  }

  @override
  void selectRowForEditingById(int id) {
    final model = modelList.firstWhere((m) => m.id == id);
    currentModel = model.clone();
    updateControllersFromModel();
    Get.toNamed(Routes.pontoParametroEditPage);
  }

  void updateControllersFromModel() {
    mesAnoController.text = currentModel.mesAno ?? '';
    diaInicialApuracaoController.updateValue((currentModel.diaInicialApuracao ?? 0).toDouble());
    horaNoturnaInicioController.text = currentModel.horaNoturnaInicio ?? '';
    horaNoturnaFimController.text = currentModel.horaNoturnaFim ?? '';
    periodoMinimoInterjornadaController.text = currentModel.periodoMinimoInterjornada ?? '';
    percentualHeDiurnaController.updateValue(currentModel.percentualHeDiurna ?? 0);
    percentualHeNoturnaController.updateValue(currentModel.percentualHeNoturna ?? 0);
    duracaoHoraNoturnaController.text = currentModel.duracaoHoraNoturna ?? '';
    tratamentoHoraMaisController.selected = currentModel.tratamentoHoraMais ?? 'Extra';
    tratamentoHoraMenosController.selected = currentModel.tratamentoHoraMenos ?? 'Falta';
    formWasChanged = false;
  }

  @override
  Future<void> save() async {
    if (!formKey.currentState!.validate()) {
      showErrorSnackBar(message: 'validator_form_message'.tr);
      return;
    }

    final existingIndex = modelList.indexWhere((m) => m.id == currentModel.id);

    if (existingIndex >= 0) {
      modelList[existingIndex] = currentModel.clone();
    }

    final result = await repository.save(pontoParametroModel: currentModel);
    if (result == null) return;

    if (existingIndex >= 0) {
      modelList[existingIndex] = result;
    } else {
      modelList.insert(0, result);
    }

    if (!GetPlatform.isMobile) {
      updateGridRow(result);
    }

    Get.back(result: true);
  }


  @override
  void onClose() {
    mesAnoController.dispose();
    diaInicialApuracaoController.dispose();
    horaNoturnaInicioController.dispose();
    horaNoturnaFimController.dispose();
    periodoMinimoInterjornadaController.dispose();
    percentualHeDiurnaController.dispose();
    percentualHeNoturnaController.dispose();
    duracaoHoraNoturnaController.dispose();
    tratamentoHoraMaisController.dispose();
    tratamentoHoraMenosController.dispose();
    super.onClose();
  }

}