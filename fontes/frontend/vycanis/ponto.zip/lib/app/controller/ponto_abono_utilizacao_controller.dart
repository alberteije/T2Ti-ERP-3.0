import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:pluto_grid/pluto_grid.dart';
import 'package:ponto/app/page/shared_widget/input/input_imports.dart';

import 'package:ponto/app/page/page_imports.dart';
import 'package:ponto/app/page/shared_widget/message_dialog.dart';
import 'package:ponto/app/page/grid_columns/grid_columns_imports.dart';
import 'package:ponto/app/controller/controller_imports.dart';
import 'package:ponto/app/data/model/model_imports.dart';

class PontoAbonoUtilizacaoController extends ControllerBase<PontoAbonoUtilizacaoModel, void> {

  PontoAbonoUtilizacaoController() : super(repository: null) {
    dbColumns = PontoAbonoUtilizacaoModel.dbColumns;
    aliasColumns = PontoAbonoUtilizacaoModel.aliasColumns;
    gridColumns = pontoAbonoUtilizacaoGridColumns();
    functionName = "ponto_abono_utilizacao";
    screenTitle = "Utilização";
  }

  final _pontoAbonoUtilizacaoModel = PontoAbonoUtilizacaoModel().obs;
  PontoAbonoUtilizacaoModel get pontoAbonoUtilizacaoModel => _pontoAbonoUtilizacaoModel.value;
  set pontoAbonoUtilizacaoModel(value) => _pontoAbonoUtilizacaoModel.value = value ?? PontoAbonoUtilizacaoModel();

  List<PontoAbonoUtilizacaoModel> get pontoAbonoUtilizacaoModelList => Get.find<PontoAbonoController>().currentModel.pontoAbonoUtilizacaoModelList ?? [];

  final _userMadeChanges = false.obs;
  get userMadeChanges => _userMadeChanges.value;
  set userMadeChanges(value) => _userMadeChanges.value = value;

  final _formWasChangedDetail = false.obs;
  bool get formWasChangedDetail => _formWasChangedDetail.value;
  set formWasChangedDetail(value) => _formWasChangedDetail.value = value;

  late PlutoGridStateManager _plutoGridStateManager;
  @override
  PlutoGridStateManager get plutoGridStateManager => _plutoGridStateManager;
  @override
  set plutoGridStateManager(value) => _plutoGridStateManager = value;

  final pontoAbonoUtilizacaoScaffoldKey = GlobalKey<ScaffoldState>();
  final pontoAbonoUtilizacaoFormKey = GlobalKey<FormState>();

  @override
  PontoAbonoUtilizacaoModel createNewModel() => PontoAbonoUtilizacaoModel();

  @override
  final standardFieldForFilter = PontoAbonoUtilizacaoModel.aliasColumns[PontoAbonoUtilizacaoModel.dbColumns.indexOf('data_utilizacao')];

  final dataUtilizacaoController = DatePickerItemController(null);
  final observacaoController = TextEditingController();

  final Map<String, dynamic> mobileConfig = {
    'primaryColumns': ['data_utilizacao'],
    'secondaryColumns': ['observacao'],
  };

  List<Map<String, dynamic>> get mobileItems {
    return modelList.map((pontoAbonoUtilizacao) => pontoAbonoUtilizacao.toJson).toList();
  }

  @override
  List<PlutoRow> plutoRows() => List<PlutoRow>.from(pontoAbonoUtilizacaoModelList.map((model) => model.toPlutoRow()));

  @override
  Future<void> getList({Filter? filter}) async {}

  @override
  void prepareForInsert() {
    isNewRecord = true;
    pontoAbonoUtilizacaoModel = createNewModel();
    _resetForm();
    Get.to(() => PontoAbonoUtilizacaoEditPage());
  }

  void _resetForm() {
    formWasChangedDetail = false;
    dataUtilizacaoController.date = null;
    observacaoController.text = '';
  }

  @override
  void selectRowForEditing(PlutoRow? row) async {
    if (row == null) {
      showInfoSnackBar(message: 'message_select_one_to_edited'.tr);
      return;
    }

    selectRowForEditingByTempId(row.cells['tempId']?.value);
  }

  @override
  void selectRowForEditingById(int id) {}

  void selectRowForEditingByTempId(String tempId) {
		isNewRecord = false;
    final model = pontoAbonoUtilizacaoModelList.firstWhere((m) => m.tempId == tempId);
    pontoAbonoUtilizacaoModel = model.clone();
		pontoAbonoUtilizacaoModel.tempId = model.tempId;
    updateControllersFromModel();
    Get.to(() => PontoAbonoUtilizacaoEditPage());
  }

  void updateControllersFromModel() {
    dataUtilizacaoController.date = pontoAbonoUtilizacaoModel.dataUtilizacao;
    observacaoController.text = pontoAbonoUtilizacaoModel.observacao ?? '';
    formWasChangedDetail = false;
  }

  @override
  Future<void> save() async {
    if (!pontoAbonoUtilizacaoFormKey.currentState!.validate()) {
      showErrorSnackBar(message: 'validator_form_message'.tr);
      return;
    }

    if (formWasChangedDetail) {
      if (isNewRecord) {
        pontoAbonoUtilizacaoModelList.insert(0, pontoAbonoUtilizacaoModel.clone());
      } else {
        final index = pontoAbonoUtilizacaoModelList.indexWhere((m) => m.tempId == pontoAbonoUtilizacaoModel.tempId);
        if (index >= 0) {
          pontoAbonoUtilizacaoModelList[index] = pontoAbonoUtilizacaoModel.clone();
        }
      }

      userMadeChanges = true;
      loadData();
      Get.back(result: true);
    } else {
      Get.back();
    }
  }


  @override
  Future deleteSelected() async {
    final currentRow = plutoGridStateManager.currentRow;
    if (currentRow == null) {
      showInfoSnackBar(message: 'message_select_one_to_delete'.tr);
      return null;
    }
    showDeleteDialog(() async {
      final id = currentRow.cells['id']?.value;
      final tempId = currentRow.cells['tempId']?.value;
      pontoAbonoUtilizacaoModelList.removeWhere((model) => (id != 0 && model.id == id) || (id == 0 && model.tempId == tempId));
      plutoGridStateManager.removeCurrentRow();
      userMadeChanges = true;
    });
  }

  @override
  void preventDataLoss() {
    if (formWasChangedDetail) {
      showQuestionDialog('message_data_loss'.tr, () => Get.back());
    } else {
      formWasChangedDetail = false;
      Get.back();
    }
  }

  @override
  void onClose() {
    dataUtilizacaoController.dispose();
    observacaoController.dispose();
  }

}