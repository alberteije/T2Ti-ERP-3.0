import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:extended_masked_text/extended_masked_text.dart';
import 'package:ponto/app/page/shared_widget/input/input_imports.dart';

import 'package:ponto/app/page/shared_widget/message_dialog.dart';
import 'package:ponto/app/page/grid_columns/grid_columns_imports.dart';
import 'package:ponto/app/routes/app_routes.dart';
import 'package:ponto/app/controller/controller_imports.dart';
import 'package:ponto/app/data/model/model_imports.dart';
import 'package:ponto/app/data/repository/ponto_horario_repository.dart';

class PontoHorarioController extends ControllerBase<PontoHorarioModel, PontoHorarioRepository> {

  PontoHorarioController({required super.repository}) {
    dbColumns = PontoHorarioModel.dbColumns;
    aliasColumns = PontoHorarioModel.aliasColumns;
    gridColumns = pontoHorarioGridColumns();
    functionName = "ponto_horario";
    screenTitle = "Horários";
  }

  @override
  PontoHorarioModel createNewModel() => PontoHorarioModel();

  @override
  final standardFieldForFilter = PontoHorarioModel.aliasColumns[PontoHorarioModel.dbColumns.indexOf('tipo')];

  final tipoController = CustomDropdownButtonController('Fixo');
  final codigoController = TextEditingController();
  final nomeController = TextEditingController();
  final tipoTrabalhoController = CustomDropdownButtonController('Normal');
  final cargaHorariaController = MaskedTextController(mask: '00:00:00',);
  final entrada01Controller = MaskedTextController(mask: '00:00:00',);
  final saida01Controller = MaskedTextController(mask: '00:00:00',);
  final entrada02Controller = MaskedTextController(mask: '00:00:00',);
  final saida02Controller = MaskedTextController(mask: '00:00:00',);
  final entrada03Controller = MaskedTextController(mask: '00:00:00',);
  final saida03Controller = MaskedTextController(mask: '00:00:00',);
  final entrada04Controller = MaskedTextController(mask: '00:00:00',);
  final saida04Controller = MaskedTextController(mask: '00:00:00',);
  final entrada05Controller = MaskedTextController(mask: '00:00:00',);
  final saida05Controller = MaskedTextController(mask: '00:00:00',);
  final horaInicioJornadaController = MaskedTextController(mask: '00:00:00',);
  final horaFimJornadaController = MaskedTextController(mask: '00:00:00',);

  final Map<String, dynamic> mobileConfig = {
    'primaryColumns': ['tipo'],
    'secondaryColumns': ['codigo'],
  };

  List<Map<String, dynamic>> get mobileItems {
    return modelList.map((pontoHorario) => pontoHorario.toJson).toList();
  }

  @override
  void prepareForInsert() {
    isNewRecord = true;
    currentModel = createNewModel();
    _resetForm();
    Get.toNamed(Routes.pontoHorarioEditPage);
  }

  void _resetForm() {
    formWasChanged = false;
    tipoController.selected = 'Fixo';
    codigoController.text = '';
    nomeController.text = '';
    tipoTrabalhoController.selected = 'Normal';
    cargaHorariaController.text = '';
    entrada01Controller.text = '';
    saida01Controller.text = '';
    entrada02Controller.text = '';
    saida02Controller.text = '';
    entrada03Controller.text = '';
    saida03Controller.text = '';
    entrada04Controller.text = '';
    saida04Controller.text = '';
    entrada05Controller.text = '';
    saida05Controller.text = '';
    horaInicioJornadaController.text = '';
    horaFimJornadaController.text = '';
  }

  @override
  void selectRowForEditingById(int id) {
    final model = modelList.firstWhere((m) => m.id == id);
    currentModel = model.clone();
    updateControllersFromModel();
    Get.toNamed(Routes.pontoHorarioEditPage);
  }

  void updateControllersFromModel() {
    tipoController.selected = currentModel.tipo ?? 'Fixo';
    codigoController.text = currentModel.codigo ?? '';
    nomeController.text = currentModel.nome ?? '';
    tipoTrabalhoController.selected = currentModel.tipoTrabalho ?? 'Normal';
    cargaHorariaController.text = currentModel.cargaHoraria ?? '';
    entrada01Controller.text = currentModel.entrada01 ?? '';
    saida01Controller.text = currentModel.saida01 ?? '';
    entrada02Controller.text = currentModel.entrada02 ?? '';
    saida02Controller.text = currentModel.saida02 ?? '';
    entrada03Controller.text = currentModel.entrada03 ?? '';
    saida03Controller.text = currentModel.saida03 ?? '';
    entrada04Controller.text = currentModel.entrada04 ?? '';
    saida04Controller.text = currentModel.saida04 ?? '';
    entrada05Controller.text = currentModel.entrada05 ?? '';
    saida05Controller.text = currentModel.saida05 ?? '';
    horaInicioJornadaController.text = currentModel.horaInicioJornada ?? '';
    horaFimJornadaController.text = currentModel.horaFimJornada ?? '';
    formWasChanged = false;
  }

  @override
  Future<void> save() async {
    if (!formKey.currentState!.validate()) {
      showErrorSnackBar(message: 'validator_form_message'.tr);
      return;
    }

    final existingIndex = modelList.indexWhere((m) => m.id == currentModel.id);

    if (existingIndex >= 0) {
      modelList[existingIndex] = currentModel.clone();
    }

    final result = await repository.save(pontoHorarioModel: currentModel);
    if (result == null) return;

    if (existingIndex >= 0) {
      modelList[existingIndex] = result;
    } else {
      modelList.insert(0, result);
    }

    if (!GetPlatform.isMobile) {
      updateGridRow(result);
    }

    Get.back(result: true);
  }


  @override
  void onClose() {
    tipoController.dispose();
    codigoController.dispose();
    nomeController.dispose();
    tipoTrabalhoController.dispose();
    cargaHorariaController.dispose();
    entrada01Controller.dispose();
    saida01Controller.dispose();
    entrada02Controller.dispose();
    saida02Controller.dispose();
    entrada03Controller.dispose();
    saida03Controller.dispose();
    entrada04Controller.dispose();
    saida04Controller.dispose();
    entrada05Controller.dispose();
    saida05Controller.dispose();
    horaInicioJornadaController.dispose();
    horaFimJornadaController.dispose();
    super.onClose();
  }

}