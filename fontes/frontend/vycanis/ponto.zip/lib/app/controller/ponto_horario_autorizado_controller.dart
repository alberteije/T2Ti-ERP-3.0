import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:extended_masked_text/extended_masked_text.dart';
import 'package:ponto/app/page/shared_widget/input/input_imports.dart';

import 'package:ponto/app/page/shared_widget/message_dialog.dart';
import 'package:ponto/app/page/grid_columns/grid_columns_imports.dart';
import 'package:ponto/app/routes/app_routes.dart';
import 'package:ponto/app/controller/controller_imports.dart';
import 'package:ponto/app/data/model/model_imports.dart';
import 'package:ponto/app/data/repository/ponto_horario_autorizado_repository.dart';

class PontoHorarioAutorizadoController extends ControllerBase<PontoHorarioAutorizadoModel, PontoHorarioAutorizadoRepository> {

  PontoHorarioAutorizadoController({required super.repository}) {
    dbColumns = PontoHorarioAutorizadoModel.dbColumns;
    aliasColumns = PontoHorarioAutorizadoModel.aliasColumns;
    gridColumns = pontoHorarioAutorizadoGridColumns();
    functionName = "ponto_horario_autorizado";
    screenTitle = "Horário Autorizado";
  }

  @override
  PontoHorarioAutorizadoModel createNewModel() => PontoHorarioAutorizadoModel();

  @override
  final standardFieldForFilter = PontoHorarioAutorizadoModel.aliasColumns[PontoHorarioAutorizadoModel.dbColumns.indexOf('data_horario')];

  final viewPessoaColaboradorModelController = TextEditingController();
  final dataHorarioController = DatePickerItemController(null);
  final tipoController = CustomDropdownButtonController('Fixo');
  final cargaHorariaController = MaskedTextController(mask: '00:00:00',);
  final entrada01Controller = MaskedTextController(mask: '00:00:00',);
  final saida01Controller = MaskedTextController(mask: '00:00:00',);
  final entrada02Controller = MaskedTextController(mask: '00:00:00',);
  final saida02Controller = MaskedTextController(mask: '00:00:00',);
  final entrada03Controller = MaskedTextController(mask: '00:00:00',);
  final saida03Controller = MaskedTextController(mask: '00:00:00',);
  final entrada04Controller = MaskedTextController(mask: '00:00:00',);
  final saida04Controller = MaskedTextController(mask: '00:00:00',);
  final entrada05Controller = MaskedTextController(mask: '00:00:00',);
  final saida05Controller = MaskedTextController(mask: '00:00:00',);
  final horaFechamentoDiaController = MaskedTextController(mask: '00:00:00',);

  final Map<String, dynamic> mobileConfig = {
    'primaryColumns': ['data_horario'],
    'secondaryColumns': ['tipo'],
  };

  List<Map<String, dynamic>> get mobileItems {
    return modelList.map((pontoHorarioAutorizado) => pontoHorarioAutorizado.toJson).toList();
  }

  @override
  void prepareForInsert() {
    isNewRecord = true;
    currentModel = createNewModel();
    _resetForm();
    Get.toNamed(Routes.pontoHorarioAutorizadoEditPage);
  }

  void _resetForm() {
    formWasChanged = false;
    viewPessoaColaboradorModelController.text = '';
    dataHorarioController.date = null;
    tipoController.selected = 'Fixo';
    cargaHorariaController.text = '';
    entrada01Controller.text = '';
    saida01Controller.text = '';
    entrada02Controller.text = '';
    saida02Controller.text = '';
    entrada03Controller.text = '';
    saida03Controller.text = '';
    entrada04Controller.text = '';
    saida04Controller.text = '';
    entrada05Controller.text = '';
    saida05Controller.text = '';
    horaFechamentoDiaController.text = '';
  }

  @override
  void selectRowForEditingById(int id) {
    final model = modelList.firstWhere((m) => m.id == id);
    currentModel = model.clone();
    updateControllersFromModel();
    Get.toNamed(Routes.pontoHorarioAutorizadoEditPage);
  }

  void updateControllersFromModel() {
    viewPessoaColaboradorModelController.text = currentModel.viewPessoaColaboradorModel?.nome?.toString() ?? '';
    dataHorarioController.date = currentModel.dataHorario;
    tipoController.selected = currentModel.tipo ?? 'Fixo';
    cargaHorariaController.text = currentModel.cargaHoraria ?? '';
    entrada01Controller.text = currentModel.entrada01 ?? '';
    saida01Controller.text = currentModel.saida01 ?? '';
    entrada02Controller.text = currentModel.entrada02 ?? '';
    saida02Controller.text = currentModel.saida02 ?? '';
    entrada03Controller.text = currentModel.entrada03 ?? '';
    saida03Controller.text = currentModel.saida03 ?? '';
    entrada04Controller.text = currentModel.entrada04 ?? '';
    saida04Controller.text = currentModel.saida04 ?? '';
    entrada05Controller.text = currentModel.entrada05 ?? '';
    saida05Controller.text = currentModel.saida05 ?? '';
    horaFechamentoDiaController.text = currentModel.horaFechamentoDia ?? '';
    formWasChanged = false;
  }

  @override
  Future<void> save() async {
    if (!formKey.currentState!.validate()) {
      showErrorSnackBar(message: 'validator_form_message'.tr);
      return;
    }

    final existingIndex = modelList.indexWhere((m) => m.id == currentModel.id);

    if (existingIndex >= 0) {
      modelList[existingIndex] = currentModel.clone();
    }

    final result = await repository.save(pontoHorarioAutorizadoModel: currentModel);
    if (result == null) return;

    if (existingIndex >= 0) {
      modelList[existingIndex] = result;
    } else {
      modelList.insert(0, result);
    }

    if (!GetPlatform.isMobile) {
      updateGridRow(result);
    }

    Get.back(result: true);
  }

  Future callViewPessoaColaboradorLookup() async { 
		final lookupController = Get.find<LookupController>(); 
		lookupController.refreshItems(standardValue: '%'); 
		lookupController.title = '${'lookup_page_title'.tr} [Colaborador]'; 
		lookupController.route = '/view-pessoa-colaborador/'; 
		lookupController.gridColumns = viewPessoaColaboradorGridColumns(isForLookup: true); 
		lookupController.aliasColumns = ViewPessoaColaboradorModel.aliasColumns; 
		lookupController.dbColumns = ViewPessoaColaboradorModel.dbColumns; 
		lookupController.standardColumn = ViewPessoaColaboradorModel.aliasColumns[ViewPessoaColaboradorModel.dbColumns.indexOf('nome')]; 

		final plutoRowResult = await Get.toNamed(Routes.lookupPage); 
		if (plutoRowResult != null) { 
			currentModel.idColaborador = plutoRowResult.cells['id']!.value; 
			currentModel.viewPessoaColaboradorModel = ViewPessoaColaboradorModel.fromPlutoRow(plutoRowResult); 
			viewPessoaColaboradorModelController.text = currentModel.viewPessoaColaboradorModel?.nome ?? ''; 
			formWasChanged = true; 
		}
	}


  @override
  void onClose() {
    viewPessoaColaboradorModelController.dispose();
    dataHorarioController.dispose();
    tipoController.dispose();
    cargaHorariaController.dispose();
    entrada01Controller.dispose();
    saida01Controller.dispose();
    entrada02Controller.dispose();
    saida02Controller.dispose();
    entrada03Controller.dispose();
    saida03Controller.dispose();
    entrada04Controller.dispose();
    saida04Controller.dispose();
    entrada05Controller.dispose();
    saida05Controller.dispose();
    horaFechamentoDiaController.dispose();
    super.onClose();
  }

}