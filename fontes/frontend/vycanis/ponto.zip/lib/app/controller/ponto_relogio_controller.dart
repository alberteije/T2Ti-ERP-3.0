import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:ponto/app/page/shared_widget/input/input_imports.dart';

import 'package:ponto/app/page/shared_widget/message_dialog.dart';
import 'package:ponto/app/page/grid_columns/grid_columns_imports.dart';
import 'package:ponto/app/routes/app_routes.dart';
import 'package:ponto/app/controller/controller_imports.dart';
import 'package:ponto/app/data/model/model_imports.dart';
import 'package:ponto/app/data/repository/ponto_relogio_repository.dart';

class PontoRelogioController extends ControllerBase<PontoRelogioModel, PontoRelogioRepository> {

  PontoRelogioController({required super.repository}) {
    dbColumns = PontoRelogioModel.dbColumns;
    aliasColumns = PontoRelogioModel.aliasColumns;
    gridColumns = pontoRelogioGridColumns();
    functionName = "ponto_relogio";
    screenTitle = "Relógio de Ponto";
  }

  @override
  PontoRelogioModel createNewModel() => PontoRelogioModel();

  @override
  final standardFieldForFilter = PontoRelogioModel.aliasColumns[PontoRelogioModel.dbColumns.indexOf('localizacao')];

  final localizacaoController = TextEditingController();
  final marcaController = TextEditingController();
  final fabricanteController = TextEditingController();
  final numeroSerieController = TextEditingController();
  final utilizacaoController = CustomDropdownButtonController('Ponto');

  final Map<String, dynamic> mobileConfig = {
    'primaryColumns': ['localizacao'],
    'secondaryColumns': ['marca'],
  };

  List<Map<String, dynamic>> get mobileItems {
    return modelList.map((pontoRelogio) => pontoRelogio.toJson).toList();
  }

  @override
  void prepareForInsert() {
    isNewRecord = true;
    currentModel = createNewModel();
    _resetForm();
    Get.toNamed(Routes.pontoRelogioEditPage);
  }

  void _resetForm() {
    formWasChanged = false;
    localizacaoController.text = '';
    marcaController.text = '';
    fabricanteController.text = '';
    numeroSerieController.text = '';
    utilizacaoController.selected = 'Ponto';
  }

  @override
  void selectRowForEditingById(int id) {
    final model = modelList.firstWhere((m) => m.id == id);
    currentModel = model.clone();
    updateControllersFromModel();
    Get.toNamed(Routes.pontoRelogioEditPage);
  }

  void updateControllersFromModel() {
    localizacaoController.text = currentModel.localizacao ?? '';
    marcaController.text = currentModel.marca ?? '';
    fabricanteController.text = currentModel.fabricante ?? '';
    numeroSerieController.text = currentModel.numeroSerie ?? '';
    utilizacaoController.selected = currentModel.utilizacao ?? 'Ponto';
    formWasChanged = false;
  }

  @override
  Future<void> save() async {
    if (!formKey.currentState!.validate()) {
      showErrorSnackBar(message: 'validator_form_message'.tr);
      return;
    }

    final existingIndex = modelList.indexWhere((m) => m.id == currentModel.id);

    if (existingIndex >= 0) {
      modelList[existingIndex] = currentModel.clone();
    }

    final result = await repository.save(pontoRelogioModel: currentModel);
    if (result == null) return;

    if (existingIndex >= 0) {
      modelList[existingIndex] = result;
    } else {
      modelList.insert(0, result);
    }

    if (!GetPlatform.isMobile) {
      updateGridRow(result);
    }

    Get.back(result: true);
  }


  @override
  void onClose() {
    localizacaoController.dispose();
    marcaController.dispose();
    fabricanteController.dispose();
    numeroSerieController.dispose();
    utilizacaoController.dispose();
    super.onClose();
  }

}