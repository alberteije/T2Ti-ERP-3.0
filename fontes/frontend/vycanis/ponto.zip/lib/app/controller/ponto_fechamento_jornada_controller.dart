import 'dart:convert';
import 'dart:io';
import 'dart:typed_data';

import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:extended_masked_text/extended_masked_text.dart';
import 'package:ponto/app/data/provider/api/ponto_horario_api_provider.dart';
import 'package:ponto/app/data/provider/api/ponto_marcacao_api_provider.dart';
import 'package:ponto/app/data/provider/drift/ponto_horario_drift_provider.dart';
import 'package:ponto/app/data/provider/drift/ponto_marcacao_drift_provider.dart';
import 'package:ponto/app/data/repository/ponto_horario_repository.dart';
import 'package:ponto/app/data/repository/ponto_marcacao_repository.dart';
import 'package:ponto/app/infra/infra_imports.dart';
import 'package:ponto/app/page/page_imports.dart';
import 'package:ponto/app/page/shared_page/shared_page_imports.dart';
import 'package:ponto/app/page/shared_widget/input/input_imports.dart';

import 'package:ponto/app/page/shared_widget/message_dialog.dart';
import 'package:ponto/app/page/grid_columns/grid_columns_imports.dart';
import 'package:ponto/app/routes/app_routes.dart';
import 'package:ponto/app/controller/controller_imports.dart';
import 'package:ponto/app/data/model/model_imports.dart';
import 'package:ponto/app/data/repository/ponto_fechamento_jornada_repository.dart';

class PontoFechamentoJornadaController extends ControllerBase<PontoFechamentoJornadaModel, PontoFechamentoJornadaRepository> {

  PontoFechamentoJornadaController({required super.repository}) {
    dbColumns = PontoFechamentoJornadaModel.dbColumns;
    aliasColumns = PontoFechamentoJornadaModel.aliasColumns;
    gridColumns = pontoFechamentoJornadaGridColumns();
    functionName = "ponto_fechamento_jornada";
    screenTitle = "Fechamento da Jornada";
  }

  @override
  PontoFechamentoJornadaModel createNewModel() => PontoFechamentoJornadaModel();

  @override
  final standardFieldForFilter = PontoFechamentoJornadaModel.aliasColumns[PontoFechamentoJornadaModel.dbColumns.indexOf('data_fechamento')];

  final pontoClassificacaoJornadaModelController = TextEditingController();
  final viewPessoaColaboradorModelController = TextEditingController();
  final dataFechamentoController = DatePickerItemController(null);
  final diaSemanaController = CustomDropdownButtonController('DOMINGO');
  final codigoHorarioController = TextEditingController();
  final cargaHorariaEsperadaController = MaskedTextController(mask: '00:00:00',);
  final cargaHorariaDiurnaController = MaskedTextController(mask: '00:00:00',);
  final cargaHorariaNoturnaController = MaskedTextController(mask: '00:00:00',);
  final cargaHorariaTotalController = MaskedTextController(mask: '00:00:00',);
  final entrada01Controller = MaskedTextController(mask: '00:00:00',);
  final saida01Controller = MaskedTextController(mask: '00:00:00',);
  final entrada02Controller = MaskedTextController(mask: '00:00:00',);
  final saida02Controller = MaskedTextController(mask: '00:00:00',);
  final entrada03Controller = MaskedTextController(mask: '00:00:00',);
  final saida03Controller = MaskedTextController(mask: '00:00:00',);
  final entrada04Controller = MaskedTextController(mask: '00:00:00',);
  final saida04Controller = MaskedTextController(mask: '00:00:00',);
  final entrada05Controller = MaskedTextController(mask: '00:00:00',);
  final saida05Controller = MaskedTextController(mask: '00:00:00',);
  final horaInicioJornadaController = MaskedTextController(mask: '00:00:00',);
  final horaFimJornadaController = MaskedTextController(mask: '00:00:00',);
  final horaExtra01Controller = MaskedTextController(mask: '00:00:00',);
  final percentualHoraExtra01Controller = MoneyMaskedTextController();
  final modalidadeHoraExtra01Controller = CustomDropdownButtonController('Diurna');
  final horaExtra02Controller = MaskedTextController(mask: '00:00:00',);
  final percentualHoraExtra02Controller = MoneyMaskedTextController();
  final modalidadeHoraExtra02Controller = CustomDropdownButtonController('Diurna');
  final horaExtra03Controller = MaskedTextController(mask: '00:00:00',);
  final percentualHoraExtra03Controller = MoneyMaskedTextController();
  final modalidadeHoraExtra03Controller = CustomDropdownButtonController('Diurna');
  final horaExtra04Controller = MaskedTextController(mask: '00:00:00',);
  final percentualHoraExtra04Controller = MoneyMaskedTextController();
  final modalidadeHoraExtra04Controller = CustomDropdownButtonController('Diurna');
  final faltaAtrasoController = MaskedTextController(mask: '00:00:00',);
  final compensarController = CustomDropdownButtonController('Horas a mais');
  final bancoHorasController = MaskedTextController(mask: '00:00:00',);
  final observacaoController = TextEditingController();

  final Map<String, dynamic> mobileConfig = {
    'primaryColumns': ['data_fechamento'],
    'secondaryColumns': ['dia_semana'],
  };

  List<Map<String, dynamic>> get mobileItems {
    return modelList.map((pontoFechamentoJornada) => pontoFechamentoJornada.toJson).toList();
  }

  @override
  void prepareForInsert() {
    isNewRecord = true;
    currentModel = createNewModel();
    _resetForm();
    Get.toNamed(Routes.pontoFechamentoJornadaEditPage);
  }

  void _resetForm() {
    formWasChanged = false;
    pontoClassificacaoJornadaModelController.text = '';
    viewPessoaColaboradorModelController.text = '';
    dataFechamentoController.date = null;
    diaSemanaController.selected = 'DOMINGO';
    codigoHorarioController.text = '';
    cargaHorariaEsperadaController.text = '';
    cargaHorariaDiurnaController.text = '';
    cargaHorariaNoturnaController.text = '';
    cargaHorariaTotalController.text = '';
    entrada01Controller.text = '';
    saida01Controller.text = '';
    entrada02Controller.text = '';
    saida02Controller.text = '';
    entrada03Controller.text = '';
    saida03Controller.text = '';
    entrada04Controller.text = '';
    saida04Controller.text = '';
    entrada05Controller.text = '';
    saida05Controller.text = '';
    horaInicioJornadaController.text = '';
    horaFimJornadaController.text = '';
    horaExtra01Controller.text = '';
    percentualHoraExtra01Controller.updateValue(0);
    modalidadeHoraExtra01Controller.selected = 'Diurna';
    horaExtra02Controller.text = '';
    percentualHoraExtra02Controller.updateValue(0);
    modalidadeHoraExtra02Controller.selected = 'Diurna';
    horaExtra03Controller.text = '';
    percentualHoraExtra03Controller.updateValue(0);
    modalidadeHoraExtra03Controller.selected = 'Diurna';
    horaExtra04Controller.text = '';
    percentualHoraExtra04Controller.updateValue(0);
    modalidadeHoraExtra04Controller.selected = 'Diurna';
    faltaAtrasoController.text = '';
    compensarController.selected = 'Horas a mais';
    bancoHorasController.text = '';
    observacaoController.text = '';
  }

  @override
  void selectRowForEditingById(int id) {
    final model = modelList.firstWhere((m) => m.id == id);
    currentModel = model.clone();
    updateControllersFromModel();
    Get.toNamed(Routes.pontoFechamentoJornadaEditPage);
  }

  void updateControllersFromModel() {
    pontoClassificacaoJornadaModelController.text = currentModel.pontoClassificacaoJornadaModel?.nome?.toString() ?? '';
    viewPessoaColaboradorModelController.text = currentModel.viewPessoaColaboradorModel?.nome?.toString() ?? '';
    dataFechamentoController.date = currentModel.dataFechamento;
    diaSemanaController.selected = currentModel.diaSemana ?? 'DOMINGO';
    codigoHorarioController.text = currentModel.codigoHorario ?? '';
    cargaHorariaEsperadaController.text = currentModel.cargaHorariaEsperada ?? '';
    cargaHorariaDiurnaController.text = currentModel.cargaHorariaDiurna ?? '';
    cargaHorariaNoturnaController.text = currentModel.cargaHorariaNoturna ?? '';
    cargaHorariaTotalController.text = currentModel.cargaHorariaTotal ?? '';
    entrada01Controller.text = currentModel.entrada01 ?? '';
    saida01Controller.text = currentModel.saida01 ?? '';
    entrada02Controller.text = currentModel.entrada02 ?? '';
    saida02Controller.text = currentModel.saida02 ?? '';
    entrada03Controller.text = currentModel.entrada03 ?? '';
    saida03Controller.text = currentModel.saida03 ?? '';
    entrada04Controller.text = currentModel.entrada04 ?? '';
    saida04Controller.text = currentModel.saida04 ?? '';
    entrada05Controller.text = currentModel.entrada05 ?? '';
    saida05Controller.text = currentModel.saida05 ?? '';
    horaInicioJornadaController.text = currentModel.horaInicioJornada ?? '';
    horaFimJornadaController.text = currentModel.horaFimJornada ?? '';
    horaExtra01Controller.text = currentModel.horaExtra01 ?? '';
    percentualHoraExtra01Controller.updateValue(currentModel.percentualHoraExtra01 ?? 0);
    modalidadeHoraExtra01Controller.selected = currentModel.modalidadeHoraExtra01 ?? 'Diurna';
    horaExtra02Controller.text = currentModel.horaExtra02 ?? '';
    percentualHoraExtra02Controller.updateValue(currentModel.percentualHoraExtra02 ?? 0);
    modalidadeHoraExtra02Controller.selected = currentModel.modalidadeHoraExtra02 ?? 'Diurna';
    horaExtra03Controller.text = currentModel.horaExtra03 ?? '';
    percentualHoraExtra03Controller.updateValue(currentModel.percentualHoraExtra03 ?? 0);
    modalidadeHoraExtra03Controller.selected = currentModel.modalidadeHoraExtra03 ?? 'Diurna';
    horaExtra04Controller.text = currentModel.horaExtra04 ?? '';
    percentualHoraExtra04Controller.updateValue(currentModel.percentualHoraExtra04 ?? 0);
    modalidadeHoraExtra04Controller.selected = currentModel.modalidadeHoraExtra04 ?? 'Diurna';
    faltaAtrasoController.text = currentModel.faltaAtraso ?? '';
    compensarController.selected = currentModel.compensar ?? 'Horas a mais';
    bancoHorasController.text = currentModel.bancoHoras ?? '';
    observacaoController.text = currentModel.observacao ?? '';
    formWasChanged = false;
  }

  @override
  Future<void> save() async {
    if (!formKey.currentState!.validate()) {
      showErrorSnackBar(message: 'validator_form_message'.tr);
      return;
    }

    final existingIndex = modelList.indexWhere((m) => m.id == currentModel.id);

    if (existingIndex >= 0) {
      modelList[existingIndex] = currentModel.clone();
    }

    final result = await repository.save(pontoFechamentoJornadaModel: currentModel);
    if (result == null) return;

    if (existingIndex >= 0) {
      modelList[existingIndex] = result;
    } else {
      modelList.insert(0, result);
    }

    if (!GetPlatform.isMobile) {
      updateGridRow(result);
    }

    Get.back(result: true);
  }

  Future callPontoClassificacaoJornadaLookup() async { 
		final lookupController = Get.find<LookupController>(); 
		lookupController.refreshItems(standardValue: '%'); 
		lookupController.title = '${'lookup_page_title'.tr} [Classificação Jornada]'; 
		lookupController.route = '/ponto-classificacao-jornada/'; 
		lookupController.gridColumns = pontoClassificacaoJornadaGridColumns(isForLookup: true); 
		lookupController.aliasColumns = PontoClassificacaoJornadaModel.aliasColumns; 
		lookupController.dbColumns = PontoClassificacaoJornadaModel.dbColumns; 
		lookupController.standardColumn = PontoClassificacaoJornadaModel.aliasColumns[PontoClassificacaoJornadaModel.dbColumns.indexOf('nome')]; 

		final plutoRowResult = await Get.toNamed(Routes.lookupPage); 
		if (plutoRowResult != null) { 
			currentModel.idPontoClassificacaoJornada = plutoRowResult.cells['id']!.value; 
			currentModel.pontoClassificacaoJornadaModel = PontoClassificacaoJornadaModel.fromPlutoRow(plutoRowResult); 
			pontoClassificacaoJornadaModelController.text = currentModel.pontoClassificacaoJornadaModel?.nome ?? ''; 
			formWasChanged = true; 
		}
	}

  Future callViewPessoaColaboradorLookup() async { 
		final lookupController = Get.find<LookupController>(); 
		lookupController.refreshItems(standardValue: '%'); 
		lookupController.title = '${'lookup_page_title'.tr} [Colaborador]'; 
		lookupController.route = '/view-pessoa-colaborador/'; 
		lookupController.gridColumns = viewPessoaColaboradorGridColumns(isForLookup: true); 
		lookupController.aliasColumns = ViewPessoaColaboradorModel.aliasColumns; 
		lookupController.dbColumns = ViewPessoaColaboradorModel.dbColumns; 
		lookupController.standardColumn = ViewPessoaColaboradorModel.aliasColumns[ViewPessoaColaboradorModel.dbColumns.indexOf('nome')]; 

		final plutoRowResult = await Get.toNamed(Routes.lookupPage); 
		if (plutoRowResult != null) { 
			currentModel.idColaborador = plutoRowResult.cells['id']!.value; 
			currentModel.viewPessoaColaboradorModel = ViewPessoaColaboradorModel.fromPlutoRow(plutoRowResult); 
			viewPessoaColaboradorModelController.text = currentModel.viewPessoaColaboradorModel?.nome ?? ''; 
			formWasChanged = true; 
		}
	}

  Future<void> imprimirEspelhoDePonto() async {
    showQuestionDialog('Deseja imprimir o Espelho de Ponto?', () async {

      // pegar os horários
      final pontoHorarioRepository = PontoHorarioRepository(pontoHorarioApiProvider: PontoHorarioApiProvider(), pontoHorarioDriftProvider: PontoHorarioDriftProvider());
      final listaHorarios = await pontoHorarioRepository.getList();

      // pegar as marcações
      final pontoMarcacaoRepository = PontoMarcacaoRepository(pontoMarcacaoApiProvider: PontoMarcacaoApiProvider(), pontoMarcacaoDriftProvider: PontoMarcacaoDriftProvider());
      final listaMarcacoes = await pontoMarcacaoRepository.getList();

      final pdfBytes = await gerarEspelhoDePontoPdf(
        empresa: Session.empresaSessao,
        colaborador: currentModel.viewPessoaColaboradorModel!,
        horariosContratuais: listaHorarios,
        jornadas: modelList,
        marcacoes: listaMarcacoes,
        mesAno: '10/2025',
      );

      Get.to(() => PdfPage(
        title: "Espelho de Ponto",
        pdfFile: pdfBytes,
      ));

    });
  }

  Future<void> gerarArquivoAEJ() async {
    showQuestionDialog('Deseja gerar o arquivo AEJ?', () async {
      final List<PontoRelogioModel> relogios = [];
      final List<PontoHorarioModel> horarios = [];
      final bytes = gerarAEJ(
        fechamentos: modelList,
        relogios: relogios,
        horarios: horarios,
        ptrpNome: 'T2Ti ERP',
        ptrpVersao: '1.0.0',
        ptrpTipoId: '1',
        ptrpId: '00000000000191',
        ptrpRazao: 'Minha Empresa de Software',
        ptrpEmail: 'suporte@empresa.com',
      );

      const path = 'c:\\t2ti\\ponto\\arquivo.aej.txt';
      final file = File(path);
      await file.writeAsBytes(bytes);

      showInfoSnackBar(message: "Arquivo gerado com sucesso.");
    });
  }

  Uint8List gerarAEJ({
    required List<PontoFechamentoJornadaModel> fechamentos,
    required List<PontoRelogioModel> relogios,
    required List<PontoHorarioModel> horarios,
    String versaoAej = '001',
    // dados do PTRP (opcional; se vazios, registro 08 será omitido)
    String? ptrpNome,
    String? ptrpVersao,
    String? ptrpTipoId,
    String? ptrpId,
    String? ptrpRazao,
    String? ptrpEmail,
    // fuso para campos DH
    String tzOffset = '-0300',
  }) {
    final lines = <String>[];
    if (fechamentos.isEmpty) {
      throw ArgumentError('Lista de fechamentos vazia — nada para exportar');
    }

    // ------------- Registro 01 - Cabeçalho -------------
    final dates = fechamentos.map((f) => f.dataFechamento!).toList();
    dates.sort((a, b) => a.compareTo(b));
    final dataInicial = dates.first;
    final dataFinal = dates.last;
    final now = DateTime.now();

    final empresa = Session.empresaSessao;
    const tpIdt = '1';
    final idtEmpregador = empresa.cnpj;
    const caepf = ''; // se tiver, colocar aqui
    const cno = ''; // se tiver, colocar aqui
    final razao = empresa.razaoSocial;

    final headerFields = <String>[
      '01', // tipoReg
      tpIdt, // tpIdtEmpregador
      idtEmpregador!, // idtEmpregador (11 ou 14)
      caepf,
      cno,
      razao!,
      _formatDateForD(dataInicial),
      _formatDateForD(dataFinal),
      _formatDH(now, tzOffset: tzOffset),
      versaoAej,
    ];
    lines.add(headerFields.join('|'));

    // ------------- Registro 02 - REPs utilizados -------------
    // idRepAej: vamos enumerar 1..N conforme relogios listados
    final idRepMap = <int, String>{}; // idPontoRelogio (model.id) -> idRepAej (string)
    for (var i = 0; i < relogios.length; i++) {
      final r = relogios[i];
      final idRepAej = (i + 1).toString(); // 1..N
      // tpRep: tentamos inferir; se vazio, assume "1" (REP-C)
      final tpRep = (r.utilizacao != null && r.utilizacao!.isNotEmpty) ? '1' : '1';
      final nrRep = (r.numeroSerie ?? '').replaceAll(RegExp(r'\D'), '');
      final fields = <String>[
        '02',
        idRepAej,
        tpRep,
        nrRep,
      ];
      lines.add(fields.join('|'));
      if (r.id != null) idRepMap[r.id!] = idRepAej;
    }

    // ------------- Registro 03 - Vínculos (colaboradores) -------------
    // Criar map idColaborador -> idtVinculoAej (seq 1..N)
    final vinculoMap = <int, int>{}; // idColaborador -> idtVinculoAej
    final List<Map<String, String>> vinculos = [];
    int vincCounter = 0;
    for (var f in fechamentos) {
      final vc = f.viewPessoaColaboradorModel;
      final idCol = vc?.id ?? f.idColaborador;
      if (idCol == null) continue;
      if (!vinculoMap.containsKey(idCol)) {
        vincCounter++;
        vinculoMap[idCol] = vincCounter;
        final cpf = (vc?.cpfCnpj ?? '').replaceAll(RegExp(r'\D'), '');
        final name = (vc?.nome ?? '').replaceAll('\n', ' ').replaceAll('|', ' ');
        vinculos.add({'idt': vincCounter.toString(), 'cpf': cpf, 'nome': name});
        lines.add(['03', vincCounter.toString(), cpf, name].join('|'));
      }
    }

    // ------------- Registro 04 - Horário contratual -------------
    // Collect unique codigoHorario from fechamentos
    final codHorSet = <String>{};
    for (var f in fechamentos) {
      if (f.codigoHorario != null && f.codigoHorario!.trim().isNotEmpty) codHorSet.add(f.codigoHorario!.trim());
    }
    final codHorList = codHorSet.toList();
    for (var cod in codHorList) {
      // try find in horarios list
      final ph = horarios.firstWhere((h) => (h.codigo ?? '') == cod, orElse: () => PontoHorarioModel()..codigo = cod);
      // durJornada em minutos (cargaHoraria pode estar em 'HH:mm' ou 'HH:mm:ss')
      final durMin = _parseDurationMinutes(ph.cargaHoraria) ;
      final hrEntrada01 = _toHField(ph.entrada01);
      final hrSaida01 = _toHField(ph.saida01);
      final hrEntrada02 = _toHField(ph.entrada02);
      final hrSaida02 = _toHField(ph.saida02);
      final fields = <String>[
        '04',
        cod,
        durMin.toString(),
        hrEntrada01,
        hrSaida01,
      ];
      // se existir segundo par
      if (hrEntrada02.isNotEmpty || hrSaida02.isNotEmpty) {
        fields.add(hrEntrada02);
        fields.add(hrSaida02);
      }
      lines.add(fields.join('|'));
    }

    // ------------- Registro 05 - Marcações -------------
    int qt05 = 0;
    for (var f in fechamentos) {
      // identifica idtVinculoAej
      final idCol = f.idColaborador ?? f.viewPessoaColaboradorModel?.id;
      final idtVinculo = (idCol != null && vinculoMap.containsKey(idCol)) ? vinculoMap[idCol]!.toString() : '';

      // para cada par entrada/saida (1..5), geramos E e S quando presentes
      for (int i = 0; i < 5; i++) {
        final ent = (i == 0) ? f.entrada01 : (i == 1) ? f.entrada02 : (i == 2) ? f.entrada03 : (i == 3) ? f.entrada04 : f.entrada05;
        final sai = (i == 0) ? f.saida01 : (i == 1) ? f.saida02 : (i == 2) ? f.saida03 : (i == 3) ? f.saida04 : f.saida05;

        if (ent != null && ent.trim().isNotEmpty) {
          // Construir DateTime DH
          final date = f.dataFechamento!;
          // ent pode estar "HH:mm:ss" ou "HH:mm"
          final parts = ent.split(':').map((s) => int.tryParse(s) ?? 0).toList();
          final dtEnt = DateTime(date.year, date.month, date.day, parts[0], parts.length > 1 ? parts[1] : 0, parts.length > 2 ? parts[2] : 0);
          final dataHoraMarc = _formatDH(dtEnt, tzOffset: tzOffset);
          final seq = _three(i + 1);
          const fonte = 'O'; // assumindo original
          final codHor = (i == 0) ? (f.codigoHorario ?? '') : ''; // obrigatório na primeira entrada
          const idRepAej = ''; // não temos mapeamento de relogio aqui (opcional)
          final fields = <String>[
            '05',
            idtVinculo,
            dataHoraMarc,
            idRepAej,
            'E',
            seq,
            fonte,
            codHor,
            '' // motivo
          ];
          lines.add(fields.join('|'));
          qt05++;
        }

        if (sai != null && sai.trim().isNotEmpty) {
          final date = f.dataFechamento!;
          final parts = sai.split(':').map((s) => int.tryParse(s) ?? 0).toList();
          final dtSai = DateTime(date.year, date.month, date.day, parts[0], parts.length > 1 ? parts[1] : 0, parts.length > 2 ? parts[2] : 0);
          final dataHoraMarc = _formatDH(dtSai, tzOffset: tzOffset);
          final seq = _three(i + 1);
          const fonte = 'O';
          const codHor = ''; // somente entrada1 deve trazer codigo
          const idRepAej = '';
          final fields = <String>[
            '05',
            idtVinculo,
            dataHoraMarc,
            idRepAej,
            'S',
            seq,
            fonte,
            codHor,
            ''
          ];
          lines.add(fields.join('|'));
          qt05++;
        }
      }
    }

    // ------------- Registro 06 (opcional) - omitido por padrão -------------
    // ------------- Registro 07 (opcional) - ausências/banco de horas - omitido por padrão -------------

    // ------------- Registro 08 - PTRP -------------
    if (ptrpNome != null && ptrpNome.trim().isNotEmpty) {
      final fields = <String>[
        '08',
        ptrpNome.replaceAll('|', ' '),
        (ptrpVersao ?? '').replaceAll('|', ' '),
        (ptrpTipoId ?? '1'),
        (ptrpId ?? '').replaceAll(RegExp(r'\D'), ''),
        (ptrpRazao ?? '').replaceAll('|', ' '),
        (ptrpEmail ?? '').replaceAll('|', ' '),
      ];
      lines.add(fields.join('|'));
    }

    // ------------- Registro 99 - Trailer -------------
    // contagens dos tipos
    const qt01 = 1;
    final qt02 = relogios.length;
    final qt03 = vinculos.length;
    final qt04 = codHorList.length;
    final qt05Final = qt05;
    const qt06 = 0;
    const qt07 = 0;
    final qt08 = (ptrpNome != null && ptrpNome.trim().isNotEmpty) ? 1 : 0;

    final trailerFields = <String>[
      '99',
      qt01.toString(),
      qt02.toString(),
      qt03.toString(),
      qt04.toString(),
      qt05Final.toString(),
      qt06.toString(),
      qt07.toString(),
      qt08.toString()
    ];
    lines.add(trailerFields.join('|'));

    // Monta conteúdo final com CRLF e codifica Latin1 (ISO-8859-1)
    final content = '${lines.join('\r\n')}\r\n';
    final bytes = latin1.encode(content);
    return Uint8List.fromList(bytes);
  }

  @override
  void onClose() {
    pontoClassificacaoJornadaModelController.dispose();
    viewPessoaColaboradorModelController.dispose();
    dataFechamentoController.dispose();
    diaSemanaController.dispose();
    codigoHorarioController.dispose();
    cargaHorariaEsperadaController.dispose();
    cargaHorariaDiurnaController.dispose();
    cargaHorariaNoturnaController.dispose();
    cargaHorariaTotalController.dispose();
    entrada01Controller.dispose();
    saida01Controller.dispose();
    entrada02Controller.dispose();
    saida02Controller.dispose();
    entrada03Controller.dispose();
    saida03Controller.dispose();
    entrada04Controller.dispose();
    saida04Controller.dispose();
    entrada05Controller.dispose();
    saida05Controller.dispose();
    horaInicioJornadaController.dispose();
    horaFimJornadaController.dispose();
    horaExtra01Controller.dispose();
    percentualHoraExtra01Controller.dispose();
    modalidadeHoraExtra01Controller.dispose();
    horaExtra02Controller.dispose();
    percentualHoraExtra02Controller.dispose();
    modalidadeHoraExtra02Controller.dispose();
    horaExtra03Controller.dispose();
    percentualHoraExtra03Controller.dispose();
    modalidadeHoraExtra03Controller.dispose();
    horaExtra04Controller.dispose();
    percentualHoraExtra04Controller.dispose();
    modalidadeHoraExtra04Controller.dispose();
    faltaAtrasoController.dispose();
    compensarController.dispose();
    bancoHorasController.dispose();
    observacaoController.dispose();
    super.onClose();
  }


  // --------------------------------------------------------------------------------------------------------------------------
  // TODO: analise se deve mover essas funções para Util
  // --------------------------------------------------------------------------------------------------------------------------
  String _two(int n) => n.toString().padLeft(2, '0');
  String _three(int n) => n.toString().padLeft(3, '0');
  String _formatDateForD(DateTime d) => '${d.year.toString().padLeft(4,'0')}-${_two(d.month)}-${_two(d.day)}';
  String _formatDH(DateTime d, {String tzOffset = '-0300'}) {
    // monta: YYYY-MM-DDThh:mm:00-0300 (segundos fixos '00')
    return '${d.year.toString().padLeft(4,'0')}-${_two(d.month)}-${_two(d.day)}T${_two(d.hour)}:${_two(d.minute)}:00$tzOffset';
  }

  /// Converte "HH:mm" ou "HH:mm:ss" em minutos inteiros
  int _parseDurationMinutes(String? horastr) {
    if (horastr == null) return 0;
    final parts = horastr.split(':').map((s) => int.tryParse(s) ?? 0).toList();
    if (parts.length >= 2) {
      return parts[0] * 60 + parts[1];
    }
    if (parts.length == 1) return parts[0] * 60;
    return 0;
  }

  /// Converte "HH:mm:ss" (ou "HH:mm") para hora "hhmm" (campo H de 4 chars)
  String _toHField(String? hora) {
    if (hora == null || hora.trim().isEmpty) return '';
    final parts = hora.split(':').map((s) => int.tryParse(s) ?? 0).toList();
    final hh = _two(parts.isNotEmpty ? parts[0] : 0);
    final mm = _two(parts.length > 1 ? parts[1] : 0);
    return '$hh$mm';
  }
  // --------------------------------------------------------------------------------------------------------------------------

}