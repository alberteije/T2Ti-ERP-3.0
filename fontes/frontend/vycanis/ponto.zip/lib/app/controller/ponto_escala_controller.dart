import 'package:flutter/material.dart';
import 'dart:math';
import 'package:get/get.dart';
import 'package:extended_masked_text/extended_masked_text.dart';

import 'package:ponto/app/infra/infra_imports.dart';
import 'package:ponto/app/page/page_imports.dart';
import 'package:ponto/app/page/shared_widget/message_dialog.dart';
import 'package:ponto/app/page/grid_columns/grid_columns_imports.dart';
import 'package:ponto/app/routes/app_routes.dart';
import 'package:ponto/app/controller/controller_imports.dart';
import 'package:ponto/app/data/model/model_imports.dart';
import 'package:ponto/app/data/repository/ponto_escala_repository.dart';

class PontoEscalaController extends ControllerBase<PontoEscalaModel, PontoEscalaRepository> 
with GetSingleTickerProviderStateMixin {

  PontoEscalaController({required super.repository}) {
    dbColumns = PontoEscalaModel.dbColumns;
    aliasColumns = PontoEscalaModel.aliasColumns;
    gridColumns = pontoEscalaGridColumns();
    functionName = "ponto_escala";
    screenTitle = "Escalas";
  }

  final pontoEscalaScaffoldKey = GlobalKey<ScaffoldState>();
  final pontoEscalaTabPageScaffoldKey = GlobalKey<ScaffoldState>();
  final pontoEscalaFormKey = GlobalKey<FormState>();
  late TabController tabController;
  String? mandatoryMessage;  

  @override
  PontoEscalaModel createNewModel() => PontoEscalaModel();

  @override
  final standardFieldForFilter = PontoEscalaModel.aliasColumns[PontoEscalaModel.dbColumns.indexOf('nome')];

  final nomeController = TextEditingController();
  final descontoHoraDiaController = MaskedTextController(mask: '00:00:00',);
  final descontoDsrController = MaskedTextController(mask: '00:00:00',);
  final codigoHorarioDomingoController = TextEditingController();
  final codigoHorarioSegundaController = TextEditingController();
  final codigoHorarioTercaController = TextEditingController();
  final codigoHorarioQuartaController = TextEditingController();
  final codigoHorarioQuintaController = TextEditingController();
  final codigoHorarioSextaController = TextEditingController();
  final codigoHorarioSabadoController = TextEditingController();

  final Map<String, dynamic> mobileConfig = {
    'primaryColumns': ['nome'],
    'secondaryColumns': ['desconto_hora_dia'],
  };

  List<Map<String, dynamic>> get mobileItems {
    return modelList.map((pontoEscala) => pontoEscala.toJson).toList();
  }

  @override
  void prepareForInsert() {
    isNewRecord = true;
    currentModel = createNewModel();
    _resetForm();
    tabController.animateTo(0);
    updateControllersFromModel();
    Get.toNamed(Routes.pontoEscalaTabPage);
  }

  void _resetForm() {
    formWasChanged = false;
    nomeController.text = '';
    descontoHoraDiaController.text = '';
    descontoDsrController.text = '';
    codigoHorarioDomingoController.text = '';
    codigoHorarioSegundaController.text = '';
    codigoHorarioTercaController.text = '';
    codigoHorarioQuartaController.text = '';
    codigoHorarioQuintaController.text = '';
    codigoHorarioSextaController.text = '';
    codigoHorarioSabadoController.text = '';
  }

  @override
  void selectRowForEditingById(int id) {
    final model = modelList.firstWhere((m) => m.id == id);
    currentModel = model.clone();
    updateControllersFromModel();
    tabController.animateTo(0);
    Get.toNamed(Routes.pontoEscalaTabPage);
  }

  _configureChildrenControllers() {
    //Turmas
		Get.put<PontoTurmaController>(PontoTurmaController()); 

  }
	
	_releaseChildrenControllers() {
    //Turmas
		Get.delete<PontoTurmaController>(); 

	}
  
  void updateControllersFromModel() {
    nomeController.text = currentModel.nome ?? '';
    descontoHoraDiaController.text = currentModel.descontoHoraDia ?? '';
    descontoDsrController.text = currentModel.descontoDsr ?? '';
    codigoHorarioDomingoController.text = currentModel.codigoHorarioDomingo ?? '';
    codigoHorarioSegundaController.text = currentModel.codigoHorarioSegunda ?? '';
    codigoHorarioTercaController.text = currentModel.codigoHorarioTerca ?? '';
    codigoHorarioQuartaController.text = currentModel.codigoHorarioQuarta ?? '';
    codigoHorarioQuintaController.text = currentModel.codigoHorarioQuinta ?? '';
    codigoHorarioSextaController.text = currentModel.codigoHorarioSexta ?? '';
    codigoHorarioSabadoController.text = currentModel.codigoHorarioSabado ?? '';

    formWasChanged = false;
    _updateChildrenControllersFromModel();
  }

  void _updateChildrenControllersFromModel() {
    //Turmas
		final pontoTurmaController = Get.find<PontoTurmaController>(); 
		pontoTurmaController.userMadeChanges = false; 

  }

  @override
  Future<void> save() async {
    if (!validateCurrentForm()) return;
    if (validateForms()) {
      if (userMadeChanges()) {
        final existingIndex = modelList.indexWhere((m) => m.id == currentModel.id);

        if (existingIndex >= 0) {
          modelList[existingIndex] = currentModel.clone();
        }

        final result = await repository.save(pontoEscalaModel: currentModel);
        if (result == null) return;

        if (existingIndex >= 0) {
          modelList[existingIndex] = result;
        } else {
          modelList.insert(0, result);
        }

        if (!GetPlatform.isMobile) {
          updateGridRow(result);
        }

        Get.back(result: true);
      } else {
        Get.back();
      }
    } 
  }


  List<Tab> tabItems = [
    Tab( 
			icon: Icon(iconDataList[Random().nextInt(10)]), 
			text: 'Escalas', 
		),
    Tab( 
			icon: Icon(iconDataList[Random().nextInt(10)]), 
			text: 'Turmas', 
		),
  ];

  List<Widget> tabPages() {
    return [
      PontoEscalaEditPage(),
      const PontoTurmaListPage(),
    ];
  }

  @override
  void preventDataLoss() {
    if (userMadeChanges()) {
      showQuestionDialog('message_data_loss'.tr, () { 
        Get.back(); 
      });
    } else {
      Get.back();
    }
  }  

  bool userMadeChanges() {
    return
    formWasChanged 
    || 
		Get.find<PontoTurmaController>().userMadeChanges
    ;
  }

  void tabChange(int index) {
    validateCurrentForm();
  }

  bool validateCurrentForm() {
    return true;
  }

  bool validateForms() {
    return true;
  }

  @override
  void onInit() {
    super.onInit();
    tabController = TabController(vsync: this, length: tabItems.length);
    _configureChildrenControllers();
  }
	
  @override
  void onClose() {
    tabController.dispose();
    nomeController.dispose();
    descontoHoraDiaController.dispose();
    descontoDsrController.dispose();
    codigoHorarioDomingoController.dispose();
    codigoHorarioSegundaController.dispose();
    codigoHorarioTercaController.dispose();
    codigoHorarioQuartaController.dispose();
    codigoHorarioQuintaController.dispose();
    codigoHorarioSextaController.dispose();
    codigoHorarioSabadoController.dispose();
    _releaseChildrenControllers();
    super.onClose();
  }	
}