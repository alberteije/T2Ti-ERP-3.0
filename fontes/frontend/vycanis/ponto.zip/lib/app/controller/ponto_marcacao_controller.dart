import 'dart:convert';
import 'dart:io';

import 'package:file_picker/file_picker.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:extended_masked_text/extended_masked_text.dart';

import 'package:ponto/app/routes/app_routes.dart';
import 'package:ponto/app/controller/controller_imports.dart';

import 'package:ponto/app/data/provider/api/ponto_relogio_api_provider.dart';
import 'package:ponto/app/data/provider/api/view_pessoa_colaborador_api_provider.dart';
import 'package:ponto/app/data/provider/drift/ponto_relogio_drift_provider.dart';
import 'package:ponto/app/data/provider/drift/view_pessoa_colaborador_drift_provider.dart';
import 'package:ponto/app/data/repository/ponto_relogio_repository.dart';
import 'package:ponto/app/data/repository/view_pessoa_colaborador_repository.dart';
import 'package:ponto/app/data/model/model_imports.dart';
import 'package:ponto/app/data/repository/ponto_marcacao_repository.dart';

import 'package:ponto/app/page/shared_widget/input/input_imports.dart';
import 'package:ponto/app/page/shared_widget/message_dialog.dart';
import 'package:ponto/app/page/grid_columns/grid_columns_imports.dart';

class PontoMarcacaoController extends ControllerBase<PontoMarcacaoModel, PontoMarcacaoRepository> {

  PontoMarcacaoController({required super.repository}) {
    dbColumns = PontoMarcacaoModel.dbColumns;
    aliasColumns = PontoMarcacaoModel.aliasColumns;
    gridColumns = pontoMarcacaoGridColumns();
    functionName = "ponto_marcacao";
    screenTitle = "Marcações";
  }

  @override
  PontoMarcacaoModel createNewModel() => PontoMarcacaoModel();

  @override
  final standardFieldForFilter = PontoMarcacaoModel.aliasColumns[PontoMarcacaoModel.dbColumns.indexOf('nsr')];

  final pontoRelogioModelController = TextEditingController();
  final viewPessoaColaboradorModelController = TextEditingController();
  final nsrController = MoneyMaskedTextController(precision: 0, decimalSeparator: '', thousandSeparator: '');
  final dataMarcacaoController = DatePickerItemController(null);
  final horaMarcacaoController = MaskedTextController(mask: '00:00:00',);
  final tipoMarcacaoController = CustomDropdownButtonController('Entrada');
  final tipoRegistroController = CustomDropdownButtonController('0=Original');
  final parEntradaSaidaController = TextEditingController();
  final justificativaController = TextEditingController();

  final Map<String, dynamic> mobileConfig = {
    'primaryColumns': ['nsr'],
    'secondaryColumns': ['data_marcacao'],
  };

  List<Map<String, dynamic>> get mobileItems {
    return modelList.map((pontoMarcacao) => pontoMarcacao.toJson).toList();
  }

  @override
  void prepareForInsert() {
    isNewRecord = true;
    currentModel = createNewModel();
    _resetForm();
    Get.toNamed(Routes.pontoMarcacaoEditPage);
  }

  void _resetForm() {
    formWasChanged = false;
    pontoRelogioModelController.text = '';
    viewPessoaColaboradorModelController.text = '';
    nsrController.updateValue(0);
    dataMarcacaoController.date = null;
    horaMarcacaoController.text = '';
    tipoMarcacaoController.selected = 'Entrada';
    tipoRegistroController.selected = '0=Original';
    parEntradaSaidaController.text = '';
    justificativaController.text = '';
  }

  @override
  void selectRowForEditingById(int id) {
    final model = modelList.firstWhere((m) => m.id == id);
    currentModel = model.clone();
    updateControllersFromModel();
    Get.toNamed(Routes.pontoMarcacaoEditPage);
  }

  void updateControllersFromModel() {
    pontoRelogioModelController.text = currentModel.pontoRelogioModel?.numeroSerie?.toString() ?? '';
    viewPessoaColaboradorModelController.text = currentModel.viewPessoaColaboradorModel?.nome?.toString() ?? '';
    nsrController.updateValue((currentModel.nsr ?? 0).toDouble());
    dataMarcacaoController.date = currentModel.dataMarcacao;
    horaMarcacaoController.text = currentModel.horaMarcacao ?? '';
    tipoMarcacaoController.selected = currentModel.tipoMarcacao ?? 'Entrada';
    tipoRegistroController.selected = currentModel.tipoRegistro ?? '0=Original';
    parEntradaSaidaController.text = currentModel.parEntradaSaida ?? '';
    justificativaController.text = currentModel.justificativa ?? '';
    formWasChanged = false;
  }

  @override
  Future<void> save() async {
    if (!formKey.currentState!.validate()) {
      showErrorSnackBar(message: 'validator_form_message'.tr);
      return;
    }

    final existingIndex = modelList.indexWhere((m) => m.id == currentModel.id);

    if (existingIndex >= 0) {
      modelList[existingIndex] = currentModel.clone();
    }

    final result = await repository.save(pontoMarcacaoModel: currentModel);
    if (result == null) return;

    if (existingIndex >= 0) {
      modelList[existingIndex] = result;
    } else {
      modelList.insert(0, result);
    }

    if (!GetPlatform.isMobile) {
      updateGridRow(result);
    }

    Get.back(result: true);
  }

  Future callPontoRelogioLookup() async { 
		final lookupController = Get.find<LookupController>(); 
		lookupController.refreshItems(standardValue: '%'); 
		lookupController.title = '${'lookup_page_title'.tr} [Relogio]'; 
		lookupController.route = '/ponto-relogio/'; 
		lookupController.gridColumns = pontoRelogioGridColumns(isForLookup: true); 
		lookupController.aliasColumns = PontoRelogioModel.aliasColumns; 
		lookupController.dbColumns = PontoRelogioModel.dbColumns; 
		lookupController.standardColumn = PontoRelogioModel.aliasColumns[PontoRelogioModel.dbColumns.indexOf('numeroSerie')]; 

		final plutoRowResult = await Get.toNamed(Routes.lookupPage); 
		if (plutoRowResult != null) { 
			currentModel.idPontoRelogio = plutoRowResult.cells['id']!.value; 
			currentModel.pontoRelogioModel = PontoRelogioModel.fromPlutoRow(plutoRowResult); 
			pontoRelogioModelController.text = currentModel.pontoRelogioModel?.numeroSerie ?? ''; 
			formWasChanged = true; 
		}
	}

  Future callViewPessoaColaboradorLookup() async { 
		final lookupController = Get.find<LookupController>(); 
		lookupController.refreshItems(standardValue: '%'); 
		lookupController.title = '${'lookup_page_title'.tr} [Colaborador]'; 
		lookupController.route = '/view-pessoa-colaborador/'; 
		lookupController.gridColumns = viewPessoaColaboradorGridColumns(isForLookup: true); 
		lookupController.aliasColumns = ViewPessoaColaboradorModel.aliasColumns; 
		lookupController.dbColumns = ViewPessoaColaboradorModel.dbColumns; 
		lookupController.standardColumn = ViewPessoaColaboradorModel.aliasColumns[ViewPessoaColaboradorModel.dbColumns.indexOf('nome')]; 

		final plutoRowResult = await Get.toNamed(Routes.lookupPage); 
		if (plutoRowResult != null) { 
			currentModel.idColaborador = plutoRowResult.cells['id']!.value; 
			currentModel.viewPessoaColaboradorModel = ViewPessoaColaboradorModel.fromPlutoRow(plutoRowResult); 
			viewPessoaColaboradorModelController.text = currentModel.viewPessoaColaboradorModel?.nome ?? ''; 
			formWasChanged = true; 
		}
	}

  Future<void> importarArquivo() async {
    showQuestionDialog('Deseja importar o arquivo de marcações?', () async {
      try {
        FilePickerResult? result = await FilePicker.platform.pickFiles();
        if (result != null) {
          String arquivoAFD;

          if (kIsWeb) {
            Uint8List fileBytes = result.files.single.bytes!;
            arquivoAFD = utf8.decode(fileBytes);
          } else {
            File file = File(result.files.single.path!);
            arquivoAFD = await file.readAsString();
          }

          List<PontoMarcacaoModel> marcacoes = await processarArquivoAFD(arquivoAFD);
          if (marcacoes.isNotEmpty) {
            final success = await repository.saveBatch(marcacoes);
            if (success == true) {
              modelList.clear();
              await loadData();
              showInfoSnackBar(message: "${marcacoes.length} lançamentos importados com sucesso!");
            } else {
              showErrorSnackBar(message: "Erro ao importar lançamentos.");
            }
          }
        } else {
          showInfoSnackBar(message: "Nenhum arquivo selecionado.");
        }
      } catch (e) {
        showErrorSnackBar(message: "Erro ao importar arquivo: ${e.toString()}");
      }
    });
  }

  Future<List<PontoMarcacaoModel>> processarArquivoAFD(String conteudo) async {
    final linhas = const LineSplitter().convert(conteudo);
    List<PontoMarcacaoModel> marcacoes = [];
    var relogio = PontoRelogioModel();

    for (var linha in linhas) {
      if (linha.length < 10) continue;
      final tipo = linha.substring(9, 10);
      var colaborador = ViewPessoaColaboradorModel();

      if (tipo == '1') {
        final numeroSerieRelogio = linha.substring(190, 207).trim();
        // pegar o relogio
        final filter = Filter(
          condition: 'eq',
          field: 'numero_serie',
          value: numeroSerieRelogio
        );
        final pontoRelogioRepository = PontoRelogioRepository(pontoRelogioApiProvider: PontoRelogioApiProvider(), pontoRelogioDriftProvider: PontoRelogioDriftProvider());
        // TODO: implemente um getObject com filtro ou faça esse tratamento no servidor
        final retorno = await pontoRelogioRepository.getList(filter: filter);
        if (retorno != null && retorno.isNotEmpty) {
          relogio = retorno[0];
        }
      } else if (tipo == '3') {
        try {
          final nsr = int.tryParse(linha.substring(0, 9));
          final dataHoraStr = linha.substring(10, 34).trim(); // 24 posições (campo DH)
          final cpf = linha.substring(34, 46).trim();

          // pegar o colaborador
          final filter = Filter(
            condition: 'eq',
            field: 'cpf_cnpj',
            value: cpf
          );
          final viewPessoaColaboradorRepository = ViewPessoaColaboradorRepository(viewPessoaColaboradorApiProvider: ViewPessoaColaboradorApiProvider(), viewPessoaColaboradorDriftProvider: ViewPessoaColaboradorDriftProvider());
          // TODO: implemente um getObject com filtro ou faça esse tratamento no servidor
          final retorno = await viewPessoaColaboradorRepository.getList(filter: filter);
          if (retorno != null && retorno.isNotEmpty) {
            colaborador = retorno[0];
          }

          // Campo DH tem 24 posições - podemos simplificar assumindo formato compactado AAAAMMDDHHMMSS...
          DateTime? dataHora;
          if (RegExp(r'^\d{14,}$').hasMatch(dataHoraStr)) {
            // formato: AAAAMMDDHHMMSS + zeros
            final data = dataHoraStr.substring(0, 8);
            final hora = dataHoraStr.substring(8, 14);
            dataHora = DateTime.parse(
                '${data.substring(0, 4)}-${data.substring(4, 6)}-${data.substring(6, 8)}T${hora.substring(0, 2)}:${hora.substring(2, 4)}:${hora.substring(4, 6)}');
          } else {
            // formato ISO 8601 (caso venha assim)
            dataHora = DateTime.tryParse(dataHoraStr);
          }

          marcacoes.add(PontoMarcacaoModel(
            nsr: nsr,
            dataMarcacao: dataHora != null
                ? DateTime(dataHora.year, dataHora.month, dataHora.day)
                : null,
            horaMarcacao: dataHora != null
                ? '${dataHora.hour.toString().padLeft(2, '0')}:${dataHora.minute.toString().padLeft(2, '0')}:${dataHora.second.toString().padLeft(2, '0')}'
                : null,
            tipoMarcacao: '', // E=Entrada | S=Saída | D=Desconsiderar
            tipoRegistro: '0', // 0=Original | 1=Incluído por digitação | 2=Intervalo pré-assinalado
            parEntradaSaida: null, // Para cada entrada deve haver uma saída. Esse campo controla isso: [E1/S1, E2/S2, E3/S3]
            justificativa: null,
            idColaborador: colaborador.id,
            idPontoRelogio: relogio.id,
          ));
        } catch (e) {
          showErrorSnackBar(message: "Erro ao processar o registro tipo 3: ${e.toString()}");
        }
      }
    }

    return marcacoes;
  }

  @override
  void onClose() {
    pontoRelogioModelController.dispose();
    viewPessoaColaboradorModelController.dispose();
    nsrController.dispose();
    dataMarcacaoController.dispose();
    horaMarcacaoController.dispose();
    tipoMarcacaoController.dispose();
    tipoRegistroController.dispose();
    parEntradaSaidaController.dispose();
    justificativaController.dispose();
    super.onClose();
  }

}