import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:ponto/app/page/shared_widget/input/input_imports.dart';

import 'package:ponto/app/page/shared_widget/message_dialog.dart';
import 'package:ponto/app/page/grid_columns/grid_columns_imports.dart';
import 'package:ponto/app/routes/app_routes.dart';
import 'package:ponto/app/controller/controller_imports.dart';
import 'package:ponto/app/data/model/model_imports.dart';
import 'package:ponto/app/data/repository/ponto_classificacao_jornada_repository.dart';

class PontoClassificacaoJornadaController extends ControllerBase<PontoClassificacaoJornadaModel, PontoClassificacaoJornadaRepository> {

  PontoClassificacaoJornadaController({required super.repository}) {
    dbColumns = PontoClassificacaoJornadaModel.dbColumns;
    aliasColumns = PontoClassificacaoJornadaModel.aliasColumns;
    gridColumns = pontoClassificacaoJornadaGridColumns();
    functionName = "ponto_classificacao_jornada";
    screenTitle = "Classificação da Jornada";
  }

  @override
  PontoClassificacaoJornadaModel createNewModel() => PontoClassificacaoJornadaModel();

  @override
  final standardFieldForFilter = PontoClassificacaoJornadaModel.aliasColumns[PontoClassificacaoJornadaModel.dbColumns.indexOf('codigo')];

  final codigoController = TextEditingController();
  final nomeController = TextEditingController();
  final descricaoController = TextEditingController();
  final padraoController = CustomDropdownButtonController('Sim');
  final descontarHorasController = CustomDropdownButtonController('Sim');

  final Map<String, dynamic> mobileConfig = {
    'primaryColumns': ['codigo'],
    'secondaryColumns': ['nome'],
  };

  List<Map<String, dynamic>> get mobileItems {
    return modelList.map((pontoClassificacaoJornada) => pontoClassificacaoJornada.toJson).toList();
  }

  @override
  void prepareForInsert() {
    isNewRecord = true;
    currentModel = createNewModel();
    _resetForm();
    Get.toNamed(Routes.pontoClassificacaoJornadaEditPage);
  }

  void _resetForm() {
    formWasChanged = false;
    codigoController.text = '';
    nomeController.text = '';
    descricaoController.text = '';
    padraoController.selected = 'Sim';
    descontarHorasController.selected = 'Sim';
  }

  @override
  void selectRowForEditingById(int id) {
    final model = modelList.firstWhere((m) => m.id == id);
    currentModel = model.clone();
    updateControllersFromModel();
    Get.toNamed(Routes.pontoClassificacaoJornadaEditPage);
  }

  void updateControllersFromModel() {
    codigoController.text = currentModel.codigo ?? '';
    nomeController.text = currentModel.nome ?? '';
    descricaoController.text = currentModel.descricao ?? '';
    padraoController.selected = currentModel.padrao ?? 'Sim';
    descontarHorasController.selected = currentModel.descontarHoras ?? 'Sim';
    formWasChanged = false;
  }

  @override
  Future<void> save() async {
    if (!formKey.currentState!.validate()) {
      showErrorSnackBar(message: 'validator_form_message'.tr);
      return;
    }

    final existingIndex = modelList.indexWhere((m) => m.id == currentModel.id);

    if (existingIndex >= 0) {
      modelList[existingIndex] = currentModel.clone();
    }

    final result = await repository.save(pontoClassificacaoJornadaModel: currentModel);
    if (result == null) return;

    if (existingIndex >= 0) {
      modelList[existingIndex] = result;
    } else {
      modelList.insert(0, result);
    }

    if (!GetPlatform.isMobile) {
      updateGridRow(result);
    }

    Get.back(result: true);
  }


  @override
  void onClose() {
    codigoController.dispose();
    nomeController.dispose();
    descricaoController.dispose();
    padraoController.dispose();
    descontarHorasController.dispose();
    super.onClose();
  }

}