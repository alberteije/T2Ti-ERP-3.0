abstract class Routes{
	
	static const splashPage = '/splashPage';
	static const loginPage = '/loginPage';
	static const homePage = '/homePage';
	static const filterPage = '/filterPage';
	static const lookupPage = '/lookupPage';
  static const menuModulesPage = '/menuModulesPage';
		
	static const pontoEscalaListPage = '/pontoEscalaListPage'; 
	static const pontoEscalaTabPage = '/pontoEscalaTabPage';
	static const pontoBancoHorasListPage = '/pontoBancoHorasListPage'; 
	static const pontoBancoHorasTabPage = '/pontoBancoHorasTabPage';
	static const pontoAbonoListPage = '/pontoAbonoListPage'; 
	static const pontoAbonoTabPage = '/pontoAbonoTabPage';
	static const pontoParametroListPage = '/pontoParametroListPage'; 
	static const pontoParametroEditPage = '/pontoParametroEditPage';
	static const pontoHorarioListPage = '/pontoHorarioListPage'; 
	static const pontoHorarioEditPage = '/pontoHorarioEditPage';
	static const pontoRelogioListPage = '/pontoRelogioListPage'; 
	static const pontoRelogioEditPage = '/pontoRelogioEditPage';
	static const pontoClassificacaoJornadaListPage = '/pontoClassificacaoJornadaListPage'; 
	static const pontoClassificacaoJornadaEditPage = '/pontoClassificacaoJornadaEditPage';
	static const pontoHorarioAutorizadoListPage = '/pontoHorarioAutorizadoListPage'; 
	static const pontoHorarioAutorizadoEditPage = '/pontoHorarioAutorizadoEditPage';
	static const pontoFechamentoJornadaListPage = '/pontoFechamentoJornadaListPage'; 
	static const pontoFechamentoJornadaEditPage = '/pontoFechamentoJornadaEditPage';
}