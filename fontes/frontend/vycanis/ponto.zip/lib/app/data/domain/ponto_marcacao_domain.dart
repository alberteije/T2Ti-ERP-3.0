class PontoMarcacaoDomain {
  PontoMarcacaoDomain._();

  static getTipoMarcacao(String? tipoMarcacao) { 
		switch (tipoMarcacao) { 
			case '': 
			case 'E': 
				return 'Entrada'; 
			case 'S': 
				return 'Saída'; 
			case 'D': 
				return 'Desconsiderar'; 
			default: 
				return null; 
		} 
	} 

  static setTipoMarcacao(String? tipoMarcacao) { 
		switch (tipoMarcacao) { 
			case 'Entrada': 
				return 'E'; 
			case 'Saída': 
				return 'S'; 
			case 'Desconsiderar': 
				return 'D'; 
			default: 
				return null; 
		} 
	}

  static getTipoRegistro(String? tipoRegistro) { 
		switch (tipoRegistro) { 
			case '': 
			case '0': 
				return '0=Original'; 
			case '1': 
				return '1=Incluído por digitação'; 
			case '2': 
				return '2=Intervalo pré-assinalado'; 
			default: 
				return null; 
		} 
	} 

  static setTipoRegistro(String? tipoRegistro) { 
		switch (tipoRegistro) { 
			case '0=Original': 
				return '0'; 
			case '1=Incluído por digitação': 
				return '1'; 
			case '2=Intervalo pré-assinalado': 
				return '2'; 
			default: 
				return null; 
		} 
	}


  static final tipoMarcacaoListDropdown = ['Entrada','Saída','Desconsiderar'];
  static final tipoRegistroListDropdown = ['0=Original','1=Incluído por digitação','2=Intervalo pré-assinalado'];

}