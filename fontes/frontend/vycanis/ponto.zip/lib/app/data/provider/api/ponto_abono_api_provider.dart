import 'package:ponto/app/data/provider/api/api_provider_base.dart';
import 'package:ponto/app/data/model/model_imports.dart';

class PontoAbonoApiProvider extends ApiProviderBase {
  static const _path = '/ponto-abono';

  Future<List<PontoAbonoModel>?> getList({Filter? filter}) {
    return super.getListBase(
      '$_path/',
      (json) => PontoAbonoModel.fromJson(json),
      filter: filter,
    );
  }

  Future<PontoAbonoModel?> getObject(dynamic pk) {
    return super.getObjectBase(
      _path,
      pk,
      (json) => PontoAbonoModel.fromJson(json),
    );
  }

  Future<PontoAbonoModel?>? insert(PontoAbonoModel model) {
    return super.insertBase(
      _path,
      model,
      (json) => PontoAbonoModel.fromJson(json),
    );
  }

  Future<PontoAbonoModel?>? update(PontoAbonoModel model) {
    return super.updateBase(
      _path,
      model,
      (json) => PontoAbonoModel.fromJson(json),
    );
  }

  Future<bool?> delete(dynamic pk) {
    return super.deleteBase(_path, pk);
  }
}
