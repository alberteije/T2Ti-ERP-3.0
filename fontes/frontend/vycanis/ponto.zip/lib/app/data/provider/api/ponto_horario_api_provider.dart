import 'package:ponto/app/data/provider/api/api_provider_base.dart';
import 'package:ponto/app/data/model/model_imports.dart';

class PontoHorarioApiProvider extends ApiProviderBase {
  static const _path = '/ponto-horario';

  Future<List<PontoHorarioModel>?> getList({Filter? filter}) {
    return super.getListBase(
      '$_path/',
      (json) => PontoHorarioModel.fromJson(json),
      filter: filter,
    );
  }

  Future<PontoHorarioModel?> getObject(dynamic pk) {
    return super.getObjectBase(
      _path,
      pk,
      (json) => PontoHorarioModel.fromJson(json),
    );
  }

  Future<PontoHorarioModel?>? insert(PontoHorarioModel model) {
    return super.insertBase(
      _path,
      model,
      (json) => PontoHorarioModel.fromJson(json),
    );
  }

  Future<PontoHorarioModel?>? update(PontoHorarioModel model) {
    return super.updateBase(
      _path,
      model,
      (json) => PontoHorarioModel.fromJson(json),
    );
  }

  Future<bool?> delete(dynamic pk) {
    return super.deleteBase(_path, pk);
  }
}
