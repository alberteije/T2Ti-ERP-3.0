import 'package:ponto/app/data/provider/api/api_provider_base.dart';
import 'package:ponto/app/data/model/model_imports.dart';

class PontoFechamentoJornadaApiProvider extends ApiProviderBase {
  static const _path = '/ponto-fechamento-jornada';

  Future<List<PontoFechamentoJornadaModel>?> getList({Filter? filter}) {
    return super.getListBase(
      '$_path/',
      (json) => PontoFechamentoJornadaModel.fromJson(json),
      filter: filter,
    );
  }

  Future<PontoFechamentoJornadaModel?> getObject(dynamic pk) {
    return super.getObjectBase(
      _path,
      pk,
      (json) => PontoFechamentoJornadaModel.fromJson(json),
    );
  }

  Future<PontoFechamentoJornadaModel?>? insert(PontoFechamentoJornadaModel model) {
    return super.insertBase(
      _path,
      model,
      (json) => PontoFechamentoJornadaModel.fromJson(json),
    );
  }

  Future<PontoFechamentoJornadaModel?>? update(PontoFechamentoJornadaModel model) {
    return super.updateBase(
      _path,
      model,
      (json) => PontoFechamentoJornadaModel.fromJson(json),
    );
  }

  Future<bool?> delete(dynamic pk) {
    return super.deleteBase(_path, pk);
  }
}
