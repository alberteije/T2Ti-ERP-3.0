import 'package:ponto/app/data/provider/api/api_provider_base.dart';
import 'package:ponto/app/data/model/model_imports.dart';

class PontoEscalaApiProvider extends ApiProviderBase {
  static const _path = '/ponto-escala';

  Future<List<PontoEscalaModel>?> getList({Filter? filter}) {
    return super.getListBase(
      '$_path/',
      (json) => PontoEscalaModel.fromJson(json),
      filter: filter,
    );
  }

  Future<PontoEscalaModel?> getObject(dynamic pk) {
    return super.getObjectBase(
      _path,
      pk,
      (json) => PontoEscalaModel.fromJson(json),
    );
  }

  Future<PontoEscalaModel?>? insert(PontoEscalaModel model) {
    return super.insertBase(
      _path,
      model,
      (json) => PontoEscalaModel.fromJson(json),
    );
  }

  Future<PontoEscalaModel?>? update(PontoEscalaModel model) {
    return super.updateBase(
      _path,
      model,
      (json) => PontoEscalaModel.fromJson(json),
    );
  }

  Future<bool?> delete(dynamic pk) {
    return super.deleteBase(_path, pk);
  }
}
