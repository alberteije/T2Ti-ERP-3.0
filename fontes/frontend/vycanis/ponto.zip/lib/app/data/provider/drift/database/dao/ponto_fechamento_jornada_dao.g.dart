// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'ponto_fechamento_jornada_dao.dart';

// ignore_for_file: type=lint
mixin _$PontoFechamentoJornadaDaoMixin on DatabaseAccessor<AppDatabase> {
  $PontoFechamentoJornadasTable get pontoFechamentoJornadas =>
      attachedDatabase.pontoFechamentoJornadas;
  $ViewPessoaColaboradorsTable get viewPessoaColaboradors =>
      attachedDatabase.viewPessoaColaboradors;
  $PontoClassificacaoJornadasTable get pontoClassificacaoJornadas =>
      attachedDatabase.pontoClassificacaoJornadas;
}
