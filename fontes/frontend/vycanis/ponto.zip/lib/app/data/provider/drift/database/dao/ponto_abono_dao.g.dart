// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'ponto_abono_dao.dart';

// ignore_for_file: type=lint
mixin _$PontoAbonoDaoMixin on DatabaseAccessor<AppDatabase> {
  $PontoAbonosTable get pontoAbonos => attachedDatabase.pontoAbonos;
  $PontoAbonoUtilizacaosTable get pontoAbonoUtilizacaos =>
      attachedDatabase.pontoAbonoUtilizacaos;
  $ViewPessoaColaboradorsTable get viewPessoaColaboradors =>
      attachedDatabase.viewPessoaColaboradors;
}
