// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'ponto_relogio_dao.dart';

// ignore_for_file: type=lint
mixin _$PontoRelogioDaoMixin on DatabaseAccessor<AppDatabase> {
  $PontoRelogiosTable get pontoRelogios => attachedDatabase.pontoRelogios;
}
