// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'ponto_marcacao_dao.dart';

// ignore_for_file: type=lint
mixin _$PontoMarcacaoDaoMixin on DatabaseAccessor<AppDatabase> {
  $PontoMarcacaosTable get pontoMarcacaos => attachedDatabase.pontoMarcacaos;
  $ViewPessoaColaboradorsTable get viewPessoaColaboradors =>
      attachedDatabase.viewPessoaColaboradors;
  $PontoRelogiosTable get pontoRelogios => attachedDatabase.pontoRelogios;
}
