// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'ponto_escala_dao.dart';

// ignore_for_file: type=lint
mixin _$PontoEscalaDaoMixin on DatabaseAccessor<AppDatabase> {
  $PontoEscalasTable get pontoEscalas => attachedDatabase.pontoEscalas;
  $PontoTurmasTable get pontoTurmas => attachedDatabase.pontoTurmas;
}
