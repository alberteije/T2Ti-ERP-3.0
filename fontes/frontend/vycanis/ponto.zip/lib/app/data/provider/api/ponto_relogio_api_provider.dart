import 'package:ponto/app/data/provider/api/api_provider_base.dart';
import 'package:ponto/app/data/model/model_imports.dart';

class PontoRelogioApiProvider extends ApiProviderBase {
  static const _path = '/ponto-relogio';

  Future<List<PontoRelogioModel>?> getList({Filter? filter}) {
    return super.getListBase(
      '$_path/',
      (json) => PontoRelogioModel.fromJson(json),
      filter: filter,
    );
  }

  Future<PontoRelogioModel?> getObject(dynamic pk) {
    return super.getObjectBase(
      _path,
      pk,
      (json) => PontoRelogioModel.fromJson(json),
    );
  }

  Future<PontoRelogioModel?>? insert(PontoRelogioModel model) {
    return super.insertBase(
      _path,
      model,
      (json) => PontoRelogioModel.fromJson(json),
    );
  }

  Future<PontoRelogioModel?>? update(PontoRelogioModel model) {
    return super.updateBase(
      _path,
      model,
      (json) => PontoRelogioModel.fromJson(json),
    );
  }

  Future<bool?> delete(dynamic pk) {
    return super.deleteBase(_path, pk);
  }
}
