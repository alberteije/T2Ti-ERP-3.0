import 'package:ponto/app/data/provider/api/api_provider_base.dart';
import 'package:ponto/app/data/model/model_imports.dart';

class PontoClassificacaoJornadaApiProvider extends ApiProviderBase {
  static const _path = '/ponto-classificacao-jornada';

  Future<List<PontoClassificacaoJornadaModel>?> getList({Filter? filter}) {
    return super.getListBase(
      '$_path/',
      (json) => PontoClassificacaoJornadaModel.fromJson(json),
      filter: filter,
    );
  }

  Future<PontoClassificacaoJornadaModel?> getObject(dynamic pk) {
    return super.getObjectBase(
      _path,
      pk,
      (json) => PontoClassificacaoJornadaModel.fromJson(json),
    );
  }

  Future<PontoClassificacaoJornadaModel?>? insert(PontoClassificacaoJornadaModel model) {
    return super.insertBase(
      _path,
      model,
      (json) => PontoClassificacaoJornadaModel.fromJson(json),
    );
  }

  Future<PontoClassificacaoJornadaModel?>? update(PontoClassificacaoJornadaModel model) {
    return super.updateBase(
      _path,
      model,
      (json) => PontoClassificacaoJornadaModel.fromJson(json),
    );
  }

  Future<bool?> delete(dynamic pk) {
    return super.deleteBase(_path, pk);
  }
}
