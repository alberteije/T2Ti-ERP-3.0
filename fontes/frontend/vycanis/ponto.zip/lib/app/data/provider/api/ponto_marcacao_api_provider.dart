import 'dart:convert';

import 'package:ponto/app/data/provider/api/api_provider_base.dart';
import 'package:ponto/app/data/model/model_imports.dart';

class PontoMarcacaoApiProvider extends ApiProviderBase {
  static const _path = '/ponto-marcacao';

  Future<List<PontoMarcacaoModel>?> getList({Filter? filter}) {
    return super.getListBase(
      '$_path/',
      (json) => PontoMarcacaoModel.fromJson(json),
      filter: filter,
    );
  }

  Future<PontoMarcacaoModel?> getObject(dynamic pk) {
    return super.getObjectBase(
      _path,
      pk,
      (json) => PontoMarcacaoModel.fromJson(json),
    );
  }

  Future<PontoMarcacaoModel?>? insert(PontoMarcacaoModel model) {
    return super.insertBase(
      _path,
      model,
      (json) => PontoMarcacaoModel.fromJson(json),
    );
  }

  Future<PontoMarcacaoModel?>? update(PontoMarcacaoModel model) {
    return super.updateBase(
      _path,
      model,
      (json) => PontoMarcacaoModel.fromJson(json),
    );
  }

  Future<bool?> delete(dynamic pk) {
    return super.deleteBase(_path, pk);
  }


  Future<bool?> saveBatch(List<PontoMarcacaoModel> marcacoes) async {
    try {
      final response = await ApiProviderBase.httpClient.post(
        Uri.tryParse('$endpoint/ponto-marcacao/batch')!,
        headers: ApiProviderBase.headerRequisition(),
        body: jsonEncode({'marcacoes': marcacoes.map((e) => e.toJson).toList(),}),
      );

      if (response.statusCode == 200 || response.statusCode == 201) {
        if (response.headers["content-type"]!.contains("html")) {
          handleResultError(response.body, response.headers);
          return null;
        } else {
          return true;
        }
      } else {
        handleResultError(response.body, response.headers);
        return null;
      }
    } on Exception catch (e) {
      handleResultError(null, null, exception: e);
      return null;
    }
  }
}
