import 'package:ponto/app/data/provider/api/api_provider_base.dart';
import 'package:ponto/app/data/model/model_imports.dart';

class PontoBancoHorasApiProvider extends ApiProviderBase {
  static const _path = '/ponto-banco-horas';

  Future<List<PontoBancoHorasModel>?> getList({Filter? filter}) {
    return super.getListBase(
      '$_path/',
      (json) => PontoBancoHorasModel.fromJson(json),
      filter: filter,
    );
  }

  Future<PontoBancoHorasModel?> getObject(dynamic pk) {
    return super.getObjectBase(
      _path,
      pk,
      (json) => PontoBancoHorasModel.fromJson(json),
    );
  }

  Future<PontoBancoHorasModel?>? insert(PontoBancoHorasModel model) {
    return super.insertBase(
      _path,
      model,
      (json) => PontoBancoHorasModel.fromJson(json),
    );
  }

  Future<PontoBancoHorasModel?>? update(PontoBancoHorasModel model) {
    return super.updateBase(
      _path,
      model,
      (json) => PontoBancoHorasModel.fromJson(json),
    );
  }

  Future<bool?> delete(dynamic pk) {
    return super.deleteBase(_path, pk);
  }
}
