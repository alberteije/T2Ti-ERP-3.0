import 'package:ponto/app/data/provider/api/api_provider_base.dart';
import 'package:ponto/app/data/model/model_imports.dart';

class PontoParametroApiProvider extends ApiProviderBase {
  static const _path = '/ponto-parametro';

  Future<List<PontoParametroModel>?> getList({Filter? filter}) {
    return super.getListBase(
      '$_path/',
      (json) => PontoParametroModel.fromJson(json),
      filter: filter,
    );
  }

  Future<PontoParametroModel?> getObject(dynamic pk) {
    return super.getObjectBase(
      _path,
      pk,
      (json) => PontoParametroModel.fromJson(json),
    );
  }

  Future<PontoParametroModel?>? insert(PontoParametroModel model) {
    return super.insertBase(
      _path,
      model,
      (json) => PontoParametroModel.fromJson(json),
    );
  }

  Future<PontoParametroModel?>? update(PontoParametroModel model) {
    return super.updateBase(
      _path,
      model,
      (json) => PontoParametroModel.fromJson(json),
    );
  }

  Future<bool?> delete(dynamic pk) {
    return super.deleteBase(_path, pk);
  }
}
