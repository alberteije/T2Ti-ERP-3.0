import 'package:ponto/app/data/provider/api/api_provider_base.dart';
import 'package:ponto/app/data/model/model_imports.dart';

class PontoHorarioAutorizadoApiProvider extends ApiProviderBase {
  static const _path = '/ponto-horario-autorizado';

  Future<List<PontoHorarioAutorizadoModel>?> getList({Filter? filter}) {
    return super.getListBase(
      '$_path/',
      (json) => PontoHorarioAutorizadoModel.fromJson(json),
      filter: filter,
    );
  }

  Future<PontoHorarioAutorizadoModel?> getObject(dynamic pk) {
    return super.getObjectBase(
      _path,
      pk,
      (json) => PontoHorarioAutorizadoModel.fromJson(json),
    );
  }

  Future<PontoHorarioAutorizadoModel?>? insert(PontoHorarioAutorizadoModel model) {
    return super.insertBase(
      _path,
      model,
      (json) => PontoHorarioAutorizadoModel.fromJson(json),
    );
  }

  Future<PontoHorarioAutorizadoModel?>? update(PontoHorarioAutorizadoModel model) {
    return super.updateBase(
      _path,
      model,
      (json) => PontoHorarioAutorizadoModel.fromJson(json),
    );
  }

  Future<bool?> delete(dynamic pk) {
    return super.deleteBase(_path, pk);
  }
}
