// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'ponto_horario_dao.dart';

// ignore_for_file: type=lint
mixin _$PontoHorarioDaoMixin on DatabaseAccessor<AppDatabase> {
  $PontoHorariosTable get pontoHorarios => attachedDatabase.pontoHorarios;
}
