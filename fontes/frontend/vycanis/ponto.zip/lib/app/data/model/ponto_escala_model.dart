import 'dart:convert';
import 'package:pluto_grid/pluto_grid.dart';
import 'package:ponto/app/data/model/model_imports.dart';

import 'package:ponto/app/infra/infra_imports.dart';

class PontoEscalaModel extends ModelBase {
  int? id;
  String? nome;
  String? descontoHoraDia;
  String? descontoDsr;
  String? codigoHorarioDomingo;
  String? codigoHorarioSegunda;
  String? codigoHorarioTerca;
  String? codigoHorarioQuarta;
  String? codigoHorarioQuinta;
  String? codigoHorarioSexta;
  String? codigoHorarioSabado;
  List<PontoTurmaModel>? pontoTurmaModelList;

  PontoEscalaModel({
    this.id,
    this.nome,
    this.descontoHoraDia,
    this.descontoDsr,
    this.codigoHorarioDomingo,
    this.codigoHorarioSegunda,
    this.codigoHorarioTerca,
    this.codigoHorarioQuarta,
    this.codigoHorarioQuinta,
    this.codigoHorarioSexta,
    this.codigoHorarioSabado,
    List<PontoTurmaModel>? pontoTurmaModelList,
  }) {
    this.pontoTurmaModelList = pontoTurmaModelList?.toList(growable: true) ?? [];
  }

  static List<String> dbColumns = <String>[
    'id',
    'nome',
    'desconto_hora_dia',
    'desconto_dsr',
    'codigo_horario_domingo',
    'codigo_horario_segunda',
    'codigo_horario_terca',
    'codigo_horario_quarta',
    'codigo_horario_quinta',
    'codigo_horario_sexta',
    'codigo_horario_sabado',
  ];

  static List<String> aliasColumns = <String>[
    'Id',
    'Nome',
    'Desconto Hora Dia',
    'Desconto Dsr',
    'Codigo Horario Domingo',
    'Codigo Horario Segunda',
    'Codigo Horario Terca',
    'Codigo Horario Quarta',
    'Codigo Horario Quinta',
    'Codigo Horario Sexta',
    'Codigo Horario Sabado',
  ];

  PontoEscalaModel.fromJson(Map<String, dynamic> jsonData) {
    id = jsonData['id'];
    nome = jsonData['nome'];
    descontoHoraDia = jsonData['descontoHoraDia'];
    descontoDsr = jsonData['descontoDsr'];
    codigoHorarioDomingo = jsonData['codigoHorarioDomingo'];
    codigoHorarioSegunda = jsonData['codigoHorarioSegunda'];
    codigoHorarioTerca = jsonData['codigoHorarioTerca'];
    codigoHorarioQuarta = jsonData['codigoHorarioQuarta'];
    codigoHorarioQuinta = jsonData['codigoHorarioQuinta'];
    codigoHorarioSexta = jsonData['codigoHorarioSexta'];
    codigoHorarioSabado = jsonData['codigoHorarioSabado'];
    pontoTurmaModelList = (jsonData['pontoTurmaModelList'] as Iterable?)?.map((m) => PontoTurmaModel.fromJson(m)).toList() ?? [];
  }

  Map<String, dynamic> get toJson {
    Map<String, dynamic> jsonData = <String, dynamic>{};

    jsonData['id'] = id != 0 ? id : null;
    jsonData['nome'] = nome;
    jsonData['descontoHoraDia'] = Util.removeMask(descontoHoraDia);
    jsonData['descontoDsr'] = Util.removeMask(descontoDsr);
    jsonData['codigoHorarioDomingo'] = codigoHorarioDomingo;
    jsonData['codigoHorarioSegunda'] = codigoHorarioSegunda;
    jsonData['codigoHorarioTerca'] = codigoHorarioTerca;
    jsonData['codigoHorarioQuarta'] = codigoHorarioQuarta;
    jsonData['codigoHorarioQuinta'] = codigoHorarioQuinta;
    jsonData['codigoHorarioSexta'] = codigoHorarioSexta;
    jsonData['codigoHorarioSabado'] = codigoHorarioSabado;
    
		var pontoTurmaModelLocalList = []; 
		for (PontoTurmaModel object in pontoTurmaModelList ?? []) { 
			pontoTurmaModelLocalList.add(object.toJson); 
		}
		jsonData['pontoTurmaModelList'] = pontoTurmaModelLocalList;

    return jsonData;
  }

  String objectEncodeJson() {
    final jsonData = toJson;
    return json.encode(jsonData);
  }

  static PontoEscalaModel fromPlutoRow(PlutoRow row) {
    return PontoEscalaModel(
      id: row.cells['id']?.value,
      nome: row.cells['nome']?.value,
      descontoHoraDia: row.cells['descontoHoraDia']?.value,
      descontoDsr: row.cells['descontoDsr']?.value,
      codigoHorarioDomingo: row.cells['codigoHorarioDomingo']?.value,
      codigoHorarioSegunda: row.cells['codigoHorarioSegunda']?.value,
      codigoHorarioTerca: row.cells['codigoHorarioTerca']?.value,
      codigoHorarioQuarta: row.cells['codigoHorarioQuarta']?.value,
      codigoHorarioQuinta: row.cells['codigoHorarioQuinta']?.value,
      codigoHorarioSexta: row.cells['codigoHorarioSexta']?.value,
      codigoHorarioSabado: row.cells['codigoHorarioSabado']?.value,
    );
  }

  PlutoRow toPlutoRow() {
    return PlutoRow(
      cells: {
        'tempId': PlutoCell(value: tempId),
        'id': PlutoCell(value: id ?? 0),
        'nome': PlutoCell(value: nome ?? ''),
        'descontoHoraDia': PlutoCell(value: descontoHoraDia ?? ''),
        'descontoDsr': PlutoCell(value: descontoDsr ?? ''),
        'codigoHorarioDomingo': PlutoCell(value: codigoHorarioDomingo ?? ''),
        'codigoHorarioSegunda': PlutoCell(value: codigoHorarioSegunda ?? ''),
        'codigoHorarioTerca': PlutoCell(value: codigoHorarioTerca ?? ''),
        'codigoHorarioQuarta': PlutoCell(value: codigoHorarioQuarta ?? ''),
        'codigoHorarioQuinta': PlutoCell(value: codigoHorarioQuinta ?? ''),
        'codigoHorarioSexta': PlutoCell(value: codigoHorarioSexta ?? ''),
        'codigoHorarioSabado': PlutoCell(value: codigoHorarioSabado ?? ''),
      },
    );
  }

  PontoEscalaModel clone() {
    return PontoEscalaModel(
      id: id,
      nome: nome,
      descontoHoraDia: descontoHoraDia,
      descontoDsr: descontoDsr,
      codigoHorarioDomingo: codigoHorarioDomingo,
      codigoHorarioSegunda: codigoHorarioSegunda,
      codigoHorarioTerca: codigoHorarioTerca,
      codigoHorarioQuarta: codigoHorarioQuarta,
      codigoHorarioQuinta: codigoHorarioQuinta,
      codigoHorarioSexta: codigoHorarioSexta,
      codigoHorarioSabado: codigoHorarioSabado,
      pontoTurmaModelList: pontoTurmaModelListClone(pontoTurmaModelList!),
    );
  }

  pontoTurmaModelListClone(List<PontoTurmaModel> pontoTurmaModelList) { 
		List<PontoTurmaModel> resultList = [];
		for (var pontoTurmaModel in pontoTurmaModelList) {
			resultList.add(pontoTurmaModel.clone());
		}
		return resultList;
	}


}