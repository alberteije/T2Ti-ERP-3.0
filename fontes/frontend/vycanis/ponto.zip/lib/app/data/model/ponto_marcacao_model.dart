import 'dart:convert';
import 'package:pluto_grid/pluto_grid.dart';
import 'package:ponto/app/data/model/model_imports.dart';

import 'package:ponto/app/infra/infra_imports.dart';
import 'package:intl/intl.dart';
import 'package:ponto/app/data/domain/domain_imports.dart';

class PontoMarcacaoModel extends ModelBase {
  int? id;
  int? idPontoRelogio;
  int? idColaborador;
  int? nsr;
  DateTime? dataMarcacao;
  String? horaMarcacao;
  String? tipoMarcacao;
  String? tipoRegistro;
  String? parEntradaSaida;
  String? justificativa;
  ViewPessoaColaboradorModel? viewPessoaColaboradorModel;
  PontoRelogioModel? pontoRelogioModel;

  PontoMarcacaoModel({
    this.id,
    this.idPontoRelogio,
    this.idColaborador,
    this.nsr,
    this.dataMarcacao,
    this.horaMarcacao,
    this.tipoMarcacao = 'Entrada',
    this.tipoRegistro = '0=Original',
    this.parEntradaSaida,
    this.justificativa,
    ViewPessoaColaboradorModel? viewPessoaColaboradorModel,
    PontoRelogioModel? pontoRelogioModel,
  }) {
    this.viewPessoaColaboradorModel = viewPessoaColaboradorModel ?? ViewPessoaColaboradorModel();
    this.pontoRelogioModel = pontoRelogioModel ?? PontoRelogioModel();
  }

  static List<String> dbColumns = <String>[
    'id',
    'nsr',
    'data_marcacao',
    'hora_marcacao',
    'tipo_marcacao',
    'tipo_registro',
    'par_entrada_saida',
    'justificativa',
  ];

  static List<String> aliasColumns = <String>[
    'Id',
    'Nsr',
    'Data Marcacao',
    'Hora Marcacao',
    'Tipo Marcacao',
    'Tipo Registro',
    'Par Entrada Saida',
    'Justificativa',
  ];

  PontoMarcacaoModel.fromJson(Map<String, dynamic> jsonData) {
    id = jsonData['id'];
    idPontoRelogio = jsonData['idPontoRelogio'];
    idColaborador = jsonData['idColaborador'];
    nsr = jsonData['nsr'];
    dataMarcacao = jsonData['dataMarcacao'] != null ? DateTime.tryParse(jsonData['dataMarcacao']) : null;
    horaMarcacao = jsonData['horaMarcacao'];
    tipoMarcacao = PontoMarcacaoDomain.getTipoMarcacao(jsonData['tipoMarcacao']);
    tipoRegistro = PontoMarcacaoDomain.getTipoRegistro(jsonData['tipoRegistro']);
    parEntradaSaida = jsonData['parEntradaSaida'];
    justificativa = jsonData['justificativa'];
    viewPessoaColaboradorModel = jsonData['viewPessoaColaboradorModel'] == null ? ViewPessoaColaboradorModel() : ViewPessoaColaboradorModel.fromJson(jsonData['viewPessoaColaboradorModel']);
    pontoRelogioModel = jsonData['pontoRelogioModel'] == null ? PontoRelogioModel() : PontoRelogioModel.fromJson(jsonData['pontoRelogioModel']);
  }

  Map<String, dynamic> get toJson {
    Map<String, dynamic> jsonData = <String, dynamic>{};

    jsonData['id'] = id != 0 ? id : null;
    jsonData['idPontoRelogio'] = idPontoRelogio != 0 ? idPontoRelogio : null;
    jsonData['idColaborador'] = idColaborador != 0 ? idColaborador : null;
    jsonData['nsr'] = nsr;
    jsonData['dataMarcacao'] = dataMarcacao != null ? DateFormat('yyyy-MM-ddT00:00:00').format(dataMarcacao!) : null;
    jsonData['horaMarcacao'] = Util.removeMask(horaMarcacao);
    jsonData['tipoMarcacao'] = PontoMarcacaoDomain.setTipoMarcacao(tipoMarcacao);
    jsonData['tipoRegistro'] = PontoMarcacaoDomain.setTipoRegistro(tipoRegistro);
    jsonData['parEntradaSaida'] = parEntradaSaida;
    jsonData['justificativa'] = justificativa;
    jsonData['viewPessoaColaboradorModel'] = viewPessoaColaboradorModel?.toJson;
    jsonData['viewPessoaColaborador'] = viewPessoaColaboradorModel?.nome ?? '';
    jsonData['pontoRelogioModel'] = pontoRelogioModel?.toJson;
    jsonData['pontoRelogio'] = pontoRelogioModel?.numeroSerie ?? '';

    return jsonData;
  }

  String objectEncodeJson() {
    final jsonData = toJson;
    return json.encode(jsonData);
  }

  static PontoMarcacaoModel fromPlutoRow(PlutoRow row) {
    return PontoMarcacaoModel(
      id: row.cells['id']?.value,
      idPontoRelogio: row.cells['idPontoRelogio']?.value,
      idColaborador: row.cells['idColaborador']?.value,
      nsr: row.cells['nsr']?.value,
      dataMarcacao: Util.stringToDate(row.cells['dataMarcacao']?.value),
      horaMarcacao: row.cells['horaMarcacao']?.value,
      tipoMarcacao: row.cells['tipoMarcacao']?.value,
      tipoRegistro: row.cells['tipoRegistro']?.value,
      parEntradaSaida: row.cells['parEntradaSaida']?.value,
      justificativa: row.cells['justificativa']?.value,
    );
  }

  PlutoRow toPlutoRow() {
    return PlutoRow(
      cells: {
        'tempId': PlutoCell(value: tempId),
        'id': PlutoCell(value: id ?? 0),
        'idPontoRelogio': PlutoCell(value: idPontoRelogio ?? 0),
        'idColaborador': PlutoCell(value: idColaborador ?? 0),
        'nsr': PlutoCell(value: nsr ?? 0),
        'dataMarcacao': PlutoCell(value: dataMarcacao),
        'horaMarcacao': PlutoCell(value: horaMarcacao ?? ''),
        'tipoMarcacao': PlutoCell(value: tipoMarcacao ?? ''),
        'tipoRegistro': PlutoCell(value: tipoRegistro ?? ''),
        'parEntradaSaida': PlutoCell(value: parEntradaSaida ?? ''),
        'justificativa': PlutoCell(value: justificativa ?? ''),
        'viewPessoaColaborador': PlutoCell(value: viewPessoaColaboradorModel?.nome ?? ''),
        'pontoRelogio': PlutoCell(value: pontoRelogioModel?.numeroSerie ?? ''),
      },
    );
  }

  PontoMarcacaoModel clone() {
    return PontoMarcacaoModel(
      id: id,
      idPontoRelogio: idPontoRelogio,
      idColaborador: idColaborador,
      nsr: nsr,
      dataMarcacao: dataMarcacao,
      horaMarcacao: horaMarcacao,
      tipoMarcacao: tipoMarcacao,
      tipoRegistro: tipoRegistro,
      parEntradaSaida: parEntradaSaida,
      justificativa: justificativa,
      viewPessoaColaboradorModel: viewPessoaColaboradorModel?.clone(),
      pontoRelogioModel: pontoRelogioModel?.clone(),
    );
  }


}