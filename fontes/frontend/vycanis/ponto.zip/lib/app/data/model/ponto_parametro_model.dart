import 'dart:convert';
import 'package:pluto_grid/pluto_grid.dart';
import 'package:ponto/app/data/model/model_imports.dart';

import 'package:ponto/app/infra/infra_imports.dart';
import 'package:ponto/app/data/domain/domain_imports.dart';

class PontoParametroModel extends ModelBase {
  int? id;
  String? mesAno;
  int? diaInicialApuracao;
  String? horaNoturnaInicio;
  String? horaNoturnaFim;
  String? periodoMinimoInterjornada;
  double? percentualHeDiurna;
  double? percentualHeNoturna;
  String? duracaoHoraNoturna;
  String? tratamentoHoraMais;
  String? tratamentoHoraMenos;

  PontoParametroModel({
    this.id,
    this.mesAno,
    this.diaInicialApuracao,
    this.horaNoturnaInicio,
    this.horaNoturnaFim,
    this.periodoMinimoInterjornada,
    this.percentualHeDiurna,
    this.percentualHeNoturna,
    this.duracaoHoraNoturna,
    this.tratamentoHoraMais = 'Extra',
    this.tratamentoHoraMenos = 'Falta',
  });

  static List<String> dbColumns = <String>[
    'id',
    'mes_ano',
    'dia_inicial_apuracao',
    'hora_noturna_inicio',
    'hora_noturna_fim',
    'periodo_minimo_interjornada',
    'percentual_he_diurna',
    'percentual_he_noturna',
    'duracao_hora_noturna',
    'tratamento_hora_mais',
    'tratamento_hora_menos',
  ];

  static List<String> aliasColumns = <String>[
    'Id',
    'Mes Ano',
    'Dia Inicial Apuracao',
    'Hora Noturna Inicio',
    'Hora Noturna Fim',
    'Periodo Minimo Interjornada',
    'Percentual He Diurna',
    'Percentual He Noturna',
    'Duracao Hora Noturna',
    'Tratamento Hora Mais',
    'Tratamento Hora Menos',
  ];

  PontoParametroModel.fromJson(Map<String, dynamic> jsonData) {
    id = jsonData['id'];
    mesAno = jsonData['mesAno'];
    diaInicialApuracao = jsonData['diaInicialApuracao'];
    horaNoturnaInicio = jsonData['horaNoturnaInicio'];
    horaNoturnaFim = jsonData['horaNoturnaFim'];
    periodoMinimoInterjornada = jsonData['periodoMinimoInterjornada'];
    percentualHeDiurna = jsonData['percentualHeDiurna']?.toDouble();
    percentualHeNoturna = jsonData['percentualHeNoturna']?.toDouble();
    duracaoHoraNoturna = jsonData['duracaoHoraNoturna'];
    tratamentoHoraMais = PontoParametroDomain.getTratamentoHoraMais(jsonData['tratamentoHoraMais']);
    tratamentoHoraMenos = PontoParametroDomain.getTratamentoHoraMenos(jsonData['tratamentoHoraMenos']);
  }

  Map<String, dynamic> get toJson {
    Map<String, dynamic> jsonData = <String, dynamic>{};

    jsonData['id'] = id != 0 ? id : null;
    jsonData['mesAno'] = Util.removeMask(mesAno);
    jsonData['diaInicialApuracao'] = diaInicialApuracao;
    jsonData['horaNoturnaInicio'] = Util.removeMask(horaNoturnaInicio);
    jsonData['horaNoturnaFim'] = Util.removeMask(horaNoturnaFim);
    jsonData['periodoMinimoInterjornada'] = Util.removeMask(periodoMinimoInterjornada);
    jsonData['percentualHeDiurna'] = percentualHeDiurna;
    jsonData['percentualHeNoturna'] = percentualHeNoturna;
    jsonData['duracaoHoraNoturna'] = Util.removeMask(duracaoHoraNoturna);
    jsonData['tratamentoHoraMais'] = PontoParametroDomain.setTratamentoHoraMais(tratamentoHoraMais);
    jsonData['tratamentoHoraMenos'] = PontoParametroDomain.setTratamentoHoraMenos(tratamentoHoraMenos);

    return jsonData;
  }

  String objectEncodeJson() {
    final jsonData = toJson;
    return json.encode(jsonData);
  }

  static PontoParametroModel fromPlutoRow(PlutoRow row) {
    return PontoParametroModel(
      id: row.cells['id']?.value,
      mesAno: row.cells['mesAno']?.value,
      diaInicialApuracao: row.cells['diaInicialApuracao']?.value,
      horaNoturnaInicio: row.cells['horaNoturnaInicio']?.value,
      horaNoturnaFim: row.cells['horaNoturnaFim']?.value,
      periodoMinimoInterjornada: row.cells['periodoMinimoInterjornada']?.value,
      percentualHeDiurna: row.cells['percentualHeDiurna']?.value,
      percentualHeNoturna: row.cells['percentualHeNoturna']?.value,
      duracaoHoraNoturna: row.cells['duracaoHoraNoturna']?.value,
      tratamentoHoraMais: row.cells['tratamentoHoraMais']?.value,
      tratamentoHoraMenos: row.cells['tratamentoHoraMenos']?.value,
    );
  }

  PlutoRow toPlutoRow() {
    return PlutoRow(
      cells: {
        'tempId': PlutoCell(value: tempId),
        'id': PlutoCell(value: id ?? 0),
        'mesAno': PlutoCell(value: mesAno ?? ''),
        'diaInicialApuracao': PlutoCell(value: diaInicialApuracao ?? 0),
        'horaNoturnaInicio': PlutoCell(value: horaNoturnaInicio ?? ''),
        'horaNoturnaFim': PlutoCell(value: horaNoturnaFim ?? ''),
        'periodoMinimoInterjornada': PlutoCell(value: periodoMinimoInterjornada ?? ''),
        'percentualHeDiurna': PlutoCell(value: percentualHeDiurna ?? 0.0),
        'percentualHeNoturna': PlutoCell(value: percentualHeNoturna ?? 0.0),
        'duracaoHoraNoturna': PlutoCell(value: duracaoHoraNoturna ?? ''),
        'tratamentoHoraMais': PlutoCell(value: tratamentoHoraMais ?? ''),
        'tratamentoHoraMenos': PlutoCell(value: tratamentoHoraMenos ?? ''),
      },
    );
  }

  PontoParametroModel clone() {
    return PontoParametroModel(
      id: id,
      mesAno: mesAno,
      diaInicialApuracao: diaInicialApuracao,
      horaNoturnaInicio: horaNoturnaInicio,
      horaNoturnaFim: horaNoturnaFim,
      periodoMinimoInterjornada: periodoMinimoInterjornada,
      percentualHeDiurna: percentualHeDiurna,
      percentualHeNoturna: percentualHeNoturna,
      duracaoHoraNoturna: duracaoHoraNoturna,
      tratamentoHoraMais: tratamentoHoraMais,
      tratamentoHoraMenos: tratamentoHoraMenos,
    );
  }


}