import 'dart:convert';
import 'package:pluto_grid/pluto_grid.dart';
import 'package:ponto/app/data/model/model_imports.dart';


class PontoTurmaModel extends ModelBase {
  int? id;
  int? idPontoEscala;
  String? codigo;
  String? nome;

  PontoTurmaModel({
    this.id,
    this.idPontoEscala,
    this.codigo,
    this.nome,
  });

  static List<String> dbColumns = <String>[
    'id',
    'codigo',
    'nome',
  ];

  static List<String> aliasColumns = <String>[
    'Id',
    'Codigo',
    'Nome',
  ];

  PontoTurmaModel.fromJson(Map<String, dynamic> jsonData) {
    id = jsonData['id'];
    idPontoEscala = jsonData['idPontoEscala'];
    codigo = jsonData['codigo'];
    nome = jsonData['nome'];
  }

  Map<String, dynamic> get toJson {
    Map<String, dynamic> jsonData = <String, dynamic>{};

    jsonData['id'] = id != 0 ? id : null;
    jsonData['idPontoEscala'] = idPontoEscala != 0 ? idPontoEscala : null;
    jsonData['codigo'] = codigo;
    jsonData['nome'] = nome;

    return jsonData;
  }

  String objectEncodeJson() {
    final jsonData = toJson;
    return json.encode(jsonData);
  }

  static PontoTurmaModel fromPlutoRow(PlutoRow row) {
    return PontoTurmaModel(
      id: row.cells['id']?.value,
      idPontoEscala: row.cells['idPontoEscala']?.value,
      codigo: row.cells['codigo']?.value,
      nome: row.cells['nome']?.value,
    );
  }

  PlutoRow toPlutoRow() {
    return PlutoRow(
      cells: {
        'tempId': PlutoCell(value: tempId),
        'id': PlutoCell(value: id ?? 0),
        'idPontoEscala': PlutoCell(value: idPontoEscala ?? 0),
        'codigo': PlutoCell(value: codigo ?? ''),
        'nome': PlutoCell(value: nome ?? ''),
      },
    );
  }

  PontoTurmaModel clone() {
    return PontoTurmaModel(
      id: id,
      idPontoEscala: idPontoEscala,
      codigo: codigo,
      nome: nome,
    );
  }


}