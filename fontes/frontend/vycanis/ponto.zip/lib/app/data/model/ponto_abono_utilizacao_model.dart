import 'dart:convert';
import 'package:pluto_grid/pluto_grid.dart';
import 'package:ponto/app/data/model/model_imports.dart';

import 'package:ponto/app/infra/infra_imports.dart';
import 'package:intl/intl.dart';

class PontoAbonoUtilizacaoModel extends ModelBase {
  int? id;
  int? idPontoAbono;
  DateTime? dataUtilizacao;
  String? observacao;

  PontoAbonoUtilizacaoModel({
    this.id,
    this.idPontoAbono,
    this.dataUtilizacao,
    this.observacao,
  });

  static List<String> dbColumns = <String>[
    'id',
    'data_utilizacao',
    'observacao',
  ];

  static List<String> aliasColumns = <String>[
    'Id',
    'Data Utilizacao',
    'Observacao',
  ];

  PontoAbonoUtilizacaoModel.fromJson(Map<String, dynamic> jsonData) {
    id = jsonData['id'];
    idPontoAbono = jsonData['idPontoAbono'];
    dataUtilizacao = jsonData['dataUtilizacao'] != null ? DateTime.tryParse(jsonData['dataUtilizacao']) : null;
    observacao = jsonData['observacao'];
  }

  Map<String, dynamic> get toJson {
    Map<String, dynamic> jsonData = <String, dynamic>{};

    jsonData['id'] = id != 0 ? id : null;
    jsonData['idPontoAbono'] = idPontoAbono != 0 ? idPontoAbono : null;
    jsonData['dataUtilizacao'] = dataUtilizacao != null ? DateFormat('yyyy-MM-ddT00:00:00').format(dataUtilizacao!) : null;
    jsonData['observacao'] = observacao;

    return jsonData;
  }

  String objectEncodeJson() {
    final jsonData = toJson;
    return json.encode(jsonData);
  }

  static PontoAbonoUtilizacaoModel fromPlutoRow(PlutoRow row) {
    return PontoAbonoUtilizacaoModel(
      id: row.cells['id']?.value,
      idPontoAbono: row.cells['idPontoAbono']?.value,
      dataUtilizacao: Util.stringToDate(row.cells['dataUtilizacao']?.value),
      observacao: row.cells['observacao']?.value,
    );
  }

  PlutoRow toPlutoRow() {
    return PlutoRow(
      cells: {
        'tempId': PlutoCell(value: tempId),
        'id': PlutoCell(value: id ?? 0),
        'idPontoAbono': PlutoCell(value: idPontoAbono ?? 0),
        'dataUtilizacao': PlutoCell(value: dataUtilizacao),
        'observacao': PlutoCell(value: observacao ?? ''),
      },
    );
  }

  PontoAbonoUtilizacaoModel clone() {
    return PontoAbonoUtilizacaoModel(
      id: id,
      idPontoAbono: idPontoAbono,
      dataUtilizacao: dataUtilizacao,
      observacao: observacao,
    );
  }


}