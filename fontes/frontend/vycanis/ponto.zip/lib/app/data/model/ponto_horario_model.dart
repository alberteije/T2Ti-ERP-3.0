import 'dart:convert';
import 'package:pluto_grid/pluto_grid.dart';
import 'package:ponto/app/data/model/model_imports.dart';

import 'package:ponto/app/infra/infra_imports.dart';
import 'package:ponto/app/data/domain/domain_imports.dart';

class PontoHorarioModel extends ModelBase {
  int? id;
  String? tipo;
  String? codigo;
  String? nome;
  String? tipoTrabalho;
  String? cargaHoraria;
  String? entrada01;
  String? saida01;
  String? entrada02;
  String? saida02;
  String? entrada03;
  String? saida03;
  String? entrada04;
  String? saida04;
  String? entrada05;
  String? saida05;
  String? horaInicioJornada;
  String? horaFimJornada;

  PontoHorarioModel({
    this.id,
    this.tipo = 'Fixo',
    this.codigo,
    this.nome,
    this.tipoTrabalho = 'Normal',
    this.cargaHoraria,
    this.entrada01,
    this.saida01,
    this.entrada02,
    this.saida02,
    this.entrada03,
    this.saida03,
    this.entrada04,
    this.saida04,
    this.entrada05,
    this.saida05,
    this.horaInicioJornada,
    this.horaFimJornada,
  });

  static List<String> dbColumns = <String>[
    'id',
    'tipo',
    'codigo',
    'nome',
    'tipo_trabalho',
    'carga_horaria',
    'entrada01',
    'saida01',
    'entrada02',
    'saida02',
    'entrada03',
    'saida03',
    'entrada04',
    'saida04',
    'entrada05',
    'saida05',
    'hora_inicio_jornada',
    'hora_fim_jornada',
  ];

  static List<String> aliasColumns = <String>[
    'Id',
    'Tipo',
    'Codigo',
    'Nome',
    'Tipo Trabalho',
    'Carga Horaria',
    'Entrada01',
    'Saida01',
    'Entrada02',
    'Saida02',
    'Entrada03',
    'Saida03',
    'Entrada04',
    'Saida04',
    'Entrada05',
    'Saida05',
    'Hora Inicio Jornada',
    'Hora Fim Jornada',
  ];

  PontoHorarioModel.fromJson(Map<String, dynamic> jsonData) {
    id = jsonData['id'];
    tipo = PontoHorarioDomain.getTipo(jsonData['tipo']);
    codigo = jsonData['codigo'];
    nome = jsonData['nome'];
    tipoTrabalho = PontoHorarioDomain.getTipoTrabalho(jsonData['tipoTrabalho']);
    cargaHoraria = jsonData['cargaHoraria'];
    entrada01 = jsonData['entrada01'];
    saida01 = jsonData['saida01'];
    entrada02 = jsonData['entrada02'];
    saida02 = jsonData['saida02'];
    entrada03 = jsonData['entrada03'];
    saida03 = jsonData['saida03'];
    entrada04 = jsonData['entrada04'];
    saida04 = jsonData['saida04'];
    entrada05 = jsonData['entrada05'];
    saida05 = jsonData['saida05'];
    horaInicioJornada = jsonData['horaInicioJornada'];
    horaFimJornada = jsonData['horaFimJornada'];
  }

  Map<String, dynamic> get toJson {
    Map<String, dynamic> jsonData = <String, dynamic>{};

    jsonData['id'] = id != 0 ? id : null;
    jsonData['tipo'] = PontoHorarioDomain.setTipo(tipo);
    jsonData['codigo'] = codigo;
    jsonData['nome'] = nome;
    jsonData['tipoTrabalho'] = PontoHorarioDomain.setTipoTrabalho(tipoTrabalho);
    jsonData['cargaHoraria'] = Util.removeMask(cargaHoraria);
    jsonData['entrada01'] = Util.removeMask(entrada01);
    jsonData['saida01'] = Util.removeMask(saida01);
    jsonData['entrada02'] = Util.removeMask(entrada02);
    jsonData['saida02'] = Util.removeMask(saida02);
    jsonData['entrada03'] = Util.removeMask(entrada03);
    jsonData['saida03'] = Util.removeMask(saida03);
    jsonData['entrada04'] = Util.removeMask(entrada04);
    jsonData['saida04'] = Util.removeMask(saida04);
    jsonData['entrada05'] = Util.removeMask(entrada05);
    jsonData['saida05'] = Util.removeMask(saida05);
    jsonData['horaInicioJornada'] = Util.removeMask(horaInicioJornada);
    jsonData['horaFimJornada'] = Util.removeMask(horaFimJornada);

    return jsonData;
  }

  String objectEncodeJson() {
    final jsonData = toJson;
    return json.encode(jsonData);
  }

  static PontoHorarioModel fromPlutoRow(PlutoRow row) {
    return PontoHorarioModel(
      id: row.cells['id']?.value,
      tipo: row.cells['tipo']?.value,
      codigo: row.cells['codigo']?.value,
      nome: row.cells['nome']?.value,
      tipoTrabalho: row.cells['tipoTrabalho']?.value,
      cargaHoraria: row.cells['cargaHoraria']?.value,
      entrada01: row.cells['entrada01']?.value,
      saida01: row.cells['saida01']?.value,
      entrada02: row.cells['entrada02']?.value,
      saida02: row.cells['saida02']?.value,
      entrada03: row.cells['entrada03']?.value,
      saida03: row.cells['saida03']?.value,
      entrada04: row.cells['entrada04']?.value,
      saida04: row.cells['saida04']?.value,
      entrada05: row.cells['entrada05']?.value,
      saida05: row.cells['saida05']?.value,
      horaInicioJornada: row.cells['horaInicioJornada']?.value,
      horaFimJornada: row.cells['horaFimJornada']?.value,
    );
  }

  PlutoRow toPlutoRow() {
    return PlutoRow(
      cells: {
        'tempId': PlutoCell(value: tempId),
        'id': PlutoCell(value: id ?? 0),
        'tipo': PlutoCell(value: tipo ?? ''),
        'codigo': PlutoCell(value: codigo ?? ''),
        'nome': PlutoCell(value: nome ?? ''),
        'tipoTrabalho': PlutoCell(value: tipoTrabalho ?? ''),
        'cargaHoraria': PlutoCell(value: cargaHoraria ?? ''),
        'entrada01': PlutoCell(value: entrada01 ?? ''),
        'saida01': PlutoCell(value: saida01 ?? ''),
        'entrada02': PlutoCell(value: entrada02 ?? ''),
        'saida02': PlutoCell(value: saida02 ?? ''),
        'entrada03': PlutoCell(value: entrada03 ?? ''),
        'saida03': PlutoCell(value: saida03 ?? ''),
        'entrada04': PlutoCell(value: entrada04 ?? ''),
        'saida04': PlutoCell(value: saida04 ?? ''),
        'entrada05': PlutoCell(value: entrada05 ?? ''),
        'saida05': PlutoCell(value: saida05 ?? ''),
        'horaInicioJornada': PlutoCell(value: horaInicioJornada ?? ''),
        'horaFimJornada': PlutoCell(value: horaFimJornada ?? ''),
      },
    );
  }

  PontoHorarioModel clone() {
    return PontoHorarioModel(
      id: id,
      tipo: tipo,
      codigo: codigo,
      nome: nome,
      tipoTrabalho: tipoTrabalho,
      cargaHoraria: cargaHoraria,
      entrada01: entrada01,
      saida01: saida01,
      entrada02: entrada02,
      saida02: saida02,
      entrada03: entrada03,
      saida03: saida03,
      entrada04: entrada04,
      saida04: saida04,
      entrada05: entrada05,
      saida05: saida05,
      horaInicioJornada: horaInicioJornada,
      horaFimJornada: horaFimJornada,
    );
  }


}