import 'dart:convert';
import 'package:pluto_grid/pluto_grid.dart';
import 'package:ponto/app/data/model/model_imports.dart';

import 'package:ponto/app/infra/infra_imports.dart';
import 'package:intl/intl.dart';
import 'package:ponto/app/data/domain/domain_imports.dart';

class PontoFechamentoJornadaModel extends ModelBase {
  int? id;
  int? idPontoClassificacaoJornada;
  int? idColaborador;
  DateTime? dataFechamento;
  String? diaSemana;
  String? codigoHorario;
  String? cargaHorariaEsperada;
  String? cargaHorariaDiurna;
  String? cargaHorariaNoturna;
  String? cargaHorariaTotal;
  String? entrada01;
  String? saida01;
  String? entrada02;
  String? saida02;
  String? entrada03;
  String? saida03;
  String? entrada04;
  String? saida04;
  String? entrada05;
  String? saida05;
  String? horaInicioJornada;
  String? horaFimJornada;
  String? horaExtra01;
  double? percentualHoraExtra01;
  String? modalidadeHoraExtra01;
  String? horaExtra02;
  double? percentualHoraExtra02;
  String? modalidadeHoraExtra02;
  String? horaExtra03;
  double? percentualHoraExtra03;
  String? modalidadeHoraExtra03;
  String? horaExtra04;
  double? percentualHoraExtra04;
  String? modalidadeHoraExtra04;
  String? faltaAtraso;
  String? compensar;
  String? bancoHoras;
  String? observacao;
  ViewPessoaColaboradorModel? viewPessoaColaboradorModel;
  PontoClassificacaoJornadaModel? pontoClassificacaoJornadaModel;

  PontoFechamentoJornadaModel({
    this.id,
    this.idPontoClassificacaoJornada,
    this.idColaborador,
    this.dataFechamento,
    this.diaSemana = 'DOMINGO',
    this.codigoHorario,
    this.cargaHorariaEsperada,
    this.cargaHorariaDiurna,
    this.cargaHorariaNoturna,
    this.cargaHorariaTotal,
    this.entrada01,
    this.saida01,
    this.entrada02,
    this.saida02,
    this.entrada03,
    this.saida03,
    this.entrada04,
    this.saida04,
    this.entrada05,
    this.saida05,
    this.horaInicioJornada,
    this.horaFimJornada,
    this.horaExtra01,
    this.percentualHoraExtra01,
    this.modalidadeHoraExtra01 = 'Diurna',
    this.horaExtra02,
    this.percentualHoraExtra02,
    this.modalidadeHoraExtra02 = 'Diurna',
    this.horaExtra03,
    this.percentualHoraExtra03,
    this.modalidadeHoraExtra03 = 'Diurna',
    this.horaExtra04,
    this.percentualHoraExtra04,
    this.modalidadeHoraExtra04 = 'Diurna',
    this.faltaAtraso,
    this.compensar = 'Horas a mais',
    this.bancoHoras,
    this.observacao,
    ViewPessoaColaboradorModel? viewPessoaColaboradorModel,
    PontoClassificacaoJornadaModel? pontoClassificacaoJornadaModel,
  }) {
    this.viewPessoaColaboradorModel = viewPessoaColaboradorModel ?? ViewPessoaColaboradorModel();
    this.pontoClassificacaoJornadaModel = pontoClassificacaoJornadaModel ?? PontoClassificacaoJornadaModel();
  }

  static List<String> dbColumns = <String>[
    'id',
    'data_fechamento',
    'dia_semana',
    'codigo_horario',
    'carga_horaria_esperada',
    'carga_horaria_diurna',
    'carga_horaria_noturna',
    'carga_horaria_total',
    'entrada01',
    'saida01',
    'entrada02',
    'saida02',
    'entrada03',
    'saida03',
    'entrada04',
    'saida04',
    'entrada05',
    'saida05',
    'hora_inicio_jornada',
    'hora_fim_jornada',
    'hora_extra01',
    'percentual_hora_extra01',
    'modalidade_hora_extra01',
    'hora_extra02',
    'percentual_hora_extra02',
    'modalidade_hora_extra02',
    'hora_extra03',
    'percentual_hora_extra03',
    'modalidade_hora_extra03',
    'hora_extra04',
    'percentual_hora_extra04',
    'modalidade_hora_extra04',
    'falta_atraso',
    'compensar',
    'banco_horas',
    'observacao',
  ];

  static List<String> aliasColumns = <String>[
    'Id',
    'Data Fechamento',
    'Dia Semana',
    'Codigo Horario',
    'Carga Horaria Esperada',
    'Carga Horaria Diurna',
    'Carga Horaria Noturna',
    'Carga Horaria Total',
    'Entrada01',
    'Saida01',
    'Entrada02',
    'Saida02',
    'Entrada03',
    'Saida03',
    'Entrada04',
    'Saida04',
    'Entrada05',
    'Saida05',
    'Hora Inicio Jornada',
    'Hora Fim Jornada',
    'Hora Extra01',
    'Percentual Hora Extra01',
    'Modalidade Hora Extra01',
    'Hora Extra02',
    'Percentual Hora Extra02',
    'Modalidade Hora Extra02',
    'Hora Extra03',
    'Percentual Hora Extra03',
    'Modalidade Hora Extra03',
    'Hora Extra04',
    'Percentual Hora Extra04',
    'Modalidade Hora Extra04',
    'Falta Atraso',
    'Compensar',
    'Banco Horas',
    'Observacao',
  ];

  PontoFechamentoJornadaModel.fromJson(Map<String, dynamic> jsonData) {
    id = jsonData['id'];
    idPontoClassificacaoJornada = jsonData['idPontoClassificacaoJornada'];
    idColaborador = jsonData['idColaborador'];
    dataFechamento = jsonData['dataFechamento'] != null ? DateTime.tryParse(jsonData['dataFechamento']) : null;
    diaSemana = PontoFechamentoJornadaDomain.getDiaSemana(jsonData['diaSemana']);
    codigoHorario = jsonData['codigoHorario'];
    cargaHorariaEsperada = jsonData['cargaHorariaEsperada'];
    cargaHorariaDiurna = jsonData['cargaHorariaDiurna'];
    cargaHorariaNoturna = jsonData['cargaHorariaNoturna'];
    cargaHorariaTotal = jsonData['cargaHorariaTotal'];
    entrada01 = jsonData['entrada01'];
    saida01 = jsonData['saida01'];
    entrada02 = jsonData['entrada02'];
    saida02 = jsonData['saida02'];
    entrada03 = jsonData['entrada03'];
    saida03 = jsonData['saida03'];
    entrada04 = jsonData['entrada04'];
    saida04 = jsonData['saida04'];
    entrada05 = jsonData['entrada05'];
    saida05 = jsonData['saida05'];
    horaInicioJornada = jsonData['horaInicioJornada'];
    horaFimJornada = jsonData['horaFimJornada'];
    horaExtra01 = jsonData['horaExtra01'];
    percentualHoraExtra01 = jsonData['percentualHoraExtra01']?.toDouble();
    modalidadeHoraExtra01 = PontoFechamentoJornadaDomain.getModalidadeHoraExtra01(jsonData['modalidadeHoraExtra01']);
    horaExtra02 = jsonData['horaExtra02'];
    percentualHoraExtra02 = jsonData['percentualHoraExtra02']?.toDouble();
    modalidadeHoraExtra02 = PontoFechamentoJornadaDomain.getModalidadeHoraExtra02(jsonData['modalidadeHoraExtra02']);
    horaExtra03 = jsonData['horaExtra03'];
    percentualHoraExtra03 = jsonData['percentualHoraExtra03']?.toDouble();
    modalidadeHoraExtra03 = PontoFechamentoJornadaDomain.getModalidadeHoraExtra03(jsonData['modalidadeHoraExtra03']);
    horaExtra04 = jsonData['horaExtra04'];
    percentualHoraExtra04 = jsonData['percentualHoraExtra04']?.toDouble();
    modalidadeHoraExtra04 = PontoFechamentoJornadaDomain.getModalidadeHoraExtra04(jsonData['modalidadeHoraExtra04']);
    faltaAtraso = jsonData['faltaAtraso'];
    compensar = PontoFechamentoJornadaDomain.getCompensar(jsonData['compensar']);
    bancoHoras = jsonData['bancoHoras'];
    observacao = jsonData['observacao'];
    viewPessoaColaboradorModel = jsonData['viewPessoaColaboradorModel'] == null ? ViewPessoaColaboradorModel() : ViewPessoaColaboradorModel.fromJson(jsonData['viewPessoaColaboradorModel']);
    pontoClassificacaoJornadaModel = jsonData['pontoClassificacaoJornadaModel'] == null ? PontoClassificacaoJornadaModel() : PontoClassificacaoJornadaModel.fromJson(jsonData['pontoClassificacaoJornadaModel']);
  }

  Map<String, dynamic> get toJson {
    Map<String, dynamic> jsonData = <String, dynamic>{};

    jsonData['id'] = id != 0 ? id : null;
    jsonData['idPontoClassificacaoJornada'] = idPontoClassificacaoJornada != 0 ? idPontoClassificacaoJornada : null;
    jsonData['idColaborador'] = idColaborador != 0 ? idColaborador : null;
    jsonData['dataFechamento'] = dataFechamento != null ? DateFormat('yyyy-MM-ddT00:00:00').format(dataFechamento!) : null;
    jsonData['diaSemana'] = PontoFechamentoJornadaDomain.setDiaSemana(diaSemana);
    jsonData['codigoHorario'] = codigoHorario;
    jsonData['cargaHorariaEsperada'] = Util.removeMask(cargaHorariaEsperada);
    jsonData['cargaHorariaDiurna'] = Util.removeMask(cargaHorariaDiurna);
    jsonData['cargaHorariaNoturna'] = Util.removeMask(cargaHorariaNoturna);
    jsonData['cargaHorariaTotal'] = Util.removeMask(cargaHorariaTotal);
    jsonData['entrada01'] = Util.removeMask(entrada01);
    jsonData['saida01'] = Util.removeMask(saida01);
    jsonData['entrada02'] = Util.removeMask(entrada02);
    jsonData['saida02'] = Util.removeMask(saida02);
    jsonData['entrada03'] = Util.removeMask(entrada03);
    jsonData['saida03'] = Util.removeMask(saida03);
    jsonData['entrada04'] = Util.removeMask(entrada04);
    jsonData['saida04'] = Util.removeMask(saida04);
    jsonData['entrada05'] = Util.removeMask(entrada05);
    jsonData['saida05'] = Util.removeMask(saida05);
    jsonData['horaInicioJornada'] = Util.removeMask(horaInicioJornada);
    jsonData['horaFimJornada'] = Util.removeMask(horaFimJornada);
    jsonData['horaExtra01'] = Util.removeMask(horaExtra01);
    jsonData['percentualHoraExtra01'] = percentualHoraExtra01;
    jsonData['modalidadeHoraExtra01'] = PontoFechamentoJornadaDomain.setModalidadeHoraExtra01(modalidadeHoraExtra01);
    jsonData['horaExtra02'] = Util.removeMask(horaExtra02);
    jsonData['percentualHoraExtra02'] = percentualHoraExtra02;
    jsonData['modalidadeHoraExtra02'] = PontoFechamentoJornadaDomain.setModalidadeHoraExtra02(modalidadeHoraExtra02);
    jsonData['horaExtra03'] = Util.removeMask(horaExtra03);
    jsonData['percentualHoraExtra03'] = percentualHoraExtra03;
    jsonData['modalidadeHoraExtra03'] = PontoFechamentoJornadaDomain.setModalidadeHoraExtra03(modalidadeHoraExtra03);
    jsonData['horaExtra04'] = Util.removeMask(horaExtra04);
    jsonData['percentualHoraExtra04'] = percentualHoraExtra04;
    jsonData['modalidadeHoraExtra04'] = PontoFechamentoJornadaDomain.setModalidadeHoraExtra04(modalidadeHoraExtra04);
    jsonData['faltaAtraso'] = Util.removeMask(faltaAtraso);
    jsonData['compensar'] = PontoFechamentoJornadaDomain.setCompensar(compensar);
    jsonData['bancoHoras'] = Util.removeMask(bancoHoras);
    jsonData['observacao'] = observacao;
    jsonData['viewPessoaColaboradorModel'] = viewPessoaColaboradorModel?.toJson;
    jsonData['viewPessoaColaborador'] = viewPessoaColaboradorModel?.nome ?? '';
    jsonData['pontoClassificacaoJornadaModel'] = pontoClassificacaoJornadaModel?.toJson;
    jsonData['pontoClassificacaoJornada'] = pontoClassificacaoJornadaModel?.nome ?? '';

    return jsonData;
  }

  String objectEncodeJson() {
    final jsonData = toJson;
    return json.encode(jsonData);
  }

  static PontoFechamentoJornadaModel fromPlutoRow(PlutoRow row) {
    return PontoFechamentoJornadaModel(
      id: row.cells['id']?.value,
      idPontoClassificacaoJornada: row.cells['idPontoClassificacaoJornada']?.value,
      idColaborador: row.cells['idColaborador']?.value,
      dataFechamento: Util.stringToDate(row.cells['dataFechamento']?.value),
      diaSemana: row.cells['diaSemana']?.value,
      codigoHorario: row.cells['codigoHorario']?.value,
      cargaHorariaEsperada: row.cells['cargaHorariaEsperada']?.value,
      cargaHorariaDiurna: row.cells['cargaHorariaDiurna']?.value,
      cargaHorariaNoturna: row.cells['cargaHorariaNoturna']?.value,
      cargaHorariaTotal: row.cells['cargaHorariaTotal']?.value,
      entrada01: row.cells['entrada01']?.value,
      saida01: row.cells['saida01']?.value,
      entrada02: row.cells['entrada02']?.value,
      saida02: row.cells['saida02']?.value,
      entrada03: row.cells['entrada03']?.value,
      saida03: row.cells['saida03']?.value,
      entrada04: row.cells['entrada04']?.value,
      saida04: row.cells['saida04']?.value,
      entrada05: row.cells['entrada05']?.value,
      saida05: row.cells['saida05']?.value,
      horaInicioJornada: row.cells['horaInicioJornada']?.value,
      horaFimJornada: row.cells['horaFimJornada']?.value,
      horaExtra01: row.cells['horaExtra01']?.value,
      percentualHoraExtra01: row.cells['percentualHoraExtra01']?.value,
      modalidadeHoraExtra01: row.cells['modalidadeHoraExtra01']?.value,
      horaExtra02: row.cells['horaExtra02']?.value,
      percentualHoraExtra02: row.cells['percentualHoraExtra02']?.value,
      modalidadeHoraExtra02: row.cells['modalidadeHoraExtra02']?.value,
      horaExtra03: row.cells['horaExtra03']?.value,
      percentualHoraExtra03: row.cells['percentualHoraExtra03']?.value,
      modalidadeHoraExtra03: row.cells['modalidadeHoraExtra03']?.value,
      horaExtra04: row.cells['horaExtra04']?.value,
      percentualHoraExtra04: row.cells['percentualHoraExtra04']?.value,
      modalidadeHoraExtra04: row.cells['modalidadeHoraExtra04']?.value,
      faltaAtraso: row.cells['faltaAtraso']?.value,
      compensar: row.cells['compensar']?.value,
      bancoHoras: row.cells['bancoHoras']?.value,
      observacao: row.cells['observacao']?.value,
    );
  }

  PlutoRow toPlutoRow() {
    return PlutoRow(
      cells: {
        'tempId': PlutoCell(value: tempId),
        'id': PlutoCell(value: id ?? 0),
        'idPontoClassificacaoJornada': PlutoCell(value: idPontoClassificacaoJornada ?? 0),
        'idColaborador': PlutoCell(value: idColaborador ?? 0),
        'dataFechamento': PlutoCell(value: dataFechamento),
        'diaSemana': PlutoCell(value: diaSemana ?? ''),
        'codigoHorario': PlutoCell(value: codigoHorario ?? ''),
        'cargaHorariaEsperada': PlutoCell(value: cargaHorariaEsperada ?? ''),
        'cargaHorariaDiurna': PlutoCell(value: cargaHorariaDiurna ?? ''),
        'cargaHorariaNoturna': PlutoCell(value: cargaHorariaNoturna ?? ''),
        'cargaHorariaTotal': PlutoCell(value: cargaHorariaTotal ?? ''),
        'entrada01': PlutoCell(value: entrada01 ?? ''),
        'saida01': PlutoCell(value: saida01 ?? ''),
        'entrada02': PlutoCell(value: entrada02 ?? ''),
        'saida02': PlutoCell(value: saida02 ?? ''),
        'entrada03': PlutoCell(value: entrada03 ?? ''),
        'saida03': PlutoCell(value: saida03 ?? ''),
        'entrada04': PlutoCell(value: entrada04 ?? ''),
        'saida04': PlutoCell(value: saida04 ?? ''),
        'entrada05': PlutoCell(value: entrada05 ?? ''),
        'saida05': PlutoCell(value: saida05 ?? ''),
        'horaInicioJornada': PlutoCell(value: horaInicioJornada ?? ''),
        'horaFimJornada': PlutoCell(value: horaFimJornada ?? ''),
        'horaExtra01': PlutoCell(value: horaExtra01 ?? ''),
        'percentualHoraExtra01': PlutoCell(value: percentualHoraExtra01 ?? 0.0),
        'modalidadeHoraExtra01': PlutoCell(value: modalidadeHoraExtra01 ?? ''),
        'horaExtra02': PlutoCell(value: horaExtra02 ?? ''),
        'percentualHoraExtra02': PlutoCell(value: percentualHoraExtra02 ?? 0.0),
        'modalidadeHoraExtra02': PlutoCell(value: modalidadeHoraExtra02 ?? ''),
        'horaExtra03': PlutoCell(value: horaExtra03 ?? ''),
        'percentualHoraExtra03': PlutoCell(value: percentualHoraExtra03 ?? 0.0),
        'modalidadeHoraExtra03': PlutoCell(value: modalidadeHoraExtra03 ?? ''),
        'horaExtra04': PlutoCell(value: horaExtra04 ?? ''),
        'percentualHoraExtra04': PlutoCell(value: percentualHoraExtra04 ?? 0.0),
        'modalidadeHoraExtra04': PlutoCell(value: modalidadeHoraExtra04 ?? ''),
        'faltaAtraso': PlutoCell(value: faltaAtraso ?? ''),
        'compensar': PlutoCell(value: compensar ?? ''),
        'bancoHoras': PlutoCell(value: bancoHoras ?? ''),
        'observacao': PlutoCell(value: observacao ?? ''),
        'viewPessoaColaborador': PlutoCell(value: viewPessoaColaboradorModel?.nome ?? ''),
        'pontoClassificacaoJornada': PlutoCell(value: pontoClassificacaoJornadaModel?.nome ?? ''),
      },
    );
  }

  PontoFechamentoJornadaModel clone() {
    return PontoFechamentoJornadaModel(
      id: id,
      idPontoClassificacaoJornada: idPontoClassificacaoJornada,
      idColaborador: idColaborador,
      dataFechamento: dataFechamento,
      diaSemana: diaSemana,
      codigoHorario: codigoHorario,
      cargaHorariaEsperada: cargaHorariaEsperada,
      cargaHorariaDiurna: cargaHorariaDiurna,
      cargaHorariaNoturna: cargaHorariaNoturna,
      cargaHorariaTotal: cargaHorariaTotal,
      entrada01: entrada01,
      saida01: saida01,
      entrada02: entrada02,
      saida02: saida02,
      entrada03: entrada03,
      saida03: saida03,
      entrada04: entrada04,
      saida04: saida04,
      entrada05: entrada05,
      saida05: saida05,
      horaInicioJornada: horaInicioJornada,
      horaFimJornada: horaFimJornada,
      horaExtra01: horaExtra01,
      percentualHoraExtra01: percentualHoraExtra01,
      modalidadeHoraExtra01: modalidadeHoraExtra01,
      horaExtra02: horaExtra02,
      percentualHoraExtra02: percentualHoraExtra02,
      modalidadeHoraExtra02: modalidadeHoraExtra02,
      horaExtra03: horaExtra03,
      percentualHoraExtra03: percentualHoraExtra03,
      modalidadeHoraExtra03: modalidadeHoraExtra03,
      horaExtra04: horaExtra04,
      percentualHoraExtra04: percentualHoraExtra04,
      modalidadeHoraExtra04: modalidadeHoraExtra04,
      faltaAtraso: faltaAtraso,
      compensar: compensar,
      bancoHoras: bancoHoras,
      observacao: observacao,
      viewPessoaColaboradorModel: viewPessoaColaboradorModel?.clone(),
      pontoClassificacaoJornadaModel: pontoClassificacaoJornadaModel?.clone(),
    );
  }


}