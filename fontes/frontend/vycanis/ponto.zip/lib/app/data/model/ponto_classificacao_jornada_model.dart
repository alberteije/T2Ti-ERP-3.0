import 'dart:convert';
import 'package:pluto_grid/pluto_grid.dart';
import 'package:ponto/app/data/model/model_imports.dart';

import 'package:ponto/app/data/domain/domain_imports.dart';

class PontoClassificacaoJornadaModel extends ModelBase {
  int? id;
  String? codigo;
  String? nome;
  String? descricao;
  String? padrao;
  String? descontarHoras;

  PontoClassificacaoJornadaModel({
    this.id,
    this.codigo,
    this.nome,
    this.descricao,
    this.padrao = 'Sim',
    this.descontarHoras = 'Sim',
  });

  static List<String> dbColumns = <String>[
    'id',
    'codigo',
    'nome',
    'descricao',
    'padrao',
    'descontar_horas',
  ];

  static List<String> aliasColumns = <String>[
    'Id',
    'Codigo',
    'Nome',
    'Descricao',
    'Padrao',
    'Descontar Horas',
  ];

  PontoClassificacaoJornadaModel.fromJson(Map<String, dynamic> jsonData) {
    id = jsonData['id'];
    codigo = jsonData['codigo'];
    nome = jsonData['nome'];
    descricao = jsonData['descricao'];
    padrao = PontoClassificacaoJornadaDomain.getPadrao(jsonData['padrao']);
    descontarHoras = PontoClassificacaoJornadaDomain.getDescontarHoras(jsonData['descontarHoras']);
  }

  Map<String, dynamic> get toJson {
    Map<String, dynamic> jsonData = <String, dynamic>{};

    jsonData['id'] = id != 0 ? id : null;
    jsonData['codigo'] = codigo;
    jsonData['nome'] = nome;
    jsonData['descricao'] = descricao;
    jsonData['padrao'] = PontoClassificacaoJornadaDomain.setPadrao(padrao);
    jsonData['descontarHoras'] = PontoClassificacaoJornadaDomain.setDescontarHoras(descontarHoras);

    return jsonData;
  }

  String objectEncodeJson() {
    final jsonData = toJson;
    return json.encode(jsonData);
  }

  static PontoClassificacaoJornadaModel fromPlutoRow(PlutoRow row) {
    return PontoClassificacaoJornadaModel(
      id: row.cells['id']?.value,
      codigo: row.cells['codigo']?.value,
      nome: row.cells['nome']?.value,
      descricao: row.cells['descricao']?.value,
      padrao: row.cells['padrao']?.value,
      descontarHoras: row.cells['descontarHoras']?.value,
    );
  }

  PlutoRow toPlutoRow() {
    return PlutoRow(
      cells: {
        'tempId': PlutoCell(value: tempId),
        'id': PlutoCell(value: id ?? 0),
        'codigo': PlutoCell(value: codigo ?? ''),
        'nome': PlutoCell(value: nome ?? ''),
        'descricao': PlutoCell(value: descricao ?? ''),
        'padrao': PlutoCell(value: padrao ?? ''),
        'descontarHoras': PlutoCell(value: descontarHoras ?? ''),
      },
    );
  }

  PontoClassificacaoJornadaModel clone() {
    return PontoClassificacaoJornadaModel(
      id: id,
      codigo: codigo,
      nome: nome,
      descricao: descricao,
      padrao: padrao,
      descontarHoras: descontarHoras,
    );
  }


}