// ignore_for_file: deprecated_member_use

import 'package:flutter/services.dart';
import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;
import 'package:ponto/app/data/model/model_imports.dart';
import 'package:ponto/app/infra/infra_imports.dart';

Future<Uint8List> gerarEspelhoDePontoPdf({
  required EmpresaModel empresa,
  required ViewPessoaColaboradorModel colaborador,
  required List<PontoHorarioModel> horariosContratuais,
  required List<PontoFechamentoJornadaModel> jornadas,
  required List<PontoMarcacaoModel> marcacoes,
  required String mesAno, // formato "MM/yyyy"
}) async {
  final doc = pw.Document();

  final fontNormal = await rootBundle.load('assets/fonts/report/roboto-normal.ttf');
  final fontBold = await rootBundle.load('assets/fonts/report/roboto-bold.ttf');
  final logo = pw.MemoryImage((await rootBundle.load('assets/images/logotipo.png')).buffer.asUint8List());

  const PdfColor corBase = PdfColors.blue900;
  const PdfColor corTexto = PdfColors.black;

  doc.addPage(
    pw.MultiPage(
      pageTheme: pw.PageTheme(
        pageFormat: PdfPageFormat.a4.landscape,
        theme: pw.ThemeData.withFont(
          base: pw.Font.ttf(fontNormal),
          bold: pw.Font.ttf(fontBold),
        ),
      ),
      header: (context) => _cabecalhoRelatorio(empresa, colaborador, logo, corBase),
      build: (context) => [
        _tabelaHorariosContratuais(horariosContratuais, corBase),
        pw.SizedBox(height: 15),
        _tabelaJornadas(jornadas, marcacoes, corTexto, corBase),
      ],
    ),
  );

  return doc.save();
}

pw.Widget _cabecalhoRelatorio(EmpresaModel empresa, ViewPessoaColaboradorModel colaborador, pw.ImageProvider logo, PdfColor corBase) {
  return pw.Column(
    crossAxisAlignment: pw.CrossAxisAlignment.start,
    children: [
      pw.Row(
        crossAxisAlignment: pw.CrossAxisAlignment.center,
        children: [
          pw.Container(height: 50, width: 50, child: pw.Image(logo)),
          pw.SizedBox(width: 10),
          pw.Column(
            crossAxisAlignment: pw.CrossAxisAlignment.start,
            children: [
              pw.Text(empresa.razaoSocial ?? '', style: pw.TextStyle(fontSize: 14, fontWeight: pw.FontWeight.bold, color: corBase)),
              pw.Text('CNPJ: ${empresa.cnpj ?? ''}', style: const pw.TextStyle(fontSize: 10)),
              pw.Text('Colaborador: ${colaborador.nome ?? ''}', style: const pw.TextStyle(fontSize: 10)),
              pw.Text('CPF: ${colaborador.cpfCnpj ?? ''}', style: const pw.TextStyle(fontSize: 10)),
            ],
          ),
        ],
      ),
      pw.SizedBox(height: 10),
      pw.Text('Espelho de Ponto Eletrônico', style: pw.TextStyle(fontSize: 16, fontWeight: pw.FontWeight.bold, color: corBase)),
      pw.Divider(),
    ],
  );
}

pw.Widget _tabelaHorariosContratuais(List<PontoHorarioModel> horarios, PdfColor corBase) {
  return pw.Column(
    crossAxisAlignment: pw.CrossAxisAlignment.start,
    children: [
      pw.Text('Horários contratuais do empregado', style: pw.TextStyle(fontSize: 12, fontWeight: pw.FontWeight.bold, color: corBase)),
      pw.SizedBox(height: 5),
      pw.Table.fromTextArray(
        headers: ['CH', 'Entrada 1', 'Saída 1', 'Entrada 2', 'Saída 2', 'Entrada 3', 'Saída 3'],
        headerStyle: pw.TextStyle(fontWeight: pw.FontWeight.bold),
        cellStyle: const pw.TextStyle(fontSize: 9),
        data: horarios.map((h) {
          return [
            h.codigo ?? '',
            h.entrada01 ?? '',
            h.saida01 ?? '',
            h.entrada02 ?? '',
            h.saida02 ?? '',
            h.entrada03 ?? '',
            h.saida03 ?? '',
          ];
        }).toList(),
      ),
    ],
  );
}

pw.Widget _tabelaJornadas(List<PontoFechamentoJornadaModel> jornadas, List<PontoMarcacaoModel> marcacoes, PdfColor corTexto, PdfColor corBase) {
  return pw.Column(
    crossAxisAlignment: pw.CrossAxisAlignment.start,
    children: [
      pw.Text('Marcações e Jornada Realizada', style: pw.TextStyle(fontSize: 12, fontWeight: pw.FontWeight.bold, color: corBase)),
      pw.SizedBox(height: 5),
      pw.Table.fromTextArray(
        headers: [
          'Data',
          'Marcações',
          'Entrada 1', 'Saída 1',
          'Entrada 2', 'Saída 2',
          'Entrada 3', 'Saída 3',
          'CH',
          'Tratamentos'
        ],
        headerStyle: pw.TextStyle(fontWeight: pw.FontWeight.bold, color: corBase),
        cellStyle: const pw.TextStyle(fontSize: 9),
        data: jornadas.map((j) {
          final marcacoesDia = marcacoes.where((m) => Util.formatDate(m.dataMarcacao!) == Util.formatDate(j.dataFechamento!)).toList();

          final marcas = marcacoesDia.map((m) => m.horaMarcacao ?? '').join('  ');
          final tratamentos = marcacoesDia
              .where((m) => (m.tipoMarcacao == 'D' || m.tipoRegistro == 'I' || m.tipoRegistro == 'P'))
              .map((m) => '${m.horaMarcacao} - ${m.tipoMarcacao ?? m.tipoRegistro} (${m.justificativa ?? ''})')
              .join('\n');

          return [
            Util.formatDate(j.dataFechamento),
            marcas,
            j.entrada01 ?? '',
            j.saida01 ?? '',
            j.entrada02 ?? '',
            j.saida02 ?? '',
            j.entrada03 ?? '',
            j.saida03 ?? '',
            j.codigoHorario ?? '',
            tratamentos,
          ];
        }).toList(),
      ),
    ],
  );
}
