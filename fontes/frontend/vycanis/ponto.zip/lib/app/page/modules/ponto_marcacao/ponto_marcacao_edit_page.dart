import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_bootstrap/flutter_bootstrap.dart';
import 'package:get/get.dart';
import 'package:ponto/app/page/shared_widget/shared_widget_imports.dart';
import 'package:ponto/app/data/domain/domain_imports.dart';
import 'package:ponto/app/controller/ponto_marcacao_controller.dart';
import 'package:ponto/app/infra/infra_imports.dart';
import 'package:ponto/app/page/shared_widget/input/input_imports.dart';

class PontoMarcacaoEditPage extends StatelessWidget {
	PontoMarcacaoEditPage({Key? key}) : super(key: key);
	final pontoMarcacaoController = Get.find<PontoMarcacaoController>();

	@override
	Widget build(BuildContext context) {
		return KeyboardListener(
			autofocus: false,
			focusNode: FocusNode(),
			onKeyEvent: (event) {
				if (event.logicalKey == LogicalKeyboardKey.escape) {
					pontoMarcacaoController.preventDataLoss();
				}
			},
			child: Scaffold(
				key: pontoMarcacaoController.scaffoldKey,
				appBar: AppBar(
					automaticallyImplyLeading: false,
					title: Text('${ pontoMarcacaoController.screenTitle } - ${ pontoMarcacaoController.isNewRecord ? 'inserting'.tr : 'editing'.tr }',),
					actions: [
						saveButton(onPressed: pontoMarcacaoController.save),
						cancelAndExitButton(onPressed: pontoMarcacaoController.preventDataLoss),
					]
				),
				body: SafeArea(
					top: false,
					bottom: false,
					child: Form(
						key: pontoMarcacaoController.formKey,
						autovalidateMode: AutovalidateMode.always,
						child: Scrollbar(
							controller: pontoMarcacaoController.scrollController,
							child: SingleChildScrollView(
								controller: pontoMarcacaoController.scrollController,
								child: BootstrapContainer(
									fluid: true,
									padding: const EdgeInsets.fromLTRB(10.0, 10.0, 10.0, 10.0),
									children: <Widget>[
										const Divider(
											color: Colors.transparent,
										),
										BootstrapRow(
											height: 60,
											children: <BootstrapCol>[
												BootstrapCol(
													sizes: 'col-12',
													child: Row(
														children: <Widget>[
															Expanded(
																flex: 1,
																child: SizedBox(
																	child: TextFormField(
																		controller: pontoMarcacaoController.pontoRelogioModelController,
																		readOnly: true,
																		decoration: inputDecoration(
																			hintText: 'Informe os dados para o campo Id Ponto Relogio',
																			labelText: 'Relogio',
																			usePadding: true,
																		),
																		onSaved: (String? value) {},
																		onChanged: (text) {},
																	),
																),
															),
															Expanded(
																flex: 0,
																child: lookupButton(onPressed: pontoMarcacaoController.callPontoRelogioLookup),
															),
														],
													),
												),
											],
										),
										const Divider(
											color: Colors.transparent,
										),
										BootstrapRow(
											height: 60,
											children: <BootstrapCol>[
												BootstrapCol(
													sizes: 'col-12',
													child: Row(
														children: <Widget>[
															Expanded(
																flex: 1,
																child: SizedBox(
																	child: TextFormField(
																		controller: pontoMarcacaoController.viewPessoaColaboradorModelController,
																		validator: ValidateFormField.validateMandatory,
																		readOnly: true,
																		decoration: inputDecoration(
																			hintText: 'Informe os dados para o campo Colaborador',
																			labelText: 'Colaborador *',
																			usePadding: true,
																		),
																		onSaved: (String? value) {},
																		onChanged: (text) {},
																	),
																),
															),
															Expanded(
																flex: 0,
																child: lookupButton(onPressed: pontoMarcacaoController.callViewPessoaColaboradorLookup),
															),
														],
													),
												),
											],
										),
										const Divider(
											color: Colors.transparent,
										),
										BootstrapRow(
											height: 60,
											children: <BootstrapCol>[
												BootstrapCol(
													sizes: 'col-12 col-md-4',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: TextFormField(
															autofocus: true,
															controller: pontoMarcacaoController.nsrController,
															decoration: inputDecoration(
																hintText: 'Informe os dados para o campo Nsr',
																labelText: 'NSR',
																usePadding: true,
															),
															onSaved: (String? value) {},
															onChanged: (text) {
																pontoMarcacaoController.currentModel.nsr = int.tryParse(text);
																pontoMarcacaoController.formWasChanged = true;
															},
														),
													),
												),
												BootstrapCol(
													sizes: 'col-12 col-md-4',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: InputDecorator(
															decoration: inputDecoration(
																hintText: 'Informe os dados para o campo Data Marcacao',
																labelText: 'Data Marcacao',
																usePadding: true,
															),
															isEmpty: false,
															child: DatePickerItem(
																controller: pontoMarcacaoController.dataMarcacaoController,
																firstDate: DateTime.parse('1000-01-01'),
																lastDate: DateTime.parse('5000-01-01'),
																onChanged: (DateTime? value) {
																	pontoMarcacaoController.currentModel.dataMarcacao = value;
																	pontoMarcacaoController.formWasChanged = true;
																},
															),
														),
													),
												),
												BootstrapCol(
													sizes: 'col-12 col-md-4',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: TextFormField(
															autofocus: true,
															controller: pontoMarcacaoController.horaMarcacaoController,
															decoration: inputDecoration(
																hintText: 'Informe os dados para o campo Hora Marcacao',
																labelText: 'Hora Marcacao',
																usePadding: true,
															),
															onSaved: (String? value) {},
															onChanged: (text) {
																pontoMarcacaoController.currentModel.horaMarcacao = text;
																pontoMarcacaoController.formWasChanged = true;
															},
														),
													),
												),
											],
										),
										const Divider(
											color: Colors.transparent,
										),
										BootstrapRow(
											height: 60,
											children: <BootstrapCol>[
												BootstrapCol(
													sizes: 'col-12 col-md-4',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: CustomDropdownButton(
															controller: pontoMarcacaoController.tipoMarcacaoController,
															labelText: 'Tipo Marcacao',
															hintText: 'Informe os dados para o campo Tipo Marcacao',
															items: PontoMarcacaoDomain.tipoMarcacaoListDropdown,
															onChanged: (dynamic newValue) {
																pontoMarcacaoController.currentModel.tipoMarcacao = newValue;
																pontoMarcacaoController.formWasChanged = true;
															},
														),
													),
												),
												BootstrapCol(
													sizes: 'col-12 col-md-4',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: CustomDropdownButton(
															controller: pontoMarcacaoController.tipoRegistroController,
															labelText: 'Tipo Registro',
															hintText: 'Informe os dados para o campo Tipo Registro',
															items: PontoMarcacaoDomain.tipoRegistroListDropdown,
															onChanged: (dynamic newValue) {
																pontoMarcacaoController.currentModel.tipoRegistro = newValue;
																pontoMarcacaoController.formWasChanged = true;
															},
														),
													),
												),
												BootstrapCol(
													sizes: 'col-12 col-md-4',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: TextFormField(
															autofocus: true,
															maxLength: 2,
															controller: pontoMarcacaoController.parEntradaSaidaController,
															decoration: inputDecoration(
																hintText: 'Informe os dados para o campo Par Entrada Saida',
																labelText: 'Par Entrada Saida',
																usePadding: true,
															),
															onSaved: (String? value) {},
															onChanged: (text) {
																pontoMarcacaoController.currentModel.parEntradaSaida = text;
																pontoMarcacaoController.formWasChanged = true;
															},
														),
													),
												),
											],
										),
										const Divider(
											color: Colors.transparent,
										),
										BootstrapRow(
											height: 60,
											children: <BootstrapCol>[
												BootstrapCol(
													sizes: 'col-12',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: TextFormField(
															autofocus: true,
															maxLength: 100,
															controller: pontoMarcacaoController.justificativaController,
															decoration: inputDecoration(
																hintText: 'Informe os dados para o campo Justificativa',
																labelText: 'Justificativa',
																usePadding: true,
															),
															onSaved: (String? value) {},
															onChanged: (text) {
																pontoMarcacaoController.currentModel.justificativa = text;
																pontoMarcacaoController.formWasChanged = true;
															},
														),
													),
												),
											],
										),
										const Divider(
											indent: 10,
											endIndent: 10,
											thickness: 2,
										),
										BootstrapRow(
											height: 60,
											children: <BootstrapCol>[
												BootstrapCol(
													sizes: 'col-12',
													child: Text(
														'field_is_mandatory'.tr,
														style: Theme.of(context).textTheme.bodySmall,
													),
												),
											],
										),
										const SizedBox(height: 10.0),
									],
								),
							),
						),
					),
				),
			),
		);
	}
}
