import 'package:flutter/material.dart';
import 'package:ponto/app/controller/ponto_horario_autorizado_controller.dart';
import 'package:ponto/app/page/shared_page/list_page_base.dart';

class PontoHorarioAutorizadoListPage extends ListPageBase<PontoHorarioAutorizadoController> {
  const PontoHorarioAutorizadoListPage({Key? key}) : super(key: key);

  @override
  List<Map<String, dynamic>> get mobileItems => controller.mobileItems;

  @override
  Map<String, dynamic> get mobileConfig => controller.mobileConfig;

  @override
  String get standardFieldForFilter => controller.standardFieldForFilter;
}