import 'package:flutter/material.dart';
import 'package:ponto/app/controller/ponto_abono_controller.dart';
import 'package:ponto/app/page/shared_page/list_page_base.dart';

class PontoAbonoListPage extends ListPageBase<PontoAbonoController> {
  const PontoAbonoListPage({Key? key}) : super(key: key);

  @override
  List<Map<String, dynamic>> get mobileItems => controller.mobileItems;

  @override
  Map<String, dynamic> get mobileConfig => controller.mobileConfig;

  @override
  String get standardFieldForFilter => controller.standardFieldForFilter;
}