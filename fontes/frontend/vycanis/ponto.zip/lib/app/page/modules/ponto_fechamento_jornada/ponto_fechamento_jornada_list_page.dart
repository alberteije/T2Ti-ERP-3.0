import 'package:flutter/material.dart';
import 'package:ponto/app/controller/ponto_fechamento_jornada_controller.dart';
import 'package:ponto/app/page/shared_page/list_page_base.dart';

class PontoFechamentoJornadaListPage extends ListPageBase<PontoFechamentoJornadaController> {
  const PontoFechamentoJornadaListPage({Key? key}) : super(key: key);

  @override
  List<Map<String, dynamic>> get mobileItems => controller.mobileItems;

  @override
  Map<String, dynamic> get mobileConfig => controller.mobileConfig;

  @override
  String get standardFieldForFilter => controller.standardFieldForFilter;

  @override
  List<Widget> additionalAppBarActions() {
    return [
      IconButton(
        tooltip: 'Gerar Arquivo AEJ',
        icon: const Icon(Icons.upload),
        color: Colors.lime,
        onPressed: controller.gerarArquivoAEJ,
      ),
      const SizedBox(width: 20,),
    ];
  }
}