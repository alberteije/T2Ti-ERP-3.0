import 'package:flutter/material.dart';
import 'package:ponto/app/controller/ponto_marcacao_controller.dart';
import 'package:ponto/app/page/shared_page/list_page_base.dart';

class PontoMarcacaoListPage extends ListPageBase<PontoMarcacaoController> {
  const PontoMarcacaoListPage({Key? key}) : super(key: key);

  @override
  List<Map<String, dynamic>> get mobileItems => controller.mobileItems;

  @override
  Map<String, dynamic> get mobileConfig => controller.mobileConfig;

  @override
  String get standardFieldForFilter => controller.standardFieldForFilter;

  @override
  List<Widget> additionalAppBarActions() {
    return [
      IconButton(
        tooltip: 'Importar Arquivo',
        icon: const Icon(Icons.download),
        color: Colors.lime,
        onPressed: controller.importarArquivo,
      ),
      const SizedBox(width: 20,),
    ];
  }
}