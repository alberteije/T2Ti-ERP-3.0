import 'package:flutter/material.dart';
import 'package:ponto/app/controller/ponto_relogio_controller.dart';
import 'package:ponto/app/page/shared_page/list_page_base.dart';

class PontoRelogioListPage extends ListPageBase<PontoRelogioController> {
  const PontoRelogioListPage({Key? key}) : super(key: key);

  @override
  List<Map<String, dynamic>> get mobileItems => controller.mobileItems;

  @override
  Map<String, dynamic> get mobileConfig => controller.mobileConfig;

  @override
  String get standardFieldForFilter => controller.standardFieldForFilter;
}