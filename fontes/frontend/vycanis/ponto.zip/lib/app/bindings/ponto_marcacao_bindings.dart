import 'package:get/get.dart';
import 'package:ponto/app/controller/ponto_marcacao_controller.dart';
import 'package:ponto/app/data/provider/api/ponto_marcacao_api_provider.dart';
import 'package:ponto/app/data/provider/drift/ponto_marcacao_drift_provider.dart';
import 'package:ponto/app/data/repository/ponto_marcacao_repository.dart';

class PontoMarcacaoBindings implements Binding {
	@override
	List<Bind> dependencies() {
		return [
			Bind.lazyPut<PontoMarcacaoController>(() => PontoMarcacaoController(
					repository: PontoMarcacaoRepository(pontoMarcacaoApiProvider: PontoMarcacaoApiProvider(), pontoMarcacaoDriftProvider: PontoMarcacaoDriftProvider()))),
		];
	}
}
