// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'produto_dao.dart';

// ignore_for_file: type=lint
mixin _$ProdutoDaoMixin on DatabaseAccessor<AppDatabase> {
  $ProdutosTable get produtos => attachedDatabase.produtos;
}
