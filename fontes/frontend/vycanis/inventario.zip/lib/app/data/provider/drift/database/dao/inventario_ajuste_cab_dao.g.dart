// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'inventario_ajuste_cab_dao.dart';

// ignore_for_file: type=lint
mixin _$InventarioAjusteCabDaoMixin on DatabaseAccessor<AppDatabase> {
  $InventarioAjusteCabsTable get inventarioAjusteCabs =>
      attachedDatabase.inventarioAjusteCabs;
  $ViewPessoaColaboradorsTable get viewPessoaColaboradors =>
      attachedDatabase.viewPessoaColaboradors;
  $InventarioAjusteDetsTable get inventarioAjusteDets =>
      attachedDatabase.inventarioAjusteDets;
  $ProdutosTable get produtos => attachedDatabase.produtos;
}
