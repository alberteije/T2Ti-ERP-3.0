import 'dart:convert';
import 'package:pluto_grid/pluto_grid.dart';
import 'package:inventario/app/data/model/model_imports.dart';

import 'package:inventario/app/data/domain/domain_imports.dart';

class InventarioContagemDetModel extends ModelBase {
  int? id;
  int? idInventarioContagemCab;
  int? idProduto;
  double? contagem01;
  double? contagem02;
  double? contagem03;
  String? fechadoContagem;
  double? quantidadeSistema;
  double? acuracidade;
  double? divergencia;
  ProdutoModel? produtoModel;

  InventarioContagemDetModel({
    this.id,
    this.idInventarioContagemCab,
    this.idProduto,
    this.contagem01,
    this.contagem02,
    this.contagem03,
    this.fechadoContagem = '01',
    this.quantidadeSistema,
    this.acuracidade,
    this.divergencia,
    ProdutoModel? produtoModel,
  }) {
    this.produtoModel = produtoModel ?? ProdutoModel();
  }

  static List<String> dbColumns = <String>[
    'id',
    'contagem01',
    'contagem02',
    'contagem03',
    'fechado_contagem',
    'quantidade_sistema',
    'acuracidade',
    'divergencia',
  ];

  static List<String> aliasColumns = <String>[
    'Id',
    'Contagem01',
    'Contagem02',
    'Contagem03',
    'Fechado Contagem',
    'Quantidade Sistema',
    'Acuracidade',
    'Divergencia',
  ];

  InventarioContagemDetModel.fromJson(Map<String, dynamic> jsonData) {
    id = jsonData['id'];
    idInventarioContagemCab = jsonData['idInventarioContagemCab'];
    idProduto = jsonData['idProduto'];
    contagem01 = jsonData['contagem01']?.toDouble();
    contagem02 = jsonData['contagem02']?.toDouble();
    contagem03 = jsonData['contagem03']?.toDouble();
    fechadoContagem = InventarioContagemDetDomain.getFechadoContagem(jsonData['fechadoContagem']);
    quantidadeSistema = jsonData['quantidadeSistema']?.toDouble();
    acuracidade = jsonData['acuracidade']?.toDouble();
    divergencia = jsonData['divergencia']?.toDouble();
    produtoModel = jsonData['produtoModel'] == null ? ProdutoModel() : ProdutoModel.fromJson(jsonData['produtoModel']);
  }

  Map<String, dynamic> get toJson {
    Map<String, dynamic> jsonData = <String, dynamic>{};

    jsonData['id'] = id != 0 ? id : null;
    jsonData['idInventarioContagemCab'] = idInventarioContagemCab != 0 ? idInventarioContagemCab : null;
    jsonData['idProduto'] = idProduto != 0 ? idProduto : null;
    jsonData['contagem01'] = contagem01;
    jsonData['contagem02'] = contagem02;
    jsonData['contagem03'] = contagem03;
    jsonData['fechadoContagem'] = InventarioContagemDetDomain.setFechadoContagem(fechadoContagem);
    jsonData['quantidadeSistema'] = quantidadeSistema;
    jsonData['acuracidade'] = acuracidade;
    jsonData['divergencia'] = divergencia;
    jsonData['produtoModel'] = produtoModel?.toJson;
    jsonData['produto'] = produtoModel?.nome ?? '';

    return jsonData;
  }

  String objectEncodeJson() {
    final jsonData = toJson;
    return json.encode(jsonData);
  }

  static InventarioContagemDetModel fromPlutoRow(PlutoRow row) {
    return InventarioContagemDetModel(
      id: row.cells['id']?.value,
      idInventarioContagemCab: row.cells['idInventarioContagemCab']?.value,
      idProduto: row.cells['idProduto']?.value,
      contagem01: row.cells['contagem01']?.value,
      contagem02: row.cells['contagem02']?.value,
      contagem03: row.cells['contagem03']?.value,
      fechadoContagem: row.cells['fechadoContagem']?.value,
      quantidadeSistema: row.cells['quantidadeSistema']?.value,
      acuracidade: row.cells['acuracidade']?.value,
      divergencia: row.cells['divergencia']?.value,
    );
  }

  PlutoRow toPlutoRow() {
    return PlutoRow(
      cells: {
        'tempId': PlutoCell(value: tempId),
        'id': PlutoCell(value: id ?? 0),
        'idInventarioContagemCab': PlutoCell(value: idInventarioContagemCab ?? 0),
        'idProduto': PlutoCell(value: idProduto ?? 0),
        'contagem01': PlutoCell(value: contagem01 ?? 0.0),
        'contagem02': PlutoCell(value: contagem02 ?? 0.0),
        'contagem03': PlutoCell(value: contagem03 ?? 0.0),
        'fechadoContagem': PlutoCell(value: fechadoContagem ?? ''),
        'quantidadeSistema': PlutoCell(value: quantidadeSistema ?? 0.0),
        'acuracidade': PlutoCell(value: acuracidade ?? 0.0),
        'divergencia': PlutoCell(value: divergencia ?? 0.0),
        'produto': PlutoCell(value: produtoModel?.nome ?? ''),
      },
    );
  }

  InventarioContagemDetModel clone() {
    return InventarioContagemDetModel(
      id: id,
      idInventarioContagemCab: idInventarioContagemCab,
      idProduto: idProduto,
      contagem01: contagem01,
      contagem02: contagem02,
      contagem03: contagem03,
      fechadoContagem: fechadoContagem,
      quantidadeSistema: quantidadeSistema,
      acuracidade: acuracidade,
      divergencia: divergencia,
      produtoModel: produtoModel?.clone(),
    );
  }


}