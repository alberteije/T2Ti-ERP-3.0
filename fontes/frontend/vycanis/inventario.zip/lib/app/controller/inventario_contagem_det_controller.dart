import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:pluto_grid/pluto_grid.dart';
import 'package:extended_masked_text/extended_masked_text.dart';
import 'package:inventario/app/page/shared_widget/input/input_imports.dart';
import 'package:inventario/app/routes/app_routes.dart';

import 'package:inventario/app/page/page_imports.dart';
import 'package:inventario/app/page/shared_widget/message_dialog.dart';
import 'package:inventario/app/page/grid_columns/grid_columns_imports.dart';
import 'package:inventario/app/controller/controller_imports.dart';
import 'package:inventario/app/data/model/model_imports.dart';

class InventarioContagemDetController extends ControllerBase<InventarioContagemDetModel, void> {

  InventarioContagemDetController() : super(repository: null) {
    dbColumns = InventarioContagemDetModel.dbColumns;
    aliasColumns = InventarioContagemDetModel.aliasColumns;
    gridColumns = inventarioContagemDetGridColumns();
    functionName = "inventario_contagem_det";
    screenTitle = "Produtos";
  }

  final _inventarioContagemDetModel = InventarioContagemDetModel().obs;
  InventarioContagemDetModel get inventarioContagemDetModel => _inventarioContagemDetModel.value;
  set inventarioContagemDetModel(value) => _inventarioContagemDetModel.value = value ?? InventarioContagemDetModel();

  List<InventarioContagemDetModel> get inventarioContagemDetModelList => Get.find<InventarioContagemCabController>().currentModel.inventarioContagemDetModelList ?? [];

  final _userMadeChanges = false.obs;
  get userMadeChanges => _userMadeChanges.value;
  set userMadeChanges(value) => _userMadeChanges.value = value;

  final _formWasChangedDetail = false.obs;
  bool get formWasChangedDetail => _formWasChangedDetail.value;
  set formWasChangedDetail(value) => _formWasChangedDetail.value = value;

  late PlutoGridStateManager _plutoGridStateManager;
  @override
  PlutoGridStateManager get plutoGridStateManager => _plutoGridStateManager;
  @override
  set plutoGridStateManager(value) => _plutoGridStateManager = value;

  final inventarioContagemDetScaffoldKey = GlobalKey<ScaffoldState>();
  final inventarioContagemDetFormKey = GlobalKey<FormState>();

  @override
  InventarioContagemDetModel createNewModel() => InventarioContagemDetModel();

  @override
  final standardFieldForFilter = InventarioContagemDetModel.aliasColumns[InventarioContagemDetModel.dbColumns.indexOf('contagem01')];

  final produtoModelController = TextEditingController();
  final contagem01Controller = MoneyMaskedTextController();
  final contagem02Controller = MoneyMaskedTextController();
  final contagem03Controller = MoneyMaskedTextController();
  final fechadoContagemController = CustomDropdownButtonController('01');
  final quantidadeSistemaController = MoneyMaskedTextController();
  final acuracidadeController = MoneyMaskedTextController();
  final divergenciaController = MoneyMaskedTextController();

  final Map<String, dynamic> mobileConfig = {
    'primaryColumns': ['contagem01'],
    'secondaryColumns': ['contagem02'],
  };

  List<Map<String, dynamic>> get mobileItems {
    return modelList.map((inventarioContagemDet) => inventarioContagemDet.toJson).toList();
  }

  @override
  List<PlutoRow> plutoRows() => List<PlutoRow>.from(inventarioContagemDetModelList.map((model) => model.toPlutoRow()));

  @override
  Future<void> getList({Filter? filter}) async {}

  @override
  void prepareForInsert() {
    isNewRecord = true;
    inventarioContagemDetModel = createNewModel();
    _resetForm();
    Get.to(() => InventarioContagemDetEditPage());
  }

  void _resetForm() {
    formWasChangedDetail = false;
    produtoModelController.text = '';
    contagem01Controller.updateValue(0);
    contagem02Controller.updateValue(0);
    contagem03Controller.updateValue(0);
    fechadoContagemController.selected = '01';
    quantidadeSistemaController.updateValue(0);
    acuracidadeController.updateValue(0);
    divergenciaController.updateValue(0);
  }

  @override
  void selectRowForEditing(PlutoRow? row) async {
    if (row == null) {
      showInfoSnackBar(message: 'message_select_one_to_edited'.tr);
      return;
    }

    selectRowForEditingByTempId(row.cells['tempId']?.value);
  }

  @override
  void selectRowForEditingById(int id) {}

  void selectRowForEditingByTempId(String tempId) {
		isNewRecord = false;
    final model = inventarioContagemDetModelList.firstWhere((m) => m.tempId == tempId);
    inventarioContagemDetModel = model.clone();
		inventarioContagemDetModel.tempId = model.tempId;
    updateControllersFromModel();
    Get.to(() => InventarioContagemDetEditPage());
  }

  void updateControllersFromModel() {
    produtoModelController.text = inventarioContagemDetModel.produtoModel?.nome?.toString() ?? '';
    contagem01Controller.updateValue(inventarioContagemDetModel.contagem01 ?? 0);
    contagem02Controller.updateValue(inventarioContagemDetModel.contagem02 ?? 0);
    contagem03Controller.updateValue(inventarioContagemDetModel.contagem03 ?? 0);
    fechadoContagemController.selected = inventarioContagemDetModel.fechadoContagem ?? '01';
    quantidadeSistemaController.updateValue(inventarioContagemDetModel.quantidadeSistema ?? 0);
    acuracidadeController.updateValue(inventarioContagemDetModel.acuracidade ?? 0);
    divergenciaController.updateValue(inventarioContagemDetModel.divergencia ?? 0);
    formWasChangedDetail = false;
  }

  @override
  Future<void> save() async {
    if (!inventarioContagemDetFormKey.currentState!.validate()) {
      showErrorSnackBar(message: 'validator_form_message'.tr);
      return;
    }

    if (formWasChangedDetail) {
      if (isNewRecord) {
        inventarioContagemDetModelList.insert(0, inventarioContagemDetModel.clone());
      } else {
        final index = inventarioContagemDetModelList.indexWhere((m) => m.tempId == inventarioContagemDetModel.tempId);
        if (index >= 0) {
          inventarioContagemDetModelList[index] = inventarioContagemDetModel.clone();
        }
      }

      userMadeChanges = true;
      loadData();
      Get.back(result: true);
    } else {
      Get.back();
    }
  }

  Future callProdutoLookup() async { 
		final lookupController = Get.find<LookupController>(); 
		lookupController.refreshItems(standardValue: '%'); 
		lookupController.title = '${'lookup_page_title'.tr} [Produto]'; 
		lookupController.route = '/produto/'; 
		lookupController.gridColumns = produtoGridColumns(isForLookup: true); 
		lookupController.aliasColumns = ProdutoModel.aliasColumns; 
		lookupController.dbColumns = ProdutoModel.dbColumns; 
		lookupController.standardColumn = ProdutoModel.aliasColumns[ProdutoModel.dbColumns.indexOf('nome')]; 

		final plutoRowResult = await Get.toNamed(Routes.lookupPage); 
		if (plutoRowResult != null) { 
			inventarioContagemDetModel.idProduto = plutoRowResult.cells['id']!.value; 
			inventarioContagemDetModel.produtoModel = ProdutoModel.fromPlutoRow(plutoRowResult); 
			produtoModelController.text = inventarioContagemDetModel.produtoModel?.nome ?? ''; 
			formWasChangedDetail = true; 
		}
	}


  @override
  Future deleteSelected() async {
    final currentRow = plutoGridStateManager.currentRow;
    if (currentRow == null) {
      showInfoSnackBar(message: 'message_select_one_to_delete'.tr);
      return null;
    }
    showDeleteDialog(() async {
      final id = currentRow.cells['id']?.value;
      final tempId = currentRow.cells['tempId']?.value;
      inventarioContagemDetModelList.removeWhere((model) => (id != 0 && model.id == id) || (id == 0 && model.tempId == tempId));
      plutoGridStateManager.removeCurrentRow();
      userMadeChanges = true;
    });
  }

  @override
  void preventDataLoss() {
    if (formWasChangedDetail) {
      showQuestionDialog('message_data_loss'.tr, () => Get.back());
    } else {
      formWasChangedDetail = false;
      Get.back();
    }
  }

  @override
  void onClose() {
    produtoModelController.dispose();
    contagem01Controller.dispose();
    contagem02Controller.dispose();
    contagem03Controller.dispose();
    fechadoContagemController.dispose();
    quantidadeSistemaController.dispose();
    acuracidadeController.dispose();
    divergenciaController.dispose();
  }

}