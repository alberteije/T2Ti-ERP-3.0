import 'package:flutter/material.dart';
import 'dart:math';
import 'package:get/get.dart';
import 'package:inventario/app/page/shared_widget/input/input_imports.dart';

import 'package:inventario/app/infra/infra_imports.dart';
import 'package:inventario/app/page/page_imports.dart';
import 'package:inventario/app/page/shared_widget/message_dialog.dart';
import 'package:inventario/app/page/grid_columns/grid_columns_imports.dart';
import 'package:inventario/app/routes/app_routes.dart';
import 'package:inventario/app/controller/controller_imports.dart';
import 'package:inventario/app/data/model/model_imports.dart';
import 'package:inventario/app/data/repository/inventario_contagem_cab_repository.dart';

class InventarioContagemCabController extends ControllerBase<InventarioContagemCabModel, InventarioContagemCabRepository> 
with GetSingleTickerProviderStateMixin {

  InventarioContagemCabController({required super.repository}) {
    dbColumns = InventarioContagemCabModel.dbColumns;
    aliasColumns = InventarioContagemCabModel.aliasColumns;
    gridColumns = inventarioContagemCabGridColumns();
    functionName = "inventario_contagem_cab";
    screenTitle = "Contagem de Produtos";
  }

  final inventarioContagemCabScaffoldKey = GlobalKey<ScaffoldState>();
  final inventarioContagemCabTabPageScaffoldKey = GlobalKey<ScaffoldState>();
  final inventarioContagemCabFormKey = GlobalKey<FormState>();
  late TabController tabController;
  String? mandatoryMessage;  

  @override
  InventarioContagemCabModel createNewModel() => InventarioContagemCabModel();

  @override
  final standardFieldForFilter = InventarioContagemCabModel.aliasColumns[InventarioContagemCabModel.dbColumns.indexOf('data_contagem')];

  final dataContagemController = DatePickerItemController(null);
  final estoqueAtualizadoController = CustomDropdownButtonController('S');
  final tipoController = CustomDropdownButtonController('Geral');

  final Map<String, dynamic> mobileConfig = {
    'primaryColumns': ['data_contagem'],
    'secondaryColumns': ['estoque_atualizado'],
  };

  List<Map<String, dynamic>> get mobileItems {
    return modelList.map((inventarioContagemCab) => inventarioContagemCab.toJson).toList();
  }

  @override
  void prepareForInsert() {
    isNewRecord = true;
    currentModel = createNewModel();
    _resetForm();
    tabController.animateTo(0);
    _configureChildrenControllers();
    Get.toNamed(Routes.inventarioContagemCabTabPage);
  }

  void _resetForm() {
    formWasChanged = false;
    dataContagemController.date = null;
    estoqueAtualizadoController.selected = 'S';
    tipoController.selected = 'Geral';
  }

  @override
  void selectRowForEditingById(int id) {
    final model = modelList.firstWhere((m) => m.id == id);
    currentModel = model.clone();
    updateControllersFromModel();

    tabController.animateTo(0);
    _configureChildrenControllers();
    Get.toNamed(Routes.inventarioContagemCabTabPage);
  }

  _configureChildrenControllers() {
    //Produtos
		Get.put<InventarioContagemDetController>(InventarioContagemDetController()); 
		final inventarioContagemDetController = Get.find<InventarioContagemDetController>(); 
		inventarioContagemDetController.userMadeChanges = false; 

  }
  
  void updateControllersFromModel() {
    dataContagemController.date = currentModel.dataContagem;
    estoqueAtualizadoController.selected = currentModel.estoqueAtualizado ?? 'S';
    tipoController.selected = currentModel.tipo ?? 'Geral';
    formWasChanged = false;
  }

  @override
  Future<void> save() async {
    if (!validateCurrentForm()) return;
    if (validateForms()) {
      if (userMadeChanges()) {
        final existingIndex = modelList.indexWhere((m) => m.id == currentModel.id);

        if (existingIndex >= 0) {
          modelList[existingIndex] = currentModel.clone();
        }

        final result = await repository.save(inventarioContagemCabModel: currentModel);
        if (result == null) return;

        if (existingIndex >= 0) {
          modelList[existingIndex] = result;
        } else {
          modelList.insert(0, result);
        }

        if (!GetPlatform.isMobile) {
          updateGridRow(result);
        }

        Get.back(result: true);
      } else {
        Get.back();
      }
    } 
  }


  List<Tab> tabItems = [
    Tab( 
			icon: Icon(iconDataList[Random().nextInt(10)]), 
			text: 'Contagem de Produtos', 
		),
    Tab( 
			icon: Icon(iconDataList[Random().nextInt(10)]), 
			text: 'Produtos', 
		),
  ];

  List<Widget> tabPages() {
    return [
      InventarioContagemCabEditPage(),
      const InventarioContagemDetListPage(),
    ];
  }

  @override
  void preventDataLoss() {
    if (userMadeChanges()) {
      showQuestionDialog('message_data_loss'.tr, () { 
        Get.back(); 
      });
    } else {
      Get.back();
    }
  }  

  bool userMadeChanges() {
    return
    formWasChanged 
    || 
		Get.find<InventarioContagemDetController>().userMadeChanges
    ;
  }

  void tabChange(int index) {
    validateCurrentForm();
  }

  bool validateCurrentForm() {
    return true;
  }

  bool validateForms() {
    return true;
  }

  @override
  void onInit() {
    super.onInit();
    tabController = TabController(vsync: this, length: tabItems.length);
  }
	
  @override
  void onClose() {
    tabController.dispose();
    dataContagemController.dispose();
    estoqueAtualizadoController.dispose();
    tipoController.dispose();
    super.onClose();
  }	
}