import 'package:flutter/material.dart';
import 'package:get/get.dart';

import 'package:cte/app/page/shared_widget/message_dialog.dart';
import 'package:cte/app/page/grid_columns/grid_columns_imports.dart';
import 'package:cte/app/routes/app_routes.dart';
import 'package:cte/app/controller/controller_imports.dart';
import 'package:cte/app/data/model/model_imports.dart';
import 'package:cte/app/data/repository/cte_rodoviario_lacre_repository.dart';

class CteRodoviarioLacreController extends ControllerBase<CteRodoviarioLacreModel, CteRodoviarioLacreRepository> {

  CteRodoviarioLacreController({required super.repository}) {
    dbColumns = CteRodoviarioLacreModel.dbColumns;
    aliasColumns = CteRodoviarioLacreModel.aliasColumns;
    gridColumns = cteRodoviarioLacreGridColumns();
    functionName = "cte_rodoviario_lacre";
    screenTitle = "Cte Rodoviario Lacre";
  }

  @override
  CteRodoviarioLacreModel createNewModel() => CteRodoviarioLacreModel();

  @override
  final standardFieldForFilter = CteRodoviarioLacreModel.aliasColumns[CteRodoviarioLacreModel.dbColumns.indexOf('numero')];

  final cteRodoviarioModelController = TextEditingController();
  final numeroController = TextEditingController();

  final Map<String, dynamic> mobileConfig = {
    'primaryColumns': ['numero'],
    'secondaryColumns': [],
  };

  List<Map<String, dynamic>> get mobileItems {
    return modelList.map((cteRodoviarioLacre) => cteRodoviarioLacre.toJson).toList();
  }

  @override
  void prepareForInsert() {
    isNewRecord = true;
    currentModel = createNewModel();
    _resetForm();
    Get.toNamed(Routes.cteRodoviarioLacreEditPage);
  }

  void _resetForm() {
    formWasChanged = false;
    cteRodoviarioModelController.text = '';
    numeroController.text = '';
  }

  @override
  void selectRowForEditingById(int id) {
    final model = modelList.firstWhere((m) => m.id == id);
    currentModel = model.clone();
    updateControllersFromModel();
    Get.toNamed(Routes.cteRodoviarioLacreEditPage);
  }

  void updateControllersFromModel() {
    cteRodoviarioModelController.text = currentModel.cteRodoviarioModel?.rntrc?.toString() ?? '';
    numeroController.text = currentModel.numero ?? '';
    formWasChanged = false;
  }

  @override
  Future<void> save() async {
    if (!formKey.currentState!.validate()) {
      showErrorSnackBar(message: 'validator_form_message'.tr);
      return;
    }

    final existingIndex = modelList.indexWhere((m) => m.id == currentModel.id);

    if (existingIndex >= 0) {
      modelList[existingIndex] = currentModel.clone();
    }

    final result = await repository.save(cteRodoviarioLacreModel: currentModel);
    if (result == null) return;

    if (existingIndex >= 0) {
      modelList[existingIndex] = result;
    } else {
      modelList.insert(0, result);
    }

    if (!GetPlatform.isMobile) {
      updateGridRow(result);
    }

    Get.back(result: true);
  }

  Future callCteRodoviarioLookup() async { 
		final lookupController = Get.find<LookupController>(); 
		lookupController.refreshItems(standardValue: '%'); 
		lookupController.title = '${'lookup_page_title'.tr} [Id Cte Rodoviario]'; 
		lookupController.route = '/cte-rodoviario/'; 
		lookupController.gridColumns = cteRodoviarioGridColumns(isForLookup: true); 
		lookupController.aliasColumns = CteRodoviarioModel.aliasColumns; 
		lookupController.dbColumns = CteRodoviarioModel.dbColumns; 
		lookupController.standardColumn = CteRodoviarioModel.aliasColumns[CteRodoviarioModel.dbColumns.indexOf('rntrc')]; 

		final plutoRowResult = await Get.toNamed(Routes.lookupPage); 
		if (plutoRowResult != null) { 
			currentModel.idCteRodoviario = plutoRowResult.cells['id']!.value; 
			currentModel.cteRodoviarioModel = CteRodoviarioModel.fromPlutoRow(plutoRowResult); 
			cteRodoviarioModelController.text = currentModel.cteRodoviarioModel?.rntrc ?? ''; 
			formWasChanged = true; 
		}
	}


  @override
  void onClose() {
    cteRodoviarioModelController.dispose();
    numeroController.dispose();
    super.onClose();
  }

}