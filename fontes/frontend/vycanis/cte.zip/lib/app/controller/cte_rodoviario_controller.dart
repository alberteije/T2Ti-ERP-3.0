import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:pluto_grid/pluto_grid.dart';
import 'package:extended_masked_text/extended_masked_text.dart';
import 'package:cte/app/page/shared_widget/input/input_imports.dart';

import 'package:cte/app/page/page_imports.dart';
import 'package:cte/app/page/shared_widget/message_dialog.dart';
import 'package:cte/app/page/grid_columns/grid_columns_imports.dart';
import 'package:cte/app/controller/controller_imports.dart';
import 'package:cte/app/data/model/model_imports.dart';

class CteRodoviarioController extends ControllerBase<CteRodoviarioModel, void> {

  CteRodoviarioController() : super(repository: null) {
    dbColumns = CteRodoviarioModel.dbColumns;
    aliasColumns = CteRodoviarioModel.aliasColumns;
    gridColumns = cteRodoviarioGridColumns();
    functionName = "cte_rodoviario";
    screenTitle = "Rodoviário";
  }

  final _cteRodoviarioModel = CteRodoviarioModel().obs;
  CteRodoviarioModel get cteRodoviarioModel => _cteRodoviarioModel.value;
  set cteRodoviarioModel(value) => _cteRodoviarioModel.value = value ?? CteRodoviarioModel();

  List<CteRodoviarioModel> get cteRodoviarioModelList => Get.find<CteCabecalhoController>().currentModel.cteRodoviarioModelList ?? [];

  final _userMadeChanges = false.obs;
  get userMadeChanges => _userMadeChanges.value;
  set userMadeChanges(value) => _userMadeChanges.value = value;

  final _formWasChangedDetail = false.obs;
  bool get formWasChangedDetail => _formWasChangedDetail.value;
  set formWasChangedDetail(value) => _formWasChangedDetail.value = value;

  late PlutoGridStateManager _plutoGridStateManager;
  @override
  PlutoGridStateManager get plutoGridStateManager => _plutoGridStateManager;
  @override
  set plutoGridStateManager(value) => _plutoGridStateManager = value;

  final cteRodoviarioScaffoldKey = GlobalKey<ScaffoldState>();
  final cteRodoviarioFormKey = GlobalKey<FormState>();

  @override
  CteRodoviarioModel createNewModel() => CteRodoviarioModel();

  @override
  final standardFieldForFilter = CteRodoviarioModel.aliasColumns[CteRodoviarioModel.dbColumns.indexOf('rntrc')];

  final rntrcController = TextEditingController();
  final dataPrevistaEntregaController = DatePickerItemController(null);
  final indicadorLotacaoController = TextEditingController();
  final ciotController = MoneyMaskedTextController(precision: 0, decimalSeparator: '', thousandSeparator: '');

  final Map<String, dynamic> mobileConfig = {
    'primaryColumns': ['rntrc'],
    'secondaryColumns': ['data_prevista_entrega'],
  };

  List<Map<String, dynamic>> get mobileItems {
    return modelList.map((cteRodoviario) => cteRodoviario.toJson).toList();
  }

  @override
  List<PlutoRow> plutoRows() => List<PlutoRow>.from(cteRodoviarioModelList.map((model) => model.toPlutoRow()));

  @override
  Future<void> getList({Filter? filter}) async {}

  @override
  void prepareForInsert() {
    isNewRecord = true;
    cteRodoviarioModel = createNewModel();
    _resetForm();
    Get.to(() => CteRodoviarioEditPage());
  }

  void _resetForm() {
    formWasChangedDetail = false;
    rntrcController.text = '';
    dataPrevistaEntregaController.date = null;
    indicadorLotacaoController.text = '';
    ciotController.updateValue(0);
  }

  @override
  void selectRowForEditing(PlutoRow? row) async {
    if (row == null) {
      showInfoSnackBar(message: 'message_select_one_to_edited'.tr);
      return;
    }

    selectRowForEditingByTempId(row.cells['tempId']?.value);
  }

  @override
  void selectRowForEditingById(int id) {}

  void selectRowForEditingByTempId(String tempId) {
		isNewRecord = false;
    final model = cteRodoviarioModelList.firstWhere((m) => m.tempId == tempId);
    cteRodoviarioModel = model.clone();
		cteRodoviarioModel.tempId = model.tempId;
    updateControllersFromModel();
    Get.to(() => CteRodoviarioEditPage());
  }

  void updateControllersFromModel() {
    rntrcController.text = cteRodoviarioModel.rntrc ?? '';
    dataPrevistaEntregaController.date = cteRodoviarioModel.dataPrevistaEntrega;
    indicadorLotacaoController.text = cteRodoviarioModel.indicadorLotacao ?? '';
    ciotController.updateValue((cteRodoviarioModel.ciot ?? 0).toDouble());
    formWasChangedDetail = false;
  }

  @override
  Future<void> save() async {
    if (!cteRodoviarioFormKey.currentState!.validate()) {
      showErrorSnackBar(message: 'validator_form_message'.tr);
      return;
    }

    if (formWasChangedDetail) {
      if (isNewRecord) {
        cteRodoviarioModelList.insert(0, cteRodoviarioModel.clone());
      } else {
        final index = cteRodoviarioModelList.indexWhere((m) => m.tempId == cteRodoviarioModel.tempId);
        if (index >= 0) {
          cteRodoviarioModelList[index] = cteRodoviarioModel.clone();
        }
      }

      userMadeChanges = true;
      loadData();
      Get.back(result: true);
    } else {
      Get.back();
    }
  }


  @override
  Future deleteSelected() async {
    final currentRow = plutoGridStateManager.currentRow;
    if (currentRow == null) {
      showInfoSnackBar(message: 'message_select_one_to_delete'.tr);
      return null;
    }
    showDeleteDialog(() async {
      final id = currentRow.cells['id']?.value;
      final tempId = currentRow.cells['tempId']?.value;
      cteRodoviarioModelList.removeWhere((model) => (id != 0 && model.id == id) || (id == 0 && model.tempId == tempId));
      plutoGridStateManager.removeCurrentRow();
      userMadeChanges = true;
    });
  }

  @override
  void preventDataLoss() {
    if (formWasChangedDetail) {
      showQuestionDialog('message_data_loss'.tr, () => Get.back());
    } else {
      formWasChangedDetail = false;
      Get.back();
    }
  }

  @override
  void onClose() {
    rntrcController.dispose();
    dataPrevistaEntregaController.dispose();
    indicadorLotacaoController.dispose();
    ciotController.dispose();
  }

}