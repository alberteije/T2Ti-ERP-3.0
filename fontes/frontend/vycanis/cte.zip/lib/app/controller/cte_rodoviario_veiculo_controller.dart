import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:extended_masked_text/extended_masked_text.dart';
import 'package:cte/app/page/shared_widget/input/input_imports.dart';

import 'package:cte/app/page/shared_widget/message_dialog.dart';
import 'package:cte/app/page/grid_columns/grid_columns_imports.dart';
import 'package:cte/app/routes/app_routes.dart';
import 'package:cte/app/controller/controller_imports.dart';
import 'package:cte/app/data/model/model_imports.dart';
import 'package:cte/app/data/repository/cte_rodoviario_veiculo_repository.dart';

class CteRodoviarioVeiculoController extends ControllerBase<CteRodoviarioVeiculoModel, CteRodoviarioVeiculoRepository> {

  CteRodoviarioVeiculoController({required super.repository}) {
    dbColumns = CteRodoviarioVeiculoModel.dbColumns;
    aliasColumns = CteRodoviarioVeiculoModel.aliasColumns;
    gridColumns = cteRodoviarioVeiculoGridColumns();
    functionName = "cte_rodoviario_veiculo";
    screenTitle = "Cte Rodoviario Veiculo";
  }

  @override
  CteRodoviarioVeiculoModel createNewModel() => CteRodoviarioVeiculoModel();

  @override
  final standardFieldForFilter = CteRodoviarioVeiculoModel.aliasColumns[CteRodoviarioVeiculoModel.dbColumns.indexOf('codigo_interno')];

  final cteRodoviarioModelController = TextEditingController();
  final codigoInternoController = TextEditingController();
  final renavamController = TextEditingController();
  final placaController = TextEditingController();
  final taraController = MoneyMaskedTextController(precision: 0, decimalSeparator: '', thousandSeparator: '');
  final capacidadeKgController = MoneyMaskedTextController(precision: 0, decimalSeparator: '', thousandSeparator: '');
  final capacidadeM3Controller = MoneyMaskedTextController(precision: 0, decimalSeparator: '', thousandSeparator: '');
  final tipoPropriedadeController = TextEditingController();
  final tipoVeiculoController = TextEditingController();
  final tipoRodadoController = TextEditingController();
  final tipoCarroceriaController = TextEditingController();
  final ufController = CustomDropdownButtonController('AC');
  final proprietarioCpfController = MaskedTextController(mask: '000.000.000-00',);
  final proprietarioCnpjController = MaskedTextController(mask: '00.000.000/0000-00',);
  final proprietarioRntrcController = TextEditingController();
  final proprietarioNomeController = TextEditingController();
  final proprietarioIeController = TextEditingController();
  final proprietarioUfController = CustomDropdownButtonController('AC');
  final proprietarioTipoController = CustomDropdownButtonController('0-TAC – Agregado');

  final Map<String, dynamic> mobileConfig = {
    'primaryColumns': ['codigo_interno'],
    'secondaryColumns': ['renavam'],
  };

  List<Map<String, dynamic>> get mobileItems {
    return modelList.map((cteRodoviarioVeiculo) => cteRodoviarioVeiculo.toJson).toList();
  }

  @override
  void prepareForInsert() {
    isNewRecord = true;
    currentModel = createNewModel();
    _resetForm();
    Get.toNamed(Routes.cteRodoviarioVeiculoEditPage);
  }

  void _resetForm() {
    formWasChanged = false;
    cteRodoviarioModelController.text = '';
    codigoInternoController.text = '';
    renavamController.text = '';
    placaController.text = '';
    taraController.updateValue(0);
    capacidadeKgController.updateValue(0);
    capacidadeM3Controller.updateValue(0);
    tipoPropriedadeController.text = '';
    tipoVeiculoController.text = '';
    tipoRodadoController.text = '';
    tipoCarroceriaController.text = '';
    ufController.selected = 'AC';
    proprietarioCpfController.text = '';
    proprietarioCnpjController.text = '';
    proprietarioRntrcController.text = '';
    proprietarioNomeController.text = '';
    proprietarioIeController.text = '';
    proprietarioUfController.selected = 'AC';
    proprietarioTipoController.selected = '0-TAC – Agregado';
  }

  @override
  void selectRowForEditingById(int id) {
    final model = modelList.firstWhere((m) => m.id == id);
    currentModel = model.clone();
    updateControllersFromModel();
    Get.toNamed(Routes.cteRodoviarioVeiculoEditPage);
  }

  void updateControllersFromModel() {
    cteRodoviarioModelController.text = currentModel.cteRodoviarioModel?.rntrc?.toString() ?? '';
    codigoInternoController.text = currentModel.codigoInterno ?? '';
    renavamController.text = currentModel.renavam ?? '';
    placaController.text = currentModel.placa ?? '';
    taraController.updateValue((currentModel.tara ?? 0).toDouble());
    capacidadeKgController.updateValue((currentModel.capacidadeKg ?? 0).toDouble());
    capacidadeM3Controller.updateValue((currentModel.capacidadeM3 ?? 0).toDouble());
    tipoPropriedadeController.text = currentModel.tipoPropriedade ?? '';
    tipoVeiculoController.text = currentModel.tipoVeiculo ?? '';
    tipoRodadoController.text = currentModel.tipoRodado ?? '';
    tipoCarroceriaController.text = currentModel.tipoCarroceria ?? '';
    ufController.selected = currentModel.uf ?? 'AC';
    proprietarioCpfController.text = currentModel.proprietarioCpf ?? '';
    proprietarioCnpjController.text = currentModel.proprietarioCnpj ?? '';
    proprietarioRntrcController.text = currentModel.proprietarioRntrc ?? '';
    proprietarioNomeController.text = currentModel.proprietarioNome ?? '';
    proprietarioIeController.text = currentModel.proprietarioIe ?? '';
    proprietarioUfController.selected = currentModel.proprietarioUf ?? 'AC';
    proprietarioTipoController.selected = currentModel.proprietarioTipo ?? '0-TAC – Agregado';
    formWasChanged = false;
  }

  @override
  Future<void> save() async {
    if (!formKey.currentState!.validate()) {
      showErrorSnackBar(message: 'validator_form_message'.tr);
      return;
    }

    final existingIndex = modelList.indexWhere((m) => m.id == currentModel.id);

    if (existingIndex >= 0) {
      modelList[existingIndex] = currentModel.clone();
    }

    final result = await repository.save(cteRodoviarioVeiculoModel: currentModel);
    if (result == null) return;

    if (existingIndex >= 0) {
      modelList[existingIndex] = result;
    } else {
      modelList.insert(0, result);
    }

    if (!GetPlatform.isMobile) {
      updateGridRow(result);
    }

    Get.back(result: true);
  }

  Future callCteRodoviarioLookup() async { 
		final lookupController = Get.find<LookupController>(); 
		lookupController.refreshItems(standardValue: '%'); 
		lookupController.title = '${'lookup_page_title'.tr} [Id Cte Rodoviario]'; 
		lookupController.route = '/cte-rodoviario/'; 
		lookupController.gridColumns = cteRodoviarioGridColumns(isForLookup: true); 
		lookupController.aliasColumns = CteRodoviarioModel.aliasColumns; 
		lookupController.dbColumns = CteRodoviarioModel.dbColumns; 
		lookupController.standardColumn = CteRodoviarioModel.aliasColumns[CteRodoviarioModel.dbColumns.indexOf('rntrc')]; 

		final plutoRowResult = await Get.toNamed(Routes.lookupPage); 
		if (plutoRowResult != null) { 
			currentModel.idCteRodoviario = plutoRowResult.cells['id']!.value; 
			currentModel.cteRodoviarioModel = CteRodoviarioModel.fromPlutoRow(plutoRowResult); 
			cteRodoviarioModelController.text = currentModel.cteRodoviarioModel?.rntrc ?? ''; 
			formWasChanged = true; 
		}
	}


  @override
  void onClose() {
    cteRodoviarioModelController.dispose();
    codigoInternoController.dispose();
    renavamController.dispose();
    placaController.dispose();
    taraController.dispose();
    capacidadeKgController.dispose();
    capacidadeM3Controller.dispose();
    tipoPropriedadeController.dispose();
    tipoVeiculoController.dispose();
    tipoRodadoController.dispose();
    tipoCarroceriaController.dispose();
    ufController.dispose();
    proprietarioCpfController.dispose();
    proprietarioCnpjController.dispose();
    proprietarioRntrcController.dispose();
    proprietarioNomeController.dispose();
    proprietarioIeController.dispose();
    proprietarioUfController.dispose();
    proprietarioTipoController.dispose();
    super.onClose();
  }

}