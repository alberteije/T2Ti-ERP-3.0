import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:cte/app/page/shared_widget/input/input_imports.dart';

import 'package:cte/app/page/shared_widget/message_dialog.dart';
import 'package:cte/app/page/grid_columns/grid_columns_imports.dart';
import 'package:cte/app/routes/app_routes.dart';
import 'package:cte/app/controller/controller_imports.dart';
import 'package:cte/app/data/model/model_imports.dart';
import 'package:cte/app/data/repository/cte_informacao_nf_transporte_repository.dart';

class CteInformacaoNfTransporteController extends ControllerBase<CteInformacaoNfTransporteModel, CteInformacaoNfTransporteRepository> {

  CteInformacaoNfTransporteController({required super.repository}) {
    dbColumns = CteInformacaoNfTransporteModel.dbColumns;
    aliasColumns = CteInformacaoNfTransporteModel.aliasColumns;
    gridColumns = cteInformacaoNfTransporteGridColumns();
    functionName = "cte_informacao_nf_transporte";
    screenTitle = "Cte Informacao Nf Transporte";
  }

  @override
  CteInformacaoNfTransporteModel createNewModel() => CteInformacaoNfTransporteModel();

  @override
  final standardFieldForFilter = CteInformacaoNfTransporteModel.aliasColumns[CteInformacaoNfTransporteModel.dbColumns.indexOf('tipo_unidade_transporte')];

  final cteInformacaoNfOutrosModelController = TextEditingController();
  final tipoUnidadeTransporteController = CustomDropdownButtonController('1 - Rodoviário Tração');
  final idUnidadeTransporteController = TextEditingController();

  final Map<String, dynamic> mobileConfig = {
    'primaryColumns': ['tipo_unidade_transporte'],
    'secondaryColumns': ['id_unidade_transporte'],
  };

  List<Map<String, dynamic>> get mobileItems {
    return modelList.map((cteInformacaoNfTransporte) => cteInformacaoNfTransporte.toJson).toList();
  }

  @override
  void prepareForInsert() {
    isNewRecord = true;
    currentModel = createNewModel();
    _resetForm();
    Get.toNamed(Routes.cteInformacaoNfTransporteEditPage);
  }

  void _resetForm() {
    formWasChanged = false;
    cteInformacaoNfOutrosModelController.text = '';
    tipoUnidadeTransporteController.selected = '1 - Rodoviário Tração';
    idUnidadeTransporteController.text = '';
  }

  @override
  void selectRowForEditingById(int id) {
    final model = modelList.firstWhere((m) => m.id == id);
    currentModel = model.clone();
    updateControllersFromModel();
    Get.toNamed(Routes.cteInformacaoNfTransporteEditPage);
  }

  void updateControllersFromModel() {
    cteInformacaoNfOutrosModelController.text = currentModel.cteInformacaoNfOutrosModel?.numero?.toString() ?? '';
    tipoUnidadeTransporteController.selected = currentModel.tipoUnidadeTransporte ?? '1 - Rodoviário Tração';
    idUnidadeTransporteController.text = currentModel.idUnidadeTransporte ?? '';
    formWasChanged = false;
  }

  @override
  Future<void> save() async {
    if (!formKey.currentState!.validate()) {
      showErrorSnackBar(message: 'validator_form_message'.tr);
      return;
    }

    final existingIndex = modelList.indexWhere((m) => m.id == currentModel.id);

    if (existingIndex >= 0) {
      modelList[existingIndex] = currentModel.clone();
    }

    final result = await repository.save(cteInformacaoNfTransporteModel: currentModel);
    if (result == null) return;

    if (existingIndex >= 0) {
      modelList[existingIndex] = result;
    } else {
      modelList.insert(0, result);
    }

    if (!GetPlatform.isMobile) {
      updateGridRow(result);
    }

    Get.back(result: true);
  }

  Future callCteInformacaoNfOutrosLookup() async { 
		final lookupController = Get.find<LookupController>(); 
		lookupController.refreshItems(standardValue: '%'); 
		lookupController.title = '${'lookup_page_title'.tr} [Id Cte Informacao Nf]'; 
		lookupController.route = '/cte-informacao-nf-outros/'; 
		lookupController.gridColumns = cteInformacaoNfOutrosGridColumns(isForLookup: true); 
		lookupController.aliasColumns = CteInformacaoNfOutrosModel.aliasColumns; 
		lookupController.dbColumns = CteInformacaoNfOutrosModel.dbColumns; 
		lookupController.standardColumn = CteInformacaoNfOutrosModel.aliasColumns[CteInformacaoNfOutrosModel.dbColumns.indexOf('numero')]; 

		final plutoRowResult = await Get.toNamed(Routes.lookupPage); 
		if (plutoRowResult != null) { 
			currentModel.idCteInformacaoNf = plutoRowResult.cells['id']!.value; 
			currentModel.cteInformacaoNfOutrosModel = CteInformacaoNfOutrosModel.fromPlutoRow(plutoRowResult); 
			cteInformacaoNfOutrosModelController.text = currentModel.cteInformacaoNfOutrosModel?.numero ?? ''; 
			formWasChanged = true; 
		}
	}


  @override
  void onClose() {
    cteInformacaoNfOutrosModelController.dispose();
    tipoUnidadeTransporteController.dispose();
    idUnidadeTransporteController.dispose();
    super.onClose();
  }

}