import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:pluto_grid/pluto_grid.dart';
import 'package:extended_masked_text/extended_masked_text.dart';

import 'package:cte/app/page/page_imports.dart';
import 'package:cte/app/page/shared_widget/message_dialog.dart';
import 'package:cte/app/page/grid_columns/grid_columns_imports.dart';
import 'package:cte/app/controller/controller_imports.dart';
import 'package:cte/app/data/model/model_imports.dart';

class CteFaturaController extends ControllerBase<CteFaturaModel, void> {

  CteFaturaController() : super(repository: null) {
    dbColumns = CteFaturaModel.dbColumns;
    aliasColumns = CteFaturaModel.aliasColumns;
    gridColumns = cteFaturaGridColumns();
    functionName = "cte_fatura";
    screenTitle = "Fatura";
  }

  final _cteFaturaModel = CteFaturaModel().obs;
  CteFaturaModel get cteFaturaModel => _cteFaturaModel.value;
  set cteFaturaModel(value) => _cteFaturaModel.value = value ?? CteFaturaModel();

  List<CteFaturaModel> get cteFaturaModelList => Get.find<CteCabecalhoController>().currentModel.cteFaturaModelList ?? [];

  final _userMadeChanges = false.obs;
  get userMadeChanges => _userMadeChanges.value;
  set userMadeChanges(value) => _userMadeChanges.value = value;

  final _formWasChangedDetail = false.obs;
  bool get formWasChangedDetail => _formWasChangedDetail.value;
  set formWasChangedDetail(value) => _formWasChangedDetail.value = value;

  late PlutoGridStateManager _plutoGridStateManager;
  @override
  PlutoGridStateManager get plutoGridStateManager => _plutoGridStateManager;
  @override
  set plutoGridStateManager(value) => _plutoGridStateManager = value;

  final cteFaturaScaffoldKey = GlobalKey<ScaffoldState>();
  final cteFaturaFormKey = GlobalKey<FormState>();

  @override
  CteFaturaModel createNewModel() => CteFaturaModel();

  @override
  final standardFieldForFilter = CteFaturaModel.aliasColumns[CteFaturaModel.dbColumns.indexOf('numero')];

  final numeroController = TextEditingController();
  final valorOriginalController = MoneyMaskedTextController();
  final valorDescontoController = MoneyMaskedTextController();
  final valorLiquidoController = MoneyMaskedTextController();

  final Map<String, dynamic> mobileConfig = {
    'primaryColumns': ['numero'],
    'secondaryColumns': ['valor_original'],
  };

  List<Map<String, dynamic>> get mobileItems {
    return modelList.map((cteFatura) => cteFatura.toJson).toList();
  }

  @override
  List<PlutoRow> plutoRows() => List<PlutoRow>.from(cteFaturaModelList.map((model) => model.toPlutoRow()));

  @override
  Future<void> getList({Filter? filter}) async {}

  @override
  void prepareForInsert() {
    isNewRecord = true;
    cteFaturaModel = createNewModel();
    _resetForm();
    Get.to(() => CteFaturaEditPage());
  }

  void _resetForm() {
    formWasChangedDetail = false;
    numeroController.text = '';
    valorOriginalController.updateValue(0);
    valorDescontoController.updateValue(0);
    valorLiquidoController.updateValue(0);
  }

  @override
  void selectRowForEditing(PlutoRow? row) async {
    if (row == null) {
      showInfoSnackBar(message: 'message_select_one_to_edited'.tr);
      return;
    }

    selectRowForEditingByTempId(row.cells['tempId']?.value);
  }

  @override
  void selectRowForEditingById(int id) {}

  void selectRowForEditingByTempId(String tempId) {
		isNewRecord = false;
    final model = cteFaturaModelList.firstWhere((m) => m.tempId == tempId);
    cteFaturaModel = model.clone();
		cteFaturaModel.tempId = model.tempId;
    updateControllersFromModel();
    Get.to(() => CteFaturaEditPage());
  }

  void updateControllersFromModel() {
    numeroController.text = cteFaturaModel.numero ?? '';
    valorOriginalController.updateValue(cteFaturaModel.valorOriginal ?? 0);
    valorDescontoController.updateValue(cteFaturaModel.valorDesconto ?? 0);
    valorLiquidoController.updateValue(cteFaturaModel.valorLiquido ?? 0);
    formWasChangedDetail = false;
  }

  @override
  Future<void> save() async {
    if (!cteFaturaFormKey.currentState!.validate()) {
      showErrorSnackBar(message: 'validator_form_message'.tr);
      return;
    }

    if (formWasChangedDetail) {
      if (isNewRecord) {
        cteFaturaModelList.insert(0, cteFaturaModel.clone());
      } else {
        final index = cteFaturaModelList.indexWhere((m) => m.tempId == cteFaturaModel.tempId);
        if (index >= 0) {
          cteFaturaModelList[index] = cteFaturaModel.clone();
        }
      }

      userMadeChanges = true;
      loadData();
      Get.back(result: true);
    } else {
      Get.back();
    }
  }


  @override
  Future deleteSelected() async {
    final currentRow = plutoGridStateManager.currentRow;
    if (currentRow == null) {
      showInfoSnackBar(message: 'message_select_one_to_delete'.tr);
      return null;
    }
    showDeleteDialog(() async {
      final id = currentRow.cells['id']?.value;
      final tempId = currentRow.cells['tempId']?.value;
      cteFaturaModelList.removeWhere((model) => (id != 0 && model.id == id) || (id == 0 && model.tempId == tempId));
      plutoGridStateManager.removeCurrentRow();
      userMadeChanges = true;
    });
  }

  @override
  void preventDataLoss() {
    if (formWasChangedDetail) {
      showQuestionDialog('message_data_loss'.tr, () => Get.back());
    } else {
      formWasChangedDetail = false;
      Get.back();
    }
  }

  @override
  void onClose() {
    numeroController.dispose();
    valorOriginalController.dispose();
    valorDescontoController.dispose();
    valorLiquidoController.dispose();
  }

}