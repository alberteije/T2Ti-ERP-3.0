import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:extended_masked_text/extended_masked_text.dart';

import 'package:cte/app/page/shared_widget/message_dialog.dart';
import 'package:cte/app/page/grid_columns/grid_columns_imports.dart';
import 'package:cte/app/routes/app_routes.dart';
import 'package:cte/app/controller/controller_imports.dart';
import 'package:cte/app/data/model/model_imports.dart';
import 'package:cte/app/data/repository/cte_rodoviario_motorista_repository.dart';

class CteRodoviarioMotoristaController extends ControllerBase<CteRodoviarioMotoristaModel, CteRodoviarioMotoristaRepository> {

  CteRodoviarioMotoristaController({required super.repository}) {
    dbColumns = CteRodoviarioMotoristaModel.dbColumns;
    aliasColumns = CteRodoviarioMotoristaModel.aliasColumns;
    gridColumns = cteRodoviarioMotoristaGridColumns();
    functionName = "cte_rodoviario_motorista";
    screenTitle = "Cte Rodoviario Motorista";
  }

  @override
  CteRodoviarioMotoristaModel createNewModel() => CteRodoviarioMotoristaModel();

  @override
  final standardFieldForFilter = CteRodoviarioMotoristaModel.aliasColumns[CteRodoviarioMotoristaModel.dbColumns.indexOf('nome')];

  final cteRodoviarioModelController = TextEditingController();
  final nomeController = TextEditingController();
  final cpfController = MaskedTextController(mask: '000.000.000-00',);

  final Map<String, dynamic> mobileConfig = {
    'primaryColumns': ['nome'],
    'secondaryColumns': ['cpf'],
  };

  List<Map<String, dynamic>> get mobileItems {
    return modelList.map((cteRodoviarioMotorista) => cteRodoviarioMotorista.toJson).toList();
  }

  @override
  void prepareForInsert() {
    isNewRecord = true;
    currentModel = createNewModel();
    _resetForm();
    Get.toNamed(Routes.cteRodoviarioMotoristaEditPage);
  }

  void _resetForm() {
    formWasChanged = false;
    cteRodoviarioModelController.text = '';
    nomeController.text = '';
    cpfController.text = '';
  }

  @override
  void selectRowForEditingById(int id) {
    final model = modelList.firstWhere((m) => m.id == id);
    currentModel = model.clone();
    updateControllersFromModel();
    Get.toNamed(Routes.cteRodoviarioMotoristaEditPage);
  }

  void updateControllersFromModel() {
    cteRodoviarioModelController.text = currentModel.cteRodoviarioModel?.rntrc?.toString() ?? '';
    nomeController.text = currentModel.nome ?? '';
    cpfController.text = currentModel.cpf ?? '';
    formWasChanged = false;
  }

  @override
  Future<void> save() async {
    if (!formKey.currentState!.validate()) {
      showErrorSnackBar(message: 'validator_form_message'.tr);
      return;
    }

    final existingIndex = modelList.indexWhere((m) => m.id == currentModel.id);

    if (existingIndex >= 0) {
      modelList[existingIndex] = currentModel.clone();
    }

    final result = await repository.save(cteRodoviarioMotoristaModel: currentModel);
    if (result == null) return;

    if (existingIndex >= 0) {
      modelList[existingIndex] = result;
    } else {
      modelList.insert(0, result);
    }

    if (!GetPlatform.isMobile) {
      updateGridRow(result);
    }

    Get.back(result: true);
  }

  Future callCteRodoviarioLookup() async { 
		final lookupController = Get.find<LookupController>(); 
		lookupController.refreshItems(standardValue: '%'); 
		lookupController.title = '${'lookup_page_title'.tr} [Id Cte Rodoviario]'; 
		lookupController.route = '/cte-rodoviario/'; 
		lookupController.gridColumns = cteRodoviarioGridColumns(isForLookup: true); 
		lookupController.aliasColumns = CteRodoviarioModel.aliasColumns; 
		lookupController.dbColumns = CteRodoviarioModel.dbColumns; 
		lookupController.standardColumn = CteRodoviarioModel.aliasColumns[CteRodoviarioModel.dbColumns.indexOf('rntrc')]; 

		final plutoRowResult = await Get.toNamed(Routes.lookupPage); 
		if (plutoRowResult != null) { 
			currentModel.idCteRodoviario = plutoRowResult.cells['id']!.value; 
			currentModel.cteRodoviarioModel = CteRodoviarioModel.fromPlutoRow(plutoRowResult); 
			cteRodoviarioModelController.text = currentModel.cteRodoviarioModel?.rntrc ?? ''; 
			formWasChanged = true; 
		}
	}


  @override
  void onClose() {
    cteRodoviarioModelController.dispose();
    nomeController.dispose();
    cpfController.dispose();
    super.onClose();
  }

}