import 'package:flutter/material.dart';
import 'package:get/get.dart';

import 'package:cte/app/page/shared_widget/message_dialog.dart';
import 'package:cte/app/page/grid_columns/grid_columns_imports.dart';
import 'package:cte/app/routes/app_routes.dart';
import 'package:cte/app/controller/controller_imports.dart';
import 'package:cte/app/data/model/model_imports.dart';
import 'package:cte/app/data/repository/cte_inf_nf_transporte_lacre_repository.dart';

class CteInfNfTransporteLacreController extends ControllerBase<CteInfNfTransporteLacreModel, CteInfNfTransporteLacreRepository> {

  CteInfNfTransporteLacreController({required super.repository}) {
    dbColumns = CteInfNfTransporteLacreModel.dbColumns;
    aliasColumns = CteInfNfTransporteLacreModel.aliasColumns;
    gridColumns = cteInfNfTransporteLacreGridColumns();
    functionName = "cte_inf_nf_transporte_lacre";
    screenTitle = "Cte Inf Nf Transporte Lacre";
  }

  @override
  CteInfNfTransporteLacreModel createNewModel() => CteInfNfTransporteLacreModel();

  @override
  final standardFieldForFilter = CteInfNfTransporteLacreModel.aliasColumns[CteInfNfTransporteLacreModel.dbColumns.indexOf('numero')];

  final cteInformacaoNfTransporteModelController = TextEditingController();
  final numeroController = TextEditingController();

  final Map<String, dynamic> mobileConfig = {
    'primaryColumns': ['numero'],
    'secondaryColumns': [],
  };

  List<Map<String, dynamic>> get mobileItems {
    return modelList.map((cteInfNfTransporteLacre) => cteInfNfTransporteLacre.toJson).toList();
  }

  @override
  void prepareForInsert() {
    isNewRecord = true;
    currentModel = createNewModel();
    _resetForm();
    Get.toNamed(Routes.cteInfNfTransporteLacreEditPage);
  }

  void _resetForm() {
    formWasChanged = false;
    cteInformacaoNfTransporteModelController.text = '';
    numeroController.text = '';
  }

  @override
  void selectRowForEditingById(int id) {
    final model = modelList.firstWhere((m) => m.id == id);
    currentModel = model.clone();
    updateControllersFromModel();
    Get.toNamed(Routes.cteInfNfTransporteLacreEditPage);
  }

  void updateControllersFromModel() {
    cteInformacaoNfTransporteModelController.text = currentModel.cteInformacaoNfTransporteModel?.tipoUnidadeTransporte?.toString() ?? '';
    numeroController.text = currentModel.numero ?? '';
    formWasChanged = false;
  }

  @override
  Future<void> save() async {
    if (!formKey.currentState!.validate()) {
      showErrorSnackBar(message: 'validator_form_message'.tr);
      return;
    }

    final existingIndex = modelList.indexWhere((m) => m.id == currentModel.id);

    if (existingIndex >= 0) {
      modelList[existingIndex] = currentModel.clone();
    }

    final result = await repository.save(cteInfNfTransporteLacreModel: currentModel);
    if (result == null) return;

    if (existingIndex >= 0) {
      modelList[existingIndex] = result;
    } else {
      modelList.insert(0, result);
    }

    if (!GetPlatform.isMobile) {
      updateGridRow(result);
    }

    Get.back(result: true);
  }

  Future callCteInformacaoNfTransporteLookup() async { 
		final lookupController = Get.find<LookupController>(); 
		lookupController.refreshItems(standardValue: '%'); 
		lookupController.title = '${'lookup_page_title'.tr} [Id Cte Informacao Nf Transporte]'; 
		lookupController.route = '/cte-informacao-nf-transporte/'; 
		lookupController.gridColumns = cteInformacaoNfTransporteGridColumns(isForLookup: true); 
		lookupController.aliasColumns = CteInformacaoNfTransporteModel.aliasColumns; 
		lookupController.dbColumns = CteInformacaoNfTransporteModel.dbColumns; 
		lookupController.standardColumn = CteInformacaoNfTransporteModel.aliasColumns[CteInformacaoNfTransporteModel.dbColumns.indexOf('tipoUnidadeTransporte')]; 

		final plutoRowResult = await Get.toNamed(Routes.lookupPage); 
		if (plutoRowResult != null) { 
			currentModel.idCteInformacaoNfTransporte = plutoRowResult.cells['id']!.value; 
			currentModel.cteInformacaoNfTransporteModel = CteInformacaoNfTransporteModel.fromPlutoRow(plutoRowResult); 
			cteInformacaoNfTransporteModelController.text = currentModel.cteInformacaoNfTransporteModel?.tipoUnidadeTransporte ?? ''; 
			formWasChanged = true; 
		}
	}


  @override
  void onClose() {
    cteInformacaoNfTransporteModelController.dispose();
    numeroController.dispose();
    super.onClose();
  }

}