import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:pluto_grid/pluto_grid.dart';
import 'package:extended_masked_text/extended_masked_text.dart';
import 'package:cte/app/page/shared_widget/input/input_imports.dart';

import 'package:cte/app/page/page_imports.dart';
import 'package:cte/app/page/shared_widget/message_dialog.dart';
import 'package:cte/app/page/grid_columns/grid_columns_imports.dart';
import 'package:cte/app/controller/controller_imports.dart';
import 'package:cte/app/data/model/model_imports.dart';

class CteDutoviarioController extends ControllerBase<CteDutoviarioModel, void> {

  CteDutoviarioController() : super(repository: null) {
    dbColumns = CteDutoviarioModel.dbColumns;
    aliasColumns = CteDutoviarioModel.aliasColumns;
    gridColumns = cteDutoviarioGridColumns();
    functionName = "cte_dutoviario";
    screenTitle = "Dutoviário";
  }

  final _cteDutoviarioModel = CteDutoviarioModel().obs;
  CteDutoviarioModel get cteDutoviarioModel => _cteDutoviarioModel.value;
  set cteDutoviarioModel(value) => _cteDutoviarioModel.value = value ?? CteDutoviarioModel();

  List<CteDutoviarioModel> get cteDutoviarioModelList => Get.find<CteCabecalhoController>().currentModel.cteDutoviarioModelList ?? [];

  final _userMadeChanges = false.obs;
  get userMadeChanges => _userMadeChanges.value;
  set userMadeChanges(value) => _userMadeChanges.value = value;

  final _formWasChangedDetail = false.obs;
  bool get formWasChangedDetail => _formWasChangedDetail.value;
  set formWasChangedDetail(value) => _formWasChangedDetail.value = value;

  late PlutoGridStateManager _plutoGridStateManager;
  @override
  PlutoGridStateManager get plutoGridStateManager => _plutoGridStateManager;
  @override
  set plutoGridStateManager(value) => _plutoGridStateManager = value;

  final cteDutoviarioScaffoldKey = GlobalKey<ScaffoldState>();
  final cteDutoviarioFormKey = GlobalKey<FormState>();

  @override
  CteDutoviarioModel createNewModel() => CteDutoviarioModel();

  @override
  final standardFieldForFilter = CteDutoviarioModel.aliasColumns[CteDutoviarioModel.dbColumns.indexOf('valor_tarifa')];

  final valorTarifaController = MoneyMaskedTextController();
  final dataInicioController = DatePickerItemController(null);
  final dataFimController = DatePickerItemController(null);

  final Map<String, dynamic> mobileConfig = {
    'primaryColumns': ['valor_tarifa'],
    'secondaryColumns': ['data_inicio'],
  };

  List<Map<String, dynamic>> get mobileItems {
    return modelList.map((cteDutoviario) => cteDutoviario.toJson).toList();
  }

  @override
  List<PlutoRow> plutoRows() => List<PlutoRow>.from(cteDutoviarioModelList.map((model) => model.toPlutoRow()));

  @override
  Future<void> getList({Filter? filter}) async {}

  @override
  void prepareForInsert() {
    isNewRecord = true;
    cteDutoviarioModel = createNewModel();
    _resetForm();
    Get.to(() => CteDutoviarioEditPage());
  }

  void _resetForm() {
    formWasChangedDetail = false;
    valorTarifaController.updateValue(0);
    dataInicioController.date = null;
    dataFimController.date = null;
  }

  @override
  void selectRowForEditing(PlutoRow? row) async {
    if (row == null) {
      showInfoSnackBar(message: 'message_select_one_to_edited'.tr);
      return;
    }

    selectRowForEditingByTempId(row.cells['tempId']?.value);
  }

  @override
  void selectRowForEditingById(int id) {}

  void selectRowForEditingByTempId(String tempId) {
		isNewRecord = false;
    final model = cteDutoviarioModelList.firstWhere((m) => m.tempId == tempId);
    cteDutoviarioModel = model.clone();
		cteDutoviarioModel.tempId = model.tempId;
    updateControllersFromModel();
    Get.to(() => CteDutoviarioEditPage());
  }

  void updateControllersFromModel() {
    valorTarifaController.updateValue(cteDutoviarioModel.valorTarifa ?? 0);
    dataInicioController.date = cteDutoviarioModel.dataInicio;
    dataFimController.date = cteDutoviarioModel.dataFim;
    formWasChangedDetail = false;
  }

  @override
  Future<void> save() async {
    if (!cteDutoviarioFormKey.currentState!.validate()) {
      showErrorSnackBar(message: 'validator_form_message'.tr);
      return;
    }

    if (formWasChangedDetail) {
      if (isNewRecord) {
        cteDutoviarioModelList.insert(0, cteDutoviarioModel.clone());
      } else {
        final index = cteDutoviarioModelList.indexWhere((m) => m.tempId == cteDutoviarioModel.tempId);
        if (index >= 0) {
          cteDutoviarioModelList[index] = cteDutoviarioModel.clone();
        }
      }

      userMadeChanges = true;
      loadData();
      Get.back(result: true);
    } else {
      Get.back();
    }
  }


  @override
  Future deleteSelected() async {
    final currentRow = plutoGridStateManager.currentRow;
    if (currentRow == null) {
      showInfoSnackBar(message: 'message_select_one_to_delete'.tr);
      return null;
    }
    showDeleteDialog(() async {
      final id = currentRow.cells['id']?.value;
      final tempId = currentRow.cells['tempId']?.value;
      cteDutoviarioModelList.removeWhere((model) => (id != 0 && model.id == id) || (id == 0 && model.tempId == tempId));
      plutoGridStateManager.removeCurrentRow();
      userMadeChanges = true;
    });
  }

  @override
  void preventDataLoss() {
    if (formWasChangedDetail) {
      showQuestionDialog('message_data_loss'.tr, () => Get.back());
    } else {
      formWasChangedDetail = false;
      Get.back();
    }
  }

  @override
  void onClose() {
    valorTarifaController.dispose();
    dataInicioController.dispose();
    dataFimController.dispose();
  }

}