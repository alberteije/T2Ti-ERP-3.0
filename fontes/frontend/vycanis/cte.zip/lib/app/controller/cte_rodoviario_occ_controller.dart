import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:extended_masked_text/extended_masked_text.dart';
import 'package:cte/app/page/shared_widget/input/input_imports.dart';

import 'package:cte/app/page/shared_widget/message_dialog.dart';
import 'package:cte/app/page/grid_columns/grid_columns_imports.dart';
import 'package:cte/app/routes/app_routes.dart';
import 'package:cte/app/controller/controller_imports.dart';
import 'package:cte/app/data/model/model_imports.dart';
import 'package:cte/app/data/repository/cte_rodoviario_occ_repository.dart';

class CteRodoviarioOccController extends ControllerBase<CteRodoviarioOccModel, CteRodoviarioOccRepository> {

  CteRodoviarioOccController({required super.repository}) {
    dbColumns = CteRodoviarioOccModel.dbColumns;
    aliasColumns = CteRodoviarioOccModel.aliasColumns;
    gridColumns = cteRodoviarioOccGridColumns();
    functionName = "cte_rodoviario_occ";
    screenTitle = "Cte Rodoviario Occ";
  }

  @override
  CteRodoviarioOccModel createNewModel() => CteRodoviarioOccModel();

  @override
  final standardFieldForFilter = CteRodoviarioOccModel.aliasColumns[CteRodoviarioOccModel.dbColumns.indexOf('serie')];

  final cteRodoviarioModelController = TextEditingController();
  final serieController = TextEditingController();
  final numeroController = MoneyMaskedTextController(precision: 0, decimalSeparator: '', thousandSeparator: '');
  final dataEmissaoController = DatePickerItemController(null);
  final cnpjController = MaskedTextController(mask: '00.000.000/0000-00',);
  final codigoInternoController = TextEditingController();
  final ieController = TextEditingController();
  final ufController = CustomDropdownButtonController('AC');
  final telefoneController = TextEditingController();

  final Map<String, dynamic> mobileConfig = {
    'primaryColumns': ['serie'],
    'secondaryColumns': ['numero'],
  };

  List<Map<String, dynamic>> get mobileItems {
    return modelList.map((cteRodoviarioOcc) => cteRodoviarioOcc.toJson).toList();
  }

  @override
  void prepareForInsert() {
    isNewRecord = true;
    currentModel = createNewModel();
    _resetForm();
    Get.toNamed(Routes.cteRodoviarioOccEditPage);
  }

  void _resetForm() {
    formWasChanged = false;
    cteRodoviarioModelController.text = '';
    serieController.text = '';
    numeroController.updateValue(0);
    dataEmissaoController.date = null;
    cnpjController.text = '';
    codigoInternoController.text = '';
    ieController.text = '';
    ufController.selected = 'AC';
    telefoneController.text = '';
  }

  @override
  void selectRowForEditingById(int id) {
    final model = modelList.firstWhere((m) => m.id == id);
    currentModel = model.clone();
    updateControllersFromModel();
    Get.toNamed(Routes.cteRodoviarioOccEditPage);
  }

  void updateControllersFromModel() {
    cteRodoviarioModelController.text = currentModel.cteRodoviarioModel?.rntrc?.toString() ?? '';
    serieController.text = currentModel.serie ?? '';
    numeroController.updateValue((currentModel.numero ?? 0).toDouble());
    dataEmissaoController.date = currentModel.dataEmissao;
    cnpjController.text = currentModel.cnpj ?? '';
    codigoInternoController.text = currentModel.codigoInterno ?? '';
    ieController.text = currentModel.ie ?? '';
    ufController.selected = currentModel.uf ?? 'AC';
    telefoneController.text = currentModel.telefone ?? '';
    formWasChanged = false;
  }

  @override
  Future<void> save() async {
    if (!formKey.currentState!.validate()) {
      showErrorSnackBar(message: 'validator_form_message'.tr);
      return;
    }

    final existingIndex = modelList.indexWhere((m) => m.id == currentModel.id);

    if (existingIndex >= 0) {
      modelList[existingIndex] = currentModel.clone();
    }

    final result = await repository.save(cteRodoviarioOccModel: currentModel);
    if (result == null) return;

    if (existingIndex >= 0) {
      modelList[existingIndex] = result;
    } else {
      modelList.insert(0, result);
    }

    if (!GetPlatform.isMobile) {
      updateGridRow(result);
    }

    Get.back(result: true);
  }

  Future callCteRodoviarioLookup() async { 
		final lookupController = Get.find<LookupController>(); 
		lookupController.refreshItems(standardValue: '%'); 
		lookupController.title = '${'lookup_page_title'.tr} [Id Cte Rodoviario]'; 
		lookupController.route = '/cte-rodoviario/'; 
		lookupController.gridColumns = cteRodoviarioGridColumns(isForLookup: true); 
		lookupController.aliasColumns = CteRodoviarioModel.aliasColumns; 
		lookupController.dbColumns = CteRodoviarioModel.dbColumns; 
		lookupController.standardColumn = CteRodoviarioModel.aliasColumns[CteRodoviarioModel.dbColumns.indexOf('rntrc')]; 

		final plutoRowResult = await Get.toNamed(Routes.lookupPage); 
		if (plutoRowResult != null) { 
			currentModel.idCteRodoviario = plutoRowResult.cells['id']!.value; 
			currentModel.cteRodoviarioModel = CteRodoviarioModel.fromPlutoRow(plutoRowResult); 
			cteRodoviarioModelController.text = currentModel.cteRodoviarioModel?.rntrc ?? ''; 
			formWasChanged = true; 
		}
	}


  @override
  void onClose() {
    cteRodoviarioModelController.dispose();
    serieController.dispose();
    numeroController.dispose();
    dataEmissaoController.dispose();
    cnpjController.dispose();
    codigoInternoController.dispose();
    ieController.dispose();
    ufController.dispose();
    telefoneController.dispose();
    super.onClose();
  }

}