import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:extended_masked_text/extended_masked_text.dart';

import 'package:cte/app/page/shared_widget/message_dialog.dart';
import 'package:cte/app/page/grid_columns/grid_columns_imports.dart';
import 'package:cte/app/routes/app_routes.dart';
import 'package:cte/app/controller/controller_imports.dart';
import 'package:cte/app/data/model/model_imports.dart';
import 'package:cte/app/data/repository/cte_inf_nf_carga_lacre_repository.dart';

class CteInfNfCargaLacreController extends ControllerBase<CteInfNfCargaLacreModel, CteInfNfCargaLacreRepository> {

  CteInfNfCargaLacreController({required super.repository}) {
    dbColumns = CteInfNfCargaLacreModel.dbColumns;
    aliasColumns = CteInfNfCargaLacreModel.aliasColumns;
    gridColumns = cteInfNfCargaLacreGridColumns();
    functionName = "cte_inf_nf_carga_lacre";
    screenTitle = "Cte Inf Nf Carga Lacre";
  }

  @override
  CteInfNfCargaLacreModel createNewModel() => CteInfNfCargaLacreModel();

  @override
  final standardFieldForFilter = CteInfNfCargaLacreModel.aliasColumns[CteInfNfCargaLacreModel.dbColumns.indexOf('numero')];

  final cteInformacaoNfCargaModelController = TextEditingController();
  final numeroController = TextEditingController();
  final quantidadeRateadaController = MoneyMaskedTextController();

  final Map<String, dynamic> mobileConfig = {
    'primaryColumns': ['numero'],
    'secondaryColumns': ['quantidade_rateada'],
  };

  List<Map<String, dynamic>> get mobileItems {
    return modelList.map((cteInfNfCargaLacre) => cteInfNfCargaLacre.toJson).toList();
  }

  @override
  void prepareForInsert() {
    isNewRecord = true;
    currentModel = createNewModel();
    _resetForm();
    Get.toNamed(Routes.cteInfNfCargaLacreEditPage);
  }

  void _resetForm() {
    formWasChanged = false;
    cteInformacaoNfCargaModelController.text = '';
    numeroController.text = '';
    quantidadeRateadaController.updateValue(0);
  }

  @override
  void selectRowForEditingById(int id) {
    final model = modelList.firstWhere((m) => m.id == id);
    currentModel = model.clone();
    updateControllersFromModel();
    Get.toNamed(Routes.cteInfNfCargaLacreEditPage);
  }

  void updateControllersFromModel() {
    cteInformacaoNfCargaModelController.text = currentModel.cteInformacaoNfCargaModel?.tipoUnidadeCarga?.toString() ?? '';
    numeroController.text = currentModel.numero ?? '';
    quantidadeRateadaController.updateValue(currentModel.quantidadeRateada ?? 0);
    formWasChanged = false;
  }

  @override
  Future<void> save() async {
    if (!formKey.currentState!.validate()) {
      showErrorSnackBar(message: 'validator_form_message'.tr);
      return;
    }

    final existingIndex = modelList.indexWhere((m) => m.id == currentModel.id);

    if (existingIndex >= 0) {
      modelList[existingIndex] = currentModel.clone();
    }

    final result = await repository.save(cteInfNfCargaLacreModel: currentModel);
    if (result == null) return;

    if (existingIndex >= 0) {
      modelList[existingIndex] = result;
    } else {
      modelList.insert(0, result);
    }

    if (!GetPlatform.isMobile) {
      updateGridRow(result);
    }

    Get.back(result: true);
  }

  Future callCteInformacaoNfCargaLookup() async { 
		final lookupController = Get.find<LookupController>(); 
		lookupController.refreshItems(standardValue: '%'); 
		lookupController.title = '${'lookup_page_title'.tr} [Id Cte Informacao Nf Carga]'; 
		lookupController.route = '/cte-informacao-nf-carga/'; 
		lookupController.gridColumns = cteInformacaoNfCargaGridColumns(isForLookup: true); 
		lookupController.aliasColumns = CteInformacaoNfCargaModel.aliasColumns; 
		lookupController.dbColumns = CteInformacaoNfCargaModel.dbColumns; 
		lookupController.standardColumn = CteInformacaoNfCargaModel.aliasColumns[CteInformacaoNfCargaModel.dbColumns.indexOf('tipoUnidadeCarga')]; 

		final plutoRowResult = await Get.toNamed(Routes.lookupPage); 
		if (plutoRowResult != null) { 
			currentModel.idCteInformacaoNfCarga = plutoRowResult.cells['id']!.value; 
			currentModel.cteInformacaoNfCargaModel = CteInformacaoNfCargaModel.fromPlutoRow(plutoRowResult); 
			cteInformacaoNfCargaModelController.text = currentModel.cteInformacaoNfCargaModel?.tipoUnidadeCarga ?? ''; 
			formWasChanged = true; 
		}
	}


  @override
  void onClose() {
    cteInformacaoNfCargaModelController.dispose();
    numeroController.dispose();
    quantidadeRateadaController.dispose();
    super.onClose();
  }

}