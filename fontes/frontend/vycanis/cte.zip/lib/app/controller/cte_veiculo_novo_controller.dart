import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:pluto_grid/pluto_grid.dart';
import 'package:extended_masked_text/extended_masked_text.dart';

import 'package:cte/app/page/page_imports.dart';
import 'package:cte/app/page/shared_widget/message_dialog.dart';
import 'package:cte/app/page/grid_columns/grid_columns_imports.dart';
import 'package:cte/app/controller/controller_imports.dart';
import 'package:cte/app/data/model/model_imports.dart';

class CteVeiculoNovoController extends ControllerBase<CteVeiculoNovoModel, void> {

  CteVeiculoNovoController() : super(repository: null) {
    dbColumns = CteVeiculoNovoModel.dbColumns;
    aliasColumns = CteVeiculoNovoModel.aliasColumns;
    gridColumns = cteVeiculoNovoGridColumns();
    functionName = "cte_veiculo_novo";
    screenTitle = "Veículo Novo";
  }

  final _cteVeiculoNovoModel = CteVeiculoNovoModel().obs;
  CteVeiculoNovoModel get cteVeiculoNovoModel => _cteVeiculoNovoModel.value;
  set cteVeiculoNovoModel(value) => _cteVeiculoNovoModel.value = value ?? CteVeiculoNovoModel();

  List<CteVeiculoNovoModel> get cteVeiculoNovoModelList => Get.find<CteCabecalhoController>().currentModel.cteVeiculoNovoModelList ?? [];

  final _userMadeChanges = false.obs;
  get userMadeChanges => _userMadeChanges.value;
  set userMadeChanges(value) => _userMadeChanges.value = value;

  final _formWasChangedDetail = false.obs;
  bool get formWasChangedDetail => _formWasChangedDetail.value;
  set formWasChangedDetail(value) => _formWasChangedDetail.value = value;

  late PlutoGridStateManager _plutoGridStateManager;
  @override
  PlutoGridStateManager get plutoGridStateManager => _plutoGridStateManager;
  @override
  set plutoGridStateManager(value) => _plutoGridStateManager = value;

  final cteVeiculoNovoScaffoldKey = GlobalKey<ScaffoldState>();
  final cteVeiculoNovoFormKey = GlobalKey<FormState>();

  @override
  CteVeiculoNovoModel createNewModel() => CteVeiculoNovoModel();

  @override
  final standardFieldForFilter = CteVeiculoNovoModel.aliasColumns[CteVeiculoNovoModel.dbColumns.indexOf('chassi')];

  final chassiController = TextEditingController();
  final corController = TextEditingController();
  final descricaoCorController = TextEditingController();
  final codigoMarcaModeloController = TextEditingController();
  final valorUnitarioController = MoneyMaskedTextController();
  final valorFreteController = MoneyMaskedTextController();

  final Map<String, dynamic> mobileConfig = {
    'primaryColumns': ['chassi'],
    'secondaryColumns': ['cor'],
  };

  List<Map<String, dynamic>> get mobileItems {
    return modelList.map((cteVeiculoNovo) => cteVeiculoNovo.toJson).toList();
  }

  @override
  List<PlutoRow> plutoRows() => List<PlutoRow>.from(cteVeiculoNovoModelList.map((model) => model.toPlutoRow()));

  @override
  Future<void> getList({Filter? filter}) async {}

  @override
  void prepareForInsert() {
    isNewRecord = true;
    cteVeiculoNovoModel = createNewModel();
    _resetForm();
    Get.to(() => CteVeiculoNovoEditPage());
  }

  void _resetForm() {
    formWasChangedDetail = false;
    chassiController.text = '';
    corController.text = '';
    descricaoCorController.text = '';
    codigoMarcaModeloController.text = '';
    valorUnitarioController.updateValue(0);
    valorFreteController.updateValue(0);
  }

  @override
  void selectRowForEditing(PlutoRow? row) async {
    if (row == null) {
      showInfoSnackBar(message: 'message_select_one_to_edited'.tr);
      return;
    }

    selectRowForEditingByTempId(row.cells['tempId']?.value);
  }

  @override
  void selectRowForEditingById(int id) {}

  void selectRowForEditingByTempId(String tempId) {
		isNewRecord = false;
    final model = cteVeiculoNovoModelList.firstWhere((m) => m.tempId == tempId);
    cteVeiculoNovoModel = model.clone();
		cteVeiculoNovoModel.tempId = model.tempId;
    updateControllersFromModel();
    Get.to(() => CteVeiculoNovoEditPage());
  }

  void updateControllersFromModel() {
    chassiController.text = cteVeiculoNovoModel.chassi ?? '';
    corController.text = cteVeiculoNovoModel.cor ?? '';
    descricaoCorController.text = cteVeiculoNovoModel.descricaoCor ?? '';
    codigoMarcaModeloController.text = cteVeiculoNovoModel.codigoMarcaModelo ?? '';
    valorUnitarioController.updateValue(cteVeiculoNovoModel.valorUnitario ?? 0);
    valorFreteController.updateValue(cteVeiculoNovoModel.valorFrete ?? 0);
    formWasChangedDetail = false;
  }

  @override
  Future<void> save() async {
    if (!cteVeiculoNovoFormKey.currentState!.validate()) {
      showErrorSnackBar(message: 'validator_form_message'.tr);
      return;
    }

    if (formWasChangedDetail) {
      if (isNewRecord) {
        cteVeiculoNovoModelList.insert(0, cteVeiculoNovoModel.clone());
      } else {
        final index = cteVeiculoNovoModelList.indexWhere((m) => m.tempId == cteVeiculoNovoModel.tempId);
        if (index >= 0) {
          cteVeiculoNovoModelList[index] = cteVeiculoNovoModel.clone();
        }
      }

      userMadeChanges = true;
      loadData();
      Get.back(result: true);
    } else {
      Get.back();
    }
  }


  @override
  Future deleteSelected() async {
    final currentRow = plutoGridStateManager.currentRow;
    if (currentRow == null) {
      showInfoSnackBar(message: 'message_select_one_to_delete'.tr);
      return null;
    }
    showDeleteDialog(() async {
      final id = currentRow.cells['id']?.value;
      final tempId = currentRow.cells['tempId']?.value;
      cteVeiculoNovoModelList.removeWhere((model) => (id != 0 && model.id == id) || (id == 0 && model.tempId == tempId));
      plutoGridStateManager.removeCurrentRow();
      userMadeChanges = true;
    });
  }

  @override
  void preventDataLoss() {
    if (formWasChangedDetail) {
      showQuestionDialog('message_data_loss'.tr, () => Get.back());
    } else {
      formWasChangedDetail = false;
      Get.back();
    }
  }

  @override
  void onClose() {
    chassiController.dispose();
    corController.dispose();
    descricaoCorController.dispose();
    codigoMarcaModeloController.dispose();
    valorUnitarioController.dispose();
    valorFreteController.dispose();
  }

}