import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:pluto_grid/pluto_grid.dart';

import 'package:cte/app/page/page_imports.dart';
import 'package:cte/app/page/shared_widget/message_dialog.dart';
import 'package:cte/app/page/grid_columns/grid_columns_imports.dart';
import 'package:cte/app/controller/controller_imports.dart';
import 'package:cte/app/data/model/model_imports.dart';

class CtePassagemController extends ControllerBase<CtePassagemModel, void> {

  CtePassagemController() : super(repository: null) {
    dbColumns = CtePassagemModel.dbColumns;
    aliasColumns = CtePassagemModel.aliasColumns;
    gridColumns = ctePassagemGridColumns();
    functionName = "cte_passagem";
    screenTitle = "Passagem";
  }

  final _ctePassagemModel = CtePassagemModel().obs;
  CtePassagemModel get ctePassagemModel => _ctePassagemModel.value;
  set ctePassagemModel(value) => _ctePassagemModel.value = value ?? CtePassagemModel();

  List<CtePassagemModel> get ctePassagemModelList => Get.find<CteCabecalhoController>().currentModel.ctePassagemModelList ?? [];

  final _userMadeChanges = false.obs;
  get userMadeChanges => _userMadeChanges.value;
  set userMadeChanges(value) => _userMadeChanges.value = value;

  final _formWasChangedDetail = false.obs;
  bool get formWasChangedDetail => _formWasChangedDetail.value;
  set formWasChangedDetail(value) => _formWasChangedDetail.value = value;

  late PlutoGridStateManager _plutoGridStateManager;
  @override
  PlutoGridStateManager get plutoGridStateManager => _plutoGridStateManager;
  @override
  set plutoGridStateManager(value) => _plutoGridStateManager = value;

  final ctePassagemScaffoldKey = GlobalKey<ScaffoldState>();
  final ctePassagemFormKey = GlobalKey<FormState>();

  @override
  CtePassagemModel createNewModel() => CtePassagemModel();

  @override
  final standardFieldForFilter = CtePassagemModel.aliasColumns[CtePassagemModel.dbColumns.indexOf('sigla_passagem')];

  final siglaPassagemController = TextEditingController();
  final siglaDestinoController = TextEditingController();
  final rotaController = TextEditingController();

  final Map<String, dynamic> mobileConfig = {
    'primaryColumns': ['sigla_passagem'],
    'secondaryColumns': ['sigla_destino'],
  };

  List<Map<String, dynamic>> get mobileItems {
    return modelList.map((ctePassagem) => ctePassagem.toJson).toList();
  }

  @override
  List<PlutoRow> plutoRows() => List<PlutoRow>.from(ctePassagemModelList.map((model) => model.toPlutoRow()));

  @override
  Future<void> getList({Filter? filter}) async {}

  @override
  void prepareForInsert() {
    isNewRecord = true;
    ctePassagemModel = createNewModel();
    _resetForm();
    Get.to(() => CtePassagemEditPage());
  }

  void _resetForm() {
    formWasChangedDetail = false;
    siglaPassagemController.text = '';
    siglaDestinoController.text = '';
    rotaController.text = '';
  }

  @override
  void selectRowForEditing(PlutoRow? row) async {
    if (row == null) {
      showInfoSnackBar(message: 'message_select_one_to_edited'.tr);
      return;
    }

    selectRowForEditingByTempId(row.cells['tempId']?.value);
  }

  @override
  void selectRowForEditingById(int id) {}

  void selectRowForEditingByTempId(String tempId) {
		isNewRecord = false;
    final model = ctePassagemModelList.firstWhere((m) => m.tempId == tempId);
    ctePassagemModel = model.clone();
		ctePassagemModel.tempId = model.tempId;
    updateControllersFromModel();
    Get.to(() => CtePassagemEditPage());
  }

  void updateControllersFromModel() {
    siglaPassagemController.text = ctePassagemModel.siglaPassagem ?? '';
    siglaDestinoController.text = ctePassagemModel.siglaDestino ?? '';
    rotaController.text = ctePassagemModel.rota ?? '';
    formWasChangedDetail = false;
  }

  @override
  Future<void> save() async {
    if (!ctePassagemFormKey.currentState!.validate()) {
      showErrorSnackBar(message: 'validator_form_message'.tr);
      return;
    }

    if (formWasChangedDetail) {
      if (isNewRecord) {
        ctePassagemModelList.insert(0, ctePassagemModel.clone());
      } else {
        final index = ctePassagemModelList.indexWhere((m) => m.tempId == ctePassagemModel.tempId);
        if (index >= 0) {
          ctePassagemModelList[index] = ctePassagemModel.clone();
        }
      }

      userMadeChanges = true;
      loadData();
      Get.back(result: true);
    } else {
      Get.back();
    }
  }


  @override
  Future deleteSelected() async {
    final currentRow = plutoGridStateManager.currentRow;
    if (currentRow == null) {
      showInfoSnackBar(message: 'message_select_one_to_delete'.tr);
      return null;
    }
    showDeleteDialog(() async {
      final id = currentRow.cells['id']?.value;
      final tempId = currentRow.cells['tempId']?.value;
      ctePassagemModelList.removeWhere((model) => (id != 0 && model.id == id) || (id == 0 && model.tempId == tempId));
      plutoGridStateManager.removeCurrentRow();
      userMadeChanges = true;
    });
  }

  @override
  void preventDataLoss() {
    if (formWasChangedDetail) {
      showQuestionDialog('message_data_loss'.tr, () => Get.back());
    } else {
      formWasChangedDetail = false;
      Get.back();
    }
  }

  @override
  void onClose() {
    siglaPassagemController.dispose();
    siglaDestinoController.dispose();
    rotaController.dispose();
  }

}