import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:pluto_grid/pluto_grid.dart';
import 'package:extended_masked_text/extended_masked_text.dart';
import 'package:cte/app/page/shared_widget/input/input_imports.dart';

import 'package:cte/app/page/page_imports.dart';
import 'package:cte/app/page/shared_widget/message_dialog.dart';
import 'package:cte/app/page/grid_columns/grid_columns_imports.dart';
import 'package:cte/app/controller/controller_imports.dart';
import 'package:cte/app/data/model/model_imports.dart';

class CteLocalEntregaController extends ControllerBase<CteLocalEntregaModel, void> {

  CteLocalEntregaController() : super(repository: null) {
    dbColumns = CteLocalEntregaModel.dbColumns;
    aliasColumns = CteLocalEntregaModel.aliasColumns;
    gridColumns = cteLocalEntregaGridColumns();
    functionName = "cte_local_entrega";
    screenTitle = "Local Entrega";
  }

  final _cteLocalEntregaModel = CteLocalEntregaModel().obs;
  CteLocalEntregaModel get cteLocalEntregaModel => _cteLocalEntregaModel.value;
  set cteLocalEntregaModel(value) => _cteLocalEntregaModel.value = value ?? CteLocalEntregaModel();

  List<CteLocalEntregaModel> get cteLocalEntregaModelList => Get.find<CteCabecalhoController>().currentModel.cteLocalEntregaModelList ?? [];

  final _userMadeChanges = false.obs;
  get userMadeChanges => _userMadeChanges.value;
  set userMadeChanges(value) => _userMadeChanges.value = value;

  final _formWasChangedDetail = false.obs;
  bool get formWasChangedDetail => _formWasChangedDetail.value;
  set formWasChangedDetail(value) => _formWasChangedDetail.value = value;

  late PlutoGridStateManager _plutoGridStateManager;
  @override
  PlutoGridStateManager get plutoGridStateManager => _plutoGridStateManager;
  @override
  set plutoGridStateManager(value) => _plutoGridStateManager = value;

  final cteLocalEntregaScaffoldKey = GlobalKey<ScaffoldState>();
  final cteLocalEntregaFormKey = GlobalKey<FormState>();

  @override
  CteLocalEntregaModel createNewModel() => CteLocalEntregaModel();

  @override
  final standardFieldForFilter = CteLocalEntregaModel.aliasColumns[CteLocalEntregaModel.dbColumns.indexOf('cnpj')];

  final cnpjController = MaskedTextController(mask: '00.000.000/0000-00',);
  final cpfController = MaskedTextController(mask: '000.000.000-00',);
  final nomeController = TextEditingController();
  final logradouroController = TextEditingController();
  final numeroController = TextEditingController();
  final complementoController = TextEditingController();
  final bairroController = TextEditingController();
  final codigoMunicipioController = MoneyMaskedTextController(precision: 0, decimalSeparator: '', thousandSeparator: '');
  final nomeMunicipioController = TextEditingController();
  final ufController = CustomDropdownButtonController('AC');

  final Map<String, dynamic> mobileConfig = {
    'primaryColumns': ['cnpj'],
    'secondaryColumns': ['cpf'],
  };

  List<Map<String, dynamic>> get mobileItems {
    return modelList.map((cteLocalEntrega) => cteLocalEntrega.toJson).toList();
  }

  @override
  List<PlutoRow> plutoRows() => List<PlutoRow>.from(cteLocalEntregaModelList.map((model) => model.toPlutoRow()));

  @override
  Future<void> getList({Filter? filter}) async {}

  @override
  void prepareForInsert() {
    isNewRecord = true;
    cteLocalEntregaModel = createNewModel();
    _resetForm();
    Get.to(() => CteLocalEntregaEditPage());
  }

  void _resetForm() {
    formWasChangedDetail = false;
    cnpjController.text = '';
    cpfController.text = '';
    nomeController.text = '';
    logradouroController.text = '';
    numeroController.text = '';
    complementoController.text = '';
    bairroController.text = '';
    codigoMunicipioController.updateValue(0);
    nomeMunicipioController.text = '';
    ufController.selected = 'AC';
  }

  @override
  void selectRowForEditing(PlutoRow? row) async {
    if (row == null) {
      showInfoSnackBar(message: 'message_select_one_to_edited'.tr);
      return;
    }

    selectRowForEditingByTempId(row.cells['tempId']?.value);
  }

  @override
  void selectRowForEditingById(int id) {}

  void selectRowForEditingByTempId(String tempId) {
		isNewRecord = false;
    final model = cteLocalEntregaModelList.firstWhere((m) => m.tempId == tempId);
    cteLocalEntregaModel = model.clone();
		cteLocalEntregaModel.tempId = model.tempId;
    updateControllersFromModel();
    Get.to(() => CteLocalEntregaEditPage());
  }

  void updateControllersFromModel() {
    cnpjController.text = cteLocalEntregaModel.cnpj ?? '';
    cpfController.text = cteLocalEntregaModel.cpf ?? '';
    nomeController.text = cteLocalEntregaModel.nome ?? '';
    logradouroController.text = cteLocalEntregaModel.logradouro ?? '';
    numeroController.text = cteLocalEntregaModel.numero ?? '';
    complementoController.text = cteLocalEntregaModel.complemento ?? '';
    bairroController.text = cteLocalEntregaModel.bairro ?? '';
    codigoMunicipioController.updateValue((cteLocalEntregaModel.codigoMunicipio ?? 0).toDouble());
    nomeMunicipioController.text = cteLocalEntregaModel.nomeMunicipio ?? '';
    ufController.selected = cteLocalEntregaModel.uf ?? 'AC';
    formWasChangedDetail = false;
  }

  @override
  Future<void> save() async {
    if (!cteLocalEntregaFormKey.currentState!.validate()) {
      showErrorSnackBar(message: 'validator_form_message'.tr);
      return;
    }

    if (formWasChangedDetail) {
      if (isNewRecord) {
        cteLocalEntregaModelList.insert(0, cteLocalEntregaModel.clone());
      } else {
        final index = cteLocalEntregaModelList.indexWhere((m) => m.tempId == cteLocalEntregaModel.tempId);
        if (index >= 0) {
          cteLocalEntregaModelList[index] = cteLocalEntregaModel.clone();
        }
      }

      userMadeChanges = true;
      loadData();
      Get.back(result: true);
    } else {
      Get.back();
    }
  }


  @override
  Future deleteSelected() async {
    final currentRow = plutoGridStateManager.currentRow;
    if (currentRow == null) {
      showInfoSnackBar(message: 'message_select_one_to_delete'.tr);
      return null;
    }
    showDeleteDialog(() async {
      final id = currentRow.cells['id']?.value;
      final tempId = currentRow.cells['tempId']?.value;
      cteLocalEntregaModelList.removeWhere((model) => (id != 0 && model.id == id) || (id == 0 && model.tempId == tempId));
      plutoGridStateManager.removeCurrentRow();
      userMadeChanges = true;
    });
  }

  @override
  void preventDataLoss() {
    if (formWasChangedDetail) {
      showQuestionDialog('message_data_loss'.tr, () => Get.back());
    } else {
      formWasChangedDetail = false;
      Get.back();
    }
  }

  @override
  void onClose() {
    cnpjController.dispose();
    cpfController.dispose();
    nomeController.dispose();
    logradouroController.dispose();
    numeroController.dispose();
    complementoController.dispose();
    bairroController.dispose();
    codigoMunicipioController.dispose();
    nomeMunicipioController.dispose();
    ufController.dispose();
  }

}