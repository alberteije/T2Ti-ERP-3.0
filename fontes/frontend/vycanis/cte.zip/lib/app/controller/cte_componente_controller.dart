import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:pluto_grid/pluto_grid.dart';
import 'package:extended_masked_text/extended_masked_text.dart';

import 'package:cte/app/page/page_imports.dart';
import 'package:cte/app/page/shared_widget/message_dialog.dart';
import 'package:cte/app/page/grid_columns/grid_columns_imports.dart';
import 'package:cte/app/controller/controller_imports.dart';
import 'package:cte/app/data/model/model_imports.dart';

class CteComponenteController extends ControllerBase<CteComponenteModel, void> {

  CteComponenteController() : super(repository: null) {
    dbColumns = CteComponenteModel.dbColumns;
    aliasColumns = CteComponenteModel.aliasColumns;
    gridColumns = cteComponenteGridColumns();
    functionName = "cte_componente";
    screenTitle = "Componente";
  }

  final _cteComponenteModel = CteComponenteModel().obs;
  CteComponenteModel get cteComponenteModel => _cteComponenteModel.value;
  set cteComponenteModel(value) => _cteComponenteModel.value = value ?? CteComponenteModel();

  List<CteComponenteModel> get cteComponenteModelList => Get.find<CteCabecalhoController>().currentModel.cteComponenteModelList ?? [];

  final _userMadeChanges = false.obs;
  get userMadeChanges => _userMadeChanges.value;
  set userMadeChanges(value) => _userMadeChanges.value = value;

  final _formWasChangedDetail = false.obs;
  bool get formWasChangedDetail => _formWasChangedDetail.value;
  set formWasChangedDetail(value) => _formWasChangedDetail.value = value;

  late PlutoGridStateManager _plutoGridStateManager;
  @override
  PlutoGridStateManager get plutoGridStateManager => _plutoGridStateManager;
  @override
  set plutoGridStateManager(value) => _plutoGridStateManager = value;

  final cteComponenteScaffoldKey = GlobalKey<ScaffoldState>();
  final cteComponenteFormKey = GlobalKey<FormState>();

  @override
  CteComponenteModel createNewModel() => CteComponenteModel();

  @override
  final standardFieldForFilter = CteComponenteModel.aliasColumns[CteComponenteModel.dbColumns.indexOf('nome')];

  final nomeController = TextEditingController();
  final valorController = MoneyMaskedTextController();

  final Map<String, dynamic> mobileConfig = {
    'primaryColumns': ['nome'],
    'secondaryColumns': ['valor'],
  };

  List<Map<String, dynamic>> get mobileItems {
    return modelList.map((cteComponente) => cteComponente.toJson).toList();
  }

  @override
  List<PlutoRow> plutoRows() => List<PlutoRow>.from(cteComponenteModelList.map((model) => model.toPlutoRow()));

  @override
  Future<void> getList({Filter? filter}) async {}

  @override
  void prepareForInsert() {
    isNewRecord = true;
    cteComponenteModel = createNewModel();
    _resetForm();
    Get.to(() => CteComponenteEditPage());
  }

  void _resetForm() {
    formWasChangedDetail = false;
    nomeController.text = '';
    valorController.updateValue(0);
  }

  @override
  void selectRowForEditing(PlutoRow? row) async {
    if (row == null) {
      showInfoSnackBar(message: 'message_select_one_to_edited'.tr);
      return;
    }

    selectRowForEditingByTempId(row.cells['tempId']?.value);
  }

  @override
  void selectRowForEditingById(int id) {}

  void selectRowForEditingByTempId(String tempId) {
		isNewRecord = false;
    final model = cteComponenteModelList.firstWhere((m) => m.tempId == tempId);
    cteComponenteModel = model.clone();
		cteComponenteModel.tempId = model.tempId;
    updateControllersFromModel();
    Get.to(() => CteComponenteEditPage());
  }

  void updateControllersFromModel() {
    nomeController.text = cteComponenteModel.nome ?? '';
    valorController.updateValue(cteComponenteModel.valor ?? 0);
    formWasChangedDetail = false;
  }

  @override
  Future<void> save() async {
    if (!cteComponenteFormKey.currentState!.validate()) {
      showErrorSnackBar(message: 'validator_form_message'.tr);
      return;
    }

    if (formWasChangedDetail) {
      if (isNewRecord) {
        cteComponenteModelList.insert(0, cteComponenteModel.clone());
      } else {
        final index = cteComponenteModelList.indexWhere((m) => m.tempId == cteComponenteModel.tempId);
        if (index >= 0) {
          cteComponenteModelList[index] = cteComponenteModel.clone();
        }
      }

      userMadeChanges = true;
      loadData();
      Get.back(result: true);
    } else {
      Get.back();
    }
  }


  @override
  Future deleteSelected() async {
    final currentRow = plutoGridStateManager.currentRow;
    if (currentRow == null) {
      showInfoSnackBar(message: 'message_select_one_to_delete'.tr);
      return null;
    }
    showDeleteDialog(() async {
      final id = currentRow.cells['id']?.value;
      final tempId = currentRow.cells['tempId']?.value;
      cteComponenteModelList.removeWhere((model) => (id != 0 && model.id == id) || (id == 0 && model.tempId == tempId));
      plutoGridStateManager.removeCurrentRow();
      userMadeChanges = true;
    });
  }

  @override
  void preventDataLoss() {
    if (formWasChangedDetail) {
      showQuestionDialog('message_data_loss'.tr, () => Get.back());
    } else {
      formWasChangedDetail = false;
      Get.back();
    }
  }

  @override
  void onClose() {
    nomeController.dispose();
    valorController.dispose();
  }

}