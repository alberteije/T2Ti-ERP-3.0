import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:extended_masked_text/extended_masked_text.dart';

import 'package:cte/app/page/shared_widget/message_dialog.dart';
import 'package:cte/app/page/grid_columns/grid_columns_imports.dart';
import 'package:cte/app/routes/app_routes.dart';
import 'package:cte/app/controller/controller_imports.dart';
import 'package:cte/app/data/model/model_imports.dart';
import 'package:cte/app/data/repository/cte_rodoviario_pedagio_repository.dart';

class CteRodoviarioPedagioController extends ControllerBase<CteRodoviarioPedagioModel, CteRodoviarioPedagioRepository> {

  CteRodoviarioPedagioController({required super.repository}) {
    dbColumns = CteRodoviarioPedagioModel.dbColumns;
    aliasColumns = CteRodoviarioPedagioModel.aliasColumns;
    gridColumns = cteRodoviarioPedagioGridColumns();
    functionName = "cte_rodoviario_pedagio";
    screenTitle = "Cte Rodoviario Pedagio";
  }

  @override
  CteRodoviarioPedagioModel createNewModel() => CteRodoviarioPedagioModel();

  @override
  final standardFieldForFilter = CteRodoviarioPedagioModel.aliasColumns[CteRodoviarioPedagioModel.dbColumns.indexOf('cnpj_fornecedor')];

  final cteRodoviarioModelController = TextEditingController();
  final cnpjFornecedorController = MaskedTextController(mask: '00.000.000/0000-00',);
  final comprovanteCompraController = TextEditingController();
  final cnpjResponsavelController = MaskedTextController(mask: '00.000.000/0000-00',);
  final valorController = MoneyMaskedTextController();

  final Map<String, dynamic> mobileConfig = {
    'primaryColumns': ['cnpj_fornecedor'],
    'secondaryColumns': ['comprovante_compra'],
  };

  List<Map<String, dynamic>> get mobileItems {
    return modelList.map((cteRodoviarioPedagio) => cteRodoviarioPedagio.toJson).toList();
  }

  @override
  void prepareForInsert() {
    isNewRecord = true;
    currentModel = createNewModel();
    _resetForm();
    Get.toNamed(Routes.cteRodoviarioPedagioEditPage);
  }

  void _resetForm() {
    formWasChanged = false;
    cteRodoviarioModelController.text = '';
    cnpjFornecedorController.text = '';
    comprovanteCompraController.text = '';
    cnpjResponsavelController.text = '';
    valorController.updateValue(0);
  }

  @override
  void selectRowForEditingById(int id) {
    final model = modelList.firstWhere((m) => m.id == id);
    currentModel = model.clone();
    updateControllersFromModel();
    Get.toNamed(Routes.cteRodoviarioPedagioEditPage);
  }

  void updateControllersFromModel() {
    cteRodoviarioModelController.text = currentModel.cteRodoviarioModel?.rntrc?.toString() ?? '';
    cnpjFornecedorController.text = currentModel.cnpjFornecedor ?? '';
    comprovanteCompraController.text = currentModel.comprovanteCompra ?? '';
    cnpjResponsavelController.text = currentModel.cnpjResponsavel ?? '';
    valorController.updateValue(currentModel.valor ?? 0);
    formWasChanged = false;
  }

  @override
  Future<void> save() async {
    if (!formKey.currentState!.validate()) {
      showErrorSnackBar(message: 'validator_form_message'.tr);
      return;
    }

    final existingIndex = modelList.indexWhere((m) => m.id == currentModel.id);

    if (existingIndex >= 0) {
      modelList[existingIndex] = currentModel.clone();
    }

    final result = await repository.save(cteRodoviarioPedagioModel: currentModel);
    if (result == null) return;

    if (existingIndex >= 0) {
      modelList[existingIndex] = result;
    } else {
      modelList.insert(0, result);
    }

    if (!GetPlatform.isMobile) {
      updateGridRow(result);
    }

    Get.back(result: true);
  }

  Future callCteRodoviarioLookup() async { 
		final lookupController = Get.find<LookupController>(); 
		lookupController.refreshItems(standardValue: '%'); 
		lookupController.title = '${'lookup_page_title'.tr} [Id Cte Rodoviario]'; 
		lookupController.route = '/cte-rodoviario/'; 
		lookupController.gridColumns = cteRodoviarioGridColumns(isForLookup: true); 
		lookupController.aliasColumns = CteRodoviarioModel.aliasColumns; 
		lookupController.dbColumns = CteRodoviarioModel.dbColumns; 
		lookupController.standardColumn = CteRodoviarioModel.aliasColumns[CteRodoviarioModel.dbColumns.indexOf('rntrc')]; 

		final plutoRowResult = await Get.toNamed(Routes.lookupPage); 
		if (plutoRowResult != null) { 
			currentModel.idCteRodoviario = plutoRowResult.cells['id']!.value; 
			currentModel.cteRodoviarioModel = CteRodoviarioModel.fromPlutoRow(plutoRowResult); 
			cteRodoviarioModelController.text = currentModel.cteRodoviarioModel?.rntrc ?? ''; 
			formWasChanged = true; 
		}
	}


  @override
  void onClose() {
    cteRodoviarioModelController.dispose();
    cnpjFornecedorController.dispose();
    comprovanteCompraController.dispose();
    cnpjResponsavelController.dispose();
    valorController.dispose();
    super.onClose();
  }

}