import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:pluto_grid/pluto_grid.dart';
import 'package:extended_masked_text/extended_masked_text.dart';
import 'package:cte/app/page/shared_widget/input/input_imports.dart';

import 'package:cte/app/page/page_imports.dart';
import 'package:cte/app/page/shared_widget/message_dialog.dart';
import 'package:cte/app/page/grid_columns/grid_columns_imports.dart';
import 'package:cte/app/controller/controller_imports.dart';
import 'package:cte/app/data/model/model_imports.dart';

class CteCargaController extends ControllerBase<CteCargaModel, void> {

  CteCargaController() : super(repository: null) {
    dbColumns = CteCargaModel.dbColumns;
    aliasColumns = CteCargaModel.aliasColumns;
    gridColumns = cteCargaGridColumns();
    functionName = "cte_carga";
    screenTitle = "Carga";
  }

  final _cteCargaModel = CteCargaModel().obs;
  CteCargaModel get cteCargaModel => _cteCargaModel.value;
  set cteCargaModel(value) => _cteCargaModel.value = value ?? CteCargaModel();

  List<CteCargaModel> get cteCargaModelList => Get.find<CteCabecalhoController>().currentModel.cteCargaModelList ?? [];

  final _userMadeChanges = false.obs;
  get userMadeChanges => _userMadeChanges.value;
  set userMadeChanges(value) => _userMadeChanges.value = value;

  final _formWasChangedDetail = false.obs;
  bool get formWasChangedDetail => _formWasChangedDetail.value;
  set formWasChangedDetail(value) => _formWasChangedDetail.value = value;

  late PlutoGridStateManager _plutoGridStateManager;
  @override
  PlutoGridStateManager get plutoGridStateManager => _plutoGridStateManager;
  @override
  set plutoGridStateManager(value) => _plutoGridStateManager = value;

  final cteCargaScaffoldKey = GlobalKey<ScaffoldState>();
  final cteCargaFormKey = GlobalKey<FormState>();

  @override
  CteCargaModel createNewModel() => CteCargaModel();

  @override
  final standardFieldForFilter = CteCargaModel.aliasColumns[CteCargaModel.dbColumns.indexOf('codigo_unidade_medida')];

  final codigoUnidadeMedidaController = CustomDropdownButtonController('00-M3');
  final tipoMedidaController = TextEditingController();
  final quantidadeController = MoneyMaskedTextController();

  final Map<String, dynamic> mobileConfig = {
    'primaryColumns': ['codigo_unidade_medida'],
    'secondaryColumns': ['tipo_medida'],
  };

  List<Map<String, dynamic>> get mobileItems {
    return modelList.map((cteCarga) => cteCarga.toJson).toList();
  }

  @override
  List<PlutoRow> plutoRows() => List<PlutoRow>.from(cteCargaModelList.map((model) => model.toPlutoRow()));

  @override
  Future<void> getList({Filter? filter}) async {}

  @override
  void prepareForInsert() {
    isNewRecord = true;
    cteCargaModel = createNewModel();
    _resetForm();
    Get.to(() => CteCargaEditPage());
  }

  void _resetForm() {
    formWasChangedDetail = false;
    codigoUnidadeMedidaController.selected = '00-M3';
    tipoMedidaController.text = '';
    quantidadeController.updateValue(0);
  }

  @override
  void selectRowForEditing(PlutoRow? row) async {
    if (row == null) {
      showInfoSnackBar(message: 'message_select_one_to_edited'.tr);
      return;
    }

    selectRowForEditingByTempId(row.cells['tempId']?.value);
  }

  @override
  void selectRowForEditingById(int id) {}

  void selectRowForEditingByTempId(String tempId) {
		isNewRecord = false;
    final model = cteCargaModelList.firstWhere((m) => m.tempId == tempId);
    cteCargaModel = model.clone();
		cteCargaModel.tempId = model.tempId;
    updateControllersFromModel();
    Get.to(() => CteCargaEditPage());
  }

  void updateControllersFromModel() {
    codigoUnidadeMedidaController.selected = cteCargaModel.codigoUnidadeMedida ?? '00-M3';
    tipoMedidaController.text = cteCargaModel.tipoMedida ?? '';
    quantidadeController.updateValue(cteCargaModel.quantidade ?? 0);
    formWasChangedDetail = false;
  }

  @override
  Future<void> save() async {
    if (!cteCargaFormKey.currentState!.validate()) {
      showErrorSnackBar(message: 'validator_form_message'.tr);
      return;
    }

    if (formWasChangedDetail) {
      if (isNewRecord) {
        cteCargaModelList.insert(0, cteCargaModel.clone());
      } else {
        final index = cteCargaModelList.indexWhere((m) => m.tempId == cteCargaModel.tempId);
        if (index >= 0) {
          cteCargaModelList[index] = cteCargaModel.clone();
        }
      }

      userMadeChanges = true;
      loadData();
      Get.back(result: true);
    } else {
      Get.back();
    }
  }


  @override
  Future deleteSelected() async {
    final currentRow = plutoGridStateManager.currentRow;
    if (currentRow == null) {
      showInfoSnackBar(message: 'message_select_one_to_delete'.tr);
      return null;
    }
    showDeleteDialog(() async {
      final id = currentRow.cells['id']?.value;
      final tempId = currentRow.cells['tempId']?.value;
      cteCargaModelList.removeWhere((model) => (id != 0 && model.id == id) || (id == 0 && model.tempId == tempId));
      plutoGridStateManager.removeCurrentRow();
      userMadeChanges = true;
    });
  }

  @override
  void preventDataLoss() {
    if (formWasChangedDetail) {
      showQuestionDialog('message_data_loss'.tr, () => Get.back());
    } else {
      formWasChangedDetail = false;
      Get.back();
    }
  }

  @override
  void onClose() {
    codigoUnidadeMedidaController.dispose();
    tipoMedidaController.dispose();
    quantidadeController.dispose();
  }

}