import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:pluto_grid/pluto_grid.dart';

import 'package:cte/app/page/page_imports.dart';
import 'package:cte/app/page/shared_widget/message_dialog.dart';
import 'package:cte/app/page/grid_columns/grid_columns_imports.dart';
import 'package:cte/app/controller/controller_imports.dart';
import 'package:cte/app/data/model/model_imports.dart';

class CtePerigosoController extends ControllerBase<CtePerigosoModel, void> {

  CtePerigosoController() : super(repository: null) {
    dbColumns = CtePerigosoModel.dbColumns;
    aliasColumns = CtePerigosoModel.aliasColumns;
    gridColumns = ctePerigosoGridColumns();
    functionName = "cte_perigoso";
    screenTitle = "Perigoso";
  }

  final _ctePerigosoModel = CtePerigosoModel().obs;
  CtePerigosoModel get ctePerigosoModel => _ctePerigosoModel.value;
  set ctePerigosoModel(value) => _ctePerigosoModel.value = value ?? CtePerigosoModel();

  List<CtePerigosoModel> get ctePerigosoModelList => Get.find<CteCabecalhoController>().currentModel.ctePerigosoModelList ?? [];

  final _userMadeChanges = false.obs;
  get userMadeChanges => _userMadeChanges.value;
  set userMadeChanges(value) => _userMadeChanges.value = value;

  final _formWasChangedDetail = false.obs;
  bool get formWasChangedDetail => _formWasChangedDetail.value;
  set formWasChangedDetail(value) => _formWasChangedDetail.value = value;

  late PlutoGridStateManager _plutoGridStateManager;
  @override
  PlutoGridStateManager get plutoGridStateManager => _plutoGridStateManager;
  @override
  set plutoGridStateManager(value) => _plutoGridStateManager = value;

  final ctePerigosoScaffoldKey = GlobalKey<ScaffoldState>();
  final ctePerigosoFormKey = GlobalKey<FormState>();

  @override
  CtePerigosoModel createNewModel() => CtePerigosoModel();

  @override
  final standardFieldForFilter = CtePerigosoModel.aliasColumns[CtePerigosoModel.dbColumns.indexOf('numero_onu')];

  final numeroOnuController = TextEditingController();
  final nomeApropriadoController = TextEditingController();
  final classeRiscoController = TextEditingController();
  final grupoEmbalagemController = TextEditingController();
  final quantidadeTotalProdutoController = TextEditingController();
  final quantidadeTipoVolumeController = TextEditingController();
  final pontoFulgorController = TextEditingController();

  final Map<String, dynamic> mobileConfig = {
    'primaryColumns': ['numero_onu'],
    'secondaryColumns': ['nome_apropriado'],
  };

  List<Map<String, dynamic>> get mobileItems {
    return modelList.map((ctePerigoso) => ctePerigoso.toJson).toList();
  }

  @override
  List<PlutoRow> plutoRows() => List<PlutoRow>.from(ctePerigosoModelList.map((model) => model.toPlutoRow()));

  @override
  Future<void> getList({Filter? filter}) async {}

  @override
  void prepareForInsert() {
    isNewRecord = true;
    ctePerigosoModel = createNewModel();
    _resetForm();
    Get.to(() => CtePerigosoEditPage());
  }

  void _resetForm() {
    formWasChangedDetail = false;
    numeroOnuController.text = '';
    nomeApropriadoController.text = '';
    classeRiscoController.text = '';
    grupoEmbalagemController.text = '';
    quantidadeTotalProdutoController.text = '';
    quantidadeTipoVolumeController.text = '';
    pontoFulgorController.text = '';
  }

  @override
  void selectRowForEditing(PlutoRow? row) async {
    if (row == null) {
      showInfoSnackBar(message: 'message_select_one_to_edited'.tr);
      return;
    }

    selectRowForEditingByTempId(row.cells['tempId']?.value);
  }

  @override
  void selectRowForEditingById(int id) {}

  void selectRowForEditingByTempId(String tempId) {
		isNewRecord = false;
    final model = ctePerigosoModelList.firstWhere((m) => m.tempId == tempId);
    ctePerigosoModel = model.clone();
		ctePerigosoModel.tempId = model.tempId;
    updateControllersFromModel();
    Get.to(() => CtePerigosoEditPage());
  }

  void updateControllersFromModel() {
    numeroOnuController.text = ctePerigosoModel.numeroOnu ?? '';
    nomeApropriadoController.text = ctePerigosoModel.nomeApropriado ?? '';
    classeRiscoController.text = ctePerigosoModel.classeRisco ?? '';
    grupoEmbalagemController.text = ctePerigosoModel.grupoEmbalagem ?? '';
    quantidadeTotalProdutoController.text = ctePerigosoModel.quantidadeTotalProduto ?? '';
    quantidadeTipoVolumeController.text = ctePerigosoModel.quantidadeTipoVolume ?? '';
    pontoFulgorController.text = ctePerigosoModel.pontoFulgor ?? '';
    formWasChangedDetail = false;
  }

  @override
  Future<void> save() async {
    if (!ctePerigosoFormKey.currentState!.validate()) {
      showErrorSnackBar(message: 'validator_form_message'.tr);
      return;
    }

    if (formWasChangedDetail) {
      if (isNewRecord) {
        ctePerigosoModelList.insert(0, ctePerigosoModel.clone());
      } else {
        final index = ctePerigosoModelList.indexWhere((m) => m.tempId == ctePerigosoModel.tempId);
        if (index >= 0) {
          ctePerigosoModelList[index] = ctePerigosoModel.clone();
        }
      }

      userMadeChanges = true;
      loadData();
      Get.back(result: true);
    } else {
      Get.back();
    }
  }


  @override
  Future deleteSelected() async {
    final currentRow = plutoGridStateManager.currentRow;
    if (currentRow == null) {
      showInfoSnackBar(message: 'message_select_one_to_delete'.tr);
      return null;
    }
    showDeleteDialog(() async {
      final id = currentRow.cells['id']?.value;
      final tempId = currentRow.cells['tempId']?.value;
      ctePerigosoModelList.removeWhere((model) => (id != 0 && model.id == id) || (id == 0 && model.tempId == tempId));
      plutoGridStateManager.removeCurrentRow();
      userMadeChanges = true;
    });
  }

  @override
  void preventDataLoss() {
    if (formWasChangedDetail) {
      showQuestionDialog('message_data_loss'.tr, () => Get.back());
    } else {
      formWasChangedDetail = false;
      Get.back();
    }
  }

  @override
  void onClose() {
    numeroOnuController.dispose();
    nomeApropriadoController.dispose();
    classeRiscoController.dispose();
    grupoEmbalagemController.dispose();
    quantidadeTotalProdutoController.dispose();
    quantidadeTipoVolumeController.dispose();
    pontoFulgorController.dispose();
  }

}