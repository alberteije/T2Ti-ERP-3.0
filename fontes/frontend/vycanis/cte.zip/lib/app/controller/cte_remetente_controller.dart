import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:pluto_grid/pluto_grid.dart';
import 'package:extended_masked_text/extended_masked_text.dart';
import 'package:cte/app/page/shared_widget/input/input_imports.dart';

import 'package:cte/app/page/page_imports.dart';
import 'package:cte/app/page/shared_widget/message_dialog.dart';
import 'package:cte/app/page/grid_columns/grid_columns_imports.dart';
import 'package:cte/app/controller/controller_imports.dart';
import 'package:cte/app/data/model/model_imports.dart';

class CteRemetenteController extends ControllerBase<CteRemetenteModel, void> {

  CteRemetenteController() : super(repository: null) {
    dbColumns = CteRemetenteModel.dbColumns;
    aliasColumns = CteRemetenteModel.aliasColumns;
    gridColumns = cteRemetenteGridColumns();
    functionName = "cte_remetente";
    screenTitle = "Remetente";
  }

  final _cteRemetenteModel = CteRemetenteModel().obs;
  CteRemetenteModel get cteRemetenteModel => _cteRemetenteModel.value;
  set cteRemetenteModel(value) => _cteRemetenteModel.value = value ?? CteRemetenteModel();

  List<CteRemetenteModel> get cteRemetenteModelList => Get.find<CteCabecalhoController>().currentModel.cteRemetenteModelList ?? [];

  final _userMadeChanges = false.obs;
  get userMadeChanges => _userMadeChanges.value;
  set userMadeChanges(value) => _userMadeChanges.value = value;

  final _formWasChangedDetail = false.obs;
  bool get formWasChangedDetail => _formWasChangedDetail.value;
  set formWasChangedDetail(value) => _formWasChangedDetail.value = value;

  late PlutoGridStateManager _plutoGridStateManager;
  @override
  PlutoGridStateManager get plutoGridStateManager => _plutoGridStateManager;
  @override
  set plutoGridStateManager(value) => _plutoGridStateManager = value;

  final cteRemetenteScaffoldKey = GlobalKey<ScaffoldState>();
  final cteRemetenteFormKey = GlobalKey<FormState>();

  @override
  CteRemetenteModel createNewModel() => CteRemetenteModel();

  @override
  final standardFieldForFilter = CteRemetenteModel.aliasColumns[CteRemetenteModel.dbColumns.indexOf('cnpj')];

  final cnpjController = MaskedTextController(mask: '00.000.000/0000-00',);
  final cpfController = MaskedTextController(mask: '000.000.000-00',);
  final ieController = TextEditingController();
  final nomeController = TextEditingController();
  final fantasiaController = TextEditingController();
  final telefoneController = TextEditingController();
  final logradouroController = TextEditingController();
  final numeroController = TextEditingController();
  final complementoController = TextEditingController();
  final bairroController = TextEditingController();
  final codigoMunicipioController = MoneyMaskedTextController(precision: 0, decimalSeparator: '', thousandSeparator: '');
  final nomeMunicipioController = TextEditingController();
  final ufController = CustomDropdownButtonController('AC');
  final cepController = MaskedTextController(mask: '00000-000',);
  final codigoPaisController = MoneyMaskedTextController(precision: 0, decimalSeparator: '', thousandSeparator: '');
  final nomePaisController = TextEditingController();
  final emailController = TextEditingController();

  final Map<String, dynamic> mobileConfig = {
    'primaryColumns': ['cnpj'],
    'secondaryColumns': ['cpf'],
  };

  List<Map<String, dynamic>> get mobileItems {
    return modelList.map((cteRemetente) => cteRemetente.toJson).toList();
  }

  @override
  List<PlutoRow> plutoRows() => List<PlutoRow>.from(cteRemetenteModelList.map((model) => model.toPlutoRow()));

  @override
  Future<void> getList({Filter? filter}) async {}

  @override
  void prepareForInsert() {
    isNewRecord = true;
    cteRemetenteModel = createNewModel();
    _resetForm();
    Get.to(() => CteRemetenteEditPage());
  }

  void _resetForm() {
    formWasChangedDetail = false;
    cnpjController.text = '';
    cpfController.text = '';
    ieController.text = '';
    nomeController.text = '';
    fantasiaController.text = '';
    telefoneController.text = '';
    logradouroController.text = '';
    numeroController.text = '';
    complementoController.text = '';
    bairroController.text = '';
    codigoMunicipioController.updateValue(0);
    nomeMunicipioController.text = '';
    ufController.selected = 'AC';
    cepController.text = '';
    codigoPaisController.updateValue(0);
    nomePaisController.text = '';
    emailController.text = '';
  }

  @override
  void selectRowForEditing(PlutoRow? row) async {
    if (row == null) {
      showInfoSnackBar(message: 'message_select_one_to_edited'.tr);
      return;
    }

    selectRowForEditingByTempId(row.cells['tempId']?.value);
  }

  @override
  void selectRowForEditingById(int id) {}

  void selectRowForEditingByTempId(String tempId) {
		isNewRecord = false;
    final model = cteRemetenteModelList.firstWhere((m) => m.tempId == tempId);
    cteRemetenteModel = model.clone();
		cteRemetenteModel.tempId = model.tempId;
    updateControllersFromModel();
    Get.to(() => CteRemetenteEditPage());
  }

  void updateControllersFromModel() {
    cnpjController.text = cteRemetenteModel.cnpj ?? '';
    cpfController.text = cteRemetenteModel.cpf ?? '';
    ieController.text = cteRemetenteModel.ie ?? '';
    nomeController.text = cteRemetenteModel.nome ?? '';
    fantasiaController.text = cteRemetenteModel.fantasia ?? '';
    telefoneController.text = cteRemetenteModel.telefone ?? '';
    logradouroController.text = cteRemetenteModel.logradouro ?? '';
    numeroController.text = cteRemetenteModel.numero ?? '';
    complementoController.text = cteRemetenteModel.complemento ?? '';
    bairroController.text = cteRemetenteModel.bairro ?? '';
    codigoMunicipioController.updateValue((cteRemetenteModel.codigoMunicipio ?? 0).toDouble());
    nomeMunicipioController.text = cteRemetenteModel.nomeMunicipio ?? '';
    ufController.selected = cteRemetenteModel.uf ?? 'AC';
    cepController.text = cteRemetenteModel.cep ?? '';
    codigoPaisController.updateValue((cteRemetenteModel.codigoPais ?? 0).toDouble());
    nomePaisController.text = cteRemetenteModel.nomePais ?? '';
    emailController.text = cteRemetenteModel.email ?? '';
    formWasChangedDetail = false;
  }

  @override
  Future<void> save() async {
    if (!cteRemetenteFormKey.currentState!.validate()) {
      showErrorSnackBar(message: 'validator_form_message'.tr);
      return;
    }

    if (formWasChangedDetail) {
      if (isNewRecord) {
        cteRemetenteModelList.insert(0, cteRemetenteModel.clone());
      } else {
        final index = cteRemetenteModelList.indexWhere((m) => m.tempId == cteRemetenteModel.tempId);
        if (index >= 0) {
          cteRemetenteModelList[index] = cteRemetenteModel.clone();
        }
      }

      userMadeChanges = true;
      loadData();
      Get.back(result: true);
    } else {
      Get.back();
    }
  }


  @override
  Future deleteSelected() async {
    final currentRow = plutoGridStateManager.currentRow;
    if (currentRow == null) {
      showInfoSnackBar(message: 'message_select_one_to_delete'.tr);
      return null;
    }
    showDeleteDialog(() async {
      final id = currentRow.cells['id']?.value;
      final tempId = currentRow.cells['tempId']?.value;
      cteRemetenteModelList.removeWhere((model) => (id != 0 && model.id == id) || (id == 0 && model.tempId == tempId));
      plutoGridStateManager.removeCurrentRow();
      userMadeChanges = true;
    });
  }

  @override
  void preventDataLoss() {
    if (formWasChangedDetail) {
      showQuestionDialog('message_data_loss'.tr, () => Get.back());
    } else {
      formWasChangedDetail = false;
      Get.back();
    }
  }

  @override
  void onClose() {
    cnpjController.dispose();
    cpfController.dispose();
    ieController.dispose();
    nomeController.dispose();
    fantasiaController.dispose();
    telefoneController.dispose();
    logradouroController.dispose();
    numeroController.dispose();
    complementoController.dispose();
    bairroController.dispose();
    codigoMunicipioController.dispose();
    nomeMunicipioController.dispose();
    ufController.dispose();
    cepController.dispose();
    codigoPaisController.dispose();
    nomePaisController.dispose();
    emailController.dispose();
  }

}