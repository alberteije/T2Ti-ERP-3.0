import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:extended_masked_text/extended_masked_text.dart';
import 'package:cte/app/page/shared_widget/input/input_imports.dart';

import 'package:cte/app/page/shared_widget/message_dialog.dart';
import 'package:cte/app/page/grid_columns/grid_columns_imports.dart';
import 'package:cte/app/routes/app_routes.dart';
import 'package:cte/app/controller/controller_imports.dart';
import 'package:cte/app/data/model/model_imports.dart';
import 'package:cte/app/data/repository/cte_ferroviario_ferrovia_repository.dart';

class CteFerroviarioFerroviaController extends ControllerBase<CteFerroviarioFerroviaModel, CteFerroviarioFerroviaRepository> {

  CteFerroviarioFerroviaController({required super.repository}) {
    dbColumns = CteFerroviarioFerroviaModel.dbColumns;
    aliasColumns = CteFerroviarioFerroviaModel.aliasColumns;
    gridColumns = cteFerroviarioFerroviaGridColumns();
    functionName = "cte_ferroviario_ferrovia";
    screenTitle = "Cte Ferroviario Ferrovia";
  }

  @override
  CteFerroviarioFerroviaModel createNewModel() => CteFerroviarioFerroviaModel();

  @override
  final standardFieldForFilter = CteFerroviarioFerroviaModel.aliasColumns[CteFerroviarioFerroviaModel.dbColumns.indexOf('cnpj')];

  final cteFerroviarioModelController = TextEditingController();
  final cnpjController = MaskedTextController(mask: '00.000.000/0000-00',);
  final codigoInternoController = TextEditingController();
  final ieController = TextEditingController();
  final nomeController = TextEditingController();
  final logradouroController = TextEditingController();
  final numeroController = TextEditingController();
  final complementoController = TextEditingController();
  final bairroController = TextEditingController();
  final codigoMunicipioController = MoneyMaskedTextController(precision: 0, decimalSeparator: '', thousandSeparator: '');
  final nomeMunicipioController = TextEditingController();
  final ufController = CustomDropdownButtonController('AC');
  final cepController = MaskedTextController(mask: '00000-000',);

  final Map<String, dynamic> mobileConfig = {
    'primaryColumns': ['cnpj'],
    'secondaryColumns': ['codigo_interno'],
  };

  List<Map<String, dynamic>> get mobileItems {
    return modelList.map((cteFerroviarioFerrovia) => cteFerroviarioFerrovia.toJson).toList();
  }

  @override
  void prepareForInsert() {
    isNewRecord = true;
    currentModel = createNewModel();
    _resetForm();
    Get.toNamed(Routes.cteFerroviarioFerroviaEditPage);
  }

  void _resetForm() {
    formWasChanged = false;
    cteFerroviarioModelController.text = '';
    cnpjController.text = '';
    codigoInternoController.text = '';
    ieController.text = '';
    nomeController.text = '';
    logradouroController.text = '';
    numeroController.text = '';
    complementoController.text = '';
    bairroController.text = '';
    codigoMunicipioController.updateValue(0);
    nomeMunicipioController.text = '';
    ufController.selected = 'AC';
    cepController.text = '';
  }

  @override
  void selectRowForEditingById(int id) {
    final model = modelList.firstWhere((m) => m.id == id);
    currentModel = model.clone();
    updateControllersFromModel();
    Get.toNamed(Routes.cteFerroviarioFerroviaEditPage);
  }

  void updateControllersFromModel() {
    cteFerroviarioModelController.text = currentModel.cteFerroviarioModel?.fluxo?.toString() ?? '';
    cnpjController.text = currentModel.cnpj ?? '';
    codigoInternoController.text = currentModel.codigoInterno ?? '';
    ieController.text = currentModel.ie ?? '';
    nomeController.text = currentModel.nome ?? '';
    logradouroController.text = currentModel.logradouro ?? '';
    numeroController.text = currentModel.numero ?? '';
    complementoController.text = currentModel.complemento ?? '';
    bairroController.text = currentModel.bairro ?? '';
    codigoMunicipioController.updateValue((currentModel.codigoMunicipio ?? 0).toDouble());
    nomeMunicipioController.text = currentModel.nomeMunicipio ?? '';
    ufController.selected = currentModel.uf ?? 'AC';
    cepController.text = currentModel.cep ?? '';
    formWasChanged = false;
  }

  @override
  Future<void> save() async {
    if (!formKey.currentState!.validate()) {
      showErrorSnackBar(message: 'validator_form_message'.tr);
      return;
    }

    final existingIndex = modelList.indexWhere((m) => m.id == currentModel.id);

    if (existingIndex >= 0) {
      modelList[existingIndex] = currentModel.clone();
    }

    final result = await repository.save(cteFerroviarioFerroviaModel: currentModel);
    if (result == null) return;

    if (existingIndex >= 0) {
      modelList[existingIndex] = result;
    } else {
      modelList.insert(0, result);
    }

    if (!GetPlatform.isMobile) {
      updateGridRow(result);
    }

    Get.back(result: true);
  }

  Future callCteFerroviarioLookup() async { 
		final lookupController = Get.find<LookupController>(); 
		lookupController.refreshItems(standardValue: '%'); 
		lookupController.title = '${'lookup_page_title'.tr} [Id Cte Ferroviario]'; 
		lookupController.route = '/cte-ferroviario/'; 
		lookupController.gridColumns = cteFerroviarioGridColumns(isForLookup: true); 
		lookupController.aliasColumns = CteFerroviarioModel.aliasColumns; 
		lookupController.dbColumns = CteFerroviarioModel.dbColumns; 
		lookupController.standardColumn = CteFerroviarioModel.aliasColumns[CteFerroviarioModel.dbColumns.indexOf('fluxo')]; 

		final plutoRowResult = await Get.toNamed(Routes.lookupPage); 
		if (plutoRowResult != null) { 
			currentModel.idCteFerroviario = plutoRowResult.cells['id']!.value; 
			currentModel.cteFerroviarioModel = CteFerroviarioModel.fromPlutoRow(plutoRowResult); 
			cteFerroviarioModelController.text = currentModel.cteFerroviarioModel?.fluxo ?? ''; 
			formWasChanged = true; 
		}
	}


  @override
  void onClose() {
    cteFerroviarioModelController.dispose();
    cnpjController.dispose();
    codigoInternoController.dispose();
    ieController.dispose();
    nomeController.dispose();
    logradouroController.dispose();
    numeroController.dispose();
    complementoController.dispose();
    bairroController.dispose();
    codigoMunicipioController.dispose();
    nomeMunicipioController.dispose();
    ufController.dispose();
    cepController.dispose();
    super.onClose();
  }

}