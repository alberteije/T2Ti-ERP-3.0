import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:pluto_grid/pluto_grid.dart';
import 'package:extended_masked_text/extended_masked_text.dart';
import 'package:cte/app/page/shared_widget/input/input_imports.dart';

import 'package:cte/app/page/page_imports.dart';
import 'package:cte/app/page/shared_widget/message_dialog.dart';
import 'package:cte/app/page/grid_columns/grid_columns_imports.dart';
import 'package:cte/app/controller/controller_imports.dart';
import 'package:cte/app/data/model/model_imports.dart';

class CteEmitenteController extends ControllerBase<CteEmitenteModel, void> {

  CteEmitenteController() : super(repository: null) {
    dbColumns = CteEmitenteModel.dbColumns;
    aliasColumns = CteEmitenteModel.aliasColumns;
    gridColumns = cteEmitenteGridColumns();
    functionName = "cte_emitente";
    screenTitle = "Emitente";
  }

  final _cteEmitenteModel = CteEmitenteModel().obs;
  CteEmitenteModel get cteEmitenteModel => _cteEmitenteModel.value;
  set cteEmitenteModel(value) => _cteEmitenteModel.value = value ?? CteEmitenteModel();

  List<CteEmitenteModel> get cteEmitenteModelList => Get.find<CteCabecalhoController>().currentModel.cteEmitenteModelList ?? [];

  final _userMadeChanges = false.obs;
  get userMadeChanges => _userMadeChanges.value;
  set userMadeChanges(value) => _userMadeChanges.value = value;

  final _formWasChangedDetail = false.obs;
  bool get formWasChangedDetail => _formWasChangedDetail.value;
  set formWasChangedDetail(value) => _formWasChangedDetail.value = value;

  late PlutoGridStateManager _plutoGridStateManager;
  @override
  PlutoGridStateManager get plutoGridStateManager => _plutoGridStateManager;
  @override
  set plutoGridStateManager(value) => _plutoGridStateManager = value;

  final cteEmitenteScaffoldKey = GlobalKey<ScaffoldState>();
  final cteEmitenteFormKey = GlobalKey<FormState>();

  @override
  CteEmitenteModel createNewModel() => CteEmitenteModel();

  @override
  final standardFieldForFilter = CteEmitenteModel.aliasColumns[CteEmitenteModel.dbColumns.indexOf('cnpj')];

  final cnpjController = MaskedTextController(mask: '00.000.000/0000-00',);
  final ieController = TextEditingController();
  final nomeController = TextEditingController();
  final fantasiaController = TextEditingController();
  final logradouroController = TextEditingController();
  final numeroController = TextEditingController();
  final complementoController = TextEditingController();
  final bairroController = TextEditingController();
  final codigoMunicipioController = MoneyMaskedTextController(precision: 0, decimalSeparator: '', thousandSeparator: '');
  final nomeMunicipioController = TextEditingController();
  final ufController = CustomDropdownButtonController('AC');
  final cepController = MaskedTextController(mask: '00000-000',);
  final telefoneController = TextEditingController();

  final Map<String, dynamic> mobileConfig = {
    'primaryColumns': ['cnpj'],
    'secondaryColumns': ['ie'],
  };

  List<Map<String, dynamic>> get mobileItems {
    return modelList.map((cteEmitente) => cteEmitente.toJson).toList();
  }

  @override
  List<PlutoRow> plutoRows() => List<PlutoRow>.from(cteEmitenteModelList.map((model) => model.toPlutoRow()));

  @override
  Future<void> getList({Filter? filter}) async {}

  @override
  void prepareForInsert() {
    isNewRecord = true;
    cteEmitenteModel = createNewModel();
    _resetForm();
    Get.to(() => CteEmitenteEditPage());
  }

  void _resetForm() {
    formWasChangedDetail = false;
    cnpjController.text = '';
    ieController.text = '';
    nomeController.text = '';
    fantasiaController.text = '';
    logradouroController.text = '';
    numeroController.text = '';
    complementoController.text = '';
    bairroController.text = '';
    codigoMunicipioController.updateValue(0);
    nomeMunicipioController.text = '';
    ufController.selected = 'AC';
    cepController.text = '';
    telefoneController.text = '';
  }

  @override
  void selectRowForEditing(PlutoRow? row) async {
    if (row == null) {
      showInfoSnackBar(message: 'message_select_one_to_edited'.tr);
      return;
    }

    selectRowForEditingByTempId(row.cells['tempId']?.value);
  }

  @override
  void selectRowForEditingById(int id) {}

  void selectRowForEditingByTempId(String tempId) {
		isNewRecord = false;
    final model = cteEmitenteModelList.firstWhere((m) => m.tempId == tempId);
    cteEmitenteModel = model.clone();
		cteEmitenteModel.tempId = model.tempId;
    updateControllersFromModel();
    Get.to(() => CteEmitenteEditPage());
  }

  void updateControllersFromModel() {
    cnpjController.text = cteEmitenteModel.cnpj ?? '';
    ieController.text = cteEmitenteModel.ie ?? '';
    nomeController.text = cteEmitenteModel.nome ?? '';
    fantasiaController.text = cteEmitenteModel.fantasia ?? '';
    logradouroController.text = cteEmitenteModel.logradouro ?? '';
    numeroController.text = cteEmitenteModel.numero ?? '';
    complementoController.text = cteEmitenteModel.complemento ?? '';
    bairroController.text = cteEmitenteModel.bairro ?? '';
    codigoMunicipioController.updateValue((cteEmitenteModel.codigoMunicipio ?? 0).toDouble());
    nomeMunicipioController.text = cteEmitenteModel.nomeMunicipio ?? '';
    ufController.selected = cteEmitenteModel.uf ?? 'AC';
    cepController.text = cteEmitenteModel.cep ?? '';
    telefoneController.text = cteEmitenteModel.telefone ?? '';
    formWasChangedDetail = false;
  }

  @override
  Future<void> save() async {
    if (!cteEmitenteFormKey.currentState!.validate()) {
      showErrorSnackBar(message: 'validator_form_message'.tr);
      return;
    }

    if (formWasChangedDetail) {
      if (isNewRecord) {
        cteEmitenteModelList.insert(0, cteEmitenteModel.clone());
      } else {
        final index = cteEmitenteModelList.indexWhere((m) => m.tempId == cteEmitenteModel.tempId);
        if (index >= 0) {
          cteEmitenteModelList[index] = cteEmitenteModel.clone();
        }
      }

      userMadeChanges = true;
      loadData();
      Get.back(result: true);
    } else {
      Get.back();
    }
  }


  @override
  Future deleteSelected() async {
    final currentRow = plutoGridStateManager.currentRow;
    if (currentRow == null) {
      showInfoSnackBar(message: 'message_select_one_to_delete'.tr);
      return null;
    }
    showDeleteDialog(() async {
      final id = currentRow.cells['id']?.value;
      final tempId = currentRow.cells['tempId']?.value;
      cteEmitenteModelList.removeWhere((model) => (id != 0 && model.id == id) || (id == 0 && model.tempId == tempId));
      plutoGridStateManager.removeCurrentRow();
      userMadeChanges = true;
    });
  }

  @override
  void preventDataLoss() {
    if (formWasChangedDetail) {
      showQuestionDialog('message_data_loss'.tr, () => Get.back());
    } else {
      formWasChangedDetail = false;
      Get.back();
    }
  }

  @override
  void onClose() {
    cnpjController.dispose();
    ieController.dispose();
    nomeController.dispose();
    fantasiaController.dispose();
    logradouroController.dispose();
    numeroController.dispose();
    complementoController.dispose();
    bairroController.dispose();
    codigoMunicipioController.dispose();
    nomeMunicipioController.dispose();
    ufController.dispose();
    cepController.dispose();
    telefoneController.dispose();
  }

}