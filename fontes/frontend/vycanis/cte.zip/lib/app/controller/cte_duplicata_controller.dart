import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:pluto_grid/pluto_grid.dart';
import 'package:extended_masked_text/extended_masked_text.dart';
import 'package:cte/app/page/shared_widget/input/input_imports.dart';

import 'package:cte/app/page/page_imports.dart';
import 'package:cte/app/page/shared_widget/message_dialog.dart';
import 'package:cte/app/page/grid_columns/grid_columns_imports.dart';
import 'package:cte/app/controller/controller_imports.dart';
import 'package:cte/app/data/model/model_imports.dart';

class CteDuplicataController extends ControllerBase<CteDuplicataModel, void> {

  CteDuplicataController() : super(repository: null) {
    dbColumns = CteDuplicataModel.dbColumns;
    aliasColumns = CteDuplicataModel.aliasColumns;
    gridColumns = cteDuplicataGridColumns();
    functionName = "cte_duplicata";
    screenTitle = "Duplicata";
  }

  final _cteDuplicataModel = CteDuplicataModel().obs;
  CteDuplicataModel get cteDuplicataModel => _cteDuplicataModel.value;
  set cteDuplicataModel(value) => _cteDuplicataModel.value = value ?? CteDuplicataModel();

  List<CteDuplicataModel> get cteDuplicataModelList => Get.find<CteCabecalhoController>().currentModel.cteDuplicataModelList ?? [];

  final _userMadeChanges = false.obs;
  get userMadeChanges => _userMadeChanges.value;
  set userMadeChanges(value) => _userMadeChanges.value = value;

  final _formWasChangedDetail = false.obs;
  bool get formWasChangedDetail => _formWasChangedDetail.value;
  set formWasChangedDetail(value) => _formWasChangedDetail.value = value;

  late PlutoGridStateManager _plutoGridStateManager;
  @override
  PlutoGridStateManager get plutoGridStateManager => _plutoGridStateManager;
  @override
  set plutoGridStateManager(value) => _plutoGridStateManager = value;

  final cteDuplicataScaffoldKey = GlobalKey<ScaffoldState>();
  final cteDuplicataFormKey = GlobalKey<FormState>();

  @override
  CteDuplicataModel createNewModel() => CteDuplicataModel();

  @override
  final standardFieldForFilter = CteDuplicataModel.aliasColumns[CteDuplicataModel.dbColumns.indexOf('numero')];

  final numeroController = TextEditingController();
  final dataVencimentoController = DatePickerItemController(null);
  final valorController = MoneyMaskedTextController();

  final Map<String, dynamic> mobileConfig = {
    'primaryColumns': ['numero'],
    'secondaryColumns': ['data_vencimento'],
  };

  List<Map<String, dynamic>> get mobileItems {
    return modelList.map((cteDuplicata) => cteDuplicata.toJson).toList();
  }

  @override
  List<PlutoRow> plutoRows() => List<PlutoRow>.from(cteDuplicataModelList.map((model) => model.toPlutoRow()));

  @override
  Future<void> getList({Filter? filter}) async {}

  @override
  void prepareForInsert() {
    isNewRecord = true;
    cteDuplicataModel = createNewModel();
    _resetForm();
    Get.to(() => CteDuplicataEditPage());
  }

  void _resetForm() {
    formWasChangedDetail = false;
    numeroController.text = '';
    dataVencimentoController.date = null;
    valorController.updateValue(0);
  }

  @override
  void selectRowForEditing(PlutoRow? row) async {
    if (row == null) {
      showInfoSnackBar(message: 'message_select_one_to_edited'.tr);
      return;
    }

    selectRowForEditingByTempId(row.cells['tempId']?.value);
  }

  @override
  void selectRowForEditingById(int id) {}

  void selectRowForEditingByTempId(String tempId) {
		isNewRecord = false;
    final model = cteDuplicataModelList.firstWhere((m) => m.tempId == tempId);
    cteDuplicataModel = model.clone();
		cteDuplicataModel.tempId = model.tempId;
    updateControllersFromModel();
    Get.to(() => CteDuplicataEditPage());
  }

  void updateControllersFromModel() {
    numeroController.text = cteDuplicataModel.numero ?? '';
    dataVencimentoController.date = cteDuplicataModel.dataVencimento;
    valorController.updateValue(cteDuplicataModel.valor ?? 0);
    formWasChangedDetail = false;
  }

  @override
  Future<void> save() async {
    if (!cteDuplicataFormKey.currentState!.validate()) {
      showErrorSnackBar(message: 'validator_form_message'.tr);
      return;
    }

    if (formWasChangedDetail) {
      if (isNewRecord) {
        cteDuplicataModelList.insert(0, cteDuplicataModel.clone());
      } else {
        final index = cteDuplicataModelList.indexWhere((m) => m.tempId == cteDuplicataModel.tempId);
        if (index >= 0) {
          cteDuplicataModelList[index] = cteDuplicataModel.clone();
        }
      }

      userMadeChanges = true;
      loadData();
      Get.back(result: true);
    } else {
      Get.back();
    }
  }


  @override
  Future deleteSelected() async {
    final currentRow = plutoGridStateManager.currentRow;
    if (currentRow == null) {
      showInfoSnackBar(message: 'message_select_one_to_delete'.tr);
      return null;
    }
    showDeleteDialog(() async {
      final id = currentRow.cells['id']?.value;
      final tempId = currentRow.cells['tempId']?.value;
      cteDuplicataModelList.removeWhere((model) => (id != 0 && model.id == id) || (id == 0 && model.tempId == tempId));
      plutoGridStateManager.removeCurrentRow();
      userMadeChanges = true;
    });
  }

  @override
  void preventDataLoss() {
    if (formWasChangedDetail) {
      showQuestionDialog('message_data_loss'.tr, () => Get.back());
    } else {
      formWasChangedDetail = false;
      Get.back();
    }
  }

  @override
  void onClose() {
    numeroController.dispose();
    dataVencimentoController.dispose();
    valorController.dispose();
  }

}