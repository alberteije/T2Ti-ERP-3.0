import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:pluto_grid/pluto_grid.dart';
import 'package:extended_masked_text/extended_masked_text.dart';
import 'package:cte/app/page/shared_widget/input/input_imports.dart';

import 'package:cte/app/page/page_imports.dart';
import 'package:cte/app/page/shared_widget/message_dialog.dart';
import 'package:cte/app/page/grid_columns/grid_columns_imports.dart';
import 'package:cte/app/controller/controller_imports.dart';
import 'package:cte/app/data/model/model_imports.dart';

class CteFerroviarioController extends ControllerBase<CteFerroviarioModel, void> {

  CteFerroviarioController() : super(repository: null) {
    dbColumns = CteFerroviarioModel.dbColumns;
    aliasColumns = CteFerroviarioModel.aliasColumns;
    gridColumns = cteFerroviarioGridColumns();
    functionName = "cte_ferroviario";
    screenTitle = "Ferroviário";
  }

  final _cteFerroviarioModel = CteFerroviarioModel().obs;
  CteFerroviarioModel get cteFerroviarioModel => _cteFerroviarioModel.value;
  set cteFerroviarioModel(value) => _cteFerroviarioModel.value = value ?? CteFerroviarioModel();

  List<CteFerroviarioModel> get cteFerroviarioModelList => Get.find<CteCabecalhoController>().currentModel.cteFerroviarioModelList ?? [];

  final _userMadeChanges = false.obs;
  get userMadeChanges => _userMadeChanges.value;
  set userMadeChanges(value) => _userMadeChanges.value = value;

  final _formWasChangedDetail = false.obs;
  bool get formWasChangedDetail => _formWasChangedDetail.value;
  set formWasChangedDetail(value) => _formWasChangedDetail.value = value;

  late PlutoGridStateManager _plutoGridStateManager;
  @override
  PlutoGridStateManager get plutoGridStateManager => _plutoGridStateManager;
  @override
  set plutoGridStateManager(value) => _plutoGridStateManager = value;

  final cteFerroviarioScaffoldKey = GlobalKey<ScaffoldState>();
  final cteFerroviarioFormKey = GlobalKey<FormState>();

  @override
  CteFerroviarioModel createNewModel() => CteFerroviarioModel();

  @override
  final standardFieldForFilter = CteFerroviarioModel.aliasColumns[CteFerroviarioModel.dbColumns.indexOf('tipo_trafego')];

  final tipoTrafegoController = CustomDropdownButtonController('0-Próprio');
  final responsavelFaturamentoController = CustomDropdownButtonController('1-Ferrovia de origem');
  final ferroviaEmitenteCteController = CustomDropdownButtonController('1-Ferrovia de origem');
  final fluxoController = TextEditingController();
  final idTremController = TextEditingController();
  final valorFreteController = MoneyMaskedTextController();

  final Map<String, dynamic> mobileConfig = {
    'primaryColumns': ['tipo_trafego'],
    'secondaryColumns': ['responsavel_faturamento'],
  };

  List<Map<String, dynamic>> get mobileItems {
    return modelList.map((cteFerroviario) => cteFerroviario.toJson).toList();
  }

  @override
  List<PlutoRow> plutoRows() => List<PlutoRow>.from(cteFerroviarioModelList.map((model) => model.toPlutoRow()));

  @override
  Future<void> getList({Filter? filter}) async {}

  @override
  void prepareForInsert() {
    isNewRecord = true;
    cteFerroviarioModel = createNewModel();
    _resetForm();
    Get.to(() => CteFerroviarioEditPage());
  }

  void _resetForm() {
    formWasChangedDetail = false;
    tipoTrafegoController.selected = '0-Próprio';
    responsavelFaturamentoController.selected = '1-Ferrovia de origem';
    ferroviaEmitenteCteController.selected = '1-Ferrovia de origem';
    fluxoController.text = '';
    idTremController.text = '';
    valorFreteController.updateValue(0);
  }

  @override
  void selectRowForEditing(PlutoRow? row) async {
    if (row == null) {
      showInfoSnackBar(message: 'message_select_one_to_edited'.tr);
      return;
    }

    selectRowForEditingByTempId(row.cells['tempId']?.value);
  }

  @override
  void selectRowForEditingById(int id) {}

  void selectRowForEditingByTempId(String tempId) {
		isNewRecord = false;
    final model = cteFerroviarioModelList.firstWhere((m) => m.tempId == tempId);
    cteFerroviarioModel = model.clone();
		cteFerroviarioModel.tempId = model.tempId;
    updateControllersFromModel();
    Get.to(() => CteFerroviarioEditPage());
  }

  void updateControllersFromModel() {
    tipoTrafegoController.selected = cteFerroviarioModel.tipoTrafego ?? '0-Próprio';
    responsavelFaturamentoController.selected = cteFerroviarioModel.responsavelFaturamento ?? '1-Ferrovia de origem';
    ferroviaEmitenteCteController.selected = cteFerroviarioModel.ferroviaEmitenteCte ?? '1-Ferrovia de origem';
    fluxoController.text = cteFerroviarioModel.fluxo ?? '';
    idTremController.text = cteFerroviarioModel.idTrem ?? '';
    valorFreteController.updateValue(cteFerroviarioModel.valorFrete ?? 0);
    formWasChangedDetail = false;
  }

  @override
  Future<void> save() async {
    if (!cteFerroviarioFormKey.currentState!.validate()) {
      showErrorSnackBar(message: 'validator_form_message'.tr);
      return;
    }

    if (formWasChangedDetail) {
      if (isNewRecord) {
        cteFerroviarioModelList.insert(0, cteFerroviarioModel.clone());
      } else {
        final index = cteFerroviarioModelList.indexWhere((m) => m.tempId == cteFerroviarioModel.tempId);
        if (index >= 0) {
          cteFerroviarioModelList[index] = cteFerroviarioModel.clone();
        }
      }

      userMadeChanges = true;
      loadData();
      Get.back(result: true);
    } else {
      Get.back();
    }
  }


  @override
  Future deleteSelected() async {
    final currentRow = plutoGridStateManager.currentRow;
    if (currentRow == null) {
      showInfoSnackBar(message: 'message_select_one_to_delete'.tr);
      return null;
    }
    showDeleteDialog(() async {
      final id = currentRow.cells['id']?.value;
      final tempId = currentRow.cells['tempId']?.value;
      cteFerroviarioModelList.removeWhere((model) => (id != 0 && model.id == id) || (id == 0 && model.tempId == tempId));
      plutoGridStateManager.removeCurrentRow();
      userMadeChanges = true;
    });
  }

  @override
  void preventDataLoss() {
    if (formWasChangedDetail) {
      showQuestionDialog('message_data_loss'.tr, () => Get.back());
    } else {
      formWasChangedDetail = false;
      Get.back();
    }
  }

  @override
  void onClose() {
    tipoTrafegoController.dispose();
    responsavelFaturamentoController.dispose();
    ferroviaEmitenteCteController.dispose();
    fluxoController.dispose();
    idTremController.dispose();
    valorFreteController.dispose();
  }

}