import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:cte/app/page/shared_widget/input/input_imports.dart';

import 'package:cte/app/page/shared_widget/message_dialog.dart';
import 'package:cte/app/page/grid_columns/grid_columns_imports.dart';
import 'package:cte/app/routes/app_routes.dart';
import 'package:cte/app/controller/controller_imports.dart';
import 'package:cte/app/data/model/model_imports.dart';
import 'package:cte/app/data/repository/cte_documento_anterior_id_repository.dart';

class CteDocumentoAnteriorIdController extends ControllerBase<CteDocumentoAnteriorIdModel, CteDocumentoAnteriorIdRepository> {

  CteDocumentoAnteriorIdController({required super.repository}) {
    dbColumns = CteDocumentoAnteriorIdModel.dbColumns;
    aliasColumns = CteDocumentoAnteriorIdModel.aliasColumns;
    gridColumns = cteDocumentoAnteriorIdGridColumns();
    functionName = "cte_documento_anterior_id";
    screenTitle = "Documento Anterior";
  }

  @override
  CteDocumentoAnteriorIdModel createNewModel() => CteDocumentoAnteriorIdModel();

  @override
  final standardFieldForFilter = CteDocumentoAnteriorIdModel.aliasColumns[CteDocumentoAnteriorIdModel.dbColumns.indexOf('tipo')];

  final tipoController = TextEditingController();
  final serieController = TextEditingController();
  final subserieController = TextEditingController();
  final numeroController = TextEditingController();
  final dataEmissaoController = DatePickerItemController(null);
  final chaveCteController = TextEditingController();

  final Map<String, dynamic> mobileConfig = {
    'primaryColumns': ['tipo'],
    'secondaryColumns': ['serie'],
  };

  List<Map<String, dynamic>> get mobileItems {
    return modelList.map((cteDocumentoAnteriorId) => cteDocumentoAnteriorId.toJson).toList();
  }

  @override
  void prepareForInsert() {
    isNewRecord = true;
    currentModel = createNewModel();
    _resetForm();
    Get.toNamed(Routes.cteDocumentoAnteriorIdEditPage);
  }

  void _resetForm() {
    formWasChanged = false;
    tipoController.text = '';
    serieController.text = '';
    subserieController.text = '';
    numeroController.text = '';
    dataEmissaoController.date = null;
    chaveCteController.text = '';
  }

  @override
  void selectRowForEditingById(int id) {
    final model = modelList.firstWhere((m) => m.id == id);
    currentModel = model.clone();
    updateControllersFromModel();
    Get.toNamed(Routes.cteDocumentoAnteriorIdEditPage);
  }

  void updateControllersFromModel() {
    tipoController.text = currentModel.tipo ?? '';
    serieController.text = currentModel.serie ?? '';
    subserieController.text = currentModel.subserie ?? '';
    numeroController.text = currentModel.numero ?? '';
    dataEmissaoController.date = currentModel.dataEmissao;
    chaveCteController.text = currentModel.chaveCte ?? '';
    formWasChanged = false;
  }

  @override
  Future<void> save() async {
    if (!formKey.currentState!.validate()) {
      showErrorSnackBar(message: 'validator_form_message'.tr);
      return;
    }

    final existingIndex = modelList.indexWhere((m) => m.id == currentModel.id);

    if (existingIndex >= 0) {
      modelList[existingIndex] = currentModel.clone();
    }

    final result = await repository.save(cteDocumentoAnteriorIdModel: currentModel);
    if (result == null) return;

    if (existingIndex >= 0) {
      modelList[existingIndex] = result;
    } else {
      modelList.insert(0, result);
    }

    if (!GetPlatform.isMobile) {
      updateGridRow(result);
    }

    Get.back(result: true);
  }


  @override
  void onClose() {
    tipoController.dispose();
    serieController.dispose();
    subserieController.dispose();
    numeroController.dispose();
    dataEmissaoController.dispose();
    chaveCteController.dispose();
    super.onClose();
  }

}