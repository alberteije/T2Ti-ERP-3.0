import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:pluto_grid/pluto_grid.dart';
import 'package:extended_masked_text/extended_masked_text.dart';
import 'package:cte/app/page/shared_widget/input/input_imports.dart';

import 'package:cte/app/page/page_imports.dart';
import 'package:cte/app/page/shared_widget/message_dialog.dart';
import 'package:cte/app/page/grid_columns/grid_columns_imports.dart';
import 'package:cte/app/controller/controller_imports.dart';
import 'package:cte/app/data/model/model_imports.dart';

class CteSeguroController extends ControllerBase<CteSeguroModel, void> {

  CteSeguroController() : super(repository: null) {
    dbColumns = CteSeguroModel.dbColumns;
    aliasColumns = CteSeguroModel.aliasColumns;
    gridColumns = cteSeguroGridColumns();
    functionName = "cte_seguro";
    screenTitle = "Seguro";
  }

  final _cteSeguroModel = CteSeguroModel().obs;
  CteSeguroModel get cteSeguroModel => _cteSeguroModel.value;
  set cteSeguroModel(value) => _cteSeguroModel.value = value ?? CteSeguroModel();

  List<CteSeguroModel> get cteSeguroModelList => Get.find<CteCabecalhoController>().currentModel.cteSeguroModelList ?? [];

  final _userMadeChanges = false.obs;
  get userMadeChanges => _userMadeChanges.value;
  set userMadeChanges(value) => _userMadeChanges.value = value;

  final _formWasChangedDetail = false.obs;
  bool get formWasChangedDetail => _formWasChangedDetail.value;
  set formWasChangedDetail(value) => _formWasChangedDetail.value = value;

  late PlutoGridStateManager _plutoGridStateManager;
  @override
  PlutoGridStateManager get plutoGridStateManager => _plutoGridStateManager;
  @override
  set plutoGridStateManager(value) => _plutoGridStateManager = value;

  final cteSeguroScaffoldKey = GlobalKey<ScaffoldState>();
  final cteSeguroFormKey = GlobalKey<FormState>();

  @override
  CteSeguroModel createNewModel() => CteSeguroModel();

  @override
  final standardFieldForFilter = CteSeguroModel.aliasColumns[CteSeguroModel.dbColumns.indexOf('responsavel')];

  final responsavelController = CustomDropdownButtonController('4 - Emitente do CTe');
  final seguradoraController = TextEditingController();
  final apoliceController = TextEditingController();
  final averbacaoController = TextEditingController();
  final valorCargaController = MoneyMaskedTextController();

  final Map<String, dynamic> mobileConfig = {
    'primaryColumns': ['responsavel'],
    'secondaryColumns': ['seguradora'],
  };

  List<Map<String, dynamic>> get mobileItems {
    return modelList.map((cteSeguro) => cteSeguro.toJson).toList();
  }

  @override
  List<PlutoRow> plutoRows() => List<PlutoRow>.from(cteSeguroModelList.map((model) => model.toPlutoRow()));

  @override
  Future<void> getList({Filter? filter}) async {}

  @override
  void prepareForInsert() {
    isNewRecord = true;
    cteSeguroModel = createNewModel();
    _resetForm();
    Get.to(() => CteSeguroEditPage());
  }

  void _resetForm() {
    formWasChangedDetail = false;
    responsavelController.selected = '4 - Emitente do CTe';
    seguradoraController.text = '';
    apoliceController.text = '';
    averbacaoController.text = '';
    valorCargaController.updateValue(0);
  }

  @override
  void selectRowForEditing(PlutoRow? row) async {
    if (row == null) {
      showInfoSnackBar(message: 'message_select_one_to_edited'.tr);
      return;
    }

    selectRowForEditingByTempId(row.cells['tempId']?.value);
  }

  @override
  void selectRowForEditingById(int id) {}

  void selectRowForEditingByTempId(String tempId) {
		isNewRecord = false;
    final model = cteSeguroModelList.firstWhere((m) => m.tempId == tempId);
    cteSeguroModel = model.clone();
		cteSeguroModel.tempId = model.tempId;
    updateControllersFromModel();
    Get.to(() => CteSeguroEditPage());
  }

  void updateControllersFromModel() {
    responsavelController.selected = cteSeguroModel.responsavel ?? '4 - Emitente do CTe';
    seguradoraController.text = cteSeguroModel.seguradora ?? '';
    apoliceController.text = cteSeguroModel.apolice ?? '';
    averbacaoController.text = cteSeguroModel.averbacao ?? '';
    valorCargaController.updateValue(cteSeguroModel.valorCarga ?? 0);
    formWasChangedDetail = false;
  }

  @override
  Future<void> save() async {
    if (!cteSeguroFormKey.currentState!.validate()) {
      showErrorSnackBar(message: 'validator_form_message'.tr);
      return;
    }

    if (formWasChangedDetail) {
      if (isNewRecord) {
        cteSeguroModelList.insert(0, cteSeguroModel.clone());
      } else {
        final index = cteSeguroModelList.indexWhere((m) => m.tempId == cteSeguroModel.tempId);
        if (index >= 0) {
          cteSeguroModelList[index] = cteSeguroModel.clone();
        }
      }

      userMadeChanges = true;
      loadData();
      Get.back(result: true);
    } else {
      Get.back();
    }
  }


  @override
  Future deleteSelected() async {
    final currentRow = plutoGridStateManager.currentRow;
    if (currentRow == null) {
      showInfoSnackBar(message: 'message_select_one_to_delete'.tr);
      return null;
    }
    showDeleteDialog(() async {
      final id = currentRow.cells['id']?.value;
      final tempId = currentRow.cells['tempId']?.value;
      cteSeguroModelList.removeWhere((model) => (id != 0 && model.id == id) || (id == 0 && model.tempId == tempId));
      plutoGridStateManager.removeCurrentRow();
      userMadeChanges = true;
    });
  }

  @override
  void preventDataLoss() {
    if (formWasChangedDetail) {
      showQuestionDialog('message_data_loss'.tr, () => Get.back());
    } else {
      formWasChangedDetail = false;
      Get.back();
    }
  }

  @override
  void onClose() {
    responsavelController.dispose();
    seguradoraController.dispose();
    apoliceController.dispose();
    averbacaoController.dispose();
    valorCargaController.dispose();
  }

}