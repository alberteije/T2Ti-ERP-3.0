import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:cte/app/page/shared_widget/input/input_imports.dart';

import 'package:cte/app/page/shared_widget/message_dialog.dart';
import 'package:cte/app/page/grid_columns/grid_columns_imports.dart';
import 'package:cte/app/routes/app_routes.dart';
import 'package:cte/app/controller/controller_imports.dart';
import 'package:cte/app/data/model/model_imports.dart';
import 'package:cte/app/data/repository/cte_informacao_nf_carga_repository.dart';

class CteInformacaoNfCargaController extends ControllerBase<CteInformacaoNfCargaModel, CteInformacaoNfCargaRepository> {

  CteInformacaoNfCargaController({required super.repository}) {
    dbColumns = CteInformacaoNfCargaModel.dbColumns;
    aliasColumns = CteInformacaoNfCargaModel.aliasColumns;
    gridColumns = cteInformacaoNfCargaGridColumns();
    functionName = "cte_informacao_nf_carga";
    screenTitle = "Cte Informacao Nf Carga";
  }

  @override
  CteInformacaoNfCargaModel createNewModel() => CteInformacaoNfCargaModel();

  @override
  final standardFieldForFilter = CteInformacaoNfCargaModel.aliasColumns[CteInformacaoNfCargaModel.dbColumns.indexOf('tipo_unidade_carga')];

  final cteInformacaoNfOutrosModelController = TextEditingController();
  final tipoUnidadeCargaController = CustomDropdownButtonController('1 - Container');
  final idUnidadeCargaController = TextEditingController();

  final Map<String, dynamic> mobileConfig = {
    'primaryColumns': ['tipo_unidade_carga'],
    'secondaryColumns': ['id_unidade_carga'],
  };

  List<Map<String, dynamic>> get mobileItems {
    return modelList.map((cteInformacaoNfCarga) => cteInformacaoNfCarga.toJson).toList();
  }

  @override
  void prepareForInsert() {
    isNewRecord = true;
    currentModel = createNewModel();
    _resetForm();
    Get.toNamed(Routes.cteInformacaoNfCargaEditPage);
  }

  void _resetForm() {
    formWasChanged = false;
    cteInformacaoNfOutrosModelController.text = '';
    tipoUnidadeCargaController.selected = '1 - Container';
    idUnidadeCargaController.text = '';
  }

  @override
  void selectRowForEditingById(int id) {
    final model = modelList.firstWhere((m) => m.id == id);
    currentModel = model.clone();
    updateControllersFromModel();
    Get.toNamed(Routes.cteInformacaoNfCargaEditPage);
  }

  void updateControllersFromModel() {
    cteInformacaoNfOutrosModelController.text = currentModel.cteInformacaoNfOutrosModel?.numero?.toString() ?? '';
    tipoUnidadeCargaController.selected = currentModel.tipoUnidadeCarga ?? '1 - Container';
    idUnidadeCargaController.text = currentModel.idUnidadeCarga ?? '';
    formWasChanged = false;
  }

  @override
  Future<void> save() async {
    if (!formKey.currentState!.validate()) {
      showErrorSnackBar(message: 'validator_form_message'.tr);
      return;
    }

    final existingIndex = modelList.indexWhere((m) => m.id == currentModel.id);

    if (existingIndex >= 0) {
      modelList[existingIndex] = currentModel.clone();
    }

    final result = await repository.save(cteInformacaoNfCargaModel: currentModel);
    if (result == null) return;

    if (existingIndex >= 0) {
      modelList[existingIndex] = result;
    } else {
      modelList.insert(0, result);
    }

    if (!GetPlatform.isMobile) {
      updateGridRow(result);
    }

    Get.back(result: true);
  }

  Future callCteInformacaoNfOutrosLookup() async { 
		final lookupController = Get.find<LookupController>(); 
		lookupController.refreshItems(standardValue: '%'); 
		lookupController.title = '${'lookup_page_title'.tr} [Id Cte Informacao Nf]'; 
		lookupController.route = '/cte-informacao-nf-outros/'; 
		lookupController.gridColumns = cteInformacaoNfOutrosGridColumns(isForLookup: true); 
		lookupController.aliasColumns = CteInformacaoNfOutrosModel.aliasColumns; 
		lookupController.dbColumns = CteInformacaoNfOutrosModel.dbColumns; 
		lookupController.standardColumn = CteInformacaoNfOutrosModel.aliasColumns[CteInformacaoNfOutrosModel.dbColumns.indexOf('numero')]; 

		final plutoRowResult = await Get.toNamed(Routes.lookupPage); 
		if (plutoRowResult != null) { 
			currentModel.idCteInformacaoNf = plutoRowResult.cells['id']!.value; 
			currentModel.cteInformacaoNfOutrosModel = CteInformacaoNfOutrosModel.fromPlutoRow(plutoRowResult); 
			cteInformacaoNfOutrosModelController.text = currentModel.cteInformacaoNfOutrosModel?.numero ?? ''; 
			formWasChanged = true; 
		}
	}


  @override
  void onClose() {
    cteInformacaoNfOutrosModelController.dispose();
    tipoUnidadeCargaController.dispose();
    idUnidadeCargaController.dispose();
    super.onClose();
  }

}