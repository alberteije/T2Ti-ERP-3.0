import 'dart:typed_data';

import 'package:cte/app/page/shared_page/shared_page_imports.dart';
import 'package:flutter/material.dart';
import 'dart:math';
import 'package:get/get.dart';
import 'package:extended_masked_text/extended_masked_text.dart';
import 'package:cte/app/page/shared_widget/input/input_imports.dart';

import 'package:cte/app/infra/infra_imports.dart';
import 'package:cte/app/page/page_imports.dart';
import 'package:cte/app/page/shared_widget/message_dialog.dart';
import 'package:cte/app/page/grid_columns/grid_columns_imports.dart';
import 'package:cte/app/routes/app_routes.dart';
import 'package:cte/app/controller/controller_imports.dart';
import 'package:cte/app/data/model/model_imports.dart';
import 'package:cte/app/data/repository/cte_cabecalho_repository.dart';

class CteCabecalhoController extends ControllerBase<CteCabecalhoModel, CteCabecalhoRepository> 
with GetSingleTickerProviderStateMixin {

  CteCabecalhoController({required super.repository}) {
    dbColumns = CteCabecalhoModel.dbColumns;
    aliasColumns = CteCabecalhoModel.aliasColumns;
    gridColumns = cteCabecalhoGridColumns();
    functionName = "cte_cabecalho";
    screenTitle = "CT-e";
  }

  final cteCabecalhoScaffoldKey = GlobalKey<ScaffoldState>();
  final cteCabecalhoTabPageScaffoldKey = GlobalKey<ScaffoldState>();
  final cteCabecalhoFormKey = GlobalKey<FormState>();
  late TabController tabController;
  String? mandatoryMessage;  

  @override
  CteCabecalhoModel createNewModel() => CteCabecalhoModel();

  @override
  final standardFieldForFilter = CteCabecalhoModel.aliasColumns[CteCabecalhoModel.dbColumns.indexOf('natureza_operacao')];

  final naturezaOperacaoController = TextEditingController();
  final chaveAcessoController = TextEditingController();
  final digitoChaveAcessoController = TextEditingController();
  final codigoNumericoController = TextEditingController();
  final serieController = TextEditingController();
  final numeroController = TextEditingController();
  final dataHoraEmissaoController = DatePickerItemController(null);
  final ufEmitenteController = CustomDropdownButtonController('AC');
  final cfopController = MoneyMaskedTextController(precision: 0, decimalSeparator: '', thousandSeparator: '');
  final formaPagamentoController = CustomDropdownButtonController('0-Pago');
  final modeloController = CustomDropdownButtonController('57');
  final formatoImpressaoDacteController = CustomDropdownButtonController('1-Retrato');
  final tipoEmissaoController = CustomDropdownButtonController('1 - Normal');
  final ambienteController = CustomDropdownButtonController('1-Produção');
  final tipoCteController = CustomDropdownButtonController('0 - CT-e Normal');
  final processoEmissaoController = CustomDropdownButtonController('0 - emissão de CT-e com aplicativo do contribuinte; 1 - emissão de CT-e avulsa pelo Fisco; 2 - emissão de CT-e avulsa');
  final versaoProcessoEmissaoController = TextEditingController();
  final chaveReferenciadoController = TextEditingController();
  final codigoMunicipioEnvioController = MoneyMaskedTextController(precision: 0, decimalSeparator: '', thousandSeparator: '');
  final nomeMunicipioEnvioController = TextEditingController();
  final ufEnvioController = CustomDropdownButtonController('AC');
  final modalController = CustomDropdownButtonController('01-Rodoviário');
  final tipoServicoController = CustomDropdownButtonController('0 - Normal');
  final codigoMunicipioIniPrestacaoController = MoneyMaskedTextController(precision: 0, decimalSeparator: '', thousandSeparator: '');
  final nomeMunicipioIniPrestacaoController = TextEditingController();
  final ufIniPrestacaoController = CustomDropdownButtonController('AC');
  final codigoMunicipioFimPrestacaoController = MoneyMaskedTextController(precision: 0, decimalSeparator: '', thousandSeparator: '');
  final nomeMunicipioFimPrestacaoController = TextEditingController();
  final ufFimPrestacaoController = CustomDropdownButtonController('AC');
  final retiraController = CustomDropdownButtonController('Sim');
  final retiraDetalheController = TextEditingController();
  final tomadorController = CustomDropdownButtonController('0-Remetente');
  final dataEntradaContingenciaController = DatePickerItemController(null);
  final justificativaContingenciaController = TextEditingController();
  final caracAdicionalTransporteController = TextEditingController();
  final caracAdicionalServicoController = TextEditingController();
  final funcionarioEmissorController = TextEditingController();
  final fluxoOrigemController = TextEditingController();
  final entregaTipoPeriodoController = CustomDropdownButtonController('0-Sem data definida');
  final entregaDataProgramadaController = DatePickerItemController(null);
  final entregaDataInicialController = DatePickerItemController(null);
  final entregaDataFinalController = DatePickerItemController(null);
  final entregaTipoHoraController = CustomDropdownButtonController('0-Sem hora definida');
  final entregaHoraProgramadaController = TextEditingController();
  final entregaHoraInicialController = TextEditingController();
  final entregaHoraFinalController = TextEditingController();
  final municipioOrigemCalculoController = TextEditingController();
  final municipioDestinoCalculoController = TextEditingController();
  final observacoesGeraisController = TextEditingController();
  final valorTotalServicoController = MoneyMaskedTextController();
  final valorReceberController = MoneyMaskedTextController();
  final cstController = TextEditingController();
  final baseCalculoIcmsController = MoneyMaskedTextController();
  final aliquotaIcmsController = MoneyMaskedTextController();
  final valorIcmsController = MoneyMaskedTextController();
  final percentualReducaoBcIcmsController = MoneyMaskedTextController();
  final valorBcIcmsStRetidoController = MoneyMaskedTextController();
  final valorIcmsStRetidoController = MoneyMaskedTextController();
  final aliquotaIcmsStRetidoController = MoneyMaskedTextController();
  final valorCreditoPresumidoIcmsController = MoneyMaskedTextController();
  final percentualBcIcmsOutraUfController = MoneyMaskedTextController();
  final valorBcIcmsOutraUfController = MoneyMaskedTextController();
  final aliquotaIcmsOutraUfController = MoneyMaskedTextController();
  final valorIcmsOutraUfController = MoneyMaskedTextController();
  final simplesNacionalIndicadorController = CustomDropdownButtonController('Sim');
  final simplesNacionalTotalController = MoneyMaskedTextController();
  final informacoesAddFiscoController = TextEditingController();
  final valorTotalCargaController = MoneyMaskedTextController();
  final produtoPredominanteController = TextEditingController();
  final cargaOutrasCaracteristicasController = TextEditingController();
  final modalVersaoLayoutController = MoneyMaskedTextController(precision: 0, decimalSeparator: '', thousandSeparator: '');
  final chaveCteSubstituidoController = TextEditingController();

  final Map<String, dynamic> mobileConfig = {
    'primaryColumns': ['natureza_operacao'],
    'secondaryColumns': ['chave_acesso'],
  };

  List<Map<String, dynamic>> get mobileItems {
    return modelList.map((cteCabecalho) => cteCabecalho.toJson).toList();
  }

  @override
  void prepareForInsert() {
    isNewRecord = true;
    currentModel = createNewModel();
    _resetForm();
    tabController.animateTo(0);
    updateControllersFromModel();
    Get.toNamed(Routes.cteCabecalhoTabPage);
  }

  void _resetForm() {
    formWasChanged = false;
    naturezaOperacaoController.text = '';
    chaveAcessoController.text = '';
    digitoChaveAcessoController.text = '';
    codigoNumericoController.text = '';
    serieController.text = '';
    numeroController.text = '';
    dataHoraEmissaoController.date = null;
    ufEmitenteController.selected = 'AC';
    cfopController.updateValue(0);
    formaPagamentoController.selected = '0-Pago';
    modeloController.selected = '57';
    formatoImpressaoDacteController.selected = '1-Retrato';
    tipoEmissaoController.selected = '1 - Normal';
    ambienteController.selected = '1-Produção';
    tipoCteController.selected = '0 - CT-e Normal';
    processoEmissaoController.selected = '0 - emissão de CT-e com aplicativo do contribuinte; 1 - emissão de CT-e avulsa pelo Fisco; 2 - emissão de CT-e avulsa';
    versaoProcessoEmissaoController.text = '';
    chaveReferenciadoController.text = '';
    codigoMunicipioEnvioController.updateValue(0);
    nomeMunicipioEnvioController.text = '';
    ufEnvioController.selected = 'AC';
    modalController.selected = '01-Rodoviário';
    tipoServicoController.selected = '0 - Normal';
    codigoMunicipioIniPrestacaoController.updateValue(0);
    nomeMunicipioIniPrestacaoController.text = '';
    ufIniPrestacaoController.selected = 'AC';
    codigoMunicipioFimPrestacaoController.updateValue(0);
    nomeMunicipioFimPrestacaoController.text = '';
    ufFimPrestacaoController.selected = 'AC';
    retiraController.selected = 'Sim';
    retiraDetalheController.text = '';
    tomadorController.selected = '0-Remetente';
    dataEntradaContingenciaController.date = null;
    justificativaContingenciaController.text = '';
    caracAdicionalTransporteController.text = '';
    caracAdicionalServicoController.text = '';
    funcionarioEmissorController.text = '';
    fluxoOrigemController.text = '';
    entregaTipoPeriodoController.selected = '0-Sem data definida';
    entregaDataProgramadaController.date = null;
    entregaDataInicialController.date = null;
    entregaDataFinalController.date = null;
    entregaTipoHoraController.selected = '0-Sem hora definida';
    entregaHoraProgramadaController.text = '';
    entregaHoraInicialController.text = '';
    entregaHoraFinalController.text = '';
    municipioOrigemCalculoController.text = '';
    municipioDestinoCalculoController.text = '';
    observacoesGeraisController.text = '';
    valorTotalServicoController.updateValue(0);
    valorReceberController.updateValue(0);
    cstController.text = '';
    baseCalculoIcmsController.updateValue(0);
    aliquotaIcmsController.updateValue(0);
    valorIcmsController.updateValue(0);
    percentualReducaoBcIcmsController.updateValue(0);
    valorBcIcmsStRetidoController.updateValue(0);
    valorIcmsStRetidoController.updateValue(0);
    aliquotaIcmsStRetidoController.updateValue(0);
    valorCreditoPresumidoIcmsController.updateValue(0);
    percentualBcIcmsOutraUfController.updateValue(0);
    valorBcIcmsOutraUfController.updateValue(0);
    aliquotaIcmsOutraUfController.updateValue(0);
    valorIcmsOutraUfController.updateValue(0);
    simplesNacionalIndicadorController.selected = 'Sim';
    simplesNacionalTotalController.updateValue(0);
    informacoesAddFiscoController.text = '';
    valorTotalCargaController.updateValue(0);
    produtoPredominanteController.text = '';
    cargaOutrasCaracteristicasController.text = '';
    modalVersaoLayoutController.updateValue(0);
    chaveCteSubstituidoController.text = '';
  }

  @override
  void selectRowForEditingById(int id) {
    final model = modelList.firstWhere((m) => m.id == id);
    currentModel = model.clone();
    updateControllersFromModel();
    tabController.animateTo(0);
    Get.toNamed(Routes.cteCabecalhoTabPage);
  }

  _configureChildrenControllers() {
    //Emitente
		Get.put<CteEmitenteController>(CteEmitenteController()); 

    //Local Coleta
		Get.put<CteLocalColetaController>(CteLocalColetaController()); 

    //Tomador
		Get.put<CteTomadorController>(CteTomadorController()); 

    //Passagem
		Get.put<CtePassagemController>(CtePassagemController()); 

    //Remetente
		Get.put<CteRemetenteController>(CteRemetenteController()); 

    //Expedidor
		Get.put<CteExpedidorController>(CteExpedidorController()); 

    //Recebedor
		Get.put<CteRecebedorController>(CteRecebedorController()); 

    //Destinatário
		Get.put<CteDestinatarioController>(CteDestinatarioController()); 

    //Local Entrega
		Get.put<CteLocalEntregaController>(CteLocalEntregaController()); 

    //Componente
		Get.put<CteComponenteController>(CteComponenteController()); 

    //Carga
		Get.put<CteCargaController>(CteCargaController()); 

    //NF Outros
		Get.put<CteInformacaoNfOutrosController>(CteInformacaoNfOutrosController()); 

    //Seguro
		Get.put<CteSeguroController>(CteSeguroController()); 

    //Perigoso
		Get.put<CtePerigosoController>(CtePerigosoController()); 

    //Veículo Novo
		Get.put<CteVeiculoNovoController>(CteVeiculoNovoController()); 

    //Fatura
		Get.put<CteFaturaController>(CteFaturaController()); 

    //Duplicata
		Get.put<CteDuplicataController>(CteDuplicataController()); 

    //Rodoviário
		Get.put<CteRodoviarioController>(CteRodoviarioController()); 

    //Aéreo
		Get.put<CteAereoController>(CteAereoController()); 

    //Aquaviário
		Get.put<CteAquaviarioController>(CteAquaviarioController()); 

    //Ferroviário
		Get.put<CteFerroviarioController>(CteFerroviarioController()); 

    //Dutoviário
		Get.put<CteDutoviarioController>(CteDutoviarioController()); 

    //Multimodal
		Get.put<CteMultimodalController>(CteMultimodalController()); 

  }
	
	_releaseChildrenControllers() {
    //Emitente
		Get.delete<CteEmitenteController>(); 

    //Local Coleta
		Get.delete<CteLocalColetaController>(); 

    //Tomador
		Get.delete<CteTomadorController>(); 

    //Passagem
		Get.delete<CtePassagemController>(); 

    //Remetente
		Get.delete<CteRemetenteController>(); 

    //Expedidor
		Get.delete<CteExpedidorController>(); 

    //Recebedor
		Get.delete<CteRecebedorController>(); 

    //Destinatário
		Get.delete<CteDestinatarioController>(); 

    //Local Entrega
		Get.delete<CteLocalEntregaController>(); 

    //Componente
		Get.delete<CteComponenteController>(); 

    //Carga
		Get.delete<CteCargaController>(); 

    //NF Outros
		Get.delete<CteInformacaoNfOutrosController>(); 

    //Seguro
		Get.delete<CteSeguroController>(); 

    //Perigoso
		Get.delete<CtePerigosoController>(); 

    //Veículo Novo
		Get.delete<CteVeiculoNovoController>(); 

    //Fatura
		Get.delete<CteFaturaController>(); 

    //Duplicata
		Get.delete<CteDuplicataController>(); 

    //Rodoviário
		Get.delete<CteRodoviarioController>(); 

    //Aéreo
		Get.delete<CteAereoController>(); 

    //Aquaviário
		Get.delete<CteAquaviarioController>(); 

    //Ferroviário
		Get.delete<CteFerroviarioController>(); 

    //Dutoviário
		Get.delete<CteDutoviarioController>(); 

    //Multimodal
		Get.delete<CteMultimodalController>(); 

	}
  
  void updateControllersFromModel() {
    naturezaOperacaoController.text = currentModel.naturezaOperacao ?? '';
    chaveAcessoController.text = currentModel.chaveAcesso ?? '';
    digitoChaveAcessoController.text = currentModel.digitoChaveAcesso ?? '';
    codigoNumericoController.text = currentModel.codigoNumerico ?? '';
    serieController.text = currentModel.serie ?? '';
    numeroController.text = currentModel.numero ?? '';
    dataHoraEmissaoController.date = currentModel.dataHoraEmissao;
    ufEmitenteController.selected = currentModel.ufEmitente ?? 'AC';
    cfopController.updateValue((currentModel.cfop ?? 0).toDouble());
    formaPagamentoController.selected = currentModel.formaPagamento ?? '0-Pago';
    modeloController.selected = currentModel.modelo ?? '57';
    formatoImpressaoDacteController.selected = currentModel.formatoImpressaoDacte ?? '1-Retrato';
    tipoEmissaoController.selected = currentModel.tipoEmissao ?? '1 - Normal';
    ambienteController.selected = currentModel.ambiente ?? '1-Produção';
    tipoCteController.selected = currentModel.tipoCte ?? '0 - CT-e Normal';
    processoEmissaoController.selected = currentModel.processoEmissao ?? '0 - emissão de CT-e com aplicativo do contribuinte; 1 - emissão de CT-e avulsa pelo Fisco; 2 - emissão de CT-e avulsa';
    versaoProcessoEmissaoController.text = currentModel.versaoProcessoEmissao ?? '';
    chaveReferenciadoController.text = currentModel.chaveReferenciado ?? '';
    codigoMunicipioEnvioController.updateValue((currentModel.codigoMunicipioEnvio ?? 0).toDouble());
    nomeMunicipioEnvioController.text = currentModel.nomeMunicipioEnvio ?? '';
    ufEnvioController.selected = currentModel.ufEnvio ?? 'AC';
    modalController.selected = currentModel.modal ?? '01-Rodoviário';
    tipoServicoController.selected = currentModel.tipoServico ?? '0 - Normal';
    codigoMunicipioIniPrestacaoController.updateValue((currentModel.codigoMunicipioIniPrestacao ?? 0).toDouble());
    nomeMunicipioIniPrestacaoController.text = currentModel.nomeMunicipioIniPrestacao ?? '';
    ufIniPrestacaoController.selected = currentModel.ufIniPrestacao ?? 'AC';
    codigoMunicipioFimPrestacaoController.updateValue((currentModel.codigoMunicipioFimPrestacao ?? 0).toDouble());
    nomeMunicipioFimPrestacaoController.text = currentModel.nomeMunicipioFimPrestacao ?? '';
    ufFimPrestacaoController.selected = currentModel.ufFimPrestacao ?? 'AC';
    retiraController.selected = currentModel.retira ?? 'Sim';
    retiraDetalheController.text = currentModel.retiraDetalhe ?? '';
    tomadorController.selected = currentModel.tomador ?? '0-Remetente';
    dataEntradaContingenciaController.date = currentModel.dataEntradaContingencia;
    justificativaContingenciaController.text = currentModel.justificativaContingencia ?? '';
    caracAdicionalTransporteController.text = currentModel.caracAdicionalTransporte ?? '';
    caracAdicionalServicoController.text = currentModel.caracAdicionalServico ?? '';
    funcionarioEmissorController.text = currentModel.funcionarioEmissor ?? '';
    fluxoOrigemController.text = currentModel.fluxoOrigem ?? '';
    entregaTipoPeriodoController.selected = currentModel.entregaTipoPeriodo ?? '0-Sem data definida';
    entregaDataProgramadaController.date = currentModel.entregaDataProgramada;
    entregaDataInicialController.date = currentModel.entregaDataInicial;
    entregaDataFinalController.date = currentModel.entregaDataFinal;
    entregaTipoHoraController.selected = currentModel.entregaTipoHora ?? '0-Sem hora definida';
    entregaHoraProgramadaController.text = currentModel.entregaHoraProgramada ?? '';
    entregaHoraInicialController.text = currentModel.entregaHoraInicial ?? '';
    entregaHoraFinalController.text = currentModel.entregaHoraFinal ?? '';
    municipioOrigemCalculoController.text = currentModel.municipioOrigemCalculo ?? '';
    municipioDestinoCalculoController.text = currentModel.municipioDestinoCalculo ?? '';
    observacoesGeraisController.text = currentModel.observacoesGerais ?? '';
    valorTotalServicoController.updateValue(currentModel.valorTotalServico ?? 0);
    valorReceberController.updateValue(currentModel.valorReceber ?? 0);
    cstController.text = currentModel.cst ?? '';
    baseCalculoIcmsController.updateValue(currentModel.baseCalculoIcms ?? 0);
    aliquotaIcmsController.updateValue(currentModel.aliquotaIcms ?? 0);
    valorIcmsController.updateValue(currentModel.valorIcms ?? 0);
    percentualReducaoBcIcmsController.updateValue(currentModel.percentualReducaoBcIcms ?? 0);
    valorBcIcmsStRetidoController.updateValue(currentModel.valorBcIcmsStRetido ?? 0);
    valorIcmsStRetidoController.updateValue(currentModel.valorIcmsStRetido ?? 0);
    aliquotaIcmsStRetidoController.updateValue(currentModel.aliquotaIcmsStRetido ?? 0);
    valorCreditoPresumidoIcmsController.updateValue(currentModel.valorCreditoPresumidoIcms ?? 0);
    percentualBcIcmsOutraUfController.updateValue(currentModel.percentualBcIcmsOutraUf ?? 0);
    valorBcIcmsOutraUfController.updateValue(currentModel.valorBcIcmsOutraUf ?? 0);
    aliquotaIcmsOutraUfController.updateValue(currentModel.aliquotaIcmsOutraUf ?? 0);
    valorIcmsOutraUfController.updateValue(currentModel.valorIcmsOutraUf ?? 0);
    simplesNacionalIndicadorController.selected = currentModel.simplesNacionalIndicador ?? 'Sim';
    simplesNacionalTotalController.updateValue(currentModel.simplesNacionalTotal ?? 0);
    informacoesAddFiscoController.text = currentModel.informacoesAddFisco ?? '';
    valorTotalCargaController.updateValue(currentModel.valorTotalCarga ?? 0);
    produtoPredominanteController.text = currentModel.produtoPredominante ?? '';
    cargaOutrasCaracteristicasController.text = currentModel.cargaOutrasCaracteristicas ?? '';
    modalVersaoLayoutController.updateValue((currentModel.modalVersaoLayout ?? 0).toDouble());
    chaveCteSubstituidoController.text = currentModel.chaveCteSubstituido ?? '';

    formWasChanged = false;
    _updateChildrenControllersFromModel();
  }

  void _updateChildrenControllersFromModel() {
    //Emitente
		final cteEmitenteController = Get.find<CteEmitenteController>(); 
		cteEmitenteController.userMadeChanges = false; 

    //Local Coleta
		final cteLocalColetaController = Get.find<CteLocalColetaController>(); 
		cteLocalColetaController.userMadeChanges = false; 

    //Tomador
		final cteTomadorController = Get.find<CteTomadorController>(); 
		cteTomadorController.userMadeChanges = false; 

    //Passagem
		final ctePassagemController = Get.find<CtePassagemController>(); 
		ctePassagemController.userMadeChanges = false; 

    //Remetente
		final cteRemetenteController = Get.find<CteRemetenteController>(); 
		cteRemetenteController.userMadeChanges = false; 

    //Expedidor
		final cteExpedidorController = Get.find<CteExpedidorController>(); 
		cteExpedidorController.userMadeChanges = false; 

    //Recebedor
		final cteRecebedorController = Get.find<CteRecebedorController>(); 
		cteRecebedorController.userMadeChanges = false; 

    //Destinatário
		final cteDestinatarioController = Get.find<CteDestinatarioController>(); 
		cteDestinatarioController.userMadeChanges = false; 

    //Local Entrega
		final cteLocalEntregaController = Get.find<CteLocalEntregaController>(); 
		cteLocalEntregaController.userMadeChanges = false; 

    //Componente
		final cteComponenteController = Get.find<CteComponenteController>(); 
		cteComponenteController.userMadeChanges = false; 

    //Carga
		final cteCargaController = Get.find<CteCargaController>(); 
		cteCargaController.userMadeChanges = false; 

    //NF Outros
		final cteInformacaoNfOutrosController = Get.find<CteInformacaoNfOutrosController>(); 
		cteInformacaoNfOutrosController.userMadeChanges = false; 

    //Seguro
		final cteSeguroController = Get.find<CteSeguroController>(); 
		cteSeguroController.userMadeChanges = false; 

    //Perigoso
		final ctePerigosoController = Get.find<CtePerigosoController>(); 
		ctePerigosoController.userMadeChanges = false; 

    //Veículo Novo
		final cteVeiculoNovoController = Get.find<CteVeiculoNovoController>(); 
		cteVeiculoNovoController.userMadeChanges = false; 

    //Fatura
		final cteFaturaController = Get.find<CteFaturaController>(); 
		cteFaturaController.userMadeChanges = false; 

    //Duplicata
		final cteDuplicataController = Get.find<CteDuplicataController>(); 
		cteDuplicataController.userMadeChanges = false; 

    //Rodoviário
		final cteRodoviarioController = Get.find<CteRodoviarioController>(); 
		cteRodoviarioController.userMadeChanges = false; 

    //Aéreo
		final cteAereoController = Get.find<CteAereoController>(); 
		cteAereoController.userMadeChanges = false; 

    //Aquaviário
		final cteAquaviarioController = Get.find<CteAquaviarioController>(); 
		cteAquaviarioController.userMadeChanges = false; 

    //Ferroviário
		final cteFerroviarioController = Get.find<CteFerroviarioController>(); 
		cteFerroviarioController.userMadeChanges = false; 

    //Dutoviário
		final cteDutoviarioController = Get.find<CteDutoviarioController>(); 
		cteDutoviarioController.userMadeChanges = false; 

    //Multimodal
		final cteMultimodalController = Get.find<CteMultimodalController>(); 
		cteMultimodalController.userMadeChanges = false; 

  }

  @override
  Future<void> save() async {
    if (!validateCurrentForm()) return;
    if (validateForms()) {
      if (userMadeChanges()) {
        final existingIndex = modelList.indexWhere((m) => m.id == currentModel.id);

        if (existingIndex >= 0) {
          modelList[existingIndex] = currentModel.clone();
        }

        final result = await repository.save(cteCabecalhoModel: currentModel);
        if (result == null) return;

        if (existingIndex >= 0) {
          modelList[existingIndex] = result;
        } else {
          modelList.insert(0, result);
        }

        if (!GetPlatform.isMobile) {
          updateGridRow(result);
        }

        Get.back(result: true);
      } else {
        Get.back();
      }
    } 
  }


  List<Tab> tabItems = [
    Tab( 
			icon: Icon(iconDataList[Random().nextInt(10)]), 
			text: 'CT-e', 
		),
    Tab( 
			icon: Icon(iconDataList[Random().nextInt(10)]), 
			text: 'Emitente', 
		),
    Tab( 
			icon: Icon(iconDataList[Random().nextInt(10)]), 
			text: 'Local Coleta', 
		),
    Tab( 
			icon: Icon(iconDataList[Random().nextInt(10)]), 
			text: 'Tomador', 
		),
    Tab( 
			icon: Icon(iconDataList[Random().nextInt(10)]), 
			text: 'Passagem', 
		),
    Tab( 
			icon: Icon(iconDataList[Random().nextInt(10)]), 
			text: 'Remetente', 
		),
    Tab( 
			icon: Icon(iconDataList[Random().nextInt(10)]), 
			text: 'Expedidor', 
		),
    Tab( 
			icon: Icon(iconDataList[Random().nextInt(10)]), 
			text: 'Recebedor', 
		),
    Tab( 
			icon: Icon(iconDataList[Random().nextInt(10)]), 
			text: 'Destinatário', 
		),
    Tab( 
			icon: Icon(iconDataList[Random().nextInt(10)]), 
			text: 'Local Entrega', 
		),
    Tab( 
			icon: Icon(iconDataList[Random().nextInt(10)]), 
			text: 'Componente', 
		),
    Tab( 
			icon: Icon(iconDataList[Random().nextInt(10)]), 
			text: 'Carga', 
		),
    Tab( 
			icon: Icon(iconDataList[Random().nextInt(10)]), 
			text: 'NF Outros', 
		),
    Tab( 
			icon: Icon(iconDataList[Random().nextInt(10)]), 
			text: 'Seguro', 
		),
    Tab( 
			icon: Icon(iconDataList[Random().nextInt(10)]), 
			text: 'Perigoso', 
		),
    Tab( 
			icon: Icon(iconDataList[Random().nextInt(10)]), 
			text: 'Veículo Novo', 
		),
    Tab( 
			icon: Icon(iconDataList[Random().nextInt(10)]), 
			text: 'Fatura', 
		),
    Tab( 
			icon: Icon(iconDataList[Random().nextInt(10)]), 
			text: 'Duplicata', 
		),
    Tab( 
			icon: Icon(iconDataList[Random().nextInt(10)]), 
			text: 'Rodoviário', 
		),
    Tab( 
			icon: Icon(iconDataList[Random().nextInt(10)]), 
			text: 'Aéreo', 
		),
    Tab( 
			icon: Icon(iconDataList[Random().nextInt(10)]), 
			text: 'Aquaviário', 
		),
    Tab( 
			icon: Icon(iconDataList[Random().nextInt(10)]), 
			text: 'Ferroviário', 
		),
    Tab( 
			icon: Icon(iconDataList[Random().nextInt(10)]), 
			text: 'Dutoviário', 
		),
    Tab( 
			icon: Icon(iconDataList[Random().nextInt(10)]), 
			text: 'Multimodal', 
		),
  ];

  List<Widget> tabPages() {
    return [
      CteCabecalhoEditPage(),
      const CteEmitenteListPage(),
      const CteLocalColetaListPage(),
      const CteTomadorListPage(),
      const CtePassagemListPage(),
      const CteRemetenteListPage(),
      const CteExpedidorListPage(),
      const CteRecebedorListPage(),
      const CteDestinatarioListPage(),
      const CteLocalEntregaListPage(),
      const CteComponenteListPage(),
      const CteCargaListPage(),
      const CteInformacaoNfOutrosListPage(),
      const CteSeguroListPage(),
      const CtePerigosoListPage(),
      const CteVeiculoNovoListPage(),
      const CteFaturaListPage(),
      const CteDuplicataListPage(),
      const CteRodoviarioListPage(),
      const CteAereoListPage(),
      const CteAquaviarioListPage(),
      const CteFerroviarioListPage(),
      const CteDutoviarioListPage(),
      const CteMultimodalListPage(),
    ];
  }

  @override
  void preventDataLoss() {
    if (userMadeChanges()) {
      showQuestionDialog('message_data_loss'.tr, () { 
        Get.back(); 
      });
    } else {
      Get.back();
    }
  }  

  bool userMadeChanges() {
    return
    formWasChanged 
    || 
		Get.find<CteEmitenteController>().userMadeChanges
    || 
		Get.find<CteLocalColetaController>().userMadeChanges
    || 
		Get.find<CteTomadorController>().userMadeChanges
    || 
		Get.find<CtePassagemController>().userMadeChanges
    || 
		Get.find<CteRemetenteController>().userMadeChanges
    || 
		Get.find<CteExpedidorController>().userMadeChanges
    || 
		Get.find<CteRecebedorController>().userMadeChanges
    || 
		Get.find<CteDestinatarioController>().userMadeChanges
    || 
		Get.find<CteLocalEntregaController>().userMadeChanges
    || 
		Get.find<CteComponenteController>().userMadeChanges
    || 
		Get.find<CteCargaController>().userMadeChanges
    || 
		Get.find<CteInformacaoNfOutrosController>().userMadeChanges
    || 
		Get.find<CteSeguroController>().userMadeChanges
    || 
		Get.find<CtePerigosoController>().userMadeChanges
    || 
		Get.find<CteVeiculoNovoController>().userMadeChanges
    || 
		Get.find<CteFaturaController>().userMadeChanges
    || 
		Get.find<CteDuplicataController>().userMadeChanges
    || 
		Get.find<CteRodoviarioController>().userMadeChanges
    || 
		Get.find<CteAereoController>().userMadeChanges
    || 
		Get.find<CteAquaviarioController>().userMadeChanges
    || 
		Get.find<CteFerroviarioController>().userMadeChanges
    || 
		Get.find<CteDutoviarioController>().userMadeChanges
    || 
		Get.find<CteMultimodalController>().userMadeChanges
    ;
  }

  void tabChange(int index) {
    validateCurrentForm();
  }

  bool validateCurrentForm() {
    return true;
  }

  bool validateForms() {
    return true;
  }

  Future transmitirCte() async {
    if (currentModel.id == null) {
      showErrorSnackBar(message: 'Primeiro salve o documento para então transmiti-lo.');
      return;
    }

    showQuestionDialog('Deseja Gerar e Transmitir a CT-e?', () async {
      try {
        final result = await repository.transmitirCte(cteCabecalhoModel: currentModel);
        if (result == null) return;

        if (result is String) {
          showErrorDialog('Ocorreu um problema na geração da CT-e: \n$result');
        } else if (result is Uint8List) {
          _imprimirDacte(result);
        }
      } catch (e) {
        showErrorSnackBar(message: "Erro ao transmitir o documento: ${e.toString()}");
      }
    });
  }

  void _imprimirDacte(Uint8List dacte) {
    Get.to(() => PdfPage(
      title: "DACTE",
      pdfFile: dacte,
    ));
  }

  @override
  void onInit() {
    super.onInit();
    tabController = TabController(vsync: this, length: tabItems.length);
    _configureChildrenControllers();
  }

  @override
  void onClose() {
    tabController.dispose();
    naturezaOperacaoController.dispose();
    chaveAcessoController.dispose();
    digitoChaveAcessoController.dispose();
    codigoNumericoController.dispose();
    serieController.dispose();
    numeroController.dispose();
    dataHoraEmissaoController.dispose();
    ufEmitenteController.dispose();
    cfopController.dispose();
    formaPagamentoController.dispose();
    modeloController.dispose();
    formatoImpressaoDacteController.dispose();
    tipoEmissaoController.dispose();
    ambienteController.dispose();
    tipoCteController.dispose();
    processoEmissaoController.dispose();
    versaoProcessoEmissaoController.dispose();
    chaveReferenciadoController.dispose();
    codigoMunicipioEnvioController.dispose();
    nomeMunicipioEnvioController.dispose();
    ufEnvioController.dispose();
    modalController.dispose();
    tipoServicoController.dispose();
    codigoMunicipioIniPrestacaoController.dispose();
    nomeMunicipioIniPrestacaoController.dispose();
    ufIniPrestacaoController.dispose();
    codigoMunicipioFimPrestacaoController.dispose();
    nomeMunicipioFimPrestacaoController.dispose();
    ufFimPrestacaoController.dispose();
    retiraController.dispose();
    retiraDetalheController.dispose();
    tomadorController.dispose();
    dataEntradaContingenciaController.dispose();
    justificativaContingenciaController.dispose();
    caracAdicionalTransporteController.dispose();
    caracAdicionalServicoController.dispose();
    funcionarioEmissorController.dispose();
    fluxoOrigemController.dispose();
    entregaTipoPeriodoController.dispose();
    entregaDataProgramadaController.dispose();
    entregaDataInicialController.dispose();
    entregaDataFinalController.dispose();
    entregaTipoHoraController.dispose();
    entregaHoraProgramadaController.dispose();
    entregaHoraInicialController.dispose();
    entregaHoraFinalController.dispose();
    municipioOrigemCalculoController.dispose();
    municipioDestinoCalculoController.dispose();
    observacoesGeraisController.dispose();
    valorTotalServicoController.dispose();
    valorReceberController.dispose();
    cstController.dispose();
    baseCalculoIcmsController.dispose();
    aliquotaIcmsController.dispose();
    valorIcmsController.dispose();
    percentualReducaoBcIcmsController.dispose();
    valorBcIcmsStRetidoController.dispose();
    valorIcmsStRetidoController.dispose();
    aliquotaIcmsStRetidoController.dispose();
    valorCreditoPresumidoIcmsController.dispose();
    percentualBcIcmsOutraUfController.dispose();
    valorBcIcmsOutraUfController.dispose();
    aliquotaIcmsOutraUfController.dispose();
    valorIcmsOutraUfController.dispose();
    simplesNacionalIndicadorController.dispose();
    simplesNacionalTotalController.dispose();
    informacoesAddFiscoController.dispose();
    valorTotalCargaController.dispose();
    produtoPredominanteController.dispose();
    cargaOutrasCaracteristicasController.dispose();
    modalVersaoLayoutController.dispose();
    chaveCteSubstituidoController.dispose();
    _releaseChildrenControllers();
    super.onClose();
  }	
}