import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:pluto_grid/pluto_grid.dart';
import 'package:extended_masked_text/extended_masked_text.dart';

import 'package:cte/app/page/page_imports.dart';
import 'package:cte/app/page/shared_widget/message_dialog.dart';
import 'package:cte/app/page/grid_columns/grid_columns_imports.dart';
import 'package:cte/app/controller/controller_imports.dart';
import 'package:cte/app/data/model/model_imports.dart';

class CteAquaviarioController extends ControllerBase<CteAquaviarioModel, void> {

  CteAquaviarioController() : super(repository: null) {
    dbColumns = CteAquaviarioModel.dbColumns;
    aliasColumns = CteAquaviarioModel.aliasColumns;
    gridColumns = cteAquaviarioGridColumns();
    functionName = "cte_aquaviario";
    screenTitle = "Aquaviário";
  }

  final _cteAquaviarioModel = CteAquaviarioModel().obs;
  CteAquaviarioModel get cteAquaviarioModel => _cteAquaviarioModel.value;
  set cteAquaviarioModel(value) => _cteAquaviarioModel.value = value ?? CteAquaviarioModel();

  List<CteAquaviarioModel> get cteAquaviarioModelList => Get.find<CteCabecalhoController>().currentModel.cteAquaviarioModelList ?? [];

  final _userMadeChanges = false.obs;
  get userMadeChanges => _userMadeChanges.value;
  set userMadeChanges(value) => _userMadeChanges.value = value;

  final _formWasChangedDetail = false.obs;
  bool get formWasChangedDetail => _formWasChangedDetail.value;
  set formWasChangedDetail(value) => _formWasChangedDetail.value = value;

  late PlutoGridStateManager _plutoGridStateManager;
  @override
  PlutoGridStateManager get plutoGridStateManager => _plutoGridStateManager;
  @override
  set plutoGridStateManager(value) => _plutoGridStateManager = value;

  final cteAquaviarioScaffoldKey = GlobalKey<ScaffoldState>();
  final cteAquaviarioFormKey = GlobalKey<FormState>();

  @override
  CteAquaviarioModel createNewModel() => CteAquaviarioModel();

  @override
  final standardFieldForFilter = CteAquaviarioModel.aliasColumns[CteAquaviarioModel.dbColumns.indexOf('valor_prestacao')];

  final valorPrestacaoController = MoneyMaskedTextController();
  final afrmmController = MoneyMaskedTextController();
  final numeroBookingController = TextEditingController();
  final numeroControleController = TextEditingController();
  final idNavioController = TextEditingController();

  final Map<String, dynamic> mobileConfig = {
    'primaryColumns': ['valor_prestacao'],
    'secondaryColumns': ['afrmm'],
  };

  List<Map<String, dynamic>> get mobileItems {
    return modelList.map((cteAquaviario) => cteAquaviario.toJson).toList();
  }

  @override
  List<PlutoRow> plutoRows() => List<PlutoRow>.from(cteAquaviarioModelList.map((model) => model.toPlutoRow()));

  @override
  Future<void> getList({Filter? filter}) async {}

  @override
  void prepareForInsert() {
    isNewRecord = true;
    cteAquaviarioModel = createNewModel();
    _resetForm();
    Get.to(() => CteAquaviarioEditPage());
  }

  void _resetForm() {
    formWasChangedDetail = false;
    valorPrestacaoController.updateValue(0);
    afrmmController.updateValue(0);
    numeroBookingController.text = '';
    numeroControleController.text = '';
    idNavioController.text = '';
  }

  @override
  void selectRowForEditing(PlutoRow? row) async {
    if (row == null) {
      showInfoSnackBar(message: 'message_select_one_to_edited'.tr);
      return;
    }

    selectRowForEditingByTempId(row.cells['tempId']?.value);
  }

  @override
  void selectRowForEditingById(int id) {}

  void selectRowForEditingByTempId(String tempId) {
		isNewRecord = false;
    final model = cteAquaviarioModelList.firstWhere((m) => m.tempId == tempId);
    cteAquaviarioModel = model.clone();
		cteAquaviarioModel.tempId = model.tempId;
    updateControllersFromModel();
    Get.to(() => CteAquaviarioEditPage());
  }

  void updateControllersFromModel() {
    valorPrestacaoController.updateValue(cteAquaviarioModel.valorPrestacao ?? 0);
    afrmmController.updateValue(cteAquaviarioModel.afrmm ?? 0);
    numeroBookingController.text = cteAquaviarioModel.numeroBooking ?? '';
    numeroControleController.text = cteAquaviarioModel.numeroControle ?? '';
    idNavioController.text = cteAquaviarioModel.idNavio ?? '';
    formWasChangedDetail = false;
  }

  @override
  Future<void> save() async {
    if (!cteAquaviarioFormKey.currentState!.validate()) {
      showErrorSnackBar(message: 'validator_form_message'.tr);
      return;
    }

    if (formWasChangedDetail) {
      if (isNewRecord) {
        cteAquaviarioModelList.insert(0, cteAquaviarioModel.clone());
      } else {
        final index = cteAquaviarioModelList.indexWhere((m) => m.tempId == cteAquaviarioModel.tempId);
        if (index >= 0) {
          cteAquaviarioModelList[index] = cteAquaviarioModel.clone();
        }
      }

      userMadeChanges = true;
      loadData();
      Get.back(result: true);
    } else {
      Get.back();
    }
  }


  @override
  Future deleteSelected() async {
    final currentRow = plutoGridStateManager.currentRow;
    if (currentRow == null) {
      showInfoSnackBar(message: 'message_select_one_to_delete'.tr);
      return null;
    }
    showDeleteDialog(() async {
      final id = currentRow.cells['id']?.value;
      final tempId = currentRow.cells['tempId']?.value;
      cteAquaviarioModelList.removeWhere((model) => (id != 0 && model.id == id) || (id == 0 && model.tempId == tempId));
      plutoGridStateManager.removeCurrentRow();
      userMadeChanges = true;
    });
  }

  @override
  void preventDataLoss() {
    if (formWasChangedDetail) {
      showQuestionDialog('message_data_loss'.tr, () => Get.back());
    } else {
      formWasChangedDetail = false;
      Get.back();
    }
  }

  @override
  void onClose() {
    valorPrestacaoController.dispose();
    afrmmController.dispose();
    numeroBookingController.dispose();
    numeroControleController.dispose();
    idNavioController.dispose();
  }

}