import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:pluto_grid/pluto_grid.dart';
import 'package:extended_masked_text/extended_masked_text.dart';
import 'package:cte/app/page/shared_widget/input/input_imports.dart';

import 'package:cte/app/page/page_imports.dart';
import 'package:cte/app/page/shared_widget/message_dialog.dart';
import 'package:cte/app/page/grid_columns/grid_columns_imports.dart';
import 'package:cte/app/controller/controller_imports.dart';
import 'package:cte/app/data/model/model_imports.dart';

class CteInformacaoNfOutrosController extends ControllerBase<CteInformacaoNfOutrosModel, void> {

  CteInformacaoNfOutrosController() : super(repository: null) {
    dbColumns = CteInformacaoNfOutrosModel.dbColumns;
    aliasColumns = CteInformacaoNfOutrosModel.aliasColumns;
    gridColumns = cteInformacaoNfOutrosGridColumns();
    functionName = "cte_informacao_nf_outros";
    screenTitle = "NF Outros";
  }

  final _cteInformacaoNfOutrosModel = CteInformacaoNfOutrosModel().obs;
  CteInformacaoNfOutrosModel get cteInformacaoNfOutrosModel => _cteInformacaoNfOutrosModel.value;
  set cteInformacaoNfOutrosModel(value) => _cteInformacaoNfOutrosModel.value = value ?? CteInformacaoNfOutrosModel();

  List<CteInformacaoNfOutrosModel> get cteInformacaoNfOutrosModelList => Get.find<CteCabecalhoController>().currentModel.cteInformacaoNfOutrosModelList ?? [];

  final _userMadeChanges = false.obs;
  get userMadeChanges => _userMadeChanges.value;
  set userMadeChanges(value) => _userMadeChanges.value = value;

  final _formWasChangedDetail = false.obs;
  bool get formWasChangedDetail => _formWasChangedDetail.value;
  set formWasChangedDetail(value) => _formWasChangedDetail.value = value;

  late PlutoGridStateManager _plutoGridStateManager;
  @override
  PlutoGridStateManager get plutoGridStateManager => _plutoGridStateManager;
  @override
  set plutoGridStateManager(value) => _plutoGridStateManager = value;

  final cteInformacaoNfOutrosScaffoldKey = GlobalKey<ScaffoldState>();
  final cteInformacaoNfOutrosFormKey = GlobalKey<FormState>();

  @override
  CteInformacaoNfOutrosModel createNewModel() => CteInformacaoNfOutrosModel();

  @override
  final standardFieldForFilter = CteInformacaoNfOutrosModel.aliasColumns[CteInformacaoNfOutrosModel.dbColumns.indexOf('numero_romaneio')];

  final numeroRomaneioController = TextEditingController();
  final numeroPedidoController = TextEditingController();
  final chaveAcessoNfeController = TextEditingController();
  final codigoModeloController = TextEditingController();
  final serieController = TextEditingController();
  final numeroController = TextEditingController();
  final dataEmissaoController = DatePickerItemController(null);
  final ufEmitenteController = MoneyMaskedTextController(precision: 0, decimalSeparator: '', thousandSeparator: '');
  final baseCalculoIcmsController = MoneyMaskedTextController();
  final valorIcmsController = MoneyMaskedTextController();
  final baseCalculoIcmsStController = MoneyMaskedTextController();
  final valorIcmsStController = MoneyMaskedTextController();
  final valorTotalProdutosController = MoneyMaskedTextController();
  final valorTotalController = MoneyMaskedTextController();
  final cfopPredominanteController = MoneyMaskedTextController(precision: 0, decimalSeparator: '', thousandSeparator: '');
  final pesoTotalKgController = MoneyMaskedTextController();
  final pinSuframaController = MoneyMaskedTextController(precision: 0, decimalSeparator: '', thousandSeparator: '');
  final dataPrevistaEntregaController = DatePickerItemController(null);
  final outroTipoDocOrigController = TextEditingController();
  final outroDescricaoController = TextEditingController();
  final outroValorDocumentoController = MoneyMaskedTextController();

  final Map<String, dynamic> mobileConfig = {
    'primaryColumns': ['numero_romaneio'],
    'secondaryColumns': ['numero_pedido'],
  };

  List<Map<String, dynamic>> get mobileItems {
    return modelList.map((cteInformacaoNfOutros) => cteInformacaoNfOutros.toJson).toList();
  }

  @override
  List<PlutoRow> plutoRows() => List<PlutoRow>.from(cteInformacaoNfOutrosModelList.map((model) => model.toPlutoRow()));

  @override
  Future<void> getList({Filter? filter}) async {}

  @override
  void prepareForInsert() {
    isNewRecord = true;
    cteInformacaoNfOutrosModel = createNewModel();
    _resetForm();
    Get.to(() => CteInformacaoNfOutrosEditPage());
  }

  void _resetForm() {
    formWasChangedDetail = false;
    numeroRomaneioController.text = '';
    numeroPedidoController.text = '';
    chaveAcessoNfeController.text = '';
    codigoModeloController.text = '';
    serieController.text = '';
    numeroController.text = '';
    dataEmissaoController.date = null;
    ufEmitenteController.updateValue(0);
    baseCalculoIcmsController.updateValue(0);
    valorIcmsController.updateValue(0);
    baseCalculoIcmsStController.updateValue(0);
    valorIcmsStController.updateValue(0);
    valorTotalProdutosController.updateValue(0);
    valorTotalController.updateValue(0);
    cfopPredominanteController.updateValue(0);
    pesoTotalKgController.updateValue(0);
    pinSuframaController.updateValue(0);
    dataPrevistaEntregaController.date = null;
    outroTipoDocOrigController.text = '';
    outroDescricaoController.text = '';
    outroValorDocumentoController.updateValue(0);
  }

  @override
  void selectRowForEditing(PlutoRow? row) async {
    if (row == null) {
      showInfoSnackBar(message: 'message_select_one_to_edited'.tr);
      return;
    }

    selectRowForEditingByTempId(row.cells['tempId']?.value);
  }

  @override
  void selectRowForEditingById(int id) {}

  void selectRowForEditingByTempId(String tempId) {
		isNewRecord = false;
    final model = cteInformacaoNfOutrosModelList.firstWhere((m) => m.tempId == tempId);
    cteInformacaoNfOutrosModel = model.clone();
		cteInformacaoNfOutrosModel.tempId = model.tempId;
    updateControllersFromModel();
    Get.to(() => CteInformacaoNfOutrosEditPage());
  }

  void updateControllersFromModel() {
    numeroRomaneioController.text = cteInformacaoNfOutrosModel.numeroRomaneio ?? '';
    numeroPedidoController.text = cteInformacaoNfOutrosModel.numeroPedido ?? '';
    chaveAcessoNfeController.text = cteInformacaoNfOutrosModel.chaveAcessoNfe ?? '';
    codigoModeloController.text = cteInformacaoNfOutrosModel.codigoModelo ?? '';
    serieController.text = cteInformacaoNfOutrosModel.serie ?? '';
    numeroController.text = cteInformacaoNfOutrosModel.numero ?? '';
    dataEmissaoController.date = cteInformacaoNfOutrosModel.dataEmissao;
    ufEmitenteController.updateValue((cteInformacaoNfOutrosModel.ufEmitente ?? 0).toDouble());
    baseCalculoIcmsController.updateValue(cteInformacaoNfOutrosModel.baseCalculoIcms ?? 0);
    valorIcmsController.updateValue(cteInformacaoNfOutrosModel.valorIcms ?? 0);
    baseCalculoIcmsStController.updateValue(cteInformacaoNfOutrosModel.baseCalculoIcmsSt ?? 0);
    valorIcmsStController.updateValue(cteInformacaoNfOutrosModel.valorIcmsSt ?? 0);
    valorTotalProdutosController.updateValue(cteInformacaoNfOutrosModel.valorTotalProdutos ?? 0);
    valorTotalController.updateValue(cteInformacaoNfOutrosModel.valorTotal ?? 0);
    cfopPredominanteController.updateValue((cteInformacaoNfOutrosModel.cfopPredominante ?? 0).toDouble());
    pesoTotalKgController.updateValue(cteInformacaoNfOutrosModel.pesoTotalKg ?? 0);
    pinSuframaController.updateValue((cteInformacaoNfOutrosModel.pinSuframa ?? 0).toDouble());
    dataPrevistaEntregaController.date = cteInformacaoNfOutrosModel.dataPrevistaEntrega;
    outroTipoDocOrigController.text = cteInformacaoNfOutrosModel.outroTipoDocOrig ?? '';
    outroDescricaoController.text = cteInformacaoNfOutrosModel.outroDescricao ?? '';
    outroValorDocumentoController.updateValue(cteInformacaoNfOutrosModel.outroValorDocumento ?? 0);
    formWasChangedDetail = false;
  }

  @override
  Future<void> save() async {
    if (!cteInformacaoNfOutrosFormKey.currentState!.validate()) {
      showErrorSnackBar(message: 'validator_form_message'.tr);
      return;
    }

    if (formWasChangedDetail) {
      if (isNewRecord) {
        cteInformacaoNfOutrosModelList.insert(0, cteInformacaoNfOutrosModel.clone());
      } else {
        final index = cteInformacaoNfOutrosModelList.indexWhere((m) => m.tempId == cteInformacaoNfOutrosModel.tempId);
        if (index >= 0) {
          cteInformacaoNfOutrosModelList[index] = cteInformacaoNfOutrosModel.clone();
        }
      }

      userMadeChanges = true;
      loadData();
      Get.back(result: true);
    } else {
      Get.back();
    }
  }


  @override
  Future deleteSelected() async {
    final currentRow = plutoGridStateManager.currentRow;
    if (currentRow == null) {
      showInfoSnackBar(message: 'message_select_one_to_delete'.tr);
      return null;
    }
    showDeleteDialog(() async {
      final id = currentRow.cells['id']?.value;
      final tempId = currentRow.cells['tempId']?.value;
      cteInformacaoNfOutrosModelList.removeWhere((model) => (id != 0 && model.id == id) || (id == 0 && model.tempId == tempId));
      plutoGridStateManager.removeCurrentRow();
      userMadeChanges = true;
    });
  }

  @override
  void preventDataLoss() {
    if (formWasChangedDetail) {
      showQuestionDialog('message_data_loss'.tr, () => Get.back());
    } else {
      formWasChangedDetail = false;
      Get.back();
    }
  }

  @override
  void onClose() {
    numeroRomaneioController.dispose();
    numeroPedidoController.dispose();
    chaveAcessoNfeController.dispose();
    codigoModeloController.dispose();
    serieController.dispose();
    numeroController.dispose();
    dataEmissaoController.dispose();
    ufEmitenteController.dispose();
    baseCalculoIcmsController.dispose();
    valorIcmsController.dispose();
    baseCalculoIcmsStController.dispose();
    valorIcmsStController.dispose();
    valorTotalProdutosController.dispose();
    valorTotalController.dispose();
    cfopPredominanteController.dispose();
    pesoTotalKgController.dispose();
    pinSuframaController.dispose();
    dataPrevistaEntregaController.dispose();
    outroTipoDocOrigController.dispose();
    outroDescricaoController.dispose();
    outroValorDocumentoController.dispose();
  }

}