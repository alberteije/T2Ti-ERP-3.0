import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:pluto_grid/pluto_grid.dart';
import 'package:extended_masked_text/extended_masked_text.dart';
import 'package:cte/app/page/shared_widget/input/input_imports.dart';

import 'package:cte/app/page/page_imports.dart';
import 'package:cte/app/page/shared_widget/message_dialog.dart';
import 'package:cte/app/page/grid_columns/grid_columns_imports.dart';
import 'package:cte/app/controller/controller_imports.dart';
import 'package:cte/app/data/model/model_imports.dart';

class CteExpedidorController extends ControllerBase<CteExpedidorModel, void> {

  CteExpedidorController() : super(repository: null) {
    dbColumns = CteExpedidorModel.dbColumns;
    aliasColumns = CteExpedidorModel.aliasColumns;
    gridColumns = cteExpedidorGridColumns();
    functionName = "cte_expedidor";
    screenTitle = "Expedidor";
  }

  final _cteExpedidorModel = CteExpedidorModel().obs;
  CteExpedidorModel get cteExpedidorModel => _cteExpedidorModel.value;
  set cteExpedidorModel(value) => _cteExpedidorModel.value = value ?? CteExpedidorModel();

  List<CteExpedidorModel> get cteExpedidorModelList => Get.find<CteCabecalhoController>().currentModel.cteExpedidorModelList ?? [];

  final _userMadeChanges = false.obs;
  get userMadeChanges => _userMadeChanges.value;
  set userMadeChanges(value) => _userMadeChanges.value = value;

  final _formWasChangedDetail = false.obs;
  bool get formWasChangedDetail => _formWasChangedDetail.value;
  set formWasChangedDetail(value) => _formWasChangedDetail.value = value;

  late PlutoGridStateManager _plutoGridStateManager;
  @override
  PlutoGridStateManager get plutoGridStateManager => _plutoGridStateManager;
  @override
  set plutoGridStateManager(value) => _plutoGridStateManager = value;

  final cteExpedidorScaffoldKey = GlobalKey<ScaffoldState>();
  final cteExpedidorFormKey = GlobalKey<FormState>();

  @override
  CteExpedidorModel createNewModel() => CteExpedidorModel();

  @override
  final standardFieldForFilter = CteExpedidorModel.aliasColumns[CteExpedidorModel.dbColumns.indexOf('cnpj')];

  final cnpjController = MaskedTextController(mask: '00.000.000/0000-00',);
  final cpfController = MaskedTextController(mask: '000.000.000-00',);
  final ieController = TextEditingController();
  final nomeController = TextEditingController();
  final fantasiaController = TextEditingController();
  final telefoneController = TextEditingController();
  final logradouroController = TextEditingController();
  final numeroController = TextEditingController();
  final complementoController = TextEditingController();
  final bairroController = TextEditingController();
  final codigoMunicipioController = MoneyMaskedTextController(precision: 0, decimalSeparator: '', thousandSeparator: '');
  final nomeMunicipioController = TextEditingController();
  final ufController = CustomDropdownButtonController('AC');
  final cepController = MaskedTextController(mask: '00000-000',);
  final codigoPaisController = MoneyMaskedTextController(precision: 0, decimalSeparator: '', thousandSeparator: '');
  final nomePaisController = TextEditingController();
  final emailController = TextEditingController();

  final Map<String, dynamic> mobileConfig = {
    'primaryColumns': ['cnpj'],
    'secondaryColumns': ['cpf'],
  };

  List<Map<String, dynamic>> get mobileItems {
    return modelList.map((cteExpedidor) => cteExpedidor.toJson).toList();
  }

  @override
  List<PlutoRow> plutoRows() => List<PlutoRow>.from(cteExpedidorModelList.map((model) => model.toPlutoRow()));

  @override
  Future<void> getList({Filter? filter}) async {}

  @override
  void prepareForInsert() {
    isNewRecord = true;
    cteExpedidorModel = createNewModel();
    _resetForm();
    Get.to(() => CteExpedidorEditPage());
  }

  void _resetForm() {
    formWasChangedDetail = false;
    cnpjController.text = '';
    cpfController.text = '';
    ieController.text = '';
    nomeController.text = '';
    fantasiaController.text = '';
    telefoneController.text = '';
    logradouroController.text = '';
    numeroController.text = '';
    complementoController.text = '';
    bairroController.text = '';
    codigoMunicipioController.updateValue(0);
    nomeMunicipioController.text = '';
    ufController.selected = 'AC';
    cepController.text = '';
    codigoPaisController.updateValue(0);
    nomePaisController.text = '';
    emailController.text = '';
  }

  @override
  void selectRowForEditing(PlutoRow? row) async {
    if (row == null) {
      showInfoSnackBar(message: 'message_select_one_to_edited'.tr);
      return;
    }

    selectRowForEditingByTempId(row.cells['tempId']?.value);
  }

  @override
  void selectRowForEditingById(int id) {}

  void selectRowForEditingByTempId(String tempId) {
		isNewRecord = false;
    final model = cteExpedidorModelList.firstWhere((m) => m.tempId == tempId);
    cteExpedidorModel = model.clone();
		cteExpedidorModel.tempId = model.tempId;
    updateControllersFromModel();
    Get.to(() => CteExpedidorEditPage());
  }

  void updateControllersFromModel() {
    cnpjController.text = cteExpedidorModel.cnpj ?? '';
    cpfController.text = cteExpedidorModel.cpf ?? '';
    ieController.text = cteExpedidorModel.ie ?? '';
    nomeController.text = cteExpedidorModel.nome ?? '';
    fantasiaController.text = cteExpedidorModel.fantasia ?? '';
    telefoneController.text = cteExpedidorModel.telefone ?? '';
    logradouroController.text = cteExpedidorModel.logradouro ?? '';
    numeroController.text = cteExpedidorModel.numero ?? '';
    complementoController.text = cteExpedidorModel.complemento ?? '';
    bairroController.text = cteExpedidorModel.bairro ?? '';
    codigoMunicipioController.updateValue((cteExpedidorModel.codigoMunicipio ?? 0).toDouble());
    nomeMunicipioController.text = cteExpedidorModel.nomeMunicipio ?? '';
    ufController.selected = cteExpedidorModel.uf ?? 'AC';
    cepController.text = cteExpedidorModel.cep ?? '';
    codigoPaisController.updateValue((cteExpedidorModel.codigoPais ?? 0).toDouble());
    nomePaisController.text = cteExpedidorModel.nomePais ?? '';
    emailController.text = cteExpedidorModel.email ?? '';
    formWasChangedDetail = false;
  }

  @override
  Future<void> save() async {
    if (!cteExpedidorFormKey.currentState!.validate()) {
      showErrorSnackBar(message: 'validator_form_message'.tr);
      return;
    }

    if (formWasChangedDetail) {
      if (isNewRecord) {
        cteExpedidorModelList.insert(0, cteExpedidorModel.clone());
      } else {
        final index = cteExpedidorModelList.indexWhere((m) => m.tempId == cteExpedidorModel.tempId);
        if (index >= 0) {
          cteExpedidorModelList[index] = cteExpedidorModel.clone();
        }
      }

      userMadeChanges = true;
      loadData();
      Get.back(result: true);
    } else {
      Get.back();
    }
  }


  @override
  Future deleteSelected() async {
    final currentRow = plutoGridStateManager.currentRow;
    if (currentRow == null) {
      showInfoSnackBar(message: 'message_select_one_to_delete'.tr);
      return null;
    }
    showDeleteDialog(() async {
      final id = currentRow.cells['id']?.value;
      final tempId = currentRow.cells['tempId']?.value;
      cteExpedidorModelList.removeWhere((model) => (id != 0 && model.id == id) || (id == 0 && model.tempId == tempId));
      plutoGridStateManager.removeCurrentRow();
      userMadeChanges = true;
    });
  }

  @override
  void preventDataLoss() {
    if (formWasChangedDetail) {
      showQuestionDialog('message_data_loss'.tr, () => Get.back());
    } else {
      formWasChangedDetail = false;
      Get.back();
    }
  }

  @override
  void onClose() {
    cnpjController.dispose();
    cpfController.dispose();
    ieController.dispose();
    nomeController.dispose();
    fantasiaController.dispose();
    telefoneController.dispose();
    logradouroController.dispose();
    numeroController.dispose();
    complementoController.dispose();
    bairroController.dispose();
    codigoMunicipioController.dispose();
    nomeMunicipioController.dispose();
    ufController.dispose();
    cepController.dispose();
    codigoPaisController.dispose();
    nomePaisController.dispose();
    emailController.dispose();
  }

}