import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:extended_masked_text/extended_masked_text.dart';
import 'package:cte/app/page/shared_widget/input/input_imports.dart';

import 'package:cte/app/page/shared_widget/message_dialog.dart';
import 'package:cte/app/page/grid_columns/grid_columns_imports.dart';
import 'package:cte/app/routes/app_routes.dart';
import 'package:cte/app/controller/controller_imports.dart';
import 'package:cte/app/data/model/model_imports.dart';
import 'package:cte/app/data/repository/cte_aquaviario_balsa_repository.dart';

class CteAquaviarioBalsaController extends ControllerBase<CteAquaviarioBalsaModel, CteAquaviarioBalsaRepository> {

  CteAquaviarioBalsaController({required super.repository}) {
    dbColumns = CteAquaviarioBalsaModel.dbColumns;
    aliasColumns = CteAquaviarioBalsaModel.aliasColumns;
    gridColumns = cteAquaviarioBalsaGridColumns();
    functionName = "cte_aquaviario_balsa";
    screenTitle = "Cte Aquaviario Balsa";
  }

  @override
  CteAquaviarioBalsaModel createNewModel() => CteAquaviarioBalsaModel();

  @override
  final standardFieldForFilter = CteAquaviarioBalsaModel.aliasColumns[CteAquaviarioBalsaModel.dbColumns.indexOf('id_balsa')];

  final cteAquaviarioModelController = TextEditingController();
  final idBalsaController = TextEditingController();
  final numeroViagemController = MoneyMaskedTextController(precision: 0, decimalSeparator: '', thousandSeparator: '');
  final direcaoController = CustomDropdownButtonController('N-Norte');
  final portoEmbarqueController = TextEditingController();
  final portoTransbordoController = TextEditingController();
  final portoDestinoController = TextEditingController();
  final tipoNavegacaoController = CustomDropdownButtonController('0-Interior');
  final irinController = TextEditingController();

  final Map<String, dynamic> mobileConfig = {
    'primaryColumns': ['id_balsa'],
    'secondaryColumns': ['numero_viagem'],
  };

  List<Map<String, dynamic>> get mobileItems {
    return modelList.map((cteAquaviarioBalsa) => cteAquaviarioBalsa.toJson).toList();
  }

  @override
  void prepareForInsert() {
    isNewRecord = true;
    currentModel = createNewModel();
    _resetForm();
    Get.toNamed(Routes.cteAquaviarioBalsaEditPage);
  }

  void _resetForm() {
    formWasChanged = false;
    cteAquaviarioModelController.text = '';
    idBalsaController.text = '';
    numeroViagemController.updateValue(0);
    direcaoController.selected = 'N-Norte';
    portoEmbarqueController.text = '';
    portoTransbordoController.text = '';
    portoDestinoController.text = '';
    tipoNavegacaoController.selected = '0-Interior';
    irinController.text = '';
  }

  @override
  void selectRowForEditingById(int id) {
    final model = modelList.firstWhere((m) => m.id == id);
    currentModel = model.clone();
    updateControllersFromModel();
    Get.toNamed(Routes.cteAquaviarioBalsaEditPage);
  }

  void updateControllersFromModel() {
    cteAquaviarioModelController.text = currentModel.cteAquaviarioModel?.numeroControle?.toString() ?? '';
    idBalsaController.text = currentModel.idBalsa ?? '';
    numeroViagemController.updateValue((currentModel.numeroViagem ?? 0).toDouble());
    direcaoController.selected = currentModel.direcao ?? 'N-Norte';
    portoEmbarqueController.text = currentModel.portoEmbarque ?? '';
    portoTransbordoController.text = currentModel.portoTransbordo ?? '';
    portoDestinoController.text = currentModel.portoDestino ?? '';
    tipoNavegacaoController.selected = currentModel.tipoNavegacao ?? '0-Interior';
    irinController.text = currentModel.irin ?? '';
    formWasChanged = false;
  }

  @override
  Future<void> save() async {
    if (!formKey.currentState!.validate()) {
      showErrorSnackBar(message: 'validator_form_message'.tr);
      return;
    }

    final existingIndex = modelList.indexWhere((m) => m.id == currentModel.id);

    if (existingIndex >= 0) {
      modelList[existingIndex] = currentModel.clone();
    }

    final result = await repository.save(cteAquaviarioBalsaModel: currentModel);
    if (result == null) return;

    if (existingIndex >= 0) {
      modelList[existingIndex] = result;
    } else {
      modelList.insert(0, result);
    }

    if (!GetPlatform.isMobile) {
      updateGridRow(result);
    }

    Get.back(result: true);
  }

  Future callCteAquaviarioLookup() async { 
		final lookupController = Get.find<LookupController>(); 
		lookupController.refreshItems(standardValue: '%'); 
		lookupController.title = '${'lookup_page_title'.tr} [Id Cte Aquaviario]'; 
		lookupController.route = '/cte-aquaviario/'; 
		lookupController.gridColumns = cteAquaviarioGridColumns(isForLookup: true); 
		lookupController.aliasColumns = CteAquaviarioModel.aliasColumns; 
		lookupController.dbColumns = CteAquaviarioModel.dbColumns; 
		lookupController.standardColumn = CteAquaviarioModel.aliasColumns[CteAquaviarioModel.dbColumns.indexOf('numeroControle')]; 

		final plutoRowResult = await Get.toNamed(Routes.lookupPage); 
		if (plutoRowResult != null) { 
			currentModel.idCteAquaviario = plutoRowResult.cells['id']!.value; 
			currentModel.cteAquaviarioModel = CteAquaviarioModel.fromPlutoRow(plutoRowResult); 
			cteAquaviarioModelController.text = currentModel.cteAquaviarioModel?.numeroControle ?? ''; 
			formWasChanged = true; 
		}
	}


  @override
  void onClose() {
    cteAquaviarioModelController.dispose();
    idBalsaController.dispose();
    numeroViagemController.dispose();
    direcaoController.dispose();
    portoEmbarqueController.dispose();
    portoTransbordoController.dispose();
    portoDestinoController.dispose();
    tipoNavegacaoController.dispose();
    irinController.dispose();
    super.onClose();
  }

}