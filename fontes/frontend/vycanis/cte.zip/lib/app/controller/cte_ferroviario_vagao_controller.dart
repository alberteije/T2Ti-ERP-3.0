import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:extended_masked_text/extended_masked_text.dart';

import 'package:cte/app/page/shared_widget/message_dialog.dart';
import 'package:cte/app/page/grid_columns/grid_columns_imports.dart';
import 'package:cte/app/routes/app_routes.dart';
import 'package:cte/app/controller/controller_imports.dart';
import 'package:cte/app/data/model/model_imports.dart';
import 'package:cte/app/data/repository/cte_ferroviario_vagao_repository.dart';

class CteFerroviarioVagaoController extends ControllerBase<CteFerroviarioVagaoModel, CteFerroviarioVagaoRepository> {

  CteFerroviarioVagaoController({required super.repository}) {
    dbColumns = CteFerroviarioVagaoModel.dbColumns;
    aliasColumns = CteFerroviarioVagaoModel.aliasColumns;
    gridColumns = cteFerroviarioVagaoGridColumns();
    functionName = "cte_ferroviario_vagao";
    screenTitle = "Cte Ferroviario Vagao";
  }

  @override
  CteFerroviarioVagaoModel createNewModel() => CteFerroviarioVagaoModel();

  @override
  final standardFieldForFilter = CteFerroviarioVagaoModel.aliasColumns[CteFerroviarioVagaoModel.dbColumns.indexOf('numero_vagao')];

  final cteFerroviarioModelController = TextEditingController();
  final numeroVagaoController = MoneyMaskedTextController(precision: 0, decimalSeparator: '', thousandSeparator: '');
  final capacidadeController = MoneyMaskedTextController();
  final tipoVagaoController = TextEditingController();
  final pesoRealController = MoneyMaskedTextController();
  final pesoBcController = MoneyMaskedTextController();

  final Map<String, dynamic> mobileConfig = {
    'primaryColumns': ['numero_vagao'],
    'secondaryColumns': ['capacidade'],
  };

  List<Map<String, dynamic>> get mobileItems {
    return modelList.map((cteFerroviarioVagao) => cteFerroviarioVagao.toJson).toList();
  }

  @override
  void prepareForInsert() {
    isNewRecord = true;
    currentModel = createNewModel();
    _resetForm();
    Get.toNamed(Routes.cteFerroviarioVagaoEditPage);
  }

  void _resetForm() {
    formWasChanged = false;
    cteFerroviarioModelController.text = '';
    numeroVagaoController.updateValue(0);
    capacidadeController.updateValue(0);
    tipoVagaoController.text = '';
    pesoRealController.updateValue(0);
    pesoBcController.updateValue(0);
  }

  @override
  void selectRowForEditingById(int id) {
    final model = modelList.firstWhere((m) => m.id == id);
    currentModel = model.clone();
    updateControllersFromModel();
    Get.toNamed(Routes.cteFerroviarioVagaoEditPage);
  }

  void updateControllersFromModel() {
    cteFerroviarioModelController.text = currentModel.cteFerroviarioModel?.fluxo?.toString() ?? '';
    numeroVagaoController.updateValue((currentModel.numeroVagao ?? 0).toDouble());
    capacidadeController.updateValue(currentModel.capacidade ?? 0);
    tipoVagaoController.text = currentModel.tipoVagao ?? '';
    pesoRealController.updateValue(currentModel.pesoReal ?? 0);
    pesoBcController.updateValue(currentModel.pesoBc ?? 0);
    formWasChanged = false;
  }

  @override
  Future<void> save() async {
    if (!formKey.currentState!.validate()) {
      showErrorSnackBar(message: 'validator_form_message'.tr);
      return;
    }

    final existingIndex = modelList.indexWhere((m) => m.id == currentModel.id);

    if (existingIndex >= 0) {
      modelList[existingIndex] = currentModel.clone();
    }

    final result = await repository.save(cteFerroviarioVagaoModel: currentModel);
    if (result == null) return;

    if (existingIndex >= 0) {
      modelList[existingIndex] = result;
    } else {
      modelList.insert(0, result);
    }

    if (!GetPlatform.isMobile) {
      updateGridRow(result);
    }

    Get.back(result: true);
  }

  Future callCteFerroviarioLookup() async { 
		final lookupController = Get.find<LookupController>(); 
		lookupController.refreshItems(standardValue: '%'); 
		lookupController.title = '${'lookup_page_title'.tr} [Id Cte Ferroviario]'; 
		lookupController.route = '/cte-ferroviario/'; 
		lookupController.gridColumns = cteFerroviarioGridColumns(isForLookup: true); 
		lookupController.aliasColumns = CteFerroviarioModel.aliasColumns; 
		lookupController.dbColumns = CteFerroviarioModel.dbColumns; 
		lookupController.standardColumn = CteFerroviarioModel.aliasColumns[CteFerroviarioModel.dbColumns.indexOf('fluxo')]; 

		final plutoRowResult = await Get.toNamed(Routes.lookupPage); 
		if (plutoRowResult != null) { 
			currentModel.idCteFerroviario = plutoRowResult.cells['id']!.value; 
			currentModel.cteFerroviarioModel = CteFerroviarioModel.fromPlutoRow(plutoRowResult); 
			cteFerroviarioModelController.text = currentModel.cteFerroviarioModel?.fluxo ?? ''; 
			formWasChanged = true; 
		}
	}


  @override
  void onClose() {
    cteFerroviarioModelController.dispose();
    numeroVagaoController.dispose();
    capacidadeController.dispose();
    tipoVagaoController.dispose();
    pesoRealController.dispose();
    pesoBcController.dispose();
    super.onClose();
  }

}