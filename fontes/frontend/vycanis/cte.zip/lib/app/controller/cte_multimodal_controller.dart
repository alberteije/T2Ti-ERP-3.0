import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:pluto_grid/pluto_grid.dart';
import 'package:cte/app/page/shared_widget/input/input_imports.dart';

import 'package:cte/app/page/page_imports.dart';
import 'package:cte/app/page/shared_widget/message_dialog.dart';
import 'package:cte/app/page/grid_columns/grid_columns_imports.dart';
import 'package:cte/app/controller/controller_imports.dart';
import 'package:cte/app/data/model/model_imports.dart';

class CteMultimodalController extends ControllerBase<CteMultimodalModel, void> {

  CteMultimodalController() : super(repository: null) {
    dbColumns = CteMultimodalModel.dbColumns;
    aliasColumns = CteMultimodalModel.aliasColumns;
    gridColumns = cteMultimodalGridColumns();
    functionName = "cte_multimodal";
    screenTitle = "Multimodal";
  }

  final _cteMultimodalModel = CteMultimodalModel().obs;
  CteMultimodalModel get cteMultimodalModel => _cteMultimodalModel.value;
  set cteMultimodalModel(value) => _cteMultimodalModel.value = value ?? CteMultimodalModel();

  List<CteMultimodalModel> get cteMultimodalModelList => Get.find<CteCabecalhoController>().currentModel.cteMultimodalModelList ?? [];

  final _userMadeChanges = false.obs;
  get userMadeChanges => _userMadeChanges.value;
  set userMadeChanges(value) => _userMadeChanges.value = value;

  final _formWasChangedDetail = false.obs;
  bool get formWasChangedDetail => _formWasChangedDetail.value;
  set formWasChangedDetail(value) => _formWasChangedDetail.value = value;

  late PlutoGridStateManager _plutoGridStateManager;
  @override
  PlutoGridStateManager get plutoGridStateManager => _plutoGridStateManager;
  @override
  set plutoGridStateManager(value) => _plutoGridStateManager = value;

  final cteMultimodalScaffoldKey = GlobalKey<ScaffoldState>();
  final cteMultimodalFormKey = GlobalKey<FormState>();

  @override
  CteMultimodalModel createNewModel() => CteMultimodalModel();

  @override
  final standardFieldForFilter = CteMultimodalModel.aliasColumns[CteMultimodalModel.dbColumns.indexOf('cotm')];

  final cotmController = TextEditingController();
  final indicadorNegociavelController = CustomDropdownButtonController('0 - Não Negociável');

  final Map<String, dynamic> mobileConfig = {
    'primaryColumns': ['cotm'],
    'secondaryColumns': ['indicador_negociavel'],
  };

  List<Map<String, dynamic>> get mobileItems {
    return modelList.map((cteMultimodal) => cteMultimodal.toJson).toList();
  }

  @override
  List<PlutoRow> plutoRows() => List<PlutoRow>.from(cteMultimodalModelList.map((model) => model.toPlutoRow()));

  @override
  Future<void> getList({Filter? filter}) async {}

  @override
  void prepareForInsert() {
    isNewRecord = true;
    cteMultimodalModel = createNewModel();
    _resetForm();
    Get.to(() => CteMultimodalEditPage());
  }

  void _resetForm() {
    formWasChangedDetail = false;
    cotmController.text = '';
    indicadorNegociavelController.selected = '0 - Não Negociável';
  }

  @override
  void selectRowForEditing(PlutoRow? row) async {
    if (row == null) {
      showInfoSnackBar(message: 'message_select_one_to_edited'.tr);
      return;
    }

    selectRowForEditingByTempId(row.cells['tempId']?.value);
  }

  @override
  void selectRowForEditingById(int id) {}

  void selectRowForEditingByTempId(String tempId) {
		isNewRecord = false;
    final model = cteMultimodalModelList.firstWhere((m) => m.tempId == tempId);
    cteMultimodalModel = model.clone();
		cteMultimodalModel.tempId = model.tempId;
    updateControllersFromModel();
    Get.to(() => CteMultimodalEditPage());
  }

  void updateControllersFromModel() {
    cotmController.text = cteMultimodalModel.cotm ?? '';
    indicadorNegociavelController.selected = cteMultimodalModel.indicadorNegociavel ?? '0 - Não Negociável';
    formWasChangedDetail = false;
  }

  @override
  Future<void> save() async {
    if (!cteMultimodalFormKey.currentState!.validate()) {
      showErrorSnackBar(message: 'validator_form_message'.tr);
      return;
    }

    if (formWasChangedDetail) {
      if (isNewRecord) {
        cteMultimodalModelList.insert(0, cteMultimodalModel.clone());
      } else {
        final index = cteMultimodalModelList.indexWhere((m) => m.tempId == cteMultimodalModel.tempId);
        if (index >= 0) {
          cteMultimodalModelList[index] = cteMultimodalModel.clone();
        }
      }

      userMadeChanges = true;
      loadData();
      Get.back(result: true);
    } else {
      Get.back();
    }
  }


  @override
  Future deleteSelected() async {
    final currentRow = plutoGridStateManager.currentRow;
    if (currentRow == null) {
      showInfoSnackBar(message: 'message_select_one_to_delete'.tr);
      return null;
    }
    showDeleteDialog(() async {
      final id = currentRow.cells['id']?.value;
      final tempId = currentRow.cells['tempId']?.value;
      cteMultimodalModelList.removeWhere((model) => (id != 0 && model.id == id) || (id == 0 && model.tempId == tempId));
      plutoGridStateManager.removeCurrentRow();
      userMadeChanges = true;
    });
  }

  @override
  void preventDataLoss() {
    if (formWasChangedDetail) {
      showQuestionDialog('message_data_loss'.tr, () => Get.back());
    } else {
      formWasChangedDetail = false;
      Get.back();
    }
  }

  @override
  void onClose() {
    cotmController.dispose();
    indicadorNegociavelController.dispose();
  }

}