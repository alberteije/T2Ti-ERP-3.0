import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:pluto_grid/pluto_grid.dart';
import 'package:extended_masked_text/extended_masked_text.dart';
import 'package:cte/app/page/shared_widget/input/input_imports.dart';

import 'package:cte/app/page/page_imports.dart';
import 'package:cte/app/page/shared_widget/message_dialog.dart';
import 'package:cte/app/page/grid_columns/grid_columns_imports.dart';
import 'package:cte/app/controller/controller_imports.dart';
import 'package:cte/app/data/model/model_imports.dart';

class CteAereoController extends ControllerBase<CteAereoModel, void> {

  CteAereoController() : super(repository: null) {
    dbColumns = CteAereoModel.dbColumns;
    aliasColumns = CteAereoModel.aliasColumns;
    gridColumns = cteAereoGridColumns();
    functionName = "cte_aereo";
    screenTitle = "Aéreo";
  }

  final _cteAereoModel = CteAereoModel().obs;
  CteAereoModel get cteAereoModel => _cteAereoModel.value;
  set cteAereoModel(value) => _cteAereoModel.value = value ?? CteAereoModel();

  List<CteAereoModel> get cteAereoModelList => Get.find<CteCabecalhoController>().currentModel.cteAereoModelList ?? [];

  final _userMadeChanges = false.obs;
  get userMadeChanges => _userMadeChanges.value;
  set userMadeChanges(value) => _userMadeChanges.value = value;

  final _formWasChangedDetail = false.obs;
  bool get formWasChangedDetail => _formWasChangedDetail.value;
  set formWasChangedDetail(value) => _formWasChangedDetail.value = value;

  late PlutoGridStateManager _plutoGridStateManager;
  @override
  PlutoGridStateManager get plutoGridStateManager => _plutoGridStateManager;
  @override
  set plutoGridStateManager(value) => _plutoGridStateManager = value;

  final cteAereoScaffoldKey = GlobalKey<ScaffoldState>();
  final cteAereoFormKey = GlobalKey<FormState>();

  @override
  CteAereoModel createNewModel() => CteAereoModel();

  @override
  final standardFieldForFilter = CteAereoModel.aliasColumns[CteAereoModel.dbColumns.indexOf('numero_minuta')];

  final numeroMinutaController = MoneyMaskedTextController(precision: 0, decimalSeparator: '', thousandSeparator: '');
  final numeroConhecimentoController = MoneyMaskedTextController(precision: 0, decimalSeparator: '', thousandSeparator: '');
  final dataPrevistaEntregaController = DatePickerItemController(null);
  final idEmissorController = TextEditingController();
  final idInternaTomadorController = TextEditingController();
  final tarifaClasseController = CustomDropdownButtonController('Mínima');
  final tarifaCodigoController = TextEditingController();
  final tarifaValorController = MoneyMaskedTextController();
  final cargaDimensaoController = TextEditingController();
  final cargaInformacaoManuseioController = CustomDropdownButtonController('01 - certificado do expedidor para embarque de animal vivo');
  final cargaEspecialController = TextEditingController();

  final Map<String, dynamic> mobileConfig = {
    'primaryColumns': ['numero_minuta'],
    'secondaryColumns': ['numero_conhecimento'],
  };

  List<Map<String, dynamic>> get mobileItems {
    return modelList.map((cteAereo) => cteAereo.toJson).toList();
  }

  @override
  List<PlutoRow> plutoRows() => List<PlutoRow>.from(cteAereoModelList.map((model) => model.toPlutoRow()));

  @override
  Future<void> getList({Filter? filter}) async {}

  @override
  void prepareForInsert() {
    isNewRecord = true;
    cteAereoModel = createNewModel();
    _resetForm();
    Get.to(() => CteAereoEditPage());
  }

  void _resetForm() {
    formWasChangedDetail = false;
    numeroMinutaController.updateValue(0);
    numeroConhecimentoController.updateValue(0);
    dataPrevistaEntregaController.date = null;
    idEmissorController.text = '';
    idInternaTomadorController.text = '';
    tarifaClasseController.selected = 'Mínima';
    tarifaCodigoController.text = '';
    tarifaValorController.updateValue(0);
    cargaDimensaoController.text = '';
    cargaInformacaoManuseioController.selected = '01 - certificado do expedidor para embarque de animal vivo';
    cargaEspecialController.text = '';
  }

  @override
  void selectRowForEditing(PlutoRow? row) async {
    if (row == null) {
      showInfoSnackBar(message: 'message_select_one_to_edited'.tr);
      return;
    }

    selectRowForEditingByTempId(row.cells['tempId']?.value);
  }

  @override
  void selectRowForEditingById(int id) {}

  void selectRowForEditingByTempId(String tempId) {
		isNewRecord = false;
    final model = cteAereoModelList.firstWhere((m) => m.tempId == tempId);
    cteAereoModel = model.clone();
		cteAereoModel.tempId = model.tempId;
    updateControllersFromModel();
    Get.to(() => CteAereoEditPage());
  }

  void updateControllersFromModel() {
    numeroMinutaController.updateValue((cteAereoModel.numeroMinuta ?? 0).toDouble());
    numeroConhecimentoController.updateValue((cteAereoModel.numeroConhecimento ?? 0).toDouble());
    dataPrevistaEntregaController.date = cteAereoModel.dataPrevistaEntrega;
    idEmissorController.text = cteAereoModel.idEmissor ?? '';
    idInternaTomadorController.text = cteAereoModel.idInternaTomador ?? '';
    tarifaClasseController.selected = cteAereoModel.tarifaClasse ?? 'Mínima';
    tarifaCodigoController.text = cteAereoModel.tarifaCodigo ?? '';
    tarifaValorController.updateValue(cteAereoModel.tarifaValor ?? 0);
    cargaDimensaoController.text = cteAereoModel.cargaDimensao ?? '';
    cargaInformacaoManuseioController.selected = cteAereoModel.cargaInformacaoManuseio ?? '01 - certificado do expedidor para embarque de animal vivo';
    cargaEspecialController.text = cteAereoModel.cargaEspecial ?? '';
    formWasChangedDetail = false;
  }

  @override
  Future<void> save() async {
    if (!cteAereoFormKey.currentState!.validate()) {
      showErrorSnackBar(message: 'validator_form_message'.tr);
      return;
    }

    if (formWasChangedDetail) {
      if (isNewRecord) {
        cteAereoModelList.insert(0, cteAereoModel.clone());
      } else {
        final index = cteAereoModelList.indexWhere((m) => m.tempId == cteAereoModel.tempId);
        if (index >= 0) {
          cteAereoModelList[index] = cteAereoModel.clone();
        }
      }

      userMadeChanges = true;
      loadData();
      Get.back(result: true);
    } else {
      Get.back();
    }
  }


  @override
  Future deleteSelected() async {
    final currentRow = plutoGridStateManager.currentRow;
    if (currentRow == null) {
      showInfoSnackBar(message: 'message_select_one_to_delete'.tr);
      return null;
    }
    showDeleteDialog(() async {
      final id = currentRow.cells['id']?.value;
      final tempId = currentRow.cells['tempId']?.value;
      cteAereoModelList.removeWhere((model) => (id != 0 && model.id == id) || (id == 0 && model.tempId == tempId));
      plutoGridStateManager.removeCurrentRow();
      userMadeChanges = true;
    });
  }

  @override
  void preventDataLoss() {
    if (formWasChangedDetail) {
      showQuestionDialog('message_data_loss'.tr, () => Get.back());
    } else {
      formWasChangedDetail = false;
      Get.back();
    }
  }

  @override
  void onClose() {
    numeroMinutaController.dispose();
    numeroConhecimentoController.dispose();
    dataPrevistaEntregaController.dispose();
    idEmissorController.dispose();
    idInternaTomadorController.dispose();
    tarifaClasseController.dispose();
    tarifaCodigoController.dispose();
    tarifaValorController.dispose();
    cargaDimensaoController.dispose();
    cargaInformacaoManuseioController.dispose();
    cargaEspecialController.dispose();
  }

}