import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:pluto_grid/pluto_grid.dart';
import 'package:extended_masked_text/extended_masked_text.dart';
import 'package:cte/app/page/shared_widget/input/input_imports.dart';

import 'package:cte/app/page/page_imports.dart';
import 'package:cte/app/page/shared_widget/message_dialog.dart';
import 'package:cte/app/page/grid_columns/grid_columns_imports.dart';
import 'package:cte/app/controller/controller_imports.dart';
import 'package:cte/app/data/model/model_imports.dart';

class CteLocalColetaController extends ControllerBase<CteLocalColetaModel, void> {

  CteLocalColetaController() : super(repository: null) {
    dbColumns = CteLocalColetaModel.dbColumns;
    aliasColumns = CteLocalColetaModel.aliasColumns;
    gridColumns = cteLocalColetaGridColumns();
    functionName = "cte_local_coleta";
    screenTitle = "Local Coleta";
  }

  final _cteLocalColetaModel = CteLocalColetaModel().obs;
  CteLocalColetaModel get cteLocalColetaModel => _cteLocalColetaModel.value;
  set cteLocalColetaModel(value) => _cteLocalColetaModel.value = value ?? CteLocalColetaModel();

  List<CteLocalColetaModel> get cteLocalColetaModelList => Get.find<CteCabecalhoController>().currentModel.cteLocalColetaModelList ?? [];

  final _userMadeChanges = false.obs;
  get userMadeChanges => _userMadeChanges.value;
  set userMadeChanges(value) => _userMadeChanges.value = value;

  final _formWasChangedDetail = false.obs;
  bool get formWasChangedDetail => _formWasChangedDetail.value;
  set formWasChangedDetail(value) => _formWasChangedDetail.value = value;

  late PlutoGridStateManager _plutoGridStateManager;
  @override
  PlutoGridStateManager get plutoGridStateManager => _plutoGridStateManager;
  @override
  set plutoGridStateManager(value) => _plutoGridStateManager = value;

  final cteLocalColetaScaffoldKey = GlobalKey<ScaffoldState>();
  final cteLocalColetaFormKey = GlobalKey<FormState>();

  @override
  CteLocalColetaModel createNewModel() => CteLocalColetaModel();

  @override
  final standardFieldForFilter = CteLocalColetaModel.aliasColumns[CteLocalColetaModel.dbColumns.indexOf('cnpj')];

  final cnpjController = MaskedTextController(mask: '00.000.000/0000-00',);
  final cpfController = MaskedTextController(mask: '000.000.000-00',);
  final nomeController = TextEditingController();
  final logradouroController = TextEditingController();
  final numeroController = TextEditingController();
  final complementoController = TextEditingController();
  final bairroController = TextEditingController();
  final codigoMunicipioController = MoneyMaskedTextController(precision: 0, decimalSeparator: '', thousandSeparator: '');
  final nomeMunicipioController = TextEditingController();
  final ufController = CustomDropdownButtonController('AC');

  final Map<String, dynamic> mobileConfig = {
    'primaryColumns': ['cnpj'],
    'secondaryColumns': ['cpf'],
  };

  List<Map<String, dynamic>> get mobileItems {
    return modelList.map((cteLocalColeta) => cteLocalColeta.toJson).toList();
  }

  @override
  List<PlutoRow> plutoRows() => List<PlutoRow>.from(cteLocalColetaModelList.map((model) => model.toPlutoRow()));

  @override
  Future<void> getList({Filter? filter}) async {}

  @override
  void prepareForInsert() {
    isNewRecord = true;
    cteLocalColetaModel = createNewModel();
    _resetForm();
    Get.to(() => CteLocalColetaEditPage());
  }

  void _resetForm() {
    formWasChangedDetail = false;
    cnpjController.text = '';
    cpfController.text = '';
    nomeController.text = '';
    logradouroController.text = '';
    numeroController.text = '';
    complementoController.text = '';
    bairroController.text = '';
    codigoMunicipioController.updateValue(0);
    nomeMunicipioController.text = '';
    ufController.selected = 'AC';
  }

  @override
  void selectRowForEditing(PlutoRow? row) async {
    if (row == null) {
      showInfoSnackBar(message: 'message_select_one_to_edited'.tr);
      return;
    }

    selectRowForEditingByTempId(row.cells['tempId']?.value);
  }

  @override
  void selectRowForEditingById(int id) {}

  void selectRowForEditingByTempId(String tempId) {
		isNewRecord = false;
    final model = cteLocalColetaModelList.firstWhere((m) => m.tempId == tempId);
    cteLocalColetaModel = model.clone();
		cteLocalColetaModel.tempId = model.tempId;
    updateControllersFromModel();
    Get.to(() => CteLocalColetaEditPage());
  }

  void updateControllersFromModel() {
    cnpjController.text = cteLocalColetaModel.cnpj ?? '';
    cpfController.text = cteLocalColetaModel.cpf ?? '';
    nomeController.text = cteLocalColetaModel.nome ?? '';
    logradouroController.text = cteLocalColetaModel.logradouro ?? '';
    numeroController.text = cteLocalColetaModel.numero ?? '';
    complementoController.text = cteLocalColetaModel.complemento ?? '';
    bairroController.text = cteLocalColetaModel.bairro ?? '';
    codigoMunicipioController.updateValue((cteLocalColetaModel.codigoMunicipio ?? 0).toDouble());
    nomeMunicipioController.text = cteLocalColetaModel.nomeMunicipio ?? '';
    ufController.selected = cteLocalColetaModel.uf ?? 'AC';
    formWasChangedDetail = false;
  }

  @override
  Future<void> save() async {
    if (!cteLocalColetaFormKey.currentState!.validate()) {
      showErrorSnackBar(message: 'validator_form_message'.tr);
      return;
    }

    if (formWasChangedDetail) {
      if (isNewRecord) {
        cteLocalColetaModelList.insert(0, cteLocalColetaModel.clone());
      } else {
        final index = cteLocalColetaModelList.indexWhere((m) => m.tempId == cteLocalColetaModel.tempId);
        if (index >= 0) {
          cteLocalColetaModelList[index] = cteLocalColetaModel.clone();
        }
      }

      userMadeChanges = true;
      loadData();
      Get.back(result: true);
    } else {
      Get.back();
    }
  }


  @override
  Future deleteSelected() async {
    final currentRow = plutoGridStateManager.currentRow;
    if (currentRow == null) {
      showInfoSnackBar(message: 'message_select_one_to_delete'.tr);
      return null;
    }
    showDeleteDialog(() async {
      final id = currentRow.cells['id']?.value;
      final tempId = currentRow.cells['tempId']?.value;
      cteLocalColetaModelList.removeWhere((model) => (id != 0 && model.id == id) || (id == 0 && model.tempId == tempId));
      plutoGridStateManager.removeCurrentRow();
      userMadeChanges = true;
    });
  }

  @override
  void preventDataLoss() {
    if (formWasChangedDetail) {
      showQuestionDialog('message_data_loss'.tr, () => Get.back());
    } else {
      formWasChangedDetail = false;
      Get.back();
    }
  }

  @override
  void onClose() {
    cnpjController.dispose();
    cpfController.dispose();
    nomeController.dispose();
    logradouroController.dispose();
    numeroController.dispose();
    complementoController.dispose();
    bairroController.dispose();
    codigoMunicipioController.dispose();
    nomeMunicipioController.dispose();
    ufController.dispose();
  }

}