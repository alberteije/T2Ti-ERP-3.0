import 'package:flutter/material.dart';
import 'package:cte/app/controller/cte_ferroviario_vagao_controller.dart';
import 'package:cte/app/page/shared_page/list_page_base.dart';

class CteFerroviarioVagaoListPage extends ListPageBase<CteFerroviarioVagaoController> {
  const CteFerroviarioVagaoListPage({Key? key}) : super(key: key);

  @override
  List<Map<String, dynamic>> get mobileItems => controller.mobileItems;

  @override
  Map<String, dynamic> get mobileConfig => controller.mobileConfig;

  @override
  String get standardFieldForFilter => controller.standardFieldForFilter;
}