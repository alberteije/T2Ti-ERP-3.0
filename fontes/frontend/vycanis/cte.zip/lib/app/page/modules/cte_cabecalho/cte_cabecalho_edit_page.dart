import 'package:flutter/material.dart';
import 'package:flutter_bootstrap/flutter_bootstrap.dart';
import 'package:get/get.dart';
import 'package:cte/app/data/domain/domain_imports.dart';
import 'package:cte/app/controller/cte_cabecalho_controller.dart';
import 'package:cte/app/infra/infra_imports.dart';
import 'package:cte/app/page/shared_widget/input/input_imports.dart';

class CteCabecalhoEditPage extends StatelessWidget {
	CteCabecalhoEditPage({Key? key}) : super(key: key);
	final cteCabecalhoController = Get.find<CteCabecalhoController>();

	@override
	Widget build(BuildContext context) {
			return Scaffold(
				key: cteCabecalhoController.cteCabecalhoScaffoldKey,
				body: SafeArea(
					top: false,
					bottom: false,
					child: Form(
						key: cteCabecalhoController.cteCabecalhoFormKey,
						autovalidateMode: AutovalidateMode.always,
						child: Scrollbar(
							controller: cteCabecalhoController.scrollController,
							child: SingleChildScrollView(
								controller: cteCabecalhoController.scrollController,
								child: BootstrapContainer(
									fluid: true,
									padding: const EdgeInsets.all(10),
									children: <Widget>[
										const Divider(
											color: Colors.transparent,
										),
										BootstrapRow(
											height: 60,
											children: <BootstrapCol>[
												BootstrapCol(
													sizes: 'col-12',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: TextFormField(
															autofocus: true,
															maxLength: 60,
															controller: cteCabecalhoController.naturezaOperacaoController,
															decoration: inputDecoration(
																hintText: 'Informe os dados para o campo Natureza Operacao',
																labelText: 'Natureza Operacao',
																usePadding: true,
															),
															onSaved: (String? value) {},
															onChanged: (text) {
																cteCabecalhoController.currentModel.naturezaOperacao = text;
																cteCabecalhoController.formWasChanged = true;
															},
														),
													),
												),
											],
										),
										const Divider(
											color: Colors.transparent,
										),
										BootstrapRow(
											height: 60,
											children: <BootstrapCol>[
												BootstrapCol(
													sizes: 'col-12 col-md-6',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: TextFormField(
															autofocus: true,
															maxLength: 44,
															controller: cteCabecalhoController.chaveAcessoController,
															decoration: inputDecoration(
																hintText: 'Informe os dados para o campo Chave Acesso',
																labelText: 'Chave Acesso',
																usePadding: true,
															),
															onSaved: (String? value) {},
															onChanged: (text) {
																cteCabecalhoController.currentModel.chaveAcesso = text;
																cteCabecalhoController.formWasChanged = true;
															},
														),
													),
												),
												BootstrapCol(
													sizes: 'col-12 col-md-2',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: TextFormField(
															autofocus: true,
															maxLength: 1,
															controller: cteCabecalhoController.digitoChaveAcessoController,
															decoration: inputDecoration(
																hintText: 'Informe os dados para o campo Digito Chave Acesso',
																labelText: 'Digito Chave Acesso',
																usePadding: true,
															),
															onSaved: (String? value) {},
															onChanged: (text) {
																cteCabecalhoController.currentModel.digitoChaveAcesso = text;
																cteCabecalhoController.formWasChanged = true;
															},
														),
													),
												),
												BootstrapCol(
													sizes: 'col-12 col-md-4',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: TextFormField(
															autofocus: true,
															maxLength: 8,
															controller: cteCabecalhoController.codigoNumericoController,
															decoration: inputDecoration(
																hintText: 'Informe os dados para o campo Codigo Numerico',
																labelText: 'Codigo Numerico',
																usePadding: true,
															),
															onSaved: (String? value) {},
															onChanged: (text) {
																cteCabecalhoController.currentModel.codigoNumerico = text;
																cteCabecalhoController.formWasChanged = true;
															},
														),
													),
												),
											],
										),
										const Divider(
											color: Colors.transparent,
										),
										BootstrapRow(
											height: 60,
											children: <BootstrapCol>[
												BootstrapCol(
													sizes: 'col-12 col-md-4',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: TextFormField(
															autofocus: true,
															maxLength: 3,
															controller: cteCabecalhoController.serieController,
															decoration: inputDecoration(
																hintText: 'Informe os dados para o campo Serie',
																labelText: 'Serie',
																usePadding: true,
															),
															onSaved: (String? value) {},
															onChanged: (text) {
																cteCabecalhoController.currentModel.serie = text;
																cteCabecalhoController.formWasChanged = true;
															},
														),
													),
												),
												BootstrapCol(
													sizes: 'col-12 col-md-4',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: TextFormField(
															autofocus: true,
															maxLength: 9,
															controller: cteCabecalhoController.numeroController,
															decoration: inputDecoration(
																hintText: 'Informe os dados para o campo Numero',
																labelText: 'Numero',
																usePadding: true,
															),
															onSaved: (String? value) {},
															onChanged: (text) {
																cteCabecalhoController.currentModel.numero = text;
																cteCabecalhoController.formWasChanged = true;
															},
														),
													),
												),
												BootstrapCol(
													sizes: 'col-12 col-md-4',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: InputDecorator(
															decoration: inputDecoration(
																hintText: 'Informe os dados para o campo Data Hora Emissao',
																labelText: 'Data Hora Emissao',
																usePadding: true,
															),
															isEmpty: false,
															child: DatePickerItem(
																controller: cteCabecalhoController.dataHoraEmissaoController,
																firstDate: DateTime.parse('1000-01-01'),
																lastDate: DateTime.parse('5000-01-01'),
																onChanged: (DateTime? value) {
																	cteCabecalhoController.currentModel.dataHoraEmissao = value;
																	cteCabecalhoController.formWasChanged = true;
																},
															),
														),
													),
												),
											],
										),
										const Divider(
											color: Colors.transparent,
										),
										BootstrapRow(
											height: 60,
											children: <BootstrapCol>[
												BootstrapCol(
													sizes: 'col-12 col-md-3',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: CustomDropdownButton(
															controller: cteCabecalhoController.ufEmitenteController,
															labelText: 'UF Emitente',
															hintText: 'Informe os dados para o campo Uf Emitente',
															items: CteCabecalhoDomain.ufEmitenteListDropdown,
															onChanged: (dynamic newValue) {
																cteCabecalhoController.currentModel.ufEmitente = newValue;
																cteCabecalhoController.formWasChanged = true;
															},
														),
													),
												),
												BootstrapCol(
													sizes: 'col-12 col-md-3',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: TextFormField(
															autofocus: true,
															controller: cteCabecalhoController.cfopController,
															decoration: inputDecoration(
																hintText: 'Informe os dados para o campo Cfop',
																labelText: 'Cfop',
																usePadding: true,
															),
															onSaved: (String? value) {},
															onChanged: (text) {
																cteCabecalhoController.currentModel.cfop = int.tryParse(text);
																cteCabecalhoController.formWasChanged = true;
															},
														),
													),
												),
												BootstrapCol(
													sizes: 'col-12 col-md-3',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: CustomDropdownButton(
															controller: cteCabecalhoController.formaPagamentoController,
															labelText: 'Forma Pagamento',
															hintText: 'Informe os dados para o campo Forma Pagamento',
															items: CteCabecalhoDomain.formaPagamentoListDropdown,
															onChanged: (dynamic newValue) {
																cteCabecalhoController.currentModel.formaPagamento = newValue;
																cteCabecalhoController.formWasChanged = true;
															},
														),
													),
												),
												BootstrapCol(
													sizes: 'col-12 col-md-3',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: CustomDropdownButton(
															controller: cteCabecalhoController.modeloController,
															labelText: 'Modelo',
															hintText: 'Informe os dados para o campo Modelo',
															items: CteCabecalhoDomain.modeloListDropdown,
															onChanged: (dynamic newValue) {
																cteCabecalhoController.currentModel.modelo = newValue;
																cteCabecalhoController.formWasChanged = true;
															},
														),
													),
												),
											],
										),
										const Divider(
											color: Colors.transparent,
										),
										BootstrapRow(
											height: 60,
											children: <BootstrapCol>[
												BootstrapCol(
													sizes: 'col-12 col-md-3',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: CustomDropdownButton(
															controller: cteCabecalhoController.formatoImpressaoDacteController,
															labelText: 'Formato Impressao Dacte',
															hintText: 'Informe os dados para o campo Formato Impressao Dacte',
															items: CteCabecalhoDomain.formatoImpressaoDacteListDropdown,
															onChanged: (dynamic newValue) {
																cteCabecalhoController.currentModel.formatoImpressaoDacte = newValue;
																cteCabecalhoController.formWasChanged = true;
															},
														),
													),
												),
												BootstrapCol(
													sizes: 'col-12 col-md-3',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: CustomDropdownButton(
															controller: cteCabecalhoController.tipoEmissaoController,
															labelText: 'Tipo Emissao',
															hintText: 'Informe os dados para o campo Tipo Emissao',
															items: CteCabecalhoDomain.tipoEmissaoListDropdown,
															onChanged: (dynamic newValue) {
																cteCabecalhoController.currentModel.tipoEmissao = newValue;
																cteCabecalhoController.formWasChanged = true;
															},
														),
													),
												),
												BootstrapCol(
													sizes: 'col-12 col-md-3',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: CustomDropdownButton(
															controller: cteCabecalhoController.ambienteController,
															labelText: 'Ambiente',
															hintText: 'Informe os dados para o campo Ambiente',
															items: CteCabecalhoDomain.ambienteListDropdown,
															onChanged: (dynamic newValue) {
																cteCabecalhoController.currentModel.ambiente = newValue;
																cteCabecalhoController.formWasChanged = true;
															},
														),
													),
												),
												BootstrapCol(
													sizes: 'col-12 col-md-3',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: CustomDropdownButton(
															controller: cteCabecalhoController.tipoCteController,
															labelText: 'Tipo Cte',
															hintText: 'Informe os dados para o campo Tipo Cte',
															items: CteCabecalhoDomain.tipoCteListDropdown,
															onChanged: (dynamic newValue) {
																cteCabecalhoController.currentModel.tipoCte = newValue;
																cteCabecalhoController.formWasChanged = true;
															},
														),
													),
												),
											],
										),
										const Divider(
											color: Colors.transparent,
										),
										BootstrapRow(
											height: 60,
											children: <BootstrapCol>[
												BootstrapCol(
													sizes: 'col-12 col-md-2',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: CustomDropdownButton(
															controller: cteCabecalhoController.processoEmissaoController,
															labelText: 'Processo Emissao',
															hintText: 'Informe os dados para o campo Processo Emissao',
															items: CteCabecalhoDomain.processoEmissaoListDropdown,
															onChanged: (dynamic newValue) {
																cteCabecalhoController.currentModel.processoEmissao = newValue;
																cteCabecalhoController.formWasChanged = true;
															},
														),
													),
												),
												BootstrapCol(
													sizes: 'col-12 col-md-2',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: TextFormField(
															autofocus: true,
															maxLength: 20,
															controller: cteCabecalhoController.versaoProcessoEmissaoController,
															decoration: inputDecoration(
																hintText: 'Informe os dados para o campo Versao Processo Emissao',
																labelText: 'Versao Processo Emissao',
																usePadding: true,
															),
															onSaved: (String? value) {},
															onChanged: (text) {
																cteCabecalhoController.currentModel.versaoProcessoEmissao = text;
																cteCabecalhoController.formWasChanged = true;
															},
														),
													),
												),
												BootstrapCol(
													sizes: 'col-12 col-md-8',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: TextFormField(
															autofocus: true,
															maxLength: 44,
															controller: cteCabecalhoController.chaveReferenciadoController,
															decoration: inputDecoration(
																hintText: 'Informe os dados para o campo Chave Referenciado',
																labelText: 'Chave Referenciado',
																usePadding: true,
															),
															onSaved: (String? value) {},
															onChanged: (text) {
																cteCabecalhoController.currentModel.chaveReferenciado = text;
																cteCabecalhoController.formWasChanged = true;
															},
														),
													),
												),
											],
										),
										const Divider(
											color: Colors.transparent,
										),
										BootstrapRow(
											height: 60,
											children: <BootstrapCol>[
												BootstrapCol(
													sizes: 'col-12 col-md-2',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: TextFormField(
															autofocus: true,
															controller: cteCabecalhoController.codigoMunicipioEnvioController,
															decoration: inputDecoration(
																hintText: 'Informe os dados para o campo Codigo Municipio Envio',
																labelText: 'Codigo Municipio Envio',
																usePadding: true,
															),
															onSaved: (String? value) {},
															onChanged: (text) {
																cteCabecalhoController.currentModel.codigoMunicipioEnvio = int.tryParse(text);
																cteCabecalhoController.formWasChanged = true;
															},
														),
													),
												),
												BootstrapCol(
													sizes: 'col-12 col-md-8',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: TextFormField(
															autofocus: true,
															maxLength: 60,
															controller: cteCabecalhoController.nomeMunicipioEnvioController,
															decoration: inputDecoration(
																hintText: 'Informe os dados para o campo Nome Municipio Envio',
																labelText: 'Nome Municipio Envio',
																usePadding: true,
															),
															onSaved: (String? value) {},
															onChanged: (text) {
																cteCabecalhoController.currentModel.nomeMunicipioEnvio = text;
																cteCabecalhoController.formWasChanged = true;
															},
														),
													),
												),
												BootstrapCol(
													sizes: 'col-12 col-md-2',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: CustomDropdownButton(
															controller: cteCabecalhoController.ufEnvioController,
															labelText: 'Uf Envio',
															hintText: 'Informe os dados para o campo Uf Envio',
															items: CteCabecalhoDomain.ufEnvioListDropdown,
															onChanged: (dynamic newValue) {
																cteCabecalhoController.currentModel.ufEnvio = newValue;
																cteCabecalhoController.formWasChanged = true;
															},
														),
													),
												),
											],
										),
										const Divider(
											color: Colors.transparent,
										),
										BootstrapRow(
											height: 60,
											children: <BootstrapCol>[
												BootstrapCol(
													sizes: 'col-12 col-md-2',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: CustomDropdownButton(
															controller: cteCabecalhoController.modalController,
															labelText: 'Modal',
															hintText: 'Informe os dados para o campo Modal',
															items: CteCabecalhoDomain.modalListDropdown,
															onChanged: (dynamic newValue) {
																cteCabecalhoController.currentModel.modal = newValue;
																cteCabecalhoController.formWasChanged = true;
															},
														),
													),
												),
												BootstrapCol(
													sizes: 'col-12 col-md-2',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: CustomDropdownButton(
															controller: cteCabecalhoController.tipoServicoController,
															labelText: 'Tipo Servico',
															hintText: 'Informe os dados para o campo Tipo Servico',
															items: CteCabecalhoDomain.tipoServicoListDropdown,
															onChanged: (dynamic newValue) {
																cteCabecalhoController.currentModel.tipoServico = newValue;
																cteCabecalhoController.formWasChanged = true;
															},
														),
													),
												),
												BootstrapCol(
													sizes: 'col-12 col-md-2',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: TextFormField(
															autofocus: true,
															controller: cteCabecalhoController.codigoMunicipioIniPrestacaoController,
															decoration: inputDecoration(
																hintText: 'Informe os dados para o campo Codigo Municipio Ini Prestacao',
																labelText: 'Codigo Municipio Ini Prestacao',
																usePadding: true,
															),
															onSaved: (String? value) {},
															onChanged: (text) {
																cteCabecalhoController.currentModel.codigoMunicipioIniPrestacao = int.tryParse(text);
																cteCabecalhoController.formWasChanged = true;
															},
														),
													),
												),
												BootstrapCol(
													sizes: 'col-12 col-md-4',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: TextFormField(
															autofocus: true,
															maxLength: 60,
															controller: cteCabecalhoController.nomeMunicipioIniPrestacaoController,
															decoration: inputDecoration(
																hintText: 'Informe os dados para o campo Nome Municipio Ini Prestacao',
																labelText: 'Nome Municipio Ini Prestacao',
																usePadding: true,
															),
															onSaved: (String? value) {},
															onChanged: (text) {
																cteCabecalhoController.currentModel.nomeMunicipioIniPrestacao = text;
																cteCabecalhoController.formWasChanged = true;
															},
														),
													),
												),
												BootstrapCol(
													sizes: 'col-12 col-md-2',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: CustomDropdownButton(
															controller: cteCabecalhoController.ufIniPrestacaoController,
															labelText: 'Uf Ini Prestacao',
															hintText: 'Informe os dados para o campo Uf Ini Prestacao',
															items: CteCabecalhoDomain.ufIniPrestacaoListDropdown,
															onChanged: (dynamic newValue) {
																cteCabecalhoController.currentModel.ufIniPrestacao = newValue;
																cteCabecalhoController.formWasChanged = true;
															},
														),
													),
												),
											],
										),
										const Divider(
											color: Colors.transparent,
										),
										BootstrapRow(
											height: 60,
											children: <BootstrapCol>[
												BootstrapCol(
													sizes: 'col-12 col-md-2',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: TextFormField(
															autofocus: true,
															controller: cteCabecalhoController.codigoMunicipioFimPrestacaoController,
															decoration: inputDecoration(
																hintText: 'Informe os dados para o campo Codigo Municipio Fim Prestacao',
																labelText: 'Codigo Municipio Fim Prestacao',
																usePadding: true,
															),
															onSaved: (String? value) {},
															onChanged: (text) {
																cteCabecalhoController.currentModel.codigoMunicipioFimPrestacao = int.tryParse(text);
																cteCabecalhoController.formWasChanged = true;
															},
														),
													),
												),
												BootstrapCol(
													sizes: 'col-12 col-md-8',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: TextFormField(
															autofocus: true,
															maxLength: 60,
															controller: cteCabecalhoController.nomeMunicipioFimPrestacaoController,
															decoration: inputDecoration(
																hintText: 'Informe os dados para o campo Nome Municipio Fim Prestacao',
																labelText: 'Nome Municipio Fim Prestacao',
																usePadding: true,
															),
															onSaved: (String? value) {},
															onChanged: (text) {
																cteCabecalhoController.currentModel.nomeMunicipioFimPrestacao = text;
																cteCabecalhoController.formWasChanged = true;
															},
														),
													),
												),
												BootstrapCol(
													sizes: 'col-12 col-md-2',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: CustomDropdownButton(
															controller: cteCabecalhoController.ufFimPrestacaoController,
															labelText: 'Uf Fim Prestacao',
															hintText: 'Informe os dados para o campo Uf Fim Prestacao',
															items: CteCabecalhoDomain.ufFimPrestacaoListDropdown,
															onChanged: (dynamic newValue) {
																cteCabecalhoController.currentModel.ufFimPrestacao = newValue;
																cteCabecalhoController.formWasChanged = true;
															},
														),
													),
												),
											],
										),
										const Divider(
											color: Colors.transparent,
										),
										BootstrapRow(
											height: 60,
											children: <BootstrapCol>[
												BootstrapCol(
													sizes: 'col-12 col-md-2',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: CustomDropdownButton(
															controller: cteCabecalhoController.retiraController,
															labelText: 'Retira',
															hintText: 'Informe os dados para o campo Retira',
															items: CteCabecalhoDomain.retiraListDropdown,
															onChanged: (dynamic newValue) {
																cteCabecalhoController.currentModel.retira = newValue;
																cteCabecalhoController.formWasChanged = true;
															},
														),
													),
												),
												BootstrapCol(
													sizes: 'col-12 col-md-10',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: TextFormField(
															autofocus: true,
															maxLength: 160,
															controller: cteCabecalhoController.retiraDetalheController,
															decoration: inputDecoration(
																hintText: 'Informe os dados para o campo Retira Detalhe',
																labelText: 'Retira Detalhe',
																usePadding: true,
															),
															onSaved: (String? value) {},
															onChanged: (text) {
																cteCabecalhoController.currentModel.retiraDetalhe = text;
																cteCabecalhoController.formWasChanged = true;
															},
														),
													),
												),
											],
										),
										const Divider(
											color: Colors.transparent,
										),
										BootstrapRow(
											height: 60,
											children: <BootstrapCol>[
												BootstrapCol(
													sizes: 'col-12 col-md-6',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: CustomDropdownButton(
															controller: cteCabecalhoController.tomadorController,
															labelText: 'Tomador',
															hintText: 'Informe os dados para o campo Tomador',
															items: CteCabecalhoDomain.tomadorListDropdown,
															onChanged: (dynamic newValue) {
																cteCabecalhoController.currentModel.tomador = newValue;
																cteCabecalhoController.formWasChanged = true;
															},
														),
													),
												),
												BootstrapCol(
													sizes: 'col-12 col-md-6',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: InputDecorator(
															decoration: inputDecoration(
																hintText: 'Informe os dados para o campo Data Entrada Contingencia',
																labelText: 'Data Entrada Contingencia',
																usePadding: true,
															),
															isEmpty: false,
															child: DatePickerItem(
																controller: cteCabecalhoController.dataEntradaContingenciaController,
																firstDate: DateTime.parse('1000-01-01'),
																lastDate: DateTime.parse('5000-01-01'),
																onChanged: (DateTime? value) {
																	cteCabecalhoController.currentModel.dataEntradaContingencia = value;
																	cteCabecalhoController.formWasChanged = true;
																},
															),
														),
													),
												),
											],
										),
										const Divider(
											color: Colors.transparent,
										),
										BootstrapRow(
											height: 60,
											children: <BootstrapCol>[
												BootstrapCol(
													sizes: 'col-12',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: TextFormField(
															autofocus: true,
															maxLength: 255,
															controller: cteCabecalhoController.justificativaContingenciaController,
															decoration: inputDecoration(
																hintText: 'Informe os dados para o campo Justificativa Contingencia',
																labelText: 'Justificativa Contingencia',
																usePadding: true,
															),
															onSaved: (String? value) {},
															onChanged: (text) {
																cteCabecalhoController.currentModel.justificativaContingencia = text;
																cteCabecalhoController.formWasChanged = true;
															},
														),
													),
												),
											],
										),
										const Divider(
											color: Colors.transparent,
										),
										BootstrapRow(
											height: 60,
											children: <BootstrapCol>[
												BootstrapCol(
													sizes: 'col-12 col-md-6',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: TextFormField(
															autofocus: true,
															maxLength: 15,
															controller: cteCabecalhoController.caracAdicionalTransporteController,
															decoration: inputDecoration(
																hintText: 'Informe os dados para o campo Carac Adicional Transporte',
																labelText: 'Carac Adicional Transporte',
																usePadding: true,
															),
															onSaved: (String? value) {},
															onChanged: (text) {
																cteCabecalhoController.currentModel.caracAdicionalTransporte = text;
																cteCabecalhoController.formWasChanged = true;
															},
														),
													),
												),
												BootstrapCol(
													sizes: 'col-12 col-md-6',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: TextFormField(
															autofocus: true,
															maxLength: 30,
															controller: cteCabecalhoController.caracAdicionalServicoController,
															decoration: inputDecoration(
																hintText: 'Informe os dados para o campo Carac Adicional Servico',
																labelText: 'Carac Adicional Servico',
																usePadding: true,
															),
															onSaved: (String? value) {},
															onChanged: (text) {
																cteCabecalhoController.currentModel.caracAdicionalServico = text;
																cteCabecalhoController.formWasChanged = true;
															},
														),
													),
												),
											],
										),
										const Divider(
											color: Colors.transparent,
										),
										BootstrapRow(
											height: 60,
											children: <BootstrapCol>[
												BootstrapCol(
													sizes: 'col-12 col-md-6',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: TextFormField(
															autofocus: true,
															maxLength: 20,
															controller: cteCabecalhoController.funcionarioEmissorController,
															decoration: inputDecoration(
																hintText: 'Informe os dados para o campo Funcionario Emissor',
																labelText: 'Funcionario Emissor',
																usePadding: true,
															),
															onSaved: (String? value) {},
															onChanged: (text) {
																cteCabecalhoController.currentModel.funcionarioEmissor = text;
																cteCabecalhoController.formWasChanged = true;
															},
														),
													),
												),
												BootstrapCol(
													sizes: 'col-12 col-md-6',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: TextFormField(
															autofocus: true,
															maxLength: 15,
															controller: cteCabecalhoController.fluxoOrigemController,
															decoration: inputDecoration(
																hintText: 'Informe os dados para o campo Fluxo Origem',
																labelText: 'Fluxo Origem',
																usePadding: true,
															),
															onSaved: (String? value) {},
															onChanged: (text) {
																cteCabecalhoController.currentModel.fluxoOrigem = text;
																cteCabecalhoController.formWasChanged = true;
															},
														),
													),
												),
											],
										),
										const Divider(
											color: Colors.transparent,
										),
										BootstrapRow(
											height: 60,
											children: <BootstrapCol>[
												BootstrapCol(
													sizes: 'col-12 col-md-3',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: CustomDropdownButton(
															controller: cteCabecalhoController.entregaTipoPeriodoController,
															labelText: 'Entrega Tipo Periodo',
															hintText: 'Informe os dados para o campo Entrega Tipo Periodo',
															items: CteCabecalhoDomain.entregaTipoPeriodoListDropdown,
															onChanged: (dynamic newValue) {
																cteCabecalhoController.currentModel.entregaTipoPeriodo = newValue;
																cteCabecalhoController.formWasChanged = true;
															},
														),
													),
												),
												BootstrapCol(
													sizes: 'col-12 col-md-3',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: InputDecorator(
															decoration: inputDecoration(
																hintText: 'Informe os dados para o campo Entrega Data Programada',
																labelText: 'Entrega Data Programada',
																usePadding: true,
															),
															isEmpty: false,
															child: DatePickerItem(
																controller: cteCabecalhoController.entregaDataProgramadaController,
																firstDate: DateTime.parse('1000-01-01'),
																lastDate: DateTime.parse('5000-01-01'),
																onChanged: (DateTime? value) {
																	cteCabecalhoController.currentModel.entregaDataProgramada = value;
																	cteCabecalhoController.formWasChanged = true;
																},
															),
														),
													),
												),
												BootstrapCol(
													sizes: 'col-12 col-md-3',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: InputDecorator(
															decoration: inputDecoration(
																hintText: 'Informe os dados para o campo Entrega Data Inicial',
																labelText: 'Entrega Data Inicial',
																usePadding: true,
															),
															isEmpty: false,
															child: DatePickerItem(
																controller: cteCabecalhoController.entregaDataInicialController,
																firstDate: DateTime.parse('1000-01-01'),
																lastDate: DateTime.parse('5000-01-01'),
																onChanged: (DateTime? value) {
																	cteCabecalhoController.currentModel.entregaDataInicial = value;
																	cteCabecalhoController.formWasChanged = true;
																},
															),
														),
													),
												),
												BootstrapCol(
													sizes: 'col-12 col-md-3',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: InputDecorator(
															decoration: inputDecoration(
																hintText: 'Informe os dados para o campo Entrega Data Final',
																labelText: 'Entrega Data Final',
																usePadding: true,
															),
															isEmpty: false,
															child: DatePickerItem(
																controller: cteCabecalhoController.entregaDataFinalController,
																firstDate: DateTime.parse('1000-01-01'),
																lastDate: DateTime.parse('5000-01-01'),
																onChanged: (DateTime? value) {
																	cteCabecalhoController.currentModel.entregaDataFinal = value;
																	cteCabecalhoController.formWasChanged = true;
																},
															),
														),
													),
												),
											],
										),
										const Divider(
											color: Colors.transparent,
										),
										BootstrapRow(
											height: 60,
											children: <BootstrapCol>[
												BootstrapCol(
													sizes: 'col-12 col-md-3',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: CustomDropdownButton(
															controller: cteCabecalhoController.entregaTipoHoraController,
															labelText: 'Entrega Tipo Hora',
															hintText: 'Informe os dados para o campo Entrega Tipo Hora',
															items: CteCabecalhoDomain.entregaTipoHoraListDropdown,
															onChanged: (dynamic newValue) {
																cteCabecalhoController.currentModel.entregaTipoHora = newValue;
																cteCabecalhoController.formWasChanged = true;
															},
														),
													),
												),
												BootstrapCol(
													sizes: 'col-12 col-md-3',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: TextFormField(
															autofocus: true,
															maxLength: 8,
															controller: cteCabecalhoController.entregaHoraProgramadaController,
															decoration: inputDecoration(
																hintText: 'Informe os dados para o campo Entrega Hora Programada',
																labelText: 'Entrega Hora Programada',
																usePadding: true,
															),
															onSaved: (String? value) {},
															onChanged: (text) {
																cteCabecalhoController.currentModel.entregaHoraProgramada = text;
																cteCabecalhoController.formWasChanged = true;
															},
														),
													),
												),
												BootstrapCol(
													sizes: 'col-12 col-md-3',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: TextFormField(
															autofocus: true,
															maxLength: 8,
															controller: cteCabecalhoController.entregaHoraInicialController,
															decoration: inputDecoration(
																hintText: 'Informe os dados para o campo Entrega Hora Inicial',
																labelText: 'Entrega Hora Inicial',
																usePadding: true,
															),
															onSaved: (String? value) {},
															onChanged: (text) {
																cteCabecalhoController.currentModel.entregaHoraInicial = text;
																cteCabecalhoController.formWasChanged = true;
															},
														),
													),
												),
												BootstrapCol(
													sizes: 'col-12 col-md-3',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: TextFormField(
															autofocus: true,
															maxLength: 8,
															controller: cteCabecalhoController.entregaHoraFinalController,
															decoration: inputDecoration(
																hintText: 'Informe os dados para o campo Entrega Hora Final',
																labelText: 'Entrega Hora Final',
																usePadding: true,
															),
															onSaved: (String? value) {},
															onChanged: (text) {
																cteCabecalhoController.currentModel.entregaHoraFinal = text;
																cteCabecalhoController.formWasChanged = true;
															},
														),
													),
												),
											],
										),
										const Divider(
											color: Colors.transparent,
										),
										BootstrapRow(
											height: 60,
											children: <BootstrapCol>[
												BootstrapCol(
													sizes: 'col-12 col-md-6',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: TextFormField(
															autofocus: true,
															maxLength: 40,
															controller: cteCabecalhoController.municipioOrigemCalculoController,
															decoration: inputDecoration(
																hintText: 'Informe os dados para o campo Municipio Origem Calculo',
																labelText: 'Municipio Origem Calculo',
																usePadding: true,
															),
															onSaved: (String? value) {},
															onChanged: (text) {
																cteCabecalhoController.currentModel.municipioOrigemCalculo = text;
																cteCabecalhoController.formWasChanged = true;
															},
														),
													),
												),
												BootstrapCol(
													sizes: 'col-12 col-md-6',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: TextFormField(
															autofocus: true,
															maxLength: 40,
															controller: cteCabecalhoController.municipioDestinoCalculoController,
															decoration: inputDecoration(
																hintText: 'Informe os dados para o campo Municipio Destino Calculo',
																labelText: 'Municipio Destino Calculo',
																usePadding: true,
															),
															onSaved: (String? value) {},
															onChanged: (text) {
																cteCabecalhoController.currentModel.municipioDestinoCalculo = text;
																cteCabecalhoController.formWasChanged = true;
															},
														),
													),
												),
											],
										),
										const Divider(
											color: Colors.transparent,
										),
										BootstrapRow(
											height: 60,
											children: <BootstrapCol>[
												BootstrapCol(
													sizes: 'col-12',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: TextFormField(
															autofocus: true,
															controller: cteCabecalhoController.observacoesGeraisController,
															decoration: inputDecoration(
																hintText: 'Informe os dados para o campo Observacoes Gerais',
																labelText: 'Observacoes Gerais',
																usePadding: true,
															),
															onSaved: (String? value) {},
															onChanged: (text) {
																cteCabecalhoController.currentModel.observacoesGerais = text;
																cteCabecalhoController.formWasChanged = true;
															},
														),
													),
												),
											],
										),
										const Divider(
											color: Colors.transparent,
										),
										BootstrapRow(
											height: 60,
											children: <BootstrapCol>[
												BootstrapCol(
													sizes: 'col-12 col-md-2',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: TextFormField(
															autofocus: true,
															controller: cteCabecalhoController.valorTotalServicoController,
															decoration: inputDecoration(
																hintText: 'Informe os dados para o campo Valor Total Servico',
																labelText: 'Valor Total Servico',
																usePadding: true,
															),
															onSaved: (String? value) {},
															onChanged: (text) {
																cteCabecalhoController.currentModel.valorTotalServico = cteCabecalhoController.valorTotalServicoController.numberValue;
																cteCabecalhoController.formWasChanged = true;
															},
														),
													),
												),
												BootstrapCol(
													sizes: 'col-12 col-md-2',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: TextFormField(
															autofocus: true,
															controller: cteCabecalhoController.valorReceberController,
															decoration: inputDecoration(
																hintText: 'Informe os dados para o campo Valor Receber',
																labelText: 'Valor Receber',
																usePadding: true,
															),
															onSaved: (String? value) {},
															onChanged: (text) {
																cteCabecalhoController.currentModel.valorReceber = cteCabecalhoController.valorReceberController.numberValue;
																cteCabecalhoController.formWasChanged = true;
															},
														),
													),
												),
												BootstrapCol(
													sizes: 'col-12 col-md-2',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: TextFormField(
															autofocus: true,
															maxLength: 2,
															controller: cteCabecalhoController.cstController,
															decoration: inputDecoration(
																hintText: 'Informe os dados para o campo Cst',
																labelText: 'Cst',
																usePadding: true,
															),
															onSaved: (String? value) {},
															onChanged: (text) {
																cteCabecalhoController.currentModel.cst = text;
																cteCabecalhoController.formWasChanged = true;
															},
														),
													),
												),
												BootstrapCol(
													sizes: 'col-12 col-md-2',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: TextFormField(
															autofocus: true,
															controller: cteCabecalhoController.baseCalculoIcmsController,
															decoration: inputDecoration(
																hintText: 'Informe os dados para o campo Base Calculo Icms',
																labelText: 'Base Calculo Icms',
																usePadding: true,
															),
															onSaved: (String? value) {},
															onChanged: (text) {
																cteCabecalhoController.currentModel.baseCalculoIcms = cteCabecalhoController.baseCalculoIcmsController.numberValue;
																cteCabecalhoController.formWasChanged = true;
															},
														),
													),
												),
												BootstrapCol(
													sizes: 'col-12 col-md-2',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: TextFormField(
															autofocus: true,
															controller: cteCabecalhoController.aliquotaIcmsController,
															decoration: inputDecoration(
																hintText: 'Informe os dados para o campo Aliquota Icms',
																labelText: 'Aliquota Icms',
																usePadding: true,
															),
															onSaved: (String? value) {},
															onChanged: (text) {
																cteCabecalhoController.currentModel.aliquotaIcms = cteCabecalhoController.aliquotaIcmsController.numberValue;
																cteCabecalhoController.formWasChanged = true;
															},
														),
													),
												),
												BootstrapCol(
													sizes: 'col-12 col-md-2',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: TextFormField(
															autofocus: true,
															controller: cteCabecalhoController.valorIcmsController,
															decoration: inputDecoration(
																hintText: 'Informe os dados para o campo Valor Icms',
																labelText: 'Valor Icms',
																usePadding: true,
															),
															onSaved: (String? value) {},
															onChanged: (text) {
																cteCabecalhoController.currentModel.valorIcms = cteCabecalhoController.valorIcmsController.numberValue;
																cteCabecalhoController.formWasChanged = true;
															},
														),
													),
												),
											],
										),
										const Divider(
											color: Colors.transparent,
										),
										BootstrapRow(
											height: 60,
											children: <BootstrapCol>[
												BootstrapCol(
													sizes: 'col-12 col-md-2',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: TextFormField(
															autofocus: true,
															controller: cteCabecalhoController.percentualReducaoBcIcmsController,
															decoration: inputDecoration(
																hintText: 'Informe os dados para o campo Percentual Reducao Bc Icms',
																labelText: 'Percentual Reducao Bc Icms',
																usePadding: true,
															),
															onSaved: (String? value) {},
															onChanged: (text) {
																cteCabecalhoController.currentModel.percentualReducaoBcIcms = cteCabecalhoController.percentualReducaoBcIcmsController.numberValue;
																cteCabecalhoController.formWasChanged = true;
															},
														),
													),
												),
												BootstrapCol(
													sizes: 'col-12 col-md-2',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: TextFormField(
															autofocus: true,
															controller: cteCabecalhoController.valorBcIcmsStRetidoController,
															decoration: inputDecoration(
																hintText: 'Informe os dados para o campo Valor Bc Icms St Retido',
																labelText: 'Valor Bc Icms St Retido',
																usePadding: true,
															),
															onSaved: (String? value) {},
															onChanged: (text) {
																cteCabecalhoController.currentModel.valorBcIcmsStRetido = cteCabecalhoController.valorBcIcmsStRetidoController.numberValue;
																cteCabecalhoController.formWasChanged = true;
															},
														),
													),
												),
												BootstrapCol(
													sizes: 'col-12 col-md-2',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: TextFormField(
															autofocus: true,
															controller: cteCabecalhoController.valorIcmsStRetidoController,
															decoration: inputDecoration(
																hintText: 'Informe os dados para o campo Valor Icms St Retido',
																labelText: 'Valor Icms St Retido',
																usePadding: true,
															),
															onSaved: (String? value) {},
															onChanged: (text) {
																cteCabecalhoController.currentModel.valorIcmsStRetido = cteCabecalhoController.valorIcmsStRetidoController.numberValue;
																cteCabecalhoController.formWasChanged = true;
															},
														),
													),
												),
												BootstrapCol(
													sizes: 'col-12 col-md-2',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: TextFormField(
															autofocus: true,
															controller: cteCabecalhoController.aliquotaIcmsStRetidoController,
															decoration: inputDecoration(
																hintText: 'Informe os dados para o campo Aliquota Icms St Retido',
																labelText: 'Aliquota Icms St Retido',
																usePadding: true,
															),
															onSaved: (String? value) {},
															onChanged: (text) {
																cteCabecalhoController.currentModel.aliquotaIcmsStRetido = cteCabecalhoController.aliquotaIcmsStRetidoController.numberValue;
																cteCabecalhoController.formWasChanged = true;
															},
														),
													),
												),
												BootstrapCol(
													sizes: 'col-12 col-md-2',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: TextFormField(
															autofocus: true,
															controller: cteCabecalhoController.valorCreditoPresumidoIcmsController,
															decoration: inputDecoration(
																hintText: 'Informe os dados para o campo Valor Credito Presumido Icms',
																labelText: 'Valor Credito Presumido Icms',
																usePadding: true,
															),
															onSaved: (String? value) {},
															onChanged: (text) {
																cteCabecalhoController.currentModel.valorCreditoPresumidoIcms = cteCabecalhoController.valorCreditoPresumidoIcmsController.numberValue;
																cteCabecalhoController.formWasChanged = true;
															},
														),
													),
												),
												BootstrapCol(
													sizes: 'col-12 col-md-2',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: TextFormField(
															autofocus: true,
															controller: cteCabecalhoController.percentualBcIcmsOutraUfController,
															decoration: inputDecoration(
																hintText: 'Informe os dados para o campo Percentual Bc Icms Outra Uf',
																labelText: 'Percentual Bc Icms Outra Uf',
																usePadding: true,
															),
															onSaved: (String? value) {},
															onChanged: (text) {
																cteCabecalhoController.currentModel.percentualBcIcmsOutraUf = cteCabecalhoController.percentualBcIcmsOutraUfController.numberValue;
																cteCabecalhoController.formWasChanged = true;
															},
														),
													),
												),
											],
										),
										const Divider(
											color: Colors.transparent,
										),
										BootstrapRow(
											height: 60,
											children: <BootstrapCol>[
												BootstrapCol(
													sizes: 'col-12 col-md-4',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: TextFormField(
															autofocus: true,
															controller: cteCabecalhoController.valorBcIcmsOutraUfController,
															decoration: inputDecoration(
																hintText: 'Informe os dados para o campo Valor Bc Icms Outra Uf',
																labelText: 'Valor Bc Icms Outra Uf',
																usePadding: true,
															),
															onSaved: (String? value) {},
															onChanged: (text) {
																cteCabecalhoController.currentModel.valorBcIcmsOutraUf = cteCabecalhoController.valorBcIcmsOutraUfController.numberValue;
																cteCabecalhoController.formWasChanged = true;
															},
														),
													),
												),
												BootstrapCol(
													sizes: 'col-12 col-md-4',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: TextFormField(
															autofocus: true,
															controller: cteCabecalhoController.aliquotaIcmsOutraUfController,
															decoration: inputDecoration(
																hintText: 'Informe os dados para o campo Aliquota Icms Outra Uf',
																labelText: 'Aliquota Icms Outra Uf',
																usePadding: true,
															),
															onSaved: (String? value) {},
															onChanged: (text) {
																cteCabecalhoController.currentModel.aliquotaIcmsOutraUf = cteCabecalhoController.aliquotaIcmsOutraUfController.numberValue;
																cteCabecalhoController.formWasChanged = true;
															},
														),
													),
												),
												BootstrapCol(
													sizes: 'col-12 col-md-4',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: TextFormField(
															autofocus: true,
															controller: cteCabecalhoController.valorIcmsOutraUfController,
															decoration: inputDecoration(
																hintText: 'Informe os dados para o campo Valor Icms Outra Uf',
																labelText: 'Valor Icms Outra Uf',
																usePadding: true,
															),
															onSaved: (String? value) {},
															onChanged: (text) {
																cteCabecalhoController.currentModel.valorIcmsOutraUf = cteCabecalhoController.valorIcmsOutraUfController.numberValue;
																cteCabecalhoController.formWasChanged = true;
															},
														),
													),
												),
											],
										),
										const Divider(
											color: Colors.transparent,
										),
										BootstrapRow(
											height: 60,
											children: <BootstrapCol>[
												BootstrapCol(
													sizes: 'col-12 col-md-6',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: CustomDropdownButton(
															controller: cteCabecalhoController.simplesNacionalIndicadorController,
															labelText: 'Simples Nacional Indicador',
															hintText: 'Informe os dados para o campo Simples Nacional Indicador',
															items: CteCabecalhoDomain.simplesNacionalIndicadorListDropdown,
															onChanged: (dynamic newValue) {
																cteCabecalhoController.currentModel.simplesNacionalIndicador = newValue;
																cteCabecalhoController.formWasChanged = true;
															},
														),
													),
												),
												BootstrapCol(
													sizes: 'col-12 col-md-6',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: TextFormField(
															autofocus: true,
															controller: cteCabecalhoController.simplesNacionalTotalController,
															decoration: inputDecoration(
																hintText: 'Informe os dados para o campo Simples Nacional Total',
																labelText: 'Simples Nacional Total',
																usePadding: true,
															),
															onSaved: (String? value) {},
															onChanged: (text) {
																cteCabecalhoController.currentModel.simplesNacionalTotal = cteCabecalhoController.simplesNacionalTotalController.numberValue;
																cteCabecalhoController.formWasChanged = true;
															},
														),
													),
												),
											],
										),
										const Divider(
											color: Colors.transparent,
										),
										BootstrapRow(
											height: 60,
											children: <BootstrapCol>[
												BootstrapCol(
													sizes: 'col-12',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: TextFormField(
															autofocus: true,
															controller: cteCabecalhoController.informacoesAddFiscoController,
															decoration: inputDecoration(
																hintText: 'Informe os dados para o campo Informacoes Add Fisco',
																labelText: 'Informacoes Add Fisco',
																usePadding: true,
															),
															onSaved: (String? value) {},
															onChanged: (text) {
																cteCabecalhoController.currentModel.informacoesAddFisco = text;
																cteCabecalhoController.formWasChanged = true;
															},
														),
													),
												),
											],
										),
										const Divider(
											color: Colors.transparent,
										),
										BootstrapRow(
											height: 60,
											children: <BootstrapCol>[
												BootstrapCol(
													sizes: 'col-12 col-md-3',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: TextFormField(
															autofocus: true,
															controller: cteCabecalhoController.valorTotalCargaController,
															decoration: inputDecoration(
																hintText: 'Informe os dados para o campo Valor Total Carga',
																labelText: 'Valor Total Carga',
																usePadding: true,
															),
															onSaved: (String? value) {},
															onChanged: (text) {
																cteCabecalhoController.currentModel.valorTotalCarga = cteCabecalhoController.valorTotalCargaController.numberValue;
																cteCabecalhoController.formWasChanged = true;
															},
														),
													),
												),
												BootstrapCol(
													sizes: 'col-12 col-md-9',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: TextFormField(
															autofocus: true,
															maxLength: 60,
															controller: cteCabecalhoController.produtoPredominanteController,
															decoration: inputDecoration(
																hintText: 'Informe os dados para o campo Produto Predominante',
																labelText: 'Produto Predominante',
																usePadding: true,
															),
															onSaved: (String? value) {},
															onChanged: (text) {
																cteCabecalhoController.currentModel.produtoPredominante = text;
																cteCabecalhoController.formWasChanged = true;
															},
														),
													),
												),
											],
										),
										const Divider(
											color: Colors.transparent,
										),
										BootstrapRow(
											height: 60,
											children: <BootstrapCol>[
												BootstrapCol(
													sizes: 'col-12 col-md-8',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: TextFormField(
															autofocus: true,
															maxLength: 30,
															controller: cteCabecalhoController.cargaOutrasCaracteristicasController,
															decoration: inputDecoration(
																hintText: 'Informe os dados para o campo Carga Outras Caracteristicas',
																labelText: 'Carga Outras Caracteristicas',
																usePadding: true,
															),
															onSaved: (String? value) {},
															onChanged: (text) {
																cteCabecalhoController.currentModel.cargaOutrasCaracteristicas = text;
																cteCabecalhoController.formWasChanged = true;
															},
														),
													),
												),
												BootstrapCol(
													sizes: 'col-12 col-md-4',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: TextFormField(
															autofocus: true,
															controller: cteCabecalhoController.modalVersaoLayoutController,
															decoration: inputDecoration(
																hintText: 'Informe os dados para o campo Modal Versao Layout',
																labelText: 'Modal Versao Layout',
																usePadding: true,
															),
															onSaved: (String? value) {},
															onChanged: (text) {
																cteCabecalhoController.currentModel.modalVersaoLayout = int.tryParse(text);
																cteCabecalhoController.formWasChanged = true;
															},
														),
													),
												),
											],
										),
										const Divider(
											color: Colors.transparent,
										),
										BootstrapRow(
											height: 60,
											children: <BootstrapCol>[
												BootstrapCol(
													sizes: 'col-12',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: TextFormField(
															autofocus: true,
															maxLength: 44,
															controller: cteCabecalhoController.chaveCteSubstituidoController,
															decoration: inputDecoration(
																hintText: 'Informe os dados para o campo Chave Cte Substituido',
																labelText: 'Chave Cte Substituido',
																usePadding: true,
															),
															onSaved: (String? value) {},
															onChanged: (text) {
																cteCabecalhoController.currentModel.chaveCteSubstituido = text;
																cteCabecalhoController.formWasChanged = true;
															},
														),
													),
												),
											],
										),
										const Divider(
											indent: 10,
											endIndent: 10,
											thickness: 2,
										),
										BootstrapRow(
											height: 60,
											children: <BootstrapCol>[
												BootstrapCol(
													sizes: 'col-12',
													child: Text(
														'field_is_mandatory'.tr,
														style: Theme.of(context).textTheme.bodySmall,
													),
												),
											],
										),
										const SizedBox(height: 10.0),
									],
								),
							),
						),
					),
				),
			);
	}
}
