import 'package:get/get.dart';
import 'package:cte/app/controller/cte_rodoviario_lacre_controller.dart';
import 'package:cte/app/data/provider/api/cte_rodoviario_lacre_api_provider.dart';
import 'package:cte/app/data/provider/drift/cte_rodoviario_lacre_drift_provider.dart';
import 'package:cte/app/data/repository/cte_rodoviario_lacre_repository.dart';

class CteRodoviarioLacreBindings implements Binding {
	@override
	List<Bind> dependencies() {
		return [
			Bind.lazyPut<CteRodoviarioLacreController>(() => CteRodoviarioLacreController(
					cteRodoviarioLacreRepository:
							CteRodoviarioLacreRepository(cteRodoviarioLacreApiProvider: CteRodoviarioLacreApiProvider(), cteRodoviarioLacreDriftProvider: CteRodoviarioLacreDriftProvider()))),
		];
	}
}
