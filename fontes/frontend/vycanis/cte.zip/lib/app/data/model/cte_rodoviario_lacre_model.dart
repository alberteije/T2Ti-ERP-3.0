import 'dart:convert';
import 'package:pluto_grid/pluto_grid.dart';
import 'package:cte/app/data/model/model_imports.dart';


class CteRodoviarioLacreModel extends ModelBase {
  int? id;
  int? idCteRodoviario;
  String? numero;
  CteRodoviarioModel? cteRodoviarioModel;

  CteRodoviarioLacreModel({
    this.id,
    this.idCteRodoviario,
    this.numero,
    CteRodoviarioModel? cteRodoviarioModel,
  }) {
    this.cteRodoviarioModel = cteRodoviarioModel ?? CteRodoviarioModel();
  }

  static List<String> dbColumns = <String>[
    'id',
    'numero',
  ];

  static List<String> aliasColumns = <String>[
    'Id',
    'Numero',
  ];

  CteRodoviarioLacreModel.fromJson(Map<String, dynamic> jsonData) {
    id = jsonData['id'];
    idCteRodoviario = jsonData['idCteRodoviario'];
    numero = jsonData['numero'];
    cteRodoviarioModel = jsonData['cteRodoviarioModel'] == null ? CteRodoviarioModel() : CteRodoviarioModel.fromJson(jsonData['cteRodoviarioModel']);
  }

  Map<String, dynamic> get toJson {
    Map<String, dynamic> jsonData = <String, dynamic>{};

    jsonData['id'] = id != 0 ? id : null;
    jsonData['idCteRodoviario'] = idCteRodoviario != 0 ? idCteRodoviario : null;
    jsonData['numero'] = numero;
    jsonData['cteRodoviarioModel'] = cteRodoviarioModel?.toJson;
    jsonData['cteRodoviario'] = cteRodoviarioModel?.rntrc ?? '';

    return jsonData;
  }

  String objectEncodeJson() {
    final jsonData = toJson;
    return json.encode(jsonData);
  }

  static CteRodoviarioLacreModel fromPlutoRow(PlutoRow row) {
    return CteRodoviarioLacreModel(
      id: row.cells['id']?.value,
      idCteRodoviario: row.cells['idCteRodoviario']?.value,
      numero: row.cells['numero']?.value,
    );
  }

  PlutoRow toPlutoRow() {
    return PlutoRow(
      cells: {
        'tempId': PlutoCell(value: tempId),
        'id': PlutoCell(value: id ?? 0),
        'idCteRodoviario': PlutoCell(value: idCteRodoviario ?? 0),
        'numero': PlutoCell(value: numero ?? ''),
        'cteRodoviario': PlutoCell(value: cteRodoviarioModel?.rntrc ?? ''),
      },
    );
  }

  CteRodoviarioLacreModel clone() {
    return CteRodoviarioLacreModel(
      id: id,
      idCteRodoviario: idCteRodoviario,
      numero: numero,
      cteRodoviarioModel: cteRodoviarioModel?.clone(),
    );
  }


}