import 'dart:convert';
import 'package:pluto_grid/pluto_grid.dart';
import 'package:cte/app/data/model/model_imports.dart';

import 'package:cte/app/infra/infra_imports.dart';
import 'package:cte/app/data/domain/domain_imports.dart';

class CteEmitenteModel extends ModelBase {
  int? id;
  int? idCteCabecalho;
  String? cnpj;
  String? ie;
  String? nome;
  String? fantasia;
  String? logradouro;
  String? numero;
  String? complemento;
  String? bairro;
  int? codigoMunicipio;
  String? nomeMunicipio;
  String? uf;
  String? cep;
  String? telefone;

  CteEmitenteModel({
    this.id,
    this.idCteCabecalho,
    this.cnpj,
    this.ie,
    this.nome,
    this.fantasia,
    this.logradouro,
    this.numero,
    this.complemento,
    this.bairro,
    this.codigoMunicipio,
    this.nomeMunicipio,
    this.uf = 'AC',
    this.cep,
    this.telefone,
  });

  static List<String> dbColumns = <String>[
    'id',
    'cnpj',
    'ie',
    'nome',
    'fantasia',
    'logradouro',
    'numero',
    'complemento',
    'bairro',
    'codigo_municipio',
    'nome_municipio',
    'uf',
    'cep',
    'telefone',
  ];

  static List<String> aliasColumns = <String>[
    'Id',
    'Cnpj',
    'Ie',
    'Nome',
    'Fantasia',
    'Logradouro',
    'Numero',
    'Complemento',
    'Bairro',
    'Codigo Municipio',
    'Nome Municipio',
    'Uf',
    'Cep',
    'Telefone',
  ];

  CteEmitenteModel.fromJson(Map<String, dynamic> jsonData) {
    id = jsonData['id'];
    idCteCabecalho = jsonData['idCteCabecalho'];
    cnpj = jsonData['cnpj'];
    ie = jsonData['ie'];
    nome = jsonData['nome'];
    fantasia = jsonData['fantasia'];
    logradouro = jsonData['logradouro'];
    numero = jsonData['numero'];
    complemento = jsonData['complemento'];
    bairro = jsonData['bairro'];
    codigoMunicipio = jsonData['codigoMunicipio'];
    nomeMunicipio = jsonData['nomeMunicipio'];
    uf = CteEmitenteDomain.getUf(jsonData['uf']);
    cep = jsonData['cep'];
    telefone = jsonData['telefone'];
  }

  Map<String, dynamic> get toJson {
    Map<String, dynamic> jsonData = <String, dynamic>{};

    jsonData['id'] = id != 0 ? id : null;
    jsonData['idCteCabecalho'] = idCteCabecalho != 0 ? idCteCabecalho : null;
    jsonData['cnpj'] = Util.removeMask(cnpj);
    jsonData['ie'] = ie;
    jsonData['nome'] = nome;
    jsonData['fantasia'] = fantasia;
    jsonData['logradouro'] = logradouro;
    jsonData['numero'] = numero;
    jsonData['complemento'] = complemento;
    jsonData['bairro'] = bairro;
    jsonData['codigoMunicipio'] = codigoMunicipio;
    jsonData['nomeMunicipio'] = nomeMunicipio;
    jsonData['uf'] = CteEmitenteDomain.setUf(uf);
    jsonData['cep'] = Util.removeMask(cep);
    jsonData['telefone'] = telefone;

    return jsonData;
  }

  String objectEncodeJson() {
    final jsonData = toJson;
    return json.encode(jsonData);
  }

  static CteEmitenteModel fromPlutoRow(PlutoRow row) {
    return CteEmitenteModel(
      id: row.cells['id']?.value,
      idCteCabecalho: row.cells['idCteCabecalho']?.value,
      cnpj: row.cells['cnpj']?.value,
      ie: row.cells['ie']?.value,
      nome: row.cells['nome']?.value,
      fantasia: row.cells['fantasia']?.value,
      logradouro: row.cells['logradouro']?.value,
      numero: row.cells['numero']?.value,
      complemento: row.cells['complemento']?.value,
      bairro: row.cells['bairro']?.value,
      codigoMunicipio: row.cells['codigoMunicipio']?.value,
      nomeMunicipio: row.cells['nomeMunicipio']?.value,
      uf: row.cells['uf']?.value,
      cep: row.cells['cep']?.value,
      telefone: row.cells['telefone']?.value,
    );
  }

  PlutoRow toPlutoRow() {
    return PlutoRow(
      cells: {
        'tempId': PlutoCell(value: tempId),
        'id': PlutoCell(value: id ?? 0),
        'idCteCabecalho': PlutoCell(value: idCteCabecalho ?? 0),
        'cnpj': PlutoCell(value: cnpj ?? ''),
        'ie': PlutoCell(value: ie ?? ''),
        'nome': PlutoCell(value: nome ?? ''),
        'fantasia': PlutoCell(value: fantasia ?? ''),
        'logradouro': PlutoCell(value: logradouro ?? ''),
        'numero': PlutoCell(value: numero ?? ''),
        'complemento': PlutoCell(value: complemento ?? ''),
        'bairro': PlutoCell(value: bairro ?? ''),
        'codigoMunicipio': PlutoCell(value: codigoMunicipio ?? 0),
        'nomeMunicipio': PlutoCell(value: nomeMunicipio ?? ''),
        'uf': PlutoCell(value: uf ?? ''),
        'cep': PlutoCell(value: cep ?? ''),
        'telefone': PlutoCell(value: telefone ?? ''),
      },
    );
  }

  CteEmitenteModel clone() {
    return CteEmitenteModel(
      id: id,
      idCteCabecalho: idCteCabecalho,
      cnpj: cnpj,
      ie: ie,
      nome: nome,
      fantasia: fantasia,
      logradouro: logradouro,
      numero: numero,
      complemento: complemento,
      bairro: bairro,
      codigoMunicipio: codigoMunicipio,
      nomeMunicipio: nomeMunicipio,
      uf: uf,
      cep: cep,
      telefone: telefone,
    );
  }


}