import 'dart:convert';
import 'package:pluto_grid/pluto_grid.dart';
import 'package:cte/app/data/model/model_imports.dart';

import 'package:cte/app/infra/infra_imports.dart';
import 'package:intl/intl.dart';

class CteDutoviarioModel extends ModelBase {
  int? id;
  int? idCteCabecalho;
  double? valorTarifa;
  DateTime? dataInicio;
  DateTime? dataFim;

  CteDutoviarioModel({
    this.id,
    this.idCteCabecalho,
    this.valorTarifa,
    this.dataInicio,
    this.dataFim,
  });

  static List<String> dbColumns = <String>[
    'id',
    'valor_tarifa',
    'data_inicio',
    'data_fim',
  ];

  static List<String> aliasColumns = <String>[
    'Id',
    'Valor Tarifa',
    'Data Inicio',
    'Data Fim',
  ];

  CteDutoviarioModel.fromJson(Map<String, dynamic> jsonData) {
    id = jsonData['id'];
    idCteCabecalho = jsonData['idCteCabecalho'];
    valorTarifa = jsonData['valorTarifa']?.toDouble();
    dataInicio = jsonData['dataInicio'] != null ? DateTime.tryParse(jsonData['dataInicio']) : null;
    dataFim = jsonData['dataFim'] != null ? DateTime.tryParse(jsonData['dataFim']) : null;
  }

  Map<String, dynamic> get toJson {
    Map<String, dynamic> jsonData = <String, dynamic>{};

    jsonData['id'] = id != 0 ? id : null;
    jsonData['idCteCabecalho'] = idCteCabecalho != 0 ? idCteCabecalho : null;
    jsonData['valorTarifa'] = valorTarifa;
    jsonData['dataInicio'] = dataInicio != null ? DateFormat('yyyy-MM-ddT00:00:00').format(dataInicio!) : null;
    jsonData['dataFim'] = dataFim != null ? DateFormat('yyyy-MM-ddT00:00:00').format(dataFim!) : null;

    return jsonData;
  }

  String objectEncodeJson() {
    final jsonData = toJson;
    return json.encode(jsonData);
  }

  static CteDutoviarioModel fromPlutoRow(PlutoRow row) {
    return CteDutoviarioModel(
      id: row.cells['id']?.value,
      idCteCabecalho: row.cells['idCteCabecalho']?.value,
      valorTarifa: row.cells['valorTarifa']?.value,
      dataInicio: Util.stringToDate(row.cells['dataInicio']?.value),
      dataFim: Util.stringToDate(row.cells['dataFim']?.value),
    );
  }

  PlutoRow toPlutoRow() {
    return PlutoRow(
      cells: {
        'tempId': PlutoCell(value: tempId),
        'id': PlutoCell(value: id ?? 0),
        'idCteCabecalho': PlutoCell(value: idCteCabecalho ?? 0),
        'valorTarifa': PlutoCell(value: valorTarifa ?? 0.0),
        'dataInicio': PlutoCell(value: dataInicio),
        'dataFim': PlutoCell(value: dataFim),
      },
    );
  }

  CteDutoviarioModel clone() {
    return CteDutoviarioModel(
      id: id,
      idCteCabecalho: idCteCabecalho,
      valorTarifa: valorTarifa,
      dataInicio: dataInicio,
      dataFim: dataFim,
    );
  }


}