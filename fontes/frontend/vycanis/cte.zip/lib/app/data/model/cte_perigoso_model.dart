import 'dart:convert';
import 'package:pluto_grid/pluto_grid.dart';
import 'package:cte/app/data/model/model_imports.dart';


class CtePerigosoModel extends ModelBase {
  int? id;
  int? idCteCabecalho;
  String? numeroOnu;
  String? nomeApropriado;
  String? classeRisco;
  String? grupoEmbalagem;
  String? quantidadeTotalProduto;
  String? quantidadeTipoVolume;
  String? pontoFulgor;

  CtePerigosoModel({
    this.id,
    this.idCteCabecalho,
    this.numeroOnu,
    this.nomeApropriado,
    this.classeRisco,
    this.grupoEmbalagem,
    this.quantidadeTotalProduto,
    this.quantidadeTipoVolume,
    this.pontoFulgor,
  });

  static List<String> dbColumns = <String>[
    'id',
    'numero_onu',
    'nome_apropriado',
    'classe_risco',
    'grupo_embalagem',
    'quantidade_total_produto',
    'quantidade_tipo_volume',
    'ponto_fulgor',
  ];

  static List<String> aliasColumns = <String>[
    'Id',
    'Numero Onu',
    'Nome Apropriado',
    'Classe Risco',
    'Grupo Embalagem',
    'Quantidade Total Produto',
    'Quantidade Tipo Volume',
    'Ponto Fulgor',
  ];

  CtePerigosoModel.fromJson(Map<String, dynamic> jsonData) {
    id = jsonData['id'];
    idCteCabecalho = jsonData['idCteCabecalho'];
    numeroOnu = jsonData['numeroOnu'];
    nomeApropriado = jsonData['nomeApropriado'];
    classeRisco = jsonData['classeRisco'];
    grupoEmbalagem = jsonData['grupoEmbalagem'];
    quantidadeTotalProduto = jsonData['quantidadeTotalProduto'];
    quantidadeTipoVolume = jsonData['quantidadeTipoVolume'];
    pontoFulgor = jsonData['pontoFulgor'];
  }

  Map<String, dynamic> get toJson {
    Map<String, dynamic> jsonData = <String, dynamic>{};

    jsonData['id'] = id != 0 ? id : null;
    jsonData['idCteCabecalho'] = idCteCabecalho != 0 ? idCteCabecalho : null;
    jsonData['numeroOnu'] = numeroOnu;
    jsonData['nomeApropriado'] = nomeApropriado;
    jsonData['classeRisco'] = classeRisco;
    jsonData['grupoEmbalagem'] = grupoEmbalagem;
    jsonData['quantidadeTotalProduto'] = quantidadeTotalProduto;
    jsonData['quantidadeTipoVolume'] = quantidadeTipoVolume;
    jsonData['pontoFulgor'] = pontoFulgor;

    return jsonData;
  }

  String objectEncodeJson() {
    final jsonData = toJson;
    return json.encode(jsonData);
  }

  static CtePerigosoModel fromPlutoRow(PlutoRow row) {
    return CtePerigosoModel(
      id: row.cells['id']?.value,
      idCteCabecalho: row.cells['idCteCabecalho']?.value,
      numeroOnu: row.cells['numeroOnu']?.value,
      nomeApropriado: row.cells['nomeApropriado']?.value,
      classeRisco: row.cells['classeRisco']?.value,
      grupoEmbalagem: row.cells['grupoEmbalagem']?.value,
      quantidadeTotalProduto: row.cells['quantidadeTotalProduto']?.value,
      quantidadeTipoVolume: row.cells['quantidadeTipoVolume']?.value,
      pontoFulgor: row.cells['pontoFulgor']?.value,
    );
  }

  PlutoRow toPlutoRow() {
    return PlutoRow(
      cells: {
        'tempId': PlutoCell(value: tempId),
        'id': PlutoCell(value: id ?? 0),
        'idCteCabecalho': PlutoCell(value: idCteCabecalho ?? 0),
        'numeroOnu': PlutoCell(value: numeroOnu ?? ''),
        'nomeApropriado': PlutoCell(value: nomeApropriado ?? ''),
        'classeRisco': PlutoCell(value: classeRisco ?? ''),
        'grupoEmbalagem': PlutoCell(value: grupoEmbalagem ?? ''),
        'quantidadeTotalProduto': PlutoCell(value: quantidadeTotalProduto ?? ''),
        'quantidadeTipoVolume': PlutoCell(value: quantidadeTipoVolume ?? ''),
        'pontoFulgor': PlutoCell(value: pontoFulgor ?? ''),
      },
    );
  }

  CtePerigosoModel clone() {
    return CtePerigosoModel(
      id: id,
      idCteCabecalho: idCteCabecalho,
      numeroOnu: numeroOnu,
      nomeApropriado: nomeApropriado,
      classeRisco: classeRisco,
      grupoEmbalagem: grupoEmbalagem,
      quantidadeTotalProduto: quantidadeTotalProduto,
      quantidadeTipoVolume: quantidadeTipoVolume,
      pontoFulgor: pontoFulgor,
    );
  }


}