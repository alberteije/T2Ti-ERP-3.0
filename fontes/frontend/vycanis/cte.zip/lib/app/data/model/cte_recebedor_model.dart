import 'dart:convert';
import 'package:pluto_grid/pluto_grid.dart';
import 'package:cte/app/data/model/model_imports.dart';

import 'package:cte/app/infra/infra_imports.dart';
import 'package:cte/app/data/domain/domain_imports.dart';

class CteRecebedorModel extends ModelBase {
  int? id;
  int? idCteCabecalho;
  String? cnpj;
  String? cpf;
  String? ie;
  String? nome;
  String? fantasia;
  String? telefone;
  String? logradouro;
  String? numero;
  String? complemento;
  String? bairro;
  int? codigoMunicipio;
  String? nomeMunicipio;
  String? uf;
  String? cep;
  int? codigoPais;
  String? nomePais;
  String? email;

  CteRecebedorModel({
    this.id,
    this.idCteCabecalho,
    this.cnpj,
    this.cpf,
    this.ie,
    this.nome,
    this.fantasia,
    this.telefone,
    this.logradouro,
    this.numero,
    this.complemento,
    this.bairro,
    this.codigoMunicipio,
    this.nomeMunicipio,
    this.uf = 'AC',
    this.cep,
    this.codigoPais,
    this.nomePais,
    this.email,
  });

  static List<String> dbColumns = <String>[
    'id',
    'cnpj',
    'cpf',
    'ie',
    'nome',
    'fantasia',
    'telefone',
    'logradouro',
    'numero',
    'complemento',
    'bairro',
    'codigo_municipio',
    'nome_municipio',
    'uf',
    'cep',
    'codigo_pais',
    'nome_pais',
    'email',
  ];

  static List<String> aliasColumns = <String>[
    'Id',
    'Cnpj',
    'Cpf',
    'Ie',
    'Nome',
    'Fantasia',
    'Telefone',
    'Logradouro',
    'Numero',
    'Complemento',
    'Bairro',
    'Codigo Municipio',
    'Nome Municipio',
    'Uf',
    'Cep',
    'Codigo Pais',
    'Nome Pais',
    'Email',
  ];

  CteRecebedorModel.fromJson(Map<String, dynamic> jsonData) {
    id = jsonData['id'];
    idCteCabecalho = jsonData['idCteCabecalho'];
    cnpj = jsonData['cnpj'];
    cpf = jsonData['cpf'];
    ie = jsonData['ie'];
    nome = jsonData['nome'];
    fantasia = jsonData['fantasia'];
    telefone = jsonData['telefone'];
    logradouro = jsonData['logradouro'];
    numero = jsonData['numero'];
    complemento = jsonData['complemento'];
    bairro = jsonData['bairro'];
    codigoMunicipio = jsonData['codigoMunicipio'];
    nomeMunicipio = jsonData['nomeMunicipio'];
    uf = CteRecebedorDomain.getUf(jsonData['uf']);
    cep = jsonData['cep'];
    codigoPais = jsonData['codigoPais'];
    nomePais = jsonData['nomePais'];
    email = jsonData['email'];
  }

  Map<String, dynamic> get toJson {
    Map<String, dynamic> jsonData = <String, dynamic>{};

    jsonData['id'] = id != 0 ? id : null;
    jsonData['idCteCabecalho'] = idCteCabecalho != 0 ? idCteCabecalho : null;
    jsonData['cnpj'] = Util.removeMask(cnpj);
    jsonData['cpf'] = Util.removeMask(cpf);
    jsonData['ie'] = ie;
    jsonData['nome'] = nome;
    jsonData['fantasia'] = fantasia;
    jsonData['telefone'] = telefone;
    jsonData['logradouro'] = logradouro;
    jsonData['numero'] = numero;
    jsonData['complemento'] = complemento;
    jsonData['bairro'] = bairro;
    jsonData['codigoMunicipio'] = codigoMunicipio;
    jsonData['nomeMunicipio'] = nomeMunicipio;
    jsonData['uf'] = CteRecebedorDomain.setUf(uf);
    jsonData['cep'] = Util.removeMask(cep);
    jsonData['codigoPais'] = codigoPais;
    jsonData['nomePais'] = nomePais;
    jsonData['email'] = email;

    return jsonData;
  }

  String objectEncodeJson() {
    final jsonData = toJson;
    return json.encode(jsonData);
  }

  static CteRecebedorModel fromPlutoRow(PlutoRow row) {
    return CteRecebedorModel(
      id: row.cells['id']?.value,
      idCteCabecalho: row.cells['idCteCabecalho']?.value,
      cnpj: row.cells['cnpj']?.value,
      cpf: row.cells['cpf']?.value,
      ie: row.cells['ie']?.value,
      nome: row.cells['nome']?.value,
      fantasia: row.cells['fantasia']?.value,
      telefone: row.cells['telefone']?.value,
      logradouro: row.cells['logradouro']?.value,
      numero: row.cells['numero']?.value,
      complemento: row.cells['complemento']?.value,
      bairro: row.cells['bairro']?.value,
      codigoMunicipio: row.cells['codigoMunicipio']?.value,
      nomeMunicipio: row.cells['nomeMunicipio']?.value,
      uf: row.cells['uf']?.value,
      cep: row.cells['cep']?.value,
      codigoPais: row.cells['codigoPais']?.value,
      nomePais: row.cells['nomePais']?.value,
      email: row.cells['email']?.value,
    );
  }

  PlutoRow toPlutoRow() {
    return PlutoRow(
      cells: {
        'tempId': PlutoCell(value: tempId),
        'id': PlutoCell(value: id ?? 0),
        'idCteCabecalho': PlutoCell(value: idCteCabecalho ?? 0),
        'cnpj': PlutoCell(value: cnpj ?? ''),
        'cpf': PlutoCell(value: cpf ?? ''),
        'ie': PlutoCell(value: ie ?? ''),
        'nome': PlutoCell(value: nome ?? ''),
        'fantasia': PlutoCell(value: fantasia ?? ''),
        'telefone': PlutoCell(value: telefone ?? ''),
        'logradouro': PlutoCell(value: logradouro ?? ''),
        'numero': PlutoCell(value: numero ?? ''),
        'complemento': PlutoCell(value: complemento ?? ''),
        'bairro': PlutoCell(value: bairro ?? ''),
        'codigoMunicipio': PlutoCell(value: codigoMunicipio ?? 0),
        'nomeMunicipio': PlutoCell(value: nomeMunicipio ?? ''),
        'uf': PlutoCell(value: uf ?? ''),
        'cep': PlutoCell(value: cep ?? ''),
        'codigoPais': PlutoCell(value: codigoPais ?? 0),
        'nomePais': PlutoCell(value: nomePais ?? ''),
        'email': PlutoCell(value: email ?? ''),
      },
    );
  }

  CteRecebedorModel clone() {
    return CteRecebedorModel(
      id: id,
      idCteCabecalho: idCteCabecalho,
      cnpj: cnpj,
      cpf: cpf,
      ie: ie,
      nome: nome,
      fantasia: fantasia,
      telefone: telefone,
      logradouro: logradouro,
      numero: numero,
      complemento: complemento,
      bairro: bairro,
      codigoMunicipio: codigoMunicipio,
      nomeMunicipio: nomeMunicipio,
      uf: uf,
      cep: cep,
      codigoPais: codigoPais,
      nomePais: nomePais,
      email: email,
    );
  }


}