import 'dart:convert';
import 'package:pluto_grid/pluto_grid.dart';
import 'package:cte/app/data/model/model_imports.dart';

import 'package:cte/app/infra/infra_imports.dart';
import 'package:intl/intl.dart';

class CteInformacaoNfOutrosModel extends ModelBase {
  int? id;
  int? idCteCabecalho;
  String? numeroRomaneio;
  String? numeroPedido;
  String? chaveAcessoNfe;
  String? codigoModelo;
  String? serie;
  String? numero;
  DateTime? dataEmissao;
  int? ufEmitente;
  double? baseCalculoIcms;
  double? valorIcms;
  double? baseCalculoIcmsSt;
  double? valorIcmsSt;
  double? valorTotalProdutos;
  double? valorTotal;
  int? cfopPredominante;
  double? pesoTotalKg;
  int? pinSuframa;
  DateTime? dataPrevistaEntrega;
  String? outroTipoDocOrig;
  String? outroDescricao;
  double? outroValorDocumento;

  CteInformacaoNfOutrosModel({
    this.id,
    this.idCteCabecalho,
    this.numeroRomaneio,
    this.numeroPedido,
    this.chaveAcessoNfe,
    this.codigoModelo,
    this.serie,
    this.numero,
    this.dataEmissao,
    this.ufEmitente,
    this.baseCalculoIcms,
    this.valorIcms,
    this.baseCalculoIcmsSt,
    this.valorIcmsSt,
    this.valorTotalProdutos,
    this.valorTotal,
    this.cfopPredominante,
    this.pesoTotalKg,
    this.pinSuframa,
    this.dataPrevistaEntrega,
    this.outroTipoDocOrig,
    this.outroDescricao,
    this.outroValorDocumento,
  });

  static List<String> dbColumns = <String>[
    'id',
    'numero_romaneio',
    'numero_pedido',
    'chave_acesso_nfe',
    'codigo_modelo',
    'serie',
    'numero',
    'data_emissao',
    'uf_emitente',
    'base_calculo_icms',
    'valor_icms',
    'base_calculo_icms_st',
    'valor_icms_st',
    'valor_total_produtos',
    'valor_total',
    'cfop_predominante',
    'peso_total_kg',
    'pin_suframa',
    'data_prevista_entrega',
    'outro_tipo_doc_orig',
    'outro_descricao',
    'outro_valor_documento',
  ];

  static List<String> aliasColumns = <String>[
    'Id',
    'Numero Romaneio',
    'Numero Pedido',
    'Chave Acesso Nfe',
    'Codigo Modelo',
    'Serie',
    'Numero',
    'Data Emissao',
    'Uf Emitente',
    'Base Calculo Icms',
    'Valor Icms',
    'Base Calculo Icms St',
    'Valor Icms St',
    'Valor Total Produtos',
    'Valor Total',
    'Cfop Predominante',
    'Peso Total Kg',
    'Pin Suframa',
    'Data Prevista Entrega',
    'Outro Tipo Doc Orig',
    'Outro Descricao',
    'Outro Valor Documento',
  ];

  CteInformacaoNfOutrosModel.fromJson(Map<String, dynamic> jsonData) {
    id = jsonData['id'];
    idCteCabecalho = jsonData['idCteCabecalho'];
    numeroRomaneio = jsonData['numeroRomaneio'];
    numeroPedido = jsonData['numeroPedido'];
    chaveAcessoNfe = jsonData['chaveAcessoNfe'];
    codigoModelo = jsonData['codigoModelo'];
    serie = jsonData['serie'];
    numero = jsonData['numero'];
    dataEmissao = jsonData['dataEmissao'] != null ? DateTime.tryParse(jsonData['dataEmissao']) : null;
    ufEmitente = jsonData['ufEmitente'];
    baseCalculoIcms = jsonData['baseCalculoIcms']?.toDouble();
    valorIcms = jsonData['valorIcms']?.toDouble();
    baseCalculoIcmsSt = jsonData['baseCalculoIcmsSt']?.toDouble();
    valorIcmsSt = jsonData['valorIcmsSt']?.toDouble();
    valorTotalProdutos = jsonData['valorTotalProdutos']?.toDouble();
    valorTotal = jsonData['valorTotal']?.toDouble();
    cfopPredominante = jsonData['cfopPredominante'];
    pesoTotalKg = jsonData['pesoTotalKg']?.toDouble();
    pinSuframa = jsonData['pinSuframa'];
    dataPrevistaEntrega = jsonData['dataPrevistaEntrega'] != null ? DateTime.tryParse(jsonData['dataPrevistaEntrega']) : null;
    outroTipoDocOrig = jsonData['outroTipoDocOrig'];
    outroDescricao = jsonData['outroDescricao'];
    outroValorDocumento = jsonData['outroValorDocumento']?.toDouble();
  }

  Map<String, dynamic> get toJson {
    Map<String, dynamic> jsonData = <String, dynamic>{};

    jsonData['id'] = id != 0 ? id : null;
    jsonData['idCteCabecalho'] = idCteCabecalho != 0 ? idCteCabecalho : null;
    jsonData['numeroRomaneio'] = numeroRomaneio;
    jsonData['numeroPedido'] = numeroPedido;
    jsonData['chaveAcessoNfe'] = chaveAcessoNfe;
    jsonData['codigoModelo'] = codigoModelo;
    jsonData['serie'] = serie;
    jsonData['numero'] = numero;
    jsonData['dataEmissao'] = dataEmissao != null ? DateFormat('yyyy-MM-ddT00:00:00').format(dataEmissao!) : null;
    jsonData['ufEmitente'] = ufEmitente;
    jsonData['baseCalculoIcms'] = baseCalculoIcms;
    jsonData['valorIcms'] = valorIcms;
    jsonData['baseCalculoIcmsSt'] = baseCalculoIcmsSt;
    jsonData['valorIcmsSt'] = valorIcmsSt;
    jsonData['valorTotalProdutos'] = valorTotalProdutos;
    jsonData['valorTotal'] = valorTotal;
    jsonData['cfopPredominante'] = cfopPredominante;
    jsonData['pesoTotalKg'] = pesoTotalKg;
    jsonData['pinSuframa'] = pinSuframa;
    jsonData['dataPrevistaEntrega'] = dataPrevistaEntrega != null ? DateFormat('yyyy-MM-ddT00:00:00').format(dataPrevistaEntrega!) : null;
    jsonData['outroTipoDocOrig'] = outroTipoDocOrig;
    jsonData['outroDescricao'] = outroDescricao;
    jsonData['outroValorDocumento'] = outroValorDocumento;

    return jsonData;
  }

  String objectEncodeJson() {
    final jsonData = toJson;
    return json.encode(jsonData);
  }

  static CteInformacaoNfOutrosModel fromPlutoRow(PlutoRow row) {
    return CteInformacaoNfOutrosModel(
      id: row.cells['id']?.value,
      idCteCabecalho: row.cells['idCteCabecalho']?.value,
      numeroRomaneio: row.cells['numeroRomaneio']?.value,
      numeroPedido: row.cells['numeroPedido']?.value,
      chaveAcessoNfe: row.cells['chaveAcessoNfe']?.value,
      codigoModelo: row.cells['codigoModelo']?.value,
      serie: row.cells['serie']?.value,
      numero: row.cells['numero']?.value,
      dataEmissao: Util.stringToDate(row.cells['dataEmissao']?.value),
      ufEmitente: row.cells['ufEmitente']?.value,
      baseCalculoIcms: row.cells['baseCalculoIcms']?.value,
      valorIcms: row.cells['valorIcms']?.value,
      baseCalculoIcmsSt: row.cells['baseCalculoIcmsSt']?.value,
      valorIcmsSt: row.cells['valorIcmsSt']?.value,
      valorTotalProdutos: row.cells['valorTotalProdutos']?.value,
      valorTotal: row.cells['valorTotal']?.value,
      cfopPredominante: row.cells['cfopPredominante']?.value,
      pesoTotalKg: row.cells['pesoTotalKg']?.value,
      pinSuframa: row.cells['pinSuframa']?.value,
      dataPrevistaEntrega: Util.stringToDate(row.cells['dataPrevistaEntrega']?.value),
      outroTipoDocOrig: row.cells['outroTipoDocOrig']?.value,
      outroDescricao: row.cells['outroDescricao']?.value,
      outroValorDocumento: row.cells['outroValorDocumento']?.value,
    );
  }

  PlutoRow toPlutoRow() {
    return PlutoRow(
      cells: {
        'tempId': PlutoCell(value: tempId),
        'id': PlutoCell(value: id ?? 0),
        'idCteCabecalho': PlutoCell(value: idCteCabecalho ?? 0),
        'numeroRomaneio': PlutoCell(value: numeroRomaneio ?? ''),
        'numeroPedido': PlutoCell(value: numeroPedido ?? ''),
        'chaveAcessoNfe': PlutoCell(value: chaveAcessoNfe ?? ''),
        'codigoModelo': PlutoCell(value: codigoModelo ?? ''),
        'serie': PlutoCell(value: serie ?? ''),
        'numero': PlutoCell(value: numero ?? ''),
        'dataEmissao': PlutoCell(value: dataEmissao),
        'ufEmitente': PlutoCell(value: ufEmitente ?? 0),
        'baseCalculoIcms': PlutoCell(value: baseCalculoIcms ?? 0.0),
        'valorIcms': PlutoCell(value: valorIcms ?? 0.0),
        'baseCalculoIcmsSt': PlutoCell(value: baseCalculoIcmsSt ?? 0.0),
        'valorIcmsSt': PlutoCell(value: valorIcmsSt ?? 0.0),
        'valorTotalProdutos': PlutoCell(value: valorTotalProdutos ?? 0.0),
        'valorTotal': PlutoCell(value: valorTotal ?? 0.0),
        'cfopPredominante': PlutoCell(value: cfopPredominante ?? 0),
        'pesoTotalKg': PlutoCell(value: pesoTotalKg ?? 0.0),
        'pinSuframa': PlutoCell(value: pinSuframa ?? 0),
        'dataPrevistaEntrega': PlutoCell(value: dataPrevistaEntrega),
        'outroTipoDocOrig': PlutoCell(value: outroTipoDocOrig ?? ''),
        'outroDescricao': PlutoCell(value: outroDescricao ?? ''),
        'outroValorDocumento': PlutoCell(value: outroValorDocumento ?? 0.0),
      },
    );
  }

  CteInformacaoNfOutrosModel clone() {
    return CteInformacaoNfOutrosModel(
      id: id,
      idCteCabecalho: idCteCabecalho,
      numeroRomaneio: numeroRomaneio,
      numeroPedido: numeroPedido,
      chaveAcessoNfe: chaveAcessoNfe,
      codigoModelo: codigoModelo,
      serie: serie,
      numero: numero,
      dataEmissao: dataEmissao,
      ufEmitente: ufEmitente,
      baseCalculoIcms: baseCalculoIcms,
      valorIcms: valorIcms,
      baseCalculoIcmsSt: baseCalculoIcmsSt,
      valorIcmsSt: valorIcmsSt,
      valorTotalProdutos: valorTotalProdutos,
      valorTotal: valorTotal,
      cfopPredominante: cfopPredominante,
      pesoTotalKg: pesoTotalKg,
      pinSuframa: pinSuframa,
      dataPrevistaEntrega: dataPrevistaEntrega,
      outroTipoDocOrig: outroTipoDocOrig,
      outroDescricao: outroDescricao,
      outroValorDocumento: outroValorDocumento,
    );
  }


}