import 'dart:convert';
import 'package:pluto_grid/pluto_grid.dart';
import 'package:cte/app/data/model/model_imports.dart';

import 'package:cte/app/data/domain/domain_imports.dart';

class CteAquaviarioBalsaModel extends ModelBase {
  int? id;
  int? idCteAquaviario;
  String? idBalsa;
  int? numeroViagem;
  String? direcao;
  String? portoEmbarque;
  String? portoTransbordo;
  String? portoDestino;
  String? tipoNavegacao;
  String? irin;
  CteAquaviarioModel? cteAquaviarioModel;

  CteAquaviarioBalsaModel({
    this.id,
    this.idCteAquaviario,
    this.idBalsa,
    this.numeroViagem,
    this.direcao = 'N-Norte',
    this.portoEmbarque,
    this.portoTransbordo,
    this.portoDestino,
    this.tipoNavegacao = '0-Interior',
    this.irin,
    CteAquaviarioModel? cteAquaviarioModel,
  }) {
    this.cteAquaviarioModel = cteAquaviarioModel ?? CteAquaviarioModel();
  }

  static List<String> dbColumns = <String>[
    'id',
    'id_balsa',
    'numero_viagem',
    'direcao',
    'porto_embarque',
    'porto_transbordo',
    'porto_destino',
    'tipo_navegacao',
    'irin',
  ];

  static List<String> aliasColumns = <String>[
    'Id',
    'Id Balsa',
    'Numero Viagem',
    'Direcao',
    'Porto Embarque',
    'Porto Transbordo',
    'Porto Destino',
    'Tipo Navegacao',
    'Irin',
  ];

  CteAquaviarioBalsaModel.fromJson(Map<String, dynamic> jsonData) {
    id = jsonData['id'];
    idCteAquaviario = jsonData['idCteAquaviario'];
    idBalsa = jsonData['idBalsa'];
    numeroViagem = jsonData['numeroViagem'];
    direcao = CteAquaviarioBalsaDomain.getDirecao(jsonData['direcao']);
    portoEmbarque = jsonData['portoEmbarque'];
    portoTransbordo = jsonData['portoTransbordo'];
    portoDestino = jsonData['portoDestino'];
    tipoNavegacao = CteAquaviarioBalsaDomain.getTipoNavegacao(jsonData['tipoNavegacao']);
    irin = jsonData['irin'];
    cteAquaviarioModel = jsonData['cteAquaviarioModel'] == null ? CteAquaviarioModel() : CteAquaviarioModel.fromJson(jsonData['cteAquaviarioModel']);
  }

  Map<String, dynamic> get toJson {
    Map<String, dynamic> jsonData = <String, dynamic>{};

    jsonData['id'] = id != 0 ? id : null;
    jsonData['idCteAquaviario'] = idCteAquaviario != 0 ? idCteAquaviario : null;
    jsonData['idBalsa'] = idBalsa;
    jsonData['numeroViagem'] = numeroViagem;
    jsonData['direcao'] = CteAquaviarioBalsaDomain.setDirecao(direcao);
    jsonData['portoEmbarque'] = portoEmbarque;
    jsonData['portoTransbordo'] = portoTransbordo;
    jsonData['portoDestino'] = portoDestino;
    jsonData['tipoNavegacao'] = CteAquaviarioBalsaDomain.setTipoNavegacao(tipoNavegacao);
    jsonData['irin'] = irin;
    jsonData['cteAquaviarioModel'] = cteAquaviarioModel?.toJson;
    jsonData['cteAquaviario'] = cteAquaviarioModel?.numeroControle ?? '';

    return jsonData;
  }

  String objectEncodeJson() {
    final jsonData = toJson;
    return json.encode(jsonData);
  }

  static CteAquaviarioBalsaModel fromPlutoRow(PlutoRow row) {
    return CteAquaviarioBalsaModel(
      id: row.cells['id']?.value,
      idCteAquaviario: row.cells['idCteAquaviario']?.value,
      idBalsa: row.cells['idBalsa']?.value,
      numeroViagem: row.cells['numeroViagem']?.value,
      direcao: row.cells['direcao']?.value,
      portoEmbarque: row.cells['portoEmbarque']?.value,
      portoTransbordo: row.cells['portoTransbordo']?.value,
      portoDestino: row.cells['portoDestino']?.value,
      tipoNavegacao: row.cells['tipoNavegacao']?.value,
      irin: row.cells['irin']?.value,
    );
  }

  PlutoRow toPlutoRow() {
    return PlutoRow(
      cells: {
        'tempId': PlutoCell(value: tempId),
        'id': PlutoCell(value: id ?? 0),
        'idCteAquaviario': PlutoCell(value: idCteAquaviario ?? 0),
        'idBalsa': PlutoCell(value: idBalsa ?? ''),
        'numeroViagem': PlutoCell(value: numeroViagem ?? 0),
        'direcao': PlutoCell(value: direcao ?? ''),
        'portoEmbarque': PlutoCell(value: portoEmbarque ?? ''),
        'portoTransbordo': PlutoCell(value: portoTransbordo ?? ''),
        'portoDestino': PlutoCell(value: portoDestino ?? ''),
        'tipoNavegacao': PlutoCell(value: tipoNavegacao ?? ''),
        'irin': PlutoCell(value: irin ?? ''),
        'cteAquaviario': PlutoCell(value: cteAquaviarioModel?.numeroControle ?? ''),
      },
    );
  }

  CteAquaviarioBalsaModel clone() {
    return CteAquaviarioBalsaModel(
      id: id,
      idCteAquaviario: idCteAquaviario,
      idBalsa: idBalsa,
      numeroViagem: numeroViagem,
      direcao: direcao,
      portoEmbarque: portoEmbarque,
      portoTransbordo: portoTransbordo,
      portoDestino: portoDestino,
      tipoNavegacao: tipoNavegacao,
      irin: irin,
      cteAquaviarioModel: cteAquaviarioModel?.clone(),
    );
  }


}