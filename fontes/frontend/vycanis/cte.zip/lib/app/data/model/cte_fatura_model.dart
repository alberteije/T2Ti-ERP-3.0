import 'dart:convert';
import 'package:pluto_grid/pluto_grid.dart';
import 'package:cte/app/data/model/model_imports.dart';


class CteFaturaModel extends ModelBase {
  int? id;
  int? idCteCabecalho;
  String? numero;
  double? valorOriginal;
  double? valorDesconto;
  double? valorLiquido;

  CteFaturaModel({
    this.id,
    this.idCteCabecalho,
    this.numero,
    this.valorOriginal,
    this.valorDesconto,
    this.valorLiquido,
  });

  static List<String> dbColumns = <String>[
    'id',
    'numero',
    'valor_original',
    'valor_desconto',
    'valor_liquido',
  ];

  static List<String> aliasColumns = <String>[
    'Id',
    'Numero',
    'Valor Original',
    'Valor Desconto',
    'Valor Liquido',
  ];

  CteFaturaModel.fromJson(Map<String, dynamic> jsonData) {
    id = jsonData['id'];
    idCteCabecalho = jsonData['idCteCabecalho'];
    numero = jsonData['numero'];
    valorOriginal = jsonData['valorOriginal']?.toDouble();
    valorDesconto = jsonData['valorDesconto']?.toDouble();
    valorLiquido = jsonData['valorLiquido']?.toDouble();
  }

  Map<String, dynamic> get toJson {
    Map<String, dynamic> jsonData = <String, dynamic>{};

    jsonData['id'] = id != 0 ? id : null;
    jsonData['idCteCabecalho'] = idCteCabecalho != 0 ? idCteCabecalho : null;
    jsonData['numero'] = numero;
    jsonData['valorOriginal'] = valorOriginal;
    jsonData['valorDesconto'] = valorDesconto;
    jsonData['valorLiquido'] = valorLiquido;

    return jsonData;
  }

  String objectEncodeJson() {
    final jsonData = toJson;
    return json.encode(jsonData);
  }

  static CteFaturaModel fromPlutoRow(PlutoRow row) {
    return CteFaturaModel(
      id: row.cells['id']?.value,
      idCteCabecalho: row.cells['idCteCabecalho']?.value,
      numero: row.cells['numero']?.value,
      valorOriginal: row.cells['valorOriginal']?.value,
      valorDesconto: row.cells['valorDesconto']?.value,
      valorLiquido: row.cells['valorLiquido']?.value,
    );
  }

  PlutoRow toPlutoRow() {
    return PlutoRow(
      cells: {
        'tempId': PlutoCell(value: tempId),
        'id': PlutoCell(value: id ?? 0),
        'idCteCabecalho': PlutoCell(value: idCteCabecalho ?? 0),
        'numero': PlutoCell(value: numero ?? ''),
        'valorOriginal': PlutoCell(value: valorOriginal ?? 0.0),
        'valorDesconto': PlutoCell(value: valorDesconto ?? 0.0),
        'valorLiquido': PlutoCell(value: valorLiquido ?? 0.0),
      },
    );
  }

  CteFaturaModel clone() {
    return CteFaturaModel(
      id: id,
      idCteCabecalho: idCteCabecalho,
      numero: numero,
      valorOriginal: valorOriginal,
      valorDesconto: valorDesconto,
      valorLiquido: valorLiquido,
    );
  }


}