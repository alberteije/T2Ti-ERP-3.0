import 'dart:convert';
import 'package:pluto_grid/pluto_grid.dart';
import 'package:cte/app/data/model/model_imports.dart';

import 'package:cte/app/data/domain/domain_imports.dart';

class CteSeguroModel extends ModelBase {
  int? id;
  int? idCteCabecalho;
  String? responsavel;
  String? seguradora;
  String? apolice;
  String? averbacao;
  double? valorCarga;

  CteSeguroModel({
    this.id,
    this.idCteCabecalho,
    this.responsavel = '4 - Emitente do CTe',
    this.seguradora,
    this.apolice,
    this.averbacao,
    this.valorCarga,
  });

  static List<String> dbColumns = <String>[
    'id',
    'responsavel',
    'seguradora',
    'apolice',
    'averbacao',
    'valor_carga',
  ];

  static List<String> aliasColumns = <String>[
    'Id',
    'Responsavel',
    'Seguradora',
    'Apolice',
    'Averbacao',
    'Valor Carga',
  ];

  CteSeguroModel.fromJson(Map<String, dynamic> jsonData) {
    id = jsonData['id'];
    idCteCabecalho = jsonData['idCteCabecalho'];
    responsavel = CteSeguroDomain.getResponsavel(jsonData['responsavel']);
    seguradora = jsonData['seguradora'];
    apolice = jsonData['apolice'];
    averbacao = jsonData['averbacao'];
    valorCarga = jsonData['valorCarga']?.toDouble();
  }

  Map<String, dynamic> get toJson {
    Map<String, dynamic> jsonData = <String, dynamic>{};

    jsonData['id'] = id != 0 ? id : null;
    jsonData['idCteCabecalho'] = idCteCabecalho != 0 ? idCteCabecalho : null;
    jsonData['responsavel'] = CteSeguroDomain.setResponsavel(responsavel);
    jsonData['seguradora'] = seguradora;
    jsonData['apolice'] = apolice;
    jsonData['averbacao'] = averbacao;
    jsonData['valorCarga'] = valorCarga;

    return jsonData;
  }

  String objectEncodeJson() {
    final jsonData = toJson;
    return json.encode(jsonData);
  }

  static CteSeguroModel fromPlutoRow(PlutoRow row) {
    return CteSeguroModel(
      id: row.cells['id']?.value,
      idCteCabecalho: row.cells['idCteCabecalho']?.value,
      responsavel: row.cells['responsavel']?.value,
      seguradora: row.cells['seguradora']?.value,
      apolice: row.cells['apolice']?.value,
      averbacao: row.cells['averbacao']?.value,
      valorCarga: row.cells['valorCarga']?.value,
    );
  }

  PlutoRow toPlutoRow() {
    return PlutoRow(
      cells: {
        'tempId': PlutoCell(value: tempId),
        'id': PlutoCell(value: id ?? 0),
        'idCteCabecalho': PlutoCell(value: idCteCabecalho ?? 0),
        'responsavel': PlutoCell(value: responsavel ?? ''),
        'seguradora': PlutoCell(value: seguradora ?? ''),
        'apolice': PlutoCell(value: apolice ?? ''),
        'averbacao': PlutoCell(value: averbacao ?? ''),
        'valorCarga': PlutoCell(value: valorCarga ?? 0.0),
      },
    );
  }

  CteSeguroModel clone() {
    return CteSeguroModel(
      id: id,
      idCteCabecalho: idCteCabecalho,
      responsavel: responsavel,
      seguradora: seguradora,
      apolice: apolice,
      averbacao: averbacao,
      valorCarga: valorCarga,
    );
  }


}