import 'dart:convert';
import 'package:pluto_grid/pluto_grid.dart';
import 'package:cte/app/data/model/model_imports.dart';


class CteInfNfCargaLacreModel extends ModelBase {
  int? id;
  int? idCteInformacaoNfCarga;
  String? numero;
  double? quantidadeRateada;
  CteInformacaoNfCargaModel? cteInformacaoNfCargaModel;

  CteInfNfCargaLacreModel({
    this.id,
    this.idCteInformacaoNfCarga,
    this.numero,
    this.quantidadeRateada,
    CteInformacaoNfCargaModel? cteInformacaoNfCargaModel,
  }) {
    this.cteInformacaoNfCargaModel = cteInformacaoNfCargaModel ?? CteInformacaoNfCargaModel();
  }

  static List<String> dbColumns = <String>[
    'id',
    'numero',
    'quantidade_rateada',
  ];

  static List<String> aliasColumns = <String>[
    'Id',
    'Numero',
    'Quantidade Rateada',
  ];

  CteInfNfCargaLacreModel.fromJson(Map<String, dynamic> jsonData) {
    id = jsonData['id'];
    idCteInformacaoNfCarga = jsonData['idCteInformacaoNfCarga'];
    numero = jsonData['numero'];
    quantidadeRateada = jsonData['quantidadeRateada']?.toDouble();
    cteInformacaoNfCargaModel = jsonData['cteInformacaoNfCargaModel'] == null ? CteInformacaoNfCargaModel() : CteInformacaoNfCargaModel.fromJson(jsonData['cteInformacaoNfCargaModel']);
  }

  Map<String, dynamic> get toJson {
    Map<String, dynamic> jsonData = <String, dynamic>{};

    jsonData['id'] = id != 0 ? id : null;
    jsonData['idCteInformacaoNfCarga'] = idCteInformacaoNfCarga != 0 ? idCteInformacaoNfCarga : null;
    jsonData['numero'] = numero;
    jsonData['quantidadeRateada'] = quantidadeRateada;
    jsonData['cteInformacaoNfCargaModel'] = cteInformacaoNfCargaModel?.toJson;
    jsonData['cteInformacaoNfCarga'] = cteInformacaoNfCargaModel?.tipoUnidadeCarga ?? '';

    return jsonData;
  }

  String objectEncodeJson() {
    final jsonData = toJson;
    return json.encode(jsonData);
  }

  static CteInfNfCargaLacreModel fromPlutoRow(PlutoRow row) {
    return CteInfNfCargaLacreModel(
      id: row.cells['id']?.value,
      idCteInformacaoNfCarga: row.cells['idCteInformacaoNfCarga']?.value,
      numero: row.cells['numero']?.value,
      quantidadeRateada: row.cells['quantidadeRateada']?.value,
    );
  }

  PlutoRow toPlutoRow() {
    return PlutoRow(
      cells: {
        'tempId': PlutoCell(value: tempId),
        'id': PlutoCell(value: id ?? 0),
        'idCteInformacaoNfCarga': PlutoCell(value: idCteInformacaoNfCarga ?? 0),
        'numero': PlutoCell(value: numero ?? ''),
        'quantidadeRateada': PlutoCell(value: quantidadeRateada ?? 0.0),
        'cteInformacaoNfCarga': PlutoCell(value: cteInformacaoNfCargaModel?.tipoUnidadeCarga ?? ''),
      },
    );
  }

  CteInfNfCargaLacreModel clone() {
    return CteInfNfCargaLacreModel(
      id: id,
      idCteInformacaoNfCarga: idCteInformacaoNfCarga,
      numero: numero,
      quantidadeRateada: quantidadeRateada,
      cteInformacaoNfCargaModel: cteInformacaoNfCargaModel?.clone(),
    );
  }


}