import 'dart:convert';
import 'package:pluto_grid/pluto_grid.dart';
import 'package:cte/app/data/model/model_imports.dart';


class CteAquaviarioModel extends ModelBase {
  int? id;
  int? idCteCabecalho;
  double? valorPrestacao;
  double? afrmm;
  String? numeroBooking;
  String? numeroControle;
  String? idNavio;

  CteAquaviarioModel({
    this.id,
    this.idCteCabecalho,
    this.valorPrestacao,
    this.afrmm,
    this.numeroBooking,
    this.numeroControle,
    this.idNavio,
  });

  static List<String> dbColumns = <String>[
    'id',
    'valor_prestacao',
    'afrmm',
    'numero_booking',
    'numero_controle',
    'id_navio',
  ];

  static List<String> aliasColumns = <String>[
    'Id',
    'Valor Prestacao',
    'Afrmm',
    'Numero Booking',
    'Numero Controle',
    'Id Navio',
  ];

  CteAquaviarioModel.fromJson(Map<String, dynamic> jsonData) {
    id = jsonData['id'];
    idCteCabecalho = jsonData['idCteCabecalho'];
    valorPrestacao = jsonData['valorPrestacao']?.toDouble();
    afrmm = jsonData['afrmm']?.toDouble();
    numeroBooking = jsonData['numeroBooking'];
    numeroControle = jsonData['numeroControle'];
    idNavio = jsonData['idNavio'];
  }

  Map<String, dynamic> get toJson {
    Map<String, dynamic> jsonData = <String, dynamic>{};

    jsonData['id'] = id != 0 ? id : null;
    jsonData['idCteCabecalho'] = idCteCabecalho != 0 ? idCteCabecalho : null;
    jsonData['valorPrestacao'] = valorPrestacao;
    jsonData['afrmm'] = afrmm;
    jsonData['numeroBooking'] = numeroBooking;
    jsonData['numeroControle'] = numeroControle;
    jsonData['idNavio'] = idNavio;

    return jsonData;
  }

  String objectEncodeJson() {
    final jsonData = toJson;
    return json.encode(jsonData);
  }

  static CteAquaviarioModel fromPlutoRow(PlutoRow row) {
    return CteAquaviarioModel(
      id: row.cells['id']?.value,
      idCteCabecalho: row.cells['idCteCabecalho']?.value,
      valorPrestacao: row.cells['valorPrestacao']?.value,
      afrmm: row.cells['afrmm']?.value,
      numeroBooking: row.cells['numeroBooking']?.value,
      numeroControle: row.cells['numeroControle']?.value,
      idNavio: row.cells['idNavio']?.value,
    );
  }

  PlutoRow toPlutoRow() {
    return PlutoRow(
      cells: {
        'tempId': PlutoCell(value: tempId),
        'id': PlutoCell(value: id ?? 0),
        'idCteCabecalho': PlutoCell(value: idCteCabecalho ?? 0),
        'valorPrestacao': PlutoCell(value: valorPrestacao ?? 0.0),
        'afrmm': PlutoCell(value: afrmm ?? 0.0),
        'numeroBooking': PlutoCell(value: numeroBooking ?? ''),
        'numeroControle': PlutoCell(value: numeroControle ?? ''),
        'idNavio': PlutoCell(value: idNavio ?? ''),
      },
    );
  }

  CteAquaviarioModel clone() {
    return CteAquaviarioModel(
      id: id,
      idCteCabecalho: idCteCabecalho,
      valorPrestacao: valorPrestacao,
      afrmm: afrmm,
      numeroBooking: numeroBooking,
      numeroControle: numeroControle,
      idNavio: idNavio,
    );
  }


}