import 'dart:convert';
import 'package:pluto_grid/pluto_grid.dart';
import 'package:cte/app/data/model/model_imports.dart';

import 'package:cte/app/infra/infra_imports.dart';

class CteRodoviarioPedagioModel extends ModelBase {
  int? id;
  int? idCteRodoviario;
  String? cnpjFornecedor;
  String? comprovanteCompra;
  String? cnpjResponsavel;
  double? valor;
  CteRodoviarioModel? cteRodoviarioModel;

  CteRodoviarioPedagioModel({
    this.id,
    this.idCteRodoviario,
    this.cnpjFornecedor,
    this.comprovanteCompra,
    this.cnpjResponsavel,
    this.valor,
    CteRodoviarioModel? cteRodoviarioModel,
  }) {
    this.cteRodoviarioModel = cteRodoviarioModel ?? CteRodoviarioModel();
  }

  static List<String> dbColumns = <String>[
    'id',
    'cnpj_fornecedor',
    'comprovante_compra',
    'cnpj_responsavel',
    'valor',
  ];

  static List<String> aliasColumns = <String>[
    'Id',
    'Cnpj Fornecedor',
    'Comprovante Compra',
    'Cnpj Responsavel',
    'Valor',
  ];

  CteRodoviarioPedagioModel.fromJson(Map<String, dynamic> jsonData) {
    id = jsonData['id'];
    idCteRodoviario = jsonData['idCteRodoviario'];
    cnpjFornecedor = jsonData['cnpjFornecedor'];
    comprovanteCompra = jsonData['comprovanteCompra'];
    cnpjResponsavel = jsonData['cnpjResponsavel'];
    valor = jsonData['valor']?.toDouble();
    cteRodoviarioModel = jsonData['cteRodoviarioModel'] == null ? CteRodoviarioModel() : CteRodoviarioModel.fromJson(jsonData['cteRodoviarioModel']);
  }

  Map<String, dynamic> get toJson {
    Map<String, dynamic> jsonData = <String, dynamic>{};

    jsonData['id'] = id != 0 ? id : null;
    jsonData['idCteRodoviario'] = idCteRodoviario != 0 ? idCteRodoviario : null;
    jsonData['cnpjFornecedor'] = Util.removeMask(cnpjFornecedor);
    jsonData['comprovanteCompra'] = comprovanteCompra;
    jsonData['cnpjResponsavel'] = Util.removeMask(cnpjResponsavel);
    jsonData['valor'] = valor;
    jsonData['cteRodoviarioModel'] = cteRodoviarioModel?.toJson;
    jsonData['cteRodoviario'] = cteRodoviarioModel?.rntrc ?? '';

    return jsonData;
  }

  String objectEncodeJson() {
    final jsonData = toJson;
    return json.encode(jsonData);
  }

  static CteRodoviarioPedagioModel fromPlutoRow(PlutoRow row) {
    return CteRodoviarioPedagioModel(
      id: row.cells['id']?.value,
      idCteRodoviario: row.cells['idCteRodoviario']?.value,
      cnpjFornecedor: row.cells['cnpjFornecedor']?.value,
      comprovanteCompra: row.cells['comprovanteCompra']?.value,
      cnpjResponsavel: row.cells['cnpjResponsavel']?.value,
      valor: row.cells['valor']?.value,
    );
  }

  PlutoRow toPlutoRow() {
    return PlutoRow(
      cells: {
        'tempId': PlutoCell(value: tempId),
        'id': PlutoCell(value: id ?? 0),
        'idCteRodoviario': PlutoCell(value: idCteRodoviario ?? 0),
        'cnpjFornecedor': PlutoCell(value: cnpjFornecedor ?? ''),
        'comprovanteCompra': PlutoCell(value: comprovanteCompra ?? ''),
        'cnpjResponsavel': PlutoCell(value: cnpjResponsavel ?? ''),
        'valor': PlutoCell(value: valor ?? 0.0),
        'cteRodoviario': PlutoCell(value: cteRodoviarioModel?.rntrc ?? ''),
      },
    );
  }

  CteRodoviarioPedagioModel clone() {
    return CteRodoviarioPedagioModel(
      id: id,
      idCteRodoviario: idCteRodoviario,
      cnpjFornecedor: cnpjFornecedor,
      comprovanteCompra: comprovanteCompra,
      cnpjResponsavel: cnpjResponsavel,
      valor: valor,
      cteRodoviarioModel: cteRodoviarioModel?.clone(),
    );
  }


}