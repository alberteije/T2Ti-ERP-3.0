import 'dart:convert';
import 'package:pluto_grid/pluto_grid.dart';
import 'package:cte/app/data/model/model_imports.dart';


class CteInfNfTransporteLacreModel extends ModelBase {
  int? id;
  int? idCteInformacaoNfTransporte;
  String? numero;
  CteInformacaoNfTransporteModel? cteInformacaoNfTransporteModel;

  CteInfNfTransporteLacreModel({
    this.id,
    this.idCteInformacaoNfTransporte,
    this.numero,
    CteInformacaoNfTransporteModel? cteInformacaoNfTransporteModel,
  }) {
    this.cteInformacaoNfTransporteModel = cteInformacaoNfTransporteModel ?? CteInformacaoNfTransporteModel();
  }

  static List<String> dbColumns = <String>[
    'id',
    'numero',
  ];

  static List<String> aliasColumns = <String>[
    'Id',
    'Numero',
  ];

  CteInfNfTransporteLacreModel.fromJson(Map<String, dynamic> jsonData) {
    id = jsonData['id'];
    idCteInformacaoNfTransporte = jsonData['idCteInformacaoNfTransporte'];
    numero = jsonData['numero'];
    cteInformacaoNfTransporteModel = jsonData['cteInformacaoNfTransporteModel'] == null ? CteInformacaoNfTransporteModel() : CteInformacaoNfTransporteModel.fromJson(jsonData['cteInformacaoNfTransporteModel']);
  }

  Map<String, dynamic> get toJson {
    Map<String, dynamic> jsonData = <String, dynamic>{};

    jsonData['id'] = id != 0 ? id : null;
    jsonData['idCteInformacaoNfTransporte'] = idCteInformacaoNfTransporte != 0 ? idCteInformacaoNfTransporte : null;
    jsonData['numero'] = numero;
    jsonData['cteInformacaoNfTransporteModel'] = cteInformacaoNfTransporteModel?.toJson;
    jsonData['cteInformacaoNfTransporte'] = cteInformacaoNfTransporteModel?.tipoUnidadeTransporte ?? '';

    return jsonData;
  }

  String objectEncodeJson() {
    final jsonData = toJson;
    return json.encode(jsonData);
  }

  static CteInfNfTransporteLacreModel fromPlutoRow(PlutoRow row) {
    return CteInfNfTransporteLacreModel(
      id: row.cells['id']?.value,
      idCteInformacaoNfTransporte: row.cells['idCteInformacaoNfTransporte']?.value,
      numero: row.cells['numero']?.value,
    );
  }

  PlutoRow toPlutoRow() {
    return PlutoRow(
      cells: {
        'tempId': PlutoCell(value: tempId),
        'id': PlutoCell(value: id ?? 0),
        'idCteInformacaoNfTransporte': PlutoCell(value: idCteInformacaoNfTransporte ?? 0),
        'numero': PlutoCell(value: numero ?? ''),
        'cteInformacaoNfTransporte': PlutoCell(value: cteInformacaoNfTransporteModel?.tipoUnidadeTransporte ?? ''),
      },
    );
  }

  CteInfNfTransporteLacreModel clone() {
    return CteInfNfTransporteLacreModel(
      id: id,
      idCteInformacaoNfTransporte: idCteInformacaoNfTransporte,
      numero: numero,
      cteInformacaoNfTransporteModel: cteInformacaoNfTransporteModel?.clone(),
    );
  }


}