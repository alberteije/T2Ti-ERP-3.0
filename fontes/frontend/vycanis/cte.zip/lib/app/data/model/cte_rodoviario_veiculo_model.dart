import 'dart:convert';
import 'package:pluto_grid/pluto_grid.dart';
import 'package:cte/app/data/model/model_imports.dart';

import 'package:cte/app/infra/infra_imports.dart';
import 'package:cte/app/data/domain/domain_imports.dart';

class CteRodoviarioVeiculoModel extends ModelBase {
  int? id;
  int? idCteRodoviario;
  String? codigoInterno;
  String? renavam;
  String? placa;
  int? tara;
  int? capacidadeKg;
  int? capacidadeM3;
  String? tipoPropriedade;
  String? tipoVeiculo;
  String? tipoRodado;
  String? tipoCarroceria;
  String? uf;
  String? proprietarioCpf;
  String? proprietarioCnpj;
  String? proprietarioRntrc;
  String? proprietarioNome;
  String? proprietarioIe;
  String? proprietarioUf;
  String? proprietarioTipo;
  CteRodoviarioModel? cteRodoviarioModel;

  CteRodoviarioVeiculoModel({
    this.id,
    this.idCteRodoviario,
    this.codigoInterno,
    this.renavam,
    this.placa,
    this.tara,
    this.capacidadeKg,
    this.capacidadeM3,
    this.tipoPropriedade,
    this.tipoVeiculo,
    this.tipoRodado,
    this.tipoCarroceria,
    this.uf = 'AC',
    this.proprietarioCpf,
    this.proprietarioCnpj,
    this.proprietarioRntrc,
    this.proprietarioNome,
    this.proprietarioIe,
    this.proprietarioUf = 'AC',
    this.proprietarioTipo = '0-TAC – Agregado',
    CteRodoviarioModel? cteRodoviarioModel,
  }) {
    this.cteRodoviarioModel = cteRodoviarioModel ?? CteRodoviarioModel();
  }

  static List<String> dbColumns = <String>[
    'id',
    'codigo_interno',
    'renavam',
    'placa',
    'tara',
    'capacidade_kg',
    'capacidade_m3',
    'tipo_propriedade',
    'tipo_veiculo',
    'tipo_rodado',
    'tipo_carroceria',
    'uf',
    'proprietario_cpf',
    'proprietario_cnpj',
    'proprietario_rntrc',
    'proprietario_nome',
    'proprietario_ie',
    'proprietario_uf',
    'proprietario_tipo',
  ];

  static List<String> aliasColumns = <String>[
    'Id',
    'Codigo Interno',
    'Renavam',
    'Placa',
    'Tara',
    'Capacidade Kg',
    'Capacidade M3',
    'Tipo Propriedade',
    'Tipo Veiculo',
    'Tipo Rodado',
    'Tipo Carroceria',
    'Uf',
    'Proprietario Cpf',
    'Proprietario Cnpj',
    'Proprietario Rntrc',
    'Proprietario Nome',
    'Proprietario Ie',
    'Proprietario Uf',
    'Proprietario Tipo',
  ];

  CteRodoviarioVeiculoModel.fromJson(Map<String, dynamic> jsonData) {
    id = jsonData['id'];
    idCteRodoviario = jsonData['idCteRodoviario'];
    codigoInterno = jsonData['codigoInterno'];
    renavam = jsonData['renavam'];
    placa = jsonData['placa'];
    tara = jsonData['tara'];
    capacidadeKg = jsonData['capacidadeKg'];
    capacidadeM3 = jsonData['capacidadeM3'];
    tipoPropriedade = jsonData['tipoPropriedade'];
    tipoVeiculo = jsonData['tipoVeiculo'];
    tipoRodado = jsonData['tipoRodado'];
    tipoCarroceria = jsonData['tipoCarroceria'];
    uf = CteRodoviarioVeiculoDomain.getUf(jsonData['uf']);
    proprietarioCpf = jsonData['proprietarioCpf'];
    proprietarioCnpj = jsonData['proprietarioCnpj'];
    proprietarioRntrc = jsonData['proprietarioRntrc'];
    proprietarioNome = jsonData['proprietarioNome'];
    proprietarioIe = jsonData['proprietarioIe'];
    proprietarioUf = CteRodoviarioVeiculoDomain.getProprietarioUf(jsonData['proprietarioUf']);
    proprietarioTipo = CteRodoviarioVeiculoDomain.getProprietarioTipo(jsonData['proprietarioTipo']);
    cteRodoviarioModel = jsonData['cteRodoviarioModel'] == null ? CteRodoviarioModel() : CteRodoviarioModel.fromJson(jsonData['cteRodoviarioModel']);
  }

  Map<String, dynamic> get toJson {
    Map<String, dynamic> jsonData = <String, dynamic>{};

    jsonData['id'] = id != 0 ? id : null;
    jsonData['idCteRodoviario'] = idCteRodoviario != 0 ? idCteRodoviario : null;
    jsonData['codigoInterno'] = codigoInterno;
    jsonData['renavam'] = renavam;
    jsonData['placa'] = placa;
    jsonData['tara'] = tara;
    jsonData['capacidadeKg'] = capacidadeKg;
    jsonData['capacidadeM3'] = capacidadeM3;
    jsonData['tipoPropriedade'] = tipoPropriedade;
    jsonData['tipoVeiculo'] = tipoVeiculo;
    jsonData['tipoRodado'] = tipoRodado;
    jsonData['tipoCarroceria'] = tipoCarroceria;
    jsonData['uf'] = CteRodoviarioVeiculoDomain.setUf(uf);
    jsonData['proprietarioCpf'] = Util.removeMask(proprietarioCpf);
    jsonData['proprietarioCnpj'] = Util.removeMask(proprietarioCnpj);
    jsonData['proprietarioRntrc'] = proprietarioRntrc;
    jsonData['proprietarioNome'] = proprietarioNome;
    jsonData['proprietarioIe'] = proprietarioIe;
    jsonData['proprietarioUf'] = CteRodoviarioVeiculoDomain.setProprietarioUf(proprietarioUf);
    jsonData['proprietarioTipo'] = CteRodoviarioVeiculoDomain.setProprietarioTipo(proprietarioTipo);
    jsonData['cteRodoviarioModel'] = cteRodoviarioModel?.toJson;
    jsonData['cteRodoviario'] = cteRodoviarioModel?.rntrc ?? '';

    return jsonData;
  }

  String objectEncodeJson() {
    final jsonData = toJson;
    return json.encode(jsonData);
  }

  static CteRodoviarioVeiculoModel fromPlutoRow(PlutoRow row) {
    return CteRodoviarioVeiculoModel(
      id: row.cells['id']?.value,
      idCteRodoviario: row.cells['idCteRodoviario']?.value,
      codigoInterno: row.cells['codigoInterno']?.value,
      renavam: row.cells['renavam']?.value,
      placa: row.cells['placa']?.value,
      tara: row.cells['tara']?.value,
      capacidadeKg: row.cells['capacidadeKg']?.value,
      capacidadeM3: row.cells['capacidadeM3']?.value,
      tipoPropriedade: row.cells['tipoPropriedade']?.value,
      tipoVeiculo: row.cells['tipoVeiculo']?.value,
      tipoRodado: row.cells['tipoRodado']?.value,
      tipoCarroceria: row.cells['tipoCarroceria']?.value,
      uf: row.cells['uf']?.value,
      proprietarioCpf: row.cells['proprietarioCpf']?.value,
      proprietarioCnpj: row.cells['proprietarioCnpj']?.value,
      proprietarioRntrc: row.cells['proprietarioRntrc']?.value,
      proprietarioNome: row.cells['proprietarioNome']?.value,
      proprietarioIe: row.cells['proprietarioIe']?.value,
      proprietarioUf: row.cells['proprietarioUf']?.value,
      proprietarioTipo: row.cells['proprietarioTipo']?.value,
    );
  }

  PlutoRow toPlutoRow() {
    return PlutoRow(
      cells: {
        'tempId': PlutoCell(value: tempId),
        'id': PlutoCell(value: id ?? 0),
        'idCteRodoviario': PlutoCell(value: idCteRodoviario ?? 0),
        'codigoInterno': PlutoCell(value: codigoInterno ?? ''),
        'renavam': PlutoCell(value: renavam ?? ''),
        'placa': PlutoCell(value: placa ?? ''),
        'tara': PlutoCell(value: tara ?? 0),
        'capacidadeKg': PlutoCell(value: capacidadeKg ?? 0),
        'capacidadeM3': PlutoCell(value: capacidadeM3 ?? 0),
        'tipoPropriedade': PlutoCell(value: tipoPropriedade ?? ''),
        'tipoVeiculo': PlutoCell(value: tipoVeiculo ?? ''),
        'tipoRodado': PlutoCell(value: tipoRodado ?? ''),
        'tipoCarroceria': PlutoCell(value: tipoCarroceria ?? ''),
        'uf': PlutoCell(value: uf ?? ''),
        'proprietarioCpf': PlutoCell(value: proprietarioCpf ?? ''),
        'proprietarioCnpj': PlutoCell(value: proprietarioCnpj ?? ''),
        'proprietarioRntrc': PlutoCell(value: proprietarioRntrc ?? ''),
        'proprietarioNome': PlutoCell(value: proprietarioNome ?? ''),
        'proprietarioIe': PlutoCell(value: proprietarioIe ?? ''),
        'proprietarioUf': PlutoCell(value: proprietarioUf ?? ''),
        'proprietarioTipo': PlutoCell(value: proprietarioTipo ?? ''),
        'cteRodoviario': PlutoCell(value: cteRodoviarioModel?.rntrc ?? ''),
      },
    );
  }

  CteRodoviarioVeiculoModel clone() {
    return CteRodoviarioVeiculoModel(
      id: id,
      idCteRodoviario: idCteRodoviario,
      codigoInterno: codigoInterno,
      renavam: renavam,
      placa: placa,
      tara: tara,
      capacidadeKg: capacidadeKg,
      capacidadeM3: capacidadeM3,
      tipoPropriedade: tipoPropriedade,
      tipoVeiculo: tipoVeiculo,
      tipoRodado: tipoRodado,
      tipoCarroceria: tipoCarroceria,
      uf: uf,
      proprietarioCpf: proprietarioCpf,
      proprietarioCnpj: proprietarioCnpj,
      proprietarioRntrc: proprietarioRntrc,
      proprietarioNome: proprietarioNome,
      proprietarioIe: proprietarioIe,
      proprietarioUf: proprietarioUf,
      proprietarioTipo: proprietarioTipo,
      cteRodoviarioModel: cteRodoviarioModel?.clone(),
    );
  }


}