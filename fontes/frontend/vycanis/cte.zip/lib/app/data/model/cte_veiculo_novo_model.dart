import 'dart:convert';
import 'package:pluto_grid/pluto_grid.dart';
import 'package:cte/app/data/model/model_imports.dart';


class CteVeiculoNovoModel extends ModelBase {
  int? id;
  int? idCteCabecalho;
  String? chassi;
  String? cor;
  String? descricaoCor;
  String? codigoMarcaModelo;
  double? valorUnitario;
  double? valorFrete;

  CteVeiculoNovoModel({
    this.id,
    this.idCteCabecalho,
    this.chassi,
    this.cor,
    this.descricaoCor,
    this.codigoMarcaModelo,
    this.valorUnitario,
    this.valorFrete,
  });

  static List<String> dbColumns = <String>[
    'id',
    'chassi',
    'cor',
    'descricao_cor',
    'codigo_marca_modelo',
    'valor_unitario',
    'valor_frete',
  ];

  static List<String> aliasColumns = <String>[
    'Id',
    'Chassi',
    'Cor',
    'Descricao Cor',
    'Codigo Marca Modelo',
    'Valor Unitario',
    'Valor Frete',
  ];

  CteVeiculoNovoModel.fromJson(Map<String, dynamic> jsonData) {
    id = jsonData['id'];
    idCteCabecalho = jsonData['idCteCabecalho'];
    chassi = jsonData['chassi'];
    cor = jsonData['cor'];
    descricaoCor = jsonData['descricaoCor'];
    codigoMarcaModelo = jsonData['codigoMarcaModelo'];
    valorUnitario = jsonData['valorUnitario']?.toDouble();
    valorFrete = jsonData['valorFrete']?.toDouble();
  }

  Map<String, dynamic> get toJson {
    Map<String, dynamic> jsonData = <String, dynamic>{};

    jsonData['id'] = id != 0 ? id : null;
    jsonData['idCteCabecalho'] = idCteCabecalho != 0 ? idCteCabecalho : null;
    jsonData['chassi'] = chassi;
    jsonData['cor'] = cor;
    jsonData['descricaoCor'] = descricaoCor;
    jsonData['codigoMarcaModelo'] = codigoMarcaModelo;
    jsonData['valorUnitario'] = valorUnitario;
    jsonData['valorFrete'] = valorFrete;

    return jsonData;
  }

  String objectEncodeJson() {
    final jsonData = toJson;
    return json.encode(jsonData);
  }

  static CteVeiculoNovoModel fromPlutoRow(PlutoRow row) {
    return CteVeiculoNovoModel(
      id: row.cells['id']?.value,
      idCteCabecalho: row.cells['idCteCabecalho']?.value,
      chassi: row.cells['chassi']?.value,
      cor: row.cells['cor']?.value,
      descricaoCor: row.cells['descricaoCor']?.value,
      codigoMarcaModelo: row.cells['codigoMarcaModelo']?.value,
      valorUnitario: row.cells['valorUnitario']?.value,
      valorFrete: row.cells['valorFrete']?.value,
    );
  }

  PlutoRow toPlutoRow() {
    return PlutoRow(
      cells: {
        'tempId': PlutoCell(value: tempId),
        'id': PlutoCell(value: id ?? 0),
        'idCteCabecalho': PlutoCell(value: idCteCabecalho ?? 0),
        'chassi': PlutoCell(value: chassi ?? ''),
        'cor': PlutoCell(value: cor ?? ''),
        'descricaoCor': PlutoCell(value: descricaoCor ?? ''),
        'codigoMarcaModelo': PlutoCell(value: codigoMarcaModelo ?? ''),
        'valorUnitario': PlutoCell(value: valorUnitario ?? 0.0),
        'valorFrete': PlutoCell(value: valorFrete ?? 0.0),
      },
    );
  }

  CteVeiculoNovoModel clone() {
    return CteVeiculoNovoModel(
      id: id,
      idCteCabecalho: idCteCabecalho,
      chassi: chassi,
      cor: cor,
      descricaoCor: descricaoCor,
      codigoMarcaModelo: codigoMarcaModelo,
      valorUnitario: valorUnitario,
      valorFrete: valorFrete,
    );
  }


}