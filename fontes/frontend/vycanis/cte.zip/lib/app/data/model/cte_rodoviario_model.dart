import 'dart:convert';
import 'package:pluto_grid/pluto_grid.dart';
import 'package:cte/app/data/model/model_imports.dart';

import 'package:cte/app/infra/infra_imports.dart';
import 'package:intl/intl.dart';

class CteRodoviarioModel extends ModelBase {
  int? id;
  int? idCteCabecalho;
  String? rntrc;
  DateTime? dataPrevistaEntrega;
  String? indicadorLotacao;
  int? ciot;

  CteRodoviarioModel({
    this.id,
    this.idCteCabecalho,
    this.rntrc,
    this.dataPrevistaEntrega,
    this.indicadorLotacao,
    this.ciot,
  });

  static List<String> dbColumns = <String>[
    'id',
    'rntrc',
    'data_prevista_entrega',
    'indicador_lotacao',
    'ciot',
  ];

  static List<String> aliasColumns = <String>[
    'Id',
    'Rntrc',
    'Data Prevista Entrega',
    'Indicador Lotacao',
    'Ciot',
  ];

  CteRodoviarioModel.fromJson(Map<String, dynamic> jsonData) {
    id = jsonData['id'];
    idCteCabecalho = jsonData['idCteCabecalho'];
    rntrc = jsonData['rntrc'];
    dataPrevistaEntrega = jsonData['dataPrevistaEntrega'] != null ? DateTime.tryParse(jsonData['dataPrevistaEntrega']) : null;
    indicadorLotacao = jsonData['indicadorLotacao'];
    ciot = jsonData['ciot'];
  }

  Map<String, dynamic> get toJson {
    Map<String, dynamic> jsonData = <String, dynamic>{};

    jsonData['id'] = id != 0 ? id : null;
    jsonData['idCteCabecalho'] = idCteCabecalho != 0 ? idCteCabecalho : null;
    jsonData['rntrc'] = rntrc;
    jsonData['dataPrevistaEntrega'] = dataPrevistaEntrega != null ? DateFormat('yyyy-MM-ddT00:00:00').format(dataPrevistaEntrega!) : null;
    jsonData['indicadorLotacao'] = indicadorLotacao;
    jsonData['ciot'] = ciot;

    return jsonData;
  }

  String objectEncodeJson() {
    final jsonData = toJson;
    return json.encode(jsonData);
  }

  static CteRodoviarioModel fromPlutoRow(PlutoRow row) {
    return CteRodoviarioModel(
      id: row.cells['id']?.value,
      idCteCabecalho: row.cells['idCteCabecalho']?.value,
      rntrc: row.cells['rntrc']?.value,
      dataPrevistaEntrega: Util.stringToDate(row.cells['dataPrevistaEntrega']?.value),
      indicadorLotacao: row.cells['indicadorLotacao']?.value,
      ciot: row.cells['ciot']?.value,
    );
  }

  PlutoRow toPlutoRow() {
    return PlutoRow(
      cells: {
        'tempId': PlutoCell(value: tempId),
        'id': PlutoCell(value: id ?? 0),
        'idCteCabecalho': PlutoCell(value: idCteCabecalho ?? 0),
        'rntrc': PlutoCell(value: rntrc ?? ''),
        'dataPrevistaEntrega': PlutoCell(value: dataPrevistaEntrega),
        'indicadorLotacao': PlutoCell(value: indicadorLotacao ?? ''),
        'ciot': PlutoCell(value: ciot ?? 0),
      },
    );
  }

  CteRodoviarioModel clone() {
    return CteRodoviarioModel(
      id: id,
      idCteCabecalho: idCteCabecalho,
      rntrc: rntrc,
      dataPrevistaEntrega: dataPrevistaEntrega,
      indicadorLotacao: indicadorLotacao,
      ciot: ciot,
    );
  }


}