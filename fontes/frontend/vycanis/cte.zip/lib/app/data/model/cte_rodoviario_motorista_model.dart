import 'dart:convert';
import 'package:pluto_grid/pluto_grid.dart';
import 'package:cte/app/data/model/model_imports.dart';

import 'package:cte/app/infra/infra_imports.dart';

class CteRodoviarioMotoristaModel extends ModelBase {
  int? id;
  int? idCteRodoviario;
  String? nome;
  String? cpf;
  CteRodoviarioModel? cteRodoviarioModel;

  CteRodoviarioMotoristaModel({
    this.id,
    this.idCteRodoviario,
    this.nome,
    this.cpf,
    CteRodoviarioModel? cteRodoviarioModel,
  }) {
    this.cteRodoviarioModel = cteRodoviarioModel ?? CteRodoviarioModel();
  }

  static List<String> dbColumns = <String>[
    'id',
    'nome',
    'cpf',
  ];

  static List<String> aliasColumns = <String>[
    'Id',
    'Nome',
    'Cpf',
  ];

  CteRodoviarioMotoristaModel.fromJson(Map<String, dynamic> jsonData) {
    id = jsonData['id'];
    idCteRodoviario = jsonData['idCteRodoviario'];
    nome = jsonData['nome'];
    cpf = jsonData['cpf'];
    cteRodoviarioModel = jsonData['cteRodoviarioModel'] == null ? CteRodoviarioModel() : CteRodoviarioModel.fromJson(jsonData['cteRodoviarioModel']);
  }

  Map<String, dynamic> get toJson {
    Map<String, dynamic> jsonData = <String, dynamic>{};

    jsonData['id'] = id != 0 ? id : null;
    jsonData['idCteRodoviario'] = idCteRodoviario != 0 ? idCteRodoviario : null;
    jsonData['nome'] = nome;
    jsonData['cpf'] = Util.removeMask(cpf);
    jsonData['cteRodoviarioModel'] = cteRodoviarioModel?.toJson;
    jsonData['cteRodoviario'] = cteRodoviarioModel?.rntrc ?? '';

    return jsonData;
  }

  String objectEncodeJson() {
    final jsonData = toJson;
    return json.encode(jsonData);
  }

  static CteRodoviarioMotoristaModel fromPlutoRow(PlutoRow row) {
    return CteRodoviarioMotoristaModel(
      id: row.cells['id']?.value,
      idCteRodoviario: row.cells['idCteRodoviario']?.value,
      nome: row.cells['nome']?.value,
      cpf: row.cells['cpf']?.value,
    );
  }

  PlutoRow toPlutoRow() {
    return PlutoRow(
      cells: {
        'tempId': PlutoCell(value: tempId),
        'id': PlutoCell(value: id ?? 0),
        'idCteRodoviario': PlutoCell(value: idCteRodoviario ?? 0),
        'nome': PlutoCell(value: nome ?? ''),
        'cpf': PlutoCell(value: cpf ?? ''),
        'cteRodoviario': PlutoCell(value: cteRodoviarioModel?.rntrc ?? ''),
      },
    );
  }

  CteRodoviarioMotoristaModel clone() {
    return CteRodoviarioMotoristaModel(
      id: id,
      idCteRodoviario: idCteRodoviario,
      nome: nome,
      cpf: cpf,
      cteRodoviarioModel: cteRodoviarioModel?.clone(),
    );
  }


}