import 'dart:convert';
import 'package:pluto_grid/pluto_grid.dart';
import 'package:cte/app/data/model/model_imports.dart';


class CteFerroviarioVagaoModel extends ModelBase {
  int? id;
  int? idCteFerroviario;
  int? numeroVagao;
  double? capacidade;
  String? tipoVagao;
  double? pesoReal;
  double? pesoBc;
  CteFerroviarioModel? cteFerroviarioModel;

  CteFerroviarioVagaoModel({
    this.id,
    this.idCteFerroviario,
    this.numeroVagao,
    this.capacidade,
    this.tipoVagao,
    this.pesoReal,
    this.pesoBc,
    CteFerroviarioModel? cteFerroviarioModel,
  }) {
    this.cteFerroviarioModel = cteFerroviarioModel ?? CteFerroviarioModel();
  }

  static List<String> dbColumns = <String>[
    'id',
    'numero_vagao',
    'capacidade',
    'tipo_vagao',
    'peso_real',
    'peso_bc',
  ];

  static List<String> aliasColumns = <String>[
    'Id',
    'Numero Vagao',
    'Capacidade',
    'Tipo Vagao',
    'Peso Real',
    'Peso Bc',
  ];

  CteFerroviarioVagaoModel.fromJson(Map<String, dynamic> jsonData) {
    id = jsonData['id'];
    idCteFerroviario = jsonData['idCteFerroviario'];
    numeroVagao = jsonData['numeroVagao'];
    capacidade = jsonData['capacidade']?.toDouble();
    tipoVagao = jsonData['tipoVagao'];
    pesoReal = jsonData['pesoReal']?.toDouble();
    pesoBc = jsonData['pesoBc']?.toDouble();
    cteFerroviarioModel = jsonData['cteFerroviarioModel'] == null ? CteFerroviarioModel() : CteFerroviarioModel.fromJson(jsonData['cteFerroviarioModel']);
  }

  Map<String, dynamic> get toJson {
    Map<String, dynamic> jsonData = <String, dynamic>{};

    jsonData['id'] = id != 0 ? id : null;
    jsonData['idCteFerroviario'] = idCteFerroviario != 0 ? idCteFerroviario : null;
    jsonData['numeroVagao'] = numeroVagao;
    jsonData['capacidade'] = capacidade;
    jsonData['tipoVagao'] = tipoVagao;
    jsonData['pesoReal'] = pesoReal;
    jsonData['pesoBc'] = pesoBc;
    jsonData['cteFerroviarioModel'] = cteFerroviarioModel?.toJson;
    jsonData['cteFerroviario'] = cteFerroviarioModel?.fluxo ?? '';

    return jsonData;
  }

  String objectEncodeJson() {
    final jsonData = toJson;
    return json.encode(jsonData);
  }

  static CteFerroviarioVagaoModel fromPlutoRow(PlutoRow row) {
    return CteFerroviarioVagaoModel(
      id: row.cells['id']?.value,
      idCteFerroviario: row.cells['idCteFerroviario']?.value,
      numeroVagao: row.cells['numeroVagao']?.value,
      capacidade: row.cells['capacidade']?.value,
      tipoVagao: row.cells['tipoVagao']?.value,
      pesoReal: row.cells['pesoReal']?.value,
      pesoBc: row.cells['pesoBc']?.value,
    );
  }

  PlutoRow toPlutoRow() {
    return PlutoRow(
      cells: {
        'tempId': PlutoCell(value: tempId),
        'id': PlutoCell(value: id ?? 0),
        'idCteFerroviario': PlutoCell(value: idCteFerroviario ?? 0),
        'numeroVagao': PlutoCell(value: numeroVagao ?? 0),
        'capacidade': PlutoCell(value: capacidade ?? 0.0),
        'tipoVagao': PlutoCell(value: tipoVagao ?? ''),
        'pesoReal': PlutoCell(value: pesoReal ?? 0.0),
        'pesoBc': PlutoCell(value: pesoBc ?? 0.0),
        'cteFerroviario': PlutoCell(value: cteFerroviarioModel?.fluxo ?? ''),
      },
    );
  }

  CteFerroviarioVagaoModel clone() {
    return CteFerroviarioVagaoModel(
      id: id,
      idCteFerroviario: idCteFerroviario,
      numeroVagao: numeroVagao,
      capacidade: capacidade,
      tipoVagao: tipoVagao,
      pesoReal: pesoReal,
      pesoBc: pesoBc,
      cteFerroviarioModel: cteFerroviarioModel?.clone(),
    );
  }


}