import 'dart:convert';
import 'package:pluto_grid/pluto_grid.dart';
import 'package:cte/app/data/model/model_imports.dart';

import 'package:cte/app/infra/infra_imports.dart';
import 'package:intl/intl.dart';

class CteDocumentoAnteriorIdModel extends ModelBase {
  int? id;
  String? tipo;
  String? serie;
  String? subserie;
  String? numero;
  DateTime? dataEmissao;
  String? chaveCte;

  CteDocumentoAnteriorIdModel({
    this.id,
    this.tipo,
    this.serie,
    this.subserie,
    this.numero,
    this.dataEmissao,
    this.chaveCte,
  });

  static List<String> dbColumns = <String>[
    'id',
    'tipo',
    'serie',
    'subserie',
    'numero',
    'data_emissao',
    'chave_cte',
  ];

  static List<String> aliasColumns = <String>[
    'Id',
    'Tipo',
    'Serie',
    'Subserie',
    'Numero',
    'Data Emissao',
    'Chave Cte',
  ];

  CteDocumentoAnteriorIdModel.fromJson(Map<String, dynamic> jsonData) {
    id = jsonData['id'];
    tipo = jsonData['tipo'];
    serie = jsonData['serie'];
    subserie = jsonData['subserie'];
    numero = jsonData['numero'];
    dataEmissao = jsonData['dataEmissao'] != null ? DateTime.tryParse(jsonData['dataEmissao']) : null;
    chaveCte = jsonData['chaveCte'];
  }

  Map<String, dynamic> get toJson {
    Map<String, dynamic> jsonData = <String, dynamic>{};

    jsonData['id'] = id != 0 ? id : null;
    jsonData['tipo'] = tipo;
    jsonData['serie'] = serie;
    jsonData['subserie'] = subserie;
    jsonData['numero'] = numero;
    jsonData['dataEmissao'] = dataEmissao != null ? DateFormat('yyyy-MM-ddT00:00:00').format(dataEmissao!) : null;
    jsonData['chaveCte'] = chaveCte;

    return jsonData;
  }

  String objectEncodeJson() {
    final jsonData = toJson;
    return json.encode(jsonData);
  }

  static CteDocumentoAnteriorIdModel fromPlutoRow(PlutoRow row) {
    return CteDocumentoAnteriorIdModel(
      id: row.cells['id']?.value,
      tipo: row.cells['tipo']?.value,
      serie: row.cells['serie']?.value,
      subserie: row.cells['subserie']?.value,
      numero: row.cells['numero']?.value,
      dataEmissao: Util.stringToDate(row.cells['dataEmissao']?.value),
      chaveCte: row.cells['chaveCte']?.value,
    );
  }

  PlutoRow toPlutoRow() {
    return PlutoRow(
      cells: {
        'tempId': PlutoCell(value: tempId),
        'id': PlutoCell(value: id ?? 0),
        'tipo': PlutoCell(value: tipo ?? ''),
        'serie': PlutoCell(value: serie ?? ''),
        'subserie': PlutoCell(value: subserie ?? ''),
        'numero': PlutoCell(value: numero ?? ''),
        'dataEmissao': PlutoCell(value: dataEmissao),
        'chaveCte': PlutoCell(value: chaveCte ?? ''),
      },
    );
  }

  CteDocumentoAnteriorIdModel clone() {
    return CteDocumentoAnteriorIdModel(
      id: id,
      tipo: tipo,
      serie: serie,
      subserie: subserie,
      numero: numero,
      dataEmissao: dataEmissao,
      chaveCte: chaveCte,
    );
  }


}