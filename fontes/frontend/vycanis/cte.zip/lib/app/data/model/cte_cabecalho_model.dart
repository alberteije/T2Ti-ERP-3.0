import 'dart:convert';
import 'package:pluto_grid/pluto_grid.dart';
import 'package:cte/app/data/model/model_imports.dart';

import 'package:cte/app/infra/infra_imports.dart';
import 'package:intl/intl.dart';
import 'package:cte/app/data/domain/domain_imports.dart';

class CteCabecalhoModel extends ModelBase {
  int? id;
  String? naturezaOperacao;
  String? chaveAcesso;
  String? digitoChaveAcesso;
  String? codigoNumerico;
  String? serie;
  String? numero;
  DateTime? dataHoraEmissao;
  String? ufEmitente;
  int? cfop;
  String? formaPagamento;
  String? modelo;
  String? formatoImpressaoDacte;
  String? tipoEmissao;
  String? ambiente;
  String? tipoCte;
  String? processoEmissao;
  String? versaoProcessoEmissao;
  String? chaveReferenciado;
  int? codigoMunicipioEnvio;
  String? nomeMunicipioEnvio;
  String? ufEnvio;
  String? modal;
  String? tipoServico;
  int? codigoMunicipioIniPrestacao;
  String? nomeMunicipioIniPrestacao;
  String? ufIniPrestacao;
  int? codigoMunicipioFimPrestacao;
  String? nomeMunicipioFimPrestacao;
  String? ufFimPrestacao;
  String? retira;
  String? retiraDetalhe;
  String? tomador;
  DateTime? dataEntradaContingencia;
  String? justificativaContingencia;
  String? caracAdicionalTransporte;
  String? caracAdicionalServico;
  String? funcionarioEmissor;
  String? fluxoOrigem;
  String? entregaTipoPeriodo;
  DateTime? entregaDataProgramada;
  DateTime? entregaDataInicial;
  DateTime? entregaDataFinal;
  String? entregaTipoHora;
  String? entregaHoraProgramada;
  String? entregaHoraInicial;
  String? entregaHoraFinal;
  String? municipioOrigemCalculo;
  String? municipioDestinoCalculo;
  String? observacoesGerais;
  double? valorTotalServico;
  double? valorReceber;
  String? cst;
  double? baseCalculoIcms;
  double? aliquotaIcms;
  double? valorIcms;
  double? percentualReducaoBcIcms;
  double? valorBcIcmsStRetido;
  double? valorIcmsStRetido;
  double? aliquotaIcmsStRetido;
  double? valorCreditoPresumidoIcms;
  double? percentualBcIcmsOutraUf;
  double? valorBcIcmsOutraUf;
  double? aliquotaIcmsOutraUf;
  double? valorIcmsOutraUf;
  String? simplesNacionalIndicador;
  double? simplesNacionalTotal;
  String? informacoesAddFisco;
  double? valorTotalCarga;
  String? produtoPredominante;
  String? cargaOutrasCaracteristicas;
  int? modalVersaoLayout;
  String? chaveCteSubstituido;
  List<CteEmitenteModel>? cteEmitenteModelList;
  List<CteLocalColetaModel>? cteLocalColetaModelList;
  List<CteTomadorModel>? cteTomadorModelList;
  List<CtePassagemModel>? ctePassagemModelList;
  List<CteRemetenteModel>? cteRemetenteModelList;
  List<CteExpedidorModel>? cteExpedidorModelList;
  List<CteRecebedorModel>? cteRecebedorModelList;
  List<CteDestinatarioModel>? cteDestinatarioModelList;
  List<CteLocalEntregaModel>? cteLocalEntregaModelList;
  List<CteComponenteModel>? cteComponenteModelList;
  List<CteCargaModel>? cteCargaModelList;
  List<CteInformacaoNfOutrosModel>? cteInformacaoNfOutrosModelList;
  List<CteSeguroModel>? cteSeguroModelList;
  List<CtePerigosoModel>? ctePerigosoModelList;
  List<CteVeiculoNovoModel>? cteVeiculoNovoModelList;
  List<CteFaturaModel>? cteFaturaModelList;
  List<CteDuplicataModel>? cteDuplicataModelList;
  List<CteRodoviarioModel>? cteRodoviarioModelList;
  List<CteAereoModel>? cteAereoModelList;
  List<CteAquaviarioModel>? cteAquaviarioModelList;
  List<CteFerroviarioModel>? cteFerroviarioModelList;
  List<CteDutoviarioModel>? cteDutoviarioModelList;
  List<CteMultimodalModel>? cteMultimodalModelList;

  CteCabecalhoModel({
    this.id,
    this.naturezaOperacao,
    this.chaveAcesso,
    this.digitoChaveAcesso,
    this.codigoNumerico,
    this.serie,
    this.numero,
    this.dataHoraEmissao,
    this.ufEmitente = 'AC',
    this.cfop,
    this.formaPagamento = '0-Pago',
    this.modelo = '57',
    this.formatoImpressaoDacte = '1-Retrato',
    this.tipoEmissao = '1 - Normal',
    this.ambiente = '1-Produção',
    this.tipoCte = '0 - CT-e Normal',
    this.processoEmissao = '0 - emissão de CT-e com aplicativo do contribuinte; 1 - emissão de CT-e avulsa pelo Fisco; 2 - emissão de CT-e avulsa',
    this.versaoProcessoEmissao,
    this.chaveReferenciado,
    this.codigoMunicipioEnvio,
    this.nomeMunicipioEnvio,
    this.ufEnvio = 'AC',
    this.modal = '01-Rodoviário',
    this.tipoServico = '0 - Normal',
    this.codigoMunicipioIniPrestacao,
    this.nomeMunicipioIniPrestacao,
    this.ufIniPrestacao = 'AC',
    this.codigoMunicipioFimPrestacao,
    this.nomeMunicipioFimPrestacao,
    this.ufFimPrestacao = 'AC',
    this.retira = 'Sim',
    this.retiraDetalhe,
    this.tomador = '0-Remetente',
    this.dataEntradaContingencia,
    this.justificativaContingencia,
    this.caracAdicionalTransporte,
    this.caracAdicionalServico,
    this.funcionarioEmissor,
    this.fluxoOrigem,
    this.entregaTipoPeriodo = '0-Sem data definida',
    this.entregaDataProgramada,
    this.entregaDataInicial,
    this.entregaDataFinal,
    this.entregaTipoHora = '0-Sem hora definida',
    this.entregaHoraProgramada,
    this.entregaHoraInicial,
    this.entregaHoraFinal,
    this.municipioOrigemCalculo,
    this.municipioDestinoCalculo,
    this.observacoesGerais,
    this.valorTotalServico,
    this.valorReceber,
    this.cst,
    this.baseCalculoIcms,
    this.aliquotaIcms,
    this.valorIcms,
    this.percentualReducaoBcIcms,
    this.valorBcIcmsStRetido,
    this.valorIcmsStRetido,
    this.aliquotaIcmsStRetido,
    this.valorCreditoPresumidoIcms,
    this.percentualBcIcmsOutraUf,
    this.valorBcIcmsOutraUf,
    this.aliquotaIcmsOutraUf,
    this.valorIcmsOutraUf,
    this.simplesNacionalIndicador = 'Sim',
    this.simplesNacionalTotal,
    this.informacoesAddFisco,
    this.valorTotalCarga,
    this.produtoPredominante,
    this.cargaOutrasCaracteristicas,
    this.modalVersaoLayout,
    this.chaveCteSubstituido,
    List<CteEmitenteModel>? cteEmitenteModelList,
    List<CteLocalColetaModel>? cteLocalColetaModelList,
    List<CteTomadorModel>? cteTomadorModelList,
    List<CtePassagemModel>? ctePassagemModelList,
    List<CteRemetenteModel>? cteRemetenteModelList,
    List<CteExpedidorModel>? cteExpedidorModelList,
    List<CteRecebedorModel>? cteRecebedorModelList,
    List<CteDestinatarioModel>? cteDestinatarioModelList,
    List<CteLocalEntregaModel>? cteLocalEntregaModelList,
    List<CteComponenteModel>? cteComponenteModelList,
    List<CteCargaModel>? cteCargaModelList,
    List<CteInformacaoNfOutrosModel>? cteInformacaoNfOutrosModelList,
    List<CteSeguroModel>? cteSeguroModelList,
    List<CtePerigosoModel>? ctePerigosoModelList,
    List<CteVeiculoNovoModel>? cteVeiculoNovoModelList,
    List<CteFaturaModel>? cteFaturaModelList,
    List<CteDuplicataModel>? cteDuplicataModelList,
    List<CteRodoviarioModel>? cteRodoviarioModelList,
    List<CteAereoModel>? cteAereoModelList,
    List<CteAquaviarioModel>? cteAquaviarioModelList,
    List<CteFerroviarioModel>? cteFerroviarioModelList,
    List<CteDutoviarioModel>? cteDutoviarioModelList,
    List<CteMultimodalModel>? cteMultimodalModelList,
  }) {
    this.cteEmitenteModelList = cteEmitenteModelList?.toList(growable: true) ?? [];
    this.cteLocalColetaModelList = cteLocalColetaModelList?.toList(growable: true) ?? [];
    this.cteTomadorModelList = cteTomadorModelList?.toList(growable: true) ?? [];
    this.ctePassagemModelList = ctePassagemModelList?.toList(growable: true) ?? [];
    this.cteRemetenteModelList = cteRemetenteModelList?.toList(growable: true) ?? [];
    this.cteExpedidorModelList = cteExpedidorModelList?.toList(growable: true) ?? [];
    this.cteRecebedorModelList = cteRecebedorModelList?.toList(growable: true) ?? [];
    this.cteDestinatarioModelList = cteDestinatarioModelList?.toList(growable: true) ?? [];
    this.cteLocalEntregaModelList = cteLocalEntregaModelList?.toList(growable: true) ?? [];
    this.cteComponenteModelList = cteComponenteModelList?.toList(growable: true) ?? [];
    this.cteCargaModelList = cteCargaModelList?.toList(growable: true) ?? [];
    this.cteInformacaoNfOutrosModelList = cteInformacaoNfOutrosModelList?.toList(growable: true) ?? [];
    this.cteSeguroModelList = cteSeguroModelList?.toList(growable: true) ?? [];
    this.ctePerigosoModelList = ctePerigosoModelList?.toList(growable: true) ?? [];
    this.cteVeiculoNovoModelList = cteVeiculoNovoModelList?.toList(growable: true) ?? [];
    this.cteFaturaModelList = cteFaturaModelList?.toList(growable: true) ?? [];
    this.cteDuplicataModelList = cteDuplicataModelList?.toList(growable: true) ?? [];
    this.cteRodoviarioModelList = cteRodoviarioModelList?.toList(growable: true) ?? [];
    this.cteAereoModelList = cteAereoModelList?.toList(growable: true) ?? [];
    this.cteAquaviarioModelList = cteAquaviarioModelList?.toList(growable: true) ?? [];
    this.cteFerroviarioModelList = cteFerroviarioModelList?.toList(growable: true) ?? [];
    this.cteDutoviarioModelList = cteDutoviarioModelList?.toList(growable: true) ?? [];
    this.cteMultimodalModelList = cteMultimodalModelList?.toList(growable: true) ?? [];
  }

  static List<String> dbColumns = <String>[
    'id',
    'natureza_operacao',
    'chave_acesso',
    'digito_chave_acesso',
    'codigo_numerico',
    'serie',
    'numero',
    'data_hora_emissao',
    'uf_emitente',
    'cfop',
    'forma_pagamento',
    'modelo',
    'formato_impressao_dacte',
    'tipo_emissao',
    'ambiente',
    'tipo_cte',
    'processo_emissao',
    'versao_processo_emissao',
    'chave_referenciado',
    'codigo_municipio_envio',
    'nome_municipio_envio',
    'uf_envio',
    'modal',
    'tipo_servico',
    'codigo_municipio_ini_prestacao',
    'nome_municipio_ini_prestacao',
    'uf_ini_prestacao',
    'codigo_municipio_fim_prestacao',
    'nome_municipio_fim_prestacao',
    'uf_fim_prestacao',
    'retira',
    'retira_detalhe',
    'tomador',
    'data_entrada_contingencia',
    'justificativa_contingencia',
    'carac_adicional_transporte',
    'carac_adicional_servico',
    'funcionario_emissor',
    'fluxo_origem',
    'entrega_tipo_periodo',
    'entrega_data_programada',
    'entrega_data_inicial',
    'entrega_data_final',
    'entrega_tipo_hora',
    'entrega_hora_programada',
    'entrega_hora_inicial',
    'entrega_hora_final',
    'municipio_origem_calculo',
    'municipio_destino_calculo',
    'observacoes_gerais',
    'valor_total_servico',
    'valor_receber',
    'cst',
    'base_calculo_icms',
    'aliquota_icms',
    'valor_icms',
    'percentual_reducao_bc_icms',
    'valor_bc_icms_st_retido',
    'valor_icms_st_retido',
    'aliquota_icms_st_retido',
    'valor_credito_presumido_icms',
    'percentual_bc_icms_outra_uf',
    'valor_bc_icms_outra_uf',
    'aliquota_icms_outra_uf',
    'valor_icms_outra_uf',
    'simples_nacional_indicador',
    'simples_nacional_total',
    'informacoes_add_fisco',
    'valor_total_carga',
    'produto_predominante',
    'carga_outras_caracteristicas',
    'modal_versao_layout',
    'chave_cte_substituido',
  ];

  static List<String> aliasColumns = <String>[
    'Id',
    'Natureza Operacao',
    'Chave Acesso',
    'Digito Chave Acesso',
    'Codigo Numerico',
    'Serie',
    'Numero',
    'Data Hora Emissao',
    'Uf Emitente',
    'Cfop',
    'Forma Pagamento',
    'Modelo',
    'Formato Impressao Dacte',
    'Tipo Emissao',
    'Ambiente',
    'Tipo Cte',
    'Processo Emissao',
    'Versao Processo Emissao',
    'Chave Referenciado',
    'Codigo Municipio Envio',
    'Nome Municipio Envio',
    'Uf Envio',
    'Modal',
    'Tipo Servico',
    'Codigo Municipio Ini Prestacao',
    'Nome Municipio Ini Prestacao',
    'Uf Ini Prestacao',
    'Codigo Municipio Fim Prestacao',
    'Nome Municipio Fim Prestacao',
    'Uf Fim Prestacao',
    'Retira',
    'Retira Detalhe',
    'Tomador',
    'Data Entrada Contingencia',
    'Justificativa Contingencia',
    'Carac Adicional Transporte',
    'Carac Adicional Servico',
    'Funcionario Emissor',
    'Fluxo Origem',
    'Entrega Tipo Periodo',
    'Entrega Data Programada',
    'Entrega Data Inicial',
    'Entrega Data Final',
    'Entrega Tipo Hora',
    'Entrega Hora Programada',
    'Entrega Hora Inicial',
    'Entrega Hora Final',
    'Municipio Origem Calculo',
    'Municipio Destino Calculo',
    'Observacoes Gerais',
    'Valor Total Servico',
    'Valor Receber',
    'Cst',
    'Base Calculo Icms',
    'Aliquota Icms',
    'Valor Icms',
    'Percentual Reducao Bc Icms',
    'Valor Bc Icms St Retido',
    'Valor Icms St Retido',
    'Aliquota Icms St Retido',
    'Valor Credito Presumido Icms',
    'Percentual Bc Icms Outra Uf',
    'Valor Bc Icms Outra Uf',
    'Aliquota Icms Outra Uf',
    'Valor Icms Outra Uf',
    'Simples Nacional Indicador',
    'Simples Nacional Total',
    'Informacoes Add Fisco',
    'Valor Total Carga',
    'Produto Predominante',
    'Carga Outras Caracteristicas',
    'Modal Versao Layout',
    'Chave Cte Substituido',
  ];

  CteCabecalhoModel.fromJson(Map<String, dynamic> jsonData) {
    id = jsonData['id'];
    naturezaOperacao = jsonData['naturezaOperacao'];
    chaveAcesso = jsonData['chaveAcesso'];
    digitoChaveAcesso = jsonData['digitoChaveAcesso'];
    codigoNumerico = jsonData['codigoNumerico'];
    serie = jsonData['serie'];
    numero = jsonData['numero'];
    dataHoraEmissao = jsonData['dataHoraEmissao'] != null ? DateTime.tryParse(jsonData['dataHoraEmissao']) : null;
    ufEmitente = CteCabecalhoDomain.getUfEmitente(jsonData['ufEmitente']);
    cfop = jsonData['cfop'];
    formaPagamento = CteCabecalhoDomain.getFormaPagamento(jsonData['formaPagamento']);
    modelo = CteCabecalhoDomain.getModelo(jsonData['modelo']);
    formatoImpressaoDacte = CteCabecalhoDomain.getFormatoImpressaoDacte(jsonData['formatoImpressaoDacte']);
    tipoEmissao = CteCabecalhoDomain.getTipoEmissao(jsonData['tipoEmissao']);
    ambiente = CteCabecalhoDomain.getAmbiente(jsonData['ambiente']);
    tipoCte = CteCabecalhoDomain.getTipoCte(jsonData['tipoCte']);
    processoEmissao = CteCabecalhoDomain.getProcessoEmissao(jsonData['processoEmissao']);
    versaoProcessoEmissao = jsonData['versaoProcessoEmissao'];
    chaveReferenciado = jsonData['chaveReferenciado'];
    codigoMunicipioEnvio = jsonData['codigoMunicipioEnvio'];
    nomeMunicipioEnvio = jsonData['nomeMunicipioEnvio'];
    ufEnvio = CteCabecalhoDomain.getUfEnvio(jsonData['ufEnvio']);
    modal = CteCabecalhoDomain.getModal(jsonData['modal']);
    tipoServico = CteCabecalhoDomain.getTipoServico(jsonData['tipoServico']);
    codigoMunicipioIniPrestacao = jsonData['codigoMunicipioIniPrestacao'];
    nomeMunicipioIniPrestacao = jsonData['nomeMunicipioIniPrestacao'];
    ufIniPrestacao = CteCabecalhoDomain.getUfIniPrestacao(jsonData['ufIniPrestacao']);
    codigoMunicipioFimPrestacao = jsonData['codigoMunicipioFimPrestacao'];
    nomeMunicipioFimPrestacao = jsonData['nomeMunicipioFimPrestacao'];
    ufFimPrestacao = CteCabecalhoDomain.getUfFimPrestacao(jsonData['ufFimPrestacao']);
    retira = CteCabecalhoDomain.getRetira(jsonData['retira']);
    retiraDetalhe = jsonData['retiraDetalhe'];
    tomador = CteCabecalhoDomain.getTomador(jsonData['tomador']);
    dataEntradaContingencia = jsonData['dataEntradaContingencia'] != null ? DateTime.tryParse(jsonData['dataEntradaContingencia']) : null;
    justificativaContingencia = jsonData['justificativaContingencia'];
    caracAdicionalTransporte = jsonData['caracAdicionalTransporte'];
    caracAdicionalServico = jsonData['caracAdicionalServico'];
    funcionarioEmissor = jsonData['funcionarioEmissor'];
    fluxoOrigem = jsonData['fluxoOrigem'];
    entregaTipoPeriodo = CteCabecalhoDomain.getEntregaTipoPeriodo(jsonData['entregaTipoPeriodo']);
    entregaDataProgramada = jsonData['entregaDataProgramada'] != null ? DateTime.tryParse(jsonData['entregaDataProgramada']) : null;
    entregaDataInicial = jsonData['entregaDataInicial'] != null ? DateTime.tryParse(jsonData['entregaDataInicial']) : null;
    entregaDataFinal = jsonData['entregaDataFinal'] != null ? DateTime.tryParse(jsonData['entregaDataFinal']) : null;
    entregaTipoHora = CteCabecalhoDomain.getEntregaTipoHora(jsonData['entregaTipoHora']);
    entregaHoraProgramada = jsonData['entregaHoraProgramada'];
    entregaHoraInicial = jsonData['entregaHoraInicial'];
    entregaHoraFinal = jsonData['entregaHoraFinal'];
    municipioOrigemCalculo = jsonData['municipioOrigemCalculo'];
    municipioDestinoCalculo = jsonData['municipioDestinoCalculo'];
    observacoesGerais = jsonData['observacoesGerais'];
    valorTotalServico = jsonData['valorTotalServico']?.toDouble();
    valorReceber = jsonData['valorReceber']?.toDouble();
    cst = jsonData['cst'];
    baseCalculoIcms = jsonData['baseCalculoIcms']?.toDouble();
    aliquotaIcms = jsonData['aliquotaIcms']?.toDouble();
    valorIcms = jsonData['valorIcms']?.toDouble();
    percentualReducaoBcIcms = jsonData['percentualReducaoBcIcms']?.toDouble();
    valorBcIcmsStRetido = jsonData['valorBcIcmsStRetido']?.toDouble();
    valorIcmsStRetido = jsonData['valorIcmsStRetido']?.toDouble();
    aliquotaIcmsStRetido = jsonData['aliquotaIcmsStRetido']?.toDouble();
    valorCreditoPresumidoIcms = jsonData['valorCreditoPresumidoIcms']?.toDouble();
    percentualBcIcmsOutraUf = jsonData['percentualBcIcmsOutraUf']?.toDouble();
    valorBcIcmsOutraUf = jsonData['valorBcIcmsOutraUf']?.toDouble();
    aliquotaIcmsOutraUf = jsonData['aliquotaIcmsOutraUf']?.toDouble();
    valorIcmsOutraUf = jsonData['valorIcmsOutraUf']?.toDouble();
    simplesNacionalIndicador = CteCabecalhoDomain.getSimplesNacionalIndicador(jsonData['simplesNacionalIndicador']);
    simplesNacionalTotal = jsonData['simplesNacionalTotal']?.toDouble();
    informacoesAddFisco = jsonData['informacoesAddFisco'];
    valorTotalCarga = jsonData['valorTotalCarga']?.toDouble();
    produtoPredominante = jsonData['produtoPredominante'];
    cargaOutrasCaracteristicas = jsonData['cargaOutrasCaracteristicas'];
    modalVersaoLayout = jsonData['modalVersaoLayout'];
    chaveCteSubstituido = jsonData['chaveCteSubstituido'];
    cteEmitenteModelList = (jsonData['cteEmitenteModelList'] as Iterable?)?.map((m) => CteEmitenteModel.fromJson(m)).toList() ?? [];
    cteLocalColetaModelList = (jsonData['cteLocalColetaModelList'] as Iterable?)?.map((m) => CteLocalColetaModel.fromJson(m)).toList() ?? [];
    cteTomadorModelList = (jsonData['cteTomadorModelList'] as Iterable?)?.map((m) => CteTomadorModel.fromJson(m)).toList() ?? [];
    ctePassagemModelList = (jsonData['ctePassagemModelList'] as Iterable?)?.map((m) => CtePassagemModel.fromJson(m)).toList() ?? [];
    cteRemetenteModelList = (jsonData['cteRemetenteModelList'] as Iterable?)?.map((m) => CteRemetenteModel.fromJson(m)).toList() ?? [];
    cteExpedidorModelList = (jsonData['cteExpedidorModelList'] as Iterable?)?.map((m) => CteExpedidorModel.fromJson(m)).toList() ?? [];
    cteRecebedorModelList = (jsonData['cteRecebedorModelList'] as Iterable?)?.map((m) => CteRecebedorModel.fromJson(m)).toList() ?? [];
    cteDestinatarioModelList = (jsonData['cteDestinatarioModelList'] as Iterable?)?.map((m) => CteDestinatarioModel.fromJson(m)).toList() ?? [];
    cteLocalEntregaModelList = (jsonData['cteLocalEntregaModelList'] as Iterable?)?.map((m) => CteLocalEntregaModel.fromJson(m)).toList() ?? [];
    cteComponenteModelList = (jsonData['cteComponenteModelList'] as Iterable?)?.map((m) => CteComponenteModel.fromJson(m)).toList() ?? [];
    cteCargaModelList = (jsonData['cteCargaModelList'] as Iterable?)?.map((m) => CteCargaModel.fromJson(m)).toList() ?? [];
    cteInformacaoNfOutrosModelList = (jsonData['cteInformacaoNfOutrosModelList'] as Iterable?)?.map((m) => CteInformacaoNfOutrosModel.fromJson(m)).toList() ?? [];
    cteSeguroModelList = (jsonData['cteSeguroModelList'] as Iterable?)?.map((m) => CteSeguroModel.fromJson(m)).toList() ?? [];
    ctePerigosoModelList = (jsonData['ctePerigosoModelList'] as Iterable?)?.map((m) => CtePerigosoModel.fromJson(m)).toList() ?? [];
    cteVeiculoNovoModelList = (jsonData['cteVeiculoNovoModelList'] as Iterable?)?.map((m) => CteVeiculoNovoModel.fromJson(m)).toList() ?? [];
    cteFaturaModelList = (jsonData['cteFaturaModelList'] as Iterable?)?.map((m) => CteFaturaModel.fromJson(m)).toList() ?? [];
    cteDuplicataModelList = (jsonData['cteDuplicataModelList'] as Iterable?)?.map((m) => CteDuplicataModel.fromJson(m)).toList() ?? [];
    cteRodoviarioModelList = (jsonData['cteRodoviarioModelList'] as Iterable?)?.map((m) => CteRodoviarioModel.fromJson(m)).toList() ?? [];
    cteAereoModelList = (jsonData['cteAereoModelList'] as Iterable?)?.map((m) => CteAereoModel.fromJson(m)).toList() ?? [];
    cteAquaviarioModelList = (jsonData['cteAquaviarioModelList'] as Iterable?)?.map((m) => CteAquaviarioModel.fromJson(m)).toList() ?? [];
    cteFerroviarioModelList = (jsonData['cteFerroviarioModelList'] as Iterable?)?.map((m) => CteFerroviarioModel.fromJson(m)).toList() ?? [];
    cteDutoviarioModelList = (jsonData['cteDutoviarioModelList'] as Iterable?)?.map((m) => CteDutoviarioModel.fromJson(m)).toList() ?? [];
    cteMultimodalModelList = (jsonData['cteMultimodalModelList'] as Iterable?)?.map((m) => CteMultimodalModel.fromJson(m)).toList() ?? [];
  }

  Map<String, dynamic> get toJson {
    Map<String, dynamic> jsonData = <String, dynamic>{};

    jsonData['id'] = id != 0 ? id : null;
    jsonData['naturezaOperacao'] = naturezaOperacao;
    jsonData['chaveAcesso'] = chaveAcesso;
    jsonData['digitoChaveAcesso'] = digitoChaveAcesso;
    jsonData['codigoNumerico'] = codigoNumerico;
    jsonData['serie'] = serie;
    jsonData['numero'] = numero;
    jsonData['dataHoraEmissao'] = dataHoraEmissao != null ? DateFormat('yyyy-MM-ddT00:00:00').format(dataHoraEmissao!) : null;
    jsonData['ufEmitente'] = CteCabecalhoDomain.setUfEmitente(ufEmitente);
    jsonData['cfop'] = cfop;
    jsonData['formaPagamento'] = CteCabecalhoDomain.setFormaPagamento(formaPagamento);
    jsonData['modelo'] = CteCabecalhoDomain.setModelo(modelo);
    jsonData['formatoImpressaoDacte'] = CteCabecalhoDomain.setFormatoImpressaoDacte(formatoImpressaoDacte);
    jsonData['tipoEmissao'] = CteCabecalhoDomain.setTipoEmissao(tipoEmissao);
    jsonData['ambiente'] = CteCabecalhoDomain.setAmbiente(ambiente);
    jsonData['tipoCte'] = CteCabecalhoDomain.setTipoCte(tipoCte);
    jsonData['processoEmissao'] = CteCabecalhoDomain.setProcessoEmissao(processoEmissao);
    jsonData['versaoProcessoEmissao'] = versaoProcessoEmissao;
    jsonData['chaveReferenciado'] = chaveReferenciado;
    jsonData['codigoMunicipioEnvio'] = codigoMunicipioEnvio;
    jsonData['nomeMunicipioEnvio'] = nomeMunicipioEnvio;
    jsonData['ufEnvio'] = CteCabecalhoDomain.setUfEnvio(ufEnvio);
    jsonData['modal'] = CteCabecalhoDomain.setModal(modal);
    jsonData['tipoServico'] = CteCabecalhoDomain.setTipoServico(tipoServico);
    jsonData['codigoMunicipioIniPrestacao'] = codigoMunicipioIniPrestacao;
    jsonData['nomeMunicipioIniPrestacao'] = nomeMunicipioIniPrestacao;
    jsonData['ufIniPrestacao'] = CteCabecalhoDomain.setUfIniPrestacao(ufIniPrestacao);
    jsonData['codigoMunicipioFimPrestacao'] = codigoMunicipioFimPrestacao;
    jsonData['nomeMunicipioFimPrestacao'] = nomeMunicipioFimPrestacao;
    jsonData['ufFimPrestacao'] = CteCabecalhoDomain.setUfFimPrestacao(ufFimPrestacao);
    jsonData['retira'] = CteCabecalhoDomain.setRetira(retira);
    jsonData['retiraDetalhe'] = retiraDetalhe;
    jsonData['tomador'] = CteCabecalhoDomain.setTomador(tomador);
    jsonData['dataEntradaContingencia'] = dataEntradaContingencia != null ? DateFormat('yyyy-MM-ddT00:00:00').format(dataEntradaContingencia!) : null;
    jsonData['justificativaContingencia'] = justificativaContingencia;
    jsonData['caracAdicionalTransporte'] = caracAdicionalTransporte;
    jsonData['caracAdicionalServico'] = caracAdicionalServico;
    jsonData['funcionarioEmissor'] = funcionarioEmissor;
    jsonData['fluxoOrigem'] = fluxoOrigem;
    jsonData['entregaTipoPeriodo'] = CteCabecalhoDomain.setEntregaTipoPeriodo(entregaTipoPeriodo);
    jsonData['entregaDataProgramada'] = entregaDataProgramada != null ? DateFormat('yyyy-MM-ddT00:00:00').format(entregaDataProgramada!) : null;
    jsonData['entregaDataInicial'] = entregaDataInicial != null ? DateFormat('yyyy-MM-ddT00:00:00').format(entregaDataInicial!) : null;
    jsonData['entregaDataFinal'] = entregaDataFinal != null ? DateFormat('yyyy-MM-ddT00:00:00').format(entregaDataFinal!) : null;
    jsonData['entregaTipoHora'] = CteCabecalhoDomain.setEntregaTipoHora(entregaTipoHora);
    jsonData['entregaHoraProgramada'] = entregaHoraProgramada;
    jsonData['entregaHoraInicial'] = entregaHoraInicial;
    jsonData['entregaHoraFinal'] = entregaHoraFinal;
    jsonData['municipioOrigemCalculo'] = municipioOrigemCalculo;
    jsonData['municipioDestinoCalculo'] = municipioDestinoCalculo;
    jsonData['observacoesGerais'] = observacoesGerais;
    jsonData['valorTotalServico'] = valorTotalServico;
    jsonData['valorReceber'] = valorReceber;
    jsonData['cst'] = cst;
    jsonData['baseCalculoIcms'] = baseCalculoIcms;
    jsonData['aliquotaIcms'] = aliquotaIcms;
    jsonData['valorIcms'] = valorIcms;
    jsonData['percentualReducaoBcIcms'] = percentualReducaoBcIcms;
    jsonData['valorBcIcmsStRetido'] = valorBcIcmsStRetido;
    jsonData['valorIcmsStRetido'] = valorIcmsStRetido;
    jsonData['aliquotaIcmsStRetido'] = aliquotaIcmsStRetido;
    jsonData['valorCreditoPresumidoIcms'] = valorCreditoPresumidoIcms;
    jsonData['percentualBcIcmsOutraUf'] = percentualBcIcmsOutraUf;
    jsonData['valorBcIcmsOutraUf'] = valorBcIcmsOutraUf;
    jsonData['aliquotaIcmsOutraUf'] = aliquotaIcmsOutraUf;
    jsonData['valorIcmsOutraUf'] = valorIcmsOutraUf;
    jsonData['simplesNacionalIndicador'] = CteCabecalhoDomain.setSimplesNacionalIndicador(simplesNacionalIndicador);
    jsonData['simplesNacionalTotal'] = simplesNacionalTotal;
    jsonData['informacoesAddFisco'] = informacoesAddFisco;
    jsonData['valorTotalCarga'] = valorTotalCarga;
    jsonData['produtoPredominante'] = produtoPredominante;
    jsonData['cargaOutrasCaracteristicas'] = cargaOutrasCaracteristicas;
    jsonData['modalVersaoLayout'] = modalVersaoLayout;
    jsonData['chaveCteSubstituido'] = chaveCteSubstituido;
    
		var cteEmitenteModelLocalList = []; 
		for (CteEmitenteModel object in cteEmitenteModelList ?? []) { 
			cteEmitenteModelLocalList.add(object.toJson); 
		}
		jsonData['cteEmitenteModelList'] = cteEmitenteModelLocalList;
    
		var cteLocalColetaModelLocalList = []; 
		for (CteLocalColetaModel object in cteLocalColetaModelList ?? []) { 
			cteLocalColetaModelLocalList.add(object.toJson); 
		}
		jsonData['cteLocalColetaModelList'] = cteLocalColetaModelLocalList;
    
		var cteTomadorModelLocalList = []; 
		for (CteTomadorModel object in cteTomadorModelList ?? []) { 
			cteTomadorModelLocalList.add(object.toJson); 
		}
		jsonData['cteTomadorModelList'] = cteTomadorModelLocalList;
    
		var ctePassagemModelLocalList = []; 
		for (CtePassagemModel object in ctePassagemModelList ?? []) { 
			ctePassagemModelLocalList.add(object.toJson); 
		}
		jsonData['ctePassagemModelList'] = ctePassagemModelLocalList;
    
		var cteRemetenteModelLocalList = []; 
		for (CteRemetenteModel object in cteRemetenteModelList ?? []) { 
			cteRemetenteModelLocalList.add(object.toJson); 
		}
		jsonData['cteRemetenteModelList'] = cteRemetenteModelLocalList;
    
		var cteExpedidorModelLocalList = []; 
		for (CteExpedidorModel object in cteExpedidorModelList ?? []) { 
			cteExpedidorModelLocalList.add(object.toJson); 
		}
		jsonData['cteExpedidorModelList'] = cteExpedidorModelLocalList;
    
		var cteRecebedorModelLocalList = []; 
		for (CteRecebedorModel object in cteRecebedorModelList ?? []) { 
			cteRecebedorModelLocalList.add(object.toJson); 
		}
		jsonData['cteRecebedorModelList'] = cteRecebedorModelLocalList;
    
		var cteDestinatarioModelLocalList = []; 
		for (CteDestinatarioModel object in cteDestinatarioModelList ?? []) { 
			cteDestinatarioModelLocalList.add(object.toJson); 
		}
		jsonData['cteDestinatarioModelList'] = cteDestinatarioModelLocalList;
    
		var cteLocalEntregaModelLocalList = []; 
		for (CteLocalEntregaModel object in cteLocalEntregaModelList ?? []) { 
			cteLocalEntregaModelLocalList.add(object.toJson); 
		}
		jsonData['cteLocalEntregaModelList'] = cteLocalEntregaModelLocalList;
    
		var cteComponenteModelLocalList = []; 
		for (CteComponenteModel object in cteComponenteModelList ?? []) { 
			cteComponenteModelLocalList.add(object.toJson); 
		}
		jsonData['cteComponenteModelList'] = cteComponenteModelLocalList;
    
		var cteCargaModelLocalList = []; 
		for (CteCargaModel object in cteCargaModelList ?? []) { 
			cteCargaModelLocalList.add(object.toJson); 
		}
		jsonData['cteCargaModelList'] = cteCargaModelLocalList;
    
		var cteInformacaoNfOutrosModelLocalList = []; 
		for (CteInformacaoNfOutrosModel object in cteInformacaoNfOutrosModelList ?? []) { 
			cteInformacaoNfOutrosModelLocalList.add(object.toJson); 
		}
		jsonData['cteInformacaoNfOutrosModelList'] = cteInformacaoNfOutrosModelLocalList;
    
		var cteSeguroModelLocalList = []; 
		for (CteSeguroModel object in cteSeguroModelList ?? []) { 
			cteSeguroModelLocalList.add(object.toJson); 
		}
		jsonData['cteSeguroModelList'] = cteSeguroModelLocalList;
    
		var ctePerigosoModelLocalList = []; 
		for (CtePerigosoModel object in ctePerigosoModelList ?? []) { 
			ctePerigosoModelLocalList.add(object.toJson); 
		}
		jsonData['ctePerigosoModelList'] = ctePerigosoModelLocalList;
    
		var cteVeiculoNovoModelLocalList = []; 
		for (CteVeiculoNovoModel object in cteVeiculoNovoModelList ?? []) { 
			cteVeiculoNovoModelLocalList.add(object.toJson); 
		}
		jsonData['cteVeiculoNovoModelList'] = cteVeiculoNovoModelLocalList;
    
		var cteFaturaModelLocalList = []; 
		for (CteFaturaModel object in cteFaturaModelList ?? []) { 
			cteFaturaModelLocalList.add(object.toJson); 
		}
		jsonData['cteFaturaModelList'] = cteFaturaModelLocalList;
    
		var cteDuplicataModelLocalList = []; 
		for (CteDuplicataModel object in cteDuplicataModelList ?? []) { 
			cteDuplicataModelLocalList.add(object.toJson); 
		}
		jsonData['cteDuplicataModelList'] = cteDuplicataModelLocalList;
    
		var cteRodoviarioModelLocalList = []; 
		for (CteRodoviarioModel object in cteRodoviarioModelList ?? []) { 
			cteRodoviarioModelLocalList.add(object.toJson); 
		}
		jsonData['cteRodoviarioModelList'] = cteRodoviarioModelLocalList;
    
		var cteAereoModelLocalList = []; 
		for (CteAereoModel object in cteAereoModelList ?? []) { 
			cteAereoModelLocalList.add(object.toJson); 
		}
		jsonData['cteAereoModelList'] = cteAereoModelLocalList;
    
		var cteAquaviarioModelLocalList = []; 
		for (CteAquaviarioModel object in cteAquaviarioModelList ?? []) { 
			cteAquaviarioModelLocalList.add(object.toJson); 
		}
		jsonData['cteAquaviarioModelList'] = cteAquaviarioModelLocalList;
    
		var cteFerroviarioModelLocalList = []; 
		for (CteFerroviarioModel object in cteFerroviarioModelList ?? []) { 
			cteFerroviarioModelLocalList.add(object.toJson); 
		}
		jsonData['cteFerroviarioModelList'] = cteFerroviarioModelLocalList;
    
		var cteDutoviarioModelLocalList = []; 
		for (CteDutoviarioModel object in cteDutoviarioModelList ?? []) { 
			cteDutoviarioModelLocalList.add(object.toJson); 
		}
		jsonData['cteDutoviarioModelList'] = cteDutoviarioModelLocalList;
    
		var cteMultimodalModelLocalList = []; 
		for (CteMultimodalModel object in cteMultimodalModelList ?? []) { 
			cteMultimodalModelLocalList.add(object.toJson); 
		}
		jsonData['cteMultimodalModelList'] = cteMultimodalModelLocalList;

    return jsonData;
  }

  String objectEncodeJson() {
    final jsonData = toJson;
    return json.encode(jsonData);
  }

  static CteCabecalhoModel fromPlutoRow(PlutoRow row) {
    return CteCabecalhoModel(
      id: row.cells['id']?.value,
      naturezaOperacao: row.cells['naturezaOperacao']?.value,
      chaveAcesso: row.cells['chaveAcesso']?.value,
      digitoChaveAcesso: row.cells['digitoChaveAcesso']?.value,
      codigoNumerico: row.cells['codigoNumerico']?.value,
      serie: row.cells['serie']?.value,
      numero: row.cells['numero']?.value,
      dataHoraEmissao: Util.stringToDate(row.cells['dataHoraEmissao']?.value),
      ufEmitente: row.cells['ufEmitente']?.value,
      cfop: row.cells['cfop']?.value,
      formaPagamento: row.cells['formaPagamento']?.value,
      modelo: row.cells['modelo']?.value,
      formatoImpressaoDacte: row.cells['formatoImpressaoDacte']?.value,
      tipoEmissao: row.cells['tipoEmissao']?.value,
      ambiente: row.cells['ambiente']?.value,
      tipoCte: row.cells['tipoCte']?.value,
      processoEmissao: row.cells['processoEmissao']?.value,
      versaoProcessoEmissao: row.cells['versaoProcessoEmissao']?.value,
      chaveReferenciado: row.cells['chaveReferenciado']?.value,
      codigoMunicipioEnvio: row.cells['codigoMunicipioEnvio']?.value,
      nomeMunicipioEnvio: row.cells['nomeMunicipioEnvio']?.value,
      ufEnvio: row.cells['ufEnvio']?.value,
      modal: row.cells['modal']?.value,
      tipoServico: row.cells['tipoServico']?.value,
      codigoMunicipioIniPrestacao: row.cells['codigoMunicipioIniPrestacao']?.value,
      nomeMunicipioIniPrestacao: row.cells['nomeMunicipioIniPrestacao']?.value,
      ufIniPrestacao: row.cells['ufIniPrestacao']?.value,
      codigoMunicipioFimPrestacao: row.cells['codigoMunicipioFimPrestacao']?.value,
      nomeMunicipioFimPrestacao: row.cells['nomeMunicipioFimPrestacao']?.value,
      ufFimPrestacao: row.cells['ufFimPrestacao']?.value,
      retira: row.cells['retira']?.value,
      retiraDetalhe: row.cells['retiraDetalhe']?.value,
      tomador: row.cells['tomador']?.value,
      dataEntradaContingencia: Util.stringToDate(row.cells['dataEntradaContingencia']?.value),
      justificativaContingencia: row.cells['justificativaContingencia']?.value,
      caracAdicionalTransporte: row.cells['caracAdicionalTransporte']?.value,
      caracAdicionalServico: row.cells['caracAdicionalServico']?.value,
      funcionarioEmissor: row.cells['funcionarioEmissor']?.value,
      fluxoOrigem: row.cells['fluxoOrigem']?.value,
      entregaTipoPeriodo: row.cells['entregaTipoPeriodo']?.value,
      entregaDataProgramada: Util.stringToDate(row.cells['entregaDataProgramada']?.value),
      entregaDataInicial: Util.stringToDate(row.cells['entregaDataInicial']?.value),
      entregaDataFinal: Util.stringToDate(row.cells['entregaDataFinal']?.value),
      entregaTipoHora: row.cells['entregaTipoHora']?.value,
      entregaHoraProgramada: row.cells['entregaHoraProgramada']?.value,
      entregaHoraInicial: row.cells['entregaHoraInicial']?.value,
      entregaHoraFinal: row.cells['entregaHoraFinal']?.value,
      municipioOrigemCalculo: row.cells['municipioOrigemCalculo']?.value,
      municipioDestinoCalculo: row.cells['municipioDestinoCalculo']?.value,
      observacoesGerais: row.cells['observacoesGerais']?.value,
      valorTotalServico: row.cells['valorTotalServico']?.value,
      valorReceber: row.cells['valorReceber']?.value,
      cst: row.cells['cst']?.value,
      baseCalculoIcms: row.cells['baseCalculoIcms']?.value,
      aliquotaIcms: row.cells['aliquotaIcms']?.value,
      valorIcms: row.cells['valorIcms']?.value,
      percentualReducaoBcIcms: row.cells['percentualReducaoBcIcms']?.value,
      valorBcIcmsStRetido: row.cells['valorBcIcmsStRetido']?.value,
      valorIcmsStRetido: row.cells['valorIcmsStRetido']?.value,
      aliquotaIcmsStRetido: row.cells['aliquotaIcmsStRetido']?.value,
      valorCreditoPresumidoIcms: row.cells['valorCreditoPresumidoIcms']?.value,
      percentualBcIcmsOutraUf: row.cells['percentualBcIcmsOutraUf']?.value,
      valorBcIcmsOutraUf: row.cells['valorBcIcmsOutraUf']?.value,
      aliquotaIcmsOutraUf: row.cells['aliquotaIcmsOutraUf']?.value,
      valorIcmsOutraUf: row.cells['valorIcmsOutraUf']?.value,
      simplesNacionalIndicador: row.cells['simplesNacionalIndicador']?.value,
      simplesNacionalTotal: row.cells['simplesNacionalTotal']?.value,
      informacoesAddFisco: row.cells['informacoesAddFisco']?.value,
      valorTotalCarga: row.cells['valorTotalCarga']?.value,
      produtoPredominante: row.cells['produtoPredominante']?.value,
      cargaOutrasCaracteristicas: row.cells['cargaOutrasCaracteristicas']?.value,
      modalVersaoLayout: row.cells['modalVersaoLayout']?.value,
      chaveCteSubstituido: row.cells['chaveCteSubstituido']?.value,
    );
  }

  PlutoRow toPlutoRow() {
    return PlutoRow(
      cells: {
        'tempId': PlutoCell(value: tempId),
        'id': PlutoCell(value: id ?? 0),
        'naturezaOperacao': PlutoCell(value: naturezaOperacao ?? ''),
        'chaveAcesso': PlutoCell(value: chaveAcesso ?? ''),
        'digitoChaveAcesso': PlutoCell(value: digitoChaveAcesso ?? ''),
        'codigoNumerico': PlutoCell(value: codigoNumerico ?? ''),
        'serie': PlutoCell(value: serie ?? ''),
        'numero': PlutoCell(value: numero ?? ''),
        'dataHoraEmissao': PlutoCell(value: dataHoraEmissao),
        'ufEmitente': PlutoCell(value: ufEmitente ?? ''),
        'cfop': PlutoCell(value: cfop ?? 0),
        'formaPagamento': PlutoCell(value: formaPagamento ?? ''),
        'modelo': PlutoCell(value: modelo ?? ''),
        'formatoImpressaoDacte': PlutoCell(value: formatoImpressaoDacte ?? ''),
        'tipoEmissao': PlutoCell(value: tipoEmissao ?? ''),
        'ambiente': PlutoCell(value: ambiente ?? ''),
        'tipoCte': PlutoCell(value: tipoCte ?? ''),
        'processoEmissao': PlutoCell(value: processoEmissao ?? ''),
        'versaoProcessoEmissao': PlutoCell(value: versaoProcessoEmissao ?? ''),
        'chaveReferenciado': PlutoCell(value: chaveReferenciado ?? ''),
        'codigoMunicipioEnvio': PlutoCell(value: codigoMunicipioEnvio ?? 0),
        'nomeMunicipioEnvio': PlutoCell(value: nomeMunicipioEnvio ?? ''),
        'ufEnvio': PlutoCell(value: ufEnvio ?? ''),
        'modal': PlutoCell(value: modal ?? ''),
        'tipoServico': PlutoCell(value: tipoServico ?? ''),
        'codigoMunicipioIniPrestacao': PlutoCell(value: codigoMunicipioIniPrestacao ?? 0),
        'nomeMunicipioIniPrestacao': PlutoCell(value: nomeMunicipioIniPrestacao ?? ''),
        'ufIniPrestacao': PlutoCell(value: ufIniPrestacao ?? ''),
        'codigoMunicipioFimPrestacao': PlutoCell(value: codigoMunicipioFimPrestacao ?? 0),
        'nomeMunicipioFimPrestacao': PlutoCell(value: nomeMunicipioFimPrestacao ?? ''),
        'ufFimPrestacao': PlutoCell(value: ufFimPrestacao ?? ''),
        'retira': PlutoCell(value: retira ?? ''),
        'retiraDetalhe': PlutoCell(value: retiraDetalhe ?? ''),
        'tomador': PlutoCell(value: tomador ?? ''),
        'dataEntradaContingencia': PlutoCell(value: dataEntradaContingencia),
        'justificativaContingencia': PlutoCell(value: justificativaContingencia ?? ''),
        'caracAdicionalTransporte': PlutoCell(value: caracAdicionalTransporte ?? ''),
        'caracAdicionalServico': PlutoCell(value: caracAdicionalServico ?? ''),
        'funcionarioEmissor': PlutoCell(value: funcionarioEmissor ?? ''),
        'fluxoOrigem': PlutoCell(value: fluxoOrigem ?? ''),
        'entregaTipoPeriodo': PlutoCell(value: entregaTipoPeriodo ?? ''),
        'entregaDataProgramada': PlutoCell(value: entregaDataProgramada),
        'entregaDataInicial': PlutoCell(value: entregaDataInicial),
        'entregaDataFinal': PlutoCell(value: entregaDataFinal),
        'entregaTipoHora': PlutoCell(value: entregaTipoHora ?? ''),
        'entregaHoraProgramada': PlutoCell(value: entregaHoraProgramada ?? ''),
        'entregaHoraInicial': PlutoCell(value: entregaHoraInicial ?? ''),
        'entregaHoraFinal': PlutoCell(value: entregaHoraFinal ?? ''),
        'municipioOrigemCalculo': PlutoCell(value: municipioOrigemCalculo ?? ''),
        'municipioDestinoCalculo': PlutoCell(value: municipioDestinoCalculo ?? ''),
        'observacoesGerais': PlutoCell(value: observacoesGerais ?? ''),
        'valorTotalServico': PlutoCell(value: valorTotalServico ?? 0.0),
        'valorReceber': PlutoCell(value: valorReceber ?? 0.0),
        'cst': PlutoCell(value: cst ?? ''),
        'baseCalculoIcms': PlutoCell(value: baseCalculoIcms ?? 0.0),
        'aliquotaIcms': PlutoCell(value: aliquotaIcms ?? 0.0),
        'valorIcms': PlutoCell(value: valorIcms ?? 0.0),
        'percentualReducaoBcIcms': PlutoCell(value: percentualReducaoBcIcms ?? 0.0),
        'valorBcIcmsStRetido': PlutoCell(value: valorBcIcmsStRetido ?? 0.0),
        'valorIcmsStRetido': PlutoCell(value: valorIcmsStRetido ?? 0.0),
        'aliquotaIcmsStRetido': PlutoCell(value: aliquotaIcmsStRetido ?? 0.0),
        'valorCreditoPresumidoIcms': PlutoCell(value: valorCreditoPresumidoIcms ?? 0.0),
        'percentualBcIcmsOutraUf': PlutoCell(value: percentualBcIcmsOutraUf ?? 0.0),
        'valorBcIcmsOutraUf': PlutoCell(value: valorBcIcmsOutraUf ?? 0.0),
        'aliquotaIcmsOutraUf': PlutoCell(value: aliquotaIcmsOutraUf ?? 0.0),
        'valorIcmsOutraUf': PlutoCell(value: valorIcmsOutraUf ?? 0.0),
        'simplesNacionalIndicador': PlutoCell(value: simplesNacionalIndicador ?? ''),
        'simplesNacionalTotal': PlutoCell(value: simplesNacionalTotal ?? 0.0),
        'informacoesAddFisco': PlutoCell(value: informacoesAddFisco ?? ''),
        'valorTotalCarga': PlutoCell(value: valorTotalCarga ?? 0.0),
        'produtoPredominante': PlutoCell(value: produtoPredominante ?? ''),
        'cargaOutrasCaracteristicas': PlutoCell(value: cargaOutrasCaracteristicas ?? ''),
        'modalVersaoLayout': PlutoCell(value: modalVersaoLayout ?? 0),
        'chaveCteSubstituido': PlutoCell(value: chaveCteSubstituido ?? ''),
      },
    );
  }

  CteCabecalhoModel clone() {
    return CteCabecalhoModel(
      id: id,
      naturezaOperacao: naturezaOperacao,
      chaveAcesso: chaveAcesso,
      digitoChaveAcesso: digitoChaveAcesso,
      codigoNumerico: codigoNumerico,
      serie: serie,
      numero: numero,
      dataHoraEmissao: dataHoraEmissao,
      ufEmitente: ufEmitente,
      cfop: cfop,
      formaPagamento: formaPagamento,
      modelo: modelo,
      formatoImpressaoDacte: formatoImpressaoDacte,
      tipoEmissao: tipoEmissao,
      ambiente: ambiente,
      tipoCte: tipoCte,
      processoEmissao: processoEmissao,
      versaoProcessoEmissao: versaoProcessoEmissao,
      chaveReferenciado: chaveReferenciado,
      codigoMunicipioEnvio: codigoMunicipioEnvio,
      nomeMunicipioEnvio: nomeMunicipioEnvio,
      ufEnvio: ufEnvio,
      modal: modal,
      tipoServico: tipoServico,
      codigoMunicipioIniPrestacao: codigoMunicipioIniPrestacao,
      nomeMunicipioIniPrestacao: nomeMunicipioIniPrestacao,
      ufIniPrestacao: ufIniPrestacao,
      codigoMunicipioFimPrestacao: codigoMunicipioFimPrestacao,
      nomeMunicipioFimPrestacao: nomeMunicipioFimPrestacao,
      ufFimPrestacao: ufFimPrestacao,
      retira: retira,
      retiraDetalhe: retiraDetalhe,
      tomador: tomador,
      dataEntradaContingencia: dataEntradaContingencia,
      justificativaContingencia: justificativaContingencia,
      caracAdicionalTransporte: caracAdicionalTransporte,
      caracAdicionalServico: caracAdicionalServico,
      funcionarioEmissor: funcionarioEmissor,
      fluxoOrigem: fluxoOrigem,
      entregaTipoPeriodo: entregaTipoPeriodo,
      entregaDataProgramada: entregaDataProgramada,
      entregaDataInicial: entregaDataInicial,
      entregaDataFinal: entregaDataFinal,
      entregaTipoHora: entregaTipoHora,
      entregaHoraProgramada: entregaHoraProgramada,
      entregaHoraInicial: entregaHoraInicial,
      entregaHoraFinal: entregaHoraFinal,
      municipioOrigemCalculo: municipioOrigemCalculo,
      municipioDestinoCalculo: municipioDestinoCalculo,
      observacoesGerais: observacoesGerais,
      valorTotalServico: valorTotalServico,
      valorReceber: valorReceber,
      cst: cst,
      baseCalculoIcms: baseCalculoIcms,
      aliquotaIcms: aliquotaIcms,
      valorIcms: valorIcms,
      percentualReducaoBcIcms: percentualReducaoBcIcms,
      valorBcIcmsStRetido: valorBcIcmsStRetido,
      valorIcmsStRetido: valorIcmsStRetido,
      aliquotaIcmsStRetido: aliquotaIcmsStRetido,
      valorCreditoPresumidoIcms: valorCreditoPresumidoIcms,
      percentualBcIcmsOutraUf: percentualBcIcmsOutraUf,
      valorBcIcmsOutraUf: valorBcIcmsOutraUf,
      aliquotaIcmsOutraUf: aliquotaIcmsOutraUf,
      valorIcmsOutraUf: valorIcmsOutraUf,
      simplesNacionalIndicador: simplesNacionalIndicador,
      simplesNacionalTotal: simplesNacionalTotal,
      informacoesAddFisco: informacoesAddFisco,
      valorTotalCarga: valorTotalCarga,
      produtoPredominante: produtoPredominante,
      cargaOutrasCaracteristicas: cargaOutrasCaracteristicas,
      modalVersaoLayout: modalVersaoLayout,
      chaveCteSubstituido: chaveCteSubstituido,
      cteEmitenteModelList: cteEmitenteModelListClone(cteEmitenteModelList!),
      cteLocalColetaModelList: cteLocalColetaModelListClone(cteLocalColetaModelList!),
      cteTomadorModelList: cteTomadorModelListClone(cteTomadorModelList!),
      ctePassagemModelList: ctePassagemModelListClone(ctePassagemModelList!),
      cteRemetenteModelList: cteRemetenteModelListClone(cteRemetenteModelList!),
      cteExpedidorModelList: cteExpedidorModelListClone(cteExpedidorModelList!),
      cteRecebedorModelList: cteRecebedorModelListClone(cteRecebedorModelList!),
      cteDestinatarioModelList: cteDestinatarioModelListClone(cteDestinatarioModelList!),
      cteLocalEntregaModelList: cteLocalEntregaModelListClone(cteLocalEntregaModelList!),
      cteComponenteModelList: cteComponenteModelListClone(cteComponenteModelList!),
      cteCargaModelList: cteCargaModelListClone(cteCargaModelList!),
      cteInformacaoNfOutrosModelList: cteInformacaoNfOutrosModelListClone(cteInformacaoNfOutrosModelList!),
      cteSeguroModelList: cteSeguroModelListClone(cteSeguroModelList!),
      ctePerigosoModelList: ctePerigosoModelListClone(ctePerigosoModelList!),
      cteVeiculoNovoModelList: cteVeiculoNovoModelListClone(cteVeiculoNovoModelList!),
      cteFaturaModelList: cteFaturaModelListClone(cteFaturaModelList!),
      cteDuplicataModelList: cteDuplicataModelListClone(cteDuplicataModelList!),
      cteRodoviarioModelList: cteRodoviarioModelListClone(cteRodoviarioModelList!),
      cteAereoModelList: cteAereoModelListClone(cteAereoModelList!),
      cteAquaviarioModelList: cteAquaviarioModelListClone(cteAquaviarioModelList!),
      cteFerroviarioModelList: cteFerroviarioModelListClone(cteFerroviarioModelList!),
      cteDutoviarioModelList: cteDutoviarioModelListClone(cteDutoviarioModelList!),
      cteMultimodalModelList: cteMultimodalModelListClone(cteMultimodalModelList!),
    );
  }

  cteEmitenteModelListClone(List<CteEmitenteModel> cteEmitenteModelList) { 
		List<CteEmitenteModel> resultList = [];
		for (var cteEmitenteModel in cteEmitenteModelList) {
			resultList.add(cteEmitenteModel.clone());
		}
		return resultList;
	}

  cteLocalColetaModelListClone(List<CteLocalColetaModel> cteLocalColetaModelList) { 
		List<CteLocalColetaModel> resultList = [];
		for (var cteLocalColetaModel in cteLocalColetaModelList) {
			resultList.add(cteLocalColetaModel.clone());
		}
		return resultList;
	}

  cteTomadorModelListClone(List<CteTomadorModel> cteTomadorModelList) { 
		List<CteTomadorModel> resultList = [];
		for (var cteTomadorModel in cteTomadorModelList) {
			resultList.add(cteTomadorModel.clone());
		}
		return resultList;
	}

  ctePassagemModelListClone(List<CtePassagemModel> ctePassagemModelList) { 
		List<CtePassagemModel> resultList = [];
		for (var ctePassagemModel in ctePassagemModelList) {
			resultList.add(ctePassagemModel.clone());
		}
		return resultList;
	}

  cteRemetenteModelListClone(List<CteRemetenteModel> cteRemetenteModelList) { 
		List<CteRemetenteModel> resultList = [];
		for (var cteRemetenteModel in cteRemetenteModelList) {
			resultList.add(cteRemetenteModel.clone());
		}
		return resultList;
	}

  cteExpedidorModelListClone(List<CteExpedidorModel> cteExpedidorModelList) { 
		List<CteExpedidorModel> resultList = [];
		for (var cteExpedidorModel in cteExpedidorModelList) {
			resultList.add(cteExpedidorModel.clone());
		}
		return resultList;
	}

  cteRecebedorModelListClone(List<CteRecebedorModel> cteRecebedorModelList) { 
		List<CteRecebedorModel> resultList = [];
		for (var cteRecebedorModel in cteRecebedorModelList) {
			resultList.add(cteRecebedorModel.clone());
		}
		return resultList;
	}

  cteDestinatarioModelListClone(List<CteDestinatarioModel> cteDestinatarioModelList) { 
		List<CteDestinatarioModel> resultList = [];
		for (var cteDestinatarioModel in cteDestinatarioModelList) {
			resultList.add(cteDestinatarioModel.clone());
		}
		return resultList;
	}

  cteLocalEntregaModelListClone(List<CteLocalEntregaModel> cteLocalEntregaModelList) { 
		List<CteLocalEntregaModel> resultList = [];
		for (var cteLocalEntregaModel in cteLocalEntregaModelList) {
			resultList.add(cteLocalEntregaModel.clone());
		}
		return resultList;
	}

  cteComponenteModelListClone(List<CteComponenteModel> cteComponenteModelList) { 
		List<CteComponenteModel> resultList = [];
		for (var cteComponenteModel in cteComponenteModelList) {
			resultList.add(cteComponenteModel.clone());
		}
		return resultList;
	}

  cteCargaModelListClone(List<CteCargaModel> cteCargaModelList) { 
		List<CteCargaModel> resultList = [];
		for (var cteCargaModel in cteCargaModelList) {
			resultList.add(cteCargaModel.clone());
		}
		return resultList;
	}

  cteInformacaoNfOutrosModelListClone(List<CteInformacaoNfOutrosModel> cteInformacaoNfOutrosModelList) { 
		List<CteInformacaoNfOutrosModel> resultList = [];
		for (var cteInformacaoNfOutrosModel in cteInformacaoNfOutrosModelList) {
			resultList.add(cteInformacaoNfOutrosModel.clone());
		}
		return resultList;
	}

  cteSeguroModelListClone(List<CteSeguroModel> cteSeguroModelList) { 
		List<CteSeguroModel> resultList = [];
		for (var cteSeguroModel in cteSeguroModelList) {
			resultList.add(cteSeguroModel.clone());
		}
		return resultList;
	}

  ctePerigosoModelListClone(List<CtePerigosoModel> ctePerigosoModelList) { 
		List<CtePerigosoModel> resultList = [];
		for (var ctePerigosoModel in ctePerigosoModelList) {
			resultList.add(ctePerigosoModel.clone());
		}
		return resultList;
	}

  cteVeiculoNovoModelListClone(List<CteVeiculoNovoModel> cteVeiculoNovoModelList) { 
		List<CteVeiculoNovoModel> resultList = [];
		for (var cteVeiculoNovoModel in cteVeiculoNovoModelList) {
			resultList.add(cteVeiculoNovoModel.clone());
		}
		return resultList;
	}

  cteFaturaModelListClone(List<CteFaturaModel> cteFaturaModelList) { 
		List<CteFaturaModel> resultList = [];
		for (var cteFaturaModel in cteFaturaModelList) {
			resultList.add(cteFaturaModel.clone());
		}
		return resultList;
	}

  cteDuplicataModelListClone(List<CteDuplicataModel> cteDuplicataModelList) { 
		List<CteDuplicataModel> resultList = [];
		for (var cteDuplicataModel in cteDuplicataModelList) {
			resultList.add(cteDuplicataModel.clone());
		}
		return resultList;
	}

  cteRodoviarioModelListClone(List<CteRodoviarioModel> cteRodoviarioModelList) { 
		List<CteRodoviarioModel> resultList = [];
		for (var cteRodoviarioModel in cteRodoviarioModelList) {
			resultList.add(cteRodoviarioModel.clone());
		}
		return resultList;
	}

  cteAereoModelListClone(List<CteAereoModel> cteAereoModelList) { 
		List<CteAereoModel> resultList = [];
		for (var cteAereoModel in cteAereoModelList) {
			resultList.add(cteAereoModel.clone());
		}
		return resultList;
	}

  cteAquaviarioModelListClone(List<CteAquaviarioModel> cteAquaviarioModelList) { 
		List<CteAquaviarioModel> resultList = [];
		for (var cteAquaviarioModel in cteAquaviarioModelList) {
			resultList.add(cteAquaviarioModel.clone());
		}
		return resultList;
	}

  cteFerroviarioModelListClone(List<CteFerroviarioModel> cteFerroviarioModelList) { 
		List<CteFerroviarioModel> resultList = [];
		for (var cteFerroviarioModel in cteFerroviarioModelList) {
			resultList.add(cteFerroviarioModel.clone());
		}
		return resultList;
	}

  cteDutoviarioModelListClone(List<CteDutoviarioModel> cteDutoviarioModelList) { 
		List<CteDutoviarioModel> resultList = [];
		for (var cteDutoviarioModel in cteDutoviarioModelList) {
			resultList.add(cteDutoviarioModel.clone());
		}
		return resultList;
	}

  cteMultimodalModelListClone(List<CteMultimodalModel> cteMultimodalModelList) { 
		List<CteMultimodalModel> resultList = [];
		for (var cteMultimodalModel in cteMultimodalModelList) {
			resultList.add(cteMultimodalModel.clone());
		}
		return resultList;
	}


}