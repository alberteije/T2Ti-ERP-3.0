import 'dart:convert';
import 'package:pluto_grid/pluto_grid.dart';
import 'package:cte/app/data/model/model_imports.dart';

import 'package:cte/app/data/domain/domain_imports.dart';

class CteMultimodalModel extends ModelBase {
  int? id;
  int? idCteCabecalho;
  String? cotm;
  String? indicadorNegociavel;

  CteMultimodalModel({
    this.id,
    this.idCteCabecalho,
    this.cotm,
    this.indicadorNegociavel = '0 - Não Negociável',
  });

  static List<String> dbColumns = <String>[
    'id',
    'cotm',
    'indicador_negociavel',
  ];

  static List<String> aliasColumns = <String>[
    'Id',
    'Cotm',
    'Indicador Negociavel',
  ];

  CteMultimodalModel.fromJson(Map<String, dynamic> jsonData) {
    id = jsonData['id'];
    idCteCabecalho = jsonData['idCteCabecalho'];
    cotm = jsonData['cotm'];
    indicadorNegociavel = CteMultimodalDomain.getIndicadorNegociavel(jsonData['indicadorNegociavel']);
  }

  Map<String, dynamic> get toJson {
    Map<String, dynamic> jsonData = <String, dynamic>{};

    jsonData['id'] = id != 0 ? id : null;
    jsonData['idCteCabecalho'] = idCteCabecalho != 0 ? idCteCabecalho : null;
    jsonData['cotm'] = cotm;
    jsonData['indicadorNegociavel'] = CteMultimodalDomain.setIndicadorNegociavel(indicadorNegociavel);

    return jsonData;
  }

  String objectEncodeJson() {
    final jsonData = toJson;
    return json.encode(jsonData);
  }

  static CteMultimodalModel fromPlutoRow(PlutoRow row) {
    return CteMultimodalModel(
      id: row.cells['id']?.value,
      idCteCabecalho: row.cells['idCteCabecalho']?.value,
      cotm: row.cells['cotm']?.value,
      indicadorNegociavel: row.cells['indicadorNegociavel']?.value,
    );
  }

  PlutoRow toPlutoRow() {
    return PlutoRow(
      cells: {
        'tempId': PlutoCell(value: tempId),
        'id': PlutoCell(value: id ?? 0),
        'idCteCabecalho': PlutoCell(value: idCteCabecalho ?? 0),
        'cotm': PlutoCell(value: cotm ?? ''),
        'indicadorNegociavel': PlutoCell(value: indicadorNegociavel ?? ''),
      },
    );
  }

  CteMultimodalModel clone() {
    return CteMultimodalModel(
      id: id,
      idCteCabecalho: idCteCabecalho,
      cotm: cotm,
      indicadorNegociavel: indicadorNegociavel,
    );
  }


}