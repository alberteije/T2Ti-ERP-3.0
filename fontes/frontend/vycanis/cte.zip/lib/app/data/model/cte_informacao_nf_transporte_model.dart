import 'dart:convert';
import 'package:pluto_grid/pluto_grid.dart';
import 'package:cte/app/data/model/model_imports.dart';

import 'package:cte/app/data/domain/domain_imports.dart';

class CteInformacaoNfTransporteModel extends ModelBase {
  int? id;
  int? idCteInformacaoNf;
  String? tipoUnidadeTransporte;
  String? idUnidadeTransporte;
  CteInformacaoNfOutrosModel? cteInformacaoNfOutrosModel;

  CteInformacaoNfTransporteModel({
    this.id,
    this.idCteInformacaoNf,
    this.tipoUnidadeTransporte = '1 - Rodoviário Tração',
    this.idUnidadeTransporte,
    CteInformacaoNfOutrosModel? cteInformacaoNfOutrosModel,
  }) {
    this.cteInformacaoNfOutrosModel = cteInformacaoNfOutrosModel ?? CteInformacaoNfOutrosModel();
  }

  static List<String> dbColumns = <String>[
    'id',
    'tipo_unidade_transporte',
    'id_unidade_transporte',
  ];

  static List<String> aliasColumns = <String>[
    'Id',
    'Tipo Unidade Transporte',
    'Id Unidade Transporte',
  ];

  CteInformacaoNfTransporteModel.fromJson(Map<String, dynamic> jsonData) {
    id = jsonData['id'];
    idCteInformacaoNf = jsonData['idCteInformacaoNf'];
    tipoUnidadeTransporte = CteInformacaoNfTransporteDomain.getTipoUnidadeTransporte(jsonData['tipoUnidadeTransporte']);
    idUnidadeTransporte = jsonData['idUnidadeTransporte'];
    cteInformacaoNfOutrosModel = jsonData['cteInformacaoNfOutrosModel'] == null ? CteInformacaoNfOutrosModel() : CteInformacaoNfOutrosModel.fromJson(jsonData['cteInformacaoNfOutrosModel']);
  }

  Map<String, dynamic> get toJson {
    Map<String, dynamic> jsonData = <String, dynamic>{};

    jsonData['id'] = id != 0 ? id : null;
    jsonData['idCteInformacaoNf'] = idCteInformacaoNf != 0 ? idCteInformacaoNf : null;
    jsonData['tipoUnidadeTransporte'] = CteInformacaoNfTransporteDomain.setTipoUnidadeTransporte(tipoUnidadeTransporte);
    jsonData['idUnidadeTransporte'] = idUnidadeTransporte;
    jsonData['cteInformacaoNfOutrosModel'] = cteInformacaoNfOutrosModel?.toJson;
    jsonData['cteInformacaoNfOutros'] = cteInformacaoNfOutrosModel?.numero ?? '';

    return jsonData;
  }

  String objectEncodeJson() {
    final jsonData = toJson;
    return json.encode(jsonData);
  }

  static CteInformacaoNfTransporteModel fromPlutoRow(PlutoRow row) {
    return CteInformacaoNfTransporteModel(
      id: row.cells['id']?.value,
      idCteInformacaoNf: row.cells['idCteInformacaoNf']?.value,
      tipoUnidadeTransporte: row.cells['tipoUnidadeTransporte']?.value,
      idUnidadeTransporte: row.cells['idUnidadeTransporte']?.value,
    );
  }

  PlutoRow toPlutoRow() {
    return PlutoRow(
      cells: {
        'tempId': PlutoCell(value: tempId),
        'id': PlutoCell(value: id ?? 0),
        'idCteInformacaoNf': PlutoCell(value: idCteInformacaoNf ?? 0),
        'tipoUnidadeTransporte': PlutoCell(value: tipoUnidadeTransporte ?? ''),
        'idUnidadeTransporte': PlutoCell(value: idUnidadeTransporte ?? ''),
        'cteInformacaoNfOutros': PlutoCell(value: cteInformacaoNfOutrosModel?.numero ?? ''),
      },
    );
  }

  CteInformacaoNfTransporteModel clone() {
    return CteInformacaoNfTransporteModel(
      id: id,
      idCteInformacaoNf: idCteInformacaoNf,
      tipoUnidadeTransporte: tipoUnidadeTransporte,
      idUnidadeTransporte: idUnidadeTransporte,
      cteInformacaoNfOutrosModel: cteInformacaoNfOutrosModel?.clone(),
    );
  }


}