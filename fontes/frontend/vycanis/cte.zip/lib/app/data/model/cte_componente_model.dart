import 'dart:convert';
import 'package:pluto_grid/pluto_grid.dart';
import 'package:cte/app/data/model/model_imports.dart';


class CteComponenteModel extends ModelBase {
  int? id;
  int? idCteCabecalho;
  String? nome;
  double? valor;

  CteComponenteModel({
    this.id,
    this.idCteCabecalho,
    this.nome,
    this.valor,
  });

  static List<String> dbColumns = <String>[
    'id',
    'nome',
    'valor',
  ];

  static List<String> aliasColumns = <String>[
    'Id',
    'Nome',
    'Valor',
  ];

  CteComponenteModel.fromJson(Map<String, dynamic> jsonData) {
    id = jsonData['id'];
    idCteCabecalho = jsonData['idCteCabecalho'];
    nome = jsonData['nome'];
    valor = jsonData['valor']?.toDouble();
  }

  Map<String, dynamic> get toJson {
    Map<String, dynamic> jsonData = <String, dynamic>{};

    jsonData['id'] = id != 0 ? id : null;
    jsonData['idCteCabecalho'] = idCteCabecalho != 0 ? idCteCabecalho : null;
    jsonData['nome'] = nome;
    jsonData['valor'] = valor;

    return jsonData;
  }

  String objectEncodeJson() {
    final jsonData = toJson;
    return json.encode(jsonData);
  }

  static CteComponenteModel fromPlutoRow(PlutoRow row) {
    return CteComponenteModel(
      id: row.cells['id']?.value,
      idCteCabecalho: row.cells['idCteCabecalho']?.value,
      nome: row.cells['nome']?.value,
      valor: row.cells['valor']?.value,
    );
  }

  PlutoRow toPlutoRow() {
    return PlutoRow(
      cells: {
        'tempId': PlutoCell(value: tempId),
        'id': PlutoCell(value: id ?? 0),
        'idCteCabecalho': PlutoCell(value: idCteCabecalho ?? 0),
        'nome': PlutoCell(value: nome ?? ''),
        'valor': PlutoCell(value: valor ?? 0.0),
      },
    );
  }

  CteComponenteModel clone() {
    return CteComponenteModel(
      id: id,
      idCteCabecalho: idCteCabecalho,
      nome: nome,
      valor: valor,
    );
  }


}