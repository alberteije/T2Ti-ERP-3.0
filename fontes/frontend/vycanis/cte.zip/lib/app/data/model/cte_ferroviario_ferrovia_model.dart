import 'dart:convert';
import 'package:pluto_grid/pluto_grid.dart';
import 'package:cte/app/data/model/model_imports.dart';

import 'package:cte/app/infra/infra_imports.dart';
import 'package:cte/app/data/domain/domain_imports.dart';

class CteFerroviarioFerroviaModel extends ModelBase {
  int? id;
  int? idCteFerroviario;
  String? cnpj;
  String? codigoInterno;
  String? ie;
  String? nome;
  String? logradouro;
  String? numero;
  String? complemento;
  String? bairro;
  int? codigoMunicipio;
  String? nomeMunicipio;
  String? uf;
  String? cep;
  CteFerroviarioModel? cteFerroviarioModel;

  CteFerroviarioFerroviaModel({
    this.id,
    this.idCteFerroviario,
    this.cnpj,
    this.codigoInterno,
    this.ie,
    this.nome,
    this.logradouro,
    this.numero,
    this.complemento,
    this.bairro,
    this.codigoMunicipio,
    this.nomeMunicipio,
    this.uf = 'AC',
    this.cep,
    CteFerroviarioModel? cteFerroviarioModel,
  }) {
    this.cteFerroviarioModel = cteFerroviarioModel ?? CteFerroviarioModel();
  }

  static List<String> dbColumns = <String>[
    'id',
    'cnpj',
    'codigo_interno',
    'ie',
    'nome',
    'logradouro',
    'numero',
    'complemento',
    'bairro',
    'codigo_municipio',
    'nome_municipio',
    'uf',
    'cep',
  ];

  static List<String> aliasColumns = <String>[
    'Id',
    'Cnpj',
    'Codigo Interno',
    'Ie',
    'Nome',
    'Logradouro',
    'Numero',
    'Complemento',
    'Bairro',
    'Codigo Municipio',
    'Nome Municipio',
    'Uf',
    'Cep',
  ];

  CteFerroviarioFerroviaModel.fromJson(Map<String, dynamic> jsonData) {
    id = jsonData['id'];
    idCteFerroviario = jsonData['idCteFerroviario'];
    cnpj = jsonData['cnpj'];
    codigoInterno = jsonData['codigoInterno'];
    ie = jsonData['ie'];
    nome = jsonData['nome'];
    logradouro = jsonData['logradouro'];
    numero = jsonData['numero'];
    complemento = jsonData['complemento'];
    bairro = jsonData['bairro'];
    codigoMunicipio = jsonData['codigoMunicipio'];
    nomeMunicipio = jsonData['nomeMunicipio'];
    uf = CteFerroviarioFerroviaDomain.getUf(jsonData['uf']);
    cep = jsonData['cep'];
    cteFerroviarioModel = jsonData['cteFerroviarioModel'] == null ? CteFerroviarioModel() : CteFerroviarioModel.fromJson(jsonData['cteFerroviarioModel']);
  }

  Map<String, dynamic> get toJson {
    Map<String, dynamic> jsonData = <String, dynamic>{};

    jsonData['id'] = id != 0 ? id : null;
    jsonData['idCteFerroviario'] = idCteFerroviario != 0 ? idCteFerroviario : null;
    jsonData['cnpj'] = Util.removeMask(cnpj);
    jsonData['codigoInterno'] = codigoInterno;
    jsonData['ie'] = ie;
    jsonData['nome'] = nome;
    jsonData['logradouro'] = logradouro;
    jsonData['numero'] = numero;
    jsonData['complemento'] = complemento;
    jsonData['bairro'] = bairro;
    jsonData['codigoMunicipio'] = codigoMunicipio;
    jsonData['nomeMunicipio'] = nomeMunicipio;
    jsonData['uf'] = CteFerroviarioFerroviaDomain.setUf(uf);
    jsonData['cep'] = Util.removeMask(cep);
    jsonData['cteFerroviarioModel'] = cteFerroviarioModel?.toJson;
    jsonData['cteFerroviario'] = cteFerroviarioModel?.fluxo ?? '';

    return jsonData;
  }

  String objectEncodeJson() {
    final jsonData = toJson;
    return json.encode(jsonData);
  }

  static CteFerroviarioFerroviaModel fromPlutoRow(PlutoRow row) {
    return CteFerroviarioFerroviaModel(
      id: row.cells['id']?.value,
      idCteFerroviario: row.cells['idCteFerroviario']?.value,
      cnpj: row.cells['cnpj']?.value,
      codigoInterno: row.cells['codigoInterno']?.value,
      ie: row.cells['ie']?.value,
      nome: row.cells['nome']?.value,
      logradouro: row.cells['logradouro']?.value,
      numero: row.cells['numero']?.value,
      complemento: row.cells['complemento']?.value,
      bairro: row.cells['bairro']?.value,
      codigoMunicipio: row.cells['codigoMunicipio']?.value,
      nomeMunicipio: row.cells['nomeMunicipio']?.value,
      uf: row.cells['uf']?.value,
      cep: row.cells['cep']?.value,
    );
  }

  PlutoRow toPlutoRow() {
    return PlutoRow(
      cells: {
        'tempId': PlutoCell(value: tempId),
        'id': PlutoCell(value: id ?? 0),
        'idCteFerroviario': PlutoCell(value: idCteFerroviario ?? 0),
        'cnpj': PlutoCell(value: cnpj ?? ''),
        'codigoInterno': PlutoCell(value: codigoInterno ?? ''),
        'ie': PlutoCell(value: ie ?? ''),
        'nome': PlutoCell(value: nome ?? ''),
        'logradouro': PlutoCell(value: logradouro ?? ''),
        'numero': PlutoCell(value: numero ?? ''),
        'complemento': PlutoCell(value: complemento ?? ''),
        'bairro': PlutoCell(value: bairro ?? ''),
        'codigoMunicipio': PlutoCell(value: codigoMunicipio ?? 0),
        'nomeMunicipio': PlutoCell(value: nomeMunicipio ?? ''),
        'uf': PlutoCell(value: uf ?? ''),
        'cep': PlutoCell(value: cep ?? ''),
        'cteFerroviario': PlutoCell(value: cteFerroviarioModel?.fluxo ?? ''),
      },
    );
  }

  CteFerroviarioFerroviaModel clone() {
    return CteFerroviarioFerroviaModel(
      id: id,
      idCteFerroviario: idCteFerroviario,
      cnpj: cnpj,
      codigoInterno: codigoInterno,
      ie: ie,
      nome: nome,
      logradouro: logradouro,
      numero: numero,
      complemento: complemento,
      bairro: bairro,
      codigoMunicipio: codigoMunicipio,
      nomeMunicipio: nomeMunicipio,
      uf: uf,
      cep: cep,
      cteFerroviarioModel: cteFerroviarioModel?.clone(),
    );
  }


}