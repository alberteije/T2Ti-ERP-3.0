import 'dart:convert';
import 'package:pluto_grid/pluto_grid.dart';
import 'package:cte/app/data/model/model_imports.dart';


class CtePassagemModel extends ModelBase {
  int? id;
  int? idCteCabecalho;
  String? siglaPassagem;
  String? siglaDestino;
  String? rota;

  CtePassagemModel({
    this.id,
    this.idCteCabecalho,
    this.siglaPassagem,
    this.siglaDestino,
    this.rota,
  });

  static List<String> dbColumns = <String>[
    'id',
    'sigla_passagem',
    'sigla_destino',
    'rota',
  ];

  static List<String> aliasColumns = <String>[
    'Id',
    'Sigla Passagem',
    'Sigla Destino',
    'Rota',
  ];

  CtePassagemModel.fromJson(Map<String, dynamic> jsonData) {
    id = jsonData['id'];
    idCteCabecalho = jsonData['idCteCabecalho'];
    siglaPassagem = jsonData['siglaPassagem'];
    siglaDestino = jsonData['siglaDestino'];
    rota = jsonData['rota'];
  }

  Map<String, dynamic> get toJson {
    Map<String, dynamic> jsonData = <String, dynamic>{};

    jsonData['id'] = id != 0 ? id : null;
    jsonData['idCteCabecalho'] = idCteCabecalho != 0 ? idCteCabecalho : null;
    jsonData['siglaPassagem'] = siglaPassagem;
    jsonData['siglaDestino'] = siglaDestino;
    jsonData['rota'] = rota;

    return jsonData;
  }

  String objectEncodeJson() {
    final jsonData = toJson;
    return json.encode(jsonData);
  }

  static CtePassagemModel fromPlutoRow(PlutoRow row) {
    return CtePassagemModel(
      id: row.cells['id']?.value,
      idCteCabecalho: row.cells['idCteCabecalho']?.value,
      siglaPassagem: row.cells['siglaPassagem']?.value,
      siglaDestino: row.cells['siglaDestino']?.value,
      rota: row.cells['rota']?.value,
    );
  }

  PlutoRow toPlutoRow() {
    return PlutoRow(
      cells: {
        'tempId': PlutoCell(value: tempId),
        'id': PlutoCell(value: id ?? 0),
        'idCteCabecalho': PlutoCell(value: idCteCabecalho ?? 0),
        'siglaPassagem': PlutoCell(value: siglaPassagem ?? ''),
        'siglaDestino': PlutoCell(value: siglaDestino ?? ''),
        'rota': PlutoCell(value: rota ?? ''),
      },
    );
  }

  CtePassagemModel clone() {
    return CtePassagemModel(
      id: id,
      idCteCabecalho: idCteCabecalho,
      siglaPassagem: siglaPassagem,
      siglaDestino: siglaDestino,
      rota: rota,
    );
  }


}