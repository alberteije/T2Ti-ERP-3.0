import 'dart:convert';
import 'package:pluto_grid/pluto_grid.dart';
import 'package:cte/app/data/model/model_imports.dart';

import 'package:cte/app/infra/infra_imports.dart';
import 'package:intl/intl.dart';
import 'package:cte/app/data/domain/domain_imports.dart';

class CteRodoviarioOccModel extends ModelBase {
  int? id;
  int? idCteRodoviario;
  String? serie;
  int? numero;
  DateTime? dataEmissao;
  String? cnpj;
  String? codigoInterno;
  String? ie;
  String? uf;
  String? telefone;
  CteRodoviarioModel? cteRodoviarioModel;

  CteRodoviarioOccModel({
    this.id,
    this.idCteRodoviario,
    this.serie,
    this.numero,
    this.dataEmissao,
    this.cnpj,
    this.codigoInterno,
    this.ie,
    this.uf = 'AC',
    this.telefone,
    CteRodoviarioModel? cteRodoviarioModel,
  }) {
    this.cteRodoviarioModel = cteRodoviarioModel ?? CteRodoviarioModel();
  }

  static List<String> dbColumns = <String>[
    'id',
    'serie',
    'numero',
    'data_emissao',
    'cnpj',
    'codigo_interno',
    'ie',
    'uf',
    'telefone',
  ];

  static List<String> aliasColumns = <String>[
    'Id',
    'Serie',
    'Numero',
    'Data Emissao',
    'Cnpj',
    'Codigo Interno',
    'Ie',
    'Uf',
    'Telefone',
  ];

  CteRodoviarioOccModel.fromJson(Map<String, dynamic> jsonData) {
    id = jsonData['id'];
    idCteRodoviario = jsonData['idCteRodoviario'];
    serie = jsonData['serie'];
    numero = jsonData['numero'];
    dataEmissao = jsonData['dataEmissao'] != null ? DateTime.tryParse(jsonData['dataEmissao']) : null;
    cnpj = jsonData['cnpj'];
    codigoInterno = jsonData['codigoInterno'];
    ie = jsonData['ie'];
    uf = CteRodoviarioOccDomain.getUf(jsonData['uf']);
    telefone = jsonData['telefone'];
    cteRodoviarioModel = jsonData['cteRodoviarioModel'] == null ? CteRodoviarioModel() : CteRodoviarioModel.fromJson(jsonData['cteRodoviarioModel']);
  }

  Map<String, dynamic> get toJson {
    Map<String, dynamic> jsonData = <String, dynamic>{};

    jsonData['id'] = id != 0 ? id : null;
    jsonData['idCteRodoviario'] = idCteRodoviario != 0 ? idCteRodoviario : null;
    jsonData['serie'] = serie;
    jsonData['numero'] = numero;
    jsonData['dataEmissao'] = dataEmissao != null ? DateFormat('yyyy-MM-ddT00:00:00').format(dataEmissao!) : null;
    jsonData['cnpj'] = Util.removeMask(cnpj);
    jsonData['codigoInterno'] = codigoInterno;
    jsonData['ie'] = ie;
    jsonData['uf'] = CteRodoviarioOccDomain.setUf(uf);
    jsonData['telefone'] = telefone;
    jsonData['cteRodoviarioModel'] = cteRodoviarioModel?.toJson;
    jsonData['cteRodoviario'] = cteRodoviarioModel?.rntrc ?? '';

    return jsonData;
  }

  String objectEncodeJson() {
    final jsonData = toJson;
    return json.encode(jsonData);
  }

  static CteRodoviarioOccModel fromPlutoRow(PlutoRow row) {
    return CteRodoviarioOccModel(
      id: row.cells['id']?.value,
      idCteRodoviario: row.cells['idCteRodoviario']?.value,
      serie: row.cells['serie']?.value,
      numero: row.cells['numero']?.value,
      dataEmissao: Util.stringToDate(row.cells['dataEmissao']?.value),
      cnpj: row.cells['cnpj']?.value,
      codigoInterno: row.cells['codigoInterno']?.value,
      ie: row.cells['ie']?.value,
      uf: row.cells['uf']?.value,
      telefone: row.cells['telefone']?.value,
    );
  }

  PlutoRow toPlutoRow() {
    return PlutoRow(
      cells: {
        'tempId': PlutoCell(value: tempId),
        'id': PlutoCell(value: id ?? 0),
        'idCteRodoviario': PlutoCell(value: idCteRodoviario ?? 0),
        'serie': PlutoCell(value: serie ?? ''),
        'numero': PlutoCell(value: numero ?? 0),
        'dataEmissao': PlutoCell(value: dataEmissao),
        'cnpj': PlutoCell(value: cnpj ?? ''),
        'codigoInterno': PlutoCell(value: codigoInterno ?? ''),
        'ie': PlutoCell(value: ie ?? ''),
        'uf': PlutoCell(value: uf ?? ''),
        'telefone': PlutoCell(value: telefone ?? ''),
        'cteRodoviario': PlutoCell(value: cteRodoviarioModel?.rntrc ?? ''),
      },
    );
  }

  CteRodoviarioOccModel clone() {
    return CteRodoviarioOccModel(
      id: id,
      idCteRodoviario: idCteRodoviario,
      serie: serie,
      numero: numero,
      dataEmissao: dataEmissao,
      cnpj: cnpj,
      codigoInterno: codigoInterno,
      ie: ie,
      uf: uf,
      telefone: telefone,
      cteRodoviarioModel: cteRodoviarioModel?.clone(),
    );
  }


}