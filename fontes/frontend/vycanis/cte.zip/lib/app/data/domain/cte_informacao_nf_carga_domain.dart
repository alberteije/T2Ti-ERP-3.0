class CteInformacaoNfCargaDomain {
  CteInformacaoNfCargaDomain._();

  static getTipoUnidadeCarga(String? tipoUnidadeCarga) { 
		switch (tipoUnidadeCarga) { 
			case '': 
			case '1': 
				return '1 - Container'; 
			case '2': 
				return '2 - ULD'; 
			case '3': 
				return '3 - Pallet'; 
			case '4': 
				return '4 - Outros'; 
			default: 
				return null; 
		} 
	} 

  static setTipoUnidadeCarga(String? tipoUnidadeCarga) { 
		switch (tipoUnidadeCarga) { 
			case '1 - Container': 
				return '1'; 
			case '2 - ULD': 
				return '2'; 
			case '3 - Pallet': 
				return '3'; 
			case '4 - Outros': 
				return '4'; 
			default: 
				return null; 
		} 
	}


  static final tipoUnidadeCargaListDropdown = ['1 - Container','2 - ULD','3 - Pallet','4 - Outros'];

}