class CteAereoDomain {
  CteAereoDomain._();

  static getTarifaClasse(String? tarifaClasse) { 
		switch (tarifaClasse) { 
			case '': 
			case 'M': 
				return 'Mínima'; 
			case 'G': 
				return 'Geral'; 
			case 'E': 
				return 'Específica'; 
			default: 
				return null; 
		} 
	} 

  static setTarifaClasse(String? tarifaClasse) { 
		switch (tarifaClasse) { 
			case 'Mínima': 
				return 'M'; 
			case 'Geral': 
				return 'G'; 
			case 'Específica': 
				return 'E'; 
			default: 
				return null; 
		} 
	}

  static getCargaInformacaoManuseio(String? cargaInformacaoManuseio) { 
		switch (cargaInformacaoManuseio) { 
			case '': 
			case '0': 
				return '01 - certificado do expedidor para embarque de animal vivo'; 
			case '1': 
				return '02 - artigo perigoso conforme Declaração do Expedidor anexa'; 
			case '2': 
				return '03 - somente em aeronave cargueira'; 
			case '3': 
				return '04 - artigo perigoso - declaração do expedidor não requerida'; 
			case '4': 
				return '05 - artigo perigoso em quantidade isenta'; 
			case '5': 
				return '06 - gelo seco para refrigeração (especificar no campo observações a quantidade)'; 
			case '6': 
				return '07 - não restrito (especificar a Disposição Especial no campo observações)'; 
			case '7': 
				return '08 - artigo perigoso em carga consolidada (especificar a quantidade no campo observações)'; 
			case '8': 
				return '09 - autorização da autoridade governamental anexa (especificar no campo observações)'; 
			case '9': 
				return '10 – baterias de íons de lítio em conformidade com a Seção II da PI965 – CAO'; 
			case '10': 
				return '11 - baterias de íons de lítio em conformidade com a Seção II da PI966'; 
			case '11': 
				return '12 - baterias de íons de lítio em conformidade com a Seção II da PI967'; 
			case '12': 
				return '13 – baterias de metal lítio em conformidade com a Seção II da PI968 — CAO'; 
			case '13': 
				return '14 - baterias de metal lítio em conformidade com a Seção II da PI969'; 
			case '14': 
				return '15 - baterias de metal lítio em conformidade com a Seção II da PI970'; 
			case '15': 
				return '99 - outro (especificar no campo observações)'; 
			default: 
				return null; 
		} 
	} 

  static setCargaInformacaoManuseio(String? cargaInformacaoManuseio) { 
		switch (cargaInformacaoManuseio) { 
			case '01 - certificado do expedidor para embarque de animal vivo': 
				return '0'; 
			case '02 - artigo perigoso conforme Declaração do Expedidor anexa': 
				return '1'; 
			case '03 - somente em aeronave cargueira': 
				return '2'; 
			case '04 - artigo perigoso - declaração do expedidor não requerida': 
				return '3'; 
			case '05 - artigo perigoso em quantidade isenta': 
				return '4'; 
			case '06 - gelo seco para refrigeração (especificar no campo observações a quantidade)': 
				return '5'; 
			case '07 - não restrito (especificar a Disposição Especial no campo observações)': 
				return '6'; 
			case '08 - artigo perigoso em carga consolidada (especificar a quantidade no campo observações)': 
				return '7'; 
			case '09 - autorização da autoridade governamental anexa (especificar no campo observações)': 
				return '8'; 
			case '10 – baterias de íons de lítio em conformidade com a Seção II da PI965 – CAO': 
				return '9'; 
			case '11 - baterias de íons de lítio em conformidade com a Seção II da PI966': 
				return '10'; 
			case '12 - baterias de íons de lítio em conformidade com a Seção II da PI967': 
				return '11'; 
			case '13 – baterias de metal lítio em conformidade com a Seção II da PI968 — CAO': 
				return '12'; 
			case '14 - baterias de metal lítio em conformidade com a Seção II da PI969': 
				return '13'; 
			case '15 - baterias de metal lítio em conformidade com a Seção II da PI970': 
				return '14'; 
			case '99 - outro (especificar no campo observações)': 
				return '15'; 
			default: 
				return null; 
		} 
	}


  static final tarifaClasseListDropdown = ['Mínima','Geral','Específica'];
  static final cargaInformacaoManuseioListDropdown = ['01 - certificado do expedidor para embarque de animal vivo','02 - artigo perigoso conforme Declaração do Expedidor anexa','03 - somente em aeronave cargueira','04 - artigo perigoso - declaração do expedidor não requerida','05 - artigo perigoso em quantidade isenta','06 - gelo seco para refrigeração (especificar no campo observações a quantidade)','07 - não restrito (especificar a Disposição Especial no campo observações)','08 - artigo perigoso em carga consolidada (especificar a quantidade no campo observações)','09 - autorização da autoridade governamental anexa (especificar no campo observações)','10 – baterias de íons de lítio em conformidade com a Seção II da PI965 – CAO','11 - baterias de íons de lítio em conformidade com a Seção II da PI966','12 - baterias de íons de lítio em conformidade com a Seção II da PI967','13 – baterias de metal lítio em conformidade com a Seção II da PI968 — CAO','14 - baterias de metal lítio em conformidade com a Seção II da PI969','15 - baterias de metal lítio em conformidade com a Seção II da PI970','99 - outro (especificar no campo observações)'];

}