class CteAquaviarioBalsaDomain {
  CteAquaviarioBalsaDomain._();

  static getDirecao(String? direcao) { 
		switch (direcao) { 
			case '': 
			case 'N': 
				return 'N-Norte'; 
			case 'L': 
				return 'L-Leste'; 
			case 'S': 
				return 'S-Sul'; 
			case 'O': 
				return 'O-Oeste '; 
			default: 
				return null; 
		} 
	} 

  static setDirecao(String? direcao) { 
		switch (direcao) { 
			case 'N-Norte': 
				return 'N'; 
			case 'L-Leste': 
				return 'L'; 
			case 'S-Sul': 
				return 'S'; 
			case 'O-Oeste ': 
				return 'O'; 
			default: 
				return null; 
		} 
	}

  static getTipoNavegacao(String? tipoNavegacao) { 
		switch (tipoNavegacao) { 
			case '': 
			case '0': 
				return '0-Interior'; 
			case '1': 
				return '1-Cabotagem'; 
			default: 
				return null; 
		} 
	} 

  static setTipoNavegacao(String? tipoNavegacao) { 
		switch (tipoNavegacao) { 
			case '0-Interior': 
				return '0'; 
			case '1-Cabotagem': 
				return '1'; 
			default: 
				return null; 
		} 
	}


  static final direcaoListDropdown = ['N-Norte','L-Leste','S-Sul','O-Oeste '];
  static final tipoNavegacaoListDropdown = ['0-Interior','1-Cabotagem'];

}