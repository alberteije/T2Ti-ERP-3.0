class CteAquaviarioBalsaDomain {
	CteAquaviarioBalsaDomain._();

	static getDirecao(String? direcao) { 
		switch (direcao) { 
			case '': 
			case '0': 
				return 'AAA'; 
			case '1': 
				return 'BBB'; 
			case '2': 
				return 'CCC'; 
			default: 
				return null; 
		} 
	} 

	static setDirecao(String? direcao) { 
		switch (direcao) { 
			case 'AAA': 
				return '0'; 
			case 'BBB': 
				return '1'; 
			case 'CCC': 
				return '2'; 
			default: 
				return null; 
		} 
	}

	static getTipoNavegacao(String? tipoNavegacao) { 
		switch (tipoNavegacao) { 
			case '': 
			case '0': 
				return 'AAA'; 
			case '1': 
				return 'BBB'; 
			case '2': 
				return 'CCC'; 
			default: 
				return null; 
		} 
	} 

	static setTipoNavegacao(String? tipoNavegacao) { 
		switch (tipoNavegacao) { 
			case 'AAA': 
				return '0'; 
			case 'BBB': 
				return '1'; 
			case 'CCC': 
				return '2'; 
			default: 
				return null; 
		} 
	}

}