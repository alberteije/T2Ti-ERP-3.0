class CteCargaDomain {
  CteCargaDomain._();

  static getCodigoUnidadeMedida(String? codigoUnidadeMedida) { 
		switch (codigoUnidadeMedida) { 
			case '': 
			case '0': 
				return '00-M3'; 
			case '1': 
				return '01-KG'; 
			case '2': 
				return '02-TON'; 
			case '3': 
				return '03-UNIDADE'; 
			case '4': 
				return '04-LITROS'; 
			case '5': 
				return '05-MMBTU '; 
			default: 
				return null; 
		} 
	} 

  static setCodigoUnidadeMedida(String? codigoUnidadeMedida) { 
		switch (codigoUnidadeMedida) { 
			case '00-M3': 
				return '0'; 
			case '01-KG': 
				return '1'; 
			case '02-TON': 
				return '2'; 
			case '03-UNIDADE': 
				return '3'; 
			case '04-LITROS': 
				return '4'; 
			case '05-MMBTU ': 
				return '5'; 
			default: 
				return null; 
		} 
	}


  static final codigoUnidadeMedidaListDropdown = ['00-M3','01-KG','02-TON','03-UNIDADE','04-LITROS','05-MMBTU '];

}