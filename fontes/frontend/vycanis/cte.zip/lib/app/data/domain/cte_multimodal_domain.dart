class CteMultimodalDomain {
  CteMultimodalDomain._();

  static getIndicadorNegociavel(String? indicadorNegociavel) { 
		switch (indicadorNegociavel) { 
			case '': 
			case '0': 
				return '0 - Não Negociável'; 
			case '1': 
				return '1 - Negociável '; 
			default: 
				return null; 
		} 
	} 

  static setIndicadorNegociavel(String? indicadorNegociavel) { 
		switch (indicadorNegociavel) { 
			case '0 - Não Negociável': 
				return '0'; 
			case '1 - Negociável ': 
				return '1'; 
			default: 
				return null; 
		} 
	}


  static final indicadorNegociavelListDropdown = ['0 - Não Negociável','1 - Negociável '];

}