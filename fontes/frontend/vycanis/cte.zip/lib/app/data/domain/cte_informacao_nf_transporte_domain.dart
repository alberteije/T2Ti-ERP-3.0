class CteInformacaoNfTransporteDomain {
  CteInformacaoNfTransporteDomain._();

  static getTipoUnidadeTransporte(String? tipoUnidadeTransporte) { 
		switch (tipoUnidadeTransporte) { 
			case '': 
			case '1': 
				return '1 - Rodoviário Tração'; 
			case '2': 
				return '2 - Rodoviário Reboque'; 
			case '3': 
				return '3 - Navio'; 
			case '4': 
				return '4 - Balsa'; 
			case '5': 
				return '5 - Aeronave'; 
			case '6': 
				return '6 - Vagão'; 
			case '7': 
				return '7 - Outros'; 
			default: 
				return null; 
		} 
	} 

  static setTipoUnidadeTransporte(String? tipoUnidadeTransporte) { 
		switch (tipoUnidadeTransporte) { 
			case '1 - Rodoviário Tração': 
				return '1'; 
			case '2 - Rodoviário Reboque': 
				return '2'; 
			case '3 - Navio': 
				return '3'; 
			case '4 - Balsa': 
				return '4'; 
			case '5 - Aeronave': 
				return '5'; 
			case '6 - Vagão': 
				return '6'; 
			case '7 - Outros': 
				return '7'; 
			default: 
				return null; 
		} 
	}


  static final tipoUnidadeTransporteListDropdown = ['1 - Rodoviário Tração','2 - Rodoviário Reboque','3 - Navio','4 - Balsa','5 - Aeronave','6 - Vagão','7 - Outros'];

}