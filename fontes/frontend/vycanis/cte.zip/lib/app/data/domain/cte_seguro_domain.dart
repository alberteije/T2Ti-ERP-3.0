class CteSeguroDomain {
  CteSeguroDomain._();

  static getResponsavel(String? responsavel) { 
		switch (responsavel) { 
			case '': 
			case '4': 
				return '4 - Emitente do CTe'; 
			case '5': 
				return '5 - Tomador de Serviço'; 
			default: 
				return null; 
		} 
	} 

  static setResponsavel(String? responsavel) { 
		switch (responsavel) { 
			case '4 - Emitente do CTe': 
				return '4'; 
			case '5 - Tomador de Serviço': 
				return '5'; 
			default: 
				return null; 
		} 
	}


  static final responsavelListDropdown = ['4 - Emitente do CTe','5 - Tomador de Serviço'];

}