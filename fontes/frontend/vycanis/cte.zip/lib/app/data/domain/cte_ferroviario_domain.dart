class CteFerroviarioDomain {
  CteFerroviarioDomain._();

  static getTipoTrafego(String? tipoTrafego) { 
		switch (tipoTrafego) { 
			case '': 
			case '0': 
				return '0-Próprio'; 
			case '1': 
				return '1-Mútuo'; 
			case '2': 
				return '2-Rodoferroviário'; 
			case '3': 
				return '3-Rodoviário'; 
			default: 
				return null; 
		} 
	} 

  static setTipoTrafego(String? tipoTrafego) { 
		switch (tipoTrafego) { 
			case '0-Próprio': 
				return '0'; 
			case '1-Mútuo': 
				return '1'; 
			case '2-Rodoferroviário': 
				return '2'; 
			case '3-Rodoviário': 
				return '3'; 
			default: 
				return null; 
		} 
	}

  static getResponsavelFaturamento(String? responsavelFaturamento) { 
		switch (responsavelFaturamento) { 
			case '': 
			case '1': 
				return '1-Ferrovia de origem'; 
			case '2': 
				return '2-Ferrovia de destino'; 
			default: 
				return null; 
		} 
	} 

  static setResponsavelFaturamento(String? responsavelFaturamento) { 
		switch (responsavelFaturamento) { 
			case '1-Ferrovia de origem': 
				return '1'; 
			case '2-Ferrovia de destino': 
				return '2'; 
			default: 
				return null; 
		} 
	}

  static getFerroviaEmitenteCte(String? ferroviaEmitenteCte) { 
		switch (ferroviaEmitenteCte) { 
			case '': 
			case '1': 
				return '1-Ferrovia de origem'; 
			case '2': 
				return '2-Ferrovia de destino'; 
			default: 
				return null; 
		} 
	} 

  static setFerroviaEmitenteCte(String? ferroviaEmitenteCte) { 
		switch (ferroviaEmitenteCte) { 
			case '1-Ferrovia de origem': 
				return '1'; 
			case '2-Ferrovia de destino': 
				return '2'; 
			default: 
				return null; 
		} 
	}


  static final tipoTrafegoListDropdown = ['0-Próprio','1-Mútuo','2-Rodoferroviário','3-Rodoviário'];
  static final responsavelFaturamentoListDropdown = ['1-Ferrovia de origem','2-Ferrovia de destino'];
  static final ferroviaEmitenteCteListDropdown = ['1-Ferrovia de origem','2-Ferrovia de destino'];

}