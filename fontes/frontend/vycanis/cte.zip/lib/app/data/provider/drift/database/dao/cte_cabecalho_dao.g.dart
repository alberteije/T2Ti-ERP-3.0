// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'cte_cabecalho_dao.dart';

// ignore_for_file: type=lint
mixin _$CteCabecalhoDaoMixin on DatabaseAccessor<AppDatabase> {
  $CteCabecalhosTable get cteCabecalhos => attachedDatabase.cteCabecalhos;
  $CteEmitentesTable get cteEmitentes => attachedDatabase.cteEmitentes;
  $CteLocalColetasTable get cteLocalColetas => attachedDatabase.cteLocalColetas;
  $CteTomadorsTable get cteTomadors => attachedDatabase.cteTomadors;
  $CtePassagemsTable get ctePassagems => attachedDatabase.ctePassagems;
  $CteRemetentesTable get cteRemetentes => attachedDatabase.cteRemetentes;
  $CteExpedidorsTable get cteExpedidors => attachedDatabase.cteExpedidors;
  $CteRecebedorsTable get cteRecebedors => attachedDatabase.cteRecebedors;
  $CteDestinatariosTable get cteDestinatarios =>
      attachedDatabase.cteDestinatarios;
  $CteLocalEntregasTable get cteLocalEntregas =>
      attachedDatabase.cteLocalEntregas;
  $CteComponentesTable get cteComponentes => attachedDatabase.cteComponentes;
  $CteCargasTable get cteCargas => attachedDatabase.cteCargas;
  $CteInformacaoNfOutrossTable get cteInformacaoNfOutross =>
      attachedDatabase.cteInformacaoNfOutross;
  $CteSegurosTable get cteSeguros => attachedDatabase.cteSeguros;
  $CtePerigososTable get ctePerigosos => attachedDatabase.ctePerigosos;
  $CteVeiculoNovosTable get cteVeiculoNovos => attachedDatabase.cteVeiculoNovos;
  $CteFaturasTable get cteFaturas => attachedDatabase.cteFaturas;
  $CteDuplicatasTable get cteDuplicatas => attachedDatabase.cteDuplicatas;
  $CteRodoviariosTable get cteRodoviarios => attachedDatabase.cteRodoviarios;
  $CteAereosTable get cteAereos => attachedDatabase.cteAereos;
  $CteAquaviariosTable get cteAquaviarios => attachedDatabase.cteAquaviarios;
  $CteFerroviariosTable get cteFerroviarios => attachedDatabase.cteFerroviarios;
  $CteDutoviariosTable get cteDutoviarios => attachedDatabase.cteDutoviarios;
  $CteMultimodalsTable get cteMultimodals => attachedDatabase.cteMultimodals;
}
