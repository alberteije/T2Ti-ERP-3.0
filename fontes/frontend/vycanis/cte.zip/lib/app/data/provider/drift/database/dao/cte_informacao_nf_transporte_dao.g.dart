// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'cte_informacao_nf_transporte_dao.dart';

// ignore_for_file: type=lint
mixin _$CteInformacaoNfTransporteDaoMixin on DatabaseAccessor<AppDatabase> {
  $CteInformacaoNfTransportesTable get cteInformacaoNfTransportes =>
      attachedDatabase.cteInformacaoNfTransportes;
  $CteInformacaoNfOutrossTable get cteInformacaoNfOutross =>
      attachedDatabase.cteInformacaoNfOutross;
}
