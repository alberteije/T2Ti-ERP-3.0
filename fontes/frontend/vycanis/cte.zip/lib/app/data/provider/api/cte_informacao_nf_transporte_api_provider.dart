import 'package:cte/app/data/provider/api/api_provider_base.dart';
import 'package:cte/app/data/model/model_imports.dart';

class CteInformacaoNfTransporteApiProvider extends ApiProviderBase {
  static const _path = '/cte-informacao-nf-transporte';

  Future<List<CteInformacaoNfTransporteModel>?> getList({Filter? filter}) {
    return super.getListBase(
      '$_path/',
      (json) => CteInformacaoNfTransporteModel.fromJson(json),
      filter: filter,
    );
  }

  Future<CteInformacaoNfTransporteModel?> getObject(dynamic pk) {
    return super.getObjectBase(
      _path,
      pk,
      (json) => CteInformacaoNfTransporteModel.fromJson(json),
    );
  }

  Future<CteInformacaoNfTransporteModel?>? insert(CteInformacaoNfTransporteModel model) {
    return super.insertBase(
      _path,
      model,
      (json) => CteInformacaoNfTransporteModel.fromJson(json),
    );
  }

  Future<CteInformacaoNfTransporteModel?>? update(CteInformacaoNfTransporteModel model) {
    return super.updateBase(
      _path,
      model,
      (json) => CteInformacaoNfTransporteModel.fromJson(json),
    );
  }

  Future<bool?> delete(dynamic pk) {
    return super.deleteBase(_path, pk);
  }
}
