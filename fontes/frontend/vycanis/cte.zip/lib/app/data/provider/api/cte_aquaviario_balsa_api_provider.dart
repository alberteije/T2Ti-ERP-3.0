import 'package:cte/app/data/provider/api/api_provider_base.dart';
import 'package:cte/app/data/model/model_imports.dart';

class CteAquaviarioBalsaApiProvider extends ApiProviderBase {
  static const _path = '/cte-aquaviario-balsa';

  Future<List<CteAquaviarioBalsaModel>?> getList({Filter? filter}) {
    return super.getListBase(
      '$_path/',
      (json) => CteAquaviarioBalsaModel.fromJson(json),
      filter: filter,
    );
  }

  Future<CteAquaviarioBalsaModel?> getObject(dynamic pk) {
    return super.getObjectBase(
      _path,
      pk,
      (json) => CteAquaviarioBalsaModel.fromJson(json),
    );
  }

  Future<CteAquaviarioBalsaModel?>? insert(CteAquaviarioBalsaModel model) {
    return super.insertBase(
      _path,
      model,
      (json) => CteAquaviarioBalsaModel.fromJson(json),
    );
  }

  Future<CteAquaviarioBalsaModel?>? update(CteAquaviarioBalsaModel model) {
    return super.updateBase(
      _path,
      model,
      (json) => CteAquaviarioBalsaModel.fromJson(json),
    );
  }

  Future<bool?> delete(dynamic pk) {
    return super.deleteBase(_path, pk);
  }
}
