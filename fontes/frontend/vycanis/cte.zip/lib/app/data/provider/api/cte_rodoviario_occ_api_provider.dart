import 'package:cte/app/data/provider/api/api_provider_base.dart';
import 'package:cte/app/data/model/model_imports.dart';

class CteRodoviarioOccApiProvider extends ApiProviderBase {
  static const _path = '/cte-rodoviario-occ';

  Future<List<CteRodoviarioOccModel>?> getList({Filter? filter}) {
    return super.getListBase(
      '$_path/',
      (json) => CteRodoviarioOccModel.fromJson(json),
      filter: filter,
    );
  }

  Future<CteRodoviarioOccModel?> getObject(dynamic pk) {
    return super.getObjectBase(
      _path,
      pk,
      (json) => CteRodoviarioOccModel.fromJson(json),
    );
  }

  Future<CteRodoviarioOccModel?>? insert(CteRodoviarioOccModel model) {
    return super.insertBase(
      _path,
      model,
      (json) => CteRodoviarioOccModel.fromJson(json),
    );
  }

  Future<CteRodoviarioOccModel?>? update(CteRodoviarioOccModel model) {
    return super.updateBase(
      _path,
      model,
      (json) => CteRodoviarioOccModel.fromJson(json),
    );
  }

  Future<bool?> delete(dynamic pk) {
    return super.deleteBase(_path, pk);
  }
}
