// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'cte_ferroviario_ferrovia_dao.dart';

// ignore_for_file: type=lint
mixin _$CteFerroviarioFerroviaDaoMixin on DatabaseAccessor<AppDatabase> {
  $CteFerroviarioFerroviasTable get cteFerroviarioFerrovias =>
      attachedDatabase.cteFerroviarioFerrovias;
  $CteFerroviariosTable get cteFerroviarios => attachedDatabase.cteFerroviarios;
}
