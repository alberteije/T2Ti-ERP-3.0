import 'dart:convert';

import 'package:cte/app/data/provider/api/api_provider_base.dart';
import 'package:cte/app/data/model/model_imports.dart';

class CteCabecalhoApiProvider extends ApiProviderBase {
  static const _path = '/cte-cabecalho';

  Future<List<CteCabecalhoModel>?> getList({Filter? filter}) {
    return super.getListBase(
      '$_path/',
      (json) => CteCabecalhoModel.fromJson(json),
      filter: filter,
    );
  }

  Future<CteCabecalhoModel?> getObject(dynamic pk) {
    return super.getObjectBase(
      _path,
      pk,
      (json) => CteCabecalhoModel.fromJson(json),
    );
  }

  Future<CteCabecalhoModel?>? insert(CteCabecalhoModel model) {
    return super.insertBase(
      _path,
      model,
      (json) => CteCabecalhoModel.fromJson(json),
    );
  }

  Future<CteCabecalhoModel?>? update(CteCabecalhoModel model) {
    return super.updateBase(
      _path,
      model,
      (json) => CteCabecalhoModel.fromJson(json),
    );
  }

  Future<bool?> delete(dynamic pk) {
    return super.deleteBase(_path, pk);
  }

  Future<dynamic> transmitirCte(CteCabecalhoModel cteCabecalhoModel) async {
    try {
      final response = await ApiProviderBase.httpClient.post(
        Uri.tryParse('$endpoint/cte-cabecalho/transmite-cte/')!,
				headers: ApiProviderBase.headerRequisition(),
				body: cteCabecalhoModel.objectEncodeJson(),
      );

      if (response.statusCode == 200 || response.statusCode == 201) {
        if (response.headers["content-type"]!.contains("html")) {
          handleResultError(response.body, response.headers);
          return null;
        } else {
          final pdf = response.bodyBytes;
          return pdf;
        }
      } else if (response.statusCode == 418) {
        return json.decode(response.body)["message"];
      } else {
        handleResultError(response.body, response.headers);
        return null;
      }
    } on Exception catch (e) {
      handleResultError(null, null, exception: e);
    }
    return null;
  }

}
