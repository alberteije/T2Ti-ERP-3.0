// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'cte_rodoviario_pedagio_dao.dart';

// ignore_for_file: type=lint
mixin _$CteRodoviarioPedagioDaoMixin on DatabaseAccessor<AppDatabase> {
  $CteRodoviarioPedagiosTable get cteRodoviarioPedagios =>
      attachedDatabase.cteRodoviarioPedagios;
  $CteRodoviariosTable get cteRodoviarios => attachedDatabase.cteRodoviarios;
}
