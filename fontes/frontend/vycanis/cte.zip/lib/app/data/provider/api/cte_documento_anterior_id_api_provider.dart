import 'package:cte/app/data/provider/api/api_provider_base.dart';
import 'package:cte/app/data/model/model_imports.dart';

class CteDocumentoAnteriorIdApiProvider extends ApiProviderBase {
  static const _path = '/cte-documento-anterior-id';

  Future<List<CteDocumentoAnteriorIdModel>?> getList({Filter? filter}) {
    return super.getListBase(
      '$_path/',
      (json) => CteDocumentoAnteriorIdModel.fromJson(json),
      filter: filter,
    );
  }

  Future<CteDocumentoAnteriorIdModel?> getObject(dynamic pk) {
    return super.getObjectBase(
      _path,
      pk,
      (json) => CteDocumentoAnteriorIdModel.fromJson(json),
    );
  }

  Future<CteDocumentoAnteriorIdModel?>? insert(CteDocumentoAnteriorIdModel model) {
    return super.insertBase(
      _path,
      model,
      (json) => CteDocumentoAnteriorIdModel.fromJson(json),
    );
  }

  Future<CteDocumentoAnteriorIdModel?>? update(CteDocumentoAnteriorIdModel model) {
    return super.updateBase(
      _path,
      model,
      (json) => CteDocumentoAnteriorIdModel.fromJson(json),
    );
  }

  Future<bool?> delete(dynamic pk) {
    return super.deleteBase(_path, pk);
  }
}
