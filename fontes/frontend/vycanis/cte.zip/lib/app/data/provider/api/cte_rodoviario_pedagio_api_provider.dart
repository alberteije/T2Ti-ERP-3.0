import 'package:cte/app/data/provider/api/api_provider_base.dart';
import 'package:cte/app/data/model/model_imports.dart';

class CteRodoviarioPedagioApiProvider extends ApiProviderBase {
  static const _path = '/cte-rodoviario-pedagio';

  Future<List<CteRodoviarioPedagioModel>?> getList({Filter? filter}) {
    return super.getListBase(
      '$_path/',
      (json) => CteRodoviarioPedagioModel.fromJson(json),
      filter: filter,
    );
  }

  Future<CteRodoviarioPedagioModel?> getObject(dynamic pk) {
    return super.getObjectBase(
      _path,
      pk,
      (json) => CteRodoviarioPedagioModel.fromJson(json),
    );
  }

  Future<CteRodoviarioPedagioModel?>? insert(CteRodoviarioPedagioModel model) {
    return super.insertBase(
      _path,
      model,
      (json) => CteRodoviarioPedagioModel.fromJson(json),
    );
  }

  Future<CteRodoviarioPedagioModel?>? update(CteRodoviarioPedagioModel model) {
    return super.updateBase(
      _path,
      model,
      (json) => CteRodoviarioPedagioModel.fromJson(json),
    );
  }

  Future<bool?> delete(dynamic pk) {
    return super.deleteBase(_path, pk);
  }
}
