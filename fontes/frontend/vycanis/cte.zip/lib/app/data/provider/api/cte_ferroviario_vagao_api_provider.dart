import 'package:cte/app/data/provider/api/api_provider_base.dart';
import 'package:cte/app/data/model/model_imports.dart';

class CteFerroviarioVagaoApiProvider extends ApiProviderBase {
  static const _path = '/cte-ferroviario-vagao';

  Future<List<CteFerroviarioVagaoModel>?> getList({Filter? filter}) {
    return super.getListBase(
      '$_path/',
      (json) => CteFerroviarioVagaoModel.fromJson(json),
      filter: filter,
    );
  }

  Future<CteFerroviarioVagaoModel?> getObject(dynamic pk) {
    return super.getObjectBase(
      _path,
      pk,
      (json) => CteFerroviarioVagaoModel.fromJson(json),
    );
  }

  Future<CteFerroviarioVagaoModel?>? insert(CteFerroviarioVagaoModel model) {
    return super.insertBase(
      _path,
      model,
      (json) => CteFerroviarioVagaoModel.fromJson(json),
    );
  }

  Future<CteFerroviarioVagaoModel?>? update(CteFerroviarioVagaoModel model) {
    return super.updateBase(
      _path,
      model,
      (json) => CteFerroviarioVagaoModel.fromJson(json),
    );
  }

  Future<bool?> delete(dynamic pk) {
    return super.deleteBase(_path, pk);
  }
}
