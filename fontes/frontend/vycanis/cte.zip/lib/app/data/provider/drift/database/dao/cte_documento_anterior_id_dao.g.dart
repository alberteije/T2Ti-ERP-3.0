// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'cte_documento_anterior_id_dao.dart';

// ignore_for_file: type=lint
mixin _$CteDocumentoAnteriorIdDaoMixin on DatabaseAccessor<AppDatabase> {
  $CteDocumentoAnteriorIdsTable get cteDocumentoAnteriorIds =>
      attachedDatabase.cteDocumentoAnteriorIds;
}
