import 'package:cte/app/data/provider/api/api_provider_base.dart';
import 'package:cte/app/data/model/model_imports.dart';

class CteInfNfTransporteLacreApiProvider extends ApiProviderBase {
  static const _path = '/cte-inf-nf-transporte-lacre';

  Future<List<CteInfNfTransporteLacreModel>?> getList({Filter? filter}) {
    return super.getListBase(
      '$_path/',
      (json) => CteInfNfTransporteLacreModel.fromJson(json),
      filter: filter,
    );
  }

  Future<CteInfNfTransporteLacreModel?> getObject(dynamic pk) {
    return super.getObjectBase(
      _path,
      pk,
      (json) => CteInfNfTransporteLacreModel.fromJson(json),
    );
  }

  Future<CteInfNfTransporteLacreModel?>? insert(CteInfNfTransporteLacreModel model) {
    return super.insertBase(
      _path,
      model,
      (json) => CteInfNfTransporteLacreModel.fromJson(json),
    );
  }

  Future<CteInfNfTransporteLacreModel?>? update(CteInfNfTransporteLacreModel model) {
    return super.updateBase(
      _path,
      model,
      (json) => CteInfNfTransporteLacreModel.fromJson(json),
    );
  }

  Future<bool?> delete(dynamic pk) {
    return super.deleteBase(_path, pk);
  }
}
