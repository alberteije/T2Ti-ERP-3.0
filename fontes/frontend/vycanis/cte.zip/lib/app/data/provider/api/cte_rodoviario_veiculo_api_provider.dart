import 'package:cte/app/data/provider/api/api_provider_base.dart';
import 'package:cte/app/data/model/model_imports.dart';

class CteRodoviarioVeiculoApiProvider extends ApiProviderBase {
  static const _path = '/cte-rodoviario-veiculo';

  Future<List<CteRodoviarioVeiculoModel>?> getList({Filter? filter}) {
    return super.getListBase(
      '$_path/',
      (json) => CteRodoviarioVeiculoModel.fromJson(json),
      filter: filter,
    );
  }

  Future<CteRodoviarioVeiculoModel?> getObject(dynamic pk) {
    return super.getObjectBase(
      _path,
      pk,
      (json) => CteRodoviarioVeiculoModel.fromJson(json),
    );
  }

  Future<CteRodoviarioVeiculoModel?>? insert(CteRodoviarioVeiculoModel model) {
    return super.insertBase(
      _path,
      model,
      (json) => CteRodoviarioVeiculoModel.fromJson(json),
    );
  }

  Future<CteRodoviarioVeiculoModel?>? update(CteRodoviarioVeiculoModel model) {
    return super.updateBase(
      _path,
      model,
      (json) => CteRodoviarioVeiculoModel.fromJson(json),
    );
  }

  Future<bool?> delete(dynamic pk) {
    return super.deleteBase(_path, pk);
  }
}
