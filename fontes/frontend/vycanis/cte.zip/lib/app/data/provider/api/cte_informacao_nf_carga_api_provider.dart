import 'package:cte/app/data/provider/api/api_provider_base.dart';
import 'package:cte/app/data/model/model_imports.dart';

class CteInformacaoNfCargaApiProvider extends ApiProviderBase {
  static const _path = '/cte-informacao-nf-carga';

  Future<List<CteInformacaoNfCargaModel>?> getList({Filter? filter}) {
    return super.getListBase(
      '$_path/',
      (json) => CteInformacaoNfCargaModel.fromJson(json),
      filter: filter,
    );
  }

  Future<CteInformacaoNfCargaModel?> getObject(dynamic pk) {
    return super.getObjectBase(
      _path,
      pk,
      (json) => CteInformacaoNfCargaModel.fromJson(json),
    );
  }

  Future<CteInformacaoNfCargaModel?>? insert(CteInformacaoNfCargaModel model) {
    return super.insertBase(
      _path,
      model,
      (json) => CteInformacaoNfCargaModel.fromJson(json),
    );
  }

  Future<CteInformacaoNfCargaModel?>? update(CteInformacaoNfCargaModel model) {
    return super.updateBase(
      _path,
      model,
      (json) => CteInformacaoNfCargaModel.fromJson(json),
    );
  }

  Future<bool?> delete(dynamic pk) {
    return super.deleteBase(_path, pk);
  }
}
