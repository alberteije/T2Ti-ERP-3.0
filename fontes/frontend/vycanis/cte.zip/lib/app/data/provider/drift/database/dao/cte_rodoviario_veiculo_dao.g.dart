// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'cte_rodoviario_veiculo_dao.dart';

// ignore_for_file: type=lint
mixin _$CteRodoviarioVeiculoDaoMixin on DatabaseAccessor<AppDatabase> {
  $CteRodoviarioVeiculosTable get cteRodoviarioVeiculos =>
      attachedDatabase.cteRodoviarioVeiculos;
  $CteRodoviariosTable get cteRodoviarios => attachedDatabase.cteRodoviarios;
}
