import 'package:cte/app/data/provider/api/api_provider_base.dart';
import 'package:cte/app/data/model/model_imports.dart';

class CteInfNfCargaLacreApiProvider extends ApiProviderBase {
  static const _path = '/cte-inf-nf-carga-lacre';

  Future<List<CteInfNfCargaLacreModel>?> getList({Filter? filter}) {
    return super.getListBase(
      '$_path/',
      (json) => CteInfNfCargaLacreModel.fromJson(json),
      filter: filter,
    );
  }

  Future<CteInfNfCargaLacreModel?> getObject(dynamic pk) {
    return super.getObjectBase(
      _path,
      pk,
      (json) => CteInfNfCargaLacreModel.fromJson(json),
    );
  }

  Future<CteInfNfCargaLacreModel?>? insert(CteInfNfCargaLacreModel model) {
    return super.insertBase(
      _path,
      model,
      (json) => CteInfNfCargaLacreModel.fromJson(json),
    );
  }

  Future<CteInfNfCargaLacreModel?>? update(CteInfNfCargaLacreModel model) {
    return super.updateBase(
      _path,
      model,
      (json) => CteInfNfCargaLacreModel.fromJson(json),
    );
  }

  Future<bool?> delete(dynamic pk) {
    return super.deleteBase(_path, pk);
  }
}
