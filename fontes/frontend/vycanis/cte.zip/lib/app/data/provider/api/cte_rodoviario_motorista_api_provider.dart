import 'package:cte/app/data/provider/api/api_provider_base.dart';
import 'package:cte/app/data/model/model_imports.dart';

class CteRodoviarioMotoristaApiProvider extends ApiProviderBase {
  static const _path = '/cte-rodoviario-motorista';

  Future<List<CteRodoviarioMotoristaModel>?> getList({Filter? filter}) {
    return super.getListBase(
      '$_path/',
      (json) => CteRodoviarioMotoristaModel.fromJson(json),
      filter: filter,
    );
  }

  Future<CteRodoviarioMotoristaModel?> getObject(dynamic pk) {
    return super.getObjectBase(
      _path,
      pk,
      (json) => CteRodoviarioMotoristaModel.fromJson(json),
    );
  }

  Future<CteRodoviarioMotoristaModel?>? insert(CteRodoviarioMotoristaModel model) {
    return super.insertBase(
      _path,
      model,
      (json) => CteRodoviarioMotoristaModel.fromJson(json),
    );
  }

  Future<CteRodoviarioMotoristaModel?>? update(CteRodoviarioMotoristaModel model) {
    return super.updateBase(
      _path,
      model,
      (json) => CteRodoviarioMotoristaModel.fromJson(json),
    );
  }

  Future<bool?> delete(dynamic pk) {
    return super.deleteBase(_path, pk);
  }
}
