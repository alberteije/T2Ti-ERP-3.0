// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'cte_rodoviario_lacre_dao.dart';

// ignore_for_file: type=lint
mixin _$CteRodoviarioLacreDaoMixin on DatabaseAccessor<AppDatabase> {
  $CteRodoviarioLacresTable get cteRodoviarioLacres =>
      attachedDatabase.cteRodoviarioLacres;
  $CteRodoviariosTable get cteRodoviarios => attachedDatabase.cteRodoviarios;
}
