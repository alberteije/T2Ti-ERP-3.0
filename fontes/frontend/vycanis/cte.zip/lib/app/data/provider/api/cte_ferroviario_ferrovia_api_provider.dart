import 'package:cte/app/data/provider/api/api_provider_base.dart';
import 'package:cte/app/data/model/model_imports.dart';

class CteFerroviarioFerroviaApiProvider extends ApiProviderBase {
  static const _path = '/cte-ferroviario-ferrovia';

  Future<List<CteFerroviarioFerroviaModel>?> getList({Filter? filter}) {
    return super.getListBase(
      '$_path/',
      (json) => CteFerroviarioFerroviaModel.fromJson(json),
      filter: filter,
    );
  }

  Future<CteFerroviarioFerroviaModel?> getObject(dynamic pk) {
    return super.getObjectBase(
      _path,
      pk,
      (json) => CteFerroviarioFerroviaModel.fromJson(json),
    );
  }

  Future<CteFerroviarioFerroviaModel?>? insert(CteFerroviarioFerroviaModel model) {
    return super.insertBase(
      _path,
      model,
      (json) => CteFerroviarioFerroviaModel.fromJson(json),
    );
  }

  Future<CteFerroviarioFerroviaModel?>? update(CteFerroviarioFerroviaModel model) {
    return super.updateBase(
      _path,
      model,
      (json) => CteFerroviarioFerroviaModel.fromJson(json),
    );
  }

  Future<bool?> delete(dynamic pk) {
    return super.deleteBase(_path, pk);
  }
}
