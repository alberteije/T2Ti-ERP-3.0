import 'package:cte/app/data/provider/api/api_provider_base.dart';
import 'package:cte/app/data/model/model_imports.dart';

class CteRodoviarioLacreApiProvider extends ApiProviderBase {
  static const _path = '/cte-rodoviario-lacre';

  Future<List<CteRodoviarioLacreModel>?> getList({Filter? filter}) {
    return super.getListBase(
      '$_path/',
      (json) => CteRodoviarioLacreModel.fromJson(json),
      filter: filter,
    );
  }

  Future<CteRodoviarioLacreModel?> getObject(dynamic pk) {
    return super.getObjectBase(
      _path,
      pk,
      (json) => CteRodoviarioLacreModel.fromJson(json),
    );
  }

  Future<CteRodoviarioLacreModel?>? insert(CteRodoviarioLacreModel model) {
    return super.insertBase(
      _path,
      model,
      (json) => CteRodoviarioLacreModel.fromJson(json),
    );
  }

  Future<CteRodoviarioLacreModel?>? update(CteRodoviarioLacreModel model) {
    return super.updateBase(
      _path,
      model,
      (json) => CteRodoviarioLacreModel.fromJson(json),
    );
  }

  Future<bool?> delete(dynamic pk) {
    return super.deleteBase(_path, pk);
  }
}
