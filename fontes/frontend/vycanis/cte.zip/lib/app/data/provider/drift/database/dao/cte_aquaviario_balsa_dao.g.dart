// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'cte_aquaviario_balsa_dao.dart';

// ignore_for_file: type=lint
mixin _$CteAquaviarioBalsaDaoMixin on DatabaseAccessor<AppDatabase> {
  $CteAquaviarioBalsasTable get cteAquaviarioBalsas =>
      attachedDatabase.cteAquaviarioBalsas;
  $CteAquaviariosTable get cteAquaviarios => attachedDatabase.cteAquaviarios;
}
