import 'package:flutter/material.dart';
import 'dart:math';
import 'package:get/get.dart';
import 'package:extended_masked_text/extended_masked_text.dart';
import 'package:projetos/app/page/shared_widget/input/input_imports.dart';
import 'package:url_launcher/url_launcher.dart';

import 'package:projetos/app/infra/infra_imports.dart';
import 'package:projetos/app/page/page_imports.dart';
import 'package:projetos/app/page/shared_widget/message_dialog.dart';
import 'package:projetos/app/page/grid_columns/grid_columns_imports.dart';
import 'package:projetos/app/routes/app_routes.dart';
import 'package:projetos/app/controller/controller_imports.dart';
import 'package:projetos/app/data/model/model_imports.dart';
import 'package:projetos/app/data/repository/projeto_principal_repository.dart';

class ProjetoPrincipalController extends ControllerBase<ProjetoPrincipalModel, ProjetoPrincipalRepository> 
with GetSingleTickerProviderStateMixin {

  ProjetoPrincipalController({required super.repository}) {
    dbColumns = ProjetoPrincipalModel.dbColumns;
    aliasColumns = ProjetoPrincipalModel.aliasColumns;
    gridColumns = projetoPrincipalGridColumns();
    functionName = "projeto_principal";
    screenTitle = "Projeto";
  }

  final projetoPrincipalScaffoldKey = GlobalKey<ScaffoldState>();
  final projetoPrincipalTabPageScaffoldKey = GlobalKey<ScaffoldState>();
  final projetoPrincipalFormKey = GlobalKey<FormState>();
  late TabController tabController;
  String? mandatoryMessage;  

  @override
  ProjetoPrincipalModel createNewModel() => ProjetoPrincipalModel();

  @override
  final standardFieldForFilter = ProjetoPrincipalModel.aliasColumns[ProjetoPrincipalModel.dbColumns.indexOf('nome')];

  final nomeController = TextEditingController();
  final dataInicioController = DatePickerItemController(null);
  final dataPrevisaoFimController = DatePickerItemController(null);
  final dataFimController = DatePickerItemController(null);
  final valorOrcamentoController = MoneyMaskedTextController();
  final linkQuadroKanbanController = TextEditingController();
  final observacaoController = TextEditingController();

  final Map<String, dynamic> mobileConfig = {
    'primaryColumns': ['nome'],
    'secondaryColumns': ['data_inicio'],
  };

  List<Map<String, dynamic>> get mobileItems {
    return modelList.map((projetoPrincipal) => projetoPrincipal.toJson).toList();
  }

  @override
  void prepareForInsert() {
    isNewRecord = true;
    currentModel = createNewModel();
    _resetForm();
    tabController.animateTo(0);
    updateControllersFromModel();
    Get.toNamed(Routes.projetoPrincipalTabPage);
  }

  void _resetForm() {
    formWasChanged = false;
    nomeController.text = '';
    dataInicioController.date = null;
    dataPrevisaoFimController.date = null;
    dataFimController.date = null;
    valorOrcamentoController.updateValue(0);
    linkQuadroKanbanController.text = '';
    observacaoController.text = '';
  }

  @override
  void selectRowForEditingById(int id) {
    final model = modelList.firstWhere((m) => m.id == id);
    currentModel = model.clone();
    updateControllersFromModel();
    tabController.animateTo(0);
    Get.toNamed(Routes.projetoPrincipalTabPage);
  }

  _configureChildrenControllers() {
    //Cronograma
		Get.put<ProjetoCronogramaController>(ProjetoCronogramaController()); 

    //Riscos
		Get.put<ProjetoRiscoController>(ProjetoRiscoController()); 

    //Custos
		Get.put<ProjetoCustoController>(ProjetoCustoController()); 

    //Stakeholders
		Get.put<ProjetoStakeholdersController>(ProjetoStakeholdersController()); 

  }
	
	_releaseChildrenControllers() {
    //Cronograma
		Get.delete<ProjetoCronogramaController>(); 

    //Riscos
		Get.delete<ProjetoRiscoController>(); 

    //Custos
		Get.delete<ProjetoCustoController>(); 

    //Stakeholders
		Get.delete<ProjetoStakeholdersController>(); 

	}
  
  void updateControllersFromModel() {
    nomeController.text = currentModel.nome ?? '';
    dataInicioController.date = currentModel.dataInicio;
    dataPrevisaoFimController.date = currentModel.dataPrevisaoFim;
    dataFimController.date = currentModel.dataFim;
    valorOrcamentoController.updateValue(currentModel.valorOrcamento ?? 0);
    linkQuadroKanbanController.text = currentModel.linkQuadroKanban ?? '';
    observacaoController.text = currentModel.observacao ?? '';

    formWasChanged = false;
    _updateChildrenControllersFromModel();
  }

  void _updateChildrenControllersFromModel() {
    //Cronograma
		final projetoCronogramaController = Get.find<ProjetoCronogramaController>(); 
		projetoCronogramaController.userMadeChanges = false; 

    //Riscos
		final projetoRiscoController = Get.find<ProjetoRiscoController>(); 
		projetoRiscoController.userMadeChanges = false; 

    //Custos
		final projetoCustoController = Get.find<ProjetoCustoController>(); 
		projetoCustoController.userMadeChanges = false; 

    //Stakeholders
		final projetoStakeholdersController = Get.find<ProjetoStakeholdersController>(); 
		projetoStakeholdersController.userMadeChanges = false; 

  }

  @override
  Future<void> save() async {
    if (!validateCurrentForm()) return;
    if (validateForms()) {
      if (userMadeChanges()) {
        final existingIndex = modelList.indexWhere((m) => m.id == currentModel.id);

        if (existingIndex >= 0) {
          modelList[existingIndex] = currentModel.clone();
        }

        final result = await repository.save(projetoPrincipalModel: currentModel);
        if (result == null) return;

        if (existingIndex >= 0) {
          modelList[existingIndex] = result;
        } else {
          modelList.insert(0, result);
        }

        if (!GetPlatform.isMobile) {
          updateGridRow(result);
        }

        Get.back(result: true);
      } else {
        Get.back();
      }
    } 
  }


  List<Tab> tabItems = [
    Tab( 
			icon: Icon(iconDataList[Random().nextInt(10)]), 
			text: 'Projeto', 
		),
    Tab( 
			icon: Icon(iconDataList[Random().nextInt(10)]), 
			text: 'Cronograma', 
		),
    Tab( 
			icon: Icon(iconDataList[Random().nextInt(10)]), 
			text: 'Riscos', 
		),
    Tab( 
			icon: Icon(iconDataList[Random().nextInt(10)]), 
			text: 'Custos', 
		),
    Tab( 
			icon: Icon(iconDataList[Random().nextInt(10)]), 
			text: 'Stakeholders', 
		),
  ];

  List<Widget> tabPages() {
    return [
      ProjetoPrincipalEditPage(),
      const ProjetoCronogramaListPage(),
      const ProjetoRiscoListPage(),
      const ProjetoCustoListPage(),
      const ProjetoStakeholdersListPage(),
    ];
  }

  @override
  void preventDataLoss() {
    if (userMadeChanges()) {
      showQuestionDialog('message_data_loss'.tr, () { 
        Get.back(); 
      });
    } else {
      Get.back();
    }
  }  

  bool userMadeChanges() {
    return
    formWasChanged 
    || 
		Get.find<ProjetoCronogramaController>().userMadeChanges
    || 
		Get.find<ProjetoRiscoController>().userMadeChanges
    || 
		Get.find<ProjetoCustoController>().userMadeChanges
    || 
		Get.find<ProjetoStakeholdersController>().userMadeChanges
    ;
  }

  void tabChange(int index) {
    validateCurrentForm();
  }

  bool validateCurrentForm() {
    return true;
  }

  bool validateForms() {
    return true;
  }

  Future<void> navegarParaQuadroKanban() async {
    await launchUrl(Uri.parse(currentModel.linkQuadroKanban!));
  }

  @override
  void onInit() {
    super.onInit();
    tabController = TabController(vsync: this, length: tabItems.length);
    _configureChildrenControllers();
  }
	
  @override
  void onClose() {
    tabController.dispose();
    nomeController.dispose();
    dataInicioController.dispose();
    dataPrevisaoFimController.dispose();
    dataFimController.dispose();
    valorOrcamentoController.dispose();
    linkQuadroKanbanController.dispose();
    observacaoController.dispose();
    _releaseChildrenControllers();
    super.onClose();
  }	
}