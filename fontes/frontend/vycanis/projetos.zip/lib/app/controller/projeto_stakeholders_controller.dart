import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:pluto_grid/pluto_grid.dart';
import 'package:projetos/app/routes/app_routes.dart';

import 'package:projetos/app/page/page_imports.dart';
import 'package:projetos/app/page/shared_widget/message_dialog.dart';
import 'package:projetos/app/page/grid_columns/grid_columns_imports.dart';
import 'package:projetos/app/controller/controller_imports.dart';
import 'package:projetos/app/data/model/model_imports.dart';

class ProjetoStakeholdersController extends ControllerBase<ProjetoStakeholdersModel, void> {

  ProjetoStakeholdersController() : super(repository: null) {
    dbColumns = ProjetoStakeholdersModel.dbColumns;
    aliasColumns = ProjetoStakeholdersModel.aliasColumns;
    gridColumns = projetoStakeholdersGridColumns();
    functionName = "projeto_stakeholders";
    screenTitle = "Stakeholders";
  }

  final _projetoStakeholdersModel = ProjetoStakeholdersModel().obs;
  ProjetoStakeholdersModel get projetoStakeholdersModel => _projetoStakeholdersModel.value;
  set projetoStakeholdersModel(value) => _projetoStakeholdersModel.value = value ?? ProjetoStakeholdersModel();

  List<ProjetoStakeholdersModel> get projetoStakeholdersModelList => Get.find<ProjetoPrincipalController>().currentModel.projetoStakeholdersModelList ?? [];

  final _userMadeChanges = false.obs;
  get userMadeChanges => _userMadeChanges.value;
  set userMadeChanges(value) => _userMadeChanges.value = value;

  final _formWasChangedDetail = false.obs;
  bool get formWasChangedDetail => _formWasChangedDetail.value;
  set formWasChangedDetail(value) => _formWasChangedDetail.value = value;

  late PlutoGridStateManager _plutoGridStateManager;
  @override
  PlutoGridStateManager get plutoGridStateManager => _plutoGridStateManager;
  @override
  set plutoGridStateManager(value) => _plutoGridStateManager = value;

  final projetoStakeholdersScaffoldKey = GlobalKey<ScaffoldState>();
  final projetoStakeholdersFormKey = GlobalKey<FormState>();

  @override
  ProjetoStakeholdersModel createNewModel() => ProjetoStakeholdersModel();

  @override
  final standardFieldForFilter = ProjetoStakeholdersModel.aliasColumns[ProjetoStakeholdersModel.dbColumns.indexOf('id')];

  final viewPessoaColaboradorModelController = TextEditingController();

  final Map<String, dynamic> mobileConfig = {
    'primaryColumns': [],
    'secondaryColumns': [],
  };

  List<Map<String, dynamic>> get mobileItems {
    return modelList.map((projetoStakeholders) => projetoStakeholders.toJson).toList();
  }

  @override
  List<PlutoRow> plutoRows() => List<PlutoRow>.from(projetoStakeholdersModelList.map((model) => model.toPlutoRow()));

  @override
  Future<void> getList({Filter? filter}) async {}

  @override
  void prepareForInsert() {
    isNewRecord = true;
    projetoStakeholdersModel = createNewModel();
    _resetForm();
    Get.to(() => ProjetoStakeholdersEditPage());
  }

  void _resetForm() {
    formWasChangedDetail = false;
    viewPessoaColaboradorModelController.text = '';
  }

  @override
  void selectRowForEditing(PlutoRow? row) async {
    if (row == null) {
      showInfoSnackBar(message: 'message_select_one_to_edited'.tr);
      return;
    }

    selectRowForEditingByTempId(row.cells['tempId']?.value);
  }

  @override
  void selectRowForEditingById(int id) {}

  void selectRowForEditingByTempId(String tempId) {
		isNewRecord = false;
    final model = projetoStakeholdersModelList.firstWhere((m) => m.tempId == tempId);
    projetoStakeholdersModel = model.clone();
		projetoStakeholdersModel.tempId = model.tempId;
    updateControllersFromModel();
    Get.to(() => ProjetoStakeholdersEditPage());
  }

  void updateControllersFromModel() {
    viewPessoaColaboradorModelController.text = projetoStakeholdersModel.viewPessoaColaboradorModel?.nome?.toString() ?? '';
    formWasChangedDetail = false;
  }

  @override
  Future<void> save() async {
    if (!projetoStakeholdersFormKey.currentState!.validate()) {
      showErrorSnackBar(message: 'validator_form_message'.tr);
      return;
    }

    if (formWasChangedDetail) {
      if (isNewRecord) {
        projetoStakeholdersModelList.insert(0, projetoStakeholdersModel.clone());
      } else {
        final index = projetoStakeholdersModelList.indexWhere((m) => m.tempId == projetoStakeholdersModel.tempId);
        if (index >= 0) {
          projetoStakeholdersModelList[index] = projetoStakeholdersModel.clone();
        }
      }

      userMadeChanges = true;
      loadData();
      Get.back(result: true);
    } else {
      Get.back();
    }
  }

  Future callViewPessoaColaboradorLookup() async { 
		final lookupController = Get.find<LookupController>(); 
		lookupController.refreshItems(standardValue: '%'); 
		lookupController.title = '${'lookup_page_title'.tr} [Colaborador]'; 
		lookupController.route = '/view-pessoa-colaborador/'; 
		lookupController.gridColumns = viewPessoaColaboradorGridColumns(isForLookup: true); 
		lookupController.aliasColumns = ViewPessoaColaboradorModel.aliasColumns; 
		lookupController.dbColumns = ViewPessoaColaboradorModel.dbColumns; 
		lookupController.standardColumn = ViewPessoaColaboradorModel.aliasColumns[ViewPessoaColaboradorModel.dbColumns.indexOf('nome')]; 

		final plutoRowResult = await Get.toNamed(Routes.lookupPage); 
		if (plutoRowResult != null) { 
			projetoStakeholdersModel.idColaborador = plutoRowResult.cells['id']!.value; 
			projetoStakeholdersModel.viewPessoaColaboradorModel = ViewPessoaColaboradorModel.fromPlutoRow(plutoRowResult); 
			viewPessoaColaboradorModelController.text = projetoStakeholdersModel.viewPessoaColaboradorModel?.nome ?? ''; 
			formWasChangedDetail = true; 
		}
	}


  @override
  Future deleteSelected() async {
    final currentRow = plutoGridStateManager.currentRow;
    if (currentRow == null) {
      showInfoSnackBar(message: 'message_select_one_to_delete'.tr);
      return null;
    }
    showDeleteDialog(() async {
      final id = currentRow.cells['id']?.value;
      final tempId = currentRow.cells['tempId']?.value;
      projetoStakeholdersModelList.removeWhere((model) => (id != 0 && model.id == id) || (id == 0 && model.tempId == tempId));
      plutoGridStateManager.removeCurrentRow();
      userMadeChanges = true;
    });
  }

  @override
  void preventDataLoss() {
    if (formWasChangedDetail) {
      showQuestionDialog('message_data_loss'.tr, () => Get.back());
    } else {
      formWasChangedDetail = false;
      Get.back();
    }
  }

  @override
  void onClose() {
    viewPessoaColaboradorModelController.dispose();
  }

}