import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:pluto_grid/pluto_grid.dart';
import 'package:projetos/app/page/shared_widget/input/input_imports.dart';

import 'package:projetos/app/page/page_imports.dart';
import 'package:projetos/app/page/shared_widget/message_dialog.dart';
import 'package:projetos/app/page/grid_columns/grid_columns_imports.dart';
import 'package:projetos/app/controller/controller_imports.dart';
import 'package:projetos/app/data/model/model_imports.dart';

class ProjetoCronogramaController extends ControllerBase<ProjetoCronogramaModel, void> {

  ProjetoCronogramaController() : super(repository: null) {
    dbColumns = ProjetoCronogramaModel.dbColumns;
    aliasColumns = ProjetoCronogramaModel.aliasColumns;
    gridColumns = projetoCronogramaGridColumns();
    functionName = "projeto_cronograma";
    screenTitle = "Cronograma";
  }

  final _projetoCronogramaModel = ProjetoCronogramaModel().obs;
  ProjetoCronogramaModel get projetoCronogramaModel => _projetoCronogramaModel.value;
  set projetoCronogramaModel(value) => _projetoCronogramaModel.value = value ?? ProjetoCronogramaModel();

  List<ProjetoCronogramaModel> get projetoCronogramaModelList => Get.find<ProjetoPrincipalController>().currentModel.projetoCronogramaModelList ?? [];

  final _userMadeChanges = false.obs;
  get userMadeChanges => _userMadeChanges.value;
  set userMadeChanges(value) => _userMadeChanges.value = value;

  final _formWasChangedDetail = false.obs;
  bool get formWasChangedDetail => _formWasChangedDetail.value;
  set formWasChangedDetail(value) => _formWasChangedDetail.value = value;

  late PlutoGridStateManager _plutoGridStateManager;
  @override
  PlutoGridStateManager get plutoGridStateManager => _plutoGridStateManager;
  @override
  set plutoGridStateManager(value) => _plutoGridStateManager = value;

  final projetoCronogramaScaffoldKey = GlobalKey<ScaffoldState>();
  final projetoCronogramaFormKey = GlobalKey<FormState>();

  @override
  ProjetoCronogramaModel createNewModel() => ProjetoCronogramaModel();

  @override
  final standardFieldForFilter = ProjetoCronogramaModel.aliasColumns[ProjetoCronogramaModel.dbColumns.indexOf('tarefa')];

  final tarefaController = TextEditingController();
  final dataTarefaController = DatePickerItemController(null);
  final descricaoController = TextEditingController();

  final Map<String, dynamic> mobileConfig = {
    'primaryColumns': ['tarefa'],
    'secondaryColumns': ['data_tarefa'],
  };

  List<Map<String, dynamic>> get mobileItems {
    return modelList.map((projetoCronograma) => projetoCronograma.toJson).toList();
  }

  @override
  List<PlutoRow> plutoRows() => List<PlutoRow>.from(projetoCronogramaModelList.map((model) => model.toPlutoRow()));

  @override
  Future<void> getList({Filter? filter}) async {}

  @override
  void prepareForInsert() {
    isNewRecord = true;
    projetoCronogramaModel = createNewModel();
    _resetForm();
    Get.to(() => ProjetoCronogramaEditPage());
  }

  void _resetForm() {
    formWasChangedDetail = false;
    tarefaController.text = '';
    dataTarefaController.date = null;
    descricaoController.text = '';
  }

  @override
  void selectRowForEditing(PlutoRow? row) async {
    if (row == null) {
      showInfoSnackBar(message: 'message_select_one_to_edited'.tr);
      return;
    }

    selectRowForEditingByTempId(row.cells['tempId']?.value);
  }

  @override
  void selectRowForEditingById(int id) {}

  void selectRowForEditingByTempId(String tempId) {
		isNewRecord = false;
    final model = projetoCronogramaModelList.firstWhere((m) => m.tempId == tempId);
    projetoCronogramaModel = model.clone();
		projetoCronogramaModel.tempId = model.tempId;
    updateControllersFromModel();
    Get.to(() => ProjetoCronogramaEditPage());
  }

  void updateControllersFromModel() {
    tarefaController.text = projetoCronogramaModel.tarefa ?? '';
    dataTarefaController.date = projetoCronogramaModel.dataTarefa;
    descricaoController.text = projetoCronogramaModel.descricao ?? '';
    formWasChangedDetail = false;
  }

  @override
  Future<void> save() async {
    if (!projetoCronogramaFormKey.currentState!.validate()) {
      showErrorSnackBar(message: 'validator_form_message'.tr);
      return;
    }

    if (formWasChangedDetail) {
      if (isNewRecord) {
        projetoCronogramaModelList.insert(0, projetoCronogramaModel.clone());
      } else {
        final index = projetoCronogramaModelList.indexWhere((m) => m.tempId == projetoCronogramaModel.tempId);
        if (index >= 0) {
          projetoCronogramaModelList[index] = projetoCronogramaModel.clone();
        }
      }

      userMadeChanges = true;
      loadData();
      Get.back(result: true);
    } else {
      Get.back();
    }
  }


  @override
  Future deleteSelected() async {
    final currentRow = plutoGridStateManager.currentRow;
    if (currentRow == null) {
      showInfoSnackBar(message: 'message_select_one_to_delete'.tr);
      return null;
    }
    showDeleteDialog(() async {
      final id = currentRow.cells['id']?.value;
      final tempId = currentRow.cells['tempId']?.value;
      projetoCronogramaModelList.removeWhere((model) => (id != 0 && model.id == id) || (id == 0 && model.tempId == tempId));
      plutoGridStateManager.removeCurrentRow();
      userMadeChanges = true;
    });
  }

  @override
  void preventDataLoss() {
    if (formWasChangedDetail) {
      showQuestionDialog('message_data_loss'.tr, () => Get.back());
    } else {
      formWasChangedDetail = false;
      Get.back();
    }
  }

  @override
  void onClose() {
    tarefaController.dispose();
    dataTarefaController.dispose();
    descricaoController.dispose();
  }

}