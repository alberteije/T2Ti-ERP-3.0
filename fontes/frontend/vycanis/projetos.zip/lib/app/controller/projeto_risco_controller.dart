import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:pluto_grid/pluto_grid.dart';
import 'package:extended_masked_text/extended_masked_text.dart';

import 'package:projetos/app/page/page_imports.dart';
import 'package:projetos/app/page/shared_widget/message_dialog.dart';
import 'package:projetos/app/page/grid_columns/grid_columns_imports.dart';
import 'package:projetos/app/controller/controller_imports.dart';
import 'package:projetos/app/data/model/model_imports.dart';

class ProjetoRiscoController extends ControllerBase<ProjetoRiscoModel, void> {

  ProjetoRiscoController() : super(repository: null) {
    dbColumns = ProjetoRiscoModel.dbColumns;
    aliasColumns = ProjetoRiscoModel.aliasColumns;
    gridColumns = projetoRiscoGridColumns();
    functionName = "projeto_risco";
    screenTitle = "Riscos";
  }

  final _projetoRiscoModel = ProjetoRiscoModel().obs;
  ProjetoRiscoModel get projetoRiscoModel => _projetoRiscoModel.value;
  set projetoRiscoModel(value) => _projetoRiscoModel.value = value ?? ProjetoRiscoModel();

  List<ProjetoRiscoModel> get projetoRiscoModelList => Get.find<ProjetoPrincipalController>().currentModel.projetoRiscoModelList ?? [];

  final _userMadeChanges = false.obs;
  get userMadeChanges => _userMadeChanges.value;
  set userMadeChanges(value) => _userMadeChanges.value = value;

  final _formWasChangedDetail = false.obs;
  bool get formWasChangedDetail => _formWasChangedDetail.value;
  set formWasChangedDetail(value) => _formWasChangedDetail.value = value;

  late PlutoGridStateManager _plutoGridStateManager;
  @override
  PlutoGridStateManager get plutoGridStateManager => _plutoGridStateManager;
  @override
  set plutoGridStateManager(value) => _plutoGridStateManager = value;

  final projetoRiscoScaffoldKey = GlobalKey<ScaffoldState>();
  final projetoRiscoFormKey = GlobalKey<FormState>();

  @override
  ProjetoRiscoModel createNewModel() => ProjetoRiscoModel();

  @override
  final standardFieldForFilter = ProjetoRiscoModel.aliasColumns[ProjetoRiscoModel.dbColumns.indexOf('nome')];

  final nomeController = TextEditingController();
  final probabilidadeController = MoneyMaskedTextController(precision: 0, decimalSeparator: '', thousandSeparator: '');
  final impactoController = MoneyMaskedTextController(precision: 0, decimalSeparator: '', thousandSeparator: '');
  final descricaoController = TextEditingController();

  final Map<String, dynamic> mobileConfig = {
    'primaryColumns': ['nome'],
    'secondaryColumns': ['probabilidade'],
  };

  List<Map<String, dynamic>> get mobileItems {
    return modelList.map((projetoRisco) => projetoRisco.toJson).toList();
  }

  @override
  List<PlutoRow> plutoRows() => List<PlutoRow>.from(projetoRiscoModelList.map((model) => model.toPlutoRow()));

  @override
  Future<void> getList({Filter? filter}) async {}

  @override
  void prepareForInsert() {
    isNewRecord = true;
    projetoRiscoModel = createNewModel();
    _resetForm();
    Get.to(() => ProjetoRiscoEditPage());
  }

  void _resetForm() {
    formWasChangedDetail = false;
    nomeController.text = '';
    probabilidadeController.updateValue(0);
    impactoController.updateValue(0);
    descricaoController.text = '';
  }

  @override
  void selectRowForEditing(PlutoRow? row) async {
    if (row == null) {
      showInfoSnackBar(message: 'message_select_one_to_edited'.tr);
      return;
    }

    selectRowForEditingByTempId(row.cells['tempId']?.value);
  }

  @override
  void selectRowForEditingById(int id) {}

  void selectRowForEditingByTempId(String tempId) {
		isNewRecord = false;
    final model = projetoRiscoModelList.firstWhere((m) => m.tempId == tempId);
    projetoRiscoModel = model.clone();
		projetoRiscoModel.tempId = model.tempId;
    updateControllersFromModel();
    Get.to(() => ProjetoRiscoEditPage());
  }

  void updateControllersFromModel() {
    nomeController.text = projetoRiscoModel.nome ?? '';
    probabilidadeController.updateValue((projetoRiscoModel.probabilidade ?? 0).toDouble());
    impactoController.updateValue((projetoRiscoModel.impacto ?? 0).toDouble());
    descricaoController.text = projetoRiscoModel.descricao ?? '';
    formWasChangedDetail = false;
  }

  @override
  Future<void> save() async {
    if (!projetoRiscoFormKey.currentState!.validate()) {
      showErrorSnackBar(message: 'validator_form_message'.tr);
      return;
    }

    if (formWasChangedDetail) {
      if (isNewRecord) {
        projetoRiscoModelList.insert(0, projetoRiscoModel.clone());
      } else {
        final index = projetoRiscoModelList.indexWhere((m) => m.tempId == projetoRiscoModel.tempId);
        if (index >= 0) {
          projetoRiscoModelList[index] = projetoRiscoModel.clone();
        }
      }

      userMadeChanges = true;
      loadData();
      Get.back(result: true);
    } else {
      Get.back();
    }
  }


  @override
  Future deleteSelected() async {
    final currentRow = plutoGridStateManager.currentRow;
    if (currentRow == null) {
      showInfoSnackBar(message: 'message_select_one_to_delete'.tr);
      return null;
    }
    showDeleteDialog(() async {
      final id = currentRow.cells['id']?.value;
      final tempId = currentRow.cells['tempId']?.value;
      projetoRiscoModelList.removeWhere((model) => (id != 0 && model.id == id) || (id == 0 && model.tempId == tempId));
      plutoGridStateManager.removeCurrentRow();
      userMadeChanges = true;
    });
  }

  @override
  void preventDataLoss() {
    if (formWasChangedDetail) {
      showQuestionDialog('message_data_loss'.tr, () => Get.back());
    } else {
      formWasChangedDetail = false;
      Get.back();
    }
  }

  @override
  void onClose() {
    nomeController.dispose();
    probabilidadeController.dispose();
    impactoController.dispose();
    descricaoController.dispose();
  }

}