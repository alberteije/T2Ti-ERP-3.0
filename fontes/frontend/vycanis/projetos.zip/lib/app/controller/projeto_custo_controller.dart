import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:pluto_grid/pluto_grid.dart';
import 'package:extended_masked_text/extended_masked_text.dart';
import 'package:projetos/app/routes/app_routes.dart';

import 'package:projetos/app/page/page_imports.dart';
import 'package:projetos/app/page/shared_widget/message_dialog.dart';
import 'package:projetos/app/page/grid_columns/grid_columns_imports.dart';
import 'package:projetos/app/controller/controller_imports.dart';
import 'package:projetos/app/data/model/model_imports.dart';

class ProjetoCustoController extends ControllerBase<ProjetoCustoModel, void> {

  ProjetoCustoController() : super(repository: null) {
    dbColumns = ProjetoCustoModel.dbColumns;
    aliasColumns = ProjetoCustoModel.aliasColumns;
    gridColumns = projetoCustoGridColumns();
    functionName = "projeto_custo";
    screenTitle = "Custos";
  }

  final _projetoCustoModel = ProjetoCustoModel().obs;
  ProjetoCustoModel get projetoCustoModel => _projetoCustoModel.value;
  set projetoCustoModel(value) => _projetoCustoModel.value = value ?? ProjetoCustoModel();

  List<ProjetoCustoModel> get projetoCustoModelList => Get.find<ProjetoPrincipalController>().currentModel.projetoCustoModelList ?? [];

  final _userMadeChanges = false.obs;
  get userMadeChanges => _userMadeChanges.value;
  set userMadeChanges(value) => _userMadeChanges.value = value;

  final _formWasChangedDetail = false.obs;
  bool get formWasChangedDetail => _formWasChangedDetail.value;
  set formWasChangedDetail(value) => _formWasChangedDetail.value = value;

  late PlutoGridStateManager _plutoGridStateManager;
  @override
  PlutoGridStateManager get plutoGridStateManager => _plutoGridStateManager;
  @override
  set plutoGridStateManager(value) => _plutoGridStateManager = value;

  final projetoCustoScaffoldKey = GlobalKey<ScaffoldState>();
  final projetoCustoFormKey = GlobalKey<FormState>();

  @override
  ProjetoCustoModel createNewModel() => ProjetoCustoModel();

  @override
  final standardFieldForFilter = ProjetoCustoModel.aliasColumns[ProjetoCustoModel.dbColumns.indexOf('nome')];

  final finNaturezaFinanceiraModelController = TextEditingController();
  final nomeController = TextEditingController();
  final valorMensalController = MoneyMaskedTextController();
  final valorTotalController = MoneyMaskedTextController();
  final justificativaController = TextEditingController();

  final Map<String, dynamic> mobileConfig = {
    'primaryColumns': ['nome'],
    'secondaryColumns': ['valor_mensal'],
  };

  List<Map<String, dynamic>> get mobileItems {
    return modelList.map((projetoCusto) => projetoCusto.toJson).toList();
  }

  @override
  List<PlutoRow> plutoRows() => List<PlutoRow>.from(projetoCustoModelList.map((model) => model.toPlutoRow()));

  @override
  Future<void> getList({Filter? filter}) async {}

  @override
  void prepareForInsert() {
    isNewRecord = true;
    projetoCustoModel = createNewModel();
    _resetForm();
    Get.to(() => ProjetoCustoEditPage());
  }

  void _resetForm() {
    formWasChangedDetail = false;
    finNaturezaFinanceiraModelController.text = '';
    nomeController.text = '';
    valorMensalController.updateValue(0);
    valorTotalController.updateValue(0);
    justificativaController.text = '';
  }

  @override
  void selectRowForEditing(PlutoRow? row) async {
    if (row == null) {
      showInfoSnackBar(message: 'message_select_one_to_edited'.tr);
      return;
    }

    selectRowForEditingByTempId(row.cells['tempId']?.value);
  }

  @override
  void selectRowForEditingById(int id) {}

  void selectRowForEditingByTempId(String tempId) {
		isNewRecord = false;
    final model = projetoCustoModelList.firstWhere((m) => m.tempId == tempId);
    projetoCustoModel = model.clone();
		projetoCustoModel.tempId = model.tempId;
    updateControllersFromModel();
    Get.to(() => ProjetoCustoEditPage());
  }

  void updateControllersFromModel() {
    finNaturezaFinanceiraModelController.text = projetoCustoModel.finNaturezaFinanceiraModel?.descricao?.toString() ?? '';
    nomeController.text = projetoCustoModel.nome ?? '';
    valorMensalController.updateValue(projetoCustoModel.valorMensal ?? 0);
    valorTotalController.updateValue(projetoCustoModel.valorTotal ?? 0);
    justificativaController.text = projetoCustoModel.justificativa ?? '';
    formWasChangedDetail = false;
  }

  @override
  Future<void> save() async {
    if (!projetoCustoFormKey.currentState!.validate()) {
      showErrorSnackBar(message: 'validator_form_message'.tr);
      return;
    }

    if (formWasChangedDetail) {
      if (isNewRecord) {
        projetoCustoModelList.insert(0, projetoCustoModel.clone());
      } else {
        final index = projetoCustoModelList.indexWhere((m) => m.tempId == projetoCustoModel.tempId);
        if (index >= 0) {
          projetoCustoModelList[index] = projetoCustoModel.clone();
        }
      }

      userMadeChanges = true;
      loadData();
      Get.back(result: true);
    } else {
      Get.back();
    }
  }

  Future callFinNaturezaFinanceiraLookup() async { 
		final lookupController = Get.find<LookupController>(); 
		lookupController.refreshItems(standardValue: '%'); 
		lookupController.title = '${'lookup_page_title'.tr} [Natureza Financeira]'; 
		lookupController.route = '/fin-natureza-financeira/'; 
		lookupController.gridColumns = finNaturezaFinanceiraGridColumns(isForLookup: true); 
		lookupController.aliasColumns = FinNaturezaFinanceiraModel.aliasColumns; 
		lookupController.dbColumns = FinNaturezaFinanceiraModel.dbColumns; 
		lookupController.standardColumn = FinNaturezaFinanceiraModel.aliasColumns[FinNaturezaFinanceiraModel.dbColumns.indexOf('descricao')]; 

		final plutoRowResult = await Get.toNamed(Routes.lookupPage); 
		if (plutoRowResult != null) { 
			projetoCustoModel.idFinNaturezaFinanceira = plutoRowResult.cells['id']!.value; 
			projetoCustoModel.finNaturezaFinanceiraModel = FinNaturezaFinanceiraModel.fromPlutoRow(plutoRowResult); 
			finNaturezaFinanceiraModelController.text = projetoCustoModel.finNaturezaFinanceiraModel?.descricao ?? ''; 
			formWasChangedDetail = true; 
		}
	}


  @override
  Future deleteSelected() async {
    final currentRow = plutoGridStateManager.currentRow;
    if (currentRow == null) {
      showInfoSnackBar(message: 'message_select_one_to_delete'.tr);
      return null;
    }
    showDeleteDialog(() async {
      final id = currentRow.cells['id']?.value;
      final tempId = currentRow.cells['tempId']?.value;
      projetoCustoModelList.removeWhere((model) => (id != 0 && model.id == id) || (id == 0 && model.tempId == tempId));
      plutoGridStateManager.removeCurrentRow();
      userMadeChanges = true;
    });
  }

  @override
  void preventDataLoss() {
    if (formWasChangedDetail) {
      showQuestionDialog('message_data_loss'.tr, () => Get.back());
    } else {
      formWasChangedDetail = false;
      Get.back();
    }
  }

  @override
  void onClose() {
    finNaturezaFinanceiraModelController.dispose();
    nomeController.dispose();
    valorMensalController.dispose();
    valorTotalController.dispose();
    justificativaController.dispose();
  }

}