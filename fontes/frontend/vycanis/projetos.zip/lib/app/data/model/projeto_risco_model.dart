import 'dart:convert';
import 'package:pluto_grid/pluto_grid.dart';
import 'package:projetos/app/data/model/model_imports.dart';


class ProjetoRiscoModel extends ModelBase {
  int? id;
  int? idProjetoPrincipal;
  String? nome;
  int? probabilidade;
  int? impacto;
  String? descricao;

  ProjetoRiscoModel({
    this.id,
    this.idProjetoPrincipal,
    this.nome,
    this.probabilidade,
    this.impacto,
    this.descricao,
  });

  static List<String> dbColumns = <String>[
    'id',
    'nome',
    'probabilidade',
    'impacto',
    'descricao',
  ];

  static List<String> aliasColumns = <String>[
    'Id',
    'Nome',
    'Probabilidade',
    'Impacto',
    'Descricao',
  ];

  ProjetoRiscoModel.fromJson(Map<String, dynamic> jsonData) {
    id = jsonData['id'];
    idProjetoPrincipal = jsonData['idProjetoPrincipal'];
    nome = jsonData['nome'];
    probabilidade = jsonData['probabilidade'];
    impacto = jsonData['impacto'];
    descricao = jsonData['descricao'];
  }

  Map<String, dynamic> get toJson {
    Map<String, dynamic> jsonData = <String, dynamic>{};

    jsonData['id'] = id != 0 ? id : null;
    jsonData['idProjetoPrincipal'] = idProjetoPrincipal != 0 ? idProjetoPrincipal : null;
    jsonData['nome'] = nome;
    jsonData['probabilidade'] = probabilidade;
    jsonData['impacto'] = impacto;
    jsonData['descricao'] = descricao;

    return jsonData;
  }

  String objectEncodeJson() {
    final jsonData = toJson;
    return json.encode(jsonData);
  }

  static ProjetoRiscoModel fromPlutoRow(PlutoRow row) {
    return ProjetoRiscoModel(
      id: row.cells['id']?.value,
      idProjetoPrincipal: row.cells['idProjetoPrincipal']?.value,
      nome: row.cells['nome']?.value,
      probabilidade: row.cells['probabilidade']?.value,
      impacto: row.cells['impacto']?.value,
      descricao: row.cells['descricao']?.value,
    );
  }

  PlutoRow toPlutoRow() {
    return PlutoRow(
      cells: {
        'tempId': PlutoCell(value: tempId),
        'id': PlutoCell(value: id ?? 0),
        'idProjetoPrincipal': PlutoCell(value: idProjetoPrincipal ?? 0),
        'nome': PlutoCell(value: nome ?? ''),
        'probabilidade': PlutoCell(value: probabilidade ?? 0),
        'impacto': PlutoCell(value: impacto ?? 0),
        'descricao': PlutoCell(value: descricao ?? ''),
      },
    );
  }

  ProjetoRiscoModel clone() {
    return ProjetoRiscoModel(
      id: id,
      idProjetoPrincipal: idProjetoPrincipal,
      nome: nome,
      probabilidade: probabilidade,
      impacto: impacto,
      descricao: descricao,
    );
  }


}