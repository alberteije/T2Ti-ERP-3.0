import 'dart:convert';
import 'package:pluto_grid/pluto_grid.dart';
import 'package:projetos/app/data/model/model_imports.dart';


class ProjetoStakeholdersModel extends ModelBase {
  int? id;
  int? idProjetoPrincipal;
  int? idColaborador;
  ViewPessoaColaboradorModel? viewPessoaColaboradorModel;

  ProjetoStakeholdersModel({
    this.id,
    this.idProjetoPrincipal,
    this.idColaborador,
    ViewPessoaColaboradorModel? viewPessoaColaboradorModel,
  }) {
    this.viewPessoaColaboradorModel = viewPessoaColaboradorModel ?? ViewPessoaColaboradorModel();
  }

  static List<String> dbColumns = <String>[
    'id',
  ];

  static List<String> aliasColumns = <String>[
    'Id',
  ];

  ProjetoStakeholdersModel.fromJson(Map<String, dynamic> jsonData) {
    id = jsonData['id'];
    idProjetoPrincipal = jsonData['idProjetoPrincipal'];
    idColaborador = jsonData['idColaborador'];
    viewPessoaColaboradorModel = jsonData['viewPessoaColaboradorModel'] == null ? ViewPessoaColaboradorModel() : ViewPessoaColaboradorModel.fromJson(jsonData['viewPessoaColaboradorModel']);
  }

  Map<String, dynamic> get toJson {
    Map<String, dynamic> jsonData = <String, dynamic>{};

    jsonData['id'] = id != 0 ? id : null;
    jsonData['idProjetoPrincipal'] = idProjetoPrincipal != 0 ? idProjetoPrincipal : null;
    jsonData['idColaborador'] = idColaborador != 0 ? idColaborador : null;
    jsonData['viewPessoaColaboradorModel'] = viewPessoaColaboradorModel?.toJson;
    jsonData['viewPessoaColaborador'] = viewPessoaColaboradorModel?.nome ?? '';

    return jsonData;
  }

  String objectEncodeJson() {
    final jsonData = toJson;
    return json.encode(jsonData);
  }

  static ProjetoStakeholdersModel fromPlutoRow(PlutoRow row) {
    return ProjetoStakeholdersModel(
      id: row.cells['id']?.value,
      idProjetoPrincipal: row.cells['idProjetoPrincipal']?.value,
      idColaborador: row.cells['idColaborador']?.value,
    );
  }

  PlutoRow toPlutoRow() {
    return PlutoRow(
      cells: {
        'tempId': PlutoCell(value: tempId),
        'id': PlutoCell(value: id ?? 0),
        'idProjetoPrincipal': PlutoCell(value: idProjetoPrincipal ?? 0),
        'idColaborador': PlutoCell(value: idColaborador ?? 0),
        'viewPessoaColaborador': PlutoCell(value: viewPessoaColaboradorModel?.nome ?? ''),
      },
    );
  }

  ProjetoStakeholdersModel clone() {
    return ProjetoStakeholdersModel(
      id: id,
      idProjetoPrincipal: idProjetoPrincipal,
      idColaborador: idColaborador,
      viewPessoaColaboradorModel: viewPessoaColaboradorModel?.clone(),
    );
  }


}