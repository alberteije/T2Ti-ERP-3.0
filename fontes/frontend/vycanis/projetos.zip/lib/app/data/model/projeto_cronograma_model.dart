import 'dart:convert';
import 'package:pluto_grid/pluto_grid.dart';
import 'package:projetos/app/data/model/model_imports.dart';

import 'package:projetos/app/infra/infra_imports.dart';
import 'package:intl/intl.dart';

class ProjetoCronogramaModel extends ModelBase {
  int? id;
  int? idProjetoPrincipal;
  String? tarefa;
  DateTime? dataTarefa;
  String? descricao;

  ProjetoCronogramaModel({
    this.id,
    this.idProjetoPrincipal,
    this.tarefa,
    this.dataTarefa,
    this.descricao,
  });

  static List<String> dbColumns = <String>[
    'id',
    'tarefa',
    'data_tarefa',
    'descricao',
  ];

  static List<String> aliasColumns = <String>[
    'Id',
    'Tarefa',
    'Data Tarefa',
    'Descricao',
  ];

  ProjetoCronogramaModel.fromJson(Map<String, dynamic> jsonData) {
    id = jsonData['id'];
    idProjetoPrincipal = jsonData['idProjetoPrincipal'];
    tarefa = jsonData['tarefa'];
    dataTarefa = jsonData['dataTarefa'] != null ? DateTime.tryParse(jsonData['dataTarefa']) : null;
    descricao = jsonData['descricao'];
  }

  Map<String, dynamic> get toJson {
    Map<String, dynamic> jsonData = <String, dynamic>{};

    jsonData['id'] = id != 0 ? id : null;
    jsonData['idProjetoPrincipal'] = idProjetoPrincipal != 0 ? idProjetoPrincipal : null;
    jsonData['tarefa'] = tarefa;
    jsonData['dataTarefa'] = dataTarefa != null ? DateFormat('yyyy-MM-ddT00:00:00').format(dataTarefa!) : null;
    jsonData['descricao'] = descricao;

    return jsonData;
  }

  String objectEncodeJson() {
    final jsonData = toJson;
    return json.encode(jsonData);
  }

  static ProjetoCronogramaModel fromPlutoRow(PlutoRow row) {
    return ProjetoCronogramaModel(
      id: row.cells['id']?.value,
      idProjetoPrincipal: row.cells['idProjetoPrincipal']?.value,
      tarefa: row.cells['tarefa']?.value,
      dataTarefa: Util.stringToDate(row.cells['dataTarefa']?.value),
      descricao: row.cells['descricao']?.value,
    );
  }

  PlutoRow toPlutoRow() {
    return PlutoRow(
      cells: {
        'tempId': PlutoCell(value: tempId),
        'id': PlutoCell(value: id ?? 0),
        'idProjetoPrincipal': PlutoCell(value: idProjetoPrincipal ?? 0),
        'tarefa': PlutoCell(value: tarefa ?? ''),
        'dataTarefa': PlutoCell(value: dataTarefa),
        'descricao': PlutoCell(value: descricao ?? ''),
      },
    );
  }

  ProjetoCronogramaModel clone() {
    return ProjetoCronogramaModel(
      id: id,
      idProjetoPrincipal: idProjetoPrincipal,
      tarefa: tarefa,
      dataTarefa: dataTarefa,
      descricao: descricao,
    );
  }


}