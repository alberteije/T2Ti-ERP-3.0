import 'dart:convert';
import 'package:pluto_grid/pluto_grid.dart';
import 'package:projetos/app/data/model/model_imports.dart';


class ProjetoCustoModel extends ModelBase {
  int? id;
  int? idProjetoPrincipal;
  int? idFinNaturezaFinanceira;
  String? nome;
  double? valorMensal;
  double? valorTotal;
  String? justificativa;
  FinNaturezaFinanceiraModel? finNaturezaFinanceiraModel;

  ProjetoCustoModel({
    this.id,
    this.idProjetoPrincipal,
    this.idFinNaturezaFinanceira,
    this.nome,
    this.valorMensal,
    this.valorTotal,
    this.justificativa,
    FinNaturezaFinanceiraModel? finNaturezaFinanceiraModel,
  }) {
    this.finNaturezaFinanceiraModel = finNaturezaFinanceiraModel ?? FinNaturezaFinanceiraModel();
  }

  static List<String> dbColumns = <String>[
    'id',
    'nome',
    'valor_mensal',
    'valor_total',
    'justificativa',
  ];

  static List<String> aliasColumns = <String>[
    'Id',
    'Nome',
    'Valor Mensal',
    'Valor Total',
    'Justificativa',
  ];

  ProjetoCustoModel.fromJson(Map<String, dynamic> jsonData) {
    id = jsonData['id'];
    idProjetoPrincipal = jsonData['idProjetoPrincipal'];
    idFinNaturezaFinanceira = jsonData['idFinNaturezaFinanceira'];
    nome = jsonData['nome'];
    valorMensal = jsonData['valorMensal']?.toDouble();
    valorTotal = jsonData['valorTotal']?.toDouble();
    justificativa = jsonData['justificativa'];
    finNaturezaFinanceiraModel = jsonData['finNaturezaFinanceiraModel'] == null ? FinNaturezaFinanceiraModel() : FinNaturezaFinanceiraModel.fromJson(jsonData['finNaturezaFinanceiraModel']);
  }

  Map<String, dynamic> get toJson {
    Map<String, dynamic> jsonData = <String, dynamic>{};

    jsonData['id'] = id != 0 ? id : null;
    jsonData['idProjetoPrincipal'] = idProjetoPrincipal != 0 ? idProjetoPrincipal : null;
    jsonData['idFinNaturezaFinanceira'] = idFinNaturezaFinanceira != 0 ? idFinNaturezaFinanceira : null;
    jsonData['nome'] = nome;
    jsonData['valorMensal'] = valorMensal;
    jsonData['valorTotal'] = valorTotal;
    jsonData['justificativa'] = justificativa;
    jsonData['finNaturezaFinanceiraModel'] = finNaturezaFinanceiraModel?.toJson;
    jsonData['finNaturezaFinanceira'] = finNaturezaFinanceiraModel?.descricao ?? '';

    return jsonData;
  }

  String objectEncodeJson() {
    final jsonData = toJson;
    return json.encode(jsonData);
  }

  static ProjetoCustoModel fromPlutoRow(PlutoRow row) {
    return ProjetoCustoModel(
      id: row.cells['id']?.value,
      idProjetoPrincipal: row.cells['idProjetoPrincipal']?.value,
      idFinNaturezaFinanceira: row.cells['idFinNaturezaFinanceira']?.value,
      nome: row.cells['nome']?.value,
      valorMensal: row.cells['valorMensal']?.value,
      valorTotal: row.cells['valorTotal']?.value,
      justificativa: row.cells['justificativa']?.value,
    );
  }

  PlutoRow toPlutoRow() {
    return PlutoRow(
      cells: {
        'tempId': PlutoCell(value: tempId),
        'id': PlutoCell(value: id ?? 0),
        'idProjetoPrincipal': PlutoCell(value: idProjetoPrincipal ?? 0),
        'idFinNaturezaFinanceira': PlutoCell(value: idFinNaturezaFinanceira ?? 0),
        'nome': PlutoCell(value: nome ?? ''),
        'valorMensal': PlutoCell(value: valorMensal ?? 0.0),
        'valorTotal': PlutoCell(value: valorTotal ?? 0.0),
        'justificativa': PlutoCell(value: justificativa ?? ''),
        'finNaturezaFinanceira': PlutoCell(value: finNaturezaFinanceiraModel?.descricao ?? ''),
      },
    );
  }

  ProjetoCustoModel clone() {
    return ProjetoCustoModel(
      id: id,
      idProjetoPrincipal: idProjetoPrincipal,
      idFinNaturezaFinanceira: idFinNaturezaFinanceira,
      nome: nome,
      valorMensal: valorMensal,
      valorTotal: valorTotal,
      justificativa: justificativa,
      finNaturezaFinanceiraModel: finNaturezaFinanceiraModel?.clone(),
    );
  }


}