class FinNaturezaFinanceiraDomain {
  FinNaturezaFinanceiraDomain._();

  static getCodigo(String? codigo) { 
		switch (codigo) { 
			case '': 
			case '0': 
				return 'AAA'; 
			case '1': 
				return 'BBB'; 
			case '2': 
				return 'CCC'; 
			default: 
				return null; 
		} 
	} 

  static setCodigo(String? codigo) { 
		switch (codigo) { 
			case 'AAA': 
				return '0'; 
			case 'BBB': 
				return '1'; 
			case 'CCC': 
				return '2'; 
			default: 
				return null; 
		} 
	}

  static getTipo(String? tipo) { 
		switch (tipo) { 
			case '': 
			case '0': 
				return 'AAA'; 
			case '1': 
				return 'BBB'; 
			case '2': 
				return 'CCC'; 
			default: 
				return null; 
		} 
	} 

  static setTipo(String? tipo) { 
		switch (tipo) { 
			case 'AAA': 
				return '0'; 
			case 'BBB': 
				return '1'; 
			case 'CCC': 
				return '2'; 
			default: 
				return null; 
		} 
	}


  static final codigoListDropdown = ['AAA','BBB','CCC'];
  static final tipoListDropdown = ['AAA','BBB','CCC'];

}