import 'package:projetos/app/data/provider/api/api_provider_base.dart';
import 'package:projetos/app/data/model/model_imports.dart';

class ProjetoPrincipalApiProvider extends ApiProviderBase {
  static const _path = '/projeto-principal';

  Future<List<ProjetoPrincipalModel>?> getList({Filter? filter}) {
    return super.getListBase(
      '$_path/',
      (json) => ProjetoPrincipalModel.fromJson(json),
      filter: filter,
    );
  }

  Future<ProjetoPrincipalModel?> getObject(dynamic pk) {
    return super.getObjectBase(
      _path,
      pk,
      (json) => ProjetoPrincipalModel.fromJson(json),
    );
  }

  Future<ProjetoPrincipalModel?>? insert(ProjetoPrincipalModel model) {
    return super.insertBase(
      _path,
      model,
      (json) => ProjetoPrincipalModel.fromJson(json),
    );
  }

  Future<ProjetoPrincipalModel?>? update(ProjetoPrincipalModel model) {
    return super.updateBase(
      _path,
      model,
      (json) => ProjetoPrincipalModel.fromJson(json),
    );
  }

  Future<bool?> delete(dynamic pk) {
    return super.deleteBase(_path, pk);
  }
}
