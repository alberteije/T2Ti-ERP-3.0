// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'fin_natureza_financeira_dao.dart';

// ignore_for_file: type=lint
mixin _$FinNaturezaFinanceiraDaoMixin on DatabaseAccessor<AppDatabase> {
  $FinNaturezaFinanceirasTable get finNaturezaFinanceiras =>
      attachedDatabase.finNaturezaFinanceiras;
}
