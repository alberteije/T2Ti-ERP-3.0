import 'package:flutter/material.dart';
import 'package:projetos/app/controller/projeto_principal_controller.dart';
import 'package:projetos/app/page/shared_page/list_page_base.dart';

class ProjetoPrincipalListPage extends ListPageBase<ProjetoPrincipalController> {
  const ProjetoPrincipalListPage({Key? key}) : super(key: key);

  @override
  List<Map<String, dynamic>> get mobileItems => controller.mobileItems;

  @override
  Map<String, dynamic> get mobileConfig => controller.mobileConfig;

  @override
  String get standardFieldForFilter => controller.standardFieldForFilter;
}