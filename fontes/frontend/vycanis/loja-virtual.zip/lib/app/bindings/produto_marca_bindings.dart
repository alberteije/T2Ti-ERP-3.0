import 'package:get/get.dart';
import 'package:loja_virtual/app/controller/produto_marca_controller.dart';
import 'package:loja_virtual/app/data/provider/api/produto_marca_api_provider.dart';
import 'package:loja_virtual/app/data/provider/drift/produto_marca_drift_provider.dart';
import 'package:loja_virtual/app/data/repository/produto_marca_repository.dart';

class ProdutoMarcaBindings implements Binding {
	@override
	List<Bind> dependencies() {
		return [
			Bind.lazyPut<ProdutoMarcaController>(() => ProdutoMarcaController(
					repository: ProdutoMarcaRepository(produtoMarcaApiProvider: ProdutoMarcaApiProvider(), produtoMarcaDriftProvider: ProdutoMarcaDriftProvider()))),
		];
	}
}
