import 'package:get/get.dart';
import 'package:loja_virtual/app/controller/store_controller.dart';
import 'package:loja_virtual/app/data/repository/local_image_repository.dart';

class StoreBindings implements Binding {
  @override
  List<Bind> dependencies() {
    return [
      Bind.lazyPut<LocalImageRepository>(() => LocalImageRepository()),
      Bind.lazyPut<StoreController>(() => StoreController()),
    ];
  }
}