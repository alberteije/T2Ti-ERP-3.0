import 'package:get/get.dart';
import 'package:loja_virtual/app/controller/produto_grupo_controller.dart';
import 'package:loja_virtual/app/data/provider/api/produto_grupo_api_provider.dart';
import 'package:loja_virtual/app/data/provider/drift/produto_grupo_drift_provider.dart';
import 'package:loja_virtual/app/data/repository/produto_grupo_repository.dart';

class ProdutoGrupoBindings implements Binding {
	@override
	List<Bind> dependencies() {
		return [
			Bind.lazyPut<ProdutoGrupoController>(() => ProdutoGrupoController(
					repository: ProdutoGrupoRepository(produtoGrupoApiProvider: ProdutoGrupoApiProvider(), produtoGrupoDriftProvider: ProdutoGrupoDriftProvider()))),
		];
	}
}
