import 'package:get/get.dart';
import 'package:loja_virtual/app/controller/produto_subgrupo_controller.dart';
import 'package:loja_virtual/app/data/provider/api/produto_subgrupo_api_provider.dart';
import 'package:loja_virtual/app/data/provider/drift/produto_subgrupo_drift_provider.dart';
import 'package:loja_virtual/app/data/repository/produto_subgrupo_repository.dart';

class ProdutoSubgrupoBindings implements Binding {
	@override
	List<Bind> dependencies() {
		return [
			Bind.lazyPut<ProdutoSubgrupoController>(() => ProdutoSubgrupoController(
					repository: ProdutoSubgrupoRepository(produtoSubgrupoApiProvider: ProdutoSubgrupoApiProvider(), produtoSubgrupoDriftProvider: ProdutoSubgrupoDriftProvider()))),
		];
	}
}
