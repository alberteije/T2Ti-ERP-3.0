import 'package:get/get.dart';
import 'package:loja_virtual/app/controller/produto_controller.dart';
import 'package:loja_virtual/app/data/provider/api/produto_api_provider.dart';
import 'package:loja_virtual/app/data/provider/drift/produto_drift_provider.dart';
import 'package:loja_virtual/app/data/repository/produto_repository.dart';

class ProdutoBindings implements Binding {
	@override
	List<Bind> dependencies() {
		return [
			Bind.lazyPut<ProdutoController>(() => ProdutoController(
					repository: ProdutoRepository(produtoApiProvider: ProdutoApiProvider(), produtoDriftProvider: ProdutoDriftProvider()))),
		];
	}
}
