class FornecedorDomain {
  FornecedorDomain._();

  static getOptanteSimplesNacional(String? optanteSimplesNacional) { 
		switch (optanteSimplesNacional) { 
			case '': 
			case 'S': 
				return 'Sim'; 
			case 'N': 
				return 'Não'; 
			default: 
				return null; 
		} 
	} 

  static setOptanteSimplesNacional(String? optanteSimplesNacional) { 
		switch (optanteSimplesNacional) { 
			case 'Sim': 
				return 'S'; 
			case 'Não': 
				return 'N'; 
			default: 
				return null; 
		} 
	}

  static getPermiteReterPagamento(String? permiteReterPagamento) { 
		switch (permiteReterPagamento) { 
			case '': 
			case 'S': 
				return 'Sim'; 
			case 'N': 
				return 'Não'; 
			default: 
				return null; 
		} 
	} 

  static setPermiteReterPagamento(String? permiteReterPagamento) { 
		switch (permiteReterPagamento) { 
			case 'Sim': 
				return 'S'; 
			case 'Não': 
				return 'N'; 
			default: 
				return null; 
		} 
	}

  static getForneceAPrazo(String? forneceAPrazo) { 
		switch (forneceAPrazo) { 
			case '': 
			case 'S': 
				return 'Sim'; 
			case 'N': 
				return 'Não'; 
			default: 
				return null; 
		} 
	} 

  static setForneceAPrazo(String? forneceAPrazo) { 
		switch (forneceAPrazo) { 
			case 'Sim': 
				return 'S'; 
			case 'Não': 
				return 'N'; 
			default: 
				return null; 
		} 
	}


  static final optanteSimplesNacionalListDropdown = ['Sim','Não'];
  static final permiteReterPagamentoListDropdown = ['Sim','Não'];
  static final forneceAPrazoListDropdown = ['Sim','Não'];

}