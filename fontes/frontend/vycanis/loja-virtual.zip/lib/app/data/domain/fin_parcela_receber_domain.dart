class FinParcelaReceberDomain {
  FinParcelaReceberDomain._();

  static getEmitiuBoleto(String? emitiuBoleto) { 
		switch (emitiuBoleto) { 
			case '': 
			case 'S': 
				return 'Sim'; 
			case 'N': 
				return 'Não'; 
			default: 
				return null; 
		} 
	} 

  static setEmitiuBoleto(String? emitiuBoleto) { 
		switch (emitiuBoleto) { 
			case 'Sim': 
				return 'S'; 
			case 'Não': 
				return 'N'; 
			default: 
				return null; 
		} 
	}


  static final emitiuBoletoListDropdown = ['Sim','Não'];

}