import 'package:loja_virtual/app/data/provider/api/api_provider_base.dart';
import 'package:loja_virtual/app/data/model/model_imports.dart';

class FinTipoRecebimentoApiProvider extends ApiProviderBase {
  static const _path = '/fin-tipo-recebimento';

  Future<List<FinTipoRecebimentoModel>?> getList({Filter? filter}) {
    return super.getListBase(
      '$_path/',
      (json) => FinTipoRecebimentoModel.fromJson(json),
      filter: filter,
    );
  }

  Future<FinTipoRecebimentoModel?> getObject(dynamic pk) {
    return super.getObjectBase(
      _path,
      pk,
      (json) => FinTipoRecebimentoModel.fromJson(json),
    );
  }

  Future<FinTipoRecebimentoModel?>? insert(FinTipoRecebimentoModel model) {
    return super.insertBase(
      _path,
      model,
      (json) => FinTipoRecebimentoModel.fromJson(json),
    );
  }

  Future<FinTipoRecebimentoModel?>? update(FinTipoRecebimentoModel model) {
    return super.updateBase(
      _path,
      model,
      (json) => FinTipoRecebimentoModel.fromJson(json),
    );
  }

  Future<bool?> delete(dynamic pk) {
    return super.deleteBase(_path, pk);
  }
}
