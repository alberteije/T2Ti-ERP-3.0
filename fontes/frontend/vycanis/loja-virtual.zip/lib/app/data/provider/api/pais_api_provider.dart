import 'package:loja_virtual/app/data/provider/api/api_provider_base.dart';
import 'package:loja_virtual/app/data/model/model_imports.dart';

class PaisApiProvider extends ApiProviderBase {
  static const _path = '/pais';

  Future<List<PaisModel>?> getList({Filter? filter}) {
    return super.getListBase(
      '$_path/',
      (json) => PaisModel.fromJson(json),
      filter: filter,
    );
  }

  Future<PaisModel?> getObject(dynamic pk) {
    return super.getObjectBase(
      _path,
      pk,
      (json) => PaisModel.fromJson(json),
    );
  }

  Future<PaisModel?>? insert(PaisModel model) {
    return super.insertBase(
      _path,
      model,
      (json) => PaisModel.fromJson(json),
    );
  }

  Future<PaisModel?>? update(PaisModel model) {
    return super.updateBase(
      _path,
      model,
      (json) => PaisModel.fromJson(json),
    );
  }

  Future<bool?> delete(dynamic pk) {
    return super.deleteBase(_path, pk);
  }
}
