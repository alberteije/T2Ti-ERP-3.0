import 'package:loja_virtual/app/data/provider/api/api_provider_base.dart';
import 'package:loja_virtual/app/data/model/model_imports.dart';

class EstadoCivilApiProvider extends ApiProviderBase {
  static const _path = '/estado-civil';

  Future<List<EstadoCivilModel>?> getList({Filter? filter}) {
    return super.getListBase(
      '$_path/',
      (json) => EstadoCivilModel.fromJson(json),
      filter: filter,
    );
  }

  Future<EstadoCivilModel?> getObject(dynamic pk) {
    return super.getObjectBase(
      _path,
      pk,
      (json) => EstadoCivilModel.fromJson(json),
    );
  }

  Future<EstadoCivilModel?>? insert(EstadoCivilModel model) {
    return super.insertBase(
      _path,
      model,
      (json) => EstadoCivilModel.fromJson(json),
    );
  }

  Future<EstadoCivilModel?>? update(EstadoCivilModel model) {
    return super.updateBase(
      _path,
      model,
      (json) => EstadoCivilModel.fromJson(json),
    );
  }

  Future<bool?> delete(dynamic pk) {
    return super.deleteBase(_path, pk);
  }
}
