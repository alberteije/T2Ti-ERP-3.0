import 'package:drift/drift.dart';
import 'package:loja_virtual/app/data/provider/drift/database/database.dart';
import 'package:loja_virtual/app/data/provider/drift/database/database_imports.dart';

@DataClassName("Produto")
class Produtos extends Table {
	@override
	String get tableName => 'produto';

	IntColumn get id => integer().named('id').nullable()();
	IntColumn get idProdutoSubgrupo => integer().named('id_produto_subgrupo').nullable()();
	IntColumn get idProdutoMarca => integer().named('id_produto_marca').nullable()();
	IntColumn get idProdutoUnidade => integer().named('id_produto_unidade').nullable()();
	TextColumn get tipoItem => text().named('tipo_item').withLength(min: 0, max: 1).nullable()();
	TextColumn get nome => text().named('nome').withLength(min: 0, max: 100).nullable()();
	TextColumn get descricao => text().named('descricao').withLength(min: 0, max: 250).nullable()();
	TextColumn get gtin => text().named('gtin').withLength(min: 0, max: 14).nullable()();
	TextColumn get codigoInterno => text().named('codigo_interno').withLength(min: 0, max: 50).nullable()();
	RealColumn get valorCompra => real().named('valor_compra').nullable()();
	RealColumn get valorVenda => real().named('valor_venda').nullable()();
	TextColumn get codigoNcm => text().named('codigo_ncm').withLength(min: 0, max: 8).nullable()();
	TextColumn get codigoNbs => text().named('codigo_nbs').withLength(min: 0, max: 8).nullable()();
	TextColumn get codigoCest => text().named('codigo_cest').withLength(min: 0, max: 7).nullable()();
	DateTimeColumn get dataCadastro => dateTime().named('data_cadastro').nullable()();
	RealColumn get quantidadeEstoque => real().named('quantidade_estoque').nullable()();
	RealColumn get estoqueMinimo => real().named('estoque_minimo').nullable()();
	RealColumn get estoqueMaximo => real().named('estoque_maximo').nullable()();
	RealColumn get estoqueIdeal => real().named('estoque_ideal').nullable()();
	TextColumn get pesavel => text().named('pesavel').withLength(min: 0, max: 1).nullable()();
	RealColumn get peso => real().named('peso').nullable()();
	RealColumn get markup => real().named('markup').nullable()();
	RealColumn get precoSugerido => real().named('preco_sugerido').nullable()();
	RealColumn get precoVendaMinimo => real().named('preco_venda_minimo').nullable()();
	RealColumn get custoPercentual => real().named('custo_percentual').nullable()();
	RealColumn get custoUnitario => real().named('custo_unitario').nullable()();
	RealColumn get custoProducao => real().named('custo_producao').nullable()();
	RealColumn get custoMedioLiquido => real().named('custo_medio_liquido').nullable()();
	RealColumn get precoLucroZero => real().named('preco_lucro_zero').nullable()();
	RealColumn get precoLucroMinimo => real().named('preco_lucro_minimo').nullable()();
	RealColumn get precoLucroMaximo => real().named('preco_lucro_maximo').nullable()();
	RealColumn get margemLucro => real().named('margem_lucro').nullable()();
	IntColumn get codigoBalanca => integer().named('codigo_balanca').nullable()();
	TextColumn get classeAbc => text().named('classe_abc').withLength(min: 0, max: 1).nullable()();
	TextColumn get ativo => text().named('ativo').withLength(min: 0, max: 1).nullable()();
	TextColumn get informacoesAdicionaisNfe => text().named('informacoes_adicionais_nfe').withLength(min: 0, max: 500).nullable()();

	@override
	Set<Column> get primaryKey => { id };	
	
}

class ProdutoGrouped {
	Produto? produto; 
	ProdutoMarca? produtoMarca; 
	ProdutoUnidade? produtoUnidade; 
	ProdutoSubgrupo? produtoSubgrupo; 
	List<ProdutoFichaTecnicaGrouped>? produtoFichaTecnicaGroupedList; 
	List<ProdutoPromocaoGrouped>? produtoPromocaoGroupedList; 

  ProdutoGrouped({
		this.produto, 
		this.produtoMarca, 
		this.produtoUnidade, 
		this.produtoSubgrupo, 
		this.produtoFichaTecnicaGroupedList, 
		this.produtoPromocaoGroupedList, 

  });
}
