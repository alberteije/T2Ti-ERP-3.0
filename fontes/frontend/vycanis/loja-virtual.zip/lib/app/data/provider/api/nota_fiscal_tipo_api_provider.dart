import 'package:loja_virtual/app/data/provider/api/api_provider_base.dart';
import 'package:loja_virtual/app/data/model/model_imports.dart';

class NotaFiscalTipoApiProvider extends ApiProviderBase {
  static const _path = '/nota-fiscal-tipo';

  Future<List<NotaFiscalTipoModel>?> getList({Filter? filter}) {
    return super.getListBase(
      '$_path/',
      (json) => NotaFiscalTipoModel.fromJson(json),
      filter: filter,
    );
  }

  Future<NotaFiscalTipoModel?> getObject(dynamic pk) {
    return super.getObjectBase(
      _path,
      pk,
      (json) => NotaFiscalTipoModel.fromJson(json),
    );
  }

  Future<NotaFiscalTipoModel?>? insert(NotaFiscalTipoModel model) {
    return super.insertBase(
      _path,
      model,
      (json) => NotaFiscalTipoModel.fromJson(json),
    );
  }

  Future<NotaFiscalTipoModel?>? update(NotaFiscalTipoModel model) {
    return super.updateBase(
      _path,
      model,
      (json) => NotaFiscalTipoModel.fromJson(json),
    );
  }

  Future<bool?> delete(dynamic pk) {
    return super.deleteBase(_path, pk);
  }
}
