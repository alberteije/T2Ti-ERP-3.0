import 'package:loja_virtual/app/data/provider/api/api_provider_base.dart';
import 'package:loja_virtual/app/data/model/model_imports.dart';

class FinLancamentoReceberApiProvider extends ApiProviderBase {
  static const _path = '/fin-lancamento-receber';

  Future<List<FinLancamentoReceberModel>?> getList({Filter? filter}) {
    return super.getListBase(
      '$_path/',
      (json) => FinLancamentoReceberModel.fromJson(json),
      filter: filter,
    );
  }

  Future<FinLancamentoReceberModel?> getObject(dynamic pk) {
    return super.getObjectBase(
      _path,
      pk,
      (json) => FinLancamentoReceberModel.fromJson(json),
    );
  }

  Future<FinLancamentoReceberModel?>? insert(FinLancamentoReceberModel model) {
    return super.insertBase(
      _path,
      model,
      (json) => FinLancamentoReceberModel.fromJson(json),
    );
  }

  Future<FinLancamentoReceberModel?>? update(FinLancamentoReceberModel model) {
    return super.updateBase(
      _path,
      model,
      (json) => FinLancamentoReceberModel.fromJson(json),
    );
  }

  Future<bool?> delete(dynamic pk) {
    return super.deleteBase(_path, pk);
  }
}
