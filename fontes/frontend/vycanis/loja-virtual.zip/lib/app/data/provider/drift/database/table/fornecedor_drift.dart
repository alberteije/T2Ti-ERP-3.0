import 'package:drift/drift.dart';
import 'package:loja_virtual/app/data/provider/drift/database/database.dart';

@DataClassName("Fornecedor")
class Fornecedors extends Table {
	@override
	String get tableName => 'fornecedor';

	IntColumn get id => integer().named('id').nullable()();
	IntColumn get idPessoa => integer().named('id_pessoa').nullable()();
	DateTimeColumn get desde => dateTime().named('desde').nullable()();
	DateTimeColumn get dataCadastro => dateTime().named('data_cadastro').nullable()();
	TextColumn get observacao => text().named('observacao').withLength(min: 0, max: 250).nullable()();
	TextColumn get optanteSimplesNacional => text().named('optante_simples_nacional').withLength(min: 0, max: 1).nullable()();
	TextColumn get permiteReterPagamento => text().named('permite_reter_pagamento').withLength(min: 0, max: 1).nullable()();
	IntColumn get prazoMedioEntrega => integer().named('prazo_medio_entrega').nullable()();
	IntColumn get numDiasPrimeiroVencimento => integer().named('num_dias_primeiro_vencimento').nullable()();
	IntColumn get numDiasIntervalo => integer().named('num_dias_intervalo').nullable()();
	IntColumn get quantidadeParcelas => integer().named('quantidade_parcelas').nullable()();
	TextColumn get forneceAPrazo => text().named('fornece_a_prazo').withLength(min: 0, max: 1).nullable()();

	@override
	Set<Column> get primaryKey => { id };	
	
}

class FornecedorGrouped {
	Fornecedor? fornecedor; 

  FornecedorGrouped({
		this.fornecedor, 

  });
}
