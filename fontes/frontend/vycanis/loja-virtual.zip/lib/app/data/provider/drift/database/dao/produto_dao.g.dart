// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'produto_dao.dart';

// ignore_for_file: type=lint
mixin _$ProdutoDaoMixin on DatabaseAccessor<AppDatabase> {
  $ProdutosTable get produtos => attachedDatabase.produtos;
  $ProdutoMarcasTable get produtoMarcas => attachedDatabase.produtoMarcas;
  $ProdutoUnidadesTable get produtoUnidades => attachedDatabase.produtoUnidades;
  $ProdutoSubgruposTable get produtoSubgrupos =>
      attachedDatabase.produtoSubgrupos;
  $ProdutoFichaTecnicasTable get produtoFichaTecnicas =>
      attachedDatabase.produtoFichaTecnicas;
  $ProdutoPromocaosTable get produtoPromocaos =>
      attachedDatabase.produtoPromocaos;
}
