import 'package:loja_virtual/app/data/provider/drift/database/database_imports.dart';
import 'package:loja_virtual/app/infra/infra_imports.dart';
import 'package:loja_virtual/app/data/provider/provider_base.dart';
import 'package:loja_virtual/app/data/provider/drift/database/database.dart';
import 'package:loja_virtual/app/data/model/model_imports.dart';
import 'package:loja_virtual/app/data/domain/domain_imports.dart';

class ProdutoDriftProvider extends ProviderBase {

	Future<List<ProdutoModel>?> getList({Filter? filter}) async {
		List<ProdutoGrouped> produtoDriftList = [];

		try {
			if (filter != null && filter.field != null) {
				produtoDriftList = await Session.database.produtoDao.getGroupedList(field: filter.field, value: filter.value!);
			} else {
				produtoDriftList = await Session.database.produtoDao.getGroupedList(); 
			}
			if (produtoDriftList.isNotEmpty) {
				return toListModel(produtoDriftList);
			} else {
				return [];
			}			 
		} catch (e) {
			handleResultError(null, null, exception: e);
			return null;
		}
	}

	Future<ProdutoModel?> getObject(dynamic pk) async {
		try {
			final result = await Session.database.produtoDao.getObjectGrouped(field: 'id', value: pk);
			return toModel(result);
		} catch (e) {
			handleResultError(null, null, exception: e);
		}
		return null;
	}

	Future<ProdutoModel?>? insert(ProdutoModel produtoModel) async {
		try {
			final lastPk = await Session.database.produtoDao.insertObject(toDrift(produtoModel));
			produtoModel.id = lastPk;
			return produtoModel;
		} catch (e) {
			handleResultError(null, null, exception: e);
		}
		return null;
	}

	Future<ProdutoModel?>? update(ProdutoModel produtoModel) async {
		try {
			await Session.database.produtoDao.updateObject(toDrift(produtoModel));
			return produtoModel;
		} catch (e) {
			handleResultError(null, null, exception: e);
		}
		return null;
	}

	Future<bool?> delete(dynamic pk) async {
		try {
			await Session.database.produtoDao.deleteObject(toDrift(ProdutoModel(id: pk)));
			return true;
		} catch (e) {
			handleResultError(null, null, exception: e);
		}
		return null;
	}	

	List<ProdutoModel> toListModel(List<ProdutoGrouped> produtoDriftList) {
		List<ProdutoModel> listModel = [];
		for (var produtoDrift in produtoDriftList) {
			listModel.add(toModel(produtoDrift)!);
		}
		return listModel;
	}	

	ProdutoModel? toModel(ProdutoGrouped? produtoDrift) {
		if (produtoDrift != null) {
			return ProdutoModel(
				id: produtoDrift.produto?.id,
				idProdutoSubgrupo: produtoDrift.produto?.idProdutoSubgrupo,
				idProdutoMarca: produtoDrift.produto?.idProdutoMarca,
				idProdutoUnidade: produtoDrift.produto?.idProdutoUnidade,
				tipoItem: ProdutoDomain.getTipoItem(produtoDrift.produto?.tipoItem),
				nome: produtoDrift.produto?.nome,
				descricao: produtoDrift.produto?.descricao,
				gtin: produtoDrift.produto?.gtin,
				codigoInterno: produtoDrift.produto?.codigoInterno,
				valorCompra: produtoDrift.produto?.valorCompra,
				valorVenda: produtoDrift.produto?.valorVenda,
				codigoNcm: produtoDrift.produto?.codigoNcm,
				codigoNbs: produtoDrift.produto?.codigoNbs,
				codigoCest: produtoDrift.produto?.codigoCest,
				dataCadastro: produtoDrift.produto?.dataCadastro,
				quantidadeEstoque: produtoDrift.produto?.quantidadeEstoque,
				estoqueMinimo: produtoDrift.produto?.estoqueMinimo,
				estoqueMaximo: produtoDrift.produto?.estoqueMaximo,
				estoqueIdeal: produtoDrift.produto?.estoqueIdeal,
				pesavel: ProdutoDomain.getPesavel(produtoDrift.produto?.pesavel),
				peso: produtoDrift.produto?.peso,
				markup: produtoDrift.produto?.markup,
				precoSugerido: produtoDrift.produto?.precoSugerido,
				precoVendaMinimo: produtoDrift.produto?.precoVendaMinimo,
				custoPercentual: produtoDrift.produto?.custoPercentual,
				custoUnitario: produtoDrift.produto?.custoUnitario,
				custoProducao: produtoDrift.produto?.custoProducao,
				custoMedioLiquido: produtoDrift.produto?.custoMedioLiquido,
				precoLucroZero: produtoDrift.produto?.precoLucroZero,
				precoLucroMinimo: produtoDrift.produto?.precoLucroMinimo,
				precoLucroMaximo: produtoDrift.produto?.precoLucroMaximo,
				margemLucro: produtoDrift.produto?.margemLucro,
				codigoBalanca: produtoDrift.produto?.codigoBalanca,
				classeAbc: ProdutoDomain.getClasseAbc(produtoDrift.produto?.classeAbc),
				ativo: ProdutoDomain.getAtivo(produtoDrift.produto?.ativo),
				informacoesAdicionaisNfe: produtoDrift.produto?.informacoesAdicionaisNfe,
				produtoMarcaModel: ProdutoMarcaModel(
					id: produtoDrift.produtoMarca?.id,
					nome: produtoDrift.produtoMarca?.nome,
					descricao: produtoDrift.produtoMarca?.descricao,
				),
				produtoUnidadeModel: ProdutoUnidadeModel(
					id: produtoDrift.produtoUnidade?.id,
					sigla: produtoDrift.produtoUnidade?.sigla,
					podeFracionar: produtoDrift.produtoUnidade?.podeFracionar,
					descricao: produtoDrift.produtoUnidade?.descricao,
				),
				produtoSubgrupoModel: ProdutoSubgrupoModel(
					id: produtoDrift.produtoSubgrupo?.id,
					idProdutoGrupo: produtoDrift.produtoSubgrupo?.idProdutoGrupo,
					nome: produtoDrift.produtoSubgrupo?.nome,
					descricao: produtoDrift.produtoSubgrupo?.descricao,
				),
				produtoFichaTecnicaModelList: produtoFichaTecnicaDriftToModel(produtoDrift.produtoFichaTecnicaGroupedList),
				produtoPromocaoModelList: produtoPromocaoDriftToModel(produtoDrift.produtoPromocaoGroupedList),
			);
		} else {
			return null;
		}
	}

	List<ProdutoFichaTecnicaModel> produtoFichaTecnicaDriftToModel(List<ProdutoFichaTecnicaGrouped>? produtoFichaTecnicaDriftList) { 
		List<ProdutoFichaTecnicaModel> produtoFichaTecnicaModelList = [];
		if (produtoFichaTecnicaDriftList != null) {
			for (var produtoFichaTecnicaGrouped in produtoFichaTecnicaDriftList) {
				produtoFichaTecnicaModelList.add(
					ProdutoFichaTecnicaModel(
						id: produtoFichaTecnicaGrouped.produtoFichaTecnica?.id,
						idProduto: produtoFichaTecnicaGrouped.produtoFichaTecnica?.idProduto,
						descricao: produtoFichaTecnicaGrouped.produtoFichaTecnica?.descricao,
						idProdutoFilho: produtoFichaTecnicaGrouped.produtoFichaTecnica?.idProdutoFilho,
						quantidade: produtoFichaTecnicaGrouped.produtoFichaTecnica?.quantidade,
						valorCusto: produtoFichaTecnicaGrouped.produtoFichaTecnica?.valorCusto,
						percentualCusto: produtoFichaTecnicaGrouped.produtoFichaTecnica?.percentualCusto,
					)
				);
			}
			return produtoFichaTecnicaModelList;
		}
		return [];
	}

	List<ProdutoPromocaoModel> produtoPromocaoDriftToModel(List<ProdutoPromocaoGrouped>? produtoPromocaoDriftList) { 
		List<ProdutoPromocaoModel> produtoPromocaoModelList = [];
		if (produtoPromocaoDriftList != null) {
			for (var produtoPromocaoGrouped in produtoPromocaoDriftList) {
				produtoPromocaoModelList.add(
					ProdutoPromocaoModel(
						id: produtoPromocaoGrouped.produtoPromocao?.id,
						idProduto: produtoPromocaoGrouped.produtoPromocao?.idProduto,
						dataInicio: produtoPromocaoGrouped.produtoPromocao?.dataInicio,
						dataFim: produtoPromocaoGrouped.produtoPromocao?.dataFim,
						quantidadeEmPromocao: produtoPromocaoGrouped.produtoPromocao?.quantidadeEmPromocao,
						quantidadeMaximaCliente: produtoPromocaoGrouped.produtoPromocao?.quantidadeMaximaCliente,
						valor: produtoPromocaoGrouped.produtoPromocao?.valor,
					)
				);
			}
			return produtoPromocaoModelList;
		}
		return [];
	}


	ProdutoGrouped toDrift(ProdutoModel produtoModel) {
		return ProdutoGrouped(
			produto: Produto(
				id: produtoModel.id,
				idProdutoSubgrupo: produtoModel.idProdutoSubgrupo,
				idProdutoMarca: produtoModel.idProdutoMarca,
				idProdutoUnidade: produtoModel.idProdutoUnidade,
				tipoItem: ProdutoDomain.setTipoItem(produtoModel.tipoItem),
				nome: produtoModel.nome,
				descricao: produtoModel.descricao,
				gtin: produtoModel.gtin,
				codigoInterno: produtoModel.codigoInterno,
				valorCompra: produtoModel.valorCompra,
				valorVenda: produtoModel.valorVenda,
				codigoNcm: produtoModel.codigoNcm,
				codigoNbs: produtoModel.codigoNbs,
				codigoCest: produtoModel.codigoCest,
				dataCadastro: produtoModel.dataCadastro,
				quantidadeEstoque: produtoModel.quantidadeEstoque,
				estoqueMinimo: produtoModel.estoqueMinimo,
				estoqueMaximo: produtoModel.estoqueMaximo,
				estoqueIdeal: produtoModel.estoqueIdeal,
				pesavel: ProdutoDomain.setPesavel(produtoModel.pesavel),
				peso: produtoModel.peso,
				markup: produtoModel.markup,
				precoSugerido: produtoModel.precoSugerido,
				precoVendaMinimo: produtoModel.precoVendaMinimo,
				custoPercentual: produtoModel.custoPercentual,
				custoUnitario: produtoModel.custoUnitario,
				custoProducao: produtoModel.custoProducao,
				custoMedioLiquido: produtoModel.custoMedioLiquido,
				precoLucroZero: produtoModel.precoLucroZero,
				precoLucroMinimo: produtoModel.precoLucroMinimo,
				precoLucroMaximo: produtoModel.precoLucroMaximo,
				margemLucro: produtoModel.margemLucro,
				codigoBalanca: produtoModel.codigoBalanca,
				classeAbc: ProdutoDomain.setClasseAbc(produtoModel.classeAbc),
				ativo: ProdutoDomain.setAtivo(produtoModel.ativo),
				informacoesAdicionaisNfe: produtoModel.informacoesAdicionaisNfe,
			),
			produtoFichaTecnicaGroupedList: produtoFichaTecnicaModelToDrift(produtoModel.produtoFichaTecnicaModelList),
			produtoPromocaoGroupedList: produtoPromocaoModelToDrift(produtoModel.produtoPromocaoModelList),
		);
	}

	List<ProdutoFichaTecnicaGrouped> produtoFichaTecnicaModelToDrift(List<ProdutoFichaTecnicaModel>? produtoFichaTecnicaModelList) { 
		List<ProdutoFichaTecnicaGrouped> produtoFichaTecnicaGroupedList = [];
		if (produtoFichaTecnicaModelList != null) {
			for (var produtoFichaTecnicaModel in produtoFichaTecnicaModelList) {
				produtoFichaTecnicaGroupedList.add(
					ProdutoFichaTecnicaGrouped(
						produtoFichaTecnica: ProdutoFichaTecnica(
							id: produtoFichaTecnicaModel.id,
							idProduto: produtoFichaTecnicaModel.idProduto,
							descricao: produtoFichaTecnicaModel.descricao,
							idProdutoFilho: produtoFichaTecnicaModel.idProdutoFilho,
							quantidade: produtoFichaTecnicaModel.quantidade,
							valorCusto: produtoFichaTecnicaModel.valorCusto,
							percentualCusto: produtoFichaTecnicaModel.percentualCusto,
						),
					),
				);
			}
			return produtoFichaTecnicaGroupedList;
		}
		return [];
	}

	List<ProdutoPromocaoGrouped> produtoPromocaoModelToDrift(List<ProdutoPromocaoModel>? produtoPromocaoModelList) { 
		List<ProdutoPromocaoGrouped> produtoPromocaoGroupedList = [];
		if (produtoPromocaoModelList != null) {
			for (var produtoPromocaoModel in produtoPromocaoModelList) {
				produtoPromocaoGroupedList.add(
					ProdutoPromocaoGrouped(
						produtoPromocao: ProdutoPromocao(
							id: produtoPromocaoModel.id,
							idProduto: produtoPromocaoModel.idProduto,
							dataInicio: produtoPromocaoModel.dataInicio,
							dataFim: produtoPromocaoModel.dataFim,
							quantidadeEmPromocao: produtoPromocaoModel.quantidadeEmPromocao,
							quantidadeMaximaCliente: produtoPromocaoModel.quantidadeMaximaCliente,
							valor: produtoPromocaoModel.valor,
						),
					),
				);
			}
			return produtoPromocaoGroupedList;
		}
		return [];
	}

		
}
