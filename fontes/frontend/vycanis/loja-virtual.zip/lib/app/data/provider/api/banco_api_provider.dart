import 'package:loja_virtual/app/data/provider/api/api_provider_base.dart';
import 'package:loja_virtual/app/data/model/model_imports.dart';

class BancoApiProvider extends ApiProviderBase {
  static const _path = '/banco';

  Future<List<BancoModel>?> getList({Filter? filter}) {
    return super.getListBase(
      '$_path/',
      (json) => BancoModel.fromJson(json),
      filter: filter,
    );
  }

  Future<BancoModel?> getObject(dynamic pk) {
    return super.getObjectBase(
      _path,
      pk,
      (json) => BancoModel.fromJson(json),
    );
  }

  Future<BancoModel?>? insert(BancoModel model) {
    return super.insertBase(
      _path,
      model,
      (json) => BancoModel.fromJson(json),
    );
  }

  Future<BancoModel?>? update(BancoModel model) {
    return super.updateBase(
      _path,
      model,
      (json) => BancoModel.fromJson(json),
    );
  }

  Future<bool?> delete(dynamic pk) {
    return super.deleteBase(_path, pk);
  }
}
