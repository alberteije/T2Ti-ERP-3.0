import 'package:loja_virtual/app/data/provider/api/api_provider_base.dart';
import 'package:loja_virtual/app/data/model/model_imports.dart';

class TabelaPrecoApiProvider extends ApiProviderBase {
  static const _path = '/tabela-preco';

  Future<List<TabelaPrecoModel>?> getList({Filter? filter}) {
    return super.getListBase(
      '$_path/',
      (json) => TabelaPrecoModel.fromJson(json),
      filter: filter,
    );
  }

  Future<TabelaPrecoModel?> getObject(dynamic pk) {
    return super.getObjectBase(
      _path,
      pk,
      (json) => TabelaPrecoModel.fromJson(json),
    );
  }

  Future<TabelaPrecoModel?>? insert(TabelaPrecoModel model) {
    return super.insertBase(
      _path,
      model,
      (json) => TabelaPrecoModel.fromJson(json),
    );
  }

  Future<TabelaPrecoModel?>? update(TabelaPrecoModel model) {
    return super.updateBase(
      _path,
      model,
      (json) => TabelaPrecoModel.fromJson(json),
    );
  }

  Future<bool?> delete(dynamic pk) {
    return super.deleteBase(_path, pk);
  }
}
