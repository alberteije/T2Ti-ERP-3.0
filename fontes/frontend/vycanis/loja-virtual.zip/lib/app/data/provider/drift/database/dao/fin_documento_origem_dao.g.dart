// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'fin_documento_origem_dao.dart';

// ignore_for_file: type=lint
mixin _$FinDocumentoOrigemDaoMixin on DatabaseAccessor<AppDatabase> {
  $FinDocumentoOrigemsTable get finDocumentoOrigems =>
      attachedDatabase.finDocumentoOrigems;
}
