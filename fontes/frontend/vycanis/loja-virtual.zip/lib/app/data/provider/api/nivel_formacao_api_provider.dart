import 'package:loja_virtual/app/data/provider/api/api_provider_base.dart';
import 'package:loja_virtual/app/data/model/model_imports.dart';

class NivelFormacaoApiProvider extends ApiProviderBase {
  static const _path = '/nivel-formacao';

  Future<List<NivelFormacaoModel>?> getList({Filter? filter}) {
    return super.getListBase(
      '$_path/',
      (json) => NivelFormacaoModel.fromJson(json),
      filter: filter,
    );
  }

  Future<NivelFormacaoModel?> getObject(dynamic pk) {
    return super.getObjectBase(
      _path,
      pk,
      (json) => NivelFormacaoModel.fromJson(json),
    );
  }

  Future<NivelFormacaoModel?>? insert(NivelFormacaoModel model) {
    return super.insertBase(
      _path,
      model,
      (json) => NivelFormacaoModel.fromJson(json),
    );
  }

  Future<NivelFormacaoModel?>? update(NivelFormacaoModel model) {
    return super.updateBase(
      _path,
      model,
      (json) => NivelFormacaoModel.fromJson(json),
    );
  }

  Future<bool?> delete(dynamic pk) {
    return super.deleteBase(_path, pk);
  }
}
