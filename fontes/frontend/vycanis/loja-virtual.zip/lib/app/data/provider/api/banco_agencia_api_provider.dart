import 'package:loja_virtual/app/data/provider/api/api_provider_base.dart';
import 'package:loja_virtual/app/data/model/model_imports.dart';

class BancoAgenciaApiProvider extends ApiProviderBase {
  static const _path = '/banco-agencia';

  Future<List<BancoAgenciaModel>?> getList({Filter? filter}) {
    return super.getListBase(
      '$_path/',
      (json) => BancoAgenciaModel.fromJson(json),
      filter: filter,
    );
  }

  Future<BancoAgenciaModel?> getObject(dynamic pk) {
    return super.getObjectBase(
      _path,
      pk,
      (json) => BancoAgenciaModel.fromJson(json),
    );
  }

  Future<BancoAgenciaModel?>? insert(BancoAgenciaModel model) {
    return super.insertBase(
      _path,
      model,
      (json) => BancoAgenciaModel.fromJson(json),
    );
  }

  Future<BancoAgenciaModel?>? update(BancoAgenciaModel model) {
    return super.updateBase(
      _path,
      model,
      (json) => BancoAgenciaModel.fromJson(json),
    );
  }

  Future<bool?> delete(dynamic pk) {
    return super.deleteBase(_path, pk);
  }
}
