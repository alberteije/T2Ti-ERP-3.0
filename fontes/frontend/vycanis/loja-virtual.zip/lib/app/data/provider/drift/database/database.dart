import 'package:drift/drift.dart';
import 'package:loja_virtual/app/data/provider/drift/database/database_imports.dart';

part 'database.g.dart';

@DriftDatabase(
	tables: [
		PessoaFisicas,
		PessoaJuridicas,
		Clientes,
		Fornecedors,
		Transportadoras,
		PessoaEnderecos,
		PessoaContatos,
		PessoaTelefones,
		ProdutoFichaTecnicas,
		ProdutoPromocaos,
		VendaDetalhes,
		VendaCondicoesParcelass,
		VendaFretes,
		FinParcelaRecebers,
		Pessoas,
		Produtos,
		VendaCondicoesPagamentos,
		VendaCabecalhos,
		FinLancamentoRecebers,
		EstadoCivils,
		Paiss,
		NivelFormacaos,
		TabelaPrecos,
		ProdutoGrupos,
		ProdutoSubgrupos,
		ProdutoMarcas,
		ProdutoUnidades,
		NotaFiscalModelos,
		NotaFiscalTipos,
		ViewPessoaClientes,
		ViewPessoaVendedors,
		ViewPessoaTransportadoras,
		Bancos,
		BancoAgencias,
		BancoContaCaixas,
		FinDocumentoOrigems,
		FinNaturezaFinanceiras,
		FinStatusParcelas,
		FinTipoRecebimentos,
		ViewControleAcessos,
		ViewPessoaUsuarios,
 ], 
	daos: [
		PessoaDao,
		ProdutoDao,
		VendaCondicoesPagamentoDao,
		VendaCabecalhoDao,
		FinLancamentoReceberDao,
		EstadoCivilDao,
		PaisDao,
		NivelFormacaoDao,
		TabelaPrecoDao,
		ProdutoGrupoDao,
		ProdutoSubgrupoDao,
		ProdutoMarcaDao,
		ProdutoUnidadeDao,
		NotaFiscalModeloDao,
		NotaFiscalTipoDao,
		ViewPessoaClienteDao,
		ViewPessoaVendedorDao,
		ViewPessoaTransportadoraDao,
		BancoDao,
		BancoAgenciaDao,
		BancoContaCaixaDao,
		FinDocumentoOrigemDao,
		FinNaturezaFinanceiraDao,
		FinStatusParcelaDao,
		FinTipoRecebimentoDao,
		ViewControleAcessoDao,
		ViewPessoaUsuarioDao,
	],
)

class AppDatabase extends _$AppDatabase {
	AppDatabase(QueryExecutor executor) : super(executor);

	@override
	int get schemaVersion => 1;

	@override
	MigrationStrategy get migration => MigrationStrategy(
		onCreate: (Migrator m) async {
			await m.createAll();
			await _populateDatabase(this);
		},		
	);	
}

Future<void> _populateDatabase(db) async {
	await db.customStatement("CREATE TABLE HIDDEN_SETTINGS("
				"ID INTEGER PRIMARY KEY,"
				"APP_THEME TEXT"
			")");
	await db.customStatement("INSERT INTO HIDDEN_SETTINGS (ID, APP_THEME) VALUES (1, 'ThemeMode.light')");
}
