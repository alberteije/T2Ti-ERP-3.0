import 'package:loja_virtual/app/data/provider/api/api_provider_base.dart';
import 'package:loja_virtual/app/data/model/model_imports.dart';

class ProdutoSubgrupoApiProvider extends ApiProviderBase {
  static const _path = '/produto-subgrupo';

  Future<List<ProdutoSubgrupoModel>?> getList({Filter? filter}) {
    return super.getListBase(
      '$_path/',
      (json) => ProdutoSubgrupoModel.fromJson(json),
      filter: filter,
    );
  }

  Future<ProdutoSubgrupoModel?> getObject(dynamic pk) {
    return super.getObjectBase(
      _path,
      pk,
      (json) => ProdutoSubgrupoModel.fromJson(json),
    );
  }

  Future<ProdutoSubgrupoModel?>? insert(ProdutoSubgrupoModel model) {
    return super.insertBase(
      _path,
      model,
      (json) => ProdutoSubgrupoModel.fromJson(json),
    );
  }

  Future<ProdutoSubgrupoModel?>? update(ProdutoSubgrupoModel model) {
    return super.updateBase(
      _path,
      model,
      (json) => ProdutoSubgrupoModel.fromJson(json),
    );
  }

  Future<bool?> delete(dynamic pk) {
    return super.deleteBase(_path, pk);
  }
}
