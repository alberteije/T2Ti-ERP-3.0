import 'package:loja_virtual/app/data/provider/api/api_provider_base.dart';
import 'package:loja_virtual/app/data/model/model_imports.dart';

class FinStatusParcelaApiProvider extends ApiProviderBase {
  static const _path = '/fin-status-parcela';

  Future<List<FinStatusParcelaModel>?> getList({Filter? filter}) {
    return super.getListBase(
      '$_path/',
      (json) => FinStatusParcelaModel.fromJson(json),
      filter: filter,
    );
  }

  Future<FinStatusParcelaModel?> getObject(dynamic pk) {
    return super.getObjectBase(
      _path,
      pk,
      (json) => FinStatusParcelaModel.fromJson(json),
    );
  }

  Future<FinStatusParcelaModel?>? insert(FinStatusParcelaModel model) {
    return super.insertBase(
      _path,
      model,
      (json) => FinStatusParcelaModel.fromJson(json),
    );
  }

  Future<FinStatusParcelaModel?>? update(FinStatusParcelaModel model) {
    return super.updateBase(
      _path,
      model,
      (json) => FinStatusParcelaModel.fromJson(json),
    );
  }

  Future<bool?> delete(dynamic pk) {
    return super.deleteBase(_path, pk);
  }
}
