import 'package:drift/drift.dart';
import 'package:loja_virtual/app/data/provider/drift/database/database.dart';
import 'package:loja_virtual/app/data/provider/drift/database/database_imports.dart';

part 'produto_dao.g.dart';

@DriftAccessor(tables: [
	Produtos,
	ProdutoMarcas,
	ProdutoUnidades,
	ProdutoSubgrupos,
	ProdutoFichaTecnicas,
	ProdutoPromocaos,
])
class ProdutoDao extends DatabaseAccessor<AppDatabase> with _$ProdutoDaoMixin {
	final AppDatabase db;

	List<Produto> produtoList = []; 
	List<ProdutoGrouped> produtoGroupedList = []; 

	ProdutoDao(this.db) : super(db);

	Future<List<Produto>> getList() async {
		produtoList = await select(produtos).get();
		return produtoList;
	}

	Future<List<Produto>> getListFilter(String field, String value) async {
		final query = " $field like '%$value%'";
		final expression = CustomExpression<bool>(query);
		produtoList = await (select(produtos)..where((t) => expression)).get();
		return produtoList;	 
	}

	Future<List<ProdutoGrouped>> getGroupedList({String? field, dynamic value}) async {
		final query = select(produtos)
			.join([ 
				leftOuterJoin(produtoMarcas, produtoMarcas.id.equalsExp(produtos.idProdutoMarca)), 
			]).join([ 
				leftOuterJoin(produtoUnidades, produtoUnidades.id.equalsExp(produtos.idProdutoUnidade)), 
			]).join([ 
				leftOuterJoin(produtoSubgrupos, produtoSubgrupos.id.equalsExp(produtos.idProdutoSubgrupo)), 
			]);

		if (field != null && field != '') { 
			final column = produtos.$columns.where(((column) => column.$name == field)).first;
			if (column is TextColumn) {
				query.where((column as TextColumn).like('%$value%'));
			} else if (column is IntColumn) {
				query.where(column.equals(int.tryParse(value) as Object));
			} else if (column is RealColumn) {
				query.where(column.equals(double.tryParse(value) as Object));
			}
		}

		produtoGroupedList = await query.map((row) {
			final produto = row.readTableOrNull(produtos); 
			final produtoMarca = row.readTableOrNull(produtoMarcas); 
			final produtoUnidade = row.readTableOrNull(produtoUnidades); 
			final produtoSubgrupo = row.readTableOrNull(produtoSubgrupos); 

			return ProdutoGrouped(
				produto: produto, 
				produtoMarca: produtoMarca, 
				produtoUnidade: produtoUnidade, 
				produtoSubgrupo: produtoSubgrupo, 

			);
		}).get();

		// fill internal lists
		dynamic expression;
		for (var produtoGrouped in produtoGroupedList) {
			produtoGrouped.produtoFichaTecnicaGroupedList = [];
			final queryProdutoFichaTecnica = ' id_produto = ${produtoGrouped.produto!.id}';
			expression = CustomExpression<bool>(queryProdutoFichaTecnica);
			final produtoFichaTecnicaList = await (select(produtoFichaTecnicas)..where((t) => expression)).get();
			for (var produtoFichaTecnica in produtoFichaTecnicaList) {
				ProdutoFichaTecnicaGrouped produtoFichaTecnicaGrouped = ProdutoFichaTecnicaGrouped(
					produtoFichaTecnica: produtoFichaTecnica,
				);
				produtoGrouped.produtoFichaTecnicaGroupedList!.add(produtoFichaTecnicaGrouped);
			}

			produtoGrouped.produtoPromocaoGroupedList = [];
			final queryProdutoPromocao = ' id_produto = ${produtoGrouped.produto!.id}';
			expression = CustomExpression<bool>(queryProdutoPromocao);
			final produtoPromocaoList = await (select(produtoPromocaos)..where((t) => expression)).get();
			for (var produtoPromocao in produtoPromocaoList) {
				ProdutoPromocaoGrouped produtoPromocaoGrouped = ProdutoPromocaoGrouped(
					produtoPromocao: produtoPromocao,
				);
				produtoGrouped.produtoPromocaoGroupedList!.add(produtoPromocaoGrouped);
			}

		}		

		return produtoGroupedList;	
	}

	Future<Produto?> getObject(dynamic pk) async {
		return await (select(produtos)..where((t) => t.id.equals(pk))).getSingleOrNull();
	} 

	Future<Produto?> getObjectFilter(String field, String value) async {
		final query = "SELECT * FROM produto WHERE $field like '%$value%'";
		return (await customSelect(query).getSingleOrNull()) as Produto;		 
	} 

	Future<ProdutoGrouped?> getObjectGrouped({String? field, dynamic value}) async {
		final result = await getGroupedList(field: field, value: value);

		if (result.length != 1) {
			return null;
		} else {
			return result[0];
		} 
	}

	Future<int> insertObject(ProdutoGrouped object) {
		return transaction(() async {
			final maxPk = await lastPk();
			object.produto = object.produto!.copyWith(id: Value(maxPk + 1));
			final pkInserted = await into(produtos).insert(object.produto!);
			object.produto = object.produto!.copyWith(id: Value(pkInserted));			 
			await insertChildren(object);
			return pkInserted;
		});		
	}	 

	Future<bool> updateObject(ProdutoGrouped object) {
		return transaction(() async {
			await deleteChildren(object);
			await insertChildren(object);
			return update(produtos).replace(object.produto!);
		});	 
	} 

	Future<int> deleteObject(ProdutoGrouped object) {
		return transaction(() async {
			await deleteChildren(object);
			return delete(produtos).delete(object.produto!);
		});		
	}

	Future<void> insertChildren(ProdutoGrouped object) async {
		for (var produtoFichaTecnicaGrouped in object.produtoFichaTecnicaGroupedList!) {
			produtoFichaTecnicaGrouped.produtoFichaTecnica = produtoFichaTecnicaGrouped.produtoFichaTecnica?.copyWith(
				id: const Value(null),
				idProduto: Value(object.produto!.id),
			);
			await into(produtoFichaTecnicas).insert(produtoFichaTecnicaGrouped.produtoFichaTecnica!);
		}
		for (var produtoPromocaoGrouped in object.produtoPromocaoGroupedList!) {
			produtoPromocaoGrouped.produtoPromocao = produtoPromocaoGrouped.produtoPromocao?.copyWith(
				id: const Value(null),
				idProduto: Value(object.produto!.id),
			);
			await into(produtoPromocaos).insert(produtoPromocaoGrouped.produtoPromocao!);
		}
	}
	
	Future<void> deleteChildren(ProdutoGrouped object) async {
		await (delete(produtoFichaTecnicas)..where((t) => t.idProduto.equals(object.produto!.id!))).go();
		await (delete(produtoPromocaos)..where((t) => t.idProduto.equals(object.produto!.id!))).go();
	}

	Future<int> lastPk() async {
		final result = await customSelect("select MAX(id) as LAST from produto").getSingleOrNull();
		return result?.data["LAST"] ?? 0;
	} 
}