import 'package:loja_virtual/app/data/provider/api/api_provider_base.dart';
import 'package:loja_virtual/app/data/model/model_imports.dart';

class VendaCabecalhoApiProvider extends ApiProviderBase {
  static const _path = '/venda-cabecalho';

  Future<List<VendaCabecalhoModel>?> getList({Filter? filter}) {
    return super.getListBase(
      '$_path/',
      (json) => VendaCabecalhoModel.fromJson(json),
      filter: filter,
    );
  }

  Future<VendaCabecalhoModel?> getObject(dynamic pk) {
    return super.getObjectBase(
      _path,
      pk,
      (json) => VendaCabecalhoModel.fromJson(json),
    );
  }

  Future<VendaCabecalhoModel?>? insert(VendaCabecalhoModel model) {
    return super.insertBase(
      _path,
      model,
      (json) => VendaCabecalhoModel.fromJson(json),
    );
  }

  Future<VendaCabecalhoModel?>? update(VendaCabecalhoModel model) {
    return super.updateBase(
      _path,
      model,
      (json) => VendaCabecalhoModel.fromJson(json),
    );
  }

  Future<bool?> delete(dynamic pk) {
    return super.deleteBase(_path, pk);
  }
}
