import 'package:loja_virtual/app/data/provider/api/api_provider_base.dart';
import 'package:loja_virtual/app/data/model/model_imports.dart';

class PessoaApiProvider extends ApiProviderBase {
  static const _path = '/pessoa';

  Future<List<PessoaModel>?> getList({Filter? filter}) {
    return super.getListBase(
      '$_path/',
      (json) => PessoaModel.fromJson(json),
      filter: filter,
    );
  }

  Future<PessoaModel?> getObject(dynamic pk) {
    return super.getObjectBase(
      _path,
      pk,
      (json) => PessoaModel.fromJson(json),
    );
  }

  Future<PessoaModel?>? insert(PessoaModel model) {
    return super.insertBase(
      _path,
      model,
      (json) => PessoaModel.fromJson(json),
    );
  }

  Future<PessoaModel?>? update(PessoaModel model) {
    return super.updateBase(
      _path,
      model,
      (json) => PessoaModel.fromJson(json),
    );
  }

  Future<bool?> delete(dynamic pk) {
    return super.deleteBase(_path, pk);
  }
}
