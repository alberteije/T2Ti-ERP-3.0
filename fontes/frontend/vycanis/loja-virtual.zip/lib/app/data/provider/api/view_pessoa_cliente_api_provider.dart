import 'package:loja_virtual/app/data/provider/api/api_provider_base.dart';
import 'package:loja_virtual/app/data/model/model_imports.dart';

class ViewPessoaClienteApiProvider extends ApiProviderBase {
  static const _path = '/view-pessoa-cliente';

  Future<List<ViewPessoaClienteModel>?> getList({Filter? filter}) {
    return super.getListBase(
      '$_path/',
      (json) => ViewPessoaClienteModel.fromJson(json),
      filter: filter,
    );
  }

  Future<ViewPessoaClienteModel?> getObject(dynamic pk) {
    return super.getObjectBase(
      _path,
      pk,
      (json) => ViewPessoaClienteModel.fromJson(json),
    );
  }

  Future<ViewPessoaClienteModel?>? insert(ViewPessoaClienteModel model) {
    return super.insertBase(
      _path,
      model,
      (json) => ViewPessoaClienteModel.fromJson(json),
    );
  }

  Future<ViewPessoaClienteModel?>? update(ViewPessoaClienteModel model) {
    return super.updateBase(
      _path,
      model,
      (json) => ViewPessoaClienteModel.fromJson(json),
    );
  }

  Future<bool?> delete(dynamic pk) {
    return super.deleteBase(_path, pk);
  }
}
