import 'package:drift/drift.dart';
import 'package:loja_virtual/app/data/provider/drift/database/database.dart';

@DataClassName("ProdutoFichaTecnica")
class ProdutoFichaTecnicas extends Table {
	@override
	String get tableName => 'produto_ficha_tecnica';

	IntColumn get id => integer().named('id').nullable()();
	IntColumn get idProduto => integer().named('id_produto').nullable()();
	TextColumn get descricao => text().named('descricao').withLength(min: 0, max: 100).nullable()();
	IntColumn get idProdutoFilho => integer().named('id_produto_filho').nullable()();
	RealColumn get quantidade => real().named('quantidade').nullable()();
	RealColumn get valorCusto => real().named('valor_custo').nullable()();
	RealColumn get percentualCusto => real().named('percentual_custo').nullable()();

	@override
	Set<Column> get primaryKey => { id };	
	
}

class ProdutoFichaTecnicaGrouped {
	ProdutoFichaTecnica? produtoFichaTecnica; 

  ProdutoFichaTecnicaGrouped({
		this.produtoFichaTecnica, 

  });
}
