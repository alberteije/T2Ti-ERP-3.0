import 'package:loja_virtual/app/data/provider/api/api_provider_base.dart';
import 'package:loja_virtual/app/data/model/model_imports.dart';

class FinDocumentoOrigemApiProvider extends ApiProviderBase {
  static const _path = '/fin-documento-origem';

  Future<List<FinDocumentoOrigemModel>?> getList({Filter? filter}) {
    return super.getListBase(
      '$_path/',
      (json) => FinDocumentoOrigemModel.fromJson(json),
      filter: filter,
    );
  }

  Future<FinDocumentoOrigemModel?> getObject(dynamic pk) {
    return super.getObjectBase(
      _path,
      pk,
      (json) => FinDocumentoOrigemModel.fromJson(json),
    );
  }

  Future<FinDocumentoOrigemModel?>? insert(FinDocumentoOrigemModel model) {
    return super.insertBase(
      _path,
      model,
      (json) => FinDocumentoOrigemModel.fromJson(json),
    );
  }

  Future<FinDocumentoOrigemModel?>? update(FinDocumentoOrigemModel model) {
    return super.updateBase(
      _path,
      model,
      (json) => FinDocumentoOrigemModel.fromJson(json),
    );
  }

  Future<bool?> delete(dynamic pk) {
    return super.deleteBase(_path, pk);
  }
}
