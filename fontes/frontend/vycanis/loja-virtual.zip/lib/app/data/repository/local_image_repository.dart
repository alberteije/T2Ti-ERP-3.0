import 'dart:io';
import 'package:path/path.dart' as p;
import 'package:get/get.dart';

class LocalImageRepository {
  static const String baseImagePath = r'C:\T2Ti\Imagens\produtos';
  
  // Verifica se a imagem existe localmente
  Future<File?> getProductImage(int productId) async {
    try {
      // Lista de extensões para tentar
      final extensions = ['.jpg', '.jpeg', '.png', '.gif', '.webp'];
      
      for (final ext in extensions) {
        final imagePath = p.join(baseImagePath, '$productId$ext');
        final file = File(imagePath);
        
        if (await file.exists()) {
          return file;
        }
        
        final lowerPath = p.join(baseImagePath, '${productId.toString().toLowerCase()}$ext');
        final lowerFile = File(lowerPath);
        
        if (await lowerFile.exists()) {
          return lowerFile;
        }
      }
      
      return null;
    } catch (e) {
      Get.log('Erro ao buscar imagem local: $e');
      return null;
    }
  }
  
  // Método alternativo: retorna o caminho como string para uso com Image.file
  Future<String?> getProductImagePath(int productId) async {
    try {
      final extensions = ['.jpg', '.jpeg', '.png', '.gif', '.webp'];
      
      for (final ext in extensions) {
        final imagePath = p.join(baseImagePath, '$productId$ext');
        if (await File(imagePath).exists()) {
          return imagePath;
        }
        
        final lowerPath = p.join(baseImagePath, '${productId.toString().toLowerCase()}$ext');
        if (await File(lowerPath).exists()) {
          return lowerPath;
        }
      }
      
      return null;
    } catch (e) {
      Get.log('Erro ao buscar caminho da imagem: $e');
      return null;
    }
  }

  Future<bool> hasLocalImages() async {
    try {
      final dir = Directory(baseImagePath);
      return await dir.exists();
    } catch (e) {
      return false;
    }
  }
}