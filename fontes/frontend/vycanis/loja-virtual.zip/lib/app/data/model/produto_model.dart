import 'dart:convert';
import 'package:pluto_grid/pluto_grid.dart';
import 'package:loja_virtual/app/data/model/model_imports.dart';

import 'package:loja_virtual/app/infra/infra_imports.dart';
import 'package:intl/intl.dart';
import 'package:loja_virtual/app/data/domain/domain_imports.dart';

class ProdutoModel extends ModelBase {
  int? id;
  int? idProdutoSubgrupo;
  int? idProdutoMarca;
  int? idProdutoUnidade;
  String? tipoItem;
  String? nome;
  String? descricao;
  String? gtin;
  String? codigoInterno;
  double? valorCompra;
  double? valorVenda;
  String? codigoNcm;
  String? codigoNbs;
  String? codigoCest;
  DateTime? dataCadastro;
  double? quantidadeEstoque;
  double? estoqueMinimo;
  double? estoqueMaximo;
  double? estoqueIdeal;
  String? pesavel;
  double? peso;
  double? markup;
  double? precoSugerido;
  double? precoVendaMinimo;
  double? custoPercentual;
  double? custoUnitario;
  double? custoProducao;
  double? custoMedioLiquido;
  double? precoLucroZero;
  double? precoLucroMinimo;
  double? precoLucroMaximo;
  double? margemLucro;
  int? codigoBalanca;
  String? classeAbc;
  String? ativo;
  String? informacoesAdicionaisNfe;
  ProdutoMarcaModel? produtoMarcaModel;
  ProdutoUnidadeModel? produtoUnidadeModel;
  ProdutoSubgrupoModel? produtoSubgrupoModel;
  List<ProdutoFichaTecnicaModel>? produtoFichaTecnicaModelList;
  List<ProdutoPromocaoModel>? produtoPromocaoModelList;

  ProdutoModel({
    this.id,
    this.idProdutoSubgrupo,
    this.idProdutoMarca,
    this.idProdutoUnidade,
    this.tipoItem = 'Produto',
    this.nome,
    this.descricao,
    this.gtin,
    this.codigoInterno,
    this.valorCompra,
    this.valorVenda,
    this.codigoNcm,
    this.codigoNbs,
    this.codigoCest,
    this.dataCadastro,
    this.quantidadeEstoque,
    this.estoqueMinimo,
    this.estoqueMaximo,
    this.estoqueIdeal,
    this.pesavel = 'Sim',
    this.peso,
    this.markup,
    this.precoSugerido,
    this.precoVendaMinimo,
    this.custoPercentual,
    this.custoUnitario,
    this.custoProducao,
    this.custoMedioLiquido,
    this.precoLucroZero,
    this.precoLucroMinimo,
    this.precoLucroMaximo,
    this.margemLucro,
    this.codigoBalanca,
    this.classeAbc = 'A',
    this.ativo = 'Sim',
    this.informacoesAdicionaisNfe,
    ProdutoMarcaModel? produtoMarcaModel,
    ProdutoUnidadeModel? produtoUnidadeModel,
    ProdutoSubgrupoModel? produtoSubgrupoModel,
    List<ProdutoFichaTecnicaModel>? produtoFichaTecnicaModelList,
    List<ProdutoPromocaoModel>? produtoPromocaoModelList,
  }) {
    this.produtoMarcaModel = produtoMarcaModel ?? ProdutoMarcaModel();
    this.produtoUnidadeModel = produtoUnidadeModel ?? ProdutoUnidadeModel();
    this.produtoSubgrupoModel = produtoSubgrupoModel ?? ProdutoSubgrupoModel();
    this.produtoFichaTecnicaModelList = produtoFichaTecnicaModelList?.toList(growable: true) ?? [];
    this.produtoPromocaoModelList = produtoPromocaoModelList?.toList(growable: true) ?? [];
  }

  static List<String> dbColumns = <String>[
    'id',
    'tipo_item',
    'nome',
    'descricao',
    'gtin',
    'codigo_interno',
    'valor_compra',
    'valor_venda',
    'codigo_ncm',
    'codigo_nbs',
    'codigo_cest',
    'data_cadastro',
    'quantidade_estoque',
    'estoque_minimo',
    'estoque_maximo',
    'estoque_ideal',
    'pesavel',
    'peso',
    'markup',
    'preco_sugerido',
    'preco_venda_minimo',
    'custo_percentual',
    'custo_unitario',
    'custo_producao',
    'custo_medio_liquido',
    'preco_lucro_zero',
    'preco_lucro_minimo',
    'preco_lucro_maximo',
    'margem_lucro',
    'codigo_balanca',
    'classe_abc',
    'ativo',
    'informacoes_adicionais_nfe',
  ];

  static List<String> aliasColumns = <String>[
    'Id',
    'Tipo Item',
    'Nome',
    'Descricao',
    'Gtin',
    'Codigo Interno',
    'Valor Compra',
    'Valor Venda',
    'Codigo Ncm',
    'Codigo Nbs',
    'Codigo Cest',
    'Data Cadastro',
    'Quantidade Estoque',
    'Estoque Minimo',
    'Estoque Maximo',
    'Estoque Ideal',
    'Pesavel',
    'Peso',
    'Markup',
    'Preco Sugerido',
    'Preco Venda Minimo',
    'Custo Percentual',
    'Custo Unitario',
    'Custo Producao',
    'Custo Medio Liquido',
    'Preco Lucro Zero',
    'Preco Lucro Minimo',
    'Preco Lucro Maximo',
    'Margem Lucro',
    'Codigo Balanca',
    'Classe Abc',
    'Ativo',
    'Informacoes Adicionais Nfe',
  ];

  ProdutoModel.fromJson(Map<String, dynamic> jsonData) {
    id = jsonData['id'];
    idProdutoSubgrupo = jsonData['idProdutoSubgrupo'];
    idProdutoMarca = jsonData['idProdutoMarca'];
    idProdutoUnidade = jsonData['idProdutoUnidade'];
    tipoItem = ProdutoDomain.getTipoItem(jsonData['tipoItem']);
    nome = jsonData['nome'];
    descricao = jsonData['descricao'];
    gtin = jsonData['gtin'];
    codigoInterno = jsonData['codigoInterno'];
    valorCompra = jsonData['valorCompra']?.toDouble();
    valorVenda = jsonData['valorVenda']?.toDouble();
    codigoNcm = jsonData['codigoNcm'];
    codigoNbs = jsonData['codigoNbs'];
    codigoCest = jsonData['codigoCest'];
    dataCadastro = jsonData['dataCadastro'] != null ? DateTime.tryParse(jsonData['dataCadastro']) : null;
    quantidadeEstoque = jsonData['quantidadeEstoque']?.toDouble();
    estoqueMinimo = jsonData['estoqueMinimo']?.toDouble();
    estoqueMaximo = jsonData['estoqueMaximo']?.toDouble();
    estoqueIdeal = jsonData['estoqueIdeal']?.toDouble();
    pesavel = ProdutoDomain.getPesavel(jsonData['pesavel']);
    peso = jsonData['peso']?.toDouble();
    markup = jsonData['markup']?.toDouble();
    precoSugerido = jsonData['precoSugerido']?.toDouble();
    precoVendaMinimo = jsonData['precoVendaMinimo']?.toDouble();
    custoPercentual = jsonData['custoPercentual']?.toDouble();
    custoUnitario = jsonData['custoUnitario']?.toDouble();
    custoProducao = jsonData['custoProducao']?.toDouble();
    custoMedioLiquido = jsonData['custoMedioLiquido']?.toDouble();
    precoLucroZero = jsonData['precoLucroZero']?.toDouble();
    precoLucroMinimo = jsonData['precoLucroMinimo']?.toDouble();
    precoLucroMaximo = jsonData['precoLucroMaximo']?.toDouble();
    margemLucro = jsonData['margemLucro']?.toDouble();
    codigoBalanca = jsonData['codigoBalanca'];
    classeAbc = ProdutoDomain.getClasseAbc(jsonData['classeAbc']);
    ativo = ProdutoDomain.getAtivo(jsonData['ativo']);
    informacoesAdicionaisNfe = jsonData['informacoesAdicionaisNfe'];
    produtoMarcaModel = jsonData['produtoMarcaModel'] == null ? ProdutoMarcaModel() : ProdutoMarcaModel.fromJson(jsonData['produtoMarcaModel']);
    produtoUnidadeModel = jsonData['produtoUnidadeModel'] == null ? ProdutoUnidadeModel() : ProdutoUnidadeModel.fromJson(jsonData['produtoUnidadeModel']);
    produtoSubgrupoModel = jsonData['produtoSubgrupoModel'] == null ? ProdutoSubgrupoModel() : ProdutoSubgrupoModel.fromJson(jsonData['produtoSubgrupoModel']);
    produtoFichaTecnicaModelList = (jsonData['produtoFichaTecnicaModelList'] as Iterable?)?.map((m) => ProdutoFichaTecnicaModel.fromJson(m)).toList() ?? [];
    produtoPromocaoModelList = (jsonData['produtoPromocaoModelList'] as Iterable?)?.map((m) => ProdutoPromocaoModel.fromJson(m)).toList() ?? [];
  }

  Map<String, dynamic> get toJson {
    Map<String, dynamic> jsonData = <String, dynamic>{};

    jsonData['id'] = id != 0 ? id : null;
    jsonData['idProdutoSubgrupo'] = idProdutoSubgrupo != 0 ? idProdutoSubgrupo : null;
    jsonData['idProdutoMarca'] = idProdutoMarca != 0 ? idProdutoMarca : null;
    jsonData['idProdutoUnidade'] = idProdutoUnidade != 0 ? idProdutoUnidade : null;
    jsonData['tipoItem'] = ProdutoDomain.setTipoItem(tipoItem);
    jsonData['nome'] = nome;
    jsonData['descricao'] = descricao;
    jsonData['gtin'] = gtin;
    jsonData['codigoInterno'] = codigoInterno;
    jsonData['valorCompra'] = valorCompra;
    jsonData['valorVenda'] = valorVenda;
    jsonData['codigoNcm'] = codigoNcm;
    jsonData['codigoNbs'] = codigoNbs;
    jsonData['codigoCest'] = codigoCest;
    jsonData['dataCadastro'] = dataCadastro != null ? DateFormat('yyyy-MM-ddT00:00:00').format(dataCadastro!) : null;
    jsonData['quantidadeEstoque'] = quantidadeEstoque;
    jsonData['estoqueMinimo'] = estoqueMinimo;
    jsonData['estoqueMaximo'] = estoqueMaximo;
    jsonData['estoqueIdeal'] = estoqueIdeal;
    jsonData['pesavel'] = ProdutoDomain.setPesavel(pesavel);
    jsonData['peso'] = peso;
    jsonData['markup'] = markup;
    jsonData['precoSugerido'] = precoSugerido;
    jsonData['precoVendaMinimo'] = precoVendaMinimo;
    jsonData['custoPercentual'] = custoPercentual;
    jsonData['custoUnitario'] = custoUnitario;
    jsonData['custoProducao'] = custoProducao;
    jsonData['custoMedioLiquido'] = custoMedioLiquido;
    jsonData['precoLucroZero'] = precoLucroZero;
    jsonData['precoLucroMinimo'] = precoLucroMinimo;
    jsonData['precoLucroMaximo'] = precoLucroMaximo;
    jsonData['margemLucro'] = margemLucro;
    jsonData['codigoBalanca'] = codigoBalanca;
    jsonData['classeAbc'] = ProdutoDomain.setClasseAbc(classeAbc);
    jsonData['ativo'] = ProdutoDomain.setAtivo(ativo);
    jsonData['informacoesAdicionaisNfe'] = informacoesAdicionaisNfe;
    jsonData['produtoMarcaModel'] = produtoMarcaModel?.toJson;
    jsonData['produtoMarca'] = produtoMarcaModel?.nome ?? '';
    jsonData['produtoUnidadeModel'] = produtoUnidadeModel?.toJson;
    jsonData['produtoUnidade'] = produtoUnidadeModel?.sigla ?? '';
    jsonData['produtoSubgrupoModel'] = produtoSubgrupoModel?.toJson;
    jsonData['produtoSubgrupo'] = produtoSubgrupoModel?.nome ?? '';
    
		var produtoFichaTecnicaModelLocalList = []; 
		for (ProdutoFichaTecnicaModel object in produtoFichaTecnicaModelList ?? []) { 
			produtoFichaTecnicaModelLocalList.add(object.toJson); 
		}
		jsonData['produtoFichaTecnicaModelList'] = produtoFichaTecnicaModelLocalList;
    
		var produtoPromocaoModelLocalList = []; 
		for (ProdutoPromocaoModel object in produtoPromocaoModelList ?? []) { 
			produtoPromocaoModelLocalList.add(object.toJson); 
		}
		jsonData['produtoPromocaoModelList'] = produtoPromocaoModelLocalList;

    return jsonData;
  }

  String objectEncodeJson() {
    final jsonData = toJson;
    return json.encode(jsonData);
  }

  static ProdutoModel fromPlutoRow(PlutoRow row) {
    return ProdutoModel(
      id: row.cells['id']?.value,
      idProdutoSubgrupo: row.cells['idProdutoSubgrupo']?.value,
      idProdutoMarca: row.cells['idProdutoMarca']?.value,
      idProdutoUnidade: row.cells['idProdutoUnidade']?.value,
      tipoItem: row.cells['tipoItem']?.value,
      nome: row.cells['nome']?.value,
      descricao: row.cells['descricao']?.value,
      gtin: row.cells['gtin']?.value,
      codigoInterno: row.cells['codigoInterno']?.value,
      valorCompra: row.cells['valorCompra']?.value,
      valorVenda: row.cells['valorVenda']?.value,
      codigoNcm: row.cells['codigoNcm']?.value,
      codigoNbs: row.cells['codigoNbs']?.value,
      codigoCest: row.cells['codigoCest']?.value,
      dataCadastro: Util.stringToDate(row.cells['dataCadastro']?.value),
      quantidadeEstoque: row.cells['quantidadeEstoque']?.value,
      estoqueMinimo: row.cells['estoqueMinimo']?.value,
      estoqueMaximo: row.cells['estoqueMaximo']?.value,
      estoqueIdeal: row.cells['estoqueIdeal']?.value,
      pesavel: row.cells['pesavel']?.value,
      peso: row.cells['peso']?.value,
      markup: row.cells['markup']?.value,
      precoSugerido: row.cells['precoSugerido']?.value,
      precoVendaMinimo: row.cells['precoVendaMinimo']?.value,
      custoPercentual: row.cells['custoPercentual']?.value,
      custoUnitario: row.cells['custoUnitario']?.value,
      custoProducao: row.cells['custoProducao']?.value,
      custoMedioLiquido: row.cells['custoMedioLiquido']?.value,
      precoLucroZero: row.cells['precoLucroZero']?.value,
      precoLucroMinimo: row.cells['precoLucroMinimo']?.value,
      precoLucroMaximo: row.cells['precoLucroMaximo']?.value,
      margemLucro: row.cells['margemLucro']?.value,
      codigoBalanca: row.cells['codigoBalanca']?.value,
      classeAbc: row.cells['classeAbc']?.value,
      ativo: row.cells['ativo']?.value,
      informacoesAdicionaisNfe: row.cells['informacoesAdicionaisNfe']?.value,
    );
  }

  PlutoRow toPlutoRow() {
    return PlutoRow(
      cells: {
        'tempId': PlutoCell(value: tempId),
        'id': PlutoCell(value: id ?? 0),
        'idProdutoSubgrupo': PlutoCell(value: idProdutoSubgrupo ?? 0),
        'idProdutoMarca': PlutoCell(value: idProdutoMarca ?? 0),
        'idProdutoUnidade': PlutoCell(value: idProdutoUnidade ?? 0),
        'tipoItem': PlutoCell(value: tipoItem ?? ''),
        'nome': PlutoCell(value: nome ?? ''),
        'descricao': PlutoCell(value: descricao ?? ''),
        'gtin': PlutoCell(value: gtin ?? ''),
        'codigoInterno': PlutoCell(value: codigoInterno ?? ''),
        'valorCompra': PlutoCell(value: valorCompra ?? 0.0),
        'valorVenda': PlutoCell(value: valorVenda ?? 0.0),
        'codigoNcm': PlutoCell(value: codigoNcm ?? ''),
        'codigoNbs': PlutoCell(value: codigoNbs ?? ''),
        'codigoCest': PlutoCell(value: codigoCest ?? ''),
        'dataCadastro': PlutoCell(value: dataCadastro),
        'quantidadeEstoque': PlutoCell(value: quantidadeEstoque ?? 0.0),
        'estoqueMinimo': PlutoCell(value: estoqueMinimo ?? 0.0),
        'estoqueMaximo': PlutoCell(value: estoqueMaximo ?? 0.0),
        'estoqueIdeal': PlutoCell(value: estoqueIdeal ?? 0.0),
        'pesavel': PlutoCell(value: pesavel ?? ''),
        'peso': PlutoCell(value: peso ?? 0.0),
        'markup': PlutoCell(value: markup ?? 0.0),
        'precoSugerido': PlutoCell(value: precoSugerido ?? 0.0),
        'precoVendaMinimo': PlutoCell(value: precoVendaMinimo ?? 0.0),
        'custoPercentual': PlutoCell(value: custoPercentual ?? 0.0),
        'custoUnitario': PlutoCell(value: custoUnitario ?? 0.0),
        'custoProducao': PlutoCell(value: custoProducao ?? 0.0),
        'custoMedioLiquido': PlutoCell(value: custoMedioLiquido ?? 0.0),
        'precoLucroZero': PlutoCell(value: precoLucroZero ?? 0.0),
        'precoLucroMinimo': PlutoCell(value: precoLucroMinimo ?? 0.0),
        'precoLucroMaximo': PlutoCell(value: precoLucroMaximo ?? 0.0),
        'margemLucro': PlutoCell(value: margemLucro ?? 0.0),
        'codigoBalanca': PlutoCell(value: codigoBalanca ?? 0),
        'classeAbc': PlutoCell(value: classeAbc ?? ''),
        'ativo': PlutoCell(value: ativo ?? ''),
        'informacoesAdicionaisNfe': PlutoCell(value: informacoesAdicionaisNfe ?? ''),
        'produtoMarca': PlutoCell(value: produtoMarcaModel?.nome ?? ''),
        'produtoUnidade': PlutoCell(value: produtoUnidadeModel?.sigla ?? ''),
        'produtoSubgrupo': PlutoCell(value: produtoSubgrupoModel?.nome ?? ''),
      },
    );
  }

  ProdutoModel clone() {
    return ProdutoModel(
      id: id,
      idProdutoSubgrupo: idProdutoSubgrupo,
      idProdutoMarca: idProdutoMarca,
      idProdutoUnidade: idProdutoUnidade,
      tipoItem: tipoItem,
      nome: nome,
      descricao: descricao,
      gtin: gtin,
      codigoInterno: codigoInterno,
      valorCompra: valorCompra,
      valorVenda: valorVenda,
      codigoNcm: codigoNcm,
      codigoNbs: codigoNbs,
      codigoCest: codigoCest,
      dataCadastro: dataCadastro,
      quantidadeEstoque: quantidadeEstoque,
      estoqueMinimo: estoqueMinimo,
      estoqueMaximo: estoqueMaximo,
      estoqueIdeal: estoqueIdeal,
      pesavel: pesavel,
      peso: peso,
      markup: markup,
      precoSugerido: precoSugerido,
      precoVendaMinimo: precoVendaMinimo,
      custoPercentual: custoPercentual,
      custoUnitario: custoUnitario,
      custoProducao: custoProducao,
      custoMedioLiquido: custoMedioLiquido,
      precoLucroZero: precoLucroZero,
      precoLucroMinimo: precoLucroMinimo,
      precoLucroMaximo: precoLucroMaximo,
      margemLucro: margemLucro,
      codigoBalanca: codigoBalanca,
      classeAbc: classeAbc,
      ativo: ativo,
      informacoesAdicionaisNfe: informacoesAdicionaisNfe,
      produtoMarcaModel: produtoMarcaModel?.clone(),
      produtoUnidadeModel: produtoUnidadeModel?.clone(),
      produtoSubgrupoModel: produtoSubgrupoModel?.clone(),
      produtoFichaTecnicaModelList: produtoFichaTecnicaModelListClone(produtoFichaTecnicaModelList!),
      produtoPromocaoModelList: produtoPromocaoModelListClone(produtoPromocaoModelList!),
    );
  }

  produtoFichaTecnicaModelListClone(List<ProdutoFichaTecnicaModel> produtoFichaTecnicaModelList) { 
		List<ProdutoFichaTecnicaModel> resultList = [];
		for (var produtoFichaTecnicaModel in produtoFichaTecnicaModelList) {
			resultList.add(produtoFichaTecnicaModel.clone());
		}
		return resultList;
	}

  produtoPromocaoModelListClone(List<ProdutoPromocaoModel> produtoPromocaoModelList) { 
		List<ProdutoPromocaoModel> resultList = [];
		for (var produtoPromocaoModel in produtoPromocaoModelList) {
			resultList.add(produtoPromocaoModel.clone());
		}
		return resultList;
	}


}