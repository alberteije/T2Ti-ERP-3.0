import 'dart:convert';
import 'package:pluto_grid/pluto_grid.dart';
import 'package:loja_virtual/app/data/model/model_imports.dart';


class ProdutoFichaTecnicaModel extends ModelBase {
  int? id;
  int? idProduto;
  String? descricao;
  int? idProdutoFilho;
  double? quantidade;
  double? valorCusto;
  double? percentualCusto;

  ProdutoFichaTecnicaModel({
    this.id,
    this.idProduto,
    this.descricao,
    this.idProdutoFilho,
    this.quantidade,
    this.valorCusto,
    this.percentualCusto,
  });

  static List<String> dbColumns = <String>[
    'id',
    'descricao',
    'id_produto_filho',
    'quantidade',
    'valor_custo',
    'percentual_custo',
  ];

  static List<String> aliasColumns = <String>[
    'Id',
    'Descricao',
    'Id Produto Filho',
    'Quantidade',
    'Valor Custo',
    'Percentual Custo',
  ];

  ProdutoFichaTecnicaModel.fromJson(Map<String, dynamic> jsonData) {
    id = jsonData['id'];
    idProduto = jsonData['idProduto'];
    descricao = jsonData['descricao'];
    idProdutoFilho = jsonData['idProdutoFilho'];
    quantidade = jsonData['quantidade']?.toDouble();
    valorCusto = jsonData['valorCusto']?.toDouble();
    percentualCusto = jsonData['percentualCusto']?.toDouble();
  }

  Map<String, dynamic> get toJson {
    Map<String, dynamic> jsonData = <String, dynamic>{};

    jsonData['id'] = id != 0 ? id : null;
    jsonData['idProduto'] = idProduto != 0 ? idProduto : null;
    jsonData['descricao'] = descricao;
    jsonData['idProdutoFilho'] = idProdutoFilho;
    jsonData['quantidade'] = quantidade;
    jsonData['valorCusto'] = valorCusto;
    jsonData['percentualCusto'] = percentualCusto;

    return jsonData;
  }

  String objectEncodeJson() {
    final jsonData = toJson;
    return json.encode(jsonData);
  }

  static ProdutoFichaTecnicaModel fromPlutoRow(PlutoRow row) {
    return ProdutoFichaTecnicaModel(
      id: row.cells['id']?.value,
      idProduto: row.cells['idProduto']?.value,
      descricao: row.cells['descricao']?.value,
      idProdutoFilho: row.cells['idProdutoFilho']?.value,
      quantidade: row.cells['quantidade']?.value,
      valorCusto: row.cells['valorCusto']?.value,
      percentualCusto: row.cells['percentualCusto']?.value,
    );
  }

  PlutoRow toPlutoRow() {
    return PlutoRow(
      cells: {
        'tempId': PlutoCell(value: tempId),
        'id': PlutoCell(value: id ?? 0),
        'idProduto': PlutoCell(value: idProduto ?? 0),
        'descricao': PlutoCell(value: descricao ?? ''),
        'idProdutoFilho': PlutoCell(value: idProdutoFilho ?? 0),
        'quantidade': PlutoCell(value: quantidade ?? 0.0),
        'valorCusto': PlutoCell(value: valorCusto ?? 0.0),
        'percentualCusto': PlutoCell(value: percentualCusto ?? 0.0),
      },
    );
  }

  ProdutoFichaTecnicaModel clone() {
    return ProdutoFichaTecnicaModel(
      id: id,
      idProduto: idProduto,
      descricao: descricao,
      idProdutoFilho: idProdutoFilho,
      quantidade: quantidade,
      valorCusto: valorCusto,
      percentualCusto: percentualCusto,
    );
  }


}