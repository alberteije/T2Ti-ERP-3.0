import 'dart:convert';
import 'package:pluto_grid/pluto_grid.dart';
import 'package:loja_virtual/app/data/model/model_imports.dart';

import 'package:loja_virtual/app/data/domain/domain_imports.dart';

class TabelaPrecoModel extends ModelBase {
  int? id;
  String? nome;
  String? principal;
  double? coeficiente;
  double? valorFixo;
  String? tipoAjuste;

  TabelaPrecoModel({
    this.id,
    this.nome,
    this.principal = 'Sim',
    this.coeficiente,
    this.valorFixo,
    this.tipoAjuste = 'Coeficiente',
  });

  static List<String> dbColumns = <String>[
    'id',
    'nome',
    'principal',
    'coeficiente',
    'valor_fixo',
    'tipo_ajuste',
  ];

  static List<String> aliasColumns = <String>[
    'Id',
    'Nome',
    'Principal',
    'Coeficiente',
    'Valor Fixo',
    'Tipo Ajuste',
  ];

  TabelaPrecoModel.fromJson(Map<String, dynamic> jsonData) {
    id = jsonData['id'];
    nome = jsonData['nome'];
    principal = TabelaPrecoDomain.getPrincipal(jsonData['principal']);
    coeficiente = jsonData['coeficiente']?.toDouble();
    valorFixo = jsonData['valorFixo']?.toDouble();
    tipoAjuste = TabelaPrecoDomain.getTipoAjuste(jsonData['tipoAjuste']);
  }

  Map<String, dynamic> get toJson {
    Map<String, dynamic> jsonData = <String, dynamic>{};

    jsonData['id'] = id != 0 ? id : null;
    jsonData['nome'] = nome;
    jsonData['principal'] = TabelaPrecoDomain.setPrincipal(principal);
    jsonData['coeficiente'] = coeficiente;
    jsonData['valorFixo'] = valorFixo;
    jsonData['tipoAjuste'] = TabelaPrecoDomain.setTipoAjuste(tipoAjuste);

    return jsonData;
  }

  String objectEncodeJson() {
    final jsonData = toJson;
    return json.encode(jsonData);
  }

  static TabelaPrecoModel fromPlutoRow(PlutoRow row) {
    return TabelaPrecoModel(
      id: row.cells['id']?.value,
      nome: row.cells['nome']?.value,
      principal: row.cells['principal']?.value,
      coeficiente: row.cells['coeficiente']?.value,
      valorFixo: row.cells['valorFixo']?.value,
      tipoAjuste: row.cells['tipoAjuste']?.value,
    );
  }

  PlutoRow toPlutoRow() {
    return PlutoRow(
      cells: {
        'tempId': PlutoCell(value: tempId),
        'id': PlutoCell(value: id ?? 0),
        'nome': PlutoCell(value: nome ?? ''),
        'principal': PlutoCell(value: principal ?? ''),
        'coeficiente': PlutoCell(value: coeficiente ?? 0.0),
        'valorFixo': PlutoCell(value: valorFixo ?? 0.0),
        'tipoAjuste': PlutoCell(value: tipoAjuste ?? ''),
      },
    );
  }

  TabelaPrecoModel clone() {
    return TabelaPrecoModel(
      id: id,
      nome: nome,
      principal: principal,
      coeficiente: coeficiente,
      valorFixo: valorFixo,
      tipoAjuste: tipoAjuste,
    );
  }


}