import 'dart:convert';
import 'package:pluto_grid/pluto_grid.dart';
import 'package:loja_virtual/app/data/model/model_imports.dart';

import 'package:loja_virtual/app/infra/infra_imports.dart';
import 'package:intl/intl.dart';
import 'package:loja_virtual/app/data/domain/domain_imports.dart';

class VendaCabecalhoModel extends ModelBase {
  int? id;
  int? idNotaFiscalTipo;
  int? idVendedor;
  int? idVendaCondicoesPagamento;
  int? idTransportadora;
  int? idCliente;
  String? localEntrega;
  String? localCobranca;
  String? tipoFrete;
  String? formaPagamento;
  DateTime? dataVenda;
  DateTime? dataSaida;
  String? horaSaida;
  int? numeroFatura;
  double? valorFrete;
  double? valorSeguro;
  double? valorSubtotal;
  double? taxaComissao;
  double? valorComissao;
  double? taxaDesconto;
  double? valorDesconto;
  double? valorTotal;
  String? situacao;
  String? diaFixoParcela;
  String? observacao;
  List<VendaDetalheModel>? vendaDetalheModelList;
  List<VendaFreteModel>? vendaFreteModelList;
  VendaCondicoesPagamentoModel? vendaCondicoesPagamentoModel;
  ViewPessoaVendedorModel? viewPessoaVendedorModel;
  ViewPessoaTransportadoraModel? viewPessoaTransportadoraModel;
  ViewPessoaClienteModel? viewPessoaClienteModel;
  NotaFiscalTipoModel? notaFiscalTipoModel;

  VendaCabecalhoModel({
    this.id,
    this.idNotaFiscalTipo,
    this.idVendedor,
    this.idVendaCondicoesPagamento,
    this.idTransportadora,
    this.idCliente,
    this.localEntrega,
    this.localCobranca,
    this.tipoFrete = 'CIF',
    this.formaPagamento = 'A Vista',
    this.dataVenda,
    this.dataSaida,
    this.horaSaida,
    this.numeroFatura,
    this.valorFrete,
    this.valorSeguro,
    this.valorSubtotal,
    this.taxaComissao,
    this.valorComissao,
    this.taxaDesconto,
    this.valorDesconto,
    this.valorTotal,
    this.situacao = 'Digitação',
    this.diaFixoParcela,
    this.observacao,
    List<VendaDetalheModel>? vendaDetalheModelList,
    List<VendaFreteModel>? vendaFreteModelList,
    VendaCondicoesPagamentoModel? vendaCondicoesPagamentoModel,
    ViewPessoaVendedorModel? viewPessoaVendedorModel,
    ViewPessoaTransportadoraModel? viewPessoaTransportadoraModel,
    ViewPessoaClienteModel? viewPessoaClienteModel,
    NotaFiscalTipoModel? notaFiscalTipoModel,
  }) {
    this.vendaDetalheModelList = vendaDetalheModelList?.toList(growable: true) ?? [];
    this.vendaFreteModelList = vendaFreteModelList?.toList(growable: true) ?? [];
    this.vendaCondicoesPagamentoModel = vendaCondicoesPagamentoModel ?? VendaCondicoesPagamentoModel();
    this.viewPessoaVendedorModel = viewPessoaVendedorModel ?? ViewPessoaVendedorModel();
    this.viewPessoaTransportadoraModel = viewPessoaTransportadoraModel ?? ViewPessoaTransportadoraModel();
    this.viewPessoaClienteModel = viewPessoaClienteModel ?? ViewPessoaClienteModel();
    this.notaFiscalTipoModel = notaFiscalTipoModel ?? NotaFiscalTipoModel();
  }

  static List<String> dbColumns = <String>[
    'id',
    'local_entrega',
    'local_cobranca',
    'tipo_frete',
    'forma_pagamento',
    'data_venda',
    'data_saida',
    'hora_saida',
    'numero_fatura',
    'valor_frete',
    'valor_seguro',
    'valor_subtotal',
    'taxa_comissao',
    'valor_comissao',
    'taxa_desconto',
    'valor_desconto',
    'valor_total',
    'situacao',
    'dia_fixo_parcela',
    'observacao',
  ];

  static List<String> aliasColumns = <String>[
    'Id',
    'Local Entrega',
    'Local Cobranca',
    'Tipo Frete',
    'Forma Pagamento',
    'Data Venda',
    'Data Saida',
    'Hora Saida',
    'Numero Fatura',
    'Valor Frete',
    'Valor Seguro',
    'Valor Subtotal',
    'Taxa Comissao',
    'Valor Comissao',
    'Taxa Desconto',
    'Valor Desconto',
    'Valor Total',
    'Situacao',
    'Dia Fixo Parcela',
    'Observacao',
  ];

  VendaCabecalhoModel.fromJson(Map<String, dynamic> jsonData) {
    id = jsonData['id'];
    idNotaFiscalTipo = jsonData['idNotaFiscalTipo'];
    idVendedor = jsonData['idVendedor'];
    idVendaCondicoesPagamento = jsonData['idVendaCondicoesPagamento'];
    idTransportadora = jsonData['idTransportadora'];
    idCliente = jsonData['idCliente'];
    localEntrega = jsonData['localEntrega'];
    localCobranca = jsonData['localCobranca'];
    tipoFrete = VendaCabecalhoDomain.getTipoFrete(jsonData['tipoFrete']);
    formaPagamento = VendaCabecalhoDomain.getFormaPagamento(jsonData['formaPagamento']);
    dataVenda = jsonData['dataVenda'] != null ? DateTime.tryParse(jsonData['dataVenda']) : null;
    dataSaida = jsonData['dataSaida'] != null ? DateTime.tryParse(jsonData['dataSaida']) : null;
    horaSaida = jsonData['horaSaida'];
    numeroFatura = jsonData['numeroFatura'];
    valorFrete = jsonData['valorFrete']?.toDouble();
    valorSeguro = jsonData['valorSeguro']?.toDouble();
    valorSubtotal = jsonData['valorSubtotal']?.toDouble();
    taxaComissao = jsonData['taxaComissao']?.toDouble();
    valorComissao = jsonData['valorComissao']?.toDouble();
    taxaDesconto = jsonData['taxaDesconto']?.toDouble();
    valorDesconto = jsonData['valorDesconto']?.toDouble();
    valorTotal = jsonData['valorTotal']?.toDouble();
    situacao = VendaCabecalhoDomain.getSituacao(jsonData['situacao']);
    diaFixoParcela = jsonData['diaFixoParcela'];
    observacao = jsonData['observacao'];
    vendaDetalheModelList = (jsonData['vendaDetalheModelList'] as Iterable?)?.map((m) => VendaDetalheModel.fromJson(m)).toList() ?? [];
    vendaFreteModelList = (jsonData['vendaFreteModelList'] as Iterable?)?.map((m) => VendaFreteModel.fromJson(m)).toList() ?? [];
    vendaCondicoesPagamentoModel = jsonData['vendaCondicoesPagamentoModel'] == null ? VendaCondicoesPagamentoModel() : VendaCondicoesPagamentoModel.fromJson(jsonData['vendaCondicoesPagamentoModel']);
    viewPessoaVendedorModel = jsonData['viewPessoaVendedorModel'] == null ? ViewPessoaVendedorModel() : ViewPessoaVendedorModel.fromJson(jsonData['viewPessoaVendedorModel']);
    viewPessoaTransportadoraModel = jsonData['viewPessoaTransportadoraModel'] == null ? ViewPessoaTransportadoraModel() : ViewPessoaTransportadoraModel.fromJson(jsonData['viewPessoaTransportadoraModel']);
    viewPessoaClienteModel = jsonData['viewPessoaClienteModel'] == null ? ViewPessoaClienteModel() : ViewPessoaClienteModel.fromJson(jsonData['viewPessoaClienteModel']);
    notaFiscalTipoModel = jsonData['notaFiscalTipoModel'] == null ? NotaFiscalTipoModel() : NotaFiscalTipoModel.fromJson(jsonData['notaFiscalTipoModel']);
  }

  Map<String, dynamic> get toJson {
    Map<String, dynamic> jsonData = <String, dynamic>{};

    jsonData['id'] = id != 0 ? id : null;
    jsonData['idNotaFiscalTipo'] = idNotaFiscalTipo != 0 ? idNotaFiscalTipo : null;
    jsonData['idVendedor'] = idVendedor != 0 ? idVendedor : null;
    jsonData['idVendaCondicoesPagamento'] = idVendaCondicoesPagamento != 0 ? idVendaCondicoesPagamento : null;
    jsonData['idTransportadora'] = idTransportadora != 0 ? idTransportadora : null;
    jsonData['idCliente'] = idCliente != 0 ? idCliente : null;
    jsonData['localEntrega'] = localEntrega;
    jsonData['localCobranca'] = localCobranca;
    jsonData['tipoFrete'] = VendaCabecalhoDomain.setTipoFrete(tipoFrete);
    jsonData['formaPagamento'] = VendaCabecalhoDomain.setFormaPagamento(formaPagamento);
    jsonData['dataVenda'] = dataVenda != null ? DateFormat('yyyy-MM-ddT00:00:00').format(dataVenda!) : null;
    jsonData['dataSaida'] = dataSaida != null ? DateFormat('yyyy-MM-ddT00:00:00').format(dataSaida!) : null;
    jsonData['horaSaida'] = Util.removeMask(horaSaida);
    jsonData['numeroFatura'] = numeroFatura;
    jsonData['valorFrete'] = valorFrete;
    jsonData['valorSeguro'] = valorSeguro;
    jsonData['valorSubtotal'] = valorSubtotal;
    jsonData['taxaComissao'] = taxaComissao;
    jsonData['valorComissao'] = valorComissao;
    jsonData['taxaDesconto'] = taxaDesconto;
    jsonData['valorDesconto'] = valorDesconto;
    jsonData['valorTotal'] = valorTotal;
    jsonData['situacao'] = VendaCabecalhoDomain.setSituacao(situacao);
    jsonData['diaFixoParcela'] = diaFixoParcela;
    jsonData['observacao'] = observacao;
    
		var vendaDetalheModelLocalList = []; 
		for (VendaDetalheModel object in vendaDetalheModelList ?? []) { 
			vendaDetalheModelLocalList.add(object.toJson); 
		}
		jsonData['vendaDetalheModelList'] = vendaDetalheModelLocalList;
    
		var vendaFreteModelLocalList = []; 
		for (VendaFreteModel object in vendaFreteModelList ?? []) { 
			vendaFreteModelLocalList.add(object.toJson); 
		}
		jsonData['vendaFreteModelList'] = vendaFreteModelLocalList;
    jsonData['vendaCondicoesPagamentoModel'] = vendaCondicoesPagamentoModel?.toJson;
    jsonData['vendaCondicoesPagamento'] = vendaCondicoesPagamentoModel?.nome ?? '';
    jsonData['viewPessoaVendedorModel'] = viewPessoaVendedorModel?.toJson;
    jsonData['viewPessoaVendedor'] = viewPessoaVendedorModel?.nome ?? '';
    jsonData['viewPessoaTransportadoraModel'] = viewPessoaTransportadoraModel?.toJson;
    jsonData['viewPessoaTransportadora'] = viewPessoaTransportadoraModel?.nome ?? '';
    jsonData['viewPessoaClienteModel'] = viewPessoaClienteModel?.toJson;
    jsonData['viewPessoaCliente'] = viewPessoaClienteModel?.nome ?? '';
    jsonData['notaFiscalTipoModel'] = notaFiscalTipoModel?.toJson;
    jsonData['notaFiscalTipo'] = notaFiscalTipoModel?.nome ?? '';

    return jsonData;
  }

  String objectEncodeJson() {
    final jsonData = toJson;
    return json.encode(jsonData);
  }

  static VendaCabecalhoModel fromPlutoRow(PlutoRow row) {
    return VendaCabecalhoModel(
      id: row.cells['id']?.value,
      idNotaFiscalTipo: row.cells['idNotaFiscalTipo']?.value,
      idVendedor: row.cells['idVendedor']?.value,
      idVendaCondicoesPagamento: row.cells['idVendaCondicoesPagamento']?.value,
      idTransportadora: row.cells['idTransportadora']?.value,
      idCliente: row.cells['idCliente']?.value,
      localEntrega: row.cells['localEntrega']?.value,
      localCobranca: row.cells['localCobranca']?.value,
      tipoFrete: row.cells['tipoFrete']?.value,
      formaPagamento: row.cells['formaPagamento']?.value,
      dataVenda: Util.stringToDate(row.cells['dataVenda']?.value),
      dataSaida: Util.stringToDate(row.cells['dataSaida']?.value),
      horaSaida: row.cells['horaSaida']?.value,
      numeroFatura: row.cells['numeroFatura']?.value,
      valorFrete: row.cells['valorFrete']?.value,
      valorSeguro: row.cells['valorSeguro']?.value,
      valorSubtotal: row.cells['valorSubtotal']?.value,
      taxaComissao: row.cells['taxaComissao']?.value,
      valorComissao: row.cells['valorComissao']?.value,
      taxaDesconto: row.cells['taxaDesconto']?.value,
      valorDesconto: row.cells['valorDesconto']?.value,
      valorTotal: row.cells['valorTotal']?.value,
      situacao: row.cells['situacao']?.value,
      diaFixoParcela: row.cells['diaFixoParcela']?.value,
      observacao: row.cells['observacao']?.value,
    );
  }

  PlutoRow toPlutoRow() {
    return PlutoRow(
      cells: {
        'tempId': PlutoCell(value: tempId),
        'id': PlutoCell(value: id ?? 0),
        'idNotaFiscalTipo': PlutoCell(value: idNotaFiscalTipo ?? 0),
        'idVendedor': PlutoCell(value: idVendedor ?? 0),
        'idVendaCondicoesPagamento': PlutoCell(value: idVendaCondicoesPagamento ?? 0),
        'idTransportadora': PlutoCell(value: idTransportadora ?? 0),
        'idCliente': PlutoCell(value: idCliente ?? 0),
        'localEntrega': PlutoCell(value: localEntrega ?? ''),
        'localCobranca': PlutoCell(value: localCobranca ?? ''),
        'tipoFrete': PlutoCell(value: tipoFrete ?? ''),
        'formaPagamento': PlutoCell(value: formaPagamento ?? ''),
        'dataVenda': PlutoCell(value: dataVenda),
        'dataSaida': PlutoCell(value: dataSaida),
        'horaSaida': PlutoCell(value: horaSaida ?? ''),
        'numeroFatura': PlutoCell(value: numeroFatura ?? 0),
        'valorFrete': PlutoCell(value: valorFrete ?? 0.0),
        'valorSeguro': PlutoCell(value: valorSeguro ?? 0.0),
        'valorSubtotal': PlutoCell(value: valorSubtotal ?? 0.0),
        'taxaComissao': PlutoCell(value: taxaComissao ?? 0.0),
        'valorComissao': PlutoCell(value: valorComissao ?? 0.0),
        'taxaDesconto': PlutoCell(value: taxaDesconto ?? 0.0),
        'valorDesconto': PlutoCell(value: valorDesconto ?? 0.0),
        'valorTotal': PlutoCell(value: valorTotal ?? 0.0),
        'situacao': PlutoCell(value: situacao ?? ''),
        'diaFixoParcela': PlutoCell(value: diaFixoParcela ?? ''),
        'observacao': PlutoCell(value: observacao ?? ''),
        'vendaCondicoesPagamento': PlutoCell(value: vendaCondicoesPagamentoModel?.nome ?? ''),
        'viewPessoaVendedor': PlutoCell(value: viewPessoaVendedorModel?.nome ?? ''),
        'viewPessoaTransportadora': PlutoCell(value: viewPessoaTransportadoraModel?.nome ?? ''),
        'viewPessoaCliente': PlutoCell(value: viewPessoaClienteModel?.nome ?? ''),
        'notaFiscalTipo': PlutoCell(value: notaFiscalTipoModel?.nome ?? ''),
      },
    );
  }

  VendaCabecalhoModel clone() {
    return VendaCabecalhoModel(
      id: id,
      idNotaFiscalTipo: idNotaFiscalTipo,
      idVendedor: idVendedor,
      idVendaCondicoesPagamento: idVendaCondicoesPagamento,
      idTransportadora: idTransportadora,
      idCliente: idCliente,
      localEntrega: localEntrega,
      localCobranca: localCobranca,
      tipoFrete: tipoFrete,
      formaPagamento: formaPagamento,
      dataVenda: dataVenda,
      dataSaida: dataSaida,
      horaSaida: horaSaida,
      numeroFatura: numeroFatura,
      valorFrete: valorFrete,
      valorSeguro: valorSeguro,
      valorSubtotal: valorSubtotal,
      taxaComissao: taxaComissao,
      valorComissao: valorComissao,
      taxaDesconto: taxaDesconto,
      valorDesconto: valorDesconto,
      valorTotal: valorTotal,
      situacao: situacao,
      diaFixoParcela: diaFixoParcela,
      observacao: observacao,
      vendaDetalheModelList: vendaDetalheModelListClone(vendaDetalheModelList!),
      vendaFreteModelList: vendaFreteModelListClone(vendaFreteModelList!),
      vendaCondicoesPagamentoModel: vendaCondicoesPagamentoModel?.clone(),
      viewPessoaVendedorModel: viewPessoaVendedorModel?.clone(),
      viewPessoaTransportadoraModel: viewPessoaTransportadoraModel?.clone(),
      viewPessoaClienteModel: viewPessoaClienteModel?.clone(),
      notaFiscalTipoModel: notaFiscalTipoModel?.clone(),
    );
  }

  vendaDetalheModelListClone(List<VendaDetalheModel> vendaDetalheModelList) { 
		List<VendaDetalheModel> resultList = [];
		for (var vendaDetalheModel in vendaDetalheModelList) {
			resultList.add(vendaDetalheModel.clone());
		}
		return resultList;
	}

  vendaFreteModelListClone(List<VendaFreteModel> vendaFreteModelList) { 
		List<VendaFreteModel> resultList = [];
		for (var vendaFreteModel in vendaFreteModelList) {
			resultList.add(vendaFreteModel.clone());
		}
		return resultList;
	}


}