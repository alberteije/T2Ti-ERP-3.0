import 'dart:convert';
import 'package:pluto_grid/pluto_grid.dart';
import 'package:loja_virtual/app/data/model/model_imports.dart';

import 'package:loja_virtual/app/infra/infra_imports.dart';
import 'package:intl/intl.dart';
import 'package:loja_virtual/app/data/domain/domain_imports.dart';

class FinParcelaReceberModel extends ModelBase {
  int? id;
  int? idFinLancamentoReceber;
  int? idFinStatusParcela;
  int? idFinTipoRecebimento;
  int? numeroParcela;
  DateTime? dataEmissao;
  DateTime? dataVencimento;
  DateTime? dataRecebimento;
  DateTime? descontoAte;
  double? valor;
  double? taxaJuro;
  double? taxaMulta;
  double? taxaDesconto;
  double? valorJuro;
  double? valorMulta;
  double? valorDesconto;
  String? emitiuBoleto;
  String? boletoNossoNumero;
  double? valorRecebido;
  String? historico;
  FinStatusParcelaModel? finStatusParcelaModel;
  FinTipoRecebimentoModel? finTipoRecebimentoModel;

  FinParcelaReceberModel({
    this.id,
    this.idFinLancamentoReceber,
    this.idFinStatusParcela,
    this.idFinTipoRecebimento,
    this.numeroParcela,
    this.dataEmissao,
    this.dataVencimento,
    this.dataRecebimento,
    this.descontoAte,
    this.valor,
    this.taxaJuro,
    this.taxaMulta,
    this.taxaDesconto,
    this.valorJuro,
    this.valorMulta,
    this.valorDesconto,
    this.emitiuBoleto = 'Sim',
    this.boletoNossoNumero,
    this.valorRecebido,
    this.historico,
    FinStatusParcelaModel? finStatusParcelaModel,
    FinTipoRecebimentoModel? finTipoRecebimentoModel,
  }) {
    this.finStatusParcelaModel = finStatusParcelaModel ?? FinStatusParcelaModel();
    this.finTipoRecebimentoModel = finTipoRecebimentoModel ?? FinTipoRecebimentoModel();
  }

  static List<String> dbColumns = <String>[
    'id',
    'numero_parcela',
    'data_emissao',
    'data_vencimento',
    'data_recebimento',
    'desconto_ate',
    'valor',
    'taxa_juro',
    'taxa_multa',
    'taxa_desconto',
    'valor_juro',
    'valor_multa',
    'valor_desconto',
    'emitiu_boleto',
    'boleto_nosso_numero',
    'valor_recebido',
    'historico',
  ];

  static List<String> aliasColumns = <String>[
    'Id',
    'Numero Parcela',
    'Data Emissao',
    'Data Vencimento',
    'Data Recebimento',
    'Desconto Ate',
    'Valor',
    'Taxa Juro',
    'Taxa Multa',
    'Taxa Desconto',
    'Valor Juro',
    'Valor Multa',
    'Valor Desconto',
    'Emitiu Boleto',
    'Boleto Nosso Numero',
    'Valor Recebido',
    'Historico',
  ];

  FinParcelaReceberModel.fromJson(Map<String, dynamic> jsonData) {
    id = jsonData['id'];
    idFinLancamentoReceber = jsonData['idFinLancamentoReceber'];
    idFinStatusParcela = jsonData['idFinStatusParcela'];
    idFinTipoRecebimento = jsonData['idFinTipoRecebimento'];
    numeroParcela = jsonData['numeroParcela'];
    dataEmissao = jsonData['dataEmissao'] != null ? DateTime.tryParse(jsonData['dataEmissao']) : null;
    dataVencimento = jsonData['dataVencimento'] != null ? DateTime.tryParse(jsonData['dataVencimento']) : null;
    dataRecebimento = jsonData['dataRecebimento'] != null ? DateTime.tryParse(jsonData['dataRecebimento']) : null;
    descontoAte = jsonData['descontoAte'] != null ? DateTime.tryParse(jsonData['descontoAte']) : null;
    valor = jsonData['valor']?.toDouble();
    taxaJuro = jsonData['taxaJuro']?.toDouble();
    taxaMulta = jsonData['taxaMulta']?.toDouble();
    taxaDesconto = jsonData['taxaDesconto']?.toDouble();
    valorJuro = jsonData['valorJuro']?.toDouble();
    valorMulta = jsonData['valorMulta']?.toDouble();
    valorDesconto = jsonData['valorDesconto']?.toDouble();
    emitiuBoleto = FinParcelaReceberDomain.getEmitiuBoleto(jsonData['emitiuBoleto']);
    boletoNossoNumero = jsonData['boletoNossoNumero'];
    valorRecebido = jsonData['valorRecebido']?.toDouble();
    historico = jsonData['historico'];
    finStatusParcelaModel = jsonData['finStatusParcelaModel'] == null ? FinStatusParcelaModel() : FinStatusParcelaModel.fromJson(jsonData['finStatusParcelaModel']);
    finTipoRecebimentoModel = jsonData['finTipoRecebimentoModel'] == null ? FinTipoRecebimentoModel() : FinTipoRecebimentoModel.fromJson(jsonData['finTipoRecebimentoModel']);
  }

  Map<String, dynamic> get toJson {
    Map<String, dynamic> jsonData = <String, dynamic>{};

    jsonData['id'] = id != 0 ? id : null;
    jsonData['idFinLancamentoReceber'] = idFinLancamentoReceber != 0 ? idFinLancamentoReceber : null;
    jsonData['idFinStatusParcela'] = idFinStatusParcela != 0 ? idFinStatusParcela : null;
    jsonData['idFinTipoRecebimento'] = idFinTipoRecebimento != 0 ? idFinTipoRecebimento : null;
    jsonData['numeroParcela'] = numeroParcela;
    jsonData['dataEmissao'] = dataEmissao != null ? DateFormat('yyyy-MM-ddT00:00:00').format(dataEmissao!) : null;
    jsonData['dataVencimento'] = dataVencimento != null ? DateFormat('yyyy-MM-ddT00:00:00').format(dataVencimento!) : null;
    jsonData['dataRecebimento'] = dataRecebimento != null ? DateFormat('yyyy-MM-ddT00:00:00').format(dataRecebimento!) : null;
    jsonData['descontoAte'] = descontoAte != null ? DateFormat('yyyy-MM-ddT00:00:00').format(descontoAte!) : null;
    jsonData['valor'] = valor;
    jsonData['taxaJuro'] = taxaJuro;
    jsonData['taxaMulta'] = taxaMulta;
    jsonData['taxaDesconto'] = taxaDesconto;
    jsonData['valorJuro'] = valorJuro;
    jsonData['valorMulta'] = valorMulta;
    jsonData['valorDesconto'] = valorDesconto;
    jsonData['emitiuBoleto'] = FinParcelaReceberDomain.setEmitiuBoleto(emitiuBoleto);
    jsonData['boletoNossoNumero'] = boletoNossoNumero;
    jsonData['valorRecebido'] = valorRecebido;
    jsonData['historico'] = historico;
    jsonData['finStatusParcelaModel'] = finStatusParcelaModel?.toJson;
    jsonData['finStatusParcela'] = finStatusParcelaModel?.descricao ?? '';
    jsonData['finTipoRecebimentoModel'] = finTipoRecebimentoModel?.toJson;
    jsonData['finTipoRecebimento'] = finTipoRecebimentoModel?.descricao ?? '';

    return jsonData;
  }

  String objectEncodeJson() {
    final jsonData = toJson;
    return json.encode(jsonData);
  }

  static FinParcelaReceberModel fromPlutoRow(PlutoRow row) {
    return FinParcelaReceberModel(
      id: row.cells['id']?.value,
      idFinLancamentoReceber: row.cells['idFinLancamentoReceber']?.value,
      idFinStatusParcela: row.cells['idFinStatusParcela']?.value,
      idFinTipoRecebimento: row.cells['idFinTipoRecebimento']?.value,
      numeroParcela: row.cells['numeroParcela']?.value,
      dataEmissao: Util.stringToDate(row.cells['dataEmissao']?.value),
      dataVencimento: Util.stringToDate(row.cells['dataVencimento']?.value),
      dataRecebimento: Util.stringToDate(row.cells['dataRecebimento']?.value),
      descontoAte: Util.stringToDate(row.cells['descontoAte']?.value),
      valor: row.cells['valor']?.value,
      taxaJuro: row.cells['taxaJuro']?.value,
      taxaMulta: row.cells['taxaMulta']?.value,
      taxaDesconto: row.cells['taxaDesconto']?.value,
      valorJuro: row.cells['valorJuro']?.value,
      valorMulta: row.cells['valorMulta']?.value,
      valorDesconto: row.cells['valorDesconto']?.value,
      emitiuBoleto: row.cells['emitiuBoleto']?.value,
      boletoNossoNumero: row.cells['boletoNossoNumero']?.value,
      valorRecebido: row.cells['valorRecebido']?.value,
      historico: row.cells['historico']?.value,
    );
  }

  PlutoRow toPlutoRow() {
    return PlutoRow(
      cells: {
        'tempId': PlutoCell(value: tempId),
        'id': PlutoCell(value: id ?? 0),
        'idFinLancamentoReceber': PlutoCell(value: idFinLancamentoReceber ?? 0),
        'idFinStatusParcela': PlutoCell(value: idFinStatusParcela ?? 0),
        'idFinTipoRecebimento': PlutoCell(value: idFinTipoRecebimento ?? 0),
        'numeroParcela': PlutoCell(value: numeroParcela ?? 0),
        'dataEmissao': PlutoCell(value: dataEmissao),
        'dataVencimento': PlutoCell(value: dataVencimento),
        'dataRecebimento': PlutoCell(value: dataRecebimento),
        'descontoAte': PlutoCell(value: descontoAte),
        'valor': PlutoCell(value: valor ?? 0.0),
        'taxaJuro': PlutoCell(value: taxaJuro ?? 0.0),
        'taxaMulta': PlutoCell(value: taxaMulta ?? 0.0),
        'taxaDesconto': PlutoCell(value: taxaDesconto ?? 0.0),
        'valorJuro': PlutoCell(value: valorJuro ?? 0.0),
        'valorMulta': PlutoCell(value: valorMulta ?? 0.0),
        'valorDesconto': PlutoCell(value: valorDesconto ?? 0.0),
        'emitiuBoleto': PlutoCell(value: emitiuBoleto ?? ''),
        'boletoNossoNumero': PlutoCell(value: boletoNossoNumero ?? ''),
        'valorRecebido': PlutoCell(value: valorRecebido ?? 0.0),
        'historico': PlutoCell(value: historico ?? ''),
        'finStatusParcela': PlutoCell(value: finStatusParcelaModel?.descricao ?? ''),
        'finTipoRecebimento': PlutoCell(value: finTipoRecebimentoModel?.descricao ?? ''),
      },
    );
  }

  FinParcelaReceberModel clone() {
    return FinParcelaReceberModel(
      id: id,
      idFinLancamentoReceber: idFinLancamentoReceber,
      idFinStatusParcela: idFinStatusParcela,
      idFinTipoRecebimento: idFinTipoRecebimento,
      numeroParcela: numeroParcela,
      dataEmissao: dataEmissao,
      dataVencimento: dataVencimento,
      dataRecebimento: dataRecebimento,
      descontoAte: descontoAte,
      valor: valor,
      taxaJuro: taxaJuro,
      taxaMulta: taxaMulta,
      taxaDesconto: taxaDesconto,
      valorJuro: valorJuro,
      valorMulta: valorMulta,
      valorDesconto: valorDesconto,
      emitiuBoleto: emitiuBoleto,
      boletoNossoNumero: boletoNossoNumero,
      valorRecebido: valorRecebido,
      historico: historico,
      finStatusParcelaModel: finStatusParcelaModel?.clone(),
      finTipoRecebimentoModel: finTipoRecebimentoModel?.clone(),
    );
  }


}