import 'dart:convert';
import 'package:pluto_grid/pluto_grid.dart';
import 'package:loja_virtual/app/data/model/model_imports.dart';

import 'package:loja_virtual/app/data/domain/domain_imports.dart';

class NotaFiscalModeloModel extends ModelBase {
  int? id;
  String? codigo;
  String? descricao;
  String? modelo;

  NotaFiscalModeloModel({
    this.id,
    this.codigo = 'AAA',
    this.descricao,
    this.modelo,
  });

  static List<String> dbColumns = <String>[
    'id',
    'codigo',
    'descricao',
    'modelo',
  ];

  static List<String> aliasColumns = <String>[
    'Id',
    'Codigo',
    'Descricao',
    'Modelo',
  ];

  NotaFiscalModeloModel.fromJson(Map<String, dynamic> jsonData) {
    id = jsonData['id'];
    codigo = NotaFiscalModeloDomain.getCodigo(jsonData['codigo']);
    descricao = jsonData['descricao'];
    modelo = jsonData['modelo'];
  }

  Map<String, dynamic> get toJson {
    Map<String, dynamic> jsonData = <String, dynamic>{};

    jsonData['id'] = id != 0 ? id : null;
    jsonData['codigo'] = NotaFiscalModeloDomain.setCodigo(codigo);
    jsonData['descricao'] = descricao;
    jsonData['modelo'] = modelo;

    return jsonData;
  }

  String objectEncodeJson() {
    final jsonData = toJson;
    return json.encode(jsonData);
  }

  static NotaFiscalModeloModel fromPlutoRow(PlutoRow row) {
    return NotaFiscalModeloModel(
      id: row.cells['id']?.value,
      codigo: row.cells['codigo']?.value,
      descricao: row.cells['descricao']?.value,
      modelo: row.cells['modelo']?.value,
    );
  }

  PlutoRow toPlutoRow() {
    return PlutoRow(
      cells: {
        'tempId': PlutoCell(value: tempId),
        'id': PlutoCell(value: id ?? 0),
        'codigo': PlutoCell(value: codigo ?? ''),
        'descricao': PlutoCell(value: descricao ?? ''),
        'modelo': PlutoCell(value: modelo ?? ''),
      },
    );
  }

  NotaFiscalModeloModel clone() {
    return NotaFiscalModeloModel(
      id: id,
      codigo: codigo,
      descricao: descricao,
      modelo: modelo,
    );
  }


}