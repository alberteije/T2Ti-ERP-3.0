import 'dart:convert';
import 'package:pluto_grid/pluto_grid.dart';
import 'package:loja_virtual/app/data/model/model_imports.dart';

import 'package:loja_virtual/app/infra/infra_imports.dart';
import 'package:intl/intl.dart';
import 'package:loja_virtual/app/data/domain/domain_imports.dart';

class FornecedorModel extends ModelBase {
  int? id;
  int? idPessoa;
  DateTime? desde;
  DateTime? dataCadastro;
  String? observacao;
  String? optanteSimplesNacional;
  String? permiteReterPagamento;
  int? prazoMedioEntrega;
  String? forneceAPrazo;
  int? numDiasPrimeiroVencimento;
  int? numDiasIntervalo;
  int? quantidadeParcelas;

  FornecedorModel({
    this.id,
    this.idPessoa,
    this.desde,
    this.dataCadastro,
    this.observacao,
    this.optanteSimplesNacional = 'Sim',
    this.permiteReterPagamento = 'Sim',
    this.prazoMedioEntrega,
    this.forneceAPrazo = 'Sim',
    this.numDiasPrimeiroVencimento,
    this.numDiasIntervalo,
    this.quantidadeParcelas,
  });

  static List<String> dbColumns = <String>[
    'id',
    'desde',
    'data_cadastro',
    'observacao',
    'optante_simples_nacional',
    'permite_reter_pagamento',
    'prazo_medio_entrega',
    'fornece_a_prazo',
    'num_dias_primeiro_vencimento',
    'num_dias_intervalo',
    'quantidade_parcelas',
  ];

  static List<String> aliasColumns = <String>[
    'Id',
    'Desde',
    'Data Cadastro',
    'Observacao',
    'Optante Simples Nacional',
    'Permite Reter Pagamento',
    'Prazo Medio Entrega',
    'Fornece A Prazo',
    'Num Dias Primeiro Vencimento',
    'Num Dias Intervalo',
    'Quantidade Parcelas',
  ];

  FornecedorModel.fromJson(Map<String, dynamic> jsonData) {
    id = jsonData['id'];
    idPessoa = jsonData['idPessoa'];
    desde = jsonData['desde'] != null ? DateTime.tryParse(jsonData['desde']) : null;
    dataCadastro = jsonData['dataCadastro'] != null ? DateTime.tryParse(jsonData['dataCadastro']) : null;
    observacao = jsonData['observacao'];
    optanteSimplesNacional = FornecedorDomain.getOptanteSimplesNacional(jsonData['optanteSimplesNacional']);
    permiteReterPagamento = FornecedorDomain.getPermiteReterPagamento(jsonData['permiteReterPagamento']);
    prazoMedioEntrega = jsonData['prazoMedioEntrega'];
    forneceAPrazo = FornecedorDomain.getForneceAPrazo(jsonData['forneceAPrazo']);
    numDiasPrimeiroVencimento = jsonData['numDiasPrimeiroVencimento'];
    numDiasIntervalo = jsonData['numDiasIntervalo'];
    quantidadeParcelas = jsonData['quantidadeParcelas'];
  }

  Map<String, dynamic> get toJson {
    Map<String, dynamic> jsonData = <String, dynamic>{};

    jsonData['id'] = id != 0 ? id : null;
    jsonData['idPessoa'] = idPessoa != 0 ? idPessoa : null;
    jsonData['desde'] = desde != null ? DateFormat('yyyy-MM-ddT00:00:00').format(desde!) : null;
    jsonData['dataCadastro'] = dataCadastro != null ? DateFormat('yyyy-MM-ddT00:00:00').format(dataCadastro!) : null;
    jsonData['observacao'] = observacao;
    jsonData['optanteSimplesNacional'] = FornecedorDomain.setOptanteSimplesNacional(optanteSimplesNacional);
    jsonData['permiteReterPagamento'] = FornecedorDomain.setPermiteReterPagamento(permiteReterPagamento);
    jsonData['prazoMedioEntrega'] = prazoMedioEntrega;
    jsonData['forneceAPrazo'] = FornecedorDomain.setForneceAPrazo(forneceAPrazo);
    jsonData['numDiasPrimeiroVencimento'] = numDiasPrimeiroVencimento;
    jsonData['numDiasIntervalo'] = numDiasIntervalo;
    jsonData['quantidadeParcelas'] = quantidadeParcelas;

    return jsonData;
  }

  String objectEncodeJson() {
    final jsonData = toJson;
    return json.encode(jsonData);
  }

  static FornecedorModel fromPlutoRow(PlutoRow row) {
    return FornecedorModel(
      id: row.cells['id']?.value,
      idPessoa: row.cells['idPessoa']?.value,
      desde: Util.stringToDate(row.cells['desde']?.value),
      dataCadastro: Util.stringToDate(row.cells['dataCadastro']?.value),
      observacao: row.cells['observacao']?.value,
      optanteSimplesNacional: row.cells['optanteSimplesNacional']?.value,
      permiteReterPagamento: row.cells['permiteReterPagamento']?.value,
      prazoMedioEntrega: row.cells['prazoMedioEntrega']?.value,
      forneceAPrazo: row.cells['forneceAPrazo']?.value,
      numDiasPrimeiroVencimento: row.cells['numDiasPrimeiroVencimento']?.value,
      numDiasIntervalo: row.cells['numDiasIntervalo']?.value,
      quantidadeParcelas: row.cells['quantidadeParcelas']?.value,
    );
  }

  PlutoRow toPlutoRow() {
    return PlutoRow(
      cells: {
        'tempId': PlutoCell(value: tempId),
        'id': PlutoCell(value: id ?? 0),
        'idPessoa': PlutoCell(value: idPessoa ?? 0),
        'desde': PlutoCell(value: desde),
        'dataCadastro': PlutoCell(value: dataCadastro),
        'observacao': PlutoCell(value: observacao ?? ''),
        'optanteSimplesNacional': PlutoCell(value: optanteSimplesNacional ?? ''),
        'permiteReterPagamento': PlutoCell(value: permiteReterPagamento ?? ''),
        'prazoMedioEntrega': PlutoCell(value: prazoMedioEntrega ?? 0),
        'forneceAPrazo': PlutoCell(value: forneceAPrazo ?? ''),
        'numDiasPrimeiroVencimento': PlutoCell(value: numDiasPrimeiroVencimento ?? 0),
        'numDiasIntervalo': PlutoCell(value: numDiasIntervalo ?? 0),
        'quantidadeParcelas': PlutoCell(value: quantidadeParcelas ?? 0),
      },
    );
  }

  FornecedorModel clone() {
    return FornecedorModel(
      id: id,
      idPessoa: idPessoa,
      desde: desde,
      dataCadastro: dataCadastro,
      observacao: observacao,
      optanteSimplesNacional: optanteSimplesNacional,
      permiteReterPagamento: permiteReterPagamento,
      prazoMedioEntrega: prazoMedioEntrega,
      forneceAPrazo: forneceAPrazo,
      numDiasPrimeiroVencimento: numDiasPrimeiroVencimento,
      numDiasIntervalo: numDiasIntervalo,
      quantidadeParcelas: quantidadeParcelas,
    );
  }


}