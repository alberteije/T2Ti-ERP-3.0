import 'dart:convert';
import 'package:pluto_grid/pluto_grid.dart';
import 'package:loja_virtual/app/data/model/model_imports.dart';

import 'package:loja_virtual/app/infra/infra_imports.dart';
import 'package:intl/intl.dart';
import 'package:loja_virtual/app/data/domain/domain_imports.dart';

class ClienteModel extends ModelBase {
  int? id;
  int? idPessoa;
  int? idTabelaPreco;
  DateTime? desde;
  DateTime? dataCadastro;
  double? taxaDesconto;
  double? limiteCredito;
  String? observacao;
  String? ehGoverno;
  String? tipoEnteGovernamental;
  double? governoPercentualReducao;
  TabelaPrecoModel? tabelaPrecoModel;

  ClienteModel({
    this.id,
    this.idPessoa,
    this.idTabelaPreco,
    this.desde,
    this.dataCadastro,
    this.taxaDesconto,
    this.limiteCredito,
    this.observacao,
    this.ehGoverno = 'Sim',
    this.tipoEnteGovernamental = '1=União',
    this.governoPercentualReducao,
    TabelaPrecoModel? tabelaPrecoModel,
  }) {
    this.tabelaPrecoModel = tabelaPrecoModel ?? TabelaPrecoModel();
  }

  static List<String> dbColumns = <String>[
    'id',
    'desde',
    'data_cadastro',
    'taxa_desconto',
    'limite_credito',
    'observacao',
    'eh_governo',
    'tipo_ente_governamental',
    'governo_percentual_reducao',
  ];

  static List<String> aliasColumns = <String>[
    'Id',
    'Desde',
    'Data Cadastro',
    'Taxa Desconto',
    'Limite Credito',
    'Observacao',
    'Eh Governo',
    'Tipo Ente Governamental',
    'Governo Percentual Reducao',
  ];

  ClienteModel.fromJson(Map<String, dynamic> jsonData) {
    id = jsonData['id'];
    idPessoa = jsonData['idPessoa'];
    idTabelaPreco = jsonData['idTabelaPreco'];
    desde = jsonData['desde'] != null ? DateTime.tryParse(jsonData['desde']) : null;
    dataCadastro = jsonData['dataCadastro'] != null ? DateTime.tryParse(jsonData['dataCadastro']) : null;
    taxaDesconto = jsonData['taxaDesconto']?.toDouble();
    limiteCredito = jsonData['limiteCredito']?.toDouble();
    observacao = jsonData['observacao'];
    ehGoverno = ClienteDomain.getEhGoverno(jsonData['ehGoverno']);
    tipoEnteGovernamental = ClienteDomain.getTipoEnteGovernamental(jsonData['tipoEnteGovernamental']);
    governoPercentualReducao = jsonData['governoPercentualReducao']?.toDouble();
    tabelaPrecoModel = jsonData['tabelaPrecoModel'] == null ? TabelaPrecoModel() : TabelaPrecoModel.fromJson(jsonData['tabelaPrecoModel']);
  }

  Map<String, dynamic> get toJson {
    Map<String, dynamic> jsonData = <String, dynamic>{};

    jsonData['id'] = id != 0 ? id : null;
    jsonData['idPessoa'] = idPessoa != 0 ? idPessoa : null;
    jsonData['idTabelaPreco'] = idTabelaPreco != 0 ? idTabelaPreco : null;
    jsonData['desde'] = desde != null ? DateFormat('yyyy-MM-ddT00:00:00').format(desde!) : null;
    jsonData['dataCadastro'] = dataCadastro != null ? DateFormat('yyyy-MM-ddT00:00:00').format(dataCadastro!) : null;
    jsonData['taxaDesconto'] = taxaDesconto;
    jsonData['limiteCredito'] = limiteCredito;
    jsonData['observacao'] = observacao;
    jsonData['ehGoverno'] = ClienteDomain.setEhGoverno(ehGoverno);
    jsonData['tipoEnteGovernamental'] = ClienteDomain.setTipoEnteGovernamental(tipoEnteGovernamental);
    jsonData['governoPercentualReducao'] = governoPercentualReducao;
    jsonData['tabelaPrecoModel'] = tabelaPrecoModel?.toJson;
    jsonData['tabelaPreco'] = tabelaPrecoModel?.nome ?? '';

    return jsonData;
  }

  String objectEncodeJson() {
    final jsonData = toJson;
    return json.encode(jsonData);
  }

  static ClienteModel fromPlutoRow(PlutoRow row) {
    return ClienteModel(
      id: row.cells['id']?.value,
      idPessoa: row.cells['idPessoa']?.value,
      idTabelaPreco: row.cells['idTabelaPreco']?.value,
      desde: Util.stringToDate(row.cells['desde']?.value),
      dataCadastro: Util.stringToDate(row.cells['dataCadastro']?.value),
      taxaDesconto: row.cells['taxaDesconto']?.value,
      limiteCredito: row.cells['limiteCredito']?.value,
      observacao: row.cells['observacao']?.value,
      ehGoverno: row.cells['ehGoverno']?.value,
      tipoEnteGovernamental: row.cells['tipoEnteGovernamental']?.value,
      governoPercentualReducao: row.cells['governoPercentualReducao']?.value,
    );
  }

  PlutoRow toPlutoRow() {
    return PlutoRow(
      cells: {
        'tempId': PlutoCell(value: tempId),
        'id': PlutoCell(value: id ?? 0),
        'idPessoa': PlutoCell(value: idPessoa ?? 0),
        'idTabelaPreco': PlutoCell(value: idTabelaPreco ?? 0),
        'desde': PlutoCell(value: desde),
        'dataCadastro': PlutoCell(value: dataCadastro),
        'taxaDesconto': PlutoCell(value: taxaDesconto ?? 0.0),
        'limiteCredito': PlutoCell(value: limiteCredito ?? 0.0),
        'observacao': PlutoCell(value: observacao ?? ''),
        'ehGoverno': PlutoCell(value: ehGoverno ?? ''),
        'tipoEnteGovernamental': PlutoCell(value: tipoEnteGovernamental ?? ''),
        'governoPercentualReducao': PlutoCell(value: governoPercentualReducao ?? 0.0),
        'tabelaPreco': PlutoCell(value: tabelaPrecoModel?.nome ?? ''),
      },
    );
  }

  ClienteModel clone() {
    return ClienteModel(
      id: id,
      idPessoa: idPessoa,
      idTabelaPreco: idTabelaPreco,
      desde: desde,
      dataCadastro: dataCadastro,
      taxaDesconto: taxaDesconto,
      limiteCredito: limiteCredito,
      observacao: observacao,
      ehGoverno: ehGoverno,
      tipoEnteGovernamental: tipoEnteGovernamental,
      governoPercentualReducao: governoPercentualReducao,
      tabelaPrecoModel: tabelaPrecoModel?.clone(),
    );
  }


}