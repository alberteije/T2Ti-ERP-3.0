import 'dart:convert';
import 'package:pluto_grid/pluto_grid.dart';
import 'package:loja_virtual/app/data/model/model_imports.dart';

import 'package:loja_virtual/app/data/domain/domain_imports.dart';

class PessoaModel extends ModelBase {
  int? id;
  String? nome;
  String? tipo;
  String? site;
  String? email;
  String? ehCliente;
  String? ehFornecedor;
  String? ehTransportadora;
  String? ehColaborador;
  String? ehContador;
  String? situacaoContribuinte;
  String? ativo;
  PessoaJuridicaModel? pessoaJuridicaModel;
  FornecedorModel? fornecedorModel;
  ClienteModel? clienteModel;
  PessoaFisicaModel? pessoaFisicaModel;
  TransportadoraModel? transportadoraModel;
  List<PessoaContatoModel>? pessoaContatoModelList;
  List<PessoaTelefoneModel>? pessoaTelefoneModelList;
  List<PessoaEnderecoModel>? pessoaEnderecoModelList;

  PessoaModel({
    this.id,
    this.nome,
    this.tipo = 'Física',
    this.site,
    this.email,
    this.ehCliente = 'Sim',
    this.ehFornecedor = 'Sim',
    this.ehTransportadora = 'Sim',
    this.ehColaborador = 'Sim',
    this.ehContador = 'Sim',
    this.situacaoContribuinte = '1-Contribuinte ICMS',
    this.ativo = 'Sim',
    PessoaJuridicaModel? pessoaJuridicaModel,
    FornecedorModel? fornecedorModel,
    ClienteModel? clienteModel,
    PessoaFisicaModel? pessoaFisicaModel,
    TransportadoraModel? transportadoraModel,
    List<PessoaContatoModel>? pessoaContatoModelList,
    List<PessoaTelefoneModel>? pessoaTelefoneModelList,
    List<PessoaEnderecoModel>? pessoaEnderecoModelList,
  }) {
    this.pessoaJuridicaModel = pessoaJuridicaModel ?? PessoaJuridicaModel();
    this.fornecedorModel = fornecedorModel ?? FornecedorModel();
    this.clienteModel = clienteModel ?? ClienteModel();
    this.pessoaFisicaModel = pessoaFisicaModel ?? PessoaFisicaModel();
    this.transportadoraModel = transportadoraModel ?? TransportadoraModel();
    this.pessoaContatoModelList = pessoaContatoModelList?.toList(growable: true) ?? [];
    this.pessoaTelefoneModelList = pessoaTelefoneModelList?.toList(growable: true) ?? [];
    this.pessoaEnderecoModelList = pessoaEnderecoModelList?.toList(growable: true) ?? [];
  }

  static List<String> dbColumns = <String>[
    'id',
    'nome',
    'tipo',
    'site',
    'email',
    'eh_cliente',
    'eh_fornecedor',
    'eh_transportadora',
    'eh_colaborador',
    'eh_contador',
    'situacao_contribuinte',
    'ativo',
  ];

  static List<String> aliasColumns = <String>[
    'Id',
    'Nome',
    'Tipo',
    'Site',
    'Email',
    'Eh Cliente',
    'Eh Fornecedor',
    'Eh Transportadora',
    'Eh Colaborador',
    'Eh Contador',
    'Situacao Contribuinte',
    'Ativo',
  ];

  PessoaModel.fromJson(Map<String, dynamic> jsonData) {
    id = jsonData['id'];
    nome = jsonData['nome'];
    tipo = PessoaDomain.getTipo(jsonData['tipo']);
    site = jsonData['site'];
    email = jsonData['email'];
    ehCliente = PessoaDomain.getEhCliente(jsonData['ehCliente']);
    ehFornecedor = PessoaDomain.getEhFornecedor(jsonData['ehFornecedor']);
    ehTransportadora = PessoaDomain.getEhTransportadora(jsonData['ehTransportadora']);
    ehColaborador = PessoaDomain.getEhColaborador(jsonData['ehColaborador']);
    ehContador = PessoaDomain.getEhContador(jsonData['ehContador']);
    situacaoContribuinte = PessoaDomain.getSituacaoContribuinte(jsonData['situacaoContribuinte']);
    ativo = PessoaDomain.getAtivo(jsonData['ativo']);
    pessoaJuridicaModel = jsonData['pessoaJuridicaModel'] == null ? PessoaJuridicaModel() : PessoaJuridicaModel.fromJson(jsonData['pessoaJuridicaModel']);
    fornecedorModel = jsonData['fornecedorModel'] == null ? FornecedorModel() : FornecedorModel.fromJson(jsonData['fornecedorModel']);
    clienteModel = jsonData['clienteModel'] == null ? ClienteModel(tabelaPrecoModel: TabelaPrecoModel(), ) : ClienteModel.fromJson(jsonData['clienteModel']);
    pessoaFisicaModel = jsonData['pessoaFisicaModel'] == null ? PessoaFisicaModel(estadoCivilModel: EstadoCivilModel(), nivelFormacaoModel: NivelFormacaoModel(), ) : PessoaFisicaModel.fromJson(jsonData['pessoaFisicaModel']);
    transportadoraModel = jsonData['transportadoraModel'] == null ? TransportadoraModel() : TransportadoraModel.fromJson(jsonData['transportadoraModel']);
    pessoaContatoModelList = (jsonData['pessoaContatoModelList'] as Iterable?)?.map((m) => PessoaContatoModel.fromJson(m)).toList() ?? [];
    pessoaTelefoneModelList = (jsonData['pessoaTelefoneModelList'] as Iterable?)?.map((m) => PessoaTelefoneModel.fromJson(m)).toList() ?? [];
    pessoaEnderecoModelList = (jsonData['pessoaEnderecoModelList'] as Iterable?)?.map((m) => PessoaEnderecoModel.fromJson(m)).toList() ?? [];
  }

  Map<String, dynamic> get toJson {
    Map<String, dynamic> jsonData = <String, dynamic>{};

    jsonData['id'] = id != 0 ? id : null;
    jsonData['nome'] = nome;
    jsonData['tipo'] = PessoaDomain.setTipo(tipo);
    jsonData['site'] = site;
    jsonData['email'] = email;
    jsonData['ehCliente'] = PessoaDomain.setEhCliente(ehCliente);
    jsonData['ehFornecedor'] = PessoaDomain.setEhFornecedor(ehFornecedor);
    jsonData['ehTransportadora'] = PessoaDomain.setEhTransportadora(ehTransportadora);
    jsonData['ehColaborador'] = PessoaDomain.setEhColaborador(ehColaborador);
    jsonData['ehContador'] = PessoaDomain.setEhContador(ehContador);
    jsonData['situacaoContribuinte'] = PessoaDomain.setSituacaoContribuinte(situacaoContribuinte);
    jsonData['ativo'] = PessoaDomain.setAtivo(ativo);
    jsonData['pessoaJuridicaModel'] = pessoaJuridicaModel?.toJson;
    jsonData['fornecedorModel'] = fornecedorModel?.toJson;
    jsonData['clienteModel'] = clienteModel?.toJson;
    jsonData['pessoaFisicaModel'] = pessoaFisicaModel?.toJson;
    jsonData['transportadoraModel'] = transportadoraModel?.toJson;
    
		var pessoaContatoModelLocalList = []; 
		for (PessoaContatoModel object in pessoaContatoModelList ?? []) { 
			pessoaContatoModelLocalList.add(object.toJson); 
		}
		jsonData['pessoaContatoModelList'] = pessoaContatoModelLocalList;
    
		var pessoaTelefoneModelLocalList = []; 
		for (PessoaTelefoneModel object in pessoaTelefoneModelList ?? []) { 
			pessoaTelefoneModelLocalList.add(object.toJson); 
		}
		jsonData['pessoaTelefoneModelList'] = pessoaTelefoneModelLocalList;
    
		var pessoaEnderecoModelLocalList = []; 
		for (PessoaEnderecoModel object in pessoaEnderecoModelList ?? []) { 
			pessoaEnderecoModelLocalList.add(object.toJson); 
		}
		jsonData['pessoaEnderecoModelList'] = pessoaEnderecoModelLocalList;

    return jsonData;
  }

  String objectEncodeJson() {
    final jsonData = toJson;
    return json.encode(jsonData);
  }

  static PessoaModel fromPlutoRow(PlutoRow row) {
    return PessoaModel(
      id: row.cells['id']?.value,
      nome: row.cells['nome']?.value,
      tipo: row.cells['tipo']?.value,
      site: row.cells['site']?.value,
      email: row.cells['email']?.value,
      ehCliente: row.cells['ehCliente']?.value,
      ehFornecedor: row.cells['ehFornecedor']?.value,
      ehTransportadora: row.cells['ehTransportadora']?.value,
      ehColaborador: row.cells['ehColaborador']?.value,
      ehContador: row.cells['ehContador']?.value,
      situacaoContribuinte: row.cells['situacaoContribuinte']?.value,
      ativo: row.cells['ativo']?.value,
    );
  }

  PlutoRow toPlutoRow() {
    return PlutoRow(
      cells: {
        'tempId': PlutoCell(value: tempId),
        'id': PlutoCell(value: id ?? 0),
        'nome': PlutoCell(value: nome ?? ''),
        'tipo': PlutoCell(value: tipo ?? ''),
        'site': PlutoCell(value: site ?? ''),
        'email': PlutoCell(value: email ?? ''),
        'ehCliente': PlutoCell(value: ehCliente ?? ''),
        'ehFornecedor': PlutoCell(value: ehFornecedor ?? ''),
        'ehTransportadora': PlutoCell(value: ehTransportadora ?? ''),
        'ehColaborador': PlutoCell(value: ehColaborador ?? ''),
        'ehContador': PlutoCell(value: ehContador ?? ''),
        'situacaoContribuinte': PlutoCell(value: situacaoContribuinte ?? ''),
        'ativo': PlutoCell(value: ativo ?? ''),
      },
    );
  }

  PessoaModel clone() {
    return PessoaModel(
      id: id,
      nome: nome,
      tipo: tipo,
      site: site,
      email: email,
      ehCliente: ehCliente,
      ehFornecedor: ehFornecedor,
      ehTransportadora: ehTransportadora,
      ehColaborador: ehColaborador,
      ehContador: ehContador,
      situacaoContribuinte: situacaoContribuinte,
      ativo: ativo,
      pessoaJuridicaModel: pessoaJuridicaModel?.clone(),
      fornecedorModel: fornecedorModel?.clone(),
      clienteModel: clienteModel?.clone(),
      pessoaFisicaModel: pessoaFisicaModel?.clone(),
      transportadoraModel: transportadoraModel?.clone(),
      pessoaContatoModelList: pessoaContatoModelListClone(pessoaContatoModelList!),
      pessoaTelefoneModelList: pessoaTelefoneModelListClone(pessoaTelefoneModelList!),
      pessoaEnderecoModelList: pessoaEnderecoModelListClone(pessoaEnderecoModelList!),
    );
  }

  pessoaContatoModelListClone(List<PessoaContatoModel> pessoaContatoModelList) { 
		List<PessoaContatoModel> resultList = [];
		for (var pessoaContatoModel in pessoaContatoModelList) {
			resultList.add(pessoaContatoModel.clone());
		}
		return resultList;
	}

  pessoaTelefoneModelListClone(List<PessoaTelefoneModel> pessoaTelefoneModelList) { 
		List<PessoaTelefoneModel> resultList = [];
		for (var pessoaTelefoneModel in pessoaTelefoneModelList) {
			resultList.add(pessoaTelefoneModel.clone());
		}
		return resultList;
	}

  pessoaEnderecoModelListClone(List<PessoaEnderecoModel> pessoaEnderecoModelList) { 
		List<PessoaEnderecoModel> resultList = [];
		for (var pessoaEnderecoModel in pessoaEnderecoModelList) {
			resultList.add(pessoaEnderecoModel.clone());
		}
		return resultList;
	}


}