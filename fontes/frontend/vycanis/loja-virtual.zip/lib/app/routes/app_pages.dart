import 'package:get/get.dart';
import 'package:loja_virtual/app/page/shared_widget/shared_widget_imports.dart';
import 'package:loja_virtual/app/routes/app_routes.dart';
import 'package:loja_virtual/app/page/login/login_page.dart';
import 'package:loja_virtual/app/page/shared_page/splash_screen_page.dart';
import 'package:loja_virtual/app/bindings/bindings_imports.dart';
import 'package:loja_virtual/app/page/shared_page/shared_page_imports.dart';
import 'package:loja_virtual/app/page/page_imports.dart';

class AppPages {
	
	static final pages = [
		GetPage(name: Routes.splashPage, page:()=> const SplashScreenPage()),
		GetPage(name: Routes.loginPage, page:()=> const LoginPage(), binding: LoginBindings()),
		GetPage(name: Routes.homePage, page:()=> HomePage()),
		GetPage(name: Routes.filterPage, page:()=> const FilterPage()),
		GetPage(name: Routes.lookupPage, page:()=> const LookupPage()),
    GetPage(name: Routes.menuModulesPage, page:()=> const MenuModulesPage()),
		
		GetPage(name: Routes.produtoListPage, page:()=> const ProdutoListPage(), binding: ProdutoBindings()), 
		GetPage(name: Routes.produtoTabPage, page:()=> ProdutoTabPage()),
		GetPage(name: Routes.vendaCabecalhoListPage, page:()=> const VendaCabecalhoListPage(), binding: VendaCabecalhoBindings()), 
		GetPage(name: Routes.vendaCabecalhoTabPage, page:()=> VendaCabecalhoTabPage()),
		GetPage(name: Routes.produtoGrupoListPage, page:()=> const ProdutoGrupoListPage(), binding: ProdutoGrupoBindings()), 
		GetPage(name: Routes.produtoGrupoEditPage, page:()=> ProdutoGrupoEditPage()),
		GetPage(name: Routes.produtoSubgrupoListPage, page:()=> const ProdutoSubgrupoListPage(), binding: ProdutoSubgrupoBindings()), 
		GetPage(name: Routes.produtoSubgrupoEditPage, page:()=> ProdutoSubgrupoEditPage()),
		GetPage(name: Routes.produtoMarcaListPage, page:()=> const ProdutoMarcaListPage(), binding: ProdutoMarcaBindings()), 
		GetPage(name: Routes.produtoMarcaEditPage, page:()=> ProdutoMarcaEditPage()),
		GetPage(name: Routes.produtoUnidadeListPage, page:()=> const ProdutoUnidadeListPage(), binding: ProdutoUnidadeBindings()), 
		GetPage(name: Routes.produtoUnidadeEditPage, page:()=> ProdutoUnidadeEditPage()),

    GetPage(
      name: Routes.cartPage,
      page: () => CartPage(),
    ),

    GetPage(
      name: Routes.checkoutPage,
      page: () => CheckoutPage(),
    ),

    GetPage(
      name: Routes.produtoDetailPage,
      page: () => ProdutoDetailPage(),
    ),    
	];
}