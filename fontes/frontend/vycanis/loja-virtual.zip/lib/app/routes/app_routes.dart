abstract class Routes{
	
	static const splashPage = '/splashPage';
	static const loginPage = '/loginPage';
	static const homePage = '/homePage';
	static const filterPage = '/filterPage';
	static const lookupPage = '/lookupPage';
  static const menuModulesPage = '/menuModulesPage';
		
	static const pessoaListPage = '/pessoaListPage'; 
	static const pessoaTabPage = '/pessoaTabPage';
	static const produtoListPage = '/produtoListPage'; 
	static const produtoTabPage = '/produtoTabPage';
	static const vendaCondicoesPagamentoListPage = '/vendaCondicoesPagamentoListPage'; 
	static const vendaCondicoesPagamentoTabPage = '/vendaCondicoesPagamentoTabPage';
	static const vendaCabecalhoListPage = '/vendaCabecalhoListPage'; 
	static const vendaCabecalhoTabPage = '/vendaCabecalhoTabPage';
	static const finLancamentoReceberListPage = '/finLancamentoReceberListPage'; 
	static const finLancamentoReceberTabPage = '/finLancamentoReceberTabPage';
	static const estadoCivilListPage = '/estadoCivilListPage'; 
	static const estadoCivilEditPage = '/estadoCivilEditPage';
	static const paisListPage = '/paisListPage'; 
	static const paisEditPage = '/paisEditPage';
	static const nivelFormacaoListPage = '/nivelFormacaoListPage'; 
	static const nivelFormacaoEditPage = '/nivelFormacaoEditPage';
	static const tabelaPrecoListPage = '/tabelaPrecoListPage'; 
	static const tabelaPrecoEditPage = '/tabelaPrecoEditPage';
	static const produtoGrupoListPage = '/produtoGrupoListPage'; 
	static const produtoGrupoEditPage = '/produtoGrupoEditPage';
	static const produtoSubgrupoListPage = '/produtoSubgrupoListPage'; 
	static const produtoSubgrupoEditPage = '/produtoSubgrupoEditPage';
	static const produtoMarcaListPage = '/produtoMarcaListPage'; 
	static const produtoMarcaEditPage = '/produtoMarcaEditPage';
	static const produtoUnidadeListPage = '/produtoUnidadeListPage'; 
	static const produtoUnidadeEditPage = '/produtoUnidadeEditPage';
	static const notaFiscalTipoListPage = '/notaFiscalTipoListPage'; 
	static const notaFiscalTipoEditPage = '/notaFiscalTipoEditPage';
	static const bancoContaCaixaListPage = '/bancoContaCaixaListPage'; 
	static const bancoContaCaixaEditPage = '/bancoContaCaixaEditPage';
	static const finDocumentoOrigemListPage = '/finDocumentoOrigemListPage'; 
	static const finDocumentoOrigemEditPage = '/finDocumentoOrigemEditPage';
	static const finNaturezaFinanceiraListPage = '/finNaturezaFinanceiraListPage'; 
	static const finNaturezaFinanceiraEditPage = '/finNaturezaFinanceiraEditPage';
	static const finStatusParcelaListPage = '/finStatusParcelaListPage'; 
	static const finStatusParcelaEditPage = '/finStatusParcelaEditPage';
	static const finTipoRecebimentoListPage = '/finTipoRecebimentoListPage'; 
	static const finTipoRecebimentoEditPage = '/finTipoRecebimentoEditPage';

  static const cartPage = '/cart';
  static const checkoutPage = '/checkout';
  static const profilePage = '/profile';
  static const orderHistoryPage = '/orders';
  static const addressListPage = '/addresses';
  static const aboutPage = '/about';
  static const produtoDetailPage = '/produto/detail';
}