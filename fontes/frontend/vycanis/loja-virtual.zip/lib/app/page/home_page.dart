import 'dart:io';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:loja_virtual/app/controller/store_controller.dart';
import 'package:loja_virtual/app/controller/cart_controller.dart';
import 'package:loja_virtual/app/controller/theme_controller.dart';
import 'package:loja_virtual/app/page/shared_widget/main_side_drawer.dart';
import 'package:loja_virtual/app/infra/infra_imports.dart';
import 'package:loja_virtual/app/routes/app_routes.dart';

class HomePage extends StatelessWidget {
  HomePage({Key? key}) : super(key: key);
  final themeController = Get.find<ThemeController>();
  final storeController = Get.find<StoreController>();
  final cartController = Get.find<CartController>();
  final isBannerExpanded = true.obs;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Row(children: [Text(Constants.appName, style: TextStyle(fontWeight: FontWeight.bold))]),
        actions: [
          // Carrinho com badge
          Stack(
            children: [
              IconButton(
                padding: const EdgeInsets.only(top: 16),
                onPressed: () {
                  Get.toNamed(Routes.cartPage);
                },
                icon: const Icon(Icons.shopping_cart),
                tooltip: 'Carrinho',
              ),
              Obx(() {
                final totalItems = cartController.totalItems;
                return totalItems > 0
                    ? Positioned(
                      right: 8,
                      top: 8,
                      child: Container(
                        padding: const EdgeInsets.all(2),
                        decoration: BoxDecoration(color: Colors.red, borderRadius: BorderRadius.circular(10)),
                        constraints: const BoxConstraints(minWidth: 16, minHeight: 16),
                        child: Text('$totalItems', style: const TextStyle(color: Colors.white, fontSize: 10), textAlign: TextAlign.center),
                      ),
                    )
                    : const SizedBox.shrink();
              }),
            ],
          ),

          Obx(
            () => IconButton(
              onPressed: () {
                final isCurrentlyDark = themeController.isDarkMode.value;
                themeController.changeThemeMode(isCurrentlyDark ? ThemeMode.light : ThemeMode.dark);
              },
              icon: themeController.isDarkMode.value ? const Icon(Icons.dark_mode_outlined) : const Icon(Icons.light_mode_outlined),
              tooltip: 'Alternar tema',
            ),
          ),

          // Perfil/Login
          IconButton(
            onPressed: () {
              final isLoggedIn = Session.loggedInUser.id != null;

              if (!isLoggedIn) {
                Get.toNamed(Routes.loginPage);
              } else {
                Scaffold.of(context).openDrawer();
              }
            },
            icon:
                Session.loggedInUser.id != null
                    ? CircleAvatar(
                      radius: 16,
                      backgroundColor: Colors.blue.shade100,
                      child: Text(Session.loggedInUser.pessoaNome?.substring(0, 1) ?? 'U', style: TextStyle(color: Colors.blue.shade900, fontWeight: FontWeight.bold)),
                    )
                    : const Icon(Icons.person_outline),
            tooltip: Session.loggedInUser.id != null ? 'Minha conta' : 'Login',
          ),
        ],
      ),
      drawer: MainSideDrawer(),
      body: Obx(() {
        if (storeController.isLoading.value) {
          return Center(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [const CircularProgressIndicator(), const SizedBox(height: 16), Text('Carregando produtos...', style: TextStyle(color: Colors.grey.shade600))],
            ),
          );
        }

        return Column(
          children: [
            // Banner promocional
            Obx(
              () => Column(
                children: [
                  // Banner - VERSÃO CORRIGIDA
                  Container(
                    height: isBannerExpanded.value ? 150 : 60,
                    width: double.infinity,
                    decoration: BoxDecoration(
                      gradient: LinearGradient(begin: Alignment.centerLeft, end: Alignment.centerRight, colors: [Colors.blue.shade800, Colors.purple.shade600]),
                      borderRadius: BorderRadius.circular(isBannerExpanded.value ? 0 : 8),
                    ),
                    child: Stack(
                      clipBehavior: Clip.none, // IMPORTANTE: Permite overflow controlado
                      children: [
                        // Conteúdo PRINCIPAL (sempre centralizado)
                        Center(
                          child: Padding(
                            padding: EdgeInsets.symmetric(
                              horizontal: 16,
                              vertical: isBannerExpanded.value ? 0 : 20, // Ajuste vertical
                            ),
                            child:
                                isBannerExpanded.value
                                    ? _buildExpandedContent() // Método separado
                                    : _buildCollapsedContent(), // Método separado
                          ),
                        ),

                        // Botão de controle (fora do fluxo normal)
                        Positioned(
                          top: 4,
                          right: 4,
                          child: IconButton(
                            onPressed: () {
                              isBannerExpanded.value = !isBannerExpanded.value;
                            },
                            icon: Obx(() => Icon(isBannerExpanded.value ? Icons.keyboard_arrow_up : Icons.keyboard_arrow_down, color: Colors.white, size: 24)),
                            splashRadius: 16,
                            padding: EdgeInsets.zero,
                            constraints: const BoxConstraints(),
                          ),
                        ),
                      ],
                    ),
                  ),

                  // Restante do seu código...
                ],
              ),
            ),
            // Barra de busca
            Padding(
              padding: const EdgeInsets.all(12.0),
              child: TextField(
                decoration: InputDecoration(
                  hintText: 'Buscar produtos...',
                  prefixIcon: const Icon(Icons.search),
                  border: OutlineInputBorder(borderRadius: BorderRadius.circular(25)),
                  filled: true,
                  fillColor: themeController.isDarkMode.value ? Colors.grey.shade800 : Colors.grey.shade100,
                  contentPadding: const EdgeInsets.symmetric(vertical: 0, horizontal: 16),
                ),
                onChanged: (value) {
                  storeController.searchProducts(value);
                },
              ),
            ),

            // Categorias
            SizedBox(
              height: 60,
              child: Obx(
                () => ListView.builder(
                  scrollDirection: Axis.horizontal,
                  itemCount: storeController.categories.length,
                  padding: const EdgeInsets.symmetric(horizontal: 8),
                  itemBuilder: (context, index) {
                    final category = storeController.categories[index];
                    final isSelected = storeController.selectedCategoryId.value == category.id;

                    return Padding(
                      padding: const EdgeInsets.all(4.0),
                      child: ChoiceChip(
                        label: Text(category.name),
                        selected: isSelected,
                        onSelected: (selected) {
                          storeController.filterByCategory(selected ? category.id : null);
                        },
                        backgroundColor: themeController.isDarkMode.value ? Colors.grey.shade800 : Colors.grey.shade200,
                        selectedColor: Colors.blue.shade200,
                        labelStyle: TextStyle(
                          color:
                              isSelected
                                  ? Colors.blue.shade900
                                  : themeController.isDarkMode.value
                                  ? Colors.white
                                  : Colors.black87,
                          fontWeight: isSelected ? FontWeight.bold : FontWeight.normal,
                        ),
                      ),
                    );
                  },
                ),
              ),
            ),

            // Contador de produtos
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16.0, vertical: 8.0),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Obx(() => Text('${storeController.filteredProducts.length} produto(s) encontrado(s)', style: TextStyle(color: Colors.grey.shade600, fontSize: 14))),
                  Obx(() {
                    final hasFilter = storeController.selectedCategoryId.value != null;
                    return hasFilter
                        ? TextButton(
                          onPressed: () {
                            storeController.clearFilters();
                          },
                          child: const Row(children: [Icon(Icons.clear, size: 16), SizedBox(width: 4), Text('Limpar filtros')]),
                        )
                        : const SizedBox.shrink();
                  }),
                ],
              ),
            ),

            // Grid de produtos
            Expanded(
              child: Obx(() {
                if (storeController.filteredProducts.isEmpty) {
                  return Center(
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Icon(Icons.search_off, size: 64, color: Colors.grey.shade400),
                        const SizedBox(height: 16),
                        Text('Nenhum produto encontrado', style: TextStyle(fontSize: 18, color: Colors.grey.shade600)),
                        const SizedBox(height: 8),
                        Text('Tente ajustar os filtros ou a busca', style: TextStyle(fontSize: 14, color: Colors.grey.shade500)),
                      ],
                    ),
                  );
                }

                return GridView.builder(
                  padding: const EdgeInsets.all(8.0),
                  gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 6, crossAxisSpacing: 12.0, mainAxisSpacing: 12.0, childAspectRatio: 0.7),
                  itemCount: storeController.filteredProducts.length,
                  itemBuilder: (context, index) {
                    final storeProduct = storeController.filteredProducts[index];
                    final produto = storeProduct.produto;
                    final isInCart = cartController.items.any((item) => item.productId == produto.id);

                    return _buildProductCard(storeProduct, isInCart);
                  },
                );
              }),
            ),
          ],
        );
      }),
    );
  }

  Widget _buildProductCard(StoreProduct storeProduct, bool isInCart) {
    final produto = storeProduct.produto;
    final isDarkMode = themeController.isDarkMode;

    return Card(
      elevation: 4,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      child: InkWell(
        borderRadius: BorderRadius.circular(12),
        onTap: () {
          Get.toNamed(
            Routes.produtoDetailPage,
            arguments: {
              'storeProduct': storeProduct,
            },
          );        
        },
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            // Imagem do produto
            Expanded(
              flex: 3,
              child: Container(
                decoration: BoxDecoration(borderRadius: const BorderRadius.vertical(top: Radius.circular(12)), color: isDarkMode.value ? Colors.grey.shade800 : Colors.grey.shade100),
                child: _buildProductImage(storeProduct),
              ),
            ),

            // Informações do produto
            Expanded(
              flex: 2,
              child: Padding(
                padding: const EdgeInsets.all(12.0),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    // Nome do produto
                    Text(produto.nome ?? 'Produto', style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 14, height: 1.2), maxLines: 2, overflow: TextOverflow.ellipsis),

                    // Preço
                    Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text('R\$${produto.valorVenda?.toStringAsFixed(2) ?? '0,00'}', style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold, color: Colors.green.shade700)),

                        // Mostra desconto se houver
                        if (produto.precoVendaMinimo != null && produto.valorVenda != null && produto.valorVenda! < produto.precoVendaMinimo!)
                          Text('De R\$${produto.precoVendaMinimo?.toStringAsFixed(2)}', style: TextStyle(fontSize: 12, color: Colors.grey.shade600, decoration: TextDecoration.lineThrough)),
                      ],
                    ),

                    // Estoque e botão
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        // Estoque
                        Row(
                          children: [
                            Icon(Icons.inventory, size: 14, color: Colors.grey.shade500),
                            const SizedBox(width: 4),
                            Text('${produto.quantidadeEstoque?.toStringAsFixed(0) ?? '0'}', style: TextStyle(fontSize: 12, color: Colors.grey.shade600)),
                          ],
                        ),

                        // Botão de ação
                        _buildActionButton(produto, isInCart, storeProduct),
                      ],
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildProductImage(StoreProduct storeProduct) {
    if (storeProduct.localImagePath != null) {
      return ClipRRect(
        borderRadius: const BorderRadius.vertical(top: Radius.circular(12)),
        child: Image.file(
          File(storeProduct.localImagePath!),
          fit: BoxFit.cover,
          frameBuilder: (context, child, frame, wasSynchronouslyLoaded) {
            if (wasSynchronouslyLoaded) {
              return child;
            }
            return AnimatedOpacity(opacity: frame == null ? 0 : 1, duration: const Duration(milliseconds: 300), curve: Curves.easeOut, child: child);
          },
          errorBuilder: (context, error, stackTrace) {
            return _buildDefaultImageIcon();
          },
        ),
      );
    }

    return _buildDefaultImageIcon();
  }

  Widget _buildDefaultImageIcon() {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [Icon(Icons.shopping_bag, size: 48, color: Colors.grey.shade400), const SizedBox(height: 8), Text('Sem imagem', style: TextStyle(fontSize: 12, color: Colors.grey.shade500))],
      ),
    );
  }

  Widget _buildActionButton(dynamic produto, bool isInCart, StoreProduct storeProduct) {
    // if (isInCart) {
    //   return OutlinedButton.icon(
    //     onPressed: () {
    //       Get.toNamed(Routes.cartPage);
    //     },
    //     icon: const Icon(Icons.check, size: 14),
    //     label: const Text('Carrinho'),
    //     style: OutlinedButton.styleFrom(padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6), foregroundColor: Colors.green.shade700, side: BorderSide(color: Colors.green.shade300)),
    //   );
    // } else {
      final isOutOfStock = (produto.quantidadeEstoque ?? 0) <= 0;

      return ElevatedButton.icon(
        onPressed:
            isOutOfStock
                ? null
                : () {
                  cartController.addItem(
                    productId: produto.id!, 
                    productName: produto.nome ?? 'Produto', 
                    unitPrice: produto.valorVenda ?? 0, 
                    quantity: 1,
                    imagePath: storeProduct.localImagePath,
                  );
                },
        icon: Icon(isOutOfStock ? Icons.block : Icons.add_shopping_cart, size: 14),
        label: Text(isOutOfStock ? 'Esgotado' : 'Comprar'),
        style: ElevatedButton.styleFrom(
          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
          backgroundColor: isOutOfStock ? Colors.grey.shade400 : Colors.blue.shade600,
          foregroundColor: Colors.white,
        ),
      );
    // }
  }

  Widget _buildExpandedContent() {
    return Column(
      mainAxisSize: MainAxisSize.min, // CRÍTICO: Ocupa só o necessário
      mainAxisAlignment: MainAxisAlignment.center,
      crossAxisAlignment: CrossAxisAlignment.center,
      children: [
        const Text(
          'Ofertas Especiais',
          style: TextStyle(
            color: Colors.white,
            fontSize: 20, // Reduzido ainda mais
            fontWeight: FontWeight.bold,
          ),
          textAlign: TextAlign.center,
        ),
        const SizedBox(height: 4),
        Text('Até 50% OFF', style: TextStyle(color: Colors.white.withValues(alpha: 0.9), fontSize: 14), textAlign: TextAlign.center),
        const SizedBox(height: 8),
        ElevatedButton.icon(
          onPressed: () {
            storeController.filterByCategory(2);
          },
          icon: const Icon(Icons.arrow_forward, size: 12),
          label: const Text('Ver Ofertas', style: TextStyle(fontSize: 12)),
          style: ElevatedButton.styleFrom(
            backgroundColor: Colors.amber,
            foregroundColor: Colors.black,
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
            minimumSize: const Size(0, 28), // Altura mínima fixa
          ),
        ),
      ],
    );
  }

  Widget _buildCollapsedContent() {
    return const Row(
      mainAxisSize: MainAxisSize.min,
      children: [Icon(Icons.local_offer, color: Colors.amber, size: 18), SizedBox(width: 8), Text('Ofertas', style: TextStyle(color: Colors.white, fontSize: 16, fontWeight: FontWeight.bold))],
    );
  }
}
