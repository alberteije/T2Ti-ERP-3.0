import 'dart:math';

import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:loja_virtual/app/controller/theme_controller.dart';
import 'package:loja_virtual/app/infra/infra_imports.dart';
import 'package:loja_virtual/app/routes/app_routes.dart';

class MainSideDrawer extends StatelessWidget {
  MainSideDrawer({Key? key}) : super(key: key);
  final themeController = Get.find<ThemeController>();

  @override
  Widget build(BuildContext context) {
    return Drawer(
      child: ListView(
        padding: EdgeInsets.zero,
        children: <Widget>[
          // Cabeçalho do usuário
          UserAccountsDrawerHeader(
            accountName: Text(
              Session.loggedInUser.id == null 
                  ? 'Visitante' 
                  : Session.loggedInUser.pessoaNome ?? 'Cliente',
              style: const TextStyle(fontWeight: FontWeight.bold),
            ),
            accountEmail: Text(
              Session.loggedInUser.id == null 
                  ? 'Faça login para comprar' 
                  : Session.loggedInUser.email ?? 'cliente@email.com',
            ),
            currentAccountPicture: GestureDetector(
              onTap: () {
                if (Session.loggedInUser.id == null) {
                  Get.toNamed(Routes.loginPage);
                }
              },
              child: CircleAvatar(
                backgroundColor: Colors.blue.shade100,
                child: Session.loggedInUser.id == null
                    ? Icon(Icons.person, color: Colors.blue.shade800)
                    : Text(
                        Session.loggedInUser.pessoaNome?.substring(0, 1) ?? 'C',
                        style: TextStyle(
                          fontSize: 20,
                          fontWeight: FontWeight.bold,
                          color: Colors.blue.shade900,
                        ),
                      ),
              ),
            ),
            decoration: BoxDecoration(
              gradient: LinearGradient(
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
                colors: [
                  Colors.blue.shade800,
                  Colors.purple.shade600,
                ],
              ),
            ),
          ),

          // Seção: Minha Conta
          if (Session.loggedInUser.id != null) ...[
            Padding(
              padding: const EdgeInsets.fromLTRB(16, 16, 0, 8),
              child: Text(
                'MINHA CONTA',
                style: TextStyle(
                  fontWeight: FontWeight.bold,
                  fontSize: 12,
                  color: Colors.grey.shade600,
                  letterSpacing: 1,
                ),
              ),
            ),
            
            ListTile(
              onTap: () {
                Get.toNamed(Routes.profilePage); // Você precisará criar esta rota
              },
              leading: const Icon(Icons.person, color: Colors.blue),
              title: const Text('Meu Perfil'),
            ),
            
            ListTile(
              onTap: () {
                Get.toNamed(Routes.orderHistoryPage); // Criar esta rota
              },
              leading: const Icon(Icons.history, color: Colors.orange),
              title: const Text('Meus Pedidos'),
            ),
            
            ListTile(
              onTap: () {
                Get.toNamed(Routes.addressListPage); // Criar esta rota
              },
              leading: const Icon(Icons.location_on, color: Colors.green),
              title: const Text('Meus Endereços'),
            ),
            
            const Divider(),
          ],

          // Seção: Categorias
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 16, 0, 8),
            child: Text(
              'CATEGORIAS',
              style: TextStyle(
                fontWeight: FontWeight.bold,
                fontSize: 12,
                color: Colors.grey.shade600,
                letterSpacing: 1,
              ),
            ),
          ),
          
          ListTile(
            onTap: () {
              Get.back();
              // Implementar filtro para todos os produtos
            },
            leading: const Icon(Icons.all_inclusive, color: Colors.purple),
            title: const Text('Todos os Produtos'),
          ),
          
          ListTile(
            onTap: () {
              Get.back();
              // Implementar filtro para ofertas
            },
            leading: const Icon(Icons.local_offer, color: Colors.red),
            title: const Text('Ofertas'),
            trailing: Chip(
              label: const Text('-50%'),
              backgroundColor: Colors.red.shade100,
              labelStyle: TextStyle(color: Colors.red.shade900, fontSize: 10),
            ),
          ),
          
          ListTile(
            onTap: () {
              Get.back();
              // Implementar filtro para mais vendidos
            },
            leading: const Icon(Icons.trending_up, color: Colors.green),
            title: const Text('Mais Vendidos'),
          ),
          
          const Divider(),

          // Seção: Navegação
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 16, 0, 8),
            child: Text(
              'NAVEGAÇÃO',
              style: TextStyle(
                fontWeight: FontWeight.bold,
                fontSize: 12,
                color: Colors.grey.shade600,
                letterSpacing: 1,
              ),
            ),
          ),
          
          ListTile(
            onTap: () {
              Get.toNamed(Routes.cartPage); // Criar esta rota
            },
            leading: Icon(Icons.shopping_cart, color: Colors.blue.shade600),
            title: const Text('Carrinho'),
          ),
          
          ListTile(
            onTap: () {
              Get.toNamed(Routes.checkoutPage); // Criar esta rota
            },
            leading: Icon(Icons.payment, color: Colors.green.shade600),
            title: const Text('Finalizar Compra'),
          ),
          
          ListTile(
            onTap: () {
              Get.toNamed(Routes.aboutPage); // Criar esta rota
            },
            leading: Icon(Icons.info, color: Colors.amber.shade700),
            title: const Text('Sobre a Loja'),
          ),

          
          // Modo administrador (se aplicável)
          if (Session.loggedInUser.administrador == 'S') ...[
            const Divider(),
            Padding(
              padding: const EdgeInsets.fromLTRB(16, 16, 0, 8),
              child: Text(
                'ADMINISTRAÇÃO',
                style: TextStyle(
                  fontWeight: FontWeight.bold,
                  fontSize: 12,
                  color: Colors.red.shade600,
                  letterSpacing: 1,
                ),
              ),
            ),

					ListTile(
						enabled: Session.loggedInUser.administrador == 'S'
							? true
								: Session.accessControlList.where( ((t) => t.funcaoNome == 'produto_grupo') ).toList().isNotEmpty
									? Session.accessControlList.where( ((t) => t.funcaoNome == 'produto_grupo') ).toList()[0].habilitado == 'S'
									: false,
						onTap: () {
							Get.toNamed(Routes.produtoGrupoListPage);
						},
						title: const Text(
							'Grupo Produto',
						),
						leading: Icon(
							iconDataList[Random().nextInt(10)],
							color: iconColorList[Random().nextInt(10)],
						),
					),

					ListTile(
						enabled: Session.loggedInUser.administrador == 'S'
							? true
								: Session.accessControlList.where( ((t) => t.funcaoNome == 'produto_subgrupo') ).toList().isNotEmpty
									? Session.accessControlList.where( ((t) => t.funcaoNome == 'produto_subgrupo') ).toList()[0].habilitado == 'S'
									: false,
						onTap: () {
							Get.toNamed(Routes.produtoSubgrupoListPage);
						},
						title: const Text(
							'Subgrupo Produto',
						),
						leading: Icon(
							iconDataList[Random().nextInt(10)],
							color: iconColorList[Random().nextInt(10)],
						),
					),

					ListTile(
						enabled: Session.loggedInUser.administrador == 'S'
							? true
								: Session.accessControlList.where( ((t) => t.funcaoNome == 'produto_marca') ).toList().isNotEmpty
									? Session.accessControlList.where( ((t) => t.funcaoNome == 'produto_marca') ).toList()[0].habilitado == 'S'
									: false,
						onTap: () {
							Get.toNamed(Routes.produtoMarcaListPage);
						},
						title: const Text(
							'Marca Produto',
						),
						leading: Icon(
							iconDataList[Random().nextInt(10)],
							color: iconColorList[Random().nextInt(10)],
						),
					),

					ListTile(
						enabled: Session.loggedInUser.administrador == 'S'
							? true
								: Session.accessControlList.where( ((t) => t.funcaoNome == 'produto_unidade') ).toList().isNotEmpty
									? Session.accessControlList.where( ((t) => t.funcaoNome == 'produto_unidade') ).toList()[0].habilitado == 'S'
									: false,
						onTap: () {
							Get.toNamed(Routes.produtoUnidadeListPage);
						},
						title: const Text(
							'Unidade Produto',
						),
						leading: Icon(
							iconDataList[Random().nextInt(10)],
							color: iconColorList[Random().nextInt(10)],
						),
					),

            ListTile(
              onTap: () {
                Get.toNamed(Routes.produtoListPage);
              },
              leading: const Icon(Icons.inventory, color: Colors.red),
              title: const Text('Produtos'),
            ),

            ListTile(
              onTap: () {
                Get.toNamed(Routes.vendaCabecalhoListPage);
              },
              leading: const Icon(Icons.receipt, color: Colors.red),
              title: const Text('Pedidos'),
            ),
          ],

          const Divider(),

          // Ações
          if (Session.loggedInUser.id != null)
            ListTile(
              onTap: () {
                Get.offAllNamed(Routes.loginPage);
              },
              leading: const Icon(Icons.exit_to_app, color: Colors.red),
              title: const Text('Sair'),
            ),
          
          if (Session.loggedInUser.id == null)
            ListTile(
              onTap: () {
                Get.toNamed(Routes.loginPage);
              },
              leading: const Icon(Icons.login, color: Colors.blue),
              title: const Text('Fazer Login'),
            ),

          const Divider(),

          // Rodapé
          const SizedBox(height: 10),
          Padding(
            padding: const EdgeInsets.all(16.0),
            child: Column(
              children: [
                Text(
                  Constants.appName,
                  style: TextStyle(
                    fontSize: 12,
                    color: Colors.grey.shade600,
                  ),
                ),
                const SizedBox(height: 4),
                Text(
                  'v1.0.0',
                  style: TextStyle(
                    fontSize: 10,
                    color: Colors.grey.shade500,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}