import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_bootstrap/flutter_bootstrap.dart';
import 'package:get/get.dart';
import 'package:loja_virtual/app/page/shared_widget/shared_widget_imports.dart';
import 'package:loja_virtual/app/data/domain/domain_imports.dart';
import 'package:loja_virtual/app/controller/produto_unidade_controller.dart';
import 'package:loja_virtual/app/infra/infra_imports.dart';
import 'package:loja_virtual/app/page/shared_widget/input/input_imports.dart';

class ProdutoUnidadeEditPage extends StatelessWidget {
	ProdutoUnidadeEditPage({Key? key}) : super(key: key);
	final produtoUnidadeController = Get.find<ProdutoUnidadeController>();

	@override
	Widget build(BuildContext context) {
		return KeyboardListener(
			autofocus: false,
			focusNode: FocusNode(),
			onKeyEvent: (event) {
				if (event.logicalKey == LogicalKeyboardKey.escape) {
					produtoUnidadeController.preventDataLoss();
				}
			},
			child: Scaffold(
				key: produtoUnidadeController.scaffoldKey,
				appBar: AppBar(
					automaticallyImplyLeading: false,
					title: Text('${ produtoUnidadeController.screenTitle } - ${ produtoUnidadeController.isNewRecord ? 'inserting'.tr : 'editing'.tr }',),
					actions: [
						saveButton(onPressed: produtoUnidadeController.save),
						cancelAndExitButton(onPressed: produtoUnidadeController.preventDataLoss),
					]
				),
				body: SafeArea(
					top: false,
					bottom: false,
					child: Form(
						key: produtoUnidadeController.formKey,
						autovalidateMode: AutovalidateMode.always,
						child: Scrollbar(
							controller: produtoUnidadeController.scrollController,
							child: SingleChildScrollView(
								controller: produtoUnidadeController.scrollController,
								child: BootstrapContainer(
									fluid: true,
									padding: const EdgeInsets.fromLTRB(10.0, 10.0, 10.0, 10.0),
									children: <Widget>[
										const Divider(
											color: Colors.transparent,
										),
										BootstrapRow(
											height: 60,
											children: <BootstrapCol>[
												BootstrapCol(
													sizes: 'col-12 col-md-6',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: TextFormField(
															autofocus: true,
															validator: ValidateFormField.validateMandatory,
															maxLength: 10,
															controller: produtoUnidadeController.siglaController,
															decoration: inputDecoration(
																hintText: 'Informe os dados para o campo Sigla',
																labelText: 'Sigla *',
																usePadding: true,
															),
															onSaved: (String? value) {},
															onChanged: (text) {
																produtoUnidadeController.currentModel.sigla = text;
																produtoUnidadeController.formWasChanged = true;
															},
														),
													),
												),
												BootstrapCol(
													sizes: 'col-12 col-md-6',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: CustomDropdownButton(
															controller: produtoUnidadeController.podeFracionarController,
															labelText: 'Pode Fracionar *',
															hintText: 'Informe os dados para o campo Pode Fracionar',
															items: ProdutoUnidadeDomain.podeFracionarListDropdown,
															onChanged: (dynamic newValue) {
																produtoUnidadeController.currentModel.podeFracionar = newValue;
																produtoUnidadeController.formWasChanged = true;
															},
														),
													),
												),
											],
										),
										const Divider(
											color: Colors.transparent,
										),
										BootstrapRow(
											height: 60,
											children: <BootstrapCol>[
												BootstrapCol(
													sizes: 'col-12',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: TextFormField(
															autofocus: true,
															maxLength: 250,
															maxLines: 3,
															controller: produtoUnidadeController.descricaoController,
															decoration: inputDecoration(
																hintText: 'Informe os dados para o campo Descrição',
																labelText: 'Descrição',
																usePadding: true,
															),
															onSaved: (String? value) {},
															onChanged: (text) {
																produtoUnidadeController.currentModel.descricao = text;
																produtoUnidadeController.formWasChanged = true;
															},
														),
													),
												),
											],
										),
										const Divider(
											indent: 10,
											endIndent: 10,
											thickness: 2,
										),
										BootstrapRow(
											height: 60,
											children: <BootstrapCol>[
												BootstrapCol(
													sizes: 'col-12',
													child: Text(
														'field_is_mandatory'.tr,
														style: Theme.of(context).textTheme.bodySmall,
													),
												),
											],
										),
										const SizedBox(height: 10.0),
									],
								),
							),
						),
					),
				),
			),
		);
	}
}
