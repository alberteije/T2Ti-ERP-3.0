import 'package:flutter/material.dart';
import 'package:flutter_bootstrap/flutter_bootstrap.dart';
import 'package:get/get.dart';
import 'package:loja_virtual/app/page/shared_widget/shared_widget_imports.dart';
import 'package:loja_virtual/app/controller/produto_promocao_controller.dart';
import 'package:loja_virtual/app/infra/infra_imports.dart';
import 'package:loja_virtual/app/page/shared_widget/input/input_imports.dart';

class ProdutoPromocaoEditPage extends StatelessWidget {
	ProdutoPromocaoEditPage({Key? key}) : super(key: key);
	final produtoPromocaoController = Get.find<ProdutoPromocaoController>();

	@override
	Widget build(BuildContext context) {
			return Scaffold(
				key: produtoPromocaoController.produtoPromocaoScaffoldKey,	
				appBar: AppBar(
					automaticallyImplyLeading: false,
					title: Text('${ produtoPromocaoController.screenTitle } - ${ produtoPromocaoController.isNewRecord ? 'inserting'.tr : 'editing'.tr }',),
					actions: [
						saveButton(onPressed: produtoPromocaoController.save),
						cancelAndExitButton(onPressed: produtoPromocaoController.preventDataLoss),
					]
				),
				body: SafeArea(
					top: false,
					bottom: false,
					child: Form(
						key: produtoPromocaoController.produtoPromocaoFormKey,
						autovalidateMode: AutovalidateMode.always,
						child: Scrollbar(
							controller: produtoPromocaoController.scrollController,
							child: SingleChildScrollView(
								controller: produtoPromocaoController.scrollController,
								child: BootstrapContainer(
									fluid: true,
									padding: const EdgeInsets.all(10.0),
									children: <Widget>[
										const Divider(
											color: Colors.transparent,
										),
										BootstrapRow(
											height: 60,
											children: <BootstrapCol>[
												BootstrapCol(
													sizes: 'col-12 col-md-6',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: InputDecorator(
															decoration: inputDecoration(
																hintText: 'Informe os dados para o campo Data Início',
																labelText: 'Data Início',
																usePadding: true,
															),
															isEmpty: false,
															child: DatePickerItem(
																controller: produtoPromocaoController.dataInicioController,
																firstDate: DateTime.parse('1000-01-01'),
																lastDate: DateTime.parse('5000-01-01'),
																onChanged: (DateTime? value) {
																	produtoPromocaoController.produtoPromocaoModel.dataInicio = value;
																	produtoPromocaoController.formWasChangedDetail = true;
																},
															),
														),
													),
												),
												BootstrapCol(
													sizes: 'col-12 col-md-6',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: InputDecorator(
															decoration: inputDecoration(
																hintText: 'Informe os dados para o campo Data Fim',
																labelText: 'Data Fim',
																usePadding: true,
															),
															isEmpty: false,
															child: DatePickerItem(
																controller: produtoPromocaoController.dataFimController,
																firstDate: DateTime.parse('1000-01-01'),
																lastDate: DateTime.parse('5000-01-01'),
																onChanged: (DateTime? value) {
																	produtoPromocaoController.produtoPromocaoModel.dataFim = value;
																	produtoPromocaoController.formWasChangedDetail = true;
																},
															),
														),
													),
												),
											],
										),
										const Divider(
											color: Colors.transparent,
										),
										BootstrapRow(
											height: 60,
											children: <BootstrapCol>[
												BootstrapCol(
													sizes: 'col-12 col-md-4',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: TextFormField(
															autofocus: true,
															controller: produtoPromocaoController.quantidadeEmPromocaoController,
															decoration: inputDecoration(
																hintText: 'Informe os dados para o campo Quantidade Em Promoção',
																labelText: 'Quantidade Em Promoção',
																usePadding: true,
															),
															onSaved: (String? value) {},
															onChanged: (text) {
																produtoPromocaoController.produtoPromocaoModel.quantidadeEmPromocao = produtoPromocaoController.quantidadeEmPromocaoController.numberValue;
																produtoPromocaoController.formWasChangedDetail = true;
															},
														),
													),
												),
												BootstrapCol(
													sizes: 'col-12 col-md-4',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: TextFormField(
															autofocus: true,
															controller: produtoPromocaoController.quantidadeMaximaClienteController,
															decoration: inputDecoration(
																hintText: 'Informe os dados para o campo Quantidade Máxima Cliente',
																labelText: 'Quantidade Máxima Cliente',
																usePadding: true,
															),
															onSaved: (String? value) {},
															onChanged: (text) {
																produtoPromocaoController.produtoPromocaoModel.quantidadeMaximaCliente = produtoPromocaoController.quantidadeMaximaClienteController.numberValue;
																produtoPromocaoController.formWasChangedDetail = true;
															},
														),
													),
												),
												BootstrapCol(
													sizes: 'col-12 col-md-4',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: TextFormField(
															autofocus: true,
															controller: produtoPromocaoController.valorController,
															decoration: inputDecoration(
																hintText: 'Informe os dados para o campo Valor',
																labelText: 'Valor',
																usePadding: true,
															),
															onSaved: (String? value) {},
															onChanged: (text) {
																produtoPromocaoController.produtoPromocaoModel.valor = produtoPromocaoController.valorController.numberValue;
																produtoPromocaoController.formWasChangedDetail = true;
															},
														),
													),
												),
											],
										),
										const Divider(
											indent: 10,
											endIndent: 10,
											thickness: 2,
										),
										BootstrapRow(
											height: 60,
											children: <BootstrapCol>[
												BootstrapCol(
													sizes: 'col-12',
													child: Text(
														'field_is_mandatory'.tr,
														style: Theme.of(context).textTheme.bodySmall,
													),
												),
											],
										),
										const SizedBox(height: 10.0),
									],
								),
							),
						),
					),
				),
			);
	}
}
