import 'dart:io';

import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:loja_virtual/app/controller/controller_imports.dart';
import 'package:loja_virtual/app/data/repository/local_image_repository.dart';

class CartPage extends StatelessWidget {
  CartPage({Key? key}) : super(key: key);
  final cartController = Get.find<CartController>();
  final themeController = Get.find<ThemeController>();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Meu Carrinho'),
        centerTitle: true,
        actions: [
          Obx(() => cartController.items.isNotEmpty
              ? IconButton(
                  icon: const Icon(Icons.delete_outline),
                  onPressed: cartController.clearCart,
                  tooltip: 'Limpar carrinho',
                )
              : const SizedBox()),
        ],
      ),
      body: Obx(() {
        if (cartController.items.isEmpty) {
          return _buildEmptyCart();
        }
        
        return Column(
          children: [
            // Lista de itens
            Expanded(
              child: ListView.builder(
                padding: const EdgeInsets.all(16),
                itemCount: cartController.items.length,
                itemBuilder: (context, index) {
                  final item = cartController.items[index];
                  return _buildCartItem(item);
                },
              ),
            ),
            
            // Resumo do pedido
            _buildOrderSummary(),
          ],
        );
      }),
    );
  }

  Widget _buildEmptyCart() {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(
            Icons.shopping_cart_outlined,
            size: 80,
            color: Colors.grey.shade400,
          ),
          const SizedBox(height: 20),
          Text(
            'Seu carrinho está vazio',
            style: TextStyle(
              fontSize: 18,
              color: Colors.grey.shade600,
              fontWeight: FontWeight.bold,
            ),
          ),
          const SizedBox(height: 10),
          Text(
            'Adicione produtos para continuar',
            style: TextStyle(color: Colors.grey.shade500),
          ),
          const SizedBox(height: 30),
          ElevatedButton.icon(
            onPressed: () {
              Get.back();
            },
            icon: const Icon(Icons.shopping_bag),
            label: const Text('Ver produtos'),
            style: ElevatedButton.styleFrom(
              padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 12),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildCartItem(CartItem item) {
    return Card(
      margin: const EdgeInsets.only(bottom: 12),
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Imagem do produto
            Container(
              width: 70,
              height: 70,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(8),
                color: Colors.grey.shade100,
              ),
              child: item.imagePath != null
                  ? ClipRRect(
                      borderRadius: BorderRadius.circular(8),
                      child: Image.file(
                        File(item.imagePath!),
                        fit: BoxFit.cover,
                        errorBuilder: (context, error, stackTrace) {
                          return Icon(
                            Icons.shopping_bag,
                            color: Colors.grey.shade400,
                          );
                        },
                      ),
                    )
                  : _buildProductImageFromId(item.productId),
            ),
            
            const SizedBox(width: 12),
            
            // Informações do produto
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    item.productName,
                    style: const TextStyle(
                      fontWeight: FontWeight.bold,
                      fontSize: 16,
                    ),
                    maxLines: 2,
                    overflow: TextOverflow.ellipsis,
                  ),
                  const SizedBox(height: 4),
                  Text(
                    'R\$${item.unitPrice.toStringAsFixed(2)}',
                    style: TextStyle(
                      color: Colors.green.shade700,
                      fontWeight: FontWeight.bold,
                      fontSize: 16,
                    ),
                  ),
                  const SizedBox(height: 8),
                  
                  // Controles de quantidade
                  Row(
                    children: [
                      // Botão diminuir
                      IconButton(
                        onPressed: () {
                          cartController.updateQuantity(
                            item.productId,
                            item.quantity - 1,
                          );
                        },
                        icon: Icon(
                          Icons.remove_circle_outline,
                          color: Colors.grey.shade600,
                        ),
                        padding: EdgeInsets.zero,
                        constraints: const BoxConstraints(),
                      ),
                      
                      // Quantidade
                      Container(
                        padding: const EdgeInsets.symmetric(
                          horizontal: 12,
                          vertical: 4,
                        ),
                        decoration: BoxDecoration(
                          border: Border.all(color: Colors.grey.shade300),
                          borderRadius: BorderRadius.circular(4),
                        ),
                        child: Text(
                          '${item.quantity}',
                          style: const TextStyle(fontWeight: FontWeight.bold),
                        ),
                      ),
                      
                      // Botão aumentar
                      IconButton(
                        onPressed: () {
                          cartController.updateQuantity(
                            item.productId,
                            item.quantity + 1,
                          );
                        },
                        icon: Icon(
                          Icons.add_circle_outline,
                          color: Colors.green.shade600,
                        ),
                        padding: EdgeInsets.zero,
                        constraints: const BoxConstraints(),
                      ),
                      
                      const Spacer(),
                      
                      // Total do item
                      Text(
                        'R\$${item.total.toStringAsFixed(2)}',
                        style: const TextStyle(
                          fontWeight: FontWeight.bold,
                          fontSize: 16,
                        ),
                      ),
                      
                      const SizedBox(width: 8),
                      
                      // Botão remover
                      IconButton(
                        onPressed: () {
                          cartController.removeItem(item.productId);
                        },
                        icon: const Icon(
                          Icons.delete_outline,
                          color: Colors.red,
                        ),
                        tooltip: 'Remover',
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildProductImageFromId(int productId) {
    final imageRepo = Get.find<LocalImageRepository>();

    return FutureBuilder<String?>(
      future: imageRepo.getProductImagePath(productId),
      builder: (context, snapshot) {
        if (snapshot.connectionState == ConnectionState.waiting) {
          return const Center(child: CircularProgressIndicator(strokeWidth: 2));
        }
        
        if (snapshot.hasData && snapshot.data != null) {
          return ClipRRect(
            borderRadius: BorderRadius.circular(8),
            child: Image.file(
              File(snapshot.data!),
              fit: BoxFit.cover,
              errorBuilder: (context, error, stackTrace) {
                return _buildDefaultIcon();
              },
            ),
          );
        }
        
        return _buildDefaultIcon();
      },
    );
  }

  Widget _buildDefaultIcon() {
    return Center(
      child: Icon(
        Icons.shopping_bag,
        color: Colors.grey.shade400,
      ),
    );
  }

  Widget _buildOrderSummary() {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: themeController.isDarkMode.value
            ? Colors.grey.shade900
            : Colors.grey.shade50,
        border: Border(
          top: BorderSide(color: Colors.grey.shade300),
        ),
      ),
      child: Column(
        children: [
          // Resumo
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                'Subtotal',
                style: TextStyle(color: Colors.grey.shade600),
              ),
              Obx(() => Text(
                'R\$${cartController.subtotal.toStringAsFixed(2)}',
                style: const TextStyle(fontWeight: FontWeight.bold),
              )),
            ],
          ),
          const SizedBox(height: 8),
          
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                'Entrega',
                style: TextStyle(color: Colors.grey.shade600),
              ),
              Obx(() => Text(
                'R\$${cartController.deliveryFee.value.toStringAsFixed(2)}',
                style: const TextStyle(fontWeight: FontWeight.bold),
              )),
            ],
          ),
          const SizedBox(height: 8),
          
          Obx(() {
            if (cartController.discount.value > 0) {
              return Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text(
                    'Desconto',
                    style: TextStyle(
                      color: Colors.green.shade600,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  Text(
                    '-R\$${cartController.discount.value.toStringAsFixed(2)}',
                    style: TextStyle(
                      color: Colors.green.shade600,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ],
              );
            }
            return const SizedBox();
          }),
          
          const Divider(height: 24),
          
          // Total
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              const Text(
                'Total',
                style: TextStyle(
                  fontSize: 18,
                  fontWeight: FontWeight.bold,
                ),
              ),
              Obx(() => Text(
                'R\$${cartController.total.toStringAsFixed(2)}',
                style: TextStyle(
                  fontSize: 20,
                  fontWeight: FontWeight.bold,
                  color: Colors.green.shade700,
                ),
              )),
            ],
          ),
          
          const SizedBox(height: 16),
          
          // Botões de ação
          Row(
            children: [
              // Continuar comprando
              Expanded(
                child: OutlinedButton.icon(
                  onPressed: () {
                    Get.back();
                  },
                  icon: const Icon(Icons.arrow_back),
                  label: const Text('Continuar comprando'),
                  style: OutlinedButton.styleFrom(
                    padding: const EdgeInsets.symmetric(vertical: 16),
                  ),
                ),
              ),
              
              const SizedBox(width: 12),
              
              // Finalizar compra
              Expanded(
                child: ElevatedButton.icon(
                  onPressed: () {
                    cartController.proceedToCheckout();
                  },
                  icon: const Icon(Icons.payment),
                  label: const Text('Finalizar compra'),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.green.shade600,
                    padding: const EdgeInsets.symmetric(vertical: 16),
                  ),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

}