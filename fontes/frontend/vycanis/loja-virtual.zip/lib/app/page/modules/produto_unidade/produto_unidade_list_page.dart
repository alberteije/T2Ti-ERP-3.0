import 'package:flutter/material.dart';
import 'package:loja_virtual/app/controller/produto_unidade_controller.dart';
import 'package:loja_virtual/app/page/shared_page/list_page_base.dart';

class ProdutoUnidadeListPage extends ListPageBase<ProdutoUnidadeController> {
  const ProdutoUnidadeListPage({Key? key}) : super(key: key);

  @override
  List<Map<String, dynamic>> get mobileItems => controller.mobileItems;

  @override
  Map<String, dynamic> get mobileConfig => controller.mobileConfig;

  @override
  String get standardFieldForFilter => controller.standardFieldForFilter;
}