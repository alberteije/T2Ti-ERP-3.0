import 'package:flutter/material.dart';
import 'package:loja_virtual/app/controller/produto_controller.dart';
import 'package:loja_virtual/app/page/shared_page/list_page_base.dart';

class ProdutoListPage extends ListPageBase<ProdutoController> {
  const ProdutoListPage({Key? key}) : super(key: key);

  @override
  List<Map<String, dynamic>> get mobileItems => controller.mobileItems;

  @override
  Map<String, dynamic> get mobileConfig => controller.mobileConfig;

  @override
  String get standardFieldForFilter => controller.standardFieldForFilter;
}