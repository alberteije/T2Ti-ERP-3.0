import 'package:flutter/material.dart';
import 'package:flutter_bootstrap/flutter_bootstrap.dart';
import 'package:get/get.dart';
import 'package:loja_virtual/app/page/shared_widget/shared_widget_imports.dart';
import 'package:loja_virtual/app/data/domain/domain_imports.dart';
import 'package:loja_virtual/app/controller/produto_controller.dart';
import 'package:loja_virtual/app/infra/infra_imports.dart';
import 'package:loja_virtual/app/page/shared_widget/input/input_imports.dart';

class ProdutoEditPage extends StatelessWidget {
	ProdutoEditPage({Key? key}) : super(key: key);
	final produtoController = Get.find<ProdutoController>();

	@override
	Widget build(BuildContext context) {
			return Scaffold(
				key: produtoController.produtoScaffoldKey,
				body: SafeArea(
					top: false,
					bottom: false,
					child: Form(
						key: produtoController.produtoFormKey,
						autovalidateMode: AutovalidateMode.always,
						child: Scrollbar(
							controller: produtoController.scrollController,
							child: SingleChildScrollView(
								controller: produtoController.scrollController,
								child: BootstrapContainer(
									fluid: true,
									padding: const EdgeInsets.all(10),
									children: <Widget>[
										const Divider(
											color: Colors.transparent,
										),
										BootstrapRow(
											height: 60,
											children: <BootstrapCol>[
												BootstrapCol(
													sizes: 'col-12 col-md-4',
													child: Row(
														children: <Widget>[
															Expanded(
																flex: 1,
																child: SizedBox(
																	child: TextFormField(
																		controller: produtoController.produtoSubgrupoModelController,
																		validator: ValidateFormField.validateMandatory,
																		readOnly: true,
																		decoration: inputDecoration(
																			hintText: 'Informe os dados para o campo Subgrupo',
																			labelText: 'Subgrupo *',
																			usePadding: true,
																		),
																		onSaved: (String? value) {},
																		onChanged: (text) {},
																	),
																),
															),
															Expanded(
																flex: 0,
																child: lookupButton(onPressed: produtoController.callProdutoSubgrupoLookup),
															),
														],
													),
												),
												BootstrapCol(
													sizes: 'col-12 col-md-4',
													child: Row(
														children: <Widget>[
															Expanded(
																flex: 1,
																child: SizedBox(
																	child: TextFormField(
																		controller: produtoController.produtoMarcaModelController,
																		validator: ValidateFormField.validateMandatory,
																		readOnly: true,
																		decoration: inputDecoration(
																			hintText: 'Informe os dados para o campo Marca',
																			labelText: 'Marca *',
																			usePadding: true,
																		),
																		onSaved: (String? value) {},
																		onChanged: (text) {},
																	),
																),
															),
															Expanded(
																flex: 0,
																child: lookupButton(onPressed: produtoController.callProdutoMarcaLookup),
															),
														],
													),
												),
												BootstrapCol(
													sizes: 'col-12 col-md-4',
													child: Row(
														children: <Widget>[
															Expanded(
																flex: 1,
																child: SizedBox(
																	child: TextFormField(
																		controller: produtoController.produtoUnidadeModelController,
																		validator: ValidateFormField.validateMandatory,
																		readOnly: true,
																		decoration: inputDecoration(
																			hintText: 'Informe os dados para o campo Unidade',
																			labelText: 'Unidade *',
																			usePadding: true,
																		),
																		onSaved: (String? value) {},
																		onChanged: (text) {},
																	),
																),
															),
															Expanded(
																flex: 0,
																child: lookupButton(onPressed: produtoController.callProdutoUnidadeLookup),
															),
														],
													),
												),
											],
										),
										const Divider(
											color: Colors.transparent,
										),
										BootstrapRow(
											height: 60,
											children: <BootstrapCol>[
												BootstrapCol(
													sizes: 'col-12 col-md-2',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: CustomDropdownButton(
															controller: produtoController.tipoItemController,
															labelText: 'Tipo Item',
															hintText: 'Informe os dados para o campo Tipo Item',
															items: ProdutoDomain.tipoItemListDropdown,
															onChanged: (dynamic newValue) {
																produtoController.currentModel.tipoItem = newValue;
																produtoController.formWasChanged = true;
															},
														),
													),
												),
												BootstrapCol(
													sizes: 'col-12 col-md-10',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: TextFormField(
															autofocus: true,
															validator: ValidateFormField.validateMandatory,
															maxLength: 100,
															controller: produtoController.nomeController,
															decoration: inputDecoration(
																hintText: 'Informe os dados para o campo Nome',
																labelText: 'Nome *',
																usePadding: true,
															),
															onSaved: (String? value) {},
															onChanged: (text) {
																produtoController.currentModel.nome = text;
																produtoController.formWasChanged = true;
															},
														),
													),
												),
											],
										),
										const Divider(
											color: Colors.transparent,
										),
										BootstrapRow(
											height: 60,
											children: <BootstrapCol>[
												BootstrapCol(
													sizes: 'col-12',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: TextFormField(
															autofocus: true,
															maxLength: 250,
															maxLines: 3,
															controller: produtoController.descricaoController,
															decoration: inputDecoration(
																hintText: 'Informe os dados para o campo Descrição',
																labelText: 'Descrição',
																usePadding: true,
															),
															onSaved: (String? value) {},
															onChanged: (text) {
																produtoController.currentModel.descricao = text;
																produtoController.formWasChanged = true;
															},
														),
													),
												),
											],
										),
										const Divider(
											color: Colors.transparent,
										),
										BootstrapRow(
											height: 60,
											children: <BootstrapCol>[
												BootstrapCol(
													sizes: 'col-12 col-md-3',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: TextFormField(
															autofocus: true,
															maxLength: 14,
															controller: produtoController.gtinController,
															decoration: inputDecoration(
																hintText: 'Informe os dados para o campo GTIN',
																labelText: 'GTIN',
																usePadding: true,
															),
															onSaved: (String? value) {},
															onChanged: (text) {
																produtoController.currentModel.gtin = text;
																produtoController.formWasChanged = true;
															},
														),
													),
												),
												BootstrapCol(
													sizes: 'col-12 col-md-3',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: TextFormField(
															autofocus: true,
															maxLength: 50,
															controller: produtoController.codigoInternoController,
															decoration: inputDecoration(
																hintText: 'Informe os dados para o campo Código Interno',
																labelText: 'Código Interno',
																usePadding: true,
															),
															onSaved: (String? value) {},
															onChanged: (text) {
																produtoController.currentModel.codigoInterno = text;
																produtoController.formWasChanged = true;
															},
														),
													),
												),
												BootstrapCol(
													sizes: 'col-12 col-md-3',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: TextFormField(
															autofocus: true,
															controller: produtoController.valorCompraController,
															decoration: inputDecoration(
																hintText: 'Informe os dados para o campo Valor Compra',
																labelText: 'Valor Compra',
																usePadding: true,
															),
															onSaved: (String? value) {},
															onChanged: (text) {
																produtoController.currentModel.valorCompra = produtoController.valorCompraController.numberValue;
																produtoController.formWasChanged = true;
															},
														),
													),
												),
												BootstrapCol(
													sizes: 'col-12 col-md-3',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: TextFormField(
															autofocus: true,
															controller: produtoController.valorVendaController,
															decoration: inputDecoration(
																hintText: 'Informe os dados para o campo Valor Venda',
																labelText: 'Valor Venda',
																usePadding: true,
															),
															onSaved: (String? value) {},
															onChanged: (text) {
																produtoController.currentModel.valorVenda = produtoController.valorVendaController.numberValue;
																produtoController.formWasChanged = true;
															},
														),
													),
												),
											],
										),
										const Divider(
											color: Colors.transparent,
										),
										BootstrapRow(
											height: 60,
											children: <BootstrapCol>[
												BootstrapCol(
													sizes: 'col-12 col-md-3',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: TextFormField(
															autofocus: true,
															maxLength: 8,
															controller: produtoController.codigoNcmController,
															decoration: inputDecoration(
																hintText: 'Informe os dados para o campo Código NCM',
																labelText: 'NCM',
																usePadding: true,
															),
															onSaved: (String? value) {},
															onChanged: (text) {
																produtoController.currentModel.codigoNcm = text;
																produtoController.formWasChanged = true;
															},
														),
													),
												),
												BootstrapCol(
													sizes: 'col-12 col-md-3',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: TextFormField(
															autofocus: true,
															maxLength: 8,
															controller: produtoController.codigoNbsController,
															decoration: inputDecoration(
																hintText: 'Informe os dados para o campo Código NBS',
																labelText: 'NBS',
																usePadding: true,
															),
															onSaved: (String? value) {},
															onChanged: (text) {
																produtoController.currentModel.codigoNbs = text;
																produtoController.formWasChanged = true;
															},
														),
													),
												),
												BootstrapCol(
													sizes: 'col-12 col-md-3',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: TextFormField(
															autofocus: true,
															maxLength: 7,
															controller: produtoController.codigoCestController,
															decoration: inputDecoration(
																hintText: 'Informe os dados para o campo Código CEST',
																labelText: 'Código CEST',
																usePadding: true,
															),
															onSaved: (String? value) {},
															onChanged: (text) {
																produtoController.currentModel.codigoCest = text;
																produtoController.formWasChanged = true;
															},
														),
													),
												),
												BootstrapCol(
													sizes: 'col-12 col-md-3',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: InputDecorator(
															decoration: inputDecoration(
																hintText: 'Informe os dados para o campo Data Cadastro',
																labelText: 'Data Cadastro',
																usePadding: true,
															),
															isEmpty: false,
															child: DatePickerItem(
																controller: produtoController.dataCadastroController,
																firstDate: DateTime.parse('1000-01-01'),
																lastDate: DateTime.parse('5000-01-01'),
																onChanged: (DateTime? value) {
																	produtoController.currentModel.dataCadastro = value;
																	produtoController.formWasChanged = true;
																},
															),
														),
													),
												),
											],
										),
										const Divider(
											color: Colors.transparent,
										),
										BootstrapRow(
											height: 60,
											children: <BootstrapCol>[
												BootstrapCol(
													sizes: 'col-12 col-md-3',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: TextFormField(
															autofocus: true,
															controller: produtoController.quantidadeEstoqueController,
															decoration: inputDecoration(
																hintText: 'Informe os dados para o campo Quantidade Estoque',
																labelText: 'Quantidade Estoque',
																usePadding: true,
															),
															onSaved: (String? value) {},
															onChanged: (text) {
																produtoController.currentModel.quantidadeEstoque = produtoController.quantidadeEstoqueController.numberValue;
																produtoController.formWasChanged = true;
															},
														),
													),
												),
												BootstrapCol(
													sizes: 'col-12 col-md-3',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: TextFormField(
															autofocus: true,
															controller: produtoController.estoqueMinimoController,
															decoration: inputDecoration(
																hintText: 'Informe os dados para o campo Estoque Mínimo',
																labelText: 'Estoque Mínimo',
																usePadding: true,
															),
															onSaved: (String? value) {},
															onChanged: (text) {
																produtoController.currentModel.estoqueMinimo = produtoController.estoqueMinimoController.numberValue;
																produtoController.formWasChanged = true;
															},
														),
													),
												),
												BootstrapCol(
													sizes: 'col-12 col-md-3',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: TextFormField(
															autofocus: true,
															controller: produtoController.estoqueMaximoController,
															decoration: inputDecoration(
																hintText: 'Informe os dados para o campo Estoque Máximo',
																labelText: 'Estoque Máximo',
																usePadding: true,
															),
															onSaved: (String? value) {},
															onChanged: (text) {
																produtoController.currentModel.estoqueMaximo = produtoController.estoqueMaximoController.numberValue;
																produtoController.formWasChanged = true;
															},
														),
													),
												),
												BootstrapCol(
													sizes: 'col-12 col-md-3',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: TextFormField(
															keyboardType: TextInputType.number,
															autofocus: true,
															controller: produtoController.estoqueIdealController,
															decoration: inputDecoration(
																hintText: 'Informe os dados para o campo Estoque Ideal',
																labelText: 'Estoque Ideal',
																usePadding: true,
															),
															onSaved: (String? value) {},
															onChanged: (text) {
																produtoController.currentModel.estoqueIdeal = produtoController.estoqueIdealController.numberValue;
																produtoController.formWasChanged = true;
															},
														),
													),
												),
											],
										),
										const Divider(
											color: Colors.transparent,
										),
										BootstrapRow(
											height: 60,
											children: <BootstrapCol>[
												BootstrapCol(
													sizes: 'col-12 col-md-6',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: CustomDropdownButton(
															controller: produtoController.pesavelController,
															labelText: 'Pesável',
															hintText: 'Informe os dados para o campo Pesável',
															items: ProdutoDomain.pesavelListDropdown,
															onChanged: (dynamic newValue) {
																produtoController.currentModel.pesavel = newValue;
																produtoController.formWasChanged = true;
															},
														),
													),
												),
												BootstrapCol(
													sizes: 'col-12 col-md-6',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: TextFormField(
															keyboardType: TextInputType.number,
															autofocus: true,
															controller: produtoController.pesoController,
															decoration: inputDecoration(
																hintText: 'Informe os dados para o campo Peso',
																labelText: 'Peso',
																usePadding: true,
															),
															onSaved: (String? value) {},
															onChanged: (text) {
																produtoController.currentModel.peso = produtoController.pesoController.numberValue;
																produtoController.formWasChanged = true;
															},
														),
													),
												),
											],
										),
										const Divider(
											color: Colors.transparent,
										),
										BootstrapRow(
											height: 60,
											children: <BootstrapCol>[
												BootstrapCol(
													sizes: 'col-12 col-md-4',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: TextFormField(
															keyboardType: TextInputType.number,
															autofocus: true,
															controller: produtoController.markupController,
															decoration: inputDecoration(
																hintText: 'Informe os dados para o campo Markup',
																labelText: 'Markup',
																usePadding: true,
															),
															onSaved: (String? value) {},
															onChanged: (text) {
																produtoController.currentModel.markup = produtoController.markupController.numberValue;
																produtoController.formWasChanged = true;
															},
														),
													),
												),
												BootstrapCol(
													sizes: 'col-12 col-md-4',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: TextFormField(
															keyboardType: TextInputType.number,
															autofocus: true,
															controller: produtoController.precoSugeridoController,
															decoration: inputDecoration(
																hintText: 'Informe os dados para o campo Preco Sugerido',
																labelText: 'Preço Sugerido',
																usePadding: true,
															),
															onSaved: (String? value) {},
															onChanged: (text) {
																produtoController.currentModel.precoSugerido = produtoController.precoSugeridoController.numberValue;
																produtoController.formWasChanged = true;
															},
														),
													),
												),
												BootstrapCol(
													sizes: 'col-12 col-md-4',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: TextFormField(
															keyboardType: TextInputType.number,
															autofocus: true,
															controller: produtoController.precoVendaMinimoController,
															decoration: inputDecoration(
																hintText: 'Informe os dados para o campo Preco Venda Minimo',
																labelText: 'Preço Venda Mínimo',
																usePadding: true,
															),
															onSaved: (String? value) {},
															onChanged: (text) {
																produtoController.currentModel.precoVendaMinimo = produtoController.precoVendaMinimoController.numberValue;
																produtoController.formWasChanged = true;
															},
														),
													),
												),
											],
										),
										const Divider(
											color: Colors.transparent,
										),
										BootstrapRow(
											height: 60,
											children: <BootstrapCol>[
												BootstrapCol(
													sizes: 'col-12 col-md-3',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: TextFormField(
															keyboardType: TextInputType.number,
															autofocus: true,
															controller: produtoController.custoPercentualController,
															decoration: inputDecoration(
																hintText: 'Informe os dados para o campo Custo Percentual',
																labelText: 'Custo Percentual',
																usePadding: true,
															),
															onSaved: (String? value) {},
															onChanged: (text) {
																produtoController.currentModel.custoPercentual = produtoController.custoPercentualController.numberValue;
																produtoController.formWasChanged = true;
															},
														),
													),
												),
												BootstrapCol(
													sizes: 'col-12 col-md-3',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: TextFormField(
															keyboardType: TextInputType.number,
															autofocus: true,
															controller: produtoController.custoUnitarioController,
															decoration: inputDecoration(
																hintText: 'Informe os dados para o campo Custo Unitario',
																labelText: 'Custo Unitário',
																usePadding: true,
															),
															onSaved: (String? value) {},
															onChanged: (text) {
																produtoController.currentModel.custoUnitario = produtoController.custoUnitarioController.numberValue;
																produtoController.formWasChanged = true;
															},
														),
													),
												),
												BootstrapCol(
													sizes: 'col-12 col-md-3',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: TextFormField(
															keyboardType: TextInputType.number,
															autofocus: true,
															controller: produtoController.custoProducaoController,
															decoration: inputDecoration(
																hintText: 'Informe os dados para o campo Custo Producao',
																labelText: 'Custo Produção',
																usePadding: true,
															),
															onSaved: (String? value) {},
															onChanged: (text) {
																produtoController.currentModel.custoProducao = produtoController.custoProducaoController.numberValue;
																produtoController.formWasChanged = true;
															},
														),
													),
												),
												BootstrapCol(
													sizes: 'col-12 col-md-3',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: TextFormField(
															keyboardType: TextInputType.number,
															autofocus: true,
															controller: produtoController.custoMedioLiquidoController,
															decoration: inputDecoration(
																hintText: 'Informe os dados para o campo Custo Medio Liquido',
																labelText: 'Custo Médio Líquido',
																usePadding: true,
															),
															onSaved: (String? value) {},
															onChanged: (text) {
																produtoController.currentModel.custoMedioLiquido = produtoController.custoMedioLiquidoController.numberValue;
																produtoController.formWasChanged = true;
															},
														),
													),
												),
											],
										),
										const Divider(
											color: Colors.transparent,
										),
										BootstrapRow(
											height: 60,
											children: <BootstrapCol>[
												BootstrapCol(
													sizes: 'col-12 col-md-3',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: TextFormField(
															keyboardType: TextInputType.number,
															autofocus: true,
															controller: produtoController.precoLucroZeroController,
															decoration: inputDecoration(
																hintText: 'Informe os dados para o campo Preco Lucro Zero',
																labelText: 'Preço Lucro Zero',
																usePadding: true,
															),
															onSaved: (String? value) {},
															onChanged: (text) {
																produtoController.currentModel.precoLucroZero = produtoController.precoLucroZeroController.numberValue;
																produtoController.formWasChanged = true;
															},
														),
													),
												),
												BootstrapCol(
													sizes: 'col-12 col-md-3',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: TextFormField(
															keyboardType: TextInputType.number,
															autofocus: true,
															controller: produtoController.precoLucroMinimoController,
															decoration: inputDecoration(
																hintText: 'Informe os dados para o campo Preco Lucro Minimo',
																labelText: 'Preço Lucro Mínimo',
																usePadding: true,
															),
															onSaved: (String? value) {},
															onChanged: (text) {
																produtoController.currentModel.precoLucroMinimo = produtoController.precoLucroMinimoController.numberValue;
																produtoController.formWasChanged = true;
															},
														),
													),
												),
												BootstrapCol(
													sizes: 'col-12 col-md-3',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: TextFormField(
															keyboardType: TextInputType.number,
															autofocus: true,
															controller: produtoController.precoLucroMaximoController,
															decoration: inputDecoration(
																hintText: 'Informe os dados para o campo Preco Lucro Maximo',
																labelText: 'Preço Lucro Máximo',
																usePadding: true,
															),
															onSaved: (String? value) {},
															onChanged: (text) {
																produtoController.currentModel.precoLucroMaximo = produtoController.precoLucroMaximoController.numberValue;
																produtoController.formWasChanged = true;
															},
														),
													),
												),
												BootstrapCol(
													sizes: 'col-12 col-md-3',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: TextFormField(
															keyboardType: TextInputType.number,
															autofocus: true,
															controller: produtoController.margemLucroController,
															decoration: inputDecoration(
																hintText: 'Informe os dados para o campo Margem Lucro',
																labelText: 'Margem Lucro',
																usePadding: true,
															),
															onSaved: (String? value) {},
															onChanged: (text) {
																produtoController.currentModel.margemLucro = produtoController.margemLucroController.numberValue;
																produtoController.formWasChanged = true;
															},
														),
													),
												),
											],
										),
										const Divider(
											color: Colors.transparent,
										),
										BootstrapRow(
											height: 60,
											children: <BootstrapCol>[
												BootstrapCol(
													sizes: 'col-12 col-md-4',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: TextFormField(
															keyboardType: TextInputType.number,
															autofocus: true,
															controller: produtoController.codigoBalancaController,
															decoration: inputDecoration(
																hintText: 'Informe os dados para o campo Código Balança',
																labelText: 'Código Balança',
																usePadding: true,
															),
															onSaved: (String? value) {},
															onChanged: (text) {
																produtoController.currentModel.codigoBalanca = int.tryParse(text);
																produtoController.formWasChanged = true;
															},
														),
													),
												),
												BootstrapCol(
													sizes: 'col-12 col-md-4',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: CustomDropdownButton(
															controller: produtoController.classeAbcController,
															labelText: 'Classe ABC',
															hintText: 'Informe os dados para o campo Classe ABC',
															items: ProdutoDomain.classeAbcListDropdown,
															onChanged: (dynamic newValue) {
																produtoController.currentModel.classeAbc = newValue;
																produtoController.formWasChanged = true;
															},
														),
													),
												),
												BootstrapCol(
													sizes: 'col-12 col-md-4',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: CustomDropdownButton(
															controller: produtoController.ativoController,
															labelText: 'Ativo',
															hintText: 'Informe os dados para o campo Ativo',
															items: ProdutoDomain.ativoListDropdown,
															onChanged: (dynamic newValue) {
																produtoController.currentModel.ativo = newValue;
																produtoController.formWasChanged = true;
															},
														),
													),
												),
											],
										),
										const Divider(
											color: Colors.transparent,
										),
										BootstrapRow(
											height: 60,
											children: <BootstrapCol>[
												BootstrapCol(
													sizes: 'col-12',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: TextFormField(
															autofocus: true,
															maxLength: 500,
															maxLines: 3,
															controller: produtoController.informacoesAdicionaisNfeController,
															decoration: inputDecoration(
																hintText: 'Informe os dados para o campo Informações Adicionais NFe',
																labelText: 'Informações Adicionais NFe',
																usePadding: true,
															),
															onSaved: (String? value) {},
															onChanged: (text) {
																produtoController.currentModel.informacoesAdicionaisNfe = text;
																produtoController.formWasChanged = true;
															},
														),
													),
												),
											],
										),
										const Divider(
											indent: 10,
											endIndent: 10,
											thickness: 2,
										),
										BootstrapRow(
											height: 60,
											children: <BootstrapCol>[
												BootstrapCol(
													sizes: 'col-12',
													child: Text(
														'field_is_mandatory'.tr,
														style: Theme.of(context).textTheme.bodySmall,
													),
												),
											],
										),
										const SizedBox(height: 10.0),
									],
								),
							),
						),
					),
				),
			);
	}
}
