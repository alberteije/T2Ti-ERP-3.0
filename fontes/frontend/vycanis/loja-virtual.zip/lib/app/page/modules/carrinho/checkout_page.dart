import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:loja_virtual/app/controller/checkout_controller.dart';
import 'package:loja_virtual/app/controller/controller_imports.dart';
import 'package:loja_virtual/app/page/shared_widget/shared_widget_imports.dart';

class CheckoutPage extends StatelessWidget {
  CheckoutPage({Key? key}) : super(key: key);

  final CheckoutController checkoutController = Get.find<CheckoutController>();
  final CartController cartController = Get.find<CartController>();
  final ThemeController themeController = Get.find<ThemeController>();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Finalizar Compra'),
        centerTitle: true,
      ),
      body: Obx(() {
        if (checkoutController.isLoading.value) {
          return const Center(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                CircularProgressIndicator(),
                SizedBox(height: 16),
                Text('Processando seu pedido...'),
              ],
            ),
          );
        }

        return Stepper(
          currentStep: checkoutController.currentStep.value,
          onStepContinue: _handleStepContinue,
          onStepCancel: checkoutController.previousStep,
          onStepTapped: checkoutController.goToStep,
          steps: [
            _buildAddressStep(),
            _buildPaymentStep(),
            _buildConfirmationStep(),
          ],
          controlsBuilder: (context, details) {
            return _buildStepperControls(details);
          },
        );
      }),
    );
  }

  // ============================================
  // PASSO 1: ENDEREÇO
  // ============================================
  Step _buildAddressStep() {
    return Step(
      title: const Text('Endereço de Entrega'),
      subtitle: checkoutController.currentStep.value > 0 
          ? const Text('Preenchido') 
          : null,
      content: Form(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text(
              'Para onde devemos enviar seu pedido?',
              style: TextStyle(fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 16),

            // CEP
            TextFormField(
              controller: checkoutController.cepController,
              decoration: const InputDecoration(
                labelText: 'CEP',
                prefixIcon: Icon(Icons.location_on),
                hintText: '00000-000',
              ),
              keyboardType: TextInputType.number,
              onChanged: (value) {
                if (value.length == 8) {
                  // Aqui você pode integrar com API de CEP
                  // checkoutController.buscarEnderecoPorCep(value);
                }
              },
            ),
            const SizedBox(height: 12),

            // Rua
            TextFormField(
              controller: checkoutController.streetController,
              decoration: const InputDecoration(
                labelText: 'Rua / Avenida',
                prefixIcon: Icon(Icons.house),
              ),
              validator: (value) {
                if (value == null || value.isEmpty) {
                  return 'Informe a rua';
                }
                return null;
              },
            ),
            const SizedBox(height: 12),

            // Número e Complemento
            Row(
              children: [
                Expanded(
                  flex: 2,
                  child: TextFormField(
                    controller: checkoutController.numberController,
                    decoration: const InputDecoration(
                      labelText: 'Número',
                      prefixIcon: Icon(Icons.numbers),
                    ),
                    keyboardType: TextInputType.number,
                    validator: (value) {
                      if (value == null || value.isEmpty) {
                        return 'Informe o número';
                      }
                      return null;
                    },
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  flex: 3,
                  child: TextFormField(
                    controller: checkoutController.complementController,
                    decoration: const InputDecoration(
                      labelText: 'Complemento (opcional)',
                      prefixIcon: Icon(Icons.home),
                    ),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 12),

            // Bairro
            TextFormField(
              controller: checkoutController.neighborhoodController,
              decoration: const InputDecoration(
                labelText: 'Bairro',
                prefixIcon: Icon(Icons.location_city),
              ),
              validator: (value) {
                if (value == null || value.isEmpty) {
                  return 'Informe o bairro';
                }
                return null;
              },
            ),
            const SizedBox(height: 12),

            // Cidade e Estado
            Row(
              children: [
                Expanded(
                  flex: 3,
                  child: TextFormField(
                    controller: checkoutController.cityController,
                    decoration: const InputDecoration(
                      labelText: 'Cidade',
                      prefixIcon: Icon(Icons.apartment),
                    ),
                    validator: (value) {
                      if (value == null || value.isEmpty) {
                        return 'Informe a cidade';
                      }
                      return null;
                    },
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  flex: 1,
                  child: TextFormField(
                    controller: checkoutController.stateController,
                    decoration: const InputDecoration(
                      labelText: 'UF',
                      prefixIcon: Icon(Icons.flag),
                      hintText: 'SP',
                    ),
                    maxLength: 2,
                    textCapitalization: TextCapitalization.characters,
                    validator: (value) {
                      if (value == null || value.isEmpty) {
                        return 'Informe o estado';
                      }
                      if (value.length != 2) {
                        return 'Use sigla (ex: SP)';
                      }
                      return null;
                    },
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
      isActive: checkoutController.currentStep.value >= 0,
      state: checkoutController.currentStep.value > 0 
          ? StepState.complete 
          : StepState.indexed,
    );
  }

  // ============================================
  // PASSO 2: PAGAMENTO
  // ============================================
  Step _buildPaymentStep() {
    return Step(
      title: const Text('Pagamento'),
      subtitle: checkoutController.currentStep.value > 1 
          ? const Text('Selecionado') 
          : null,
      content: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text(
            'Como você prefere pagar?',
            style: TextStyle(fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 16),

          // Métodos de pagamento
          Obx(() => Column(
            children: [
              // CARTÃO DE CRÉDITO
              Card(
                margin: const EdgeInsets.only(bottom: 8),
                child: RadioListTile<String>(
                  title: Row(
                    children: [
                      Icon(Icons.credit_card, color: Colors.blue.shade700),
                      const SizedBox(width: 8),
                      const Text('Cartão de Crédito'),
                    ],
                  ),
                  subtitle: const Text('Parcelado em até 12x'),
                  value: 'credit_card',
                  groupValue: checkoutController.selectedPaymentMethod.value,
                  onChanged: (value) {
                    checkoutController.selectedPaymentMethod.value = value!;
                  },
                ),
              ),

              // PIX
              Card(
                margin: const EdgeInsets.only(bottom: 8),
                child: RadioListTile<String>(
                  title: Row(
                    children: [
                      Icon(Icons.qr_code, color: Colors.green.shade700),
                      const SizedBox(width: 8),
                      const Text('PIX'),
                    ],
                  ),
                  subtitle: const Text('Pagamento instantâneo'),
                  value: 'pix',
                  groupValue: checkoutController.selectedPaymentMethod.value,
                  onChanged: (value) {
                    checkoutController.selectedPaymentMethod.value = value!;
                  },
                ),
              ),

              // BOLETO
              Card(
                child: RadioListTile<String>(
                  title: Row(
                    children: [
                      Icon(Icons.receipt_long, color: Colors.orange.shade700),
                      const SizedBox(width: 8),
                      const Text('Boleto Bancário'),
                    ],
                  ),
                  subtitle: const Text('Vencimento em 3 dias'),
                  value: 'boleto',
                  groupValue: checkoutController.selectedPaymentMethod.value,
                  onChanged: (value) {
                    checkoutController.selectedPaymentMethod.value = value!;
                  },
                ),
              ),
            ],
          )),

          const SizedBox(height: 20),

          // Campos condicionais para cartão
          Obx(() {
            if (checkoutController.selectedPaymentMethod.value == 'credit_card') {
              return Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Divider(),
                  const SizedBox(height: 16),
                  const Text(
                    'Dados do cartão:',
                    style: TextStyle(fontWeight: FontWeight.bold),
                  ),
                  const SizedBox(height: 12),

                  // Número do cartão
                  TextFormField(
                    controller: checkoutController.cardNumberController,
                    decoration: const InputDecoration(
                      labelText: 'Número do cartão',
                      prefixIcon: Icon(Icons.credit_card),
                      hintText: '0000 0000 0000 0000',
                    ),
                    keyboardType: TextInputType.number,
                    validator: (value) {
                      if (value == null || value.isEmpty) {
                        return 'Informe o número do cartão';
                      }
                      if (value.replaceAll(' ', '').length < 16) {
                        return 'Número inválido';
                      }
                      return null;
                    },
                  ),
                  const SizedBox(height: 12),

                  // Nome no cartão
                  TextFormField(
                    controller: checkoutController.cardNameController,
                    decoration: const InputDecoration(
                      labelText: 'Nome impresso no cartão',
                      prefixIcon: Icon(Icons.person),
                    ),
                    textCapitalization: TextCapitalization.words,
                    validator: (value) {
                      if (value == null || value.isEmpty) {
                        return 'Informe o nome no cartão';
                      }
                      return null;
                    },
                  ),
                  const SizedBox(height: 12),

                  // Validade e CVV
                  Row(
                    children: [
                      Expanded(
                        child: TextFormField(
                          controller: checkoutController.cardExpiryController,
                          decoration: const InputDecoration(
                            labelText: 'Validade',
                            prefixIcon: Icon(Icons.calendar_today),
                            hintText: 'MM/AA',
                          ),
                          keyboardType: TextInputType.datetime,
                          validator: (value) {
                            if (value == null || value.isEmpty) {
                              return 'Informe a validade';
                            }
                            if (!RegExp(r'^\d{2}/\d{2}$').hasMatch(value)) {
                              return 'Formato inválido (MM/AA)';
                            }
                            return null;
                          },
                        ),
                      ),
                      const SizedBox(width: 12),
                      Expanded(
                        child: TextFormField(
                          controller: checkoutController.cardCvvController,
                          decoration: const InputDecoration(
                            labelText: 'CVV',
                            prefixIcon: Icon(Icons.lock),
                            hintText: '123',
                          ),
                          keyboardType: TextInputType.number,
                          obscureText: true,
                          maxLength: 4,
                          validator: (value) {
                            if (value == null || value.isEmpty) {
                              return 'Informe o CVV';
                            }
                            return null;
                          },
                        ),
                      ),
                    ],
                  ),
                ],
              );
            }

            // Informações para PIX
            if (checkoutController.selectedPaymentMethod.value == 'pix') {
              return Container(
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(
                  color: Colors.green.shade50,
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(color: Colors.green.shade200),
                ),
                child: Column(
                  children: [
                    Icon(Icons.qr_code_scanner, size: 50, color: Colors.green.shade700),
                    const SizedBox(height: 12),
                    const Text(
                      'Pagamento via PIX',
                      style: TextStyle(
                        fontWeight: FontWeight.bold,
                        fontSize: 16,
                      ),
                    ),
                    const SizedBox(height: 8),
                    const Text(
                      'Após confirmar o pedido, você receberá um QR Code para pagamento.',
                      textAlign: TextAlign.center,
                      style: TextStyle(fontSize: 14),
                    ),
                    const SizedBox(height: 8),
                    Text(
                      'Aprovação em até 5 minutos.',
                      style: TextStyle(
                        color: Colors.green.shade700,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ],
                ),
              );
            }

            // Informações para Boleto
            if (checkoutController.selectedPaymentMethod.value == 'boleto') {
              return Container(
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(
                  color: Colors.orange.shade50,
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(color: Colors.orange.shade200),
                ),
                child: Column(
                  children: [
                    Icon(Icons.receipt_long, size: 50, color: Colors.orange.shade700),
                    const SizedBox(height: 12),
                    const Text(
                      'Boleto Bancário',
                      style: TextStyle(
                        fontWeight: FontWeight.bold,
                        fontSize: 16,
                      ),
                    ),
                    const SizedBox(height: 8),
                    const Text(
                      'Após confirmar o pedido, você receberá o boleto para pagamento.',
                      textAlign: TextAlign.center,
                      style: TextStyle(fontSize: 14),
                    ),
                    const SizedBox(height: 8),
                    Text(
                      'Vencimento: 3 dias úteis',
                      style: TextStyle(
                        color: Colors.orange.shade700,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ],
                ),
              );
            }

            return const SizedBox();
          }),
        ],
      ),
      isActive: checkoutController.currentStep.value >= 1,
      state: checkoutController.currentStep.value > 1 
          ? StepState.complete 
          : StepState.indexed,
    );
  }

  // ============================================
  // PASSO 3: CONFIRMAÇÃO
  // ============================================
  Step _buildConfirmationStep() {
    return Step(
      title: const Text('Confirmação'),
      content: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Resumo do pedido
          Card(
            elevation: 2,
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text(
                    '📦 Resumo do Pedido',
                    style: TextStyle(
                      fontSize: 18,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  const SizedBox(height: 12),

                  // Itens
                  Obx(() {
                    if (cartController.items.isEmpty) {
                      return const Text('Nenhum item no carrinho');
                    }

                    return Column(
                      children: [
                        for (var i = 0; i < cartController.items.length && i < 3; i++)
                          _buildOrderItem(cartController.items[i]),

                        if (cartController.items.length > 3)
                          Padding(
                            padding: const EdgeInsets.only(top: 8),
                            child: Text(
                              '+ ${cartController.items.length - 3} outros itens',
                              style: TextStyle(
                                color: Colors.grey.shade600,
                                fontStyle: FontStyle.italic,
                              ),
                            ),
                          ),
                      ],
                    );
                  }),

                  const Divider(height: 24),

                  // Totais
                  GetX<CartController>(
                    builder: (cart) => Column(
                      children: [
                        _buildSummaryRow('Subtotal', cart.subtotal),
                        _buildSummaryRow('Entrega', cart.deliveryFee.value),
                        if (cart.discount.value > 0)
                          _buildSummaryRow(
                            'Desconto',
                            -cart.discount.value,
                            isDiscount: true,
                          ),
                        const SizedBox(height: 8),
                        _buildSummaryRow(
                          'Total',
                          cart.total,
                          isTotal: true,
                        ),
                      ],
                    ),
                  ),

                ],
              ),
            ),
          ),

          const SizedBox(height: 20),

          // Endereço de entrega
          Card(
            elevation: 2,
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text(
                    '🏠 Endereço de Entrega',
                    style: TextStyle(
                      fontSize: 18,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  const SizedBox(height: 12),
                  Builder(builder: (_) {
                    if (checkoutController.streetController.text.isEmpty) {
                      return const Text(
                        'Endereço não informado',
                        style: TextStyle(color: Colors.grey),
                      );
                    }

                    return Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          '${checkoutController.streetController.text}, ${checkoutController.numberController.text}',
                          style: const TextStyle(fontWeight: FontWeight.bold),
                        ),
                        if (checkoutController.complementController.text.isNotEmpty)
                          Text(checkoutController.complementController.text),
                        Text(checkoutController.neighborhoodController.text),
                        Text('${checkoutController.cityController.text} - ${checkoutController.stateController.text}'),
                        Text('CEP: ${checkoutController.cepController.text}'),
                      ],
                    );
                  })
                ],
              ),
            ),
          ),

          const SizedBox(height: 20),

          // Método de pagamento
          Card(
            elevation: 2,
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text(
                    '💳 Método de Pagamento',
                    style: TextStyle(
                      fontSize: 18,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  const SizedBox(height: 12),
                  Obx(() {
                    String metodo = '';
                    switch (checkoutController.selectedPaymentMethod.value) {
                      case 'credit_card':
                        metodo = 'Cartão de Crédito';
                        break;
                      case 'pix':
                        metodo = 'PIX';
                        break;
                      case 'boleto':
                        metodo = 'Boleto Bancário';
                        break;
                      default:
                        metodo = 'Não selecionado';
                    }
                    return Text(
                      metodo,
                      style: const TextStyle(
                        fontSize: 16,
                        fontWeight: FontWeight.bold,
                      ),
                    );
                  }),
                ],
              ),
            ),
          ),

          const SizedBox(height: 20),

          // Termos e condições
          Container(
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(
              color: Colors.grey.shade100,
              borderRadius: BorderRadius.circular(8),
            ),
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Icon(
                  Icons.check_circle,
                  color: Colors.green.shade600,
                  size: 20,
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Text(
                    'Ao finalizar, você concorda com nossos Termos de Serviço e Política de Privacidade. O pedido será processado imediatamente após a confirmação do pagamento.',
                    style: TextStyle(
                      color: Colors.grey.shade700,
                      fontSize: 12,
                    ),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
      isActive: checkoutController.currentStep.value >= 2,
      state: StepState.indexed,
    );
  }

  // ============================================
  // WIDGETS AUXILIARES
  // ============================================
  Widget _buildOrderItem(CartItem item) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 8),
      child: Row(
        children: [
          Expanded(
            flex: 3,
            child: Text(
              item.productName,
              style: TextStyle(color: Colors.grey.shade700),
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
            ),
          ),
          Expanded(
            flex: 1,
            child: Text(
              'x${item.quantity}',
              style: TextStyle(color: Colors.grey.shade600),
              textAlign: TextAlign.center,
            ),
          ),
          Expanded(
            flex: 2,
            child: Text(
              'R\$${item.total.toStringAsFixed(2)}',
              style: const TextStyle(fontWeight: FontWeight.bold),
              textAlign: TextAlign.right,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildSummaryRow(String label, double value,
      {bool isDiscount = false, bool isTotal = false}) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 6),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(
            label,
            style: TextStyle(
              fontSize: isTotal ? 16 : 14,
              fontWeight: isTotal ? FontWeight.bold : FontWeight.normal,
              color: isDiscount ? Colors.green.shade700 : Colors.grey.shade700,
            ),
          ),
          Text(
            'R\$${value.toStringAsFixed(2)}',
            style: TextStyle(
              fontSize: isTotal ? 18 : 14,
              fontWeight: isTotal ? FontWeight.bold : FontWeight.normal,
              color: isTotal
                  ? Colors.green.shade700
                  : isDiscount
                      ? Colors.green.shade700
                      : Colors.grey.shade700,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildStepperControls(ControlsDetails details) {
    return Padding(
      padding: const EdgeInsets.only(top: 24),
      child: Row(
        children: [
          // Botão voltar
          if (checkoutController.currentStep.value > 0)
            Expanded(
              child: OutlinedButton(
                onPressed: details.onStepCancel,
                style: OutlinedButton.styleFrom(
                  padding: const EdgeInsets.symmetric(vertical: 16),
                  side: BorderSide(color: Colors.blue.shade600),
                ),
                child: const Text(
                  'Voltar',
                  style: TextStyle(fontSize: 16),
                ),
              ),
            ),

          if (checkoutController.currentStep.value > 0) 
            const SizedBox(width: 12),

          // Botão próximo/finalizar
          Expanded(
            child: ElevatedButton(
              onPressed: details.onStepContinue,
              style: ElevatedButton.styleFrom(
                backgroundColor: checkoutController.currentStep.value == 2
                    ? Colors.green.shade600
                    : Colors.blue.shade600,
                padding: const EdgeInsets.symmetric(vertical: 16),
              ),
              child: Text(
                checkoutController.currentStep.value == 2
                    ? 'Finalizar Compra'
                    : 'Continuar',
                style: const TextStyle(fontSize: 16, color: Colors.white),
              ),
            ),
          ),
        ],
      ),
    );
  }

  // ============================================
  // LÓGICA DOS PASSOS
  // ============================================
  void _handleStepContinue() {
    switch (checkoutController.currentStep.value) {
      case 0:
        if (checkoutController.validateAddressStep()) {
          checkoutController.nextStep();
        } else {
          showErrorSnackBar(
            message: 'Preencha todos os campos do endereço',
          );
        }
        break;

      case 1:
        if (checkoutController.validatePaymentStep()) {
          checkoutController.nextStep();
        } else {
          showErrorSnackBar(
            message: 'Preencha os dados de pagamento corretamente',
          );
        }
        break;

      case 2:
        checkoutController.finalizeOrder();
        break;
    }
  }
}