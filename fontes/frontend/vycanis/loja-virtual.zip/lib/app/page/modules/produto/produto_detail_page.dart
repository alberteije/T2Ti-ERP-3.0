import 'dart:io';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:loja_virtual/app/controller/controller_imports.dart';
import 'package:loja_virtual/app/page/shared_widget/shared_widget_imports.dart';
import 'package:loja_virtual/app/routes/app_routes.dart';

class ProdutoDetailPage extends StatelessWidget {
  ProdutoDetailPage({Key? key}) : super(key: key);
  
  final CartController cartController = Get.find<CartController>();
  final ThemeController themeController = Get.find<ThemeController>();
  
  @override
  Widget build(BuildContext context) {
    // Recupera o produto passado como argumento
    final arguments = Get.arguments;
    if (arguments == null) {
      Get.back();
      return const Scaffold(body: SizedBox());
    }
    
    final storeProduct = arguments['storeProduct'] as StoreProduct;
    final produto = storeProduct.produto;
    final imagePath = storeProduct.localImagePath;
    
    return Scaffold(
      appBar: AppBar(
        title: Text(produto.nome ?? 'Detalhes'),
        centerTitle: true,
        actions: [
          IconButton(
            icon: const Icon(Icons.share),
            onPressed: () => _shareProduct(produto),
            tooltip: 'Compartilhar',
          ),
        ],
      ),
      body: SingleChildScrollView(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Imagem do produto
            _buildProductImage(imagePath, produto.nome),
            
            // Informações principais
            Padding(
              padding: const EdgeInsets.all(16.0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  // Nome
                  Text(
                    produto.nome ?? 'Produto',
                    style: const TextStyle(
                      fontSize: 24,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  const SizedBox(height: 8),
                  
                  // Preço
                  _buildPriceSection(produto),
                  const SizedBox(height: 16),
                  
                  // Descrição
                  if (produto.descricao != null && produto.descricao!.isNotEmpty)
                    Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        const Text(
                          'Descrição',
                          style: TextStyle(
                            fontSize: 18,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                        const SizedBox(height: 8),
                        Text(
                          produto.descricao!,
                          style: TextStyle(
                            fontSize: 16,
                            color: Colors.grey.shade700,
                            height: 1.5,
                          ),
                        ),
                        const SizedBox(height: 16),
                      ],
                    ),
                  
                  // Estoque
                  _buildStockInfo(produto),
                  const SizedBox(height: 16),
                  
                  // Códigos
                  _buildCodeInfo(produto),
                ],
              ),
            ),
          ],
        ),
      ),
      bottomNavigationBar: _buildBottomBar(produto, storeProduct),
    );
  }
  
  // ============================================
  // WIDGETS AUXILIARES
  // ============================================
  
  Widget _buildProductImage(String? imagePath, String? productName) {
    return Container(
      height: 300,
      width: double.infinity,
      color: themeController.isDarkMode.value
          ? Colors.grey.shade900 
          : Colors.grey.shade100,
      child: imagePath != null && File(imagePath).existsSync()
          ? Image.file(
              File(imagePath),
              fit: BoxFit.contain,
              errorBuilder: (context, error, stackTrace) {
                return _buildDefaultImage(productName);
              },
            )
          : _buildDefaultImage(productName),
    );
  }
  
  Widget _buildDefaultImage(String? productName) {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(
            Icons.shopping_bag,
            size: 80,
            color: Colors.grey.shade400,
          ),
          if (productName != null) ...[
            const SizedBox(height: 8),
            Text(
              productName,
              style: TextStyle(
                fontSize: 16,
                color: Colors.grey.shade500,
              ),
              textAlign: TextAlign.center,
            ),
          ],
        ],
      ),
    );
  }
  
  Widget _buildPriceSection(dynamic produto) {
    final hasDiscount = produto.precoVendaMinimo != null &&
                      produto.valorVenda != null &&
                      produto.valorVenda! < produto.precoVendaMinimo!;
    
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        // Preço atual
        Text(
          'R\$${produto.valorVenda?.toStringAsFixed(2) ?? '0,00'}',
          style: const TextStyle(
            fontSize: 28,
            fontWeight: FontWeight.bold,
            color: Colors.green,
          ),
        ),
        
        // Preço original (se tiver desconto)
        if (hasDiscount)
          Padding(
            padding: const EdgeInsets.only(top: 4),
            child: Row(
              children: [
                Text(
                  'De R\$${produto.precoVendaMinimo?.toStringAsFixed(2)}',
                  style: const TextStyle(
                    fontSize: 16,
                    color: Colors.grey,
                    decoration: TextDecoration.lineThrough,
                  ),
                ),
                const SizedBox(width: 8),
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                  decoration: BoxDecoration(
                    color: Colors.red.shade100,
                    borderRadius: BorderRadius.circular(4),
                  ),
                  child: Text(
                    '${((produto.precoVendaMinimo! - produto.valorVenda!) / produto.precoVendaMinimo! * 100).toStringAsFixed(0)}% OFF',
                    style: TextStyle(
                      fontSize: 12,
                      color: Colors.red.shade800,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),
              ],
            ),
          ),
      ],
    );
  }
  
  Widget _buildStockInfo(dynamic produto) {
    final estoque = produto.quantidadeEstoque ?? 0;
    final isAvailable = estoque > 0;
    
    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: isAvailable ? Colors.green.shade50 : Colors.grey.shade100,
        borderRadius: BorderRadius.circular(8),
        border: Border.all(
          color: isAvailable ? Colors.green.shade200 : Colors.grey.shade300,
        ),
      ),
      child: Row(
        children: [
          Icon(
            isAvailable ? Icons.check_circle : Icons.remove_circle,
            color: isAvailable ? Colors.green.shade600 : Colors.grey.shade600,
          ),
          const SizedBox(width: 8),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  isAvailable ? 'Disponível' : 'Indisponível',
                  style: TextStyle(
                    fontWeight: FontWeight.bold,
                    color: isAvailable ? Colors.green.shade800 : Colors.grey.shade700,
                  ),
                ),
                const SizedBox(height: 2),
                Text(
                  isAvailable 
                      ? '${estoque.toStringAsFixed(0)} unidades em estoque'
                      : 'Produto esgotado',
                  style: TextStyle(
                    fontSize: 12,
                    color: isAvailable ? Colors.green.shade600 : Colors.grey.shade600,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
  
  Widget _buildCodeInfo(dynamic produto) {
    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: Colors.blue.shade50,
        borderRadius: BorderRadius.circular(8),
        border: Border.all(color: Colors.blue.shade200),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'Informações do produto',
            style: TextStyle(
              fontWeight: FontWeight.bold,
              color: Colors.blue.shade800,
            ),
          ),
          const SizedBox(height: 8),
          if (produto.codigoInterno != null)
            _buildInfoRow('Código interno', produto.codigoInterno!),
          if (produto.gtin != null)
            _buildInfoRow('GTIN/EAN', produto.gtin!),
          if (produto.codigoNcm != null)
            _buildInfoRow('NCM', produto.codigoNcm!),
          if (produto.codigoCest != null)
            _buildInfoRow('CEST', produto.codigoCest!),
        ],
      ),
    );
  }
  
  Widget _buildInfoRow(String label, String value) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 4),
      child: Row(
        children: [
          Expanded(
            flex: 2,
            child: Text(
              '$label:',
              style: TextStyle(
                fontSize: 12,
                color: Colors.grey.shade600,
              ),
            ),
          ),
          Expanded(
            flex: 3,
            child: Text(
              value,
              style: const TextStyle(
                fontSize: 12,
                fontWeight: FontWeight.bold,
              ),
            ),
          ),
        ],
      ),
    );
  }
  
  Widget _buildBottomBar(dynamic produto, StoreProduct storeProduct) {
    final estoque = produto.quantidadeEstoque ?? 0;
    final isAvailable = estoque > 0;
    final isInCart = cartController.items
        .any((item) => item.productId == produto.id);
    
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: themeController.isDarkMode.value
            ? Colors.grey.shade900
            : Colors.white,
        border: Border(top: BorderSide(color: Colors.grey.shade300)),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withValues(alpha: 0.1),
            blurRadius: 4,
            offset: const Offset(0, -2),
          ),
        ],
      ),
      child: Row(
        children: [
          // Botão voltar
          Expanded(
            child: OutlinedButton.icon(
              onPressed: () => Get.back(),
              icon: const Icon(Icons.arrow_back),
              label: const Text('Voltar'),
              style: OutlinedButton.styleFrom(
                padding: const EdgeInsets.symmetric(vertical: 12),
              ),
            ),
          ),
          const SizedBox(width: 12),
          
          // Botão comprar/adicionar
          Expanded(
            child: isInCart
                ? ElevatedButton.icon(
                    onPressed: () {
                      Get.toNamed(Routes.cartPage);
                    },
                    icon: const Icon(Icons.shopping_cart_checkout),
                    label: const Text('Ver Carrinho'),
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.green.shade600,
                      padding: const EdgeInsets.symmetric(vertical: 12),
                    ),
                  )
                : ElevatedButton.icon(
                    onPressed: isAvailable
                        ? () {
                            cartController.addItem(
                              productId: produto.id!,
                              productName: produto.nome ?? 'Produto',
                              unitPrice: produto.valorVenda ?? 0,
                              quantity: 1,
                              imagePath: storeProduct.localImagePath,
                            );
                            showInfoSnackBar(
                              message: '${produto.nome} adicionado ao carrinho',
                            );
                          }
                        : null,
                    icon: Icon(isAvailable ? Icons.add_shopping_cart : Icons.block),
                    label: Text(isAvailable ? 'Comprar' : 'Esgotado'),
                    style: ElevatedButton.styleFrom(
                      backgroundColor: isAvailable 
                          ? Colors.blue.shade600 
                          : Colors.grey.shade400,
                      padding: const EdgeInsets.symmetric(vertical: 12),
                    ),
                  ),
          ),
        ],
      ),
    );
  }
  
  void _shareProduct(dynamic produto) {
    // Implemente compartilhamento se desejar
    showInfoSnackBar(message: 'Compartilhar ${produto.nome}');
  }
}