import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:buttons_tabbar/buttons_tabbar.dart';
import 'package:get/get.dart';
import 'package:loja_virtual/app/controller/produto_controller.dart';
import 'package:loja_virtual/app/page/shared_widget/shared_widget_imports.dart';

class ProdutoTabPage extends StatelessWidget {
  ProdutoTabPage({Key? key}) : super(key: key);
  final produtoController = Get.find<ProdutoController>();

  @override
  Widget build(BuildContext context) {
		return KeyboardListener(
			autofocus: false,
			focusNode: FocusNode(),
			onKeyEvent: (event) {
				if (event.logicalKey == LogicalKeyboardKey.escape) {
          produtoController.preventDataLoss();
        }
      },
      child: Scaffold(
        key: produtoController.produtoTabPageScaffoldKey,
        appBar: AppBar(
					automaticallyImplyLeading: false, 
					title: Text('${ produtoController.screenTitle } - ${ produtoController.isNewRecord ? 'inserting'.tr : 'editing'.tr }',),
					actions: [
						saveButton(onPressed: produtoController.save),
						cancelAndExitButton(onPressed: produtoController.preventDataLoss),
					]
				),
        body: SafeArea(
          child: Column(
            children: <Widget>[
              Expanded(
                child: TabBarView(
                  controller: produtoController.tabController,
                  children: produtoController.tabPages(),
                ),
              ),
              ButtonsTabBar(
                controller: produtoController.tabController,
                onTap: produtoController.tabChange,
                height: 40,
                elevation: 2,
                borderWidth: 0,
                backgroundColor: Colors.blueGrey,
                unselectedBackgroundColor: Colors.grey[300],
                unselectedLabelStyle: const TextStyle(color: Colors.black),
                labelStyle: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold),
                tabs: produtoController.tabItems,
              ),
              const SizedBox(
                height: 10,
              ),
            ],
          ),
        ),
      ),
    );
  }
}
