import 'package:flutter/material.dart';
import 'package:flutter_bootstrap/flutter_bootstrap.dart';
import 'package:get/get.dart';
import 'package:loja_virtual/app/page/shared_widget/shared_widget_imports.dart';
import 'package:loja_virtual/app/controller/produto_ficha_tecnica_controller.dart';
import 'package:loja_virtual/app/infra/infra_imports.dart';
import 'package:loja_virtual/app/page/shared_widget/input/input_imports.dart';

class ProdutoFichaTecnicaEditPage extends StatelessWidget {
	ProdutoFichaTecnicaEditPage({Key? key}) : super(key: key);
	final produtoFichaTecnicaController = Get.find<ProdutoFichaTecnicaController>();

	@override
	Widget build(BuildContext context) {
			return Scaffold(
				key: produtoFichaTecnicaController.produtoFichaTecnicaScaffoldKey,	
				appBar: AppBar(
					automaticallyImplyLeading: false,
					title: Text('${ produtoFichaTecnicaController.screenTitle } - ${ produtoFichaTecnicaController.isNewRecord ? 'inserting'.tr : 'editing'.tr }',),
					actions: [
						saveButton(onPressed: produtoFichaTecnicaController.save),
						cancelAndExitButton(onPressed: produtoFichaTecnicaController.preventDataLoss),
					]
				),
				body: SafeArea(
					top: false,
					bottom: false,
					child: Form(
						key: produtoFichaTecnicaController.produtoFichaTecnicaFormKey,
						autovalidateMode: AutovalidateMode.always,
						child: Scrollbar(
							controller: produtoFichaTecnicaController.scrollController,
							child: SingleChildScrollView(
								controller: produtoFichaTecnicaController.scrollController,
								child: BootstrapContainer(
									fluid: true,
									padding: const EdgeInsets.all(10.0),
									children: <Widget>[
										const Divider(
											color: Colors.transparent,
										),
										BootstrapRow(
											height: 60,
											children: <BootstrapCol>[
												BootstrapCol(
													sizes: 'col-12',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: TextFormField(
															autofocus: true,
															validator: ValidateFormField.validateMandatory,
															maxLength: 100,
															controller: produtoFichaTecnicaController.descricaoController,
															decoration: inputDecoration(
																hintText: 'Informe os dados para o campo Descrição',
																labelText: 'Descrição *',
																usePadding: true,
															),
															onSaved: (String? value) {},
															onChanged: (text) {
																produtoFichaTecnicaController.produtoFichaTecnicaModel.descricao = text;
																produtoFichaTecnicaController.formWasChangedDetail = true;
															},
														),
													),
												),
											],
										),
										const Divider(
											color: Colors.transparent,
										),
										BootstrapRow(
											height: 60,
											children: <BootstrapCol>[
												BootstrapCol(
													sizes: 'col-12 col-md-3',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: TextFormField(
															keyboardType: TextInputType.number,
															autofocus: true,
															controller: produtoFichaTecnicaController.idProdutoFilhoController,
															decoration: inputDecoration(
																hintText: 'Informe os dados para o campo Id Produto Filho',
																labelText: 'ID Produto Filho',
																usePadding: true,
															),
															onSaved: (String? value) {},
															onChanged: (text) {
																produtoFichaTecnicaController.produtoFichaTecnicaModel.idProdutoFilho = int.tryParse(text);
																produtoFichaTecnicaController.formWasChangedDetail = true;
															},
														),
													),
												),
												BootstrapCol(
													sizes: 'col-12 col-md-3',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: TextFormField(
															keyboardType: TextInputType.number,
															autofocus: true,
															controller: produtoFichaTecnicaController.quantidadeController,
															decoration: inputDecoration(
																hintText: 'Informe os dados para o campo Quantidade',
																labelText: 'Quantidade',
																usePadding: true,
															),
															onSaved: (String? value) {},
															onChanged: (text) {
																produtoFichaTecnicaController.produtoFichaTecnicaModel.quantidade = produtoFichaTecnicaController.quantidadeController.numberValue;
																produtoFichaTecnicaController.formWasChangedDetail = true;
															},
														),
													),
												),
												BootstrapCol(
													sizes: 'col-12 col-md-3',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: TextFormField(
															keyboardType: TextInputType.number,
															autofocus: true,
															controller: produtoFichaTecnicaController.valorCustoController,
															decoration: inputDecoration(
																hintText: 'Informe os dados para o campo Valor Custo',
																labelText: 'Valor Custo',
																usePadding: true,
															),
															onSaved: (String? value) {},
															onChanged: (text) {
																produtoFichaTecnicaController.produtoFichaTecnicaModel.valorCusto = produtoFichaTecnicaController.valorCustoController.numberValue;
																produtoFichaTecnicaController.formWasChangedDetail = true;
															},
														),
													),
												),
												BootstrapCol(
													sizes: 'col-12 col-md-3',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: TextFormField(
															keyboardType: TextInputType.number,
															autofocus: true,
															controller: produtoFichaTecnicaController.percentualCustoController,
															decoration: inputDecoration(
																hintText: 'Informe os dados para o campo Percentual Custo',
																labelText: 'Percentual Custo',
																usePadding: true,
															),
															onSaved: (String? value) {},
															onChanged: (text) {
																produtoFichaTecnicaController.produtoFichaTecnicaModel.percentualCusto = produtoFichaTecnicaController.percentualCustoController.numberValue;
																produtoFichaTecnicaController.formWasChangedDetail = true;
															},
														),
													),
												),
											],
										),
										const Divider(
											indent: 10,
											endIndent: 10,
											thickness: 2,
										),
										BootstrapRow(
											height: 60,
											children: <BootstrapCol>[
												BootstrapCol(
													sizes: 'col-12',
													child: Text(
														'field_is_mandatory'.tr,
														style: Theme.of(context).textTheme.bodySmall,
													),
												),
											],
										),
										const SizedBox(height: 10.0),
									],
								),
							),
						),
					),
				),
			);
	}
}
