import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:loja_virtual/app/infra/infra_imports.dart';

class ThemeController extends GetxController {
  RxBool isDarkMode = true.obs;

  RxBool isModuleButtonsVisible = false.obs;

  Future<ThemeMode> getTheme() async {
    if (Constants.usingLocalDatabase) {
      final settings = await Session.database.customSelect(Constants.sqlGetSettings).getSingleOrNull();

      if (settings!.data["APP_THEME"] == 'ThemeMode.dark') {
        isDarkMode.value = true;
        return ThemeMode.dark;
      } else {
        isDarkMode.value = false;
        return ThemeMode.light;
      }
    } else {
      isDarkMode.value = false;
      return ThemeMode.light;
    }
  }

  void changeThemeMode(ThemeMode themeMode) {
    isDarkMode.value = !isDarkMode.value;
    Get.changeThemeMode(themeMode);
    Session.database.customUpdate("update HIDDEN_SETTINGS set APP_THEME = '$themeMode'");
  }
}
