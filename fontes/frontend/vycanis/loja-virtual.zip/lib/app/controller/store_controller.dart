import 'package:get/get.dart';
import 'package:loja_virtual/app/controller/produto_controller.dart';
import 'package:loja_virtual/app/data/repository/local_image_repository.dart';
import 'package:loja_virtual/app/data/repository/produto_repository.dart';
import 'package:loja_virtual/app/page/shared_widget/message_dialog.dart';

class StoreProduct {
  final dynamic produto;
  final String? localImagePath;

  StoreProduct({
    required this.produto,
    this.localImagePath,
  });

  int? get id => produto.id;
  String? get nome => produto.nome;
  double? get valorVenda => produto.valorVenda;
  double? get quantidadeEstoque => produto.quantidadeEstoque;
  double? get precoVendaMinimo => produto.precoVendaMinimo;
}

// Categoria para filtros
class StoreCategory {
  final int id;
  final String name;

  StoreCategory({required this.id, required this.name});
}

class StoreController extends GetxController {
  final LocalImageRepository _imageRepo = LocalImageRepository();
  final ProdutoRepository produtoRepository = Get.find<ProdutoRepository>();

  ProdutoController get produtoController => Get.find<ProdutoController>();

  var storeProducts = <StoreProduct>[].obs;
  var filteredProducts = <StoreProduct>[].obs;

  // Estados observáveis
  var isLoading = true.obs;
  var hasLocalImages = false.obs;
  var selectedCategoryId = Rx<int?>(null);

  // Categorias
  var categories = <StoreCategory>[].obs;

  @override
  void onInit() async {
    super.onInit();

    // Inicializa categorias
    categories.value = [
      StoreCategory(id: 1, name: 'Todos'),
      StoreCategory(id: 2, name: 'Ofertas'),
      StoreCategory(id: 3, name: 'Mais Vendidos'),
    ];

    await checkLocalImages();
    await loadStoreProducts();
  }

  Future<void> checkLocalImages() async {
    hasLocalImages.value = await _imageRepo.hasLocalImages();
  }

  Future<void> loadStoreProducts() async {
    try {
      isLoading.value = true;

      final produtosData = await produtoRepository.getList(filter: null);

      final List<StoreProduct> products = [];

      for (final produto in produtosData) {
        if (produto.id != null) {
          final imagePath = await _imageRepo.getProductImagePath(produto.id!);

          products.add(StoreProduct(
            produto: produto,
            localImagePath: imagePath,
          ));
        }
      }

      storeProducts.value = products;
      filteredProducts.value = products;

    } catch (e) {
      showErrorSnackBar(message: e.toString());
    } finally {
      isLoading.value = false;
    }
  }

  void searchProducts(String query) {
    if (query.isEmpty) {
      filteredProducts.value = storeProducts;
      return;
    }

    final searchTerm = query.toLowerCase();
    filteredProducts.value = storeProducts.where((storeProduct) {
      return storeProduct.nome?.toLowerCase().contains(searchTerm) ?? false;
    }).toList();
  }

  void filterByCategory(int? categoryId) {
    selectedCategoryId.value = categoryId;

    if (categoryId == null || categoryId == 1) {
      filteredProducts.value = storeProducts;
      return;
    }

    if (categoryId == 2) {
      filteredProducts.value = storeProducts.where((storeProduct) {
        final produto = storeProduct.produto;
        return produto.precoVendaMinimo != null &&
              produto.valorVenda != null &&
              produto.valorVenda! < produto.precoVendaMinimo!;
      }).toList();
      return;
    }

    filteredProducts.value = storeProducts;
  }

  void clearFilters() {
    selectedCategoryId.value = null;
    filteredProducts.value = storeProducts;
  }
}