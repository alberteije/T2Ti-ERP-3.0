import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:pluto_grid/pluto_grid.dart';
import 'package:extended_masked_text/extended_masked_text.dart';

import 'package:loja_virtual/app/page/page_imports.dart';
import 'package:loja_virtual/app/page/shared_widget/message_dialog.dart';
import 'package:loja_virtual/app/page/grid_columns/grid_columns_imports.dart';
import 'package:loja_virtual/app/controller/controller_imports.dart';
import 'package:loja_virtual/app/data/model/model_imports.dart';

class ProdutoFichaTecnicaController extends ControllerBase<ProdutoFichaTecnicaModel, void> {

  ProdutoFichaTecnicaController() : super(repository: null) {
    dbColumns = ProdutoFichaTecnicaModel.dbColumns;
    aliasColumns = ProdutoFichaTecnicaModel.aliasColumns;
    gridColumns = produtoFichaTecnicaGridColumns();
    functionName = "produto_ficha_tecnica";
    screenTitle = "Ficha Técnica";
  }

  final _produtoFichaTecnicaModel = ProdutoFichaTecnicaModel().obs;
  ProdutoFichaTecnicaModel get produtoFichaTecnicaModel => _produtoFichaTecnicaModel.value;
  set produtoFichaTecnicaModel(value) => _produtoFichaTecnicaModel.value = value ?? ProdutoFichaTecnicaModel();

  List<ProdutoFichaTecnicaModel> get produtoFichaTecnicaModelList => Get.find<ProdutoController>().currentModel.produtoFichaTecnicaModelList ?? [];

  final _userMadeChanges = false.obs;
  get userMadeChanges => _userMadeChanges.value;
  set userMadeChanges(value) => _userMadeChanges.value = value;

  final _formWasChangedDetail = false.obs;
  bool get formWasChangedDetail => _formWasChangedDetail.value;
  set formWasChangedDetail(value) => _formWasChangedDetail.value = value;

  late PlutoGridStateManager _plutoGridStateManager;
  @override
  PlutoGridStateManager get plutoGridStateManager => _plutoGridStateManager;
  @override
  set plutoGridStateManager(value) => _plutoGridStateManager = value;

  final produtoFichaTecnicaScaffoldKey = GlobalKey<ScaffoldState>();
  final produtoFichaTecnicaFormKey = GlobalKey<FormState>();

  @override
  ProdutoFichaTecnicaModel createNewModel() => ProdutoFichaTecnicaModel();

  @override
  final standardFieldForFilter = ProdutoFichaTecnicaModel.aliasColumns[ProdutoFichaTecnicaModel.dbColumns.indexOf('descricao')];

  final descricaoController = TextEditingController();
  final idProdutoFilhoController = MoneyMaskedTextController(precision: 0, decimalSeparator: '', thousandSeparator: '');
  final quantidadeController = MoneyMaskedTextController();
  final valorCustoController = MoneyMaskedTextController();
  final percentualCustoController = MoneyMaskedTextController();

  final Map<String, dynamic> mobileConfig = {
    'primaryColumns': ['descricao'],
    'secondaryColumns': ['id_produto_filho'],
  };

  List<Map<String, dynamic>> get mobileItems {
    return modelList.map((produtoFichaTecnica) => produtoFichaTecnica.toJson).toList();
  }

  @override
  List<PlutoRow> plutoRows() => List<PlutoRow>.from(produtoFichaTecnicaModelList.map((model) => model.toPlutoRow()));

  @override
  Future<void> getList({Filter? filter}) async {}

  @override
  void prepareForInsert() {
    isNewRecord = true;
    produtoFichaTecnicaModel = createNewModel();
    _resetForm();
    Get.to(() => ProdutoFichaTecnicaEditPage());
  }

  void _resetForm() {
    formWasChangedDetail = false;
    descricaoController.text = '';
    idProdutoFilhoController.updateValue(0);
    quantidadeController.updateValue(0);
    valorCustoController.updateValue(0);
    percentualCustoController.updateValue(0);
  }

  @override
  void selectRowForEditing(PlutoRow? row) async {
    if (row == null) {
      showInfoSnackBar(message: 'message_select_one_to_edited'.tr);
      return;
    }

    selectRowForEditingByTempId(row.cells['tempId']?.value);
  }

  @override
  void selectRowForEditingById(int id) {}

  void selectRowForEditingByTempId(String tempId) {
		isNewRecord = false;
    final model = produtoFichaTecnicaModelList.firstWhere((m) => m.tempId == tempId);
    produtoFichaTecnicaModel = model.clone();
		produtoFichaTecnicaModel.tempId = model.tempId;
    updateControllersFromModel();
    Get.to(() => ProdutoFichaTecnicaEditPage());
  }

  void updateControllersFromModel() {
    descricaoController.text = produtoFichaTecnicaModel.descricao ?? '';
    idProdutoFilhoController.updateValue((produtoFichaTecnicaModel.idProdutoFilho ?? 0).toDouble());
    quantidadeController.updateValue(produtoFichaTecnicaModel.quantidade ?? 0);
    valorCustoController.updateValue(produtoFichaTecnicaModel.valorCusto ?? 0);
    percentualCustoController.updateValue(produtoFichaTecnicaModel.percentualCusto ?? 0);
    formWasChangedDetail = false;
  }

  @override
  Future<void> save() async {
    if (!produtoFichaTecnicaFormKey.currentState!.validate()) {
      showErrorSnackBar(message: 'validator_form_message'.tr);
      return;
    }

    if (formWasChangedDetail) {
      if (isNewRecord) {
        produtoFichaTecnicaModelList.insert(0, produtoFichaTecnicaModel.clone());
      } else {
        final index = produtoFichaTecnicaModelList.indexWhere((m) => m.tempId == produtoFichaTecnicaModel.tempId);
        if (index >= 0) {
          produtoFichaTecnicaModelList[index] = produtoFichaTecnicaModel.clone();
        }
      }

      userMadeChanges = true;
      loadData();
      Get.back(result: true);
    } else {
      Get.back();
    }
  }


  @override
  Future deleteSelected() async {
    final currentRow = plutoGridStateManager.currentRow;
    if (currentRow == null) {
      showInfoSnackBar(message: 'message_select_one_to_delete'.tr);
      return null;
    }
    showDeleteDialog(() async {
      final id = currentRow.cells['id']?.value;
      final tempId = currentRow.cells['tempId']?.value;
      produtoFichaTecnicaModelList.removeWhere((model) => (id != 0 && model.id == id) || (id == 0 && model.tempId == tempId));
      plutoGridStateManager.removeCurrentRow();
      userMadeChanges = true;
    });
  }

  @override
  void preventDataLoss() {
    if (formWasChangedDetail) {
      showQuestionDialog('message_data_loss'.tr, () => Get.back());
    } else {
      formWasChangedDetail = false;
      Get.back();
    }
  }

  @override
  void onClose() {
    descricaoController.dispose();
    idProdutoFilhoController.dispose();
    quantidadeController.dispose();
    valorCustoController.dispose();
    percentualCustoController.dispose();
  }

}