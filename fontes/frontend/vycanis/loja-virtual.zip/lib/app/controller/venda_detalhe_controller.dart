import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:pluto_grid/pluto_grid.dart';
import 'package:extended_masked_text/extended_masked_text.dart';
import 'package:loja_virtual/app/routes/app_routes.dart';

import 'package:loja_virtual/app/page/page_imports.dart';
import 'package:loja_virtual/app/page/shared_widget/message_dialog.dart';
import 'package:loja_virtual/app/page/grid_columns/grid_columns_imports.dart';
import 'package:loja_virtual/app/controller/controller_imports.dart';
import 'package:loja_virtual/app/data/model/model_imports.dart';

class VendaDetalheController extends ControllerBase<VendaDetalheModel, void> {

  VendaDetalheController() : super(repository: null) {
    dbColumns = VendaDetalheModel.dbColumns;
    aliasColumns = VendaDetalheModel.aliasColumns;
    gridColumns = vendaDetalheGridColumns();
    functionName = "venda_detalhe";
    screenTitle = "Itens da Venda";
  }

  final _vendaDetalheModel = VendaDetalheModel().obs;
  VendaDetalheModel get vendaDetalheModel => _vendaDetalheModel.value;
  set vendaDetalheModel(value) => _vendaDetalheModel.value = value ?? VendaDetalheModel();

  List<VendaDetalheModel> get vendaDetalheModelList => Get.find<VendaCabecalhoController>().currentModel.vendaDetalheModelList ?? [];

  final _userMadeChanges = false.obs;
  get userMadeChanges => _userMadeChanges.value;
  set userMadeChanges(value) => _userMadeChanges.value = value;

  final _formWasChangedDetail = false.obs;
  bool get formWasChangedDetail => _formWasChangedDetail.value;
  set formWasChangedDetail(value) => _formWasChangedDetail.value = value;

  late PlutoGridStateManager _plutoGridStateManager;
  @override
  PlutoGridStateManager get plutoGridStateManager => _plutoGridStateManager;
  @override
  set plutoGridStateManager(value) => _plutoGridStateManager = value;

  final vendaDetalheScaffoldKey = GlobalKey<ScaffoldState>();
  final vendaDetalheFormKey = GlobalKey<FormState>();

  @override
  VendaDetalheModel createNewModel() => VendaDetalheModel();

  @override
  final standardFieldForFilter = VendaDetalheModel.aliasColumns[VendaDetalheModel.dbColumns.indexOf('quantidade')];

  final produtoModelController = TextEditingController();
  final quantidadeController = MoneyMaskedTextController();
  final valorUnitarioController = MoneyMaskedTextController();
  final valorSubtotalController = MoneyMaskedTextController();
  final taxaDescontoController = MoneyMaskedTextController();
  final valorDescontoController = MoneyMaskedTextController();
  final valorTotalController = MoneyMaskedTextController();

  final Map<String, dynamic> mobileConfig = {
    'primaryColumns': ['quantidade'],
    'secondaryColumns': ['valor_unitario'],
  };

  List<Map<String, dynamic>> get mobileItems {
    return modelList.map((vendaDetalhe) => vendaDetalhe.toJson).toList();
  }

  @override
  List<PlutoRow> plutoRows() => List<PlutoRow>.from(vendaDetalheModelList.map((model) => model.toPlutoRow()));

  @override
  Future<void> getList({Filter? filter}) async {}

  @override
  void prepareForInsert() {
    isNewRecord = true;
    vendaDetalheModel = createNewModel();
    _resetForm();
    Get.to(() => VendaDetalheEditPage());
  }

  void _resetForm() {
    formWasChangedDetail = false;
    produtoModelController.text = '';
    quantidadeController.updateValue(0);
    valorUnitarioController.updateValue(0);
    valorSubtotalController.updateValue(0);
    taxaDescontoController.updateValue(0);
    valorDescontoController.updateValue(0);
    valorTotalController.updateValue(0);
  }

  @override
  void selectRowForEditing(PlutoRow? row) async {
    if (row == null) {
      showInfoSnackBar(message: 'message_select_one_to_edited'.tr);
      return;
    }

    selectRowForEditingByTempId(row.cells['tempId']?.value);
  }

  @override
  void selectRowForEditingById(int id) {}

  void selectRowForEditingByTempId(String tempId) {
		isNewRecord = false;
    final model = vendaDetalheModelList.firstWhere((m) => m.tempId == tempId);
    vendaDetalheModel = model.clone();
		vendaDetalheModel.tempId = model.tempId;
    updateControllersFromModel();
    Get.to(() => VendaDetalheEditPage());
  }

  void updateControllersFromModel() {
    produtoModelController.text = vendaDetalheModel.produtoModel?.nome?.toString() ?? '';
    quantidadeController.updateValue(vendaDetalheModel.quantidade ?? 0);
    valorUnitarioController.updateValue(vendaDetalheModel.valorUnitario ?? 0);
    valorSubtotalController.updateValue(vendaDetalheModel.valorSubtotal ?? 0);
    taxaDescontoController.updateValue(vendaDetalheModel.taxaDesconto ?? 0);
    valorDescontoController.updateValue(vendaDetalheModel.valorDesconto ?? 0);
    valorTotalController.updateValue(vendaDetalheModel.valorTotal ?? 0);
    formWasChangedDetail = false;
  }

  @override
  Future<void> save() async {
    if (!vendaDetalheFormKey.currentState!.validate()) {
      showErrorSnackBar(message: 'validator_form_message'.tr);
      return;
    }

    if (formWasChangedDetail) {
      if (isNewRecord) {
        vendaDetalheModelList.insert(0, vendaDetalheModel.clone());
      } else {
        final index = vendaDetalheModelList.indexWhere((m) => m.tempId == vendaDetalheModel.tempId);
        if (index >= 0) {
          vendaDetalheModelList[index] = vendaDetalheModel.clone();
        }
      }

      userMadeChanges = true;
      loadData();
      Get.back(result: true);
    } else {
      Get.back();
    }
  }

  Future callProdutoLookup() async { 
		final lookupController = Get.find<LookupController>(); 
		lookupController.refreshItems(standardValue: '%'); 
		lookupController.title = '${'lookup_page_title'.tr} [Id Produto]'; 
		lookupController.route = '/produto/'; 
		lookupController.gridColumns = produtoGridColumns(isForLookup: true); 
		lookupController.aliasColumns = ProdutoModel.aliasColumns; 
		lookupController.dbColumns = ProdutoModel.dbColumns; 
		lookupController.standardColumn = ProdutoModel.aliasColumns[ProdutoModel.dbColumns.indexOf('nome')]; 

		final plutoRowResult = await Get.toNamed(Routes.lookupPage); 
		if (plutoRowResult != null) { 
			vendaDetalheModel.idProduto = plutoRowResult.cells['id']!.value; 
			vendaDetalheModel.produtoModel = ProdutoModel.fromPlutoRow(plutoRowResult); 
			produtoModelController.text = vendaDetalheModel.produtoModel?.nome ?? ''; 
			formWasChangedDetail = true; 
		}
	}


  @override
  Future deleteSelected() async {
    final currentRow = plutoGridStateManager.currentRow;
    if (currentRow == null) {
      showInfoSnackBar(message: 'message_select_one_to_delete'.tr);
      return null;
    }
    showDeleteDialog(() async {
      final id = currentRow.cells['id']?.value;
      final tempId = currentRow.cells['tempId']?.value;
      vendaDetalheModelList.removeWhere((model) => (id != 0 && model.id == id) || (id == 0 && model.tempId == tempId));
      plutoGridStateManager.removeCurrentRow();
      userMadeChanges = true;
    });
  }

  @override
  void preventDataLoss() {
    if (formWasChangedDetail) {
      showQuestionDialog('message_data_loss'.tr, () => Get.back());
    } else {
      formWasChangedDetail = false;
      Get.back();
    }
  }

  @override
  void onClose() {
    produtoModelController.dispose();
    quantidadeController.dispose();
    valorUnitarioController.dispose();
    valorSubtotalController.dispose();
    taxaDescontoController.dispose();
    valorDescontoController.dispose();
    valorTotalController.dispose();
  }

}