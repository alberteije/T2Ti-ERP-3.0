import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:loja_virtual/app/controller/controller_imports.dart';
import 'package:loja_virtual/app/data/model/model_imports.dart';
import 'package:loja_virtual/app/data/repository/produto_repository.dart';
import 'package:loja_virtual/app/data/repository/venda_cabecalho_repository.dart';
import 'package:loja_virtual/app/infra/infra_imports.dart';
import 'package:loja_virtual/app/page/shared_widget/shared_widget_imports.dart';
import 'package:loja_virtual/app/routes/app_routes.dart';

class CheckoutController extends GetxController {
  final CartController cartController = Get.find<CartController>();
  final VendaCabecalhoRepository vendaRepository;

  // Observables para os formulários
  var currentStep = 0.obs;
  var selectedPaymentMethod = 'credit_card'.obs;
  var isLoading = false.obs;

  // Controllers para formulário
  final cepController = TextEditingController();
  final streetController = TextEditingController();
  final numberController = TextEditingController();
  final complementController = TextEditingController();
  final neighborhoodController = TextEditingController();
  final cityController = TextEditingController();
  final stateController = TextEditingController();

  // Controllers para pagamento com cartão
  final cardNumberController = TextEditingController();
  final cardNameController = TextEditingController();
  final cardExpiryController = TextEditingController();
  final cardCvvController = TextEditingController();

  CheckoutController({required this.vendaRepository});

  // Métodos para controlar os passos
  void nextStep() {
    if (currentStep.value < 2) {
      currentStep.value++;
    }
  }

  void previousStep() {
    if (currentStep.value > 0) {
      currentStep.value--;
    }
  }

  void goToStep(int step) {
    currentStep.value = step;
  }

  // Validação dos formulários
  bool validateAddressStep() {
    // Implemente a validação conforme sua necessidade
    return streetController.text.isNotEmpty &&
          numberController.text.isNotEmpty &&
          cityController.text.isNotEmpty &&
          stateController.text.isNotEmpty;
  }

  bool validatePaymentStep() {
    if (selectedPaymentMethod.value == 'credit_card') {
      return cardNumberController.text.isNotEmpty &&
            cardNameController.text.isNotEmpty &&
            cardExpiryController.text.isNotEmpty &&
            cardCvvController.text.isNotEmpty;
    }
    return true; // PIX e Boleto não precisam de validação adicional
  }

  // Método principal para finalizar a compra
  Future<void> finalizeOrder() async {
    if (!validateAddressStep() || !validatePaymentStep()) {
      showErrorSnackBar(message: 'Preencha todos os campos obrigatórios');
      return;
    }

    if (cartController.items.isEmpty) {
      showErrorSnackBar(message: 'Carrinho vazio');
      return;
    }

    try {
      isLoading.value = true;

      // 1. Calcular totais
      final subtotal = cartController.subtotal;
      final taxaDesconto = cartController.discount.value > 0
          ? (cartController.discount.value / subtotal * 100)
          : 0.0;
      final valorDesconto = cartController.discount.value;
      final frete = cartController.deliveryFee.value;
      final total = cartController.total;

      // 2. Converter itens do carrinho para VendaDetalheModel
      final detalhesList = cartController.items.map((item) {
        return VendaDetalheModel(
          idProduto: item.productId,
          quantidade: item.quantity.toDouble(),
          valorUnitario: item.unitPrice,
          valorSubtotal: item.total,
          valorTotal: item.total,
        );
      }).toList();

      // 3. Criar o VendaCabecalhoModel COMPLETO
      final vendaCabecalho = VendaCabecalhoModel(
        // IDs das tabelas relacionadas (você precisa definir esses valores)
        idNotaFiscalTipo: 1, // Exemplo: 1 = NF-e
        idVendedor: 1, // ID do vendedor padrão ou do usuário logado
        idVendaCondicoesPagamento: _getIdCondicaoPagamento(), // Método auxiliar
        idTransportadora: null, // Se não tiver frete
        idCliente: Session.loggedInUser.id ?? 1, // ID do cliente logado

        // Endereços
        localEntrega: _formatarEnderecoEntrega(),
        localCobranca: _formatarEnderecoEntrega(), // Ou diferente se tiver

        // Frete e pagamento
        tipoFrete: frete > 0 ? 'C' : 'F', // C = CIF, F = FOB (ajuste conforme)
        formaPagamento: _getFormaPagamentoCode(),

        // Datas
        dataVenda: DateTime.now(),
        dataSaida: null, // Será preenchido quando enviar
        horaSaida: null,

        // Valores financeiros
        valorSubtotal: subtotal,
        taxaDesconto: taxaDesconto,
        valorDesconto: valorDesconto,
        valorFrete: frete,
        valorSeguro: 0.0, // Se não tiver seguro
        valorTotal: total,
        taxaComissao: 0.0, // Definir se houver comissão
        valorComissao: 0.0,

        // Status e informações
        situacao: 'A', // A = Aberto
        numeroFatura: _gerarNumeroFatura(), // Método para gerar número
        diaFixoParcela: null, // Se for parcelado
        observacao: 'Venda realizada via loja virtual',

        // LISTA DE DETALHES POPULADA
        vendaDetalheModelList: detalhesList,
      );

      // 4. Salvar no banco (o repositório deve salvar cabecalho + detalhes)
      final result = await vendaRepository.save(vendaCabecalhoModel: vendaCabecalho);

      if (result != null && result.id != null) {
        // 5. Atualizar estoque dos produtos (se necessário)
        await _atualizarEstoqueProdutos();

        // 6. Limpar o carrinho
        cartController.clearCartWithSuccess();

        // 7. recarrega itens
        try {
          final storeController = Get.find<StoreController>();
          await storeController.loadStoreProducts();
        } catch (e) {
          showErrorSnackBar(message: 'Erro ao recarregar produtos: $e');
        }

        // TODO: 8. Navegar para tela de sucesso
        Get.offAllNamed(
          Routes.homePage, 
          arguments: {
            'numeroPedido': result.id,
            'valorTotal': result.valorTotal,
            'data': result.dataVenda,
          }
        );

        showInfoSnackBar(message: 'Compra realizada com sucesso! Pedido #${result.id}');
      } else {
        showErrorSnackBar(message: 'Erro ao salvar a venda');
      }

    } catch (e) {
      showErrorSnackBar(message: 'Erro ao processar pedido: $e');
    } finally {
      isLoading.value = false;
    }
  }

String _getFormaPagamentoCode() {
  switch (selectedPaymentMethod.value) {
    case 'credit_card': return 'C'; // Cartão
    case 'pix': return 'P'; // PIX
    case 'boleto': return 'B'; // Boleto
    default: return 'D'; // Dinheiro
  }
}

int _getIdCondicaoPagamento() {
  // Retorna o ID da condição de pagamento baseado na seleção
  // TODO: Use a tabela já disponível no ERP
  switch (selectedPaymentMethod.value) {
    case 'credit_card': return 1; // Exemplo: Cartão à vista
    case 'pix': return 2; // PIX
    case 'boleto': return 3; // Boleto
    default: return 4; // Outro
  }
}

String _formatarEnderecoEntrega() {
  return '${streetController.text}, ${numberController.text}'
        '${complementController.text.isNotEmpty ? ', ${complementController.text}' : ''}'
        ' - ${neighborhoodController.text}'
        ' - ${cityController.text}/${stateController.text}'
        ' - CEP: ${cepController.text}';
}

int _gerarNumeroFatura() {
  // TODO: Gera um número sequencial para a fatura
  return DateTime.now().millisecondsSinceEpoch ~/ 1000;
}

Future<void> _atualizarEstoqueProdutos() async {
  // Atualizar estoque na tabela produto
  // Para cada item do carrinho, subtrair a quantidade vendida
  final produtoRepo = Get.find<ProdutoRepository>();

  for (final item in cartController.items) {
    try {
      // Buscar produto atual
      final produto = await produtoRepo.getObject(item.productId.toString());
      if (produto.quantidadeEstoque != null) {
        // Calcular novo estoque
        final novoEstoque = (produto.quantidadeEstoque ?? 0) - item.quantity;
        produto.quantidadeEstoque = novoEstoque;
        await produtoRepo.save(produtoModel: produto);
      }
    } catch (e) {
      showErrorSnackBar(message: 'Erro ao atualizar estoque do produto: $e');
    }
  }
}

  @override
  void onClose() {
    // Dispose dos controllers
    cepController.dispose();
    streetController.dispose();
    numberController.dispose();
    complementController.dispose();
    neighborhoodController.dispose();
    cityController.dispose();
    stateController.dispose();
    cardNumberController.dispose();
    cardNameController.dispose();
    cardExpiryController.dispose();
    cardCvvController.dispose();
    super.onClose();
  }
}