import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:pluto_grid/pluto_grid.dart';
import 'package:extended_masked_text/extended_masked_text.dart';
import 'package:loja_virtual/app/page/shared_widget/input/input_imports.dart';
import 'package:loja_virtual/app/routes/app_routes.dart';

import 'package:loja_virtual/app/page/page_imports.dart';
import 'package:loja_virtual/app/page/shared_widget/message_dialog.dart';
import 'package:loja_virtual/app/page/grid_columns/grid_columns_imports.dart';
import 'package:loja_virtual/app/controller/controller_imports.dart';
import 'package:loja_virtual/app/data/model/model_imports.dart';

class VendaFreteController extends ControllerBase<VendaFreteModel, void> {

  VendaFreteController() : super(repository: null) {
    dbColumns = VendaFreteModel.dbColumns;
    aliasColumns = VendaFreteModel.aliasColumns;
    gridColumns = vendaFreteGridColumns();
    functionName = "venda_frete";
    screenTitle = "Frete";
  }

  final _vendaFreteModel = VendaFreteModel().obs;
  VendaFreteModel get vendaFreteModel => _vendaFreteModel.value;
  set vendaFreteModel(value) => _vendaFreteModel.value = value ?? VendaFreteModel();

  List<VendaFreteModel> get vendaFreteModelList => Get.find<VendaCabecalhoController>().currentModel.vendaFreteModelList ?? [];

  final _userMadeChanges = false.obs;
  get userMadeChanges => _userMadeChanges.value;
  set userMadeChanges(value) => _userMadeChanges.value = value;

  final _formWasChangedDetail = false.obs;
  bool get formWasChangedDetail => _formWasChangedDetail.value;
  set formWasChangedDetail(value) => _formWasChangedDetail.value = value;

  late PlutoGridStateManager _plutoGridStateManager;
  @override
  PlutoGridStateManager get plutoGridStateManager => _plutoGridStateManager;
  @override
  set plutoGridStateManager(value) => _plutoGridStateManager = value;

  final vendaFreteScaffoldKey = GlobalKey<ScaffoldState>();
  final vendaFreteFormKey = GlobalKey<FormState>();

  @override
  VendaFreteModel createNewModel() => VendaFreteModel();

  @override
  final standardFieldForFilter = VendaFreteModel.aliasColumns[VendaFreteModel.dbColumns.indexOf('responsavel')];

  final viewPessoaTransportadoraModelController = TextEditingController();
  final responsavelController = CustomDropdownButtonController('1-Emitente');
  final conhecimentoController = MoneyMaskedTextController(precision: 0, decimalSeparator: '', thousandSeparator: '');
  final placaController = TextEditingController();
  final ufPlacaController = CustomDropdownButtonController('AC');
  final seloFiscalController = MoneyMaskedTextController(precision: 0, decimalSeparator: '', thousandSeparator: '');
  final quantidadeVolumeController = MoneyMaskedTextController();
  final marcaVolumeController = TextEditingController();
  final especieVolumeController = TextEditingController();
  final pesoBrutoController = MoneyMaskedTextController();
  final pesoLiquidoController = MoneyMaskedTextController();

  final Map<String, dynamic> mobileConfig = {
    'primaryColumns': ['responsavel'],
    'secondaryColumns': ['conhecimento'],
  };

  List<Map<String, dynamic>> get mobileItems {
    return modelList.map((vendaFrete) => vendaFrete.toJson).toList();
  }

  @override
  List<PlutoRow> plutoRows() => List<PlutoRow>.from(vendaFreteModelList.map((model) => model.toPlutoRow()));

  @override
  Future<void> getList({Filter? filter}) async {}

  @override
  void prepareForInsert() {
    isNewRecord = true;
    vendaFreteModel = createNewModel();
    _resetForm();
    Get.to(() => VendaFreteEditPage());
  }

  void _resetForm() {
    formWasChangedDetail = false;
    viewPessoaTransportadoraModelController.text = '';
    responsavelController.selected = '1-Emitente';
    conhecimentoController.updateValue(0);
    placaController.text = '';
    ufPlacaController.selected = 'AC';
    seloFiscalController.updateValue(0);
    quantidadeVolumeController.updateValue(0);
    marcaVolumeController.text = '';
    especieVolumeController.text = '';
    pesoBrutoController.updateValue(0);
    pesoLiquidoController.updateValue(0);
  }

  @override
  void selectRowForEditing(PlutoRow? row) async {
    if (row == null) {
      showInfoSnackBar(message: 'message_select_one_to_edited'.tr);
      return;
    }

    selectRowForEditingByTempId(row.cells['tempId']?.value);
  }

  @override
  void selectRowForEditingById(int id) {}

  void selectRowForEditingByTempId(String tempId) {
		isNewRecord = false;
    final model = vendaFreteModelList.firstWhere((m) => m.tempId == tempId);
    vendaFreteModel = model.clone();
		vendaFreteModel.tempId = model.tempId;
    updateControllersFromModel();
    Get.to(() => VendaFreteEditPage());
  }

  void updateControllersFromModel() {
    viewPessoaTransportadoraModelController.text = vendaFreteModel.viewPessoaTransportadoraModel?.nome?.toString() ?? '';
    responsavelController.selected = vendaFreteModel.responsavel ?? '1-Emitente';
    conhecimentoController.updateValue((vendaFreteModel.conhecimento ?? 0).toDouble());
    placaController.text = vendaFreteModel.placa ?? '';
    ufPlacaController.selected = vendaFreteModel.ufPlaca ?? 'AC';
    seloFiscalController.updateValue((vendaFreteModel.seloFiscal ?? 0).toDouble());
    quantidadeVolumeController.updateValue(vendaFreteModel.quantidadeVolume ?? 0);
    marcaVolumeController.text = vendaFreteModel.marcaVolume ?? '';
    especieVolumeController.text = vendaFreteModel.especieVolume ?? '';
    pesoBrutoController.updateValue(vendaFreteModel.pesoBruto ?? 0);
    pesoLiquidoController.updateValue(vendaFreteModel.pesoLiquido ?? 0);
    formWasChangedDetail = false;
  }

  @override
  Future<void> save() async {
    if (!vendaFreteFormKey.currentState!.validate()) {
      showErrorSnackBar(message: 'validator_form_message'.tr);
      return;
    }

    if (formWasChangedDetail) {
      if (isNewRecord) {
        vendaFreteModelList.insert(0, vendaFreteModel.clone());
      } else {
        final index = vendaFreteModelList.indexWhere((m) => m.tempId == vendaFreteModel.tempId);
        if (index >= 0) {
          vendaFreteModelList[index] = vendaFreteModel.clone();
        }
      }

      userMadeChanges = true;
      loadData();
      Get.back(result: true);
    } else {
      Get.back();
    }
  }

  Future callViewPessoaTransportadoraLookup() async { 
		final lookupController = Get.find<LookupController>(); 
		lookupController.refreshItems(standardValue: '%'); 
		lookupController.title = '${'lookup_page_title'.tr} [Transportadora]'; 
		lookupController.route = '/view-pessoa-transportadora/'; 
		lookupController.gridColumns = viewPessoaTransportadoraGridColumns(isForLookup: true); 
		lookupController.aliasColumns = ViewPessoaTransportadoraModel.aliasColumns; 
		lookupController.dbColumns = ViewPessoaTransportadoraModel.dbColumns; 
		lookupController.standardColumn = ViewPessoaTransportadoraModel.aliasColumns[ViewPessoaTransportadoraModel.dbColumns.indexOf('nome')]; 

		final plutoRowResult = await Get.toNamed(Routes.lookupPage); 
		if (plutoRowResult != null) { 
			vendaFreteModel.idTransportadora = plutoRowResult.cells['id']!.value; 
			vendaFreteModel.viewPessoaTransportadoraModel = ViewPessoaTransportadoraModel.fromPlutoRow(plutoRowResult); 
			viewPessoaTransportadoraModelController.text = vendaFreteModel.viewPessoaTransportadoraModel?.nome ?? ''; 
			formWasChangedDetail = true; 
		}
	}


  @override
  Future deleteSelected() async {
    final currentRow = plutoGridStateManager.currentRow;
    if (currentRow == null) {
      showInfoSnackBar(message: 'message_select_one_to_delete'.tr);
      return null;
    }
    showDeleteDialog(() async {
      final id = currentRow.cells['id']?.value;
      final tempId = currentRow.cells['tempId']?.value;
      vendaFreteModelList.removeWhere((model) => (id != 0 && model.id == id) || (id == 0 && model.tempId == tempId));
      plutoGridStateManager.removeCurrentRow();
      userMadeChanges = true;
    });
  }

  @override
  void preventDataLoss() {
    if (formWasChangedDetail) {
      showQuestionDialog('message_data_loss'.tr, () => Get.back());
    } else {
      formWasChangedDetail = false;
      Get.back();
    }
  }

  @override
  void onClose() {
    viewPessoaTransportadoraModelController.dispose();
    responsavelController.dispose();
    conhecimentoController.dispose();
    placaController.dispose();
    ufPlacaController.dispose();
    seloFiscalController.dispose();
    quantidadeVolumeController.dispose();
    marcaVolumeController.dispose();
    especieVolumeController.dispose();
    pesoBrutoController.dispose();
    pesoLiquidoController.dispose();
  }

}