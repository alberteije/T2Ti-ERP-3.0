import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:loja_virtual/app/page/shared_widget/input/input_imports.dart';

import 'package:loja_virtual/app/page/shared_widget/message_dialog.dart';
import 'package:loja_virtual/app/page/grid_columns/grid_columns_imports.dart';
import 'package:loja_virtual/app/routes/app_routes.dart';
import 'package:loja_virtual/app/controller/controller_imports.dart';
import 'package:loja_virtual/app/data/model/model_imports.dart';
import 'package:loja_virtual/app/data/repository/produto_unidade_repository.dart';

class ProdutoUnidadeController extends ControllerBase<ProdutoUnidadeModel, ProdutoUnidadeRepository> {

  ProdutoUnidadeController({required super.repository}) {
    dbColumns = ProdutoUnidadeModel.dbColumns;
    aliasColumns = ProdutoUnidadeModel.aliasColumns;
    gridColumns = produtoUnidadeGridColumns();
    functionName = "produto_unidade";
    screenTitle = "Unidade Produto";
  }

  @override
  ProdutoUnidadeModel createNewModel() => ProdutoUnidadeModel();

  @override
  final standardFieldForFilter = ProdutoUnidadeModel.aliasColumns[ProdutoUnidadeModel.dbColumns.indexOf('sigla')];

  final siglaController = TextEditingController();
  final podeFracionarController = CustomDropdownButtonController('Sim');
  final descricaoController = TextEditingController();

  final Map<String, dynamic> mobileConfig = {
    'primaryColumns': ['sigla'],
    'secondaryColumns': ['pode_fracionar'],
  };

  List<Map<String, dynamic>> get mobileItems {
    return modelList.map((produtoUnidade) => produtoUnidade.toJson).toList();
  }

  @override
  void prepareForInsert() {
    isNewRecord = true;
    currentModel = createNewModel();
    _resetForm();
    Get.toNamed(Routes.produtoUnidadeEditPage);
  }

  void _resetForm() {
    formWasChanged = false;
    siglaController.text = '';
    podeFracionarController.selected = 'Sim';
    descricaoController.text = '';
  }

  @override
  void selectRowForEditingById(int id) {
    final model = modelList.firstWhere((m) => m.id == id);
    currentModel = model.clone();
    updateControllersFromModel();
    Get.toNamed(Routes.produtoUnidadeEditPage);
  }

  void updateControllersFromModel() {
    siglaController.text = currentModel.sigla ?? '';
    podeFracionarController.selected = currentModel.podeFracionar ?? 'Sim';
    descricaoController.text = currentModel.descricao ?? '';
    formWasChanged = false;
  }

  @override
  Future<void> save() async {
    if (!formKey.currentState!.validate()) {
      showErrorSnackBar(message: 'validator_form_message'.tr);
      return;
    }

    final existingIndex = modelList.indexWhere((m) => m.id == currentModel.id);

    if (existingIndex >= 0) {
      modelList[existingIndex] = currentModel.clone();
    }

    final result = await repository.save(produtoUnidadeModel: currentModel);
    if (result == null) return;

    if (existingIndex >= 0) {
      modelList[existingIndex] = result;
    } else {
      modelList.insert(0, result);
    }

    if (!GetPlatform.isMobile) {
      updateGridRow(result);
    }

    Get.back(result: true);
  }


  @override
  void onClose() {
    siglaController.dispose();
    podeFracionarController.dispose();
    descricaoController.dispose();
    super.onClose();
  }

}