import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:loja_virtual/app/infra/infra_imports.dart';
import 'package:loja_virtual/app/routes/app_routes.dart';

class CartItem {
  final int productId;
  final String productName;
  final double unitPrice;
  final String? imagePath;
  int quantity;

  CartItem({
    required this.productId,
    required this.productName,
    required this.unitPrice,
    required this.quantity,
    this.imagePath,
  });

  double get total => unitPrice * quantity;
}

class CartController extends GetxController {
  var items = <CartItem>[].obs;

  // Getters observáveis
  int get totalItems => items.fold(0, (sum, item) => sum + item.quantity);
  double get subtotal => items.fold(0.0, (sum, item) => sum + item.total);
  
  // Taxas e descontos (pode ser dinâmico no futuro)
  final deliveryFee = 15.0.obs;
  final discount = 0.0.obs;
  
  double get total => subtotal + deliveryFee.value - discount.value;
  
  // Métodos do carrinho
  void addItem({
    required int productId,
    required String productName,
    required double unitPrice,
    int quantity = 1,
    String? imagePath,
  }) {
    final existingIndex = items.indexWhere((item) => item.productId == productId);

    if (existingIndex >= 0) {
      items[existingIndex].quantity += quantity;
      items.refresh();
      Get.snackbar(
        'Quantidade atualizada',
        '$productName: ${items[existingIndex].quantity} unidades',
        snackPosition: SnackPosition.bottom,
        duration: const Duration(seconds: 1),
      );
    } else {
      items.add(CartItem(
        productId: productId,
        productName: productName,
        unitPrice: unitPrice,
        quantity: quantity,
        imagePath: imagePath,
      ));
      Get.snackbar(
        'Adicionado ao carrinho',
        '$productName adicionado',
        snackPosition: SnackPosition.bottom,
      );
    }
  }

  void updateQuantity(int productId, int newQuantity) {
    if (newQuantity <= 0) {
      removeItem(productId);
      return;
    }

    final index = items.indexWhere((item) => item.productId == productId);
    if (index >= 0) {
      items[index].quantity = newQuantity;
      items.refresh();
    }
  }

  void removeItem(int productId) {
    final item = items.firstWhereOrNull((item) => item.productId == productId);
    if (item != null) {
      items.removeWhere((item) => item.productId == productId);
      Get.snackbar(
        'Removido',
        '${item.productName} removido do carrinho',
        snackPosition: SnackPosition.bottom,
      );
    }
  }

  void clearCart() {
    if (items.isNotEmpty) {
      Get.defaultDialog(
        title: 'Limpar carrinho',
        middleText: 'Deseja remover todos os itens do carrinho?',
        textConfirm: 'Sim',
        textCancel: 'Não',
        confirmTextColor: Colors.white,
        onConfirm: () {
          items.clear();
          Get.back();
          Get.snackbar('Carrinho limpo', 'Todos os itens foram removidos');
        },
      );
    }
  }

  // Simular pagamento (será integrado com gateway depois)
  Future<bool> processPayment() async {
    if (items.isEmpty) {
      Get.snackbar('Carrinho vazio', 'Adicione itens antes de finalizar');
      return false;
    }

    // Aqui você integrará com sua API de pagamento
    // Por enquanto, simula um processamento

    Get.dialog(
      const Center(child: CircularProgressIndicator()),
      barrierDismissible: false,
    );

    await Future.delayed(const Duration(seconds: 2)); // Simula processamento

    Get.back(); // Fecha o loading

    return true; // Simula sucesso
  }

  void proceedToCheckout() {
    // Verifica se usuário está logado
    if (Session.loggedInUser.id == null) {
      Get.toNamed(Routes.loginPage);
      Get.snackbar(
        'Login necessário',
        'Faça login para finalizar a compra',
        snackPosition: SnackPosition.bottom,
      );
      return;
    }

    // Navega para checkout
    Get.toNamed(Routes.checkoutPage);
  }

  void clearCartWithSuccess() {
    items.clear();
  }
}