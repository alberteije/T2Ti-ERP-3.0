import 'package:flutter/material.dart';
import 'dart:math';
import 'package:get/get.dart';
import 'package:extended_masked_text/extended_masked_text.dart';
import 'package:loja_virtual/app/page/shared_widget/input/input_imports.dart';

import 'package:loja_virtual/app/infra/infra_imports.dart';
import 'package:loja_virtual/app/page/page_imports.dart';
import 'package:loja_virtual/app/page/shared_widget/message_dialog.dart';
import 'package:loja_virtual/app/page/grid_columns/grid_columns_imports.dart';
import 'package:loja_virtual/app/routes/app_routes.dart';
import 'package:loja_virtual/app/controller/controller_imports.dart';
import 'package:loja_virtual/app/data/model/model_imports.dart';
import 'package:loja_virtual/app/data/repository/produto_repository.dart';

class ProdutoController extends ControllerBase<ProdutoModel, ProdutoRepository> 
with GetSingleTickerProviderStateMixin {

  ProdutoController({required super.repository}) {
    dbColumns = ProdutoModel.dbColumns;
    aliasColumns = ProdutoModel.aliasColumns;
    gridColumns = produtoGridColumns();
    functionName = "produto";
    screenTitle = "Produto";
  }

  final produtoScaffoldKey = GlobalKey<ScaffoldState>();
  final produtoTabPageScaffoldKey = GlobalKey<ScaffoldState>();
  final produtoFormKey = GlobalKey<FormState>();
  late TabController tabController;
  String? mandatoryMessage;  

  @override
  ProdutoModel createNewModel() => ProdutoModel();

  @override
  final standardFieldForFilter = ProdutoModel.aliasColumns[ProdutoModel.dbColumns.indexOf('tipo_item')];

  final produtoSubgrupoModelController = TextEditingController();
  final produtoMarcaModelController = TextEditingController();
  final produtoUnidadeModelController = TextEditingController();
  final tipoItemController = CustomDropdownButtonController('Produto');
  final nomeController = TextEditingController();
  final descricaoController = TextEditingController();
  final gtinController = TextEditingController();
  final codigoInternoController = TextEditingController();
  final valorCompraController = MoneyMaskedTextController();
  final valorVendaController = MoneyMaskedTextController();
  final codigoNcmController = TextEditingController();
  final codigoNbsController = TextEditingController();
  final codigoCestController = TextEditingController();
  final dataCadastroController = DatePickerItemController(null);
  final quantidadeEstoqueController = MoneyMaskedTextController();
  final estoqueMinimoController = MoneyMaskedTextController();
  final estoqueMaximoController = MoneyMaskedTextController();
  final estoqueIdealController = MoneyMaskedTextController();
  final pesavelController = CustomDropdownButtonController('Sim');
  final pesoController = MoneyMaskedTextController();
  final markupController = MoneyMaskedTextController();
  final precoSugeridoController = MoneyMaskedTextController();
  final precoVendaMinimoController = MoneyMaskedTextController();
  final custoPercentualController = MoneyMaskedTextController();
  final custoUnitarioController = MoneyMaskedTextController();
  final custoProducaoController = MoneyMaskedTextController();
  final custoMedioLiquidoController = MoneyMaskedTextController();
  final precoLucroZeroController = MoneyMaskedTextController();
  final precoLucroMinimoController = MoneyMaskedTextController();
  final precoLucroMaximoController = MoneyMaskedTextController();
  final margemLucroController = MoneyMaskedTextController();
  final codigoBalancaController = MoneyMaskedTextController(precision: 0, decimalSeparator: '', thousandSeparator: '');
  final classeAbcController = CustomDropdownButtonController('A');
  final ativoController = CustomDropdownButtonController('Sim');
  final informacoesAdicionaisNfeController = TextEditingController();

  final Map<String, dynamic> mobileConfig = {
    'primaryColumns': ['tipo_item'],
    'secondaryColumns': ['nome'],
  };

  List<Map<String, dynamic>> get mobileItems {
    return modelList.map((produto) => produto.toJson).toList();
  }

  @override
  void prepareForInsert() {
    isNewRecord = true;
    currentModel = createNewModel();
    _resetForm();
    tabController.animateTo(0);
    updateControllersFromModel();
    Get.toNamed(Routes.produtoTabPage);
  }

  void _resetForm() {
    formWasChanged = false;
    produtoSubgrupoModelController.text = '';
    produtoMarcaModelController.text = '';
    produtoUnidadeModelController.text = '';
    tipoItemController.selected = 'Produto';
    nomeController.text = '';
    descricaoController.text = '';
    gtinController.text = '';
    codigoInternoController.text = '';
    valorCompraController.updateValue(0);
    valorVendaController.updateValue(0);
    codigoNcmController.text = '';
    codigoNbsController.text = '';
    codigoCestController.text = '';
    dataCadastroController.date = null;
    quantidadeEstoqueController.updateValue(0);
    estoqueMinimoController.updateValue(0);
    estoqueMaximoController.updateValue(0);
    estoqueIdealController.updateValue(0);
    pesavelController.selected = 'Sim';
    pesoController.updateValue(0);
    markupController.updateValue(0);
    precoSugeridoController.updateValue(0);
    precoVendaMinimoController.updateValue(0);
    custoPercentualController.updateValue(0);
    custoUnitarioController.updateValue(0);
    custoProducaoController.updateValue(0);
    custoMedioLiquidoController.updateValue(0);
    precoLucroZeroController.updateValue(0);
    precoLucroMinimoController.updateValue(0);
    precoLucroMaximoController.updateValue(0);
    margemLucroController.updateValue(0);
    codigoBalancaController.updateValue(0);
    classeAbcController.selected = 'A';
    ativoController.selected = 'Sim';
    informacoesAdicionaisNfeController.text = '';
  }

  @override
  void selectRowForEditingById(int id) {
    final model = modelList.firstWhere((m) => m.id == id);
    currentModel = model.clone();
    updateControllersFromModel();
    tabController.animateTo(0);
    Get.toNamed(Routes.produtoTabPage);
  }

  _configureChildrenControllers() {
    //Ficha Técnica
		Get.put<ProdutoFichaTecnicaController>(ProdutoFichaTecnicaController()); 

    //Promoções
		Get.put<ProdutoPromocaoController>(ProdutoPromocaoController()); 

  }
	
	_releaseChildrenControllers() {
    //Ficha Técnica
		Get.delete<ProdutoFichaTecnicaController>(); 

    //Promoções
		Get.delete<ProdutoPromocaoController>(); 

	}
  
  void updateControllersFromModel() {
    produtoSubgrupoModelController.text = currentModel.produtoSubgrupoModel?.nome?.toString() ?? '';
    produtoMarcaModelController.text = currentModel.produtoMarcaModel?.nome?.toString() ?? '';
    produtoUnidadeModelController.text = currentModel.produtoUnidadeModel?.sigla?.toString() ?? '';
    tipoItemController.selected = currentModel.tipoItem ?? 'Produto';
    nomeController.text = currentModel.nome ?? '';
    descricaoController.text = currentModel.descricao ?? '';
    gtinController.text = currentModel.gtin ?? '';
    codigoInternoController.text = currentModel.codigoInterno ?? '';
    valorCompraController.updateValue(currentModel.valorCompra ?? 0);
    valorVendaController.updateValue(currentModel.valorVenda ?? 0);
    codigoNcmController.text = currentModel.codigoNcm ?? '';
    codigoNbsController.text = currentModel.codigoNbs ?? '';
    codigoCestController.text = currentModel.codigoCest ?? '';
    dataCadastroController.date = currentModel.dataCadastro;
    quantidadeEstoqueController.updateValue(currentModel.quantidadeEstoque ?? 0);
    estoqueMinimoController.updateValue(currentModel.estoqueMinimo ?? 0);
    estoqueMaximoController.updateValue(currentModel.estoqueMaximo ?? 0);
    estoqueIdealController.updateValue(currentModel.estoqueIdeal ?? 0);
    pesavelController.selected = currentModel.pesavel ?? 'Sim';
    pesoController.updateValue(currentModel.peso ?? 0);
    markupController.updateValue(currentModel.markup ?? 0);
    precoSugeridoController.updateValue(currentModel.precoSugerido ?? 0);
    precoVendaMinimoController.updateValue(currentModel.precoVendaMinimo ?? 0);
    custoPercentualController.updateValue(currentModel.custoPercentual ?? 0);
    custoUnitarioController.updateValue(currentModel.custoUnitario ?? 0);
    custoProducaoController.updateValue(currentModel.custoProducao ?? 0);
    custoMedioLiquidoController.updateValue(currentModel.custoMedioLiquido ?? 0);
    precoLucroZeroController.updateValue(currentModel.precoLucroZero ?? 0);
    precoLucroMinimoController.updateValue(currentModel.precoLucroMinimo ?? 0);
    precoLucroMaximoController.updateValue(currentModel.precoLucroMaximo ?? 0);
    margemLucroController.updateValue(currentModel.margemLucro ?? 0);
    codigoBalancaController.updateValue((currentModel.codigoBalanca ?? 0).toDouble());
    classeAbcController.selected = currentModel.classeAbc ?? 'A';
    ativoController.selected = currentModel.ativo ?? 'Sim';
    informacoesAdicionaisNfeController.text = currentModel.informacoesAdicionaisNfe ?? '';

    formWasChanged = false;
    _updateChildrenControllersFromModel();
  }

  void _updateChildrenControllersFromModel() {
    //Ficha Técnica
		final produtoFichaTecnicaController = Get.find<ProdutoFichaTecnicaController>(); 
		produtoFichaTecnicaController.userMadeChanges = false; 

    //Promoções
		final produtoPromocaoController = Get.find<ProdutoPromocaoController>(); 
		produtoPromocaoController.userMadeChanges = false; 

  }

  @override
  Future<void> save() async {
    if (!validateCurrentForm()) return;
    if (validateForms()) {
      if (userMadeChanges()) {
        final existingIndex = modelList.indexWhere((m) => m.id == currentModel.id);

        if (existingIndex >= 0) {
          modelList[existingIndex] = currentModel.clone();
        }

        final result = await repository.save(produtoModel: currentModel);
        if (result == null) return;

        if (existingIndex >= 0) {
          modelList[existingIndex] = result;
        } else {
          modelList.insert(0, result);
        }

        if (!GetPlatform.isMobile) {
          updateGridRow(result);
        }

        Get.back(result: true);
      } else {
        Get.back();
      }
    } 
  }

  Future callProdutoSubgrupoLookup() async { 
		final lookupController = Get.find<LookupController>(); 
		lookupController.refreshItems(standardValue: '%'); 
		lookupController.title = '${'lookup_page_title'.tr} [Subgrupo]'; 
		lookupController.route = '/produto-subgrupo/'; 
		lookupController.gridColumns = produtoSubgrupoGridColumns(isForLookup: true); 
		lookupController.aliasColumns = ProdutoSubgrupoModel.aliasColumns; 
		lookupController.dbColumns = ProdutoSubgrupoModel.dbColumns; 
		lookupController.standardColumn = ProdutoSubgrupoModel.aliasColumns[ProdutoSubgrupoModel.dbColumns.indexOf('nome')]; 

		final plutoRowResult = await Get.toNamed(Routes.lookupPage); 
		if (plutoRowResult != null) { 
			currentModel.idProdutoSubgrupo = plutoRowResult.cells['id']!.value; 
			currentModel.produtoSubgrupoModel = ProdutoSubgrupoModel.fromPlutoRow(plutoRowResult); 
			produtoSubgrupoModelController.text = currentModel.produtoSubgrupoModel?.nome ?? ''; 
			formWasChanged = true; 
		}
	}

  Future callProdutoMarcaLookup() async { 
		final lookupController = Get.find<LookupController>(); 
		lookupController.refreshItems(standardValue: '%'); 
		lookupController.title = '${'lookup_page_title'.tr} [Marca]'; 
		lookupController.route = '/produto-marca/'; 
		lookupController.gridColumns = produtoMarcaGridColumns(isForLookup: true); 
		lookupController.aliasColumns = ProdutoMarcaModel.aliasColumns; 
		lookupController.dbColumns = ProdutoMarcaModel.dbColumns; 
		lookupController.standardColumn = ProdutoMarcaModel.aliasColumns[ProdutoMarcaModel.dbColumns.indexOf('nome')]; 

		final plutoRowResult = await Get.toNamed(Routes.lookupPage); 
		if (plutoRowResult != null) { 
			currentModel.idProdutoMarca = plutoRowResult.cells['id']!.value; 
			currentModel.produtoMarcaModel = ProdutoMarcaModel.fromPlutoRow(plutoRowResult); 
			produtoMarcaModelController.text = currentModel.produtoMarcaModel?.nome ?? ''; 
			formWasChanged = true; 
		}
	}

  Future callProdutoUnidadeLookup() async { 
		final lookupController = Get.find<LookupController>(); 
		lookupController.refreshItems(standardValue: '%'); 
		lookupController.title = '${'lookup_page_title'.tr} [Unidade]'; 
		lookupController.route = '/produto-unidade/'; 
		lookupController.gridColumns = produtoUnidadeGridColumns(isForLookup: true); 
		lookupController.aliasColumns = ProdutoUnidadeModel.aliasColumns; 
		lookupController.dbColumns = ProdutoUnidadeModel.dbColumns; 
		lookupController.standardColumn = ProdutoUnidadeModel.aliasColumns[ProdutoUnidadeModel.dbColumns.indexOf('sigla')]; 

		final plutoRowResult = await Get.toNamed(Routes.lookupPage); 
		if (plutoRowResult != null) { 
			currentModel.idProdutoUnidade = plutoRowResult.cells['id']!.value; 
			currentModel.produtoUnidadeModel = ProdutoUnidadeModel.fromPlutoRow(plutoRowResult); 
			produtoUnidadeModelController.text = currentModel.produtoUnidadeModel?.sigla ?? ''; 
			formWasChanged = true; 
		}
	}


  List<Tab> tabItems = [
    Tab( 
			icon: Icon(iconDataList[Random().nextInt(10)]), 
			text: 'Produto', 
		),
    Tab( 
			icon: Icon(iconDataList[Random().nextInt(10)]), 
			text: 'Ficha Técnica', 
		),
    Tab( 
			icon: Icon(iconDataList[Random().nextInt(10)]), 
			text: 'Promoções', 
		),
  ];

  List<Widget> tabPages() {
    return [
      ProdutoEditPage(),
      const ProdutoFichaTecnicaListPage(),
      const ProdutoPromocaoListPage(),
    ];
  }

  @override
  void preventDataLoss() {
    if (userMadeChanges()) {
      showQuestionDialog('message_data_loss'.tr, () { 
        Get.back(); 
      });
    } else {
      Get.back();
    }
  }  

  bool userMadeChanges() {
    return
    formWasChanged 
    || 
		Get.find<ProdutoFichaTecnicaController>().userMadeChanges
    || 
		Get.find<ProdutoPromocaoController>().userMadeChanges
    ;
  }

  void tabChange(int index) {
    validateCurrentForm();
  }

  bool validateCurrentForm() {
    mandatoryMessage = ValidateFormField.validateMandatory(currentModel.produtoSubgrupoModel?.nome); 
		if (mandatoryMessage != null) { 
			tabController.animateTo(0); 
			showErrorSnackBar(message: '$mandatoryMessage [Subgrupo]'); 
			return false; 
		}
    mandatoryMessage = ValidateFormField.validateMandatory(currentModel.produtoMarcaModel?.nome); 
		if (mandatoryMessage != null) { 
			tabController.animateTo(0); 
			showErrorSnackBar(message: '$mandatoryMessage [Marca]'); 
			return false; 
		}
    mandatoryMessage = ValidateFormField.validateMandatory(currentModel.produtoUnidadeModel?.sigla); 
		if (mandatoryMessage != null) { 
			tabController.animateTo(0); 
			showErrorSnackBar(message: '$mandatoryMessage [Unidade]'); 
			return false; 
		}
    mandatoryMessage = ValidateFormField.validateMandatory(currentModel.nome); 
		if (mandatoryMessage != null) { 
			tabController.animateTo(0); 
			showErrorSnackBar(message: '$mandatoryMessage [Nome]'); 
			return false; 
		}
    return true;
  }

  bool validateForms() {
    return true;
  }

  @override
  void onInit() {
    super.onInit();
    tabController = TabController(vsync: this, length: tabItems.length);
    _configureChildrenControllers();
  }
	
  @override
  void onClose() {
    tabController.dispose();
    produtoSubgrupoModelController.dispose();
    produtoMarcaModelController.dispose();
    produtoUnidadeModelController.dispose();
    tipoItemController.dispose();
    nomeController.dispose();
    descricaoController.dispose();
    gtinController.dispose();
    codigoInternoController.dispose();
    valorCompraController.dispose();
    valorVendaController.dispose();
    codigoNcmController.dispose();
    codigoNbsController.dispose();
    codigoCestController.dispose();
    dataCadastroController.dispose();
    quantidadeEstoqueController.dispose();
    estoqueMinimoController.dispose();
    estoqueMaximoController.dispose();
    estoqueIdealController.dispose();
    pesavelController.dispose();
    pesoController.dispose();
    markupController.dispose();
    precoSugeridoController.dispose();
    precoVendaMinimoController.dispose();
    custoPercentualController.dispose();
    custoUnitarioController.dispose();
    custoProducaoController.dispose();
    custoMedioLiquidoController.dispose();
    precoLucroZeroController.dispose();
    precoLucroMinimoController.dispose();
    precoLucroMaximoController.dispose();
    margemLucroController.dispose();
    codigoBalancaController.dispose();
    classeAbcController.dispose();
    ativoController.dispose();
    informacoesAdicionaisNfeController.dispose();
    _releaseChildrenControllers();
    super.onClose();
  }	
}