import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:pluto_grid/pluto_grid.dart';
import 'package:extended_masked_text/extended_masked_text.dart';
import 'package:loja_virtual/app/page/shared_widget/input/input_imports.dart';

import 'package:loja_virtual/app/page/page_imports.dart';
import 'package:loja_virtual/app/page/shared_widget/message_dialog.dart';
import 'package:loja_virtual/app/page/grid_columns/grid_columns_imports.dart';
import 'package:loja_virtual/app/controller/controller_imports.dart';
import 'package:loja_virtual/app/data/model/model_imports.dart';

class ProdutoPromocaoController extends ControllerBase<ProdutoPromocaoModel, void> {

  ProdutoPromocaoController() : super(repository: null) {
    dbColumns = ProdutoPromocaoModel.dbColumns;
    aliasColumns = ProdutoPromocaoModel.aliasColumns;
    gridColumns = produtoPromocaoGridColumns();
    functionName = "produto_promocao";
    screenTitle = "Promoções";
  }

  final _produtoPromocaoModel = ProdutoPromocaoModel().obs;
  ProdutoPromocaoModel get produtoPromocaoModel => _produtoPromocaoModel.value;
  set produtoPromocaoModel(value) => _produtoPromocaoModel.value = value ?? ProdutoPromocaoModel();

  List<ProdutoPromocaoModel> get produtoPromocaoModelList => Get.find<ProdutoController>().currentModel.produtoPromocaoModelList ?? [];

  final _userMadeChanges = false.obs;
  get userMadeChanges => _userMadeChanges.value;
  set userMadeChanges(value) => _userMadeChanges.value = value;

  final _formWasChangedDetail = false.obs;
  bool get formWasChangedDetail => _formWasChangedDetail.value;
  set formWasChangedDetail(value) => _formWasChangedDetail.value = value;

  late PlutoGridStateManager _plutoGridStateManager;
  @override
  PlutoGridStateManager get plutoGridStateManager => _plutoGridStateManager;
  @override
  set plutoGridStateManager(value) => _plutoGridStateManager = value;

  final produtoPromocaoScaffoldKey = GlobalKey<ScaffoldState>();
  final produtoPromocaoFormKey = GlobalKey<FormState>();

  @override
  ProdutoPromocaoModel createNewModel() => ProdutoPromocaoModel();

  @override
  final standardFieldForFilter = ProdutoPromocaoModel.aliasColumns[ProdutoPromocaoModel.dbColumns.indexOf('data_inicio')];

  final dataInicioController = DatePickerItemController(null);
  final dataFimController = DatePickerItemController(null);
  final quantidadeEmPromocaoController = MoneyMaskedTextController();
  final quantidadeMaximaClienteController = MoneyMaskedTextController();
  final valorController = MoneyMaskedTextController();

  final Map<String, dynamic> mobileConfig = {
    'primaryColumns': ['data_inicio'],
    'secondaryColumns': ['data_fim'],
  };

  List<Map<String, dynamic>> get mobileItems {
    return modelList.map((produtoPromocao) => produtoPromocao.toJson).toList();
  }

  @override
  List<PlutoRow> plutoRows() => List<PlutoRow>.from(produtoPromocaoModelList.map((model) => model.toPlutoRow()));

  @override
  Future<void> getList({Filter? filter}) async {}

  @override
  void prepareForInsert() {
    isNewRecord = true;
    produtoPromocaoModel = createNewModel();
    _resetForm();
    Get.to(() => ProdutoPromocaoEditPage());
  }

  void _resetForm() {
    formWasChangedDetail = false;
    dataInicioController.date = null;
    dataFimController.date = null;
    quantidadeEmPromocaoController.updateValue(0);
    quantidadeMaximaClienteController.updateValue(0);
    valorController.updateValue(0);
  }

  @override
  void selectRowForEditing(PlutoRow? row) async {
    if (row == null) {
      showInfoSnackBar(message: 'message_select_one_to_edited'.tr);
      return;
    }

    selectRowForEditingByTempId(row.cells['tempId']?.value);
  }

  @override
  void selectRowForEditingById(int id) {}

  void selectRowForEditingByTempId(String tempId) {
		isNewRecord = false;
    final model = produtoPromocaoModelList.firstWhere((m) => m.tempId == tempId);
    produtoPromocaoModel = model.clone();
		produtoPromocaoModel.tempId = model.tempId;
    updateControllersFromModel();
    Get.to(() => ProdutoPromocaoEditPage());
  }

  void updateControllersFromModel() {
    dataInicioController.date = produtoPromocaoModel.dataInicio;
    dataFimController.date = produtoPromocaoModel.dataFim;
    quantidadeEmPromocaoController.updateValue(produtoPromocaoModel.quantidadeEmPromocao ?? 0);
    quantidadeMaximaClienteController.updateValue(produtoPromocaoModel.quantidadeMaximaCliente ?? 0);
    valorController.updateValue(produtoPromocaoModel.valor ?? 0);
    formWasChangedDetail = false;
  }

  @override
  Future<void> save() async {
    if (!produtoPromocaoFormKey.currentState!.validate()) {
      showErrorSnackBar(message: 'validator_form_message'.tr);
      return;
    }

    if (formWasChangedDetail) {
      if (isNewRecord) {
        produtoPromocaoModelList.insert(0, produtoPromocaoModel.clone());
      } else {
        final index = produtoPromocaoModelList.indexWhere((m) => m.tempId == produtoPromocaoModel.tempId);
        if (index >= 0) {
          produtoPromocaoModelList[index] = produtoPromocaoModel.clone();
        }
      }

      userMadeChanges = true;
      loadData();
      Get.back(result: true);
    } else {
      Get.back();
    }
  }


  @override
  Future deleteSelected() async {
    final currentRow = plutoGridStateManager.currentRow;
    if (currentRow == null) {
      showInfoSnackBar(message: 'message_select_one_to_delete'.tr);
      return null;
    }
    showDeleteDialog(() async {
      final id = currentRow.cells['id']?.value;
      final tempId = currentRow.cells['tempId']?.value;
      produtoPromocaoModelList.removeWhere((model) => (id != 0 && model.id == id) || (id == 0 && model.tempId == tempId));
      plutoGridStateManager.removeCurrentRow();
      userMadeChanges = true;
    });
  }

  @override
  void preventDataLoss() {
    if (formWasChangedDetail) {
      showQuestionDialog('message_data_loss'.tr, () => Get.back());
    } else {
      formWasChangedDetail = false;
      Get.back();
    }
  }

  @override
  void onClose() {
    dataInicioController.dispose();
    dataFimController.dispose();
    quantidadeEmPromocaoController.dispose();
    quantidadeMaximaClienteController.dispose();
    valorController.dispose();
  }

}