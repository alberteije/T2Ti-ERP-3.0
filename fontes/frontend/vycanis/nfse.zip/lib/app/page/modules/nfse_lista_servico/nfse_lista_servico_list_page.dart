import 'package:flutter/material.dart';
import 'package:nfse/app/controller/nfse_lista_servico_controller.dart';
import 'package:nfse/app/page/shared_page/list_page_base.dart';

class NfseListaServicoListPage extends ListPageBase<NfseListaServicoController> {
  const NfseListaServicoListPage({Key? key}) : super(key: key);

  @override
  List<Map<String, dynamic>> get mobileItems => controller.mobileItems;

  @override
  Map<String, dynamic> get mobileConfig => controller.mobileConfig;

  @override
  String get standardFieldForFilter => controller.standardFieldForFilter;
}