import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:pluto_grid/pluto_grid.dart';
import 'package:extended_masked_text/extended_masked_text.dart';
import 'package:nfse/app/page/shared_widget/input/input_imports.dart';
import 'package:nfse/app/routes/app_routes.dart';

import 'package:nfse/app/page/page_imports.dart';
import 'package:nfse/app/page/shared_widget/message_dialog.dart';
import 'package:nfse/app/page/grid_columns/grid_columns_imports.dart';
import 'package:nfse/app/controller/controller_imports.dart';
import 'package:nfse/app/data/model/model_imports.dart';

class NfseDetalheController extends ControllerBase<NfseDetalheModel, void> {

  NfseDetalheController() : super(repository: null) {
    dbColumns = NfseDetalheModel.dbColumns;
    aliasColumns = NfseDetalheModel.aliasColumns;
    gridColumns = nfseDetalheGridColumns();
    functionName = "nfse_detalhe";
    screenTitle = "Itens da NFS-e";
  }

  final _nfseDetalheModel = NfseDetalheModel().obs;
  NfseDetalheModel get nfseDetalheModel => _nfseDetalheModel.value;
  set nfseDetalheModel(value) => _nfseDetalheModel.value = value ?? NfseDetalheModel();

  List<NfseDetalheModel> get nfseDetalheModelList => Get.find<NfseCabecalhoController>().currentModel.nfseDetalheModelList ?? [];

  final _userMadeChanges = false.obs;
  get userMadeChanges => _userMadeChanges.value;
  set userMadeChanges(value) => _userMadeChanges.value = value;

  final _formWasChangedDetail = false.obs;
  bool get formWasChangedDetail => _formWasChangedDetail.value;
  set formWasChangedDetail(value) => _formWasChangedDetail.value = value;

  late PlutoGridStateManager _plutoGridStateManager;
  @override
  PlutoGridStateManager get plutoGridStateManager => _plutoGridStateManager;
  @override
  set plutoGridStateManager(value) => _plutoGridStateManager = value;

  final nfseDetalheScaffoldKey = GlobalKey<ScaffoldState>();
  final nfseDetalheFormKey = GlobalKey<FormState>();

  @override
  NfseDetalheModel createNewModel() => NfseDetalheModel();

  @override
  final standardFieldForFilter = NfseDetalheModel.aliasColumns[NfseDetalheModel.dbColumns.indexOf('codigo_cnae')];

  final nfseListaServicoModelController = TextEditingController();
  final codigoCnaeController = TextEditingController();
  final codigoTributacaoMunicipioController = TextEditingController();
  final valorServicosController = MoneyMaskedTextController();
  final valorDeducoesController = MoneyMaskedTextController();
  final valorPisController = MoneyMaskedTextController();
  final valorCofinsController = MoneyMaskedTextController();
  final valorInssController = MoneyMaskedTextController();
  final valorIrController = MoneyMaskedTextController();
  final valorCsllController = MoneyMaskedTextController();
  final valorBaseCalculoController = MoneyMaskedTextController();
  final aliquotaController = MoneyMaskedTextController();
  final valorIssController = MoneyMaskedTextController();
  final valorLiquidoController = MoneyMaskedTextController();
  final outrasRetencoesController = MoneyMaskedTextController();
  final valorCreditoController = MoneyMaskedTextController();
  final issRetidoController = CustomDropdownButtonController('S');
  final valorIssRetidoController = MoneyMaskedTextController();
  final valorDescontoCondicionadoController = MoneyMaskedTextController();
  final valorDescontoIncondicionadoController = MoneyMaskedTextController();
  final municipioPrestacaoController = MoneyMaskedTextController(precision: 0, decimalSeparator: '', thousandSeparator: '');
  final discriminacaoController = TextEditingController();

  final Map<String, dynamic> mobileConfig = {
    'primaryColumns': ['codigo_cnae'],
    'secondaryColumns': ['codigo_tributacao_municipio'],
  };

  List<Map<String, dynamic>> get mobileItems {
    return modelList.map((nfseDetalhe) => nfseDetalhe.toJson).toList();
  }

  @override
  List<PlutoRow> plutoRows() => List<PlutoRow>.from(nfseDetalheModelList.map((model) => model.toPlutoRow()));

  @override
  Future<void> getList({Filter? filter}) async {}

  @override
  void prepareForInsert() {
    isNewRecord = true;
    nfseDetalheModel = createNewModel();
    _resetForm();
    Get.to(() => NfseDetalheEditPage());
  }

  void _resetForm() {
    formWasChangedDetail = false;
    nfseListaServicoModelController.text = '';
    codigoCnaeController.text = '';
    codigoTributacaoMunicipioController.text = '';
    valorServicosController.updateValue(0);
    valorDeducoesController.updateValue(0);
    valorPisController.updateValue(0);
    valorCofinsController.updateValue(0);
    valorInssController.updateValue(0);
    valorIrController.updateValue(0);
    valorCsllController.updateValue(0);
    valorBaseCalculoController.updateValue(0);
    aliquotaController.updateValue(0);
    valorIssController.updateValue(0);
    valorLiquidoController.updateValue(0);
    outrasRetencoesController.updateValue(0);
    valorCreditoController.updateValue(0);
    issRetidoController.selected = 'S';
    valorIssRetidoController.updateValue(0);
    valorDescontoCondicionadoController.updateValue(0);
    valorDescontoIncondicionadoController.updateValue(0);
    municipioPrestacaoController.updateValue(0);
    discriminacaoController.text = '';
  }

  @override
  void selectRowForEditing(PlutoRow? row) async {
    if (row == null) {
      showInfoSnackBar(message: 'message_select_one_to_edited'.tr);
      return;
    }

    selectRowForEditingByTempId(row.cells['tempId']?.value);
  }

  @override
  void selectRowForEditingById(int id) {}

  void selectRowForEditingByTempId(String tempId) {
		isNewRecord = false;
    final model = nfseDetalheModelList.firstWhere((m) => m.tempId == tempId);
    nfseDetalheModel = model.clone();
		nfseDetalheModel.tempId = model.tempId;
    updateControllersFromModel();
    Get.to(() => NfseDetalheEditPage());
  }

  void updateControllersFromModel() {
    nfseListaServicoModelController.text = nfseDetalheModel.nfseListaServicoModel?.descricao?.toString() ?? '';
    codigoCnaeController.text = nfseDetalheModel.codigoCnae ?? '';
    codigoTributacaoMunicipioController.text = nfseDetalheModel.codigoTributacaoMunicipio ?? '';
    valorServicosController.updateValue(nfseDetalheModel.valorServicos ?? 0);
    valorDeducoesController.updateValue(nfseDetalheModel.valorDeducoes ?? 0);
    valorPisController.updateValue(nfseDetalheModel.valorPis ?? 0);
    valorCofinsController.updateValue(nfseDetalheModel.valorCofins ?? 0);
    valorInssController.updateValue(nfseDetalheModel.valorInss ?? 0);
    valorIrController.updateValue(nfseDetalheModel.valorIr ?? 0);
    valorCsllController.updateValue(nfseDetalheModel.valorCsll ?? 0);
    valorBaseCalculoController.updateValue(nfseDetalheModel.valorBaseCalculo ?? 0);
    aliquotaController.updateValue(nfseDetalheModel.aliquota ?? 0);
    valorIssController.updateValue(nfseDetalheModel.valorIss ?? 0);
    valorLiquidoController.updateValue(nfseDetalheModel.valorLiquido ?? 0);
    outrasRetencoesController.updateValue(nfseDetalheModel.outrasRetencoes ?? 0);
    valorCreditoController.updateValue(nfseDetalheModel.valorCredito ?? 0);
    issRetidoController.selected = nfseDetalheModel.issRetido ?? 'S';
    valorIssRetidoController.updateValue(nfseDetalheModel.valorIssRetido ?? 0);
    valorDescontoCondicionadoController.updateValue(nfseDetalheModel.valorDescontoCondicionado ?? 0);
    valorDescontoIncondicionadoController.updateValue(nfseDetalheModel.valorDescontoIncondicionado ?? 0);
    municipioPrestacaoController.updateValue((nfseDetalheModel.municipioPrestacao ?? 0).toDouble());
    discriminacaoController.text = nfseDetalheModel.discriminacao ?? '';
    formWasChangedDetail = false;
  }

  @override
  Future<void> save() async {
    if (!nfseDetalheFormKey.currentState!.validate()) {
      showErrorSnackBar(message: 'validator_form_message'.tr);
      return;
    }

    if (formWasChangedDetail) {
      if (isNewRecord) {
        nfseDetalheModelList.insert(0, nfseDetalheModel.clone());
      } else {
        final index = nfseDetalheModelList.indexWhere((m) => m.tempId == nfseDetalheModel.tempId);
        if (index >= 0) {
          nfseDetalheModelList[index] = nfseDetalheModel.clone();
        }
      }

      userMadeChanges = true;
      loadData();
      Get.back(result: true);
    } else {
      Get.back();
    }
  }

  Future callNfseListaServicoLookup() async { 
		final lookupController = Get.find<LookupController>(); 
		lookupController.refreshItems(standardValue: '%'); 
		lookupController.title = '${'lookup_page_title'.tr} [Lista Serviço]'; 
		lookupController.route = '/nfse-lista-servico/'; 
		lookupController.gridColumns = nfseListaServicoGridColumns(isForLookup: true); 
		lookupController.aliasColumns = NfseListaServicoModel.aliasColumns; 
		lookupController.dbColumns = NfseListaServicoModel.dbColumns; 
		lookupController.standardColumn = NfseListaServicoModel.aliasColumns[NfseListaServicoModel.dbColumns.indexOf('descricao')]; 

		final plutoRowResult = await Get.toNamed(Routes.lookupPage); 
		if (plutoRowResult != null) { 
			nfseDetalheModel.idNfseListaServico = plutoRowResult.cells['id']!.value; 
			nfseDetalheModel.nfseListaServicoModel = NfseListaServicoModel.fromPlutoRow(plutoRowResult); 
			nfseListaServicoModelController.text = nfseDetalheModel.nfseListaServicoModel?.descricao ?? ''; 
			formWasChangedDetail = true; 
		}
	}


  @override
  Future deleteSelected() async {
    final currentRow = plutoGridStateManager.currentRow;
    if (currentRow == null) {
      showInfoSnackBar(message: 'message_select_one_to_delete'.tr);
      return null;
    }
    showDeleteDialog(() async {
      final id = currentRow.cells['id']?.value;
      final tempId = currentRow.cells['tempId']?.value;
      nfseDetalheModelList.removeWhere((model) => (id != 0 && model.id == id) || (id == 0 && model.tempId == tempId));
      plutoGridStateManager.removeCurrentRow();
      userMadeChanges = true;
    });
  }

  @override
  void preventDataLoss() {
    if (formWasChangedDetail) {
      showQuestionDialog('message_data_loss'.tr, () => Get.back());
    } else {
      formWasChangedDetail = false;
      Get.back();
    }
  }

  @override
  void onClose() {
    nfseListaServicoModelController.dispose();
    codigoCnaeController.dispose();
    codigoTributacaoMunicipioController.dispose();
    valorServicosController.dispose();
    valorDeducoesController.dispose();
    valorPisController.dispose();
    valorCofinsController.dispose();
    valorInssController.dispose();
    valorIrController.dispose();
    valorCsllController.dispose();
    valorBaseCalculoController.dispose();
    aliquotaController.dispose();
    valorIssController.dispose();
    valorLiquidoController.dispose();
    outrasRetencoesController.dispose();
    valorCreditoController.dispose();
    issRetidoController.dispose();
    valorIssRetidoController.dispose();
    valorDescontoCondicionadoController.dispose();
    valorDescontoIncondicionadoController.dispose();
    municipioPrestacaoController.dispose();
    discriminacaoController.dispose();
  }

}