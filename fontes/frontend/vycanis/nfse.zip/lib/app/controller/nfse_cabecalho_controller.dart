import 'dart:typed_data';

import 'package:flutter/material.dart';
import 'dart:math';
import 'package:get/get.dart';
import 'package:extended_masked_text/extended_masked_text.dart';
import 'package:nfse/app/page/shared_page/shared_page_imports.dart';
import 'package:nfse/app/page/shared_widget/input/input_imports.dart';

import 'package:nfse/app/infra/infra_imports.dart';
import 'package:nfse/app/page/page_imports.dart';
import 'package:nfse/app/page/shared_widget/message_dialog.dart';
import 'package:nfse/app/page/grid_columns/grid_columns_imports.dart';
import 'package:nfse/app/routes/app_routes.dart';
import 'package:nfse/app/controller/controller_imports.dart';
import 'package:nfse/app/data/model/model_imports.dart';
import 'package:nfse/app/data/repository/nfse_cabecalho_repository.dart';

class NfseCabecalhoController extends ControllerBase<NfseCabecalhoModel, NfseCabecalhoRepository> 
with GetSingleTickerProviderStateMixin {

  NfseCabecalhoController({required super.repository}) {
    dbColumns = NfseCabecalhoModel.dbColumns;
    aliasColumns = NfseCabecalhoModel.aliasColumns;
    gridColumns = nfseCabecalhoGridColumns();
    functionName = "nfse_cabecalho";
    screenTitle = "NFS-e";
  }

  final nfseCabecalhoScaffoldKey = GlobalKey<ScaffoldState>();
  final nfseCabecalhoTabPageScaffoldKey = GlobalKey<ScaffoldState>();
  final nfseCabecalhoFormKey = GlobalKey<FormState>();
  late TabController tabController;
  String? mandatoryMessage;  

  @override
  NfseCabecalhoModel createNewModel() => NfseCabecalhoModel();

  @override
  final standardFieldForFilter = NfseCabecalhoModel.aliasColumns[NfseCabecalhoModel.dbColumns.indexOf('numero')];

  final viewPessoaClienteModelController = TextEditingController();
  final osAberturaModelController = TextEditingController();
  final numeroController = TextEditingController();
  final codigoVerificacaoController = TextEditingController();
  final dataHoraEmissaoController = DatePickerItemController(null);
  final competenciaController = MaskedTextController(mask: '00/0000',);
  final numeroSubstituidaController = TextEditingController();
  final naturezaOperacaoController = CustomDropdownButtonController('1=Tributação no município');
  final regimeEspecialTributacaoController = CustomDropdownButtonController('1=Microempresa Municipal');
  final optanteSimplesNacionalController = CustomDropdownButtonController('S');
  final incentivadorCulturalController = CustomDropdownButtonController('S');
  final numeroRpsController = TextEditingController();
  final serieRpsController = TextEditingController();
  final tipoRpsController = CustomDropdownButtonController('1=Recibo Provisório de Serviços');
  final dataEmissaoRpsController = DatePickerItemController(null);
  final outrasInformacoesController = TextEditingController();

  final Map<String, dynamic> mobileConfig = {
    'primaryColumns': ['numero'],
    'secondaryColumns': ['codigo_verificacao'],
  };

  List<Map<String, dynamic>> get mobileItems {
    return modelList.map((nfseCabecalho) => nfseCabecalho.toJson).toList();
  }

  @override
  void prepareForInsert() {
    isNewRecord = true;
    currentModel = createNewModel();
    _resetForm();
    tabController.animateTo(0);
    updateControllersFromModel();
    Get.toNamed(Routes.nfseCabecalhoTabPage);
  }

  void _resetForm() {
    formWasChanged = false;
    viewPessoaClienteModelController.text = '';
    osAberturaModelController.text = '';
    numeroController.text = '';
    codigoVerificacaoController.text = '';
    dataHoraEmissaoController.date = null;
    competenciaController.text = '';
    numeroSubstituidaController.text = '';
    naturezaOperacaoController.selected = '1=Tributação no município';
    regimeEspecialTributacaoController.selected = '1=Microempresa Municipal';
    optanteSimplesNacionalController.selected = 'S';
    incentivadorCulturalController.selected = 'S';
    numeroRpsController.text = '';
    serieRpsController.text = '';
    tipoRpsController.selected = '1=Recibo Provisório de Serviços';
    dataEmissaoRpsController.date = null;
    outrasInformacoesController.text = '';
  }

  @override
  void selectRowForEditingById(int id) {
    final model = modelList.firstWhere((m) => m.id == id);
    currentModel = model.clone();
    updateControllersFromModel();
    tabController.animateTo(0);
    Get.toNamed(Routes.nfseCabecalhoTabPage);
  }

  _configureChildrenControllers() {
    //Itens da NFS-e
		Get.put<NfseDetalheController>(NfseDetalheController()); 

    //Intermediários
		Get.put<NfseIntermediarioController>(NfseIntermediarioController()); 

  }
	
	_releaseChildrenControllers() {
    //Itens da NFS-e
		Get.delete<NfseDetalheController>(); 

    //Intermediários
		Get.delete<NfseIntermediarioController>(); 

	}
  
  void updateControllersFromModel() {
    viewPessoaClienteModelController.text = currentModel.viewPessoaClienteModel?.nome?.toString() ?? '';
    osAberturaModelController.text = currentModel.osAberturaModel?.numero?.toString() ?? '';
    numeroController.text = currentModel.numero ?? '';
    codigoVerificacaoController.text = currentModel.codigoVerificacao ?? '';
    dataHoraEmissaoController.date = currentModel.dataHoraEmissao;
    competenciaController.text = currentModel.competencia ?? '';
    numeroSubstituidaController.text = currentModel.numeroSubstituida ?? '';
    naturezaOperacaoController.selected = currentModel.naturezaOperacao ?? '1=Tributação no município';
    regimeEspecialTributacaoController.selected = currentModel.regimeEspecialTributacao ?? '1=Microempresa Municipal';
    optanteSimplesNacionalController.selected = currentModel.optanteSimplesNacional ?? 'S';
    incentivadorCulturalController.selected = currentModel.incentivadorCultural ?? 'S';
    numeroRpsController.text = currentModel.numeroRps ?? '';
    serieRpsController.text = currentModel.serieRps ?? '';
    tipoRpsController.selected = currentModel.tipoRps ?? '1=Recibo Provisório de Serviços';
    dataEmissaoRpsController.date = currentModel.dataEmissaoRps;
    outrasInformacoesController.text = currentModel.outrasInformacoes ?? '';

    formWasChanged = false;
    _updateChildrenControllersFromModel();
  }

  void _updateChildrenControllersFromModel() {
    //Itens da NFS-e
		final nfseDetalheController = Get.find<NfseDetalheController>(); 
		nfseDetalheController.userMadeChanges = false; 

    //Intermediários
		final nfseIntermediarioController = Get.find<NfseIntermediarioController>(); 
		nfseIntermediarioController.userMadeChanges = false; 

  }

  @override
  Future<void> save() async {
    if (!validateCurrentForm()) return;
    if (validateForms()) {
      if (userMadeChanges()) {
        final existingIndex = modelList.indexWhere((m) => m.id == currentModel.id);

        if (existingIndex >= 0) {
          modelList[existingIndex] = currentModel.clone();
        }

        final result = await repository.save(nfseCabecalhoModel: currentModel);
        if (result == null) return;

        if (existingIndex >= 0) {
          modelList[existingIndex] = result;
        } else {
          modelList.insert(0, result);
        }

        if (!GetPlatform.isMobile) {
          updateGridRow(result);
        }

        Get.back(result: true);
      } else {
        Get.back();
      }
    } 
  }

  Future callViewPessoaClienteLookup() async { 
		final lookupController = Get.find<LookupController>(); 
		lookupController.refreshItems(standardValue: '%'); 
		lookupController.title = '${'lookup_page_title'.tr} [Cliente]'; 
		lookupController.route = '/view-pessoa-cliente/'; 
		lookupController.gridColumns = viewPessoaClienteGridColumns(isForLookup: true); 
		lookupController.aliasColumns = ViewPessoaClienteModel.aliasColumns; 
		lookupController.dbColumns = ViewPessoaClienteModel.dbColumns; 
		lookupController.standardColumn = ViewPessoaClienteModel.aliasColumns[ViewPessoaClienteModel.dbColumns.indexOf('nome')]; 

		final plutoRowResult = await Get.toNamed(Routes.lookupPage); 
		if (plutoRowResult != null) { 
			currentModel.idCliente = plutoRowResult.cells['id']!.value; 
			currentModel.viewPessoaClienteModel = ViewPessoaClienteModel.fromPlutoRow(plutoRowResult); 
			viewPessoaClienteModelController.text = currentModel.viewPessoaClienteModel?.nome ?? ''; 
			formWasChanged = true; 
		}
	}

  Future callOsAberturaLookup() async { 
		final lookupController = Get.find<LookupController>(); 
		lookupController.refreshItems(standardValue: '%'); 
		lookupController.title = '${'lookup_page_title'.tr} [Número OS]'; 
		lookupController.route = '/os-abertura/'; 
		lookupController.gridColumns = osAberturaGridColumns(isForLookup: true); 
		lookupController.aliasColumns = OsAberturaModel.aliasColumns; 
		lookupController.dbColumns = OsAberturaModel.dbColumns; 
		lookupController.standardColumn = OsAberturaModel.aliasColumns[OsAberturaModel.dbColumns.indexOf('numero')]; 

		final plutoRowResult = await Get.toNamed(Routes.lookupPage); 
		if (plutoRowResult != null) { 
			currentModel.idOsAbertura = plutoRowResult.cells['id']!.value; 
			currentModel.osAberturaModel = OsAberturaModel.fromPlutoRow(plutoRowResult); 
			osAberturaModelController.text = currentModel.osAberturaModel?.numero ?? ''; 
			formWasChanged = true; 
		}
	}


  List<Tab> tabItems = [
    Tab( 
			icon: Icon(iconDataList[Random().nextInt(10)]), 
			text: 'NFS-e', 
		),
    Tab( 
			icon: Icon(iconDataList[Random().nextInt(10)]), 
			text: 'Itens da NFS-e', 
		),
    Tab( 
			icon: Icon(iconDataList[Random().nextInt(10)]), 
			text: 'Intermediários', 
		),
  ];

  List<Widget> tabPages() {
    return [
      NfseCabecalhoEditPage(),
      const NfseDetalheListPage(),
      const NfseIntermediarioListPage(),
    ];
  }

  @override
  void preventDataLoss() {
    if (userMadeChanges()) {
      showQuestionDialog('message_data_loss'.tr, () { 
        Get.back(); 
      });
    } else {
      Get.back();
    }
  }  

  bool userMadeChanges() {
    return
    formWasChanged 
    || 
		Get.find<NfseDetalheController>().userMadeChanges
    || 
		Get.find<NfseIntermediarioController>().userMadeChanges
    ;
  }

  void tabChange(int index) {
    validateCurrentForm();
  }

  bool validateCurrentForm() {
    mandatoryMessage = ValidateFormField.validateMandatory(currentModel.viewPessoaClienteModel?.nome); 
		if (mandatoryMessage != null) { 
			tabController.animateTo(0); 
			showErrorSnackBar(message: '$mandatoryMessage [Cliente]'); 
			return false; 
		}
    return true;
  }

  bool validateForms() {
    return true;
  }

  Future transmitirNfse() async {
    if (currentModel.id == null) {
      showErrorSnackBar(message: 'Primeiro salve a nota para então transmiti-la.');
      return;
    }

    showQuestionDialog('Deseja Gerar e Transmitir a NFS-e?', () async {
      try {
        final result = await repository.transmitirNfse(nfseCabecalhoModel: currentModel);
        if (result == null) return;

        if (result is String) {
          showErrorDialog('Ocorreu um problema na geração da NFS-e: \n$result');
        } else if (result is Uint8List) {
          _imprimirDanfse(result);
        }
      } catch (e) {
        showErrorSnackBar(message: "Erro ao transmitir a NFS-e: ${e.toString()}");
      }
    });
  }

  void _imprimirDanfse(Uint8List danfse) {
    Get.to(() => PdfPage(
      title: "DANFSe",
      pdfFile: danfse,
    ));
  }

  @override
  void onInit() {
    super.onInit();
    tabController = TabController(vsync: this, length: tabItems.length);
    _configureChildrenControllers();
  }

  @override
  void onClose() {
    tabController.dispose();
    viewPessoaClienteModelController.dispose();
    osAberturaModelController.dispose();
    numeroController.dispose();
    codigoVerificacaoController.dispose();
    dataHoraEmissaoController.dispose();
    competenciaController.dispose();
    numeroSubstituidaController.dispose();
    naturezaOperacaoController.dispose();
    regimeEspecialTributacaoController.dispose();
    optanteSimplesNacionalController.dispose();
    incentivadorCulturalController.dispose();
    numeroRpsController.dispose();
    serieRpsController.dispose();
    tipoRpsController.dispose();
    dataEmissaoRpsController.dispose();
    outrasInformacoesController.dispose();
    _releaseChildrenControllers();
    super.onClose();
  }	
}