import 'package:flutter/material.dart';
import 'package:get/get.dart';

import 'package:nfse/app/page/shared_widget/message_dialog.dart';
import 'package:nfse/app/page/grid_columns/grid_columns_imports.dart';
import 'package:nfse/app/routes/app_routes.dart';
import 'package:nfse/app/controller/controller_imports.dart';
import 'package:nfse/app/data/model/model_imports.dart';
import 'package:nfse/app/data/repository/nfse_lista_servico_repository.dart';

class NfseListaServicoController extends ControllerBase<NfseListaServicoModel, NfseListaServicoRepository> {

  NfseListaServicoController({required super.repository}) {
    dbColumns = NfseListaServicoModel.dbColumns;
    aliasColumns = NfseListaServicoModel.aliasColumns;
    gridColumns = nfseListaServicoGridColumns();
    functionName = "nfse_lista_servico";
    screenTitle = "Lista de Serviços";
  }

  @override
  NfseListaServicoModel createNewModel() => NfseListaServicoModel();

  @override
  final standardFieldForFilter = NfseListaServicoModel.aliasColumns[NfseListaServicoModel.dbColumns.indexOf('codigo')];

  final codigoController = TextEditingController();
  final descricaoController = TextEditingController();

  final Map<String, dynamic> mobileConfig = {
    'primaryColumns': ['codigo'],
    'secondaryColumns': ['descricao'],
  };

  List<Map<String, dynamic>> get mobileItems {
    return modelList.map((nfseListaServico) => nfseListaServico.toJson).toList();
  }

  @override
  void prepareForInsert() {
    isNewRecord = true;
    currentModel = createNewModel();
    _resetForm();
    Get.toNamed(Routes.nfseListaServicoEditPage);
  }

  void _resetForm() {
    formWasChanged = false;
    codigoController.text = '';
    descricaoController.text = '';
  }

  @override
  void selectRowForEditingById(int id) {
    final model = modelList.firstWhere((m) => m.id == id);
    currentModel = model.clone();
    updateControllersFromModel();
    Get.toNamed(Routes.nfseListaServicoEditPage);
  }

  void updateControllersFromModel() {
    codigoController.text = currentModel.codigo ?? '';
    descricaoController.text = currentModel.descricao ?? '';
    formWasChanged = false;
  }

  @override
  Future<void> save() async {
    if (!formKey.currentState!.validate()) {
      showErrorSnackBar(message: 'validator_form_message'.tr);
      return;
    }

    final existingIndex = modelList.indexWhere((m) => m.id == currentModel.id);

    if (existingIndex >= 0) {
      modelList[existingIndex] = currentModel.clone();
    }

    final result = await repository.save(nfseListaServicoModel: currentModel);
    if (result == null) return;

    if (existingIndex >= 0) {
      modelList[existingIndex] = result;
    } else {
      modelList.insert(0, result);
    }

    if (!GetPlatform.isMobile) {
      updateGridRow(result);
    }

    Get.back(result: true);
  }


  @override
  void onClose() {
    codigoController.dispose();
    descricaoController.dispose();
    super.onClose();
  }

}