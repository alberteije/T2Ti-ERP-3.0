import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:pluto_grid/pluto_grid.dart';
import 'package:extended_masked_text/extended_masked_text.dart';

import 'package:nfse/app/page/page_imports.dart';
import 'package:nfse/app/page/shared_widget/message_dialog.dart';
import 'package:nfse/app/page/grid_columns/grid_columns_imports.dart';
import 'package:nfse/app/controller/controller_imports.dart';
import 'package:nfse/app/data/model/model_imports.dart';

class NfseIntermediarioController extends ControllerBase<NfseIntermediarioModel, void> {

  NfseIntermediarioController() : super(repository: null) {
    dbColumns = NfseIntermediarioModel.dbColumns;
    aliasColumns = NfseIntermediarioModel.aliasColumns;
    gridColumns = nfseIntermediarioGridColumns();
    functionName = "nfse_intermediario";
    screenTitle = "Intermediários";
  }

  final _nfseIntermediarioModel = NfseIntermediarioModel().obs;
  NfseIntermediarioModel get nfseIntermediarioModel => _nfseIntermediarioModel.value;
  set nfseIntermediarioModel(value) => _nfseIntermediarioModel.value = value ?? NfseIntermediarioModel();

  List<NfseIntermediarioModel> get nfseIntermediarioModelList => Get.find<NfseCabecalhoController>().currentModel.nfseIntermediarioModelList ?? [];

  final _userMadeChanges = false.obs;
  get userMadeChanges => _userMadeChanges.value;
  set userMadeChanges(value) => _userMadeChanges.value = value;

  final _formWasChangedDetail = false.obs;
  bool get formWasChangedDetail => _formWasChangedDetail.value;
  set formWasChangedDetail(value) => _formWasChangedDetail.value = value;

  late PlutoGridStateManager _plutoGridStateManager;
  @override
  PlutoGridStateManager get plutoGridStateManager => _plutoGridStateManager;
  @override
  set plutoGridStateManager(value) => _plutoGridStateManager = value;

  final nfseIntermediarioScaffoldKey = GlobalKey<ScaffoldState>();
  final nfseIntermediarioFormKey = GlobalKey<FormState>();

  @override
  NfseIntermediarioModel createNewModel() => NfseIntermediarioModel();

  @override
  final standardFieldForFilter = NfseIntermediarioModel.aliasColumns[NfseIntermediarioModel.dbColumns.indexOf('cnpj')];

  final cnpjController = MaskedTextController(mask: '00.000.000/0000-00',);
  final inscricaoMunicipalController = TextEditingController();
  final razaoController = TextEditingController();

  final Map<String, dynamic> mobileConfig = {
    'primaryColumns': ['cnpj'],
    'secondaryColumns': ['inscricao_municipal'],
  };

  List<Map<String, dynamic>> get mobileItems {
    return modelList.map((nfseIntermediario) => nfseIntermediario.toJson).toList();
  }

  @override
  List<PlutoRow> plutoRows() => List<PlutoRow>.from(nfseIntermediarioModelList.map((model) => model.toPlutoRow()));

  @override
  Future<void> getList({Filter? filter}) async {}

  @override
  void prepareForInsert() {
    isNewRecord = true;
    nfseIntermediarioModel = createNewModel();
    _resetForm();
    Get.to(() => NfseIntermediarioEditPage());
  }

  void _resetForm() {
    formWasChangedDetail = false;
    cnpjController.text = '';
    inscricaoMunicipalController.text = '';
    razaoController.text = '';
  }

  @override
  void selectRowForEditing(PlutoRow? row) async {
    if (row == null) {
      showInfoSnackBar(message: 'message_select_one_to_edited'.tr);
      return;
    }

    selectRowForEditingByTempId(row.cells['tempId']?.value);
  }

  @override
  void selectRowForEditingById(int id) {}

  void selectRowForEditingByTempId(String tempId) {
		isNewRecord = false;
    final model = nfseIntermediarioModelList.firstWhere((m) => m.tempId == tempId);
    nfseIntermediarioModel = model.clone();
		nfseIntermediarioModel.tempId = model.tempId;
    updateControllersFromModel();
    Get.to(() => NfseIntermediarioEditPage());
  }

  void updateControllersFromModel() {
    cnpjController.text = nfseIntermediarioModel.cnpj ?? '';
    inscricaoMunicipalController.text = nfseIntermediarioModel.inscricaoMunicipal ?? '';
    razaoController.text = nfseIntermediarioModel.razao ?? '';
    formWasChangedDetail = false;
  }

  @override
  Future<void> save() async {
    if (!nfseIntermediarioFormKey.currentState!.validate()) {
      showErrorSnackBar(message: 'validator_form_message'.tr);
      return;
    }

    if (formWasChangedDetail) {
      if (isNewRecord) {
        nfseIntermediarioModelList.insert(0, nfseIntermediarioModel.clone());
      } else {
        final index = nfseIntermediarioModelList.indexWhere((m) => m.tempId == nfseIntermediarioModel.tempId);
        if (index >= 0) {
          nfseIntermediarioModelList[index] = nfseIntermediarioModel.clone();
        }
      }

      userMadeChanges = true;
      loadData();
      Get.back(result: true);
    } else {
      Get.back();
    }
  }


  @override
  Future deleteSelected() async {
    final currentRow = plutoGridStateManager.currentRow;
    if (currentRow == null) {
      showInfoSnackBar(message: 'message_select_one_to_delete'.tr);
      return null;
    }
    showDeleteDialog(() async {
      final id = currentRow.cells['id']?.value;
      final tempId = currentRow.cells['tempId']?.value;
      nfseIntermediarioModelList.removeWhere((model) => (id != 0 && model.id == id) || (id == 0 && model.tempId == tempId));
      plutoGridStateManager.removeCurrentRow();
      userMadeChanges = true;
    });
  }

  @override
  void preventDataLoss() {
    if (formWasChangedDetail) {
      showQuestionDialog('message_data_loss'.tr, () => Get.back());
    } else {
      formWasChangedDetail = false;
      Get.back();
    }
  }

  @override
  void onClose() {
    cnpjController.dispose();
    inscricaoMunicipalController.dispose();
    razaoController.dispose();
  }

}