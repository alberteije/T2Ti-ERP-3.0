import 'dart:convert';
import 'package:pluto_grid/pluto_grid.dart';
import 'package:nfse/app/data/model/model_imports.dart';

import 'package:nfse/app/infra/infra_imports.dart';
import 'package:intl/intl.dart';

class OsAberturaModel extends ModelBase {
  int? id;
  int? idOsStatus;
  int? idColaborador;
  int? idCliente;
  String? numero;
  DateTime? dataInicio;
  String? horaInicio;
  DateTime? dataPrevisao;
  String? horaPrevisao;
  DateTime? dataFim;
  String? horaFim;
  String? nomeContato;
  String? foneContato;
  String? observacaoCliente;
  String? observacaoAbertura;
  ViewPessoaColaboradorModel? viewPessoaColaboradorModel;
  ViewPessoaClienteModel? viewPessoaClienteModel;

  OsAberturaModel({
    this.id,
    this.idOsStatus,
    this.idColaborador,
    this.idCliente,
    this.numero,
    this.dataInicio,
    this.horaInicio,
    this.dataPrevisao,
    this.horaPrevisao,
    this.dataFim,
    this.horaFim,
    this.nomeContato,
    this.foneContato,
    this.observacaoCliente,
    this.observacaoAbertura,
    ViewPessoaColaboradorModel? viewPessoaColaboradorModel,
    ViewPessoaClienteModel? viewPessoaClienteModel,
  }) {
    this.viewPessoaColaboradorModel = viewPessoaColaboradorModel ?? ViewPessoaColaboradorModel();
    this.viewPessoaClienteModel = viewPessoaClienteModel ?? ViewPessoaClienteModel();
  }

  static List<String> dbColumns = <String>[
    'id',
    'numero',
    'data_inicio',
    'hora_inicio',
    'data_previsao',
    'hora_previsao',
    'data_fim',
    'hora_fim',
    'nome_contato',
    'fone_contato',
    'observacao_cliente',
    'observacao_abertura',
  ];

  static List<String> aliasColumns = <String>[
    'Id',
    'Numero',
    'Data Inicio',
    'Hora Inicio',
    'Data Previsao',
    'Hora Previsao',
    'Data Fim',
    'Hora Fim',
    'Nome Contato',
    'Fone Contato',
    'Observacao Cliente',
    'Observacao Abertura',
  ];

  OsAberturaModel.fromJson(Map<String, dynamic> jsonData) {
    id = jsonData['id'];
    idOsStatus = jsonData['idOsStatus'];
    idColaborador = jsonData['idColaborador'];
    idCliente = jsonData['idCliente'];
    numero = jsonData['numero'];
    dataInicio = jsonData['dataInicio'] != null ? DateTime.tryParse(jsonData['dataInicio']) : null;
    horaInicio = jsonData['horaInicio'];
    dataPrevisao = jsonData['dataPrevisao'] != null ? DateTime.tryParse(jsonData['dataPrevisao']) : null;
    horaPrevisao = jsonData['horaPrevisao'];
    dataFim = jsonData['dataFim'] != null ? DateTime.tryParse(jsonData['dataFim']) : null;
    horaFim = jsonData['horaFim'];
    nomeContato = jsonData['nomeContato'];
    foneContato = jsonData['foneContato'];
    observacaoCliente = jsonData['observacaoCliente'];
    observacaoAbertura = jsonData['observacaoAbertura'];
    viewPessoaColaboradorModel = jsonData['viewPessoaColaboradorModel'] == null ? ViewPessoaColaboradorModel() : ViewPessoaColaboradorModel.fromJson(jsonData['viewPessoaColaboradorModel']);
    viewPessoaClienteModel = jsonData['viewPessoaClienteModel'] == null ? ViewPessoaClienteModel() : ViewPessoaClienteModel.fromJson(jsonData['viewPessoaClienteModel']);
  }

  Map<String, dynamic> get toJson {
    Map<String, dynamic> jsonData = <String, dynamic>{};

    jsonData['id'] = id != 0 ? id : null;
    jsonData['idOsStatus'] = idOsStatus != 0 ? idOsStatus : null;
    jsonData['idColaborador'] = idColaborador != 0 ? idColaborador : null;
    jsonData['idCliente'] = idCliente != 0 ? idCliente : null;
    jsonData['numero'] = numero;
    jsonData['dataInicio'] = dataInicio != null ? DateFormat('yyyy-MM-ddT00:00:00').format(dataInicio!) : null;
    jsonData['horaInicio'] = horaInicio;
    jsonData['dataPrevisao'] = dataPrevisao != null ? DateFormat('yyyy-MM-ddT00:00:00').format(dataPrevisao!) : null;
    jsonData['horaPrevisao'] = horaPrevisao;
    jsonData['dataFim'] = dataFim != null ? DateFormat('yyyy-MM-ddT00:00:00').format(dataFim!) : null;
    jsonData['horaFim'] = horaFim;
    jsonData['nomeContato'] = nomeContato;
    jsonData['foneContato'] = foneContato;
    jsonData['observacaoCliente'] = observacaoCliente;
    jsonData['observacaoAbertura'] = observacaoAbertura;
    jsonData['viewPessoaColaboradorModel'] = viewPessoaColaboradorModel?.toJson;
    jsonData['viewPessoaColaborador'] = viewPessoaColaboradorModel?.nome ?? '';
    jsonData['viewPessoaClienteModel'] = viewPessoaClienteModel?.toJson;
    jsonData['viewPessoaCliente'] = viewPessoaClienteModel?.nome ?? '';

    return jsonData;
  }

  String objectEncodeJson() {
    final jsonData = toJson;
    return json.encode(jsonData);
  }

  static OsAberturaModel fromPlutoRow(PlutoRow row) {
    return OsAberturaModel(
      id: row.cells['id']?.value,
      idOsStatus: row.cells['idOsStatus']?.value,
      idColaborador: row.cells['idColaborador']?.value,
      idCliente: row.cells['idCliente']?.value,
      numero: row.cells['numero']?.value,
      dataInicio: Util.stringToDate(row.cells['dataInicio']?.value),
      horaInicio: row.cells['horaInicio']?.value,
      dataPrevisao: Util.stringToDate(row.cells['dataPrevisao']?.value),
      horaPrevisao: row.cells['horaPrevisao']?.value,
      dataFim: Util.stringToDate(row.cells['dataFim']?.value),
      horaFim: row.cells['horaFim']?.value,
      nomeContato: row.cells['nomeContato']?.value,
      foneContato: row.cells['foneContato']?.value,
      observacaoCliente: row.cells['observacaoCliente']?.value,
      observacaoAbertura: row.cells['observacaoAbertura']?.value,
    );
  }

  PlutoRow toPlutoRow() {
    return PlutoRow(
      cells: {
        'tempId': PlutoCell(value: tempId),
        'id': PlutoCell(value: id ?? 0),
        'idOsStatus': PlutoCell(value: idOsStatus ?? 0),
        'idColaborador': PlutoCell(value: idColaborador ?? 0),
        'idCliente': PlutoCell(value: idCliente ?? 0),
        'numero': PlutoCell(value: numero ?? ''),
        'dataInicio': PlutoCell(value: dataInicio),
        'horaInicio': PlutoCell(value: horaInicio ?? ''),
        'dataPrevisao': PlutoCell(value: dataPrevisao),
        'horaPrevisao': PlutoCell(value: horaPrevisao ?? ''),
        'dataFim': PlutoCell(value: dataFim),
        'horaFim': PlutoCell(value: horaFim ?? ''),
        'nomeContato': PlutoCell(value: nomeContato ?? ''),
        'foneContato': PlutoCell(value: foneContato ?? ''),
        'observacaoCliente': PlutoCell(value: observacaoCliente ?? ''),
        'observacaoAbertura': PlutoCell(value: observacaoAbertura ?? ''),
        'viewPessoaColaborador': PlutoCell(value: viewPessoaColaboradorModel?.nome ?? ''),
        'viewPessoaCliente': PlutoCell(value: viewPessoaClienteModel?.nome ?? ''),
      },
    );
  }

  OsAberturaModel clone() {
    return OsAberturaModel(
      id: id,
      idOsStatus: idOsStatus,
      idColaborador: idColaborador,
      idCliente: idCliente,
      numero: numero,
      dataInicio: dataInicio,
      horaInicio: horaInicio,
      dataPrevisao: dataPrevisao,
      horaPrevisao: horaPrevisao,
      dataFim: dataFim,
      horaFim: horaFim,
      nomeContato: nomeContato,
      foneContato: foneContato,
      observacaoCliente: observacaoCliente,
      observacaoAbertura: observacaoAbertura,
      viewPessoaColaboradorModel: viewPessoaColaboradorModel?.clone(),
      viewPessoaClienteModel: viewPessoaClienteModel?.clone(),
    );
  }


}