import 'dart:convert';
import 'package:pluto_grid/pluto_grid.dart';
import 'package:nfse/app/data/model/model_imports.dart';

import 'package:nfse/app/infra/infra_imports.dart';
import 'package:intl/intl.dart';
import 'package:nfse/app/data/domain/domain_imports.dart';

class NfseCabecalhoModel extends ModelBase {
  int? id;
  int? idCliente;
  int? idOsAbertura;
  String? numero;
  String? codigoVerificacao;
  DateTime? dataHoraEmissao;
  String? competencia;
  String? numeroSubstituida;
  String? naturezaOperacao;
  String? regimeEspecialTributacao;
  String? optanteSimplesNacional;
  String? incentivadorCultural;
  String? numeroRps;
  String? serieRps;
  String? tipoRps;
  DateTime? dataEmissaoRps;
  String? outrasInformacoes;
  List<NfseDetalheModel>? nfseDetalheModelList;
  List<NfseIntermediarioModel>? nfseIntermediarioModelList;
  ViewPessoaClienteModel? viewPessoaClienteModel;
  OsAberturaModel? osAberturaModel;

  NfseCabecalhoModel({
    this.id,
    this.idCliente,
    this.idOsAbertura,
    this.numero,
    this.codigoVerificacao,
    this.dataHoraEmissao,
    this.competencia,
    this.numeroSubstituida,
    this.naturezaOperacao = '1=Tributação no município',
    this.regimeEspecialTributacao = '1=Microempresa Municipal',
    this.optanteSimplesNacional = 'S',
    this.incentivadorCultural = 'S',
    this.numeroRps,
    this.serieRps,
    this.tipoRps = '1=Recibo Provisório de Serviços',
    this.dataEmissaoRps,
    this.outrasInformacoes,
    List<NfseDetalheModel>? nfseDetalheModelList,
    List<NfseIntermediarioModel>? nfseIntermediarioModelList,
    ViewPessoaClienteModel? viewPessoaClienteModel,
    OsAberturaModel? osAberturaModel,
  }) {
    this.nfseDetalheModelList = nfseDetalheModelList?.toList(growable: true) ?? [];
    this.nfseIntermediarioModelList = nfseIntermediarioModelList?.toList(growable: true) ?? [];
    this.viewPessoaClienteModel = viewPessoaClienteModel ?? ViewPessoaClienteModel();
    this.osAberturaModel = osAberturaModel ?? OsAberturaModel();
  }

  static List<String> dbColumns = <String>[
    'id',
    'numero',
    'codigo_verificacao',
    'data_hora_emissao',
    'competencia',
    'numero_substituida',
    'natureza_operacao',
    'regime_especial_nfse',
    'optante_simples_nacional',
    'incentivador_cultural',
    'numero_rps',
    'serie_rps',
    'tipo_rps',
    'data_emissao_rps',
    'outras_informacoes',
  ];

  static List<String> aliasColumns = <String>[
    'Id',
    'Numero',
    'Codigo Verificacao',
    'Data Hora Emissao',
    'Competencia',
    'Numero Substituida',
    'Natureza Operacao',
    'Regime Especial Tributacao',
    'Optante Simples Nacional',
    'Incentivador Cultural',
    'Numero Rps',
    'Serie Rps',
    'Tipo Rps',
    'Data Emissao Rps',
    'Outras Informacoes',
  ];

  NfseCabecalhoModel.fromJson(Map<String, dynamic> jsonData) {
    id = jsonData['id'];
    idCliente = jsonData['idCliente'];
    idOsAbertura = jsonData['idOsAbertura'];
    numero = jsonData['numero'];
    codigoVerificacao = jsonData['codigoVerificacao'];
    dataHoraEmissao = jsonData['dataHoraEmissao'] != null ? DateTime.tryParse(jsonData['dataHoraEmissao']) : null;
    competencia = jsonData['competencia'];
    numeroSubstituida = jsonData['numeroSubstituida'];
    naturezaOperacao = NfseCabecalhoDomain.getNaturezaOperacao(jsonData['naturezaOperacao']);
    regimeEspecialTributacao = NfseCabecalhoDomain.getRegimeEspecialTributacao(jsonData['regimeEspecialTributacao']);
    optanteSimplesNacional = NfseCabecalhoDomain.getOptanteSimplesNacional(jsonData['optanteSimplesNacional']);
    incentivadorCultural = NfseCabecalhoDomain.getIncentivadorCultural(jsonData['incentivadorCultural']);
    numeroRps = jsonData['numeroRps'];
    serieRps = jsonData['serieRps'];
    tipoRps = NfseCabecalhoDomain.getTipoRps(jsonData['tipoRps']);
    dataEmissaoRps = jsonData['dataEmissaoRps'] != null ? DateTime.tryParse(jsonData['dataEmissaoRps']) : null;
    outrasInformacoes = jsonData['outrasInformacoes'];
    nfseDetalheModelList = (jsonData['nfseDetalheModelList'] as Iterable?)?.map((m) => NfseDetalheModel.fromJson(m)).toList() ?? [];
    nfseIntermediarioModelList = (jsonData['nfseIntermediarioModelList'] as Iterable?)?.map((m) => NfseIntermediarioModel.fromJson(m)).toList() ?? [];
    viewPessoaClienteModel = jsonData['viewPessoaClienteModel'] == null ? ViewPessoaClienteModel() : ViewPessoaClienteModel.fromJson(jsonData['viewPessoaClienteModel']);
    osAberturaModel = jsonData['osAberturaModel'] == null ? OsAberturaModel() : OsAberturaModel.fromJson(jsonData['osAberturaModel']);
  }

  Map<String, dynamic> get toJson {
    Map<String, dynamic> jsonData = <String, dynamic>{};

    jsonData['id'] = id != 0 ? id : null;
    jsonData['idCliente'] = idCliente != 0 ? idCliente : null;
    jsonData['idOsAbertura'] = idOsAbertura != 0 ? idOsAbertura : null;
    jsonData['numero'] = numero;
    jsonData['codigoVerificacao'] = codigoVerificacao;
    jsonData['dataHoraEmissao'] = dataHoraEmissao != null ? DateFormat('yyyy-MM-ddT00:00:00').format(dataHoraEmissao!) : null;
    jsonData['competencia'] = Util.removeMask(competencia);
    jsonData['numeroSubstituida'] = numeroSubstituida;
    jsonData['naturezaOperacao'] = NfseCabecalhoDomain.setNaturezaOperacao(naturezaOperacao);
    jsonData['regimeEspecialTributacao'] = NfseCabecalhoDomain.setRegimeEspecialTributacao(regimeEspecialTributacao);
    jsonData['optanteSimplesNacional'] = NfseCabecalhoDomain.setOptanteSimplesNacional(optanteSimplesNacional);
    jsonData['incentivadorCultural'] = NfseCabecalhoDomain.setIncentivadorCultural(incentivadorCultural);
    jsonData['numeroRps'] = numeroRps;
    jsonData['serieRps'] = serieRps;
    jsonData['tipoRps'] = NfseCabecalhoDomain.setTipoRps(tipoRps);
    jsonData['dataEmissaoRps'] = dataEmissaoRps != null ? DateFormat('yyyy-MM-ddT00:00:00').format(dataEmissaoRps!) : null;
    jsonData['outrasInformacoes'] = outrasInformacoes;
    
		var nfseDetalheModelLocalList = []; 
		for (NfseDetalheModel object in nfseDetalheModelList ?? []) { 
			nfseDetalheModelLocalList.add(object.toJson); 
		}
		jsonData['nfseDetalheModelList'] = nfseDetalheModelLocalList;
    
		var nfseIntermediarioModelLocalList = []; 
		for (NfseIntermediarioModel object in nfseIntermediarioModelList ?? []) { 
			nfseIntermediarioModelLocalList.add(object.toJson); 
		}
		jsonData['nfseIntermediarioModelList'] = nfseIntermediarioModelLocalList;
    jsonData['viewPessoaClienteModel'] = viewPessoaClienteModel?.toJson;
    jsonData['viewPessoaCliente'] = viewPessoaClienteModel?.nome ?? '';
    jsonData['osAberturaModel'] = osAberturaModel?.toJson;
    jsonData['osAbertura'] = osAberturaModel?.numero ?? '';

    return jsonData;
  }

  String objectEncodeJson() {
    final jsonData = toJson;
    return json.encode(jsonData);
  }

  static NfseCabecalhoModel fromPlutoRow(PlutoRow row) {
    return NfseCabecalhoModel(
      id: row.cells['id']?.value,
      idCliente: row.cells['idCliente']?.value,
      idOsAbertura: row.cells['idOsAbertura']?.value,
      numero: row.cells['numero']?.value,
      codigoVerificacao: row.cells['codigoVerificacao']?.value,
      dataHoraEmissao: Util.stringToDate(row.cells['dataHoraEmissao']?.value),
      competencia: row.cells['competencia']?.value,
      numeroSubstituida: row.cells['numeroSubstituida']?.value,
      naturezaOperacao: row.cells['naturezaOperacao']?.value,
      regimeEspecialTributacao: row.cells['regimeEspecialTributacao']?.value,
      optanteSimplesNacional: row.cells['optanteSimplesNacional']?.value,
      incentivadorCultural: row.cells['incentivadorCultural']?.value,
      numeroRps: row.cells['numeroRps']?.value,
      serieRps: row.cells['serieRps']?.value,
      tipoRps: row.cells['tipoRps']?.value,
      dataEmissaoRps: Util.stringToDate(row.cells['dataEmissaoRps']?.value),
      outrasInformacoes: row.cells['outrasInformacoes']?.value,
    );
  }

  PlutoRow toPlutoRow() {
    return PlutoRow(
      cells: {
        'tempId': PlutoCell(value: tempId),
        'id': PlutoCell(value: id ?? 0),
        'idCliente': PlutoCell(value: idCliente ?? 0),
        'idOsAbertura': PlutoCell(value: idOsAbertura ?? 0),
        'numero': PlutoCell(value: numero ?? ''),
        'codigoVerificacao': PlutoCell(value: codigoVerificacao ?? ''),
        'dataHoraEmissao': PlutoCell(value: dataHoraEmissao),
        'competencia': PlutoCell(value: competencia ?? ''),
        'numeroSubstituida': PlutoCell(value: numeroSubstituida ?? ''),
        'naturezaOperacao': PlutoCell(value: naturezaOperacao ?? ''),
        'regimeEspecialTributacao': PlutoCell(value: regimeEspecialTributacao ?? ''),
        'optanteSimplesNacional': PlutoCell(value: optanteSimplesNacional ?? ''),
        'incentivadorCultural': PlutoCell(value: incentivadorCultural ?? ''),
        'numeroRps': PlutoCell(value: numeroRps ?? ''),
        'serieRps': PlutoCell(value: serieRps ?? ''),
        'tipoRps': PlutoCell(value: tipoRps ?? ''),
        'dataEmissaoRps': PlutoCell(value: dataEmissaoRps),
        'outrasInformacoes': PlutoCell(value: outrasInformacoes ?? ''),
        'viewPessoaCliente': PlutoCell(value: viewPessoaClienteModel?.nome ?? ''),
        'osAbertura': PlutoCell(value: osAberturaModel?.numero ?? ''),
      },
    );
  }

  NfseCabecalhoModel clone() {
    return NfseCabecalhoModel(
      id: id,
      idCliente: idCliente,
      idOsAbertura: idOsAbertura,
      numero: numero,
      codigoVerificacao: codigoVerificacao,
      dataHoraEmissao: dataHoraEmissao,
      competencia: competencia,
      numeroSubstituida: numeroSubstituida,
      naturezaOperacao: naturezaOperacao,
      regimeEspecialTributacao: regimeEspecialTributacao,
      optanteSimplesNacional: optanteSimplesNacional,
      incentivadorCultural: incentivadorCultural,
      numeroRps: numeroRps,
      serieRps: serieRps,
      tipoRps: tipoRps,
      dataEmissaoRps: dataEmissaoRps,
      outrasInformacoes: outrasInformacoes,
      nfseDetalheModelList: nfseDetalheModelListClone(nfseDetalheModelList!),
      nfseIntermediarioModelList: nfseIntermediarioModelListClone(nfseIntermediarioModelList!),
      viewPessoaClienteModel: viewPessoaClienteModel?.clone(),
      osAberturaModel: osAberturaModel?.clone(),
    );
  }

  nfseDetalheModelListClone(List<NfseDetalheModel> nfseDetalheModelList) { 
		List<NfseDetalheModel> resultList = [];
		for (var nfseDetalheModel in nfseDetalheModelList) {
			resultList.add(nfseDetalheModel.clone());
		}
		return resultList;
	}

  nfseIntermediarioModelListClone(List<NfseIntermediarioModel> nfseIntermediarioModelList) { 
		List<NfseIntermediarioModel> resultList = [];
		for (var nfseIntermediarioModel in nfseIntermediarioModelList) {
			resultList.add(nfseIntermediarioModel.clone());
		}
		return resultList;
	}


}