import 'dart:convert';
import 'package:pluto_grid/pluto_grid.dart';
import 'package:nfse/app/data/model/model_imports.dart';

import 'package:nfse/app/data/domain/domain_imports.dart';

class NfseDetalheModel extends ModelBase {
  int? id;
  int? idNfseCabecalho;
  int? idNfseListaServico;
  String? codigoCnae;
  String? codigoTributacaoMunicipio;
  double? valorServicos;
  double? valorDeducoes;
  double? valorPis;
  double? valorCofins;
  double? valorInss;
  double? valorIr;
  double? valorCsll;
  double? valorBaseCalculo;
  double? aliquota;
  double? valorIss;
  double? valorLiquido;
  double? outrasRetencoes;
  double? valorCredito;
  String? issRetido;
  double? valorIssRetido;
  double? valorDescontoCondicionado;
  double? valorDescontoIncondicionado;
  int? municipioPrestacao;
  String? discriminacao;
  NfseListaServicoModel? nfseListaServicoModel;

  NfseDetalheModel({
    this.id,
    this.idNfseCabecalho,
    this.idNfseListaServico,
    this.codigoCnae,
    this.codigoTributacaoMunicipio,
    this.valorServicos,
    this.valorDeducoes,
    this.valorPis,
    this.valorCofins,
    this.valorInss,
    this.valorIr,
    this.valorCsll,
    this.valorBaseCalculo,
    this.aliquota,
    this.valorIss,
    this.valorLiquido,
    this.outrasRetencoes,
    this.valorCredito,
    this.issRetido = 'S',
    this.valorIssRetido,
    this.valorDescontoCondicionado,
    this.valorDescontoIncondicionado,
    this.municipioPrestacao,
    this.discriminacao,
    NfseListaServicoModel? nfseListaServicoModel,
  }) {
    this.nfseListaServicoModel = nfseListaServicoModel ?? NfseListaServicoModel();
  }

  static List<String> dbColumns = <String>[
    'id',
    'codigo_cnae',
    'codigo_nfse_municipio',
    'valor_servicos',
    'valor_deducoes',
    'valor_pis',
    'valor_cofins',
    'valor_inss',
    'valor_ir',
    'valor_csll',
    'valor_base_calculo',
    'aliquota',
    'valor_iss',
    'valor_liquido',
    'outras_retencoes',
    'valor_credito',
    'iss_retido',
    'valor_iss_retido',
    'valor_desconto_condicionado',
    'valor_desconto_incondicionado',
    'municipio_prestacao',
    'discriminacao',
  ];

  static List<String> aliasColumns = <String>[
    'Id',
    'Codigo Cnae',
    'Codigo Tributacao Municipio',
    'Valor Servicos',
    'Valor Deducoes',
    'Valor Pis',
    'Valor Cofins',
    'Valor Inss',
    'Valor Ir',
    'Valor Csll',
    'Valor Base Calculo',
    'Aliquota',
    'Valor Iss',
    'Valor Liquido',
    'Outras Retencoes',
    'Valor Credito',
    'Iss Retido',
    'Valor Iss Retido',
    'Valor Desconto Condicionado',
    'Valor Desconto Incondicionado',
    'Municipio Prestacao',
    'Discriminacao',
  ];

  NfseDetalheModel.fromJson(Map<String, dynamic> jsonData) {
    id = jsonData['id'];
    idNfseCabecalho = jsonData['idNfseCabecalho'];
    idNfseListaServico = jsonData['idNfseListaServico'];
    codigoCnae = jsonData['codigoCnae'];
    codigoTributacaoMunicipio = jsonData['codigoTributacaoMunicipio'];
    valorServicos = jsonData['valorServicos']?.toDouble();
    valorDeducoes = jsonData['valorDeducoes']?.toDouble();
    valorPis = jsonData['valorPis']?.toDouble();
    valorCofins = jsonData['valorCofins']?.toDouble();
    valorInss = jsonData['valorInss']?.toDouble();
    valorIr = jsonData['valorIr']?.toDouble();
    valorCsll = jsonData['valorCsll']?.toDouble();
    valorBaseCalculo = jsonData['valorBaseCalculo']?.toDouble();
    aliquota = jsonData['aliquota']?.toDouble();
    valorIss = jsonData['valorIss']?.toDouble();
    valorLiquido = jsonData['valorLiquido']?.toDouble();
    outrasRetencoes = jsonData['outrasRetencoes']?.toDouble();
    valorCredito = jsonData['valorCredito']?.toDouble();
    issRetido = NfseDetalheDomain.getIssRetido(jsonData['issRetido']);
    valorIssRetido = jsonData['valorIssRetido']?.toDouble();
    valorDescontoCondicionado = jsonData['valorDescontoCondicionado']?.toDouble();
    valorDescontoIncondicionado = jsonData['valorDescontoIncondicionado']?.toDouble();
    municipioPrestacao = jsonData['municipioPrestacao'];
    discriminacao = jsonData['discriminacao'];
    nfseListaServicoModel = jsonData['nfseListaServicoModel'] == null ? NfseListaServicoModel() : NfseListaServicoModel.fromJson(jsonData['nfseListaServicoModel']);
  }

  Map<String, dynamic> get toJson {
    Map<String, dynamic> jsonData = <String, dynamic>{};

    jsonData['id'] = id != 0 ? id : null;
    jsonData['idNfseCabecalho'] = idNfseCabecalho != 0 ? idNfseCabecalho : null;
    jsonData['idNfseListaServico'] = idNfseListaServico != 0 ? idNfseListaServico : null;
    jsonData['codigoCnae'] = codigoCnae;
    jsonData['codigoTributacaoMunicipio'] = codigoTributacaoMunicipio;
    jsonData['valorServicos'] = valorServicos;
    jsonData['valorDeducoes'] = valorDeducoes;
    jsonData['valorPis'] = valorPis;
    jsonData['valorCofins'] = valorCofins;
    jsonData['valorInss'] = valorInss;
    jsonData['valorIr'] = valorIr;
    jsonData['valorCsll'] = valorCsll;
    jsonData['valorBaseCalculo'] = valorBaseCalculo;
    jsonData['aliquota'] = aliquota;
    jsonData['valorIss'] = valorIss;
    jsonData['valorLiquido'] = valorLiquido;
    jsonData['outrasRetencoes'] = outrasRetencoes;
    jsonData['valorCredito'] = valorCredito;
    jsonData['issRetido'] = NfseDetalheDomain.setIssRetido(issRetido);
    jsonData['valorIssRetido'] = valorIssRetido;
    jsonData['valorDescontoCondicionado'] = valorDescontoCondicionado;
    jsonData['valorDescontoIncondicionado'] = valorDescontoIncondicionado;
    jsonData['municipioPrestacao'] = municipioPrestacao;
    jsonData['discriminacao'] = discriminacao;
    jsonData['nfseListaServicoModel'] = nfseListaServicoModel?.toJson;
    jsonData['nfseListaServico'] = nfseListaServicoModel?.descricao ?? '';

    return jsonData;
  }

  String objectEncodeJson() {
    final jsonData = toJson;
    return json.encode(jsonData);
  }

  static NfseDetalheModel fromPlutoRow(PlutoRow row) {
    return NfseDetalheModel(
      id: row.cells['id']?.value,
      idNfseCabecalho: row.cells['idNfseCabecalho']?.value,
      idNfseListaServico: row.cells['idNfseListaServico']?.value,
      codigoCnae: row.cells['codigoCnae']?.value,
      codigoTributacaoMunicipio: row.cells['codigoTributacaoMunicipio']?.value,
      valorServicos: row.cells['valorServicos']?.value,
      valorDeducoes: row.cells['valorDeducoes']?.value,
      valorPis: row.cells['valorPis']?.value,
      valorCofins: row.cells['valorCofins']?.value,
      valorInss: row.cells['valorInss']?.value,
      valorIr: row.cells['valorIr']?.value,
      valorCsll: row.cells['valorCsll']?.value,
      valorBaseCalculo: row.cells['valorBaseCalculo']?.value,
      aliquota: row.cells['aliquota']?.value,
      valorIss: row.cells['valorIss']?.value,
      valorLiquido: row.cells['valorLiquido']?.value,
      outrasRetencoes: row.cells['outrasRetencoes']?.value,
      valorCredito: row.cells['valorCredito']?.value,
      issRetido: row.cells['issRetido']?.value,
      valorIssRetido: row.cells['valorIssRetido']?.value,
      valorDescontoCondicionado: row.cells['valorDescontoCondicionado']?.value,
      valorDescontoIncondicionado: row.cells['valorDescontoIncondicionado']?.value,
      municipioPrestacao: row.cells['municipioPrestacao']?.value,
      discriminacao: row.cells['discriminacao']?.value,
    );
  }

  PlutoRow toPlutoRow() {
    return PlutoRow(
      cells: {
        'tempId': PlutoCell(value: tempId),
        'id': PlutoCell(value: id ?? 0),
        'idNfseCabecalho': PlutoCell(value: idNfseCabecalho ?? 0),
        'idNfseListaServico': PlutoCell(value: idNfseListaServico ?? 0),
        'codigoCnae': PlutoCell(value: codigoCnae ?? ''),
        'codigoTributacaoMunicipio': PlutoCell(value: codigoTributacaoMunicipio ?? ''),
        'valorServicos': PlutoCell(value: valorServicos ?? 0.0),
        'valorDeducoes': PlutoCell(value: valorDeducoes ?? 0.0),
        'valorPis': PlutoCell(value: valorPis ?? 0.0),
        'valorCofins': PlutoCell(value: valorCofins ?? 0.0),
        'valorInss': PlutoCell(value: valorInss ?? 0.0),
        'valorIr': PlutoCell(value: valorIr ?? 0.0),
        'valorCsll': PlutoCell(value: valorCsll ?? 0.0),
        'valorBaseCalculo': PlutoCell(value: valorBaseCalculo ?? 0.0),
        'aliquota': PlutoCell(value: aliquota ?? 0.0),
        'valorIss': PlutoCell(value: valorIss ?? 0.0),
        'valorLiquido': PlutoCell(value: valorLiquido ?? 0.0),
        'outrasRetencoes': PlutoCell(value: outrasRetencoes ?? 0.0),
        'valorCredito': PlutoCell(value: valorCredito ?? 0.0),
        'issRetido': PlutoCell(value: issRetido ?? ''),
        'valorIssRetido': PlutoCell(value: valorIssRetido ?? 0.0),
        'valorDescontoCondicionado': PlutoCell(value: valorDescontoCondicionado ?? 0.0),
        'valorDescontoIncondicionado': PlutoCell(value: valorDescontoIncondicionado ?? 0.0),
        'municipioPrestacao': PlutoCell(value: municipioPrestacao ?? 0),
        'discriminacao': PlutoCell(value: discriminacao ?? ''),
        'nfseListaServico': PlutoCell(value: nfseListaServicoModel?.descricao ?? ''),
      },
    );
  }

  NfseDetalheModel clone() {
    return NfseDetalheModel(
      id: id,
      idNfseCabecalho: idNfseCabecalho,
      idNfseListaServico: idNfseListaServico,
      codigoCnae: codigoCnae,
      codigoTributacaoMunicipio: codigoTributacaoMunicipio,
      valorServicos: valorServicos,
      valorDeducoes: valorDeducoes,
      valorPis: valorPis,
      valorCofins: valorCofins,
      valorInss: valorInss,
      valorIr: valorIr,
      valorCsll: valorCsll,
      valorBaseCalculo: valorBaseCalculo,
      aliquota: aliquota,
      valorIss: valorIss,
      valorLiquido: valorLiquido,
      outrasRetencoes: outrasRetencoes,
      valorCredito: valorCredito,
      issRetido: issRetido,
      valorIssRetido: valorIssRetido,
      valorDescontoCondicionado: valorDescontoCondicionado,
      valorDescontoIncondicionado: valorDescontoIncondicionado,
      municipioPrestacao: municipioPrestacao,
      discriminacao: discriminacao,
      nfseListaServicoModel: nfseListaServicoModel?.clone(),
    );
  }


}