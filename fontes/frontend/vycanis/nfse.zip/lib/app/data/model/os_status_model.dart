import 'dart:convert';
import 'package:pluto_grid/pluto_grid.dart';
import 'package:nfse/app/data/model/model_imports.dart';

import 'package:nfse/app/data/domain/domain_imports.dart';

class OsStatusModel extends ModelBase {
  int? id;
  String? codigo;
  String? nome;
  List<OsAberturaModel>? osAberturaModelList;

  OsStatusModel({
    this.id,
    this.codigo = 'AAA',
    this.nome,
    List<OsAberturaModel>? osAberturaModelList,
  }) {
    this.osAberturaModelList = osAberturaModelList?.toList(growable: true) ?? [];
  }

  static List<String> dbColumns = <String>[
    'id',
    'codigo',
    'nome',
  ];

  static List<String> aliasColumns = <String>[
    'Id',
    'Codigo',
    'Nome',
  ];

  OsStatusModel.fromJson(Map<String, dynamic> jsonData) {
    id = jsonData['id'];
    codigo = OsStatusDomain.getCodigo(jsonData['codigo']);
    nome = jsonData['nome'];
    osAberturaModelList = (jsonData['osAberturaModelList'] as Iterable?)?.map((m) => OsAberturaModel.fromJson(m)).toList() ?? [];
  }

  Map<String, dynamic> get toJson {
    Map<String, dynamic> jsonData = <String, dynamic>{};

    jsonData['id'] = id != 0 ? id : null;
    jsonData['codigo'] = OsStatusDomain.setCodigo(codigo);
    jsonData['nome'] = nome;
    
		var osAberturaModelLocalList = []; 
		for (OsAberturaModel object in osAberturaModelList ?? []) { 
			osAberturaModelLocalList.add(object.toJson); 
		}
		jsonData['osAberturaModelList'] = osAberturaModelLocalList;

    return jsonData;
  }

  String objectEncodeJson() {
    final jsonData = toJson;
    return json.encode(jsonData);
  }

  static OsStatusModel fromPlutoRow(PlutoRow row) {
    return OsStatusModel(
      id: row.cells['id']?.value,
      codigo: row.cells['codigo']?.value,
      nome: row.cells['nome']?.value,
    );
  }

  PlutoRow toPlutoRow() {
    return PlutoRow(
      cells: {
        'tempId': PlutoCell(value: tempId),
        'id': PlutoCell(value: id ?? 0),
        'codigo': PlutoCell(value: codigo ?? ''),
        'nome': PlutoCell(value: nome ?? ''),
      },
    );
  }

  OsStatusModel clone() {
    return OsStatusModel(
      id: id,
      codigo: codigo,
      nome: nome,
      osAberturaModelList: osAberturaModelListClone(osAberturaModelList!),
    );
  }

  osAberturaModelListClone(List<OsAberturaModel> osAberturaModelList) { 
		List<OsAberturaModel> resultList = [];
		for (var osAberturaModel in osAberturaModelList) {
			resultList.add(osAberturaModel.clone());
		}
		return resultList;
	}


}