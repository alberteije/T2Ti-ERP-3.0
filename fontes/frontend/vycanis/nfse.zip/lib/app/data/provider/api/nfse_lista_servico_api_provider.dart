import 'package:nfse/app/data/provider/api/api_provider_base.dart';
import 'package:nfse/app/data/model/model_imports.dart';

class NfseListaServicoApiProvider extends ApiProviderBase {
  static const _path = '/nfse-lista-servico';

  Future<List<NfseListaServicoModel>?> getList({Filter? filter}) {
    return super.getListBase(
      '$_path/',
      (json) => NfseListaServicoModel.fromJson(json),
      filter: filter,
    );
  }

  Future<NfseListaServicoModel?> getObject(dynamic pk) {
    return super.getObjectBase(
      _path,
      pk,
      (json) => NfseListaServicoModel.fromJson(json),
    );
  }

  Future<NfseListaServicoModel?>? insert(NfseListaServicoModel model) {
    return super.insertBase(
      _path,
      model,
      (json) => NfseListaServicoModel.fromJson(json),
    );
  }

  Future<NfseListaServicoModel?>? update(NfseListaServicoModel model) {
    return super.updateBase(
      _path,
      model,
      (json) => NfseListaServicoModel.fromJson(json),
    );
  }

  Future<bool?> delete(dynamic pk) {
    return super.deleteBase(_path, pk);
  }
}
