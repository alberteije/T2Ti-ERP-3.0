// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'nfse_cabecalho_dao.dart';

// ignore_for_file: type=lint
mixin _$NfseCabecalhoDaoMixin on DatabaseAccessor<AppDatabase> {
  $NfseCabecalhosTable get nfseCabecalhos => attachedDatabase.nfseCabecalhos;
  $NfseDetalhesTable get nfseDetalhes => attachedDatabase.nfseDetalhes;
  $NfseListaServicosTable get nfseListaServicos =>
      attachedDatabase.nfseListaServicos;
  $NfseIntermediariosTable get nfseIntermediarios =>
      attachedDatabase.nfseIntermediarios;
  $ViewPessoaClientesTable get viewPessoaClientes =>
      attachedDatabase.viewPessoaClientes;
  $OsAberturasTable get osAberturas => attachedDatabase.osAberturas;
}
