import 'package:nfse/app/data/provider/api/api_provider_base.dart';
import 'package:nfse/app/data/model/model_imports.dart';

class OsStatusApiProvider extends ApiProviderBase {
  static const _path = '/os-status';

  Future<List<OsStatusModel>?> getList({Filter? filter}) {
    return super.getListBase(
      '$_path/',
      (json) => OsStatusModel.fromJson(json),
      filter: filter,
    );
  }

  Future<OsStatusModel?> getObject(dynamic pk) {
    return super.getObjectBase(
      _path,
      pk,
      (json) => OsStatusModel.fromJson(json),
    );
  }

  Future<OsStatusModel?>? insert(OsStatusModel model) {
    return super.insertBase(
      _path,
      model,
      (json) => OsStatusModel.fromJson(json),
    );
  }

  Future<OsStatusModel?>? update(OsStatusModel model) {
    return super.updateBase(
      _path,
      model,
      (json) => OsStatusModel.fromJson(json),
    );
  }

  Future<bool?> delete(dynamic pk) {
    return super.deleteBase(_path, pk);
  }
}
