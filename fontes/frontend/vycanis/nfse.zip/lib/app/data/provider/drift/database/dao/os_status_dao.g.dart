// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'os_status_dao.dart';

// ignore_for_file: type=lint
mixin _$OsStatusDaoMixin on DatabaseAccessor<AppDatabase> {
  $OsStatussTable get osStatuss => attachedDatabase.osStatuss;
  $OsAberturasTable get osAberturas => attachedDatabase.osAberturas;
  $ViewPessoaColaboradorsTable get viewPessoaColaboradors =>
      attachedDatabase.viewPessoaColaboradors;
  $ViewPessoaClientesTable get viewPessoaClientes =>
      attachedDatabase.viewPessoaClientes;
}
