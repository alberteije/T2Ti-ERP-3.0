// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'database.dart';

// ignore_for_file: type=lint
class $OsAberturasTable extends OsAberturas
    with TableInfo<$OsAberturasTable, OsAbertura> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $OsAberturasTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
      'id', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _idOsStatusMeta =
      const VerificationMeta('idOsStatus');
  @override
  late final GeneratedColumn<int> idOsStatus = GeneratedColumn<int>(
      'id_os_status', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _idColaboradorMeta =
      const VerificationMeta('idColaborador');
  @override
  late final GeneratedColumn<int> idColaborador = GeneratedColumn<int>(
      'id_colaborador', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _idClienteMeta =
      const VerificationMeta('idCliente');
  @override
  late final GeneratedColumn<int> idCliente = GeneratedColumn<int>(
      'id_cliente', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _numeroMeta = const VerificationMeta('numero');
  @override
  late final GeneratedColumn<String> numero = GeneratedColumn<String>(
      'numero', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 20),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _dataInicioMeta =
      const VerificationMeta('dataInicio');
  @override
  late final GeneratedColumn<DateTime> dataInicio = GeneratedColumn<DateTime>(
      'data_inicio', aliasedName, true,
      type: DriftSqlType.dateTime, requiredDuringInsert: false);
  static const VerificationMeta _horaInicioMeta =
      const VerificationMeta('horaInicio');
  @override
  late final GeneratedColumn<String> horaInicio = GeneratedColumn<String>(
      'hora_inicio', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 8),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _dataPrevisaoMeta =
      const VerificationMeta('dataPrevisao');
  @override
  late final GeneratedColumn<DateTime> dataPrevisao = GeneratedColumn<DateTime>(
      'data_previsao', aliasedName, true,
      type: DriftSqlType.dateTime, requiredDuringInsert: false);
  static const VerificationMeta _horaPrevisaoMeta =
      const VerificationMeta('horaPrevisao');
  @override
  late final GeneratedColumn<String> horaPrevisao = GeneratedColumn<String>(
      'hora_previsao', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 8),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _dataFimMeta =
      const VerificationMeta('dataFim');
  @override
  late final GeneratedColumn<DateTime> dataFim = GeneratedColumn<DateTime>(
      'data_fim', aliasedName, true,
      type: DriftSqlType.dateTime, requiredDuringInsert: false);
  static const VerificationMeta _horaFimMeta =
      const VerificationMeta('horaFim');
  @override
  late final GeneratedColumn<String> horaFim = GeneratedColumn<String>(
      'hora_fim', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 8),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _nomeContatoMeta =
      const VerificationMeta('nomeContato');
  @override
  late final GeneratedColumn<String> nomeContato = GeneratedColumn<String>(
      'nome_contato', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 50),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _foneContatoMeta =
      const VerificationMeta('foneContato');
  @override
  late final GeneratedColumn<String> foneContato = GeneratedColumn<String>(
      'fone_contato', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 15),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _observacaoClienteMeta =
      const VerificationMeta('observacaoCliente');
  @override
  late final GeneratedColumn<String> observacaoCliente =
      GeneratedColumn<String>('observacao_cliente', aliasedName, true,
          type: DriftSqlType.string, requiredDuringInsert: false);
  static const VerificationMeta _observacaoAberturaMeta =
      const VerificationMeta('observacaoAbertura');
  @override
  late final GeneratedColumn<String> observacaoAbertura =
      GeneratedColumn<String>('observacao_abertura', aliasedName, true,
          type: DriftSqlType.string, requiredDuringInsert: false);
  @override
  List<GeneratedColumn> get $columns => [
        id,
        idOsStatus,
        idColaborador,
        idCliente,
        numero,
        dataInicio,
        horaInicio,
        dataPrevisao,
        horaPrevisao,
        dataFim,
        horaFim,
        nomeContato,
        foneContato,
        observacaoCliente,
        observacaoAbertura
      ];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'os_abertura';
  @override
  VerificationContext validateIntegrity(Insertable<OsAbertura> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('id_os_status')) {
      context.handle(
          _idOsStatusMeta,
          idOsStatus.isAcceptableOrUnknown(
              data['id_os_status']!, _idOsStatusMeta));
    }
    if (data.containsKey('id_colaborador')) {
      context.handle(
          _idColaboradorMeta,
          idColaborador.isAcceptableOrUnknown(
              data['id_colaborador']!, _idColaboradorMeta));
    }
    if (data.containsKey('id_cliente')) {
      context.handle(_idClienteMeta,
          idCliente.isAcceptableOrUnknown(data['id_cliente']!, _idClienteMeta));
    }
    if (data.containsKey('numero')) {
      context.handle(_numeroMeta,
          numero.isAcceptableOrUnknown(data['numero']!, _numeroMeta));
    }
    if (data.containsKey('data_inicio')) {
      context.handle(
          _dataInicioMeta,
          dataInicio.isAcceptableOrUnknown(
              data['data_inicio']!, _dataInicioMeta));
    }
    if (data.containsKey('hora_inicio')) {
      context.handle(
          _horaInicioMeta,
          horaInicio.isAcceptableOrUnknown(
              data['hora_inicio']!, _horaInicioMeta));
    }
    if (data.containsKey('data_previsao')) {
      context.handle(
          _dataPrevisaoMeta,
          dataPrevisao.isAcceptableOrUnknown(
              data['data_previsao']!, _dataPrevisaoMeta));
    }
    if (data.containsKey('hora_previsao')) {
      context.handle(
          _horaPrevisaoMeta,
          horaPrevisao.isAcceptableOrUnknown(
              data['hora_previsao']!, _horaPrevisaoMeta));
    }
    if (data.containsKey('data_fim')) {
      context.handle(_dataFimMeta,
          dataFim.isAcceptableOrUnknown(data['data_fim']!, _dataFimMeta));
    }
    if (data.containsKey('hora_fim')) {
      context.handle(_horaFimMeta,
          horaFim.isAcceptableOrUnknown(data['hora_fim']!, _horaFimMeta));
    }
    if (data.containsKey('nome_contato')) {
      context.handle(
          _nomeContatoMeta,
          nomeContato.isAcceptableOrUnknown(
              data['nome_contato']!, _nomeContatoMeta));
    }
    if (data.containsKey('fone_contato')) {
      context.handle(
          _foneContatoMeta,
          foneContato.isAcceptableOrUnknown(
              data['fone_contato']!, _foneContatoMeta));
    }
    if (data.containsKey('observacao_cliente')) {
      context.handle(
          _observacaoClienteMeta,
          observacaoCliente.isAcceptableOrUnknown(
              data['observacao_cliente']!, _observacaoClienteMeta));
    }
    if (data.containsKey('observacao_abertura')) {
      context.handle(
          _observacaoAberturaMeta,
          observacaoAbertura.isAcceptableOrUnknown(
              data['observacao_abertura']!, _observacaoAberturaMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  OsAbertura map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return OsAbertura(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id']),
      idOsStatus: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id_os_status']),
      idColaborador: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id_colaborador']),
      idCliente: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id_cliente']),
      numero: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}numero']),
      dataInicio: attachedDatabase.typeMapping
          .read(DriftSqlType.dateTime, data['${effectivePrefix}data_inicio']),
      horaInicio: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}hora_inicio']),
      dataPrevisao: attachedDatabase.typeMapping
          .read(DriftSqlType.dateTime, data['${effectivePrefix}data_previsao']),
      horaPrevisao: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}hora_previsao']),
      dataFim: attachedDatabase.typeMapping
          .read(DriftSqlType.dateTime, data['${effectivePrefix}data_fim']),
      horaFim: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}hora_fim']),
      nomeContato: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}nome_contato']),
      foneContato: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}fone_contato']),
      observacaoCliente: attachedDatabase.typeMapping.read(
          DriftSqlType.string, data['${effectivePrefix}observacao_cliente']),
      observacaoAbertura: attachedDatabase.typeMapping.read(
          DriftSqlType.string, data['${effectivePrefix}observacao_abertura']),
    );
  }

  @override
  $OsAberturasTable createAlias(String alias) {
    return $OsAberturasTable(attachedDatabase, alias);
  }
}

class OsAbertura extends DataClass implements Insertable<OsAbertura> {
  final int? id;
  final int? idOsStatus;
  final int? idColaborador;
  final int? idCliente;
  final String? numero;
  final DateTime? dataInicio;
  final String? horaInicio;
  final DateTime? dataPrevisao;
  final String? horaPrevisao;
  final DateTime? dataFim;
  final String? horaFim;
  final String? nomeContato;
  final String? foneContato;
  final String? observacaoCliente;
  final String? observacaoAbertura;
  const OsAbertura(
      {this.id,
      this.idOsStatus,
      this.idColaborador,
      this.idCliente,
      this.numero,
      this.dataInicio,
      this.horaInicio,
      this.dataPrevisao,
      this.horaPrevisao,
      this.dataFim,
      this.horaFim,
      this.nomeContato,
      this.foneContato,
      this.observacaoCliente,
      this.observacaoAbertura});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || idOsStatus != null) {
      map['id_os_status'] = Variable<int>(idOsStatus);
    }
    if (!nullToAbsent || idColaborador != null) {
      map['id_colaborador'] = Variable<int>(idColaborador);
    }
    if (!nullToAbsent || idCliente != null) {
      map['id_cliente'] = Variable<int>(idCliente);
    }
    if (!nullToAbsent || numero != null) {
      map['numero'] = Variable<String>(numero);
    }
    if (!nullToAbsent || dataInicio != null) {
      map['data_inicio'] = Variable<DateTime>(dataInicio);
    }
    if (!nullToAbsent || horaInicio != null) {
      map['hora_inicio'] = Variable<String>(horaInicio);
    }
    if (!nullToAbsent || dataPrevisao != null) {
      map['data_previsao'] = Variable<DateTime>(dataPrevisao);
    }
    if (!nullToAbsent || horaPrevisao != null) {
      map['hora_previsao'] = Variable<String>(horaPrevisao);
    }
    if (!nullToAbsent || dataFim != null) {
      map['data_fim'] = Variable<DateTime>(dataFim);
    }
    if (!nullToAbsent || horaFim != null) {
      map['hora_fim'] = Variable<String>(horaFim);
    }
    if (!nullToAbsent || nomeContato != null) {
      map['nome_contato'] = Variable<String>(nomeContato);
    }
    if (!nullToAbsent || foneContato != null) {
      map['fone_contato'] = Variable<String>(foneContato);
    }
    if (!nullToAbsent || observacaoCliente != null) {
      map['observacao_cliente'] = Variable<String>(observacaoCliente);
    }
    if (!nullToAbsent || observacaoAbertura != null) {
      map['observacao_abertura'] = Variable<String>(observacaoAbertura);
    }
    return map;
  }

  factory OsAbertura.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return OsAbertura(
      id: serializer.fromJson<int?>(json['id']),
      idOsStatus: serializer.fromJson<int?>(json['idOsStatus']),
      idColaborador: serializer.fromJson<int?>(json['idColaborador']),
      idCliente: serializer.fromJson<int?>(json['idCliente']),
      numero: serializer.fromJson<String?>(json['numero']),
      dataInicio: serializer.fromJson<DateTime?>(json['dataInicio']),
      horaInicio: serializer.fromJson<String?>(json['horaInicio']),
      dataPrevisao: serializer.fromJson<DateTime?>(json['dataPrevisao']),
      horaPrevisao: serializer.fromJson<String?>(json['horaPrevisao']),
      dataFim: serializer.fromJson<DateTime?>(json['dataFim']),
      horaFim: serializer.fromJson<String?>(json['horaFim']),
      nomeContato: serializer.fromJson<String?>(json['nomeContato']),
      foneContato: serializer.fromJson<String?>(json['foneContato']),
      observacaoCliente:
          serializer.fromJson<String?>(json['observacaoCliente']),
      observacaoAbertura:
          serializer.fromJson<String?>(json['observacaoAbertura']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'idOsStatus': serializer.toJson<int?>(idOsStatus),
      'idColaborador': serializer.toJson<int?>(idColaborador),
      'idCliente': serializer.toJson<int?>(idCliente),
      'numero': serializer.toJson<String?>(numero),
      'dataInicio': serializer.toJson<DateTime?>(dataInicio),
      'horaInicio': serializer.toJson<String?>(horaInicio),
      'dataPrevisao': serializer.toJson<DateTime?>(dataPrevisao),
      'horaPrevisao': serializer.toJson<String?>(horaPrevisao),
      'dataFim': serializer.toJson<DateTime?>(dataFim),
      'horaFim': serializer.toJson<String?>(horaFim),
      'nomeContato': serializer.toJson<String?>(nomeContato),
      'foneContato': serializer.toJson<String?>(foneContato),
      'observacaoCliente': serializer.toJson<String?>(observacaoCliente),
      'observacaoAbertura': serializer.toJson<String?>(observacaoAbertura),
    };
  }

  OsAbertura copyWith(
          {Value<int?> id = const Value.absent(),
          Value<int?> idOsStatus = const Value.absent(),
          Value<int?> idColaborador = const Value.absent(),
          Value<int?> idCliente = const Value.absent(),
          Value<String?> numero = const Value.absent(),
          Value<DateTime?> dataInicio = const Value.absent(),
          Value<String?> horaInicio = const Value.absent(),
          Value<DateTime?> dataPrevisao = const Value.absent(),
          Value<String?> horaPrevisao = const Value.absent(),
          Value<DateTime?> dataFim = const Value.absent(),
          Value<String?> horaFim = const Value.absent(),
          Value<String?> nomeContato = const Value.absent(),
          Value<String?> foneContato = const Value.absent(),
          Value<String?> observacaoCliente = const Value.absent(),
          Value<String?> observacaoAbertura = const Value.absent()}) =>
      OsAbertura(
        id: id.present ? id.value : this.id,
        idOsStatus: idOsStatus.present ? idOsStatus.value : this.idOsStatus,
        idColaborador:
            idColaborador.present ? idColaborador.value : this.idColaborador,
        idCliente: idCliente.present ? idCliente.value : this.idCliente,
        numero: numero.present ? numero.value : this.numero,
        dataInicio: dataInicio.present ? dataInicio.value : this.dataInicio,
        horaInicio: horaInicio.present ? horaInicio.value : this.horaInicio,
        dataPrevisao:
            dataPrevisao.present ? dataPrevisao.value : this.dataPrevisao,
        horaPrevisao:
            horaPrevisao.present ? horaPrevisao.value : this.horaPrevisao,
        dataFim: dataFim.present ? dataFim.value : this.dataFim,
        horaFim: horaFim.present ? horaFim.value : this.horaFim,
        nomeContato: nomeContato.present ? nomeContato.value : this.nomeContato,
        foneContato: foneContato.present ? foneContato.value : this.foneContato,
        observacaoCliente: observacaoCliente.present
            ? observacaoCliente.value
            : this.observacaoCliente,
        observacaoAbertura: observacaoAbertura.present
            ? observacaoAbertura.value
            : this.observacaoAbertura,
      );
  OsAbertura copyWithCompanion(OsAberturasCompanion data) {
    return OsAbertura(
      id: data.id.present ? data.id.value : this.id,
      idOsStatus:
          data.idOsStatus.present ? data.idOsStatus.value : this.idOsStatus,
      idColaborador: data.idColaborador.present
          ? data.idColaborador.value
          : this.idColaborador,
      idCliente: data.idCliente.present ? data.idCliente.value : this.idCliente,
      numero: data.numero.present ? data.numero.value : this.numero,
      dataInicio:
          data.dataInicio.present ? data.dataInicio.value : this.dataInicio,
      horaInicio:
          data.horaInicio.present ? data.horaInicio.value : this.horaInicio,
      dataPrevisao: data.dataPrevisao.present
          ? data.dataPrevisao.value
          : this.dataPrevisao,
      horaPrevisao: data.horaPrevisao.present
          ? data.horaPrevisao.value
          : this.horaPrevisao,
      dataFim: data.dataFim.present ? data.dataFim.value : this.dataFim,
      horaFim: data.horaFim.present ? data.horaFim.value : this.horaFim,
      nomeContato:
          data.nomeContato.present ? data.nomeContato.value : this.nomeContato,
      foneContato:
          data.foneContato.present ? data.foneContato.value : this.foneContato,
      observacaoCliente: data.observacaoCliente.present
          ? data.observacaoCliente.value
          : this.observacaoCliente,
      observacaoAbertura: data.observacaoAbertura.present
          ? data.observacaoAbertura.value
          : this.observacaoAbertura,
    );
  }

  @override
  String toString() {
    return (StringBuffer('OsAbertura(')
          ..write('id: $id, ')
          ..write('idOsStatus: $idOsStatus, ')
          ..write('idColaborador: $idColaborador, ')
          ..write('idCliente: $idCliente, ')
          ..write('numero: $numero, ')
          ..write('dataInicio: $dataInicio, ')
          ..write('horaInicio: $horaInicio, ')
          ..write('dataPrevisao: $dataPrevisao, ')
          ..write('horaPrevisao: $horaPrevisao, ')
          ..write('dataFim: $dataFim, ')
          ..write('horaFim: $horaFim, ')
          ..write('nomeContato: $nomeContato, ')
          ..write('foneContato: $foneContato, ')
          ..write('observacaoCliente: $observacaoCliente, ')
          ..write('observacaoAbertura: $observacaoAbertura')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(
      id,
      idOsStatus,
      idColaborador,
      idCliente,
      numero,
      dataInicio,
      horaInicio,
      dataPrevisao,
      horaPrevisao,
      dataFim,
      horaFim,
      nomeContato,
      foneContato,
      observacaoCliente,
      observacaoAbertura);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is OsAbertura &&
          other.id == this.id &&
          other.idOsStatus == this.idOsStatus &&
          other.idColaborador == this.idColaborador &&
          other.idCliente == this.idCliente &&
          other.numero == this.numero &&
          other.dataInicio == this.dataInicio &&
          other.horaInicio == this.horaInicio &&
          other.dataPrevisao == this.dataPrevisao &&
          other.horaPrevisao == this.horaPrevisao &&
          other.dataFim == this.dataFim &&
          other.horaFim == this.horaFim &&
          other.nomeContato == this.nomeContato &&
          other.foneContato == this.foneContato &&
          other.observacaoCliente == this.observacaoCliente &&
          other.observacaoAbertura == this.observacaoAbertura);
}

class OsAberturasCompanion extends UpdateCompanion<OsAbertura> {
  final Value<int?> id;
  final Value<int?> idOsStatus;
  final Value<int?> idColaborador;
  final Value<int?> idCliente;
  final Value<String?> numero;
  final Value<DateTime?> dataInicio;
  final Value<String?> horaInicio;
  final Value<DateTime?> dataPrevisao;
  final Value<String?> horaPrevisao;
  final Value<DateTime?> dataFim;
  final Value<String?> horaFim;
  final Value<String?> nomeContato;
  final Value<String?> foneContato;
  final Value<String?> observacaoCliente;
  final Value<String?> observacaoAbertura;
  const OsAberturasCompanion({
    this.id = const Value.absent(),
    this.idOsStatus = const Value.absent(),
    this.idColaborador = const Value.absent(),
    this.idCliente = const Value.absent(),
    this.numero = const Value.absent(),
    this.dataInicio = const Value.absent(),
    this.horaInicio = const Value.absent(),
    this.dataPrevisao = const Value.absent(),
    this.horaPrevisao = const Value.absent(),
    this.dataFim = const Value.absent(),
    this.horaFim = const Value.absent(),
    this.nomeContato = const Value.absent(),
    this.foneContato = const Value.absent(),
    this.observacaoCliente = const Value.absent(),
    this.observacaoAbertura = const Value.absent(),
  });
  OsAberturasCompanion.insert({
    this.id = const Value.absent(),
    this.idOsStatus = const Value.absent(),
    this.idColaborador = const Value.absent(),
    this.idCliente = const Value.absent(),
    this.numero = const Value.absent(),
    this.dataInicio = const Value.absent(),
    this.horaInicio = const Value.absent(),
    this.dataPrevisao = const Value.absent(),
    this.horaPrevisao = const Value.absent(),
    this.dataFim = const Value.absent(),
    this.horaFim = const Value.absent(),
    this.nomeContato = const Value.absent(),
    this.foneContato = const Value.absent(),
    this.observacaoCliente = const Value.absent(),
    this.observacaoAbertura = const Value.absent(),
  });
  static Insertable<OsAbertura> custom({
    Expression<int>? id,
    Expression<int>? idOsStatus,
    Expression<int>? idColaborador,
    Expression<int>? idCliente,
    Expression<String>? numero,
    Expression<DateTime>? dataInicio,
    Expression<String>? horaInicio,
    Expression<DateTime>? dataPrevisao,
    Expression<String>? horaPrevisao,
    Expression<DateTime>? dataFim,
    Expression<String>? horaFim,
    Expression<String>? nomeContato,
    Expression<String>? foneContato,
    Expression<String>? observacaoCliente,
    Expression<String>? observacaoAbertura,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (idOsStatus != null) 'id_os_status': idOsStatus,
      if (idColaborador != null) 'id_colaborador': idColaborador,
      if (idCliente != null) 'id_cliente': idCliente,
      if (numero != null) 'numero': numero,
      if (dataInicio != null) 'data_inicio': dataInicio,
      if (horaInicio != null) 'hora_inicio': horaInicio,
      if (dataPrevisao != null) 'data_previsao': dataPrevisao,
      if (horaPrevisao != null) 'hora_previsao': horaPrevisao,
      if (dataFim != null) 'data_fim': dataFim,
      if (horaFim != null) 'hora_fim': horaFim,
      if (nomeContato != null) 'nome_contato': nomeContato,
      if (foneContato != null) 'fone_contato': foneContato,
      if (observacaoCliente != null) 'observacao_cliente': observacaoCliente,
      if (observacaoAbertura != null) 'observacao_abertura': observacaoAbertura,
    });
  }

  OsAberturasCompanion copyWith(
      {Value<int?>? id,
      Value<int?>? idOsStatus,
      Value<int?>? idColaborador,
      Value<int?>? idCliente,
      Value<String?>? numero,
      Value<DateTime?>? dataInicio,
      Value<String?>? horaInicio,
      Value<DateTime?>? dataPrevisao,
      Value<String?>? horaPrevisao,
      Value<DateTime?>? dataFim,
      Value<String?>? horaFim,
      Value<String?>? nomeContato,
      Value<String?>? foneContato,
      Value<String?>? observacaoCliente,
      Value<String?>? observacaoAbertura}) {
    return OsAberturasCompanion(
      id: id ?? this.id,
      idOsStatus: idOsStatus ?? this.idOsStatus,
      idColaborador: idColaborador ?? this.idColaborador,
      idCliente: idCliente ?? this.idCliente,
      numero: numero ?? this.numero,
      dataInicio: dataInicio ?? this.dataInicio,
      horaInicio: horaInicio ?? this.horaInicio,
      dataPrevisao: dataPrevisao ?? this.dataPrevisao,
      horaPrevisao: horaPrevisao ?? this.horaPrevisao,
      dataFim: dataFim ?? this.dataFim,
      horaFim: horaFim ?? this.horaFim,
      nomeContato: nomeContato ?? this.nomeContato,
      foneContato: foneContato ?? this.foneContato,
      observacaoCliente: observacaoCliente ?? this.observacaoCliente,
      observacaoAbertura: observacaoAbertura ?? this.observacaoAbertura,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (idOsStatus.present) {
      map['id_os_status'] = Variable<int>(idOsStatus.value);
    }
    if (idColaborador.present) {
      map['id_colaborador'] = Variable<int>(idColaborador.value);
    }
    if (idCliente.present) {
      map['id_cliente'] = Variable<int>(idCliente.value);
    }
    if (numero.present) {
      map['numero'] = Variable<String>(numero.value);
    }
    if (dataInicio.present) {
      map['data_inicio'] = Variable<DateTime>(dataInicio.value);
    }
    if (horaInicio.present) {
      map['hora_inicio'] = Variable<String>(horaInicio.value);
    }
    if (dataPrevisao.present) {
      map['data_previsao'] = Variable<DateTime>(dataPrevisao.value);
    }
    if (horaPrevisao.present) {
      map['hora_previsao'] = Variable<String>(horaPrevisao.value);
    }
    if (dataFim.present) {
      map['data_fim'] = Variable<DateTime>(dataFim.value);
    }
    if (horaFim.present) {
      map['hora_fim'] = Variable<String>(horaFim.value);
    }
    if (nomeContato.present) {
      map['nome_contato'] = Variable<String>(nomeContato.value);
    }
    if (foneContato.present) {
      map['fone_contato'] = Variable<String>(foneContato.value);
    }
    if (observacaoCliente.present) {
      map['observacao_cliente'] = Variable<String>(observacaoCliente.value);
    }
    if (observacaoAbertura.present) {
      map['observacao_abertura'] = Variable<String>(observacaoAbertura.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('OsAberturasCompanion(')
          ..write('id: $id, ')
          ..write('idOsStatus: $idOsStatus, ')
          ..write('idColaborador: $idColaborador, ')
          ..write('idCliente: $idCliente, ')
          ..write('numero: $numero, ')
          ..write('dataInicio: $dataInicio, ')
          ..write('horaInicio: $horaInicio, ')
          ..write('dataPrevisao: $dataPrevisao, ')
          ..write('horaPrevisao: $horaPrevisao, ')
          ..write('dataFim: $dataFim, ')
          ..write('horaFim: $horaFim, ')
          ..write('nomeContato: $nomeContato, ')
          ..write('foneContato: $foneContato, ')
          ..write('observacaoCliente: $observacaoCliente, ')
          ..write('observacaoAbertura: $observacaoAbertura')
          ..write(')'))
        .toString();
  }
}

class $NfseDetalhesTable extends NfseDetalhes
    with TableInfo<$NfseDetalhesTable, NfseDetalhe> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $NfseDetalhesTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
      'id', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _idNfseCabecalhoMeta =
      const VerificationMeta('idNfseCabecalho');
  @override
  late final GeneratedColumn<int> idNfseCabecalho = GeneratedColumn<int>(
      'id_nfse_cabecalho', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _idNfseListaServicoMeta =
      const VerificationMeta('idNfseListaServico');
  @override
  late final GeneratedColumn<int> idNfseListaServico = GeneratedColumn<int>(
      'id_nfse_lista_servico', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _codigoCnaeMeta =
      const VerificationMeta('codigoCnae');
  @override
  late final GeneratedColumn<String> codigoCnae = GeneratedColumn<String>(
      'codigo_cnae', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 7),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _codigoTributacaoMunicipioMeta =
      const VerificationMeta('codigoTributacaoMunicipio');
  @override
  late final GeneratedColumn<String> codigoTributacaoMunicipio =
      GeneratedColumn<String>('codigo_tributacao_municipio', aliasedName, true,
          additionalChecks: GeneratedColumn.checkTextLength(
              minTextLength: 0, maxTextLength: 20),
          type: DriftSqlType.string,
          requiredDuringInsert: false);
  static const VerificationMeta _valorServicosMeta =
      const VerificationMeta('valorServicos');
  @override
  late final GeneratedColumn<double> valorServicos = GeneratedColumn<double>(
      'valor_servicos', aliasedName, true,
      type: DriftSqlType.double, requiredDuringInsert: false);
  static const VerificationMeta _valorDeducoesMeta =
      const VerificationMeta('valorDeducoes');
  @override
  late final GeneratedColumn<double> valorDeducoes = GeneratedColumn<double>(
      'valor_deducoes', aliasedName, true,
      type: DriftSqlType.double, requiredDuringInsert: false);
  static const VerificationMeta _valorPisMeta =
      const VerificationMeta('valorPis');
  @override
  late final GeneratedColumn<double> valorPis = GeneratedColumn<double>(
      'valor_pis', aliasedName, true,
      type: DriftSqlType.double, requiredDuringInsert: false);
  static const VerificationMeta _valorCofinsMeta =
      const VerificationMeta('valorCofins');
  @override
  late final GeneratedColumn<double> valorCofins = GeneratedColumn<double>(
      'valor_cofins', aliasedName, true,
      type: DriftSqlType.double, requiredDuringInsert: false);
  static const VerificationMeta _valorInssMeta =
      const VerificationMeta('valorInss');
  @override
  late final GeneratedColumn<double> valorInss = GeneratedColumn<double>(
      'valor_inss', aliasedName, true,
      type: DriftSqlType.double, requiredDuringInsert: false);
  static const VerificationMeta _valorIrMeta =
      const VerificationMeta('valorIr');
  @override
  late final GeneratedColumn<double> valorIr = GeneratedColumn<double>(
      'valor_ir', aliasedName, true,
      type: DriftSqlType.double, requiredDuringInsert: false);
  static const VerificationMeta _valorCsllMeta =
      const VerificationMeta('valorCsll');
  @override
  late final GeneratedColumn<double> valorCsll = GeneratedColumn<double>(
      'valor_csll', aliasedName, true,
      type: DriftSqlType.double, requiredDuringInsert: false);
  static const VerificationMeta _valorBaseCalculoMeta =
      const VerificationMeta('valorBaseCalculo');
  @override
  late final GeneratedColumn<double> valorBaseCalculo = GeneratedColumn<double>(
      'valor_base_calculo', aliasedName, true,
      type: DriftSqlType.double, requiredDuringInsert: false);
  static const VerificationMeta _aliquotaMeta =
      const VerificationMeta('aliquota');
  @override
  late final GeneratedColumn<double> aliquota = GeneratedColumn<double>(
      'aliquota', aliasedName, true,
      type: DriftSqlType.double, requiredDuringInsert: false);
  static const VerificationMeta _valorIssMeta =
      const VerificationMeta('valorIss');
  @override
  late final GeneratedColumn<double> valorIss = GeneratedColumn<double>(
      'valor_iss', aliasedName, true,
      type: DriftSqlType.double, requiredDuringInsert: false);
  static const VerificationMeta _valorLiquidoMeta =
      const VerificationMeta('valorLiquido');
  @override
  late final GeneratedColumn<double> valorLiquido = GeneratedColumn<double>(
      'valor_liquido', aliasedName, true,
      type: DriftSqlType.double, requiredDuringInsert: false);
  static const VerificationMeta _outrasRetencoesMeta =
      const VerificationMeta('outrasRetencoes');
  @override
  late final GeneratedColumn<double> outrasRetencoes = GeneratedColumn<double>(
      'outras_retencoes', aliasedName, true,
      type: DriftSqlType.double, requiredDuringInsert: false);
  static const VerificationMeta _valorCreditoMeta =
      const VerificationMeta('valorCredito');
  @override
  late final GeneratedColumn<double> valorCredito = GeneratedColumn<double>(
      'valor_credito', aliasedName, true,
      type: DriftSqlType.double, requiredDuringInsert: false);
  static const VerificationMeta _issRetidoMeta =
      const VerificationMeta('issRetido');
  @override
  late final GeneratedColumn<String> issRetido = GeneratedColumn<String>(
      'iss_retido', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 1),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _valorIssRetidoMeta =
      const VerificationMeta('valorIssRetido');
  @override
  late final GeneratedColumn<double> valorIssRetido = GeneratedColumn<double>(
      'valor_iss_retido', aliasedName, true,
      type: DriftSqlType.double, requiredDuringInsert: false);
  static const VerificationMeta _valorDescontoCondicionadoMeta =
      const VerificationMeta('valorDescontoCondicionado');
  @override
  late final GeneratedColumn<double> valorDescontoCondicionado =
      GeneratedColumn<double>('valor_desconto_condicionado', aliasedName, true,
          type: DriftSqlType.double, requiredDuringInsert: false);
  static const VerificationMeta _valorDescontoIncondicionadoMeta =
      const VerificationMeta('valorDescontoIncondicionado');
  @override
  late final GeneratedColumn<double> valorDescontoIncondicionado =
      GeneratedColumn<double>(
          'valor_desconto_incondicionado', aliasedName, true,
          type: DriftSqlType.double, requiredDuringInsert: false);
  static const VerificationMeta _municipioPrestacaoMeta =
      const VerificationMeta('municipioPrestacao');
  @override
  late final GeneratedColumn<int> municipioPrestacao = GeneratedColumn<int>(
      'municipio_prestacao', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _discriminacaoMeta =
      const VerificationMeta('discriminacao');
  @override
  late final GeneratedColumn<String> discriminacao = GeneratedColumn<String>(
      'discriminacao', aliasedName, true,
      type: DriftSqlType.string, requiredDuringInsert: false);
  @override
  List<GeneratedColumn> get $columns => [
        id,
        idNfseCabecalho,
        idNfseListaServico,
        codigoCnae,
        codigoTributacaoMunicipio,
        valorServicos,
        valorDeducoes,
        valorPis,
        valorCofins,
        valorInss,
        valorIr,
        valorCsll,
        valorBaseCalculo,
        aliquota,
        valorIss,
        valorLiquido,
        outrasRetencoes,
        valorCredito,
        issRetido,
        valorIssRetido,
        valorDescontoCondicionado,
        valorDescontoIncondicionado,
        municipioPrestacao,
        discriminacao
      ];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'nfse_detalhe';
  @override
  VerificationContext validateIntegrity(Insertable<NfseDetalhe> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('id_nfse_cabecalho')) {
      context.handle(
          _idNfseCabecalhoMeta,
          idNfseCabecalho.isAcceptableOrUnknown(
              data['id_nfse_cabecalho']!, _idNfseCabecalhoMeta));
    }
    if (data.containsKey('id_nfse_lista_servico')) {
      context.handle(
          _idNfseListaServicoMeta,
          idNfseListaServico.isAcceptableOrUnknown(
              data['id_nfse_lista_servico']!, _idNfseListaServicoMeta));
    }
    if (data.containsKey('codigo_cnae')) {
      context.handle(
          _codigoCnaeMeta,
          codigoCnae.isAcceptableOrUnknown(
              data['codigo_cnae']!, _codigoCnaeMeta));
    }
    if (data.containsKey('codigo_tributacao_municipio')) {
      context.handle(
          _codigoTributacaoMunicipioMeta,
          codigoTributacaoMunicipio.isAcceptableOrUnknown(
              data['codigo_tributacao_municipio']!,
              _codigoTributacaoMunicipioMeta));
    }
    if (data.containsKey('valor_servicos')) {
      context.handle(
          _valorServicosMeta,
          valorServicos.isAcceptableOrUnknown(
              data['valor_servicos']!, _valorServicosMeta));
    }
    if (data.containsKey('valor_deducoes')) {
      context.handle(
          _valorDeducoesMeta,
          valorDeducoes.isAcceptableOrUnknown(
              data['valor_deducoes']!, _valorDeducoesMeta));
    }
    if (data.containsKey('valor_pis')) {
      context.handle(_valorPisMeta,
          valorPis.isAcceptableOrUnknown(data['valor_pis']!, _valorPisMeta));
    }
    if (data.containsKey('valor_cofins')) {
      context.handle(
          _valorCofinsMeta,
          valorCofins.isAcceptableOrUnknown(
              data['valor_cofins']!, _valorCofinsMeta));
    }
    if (data.containsKey('valor_inss')) {
      context.handle(_valorInssMeta,
          valorInss.isAcceptableOrUnknown(data['valor_inss']!, _valorInssMeta));
    }
    if (data.containsKey('valor_ir')) {
      context.handle(_valorIrMeta,
          valorIr.isAcceptableOrUnknown(data['valor_ir']!, _valorIrMeta));
    }
    if (data.containsKey('valor_csll')) {
      context.handle(_valorCsllMeta,
          valorCsll.isAcceptableOrUnknown(data['valor_csll']!, _valorCsllMeta));
    }
    if (data.containsKey('valor_base_calculo')) {
      context.handle(
          _valorBaseCalculoMeta,
          valorBaseCalculo.isAcceptableOrUnknown(
              data['valor_base_calculo']!, _valorBaseCalculoMeta));
    }
    if (data.containsKey('aliquota')) {
      context.handle(_aliquotaMeta,
          aliquota.isAcceptableOrUnknown(data['aliquota']!, _aliquotaMeta));
    }
    if (data.containsKey('valor_iss')) {
      context.handle(_valorIssMeta,
          valorIss.isAcceptableOrUnknown(data['valor_iss']!, _valorIssMeta));
    }
    if (data.containsKey('valor_liquido')) {
      context.handle(
          _valorLiquidoMeta,
          valorLiquido.isAcceptableOrUnknown(
              data['valor_liquido']!, _valorLiquidoMeta));
    }
    if (data.containsKey('outras_retencoes')) {
      context.handle(
          _outrasRetencoesMeta,
          outrasRetencoes.isAcceptableOrUnknown(
              data['outras_retencoes']!, _outrasRetencoesMeta));
    }
    if (data.containsKey('valor_credito')) {
      context.handle(
          _valorCreditoMeta,
          valorCredito.isAcceptableOrUnknown(
              data['valor_credito']!, _valorCreditoMeta));
    }
    if (data.containsKey('iss_retido')) {
      context.handle(_issRetidoMeta,
          issRetido.isAcceptableOrUnknown(data['iss_retido']!, _issRetidoMeta));
    }
    if (data.containsKey('valor_iss_retido')) {
      context.handle(
          _valorIssRetidoMeta,
          valorIssRetido.isAcceptableOrUnknown(
              data['valor_iss_retido']!, _valorIssRetidoMeta));
    }
    if (data.containsKey('valor_desconto_condicionado')) {
      context.handle(
          _valorDescontoCondicionadoMeta,
          valorDescontoCondicionado.isAcceptableOrUnknown(
              data['valor_desconto_condicionado']!,
              _valorDescontoCondicionadoMeta));
    }
    if (data.containsKey('valor_desconto_incondicionado')) {
      context.handle(
          _valorDescontoIncondicionadoMeta,
          valorDescontoIncondicionado.isAcceptableOrUnknown(
              data['valor_desconto_incondicionado']!,
              _valorDescontoIncondicionadoMeta));
    }
    if (data.containsKey('municipio_prestacao')) {
      context.handle(
          _municipioPrestacaoMeta,
          municipioPrestacao.isAcceptableOrUnknown(
              data['municipio_prestacao']!, _municipioPrestacaoMeta));
    }
    if (data.containsKey('discriminacao')) {
      context.handle(
          _discriminacaoMeta,
          discriminacao.isAcceptableOrUnknown(
              data['discriminacao']!, _discriminacaoMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  NfseDetalhe map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return NfseDetalhe(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id']),
      idNfseCabecalho: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id_nfse_cabecalho']),
      idNfseListaServico: attachedDatabase.typeMapping.read(
          DriftSqlType.int, data['${effectivePrefix}id_nfse_lista_servico']),
      codigoCnae: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}codigo_cnae']),
      codigoTributacaoMunicipio: attachedDatabase.typeMapping.read(
          DriftSqlType.string,
          data['${effectivePrefix}codigo_tributacao_municipio']),
      valorServicos: attachedDatabase.typeMapping
          .read(DriftSqlType.double, data['${effectivePrefix}valor_servicos']),
      valorDeducoes: attachedDatabase.typeMapping
          .read(DriftSqlType.double, data['${effectivePrefix}valor_deducoes']),
      valorPis: attachedDatabase.typeMapping
          .read(DriftSqlType.double, data['${effectivePrefix}valor_pis']),
      valorCofins: attachedDatabase.typeMapping
          .read(DriftSqlType.double, data['${effectivePrefix}valor_cofins']),
      valorInss: attachedDatabase.typeMapping
          .read(DriftSqlType.double, data['${effectivePrefix}valor_inss']),
      valorIr: attachedDatabase.typeMapping
          .read(DriftSqlType.double, data['${effectivePrefix}valor_ir']),
      valorCsll: attachedDatabase.typeMapping
          .read(DriftSqlType.double, data['${effectivePrefix}valor_csll']),
      valorBaseCalculo: attachedDatabase.typeMapping.read(
          DriftSqlType.double, data['${effectivePrefix}valor_base_calculo']),
      aliquota: attachedDatabase.typeMapping
          .read(DriftSqlType.double, data['${effectivePrefix}aliquota']),
      valorIss: attachedDatabase.typeMapping
          .read(DriftSqlType.double, data['${effectivePrefix}valor_iss']),
      valorLiquido: attachedDatabase.typeMapping
          .read(DriftSqlType.double, data['${effectivePrefix}valor_liquido']),
      outrasRetencoes: attachedDatabase.typeMapping.read(
          DriftSqlType.double, data['${effectivePrefix}outras_retencoes']),
      valorCredito: attachedDatabase.typeMapping
          .read(DriftSqlType.double, data['${effectivePrefix}valor_credito']),
      issRetido: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}iss_retido']),
      valorIssRetido: attachedDatabase.typeMapping.read(
          DriftSqlType.double, data['${effectivePrefix}valor_iss_retido']),
      valorDescontoCondicionado: attachedDatabase.typeMapping.read(
          DriftSqlType.double,
          data['${effectivePrefix}valor_desconto_condicionado']),
      valorDescontoIncondicionado: attachedDatabase.typeMapping.read(
          DriftSqlType.double,
          data['${effectivePrefix}valor_desconto_incondicionado']),
      municipioPrestacao: attachedDatabase.typeMapping.read(
          DriftSqlType.int, data['${effectivePrefix}municipio_prestacao']),
      discriminacao: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}discriminacao']),
    );
  }

  @override
  $NfseDetalhesTable createAlias(String alias) {
    return $NfseDetalhesTable(attachedDatabase, alias);
  }
}

class NfseDetalhe extends DataClass implements Insertable<NfseDetalhe> {
  final int? id;
  final int? idNfseCabecalho;
  final int? idNfseListaServico;
  final String? codigoCnae;
  final String? codigoTributacaoMunicipio;
  final double? valorServicos;
  final double? valorDeducoes;
  final double? valorPis;
  final double? valorCofins;
  final double? valorInss;
  final double? valorIr;
  final double? valorCsll;
  final double? valorBaseCalculo;
  final double? aliquota;
  final double? valorIss;
  final double? valorLiquido;
  final double? outrasRetencoes;
  final double? valorCredito;
  final String? issRetido;
  final double? valorIssRetido;
  final double? valorDescontoCondicionado;
  final double? valorDescontoIncondicionado;
  final int? municipioPrestacao;
  final String? discriminacao;
  const NfseDetalhe(
      {this.id,
      this.idNfseCabecalho,
      this.idNfseListaServico,
      this.codigoCnae,
      this.codigoTributacaoMunicipio,
      this.valorServicos,
      this.valorDeducoes,
      this.valorPis,
      this.valorCofins,
      this.valorInss,
      this.valorIr,
      this.valorCsll,
      this.valorBaseCalculo,
      this.aliquota,
      this.valorIss,
      this.valorLiquido,
      this.outrasRetencoes,
      this.valorCredito,
      this.issRetido,
      this.valorIssRetido,
      this.valorDescontoCondicionado,
      this.valorDescontoIncondicionado,
      this.municipioPrestacao,
      this.discriminacao});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || idNfseCabecalho != null) {
      map['id_nfse_cabecalho'] = Variable<int>(idNfseCabecalho);
    }
    if (!nullToAbsent || idNfseListaServico != null) {
      map['id_nfse_lista_servico'] = Variable<int>(idNfseListaServico);
    }
    if (!nullToAbsent || codigoCnae != null) {
      map['codigo_cnae'] = Variable<String>(codigoCnae);
    }
    if (!nullToAbsent || codigoTributacaoMunicipio != null) {
      map['codigo_tributacao_municipio'] =
          Variable<String>(codigoTributacaoMunicipio);
    }
    if (!nullToAbsent || valorServicos != null) {
      map['valor_servicos'] = Variable<double>(valorServicos);
    }
    if (!nullToAbsent || valorDeducoes != null) {
      map['valor_deducoes'] = Variable<double>(valorDeducoes);
    }
    if (!nullToAbsent || valorPis != null) {
      map['valor_pis'] = Variable<double>(valorPis);
    }
    if (!nullToAbsent || valorCofins != null) {
      map['valor_cofins'] = Variable<double>(valorCofins);
    }
    if (!nullToAbsent || valorInss != null) {
      map['valor_inss'] = Variable<double>(valorInss);
    }
    if (!nullToAbsent || valorIr != null) {
      map['valor_ir'] = Variable<double>(valorIr);
    }
    if (!nullToAbsent || valorCsll != null) {
      map['valor_csll'] = Variable<double>(valorCsll);
    }
    if (!nullToAbsent || valorBaseCalculo != null) {
      map['valor_base_calculo'] = Variable<double>(valorBaseCalculo);
    }
    if (!nullToAbsent || aliquota != null) {
      map['aliquota'] = Variable<double>(aliquota);
    }
    if (!nullToAbsent || valorIss != null) {
      map['valor_iss'] = Variable<double>(valorIss);
    }
    if (!nullToAbsent || valorLiquido != null) {
      map['valor_liquido'] = Variable<double>(valorLiquido);
    }
    if (!nullToAbsent || outrasRetencoes != null) {
      map['outras_retencoes'] = Variable<double>(outrasRetencoes);
    }
    if (!nullToAbsent || valorCredito != null) {
      map['valor_credito'] = Variable<double>(valorCredito);
    }
    if (!nullToAbsent || issRetido != null) {
      map['iss_retido'] = Variable<String>(issRetido);
    }
    if (!nullToAbsent || valorIssRetido != null) {
      map['valor_iss_retido'] = Variable<double>(valorIssRetido);
    }
    if (!nullToAbsent || valorDescontoCondicionado != null) {
      map['valor_desconto_condicionado'] =
          Variable<double>(valorDescontoCondicionado);
    }
    if (!nullToAbsent || valorDescontoIncondicionado != null) {
      map['valor_desconto_incondicionado'] =
          Variable<double>(valorDescontoIncondicionado);
    }
    if (!nullToAbsent || municipioPrestacao != null) {
      map['municipio_prestacao'] = Variable<int>(municipioPrestacao);
    }
    if (!nullToAbsent || discriminacao != null) {
      map['discriminacao'] = Variable<String>(discriminacao);
    }
    return map;
  }

  factory NfseDetalhe.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return NfseDetalhe(
      id: serializer.fromJson<int?>(json['id']),
      idNfseCabecalho: serializer.fromJson<int?>(json['idNfseCabecalho']),
      idNfseListaServico: serializer.fromJson<int?>(json['idNfseListaServico']),
      codigoCnae: serializer.fromJson<String?>(json['codigoCnae']),
      codigoTributacaoMunicipio:
          serializer.fromJson<String?>(json['codigoTributacaoMunicipio']),
      valorServicos: serializer.fromJson<double?>(json['valorServicos']),
      valorDeducoes: serializer.fromJson<double?>(json['valorDeducoes']),
      valorPis: serializer.fromJson<double?>(json['valorPis']),
      valorCofins: serializer.fromJson<double?>(json['valorCofins']),
      valorInss: serializer.fromJson<double?>(json['valorInss']),
      valorIr: serializer.fromJson<double?>(json['valorIr']),
      valorCsll: serializer.fromJson<double?>(json['valorCsll']),
      valorBaseCalculo: serializer.fromJson<double?>(json['valorBaseCalculo']),
      aliquota: serializer.fromJson<double?>(json['aliquota']),
      valorIss: serializer.fromJson<double?>(json['valorIss']),
      valorLiquido: serializer.fromJson<double?>(json['valorLiquido']),
      outrasRetencoes: serializer.fromJson<double?>(json['outrasRetencoes']),
      valorCredito: serializer.fromJson<double?>(json['valorCredito']),
      issRetido: serializer.fromJson<String?>(json['issRetido']),
      valorIssRetido: serializer.fromJson<double?>(json['valorIssRetido']),
      valorDescontoCondicionado:
          serializer.fromJson<double?>(json['valorDescontoCondicionado']),
      valorDescontoIncondicionado:
          serializer.fromJson<double?>(json['valorDescontoIncondicionado']),
      municipioPrestacao: serializer.fromJson<int?>(json['municipioPrestacao']),
      discriminacao: serializer.fromJson<String?>(json['discriminacao']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'idNfseCabecalho': serializer.toJson<int?>(idNfseCabecalho),
      'idNfseListaServico': serializer.toJson<int?>(idNfseListaServico),
      'codigoCnae': serializer.toJson<String?>(codigoCnae),
      'codigoTributacaoMunicipio':
          serializer.toJson<String?>(codigoTributacaoMunicipio),
      'valorServicos': serializer.toJson<double?>(valorServicos),
      'valorDeducoes': serializer.toJson<double?>(valorDeducoes),
      'valorPis': serializer.toJson<double?>(valorPis),
      'valorCofins': serializer.toJson<double?>(valorCofins),
      'valorInss': serializer.toJson<double?>(valorInss),
      'valorIr': serializer.toJson<double?>(valorIr),
      'valorCsll': serializer.toJson<double?>(valorCsll),
      'valorBaseCalculo': serializer.toJson<double?>(valorBaseCalculo),
      'aliquota': serializer.toJson<double?>(aliquota),
      'valorIss': serializer.toJson<double?>(valorIss),
      'valorLiquido': serializer.toJson<double?>(valorLiquido),
      'outrasRetencoes': serializer.toJson<double?>(outrasRetencoes),
      'valorCredito': serializer.toJson<double?>(valorCredito),
      'issRetido': serializer.toJson<String?>(issRetido),
      'valorIssRetido': serializer.toJson<double?>(valorIssRetido),
      'valorDescontoCondicionado':
          serializer.toJson<double?>(valorDescontoCondicionado),
      'valorDescontoIncondicionado':
          serializer.toJson<double?>(valorDescontoIncondicionado),
      'municipioPrestacao': serializer.toJson<int?>(municipioPrestacao),
      'discriminacao': serializer.toJson<String?>(discriminacao),
    };
  }

  NfseDetalhe copyWith(
          {Value<int?> id = const Value.absent(),
          Value<int?> idNfseCabecalho = const Value.absent(),
          Value<int?> idNfseListaServico = const Value.absent(),
          Value<String?> codigoCnae = const Value.absent(),
          Value<String?> codigoTributacaoMunicipio = const Value.absent(),
          Value<double?> valorServicos = const Value.absent(),
          Value<double?> valorDeducoes = const Value.absent(),
          Value<double?> valorPis = const Value.absent(),
          Value<double?> valorCofins = const Value.absent(),
          Value<double?> valorInss = const Value.absent(),
          Value<double?> valorIr = const Value.absent(),
          Value<double?> valorCsll = const Value.absent(),
          Value<double?> valorBaseCalculo = const Value.absent(),
          Value<double?> aliquota = const Value.absent(),
          Value<double?> valorIss = const Value.absent(),
          Value<double?> valorLiquido = const Value.absent(),
          Value<double?> outrasRetencoes = const Value.absent(),
          Value<double?> valorCredito = const Value.absent(),
          Value<String?> issRetido = const Value.absent(),
          Value<double?> valorIssRetido = const Value.absent(),
          Value<double?> valorDescontoCondicionado = const Value.absent(),
          Value<double?> valorDescontoIncondicionado = const Value.absent(),
          Value<int?> municipioPrestacao = const Value.absent(),
          Value<String?> discriminacao = const Value.absent()}) =>
      NfseDetalhe(
        id: id.present ? id.value : this.id,
        idNfseCabecalho: idNfseCabecalho.present
            ? idNfseCabecalho.value
            : this.idNfseCabecalho,
        idNfseListaServico: idNfseListaServico.present
            ? idNfseListaServico.value
            : this.idNfseListaServico,
        codigoCnae: codigoCnae.present ? codigoCnae.value : this.codigoCnae,
        codigoTributacaoMunicipio: codigoTributacaoMunicipio.present
            ? codigoTributacaoMunicipio.value
            : this.codigoTributacaoMunicipio,
        valorServicos:
            valorServicos.present ? valorServicos.value : this.valorServicos,
        valorDeducoes:
            valorDeducoes.present ? valorDeducoes.value : this.valorDeducoes,
        valorPis: valorPis.present ? valorPis.value : this.valorPis,
        valorCofins: valorCofins.present ? valorCofins.value : this.valorCofins,
        valorInss: valorInss.present ? valorInss.value : this.valorInss,
        valorIr: valorIr.present ? valorIr.value : this.valorIr,
        valorCsll: valorCsll.present ? valorCsll.value : this.valorCsll,
        valorBaseCalculo: valorBaseCalculo.present
            ? valorBaseCalculo.value
            : this.valorBaseCalculo,
        aliquota: aliquota.present ? aliquota.value : this.aliquota,
        valorIss: valorIss.present ? valorIss.value : this.valorIss,
        valorLiquido:
            valorLiquido.present ? valorLiquido.value : this.valorLiquido,
        outrasRetencoes: outrasRetencoes.present
            ? outrasRetencoes.value
            : this.outrasRetencoes,
        valorCredito:
            valorCredito.present ? valorCredito.value : this.valorCredito,
        issRetido: issRetido.present ? issRetido.value : this.issRetido,
        valorIssRetido:
            valorIssRetido.present ? valorIssRetido.value : this.valorIssRetido,
        valorDescontoCondicionado: valorDescontoCondicionado.present
            ? valorDescontoCondicionado.value
            : this.valorDescontoCondicionado,
        valorDescontoIncondicionado: valorDescontoIncondicionado.present
            ? valorDescontoIncondicionado.value
            : this.valorDescontoIncondicionado,
        municipioPrestacao: municipioPrestacao.present
            ? municipioPrestacao.value
            : this.municipioPrestacao,
        discriminacao:
            discriminacao.present ? discriminacao.value : this.discriminacao,
      );
  NfseDetalhe copyWithCompanion(NfseDetalhesCompanion data) {
    return NfseDetalhe(
      id: data.id.present ? data.id.value : this.id,
      idNfseCabecalho: data.idNfseCabecalho.present
          ? data.idNfseCabecalho.value
          : this.idNfseCabecalho,
      idNfseListaServico: data.idNfseListaServico.present
          ? data.idNfseListaServico.value
          : this.idNfseListaServico,
      codigoCnae:
          data.codigoCnae.present ? data.codigoCnae.value : this.codigoCnae,
      codigoTributacaoMunicipio: data.codigoTributacaoMunicipio.present
          ? data.codigoTributacaoMunicipio.value
          : this.codigoTributacaoMunicipio,
      valorServicos: data.valorServicos.present
          ? data.valorServicos.value
          : this.valorServicos,
      valorDeducoes: data.valorDeducoes.present
          ? data.valorDeducoes.value
          : this.valorDeducoes,
      valorPis: data.valorPis.present ? data.valorPis.value : this.valorPis,
      valorCofins:
          data.valorCofins.present ? data.valorCofins.value : this.valorCofins,
      valorInss: data.valorInss.present ? data.valorInss.value : this.valorInss,
      valorIr: data.valorIr.present ? data.valorIr.value : this.valorIr,
      valorCsll: data.valorCsll.present ? data.valorCsll.value : this.valorCsll,
      valorBaseCalculo: data.valorBaseCalculo.present
          ? data.valorBaseCalculo.value
          : this.valorBaseCalculo,
      aliquota: data.aliquota.present ? data.aliquota.value : this.aliquota,
      valorIss: data.valorIss.present ? data.valorIss.value : this.valorIss,
      valorLiquido: data.valorLiquido.present
          ? data.valorLiquido.value
          : this.valorLiquido,
      outrasRetencoes: data.outrasRetencoes.present
          ? data.outrasRetencoes.value
          : this.outrasRetencoes,
      valorCredito: data.valorCredito.present
          ? data.valorCredito.value
          : this.valorCredito,
      issRetido: data.issRetido.present ? data.issRetido.value : this.issRetido,
      valorIssRetido: data.valorIssRetido.present
          ? data.valorIssRetido.value
          : this.valorIssRetido,
      valorDescontoCondicionado: data.valorDescontoCondicionado.present
          ? data.valorDescontoCondicionado.value
          : this.valorDescontoCondicionado,
      valorDescontoIncondicionado: data.valorDescontoIncondicionado.present
          ? data.valorDescontoIncondicionado.value
          : this.valorDescontoIncondicionado,
      municipioPrestacao: data.municipioPrestacao.present
          ? data.municipioPrestacao.value
          : this.municipioPrestacao,
      discriminacao: data.discriminacao.present
          ? data.discriminacao.value
          : this.discriminacao,
    );
  }

  @override
  String toString() {
    return (StringBuffer('NfseDetalhe(')
          ..write('id: $id, ')
          ..write('idNfseCabecalho: $idNfseCabecalho, ')
          ..write('idNfseListaServico: $idNfseListaServico, ')
          ..write('codigoCnae: $codigoCnae, ')
          ..write('codigoTributacaoMunicipio: $codigoTributacaoMunicipio, ')
          ..write('valorServicos: $valorServicos, ')
          ..write('valorDeducoes: $valorDeducoes, ')
          ..write('valorPis: $valorPis, ')
          ..write('valorCofins: $valorCofins, ')
          ..write('valorInss: $valorInss, ')
          ..write('valorIr: $valorIr, ')
          ..write('valorCsll: $valorCsll, ')
          ..write('valorBaseCalculo: $valorBaseCalculo, ')
          ..write('aliquota: $aliquota, ')
          ..write('valorIss: $valorIss, ')
          ..write('valorLiquido: $valorLiquido, ')
          ..write('outrasRetencoes: $outrasRetencoes, ')
          ..write('valorCredito: $valorCredito, ')
          ..write('issRetido: $issRetido, ')
          ..write('valorIssRetido: $valorIssRetido, ')
          ..write('valorDescontoCondicionado: $valorDescontoCondicionado, ')
          ..write('valorDescontoIncondicionado: $valorDescontoIncondicionado, ')
          ..write('municipioPrestacao: $municipioPrestacao, ')
          ..write('discriminacao: $discriminacao')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hashAll([
        id,
        idNfseCabecalho,
        idNfseListaServico,
        codigoCnae,
        codigoTributacaoMunicipio,
        valorServicos,
        valorDeducoes,
        valorPis,
        valorCofins,
        valorInss,
        valorIr,
        valorCsll,
        valorBaseCalculo,
        aliquota,
        valorIss,
        valorLiquido,
        outrasRetencoes,
        valorCredito,
        issRetido,
        valorIssRetido,
        valorDescontoCondicionado,
        valorDescontoIncondicionado,
        municipioPrestacao,
        discriminacao
      ]);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is NfseDetalhe &&
          other.id == this.id &&
          other.idNfseCabecalho == this.idNfseCabecalho &&
          other.idNfseListaServico == this.idNfseListaServico &&
          other.codigoCnae == this.codigoCnae &&
          other.codigoTributacaoMunicipio == this.codigoTributacaoMunicipio &&
          other.valorServicos == this.valorServicos &&
          other.valorDeducoes == this.valorDeducoes &&
          other.valorPis == this.valorPis &&
          other.valorCofins == this.valorCofins &&
          other.valorInss == this.valorInss &&
          other.valorIr == this.valorIr &&
          other.valorCsll == this.valorCsll &&
          other.valorBaseCalculo == this.valorBaseCalculo &&
          other.aliquota == this.aliquota &&
          other.valorIss == this.valorIss &&
          other.valorLiquido == this.valorLiquido &&
          other.outrasRetencoes == this.outrasRetencoes &&
          other.valorCredito == this.valorCredito &&
          other.issRetido == this.issRetido &&
          other.valorIssRetido == this.valorIssRetido &&
          other.valorDescontoCondicionado == this.valorDescontoCondicionado &&
          other.valorDescontoIncondicionado ==
              this.valorDescontoIncondicionado &&
          other.municipioPrestacao == this.municipioPrestacao &&
          other.discriminacao == this.discriminacao);
}

class NfseDetalhesCompanion extends UpdateCompanion<NfseDetalhe> {
  final Value<int?> id;
  final Value<int?> idNfseCabecalho;
  final Value<int?> idNfseListaServico;
  final Value<String?> codigoCnae;
  final Value<String?> codigoTributacaoMunicipio;
  final Value<double?> valorServicos;
  final Value<double?> valorDeducoes;
  final Value<double?> valorPis;
  final Value<double?> valorCofins;
  final Value<double?> valorInss;
  final Value<double?> valorIr;
  final Value<double?> valorCsll;
  final Value<double?> valorBaseCalculo;
  final Value<double?> aliquota;
  final Value<double?> valorIss;
  final Value<double?> valorLiquido;
  final Value<double?> outrasRetencoes;
  final Value<double?> valorCredito;
  final Value<String?> issRetido;
  final Value<double?> valorIssRetido;
  final Value<double?> valorDescontoCondicionado;
  final Value<double?> valorDescontoIncondicionado;
  final Value<int?> municipioPrestacao;
  final Value<String?> discriminacao;
  const NfseDetalhesCompanion({
    this.id = const Value.absent(),
    this.idNfseCabecalho = const Value.absent(),
    this.idNfseListaServico = const Value.absent(),
    this.codigoCnae = const Value.absent(),
    this.codigoTributacaoMunicipio = const Value.absent(),
    this.valorServicos = const Value.absent(),
    this.valorDeducoes = const Value.absent(),
    this.valorPis = const Value.absent(),
    this.valorCofins = const Value.absent(),
    this.valorInss = const Value.absent(),
    this.valorIr = const Value.absent(),
    this.valorCsll = const Value.absent(),
    this.valorBaseCalculo = const Value.absent(),
    this.aliquota = const Value.absent(),
    this.valorIss = const Value.absent(),
    this.valorLiquido = const Value.absent(),
    this.outrasRetencoes = const Value.absent(),
    this.valorCredito = const Value.absent(),
    this.issRetido = const Value.absent(),
    this.valorIssRetido = const Value.absent(),
    this.valorDescontoCondicionado = const Value.absent(),
    this.valorDescontoIncondicionado = const Value.absent(),
    this.municipioPrestacao = const Value.absent(),
    this.discriminacao = const Value.absent(),
  });
  NfseDetalhesCompanion.insert({
    this.id = const Value.absent(),
    this.idNfseCabecalho = const Value.absent(),
    this.idNfseListaServico = const Value.absent(),
    this.codigoCnae = const Value.absent(),
    this.codigoTributacaoMunicipio = const Value.absent(),
    this.valorServicos = const Value.absent(),
    this.valorDeducoes = const Value.absent(),
    this.valorPis = const Value.absent(),
    this.valorCofins = const Value.absent(),
    this.valorInss = const Value.absent(),
    this.valorIr = const Value.absent(),
    this.valorCsll = const Value.absent(),
    this.valorBaseCalculo = const Value.absent(),
    this.aliquota = const Value.absent(),
    this.valorIss = const Value.absent(),
    this.valorLiquido = const Value.absent(),
    this.outrasRetencoes = const Value.absent(),
    this.valorCredito = const Value.absent(),
    this.issRetido = const Value.absent(),
    this.valorIssRetido = const Value.absent(),
    this.valorDescontoCondicionado = const Value.absent(),
    this.valorDescontoIncondicionado = const Value.absent(),
    this.municipioPrestacao = const Value.absent(),
    this.discriminacao = const Value.absent(),
  });
  static Insertable<NfseDetalhe> custom({
    Expression<int>? id,
    Expression<int>? idNfseCabecalho,
    Expression<int>? idNfseListaServico,
    Expression<String>? codigoCnae,
    Expression<String>? codigoTributacaoMunicipio,
    Expression<double>? valorServicos,
    Expression<double>? valorDeducoes,
    Expression<double>? valorPis,
    Expression<double>? valorCofins,
    Expression<double>? valorInss,
    Expression<double>? valorIr,
    Expression<double>? valorCsll,
    Expression<double>? valorBaseCalculo,
    Expression<double>? aliquota,
    Expression<double>? valorIss,
    Expression<double>? valorLiquido,
    Expression<double>? outrasRetencoes,
    Expression<double>? valorCredito,
    Expression<String>? issRetido,
    Expression<double>? valorIssRetido,
    Expression<double>? valorDescontoCondicionado,
    Expression<double>? valorDescontoIncondicionado,
    Expression<int>? municipioPrestacao,
    Expression<String>? discriminacao,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (idNfseCabecalho != null) 'id_nfse_cabecalho': idNfseCabecalho,
      if (idNfseListaServico != null)
        'id_nfse_lista_servico': idNfseListaServico,
      if (codigoCnae != null) 'codigo_cnae': codigoCnae,
      if (codigoTributacaoMunicipio != null)
        'codigo_tributacao_municipio': codigoTributacaoMunicipio,
      if (valorServicos != null) 'valor_servicos': valorServicos,
      if (valorDeducoes != null) 'valor_deducoes': valorDeducoes,
      if (valorPis != null) 'valor_pis': valorPis,
      if (valorCofins != null) 'valor_cofins': valorCofins,
      if (valorInss != null) 'valor_inss': valorInss,
      if (valorIr != null) 'valor_ir': valorIr,
      if (valorCsll != null) 'valor_csll': valorCsll,
      if (valorBaseCalculo != null) 'valor_base_calculo': valorBaseCalculo,
      if (aliquota != null) 'aliquota': aliquota,
      if (valorIss != null) 'valor_iss': valorIss,
      if (valorLiquido != null) 'valor_liquido': valorLiquido,
      if (outrasRetencoes != null) 'outras_retencoes': outrasRetencoes,
      if (valorCredito != null) 'valor_credito': valorCredito,
      if (issRetido != null) 'iss_retido': issRetido,
      if (valorIssRetido != null) 'valor_iss_retido': valorIssRetido,
      if (valorDescontoCondicionado != null)
        'valor_desconto_condicionado': valorDescontoCondicionado,
      if (valorDescontoIncondicionado != null)
        'valor_desconto_incondicionado': valorDescontoIncondicionado,
      if (municipioPrestacao != null) 'municipio_prestacao': municipioPrestacao,
      if (discriminacao != null) 'discriminacao': discriminacao,
    });
  }

  NfseDetalhesCompanion copyWith(
      {Value<int?>? id,
      Value<int?>? idNfseCabecalho,
      Value<int?>? idNfseListaServico,
      Value<String?>? codigoCnae,
      Value<String?>? codigoTributacaoMunicipio,
      Value<double?>? valorServicos,
      Value<double?>? valorDeducoes,
      Value<double?>? valorPis,
      Value<double?>? valorCofins,
      Value<double?>? valorInss,
      Value<double?>? valorIr,
      Value<double?>? valorCsll,
      Value<double?>? valorBaseCalculo,
      Value<double?>? aliquota,
      Value<double?>? valorIss,
      Value<double?>? valorLiquido,
      Value<double?>? outrasRetencoes,
      Value<double?>? valorCredito,
      Value<String?>? issRetido,
      Value<double?>? valorIssRetido,
      Value<double?>? valorDescontoCondicionado,
      Value<double?>? valorDescontoIncondicionado,
      Value<int?>? municipioPrestacao,
      Value<String?>? discriminacao}) {
    return NfseDetalhesCompanion(
      id: id ?? this.id,
      idNfseCabecalho: idNfseCabecalho ?? this.idNfseCabecalho,
      idNfseListaServico: idNfseListaServico ?? this.idNfseListaServico,
      codigoCnae: codigoCnae ?? this.codigoCnae,
      codigoTributacaoMunicipio:
          codigoTributacaoMunicipio ?? this.codigoTributacaoMunicipio,
      valorServicos: valorServicos ?? this.valorServicos,
      valorDeducoes: valorDeducoes ?? this.valorDeducoes,
      valorPis: valorPis ?? this.valorPis,
      valorCofins: valorCofins ?? this.valorCofins,
      valorInss: valorInss ?? this.valorInss,
      valorIr: valorIr ?? this.valorIr,
      valorCsll: valorCsll ?? this.valorCsll,
      valorBaseCalculo: valorBaseCalculo ?? this.valorBaseCalculo,
      aliquota: aliquota ?? this.aliquota,
      valorIss: valorIss ?? this.valorIss,
      valorLiquido: valorLiquido ?? this.valorLiquido,
      outrasRetencoes: outrasRetencoes ?? this.outrasRetencoes,
      valorCredito: valorCredito ?? this.valorCredito,
      issRetido: issRetido ?? this.issRetido,
      valorIssRetido: valorIssRetido ?? this.valorIssRetido,
      valorDescontoCondicionado:
          valorDescontoCondicionado ?? this.valorDescontoCondicionado,
      valorDescontoIncondicionado:
          valorDescontoIncondicionado ?? this.valorDescontoIncondicionado,
      municipioPrestacao: municipioPrestacao ?? this.municipioPrestacao,
      discriminacao: discriminacao ?? this.discriminacao,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (idNfseCabecalho.present) {
      map['id_nfse_cabecalho'] = Variable<int>(idNfseCabecalho.value);
    }
    if (idNfseListaServico.present) {
      map['id_nfse_lista_servico'] = Variable<int>(idNfseListaServico.value);
    }
    if (codigoCnae.present) {
      map['codigo_cnae'] = Variable<String>(codigoCnae.value);
    }
    if (codigoTributacaoMunicipio.present) {
      map['codigo_tributacao_municipio'] =
          Variable<String>(codigoTributacaoMunicipio.value);
    }
    if (valorServicos.present) {
      map['valor_servicos'] = Variable<double>(valorServicos.value);
    }
    if (valorDeducoes.present) {
      map['valor_deducoes'] = Variable<double>(valorDeducoes.value);
    }
    if (valorPis.present) {
      map['valor_pis'] = Variable<double>(valorPis.value);
    }
    if (valorCofins.present) {
      map['valor_cofins'] = Variable<double>(valorCofins.value);
    }
    if (valorInss.present) {
      map['valor_inss'] = Variable<double>(valorInss.value);
    }
    if (valorIr.present) {
      map['valor_ir'] = Variable<double>(valorIr.value);
    }
    if (valorCsll.present) {
      map['valor_csll'] = Variable<double>(valorCsll.value);
    }
    if (valorBaseCalculo.present) {
      map['valor_base_calculo'] = Variable<double>(valorBaseCalculo.value);
    }
    if (aliquota.present) {
      map['aliquota'] = Variable<double>(aliquota.value);
    }
    if (valorIss.present) {
      map['valor_iss'] = Variable<double>(valorIss.value);
    }
    if (valorLiquido.present) {
      map['valor_liquido'] = Variable<double>(valorLiquido.value);
    }
    if (outrasRetencoes.present) {
      map['outras_retencoes'] = Variable<double>(outrasRetencoes.value);
    }
    if (valorCredito.present) {
      map['valor_credito'] = Variable<double>(valorCredito.value);
    }
    if (issRetido.present) {
      map['iss_retido'] = Variable<String>(issRetido.value);
    }
    if (valorIssRetido.present) {
      map['valor_iss_retido'] = Variable<double>(valorIssRetido.value);
    }
    if (valorDescontoCondicionado.present) {
      map['valor_desconto_condicionado'] =
          Variable<double>(valorDescontoCondicionado.value);
    }
    if (valorDescontoIncondicionado.present) {
      map['valor_desconto_incondicionado'] =
          Variable<double>(valorDescontoIncondicionado.value);
    }
    if (municipioPrestacao.present) {
      map['municipio_prestacao'] = Variable<int>(municipioPrestacao.value);
    }
    if (discriminacao.present) {
      map['discriminacao'] = Variable<String>(discriminacao.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('NfseDetalhesCompanion(')
          ..write('id: $id, ')
          ..write('idNfseCabecalho: $idNfseCabecalho, ')
          ..write('idNfseListaServico: $idNfseListaServico, ')
          ..write('codigoCnae: $codigoCnae, ')
          ..write('codigoTributacaoMunicipio: $codigoTributacaoMunicipio, ')
          ..write('valorServicos: $valorServicos, ')
          ..write('valorDeducoes: $valorDeducoes, ')
          ..write('valorPis: $valorPis, ')
          ..write('valorCofins: $valorCofins, ')
          ..write('valorInss: $valorInss, ')
          ..write('valorIr: $valorIr, ')
          ..write('valorCsll: $valorCsll, ')
          ..write('valorBaseCalculo: $valorBaseCalculo, ')
          ..write('aliquota: $aliquota, ')
          ..write('valorIss: $valorIss, ')
          ..write('valorLiquido: $valorLiquido, ')
          ..write('outrasRetencoes: $outrasRetencoes, ')
          ..write('valorCredito: $valorCredito, ')
          ..write('issRetido: $issRetido, ')
          ..write('valorIssRetido: $valorIssRetido, ')
          ..write('valorDescontoCondicionado: $valorDescontoCondicionado, ')
          ..write('valorDescontoIncondicionado: $valorDescontoIncondicionado, ')
          ..write('municipioPrestacao: $municipioPrestacao, ')
          ..write('discriminacao: $discriminacao')
          ..write(')'))
        .toString();
  }
}

class $NfseIntermediariosTable extends NfseIntermediarios
    with TableInfo<$NfseIntermediariosTable, NfseIntermediario> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $NfseIntermediariosTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
      'id', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _idNfseCabecalhoMeta =
      const VerificationMeta('idNfseCabecalho');
  @override
  late final GeneratedColumn<int> idNfseCabecalho = GeneratedColumn<int>(
      'id_nfse_cabecalho', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _cnpjMeta = const VerificationMeta('cnpj');
  @override
  late final GeneratedColumn<String> cnpj = GeneratedColumn<String>(
      'cnpj', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 14),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _inscricaoMunicipalMeta =
      const VerificationMeta('inscricaoMunicipal');
  @override
  late final GeneratedColumn<String> inscricaoMunicipal =
      GeneratedColumn<String>('inscricao_municipal', aliasedName, true,
          additionalChecks: GeneratedColumn.checkTextLength(
              minTextLength: 0, maxTextLength: 15),
          type: DriftSqlType.string,
          requiredDuringInsert: false);
  static const VerificationMeta _razaoMeta = const VerificationMeta('razao');
  @override
  late final GeneratedColumn<String> razao = GeneratedColumn<String>(
      'razao', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 150),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  @override
  List<GeneratedColumn> get $columns =>
      [id, idNfseCabecalho, cnpj, inscricaoMunicipal, razao];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'nfse_intermediario';
  @override
  VerificationContext validateIntegrity(Insertable<NfseIntermediario> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('id_nfse_cabecalho')) {
      context.handle(
          _idNfseCabecalhoMeta,
          idNfseCabecalho.isAcceptableOrUnknown(
              data['id_nfse_cabecalho']!, _idNfseCabecalhoMeta));
    }
    if (data.containsKey('cnpj')) {
      context.handle(
          _cnpjMeta, cnpj.isAcceptableOrUnknown(data['cnpj']!, _cnpjMeta));
    }
    if (data.containsKey('inscricao_municipal')) {
      context.handle(
          _inscricaoMunicipalMeta,
          inscricaoMunicipal.isAcceptableOrUnknown(
              data['inscricao_municipal']!, _inscricaoMunicipalMeta));
    }
    if (data.containsKey('razao')) {
      context.handle(
          _razaoMeta, razao.isAcceptableOrUnknown(data['razao']!, _razaoMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  NfseIntermediario map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return NfseIntermediario(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id']),
      idNfseCabecalho: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id_nfse_cabecalho']),
      cnpj: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}cnpj']),
      inscricaoMunicipal: attachedDatabase.typeMapping.read(
          DriftSqlType.string, data['${effectivePrefix}inscricao_municipal']),
      razao: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}razao']),
    );
  }

  @override
  $NfseIntermediariosTable createAlias(String alias) {
    return $NfseIntermediariosTable(attachedDatabase, alias);
  }
}

class NfseIntermediario extends DataClass
    implements Insertable<NfseIntermediario> {
  final int? id;
  final int? idNfseCabecalho;
  final String? cnpj;
  final String? inscricaoMunicipal;
  final String? razao;
  const NfseIntermediario(
      {this.id,
      this.idNfseCabecalho,
      this.cnpj,
      this.inscricaoMunicipal,
      this.razao});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || idNfseCabecalho != null) {
      map['id_nfse_cabecalho'] = Variable<int>(idNfseCabecalho);
    }
    if (!nullToAbsent || cnpj != null) {
      map['cnpj'] = Variable<String>(cnpj);
    }
    if (!nullToAbsent || inscricaoMunicipal != null) {
      map['inscricao_municipal'] = Variable<String>(inscricaoMunicipal);
    }
    if (!nullToAbsent || razao != null) {
      map['razao'] = Variable<String>(razao);
    }
    return map;
  }

  factory NfseIntermediario.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return NfseIntermediario(
      id: serializer.fromJson<int?>(json['id']),
      idNfseCabecalho: serializer.fromJson<int?>(json['idNfseCabecalho']),
      cnpj: serializer.fromJson<String?>(json['cnpj']),
      inscricaoMunicipal:
          serializer.fromJson<String?>(json['inscricaoMunicipal']),
      razao: serializer.fromJson<String?>(json['razao']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'idNfseCabecalho': serializer.toJson<int?>(idNfseCabecalho),
      'cnpj': serializer.toJson<String?>(cnpj),
      'inscricaoMunicipal': serializer.toJson<String?>(inscricaoMunicipal),
      'razao': serializer.toJson<String?>(razao),
    };
  }

  NfseIntermediario copyWith(
          {Value<int?> id = const Value.absent(),
          Value<int?> idNfseCabecalho = const Value.absent(),
          Value<String?> cnpj = const Value.absent(),
          Value<String?> inscricaoMunicipal = const Value.absent(),
          Value<String?> razao = const Value.absent()}) =>
      NfseIntermediario(
        id: id.present ? id.value : this.id,
        idNfseCabecalho: idNfseCabecalho.present
            ? idNfseCabecalho.value
            : this.idNfseCabecalho,
        cnpj: cnpj.present ? cnpj.value : this.cnpj,
        inscricaoMunicipal: inscricaoMunicipal.present
            ? inscricaoMunicipal.value
            : this.inscricaoMunicipal,
        razao: razao.present ? razao.value : this.razao,
      );
  NfseIntermediario copyWithCompanion(NfseIntermediariosCompanion data) {
    return NfseIntermediario(
      id: data.id.present ? data.id.value : this.id,
      idNfseCabecalho: data.idNfseCabecalho.present
          ? data.idNfseCabecalho.value
          : this.idNfseCabecalho,
      cnpj: data.cnpj.present ? data.cnpj.value : this.cnpj,
      inscricaoMunicipal: data.inscricaoMunicipal.present
          ? data.inscricaoMunicipal.value
          : this.inscricaoMunicipal,
      razao: data.razao.present ? data.razao.value : this.razao,
    );
  }

  @override
  String toString() {
    return (StringBuffer('NfseIntermediario(')
          ..write('id: $id, ')
          ..write('idNfseCabecalho: $idNfseCabecalho, ')
          ..write('cnpj: $cnpj, ')
          ..write('inscricaoMunicipal: $inscricaoMunicipal, ')
          ..write('razao: $razao')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode =>
      Object.hash(id, idNfseCabecalho, cnpj, inscricaoMunicipal, razao);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is NfseIntermediario &&
          other.id == this.id &&
          other.idNfseCabecalho == this.idNfseCabecalho &&
          other.cnpj == this.cnpj &&
          other.inscricaoMunicipal == this.inscricaoMunicipal &&
          other.razao == this.razao);
}

class NfseIntermediariosCompanion extends UpdateCompanion<NfseIntermediario> {
  final Value<int?> id;
  final Value<int?> idNfseCabecalho;
  final Value<String?> cnpj;
  final Value<String?> inscricaoMunicipal;
  final Value<String?> razao;
  const NfseIntermediariosCompanion({
    this.id = const Value.absent(),
    this.idNfseCabecalho = const Value.absent(),
    this.cnpj = const Value.absent(),
    this.inscricaoMunicipal = const Value.absent(),
    this.razao = const Value.absent(),
  });
  NfseIntermediariosCompanion.insert({
    this.id = const Value.absent(),
    this.idNfseCabecalho = const Value.absent(),
    this.cnpj = const Value.absent(),
    this.inscricaoMunicipal = const Value.absent(),
    this.razao = const Value.absent(),
  });
  static Insertable<NfseIntermediario> custom({
    Expression<int>? id,
    Expression<int>? idNfseCabecalho,
    Expression<String>? cnpj,
    Expression<String>? inscricaoMunicipal,
    Expression<String>? razao,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (idNfseCabecalho != null) 'id_nfse_cabecalho': idNfseCabecalho,
      if (cnpj != null) 'cnpj': cnpj,
      if (inscricaoMunicipal != null) 'inscricao_municipal': inscricaoMunicipal,
      if (razao != null) 'razao': razao,
    });
  }

  NfseIntermediariosCompanion copyWith(
      {Value<int?>? id,
      Value<int?>? idNfseCabecalho,
      Value<String?>? cnpj,
      Value<String?>? inscricaoMunicipal,
      Value<String?>? razao}) {
    return NfseIntermediariosCompanion(
      id: id ?? this.id,
      idNfseCabecalho: idNfseCabecalho ?? this.idNfseCabecalho,
      cnpj: cnpj ?? this.cnpj,
      inscricaoMunicipal: inscricaoMunicipal ?? this.inscricaoMunicipal,
      razao: razao ?? this.razao,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (idNfseCabecalho.present) {
      map['id_nfse_cabecalho'] = Variable<int>(idNfseCabecalho.value);
    }
    if (cnpj.present) {
      map['cnpj'] = Variable<String>(cnpj.value);
    }
    if (inscricaoMunicipal.present) {
      map['inscricao_municipal'] = Variable<String>(inscricaoMunicipal.value);
    }
    if (razao.present) {
      map['razao'] = Variable<String>(razao.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('NfseIntermediariosCompanion(')
          ..write('id: $id, ')
          ..write('idNfseCabecalho: $idNfseCabecalho, ')
          ..write('cnpj: $cnpj, ')
          ..write('inscricaoMunicipal: $inscricaoMunicipal, ')
          ..write('razao: $razao')
          ..write(')'))
        .toString();
  }
}

class $OsStatussTable extends OsStatuss
    with TableInfo<$OsStatussTable, OsStatus> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $OsStatussTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
      'id', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _codigoMeta = const VerificationMeta('codigo');
  @override
  late final GeneratedColumn<String> codigo = GeneratedColumn<String>(
      'codigo', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 2),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _nomeMeta = const VerificationMeta('nome');
  @override
  late final GeneratedColumn<String> nome = GeneratedColumn<String>(
      'nome', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 100),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  @override
  List<GeneratedColumn> get $columns => [id, codigo, nome];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'os_status';
  @override
  VerificationContext validateIntegrity(Insertable<OsStatus> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('codigo')) {
      context.handle(_codigoMeta,
          codigo.isAcceptableOrUnknown(data['codigo']!, _codigoMeta));
    }
    if (data.containsKey('nome')) {
      context.handle(
          _nomeMeta, nome.isAcceptableOrUnknown(data['nome']!, _nomeMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  OsStatus map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return OsStatus(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id']),
      codigo: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}codigo']),
      nome: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}nome']),
    );
  }

  @override
  $OsStatussTable createAlias(String alias) {
    return $OsStatussTable(attachedDatabase, alias);
  }
}

class OsStatus extends DataClass implements Insertable<OsStatus> {
  final int? id;
  final String? codigo;
  final String? nome;
  const OsStatus({this.id, this.codigo, this.nome});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || codigo != null) {
      map['codigo'] = Variable<String>(codigo);
    }
    if (!nullToAbsent || nome != null) {
      map['nome'] = Variable<String>(nome);
    }
    return map;
  }

  factory OsStatus.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return OsStatus(
      id: serializer.fromJson<int?>(json['id']),
      codigo: serializer.fromJson<String?>(json['codigo']),
      nome: serializer.fromJson<String?>(json['nome']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'codigo': serializer.toJson<String?>(codigo),
      'nome': serializer.toJson<String?>(nome),
    };
  }

  OsStatus copyWith(
          {Value<int?> id = const Value.absent(),
          Value<String?> codigo = const Value.absent(),
          Value<String?> nome = const Value.absent()}) =>
      OsStatus(
        id: id.present ? id.value : this.id,
        codigo: codigo.present ? codigo.value : this.codigo,
        nome: nome.present ? nome.value : this.nome,
      );
  OsStatus copyWithCompanion(OsStatussCompanion data) {
    return OsStatus(
      id: data.id.present ? data.id.value : this.id,
      codigo: data.codigo.present ? data.codigo.value : this.codigo,
      nome: data.nome.present ? data.nome.value : this.nome,
    );
  }

  @override
  String toString() {
    return (StringBuffer('OsStatus(')
          ..write('id: $id, ')
          ..write('codigo: $codigo, ')
          ..write('nome: $nome')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(id, codigo, nome);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is OsStatus &&
          other.id == this.id &&
          other.codigo == this.codigo &&
          other.nome == this.nome);
}

class OsStatussCompanion extends UpdateCompanion<OsStatus> {
  final Value<int?> id;
  final Value<String?> codigo;
  final Value<String?> nome;
  const OsStatussCompanion({
    this.id = const Value.absent(),
    this.codigo = const Value.absent(),
    this.nome = const Value.absent(),
  });
  OsStatussCompanion.insert({
    this.id = const Value.absent(),
    this.codigo = const Value.absent(),
    this.nome = const Value.absent(),
  });
  static Insertable<OsStatus> custom({
    Expression<int>? id,
    Expression<String>? codigo,
    Expression<String>? nome,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (codigo != null) 'codigo': codigo,
      if (nome != null) 'nome': nome,
    });
  }

  OsStatussCompanion copyWith(
      {Value<int?>? id, Value<String?>? codigo, Value<String?>? nome}) {
    return OsStatussCompanion(
      id: id ?? this.id,
      codigo: codigo ?? this.codigo,
      nome: nome ?? this.nome,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (codigo.present) {
      map['codigo'] = Variable<String>(codigo.value);
    }
    if (nome.present) {
      map['nome'] = Variable<String>(nome.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('OsStatussCompanion(')
          ..write('id: $id, ')
          ..write('codigo: $codigo, ')
          ..write('nome: $nome')
          ..write(')'))
        .toString();
  }
}

class $NfseCabecalhosTable extends NfseCabecalhos
    with TableInfo<$NfseCabecalhosTable, NfseCabecalho> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $NfseCabecalhosTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
      'id', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _idClienteMeta =
      const VerificationMeta('idCliente');
  @override
  late final GeneratedColumn<int> idCliente = GeneratedColumn<int>(
      'id_cliente', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _idOsAberturaMeta =
      const VerificationMeta('idOsAbertura');
  @override
  late final GeneratedColumn<int> idOsAbertura = GeneratedColumn<int>(
      'id_os_abertura', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _numeroMeta = const VerificationMeta('numero');
  @override
  late final GeneratedColumn<String> numero = GeneratedColumn<String>(
      'numero', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 15),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _codigoVerificacaoMeta =
      const VerificationMeta('codigoVerificacao');
  @override
  late final GeneratedColumn<String> codigoVerificacao =
      GeneratedColumn<String>('codigo_verificacao', aliasedName, true,
          additionalChecks: GeneratedColumn.checkTextLength(
              minTextLength: 0, maxTextLength: 9),
          type: DriftSqlType.string,
          requiredDuringInsert: false);
  static const VerificationMeta _dataHoraEmissaoMeta =
      const VerificationMeta('dataHoraEmissao');
  @override
  late final GeneratedColumn<DateTime> dataHoraEmissao =
      GeneratedColumn<DateTime>('data_hora_emissao', aliasedName, true,
          type: DriftSqlType.dateTime, requiredDuringInsert: false);
  static const VerificationMeta _competenciaMeta =
      const VerificationMeta('competencia');
  @override
  late final GeneratedColumn<String> competencia = GeneratedColumn<String>(
      'competencia', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 6),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _numeroSubstituidaMeta =
      const VerificationMeta('numeroSubstituida');
  @override
  late final GeneratedColumn<String> numeroSubstituida =
      GeneratedColumn<String>('numero_substituida', aliasedName, true,
          additionalChecks: GeneratedColumn.checkTextLength(
              minTextLength: 0, maxTextLength: 15),
          type: DriftSqlType.string,
          requiredDuringInsert: false);
  static const VerificationMeta _naturezaOperacaoMeta =
      const VerificationMeta('naturezaOperacao');
  @override
  late final GeneratedColumn<String> naturezaOperacao = GeneratedColumn<String>(
      'natureza_operacao', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 1),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _regimeEspecialTributacaoMeta =
      const VerificationMeta('regimeEspecialTributacao');
  @override
  late final GeneratedColumn<String> regimeEspecialTributacao =
      GeneratedColumn<String>('regime_especial_tributacao', aliasedName, true,
          additionalChecks: GeneratedColumn.checkTextLength(
              minTextLength: 0, maxTextLength: 1),
          type: DriftSqlType.string,
          requiredDuringInsert: false);
  static const VerificationMeta _optanteSimplesNacionalMeta =
      const VerificationMeta('optanteSimplesNacional');
  @override
  late final GeneratedColumn<String> optanteSimplesNacional =
      GeneratedColumn<String>('optante_simples_nacional', aliasedName, true,
          additionalChecks: GeneratedColumn.checkTextLength(
              minTextLength: 0, maxTextLength: 1),
          type: DriftSqlType.string,
          requiredDuringInsert: false);
  static const VerificationMeta _incentivadorCulturalMeta =
      const VerificationMeta('incentivadorCultural');
  @override
  late final GeneratedColumn<String> incentivadorCultural =
      GeneratedColumn<String>(
          'incentivador_cultural', aliasedName, true,
          additionalChecks: GeneratedColumn.checkTextLength(
              minTextLength: 0, maxTextLength: 1),
          type: DriftSqlType.string,
          requiredDuringInsert: false);
  static const VerificationMeta _numeroRpsMeta =
      const VerificationMeta('numeroRps');
  @override
  late final GeneratedColumn<String> numeroRps = GeneratedColumn<String>(
      'numero_rps', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 15),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _serieRpsMeta =
      const VerificationMeta('serieRps');
  @override
  late final GeneratedColumn<String> serieRps = GeneratedColumn<String>(
      'serie_rps', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 5),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _tipoRpsMeta =
      const VerificationMeta('tipoRps');
  @override
  late final GeneratedColumn<String> tipoRps = GeneratedColumn<String>(
      'tipo_rps', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 1),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _dataEmissaoRpsMeta =
      const VerificationMeta('dataEmissaoRps');
  @override
  late final GeneratedColumn<DateTime> dataEmissaoRps =
      GeneratedColumn<DateTime>('data_emissao_rps', aliasedName, true,
          type: DriftSqlType.dateTime, requiredDuringInsert: false);
  static const VerificationMeta _outrasInformacoesMeta =
      const VerificationMeta('outrasInformacoes');
  @override
  late final GeneratedColumn<String> outrasInformacoes =
      GeneratedColumn<String>('outras_informacoes', aliasedName, true,
          type: DriftSqlType.string, requiredDuringInsert: false);
  @override
  List<GeneratedColumn> get $columns => [
        id,
        idCliente,
        idOsAbertura,
        numero,
        codigoVerificacao,
        dataHoraEmissao,
        competencia,
        numeroSubstituida,
        naturezaOperacao,
        regimeEspecialTributacao,
        optanteSimplesNacional,
        incentivadorCultural,
        numeroRps,
        serieRps,
        tipoRps,
        dataEmissaoRps,
        outrasInformacoes
      ];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'nfse_cabecalho';
  @override
  VerificationContext validateIntegrity(Insertable<NfseCabecalho> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('id_cliente')) {
      context.handle(_idClienteMeta,
          idCliente.isAcceptableOrUnknown(data['id_cliente']!, _idClienteMeta));
    }
    if (data.containsKey('id_os_abertura')) {
      context.handle(
          _idOsAberturaMeta,
          idOsAbertura.isAcceptableOrUnknown(
              data['id_os_abertura']!, _idOsAberturaMeta));
    }
    if (data.containsKey('numero')) {
      context.handle(_numeroMeta,
          numero.isAcceptableOrUnknown(data['numero']!, _numeroMeta));
    }
    if (data.containsKey('codigo_verificacao')) {
      context.handle(
          _codigoVerificacaoMeta,
          codigoVerificacao.isAcceptableOrUnknown(
              data['codigo_verificacao']!, _codigoVerificacaoMeta));
    }
    if (data.containsKey('data_hora_emissao')) {
      context.handle(
          _dataHoraEmissaoMeta,
          dataHoraEmissao.isAcceptableOrUnknown(
              data['data_hora_emissao']!, _dataHoraEmissaoMeta));
    }
    if (data.containsKey('competencia')) {
      context.handle(
          _competenciaMeta,
          competencia.isAcceptableOrUnknown(
              data['competencia']!, _competenciaMeta));
    }
    if (data.containsKey('numero_substituida')) {
      context.handle(
          _numeroSubstituidaMeta,
          numeroSubstituida.isAcceptableOrUnknown(
              data['numero_substituida']!, _numeroSubstituidaMeta));
    }
    if (data.containsKey('natureza_operacao')) {
      context.handle(
          _naturezaOperacaoMeta,
          naturezaOperacao.isAcceptableOrUnknown(
              data['natureza_operacao']!, _naturezaOperacaoMeta));
    }
    if (data.containsKey('regime_especial_tributacao')) {
      context.handle(
          _regimeEspecialTributacaoMeta,
          regimeEspecialTributacao.isAcceptableOrUnknown(
              data['regime_especial_tributacao']!,
              _regimeEspecialTributacaoMeta));
    }
    if (data.containsKey('optante_simples_nacional')) {
      context.handle(
          _optanteSimplesNacionalMeta,
          optanteSimplesNacional.isAcceptableOrUnknown(
              data['optante_simples_nacional']!, _optanteSimplesNacionalMeta));
    }
    if (data.containsKey('incentivador_cultural')) {
      context.handle(
          _incentivadorCulturalMeta,
          incentivadorCultural.isAcceptableOrUnknown(
              data['incentivador_cultural']!, _incentivadorCulturalMeta));
    }
    if (data.containsKey('numero_rps')) {
      context.handle(_numeroRpsMeta,
          numeroRps.isAcceptableOrUnknown(data['numero_rps']!, _numeroRpsMeta));
    }
    if (data.containsKey('serie_rps')) {
      context.handle(_serieRpsMeta,
          serieRps.isAcceptableOrUnknown(data['serie_rps']!, _serieRpsMeta));
    }
    if (data.containsKey('tipo_rps')) {
      context.handle(_tipoRpsMeta,
          tipoRps.isAcceptableOrUnknown(data['tipo_rps']!, _tipoRpsMeta));
    }
    if (data.containsKey('data_emissao_rps')) {
      context.handle(
          _dataEmissaoRpsMeta,
          dataEmissaoRps.isAcceptableOrUnknown(
              data['data_emissao_rps']!, _dataEmissaoRpsMeta));
    }
    if (data.containsKey('outras_informacoes')) {
      context.handle(
          _outrasInformacoesMeta,
          outrasInformacoes.isAcceptableOrUnknown(
              data['outras_informacoes']!, _outrasInformacoesMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  NfseCabecalho map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return NfseCabecalho(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id']),
      idCliente: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id_cliente']),
      idOsAbertura: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id_os_abertura']),
      numero: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}numero']),
      codigoVerificacao: attachedDatabase.typeMapping.read(
          DriftSqlType.string, data['${effectivePrefix}codigo_verificacao']),
      dataHoraEmissao: attachedDatabase.typeMapping.read(
          DriftSqlType.dateTime, data['${effectivePrefix}data_hora_emissao']),
      competencia: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}competencia']),
      numeroSubstituida: attachedDatabase.typeMapping.read(
          DriftSqlType.string, data['${effectivePrefix}numero_substituida']),
      naturezaOperacao: attachedDatabase.typeMapping.read(
          DriftSqlType.string, data['${effectivePrefix}natureza_operacao']),
      regimeEspecialTributacao: attachedDatabase.typeMapping.read(
          DriftSqlType.string,
          data['${effectivePrefix}regime_especial_tributacao']),
      optanteSimplesNacional: attachedDatabase.typeMapping.read(
          DriftSqlType.string,
          data['${effectivePrefix}optante_simples_nacional']),
      incentivadorCultural: attachedDatabase.typeMapping.read(
          DriftSqlType.string, data['${effectivePrefix}incentivador_cultural']),
      numeroRps: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}numero_rps']),
      serieRps: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}serie_rps']),
      tipoRps: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}tipo_rps']),
      dataEmissaoRps: attachedDatabase.typeMapping.read(
          DriftSqlType.dateTime, data['${effectivePrefix}data_emissao_rps']),
      outrasInformacoes: attachedDatabase.typeMapping.read(
          DriftSqlType.string, data['${effectivePrefix}outras_informacoes']),
    );
  }

  @override
  $NfseCabecalhosTable createAlias(String alias) {
    return $NfseCabecalhosTable(attachedDatabase, alias);
  }
}

class NfseCabecalho extends DataClass implements Insertable<NfseCabecalho> {
  final int? id;
  final int? idCliente;
  final int? idOsAbertura;
  final String? numero;
  final String? codigoVerificacao;
  final DateTime? dataHoraEmissao;
  final String? competencia;
  final String? numeroSubstituida;
  final String? naturezaOperacao;
  final String? regimeEspecialTributacao;
  final String? optanteSimplesNacional;
  final String? incentivadorCultural;
  final String? numeroRps;
  final String? serieRps;
  final String? tipoRps;
  final DateTime? dataEmissaoRps;
  final String? outrasInformacoes;
  const NfseCabecalho(
      {this.id,
      this.idCliente,
      this.idOsAbertura,
      this.numero,
      this.codigoVerificacao,
      this.dataHoraEmissao,
      this.competencia,
      this.numeroSubstituida,
      this.naturezaOperacao,
      this.regimeEspecialTributacao,
      this.optanteSimplesNacional,
      this.incentivadorCultural,
      this.numeroRps,
      this.serieRps,
      this.tipoRps,
      this.dataEmissaoRps,
      this.outrasInformacoes});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || idCliente != null) {
      map['id_cliente'] = Variable<int>(idCliente);
    }
    if (!nullToAbsent || idOsAbertura != null) {
      map['id_os_abertura'] = Variable<int>(idOsAbertura);
    }
    if (!nullToAbsent || numero != null) {
      map['numero'] = Variable<String>(numero);
    }
    if (!nullToAbsent || codigoVerificacao != null) {
      map['codigo_verificacao'] = Variable<String>(codigoVerificacao);
    }
    if (!nullToAbsent || dataHoraEmissao != null) {
      map['data_hora_emissao'] = Variable<DateTime>(dataHoraEmissao);
    }
    if (!nullToAbsent || competencia != null) {
      map['competencia'] = Variable<String>(competencia);
    }
    if (!nullToAbsent || numeroSubstituida != null) {
      map['numero_substituida'] = Variable<String>(numeroSubstituida);
    }
    if (!nullToAbsent || naturezaOperacao != null) {
      map['natureza_operacao'] = Variable<String>(naturezaOperacao);
    }
    if (!nullToAbsent || regimeEspecialTributacao != null) {
      map['regime_especial_tributacao'] =
          Variable<String>(regimeEspecialTributacao);
    }
    if (!nullToAbsent || optanteSimplesNacional != null) {
      map['optante_simples_nacional'] =
          Variable<String>(optanteSimplesNacional);
    }
    if (!nullToAbsent || incentivadorCultural != null) {
      map['incentivador_cultural'] = Variable<String>(incentivadorCultural);
    }
    if (!nullToAbsent || numeroRps != null) {
      map['numero_rps'] = Variable<String>(numeroRps);
    }
    if (!nullToAbsent || serieRps != null) {
      map['serie_rps'] = Variable<String>(serieRps);
    }
    if (!nullToAbsent || tipoRps != null) {
      map['tipo_rps'] = Variable<String>(tipoRps);
    }
    if (!nullToAbsent || dataEmissaoRps != null) {
      map['data_emissao_rps'] = Variable<DateTime>(dataEmissaoRps);
    }
    if (!nullToAbsent || outrasInformacoes != null) {
      map['outras_informacoes'] = Variable<String>(outrasInformacoes);
    }
    return map;
  }

  factory NfseCabecalho.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return NfseCabecalho(
      id: serializer.fromJson<int?>(json['id']),
      idCliente: serializer.fromJson<int?>(json['idCliente']),
      idOsAbertura: serializer.fromJson<int?>(json['idOsAbertura']),
      numero: serializer.fromJson<String?>(json['numero']),
      codigoVerificacao:
          serializer.fromJson<String?>(json['codigoVerificacao']),
      dataHoraEmissao: serializer.fromJson<DateTime?>(json['dataHoraEmissao']),
      competencia: serializer.fromJson<String?>(json['competencia']),
      numeroSubstituida:
          serializer.fromJson<String?>(json['numeroSubstituida']),
      naturezaOperacao: serializer.fromJson<String?>(json['naturezaOperacao']),
      regimeEspecialTributacao:
          serializer.fromJson<String?>(json['regimeEspecialTributacao']),
      optanteSimplesNacional:
          serializer.fromJson<String?>(json['optanteSimplesNacional']),
      incentivadorCultural:
          serializer.fromJson<String?>(json['incentivadorCultural']),
      numeroRps: serializer.fromJson<String?>(json['numeroRps']),
      serieRps: serializer.fromJson<String?>(json['serieRps']),
      tipoRps: serializer.fromJson<String?>(json['tipoRps']),
      dataEmissaoRps: serializer.fromJson<DateTime?>(json['dataEmissaoRps']),
      outrasInformacoes:
          serializer.fromJson<String?>(json['outrasInformacoes']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'idCliente': serializer.toJson<int?>(idCliente),
      'idOsAbertura': serializer.toJson<int?>(idOsAbertura),
      'numero': serializer.toJson<String?>(numero),
      'codigoVerificacao': serializer.toJson<String?>(codigoVerificacao),
      'dataHoraEmissao': serializer.toJson<DateTime?>(dataHoraEmissao),
      'competencia': serializer.toJson<String?>(competencia),
      'numeroSubstituida': serializer.toJson<String?>(numeroSubstituida),
      'naturezaOperacao': serializer.toJson<String?>(naturezaOperacao),
      'regimeEspecialTributacao':
          serializer.toJson<String?>(regimeEspecialTributacao),
      'optanteSimplesNacional':
          serializer.toJson<String?>(optanteSimplesNacional),
      'incentivadorCultural': serializer.toJson<String?>(incentivadorCultural),
      'numeroRps': serializer.toJson<String?>(numeroRps),
      'serieRps': serializer.toJson<String?>(serieRps),
      'tipoRps': serializer.toJson<String?>(tipoRps),
      'dataEmissaoRps': serializer.toJson<DateTime?>(dataEmissaoRps),
      'outrasInformacoes': serializer.toJson<String?>(outrasInformacoes),
    };
  }

  NfseCabecalho copyWith(
          {Value<int?> id = const Value.absent(),
          Value<int?> idCliente = const Value.absent(),
          Value<int?> idOsAbertura = const Value.absent(),
          Value<String?> numero = const Value.absent(),
          Value<String?> codigoVerificacao = const Value.absent(),
          Value<DateTime?> dataHoraEmissao = const Value.absent(),
          Value<String?> competencia = const Value.absent(),
          Value<String?> numeroSubstituida = const Value.absent(),
          Value<String?> naturezaOperacao = const Value.absent(),
          Value<String?> regimeEspecialTributacao = const Value.absent(),
          Value<String?> optanteSimplesNacional = const Value.absent(),
          Value<String?> incentivadorCultural = const Value.absent(),
          Value<String?> numeroRps = const Value.absent(),
          Value<String?> serieRps = const Value.absent(),
          Value<String?> tipoRps = const Value.absent(),
          Value<DateTime?> dataEmissaoRps = const Value.absent(),
          Value<String?> outrasInformacoes = const Value.absent()}) =>
      NfseCabecalho(
        id: id.present ? id.value : this.id,
        idCliente: idCliente.present ? idCliente.value : this.idCliente,
        idOsAbertura:
            idOsAbertura.present ? idOsAbertura.value : this.idOsAbertura,
        numero: numero.present ? numero.value : this.numero,
        codigoVerificacao: codigoVerificacao.present
            ? codigoVerificacao.value
            : this.codigoVerificacao,
        dataHoraEmissao: dataHoraEmissao.present
            ? dataHoraEmissao.value
            : this.dataHoraEmissao,
        competencia: competencia.present ? competencia.value : this.competencia,
        numeroSubstituida: numeroSubstituida.present
            ? numeroSubstituida.value
            : this.numeroSubstituida,
        naturezaOperacao: naturezaOperacao.present
            ? naturezaOperacao.value
            : this.naturezaOperacao,
        regimeEspecialTributacao: regimeEspecialTributacao.present
            ? regimeEspecialTributacao.value
            : this.regimeEspecialTributacao,
        optanteSimplesNacional: optanteSimplesNacional.present
            ? optanteSimplesNacional.value
            : this.optanteSimplesNacional,
        incentivadorCultural: incentivadorCultural.present
            ? incentivadorCultural.value
            : this.incentivadorCultural,
        numeroRps: numeroRps.present ? numeroRps.value : this.numeroRps,
        serieRps: serieRps.present ? serieRps.value : this.serieRps,
        tipoRps: tipoRps.present ? tipoRps.value : this.tipoRps,
        dataEmissaoRps:
            dataEmissaoRps.present ? dataEmissaoRps.value : this.dataEmissaoRps,
        outrasInformacoes: outrasInformacoes.present
            ? outrasInformacoes.value
            : this.outrasInformacoes,
      );
  NfseCabecalho copyWithCompanion(NfseCabecalhosCompanion data) {
    return NfseCabecalho(
      id: data.id.present ? data.id.value : this.id,
      idCliente: data.idCliente.present ? data.idCliente.value : this.idCliente,
      idOsAbertura: data.idOsAbertura.present
          ? data.idOsAbertura.value
          : this.idOsAbertura,
      numero: data.numero.present ? data.numero.value : this.numero,
      codigoVerificacao: data.codigoVerificacao.present
          ? data.codigoVerificacao.value
          : this.codigoVerificacao,
      dataHoraEmissao: data.dataHoraEmissao.present
          ? data.dataHoraEmissao.value
          : this.dataHoraEmissao,
      competencia:
          data.competencia.present ? data.competencia.value : this.competencia,
      numeroSubstituida: data.numeroSubstituida.present
          ? data.numeroSubstituida.value
          : this.numeroSubstituida,
      naturezaOperacao: data.naturezaOperacao.present
          ? data.naturezaOperacao.value
          : this.naturezaOperacao,
      regimeEspecialTributacao: data.regimeEspecialTributacao.present
          ? data.regimeEspecialTributacao.value
          : this.regimeEspecialTributacao,
      optanteSimplesNacional: data.optanteSimplesNacional.present
          ? data.optanteSimplesNacional.value
          : this.optanteSimplesNacional,
      incentivadorCultural: data.incentivadorCultural.present
          ? data.incentivadorCultural.value
          : this.incentivadorCultural,
      numeroRps: data.numeroRps.present ? data.numeroRps.value : this.numeroRps,
      serieRps: data.serieRps.present ? data.serieRps.value : this.serieRps,
      tipoRps: data.tipoRps.present ? data.tipoRps.value : this.tipoRps,
      dataEmissaoRps: data.dataEmissaoRps.present
          ? data.dataEmissaoRps.value
          : this.dataEmissaoRps,
      outrasInformacoes: data.outrasInformacoes.present
          ? data.outrasInformacoes.value
          : this.outrasInformacoes,
    );
  }

  @override
  String toString() {
    return (StringBuffer('NfseCabecalho(')
          ..write('id: $id, ')
          ..write('idCliente: $idCliente, ')
          ..write('idOsAbertura: $idOsAbertura, ')
          ..write('numero: $numero, ')
          ..write('codigoVerificacao: $codigoVerificacao, ')
          ..write('dataHoraEmissao: $dataHoraEmissao, ')
          ..write('competencia: $competencia, ')
          ..write('numeroSubstituida: $numeroSubstituida, ')
          ..write('naturezaOperacao: $naturezaOperacao, ')
          ..write('regimeEspecialTributacao: $regimeEspecialTributacao, ')
          ..write('optanteSimplesNacional: $optanteSimplesNacional, ')
          ..write('incentivadorCultural: $incentivadorCultural, ')
          ..write('numeroRps: $numeroRps, ')
          ..write('serieRps: $serieRps, ')
          ..write('tipoRps: $tipoRps, ')
          ..write('dataEmissaoRps: $dataEmissaoRps, ')
          ..write('outrasInformacoes: $outrasInformacoes')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(
      id,
      idCliente,
      idOsAbertura,
      numero,
      codigoVerificacao,
      dataHoraEmissao,
      competencia,
      numeroSubstituida,
      naturezaOperacao,
      regimeEspecialTributacao,
      optanteSimplesNacional,
      incentivadorCultural,
      numeroRps,
      serieRps,
      tipoRps,
      dataEmissaoRps,
      outrasInformacoes);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is NfseCabecalho &&
          other.id == this.id &&
          other.idCliente == this.idCliente &&
          other.idOsAbertura == this.idOsAbertura &&
          other.numero == this.numero &&
          other.codigoVerificacao == this.codigoVerificacao &&
          other.dataHoraEmissao == this.dataHoraEmissao &&
          other.competencia == this.competencia &&
          other.numeroSubstituida == this.numeroSubstituida &&
          other.naturezaOperacao == this.naturezaOperacao &&
          other.regimeEspecialTributacao == this.regimeEspecialTributacao &&
          other.optanteSimplesNacional == this.optanteSimplesNacional &&
          other.incentivadorCultural == this.incentivadorCultural &&
          other.numeroRps == this.numeroRps &&
          other.serieRps == this.serieRps &&
          other.tipoRps == this.tipoRps &&
          other.dataEmissaoRps == this.dataEmissaoRps &&
          other.outrasInformacoes == this.outrasInformacoes);
}

class NfseCabecalhosCompanion extends UpdateCompanion<NfseCabecalho> {
  final Value<int?> id;
  final Value<int?> idCliente;
  final Value<int?> idOsAbertura;
  final Value<String?> numero;
  final Value<String?> codigoVerificacao;
  final Value<DateTime?> dataHoraEmissao;
  final Value<String?> competencia;
  final Value<String?> numeroSubstituida;
  final Value<String?> naturezaOperacao;
  final Value<String?> regimeEspecialTributacao;
  final Value<String?> optanteSimplesNacional;
  final Value<String?> incentivadorCultural;
  final Value<String?> numeroRps;
  final Value<String?> serieRps;
  final Value<String?> tipoRps;
  final Value<DateTime?> dataEmissaoRps;
  final Value<String?> outrasInformacoes;
  const NfseCabecalhosCompanion({
    this.id = const Value.absent(),
    this.idCliente = const Value.absent(),
    this.idOsAbertura = const Value.absent(),
    this.numero = const Value.absent(),
    this.codigoVerificacao = const Value.absent(),
    this.dataHoraEmissao = const Value.absent(),
    this.competencia = const Value.absent(),
    this.numeroSubstituida = const Value.absent(),
    this.naturezaOperacao = const Value.absent(),
    this.regimeEspecialTributacao = const Value.absent(),
    this.optanteSimplesNacional = const Value.absent(),
    this.incentivadorCultural = const Value.absent(),
    this.numeroRps = const Value.absent(),
    this.serieRps = const Value.absent(),
    this.tipoRps = const Value.absent(),
    this.dataEmissaoRps = const Value.absent(),
    this.outrasInformacoes = const Value.absent(),
  });
  NfseCabecalhosCompanion.insert({
    this.id = const Value.absent(),
    this.idCliente = const Value.absent(),
    this.idOsAbertura = const Value.absent(),
    this.numero = const Value.absent(),
    this.codigoVerificacao = const Value.absent(),
    this.dataHoraEmissao = const Value.absent(),
    this.competencia = const Value.absent(),
    this.numeroSubstituida = const Value.absent(),
    this.naturezaOperacao = const Value.absent(),
    this.regimeEspecialTributacao = const Value.absent(),
    this.optanteSimplesNacional = const Value.absent(),
    this.incentivadorCultural = const Value.absent(),
    this.numeroRps = const Value.absent(),
    this.serieRps = const Value.absent(),
    this.tipoRps = const Value.absent(),
    this.dataEmissaoRps = const Value.absent(),
    this.outrasInformacoes = const Value.absent(),
  });
  static Insertable<NfseCabecalho> custom({
    Expression<int>? id,
    Expression<int>? idCliente,
    Expression<int>? idOsAbertura,
    Expression<String>? numero,
    Expression<String>? codigoVerificacao,
    Expression<DateTime>? dataHoraEmissao,
    Expression<String>? competencia,
    Expression<String>? numeroSubstituida,
    Expression<String>? naturezaOperacao,
    Expression<String>? regimeEspecialTributacao,
    Expression<String>? optanteSimplesNacional,
    Expression<String>? incentivadorCultural,
    Expression<String>? numeroRps,
    Expression<String>? serieRps,
    Expression<String>? tipoRps,
    Expression<DateTime>? dataEmissaoRps,
    Expression<String>? outrasInformacoes,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (idCliente != null) 'id_cliente': idCliente,
      if (idOsAbertura != null) 'id_os_abertura': idOsAbertura,
      if (numero != null) 'numero': numero,
      if (codigoVerificacao != null) 'codigo_verificacao': codigoVerificacao,
      if (dataHoraEmissao != null) 'data_hora_emissao': dataHoraEmissao,
      if (competencia != null) 'competencia': competencia,
      if (numeroSubstituida != null) 'numero_substituida': numeroSubstituida,
      if (naturezaOperacao != null) 'natureza_operacao': naturezaOperacao,
      if (regimeEspecialTributacao != null)
        'regime_especial_tributacao': regimeEspecialTributacao,
      if (optanteSimplesNacional != null)
        'optante_simples_nacional': optanteSimplesNacional,
      if (incentivadorCultural != null)
        'incentivador_cultural': incentivadorCultural,
      if (numeroRps != null) 'numero_rps': numeroRps,
      if (serieRps != null) 'serie_rps': serieRps,
      if (tipoRps != null) 'tipo_rps': tipoRps,
      if (dataEmissaoRps != null) 'data_emissao_rps': dataEmissaoRps,
      if (outrasInformacoes != null) 'outras_informacoes': outrasInformacoes,
    });
  }

  NfseCabecalhosCompanion copyWith(
      {Value<int?>? id,
      Value<int?>? idCliente,
      Value<int?>? idOsAbertura,
      Value<String?>? numero,
      Value<String?>? codigoVerificacao,
      Value<DateTime?>? dataHoraEmissao,
      Value<String?>? competencia,
      Value<String?>? numeroSubstituida,
      Value<String?>? naturezaOperacao,
      Value<String?>? regimeEspecialTributacao,
      Value<String?>? optanteSimplesNacional,
      Value<String?>? incentivadorCultural,
      Value<String?>? numeroRps,
      Value<String?>? serieRps,
      Value<String?>? tipoRps,
      Value<DateTime?>? dataEmissaoRps,
      Value<String?>? outrasInformacoes}) {
    return NfseCabecalhosCompanion(
      id: id ?? this.id,
      idCliente: idCliente ?? this.idCliente,
      idOsAbertura: idOsAbertura ?? this.idOsAbertura,
      numero: numero ?? this.numero,
      codigoVerificacao: codigoVerificacao ?? this.codigoVerificacao,
      dataHoraEmissao: dataHoraEmissao ?? this.dataHoraEmissao,
      competencia: competencia ?? this.competencia,
      numeroSubstituida: numeroSubstituida ?? this.numeroSubstituida,
      naturezaOperacao: naturezaOperacao ?? this.naturezaOperacao,
      regimeEspecialTributacao:
          regimeEspecialTributacao ?? this.regimeEspecialTributacao,
      optanteSimplesNacional:
          optanteSimplesNacional ?? this.optanteSimplesNacional,
      incentivadorCultural: incentivadorCultural ?? this.incentivadorCultural,
      numeroRps: numeroRps ?? this.numeroRps,
      serieRps: serieRps ?? this.serieRps,
      tipoRps: tipoRps ?? this.tipoRps,
      dataEmissaoRps: dataEmissaoRps ?? this.dataEmissaoRps,
      outrasInformacoes: outrasInformacoes ?? this.outrasInformacoes,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (idCliente.present) {
      map['id_cliente'] = Variable<int>(idCliente.value);
    }
    if (idOsAbertura.present) {
      map['id_os_abertura'] = Variable<int>(idOsAbertura.value);
    }
    if (numero.present) {
      map['numero'] = Variable<String>(numero.value);
    }
    if (codigoVerificacao.present) {
      map['codigo_verificacao'] = Variable<String>(codigoVerificacao.value);
    }
    if (dataHoraEmissao.present) {
      map['data_hora_emissao'] = Variable<DateTime>(dataHoraEmissao.value);
    }
    if (competencia.present) {
      map['competencia'] = Variable<String>(competencia.value);
    }
    if (numeroSubstituida.present) {
      map['numero_substituida'] = Variable<String>(numeroSubstituida.value);
    }
    if (naturezaOperacao.present) {
      map['natureza_operacao'] = Variable<String>(naturezaOperacao.value);
    }
    if (regimeEspecialTributacao.present) {
      map['regime_especial_tributacao'] =
          Variable<String>(regimeEspecialTributacao.value);
    }
    if (optanteSimplesNacional.present) {
      map['optante_simples_nacional'] =
          Variable<String>(optanteSimplesNacional.value);
    }
    if (incentivadorCultural.present) {
      map['incentivador_cultural'] =
          Variable<String>(incentivadorCultural.value);
    }
    if (numeroRps.present) {
      map['numero_rps'] = Variable<String>(numeroRps.value);
    }
    if (serieRps.present) {
      map['serie_rps'] = Variable<String>(serieRps.value);
    }
    if (tipoRps.present) {
      map['tipo_rps'] = Variable<String>(tipoRps.value);
    }
    if (dataEmissaoRps.present) {
      map['data_emissao_rps'] = Variable<DateTime>(dataEmissaoRps.value);
    }
    if (outrasInformacoes.present) {
      map['outras_informacoes'] = Variable<String>(outrasInformacoes.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('NfseCabecalhosCompanion(')
          ..write('id: $id, ')
          ..write('idCliente: $idCliente, ')
          ..write('idOsAbertura: $idOsAbertura, ')
          ..write('numero: $numero, ')
          ..write('codigoVerificacao: $codigoVerificacao, ')
          ..write('dataHoraEmissao: $dataHoraEmissao, ')
          ..write('competencia: $competencia, ')
          ..write('numeroSubstituida: $numeroSubstituida, ')
          ..write('naturezaOperacao: $naturezaOperacao, ')
          ..write('regimeEspecialTributacao: $regimeEspecialTributacao, ')
          ..write('optanteSimplesNacional: $optanteSimplesNacional, ')
          ..write('incentivadorCultural: $incentivadorCultural, ')
          ..write('numeroRps: $numeroRps, ')
          ..write('serieRps: $serieRps, ')
          ..write('tipoRps: $tipoRps, ')
          ..write('dataEmissaoRps: $dataEmissaoRps, ')
          ..write('outrasInformacoes: $outrasInformacoes')
          ..write(')'))
        .toString();
  }
}

class $NfseListaServicosTable extends NfseListaServicos
    with TableInfo<$NfseListaServicosTable, NfseListaServico> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $NfseListaServicosTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
      'id', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _codigoMeta = const VerificationMeta('codigo');
  @override
  late final GeneratedColumn<String> codigo = GeneratedColumn<String>(
      'codigo', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 5),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _descricaoMeta =
      const VerificationMeta('descricao');
  @override
  late final GeneratedColumn<String> descricao = GeneratedColumn<String>(
      'descricao', aliasedName, true,
      type: DriftSqlType.string, requiredDuringInsert: false);
  @override
  List<GeneratedColumn> get $columns => [id, codigo, descricao];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'nfse_lista_servico';
  @override
  VerificationContext validateIntegrity(Insertable<NfseListaServico> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('codigo')) {
      context.handle(_codigoMeta,
          codigo.isAcceptableOrUnknown(data['codigo']!, _codigoMeta));
    }
    if (data.containsKey('descricao')) {
      context.handle(_descricaoMeta,
          descricao.isAcceptableOrUnknown(data['descricao']!, _descricaoMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  NfseListaServico map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return NfseListaServico(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id']),
      codigo: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}codigo']),
      descricao: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}descricao']),
    );
  }

  @override
  $NfseListaServicosTable createAlias(String alias) {
    return $NfseListaServicosTable(attachedDatabase, alias);
  }
}

class NfseListaServico extends DataClass
    implements Insertable<NfseListaServico> {
  final int? id;
  final String? codigo;
  final String? descricao;
  const NfseListaServico({this.id, this.codigo, this.descricao});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || codigo != null) {
      map['codigo'] = Variable<String>(codigo);
    }
    if (!nullToAbsent || descricao != null) {
      map['descricao'] = Variable<String>(descricao);
    }
    return map;
  }

  factory NfseListaServico.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return NfseListaServico(
      id: serializer.fromJson<int?>(json['id']),
      codigo: serializer.fromJson<String?>(json['codigo']),
      descricao: serializer.fromJson<String?>(json['descricao']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'codigo': serializer.toJson<String?>(codigo),
      'descricao': serializer.toJson<String?>(descricao),
    };
  }

  NfseListaServico copyWith(
          {Value<int?> id = const Value.absent(),
          Value<String?> codigo = const Value.absent(),
          Value<String?> descricao = const Value.absent()}) =>
      NfseListaServico(
        id: id.present ? id.value : this.id,
        codigo: codigo.present ? codigo.value : this.codigo,
        descricao: descricao.present ? descricao.value : this.descricao,
      );
  NfseListaServico copyWithCompanion(NfseListaServicosCompanion data) {
    return NfseListaServico(
      id: data.id.present ? data.id.value : this.id,
      codigo: data.codigo.present ? data.codigo.value : this.codigo,
      descricao: data.descricao.present ? data.descricao.value : this.descricao,
    );
  }

  @override
  String toString() {
    return (StringBuffer('NfseListaServico(')
          ..write('id: $id, ')
          ..write('codigo: $codigo, ')
          ..write('descricao: $descricao')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(id, codigo, descricao);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is NfseListaServico &&
          other.id == this.id &&
          other.codigo == this.codigo &&
          other.descricao == this.descricao);
}

class NfseListaServicosCompanion extends UpdateCompanion<NfseListaServico> {
  final Value<int?> id;
  final Value<String?> codigo;
  final Value<String?> descricao;
  const NfseListaServicosCompanion({
    this.id = const Value.absent(),
    this.codigo = const Value.absent(),
    this.descricao = const Value.absent(),
  });
  NfseListaServicosCompanion.insert({
    this.id = const Value.absent(),
    this.codigo = const Value.absent(),
    this.descricao = const Value.absent(),
  });
  static Insertable<NfseListaServico> custom({
    Expression<int>? id,
    Expression<String>? codigo,
    Expression<String>? descricao,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (codigo != null) 'codigo': codigo,
      if (descricao != null) 'descricao': descricao,
    });
  }

  NfseListaServicosCompanion copyWith(
      {Value<int?>? id, Value<String?>? codigo, Value<String?>? descricao}) {
    return NfseListaServicosCompanion(
      id: id ?? this.id,
      codigo: codigo ?? this.codigo,
      descricao: descricao ?? this.descricao,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (codigo.present) {
      map['codigo'] = Variable<String>(codigo.value);
    }
    if (descricao.present) {
      map['descricao'] = Variable<String>(descricao.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('NfseListaServicosCompanion(')
          ..write('id: $id, ')
          ..write('codigo: $codigo, ')
          ..write('descricao: $descricao')
          ..write(')'))
        .toString();
  }
}

class $ViewControleAcessosTable extends ViewControleAcessos
    with TableInfo<$ViewControleAcessosTable, ViewControleAcesso> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $ViewControleAcessosTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
      'id', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _idPessoaMeta =
      const VerificationMeta('idPessoa');
  @override
  late final GeneratedColumn<int> idPessoa = GeneratedColumn<int>(
      'id_pessoa', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _pessoaNomeMeta =
      const VerificationMeta('pessoaNome');
  @override
  late final GeneratedColumn<String> pessoaNome = GeneratedColumn<String>(
      'pessoa_nome', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 450),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _idColaboradorMeta =
      const VerificationMeta('idColaborador');
  @override
  late final GeneratedColumn<int> idColaborador = GeneratedColumn<int>(
      'id_colaborador', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _idUsuarioMeta =
      const VerificationMeta('idUsuario');
  @override
  late final GeneratedColumn<int> idUsuario = GeneratedColumn<int>(
      'id_usuario', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _administradorMeta =
      const VerificationMeta('administrador');
  @override
  late final GeneratedColumn<String> administrador = GeneratedColumn<String>(
      'administrador', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 3),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _idPapelMeta =
      const VerificationMeta('idPapel');
  @override
  late final GeneratedColumn<int> idPapel = GeneratedColumn<int>(
      'id_papel', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _papelNomeMeta =
      const VerificationMeta('papelNome');
  @override
  late final GeneratedColumn<String> papelNome = GeneratedColumn<String>(
      'papel_nome', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 300),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _papelDescricaoMeta =
      const VerificationMeta('papelDescricao');
  @override
  late final GeneratedColumn<String> papelDescricao = GeneratedColumn<String>(
      'papel_descricao', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 750),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _idFuncaoMeta =
      const VerificationMeta('idFuncao');
  @override
  late final GeneratedColumn<int> idFuncao = GeneratedColumn<int>(
      'id_funcao', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _funcaoNomeMeta =
      const VerificationMeta('funcaoNome');
  @override
  late final GeneratedColumn<String> funcaoNome = GeneratedColumn<String>(
      'funcao_nome', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 300),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _funcaoDescricaoMeta =
      const VerificationMeta('funcaoDescricao');
  @override
  late final GeneratedColumn<String> funcaoDescricao = GeneratedColumn<String>(
      'funcao_descricao', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 750),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _idPapelFuncaoMeta =
      const VerificationMeta('idPapelFuncao');
  @override
  late final GeneratedColumn<int> idPapelFuncao = GeneratedColumn<int>(
      'id_papel_funcao', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _habilitadoMeta =
      const VerificationMeta('habilitado');
  @override
  late final GeneratedColumn<String> habilitado = GeneratedColumn<String>(
      'habilitado', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 3),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _podeInserirMeta =
      const VerificationMeta('podeInserir');
  @override
  late final GeneratedColumn<String> podeInserir = GeneratedColumn<String>(
      'pode_inserir', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 3),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _podeAlterarMeta =
      const VerificationMeta('podeAlterar');
  @override
  late final GeneratedColumn<String> podeAlterar = GeneratedColumn<String>(
      'pode_alterar', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 3),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _podeExcluirMeta =
      const VerificationMeta('podeExcluir');
  @override
  late final GeneratedColumn<String> podeExcluir = GeneratedColumn<String>(
      'pode_excluir', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 3),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  @override
  List<GeneratedColumn> get $columns => [
        id,
        idPessoa,
        pessoaNome,
        idColaborador,
        idUsuario,
        administrador,
        idPapel,
        papelNome,
        papelDescricao,
        idFuncao,
        funcaoNome,
        funcaoDescricao,
        idPapelFuncao,
        habilitado,
        podeInserir,
        podeAlterar,
        podeExcluir
      ];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'view_controle_acesso';
  @override
  VerificationContext validateIntegrity(Insertable<ViewControleAcesso> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('id_pessoa')) {
      context.handle(_idPessoaMeta,
          idPessoa.isAcceptableOrUnknown(data['id_pessoa']!, _idPessoaMeta));
    }
    if (data.containsKey('pessoa_nome')) {
      context.handle(
          _pessoaNomeMeta,
          pessoaNome.isAcceptableOrUnknown(
              data['pessoa_nome']!, _pessoaNomeMeta));
    }
    if (data.containsKey('id_colaborador')) {
      context.handle(
          _idColaboradorMeta,
          idColaborador.isAcceptableOrUnknown(
              data['id_colaborador']!, _idColaboradorMeta));
    }
    if (data.containsKey('id_usuario')) {
      context.handle(_idUsuarioMeta,
          idUsuario.isAcceptableOrUnknown(data['id_usuario']!, _idUsuarioMeta));
    }
    if (data.containsKey('administrador')) {
      context.handle(
          _administradorMeta,
          administrador.isAcceptableOrUnknown(
              data['administrador']!, _administradorMeta));
    }
    if (data.containsKey('id_papel')) {
      context.handle(_idPapelMeta,
          idPapel.isAcceptableOrUnknown(data['id_papel']!, _idPapelMeta));
    }
    if (data.containsKey('papel_nome')) {
      context.handle(_papelNomeMeta,
          papelNome.isAcceptableOrUnknown(data['papel_nome']!, _papelNomeMeta));
    }
    if (data.containsKey('papel_descricao')) {
      context.handle(
          _papelDescricaoMeta,
          papelDescricao.isAcceptableOrUnknown(
              data['papel_descricao']!, _papelDescricaoMeta));
    }
    if (data.containsKey('id_funcao')) {
      context.handle(_idFuncaoMeta,
          idFuncao.isAcceptableOrUnknown(data['id_funcao']!, _idFuncaoMeta));
    }
    if (data.containsKey('funcao_nome')) {
      context.handle(
          _funcaoNomeMeta,
          funcaoNome.isAcceptableOrUnknown(
              data['funcao_nome']!, _funcaoNomeMeta));
    }
    if (data.containsKey('funcao_descricao')) {
      context.handle(
          _funcaoDescricaoMeta,
          funcaoDescricao.isAcceptableOrUnknown(
              data['funcao_descricao']!, _funcaoDescricaoMeta));
    }
    if (data.containsKey('id_papel_funcao')) {
      context.handle(
          _idPapelFuncaoMeta,
          idPapelFuncao.isAcceptableOrUnknown(
              data['id_papel_funcao']!, _idPapelFuncaoMeta));
    }
    if (data.containsKey('habilitado')) {
      context.handle(
          _habilitadoMeta,
          habilitado.isAcceptableOrUnknown(
              data['habilitado']!, _habilitadoMeta));
    }
    if (data.containsKey('pode_inserir')) {
      context.handle(
          _podeInserirMeta,
          podeInserir.isAcceptableOrUnknown(
              data['pode_inserir']!, _podeInserirMeta));
    }
    if (data.containsKey('pode_alterar')) {
      context.handle(
          _podeAlterarMeta,
          podeAlterar.isAcceptableOrUnknown(
              data['pode_alterar']!, _podeAlterarMeta));
    }
    if (data.containsKey('pode_excluir')) {
      context.handle(
          _podeExcluirMeta,
          podeExcluir.isAcceptableOrUnknown(
              data['pode_excluir']!, _podeExcluirMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  ViewControleAcesso map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return ViewControleAcesso(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id']),
      idPessoa: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id_pessoa']),
      pessoaNome: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}pessoa_nome']),
      idColaborador: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id_colaborador']),
      idUsuario: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id_usuario']),
      administrador: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}administrador']),
      idPapel: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id_papel']),
      papelNome: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}papel_nome']),
      papelDescricao: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}papel_descricao']),
      idFuncao: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id_funcao']),
      funcaoNome: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}funcao_nome']),
      funcaoDescricao: attachedDatabase.typeMapping.read(
          DriftSqlType.string, data['${effectivePrefix}funcao_descricao']),
      idPapelFuncao: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id_papel_funcao']),
      habilitado: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}habilitado']),
      podeInserir: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}pode_inserir']),
      podeAlterar: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}pode_alterar']),
      podeExcluir: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}pode_excluir']),
    );
  }

  @override
  $ViewControleAcessosTable createAlias(String alias) {
    return $ViewControleAcessosTable(attachedDatabase, alias);
  }
}

class ViewControleAcesso extends DataClass
    implements Insertable<ViewControleAcesso> {
  final int? id;
  final int? idPessoa;
  final String? pessoaNome;
  final int? idColaborador;
  final int? idUsuario;
  final String? administrador;
  final int? idPapel;
  final String? papelNome;
  final String? papelDescricao;
  final int? idFuncao;
  final String? funcaoNome;
  final String? funcaoDescricao;
  final int? idPapelFuncao;
  final String? habilitado;
  final String? podeInserir;
  final String? podeAlterar;
  final String? podeExcluir;
  const ViewControleAcesso(
      {this.id,
      this.idPessoa,
      this.pessoaNome,
      this.idColaborador,
      this.idUsuario,
      this.administrador,
      this.idPapel,
      this.papelNome,
      this.papelDescricao,
      this.idFuncao,
      this.funcaoNome,
      this.funcaoDescricao,
      this.idPapelFuncao,
      this.habilitado,
      this.podeInserir,
      this.podeAlterar,
      this.podeExcluir});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || idPessoa != null) {
      map['id_pessoa'] = Variable<int>(idPessoa);
    }
    if (!nullToAbsent || pessoaNome != null) {
      map['pessoa_nome'] = Variable<String>(pessoaNome);
    }
    if (!nullToAbsent || idColaborador != null) {
      map['id_colaborador'] = Variable<int>(idColaborador);
    }
    if (!nullToAbsent || idUsuario != null) {
      map['id_usuario'] = Variable<int>(idUsuario);
    }
    if (!nullToAbsent || administrador != null) {
      map['administrador'] = Variable<String>(administrador);
    }
    if (!nullToAbsent || idPapel != null) {
      map['id_papel'] = Variable<int>(idPapel);
    }
    if (!nullToAbsent || papelNome != null) {
      map['papel_nome'] = Variable<String>(papelNome);
    }
    if (!nullToAbsent || papelDescricao != null) {
      map['papel_descricao'] = Variable<String>(papelDescricao);
    }
    if (!nullToAbsent || idFuncao != null) {
      map['id_funcao'] = Variable<int>(idFuncao);
    }
    if (!nullToAbsent || funcaoNome != null) {
      map['funcao_nome'] = Variable<String>(funcaoNome);
    }
    if (!nullToAbsent || funcaoDescricao != null) {
      map['funcao_descricao'] = Variable<String>(funcaoDescricao);
    }
    if (!nullToAbsent || idPapelFuncao != null) {
      map['id_papel_funcao'] = Variable<int>(idPapelFuncao);
    }
    if (!nullToAbsent || habilitado != null) {
      map['habilitado'] = Variable<String>(habilitado);
    }
    if (!nullToAbsent || podeInserir != null) {
      map['pode_inserir'] = Variable<String>(podeInserir);
    }
    if (!nullToAbsent || podeAlterar != null) {
      map['pode_alterar'] = Variable<String>(podeAlterar);
    }
    if (!nullToAbsent || podeExcluir != null) {
      map['pode_excluir'] = Variable<String>(podeExcluir);
    }
    return map;
  }

  factory ViewControleAcesso.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return ViewControleAcesso(
      id: serializer.fromJson<int?>(json['id']),
      idPessoa: serializer.fromJson<int?>(json['idPessoa']),
      pessoaNome: serializer.fromJson<String?>(json['pessoaNome']),
      idColaborador: serializer.fromJson<int?>(json['idColaborador']),
      idUsuario: serializer.fromJson<int?>(json['idUsuario']),
      administrador: serializer.fromJson<String?>(json['administrador']),
      idPapel: serializer.fromJson<int?>(json['idPapel']),
      papelNome: serializer.fromJson<String?>(json['papelNome']),
      papelDescricao: serializer.fromJson<String?>(json['papelDescricao']),
      idFuncao: serializer.fromJson<int?>(json['idFuncao']),
      funcaoNome: serializer.fromJson<String?>(json['funcaoNome']),
      funcaoDescricao: serializer.fromJson<String?>(json['funcaoDescricao']),
      idPapelFuncao: serializer.fromJson<int?>(json['idPapelFuncao']),
      habilitado: serializer.fromJson<String?>(json['habilitado']),
      podeInserir: serializer.fromJson<String?>(json['podeInserir']),
      podeAlterar: serializer.fromJson<String?>(json['podeAlterar']),
      podeExcluir: serializer.fromJson<String?>(json['podeExcluir']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'idPessoa': serializer.toJson<int?>(idPessoa),
      'pessoaNome': serializer.toJson<String?>(pessoaNome),
      'idColaborador': serializer.toJson<int?>(idColaborador),
      'idUsuario': serializer.toJson<int?>(idUsuario),
      'administrador': serializer.toJson<String?>(administrador),
      'idPapel': serializer.toJson<int?>(idPapel),
      'papelNome': serializer.toJson<String?>(papelNome),
      'papelDescricao': serializer.toJson<String?>(papelDescricao),
      'idFuncao': serializer.toJson<int?>(idFuncao),
      'funcaoNome': serializer.toJson<String?>(funcaoNome),
      'funcaoDescricao': serializer.toJson<String?>(funcaoDescricao),
      'idPapelFuncao': serializer.toJson<int?>(idPapelFuncao),
      'habilitado': serializer.toJson<String?>(habilitado),
      'podeInserir': serializer.toJson<String?>(podeInserir),
      'podeAlterar': serializer.toJson<String?>(podeAlterar),
      'podeExcluir': serializer.toJson<String?>(podeExcluir),
    };
  }

  ViewControleAcesso copyWith(
          {Value<int?> id = const Value.absent(),
          Value<int?> idPessoa = const Value.absent(),
          Value<String?> pessoaNome = const Value.absent(),
          Value<int?> idColaborador = const Value.absent(),
          Value<int?> idUsuario = const Value.absent(),
          Value<String?> administrador = const Value.absent(),
          Value<int?> idPapel = const Value.absent(),
          Value<String?> papelNome = const Value.absent(),
          Value<String?> papelDescricao = const Value.absent(),
          Value<int?> idFuncao = const Value.absent(),
          Value<String?> funcaoNome = const Value.absent(),
          Value<String?> funcaoDescricao = const Value.absent(),
          Value<int?> idPapelFuncao = const Value.absent(),
          Value<String?> habilitado = const Value.absent(),
          Value<String?> podeInserir = const Value.absent(),
          Value<String?> podeAlterar = const Value.absent(),
          Value<String?> podeExcluir = const Value.absent()}) =>
      ViewControleAcesso(
        id: id.present ? id.value : this.id,
        idPessoa: idPessoa.present ? idPessoa.value : this.idPessoa,
        pessoaNome: pessoaNome.present ? pessoaNome.value : this.pessoaNome,
        idColaborador:
            idColaborador.present ? idColaborador.value : this.idColaborador,
        idUsuario: idUsuario.present ? idUsuario.value : this.idUsuario,
        administrador:
            administrador.present ? administrador.value : this.administrador,
        idPapel: idPapel.present ? idPapel.value : this.idPapel,
        papelNome: papelNome.present ? papelNome.value : this.papelNome,
        papelDescricao:
            papelDescricao.present ? papelDescricao.value : this.papelDescricao,
        idFuncao: idFuncao.present ? idFuncao.value : this.idFuncao,
        funcaoNome: funcaoNome.present ? funcaoNome.value : this.funcaoNome,
        funcaoDescricao: funcaoDescricao.present
            ? funcaoDescricao.value
            : this.funcaoDescricao,
        idPapelFuncao:
            idPapelFuncao.present ? idPapelFuncao.value : this.idPapelFuncao,
        habilitado: habilitado.present ? habilitado.value : this.habilitado,
        podeInserir: podeInserir.present ? podeInserir.value : this.podeInserir,
        podeAlterar: podeAlterar.present ? podeAlterar.value : this.podeAlterar,
        podeExcluir: podeExcluir.present ? podeExcluir.value : this.podeExcluir,
      );
  ViewControleAcesso copyWithCompanion(ViewControleAcessosCompanion data) {
    return ViewControleAcesso(
      id: data.id.present ? data.id.value : this.id,
      idPessoa: data.idPessoa.present ? data.idPessoa.value : this.idPessoa,
      pessoaNome:
          data.pessoaNome.present ? data.pessoaNome.value : this.pessoaNome,
      idColaborador: data.idColaborador.present
          ? data.idColaborador.value
          : this.idColaborador,
      idUsuario: data.idUsuario.present ? data.idUsuario.value : this.idUsuario,
      administrador: data.administrador.present
          ? data.administrador.value
          : this.administrador,
      idPapel: data.idPapel.present ? data.idPapel.value : this.idPapel,
      papelNome: data.papelNome.present ? data.papelNome.value : this.papelNome,
      papelDescricao: data.papelDescricao.present
          ? data.papelDescricao.value
          : this.papelDescricao,
      idFuncao: data.idFuncao.present ? data.idFuncao.value : this.idFuncao,
      funcaoNome:
          data.funcaoNome.present ? data.funcaoNome.value : this.funcaoNome,
      funcaoDescricao: data.funcaoDescricao.present
          ? data.funcaoDescricao.value
          : this.funcaoDescricao,
      idPapelFuncao: data.idPapelFuncao.present
          ? data.idPapelFuncao.value
          : this.idPapelFuncao,
      habilitado:
          data.habilitado.present ? data.habilitado.value : this.habilitado,
      podeInserir:
          data.podeInserir.present ? data.podeInserir.value : this.podeInserir,
      podeAlterar:
          data.podeAlterar.present ? data.podeAlterar.value : this.podeAlterar,
      podeExcluir:
          data.podeExcluir.present ? data.podeExcluir.value : this.podeExcluir,
    );
  }

  @override
  String toString() {
    return (StringBuffer('ViewControleAcesso(')
          ..write('id: $id, ')
          ..write('idPessoa: $idPessoa, ')
          ..write('pessoaNome: $pessoaNome, ')
          ..write('idColaborador: $idColaborador, ')
          ..write('idUsuario: $idUsuario, ')
          ..write('administrador: $administrador, ')
          ..write('idPapel: $idPapel, ')
          ..write('papelNome: $papelNome, ')
          ..write('papelDescricao: $papelDescricao, ')
          ..write('idFuncao: $idFuncao, ')
          ..write('funcaoNome: $funcaoNome, ')
          ..write('funcaoDescricao: $funcaoDescricao, ')
          ..write('idPapelFuncao: $idPapelFuncao, ')
          ..write('habilitado: $habilitado, ')
          ..write('podeInserir: $podeInserir, ')
          ..write('podeAlterar: $podeAlterar, ')
          ..write('podeExcluir: $podeExcluir')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(
      id,
      idPessoa,
      pessoaNome,
      idColaborador,
      idUsuario,
      administrador,
      idPapel,
      papelNome,
      papelDescricao,
      idFuncao,
      funcaoNome,
      funcaoDescricao,
      idPapelFuncao,
      habilitado,
      podeInserir,
      podeAlterar,
      podeExcluir);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is ViewControleAcesso &&
          other.id == this.id &&
          other.idPessoa == this.idPessoa &&
          other.pessoaNome == this.pessoaNome &&
          other.idColaborador == this.idColaborador &&
          other.idUsuario == this.idUsuario &&
          other.administrador == this.administrador &&
          other.idPapel == this.idPapel &&
          other.papelNome == this.papelNome &&
          other.papelDescricao == this.papelDescricao &&
          other.idFuncao == this.idFuncao &&
          other.funcaoNome == this.funcaoNome &&
          other.funcaoDescricao == this.funcaoDescricao &&
          other.idPapelFuncao == this.idPapelFuncao &&
          other.habilitado == this.habilitado &&
          other.podeInserir == this.podeInserir &&
          other.podeAlterar == this.podeAlterar &&
          other.podeExcluir == this.podeExcluir);
}

class ViewControleAcessosCompanion extends UpdateCompanion<ViewControleAcesso> {
  final Value<int?> id;
  final Value<int?> idPessoa;
  final Value<String?> pessoaNome;
  final Value<int?> idColaborador;
  final Value<int?> idUsuario;
  final Value<String?> administrador;
  final Value<int?> idPapel;
  final Value<String?> papelNome;
  final Value<String?> papelDescricao;
  final Value<int?> idFuncao;
  final Value<String?> funcaoNome;
  final Value<String?> funcaoDescricao;
  final Value<int?> idPapelFuncao;
  final Value<String?> habilitado;
  final Value<String?> podeInserir;
  final Value<String?> podeAlterar;
  final Value<String?> podeExcluir;
  const ViewControleAcessosCompanion({
    this.id = const Value.absent(),
    this.idPessoa = const Value.absent(),
    this.pessoaNome = const Value.absent(),
    this.idColaborador = const Value.absent(),
    this.idUsuario = const Value.absent(),
    this.administrador = const Value.absent(),
    this.idPapel = const Value.absent(),
    this.papelNome = const Value.absent(),
    this.papelDescricao = const Value.absent(),
    this.idFuncao = const Value.absent(),
    this.funcaoNome = const Value.absent(),
    this.funcaoDescricao = const Value.absent(),
    this.idPapelFuncao = const Value.absent(),
    this.habilitado = const Value.absent(),
    this.podeInserir = const Value.absent(),
    this.podeAlterar = const Value.absent(),
    this.podeExcluir = const Value.absent(),
  });
  ViewControleAcessosCompanion.insert({
    this.id = const Value.absent(),
    this.idPessoa = const Value.absent(),
    this.pessoaNome = const Value.absent(),
    this.idColaborador = const Value.absent(),
    this.idUsuario = const Value.absent(),
    this.administrador = const Value.absent(),
    this.idPapel = const Value.absent(),
    this.papelNome = const Value.absent(),
    this.papelDescricao = const Value.absent(),
    this.idFuncao = const Value.absent(),
    this.funcaoNome = const Value.absent(),
    this.funcaoDescricao = const Value.absent(),
    this.idPapelFuncao = const Value.absent(),
    this.habilitado = const Value.absent(),
    this.podeInserir = const Value.absent(),
    this.podeAlterar = const Value.absent(),
    this.podeExcluir = const Value.absent(),
  });
  static Insertable<ViewControleAcesso> custom({
    Expression<int>? id,
    Expression<int>? idPessoa,
    Expression<String>? pessoaNome,
    Expression<int>? idColaborador,
    Expression<int>? idUsuario,
    Expression<String>? administrador,
    Expression<int>? idPapel,
    Expression<String>? papelNome,
    Expression<String>? papelDescricao,
    Expression<int>? idFuncao,
    Expression<String>? funcaoNome,
    Expression<String>? funcaoDescricao,
    Expression<int>? idPapelFuncao,
    Expression<String>? habilitado,
    Expression<String>? podeInserir,
    Expression<String>? podeAlterar,
    Expression<String>? podeExcluir,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (idPessoa != null) 'id_pessoa': idPessoa,
      if (pessoaNome != null) 'pessoa_nome': pessoaNome,
      if (idColaborador != null) 'id_colaborador': idColaborador,
      if (idUsuario != null) 'id_usuario': idUsuario,
      if (administrador != null) 'administrador': administrador,
      if (idPapel != null) 'id_papel': idPapel,
      if (papelNome != null) 'papel_nome': papelNome,
      if (papelDescricao != null) 'papel_descricao': papelDescricao,
      if (idFuncao != null) 'id_funcao': idFuncao,
      if (funcaoNome != null) 'funcao_nome': funcaoNome,
      if (funcaoDescricao != null) 'funcao_descricao': funcaoDescricao,
      if (idPapelFuncao != null) 'id_papel_funcao': idPapelFuncao,
      if (habilitado != null) 'habilitado': habilitado,
      if (podeInserir != null) 'pode_inserir': podeInserir,
      if (podeAlterar != null) 'pode_alterar': podeAlterar,
      if (podeExcluir != null) 'pode_excluir': podeExcluir,
    });
  }

  ViewControleAcessosCompanion copyWith(
      {Value<int?>? id,
      Value<int?>? idPessoa,
      Value<String?>? pessoaNome,
      Value<int?>? idColaborador,
      Value<int?>? idUsuario,
      Value<String?>? administrador,
      Value<int?>? idPapel,
      Value<String?>? papelNome,
      Value<String?>? papelDescricao,
      Value<int?>? idFuncao,
      Value<String?>? funcaoNome,
      Value<String?>? funcaoDescricao,
      Value<int?>? idPapelFuncao,
      Value<String?>? habilitado,
      Value<String?>? podeInserir,
      Value<String?>? podeAlterar,
      Value<String?>? podeExcluir}) {
    return ViewControleAcessosCompanion(
      id: id ?? this.id,
      idPessoa: idPessoa ?? this.idPessoa,
      pessoaNome: pessoaNome ?? this.pessoaNome,
      idColaborador: idColaborador ?? this.idColaborador,
      idUsuario: idUsuario ?? this.idUsuario,
      administrador: administrador ?? this.administrador,
      idPapel: idPapel ?? this.idPapel,
      papelNome: papelNome ?? this.papelNome,
      papelDescricao: papelDescricao ?? this.papelDescricao,
      idFuncao: idFuncao ?? this.idFuncao,
      funcaoNome: funcaoNome ?? this.funcaoNome,
      funcaoDescricao: funcaoDescricao ?? this.funcaoDescricao,
      idPapelFuncao: idPapelFuncao ?? this.idPapelFuncao,
      habilitado: habilitado ?? this.habilitado,
      podeInserir: podeInserir ?? this.podeInserir,
      podeAlterar: podeAlterar ?? this.podeAlterar,
      podeExcluir: podeExcluir ?? this.podeExcluir,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (idPessoa.present) {
      map['id_pessoa'] = Variable<int>(idPessoa.value);
    }
    if (pessoaNome.present) {
      map['pessoa_nome'] = Variable<String>(pessoaNome.value);
    }
    if (idColaborador.present) {
      map['id_colaborador'] = Variable<int>(idColaborador.value);
    }
    if (idUsuario.present) {
      map['id_usuario'] = Variable<int>(idUsuario.value);
    }
    if (administrador.present) {
      map['administrador'] = Variable<String>(administrador.value);
    }
    if (idPapel.present) {
      map['id_papel'] = Variable<int>(idPapel.value);
    }
    if (papelNome.present) {
      map['papel_nome'] = Variable<String>(papelNome.value);
    }
    if (papelDescricao.present) {
      map['papel_descricao'] = Variable<String>(papelDescricao.value);
    }
    if (idFuncao.present) {
      map['id_funcao'] = Variable<int>(idFuncao.value);
    }
    if (funcaoNome.present) {
      map['funcao_nome'] = Variable<String>(funcaoNome.value);
    }
    if (funcaoDescricao.present) {
      map['funcao_descricao'] = Variable<String>(funcaoDescricao.value);
    }
    if (idPapelFuncao.present) {
      map['id_papel_funcao'] = Variable<int>(idPapelFuncao.value);
    }
    if (habilitado.present) {
      map['habilitado'] = Variable<String>(habilitado.value);
    }
    if (podeInserir.present) {
      map['pode_inserir'] = Variable<String>(podeInserir.value);
    }
    if (podeAlterar.present) {
      map['pode_alterar'] = Variable<String>(podeAlterar.value);
    }
    if (podeExcluir.present) {
      map['pode_excluir'] = Variable<String>(podeExcluir.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('ViewControleAcessosCompanion(')
          ..write('id: $id, ')
          ..write('idPessoa: $idPessoa, ')
          ..write('pessoaNome: $pessoaNome, ')
          ..write('idColaborador: $idColaborador, ')
          ..write('idUsuario: $idUsuario, ')
          ..write('administrador: $administrador, ')
          ..write('idPapel: $idPapel, ')
          ..write('papelNome: $papelNome, ')
          ..write('papelDescricao: $papelDescricao, ')
          ..write('idFuncao: $idFuncao, ')
          ..write('funcaoNome: $funcaoNome, ')
          ..write('funcaoDescricao: $funcaoDescricao, ')
          ..write('idPapelFuncao: $idPapelFuncao, ')
          ..write('habilitado: $habilitado, ')
          ..write('podeInserir: $podeInserir, ')
          ..write('podeAlterar: $podeAlterar, ')
          ..write('podeExcluir: $podeExcluir')
          ..write(')'))
        .toString();
  }
}

class $ViewPessoaUsuariosTable extends ViewPessoaUsuarios
    with TableInfo<$ViewPessoaUsuariosTable, ViewPessoaUsuario> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $ViewPessoaUsuariosTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
      'id', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _idPessoaMeta =
      const VerificationMeta('idPessoa');
  @override
  late final GeneratedColumn<int> idPessoa = GeneratedColumn<int>(
      'id_pessoa', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _pessoaNomeMeta =
      const VerificationMeta('pessoaNome');
  @override
  late final GeneratedColumn<String> pessoaNome = GeneratedColumn<String>(
      'pessoa_nome', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 450),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _tipoMeta = const VerificationMeta('tipo');
  @override
  late final GeneratedColumn<String> tipo = GeneratedColumn<String>(
      'tipo', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 3),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _emailMeta = const VerificationMeta('email');
  @override
  late final GeneratedColumn<String> email = GeneratedColumn<String>(
      'email', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 750),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _idColaboradorMeta =
      const VerificationMeta('idColaborador');
  @override
  late final GeneratedColumn<int> idColaborador = GeneratedColumn<int>(
      'id_colaborador', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _idUsuarioMeta =
      const VerificationMeta('idUsuario');
  @override
  late final GeneratedColumn<int> idUsuario = GeneratedColumn<int>(
      'id_usuario', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _loginMeta = const VerificationMeta('login');
  @override
  late final GeneratedColumn<String> login = GeneratedColumn<String>(
      'login', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 150),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _senhaMeta = const VerificationMeta('senha');
  @override
  late final GeneratedColumn<String> senha = GeneratedColumn<String>(
      'senha', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 150),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _dataCadastroMeta =
      const VerificationMeta('dataCadastro');
  @override
  late final GeneratedColumn<DateTime> dataCadastro = GeneratedColumn<DateTime>(
      'data_cadastro', aliasedName, true,
      type: DriftSqlType.dateTime, requiredDuringInsert: false);
  static const VerificationMeta _administradorMeta =
      const VerificationMeta('administrador');
  @override
  late final GeneratedColumn<String> administrador = GeneratedColumn<String>(
      'administrador', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 3),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  @override
  List<GeneratedColumn> get $columns => [
        id,
        idPessoa,
        pessoaNome,
        tipo,
        email,
        idColaborador,
        idUsuario,
        login,
        senha,
        dataCadastro,
        administrador
      ];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'view_pessoa_usuario';
  @override
  VerificationContext validateIntegrity(Insertable<ViewPessoaUsuario> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('id_pessoa')) {
      context.handle(_idPessoaMeta,
          idPessoa.isAcceptableOrUnknown(data['id_pessoa']!, _idPessoaMeta));
    }
    if (data.containsKey('pessoa_nome')) {
      context.handle(
          _pessoaNomeMeta,
          pessoaNome.isAcceptableOrUnknown(
              data['pessoa_nome']!, _pessoaNomeMeta));
    }
    if (data.containsKey('tipo')) {
      context.handle(
          _tipoMeta, tipo.isAcceptableOrUnknown(data['tipo']!, _tipoMeta));
    }
    if (data.containsKey('email')) {
      context.handle(
          _emailMeta, email.isAcceptableOrUnknown(data['email']!, _emailMeta));
    }
    if (data.containsKey('id_colaborador')) {
      context.handle(
          _idColaboradorMeta,
          idColaborador.isAcceptableOrUnknown(
              data['id_colaborador']!, _idColaboradorMeta));
    }
    if (data.containsKey('id_usuario')) {
      context.handle(_idUsuarioMeta,
          idUsuario.isAcceptableOrUnknown(data['id_usuario']!, _idUsuarioMeta));
    }
    if (data.containsKey('login')) {
      context.handle(
          _loginMeta, login.isAcceptableOrUnknown(data['login']!, _loginMeta));
    }
    if (data.containsKey('senha')) {
      context.handle(
          _senhaMeta, senha.isAcceptableOrUnknown(data['senha']!, _senhaMeta));
    }
    if (data.containsKey('data_cadastro')) {
      context.handle(
          _dataCadastroMeta,
          dataCadastro.isAcceptableOrUnknown(
              data['data_cadastro']!, _dataCadastroMeta));
    }
    if (data.containsKey('administrador')) {
      context.handle(
          _administradorMeta,
          administrador.isAcceptableOrUnknown(
              data['administrador']!, _administradorMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  ViewPessoaUsuario map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return ViewPessoaUsuario(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id']),
      idPessoa: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id_pessoa']),
      pessoaNome: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}pessoa_nome']),
      tipo: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}tipo']),
      email: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}email']),
      idColaborador: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id_colaborador']),
      idUsuario: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id_usuario']),
      login: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}login']),
      senha: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}senha']),
      dataCadastro: attachedDatabase.typeMapping
          .read(DriftSqlType.dateTime, data['${effectivePrefix}data_cadastro']),
      administrador: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}administrador']),
    );
  }

  @override
  $ViewPessoaUsuariosTable createAlias(String alias) {
    return $ViewPessoaUsuariosTable(attachedDatabase, alias);
  }
}

class ViewPessoaUsuario extends DataClass
    implements Insertable<ViewPessoaUsuario> {
  final int? id;
  final int? idPessoa;
  final String? pessoaNome;
  final String? tipo;
  final String? email;
  final int? idColaborador;
  final int? idUsuario;
  final String? login;
  final String? senha;
  final DateTime? dataCadastro;
  final String? administrador;
  const ViewPessoaUsuario(
      {this.id,
      this.idPessoa,
      this.pessoaNome,
      this.tipo,
      this.email,
      this.idColaborador,
      this.idUsuario,
      this.login,
      this.senha,
      this.dataCadastro,
      this.administrador});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || idPessoa != null) {
      map['id_pessoa'] = Variable<int>(idPessoa);
    }
    if (!nullToAbsent || pessoaNome != null) {
      map['pessoa_nome'] = Variable<String>(pessoaNome);
    }
    if (!nullToAbsent || tipo != null) {
      map['tipo'] = Variable<String>(tipo);
    }
    if (!nullToAbsent || email != null) {
      map['email'] = Variable<String>(email);
    }
    if (!nullToAbsent || idColaborador != null) {
      map['id_colaborador'] = Variable<int>(idColaborador);
    }
    if (!nullToAbsent || idUsuario != null) {
      map['id_usuario'] = Variable<int>(idUsuario);
    }
    if (!nullToAbsent || login != null) {
      map['login'] = Variable<String>(login);
    }
    if (!nullToAbsent || senha != null) {
      map['senha'] = Variable<String>(senha);
    }
    if (!nullToAbsent || dataCadastro != null) {
      map['data_cadastro'] = Variable<DateTime>(dataCadastro);
    }
    if (!nullToAbsent || administrador != null) {
      map['administrador'] = Variable<String>(administrador);
    }
    return map;
  }

  factory ViewPessoaUsuario.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return ViewPessoaUsuario(
      id: serializer.fromJson<int?>(json['id']),
      idPessoa: serializer.fromJson<int?>(json['idPessoa']),
      pessoaNome: serializer.fromJson<String?>(json['pessoaNome']),
      tipo: serializer.fromJson<String?>(json['tipo']),
      email: serializer.fromJson<String?>(json['email']),
      idColaborador: serializer.fromJson<int?>(json['idColaborador']),
      idUsuario: serializer.fromJson<int?>(json['idUsuario']),
      login: serializer.fromJson<String?>(json['login']),
      senha: serializer.fromJson<String?>(json['senha']),
      dataCadastro: serializer.fromJson<DateTime?>(json['dataCadastro']),
      administrador: serializer.fromJson<String?>(json['administrador']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'idPessoa': serializer.toJson<int?>(idPessoa),
      'pessoaNome': serializer.toJson<String?>(pessoaNome),
      'tipo': serializer.toJson<String?>(tipo),
      'email': serializer.toJson<String?>(email),
      'idColaborador': serializer.toJson<int?>(idColaborador),
      'idUsuario': serializer.toJson<int?>(idUsuario),
      'login': serializer.toJson<String?>(login),
      'senha': serializer.toJson<String?>(senha),
      'dataCadastro': serializer.toJson<DateTime?>(dataCadastro),
      'administrador': serializer.toJson<String?>(administrador),
    };
  }

  ViewPessoaUsuario copyWith(
          {Value<int?> id = const Value.absent(),
          Value<int?> idPessoa = const Value.absent(),
          Value<String?> pessoaNome = const Value.absent(),
          Value<String?> tipo = const Value.absent(),
          Value<String?> email = const Value.absent(),
          Value<int?> idColaborador = const Value.absent(),
          Value<int?> idUsuario = const Value.absent(),
          Value<String?> login = const Value.absent(),
          Value<String?> senha = const Value.absent(),
          Value<DateTime?> dataCadastro = const Value.absent(),
          Value<String?> administrador = const Value.absent()}) =>
      ViewPessoaUsuario(
        id: id.present ? id.value : this.id,
        idPessoa: idPessoa.present ? idPessoa.value : this.idPessoa,
        pessoaNome: pessoaNome.present ? pessoaNome.value : this.pessoaNome,
        tipo: tipo.present ? tipo.value : this.tipo,
        email: email.present ? email.value : this.email,
        idColaborador:
            idColaborador.present ? idColaborador.value : this.idColaborador,
        idUsuario: idUsuario.present ? idUsuario.value : this.idUsuario,
        login: login.present ? login.value : this.login,
        senha: senha.present ? senha.value : this.senha,
        dataCadastro:
            dataCadastro.present ? dataCadastro.value : this.dataCadastro,
        administrador:
            administrador.present ? administrador.value : this.administrador,
      );
  ViewPessoaUsuario copyWithCompanion(ViewPessoaUsuariosCompanion data) {
    return ViewPessoaUsuario(
      id: data.id.present ? data.id.value : this.id,
      idPessoa: data.idPessoa.present ? data.idPessoa.value : this.idPessoa,
      pessoaNome:
          data.pessoaNome.present ? data.pessoaNome.value : this.pessoaNome,
      tipo: data.tipo.present ? data.tipo.value : this.tipo,
      email: data.email.present ? data.email.value : this.email,
      idColaborador: data.idColaborador.present
          ? data.idColaborador.value
          : this.idColaborador,
      idUsuario: data.idUsuario.present ? data.idUsuario.value : this.idUsuario,
      login: data.login.present ? data.login.value : this.login,
      senha: data.senha.present ? data.senha.value : this.senha,
      dataCadastro: data.dataCadastro.present
          ? data.dataCadastro.value
          : this.dataCadastro,
      administrador: data.administrador.present
          ? data.administrador.value
          : this.administrador,
    );
  }

  @override
  String toString() {
    return (StringBuffer('ViewPessoaUsuario(')
          ..write('id: $id, ')
          ..write('idPessoa: $idPessoa, ')
          ..write('pessoaNome: $pessoaNome, ')
          ..write('tipo: $tipo, ')
          ..write('email: $email, ')
          ..write('idColaborador: $idColaborador, ')
          ..write('idUsuario: $idUsuario, ')
          ..write('login: $login, ')
          ..write('senha: $senha, ')
          ..write('dataCadastro: $dataCadastro, ')
          ..write('administrador: $administrador')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(id, idPessoa, pessoaNome, tipo, email,
      idColaborador, idUsuario, login, senha, dataCadastro, administrador);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is ViewPessoaUsuario &&
          other.id == this.id &&
          other.idPessoa == this.idPessoa &&
          other.pessoaNome == this.pessoaNome &&
          other.tipo == this.tipo &&
          other.email == this.email &&
          other.idColaborador == this.idColaborador &&
          other.idUsuario == this.idUsuario &&
          other.login == this.login &&
          other.senha == this.senha &&
          other.dataCadastro == this.dataCadastro &&
          other.administrador == this.administrador);
}

class ViewPessoaUsuariosCompanion extends UpdateCompanion<ViewPessoaUsuario> {
  final Value<int?> id;
  final Value<int?> idPessoa;
  final Value<String?> pessoaNome;
  final Value<String?> tipo;
  final Value<String?> email;
  final Value<int?> idColaborador;
  final Value<int?> idUsuario;
  final Value<String?> login;
  final Value<String?> senha;
  final Value<DateTime?> dataCadastro;
  final Value<String?> administrador;
  const ViewPessoaUsuariosCompanion({
    this.id = const Value.absent(),
    this.idPessoa = const Value.absent(),
    this.pessoaNome = const Value.absent(),
    this.tipo = const Value.absent(),
    this.email = const Value.absent(),
    this.idColaborador = const Value.absent(),
    this.idUsuario = const Value.absent(),
    this.login = const Value.absent(),
    this.senha = const Value.absent(),
    this.dataCadastro = const Value.absent(),
    this.administrador = const Value.absent(),
  });
  ViewPessoaUsuariosCompanion.insert({
    this.id = const Value.absent(),
    this.idPessoa = const Value.absent(),
    this.pessoaNome = const Value.absent(),
    this.tipo = const Value.absent(),
    this.email = const Value.absent(),
    this.idColaborador = const Value.absent(),
    this.idUsuario = const Value.absent(),
    this.login = const Value.absent(),
    this.senha = const Value.absent(),
    this.dataCadastro = const Value.absent(),
    this.administrador = const Value.absent(),
  });
  static Insertable<ViewPessoaUsuario> custom({
    Expression<int>? id,
    Expression<int>? idPessoa,
    Expression<String>? pessoaNome,
    Expression<String>? tipo,
    Expression<String>? email,
    Expression<int>? idColaborador,
    Expression<int>? idUsuario,
    Expression<String>? login,
    Expression<String>? senha,
    Expression<DateTime>? dataCadastro,
    Expression<String>? administrador,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (idPessoa != null) 'id_pessoa': idPessoa,
      if (pessoaNome != null) 'pessoa_nome': pessoaNome,
      if (tipo != null) 'tipo': tipo,
      if (email != null) 'email': email,
      if (idColaborador != null) 'id_colaborador': idColaborador,
      if (idUsuario != null) 'id_usuario': idUsuario,
      if (login != null) 'login': login,
      if (senha != null) 'senha': senha,
      if (dataCadastro != null) 'data_cadastro': dataCadastro,
      if (administrador != null) 'administrador': administrador,
    });
  }

  ViewPessoaUsuariosCompanion copyWith(
      {Value<int?>? id,
      Value<int?>? idPessoa,
      Value<String?>? pessoaNome,
      Value<String?>? tipo,
      Value<String?>? email,
      Value<int?>? idColaborador,
      Value<int?>? idUsuario,
      Value<String?>? login,
      Value<String?>? senha,
      Value<DateTime?>? dataCadastro,
      Value<String?>? administrador}) {
    return ViewPessoaUsuariosCompanion(
      id: id ?? this.id,
      idPessoa: idPessoa ?? this.idPessoa,
      pessoaNome: pessoaNome ?? this.pessoaNome,
      tipo: tipo ?? this.tipo,
      email: email ?? this.email,
      idColaborador: idColaborador ?? this.idColaborador,
      idUsuario: idUsuario ?? this.idUsuario,
      login: login ?? this.login,
      senha: senha ?? this.senha,
      dataCadastro: dataCadastro ?? this.dataCadastro,
      administrador: administrador ?? this.administrador,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (idPessoa.present) {
      map['id_pessoa'] = Variable<int>(idPessoa.value);
    }
    if (pessoaNome.present) {
      map['pessoa_nome'] = Variable<String>(pessoaNome.value);
    }
    if (tipo.present) {
      map['tipo'] = Variable<String>(tipo.value);
    }
    if (email.present) {
      map['email'] = Variable<String>(email.value);
    }
    if (idColaborador.present) {
      map['id_colaborador'] = Variable<int>(idColaborador.value);
    }
    if (idUsuario.present) {
      map['id_usuario'] = Variable<int>(idUsuario.value);
    }
    if (login.present) {
      map['login'] = Variable<String>(login.value);
    }
    if (senha.present) {
      map['senha'] = Variable<String>(senha.value);
    }
    if (dataCadastro.present) {
      map['data_cadastro'] = Variable<DateTime>(dataCadastro.value);
    }
    if (administrador.present) {
      map['administrador'] = Variable<String>(administrador.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('ViewPessoaUsuariosCompanion(')
          ..write('id: $id, ')
          ..write('idPessoa: $idPessoa, ')
          ..write('pessoaNome: $pessoaNome, ')
          ..write('tipo: $tipo, ')
          ..write('email: $email, ')
          ..write('idColaborador: $idColaborador, ')
          ..write('idUsuario: $idUsuario, ')
          ..write('login: $login, ')
          ..write('senha: $senha, ')
          ..write('dataCadastro: $dataCadastro, ')
          ..write('administrador: $administrador')
          ..write(')'))
        .toString();
  }
}

class $ViewPessoaClientesTable extends ViewPessoaClientes
    with TableInfo<$ViewPessoaClientesTable, ViewPessoaCliente> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $ViewPessoaClientesTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
      'id', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _nomeMeta = const VerificationMeta('nome');
  @override
  late final GeneratedColumn<String> nome = GeneratedColumn<String>(
      'nome', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 450),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _tipoMeta = const VerificationMeta('tipo');
  @override
  late final GeneratedColumn<String> tipo = GeneratedColumn<String>(
      'tipo', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 3),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _emailMeta = const VerificationMeta('email');
  @override
  late final GeneratedColumn<String> email = GeneratedColumn<String>(
      'email', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 750),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _siteMeta = const VerificationMeta('site');
  @override
  late final GeneratedColumn<String> site = GeneratedColumn<String>(
      'site', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 450),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _cpfCnpjMeta =
      const VerificationMeta('cpfCnpj');
  @override
  late final GeneratedColumn<String> cpfCnpj = GeneratedColumn<String>(
      'cpf_cnpj', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 20),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _rgIeMeta = const VerificationMeta('rgIe');
  @override
  late final GeneratedColumn<String> rgIe = GeneratedColumn<String>(
      'rg_ie', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 20),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _desdeMeta = const VerificationMeta('desde');
  @override
  late final GeneratedColumn<DateTime> desde = GeneratedColumn<DateTime>(
      'desde', aliasedName, true,
      type: DriftSqlType.dateTime, requiredDuringInsert: false);
  static const VerificationMeta _taxaDescontoMeta =
      const VerificationMeta('taxaDesconto');
  @override
  late final GeneratedColumn<double> taxaDesconto = GeneratedColumn<double>(
      'taxa_desconto', aliasedName, true,
      type: DriftSqlType.double, requiredDuringInsert: false);
  static const VerificationMeta _limiteCreditoMeta =
      const VerificationMeta('limiteCredito');
  @override
  late final GeneratedColumn<double> limiteCredito = GeneratedColumn<double>(
      'limite_credito', aliasedName, true,
      type: DriftSqlType.double, requiredDuringInsert: false);
  static const VerificationMeta _dataCadastroMeta =
      const VerificationMeta('dataCadastro');
  @override
  late final GeneratedColumn<DateTime> dataCadastro = GeneratedColumn<DateTime>(
      'data_cadastro', aliasedName, true,
      type: DriftSqlType.dateTime, requiredDuringInsert: false);
  static const VerificationMeta _observacaoMeta =
      const VerificationMeta('observacao');
  @override
  late final GeneratedColumn<String> observacao = GeneratedColumn<String>(
      'observacao', aliasedName, true,
      type: DriftSqlType.string, requiredDuringInsert: false);
  static const VerificationMeta _idPessoaMeta =
      const VerificationMeta('idPessoa');
  @override
  late final GeneratedColumn<int> idPessoa = GeneratedColumn<int>(
      'id_pessoa', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  @override
  List<GeneratedColumn> get $columns => [
        id,
        nome,
        tipo,
        email,
        site,
        cpfCnpj,
        rgIe,
        desde,
        taxaDesconto,
        limiteCredito,
        dataCadastro,
        observacao,
        idPessoa
      ];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'view_pessoa_cliente';
  @override
  VerificationContext validateIntegrity(Insertable<ViewPessoaCliente> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('nome')) {
      context.handle(
          _nomeMeta, nome.isAcceptableOrUnknown(data['nome']!, _nomeMeta));
    }
    if (data.containsKey('tipo')) {
      context.handle(
          _tipoMeta, tipo.isAcceptableOrUnknown(data['tipo']!, _tipoMeta));
    }
    if (data.containsKey('email')) {
      context.handle(
          _emailMeta, email.isAcceptableOrUnknown(data['email']!, _emailMeta));
    }
    if (data.containsKey('site')) {
      context.handle(
          _siteMeta, site.isAcceptableOrUnknown(data['site']!, _siteMeta));
    }
    if (data.containsKey('cpf_cnpj')) {
      context.handle(_cpfCnpjMeta,
          cpfCnpj.isAcceptableOrUnknown(data['cpf_cnpj']!, _cpfCnpjMeta));
    }
    if (data.containsKey('rg_ie')) {
      context.handle(
          _rgIeMeta, rgIe.isAcceptableOrUnknown(data['rg_ie']!, _rgIeMeta));
    }
    if (data.containsKey('desde')) {
      context.handle(
          _desdeMeta, desde.isAcceptableOrUnknown(data['desde']!, _desdeMeta));
    }
    if (data.containsKey('taxa_desconto')) {
      context.handle(
          _taxaDescontoMeta,
          taxaDesconto.isAcceptableOrUnknown(
              data['taxa_desconto']!, _taxaDescontoMeta));
    }
    if (data.containsKey('limite_credito')) {
      context.handle(
          _limiteCreditoMeta,
          limiteCredito.isAcceptableOrUnknown(
              data['limite_credito']!, _limiteCreditoMeta));
    }
    if (data.containsKey('data_cadastro')) {
      context.handle(
          _dataCadastroMeta,
          dataCadastro.isAcceptableOrUnknown(
              data['data_cadastro']!, _dataCadastroMeta));
    }
    if (data.containsKey('observacao')) {
      context.handle(
          _observacaoMeta,
          observacao.isAcceptableOrUnknown(
              data['observacao']!, _observacaoMeta));
    }
    if (data.containsKey('id_pessoa')) {
      context.handle(_idPessoaMeta,
          idPessoa.isAcceptableOrUnknown(data['id_pessoa']!, _idPessoaMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  ViewPessoaCliente map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return ViewPessoaCliente(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id']),
      nome: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}nome']),
      tipo: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}tipo']),
      email: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}email']),
      site: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}site']),
      cpfCnpj: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}cpf_cnpj']),
      rgIe: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}rg_ie']),
      desde: attachedDatabase.typeMapping
          .read(DriftSqlType.dateTime, data['${effectivePrefix}desde']),
      taxaDesconto: attachedDatabase.typeMapping
          .read(DriftSqlType.double, data['${effectivePrefix}taxa_desconto']),
      limiteCredito: attachedDatabase.typeMapping
          .read(DriftSqlType.double, data['${effectivePrefix}limite_credito']),
      dataCadastro: attachedDatabase.typeMapping
          .read(DriftSqlType.dateTime, data['${effectivePrefix}data_cadastro']),
      observacao: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}observacao']),
      idPessoa: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id_pessoa']),
    );
  }

  @override
  $ViewPessoaClientesTable createAlias(String alias) {
    return $ViewPessoaClientesTable(attachedDatabase, alias);
  }
}

class ViewPessoaCliente extends DataClass
    implements Insertable<ViewPessoaCliente> {
  final int? id;
  final String? nome;
  final String? tipo;
  final String? email;
  final String? site;
  final String? cpfCnpj;
  final String? rgIe;
  final DateTime? desde;
  final double? taxaDesconto;
  final double? limiteCredito;
  final DateTime? dataCadastro;
  final String? observacao;
  final int? idPessoa;
  const ViewPessoaCliente(
      {this.id,
      this.nome,
      this.tipo,
      this.email,
      this.site,
      this.cpfCnpj,
      this.rgIe,
      this.desde,
      this.taxaDesconto,
      this.limiteCredito,
      this.dataCadastro,
      this.observacao,
      this.idPessoa});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || nome != null) {
      map['nome'] = Variable<String>(nome);
    }
    if (!nullToAbsent || tipo != null) {
      map['tipo'] = Variable<String>(tipo);
    }
    if (!nullToAbsent || email != null) {
      map['email'] = Variable<String>(email);
    }
    if (!nullToAbsent || site != null) {
      map['site'] = Variable<String>(site);
    }
    if (!nullToAbsent || cpfCnpj != null) {
      map['cpf_cnpj'] = Variable<String>(cpfCnpj);
    }
    if (!nullToAbsent || rgIe != null) {
      map['rg_ie'] = Variable<String>(rgIe);
    }
    if (!nullToAbsent || desde != null) {
      map['desde'] = Variable<DateTime>(desde);
    }
    if (!nullToAbsent || taxaDesconto != null) {
      map['taxa_desconto'] = Variable<double>(taxaDesconto);
    }
    if (!nullToAbsent || limiteCredito != null) {
      map['limite_credito'] = Variable<double>(limiteCredito);
    }
    if (!nullToAbsent || dataCadastro != null) {
      map['data_cadastro'] = Variable<DateTime>(dataCadastro);
    }
    if (!nullToAbsent || observacao != null) {
      map['observacao'] = Variable<String>(observacao);
    }
    if (!nullToAbsent || idPessoa != null) {
      map['id_pessoa'] = Variable<int>(idPessoa);
    }
    return map;
  }

  factory ViewPessoaCliente.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return ViewPessoaCliente(
      id: serializer.fromJson<int?>(json['id']),
      nome: serializer.fromJson<String?>(json['nome']),
      tipo: serializer.fromJson<String?>(json['tipo']),
      email: serializer.fromJson<String?>(json['email']),
      site: serializer.fromJson<String?>(json['site']),
      cpfCnpj: serializer.fromJson<String?>(json['cpfCnpj']),
      rgIe: serializer.fromJson<String?>(json['rgIe']),
      desde: serializer.fromJson<DateTime?>(json['desde']),
      taxaDesconto: serializer.fromJson<double?>(json['taxaDesconto']),
      limiteCredito: serializer.fromJson<double?>(json['limiteCredito']),
      dataCadastro: serializer.fromJson<DateTime?>(json['dataCadastro']),
      observacao: serializer.fromJson<String?>(json['observacao']),
      idPessoa: serializer.fromJson<int?>(json['idPessoa']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'nome': serializer.toJson<String?>(nome),
      'tipo': serializer.toJson<String?>(tipo),
      'email': serializer.toJson<String?>(email),
      'site': serializer.toJson<String?>(site),
      'cpfCnpj': serializer.toJson<String?>(cpfCnpj),
      'rgIe': serializer.toJson<String?>(rgIe),
      'desde': serializer.toJson<DateTime?>(desde),
      'taxaDesconto': serializer.toJson<double?>(taxaDesconto),
      'limiteCredito': serializer.toJson<double?>(limiteCredito),
      'dataCadastro': serializer.toJson<DateTime?>(dataCadastro),
      'observacao': serializer.toJson<String?>(observacao),
      'idPessoa': serializer.toJson<int?>(idPessoa),
    };
  }

  ViewPessoaCliente copyWith(
          {Value<int?> id = const Value.absent(),
          Value<String?> nome = const Value.absent(),
          Value<String?> tipo = const Value.absent(),
          Value<String?> email = const Value.absent(),
          Value<String?> site = const Value.absent(),
          Value<String?> cpfCnpj = const Value.absent(),
          Value<String?> rgIe = const Value.absent(),
          Value<DateTime?> desde = const Value.absent(),
          Value<double?> taxaDesconto = const Value.absent(),
          Value<double?> limiteCredito = const Value.absent(),
          Value<DateTime?> dataCadastro = const Value.absent(),
          Value<String?> observacao = const Value.absent(),
          Value<int?> idPessoa = const Value.absent()}) =>
      ViewPessoaCliente(
        id: id.present ? id.value : this.id,
        nome: nome.present ? nome.value : this.nome,
        tipo: tipo.present ? tipo.value : this.tipo,
        email: email.present ? email.value : this.email,
        site: site.present ? site.value : this.site,
        cpfCnpj: cpfCnpj.present ? cpfCnpj.value : this.cpfCnpj,
        rgIe: rgIe.present ? rgIe.value : this.rgIe,
        desde: desde.present ? desde.value : this.desde,
        taxaDesconto:
            taxaDesconto.present ? taxaDesconto.value : this.taxaDesconto,
        limiteCredito:
            limiteCredito.present ? limiteCredito.value : this.limiteCredito,
        dataCadastro:
            dataCadastro.present ? dataCadastro.value : this.dataCadastro,
        observacao: observacao.present ? observacao.value : this.observacao,
        idPessoa: idPessoa.present ? idPessoa.value : this.idPessoa,
      );
  ViewPessoaCliente copyWithCompanion(ViewPessoaClientesCompanion data) {
    return ViewPessoaCliente(
      id: data.id.present ? data.id.value : this.id,
      nome: data.nome.present ? data.nome.value : this.nome,
      tipo: data.tipo.present ? data.tipo.value : this.tipo,
      email: data.email.present ? data.email.value : this.email,
      site: data.site.present ? data.site.value : this.site,
      cpfCnpj: data.cpfCnpj.present ? data.cpfCnpj.value : this.cpfCnpj,
      rgIe: data.rgIe.present ? data.rgIe.value : this.rgIe,
      desde: data.desde.present ? data.desde.value : this.desde,
      taxaDesconto: data.taxaDesconto.present
          ? data.taxaDesconto.value
          : this.taxaDesconto,
      limiteCredito: data.limiteCredito.present
          ? data.limiteCredito.value
          : this.limiteCredito,
      dataCadastro: data.dataCadastro.present
          ? data.dataCadastro.value
          : this.dataCadastro,
      observacao:
          data.observacao.present ? data.observacao.value : this.observacao,
      idPessoa: data.idPessoa.present ? data.idPessoa.value : this.idPessoa,
    );
  }

  @override
  String toString() {
    return (StringBuffer('ViewPessoaCliente(')
          ..write('id: $id, ')
          ..write('nome: $nome, ')
          ..write('tipo: $tipo, ')
          ..write('email: $email, ')
          ..write('site: $site, ')
          ..write('cpfCnpj: $cpfCnpj, ')
          ..write('rgIe: $rgIe, ')
          ..write('desde: $desde, ')
          ..write('taxaDesconto: $taxaDesconto, ')
          ..write('limiteCredito: $limiteCredito, ')
          ..write('dataCadastro: $dataCadastro, ')
          ..write('observacao: $observacao, ')
          ..write('idPessoa: $idPessoa')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(id, nome, tipo, email, site, cpfCnpj, rgIe,
      desde, taxaDesconto, limiteCredito, dataCadastro, observacao, idPessoa);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is ViewPessoaCliente &&
          other.id == this.id &&
          other.nome == this.nome &&
          other.tipo == this.tipo &&
          other.email == this.email &&
          other.site == this.site &&
          other.cpfCnpj == this.cpfCnpj &&
          other.rgIe == this.rgIe &&
          other.desde == this.desde &&
          other.taxaDesconto == this.taxaDesconto &&
          other.limiteCredito == this.limiteCredito &&
          other.dataCadastro == this.dataCadastro &&
          other.observacao == this.observacao &&
          other.idPessoa == this.idPessoa);
}

class ViewPessoaClientesCompanion extends UpdateCompanion<ViewPessoaCliente> {
  final Value<int?> id;
  final Value<String?> nome;
  final Value<String?> tipo;
  final Value<String?> email;
  final Value<String?> site;
  final Value<String?> cpfCnpj;
  final Value<String?> rgIe;
  final Value<DateTime?> desde;
  final Value<double?> taxaDesconto;
  final Value<double?> limiteCredito;
  final Value<DateTime?> dataCadastro;
  final Value<String?> observacao;
  final Value<int?> idPessoa;
  const ViewPessoaClientesCompanion({
    this.id = const Value.absent(),
    this.nome = const Value.absent(),
    this.tipo = const Value.absent(),
    this.email = const Value.absent(),
    this.site = const Value.absent(),
    this.cpfCnpj = const Value.absent(),
    this.rgIe = const Value.absent(),
    this.desde = const Value.absent(),
    this.taxaDesconto = const Value.absent(),
    this.limiteCredito = const Value.absent(),
    this.dataCadastro = const Value.absent(),
    this.observacao = const Value.absent(),
    this.idPessoa = const Value.absent(),
  });
  ViewPessoaClientesCompanion.insert({
    this.id = const Value.absent(),
    this.nome = const Value.absent(),
    this.tipo = const Value.absent(),
    this.email = const Value.absent(),
    this.site = const Value.absent(),
    this.cpfCnpj = const Value.absent(),
    this.rgIe = const Value.absent(),
    this.desde = const Value.absent(),
    this.taxaDesconto = const Value.absent(),
    this.limiteCredito = const Value.absent(),
    this.dataCadastro = const Value.absent(),
    this.observacao = const Value.absent(),
    this.idPessoa = const Value.absent(),
  });
  static Insertable<ViewPessoaCliente> custom({
    Expression<int>? id,
    Expression<String>? nome,
    Expression<String>? tipo,
    Expression<String>? email,
    Expression<String>? site,
    Expression<String>? cpfCnpj,
    Expression<String>? rgIe,
    Expression<DateTime>? desde,
    Expression<double>? taxaDesconto,
    Expression<double>? limiteCredito,
    Expression<DateTime>? dataCadastro,
    Expression<String>? observacao,
    Expression<int>? idPessoa,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (nome != null) 'nome': nome,
      if (tipo != null) 'tipo': tipo,
      if (email != null) 'email': email,
      if (site != null) 'site': site,
      if (cpfCnpj != null) 'cpf_cnpj': cpfCnpj,
      if (rgIe != null) 'rg_ie': rgIe,
      if (desde != null) 'desde': desde,
      if (taxaDesconto != null) 'taxa_desconto': taxaDesconto,
      if (limiteCredito != null) 'limite_credito': limiteCredito,
      if (dataCadastro != null) 'data_cadastro': dataCadastro,
      if (observacao != null) 'observacao': observacao,
      if (idPessoa != null) 'id_pessoa': idPessoa,
    });
  }

  ViewPessoaClientesCompanion copyWith(
      {Value<int?>? id,
      Value<String?>? nome,
      Value<String?>? tipo,
      Value<String?>? email,
      Value<String?>? site,
      Value<String?>? cpfCnpj,
      Value<String?>? rgIe,
      Value<DateTime?>? desde,
      Value<double?>? taxaDesconto,
      Value<double?>? limiteCredito,
      Value<DateTime?>? dataCadastro,
      Value<String?>? observacao,
      Value<int?>? idPessoa}) {
    return ViewPessoaClientesCompanion(
      id: id ?? this.id,
      nome: nome ?? this.nome,
      tipo: tipo ?? this.tipo,
      email: email ?? this.email,
      site: site ?? this.site,
      cpfCnpj: cpfCnpj ?? this.cpfCnpj,
      rgIe: rgIe ?? this.rgIe,
      desde: desde ?? this.desde,
      taxaDesconto: taxaDesconto ?? this.taxaDesconto,
      limiteCredito: limiteCredito ?? this.limiteCredito,
      dataCadastro: dataCadastro ?? this.dataCadastro,
      observacao: observacao ?? this.observacao,
      idPessoa: idPessoa ?? this.idPessoa,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (nome.present) {
      map['nome'] = Variable<String>(nome.value);
    }
    if (tipo.present) {
      map['tipo'] = Variable<String>(tipo.value);
    }
    if (email.present) {
      map['email'] = Variable<String>(email.value);
    }
    if (site.present) {
      map['site'] = Variable<String>(site.value);
    }
    if (cpfCnpj.present) {
      map['cpf_cnpj'] = Variable<String>(cpfCnpj.value);
    }
    if (rgIe.present) {
      map['rg_ie'] = Variable<String>(rgIe.value);
    }
    if (desde.present) {
      map['desde'] = Variable<DateTime>(desde.value);
    }
    if (taxaDesconto.present) {
      map['taxa_desconto'] = Variable<double>(taxaDesconto.value);
    }
    if (limiteCredito.present) {
      map['limite_credito'] = Variable<double>(limiteCredito.value);
    }
    if (dataCadastro.present) {
      map['data_cadastro'] = Variable<DateTime>(dataCadastro.value);
    }
    if (observacao.present) {
      map['observacao'] = Variable<String>(observacao.value);
    }
    if (idPessoa.present) {
      map['id_pessoa'] = Variable<int>(idPessoa.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('ViewPessoaClientesCompanion(')
          ..write('id: $id, ')
          ..write('nome: $nome, ')
          ..write('tipo: $tipo, ')
          ..write('email: $email, ')
          ..write('site: $site, ')
          ..write('cpfCnpj: $cpfCnpj, ')
          ..write('rgIe: $rgIe, ')
          ..write('desde: $desde, ')
          ..write('taxaDesconto: $taxaDesconto, ')
          ..write('limiteCredito: $limiteCredito, ')
          ..write('dataCadastro: $dataCadastro, ')
          ..write('observacao: $observacao, ')
          ..write('idPessoa: $idPessoa')
          ..write(')'))
        .toString();
  }
}

class $ViewPessoaColaboradorsTable extends ViewPessoaColaboradors
    with TableInfo<$ViewPessoaColaboradorsTable, ViewPessoaColaborador> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $ViewPessoaColaboradorsTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
      'id', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _nomeMeta = const VerificationMeta('nome');
  @override
  late final GeneratedColumn<String> nome = GeneratedColumn<String>(
      'nome', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 450),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _tipoMeta = const VerificationMeta('tipo');
  @override
  late final GeneratedColumn<String> tipo = GeneratedColumn<String>(
      'tipo', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 3),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _emailMeta = const VerificationMeta('email');
  @override
  late final GeneratedColumn<String> email = GeneratedColumn<String>(
      'email', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 750),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _siteMeta = const VerificationMeta('site');
  @override
  late final GeneratedColumn<String> site = GeneratedColumn<String>(
      'site', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 450),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _cpfCnpjMeta =
      const VerificationMeta('cpfCnpj');
  @override
  late final GeneratedColumn<String> cpfCnpj = GeneratedColumn<String>(
      'cpf_cnpj', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 20),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _rgIeMeta = const VerificationMeta('rgIe');
  @override
  late final GeneratedColumn<String> rgIe = GeneratedColumn<String>(
      'rg_ie', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 20),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _matriculaMeta =
      const VerificationMeta('matricula');
  @override
  late final GeneratedColumn<String> matricula = GeneratedColumn<String>(
      'matricula', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 50),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _dataCadastroMeta =
      const VerificationMeta('dataCadastro');
  @override
  late final GeneratedColumn<DateTime> dataCadastro = GeneratedColumn<DateTime>(
      'data_cadastro', aliasedName, true,
      type: DriftSqlType.dateTime, requiredDuringInsert: false);
  static const VerificationMeta _dataAdmissaoMeta =
      const VerificationMeta('dataAdmissao');
  @override
  late final GeneratedColumn<DateTime> dataAdmissao = GeneratedColumn<DateTime>(
      'data_admissao', aliasedName, true,
      type: DriftSqlType.dateTime, requiredDuringInsert: false);
  static const VerificationMeta _dataDemissaoMeta =
      const VerificationMeta('dataDemissao');
  @override
  late final GeneratedColumn<DateTime> dataDemissao = GeneratedColumn<DateTime>(
      'data_demissao', aliasedName, true,
      type: DriftSqlType.dateTime, requiredDuringInsert: false);
  static const VerificationMeta _ctpsNumeroMeta =
      const VerificationMeta('ctpsNumero');
  @override
  late final GeneratedColumn<String> ctpsNumero = GeneratedColumn<String>(
      'ctps_numero', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 20),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _ctpsSerieMeta =
      const VerificationMeta('ctpsSerie');
  @override
  late final GeneratedColumn<String> ctpsSerie = GeneratedColumn<String>(
      'ctps_serie', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 10),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _ctpsDataExpedicaoMeta =
      const VerificationMeta('ctpsDataExpedicao');
  @override
  late final GeneratedColumn<DateTime> ctpsDataExpedicao =
      GeneratedColumn<DateTime>('ctps_data_expedicao', aliasedName, true,
          type: DriftSqlType.dateTime, requiredDuringInsert: false);
  static const VerificationMeta _ctpsUfMeta = const VerificationMeta('ctpsUf');
  @override
  late final GeneratedColumn<String> ctpsUf = GeneratedColumn<String>(
      'ctps_uf', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 2),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _observacaoMeta =
      const VerificationMeta('observacao');
  @override
  late final GeneratedColumn<String> observacao = GeneratedColumn<String>(
      'observacao', aliasedName, true,
      type: DriftSqlType.string, requiredDuringInsert: false);
  static const VerificationMeta _logradouroMeta =
      const VerificationMeta('logradouro');
  @override
  late final GeneratedColumn<String> logradouro = GeneratedColumn<String>(
      'logradouro', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 450),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _numeroMeta = const VerificationMeta('numero');
  @override
  late final GeneratedColumn<String> numero = GeneratedColumn<String>(
      'numero', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 20),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _complementoMeta =
      const VerificationMeta('complemento');
  @override
  late final GeneratedColumn<String> complemento = GeneratedColumn<String>(
      'complemento', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 450),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _bairroMeta = const VerificationMeta('bairro');
  @override
  late final GeneratedColumn<String> bairro = GeneratedColumn<String>(
      'bairro', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 150),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _cidadeMeta = const VerificationMeta('cidade');
  @override
  late final GeneratedColumn<String> cidade = GeneratedColumn<String>(
      'cidade', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 150),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _cepMeta = const VerificationMeta('cep');
  @override
  late final GeneratedColumn<String> cep = GeneratedColumn<String>(
      'cep', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 10),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _municipioIbgeMeta =
      const VerificationMeta('municipioIbge');
  @override
  late final GeneratedColumn<String> municipioIbge = GeneratedColumn<String>(
      'municipio_ibge', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 10),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _ufMeta = const VerificationMeta('uf');
  @override
  late final GeneratedColumn<String> uf = GeneratedColumn<String>(
      'uf', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 2),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _idPessoaMeta =
      const VerificationMeta('idPessoa');
  @override
  late final GeneratedColumn<int> idPessoa = GeneratedColumn<int>(
      'id_pessoa', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _idCargoMeta =
      const VerificationMeta('idCargo');
  @override
  late final GeneratedColumn<int> idCargo = GeneratedColumn<int>(
      'id_cargo', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _idSetorMeta =
      const VerificationMeta('idSetor');
  @override
  late final GeneratedColumn<int> idSetor = GeneratedColumn<int>(
      'id_setor', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  @override
  List<GeneratedColumn> get $columns => [
        id,
        nome,
        tipo,
        email,
        site,
        cpfCnpj,
        rgIe,
        matricula,
        dataCadastro,
        dataAdmissao,
        dataDemissao,
        ctpsNumero,
        ctpsSerie,
        ctpsDataExpedicao,
        ctpsUf,
        observacao,
        logradouro,
        numero,
        complemento,
        bairro,
        cidade,
        cep,
        municipioIbge,
        uf,
        idPessoa,
        idCargo,
        idSetor
      ];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'view_pessoa_colaborador';
  @override
  VerificationContext validateIntegrity(
      Insertable<ViewPessoaColaborador> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('nome')) {
      context.handle(
          _nomeMeta, nome.isAcceptableOrUnknown(data['nome']!, _nomeMeta));
    }
    if (data.containsKey('tipo')) {
      context.handle(
          _tipoMeta, tipo.isAcceptableOrUnknown(data['tipo']!, _tipoMeta));
    }
    if (data.containsKey('email')) {
      context.handle(
          _emailMeta, email.isAcceptableOrUnknown(data['email']!, _emailMeta));
    }
    if (data.containsKey('site')) {
      context.handle(
          _siteMeta, site.isAcceptableOrUnknown(data['site']!, _siteMeta));
    }
    if (data.containsKey('cpf_cnpj')) {
      context.handle(_cpfCnpjMeta,
          cpfCnpj.isAcceptableOrUnknown(data['cpf_cnpj']!, _cpfCnpjMeta));
    }
    if (data.containsKey('rg_ie')) {
      context.handle(
          _rgIeMeta, rgIe.isAcceptableOrUnknown(data['rg_ie']!, _rgIeMeta));
    }
    if (data.containsKey('matricula')) {
      context.handle(_matriculaMeta,
          matricula.isAcceptableOrUnknown(data['matricula']!, _matriculaMeta));
    }
    if (data.containsKey('data_cadastro')) {
      context.handle(
          _dataCadastroMeta,
          dataCadastro.isAcceptableOrUnknown(
              data['data_cadastro']!, _dataCadastroMeta));
    }
    if (data.containsKey('data_admissao')) {
      context.handle(
          _dataAdmissaoMeta,
          dataAdmissao.isAcceptableOrUnknown(
              data['data_admissao']!, _dataAdmissaoMeta));
    }
    if (data.containsKey('data_demissao')) {
      context.handle(
          _dataDemissaoMeta,
          dataDemissao.isAcceptableOrUnknown(
              data['data_demissao']!, _dataDemissaoMeta));
    }
    if (data.containsKey('ctps_numero')) {
      context.handle(
          _ctpsNumeroMeta,
          ctpsNumero.isAcceptableOrUnknown(
              data['ctps_numero']!, _ctpsNumeroMeta));
    }
    if (data.containsKey('ctps_serie')) {
      context.handle(_ctpsSerieMeta,
          ctpsSerie.isAcceptableOrUnknown(data['ctps_serie']!, _ctpsSerieMeta));
    }
    if (data.containsKey('ctps_data_expedicao')) {
      context.handle(
          _ctpsDataExpedicaoMeta,
          ctpsDataExpedicao.isAcceptableOrUnknown(
              data['ctps_data_expedicao']!, _ctpsDataExpedicaoMeta));
    }
    if (data.containsKey('ctps_uf')) {
      context.handle(_ctpsUfMeta,
          ctpsUf.isAcceptableOrUnknown(data['ctps_uf']!, _ctpsUfMeta));
    }
    if (data.containsKey('observacao')) {
      context.handle(
          _observacaoMeta,
          observacao.isAcceptableOrUnknown(
              data['observacao']!, _observacaoMeta));
    }
    if (data.containsKey('logradouro')) {
      context.handle(
          _logradouroMeta,
          logradouro.isAcceptableOrUnknown(
              data['logradouro']!, _logradouroMeta));
    }
    if (data.containsKey('numero')) {
      context.handle(_numeroMeta,
          numero.isAcceptableOrUnknown(data['numero']!, _numeroMeta));
    }
    if (data.containsKey('complemento')) {
      context.handle(
          _complementoMeta,
          complemento.isAcceptableOrUnknown(
              data['complemento']!, _complementoMeta));
    }
    if (data.containsKey('bairro')) {
      context.handle(_bairroMeta,
          bairro.isAcceptableOrUnknown(data['bairro']!, _bairroMeta));
    }
    if (data.containsKey('cidade')) {
      context.handle(_cidadeMeta,
          cidade.isAcceptableOrUnknown(data['cidade']!, _cidadeMeta));
    }
    if (data.containsKey('cep')) {
      context.handle(
          _cepMeta, cep.isAcceptableOrUnknown(data['cep']!, _cepMeta));
    }
    if (data.containsKey('municipio_ibge')) {
      context.handle(
          _municipioIbgeMeta,
          municipioIbge.isAcceptableOrUnknown(
              data['municipio_ibge']!, _municipioIbgeMeta));
    }
    if (data.containsKey('uf')) {
      context.handle(_ufMeta, uf.isAcceptableOrUnknown(data['uf']!, _ufMeta));
    }
    if (data.containsKey('id_pessoa')) {
      context.handle(_idPessoaMeta,
          idPessoa.isAcceptableOrUnknown(data['id_pessoa']!, _idPessoaMeta));
    }
    if (data.containsKey('id_cargo')) {
      context.handle(_idCargoMeta,
          idCargo.isAcceptableOrUnknown(data['id_cargo']!, _idCargoMeta));
    }
    if (data.containsKey('id_setor')) {
      context.handle(_idSetorMeta,
          idSetor.isAcceptableOrUnknown(data['id_setor']!, _idSetorMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  ViewPessoaColaborador map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return ViewPessoaColaborador(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id']),
      nome: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}nome']),
      tipo: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}tipo']),
      email: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}email']),
      site: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}site']),
      cpfCnpj: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}cpf_cnpj']),
      rgIe: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}rg_ie']),
      matricula: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}matricula']),
      dataCadastro: attachedDatabase.typeMapping
          .read(DriftSqlType.dateTime, data['${effectivePrefix}data_cadastro']),
      dataAdmissao: attachedDatabase.typeMapping
          .read(DriftSqlType.dateTime, data['${effectivePrefix}data_admissao']),
      dataDemissao: attachedDatabase.typeMapping
          .read(DriftSqlType.dateTime, data['${effectivePrefix}data_demissao']),
      ctpsNumero: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}ctps_numero']),
      ctpsSerie: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}ctps_serie']),
      ctpsDataExpedicao: attachedDatabase.typeMapping.read(
          DriftSqlType.dateTime, data['${effectivePrefix}ctps_data_expedicao']),
      ctpsUf: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}ctps_uf']),
      observacao: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}observacao']),
      logradouro: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}logradouro']),
      numero: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}numero']),
      complemento: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}complemento']),
      bairro: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}bairro']),
      cidade: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}cidade']),
      cep: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}cep']),
      municipioIbge: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}municipio_ibge']),
      uf: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}uf']),
      idPessoa: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id_pessoa']),
      idCargo: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id_cargo']),
      idSetor: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id_setor']),
    );
  }

  @override
  $ViewPessoaColaboradorsTable createAlias(String alias) {
    return $ViewPessoaColaboradorsTable(attachedDatabase, alias);
  }
}

class ViewPessoaColaborador extends DataClass
    implements Insertable<ViewPessoaColaborador> {
  final int? id;
  final String? nome;
  final String? tipo;
  final String? email;
  final String? site;
  final String? cpfCnpj;
  final String? rgIe;
  final String? matricula;
  final DateTime? dataCadastro;
  final DateTime? dataAdmissao;
  final DateTime? dataDemissao;
  final String? ctpsNumero;
  final String? ctpsSerie;
  final DateTime? ctpsDataExpedicao;
  final String? ctpsUf;
  final String? observacao;
  final String? logradouro;
  final String? numero;
  final String? complemento;
  final String? bairro;
  final String? cidade;
  final String? cep;
  final String? municipioIbge;
  final String? uf;
  final int? idPessoa;
  final int? idCargo;
  final int? idSetor;
  const ViewPessoaColaborador(
      {this.id,
      this.nome,
      this.tipo,
      this.email,
      this.site,
      this.cpfCnpj,
      this.rgIe,
      this.matricula,
      this.dataCadastro,
      this.dataAdmissao,
      this.dataDemissao,
      this.ctpsNumero,
      this.ctpsSerie,
      this.ctpsDataExpedicao,
      this.ctpsUf,
      this.observacao,
      this.logradouro,
      this.numero,
      this.complemento,
      this.bairro,
      this.cidade,
      this.cep,
      this.municipioIbge,
      this.uf,
      this.idPessoa,
      this.idCargo,
      this.idSetor});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || nome != null) {
      map['nome'] = Variable<String>(nome);
    }
    if (!nullToAbsent || tipo != null) {
      map['tipo'] = Variable<String>(tipo);
    }
    if (!nullToAbsent || email != null) {
      map['email'] = Variable<String>(email);
    }
    if (!nullToAbsent || site != null) {
      map['site'] = Variable<String>(site);
    }
    if (!nullToAbsent || cpfCnpj != null) {
      map['cpf_cnpj'] = Variable<String>(cpfCnpj);
    }
    if (!nullToAbsent || rgIe != null) {
      map['rg_ie'] = Variable<String>(rgIe);
    }
    if (!nullToAbsent || matricula != null) {
      map['matricula'] = Variable<String>(matricula);
    }
    if (!nullToAbsent || dataCadastro != null) {
      map['data_cadastro'] = Variable<DateTime>(dataCadastro);
    }
    if (!nullToAbsent || dataAdmissao != null) {
      map['data_admissao'] = Variable<DateTime>(dataAdmissao);
    }
    if (!nullToAbsent || dataDemissao != null) {
      map['data_demissao'] = Variable<DateTime>(dataDemissao);
    }
    if (!nullToAbsent || ctpsNumero != null) {
      map['ctps_numero'] = Variable<String>(ctpsNumero);
    }
    if (!nullToAbsent || ctpsSerie != null) {
      map['ctps_serie'] = Variable<String>(ctpsSerie);
    }
    if (!nullToAbsent || ctpsDataExpedicao != null) {
      map['ctps_data_expedicao'] = Variable<DateTime>(ctpsDataExpedicao);
    }
    if (!nullToAbsent || ctpsUf != null) {
      map['ctps_uf'] = Variable<String>(ctpsUf);
    }
    if (!nullToAbsent || observacao != null) {
      map['observacao'] = Variable<String>(observacao);
    }
    if (!nullToAbsent || logradouro != null) {
      map['logradouro'] = Variable<String>(logradouro);
    }
    if (!nullToAbsent || numero != null) {
      map['numero'] = Variable<String>(numero);
    }
    if (!nullToAbsent || complemento != null) {
      map['complemento'] = Variable<String>(complemento);
    }
    if (!nullToAbsent || bairro != null) {
      map['bairro'] = Variable<String>(bairro);
    }
    if (!nullToAbsent || cidade != null) {
      map['cidade'] = Variable<String>(cidade);
    }
    if (!nullToAbsent || cep != null) {
      map['cep'] = Variable<String>(cep);
    }
    if (!nullToAbsent || municipioIbge != null) {
      map['municipio_ibge'] = Variable<String>(municipioIbge);
    }
    if (!nullToAbsent || uf != null) {
      map['uf'] = Variable<String>(uf);
    }
    if (!nullToAbsent || idPessoa != null) {
      map['id_pessoa'] = Variable<int>(idPessoa);
    }
    if (!nullToAbsent || idCargo != null) {
      map['id_cargo'] = Variable<int>(idCargo);
    }
    if (!nullToAbsent || idSetor != null) {
      map['id_setor'] = Variable<int>(idSetor);
    }
    return map;
  }

  factory ViewPessoaColaborador.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return ViewPessoaColaborador(
      id: serializer.fromJson<int?>(json['id']),
      nome: serializer.fromJson<String?>(json['nome']),
      tipo: serializer.fromJson<String?>(json['tipo']),
      email: serializer.fromJson<String?>(json['email']),
      site: serializer.fromJson<String?>(json['site']),
      cpfCnpj: serializer.fromJson<String?>(json['cpfCnpj']),
      rgIe: serializer.fromJson<String?>(json['rgIe']),
      matricula: serializer.fromJson<String?>(json['matricula']),
      dataCadastro: serializer.fromJson<DateTime?>(json['dataCadastro']),
      dataAdmissao: serializer.fromJson<DateTime?>(json['dataAdmissao']),
      dataDemissao: serializer.fromJson<DateTime?>(json['dataDemissao']),
      ctpsNumero: serializer.fromJson<String?>(json['ctpsNumero']),
      ctpsSerie: serializer.fromJson<String?>(json['ctpsSerie']),
      ctpsDataExpedicao:
          serializer.fromJson<DateTime?>(json['ctpsDataExpedicao']),
      ctpsUf: serializer.fromJson<String?>(json['ctpsUf']),
      observacao: serializer.fromJson<String?>(json['observacao']),
      logradouro: serializer.fromJson<String?>(json['logradouro']),
      numero: serializer.fromJson<String?>(json['numero']),
      complemento: serializer.fromJson<String?>(json['complemento']),
      bairro: serializer.fromJson<String?>(json['bairro']),
      cidade: serializer.fromJson<String?>(json['cidade']),
      cep: serializer.fromJson<String?>(json['cep']),
      municipioIbge: serializer.fromJson<String?>(json['municipioIbge']),
      uf: serializer.fromJson<String?>(json['uf']),
      idPessoa: serializer.fromJson<int?>(json['idPessoa']),
      idCargo: serializer.fromJson<int?>(json['idCargo']),
      idSetor: serializer.fromJson<int?>(json['idSetor']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'nome': serializer.toJson<String?>(nome),
      'tipo': serializer.toJson<String?>(tipo),
      'email': serializer.toJson<String?>(email),
      'site': serializer.toJson<String?>(site),
      'cpfCnpj': serializer.toJson<String?>(cpfCnpj),
      'rgIe': serializer.toJson<String?>(rgIe),
      'matricula': serializer.toJson<String?>(matricula),
      'dataCadastro': serializer.toJson<DateTime?>(dataCadastro),
      'dataAdmissao': serializer.toJson<DateTime?>(dataAdmissao),
      'dataDemissao': serializer.toJson<DateTime?>(dataDemissao),
      'ctpsNumero': serializer.toJson<String?>(ctpsNumero),
      'ctpsSerie': serializer.toJson<String?>(ctpsSerie),
      'ctpsDataExpedicao': serializer.toJson<DateTime?>(ctpsDataExpedicao),
      'ctpsUf': serializer.toJson<String?>(ctpsUf),
      'observacao': serializer.toJson<String?>(observacao),
      'logradouro': serializer.toJson<String?>(logradouro),
      'numero': serializer.toJson<String?>(numero),
      'complemento': serializer.toJson<String?>(complemento),
      'bairro': serializer.toJson<String?>(bairro),
      'cidade': serializer.toJson<String?>(cidade),
      'cep': serializer.toJson<String?>(cep),
      'municipioIbge': serializer.toJson<String?>(municipioIbge),
      'uf': serializer.toJson<String?>(uf),
      'idPessoa': serializer.toJson<int?>(idPessoa),
      'idCargo': serializer.toJson<int?>(idCargo),
      'idSetor': serializer.toJson<int?>(idSetor),
    };
  }

  ViewPessoaColaborador copyWith(
          {Value<int?> id = const Value.absent(),
          Value<String?> nome = const Value.absent(),
          Value<String?> tipo = const Value.absent(),
          Value<String?> email = const Value.absent(),
          Value<String?> site = const Value.absent(),
          Value<String?> cpfCnpj = const Value.absent(),
          Value<String?> rgIe = const Value.absent(),
          Value<String?> matricula = const Value.absent(),
          Value<DateTime?> dataCadastro = const Value.absent(),
          Value<DateTime?> dataAdmissao = const Value.absent(),
          Value<DateTime?> dataDemissao = const Value.absent(),
          Value<String?> ctpsNumero = const Value.absent(),
          Value<String?> ctpsSerie = const Value.absent(),
          Value<DateTime?> ctpsDataExpedicao = const Value.absent(),
          Value<String?> ctpsUf = const Value.absent(),
          Value<String?> observacao = const Value.absent(),
          Value<String?> logradouro = const Value.absent(),
          Value<String?> numero = const Value.absent(),
          Value<String?> complemento = const Value.absent(),
          Value<String?> bairro = const Value.absent(),
          Value<String?> cidade = const Value.absent(),
          Value<String?> cep = const Value.absent(),
          Value<String?> municipioIbge = const Value.absent(),
          Value<String?> uf = const Value.absent(),
          Value<int?> idPessoa = const Value.absent(),
          Value<int?> idCargo = const Value.absent(),
          Value<int?> idSetor = const Value.absent()}) =>
      ViewPessoaColaborador(
        id: id.present ? id.value : this.id,
        nome: nome.present ? nome.value : this.nome,
        tipo: tipo.present ? tipo.value : this.tipo,
        email: email.present ? email.value : this.email,
        site: site.present ? site.value : this.site,
        cpfCnpj: cpfCnpj.present ? cpfCnpj.value : this.cpfCnpj,
        rgIe: rgIe.present ? rgIe.value : this.rgIe,
        matricula: matricula.present ? matricula.value : this.matricula,
        dataCadastro:
            dataCadastro.present ? dataCadastro.value : this.dataCadastro,
        dataAdmissao:
            dataAdmissao.present ? dataAdmissao.value : this.dataAdmissao,
        dataDemissao:
            dataDemissao.present ? dataDemissao.value : this.dataDemissao,
        ctpsNumero: ctpsNumero.present ? ctpsNumero.value : this.ctpsNumero,
        ctpsSerie: ctpsSerie.present ? ctpsSerie.value : this.ctpsSerie,
        ctpsDataExpedicao: ctpsDataExpedicao.present
            ? ctpsDataExpedicao.value
            : this.ctpsDataExpedicao,
        ctpsUf: ctpsUf.present ? ctpsUf.value : this.ctpsUf,
        observacao: observacao.present ? observacao.value : this.observacao,
        logradouro: logradouro.present ? logradouro.value : this.logradouro,
        numero: numero.present ? numero.value : this.numero,
        complemento: complemento.present ? complemento.value : this.complemento,
        bairro: bairro.present ? bairro.value : this.bairro,
        cidade: cidade.present ? cidade.value : this.cidade,
        cep: cep.present ? cep.value : this.cep,
        municipioIbge:
            municipioIbge.present ? municipioIbge.value : this.municipioIbge,
        uf: uf.present ? uf.value : this.uf,
        idPessoa: idPessoa.present ? idPessoa.value : this.idPessoa,
        idCargo: idCargo.present ? idCargo.value : this.idCargo,
        idSetor: idSetor.present ? idSetor.value : this.idSetor,
      );
  ViewPessoaColaborador copyWithCompanion(
      ViewPessoaColaboradorsCompanion data) {
    return ViewPessoaColaborador(
      id: data.id.present ? data.id.value : this.id,
      nome: data.nome.present ? data.nome.value : this.nome,
      tipo: data.tipo.present ? data.tipo.value : this.tipo,
      email: data.email.present ? data.email.value : this.email,
      site: data.site.present ? data.site.value : this.site,
      cpfCnpj: data.cpfCnpj.present ? data.cpfCnpj.value : this.cpfCnpj,
      rgIe: data.rgIe.present ? data.rgIe.value : this.rgIe,
      matricula: data.matricula.present ? data.matricula.value : this.matricula,
      dataCadastro: data.dataCadastro.present
          ? data.dataCadastro.value
          : this.dataCadastro,
      dataAdmissao: data.dataAdmissao.present
          ? data.dataAdmissao.value
          : this.dataAdmissao,
      dataDemissao: data.dataDemissao.present
          ? data.dataDemissao.value
          : this.dataDemissao,
      ctpsNumero:
          data.ctpsNumero.present ? data.ctpsNumero.value : this.ctpsNumero,
      ctpsSerie: data.ctpsSerie.present ? data.ctpsSerie.value : this.ctpsSerie,
      ctpsDataExpedicao: data.ctpsDataExpedicao.present
          ? data.ctpsDataExpedicao.value
          : this.ctpsDataExpedicao,
      ctpsUf: data.ctpsUf.present ? data.ctpsUf.value : this.ctpsUf,
      observacao:
          data.observacao.present ? data.observacao.value : this.observacao,
      logradouro:
          data.logradouro.present ? data.logradouro.value : this.logradouro,
      numero: data.numero.present ? data.numero.value : this.numero,
      complemento:
          data.complemento.present ? data.complemento.value : this.complemento,
      bairro: data.bairro.present ? data.bairro.value : this.bairro,
      cidade: data.cidade.present ? data.cidade.value : this.cidade,
      cep: data.cep.present ? data.cep.value : this.cep,
      municipioIbge: data.municipioIbge.present
          ? data.municipioIbge.value
          : this.municipioIbge,
      uf: data.uf.present ? data.uf.value : this.uf,
      idPessoa: data.idPessoa.present ? data.idPessoa.value : this.idPessoa,
      idCargo: data.idCargo.present ? data.idCargo.value : this.idCargo,
      idSetor: data.idSetor.present ? data.idSetor.value : this.idSetor,
    );
  }

  @override
  String toString() {
    return (StringBuffer('ViewPessoaColaborador(')
          ..write('id: $id, ')
          ..write('nome: $nome, ')
          ..write('tipo: $tipo, ')
          ..write('email: $email, ')
          ..write('site: $site, ')
          ..write('cpfCnpj: $cpfCnpj, ')
          ..write('rgIe: $rgIe, ')
          ..write('matricula: $matricula, ')
          ..write('dataCadastro: $dataCadastro, ')
          ..write('dataAdmissao: $dataAdmissao, ')
          ..write('dataDemissao: $dataDemissao, ')
          ..write('ctpsNumero: $ctpsNumero, ')
          ..write('ctpsSerie: $ctpsSerie, ')
          ..write('ctpsDataExpedicao: $ctpsDataExpedicao, ')
          ..write('ctpsUf: $ctpsUf, ')
          ..write('observacao: $observacao, ')
          ..write('logradouro: $logradouro, ')
          ..write('numero: $numero, ')
          ..write('complemento: $complemento, ')
          ..write('bairro: $bairro, ')
          ..write('cidade: $cidade, ')
          ..write('cep: $cep, ')
          ..write('municipioIbge: $municipioIbge, ')
          ..write('uf: $uf, ')
          ..write('idPessoa: $idPessoa, ')
          ..write('idCargo: $idCargo, ')
          ..write('idSetor: $idSetor')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hashAll([
        id,
        nome,
        tipo,
        email,
        site,
        cpfCnpj,
        rgIe,
        matricula,
        dataCadastro,
        dataAdmissao,
        dataDemissao,
        ctpsNumero,
        ctpsSerie,
        ctpsDataExpedicao,
        ctpsUf,
        observacao,
        logradouro,
        numero,
        complemento,
        bairro,
        cidade,
        cep,
        municipioIbge,
        uf,
        idPessoa,
        idCargo,
        idSetor
      ]);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is ViewPessoaColaborador &&
          other.id == this.id &&
          other.nome == this.nome &&
          other.tipo == this.tipo &&
          other.email == this.email &&
          other.site == this.site &&
          other.cpfCnpj == this.cpfCnpj &&
          other.rgIe == this.rgIe &&
          other.matricula == this.matricula &&
          other.dataCadastro == this.dataCadastro &&
          other.dataAdmissao == this.dataAdmissao &&
          other.dataDemissao == this.dataDemissao &&
          other.ctpsNumero == this.ctpsNumero &&
          other.ctpsSerie == this.ctpsSerie &&
          other.ctpsDataExpedicao == this.ctpsDataExpedicao &&
          other.ctpsUf == this.ctpsUf &&
          other.observacao == this.observacao &&
          other.logradouro == this.logradouro &&
          other.numero == this.numero &&
          other.complemento == this.complemento &&
          other.bairro == this.bairro &&
          other.cidade == this.cidade &&
          other.cep == this.cep &&
          other.municipioIbge == this.municipioIbge &&
          other.uf == this.uf &&
          other.idPessoa == this.idPessoa &&
          other.idCargo == this.idCargo &&
          other.idSetor == this.idSetor);
}

class ViewPessoaColaboradorsCompanion
    extends UpdateCompanion<ViewPessoaColaborador> {
  final Value<int?> id;
  final Value<String?> nome;
  final Value<String?> tipo;
  final Value<String?> email;
  final Value<String?> site;
  final Value<String?> cpfCnpj;
  final Value<String?> rgIe;
  final Value<String?> matricula;
  final Value<DateTime?> dataCadastro;
  final Value<DateTime?> dataAdmissao;
  final Value<DateTime?> dataDemissao;
  final Value<String?> ctpsNumero;
  final Value<String?> ctpsSerie;
  final Value<DateTime?> ctpsDataExpedicao;
  final Value<String?> ctpsUf;
  final Value<String?> observacao;
  final Value<String?> logradouro;
  final Value<String?> numero;
  final Value<String?> complemento;
  final Value<String?> bairro;
  final Value<String?> cidade;
  final Value<String?> cep;
  final Value<String?> municipioIbge;
  final Value<String?> uf;
  final Value<int?> idPessoa;
  final Value<int?> idCargo;
  final Value<int?> idSetor;
  const ViewPessoaColaboradorsCompanion({
    this.id = const Value.absent(),
    this.nome = const Value.absent(),
    this.tipo = const Value.absent(),
    this.email = const Value.absent(),
    this.site = const Value.absent(),
    this.cpfCnpj = const Value.absent(),
    this.rgIe = const Value.absent(),
    this.matricula = const Value.absent(),
    this.dataCadastro = const Value.absent(),
    this.dataAdmissao = const Value.absent(),
    this.dataDemissao = const Value.absent(),
    this.ctpsNumero = const Value.absent(),
    this.ctpsSerie = const Value.absent(),
    this.ctpsDataExpedicao = const Value.absent(),
    this.ctpsUf = const Value.absent(),
    this.observacao = const Value.absent(),
    this.logradouro = const Value.absent(),
    this.numero = const Value.absent(),
    this.complemento = const Value.absent(),
    this.bairro = const Value.absent(),
    this.cidade = const Value.absent(),
    this.cep = const Value.absent(),
    this.municipioIbge = const Value.absent(),
    this.uf = const Value.absent(),
    this.idPessoa = const Value.absent(),
    this.idCargo = const Value.absent(),
    this.idSetor = const Value.absent(),
  });
  ViewPessoaColaboradorsCompanion.insert({
    this.id = const Value.absent(),
    this.nome = const Value.absent(),
    this.tipo = const Value.absent(),
    this.email = const Value.absent(),
    this.site = const Value.absent(),
    this.cpfCnpj = const Value.absent(),
    this.rgIe = const Value.absent(),
    this.matricula = const Value.absent(),
    this.dataCadastro = const Value.absent(),
    this.dataAdmissao = const Value.absent(),
    this.dataDemissao = const Value.absent(),
    this.ctpsNumero = const Value.absent(),
    this.ctpsSerie = const Value.absent(),
    this.ctpsDataExpedicao = const Value.absent(),
    this.ctpsUf = const Value.absent(),
    this.observacao = const Value.absent(),
    this.logradouro = const Value.absent(),
    this.numero = const Value.absent(),
    this.complemento = const Value.absent(),
    this.bairro = const Value.absent(),
    this.cidade = const Value.absent(),
    this.cep = const Value.absent(),
    this.municipioIbge = const Value.absent(),
    this.uf = const Value.absent(),
    this.idPessoa = const Value.absent(),
    this.idCargo = const Value.absent(),
    this.idSetor = const Value.absent(),
  });
  static Insertable<ViewPessoaColaborador> custom({
    Expression<int>? id,
    Expression<String>? nome,
    Expression<String>? tipo,
    Expression<String>? email,
    Expression<String>? site,
    Expression<String>? cpfCnpj,
    Expression<String>? rgIe,
    Expression<String>? matricula,
    Expression<DateTime>? dataCadastro,
    Expression<DateTime>? dataAdmissao,
    Expression<DateTime>? dataDemissao,
    Expression<String>? ctpsNumero,
    Expression<String>? ctpsSerie,
    Expression<DateTime>? ctpsDataExpedicao,
    Expression<String>? ctpsUf,
    Expression<String>? observacao,
    Expression<String>? logradouro,
    Expression<String>? numero,
    Expression<String>? complemento,
    Expression<String>? bairro,
    Expression<String>? cidade,
    Expression<String>? cep,
    Expression<String>? municipioIbge,
    Expression<String>? uf,
    Expression<int>? idPessoa,
    Expression<int>? idCargo,
    Expression<int>? idSetor,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (nome != null) 'nome': nome,
      if (tipo != null) 'tipo': tipo,
      if (email != null) 'email': email,
      if (site != null) 'site': site,
      if (cpfCnpj != null) 'cpf_cnpj': cpfCnpj,
      if (rgIe != null) 'rg_ie': rgIe,
      if (matricula != null) 'matricula': matricula,
      if (dataCadastro != null) 'data_cadastro': dataCadastro,
      if (dataAdmissao != null) 'data_admissao': dataAdmissao,
      if (dataDemissao != null) 'data_demissao': dataDemissao,
      if (ctpsNumero != null) 'ctps_numero': ctpsNumero,
      if (ctpsSerie != null) 'ctps_serie': ctpsSerie,
      if (ctpsDataExpedicao != null) 'ctps_data_expedicao': ctpsDataExpedicao,
      if (ctpsUf != null) 'ctps_uf': ctpsUf,
      if (observacao != null) 'observacao': observacao,
      if (logradouro != null) 'logradouro': logradouro,
      if (numero != null) 'numero': numero,
      if (complemento != null) 'complemento': complemento,
      if (bairro != null) 'bairro': bairro,
      if (cidade != null) 'cidade': cidade,
      if (cep != null) 'cep': cep,
      if (municipioIbge != null) 'municipio_ibge': municipioIbge,
      if (uf != null) 'uf': uf,
      if (idPessoa != null) 'id_pessoa': idPessoa,
      if (idCargo != null) 'id_cargo': idCargo,
      if (idSetor != null) 'id_setor': idSetor,
    });
  }

  ViewPessoaColaboradorsCompanion copyWith(
      {Value<int?>? id,
      Value<String?>? nome,
      Value<String?>? tipo,
      Value<String?>? email,
      Value<String?>? site,
      Value<String?>? cpfCnpj,
      Value<String?>? rgIe,
      Value<String?>? matricula,
      Value<DateTime?>? dataCadastro,
      Value<DateTime?>? dataAdmissao,
      Value<DateTime?>? dataDemissao,
      Value<String?>? ctpsNumero,
      Value<String?>? ctpsSerie,
      Value<DateTime?>? ctpsDataExpedicao,
      Value<String?>? ctpsUf,
      Value<String?>? observacao,
      Value<String?>? logradouro,
      Value<String?>? numero,
      Value<String?>? complemento,
      Value<String?>? bairro,
      Value<String?>? cidade,
      Value<String?>? cep,
      Value<String?>? municipioIbge,
      Value<String?>? uf,
      Value<int?>? idPessoa,
      Value<int?>? idCargo,
      Value<int?>? idSetor}) {
    return ViewPessoaColaboradorsCompanion(
      id: id ?? this.id,
      nome: nome ?? this.nome,
      tipo: tipo ?? this.tipo,
      email: email ?? this.email,
      site: site ?? this.site,
      cpfCnpj: cpfCnpj ?? this.cpfCnpj,
      rgIe: rgIe ?? this.rgIe,
      matricula: matricula ?? this.matricula,
      dataCadastro: dataCadastro ?? this.dataCadastro,
      dataAdmissao: dataAdmissao ?? this.dataAdmissao,
      dataDemissao: dataDemissao ?? this.dataDemissao,
      ctpsNumero: ctpsNumero ?? this.ctpsNumero,
      ctpsSerie: ctpsSerie ?? this.ctpsSerie,
      ctpsDataExpedicao: ctpsDataExpedicao ?? this.ctpsDataExpedicao,
      ctpsUf: ctpsUf ?? this.ctpsUf,
      observacao: observacao ?? this.observacao,
      logradouro: logradouro ?? this.logradouro,
      numero: numero ?? this.numero,
      complemento: complemento ?? this.complemento,
      bairro: bairro ?? this.bairro,
      cidade: cidade ?? this.cidade,
      cep: cep ?? this.cep,
      municipioIbge: municipioIbge ?? this.municipioIbge,
      uf: uf ?? this.uf,
      idPessoa: idPessoa ?? this.idPessoa,
      idCargo: idCargo ?? this.idCargo,
      idSetor: idSetor ?? this.idSetor,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (nome.present) {
      map['nome'] = Variable<String>(nome.value);
    }
    if (tipo.present) {
      map['tipo'] = Variable<String>(tipo.value);
    }
    if (email.present) {
      map['email'] = Variable<String>(email.value);
    }
    if (site.present) {
      map['site'] = Variable<String>(site.value);
    }
    if (cpfCnpj.present) {
      map['cpf_cnpj'] = Variable<String>(cpfCnpj.value);
    }
    if (rgIe.present) {
      map['rg_ie'] = Variable<String>(rgIe.value);
    }
    if (matricula.present) {
      map['matricula'] = Variable<String>(matricula.value);
    }
    if (dataCadastro.present) {
      map['data_cadastro'] = Variable<DateTime>(dataCadastro.value);
    }
    if (dataAdmissao.present) {
      map['data_admissao'] = Variable<DateTime>(dataAdmissao.value);
    }
    if (dataDemissao.present) {
      map['data_demissao'] = Variable<DateTime>(dataDemissao.value);
    }
    if (ctpsNumero.present) {
      map['ctps_numero'] = Variable<String>(ctpsNumero.value);
    }
    if (ctpsSerie.present) {
      map['ctps_serie'] = Variable<String>(ctpsSerie.value);
    }
    if (ctpsDataExpedicao.present) {
      map['ctps_data_expedicao'] = Variable<DateTime>(ctpsDataExpedicao.value);
    }
    if (ctpsUf.present) {
      map['ctps_uf'] = Variable<String>(ctpsUf.value);
    }
    if (observacao.present) {
      map['observacao'] = Variable<String>(observacao.value);
    }
    if (logradouro.present) {
      map['logradouro'] = Variable<String>(logradouro.value);
    }
    if (numero.present) {
      map['numero'] = Variable<String>(numero.value);
    }
    if (complemento.present) {
      map['complemento'] = Variable<String>(complemento.value);
    }
    if (bairro.present) {
      map['bairro'] = Variable<String>(bairro.value);
    }
    if (cidade.present) {
      map['cidade'] = Variable<String>(cidade.value);
    }
    if (cep.present) {
      map['cep'] = Variable<String>(cep.value);
    }
    if (municipioIbge.present) {
      map['municipio_ibge'] = Variable<String>(municipioIbge.value);
    }
    if (uf.present) {
      map['uf'] = Variable<String>(uf.value);
    }
    if (idPessoa.present) {
      map['id_pessoa'] = Variable<int>(idPessoa.value);
    }
    if (idCargo.present) {
      map['id_cargo'] = Variable<int>(idCargo.value);
    }
    if (idSetor.present) {
      map['id_setor'] = Variable<int>(idSetor.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('ViewPessoaColaboradorsCompanion(')
          ..write('id: $id, ')
          ..write('nome: $nome, ')
          ..write('tipo: $tipo, ')
          ..write('email: $email, ')
          ..write('site: $site, ')
          ..write('cpfCnpj: $cpfCnpj, ')
          ..write('rgIe: $rgIe, ')
          ..write('matricula: $matricula, ')
          ..write('dataCadastro: $dataCadastro, ')
          ..write('dataAdmissao: $dataAdmissao, ')
          ..write('dataDemissao: $dataDemissao, ')
          ..write('ctpsNumero: $ctpsNumero, ')
          ..write('ctpsSerie: $ctpsSerie, ')
          ..write('ctpsDataExpedicao: $ctpsDataExpedicao, ')
          ..write('ctpsUf: $ctpsUf, ')
          ..write('observacao: $observacao, ')
          ..write('logradouro: $logradouro, ')
          ..write('numero: $numero, ')
          ..write('complemento: $complemento, ')
          ..write('bairro: $bairro, ')
          ..write('cidade: $cidade, ')
          ..write('cep: $cep, ')
          ..write('municipioIbge: $municipioIbge, ')
          ..write('uf: $uf, ')
          ..write('idPessoa: $idPessoa, ')
          ..write('idCargo: $idCargo, ')
          ..write('idSetor: $idSetor')
          ..write(')'))
        .toString();
  }
}

abstract class _$AppDatabase extends GeneratedDatabase {
  _$AppDatabase(QueryExecutor e) : super(e);
  $AppDatabaseManager get managers => $AppDatabaseManager(this);
  late final $OsAberturasTable osAberturas = $OsAberturasTable(this);
  late final $NfseDetalhesTable nfseDetalhes = $NfseDetalhesTable(this);
  late final $NfseIntermediariosTable nfseIntermediarios =
      $NfseIntermediariosTable(this);
  late final $OsStatussTable osStatuss = $OsStatussTable(this);
  late final $NfseCabecalhosTable nfseCabecalhos = $NfseCabecalhosTable(this);
  late final $NfseListaServicosTable nfseListaServicos =
      $NfseListaServicosTable(this);
  late final $ViewControleAcessosTable viewControleAcessos =
      $ViewControleAcessosTable(this);
  late final $ViewPessoaUsuariosTable viewPessoaUsuarios =
      $ViewPessoaUsuariosTable(this);
  late final $ViewPessoaClientesTable viewPessoaClientes =
      $ViewPessoaClientesTable(this);
  late final $ViewPessoaColaboradorsTable viewPessoaColaboradors =
      $ViewPessoaColaboradorsTable(this);
  late final OsStatusDao osStatusDao = OsStatusDao(this as AppDatabase);
  late final NfseCabecalhoDao nfseCabecalhoDao =
      NfseCabecalhoDao(this as AppDatabase);
  late final NfseListaServicoDao nfseListaServicoDao =
      NfseListaServicoDao(this as AppDatabase);
  late final ViewControleAcessoDao viewControleAcessoDao =
      ViewControleAcessoDao(this as AppDatabase);
  late final ViewPessoaUsuarioDao viewPessoaUsuarioDao =
      ViewPessoaUsuarioDao(this as AppDatabase);
  late final ViewPessoaClienteDao viewPessoaClienteDao =
      ViewPessoaClienteDao(this as AppDatabase);
  late final ViewPessoaColaboradorDao viewPessoaColaboradorDao =
      ViewPessoaColaboradorDao(this as AppDatabase);
  @override
  Iterable<TableInfo<Table, Object?>> get allTables =>
      allSchemaEntities.whereType<TableInfo<Table, Object?>>();
  @override
  List<DatabaseSchemaEntity> get allSchemaEntities => [
        osAberturas,
        nfseDetalhes,
        nfseIntermediarios,
        osStatuss,
        nfseCabecalhos,
        nfseListaServicos,
        viewControleAcessos,
        viewPessoaUsuarios,
        viewPessoaClientes,
        viewPessoaColaboradors
      ];
}

typedef $$OsAberturasTableCreateCompanionBuilder = OsAberturasCompanion
    Function({
  Value<int?> id,
  Value<int?> idOsStatus,
  Value<int?> idColaborador,
  Value<int?> idCliente,
  Value<String?> numero,
  Value<DateTime?> dataInicio,
  Value<String?> horaInicio,
  Value<DateTime?> dataPrevisao,
  Value<String?> horaPrevisao,
  Value<DateTime?> dataFim,
  Value<String?> horaFim,
  Value<String?> nomeContato,
  Value<String?> foneContato,
  Value<String?> observacaoCliente,
  Value<String?> observacaoAbertura,
});
typedef $$OsAberturasTableUpdateCompanionBuilder = OsAberturasCompanion
    Function({
  Value<int?> id,
  Value<int?> idOsStatus,
  Value<int?> idColaborador,
  Value<int?> idCliente,
  Value<String?> numero,
  Value<DateTime?> dataInicio,
  Value<String?> horaInicio,
  Value<DateTime?> dataPrevisao,
  Value<String?> horaPrevisao,
  Value<DateTime?> dataFim,
  Value<String?> horaFim,
  Value<String?> nomeContato,
  Value<String?> foneContato,
  Value<String?> observacaoCliente,
  Value<String?> observacaoAbertura,
});

class $$OsAberturasTableTableManager extends RootTableManager<
    _$AppDatabase,
    $OsAberturasTable,
    OsAbertura,
    $$OsAberturasTableFilterComposer,
    $$OsAberturasTableOrderingComposer,
    $$OsAberturasTableCreateCompanionBuilder,
    $$OsAberturasTableUpdateCompanionBuilder> {
  $$OsAberturasTableTableManager(_$AppDatabase db, $OsAberturasTable table)
      : super(TableManagerState(
          db: db,
          table: table,
          filteringComposer:
              $$OsAberturasTableFilterComposer(ComposerState(db, table)),
          orderingComposer:
              $$OsAberturasTableOrderingComposer(ComposerState(db, table)),
          updateCompanionCallback: ({
            Value<int?> id = const Value.absent(),
            Value<int?> idOsStatus = const Value.absent(),
            Value<int?> idColaborador = const Value.absent(),
            Value<int?> idCliente = const Value.absent(),
            Value<String?> numero = const Value.absent(),
            Value<DateTime?> dataInicio = const Value.absent(),
            Value<String?> horaInicio = const Value.absent(),
            Value<DateTime?> dataPrevisao = const Value.absent(),
            Value<String?> horaPrevisao = const Value.absent(),
            Value<DateTime?> dataFim = const Value.absent(),
            Value<String?> horaFim = const Value.absent(),
            Value<String?> nomeContato = const Value.absent(),
            Value<String?> foneContato = const Value.absent(),
            Value<String?> observacaoCliente = const Value.absent(),
            Value<String?> observacaoAbertura = const Value.absent(),
          }) =>
              OsAberturasCompanion(
            id: id,
            idOsStatus: idOsStatus,
            idColaborador: idColaborador,
            idCliente: idCliente,
            numero: numero,
            dataInicio: dataInicio,
            horaInicio: horaInicio,
            dataPrevisao: dataPrevisao,
            horaPrevisao: horaPrevisao,
            dataFim: dataFim,
            horaFim: horaFim,
            nomeContato: nomeContato,
            foneContato: foneContato,
            observacaoCliente: observacaoCliente,
            observacaoAbertura: observacaoAbertura,
          ),
          createCompanionCallback: ({
            Value<int?> id = const Value.absent(),
            Value<int?> idOsStatus = const Value.absent(),
            Value<int?> idColaborador = const Value.absent(),
            Value<int?> idCliente = const Value.absent(),
            Value<String?> numero = const Value.absent(),
            Value<DateTime?> dataInicio = const Value.absent(),
            Value<String?> horaInicio = const Value.absent(),
            Value<DateTime?> dataPrevisao = const Value.absent(),
            Value<String?> horaPrevisao = const Value.absent(),
            Value<DateTime?> dataFim = const Value.absent(),
            Value<String?> horaFim = const Value.absent(),
            Value<String?> nomeContato = const Value.absent(),
            Value<String?> foneContato = const Value.absent(),
            Value<String?> observacaoCliente = const Value.absent(),
            Value<String?> observacaoAbertura = const Value.absent(),
          }) =>
              OsAberturasCompanion.insert(
            id: id,
            idOsStatus: idOsStatus,
            idColaborador: idColaborador,
            idCliente: idCliente,
            numero: numero,
            dataInicio: dataInicio,
            horaInicio: horaInicio,
            dataPrevisao: dataPrevisao,
            horaPrevisao: horaPrevisao,
            dataFim: dataFim,
            horaFim: horaFim,
            nomeContato: nomeContato,
            foneContato: foneContato,
            observacaoCliente: observacaoCliente,
            observacaoAbertura: observacaoAbertura,
          ),
        ));
}

class $$OsAberturasTableFilterComposer
    extends FilterComposer<_$AppDatabase, $OsAberturasTable> {
  $$OsAberturasTableFilterComposer(super.$state);
  ColumnFilters<int> get id => $state.composableBuilder(
      column: $state.table.id,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<int> get idOsStatus => $state.composableBuilder(
      column: $state.table.idOsStatus,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<int> get idColaborador => $state.composableBuilder(
      column: $state.table.idColaborador,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<int> get idCliente => $state.composableBuilder(
      column: $state.table.idCliente,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get numero => $state.composableBuilder(
      column: $state.table.numero,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<DateTime> get dataInicio => $state.composableBuilder(
      column: $state.table.dataInicio,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get horaInicio => $state.composableBuilder(
      column: $state.table.horaInicio,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<DateTime> get dataPrevisao => $state.composableBuilder(
      column: $state.table.dataPrevisao,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get horaPrevisao => $state.composableBuilder(
      column: $state.table.horaPrevisao,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<DateTime> get dataFim => $state.composableBuilder(
      column: $state.table.dataFim,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get horaFim => $state.composableBuilder(
      column: $state.table.horaFim,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get nomeContato => $state.composableBuilder(
      column: $state.table.nomeContato,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get foneContato => $state.composableBuilder(
      column: $state.table.foneContato,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get observacaoCliente => $state.composableBuilder(
      column: $state.table.observacaoCliente,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get observacaoAbertura => $state.composableBuilder(
      column: $state.table.observacaoAbertura,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));
}

class $$OsAberturasTableOrderingComposer
    extends OrderingComposer<_$AppDatabase, $OsAberturasTable> {
  $$OsAberturasTableOrderingComposer(super.$state);
  ColumnOrderings<int> get id => $state.composableBuilder(
      column: $state.table.id,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<int> get idOsStatus => $state.composableBuilder(
      column: $state.table.idOsStatus,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<int> get idColaborador => $state.composableBuilder(
      column: $state.table.idColaborador,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<int> get idCliente => $state.composableBuilder(
      column: $state.table.idCliente,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get numero => $state.composableBuilder(
      column: $state.table.numero,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<DateTime> get dataInicio => $state.composableBuilder(
      column: $state.table.dataInicio,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get horaInicio => $state.composableBuilder(
      column: $state.table.horaInicio,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<DateTime> get dataPrevisao => $state.composableBuilder(
      column: $state.table.dataPrevisao,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get horaPrevisao => $state.composableBuilder(
      column: $state.table.horaPrevisao,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<DateTime> get dataFim => $state.composableBuilder(
      column: $state.table.dataFim,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get horaFim => $state.composableBuilder(
      column: $state.table.horaFim,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get nomeContato => $state.composableBuilder(
      column: $state.table.nomeContato,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get foneContato => $state.composableBuilder(
      column: $state.table.foneContato,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get observacaoCliente => $state.composableBuilder(
      column: $state.table.observacaoCliente,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get observacaoAbertura => $state.composableBuilder(
      column: $state.table.observacaoAbertura,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));
}

typedef $$NfseDetalhesTableCreateCompanionBuilder = NfseDetalhesCompanion
    Function({
  Value<int?> id,
  Value<int?> idNfseCabecalho,
  Value<int?> idNfseListaServico,
  Value<String?> codigoCnae,
  Value<String?> codigoTributacaoMunicipio,
  Value<double?> valorServicos,
  Value<double?> valorDeducoes,
  Value<double?> valorPis,
  Value<double?> valorCofins,
  Value<double?> valorInss,
  Value<double?> valorIr,
  Value<double?> valorCsll,
  Value<double?> valorBaseCalculo,
  Value<double?> aliquota,
  Value<double?> valorIss,
  Value<double?> valorLiquido,
  Value<double?> outrasRetencoes,
  Value<double?> valorCredito,
  Value<String?> issRetido,
  Value<double?> valorIssRetido,
  Value<double?> valorDescontoCondicionado,
  Value<double?> valorDescontoIncondicionado,
  Value<int?> municipioPrestacao,
  Value<String?> discriminacao,
});
typedef $$NfseDetalhesTableUpdateCompanionBuilder = NfseDetalhesCompanion
    Function({
  Value<int?> id,
  Value<int?> idNfseCabecalho,
  Value<int?> idNfseListaServico,
  Value<String?> codigoCnae,
  Value<String?> codigoTributacaoMunicipio,
  Value<double?> valorServicos,
  Value<double?> valorDeducoes,
  Value<double?> valorPis,
  Value<double?> valorCofins,
  Value<double?> valorInss,
  Value<double?> valorIr,
  Value<double?> valorCsll,
  Value<double?> valorBaseCalculo,
  Value<double?> aliquota,
  Value<double?> valorIss,
  Value<double?> valorLiquido,
  Value<double?> outrasRetencoes,
  Value<double?> valorCredito,
  Value<String?> issRetido,
  Value<double?> valorIssRetido,
  Value<double?> valorDescontoCondicionado,
  Value<double?> valorDescontoIncondicionado,
  Value<int?> municipioPrestacao,
  Value<String?> discriminacao,
});

class $$NfseDetalhesTableTableManager extends RootTableManager<
    _$AppDatabase,
    $NfseDetalhesTable,
    NfseDetalhe,
    $$NfseDetalhesTableFilterComposer,
    $$NfseDetalhesTableOrderingComposer,
    $$NfseDetalhesTableCreateCompanionBuilder,
    $$NfseDetalhesTableUpdateCompanionBuilder> {
  $$NfseDetalhesTableTableManager(_$AppDatabase db, $NfseDetalhesTable table)
      : super(TableManagerState(
          db: db,
          table: table,
          filteringComposer:
              $$NfseDetalhesTableFilterComposer(ComposerState(db, table)),
          orderingComposer:
              $$NfseDetalhesTableOrderingComposer(ComposerState(db, table)),
          updateCompanionCallback: ({
            Value<int?> id = const Value.absent(),
            Value<int?> idNfseCabecalho = const Value.absent(),
            Value<int?> idNfseListaServico = const Value.absent(),
            Value<String?> codigoCnae = const Value.absent(),
            Value<String?> codigoTributacaoMunicipio = const Value.absent(),
            Value<double?> valorServicos = const Value.absent(),
            Value<double?> valorDeducoes = const Value.absent(),
            Value<double?> valorPis = const Value.absent(),
            Value<double?> valorCofins = const Value.absent(),
            Value<double?> valorInss = const Value.absent(),
            Value<double?> valorIr = const Value.absent(),
            Value<double?> valorCsll = const Value.absent(),
            Value<double?> valorBaseCalculo = const Value.absent(),
            Value<double?> aliquota = const Value.absent(),
            Value<double?> valorIss = const Value.absent(),
            Value<double?> valorLiquido = const Value.absent(),
            Value<double?> outrasRetencoes = const Value.absent(),
            Value<double?> valorCredito = const Value.absent(),
            Value<String?> issRetido = const Value.absent(),
            Value<double?> valorIssRetido = const Value.absent(),
            Value<double?> valorDescontoCondicionado = const Value.absent(),
            Value<double?> valorDescontoIncondicionado = const Value.absent(),
            Value<int?> municipioPrestacao = const Value.absent(),
            Value<String?> discriminacao = const Value.absent(),
          }) =>
              NfseDetalhesCompanion(
            id: id,
            idNfseCabecalho: idNfseCabecalho,
            idNfseListaServico: idNfseListaServico,
            codigoCnae: codigoCnae,
            codigoTributacaoMunicipio: codigoTributacaoMunicipio,
            valorServicos: valorServicos,
            valorDeducoes: valorDeducoes,
            valorPis: valorPis,
            valorCofins: valorCofins,
            valorInss: valorInss,
            valorIr: valorIr,
            valorCsll: valorCsll,
            valorBaseCalculo: valorBaseCalculo,
            aliquota: aliquota,
            valorIss: valorIss,
            valorLiquido: valorLiquido,
            outrasRetencoes: outrasRetencoes,
            valorCredito: valorCredito,
            issRetido: issRetido,
            valorIssRetido: valorIssRetido,
            valorDescontoCondicionado: valorDescontoCondicionado,
            valorDescontoIncondicionado: valorDescontoIncondicionado,
            municipioPrestacao: municipioPrestacao,
            discriminacao: discriminacao,
          ),
          createCompanionCallback: ({
            Value<int?> id = const Value.absent(),
            Value<int?> idNfseCabecalho = const Value.absent(),
            Value<int?> idNfseListaServico = const Value.absent(),
            Value<String?> codigoCnae = const Value.absent(),
            Value<String?> codigoTributacaoMunicipio = const Value.absent(),
            Value<double?> valorServicos = const Value.absent(),
            Value<double?> valorDeducoes = const Value.absent(),
            Value<double?> valorPis = const Value.absent(),
            Value<double?> valorCofins = const Value.absent(),
            Value<double?> valorInss = const Value.absent(),
            Value<double?> valorIr = const Value.absent(),
            Value<double?> valorCsll = const Value.absent(),
            Value<double?> valorBaseCalculo = const Value.absent(),
            Value<double?> aliquota = const Value.absent(),
            Value<double?> valorIss = const Value.absent(),
            Value<double?> valorLiquido = const Value.absent(),
            Value<double?> outrasRetencoes = const Value.absent(),
            Value<double?> valorCredito = const Value.absent(),
            Value<String?> issRetido = const Value.absent(),
            Value<double?> valorIssRetido = const Value.absent(),
            Value<double?> valorDescontoCondicionado = const Value.absent(),
            Value<double?> valorDescontoIncondicionado = const Value.absent(),
            Value<int?> municipioPrestacao = const Value.absent(),
            Value<String?> discriminacao = const Value.absent(),
          }) =>
              NfseDetalhesCompanion.insert(
            id: id,
            idNfseCabecalho: idNfseCabecalho,
            idNfseListaServico: idNfseListaServico,
            codigoCnae: codigoCnae,
            codigoTributacaoMunicipio: codigoTributacaoMunicipio,
            valorServicos: valorServicos,
            valorDeducoes: valorDeducoes,
            valorPis: valorPis,
            valorCofins: valorCofins,
            valorInss: valorInss,
            valorIr: valorIr,
            valorCsll: valorCsll,
            valorBaseCalculo: valorBaseCalculo,
            aliquota: aliquota,
            valorIss: valorIss,
            valorLiquido: valorLiquido,
            outrasRetencoes: outrasRetencoes,
            valorCredito: valorCredito,
            issRetido: issRetido,
            valorIssRetido: valorIssRetido,
            valorDescontoCondicionado: valorDescontoCondicionado,
            valorDescontoIncondicionado: valorDescontoIncondicionado,
            municipioPrestacao: municipioPrestacao,
            discriminacao: discriminacao,
          ),
        ));
}

class $$NfseDetalhesTableFilterComposer
    extends FilterComposer<_$AppDatabase, $NfseDetalhesTable> {
  $$NfseDetalhesTableFilterComposer(super.$state);
  ColumnFilters<int> get id => $state.composableBuilder(
      column: $state.table.id,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<int> get idNfseCabecalho => $state.composableBuilder(
      column: $state.table.idNfseCabecalho,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<int> get idNfseListaServico => $state.composableBuilder(
      column: $state.table.idNfseListaServico,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get codigoCnae => $state.composableBuilder(
      column: $state.table.codigoCnae,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get codigoTributacaoMunicipio =>
      $state.composableBuilder(
          column: $state.table.codigoTributacaoMunicipio,
          builder: (column, joinBuilders) =>
              ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<double> get valorServicos => $state.composableBuilder(
      column: $state.table.valorServicos,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<double> get valorDeducoes => $state.composableBuilder(
      column: $state.table.valorDeducoes,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<double> get valorPis => $state.composableBuilder(
      column: $state.table.valorPis,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<double> get valorCofins => $state.composableBuilder(
      column: $state.table.valorCofins,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<double> get valorInss => $state.composableBuilder(
      column: $state.table.valorInss,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<double> get valorIr => $state.composableBuilder(
      column: $state.table.valorIr,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<double> get valorCsll => $state.composableBuilder(
      column: $state.table.valorCsll,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<double> get valorBaseCalculo => $state.composableBuilder(
      column: $state.table.valorBaseCalculo,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<double> get aliquota => $state.composableBuilder(
      column: $state.table.aliquota,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<double> get valorIss => $state.composableBuilder(
      column: $state.table.valorIss,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<double> get valorLiquido => $state.composableBuilder(
      column: $state.table.valorLiquido,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<double> get outrasRetencoes => $state.composableBuilder(
      column: $state.table.outrasRetencoes,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<double> get valorCredito => $state.composableBuilder(
      column: $state.table.valorCredito,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get issRetido => $state.composableBuilder(
      column: $state.table.issRetido,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<double> get valorIssRetido => $state.composableBuilder(
      column: $state.table.valorIssRetido,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<double> get valorDescontoCondicionado =>
      $state.composableBuilder(
          column: $state.table.valorDescontoCondicionado,
          builder: (column, joinBuilders) =>
              ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<double> get valorDescontoIncondicionado => $state
      .composableBuilder(
          column: $state.table.valorDescontoIncondicionado,
          builder: (column, joinBuilders) =>
              ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<int> get municipioPrestacao => $state.composableBuilder(
      column: $state.table.municipioPrestacao,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get discriminacao => $state.composableBuilder(
      column: $state.table.discriminacao,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));
}

class $$NfseDetalhesTableOrderingComposer
    extends OrderingComposer<_$AppDatabase, $NfseDetalhesTable> {
  $$NfseDetalhesTableOrderingComposer(super.$state);
  ColumnOrderings<int> get id => $state.composableBuilder(
      column: $state.table.id,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<int> get idNfseCabecalho => $state.composableBuilder(
      column: $state.table.idNfseCabecalho,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<int> get idNfseListaServico => $state.composableBuilder(
      column: $state.table.idNfseListaServico,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get codigoCnae => $state.composableBuilder(
      column: $state.table.codigoCnae,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get codigoTributacaoMunicipio => $state
      .composableBuilder(
          column: $state.table.codigoTributacaoMunicipio,
          builder: (column, joinBuilders) =>
              ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<double> get valorServicos => $state.composableBuilder(
      column: $state.table.valorServicos,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<double> get valorDeducoes => $state.composableBuilder(
      column: $state.table.valorDeducoes,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<double> get valorPis => $state.composableBuilder(
      column: $state.table.valorPis,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<double> get valorCofins => $state.composableBuilder(
      column: $state.table.valorCofins,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<double> get valorInss => $state.composableBuilder(
      column: $state.table.valorInss,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<double> get valorIr => $state.composableBuilder(
      column: $state.table.valorIr,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<double> get valorCsll => $state.composableBuilder(
      column: $state.table.valorCsll,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<double> get valorBaseCalculo => $state.composableBuilder(
      column: $state.table.valorBaseCalculo,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<double> get aliquota => $state.composableBuilder(
      column: $state.table.aliquota,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<double> get valorIss => $state.composableBuilder(
      column: $state.table.valorIss,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<double> get valorLiquido => $state.composableBuilder(
      column: $state.table.valorLiquido,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<double> get outrasRetencoes => $state.composableBuilder(
      column: $state.table.outrasRetencoes,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<double> get valorCredito => $state.composableBuilder(
      column: $state.table.valorCredito,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get issRetido => $state.composableBuilder(
      column: $state.table.issRetido,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<double> get valorIssRetido => $state.composableBuilder(
      column: $state.table.valorIssRetido,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<double> get valorDescontoCondicionado => $state
      .composableBuilder(
          column: $state.table.valorDescontoCondicionado,
          builder: (column, joinBuilders) =>
              ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<double> get valorDescontoIncondicionado =>
      $state.composableBuilder(
          column: $state.table.valorDescontoIncondicionado,
          builder: (column, joinBuilders) =>
              ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<int> get municipioPrestacao => $state.composableBuilder(
      column: $state.table.municipioPrestacao,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get discriminacao => $state.composableBuilder(
      column: $state.table.discriminacao,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));
}

typedef $$NfseIntermediariosTableCreateCompanionBuilder
    = NfseIntermediariosCompanion Function({
  Value<int?> id,
  Value<int?> idNfseCabecalho,
  Value<String?> cnpj,
  Value<String?> inscricaoMunicipal,
  Value<String?> razao,
});
typedef $$NfseIntermediariosTableUpdateCompanionBuilder
    = NfseIntermediariosCompanion Function({
  Value<int?> id,
  Value<int?> idNfseCabecalho,
  Value<String?> cnpj,
  Value<String?> inscricaoMunicipal,
  Value<String?> razao,
});

class $$NfseIntermediariosTableTableManager extends RootTableManager<
    _$AppDatabase,
    $NfseIntermediariosTable,
    NfseIntermediario,
    $$NfseIntermediariosTableFilterComposer,
    $$NfseIntermediariosTableOrderingComposer,
    $$NfseIntermediariosTableCreateCompanionBuilder,
    $$NfseIntermediariosTableUpdateCompanionBuilder> {
  $$NfseIntermediariosTableTableManager(
      _$AppDatabase db, $NfseIntermediariosTable table)
      : super(TableManagerState(
          db: db,
          table: table,
          filteringComposer:
              $$NfseIntermediariosTableFilterComposer(ComposerState(db, table)),
          orderingComposer: $$NfseIntermediariosTableOrderingComposer(
              ComposerState(db, table)),
          updateCompanionCallback: ({
            Value<int?> id = const Value.absent(),
            Value<int?> idNfseCabecalho = const Value.absent(),
            Value<String?> cnpj = const Value.absent(),
            Value<String?> inscricaoMunicipal = const Value.absent(),
            Value<String?> razao = const Value.absent(),
          }) =>
              NfseIntermediariosCompanion(
            id: id,
            idNfseCabecalho: idNfseCabecalho,
            cnpj: cnpj,
            inscricaoMunicipal: inscricaoMunicipal,
            razao: razao,
          ),
          createCompanionCallback: ({
            Value<int?> id = const Value.absent(),
            Value<int?> idNfseCabecalho = const Value.absent(),
            Value<String?> cnpj = const Value.absent(),
            Value<String?> inscricaoMunicipal = const Value.absent(),
            Value<String?> razao = const Value.absent(),
          }) =>
              NfseIntermediariosCompanion.insert(
            id: id,
            idNfseCabecalho: idNfseCabecalho,
            cnpj: cnpj,
            inscricaoMunicipal: inscricaoMunicipal,
            razao: razao,
          ),
        ));
}

class $$NfseIntermediariosTableFilterComposer
    extends FilterComposer<_$AppDatabase, $NfseIntermediariosTable> {
  $$NfseIntermediariosTableFilterComposer(super.$state);
  ColumnFilters<int> get id => $state.composableBuilder(
      column: $state.table.id,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<int> get idNfseCabecalho => $state.composableBuilder(
      column: $state.table.idNfseCabecalho,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get cnpj => $state.composableBuilder(
      column: $state.table.cnpj,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get inscricaoMunicipal => $state.composableBuilder(
      column: $state.table.inscricaoMunicipal,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get razao => $state.composableBuilder(
      column: $state.table.razao,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));
}

class $$NfseIntermediariosTableOrderingComposer
    extends OrderingComposer<_$AppDatabase, $NfseIntermediariosTable> {
  $$NfseIntermediariosTableOrderingComposer(super.$state);
  ColumnOrderings<int> get id => $state.composableBuilder(
      column: $state.table.id,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<int> get idNfseCabecalho => $state.composableBuilder(
      column: $state.table.idNfseCabecalho,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get cnpj => $state.composableBuilder(
      column: $state.table.cnpj,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get inscricaoMunicipal => $state.composableBuilder(
      column: $state.table.inscricaoMunicipal,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get razao => $state.composableBuilder(
      column: $state.table.razao,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));
}

typedef $$OsStatussTableCreateCompanionBuilder = OsStatussCompanion Function({
  Value<int?> id,
  Value<String?> codigo,
  Value<String?> nome,
});
typedef $$OsStatussTableUpdateCompanionBuilder = OsStatussCompanion Function({
  Value<int?> id,
  Value<String?> codigo,
  Value<String?> nome,
});

class $$OsStatussTableTableManager extends RootTableManager<
    _$AppDatabase,
    $OsStatussTable,
    OsStatus,
    $$OsStatussTableFilterComposer,
    $$OsStatussTableOrderingComposer,
    $$OsStatussTableCreateCompanionBuilder,
    $$OsStatussTableUpdateCompanionBuilder> {
  $$OsStatussTableTableManager(_$AppDatabase db, $OsStatussTable table)
      : super(TableManagerState(
          db: db,
          table: table,
          filteringComposer:
              $$OsStatussTableFilterComposer(ComposerState(db, table)),
          orderingComposer:
              $$OsStatussTableOrderingComposer(ComposerState(db, table)),
          updateCompanionCallback: ({
            Value<int?> id = const Value.absent(),
            Value<String?> codigo = const Value.absent(),
            Value<String?> nome = const Value.absent(),
          }) =>
              OsStatussCompanion(
            id: id,
            codigo: codigo,
            nome: nome,
          ),
          createCompanionCallback: ({
            Value<int?> id = const Value.absent(),
            Value<String?> codigo = const Value.absent(),
            Value<String?> nome = const Value.absent(),
          }) =>
              OsStatussCompanion.insert(
            id: id,
            codigo: codigo,
            nome: nome,
          ),
        ));
}

class $$OsStatussTableFilterComposer
    extends FilterComposer<_$AppDatabase, $OsStatussTable> {
  $$OsStatussTableFilterComposer(super.$state);
  ColumnFilters<int> get id => $state.composableBuilder(
      column: $state.table.id,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get codigo => $state.composableBuilder(
      column: $state.table.codigo,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get nome => $state.composableBuilder(
      column: $state.table.nome,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));
}

class $$OsStatussTableOrderingComposer
    extends OrderingComposer<_$AppDatabase, $OsStatussTable> {
  $$OsStatussTableOrderingComposer(super.$state);
  ColumnOrderings<int> get id => $state.composableBuilder(
      column: $state.table.id,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get codigo => $state.composableBuilder(
      column: $state.table.codigo,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get nome => $state.composableBuilder(
      column: $state.table.nome,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));
}

typedef $$NfseCabecalhosTableCreateCompanionBuilder = NfseCabecalhosCompanion
    Function({
  Value<int?> id,
  Value<int?> idCliente,
  Value<int?> idOsAbertura,
  Value<String?> numero,
  Value<String?> codigoVerificacao,
  Value<DateTime?> dataHoraEmissao,
  Value<String?> competencia,
  Value<String?> numeroSubstituida,
  Value<String?> naturezaOperacao,
  Value<String?> regimeEspecialTributacao,
  Value<String?> optanteSimplesNacional,
  Value<String?> incentivadorCultural,
  Value<String?> numeroRps,
  Value<String?> serieRps,
  Value<String?> tipoRps,
  Value<DateTime?> dataEmissaoRps,
  Value<String?> outrasInformacoes,
});
typedef $$NfseCabecalhosTableUpdateCompanionBuilder = NfseCabecalhosCompanion
    Function({
  Value<int?> id,
  Value<int?> idCliente,
  Value<int?> idOsAbertura,
  Value<String?> numero,
  Value<String?> codigoVerificacao,
  Value<DateTime?> dataHoraEmissao,
  Value<String?> competencia,
  Value<String?> numeroSubstituida,
  Value<String?> naturezaOperacao,
  Value<String?> regimeEspecialTributacao,
  Value<String?> optanteSimplesNacional,
  Value<String?> incentivadorCultural,
  Value<String?> numeroRps,
  Value<String?> serieRps,
  Value<String?> tipoRps,
  Value<DateTime?> dataEmissaoRps,
  Value<String?> outrasInformacoes,
});

class $$NfseCabecalhosTableTableManager extends RootTableManager<
    _$AppDatabase,
    $NfseCabecalhosTable,
    NfseCabecalho,
    $$NfseCabecalhosTableFilterComposer,
    $$NfseCabecalhosTableOrderingComposer,
    $$NfseCabecalhosTableCreateCompanionBuilder,
    $$NfseCabecalhosTableUpdateCompanionBuilder> {
  $$NfseCabecalhosTableTableManager(
      _$AppDatabase db, $NfseCabecalhosTable table)
      : super(TableManagerState(
          db: db,
          table: table,
          filteringComposer:
              $$NfseCabecalhosTableFilterComposer(ComposerState(db, table)),
          orderingComposer:
              $$NfseCabecalhosTableOrderingComposer(ComposerState(db, table)),
          updateCompanionCallback: ({
            Value<int?> id = const Value.absent(),
            Value<int?> idCliente = const Value.absent(),
            Value<int?> idOsAbertura = const Value.absent(),
            Value<String?> numero = const Value.absent(),
            Value<String?> codigoVerificacao = const Value.absent(),
            Value<DateTime?> dataHoraEmissao = const Value.absent(),
            Value<String?> competencia = const Value.absent(),
            Value<String?> numeroSubstituida = const Value.absent(),
            Value<String?> naturezaOperacao = const Value.absent(),
            Value<String?> regimeEspecialTributacao = const Value.absent(),
            Value<String?> optanteSimplesNacional = const Value.absent(),
            Value<String?> incentivadorCultural = const Value.absent(),
            Value<String?> numeroRps = const Value.absent(),
            Value<String?> serieRps = const Value.absent(),
            Value<String?> tipoRps = const Value.absent(),
            Value<DateTime?> dataEmissaoRps = const Value.absent(),
            Value<String?> outrasInformacoes = const Value.absent(),
          }) =>
              NfseCabecalhosCompanion(
            id: id,
            idCliente: idCliente,
            idOsAbertura: idOsAbertura,
            numero: numero,
            codigoVerificacao: codigoVerificacao,
            dataHoraEmissao: dataHoraEmissao,
            competencia: competencia,
            numeroSubstituida: numeroSubstituida,
            naturezaOperacao: naturezaOperacao,
            regimeEspecialTributacao: regimeEspecialTributacao,
            optanteSimplesNacional: optanteSimplesNacional,
            incentivadorCultural: incentivadorCultural,
            numeroRps: numeroRps,
            serieRps: serieRps,
            tipoRps: tipoRps,
            dataEmissaoRps: dataEmissaoRps,
            outrasInformacoes: outrasInformacoes,
          ),
          createCompanionCallback: ({
            Value<int?> id = const Value.absent(),
            Value<int?> idCliente = const Value.absent(),
            Value<int?> idOsAbertura = const Value.absent(),
            Value<String?> numero = const Value.absent(),
            Value<String?> codigoVerificacao = const Value.absent(),
            Value<DateTime?> dataHoraEmissao = const Value.absent(),
            Value<String?> competencia = const Value.absent(),
            Value<String?> numeroSubstituida = const Value.absent(),
            Value<String?> naturezaOperacao = const Value.absent(),
            Value<String?> regimeEspecialTributacao = const Value.absent(),
            Value<String?> optanteSimplesNacional = const Value.absent(),
            Value<String?> incentivadorCultural = const Value.absent(),
            Value<String?> numeroRps = const Value.absent(),
            Value<String?> serieRps = const Value.absent(),
            Value<String?> tipoRps = const Value.absent(),
            Value<DateTime?> dataEmissaoRps = const Value.absent(),
            Value<String?> outrasInformacoes = const Value.absent(),
          }) =>
              NfseCabecalhosCompanion.insert(
            id: id,
            idCliente: idCliente,
            idOsAbertura: idOsAbertura,
            numero: numero,
            codigoVerificacao: codigoVerificacao,
            dataHoraEmissao: dataHoraEmissao,
            competencia: competencia,
            numeroSubstituida: numeroSubstituida,
            naturezaOperacao: naturezaOperacao,
            regimeEspecialTributacao: regimeEspecialTributacao,
            optanteSimplesNacional: optanteSimplesNacional,
            incentivadorCultural: incentivadorCultural,
            numeroRps: numeroRps,
            serieRps: serieRps,
            tipoRps: tipoRps,
            dataEmissaoRps: dataEmissaoRps,
            outrasInformacoes: outrasInformacoes,
          ),
        ));
}

class $$NfseCabecalhosTableFilterComposer
    extends FilterComposer<_$AppDatabase, $NfseCabecalhosTable> {
  $$NfseCabecalhosTableFilterComposer(super.$state);
  ColumnFilters<int> get id => $state.composableBuilder(
      column: $state.table.id,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<int> get idCliente => $state.composableBuilder(
      column: $state.table.idCliente,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<int> get idOsAbertura => $state.composableBuilder(
      column: $state.table.idOsAbertura,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get numero => $state.composableBuilder(
      column: $state.table.numero,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get codigoVerificacao => $state.composableBuilder(
      column: $state.table.codigoVerificacao,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<DateTime> get dataHoraEmissao => $state.composableBuilder(
      column: $state.table.dataHoraEmissao,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get competencia => $state.composableBuilder(
      column: $state.table.competencia,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get numeroSubstituida => $state.composableBuilder(
      column: $state.table.numeroSubstituida,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get naturezaOperacao => $state.composableBuilder(
      column: $state.table.naturezaOperacao,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get regimeEspecialTributacao =>
      $state.composableBuilder(
          column: $state.table.regimeEspecialTributacao,
          builder: (column, joinBuilders) =>
              ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get optanteSimplesNacional => $state.composableBuilder(
      column: $state.table.optanteSimplesNacional,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get incentivadorCultural => $state.composableBuilder(
      column: $state.table.incentivadorCultural,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get numeroRps => $state.composableBuilder(
      column: $state.table.numeroRps,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get serieRps => $state.composableBuilder(
      column: $state.table.serieRps,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get tipoRps => $state.composableBuilder(
      column: $state.table.tipoRps,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<DateTime> get dataEmissaoRps => $state.composableBuilder(
      column: $state.table.dataEmissaoRps,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get outrasInformacoes => $state.composableBuilder(
      column: $state.table.outrasInformacoes,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));
}

class $$NfseCabecalhosTableOrderingComposer
    extends OrderingComposer<_$AppDatabase, $NfseCabecalhosTable> {
  $$NfseCabecalhosTableOrderingComposer(super.$state);
  ColumnOrderings<int> get id => $state.composableBuilder(
      column: $state.table.id,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<int> get idCliente => $state.composableBuilder(
      column: $state.table.idCliente,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<int> get idOsAbertura => $state.composableBuilder(
      column: $state.table.idOsAbertura,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get numero => $state.composableBuilder(
      column: $state.table.numero,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get codigoVerificacao => $state.composableBuilder(
      column: $state.table.codigoVerificacao,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<DateTime> get dataHoraEmissao => $state.composableBuilder(
      column: $state.table.dataHoraEmissao,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get competencia => $state.composableBuilder(
      column: $state.table.competencia,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get numeroSubstituida => $state.composableBuilder(
      column: $state.table.numeroSubstituida,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get naturezaOperacao => $state.composableBuilder(
      column: $state.table.naturezaOperacao,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get regimeEspecialTributacao =>
      $state.composableBuilder(
          column: $state.table.regimeEspecialTributacao,
          builder: (column, joinBuilders) =>
              ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get optanteSimplesNacional =>
      $state.composableBuilder(
          column: $state.table.optanteSimplesNacional,
          builder: (column, joinBuilders) =>
              ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get incentivadorCultural => $state.composableBuilder(
      column: $state.table.incentivadorCultural,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get numeroRps => $state.composableBuilder(
      column: $state.table.numeroRps,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get serieRps => $state.composableBuilder(
      column: $state.table.serieRps,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get tipoRps => $state.composableBuilder(
      column: $state.table.tipoRps,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<DateTime> get dataEmissaoRps => $state.composableBuilder(
      column: $state.table.dataEmissaoRps,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get outrasInformacoes => $state.composableBuilder(
      column: $state.table.outrasInformacoes,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));
}

typedef $$NfseListaServicosTableCreateCompanionBuilder
    = NfseListaServicosCompanion Function({
  Value<int?> id,
  Value<String?> codigo,
  Value<String?> descricao,
});
typedef $$NfseListaServicosTableUpdateCompanionBuilder
    = NfseListaServicosCompanion Function({
  Value<int?> id,
  Value<String?> codigo,
  Value<String?> descricao,
});

class $$NfseListaServicosTableTableManager extends RootTableManager<
    _$AppDatabase,
    $NfseListaServicosTable,
    NfseListaServico,
    $$NfseListaServicosTableFilterComposer,
    $$NfseListaServicosTableOrderingComposer,
    $$NfseListaServicosTableCreateCompanionBuilder,
    $$NfseListaServicosTableUpdateCompanionBuilder> {
  $$NfseListaServicosTableTableManager(
      _$AppDatabase db, $NfseListaServicosTable table)
      : super(TableManagerState(
          db: db,
          table: table,
          filteringComposer:
              $$NfseListaServicosTableFilterComposer(ComposerState(db, table)),
          orderingComposer: $$NfseListaServicosTableOrderingComposer(
              ComposerState(db, table)),
          updateCompanionCallback: ({
            Value<int?> id = const Value.absent(),
            Value<String?> codigo = const Value.absent(),
            Value<String?> descricao = const Value.absent(),
          }) =>
              NfseListaServicosCompanion(
            id: id,
            codigo: codigo,
            descricao: descricao,
          ),
          createCompanionCallback: ({
            Value<int?> id = const Value.absent(),
            Value<String?> codigo = const Value.absent(),
            Value<String?> descricao = const Value.absent(),
          }) =>
              NfseListaServicosCompanion.insert(
            id: id,
            codigo: codigo,
            descricao: descricao,
          ),
        ));
}

class $$NfseListaServicosTableFilterComposer
    extends FilterComposer<_$AppDatabase, $NfseListaServicosTable> {
  $$NfseListaServicosTableFilterComposer(super.$state);
  ColumnFilters<int> get id => $state.composableBuilder(
      column: $state.table.id,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get codigo => $state.composableBuilder(
      column: $state.table.codigo,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get descricao => $state.composableBuilder(
      column: $state.table.descricao,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));
}

class $$NfseListaServicosTableOrderingComposer
    extends OrderingComposer<_$AppDatabase, $NfseListaServicosTable> {
  $$NfseListaServicosTableOrderingComposer(super.$state);
  ColumnOrderings<int> get id => $state.composableBuilder(
      column: $state.table.id,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get codigo => $state.composableBuilder(
      column: $state.table.codigo,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get descricao => $state.composableBuilder(
      column: $state.table.descricao,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));
}

typedef $$ViewControleAcessosTableCreateCompanionBuilder
    = ViewControleAcessosCompanion Function({
  Value<int?> id,
  Value<int?> idPessoa,
  Value<String?> pessoaNome,
  Value<int?> idColaborador,
  Value<int?> idUsuario,
  Value<String?> administrador,
  Value<int?> idPapel,
  Value<String?> papelNome,
  Value<String?> papelDescricao,
  Value<int?> idFuncao,
  Value<String?> funcaoNome,
  Value<String?> funcaoDescricao,
  Value<int?> idPapelFuncao,
  Value<String?> habilitado,
  Value<String?> podeInserir,
  Value<String?> podeAlterar,
  Value<String?> podeExcluir,
});
typedef $$ViewControleAcessosTableUpdateCompanionBuilder
    = ViewControleAcessosCompanion Function({
  Value<int?> id,
  Value<int?> idPessoa,
  Value<String?> pessoaNome,
  Value<int?> idColaborador,
  Value<int?> idUsuario,
  Value<String?> administrador,
  Value<int?> idPapel,
  Value<String?> papelNome,
  Value<String?> papelDescricao,
  Value<int?> idFuncao,
  Value<String?> funcaoNome,
  Value<String?> funcaoDescricao,
  Value<int?> idPapelFuncao,
  Value<String?> habilitado,
  Value<String?> podeInserir,
  Value<String?> podeAlterar,
  Value<String?> podeExcluir,
});

class $$ViewControleAcessosTableTableManager extends RootTableManager<
    _$AppDatabase,
    $ViewControleAcessosTable,
    ViewControleAcesso,
    $$ViewControleAcessosTableFilterComposer,
    $$ViewControleAcessosTableOrderingComposer,
    $$ViewControleAcessosTableCreateCompanionBuilder,
    $$ViewControleAcessosTableUpdateCompanionBuilder> {
  $$ViewControleAcessosTableTableManager(
      _$AppDatabase db, $ViewControleAcessosTable table)
      : super(TableManagerState(
          db: db,
          table: table,
          filteringComposer: $$ViewControleAcessosTableFilterComposer(
              ComposerState(db, table)),
          orderingComposer: $$ViewControleAcessosTableOrderingComposer(
              ComposerState(db, table)),
          updateCompanionCallback: ({
            Value<int?> id = const Value.absent(),
            Value<int?> idPessoa = const Value.absent(),
            Value<String?> pessoaNome = const Value.absent(),
            Value<int?> idColaborador = const Value.absent(),
            Value<int?> idUsuario = const Value.absent(),
            Value<String?> administrador = const Value.absent(),
            Value<int?> idPapel = const Value.absent(),
            Value<String?> papelNome = const Value.absent(),
            Value<String?> papelDescricao = const Value.absent(),
            Value<int?> idFuncao = const Value.absent(),
            Value<String?> funcaoNome = const Value.absent(),
            Value<String?> funcaoDescricao = const Value.absent(),
            Value<int?> idPapelFuncao = const Value.absent(),
            Value<String?> habilitado = const Value.absent(),
            Value<String?> podeInserir = const Value.absent(),
            Value<String?> podeAlterar = const Value.absent(),
            Value<String?> podeExcluir = const Value.absent(),
          }) =>
              ViewControleAcessosCompanion(
            id: id,
            idPessoa: idPessoa,
            pessoaNome: pessoaNome,
            idColaborador: idColaborador,
            idUsuario: idUsuario,
            administrador: administrador,
            idPapel: idPapel,
            papelNome: papelNome,
            papelDescricao: papelDescricao,
            idFuncao: idFuncao,
            funcaoNome: funcaoNome,
            funcaoDescricao: funcaoDescricao,
            idPapelFuncao: idPapelFuncao,
            habilitado: habilitado,
            podeInserir: podeInserir,
            podeAlterar: podeAlterar,
            podeExcluir: podeExcluir,
          ),
          createCompanionCallback: ({
            Value<int?> id = const Value.absent(),
            Value<int?> idPessoa = const Value.absent(),
            Value<String?> pessoaNome = const Value.absent(),
            Value<int?> idColaborador = const Value.absent(),
            Value<int?> idUsuario = const Value.absent(),
            Value<String?> administrador = const Value.absent(),
            Value<int?> idPapel = const Value.absent(),
            Value<String?> papelNome = const Value.absent(),
            Value<String?> papelDescricao = const Value.absent(),
            Value<int?> idFuncao = const Value.absent(),
            Value<String?> funcaoNome = const Value.absent(),
            Value<String?> funcaoDescricao = const Value.absent(),
            Value<int?> idPapelFuncao = const Value.absent(),
            Value<String?> habilitado = const Value.absent(),
            Value<String?> podeInserir = const Value.absent(),
            Value<String?> podeAlterar = const Value.absent(),
            Value<String?> podeExcluir = const Value.absent(),
          }) =>
              ViewControleAcessosCompanion.insert(
            id: id,
            idPessoa: idPessoa,
            pessoaNome: pessoaNome,
            idColaborador: idColaborador,
            idUsuario: idUsuario,
            administrador: administrador,
            idPapel: idPapel,
            papelNome: papelNome,
            papelDescricao: papelDescricao,
            idFuncao: idFuncao,
            funcaoNome: funcaoNome,
            funcaoDescricao: funcaoDescricao,
            idPapelFuncao: idPapelFuncao,
            habilitado: habilitado,
            podeInserir: podeInserir,
            podeAlterar: podeAlterar,
            podeExcluir: podeExcluir,
          ),
        ));
}

class $$ViewControleAcessosTableFilterComposer
    extends FilterComposer<_$AppDatabase, $ViewControleAcessosTable> {
  $$ViewControleAcessosTableFilterComposer(super.$state);
  ColumnFilters<int> get id => $state.composableBuilder(
      column: $state.table.id,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<int> get idPessoa => $state.composableBuilder(
      column: $state.table.idPessoa,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get pessoaNome => $state.composableBuilder(
      column: $state.table.pessoaNome,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<int> get idColaborador => $state.composableBuilder(
      column: $state.table.idColaborador,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<int> get idUsuario => $state.composableBuilder(
      column: $state.table.idUsuario,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get administrador => $state.composableBuilder(
      column: $state.table.administrador,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<int> get idPapel => $state.composableBuilder(
      column: $state.table.idPapel,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get papelNome => $state.composableBuilder(
      column: $state.table.papelNome,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get papelDescricao => $state.composableBuilder(
      column: $state.table.papelDescricao,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<int> get idFuncao => $state.composableBuilder(
      column: $state.table.idFuncao,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get funcaoNome => $state.composableBuilder(
      column: $state.table.funcaoNome,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get funcaoDescricao => $state.composableBuilder(
      column: $state.table.funcaoDescricao,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<int> get idPapelFuncao => $state.composableBuilder(
      column: $state.table.idPapelFuncao,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get habilitado => $state.composableBuilder(
      column: $state.table.habilitado,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get podeInserir => $state.composableBuilder(
      column: $state.table.podeInserir,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get podeAlterar => $state.composableBuilder(
      column: $state.table.podeAlterar,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get podeExcluir => $state.composableBuilder(
      column: $state.table.podeExcluir,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));
}

class $$ViewControleAcessosTableOrderingComposer
    extends OrderingComposer<_$AppDatabase, $ViewControleAcessosTable> {
  $$ViewControleAcessosTableOrderingComposer(super.$state);
  ColumnOrderings<int> get id => $state.composableBuilder(
      column: $state.table.id,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<int> get idPessoa => $state.composableBuilder(
      column: $state.table.idPessoa,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get pessoaNome => $state.composableBuilder(
      column: $state.table.pessoaNome,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<int> get idColaborador => $state.composableBuilder(
      column: $state.table.idColaborador,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<int> get idUsuario => $state.composableBuilder(
      column: $state.table.idUsuario,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get administrador => $state.composableBuilder(
      column: $state.table.administrador,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<int> get idPapel => $state.composableBuilder(
      column: $state.table.idPapel,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get papelNome => $state.composableBuilder(
      column: $state.table.papelNome,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get papelDescricao => $state.composableBuilder(
      column: $state.table.papelDescricao,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<int> get idFuncao => $state.composableBuilder(
      column: $state.table.idFuncao,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get funcaoNome => $state.composableBuilder(
      column: $state.table.funcaoNome,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get funcaoDescricao => $state.composableBuilder(
      column: $state.table.funcaoDescricao,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<int> get idPapelFuncao => $state.composableBuilder(
      column: $state.table.idPapelFuncao,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get habilitado => $state.composableBuilder(
      column: $state.table.habilitado,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get podeInserir => $state.composableBuilder(
      column: $state.table.podeInserir,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get podeAlterar => $state.composableBuilder(
      column: $state.table.podeAlterar,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get podeExcluir => $state.composableBuilder(
      column: $state.table.podeExcluir,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));
}

typedef $$ViewPessoaUsuariosTableCreateCompanionBuilder
    = ViewPessoaUsuariosCompanion Function({
  Value<int?> id,
  Value<int?> idPessoa,
  Value<String?> pessoaNome,
  Value<String?> tipo,
  Value<String?> email,
  Value<int?> idColaborador,
  Value<int?> idUsuario,
  Value<String?> login,
  Value<String?> senha,
  Value<DateTime?> dataCadastro,
  Value<String?> administrador,
});
typedef $$ViewPessoaUsuariosTableUpdateCompanionBuilder
    = ViewPessoaUsuariosCompanion Function({
  Value<int?> id,
  Value<int?> idPessoa,
  Value<String?> pessoaNome,
  Value<String?> tipo,
  Value<String?> email,
  Value<int?> idColaborador,
  Value<int?> idUsuario,
  Value<String?> login,
  Value<String?> senha,
  Value<DateTime?> dataCadastro,
  Value<String?> administrador,
});

class $$ViewPessoaUsuariosTableTableManager extends RootTableManager<
    _$AppDatabase,
    $ViewPessoaUsuariosTable,
    ViewPessoaUsuario,
    $$ViewPessoaUsuariosTableFilterComposer,
    $$ViewPessoaUsuariosTableOrderingComposer,
    $$ViewPessoaUsuariosTableCreateCompanionBuilder,
    $$ViewPessoaUsuariosTableUpdateCompanionBuilder> {
  $$ViewPessoaUsuariosTableTableManager(
      _$AppDatabase db, $ViewPessoaUsuariosTable table)
      : super(TableManagerState(
          db: db,
          table: table,
          filteringComposer:
              $$ViewPessoaUsuariosTableFilterComposer(ComposerState(db, table)),
          orderingComposer: $$ViewPessoaUsuariosTableOrderingComposer(
              ComposerState(db, table)),
          updateCompanionCallback: ({
            Value<int?> id = const Value.absent(),
            Value<int?> idPessoa = const Value.absent(),
            Value<String?> pessoaNome = const Value.absent(),
            Value<String?> tipo = const Value.absent(),
            Value<String?> email = const Value.absent(),
            Value<int?> idColaborador = const Value.absent(),
            Value<int?> idUsuario = const Value.absent(),
            Value<String?> login = const Value.absent(),
            Value<String?> senha = const Value.absent(),
            Value<DateTime?> dataCadastro = const Value.absent(),
            Value<String?> administrador = const Value.absent(),
          }) =>
              ViewPessoaUsuariosCompanion(
            id: id,
            idPessoa: idPessoa,
            pessoaNome: pessoaNome,
            tipo: tipo,
            email: email,
            idColaborador: idColaborador,
            idUsuario: idUsuario,
            login: login,
            senha: senha,
            dataCadastro: dataCadastro,
            administrador: administrador,
          ),
          createCompanionCallback: ({
            Value<int?> id = const Value.absent(),
            Value<int?> idPessoa = const Value.absent(),
            Value<String?> pessoaNome = const Value.absent(),
            Value<String?> tipo = const Value.absent(),
            Value<String?> email = const Value.absent(),
            Value<int?> idColaborador = const Value.absent(),
            Value<int?> idUsuario = const Value.absent(),
            Value<String?> login = const Value.absent(),
            Value<String?> senha = const Value.absent(),
            Value<DateTime?> dataCadastro = const Value.absent(),
            Value<String?> administrador = const Value.absent(),
          }) =>
              ViewPessoaUsuariosCompanion.insert(
            id: id,
            idPessoa: idPessoa,
            pessoaNome: pessoaNome,
            tipo: tipo,
            email: email,
            idColaborador: idColaborador,
            idUsuario: idUsuario,
            login: login,
            senha: senha,
            dataCadastro: dataCadastro,
            administrador: administrador,
          ),
        ));
}

class $$ViewPessoaUsuariosTableFilterComposer
    extends FilterComposer<_$AppDatabase, $ViewPessoaUsuariosTable> {
  $$ViewPessoaUsuariosTableFilterComposer(super.$state);
  ColumnFilters<int> get id => $state.composableBuilder(
      column: $state.table.id,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<int> get idPessoa => $state.composableBuilder(
      column: $state.table.idPessoa,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get pessoaNome => $state.composableBuilder(
      column: $state.table.pessoaNome,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get tipo => $state.composableBuilder(
      column: $state.table.tipo,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get email => $state.composableBuilder(
      column: $state.table.email,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<int> get idColaborador => $state.composableBuilder(
      column: $state.table.idColaborador,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<int> get idUsuario => $state.composableBuilder(
      column: $state.table.idUsuario,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get login => $state.composableBuilder(
      column: $state.table.login,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get senha => $state.composableBuilder(
      column: $state.table.senha,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<DateTime> get dataCadastro => $state.composableBuilder(
      column: $state.table.dataCadastro,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get administrador => $state.composableBuilder(
      column: $state.table.administrador,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));
}

class $$ViewPessoaUsuariosTableOrderingComposer
    extends OrderingComposer<_$AppDatabase, $ViewPessoaUsuariosTable> {
  $$ViewPessoaUsuariosTableOrderingComposer(super.$state);
  ColumnOrderings<int> get id => $state.composableBuilder(
      column: $state.table.id,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<int> get idPessoa => $state.composableBuilder(
      column: $state.table.idPessoa,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get pessoaNome => $state.composableBuilder(
      column: $state.table.pessoaNome,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get tipo => $state.composableBuilder(
      column: $state.table.tipo,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get email => $state.composableBuilder(
      column: $state.table.email,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<int> get idColaborador => $state.composableBuilder(
      column: $state.table.idColaborador,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<int> get idUsuario => $state.composableBuilder(
      column: $state.table.idUsuario,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get login => $state.composableBuilder(
      column: $state.table.login,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get senha => $state.composableBuilder(
      column: $state.table.senha,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<DateTime> get dataCadastro => $state.composableBuilder(
      column: $state.table.dataCadastro,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get administrador => $state.composableBuilder(
      column: $state.table.administrador,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));
}

typedef $$ViewPessoaClientesTableCreateCompanionBuilder
    = ViewPessoaClientesCompanion Function({
  Value<int?> id,
  Value<String?> nome,
  Value<String?> tipo,
  Value<String?> email,
  Value<String?> site,
  Value<String?> cpfCnpj,
  Value<String?> rgIe,
  Value<DateTime?> desde,
  Value<double?> taxaDesconto,
  Value<double?> limiteCredito,
  Value<DateTime?> dataCadastro,
  Value<String?> observacao,
  Value<int?> idPessoa,
});
typedef $$ViewPessoaClientesTableUpdateCompanionBuilder
    = ViewPessoaClientesCompanion Function({
  Value<int?> id,
  Value<String?> nome,
  Value<String?> tipo,
  Value<String?> email,
  Value<String?> site,
  Value<String?> cpfCnpj,
  Value<String?> rgIe,
  Value<DateTime?> desde,
  Value<double?> taxaDesconto,
  Value<double?> limiteCredito,
  Value<DateTime?> dataCadastro,
  Value<String?> observacao,
  Value<int?> idPessoa,
});

class $$ViewPessoaClientesTableTableManager extends RootTableManager<
    _$AppDatabase,
    $ViewPessoaClientesTable,
    ViewPessoaCliente,
    $$ViewPessoaClientesTableFilterComposer,
    $$ViewPessoaClientesTableOrderingComposer,
    $$ViewPessoaClientesTableCreateCompanionBuilder,
    $$ViewPessoaClientesTableUpdateCompanionBuilder> {
  $$ViewPessoaClientesTableTableManager(
      _$AppDatabase db, $ViewPessoaClientesTable table)
      : super(TableManagerState(
          db: db,
          table: table,
          filteringComposer:
              $$ViewPessoaClientesTableFilterComposer(ComposerState(db, table)),
          orderingComposer: $$ViewPessoaClientesTableOrderingComposer(
              ComposerState(db, table)),
          updateCompanionCallback: ({
            Value<int?> id = const Value.absent(),
            Value<String?> nome = const Value.absent(),
            Value<String?> tipo = const Value.absent(),
            Value<String?> email = const Value.absent(),
            Value<String?> site = const Value.absent(),
            Value<String?> cpfCnpj = const Value.absent(),
            Value<String?> rgIe = const Value.absent(),
            Value<DateTime?> desde = const Value.absent(),
            Value<double?> taxaDesconto = const Value.absent(),
            Value<double?> limiteCredito = const Value.absent(),
            Value<DateTime?> dataCadastro = const Value.absent(),
            Value<String?> observacao = const Value.absent(),
            Value<int?> idPessoa = const Value.absent(),
          }) =>
              ViewPessoaClientesCompanion(
            id: id,
            nome: nome,
            tipo: tipo,
            email: email,
            site: site,
            cpfCnpj: cpfCnpj,
            rgIe: rgIe,
            desde: desde,
            taxaDesconto: taxaDesconto,
            limiteCredito: limiteCredito,
            dataCadastro: dataCadastro,
            observacao: observacao,
            idPessoa: idPessoa,
          ),
          createCompanionCallback: ({
            Value<int?> id = const Value.absent(),
            Value<String?> nome = const Value.absent(),
            Value<String?> tipo = const Value.absent(),
            Value<String?> email = const Value.absent(),
            Value<String?> site = const Value.absent(),
            Value<String?> cpfCnpj = const Value.absent(),
            Value<String?> rgIe = const Value.absent(),
            Value<DateTime?> desde = const Value.absent(),
            Value<double?> taxaDesconto = const Value.absent(),
            Value<double?> limiteCredito = const Value.absent(),
            Value<DateTime?> dataCadastro = const Value.absent(),
            Value<String?> observacao = const Value.absent(),
            Value<int?> idPessoa = const Value.absent(),
          }) =>
              ViewPessoaClientesCompanion.insert(
            id: id,
            nome: nome,
            tipo: tipo,
            email: email,
            site: site,
            cpfCnpj: cpfCnpj,
            rgIe: rgIe,
            desde: desde,
            taxaDesconto: taxaDesconto,
            limiteCredito: limiteCredito,
            dataCadastro: dataCadastro,
            observacao: observacao,
            idPessoa: idPessoa,
          ),
        ));
}

class $$ViewPessoaClientesTableFilterComposer
    extends FilterComposer<_$AppDatabase, $ViewPessoaClientesTable> {
  $$ViewPessoaClientesTableFilterComposer(super.$state);
  ColumnFilters<int> get id => $state.composableBuilder(
      column: $state.table.id,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get nome => $state.composableBuilder(
      column: $state.table.nome,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get tipo => $state.composableBuilder(
      column: $state.table.tipo,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get email => $state.composableBuilder(
      column: $state.table.email,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get site => $state.composableBuilder(
      column: $state.table.site,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get cpfCnpj => $state.composableBuilder(
      column: $state.table.cpfCnpj,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get rgIe => $state.composableBuilder(
      column: $state.table.rgIe,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<DateTime> get desde => $state.composableBuilder(
      column: $state.table.desde,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<double> get taxaDesconto => $state.composableBuilder(
      column: $state.table.taxaDesconto,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<double> get limiteCredito => $state.composableBuilder(
      column: $state.table.limiteCredito,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<DateTime> get dataCadastro => $state.composableBuilder(
      column: $state.table.dataCadastro,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get observacao => $state.composableBuilder(
      column: $state.table.observacao,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<int> get idPessoa => $state.composableBuilder(
      column: $state.table.idPessoa,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));
}

class $$ViewPessoaClientesTableOrderingComposer
    extends OrderingComposer<_$AppDatabase, $ViewPessoaClientesTable> {
  $$ViewPessoaClientesTableOrderingComposer(super.$state);
  ColumnOrderings<int> get id => $state.composableBuilder(
      column: $state.table.id,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get nome => $state.composableBuilder(
      column: $state.table.nome,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get tipo => $state.composableBuilder(
      column: $state.table.tipo,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get email => $state.composableBuilder(
      column: $state.table.email,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get site => $state.composableBuilder(
      column: $state.table.site,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get cpfCnpj => $state.composableBuilder(
      column: $state.table.cpfCnpj,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get rgIe => $state.composableBuilder(
      column: $state.table.rgIe,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<DateTime> get desde => $state.composableBuilder(
      column: $state.table.desde,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<double> get taxaDesconto => $state.composableBuilder(
      column: $state.table.taxaDesconto,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<double> get limiteCredito => $state.composableBuilder(
      column: $state.table.limiteCredito,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<DateTime> get dataCadastro => $state.composableBuilder(
      column: $state.table.dataCadastro,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get observacao => $state.composableBuilder(
      column: $state.table.observacao,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<int> get idPessoa => $state.composableBuilder(
      column: $state.table.idPessoa,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));
}

typedef $$ViewPessoaColaboradorsTableCreateCompanionBuilder
    = ViewPessoaColaboradorsCompanion Function({
  Value<int?> id,
  Value<String?> nome,
  Value<String?> tipo,
  Value<String?> email,
  Value<String?> site,
  Value<String?> cpfCnpj,
  Value<String?> rgIe,
  Value<String?> matricula,
  Value<DateTime?> dataCadastro,
  Value<DateTime?> dataAdmissao,
  Value<DateTime?> dataDemissao,
  Value<String?> ctpsNumero,
  Value<String?> ctpsSerie,
  Value<DateTime?> ctpsDataExpedicao,
  Value<String?> ctpsUf,
  Value<String?> observacao,
  Value<String?> logradouro,
  Value<String?> numero,
  Value<String?> complemento,
  Value<String?> bairro,
  Value<String?> cidade,
  Value<String?> cep,
  Value<String?> municipioIbge,
  Value<String?> uf,
  Value<int?> idPessoa,
  Value<int?> idCargo,
  Value<int?> idSetor,
});
typedef $$ViewPessoaColaboradorsTableUpdateCompanionBuilder
    = ViewPessoaColaboradorsCompanion Function({
  Value<int?> id,
  Value<String?> nome,
  Value<String?> tipo,
  Value<String?> email,
  Value<String?> site,
  Value<String?> cpfCnpj,
  Value<String?> rgIe,
  Value<String?> matricula,
  Value<DateTime?> dataCadastro,
  Value<DateTime?> dataAdmissao,
  Value<DateTime?> dataDemissao,
  Value<String?> ctpsNumero,
  Value<String?> ctpsSerie,
  Value<DateTime?> ctpsDataExpedicao,
  Value<String?> ctpsUf,
  Value<String?> observacao,
  Value<String?> logradouro,
  Value<String?> numero,
  Value<String?> complemento,
  Value<String?> bairro,
  Value<String?> cidade,
  Value<String?> cep,
  Value<String?> municipioIbge,
  Value<String?> uf,
  Value<int?> idPessoa,
  Value<int?> idCargo,
  Value<int?> idSetor,
});

class $$ViewPessoaColaboradorsTableTableManager extends RootTableManager<
    _$AppDatabase,
    $ViewPessoaColaboradorsTable,
    ViewPessoaColaborador,
    $$ViewPessoaColaboradorsTableFilterComposer,
    $$ViewPessoaColaboradorsTableOrderingComposer,
    $$ViewPessoaColaboradorsTableCreateCompanionBuilder,
    $$ViewPessoaColaboradorsTableUpdateCompanionBuilder> {
  $$ViewPessoaColaboradorsTableTableManager(
      _$AppDatabase db, $ViewPessoaColaboradorsTable table)
      : super(TableManagerState(
          db: db,
          table: table,
          filteringComposer: $$ViewPessoaColaboradorsTableFilterComposer(
              ComposerState(db, table)),
          orderingComposer: $$ViewPessoaColaboradorsTableOrderingComposer(
              ComposerState(db, table)),
          updateCompanionCallback: ({
            Value<int?> id = const Value.absent(),
            Value<String?> nome = const Value.absent(),
            Value<String?> tipo = const Value.absent(),
            Value<String?> email = const Value.absent(),
            Value<String?> site = const Value.absent(),
            Value<String?> cpfCnpj = const Value.absent(),
            Value<String?> rgIe = const Value.absent(),
            Value<String?> matricula = const Value.absent(),
            Value<DateTime?> dataCadastro = const Value.absent(),
            Value<DateTime?> dataAdmissao = const Value.absent(),
            Value<DateTime?> dataDemissao = const Value.absent(),
            Value<String?> ctpsNumero = const Value.absent(),
            Value<String?> ctpsSerie = const Value.absent(),
            Value<DateTime?> ctpsDataExpedicao = const Value.absent(),
            Value<String?> ctpsUf = const Value.absent(),
            Value<String?> observacao = const Value.absent(),
            Value<String?> logradouro = const Value.absent(),
            Value<String?> numero = const Value.absent(),
            Value<String?> complemento = const Value.absent(),
            Value<String?> bairro = const Value.absent(),
            Value<String?> cidade = const Value.absent(),
            Value<String?> cep = const Value.absent(),
            Value<String?> municipioIbge = const Value.absent(),
            Value<String?> uf = const Value.absent(),
            Value<int?> idPessoa = const Value.absent(),
            Value<int?> idCargo = const Value.absent(),
            Value<int?> idSetor = const Value.absent(),
          }) =>
              ViewPessoaColaboradorsCompanion(
            id: id,
            nome: nome,
            tipo: tipo,
            email: email,
            site: site,
            cpfCnpj: cpfCnpj,
            rgIe: rgIe,
            matricula: matricula,
            dataCadastro: dataCadastro,
            dataAdmissao: dataAdmissao,
            dataDemissao: dataDemissao,
            ctpsNumero: ctpsNumero,
            ctpsSerie: ctpsSerie,
            ctpsDataExpedicao: ctpsDataExpedicao,
            ctpsUf: ctpsUf,
            observacao: observacao,
            logradouro: logradouro,
            numero: numero,
            complemento: complemento,
            bairro: bairro,
            cidade: cidade,
            cep: cep,
            municipioIbge: municipioIbge,
            uf: uf,
            idPessoa: idPessoa,
            idCargo: idCargo,
            idSetor: idSetor,
          ),
          createCompanionCallback: ({
            Value<int?> id = const Value.absent(),
            Value<String?> nome = const Value.absent(),
            Value<String?> tipo = const Value.absent(),
            Value<String?> email = const Value.absent(),
            Value<String?> site = const Value.absent(),
            Value<String?> cpfCnpj = const Value.absent(),
            Value<String?> rgIe = const Value.absent(),
            Value<String?> matricula = const Value.absent(),
            Value<DateTime?> dataCadastro = const Value.absent(),
            Value<DateTime?> dataAdmissao = const Value.absent(),
            Value<DateTime?> dataDemissao = const Value.absent(),
            Value<String?> ctpsNumero = const Value.absent(),
            Value<String?> ctpsSerie = const Value.absent(),
            Value<DateTime?> ctpsDataExpedicao = const Value.absent(),
            Value<String?> ctpsUf = const Value.absent(),
            Value<String?> observacao = const Value.absent(),
            Value<String?> logradouro = const Value.absent(),
            Value<String?> numero = const Value.absent(),
            Value<String?> complemento = const Value.absent(),
            Value<String?> bairro = const Value.absent(),
            Value<String?> cidade = const Value.absent(),
            Value<String?> cep = const Value.absent(),
            Value<String?> municipioIbge = const Value.absent(),
            Value<String?> uf = const Value.absent(),
            Value<int?> idPessoa = const Value.absent(),
            Value<int?> idCargo = const Value.absent(),
            Value<int?> idSetor = const Value.absent(),
          }) =>
              ViewPessoaColaboradorsCompanion.insert(
            id: id,
            nome: nome,
            tipo: tipo,
            email: email,
            site: site,
            cpfCnpj: cpfCnpj,
            rgIe: rgIe,
            matricula: matricula,
            dataCadastro: dataCadastro,
            dataAdmissao: dataAdmissao,
            dataDemissao: dataDemissao,
            ctpsNumero: ctpsNumero,
            ctpsSerie: ctpsSerie,
            ctpsDataExpedicao: ctpsDataExpedicao,
            ctpsUf: ctpsUf,
            observacao: observacao,
            logradouro: logradouro,
            numero: numero,
            complemento: complemento,
            bairro: bairro,
            cidade: cidade,
            cep: cep,
            municipioIbge: municipioIbge,
            uf: uf,
            idPessoa: idPessoa,
            idCargo: idCargo,
            idSetor: idSetor,
          ),
        ));
}

class $$ViewPessoaColaboradorsTableFilterComposer
    extends FilterComposer<_$AppDatabase, $ViewPessoaColaboradorsTable> {
  $$ViewPessoaColaboradorsTableFilterComposer(super.$state);
  ColumnFilters<int> get id => $state.composableBuilder(
      column: $state.table.id,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get nome => $state.composableBuilder(
      column: $state.table.nome,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get tipo => $state.composableBuilder(
      column: $state.table.tipo,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get email => $state.composableBuilder(
      column: $state.table.email,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get site => $state.composableBuilder(
      column: $state.table.site,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get cpfCnpj => $state.composableBuilder(
      column: $state.table.cpfCnpj,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get rgIe => $state.composableBuilder(
      column: $state.table.rgIe,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get matricula => $state.composableBuilder(
      column: $state.table.matricula,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<DateTime> get dataCadastro => $state.composableBuilder(
      column: $state.table.dataCadastro,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<DateTime> get dataAdmissao => $state.composableBuilder(
      column: $state.table.dataAdmissao,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<DateTime> get dataDemissao => $state.composableBuilder(
      column: $state.table.dataDemissao,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get ctpsNumero => $state.composableBuilder(
      column: $state.table.ctpsNumero,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get ctpsSerie => $state.composableBuilder(
      column: $state.table.ctpsSerie,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<DateTime> get ctpsDataExpedicao => $state.composableBuilder(
      column: $state.table.ctpsDataExpedicao,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get ctpsUf => $state.composableBuilder(
      column: $state.table.ctpsUf,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get observacao => $state.composableBuilder(
      column: $state.table.observacao,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get logradouro => $state.composableBuilder(
      column: $state.table.logradouro,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get numero => $state.composableBuilder(
      column: $state.table.numero,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get complemento => $state.composableBuilder(
      column: $state.table.complemento,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get bairro => $state.composableBuilder(
      column: $state.table.bairro,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get cidade => $state.composableBuilder(
      column: $state.table.cidade,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get cep => $state.composableBuilder(
      column: $state.table.cep,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get municipioIbge => $state.composableBuilder(
      column: $state.table.municipioIbge,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get uf => $state.composableBuilder(
      column: $state.table.uf,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<int> get idPessoa => $state.composableBuilder(
      column: $state.table.idPessoa,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<int> get idCargo => $state.composableBuilder(
      column: $state.table.idCargo,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<int> get idSetor => $state.composableBuilder(
      column: $state.table.idSetor,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));
}

class $$ViewPessoaColaboradorsTableOrderingComposer
    extends OrderingComposer<_$AppDatabase, $ViewPessoaColaboradorsTable> {
  $$ViewPessoaColaboradorsTableOrderingComposer(super.$state);
  ColumnOrderings<int> get id => $state.composableBuilder(
      column: $state.table.id,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get nome => $state.composableBuilder(
      column: $state.table.nome,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get tipo => $state.composableBuilder(
      column: $state.table.tipo,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get email => $state.composableBuilder(
      column: $state.table.email,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get site => $state.composableBuilder(
      column: $state.table.site,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get cpfCnpj => $state.composableBuilder(
      column: $state.table.cpfCnpj,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get rgIe => $state.composableBuilder(
      column: $state.table.rgIe,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get matricula => $state.composableBuilder(
      column: $state.table.matricula,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<DateTime> get dataCadastro => $state.composableBuilder(
      column: $state.table.dataCadastro,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<DateTime> get dataAdmissao => $state.composableBuilder(
      column: $state.table.dataAdmissao,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<DateTime> get dataDemissao => $state.composableBuilder(
      column: $state.table.dataDemissao,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get ctpsNumero => $state.composableBuilder(
      column: $state.table.ctpsNumero,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get ctpsSerie => $state.composableBuilder(
      column: $state.table.ctpsSerie,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<DateTime> get ctpsDataExpedicao => $state.composableBuilder(
      column: $state.table.ctpsDataExpedicao,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get ctpsUf => $state.composableBuilder(
      column: $state.table.ctpsUf,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get observacao => $state.composableBuilder(
      column: $state.table.observacao,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get logradouro => $state.composableBuilder(
      column: $state.table.logradouro,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get numero => $state.composableBuilder(
      column: $state.table.numero,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get complemento => $state.composableBuilder(
      column: $state.table.complemento,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get bairro => $state.composableBuilder(
      column: $state.table.bairro,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get cidade => $state.composableBuilder(
      column: $state.table.cidade,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get cep => $state.composableBuilder(
      column: $state.table.cep,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get municipioIbge => $state.composableBuilder(
      column: $state.table.municipioIbge,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get uf => $state.composableBuilder(
      column: $state.table.uf,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<int> get idPessoa => $state.composableBuilder(
      column: $state.table.idPessoa,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<int> get idCargo => $state.composableBuilder(
      column: $state.table.idCargo,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<int> get idSetor => $state.composableBuilder(
      column: $state.table.idSetor,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));
}

class $AppDatabaseManager {
  final _$AppDatabase _db;
  $AppDatabaseManager(this._db);
  $$OsAberturasTableTableManager get osAberturas =>
      $$OsAberturasTableTableManager(_db, _db.osAberturas);
  $$NfseDetalhesTableTableManager get nfseDetalhes =>
      $$NfseDetalhesTableTableManager(_db, _db.nfseDetalhes);
  $$NfseIntermediariosTableTableManager get nfseIntermediarios =>
      $$NfseIntermediariosTableTableManager(_db, _db.nfseIntermediarios);
  $$OsStatussTableTableManager get osStatuss =>
      $$OsStatussTableTableManager(_db, _db.osStatuss);
  $$NfseCabecalhosTableTableManager get nfseCabecalhos =>
      $$NfseCabecalhosTableTableManager(_db, _db.nfseCabecalhos);
  $$NfseListaServicosTableTableManager get nfseListaServicos =>
      $$NfseListaServicosTableTableManager(_db, _db.nfseListaServicos);
  $$ViewControleAcessosTableTableManager get viewControleAcessos =>
      $$ViewControleAcessosTableTableManager(_db, _db.viewControleAcessos);
  $$ViewPessoaUsuariosTableTableManager get viewPessoaUsuarios =>
      $$ViewPessoaUsuariosTableTableManager(_db, _db.viewPessoaUsuarios);
  $$ViewPessoaClientesTableTableManager get viewPessoaClientes =>
      $$ViewPessoaClientesTableTableManager(_db, _db.viewPessoaClientes);
  $$ViewPessoaColaboradorsTableTableManager get viewPessoaColaboradors =>
      $$ViewPessoaColaboradorsTableTableManager(
          _db, _db.viewPessoaColaboradors);
}
