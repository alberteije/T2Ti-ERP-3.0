import 'dart:convert';

import 'package:nfse/app/data/provider/api/api_provider_base.dart';
import 'package:nfse/app/data/model/model_imports.dart';

class NfseCabecalhoApiProvider extends ApiProviderBase {
  static const _path = '/nfse-cabecalho';

  Future<List<NfseCabecalhoModel>?> getList({Filter? filter}) {
    return super.getListBase(
      '$_path/',
      (json) => NfseCabecalhoModel.fromJson(json),
      filter: filter,
    );
  }

  Future<NfseCabecalhoModel?> getObject(dynamic pk) {
    return super.getObjectBase(
      _path,
      pk,
      (json) => NfseCabecalhoModel.fromJson(json),
    );
  }

  Future<NfseCabecalhoModel?>? insert(NfseCabecalhoModel model) {
    return super.insertBase(
      _path,
      model,
      (json) => NfseCabecalhoModel.fromJson(json),
    );
  }

  Future<NfseCabecalhoModel?>? update(NfseCabecalhoModel model) {
    return super.updateBase(
      _path,
      model,
      (json) => NfseCabecalhoModel.fromJson(json),
    );
  }

  Future<bool?> delete(dynamic pk) {
    return super.deleteBase(_path, pk);
  }

  Future<dynamic> transmitirNfse(NfseCabecalhoModel nfseCabecalhoModel) async {
    try {
      final response = await ApiProviderBase.httpClient.post(
        Uri.tryParse('$endpoint/nfse-cabecalho/transmite-nfse/')!,
				headers: ApiProviderBase.headerRequisition(),
				body: nfseCabecalhoModel.objectEncodeJson(),
      );

      if (response.statusCode == 200 || response.statusCode == 201) {
        if (response.headers["content-type"]!.contains("html")) {
          handleResultError(response.body, response.headers);
          return null;
        } else {
          final pdf = response.bodyBytes;
          return pdf;
        }
      } else if (response.statusCode == 418) {
        return json.decode(response.body)["message"];
      } else {
        handleResultError(response.body, response.headers);
        return null;
      }
    } on Exception catch (e) {
      handleResultError(null, null, exception: e);
    }
    return null;
  }

}
