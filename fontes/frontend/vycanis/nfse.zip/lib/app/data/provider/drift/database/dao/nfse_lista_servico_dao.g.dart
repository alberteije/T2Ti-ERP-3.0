// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'nfse_lista_servico_dao.dart';

// ignore_for_file: type=lint
mixin _$NfseListaServicoDaoMixin on DatabaseAccessor<AppDatabase> {
  $NfseListaServicosTable get nfseListaServicos =>
      attachedDatabase.nfseListaServicos;
}
