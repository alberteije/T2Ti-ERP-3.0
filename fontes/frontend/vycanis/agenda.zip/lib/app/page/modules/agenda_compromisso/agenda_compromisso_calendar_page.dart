import 'package:agenda/app/page/shared_widget/shared_widget_imports.dart';
import 'package:flutter/material.dart';
import 'package:syncfusion_flutter_calendar/calendar.dart';
import 'package:get/get.dart';
import 'package:agenda/app/controller/controller_imports.dart';

class AgendaCompromissoCalendarPage extends StatelessWidget {
  const AgendaCompromissoCalendarPage({super.key});

  @override
  Widget build(BuildContext context) {
    final controller = Get.find<AgendaCompromissoController>();

    return Scaffold(
      appBar: AppBar(
        automaticallyImplyLeading: false,
        title: const Text("Calendário de Compromissos"),
        actions: [
          exitButton(),
        ]
      ),
      body: SfCalendar(
          view: CalendarView.month,
          dataSource: controller.calendarDataSource,
          monthViewSettings: const MonthViewSettings(showAgenda: true),
        ),
    );
  }
}
