import 'package:flutter/material.dart';
import 'package:agenda/app/controller/reuniao_sala_controller.dart';
import 'package:agenda/app/page/shared_page/list_page_base.dart';

class ReuniaoSalaListPage extends ListPageBase<ReuniaoSalaController> {
  const ReuniaoSalaListPage({Key? key}) : super(key: key);

  @override
  List<Map<String, dynamic>> get mobileItems => controller.mobileItems;

  @override
  Map<String, dynamic> get mobileConfig => controller.mobileConfig;

  @override
  String get standardFieldForFilter => controller.standardFieldForFilter;
}