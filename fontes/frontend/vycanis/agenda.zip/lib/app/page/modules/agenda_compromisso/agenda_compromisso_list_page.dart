import 'package:flutter/material.dart';
import 'package:agenda/app/controller/agenda_compromisso_controller.dart';
import 'package:agenda/app/page/shared_page/list_page_base.dart';

class AgendaCompromissoListPage extends ListPageBase<AgendaCompromissoController> {
  const AgendaCompromissoListPage({Key? key}) : super(key: key);

  @override
  List<Map<String, dynamic>> get mobileItems => controller.mobileItems;

  @override
  Map<String, dynamic> get mobileConfig => controller.mobileConfig;

  @override
  String get standardFieldForFilter => controller.standardFieldForFilter;

  @override
  List<Widget> additionalAppBarActions() {
    return [
      IconButton(
        tooltip: 'Ver Agenda',
        icon: const Icon(Icons.calendar_month),
        color: Colors.lime,
        onPressed: controller.openCalendarForCurrentList,
      ),
    ];
  }
}