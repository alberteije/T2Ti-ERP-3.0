import 'package:agenda/app/data/provider/api/api_provider_base.dart';
import 'package:agenda/app/data/model/model_imports.dart';

class AgendaCompromissoApiProvider extends ApiProviderBase {
  static const _path = '/agenda-compromisso';

  Future<List<AgendaCompromissoModel>?> getList({Filter? filter}) {
    return super.getListBase(
      '$_path/',
      (json) => AgendaCompromissoModel.fromJson(json),
      filter: filter,
    );
  }

  Future<AgendaCompromissoModel?> getObject(dynamic pk) {
    return super.getObjectBase(
      _path,
      pk,
      (json) => AgendaCompromissoModel.fromJson(json),
    );
  }

  Future<AgendaCompromissoModel?>? insert(AgendaCompromissoModel model) {
    return super.insertBase(
      _path,
      model,
      (json) => AgendaCompromissoModel.fromJson(json),
    );
  }

  Future<AgendaCompromissoModel?>? update(AgendaCompromissoModel model) {
    return super.updateBase(
      _path,
      model,
      (json) => AgendaCompromissoModel.fromJson(json),
    );
  }

  Future<bool?> delete(dynamic pk) {
    return super.deleteBase(_path, pk);
  }
}
