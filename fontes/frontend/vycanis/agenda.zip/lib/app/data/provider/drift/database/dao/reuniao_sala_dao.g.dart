// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'reuniao_sala_dao.dart';

// ignore_for_file: type=lint
mixin _$ReuniaoSalaDaoMixin on DatabaseAccessor<AppDatabase> {
  $ReuniaoSalasTable get reuniaoSalas => attachedDatabase.reuniaoSalas;
}
