// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'database.dart';

// ignore_for_file: type=lint
class $AgendaNotificacaosTable extends AgendaNotificacaos
    with TableInfo<$AgendaNotificacaosTable, AgendaNotificacao> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $AgendaNotificacaosTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
    'id',
    aliasedName,
    true,
    type: DriftSqlType.int,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _idAgendaCompromissoMeta =
      const VerificationMeta('idAgendaCompromisso');
  @override
  late final GeneratedColumn<int> idAgendaCompromisso = GeneratedColumn<int>(
    'id_agenda_compromisso',
    aliasedName,
    true,
    type: DriftSqlType.int,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _dataNotificacaoMeta = const VerificationMeta(
    'dataNotificacao',
  );
  @override
  late final GeneratedColumn<DateTime> dataNotificacao =
      GeneratedColumn<DateTime>(
        'data_notificacao',
        aliasedName,
        true,
        type: DriftSqlType.dateTime,
        requiredDuringInsert: false,
      );
  static const VerificationMeta _horaMeta = const VerificationMeta('hora');
  @override
  late final GeneratedColumn<String> hora = GeneratedColumn<String>(
    'hora',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 8,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _tipoMeta = const VerificationMeta('tipo');
  @override
  late final GeneratedColumn<String> tipo = GeneratedColumn<String>(
    'tipo',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 1,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  @override
  List<GeneratedColumn> get $columns => [
    id,
    idAgendaCompromisso,
    dataNotificacao,
    hora,
    tipo,
  ];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'agenda_notificacao';
  @override
  VerificationContext validateIntegrity(
    Insertable<AgendaNotificacao> instance, {
    bool isInserting = false,
  }) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('id_agenda_compromisso')) {
      context.handle(
        _idAgendaCompromissoMeta,
        idAgendaCompromisso.isAcceptableOrUnknown(
          data['id_agenda_compromisso']!,
          _idAgendaCompromissoMeta,
        ),
      );
    }
    if (data.containsKey('data_notificacao')) {
      context.handle(
        _dataNotificacaoMeta,
        dataNotificacao.isAcceptableOrUnknown(
          data['data_notificacao']!,
          _dataNotificacaoMeta,
        ),
      );
    }
    if (data.containsKey('hora')) {
      context.handle(
        _horaMeta,
        hora.isAcceptableOrUnknown(data['hora']!, _horaMeta),
      );
    }
    if (data.containsKey('tipo')) {
      context.handle(
        _tipoMeta,
        tipo.isAcceptableOrUnknown(data['tipo']!, _tipoMeta),
      );
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  AgendaNotificacao map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return AgendaNotificacao(
      id: attachedDatabase.typeMapping.read(
        DriftSqlType.int,
        data['${effectivePrefix}id'],
      ),
      idAgendaCompromisso: attachedDatabase.typeMapping.read(
        DriftSqlType.int,
        data['${effectivePrefix}id_agenda_compromisso'],
      ),
      dataNotificacao: attachedDatabase.typeMapping.read(
        DriftSqlType.dateTime,
        data['${effectivePrefix}data_notificacao'],
      ),
      hora: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}hora'],
      ),
      tipo: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}tipo'],
      ),
    );
  }

  @override
  $AgendaNotificacaosTable createAlias(String alias) {
    return $AgendaNotificacaosTable(attachedDatabase, alias);
  }
}

class AgendaNotificacao extends DataClass
    implements Insertable<AgendaNotificacao> {
  final int? id;
  final int? idAgendaCompromisso;
  final DateTime? dataNotificacao;
  final String? hora;
  final String? tipo;
  const AgendaNotificacao({
    this.id,
    this.idAgendaCompromisso,
    this.dataNotificacao,
    this.hora,
    this.tipo,
  });
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || idAgendaCompromisso != null) {
      map['id_agenda_compromisso'] = Variable<int>(idAgendaCompromisso);
    }
    if (!nullToAbsent || dataNotificacao != null) {
      map['data_notificacao'] = Variable<DateTime>(dataNotificacao);
    }
    if (!nullToAbsent || hora != null) {
      map['hora'] = Variable<String>(hora);
    }
    if (!nullToAbsent || tipo != null) {
      map['tipo'] = Variable<String>(tipo);
    }
    return map;
  }

  factory AgendaNotificacao.fromJson(
    Map<String, dynamic> json, {
    ValueSerializer? serializer,
  }) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return AgendaNotificacao(
      id: serializer.fromJson<int?>(json['id']),
      idAgendaCompromisso: serializer.fromJson<int?>(
        json['idAgendaCompromisso'],
      ),
      dataNotificacao: serializer.fromJson<DateTime?>(json['dataNotificacao']),
      hora: serializer.fromJson<String?>(json['hora']),
      tipo: serializer.fromJson<String?>(json['tipo']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'idAgendaCompromisso': serializer.toJson<int?>(idAgendaCompromisso),
      'dataNotificacao': serializer.toJson<DateTime?>(dataNotificacao),
      'hora': serializer.toJson<String?>(hora),
      'tipo': serializer.toJson<String?>(tipo),
    };
  }

  AgendaNotificacao copyWith({
    Value<int?> id = const Value.absent(),
    Value<int?> idAgendaCompromisso = const Value.absent(),
    Value<DateTime?> dataNotificacao = const Value.absent(),
    Value<String?> hora = const Value.absent(),
    Value<String?> tipo = const Value.absent(),
  }) => AgendaNotificacao(
    id: id.present ? id.value : this.id,
    idAgendaCompromisso:
        idAgendaCompromisso.present
            ? idAgendaCompromisso.value
            : this.idAgendaCompromisso,
    dataNotificacao:
        dataNotificacao.present ? dataNotificacao.value : this.dataNotificacao,
    hora: hora.present ? hora.value : this.hora,
    tipo: tipo.present ? tipo.value : this.tipo,
  );
  AgendaNotificacao copyWithCompanion(AgendaNotificacaosCompanion data) {
    return AgendaNotificacao(
      id: data.id.present ? data.id.value : this.id,
      idAgendaCompromisso:
          data.idAgendaCompromisso.present
              ? data.idAgendaCompromisso.value
              : this.idAgendaCompromisso,
      dataNotificacao:
          data.dataNotificacao.present
              ? data.dataNotificacao.value
              : this.dataNotificacao,
      hora: data.hora.present ? data.hora.value : this.hora,
      tipo: data.tipo.present ? data.tipo.value : this.tipo,
    );
  }

  @override
  String toString() {
    return (StringBuffer('AgendaNotificacao(')
          ..write('id: $id, ')
          ..write('idAgendaCompromisso: $idAgendaCompromisso, ')
          ..write('dataNotificacao: $dataNotificacao, ')
          ..write('hora: $hora, ')
          ..write('tipo: $tipo')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode =>
      Object.hash(id, idAgendaCompromisso, dataNotificacao, hora, tipo);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is AgendaNotificacao &&
          other.id == this.id &&
          other.idAgendaCompromisso == this.idAgendaCompromisso &&
          other.dataNotificacao == this.dataNotificacao &&
          other.hora == this.hora &&
          other.tipo == this.tipo);
}

class AgendaNotificacaosCompanion extends UpdateCompanion<AgendaNotificacao> {
  final Value<int?> id;
  final Value<int?> idAgendaCompromisso;
  final Value<DateTime?> dataNotificacao;
  final Value<String?> hora;
  final Value<String?> tipo;
  const AgendaNotificacaosCompanion({
    this.id = const Value.absent(),
    this.idAgendaCompromisso = const Value.absent(),
    this.dataNotificacao = const Value.absent(),
    this.hora = const Value.absent(),
    this.tipo = const Value.absent(),
  });
  AgendaNotificacaosCompanion.insert({
    this.id = const Value.absent(),
    this.idAgendaCompromisso = const Value.absent(),
    this.dataNotificacao = const Value.absent(),
    this.hora = const Value.absent(),
    this.tipo = const Value.absent(),
  });
  static Insertable<AgendaNotificacao> custom({
    Expression<int>? id,
    Expression<int>? idAgendaCompromisso,
    Expression<DateTime>? dataNotificacao,
    Expression<String>? hora,
    Expression<String>? tipo,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (idAgendaCompromisso != null)
        'id_agenda_compromisso': idAgendaCompromisso,
      if (dataNotificacao != null) 'data_notificacao': dataNotificacao,
      if (hora != null) 'hora': hora,
      if (tipo != null) 'tipo': tipo,
    });
  }

  AgendaNotificacaosCompanion copyWith({
    Value<int?>? id,
    Value<int?>? idAgendaCompromisso,
    Value<DateTime?>? dataNotificacao,
    Value<String?>? hora,
    Value<String?>? tipo,
  }) {
    return AgendaNotificacaosCompanion(
      id: id ?? this.id,
      idAgendaCompromisso: idAgendaCompromisso ?? this.idAgendaCompromisso,
      dataNotificacao: dataNotificacao ?? this.dataNotificacao,
      hora: hora ?? this.hora,
      tipo: tipo ?? this.tipo,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (idAgendaCompromisso.present) {
      map['id_agenda_compromisso'] = Variable<int>(idAgendaCompromisso.value);
    }
    if (dataNotificacao.present) {
      map['data_notificacao'] = Variable<DateTime>(dataNotificacao.value);
    }
    if (hora.present) {
      map['hora'] = Variable<String>(hora.value);
    }
    if (tipo.present) {
      map['tipo'] = Variable<String>(tipo.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('AgendaNotificacaosCompanion(')
          ..write('id: $id, ')
          ..write('idAgendaCompromisso: $idAgendaCompromisso, ')
          ..write('dataNotificacao: $dataNotificacao, ')
          ..write('hora: $hora, ')
          ..write('tipo: $tipo')
          ..write(')'))
        .toString();
  }
}

class $AgendaCompromissoConvidadosTable extends AgendaCompromissoConvidados
    with
        TableInfo<
          $AgendaCompromissoConvidadosTable,
          AgendaCompromissoConvidado
        > {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $AgendaCompromissoConvidadosTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
    'id',
    aliasedName,
    true,
    type: DriftSqlType.int,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _idAgendaCompromissoMeta =
      const VerificationMeta('idAgendaCompromisso');
  @override
  late final GeneratedColumn<int> idAgendaCompromisso = GeneratedColumn<int>(
    'id_agenda_compromisso',
    aliasedName,
    true,
    type: DriftSqlType.int,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _idColaboradorMeta = const VerificationMeta(
    'idColaborador',
  );
  @override
  late final GeneratedColumn<int> idColaborador = GeneratedColumn<int>(
    'id_colaborador',
    aliasedName,
    true,
    type: DriftSqlType.int,
    requiredDuringInsert: false,
  );
  @override
  List<GeneratedColumn> get $columns => [
    id,
    idAgendaCompromisso,
    idColaborador,
  ];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'agenda_compromisso_convidado';
  @override
  VerificationContext validateIntegrity(
    Insertable<AgendaCompromissoConvidado> instance, {
    bool isInserting = false,
  }) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('id_agenda_compromisso')) {
      context.handle(
        _idAgendaCompromissoMeta,
        idAgendaCompromisso.isAcceptableOrUnknown(
          data['id_agenda_compromisso']!,
          _idAgendaCompromissoMeta,
        ),
      );
    }
    if (data.containsKey('id_colaborador')) {
      context.handle(
        _idColaboradorMeta,
        idColaborador.isAcceptableOrUnknown(
          data['id_colaborador']!,
          _idColaboradorMeta,
        ),
      );
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  AgendaCompromissoConvidado map(
    Map<String, dynamic> data, {
    String? tablePrefix,
  }) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return AgendaCompromissoConvidado(
      id: attachedDatabase.typeMapping.read(
        DriftSqlType.int,
        data['${effectivePrefix}id'],
      ),
      idAgendaCompromisso: attachedDatabase.typeMapping.read(
        DriftSqlType.int,
        data['${effectivePrefix}id_agenda_compromisso'],
      ),
      idColaborador: attachedDatabase.typeMapping.read(
        DriftSqlType.int,
        data['${effectivePrefix}id_colaborador'],
      ),
    );
  }

  @override
  $AgendaCompromissoConvidadosTable createAlias(String alias) {
    return $AgendaCompromissoConvidadosTable(attachedDatabase, alias);
  }
}

class AgendaCompromissoConvidado extends DataClass
    implements Insertable<AgendaCompromissoConvidado> {
  final int? id;
  final int? idAgendaCompromisso;
  final int? idColaborador;
  const AgendaCompromissoConvidado({
    this.id,
    this.idAgendaCompromisso,
    this.idColaborador,
  });
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || idAgendaCompromisso != null) {
      map['id_agenda_compromisso'] = Variable<int>(idAgendaCompromisso);
    }
    if (!nullToAbsent || idColaborador != null) {
      map['id_colaborador'] = Variable<int>(idColaborador);
    }
    return map;
  }

  factory AgendaCompromissoConvidado.fromJson(
    Map<String, dynamic> json, {
    ValueSerializer? serializer,
  }) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return AgendaCompromissoConvidado(
      id: serializer.fromJson<int?>(json['id']),
      idAgendaCompromisso: serializer.fromJson<int?>(
        json['idAgendaCompromisso'],
      ),
      idColaborador: serializer.fromJson<int?>(json['idColaborador']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'idAgendaCompromisso': serializer.toJson<int?>(idAgendaCompromisso),
      'idColaborador': serializer.toJson<int?>(idColaborador),
    };
  }

  AgendaCompromissoConvidado copyWith({
    Value<int?> id = const Value.absent(),
    Value<int?> idAgendaCompromisso = const Value.absent(),
    Value<int?> idColaborador = const Value.absent(),
  }) => AgendaCompromissoConvidado(
    id: id.present ? id.value : this.id,
    idAgendaCompromisso:
        idAgendaCompromisso.present
            ? idAgendaCompromisso.value
            : this.idAgendaCompromisso,
    idColaborador:
        idColaborador.present ? idColaborador.value : this.idColaborador,
  );
  AgendaCompromissoConvidado copyWithCompanion(
    AgendaCompromissoConvidadosCompanion data,
  ) {
    return AgendaCompromissoConvidado(
      id: data.id.present ? data.id.value : this.id,
      idAgendaCompromisso:
          data.idAgendaCompromisso.present
              ? data.idAgendaCompromisso.value
              : this.idAgendaCompromisso,
      idColaborador:
          data.idColaborador.present
              ? data.idColaborador.value
              : this.idColaborador,
    );
  }

  @override
  String toString() {
    return (StringBuffer('AgendaCompromissoConvidado(')
          ..write('id: $id, ')
          ..write('idAgendaCompromisso: $idAgendaCompromisso, ')
          ..write('idColaborador: $idColaborador')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(id, idAgendaCompromisso, idColaborador);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is AgendaCompromissoConvidado &&
          other.id == this.id &&
          other.idAgendaCompromisso == this.idAgendaCompromisso &&
          other.idColaborador == this.idColaborador);
}

class AgendaCompromissoConvidadosCompanion
    extends UpdateCompanion<AgendaCompromissoConvidado> {
  final Value<int?> id;
  final Value<int?> idAgendaCompromisso;
  final Value<int?> idColaborador;
  const AgendaCompromissoConvidadosCompanion({
    this.id = const Value.absent(),
    this.idAgendaCompromisso = const Value.absent(),
    this.idColaborador = const Value.absent(),
  });
  AgendaCompromissoConvidadosCompanion.insert({
    this.id = const Value.absent(),
    this.idAgendaCompromisso = const Value.absent(),
    this.idColaborador = const Value.absent(),
  });
  static Insertable<AgendaCompromissoConvidado> custom({
    Expression<int>? id,
    Expression<int>? idAgendaCompromisso,
    Expression<int>? idColaborador,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (idAgendaCompromisso != null)
        'id_agenda_compromisso': idAgendaCompromisso,
      if (idColaborador != null) 'id_colaborador': idColaborador,
    });
  }

  AgendaCompromissoConvidadosCompanion copyWith({
    Value<int?>? id,
    Value<int?>? idAgendaCompromisso,
    Value<int?>? idColaborador,
  }) {
    return AgendaCompromissoConvidadosCompanion(
      id: id ?? this.id,
      idAgendaCompromisso: idAgendaCompromisso ?? this.idAgendaCompromisso,
      idColaborador: idColaborador ?? this.idColaborador,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (idAgendaCompromisso.present) {
      map['id_agenda_compromisso'] = Variable<int>(idAgendaCompromisso.value);
    }
    if (idColaborador.present) {
      map['id_colaborador'] = Variable<int>(idColaborador.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('AgendaCompromissoConvidadosCompanion(')
          ..write('id: $id, ')
          ..write('idAgendaCompromisso: $idAgendaCompromisso, ')
          ..write('idColaborador: $idColaborador')
          ..write(')'))
        .toString();
  }
}

class $ReuniaoSalaEventosTable extends ReuniaoSalaEventos
    with TableInfo<$ReuniaoSalaEventosTable, ReuniaoSalaEvento> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $ReuniaoSalaEventosTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
    'id',
    aliasedName,
    true,
    type: DriftSqlType.int,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _idAgendaCompromissoMeta =
      const VerificationMeta('idAgendaCompromisso');
  @override
  late final GeneratedColumn<int> idAgendaCompromisso = GeneratedColumn<int>(
    'id_agenda_compromisso',
    aliasedName,
    true,
    type: DriftSqlType.int,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _idReuniaoSalaMeta = const VerificationMeta(
    'idReuniaoSala',
  );
  @override
  late final GeneratedColumn<int> idReuniaoSala = GeneratedColumn<int>(
    'id_reuniao_sala',
    aliasedName,
    true,
    type: DriftSqlType.int,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _dataReservaMeta = const VerificationMeta(
    'dataReserva',
  );
  @override
  late final GeneratedColumn<DateTime> dataReserva = GeneratedColumn<DateTime>(
    'data_reserva',
    aliasedName,
    true,
    type: DriftSqlType.dateTime,
    requiredDuringInsert: false,
  );
  @override
  List<GeneratedColumn> get $columns => [
    id,
    idAgendaCompromisso,
    idReuniaoSala,
    dataReserva,
  ];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'reuniao_sala_evento';
  @override
  VerificationContext validateIntegrity(
    Insertable<ReuniaoSalaEvento> instance, {
    bool isInserting = false,
  }) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('id_agenda_compromisso')) {
      context.handle(
        _idAgendaCompromissoMeta,
        idAgendaCompromisso.isAcceptableOrUnknown(
          data['id_agenda_compromisso']!,
          _idAgendaCompromissoMeta,
        ),
      );
    }
    if (data.containsKey('id_reuniao_sala')) {
      context.handle(
        _idReuniaoSalaMeta,
        idReuniaoSala.isAcceptableOrUnknown(
          data['id_reuniao_sala']!,
          _idReuniaoSalaMeta,
        ),
      );
    }
    if (data.containsKey('data_reserva')) {
      context.handle(
        _dataReservaMeta,
        dataReserva.isAcceptableOrUnknown(
          data['data_reserva']!,
          _dataReservaMeta,
        ),
      );
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  ReuniaoSalaEvento map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return ReuniaoSalaEvento(
      id: attachedDatabase.typeMapping.read(
        DriftSqlType.int,
        data['${effectivePrefix}id'],
      ),
      idAgendaCompromisso: attachedDatabase.typeMapping.read(
        DriftSqlType.int,
        data['${effectivePrefix}id_agenda_compromisso'],
      ),
      idReuniaoSala: attachedDatabase.typeMapping.read(
        DriftSqlType.int,
        data['${effectivePrefix}id_reuniao_sala'],
      ),
      dataReserva: attachedDatabase.typeMapping.read(
        DriftSqlType.dateTime,
        data['${effectivePrefix}data_reserva'],
      ),
    );
  }

  @override
  $ReuniaoSalaEventosTable createAlias(String alias) {
    return $ReuniaoSalaEventosTable(attachedDatabase, alias);
  }
}

class ReuniaoSalaEvento extends DataClass
    implements Insertable<ReuniaoSalaEvento> {
  final int? id;
  final int? idAgendaCompromisso;
  final int? idReuniaoSala;
  final DateTime? dataReserva;
  const ReuniaoSalaEvento({
    this.id,
    this.idAgendaCompromisso,
    this.idReuniaoSala,
    this.dataReserva,
  });
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || idAgendaCompromisso != null) {
      map['id_agenda_compromisso'] = Variable<int>(idAgendaCompromisso);
    }
    if (!nullToAbsent || idReuniaoSala != null) {
      map['id_reuniao_sala'] = Variable<int>(idReuniaoSala);
    }
    if (!nullToAbsent || dataReserva != null) {
      map['data_reserva'] = Variable<DateTime>(dataReserva);
    }
    return map;
  }

  factory ReuniaoSalaEvento.fromJson(
    Map<String, dynamic> json, {
    ValueSerializer? serializer,
  }) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return ReuniaoSalaEvento(
      id: serializer.fromJson<int?>(json['id']),
      idAgendaCompromisso: serializer.fromJson<int?>(
        json['idAgendaCompromisso'],
      ),
      idReuniaoSala: serializer.fromJson<int?>(json['idReuniaoSala']),
      dataReserva: serializer.fromJson<DateTime?>(json['dataReserva']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'idAgendaCompromisso': serializer.toJson<int?>(idAgendaCompromisso),
      'idReuniaoSala': serializer.toJson<int?>(idReuniaoSala),
      'dataReserva': serializer.toJson<DateTime?>(dataReserva),
    };
  }

  ReuniaoSalaEvento copyWith({
    Value<int?> id = const Value.absent(),
    Value<int?> idAgendaCompromisso = const Value.absent(),
    Value<int?> idReuniaoSala = const Value.absent(),
    Value<DateTime?> dataReserva = const Value.absent(),
  }) => ReuniaoSalaEvento(
    id: id.present ? id.value : this.id,
    idAgendaCompromisso:
        idAgendaCompromisso.present
            ? idAgendaCompromisso.value
            : this.idAgendaCompromisso,
    idReuniaoSala:
        idReuniaoSala.present ? idReuniaoSala.value : this.idReuniaoSala,
    dataReserva: dataReserva.present ? dataReserva.value : this.dataReserva,
  );
  ReuniaoSalaEvento copyWithCompanion(ReuniaoSalaEventosCompanion data) {
    return ReuniaoSalaEvento(
      id: data.id.present ? data.id.value : this.id,
      idAgendaCompromisso:
          data.idAgendaCompromisso.present
              ? data.idAgendaCompromisso.value
              : this.idAgendaCompromisso,
      idReuniaoSala:
          data.idReuniaoSala.present
              ? data.idReuniaoSala.value
              : this.idReuniaoSala,
      dataReserva:
          data.dataReserva.present ? data.dataReserva.value : this.dataReserva,
    );
  }

  @override
  String toString() {
    return (StringBuffer('ReuniaoSalaEvento(')
          ..write('id: $id, ')
          ..write('idAgendaCompromisso: $idAgendaCompromisso, ')
          ..write('idReuniaoSala: $idReuniaoSala, ')
          ..write('dataReserva: $dataReserva')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode =>
      Object.hash(id, idAgendaCompromisso, idReuniaoSala, dataReserva);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is ReuniaoSalaEvento &&
          other.id == this.id &&
          other.idAgendaCompromisso == this.idAgendaCompromisso &&
          other.idReuniaoSala == this.idReuniaoSala &&
          other.dataReserva == this.dataReserva);
}

class ReuniaoSalaEventosCompanion extends UpdateCompanion<ReuniaoSalaEvento> {
  final Value<int?> id;
  final Value<int?> idAgendaCompromisso;
  final Value<int?> idReuniaoSala;
  final Value<DateTime?> dataReserva;
  const ReuniaoSalaEventosCompanion({
    this.id = const Value.absent(),
    this.idAgendaCompromisso = const Value.absent(),
    this.idReuniaoSala = const Value.absent(),
    this.dataReserva = const Value.absent(),
  });
  ReuniaoSalaEventosCompanion.insert({
    this.id = const Value.absent(),
    this.idAgendaCompromisso = const Value.absent(),
    this.idReuniaoSala = const Value.absent(),
    this.dataReserva = const Value.absent(),
  });
  static Insertable<ReuniaoSalaEvento> custom({
    Expression<int>? id,
    Expression<int>? idAgendaCompromisso,
    Expression<int>? idReuniaoSala,
    Expression<DateTime>? dataReserva,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (idAgendaCompromisso != null)
        'id_agenda_compromisso': idAgendaCompromisso,
      if (idReuniaoSala != null) 'id_reuniao_sala': idReuniaoSala,
      if (dataReserva != null) 'data_reserva': dataReserva,
    });
  }

  ReuniaoSalaEventosCompanion copyWith({
    Value<int?>? id,
    Value<int?>? idAgendaCompromisso,
    Value<int?>? idReuniaoSala,
    Value<DateTime?>? dataReserva,
  }) {
    return ReuniaoSalaEventosCompanion(
      id: id ?? this.id,
      idAgendaCompromisso: idAgendaCompromisso ?? this.idAgendaCompromisso,
      idReuniaoSala: idReuniaoSala ?? this.idReuniaoSala,
      dataReserva: dataReserva ?? this.dataReserva,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (idAgendaCompromisso.present) {
      map['id_agenda_compromisso'] = Variable<int>(idAgendaCompromisso.value);
    }
    if (idReuniaoSala.present) {
      map['id_reuniao_sala'] = Variable<int>(idReuniaoSala.value);
    }
    if (dataReserva.present) {
      map['data_reserva'] = Variable<DateTime>(dataReserva.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('ReuniaoSalaEventosCompanion(')
          ..write('id: $id, ')
          ..write('idAgendaCompromisso: $idAgendaCompromisso, ')
          ..write('idReuniaoSala: $idReuniaoSala, ')
          ..write('dataReserva: $dataReserva')
          ..write(')'))
        .toString();
  }
}

class $RecadoDestinatariosTable extends RecadoDestinatarios
    with TableInfo<$RecadoDestinatariosTable, RecadoDestinatario> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $RecadoDestinatariosTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
    'id',
    aliasedName,
    true,
    type: DriftSqlType.int,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _idColaboradorMeta = const VerificationMeta(
    'idColaborador',
  );
  @override
  late final GeneratedColumn<int> idColaborador = GeneratedColumn<int>(
    'id_colaborador',
    aliasedName,
    true,
    type: DriftSqlType.int,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _idRecadoRemetenteMeta = const VerificationMeta(
    'idRecadoRemetente',
  );
  @override
  late final GeneratedColumn<int> idRecadoRemetente = GeneratedColumn<int>(
    'id_recado_remetente',
    aliasedName,
    true,
    type: DriftSqlType.int,
    requiredDuringInsert: false,
  );
  @override
  List<GeneratedColumn> get $columns => [id, idColaborador, idRecadoRemetente];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'recado_destinatario';
  @override
  VerificationContext validateIntegrity(
    Insertable<RecadoDestinatario> instance, {
    bool isInserting = false,
  }) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('id_colaborador')) {
      context.handle(
        _idColaboradorMeta,
        idColaborador.isAcceptableOrUnknown(
          data['id_colaborador']!,
          _idColaboradorMeta,
        ),
      );
    }
    if (data.containsKey('id_recado_remetente')) {
      context.handle(
        _idRecadoRemetenteMeta,
        idRecadoRemetente.isAcceptableOrUnknown(
          data['id_recado_remetente']!,
          _idRecadoRemetenteMeta,
        ),
      );
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  RecadoDestinatario map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return RecadoDestinatario(
      id: attachedDatabase.typeMapping.read(
        DriftSqlType.int,
        data['${effectivePrefix}id'],
      ),
      idColaborador: attachedDatabase.typeMapping.read(
        DriftSqlType.int,
        data['${effectivePrefix}id_colaborador'],
      ),
      idRecadoRemetente: attachedDatabase.typeMapping.read(
        DriftSqlType.int,
        data['${effectivePrefix}id_recado_remetente'],
      ),
    );
  }

  @override
  $RecadoDestinatariosTable createAlias(String alias) {
    return $RecadoDestinatariosTable(attachedDatabase, alias);
  }
}

class RecadoDestinatario extends DataClass
    implements Insertable<RecadoDestinatario> {
  final int? id;
  final int? idColaborador;
  final int? idRecadoRemetente;
  const RecadoDestinatario({
    this.id,
    this.idColaborador,
    this.idRecadoRemetente,
  });
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || idColaborador != null) {
      map['id_colaborador'] = Variable<int>(idColaborador);
    }
    if (!nullToAbsent || idRecadoRemetente != null) {
      map['id_recado_remetente'] = Variable<int>(idRecadoRemetente);
    }
    return map;
  }

  factory RecadoDestinatario.fromJson(
    Map<String, dynamic> json, {
    ValueSerializer? serializer,
  }) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return RecadoDestinatario(
      id: serializer.fromJson<int?>(json['id']),
      idColaborador: serializer.fromJson<int?>(json['idColaborador']),
      idRecadoRemetente: serializer.fromJson<int?>(json['idRecadoRemetente']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'idColaborador': serializer.toJson<int?>(idColaborador),
      'idRecadoRemetente': serializer.toJson<int?>(idRecadoRemetente),
    };
  }

  RecadoDestinatario copyWith({
    Value<int?> id = const Value.absent(),
    Value<int?> idColaborador = const Value.absent(),
    Value<int?> idRecadoRemetente = const Value.absent(),
  }) => RecadoDestinatario(
    id: id.present ? id.value : this.id,
    idColaborador:
        idColaborador.present ? idColaborador.value : this.idColaborador,
    idRecadoRemetente:
        idRecadoRemetente.present
            ? idRecadoRemetente.value
            : this.idRecadoRemetente,
  );
  RecadoDestinatario copyWithCompanion(RecadoDestinatariosCompanion data) {
    return RecadoDestinatario(
      id: data.id.present ? data.id.value : this.id,
      idColaborador:
          data.idColaborador.present
              ? data.idColaborador.value
              : this.idColaborador,
      idRecadoRemetente:
          data.idRecadoRemetente.present
              ? data.idRecadoRemetente.value
              : this.idRecadoRemetente,
    );
  }

  @override
  String toString() {
    return (StringBuffer('RecadoDestinatario(')
          ..write('id: $id, ')
          ..write('idColaborador: $idColaborador, ')
          ..write('idRecadoRemetente: $idRecadoRemetente')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(id, idColaborador, idRecadoRemetente);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is RecadoDestinatario &&
          other.id == this.id &&
          other.idColaborador == this.idColaborador &&
          other.idRecadoRemetente == this.idRecadoRemetente);
}

class RecadoDestinatariosCompanion extends UpdateCompanion<RecadoDestinatario> {
  final Value<int?> id;
  final Value<int?> idColaborador;
  final Value<int?> idRecadoRemetente;
  const RecadoDestinatariosCompanion({
    this.id = const Value.absent(),
    this.idColaborador = const Value.absent(),
    this.idRecadoRemetente = const Value.absent(),
  });
  RecadoDestinatariosCompanion.insert({
    this.id = const Value.absent(),
    this.idColaborador = const Value.absent(),
    this.idRecadoRemetente = const Value.absent(),
  });
  static Insertable<RecadoDestinatario> custom({
    Expression<int>? id,
    Expression<int>? idColaborador,
    Expression<int>? idRecadoRemetente,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (idColaborador != null) 'id_colaborador': idColaborador,
      if (idRecadoRemetente != null) 'id_recado_remetente': idRecadoRemetente,
    });
  }

  RecadoDestinatariosCompanion copyWith({
    Value<int?>? id,
    Value<int?>? idColaborador,
    Value<int?>? idRecadoRemetente,
  }) {
    return RecadoDestinatariosCompanion(
      id: id ?? this.id,
      idColaborador: idColaborador ?? this.idColaborador,
      idRecadoRemetente: idRecadoRemetente ?? this.idRecadoRemetente,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (idColaborador.present) {
      map['id_colaborador'] = Variable<int>(idColaborador.value);
    }
    if (idRecadoRemetente.present) {
      map['id_recado_remetente'] = Variable<int>(idRecadoRemetente.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('RecadoDestinatariosCompanion(')
          ..write('id: $id, ')
          ..write('idColaborador: $idColaborador, ')
          ..write('idRecadoRemetente: $idRecadoRemetente')
          ..write(')'))
        .toString();
  }
}

class $AgendaCompromissosTable extends AgendaCompromissos
    with TableInfo<$AgendaCompromissosTable, AgendaCompromisso> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $AgendaCompromissosTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
    'id',
    aliasedName,
    true,
    type: DriftSqlType.int,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _idAgendaCategoriaCompromissoMeta =
      const VerificationMeta('idAgendaCategoriaCompromisso');
  @override
  late final GeneratedColumn<int> idAgendaCategoriaCompromisso =
      GeneratedColumn<int>(
        'id_agenda_categoria_compromisso',
        aliasedName,
        true,
        type: DriftSqlType.int,
        requiredDuringInsert: false,
      );
  static const VerificationMeta _idColaboradorMeta = const VerificationMeta(
    'idColaborador',
  );
  @override
  late final GeneratedColumn<int> idColaborador = GeneratedColumn<int>(
    'id_colaborador',
    aliasedName,
    true,
    type: DriftSqlType.int,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _dataCompromissoMeta = const VerificationMeta(
    'dataCompromisso',
  );
  @override
  late final GeneratedColumn<DateTime> dataCompromisso =
      GeneratedColumn<DateTime>(
        'data_compromisso',
        aliasedName,
        true,
        type: DriftSqlType.dateTime,
        requiredDuringInsert: false,
      );
  static const VerificationMeta _horaMeta = const VerificationMeta('hora');
  @override
  late final GeneratedColumn<String> hora = GeneratedColumn<String>(
    'hora',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 8,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _duracaoMeta = const VerificationMeta(
    'duracao',
  );
  @override
  late final GeneratedColumn<int> duracao = GeneratedColumn<int>(
    'duracao',
    aliasedName,
    true,
    type: DriftSqlType.int,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _tipoMeta = const VerificationMeta('tipo');
  @override
  late final GeneratedColumn<String> tipo = GeneratedColumn<String>(
    'tipo',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 1,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _ondeMeta = const VerificationMeta('onde');
  @override
  late final GeneratedColumn<String> onde = GeneratedColumn<String>(
    'onde',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 100,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _descricaoMeta = const VerificationMeta(
    'descricao',
  );
  @override
  late final GeneratedColumn<String> descricao = GeneratedColumn<String>(
    'descricao',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 100,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  @override
  List<GeneratedColumn> get $columns => [
    id,
    idAgendaCategoriaCompromisso,
    idColaborador,
    dataCompromisso,
    hora,
    duracao,
    tipo,
    onde,
    descricao,
  ];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'agenda_compromisso';
  @override
  VerificationContext validateIntegrity(
    Insertable<AgendaCompromisso> instance, {
    bool isInserting = false,
  }) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('id_agenda_categoria_compromisso')) {
      context.handle(
        _idAgendaCategoriaCompromissoMeta,
        idAgendaCategoriaCompromisso.isAcceptableOrUnknown(
          data['id_agenda_categoria_compromisso']!,
          _idAgendaCategoriaCompromissoMeta,
        ),
      );
    }
    if (data.containsKey('id_colaborador')) {
      context.handle(
        _idColaboradorMeta,
        idColaborador.isAcceptableOrUnknown(
          data['id_colaborador']!,
          _idColaboradorMeta,
        ),
      );
    }
    if (data.containsKey('data_compromisso')) {
      context.handle(
        _dataCompromissoMeta,
        dataCompromisso.isAcceptableOrUnknown(
          data['data_compromisso']!,
          _dataCompromissoMeta,
        ),
      );
    }
    if (data.containsKey('hora')) {
      context.handle(
        _horaMeta,
        hora.isAcceptableOrUnknown(data['hora']!, _horaMeta),
      );
    }
    if (data.containsKey('duracao')) {
      context.handle(
        _duracaoMeta,
        duracao.isAcceptableOrUnknown(data['duracao']!, _duracaoMeta),
      );
    }
    if (data.containsKey('tipo')) {
      context.handle(
        _tipoMeta,
        tipo.isAcceptableOrUnknown(data['tipo']!, _tipoMeta),
      );
    }
    if (data.containsKey('onde')) {
      context.handle(
        _ondeMeta,
        onde.isAcceptableOrUnknown(data['onde']!, _ondeMeta),
      );
    }
    if (data.containsKey('descricao')) {
      context.handle(
        _descricaoMeta,
        descricao.isAcceptableOrUnknown(data['descricao']!, _descricaoMeta),
      );
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  AgendaCompromisso map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return AgendaCompromisso(
      id: attachedDatabase.typeMapping.read(
        DriftSqlType.int,
        data['${effectivePrefix}id'],
      ),
      idAgendaCategoriaCompromisso: attachedDatabase.typeMapping.read(
        DriftSqlType.int,
        data['${effectivePrefix}id_agenda_categoria_compromisso'],
      ),
      idColaborador: attachedDatabase.typeMapping.read(
        DriftSqlType.int,
        data['${effectivePrefix}id_colaborador'],
      ),
      dataCompromisso: attachedDatabase.typeMapping.read(
        DriftSqlType.dateTime,
        data['${effectivePrefix}data_compromisso'],
      ),
      hora: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}hora'],
      ),
      duracao: attachedDatabase.typeMapping.read(
        DriftSqlType.int,
        data['${effectivePrefix}duracao'],
      ),
      tipo: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}tipo'],
      ),
      onde: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}onde'],
      ),
      descricao: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}descricao'],
      ),
    );
  }

  @override
  $AgendaCompromissosTable createAlias(String alias) {
    return $AgendaCompromissosTable(attachedDatabase, alias);
  }
}

class AgendaCompromisso extends DataClass
    implements Insertable<AgendaCompromisso> {
  final int? id;
  final int? idAgendaCategoriaCompromisso;
  final int? idColaborador;
  final DateTime? dataCompromisso;
  final String? hora;
  final int? duracao;
  final String? tipo;
  final String? onde;
  final String? descricao;
  const AgendaCompromisso({
    this.id,
    this.idAgendaCategoriaCompromisso,
    this.idColaborador,
    this.dataCompromisso,
    this.hora,
    this.duracao,
    this.tipo,
    this.onde,
    this.descricao,
  });
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || idAgendaCategoriaCompromisso != null) {
      map['id_agenda_categoria_compromisso'] = Variable<int>(
        idAgendaCategoriaCompromisso,
      );
    }
    if (!nullToAbsent || idColaborador != null) {
      map['id_colaborador'] = Variable<int>(idColaborador);
    }
    if (!nullToAbsent || dataCompromisso != null) {
      map['data_compromisso'] = Variable<DateTime>(dataCompromisso);
    }
    if (!nullToAbsent || hora != null) {
      map['hora'] = Variable<String>(hora);
    }
    if (!nullToAbsent || duracao != null) {
      map['duracao'] = Variable<int>(duracao);
    }
    if (!nullToAbsent || tipo != null) {
      map['tipo'] = Variable<String>(tipo);
    }
    if (!nullToAbsent || onde != null) {
      map['onde'] = Variable<String>(onde);
    }
    if (!nullToAbsent || descricao != null) {
      map['descricao'] = Variable<String>(descricao);
    }
    return map;
  }

  factory AgendaCompromisso.fromJson(
    Map<String, dynamic> json, {
    ValueSerializer? serializer,
  }) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return AgendaCompromisso(
      id: serializer.fromJson<int?>(json['id']),
      idAgendaCategoriaCompromisso: serializer.fromJson<int?>(
        json['idAgendaCategoriaCompromisso'],
      ),
      idColaborador: serializer.fromJson<int?>(json['idColaborador']),
      dataCompromisso: serializer.fromJson<DateTime?>(json['dataCompromisso']),
      hora: serializer.fromJson<String?>(json['hora']),
      duracao: serializer.fromJson<int?>(json['duracao']),
      tipo: serializer.fromJson<String?>(json['tipo']),
      onde: serializer.fromJson<String?>(json['onde']),
      descricao: serializer.fromJson<String?>(json['descricao']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'idAgendaCategoriaCompromisso': serializer.toJson<int?>(
        idAgendaCategoriaCompromisso,
      ),
      'idColaborador': serializer.toJson<int?>(idColaborador),
      'dataCompromisso': serializer.toJson<DateTime?>(dataCompromisso),
      'hora': serializer.toJson<String?>(hora),
      'duracao': serializer.toJson<int?>(duracao),
      'tipo': serializer.toJson<String?>(tipo),
      'onde': serializer.toJson<String?>(onde),
      'descricao': serializer.toJson<String?>(descricao),
    };
  }

  AgendaCompromisso copyWith({
    Value<int?> id = const Value.absent(),
    Value<int?> idAgendaCategoriaCompromisso = const Value.absent(),
    Value<int?> idColaborador = const Value.absent(),
    Value<DateTime?> dataCompromisso = const Value.absent(),
    Value<String?> hora = const Value.absent(),
    Value<int?> duracao = const Value.absent(),
    Value<String?> tipo = const Value.absent(),
    Value<String?> onde = const Value.absent(),
    Value<String?> descricao = const Value.absent(),
  }) => AgendaCompromisso(
    id: id.present ? id.value : this.id,
    idAgendaCategoriaCompromisso:
        idAgendaCategoriaCompromisso.present
            ? idAgendaCategoriaCompromisso.value
            : this.idAgendaCategoriaCompromisso,
    idColaborador:
        idColaborador.present ? idColaborador.value : this.idColaborador,
    dataCompromisso:
        dataCompromisso.present ? dataCompromisso.value : this.dataCompromisso,
    hora: hora.present ? hora.value : this.hora,
    duracao: duracao.present ? duracao.value : this.duracao,
    tipo: tipo.present ? tipo.value : this.tipo,
    onde: onde.present ? onde.value : this.onde,
    descricao: descricao.present ? descricao.value : this.descricao,
  );
  AgendaCompromisso copyWithCompanion(AgendaCompromissosCompanion data) {
    return AgendaCompromisso(
      id: data.id.present ? data.id.value : this.id,
      idAgendaCategoriaCompromisso:
          data.idAgendaCategoriaCompromisso.present
              ? data.idAgendaCategoriaCompromisso.value
              : this.idAgendaCategoriaCompromisso,
      idColaborador:
          data.idColaborador.present
              ? data.idColaborador.value
              : this.idColaborador,
      dataCompromisso:
          data.dataCompromisso.present
              ? data.dataCompromisso.value
              : this.dataCompromisso,
      hora: data.hora.present ? data.hora.value : this.hora,
      duracao: data.duracao.present ? data.duracao.value : this.duracao,
      tipo: data.tipo.present ? data.tipo.value : this.tipo,
      onde: data.onde.present ? data.onde.value : this.onde,
      descricao: data.descricao.present ? data.descricao.value : this.descricao,
    );
  }

  @override
  String toString() {
    return (StringBuffer('AgendaCompromisso(')
          ..write('id: $id, ')
          ..write(
            'idAgendaCategoriaCompromisso: $idAgendaCategoriaCompromisso, ',
          )
          ..write('idColaborador: $idColaborador, ')
          ..write('dataCompromisso: $dataCompromisso, ')
          ..write('hora: $hora, ')
          ..write('duracao: $duracao, ')
          ..write('tipo: $tipo, ')
          ..write('onde: $onde, ')
          ..write('descricao: $descricao')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(
    id,
    idAgendaCategoriaCompromisso,
    idColaborador,
    dataCompromisso,
    hora,
    duracao,
    tipo,
    onde,
    descricao,
  );
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is AgendaCompromisso &&
          other.id == this.id &&
          other.idAgendaCategoriaCompromisso ==
              this.idAgendaCategoriaCompromisso &&
          other.idColaborador == this.idColaborador &&
          other.dataCompromisso == this.dataCompromisso &&
          other.hora == this.hora &&
          other.duracao == this.duracao &&
          other.tipo == this.tipo &&
          other.onde == this.onde &&
          other.descricao == this.descricao);
}

class AgendaCompromissosCompanion extends UpdateCompanion<AgendaCompromisso> {
  final Value<int?> id;
  final Value<int?> idAgendaCategoriaCompromisso;
  final Value<int?> idColaborador;
  final Value<DateTime?> dataCompromisso;
  final Value<String?> hora;
  final Value<int?> duracao;
  final Value<String?> tipo;
  final Value<String?> onde;
  final Value<String?> descricao;
  const AgendaCompromissosCompanion({
    this.id = const Value.absent(),
    this.idAgendaCategoriaCompromisso = const Value.absent(),
    this.idColaborador = const Value.absent(),
    this.dataCompromisso = const Value.absent(),
    this.hora = const Value.absent(),
    this.duracao = const Value.absent(),
    this.tipo = const Value.absent(),
    this.onde = const Value.absent(),
    this.descricao = const Value.absent(),
  });
  AgendaCompromissosCompanion.insert({
    this.id = const Value.absent(),
    this.idAgendaCategoriaCompromisso = const Value.absent(),
    this.idColaborador = const Value.absent(),
    this.dataCompromisso = const Value.absent(),
    this.hora = const Value.absent(),
    this.duracao = const Value.absent(),
    this.tipo = const Value.absent(),
    this.onde = const Value.absent(),
    this.descricao = const Value.absent(),
  });
  static Insertable<AgendaCompromisso> custom({
    Expression<int>? id,
    Expression<int>? idAgendaCategoriaCompromisso,
    Expression<int>? idColaborador,
    Expression<DateTime>? dataCompromisso,
    Expression<String>? hora,
    Expression<int>? duracao,
    Expression<String>? tipo,
    Expression<String>? onde,
    Expression<String>? descricao,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (idAgendaCategoriaCompromisso != null)
        'id_agenda_categoria_compromisso': idAgendaCategoriaCompromisso,
      if (idColaborador != null) 'id_colaborador': idColaborador,
      if (dataCompromisso != null) 'data_compromisso': dataCompromisso,
      if (hora != null) 'hora': hora,
      if (duracao != null) 'duracao': duracao,
      if (tipo != null) 'tipo': tipo,
      if (onde != null) 'onde': onde,
      if (descricao != null) 'descricao': descricao,
    });
  }

  AgendaCompromissosCompanion copyWith({
    Value<int?>? id,
    Value<int?>? idAgendaCategoriaCompromisso,
    Value<int?>? idColaborador,
    Value<DateTime?>? dataCompromisso,
    Value<String?>? hora,
    Value<int?>? duracao,
    Value<String?>? tipo,
    Value<String?>? onde,
    Value<String?>? descricao,
  }) {
    return AgendaCompromissosCompanion(
      id: id ?? this.id,
      idAgendaCategoriaCompromisso:
          idAgendaCategoriaCompromisso ?? this.idAgendaCategoriaCompromisso,
      idColaborador: idColaborador ?? this.idColaborador,
      dataCompromisso: dataCompromisso ?? this.dataCompromisso,
      hora: hora ?? this.hora,
      duracao: duracao ?? this.duracao,
      tipo: tipo ?? this.tipo,
      onde: onde ?? this.onde,
      descricao: descricao ?? this.descricao,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (idAgendaCategoriaCompromisso.present) {
      map['id_agenda_categoria_compromisso'] = Variable<int>(
        idAgendaCategoriaCompromisso.value,
      );
    }
    if (idColaborador.present) {
      map['id_colaborador'] = Variable<int>(idColaborador.value);
    }
    if (dataCompromisso.present) {
      map['data_compromisso'] = Variable<DateTime>(dataCompromisso.value);
    }
    if (hora.present) {
      map['hora'] = Variable<String>(hora.value);
    }
    if (duracao.present) {
      map['duracao'] = Variable<int>(duracao.value);
    }
    if (tipo.present) {
      map['tipo'] = Variable<String>(tipo.value);
    }
    if (onde.present) {
      map['onde'] = Variable<String>(onde.value);
    }
    if (descricao.present) {
      map['descricao'] = Variable<String>(descricao.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('AgendaCompromissosCompanion(')
          ..write('id: $id, ')
          ..write(
            'idAgendaCategoriaCompromisso: $idAgendaCategoriaCompromisso, ',
          )
          ..write('idColaborador: $idColaborador, ')
          ..write('dataCompromisso: $dataCompromisso, ')
          ..write('hora: $hora, ')
          ..write('duracao: $duracao, ')
          ..write('tipo: $tipo, ')
          ..write('onde: $onde, ')
          ..write('descricao: $descricao')
          ..write(')'))
        .toString();
  }
}

class $RecadoRemetentesTable extends RecadoRemetentes
    with TableInfo<$RecadoRemetentesTable, RecadoRemetente> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $RecadoRemetentesTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
    'id',
    aliasedName,
    true,
    type: DriftSqlType.int,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _idColaboradorMeta = const VerificationMeta(
    'idColaborador',
  );
  @override
  late final GeneratedColumn<int> idColaborador = GeneratedColumn<int>(
    'id_colaborador',
    aliasedName,
    true,
    type: DriftSqlType.int,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _dataEnvioMeta = const VerificationMeta(
    'dataEnvio',
  );
  @override
  late final GeneratedColumn<DateTime> dataEnvio = GeneratedColumn<DateTime>(
    'data_envio',
    aliasedName,
    true,
    type: DriftSqlType.dateTime,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _horaEnvioMeta = const VerificationMeta(
    'horaEnvio',
  );
  @override
  late final GeneratedColumn<String> horaEnvio = GeneratedColumn<String>(
    'hora_envio',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 8,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _assuntoMeta = const VerificationMeta(
    'assunto',
  );
  @override
  late final GeneratedColumn<String> assunto = GeneratedColumn<String>(
    'assunto',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 100,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _textoMeta = const VerificationMeta('texto');
  @override
  late final GeneratedColumn<String> texto = GeneratedColumn<String>(
    'texto',
    aliasedName,
    true,
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  @override
  List<GeneratedColumn> get $columns => [
    id,
    idColaborador,
    dataEnvio,
    horaEnvio,
    assunto,
    texto,
  ];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'recado_remetente';
  @override
  VerificationContext validateIntegrity(
    Insertable<RecadoRemetente> instance, {
    bool isInserting = false,
  }) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('id_colaborador')) {
      context.handle(
        _idColaboradorMeta,
        idColaborador.isAcceptableOrUnknown(
          data['id_colaborador']!,
          _idColaboradorMeta,
        ),
      );
    }
    if (data.containsKey('data_envio')) {
      context.handle(
        _dataEnvioMeta,
        dataEnvio.isAcceptableOrUnknown(data['data_envio']!, _dataEnvioMeta),
      );
    }
    if (data.containsKey('hora_envio')) {
      context.handle(
        _horaEnvioMeta,
        horaEnvio.isAcceptableOrUnknown(data['hora_envio']!, _horaEnvioMeta),
      );
    }
    if (data.containsKey('assunto')) {
      context.handle(
        _assuntoMeta,
        assunto.isAcceptableOrUnknown(data['assunto']!, _assuntoMeta),
      );
    }
    if (data.containsKey('texto')) {
      context.handle(
        _textoMeta,
        texto.isAcceptableOrUnknown(data['texto']!, _textoMeta),
      );
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  RecadoRemetente map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return RecadoRemetente(
      id: attachedDatabase.typeMapping.read(
        DriftSqlType.int,
        data['${effectivePrefix}id'],
      ),
      idColaborador: attachedDatabase.typeMapping.read(
        DriftSqlType.int,
        data['${effectivePrefix}id_colaborador'],
      ),
      dataEnvio: attachedDatabase.typeMapping.read(
        DriftSqlType.dateTime,
        data['${effectivePrefix}data_envio'],
      ),
      horaEnvio: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}hora_envio'],
      ),
      assunto: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}assunto'],
      ),
      texto: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}texto'],
      ),
    );
  }

  @override
  $RecadoRemetentesTable createAlias(String alias) {
    return $RecadoRemetentesTable(attachedDatabase, alias);
  }
}

class RecadoRemetente extends DataClass implements Insertable<RecadoRemetente> {
  final int? id;
  final int? idColaborador;
  final DateTime? dataEnvio;
  final String? horaEnvio;
  final String? assunto;
  final String? texto;
  const RecadoRemetente({
    this.id,
    this.idColaborador,
    this.dataEnvio,
    this.horaEnvio,
    this.assunto,
    this.texto,
  });
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || idColaborador != null) {
      map['id_colaborador'] = Variable<int>(idColaborador);
    }
    if (!nullToAbsent || dataEnvio != null) {
      map['data_envio'] = Variable<DateTime>(dataEnvio);
    }
    if (!nullToAbsent || horaEnvio != null) {
      map['hora_envio'] = Variable<String>(horaEnvio);
    }
    if (!nullToAbsent || assunto != null) {
      map['assunto'] = Variable<String>(assunto);
    }
    if (!nullToAbsent || texto != null) {
      map['texto'] = Variable<String>(texto);
    }
    return map;
  }

  factory RecadoRemetente.fromJson(
    Map<String, dynamic> json, {
    ValueSerializer? serializer,
  }) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return RecadoRemetente(
      id: serializer.fromJson<int?>(json['id']),
      idColaborador: serializer.fromJson<int?>(json['idColaborador']),
      dataEnvio: serializer.fromJson<DateTime?>(json['dataEnvio']),
      horaEnvio: serializer.fromJson<String?>(json['horaEnvio']),
      assunto: serializer.fromJson<String?>(json['assunto']),
      texto: serializer.fromJson<String?>(json['texto']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'idColaborador': serializer.toJson<int?>(idColaborador),
      'dataEnvio': serializer.toJson<DateTime?>(dataEnvio),
      'horaEnvio': serializer.toJson<String?>(horaEnvio),
      'assunto': serializer.toJson<String?>(assunto),
      'texto': serializer.toJson<String?>(texto),
    };
  }

  RecadoRemetente copyWith({
    Value<int?> id = const Value.absent(),
    Value<int?> idColaborador = const Value.absent(),
    Value<DateTime?> dataEnvio = const Value.absent(),
    Value<String?> horaEnvio = const Value.absent(),
    Value<String?> assunto = const Value.absent(),
    Value<String?> texto = const Value.absent(),
  }) => RecadoRemetente(
    id: id.present ? id.value : this.id,
    idColaborador:
        idColaborador.present ? idColaborador.value : this.idColaborador,
    dataEnvio: dataEnvio.present ? dataEnvio.value : this.dataEnvio,
    horaEnvio: horaEnvio.present ? horaEnvio.value : this.horaEnvio,
    assunto: assunto.present ? assunto.value : this.assunto,
    texto: texto.present ? texto.value : this.texto,
  );
  RecadoRemetente copyWithCompanion(RecadoRemetentesCompanion data) {
    return RecadoRemetente(
      id: data.id.present ? data.id.value : this.id,
      idColaborador:
          data.idColaborador.present
              ? data.idColaborador.value
              : this.idColaborador,
      dataEnvio: data.dataEnvio.present ? data.dataEnvio.value : this.dataEnvio,
      horaEnvio: data.horaEnvio.present ? data.horaEnvio.value : this.horaEnvio,
      assunto: data.assunto.present ? data.assunto.value : this.assunto,
      texto: data.texto.present ? data.texto.value : this.texto,
    );
  }

  @override
  String toString() {
    return (StringBuffer('RecadoRemetente(')
          ..write('id: $id, ')
          ..write('idColaborador: $idColaborador, ')
          ..write('dataEnvio: $dataEnvio, ')
          ..write('horaEnvio: $horaEnvio, ')
          ..write('assunto: $assunto, ')
          ..write('texto: $texto')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode =>
      Object.hash(id, idColaborador, dataEnvio, horaEnvio, assunto, texto);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is RecadoRemetente &&
          other.id == this.id &&
          other.idColaborador == this.idColaborador &&
          other.dataEnvio == this.dataEnvio &&
          other.horaEnvio == this.horaEnvio &&
          other.assunto == this.assunto &&
          other.texto == this.texto);
}

class RecadoRemetentesCompanion extends UpdateCompanion<RecadoRemetente> {
  final Value<int?> id;
  final Value<int?> idColaborador;
  final Value<DateTime?> dataEnvio;
  final Value<String?> horaEnvio;
  final Value<String?> assunto;
  final Value<String?> texto;
  const RecadoRemetentesCompanion({
    this.id = const Value.absent(),
    this.idColaborador = const Value.absent(),
    this.dataEnvio = const Value.absent(),
    this.horaEnvio = const Value.absent(),
    this.assunto = const Value.absent(),
    this.texto = const Value.absent(),
  });
  RecadoRemetentesCompanion.insert({
    this.id = const Value.absent(),
    this.idColaborador = const Value.absent(),
    this.dataEnvio = const Value.absent(),
    this.horaEnvio = const Value.absent(),
    this.assunto = const Value.absent(),
    this.texto = const Value.absent(),
  });
  static Insertable<RecadoRemetente> custom({
    Expression<int>? id,
    Expression<int>? idColaborador,
    Expression<DateTime>? dataEnvio,
    Expression<String>? horaEnvio,
    Expression<String>? assunto,
    Expression<String>? texto,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (idColaborador != null) 'id_colaborador': idColaborador,
      if (dataEnvio != null) 'data_envio': dataEnvio,
      if (horaEnvio != null) 'hora_envio': horaEnvio,
      if (assunto != null) 'assunto': assunto,
      if (texto != null) 'texto': texto,
    });
  }

  RecadoRemetentesCompanion copyWith({
    Value<int?>? id,
    Value<int?>? idColaborador,
    Value<DateTime?>? dataEnvio,
    Value<String?>? horaEnvio,
    Value<String?>? assunto,
    Value<String?>? texto,
  }) {
    return RecadoRemetentesCompanion(
      id: id ?? this.id,
      idColaborador: idColaborador ?? this.idColaborador,
      dataEnvio: dataEnvio ?? this.dataEnvio,
      horaEnvio: horaEnvio ?? this.horaEnvio,
      assunto: assunto ?? this.assunto,
      texto: texto ?? this.texto,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (idColaborador.present) {
      map['id_colaborador'] = Variable<int>(idColaborador.value);
    }
    if (dataEnvio.present) {
      map['data_envio'] = Variable<DateTime>(dataEnvio.value);
    }
    if (horaEnvio.present) {
      map['hora_envio'] = Variable<String>(horaEnvio.value);
    }
    if (assunto.present) {
      map['assunto'] = Variable<String>(assunto.value);
    }
    if (texto.present) {
      map['texto'] = Variable<String>(texto.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('RecadoRemetentesCompanion(')
          ..write('id: $id, ')
          ..write('idColaborador: $idColaborador, ')
          ..write('dataEnvio: $dataEnvio, ')
          ..write('horaEnvio: $horaEnvio, ')
          ..write('assunto: $assunto, ')
          ..write('texto: $texto')
          ..write(')'))
        .toString();
  }
}

class $AgendaCategoriaCompromissosTable extends AgendaCategoriaCompromissos
    with
        TableInfo<
          $AgendaCategoriaCompromissosTable,
          AgendaCategoriaCompromisso
        > {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $AgendaCategoriaCompromissosTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
    'id',
    aliasedName,
    true,
    type: DriftSqlType.int,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _nomeMeta = const VerificationMeta('nome');
  @override
  late final GeneratedColumn<String> nome = GeneratedColumn<String>(
    'nome',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 100,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _corMeta = const VerificationMeta('cor');
  @override
  late final GeneratedColumn<String> cor = GeneratedColumn<String>(
    'cor',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 50,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  @override
  List<GeneratedColumn> get $columns => [id, nome, cor];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'agenda_categoria_compromisso';
  @override
  VerificationContext validateIntegrity(
    Insertable<AgendaCategoriaCompromisso> instance, {
    bool isInserting = false,
  }) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('nome')) {
      context.handle(
        _nomeMeta,
        nome.isAcceptableOrUnknown(data['nome']!, _nomeMeta),
      );
    }
    if (data.containsKey('cor')) {
      context.handle(
        _corMeta,
        cor.isAcceptableOrUnknown(data['cor']!, _corMeta),
      );
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  AgendaCategoriaCompromisso map(
    Map<String, dynamic> data, {
    String? tablePrefix,
  }) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return AgendaCategoriaCompromisso(
      id: attachedDatabase.typeMapping.read(
        DriftSqlType.int,
        data['${effectivePrefix}id'],
      ),
      nome: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}nome'],
      ),
      cor: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}cor'],
      ),
    );
  }

  @override
  $AgendaCategoriaCompromissosTable createAlias(String alias) {
    return $AgendaCategoriaCompromissosTable(attachedDatabase, alias);
  }
}

class AgendaCategoriaCompromisso extends DataClass
    implements Insertable<AgendaCategoriaCompromisso> {
  final int? id;
  final String? nome;
  final String? cor;
  const AgendaCategoriaCompromisso({this.id, this.nome, this.cor});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || nome != null) {
      map['nome'] = Variable<String>(nome);
    }
    if (!nullToAbsent || cor != null) {
      map['cor'] = Variable<String>(cor);
    }
    return map;
  }

  factory AgendaCategoriaCompromisso.fromJson(
    Map<String, dynamic> json, {
    ValueSerializer? serializer,
  }) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return AgendaCategoriaCompromisso(
      id: serializer.fromJson<int?>(json['id']),
      nome: serializer.fromJson<String?>(json['nome']),
      cor: serializer.fromJson<String?>(json['cor']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'nome': serializer.toJson<String?>(nome),
      'cor': serializer.toJson<String?>(cor),
    };
  }

  AgendaCategoriaCompromisso copyWith({
    Value<int?> id = const Value.absent(),
    Value<String?> nome = const Value.absent(),
    Value<String?> cor = const Value.absent(),
  }) => AgendaCategoriaCompromisso(
    id: id.present ? id.value : this.id,
    nome: nome.present ? nome.value : this.nome,
    cor: cor.present ? cor.value : this.cor,
  );
  AgendaCategoriaCompromisso copyWithCompanion(
    AgendaCategoriaCompromissosCompanion data,
  ) {
    return AgendaCategoriaCompromisso(
      id: data.id.present ? data.id.value : this.id,
      nome: data.nome.present ? data.nome.value : this.nome,
      cor: data.cor.present ? data.cor.value : this.cor,
    );
  }

  @override
  String toString() {
    return (StringBuffer('AgendaCategoriaCompromisso(')
          ..write('id: $id, ')
          ..write('nome: $nome, ')
          ..write('cor: $cor')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(id, nome, cor);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is AgendaCategoriaCompromisso &&
          other.id == this.id &&
          other.nome == this.nome &&
          other.cor == this.cor);
}

class AgendaCategoriaCompromissosCompanion
    extends UpdateCompanion<AgendaCategoriaCompromisso> {
  final Value<int?> id;
  final Value<String?> nome;
  final Value<String?> cor;
  const AgendaCategoriaCompromissosCompanion({
    this.id = const Value.absent(),
    this.nome = const Value.absent(),
    this.cor = const Value.absent(),
  });
  AgendaCategoriaCompromissosCompanion.insert({
    this.id = const Value.absent(),
    this.nome = const Value.absent(),
    this.cor = const Value.absent(),
  });
  static Insertable<AgendaCategoriaCompromisso> custom({
    Expression<int>? id,
    Expression<String>? nome,
    Expression<String>? cor,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (nome != null) 'nome': nome,
      if (cor != null) 'cor': cor,
    });
  }

  AgendaCategoriaCompromissosCompanion copyWith({
    Value<int?>? id,
    Value<String?>? nome,
    Value<String?>? cor,
  }) {
    return AgendaCategoriaCompromissosCompanion(
      id: id ?? this.id,
      nome: nome ?? this.nome,
      cor: cor ?? this.cor,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (nome.present) {
      map['nome'] = Variable<String>(nome.value);
    }
    if (cor.present) {
      map['cor'] = Variable<String>(cor.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('AgendaCategoriaCompromissosCompanion(')
          ..write('id: $id, ')
          ..write('nome: $nome, ')
          ..write('cor: $cor')
          ..write(')'))
        .toString();
  }
}

class $ReuniaoSalasTable extends ReuniaoSalas
    with TableInfo<$ReuniaoSalasTable, ReuniaoSala> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $ReuniaoSalasTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
    'id',
    aliasedName,
    true,
    type: DriftSqlType.int,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _predioMeta = const VerificationMeta('predio');
  @override
  late final GeneratedColumn<String> predio = GeneratedColumn<String>(
    'predio',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 100,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _nomeMeta = const VerificationMeta('nome');
  @override
  late final GeneratedColumn<String> nome = GeneratedColumn<String>(
    'nome',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 100,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _andarMeta = const VerificationMeta('andar');
  @override
  late final GeneratedColumn<String> andar = GeneratedColumn<String>(
    'andar',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 10,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _numeroMeta = const VerificationMeta('numero');
  @override
  late final GeneratedColumn<String> numero = GeneratedColumn<String>(
    'numero',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 10,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  @override
  List<GeneratedColumn> get $columns => [id, predio, nome, andar, numero];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'reuniao_sala';
  @override
  VerificationContext validateIntegrity(
    Insertable<ReuniaoSala> instance, {
    bool isInserting = false,
  }) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('predio')) {
      context.handle(
        _predioMeta,
        predio.isAcceptableOrUnknown(data['predio']!, _predioMeta),
      );
    }
    if (data.containsKey('nome')) {
      context.handle(
        _nomeMeta,
        nome.isAcceptableOrUnknown(data['nome']!, _nomeMeta),
      );
    }
    if (data.containsKey('andar')) {
      context.handle(
        _andarMeta,
        andar.isAcceptableOrUnknown(data['andar']!, _andarMeta),
      );
    }
    if (data.containsKey('numero')) {
      context.handle(
        _numeroMeta,
        numero.isAcceptableOrUnknown(data['numero']!, _numeroMeta),
      );
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  ReuniaoSala map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return ReuniaoSala(
      id: attachedDatabase.typeMapping.read(
        DriftSqlType.int,
        data['${effectivePrefix}id'],
      ),
      predio: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}predio'],
      ),
      nome: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}nome'],
      ),
      andar: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}andar'],
      ),
      numero: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}numero'],
      ),
    );
  }

  @override
  $ReuniaoSalasTable createAlias(String alias) {
    return $ReuniaoSalasTable(attachedDatabase, alias);
  }
}

class ReuniaoSala extends DataClass implements Insertable<ReuniaoSala> {
  final int? id;
  final String? predio;
  final String? nome;
  final String? andar;
  final String? numero;
  const ReuniaoSala({this.id, this.predio, this.nome, this.andar, this.numero});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || predio != null) {
      map['predio'] = Variable<String>(predio);
    }
    if (!nullToAbsent || nome != null) {
      map['nome'] = Variable<String>(nome);
    }
    if (!nullToAbsent || andar != null) {
      map['andar'] = Variable<String>(andar);
    }
    if (!nullToAbsent || numero != null) {
      map['numero'] = Variable<String>(numero);
    }
    return map;
  }

  factory ReuniaoSala.fromJson(
    Map<String, dynamic> json, {
    ValueSerializer? serializer,
  }) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return ReuniaoSala(
      id: serializer.fromJson<int?>(json['id']),
      predio: serializer.fromJson<String?>(json['predio']),
      nome: serializer.fromJson<String?>(json['nome']),
      andar: serializer.fromJson<String?>(json['andar']),
      numero: serializer.fromJson<String?>(json['numero']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'predio': serializer.toJson<String?>(predio),
      'nome': serializer.toJson<String?>(nome),
      'andar': serializer.toJson<String?>(andar),
      'numero': serializer.toJson<String?>(numero),
    };
  }

  ReuniaoSala copyWith({
    Value<int?> id = const Value.absent(),
    Value<String?> predio = const Value.absent(),
    Value<String?> nome = const Value.absent(),
    Value<String?> andar = const Value.absent(),
    Value<String?> numero = const Value.absent(),
  }) => ReuniaoSala(
    id: id.present ? id.value : this.id,
    predio: predio.present ? predio.value : this.predio,
    nome: nome.present ? nome.value : this.nome,
    andar: andar.present ? andar.value : this.andar,
    numero: numero.present ? numero.value : this.numero,
  );
  ReuniaoSala copyWithCompanion(ReuniaoSalasCompanion data) {
    return ReuniaoSala(
      id: data.id.present ? data.id.value : this.id,
      predio: data.predio.present ? data.predio.value : this.predio,
      nome: data.nome.present ? data.nome.value : this.nome,
      andar: data.andar.present ? data.andar.value : this.andar,
      numero: data.numero.present ? data.numero.value : this.numero,
    );
  }

  @override
  String toString() {
    return (StringBuffer('ReuniaoSala(')
          ..write('id: $id, ')
          ..write('predio: $predio, ')
          ..write('nome: $nome, ')
          ..write('andar: $andar, ')
          ..write('numero: $numero')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(id, predio, nome, andar, numero);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is ReuniaoSala &&
          other.id == this.id &&
          other.predio == this.predio &&
          other.nome == this.nome &&
          other.andar == this.andar &&
          other.numero == this.numero);
}

class ReuniaoSalasCompanion extends UpdateCompanion<ReuniaoSala> {
  final Value<int?> id;
  final Value<String?> predio;
  final Value<String?> nome;
  final Value<String?> andar;
  final Value<String?> numero;
  const ReuniaoSalasCompanion({
    this.id = const Value.absent(),
    this.predio = const Value.absent(),
    this.nome = const Value.absent(),
    this.andar = const Value.absent(),
    this.numero = const Value.absent(),
  });
  ReuniaoSalasCompanion.insert({
    this.id = const Value.absent(),
    this.predio = const Value.absent(),
    this.nome = const Value.absent(),
    this.andar = const Value.absent(),
    this.numero = const Value.absent(),
  });
  static Insertable<ReuniaoSala> custom({
    Expression<int>? id,
    Expression<String>? predio,
    Expression<String>? nome,
    Expression<String>? andar,
    Expression<String>? numero,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (predio != null) 'predio': predio,
      if (nome != null) 'nome': nome,
      if (andar != null) 'andar': andar,
      if (numero != null) 'numero': numero,
    });
  }

  ReuniaoSalasCompanion copyWith({
    Value<int?>? id,
    Value<String?>? predio,
    Value<String?>? nome,
    Value<String?>? andar,
    Value<String?>? numero,
  }) {
    return ReuniaoSalasCompanion(
      id: id ?? this.id,
      predio: predio ?? this.predio,
      nome: nome ?? this.nome,
      andar: andar ?? this.andar,
      numero: numero ?? this.numero,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (predio.present) {
      map['predio'] = Variable<String>(predio.value);
    }
    if (nome.present) {
      map['nome'] = Variable<String>(nome.value);
    }
    if (andar.present) {
      map['andar'] = Variable<String>(andar.value);
    }
    if (numero.present) {
      map['numero'] = Variable<String>(numero.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('ReuniaoSalasCompanion(')
          ..write('id: $id, ')
          ..write('predio: $predio, ')
          ..write('nome: $nome, ')
          ..write('andar: $andar, ')
          ..write('numero: $numero')
          ..write(')'))
        .toString();
  }
}

class $ViewControleAcessosTable extends ViewControleAcessos
    with TableInfo<$ViewControleAcessosTable, ViewControleAcesso> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $ViewControleAcessosTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
    'id',
    aliasedName,
    true,
    type: DriftSqlType.int,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _idPessoaMeta = const VerificationMeta(
    'idPessoa',
  );
  @override
  late final GeneratedColumn<int> idPessoa = GeneratedColumn<int>(
    'id_pessoa',
    aliasedName,
    true,
    type: DriftSqlType.int,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _pessoaNomeMeta = const VerificationMeta(
    'pessoaNome',
  );
  @override
  late final GeneratedColumn<String> pessoaNome = GeneratedColumn<String>(
    'pessoa_nome',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 450,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _idColaboradorMeta = const VerificationMeta(
    'idColaborador',
  );
  @override
  late final GeneratedColumn<int> idColaborador = GeneratedColumn<int>(
    'id_colaborador',
    aliasedName,
    true,
    type: DriftSqlType.int,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _idUsuarioMeta = const VerificationMeta(
    'idUsuario',
  );
  @override
  late final GeneratedColumn<int> idUsuario = GeneratedColumn<int>(
    'id_usuario',
    aliasedName,
    true,
    type: DriftSqlType.int,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _administradorMeta = const VerificationMeta(
    'administrador',
  );
  @override
  late final GeneratedColumn<String> administrador = GeneratedColumn<String>(
    'administrador',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 3,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _idPapelMeta = const VerificationMeta(
    'idPapel',
  );
  @override
  late final GeneratedColumn<int> idPapel = GeneratedColumn<int>(
    'id_papel',
    aliasedName,
    true,
    type: DriftSqlType.int,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _papelNomeMeta = const VerificationMeta(
    'papelNome',
  );
  @override
  late final GeneratedColumn<String> papelNome = GeneratedColumn<String>(
    'papel_nome',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 300,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _papelDescricaoMeta = const VerificationMeta(
    'papelDescricao',
  );
  @override
  late final GeneratedColumn<String> papelDescricao = GeneratedColumn<String>(
    'papel_descricao',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 750,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _idFuncaoMeta = const VerificationMeta(
    'idFuncao',
  );
  @override
  late final GeneratedColumn<int> idFuncao = GeneratedColumn<int>(
    'id_funcao',
    aliasedName,
    true,
    type: DriftSqlType.int,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _funcaoNomeMeta = const VerificationMeta(
    'funcaoNome',
  );
  @override
  late final GeneratedColumn<String> funcaoNome = GeneratedColumn<String>(
    'funcao_nome',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 300,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _funcaoDescricaoMeta = const VerificationMeta(
    'funcaoDescricao',
  );
  @override
  late final GeneratedColumn<String> funcaoDescricao = GeneratedColumn<String>(
    'funcao_descricao',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 750,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _idPapelFuncaoMeta = const VerificationMeta(
    'idPapelFuncao',
  );
  @override
  late final GeneratedColumn<int> idPapelFuncao = GeneratedColumn<int>(
    'id_papel_funcao',
    aliasedName,
    true,
    type: DriftSqlType.int,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _habilitadoMeta = const VerificationMeta(
    'habilitado',
  );
  @override
  late final GeneratedColumn<String> habilitado = GeneratedColumn<String>(
    'habilitado',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 3,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _podeInserirMeta = const VerificationMeta(
    'podeInserir',
  );
  @override
  late final GeneratedColumn<String> podeInserir = GeneratedColumn<String>(
    'pode_inserir',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 3,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _podeAlterarMeta = const VerificationMeta(
    'podeAlterar',
  );
  @override
  late final GeneratedColumn<String> podeAlterar = GeneratedColumn<String>(
    'pode_alterar',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 3,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _podeExcluirMeta = const VerificationMeta(
    'podeExcluir',
  );
  @override
  late final GeneratedColumn<String> podeExcluir = GeneratedColumn<String>(
    'pode_excluir',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 3,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  @override
  List<GeneratedColumn> get $columns => [
    id,
    idPessoa,
    pessoaNome,
    idColaborador,
    idUsuario,
    administrador,
    idPapel,
    papelNome,
    papelDescricao,
    idFuncao,
    funcaoNome,
    funcaoDescricao,
    idPapelFuncao,
    habilitado,
    podeInserir,
    podeAlterar,
    podeExcluir,
  ];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'view_controle_acesso';
  @override
  VerificationContext validateIntegrity(
    Insertable<ViewControleAcesso> instance, {
    bool isInserting = false,
  }) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('id_pessoa')) {
      context.handle(
        _idPessoaMeta,
        idPessoa.isAcceptableOrUnknown(data['id_pessoa']!, _idPessoaMeta),
      );
    }
    if (data.containsKey('pessoa_nome')) {
      context.handle(
        _pessoaNomeMeta,
        pessoaNome.isAcceptableOrUnknown(data['pessoa_nome']!, _pessoaNomeMeta),
      );
    }
    if (data.containsKey('id_colaborador')) {
      context.handle(
        _idColaboradorMeta,
        idColaborador.isAcceptableOrUnknown(
          data['id_colaborador']!,
          _idColaboradorMeta,
        ),
      );
    }
    if (data.containsKey('id_usuario')) {
      context.handle(
        _idUsuarioMeta,
        idUsuario.isAcceptableOrUnknown(data['id_usuario']!, _idUsuarioMeta),
      );
    }
    if (data.containsKey('administrador')) {
      context.handle(
        _administradorMeta,
        administrador.isAcceptableOrUnknown(
          data['administrador']!,
          _administradorMeta,
        ),
      );
    }
    if (data.containsKey('id_papel')) {
      context.handle(
        _idPapelMeta,
        idPapel.isAcceptableOrUnknown(data['id_papel']!, _idPapelMeta),
      );
    }
    if (data.containsKey('papel_nome')) {
      context.handle(
        _papelNomeMeta,
        papelNome.isAcceptableOrUnknown(data['papel_nome']!, _papelNomeMeta),
      );
    }
    if (data.containsKey('papel_descricao')) {
      context.handle(
        _papelDescricaoMeta,
        papelDescricao.isAcceptableOrUnknown(
          data['papel_descricao']!,
          _papelDescricaoMeta,
        ),
      );
    }
    if (data.containsKey('id_funcao')) {
      context.handle(
        _idFuncaoMeta,
        idFuncao.isAcceptableOrUnknown(data['id_funcao']!, _idFuncaoMeta),
      );
    }
    if (data.containsKey('funcao_nome')) {
      context.handle(
        _funcaoNomeMeta,
        funcaoNome.isAcceptableOrUnknown(data['funcao_nome']!, _funcaoNomeMeta),
      );
    }
    if (data.containsKey('funcao_descricao')) {
      context.handle(
        _funcaoDescricaoMeta,
        funcaoDescricao.isAcceptableOrUnknown(
          data['funcao_descricao']!,
          _funcaoDescricaoMeta,
        ),
      );
    }
    if (data.containsKey('id_papel_funcao')) {
      context.handle(
        _idPapelFuncaoMeta,
        idPapelFuncao.isAcceptableOrUnknown(
          data['id_papel_funcao']!,
          _idPapelFuncaoMeta,
        ),
      );
    }
    if (data.containsKey('habilitado')) {
      context.handle(
        _habilitadoMeta,
        habilitado.isAcceptableOrUnknown(data['habilitado']!, _habilitadoMeta),
      );
    }
    if (data.containsKey('pode_inserir')) {
      context.handle(
        _podeInserirMeta,
        podeInserir.isAcceptableOrUnknown(
          data['pode_inserir']!,
          _podeInserirMeta,
        ),
      );
    }
    if (data.containsKey('pode_alterar')) {
      context.handle(
        _podeAlterarMeta,
        podeAlterar.isAcceptableOrUnknown(
          data['pode_alterar']!,
          _podeAlterarMeta,
        ),
      );
    }
    if (data.containsKey('pode_excluir')) {
      context.handle(
        _podeExcluirMeta,
        podeExcluir.isAcceptableOrUnknown(
          data['pode_excluir']!,
          _podeExcluirMeta,
        ),
      );
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  ViewControleAcesso map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return ViewControleAcesso(
      id: attachedDatabase.typeMapping.read(
        DriftSqlType.int,
        data['${effectivePrefix}id'],
      ),
      idPessoa: attachedDatabase.typeMapping.read(
        DriftSqlType.int,
        data['${effectivePrefix}id_pessoa'],
      ),
      pessoaNome: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}pessoa_nome'],
      ),
      idColaborador: attachedDatabase.typeMapping.read(
        DriftSqlType.int,
        data['${effectivePrefix}id_colaborador'],
      ),
      idUsuario: attachedDatabase.typeMapping.read(
        DriftSqlType.int,
        data['${effectivePrefix}id_usuario'],
      ),
      administrador: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}administrador'],
      ),
      idPapel: attachedDatabase.typeMapping.read(
        DriftSqlType.int,
        data['${effectivePrefix}id_papel'],
      ),
      papelNome: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}papel_nome'],
      ),
      papelDescricao: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}papel_descricao'],
      ),
      idFuncao: attachedDatabase.typeMapping.read(
        DriftSqlType.int,
        data['${effectivePrefix}id_funcao'],
      ),
      funcaoNome: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}funcao_nome'],
      ),
      funcaoDescricao: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}funcao_descricao'],
      ),
      idPapelFuncao: attachedDatabase.typeMapping.read(
        DriftSqlType.int,
        data['${effectivePrefix}id_papel_funcao'],
      ),
      habilitado: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}habilitado'],
      ),
      podeInserir: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}pode_inserir'],
      ),
      podeAlterar: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}pode_alterar'],
      ),
      podeExcluir: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}pode_excluir'],
      ),
    );
  }

  @override
  $ViewControleAcessosTable createAlias(String alias) {
    return $ViewControleAcessosTable(attachedDatabase, alias);
  }
}

class ViewControleAcesso extends DataClass
    implements Insertable<ViewControleAcesso> {
  final int? id;
  final int? idPessoa;
  final String? pessoaNome;
  final int? idColaborador;
  final int? idUsuario;
  final String? administrador;
  final int? idPapel;
  final String? papelNome;
  final String? papelDescricao;
  final int? idFuncao;
  final String? funcaoNome;
  final String? funcaoDescricao;
  final int? idPapelFuncao;
  final String? habilitado;
  final String? podeInserir;
  final String? podeAlterar;
  final String? podeExcluir;
  const ViewControleAcesso({
    this.id,
    this.idPessoa,
    this.pessoaNome,
    this.idColaborador,
    this.idUsuario,
    this.administrador,
    this.idPapel,
    this.papelNome,
    this.papelDescricao,
    this.idFuncao,
    this.funcaoNome,
    this.funcaoDescricao,
    this.idPapelFuncao,
    this.habilitado,
    this.podeInserir,
    this.podeAlterar,
    this.podeExcluir,
  });
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || idPessoa != null) {
      map['id_pessoa'] = Variable<int>(idPessoa);
    }
    if (!nullToAbsent || pessoaNome != null) {
      map['pessoa_nome'] = Variable<String>(pessoaNome);
    }
    if (!nullToAbsent || idColaborador != null) {
      map['id_colaborador'] = Variable<int>(idColaborador);
    }
    if (!nullToAbsent || idUsuario != null) {
      map['id_usuario'] = Variable<int>(idUsuario);
    }
    if (!nullToAbsent || administrador != null) {
      map['administrador'] = Variable<String>(administrador);
    }
    if (!nullToAbsent || idPapel != null) {
      map['id_papel'] = Variable<int>(idPapel);
    }
    if (!nullToAbsent || papelNome != null) {
      map['papel_nome'] = Variable<String>(papelNome);
    }
    if (!nullToAbsent || papelDescricao != null) {
      map['papel_descricao'] = Variable<String>(papelDescricao);
    }
    if (!nullToAbsent || idFuncao != null) {
      map['id_funcao'] = Variable<int>(idFuncao);
    }
    if (!nullToAbsent || funcaoNome != null) {
      map['funcao_nome'] = Variable<String>(funcaoNome);
    }
    if (!nullToAbsent || funcaoDescricao != null) {
      map['funcao_descricao'] = Variable<String>(funcaoDescricao);
    }
    if (!nullToAbsent || idPapelFuncao != null) {
      map['id_papel_funcao'] = Variable<int>(idPapelFuncao);
    }
    if (!nullToAbsent || habilitado != null) {
      map['habilitado'] = Variable<String>(habilitado);
    }
    if (!nullToAbsent || podeInserir != null) {
      map['pode_inserir'] = Variable<String>(podeInserir);
    }
    if (!nullToAbsent || podeAlterar != null) {
      map['pode_alterar'] = Variable<String>(podeAlterar);
    }
    if (!nullToAbsent || podeExcluir != null) {
      map['pode_excluir'] = Variable<String>(podeExcluir);
    }
    return map;
  }

  factory ViewControleAcesso.fromJson(
    Map<String, dynamic> json, {
    ValueSerializer? serializer,
  }) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return ViewControleAcesso(
      id: serializer.fromJson<int?>(json['id']),
      idPessoa: serializer.fromJson<int?>(json['idPessoa']),
      pessoaNome: serializer.fromJson<String?>(json['pessoaNome']),
      idColaborador: serializer.fromJson<int?>(json['idColaborador']),
      idUsuario: serializer.fromJson<int?>(json['idUsuario']),
      administrador: serializer.fromJson<String?>(json['administrador']),
      idPapel: serializer.fromJson<int?>(json['idPapel']),
      papelNome: serializer.fromJson<String?>(json['papelNome']),
      papelDescricao: serializer.fromJson<String?>(json['papelDescricao']),
      idFuncao: serializer.fromJson<int?>(json['idFuncao']),
      funcaoNome: serializer.fromJson<String?>(json['funcaoNome']),
      funcaoDescricao: serializer.fromJson<String?>(json['funcaoDescricao']),
      idPapelFuncao: serializer.fromJson<int?>(json['idPapelFuncao']),
      habilitado: serializer.fromJson<String?>(json['habilitado']),
      podeInserir: serializer.fromJson<String?>(json['podeInserir']),
      podeAlterar: serializer.fromJson<String?>(json['podeAlterar']),
      podeExcluir: serializer.fromJson<String?>(json['podeExcluir']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'idPessoa': serializer.toJson<int?>(idPessoa),
      'pessoaNome': serializer.toJson<String?>(pessoaNome),
      'idColaborador': serializer.toJson<int?>(idColaborador),
      'idUsuario': serializer.toJson<int?>(idUsuario),
      'administrador': serializer.toJson<String?>(administrador),
      'idPapel': serializer.toJson<int?>(idPapel),
      'papelNome': serializer.toJson<String?>(papelNome),
      'papelDescricao': serializer.toJson<String?>(papelDescricao),
      'idFuncao': serializer.toJson<int?>(idFuncao),
      'funcaoNome': serializer.toJson<String?>(funcaoNome),
      'funcaoDescricao': serializer.toJson<String?>(funcaoDescricao),
      'idPapelFuncao': serializer.toJson<int?>(idPapelFuncao),
      'habilitado': serializer.toJson<String?>(habilitado),
      'podeInserir': serializer.toJson<String?>(podeInserir),
      'podeAlterar': serializer.toJson<String?>(podeAlterar),
      'podeExcluir': serializer.toJson<String?>(podeExcluir),
    };
  }

  ViewControleAcesso copyWith({
    Value<int?> id = const Value.absent(),
    Value<int?> idPessoa = const Value.absent(),
    Value<String?> pessoaNome = const Value.absent(),
    Value<int?> idColaborador = const Value.absent(),
    Value<int?> idUsuario = const Value.absent(),
    Value<String?> administrador = const Value.absent(),
    Value<int?> idPapel = const Value.absent(),
    Value<String?> papelNome = const Value.absent(),
    Value<String?> papelDescricao = const Value.absent(),
    Value<int?> idFuncao = const Value.absent(),
    Value<String?> funcaoNome = const Value.absent(),
    Value<String?> funcaoDescricao = const Value.absent(),
    Value<int?> idPapelFuncao = const Value.absent(),
    Value<String?> habilitado = const Value.absent(),
    Value<String?> podeInserir = const Value.absent(),
    Value<String?> podeAlterar = const Value.absent(),
    Value<String?> podeExcluir = const Value.absent(),
  }) => ViewControleAcesso(
    id: id.present ? id.value : this.id,
    idPessoa: idPessoa.present ? idPessoa.value : this.idPessoa,
    pessoaNome: pessoaNome.present ? pessoaNome.value : this.pessoaNome,
    idColaborador:
        idColaborador.present ? idColaborador.value : this.idColaborador,
    idUsuario: idUsuario.present ? idUsuario.value : this.idUsuario,
    administrador:
        administrador.present ? administrador.value : this.administrador,
    idPapel: idPapel.present ? idPapel.value : this.idPapel,
    papelNome: papelNome.present ? papelNome.value : this.papelNome,
    papelDescricao:
        papelDescricao.present ? papelDescricao.value : this.papelDescricao,
    idFuncao: idFuncao.present ? idFuncao.value : this.idFuncao,
    funcaoNome: funcaoNome.present ? funcaoNome.value : this.funcaoNome,
    funcaoDescricao:
        funcaoDescricao.present ? funcaoDescricao.value : this.funcaoDescricao,
    idPapelFuncao:
        idPapelFuncao.present ? idPapelFuncao.value : this.idPapelFuncao,
    habilitado: habilitado.present ? habilitado.value : this.habilitado,
    podeInserir: podeInserir.present ? podeInserir.value : this.podeInserir,
    podeAlterar: podeAlterar.present ? podeAlterar.value : this.podeAlterar,
    podeExcluir: podeExcluir.present ? podeExcluir.value : this.podeExcluir,
  );
  ViewControleAcesso copyWithCompanion(ViewControleAcessosCompanion data) {
    return ViewControleAcesso(
      id: data.id.present ? data.id.value : this.id,
      idPessoa: data.idPessoa.present ? data.idPessoa.value : this.idPessoa,
      pessoaNome:
          data.pessoaNome.present ? data.pessoaNome.value : this.pessoaNome,
      idColaborador:
          data.idColaborador.present
              ? data.idColaborador.value
              : this.idColaborador,
      idUsuario: data.idUsuario.present ? data.idUsuario.value : this.idUsuario,
      administrador:
          data.administrador.present
              ? data.administrador.value
              : this.administrador,
      idPapel: data.idPapel.present ? data.idPapel.value : this.idPapel,
      papelNome: data.papelNome.present ? data.papelNome.value : this.papelNome,
      papelDescricao:
          data.papelDescricao.present
              ? data.papelDescricao.value
              : this.papelDescricao,
      idFuncao: data.idFuncao.present ? data.idFuncao.value : this.idFuncao,
      funcaoNome:
          data.funcaoNome.present ? data.funcaoNome.value : this.funcaoNome,
      funcaoDescricao:
          data.funcaoDescricao.present
              ? data.funcaoDescricao.value
              : this.funcaoDescricao,
      idPapelFuncao:
          data.idPapelFuncao.present
              ? data.idPapelFuncao.value
              : this.idPapelFuncao,
      habilitado:
          data.habilitado.present ? data.habilitado.value : this.habilitado,
      podeInserir:
          data.podeInserir.present ? data.podeInserir.value : this.podeInserir,
      podeAlterar:
          data.podeAlterar.present ? data.podeAlterar.value : this.podeAlterar,
      podeExcluir:
          data.podeExcluir.present ? data.podeExcluir.value : this.podeExcluir,
    );
  }

  @override
  String toString() {
    return (StringBuffer('ViewControleAcesso(')
          ..write('id: $id, ')
          ..write('idPessoa: $idPessoa, ')
          ..write('pessoaNome: $pessoaNome, ')
          ..write('idColaborador: $idColaborador, ')
          ..write('idUsuario: $idUsuario, ')
          ..write('administrador: $administrador, ')
          ..write('idPapel: $idPapel, ')
          ..write('papelNome: $papelNome, ')
          ..write('papelDescricao: $papelDescricao, ')
          ..write('idFuncao: $idFuncao, ')
          ..write('funcaoNome: $funcaoNome, ')
          ..write('funcaoDescricao: $funcaoDescricao, ')
          ..write('idPapelFuncao: $idPapelFuncao, ')
          ..write('habilitado: $habilitado, ')
          ..write('podeInserir: $podeInserir, ')
          ..write('podeAlterar: $podeAlterar, ')
          ..write('podeExcluir: $podeExcluir')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(
    id,
    idPessoa,
    pessoaNome,
    idColaborador,
    idUsuario,
    administrador,
    idPapel,
    papelNome,
    papelDescricao,
    idFuncao,
    funcaoNome,
    funcaoDescricao,
    idPapelFuncao,
    habilitado,
    podeInserir,
    podeAlterar,
    podeExcluir,
  );
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is ViewControleAcesso &&
          other.id == this.id &&
          other.idPessoa == this.idPessoa &&
          other.pessoaNome == this.pessoaNome &&
          other.idColaborador == this.idColaborador &&
          other.idUsuario == this.idUsuario &&
          other.administrador == this.administrador &&
          other.idPapel == this.idPapel &&
          other.papelNome == this.papelNome &&
          other.papelDescricao == this.papelDescricao &&
          other.idFuncao == this.idFuncao &&
          other.funcaoNome == this.funcaoNome &&
          other.funcaoDescricao == this.funcaoDescricao &&
          other.idPapelFuncao == this.idPapelFuncao &&
          other.habilitado == this.habilitado &&
          other.podeInserir == this.podeInserir &&
          other.podeAlterar == this.podeAlterar &&
          other.podeExcluir == this.podeExcluir);
}

class ViewControleAcessosCompanion extends UpdateCompanion<ViewControleAcesso> {
  final Value<int?> id;
  final Value<int?> idPessoa;
  final Value<String?> pessoaNome;
  final Value<int?> idColaborador;
  final Value<int?> idUsuario;
  final Value<String?> administrador;
  final Value<int?> idPapel;
  final Value<String?> papelNome;
  final Value<String?> papelDescricao;
  final Value<int?> idFuncao;
  final Value<String?> funcaoNome;
  final Value<String?> funcaoDescricao;
  final Value<int?> idPapelFuncao;
  final Value<String?> habilitado;
  final Value<String?> podeInserir;
  final Value<String?> podeAlterar;
  final Value<String?> podeExcluir;
  const ViewControleAcessosCompanion({
    this.id = const Value.absent(),
    this.idPessoa = const Value.absent(),
    this.pessoaNome = const Value.absent(),
    this.idColaborador = const Value.absent(),
    this.idUsuario = const Value.absent(),
    this.administrador = const Value.absent(),
    this.idPapel = const Value.absent(),
    this.papelNome = const Value.absent(),
    this.papelDescricao = const Value.absent(),
    this.idFuncao = const Value.absent(),
    this.funcaoNome = const Value.absent(),
    this.funcaoDescricao = const Value.absent(),
    this.idPapelFuncao = const Value.absent(),
    this.habilitado = const Value.absent(),
    this.podeInserir = const Value.absent(),
    this.podeAlterar = const Value.absent(),
    this.podeExcluir = const Value.absent(),
  });
  ViewControleAcessosCompanion.insert({
    this.id = const Value.absent(),
    this.idPessoa = const Value.absent(),
    this.pessoaNome = const Value.absent(),
    this.idColaborador = const Value.absent(),
    this.idUsuario = const Value.absent(),
    this.administrador = const Value.absent(),
    this.idPapel = const Value.absent(),
    this.papelNome = const Value.absent(),
    this.papelDescricao = const Value.absent(),
    this.idFuncao = const Value.absent(),
    this.funcaoNome = const Value.absent(),
    this.funcaoDescricao = const Value.absent(),
    this.idPapelFuncao = const Value.absent(),
    this.habilitado = const Value.absent(),
    this.podeInserir = const Value.absent(),
    this.podeAlterar = const Value.absent(),
    this.podeExcluir = const Value.absent(),
  });
  static Insertable<ViewControleAcesso> custom({
    Expression<int>? id,
    Expression<int>? idPessoa,
    Expression<String>? pessoaNome,
    Expression<int>? idColaborador,
    Expression<int>? idUsuario,
    Expression<String>? administrador,
    Expression<int>? idPapel,
    Expression<String>? papelNome,
    Expression<String>? papelDescricao,
    Expression<int>? idFuncao,
    Expression<String>? funcaoNome,
    Expression<String>? funcaoDescricao,
    Expression<int>? idPapelFuncao,
    Expression<String>? habilitado,
    Expression<String>? podeInserir,
    Expression<String>? podeAlterar,
    Expression<String>? podeExcluir,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (idPessoa != null) 'id_pessoa': idPessoa,
      if (pessoaNome != null) 'pessoa_nome': pessoaNome,
      if (idColaborador != null) 'id_colaborador': idColaborador,
      if (idUsuario != null) 'id_usuario': idUsuario,
      if (administrador != null) 'administrador': administrador,
      if (idPapel != null) 'id_papel': idPapel,
      if (papelNome != null) 'papel_nome': papelNome,
      if (papelDescricao != null) 'papel_descricao': papelDescricao,
      if (idFuncao != null) 'id_funcao': idFuncao,
      if (funcaoNome != null) 'funcao_nome': funcaoNome,
      if (funcaoDescricao != null) 'funcao_descricao': funcaoDescricao,
      if (idPapelFuncao != null) 'id_papel_funcao': idPapelFuncao,
      if (habilitado != null) 'habilitado': habilitado,
      if (podeInserir != null) 'pode_inserir': podeInserir,
      if (podeAlterar != null) 'pode_alterar': podeAlterar,
      if (podeExcluir != null) 'pode_excluir': podeExcluir,
    });
  }

  ViewControleAcessosCompanion copyWith({
    Value<int?>? id,
    Value<int?>? idPessoa,
    Value<String?>? pessoaNome,
    Value<int?>? idColaborador,
    Value<int?>? idUsuario,
    Value<String?>? administrador,
    Value<int?>? idPapel,
    Value<String?>? papelNome,
    Value<String?>? papelDescricao,
    Value<int?>? idFuncao,
    Value<String?>? funcaoNome,
    Value<String?>? funcaoDescricao,
    Value<int?>? idPapelFuncao,
    Value<String?>? habilitado,
    Value<String?>? podeInserir,
    Value<String?>? podeAlterar,
    Value<String?>? podeExcluir,
  }) {
    return ViewControleAcessosCompanion(
      id: id ?? this.id,
      idPessoa: idPessoa ?? this.idPessoa,
      pessoaNome: pessoaNome ?? this.pessoaNome,
      idColaborador: idColaborador ?? this.idColaborador,
      idUsuario: idUsuario ?? this.idUsuario,
      administrador: administrador ?? this.administrador,
      idPapel: idPapel ?? this.idPapel,
      papelNome: papelNome ?? this.papelNome,
      papelDescricao: papelDescricao ?? this.papelDescricao,
      idFuncao: idFuncao ?? this.idFuncao,
      funcaoNome: funcaoNome ?? this.funcaoNome,
      funcaoDescricao: funcaoDescricao ?? this.funcaoDescricao,
      idPapelFuncao: idPapelFuncao ?? this.idPapelFuncao,
      habilitado: habilitado ?? this.habilitado,
      podeInserir: podeInserir ?? this.podeInserir,
      podeAlterar: podeAlterar ?? this.podeAlterar,
      podeExcluir: podeExcluir ?? this.podeExcluir,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (idPessoa.present) {
      map['id_pessoa'] = Variable<int>(idPessoa.value);
    }
    if (pessoaNome.present) {
      map['pessoa_nome'] = Variable<String>(pessoaNome.value);
    }
    if (idColaborador.present) {
      map['id_colaborador'] = Variable<int>(idColaborador.value);
    }
    if (idUsuario.present) {
      map['id_usuario'] = Variable<int>(idUsuario.value);
    }
    if (administrador.present) {
      map['administrador'] = Variable<String>(administrador.value);
    }
    if (idPapel.present) {
      map['id_papel'] = Variable<int>(idPapel.value);
    }
    if (papelNome.present) {
      map['papel_nome'] = Variable<String>(papelNome.value);
    }
    if (papelDescricao.present) {
      map['papel_descricao'] = Variable<String>(papelDescricao.value);
    }
    if (idFuncao.present) {
      map['id_funcao'] = Variable<int>(idFuncao.value);
    }
    if (funcaoNome.present) {
      map['funcao_nome'] = Variable<String>(funcaoNome.value);
    }
    if (funcaoDescricao.present) {
      map['funcao_descricao'] = Variable<String>(funcaoDescricao.value);
    }
    if (idPapelFuncao.present) {
      map['id_papel_funcao'] = Variable<int>(idPapelFuncao.value);
    }
    if (habilitado.present) {
      map['habilitado'] = Variable<String>(habilitado.value);
    }
    if (podeInserir.present) {
      map['pode_inserir'] = Variable<String>(podeInserir.value);
    }
    if (podeAlterar.present) {
      map['pode_alterar'] = Variable<String>(podeAlterar.value);
    }
    if (podeExcluir.present) {
      map['pode_excluir'] = Variable<String>(podeExcluir.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('ViewControleAcessosCompanion(')
          ..write('id: $id, ')
          ..write('idPessoa: $idPessoa, ')
          ..write('pessoaNome: $pessoaNome, ')
          ..write('idColaborador: $idColaborador, ')
          ..write('idUsuario: $idUsuario, ')
          ..write('administrador: $administrador, ')
          ..write('idPapel: $idPapel, ')
          ..write('papelNome: $papelNome, ')
          ..write('papelDescricao: $papelDescricao, ')
          ..write('idFuncao: $idFuncao, ')
          ..write('funcaoNome: $funcaoNome, ')
          ..write('funcaoDescricao: $funcaoDescricao, ')
          ..write('idPapelFuncao: $idPapelFuncao, ')
          ..write('habilitado: $habilitado, ')
          ..write('podeInserir: $podeInserir, ')
          ..write('podeAlterar: $podeAlterar, ')
          ..write('podeExcluir: $podeExcluir')
          ..write(')'))
        .toString();
  }
}

class $ViewPessoaUsuariosTable extends ViewPessoaUsuarios
    with TableInfo<$ViewPessoaUsuariosTable, ViewPessoaUsuario> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $ViewPessoaUsuariosTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
    'id',
    aliasedName,
    true,
    type: DriftSqlType.int,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _idPessoaMeta = const VerificationMeta(
    'idPessoa',
  );
  @override
  late final GeneratedColumn<int> idPessoa = GeneratedColumn<int>(
    'id_pessoa',
    aliasedName,
    true,
    type: DriftSqlType.int,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _pessoaNomeMeta = const VerificationMeta(
    'pessoaNome',
  );
  @override
  late final GeneratedColumn<String> pessoaNome = GeneratedColumn<String>(
    'pessoa_nome',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 450,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _tipoMeta = const VerificationMeta('tipo');
  @override
  late final GeneratedColumn<String> tipo = GeneratedColumn<String>(
    'tipo',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 3,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _emailMeta = const VerificationMeta('email');
  @override
  late final GeneratedColumn<String> email = GeneratedColumn<String>(
    'email',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 750,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _idColaboradorMeta = const VerificationMeta(
    'idColaborador',
  );
  @override
  late final GeneratedColumn<int> idColaborador = GeneratedColumn<int>(
    'id_colaborador',
    aliasedName,
    true,
    type: DriftSqlType.int,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _idUsuarioMeta = const VerificationMeta(
    'idUsuario',
  );
  @override
  late final GeneratedColumn<int> idUsuario = GeneratedColumn<int>(
    'id_usuario',
    aliasedName,
    true,
    type: DriftSqlType.int,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _loginMeta = const VerificationMeta('login');
  @override
  late final GeneratedColumn<String> login = GeneratedColumn<String>(
    'login',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 150,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _senhaMeta = const VerificationMeta('senha');
  @override
  late final GeneratedColumn<String> senha = GeneratedColumn<String>(
    'senha',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 150,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _dataCadastroMeta = const VerificationMeta(
    'dataCadastro',
  );
  @override
  late final GeneratedColumn<DateTime> dataCadastro = GeneratedColumn<DateTime>(
    'data_cadastro',
    aliasedName,
    true,
    type: DriftSqlType.dateTime,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _administradorMeta = const VerificationMeta(
    'administrador',
  );
  @override
  late final GeneratedColumn<String> administrador = GeneratedColumn<String>(
    'administrador',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 3,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  @override
  List<GeneratedColumn> get $columns => [
    id,
    idPessoa,
    pessoaNome,
    tipo,
    email,
    idColaborador,
    idUsuario,
    login,
    senha,
    dataCadastro,
    administrador,
  ];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'view_pessoa_usuario';
  @override
  VerificationContext validateIntegrity(
    Insertable<ViewPessoaUsuario> instance, {
    bool isInserting = false,
  }) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('id_pessoa')) {
      context.handle(
        _idPessoaMeta,
        idPessoa.isAcceptableOrUnknown(data['id_pessoa']!, _idPessoaMeta),
      );
    }
    if (data.containsKey('pessoa_nome')) {
      context.handle(
        _pessoaNomeMeta,
        pessoaNome.isAcceptableOrUnknown(data['pessoa_nome']!, _pessoaNomeMeta),
      );
    }
    if (data.containsKey('tipo')) {
      context.handle(
        _tipoMeta,
        tipo.isAcceptableOrUnknown(data['tipo']!, _tipoMeta),
      );
    }
    if (data.containsKey('email')) {
      context.handle(
        _emailMeta,
        email.isAcceptableOrUnknown(data['email']!, _emailMeta),
      );
    }
    if (data.containsKey('id_colaborador')) {
      context.handle(
        _idColaboradorMeta,
        idColaborador.isAcceptableOrUnknown(
          data['id_colaborador']!,
          _idColaboradorMeta,
        ),
      );
    }
    if (data.containsKey('id_usuario')) {
      context.handle(
        _idUsuarioMeta,
        idUsuario.isAcceptableOrUnknown(data['id_usuario']!, _idUsuarioMeta),
      );
    }
    if (data.containsKey('login')) {
      context.handle(
        _loginMeta,
        login.isAcceptableOrUnknown(data['login']!, _loginMeta),
      );
    }
    if (data.containsKey('senha')) {
      context.handle(
        _senhaMeta,
        senha.isAcceptableOrUnknown(data['senha']!, _senhaMeta),
      );
    }
    if (data.containsKey('data_cadastro')) {
      context.handle(
        _dataCadastroMeta,
        dataCadastro.isAcceptableOrUnknown(
          data['data_cadastro']!,
          _dataCadastroMeta,
        ),
      );
    }
    if (data.containsKey('administrador')) {
      context.handle(
        _administradorMeta,
        administrador.isAcceptableOrUnknown(
          data['administrador']!,
          _administradorMeta,
        ),
      );
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  ViewPessoaUsuario map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return ViewPessoaUsuario(
      id: attachedDatabase.typeMapping.read(
        DriftSqlType.int,
        data['${effectivePrefix}id'],
      ),
      idPessoa: attachedDatabase.typeMapping.read(
        DriftSqlType.int,
        data['${effectivePrefix}id_pessoa'],
      ),
      pessoaNome: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}pessoa_nome'],
      ),
      tipo: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}tipo'],
      ),
      email: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}email'],
      ),
      idColaborador: attachedDatabase.typeMapping.read(
        DriftSqlType.int,
        data['${effectivePrefix}id_colaborador'],
      ),
      idUsuario: attachedDatabase.typeMapping.read(
        DriftSqlType.int,
        data['${effectivePrefix}id_usuario'],
      ),
      login: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}login'],
      ),
      senha: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}senha'],
      ),
      dataCadastro: attachedDatabase.typeMapping.read(
        DriftSqlType.dateTime,
        data['${effectivePrefix}data_cadastro'],
      ),
      administrador: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}administrador'],
      ),
    );
  }

  @override
  $ViewPessoaUsuariosTable createAlias(String alias) {
    return $ViewPessoaUsuariosTable(attachedDatabase, alias);
  }
}

class ViewPessoaUsuario extends DataClass
    implements Insertable<ViewPessoaUsuario> {
  final int? id;
  final int? idPessoa;
  final String? pessoaNome;
  final String? tipo;
  final String? email;
  final int? idColaborador;
  final int? idUsuario;
  final String? login;
  final String? senha;
  final DateTime? dataCadastro;
  final String? administrador;
  const ViewPessoaUsuario({
    this.id,
    this.idPessoa,
    this.pessoaNome,
    this.tipo,
    this.email,
    this.idColaborador,
    this.idUsuario,
    this.login,
    this.senha,
    this.dataCadastro,
    this.administrador,
  });
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || idPessoa != null) {
      map['id_pessoa'] = Variable<int>(idPessoa);
    }
    if (!nullToAbsent || pessoaNome != null) {
      map['pessoa_nome'] = Variable<String>(pessoaNome);
    }
    if (!nullToAbsent || tipo != null) {
      map['tipo'] = Variable<String>(tipo);
    }
    if (!nullToAbsent || email != null) {
      map['email'] = Variable<String>(email);
    }
    if (!nullToAbsent || idColaborador != null) {
      map['id_colaborador'] = Variable<int>(idColaborador);
    }
    if (!nullToAbsent || idUsuario != null) {
      map['id_usuario'] = Variable<int>(idUsuario);
    }
    if (!nullToAbsent || login != null) {
      map['login'] = Variable<String>(login);
    }
    if (!nullToAbsent || senha != null) {
      map['senha'] = Variable<String>(senha);
    }
    if (!nullToAbsent || dataCadastro != null) {
      map['data_cadastro'] = Variable<DateTime>(dataCadastro);
    }
    if (!nullToAbsent || administrador != null) {
      map['administrador'] = Variable<String>(administrador);
    }
    return map;
  }

  factory ViewPessoaUsuario.fromJson(
    Map<String, dynamic> json, {
    ValueSerializer? serializer,
  }) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return ViewPessoaUsuario(
      id: serializer.fromJson<int?>(json['id']),
      idPessoa: serializer.fromJson<int?>(json['idPessoa']),
      pessoaNome: serializer.fromJson<String?>(json['pessoaNome']),
      tipo: serializer.fromJson<String?>(json['tipo']),
      email: serializer.fromJson<String?>(json['email']),
      idColaborador: serializer.fromJson<int?>(json['idColaborador']),
      idUsuario: serializer.fromJson<int?>(json['idUsuario']),
      login: serializer.fromJson<String?>(json['login']),
      senha: serializer.fromJson<String?>(json['senha']),
      dataCadastro: serializer.fromJson<DateTime?>(json['dataCadastro']),
      administrador: serializer.fromJson<String?>(json['administrador']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'idPessoa': serializer.toJson<int?>(idPessoa),
      'pessoaNome': serializer.toJson<String?>(pessoaNome),
      'tipo': serializer.toJson<String?>(tipo),
      'email': serializer.toJson<String?>(email),
      'idColaborador': serializer.toJson<int?>(idColaborador),
      'idUsuario': serializer.toJson<int?>(idUsuario),
      'login': serializer.toJson<String?>(login),
      'senha': serializer.toJson<String?>(senha),
      'dataCadastro': serializer.toJson<DateTime?>(dataCadastro),
      'administrador': serializer.toJson<String?>(administrador),
    };
  }

  ViewPessoaUsuario copyWith({
    Value<int?> id = const Value.absent(),
    Value<int?> idPessoa = const Value.absent(),
    Value<String?> pessoaNome = const Value.absent(),
    Value<String?> tipo = const Value.absent(),
    Value<String?> email = const Value.absent(),
    Value<int?> idColaborador = const Value.absent(),
    Value<int?> idUsuario = const Value.absent(),
    Value<String?> login = const Value.absent(),
    Value<String?> senha = const Value.absent(),
    Value<DateTime?> dataCadastro = const Value.absent(),
    Value<String?> administrador = const Value.absent(),
  }) => ViewPessoaUsuario(
    id: id.present ? id.value : this.id,
    idPessoa: idPessoa.present ? idPessoa.value : this.idPessoa,
    pessoaNome: pessoaNome.present ? pessoaNome.value : this.pessoaNome,
    tipo: tipo.present ? tipo.value : this.tipo,
    email: email.present ? email.value : this.email,
    idColaborador:
        idColaborador.present ? idColaborador.value : this.idColaborador,
    idUsuario: idUsuario.present ? idUsuario.value : this.idUsuario,
    login: login.present ? login.value : this.login,
    senha: senha.present ? senha.value : this.senha,
    dataCadastro: dataCadastro.present ? dataCadastro.value : this.dataCadastro,
    administrador:
        administrador.present ? administrador.value : this.administrador,
  );
  ViewPessoaUsuario copyWithCompanion(ViewPessoaUsuariosCompanion data) {
    return ViewPessoaUsuario(
      id: data.id.present ? data.id.value : this.id,
      idPessoa: data.idPessoa.present ? data.idPessoa.value : this.idPessoa,
      pessoaNome:
          data.pessoaNome.present ? data.pessoaNome.value : this.pessoaNome,
      tipo: data.tipo.present ? data.tipo.value : this.tipo,
      email: data.email.present ? data.email.value : this.email,
      idColaborador:
          data.idColaborador.present
              ? data.idColaborador.value
              : this.idColaborador,
      idUsuario: data.idUsuario.present ? data.idUsuario.value : this.idUsuario,
      login: data.login.present ? data.login.value : this.login,
      senha: data.senha.present ? data.senha.value : this.senha,
      dataCadastro:
          data.dataCadastro.present
              ? data.dataCadastro.value
              : this.dataCadastro,
      administrador:
          data.administrador.present
              ? data.administrador.value
              : this.administrador,
    );
  }

  @override
  String toString() {
    return (StringBuffer('ViewPessoaUsuario(')
          ..write('id: $id, ')
          ..write('idPessoa: $idPessoa, ')
          ..write('pessoaNome: $pessoaNome, ')
          ..write('tipo: $tipo, ')
          ..write('email: $email, ')
          ..write('idColaborador: $idColaborador, ')
          ..write('idUsuario: $idUsuario, ')
          ..write('login: $login, ')
          ..write('senha: $senha, ')
          ..write('dataCadastro: $dataCadastro, ')
          ..write('administrador: $administrador')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(
    id,
    idPessoa,
    pessoaNome,
    tipo,
    email,
    idColaborador,
    idUsuario,
    login,
    senha,
    dataCadastro,
    administrador,
  );
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is ViewPessoaUsuario &&
          other.id == this.id &&
          other.idPessoa == this.idPessoa &&
          other.pessoaNome == this.pessoaNome &&
          other.tipo == this.tipo &&
          other.email == this.email &&
          other.idColaborador == this.idColaborador &&
          other.idUsuario == this.idUsuario &&
          other.login == this.login &&
          other.senha == this.senha &&
          other.dataCadastro == this.dataCadastro &&
          other.administrador == this.administrador);
}

class ViewPessoaUsuariosCompanion extends UpdateCompanion<ViewPessoaUsuario> {
  final Value<int?> id;
  final Value<int?> idPessoa;
  final Value<String?> pessoaNome;
  final Value<String?> tipo;
  final Value<String?> email;
  final Value<int?> idColaborador;
  final Value<int?> idUsuario;
  final Value<String?> login;
  final Value<String?> senha;
  final Value<DateTime?> dataCadastro;
  final Value<String?> administrador;
  const ViewPessoaUsuariosCompanion({
    this.id = const Value.absent(),
    this.idPessoa = const Value.absent(),
    this.pessoaNome = const Value.absent(),
    this.tipo = const Value.absent(),
    this.email = const Value.absent(),
    this.idColaborador = const Value.absent(),
    this.idUsuario = const Value.absent(),
    this.login = const Value.absent(),
    this.senha = const Value.absent(),
    this.dataCadastro = const Value.absent(),
    this.administrador = const Value.absent(),
  });
  ViewPessoaUsuariosCompanion.insert({
    this.id = const Value.absent(),
    this.idPessoa = const Value.absent(),
    this.pessoaNome = const Value.absent(),
    this.tipo = const Value.absent(),
    this.email = const Value.absent(),
    this.idColaborador = const Value.absent(),
    this.idUsuario = const Value.absent(),
    this.login = const Value.absent(),
    this.senha = const Value.absent(),
    this.dataCadastro = const Value.absent(),
    this.administrador = const Value.absent(),
  });
  static Insertable<ViewPessoaUsuario> custom({
    Expression<int>? id,
    Expression<int>? idPessoa,
    Expression<String>? pessoaNome,
    Expression<String>? tipo,
    Expression<String>? email,
    Expression<int>? idColaborador,
    Expression<int>? idUsuario,
    Expression<String>? login,
    Expression<String>? senha,
    Expression<DateTime>? dataCadastro,
    Expression<String>? administrador,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (idPessoa != null) 'id_pessoa': idPessoa,
      if (pessoaNome != null) 'pessoa_nome': pessoaNome,
      if (tipo != null) 'tipo': tipo,
      if (email != null) 'email': email,
      if (idColaborador != null) 'id_colaborador': idColaborador,
      if (idUsuario != null) 'id_usuario': idUsuario,
      if (login != null) 'login': login,
      if (senha != null) 'senha': senha,
      if (dataCadastro != null) 'data_cadastro': dataCadastro,
      if (administrador != null) 'administrador': administrador,
    });
  }

  ViewPessoaUsuariosCompanion copyWith({
    Value<int?>? id,
    Value<int?>? idPessoa,
    Value<String?>? pessoaNome,
    Value<String?>? tipo,
    Value<String?>? email,
    Value<int?>? idColaborador,
    Value<int?>? idUsuario,
    Value<String?>? login,
    Value<String?>? senha,
    Value<DateTime?>? dataCadastro,
    Value<String?>? administrador,
  }) {
    return ViewPessoaUsuariosCompanion(
      id: id ?? this.id,
      idPessoa: idPessoa ?? this.idPessoa,
      pessoaNome: pessoaNome ?? this.pessoaNome,
      tipo: tipo ?? this.tipo,
      email: email ?? this.email,
      idColaborador: idColaborador ?? this.idColaborador,
      idUsuario: idUsuario ?? this.idUsuario,
      login: login ?? this.login,
      senha: senha ?? this.senha,
      dataCadastro: dataCadastro ?? this.dataCadastro,
      administrador: administrador ?? this.administrador,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (idPessoa.present) {
      map['id_pessoa'] = Variable<int>(idPessoa.value);
    }
    if (pessoaNome.present) {
      map['pessoa_nome'] = Variable<String>(pessoaNome.value);
    }
    if (tipo.present) {
      map['tipo'] = Variable<String>(tipo.value);
    }
    if (email.present) {
      map['email'] = Variable<String>(email.value);
    }
    if (idColaborador.present) {
      map['id_colaborador'] = Variable<int>(idColaborador.value);
    }
    if (idUsuario.present) {
      map['id_usuario'] = Variable<int>(idUsuario.value);
    }
    if (login.present) {
      map['login'] = Variable<String>(login.value);
    }
    if (senha.present) {
      map['senha'] = Variable<String>(senha.value);
    }
    if (dataCadastro.present) {
      map['data_cadastro'] = Variable<DateTime>(dataCadastro.value);
    }
    if (administrador.present) {
      map['administrador'] = Variable<String>(administrador.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('ViewPessoaUsuariosCompanion(')
          ..write('id: $id, ')
          ..write('idPessoa: $idPessoa, ')
          ..write('pessoaNome: $pessoaNome, ')
          ..write('tipo: $tipo, ')
          ..write('email: $email, ')
          ..write('idColaborador: $idColaborador, ')
          ..write('idUsuario: $idUsuario, ')
          ..write('login: $login, ')
          ..write('senha: $senha, ')
          ..write('dataCadastro: $dataCadastro, ')
          ..write('administrador: $administrador')
          ..write(')'))
        .toString();
  }
}

class $ViewPessoaColaboradorsTable extends ViewPessoaColaboradors
    with TableInfo<$ViewPessoaColaboradorsTable, ViewPessoaColaborador> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $ViewPessoaColaboradorsTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
    'id',
    aliasedName,
    true,
    type: DriftSqlType.int,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _nomeMeta = const VerificationMeta('nome');
  @override
  late final GeneratedColumn<String> nome = GeneratedColumn<String>(
    'nome',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 450,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _tipoMeta = const VerificationMeta('tipo');
  @override
  late final GeneratedColumn<String> tipo = GeneratedColumn<String>(
    'tipo',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 3,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _emailMeta = const VerificationMeta('email');
  @override
  late final GeneratedColumn<String> email = GeneratedColumn<String>(
    'email',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 750,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _siteMeta = const VerificationMeta('site');
  @override
  late final GeneratedColumn<String> site = GeneratedColumn<String>(
    'site',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 450,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _cpfCnpjMeta = const VerificationMeta(
    'cpfCnpj',
  );
  @override
  late final GeneratedColumn<String> cpfCnpj = GeneratedColumn<String>(
    'cpf_cnpj',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 20,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _rgIeMeta = const VerificationMeta('rgIe');
  @override
  late final GeneratedColumn<String> rgIe = GeneratedColumn<String>(
    'rg_ie',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 20,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _matriculaMeta = const VerificationMeta(
    'matricula',
  );
  @override
  late final GeneratedColumn<String> matricula = GeneratedColumn<String>(
    'matricula',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 50,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _dataCadastroMeta = const VerificationMeta(
    'dataCadastro',
  );
  @override
  late final GeneratedColumn<DateTime> dataCadastro = GeneratedColumn<DateTime>(
    'data_cadastro',
    aliasedName,
    true,
    type: DriftSqlType.dateTime,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _dataAdmissaoMeta = const VerificationMeta(
    'dataAdmissao',
  );
  @override
  late final GeneratedColumn<DateTime> dataAdmissao = GeneratedColumn<DateTime>(
    'data_admissao',
    aliasedName,
    true,
    type: DriftSqlType.dateTime,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _dataDemissaoMeta = const VerificationMeta(
    'dataDemissao',
  );
  @override
  late final GeneratedColumn<DateTime> dataDemissao = GeneratedColumn<DateTime>(
    'data_demissao',
    aliasedName,
    true,
    type: DriftSqlType.dateTime,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _ctpsNumeroMeta = const VerificationMeta(
    'ctpsNumero',
  );
  @override
  late final GeneratedColumn<String> ctpsNumero = GeneratedColumn<String>(
    'ctps_numero',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 20,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _ctpsSerieMeta = const VerificationMeta(
    'ctpsSerie',
  );
  @override
  late final GeneratedColumn<String> ctpsSerie = GeneratedColumn<String>(
    'ctps_serie',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 10,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _ctpsDataExpedicaoMeta = const VerificationMeta(
    'ctpsDataExpedicao',
  );
  @override
  late final GeneratedColumn<DateTime> ctpsDataExpedicao =
      GeneratedColumn<DateTime>(
        'ctps_data_expedicao',
        aliasedName,
        true,
        type: DriftSqlType.dateTime,
        requiredDuringInsert: false,
      );
  static const VerificationMeta _ctpsUfMeta = const VerificationMeta('ctpsUf');
  @override
  late final GeneratedColumn<String> ctpsUf = GeneratedColumn<String>(
    'ctps_uf',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 2,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _observacaoMeta = const VerificationMeta(
    'observacao',
  );
  @override
  late final GeneratedColumn<String> observacao = GeneratedColumn<String>(
    'observacao',
    aliasedName,
    true,
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _logradouroMeta = const VerificationMeta(
    'logradouro',
  );
  @override
  late final GeneratedColumn<String> logradouro = GeneratedColumn<String>(
    'logradouro',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 450,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _numeroMeta = const VerificationMeta('numero');
  @override
  late final GeneratedColumn<String> numero = GeneratedColumn<String>(
    'numero',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 20,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _complementoMeta = const VerificationMeta(
    'complemento',
  );
  @override
  late final GeneratedColumn<String> complemento = GeneratedColumn<String>(
    'complemento',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 450,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _bairroMeta = const VerificationMeta('bairro');
  @override
  late final GeneratedColumn<String> bairro = GeneratedColumn<String>(
    'bairro',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 150,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _cidadeMeta = const VerificationMeta('cidade');
  @override
  late final GeneratedColumn<String> cidade = GeneratedColumn<String>(
    'cidade',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 150,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _cepMeta = const VerificationMeta('cep');
  @override
  late final GeneratedColumn<String> cep = GeneratedColumn<String>(
    'cep',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 10,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _municipioIbgeMeta = const VerificationMeta(
    'municipioIbge',
  );
  @override
  late final GeneratedColumn<String> municipioIbge = GeneratedColumn<String>(
    'municipio_ibge',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 10,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _ufMeta = const VerificationMeta('uf');
  @override
  late final GeneratedColumn<String> uf = GeneratedColumn<String>(
    'uf',
    aliasedName,
    true,
    additionalChecks: GeneratedColumn.checkTextLength(
      minTextLength: 0,
      maxTextLength: 2,
    ),
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _idPessoaMeta = const VerificationMeta(
    'idPessoa',
  );
  @override
  late final GeneratedColumn<int> idPessoa = GeneratedColumn<int>(
    'id_pessoa',
    aliasedName,
    true,
    type: DriftSqlType.int,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _idCargoMeta = const VerificationMeta(
    'idCargo',
  );
  @override
  late final GeneratedColumn<int> idCargo = GeneratedColumn<int>(
    'id_cargo',
    aliasedName,
    true,
    type: DriftSqlType.int,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _idSetorMeta = const VerificationMeta(
    'idSetor',
  );
  @override
  late final GeneratedColumn<int> idSetor = GeneratedColumn<int>(
    'id_setor',
    aliasedName,
    true,
    type: DriftSqlType.int,
    requiredDuringInsert: false,
  );
  @override
  List<GeneratedColumn> get $columns => [
    id,
    nome,
    tipo,
    email,
    site,
    cpfCnpj,
    rgIe,
    matricula,
    dataCadastro,
    dataAdmissao,
    dataDemissao,
    ctpsNumero,
    ctpsSerie,
    ctpsDataExpedicao,
    ctpsUf,
    observacao,
    logradouro,
    numero,
    complemento,
    bairro,
    cidade,
    cep,
    municipioIbge,
    uf,
    idPessoa,
    idCargo,
    idSetor,
  ];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'view_pessoa_colaborador';
  @override
  VerificationContext validateIntegrity(
    Insertable<ViewPessoaColaborador> instance, {
    bool isInserting = false,
  }) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('nome')) {
      context.handle(
        _nomeMeta,
        nome.isAcceptableOrUnknown(data['nome']!, _nomeMeta),
      );
    }
    if (data.containsKey('tipo')) {
      context.handle(
        _tipoMeta,
        tipo.isAcceptableOrUnknown(data['tipo']!, _tipoMeta),
      );
    }
    if (data.containsKey('email')) {
      context.handle(
        _emailMeta,
        email.isAcceptableOrUnknown(data['email']!, _emailMeta),
      );
    }
    if (data.containsKey('site')) {
      context.handle(
        _siteMeta,
        site.isAcceptableOrUnknown(data['site']!, _siteMeta),
      );
    }
    if (data.containsKey('cpf_cnpj')) {
      context.handle(
        _cpfCnpjMeta,
        cpfCnpj.isAcceptableOrUnknown(data['cpf_cnpj']!, _cpfCnpjMeta),
      );
    }
    if (data.containsKey('rg_ie')) {
      context.handle(
        _rgIeMeta,
        rgIe.isAcceptableOrUnknown(data['rg_ie']!, _rgIeMeta),
      );
    }
    if (data.containsKey('matricula')) {
      context.handle(
        _matriculaMeta,
        matricula.isAcceptableOrUnknown(data['matricula']!, _matriculaMeta),
      );
    }
    if (data.containsKey('data_cadastro')) {
      context.handle(
        _dataCadastroMeta,
        dataCadastro.isAcceptableOrUnknown(
          data['data_cadastro']!,
          _dataCadastroMeta,
        ),
      );
    }
    if (data.containsKey('data_admissao')) {
      context.handle(
        _dataAdmissaoMeta,
        dataAdmissao.isAcceptableOrUnknown(
          data['data_admissao']!,
          _dataAdmissaoMeta,
        ),
      );
    }
    if (data.containsKey('data_demissao')) {
      context.handle(
        _dataDemissaoMeta,
        dataDemissao.isAcceptableOrUnknown(
          data['data_demissao']!,
          _dataDemissaoMeta,
        ),
      );
    }
    if (data.containsKey('ctps_numero')) {
      context.handle(
        _ctpsNumeroMeta,
        ctpsNumero.isAcceptableOrUnknown(data['ctps_numero']!, _ctpsNumeroMeta),
      );
    }
    if (data.containsKey('ctps_serie')) {
      context.handle(
        _ctpsSerieMeta,
        ctpsSerie.isAcceptableOrUnknown(data['ctps_serie']!, _ctpsSerieMeta),
      );
    }
    if (data.containsKey('ctps_data_expedicao')) {
      context.handle(
        _ctpsDataExpedicaoMeta,
        ctpsDataExpedicao.isAcceptableOrUnknown(
          data['ctps_data_expedicao']!,
          _ctpsDataExpedicaoMeta,
        ),
      );
    }
    if (data.containsKey('ctps_uf')) {
      context.handle(
        _ctpsUfMeta,
        ctpsUf.isAcceptableOrUnknown(data['ctps_uf']!, _ctpsUfMeta),
      );
    }
    if (data.containsKey('observacao')) {
      context.handle(
        _observacaoMeta,
        observacao.isAcceptableOrUnknown(data['observacao']!, _observacaoMeta),
      );
    }
    if (data.containsKey('logradouro')) {
      context.handle(
        _logradouroMeta,
        logradouro.isAcceptableOrUnknown(data['logradouro']!, _logradouroMeta),
      );
    }
    if (data.containsKey('numero')) {
      context.handle(
        _numeroMeta,
        numero.isAcceptableOrUnknown(data['numero']!, _numeroMeta),
      );
    }
    if (data.containsKey('complemento')) {
      context.handle(
        _complementoMeta,
        complemento.isAcceptableOrUnknown(
          data['complemento']!,
          _complementoMeta,
        ),
      );
    }
    if (data.containsKey('bairro')) {
      context.handle(
        _bairroMeta,
        bairro.isAcceptableOrUnknown(data['bairro']!, _bairroMeta),
      );
    }
    if (data.containsKey('cidade')) {
      context.handle(
        _cidadeMeta,
        cidade.isAcceptableOrUnknown(data['cidade']!, _cidadeMeta),
      );
    }
    if (data.containsKey('cep')) {
      context.handle(
        _cepMeta,
        cep.isAcceptableOrUnknown(data['cep']!, _cepMeta),
      );
    }
    if (data.containsKey('municipio_ibge')) {
      context.handle(
        _municipioIbgeMeta,
        municipioIbge.isAcceptableOrUnknown(
          data['municipio_ibge']!,
          _municipioIbgeMeta,
        ),
      );
    }
    if (data.containsKey('uf')) {
      context.handle(_ufMeta, uf.isAcceptableOrUnknown(data['uf']!, _ufMeta));
    }
    if (data.containsKey('id_pessoa')) {
      context.handle(
        _idPessoaMeta,
        idPessoa.isAcceptableOrUnknown(data['id_pessoa']!, _idPessoaMeta),
      );
    }
    if (data.containsKey('id_cargo')) {
      context.handle(
        _idCargoMeta,
        idCargo.isAcceptableOrUnknown(data['id_cargo']!, _idCargoMeta),
      );
    }
    if (data.containsKey('id_setor')) {
      context.handle(
        _idSetorMeta,
        idSetor.isAcceptableOrUnknown(data['id_setor']!, _idSetorMeta),
      );
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  ViewPessoaColaborador map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return ViewPessoaColaborador(
      id: attachedDatabase.typeMapping.read(
        DriftSqlType.int,
        data['${effectivePrefix}id'],
      ),
      nome: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}nome'],
      ),
      tipo: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}tipo'],
      ),
      email: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}email'],
      ),
      site: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}site'],
      ),
      cpfCnpj: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}cpf_cnpj'],
      ),
      rgIe: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}rg_ie'],
      ),
      matricula: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}matricula'],
      ),
      dataCadastro: attachedDatabase.typeMapping.read(
        DriftSqlType.dateTime,
        data['${effectivePrefix}data_cadastro'],
      ),
      dataAdmissao: attachedDatabase.typeMapping.read(
        DriftSqlType.dateTime,
        data['${effectivePrefix}data_admissao'],
      ),
      dataDemissao: attachedDatabase.typeMapping.read(
        DriftSqlType.dateTime,
        data['${effectivePrefix}data_demissao'],
      ),
      ctpsNumero: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}ctps_numero'],
      ),
      ctpsSerie: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}ctps_serie'],
      ),
      ctpsDataExpedicao: attachedDatabase.typeMapping.read(
        DriftSqlType.dateTime,
        data['${effectivePrefix}ctps_data_expedicao'],
      ),
      ctpsUf: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}ctps_uf'],
      ),
      observacao: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}observacao'],
      ),
      logradouro: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}logradouro'],
      ),
      numero: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}numero'],
      ),
      complemento: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}complemento'],
      ),
      bairro: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}bairro'],
      ),
      cidade: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}cidade'],
      ),
      cep: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}cep'],
      ),
      municipioIbge: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}municipio_ibge'],
      ),
      uf: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}uf'],
      ),
      idPessoa: attachedDatabase.typeMapping.read(
        DriftSqlType.int,
        data['${effectivePrefix}id_pessoa'],
      ),
      idCargo: attachedDatabase.typeMapping.read(
        DriftSqlType.int,
        data['${effectivePrefix}id_cargo'],
      ),
      idSetor: attachedDatabase.typeMapping.read(
        DriftSqlType.int,
        data['${effectivePrefix}id_setor'],
      ),
    );
  }

  @override
  $ViewPessoaColaboradorsTable createAlias(String alias) {
    return $ViewPessoaColaboradorsTable(attachedDatabase, alias);
  }
}

class ViewPessoaColaborador extends DataClass
    implements Insertable<ViewPessoaColaborador> {
  final int? id;
  final String? nome;
  final String? tipo;
  final String? email;
  final String? site;
  final String? cpfCnpj;
  final String? rgIe;
  final String? matricula;
  final DateTime? dataCadastro;
  final DateTime? dataAdmissao;
  final DateTime? dataDemissao;
  final String? ctpsNumero;
  final String? ctpsSerie;
  final DateTime? ctpsDataExpedicao;
  final String? ctpsUf;
  final String? observacao;
  final String? logradouro;
  final String? numero;
  final String? complemento;
  final String? bairro;
  final String? cidade;
  final String? cep;
  final String? municipioIbge;
  final String? uf;
  final int? idPessoa;
  final int? idCargo;
  final int? idSetor;
  const ViewPessoaColaborador({
    this.id,
    this.nome,
    this.tipo,
    this.email,
    this.site,
    this.cpfCnpj,
    this.rgIe,
    this.matricula,
    this.dataCadastro,
    this.dataAdmissao,
    this.dataDemissao,
    this.ctpsNumero,
    this.ctpsSerie,
    this.ctpsDataExpedicao,
    this.ctpsUf,
    this.observacao,
    this.logradouro,
    this.numero,
    this.complemento,
    this.bairro,
    this.cidade,
    this.cep,
    this.municipioIbge,
    this.uf,
    this.idPessoa,
    this.idCargo,
    this.idSetor,
  });
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || nome != null) {
      map['nome'] = Variable<String>(nome);
    }
    if (!nullToAbsent || tipo != null) {
      map['tipo'] = Variable<String>(tipo);
    }
    if (!nullToAbsent || email != null) {
      map['email'] = Variable<String>(email);
    }
    if (!nullToAbsent || site != null) {
      map['site'] = Variable<String>(site);
    }
    if (!nullToAbsent || cpfCnpj != null) {
      map['cpf_cnpj'] = Variable<String>(cpfCnpj);
    }
    if (!nullToAbsent || rgIe != null) {
      map['rg_ie'] = Variable<String>(rgIe);
    }
    if (!nullToAbsent || matricula != null) {
      map['matricula'] = Variable<String>(matricula);
    }
    if (!nullToAbsent || dataCadastro != null) {
      map['data_cadastro'] = Variable<DateTime>(dataCadastro);
    }
    if (!nullToAbsent || dataAdmissao != null) {
      map['data_admissao'] = Variable<DateTime>(dataAdmissao);
    }
    if (!nullToAbsent || dataDemissao != null) {
      map['data_demissao'] = Variable<DateTime>(dataDemissao);
    }
    if (!nullToAbsent || ctpsNumero != null) {
      map['ctps_numero'] = Variable<String>(ctpsNumero);
    }
    if (!nullToAbsent || ctpsSerie != null) {
      map['ctps_serie'] = Variable<String>(ctpsSerie);
    }
    if (!nullToAbsent || ctpsDataExpedicao != null) {
      map['ctps_data_expedicao'] = Variable<DateTime>(ctpsDataExpedicao);
    }
    if (!nullToAbsent || ctpsUf != null) {
      map['ctps_uf'] = Variable<String>(ctpsUf);
    }
    if (!nullToAbsent || observacao != null) {
      map['observacao'] = Variable<String>(observacao);
    }
    if (!nullToAbsent || logradouro != null) {
      map['logradouro'] = Variable<String>(logradouro);
    }
    if (!nullToAbsent || numero != null) {
      map['numero'] = Variable<String>(numero);
    }
    if (!nullToAbsent || complemento != null) {
      map['complemento'] = Variable<String>(complemento);
    }
    if (!nullToAbsent || bairro != null) {
      map['bairro'] = Variable<String>(bairro);
    }
    if (!nullToAbsent || cidade != null) {
      map['cidade'] = Variable<String>(cidade);
    }
    if (!nullToAbsent || cep != null) {
      map['cep'] = Variable<String>(cep);
    }
    if (!nullToAbsent || municipioIbge != null) {
      map['municipio_ibge'] = Variable<String>(municipioIbge);
    }
    if (!nullToAbsent || uf != null) {
      map['uf'] = Variable<String>(uf);
    }
    if (!nullToAbsent || idPessoa != null) {
      map['id_pessoa'] = Variable<int>(idPessoa);
    }
    if (!nullToAbsent || idCargo != null) {
      map['id_cargo'] = Variable<int>(idCargo);
    }
    if (!nullToAbsent || idSetor != null) {
      map['id_setor'] = Variable<int>(idSetor);
    }
    return map;
  }

  factory ViewPessoaColaborador.fromJson(
    Map<String, dynamic> json, {
    ValueSerializer? serializer,
  }) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return ViewPessoaColaborador(
      id: serializer.fromJson<int?>(json['id']),
      nome: serializer.fromJson<String?>(json['nome']),
      tipo: serializer.fromJson<String?>(json['tipo']),
      email: serializer.fromJson<String?>(json['email']),
      site: serializer.fromJson<String?>(json['site']),
      cpfCnpj: serializer.fromJson<String?>(json['cpfCnpj']),
      rgIe: serializer.fromJson<String?>(json['rgIe']),
      matricula: serializer.fromJson<String?>(json['matricula']),
      dataCadastro: serializer.fromJson<DateTime?>(json['dataCadastro']),
      dataAdmissao: serializer.fromJson<DateTime?>(json['dataAdmissao']),
      dataDemissao: serializer.fromJson<DateTime?>(json['dataDemissao']),
      ctpsNumero: serializer.fromJson<String?>(json['ctpsNumero']),
      ctpsSerie: serializer.fromJson<String?>(json['ctpsSerie']),
      ctpsDataExpedicao: serializer.fromJson<DateTime?>(
        json['ctpsDataExpedicao'],
      ),
      ctpsUf: serializer.fromJson<String?>(json['ctpsUf']),
      observacao: serializer.fromJson<String?>(json['observacao']),
      logradouro: serializer.fromJson<String?>(json['logradouro']),
      numero: serializer.fromJson<String?>(json['numero']),
      complemento: serializer.fromJson<String?>(json['complemento']),
      bairro: serializer.fromJson<String?>(json['bairro']),
      cidade: serializer.fromJson<String?>(json['cidade']),
      cep: serializer.fromJson<String?>(json['cep']),
      municipioIbge: serializer.fromJson<String?>(json['municipioIbge']),
      uf: serializer.fromJson<String?>(json['uf']),
      idPessoa: serializer.fromJson<int?>(json['idPessoa']),
      idCargo: serializer.fromJson<int?>(json['idCargo']),
      idSetor: serializer.fromJson<int?>(json['idSetor']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'nome': serializer.toJson<String?>(nome),
      'tipo': serializer.toJson<String?>(tipo),
      'email': serializer.toJson<String?>(email),
      'site': serializer.toJson<String?>(site),
      'cpfCnpj': serializer.toJson<String?>(cpfCnpj),
      'rgIe': serializer.toJson<String?>(rgIe),
      'matricula': serializer.toJson<String?>(matricula),
      'dataCadastro': serializer.toJson<DateTime?>(dataCadastro),
      'dataAdmissao': serializer.toJson<DateTime?>(dataAdmissao),
      'dataDemissao': serializer.toJson<DateTime?>(dataDemissao),
      'ctpsNumero': serializer.toJson<String?>(ctpsNumero),
      'ctpsSerie': serializer.toJson<String?>(ctpsSerie),
      'ctpsDataExpedicao': serializer.toJson<DateTime?>(ctpsDataExpedicao),
      'ctpsUf': serializer.toJson<String?>(ctpsUf),
      'observacao': serializer.toJson<String?>(observacao),
      'logradouro': serializer.toJson<String?>(logradouro),
      'numero': serializer.toJson<String?>(numero),
      'complemento': serializer.toJson<String?>(complemento),
      'bairro': serializer.toJson<String?>(bairro),
      'cidade': serializer.toJson<String?>(cidade),
      'cep': serializer.toJson<String?>(cep),
      'municipioIbge': serializer.toJson<String?>(municipioIbge),
      'uf': serializer.toJson<String?>(uf),
      'idPessoa': serializer.toJson<int?>(idPessoa),
      'idCargo': serializer.toJson<int?>(idCargo),
      'idSetor': serializer.toJson<int?>(idSetor),
    };
  }

  ViewPessoaColaborador copyWith({
    Value<int?> id = const Value.absent(),
    Value<String?> nome = const Value.absent(),
    Value<String?> tipo = const Value.absent(),
    Value<String?> email = const Value.absent(),
    Value<String?> site = const Value.absent(),
    Value<String?> cpfCnpj = const Value.absent(),
    Value<String?> rgIe = const Value.absent(),
    Value<String?> matricula = const Value.absent(),
    Value<DateTime?> dataCadastro = const Value.absent(),
    Value<DateTime?> dataAdmissao = const Value.absent(),
    Value<DateTime?> dataDemissao = const Value.absent(),
    Value<String?> ctpsNumero = const Value.absent(),
    Value<String?> ctpsSerie = const Value.absent(),
    Value<DateTime?> ctpsDataExpedicao = const Value.absent(),
    Value<String?> ctpsUf = const Value.absent(),
    Value<String?> observacao = const Value.absent(),
    Value<String?> logradouro = const Value.absent(),
    Value<String?> numero = const Value.absent(),
    Value<String?> complemento = const Value.absent(),
    Value<String?> bairro = const Value.absent(),
    Value<String?> cidade = const Value.absent(),
    Value<String?> cep = const Value.absent(),
    Value<String?> municipioIbge = const Value.absent(),
    Value<String?> uf = const Value.absent(),
    Value<int?> idPessoa = const Value.absent(),
    Value<int?> idCargo = const Value.absent(),
    Value<int?> idSetor = const Value.absent(),
  }) => ViewPessoaColaborador(
    id: id.present ? id.value : this.id,
    nome: nome.present ? nome.value : this.nome,
    tipo: tipo.present ? tipo.value : this.tipo,
    email: email.present ? email.value : this.email,
    site: site.present ? site.value : this.site,
    cpfCnpj: cpfCnpj.present ? cpfCnpj.value : this.cpfCnpj,
    rgIe: rgIe.present ? rgIe.value : this.rgIe,
    matricula: matricula.present ? matricula.value : this.matricula,
    dataCadastro: dataCadastro.present ? dataCadastro.value : this.dataCadastro,
    dataAdmissao: dataAdmissao.present ? dataAdmissao.value : this.dataAdmissao,
    dataDemissao: dataDemissao.present ? dataDemissao.value : this.dataDemissao,
    ctpsNumero: ctpsNumero.present ? ctpsNumero.value : this.ctpsNumero,
    ctpsSerie: ctpsSerie.present ? ctpsSerie.value : this.ctpsSerie,
    ctpsDataExpedicao:
        ctpsDataExpedicao.present
            ? ctpsDataExpedicao.value
            : this.ctpsDataExpedicao,
    ctpsUf: ctpsUf.present ? ctpsUf.value : this.ctpsUf,
    observacao: observacao.present ? observacao.value : this.observacao,
    logradouro: logradouro.present ? logradouro.value : this.logradouro,
    numero: numero.present ? numero.value : this.numero,
    complemento: complemento.present ? complemento.value : this.complemento,
    bairro: bairro.present ? bairro.value : this.bairro,
    cidade: cidade.present ? cidade.value : this.cidade,
    cep: cep.present ? cep.value : this.cep,
    municipioIbge:
        municipioIbge.present ? municipioIbge.value : this.municipioIbge,
    uf: uf.present ? uf.value : this.uf,
    idPessoa: idPessoa.present ? idPessoa.value : this.idPessoa,
    idCargo: idCargo.present ? idCargo.value : this.idCargo,
    idSetor: idSetor.present ? idSetor.value : this.idSetor,
  );
  ViewPessoaColaborador copyWithCompanion(
    ViewPessoaColaboradorsCompanion data,
  ) {
    return ViewPessoaColaborador(
      id: data.id.present ? data.id.value : this.id,
      nome: data.nome.present ? data.nome.value : this.nome,
      tipo: data.tipo.present ? data.tipo.value : this.tipo,
      email: data.email.present ? data.email.value : this.email,
      site: data.site.present ? data.site.value : this.site,
      cpfCnpj: data.cpfCnpj.present ? data.cpfCnpj.value : this.cpfCnpj,
      rgIe: data.rgIe.present ? data.rgIe.value : this.rgIe,
      matricula: data.matricula.present ? data.matricula.value : this.matricula,
      dataCadastro:
          data.dataCadastro.present
              ? data.dataCadastro.value
              : this.dataCadastro,
      dataAdmissao:
          data.dataAdmissao.present
              ? data.dataAdmissao.value
              : this.dataAdmissao,
      dataDemissao:
          data.dataDemissao.present
              ? data.dataDemissao.value
              : this.dataDemissao,
      ctpsNumero:
          data.ctpsNumero.present ? data.ctpsNumero.value : this.ctpsNumero,
      ctpsSerie: data.ctpsSerie.present ? data.ctpsSerie.value : this.ctpsSerie,
      ctpsDataExpedicao:
          data.ctpsDataExpedicao.present
              ? data.ctpsDataExpedicao.value
              : this.ctpsDataExpedicao,
      ctpsUf: data.ctpsUf.present ? data.ctpsUf.value : this.ctpsUf,
      observacao:
          data.observacao.present ? data.observacao.value : this.observacao,
      logradouro:
          data.logradouro.present ? data.logradouro.value : this.logradouro,
      numero: data.numero.present ? data.numero.value : this.numero,
      complemento:
          data.complemento.present ? data.complemento.value : this.complemento,
      bairro: data.bairro.present ? data.bairro.value : this.bairro,
      cidade: data.cidade.present ? data.cidade.value : this.cidade,
      cep: data.cep.present ? data.cep.value : this.cep,
      municipioIbge:
          data.municipioIbge.present
              ? data.municipioIbge.value
              : this.municipioIbge,
      uf: data.uf.present ? data.uf.value : this.uf,
      idPessoa: data.idPessoa.present ? data.idPessoa.value : this.idPessoa,
      idCargo: data.idCargo.present ? data.idCargo.value : this.idCargo,
      idSetor: data.idSetor.present ? data.idSetor.value : this.idSetor,
    );
  }

  @override
  String toString() {
    return (StringBuffer('ViewPessoaColaborador(')
          ..write('id: $id, ')
          ..write('nome: $nome, ')
          ..write('tipo: $tipo, ')
          ..write('email: $email, ')
          ..write('site: $site, ')
          ..write('cpfCnpj: $cpfCnpj, ')
          ..write('rgIe: $rgIe, ')
          ..write('matricula: $matricula, ')
          ..write('dataCadastro: $dataCadastro, ')
          ..write('dataAdmissao: $dataAdmissao, ')
          ..write('dataDemissao: $dataDemissao, ')
          ..write('ctpsNumero: $ctpsNumero, ')
          ..write('ctpsSerie: $ctpsSerie, ')
          ..write('ctpsDataExpedicao: $ctpsDataExpedicao, ')
          ..write('ctpsUf: $ctpsUf, ')
          ..write('observacao: $observacao, ')
          ..write('logradouro: $logradouro, ')
          ..write('numero: $numero, ')
          ..write('complemento: $complemento, ')
          ..write('bairro: $bairro, ')
          ..write('cidade: $cidade, ')
          ..write('cep: $cep, ')
          ..write('municipioIbge: $municipioIbge, ')
          ..write('uf: $uf, ')
          ..write('idPessoa: $idPessoa, ')
          ..write('idCargo: $idCargo, ')
          ..write('idSetor: $idSetor')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hashAll([
    id,
    nome,
    tipo,
    email,
    site,
    cpfCnpj,
    rgIe,
    matricula,
    dataCadastro,
    dataAdmissao,
    dataDemissao,
    ctpsNumero,
    ctpsSerie,
    ctpsDataExpedicao,
    ctpsUf,
    observacao,
    logradouro,
    numero,
    complemento,
    bairro,
    cidade,
    cep,
    municipioIbge,
    uf,
    idPessoa,
    idCargo,
    idSetor,
  ]);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is ViewPessoaColaborador &&
          other.id == this.id &&
          other.nome == this.nome &&
          other.tipo == this.tipo &&
          other.email == this.email &&
          other.site == this.site &&
          other.cpfCnpj == this.cpfCnpj &&
          other.rgIe == this.rgIe &&
          other.matricula == this.matricula &&
          other.dataCadastro == this.dataCadastro &&
          other.dataAdmissao == this.dataAdmissao &&
          other.dataDemissao == this.dataDemissao &&
          other.ctpsNumero == this.ctpsNumero &&
          other.ctpsSerie == this.ctpsSerie &&
          other.ctpsDataExpedicao == this.ctpsDataExpedicao &&
          other.ctpsUf == this.ctpsUf &&
          other.observacao == this.observacao &&
          other.logradouro == this.logradouro &&
          other.numero == this.numero &&
          other.complemento == this.complemento &&
          other.bairro == this.bairro &&
          other.cidade == this.cidade &&
          other.cep == this.cep &&
          other.municipioIbge == this.municipioIbge &&
          other.uf == this.uf &&
          other.idPessoa == this.idPessoa &&
          other.idCargo == this.idCargo &&
          other.idSetor == this.idSetor);
}

class ViewPessoaColaboradorsCompanion
    extends UpdateCompanion<ViewPessoaColaborador> {
  final Value<int?> id;
  final Value<String?> nome;
  final Value<String?> tipo;
  final Value<String?> email;
  final Value<String?> site;
  final Value<String?> cpfCnpj;
  final Value<String?> rgIe;
  final Value<String?> matricula;
  final Value<DateTime?> dataCadastro;
  final Value<DateTime?> dataAdmissao;
  final Value<DateTime?> dataDemissao;
  final Value<String?> ctpsNumero;
  final Value<String?> ctpsSerie;
  final Value<DateTime?> ctpsDataExpedicao;
  final Value<String?> ctpsUf;
  final Value<String?> observacao;
  final Value<String?> logradouro;
  final Value<String?> numero;
  final Value<String?> complemento;
  final Value<String?> bairro;
  final Value<String?> cidade;
  final Value<String?> cep;
  final Value<String?> municipioIbge;
  final Value<String?> uf;
  final Value<int?> idPessoa;
  final Value<int?> idCargo;
  final Value<int?> idSetor;
  const ViewPessoaColaboradorsCompanion({
    this.id = const Value.absent(),
    this.nome = const Value.absent(),
    this.tipo = const Value.absent(),
    this.email = const Value.absent(),
    this.site = const Value.absent(),
    this.cpfCnpj = const Value.absent(),
    this.rgIe = const Value.absent(),
    this.matricula = const Value.absent(),
    this.dataCadastro = const Value.absent(),
    this.dataAdmissao = const Value.absent(),
    this.dataDemissao = const Value.absent(),
    this.ctpsNumero = const Value.absent(),
    this.ctpsSerie = const Value.absent(),
    this.ctpsDataExpedicao = const Value.absent(),
    this.ctpsUf = const Value.absent(),
    this.observacao = const Value.absent(),
    this.logradouro = const Value.absent(),
    this.numero = const Value.absent(),
    this.complemento = const Value.absent(),
    this.bairro = const Value.absent(),
    this.cidade = const Value.absent(),
    this.cep = const Value.absent(),
    this.municipioIbge = const Value.absent(),
    this.uf = const Value.absent(),
    this.idPessoa = const Value.absent(),
    this.idCargo = const Value.absent(),
    this.idSetor = const Value.absent(),
  });
  ViewPessoaColaboradorsCompanion.insert({
    this.id = const Value.absent(),
    this.nome = const Value.absent(),
    this.tipo = const Value.absent(),
    this.email = const Value.absent(),
    this.site = const Value.absent(),
    this.cpfCnpj = const Value.absent(),
    this.rgIe = const Value.absent(),
    this.matricula = const Value.absent(),
    this.dataCadastro = const Value.absent(),
    this.dataAdmissao = const Value.absent(),
    this.dataDemissao = const Value.absent(),
    this.ctpsNumero = const Value.absent(),
    this.ctpsSerie = const Value.absent(),
    this.ctpsDataExpedicao = const Value.absent(),
    this.ctpsUf = const Value.absent(),
    this.observacao = const Value.absent(),
    this.logradouro = const Value.absent(),
    this.numero = const Value.absent(),
    this.complemento = const Value.absent(),
    this.bairro = const Value.absent(),
    this.cidade = const Value.absent(),
    this.cep = const Value.absent(),
    this.municipioIbge = const Value.absent(),
    this.uf = const Value.absent(),
    this.idPessoa = const Value.absent(),
    this.idCargo = const Value.absent(),
    this.idSetor = const Value.absent(),
  });
  static Insertable<ViewPessoaColaborador> custom({
    Expression<int>? id,
    Expression<String>? nome,
    Expression<String>? tipo,
    Expression<String>? email,
    Expression<String>? site,
    Expression<String>? cpfCnpj,
    Expression<String>? rgIe,
    Expression<String>? matricula,
    Expression<DateTime>? dataCadastro,
    Expression<DateTime>? dataAdmissao,
    Expression<DateTime>? dataDemissao,
    Expression<String>? ctpsNumero,
    Expression<String>? ctpsSerie,
    Expression<DateTime>? ctpsDataExpedicao,
    Expression<String>? ctpsUf,
    Expression<String>? observacao,
    Expression<String>? logradouro,
    Expression<String>? numero,
    Expression<String>? complemento,
    Expression<String>? bairro,
    Expression<String>? cidade,
    Expression<String>? cep,
    Expression<String>? municipioIbge,
    Expression<String>? uf,
    Expression<int>? idPessoa,
    Expression<int>? idCargo,
    Expression<int>? idSetor,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (nome != null) 'nome': nome,
      if (tipo != null) 'tipo': tipo,
      if (email != null) 'email': email,
      if (site != null) 'site': site,
      if (cpfCnpj != null) 'cpf_cnpj': cpfCnpj,
      if (rgIe != null) 'rg_ie': rgIe,
      if (matricula != null) 'matricula': matricula,
      if (dataCadastro != null) 'data_cadastro': dataCadastro,
      if (dataAdmissao != null) 'data_admissao': dataAdmissao,
      if (dataDemissao != null) 'data_demissao': dataDemissao,
      if (ctpsNumero != null) 'ctps_numero': ctpsNumero,
      if (ctpsSerie != null) 'ctps_serie': ctpsSerie,
      if (ctpsDataExpedicao != null) 'ctps_data_expedicao': ctpsDataExpedicao,
      if (ctpsUf != null) 'ctps_uf': ctpsUf,
      if (observacao != null) 'observacao': observacao,
      if (logradouro != null) 'logradouro': logradouro,
      if (numero != null) 'numero': numero,
      if (complemento != null) 'complemento': complemento,
      if (bairro != null) 'bairro': bairro,
      if (cidade != null) 'cidade': cidade,
      if (cep != null) 'cep': cep,
      if (municipioIbge != null) 'municipio_ibge': municipioIbge,
      if (uf != null) 'uf': uf,
      if (idPessoa != null) 'id_pessoa': idPessoa,
      if (idCargo != null) 'id_cargo': idCargo,
      if (idSetor != null) 'id_setor': idSetor,
    });
  }

  ViewPessoaColaboradorsCompanion copyWith({
    Value<int?>? id,
    Value<String?>? nome,
    Value<String?>? tipo,
    Value<String?>? email,
    Value<String?>? site,
    Value<String?>? cpfCnpj,
    Value<String?>? rgIe,
    Value<String?>? matricula,
    Value<DateTime?>? dataCadastro,
    Value<DateTime?>? dataAdmissao,
    Value<DateTime?>? dataDemissao,
    Value<String?>? ctpsNumero,
    Value<String?>? ctpsSerie,
    Value<DateTime?>? ctpsDataExpedicao,
    Value<String?>? ctpsUf,
    Value<String?>? observacao,
    Value<String?>? logradouro,
    Value<String?>? numero,
    Value<String?>? complemento,
    Value<String?>? bairro,
    Value<String?>? cidade,
    Value<String?>? cep,
    Value<String?>? municipioIbge,
    Value<String?>? uf,
    Value<int?>? idPessoa,
    Value<int?>? idCargo,
    Value<int?>? idSetor,
  }) {
    return ViewPessoaColaboradorsCompanion(
      id: id ?? this.id,
      nome: nome ?? this.nome,
      tipo: tipo ?? this.tipo,
      email: email ?? this.email,
      site: site ?? this.site,
      cpfCnpj: cpfCnpj ?? this.cpfCnpj,
      rgIe: rgIe ?? this.rgIe,
      matricula: matricula ?? this.matricula,
      dataCadastro: dataCadastro ?? this.dataCadastro,
      dataAdmissao: dataAdmissao ?? this.dataAdmissao,
      dataDemissao: dataDemissao ?? this.dataDemissao,
      ctpsNumero: ctpsNumero ?? this.ctpsNumero,
      ctpsSerie: ctpsSerie ?? this.ctpsSerie,
      ctpsDataExpedicao: ctpsDataExpedicao ?? this.ctpsDataExpedicao,
      ctpsUf: ctpsUf ?? this.ctpsUf,
      observacao: observacao ?? this.observacao,
      logradouro: logradouro ?? this.logradouro,
      numero: numero ?? this.numero,
      complemento: complemento ?? this.complemento,
      bairro: bairro ?? this.bairro,
      cidade: cidade ?? this.cidade,
      cep: cep ?? this.cep,
      municipioIbge: municipioIbge ?? this.municipioIbge,
      uf: uf ?? this.uf,
      idPessoa: idPessoa ?? this.idPessoa,
      idCargo: idCargo ?? this.idCargo,
      idSetor: idSetor ?? this.idSetor,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (nome.present) {
      map['nome'] = Variable<String>(nome.value);
    }
    if (tipo.present) {
      map['tipo'] = Variable<String>(tipo.value);
    }
    if (email.present) {
      map['email'] = Variable<String>(email.value);
    }
    if (site.present) {
      map['site'] = Variable<String>(site.value);
    }
    if (cpfCnpj.present) {
      map['cpf_cnpj'] = Variable<String>(cpfCnpj.value);
    }
    if (rgIe.present) {
      map['rg_ie'] = Variable<String>(rgIe.value);
    }
    if (matricula.present) {
      map['matricula'] = Variable<String>(matricula.value);
    }
    if (dataCadastro.present) {
      map['data_cadastro'] = Variable<DateTime>(dataCadastro.value);
    }
    if (dataAdmissao.present) {
      map['data_admissao'] = Variable<DateTime>(dataAdmissao.value);
    }
    if (dataDemissao.present) {
      map['data_demissao'] = Variable<DateTime>(dataDemissao.value);
    }
    if (ctpsNumero.present) {
      map['ctps_numero'] = Variable<String>(ctpsNumero.value);
    }
    if (ctpsSerie.present) {
      map['ctps_serie'] = Variable<String>(ctpsSerie.value);
    }
    if (ctpsDataExpedicao.present) {
      map['ctps_data_expedicao'] = Variable<DateTime>(ctpsDataExpedicao.value);
    }
    if (ctpsUf.present) {
      map['ctps_uf'] = Variable<String>(ctpsUf.value);
    }
    if (observacao.present) {
      map['observacao'] = Variable<String>(observacao.value);
    }
    if (logradouro.present) {
      map['logradouro'] = Variable<String>(logradouro.value);
    }
    if (numero.present) {
      map['numero'] = Variable<String>(numero.value);
    }
    if (complemento.present) {
      map['complemento'] = Variable<String>(complemento.value);
    }
    if (bairro.present) {
      map['bairro'] = Variable<String>(bairro.value);
    }
    if (cidade.present) {
      map['cidade'] = Variable<String>(cidade.value);
    }
    if (cep.present) {
      map['cep'] = Variable<String>(cep.value);
    }
    if (municipioIbge.present) {
      map['municipio_ibge'] = Variable<String>(municipioIbge.value);
    }
    if (uf.present) {
      map['uf'] = Variable<String>(uf.value);
    }
    if (idPessoa.present) {
      map['id_pessoa'] = Variable<int>(idPessoa.value);
    }
    if (idCargo.present) {
      map['id_cargo'] = Variable<int>(idCargo.value);
    }
    if (idSetor.present) {
      map['id_setor'] = Variable<int>(idSetor.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('ViewPessoaColaboradorsCompanion(')
          ..write('id: $id, ')
          ..write('nome: $nome, ')
          ..write('tipo: $tipo, ')
          ..write('email: $email, ')
          ..write('site: $site, ')
          ..write('cpfCnpj: $cpfCnpj, ')
          ..write('rgIe: $rgIe, ')
          ..write('matricula: $matricula, ')
          ..write('dataCadastro: $dataCadastro, ')
          ..write('dataAdmissao: $dataAdmissao, ')
          ..write('dataDemissao: $dataDemissao, ')
          ..write('ctpsNumero: $ctpsNumero, ')
          ..write('ctpsSerie: $ctpsSerie, ')
          ..write('ctpsDataExpedicao: $ctpsDataExpedicao, ')
          ..write('ctpsUf: $ctpsUf, ')
          ..write('observacao: $observacao, ')
          ..write('logradouro: $logradouro, ')
          ..write('numero: $numero, ')
          ..write('complemento: $complemento, ')
          ..write('bairro: $bairro, ')
          ..write('cidade: $cidade, ')
          ..write('cep: $cep, ')
          ..write('municipioIbge: $municipioIbge, ')
          ..write('uf: $uf, ')
          ..write('idPessoa: $idPessoa, ')
          ..write('idCargo: $idCargo, ')
          ..write('idSetor: $idSetor')
          ..write(')'))
        .toString();
  }
}

abstract class _$AppDatabase extends GeneratedDatabase {
  _$AppDatabase(QueryExecutor e) : super(e);
  $AppDatabaseManager get managers => $AppDatabaseManager(this);
  late final $AgendaNotificacaosTable agendaNotificacaos =
      $AgendaNotificacaosTable(this);
  late final $AgendaCompromissoConvidadosTable agendaCompromissoConvidados =
      $AgendaCompromissoConvidadosTable(this);
  late final $ReuniaoSalaEventosTable reuniaoSalaEventos =
      $ReuniaoSalaEventosTable(this);
  late final $RecadoDestinatariosTable recadoDestinatarios =
      $RecadoDestinatariosTable(this);
  late final $AgendaCompromissosTable agendaCompromissos =
      $AgendaCompromissosTable(this);
  late final $RecadoRemetentesTable recadoRemetentes = $RecadoRemetentesTable(
    this,
  );
  late final $AgendaCategoriaCompromissosTable agendaCategoriaCompromissos =
      $AgendaCategoriaCompromissosTable(this);
  late final $ReuniaoSalasTable reuniaoSalas = $ReuniaoSalasTable(this);
  late final $ViewControleAcessosTable viewControleAcessos =
      $ViewControleAcessosTable(this);
  late final $ViewPessoaUsuariosTable viewPessoaUsuarios =
      $ViewPessoaUsuariosTable(this);
  late final $ViewPessoaColaboradorsTable viewPessoaColaboradors =
      $ViewPessoaColaboradorsTable(this);
  late final AgendaCompromissoDao agendaCompromissoDao = AgendaCompromissoDao(
    this as AppDatabase,
  );
  late final RecadoRemetenteDao recadoRemetenteDao = RecadoRemetenteDao(
    this as AppDatabase,
  );
  late final AgendaCategoriaCompromissoDao agendaCategoriaCompromissoDao =
      AgendaCategoriaCompromissoDao(this as AppDatabase);
  late final ReuniaoSalaDao reuniaoSalaDao = ReuniaoSalaDao(
    this as AppDatabase,
  );
  late final ViewControleAcessoDao viewControleAcessoDao =
      ViewControleAcessoDao(this as AppDatabase);
  late final ViewPessoaUsuarioDao viewPessoaUsuarioDao = ViewPessoaUsuarioDao(
    this as AppDatabase,
  );
  late final ViewPessoaColaboradorDao viewPessoaColaboradorDao =
      ViewPessoaColaboradorDao(this as AppDatabase);
  @override
  Iterable<TableInfo<Table, Object?>> get allTables =>
      allSchemaEntities.whereType<TableInfo<Table, Object?>>();
  @override
  List<DatabaseSchemaEntity> get allSchemaEntities => [
    agendaNotificacaos,
    agendaCompromissoConvidados,
    reuniaoSalaEventos,
    recadoDestinatarios,
    agendaCompromissos,
    recadoRemetentes,
    agendaCategoriaCompromissos,
    reuniaoSalas,
    viewControleAcessos,
    viewPessoaUsuarios,
    viewPessoaColaboradors,
  ];
}

typedef $$AgendaNotificacaosTableCreateCompanionBuilder =
    AgendaNotificacaosCompanion Function({
      Value<int?> id,
      Value<int?> idAgendaCompromisso,
      Value<DateTime?> dataNotificacao,
      Value<String?> hora,
      Value<String?> tipo,
    });
typedef $$AgendaNotificacaosTableUpdateCompanionBuilder =
    AgendaNotificacaosCompanion Function({
      Value<int?> id,
      Value<int?> idAgendaCompromisso,
      Value<DateTime?> dataNotificacao,
      Value<String?> hora,
      Value<String?> tipo,
    });

class $$AgendaNotificacaosTableFilterComposer
    extends Composer<_$AppDatabase, $AgendaNotificacaosTable> {
  $$AgendaNotificacaosTableFilterComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnFilters<int> get id => $composableBuilder(
    column: $table.id,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<int> get idAgendaCompromisso => $composableBuilder(
    column: $table.idAgendaCompromisso,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<DateTime> get dataNotificacao => $composableBuilder(
    column: $table.dataNotificacao,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get hora => $composableBuilder(
    column: $table.hora,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get tipo => $composableBuilder(
    column: $table.tipo,
    builder: (column) => ColumnFilters(column),
  );
}

class $$AgendaNotificacaosTableOrderingComposer
    extends Composer<_$AppDatabase, $AgendaNotificacaosTable> {
  $$AgendaNotificacaosTableOrderingComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnOrderings<int> get id => $composableBuilder(
    column: $table.id,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<int> get idAgendaCompromisso => $composableBuilder(
    column: $table.idAgendaCompromisso,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<DateTime> get dataNotificacao => $composableBuilder(
    column: $table.dataNotificacao,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get hora => $composableBuilder(
    column: $table.hora,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get tipo => $composableBuilder(
    column: $table.tipo,
    builder: (column) => ColumnOrderings(column),
  );
}

class $$AgendaNotificacaosTableAnnotationComposer
    extends Composer<_$AppDatabase, $AgendaNotificacaosTable> {
  $$AgendaNotificacaosTableAnnotationComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  GeneratedColumn<int> get id =>
      $composableBuilder(column: $table.id, builder: (column) => column);

  GeneratedColumn<int> get idAgendaCompromisso => $composableBuilder(
    column: $table.idAgendaCompromisso,
    builder: (column) => column,
  );

  GeneratedColumn<DateTime> get dataNotificacao => $composableBuilder(
    column: $table.dataNotificacao,
    builder: (column) => column,
  );

  GeneratedColumn<String> get hora =>
      $composableBuilder(column: $table.hora, builder: (column) => column);

  GeneratedColumn<String> get tipo =>
      $composableBuilder(column: $table.tipo, builder: (column) => column);
}

class $$AgendaNotificacaosTableTableManager
    extends
        RootTableManager<
          _$AppDatabase,
          $AgendaNotificacaosTable,
          AgendaNotificacao,
          $$AgendaNotificacaosTableFilterComposer,
          $$AgendaNotificacaosTableOrderingComposer,
          $$AgendaNotificacaosTableAnnotationComposer,
          $$AgendaNotificacaosTableCreateCompanionBuilder,
          $$AgendaNotificacaosTableUpdateCompanionBuilder,
          (
            AgendaNotificacao,
            BaseReferences<
              _$AppDatabase,
              $AgendaNotificacaosTable,
              AgendaNotificacao
            >,
          ),
          AgendaNotificacao,
          PrefetchHooks Function()
        > {
  $$AgendaNotificacaosTableTableManager(
    _$AppDatabase db,
    $AgendaNotificacaosTable table,
  ) : super(
        TableManagerState(
          db: db,
          table: table,
          createFilteringComposer:
              () => $$AgendaNotificacaosTableFilterComposer(
                $db: db,
                $table: table,
              ),
          createOrderingComposer:
              () => $$AgendaNotificacaosTableOrderingComposer(
                $db: db,
                $table: table,
              ),
          createComputedFieldComposer:
              () => $$AgendaNotificacaosTableAnnotationComposer(
                $db: db,
                $table: table,
              ),
          updateCompanionCallback:
              ({
                Value<int?> id = const Value.absent(),
                Value<int?> idAgendaCompromisso = const Value.absent(),
                Value<DateTime?> dataNotificacao = const Value.absent(),
                Value<String?> hora = const Value.absent(),
                Value<String?> tipo = const Value.absent(),
              }) => AgendaNotificacaosCompanion(
                id: id,
                idAgendaCompromisso: idAgendaCompromisso,
                dataNotificacao: dataNotificacao,
                hora: hora,
                tipo: tipo,
              ),
          createCompanionCallback:
              ({
                Value<int?> id = const Value.absent(),
                Value<int?> idAgendaCompromisso = const Value.absent(),
                Value<DateTime?> dataNotificacao = const Value.absent(),
                Value<String?> hora = const Value.absent(),
                Value<String?> tipo = const Value.absent(),
              }) => AgendaNotificacaosCompanion.insert(
                id: id,
                idAgendaCompromisso: idAgendaCompromisso,
                dataNotificacao: dataNotificacao,
                hora: hora,
                tipo: tipo,
              ),
          withReferenceMapper:
              (p0) =>
                  p0
                      .map(
                        (e) => (
                          e.readTable(table),
                          BaseReferences(db, table, e),
                        ),
                      )
                      .toList(),
          prefetchHooksCallback: null,
        ),
      );
}

typedef $$AgendaNotificacaosTableProcessedTableManager =
    ProcessedTableManager<
      _$AppDatabase,
      $AgendaNotificacaosTable,
      AgendaNotificacao,
      $$AgendaNotificacaosTableFilterComposer,
      $$AgendaNotificacaosTableOrderingComposer,
      $$AgendaNotificacaosTableAnnotationComposer,
      $$AgendaNotificacaosTableCreateCompanionBuilder,
      $$AgendaNotificacaosTableUpdateCompanionBuilder,
      (
        AgendaNotificacao,
        BaseReferences<
          _$AppDatabase,
          $AgendaNotificacaosTable,
          AgendaNotificacao
        >,
      ),
      AgendaNotificacao,
      PrefetchHooks Function()
    >;
typedef $$AgendaCompromissoConvidadosTableCreateCompanionBuilder =
    AgendaCompromissoConvidadosCompanion Function({
      Value<int?> id,
      Value<int?> idAgendaCompromisso,
      Value<int?> idColaborador,
    });
typedef $$AgendaCompromissoConvidadosTableUpdateCompanionBuilder =
    AgendaCompromissoConvidadosCompanion Function({
      Value<int?> id,
      Value<int?> idAgendaCompromisso,
      Value<int?> idColaborador,
    });

class $$AgendaCompromissoConvidadosTableFilterComposer
    extends Composer<_$AppDatabase, $AgendaCompromissoConvidadosTable> {
  $$AgendaCompromissoConvidadosTableFilterComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnFilters<int> get id => $composableBuilder(
    column: $table.id,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<int> get idAgendaCompromisso => $composableBuilder(
    column: $table.idAgendaCompromisso,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<int> get idColaborador => $composableBuilder(
    column: $table.idColaborador,
    builder: (column) => ColumnFilters(column),
  );
}

class $$AgendaCompromissoConvidadosTableOrderingComposer
    extends Composer<_$AppDatabase, $AgendaCompromissoConvidadosTable> {
  $$AgendaCompromissoConvidadosTableOrderingComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnOrderings<int> get id => $composableBuilder(
    column: $table.id,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<int> get idAgendaCompromisso => $composableBuilder(
    column: $table.idAgendaCompromisso,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<int> get idColaborador => $composableBuilder(
    column: $table.idColaborador,
    builder: (column) => ColumnOrderings(column),
  );
}

class $$AgendaCompromissoConvidadosTableAnnotationComposer
    extends Composer<_$AppDatabase, $AgendaCompromissoConvidadosTable> {
  $$AgendaCompromissoConvidadosTableAnnotationComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  GeneratedColumn<int> get id =>
      $composableBuilder(column: $table.id, builder: (column) => column);

  GeneratedColumn<int> get idAgendaCompromisso => $composableBuilder(
    column: $table.idAgendaCompromisso,
    builder: (column) => column,
  );

  GeneratedColumn<int> get idColaborador => $composableBuilder(
    column: $table.idColaborador,
    builder: (column) => column,
  );
}

class $$AgendaCompromissoConvidadosTableTableManager
    extends
        RootTableManager<
          _$AppDatabase,
          $AgendaCompromissoConvidadosTable,
          AgendaCompromissoConvidado,
          $$AgendaCompromissoConvidadosTableFilterComposer,
          $$AgendaCompromissoConvidadosTableOrderingComposer,
          $$AgendaCompromissoConvidadosTableAnnotationComposer,
          $$AgendaCompromissoConvidadosTableCreateCompanionBuilder,
          $$AgendaCompromissoConvidadosTableUpdateCompanionBuilder,
          (
            AgendaCompromissoConvidado,
            BaseReferences<
              _$AppDatabase,
              $AgendaCompromissoConvidadosTable,
              AgendaCompromissoConvidado
            >,
          ),
          AgendaCompromissoConvidado,
          PrefetchHooks Function()
        > {
  $$AgendaCompromissoConvidadosTableTableManager(
    _$AppDatabase db,
    $AgendaCompromissoConvidadosTable table,
  ) : super(
        TableManagerState(
          db: db,
          table: table,
          createFilteringComposer:
              () => $$AgendaCompromissoConvidadosTableFilterComposer(
                $db: db,
                $table: table,
              ),
          createOrderingComposer:
              () => $$AgendaCompromissoConvidadosTableOrderingComposer(
                $db: db,
                $table: table,
              ),
          createComputedFieldComposer:
              () => $$AgendaCompromissoConvidadosTableAnnotationComposer(
                $db: db,
                $table: table,
              ),
          updateCompanionCallback:
              ({
                Value<int?> id = const Value.absent(),
                Value<int?> idAgendaCompromisso = const Value.absent(),
                Value<int?> idColaborador = const Value.absent(),
              }) => AgendaCompromissoConvidadosCompanion(
                id: id,
                idAgendaCompromisso: idAgendaCompromisso,
                idColaborador: idColaborador,
              ),
          createCompanionCallback:
              ({
                Value<int?> id = const Value.absent(),
                Value<int?> idAgendaCompromisso = const Value.absent(),
                Value<int?> idColaborador = const Value.absent(),
              }) => AgendaCompromissoConvidadosCompanion.insert(
                id: id,
                idAgendaCompromisso: idAgendaCompromisso,
                idColaborador: idColaborador,
              ),
          withReferenceMapper:
              (p0) =>
                  p0
                      .map(
                        (e) => (
                          e.readTable(table),
                          BaseReferences(db, table, e),
                        ),
                      )
                      .toList(),
          prefetchHooksCallback: null,
        ),
      );
}

typedef $$AgendaCompromissoConvidadosTableProcessedTableManager =
    ProcessedTableManager<
      _$AppDatabase,
      $AgendaCompromissoConvidadosTable,
      AgendaCompromissoConvidado,
      $$AgendaCompromissoConvidadosTableFilterComposer,
      $$AgendaCompromissoConvidadosTableOrderingComposer,
      $$AgendaCompromissoConvidadosTableAnnotationComposer,
      $$AgendaCompromissoConvidadosTableCreateCompanionBuilder,
      $$AgendaCompromissoConvidadosTableUpdateCompanionBuilder,
      (
        AgendaCompromissoConvidado,
        BaseReferences<
          _$AppDatabase,
          $AgendaCompromissoConvidadosTable,
          AgendaCompromissoConvidado
        >,
      ),
      AgendaCompromissoConvidado,
      PrefetchHooks Function()
    >;
typedef $$ReuniaoSalaEventosTableCreateCompanionBuilder =
    ReuniaoSalaEventosCompanion Function({
      Value<int?> id,
      Value<int?> idAgendaCompromisso,
      Value<int?> idReuniaoSala,
      Value<DateTime?> dataReserva,
    });
typedef $$ReuniaoSalaEventosTableUpdateCompanionBuilder =
    ReuniaoSalaEventosCompanion Function({
      Value<int?> id,
      Value<int?> idAgendaCompromisso,
      Value<int?> idReuniaoSala,
      Value<DateTime?> dataReserva,
    });

class $$ReuniaoSalaEventosTableFilterComposer
    extends Composer<_$AppDatabase, $ReuniaoSalaEventosTable> {
  $$ReuniaoSalaEventosTableFilterComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnFilters<int> get id => $composableBuilder(
    column: $table.id,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<int> get idAgendaCompromisso => $composableBuilder(
    column: $table.idAgendaCompromisso,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<int> get idReuniaoSala => $composableBuilder(
    column: $table.idReuniaoSala,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<DateTime> get dataReserva => $composableBuilder(
    column: $table.dataReserva,
    builder: (column) => ColumnFilters(column),
  );
}

class $$ReuniaoSalaEventosTableOrderingComposer
    extends Composer<_$AppDatabase, $ReuniaoSalaEventosTable> {
  $$ReuniaoSalaEventosTableOrderingComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnOrderings<int> get id => $composableBuilder(
    column: $table.id,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<int> get idAgendaCompromisso => $composableBuilder(
    column: $table.idAgendaCompromisso,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<int> get idReuniaoSala => $composableBuilder(
    column: $table.idReuniaoSala,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<DateTime> get dataReserva => $composableBuilder(
    column: $table.dataReserva,
    builder: (column) => ColumnOrderings(column),
  );
}

class $$ReuniaoSalaEventosTableAnnotationComposer
    extends Composer<_$AppDatabase, $ReuniaoSalaEventosTable> {
  $$ReuniaoSalaEventosTableAnnotationComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  GeneratedColumn<int> get id =>
      $composableBuilder(column: $table.id, builder: (column) => column);

  GeneratedColumn<int> get idAgendaCompromisso => $composableBuilder(
    column: $table.idAgendaCompromisso,
    builder: (column) => column,
  );

  GeneratedColumn<int> get idReuniaoSala => $composableBuilder(
    column: $table.idReuniaoSala,
    builder: (column) => column,
  );

  GeneratedColumn<DateTime> get dataReserva => $composableBuilder(
    column: $table.dataReserva,
    builder: (column) => column,
  );
}

class $$ReuniaoSalaEventosTableTableManager
    extends
        RootTableManager<
          _$AppDatabase,
          $ReuniaoSalaEventosTable,
          ReuniaoSalaEvento,
          $$ReuniaoSalaEventosTableFilterComposer,
          $$ReuniaoSalaEventosTableOrderingComposer,
          $$ReuniaoSalaEventosTableAnnotationComposer,
          $$ReuniaoSalaEventosTableCreateCompanionBuilder,
          $$ReuniaoSalaEventosTableUpdateCompanionBuilder,
          (
            ReuniaoSalaEvento,
            BaseReferences<
              _$AppDatabase,
              $ReuniaoSalaEventosTable,
              ReuniaoSalaEvento
            >,
          ),
          ReuniaoSalaEvento,
          PrefetchHooks Function()
        > {
  $$ReuniaoSalaEventosTableTableManager(
    _$AppDatabase db,
    $ReuniaoSalaEventosTable table,
  ) : super(
        TableManagerState(
          db: db,
          table: table,
          createFilteringComposer:
              () => $$ReuniaoSalaEventosTableFilterComposer(
                $db: db,
                $table: table,
              ),
          createOrderingComposer:
              () => $$ReuniaoSalaEventosTableOrderingComposer(
                $db: db,
                $table: table,
              ),
          createComputedFieldComposer:
              () => $$ReuniaoSalaEventosTableAnnotationComposer(
                $db: db,
                $table: table,
              ),
          updateCompanionCallback:
              ({
                Value<int?> id = const Value.absent(),
                Value<int?> idAgendaCompromisso = const Value.absent(),
                Value<int?> idReuniaoSala = const Value.absent(),
                Value<DateTime?> dataReserva = const Value.absent(),
              }) => ReuniaoSalaEventosCompanion(
                id: id,
                idAgendaCompromisso: idAgendaCompromisso,
                idReuniaoSala: idReuniaoSala,
                dataReserva: dataReserva,
              ),
          createCompanionCallback:
              ({
                Value<int?> id = const Value.absent(),
                Value<int?> idAgendaCompromisso = const Value.absent(),
                Value<int?> idReuniaoSala = const Value.absent(),
                Value<DateTime?> dataReserva = const Value.absent(),
              }) => ReuniaoSalaEventosCompanion.insert(
                id: id,
                idAgendaCompromisso: idAgendaCompromisso,
                idReuniaoSala: idReuniaoSala,
                dataReserva: dataReserva,
              ),
          withReferenceMapper:
              (p0) =>
                  p0
                      .map(
                        (e) => (
                          e.readTable(table),
                          BaseReferences(db, table, e),
                        ),
                      )
                      .toList(),
          prefetchHooksCallback: null,
        ),
      );
}

typedef $$ReuniaoSalaEventosTableProcessedTableManager =
    ProcessedTableManager<
      _$AppDatabase,
      $ReuniaoSalaEventosTable,
      ReuniaoSalaEvento,
      $$ReuniaoSalaEventosTableFilterComposer,
      $$ReuniaoSalaEventosTableOrderingComposer,
      $$ReuniaoSalaEventosTableAnnotationComposer,
      $$ReuniaoSalaEventosTableCreateCompanionBuilder,
      $$ReuniaoSalaEventosTableUpdateCompanionBuilder,
      (
        ReuniaoSalaEvento,
        BaseReferences<
          _$AppDatabase,
          $ReuniaoSalaEventosTable,
          ReuniaoSalaEvento
        >,
      ),
      ReuniaoSalaEvento,
      PrefetchHooks Function()
    >;
typedef $$RecadoDestinatariosTableCreateCompanionBuilder =
    RecadoDestinatariosCompanion Function({
      Value<int?> id,
      Value<int?> idColaborador,
      Value<int?> idRecadoRemetente,
    });
typedef $$RecadoDestinatariosTableUpdateCompanionBuilder =
    RecadoDestinatariosCompanion Function({
      Value<int?> id,
      Value<int?> idColaborador,
      Value<int?> idRecadoRemetente,
    });

class $$RecadoDestinatariosTableFilterComposer
    extends Composer<_$AppDatabase, $RecadoDestinatariosTable> {
  $$RecadoDestinatariosTableFilterComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnFilters<int> get id => $composableBuilder(
    column: $table.id,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<int> get idColaborador => $composableBuilder(
    column: $table.idColaborador,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<int> get idRecadoRemetente => $composableBuilder(
    column: $table.idRecadoRemetente,
    builder: (column) => ColumnFilters(column),
  );
}

class $$RecadoDestinatariosTableOrderingComposer
    extends Composer<_$AppDatabase, $RecadoDestinatariosTable> {
  $$RecadoDestinatariosTableOrderingComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnOrderings<int> get id => $composableBuilder(
    column: $table.id,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<int> get idColaborador => $composableBuilder(
    column: $table.idColaborador,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<int> get idRecadoRemetente => $composableBuilder(
    column: $table.idRecadoRemetente,
    builder: (column) => ColumnOrderings(column),
  );
}

class $$RecadoDestinatariosTableAnnotationComposer
    extends Composer<_$AppDatabase, $RecadoDestinatariosTable> {
  $$RecadoDestinatariosTableAnnotationComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  GeneratedColumn<int> get id =>
      $composableBuilder(column: $table.id, builder: (column) => column);

  GeneratedColumn<int> get idColaborador => $composableBuilder(
    column: $table.idColaborador,
    builder: (column) => column,
  );

  GeneratedColumn<int> get idRecadoRemetente => $composableBuilder(
    column: $table.idRecadoRemetente,
    builder: (column) => column,
  );
}

class $$RecadoDestinatariosTableTableManager
    extends
        RootTableManager<
          _$AppDatabase,
          $RecadoDestinatariosTable,
          RecadoDestinatario,
          $$RecadoDestinatariosTableFilterComposer,
          $$RecadoDestinatariosTableOrderingComposer,
          $$RecadoDestinatariosTableAnnotationComposer,
          $$RecadoDestinatariosTableCreateCompanionBuilder,
          $$RecadoDestinatariosTableUpdateCompanionBuilder,
          (
            RecadoDestinatario,
            BaseReferences<
              _$AppDatabase,
              $RecadoDestinatariosTable,
              RecadoDestinatario
            >,
          ),
          RecadoDestinatario,
          PrefetchHooks Function()
        > {
  $$RecadoDestinatariosTableTableManager(
    _$AppDatabase db,
    $RecadoDestinatariosTable table,
  ) : super(
        TableManagerState(
          db: db,
          table: table,
          createFilteringComposer:
              () => $$RecadoDestinatariosTableFilterComposer(
                $db: db,
                $table: table,
              ),
          createOrderingComposer:
              () => $$RecadoDestinatariosTableOrderingComposer(
                $db: db,
                $table: table,
              ),
          createComputedFieldComposer:
              () => $$RecadoDestinatariosTableAnnotationComposer(
                $db: db,
                $table: table,
              ),
          updateCompanionCallback:
              ({
                Value<int?> id = const Value.absent(),
                Value<int?> idColaborador = const Value.absent(),
                Value<int?> idRecadoRemetente = const Value.absent(),
              }) => RecadoDestinatariosCompanion(
                id: id,
                idColaborador: idColaborador,
                idRecadoRemetente: idRecadoRemetente,
              ),
          createCompanionCallback:
              ({
                Value<int?> id = const Value.absent(),
                Value<int?> idColaborador = const Value.absent(),
                Value<int?> idRecadoRemetente = const Value.absent(),
              }) => RecadoDestinatariosCompanion.insert(
                id: id,
                idColaborador: idColaborador,
                idRecadoRemetente: idRecadoRemetente,
              ),
          withReferenceMapper:
              (p0) =>
                  p0
                      .map(
                        (e) => (
                          e.readTable(table),
                          BaseReferences(db, table, e),
                        ),
                      )
                      .toList(),
          prefetchHooksCallback: null,
        ),
      );
}

typedef $$RecadoDestinatariosTableProcessedTableManager =
    ProcessedTableManager<
      _$AppDatabase,
      $RecadoDestinatariosTable,
      RecadoDestinatario,
      $$RecadoDestinatariosTableFilterComposer,
      $$RecadoDestinatariosTableOrderingComposer,
      $$RecadoDestinatariosTableAnnotationComposer,
      $$RecadoDestinatariosTableCreateCompanionBuilder,
      $$RecadoDestinatariosTableUpdateCompanionBuilder,
      (
        RecadoDestinatario,
        BaseReferences<
          _$AppDatabase,
          $RecadoDestinatariosTable,
          RecadoDestinatario
        >,
      ),
      RecadoDestinatario,
      PrefetchHooks Function()
    >;
typedef $$AgendaCompromissosTableCreateCompanionBuilder =
    AgendaCompromissosCompanion Function({
      Value<int?> id,
      Value<int?> idAgendaCategoriaCompromisso,
      Value<int?> idColaborador,
      Value<DateTime?> dataCompromisso,
      Value<String?> hora,
      Value<int?> duracao,
      Value<String?> tipo,
      Value<String?> onde,
      Value<String?> descricao,
    });
typedef $$AgendaCompromissosTableUpdateCompanionBuilder =
    AgendaCompromissosCompanion Function({
      Value<int?> id,
      Value<int?> idAgendaCategoriaCompromisso,
      Value<int?> idColaborador,
      Value<DateTime?> dataCompromisso,
      Value<String?> hora,
      Value<int?> duracao,
      Value<String?> tipo,
      Value<String?> onde,
      Value<String?> descricao,
    });

class $$AgendaCompromissosTableFilterComposer
    extends Composer<_$AppDatabase, $AgendaCompromissosTable> {
  $$AgendaCompromissosTableFilterComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnFilters<int> get id => $composableBuilder(
    column: $table.id,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<int> get idAgendaCategoriaCompromisso => $composableBuilder(
    column: $table.idAgendaCategoriaCompromisso,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<int> get idColaborador => $composableBuilder(
    column: $table.idColaborador,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<DateTime> get dataCompromisso => $composableBuilder(
    column: $table.dataCompromisso,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get hora => $composableBuilder(
    column: $table.hora,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<int> get duracao => $composableBuilder(
    column: $table.duracao,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get tipo => $composableBuilder(
    column: $table.tipo,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get onde => $composableBuilder(
    column: $table.onde,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get descricao => $composableBuilder(
    column: $table.descricao,
    builder: (column) => ColumnFilters(column),
  );
}

class $$AgendaCompromissosTableOrderingComposer
    extends Composer<_$AppDatabase, $AgendaCompromissosTable> {
  $$AgendaCompromissosTableOrderingComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnOrderings<int> get id => $composableBuilder(
    column: $table.id,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<int> get idAgendaCategoriaCompromisso => $composableBuilder(
    column: $table.idAgendaCategoriaCompromisso,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<int> get idColaborador => $composableBuilder(
    column: $table.idColaborador,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<DateTime> get dataCompromisso => $composableBuilder(
    column: $table.dataCompromisso,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get hora => $composableBuilder(
    column: $table.hora,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<int> get duracao => $composableBuilder(
    column: $table.duracao,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get tipo => $composableBuilder(
    column: $table.tipo,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get onde => $composableBuilder(
    column: $table.onde,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get descricao => $composableBuilder(
    column: $table.descricao,
    builder: (column) => ColumnOrderings(column),
  );
}

class $$AgendaCompromissosTableAnnotationComposer
    extends Composer<_$AppDatabase, $AgendaCompromissosTable> {
  $$AgendaCompromissosTableAnnotationComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  GeneratedColumn<int> get id =>
      $composableBuilder(column: $table.id, builder: (column) => column);

  GeneratedColumn<int> get idAgendaCategoriaCompromisso => $composableBuilder(
    column: $table.idAgendaCategoriaCompromisso,
    builder: (column) => column,
  );

  GeneratedColumn<int> get idColaborador => $composableBuilder(
    column: $table.idColaborador,
    builder: (column) => column,
  );

  GeneratedColumn<DateTime> get dataCompromisso => $composableBuilder(
    column: $table.dataCompromisso,
    builder: (column) => column,
  );

  GeneratedColumn<String> get hora =>
      $composableBuilder(column: $table.hora, builder: (column) => column);

  GeneratedColumn<int> get duracao =>
      $composableBuilder(column: $table.duracao, builder: (column) => column);

  GeneratedColumn<String> get tipo =>
      $composableBuilder(column: $table.tipo, builder: (column) => column);

  GeneratedColumn<String> get onde =>
      $composableBuilder(column: $table.onde, builder: (column) => column);

  GeneratedColumn<String> get descricao =>
      $composableBuilder(column: $table.descricao, builder: (column) => column);
}

class $$AgendaCompromissosTableTableManager
    extends
        RootTableManager<
          _$AppDatabase,
          $AgendaCompromissosTable,
          AgendaCompromisso,
          $$AgendaCompromissosTableFilterComposer,
          $$AgendaCompromissosTableOrderingComposer,
          $$AgendaCompromissosTableAnnotationComposer,
          $$AgendaCompromissosTableCreateCompanionBuilder,
          $$AgendaCompromissosTableUpdateCompanionBuilder,
          (
            AgendaCompromisso,
            BaseReferences<
              _$AppDatabase,
              $AgendaCompromissosTable,
              AgendaCompromisso
            >,
          ),
          AgendaCompromisso,
          PrefetchHooks Function()
        > {
  $$AgendaCompromissosTableTableManager(
    _$AppDatabase db,
    $AgendaCompromissosTable table,
  ) : super(
        TableManagerState(
          db: db,
          table: table,
          createFilteringComposer:
              () => $$AgendaCompromissosTableFilterComposer(
                $db: db,
                $table: table,
              ),
          createOrderingComposer:
              () => $$AgendaCompromissosTableOrderingComposer(
                $db: db,
                $table: table,
              ),
          createComputedFieldComposer:
              () => $$AgendaCompromissosTableAnnotationComposer(
                $db: db,
                $table: table,
              ),
          updateCompanionCallback:
              ({
                Value<int?> id = const Value.absent(),
                Value<int?> idAgendaCategoriaCompromisso = const Value.absent(),
                Value<int?> idColaborador = const Value.absent(),
                Value<DateTime?> dataCompromisso = const Value.absent(),
                Value<String?> hora = const Value.absent(),
                Value<int?> duracao = const Value.absent(),
                Value<String?> tipo = const Value.absent(),
                Value<String?> onde = const Value.absent(),
                Value<String?> descricao = const Value.absent(),
              }) => AgendaCompromissosCompanion(
                id: id,
                idAgendaCategoriaCompromisso: idAgendaCategoriaCompromisso,
                idColaborador: idColaborador,
                dataCompromisso: dataCompromisso,
                hora: hora,
                duracao: duracao,
                tipo: tipo,
                onde: onde,
                descricao: descricao,
              ),
          createCompanionCallback:
              ({
                Value<int?> id = const Value.absent(),
                Value<int?> idAgendaCategoriaCompromisso = const Value.absent(),
                Value<int?> idColaborador = const Value.absent(),
                Value<DateTime?> dataCompromisso = const Value.absent(),
                Value<String?> hora = const Value.absent(),
                Value<int?> duracao = const Value.absent(),
                Value<String?> tipo = const Value.absent(),
                Value<String?> onde = const Value.absent(),
                Value<String?> descricao = const Value.absent(),
              }) => AgendaCompromissosCompanion.insert(
                id: id,
                idAgendaCategoriaCompromisso: idAgendaCategoriaCompromisso,
                idColaborador: idColaborador,
                dataCompromisso: dataCompromisso,
                hora: hora,
                duracao: duracao,
                tipo: tipo,
                onde: onde,
                descricao: descricao,
              ),
          withReferenceMapper:
              (p0) =>
                  p0
                      .map(
                        (e) => (
                          e.readTable(table),
                          BaseReferences(db, table, e),
                        ),
                      )
                      .toList(),
          prefetchHooksCallback: null,
        ),
      );
}

typedef $$AgendaCompromissosTableProcessedTableManager =
    ProcessedTableManager<
      _$AppDatabase,
      $AgendaCompromissosTable,
      AgendaCompromisso,
      $$AgendaCompromissosTableFilterComposer,
      $$AgendaCompromissosTableOrderingComposer,
      $$AgendaCompromissosTableAnnotationComposer,
      $$AgendaCompromissosTableCreateCompanionBuilder,
      $$AgendaCompromissosTableUpdateCompanionBuilder,
      (
        AgendaCompromisso,
        BaseReferences<
          _$AppDatabase,
          $AgendaCompromissosTable,
          AgendaCompromisso
        >,
      ),
      AgendaCompromisso,
      PrefetchHooks Function()
    >;
typedef $$RecadoRemetentesTableCreateCompanionBuilder =
    RecadoRemetentesCompanion Function({
      Value<int?> id,
      Value<int?> idColaborador,
      Value<DateTime?> dataEnvio,
      Value<String?> horaEnvio,
      Value<String?> assunto,
      Value<String?> texto,
    });
typedef $$RecadoRemetentesTableUpdateCompanionBuilder =
    RecadoRemetentesCompanion Function({
      Value<int?> id,
      Value<int?> idColaborador,
      Value<DateTime?> dataEnvio,
      Value<String?> horaEnvio,
      Value<String?> assunto,
      Value<String?> texto,
    });

class $$RecadoRemetentesTableFilterComposer
    extends Composer<_$AppDatabase, $RecadoRemetentesTable> {
  $$RecadoRemetentesTableFilterComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnFilters<int> get id => $composableBuilder(
    column: $table.id,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<int> get idColaborador => $composableBuilder(
    column: $table.idColaborador,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<DateTime> get dataEnvio => $composableBuilder(
    column: $table.dataEnvio,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get horaEnvio => $composableBuilder(
    column: $table.horaEnvio,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get assunto => $composableBuilder(
    column: $table.assunto,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get texto => $composableBuilder(
    column: $table.texto,
    builder: (column) => ColumnFilters(column),
  );
}

class $$RecadoRemetentesTableOrderingComposer
    extends Composer<_$AppDatabase, $RecadoRemetentesTable> {
  $$RecadoRemetentesTableOrderingComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnOrderings<int> get id => $composableBuilder(
    column: $table.id,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<int> get idColaborador => $composableBuilder(
    column: $table.idColaborador,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<DateTime> get dataEnvio => $composableBuilder(
    column: $table.dataEnvio,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get horaEnvio => $composableBuilder(
    column: $table.horaEnvio,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get assunto => $composableBuilder(
    column: $table.assunto,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get texto => $composableBuilder(
    column: $table.texto,
    builder: (column) => ColumnOrderings(column),
  );
}

class $$RecadoRemetentesTableAnnotationComposer
    extends Composer<_$AppDatabase, $RecadoRemetentesTable> {
  $$RecadoRemetentesTableAnnotationComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  GeneratedColumn<int> get id =>
      $composableBuilder(column: $table.id, builder: (column) => column);

  GeneratedColumn<int> get idColaborador => $composableBuilder(
    column: $table.idColaborador,
    builder: (column) => column,
  );

  GeneratedColumn<DateTime> get dataEnvio =>
      $composableBuilder(column: $table.dataEnvio, builder: (column) => column);

  GeneratedColumn<String> get horaEnvio =>
      $composableBuilder(column: $table.horaEnvio, builder: (column) => column);

  GeneratedColumn<String> get assunto =>
      $composableBuilder(column: $table.assunto, builder: (column) => column);

  GeneratedColumn<String> get texto =>
      $composableBuilder(column: $table.texto, builder: (column) => column);
}

class $$RecadoRemetentesTableTableManager
    extends
        RootTableManager<
          _$AppDatabase,
          $RecadoRemetentesTable,
          RecadoRemetente,
          $$RecadoRemetentesTableFilterComposer,
          $$RecadoRemetentesTableOrderingComposer,
          $$RecadoRemetentesTableAnnotationComposer,
          $$RecadoRemetentesTableCreateCompanionBuilder,
          $$RecadoRemetentesTableUpdateCompanionBuilder,
          (
            RecadoRemetente,
            BaseReferences<
              _$AppDatabase,
              $RecadoRemetentesTable,
              RecadoRemetente
            >,
          ),
          RecadoRemetente,
          PrefetchHooks Function()
        > {
  $$RecadoRemetentesTableTableManager(
    _$AppDatabase db,
    $RecadoRemetentesTable table,
  ) : super(
        TableManagerState(
          db: db,
          table: table,
          createFilteringComposer:
              () =>
                  $$RecadoRemetentesTableFilterComposer($db: db, $table: table),
          createOrderingComposer:
              () => $$RecadoRemetentesTableOrderingComposer(
                $db: db,
                $table: table,
              ),
          createComputedFieldComposer:
              () => $$RecadoRemetentesTableAnnotationComposer(
                $db: db,
                $table: table,
              ),
          updateCompanionCallback:
              ({
                Value<int?> id = const Value.absent(),
                Value<int?> idColaborador = const Value.absent(),
                Value<DateTime?> dataEnvio = const Value.absent(),
                Value<String?> horaEnvio = const Value.absent(),
                Value<String?> assunto = const Value.absent(),
                Value<String?> texto = const Value.absent(),
              }) => RecadoRemetentesCompanion(
                id: id,
                idColaborador: idColaborador,
                dataEnvio: dataEnvio,
                horaEnvio: horaEnvio,
                assunto: assunto,
                texto: texto,
              ),
          createCompanionCallback:
              ({
                Value<int?> id = const Value.absent(),
                Value<int?> idColaborador = const Value.absent(),
                Value<DateTime?> dataEnvio = const Value.absent(),
                Value<String?> horaEnvio = const Value.absent(),
                Value<String?> assunto = const Value.absent(),
                Value<String?> texto = const Value.absent(),
              }) => RecadoRemetentesCompanion.insert(
                id: id,
                idColaborador: idColaborador,
                dataEnvio: dataEnvio,
                horaEnvio: horaEnvio,
                assunto: assunto,
                texto: texto,
              ),
          withReferenceMapper:
              (p0) =>
                  p0
                      .map(
                        (e) => (
                          e.readTable(table),
                          BaseReferences(db, table, e),
                        ),
                      )
                      .toList(),
          prefetchHooksCallback: null,
        ),
      );
}

typedef $$RecadoRemetentesTableProcessedTableManager =
    ProcessedTableManager<
      _$AppDatabase,
      $RecadoRemetentesTable,
      RecadoRemetente,
      $$RecadoRemetentesTableFilterComposer,
      $$RecadoRemetentesTableOrderingComposer,
      $$RecadoRemetentesTableAnnotationComposer,
      $$RecadoRemetentesTableCreateCompanionBuilder,
      $$RecadoRemetentesTableUpdateCompanionBuilder,
      (
        RecadoRemetente,
        BaseReferences<_$AppDatabase, $RecadoRemetentesTable, RecadoRemetente>,
      ),
      RecadoRemetente,
      PrefetchHooks Function()
    >;
typedef $$AgendaCategoriaCompromissosTableCreateCompanionBuilder =
    AgendaCategoriaCompromissosCompanion Function({
      Value<int?> id,
      Value<String?> nome,
      Value<String?> cor,
    });
typedef $$AgendaCategoriaCompromissosTableUpdateCompanionBuilder =
    AgendaCategoriaCompromissosCompanion Function({
      Value<int?> id,
      Value<String?> nome,
      Value<String?> cor,
    });

class $$AgendaCategoriaCompromissosTableFilterComposer
    extends Composer<_$AppDatabase, $AgendaCategoriaCompromissosTable> {
  $$AgendaCategoriaCompromissosTableFilterComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnFilters<int> get id => $composableBuilder(
    column: $table.id,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get nome => $composableBuilder(
    column: $table.nome,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get cor => $composableBuilder(
    column: $table.cor,
    builder: (column) => ColumnFilters(column),
  );
}

class $$AgendaCategoriaCompromissosTableOrderingComposer
    extends Composer<_$AppDatabase, $AgendaCategoriaCompromissosTable> {
  $$AgendaCategoriaCompromissosTableOrderingComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnOrderings<int> get id => $composableBuilder(
    column: $table.id,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get nome => $composableBuilder(
    column: $table.nome,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get cor => $composableBuilder(
    column: $table.cor,
    builder: (column) => ColumnOrderings(column),
  );
}

class $$AgendaCategoriaCompromissosTableAnnotationComposer
    extends Composer<_$AppDatabase, $AgendaCategoriaCompromissosTable> {
  $$AgendaCategoriaCompromissosTableAnnotationComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  GeneratedColumn<int> get id =>
      $composableBuilder(column: $table.id, builder: (column) => column);

  GeneratedColumn<String> get nome =>
      $composableBuilder(column: $table.nome, builder: (column) => column);

  GeneratedColumn<String> get cor =>
      $composableBuilder(column: $table.cor, builder: (column) => column);
}

class $$AgendaCategoriaCompromissosTableTableManager
    extends
        RootTableManager<
          _$AppDatabase,
          $AgendaCategoriaCompromissosTable,
          AgendaCategoriaCompromisso,
          $$AgendaCategoriaCompromissosTableFilterComposer,
          $$AgendaCategoriaCompromissosTableOrderingComposer,
          $$AgendaCategoriaCompromissosTableAnnotationComposer,
          $$AgendaCategoriaCompromissosTableCreateCompanionBuilder,
          $$AgendaCategoriaCompromissosTableUpdateCompanionBuilder,
          (
            AgendaCategoriaCompromisso,
            BaseReferences<
              _$AppDatabase,
              $AgendaCategoriaCompromissosTable,
              AgendaCategoriaCompromisso
            >,
          ),
          AgendaCategoriaCompromisso,
          PrefetchHooks Function()
        > {
  $$AgendaCategoriaCompromissosTableTableManager(
    _$AppDatabase db,
    $AgendaCategoriaCompromissosTable table,
  ) : super(
        TableManagerState(
          db: db,
          table: table,
          createFilteringComposer:
              () => $$AgendaCategoriaCompromissosTableFilterComposer(
                $db: db,
                $table: table,
              ),
          createOrderingComposer:
              () => $$AgendaCategoriaCompromissosTableOrderingComposer(
                $db: db,
                $table: table,
              ),
          createComputedFieldComposer:
              () => $$AgendaCategoriaCompromissosTableAnnotationComposer(
                $db: db,
                $table: table,
              ),
          updateCompanionCallback:
              ({
                Value<int?> id = const Value.absent(),
                Value<String?> nome = const Value.absent(),
                Value<String?> cor = const Value.absent(),
              }) => AgendaCategoriaCompromissosCompanion(
                id: id,
                nome: nome,
                cor: cor,
              ),
          createCompanionCallback:
              ({
                Value<int?> id = const Value.absent(),
                Value<String?> nome = const Value.absent(),
                Value<String?> cor = const Value.absent(),
              }) => AgendaCategoriaCompromissosCompanion.insert(
                id: id,
                nome: nome,
                cor: cor,
              ),
          withReferenceMapper:
              (p0) =>
                  p0
                      .map(
                        (e) => (
                          e.readTable(table),
                          BaseReferences(db, table, e),
                        ),
                      )
                      .toList(),
          prefetchHooksCallback: null,
        ),
      );
}

typedef $$AgendaCategoriaCompromissosTableProcessedTableManager =
    ProcessedTableManager<
      _$AppDatabase,
      $AgendaCategoriaCompromissosTable,
      AgendaCategoriaCompromisso,
      $$AgendaCategoriaCompromissosTableFilterComposer,
      $$AgendaCategoriaCompromissosTableOrderingComposer,
      $$AgendaCategoriaCompromissosTableAnnotationComposer,
      $$AgendaCategoriaCompromissosTableCreateCompanionBuilder,
      $$AgendaCategoriaCompromissosTableUpdateCompanionBuilder,
      (
        AgendaCategoriaCompromisso,
        BaseReferences<
          _$AppDatabase,
          $AgendaCategoriaCompromissosTable,
          AgendaCategoriaCompromisso
        >,
      ),
      AgendaCategoriaCompromisso,
      PrefetchHooks Function()
    >;
typedef $$ReuniaoSalasTableCreateCompanionBuilder =
    ReuniaoSalasCompanion Function({
      Value<int?> id,
      Value<String?> predio,
      Value<String?> nome,
      Value<String?> andar,
      Value<String?> numero,
    });
typedef $$ReuniaoSalasTableUpdateCompanionBuilder =
    ReuniaoSalasCompanion Function({
      Value<int?> id,
      Value<String?> predio,
      Value<String?> nome,
      Value<String?> andar,
      Value<String?> numero,
    });

class $$ReuniaoSalasTableFilterComposer
    extends Composer<_$AppDatabase, $ReuniaoSalasTable> {
  $$ReuniaoSalasTableFilterComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnFilters<int> get id => $composableBuilder(
    column: $table.id,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get predio => $composableBuilder(
    column: $table.predio,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get nome => $composableBuilder(
    column: $table.nome,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get andar => $composableBuilder(
    column: $table.andar,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get numero => $composableBuilder(
    column: $table.numero,
    builder: (column) => ColumnFilters(column),
  );
}

class $$ReuniaoSalasTableOrderingComposer
    extends Composer<_$AppDatabase, $ReuniaoSalasTable> {
  $$ReuniaoSalasTableOrderingComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnOrderings<int> get id => $composableBuilder(
    column: $table.id,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get predio => $composableBuilder(
    column: $table.predio,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get nome => $composableBuilder(
    column: $table.nome,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get andar => $composableBuilder(
    column: $table.andar,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get numero => $composableBuilder(
    column: $table.numero,
    builder: (column) => ColumnOrderings(column),
  );
}

class $$ReuniaoSalasTableAnnotationComposer
    extends Composer<_$AppDatabase, $ReuniaoSalasTable> {
  $$ReuniaoSalasTableAnnotationComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  GeneratedColumn<int> get id =>
      $composableBuilder(column: $table.id, builder: (column) => column);

  GeneratedColumn<String> get predio =>
      $composableBuilder(column: $table.predio, builder: (column) => column);

  GeneratedColumn<String> get nome =>
      $composableBuilder(column: $table.nome, builder: (column) => column);

  GeneratedColumn<String> get andar =>
      $composableBuilder(column: $table.andar, builder: (column) => column);

  GeneratedColumn<String> get numero =>
      $composableBuilder(column: $table.numero, builder: (column) => column);
}

class $$ReuniaoSalasTableTableManager
    extends
        RootTableManager<
          _$AppDatabase,
          $ReuniaoSalasTable,
          ReuniaoSala,
          $$ReuniaoSalasTableFilterComposer,
          $$ReuniaoSalasTableOrderingComposer,
          $$ReuniaoSalasTableAnnotationComposer,
          $$ReuniaoSalasTableCreateCompanionBuilder,
          $$ReuniaoSalasTableUpdateCompanionBuilder,
          (
            ReuniaoSala,
            BaseReferences<_$AppDatabase, $ReuniaoSalasTable, ReuniaoSala>,
          ),
          ReuniaoSala,
          PrefetchHooks Function()
        > {
  $$ReuniaoSalasTableTableManager(_$AppDatabase db, $ReuniaoSalasTable table)
    : super(
        TableManagerState(
          db: db,
          table: table,
          createFilteringComposer:
              () => $$ReuniaoSalasTableFilterComposer($db: db, $table: table),
          createOrderingComposer:
              () => $$ReuniaoSalasTableOrderingComposer($db: db, $table: table),
          createComputedFieldComposer:
              () =>
                  $$ReuniaoSalasTableAnnotationComposer($db: db, $table: table),
          updateCompanionCallback:
              ({
                Value<int?> id = const Value.absent(),
                Value<String?> predio = const Value.absent(),
                Value<String?> nome = const Value.absent(),
                Value<String?> andar = const Value.absent(),
                Value<String?> numero = const Value.absent(),
              }) => ReuniaoSalasCompanion(
                id: id,
                predio: predio,
                nome: nome,
                andar: andar,
                numero: numero,
              ),
          createCompanionCallback:
              ({
                Value<int?> id = const Value.absent(),
                Value<String?> predio = const Value.absent(),
                Value<String?> nome = const Value.absent(),
                Value<String?> andar = const Value.absent(),
                Value<String?> numero = const Value.absent(),
              }) => ReuniaoSalasCompanion.insert(
                id: id,
                predio: predio,
                nome: nome,
                andar: andar,
                numero: numero,
              ),
          withReferenceMapper:
              (p0) =>
                  p0
                      .map(
                        (e) => (
                          e.readTable(table),
                          BaseReferences(db, table, e),
                        ),
                      )
                      .toList(),
          prefetchHooksCallback: null,
        ),
      );
}

typedef $$ReuniaoSalasTableProcessedTableManager =
    ProcessedTableManager<
      _$AppDatabase,
      $ReuniaoSalasTable,
      ReuniaoSala,
      $$ReuniaoSalasTableFilterComposer,
      $$ReuniaoSalasTableOrderingComposer,
      $$ReuniaoSalasTableAnnotationComposer,
      $$ReuniaoSalasTableCreateCompanionBuilder,
      $$ReuniaoSalasTableUpdateCompanionBuilder,
      (
        ReuniaoSala,
        BaseReferences<_$AppDatabase, $ReuniaoSalasTable, ReuniaoSala>,
      ),
      ReuniaoSala,
      PrefetchHooks Function()
    >;
typedef $$ViewControleAcessosTableCreateCompanionBuilder =
    ViewControleAcessosCompanion Function({
      Value<int?> id,
      Value<int?> idPessoa,
      Value<String?> pessoaNome,
      Value<int?> idColaborador,
      Value<int?> idUsuario,
      Value<String?> administrador,
      Value<int?> idPapel,
      Value<String?> papelNome,
      Value<String?> papelDescricao,
      Value<int?> idFuncao,
      Value<String?> funcaoNome,
      Value<String?> funcaoDescricao,
      Value<int?> idPapelFuncao,
      Value<String?> habilitado,
      Value<String?> podeInserir,
      Value<String?> podeAlterar,
      Value<String?> podeExcluir,
    });
typedef $$ViewControleAcessosTableUpdateCompanionBuilder =
    ViewControleAcessosCompanion Function({
      Value<int?> id,
      Value<int?> idPessoa,
      Value<String?> pessoaNome,
      Value<int?> idColaborador,
      Value<int?> idUsuario,
      Value<String?> administrador,
      Value<int?> idPapel,
      Value<String?> papelNome,
      Value<String?> papelDescricao,
      Value<int?> idFuncao,
      Value<String?> funcaoNome,
      Value<String?> funcaoDescricao,
      Value<int?> idPapelFuncao,
      Value<String?> habilitado,
      Value<String?> podeInserir,
      Value<String?> podeAlterar,
      Value<String?> podeExcluir,
    });

class $$ViewControleAcessosTableFilterComposer
    extends Composer<_$AppDatabase, $ViewControleAcessosTable> {
  $$ViewControleAcessosTableFilterComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnFilters<int> get id => $composableBuilder(
    column: $table.id,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<int> get idPessoa => $composableBuilder(
    column: $table.idPessoa,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get pessoaNome => $composableBuilder(
    column: $table.pessoaNome,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<int> get idColaborador => $composableBuilder(
    column: $table.idColaborador,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<int> get idUsuario => $composableBuilder(
    column: $table.idUsuario,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get administrador => $composableBuilder(
    column: $table.administrador,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<int> get idPapel => $composableBuilder(
    column: $table.idPapel,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get papelNome => $composableBuilder(
    column: $table.papelNome,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get papelDescricao => $composableBuilder(
    column: $table.papelDescricao,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<int> get idFuncao => $composableBuilder(
    column: $table.idFuncao,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get funcaoNome => $composableBuilder(
    column: $table.funcaoNome,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get funcaoDescricao => $composableBuilder(
    column: $table.funcaoDescricao,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<int> get idPapelFuncao => $composableBuilder(
    column: $table.idPapelFuncao,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get habilitado => $composableBuilder(
    column: $table.habilitado,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get podeInserir => $composableBuilder(
    column: $table.podeInserir,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get podeAlterar => $composableBuilder(
    column: $table.podeAlterar,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get podeExcluir => $composableBuilder(
    column: $table.podeExcluir,
    builder: (column) => ColumnFilters(column),
  );
}

class $$ViewControleAcessosTableOrderingComposer
    extends Composer<_$AppDatabase, $ViewControleAcessosTable> {
  $$ViewControleAcessosTableOrderingComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnOrderings<int> get id => $composableBuilder(
    column: $table.id,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<int> get idPessoa => $composableBuilder(
    column: $table.idPessoa,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get pessoaNome => $composableBuilder(
    column: $table.pessoaNome,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<int> get idColaborador => $composableBuilder(
    column: $table.idColaborador,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<int> get idUsuario => $composableBuilder(
    column: $table.idUsuario,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get administrador => $composableBuilder(
    column: $table.administrador,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<int> get idPapel => $composableBuilder(
    column: $table.idPapel,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get papelNome => $composableBuilder(
    column: $table.papelNome,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get papelDescricao => $composableBuilder(
    column: $table.papelDescricao,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<int> get idFuncao => $composableBuilder(
    column: $table.idFuncao,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get funcaoNome => $composableBuilder(
    column: $table.funcaoNome,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get funcaoDescricao => $composableBuilder(
    column: $table.funcaoDescricao,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<int> get idPapelFuncao => $composableBuilder(
    column: $table.idPapelFuncao,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get habilitado => $composableBuilder(
    column: $table.habilitado,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get podeInserir => $composableBuilder(
    column: $table.podeInserir,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get podeAlterar => $composableBuilder(
    column: $table.podeAlterar,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get podeExcluir => $composableBuilder(
    column: $table.podeExcluir,
    builder: (column) => ColumnOrderings(column),
  );
}

class $$ViewControleAcessosTableAnnotationComposer
    extends Composer<_$AppDatabase, $ViewControleAcessosTable> {
  $$ViewControleAcessosTableAnnotationComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  GeneratedColumn<int> get id =>
      $composableBuilder(column: $table.id, builder: (column) => column);

  GeneratedColumn<int> get idPessoa =>
      $composableBuilder(column: $table.idPessoa, builder: (column) => column);

  GeneratedColumn<String> get pessoaNome => $composableBuilder(
    column: $table.pessoaNome,
    builder: (column) => column,
  );

  GeneratedColumn<int> get idColaborador => $composableBuilder(
    column: $table.idColaborador,
    builder: (column) => column,
  );

  GeneratedColumn<int> get idUsuario =>
      $composableBuilder(column: $table.idUsuario, builder: (column) => column);

  GeneratedColumn<String> get administrador => $composableBuilder(
    column: $table.administrador,
    builder: (column) => column,
  );

  GeneratedColumn<int> get idPapel =>
      $composableBuilder(column: $table.idPapel, builder: (column) => column);

  GeneratedColumn<String> get papelNome =>
      $composableBuilder(column: $table.papelNome, builder: (column) => column);

  GeneratedColumn<String> get papelDescricao => $composableBuilder(
    column: $table.papelDescricao,
    builder: (column) => column,
  );

  GeneratedColumn<int> get idFuncao =>
      $composableBuilder(column: $table.idFuncao, builder: (column) => column);

  GeneratedColumn<String> get funcaoNome => $composableBuilder(
    column: $table.funcaoNome,
    builder: (column) => column,
  );

  GeneratedColumn<String> get funcaoDescricao => $composableBuilder(
    column: $table.funcaoDescricao,
    builder: (column) => column,
  );

  GeneratedColumn<int> get idPapelFuncao => $composableBuilder(
    column: $table.idPapelFuncao,
    builder: (column) => column,
  );

  GeneratedColumn<String> get habilitado => $composableBuilder(
    column: $table.habilitado,
    builder: (column) => column,
  );

  GeneratedColumn<String> get podeInserir => $composableBuilder(
    column: $table.podeInserir,
    builder: (column) => column,
  );

  GeneratedColumn<String> get podeAlterar => $composableBuilder(
    column: $table.podeAlterar,
    builder: (column) => column,
  );

  GeneratedColumn<String> get podeExcluir => $composableBuilder(
    column: $table.podeExcluir,
    builder: (column) => column,
  );
}

class $$ViewControleAcessosTableTableManager
    extends
        RootTableManager<
          _$AppDatabase,
          $ViewControleAcessosTable,
          ViewControleAcesso,
          $$ViewControleAcessosTableFilterComposer,
          $$ViewControleAcessosTableOrderingComposer,
          $$ViewControleAcessosTableAnnotationComposer,
          $$ViewControleAcessosTableCreateCompanionBuilder,
          $$ViewControleAcessosTableUpdateCompanionBuilder,
          (
            ViewControleAcesso,
            BaseReferences<
              _$AppDatabase,
              $ViewControleAcessosTable,
              ViewControleAcesso
            >,
          ),
          ViewControleAcesso,
          PrefetchHooks Function()
        > {
  $$ViewControleAcessosTableTableManager(
    _$AppDatabase db,
    $ViewControleAcessosTable table,
  ) : super(
        TableManagerState(
          db: db,
          table: table,
          createFilteringComposer:
              () => $$ViewControleAcessosTableFilterComposer(
                $db: db,
                $table: table,
              ),
          createOrderingComposer:
              () => $$ViewControleAcessosTableOrderingComposer(
                $db: db,
                $table: table,
              ),
          createComputedFieldComposer:
              () => $$ViewControleAcessosTableAnnotationComposer(
                $db: db,
                $table: table,
              ),
          updateCompanionCallback:
              ({
                Value<int?> id = const Value.absent(),
                Value<int?> idPessoa = const Value.absent(),
                Value<String?> pessoaNome = const Value.absent(),
                Value<int?> idColaborador = const Value.absent(),
                Value<int?> idUsuario = const Value.absent(),
                Value<String?> administrador = const Value.absent(),
                Value<int?> idPapel = const Value.absent(),
                Value<String?> papelNome = const Value.absent(),
                Value<String?> papelDescricao = const Value.absent(),
                Value<int?> idFuncao = const Value.absent(),
                Value<String?> funcaoNome = const Value.absent(),
                Value<String?> funcaoDescricao = const Value.absent(),
                Value<int?> idPapelFuncao = const Value.absent(),
                Value<String?> habilitado = const Value.absent(),
                Value<String?> podeInserir = const Value.absent(),
                Value<String?> podeAlterar = const Value.absent(),
                Value<String?> podeExcluir = const Value.absent(),
              }) => ViewControleAcessosCompanion(
                id: id,
                idPessoa: idPessoa,
                pessoaNome: pessoaNome,
                idColaborador: idColaborador,
                idUsuario: idUsuario,
                administrador: administrador,
                idPapel: idPapel,
                papelNome: papelNome,
                papelDescricao: papelDescricao,
                idFuncao: idFuncao,
                funcaoNome: funcaoNome,
                funcaoDescricao: funcaoDescricao,
                idPapelFuncao: idPapelFuncao,
                habilitado: habilitado,
                podeInserir: podeInserir,
                podeAlterar: podeAlterar,
                podeExcluir: podeExcluir,
              ),
          createCompanionCallback:
              ({
                Value<int?> id = const Value.absent(),
                Value<int?> idPessoa = const Value.absent(),
                Value<String?> pessoaNome = const Value.absent(),
                Value<int?> idColaborador = const Value.absent(),
                Value<int?> idUsuario = const Value.absent(),
                Value<String?> administrador = const Value.absent(),
                Value<int?> idPapel = const Value.absent(),
                Value<String?> papelNome = const Value.absent(),
                Value<String?> papelDescricao = const Value.absent(),
                Value<int?> idFuncao = const Value.absent(),
                Value<String?> funcaoNome = const Value.absent(),
                Value<String?> funcaoDescricao = const Value.absent(),
                Value<int?> idPapelFuncao = const Value.absent(),
                Value<String?> habilitado = const Value.absent(),
                Value<String?> podeInserir = const Value.absent(),
                Value<String?> podeAlterar = const Value.absent(),
                Value<String?> podeExcluir = const Value.absent(),
              }) => ViewControleAcessosCompanion.insert(
                id: id,
                idPessoa: idPessoa,
                pessoaNome: pessoaNome,
                idColaborador: idColaborador,
                idUsuario: idUsuario,
                administrador: administrador,
                idPapel: idPapel,
                papelNome: papelNome,
                papelDescricao: papelDescricao,
                idFuncao: idFuncao,
                funcaoNome: funcaoNome,
                funcaoDescricao: funcaoDescricao,
                idPapelFuncao: idPapelFuncao,
                habilitado: habilitado,
                podeInserir: podeInserir,
                podeAlterar: podeAlterar,
                podeExcluir: podeExcluir,
              ),
          withReferenceMapper:
              (p0) =>
                  p0
                      .map(
                        (e) => (
                          e.readTable(table),
                          BaseReferences(db, table, e),
                        ),
                      )
                      .toList(),
          prefetchHooksCallback: null,
        ),
      );
}

typedef $$ViewControleAcessosTableProcessedTableManager =
    ProcessedTableManager<
      _$AppDatabase,
      $ViewControleAcessosTable,
      ViewControleAcesso,
      $$ViewControleAcessosTableFilterComposer,
      $$ViewControleAcessosTableOrderingComposer,
      $$ViewControleAcessosTableAnnotationComposer,
      $$ViewControleAcessosTableCreateCompanionBuilder,
      $$ViewControleAcessosTableUpdateCompanionBuilder,
      (
        ViewControleAcesso,
        BaseReferences<
          _$AppDatabase,
          $ViewControleAcessosTable,
          ViewControleAcesso
        >,
      ),
      ViewControleAcesso,
      PrefetchHooks Function()
    >;
typedef $$ViewPessoaUsuariosTableCreateCompanionBuilder =
    ViewPessoaUsuariosCompanion Function({
      Value<int?> id,
      Value<int?> idPessoa,
      Value<String?> pessoaNome,
      Value<String?> tipo,
      Value<String?> email,
      Value<int?> idColaborador,
      Value<int?> idUsuario,
      Value<String?> login,
      Value<String?> senha,
      Value<DateTime?> dataCadastro,
      Value<String?> administrador,
    });
typedef $$ViewPessoaUsuariosTableUpdateCompanionBuilder =
    ViewPessoaUsuariosCompanion Function({
      Value<int?> id,
      Value<int?> idPessoa,
      Value<String?> pessoaNome,
      Value<String?> tipo,
      Value<String?> email,
      Value<int?> idColaborador,
      Value<int?> idUsuario,
      Value<String?> login,
      Value<String?> senha,
      Value<DateTime?> dataCadastro,
      Value<String?> administrador,
    });

class $$ViewPessoaUsuariosTableFilterComposer
    extends Composer<_$AppDatabase, $ViewPessoaUsuariosTable> {
  $$ViewPessoaUsuariosTableFilterComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnFilters<int> get id => $composableBuilder(
    column: $table.id,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<int> get idPessoa => $composableBuilder(
    column: $table.idPessoa,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get pessoaNome => $composableBuilder(
    column: $table.pessoaNome,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get tipo => $composableBuilder(
    column: $table.tipo,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get email => $composableBuilder(
    column: $table.email,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<int> get idColaborador => $composableBuilder(
    column: $table.idColaborador,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<int> get idUsuario => $composableBuilder(
    column: $table.idUsuario,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get login => $composableBuilder(
    column: $table.login,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get senha => $composableBuilder(
    column: $table.senha,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<DateTime> get dataCadastro => $composableBuilder(
    column: $table.dataCadastro,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get administrador => $composableBuilder(
    column: $table.administrador,
    builder: (column) => ColumnFilters(column),
  );
}

class $$ViewPessoaUsuariosTableOrderingComposer
    extends Composer<_$AppDatabase, $ViewPessoaUsuariosTable> {
  $$ViewPessoaUsuariosTableOrderingComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnOrderings<int> get id => $composableBuilder(
    column: $table.id,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<int> get idPessoa => $composableBuilder(
    column: $table.idPessoa,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get pessoaNome => $composableBuilder(
    column: $table.pessoaNome,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get tipo => $composableBuilder(
    column: $table.tipo,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get email => $composableBuilder(
    column: $table.email,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<int> get idColaborador => $composableBuilder(
    column: $table.idColaborador,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<int> get idUsuario => $composableBuilder(
    column: $table.idUsuario,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get login => $composableBuilder(
    column: $table.login,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get senha => $composableBuilder(
    column: $table.senha,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<DateTime> get dataCadastro => $composableBuilder(
    column: $table.dataCadastro,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get administrador => $composableBuilder(
    column: $table.administrador,
    builder: (column) => ColumnOrderings(column),
  );
}

class $$ViewPessoaUsuariosTableAnnotationComposer
    extends Composer<_$AppDatabase, $ViewPessoaUsuariosTable> {
  $$ViewPessoaUsuariosTableAnnotationComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  GeneratedColumn<int> get id =>
      $composableBuilder(column: $table.id, builder: (column) => column);

  GeneratedColumn<int> get idPessoa =>
      $composableBuilder(column: $table.idPessoa, builder: (column) => column);

  GeneratedColumn<String> get pessoaNome => $composableBuilder(
    column: $table.pessoaNome,
    builder: (column) => column,
  );

  GeneratedColumn<String> get tipo =>
      $composableBuilder(column: $table.tipo, builder: (column) => column);

  GeneratedColumn<String> get email =>
      $composableBuilder(column: $table.email, builder: (column) => column);

  GeneratedColumn<int> get idColaborador => $composableBuilder(
    column: $table.idColaborador,
    builder: (column) => column,
  );

  GeneratedColumn<int> get idUsuario =>
      $composableBuilder(column: $table.idUsuario, builder: (column) => column);

  GeneratedColumn<String> get login =>
      $composableBuilder(column: $table.login, builder: (column) => column);

  GeneratedColumn<String> get senha =>
      $composableBuilder(column: $table.senha, builder: (column) => column);

  GeneratedColumn<DateTime> get dataCadastro => $composableBuilder(
    column: $table.dataCadastro,
    builder: (column) => column,
  );

  GeneratedColumn<String> get administrador => $composableBuilder(
    column: $table.administrador,
    builder: (column) => column,
  );
}

class $$ViewPessoaUsuariosTableTableManager
    extends
        RootTableManager<
          _$AppDatabase,
          $ViewPessoaUsuariosTable,
          ViewPessoaUsuario,
          $$ViewPessoaUsuariosTableFilterComposer,
          $$ViewPessoaUsuariosTableOrderingComposer,
          $$ViewPessoaUsuariosTableAnnotationComposer,
          $$ViewPessoaUsuariosTableCreateCompanionBuilder,
          $$ViewPessoaUsuariosTableUpdateCompanionBuilder,
          (
            ViewPessoaUsuario,
            BaseReferences<
              _$AppDatabase,
              $ViewPessoaUsuariosTable,
              ViewPessoaUsuario
            >,
          ),
          ViewPessoaUsuario,
          PrefetchHooks Function()
        > {
  $$ViewPessoaUsuariosTableTableManager(
    _$AppDatabase db,
    $ViewPessoaUsuariosTable table,
  ) : super(
        TableManagerState(
          db: db,
          table: table,
          createFilteringComposer:
              () => $$ViewPessoaUsuariosTableFilterComposer(
                $db: db,
                $table: table,
              ),
          createOrderingComposer:
              () => $$ViewPessoaUsuariosTableOrderingComposer(
                $db: db,
                $table: table,
              ),
          createComputedFieldComposer:
              () => $$ViewPessoaUsuariosTableAnnotationComposer(
                $db: db,
                $table: table,
              ),
          updateCompanionCallback:
              ({
                Value<int?> id = const Value.absent(),
                Value<int?> idPessoa = const Value.absent(),
                Value<String?> pessoaNome = const Value.absent(),
                Value<String?> tipo = const Value.absent(),
                Value<String?> email = const Value.absent(),
                Value<int?> idColaborador = const Value.absent(),
                Value<int?> idUsuario = const Value.absent(),
                Value<String?> login = const Value.absent(),
                Value<String?> senha = const Value.absent(),
                Value<DateTime?> dataCadastro = const Value.absent(),
                Value<String?> administrador = const Value.absent(),
              }) => ViewPessoaUsuariosCompanion(
                id: id,
                idPessoa: idPessoa,
                pessoaNome: pessoaNome,
                tipo: tipo,
                email: email,
                idColaborador: idColaborador,
                idUsuario: idUsuario,
                login: login,
                senha: senha,
                dataCadastro: dataCadastro,
                administrador: administrador,
              ),
          createCompanionCallback:
              ({
                Value<int?> id = const Value.absent(),
                Value<int?> idPessoa = const Value.absent(),
                Value<String?> pessoaNome = const Value.absent(),
                Value<String?> tipo = const Value.absent(),
                Value<String?> email = const Value.absent(),
                Value<int?> idColaborador = const Value.absent(),
                Value<int?> idUsuario = const Value.absent(),
                Value<String?> login = const Value.absent(),
                Value<String?> senha = const Value.absent(),
                Value<DateTime?> dataCadastro = const Value.absent(),
                Value<String?> administrador = const Value.absent(),
              }) => ViewPessoaUsuariosCompanion.insert(
                id: id,
                idPessoa: idPessoa,
                pessoaNome: pessoaNome,
                tipo: tipo,
                email: email,
                idColaborador: idColaborador,
                idUsuario: idUsuario,
                login: login,
                senha: senha,
                dataCadastro: dataCadastro,
                administrador: administrador,
              ),
          withReferenceMapper:
              (p0) =>
                  p0
                      .map(
                        (e) => (
                          e.readTable(table),
                          BaseReferences(db, table, e),
                        ),
                      )
                      .toList(),
          prefetchHooksCallback: null,
        ),
      );
}

typedef $$ViewPessoaUsuariosTableProcessedTableManager =
    ProcessedTableManager<
      _$AppDatabase,
      $ViewPessoaUsuariosTable,
      ViewPessoaUsuario,
      $$ViewPessoaUsuariosTableFilterComposer,
      $$ViewPessoaUsuariosTableOrderingComposer,
      $$ViewPessoaUsuariosTableAnnotationComposer,
      $$ViewPessoaUsuariosTableCreateCompanionBuilder,
      $$ViewPessoaUsuariosTableUpdateCompanionBuilder,
      (
        ViewPessoaUsuario,
        BaseReferences<
          _$AppDatabase,
          $ViewPessoaUsuariosTable,
          ViewPessoaUsuario
        >,
      ),
      ViewPessoaUsuario,
      PrefetchHooks Function()
    >;
typedef $$ViewPessoaColaboradorsTableCreateCompanionBuilder =
    ViewPessoaColaboradorsCompanion Function({
      Value<int?> id,
      Value<String?> nome,
      Value<String?> tipo,
      Value<String?> email,
      Value<String?> site,
      Value<String?> cpfCnpj,
      Value<String?> rgIe,
      Value<String?> matricula,
      Value<DateTime?> dataCadastro,
      Value<DateTime?> dataAdmissao,
      Value<DateTime?> dataDemissao,
      Value<String?> ctpsNumero,
      Value<String?> ctpsSerie,
      Value<DateTime?> ctpsDataExpedicao,
      Value<String?> ctpsUf,
      Value<String?> observacao,
      Value<String?> logradouro,
      Value<String?> numero,
      Value<String?> complemento,
      Value<String?> bairro,
      Value<String?> cidade,
      Value<String?> cep,
      Value<String?> municipioIbge,
      Value<String?> uf,
      Value<int?> idPessoa,
      Value<int?> idCargo,
      Value<int?> idSetor,
    });
typedef $$ViewPessoaColaboradorsTableUpdateCompanionBuilder =
    ViewPessoaColaboradorsCompanion Function({
      Value<int?> id,
      Value<String?> nome,
      Value<String?> tipo,
      Value<String?> email,
      Value<String?> site,
      Value<String?> cpfCnpj,
      Value<String?> rgIe,
      Value<String?> matricula,
      Value<DateTime?> dataCadastro,
      Value<DateTime?> dataAdmissao,
      Value<DateTime?> dataDemissao,
      Value<String?> ctpsNumero,
      Value<String?> ctpsSerie,
      Value<DateTime?> ctpsDataExpedicao,
      Value<String?> ctpsUf,
      Value<String?> observacao,
      Value<String?> logradouro,
      Value<String?> numero,
      Value<String?> complemento,
      Value<String?> bairro,
      Value<String?> cidade,
      Value<String?> cep,
      Value<String?> municipioIbge,
      Value<String?> uf,
      Value<int?> idPessoa,
      Value<int?> idCargo,
      Value<int?> idSetor,
    });

class $$ViewPessoaColaboradorsTableFilterComposer
    extends Composer<_$AppDatabase, $ViewPessoaColaboradorsTable> {
  $$ViewPessoaColaboradorsTableFilterComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnFilters<int> get id => $composableBuilder(
    column: $table.id,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get nome => $composableBuilder(
    column: $table.nome,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get tipo => $composableBuilder(
    column: $table.tipo,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get email => $composableBuilder(
    column: $table.email,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get site => $composableBuilder(
    column: $table.site,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get cpfCnpj => $composableBuilder(
    column: $table.cpfCnpj,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get rgIe => $composableBuilder(
    column: $table.rgIe,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get matricula => $composableBuilder(
    column: $table.matricula,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<DateTime> get dataCadastro => $composableBuilder(
    column: $table.dataCadastro,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<DateTime> get dataAdmissao => $composableBuilder(
    column: $table.dataAdmissao,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<DateTime> get dataDemissao => $composableBuilder(
    column: $table.dataDemissao,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get ctpsNumero => $composableBuilder(
    column: $table.ctpsNumero,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get ctpsSerie => $composableBuilder(
    column: $table.ctpsSerie,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<DateTime> get ctpsDataExpedicao => $composableBuilder(
    column: $table.ctpsDataExpedicao,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get ctpsUf => $composableBuilder(
    column: $table.ctpsUf,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get observacao => $composableBuilder(
    column: $table.observacao,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get logradouro => $composableBuilder(
    column: $table.logradouro,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get numero => $composableBuilder(
    column: $table.numero,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get complemento => $composableBuilder(
    column: $table.complemento,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get bairro => $composableBuilder(
    column: $table.bairro,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get cidade => $composableBuilder(
    column: $table.cidade,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get cep => $composableBuilder(
    column: $table.cep,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get municipioIbge => $composableBuilder(
    column: $table.municipioIbge,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get uf => $composableBuilder(
    column: $table.uf,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<int> get idPessoa => $composableBuilder(
    column: $table.idPessoa,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<int> get idCargo => $composableBuilder(
    column: $table.idCargo,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<int> get idSetor => $composableBuilder(
    column: $table.idSetor,
    builder: (column) => ColumnFilters(column),
  );
}

class $$ViewPessoaColaboradorsTableOrderingComposer
    extends Composer<_$AppDatabase, $ViewPessoaColaboradorsTable> {
  $$ViewPessoaColaboradorsTableOrderingComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnOrderings<int> get id => $composableBuilder(
    column: $table.id,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get nome => $composableBuilder(
    column: $table.nome,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get tipo => $composableBuilder(
    column: $table.tipo,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get email => $composableBuilder(
    column: $table.email,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get site => $composableBuilder(
    column: $table.site,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get cpfCnpj => $composableBuilder(
    column: $table.cpfCnpj,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get rgIe => $composableBuilder(
    column: $table.rgIe,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get matricula => $composableBuilder(
    column: $table.matricula,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<DateTime> get dataCadastro => $composableBuilder(
    column: $table.dataCadastro,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<DateTime> get dataAdmissao => $composableBuilder(
    column: $table.dataAdmissao,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<DateTime> get dataDemissao => $composableBuilder(
    column: $table.dataDemissao,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get ctpsNumero => $composableBuilder(
    column: $table.ctpsNumero,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get ctpsSerie => $composableBuilder(
    column: $table.ctpsSerie,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<DateTime> get ctpsDataExpedicao => $composableBuilder(
    column: $table.ctpsDataExpedicao,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get ctpsUf => $composableBuilder(
    column: $table.ctpsUf,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get observacao => $composableBuilder(
    column: $table.observacao,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get logradouro => $composableBuilder(
    column: $table.logradouro,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get numero => $composableBuilder(
    column: $table.numero,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get complemento => $composableBuilder(
    column: $table.complemento,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get bairro => $composableBuilder(
    column: $table.bairro,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get cidade => $composableBuilder(
    column: $table.cidade,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get cep => $composableBuilder(
    column: $table.cep,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get municipioIbge => $composableBuilder(
    column: $table.municipioIbge,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get uf => $composableBuilder(
    column: $table.uf,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<int> get idPessoa => $composableBuilder(
    column: $table.idPessoa,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<int> get idCargo => $composableBuilder(
    column: $table.idCargo,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<int> get idSetor => $composableBuilder(
    column: $table.idSetor,
    builder: (column) => ColumnOrderings(column),
  );
}

class $$ViewPessoaColaboradorsTableAnnotationComposer
    extends Composer<_$AppDatabase, $ViewPessoaColaboradorsTable> {
  $$ViewPessoaColaboradorsTableAnnotationComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  GeneratedColumn<int> get id =>
      $composableBuilder(column: $table.id, builder: (column) => column);

  GeneratedColumn<String> get nome =>
      $composableBuilder(column: $table.nome, builder: (column) => column);

  GeneratedColumn<String> get tipo =>
      $composableBuilder(column: $table.tipo, builder: (column) => column);

  GeneratedColumn<String> get email =>
      $composableBuilder(column: $table.email, builder: (column) => column);

  GeneratedColumn<String> get site =>
      $composableBuilder(column: $table.site, builder: (column) => column);

  GeneratedColumn<String> get cpfCnpj =>
      $composableBuilder(column: $table.cpfCnpj, builder: (column) => column);

  GeneratedColumn<String> get rgIe =>
      $composableBuilder(column: $table.rgIe, builder: (column) => column);

  GeneratedColumn<String> get matricula =>
      $composableBuilder(column: $table.matricula, builder: (column) => column);

  GeneratedColumn<DateTime> get dataCadastro => $composableBuilder(
    column: $table.dataCadastro,
    builder: (column) => column,
  );

  GeneratedColumn<DateTime> get dataAdmissao => $composableBuilder(
    column: $table.dataAdmissao,
    builder: (column) => column,
  );

  GeneratedColumn<DateTime> get dataDemissao => $composableBuilder(
    column: $table.dataDemissao,
    builder: (column) => column,
  );

  GeneratedColumn<String> get ctpsNumero => $composableBuilder(
    column: $table.ctpsNumero,
    builder: (column) => column,
  );

  GeneratedColumn<String> get ctpsSerie =>
      $composableBuilder(column: $table.ctpsSerie, builder: (column) => column);

  GeneratedColumn<DateTime> get ctpsDataExpedicao => $composableBuilder(
    column: $table.ctpsDataExpedicao,
    builder: (column) => column,
  );

  GeneratedColumn<String> get ctpsUf =>
      $composableBuilder(column: $table.ctpsUf, builder: (column) => column);

  GeneratedColumn<String> get observacao => $composableBuilder(
    column: $table.observacao,
    builder: (column) => column,
  );

  GeneratedColumn<String> get logradouro => $composableBuilder(
    column: $table.logradouro,
    builder: (column) => column,
  );

  GeneratedColumn<String> get numero =>
      $composableBuilder(column: $table.numero, builder: (column) => column);

  GeneratedColumn<String> get complemento => $composableBuilder(
    column: $table.complemento,
    builder: (column) => column,
  );

  GeneratedColumn<String> get bairro =>
      $composableBuilder(column: $table.bairro, builder: (column) => column);

  GeneratedColumn<String> get cidade =>
      $composableBuilder(column: $table.cidade, builder: (column) => column);

  GeneratedColumn<String> get cep =>
      $composableBuilder(column: $table.cep, builder: (column) => column);

  GeneratedColumn<String> get municipioIbge => $composableBuilder(
    column: $table.municipioIbge,
    builder: (column) => column,
  );

  GeneratedColumn<String> get uf =>
      $composableBuilder(column: $table.uf, builder: (column) => column);

  GeneratedColumn<int> get idPessoa =>
      $composableBuilder(column: $table.idPessoa, builder: (column) => column);

  GeneratedColumn<int> get idCargo =>
      $composableBuilder(column: $table.idCargo, builder: (column) => column);

  GeneratedColumn<int> get idSetor =>
      $composableBuilder(column: $table.idSetor, builder: (column) => column);
}

class $$ViewPessoaColaboradorsTableTableManager
    extends
        RootTableManager<
          _$AppDatabase,
          $ViewPessoaColaboradorsTable,
          ViewPessoaColaborador,
          $$ViewPessoaColaboradorsTableFilterComposer,
          $$ViewPessoaColaboradorsTableOrderingComposer,
          $$ViewPessoaColaboradorsTableAnnotationComposer,
          $$ViewPessoaColaboradorsTableCreateCompanionBuilder,
          $$ViewPessoaColaboradorsTableUpdateCompanionBuilder,
          (
            ViewPessoaColaborador,
            BaseReferences<
              _$AppDatabase,
              $ViewPessoaColaboradorsTable,
              ViewPessoaColaborador
            >,
          ),
          ViewPessoaColaborador,
          PrefetchHooks Function()
        > {
  $$ViewPessoaColaboradorsTableTableManager(
    _$AppDatabase db,
    $ViewPessoaColaboradorsTable table,
  ) : super(
        TableManagerState(
          db: db,
          table: table,
          createFilteringComposer:
              () => $$ViewPessoaColaboradorsTableFilterComposer(
                $db: db,
                $table: table,
              ),
          createOrderingComposer:
              () => $$ViewPessoaColaboradorsTableOrderingComposer(
                $db: db,
                $table: table,
              ),
          createComputedFieldComposer:
              () => $$ViewPessoaColaboradorsTableAnnotationComposer(
                $db: db,
                $table: table,
              ),
          updateCompanionCallback:
              ({
                Value<int?> id = const Value.absent(),
                Value<String?> nome = const Value.absent(),
                Value<String?> tipo = const Value.absent(),
                Value<String?> email = const Value.absent(),
                Value<String?> site = const Value.absent(),
                Value<String?> cpfCnpj = const Value.absent(),
                Value<String?> rgIe = const Value.absent(),
                Value<String?> matricula = const Value.absent(),
                Value<DateTime?> dataCadastro = const Value.absent(),
                Value<DateTime?> dataAdmissao = const Value.absent(),
                Value<DateTime?> dataDemissao = const Value.absent(),
                Value<String?> ctpsNumero = const Value.absent(),
                Value<String?> ctpsSerie = const Value.absent(),
                Value<DateTime?> ctpsDataExpedicao = const Value.absent(),
                Value<String?> ctpsUf = const Value.absent(),
                Value<String?> observacao = const Value.absent(),
                Value<String?> logradouro = const Value.absent(),
                Value<String?> numero = const Value.absent(),
                Value<String?> complemento = const Value.absent(),
                Value<String?> bairro = const Value.absent(),
                Value<String?> cidade = const Value.absent(),
                Value<String?> cep = const Value.absent(),
                Value<String?> municipioIbge = const Value.absent(),
                Value<String?> uf = const Value.absent(),
                Value<int?> idPessoa = const Value.absent(),
                Value<int?> idCargo = const Value.absent(),
                Value<int?> idSetor = const Value.absent(),
              }) => ViewPessoaColaboradorsCompanion(
                id: id,
                nome: nome,
                tipo: tipo,
                email: email,
                site: site,
                cpfCnpj: cpfCnpj,
                rgIe: rgIe,
                matricula: matricula,
                dataCadastro: dataCadastro,
                dataAdmissao: dataAdmissao,
                dataDemissao: dataDemissao,
                ctpsNumero: ctpsNumero,
                ctpsSerie: ctpsSerie,
                ctpsDataExpedicao: ctpsDataExpedicao,
                ctpsUf: ctpsUf,
                observacao: observacao,
                logradouro: logradouro,
                numero: numero,
                complemento: complemento,
                bairro: bairro,
                cidade: cidade,
                cep: cep,
                municipioIbge: municipioIbge,
                uf: uf,
                idPessoa: idPessoa,
                idCargo: idCargo,
                idSetor: idSetor,
              ),
          createCompanionCallback:
              ({
                Value<int?> id = const Value.absent(),
                Value<String?> nome = const Value.absent(),
                Value<String?> tipo = const Value.absent(),
                Value<String?> email = const Value.absent(),
                Value<String?> site = const Value.absent(),
                Value<String?> cpfCnpj = const Value.absent(),
                Value<String?> rgIe = const Value.absent(),
                Value<String?> matricula = const Value.absent(),
                Value<DateTime?> dataCadastro = const Value.absent(),
                Value<DateTime?> dataAdmissao = const Value.absent(),
                Value<DateTime?> dataDemissao = const Value.absent(),
                Value<String?> ctpsNumero = const Value.absent(),
                Value<String?> ctpsSerie = const Value.absent(),
                Value<DateTime?> ctpsDataExpedicao = const Value.absent(),
                Value<String?> ctpsUf = const Value.absent(),
                Value<String?> observacao = const Value.absent(),
                Value<String?> logradouro = const Value.absent(),
                Value<String?> numero = const Value.absent(),
                Value<String?> complemento = const Value.absent(),
                Value<String?> bairro = const Value.absent(),
                Value<String?> cidade = const Value.absent(),
                Value<String?> cep = const Value.absent(),
                Value<String?> municipioIbge = const Value.absent(),
                Value<String?> uf = const Value.absent(),
                Value<int?> idPessoa = const Value.absent(),
                Value<int?> idCargo = const Value.absent(),
                Value<int?> idSetor = const Value.absent(),
              }) => ViewPessoaColaboradorsCompanion.insert(
                id: id,
                nome: nome,
                tipo: tipo,
                email: email,
                site: site,
                cpfCnpj: cpfCnpj,
                rgIe: rgIe,
                matricula: matricula,
                dataCadastro: dataCadastro,
                dataAdmissao: dataAdmissao,
                dataDemissao: dataDemissao,
                ctpsNumero: ctpsNumero,
                ctpsSerie: ctpsSerie,
                ctpsDataExpedicao: ctpsDataExpedicao,
                ctpsUf: ctpsUf,
                observacao: observacao,
                logradouro: logradouro,
                numero: numero,
                complemento: complemento,
                bairro: bairro,
                cidade: cidade,
                cep: cep,
                municipioIbge: municipioIbge,
                uf: uf,
                idPessoa: idPessoa,
                idCargo: idCargo,
                idSetor: idSetor,
              ),
          withReferenceMapper:
              (p0) =>
                  p0
                      .map(
                        (e) => (
                          e.readTable(table),
                          BaseReferences(db, table, e),
                        ),
                      )
                      .toList(),
          prefetchHooksCallback: null,
        ),
      );
}

typedef $$ViewPessoaColaboradorsTableProcessedTableManager =
    ProcessedTableManager<
      _$AppDatabase,
      $ViewPessoaColaboradorsTable,
      ViewPessoaColaborador,
      $$ViewPessoaColaboradorsTableFilterComposer,
      $$ViewPessoaColaboradorsTableOrderingComposer,
      $$ViewPessoaColaboradorsTableAnnotationComposer,
      $$ViewPessoaColaboradorsTableCreateCompanionBuilder,
      $$ViewPessoaColaboradorsTableUpdateCompanionBuilder,
      (
        ViewPessoaColaborador,
        BaseReferences<
          _$AppDatabase,
          $ViewPessoaColaboradorsTable,
          ViewPessoaColaborador
        >,
      ),
      ViewPessoaColaborador,
      PrefetchHooks Function()
    >;

class $AppDatabaseManager {
  final _$AppDatabase _db;
  $AppDatabaseManager(this._db);
  $$AgendaNotificacaosTableTableManager get agendaNotificacaos =>
      $$AgendaNotificacaosTableTableManager(_db, _db.agendaNotificacaos);
  $$AgendaCompromissoConvidadosTableTableManager
  get agendaCompromissoConvidados =>
      $$AgendaCompromissoConvidadosTableTableManager(
        _db,
        _db.agendaCompromissoConvidados,
      );
  $$ReuniaoSalaEventosTableTableManager get reuniaoSalaEventos =>
      $$ReuniaoSalaEventosTableTableManager(_db, _db.reuniaoSalaEventos);
  $$RecadoDestinatariosTableTableManager get recadoDestinatarios =>
      $$RecadoDestinatariosTableTableManager(_db, _db.recadoDestinatarios);
  $$AgendaCompromissosTableTableManager get agendaCompromissos =>
      $$AgendaCompromissosTableTableManager(_db, _db.agendaCompromissos);
  $$RecadoRemetentesTableTableManager get recadoRemetentes =>
      $$RecadoRemetentesTableTableManager(_db, _db.recadoRemetentes);
  $$AgendaCategoriaCompromissosTableTableManager
  get agendaCategoriaCompromissos =>
      $$AgendaCategoriaCompromissosTableTableManager(
        _db,
        _db.agendaCategoriaCompromissos,
      );
  $$ReuniaoSalasTableTableManager get reuniaoSalas =>
      $$ReuniaoSalasTableTableManager(_db, _db.reuniaoSalas);
  $$ViewControleAcessosTableTableManager get viewControleAcessos =>
      $$ViewControleAcessosTableTableManager(_db, _db.viewControleAcessos);
  $$ViewPessoaUsuariosTableTableManager get viewPessoaUsuarios =>
      $$ViewPessoaUsuariosTableTableManager(_db, _db.viewPessoaUsuarios);
  $$ViewPessoaColaboradorsTableTableManager get viewPessoaColaboradors =>
      $$ViewPessoaColaboradorsTableTableManager(
        _db,
        _db.viewPessoaColaboradors,
      );
}
