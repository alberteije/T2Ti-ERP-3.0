// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'agenda_categoria_compromisso_dao.dart';

// ignore_for_file: type=lint
mixin _$AgendaCategoriaCompromissoDaoMixin on DatabaseAccessor<AppDatabase> {
  $AgendaCategoriaCompromissosTable get agendaCategoriaCompromissos =>
      attachedDatabase.agendaCategoriaCompromissos;
}
