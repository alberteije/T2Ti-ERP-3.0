// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'agenda_compromisso_dao.dart';

// ignore_for_file: type=lint
mixin _$AgendaCompromissoDaoMixin on DatabaseAccessor<AppDatabase> {
  $AgendaCompromissosTable get agendaCompromissos =>
      attachedDatabase.agendaCompromissos;
  $AgendaNotificacaosTable get agendaNotificacaos =>
      attachedDatabase.agendaNotificacaos;
  $AgendaCompromissoConvidadosTable get agendaCompromissoConvidados =>
      attachedDatabase.agendaCompromissoConvidados;
  $ViewPessoaColaboradorsTable get viewPessoaColaboradors =>
      attachedDatabase.viewPessoaColaboradors;
  $ReuniaoSalaEventosTable get reuniaoSalaEventos =>
      attachedDatabase.reuniaoSalaEventos;
  $ReuniaoSalasTable get reuniaoSalas => attachedDatabase.reuniaoSalas;
  $AgendaCategoriaCompromissosTable get agendaCategoriaCompromissos =>
      attachedDatabase.agendaCategoriaCompromissos;
}
