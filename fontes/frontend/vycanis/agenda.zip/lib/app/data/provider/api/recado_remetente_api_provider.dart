import 'package:agenda/app/data/provider/api/api_provider_base.dart';
import 'package:agenda/app/data/model/model_imports.dart';

class RecadoRemetenteApiProvider extends ApiProviderBase {
  static const _path = '/recado-remetente';

  Future<List<RecadoRemetenteModel>?> getList({Filter? filter}) {
    return super.getListBase(
      '$_path/',
      (json) => RecadoRemetenteModel.fromJson(json),
      filter: filter,
    );
  }

  Future<RecadoRemetenteModel?> getObject(dynamic pk) {
    return super.getObjectBase(
      _path,
      pk,
      (json) => RecadoRemetenteModel.fromJson(json),
    );
  }

  Future<RecadoRemetenteModel?>? insert(RecadoRemetenteModel model) {
    return super.insertBase(
      _path,
      model,
      (json) => RecadoRemetenteModel.fromJson(json),
    );
  }

  Future<RecadoRemetenteModel?>? update(RecadoRemetenteModel model) {
    return super.updateBase(
      _path,
      model,
      (json) => RecadoRemetenteModel.fromJson(json),
    );
  }

  Future<bool?> delete(dynamic pk) {
    return super.deleteBase(_path, pk);
  }
}
