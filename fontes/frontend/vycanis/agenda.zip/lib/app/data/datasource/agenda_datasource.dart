import 'package:flutter/material.dart';
import 'package:syncfusion_flutter_calendar/calendar.dart';
import 'package:agenda/app/data/model/model_imports.dart';

class AgendaDataSource extends CalendarDataSource {
  AgendaDataSource(List<AgendaCompromissoModel> compromissos) {
    appointments = compromissos;
  }

  @override
  DateTime getStartTime(int index) {
    final compromisso = appointments![index] as AgendaCompromissoModel;
    final data = compromisso.dataCompromisso ?? DateTime.now();
    final hora = compromisso.hora != null
        ? TimeOfDay(
            hour: int.parse(compromisso.hora!.split(':')[0]),
            minute: int.parse(compromisso.hora!.split(':')[1]),
          )
        : const TimeOfDay(hour: 0, minute: 0);

    return DateTime(data.year, data.month, data.day, hora.hour, hora.minute);
  }

  @override
  DateTime getEndTime(int index) {
    final compromisso = appointments![index] as AgendaCompromissoModel;
    final inicio = getStartTime(index);
    final duracao = compromisso.duracao ?? 60;
    return inicio.add(Duration(minutes: duracao));
  }

  @override
  String getSubject(int index) {
    final compromisso = appointments![index] as AgendaCompromissoModel;
    return compromisso.descricao ?? compromisso.agendaCategoriaCompromissoModel?.nome ?? "Compromisso";
  }

  @override
  Color getColor(int index) {
    final compromisso = appointments![index] as AgendaCompromissoModel;
    final corHex = compromisso.agendaCategoriaCompromissoModel?.cor ?? "#2196F3";
    return hexToColor(corHex);
  }

  Color hexToColor(String hex) {
    hex = hex.replaceAll("#", "");
    if (hex.length == 6) hex = "FF$hex";
    return Color(int.parse(hex, radix: 16));
  }
}
