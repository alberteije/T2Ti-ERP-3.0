import 'dart:convert';
import 'package:pluto_grid/pluto_grid.dart';
import 'package:agenda/app/data/model/model_imports.dart';

import 'package:agenda/app/infra/infra_imports.dart';
import 'package:intl/intl.dart';
import 'package:agenda/app/data/domain/domain_imports.dart';

class AgendaNotificacaoModel extends ModelBase {
  int? id;
  int? idAgendaCompromisso;
  DateTime? dataNotificacao;
  String? hora;
  String? tipo;

  AgendaNotificacaoModel({
    this.id,
    this.idAgendaCompromisso,
    this.dataNotificacao,
    this.hora,
    this.tipo = 'Email',
  });

  static List<String> dbColumns = <String>[
    'id',
    'data_notificacao',
    'hora',
    'tipo',
  ];

  static List<String> aliasColumns = <String>[
    'Id',
    'Data Notificacao',
    'Hora',
    'Tipo',
  ];

  AgendaNotificacaoModel.fromJson(Map<String, dynamic> jsonData) {
    id = jsonData['id'];
    idAgendaCompromisso = jsonData['idAgendaCompromisso'];
    dataNotificacao = jsonData['dataNotificacao'] != null ? DateTime.tryParse(jsonData['dataNotificacao']) : null;
    hora = jsonData['hora'];
    tipo = AgendaNotificacaoDomain.getTipo(jsonData['tipo']);
  }

  Map<String, dynamic> get toJson {
    Map<String, dynamic> jsonData = <String, dynamic>{};

    jsonData['id'] = id != 0 ? id : null;
    jsonData['idAgendaCompromisso'] = idAgendaCompromisso != 0 ? idAgendaCompromisso : null;
    jsonData['dataNotificacao'] = dataNotificacao != null ? DateFormat('yyyy-MM-ddT00:00:00').format(dataNotificacao!) : null;
    jsonData['hora'] = Util.removeMask(hora);
    jsonData['tipo'] = AgendaNotificacaoDomain.setTipo(tipo);

    return jsonData;
  }

  String objectEncodeJson() {
    final jsonData = toJson;
    return json.encode(jsonData);
  }

  static AgendaNotificacaoModel fromPlutoRow(PlutoRow row) {
    return AgendaNotificacaoModel(
      id: row.cells['id']?.value,
      idAgendaCompromisso: row.cells['idAgendaCompromisso']?.value,
      dataNotificacao: Util.stringToDate(row.cells['dataNotificacao']?.value),
      hora: row.cells['hora']?.value,
      tipo: row.cells['tipo']?.value,
    );
  }

  PlutoRow toPlutoRow() {
    return PlutoRow(
      cells: {
        'tempId': PlutoCell(value: tempId),
        'id': PlutoCell(value: id ?? 0),
        'idAgendaCompromisso': PlutoCell(value: idAgendaCompromisso ?? 0),
        'dataNotificacao': PlutoCell(value: dataNotificacao),
        'hora': PlutoCell(value: hora ?? ''),
        'tipo': PlutoCell(value: tipo ?? ''),
      },
    );
  }

  AgendaNotificacaoModel clone() {
    return AgendaNotificacaoModel(
      id: id,
      idAgendaCompromisso: idAgendaCompromisso,
      dataNotificacao: dataNotificacao,
      hora: hora,
      tipo: tipo,
    );
  }


}