import 'dart:convert';
import 'package:pluto_grid/pluto_grid.dart';
import 'package:agenda/app/data/model/model_imports.dart';


class AgendaCompromissoConvidadoModel extends ModelBase {
  int? id;
  int? idAgendaCompromisso;
  int? idColaborador;
  ViewPessoaColaboradorModel? viewPessoaColaboradorModel;

  AgendaCompromissoConvidadoModel({
    this.id,
    this.idAgendaCompromisso,
    this.idColaborador,
    ViewPessoaColaboradorModel? viewPessoaColaboradorModel,
  }) {
    this.viewPessoaColaboradorModel = viewPessoaColaboradorModel ?? ViewPessoaColaboradorModel();
  }

  static List<String> dbColumns = <String>[
    'id',
  ];

  static List<String> aliasColumns = <String>[
    'Id',
  ];

  AgendaCompromissoConvidadoModel.fromJson(Map<String, dynamic> jsonData) {
    id = jsonData['id'];
    idAgendaCompromisso = jsonData['idAgendaCompromisso'];
    idColaborador = jsonData['idColaborador'];
    viewPessoaColaboradorModel = jsonData['viewPessoaColaboradorModel'] == null ? ViewPessoaColaboradorModel() : ViewPessoaColaboradorModel.fromJson(jsonData['viewPessoaColaboradorModel']);
  }

  Map<String, dynamic> get toJson {
    Map<String, dynamic> jsonData = <String, dynamic>{};

    jsonData['id'] = id != 0 ? id : null;
    jsonData['idAgendaCompromisso'] = idAgendaCompromisso != 0 ? idAgendaCompromisso : null;
    jsonData['idColaborador'] = idColaborador != 0 ? idColaborador : null;
    jsonData['viewPessoaColaboradorModel'] = viewPessoaColaboradorModel?.toJson;
    jsonData['viewPessoaColaborador'] = viewPessoaColaboradorModel?.nome ?? '';

    return jsonData;
  }

  String objectEncodeJson() {
    final jsonData = toJson;
    return json.encode(jsonData);
  }

  static AgendaCompromissoConvidadoModel fromPlutoRow(PlutoRow row) {
    return AgendaCompromissoConvidadoModel(
      id: row.cells['id']?.value,
      idAgendaCompromisso: row.cells['idAgendaCompromisso']?.value,
      idColaborador: row.cells['idColaborador']?.value,
    );
  }

  PlutoRow toPlutoRow() {
    return PlutoRow(
      cells: {
        'tempId': PlutoCell(value: tempId),
        'id': PlutoCell(value: id ?? 0),
        'idAgendaCompromisso': PlutoCell(value: idAgendaCompromisso ?? 0),
        'idColaborador': PlutoCell(value: idColaborador ?? 0),
        'viewPessoaColaborador': PlutoCell(value: viewPessoaColaboradorModel?.nome ?? ''),
      },
    );
  }

  AgendaCompromissoConvidadoModel clone() {
    return AgendaCompromissoConvidadoModel(
      id: id,
      idAgendaCompromisso: idAgendaCompromisso,
      idColaborador: idColaborador,
      viewPessoaColaboradorModel: viewPessoaColaboradorModel?.clone(),
    );
  }


}