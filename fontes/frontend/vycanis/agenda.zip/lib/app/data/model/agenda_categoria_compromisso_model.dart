import 'dart:convert';
import 'package:pluto_grid/pluto_grid.dart';
import 'package:agenda/app/data/model/model_imports.dart';


class AgendaCategoriaCompromissoModel extends ModelBase {
  int? id;
  String? nome;
  String? cor;

  AgendaCategoriaCompromissoModel({
    this.id,
    this.nome,
    this.cor,
  });

  static List<String> dbColumns = <String>[
    'id',
    'nome',
    'cor',
  ];

  static List<String> aliasColumns = <String>[
    'Id',
    'Nome',
    'Cor',
  ];

  AgendaCategoriaCompromissoModel.fromJson(Map<String, dynamic> jsonData) {
    id = jsonData['id'];
    nome = jsonData['nome'];
    cor = jsonData['cor'];
  }

  Map<String, dynamic> get toJson {
    Map<String, dynamic> jsonData = <String, dynamic>{};

    jsonData['id'] = id != 0 ? id : null;
    jsonData['nome'] = nome;
    jsonData['cor'] = cor;

    return jsonData;
  }

  String objectEncodeJson() {
    final jsonData = toJson;
    return json.encode(jsonData);
  }

  static AgendaCategoriaCompromissoModel fromPlutoRow(PlutoRow row) {
    return AgendaCategoriaCompromissoModel(
      id: row.cells['id']?.value,
      nome: row.cells['nome']?.value,
      cor: row.cells['cor']?.value,
    );
  }

  PlutoRow toPlutoRow() {
    return PlutoRow(
      cells: {
        'tempId': PlutoCell(value: tempId),
        'id': PlutoCell(value: id ?? 0),
        'nome': PlutoCell(value: nome ?? ''),
        'cor': PlutoCell(value: cor ?? ''),
      },
    );
  }

  AgendaCategoriaCompromissoModel clone() {
    return AgendaCategoriaCompromissoModel(
      id: id,
      nome: nome,
      cor: cor,
    );
  }


}