import 'dart:convert';
import 'package:pluto_grid/pluto_grid.dart';
import 'package:agenda/app/data/model/model_imports.dart';


class RecadoDestinatarioModel extends ModelBase {
  int? id;
  int? idRecadoRemetente;
  int? idColaborador;
  ViewPessoaColaboradorModel? viewPessoaColaboradorModel;

  RecadoDestinatarioModel({
    this.id,
    this.idRecadoRemetente,
    this.idColaborador,
    ViewPessoaColaboradorModel? viewPessoaColaboradorModel,
  }) {
    this.viewPessoaColaboradorModel = viewPessoaColaboradorModel ?? ViewPessoaColaboradorModel();
  }

  static List<String> dbColumns = <String>[
    'id',
  ];

  static List<String> aliasColumns = <String>[
    'Id',
  ];

  RecadoDestinatarioModel.fromJson(Map<String, dynamic> jsonData) {
    id = jsonData['id'];
    idRecadoRemetente = jsonData['idRecadoRemetente'];
    idColaborador = jsonData['idColaborador'];
    viewPessoaColaboradorModel = jsonData['viewPessoaColaboradorModel'] == null ? ViewPessoaColaboradorModel() : ViewPessoaColaboradorModel.fromJson(jsonData['viewPessoaColaboradorModel']);
  }

  Map<String, dynamic> get toJson {
    Map<String, dynamic> jsonData = <String, dynamic>{};

    jsonData['id'] = id != 0 ? id : null;
    jsonData['idRecadoRemetente'] = idRecadoRemetente != 0 ? idRecadoRemetente : null;
    jsonData['idColaborador'] = idColaborador != 0 ? idColaborador : null;
    jsonData['viewPessoaColaboradorModel'] = viewPessoaColaboradorModel?.toJson;
    jsonData['viewPessoaColaborador'] = viewPessoaColaboradorModel?.nome ?? '';

    return jsonData;
  }

  String objectEncodeJson() {
    final jsonData = toJson;
    return json.encode(jsonData);
  }

  static RecadoDestinatarioModel fromPlutoRow(PlutoRow row) {
    return RecadoDestinatarioModel(
      id: row.cells['id']?.value,
      idRecadoRemetente: row.cells['idRecadoRemetente']?.value,
      idColaborador: row.cells['idColaborador']?.value,
    );
  }

  PlutoRow toPlutoRow() {
    return PlutoRow(
      cells: {
        'tempId': PlutoCell(value: tempId),
        'id': PlutoCell(value: id ?? 0),
        'idRecadoRemetente': PlutoCell(value: idRecadoRemetente ?? 0),
        'idColaborador': PlutoCell(value: idColaborador ?? 0),
        'viewPessoaColaborador': PlutoCell(value: viewPessoaColaboradorModel?.nome ?? ''),
      },
    );
  }

  RecadoDestinatarioModel clone() {
    return RecadoDestinatarioModel(
      id: id,
      idRecadoRemetente: idRecadoRemetente,
      idColaborador: idColaborador,
      viewPessoaColaboradorModel: viewPessoaColaboradorModel?.clone(),
    );
  }


}