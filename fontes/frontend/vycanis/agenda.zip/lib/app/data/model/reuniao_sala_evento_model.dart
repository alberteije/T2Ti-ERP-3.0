import 'dart:convert';
import 'package:pluto_grid/pluto_grid.dart';
import 'package:agenda/app/data/model/model_imports.dart';

import 'package:agenda/app/infra/infra_imports.dart';
import 'package:intl/intl.dart';

class ReuniaoSalaEventoModel extends ModelBase {
  int? id;
  int? idAgendaCompromisso;
  int? idReuniaoSala;
  DateTime? dataReserva;
  ReuniaoSalaModel? reuniaoSalaModel;

  ReuniaoSalaEventoModel({
    this.id,
    this.idAgendaCompromisso,
    this.idReuniaoSala,
    this.dataReserva,
    ReuniaoSalaModel? reuniaoSalaModel,
  }) {
    this.reuniaoSalaModel = reuniaoSalaModel ?? ReuniaoSalaModel();
  }

  static List<String> dbColumns = <String>[
    'id',
    'data_reserva',
  ];

  static List<String> aliasColumns = <String>[
    'Id',
    'Data Reserva',
  ];

  ReuniaoSalaEventoModel.fromJson(Map<String, dynamic> jsonData) {
    id = jsonData['id'];
    idAgendaCompromisso = jsonData['idAgendaCompromisso'];
    idReuniaoSala = jsonData['idReuniaoSala'];
    dataReserva = jsonData['dataReserva'] != null ? DateTime.tryParse(jsonData['dataReserva']) : null;
    reuniaoSalaModel = jsonData['reuniaoSalaModel'] == null ? ReuniaoSalaModel() : ReuniaoSalaModel.fromJson(jsonData['reuniaoSalaModel']);
  }

  Map<String, dynamic> get toJson {
    Map<String, dynamic> jsonData = <String, dynamic>{};

    jsonData['id'] = id != 0 ? id : null;
    jsonData['idAgendaCompromisso'] = idAgendaCompromisso != 0 ? idAgendaCompromisso : null;
    jsonData['idReuniaoSala'] = idReuniaoSala != 0 ? idReuniaoSala : null;
    jsonData['dataReserva'] = dataReserva != null ? DateFormat('yyyy-MM-ddT00:00:00').format(dataReserva!) : null;
    jsonData['reuniaoSalaModel'] = reuniaoSalaModel?.toJson;
    jsonData['reuniaoSala'] = reuniaoSalaModel?.nome ?? '';

    return jsonData;
  }

  String objectEncodeJson() {
    final jsonData = toJson;
    return json.encode(jsonData);
  }

  static ReuniaoSalaEventoModel fromPlutoRow(PlutoRow row) {
    return ReuniaoSalaEventoModel(
      id: row.cells['id']?.value,
      idAgendaCompromisso: row.cells['idAgendaCompromisso']?.value,
      idReuniaoSala: row.cells['idReuniaoSala']?.value,
      dataReserva: Util.stringToDate(row.cells['dataReserva']?.value),
    );
  }

  PlutoRow toPlutoRow() {
    return PlutoRow(
      cells: {
        'tempId': PlutoCell(value: tempId),
        'id': PlutoCell(value: id ?? 0),
        'idAgendaCompromisso': PlutoCell(value: idAgendaCompromisso ?? 0),
        'idReuniaoSala': PlutoCell(value: idReuniaoSala ?? 0),
        'dataReserva': PlutoCell(value: dataReserva),
        'reuniaoSala': PlutoCell(value: reuniaoSalaModel?.nome ?? ''),
      },
    );
  }

  ReuniaoSalaEventoModel clone() {
    return ReuniaoSalaEventoModel(
      id: id,
      idAgendaCompromisso: idAgendaCompromisso,
      idReuniaoSala: idReuniaoSala,
      dataReserva: dataReserva,
      reuniaoSalaModel: reuniaoSalaModel?.clone(),
    );
  }


}