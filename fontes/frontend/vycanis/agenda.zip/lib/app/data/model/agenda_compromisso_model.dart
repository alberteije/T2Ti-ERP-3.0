import 'dart:convert';
import 'package:pluto_grid/pluto_grid.dart';
import 'package:agenda/app/data/model/model_imports.dart';

import 'package:agenda/app/infra/infra_imports.dart';
import 'package:intl/intl.dart';
import 'package:agenda/app/data/domain/domain_imports.dart';

class AgendaCompromissoModel extends ModelBase {
  int? id;
  int? idAgendaCategoriaCompromisso;
  int? idColaborador;
  DateTime? dataCompromisso;
  String? hora;
  int? duracao;
  String? tipo;
  String? onde;
  String? descricao;
  List<AgendaNotificacaoModel>? agendaNotificacaoModelList;
  List<AgendaCompromissoConvidadoModel>? agendaCompromissoConvidadoModelList;
  List<ReuniaoSalaEventoModel>? reuniaoSalaEventoModelList;
  ViewPessoaColaboradorModel? viewPessoaColaboradorModel;
  AgendaCategoriaCompromissoModel? agendaCategoriaCompromissoModel;

  AgendaCompromissoModel({
    this.id,
    this.idAgendaCategoriaCompromisso,
    this.idColaborador,
    this.dataCompromisso,
    this.hora,
    this.duracao,
    this.tipo = 'Pessoal',
    this.onde,
    this.descricao,
    List<AgendaNotificacaoModel>? agendaNotificacaoModelList,
    List<AgendaCompromissoConvidadoModel>? agendaCompromissoConvidadoModelList,
    List<ReuniaoSalaEventoModel>? reuniaoSalaEventoModelList,
    ViewPessoaColaboradorModel? viewPessoaColaboradorModel,
    AgendaCategoriaCompromissoModel? agendaCategoriaCompromissoModel,
  }) {
    this.agendaNotificacaoModelList = agendaNotificacaoModelList?.toList(growable: true) ?? [];
    this.agendaCompromissoConvidadoModelList = agendaCompromissoConvidadoModelList?.toList(growable: true) ?? [];
    this.reuniaoSalaEventoModelList = reuniaoSalaEventoModelList?.toList(growable: true) ?? [];
    this.viewPessoaColaboradorModel = viewPessoaColaboradorModel ?? ViewPessoaColaboradorModel();
    this.agendaCategoriaCompromissoModel = agendaCategoriaCompromissoModel ?? AgendaCategoriaCompromissoModel();
  }

  static List<String> dbColumns = <String>[
    'id',
    'data_compromisso',
    'hora',
    'duracao',
    'tipo',
    'onde',
    'descricao',
  ];

  static List<String> aliasColumns = <String>[
    'Id',
    'Data Compromisso',
    'Hora',
    'Duracao',
    'Tipo',
    'Onde',
    'Descricao',
  ];

  AgendaCompromissoModel.fromJson(Map<String, dynamic> jsonData) {
    id = jsonData['id'];
    idAgendaCategoriaCompromisso = jsonData['idAgendaCategoriaCompromisso'];
    idColaborador = jsonData['idColaborador'];
    dataCompromisso = jsonData['dataCompromisso'] != null ? DateTime.tryParse(jsonData['dataCompromisso']) : null;
    hora = jsonData['hora'];
    duracao = jsonData['duracao'];
    tipo = AgendaCompromissoDomain.getTipo(jsonData['tipo']);
    onde = jsonData['onde'];
    descricao = jsonData['descricao'];
    agendaNotificacaoModelList = (jsonData['agendaNotificacaoModelList'] as Iterable?)?.map((m) => AgendaNotificacaoModel.fromJson(m)).toList() ?? [];
    agendaCompromissoConvidadoModelList = (jsonData['agendaCompromissoConvidadoModelList'] as Iterable?)?.map((m) => AgendaCompromissoConvidadoModel.fromJson(m)).toList() ?? [];
    reuniaoSalaEventoModelList = (jsonData['reuniaoSalaEventoModelList'] as Iterable?)?.map((m) => ReuniaoSalaEventoModel.fromJson(m)).toList() ?? [];
    viewPessoaColaboradorModel = jsonData['viewPessoaColaboradorModel'] == null ? ViewPessoaColaboradorModel() : ViewPessoaColaboradorModel.fromJson(jsonData['viewPessoaColaboradorModel']);
    agendaCategoriaCompromissoModel = jsonData['agendaCategoriaCompromissoModel'] == null ? AgendaCategoriaCompromissoModel() : AgendaCategoriaCompromissoModel.fromJson(jsonData['agendaCategoriaCompromissoModel']);
  }

  Map<String, dynamic> get toJson {
    Map<String, dynamic> jsonData = <String, dynamic>{};

    jsonData['id'] = id != 0 ? id : null;
    jsonData['idAgendaCategoriaCompromisso'] = idAgendaCategoriaCompromisso != 0 ? idAgendaCategoriaCompromisso : null;
    jsonData['idColaborador'] = idColaborador != 0 ? idColaborador : null;
    jsonData['dataCompromisso'] = dataCompromisso != null ? DateFormat('yyyy-MM-ddT00:00:00').format(dataCompromisso!) : null;
    jsonData['hora'] = hora;
    jsonData['duracao'] = duracao;
    jsonData['tipo'] = AgendaCompromissoDomain.setTipo(tipo);
    jsonData['onde'] = onde;
    jsonData['descricao'] = descricao;
    
		var agendaNotificacaoModelLocalList = []; 
		for (AgendaNotificacaoModel object in agendaNotificacaoModelList ?? []) { 
			agendaNotificacaoModelLocalList.add(object.toJson); 
		}
		jsonData['agendaNotificacaoModelList'] = agendaNotificacaoModelLocalList;
    
		var agendaCompromissoConvidadoModelLocalList = []; 
		for (AgendaCompromissoConvidadoModel object in agendaCompromissoConvidadoModelList ?? []) { 
			agendaCompromissoConvidadoModelLocalList.add(object.toJson); 
		}
		jsonData['agendaCompromissoConvidadoModelList'] = agendaCompromissoConvidadoModelLocalList;
    
		var reuniaoSalaEventoModelLocalList = []; 
		for (ReuniaoSalaEventoModel object in reuniaoSalaEventoModelList ?? []) { 
			reuniaoSalaEventoModelLocalList.add(object.toJson); 
		}
		jsonData['reuniaoSalaEventoModelList'] = reuniaoSalaEventoModelLocalList;
    jsonData['viewPessoaColaboradorModel'] = viewPessoaColaboradorModel?.toJson;
    jsonData['viewPessoaColaborador'] = viewPessoaColaboradorModel?.nome ?? '';
    jsonData['agendaCategoriaCompromissoModel'] = agendaCategoriaCompromissoModel?.toJson;
    jsonData['agendaCategoriaCompromisso'] = agendaCategoriaCompromissoModel?.nome ?? '';

    return jsonData;
  }

  String objectEncodeJson() {
    final jsonData = toJson;
    return json.encode(jsonData);
  }

  static AgendaCompromissoModel fromPlutoRow(PlutoRow row) {
    return AgendaCompromissoModel(
      id: row.cells['id']?.value,
      idAgendaCategoriaCompromisso: row.cells['idAgendaCategoriaCompromisso']?.value,
      idColaborador: row.cells['idColaborador']?.value,
      dataCompromisso: Util.stringToDate(row.cells['dataCompromisso']?.value),
      hora: row.cells['hora']?.value,
      duracao: row.cells['duracao']?.value,
      tipo: row.cells['tipo']?.value,
      onde: row.cells['onde']?.value,
      descricao: row.cells['descricao']?.value,
    );
  }

  PlutoRow toPlutoRow() {
    return PlutoRow(
      cells: {
        'tempId': PlutoCell(value: tempId),
        'id': PlutoCell(value: id ?? 0),
        'idAgendaCategoriaCompromisso': PlutoCell(value: idAgendaCategoriaCompromisso ?? 0),
        'idColaborador': PlutoCell(value: idColaborador ?? 0),
        'dataCompromisso': PlutoCell(value: dataCompromisso),
        'hora': PlutoCell(value: hora ?? ''),
        'duracao': PlutoCell(value: duracao ?? 0),
        'tipo': PlutoCell(value: tipo ?? ''),
        'onde': PlutoCell(value: onde ?? ''),
        'descricao': PlutoCell(value: descricao ?? ''),
        'viewPessoaColaborador': PlutoCell(value: viewPessoaColaboradorModel?.nome ?? ''),
        'agendaCategoriaCompromisso': PlutoCell(value: agendaCategoriaCompromissoModel?.nome ?? ''),
      },
    );
  }

  AgendaCompromissoModel clone() {
    return AgendaCompromissoModel(
      id: id,
      idAgendaCategoriaCompromisso: idAgendaCategoriaCompromisso,
      idColaborador: idColaborador,
      dataCompromisso: dataCompromisso,
      hora: hora,
      duracao: duracao,
      tipo: tipo,
      onde: onde,
      descricao: descricao,
      agendaNotificacaoModelList: agendaNotificacaoModelListClone(agendaNotificacaoModelList!),
      agendaCompromissoConvidadoModelList: agendaCompromissoConvidadoModelListClone(agendaCompromissoConvidadoModelList!),
      reuniaoSalaEventoModelList: reuniaoSalaEventoModelListClone(reuniaoSalaEventoModelList!),
      viewPessoaColaboradorModel: viewPessoaColaboradorModel?.clone(),
      agendaCategoriaCompromissoModel: agendaCategoriaCompromissoModel?.clone(),
    );
  }

  agendaNotificacaoModelListClone(List<AgendaNotificacaoModel> agendaNotificacaoModelList) { 
		List<AgendaNotificacaoModel> resultList = [];
		for (var agendaNotificacaoModel in agendaNotificacaoModelList) {
			resultList.add(agendaNotificacaoModel.clone());
		}
		return resultList;
	}

  agendaCompromissoConvidadoModelListClone(List<AgendaCompromissoConvidadoModel> agendaCompromissoConvidadoModelList) { 
		List<AgendaCompromissoConvidadoModel> resultList = [];
		for (var agendaCompromissoConvidadoModel in agendaCompromissoConvidadoModelList) {
			resultList.add(agendaCompromissoConvidadoModel.clone());
		}
		return resultList;
	}

  reuniaoSalaEventoModelListClone(List<ReuniaoSalaEventoModel> reuniaoSalaEventoModelList) { 
		List<ReuniaoSalaEventoModel> resultList = [];
		for (var reuniaoSalaEventoModel in reuniaoSalaEventoModelList) {
			resultList.add(reuniaoSalaEventoModel.clone());
		}
		return resultList;
	}


}