import 'dart:convert';
import 'package:pluto_grid/pluto_grid.dart';
import 'package:agenda/app/data/model/model_imports.dart';


class ReuniaoSalaModel extends ModelBase {
  int? id;
  String? predio;
  String? nome;
  String? andar;
  String? numero;

  ReuniaoSalaModel({
    this.id,
    this.predio,
    this.nome,
    this.andar,
    this.numero,
  });

  static List<String> dbColumns = <String>[
    'id',
    'predio',
    'nome',
    'andar',
    'numero',
  ];

  static List<String> aliasColumns = <String>[
    'Id',
    'Predio',
    'Nome',
    'Andar',
    'Numero',
  ];

  ReuniaoSalaModel.fromJson(Map<String, dynamic> jsonData) {
    id = jsonData['id'];
    predio = jsonData['predio'];
    nome = jsonData['nome'];
    andar = jsonData['andar'];
    numero = jsonData['numero'];
  }

  Map<String, dynamic> get toJson {
    Map<String, dynamic> jsonData = <String, dynamic>{};

    jsonData['id'] = id != 0 ? id : null;
    jsonData['predio'] = predio;
    jsonData['nome'] = nome;
    jsonData['andar'] = andar;
    jsonData['numero'] = numero;

    return jsonData;
  }

  String objectEncodeJson() {
    final jsonData = toJson;
    return json.encode(jsonData);
  }

  static ReuniaoSalaModel fromPlutoRow(PlutoRow row) {
    return ReuniaoSalaModel(
      id: row.cells['id']?.value,
      predio: row.cells['predio']?.value,
      nome: row.cells['nome']?.value,
      andar: row.cells['andar']?.value,
      numero: row.cells['numero']?.value,
    );
  }

  PlutoRow toPlutoRow() {
    return PlutoRow(
      cells: {
        'tempId': PlutoCell(value: tempId),
        'id': PlutoCell(value: id ?? 0),
        'predio': PlutoCell(value: predio ?? ''),
        'nome': PlutoCell(value: nome ?? ''),
        'andar': PlutoCell(value: andar ?? ''),
        'numero': PlutoCell(value: numero ?? ''),
      },
    );
  }

  ReuniaoSalaModel clone() {
    return ReuniaoSalaModel(
      id: id,
      predio: predio,
      nome: nome,
      andar: andar,
      numero: numero,
    );
  }


}