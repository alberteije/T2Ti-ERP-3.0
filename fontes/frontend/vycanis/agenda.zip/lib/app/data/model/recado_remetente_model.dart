import 'dart:convert';
import 'package:pluto_grid/pluto_grid.dart';
import 'package:agenda/app/data/model/model_imports.dart';

import 'package:agenda/app/infra/infra_imports.dart';
import 'package:intl/intl.dart';

class RecadoRemetenteModel extends ModelBase {
  int? id;
  int? idColaborador;
  DateTime? dataEnvio;
  String? horaEnvio;
  String? assunto;
  String? texto;
  List<RecadoDestinatarioModel>? recadoDestinatarioModelList;
  ViewPessoaColaboradorModel? viewPessoaColaboradorModel;

  RecadoRemetenteModel({
    this.id,
    this.idColaborador,
    this.dataEnvio,
    this.horaEnvio,
    this.assunto,
    this.texto,
    List<RecadoDestinatarioModel>? recadoDestinatarioModelList,
    ViewPessoaColaboradorModel? viewPessoaColaboradorModel,
  }) {
    this.recadoDestinatarioModelList = recadoDestinatarioModelList?.toList(growable: true) ?? [];
    this.viewPessoaColaboradorModel = viewPessoaColaboradorModel ?? ViewPessoaColaboradorModel();
  }

  static List<String> dbColumns = <String>[
    'id',
    'data_envio',
    'hora_envio',
    'assunto',
    'texto',
  ];

  static List<String> aliasColumns = <String>[
    'Id',
    'Data Envio',
    'Hora Envio',
    'Assunto',
    'Texto',
  ];

  RecadoRemetenteModel.fromJson(Map<String, dynamic> jsonData) {
    id = jsonData['id'];
    idColaborador = jsonData['idColaborador'];
    dataEnvio = jsonData['dataEnvio'] != null ? DateTime.tryParse(jsonData['dataEnvio']) : null;
    horaEnvio = jsonData['horaEnvio'];
    assunto = jsonData['assunto'];
    texto = jsonData['texto'];
    recadoDestinatarioModelList = (jsonData['recadoDestinatarioModelList'] as Iterable?)?.map((m) => RecadoDestinatarioModel.fromJson(m)).toList() ?? [];
    viewPessoaColaboradorModel = jsonData['viewPessoaColaboradorModel'] == null ? ViewPessoaColaboradorModel() : ViewPessoaColaboradorModel.fromJson(jsonData['viewPessoaColaboradorModel']);
  }

  Map<String, dynamic> get toJson {
    Map<String, dynamic> jsonData = <String, dynamic>{};

    jsonData['id'] = id != 0 ? id : null;
    jsonData['idColaborador'] = idColaborador != 0 ? idColaborador : null;
    jsonData['dataEnvio'] = dataEnvio != null ? DateFormat('yyyy-MM-ddT00:00:00').format(dataEnvio!) : null;
    jsonData['horaEnvio'] = Util.removeMask(horaEnvio);
    jsonData['assunto'] = assunto;
    jsonData['texto'] = texto;
    
		var recadoDestinatarioModelLocalList = []; 
		for (RecadoDestinatarioModel object in recadoDestinatarioModelList ?? []) { 
			recadoDestinatarioModelLocalList.add(object.toJson); 
		}
		jsonData['recadoDestinatarioModelList'] = recadoDestinatarioModelLocalList;
    jsonData['viewPessoaColaboradorModel'] = viewPessoaColaboradorModel?.toJson;
    jsonData['viewPessoaColaborador'] = viewPessoaColaboradorModel?.nome ?? '';

    return jsonData;
  }

  String objectEncodeJson() {
    final jsonData = toJson;
    return json.encode(jsonData);
  }

  static RecadoRemetenteModel fromPlutoRow(PlutoRow row) {
    return RecadoRemetenteModel(
      id: row.cells['id']?.value,
      idColaborador: row.cells['idColaborador']?.value,
      dataEnvio: Util.stringToDate(row.cells['dataEnvio']?.value),
      horaEnvio: row.cells['horaEnvio']?.value,
      assunto: row.cells['assunto']?.value,
      texto: row.cells['texto']?.value,
    );
  }

  PlutoRow toPlutoRow() {
    return PlutoRow(
      cells: {
        'tempId': PlutoCell(value: tempId),
        'id': PlutoCell(value: id ?? 0),
        'idColaborador': PlutoCell(value: idColaborador ?? 0),
        'dataEnvio': PlutoCell(value: dataEnvio),
        'horaEnvio': PlutoCell(value: horaEnvio ?? ''),
        'assunto': PlutoCell(value: assunto ?? ''),
        'texto': PlutoCell(value: texto ?? ''),
        'viewPessoaColaborador': PlutoCell(value: viewPessoaColaboradorModel?.nome ?? ''),
      },
    );
  }

  RecadoRemetenteModel clone() {
    return RecadoRemetenteModel(
      id: id,
      idColaborador: idColaborador,
      dataEnvio: dataEnvio,
      horaEnvio: horaEnvio,
      assunto: assunto,
      texto: texto,
      recadoDestinatarioModelList: recadoDestinatarioModelListClone(recadoDestinatarioModelList!),
      viewPessoaColaboradorModel: viewPessoaColaboradorModel?.clone(),
    );
  }

  recadoDestinatarioModelListClone(List<RecadoDestinatarioModel> recadoDestinatarioModelList) { 
		List<RecadoDestinatarioModel> resultList = [];
		for (var recadoDestinatarioModel in recadoDestinatarioModelList) {
			resultList.add(recadoDestinatarioModel.clone());
		}
		return resultList;
	}


}