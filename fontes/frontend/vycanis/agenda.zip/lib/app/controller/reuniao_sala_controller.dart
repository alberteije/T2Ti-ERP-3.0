import 'package:flutter/material.dart';
import 'package:get/get.dart';

import 'package:agenda/app/page/shared_widget/message_dialog.dart';
import 'package:agenda/app/page/grid_columns/grid_columns_imports.dart';
import 'package:agenda/app/routes/app_routes.dart';
import 'package:agenda/app/controller/controller_imports.dart';
import 'package:agenda/app/data/model/model_imports.dart';
import 'package:agenda/app/data/repository/reuniao_sala_repository.dart';

class ReuniaoSalaController extends ControllerBase<ReuniaoSalaModel, ReuniaoSalaRepository> {

  ReuniaoSalaController({required super.repository}) {
    dbColumns = ReuniaoSalaModel.dbColumns;
    aliasColumns = ReuniaoSalaModel.aliasColumns;
    gridColumns = reuniaoSalaGridColumns();
    functionName = "reuniao_sala";
    screenTitle = "Sala de Reunião";
  }

  @override
  ReuniaoSalaModel createNewModel() => ReuniaoSalaModel();

  @override
  final standardFieldForFilter = ReuniaoSalaModel.aliasColumns[ReuniaoSalaModel.dbColumns.indexOf('predio')];

  final predioController = TextEditingController();
  final nomeController = TextEditingController();
  final andarController = TextEditingController();
  final numeroController = TextEditingController();

  final Map<String, dynamic> mobileConfig = {
    'primaryColumns': ['predio'],
    'secondaryColumns': ['nome'],
  };

  List<Map<String, dynamic>> get mobileItems {
    return modelList.map((reuniaoSala) => reuniaoSala.toJson).toList();
  }

  @override
  void prepareForInsert() {
    isNewRecord = true;
    currentModel = createNewModel();
    _resetForm();
    Get.toNamed(Routes.reuniaoSalaEditPage);
  }

  void _resetForm() {
    formWasChanged = false;
    predioController.text = '';
    nomeController.text = '';
    andarController.text = '';
    numeroController.text = '';
  }

  @override
  void selectRowForEditingById(int id) {
    final model = modelList.firstWhere((m) => m.id == id);
    currentModel = model.clone();
    updateControllersFromModel();
    Get.toNamed(Routes.reuniaoSalaEditPage);
  }

  void updateControllersFromModel() {
    predioController.text = currentModel.predio ?? '';
    nomeController.text = currentModel.nome ?? '';
    andarController.text = currentModel.andar ?? '';
    numeroController.text = currentModel.numero ?? '';
    formWasChanged = false;
  }

  @override
  Future<void> save() async {
    if (!formKey.currentState!.validate()) {
      showErrorSnackBar(message: 'validator_form_message'.tr);
      return;
    }

    final existingIndex = modelList.indexWhere((m) => m.id == currentModel.id);

    if (existingIndex >= 0) {
      modelList[existingIndex] = currentModel.clone();
    }

    final result = await repository.save(reuniaoSalaModel: currentModel);
    if (result == null) return;

    if (existingIndex >= 0) {
      modelList[existingIndex] = result;
    } else {
      modelList.insert(0, result);
    }

    if (!GetPlatform.isMobile) {
      updateGridRow(result);
    }

    Get.back(result: true);
  }


  @override
  void onClose() {
    predioController.dispose();
    nomeController.dispose();
    andarController.dispose();
    numeroController.dispose();
    super.onClose();
  }

}