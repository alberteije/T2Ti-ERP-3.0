import 'package:flutter/material.dart';
import 'package:get/get.dart';

import 'package:agenda/app/page/shared_widget/message_dialog.dart';
import 'package:agenda/app/page/grid_columns/grid_columns_imports.dart';
import 'package:agenda/app/routes/app_routes.dart';
import 'package:agenda/app/controller/controller_imports.dart';
import 'package:agenda/app/data/model/model_imports.dart';
import 'package:agenda/app/data/repository/agenda_categoria_compromisso_repository.dart';

class AgendaCategoriaCompromissoController extends ControllerBase<AgendaCategoriaCompromissoModel, AgendaCategoriaCompromissoRepository> {

  AgendaCategoriaCompromissoController({required super.repository}) {
    dbColumns = AgendaCategoriaCompromissoModel.dbColumns;
    aliasColumns = AgendaCategoriaCompromissoModel.aliasColumns;
    gridColumns = agendaCategoriaCompromissoGridColumns();
    functionName = "agenda_categoria_compromisso";
    screenTitle = "Categoria Compromisso";
  }

  @override
  AgendaCategoriaCompromissoModel createNewModel() => AgendaCategoriaCompromissoModel();

  @override
  final standardFieldForFilter = AgendaCategoriaCompromissoModel.aliasColumns[AgendaCategoriaCompromissoModel.dbColumns.indexOf('nome')];

  final nomeController = TextEditingController();
  final corController = TextEditingController();

  final Map<String, dynamic> mobileConfig = {
    'primaryColumns': ['nome'],
    'secondaryColumns': ['cor'],
  };

  List<Map<String, dynamic>> get mobileItems {
    return modelList.map((agendaCategoriaCompromisso) => agendaCategoriaCompromisso.toJson).toList();
  }

  @override
  void prepareForInsert() {
    isNewRecord = true;
    currentModel = createNewModel();
    _resetForm();
    Get.toNamed(Routes.agendaCategoriaCompromissoEditPage);
  }

  void _resetForm() {
    formWasChanged = false;
    nomeController.text = '';
    corController.text = '';
  }

  @override
  void selectRowForEditingById(int id) {
    final model = modelList.firstWhere((m) => m.id == id);
    currentModel = model.clone();
    updateControllersFromModel();
    Get.toNamed(Routes.agendaCategoriaCompromissoEditPage);
  }

  void updateControllersFromModel() {
    nomeController.text = currentModel.nome ?? '';
    corController.text = currentModel.cor ?? '';
    formWasChanged = false;
  }

  @override
  Future<void> save() async {
    if (!formKey.currentState!.validate()) {
      showErrorSnackBar(message: 'validator_form_message'.tr);
      return;
    }

    final existingIndex = modelList.indexWhere((m) => m.id == currentModel.id);

    if (existingIndex >= 0) {
      modelList[existingIndex] = currentModel.clone();
    }

    final result = await repository.save(agendaCategoriaCompromissoModel: currentModel);
    if (result == null) return;

    if (existingIndex >= 0) {
      modelList[existingIndex] = result;
    } else {
      modelList.insert(0, result);
    }

    if (!GetPlatform.isMobile) {
      updateGridRow(result);
    }

    Get.back(result: true);
  }


  @override
  void onClose() {
    nomeController.dispose();
    corController.dispose();
    super.onClose();
  }

}