import 'package:flutter/material.dart';
import 'dart:math';
import 'package:get/get.dart';
import 'package:extended_masked_text/extended_masked_text.dart';
import 'package:agenda/app/page/shared_widget/input/input_imports.dart';

import 'package:agenda/app/infra/infra_imports.dart';
import 'package:agenda/app/page/page_imports.dart';
import 'package:agenda/app/page/shared_widget/message_dialog.dart';
import 'package:agenda/app/page/grid_columns/grid_columns_imports.dart';
import 'package:agenda/app/routes/app_routes.dart';
import 'package:agenda/app/controller/controller_imports.dart';
import 'package:agenda/app/data/model/model_imports.dart';
import 'package:agenda/app/data/repository/recado_remetente_repository.dart';

class RecadoRemetenteController extends ControllerBase<RecadoRemetenteModel, RecadoRemetenteRepository> 
with GetSingleTickerProviderStateMixin {

  RecadoRemetenteController({required super.repository}) {
    dbColumns = RecadoRemetenteModel.dbColumns;
    aliasColumns = RecadoRemetenteModel.aliasColumns;
    gridColumns = recadoRemetenteGridColumns();
    functionName = "recado_remetente";
    screenTitle = "Recado";
  }

  final recadoRemetenteScaffoldKey = GlobalKey<ScaffoldState>();
  final recadoRemetenteTabPageScaffoldKey = GlobalKey<ScaffoldState>();
  final recadoRemetenteFormKey = GlobalKey<FormState>();
  late TabController tabController;
  String? mandatoryMessage;  

  @override
  RecadoRemetenteModel createNewModel() => RecadoRemetenteModel();

  @override
  final standardFieldForFilter = RecadoRemetenteModel.aliasColumns[RecadoRemetenteModel.dbColumns.indexOf('data_envio')];

  final viewPessoaColaboradorModelController = TextEditingController();
  final dataEnvioController = DatePickerItemController(null);
  final horaEnvioController = MaskedTextController(mask: '00:00:00',);
  final assuntoController = TextEditingController();
  final textoController = TextEditingController();

  final Map<String, dynamic> mobileConfig = {
    'primaryColumns': ['data_envio'],
    'secondaryColumns': ['hora_envio'],
  };

  List<Map<String, dynamic>> get mobileItems {
    return modelList.map((recadoRemetente) => recadoRemetente.toJson).toList();
  }

  @override
  void prepareForInsert() {
    isNewRecord = true;
    currentModel = createNewModel();
    _resetForm();
    tabController.animateTo(0);
    updateControllersFromModel();
    Get.toNamed(Routes.recadoRemetenteTabPage);
  }

  void _resetForm() {
    formWasChanged = false;
    viewPessoaColaboradorModelController.text = '';
    dataEnvioController.date = null;
    horaEnvioController.text = '';
    assuntoController.text = '';
    textoController.text = '';
  }

  @override
  void selectRowForEditingById(int id) {
    final model = modelList.firstWhere((m) => m.id == id);
    currentModel = model.clone();
    updateControllersFromModel();
    tabController.animateTo(0);
    Get.toNamed(Routes.recadoRemetenteTabPage);
  }

  _configureChildrenControllers() {
    //Destinatarios
		Get.put<RecadoDestinatarioController>(RecadoDestinatarioController()); 

  }
	
	_releaseChildrenControllers() {
    //Destinatarios
		Get.delete<RecadoDestinatarioController>(); 

	}
  
  void updateControllersFromModel() {
    viewPessoaColaboradorModelController.text = currentModel.viewPessoaColaboradorModel?.nome?.toString() ?? '';
    dataEnvioController.date = currentModel.dataEnvio;
    horaEnvioController.text = currentModel.horaEnvio ?? '';
    assuntoController.text = currentModel.assunto ?? '';
    textoController.text = currentModel.texto ?? '';

    formWasChanged = false;
    _updateChildrenControllersFromModel();
  }

  void _updateChildrenControllersFromModel() {
    //Destinatarios
		final recadoDestinatarioController = Get.find<RecadoDestinatarioController>(); 
		recadoDestinatarioController.userMadeChanges = false; 

  }

  @override
  Future<void> save() async {
    if (!validateCurrentForm()) return;
    if (validateForms()) {
      if (userMadeChanges()) {
        final existingIndex = modelList.indexWhere((m) => m.id == currentModel.id);

        if (existingIndex >= 0) {
          modelList[existingIndex] = currentModel.clone();
        }

        final result = await repository.save(recadoRemetenteModel: currentModel);
        if (result == null) return;

        if (existingIndex >= 0) {
          modelList[existingIndex] = result;
        } else {
          modelList.insert(0, result);
        }

        if (!GetPlatform.isMobile) {
          updateGridRow(result);
        }

        Get.back(result: true);
      } else {
        Get.back();
      }
    } 
  }

  Future callViewPessoaColaboradorLookup() async { 
		final lookupController = Get.find<LookupController>(); 
		lookupController.refreshItems(standardValue: '%'); 
		lookupController.title = '${'lookup_page_title'.tr} [Remetente]'; 
		lookupController.route = '/view-pessoa-colaborador/'; 
		lookupController.gridColumns = viewPessoaColaboradorGridColumns(isForLookup: true); 
		lookupController.aliasColumns = ViewPessoaColaboradorModel.aliasColumns; 
		lookupController.dbColumns = ViewPessoaColaboradorModel.dbColumns; 
		lookupController.standardColumn = ViewPessoaColaboradorModel.aliasColumns[ViewPessoaColaboradorModel.dbColumns.indexOf('nome')]; 

		final plutoRowResult = await Get.toNamed(Routes.lookupPage); 
		if (plutoRowResult != null) { 
			currentModel.idColaborador = plutoRowResult.cells['id']!.value; 
			currentModel.viewPessoaColaboradorModel = ViewPessoaColaboradorModel.fromPlutoRow(plutoRowResult); 
			viewPessoaColaboradorModelController.text = currentModel.viewPessoaColaboradorModel?.nome ?? ''; 
			formWasChanged = true; 
		}
	}


  List<Tab> tabItems = [
    Tab( 
			icon: Icon(iconDataList[Random().nextInt(10)]), 
			text: 'Recado', 
		),
    Tab( 
			icon: Icon(iconDataList[Random().nextInt(10)]), 
			text: 'Destinatarios', 
		),
  ];

  List<Widget> tabPages() {
    return [
      RecadoRemetenteEditPage(),
      const RecadoDestinatarioListPage(),
    ];
  }

  @override
  void preventDataLoss() {
    if (userMadeChanges()) {
      showQuestionDialog('message_data_loss'.tr, () { 
        Get.back(); 
      });
    } else {
      Get.back();
    }
  }  

  bool userMadeChanges() {
    return
    formWasChanged 
    || 
		Get.find<RecadoDestinatarioController>().userMadeChanges
    ;
  }

  void tabChange(int index) {
    validateCurrentForm();
  }

  bool validateCurrentForm() {
    mandatoryMessage = ValidateFormField.validateMandatory(currentModel.viewPessoaColaboradorModel?.nome); 
		if (mandatoryMessage != null) { 
			tabController.animateTo(0); 
			showErrorSnackBar(message: '$mandatoryMessage [Remetente]'); 
			return false; 
		}
    return true;
  }

  bool validateForms() {
    return true;
  }

  @override
  void onInit() {
    super.onInit();
    tabController = TabController(vsync: this, length: tabItems.length);
    _configureChildrenControllers();
  }
	
  @override
  void onClose() {
    tabController.dispose();
    viewPessoaColaboradorModelController.dispose();
    dataEnvioController.dispose();
    horaEnvioController.dispose();
    assuntoController.dispose();
    textoController.dispose();
    _releaseChildrenControllers();
    super.onClose();
  }	
}