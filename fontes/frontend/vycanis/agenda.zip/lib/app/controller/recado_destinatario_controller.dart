import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:pluto_grid/pluto_grid.dart';
import 'package:agenda/app/routes/app_routes.dart';

import 'package:agenda/app/page/page_imports.dart';
import 'package:agenda/app/page/shared_widget/message_dialog.dart';
import 'package:agenda/app/page/grid_columns/grid_columns_imports.dart';
import 'package:agenda/app/controller/controller_imports.dart';
import 'package:agenda/app/data/model/model_imports.dart';

class RecadoDestinatarioController extends ControllerBase<RecadoDestinatarioModel, void> {

  RecadoDestinatarioController() : super(repository: null) {
    dbColumns = RecadoDestinatarioModel.dbColumns;
    aliasColumns = RecadoDestinatarioModel.aliasColumns;
    gridColumns = recadoDestinatarioGridColumns();
    functionName = "recado_destinatario";
    screenTitle = "Destinatarios";
  }

  final _recadoDestinatarioModel = RecadoDestinatarioModel().obs;
  RecadoDestinatarioModel get recadoDestinatarioModel => _recadoDestinatarioModel.value;
  set recadoDestinatarioModel(value) => _recadoDestinatarioModel.value = value ?? RecadoDestinatarioModel();

  List<RecadoDestinatarioModel> get recadoDestinatarioModelList => Get.find<RecadoRemetenteController>().currentModel.recadoDestinatarioModelList ?? [];

  final _userMadeChanges = false.obs;
  get userMadeChanges => _userMadeChanges.value;
  set userMadeChanges(value) => _userMadeChanges.value = value;

  final _formWasChangedDetail = false.obs;
  bool get formWasChangedDetail => _formWasChangedDetail.value;
  set formWasChangedDetail(value) => _formWasChangedDetail.value = value;

  late PlutoGridStateManager _plutoGridStateManager;
  @override
  PlutoGridStateManager get plutoGridStateManager => _plutoGridStateManager;
  @override
  set plutoGridStateManager(value) => _plutoGridStateManager = value;

  final recadoDestinatarioScaffoldKey = GlobalKey<ScaffoldState>();
  final recadoDestinatarioFormKey = GlobalKey<FormState>();

  @override
  RecadoDestinatarioModel createNewModel() => RecadoDestinatarioModel();

  @override
  final standardFieldForFilter = RecadoDestinatarioModel.aliasColumns[RecadoDestinatarioModel.dbColumns.indexOf('id')];

  final viewPessoaColaboradorModelController = TextEditingController();

  final Map<String, dynamic> mobileConfig = {
    'primaryColumns': [],
    'secondaryColumns': [],
  };

  List<Map<String, dynamic>> get mobileItems {
    return modelList.map((recadoDestinatario) => recadoDestinatario.toJson).toList();
  }

  @override
  List<PlutoRow> plutoRows() => List<PlutoRow>.from(recadoDestinatarioModelList.map((model) => model.toPlutoRow()));

  @override
  Future<void> getList({Filter? filter}) async {}

  @override
  void prepareForInsert() {
    isNewRecord = true;
    recadoDestinatarioModel = createNewModel();
    _resetForm();
    Get.to(() => RecadoDestinatarioEditPage());
  }

  void _resetForm() {
    formWasChangedDetail = false;
    viewPessoaColaboradorModelController.text = '';
  }

  @override
  void selectRowForEditing(PlutoRow? row) async {
    if (row == null) {
      showInfoSnackBar(message: 'message_select_one_to_edited'.tr);
      return;
    }

    selectRowForEditingByTempId(row.cells['tempId']?.value);
  }

  @override
  void selectRowForEditingById(int id) {}

  void selectRowForEditingByTempId(String tempId) {
		isNewRecord = false;
    final model = recadoDestinatarioModelList.firstWhere((m) => m.tempId == tempId);
    recadoDestinatarioModel = model.clone();
		recadoDestinatarioModel.tempId = model.tempId;
    updateControllersFromModel();
    Get.to(() => RecadoDestinatarioEditPage());
  }

  void updateControllersFromModel() {
    viewPessoaColaboradorModelController.text = recadoDestinatarioModel.viewPessoaColaboradorModel?.nome?.toString() ?? '';
    formWasChangedDetail = false;
  }

  @override
  Future<void> save() async {
    if (!recadoDestinatarioFormKey.currentState!.validate()) {
      showErrorSnackBar(message: 'validator_form_message'.tr);
      return;
    }

    if (formWasChangedDetail) {
      if (isNewRecord) {
        recadoDestinatarioModelList.insert(0, recadoDestinatarioModel.clone());
      } else {
        final index = recadoDestinatarioModelList.indexWhere((m) => m.tempId == recadoDestinatarioModel.tempId);
        if (index >= 0) {
          recadoDestinatarioModelList[index] = recadoDestinatarioModel.clone();
        }
      }

      userMadeChanges = true;
      loadData();
      Get.back(result: true);
    } else {
      Get.back();
    }
  }

  Future callViewPessoaColaboradorLookup() async { 
		final lookupController = Get.find<LookupController>(); 
		lookupController.refreshItems(standardValue: '%'); 
		lookupController.title = '${'lookup_page_title'.tr} [Destinatário]'; 
		lookupController.route = '/view-pessoa-colaborador/'; 
		lookupController.gridColumns = viewPessoaColaboradorGridColumns(isForLookup: true); 
		lookupController.aliasColumns = ViewPessoaColaboradorModel.aliasColumns; 
		lookupController.dbColumns = ViewPessoaColaboradorModel.dbColumns; 
		lookupController.standardColumn = ViewPessoaColaboradorModel.aliasColumns[ViewPessoaColaboradorModel.dbColumns.indexOf('nome')]; 

		final plutoRowResult = await Get.toNamed(Routes.lookupPage); 
		if (plutoRowResult != null) { 
			recadoDestinatarioModel.idColaborador = plutoRowResult.cells['id']!.value; 
			recadoDestinatarioModel.viewPessoaColaboradorModel = ViewPessoaColaboradorModel.fromPlutoRow(plutoRowResult); 
			viewPessoaColaboradorModelController.text = recadoDestinatarioModel.viewPessoaColaboradorModel?.nome ?? ''; 
			formWasChangedDetail = true; 
		}
	}


  @override
  Future deleteSelected() async {
    final currentRow = plutoGridStateManager.currentRow;
    if (currentRow == null) {
      showInfoSnackBar(message: 'message_select_one_to_delete'.tr);
      return null;
    }
    showDeleteDialog(() async {
      final id = currentRow.cells['id']?.value;
      final tempId = currentRow.cells['tempId']?.value;
      recadoDestinatarioModelList.removeWhere((model) => (id != 0 && model.id == id) || (id == 0 && model.tempId == tempId));
      plutoGridStateManager.removeCurrentRow();
      userMadeChanges = true;
    });
  }

  @override
  void preventDataLoss() {
    if (formWasChangedDetail) {
      showQuestionDialog('message_data_loss'.tr, () => Get.back());
    } else {
      formWasChangedDetail = false;
      Get.back();
    }
  }

  @override
  void onClose() {
    viewPessoaColaboradorModelController.dispose();
  }

}