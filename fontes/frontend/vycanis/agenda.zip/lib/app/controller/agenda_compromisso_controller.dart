import 'package:agenda/app/data/datasource/agenda_datasource.dart';
import 'package:flutter/material.dart';
import 'dart:math';
import 'package:get/get.dart';
import 'package:extended_masked_text/extended_masked_text.dart';
import 'package:agenda/app/page/shared_widget/input/input_imports.dart';

import 'package:agenda/app/infra/infra_imports.dart';
import 'package:agenda/app/page/page_imports.dart';
import 'package:agenda/app/page/shared_widget/message_dialog.dart';
import 'package:agenda/app/page/grid_columns/grid_columns_imports.dart';
import 'package:agenda/app/routes/app_routes.dart';
import 'package:agenda/app/controller/controller_imports.dart';
import 'package:agenda/app/data/model/model_imports.dart';
import 'package:agenda/app/data/repository/agenda_compromisso_repository.dart';

class AgendaCompromissoController extends ControllerBase<AgendaCompromissoModel, AgendaCompromissoRepository> 
with GetSingleTickerProviderStateMixin {

  AgendaCompromissoController({required super.repository}) {
    dbColumns = AgendaCompromissoModel.dbColumns;
    aliasColumns = AgendaCompromissoModel.aliasColumns;
    gridColumns = agendaCompromissoGridColumns();
    functionName = "agenda_compromisso";
    screenTitle = "Compromissos";
  }

  AgendaDataSource get calendarDataSource {
    return AgendaDataSource(modelList);
  }

  final agendaCompromissoScaffoldKey = GlobalKey<ScaffoldState>();
  final agendaCompromissoTabPageScaffoldKey = GlobalKey<ScaffoldState>();
  final agendaCompromissoFormKey = GlobalKey<FormState>();
  late TabController tabController;
  String? mandatoryMessage;  

  @override
  AgendaCompromissoModel createNewModel() => AgendaCompromissoModel();

  @override
  final standardFieldForFilter = AgendaCompromissoModel.aliasColumns[AgendaCompromissoModel.dbColumns.indexOf('data_compromisso')];

  final agendaCategoriaCompromissoModelController = TextEditingController();
  final viewPessoaColaboradorModelController = TextEditingController();
  final dataCompromissoController = DatePickerItemController(null);
  final horaController = TextEditingController();
  final duracaoController = MoneyMaskedTextController(precision: 0, decimalSeparator: '', thousandSeparator: '');
  final tipoController = CustomDropdownButtonController('Pessoal');
  final ondeController = TextEditingController();
  final descricaoController = TextEditingController();

  final Map<String, dynamic> mobileConfig = {
    'primaryColumns': ['data_compromisso'],
    'secondaryColumns': ['hora'],
  };

  List<Map<String, dynamic>> get mobileItems {
    return modelList.map((agendaCompromisso) => agendaCompromisso.toJson).toList();
  }

  @override
  void prepareForInsert() {
    isNewRecord = true;
    currentModel = createNewModel();
    _resetForm();
    tabController.animateTo(0);
    updateControllersFromModel();
    Get.toNamed(Routes.agendaCompromissoTabPage);
  }

  void _resetForm() {
    formWasChanged = false;
    agendaCategoriaCompromissoModelController.text = '';
    viewPessoaColaboradorModelController.text = '';
    dataCompromissoController.date = null;
    horaController.text = '';
    duracaoController.updateValue(0);
    tipoController.selected = 'Pessoal';
    ondeController.text = '';
    descricaoController.text = '';
  }

  @override
  void selectRowForEditingById(int id) {
    final model = modelList.firstWhere((m) => m.id == id);
    currentModel = model.clone();
    updateControllersFromModel();
    tabController.animateTo(0);
    Get.toNamed(Routes.agendaCompromissoTabPage);
  }

  _configureChildrenControllers() {
    //Notificações
		Get.put<AgendaNotificacaoController>(AgendaNotificacaoController()); 

    //Convidados
		Get.put<AgendaCompromissoConvidadoController>(AgendaCompromissoConvidadoController()); 

    //Eventos
		Get.put<ReuniaoSalaEventoController>(ReuniaoSalaEventoController()); 

  }
	
	_releaseChildrenControllers() {
    //Notificações
		Get.delete<AgendaNotificacaoController>(); 

    //Convidados
		Get.delete<AgendaCompromissoConvidadoController>(); 

    //Eventos
		Get.delete<ReuniaoSalaEventoController>(); 

	}
  
  void updateControllersFromModel() {
    agendaCategoriaCompromissoModelController.text = currentModel.agendaCategoriaCompromissoModel?.nome?.toString() ?? '';
    viewPessoaColaboradorModelController.text = currentModel.viewPessoaColaboradorModel?.nome?.toString() ?? '';
    dataCompromissoController.date = currentModel.dataCompromisso;
    horaController.text = currentModel.hora ?? '';
    duracaoController.updateValue((currentModel.duracao ?? 0).toDouble());
    tipoController.selected = currentModel.tipo ?? 'Pessoal';
    ondeController.text = currentModel.onde ?? '';
    descricaoController.text = currentModel.descricao ?? '';

    formWasChanged = false;
    _updateChildrenControllersFromModel();
  }

  void _updateChildrenControllersFromModel() {
    //Notificações
		final agendaNotificacaoController = Get.find<AgendaNotificacaoController>(); 
		agendaNotificacaoController.userMadeChanges = false; 

    //Convidados
		final agendaCompromissoConvidadoController = Get.find<AgendaCompromissoConvidadoController>(); 
		agendaCompromissoConvidadoController.userMadeChanges = false; 

    //Eventos
		final reuniaoSalaEventoController = Get.find<ReuniaoSalaEventoController>(); 
		reuniaoSalaEventoController.userMadeChanges = false; 

  }

  @override
  Future<void> save() async {
    if (!validateCurrentForm()) return;
    if (validateForms()) {
      if (userMadeChanges()) {
        final existingIndex = modelList.indexWhere((m) => m.id == currentModel.id);

        if (existingIndex >= 0) {
          modelList[existingIndex] = currentModel.clone();
        }

        final result = await repository.save(agendaCompromissoModel: currentModel);
        if (result == null) return;

        if (existingIndex >= 0) {
          modelList[existingIndex] = result;
        } else {
          modelList.insert(0, result);
        }

        if (!GetPlatform.isMobile) {
          updateGridRow(result);
        }

        Get.back(result: true);
      } else {
        Get.back();
      }
    } 
  }

  Future callAgendaCategoriaCompromissoLookup() async { 
		final lookupController = Get.find<LookupController>(); 
		lookupController.refreshItems(standardValue: '%'); 
		lookupController.title = '${'lookup_page_title'.tr} [Categoria]'; 
		lookupController.route = '/agenda-categoria-compromisso/'; 
		lookupController.gridColumns = agendaCategoriaCompromissoGridColumns(isForLookup: true); 
		lookupController.aliasColumns = AgendaCategoriaCompromissoModel.aliasColumns; 
		lookupController.dbColumns = AgendaCategoriaCompromissoModel.dbColumns; 
		lookupController.standardColumn = AgendaCategoriaCompromissoModel.aliasColumns[AgendaCategoriaCompromissoModel.dbColumns.indexOf('nome')]; 

		final plutoRowResult = await Get.toNamed(Routes.lookupPage); 
		if (plutoRowResult != null) { 
			currentModel.idAgendaCategoriaCompromisso = plutoRowResult.cells['id']!.value; 
			currentModel.agendaCategoriaCompromissoModel = AgendaCategoriaCompromissoModel.fromPlutoRow(plutoRowResult); 
			agendaCategoriaCompromissoModelController.text = currentModel.agendaCategoriaCompromissoModel?.nome ?? ''; 
			formWasChanged = true; 
		}
	}

  Future callViewPessoaColaboradorLookup() async { 
		final lookupController = Get.find<LookupController>(); 
		lookupController.refreshItems(standardValue: '%'); 
		lookupController.title = '${'lookup_page_title'.tr} [Colaborador]'; 
		lookupController.route = '/view-pessoa-colaborador/'; 
		lookupController.gridColumns = viewPessoaColaboradorGridColumns(isForLookup: true); 
		lookupController.aliasColumns = ViewPessoaColaboradorModel.aliasColumns; 
		lookupController.dbColumns = ViewPessoaColaboradorModel.dbColumns; 
		lookupController.standardColumn = ViewPessoaColaboradorModel.aliasColumns[ViewPessoaColaboradorModel.dbColumns.indexOf('nome')]; 

		final plutoRowResult = await Get.toNamed(Routes.lookupPage); 
		if (plutoRowResult != null) { 
			currentModel.idColaborador = plutoRowResult.cells['id']!.value; 
			currentModel.viewPessoaColaboradorModel = ViewPessoaColaboradorModel.fromPlutoRow(plutoRowResult); 
			viewPessoaColaboradorModelController.text = currentModel.viewPessoaColaboradorModel?.nome ?? ''; 
			formWasChanged = true; 
		}
	}


  List<Tab> tabItems = [
    Tab( 
			icon: Icon(iconDataList[Random().nextInt(10)]), 
			text: 'Compromissos', 
		),
    Tab( 
			icon: Icon(iconDataList[Random().nextInt(10)]), 
			text: 'Notificações', 
		),
    Tab( 
			icon: Icon(iconDataList[Random().nextInt(10)]), 
			text: 'Convidados', 
		),
    Tab( 
			icon: Icon(iconDataList[Random().nextInt(10)]), 
			text: 'Eventos', 
		),
  ];

  List<Widget> tabPages() {
    return [
      AgendaCompromissoEditPage(),
      const AgendaNotificacaoListPage(),
      const AgendaCompromissoConvidadoListPage(),
      const ReuniaoSalaEventoListPage(),
    ];
  }

  @override
  void preventDataLoss() {
    if (userMadeChanges()) {
      showQuestionDialog('message_data_loss'.tr, () { 
        Get.back(); 
      });
    } else {
      Get.back();
    }
  }  

  bool userMadeChanges() {
    return
    formWasChanged 
    || 
		Get.find<AgendaNotificacaoController>().userMadeChanges
    || 
		Get.find<AgendaCompromissoConvidadoController>().userMadeChanges
    || 
		Get.find<ReuniaoSalaEventoController>().userMadeChanges
    ;
  }

  void tabChange(int index) {
    validateCurrentForm();
  }

  bool validateCurrentForm() {
    mandatoryMessage = ValidateFormField.validateMandatory(currentModel.agendaCategoriaCompromissoModel?.nome); 
		if (mandatoryMessage != null) { 
			tabController.animateTo(0); 
			showErrorSnackBar(message: '$mandatoryMessage [Categoria]'); 
			return false; 
		}
    mandatoryMessage = ValidateFormField.validateMandatory(currentModel.viewPessoaColaboradorModel?.nome); 
		if (mandatoryMessage != null) { 
			tabController.animateTo(0); 
			showErrorSnackBar(message: '$mandatoryMessage [Colaborador]'); 
			return false; 
		}
    return true;
  }

  bool validateForms() {
    return true;
  }

  void openCalendarForCurrentList() {
    Get.to(() => const AgendaCompromissoCalendarPage());
  }

  @override
  void onInit() {
    super.onInit();
    tabController = TabController(vsync: this, length: tabItems.length);
    _configureChildrenControllers();
  }
	
  @override
  void onClose() {
    tabController.dispose();
    agendaCategoriaCompromissoModelController.dispose();
    viewPessoaColaboradorModelController.dispose();
    dataCompromissoController.dispose();
    horaController.dispose();
    duracaoController.dispose();
    tipoController.dispose();
    ondeController.dispose();
    descricaoController.dispose();
    _releaseChildrenControllers();
    super.onClose();
  }	
}