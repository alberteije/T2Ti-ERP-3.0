abstract class Routes{
	
	static const splashPage = '/splashPage';
	static const loginPage = '/loginPage';
	static const homePage = '/homePage';
	static const filterPage = '/filterPage';
	static const lookupPage = '/lookupPage';
  static const menuModulesPage = '/menuModulesPage';
		
	static const agendaCompromissoListPage = '/agendaCompromissoListPage'; 
	static const agendaCompromissoTabPage = '/agendaCompromissoTabPage';
	static const recadoRemetenteListPage = '/recadoRemetenteListPage'; 
	static const recadoRemetenteTabPage = '/recadoRemetenteTabPage';
	static const agendaCategoriaCompromissoListPage = '/agendaCategoriaCompromissoListPage'; 
	static const agendaCategoriaCompromissoEditPage = '/agendaCategoriaCompromissoEditPage';
	static const reuniaoSalaListPage = '/reuniaoSalaListPage'; 
	static const reuniaoSalaEditPage = '/reuniaoSalaEditPage';
}