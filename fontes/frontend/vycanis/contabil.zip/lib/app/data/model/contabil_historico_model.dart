import 'dart:convert';
import 'package:pluto_grid/pluto_grid.dart';
import 'package:contabil/app/data/model/model_imports.dart';

import 'package:contabil/app/data/domain/domain_imports.dart';

class ContabilHistoricoModel extends ModelBase {
  int? id;
  String? descricao;
  String? pedeComplemento;
  String? historico;

  ContabilHistoricoModel({
    this.id,
    this.descricao,
    this.pedeComplemento = 'Sim',
    this.historico,
  });

  static List<String> dbColumns = <String>[
    'id',
    'descricao',
    'pede_complemento',
    'historico',
  ];

  static List<String> aliasColumns = <String>[
    'Id',
    'Descricao',
    'Pede Complemento',
    'Historico',
  ];

  ContabilHistoricoModel.fromJson(Map<String, dynamic> jsonData) {
    id = jsonData['id'];
    descricao = jsonData['descricao'];
    pedeComplemento = ContabilHistoricoDomain.getPedeComplemento(jsonData['pedeComplemento']);
    historico = jsonData['historico'];
  }

  Map<String, dynamic> get toJson {
    Map<String, dynamic> jsonData = <String, dynamic>{};

    jsonData['id'] = id != 0 ? id : null;
    jsonData['descricao'] = descricao;
    jsonData['pedeComplemento'] = ContabilHistoricoDomain.setPedeComplemento(pedeComplemento);
    jsonData['historico'] = historico;

    return jsonData;
  }

  String objectEncodeJson() {
    final jsonData = toJson;
    return json.encode(jsonData);
  }

  static ContabilHistoricoModel fromPlutoRow(PlutoRow row) {
    return ContabilHistoricoModel(
      id: row.cells['id']?.value,
      descricao: row.cells['descricao']?.value,
      pedeComplemento: row.cells['pedeComplemento']?.value,
      historico: row.cells['historico']?.value,
    );
  }

  PlutoRow toPlutoRow() {
    return PlutoRow(
      cells: {
        'tempId': PlutoCell(value: tempId),
        'id': PlutoCell(value: id ?? 0),
        'descricao': PlutoCell(value: descricao ?? ''),
        'pedeComplemento': PlutoCell(value: pedeComplemento ?? ''),
        'historico': PlutoCell(value: historico ?? ''),
      },
    );
  }

  ContabilHistoricoModel clone() {
    return ContabilHistoricoModel(
      id: id,
      descricao: descricao,
      pedeComplemento: pedeComplemento,
      historico: historico,
    );
  }


}