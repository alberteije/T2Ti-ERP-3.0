import 'dart:convert';
import 'package:pluto_grid/pluto_grid.dart';
import 'package:contabil/app/data/model/model_imports.dart';

import 'package:contabil/app/infra/infra_imports.dart';
import 'package:intl/intl.dart';

class FapModel extends ModelBase {
  int? id;
  double? fap;
  DateTime? dataInicial;
  DateTime? dataFinal;

  FapModel({
    this.id,
    this.fap,
    this.dataInicial,
    this.dataFinal,
  });

  static List<String> dbColumns = <String>[
    'id',
    'fap',
    'data_inicial',
    'data_final',
  ];

  static List<String> aliasColumns = <String>[
    'Id',
    'Fap',
    'Data Inicial',
    'Data Final',
  ];

  FapModel.fromJson(Map<String, dynamic> jsonData) {
    id = jsonData['id'];
    fap = jsonData['fap']?.toDouble();
    dataInicial = jsonData['dataInicial'] != null ? DateTime.tryParse(jsonData['dataInicial']) : null;
    dataFinal = jsonData['dataFinal'] != null ? DateTime.tryParse(jsonData['dataFinal']) : null;
  }

  Map<String, dynamic> get toJson {
    Map<String, dynamic> jsonData = <String, dynamic>{};

    jsonData['id'] = id != 0 ? id : null;
    jsonData['fap'] = fap;
    jsonData['dataInicial'] = dataInicial != null ? DateFormat('yyyy-MM-ddT00:00:00').format(dataInicial!) : null;
    jsonData['dataFinal'] = dataFinal != null ? DateFormat('yyyy-MM-ddT00:00:00').format(dataFinal!) : null;

    return jsonData;
  }

  String objectEncodeJson() {
    final jsonData = toJson;
    return json.encode(jsonData);
  }

  static FapModel fromPlutoRow(PlutoRow row) {
    return FapModel(
      id: row.cells['id']?.value,
      fap: row.cells['fap']?.value,
      dataInicial: Util.stringToDate(row.cells['dataInicial']?.value),
      dataFinal: Util.stringToDate(row.cells['dataFinal']?.value),
    );
  }

  PlutoRow toPlutoRow() {
    return PlutoRow(
      cells: {
        'tempId': PlutoCell(value: tempId),
        'id': PlutoCell(value: id ?? 0),
        'fap': PlutoCell(value: fap ?? 0.0),
        'dataInicial': PlutoCell(value: dataInicial),
        'dataFinal': PlutoCell(value: dataFinal),
      },
    );
  }

  FapModel clone() {
    return FapModel(
      id: id,
      fap: fap,
      dataInicial: dataInicial,
      dataFinal: dataFinal,
    );
  }


}