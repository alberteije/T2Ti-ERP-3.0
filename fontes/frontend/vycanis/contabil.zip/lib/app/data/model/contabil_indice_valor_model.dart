import 'dart:convert';
import 'package:pluto_grid/pluto_grid.dart';
import 'package:contabil/app/data/model/model_imports.dart';

import 'package:contabil/app/infra/infra_imports.dart';
import 'package:intl/intl.dart';

class ContabilIndiceValorModel extends ModelBase {
  int? id;
  int? idContabilIndice;
  DateTime? dataIndice;
  double? valor;

  ContabilIndiceValorModel({
    this.id,
    this.idContabilIndice,
    this.dataIndice,
    this.valor,
  });

  static List<String> dbColumns = <String>[
    'id',
    'data_indice',
    'valor',
  ];

  static List<String> aliasColumns = <String>[
    'Id',
    'Data Indice',
    'Valor',
  ];

  ContabilIndiceValorModel.fromJson(Map<String, dynamic> jsonData) {
    id = jsonData['id'];
    idContabilIndice = jsonData['idContabilIndice'];
    dataIndice = jsonData['dataIndice'] != null ? DateTime.tryParse(jsonData['dataIndice']) : null;
    valor = jsonData['valor']?.toDouble();
  }

  Map<String, dynamic> get toJson {
    Map<String, dynamic> jsonData = <String, dynamic>{};

    jsonData['id'] = id != 0 ? id : null;
    jsonData['idContabilIndice'] = idContabilIndice != 0 ? idContabilIndice : null;
    jsonData['dataIndice'] = dataIndice != null ? DateFormat('yyyy-MM-ddT00:00:00').format(dataIndice!) : null;
    jsonData['valor'] = valor;

    return jsonData;
  }

  String objectEncodeJson() {
    final jsonData = toJson;
    return json.encode(jsonData);
  }

  static ContabilIndiceValorModel fromPlutoRow(PlutoRow row) {
    return ContabilIndiceValorModel(
      id: row.cells['id']?.value,
      idContabilIndice: row.cells['idContabilIndice']?.value,
      dataIndice: Util.stringToDate(row.cells['dataIndice']?.value),
      valor: row.cells['valor']?.value,
    );
  }

  PlutoRow toPlutoRow() {
    return PlutoRow(
      cells: {
        'tempId': PlutoCell(value: tempId),
        'id': PlutoCell(value: id ?? 0),
        'idContabilIndice': PlutoCell(value: idContabilIndice ?? 0),
        'dataIndice': PlutoCell(value: dataIndice),
        'valor': PlutoCell(value: valor ?? 0.0),
      },
    );
  }

  ContabilIndiceValorModel clone() {
    return ContabilIndiceValorModel(
      id: id,
      idContabilIndice: idContabilIndice,
      dataIndice: dataIndice,
      valor: valor,
    );
  }


}