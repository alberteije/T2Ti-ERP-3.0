import 'dart:convert';
import 'package:pluto_grid/pluto_grid.dart';
import 'package:contabil/app/data/model/model_imports.dart';

import 'package:contabil/app/data/domain/domain_imports.dart';

class ContabilLancamentoDetalheModel extends ModelBase {
  int? id;
  int? idContabilLancamentoCab;
  int? idContabilConta;
  int? idContabilHistorico;
  String? tipo;
  double? valor;
  String? historico;
  ContabilHistoricoModel? contabilHistoricoModel;
  ContabilContaModel? contabilContaModel;

  ContabilLancamentoDetalheModel({
    this.id,
    this.idContabilLancamentoCab,
    this.idContabilConta,
    this.idContabilHistorico,
    this.tipo = 'Débito',
    this.valor,
    this.historico,
    ContabilHistoricoModel? contabilHistoricoModel,
    ContabilContaModel? contabilContaModel,
  }) {
    this.contabilHistoricoModel = contabilHistoricoModel ?? ContabilHistoricoModel();
    this.contabilContaModel = contabilContaModel ?? ContabilContaModel();
  }

  static List<String> dbColumns = <String>[
    'id',
    'tipo',
    'valor',
    'historico',
  ];

  static List<String> aliasColumns = <String>[
    'Id',
    'Tipo',
    'Valor',
    'Historico',
  ];

  ContabilLancamentoDetalheModel.fromJson(Map<String, dynamic> jsonData) {
    id = jsonData['id'];
    idContabilLancamentoCab = jsonData['idContabilLancamentoCab'];
    idContabilConta = jsonData['idContabilConta'];
    idContabilHistorico = jsonData['idContabilHistorico'];
    tipo = ContabilLancamentoDetalheDomain.getTipo(jsonData['tipo']);
    valor = jsonData['valor']?.toDouble();
    historico = jsonData['historico'];
    contabilHistoricoModel = jsonData['contabilHistoricoModel'] == null ? ContabilHistoricoModel() : ContabilHistoricoModel.fromJson(jsonData['contabilHistoricoModel']);
    contabilContaModel = jsonData['contabilContaModel'] == null ? ContabilContaModel() : ContabilContaModel.fromJson(jsonData['contabilContaModel']);
  }

  Map<String, dynamic> get toJson {
    Map<String, dynamic> jsonData = <String, dynamic>{};

    jsonData['id'] = id != 0 ? id : null;
    jsonData['idContabilLancamentoCab'] = idContabilLancamentoCab != 0 ? idContabilLancamentoCab : null;
    jsonData['idContabilConta'] = idContabilConta != 0 ? idContabilConta : null;
    jsonData['idContabilHistorico'] = idContabilHistorico != 0 ? idContabilHistorico : null;
    jsonData['tipo'] = ContabilLancamentoDetalheDomain.setTipo(tipo);
    jsonData['valor'] = valor;
    jsonData['historico'] = historico;
    jsonData['contabilHistoricoModel'] = contabilHistoricoModel?.toJson;
    jsonData['contabilHistorico'] = contabilHistoricoModel?.descricao ?? '';
    jsonData['contabilContaModel'] = contabilContaModel?.toJson;
    jsonData['contabilConta'] = contabilContaModel?.descricao ?? '';

    return jsonData;
  }

  String objectEncodeJson() {
    final jsonData = toJson;
    return json.encode(jsonData);
  }

  static ContabilLancamentoDetalheModel fromPlutoRow(PlutoRow row) {
    return ContabilLancamentoDetalheModel(
      id: row.cells['id']?.value,
      idContabilLancamentoCab: row.cells['idContabilLancamentoCab']?.value,
      idContabilConta: row.cells['idContabilConta']?.value,
      idContabilHistorico: row.cells['idContabilHistorico']?.value,
      tipo: row.cells['tipo']?.value,
      valor: row.cells['valor']?.value,
      historico: row.cells['historico']?.value,
    );
  }

  PlutoRow toPlutoRow() {
    return PlutoRow(
      cells: {
        'tempId': PlutoCell(value: tempId),
        'id': PlutoCell(value: id ?? 0),
        'idContabilLancamentoCab': PlutoCell(value: idContabilLancamentoCab ?? 0),
        'idContabilConta': PlutoCell(value: idContabilConta ?? 0),
        'idContabilHistorico': PlutoCell(value: idContabilHistorico ?? 0),
        'tipo': PlutoCell(value: tipo ?? ''),
        'valor': PlutoCell(value: valor ?? 0.0),
        'historico': PlutoCell(value: historico ?? ''),
        'contabilHistorico': PlutoCell(value: contabilHistoricoModel?.descricao ?? ''),
        'contabilConta': PlutoCell(value: contabilContaModel?.descricao ?? ''),
      },
    );
  }

  ContabilLancamentoDetalheModel clone() {
    return ContabilLancamentoDetalheModel(
      id: id,
      idContabilLancamentoCab: idContabilLancamentoCab,
      idContabilConta: idContabilConta,
      idContabilHistorico: idContabilHistorico,
      tipo: tipo,
      valor: valor,
      historico: historico,
      contabilHistoricoModel: contabilHistoricoModel?.clone(),
      contabilContaModel: contabilContaModel?.clone(),
    );
  }


}