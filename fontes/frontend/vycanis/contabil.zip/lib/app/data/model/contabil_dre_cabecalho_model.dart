import 'dart:convert';
import 'package:pluto_grid/pluto_grid.dart';
import 'package:contabil/app/data/model/model_imports.dart';

import 'package:contabil/app/infra/infra_imports.dart';
import 'package:contabil/app/data/domain/domain_imports.dart';

class ContabilDreCabecalhoModel extends ModelBase {
  int? id;
  String? descricao;
  String? padrao;
  String? periodoInicial;
  String? periodoFinal;
  List<ContabilDreDetalheModel>? contabilDreDetalheModelList;

  ContabilDreCabecalhoModel({
    this.id,
    this.descricao,
    this.padrao = 'Sim',
    this.periodoInicial,
    this.periodoFinal,
    List<ContabilDreDetalheModel>? contabilDreDetalheModelList,
  }) {
    this.contabilDreDetalheModelList = contabilDreDetalheModelList?.toList(growable: true) ?? [];
  }

  static List<String> dbColumns = <String>[
    'id',
    'descricao',
    'padrao',
    'periodo_inicial',
    'periodo_final',
  ];

  static List<String> aliasColumns = <String>[
    'Id',
    'Descricao',
    'Padrao',
    'Periodo Inicial',
    'Periodo Final',
  ];

  ContabilDreCabecalhoModel.fromJson(Map<String, dynamic> jsonData) {
    id = jsonData['id'];
    descricao = jsonData['descricao'];
    padrao = ContabilDreCabecalhoDomain.getPadrao(jsonData['padrao']);
    periodoInicial = jsonData['periodoInicial'];
    periodoFinal = jsonData['periodoFinal'];
    contabilDreDetalheModelList = (jsonData['contabilDreDetalheModelList'] as Iterable?)?.map((m) => ContabilDreDetalheModel.fromJson(m)).toList() ?? [];
  }

  Map<String, dynamic> get toJson {
    Map<String, dynamic> jsonData = <String, dynamic>{};

    jsonData['id'] = id != 0 ? id : null;
    jsonData['descricao'] = descricao;
    jsonData['padrao'] = ContabilDreCabecalhoDomain.setPadrao(padrao);
    jsonData['periodoInicial'] = Util.removeMask(periodoInicial);
    jsonData['periodoFinal'] = Util.removeMask(periodoFinal);
    
		var contabilDreDetalheModelLocalList = []; 
		for (ContabilDreDetalheModel object in contabilDreDetalheModelList ?? []) { 
			contabilDreDetalheModelLocalList.add(object.toJson); 
		}
		jsonData['contabilDreDetalheModelList'] = contabilDreDetalheModelLocalList;

    return jsonData;
  }

  String objectEncodeJson() {
    final jsonData = toJson;
    return json.encode(jsonData);
  }

  static ContabilDreCabecalhoModel fromPlutoRow(PlutoRow row) {
    return ContabilDreCabecalhoModel(
      id: row.cells['id']?.value,
      descricao: row.cells['descricao']?.value,
      padrao: row.cells['padrao']?.value,
      periodoInicial: row.cells['periodoInicial']?.value,
      periodoFinal: row.cells['periodoFinal']?.value,
    );
  }

  PlutoRow toPlutoRow() {
    return PlutoRow(
      cells: {
        'tempId': PlutoCell(value: tempId),
        'id': PlutoCell(value: id ?? 0),
        'descricao': PlutoCell(value: descricao ?? ''),
        'padrao': PlutoCell(value: padrao ?? ''),
        'periodoInicial': PlutoCell(value: periodoInicial ?? ''),
        'periodoFinal': PlutoCell(value: periodoFinal ?? ''),
      },
    );
  }

  ContabilDreCabecalhoModel clone() {
    return ContabilDreCabecalhoModel(
      id: id,
      descricao: descricao,
      padrao: padrao,
      periodoInicial: periodoInicial,
      periodoFinal: periodoFinal,
      contabilDreDetalheModelList: contabilDreDetalheModelListClone(contabilDreDetalheModelList!),
    );
  }

  contabilDreDetalheModelListClone(List<ContabilDreDetalheModel> contabilDreDetalheModelList) { 
		List<ContabilDreDetalheModel> resultList = [];
		for (var contabilDreDetalheModel in contabilDreDetalheModelList) {
			resultList.add(contabilDreDetalheModel.clone());
		}
		return resultList;
	}


}