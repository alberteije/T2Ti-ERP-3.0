import 'dart:convert';
import 'package:pluto_grid/pluto_grid.dart';
import 'package:contabil/app/data/model/model_imports.dart';


class RateioCentroResultadoDetModel extends ModelBase {
  int? id;
  int? idRateioCentroResulCab;
  int? idCentroResultadoDestino;
  double? porcentoRateio;
  CentroResultadoModel? centroResultadoModel;

  RateioCentroResultadoDetModel({
    this.id,
    this.idRateioCentroResulCab,
    this.idCentroResultadoDestino,
    this.porcentoRateio,
    CentroResultadoModel? centroResultadoModel,
  }) {
    this.centroResultadoModel = centroResultadoModel ?? CentroResultadoModel();
  }

  static List<String> dbColumns = <String>[
    'id',
    'porcento_rateio',
  ];

  static List<String> aliasColumns = <String>[
    'Id',
    'Porcento Rateio',
  ];

  RateioCentroResultadoDetModel.fromJson(Map<String, dynamic> jsonData) {
    id = jsonData['id'];
    idRateioCentroResulCab = jsonData['idRateioCentroResulCab'];
    idCentroResultadoDestino = jsonData['idCentroResultadoDestino'];
    porcentoRateio = jsonData['porcentoRateio']?.toDouble();
    centroResultadoModel = jsonData['centroResultadoModel'] == null ? CentroResultadoModel() : CentroResultadoModel.fromJson(jsonData['centroResultadoModel']);
  }

  Map<String, dynamic> get toJson {
    Map<String, dynamic> jsonData = <String, dynamic>{};

    jsonData['id'] = id != 0 ? id : null;
    jsonData['idRateioCentroResulCab'] = idRateioCentroResulCab != 0 ? idRateioCentroResulCab : null;
    jsonData['idCentroResultadoDestino'] = idCentroResultadoDestino != 0 ? idCentroResultadoDestino : null;
    jsonData['porcentoRateio'] = porcentoRateio;
    jsonData['centroResultadoModel'] = centroResultadoModel?.toJson;
    jsonData['centroResultado'] = centroResultadoModel?.descricao ?? '';

    return jsonData;
  }

  String objectEncodeJson() {
    final jsonData = toJson;
    return json.encode(jsonData);
  }

  static RateioCentroResultadoDetModel fromPlutoRow(PlutoRow row) {
    return RateioCentroResultadoDetModel(
      id: row.cells['id']?.value,
      idRateioCentroResulCab: row.cells['idRateioCentroResulCab']?.value,
      idCentroResultadoDestino: row.cells['idCentroResultadoDestino']?.value,
      porcentoRateio: row.cells['porcentoRateio']?.value,
    );
  }

  PlutoRow toPlutoRow() {
    return PlutoRow(
      cells: {
        'tempId': PlutoCell(value: tempId),
        'id': PlutoCell(value: id ?? 0),
        'idRateioCentroResulCab': PlutoCell(value: idRateioCentroResulCab ?? 0),
        'idCentroResultadoDestino': PlutoCell(value: idCentroResultadoDestino ?? 0),
        'porcentoRateio': PlutoCell(value: porcentoRateio ?? 0.0),
        'centroResultado': PlutoCell(value: centroResultadoModel?.descricao ?? ''),
      },
    );
  }

  RateioCentroResultadoDetModel clone() {
    return RateioCentroResultadoDetModel(
      id: id,
      idRateioCentroResulCab: idRateioCentroResulCab,
      idCentroResultadoDestino: idCentroResultadoDestino,
      porcentoRateio: porcentoRateio,
      centroResultadoModel: centroResultadoModel?.clone(),
    );
  }


}