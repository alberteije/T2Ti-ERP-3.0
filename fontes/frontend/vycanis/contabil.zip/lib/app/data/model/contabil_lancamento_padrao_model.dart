import 'dart:convert';
import 'package:pluto_grid/pluto_grid.dart';
import 'package:contabil/app/data/model/model_imports.dart';


class ContabilLancamentoPadraoModel extends ModelBase {
  int? id;
  String? descricao;
  String? historico;
  int? idContaDebito;
  int? idContaCredito;

  ContabilLancamentoPadraoModel({
    this.id,
    this.descricao,
    this.historico,
    this.idContaDebito,
    this.idContaCredito,
  });

  static List<String> dbColumns = <String>[
    'id',
    'descricao',
    'historico',
    'id_conta_debito',
    'id_conta_credito',
  ];

  static List<String> aliasColumns = <String>[
    'Id',
    'Descricao',
    'Historico',
    'Id Conta Debito',
    'Id Conta Credito',
  ];

  ContabilLancamentoPadraoModel.fromJson(Map<String, dynamic> jsonData) {
    id = jsonData['id'];
    descricao = jsonData['descricao'];
    historico = jsonData['historico'];
    idContaDebito = jsonData['idContaDebito'];
    idContaCredito = jsonData['idContaCredito'];
  }

  Map<String, dynamic> get toJson {
    Map<String, dynamic> jsonData = <String, dynamic>{};

    jsonData['id'] = id != 0 ? id : null;
    jsonData['descricao'] = descricao;
    jsonData['historico'] = historico;
    jsonData['idContaDebito'] = idContaDebito;
    jsonData['idContaCredito'] = idContaCredito;

    return jsonData;
  }

  String objectEncodeJson() {
    final jsonData = toJson;
    return json.encode(jsonData);
  }

  static ContabilLancamentoPadraoModel fromPlutoRow(PlutoRow row) {
    return ContabilLancamentoPadraoModel(
      id: row.cells['id']?.value,
      descricao: row.cells['descricao']?.value,
      historico: row.cells['historico']?.value,
      idContaDebito: row.cells['idContaDebito']?.value,
      idContaCredito: row.cells['idContaCredito']?.value,
    );
  }

  PlutoRow toPlutoRow() {
    return PlutoRow(
      cells: {
        'tempId': PlutoCell(value: tempId),
        'id': PlutoCell(value: id ?? 0),
        'descricao': PlutoCell(value: descricao ?? ''),
        'historico': PlutoCell(value: historico ?? ''),
        'idContaDebito': PlutoCell(value: idContaDebito ?? 0),
        'idContaCredito': PlutoCell(value: idContaCredito ?? 0),
      },
    );
  }

  ContabilLancamentoPadraoModel clone() {
    return ContabilLancamentoPadraoModel(
      id: id,
      descricao: descricao,
      historico: historico,
      idContaDebito: idContaDebito,
      idContaCredito: idContaCredito,
    );
  }


}