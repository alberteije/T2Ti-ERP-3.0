import 'dart:convert';
import 'package:pluto_grid/pluto_grid.dart';
import 'package:contabil/app/data/model/model_imports.dart';


class ContabilContaRateioModel extends ModelBase {
  int? id;
  int? idCentroResultado;
  int? idContabilConta;
  double? porcentoRateio;
  ContabilContaModel? contabilContaModel;
  CentroResultadoModel? centroResultadoModel;

  ContabilContaRateioModel({
    this.id,
    this.idCentroResultado,
    this.idContabilConta,
    this.porcentoRateio,
    ContabilContaModel? contabilContaModel,
    CentroResultadoModel? centroResultadoModel,
  }) {
    this.contabilContaModel = contabilContaModel ?? ContabilContaModel();
    this.centroResultadoModel = centroResultadoModel ?? CentroResultadoModel();
  }

  static List<String> dbColumns = <String>[
    'id',
    'porcento_rateio',
  ];

  static List<String> aliasColumns = <String>[
    'Id',
    'Porcento Rateio',
  ];

  ContabilContaRateioModel.fromJson(Map<String, dynamic> jsonData) {
    id = jsonData['id'];
    idCentroResultado = jsonData['idCentroResultado'];
    idContabilConta = jsonData['idContabilConta'];
    porcentoRateio = jsonData['porcentoRateio']?.toDouble();
    contabilContaModel = jsonData['contabilContaModel'] == null ? ContabilContaModel() : ContabilContaModel.fromJson(jsonData['contabilContaModel']);
    centroResultadoModel = jsonData['centroResultadoModel'] == null ? CentroResultadoModel() : CentroResultadoModel.fromJson(jsonData['centroResultadoModel']);
  }

  Map<String, dynamic> get toJson {
    Map<String, dynamic> jsonData = <String, dynamic>{};

    jsonData['id'] = id != 0 ? id : null;
    jsonData['idCentroResultado'] = idCentroResultado != 0 ? idCentroResultado : null;
    jsonData['idContabilConta'] = idContabilConta != 0 ? idContabilConta : null;
    jsonData['porcentoRateio'] = porcentoRateio;
    jsonData['contabilContaModel'] = contabilContaModel?.toJson;
    jsonData['contabilConta'] = contabilContaModel?.descricao ?? '';
    jsonData['centroResultadoModel'] = centroResultadoModel?.toJson;
    jsonData['centroResultado'] = centroResultadoModel?.descricao ?? '';

    return jsonData;
  }

  String objectEncodeJson() {
    final jsonData = toJson;
    return json.encode(jsonData);
  }

  static ContabilContaRateioModel fromPlutoRow(PlutoRow row) {
    return ContabilContaRateioModel(
      id: row.cells['id']?.value,
      idCentroResultado: row.cells['idCentroResultado']?.value,
      idContabilConta: row.cells['idContabilConta']?.value,
      porcentoRateio: row.cells['porcentoRateio']?.value,
    );
  }

  PlutoRow toPlutoRow() {
    return PlutoRow(
      cells: {
        'tempId': PlutoCell(value: tempId),
        'id': PlutoCell(value: id ?? 0),
        'idCentroResultado': PlutoCell(value: idCentroResultado ?? 0),
        'idContabilConta': PlutoCell(value: idContabilConta ?? 0),
        'porcentoRateio': PlutoCell(value: porcentoRateio ?? 0.0),
        'contabilConta': PlutoCell(value: contabilContaModel?.descricao ?? ''),
        'centroResultado': PlutoCell(value: centroResultadoModel?.descricao ?? ''),
      },
    );
  }

  ContabilContaRateioModel clone() {
    return ContabilContaRateioModel(
      id: id,
      idCentroResultado: idCentroResultado,
      idContabilConta: idContabilConta,
      porcentoRateio: porcentoRateio,
      contabilContaModel: contabilContaModel?.clone(),
      centroResultadoModel: centroResultadoModel?.clone(),
    );
  }


}