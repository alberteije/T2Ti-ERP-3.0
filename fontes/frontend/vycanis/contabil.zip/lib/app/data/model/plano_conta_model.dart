import 'dart:convert';
import 'package:pluto_grid/pluto_grid.dart';
import 'package:contabil/app/data/model/model_imports.dart';

import 'package:contabil/app/infra/infra_imports.dart';
import 'package:intl/intl.dart';

class PlanoContaModel extends ModelBase {
  int? id;
  String? nome;
  DateTime? dataInclusao;
  String? mascara;
  int? niveis;

  PlanoContaModel({
    this.id,
    this.nome,
    this.dataInclusao,
    this.mascara,
    this.niveis,
  });

  static List<String> dbColumns = <String>[
    'id',
    'nome',
    'data_inclusao',
    'mascara',
    'niveis',
  ];

  static List<String> aliasColumns = <String>[
    'Id',
    'Nome',
    'Data Inclusao',
    'Mascara',
    'Niveis',
  ];

  PlanoContaModel.fromJson(Map<String, dynamic> jsonData) {
    id = jsonData['id'];
    nome = jsonData['nome'];
    dataInclusao = jsonData['dataInclusao'] != null ? DateTime.tryParse(jsonData['dataInclusao']) : null;
    mascara = jsonData['mascara'];
    niveis = jsonData['niveis'];
  }

  Map<String, dynamic> get toJson {
    Map<String, dynamic> jsonData = <String, dynamic>{};

    jsonData['id'] = id != 0 ? id : null;
    jsonData['nome'] = nome;
    jsonData['dataInclusao'] = dataInclusao != null ? DateFormat('yyyy-MM-ddT00:00:00').format(dataInclusao!) : null;
    jsonData['mascara'] = mascara;
    jsonData['niveis'] = niveis;

    return jsonData;
  }

  String objectEncodeJson() {
    final jsonData = toJson;
    return json.encode(jsonData);
  }

  static PlanoContaModel fromPlutoRow(PlutoRow row) {
    return PlanoContaModel(
      id: row.cells['id']?.value,
      nome: row.cells['nome']?.value,
      dataInclusao: Util.stringToDate(row.cells['dataInclusao']?.value),
      mascara: row.cells['mascara']?.value,
      niveis: row.cells['niveis']?.value,
    );
  }

  PlutoRow toPlutoRow() {
    return PlutoRow(
      cells: {
        'tempId': PlutoCell(value: tempId),
        'id': PlutoCell(value: id ?? 0),
        'nome': PlutoCell(value: nome ?? ''),
        'dataInclusao': PlutoCell(value: dataInclusao),
        'mascara': PlutoCell(value: mascara ?? ''),
        'niveis': PlutoCell(value: niveis ?? 0),
      },
    );
  }

  PlanoContaModel clone() {
    return PlanoContaModel(
      id: id,
      nome: nome,
      dataInclusao: dataInclusao,
      mascara: mascara,
      niveis: niveis,
    );
  }


}