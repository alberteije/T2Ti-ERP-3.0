import 'dart:convert';
import 'package:pluto_grid/pluto_grid.dart';
import 'package:contabil/app/data/model/model_imports.dart';

import 'package:contabil/app/data/domain/domain_imports.dart';

class CentroResultadoModel extends ModelBase {
  int? id;
  int? idPlanoCentroResultado;
  String? descricao;
  String? classificacao;
  String? sofreRateiro;
  PlanoCentroResultadoModel? planoCentroResultadoModel;
  List<CtResultadoNtFinanceiraModel>? ctResultadoNtFinanceiraModelList;

  CentroResultadoModel({
    this.id,
    this.idPlanoCentroResultado,
    this.descricao,
    this.classificacao,
    this.sofreRateiro = 'Sim',
    PlanoCentroResultadoModel? planoCentroResultadoModel,
    List<CtResultadoNtFinanceiraModel>? ctResultadoNtFinanceiraModelList,
  }) {
    this.planoCentroResultadoModel = planoCentroResultadoModel ?? PlanoCentroResultadoModel();
    this.ctResultadoNtFinanceiraModelList = ctResultadoNtFinanceiraModelList?.toList(growable: true) ?? [];
  }

  static List<String> dbColumns = <String>[
    'id',
    'descricao',
    'classificacao',
    'sofre_rateiro',
  ];

  static List<String> aliasColumns = <String>[
    'Id',
    'Descricao',
    'Classificacao',
    'Sofre Rateiro',
  ];

  CentroResultadoModel.fromJson(Map<String, dynamic> jsonData) {
    id = jsonData['id'];
    idPlanoCentroResultado = jsonData['idPlanoCentroResultado'];
    descricao = jsonData['descricao'];
    classificacao = jsonData['classificacao'];
    sofreRateiro = CentroResultadoDomain.getSofreRateiro(jsonData['sofreRateiro']);
    planoCentroResultadoModel = jsonData['planoCentroResultadoModel'] == null ? PlanoCentroResultadoModel() : PlanoCentroResultadoModel.fromJson(jsonData['planoCentroResultadoModel']);
    ctResultadoNtFinanceiraModelList = (jsonData['ctResultadoNtFinanceiraModelList'] as Iterable?)?.map((m) => CtResultadoNtFinanceiraModel.fromJson(m)).toList() ?? [];
  }

  Map<String, dynamic> get toJson {
    Map<String, dynamic> jsonData = <String, dynamic>{};

    jsonData['id'] = id != 0 ? id : null;
    jsonData['idPlanoCentroResultado'] = idPlanoCentroResultado != 0 ? idPlanoCentroResultado : null;
    jsonData['descricao'] = descricao;
    jsonData['classificacao'] = classificacao;
    jsonData['sofreRateiro'] = CentroResultadoDomain.setSofreRateiro(sofreRateiro);
    jsonData['planoCentroResultadoModel'] = planoCentroResultadoModel?.toJson;
    jsonData['planoCentroResultado'] = planoCentroResultadoModel?.nome ?? '';
    
		var ctResultadoNtFinanceiraModelLocalList = []; 
		for (CtResultadoNtFinanceiraModel object in ctResultadoNtFinanceiraModelList ?? []) { 
			ctResultadoNtFinanceiraModelLocalList.add(object.toJson); 
		}
		jsonData['ctResultadoNtFinanceiraModelList'] = ctResultadoNtFinanceiraModelLocalList;

    return jsonData;
  }

  String objectEncodeJson() {
    final jsonData = toJson;
    return json.encode(jsonData);
  }

  static CentroResultadoModel fromPlutoRow(PlutoRow row) {
    return CentroResultadoModel(
      id: row.cells['id']?.value,
      idPlanoCentroResultado: row.cells['idPlanoCentroResultado']?.value,
      descricao: row.cells['descricao']?.value,
      classificacao: row.cells['classificacao']?.value,
      sofreRateiro: row.cells['sofreRateiro']?.value,
    );
  }

  PlutoRow toPlutoRow() {
    return PlutoRow(
      cells: {
        'tempId': PlutoCell(value: tempId),
        'id': PlutoCell(value: id ?? 0),
        'idPlanoCentroResultado': PlutoCell(value: idPlanoCentroResultado ?? 0),
        'descricao': PlutoCell(value: descricao ?? ''),
        'classificacao': PlutoCell(value: classificacao ?? ''),
        'sofreRateiro': PlutoCell(value: sofreRateiro ?? ''),
        'planoCentroResultado': PlutoCell(value: planoCentroResultadoModel?.nome ?? ''),
      },
    );
  }

  CentroResultadoModel clone() {
    return CentroResultadoModel(
      id: id,
      idPlanoCentroResultado: idPlanoCentroResultado,
      descricao: descricao,
      classificacao: classificacao,
      sofreRateiro: sofreRateiro,
      planoCentroResultadoModel: planoCentroResultadoModel?.clone(),
      ctResultadoNtFinanceiraModelList: ctResultadoNtFinanceiraModelListClone(ctResultadoNtFinanceiraModelList!),
    );
  }

  ctResultadoNtFinanceiraModelListClone(List<CtResultadoNtFinanceiraModel> ctResultadoNtFinanceiraModelList) { 
		List<CtResultadoNtFinanceiraModel> resultList = [];
		for (var ctResultadoNtFinanceiraModel in ctResultadoNtFinanceiraModelList) {
			resultList.add(ctResultadoNtFinanceiraModel.clone());
		}
		return resultList;
	}


}