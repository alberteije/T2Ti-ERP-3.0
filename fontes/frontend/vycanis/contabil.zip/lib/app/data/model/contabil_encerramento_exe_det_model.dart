import 'dart:convert';
import 'package:pluto_grid/pluto_grid.dart';
import 'package:contabil/app/data/model/model_imports.dart';


class ContabilEncerramentoExeDetModel extends ModelBase {
  int? id;
  int? idContabilEncerramentoExe;
  int? idContabilConta;
  double? saldoAnterior;
  double? valorDebito;
  double? valorCredito;
  double? saldo;
  ContabilContaModel? contabilContaModel;

  ContabilEncerramentoExeDetModel({
    this.id,
    this.idContabilEncerramentoExe,
    this.idContabilConta,
    this.saldoAnterior,
    this.valorDebito,
    this.valorCredito,
    this.saldo,
    ContabilContaModel? contabilContaModel,
  }) {
    this.contabilContaModel = contabilContaModel ?? ContabilContaModel();
  }

  static List<String> dbColumns = <String>[
    'id',
    'saldo_anterior',
    'valor_debito',
    'valor_credito',
    'saldo',
  ];

  static List<String> aliasColumns = <String>[
    'Id',
    'Saldo Anterior',
    'Valor Debito',
    'Valor Credito',
    'Saldo',
  ];

  ContabilEncerramentoExeDetModel.fromJson(Map<String, dynamic> jsonData) {
    id = jsonData['id'];
    idContabilEncerramentoExe = jsonData['idContabilEncerramentoExe'];
    idContabilConta = jsonData['idContabilConta'];
    saldoAnterior = jsonData['saldoAnterior']?.toDouble();
    valorDebito = jsonData['valorDebito']?.toDouble();
    valorCredito = jsonData['valorCredito']?.toDouble();
    saldo = jsonData['saldo']?.toDouble();
    contabilContaModel = jsonData['contabilContaModel'] == null ? ContabilContaModel() : ContabilContaModel.fromJson(jsonData['contabilContaModel']);
  }

  Map<String, dynamic> get toJson {
    Map<String, dynamic> jsonData = <String, dynamic>{};

    jsonData['id'] = id != 0 ? id : null;
    jsonData['idContabilEncerramentoExe'] = idContabilEncerramentoExe != 0 ? idContabilEncerramentoExe : null;
    jsonData['idContabilConta'] = idContabilConta != 0 ? idContabilConta : null;
    jsonData['saldoAnterior'] = saldoAnterior;
    jsonData['valorDebito'] = valorDebito;
    jsonData['valorCredito'] = valorCredito;
    jsonData['saldo'] = saldo;
    jsonData['contabilContaModel'] = contabilContaModel?.toJson;
    jsonData['contabilConta'] = contabilContaModel?.descricao ?? '';

    return jsonData;
  }

  String objectEncodeJson() {
    final jsonData = toJson;
    return json.encode(jsonData);
  }

  static ContabilEncerramentoExeDetModel fromPlutoRow(PlutoRow row) {
    return ContabilEncerramentoExeDetModel(
      id: row.cells['id']?.value,
      idContabilEncerramentoExe: row.cells['idContabilEncerramentoExe']?.value,
      idContabilConta: row.cells['idContabilConta']?.value,
      saldoAnterior: row.cells['saldoAnterior']?.value,
      valorDebito: row.cells['valorDebito']?.value,
      valorCredito: row.cells['valorCredito']?.value,
      saldo: row.cells['saldo']?.value,
    );
  }

  PlutoRow toPlutoRow() {
    return PlutoRow(
      cells: {
        'tempId': PlutoCell(value: tempId),
        'id': PlutoCell(value: id ?? 0),
        'idContabilEncerramentoExe': PlutoCell(value: idContabilEncerramentoExe ?? 0),
        'idContabilConta': PlutoCell(value: idContabilConta ?? 0),
        'saldoAnterior': PlutoCell(value: saldoAnterior ?? 0.0),
        'valorDebito': PlutoCell(value: valorDebito ?? 0.0),
        'valorCredito': PlutoCell(value: valorCredito ?? 0.0),
        'saldo': PlutoCell(value: saldo ?? 0.0),
        'contabilConta': PlutoCell(value: contabilContaModel?.descricao ?? ''),
      },
    );
  }

  ContabilEncerramentoExeDetModel clone() {
    return ContabilEncerramentoExeDetModel(
      id: id,
      idContabilEncerramentoExe: idContabilEncerramentoExe,
      idContabilConta: idContabilConta,
      saldoAnterior: saldoAnterior,
      valorDebito: valorDebito,
      valorCredito: valorCredito,
      saldo: saldo,
      contabilContaModel: contabilContaModel?.clone(),
    );
  }


}