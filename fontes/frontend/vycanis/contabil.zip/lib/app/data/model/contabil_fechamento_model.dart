import 'dart:convert';
import 'package:pluto_grid/pluto_grid.dart';
import 'package:contabil/app/data/model/model_imports.dart';

import 'package:contabil/app/infra/infra_imports.dart';
import 'package:intl/intl.dart';
import 'package:contabil/app/data/domain/domain_imports.dart';

class ContabilFechamentoModel extends ModelBase {
  int? id;
  DateTime? dataInicio;
  DateTime? dataFim;
  String? criterioLancamento;

  ContabilFechamentoModel({
    this.id,
    this.dataInicio,
    this.dataFim,
    this.criterioLancamento = 'Livre',
  });

  static List<String> dbColumns = <String>[
    'id',
    'data_inicio',
    'data_fim',
    'criterio_lancamento',
  ];

  static List<String> aliasColumns = <String>[
    'Id',
    'Data Inicio',
    'Data Fim',
    'Criterio Lancamento',
  ];

  ContabilFechamentoModel.fromJson(Map<String, dynamic> jsonData) {
    id = jsonData['id'];
    dataInicio = jsonData['dataInicio'] != null ? DateTime.tryParse(jsonData['dataInicio']) : null;
    dataFim = jsonData['dataFim'] != null ? DateTime.tryParse(jsonData['dataFim']) : null;
    criterioLancamento = ContabilFechamentoDomain.getCriterioLancamento(jsonData['criterioLancamento']);
  }

  Map<String, dynamic> get toJson {
    Map<String, dynamic> jsonData = <String, dynamic>{};

    jsonData['id'] = id != 0 ? id : null;
    jsonData['dataInicio'] = dataInicio != null ? DateFormat('yyyy-MM-ddT00:00:00').format(dataInicio!) : null;
    jsonData['dataFim'] = dataFim != null ? DateFormat('yyyy-MM-ddT00:00:00').format(dataFim!) : null;
    jsonData['criterioLancamento'] = ContabilFechamentoDomain.setCriterioLancamento(criterioLancamento);

    return jsonData;
  }

  String objectEncodeJson() {
    final jsonData = toJson;
    return json.encode(jsonData);
  }

  static ContabilFechamentoModel fromPlutoRow(PlutoRow row) {
    return ContabilFechamentoModel(
      id: row.cells['id']?.value,
      dataInicio: Util.stringToDate(row.cells['dataInicio']?.value),
      dataFim: Util.stringToDate(row.cells['dataFim']?.value),
      criterioLancamento: row.cells['criterioLancamento']?.value,
    );
  }

  PlutoRow toPlutoRow() {
    return PlutoRow(
      cells: {
        'tempId': PlutoCell(value: tempId),
        'id': PlutoCell(value: id ?? 0),
        'dataInicio': PlutoCell(value: dataInicio),
        'dataFim': PlutoCell(value: dataFim),
        'criterioLancamento': PlutoCell(value: criterioLancamento ?? ''),
      },
    );
  }

  ContabilFechamentoModel clone() {
    return ContabilFechamentoModel(
      id: id,
      dataInicio: dataInicio,
      dataFim: dataFim,
      criterioLancamento: criterioLancamento,
    );
  }


}