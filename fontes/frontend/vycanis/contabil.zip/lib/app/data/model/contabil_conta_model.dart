import 'dart:convert';
import 'package:pluto_grid/pluto_grid.dart';
import 'package:contabil/app/data/model/model_imports.dart';

import 'package:contabil/app/infra/infra_imports.dart';
import 'package:intl/intl.dart';
import 'package:contabil/app/data/domain/domain_imports.dart';

class ContabilContaModel extends ModelBase {
  int? id;
  int? idPlanoConta;
  int? idPlanoContaRefSped;
  int? idContabilConta;
  String? classificacao;
  String? tipo;
  String? descricao;
  DateTime? dataInclusao;
  String? situacao;
  String? natureza;
  String? patrimonioResultado;
  String? livroCaixa;
  String? dfc;
  String? codigoEfd;
  String? ordem;
  String? codigoReduzido;
  PlanoContaModel? planoContaModel;
  PlanoContaRefSpedModel? planoContaRefSpedModel;

  ContabilContaModel({
    this.id,
    this.idPlanoConta,
    this.idPlanoContaRefSped,
    this.idContabilConta,
    this.classificacao,
    this.tipo = 'Sintética',
    this.descricao,
    this.dataInclusao,
    this.situacao = 'Ativa',
    this.natureza = 'Credora',
    this.patrimonioResultado = 'Patrimonio',
    this.livroCaixa = 'Sim',
    this.dfc = 'Não participa',
    this.codigoEfd,
    this.ordem,
    this.codigoReduzido,
    PlanoContaModel? planoContaModel,
    PlanoContaRefSpedModel? planoContaRefSpedModel,
  }) {
    this.planoContaModel = planoContaModel ?? PlanoContaModel();
    this.planoContaRefSpedModel = planoContaRefSpedModel ?? PlanoContaRefSpedModel();
  }

  static List<String> dbColumns = <String>[
    'id',
    'id_contabil_conta',
    'classificacao',
    'tipo',
    'descricao',
    'data_inclusao',
    'situacao',
    'natureza',
    'patrimonio_resultado',
    'livro_caixa',
    'dfc',
    'codigo_efd',
    'ordem',
    'codigo_reduzido',
  ];

  static List<String> aliasColumns = <String>[
    'Id',
    'Id Contabil Conta',
    'Classificacao',
    'Tipo',
    'Descricao',
    'Data Inclusao',
    'Situacao',
    'Natureza',
    'Patrimonio Resultado',
    'Livro Caixa',
    'Dfc',
    'Codigo Efd',
    'Ordem',
    'Codigo Reduzido',
  ];

  ContabilContaModel.fromJson(Map<String, dynamic> jsonData) {
    id = jsonData['id'];
    idPlanoConta = jsonData['idPlanoConta'];
    idPlanoContaRefSped = jsonData['idPlanoContaRefSped'];
    idContabilConta = jsonData['idContabilConta'];
    classificacao = jsonData['classificacao'];
    tipo = ContabilContaDomain.getTipo(jsonData['tipo']);
    descricao = jsonData['descricao'];
    dataInclusao = jsonData['dataInclusao'] != null ? DateTime.tryParse(jsonData['dataInclusao']) : null;
    situacao = ContabilContaDomain.getSituacao(jsonData['situacao']);
    natureza = ContabilContaDomain.getNatureza(jsonData['natureza']);
    patrimonioResultado = ContabilContaDomain.getPatrimonioResultado(jsonData['patrimonioResultado']);
    livroCaixa = ContabilContaDomain.getLivroCaixa(jsonData['livroCaixa']);
    dfc = ContabilContaDomain.getDfc(jsonData['dfc']);
    codigoEfd = jsonData['codigoEfd'];
    ordem = jsonData['ordem'];
    codigoReduzido = jsonData['codigoReduzido'];
    planoContaModel = jsonData['planoContaModel'] == null ? PlanoContaModel() : PlanoContaModel.fromJson(jsonData['planoContaModel']);
    planoContaRefSpedModel = jsonData['planoContaRefSpedModel'] == null ? PlanoContaRefSpedModel() : PlanoContaRefSpedModel.fromJson(jsonData['planoContaRefSpedModel']);
  }

  Map<String, dynamic> get toJson {
    Map<String, dynamic> jsonData = <String, dynamic>{};

    jsonData['id'] = id != 0 ? id : null;
    jsonData['idPlanoConta'] = idPlanoConta != 0 ? idPlanoConta : null;
    jsonData['idPlanoContaRefSped'] = idPlanoContaRefSped != 0 ? idPlanoContaRefSped : null;
    jsonData['idContabilConta'] = idContabilConta;
    jsonData['classificacao'] = classificacao;
    jsonData['tipo'] = ContabilContaDomain.setTipo(tipo);
    jsonData['descricao'] = descricao;
    jsonData['dataInclusao'] = dataInclusao != null ? DateFormat('yyyy-MM-ddT00:00:00').format(dataInclusao!) : null;
    jsonData['situacao'] = ContabilContaDomain.setSituacao(situacao);
    jsonData['natureza'] = ContabilContaDomain.setNatureza(natureza);
    jsonData['patrimonioResultado'] = ContabilContaDomain.setPatrimonioResultado(patrimonioResultado);
    jsonData['livroCaixa'] = ContabilContaDomain.setLivroCaixa(livroCaixa);
    jsonData['dfc'] = ContabilContaDomain.setDfc(dfc);
    jsonData['codigoEfd'] = codigoEfd;
    jsonData['ordem'] = ordem;
    jsonData['codigoReduzido'] = codigoReduzido;
    jsonData['planoContaModel'] = planoContaModel?.toJson;
    jsonData['planoConta'] = planoContaModel?.nome ?? '';
    jsonData['planoContaRefSpedModel'] = planoContaRefSpedModel?.toJson;
    jsonData['planoContaRefSped'] = planoContaRefSpedModel?.codCtaRef ?? '';

    return jsonData;
  }

  String objectEncodeJson() {
    final jsonData = toJson;
    return json.encode(jsonData);
  }

  static ContabilContaModel fromPlutoRow(PlutoRow row) {
    return ContabilContaModel(
      id: row.cells['id']?.value,
      idPlanoConta: row.cells['idPlanoConta']?.value,
      idPlanoContaRefSped: row.cells['idPlanoContaRefSped']?.value,
      idContabilConta: row.cells['idContabilConta']?.value,
      classificacao: row.cells['classificacao']?.value,
      tipo: row.cells['tipo']?.value,
      descricao: row.cells['descricao']?.value,
      dataInclusao: Util.stringToDate(row.cells['dataInclusao']?.value),
      situacao: row.cells['situacao']?.value,
      natureza: row.cells['natureza']?.value,
      patrimonioResultado: row.cells['patrimonioResultado']?.value,
      livroCaixa: row.cells['livroCaixa']?.value,
      dfc: row.cells['dfc']?.value,
      codigoEfd: row.cells['codigoEfd']?.value,
      ordem: row.cells['ordem']?.value,
      codigoReduzido: row.cells['codigoReduzido']?.value,
    );
  }

  PlutoRow toPlutoRow() {
    return PlutoRow(
      cells: {
        'tempId': PlutoCell(value: tempId),
        'id': PlutoCell(value: id ?? 0),
        'idPlanoConta': PlutoCell(value: idPlanoConta ?? 0),
        'idPlanoContaRefSped': PlutoCell(value: idPlanoContaRefSped ?? 0),
        'idContabilConta': PlutoCell(value: idContabilConta ?? 0),
        'classificacao': PlutoCell(value: classificacao ?? ''),
        'tipo': PlutoCell(value: tipo ?? ''),
        'descricao': PlutoCell(value: descricao ?? ''),
        'dataInclusao': PlutoCell(value: dataInclusao),
        'situacao': PlutoCell(value: situacao ?? ''),
        'natureza': PlutoCell(value: natureza ?? ''),
        'patrimonioResultado': PlutoCell(value: patrimonioResultado ?? ''),
        'livroCaixa': PlutoCell(value: livroCaixa ?? ''),
        'dfc': PlutoCell(value: dfc ?? ''),
        'codigoEfd': PlutoCell(value: codigoEfd ?? ''),
        'ordem': PlutoCell(value: ordem ?? ''),
        'codigoReduzido': PlutoCell(value: codigoReduzido ?? ''),
        'planoConta': PlutoCell(value: planoContaModel?.nome ?? ''),
        'planoContaRefSped': PlutoCell(value: planoContaRefSpedModel?.codCtaRef ?? ''),
      },
    );
  }

  ContabilContaModel clone() {
    return ContabilContaModel(
      id: id,
      idPlanoConta: idPlanoConta,
      idPlanoContaRefSped: idPlanoContaRefSped,
      idContabilConta: idContabilConta,
      classificacao: classificacao,
      tipo: tipo,
      descricao: descricao,
      dataInclusao: dataInclusao,
      situacao: situacao,
      natureza: natureza,
      patrimonioResultado: patrimonioResultado,
      livroCaixa: livroCaixa,
      dfc: dfc,
      codigoEfd: codigoEfd,
      ordem: ordem,
      codigoReduzido: codigoReduzido,
      planoContaModel: planoContaModel?.clone(),
      planoContaRefSpedModel: planoContaRefSpedModel?.clone(),
    );
  }


}