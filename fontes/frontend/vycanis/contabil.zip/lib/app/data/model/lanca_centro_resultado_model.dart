import 'dart:convert';
import 'package:pluto_grid/pluto_grid.dart';
import 'package:contabil/app/data/model/model_imports.dart';

import 'package:contabil/app/infra/infra_imports.dart';
import 'package:intl/intl.dart';
import 'package:contabil/app/data/domain/domain_imports.dart';

class LancaCentroResultadoModel extends ModelBase {
  int? id;
  int? idCentroResultado;
  double? valor;
  DateTime? dataLancamento;
  DateTime? dataInclusao;
  String? origemDeRateio;
  String? historico;
  CentroResultadoModel? centroResultadoModel;

  LancaCentroResultadoModel({
    this.id,
    this.idCentroResultado,
    this.valor,
    this.dataLancamento,
    this.dataInclusao,
    this.origemDeRateio = 'Sim',
    this.historico,
    CentroResultadoModel? centroResultadoModel,
  }) {
    this.centroResultadoModel = centroResultadoModel ?? CentroResultadoModel();
  }

  static List<String> dbColumns = <String>[
    'id',
    'valor',
    'data_lancamento',
    'data_inclusao',
    'origem_de_rateio',
    'historico',
  ];

  static List<String> aliasColumns = <String>[
    'Id',
    'Valor',
    'Data Lancamento',
    'Data Inclusao',
    'Origem De Rateio',
    'Historico',
  ];

  LancaCentroResultadoModel.fromJson(Map<String, dynamic> jsonData) {
    id = jsonData['id'];
    idCentroResultado = jsonData['idCentroResultado'];
    valor = jsonData['valor']?.toDouble();
    dataLancamento = jsonData['dataLancamento'] != null ? DateTime.tryParse(jsonData['dataLancamento']) : null;
    dataInclusao = jsonData['dataInclusao'] != null ? DateTime.tryParse(jsonData['dataInclusao']) : null;
    origemDeRateio = LancaCentroResultadoDomain.getOrigemDeRateio(jsonData['origemDeRateio']);
    historico = jsonData['historico'];
    centroResultadoModel = jsonData['centroResultadoModel'] == null ? CentroResultadoModel() : CentroResultadoModel.fromJson(jsonData['centroResultadoModel']);
  }

  Map<String, dynamic> get toJson {
    Map<String, dynamic> jsonData = <String, dynamic>{};

    jsonData['id'] = id != 0 ? id : null;
    jsonData['idCentroResultado'] = idCentroResultado != 0 ? idCentroResultado : null;
    jsonData['valor'] = valor;
    jsonData['dataLancamento'] = dataLancamento != null ? DateFormat('yyyy-MM-ddT00:00:00').format(dataLancamento!) : null;
    jsonData['dataInclusao'] = dataInclusao != null ? DateFormat('yyyy-MM-ddT00:00:00').format(dataInclusao!) : null;
    jsonData['origemDeRateio'] = LancaCentroResultadoDomain.setOrigemDeRateio(origemDeRateio);
    jsonData['historico'] = historico;
    jsonData['centroResultadoModel'] = centroResultadoModel?.toJson;
    jsonData['centroResultado'] = centroResultadoModel?.descricao ?? '';

    return jsonData;
  }

  String objectEncodeJson() {
    final jsonData = toJson;
    return json.encode(jsonData);
  }

  static LancaCentroResultadoModel fromPlutoRow(PlutoRow row) {
    return LancaCentroResultadoModel(
      id: row.cells['id']?.value,
      idCentroResultado: row.cells['idCentroResultado']?.value,
      valor: row.cells['valor']?.value,
      dataLancamento: Util.stringToDate(row.cells['dataLancamento']?.value),
      dataInclusao: Util.stringToDate(row.cells['dataInclusao']?.value),
      origemDeRateio: row.cells['origemDeRateio']?.value,
      historico: row.cells['historico']?.value,
    );
  }

  PlutoRow toPlutoRow() {
    return PlutoRow(
      cells: {
        'tempId': PlutoCell(value: tempId),
        'id': PlutoCell(value: id ?? 0),
        'idCentroResultado': PlutoCell(value: idCentroResultado ?? 0),
        'valor': PlutoCell(value: valor ?? 0.0),
        'dataLancamento': PlutoCell(value: dataLancamento),
        'dataInclusao': PlutoCell(value: dataInclusao),
        'origemDeRateio': PlutoCell(value: origemDeRateio ?? ''),
        'historico': PlutoCell(value: historico ?? ''),
        'centroResultado': PlutoCell(value: centroResultadoModel?.descricao ?? ''),
      },
    );
  }

  LancaCentroResultadoModel clone() {
    return LancaCentroResultadoModel(
      id: id,
      idCentroResultado: idCentroResultado,
      valor: valor,
      dataLancamento: dataLancamento,
      dataInclusao: dataInclusao,
      origemDeRateio: origemDeRateio,
      historico: historico,
      centroResultadoModel: centroResultadoModel?.clone(),
    );
  }


}