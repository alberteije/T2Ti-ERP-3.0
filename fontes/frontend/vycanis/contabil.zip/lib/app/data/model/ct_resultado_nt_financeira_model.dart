import 'dart:convert';
import 'package:pluto_grid/pluto_grid.dart';
import 'package:contabil/app/data/model/model_imports.dart';


class CtResultadoNtFinanceiraModel extends ModelBase {
  int? id;
  int? idCentroResultado;
  int? idFinNaturezaFinanceira;
  double? percentualRateio;
  FinNaturezaFinanceiraModel? finNaturezaFinanceiraModel;

  CtResultadoNtFinanceiraModel({
    this.id,
    this.idCentroResultado,
    this.idFinNaturezaFinanceira,
    this.percentualRateio,
    FinNaturezaFinanceiraModel? finNaturezaFinanceiraModel,
  }) {
    this.finNaturezaFinanceiraModel = finNaturezaFinanceiraModel ?? FinNaturezaFinanceiraModel();
  }

  static List<String> dbColumns = <String>[
    'id',
    'percentual_rateio',
  ];

  static List<String> aliasColumns = <String>[
    'Id',
    'Percentual Rateio',
  ];

  CtResultadoNtFinanceiraModel.fromJson(Map<String, dynamic> jsonData) {
    id = jsonData['id'];
    idCentroResultado = jsonData['idCentroResultado'];
    idFinNaturezaFinanceira = jsonData['idFinNaturezaFinanceira'];
    percentualRateio = jsonData['percentualRateio']?.toDouble();
    finNaturezaFinanceiraModel = jsonData['finNaturezaFinanceiraModel'] == null ? FinNaturezaFinanceiraModel() : FinNaturezaFinanceiraModel.fromJson(jsonData['finNaturezaFinanceiraModel']);
  }

  Map<String, dynamic> get toJson {
    Map<String, dynamic> jsonData = <String, dynamic>{};

    jsonData['id'] = id != 0 ? id : null;
    jsonData['idCentroResultado'] = idCentroResultado != 0 ? idCentroResultado : null;
    jsonData['idFinNaturezaFinanceira'] = idFinNaturezaFinanceira != 0 ? idFinNaturezaFinanceira : null;
    jsonData['percentualRateio'] = percentualRateio;
    jsonData['finNaturezaFinanceiraModel'] = finNaturezaFinanceiraModel?.toJson;
    jsonData['finNaturezaFinanceira'] = finNaturezaFinanceiraModel?.descricao ?? '';

    return jsonData;
  }

  String objectEncodeJson() {
    final jsonData = toJson;
    return json.encode(jsonData);
  }

  static CtResultadoNtFinanceiraModel fromPlutoRow(PlutoRow row) {
    return CtResultadoNtFinanceiraModel(
      id: row.cells['id']?.value,
      idCentroResultado: row.cells['idCentroResultado']?.value,
      idFinNaturezaFinanceira: row.cells['idFinNaturezaFinanceira']?.value,
      percentualRateio: row.cells['percentualRateio']?.value,
    );
  }

  PlutoRow toPlutoRow() {
    return PlutoRow(
      cells: {
        'tempId': PlutoCell(value: tempId),
        'id': PlutoCell(value: id ?? 0),
        'idCentroResultado': PlutoCell(value: idCentroResultado ?? 0),
        'idFinNaturezaFinanceira': PlutoCell(value: idFinNaturezaFinanceira ?? 0),
        'percentualRateio': PlutoCell(value: percentualRateio ?? 0.0),
        'finNaturezaFinanceira': PlutoCell(value: finNaturezaFinanceiraModel?.descricao ?? ''),
      },
    );
  }

  CtResultadoNtFinanceiraModel clone() {
    return CtResultadoNtFinanceiraModel(
      id: id,
      idCentroResultado: idCentroResultado,
      idFinNaturezaFinanceira: idFinNaturezaFinanceira,
      percentualRateio: percentualRateio,
      finNaturezaFinanceiraModel: finNaturezaFinanceiraModel?.clone(),
    );
  }


}