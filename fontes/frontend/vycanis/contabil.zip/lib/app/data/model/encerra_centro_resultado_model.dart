import 'dart:convert';
import 'package:pluto_grid/pluto_grid.dart';
import 'package:contabil/app/data/model/model_imports.dart';

import 'package:contabil/app/infra/infra_imports.dart';

class EncerraCentroResultadoModel extends ModelBase {
  int? id;
  int? idCentroResultado;
  String? competencia;
  double? valorTotal;
  double? valorSubRateio;
  CentroResultadoModel? centroResultadoModel;

  EncerraCentroResultadoModel({
    this.id,
    this.idCentroResultado,
    this.competencia,
    this.valorTotal,
    this.valorSubRateio,
    CentroResultadoModel? centroResultadoModel,
  }) {
    this.centroResultadoModel = centroResultadoModel ?? CentroResultadoModel();
  }

  static List<String> dbColumns = <String>[
    'id',
    'competencia',
    'valor_total',
    'valor_sub_rateio',
  ];

  static List<String> aliasColumns = <String>[
    'Id',
    'Competencia',
    'Valor Total',
    'Valor Sub Rateio',
  ];

  EncerraCentroResultadoModel.fromJson(Map<String, dynamic> jsonData) {
    id = jsonData['id'];
    idCentroResultado = jsonData['idCentroResultado'];
    competencia = jsonData['competencia'];
    valorTotal = jsonData['valorTotal']?.toDouble();
    valorSubRateio = jsonData['valorSubRateio']?.toDouble();
    centroResultadoModel = jsonData['centroResultadoModel'] == null ? CentroResultadoModel() : CentroResultadoModel.fromJson(jsonData['centroResultadoModel']);
  }

  Map<String, dynamic> get toJson {
    Map<String, dynamic> jsonData = <String, dynamic>{};

    jsonData['id'] = id != 0 ? id : null;
    jsonData['idCentroResultado'] = idCentroResultado != 0 ? idCentroResultado : null;
    jsonData['competencia'] = Util.removeMask(competencia);
    jsonData['valorTotal'] = valorTotal;
    jsonData['valorSubRateio'] = valorSubRateio;
    jsonData['centroResultadoModel'] = centroResultadoModel?.toJson;
    jsonData['centroResultado'] = centroResultadoModel?.descricao ?? '';

    return jsonData;
  }

  String objectEncodeJson() {
    final jsonData = toJson;
    return json.encode(jsonData);
  }

  static EncerraCentroResultadoModel fromPlutoRow(PlutoRow row) {
    return EncerraCentroResultadoModel(
      id: row.cells['id']?.value,
      idCentroResultado: row.cells['idCentroResultado']?.value,
      competencia: row.cells['competencia']?.value,
      valorTotal: row.cells['valorTotal']?.value,
      valorSubRateio: row.cells['valorSubRateio']?.value,
    );
  }

  PlutoRow toPlutoRow() {
    return PlutoRow(
      cells: {
        'tempId': PlutoCell(value: tempId),
        'id': PlutoCell(value: id ?? 0),
        'idCentroResultado': PlutoCell(value: idCentroResultado ?? 0),
        'competencia': PlutoCell(value: competencia ?? ''),
        'valorTotal': PlutoCell(value: valorTotal ?? 0.0),
        'valorSubRateio': PlutoCell(value: valorSubRateio ?? 0.0),
        'centroResultado': PlutoCell(value: centroResultadoModel?.descricao ?? ''),
      },
    );
  }

  EncerraCentroResultadoModel clone() {
    return EncerraCentroResultadoModel(
      id: id,
      idCentroResultado: idCentroResultado,
      competencia: competencia,
      valorTotal: valorTotal,
      valorSubRateio: valorSubRateio,
      centroResultadoModel: centroResultadoModel?.clone(),
    );
  }


}