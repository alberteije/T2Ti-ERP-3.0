import 'dart:convert';
import 'package:pluto_grid/pluto_grid.dart';
import 'package:contabil/app/data/model/model_imports.dart';


class ContabilLancamentoOrcadoModel extends ModelBase {
  int? id;
  int? idContabilConta;
  String? ano;
  double? janeiro;
  double? fevereiro;
  double? marco;
  double? abril;
  double? maio;
  double? junho;
  double? julho;
  double? agosto;
  double? setembro;
  double? outubro;
  double? novembro;
  double? dezembro;
  ContabilContaModel? contabilContaModel;

  ContabilLancamentoOrcadoModel({
    this.id,
    this.idContabilConta,
    this.ano,
    this.janeiro,
    this.fevereiro,
    this.marco,
    this.abril,
    this.maio,
    this.junho,
    this.julho,
    this.agosto,
    this.setembro,
    this.outubro,
    this.novembro,
    this.dezembro,
    ContabilContaModel? contabilContaModel,
  }) {
    this.contabilContaModel = contabilContaModel ?? ContabilContaModel();
  }

  static List<String> dbColumns = <String>[
    'id',
    'ano',
    'janeiro',
    'fevereiro',
    'marco',
    'abril',
    'maio',
    'junho',
    'julho',
    'agosto',
    'setembro',
    'outubro',
    'novembro',
    'dezembro',
  ];

  static List<String> aliasColumns = <String>[
    'Id',
    'Ano',
    'Janeiro',
    'Fevereiro',
    'Marco',
    'Abril',
    'Maio',
    'Junho',
    'Julho',
    'Agosto',
    'Setembro',
    'Outubro',
    'Novembro',
    'Dezembro',
  ];

  ContabilLancamentoOrcadoModel.fromJson(Map<String, dynamic> jsonData) {
    id = jsonData['id'];
    idContabilConta = jsonData['idContabilConta'];
    ano = jsonData['ano'];
    janeiro = jsonData['janeiro']?.toDouble();
    fevereiro = jsonData['fevereiro']?.toDouble();
    marco = jsonData['marco']?.toDouble();
    abril = jsonData['abril']?.toDouble();
    maio = jsonData['maio']?.toDouble();
    junho = jsonData['junho']?.toDouble();
    julho = jsonData['julho']?.toDouble();
    agosto = jsonData['agosto']?.toDouble();
    setembro = jsonData['setembro']?.toDouble();
    outubro = jsonData['outubro']?.toDouble();
    novembro = jsonData['novembro']?.toDouble();
    dezembro = jsonData['dezembro']?.toDouble();
    contabilContaModel = jsonData['contabilContaModel'] == null ? ContabilContaModel() : ContabilContaModel.fromJson(jsonData['contabilContaModel']);
  }

  Map<String, dynamic> get toJson {
    Map<String, dynamic> jsonData = <String, dynamic>{};

    jsonData['id'] = id != 0 ? id : null;
    jsonData['idContabilConta'] = idContabilConta != 0 ? idContabilConta : null;
    jsonData['ano'] = ano;
    jsonData['janeiro'] = janeiro;
    jsonData['fevereiro'] = fevereiro;
    jsonData['marco'] = marco;
    jsonData['abril'] = abril;
    jsonData['maio'] = maio;
    jsonData['junho'] = junho;
    jsonData['julho'] = julho;
    jsonData['agosto'] = agosto;
    jsonData['setembro'] = setembro;
    jsonData['outubro'] = outubro;
    jsonData['novembro'] = novembro;
    jsonData['dezembro'] = dezembro;
    jsonData['contabilContaModel'] = contabilContaModel?.toJson;
    jsonData['contabilConta'] = contabilContaModel?.descricao ?? '';

    return jsonData;
  }

  String objectEncodeJson() {
    final jsonData = toJson;
    return json.encode(jsonData);
  }

  static ContabilLancamentoOrcadoModel fromPlutoRow(PlutoRow row) {
    return ContabilLancamentoOrcadoModel(
      id: row.cells['id']?.value,
      idContabilConta: row.cells['idContabilConta']?.value,
      ano: row.cells['ano']?.value,
      janeiro: row.cells['janeiro']?.value,
      fevereiro: row.cells['fevereiro']?.value,
      marco: row.cells['marco']?.value,
      abril: row.cells['abril']?.value,
      maio: row.cells['maio']?.value,
      junho: row.cells['junho']?.value,
      julho: row.cells['julho']?.value,
      agosto: row.cells['agosto']?.value,
      setembro: row.cells['setembro']?.value,
      outubro: row.cells['outubro']?.value,
      novembro: row.cells['novembro']?.value,
      dezembro: row.cells['dezembro']?.value,
    );
  }

  PlutoRow toPlutoRow() {
    return PlutoRow(
      cells: {
        'tempId': PlutoCell(value: tempId),
        'id': PlutoCell(value: id ?? 0),
        'idContabilConta': PlutoCell(value: idContabilConta ?? 0),
        'ano': PlutoCell(value: ano ?? ''),
        'janeiro': PlutoCell(value: janeiro ?? 0.0),
        'fevereiro': PlutoCell(value: fevereiro ?? 0.0),
        'marco': PlutoCell(value: marco ?? 0.0),
        'abril': PlutoCell(value: abril ?? 0.0),
        'maio': PlutoCell(value: maio ?? 0.0),
        'junho': PlutoCell(value: junho ?? 0.0),
        'julho': PlutoCell(value: julho ?? 0.0),
        'agosto': PlutoCell(value: agosto ?? 0.0),
        'setembro': PlutoCell(value: setembro ?? 0.0),
        'outubro': PlutoCell(value: outubro ?? 0.0),
        'novembro': PlutoCell(value: novembro ?? 0.0),
        'dezembro': PlutoCell(value: dezembro ?? 0.0),
        'contabilConta': PlutoCell(value: contabilContaModel?.descricao ?? ''),
      },
    );
  }

  ContabilLancamentoOrcadoModel clone() {
    return ContabilLancamentoOrcadoModel(
      id: id,
      idContabilConta: idContabilConta,
      ano: ano,
      janeiro: janeiro,
      fevereiro: fevereiro,
      marco: marco,
      abril: abril,
      maio: maio,
      junho: junho,
      julho: julho,
      agosto: agosto,
      setembro: setembro,
      outubro: outubro,
      novembro: novembro,
      dezembro: dezembro,
      contabilContaModel: contabilContaModel?.clone(),
    );
  }


}