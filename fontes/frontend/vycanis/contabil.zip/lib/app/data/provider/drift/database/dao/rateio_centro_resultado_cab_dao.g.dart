// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'rateio_centro_resultado_cab_dao.dart';

// ignore_for_file: type=lint
mixin _$RateioCentroResultadoCabDaoMixin on DatabaseAccessor<AppDatabase> {
  $RateioCentroResultadoCabsTable get rateioCentroResultadoCabs =>
      attachedDatabase.rateioCentroResultadoCabs;
  $RateioCentroResultadoDetsTable get rateioCentroResultadoDets =>
      attachedDatabase.rateioCentroResultadoDets;
  $CentroResultadosTable get centroResultados =>
      attachedDatabase.centroResultados;
}
