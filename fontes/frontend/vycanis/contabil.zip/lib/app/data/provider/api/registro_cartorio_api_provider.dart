import 'package:contabil/app/data/provider/api/api_provider_base.dart';
import 'package:contabil/app/data/model/model_imports.dart';

class RegistroCartorioApiProvider extends ApiProviderBase {
  static const _path = '/registro-cartorio';

  Future<List<RegistroCartorioModel>?> getList({Filter? filter}) {
    return super.getListBase(
      '$_path/',
      (json) => RegistroCartorioModel.fromJson(json),
      filter: filter,
    );
  }

  Future<RegistroCartorioModel?> getObject(dynamic pk) {
    return super.getObjectBase(
      _path,
      pk,
      (json) => RegistroCartorioModel.fromJson(json),
    );
  }

  Future<RegistroCartorioModel?>? insert(RegistroCartorioModel model) {
    return super.insertBase(
      _path,
      model,
      (json) => RegistroCartorioModel.fromJson(json),
    );
  }

  Future<RegistroCartorioModel?>? update(RegistroCartorioModel model) {
    return super.updateBase(
      _path,
      model,
      (json) => RegistroCartorioModel.fromJson(json),
    );
  }

  Future<bool?> delete(dynamic pk) {
    return super.deleteBase(_path, pk);
  }
}
