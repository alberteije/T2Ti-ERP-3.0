// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'contabil_livro_dao.dart';

// ignore_for_file: type=lint
mixin _$ContabilLivroDaoMixin on DatabaseAccessor<AppDatabase> {
  $ContabilLivrosTable get contabilLivros => attachedDatabase.contabilLivros;
  $ContabilTermosTable get contabilTermos => attachedDatabase.contabilTermos;
}
