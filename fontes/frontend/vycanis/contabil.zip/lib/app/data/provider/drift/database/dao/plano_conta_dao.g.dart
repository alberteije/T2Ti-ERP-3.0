// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'plano_conta_dao.dart';

// ignore_for_file: type=lint
mixin _$PlanoContaDaoMixin on DatabaseAccessor<AppDatabase> {
  $PlanoContasTable get planoContas => attachedDatabase.planoContas;
}
