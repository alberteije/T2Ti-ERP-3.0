import 'package:contabil/app/data/provider/api/api_provider_base.dart';
import 'package:contabil/app/data/model/model_imports.dart';

class PlanoContaRefSpedApiProvider extends ApiProviderBase {
  static const _path = '/plano-conta-ref-sped';

  Future<List<PlanoContaRefSpedModel>?> getList({Filter? filter}) {
    return super.getListBase(
      '$_path/',
      (json) => PlanoContaRefSpedModel.fromJson(json),
      filter: filter,
    );
  }

  Future<PlanoContaRefSpedModel?> getObject(dynamic pk) {
    return super.getObjectBase(
      _path,
      pk,
      (json) => PlanoContaRefSpedModel.fromJson(json),
    );
  }

  Future<PlanoContaRefSpedModel?>? insert(PlanoContaRefSpedModel model) {
    return super.insertBase(
      _path,
      model,
      (json) => PlanoContaRefSpedModel.fromJson(json),
    );
  }

  Future<PlanoContaRefSpedModel?>? update(PlanoContaRefSpedModel model) {
    return super.updateBase(
      _path,
      model,
      (json) => PlanoContaRefSpedModel.fromJson(json),
    );
  }

  Future<bool?> delete(dynamic pk) {
    return super.deleteBase(_path, pk);
  }
}
