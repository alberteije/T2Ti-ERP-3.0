import 'package:contabil/app/data/provider/api/api_provider_base.dart';
import 'package:contabil/app/data/model/model_imports.dart';

class ContabilLoteApiProvider extends ApiProviderBase {
  static const _path = '/contabil-lote';

  Future<List<ContabilLoteModel>?> getList({Filter? filter}) {
    return super.getListBase(
      '$_path/',
      (json) => ContabilLoteModel.fromJson(json),
      filter: filter,
    );
  }

  Future<ContabilLoteModel?> getObject(dynamic pk) {
    return super.getObjectBase(
      _path,
      pk,
      (json) => ContabilLoteModel.fromJson(json),
    );
  }

  Future<ContabilLoteModel?>? insert(ContabilLoteModel model) {
    return super.insertBase(
      _path,
      model,
      (json) => ContabilLoteModel.fromJson(json),
    );
  }

  Future<ContabilLoteModel?>? update(ContabilLoteModel model) {
    return super.updateBase(
      _path,
      model,
      (json) => ContabilLoteModel.fromJson(json),
    );
  }

  Future<bool?> delete(dynamic pk) {
    return super.deleteBase(_path, pk);
  }
}
