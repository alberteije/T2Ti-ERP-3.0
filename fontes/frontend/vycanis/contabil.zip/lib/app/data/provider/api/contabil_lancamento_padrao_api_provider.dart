import 'package:contabil/app/data/provider/api/api_provider_base.dart';
import 'package:contabil/app/data/model/model_imports.dart';

class ContabilLancamentoPadraoApiProvider extends ApiProviderBase {
  static const _path = '/contabil-lancamento-padrao';

  Future<List<ContabilLancamentoPadraoModel>?> getList({Filter? filter}) {
    return super.getListBase(
      '$_path/',
      (json) => ContabilLancamentoPadraoModel.fromJson(json),
      filter: filter,
    );
  }

  Future<ContabilLancamentoPadraoModel?> getObject(dynamic pk) {
    return super.getObjectBase(
      _path,
      pk,
      (json) => ContabilLancamentoPadraoModel.fromJson(json),
    );
  }

  Future<ContabilLancamentoPadraoModel?>? insert(ContabilLancamentoPadraoModel model) {
    return super.insertBase(
      _path,
      model,
      (json) => ContabilLancamentoPadraoModel.fromJson(json),
    );
  }

  Future<ContabilLancamentoPadraoModel?>? update(ContabilLancamentoPadraoModel model) {
    return super.updateBase(
      _path,
      model,
      (json) => ContabilLancamentoPadraoModel.fromJson(json),
    );
  }

  Future<bool?> delete(dynamic pk) {
    return super.deleteBase(_path, pk);
  }
}
