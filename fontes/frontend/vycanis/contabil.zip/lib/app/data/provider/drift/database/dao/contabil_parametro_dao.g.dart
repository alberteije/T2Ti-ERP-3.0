// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'contabil_parametro_dao.dart';

// ignore_for_file: type=lint
mixin _$ContabilParametroDaoMixin on DatabaseAccessor<AppDatabase> {
  $ContabilParametrosTable get contabilParametros =>
      attachedDatabase.contabilParametros;
}
