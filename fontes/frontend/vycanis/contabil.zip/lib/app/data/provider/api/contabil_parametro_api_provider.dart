import 'package:contabil/app/data/provider/api/api_provider_base.dart';
import 'package:contabil/app/data/model/model_imports.dart';

class ContabilParametroApiProvider extends ApiProviderBase {
  static const _path = '/contabil-parametro';

  Future<List<ContabilParametroModel>?> getList({Filter? filter}) {
    return super.getListBase(
      '$_path/',
      (json) => ContabilParametroModel.fromJson(json),
      filter: filter,
    );
  }

  Future<ContabilParametroModel?> getObject(dynamic pk) {
    return super.getObjectBase(
      _path,
      pk,
      (json) => ContabilParametroModel.fromJson(json),
    );
  }

  Future<ContabilParametroModel?>? insert(ContabilParametroModel model) {
    return super.insertBase(
      _path,
      model,
      (json) => ContabilParametroModel.fromJson(json),
    );
  }

  Future<ContabilParametroModel?>? update(ContabilParametroModel model) {
    return super.updateBase(
      _path,
      model,
      (json) => ContabilParametroModel.fromJson(json),
    );
  }

  Future<bool?> delete(dynamic pk) {
    return super.deleteBase(_path, pk);
  }
}
