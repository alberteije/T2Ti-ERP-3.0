// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'contabil_fechamento_dao.dart';

// ignore_for_file: type=lint
mixin _$ContabilFechamentoDaoMixin on DatabaseAccessor<AppDatabase> {
  $ContabilFechamentosTable get contabilFechamentos =>
      attachedDatabase.contabilFechamentos;
}
