import 'package:contabil/app/data/provider/api/api_provider_base.dart';
import 'package:contabil/app/data/model/model_imports.dart';

class PlanoCentroResultadoApiProvider extends ApiProviderBase {
  static const _path = '/plano-centro-resultado';

  Future<List<PlanoCentroResultadoModel>?> getList({Filter? filter}) {
    return super.getListBase(
      '$_path/',
      (json) => PlanoCentroResultadoModel.fromJson(json),
      filter: filter,
    );
  }

  Future<PlanoCentroResultadoModel?> getObject(dynamic pk) {
    return super.getObjectBase(
      _path,
      pk,
      (json) => PlanoCentroResultadoModel.fromJson(json),
    );
  }

  Future<PlanoCentroResultadoModel?>? insert(PlanoCentroResultadoModel model) {
    return super.insertBase(
      _path,
      model,
      (json) => PlanoCentroResultadoModel.fromJson(json),
    );
  }

  Future<PlanoCentroResultadoModel?>? update(PlanoCentroResultadoModel model) {
    return super.updateBase(
      _path,
      model,
      (json) => PlanoCentroResultadoModel.fromJson(json),
    );
  }

  Future<bool?> delete(dynamic pk) {
    return super.deleteBase(_path, pk);
  }
}
