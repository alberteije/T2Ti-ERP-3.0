// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'contabil_dre_cabecalho_dao.dart';

// ignore_for_file: type=lint
mixin _$ContabilDreCabecalhoDaoMixin on DatabaseAccessor<AppDatabase> {
  $ContabilDreCabecalhosTable get contabilDreCabecalhos =>
      attachedDatabase.contabilDreCabecalhos;
  $ContabilDreDetalhesTable get contabilDreDetalhes =>
      attachedDatabase.contabilDreDetalhes;
}
