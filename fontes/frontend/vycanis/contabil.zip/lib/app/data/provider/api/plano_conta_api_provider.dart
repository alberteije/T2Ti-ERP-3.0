import 'package:contabil/app/data/provider/api/api_provider_base.dart';
import 'package:contabil/app/data/model/model_imports.dart';

class PlanoContaApiProvider extends ApiProviderBase {
  static const _path = '/plano-conta';

  Future<List<PlanoContaModel>?> getList({Filter? filter}) {
    return super.getListBase(
      '$_path/',
      (json) => PlanoContaModel.fromJson(json),
      filter: filter,
    );
  }

  Future<PlanoContaModel?> getObject(dynamic pk) {
    return super.getObjectBase(
      _path,
      pk,
      (json) => PlanoContaModel.fromJson(json),
    );
  }

  Future<PlanoContaModel?>? insert(PlanoContaModel model) {
    return super.insertBase(
      _path,
      model,
      (json) => PlanoContaModel.fromJson(json),
    );
  }

  Future<PlanoContaModel?>? update(PlanoContaModel model) {
    return super.updateBase(
      _path,
      model,
      (json) => PlanoContaModel.fromJson(json),
    );
  }

  Future<bool?> delete(dynamic pk) {
    return super.deleteBase(_path, pk);
  }
}
