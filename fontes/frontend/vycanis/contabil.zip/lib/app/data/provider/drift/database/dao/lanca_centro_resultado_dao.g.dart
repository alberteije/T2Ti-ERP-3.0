// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'lanca_centro_resultado_dao.dart';

// ignore_for_file: type=lint
mixin _$LancaCentroResultadoDaoMixin on DatabaseAccessor<AppDatabase> {
  $LancaCentroResultadosTable get lancaCentroResultados =>
      attachedDatabase.lancaCentroResultados;
  $CentroResultadosTable get centroResultados =>
      attachedDatabase.centroResultados;
}
