// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'contabil_conta_rateio_dao.dart';

// ignore_for_file: type=lint
mixin _$ContabilContaRateioDaoMixin on DatabaseAccessor<AppDatabase> {
  $ContabilContaRateiosTable get contabilContaRateios =>
      attachedDatabase.contabilContaRateios;
  $ContabilContasTable get contabilContas => attachedDatabase.contabilContas;
  $CentroResultadosTable get centroResultados =>
      attachedDatabase.centroResultados;
}
