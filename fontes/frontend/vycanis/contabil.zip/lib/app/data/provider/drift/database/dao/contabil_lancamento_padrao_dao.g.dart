// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'contabil_lancamento_padrao_dao.dart';

// ignore_for_file: type=lint
mixin _$ContabilLancamentoPadraoDaoMixin on DatabaseAccessor<AppDatabase> {
  $ContabilLancamentoPadraosTable get contabilLancamentoPadraos =>
      attachedDatabase.contabilLancamentoPadraos;
}
