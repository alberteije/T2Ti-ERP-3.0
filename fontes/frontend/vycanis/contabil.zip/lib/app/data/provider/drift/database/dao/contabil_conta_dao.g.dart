// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'contabil_conta_dao.dart';

// ignore_for_file: type=lint
mixin _$ContabilContaDaoMixin on DatabaseAccessor<AppDatabase> {
  $ContabilContasTable get contabilContas => attachedDatabase.contabilContas;
  $PlanoContasTable get planoContas => attachedDatabase.planoContas;
  $PlanoContaRefSpedsTable get planoContaRefSpeds =>
      attachedDatabase.planoContaRefSpeds;
}
