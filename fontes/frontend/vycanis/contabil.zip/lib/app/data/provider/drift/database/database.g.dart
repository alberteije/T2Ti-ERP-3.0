// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'database.dart';

// ignore_for_file: type=lint
class $ContabilLancamentoDetalhesTable extends ContabilLancamentoDetalhes
    with
        TableInfo<$ContabilLancamentoDetalhesTable, ContabilLancamentoDetalhe> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $ContabilLancamentoDetalhesTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
      'id', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _idContabilLancamentoCabMeta =
      const VerificationMeta('idContabilLancamentoCab');
  @override
  late final GeneratedColumn<int> idContabilLancamentoCab =
      GeneratedColumn<int>('id_contabil_lancamento_cab', aliasedName, true,
          type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _idContabilContaMeta =
      const VerificationMeta('idContabilConta');
  @override
  late final GeneratedColumn<int> idContabilConta = GeneratedColumn<int>(
      'id_contabil_conta', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _idContabilHistoricoMeta =
      const VerificationMeta('idContabilHistorico');
  @override
  late final GeneratedColumn<int> idContabilHistorico = GeneratedColumn<int>(
      'id_contabil_historico', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _tipoMeta = const VerificationMeta('tipo');
  @override
  late final GeneratedColumn<String> tipo = GeneratedColumn<String>(
      'tipo', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 1),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _valorMeta = const VerificationMeta('valor');
  @override
  late final GeneratedColumn<double> valor = GeneratedColumn<double>(
      'valor', aliasedName, true,
      type: DriftSqlType.double, requiredDuringInsert: false);
  static const VerificationMeta _historicoMeta =
      const VerificationMeta('historico');
  @override
  late final GeneratedColumn<String> historico = GeneratedColumn<String>(
      'historico', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 250),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  @override
  List<GeneratedColumn> get $columns => [
        id,
        idContabilLancamentoCab,
        idContabilConta,
        idContabilHistorico,
        tipo,
        valor,
        historico
      ];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'contabil_lancamento_detalhe';
  @override
  VerificationContext validateIntegrity(
      Insertable<ContabilLancamentoDetalhe> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('id_contabil_lancamento_cab')) {
      context.handle(
          _idContabilLancamentoCabMeta,
          idContabilLancamentoCab.isAcceptableOrUnknown(
              data['id_contabil_lancamento_cab']!,
              _idContabilLancamentoCabMeta));
    }
    if (data.containsKey('id_contabil_conta')) {
      context.handle(
          _idContabilContaMeta,
          idContabilConta.isAcceptableOrUnknown(
              data['id_contabil_conta']!, _idContabilContaMeta));
    }
    if (data.containsKey('id_contabil_historico')) {
      context.handle(
          _idContabilHistoricoMeta,
          idContabilHistorico.isAcceptableOrUnknown(
              data['id_contabil_historico']!, _idContabilHistoricoMeta));
    }
    if (data.containsKey('tipo')) {
      context.handle(
          _tipoMeta, tipo.isAcceptableOrUnknown(data['tipo']!, _tipoMeta));
    }
    if (data.containsKey('valor')) {
      context.handle(
          _valorMeta, valor.isAcceptableOrUnknown(data['valor']!, _valorMeta));
    }
    if (data.containsKey('historico')) {
      context.handle(_historicoMeta,
          historico.isAcceptableOrUnknown(data['historico']!, _historicoMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  ContabilLancamentoDetalhe map(Map<String, dynamic> data,
      {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return ContabilLancamentoDetalhe(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id']),
      idContabilLancamentoCab: attachedDatabase.typeMapping.read(
          DriftSqlType.int,
          data['${effectivePrefix}id_contabil_lancamento_cab']),
      idContabilConta: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id_contabil_conta']),
      idContabilHistorico: attachedDatabase.typeMapping.read(
          DriftSqlType.int, data['${effectivePrefix}id_contabil_historico']),
      tipo: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}tipo']),
      valor: attachedDatabase.typeMapping
          .read(DriftSqlType.double, data['${effectivePrefix}valor']),
      historico: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}historico']),
    );
  }

  @override
  $ContabilLancamentoDetalhesTable createAlias(String alias) {
    return $ContabilLancamentoDetalhesTable(attachedDatabase, alias);
  }
}

class ContabilLancamentoDetalhe extends DataClass
    implements Insertable<ContabilLancamentoDetalhe> {
  final int? id;
  final int? idContabilLancamentoCab;
  final int? idContabilConta;
  final int? idContabilHistorico;
  final String? tipo;
  final double? valor;
  final String? historico;
  const ContabilLancamentoDetalhe(
      {this.id,
      this.idContabilLancamentoCab,
      this.idContabilConta,
      this.idContabilHistorico,
      this.tipo,
      this.valor,
      this.historico});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || idContabilLancamentoCab != null) {
      map['id_contabil_lancamento_cab'] =
          Variable<int>(idContabilLancamentoCab);
    }
    if (!nullToAbsent || idContabilConta != null) {
      map['id_contabil_conta'] = Variable<int>(idContabilConta);
    }
    if (!nullToAbsent || idContabilHistorico != null) {
      map['id_contabil_historico'] = Variable<int>(idContabilHistorico);
    }
    if (!nullToAbsent || tipo != null) {
      map['tipo'] = Variable<String>(tipo);
    }
    if (!nullToAbsent || valor != null) {
      map['valor'] = Variable<double>(valor);
    }
    if (!nullToAbsent || historico != null) {
      map['historico'] = Variable<String>(historico);
    }
    return map;
  }

  factory ContabilLancamentoDetalhe.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return ContabilLancamentoDetalhe(
      id: serializer.fromJson<int?>(json['id']),
      idContabilLancamentoCab:
          serializer.fromJson<int?>(json['idContabilLancamentoCab']),
      idContabilConta: serializer.fromJson<int?>(json['idContabilConta']),
      idContabilHistorico:
          serializer.fromJson<int?>(json['idContabilHistorico']),
      tipo: serializer.fromJson<String?>(json['tipo']),
      valor: serializer.fromJson<double?>(json['valor']),
      historico: serializer.fromJson<String?>(json['historico']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'idContabilLancamentoCab':
          serializer.toJson<int?>(idContabilLancamentoCab),
      'idContabilConta': serializer.toJson<int?>(idContabilConta),
      'idContabilHistorico': serializer.toJson<int?>(idContabilHistorico),
      'tipo': serializer.toJson<String?>(tipo),
      'valor': serializer.toJson<double?>(valor),
      'historico': serializer.toJson<String?>(historico),
    };
  }

  ContabilLancamentoDetalhe copyWith(
          {Value<int?> id = const Value.absent(),
          Value<int?> idContabilLancamentoCab = const Value.absent(),
          Value<int?> idContabilConta = const Value.absent(),
          Value<int?> idContabilHistorico = const Value.absent(),
          Value<String?> tipo = const Value.absent(),
          Value<double?> valor = const Value.absent(),
          Value<String?> historico = const Value.absent()}) =>
      ContabilLancamentoDetalhe(
        id: id.present ? id.value : this.id,
        idContabilLancamentoCab: idContabilLancamentoCab.present
            ? idContabilLancamentoCab.value
            : this.idContabilLancamentoCab,
        idContabilConta: idContabilConta.present
            ? idContabilConta.value
            : this.idContabilConta,
        idContabilHistorico: idContabilHistorico.present
            ? idContabilHistorico.value
            : this.idContabilHistorico,
        tipo: tipo.present ? tipo.value : this.tipo,
        valor: valor.present ? valor.value : this.valor,
        historico: historico.present ? historico.value : this.historico,
      );
  ContabilLancamentoDetalhe copyWithCompanion(
      ContabilLancamentoDetalhesCompanion data) {
    return ContabilLancamentoDetalhe(
      id: data.id.present ? data.id.value : this.id,
      idContabilLancamentoCab: data.idContabilLancamentoCab.present
          ? data.idContabilLancamentoCab.value
          : this.idContabilLancamentoCab,
      idContabilConta: data.idContabilConta.present
          ? data.idContabilConta.value
          : this.idContabilConta,
      idContabilHistorico: data.idContabilHistorico.present
          ? data.idContabilHistorico.value
          : this.idContabilHistorico,
      tipo: data.tipo.present ? data.tipo.value : this.tipo,
      valor: data.valor.present ? data.valor.value : this.valor,
      historico: data.historico.present ? data.historico.value : this.historico,
    );
  }

  @override
  String toString() {
    return (StringBuffer('ContabilLancamentoDetalhe(')
          ..write('id: $id, ')
          ..write('idContabilLancamentoCab: $idContabilLancamentoCab, ')
          ..write('idContabilConta: $idContabilConta, ')
          ..write('idContabilHistorico: $idContabilHistorico, ')
          ..write('tipo: $tipo, ')
          ..write('valor: $valor, ')
          ..write('historico: $historico')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(id, idContabilLancamentoCab, idContabilConta,
      idContabilHistorico, tipo, valor, historico);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is ContabilLancamentoDetalhe &&
          other.id == this.id &&
          other.idContabilLancamentoCab == this.idContabilLancamentoCab &&
          other.idContabilConta == this.idContabilConta &&
          other.idContabilHistorico == this.idContabilHistorico &&
          other.tipo == this.tipo &&
          other.valor == this.valor &&
          other.historico == this.historico);
}

class ContabilLancamentoDetalhesCompanion
    extends UpdateCompanion<ContabilLancamentoDetalhe> {
  final Value<int?> id;
  final Value<int?> idContabilLancamentoCab;
  final Value<int?> idContabilConta;
  final Value<int?> idContabilHistorico;
  final Value<String?> tipo;
  final Value<double?> valor;
  final Value<String?> historico;
  const ContabilLancamentoDetalhesCompanion({
    this.id = const Value.absent(),
    this.idContabilLancamentoCab = const Value.absent(),
    this.idContabilConta = const Value.absent(),
    this.idContabilHistorico = const Value.absent(),
    this.tipo = const Value.absent(),
    this.valor = const Value.absent(),
    this.historico = const Value.absent(),
  });
  ContabilLancamentoDetalhesCompanion.insert({
    this.id = const Value.absent(),
    this.idContabilLancamentoCab = const Value.absent(),
    this.idContabilConta = const Value.absent(),
    this.idContabilHistorico = const Value.absent(),
    this.tipo = const Value.absent(),
    this.valor = const Value.absent(),
    this.historico = const Value.absent(),
  });
  static Insertable<ContabilLancamentoDetalhe> custom({
    Expression<int>? id,
    Expression<int>? idContabilLancamentoCab,
    Expression<int>? idContabilConta,
    Expression<int>? idContabilHistorico,
    Expression<String>? tipo,
    Expression<double>? valor,
    Expression<String>? historico,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (idContabilLancamentoCab != null)
        'id_contabil_lancamento_cab': idContabilLancamentoCab,
      if (idContabilConta != null) 'id_contabil_conta': idContabilConta,
      if (idContabilHistorico != null)
        'id_contabil_historico': idContabilHistorico,
      if (tipo != null) 'tipo': tipo,
      if (valor != null) 'valor': valor,
      if (historico != null) 'historico': historico,
    });
  }

  ContabilLancamentoDetalhesCompanion copyWith(
      {Value<int?>? id,
      Value<int?>? idContabilLancamentoCab,
      Value<int?>? idContabilConta,
      Value<int?>? idContabilHistorico,
      Value<String?>? tipo,
      Value<double?>? valor,
      Value<String?>? historico}) {
    return ContabilLancamentoDetalhesCompanion(
      id: id ?? this.id,
      idContabilLancamentoCab:
          idContabilLancamentoCab ?? this.idContabilLancamentoCab,
      idContabilConta: idContabilConta ?? this.idContabilConta,
      idContabilHistorico: idContabilHistorico ?? this.idContabilHistorico,
      tipo: tipo ?? this.tipo,
      valor: valor ?? this.valor,
      historico: historico ?? this.historico,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (idContabilLancamentoCab.present) {
      map['id_contabil_lancamento_cab'] =
          Variable<int>(idContabilLancamentoCab.value);
    }
    if (idContabilConta.present) {
      map['id_contabil_conta'] = Variable<int>(idContabilConta.value);
    }
    if (idContabilHistorico.present) {
      map['id_contabil_historico'] = Variable<int>(idContabilHistorico.value);
    }
    if (tipo.present) {
      map['tipo'] = Variable<String>(tipo.value);
    }
    if (valor.present) {
      map['valor'] = Variable<double>(valor.value);
    }
    if (historico.present) {
      map['historico'] = Variable<String>(historico.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('ContabilLancamentoDetalhesCompanion(')
          ..write('id: $id, ')
          ..write('idContabilLancamentoCab: $idContabilLancamentoCab, ')
          ..write('idContabilConta: $idContabilConta, ')
          ..write('idContabilHistorico: $idContabilHistorico, ')
          ..write('tipo: $tipo, ')
          ..write('valor: $valor, ')
          ..write('historico: $historico')
          ..write(')'))
        .toString();
  }
}

class $ContabilDreDetalhesTable extends ContabilDreDetalhes
    with TableInfo<$ContabilDreDetalhesTable, ContabilDreDetalhe> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $ContabilDreDetalhesTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
      'id', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _idContabilDreCabecalhoMeta =
      const VerificationMeta('idContabilDreCabecalho');
  @override
  late final GeneratedColumn<int> idContabilDreCabecalho = GeneratedColumn<int>(
      'id_contabil_dre_cabecalho', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _classificacaoMeta =
      const VerificationMeta('classificacao');
  @override
  late final GeneratedColumn<String> classificacao = GeneratedColumn<String>(
      'classificacao', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 30),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _descricaoMeta =
      const VerificationMeta('descricao');
  @override
  late final GeneratedColumn<String> descricao = GeneratedColumn<String>(
      'descricao', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 100),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _formaCalculoMeta =
      const VerificationMeta('formaCalculo');
  @override
  late final GeneratedColumn<String> formaCalculo = GeneratedColumn<String>(
      'forma_calculo', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 1),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _sinalMeta = const VerificationMeta('sinal');
  @override
  late final GeneratedColumn<String> sinal = GeneratedColumn<String>(
      'sinal', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 1),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _naturezaMeta =
      const VerificationMeta('natureza');
  @override
  late final GeneratedColumn<String> natureza = GeneratedColumn<String>(
      'natureza', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 1),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _valorMeta = const VerificationMeta('valor');
  @override
  late final GeneratedColumn<double> valor = GeneratedColumn<double>(
      'valor', aliasedName, true,
      type: DriftSqlType.double, requiredDuringInsert: false);
  @override
  List<GeneratedColumn> get $columns => [
        id,
        idContabilDreCabecalho,
        classificacao,
        descricao,
        formaCalculo,
        sinal,
        natureza,
        valor
      ];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'contabil_dre_detalhe';
  @override
  VerificationContext validateIntegrity(Insertable<ContabilDreDetalhe> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('id_contabil_dre_cabecalho')) {
      context.handle(
          _idContabilDreCabecalhoMeta,
          idContabilDreCabecalho.isAcceptableOrUnknown(
              data['id_contabil_dre_cabecalho']!, _idContabilDreCabecalhoMeta));
    }
    if (data.containsKey('classificacao')) {
      context.handle(
          _classificacaoMeta,
          classificacao.isAcceptableOrUnknown(
              data['classificacao']!, _classificacaoMeta));
    }
    if (data.containsKey('descricao')) {
      context.handle(_descricaoMeta,
          descricao.isAcceptableOrUnknown(data['descricao']!, _descricaoMeta));
    }
    if (data.containsKey('forma_calculo')) {
      context.handle(
          _formaCalculoMeta,
          formaCalculo.isAcceptableOrUnknown(
              data['forma_calculo']!, _formaCalculoMeta));
    }
    if (data.containsKey('sinal')) {
      context.handle(
          _sinalMeta, sinal.isAcceptableOrUnknown(data['sinal']!, _sinalMeta));
    }
    if (data.containsKey('natureza')) {
      context.handle(_naturezaMeta,
          natureza.isAcceptableOrUnknown(data['natureza']!, _naturezaMeta));
    }
    if (data.containsKey('valor')) {
      context.handle(
          _valorMeta, valor.isAcceptableOrUnknown(data['valor']!, _valorMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  ContabilDreDetalhe map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return ContabilDreDetalhe(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id']),
      idContabilDreCabecalho: attachedDatabase.typeMapping.read(
          DriftSqlType.int,
          data['${effectivePrefix}id_contabil_dre_cabecalho']),
      classificacao: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}classificacao']),
      descricao: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}descricao']),
      formaCalculo: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}forma_calculo']),
      sinal: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}sinal']),
      natureza: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}natureza']),
      valor: attachedDatabase.typeMapping
          .read(DriftSqlType.double, data['${effectivePrefix}valor']),
    );
  }

  @override
  $ContabilDreDetalhesTable createAlias(String alias) {
    return $ContabilDreDetalhesTable(attachedDatabase, alias);
  }
}

class ContabilDreDetalhe extends DataClass
    implements Insertable<ContabilDreDetalhe> {
  final int? id;
  final int? idContabilDreCabecalho;
  final String? classificacao;
  final String? descricao;
  final String? formaCalculo;
  final String? sinal;
  final String? natureza;
  final double? valor;
  const ContabilDreDetalhe(
      {this.id,
      this.idContabilDreCabecalho,
      this.classificacao,
      this.descricao,
      this.formaCalculo,
      this.sinal,
      this.natureza,
      this.valor});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || idContabilDreCabecalho != null) {
      map['id_contabil_dre_cabecalho'] = Variable<int>(idContabilDreCabecalho);
    }
    if (!nullToAbsent || classificacao != null) {
      map['classificacao'] = Variable<String>(classificacao);
    }
    if (!nullToAbsent || descricao != null) {
      map['descricao'] = Variable<String>(descricao);
    }
    if (!nullToAbsent || formaCalculo != null) {
      map['forma_calculo'] = Variable<String>(formaCalculo);
    }
    if (!nullToAbsent || sinal != null) {
      map['sinal'] = Variable<String>(sinal);
    }
    if (!nullToAbsent || natureza != null) {
      map['natureza'] = Variable<String>(natureza);
    }
    if (!nullToAbsent || valor != null) {
      map['valor'] = Variable<double>(valor);
    }
    return map;
  }

  factory ContabilDreDetalhe.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return ContabilDreDetalhe(
      id: serializer.fromJson<int?>(json['id']),
      idContabilDreCabecalho:
          serializer.fromJson<int?>(json['idContabilDreCabecalho']),
      classificacao: serializer.fromJson<String?>(json['classificacao']),
      descricao: serializer.fromJson<String?>(json['descricao']),
      formaCalculo: serializer.fromJson<String?>(json['formaCalculo']),
      sinal: serializer.fromJson<String?>(json['sinal']),
      natureza: serializer.fromJson<String?>(json['natureza']),
      valor: serializer.fromJson<double?>(json['valor']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'idContabilDreCabecalho': serializer.toJson<int?>(idContabilDreCabecalho),
      'classificacao': serializer.toJson<String?>(classificacao),
      'descricao': serializer.toJson<String?>(descricao),
      'formaCalculo': serializer.toJson<String?>(formaCalculo),
      'sinal': serializer.toJson<String?>(sinal),
      'natureza': serializer.toJson<String?>(natureza),
      'valor': serializer.toJson<double?>(valor),
    };
  }

  ContabilDreDetalhe copyWith(
          {Value<int?> id = const Value.absent(),
          Value<int?> idContabilDreCabecalho = const Value.absent(),
          Value<String?> classificacao = const Value.absent(),
          Value<String?> descricao = const Value.absent(),
          Value<String?> formaCalculo = const Value.absent(),
          Value<String?> sinal = const Value.absent(),
          Value<String?> natureza = const Value.absent(),
          Value<double?> valor = const Value.absent()}) =>
      ContabilDreDetalhe(
        id: id.present ? id.value : this.id,
        idContabilDreCabecalho: idContabilDreCabecalho.present
            ? idContabilDreCabecalho.value
            : this.idContabilDreCabecalho,
        classificacao:
            classificacao.present ? classificacao.value : this.classificacao,
        descricao: descricao.present ? descricao.value : this.descricao,
        formaCalculo:
            formaCalculo.present ? formaCalculo.value : this.formaCalculo,
        sinal: sinal.present ? sinal.value : this.sinal,
        natureza: natureza.present ? natureza.value : this.natureza,
        valor: valor.present ? valor.value : this.valor,
      );
  ContabilDreDetalhe copyWithCompanion(ContabilDreDetalhesCompanion data) {
    return ContabilDreDetalhe(
      id: data.id.present ? data.id.value : this.id,
      idContabilDreCabecalho: data.idContabilDreCabecalho.present
          ? data.idContabilDreCabecalho.value
          : this.idContabilDreCabecalho,
      classificacao: data.classificacao.present
          ? data.classificacao.value
          : this.classificacao,
      descricao: data.descricao.present ? data.descricao.value : this.descricao,
      formaCalculo: data.formaCalculo.present
          ? data.formaCalculo.value
          : this.formaCalculo,
      sinal: data.sinal.present ? data.sinal.value : this.sinal,
      natureza: data.natureza.present ? data.natureza.value : this.natureza,
      valor: data.valor.present ? data.valor.value : this.valor,
    );
  }

  @override
  String toString() {
    return (StringBuffer('ContabilDreDetalhe(')
          ..write('id: $id, ')
          ..write('idContabilDreCabecalho: $idContabilDreCabecalho, ')
          ..write('classificacao: $classificacao, ')
          ..write('descricao: $descricao, ')
          ..write('formaCalculo: $formaCalculo, ')
          ..write('sinal: $sinal, ')
          ..write('natureza: $natureza, ')
          ..write('valor: $valor')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(id, idContabilDreCabecalho, classificacao,
      descricao, formaCalculo, sinal, natureza, valor);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is ContabilDreDetalhe &&
          other.id == this.id &&
          other.idContabilDreCabecalho == this.idContabilDreCabecalho &&
          other.classificacao == this.classificacao &&
          other.descricao == this.descricao &&
          other.formaCalculo == this.formaCalculo &&
          other.sinal == this.sinal &&
          other.natureza == this.natureza &&
          other.valor == this.valor);
}

class ContabilDreDetalhesCompanion extends UpdateCompanion<ContabilDreDetalhe> {
  final Value<int?> id;
  final Value<int?> idContabilDreCabecalho;
  final Value<String?> classificacao;
  final Value<String?> descricao;
  final Value<String?> formaCalculo;
  final Value<String?> sinal;
  final Value<String?> natureza;
  final Value<double?> valor;
  const ContabilDreDetalhesCompanion({
    this.id = const Value.absent(),
    this.idContabilDreCabecalho = const Value.absent(),
    this.classificacao = const Value.absent(),
    this.descricao = const Value.absent(),
    this.formaCalculo = const Value.absent(),
    this.sinal = const Value.absent(),
    this.natureza = const Value.absent(),
    this.valor = const Value.absent(),
  });
  ContabilDreDetalhesCompanion.insert({
    this.id = const Value.absent(),
    this.idContabilDreCabecalho = const Value.absent(),
    this.classificacao = const Value.absent(),
    this.descricao = const Value.absent(),
    this.formaCalculo = const Value.absent(),
    this.sinal = const Value.absent(),
    this.natureza = const Value.absent(),
    this.valor = const Value.absent(),
  });
  static Insertable<ContabilDreDetalhe> custom({
    Expression<int>? id,
    Expression<int>? idContabilDreCabecalho,
    Expression<String>? classificacao,
    Expression<String>? descricao,
    Expression<String>? formaCalculo,
    Expression<String>? sinal,
    Expression<String>? natureza,
    Expression<double>? valor,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (idContabilDreCabecalho != null)
        'id_contabil_dre_cabecalho': idContabilDreCabecalho,
      if (classificacao != null) 'classificacao': classificacao,
      if (descricao != null) 'descricao': descricao,
      if (formaCalculo != null) 'forma_calculo': formaCalculo,
      if (sinal != null) 'sinal': sinal,
      if (natureza != null) 'natureza': natureza,
      if (valor != null) 'valor': valor,
    });
  }

  ContabilDreDetalhesCompanion copyWith(
      {Value<int?>? id,
      Value<int?>? idContabilDreCabecalho,
      Value<String?>? classificacao,
      Value<String?>? descricao,
      Value<String?>? formaCalculo,
      Value<String?>? sinal,
      Value<String?>? natureza,
      Value<double?>? valor}) {
    return ContabilDreDetalhesCompanion(
      id: id ?? this.id,
      idContabilDreCabecalho:
          idContabilDreCabecalho ?? this.idContabilDreCabecalho,
      classificacao: classificacao ?? this.classificacao,
      descricao: descricao ?? this.descricao,
      formaCalculo: formaCalculo ?? this.formaCalculo,
      sinal: sinal ?? this.sinal,
      natureza: natureza ?? this.natureza,
      valor: valor ?? this.valor,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (idContabilDreCabecalho.present) {
      map['id_contabil_dre_cabecalho'] =
          Variable<int>(idContabilDreCabecalho.value);
    }
    if (classificacao.present) {
      map['classificacao'] = Variable<String>(classificacao.value);
    }
    if (descricao.present) {
      map['descricao'] = Variable<String>(descricao.value);
    }
    if (formaCalculo.present) {
      map['forma_calculo'] = Variable<String>(formaCalculo.value);
    }
    if (sinal.present) {
      map['sinal'] = Variable<String>(sinal.value);
    }
    if (natureza.present) {
      map['natureza'] = Variable<String>(natureza.value);
    }
    if (valor.present) {
      map['valor'] = Variable<double>(valor.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('ContabilDreDetalhesCompanion(')
          ..write('id: $id, ')
          ..write('idContabilDreCabecalho: $idContabilDreCabecalho, ')
          ..write('classificacao: $classificacao, ')
          ..write('descricao: $descricao, ')
          ..write('formaCalculo: $formaCalculo, ')
          ..write('sinal: $sinal, ')
          ..write('natureza: $natureza, ')
          ..write('valor: $valor')
          ..write(')'))
        .toString();
  }
}

class $ContabilTermosTable extends ContabilTermos
    with TableInfo<$ContabilTermosTable, ContabilTermo> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $ContabilTermosTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
      'id', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _idContabilLivroMeta =
      const VerificationMeta('idContabilLivro');
  @override
  late final GeneratedColumn<int> idContabilLivro = GeneratedColumn<int>(
      'id_contabil_livro', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _aberturaEncerramentoMeta =
      const VerificationMeta('aberturaEncerramento');
  @override
  late final GeneratedColumn<String> aberturaEncerramento =
      GeneratedColumn<String>(
          'abertura_encerramento', aliasedName, true,
          additionalChecks: GeneratedColumn.checkTextLength(
              minTextLength: 0, maxTextLength: 1),
          type: DriftSqlType.string,
          requiredDuringInsert: false);
  static const VerificationMeta _numeroMeta = const VerificationMeta('numero');
  @override
  late final GeneratedColumn<int> numero = GeneratedColumn<int>(
      'numero', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _paginaInicialMeta =
      const VerificationMeta('paginaInicial');
  @override
  late final GeneratedColumn<int> paginaInicial = GeneratedColumn<int>(
      'pagina_inicial', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _paginaFinalMeta =
      const VerificationMeta('paginaFinal');
  @override
  late final GeneratedColumn<int> paginaFinal = GeneratedColumn<int>(
      'pagina_final', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _registradoMeta =
      const VerificationMeta('registrado');
  @override
  late final GeneratedColumn<String> registrado = GeneratedColumn<String>(
      'registrado', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 100),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _numeroRegistroMeta =
      const VerificationMeta('numeroRegistro');
  @override
  late final GeneratedColumn<String> numeroRegistro = GeneratedColumn<String>(
      'numero_registro', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 50),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _dataDespachoMeta =
      const VerificationMeta('dataDespacho');
  @override
  late final GeneratedColumn<DateTime> dataDespacho = GeneratedColumn<DateTime>(
      'data_despacho', aliasedName, true,
      type: DriftSqlType.dateTime, requiredDuringInsert: false);
  static const VerificationMeta _dataAberturaMeta =
      const VerificationMeta('dataAbertura');
  @override
  late final GeneratedColumn<DateTime> dataAbertura = GeneratedColumn<DateTime>(
      'data_abertura', aliasedName, true,
      type: DriftSqlType.dateTime, requiredDuringInsert: false);
  static const VerificationMeta _dataEncerramentoMeta =
      const VerificationMeta('dataEncerramento');
  @override
  late final GeneratedColumn<DateTime> dataEncerramento =
      GeneratedColumn<DateTime>('data_encerramento', aliasedName, true,
          type: DriftSqlType.dateTime, requiredDuringInsert: false);
  static const VerificationMeta _escrituracaoInicioMeta =
      const VerificationMeta('escrituracaoInicio');
  @override
  late final GeneratedColumn<DateTime> escrituracaoInicio =
      GeneratedColumn<DateTime>('escrituracao_inicio', aliasedName, true,
          type: DriftSqlType.dateTime, requiredDuringInsert: false);
  static const VerificationMeta _escrituracaoFimMeta =
      const VerificationMeta('escrituracaoFim');
  @override
  late final GeneratedColumn<DateTime> escrituracaoFim =
      GeneratedColumn<DateTime>('escrituracao_fim', aliasedName, true,
          type: DriftSqlType.dateTime, requiredDuringInsert: false);
  static const VerificationMeta _textoMeta = const VerificationMeta('texto');
  @override
  late final GeneratedColumn<String> texto = GeneratedColumn<String>(
      'texto', aliasedName, true,
      type: DriftSqlType.string, requiredDuringInsert: false);
  @override
  List<GeneratedColumn> get $columns => [
        id,
        idContabilLivro,
        aberturaEncerramento,
        numero,
        paginaInicial,
        paginaFinal,
        registrado,
        numeroRegistro,
        dataDespacho,
        dataAbertura,
        dataEncerramento,
        escrituracaoInicio,
        escrituracaoFim,
        texto
      ];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'contabil_termo';
  @override
  VerificationContext validateIntegrity(Insertable<ContabilTermo> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('id_contabil_livro')) {
      context.handle(
          _idContabilLivroMeta,
          idContabilLivro.isAcceptableOrUnknown(
              data['id_contabil_livro']!, _idContabilLivroMeta));
    }
    if (data.containsKey('abertura_encerramento')) {
      context.handle(
          _aberturaEncerramentoMeta,
          aberturaEncerramento.isAcceptableOrUnknown(
              data['abertura_encerramento']!, _aberturaEncerramentoMeta));
    }
    if (data.containsKey('numero')) {
      context.handle(_numeroMeta,
          numero.isAcceptableOrUnknown(data['numero']!, _numeroMeta));
    }
    if (data.containsKey('pagina_inicial')) {
      context.handle(
          _paginaInicialMeta,
          paginaInicial.isAcceptableOrUnknown(
              data['pagina_inicial']!, _paginaInicialMeta));
    }
    if (data.containsKey('pagina_final')) {
      context.handle(
          _paginaFinalMeta,
          paginaFinal.isAcceptableOrUnknown(
              data['pagina_final']!, _paginaFinalMeta));
    }
    if (data.containsKey('registrado')) {
      context.handle(
          _registradoMeta,
          registrado.isAcceptableOrUnknown(
              data['registrado']!, _registradoMeta));
    }
    if (data.containsKey('numero_registro')) {
      context.handle(
          _numeroRegistroMeta,
          numeroRegistro.isAcceptableOrUnknown(
              data['numero_registro']!, _numeroRegistroMeta));
    }
    if (data.containsKey('data_despacho')) {
      context.handle(
          _dataDespachoMeta,
          dataDespacho.isAcceptableOrUnknown(
              data['data_despacho']!, _dataDespachoMeta));
    }
    if (data.containsKey('data_abertura')) {
      context.handle(
          _dataAberturaMeta,
          dataAbertura.isAcceptableOrUnknown(
              data['data_abertura']!, _dataAberturaMeta));
    }
    if (data.containsKey('data_encerramento')) {
      context.handle(
          _dataEncerramentoMeta,
          dataEncerramento.isAcceptableOrUnknown(
              data['data_encerramento']!, _dataEncerramentoMeta));
    }
    if (data.containsKey('escrituracao_inicio')) {
      context.handle(
          _escrituracaoInicioMeta,
          escrituracaoInicio.isAcceptableOrUnknown(
              data['escrituracao_inicio']!, _escrituracaoInicioMeta));
    }
    if (data.containsKey('escrituracao_fim')) {
      context.handle(
          _escrituracaoFimMeta,
          escrituracaoFim.isAcceptableOrUnknown(
              data['escrituracao_fim']!, _escrituracaoFimMeta));
    }
    if (data.containsKey('texto')) {
      context.handle(
          _textoMeta, texto.isAcceptableOrUnknown(data['texto']!, _textoMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  ContabilTermo map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return ContabilTermo(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id']),
      idContabilLivro: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id_contabil_livro']),
      aberturaEncerramento: attachedDatabase.typeMapping.read(
          DriftSqlType.string, data['${effectivePrefix}abertura_encerramento']),
      numero: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}numero']),
      paginaInicial: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}pagina_inicial']),
      paginaFinal: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}pagina_final']),
      registrado: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}registrado']),
      numeroRegistro: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}numero_registro']),
      dataDespacho: attachedDatabase.typeMapping
          .read(DriftSqlType.dateTime, data['${effectivePrefix}data_despacho']),
      dataAbertura: attachedDatabase.typeMapping
          .read(DriftSqlType.dateTime, data['${effectivePrefix}data_abertura']),
      dataEncerramento: attachedDatabase.typeMapping.read(
          DriftSqlType.dateTime, data['${effectivePrefix}data_encerramento']),
      escrituracaoInicio: attachedDatabase.typeMapping.read(
          DriftSqlType.dateTime, data['${effectivePrefix}escrituracao_inicio']),
      escrituracaoFim: attachedDatabase.typeMapping.read(
          DriftSqlType.dateTime, data['${effectivePrefix}escrituracao_fim']),
      texto: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}texto']),
    );
  }

  @override
  $ContabilTermosTable createAlias(String alias) {
    return $ContabilTermosTable(attachedDatabase, alias);
  }
}

class ContabilTermo extends DataClass implements Insertable<ContabilTermo> {
  final int? id;
  final int? idContabilLivro;
  final String? aberturaEncerramento;
  final int? numero;
  final int? paginaInicial;
  final int? paginaFinal;
  final String? registrado;
  final String? numeroRegistro;
  final DateTime? dataDespacho;
  final DateTime? dataAbertura;
  final DateTime? dataEncerramento;
  final DateTime? escrituracaoInicio;
  final DateTime? escrituracaoFim;
  final String? texto;
  const ContabilTermo(
      {this.id,
      this.idContabilLivro,
      this.aberturaEncerramento,
      this.numero,
      this.paginaInicial,
      this.paginaFinal,
      this.registrado,
      this.numeroRegistro,
      this.dataDespacho,
      this.dataAbertura,
      this.dataEncerramento,
      this.escrituracaoInicio,
      this.escrituracaoFim,
      this.texto});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || idContabilLivro != null) {
      map['id_contabil_livro'] = Variable<int>(idContabilLivro);
    }
    if (!nullToAbsent || aberturaEncerramento != null) {
      map['abertura_encerramento'] = Variable<String>(aberturaEncerramento);
    }
    if (!nullToAbsent || numero != null) {
      map['numero'] = Variable<int>(numero);
    }
    if (!nullToAbsent || paginaInicial != null) {
      map['pagina_inicial'] = Variable<int>(paginaInicial);
    }
    if (!nullToAbsent || paginaFinal != null) {
      map['pagina_final'] = Variable<int>(paginaFinal);
    }
    if (!nullToAbsent || registrado != null) {
      map['registrado'] = Variable<String>(registrado);
    }
    if (!nullToAbsent || numeroRegistro != null) {
      map['numero_registro'] = Variable<String>(numeroRegistro);
    }
    if (!nullToAbsent || dataDespacho != null) {
      map['data_despacho'] = Variable<DateTime>(dataDespacho);
    }
    if (!nullToAbsent || dataAbertura != null) {
      map['data_abertura'] = Variable<DateTime>(dataAbertura);
    }
    if (!nullToAbsent || dataEncerramento != null) {
      map['data_encerramento'] = Variable<DateTime>(dataEncerramento);
    }
    if (!nullToAbsent || escrituracaoInicio != null) {
      map['escrituracao_inicio'] = Variable<DateTime>(escrituracaoInicio);
    }
    if (!nullToAbsent || escrituracaoFim != null) {
      map['escrituracao_fim'] = Variable<DateTime>(escrituracaoFim);
    }
    if (!nullToAbsent || texto != null) {
      map['texto'] = Variable<String>(texto);
    }
    return map;
  }

  factory ContabilTermo.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return ContabilTermo(
      id: serializer.fromJson<int?>(json['id']),
      idContabilLivro: serializer.fromJson<int?>(json['idContabilLivro']),
      aberturaEncerramento:
          serializer.fromJson<String?>(json['aberturaEncerramento']),
      numero: serializer.fromJson<int?>(json['numero']),
      paginaInicial: serializer.fromJson<int?>(json['paginaInicial']),
      paginaFinal: serializer.fromJson<int?>(json['paginaFinal']),
      registrado: serializer.fromJson<String?>(json['registrado']),
      numeroRegistro: serializer.fromJson<String?>(json['numeroRegistro']),
      dataDespacho: serializer.fromJson<DateTime?>(json['dataDespacho']),
      dataAbertura: serializer.fromJson<DateTime?>(json['dataAbertura']),
      dataEncerramento:
          serializer.fromJson<DateTime?>(json['dataEncerramento']),
      escrituracaoInicio:
          serializer.fromJson<DateTime?>(json['escrituracaoInicio']),
      escrituracaoFim: serializer.fromJson<DateTime?>(json['escrituracaoFim']),
      texto: serializer.fromJson<String?>(json['texto']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'idContabilLivro': serializer.toJson<int?>(idContabilLivro),
      'aberturaEncerramento': serializer.toJson<String?>(aberturaEncerramento),
      'numero': serializer.toJson<int?>(numero),
      'paginaInicial': serializer.toJson<int?>(paginaInicial),
      'paginaFinal': serializer.toJson<int?>(paginaFinal),
      'registrado': serializer.toJson<String?>(registrado),
      'numeroRegistro': serializer.toJson<String?>(numeroRegistro),
      'dataDespacho': serializer.toJson<DateTime?>(dataDespacho),
      'dataAbertura': serializer.toJson<DateTime?>(dataAbertura),
      'dataEncerramento': serializer.toJson<DateTime?>(dataEncerramento),
      'escrituracaoInicio': serializer.toJson<DateTime?>(escrituracaoInicio),
      'escrituracaoFim': serializer.toJson<DateTime?>(escrituracaoFim),
      'texto': serializer.toJson<String?>(texto),
    };
  }

  ContabilTermo copyWith(
          {Value<int?> id = const Value.absent(),
          Value<int?> idContabilLivro = const Value.absent(),
          Value<String?> aberturaEncerramento = const Value.absent(),
          Value<int?> numero = const Value.absent(),
          Value<int?> paginaInicial = const Value.absent(),
          Value<int?> paginaFinal = const Value.absent(),
          Value<String?> registrado = const Value.absent(),
          Value<String?> numeroRegistro = const Value.absent(),
          Value<DateTime?> dataDespacho = const Value.absent(),
          Value<DateTime?> dataAbertura = const Value.absent(),
          Value<DateTime?> dataEncerramento = const Value.absent(),
          Value<DateTime?> escrituracaoInicio = const Value.absent(),
          Value<DateTime?> escrituracaoFim = const Value.absent(),
          Value<String?> texto = const Value.absent()}) =>
      ContabilTermo(
        id: id.present ? id.value : this.id,
        idContabilLivro: idContabilLivro.present
            ? idContabilLivro.value
            : this.idContabilLivro,
        aberturaEncerramento: aberturaEncerramento.present
            ? aberturaEncerramento.value
            : this.aberturaEncerramento,
        numero: numero.present ? numero.value : this.numero,
        paginaInicial:
            paginaInicial.present ? paginaInicial.value : this.paginaInicial,
        paginaFinal: paginaFinal.present ? paginaFinal.value : this.paginaFinal,
        registrado: registrado.present ? registrado.value : this.registrado,
        numeroRegistro:
            numeroRegistro.present ? numeroRegistro.value : this.numeroRegistro,
        dataDespacho:
            dataDespacho.present ? dataDespacho.value : this.dataDespacho,
        dataAbertura:
            dataAbertura.present ? dataAbertura.value : this.dataAbertura,
        dataEncerramento: dataEncerramento.present
            ? dataEncerramento.value
            : this.dataEncerramento,
        escrituracaoInicio: escrituracaoInicio.present
            ? escrituracaoInicio.value
            : this.escrituracaoInicio,
        escrituracaoFim: escrituracaoFim.present
            ? escrituracaoFim.value
            : this.escrituracaoFim,
        texto: texto.present ? texto.value : this.texto,
      );
  ContabilTermo copyWithCompanion(ContabilTermosCompanion data) {
    return ContabilTermo(
      id: data.id.present ? data.id.value : this.id,
      idContabilLivro: data.idContabilLivro.present
          ? data.idContabilLivro.value
          : this.idContabilLivro,
      aberturaEncerramento: data.aberturaEncerramento.present
          ? data.aberturaEncerramento.value
          : this.aberturaEncerramento,
      numero: data.numero.present ? data.numero.value : this.numero,
      paginaInicial: data.paginaInicial.present
          ? data.paginaInicial.value
          : this.paginaInicial,
      paginaFinal:
          data.paginaFinal.present ? data.paginaFinal.value : this.paginaFinal,
      registrado:
          data.registrado.present ? data.registrado.value : this.registrado,
      numeroRegistro: data.numeroRegistro.present
          ? data.numeroRegistro.value
          : this.numeroRegistro,
      dataDespacho: data.dataDespacho.present
          ? data.dataDespacho.value
          : this.dataDespacho,
      dataAbertura: data.dataAbertura.present
          ? data.dataAbertura.value
          : this.dataAbertura,
      dataEncerramento: data.dataEncerramento.present
          ? data.dataEncerramento.value
          : this.dataEncerramento,
      escrituracaoInicio: data.escrituracaoInicio.present
          ? data.escrituracaoInicio.value
          : this.escrituracaoInicio,
      escrituracaoFim: data.escrituracaoFim.present
          ? data.escrituracaoFim.value
          : this.escrituracaoFim,
      texto: data.texto.present ? data.texto.value : this.texto,
    );
  }

  @override
  String toString() {
    return (StringBuffer('ContabilTermo(')
          ..write('id: $id, ')
          ..write('idContabilLivro: $idContabilLivro, ')
          ..write('aberturaEncerramento: $aberturaEncerramento, ')
          ..write('numero: $numero, ')
          ..write('paginaInicial: $paginaInicial, ')
          ..write('paginaFinal: $paginaFinal, ')
          ..write('registrado: $registrado, ')
          ..write('numeroRegistro: $numeroRegistro, ')
          ..write('dataDespacho: $dataDespacho, ')
          ..write('dataAbertura: $dataAbertura, ')
          ..write('dataEncerramento: $dataEncerramento, ')
          ..write('escrituracaoInicio: $escrituracaoInicio, ')
          ..write('escrituracaoFim: $escrituracaoFim, ')
          ..write('texto: $texto')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(
      id,
      idContabilLivro,
      aberturaEncerramento,
      numero,
      paginaInicial,
      paginaFinal,
      registrado,
      numeroRegistro,
      dataDespacho,
      dataAbertura,
      dataEncerramento,
      escrituracaoInicio,
      escrituracaoFim,
      texto);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is ContabilTermo &&
          other.id == this.id &&
          other.idContabilLivro == this.idContabilLivro &&
          other.aberturaEncerramento == this.aberturaEncerramento &&
          other.numero == this.numero &&
          other.paginaInicial == this.paginaInicial &&
          other.paginaFinal == this.paginaFinal &&
          other.registrado == this.registrado &&
          other.numeroRegistro == this.numeroRegistro &&
          other.dataDespacho == this.dataDespacho &&
          other.dataAbertura == this.dataAbertura &&
          other.dataEncerramento == this.dataEncerramento &&
          other.escrituracaoInicio == this.escrituracaoInicio &&
          other.escrituracaoFim == this.escrituracaoFim &&
          other.texto == this.texto);
}

class ContabilTermosCompanion extends UpdateCompanion<ContabilTermo> {
  final Value<int?> id;
  final Value<int?> idContabilLivro;
  final Value<String?> aberturaEncerramento;
  final Value<int?> numero;
  final Value<int?> paginaInicial;
  final Value<int?> paginaFinal;
  final Value<String?> registrado;
  final Value<String?> numeroRegistro;
  final Value<DateTime?> dataDespacho;
  final Value<DateTime?> dataAbertura;
  final Value<DateTime?> dataEncerramento;
  final Value<DateTime?> escrituracaoInicio;
  final Value<DateTime?> escrituracaoFim;
  final Value<String?> texto;
  const ContabilTermosCompanion({
    this.id = const Value.absent(),
    this.idContabilLivro = const Value.absent(),
    this.aberturaEncerramento = const Value.absent(),
    this.numero = const Value.absent(),
    this.paginaInicial = const Value.absent(),
    this.paginaFinal = const Value.absent(),
    this.registrado = const Value.absent(),
    this.numeroRegistro = const Value.absent(),
    this.dataDespacho = const Value.absent(),
    this.dataAbertura = const Value.absent(),
    this.dataEncerramento = const Value.absent(),
    this.escrituracaoInicio = const Value.absent(),
    this.escrituracaoFim = const Value.absent(),
    this.texto = const Value.absent(),
  });
  ContabilTermosCompanion.insert({
    this.id = const Value.absent(),
    this.idContabilLivro = const Value.absent(),
    this.aberturaEncerramento = const Value.absent(),
    this.numero = const Value.absent(),
    this.paginaInicial = const Value.absent(),
    this.paginaFinal = const Value.absent(),
    this.registrado = const Value.absent(),
    this.numeroRegistro = const Value.absent(),
    this.dataDespacho = const Value.absent(),
    this.dataAbertura = const Value.absent(),
    this.dataEncerramento = const Value.absent(),
    this.escrituracaoInicio = const Value.absent(),
    this.escrituracaoFim = const Value.absent(),
    this.texto = const Value.absent(),
  });
  static Insertable<ContabilTermo> custom({
    Expression<int>? id,
    Expression<int>? idContabilLivro,
    Expression<String>? aberturaEncerramento,
    Expression<int>? numero,
    Expression<int>? paginaInicial,
    Expression<int>? paginaFinal,
    Expression<String>? registrado,
    Expression<String>? numeroRegistro,
    Expression<DateTime>? dataDespacho,
    Expression<DateTime>? dataAbertura,
    Expression<DateTime>? dataEncerramento,
    Expression<DateTime>? escrituracaoInicio,
    Expression<DateTime>? escrituracaoFim,
    Expression<String>? texto,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (idContabilLivro != null) 'id_contabil_livro': idContabilLivro,
      if (aberturaEncerramento != null)
        'abertura_encerramento': aberturaEncerramento,
      if (numero != null) 'numero': numero,
      if (paginaInicial != null) 'pagina_inicial': paginaInicial,
      if (paginaFinal != null) 'pagina_final': paginaFinal,
      if (registrado != null) 'registrado': registrado,
      if (numeroRegistro != null) 'numero_registro': numeroRegistro,
      if (dataDespacho != null) 'data_despacho': dataDespacho,
      if (dataAbertura != null) 'data_abertura': dataAbertura,
      if (dataEncerramento != null) 'data_encerramento': dataEncerramento,
      if (escrituracaoInicio != null) 'escrituracao_inicio': escrituracaoInicio,
      if (escrituracaoFim != null) 'escrituracao_fim': escrituracaoFim,
      if (texto != null) 'texto': texto,
    });
  }

  ContabilTermosCompanion copyWith(
      {Value<int?>? id,
      Value<int?>? idContabilLivro,
      Value<String?>? aberturaEncerramento,
      Value<int?>? numero,
      Value<int?>? paginaInicial,
      Value<int?>? paginaFinal,
      Value<String?>? registrado,
      Value<String?>? numeroRegistro,
      Value<DateTime?>? dataDespacho,
      Value<DateTime?>? dataAbertura,
      Value<DateTime?>? dataEncerramento,
      Value<DateTime?>? escrituracaoInicio,
      Value<DateTime?>? escrituracaoFim,
      Value<String?>? texto}) {
    return ContabilTermosCompanion(
      id: id ?? this.id,
      idContabilLivro: idContabilLivro ?? this.idContabilLivro,
      aberturaEncerramento: aberturaEncerramento ?? this.aberturaEncerramento,
      numero: numero ?? this.numero,
      paginaInicial: paginaInicial ?? this.paginaInicial,
      paginaFinal: paginaFinal ?? this.paginaFinal,
      registrado: registrado ?? this.registrado,
      numeroRegistro: numeroRegistro ?? this.numeroRegistro,
      dataDespacho: dataDespacho ?? this.dataDespacho,
      dataAbertura: dataAbertura ?? this.dataAbertura,
      dataEncerramento: dataEncerramento ?? this.dataEncerramento,
      escrituracaoInicio: escrituracaoInicio ?? this.escrituracaoInicio,
      escrituracaoFim: escrituracaoFim ?? this.escrituracaoFim,
      texto: texto ?? this.texto,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (idContabilLivro.present) {
      map['id_contabil_livro'] = Variable<int>(idContabilLivro.value);
    }
    if (aberturaEncerramento.present) {
      map['abertura_encerramento'] =
          Variable<String>(aberturaEncerramento.value);
    }
    if (numero.present) {
      map['numero'] = Variable<int>(numero.value);
    }
    if (paginaInicial.present) {
      map['pagina_inicial'] = Variable<int>(paginaInicial.value);
    }
    if (paginaFinal.present) {
      map['pagina_final'] = Variable<int>(paginaFinal.value);
    }
    if (registrado.present) {
      map['registrado'] = Variable<String>(registrado.value);
    }
    if (numeroRegistro.present) {
      map['numero_registro'] = Variable<String>(numeroRegistro.value);
    }
    if (dataDespacho.present) {
      map['data_despacho'] = Variable<DateTime>(dataDespacho.value);
    }
    if (dataAbertura.present) {
      map['data_abertura'] = Variable<DateTime>(dataAbertura.value);
    }
    if (dataEncerramento.present) {
      map['data_encerramento'] = Variable<DateTime>(dataEncerramento.value);
    }
    if (escrituracaoInicio.present) {
      map['escrituracao_inicio'] = Variable<DateTime>(escrituracaoInicio.value);
    }
    if (escrituracaoFim.present) {
      map['escrituracao_fim'] = Variable<DateTime>(escrituracaoFim.value);
    }
    if (texto.present) {
      map['texto'] = Variable<String>(texto.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('ContabilTermosCompanion(')
          ..write('id: $id, ')
          ..write('idContabilLivro: $idContabilLivro, ')
          ..write('aberturaEncerramento: $aberturaEncerramento, ')
          ..write('numero: $numero, ')
          ..write('paginaInicial: $paginaInicial, ')
          ..write('paginaFinal: $paginaFinal, ')
          ..write('registrado: $registrado, ')
          ..write('numeroRegistro: $numeroRegistro, ')
          ..write('dataDespacho: $dataDespacho, ')
          ..write('dataAbertura: $dataAbertura, ')
          ..write('dataEncerramento: $dataEncerramento, ')
          ..write('escrituracaoInicio: $escrituracaoInicio, ')
          ..write('escrituracaoFim: $escrituracaoFim, ')
          ..write('texto: $texto')
          ..write(')'))
        .toString();
  }
}

class $ContabilEncerramentoExeDetsTable extends ContabilEncerramentoExeDets
    with
        TableInfo<$ContabilEncerramentoExeDetsTable,
            ContabilEncerramentoExeDet> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $ContabilEncerramentoExeDetsTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
      'id', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _idContabilEncerramentoExeMeta =
      const VerificationMeta('idContabilEncerramentoExe');
  @override
  late final GeneratedColumn<int> idContabilEncerramentoExe =
      GeneratedColumn<int>('id_contabil_encerramento_exe', aliasedName, true,
          type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _idContabilContaMeta =
      const VerificationMeta('idContabilConta');
  @override
  late final GeneratedColumn<int> idContabilConta = GeneratedColumn<int>(
      'id_contabil_conta', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _saldoAnteriorMeta =
      const VerificationMeta('saldoAnterior');
  @override
  late final GeneratedColumn<double> saldoAnterior = GeneratedColumn<double>(
      'saldo_anterior', aliasedName, true,
      type: DriftSqlType.double, requiredDuringInsert: false);
  static const VerificationMeta _valorDebitoMeta =
      const VerificationMeta('valorDebito');
  @override
  late final GeneratedColumn<double> valorDebito = GeneratedColumn<double>(
      'valor_debito', aliasedName, true,
      type: DriftSqlType.double, requiredDuringInsert: false);
  static const VerificationMeta _valorCreditoMeta =
      const VerificationMeta('valorCredito');
  @override
  late final GeneratedColumn<double> valorCredito = GeneratedColumn<double>(
      'valor_credito', aliasedName, true,
      type: DriftSqlType.double, requiredDuringInsert: false);
  static const VerificationMeta _saldoMeta = const VerificationMeta('saldo');
  @override
  late final GeneratedColumn<double> saldo = GeneratedColumn<double>(
      'saldo', aliasedName, true,
      type: DriftSqlType.double, requiredDuringInsert: false);
  @override
  List<GeneratedColumn> get $columns => [
        id,
        idContabilEncerramentoExe,
        idContabilConta,
        saldoAnterior,
        valorDebito,
        valorCredito,
        saldo
      ];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'contabil_encerramento_exe_det';
  @override
  VerificationContext validateIntegrity(
      Insertable<ContabilEncerramentoExeDet> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('id_contabil_encerramento_exe')) {
      context.handle(
          _idContabilEncerramentoExeMeta,
          idContabilEncerramentoExe.isAcceptableOrUnknown(
              data['id_contabil_encerramento_exe']!,
              _idContabilEncerramentoExeMeta));
    }
    if (data.containsKey('id_contabil_conta')) {
      context.handle(
          _idContabilContaMeta,
          idContabilConta.isAcceptableOrUnknown(
              data['id_contabil_conta']!, _idContabilContaMeta));
    }
    if (data.containsKey('saldo_anterior')) {
      context.handle(
          _saldoAnteriorMeta,
          saldoAnterior.isAcceptableOrUnknown(
              data['saldo_anterior']!, _saldoAnteriorMeta));
    }
    if (data.containsKey('valor_debito')) {
      context.handle(
          _valorDebitoMeta,
          valorDebito.isAcceptableOrUnknown(
              data['valor_debito']!, _valorDebitoMeta));
    }
    if (data.containsKey('valor_credito')) {
      context.handle(
          _valorCreditoMeta,
          valorCredito.isAcceptableOrUnknown(
              data['valor_credito']!, _valorCreditoMeta));
    }
    if (data.containsKey('saldo')) {
      context.handle(
          _saldoMeta, saldo.isAcceptableOrUnknown(data['saldo']!, _saldoMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  ContabilEncerramentoExeDet map(Map<String, dynamic> data,
      {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return ContabilEncerramentoExeDet(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id']),
      idContabilEncerramentoExe: attachedDatabase.typeMapping.read(
          DriftSqlType.int,
          data['${effectivePrefix}id_contabil_encerramento_exe']),
      idContabilConta: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id_contabil_conta']),
      saldoAnterior: attachedDatabase.typeMapping
          .read(DriftSqlType.double, data['${effectivePrefix}saldo_anterior']),
      valorDebito: attachedDatabase.typeMapping
          .read(DriftSqlType.double, data['${effectivePrefix}valor_debito']),
      valorCredito: attachedDatabase.typeMapping
          .read(DriftSqlType.double, data['${effectivePrefix}valor_credito']),
      saldo: attachedDatabase.typeMapping
          .read(DriftSqlType.double, data['${effectivePrefix}saldo']),
    );
  }

  @override
  $ContabilEncerramentoExeDetsTable createAlias(String alias) {
    return $ContabilEncerramentoExeDetsTable(attachedDatabase, alias);
  }
}

class ContabilEncerramentoExeDet extends DataClass
    implements Insertable<ContabilEncerramentoExeDet> {
  final int? id;
  final int? idContabilEncerramentoExe;
  final int? idContabilConta;
  final double? saldoAnterior;
  final double? valorDebito;
  final double? valorCredito;
  final double? saldo;
  const ContabilEncerramentoExeDet(
      {this.id,
      this.idContabilEncerramentoExe,
      this.idContabilConta,
      this.saldoAnterior,
      this.valorDebito,
      this.valorCredito,
      this.saldo});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || idContabilEncerramentoExe != null) {
      map['id_contabil_encerramento_exe'] =
          Variable<int>(idContabilEncerramentoExe);
    }
    if (!nullToAbsent || idContabilConta != null) {
      map['id_contabil_conta'] = Variable<int>(idContabilConta);
    }
    if (!nullToAbsent || saldoAnterior != null) {
      map['saldo_anterior'] = Variable<double>(saldoAnterior);
    }
    if (!nullToAbsent || valorDebito != null) {
      map['valor_debito'] = Variable<double>(valorDebito);
    }
    if (!nullToAbsent || valorCredito != null) {
      map['valor_credito'] = Variable<double>(valorCredito);
    }
    if (!nullToAbsent || saldo != null) {
      map['saldo'] = Variable<double>(saldo);
    }
    return map;
  }

  factory ContabilEncerramentoExeDet.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return ContabilEncerramentoExeDet(
      id: serializer.fromJson<int?>(json['id']),
      idContabilEncerramentoExe:
          serializer.fromJson<int?>(json['idContabilEncerramentoExe']),
      idContabilConta: serializer.fromJson<int?>(json['idContabilConta']),
      saldoAnterior: serializer.fromJson<double?>(json['saldoAnterior']),
      valorDebito: serializer.fromJson<double?>(json['valorDebito']),
      valorCredito: serializer.fromJson<double?>(json['valorCredito']),
      saldo: serializer.fromJson<double?>(json['saldo']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'idContabilEncerramentoExe':
          serializer.toJson<int?>(idContabilEncerramentoExe),
      'idContabilConta': serializer.toJson<int?>(idContabilConta),
      'saldoAnterior': serializer.toJson<double?>(saldoAnterior),
      'valorDebito': serializer.toJson<double?>(valorDebito),
      'valorCredito': serializer.toJson<double?>(valorCredito),
      'saldo': serializer.toJson<double?>(saldo),
    };
  }

  ContabilEncerramentoExeDet copyWith(
          {Value<int?> id = const Value.absent(),
          Value<int?> idContabilEncerramentoExe = const Value.absent(),
          Value<int?> idContabilConta = const Value.absent(),
          Value<double?> saldoAnterior = const Value.absent(),
          Value<double?> valorDebito = const Value.absent(),
          Value<double?> valorCredito = const Value.absent(),
          Value<double?> saldo = const Value.absent()}) =>
      ContabilEncerramentoExeDet(
        id: id.present ? id.value : this.id,
        idContabilEncerramentoExe: idContabilEncerramentoExe.present
            ? idContabilEncerramentoExe.value
            : this.idContabilEncerramentoExe,
        idContabilConta: idContabilConta.present
            ? idContabilConta.value
            : this.idContabilConta,
        saldoAnterior:
            saldoAnterior.present ? saldoAnterior.value : this.saldoAnterior,
        valorDebito: valorDebito.present ? valorDebito.value : this.valorDebito,
        valorCredito:
            valorCredito.present ? valorCredito.value : this.valorCredito,
        saldo: saldo.present ? saldo.value : this.saldo,
      );
  ContabilEncerramentoExeDet copyWithCompanion(
      ContabilEncerramentoExeDetsCompanion data) {
    return ContabilEncerramentoExeDet(
      id: data.id.present ? data.id.value : this.id,
      idContabilEncerramentoExe: data.idContabilEncerramentoExe.present
          ? data.idContabilEncerramentoExe.value
          : this.idContabilEncerramentoExe,
      idContabilConta: data.idContabilConta.present
          ? data.idContabilConta.value
          : this.idContabilConta,
      saldoAnterior: data.saldoAnterior.present
          ? data.saldoAnterior.value
          : this.saldoAnterior,
      valorDebito:
          data.valorDebito.present ? data.valorDebito.value : this.valorDebito,
      valorCredito: data.valorCredito.present
          ? data.valorCredito.value
          : this.valorCredito,
      saldo: data.saldo.present ? data.saldo.value : this.saldo,
    );
  }

  @override
  String toString() {
    return (StringBuffer('ContabilEncerramentoExeDet(')
          ..write('id: $id, ')
          ..write('idContabilEncerramentoExe: $idContabilEncerramentoExe, ')
          ..write('idContabilConta: $idContabilConta, ')
          ..write('saldoAnterior: $saldoAnterior, ')
          ..write('valorDebito: $valorDebito, ')
          ..write('valorCredito: $valorCredito, ')
          ..write('saldo: $saldo')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(id, idContabilEncerramentoExe,
      idContabilConta, saldoAnterior, valorDebito, valorCredito, saldo);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is ContabilEncerramentoExeDet &&
          other.id == this.id &&
          other.idContabilEncerramentoExe == this.idContabilEncerramentoExe &&
          other.idContabilConta == this.idContabilConta &&
          other.saldoAnterior == this.saldoAnterior &&
          other.valorDebito == this.valorDebito &&
          other.valorCredito == this.valorCredito &&
          other.saldo == this.saldo);
}

class ContabilEncerramentoExeDetsCompanion
    extends UpdateCompanion<ContabilEncerramentoExeDet> {
  final Value<int?> id;
  final Value<int?> idContabilEncerramentoExe;
  final Value<int?> idContabilConta;
  final Value<double?> saldoAnterior;
  final Value<double?> valorDebito;
  final Value<double?> valorCredito;
  final Value<double?> saldo;
  const ContabilEncerramentoExeDetsCompanion({
    this.id = const Value.absent(),
    this.idContabilEncerramentoExe = const Value.absent(),
    this.idContabilConta = const Value.absent(),
    this.saldoAnterior = const Value.absent(),
    this.valorDebito = const Value.absent(),
    this.valorCredito = const Value.absent(),
    this.saldo = const Value.absent(),
  });
  ContabilEncerramentoExeDetsCompanion.insert({
    this.id = const Value.absent(),
    this.idContabilEncerramentoExe = const Value.absent(),
    this.idContabilConta = const Value.absent(),
    this.saldoAnterior = const Value.absent(),
    this.valorDebito = const Value.absent(),
    this.valorCredito = const Value.absent(),
    this.saldo = const Value.absent(),
  });
  static Insertable<ContabilEncerramentoExeDet> custom({
    Expression<int>? id,
    Expression<int>? idContabilEncerramentoExe,
    Expression<int>? idContabilConta,
    Expression<double>? saldoAnterior,
    Expression<double>? valorDebito,
    Expression<double>? valorCredito,
    Expression<double>? saldo,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (idContabilEncerramentoExe != null)
        'id_contabil_encerramento_exe': idContabilEncerramentoExe,
      if (idContabilConta != null) 'id_contabil_conta': idContabilConta,
      if (saldoAnterior != null) 'saldo_anterior': saldoAnterior,
      if (valorDebito != null) 'valor_debito': valorDebito,
      if (valorCredito != null) 'valor_credito': valorCredito,
      if (saldo != null) 'saldo': saldo,
    });
  }

  ContabilEncerramentoExeDetsCompanion copyWith(
      {Value<int?>? id,
      Value<int?>? idContabilEncerramentoExe,
      Value<int?>? idContabilConta,
      Value<double?>? saldoAnterior,
      Value<double?>? valorDebito,
      Value<double?>? valorCredito,
      Value<double?>? saldo}) {
    return ContabilEncerramentoExeDetsCompanion(
      id: id ?? this.id,
      idContabilEncerramentoExe:
          idContabilEncerramentoExe ?? this.idContabilEncerramentoExe,
      idContabilConta: idContabilConta ?? this.idContabilConta,
      saldoAnterior: saldoAnterior ?? this.saldoAnterior,
      valorDebito: valorDebito ?? this.valorDebito,
      valorCredito: valorCredito ?? this.valorCredito,
      saldo: saldo ?? this.saldo,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (idContabilEncerramentoExe.present) {
      map['id_contabil_encerramento_exe'] =
          Variable<int>(idContabilEncerramentoExe.value);
    }
    if (idContabilConta.present) {
      map['id_contabil_conta'] = Variable<int>(idContabilConta.value);
    }
    if (saldoAnterior.present) {
      map['saldo_anterior'] = Variable<double>(saldoAnterior.value);
    }
    if (valorDebito.present) {
      map['valor_debito'] = Variable<double>(valorDebito.value);
    }
    if (valorCredito.present) {
      map['valor_credito'] = Variable<double>(valorCredito.value);
    }
    if (saldo.present) {
      map['saldo'] = Variable<double>(saldo.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('ContabilEncerramentoExeDetsCompanion(')
          ..write('id: $id, ')
          ..write('idContabilEncerramentoExe: $idContabilEncerramentoExe, ')
          ..write('idContabilConta: $idContabilConta, ')
          ..write('saldoAnterior: $saldoAnterior, ')
          ..write('valorDebito: $valorDebito, ')
          ..write('valorCredito: $valorCredito, ')
          ..write('saldo: $saldo')
          ..write(')'))
        .toString();
  }
}

class $RateioCentroResultadoDetsTable extends RateioCentroResultadoDets
    with TableInfo<$RateioCentroResultadoDetsTable, RateioCentroResultadoDet> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $RateioCentroResultadoDetsTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
      'id', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _idCentroResultadoDestinoMeta =
      const VerificationMeta('idCentroResultadoDestino');
  @override
  late final GeneratedColumn<int> idCentroResultadoDestino =
      GeneratedColumn<int>('id_centro_resultado_destino', aliasedName, true,
          type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _idRateioCentroResulCabMeta =
      const VerificationMeta('idRateioCentroResulCab');
  @override
  late final GeneratedColumn<int> idRateioCentroResulCab = GeneratedColumn<int>(
      'id_rateio_centro_resul_cab', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _porcentoRateioMeta =
      const VerificationMeta('porcentoRateio');
  @override
  late final GeneratedColumn<double> porcentoRateio = GeneratedColumn<double>(
      'porcento_rateio', aliasedName, true,
      type: DriftSqlType.double, requiredDuringInsert: false);
  @override
  List<GeneratedColumn> get $columns =>
      [id, idCentroResultadoDestino, idRateioCentroResulCab, porcentoRateio];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'rateio_centro_resultado_det';
  @override
  VerificationContext validateIntegrity(
      Insertable<RateioCentroResultadoDet> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('id_centro_resultado_destino')) {
      context.handle(
          _idCentroResultadoDestinoMeta,
          idCentroResultadoDestino.isAcceptableOrUnknown(
              data['id_centro_resultado_destino']!,
              _idCentroResultadoDestinoMeta));
    }
    if (data.containsKey('id_rateio_centro_resul_cab')) {
      context.handle(
          _idRateioCentroResulCabMeta,
          idRateioCentroResulCab.isAcceptableOrUnknown(
              data['id_rateio_centro_resul_cab']!,
              _idRateioCentroResulCabMeta));
    }
    if (data.containsKey('porcento_rateio')) {
      context.handle(
          _porcentoRateioMeta,
          porcentoRateio.isAcceptableOrUnknown(
              data['porcento_rateio']!, _porcentoRateioMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  RateioCentroResultadoDet map(Map<String, dynamic> data,
      {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return RateioCentroResultadoDet(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id']),
      idCentroResultadoDestino: attachedDatabase.typeMapping.read(
          DriftSqlType.int,
          data['${effectivePrefix}id_centro_resultado_destino']),
      idRateioCentroResulCab: attachedDatabase.typeMapping.read(
          DriftSqlType.int,
          data['${effectivePrefix}id_rateio_centro_resul_cab']),
      porcentoRateio: attachedDatabase.typeMapping
          .read(DriftSqlType.double, data['${effectivePrefix}porcento_rateio']),
    );
  }

  @override
  $RateioCentroResultadoDetsTable createAlias(String alias) {
    return $RateioCentroResultadoDetsTable(attachedDatabase, alias);
  }
}

class RateioCentroResultadoDet extends DataClass
    implements Insertable<RateioCentroResultadoDet> {
  final int? id;
  final int? idCentroResultadoDestino;
  final int? idRateioCentroResulCab;
  final double? porcentoRateio;
  const RateioCentroResultadoDet(
      {this.id,
      this.idCentroResultadoDestino,
      this.idRateioCentroResulCab,
      this.porcentoRateio});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || idCentroResultadoDestino != null) {
      map['id_centro_resultado_destino'] =
          Variable<int>(idCentroResultadoDestino);
    }
    if (!nullToAbsent || idRateioCentroResulCab != null) {
      map['id_rateio_centro_resul_cab'] = Variable<int>(idRateioCentroResulCab);
    }
    if (!nullToAbsent || porcentoRateio != null) {
      map['porcento_rateio'] = Variable<double>(porcentoRateio);
    }
    return map;
  }

  factory RateioCentroResultadoDet.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return RateioCentroResultadoDet(
      id: serializer.fromJson<int?>(json['id']),
      idCentroResultadoDestino:
          serializer.fromJson<int?>(json['idCentroResultadoDestino']),
      idRateioCentroResulCab:
          serializer.fromJson<int?>(json['idRateioCentroResulCab']),
      porcentoRateio: serializer.fromJson<double?>(json['porcentoRateio']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'idCentroResultadoDestino':
          serializer.toJson<int?>(idCentroResultadoDestino),
      'idRateioCentroResulCab': serializer.toJson<int?>(idRateioCentroResulCab),
      'porcentoRateio': serializer.toJson<double?>(porcentoRateio),
    };
  }

  RateioCentroResultadoDet copyWith(
          {Value<int?> id = const Value.absent(),
          Value<int?> idCentroResultadoDestino = const Value.absent(),
          Value<int?> idRateioCentroResulCab = const Value.absent(),
          Value<double?> porcentoRateio = const Value.absent()}) =>
      RateioCentroResultadoDet(
        id: id.present ? id.value : this.id,
        idCentroResultadoDestino: idCentroResultadoDestino.present
            ? idCentroResultadoDestino.value
            : this.idCentroResultadoDestino,
        idRateioCentroResulCab: idRateioCentroResulCab.present
            ? idRateioCentroResulCab.value
            : this.idRateioCentroResulCab,
        porcentoRateio:
            porcentoRateio.present ? porcentoRateio.value : this.porcentoRateio,
      );
  RateioCentroResultadoDet copyWithCompanion(
      RateioCentroResultadoDetsCompanion data) {
    return RateioCentroResultadoDet(
      id: data.id.present ? data.id.value : this.id,
      idCentroResultadoDestino: data.idCentroResultadoDestino.present
          ? data.idCentroResultadoDestino.value
          : this.idCentroResultadoDestino,
      idRateioCentroResulCab: data.idRateioCentroResulCab.present
          ? data.idRateioCentroResulCab.value
          : this.idRateioCentroResulCab,
      porcentoRateio: data.porcentoRateio.present
          ? data.porcentoRateio.value
          : this.porcentoRateio,
    );
  }

  @override
  String toString() {
    return (StringBuffer('RateioCentroResultadoDet(')
          ..write('id: $id, ')
          ..write('idCentroResultadoDestino: $idCentroResultadoDestino, ')
          ..write('idRateioCentroResulCab: $idRateioCentroResulCab, ')
          ..write('porcentoRateio: $porcentoRateio')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(
      id, idCentroResultadoDestino, idRateioCentroResulCab, porcentoRateio);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is RateioCentroResultadoDet &&
          other.id == this.id &&
          other.idCentroResultadoDestino == this.idCentroResultadoDestino &&
          other.idRateioCentroResulCab == this.idRateioCentroResulCab &&
          other.porcentoRateio == this.porcentoRateio);
}

class RateioCentroResultadoDetsCompanion
    extends UpdateCompanion<RateioCentroResultadoDet> {
  final Value<int?> id;
  final Value<int?> idCentroResultadoDestino;
  final Value<int?> idRateioCentroResulCab;
  final Value<double?> porcentoRateio;
  const RateioCentroResultadoDetsCompanion({
    this.id = const Value.absent(),
    this.idCentroResultadoDestino = const Value.absent(),
    this.idRateioCentroResulCab = const Value.absent(),
    this.porcentoRateio = const Value.absent(),
  });
  RateioCentroResultadoDetsCompanion.insert({
    this.id = const Value.absent(),
    this.idCentroResultadoDestino = const Value.absent(),
    this.idRateioCentroResulCab = const Value.absent(),
    this.porcentoRateio = const Value.absent(),
  });
  static Insertable<RateioCentroResultadoDet> custom({
    Expression<int>? id,
    Expression<int>? idCentroResultadoDestino,
    Expression<int>? idRateioCentroResulCab,
    Expression<double>? porcentoRateio,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (idCentroResultadoDestino != null)
        'id_centro_resultado_destino': idCentroResultadoDestino,
      if (idRateioCentroResulCab != null)
        'id_rateio_centro_resul_cab': idRateioCentroResulCab,
      if (porcentoRateio != null) 'porcento_rateio': porcentoRateio,
    });
  }

  RateioCentroResultadoDetsCompanion copyWith(
      {Value<int?>? id,
      Value<int?>? idCentroResultadoDestino,
      Value<int?>? idRateioCentroResulCab,
      Value<double?>? porcentoRateio}) {
    return RateioCentroResultadoDetsCompanion(
      id: id ?? this.id,
      idCentroResultadoDestino:
          idCentroResultadoDestino ?? this.idCentroResultadoDestino,
      idRateioCentroResulCab:
          idRateioCentroResulCab ?? this.idRateioCentroResulCab,
      porcentoRateio: porcentoRateio ?? this.porcentoRateio,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (idCentroResultadoDestino.present) {
      map['id_centro_resultado_destino'] =
          Variable<int>(idCentroResultadoDestino.value);
    }
    if (idRateioCentroResulCab.present) {
      map['id_rateio_centro_resul_cab'] =
          Variable<int>(idRateioCentroResulCab.value);
    }
    if (porcentoRateio.present) {
      map['porcento_rateio'] = Variable<double>(porcentoRateio.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('RateioCentroResultadoDetsCompanion(')
          ..write('id: $id, ')
          ..write('idCentroResultadoDestino: $idCentroResultadoDestino, ')
          ..write('idRateioCentroResulCab: $idRateioCentroResulCab, ')
          ..write('porcentoRateio: $porcentoRateio')
          ..write(')'))
        .toString();
  }
}

class $ContabilIndiceValorsTable extends ContabilIndiceValors
    with TableInfo<$ContabilIndiceValorsTable, ContabilIndiceValor> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $ContabilIndiceValorsTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
      'id', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _idContabilIndiceMeta =
      const VerificationMeta('idContabilIndice');
  @override
  late final GeneratedColumn<int> idContabilIndice = GeneratedColumn<int>(
      'id_contabil_indice', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _dataIndiceMeta =
      const VerificationMeta('dataIndice');
  @override
  late final GeneratedColumn<DateTime> dataIndice = GeneratedColumn<DateTime>(
      'data_indice', aliasedName, true,
      type: DriftSqlType.dateTime, requiredDuringInsert: false);
  static const VerificationMeta _valorMeta = const VerificationMeta('valor');
  @override
  late final GeneratedColumn<double> valor = GeneratedColumn<double>(
      'valor', aliasedName, true,
      type: DriftSqlType.double, requiredDuringInsert: false);
  @override
  List<GeneratedColumn> get $columns =>
      [id, idContabilIndice, dataIndice, valor];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'contabil_indice_valor';
  @override
  VerificationContext validateIntegrity(
      Insertable<ContabilIndiceValor> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('id_contabil_indice')) {
      context.handle(
          _idContabilIndiceMeta,
          idContabilIndice.isAcceptableOrUnknown(
              data['id_contabil_indice']!, _idContabilIndiceMeta));
    }
    if (data.containsKey('data_indice')) {
      context.handle(
          _dataIndiceMeta,
          dataIndice.isAcceptableOrUnknown(
              data['data_indice']!, _dataIndiceMeta));
    }
    if (data.containsKey('valor')) {
      context.handle(
          _valorMeta, valor.isAcceptableOrUnknown(data['valor']!, _valorMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  ContabilIndiceValor map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return ContabilIndiceValor(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id']),
      idContabilIndice: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id_contabil_indice']),
      dataIndice: attachedDatabase.typeMapping
          .read(DriftSqlType.dateTime, data['${effectivePrefix}data_indice']),
      valor: attachedDatabase.typeMapping
          .read(DriftSqlType.double, data['${effectivePrefix}valor']),
    );
  }

  @override
  $ContabilIndiceValorsTable createAlias(String alias) {
    return $ContabilIndiceValorsTable(attachedDatabase, alias);
  }
}

class ContabilIndiceValor extends DataClass
    implements Insertable<ContabilIndiceValor> {
  final int? id;
  final int? idContabilIndice;
  final DateTime? dataIndice;
  final double? valor;
  const ContabilIndiceValor(
      {this.id, this.idContabilIndice, this.dataIndice, this.valor});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || idContabilIndice != null) {
      map['id_contabil_indice'] = Variable<int>(idContabilIndice);
    }
    if (!nullToAbsent || dataIndice != null) {
      map['data_indice'] = Variable<DateTime>(dataIndice);
    }
    if (!nullToAbsent || valor != null) {
      map['valor'] = Variable<double>(valor);
    }
    return map;
  }

  factory ContabilIndiceValor.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return ContabilIndiceValor(
      id: serializer.fromJson<int?>(json['id']),
      idContabilIndice: serializer.fromJson<int?>(json['idContabilIndice']),
      dataIndice: serializer.fromJson<DateTime?>(json['dataIndice']),
      valor: serializer.fromJson<double?>(json['valor']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'idContabilIndice': serializer.toJson<int?>(idContabilIndice),
      'dataIndice': serializer.toJson<DateTime?>(dataIndice),
      'valor': serializer.toJson<double?>(valor),
    };
  }

  ContabilIndiceValor copyWith(
          {Value<int?> id = const Value.absent(),
          Value<int?> idContabilIndice = const Value.absent(),
          Value<DateTime?> dataIndice = const Value.absent(),
          Value<double?> valor = const Value.absent()}) =>
      ContabilIndiceValor(
        id: id.present ? id.value : this.id,
        idContabilIndice: idContabilIndice.present
            ? idContabilIndice.value
            : this.idContabilIndice,
        dataIndice: dataIndice.present ? dataIndice.value : this.dataIndice,
        valor: valor.present ? valor.value : this.valor,
      );
  ContabilIndiceValor copyWithCompanion(ContabilIndiceValorsCompanion data) {
    return ContabilIndiceValor(
      id: data.id.present ? data.id.value : this.id,
      idContabilIndice: data.idContabilIndice.present
          ? data.idContabilIndice.value
          : this.idContabilIndice,
      dataIndice:
          data.dataIndice.present ? data.dataIndice.value : this.dataIndice,
      valor: data.valor.present ? data.valor.value : this.valor,
    );
  }

  @override
  String toString() {
    return (StringBuffer('ContabilIndiceValor(')
          ..write('id: $id, ')
          ..write('idContabilIndice: $idContabilIndice, ')
          ..write('dataIndice: $dataIndice, ')
          ..write('valor: $valor')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(id, idContabilIndice, dataIndice, valor);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is ContabilIndiceValor &&
          other.id == this.id &&
          other.idContabilIndice == this.idContabilIndice &&
          other.dataIndice == this.dataIndice &&
          other.valor == this.valor);
}

class ContabilIndiceValorsCompanion
    extends UpdateCompanion<ContabilIndiceValor> {
  final Value<int?> id;
  final Value<int?> idContabilIndice;
  final Value<DateTime?> dataIndice;
  final Value<double?> valor;
  const ContabilIndiceValorsCompanion({
    this.id = const Value.absent(),
    this.idContabilIndice = const Value.absent(),
    this.dataIndice = const Value.absent(),
    this.valor = const Value.absent(),
  });
  ContabilIndiceValorsCompanion.insert({
    this.id = const Value.absent(),
    this.idContabilIndice = const Value.absent(),
    this.dataIndice = const Value.absent(),
    this.valor = const Value.absent(),
  });
  static Insertable<ContabilIndiceValor> custom({
    Expression<int>? id,
    Expression<int>? idContabilIndice,
    Expression<DateTime>? dataIndice,
    Expression<double>? valor,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (idContabilIndice != null) 'id_contabil_indice': idContabilIndice,
      if (dataIndice != null) 'data_indice': dataIndice,
      if (valor != null) 'valor': valor,
    });
  }

  ContabilIndiceValorsCompanion copyWith(
      {Value<int?>? id,
      Value<int?>? idContabilIndice,
      Value<DateTime?>? dataIndice,
      Value<double?>? valor}) {
    return ContabilIndiceValorsCompanion(
      id: id ?? this.id,
      idContabilIndice: idContabilIndice ?? this.idContabilIndice,
      dataIndice: dataIndice ?? this.dataIndice,
      valor: valor ?? this.valor,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (idContabilIndice.present) {
      map['id_contabil_indice'] = Variable<int>(idContabilIndice.value);
    }
    if (dataIndice.present) {
      map['data_indice'] = Variable<DateTime>(dataIndice.value);
    }
    if (valor.present) {
      map['valor'] = Variable<double>(valor.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('ContabilIndiceValorsCompanion(')
          ..write('id: $id, ')
          ..write('idContabilIndice: $idContabilIndice, ')
          ..write('dataIndice: $dataIndice, ')
          ..write('valor: $valor')
          ..write(')'))
        .toString();
  }
}

class $CtResultadoNtFinanceirasTable extends CtResultadoNtFinanceiras
    with TableInfo<$CtResultadoNtFinanceirasTable, CtResultadoNtFinanceira> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $CtResultadoNtFinanceirasTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
      'id', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _idCentroResultadoMeta =
      const VerificationMeta('idCentroResultado');
  @override
  late final GeneratedColumn<int> idCentroResultado = GeneratedColumn<int>(
      'id_centro_resultado', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _idFinNaturezaFinanceiraMeta =
      const VerificationMeta('idFinNaturezaFinanceira');
  @override
  late final GeneratedColumn<int> idFinNaturezaFinanceira =
      GeneratedColumn<int>('id_fin_natureza_financeira', aliasedName, true,
          type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _percentualRateioMeta =
      const VerificationMeta('percentualRateio');
  @override
  late final GeneratedColumn<double> percentualRateio = GeneratedColumn<double>(
      'percentual_rateio', aliasedName, true,
      type: DriftSqlType.double, requiredDuringInsert: false);
  @override
  List<GeneratedColumn> get $columns =>
      [id, idCentroResultado, idFinNaturezaFinanceira, percentualRateio];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'ct_resultado_nt_financeira';
  @override
  VerificationContext validateIntegrity(
      Insertable<CtResultadoNtFinanceira> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('id_centro_resultado')) {
      context.handle(
          _idCentroResultadoMeta,
          idCentroResultado.isAcceptableOrUnknown(
              data['id_centro_resultado']!, _idCentroResultadoMeta));
    }
    if (data.containsKey('id_fin_natureza_financeira')) {
      context.handle(
          _idFinNaturezaFinanceiraMeta,
          idFinNaturezaFinanceira.isAcceptableOrUnknown(
              data['id_fin_natureza_financeira']!,
              _idFinNaturezaFinanceiraMeta));
    }
    if (data.containsKey('percentual_rateio')) {
      context.handle(
          _percentualRateioMeta,
          percentualRateio.isAcceptableOrUnknown(
              data['percentual_rateio']!, _percentualRateioMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  CtResultadoNtFinanceira map(Map<String, dynamic> data,
      {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return CtResultadoNtFinanceira(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id']),
      idCentroResultado: attachedDatabase.typeMapping.read(
          DriftSqlType.int, data['${effectivePrefix}id_centro_resultado']),
      idFinNaturezaFinanceira: attachedDatabase.typeMapping.read(
          DriftSqlType.int,
          data['${effectivePrefix}id_fin_natureza_financeira']),
      percentualRateio: attachedDatabase.typeMapping.read(
          DriftSqlType.double, data['${effectivePrefix}percentual_rateio']),
    );
  }

  @override
  $CtResultadoNtFinanceirasTable createAlias(String alias) {
    return $CtResultadoNtFinanceirasTable(attachedDatabase, alias);
  }
}

class CtResultadoNtFinanceira extends DataClass
    implements Insertable<CtResultadoNtFinanceira> {
  final int? id;
  final int? idCentroResultado;
  final int? idFinNaturezaFinanceira;
  final double? percentualRateio;
  const CtResultadoNtFinanceira(
      {this.id,
      this.idCentroResultado,
      this.idFinNaturezaFinanceira,
      this.percentualRateio});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || idCentroResultado != null) {
      map['id_centro_resultado'] = Variable<int>(idCentroResultado);
    }
    if (!nullToAbsent || idFinNaturezaFinanceira != null) {
      map['id_fin_natureza_financeira'] =
          Variable<int>(idFinNaturezaFinanceira);
    }
    if (!nullToAbsent || percentualRateio != null) {
      map['percentual_rateio'] = Variable<double>(percentualRateio);
    }
    return map;
  }

  factory CtResultadoNtFinanceira.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return CtResultadoNtFinanceira(
      id: serializer.fromJson<int?>(json['id']),
      idCentroResultado: serializer.fromJson<int?>(json['idCentroResultado']),
      idFinNaturezaFinanceira:
          serializer.fromJson<int?>(json['idFinNaturezaFinanceira']),
      percentualRateio: serializer.fromJson<double?>(json['percentualRateio']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'idCentroResultado': serializer.toJson<int?>(idCentroResultado),
      'idFinNaturezaFinanceira':
          serializer.toJson<int?>(idFinNaturezaFinanceira),
      'percentualRateio': serializer.toJson<double?>(percentualRateio),
    };
  }

  CtResultadoNtFinanceira copyWith(
          {Value<int?> id = const Value.absent(),
          Value<int?> idCentroResultado = const Value.absent(),
          Value<int?> idFinNaturezaFinanceira = const Value.absent(),
          Value<double?> percentualRateio = const Value.absent()}) =>
      CtResultadoNtFinanceira(
        id: id.present ? id.value : this.id,
        idCentroResultado: idCentroResultado.present
            ? idCentroResultado.value
            : this.idCentroResultado,
        idFinNaturezaFinanceira: idFinNaturezaFinanceira.present
            ? idFinNaturezaFinanceira.value
            : this.idFinNaturezaFinanceira,
        percentualRateio: percentualRateio.present
            ? percentualRateio.value
            : this.percentualRateio,
      );
  CtResultadoNtFinanceira copyWithCompanion(
      CtResultadoNtFinanceirasCompanion data) {
    return CtResultadoNtFinanceira(
      id: data.id.present ? data.id.value : this.id,
      idCentroResultado: data.idCentroResultado.present
          ? data.idCentroResultado.value
          : this.idCentroResultado,
      idFinNaturezaFinanceira: data.idFinNaturezaFinanceira.present
          ? data.idFinNaturezaFinanceira.value
          : this.idFinNaturezaFinanceira,
      percentualRateio: data.percentualRateio.present
          ? data.percentualRateio.value
          : this.percentualRateio,
    );
  }

  @override
  String toString() {
    return (StringBuffer('CtResultadoNtFinanceira(')
          ..write('id: $id, ')
          ..write('idCentroResultado: $idCentroResultado, ')
          ..write('idFinNaturezaFinanceira: $idFinNaturezaFinanceira, ')
          ..write('percentualRateio: $percentualRateio')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(
      id, idCentroResultado, idFinNaturezaFinanceira, percentualRateio);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is CtResultadoNtFinanceira &&
          other.id == this.id &&
          other.idCentroResultado == this.idCentroResultado &&
          other.idFinNaturezaFinanceira == this.idFinNaturezaFinanceira &&
          other.percentualRateio == this.percentualRateio);
}

class CtResultadoNtFinanceirasCompanion
    extends UpdateCompanion<CtResultadoNtFinanceira> {
  final Value<int?> id;
  final Value<int?> idCentroResultado;
  final Value<int?> idFinNaturezaFinanceira;
  final Value<double?> percentualRateio;
  const CtResultadoNtFinanceirasCompanion({
    this.id = const Value.absent(),
    this.idCentroResultado = const Value.absent(),
    this.idFinNaturezaFinanceira = const Value.absent(),
    this.percentualRateio = const Value.absent(),
  });
  CtResultadoNtFinanceirasCompanion.insert({
    this.id = const Value.absent(),
    this.idCentroResultado = const Value.absent(),
    this.idFinNaturezaFinanceira = const Value.absent(),
    this.percentualRateio = const Value.absent(),
  });
  static Insertable<CtResultadoNtFinanceira> custom({
    Expression<int>? id,
    Expression<int>? idCentroResultado,
    Expression<int>? idFinNaturezaFinanceira,
    Expression<double>? percentualRateio,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (idCentroResultado != null) 'id_centro_resultado': idCentroResultado,
      if (idFinNaturezaFinanceira != null)
        'id_fin_natureza_financeira': idFinNaturezaFinanceira,
      if (percentualRateio != null) 'percentual_rateio': percentualRateio,
    });
  }

  CtResultadoNtFinanceirasCompanion copyWith(
      {Value<int?>? id,
      Value<int?>? idCentroResultado,
      Value<int?>? idFinNaturezaFinanceira,
      Value<double?>? percentualRateio}) {
    return CtResultadoNtFinanceirasCompanion(
      id: id ?? this.id,
      idCentroResultado: idCentroResultado ?? this.idCentroResultado,
      idFinNaturezaFinanceira:
          idFinNaturezaFinanceira ?? this.idFinNaturezaFinanceira,
      percentualRateio: percentualRateio ?? this.percentualRateio,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (idCentroResultado.present) {
      map['id_centro_resultado'] = Variable<int>(idCentroResultado.value);
    }
    if (idFinNaturezaFinanceira.present) {
      map['id_fin_natureza_financeira'] =
          Variable<int>(idFinNaturezaFinanceira.value);
    }
    if (percentualRateio.present) {
      map['percentual_rateio'] = Variable<double>(percentualRateio.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('CtResultadoNtFinanceirasCompanion(')
          ..write('id: $id, ')
          ..write('idCentroResultado: $idCentroResultado, ')
          ..write('idFinNaturezaFinanceira: $idFinNaturezaFinanceira, ')
          ..write('percentualRateio: $percentualRateio')
          ..write(')'))
        .toString();
  }
}

class $ContabilLancamentoCabecalhosTable extends ContabilLancamentoCabecalhos
    with
        TableInfo<$ContabilLancamentoCabecalhosTable,
            ContabilLancamentoCabecalho> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $ContabilLancamentoCabecalhosTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
      'id', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _idContabilLoteMeta =
      const VerificationMeta('idContabilLote');
  @override
  late final GeneratedColumn<int> idContabilLote = GeneratedColumn<int>(
      'id_contabil_lote', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _dataLancamentoMeta =
      const VerificationMeta('dataLancamento');
  @override
  late final GeneratedColumn<DateTime> dataLancamento =
      GeneratedColumn<DateTime>('data_lancamento', aliasedName, true,
          type: DriftSqlType.dateTime, requiredDuringInsert: false);
  static const VerificationMeta _dataInclusaoMeta =
      const VerificationMeta('dataInclusao');
  @override
  late final GeneratedColumn<DateTime> dataInclusao = GeneratedColumn<DateTime>(
      'data_inclusao', aliasedName, true,
      type: DriftSqlType.dateTime, requiredDuringInsert: false);
  static const VerificationMeta _tipoMeta = const VerificationMeta('tipo');
  @override
  late final GeneratedColumn<String> tipo = GeneratedColumn<String>(
      'tipo', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 1),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _liberadoMeta =
      const VerificationMeta('liberado');
  @override
  late final GeneratedColumn<String> liberado = GeneratedColumn<String>(
      'liberado', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 1),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _valorMeta = const VerificationMeta('valor');
  @override
  late final GeneratedColumn<double> valor = GeneratedColumn<double>(
      'valor', aliasedName, true,
      type: DriftSqlType.double, requiredDuringInsert: false);
  @override
  List<GeneratedColumn> get $columns =>
      [id, idContabilLote, dataLancamento, dataInclusao, tipo, liberado, valor];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'contabil_lancamento_cabecalho';
  @override
  VerificationContext validateIntegrity(
      Insertable<ContabilLancamentoCabecalho> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('id_contabil_lote')) {
      context.handle(
          _idContabilLoteMeta,
          idContabilLote.isAcceptableOrUnknown(
              data['id_contabil_lote']!, _idContabilLoteMeta));
    }
    if (data.containsKey('data_lancamento')) {
      context.handle(
          _dataLancamentoMeta,
          dataLancamento.isAcceptableOrUnknown(
              data['data_lancamento']!, _dataLancamentoMeta));
    }
    if (data.containsKey('data_inclusao')) {
      context.handle(
          _dataInclusaoMeta,
          dataInclusao.isAcceptableOrUnknown(
              data['data_inclusao']!, _dataInclusaoMeta));
    }
    if (data.containsKey('tipo')) {
      context.handle(
          _tipoMeta, tipo.isAcceptableOrUnknown(data['tipo']!, _tipoMeta));
    }
    if (data.containsKey('liberado')) {
      context.handle(_liberadoMeta,
          liberado.isAcceptableOrUnknown(data['liberado']!, _liberadoMeta));
    }
    if (data.containsKey('valor')) {
      context.handle(
          _valorMeta, valor.isAcceptableOrUnknown(data['valor']!, _valorMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  ContabilLancamentoCabecalho map(Map<String, dynamic> data,
      {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return ContabilLancamentoCabecalho(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id']),
      idContabilLote: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id_contabil_lote']),
      dataLancamento: attachedDatabase.typeMapping.read(
          DriftSqlType.dateTime, data['${effectivePrefix}data_lancamento']),
      dataInclusao: attachedDatabase.typeMapping
          .read(DriftSqlType.dateTime, data['${effectivePrefix}data_inclusao']),
      tipo: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}tipo']),
      liberado: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}liberado']),
      valor: attachedDatabase.typeMapping
          .read(DriftSqlType.double, data['${effectivePrefix}valor']),
    );
  }

  @override
  $ContabilLancamentoCabecalhosTable createAlias(String alias) {
    return $ContabilLancamentoCabecalhosTable(attachedDatabase, alias);
  }
}

class ContabilLancamentoCabecalho extends DataClass
    implements Insertable<ContabilLancamentoCabecalho> {
  final int? id;
  final int? idContabilLote;
  final DateTime? dataLancamento;
  final DateTime? dataInclusao;
  final String? tipo;
  final String? liberado;
  final double? valor;
  const ContabilLancamentoCabecalho(
      {this.id,
      this.idContabilLote,
      this.dataLancamento,
      this.dataInclusao,
      this.tipo,
      this.liberado,
      this.valor});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || idContabilLote != null) {
      map['id_contabil_lote'] = Variable<int>(idContabilLote);
    }
    if (!nullToAbsent || dataLancamento != null) {
      map['data_lancamento'] = Variable<DateTime>(dataLancamento);
    }
    if (!nullToAbsent || dataInclusao != null) {
      map['data_inclusao'] = Variable<DateTime>(dataInclusao);
    }
    if (!nullToAbsent || tipo != null) {
      map['tipo'] = Variable<String>(tipo);
    }
    if (!nullToAbsent || liberado != null) {
      map['liberado'] = Variable<String>(liberado);
    }
    if (!nullToAbsent || valor != null) {
      map['valor'] = Variable<double>(valor);
    }
    return map;
  }

  factory ContabilLancamentoCabecalho.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return ContabilLancamentoCabecalho(
      id: serializer.fromJson<int?>(json['id']),
      idContabilLote: serializer.fromJson<int?>(json['idContabilLote']),
      dataLancamento: serializer.fromJson<DateTime?>(json['dataLancamento']),
      dataInclusao: serializer.fromJson<DateTime?>(json['dataInclusao']),
      tipo: serializer.fromJson<String?>(json['tipo']),
      liberado: serializer.fromJson<String?>(json['liberado']),
      valor: serializer.fromJson<double?>(json['valor']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'idContabilLote': serializer.toJson<int?>(idContabilLote),
      'dataLancamento': serializer.toJson<DateTime?>(dataLancamento),
      'dataInclusao': serializer.toJson<DateTime?>(dataInclusao),
      'tipo': serializer.toJson<String?>(tipo),
      'liberado': serializer.toJson<String?>(liberado),
      'valor': serializer.toJson<double?>(valor),
    };
  }

  ContabilLancamentoCabecalho copyWith(
          {Value<int?> id = const Value.absent(),
          Value<int?> idContabilLote = const Value.absent(),
          Value<DateTime?> dataLancamento = const Value.absent(),
          Value<DateTime?> dataInclusao = const Value.absent(),
          Value<String?> tipo = const Value.absent(),
          Value<String?> liberado = const Value.absent(),
          Value<double?> valor = const Value.absent()}) =>
      ContabilLancamentoCabecalho(
        id: id.present ? id.value : this.id,
        idContabilLote:
            idContabilLote.present ? idContabilLote.value : this.idContabilLote,
        dataLancamento:
            dataLancamento.present ? dataLancamento.value : this.dataLancamento,
        dataInclusao:
            dataInclusao.present ? dataInclusao.value : this.dataInclusao,
        tipo: tipo.present ? tipo.value : this.tipo,
        liberado: liberado.present ? liberado.value : this.liberado,
        valor: valor.present ? valor.value : this.valor,
      );
  ContabilLancamentoCabecalho copyWithCompanion(
      ContabilLancamentoCabecalhosCompanion data) {
    return ContabilLancamentoCabecalho(
      id: data.id.present ? data.id.value : this.id,
      idContabilLote: data.idContabilLote.present
          ? data.idContabilLote.value
          : this.idContabilLote,
      dataLancamento: data.dataLancamento.present
          ? data.dataLancamento.value
          : this.dataLancamento,
      dataInclusao: data.dataInclusao.present
          ? data.dataInclusao.value
          : this.dataInclusao,
      tipo: data.tipo.present ? data.tipo.value : this.tipo,
      liberado: data.liberado.present ? data.liberado.value : this.liberado,
      valor: data.valor.present ? data.valor.value : this.valor,
    );
  }

  @override
  String toString() {
    return (StringBuffer('ContabilLancamentoCabecalho(')
          ..write('id: $id, ')
          ..write('idContabilLote: $idContabilLote, ')
          ..write('dataLancamento: $dataLancamento, ')
          ..write('dataInclusao: $dataInclusao, ')
          ..write('tipo: $tipo, ')
          ..write('liberado: $liberado, ')
          ..write('valor: $valor')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(
      id, idContabilLote, dataLancamento, dataInclusao, tipo, liberado, valor);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is ContabilLancamentoCabecalho &&
          other.id == this.id &&
          other.idContabilLote == this.idContabilLote &&
          other.dataLancamento == this.dataLancamento &&
          other.dataInclusao == this.dataInclusao &&
          other.tipo == this.tipo &&
          other.liberado == this.liberado &&
          other.valor == this.valor);
}

class ContabilLancamentoCabecalhosCompanion
    extends UpdateCompanion<ContabilLancamentoCabecalho> {
  final Value<int?> id;
  final Value<int?> idContabilLote;
  final Value<DateTime?> dataLancamento;
  final Value<DateTime?> dataInclusao;
  final Value<String?> tipo;
  final Value<String?> liberado;
  final Value<double?> valor;
  const ContabilLancamentoCabecalhosCompanion({
    this.id = const Value.absent(),
    this.idContabilLote = const Value.absent(),
    this.dataLancamento = const Value.absent(),
    this.dataInclusao = const Value.absent(),
    this.tipo = const Value.absent(),
    this.liberado = const Value.absent(),
    this.valor = const Value.absent(),
  });
  ContabilLancamentoCabecalhosCompanion.insert({
    this.id = const Value.absent(),
    this.idContabilLote = const Value.absent(),
    this.dataLancamento = const Value.absent(),
    this.dataInclusao = const Value.absent(),
    this.tipo = const Value.absent(),
    this.liberado = const Value.absent(),
    this.valor = const Value.absent(),
  });
  static Insertable<ContabilLancamentoCabecalho> custom({
    Expression<int>? id,
    Expression<int>? idContabilLote,
    Expression<DateTime>? dataLancamento,
    Expression<DateTime>? dataInclusao,
    Expression<String>? tipo,
    Expression<String>? liberado,
    Expression<double>? valor,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (idContabilLote != null) 'id_contabil_lote': idContabilLote,
      if (dataLancamento != null) 'data_lancamento': dataLancamento,
      if (dataInclusao != null) 'data_inclusao': dataInclusao,
      if (tipo != null) 'tipo': tipo,
      if (liberado != null) 'liberado': liberado,
      if (valor != null) 'valor': valor,
    });
  }

  ContabilLancamentoCabecalhosCompanion copyWith(
      {Value<int?>? id,
      Value<int?>? idContabilLote,
      Value<DateTime?>? dataLancamento,
      Value<DateTime?>? dataInclusao,
      Value<String?>? tipo,
      Value<String?>? liberado,
      Value<double?>? valor}) {
    return ContabilLancamentoCabecalhosCompanion(
      id: id ?? this.id,
      idContabilLote: idContabilLote ?? this.idContabilLote,
      dataLancamento: dataLancamento ?? this.dataLancamento,
      dataInclusao: dataInclusao ?? this.dataInclusao,
      tipo: tipo ?? this.tipo,
      liberado: liberado ?? this.liberado,
      valor: valor ?? this.valor,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (idContabilLote.present) {
      map['id_contabil_lote'] = Variable<int>(idContabilLote.value);
    }
    if (dataLancamento.present) {
      map['data_lancamento'] = Variable<DateTime>(dataLancamento.value);
    }
    if (dataInclusao.present) {
      map['data_inclusao'] = Variable<DateTime>(dataInclusao.value);
    }
    if (tipo.present) {
      map['tipo'] = Variable<String>(tipo.value);
    }
    if (liberado.present) {
      map['liberado'] = Variable<String>(liberado.value);
    }
    if (valor.present) {
      map['valor'] = Variable<double>(valor.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('ContabilLancamentoCabecalhosCompanion(')
          ..write('id: $id, ')
          ..write('idContabilLote: $idContabilLote, ')
          ..write('dataLancamento: $dataLancamento, ')
          ..write('dataInclusao: $dataInclusao, ')
          ..write('tipo: $tipo, ')
          ..write('liberado: $liberado, ')
          ..write('valor: $valor')
          ..write(')'))
        .toString();
  }
}

class $ContabilDreCabecalhosTable extends ContabilDreCabecalhos
    with TableInfo<$ContabilDreCabecalhosTable, ContabilDreCabecalho> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $ContabilDreCabecalhosTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
      'id', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _descricaoMeta =
      const VerificationMeta('descricao');
  @override
  late final GeneratedColumn<String> descricao = GeneratedColumn<String>(
      'descricao', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 100),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _padraoMeta = const VerificationMeta('padrao');
  @override
  late final GeneratedColumn<String> padrao = GeneratedColumn<String>(
      'padrao', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 1),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _periodoInicialMeta =
      const VerificationMeta('periodoInicial');
  @override
  late final GeneratedColumn<String> periodoInicial = GeneratedColumn<String>(
      'periodo_inicial', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 7),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _periodoFinalMeta =
      const VerificationMeta('periodoFinal');
  @override
  late final GeneratedColumn<String> periodoFinal = GeneratedColumn<String>(
      'periodo_final', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 7),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  @override
  List<GeneratedColumn> get $columns =>
      [id, descricao, padrao, periodoInicial, periodoFinal];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'contabil_dre_cabecalho';
  @override
  VerificationContext validateIntegrity(
      Insertable<ContabilDreCabecalho> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('descricao')) {
      context.handle(_descricaoMeta,
          descricao.isAcceptableOrUnknown(data['descricao']!, _descricaoMeta));
    }
    if (data.containsKey('padrao')) {
      context.handle(_padraoMeta,
          padrao.isAcceptableOrUnknown(data['padrao']!, _padraoMeta));
    }
    if (data.containsKey('periodo_inicial')) {
      context.handle(
          _periodoInicialMeta,
          periodoInicial.isAcceptableOrUnknown(
              data['periodo_inicial']!, _periodoInicialMeta));
    }
    if (data.containsKey('periodo_final')) {
      context.handle(
          _periodoFinalMeta,
          periodoFinal.isAcceptableOrUnknown(
              data['periodo_final']!, _periodoFinalMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  ContabilDreCabecalho map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return ContabilDreCabecalho(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id']),
      descricao: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}descricao']),
      padrao: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}padrao']),
      periodoInicial: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}periodo_inicial']),
      periodoFinal: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}periodo_final']),
    );
  }

  @override
  $ContabilDreCabecalhosTable createAlias(String alias) {
    return $ContabilDreCabecalhosTable(attachedDatabase, alias);
  }
}

class ContabilDreCabecalho extends DataClass
    implements Insertable<ContabilDreCabecalho> {
  final int? id;
  final String? descricao;
  final String? padrao;
  final String? periodoInicial;
  final String? periodoFinal;
  const ContabilDreCabecalho(
      {this.id,
      this.descricao,
      this.padrao,
      this.periodoInicial,
      this.periodoFinal});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || descricao != null) {
      map['descricao'] = Variable<String>(descricao);
    }
    if (!nullToAbsent || padrao != null) {
      map['padrao'] = Variable<String>(padrao);
    }
    if (!nullToAbsent || periodoInicial != null) {
      map['periodo_inicial'] = Variable<String>(periodoInicial);
    }
    if (!nullToAbsent || periodoFinal != null) {
      map['periodo_final'] = Variable<String>(periodoFinal);
    }
    return map;
  }

  factory ContabilDreCabecalho.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return ContabilDreCabecalho(
      id: serializer.fromJson<int?>(json['id']),
      descricao: serializer.fromJson<String?>(json['descricao']),
      padrao: serializer.fromJson<String?>(json['padrao']),
      periodoInicial: serializer.fromJson<String?>(json['periodoInicial']),
      periodoFinal: serializer.fromJson<String?>(json['periodoFinal']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'descricao': serializer.toJson<String?>(descricao),
      'padrao': serializer.toJson<String?>(padrao),
      'periodoInicial': serializer.toJson<String?>(periodoInicial),
      'periodoFinal': serializer.toJson<String?>(periodoFinal),
    };
  }

  ContabilDreCabecalho copyWith(
          {Value<int?> id = const Value.absent(),
          Value<String?> descricao = const Value.absent(),
          Value<String?> padrao = const Value.absent(),
          Value<String?> periodoInicial = const Value.absent(),
          Value<String?> periodoFinal = const Value.absent()}) =>
      ContabilDreCabecalho(
        id: id.present ? id.value : this.id,
        descricao: descricao.present ? descricao.value : this.descricao,
        padrao: padrao.present ? padrao.value : this.padrao,
        periodoInicial:
            periodoInicial.present ? periodoInicial.value : this.periodoInicial,
        periodoFinal:
            periodoFinal.present ? periodoFinal.value : this.periodoFinal,
      );
  ContabilDreCabecalho copyWithCompanion(ContabilDreCabecalhosCompanion data) {
    return ContabilDreCabecalho(
      id: data.id.present ? data.id.value : this.id,
      descricao: data.descricao.present ? data.descricao.value : this.descricao,
      padrao: data.padrao.present ? data.padrao.value : this.padrao,
      periodoInicial: data.periodoInicial.present
          ? data.periodoInicial.value
          : this.periodoInicial,
      periodoFinal: data.periodoFinal.present
          ? data.periodoFinal.value
          : this.periodoFinal,
    );
  }

  @override
  String toString() {
    return (StringBuffer('ContabilDreCabecalho(')
          ..write('id: $id, ')
          ..write('descricao: $descricao, ')
          ..write('padrao: $padrao, ')
          ..write('periodoInicial: $periodoInicial, ')
          ..write('periodoFinal: $periodoFinal')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode =>
      Object.hash(id, descricao, padrao, periodoInicial, periodoFinal);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is ContabilDreCabecalho &&
          other.id == this.id &&
          other.descricao == this.descricao &&
          other.padrao == this.padrao &&
          other.periodoInicial == this.periodoInicial &&
          other.periodoFinal == this.periodoFinal);
}

class ContabilDreCabecalhosCompanion
    extends UpdateCompanion<ContabilDreCabecalho> {
  final Value<int?> id;
  final Value<String?> descricao;
  final Value<String?> padrao;
  final Value<String?> periodoInicial;
  final Value<String?> periodoFinal;
  const ContabilDreCabecalhosCompanion({
    this.id = const Value.absent(),
    this.descricao = const Value.absent(),
    this.padrao = const Value.absent(),
    this.periodoInicial = const Value.absent(),
    this.periodoFinal = const Value.absent(),
  });
  ContabilDreCabecalhosCompanion.insert({
    this.id = const Value.absent(),
    this.descricao = const Value.absent(),
    this.padrao = const Value.absent(),
    this.periodoInicial = const Value.absent(),
    this.periodoFinal = const Value.absent(),
  });
  static Insertable<ContabilDreCabecalho> custom({
    Expression<int>? id,
    Expression<String>? descricao,
    Expression<String>? padrao,
    Expression<String>? periodoInicial,
    Expression<String>? periodoFinal,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (descricao != null) 'descricao': descricao,
      if (padrao != null) 'padrao': padrao,
      if (periodoInicial != null) 'periodo_inicial': periodoInicial,
      if (periodoFinal != null) 'periodo_final': periodoFinal,
    });
  }

  ContabilDreCabecalhosCompanion copyWith(
      {Value<int?>? id,
      Value<String?>? descricao,
      Value<String?>? padrao,
      Value<String?>? periodoInicial,
      Value<String?>? periodoFinal}) {
    return ContabilDreCabecalhosCompanion(
      id: id ?? this.id,
      descricao: descricao ?? this.descricao,
      padrao: padrao ?? this.padrao,
      periodoInicial: periodoInicial ?? this.periodoInicial,
      periodoFinal: periodoFinal ?? this.periodoFinal,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (descricao.present) {
      map['descricao'] = Variable<String>(descricao.value);
    }
    if (padrao.present) {
      map['padrao'] = Variable<String>(padrao.value);
    }
    if (periodoInicial.present) {
      map['periodo_inicial'] = Variable<String>(periodoInicial.value);
    }
    if (periodoFinal.present) {
      map['periodo_final'] = Variable<String>(periodoFinal.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('ContabilDreCabecalhosCompanion(')
          ..write('id: $id, ')
          ..write('descricao: $descricao, ')
          ..write('padrao: $padrao, ')
          ..write('periodoInicial: $periodoInicial, ')
          ..write('periodoFinal: $periodoFinal')
          ..write(')'))
        .toString();
  }
}

class $ContabilLivrosTable extends ContabilLivros
    with TableInfo<$ContabilLivrosTable, ContabilLivro> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $ContabilLivrosTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
      'id', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _competenciaMeta =
      const VerificationMeta('competencia');
  @override
  late final GeneratedColumn<String> competencia = GeneratedColumn<String>(
      'competencia', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 7),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _formaEscrituracaoMeta =
      const VerificationMeta('formaEscrituracao');
  @override
  late final GeneratedColumn<String> formaEscrituracao =
      GeneratedColumn<String>('forma_escrituracao', aliasedName, true,
          additionalChecks: GeneratedColumn.checkTextLength(
              minTextLength: 0, maxTextLength: 1),
          type: DriftSqlType.string,
          requiredDuringInsert: false);
  static const VerificationMeta _descricaoMeta =
      const VerificationMeta('descricao');
  @override
  late final GeneratedColumn<String> descricao = GeneratedColumn<String>(
      'descricao', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 100),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  @override
  List<GeneratedColumn> get $columns =>
      [id, competencia, formaEscrituracao, descricao];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'contabil_livro';
  @override
  VerificationContext validateIntegrity(Insertable<ContabilLivro> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('competencia')) {
      context.handle(
          _competenciaMeta,
          competencia.isAcceptableOrUnknown(
              data['competencia']!, _competenciaMeta));
    }
    if (data.containsKey('forma_escrituracao')) {
      context.handle(
          _formaEscrituracaoMeta,
          formaEscrituracao.isAcceptableOrUnknown(
              data['forma_escrituracao']!, _formaEscrituracaoMeta));
    }
    if (data.containsKey('descricao')) {
      context.handle(_descricaoMeta,
          descricao.isAcceptableOrUnknown(data['descricao']!, _descricaoMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  ContabilLivro map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return ContabilLivro(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id']),
      competencia: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}competencia']),
      formaEscrituracao: attachedDatabase.typeMapping.read(
          DriftSqlType.string, data['${effectivePrefix}forma_escrituracao']),
      descricao: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}descricao']),
    );
  }

  @override
  $ContabilLivrosTable createAlias(String alias) {
    return $ContabilLivrosTable(attachedDatabase, alias);
  }
}

class ContabilLivro extends DataClass implements Insertable<ContabilLivro> {
  final int? id;
  final String? competencia;
  final String? formaEscrituracao;
  final String? descricao;
  const ContabilLivro(
      {this.id, this.competencia, this.formaEscrituracao, this.descricao});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || competencia != null) {
      map['competencia'] = Variable<String>(competencia);
    }
    if (!nullToAbsent || formaEscrituracao != null) {
      map['forma_escrituracao'] = Variable<String>(formaEscrituracao);
    }
    if (!nullToAbsent || descricao != null) {
      map['descricao'] = Variable<String>(descricao);
    }
    return map;
  }

  factory ContabilLivro.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return ContabilLivro(
      id: serializer.fromJson<int?>(json['id']),
      competencia: serializer.fromJson<String?>(json['competencia']),
      formaEscrituracao:
          serializer.fromJson<String?>(json['formaEscrituracao']),
      descricao: serializer.fromJson<String?>(json['descricao']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'competencia': serializer.toJson<String?>(competencia),
      'formaEscrituracao': serializer.toJson<String?>(formaEscrituracao),
      'descricao': serializer.toJson<String?>(descricao),
    };
  }

  ContabilLivro copyWith(
          {Value<int?> id = const Value.absent(),
          Value<String?> competencia = const Value.absent(),
          Value<String?> formaEscrituracao = const Value.absent(),
          Value<String?> descricao = const Value.absent()}) =>
      ContabilLivro(
        id: id.present ? id.value : this.id,
        competencia: competencia.present ? competencia.value : this.competencia,
        formaEscrituracao: formaEscrituracao.present
            ? formaEscrituracao.value
            : this.formaEscrituracao,
        descricao: descricao.present ? descricao.value : this.descricao,
      );
  ContabilLivro copyWithCompanion(ContabilLivrosCompanion data) {
    return ContabilLivro(
      id: data.id.present ? data.id.value : this.id,
      competencia:
          data.competencia.present ? data.competencia.value : this.competencia,
      formaEscrituracao: data.formaEscrituracao.present
          ? data.formaEscrituracao.value
          : this.formaEscrituracao,
      descricao: data.descricao.present ? data.descricao.value : this.descricao,
    );
  }

  @override
  String toString() {
    return (StringBuffer('ContabilLivro(')
          ..write('id: $id, ')
          ..write('competencia: $competencia, ')
          ..write('formaEscrituracao: $formaEscrituracao, ')
          ..write('descricao: $descricao')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode =>
      Object.hash(id, competencia, formaEscrituracao, descricao);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is ContabilLivro &&
          other.id == this.id &&
          other.competencia == this.competencia &&
          other.formaEscrituracao == this.formaEscrituracao &&
          other.descricao == this.descricao);
}

class ContabilLivrosCompanion extends UpdateCompanion<ContabilLivro> {
  final Value<int?> id;
  final Value<String?> competencia;
  final Value<String?> formaEscrituracao;
  final Value<String?> descricao;
  const ContabilLivrosCompanion({
    this.id = const Value.absent(),
    this.competencia = const Value.absent(),
    this.formaEscrituracao = const Value.absent(),
    this.descricao = const Value.absent(),
  });
  ContabilLivrosCompanion.insert({
    this.id = const Value.absent(),
    this.competencia = const Value.absent(),
    this.formaEscrituracao = const Value.absent(),
    this.descricao = const Value.absent(),
  });
  static Insertable<ContabilLivro> custom({
    Expression<int>? id,
    Expression<String>? competencia,
    Expression<String>? formaEscrituracao,
    Expression<String>? descricao,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (competencia != null) 'competencia': competencia,
      if (formaEscrituracao != null) 'forma_escrituracao': formaEscrituracao,
      if (descricao != null) 'descricao': descricao,
    });
  }

  ContabilLivrosCompanion copyWith(
      {Value<int?>? id,
      Value<String?>? competencia,
      Value<String?>? formaEscrituracao,
      Value<String?>? descricao}) {
    return ContabilLivrosCompanion(
      id: id ?? this.id,
      competencia: competencia ?? this.competencia,
      formaEscrituracao: formaEscrituracao ?? this.formaEscrituracao,
      descricao: descricao ?? this.descricao,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (competencia.present) {
      map['competencia'] = Variable<String>(competencia.value);
    }
    if (formaEscrituracao.present) {
      map['forma_escrituracao'] = Variable<String>(formaEscrituracao.value);
    }
    if (descricao.present) {
      map['descricao'] = Variable<String>(descricao.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('ContabilLivrosCompanion(')
          ..write('id: $id, ')
          ..write('competencia: $competencia, ')
          ..write('formaEscrituracao: $formaEscrituracao, ')
          ..write('descricao: $descricao')
          ..write(')'))
        .toString();
  }
}

class $ContabilEncerramentoExeCabsTable extends ContabilEncerramentoExeCabs
    with
        TableInfo<$ContabilEncerramentoExeCabsTable,
            ContabilEncerramentoExeCab> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $ContabilEncerramentoExeCabsTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
      'id', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _dataInicioMeta =
      const VerificationMeta('dataInicio');
  @override
  late final GeneratedColumn<DateTime> dataInicio = GeneratedColumn<DateTime>(
      'data_inicio', aliasedName, true,
      type: DriftSqlType.dateTime, requiredDuringInsert: false);
  static const VerificationMeta _dataFimMeta =
      const VerificationMeta('dataFim');
  @override
  late final GeneratedColumn<DateTime> dataFim = GeneratedColumn<DateTime>(
      'data_fim', aliasedName, true,
      type: DriftSqlType.dateTime, requiredDuringInsert: false);
  static const VerificationMeta _dataInclusaoMeta =
      const VerificationMeta('dataInclusao');
  @override
  late final GeneratedColumn<DateTime> dataInclusao = GeneratedColumn<DateTime>(
      'data_inclusao', aliasedName, true,
      type: DriftSqlType.dateTime, requiredDuringInsert: false);
  static const VerificationMeta _motivoMeta = const VerificationMeta('motivo');
  @override
  late final GeneratedColumn<String> motivo = GeneratedColumn<String>(
      'motivo', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 100),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  @override
  List<GeneratedColumn> get $columns =>
      [id, dataInicio, dataFim, dataInclusao, motivo];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'contabil_encerramento_exe_cab';
  @override
  VerificationContext validateIntegrity(
      Insertable<ContabilEncerramentoExeCab> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('data_inicio')) {
      context.handle(
          _dataInicioMeta,
          dataInicio.isAcceptableOrUnknown(
              data['data_inicio']!, _dataInicioMeta));
    }
    if (data.containsKey('data_fim')) {
      context.handle(_dataFimMeta,
          dataFim.isAcceptableOrUnknown(data['data_fim']!, _dataFimMeta));
    }
    if (data.containsKey('data_inclusao')) {
      context.handle(
          _dataInclusaoMeta,
          dataInclusao.isAcceptableOrUnknown(
              data['data_inclusao']!, _dataInclusaoMeta));
    }
    if (data.containsKey('motivo')) {
      context.handle(_motivoMeta,
          motivo.isAcceptableOrUnknown(data['motivo']!, _motivoMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  ContabilEncerramentoExeCab map(Map<String, dynamic> data,
      {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return ContabilEncerramentoExeCab(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id']),
      dataInicio: attachedDatabase.typeMapping
          .read(DriftSqlType.dateTime, data['${effectivePrefix}data_inicio']),
      dataFim: attachedDatabase.typeMapping
          .read(DriftSqlType.dateTime, data['${effectivePrefix}data_fim']),
      dataInclusao: attachedDatabase.typeMapping
          .read(DriftSqlType.dateTime, data['${effectivePrefix}data_inclusao']),
      motivo: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}motivo']),
    );
  }

  @override
  $ContabilEncerramentoExeCabsTable createAlias(String alias) {
    return $ContabilEncerramentoExeCabsTable(attachedDatabase, alias);
  }
}

class ContabilEncerramentoExeCab extends DataClass
    implements Insertable<ContabilEncerramentoExeCab> {
  final int? id;
  final DateTime? dataInicio;
  final DateTime? dataFim;
  final DateTime? dataInclusao;
  final String? motivo;
  const ContabilEncerramentoExeCab(
      {this.id, this.dataInicio, this.dataFim, this.dataInclusao, this.motivo});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || dataInicio != null) {
      map['data_inicio'] = Variable<DateTime>(dataInicio);
    }
    if (!nullToAbsent || dataFim != null) {
      map['data_fim'] = Variable<DateTime>(dataFim);
    }
    if (!nullToAbsent || dataInclusao != null) {
      map['data_inclusao'] = Variable<DateTime>(dataInclusao);
    }
    if (!nullToAbsent || motivo != null) {
      map['motivo'] = Variable<String>(motivo);
    }
    return map;
  }

  factory ContabilEncerramentoExeCab.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return ContabilEncerramentoExeCab(
      id: serializer.fromJson<int?>(json['id']),
      dataInicio: serializer.fromJson<DateTime?>(json['dataInicio']),
      dataFim: serializer.fromJson<DateTime?>(json['dataFim']),
      dataInclusao: serializer.fromJson<DateTime?>(json['dataInclusao']),
      motivo: serializer.fromJson<String?>(json['motivo']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'dataInicio': serializer.toJson<DateTime?>(dataInicio),
      'dataFim': serializer.toJson<DateTime?>(dataFim),
      'dataInclusao': serializer.toJson<DateTime?>(dataInclusao),
      'motivo': serializer.toJson<String?>(motivo),
    };
  }

  ContabilEncerramentoExeCab copyWith(
          {Value<int?> id = const Value.absent(),
          Value<DateTime?> dataInicio = const Value.absent(),
          Value<DateTime?> dataFim = const Value.absent(),
          Value<DateTime?> dataInclusao = const Value.absent(),
          Value<String?> motivo = const Value.absent()}) =>
      ContabilEncerramentoExeCab(
        id: id.present ? id.value : this.id,
        dataInicio: dataInicio.present ? dataInicio.value : this.dataInicio,
        dataFim: dataFim.present ? dataFim.value : this.dataFim,
        dataInclusao:
            dataInclusao.present ? dataInclusao.value : this.dataInclusao,
        motivo: motivo.present ? motivo.value : this.motivo,
      );
  ContabilEncerramentoExeCab copyWithCompanion(
      ContabilEncerramentoExeCabsCompanion data) {
    return ContabilEncerramentoExeCab(
      id: data.id.present ? data.id.value : this.id,
      dataInicio:
          data.dataInicio.present ? data.dataInicio.value : this.dataInicio,
      dataFim: data.dataFim.present ? data.dataFim.value : this.dataFim,
      dataInclusao: data.dataInclusao.present
          ? data.dataInclusao.value
          : this.dataInclusao,
      motivo: data.motivo.present ? data.motivo.value : this.motivo,
    );
  }

  @override
  String toString() {
    return (StringBuffer('ContabilEncerramentoExeCab(')
          ..write('id: $id, ')
          ..write('dataInicio: $dataInicio, ')
          ..write('dataFim: $dataFim, ')
          ..write('dataInclusao: $dataInclusao, ')
          ..write('motivo: $motivo')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode =>
      Object.hash(id, dataInicio, dataFim, dataInclusao, motivo);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is ContabilEncerramentoExeCab &&
          other.id == this.id &&
          other.dataInicio == this.dataInicio &&
          other.dataFim == this.dataFim &&
          other.dataInclusao == this.dataInclusao &&
          other.motivo == this.motivo);
}

class ContabilEncerramentoExeCabsCompanion
    extends UpdateCompanion<ContabilEncerramentoExeCab> {
  final Value<int?> id;
  final Value<DateTime?> dataInicio;
  final Value<DateTime?> dataFim;
  final Value<DateTime?> dataInclusao;
  final Value<String?> motivo;
  const ContabilEncerramentoExeCabsCompanion({
    this.id = const Value.absent(),
    this.dataInicio = const Value.absent(),
    this.dataFim = const Value.absent(),
    this.dataInclusao = const Value.absent(),
    this.motivo = const Value.absent(),
  });
  ContabilEncerramentoExeCabsCompanion.insert({
    this.id = const Value.absent(),
    this.dataInicio = const Value.absent(),
    this.dataFim = const Value.absent(),
    this.dataInclusao = const Value.absent(),
    this.motivo = const Value.absent(),
  });
  static Insertable<ContabilEncerramentoExeCab> custom({
    Expression<int>? id,
    Expression<DateTime>? dataInicio,
    Expression<DateTime>? dataFim,
    Expression<DateTime>? dataInclusao,
    Expression<String>? motivo,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (dataInicio != null) 'data_inicio': dataInicio,
      if (dataFim != null) 'data_fim': dataFim,
      if (dataInclusao != null) 'data_inclusao': dataInclusao,
      if (motivo != null) 'motivo': motivo,
    });
  }

  ContabilEncerramentoExeCabsCompanion copyWith(
      {Value<int?>? id,
      Value<DateTime?>? dataInicio,
      Value<DateTime?>? dataFim,
      Value<DateTime?>? dataInclusao,
      Value<String?>? motivo}) {
    return ContabilEncerramentoExeCabsCompanion(
      id: id ?? this.id,
      dataInicio: dataInicio ?? this.dataInicio,
      dataFim: dataFim ?? this.dataFim,
      dataInclusao: dataInclusao ?? this.dataInclusao,
      motivo: motivo ?? this.motivo,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (dataInicio.present) {
      map['data_inicio'] = Variable<DateTime>(dataInicio.value);
    }
    if (dataFim.present) {
      map['data_fim'] = Variable<DateTime>(dataFim.value);
    }
    if (dataInclusao.present) {
      map['data_inclusao'] = Variable<DateTime>(dataInclusao.value);
    }
    if (motivo.present) {
      map['motivo'] = Variable<String>(motivo.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('ContabilEncerramentoExeCabsCompanion(')
          ..write('id: $id, ')
          ..write('dataInicio: $dataInicio, ')
          ..write('dataFim: $dataFim, ')
          ..write('dataInclusao: $dataInclusao, ')
          ..write('motivo: $motivo')
          ..write(')'))
        .toString();
  }
}

class $CentroResultadosTable extends CentroResultados
    with TableInfo<$CentroResultadosTable, CentroResultado> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $CentroResultadosTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
      'id', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _idPlanoCentroResultadoMeta =
      const VerificationMeta('idPlanoCentroResultado');
  @override
  late final GeneratedColumn<int> idPlanoCentroResultado = GeneratedColumn<int>(
      'id_plano_centro_resultado', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _descricaoMeta =
      const VerificationMeta('descricao');
  @override
  late final GeneratedColumn<String> descricao = GeneratedColumn<String>(
      'descricao', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 100),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _classificacaoMeta =
      const VerificationMeta('classificacao');
  @override
  late final GeneratedColumn<String> classificacao = GeneratedColumn<String>(
      'classificacao', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 30),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _sofreRateiroMeta =
      const VerificationMeta('sofreRateiro');
  @override
  late final GeneratedColumn<String> sofreRateiro = GeneratedColumn<String>(
      'sofre_rateiro', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 1),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  @override
  List<GeneratedColumn> get $columns =>
      [id, idPlanoCentroResultado, descricao, classificacao, sofreRateiro];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'centro_resultado';
  @override
  VerificationContext validateIntegrity(Insertable<CentroResultado> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('id_plano_centro_resultado')) {
      context.handle(
          _idPlanoCentroResultadoMeta,
          idPlanoCentroResultado.isAcceptableOrUnknown(
              data['id_plano_centro_resultado']!, _idPlanoCentroResultadoMeta));
    }
    if (data.containsKey('descricao')) {
      context.handle(_descricaoMeta,
          descricao.isAcceptableOrUnknown(data['descricao']!, _descricaoMeta));
    }
    if (data.containsKey('classificacao')) {
      context.handle(
          _classificacaoMeta,
          classificacao.isAcceptableOrUnknown(
              data['classificacao']!, _classificacaoMeta));
    }
    if (data.containsKey('sofre_rateiro')) {
      context.handle(
          _sofreRateiroMeta,
          sofreRateiro.isAcceptableOrUnknown(
              data['sofre_rateiro']!, _sofreRateiroMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  CentroResultado map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return CentroResultado(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id']),
      idPlanoCentroResultado: attachedDatabase.typeMapping.read(
          DriftSqlType.int,
          data['${effectivePrefix}id_plano_centro_resultado']),
      descricao: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}descricao']),
      classificacao: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}classificacao']),
      sofreRateiro: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}sofre_rateiro']),
    );
  }

  @override
  $CentroResultadosTable createAlias(String alias) {
    return $CentroResultadosTable(attachedDatabase, alias);
  }
}

class CentroResultado extends DataClass implements Insertable<CentroResultado> {
  final int? id;
  final int? idPlanoCentroResultado;
  final String? descricao;
  final String? classificacao;
  final String? sofreRateiro;
  const CentroResultado(
      {this.id,
      this.idPlanoCentroResultado,
      this.descricao,
      this.classificacao,
      this.sofreRateiro});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || idPlanoCentroResultado != null) {
      map['id_plano_centro_resultado'] = Variable<int>(idPlanoCentroResultado);
    }
    if (!nullToAbsent || descricao != null) {
      map['descricao'] = Variable<String>(descricao);
    }
    if (!nullToAbsent || classificacao != null) {
      map['classificacao'] = Variable<String>(classificacao);
    }
    if (!nullToAbsent || sofreRateiro != null) {
      map['sofre_rateiro'] = Variable<String>(sofreRateiro);
    }
    return map;
  }

  factory CentroResultado.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return CentroResultado(
      id: serializer.fromJson<int?>(json['id']),
      idPlanoCentroResultado:
          serializer.fromJson<int?>(json['idPlanoCentroResultado']),
      descricao: serializer.fromJson<String?>(json['descricao']),
      classificacao: serializer.fromJson<String?>(json['classificacao']),
      sofreRateiro: serializer.fromJson<String?>(json['sofreRateiro']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'idPlanoCentroResultado': serializer.toJson<int?>(idPlanoCentroResultado),
      'descricao': serializer.toJson<String?>(descricao),
      'classificacao': serializer.toJson<String?>(classificacao),
      'sofreRateiro': serializer.toJson<String?>(sofreRateiro),
    };
  }

  CentroResultado copyWith(
          {Value<int?> id = const Value.absent(),
          Value<int?> idPlanoCentroResultado = const Value.absent(),
          Value<String?> descricao = const Value.absent(),
          Value<String?> classificacao = const Value.absent(),
          Value<String?> sofreRateiro = const Value.absent()}) =>
      CentroResultado(
        id: id.present ? id.value : this.id,
        idPlanoCentroResultado: idPlanoCentroResultado.present
            ? idPlanoCentroResultado.value
            : this.idPlanoCentroResultado,
        descricao: descricao.present ? descricao.value : this.descricao,
        classificacao:
            classificacao.present ? classificacao.value : this.classificacao,
        sofreRateiro:
            sofreRateiro.present ? sofreRateiro.value : this.sofreRateiro,
      );
  CentroResultado copyWithCompanion(CentroResultadosCompanion data) {
    return CentroResultado(
      id: data.id.present ? data.id.value : this.id,
      idPlanoCentroResultado: data.idPlanoCentroResultado.present
          ? data.idPlanoCentroResultado.value
          : this.idPlanoCentroResultado,
      descricao: data.descricao.present ? data.descricao.value : this.descricao,
      classificacao: data.classificacao.present
          ? data.classificacao.value
          : this.classificacao,
      sofreRateiro: data.sofreRateiro.present
          ? data.sofreRateiro.value
          : this.sofreRateiro,
    );
  }

  @override
  String toString() {
    return (StringBuffer('CentroResultado(')
          ..write('id: $id, ')
          ..write('idPlanoCentroResultado: $idPlanoCentroResultado, ')
          ..write('descricao: $descricao, ')
          ..write('classificacao: $classificacao, ')
          ..write('sofreRateiro: $sofreRateiro')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(
      id, idPlanoCentroResultado, descricao, classificacao, sofreRateiro);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is CentroResultado &&
          other.id == this.id &&
          other.idPlanoCentroResultado == this.idPlanoCentroResultado &&
          other.descricao == this.descricao &&
          other.classificacao == this.classificacao &&
          other.sofreRateiro == this.sofreRateiro);
}

class CentroResultadosCompanion extends UpdateCompanion<CentroResultado> {
  final Value<int?> id;
  final Value<int?> idPlanoCentroResultado;
  final Value<String?> descricao;
  final Value<String?> classificacao;
  final Value<String?> sofreRateiro;
  const CentroResultadosCompanion({
    this.id = const Value.absent(),
    this.idPlanoCentroResultado = const Value.absent(),
    this.descricao = const Value.absent(),
    this.classificacao = const Value.absent(),
    this.sofreRateiro = const Value.absent(),
  });
  CentroResultadosCompanion.insert({
    this.id = const Value.absent(),
    this.idPlanoCentroResultado = const Value.absent(),
    this.descricao = const Value.absent(),
    this.classificacao = const Value.absent(),
    this.sofreRateiro = const Value.absent(),
  });
  static Insertable<CentroResultado> custom({
    Expression<int>? id,
    Expression<int>? idPlanoCentroResultado,
    Expression<String>? descricao,
    Expression<String>? classificacao,
    Expression<String>? sofreRateiro,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (idPlanoCentroResultado != null)
        'id_plano_centro_resultado': idPlanoCentroResultado,
      if (descricao != null) 'descricao': descricao,
      if (classificacao != null) 'classificacao': classificacao,
      if (sofreRateiro != null) 'sofre_rateiro': sofreRateiro,
    });
  }

  CentroResultadosCompanion copyWith(
      {Value<int?>? id,
      Value<int?>? idPlanoCentroResultado,
      Value<String?>? descricao,
      Value<String?>? classificacao,
      Value<String?>? sofreRateiro}) {
    return CentroResultadosCompanion(
      id: id ?? this.id,
      idPlanoCentroResultado:
          idPlanoCentroResultado ?? this.idPlanoCentroResultado,
      descricao: descricao ?? this.descricao,
      classificacao: classificacao ?? this.classificacao,
      sofreRateiro: sofreRateiro ?? this.sofreRateiro,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (idPlanoCentroResultado.present) {
      map['id_plano_centro_resultado'] =
          Variable<int>(idPlanoCentroResultado.value);
    }
    if (descricao.present) {
      map['descricao'] = Variable<String>(descricao.value);
    }
    if (classificacao.present) {
      map['classificacao'] = Variable<String>(classificacao.value);
    }
    if (sofreRateiro.present) {
      map['sofre_rateiro'] = Variable<String>(sofreRateiro.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('CentroResultadosCompanion(')
          ..write('id: $id, ')
          ..write('idPlanoCentroResultado: $idPlanoCentroResultado, ')
          ..write('descricao: $descricao, ')
          ..write('classificacao: $classificacao, ')
          ..write('sofreRateiro: $sofreRateiro')
          ..write(')'))
        .toString();
  }
}

class $RateioCentroResultadoCabsTable extends RateioCentroResultadoCabs
    with TableInfo<$RateioCentroResultadoCabsTable, RateioCentroResultadoCab> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $RateioCentroResultadoCabsTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
      'id', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _idCentroResultadoMeta =
      const VerificationMeta('idCentroResultado');
  @override
  late final GeneratedColumn<int> idCentroResultado = GeneratedColumn<int>(
      'id_centro_resultado', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _descricaoMeta =
      const VerificationMeta('descricao');
  @override
  late final GeneratedColumn<String> descricao = GeneratedColumn<String>(
      'descricao', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 100),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  @override
  List<GeneratedColumn> get $columns => [id, idCentroResultado, descricao];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'rateio_centro_resultado_cab';
  @override
  VerificationContext validateIntegrity(
      Insertable<RateioCentroResultadoCab> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('id_centro_resultado')) {
      context.handle(
          _idCentroResultadoMeta,
          idCentroResultado.isAcceptableOrUnknown(
              data['id_centro_resultado']!, _idCentroResultadoMeta));
    }
    if (data.containsKey('descricao')) {
      context.handle(_descricaoMeta,
          descricao.isAcceptableOrUnknown(data['descricao']!, _descricaoMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  RateioCentroResultadoCab map(Map<String, dynamic> data,
      {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return RateioCentroResultadoCab(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id']),
      idCentroResultado: attachedDatabase.typeMapping.read(
          DriftSqlType.int, data['${effectivePrefix}id_centro_resultado']),
      descricao: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}descricao']),
    );
  }

  @override
  $RateioCentroResultadoCabsTable createAlias(String alias) {
    return $RateioCentroResultadoCabsTable(attachedDatabase, alias);
  }
}

class RateioCentroResultadoCab extends DataClass
    implements Insertable<RateioCentroResultadoCab> {
  final int? id;
  final int? idCentroResultado;
  final String? descricao;
  const RateioCentroResultadoCab(
      {this.id, this.idCentroResultado, this.descricao});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || idCentroResultado != null) {
      map['id_centro_resultado'] = Variable<int>(idCentroResultado);
    }
    if (!nullToAbsent || descricao != null) {
      map['descricao'] = Variable<String>(descricao);
    }
    return map;
  }

  factory RateioCentroResultadoCab.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return RateioCentroResultadoCab(
      id: serializer.fromJson<int?>(json['id']),
      idCentroResultado: serializer.fromJson<int?>(json['idCentroResultado']),
      descricao: serializer.fromJson<String?>(json['descricao']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'idCentroResultado': serializer.toJson<int?>(idCentroResultado),
      'descricao': serializer.toJson<String?>(descricao),
    };
  }

  RateioCentroResultadoCab copyWith(
          {Value<int?> id = const Value.absent(),
          Value<int?> idCentroResultado = const Value.absent(),
          Value<String?> descricao = const Value.absent()}) =>
      RateioCentroResultadoCab(
        id: id.present ? id.value : this.id,
        idCentroResultado: idCentroResultado.present
            ? idCentroResultado.value
            : this.idCentroResultado,
        descricao: descricao.present ? descricao.value : this.descricao,
      );
  RateioCentroResultadoCab copyWithCompanion(
      RateioCentroResultadoCabsCompanion data) {
    return RateioCentroResultadoCab(
      id: data.id.present ? data.id.value : this.id,
      idCentroResultado: data.idCentroResultado.present
          ? data.idCentroResultado.value
          : this.idCentroResultado,
      descricao: data.descricao.present ? data.descricao.value : this.descricao,
    );
  }

  @override
  String toString() {
    return (StringBuffer('RateioCentroResultadoCab(')
          ..write('id: $id, ')
          ..write('idCentroResultado: $idCentroResultado, ')
          ..write('descricao: $descricao')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(id, idCentroResultado, descricao);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is RateioCentroResultadoCab &&
          other.id == this.id &&
          other.idCentroResultado == this.idCentroResultado &&
          other.descricao == this.descricao);
}

class RateioCentroResultadoCabsCompanion
    extends UpdateCompanion<RateioCentroResultadoCab> {
  final Value<int?> id;
  final Value<int?> idCentroResultado;
  final Value<String?> descricao;
  const RateioCentroResultadoCabsCompanion({
    this.id = const Value.absent(),
    this.idCentroResultado = const Value.absent(),
    this.descricao = const Value.absent(),
  });
  RateioCentroResultadoCabsCompanion.insert({
    this.id = const Value.absent(),
    this.idCentroResultado = const Value.absent(),
    this.descricao = const Value.absent(),
  });
  static Insertable<RateioCentroResultadoCab> custom({
    Expression<int>? id,
    Expression<int>? idCentroResultado,
    Expression<String>? descricao,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (idCentroResultado != null) 'id_centro_resultado': idCentroResultado,
      if (descricao != null) 'descricao': descricao,
    });
  }

  RateioCentroResultadoCabsCompanion copyWith(
      {Value<int?>? id,
      Value<int?>? idCentroResultado,
      Value<String?>? descricao}) {
    return RateioCentroResultadoCabsCompanion(
      id: id ?? this.id,
      idCentroResultado: idCentroResultado ?? this.idCentroResultado,
      descricao: descricao ?? this.descricao,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (idCentroResultado.present) {
      map['id_centro_resultado'] = Variable<int>(idCentroResultado.value);
    }
    if (descricao.present) {
      map['descricao'] = Variable<String>(descricao.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('RateioCentroResultadoCabsCompanion(')
          ..write('id: $id, ')
          ..write('idCentroResultado: $idCentroResultado, ')
          ..write('descricao: $descricao')
          ..write(')'))
        .toString();
  }
}

class $ContabilIndicesTable extends ContabilIndices
    with TableInfo<$ContabilIndicesTable, ContabilIndice> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $ContabilIndicesTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
      'id', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _indiceMeta = const VerificationMeta('indice');
  @override
  late final GeneratedColumn<String> indice = GeneratedColumn<String>(
      'indice', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 50),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _periodicidadeMeta =
      const VerificationMeta('periodicidade');
  @override
  late final GeneratedColumn<String> periodicidade = GeneratedColumn<String>(
      'periodicidade', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 1),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _diarioAPartirDeMeta =
      const VerificationMeta('diarioAPartirDe');
  @override
  late final GeneratedColumn<DateTime> diarioAPartirDe =
      GeneratedColumn<DateTime>('diario_a_partir_de', aliasedName, true,
          type: DriftSqlType.dateTime, requiredDuringInsert: false);
  static const VerificationMeta _mensalMesAnoMeta =
      const VerificationMeta('mensalMesAno');
  @override
  late final GeneratedColumn<String> mensalMesAno = GeneratedColumn<String>(
      'mensal_mes_ano', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 7),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  @override
  List<GeneratedColumn> get $columns =>
      [id, indice, periodicidade, diarioAPartirDe, mensalMesAno];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'contabil_indice';
  @override
  VerificationContext validateIntegrity(Insertable<ContabilIndice> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('indice')) {
      context.handle(_indiceMeta,
          indice.isAcceptableOrUnknown(data['indice']!, _indiceMeta));
    }
    if (data.containsKey('periodicidade')) {
      context.handle(
          _periodicidadeMeta,
          periodicidade.isAcceptableOrUnknown(
              data['periodicidade']!, _periodicidadeMeta));
    }
    if (data.containsKey('diario_a_partir_de')) {
      context.handle(
          _diarioAPartirDeMeta,
          diarioAPartirDe.isAcceptableOrUnknown(
              data['diario_a_partir_de']!, _diarioAPartirDeMeta));
    }
    if (data.containsKey('mensal_mes_ano')) {
      context.handle(
          _mensalMesAnoMeta,
          mensalMesAno.isAcceptableOrUnknown(
              data['mensal_mes_ano']!, _mensalMesAnoMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  ContabilIndice map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return ContabilIndice(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id']),
      indice: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}indice']),
      periodicidade: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}periodicidade']),
      diarioAPartirDe: attachedDatabase.typeMapping.read(
          DriftSqlType.dateTime, data['${effectivePrefix}diario_a_partir_de']),
      mensalMesAno: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}mensal_mes_ano']),
    );
  }

  @override
  $ContabilIndicesTable createAlias(String alias) {
    return $ContabilIndicesTable(attachedDatabase, alias);
  }
}

class ContabilIndice extends DataClass implements Insertable<ContabilIndice> {
  final int? id;
  final String? indice;
  final String? periodicidade;
  final DateTime? diarioAPartirDe;
  final String? mensalMesAno;
  const ContabilIndice(
      {this.id,
      this.indice,
      this.periodicidade,
      this.diarioAPartirDe,
      this.mensalMesAno});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || indice != null) {
      map['indice'] = Variable<String>(indice);
    }
    if (!nullToAbsent || periodicidade != null) {
      map['periodicidade'] = Variable<String>(periodicidade);
    }
    if (!nullToAbsent || diarioAPartirDe != null) {
      map['diario_a_partir_de'] = Variable<DateTime>(diarioAPartirDe);
    }
    if (!nullToAbsent || mensalMesAno != null) {
      map['mensal_mes_ano'] = Variable<String>(mensalMesAno);
    }
    return map;
  }

  factory ContabilIndice.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return ContabilIndice(
      id: serializer.fromJson<int?>(json['id']),
      indice: serializer.fromJson<String?>(json['indice']),
      periodicidade: serializer.fromJson<String?>(json['periodicidade']),
      diarioAPartirDe: serializer.fromJson<DateTime?>(json['diarioAPartirDe']),
      mensalMesAno: serializer.fromJson<String?>(json['mensalMesAno']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'indice': serializer.toJson<String?>(indice),
      'periodicidade': serializer.toJson<String?>(periodicidade),
      'diarioAPartirDe': serializer.toJson<DateTime?>(diarioAPartirDe),
      'mensalMesAno': serializer.toJson<String?>(mensalMesAno),
    };
  }

  ContabilIndice copyWith(
          {Value<int?> id = const Value.absent(),
          Value<String?> indice = const Value.absent(),
          Value<String?> periodicidade = const Value.absent(),
          Value<DateTime?> diarioAPartirDe = const Value.absent(),
          Value<String?> mensalMesAno = const Value.absent()}) =>
      ContabilIndice(
        id: id.present ? id.value : this.id,
        indice: indice.present ? indice.value : this.indice,
        periodicidade:
            periodicidade.present ? periodicidade.value : this.periodicidade,
        diarioAPartirDe: diarioAPartirDe.present
            ? diarioAPartirDe.value
            : this.diarioAPartirDe,
        mensalMesAno:
            mensalMesAno.present ? mensalMesAno.value : this.mensalMesAno,
      );
  ContabilIndice copyWithCompanion(ContabilIndicesCompanion data) {
    return ContabilIndice(
      id: data.id.present ? data.id.value : this.id,
      indice: data.indice.present ? data.indice.value : this.indice,
      periodicidade: data.periodicidade.present
          ? data.periodicidade.value
          : this.periodicidade,
      diarioAPartirDe: data.diarioAPartirDe.present
          ? data.diarioAPartirDe.value
          : this.diarioAPartirDe,
      mensalMesAno: data.mensalMesAno.present
          ? data.mensalMesAno.value
          : this.mensalMesAno,
    );
  }

  @override
  String toString() {
    return (StringBuffer('ContabilIndice(')
          ..write('id: $id, ')
          ..write('indice: $indice, ')
          ..write('periodicidade: $periodicidade, ')
          ..write('diarioAPartirDe: $diarioAPartirDe, ')
          ..write('mensalMesAno: $mensalMesAno')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode =>
      Object.hash(id, indice, periodicidade, diarioAPartirDe, mensalMesAno);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is ContabilIndice &&
          other.id == this.id &&
          other.indice == this.indice &&
          other.periodicidade == this.periodicidade &&
          other.diarioAPartirDe == this.diarioAPartirDe &&
          other.mensalMesAno == this.mensalMesAno);
}

class ContabilIndicesCompanion extends UpdateCompanion<ContabilIndice> {
  final Value<int?> id;
  final Value<String?> indice;
  final Value<String?> periodicidade;
  final Value<DateTime?> diarioAPartirDe;
  final Value<String?> mensalMesAno;
  const ContabilIndicesCompanion({
    this.id = const Value.absent(),
    this.indice = const Value.absent(),
    this.periodicidade = const Value.absent(),
    this.diarioAPartirDe = const Value.absent(),
    this.mensalMesAno = const Value.absent(),
  });
  ContabilIndicesCompanion.insert({
    this.id = const Value.absent(),
    this.indice = const Value.absent(),
    this.periodicidade = const Value.absent(),
    this.diarioAPartirDe = const Value.absent(),
    this.mensalMesAno = const Value.absent(),
  });
  static Insertable<ContabilIndice> custom({
    Expression<int>? id,
    Expression<String>? indice,
    Expression<String>? periodicidade,
    Expression<DateTime>? diarioAPartirDe,
    Expression<String>? mensalMesAno,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (indice != null) 'indice': indice,
      if (periodicidade != null) 'periodicidade': periodicidade,
      if (diarioAPartirDe != null) 'diario_a_partir_de': diarioAPartirDe,
      if (mensalMesAno != null) 'mensal_mes_ano': mensalMesAno,
    });
  }

  ContabilIndicesCompanion copyWith(
      {Value<int?>? id,
      Value<String?>? indice,
      Value<String?>? periodicidade,
      Value<DateTime?>? diarioAPartirDe,
      Value<String?>? mensalMesAno}) {
    return ContabilIndicesCompanion(
      id: id ?? this.id,
      indice: indice ?? this.indice,
      periodicidade: periodicidade ?? this.periodicidade,
      diarioAPartirDe: diarioAPartirDe ?? this.diarioAPartirDe,
      mensalMesAno: mensalMesAno ?? this.mensalMesAno,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (indice.present) {
      map['indice'] = Variable<String>(indice.value);
    }
    if (periodicidade.present) {
      map['periodicidade'] = Variable<String>(periodicidade.value);
    }
    if (diarioAPartirDe.present) {
      map['diario_a_partir_de'] = Variable<DateTime>(diarioAPartirDe.value);
    }
    if (mensalMesAno.present) {
      map['mensal_mes_ano'] = Variable<String>(mensalMesAno.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('ContabilIndicesCompanion(')
          ..write('id: $id, ')
          ..write('indice: $indice, ')
          ..write('periodicidade: $periodicidade, ')
          ..write('diarioAPartirDe: $diarioAPartirDe, ')
          ..write('mensalMesAno: $mensalMesAno')
          ..write(')'))
        .toString();
  }
}

class $FinNaturezaFinanceirasTable extends FinNaturezaFinanceiras
    with TableInfo<$FinNaturezaFinanceirasTable, FinNaturezaFinanceira> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $FinNaturezaFinanceirasTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
      'id', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _codigoMeta = const VerificationMeta('codigo');
  @override
  late final GeneratedColumn<String> codigo = GeneratedColumn<String>(
      'codigo', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 4),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _descricaoMeta =
      const VerificationMeta('descricao');
  @override
  late final GeneratedColumn<String> descricao = GeneratedColumn<String>(
      'descricao', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 100),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _tipoMeta = const VerificationMeta('tipo');
  @override
  late final GeneratedColumn<String> tipo = GeneratedColumn<String>(
      'tipo', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 1),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _aplicacaoMeta =
      const VerificationMeta('aplicacao');
  @override
  late final GeneratedColumn<String> aplicacao = GeneratedColumn<String>(
      'aplicacao', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 250),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  @override
  List<GeneratedColumn> get $columns =>
      [id, codigo, descricao, tipo, aplicacao];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'fin_natureza_financeira';
  @override
  VerificationContext validateIntegrity(
      Insertable<FinNaturezaFinanceira> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('codigo')) {
      context.handle(_codigoMeta,
          codigo.isAcceptableOrUnknown(data['codigo']!, _codigoMeta));
    }
    if (data.containsKey('descricao')) {
      context.handle(_descricaoMeta,
          descricao.isAcceptableOrUnknown(data['descricao']!, _descricaoMeta));
    }
    if (data.containsKey('tipo')) {
      context.handle(
          _tipoMeta, tipo.isAcceptableOrUnknown(data['tipo']!, _tipoMeta));
    }
    if (data.containsKey('aplicacao')) {
      context.handle(_aplicacaoMeta,
          aplicacao.isAcceptableOrUnknown(data['aplicacao']!, _aplicacaoMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  FinNaturezaFinanceira map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return FinNaturezaFinanceira(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id']),
      codigo: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}codigo']),
      descricao: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}descricao']),
      tipo: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}tipo']),
      aplicacao: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}aplicacao']),
    );
  }

  @override
  $FinNaturezaFinanceirasTable createAlias(String alias) {
    return $FinNaturezaFinanceirasTable(attachedDatabase, alias);
  }
}

class FinNaturezaFinanceira extends DataClass
    implements Insertable<FinNaturezaFinanceira> {
  final int? id;
  final String? codigo;
  final String? descricao;
  final String? tipo;
  final String? aplicacao;
  const FinNaturezaFinanceira(
      {this.id, this.codigo, this.descricao, this.tipo, this.aplicacao});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || codigo != null) {
      map['codigo'] = Variable<String>(codigo);
    }
    if (!nullToAbsent || descricao != null) {
      map['descricao'] = Variable<String>(descricao);
    }
    if (!nullToAbsent || tipo != null) {
      map['tipo'] = Variable<String>(tipo);
    }
    if (!nullToAbsent || aplicacao != null) {
      map['aplicacao'] = Variable<String>(aplicacao);
    }
    return map;
  }

  factory FinNaturezaFinanceira.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return FinNaturezaFinanceira(
      id: serializer.fromJson<int?>(json['id']),
      codigo: serializer.fromJson<String?>(json['codigo']),
      descricao: serializer.fromJson<String?>(json['descricao']),
      tipo: serializer.fromJson<String?>(json['tipo']),
      aplicacao: serializer.fromJson<String?>(json['aplicacao']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'codigo': serializer.toJson<String?>(codigo),
      'descricao': serializer.toJson<String?>(descricao),
      'tipo': serializer.toJson<String?>(tipo),
      'aplicacao': serializer.toJson<String?>(aplicacao),
    };
  }

  FinNaturezaFinanceira copyWith(
          {Value<int?> id = const Value.absent(),
          Value<String?> codigo = const Value.absent(),
          Value<String?> descricao = const Value.absent(),
          Value<String?> tipo = const Value.absent(),
          Value<String?> aplicacao = const Value.absent()}) =>
      FinNaturezaFinanceira(
        id: id.present ? id.value : this.id,
        codigo: codigo.present ? codigo.value : this.codigo,
        descricao: descricao.present ? descricao.value : this.descricao,
        tipo: tipo.present ? tipo.value : this.tipo,
        aplicacao: aplicacao.present ? aplicacao.value : this.aplicacao,
      );
  FinNaturezaFinanceira copyWithCompanion(
      FinNaturezaFinanceirasCompanion data) {
    return FinNaturezaFinanceira(
      id: data.id.present ? data.id.value : this.id,
      codigo: data.codigo.present ? data.codigo.value : this.codigo,
      descricao: data.descricao.present ? data.descricao.value : this.descricao,
      tipo: data.tipo.present ? data.tipo.value : this.tipo,
      aplicacao: data.aplicacao.present ? data.aplicacao.value : this.aplicacao,
    );
  }

  @override
  String toString() {
    return (StringBuffer('FinNaturezaFinanceira(')
          ..write('id: $id, ')
          ..write('codigo: $codigo, ')
          ..write('descricao: $descricao, ')
          ..write('tipo: $tipo, ')
          ..write('aplicacao: $aplicacao')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(id, codigo, descricao, tipo, aplicacao);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is FinNaturezaFinanceira &&
          other.id == this.id &&
          other.codigo == this.codigo &&
          other.descricao == this.descricao &&
          other.tipo == this.tipo &&
          other.aplicacao == this.aplicacao);
}

class FinNaturezaFinanceirasCompanion
    extends UpdateCompanion<FinNaturezaFinanceira> {
  final Value<int?> id;
  final Value<String?> codigo;
  final Value<String?> descricao;
  final Value<String?> tipo;
  final Value<String?> aplicacao;
  const FinNaturezaFinanceirasCompanion({
    this.id = const Value.absent(),
    this.codigo = const Value.absent(),
    this.descricao = const Value.absent(),
    this.tipo = const Value.absent(),
    this.aplicacao = const Value.absent(),
  });
  FinNaturezaFinanceirasCompanion.insert({
    this.id = const Value.absent(),
    this.codigo = const Value.absent(),
    this.descricao = const Value.absent(),
    this.tipo = const Value.absent(),
    this.aplicacao = const Value.absent(),
  });
  static Insertable<FinNaturezaFinanceira> custom({
    Expression<int>? id,
    Expression<String>? codigo,
    Expression<String>? descricao,
    Expression<String>? tipo,
    Expression<String>? aplicacao,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (codigo != null) 'codigo': codigo,
      if (descricao != null) 'descricao': descricao,
      if (tipo != null) 'tipo': tipo,
      if (aplicacao != null) 'aplicacao': aplicacao,
    });
  }

  FinNaturezaFinanceirasCompanion copyWith(
      {Value<int?>? id,
      Value<String?>? codigo,
      Value<String?>? descricao,
      Value<String?>? tipo,
      Value<String?>? aplicacao}) {
    return FinNaturezaFinanceirasCompanion(
      id: id ?? this.id,
      codigo: codigo ?? this.codigo,
      descricao: descricao ?? this.descricao,
      tipo: tipo ?? this.tipo,
      aplicacao: aplicacao ?? this.aplicacao,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (codigo.present) {
      map['codigo'] = Variable<String>(codigo.value);
    }
    if (descricao.present) {
      map['descricao'] = Variable<String>(descricao.value);
    }
    if (tipo.present) {
      map['tipo'] = Variable<String>(tipo.value);
    }
    if (aplicacao.present) {
      map['aplicacao'] = Variable<String>(aplicacao.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('FinNaturezaFinanceirasCompanion(')
          ..write('id: $id, ')
          ..write('codigo: $codigo, ')
          ..write('descricao: $descricao, ')
          ..write('tipo: $tipo, ')
          ..write('aplicacao: $aplicacao')
          ..write(')'))
        .toString();
  }
}

class $AidfAimdfsTable extends AidfAimdfs
    with TableInfo<$AidfAimdfsTable, AidfAimdf> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $AidfAimdfsTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
      'id', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _numeroMeta = const VerificationMeta('numero');
  @override
  late final GeneratedColumn<int> numero = GeneratedColumn<int>(
      'numero', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _dataValidadeMeta =
      const VerificationMeta('dataValidade');
  @override
  late final GeneratedColumn<DateTime> dataValidade = GeneratedColumn<DateTime>(
      'data_validade', aliasedName, true,
      type: DriftSqlType.dateTime, requiredDuringInsert: false);
  static const VerificationMeta _dataAutorizacaoMeta =
      const VerificationMeta('dataAutorizacao');
  @override
  late final GeneratedColumn<DateTime> dataAutorizacao =
      GeneratedColumn<DateTime>('data_autorizacao', aliasedName, true,
          type: DriftSqlType.dateTime, requiredDuringInsert: false);
  static const VerificationMeta _numeroAutorizacaoMeta =
      const VerificationMeta('numeroAutorizacao');
  @override
  late final GeneratedColumn<String> numeroAutorizacao =
      GeneratedColumn<String>('numero_autorizacao', aliasedName, true,
          additionalChecks: GeneratedColumn.checkTextLength(
              minTextLength: 0, maxTextLength: 20),
          type: DriftSqlType.string,
          requiredDuringInsert: false);
  static const VerificationMeta _formularioDisponivelMeta =
      const VerificationMeta('formularioDisponivel');
  @override
  late final GeneratedColumn<String> formularioDisponivel =
      GeneratedColumn<String>(
          'formulario_disponivel', aliasedName, true,
          additionalChecks: GeneratedColumn.checkTextLength(
              minTextLength: 0, maxTextLength: 1),
          type: DriftSqlType.string,
          requiredDuringInsert: false);
  @override
  List<GeneratedColumn> get $columns => [
        id,
        numero,
        dataValidade,
        dataAutorizacao,
        numeroAutorizacao,
        formularioDisponivel
      ];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'aidf_aimdf';
  @override
  VerificationContext validateIntegrity(Insertable<AidfAimdf> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('numero')) {
      context.handle(_numeroMeta,
          numero.isAcceptableOrUnknown(data['numero']!, _numeroMeta));
    }
    if (data.containsKey('data_validade')) {
      context.handle(
          _dataValidadeMeta,
          dataValidade.isAcceptableOrUnknown(
              data['data_validade']!, _dataValidadeMeta));
    }
    if (data.containsKey('data_autorizacao')) {
      context.handle(
          _dataAutorizacaoMeta,
          dataAutorizacao.isAcceptableOrUnknown(
              data['data_autorizacao']!, _dataAutorizacaoMeta));
    }
    if (data.containsKey('numero_autorizacao')) {
      context.handle(
          _numeroAutorizacaoMeta,
          numeroAutorizacao.isAcceptableOrUnknown(
              data['numero_autorizacao']!, _numeroAutorizacaoMeta));
    }
    if (data.containsKey('formulario_disponivel')) {
      context.handle(
          _formularioDisponivelMeta,
          formularioDisponivel.isAcceptableOrUnknown(
              data['formulario_disponivel']!, _formularioDisponivelMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  AidfAimdf map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return AidfAimdf(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id']),
      numero: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}numero']),
      dataValidade: attachedDatabase.typeMapping
          .read(DriftSqlType.dateTime, data['${effectivePrefix}data_validade']),
      dataAutorizacao: attachedDatabase.typeMapping.read(
          DriftSqlType.dateTime, data['${effectivePrefix}data_autorizacao']),
      numeroAutorizacao: attachedDatabase.typeMapping.read(
          DriftSqlType.string, data['${effectivePrefix}numero_autorizacao']),
      formularioDisponivel: attachedDatabase.typeMapping.read(
          DriftSqlType.string, data['${effectivePrefix}formulario_disponivel']),
    );
  }

  @override
  $AidfAimdfsTable createAlias(String alias) {
    return $AidfAimdfsTable(attachedDatabase, alias);
  }
}

class AidfAimdf extends DataClass implements Insertable<AidfAimdf> {
  final int? id;
  final int? numero;
  final DateTime? dataValidade;
  final DateTime? dataAutorizacao;
  final String? numeroAutorizacao;
  final String? formularioDisponivel;
  const AidfAimdf(
      {this.id,
      this.numero,
      this.dataValidade,
      this.dataAutorizacao,
      this.numeroAutorizacao,
      this.formularioDisponivel});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || numero != null) {
      map['numero'] = Variable<int>(numero);
    }
    if (!nullToAbsent || dataValidade != null) {
      map['data_validade'] = Variable<DateTime>(dataValidade);
    }
    if (!nullToAbsent || dataAutorizacao != null) {
      map['data_autorizacao'] = Variable<DateTime>(dataAutorizacao);
    }
    if (!nullToAbsent || numeroAutorizacao != null) {
      map['numero_autorizacao'] = Variable<String>(numeroAutorizacao);
    }
    if (!nullToAbsent || formularioDisponivel != null) {
      map['formulario_disponivel'] = Variable<String>(formularioDisponivel);
    }
    return map;
  }

  factory AidfAimdf.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return AidfAimdf(
      id: serializer.fromJson<int?>(json['id']),
      numero: serializer.fromJson<int?>(json['numero']),
      dataValidade: serializer.fromJson<DateTime?>(json['dataValidade']),
      dataAutorizacao: serializer.fromJson<DateTime?>(json['dataAutorizacao']),
      numeroAutorizacao:
          serializer.fromJson<String?>(json['numeroAutorizacao']),
      formularioDisponivel:
          serializer.fromJson<String?>(json['formularioDisponivel']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'numero': serializer.toJson<int?>(numero),
      'dataValidade': serializer.toJson<DateTime?>(dataValidade),
      'dataAutorizacao': serializer.toJson<DateTime?>(dataAutorizacao),
      'numeroAutorizacao': serializer.toJson<String?>(numeroAutorizacao),
      'formularioDisponivel': serializer.toJson<String?>(formularioDisponivel),
    };
  }

  AidfAimdf copyWith(
          {Value<int?> id = const Value.absent(),
          Value<int?> numero = const Value.absent(),
          Value<DateTime?> dataValidade = const Value.absent(),
          Value<DateTime?> dataAutorizacao = const Value.absent(),
          Value<String?> numeroAutorizacao = const Value.absent(),
          Value<String?> formularioDisponivel = const Value.absent()}) =>
      AidfAimdf(
        id: id.present ? id.value : this.id,
        numero: numero.present ? numero.value : this.numero,
        dataValidade:
            dataValidade.present ? dataValidade.value : this.dataValidade,
        dataAutorizacao: dataAutorizacao.present
            ? dataAutorizacao.value
            : this.dataAutorizacao,
        numeroAutorizacao: numeroAutorizacao.present
            ? numeroAutorizacao.value
            : this.numeroAutorizacao,
        formularioDisponivel: formularioDisponivel.present
            ? formularioDisponivel.value
            : this.formularioDisponivel,
      );
  AidfAimdf copyWithCompanion(AidfAimdfsCompanion data) {
    return AidfAimdf(
      id: data.id.present ? data.id.value : this.id,
      numero: data.numero.present ? data.numero.value : this.numero,
      dataValidade: data.dataValidade.present
          ? data.dataValidade.value
          : this.dataValidade,
      dataAutorizacao: data.dataAutorizacao.present
          ? data.dataAutorizacao.value
          : this.dataAutorizacao,
      numeroAutorizacao: data.numeroAutorizacao.present
          ? data.numeroAutorizacao.value
          : this.numeroAutorizacao,
      formularioDisponivel: data.formularioDisponivel.present
          ? data.formularioDisponivel.value
          : this.formularioDisponivel,
    );
  }

  @override
  String toString() {
    return (StringBuffer('AidfAimdf(')
          ..write('id: $id, ')
          ..write('numero: $numero, ')
          ..write('dataValidade: $dataValidade, ')
          ..write('dataAutorizacao: $dataAutorizacao, ')
          ..write('numeroAutorizacao: $numeroAutorizacao, ')
          ..write('formularioDisponivel: $formularioDisponivel')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(id, numero, dataValidade, dataAutorizacao,
      numeroAutorizacao, formularioDisponivel);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is AidfAimdf &&
          other.id == this.id &&
          other.numero == this.numero &&
          other.dataValidade == this.dataValidade &&
          other.dataAutorizacao == this.dataAutorizacao &&
          other.numeroAutorizacao == this.numeroAutorizacao &&
          other.formularioDisponivel == this.formularioDisponivel);
}

class AidfAimdfsCompanion extends UpdateCompanion<AidfAimdf> {
  final Value<int?> id;
  final Value<int?> numero;
  final Value<DateTime?> dataValidade;
  final Value<DateTime?> dataAutorizacao;
  final Value<String?> numeroAutorizacao;
  final Value<String?> formularioDisponivel;
  const AidfAimdfsCompanion({
    this.id = const Value.absent(),
    this.numero = const Value.absent(),
    this.dataValidade = const Value.absent(),
    this.dataAutorizacao = const Value.absent(),
    this.numeroAutorizacao = const Value.absent(),
    this.formularioDisponivel = const Value.absent(),
  });
  AidfAimdfsCompanion.insert({
    this.id = const Value.absent(),
    this.numero = const Value.absent(),
    this.dataValidade = const Value.absent(),
    this.dataAutorizacao = const Value.absent(),
    this.numeroAutorizacao = const Value.absent(),
    this.formularioDisponivel = const Value.absent(),
  });
  static Insertable<AidfAimdf> custom({
    Expression<int>? id,
    Expression<int>? numero,
    Expression<DateTime>? dataValidade,
    Expression<DateTime>? dataAutorizacao,
    Expression<String>? numeroAutorizacao,
    Expression<String>? formularioDisponivel,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (numero != null) 'numero': numero,
      if (dataValidade != null) 'data_validade': dataValidade,
      if (dataAutorizacao != null) 'data_autorizacao': dataAutorizacao,
      if (numeroAutorizacao != null) 'numero_autorizacao': numeroAutorizacao,
      if (formularioDisponivel != null)
        'formulario_disponivel': formularioDisponivel,
    });
  }

  AidfAimdfsCompanion copyWith(
      {Value<int?>? id,
      Value<int?>? numero,
      Value<DateTime?>? dataValidade,
      Value<DateTime?>? dataAutorizacao,
      Value<String?>? numeroAutorizacao,
      Value<String?>? formularioDisponivel}) {
    return AidfAimdfsCompanion(
      id: id ?? this.id,
      numero: numero ?? this.numero,
      dataValidade: dataValidade ?? this.dataValidade,
      dataAutorizacao: dataAutorizacao ?? this.dataAutorizacao,
      numeroAutorizacao: numeroAutorizacao ?? this.numeroAutorizacao,
      formularioDisponivel: formularioDisponivel ?? this.formularioDisponivel,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (numero.present) {
      map['numero'] = Variable<int>(numero.value);
    }
    if (dataValidade.present) {
      map['data_validade'] = Variable<DateTime>(dataValidade.value);
    }
    if (dataAutorizacao.present) {
      map['data_autorizacao'] = Variable<DateTime>(dataAutorizacao.value);
    }
    if (numeroAutorizacao.present) {
      map['numero_autorizacao'] = Variable<String>(numeroAutorizacao.value);
    }
    if (formularioDisponivel.present) {
      map['formulario_disponivel'] =
          Variable<String>(formularioDisponivel.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('AidfAimdfsCompanion(')
          ..write('id: $id, ')
          ..write('numero: $numero, ')
          ..write('dataValidade: $dataValidade, ')
          ..write('dataAutorizacao: $dataAutorizacao, ')
          ..write('numeroAutorizacao: $numeroAutorizacao, ')
          ..write('formularioDisponivel: $formularioDisponivel')
          ..write(')'))
        .toString();
  }
}

class $FapsTable extends Faps with TableInfo<$FapsTable, Fap> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $FapsTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
      'id', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _fapMeta = const VerificationMeta('fap');
  @override
  late final GeneratedColumn<double> fap = GeneratedColumn<double>(
      'fap', aliasedName, true,
      type: DriftSqlType.double, requiredDuringInsert: false);
  static const VerificationMeta _dataInicialMeta =
      const VerificationMeta('dataInicial');
  @override
  late final GeneratedColumn<DateTime> dataInicial = GeneratedColumn<DateTime>(
      'data_inicial', aliasedName, true,
      type: DriftSqlType.dateTime, requiredDuringInsert: false);
  static const VerificationMeta _dataFinalMeta =
      const VerificationMeta('dataFinal');
  @override
  late final GeneratedColumn<DateTime> dataFinal = GeneratedColumn<DateTime>(
      'data_final', aliasedName, true,
      type: DriftSqlType.dateTime, requiredDuringInsert: false);
  @override
  List<GeneratedColumn> get $columns => [id, fap, dataInicial, dataFinal];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'fap';
  @override
  VerificationContext validateIntegrity(Insertable<Fap> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('fap')) {
      context.handle(
          _fapMeta, fap.isAcceptableOrUnknown(data['fap']!, _fapMeta));
    }
    if (data.containsKey('data_inicial')) {
      context.handle(
          _dataInicialMeta,
          dataInicial.isAcceptableOrUnknown(
              data['data_inicial']!, _dataInicialMeta));
    }
    if (data.containsKey('data_final')) {
      context.handle(_dataFinalMeta,
          dataFinal.isAcceptableOrUnknown(data['data_final']!, _dataFinalMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  Fap map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return Fap(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id']),
      fap: attachedDatabase.typeMapping
          .read(DriftSqlType.double, data['${effectivePrefix}fap']),
      dataInicial: attachedDatabase.typeMapping
          .read(DriftSqlType.dateTime, data['${effectivePrefix}data_inicial']),
      dataFinal: attachedDatabase.typeMapping
          .read(DriftSqlType.dateTime, data['${effectivePrefix}data_final']),
    );
  }

  @override
  $FapsTable createAlias(String alias) {
    return $FapsTable(attachedDatabase, alias);
  }
}

class Fap extends DataClass implements Insertable<Fap> {
  final int? id;
  final double? fap;
  final DateTime? dataInicial;
  final DateTime? dataFinal;
  const Fap({this.id, this.fap, this.dataInicial, this.dataFinal});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || fap != null) {
      map['fap'] = Variable<double>(fap);
    }
    if (!nullToAbsent || dataInicial != null) {
      map['data_inicial'] = Variable<DateTime>(dataInicial);
    }
    if (!nullToAbsent || dataFinal != null) {
      map['data_final'] = Variable<DateTime>(dataFinal);
    }
    return map;
  }

  factory Fap.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return Fap(
      id: serializer.fromJson<int?>(json['id']),
      fap: serializer.fromJson<double?>(json['fap']),
      dataInicial: serializer.fromJson<DateTime?>(json['dataInicial']),
      dataFinal: serializer.fromJson<DateTime?>(json['dataFinal']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'fap': serializer.toJson<double?>(fap),
      'dataInicial': serializer.toJson<DateTime?>(dataInicial),
      'dataFinal': serializer.toJson<DateTime?>(dataFinal),
    };
  }

  Fap copyWith(
          {Value<int?> id = const Value.absent(),
          Value<double?> fap = const Value.absent(),
          Value<DateTime?> dataInicial = const Value.absent(),
          Value<DateTime?> dataFinal = const Value.absent()}) =>
      Fap(
        id: id.present ? id.value : this.id,
        fap: fap.present ? fap.value : this.fap,
        dataInicial: dataInicial.present ? dataInicial.value : this.dataInicial,
        dataFinal: dataFinal.present ? dataFinal.value : this.dataFinal,
      );
  Fap copyWithCompanion(FapsCompanion data) {
    return Fap(
      id: data.id.present ? data.id.value : this.id,
      fap: data.fap.present ? data.fap.value : this.fap,
      dataInicial:
          data.dataInicial.present ? data.dataInicial.value : this.dataInicial,
      dataFinal: data.dataFinal.present ? data.dataFinal.value : this.dataFinal,
    );
  }

  @override
  String toString() {
    return (StringBuffer('Fap(')
          ..write('id: $id, ')
          ..write('fap: $fap, ')
          ..write('dataInicial: $dataInicial, ')
          ..write('dataFinal: $dataFinal')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(id, fap, dataInicial, dataFinal);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is Fap &&
          other.id == this.id &&
          other.fap == this.fap &&
          other.dataInicial == this.dataInicial &&
          other.dataFinal == this.dataFinal);
}

class FapsCompanion extends UpdateCompanion<Fap> {
  final Value<int?> id;
  final Value<double?> fap;
  final Value<DateTime?> dataInicial;
  final Value<DateTime?> dataFinal;
  const FapsCompanion({
    this.id = const Value.absent(),
    this.fap = const Value.absent(),
    this.dataInicial = const Value.absent(),
    this.dataFinal = const Value.absent(),
  });
  FapsCompanion.insert({
    this.id = const Value.absent(),
    this.fap = const Value.absent(),
    this.dataInicial = const Value.absent(),
    this.dataFinal = const Value.absent(),
  });
  static Insertable<Fap> custom({
    Expression<int>? id,
    Expression<double>? fap,
    Expression<DateTime>? dataInicial,
    Expression<DateTime>? dataFinal,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (fap != null) 'fap': fap,
      if (dataInicial != null) 'data_inicial': dataInicial,
      if (dataFinal != null) 'data_final': dataFinal,
    });
  }

  FapsCompanion copyWith(
      {Value<int?>? id,
      Value<double?>? fap,
      Value<DateTime?>? dataInicial,
      Value<DateTime?>? dataFinal}) {
    return FapsCompanion(
      id: id ?? this.id,
      fap: fap ?? this.fap,
      dataInicial: dataInicial ?? this.dataInicial,
      dataFinal: dataFinal ?? this.dataFinal,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (fap.present) {
      map['fap'] = Variable<double>(fap.value);
    }
    if (dataInicial.present) {
      map['data_inicial'] = Variable<DateTime>(dataInicial.value);
    }
    if (dataFinal.present) {
      map['data_final'] = Variable<DateTime>(dataFinal.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('FapsCompanion(')
          ..write('id: $id, ')
          ..write('fap: $fap, ')
          ..write('dataInicial: $dataInicial, ')
          ..write('dataFinal: $dataFinal')
          ..write(')'))
        .toString();
  }
}

class $RegistroCartoriosTable extends RegistroCartorios
    with TableInfo<$RegistroCartoriosTable, RegistroCartorio> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $RegistroCartoriosTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
      'id', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _nomeCartorioMeta =
      const VerificationMeta('nomeCartorio');
  @override
  late final GeneratedColumn<String> nomeCartorio = GeneratedColumn<String>(
      'nome_cartorio', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 100),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _dataRegistroMeta =
      const VerificationMeta('dataRegistro');
  @override
  late final GeneratedColumn<DateTime> dataRegistro = GeneratedColumn<DateTime>(
      'data_registro', aliasedName, true,
      type: DriftSqlType.dateTime, requiredDuringInsert: false);
  static const VerificationMeta _numeroMeta = const VerificationMeta('numero');
  @override
  late final GeneratedColumn<int> numero = GeneratedColumn<int>(
      'numero', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _folhaMeta = const VerificationMeta('folha');
  @override
  late final GeneratedColumn<int> folha = GeneratedColumn<int>(
      'folha', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _livroMeta = const VerificationMeta('livro');
  @override
  late final GeneratedColumn<int> livro = GeneratedColumn<int>(
      'livro', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _nireMeta = const VerificationMeta('nire');
  @override
  late final GeneratedColumn<String> nire = GeneratedColumn<String>(
      'nire', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 11),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  @override
  List<GeneratedColumn> get $columns =>
      [id, nomeCartorio, dataRegistro, numero, folha, livro, nire];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'registro_cartorio';
  @override
  VerificationContext validateIntegrity(Insertable<RegistroCartorio> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('nome_cartorio')) {
      context.handle(
          _nomeCartorioMeta,
          nomeCartorio.isAcceptableOrUnknown(
              data['nome_cartorio']!, _nomeCartorioMeta));
    }
    if (data.containsKey('data_registro')) {
      context.handle(
          _dataRegistroMeta,
          dataRegistro.isAcceptableOrUnknown(
              data['data_registro']!, _dataRegistroMeta));
    }
    if (data.containsKey('numero')) {
      context.handle(_numeroMeta,
          numero.isAcceptableOrUnknown(data['numero']!, _numeroMeta));
    }
    if (data.containsKey('folha')) {
      context.handle(
          _folhaMeta, folha.isAcceptableOrUnknown(data['folha']!, _folhaMeta));
    }
    if (data.containsKey('livro')) {
      context.handle(
          _livroMeta, livro.isAcceptableOrUnknown(data['livro']!, _livroMeta));
    }
    if (data.containsKey('nire')) {
      context.handle(
          _nireMeta, nire.isAcceptableOrUnknown(data['nire']!, _nireMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  RegistroCartorio map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return RegistroCartorio(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id']),
      nomeCartorio: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}nome_cartorio']),
      dataRegistro: attachedDatabase.typeMapping
          .read(DriftSqlType.dateTime, data['${effectivePrefix}data_registro']),
      numero: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}numero']),
      folha: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}folha']),
      livro: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}livro']),
      nire: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}nire']),
    );
  }

  @override
  $RegistroCartoriosTable createAlias(String alias) {
    return $RegistroCartoriosTable(attachedDatabase, alias);
  }
}

class RegistroCartorio extends DataClass
    implements Insertable<RegistroCartorio> {
  final int? id;
  final String? nomeCartorio;
  final DateTime? dataRegistro;
  final int? numero;
  final int? folha;
  final int? livro;
  final String? nire;
  const RegistroCartorio(
      {this.id,
      this.nomeCartorio,
      this.dataRegistro,
      this.numero,
      this.folha,
      this.livro,
      this.nire});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || nomeCartorio != null) {
      map['nome_cartorio'] = Variable<String>(nomeCartorio);
    }
    if (!nullToAbsent || dataRegistro != null) {
      map['data_registro'] = Variable<DateTime>(dataRegistro);
    }
    if (!nullToAbsent || numero != null) {
      map['numero'] = Variable<int>(numero);
    }
    if (!nullToAbsent || folha != null) {
      map['folha'] = Variable<int>(folha);
    }
    if (!nullToAbsent || livro != null) {
      map['livro'] = Variable<int>(livro);
    }
    if (!nullToAbsent || nire != null) {
      map['nire'] = Variable<String>(nire);
    }
    return map;
  }

  factory RegistroCartorio.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return RegistroCartorio(
      id: serializer.fromJson<int?>(json['id']),
      nomeCartorio: serializer.fromJson<String?>(json['nomeCartorio']),
      dataRegistro: serializer.fromJson<DateTime?>(json['dataRegistro']),
      numero: serializer.fromJson<int?>(json['numero']),
      folha: serializer.fromJson<int?>(json['folha']),
      livro: serializer.fromJson<int?>(json['livro']),
      nire: serializer.fromJson<String?>(json['nire']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'nomeCartorio': serializer.toJson<String?>(nomeCartorio),
      'dataRegistro': serializer.toJson<DateTime?>(dataRegistro),
      'numero': serializer.toJson<int?>(numero),
      'folha': serializer.toJson<int?>(folha),
      'livro': serializer.toJson<int?>(livro),
      'nire': serializer.toJson<String?>(nire),
    };
  }

  RegistroCartorio copyWith(
          {Value<int?> id = const Value.absent(),
          Value<String?> nomeCartorio = const Value.absent(),
          Value<DateTime?> dataRegistro = const Value.absent(),
          Value<int?> numero = const Value.absent(),
          Value<int?> folha = const Value.absent(),
          Value<int?> livro = const Value.absent(),
          Value<String?> nire = const Value.absent()}) =>
      RegistroCartorio(
        id: id.present ? id.value : this.id,
        nomeCartorio:
            nomeCartorio.present ? nomeCartorio.value : this.nomeCartorio,
        dataRegistro:
            dataRegistro.present ? dataRegistro.value : this.dataRegistro,
        numero: numero.present ? numero.value : this.numero,
        folha: folha.present ? folha.value : this.folha,
        livro: livro.present ? livro.value : this.livro,
        nire: nire.present ? nire.value : this.nire,
      );
  RegistroCartorio copyWithCompanion(RegistroCartoriosCompanion data) {
    return RegistroCartorio(
      id: data.id.present ? data.id.value : this.id,
      nomeCartorio: data.nomeCartorio.present
          ? data.nomeCartorio.value
          : this.nomeCartorio,
      dataRegistro: data.dataRegistro.present
          ? data.dataRegistro.value
          : this.dataRegistro,
      numero: data.numero.present ? data.numero.value : this.numero,
      folha: data.folha.present ? data.folha.value : this.folha,
      livro: data.livro.present ? data.livro.value : this.livro,
      nire: data.nire.present ? data.nire.value : this.nire,
    );
  }

  @override
  String toString() {
    return (StringBuffer('RegistroCartorio(')
          ..write('id: $id, ')
          ..write('nomeCartorio: $nomeCartorio, ')
          ..write('dataRegistro: $dataRegistro, ')
          ..write('numero: $numero, ')
          ..write('folha: $folha, ')
          ..write('livro: $livro, ')
          ..write('nire: $nire')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode =>
      Object.hash(id, nomeCartorio, dataRegistro, numero, folha, livro, nire);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is RegistroCartorio &&
          other.id == this.id &&
          other.nomeCartorio == this.nomeCartorio &&
          other.dataRegistro == this.dataRegistro &&
          other.numero == this.numero &&
          other.folha == this.folha &&
          other.livro == this.livro &&
          other.nire == this.nire);
}

class RegistroCartoriosCompanion extends UpdateCompanion<RegistroCartorio> {
  final Value<int?> id;
  final Value<String?> nomeCartorio;
  final Value<DateTime?> dataRegistro;
  final Value<int?> numero;
  final Value<int?> folha;
  final Value<int?> livro;
  final Value<String?> nire;
  const RegistroCartoriosCompanion({
    this.id = const Value.absent(),
    this.nomeCartorio = const Value.absent(),
    this.dataRegistro = const Value.absent(),
    this.numero = const Value.absent(),
    this.folha = const Value.absent(),
    this.livro = const Value.absent(),
    this.nire = const Value.absent(),
  });
  RegistroCartoriosCompanion.insert({
    this.id = const Value.absent(),
    this.nomeCartorio = const Value.absent(),
    this.dataRegistro = const Value.absent(),
    this.numero = const Value.absent(),
    this.folha = const Value.absent(),
    this.livro = const Value.absent(),
    this.nire = const Value.absent(),
  });
  static Insertable<RegistroCartorio> custom({
    Expression<int>? id,
    Expression<String>? nomeCartorio,
    Expression<DateTime>? dataRegistro,
    Expression<int>? numero,
    Expression<int>? folha,
    Expression<int>? livro,
    Expression<String>? nire,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (nomeCartorio != null) 'nome_cartorio': nomeCartorio,
      if (dataRegistro != null) 'data_registro': dataRegistro,
      if (numero != null) 'numero': numero,
      if (folha != null) 'folha': folha,
      if (livro != null) 'livro': livro,
      if (nire != null) 'nire': nire,
    });
  }

  RegistroCartoriosCompanion copyWith(
      {Value<int?>? id,
      Value<String?>? nomeCartorio,
      Value<DateTime?>? dataRegistro,
      Value<int?>? numero,
      Value<int?>? folha,
      Value<int?>? livro,
      Value<String?>? nire}) {
    return RegistroCartoriosCompanion(
      id: id ?? this.id,
      nomeCartorio: nomeCartorio ?? this.nomeCartorio,
      dataRegistro: dataRegistro ?? this.dataRegistro,
      numero: numero ?? this.numero,
      folha: folha ?? this.folha,
      livro: livro ?? this.livro,
      nire: nire ?? this.nire,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (nomeCartorio.present) {
      map['nome_cartorio'] = Variable<String>(nomeCartorio.value);
    }
    if (dataRegistro.present) {
      map['data_registro'] = Variable<DateTime>(dataRegistro.value);
    }
    if (numero.present) {
      map['numero'] = Variable<int>(numero.value);
    }
    if (folha.present) {
      map['folha'] = Variable<int>(folha.value);
    }
    if (livro.present) {
      map['livro'] = Variable<int>(livro.value);
    }
    if (nire.present) {
      map['nire'] = Variable<String>(nire.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('RegistroCartoriosCompanion(')
          ..write('id: $id, ')
          ..write('nomeCartorio: $nomeCartorio, ')
          ..write('dataRegistro: $dataRegistro, ')
          ..write('numero: $numero, ')
          ..write('folha: $folha, ')
          ..write('livro: $livro, ')
          ..write('nire: $nire')
          ..write(')'))
        .toString();
  }
}

class $ContabilParametrosTable extends ContabilParametros
    with TableInfo<$ContabilParametrosTable, ContabilParametro> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $ContabilParametrosTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
      'id', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _mascaraMeta =
      const VerificationMeta('mascara');
  @override
  late final GeneratedColumn<String> mascara = GeneratedColumn<String>(
      'mascara', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 30),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _niveisMeta = const VerificationMeta('niveis');
  @override
  late final GeneratedColumn<int> niveis = GeneratedColumn<int>(
      'niveis', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _informarContaPorMeta =
      const VerificationMeta('informarContaPor');
  @override
  late final GeneratedColumn<String> informarContaPor = GeneratedColumn<String>(
      'informar_conta_por', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 1),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _compartilhaPlanoContaMeta =
      const VerificationMeta('compartilhaPlanoConta');
  @override
  late final GeneratedColumn<String> compartilhaPlanoConta =
      GeneratedColumn<String>('compartilha_plano_conta', aliasedName, true,
          additionalChecks: GeneratedColumn.checkTextLength(
              minTextLength: 0, maxTextLength: 1),
          type: DriftSqlType.string,
          requiredDuringInsert: false);
  static const VerificationMeta _compartilhaHistoricosMeta =
      const VerificationMeta('compartilhaHistoricos');
  @override
  late final GeneratedColumn<String> compartilhaHistoricos =
      GeneratedColumn<String>('compartilha_historicos', aliasedName, true,
          additionalChecks: GeneratedColumn.checkTextLength(
              minTextLength: 0, maxTextLength: 1),
          type: DriftSqlType.string,
          requiredDuringInsert: false);
  static const VerificationMeta _alteraLancamentoOutroMeta =
      const VerificationMeta('alteraLancamentoOutro');
  @override
  late final GeneratedColumn<String> alteraLancamentoOutro =
      GeneratedColumn<String>('altera_lancamento_outro', aliasedName, true,
          additionalChecks: GeneratedColumn.checkTextLength(
              minTextLength: 0, maxTextLength: 1),
          type: DriftSqlType.string,
          requiredDuringInsert: false);
  static const VerificationMeta _historicoObrigatorioMeta =
      const VerificationMeta('historicoObrigatorio');
  @override
  late final GeneratedColumn<String> historicoObrigatorio =
      GeneratedColumn<String>(
          'historico_obrigatorio', aliasedName, true,
          additionalChecks: GeneratedColumn.checkTextLength(
              minTextLength: 0, maxTextLength: 1),
          type: DriftSqlType.string,
          requiredDuringInsert: false);
  static const VerificationMeta _permiteLancamentoZeradoMeta =
      const VerificationMeta('permiteLancamentoZerado');
  @override
  late final GeneratedColumn<String> permiteLancamentoZerado =
      GeneratedColumn<String>('permite_lancamento_zerado', aliasedName, true,
          additionalChecks: GeneratedColumn.checkTextLength(
              minTextLength: 0, maxTextLength: 1),
          type: DriftSqlType.string,
          requiredDuringInsert: false);
  static const VerificationMeta _geraInformativoSpedMeta =
      const VerificationMeta('geraInformativoSped');
  @override
  late final GeneratedColumn<String> geraInformativoSped =
      GeneratedColumn<String>('gera_informativo_sped', aliasedName, true,
          additionalChecks: GeneratedColumn.checkTextLength(
              minTextLength: 0, maxTextLength: 1),
          type: DriftSqlType.string,
          requiredDuringInsert: false);
  static const VerificationMeta _spedFormaEscritDiarioMeta =
      const VerificationMeta('spedFormaEscritDiario');
  @override
  late final GeneratedColumn<String> spedFormaEscritDiario =
      GeneratedColumn<String>('sped_forma_escrit_diario', aliasedName, true,
          additionalChecks: GeneratedColumn.checkTextLength(
              minTextLength: 0, maxTextLength: 1),
          type: DriftSqlType.string,
          requiredDuringInsert: false);
  static const VerificationMeta _spedNomeLivroDiarioMeta =
      const VerificationMeta('spedNomeLivroDiario');
  @override
  late final GeneratedColumn<String> spedNomeLivroDiario =
      GeneratedColumn<String>('sped_nome_livro_diario', aliasedName, true,
          additionalChecks: GeneratedColumn.checkTextLength(
              minTextLength: 0, maxTextLength: 100),
          type: DriftSqlType.string,
          requiredDuringInsert: false);
  static const VerificationMeta _assinaturaDireitaMeta =
      const VerificationMeta('assinaturaDireita');
  @override
  late final GeneratedColumn<String> assinaturaDireita =
      GeneratedColumn<String>('assinatura_direita', aliasedName, true,
          type: DriftSqlType.string, requiredDuringInsert: false);
  static const VerificationMeta _assinaturaEsquerdaMeta =
      const VerificationMeta('assinaturaEsquerda');
  @override
  late final GeneratedColumn<String> assinaturaEsquerda =
      GeneratedColumn<String>('assinatura_esquerda', aliasedName, true,
          type: DriftSqlType.string, requiredDuringInsert: false);
  static const VerificationMeta _contaAtivoMeta =
      const VerificationMeta('contaAtivo');
  @override
  late final GeneratedColumn<String> contaAtivo = GeneratedColumn<String>(
      'conta_ativo', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 30),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _contaPassivoMeta =
      const VerificationMeta('contaPassivo');
  @override
  late final GeneratedColumn<String> contaPassivo = GeneratedColumn<String>(
      'conta_passivo', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 30),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _contaPatrimonioLiquidoMeta =
      const VerificationMeta('contaPatrimonioLiquido');
  @override
  late final GeneratedColumn<String> contaPatrimonioLiquido =
      GeneratedColumn<String>('conta_patrimonio_liquido', aliasedName, true,
          additionalChecks: GeneratedColumn.checkTextLength(
              minTextLength: 0, maxTextLength: 30),
          type: DriftSqlType.string,
          requiredDuringInsert: false);
  static const VerificationMeta _contaDepreciacaoAcumuladaMeta =
      const VerificationMeta('contaDepreciacaoAcumulada');
  @override
  late final GeneratedColumn<String> contaDepreciacaoAcumulada =
      GeneratedColumn<String>('conta_depreciacao_acumulada', aliasedName, true,
          additionalChecks: GeneratedColumn.checkTextLength(
              minTextLength: 0, maxTextLength: 30),
          type: DriftSqlType.string,
          requiredDuringInsert: false);
  static const VerificationMeta _contaCapitalSocialMeta =
      const VerificationMeta('contaCapitalSocial');
  @override
  late final GeneratedColumn<String> contaCapitalSocial =
      GeneratedColumn<String>('conta_capital_social', aliasedName, true,
          additionalChecks: GeneratedColumn.checkTextLength(
              minTextLength: 0, maxTextLength: 30),
          type: DriftSqlType.string,
          requiredDuringInsert: false);
  static const VerificationMeta _contaResultadoExercicioMeta =
      const VerificationMeta('contaResultadoExercicio');
  @override
  late final GeneratedColumn<String> contaResultadoExercicio =
      GeneratedColumn<String>('conta_resultado_exercicio', aliasedName, true,
          additionalChecks: GeneratedColumn.checkTextLength(
              minTextLength: 0, maxTextLength: 30),
          type: DriftSqlType.string,
          requiredDuringInsert: false);
  static const VerificationMeta _contaPrejuizoAcumuladoMeta =
      const VerificationMeta('contaPrejuizoAcumulado');
  @override
  late final GeneratedColumn<String> contaPrejuizoAcumulado =
      GeneratedColumn<String>('conta_prejuizo_acumulado', aliasedName, true,
          additionalChecks: GeneratedColumn.checkTextLength(
              minTextLength: 0, maxTextLength: 30),
          type: DriftSqlType.string,
          requiredDuringInsert: false);
  static const VerificationMeta _contaLucroAcumuladoMeta =
      const VerificationMeta('contaLucroAcumulado');
  @override
  late final GeneratedColumn<String> contaLucroAcumulado =
      GeneratedColumn<String>('conta_lucro_acumulado', aliasedName, true,
          additionalChecks: GeneratedColumn.checkTextLength(
              minTextLength: 0, maxTextLength: 30),
          type: DriftSqlType.string,
          requiredDuringInsert: false);
  static const VerificationMeta _contaTituloPagarMeta =
      const VerificationMeta('contaTituloPagar');
  @override
  late final GeneratedColumn<String> contaTituloPagar = GeneratedColumn<String>(
      'conta_titulo_pagar', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 30),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _contaTituloReceberMeta =
      const VerificationMeta('contaTituloReceber');
  @override
  late final GeneratedColumn<String> contaTituloReceber =
      GeneratedColumn<String>('conta_titulo_receber', aliasedName, true,
          additionalChecks: GeneratedColumn.checkTextLength(
              minTextLength: 0, maxTextLength: 30),
          type: DriftSqlType.string,
          requiredDuringInsert: false);
  static const VerificationMeta _contaJurosPassivoMeta =
      const VerificationMeta('contaJurosPassivo');
  @override
  late final GeneratedColumn<String> contaJurosPassivo =
      GeneratedColumn<String>('conta_juros_passivo', aliasedName, true,
          additionalChecks: GeneratedColumn.checkTextLength(
              minTextLength: 0, maxTextLength: 30),
          type: DriftSqlType.string,
          requiredDuringInsert: false);
  static const VerificationMeta _contaJurosAtivoMeta =
      const VerificationMeta('contaJurosAtivo');
  @override
  late final GeneratedColumn<String> contaJurosAtivo = GeneratedColumn<String>(
      'conta_juros_ativo', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 30),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _contaDescontoObtidoMeta =
      const VerificationMeta('contaDescontoObtido');
  @override
  late final GeneratedColumn<String> contaDescontoObtido =
      GeneratedColumn<String>('conta_desconto_obtido', aliasedName, true,
          additionalChecks: GeneratedColumn.checkTextLength(
              minTextLength: 0, maxTextLength: 30),
          type: DriftSqlType.string,
          requiredDuringInsert: false);
  static const VerificationMeta _contaDescontoConcedidoMeta =
      const VerificationMeta('contaDescontoConcedido');
  @override
  late final GeneratedColumn<String> contaDescontoConcedido =
      GeneratedColumn<String>('conta_desconto_concedido', aliasedName, true,
          additionalChecks: GeneratedColumn.checkTextLength(
              minTextLength: 0, maxTextLength: 30),
          type: DriftSqlType.string,
          requiredDuringInsert: false);
  static const VerificationMeta _contaCmvMeta =
      const VerificationMeta('contaCmv');
  @override
  late final GeneratedColumn<String> contaCmv = GeneratedColumn<String>(
      'conta_cmv', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 30),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _contaVendaMeta =
      const VerificationMeta('contaVenda');
  @override
  late final GeneratedColumn<String> contaVenda = GeneratedColumn<String>(
      'conta_venda', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 30),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _contaVendaServicoMeta =
      const VerificationMeta('contaVendaServico');
  @override
  late final GeneratedColumn<String> contaVendaServico =
      GeneratedColumn<String>('conta_venda_servico', aliasedName, true,
          additionalChecks: GeneratedColumn.checkTextLength(
              minTextLength: 0, maxTextLength: 30),
          type: DriftSqlType.string,
          requiredDuringInsert: false);
  static const VerificationMeta _contaEstoqueMeta =
      const VerificationMeta('contaEstoque');
  @override
  late final GeneratedColumn<String> contaEstoque = GeneratedColumn<String>(
      'conta_estoque', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 30),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _contaApuraResultadoMeta =
      const VerificationMeta('contaApuraResultado');
  @override
  late final GeneratedColumn<String> contaApuraResultado =
      GeneratedColumn<String>('conta_apura_resultado', aliasedName, true,
          additionalChecks: GeneratedColumn.checkTextLength(
              minTextLength: 0, maxTextLength: 30),
          type: DriftSqlType.string,
          requiredDuringInsert: false);
  static const VerificationMeta _contaJurosApropriarMeta =
      const VerificationMeta('contaJurosApropriar');
  @override
  late final GeneratedColumn<String> contaJurosApropriar =
      GeneratedColumn<String>('conta_juros_apropriar', aliasedName, true,
          additionalChecks: GeneratedColumn.checkTextLength(
              minTextLength: 0, maxTextLength: 30),
          type: DriftSqlType.string,
          requiredDuringInsert: false);
  static const VerificationMeta _idHistPadraoResultadoMeta =
      const VerificationMeta('idHistPadraoResultado');
  @override
  late final GeneratedColumn<int> idHistPadraoResultado = GeneratedColumn<int>(
      'id_hist_padrao_resultado', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _idHistPadraoLucroMeta =
      const VerificationMeta('idHistPadraoLucro');
  @override
  late final GeneratedColumn<int> idHistPadraoLucro = GeneratedColumn<int>(
      'id_hist_padrao_lucro', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _idHistPadraoPrejuizoMeta =
      const VerificationMeta('idHistPadraoPrejuizo');
  @override
  late final GeneratedColumn<int> idHistPadraoPrejuizo = GeneratedColumn<int>(
      'id_hist_padrao_prejuizo', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  @override
  List<GeneratedColumn> get $columns => [
        id,
        mascara,
        niveis,
        informarContaPor,
        compartilhaPlanoConta,
        compartilhaHistoricos,
        alteraLancamentoOutro,
        historicoObrigatorio,
        permiteLancamentoZerado,
        geraInformativoSped,
        spedFormaEscritDiario,
        spedNomeLivroDiario,
        assinaturaDireita,
        assinaturaEsquerda,
        contaAtivo,
        contaPassivo,
        contaPatrimonioLiquido,
        contaDepreciacaoAcumulada,
        contaCapitalSocial,
        contaResultadoExercicio,
        contaPrejuizoAcumulado,
        contaLucroAcumulado,
        contaTituloPagar,
        contaTituloReceber,
        contaJurosPassivo,
        contaJurosAtivo,
        contaDescontoObtido,
        contaDescontoConcedido,
        contaCmv,
        contaVenda,
        contaVendaServico,
        contaEstoque,
        contaApuraResultado,
        contaJurosApropriar,
        idHistPadraoResultado,
        idHistPadraoLucro,
        idHistPadraoPrejuizo
      ];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'contabil_parametro';
  @override
  VerificationContext validateIntegrity(Insertable<ContabilParametro> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('mascara')) {
      context.handle(_mascaraMeta,
          mascara.isAcceptableOrUnknown(data['mascara']!, _mascaraMeta));
    }
    if (data.containsKey('niveis')) {
      context.handle(_niveisMeta,
          niveis.isAcceptableOrUnknown(data['niveis']!, _niveisMeta));
    }
    if (data.containsKey('informar_conta_por')) {
      context.handle(
          _informarContaPorMeta,
          informarContaPor.isAcceptableOrUnknown(
              data['informar_conta_por']!, _informarContaPorMeta));
    }
    if (data.containsKey('compartilha_plano_conta')) {
      context.handle(
          _compartilhaPlanoContaMeta,
          compartilhaPlanoConta.isAcceptableOrUnknown(
              data['compartilha_plano_conta']!, _compartilhaPlanoContaMeta));
    }
    if (data.containsKey('compartilha_historicos')) {
      context.handle(
          _compartilhaHistoricosMeta,
          compartilhaHistoricos.isAcceptableOrUnknown(
              data['compartilha_historicos']!, _compartilhaHistoricosMeta));
    }
    if (data.containsKey('altera_lancamento_outro')) {
      context.handle(
          _alteraLancamentoOutroMeta,
          alteraLancamentoOutro.isAcceptableOrUnknown(
              data['altera_lancamento_outro']!, _alteraLancamentoOutroMeta));
    }
    if (data.containsKey('historico_obrigatorio')) {
      context.handle(
          _historicoObrigatorioMeta,
          historicoObrigatorio.isAcceptableOrUnknown(
              data['historico_obrigatorio']!, _historicoObrigatorioMeta));
    }
    if (data.containsKey('permite_lancamento_zerado')) {
      context.handle(
          _permiteLancamentoZeradoMeta,
          permiteLancamentoZerado.isAcceptableOrUnknown(
              data['permite_lancamento_zerado']!,
              _permiteLancamentoZeradoMeta));
    }
    if (data.containsKey('gera_informativo_sped')) {
      context.handle(
          _geraInformativoSpedMeta,
          geraInformativoSped.isAcceptableOrUnknown(
              data['gera_informativo_sped']!, _geraInformativoSpedMeta));
    }
    if (data.containsKey('sped_forma_escrit_diario')) {
      context.handle(
          _spedFormaEscritDiarioMeta,
          spedFormaEscritDiario.isAcceptableOrUnknown(
              data['sped_forma_escrit_diario']!, _spedFormaEscritDiarioMeta));
    }
    if (data.containsKey('sped_nome_livro_diario')) {
      context.handle(
          _spedNomeLivroDiarioMeta,
          spedNomeLivroDiario.isAcceptableOrUnknown(
              data['sped_nome_livro_diario']!, _spedNomeLivroDiarioMeta));
    }
    if (data.containsKey('assinatura_direita')) {
      context.handle(
          _assinaturaDireitaMeta,
          assinaturaDireita.isAcceptableOrUnknown(
              data['assinatura_direita']!, _assinaturaDireitaMeta));
    }
    if (data.containsKey('assinatura_esquerda')) {
      context.handle(
          _assinaturaEsquerdaMeta,
          assinaturaEsquerda.isAcceptableOrUnknown(
              data['assinatura_esquerda']!, _assinaturaEsquerdaMeta));
    }
    if (data.containsKey('conta_ativo')) {
      context.handle(
          _contaAtivoMeta,
          contaAtivo.isAcceptableOrUnknown(
              data['conta_ativo']!, _contaAtivoMeta));
    }
    if (data.containsKey('conta_passivo')) {
      context.handle(
          _contaPassivoMeta,
          contaPassivo.isAcceptableOrUnknown(
              data['conta_passivo']!, _contaPassivoMeta));
    }
    if (data.containsKey('conta_patrimonio_liquido')) {
      context.handle(
          _contaPatrimonioLiquidoMeta,
          contaPatrimonioLiquido.isAcceptableOrUnknown(
              data['conta_patrimonio_liquido']!, _contaPatrimonioLiquidoMeta));
    }
    if (data.containsKey('conta_depreciacao_acumulada')) {
      context.handle(
          _contaDepreciacaoAcumuladaMeta,
          contaDepreciacaoAcumulada.isAcceptableOrUnknown(
              data['conta_depreciacao_acumulada']!,
              _contaDepreciacaoAcumuladaMeta));
    }
    if (data.containsKey('conta_capital_social')) {
      context.handle(
          _contaCapitalSocialMeta,
          contaCapitalSocial.isAcceptableOrUnknown(
              data['conta_capital_social']!, _contaCapitalSocialMeta));
    }
    if (data.containsKey('conta_resultado_exercicio')) {
      context.handle(
          _contaResultadoExercicioMeta,
          contaResultadoExercicio.isAcceptableOrUnknown(
              data['conta_resultado_exercicio']!,
              _contaResultadoExercicioMeta));
    }
    if (data.containsKey('conta_prejuizo_acumulado')) {
      context.handle(
          _contaPrejuizoAcumuladoMeta,
          contaPrejuizoAcumulado.isAcceptableOrUnknown(
              data['conta_prejuizo_acumulado']!, _contaPrejuizoAcumuladoMeta));
    }
    if (data.containsKey('conta_lucro_acumulado')) {
      context.handle(
          _contaLucroAcumuladoMeta,
          contaLucroAcumulado.isAcceptableOrUnknown(
              data['conta_lucro_acumulado']!, _contaLucroAcumuladoMeta));
    }
    if (data.containsKey('conta_titulo_pagar')) {
      context.handle(
          _contaTituloPagarMeta,
          contaTituloPagar.isAcceptableOrUnknown(
              data['conta_titulo_pagar']!, _contaTituloPagarMeta));
    }
    if (data.containsKey('conta_titulo_receber')) {
      context.handle(
          _contaTituloReceberMeta,
          contaTituloReceber.isAcceptableOrUnknown(
              data['conta_titulo_receber']!, _contaTituloReceberMeta));
    }
    if (data.containsKey('conta_juros_passivo')) {
      context.handle(
          _contaJurosPassivoMeta,
          contaJurosPassivo.isAcceptableOrUnknown(
              data['conta_juros_passivo']!, _contaJurosPassivoMeta));
    }
    if (data.containsKey('conta_juros_ativo')) {
      context.handle(
          _contaJurosAtivoMeta,
          contaJurosAtivo.isAcceptableOrUnknown(
              data['conta_juros_ativo']!, _contaJurosAtivoMeta));
    }
    if (data.containsKey('conta_desconto_obtido')) {
      context.handle(
          _contaDescontoObtidoMeta,
          contaDescontoObtido.isAcceptableOrUnknown(
              data['conta_desconto_obtido']!, _contaDescontoObtidoMeta));
    }
    if (data.containsKey('conta_desconto_concedido')) {
      context.handle(
          _contaDescontoConcedidoMeta,
          contaDescontoConcedido.isAcceptableOrUnknown(
              data['conta_desconto_concedido']!, _contaDescontoConcedidoMeta));
    }
    if (data.containsKey('conta_cmv')) {
      context.handle(_contaCmvMeta,
          contaCmv.isAcceptableOrUnknown(data['conta_cmv']!, _contaCmvMeta));
    }
    if (data.containsKey('conta_venda')) {
      context.handle(
          _contaVendaMeta,
          contaVenda.isAcceptableOrUnknown(
              data['conta_venda']!, _contaVendaMeta));
    }
    if (data.containsKey('conta_venda_servico')) {
      context.handle(
          _contaVendaServicoMeta,
          contaVendaServico.isAcceptableOrUnknown(
              data['conta_venda_servico']!, _contaVendaServicoMeta));
    }
    if (data.containsKey('conta_estoque')) {
      context.handle(
          _contaEstoqueMeta,
          contaEstoque.isAcceptableOrUnknown(
              data['conta_estoque']!, _contaEstoqueMeta));
    }
    if (data.containsKey('conta_apura_resultado')) {
      context.handle(
          _contaApuraResultadoMeta,
          contaApuraResultado.isAcceptableOrUnknown(
              data['conta_apura_resultado']!, _contaApuraResultadoMeta));
    }
    if (data.containsKey('conta_juros_apropriar')) {
      context.handle(
          _contaJurosApropriarMeta,
          contaJurosApropriar.isAcceptableOrUnknown(
              data['conta_juros_apropriar']!, _contaJurosApropriarMeta));
    }
    if (data.containsKey('id_hist_padrao_resultado')) {
      context.handle(
          _idHistPadraoResultadoMeta,
          idHistPadraoResultado.isAcceptableOrUnknown(
              data['id_hist_padrao_resultado']!, _idHistPadraoResultadoMeta));
    }
    if (data.containsKey('id_hist_padrao_lucro')) {
      context.handle(
          _idHistPadraoLucroMeta,
          idHistPadraoLucro.isAcceptableOrUnknown(
              data['id_hist_padrao_lucro']!, _idHistPadraoLucroMeta));
    }
    if (data.containsKey('id_hist_padrao_prejuizo')) {
      context.handle(
          _idHistPadraoPrejuizoMeta,
          idHistPadraoPrejuizo.isAcceptableOrUnknown(
              data['id_hist_padrao_prejuizo']!, _idHistPadraoPrejuizoMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  ContabilParametro map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return ContabilParametro(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id']),
      mascara: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}mascara']),
      niveis: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}niveis']),
      informarContaPor: attachedDatabase.typeMapping.read(
          DriftSqlType.string, data['${effectivePrefix}informar_conta_por']),
      compartilhaPlanoConta: attachedDatabase.typeMapping.read(
          DriftSqlType.string,
          data['${effectivePrefix}compartilha_plano_conta']),
      compartilhaHistoricos: attachedDatabase.typeMapping.read(
          DriftSqlType.string,
          data['${effectivePrefix}compartilha_historicos']),
      alteraLancamentoOutro: attachedDatabase.typeMapping.read(
          DriftSqlType.string,
          data['${effectivePrefix}altera_lancamento_outro']),
      historicoObrigatorio: attachedDatabase.typeMapping.read(
          DriftSqlType.string, data['${effectivePrefix}historico_obrigatorio']),
      permiteLancamentoZerado: attachedDatabase.typeMapping.read(
          DriftSqlType.string,
          data['${effectivePrefix}permite_lancamento_zerado']),
      geraInformativoSped: attachedDatabase.typeMapping.read(
          DriftSqlType.string, data['${effectivePrefix}gera_informativo_sped']),
      spedFormaEscritDiario: attachedDatabase.typeMapping.read(
          DriftSqlType.string,
          data['${effectivePrefix}sped_forma_escrit_diario']),
      spedNomeLivroDiario: attachedDatabase.typeMapping.read(
          DriftSqlType.string,
          data['${effectivePrefix}sped_nome_livro_diario']),
      assinaturaDireita: attachedDatabase.typeMapping.read(
          DriftSqlType.string, data['${effectivePrefix}assinatura_direita']),
      assinaturaEsquerda: attachedDatabase.typeMapping.read(
          DriftSqlType.string, data['${effectivePrefix}assinatura_esquerda']),
      contaAtivo: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}conta_ativo']),
      contaPassivo: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}conta_passivo']),
      contaPatrimonioLiquido: attachedDatabase.typeMapping.read(
          DriftSqlType.string,
          data['${effectivePrefix}conta_patrimonio_liquido']),
      contaDepreciacaoAcumulada: attachedDatabase.typeMapping.read(
          DriftSqlType.string,
          data['${effectivePrefix}conta_depreciacao_acumulada']),
      contaCapitalSocial: attachedDatabase.typeMapping.read(
          DriftSqlType.string, data['${effectivePrefix}conta_capital_social']),
      contaResultadoExercicio: attachedDatabase.typeMapping.read(
          DriftSqlType.string,
          data['${effectivePrefix}conta_resultado_exercicio']),
      contaPrejuizoAcumulado: attachedDatabase.typeMapping.read(
          DriftSqlType.string,
          data['${effectivePrefix}conta_prejuizo_acumulado']),
      contaLucroAcumulado: attachedDatabase.typeMapping.read(
          DriftSqlType.string, data['${effectivePrefix}conta_lucro_acumulado']),
      contaTituloPagar: attachedDatabase.typeMapping.read(
          DriftSqlType.string, data['${effectivePrefix}conta_titulo_pagar']),
      contaTituloReceber: attachedDatabase.typeMapping.read(
          DriftSqlType.string, data['${effectivePrefix}conta_titulo_receber']),
      contaJurosPassivo: attachedDatabase.typeMapping.read(
          DriftSqlType.string, data['${effectivePrefix}conta_juros_passivo']),
      contaJurosAtivo: attachedDatabase.typeMapping.read(
          DriftSqlType.string, data['${effectivePrefix}conta_juros_ativo']),
      contaDescontoObtido: attachedDatabase.typeMapping.read(
          DriftSqlType.string, data['${effectivePrefix}conta_desconto_obtido']),
      contaDescontoConcedido: attachedDatabase.typeMapping.read(
          DriftSqlType.string,
          data['${effectivePrefix}conta_desconto_concedido']),
      contaCmv: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}conta_cmv']),
      contaVenda: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}conta_venda']),
      contaVendaServico: attachedDatabase.typeMapping.read(
          DriftSqlType.string, data['${effectivePrefix}conta_venda_servico']),
      contaEstoque: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}conta_estoque']),
      contaApuraResultado: attachedDatabase.typeMapping.read(
          DriftSqlType.string, data['${effectivePrefix}conta_apura_resultado']),
      contaJurosApropriar: attachedDatabase.typeMapping.read(
          DriftSqlType.string, data['${effectivePrefix}conta_juros_apropriar']),
      idHistPadraoResultado: attachedDatabase.typeMapping.read(
          DriftSqlType.int, data['${effectivePrefix}id_hist_padrao_resultado']),
      idHistPadraoLucro: attachedDatabase.typeMapping.read(
          DriftSqlType.int, data['${effectivePrefix}id_hist_padrao_lucro']),
      idHistPadraoPrejuizo: attachedDatabase.typeMapping.read(
          DriftSqlType.int, data['${effectivePrefix}id_hist_padrao_prejuizo']),
    );
  }

  @override
  $ContabilParametrosTable createAlias(String alias) {
    return $ContabilParametrosTable(attachedDatabase, alias);
  }
}

class ContabilParametro extends DataClass
    implements Insertable<ContabilParametro> {
  final int? id;
  final String? mascara;
  final int? niveis;
  final String? informarContaPor;
  final String? compartilhaPlanoConta;
  final String? compartilhaHistoricos;
  final String? alteraLancamentoOutro;
  final String? historicoObrigatorio;
  final String? permiteLancamentoZerado;
  final String? geraInformativoSped;
  final String? spedFormaEscritDiario;
  final String? spedNomeLivroDiario;
  final String? assinaturaDireita;
  final String? assinaturaEsquerda;
  final String? contaAtivo;
  final String? contaPassivo;
  final String? contaPatrimonioLiquido;
  final String? contaDepreciacaoAcumulada;
  final String? contaCapitalSocial;
  final String? contaResultadoExercicio;
  final String? contaPrejuizoAcumulado;
  final String? contaLucroAcumulado;
  final String? contaTituloPagar;
  final String? contaTituloReceber;
  final String? contaJurosPassivo;
  final String? contaJurosAtivo;
  final String? contaDescontoObtido;
  final String? contaDescontoConcedido;
  final String? contaCmv;
  final String? contaVenda;
  final String? contaVendaServico;
  final String? contaEstoque;
  final String? contaApuraResultado;
  final String? contaJurosApropriar;
  final int? idHistPadraoResultado;
  final int? idHistPadraoLucro;
  final int? idHistPadraoPrejuizo;
  const ContabilParametro(
      {this.id,
      this.mascara,
      this.niveis,
      this.informarContaPor,
      this.compartilhaPlanoConta,
      this.compartilhaHistoricos,
      this.alteraLancamentoOutro,
      this.historicoObrigatorio,
      this.permiteLancamentoZerado,
      this.geraInformativoSped,
      this.spedFormaEscritDiario,
      this.spedNomeLivroDiario,
      this.assinaturaDireita,
      this.assinaturaEsquerda,
      this.contaAtivo,
      this.contaPassivo,
      this.contaPatrimonioLiquido,
      this.contaDepreciacaoAcumulada,
      this.contaCapitalSocial,
      this.contaResultadoExercicio,
      this.contaPrejuizoAcumulado,
      this.contaLucroAcumulado,
      this.contaTituloPagar,
      this.contaTituloReceber,
      this.contaJurosPassivo,
      this.contaJurosAtivo,
      this.contaDescontoObtido,
      this.contaDescontoConcedido,
      this.contaCmv,
      this.contaVenda,
      this.contaVendaServico,
      this.contaEstoque,
      this.contaApuraResultado,
      this.contaJurosApropriar,
      this.idHistPadraoResultado,
      this.idHistPadraoLucro,
      this.idHistPadraoPrejuizo});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || mascara != null) {
      map['mascara'] = Variable<String>(mascara);
    }
    if (!nullToAbsent || niveis != null) {
      map['niveis'] = Variable<int>(niveis);
    }
    if (!nullToAbsent || informarContaPor != null) {
      map['informar_conta_por'] = Variable<String>(informarContaPor);
    }
    if (!nullToAbsent || compartilhaPlanoConta != null) {
      map['compartilha_plano_conta'] = Variable<String>(compartilhaPlanoConta);
    }
    if (!nullToAbsent || compartilhaHistoricos != null) {
      map['compartilha_historicos'] = Variable<String>(compartilhaHistoricos);
    }
    if (!nullToAbsent || alteraLancamentoOutro != null) {
      map['altera_lancamento_outro'] = Variable<String>(alteraLancamentoOutro);
    }
    if (!nullToAbsent || historicoObrigatorio != null) {
      map['historico_obrigatorio'] = Variable<String>(historicoObrigatorio);
    }
    if (!nullToAbsent || permiteLancamentoZerado != null) {
      map['permite_lancamento_zerado'] =
          Variable<String>(permiteLancamentoZerado);
    }
    if (!nullToAbsent || geraInformativoSped != null) {
      map['gera_informativo_sped'] = Variable<String>(geraInformativoSped);
    }
    if (!nullToAbsent || spedFormaEscritDiario != null) {
      map['sped_forma_escrit_diario'] = Variable<String>(spedFormaEscritDiario);
    }
    if (!nullToAbsent || spedNomeLivroDiario != null) {
      map['sped_nome_livro_diario'] = Variable<String>(spedNomeLivroDiario);
    }
    if (!nullToAbsent || assinaturaDireita != null) {
      map['assinatura_direita'] = Variable<String>(assinaturaDireita);
    }
    if (!nullToAbsent || assinaturaEsquerda != null) {
      map['assinatura_esquerda'] = Variable<String>(assinaturaEsquerda);
    }
    if (!nullToAbsent || contaAtivo != null) {
      map['conta_ativo'] = Variable<String>(contaAtivo);
    }
    if (!nullToAbsent || contaPassivo != null) {
      map['conta_passivo'] = Variable<String>(contaPassivo);
    }
    if (!nullToAbsent || contaPatrimonioLiquido != null) {
      map['conta_patrimonio_liquido'] =
          Variable<String>(contaPatrimonioLiquido);
    }
    if (!nullToAbsent || contaDepreciacaoAcumulada != null) {
      map['conta_depreciacao_acumulada'] =
          Variable<String>(contaDepreciacaoAcumulada);
    }
    if (!nullToAbsent || contaCapitalSocial != null) {
      map['conta_capital_social'] = Variable<String>(contaCapitalSocial);
    }
    if (!nullToAbsent || contaResultadoExercicio != null) {
      map['conta_resultado_exercicio'] =
          Variable<String>(contaResultadoExercicio);
    }
    if (!nullToAbsent || contaPrejuizoAcumulado != null) {
      map['conta_prejuizo_acumulado'] =
          Variable<String>(contaPrejuizoAcumulado);
    }
    if (!nullToAbsent || contaLucroAcumulado != null) {
      map['conta_lucro_acumulado'] = Variable<String>(contaLucroAcumulado);
    }
    if (!nullToAbsent || contaTituloPagar != null) {
      map['conta_titulo_pagar'] = Variable<String>(contaTituloPagar);
    }
    if (!nullToAbsent || contaTituloReceber != null) {
      map['conta_titulo_receber'] = Variable<String>(contaTituloReceber);
    }
    if (!nullToAbsent || contaJurosPassivo != null) {
      map['conta_juros_passivo'] = Variable<String>(contaJurosPassivo);
    }
    if (!nullToAbsent || contaJurosAtivo != null) {
      map['conta_juros_ativo'] = Variable<String>(contaJurosAtivo);
    }
    if (!nullToAbsent || contaDescontoObtido != null) {
      map['conta_desconto_obtido'] = Variable<String>(contaDescontoObtido);
    }
    if (!nullToAbsent || contaDescontoConcedido != null) {
      map['conta_desconto_concedido'] =
          Variable<String>(contaDescontoConcedido);
    }
    if (!nullToAbsent || contaCmv != null) {
      map['conta_cmv'] = Variable<String>(contaCmv);
    }
    if (!nullToAbsent || contaVenda != null) {
      map['conta_venda'] = Variable<String>(contaVenda);
    }
    if (!nullToAbsent || contaVendaServico != null) {
      map['conta_venda_servico'] = Variable<String>(contaVendaServico);
    }
    if (!nullToAbsent || contaEstoque != null) {
      map['conta_estoque'] = Variable<String>(contaEstoque);
    }
    if (!nullToAbsent || contaApuraResultado != null) {
      map['conta_apura_resultado'] = Variable<String>(contaApuraResultado);
    }
    if (!nullToAbsent || contaJurosApropriar != null) {
      map['conta_juros_apropriar'] = Variable<String>(contaJurosApropriar);
    }
    if (!nullToAbsent || idHistPadraoResultado != null) {
      map['id_hist_padrao_resultado'] = Variable<int>(idHistPadraoResultado);
    }
    if (!nullToAbsent || idHistPadraoLucro != null) {
      map['id_hist_padrao_lucro'] = Variable<int>(idHistPadraoLucro);
    }
    if (!nullToAbsent || idHistPadraoPrejuizo != null) {
      map['id_hist_padrao_prejuizo'] = Variable<int>(idHistPadraoPrejuizo);
    }
    return map;
  }

  factory ContabilParametro.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return ContabilParametro(
      id: serializer.fromJson<int?>(json['id']),
      mascara: serializer.fromJson<String?>(json['mascara']),
      niveis: serializer.fromJson<int?>(json['niveis']),
      informarContaPor: serializer.fromJson<String?>(json['informarContaPor']),
      compartilhaPlanoConta:
          serializer.fromJson<String?>(json['compartilhaPlanoConta']),
      compartilhaHistoricos:
          serializer.fromJson<String?>(json['compartilhaHistoricos']),
      alteraLancamentoOutro:
          serializer.fromJson<String?>(json['alteraLancamentoOutro']),
      historicoObrigatorio:
          serializer.fromJson<String?>(json['historicoObrigatorio']),
      permiteLancamentoZerado:
          serializer.fromJson<String?>(json['permiteLancamentoZerado']),
      geraInformativoSped:
          serializer.fromJson<String?>(json['geraInformativoSped']),
      spedFormaEscritDiario:
          serializer.fromJson<String?>(json['spedFormaEscritDiario']),
      spedNomeLivroDiario:
          serializer.fromJson<String?>(json['spedNomeLivroDiario']),
      assinaturaDireita:
          serializer.fromJson<String?>(json['assinaturaDireita']),
      assinaturaEsquerda:
          serializer.fromJson<String?>(json['assinaturaEsquerda']),
      contaAtivo: serializer.fromJson<String?>(json['contaAtivo']),
      contaPassivo: serializer.fromJson<String?>(json['contaPassivo']),
      contaPatrimonioLiquido:
          serializer.fromJson<String?>(json['contaPatrimonioLiquido']),
      contaDepreciacaoAcumulada:
          serializer.fromJson<String?>(json['contaDepreciacaoAcumulada']),
      contaCapitalSocial:
          serializer.fromJson<String?>(json['contaCapitalSocial']),
      contaResultadoExercicio:
          serializer.fromJson<String?>(json['contaResultadoExercicio']),
      contaPrejuizoAcumulado:
          serializer.fromJson<String?>(json['contaPrejuizoAcumulado']),
      contaLucroAcumulado:
          serializer.fromJson<String?>(json['contaLucroAcumulado']),
      contaTituloPagar: serializer.fromJson<String?>(json['contaTituloPagar']),
      contaTituloReceber:
          serializer.fromJson<String?>(json['contaTituloReceber']),
      contaJurosPassivo:
          serializer.fromJson<String?>(json['contaJurosPassivo']),
      contaJurosAtivo: serializer.fromJson<String?>(json['contaJurosAtivo']),
      contaDescontoObtido:
          serializer.fromJson<String?>(json['contaDescontoObtido']),
      contaDescontoConcedido:
          serializer.fromJson<String?>(json['contaDescontoConcedido']),
      contaCmv: serializer.fromJson<String?>(json['contaCmv']),
      contaVenda: serializer.fromJson<String?>(json['contaVenda']),
      contaVendaServico:
          serializer.fromJson<String?>(json['contaVendaServico']),
      contaEstoque: serializer.fromJson<String?>(json['contaEstoque']),
      contaApuraResultado:
          serializer.fromJson<String?>(json['contaApuraResultado']),
      contaJurosApropriar:
          serializer.fromJson<String?>(json['contaJurosApropriar']),
      idHistPadraoResultado:
          serializer.fromJson<int?>(json['idHistPadraoResultado']),
      idHistPadraoLucro: serializer.fromJson<int?>(json['idHistPadraoLucro']),
      idHistPadraoPrejuizo:
          serializer.fromJson<int?>(json['idHistPadraoPrejuizo']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'mascara': serializer.toJson<String?>(mascara),
      'niveis': serializer.toJson<int?>(niveis),
      'informarContaPor': serializer.toJson<String?>(informarContaPor),
      'compartilhaPlanoConta':
          serializer.toJson<String?>(compartilhaPlanoConta),
      'compartilhaHistoricos':
          serializer.toJson<String?>(compartilhaHistoricos),
      'alteraLancamentoOutro':
          serializer.toJson<String?>(alteraLancamentoOutro),
      'historicoObrigatorio': serializer.toJson<String?>(historicoObrigatorio),
      'permiteLancamentoZerado':
          serializer.toJson<String?>(permiteLancamentoZerado),
      'geraInformativoSped': serializer.toJson<String?>(geraInformativoSped),
      'spedFormaEscritDiario':
          serializer.toJson<String?>(spedFormaEscritDiario),
      'spedNomeLivroDiario': serializer.toJson<String?>(spedNomeLivroDiario),
      'assinaturaDireita': serializer.toJson<String?>(assinaturaDireita),
      'assinaturaEsquerda': serializer.toJson<String?>(assinaturaEsquerda),
      'contaAtivo': serializer.toJson<String?>(contaAtivo),
      'contaPassivo': serializer.toJson<String?>(contaPassivo),
      'contaPatrimonioLiquido':
          serializer.toJson<String?>(contaPatrimonioLiquido),
      'contaDepreciacaoAcumulada':
          serializer.toJson<String?>(contaDepreciacaoAcumulada),
      'contaCapitalSocial': serializer.toJson<String?>(contaCapitalSocial),
      'contaResultadoExercicio':
          serializer.toJson<String?>(contaResultadoExercicio),
      'contaPrejuizoAcumulado':
          serializer.toJson<String?>(contaPrejuizoAcumulado),
      'contaLucroAcumulado': serializer.toJson<String?>(contaLucroAcumulado),
      'contaTituloPagar': serializer.toJson<String?>(contaTituloPagar),
      'contaTituloReceber': serializer.toJson<String?>(contaTituloReceber),
      'contaJurosPassivo': serializer.toJson<String?>(contaJurosPassivo),
      'contaJurosAtivo': serializer.toJson<String?>(contaJurosAtivo),
      'contaDescontoObtido': serializer.toJson<String?>(contaDescontoObtido),
      'contaDescontoConcedido':
          serializer.toJson<String?>(contaDescontoConcedido),
      'contaCmv': serializer.toJson<String?>(contaCmv),
      'contaVenda': serializer.toJson<String?>(contaVenda),
      'contaVendaServico': serializer.toJson<String?>(contaVendaServico),
      'contaEstoque': serializer.toJson<String?>(contaEstoque),
      'contaApuraResultado': serializer.toJson<String?>(contaApuraResultado),
      'contaJurosApropriar': serializer.toJson<String?>(contaJurosApropriar),
      'idHistPadraoResultado': serializer.toJson<int?>(idHistPadraoResultado),
      'idHistPadraoLucro': serializer.toJson<int?>(idHistPadraoLucro),
      'idHistPadraoPrejuizo': serializer.toJson<int?>(idHistPadraoPrejuizo),
    };
  }

  ContabilParametro copyWith(
          {Value<int?> id = const Value.absent(),
          Value<String?> mascara = const Value.absent(),
          Value<int?> niveis = const Value.absent(),
          Value<String?> informarContaPor = const Value.absent(),
          Value<String?> compartilhaPlanoConta = const Value.absent(),
          Value<String?> compartilhaHistoricos = const Value.absent(),
          Value<String?> alteraLancamentoOutro = const Value.absent(),
          Value<String?> historicoObrigatorio = const Value.absent(),
          Value<String?> permiteLancamentoZerado = const Value.absent(),
          Value<String?> geraInformativoSped = const Value.absent(),
          Value<String?> spedFormaEscritDiario = const Value.absent(),
          Value<String?> spedNomeLivroDiario = const Value.absent(),
          Value<String?> assinaturaDireita = const Value.absent(),
          Value<String?> assinaturaEsquerda = const Value.absent(),
          Value<String?> contaAtivo = const Value.absent(),
          Value<String?> contaPassivo = const Value.absent(),
          Value<String?> contaPatrimonioLiquido = const Value.absent(),
          Value<String?> contaDepreciacaoAcumulada = const Value.absent(),
          Value<String?> contaCapitalSocial = const Value.absent(),
          Value<String?> contaResultadoExercicio = const Value.absent(),
          Value<String?> contaPrejuizoAcumulado = const Value.absent(),
          Value<String?> contaLucroAcumulado = const Value.absent(),
          Value<String?> contaTituloPagar = const Value.absent(),
          Value<String?> contaTituloReceber = const Value.absent(),
          Value<String?> contaJurosPassivo = const Value.absent(),
          Value<String?> contaJurosAtivo = const Value.absent(),
          Value<String?> contaDescontoObtido = const Value.absent(),
          Value<String?> contaDescontoConcedido = const Value.absent(),
          Value<String?> contaCmv = const Value.absent(),
          Value<String?> contaVenda = const Value.absent(),
          Value<String?> contaVendaServico = const Value.absent(),
          Value<String?> contaEstoque = const Value.absent(),
          Value<String?> contaApuraResultado = const Value.absent(),
          Value<String?> contaJurosApropriar = const Value.absent(),
          Value<int?> idHistPadraoResultado = const Value.absent(),
          Value<int?> idHistPadraoLucro = const Value.absent(),
          Value<int?> idHistPadraoPrejuizo = const Value.absent()}) =>
      ContabilParametro(
        id: id.present ? id.value : this.id,
        mascara: mascara.present ? mascara.value : this.mascara,
        niveis: niveis.present ? niveis.value : this.niveis,
        informarContaPor: informarContaPor.present
            ? informarContaPor.value
            : this.informarContaPor,
        compartilhaPlanoConta: compartilhaPlanoConta.present
            ? compartilhaPlanoConta.value
            : this.compartilhaPlanoConta,
        compartilhaHistoricos: compartilhaHistoricos.present
            ? compartilhaHistoricos.value
            : this.compartilhaHistoricos,
        alteraLancamentoOutro: alteraLancamentoOutro.present
            ? alteraLancamentoOutro.value
            : this.alteraLancamentoOutro,
        historicoObrigatorio: historicoObrigatorio.present
            ? historicoObrigatorio.value
            : this.historicoObrigatorio,
        permiteLancamentoZerado: permiteLancamentoZerado.present
            ? permiteLancamentoZerado.value
            : this.permiteLancamentoZerado,
        geraInformativoSped: geraInformativoSped.present
            ? geraInformativoSped.value
            : this.geraInformativoSped,
        spedFormaEscritDiario: spedFormaEscritDiario.present
            ? spedFormaEscritDiario.value
            : this.spedFormaEscritDiario,
        spedNomeLivroDiario: spedNomeLivroDiario.present
            ? spedNomeLivroDiario.value
            : this.spedNomeLivroDiario,
        assinaturaDireita: assinaturaDireita.present
            ? assinaturaDireita.value
            : this.assinaturaDireita,
        assinaturaEsquerda: assinaturaEsquerda.present
            ? assinaturaEsquerda.value
            : this.assinaturaEsquerda,
        contaAtivo: contaAtivo.present ? contaAtivo.value : this.contaAtivo,
        contaPassivo:
            contaPassivo.present ? contaPassivo.value : this.contaPassivo,
        contaPatrimonioLiquido: contaPatrimonioLiquido.present
            ? contaPatrimonioLiquido.value
            : this.contaPatrimonioLiquido,
        contaDepreciacaoAcumulada: contaDepreciacaoAcumulada.present
            ? contaDepreciacaoAcumulada.value
            : this.contaDepreciacaoAcumulada,
        contaCapitalSocial: contaCapitalSocial.present
            ? contaCapitalSocial.value
            : this.contaCapitalSocial,
        contaResultadoExercicio: contaResultadoExercicio.present
            ? contaResultadoExercicio.value
            : this.contaResultadoExercicio,
        contaPrejuizoAcumulado: contaPrejuizoAcumulado.present
            ? contaPrejuizoAcumulado.value
            : this.contaPrejuizoAcumulado,
        contaLucroAcumulado: contaLucroAcumulado.present
            ? contaLucroAcumulado.value
            : this.contaLucroAcumulado,
        contaTituloPagar: contaTituloPagar.present
            ? contaTituloPagar.value
            : this.contaTituloPagar,
        contaTituloReceber: contaTituloReceber.present
            ? contaTituloReceber.value
            : this.contaTituloReceber,
        contaJurosPassivo: contaJurosPassivo.present
            ? contaJurosPassivo.value
            : this.contaJurosPassivo,
        contaJurosAtivo: contaJurosAtivo.present
            ? contaJurosAtivo.value
            : this.contaJurosAtivo,
        contaDescontoObtido: contaDescontoObtido.present
            ? contaDescontoObtido.value
            : this.contaDescontoObtido,
        contaDescontoConcedido: contaDescontoConcedido.present
            ? contaDescontoConcedido.value
            : this.contaDescontoConcedido,
        contaCmv: contaCmv.present ? contaCmv.value : this.contaCmv,
        contaVenda: contaVenda.present ? contaVenda.value : this.contaVenda,
        contaVendaServico: contaVendaServico.present
            ? contaVendaServico.value
            : this.contaVendaServico,
        contaEstoque:
            contaEstoque.present ? contaEstoque.value : this.contaEstoque,
        contaApuraResultado: contaApuraResultado.present
            ? contaApuraResultado.value
            : this.contaApuraResultado,
        contaJurosApropriar: contaJurosApropriar.present
            ? contaJurosApropriar.value
            : this.contaJurosApropriar,
        idHistPadraoResultado: idHistPadraoResultado.present
            ? idHistPadraoResultado.value
            : this.idHistPadraoResultado,
        idHistPadraoLucro: idHistPadraoLucro.present
            ? idHistPadraoLucro.value
            : this.idHistPadraoLucro,
        idHistPadraoPrejuizo: idHistPadraoPrejuizo.present
            ? idHistPadraoPrejuizo.value
            : this.idHistPadraoPrejuizo,
      );
  ContabilParametro copyWithCompanion(ContabilParametrosCompanion data) {
    return ContabilParametro(
      id: data.id.present ? data.id.value : this.id,
      mascara: data.mascara.present ? data.mascara.value : this.mascara,
      niveis: data.niveis.present ? data.niveis.value : this.niveis,
      informarContaPor: data.informarContaPor.present
          ? data.informarContaPor.value
          : this.informarContaPor,
      compartilhaPlanoConta: data.compartilhaPlanoConta.present
          ? data.compartilhaPlanoConta.value
          : this.compartilhaPlanoConta,
      compartilhaHistoricos: data.compartilhaHistoricos.present
          ? data.compartilhaHistoricos.value
          : this.compartilhaHistoricos,
      alteraLancamentoOutro: data.alteraLancamentoOutro.present
          ? data.alteraLancamentoOutro.value
          : this.alteraLancamentoOutro,
      historicoObrigatorio: data.historicoObrigatorio.present
          ? data.historicoObrigatorio.value
          : this.historicoObrigatorio,
      permiteLancamentoZerado: data.permiteLancamentoZerado.present
          ? data.permiteLancamentoZerado.value
          : this.permiteLancamentoZerado,
      geraInformativoSped: data.geraInformativoSped.present
          ? data.geraInformativoSped.value
          : this.geraInformativoSped,
      spedFormaEscritDiario: data.spedFormaEscritDiario.present
          ? data.spedFormaEscritDiario.value
          : this.spedFormaEscritDiario,
      spedNomeLivroDiario: data.spedNomeLivroDiario.present
          ? data.spedNomeLivroDiario.value
          : this.spedNomeLivroDiario,
      assinaturaDireita: data.assinaturaDireita.present
          ? data.assinaturaDireita.value
          : this.assinaturaDireita,
      assinaturaEsquerda: data.assinaturaEsquerda.present
          ? data.assinaturaEsquerda.value
          : this.assinaturaEsquerda,
      contaAtivo:
          data.contaAtivo.present ? data.contaAtivo.value : this.contaAtivo,
      contaPassivo: data.contaPassivo.present
          ? data.contaPassivo.value
          : this.contaPassivo,
      contaPatrimonioLiquido: data.contaPatrimonioLiquido.present
          ? data.contaPatrimonioLiquido.value
          : this.contaPatrimonioLiquido,
      contaDepreciacaoAcumulada: data.contaDepreciacaoAcumulada.present
          ? data.contaDepreciacaoAcumulada.value
          : this.contaDepreciacaoAcumulada,
      contaCapitalSocial: data.contaCapitalSocial.present
          ? data.contaCapitalSocial.value
          : this.contaCapitalSocial,
      contaResultadoExercicio: data.contaResultadoExercicio.present
          ? data.contaResultadoExercicio.value
          : this.contaResultadoExercicio,
      contaPrejuizoAcumulado: data.contaPrejuizoAcumulado.present
          ? data.contaPrejuizoAcumulado.value
          : this.contaPrejuizoAcumulado,
      contaLucroAcumulado: data.contaLucroAcumulado.present
          ? data.contaLucroAcumulado.value
          : this.contaLucroAcumulado,
      contaTituloPagar: data.contaTituloPagar.present
          ? data.contaTituloPagar.value
          : this.contaTituloPagar,
      contaTituloReceber: data.contaTituloReceber.present
          ? data.contaTituloReceber.value
          : this.contaTituloReceber,
      contaJurosPassivo: data.contaJurosPassivo.present
          ? data.contaJurosPassivo.value
          : this.contaJurosPassivo,
      contaJurosAtivo: data.contaJurosAtivo.present
          ? data.contaJurosAtivo.value
          : this.contaJurosAtivo,
      contaDescontoObtido: data.contaDescontoObtido.present
          ? data.contaDescontoObtido.value
          : this.contaDescontoObtido,
      contaDescontoConcedido: data.contaDescontoConcedido.present
          ? data.contaDescontoConcedido.value
          : this.contaDescontoConcedido,
      contaCmv: data.contaCmv.present ? data.contaCmv.value : this.contaCmv,
      contaVenda:
          data.contaVenda.present ? data.contaVenda.value : this.contaVenda,
      contaVendaServico: data.contaVendaServico.present
          ? data.contaVendaServico.value
          : this.contaVendaServico,
      contaEstoque: data.contaEstoque.present
          ? data.contaEstoque.value
          : this.contaEstoque,
      contaApuraResultado: data.contaApuraResultado.present
          ? data.contaApuraResultado.value
          : this.contaApuraResultado,
      contaJurosApropriar: data.contaJurosApropriar.present
          ? data.contaJurosApropriar.value
          : this.contaJurosApropriar,
      idHistPadraoResultado: data.idHistPadraoResultado.present
          ? data.idHistPadraoResultado.value
          : this.idHistPadraoResultado,
      idHistPadraoLucro: data.idHistPadraoLucro.present
          ? data.idHistPadraoLucro.value
          : this.idHistPadraoLucro,
      idHistPadraoPrejuizo: data.idHistPadraoPrejuizo.present
          ? data.idHistPadraoPrejuizo.value
          : this.idHistPadraoPrejuizo,
    );
  }

  @override
  String toString() {
    return (StringBuffer('ContabilParametro(')
          ..write('id: $id, ')
          ..write('mascara: $mascara, ')
          ..write('niveis: $niveis, ')
          ..write('informarContaPor: $informarContaPor, ')
          ..write('compartilhaPlanoConta: $compartilhaPlanoConta, ')
          ..write('compartilhaHistoricos: $compartilhaHistoricos, ')
          ..write('alteraLancamentoOutro: $alteraLancamentoOutro, ')
          ..write('historicoObrigatorio: $historicoObrigatorio, ')
          ..write('permiteLancamentoZerado: $permiteLancamentoZerado, ')
          ..write('geraInformativoSped: $geraInformativoSped, ')
          ..write('spedFormaEscritDiario: $spedFormaEscritDiario, ')
          ..write('spedNomeLivroDiario: $spedNomeLivroDiario, ')
          ..write('assinaturaDireita: $assinaturaDireita, ')
          ..write('assinaturaEsquerda: $assinaturaEsquerda, ')
          ..write('contaAtivo: $contaAtivo, ')
          ..write('contaPassivo: $contaPassivo, ')
          ..write('contaPatrimonioLiquido: $contaPatrimonioLiquido, ')
          ..write('contaDepreciacaoAcumulada: $contaDepreciacaoAcumulada, ')
          ..write('contaCapitalSocial: $contaCapitalSocial, ')
          ..write('contaResultadoExercicio: $contaResultadoExercicio, ')
          ..write('contaPrejuizoAcumulado: $contaPrejuizoAcumulado, ')
          ..write('contaLucroAcumulado: $contaLucroAcumulado, ')
          ..write('contaTituloPagar: $contaTituloPagar, ')
          ..write('contaTituloReceber: $contaTituloReceber, ')
          ..write('contaJurosPassivo: $contaJurosPassivo, ')
          ..write('contaJurosAtivo: $contaJurosAtivo, ')
          ..write('contaDescontoObtido: $contaDescontoObtido, ')
          ..write('contaDescontoConcedido: $contaDescontoConcedido, ')
          ..write('contaCmv: $contaCmv, ')
          ..write('contaVenda: $contaVenda, ')
          ..write('contaVendaServico: $contaVendaServico, ')
          ..write('contaEstoque: $contaEstoque, ')
          ..write('contaApuraResultado: $contaApuraResultado, ')
          ..write('contaJurosApropriar: $contaJurosApropriar, ')
          ..write('idHistPadraoResultado: $idHistPadraoResultado, ')
          ..write('idHistPadraoLucro: $idHistPadraoLucro, ')
          ..write('idHistPadraoPrejuizo: $idHistPadraoPrejuizo')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hashAll([
        id,
        mascara,
        niveis,
        informarContaPor,
        compartilhaPlanoConta,
        compartilhaHistoricos,
        alteraLancamentoOutro,
        historicoObrigatorio,
        permiteLancamentoZerado,
        geraInformativoSped,
        spedFormaEscritDiario,
        spedNomeLivroDiario,
        assinaturaDireita,
        assinaturaEsquerda,
        contaAtivo,
        contaPassivo,
        contaPatrimonioLiquido,
        contaDepreciacaoAcumulada,
        contaCapitalSocial,
        contaResultadoExercicio,
        contaPrejuizoAcumulado,
        contaLucroAcumulado,
        contaTituloPagar,
        contaTituloReceber,
        contaJurosPassivo,
        contaJurosAtivo,
        contaDescontoObtido,
        contaDescontoConcedido,
        contaCmv,
        contaVenda,
        contaVendaServico,
        contaEstoque,
        contaApuraResultado,
        contaJurosApropriar,
        idHistPadraoResultado,
        idHistPadraoLucro,
        idHistPadraoPrejuizo
      ]);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is ContabilParametro &&
          other.id == this.id &&
          other.mascara == this.mascara &&
          other.niveis == this.niveis &&
          other.informarContaPor == this.informarContaPor &&
          other.compartilhaPlanoConta == this.compartilhaPlanoConta &&
          other.compartilhaHistoricos == this.compartilhaHistoricos &&
          other.alteraLancamentoOutro == this.alteraLancamentoOutro &&
          other.historicoObrigatorio == this.historicoObrigatorio &&
          other.permiteLancamentoZerado == this.permiteLancamentoZerado &&
          other.geraInformativoSped == this.geraInformativoSped &&
          other.spedFormaEscritDiario == this.spedFormaEscritDiario &&
          other.spedNomeLivroDiario == this.spedNomeLivroDiario &&
          other.assinaturaDireita == this.assinaturaDireita &&
          other.assinaturaEsquerda == this.assinaturaEsquerda &&
          other.contaAtivo == this.contaAtivo &&
          other.contaPassivo == this.contaPassivo &&
          other.contaPatrimonioLiquido == this.contaPatrimonioLiquido &&
          other.contaDepreciacaoAcumulada == this.contaDepreciacaoAcumulada &&
          other.contaCapitalSocial == this.contaCapitalSocial &&
          other.contaResultadoExercicio == this.contaResultadoExercicio &&
          other.contaPrejuizoAcumulado == this.contaPrejuizoAcumulado &&
          other.contaLucroAcumulado == this.contaLucroAcumulado &&
          other.contaTituloPagar == this.contaTituloPagar &&
          other.contaTituloReceber == this.contaTituloReceber &&
          other.contaJurosPassivo == this.contaJurosPassivo &&
          other.contaJurosAtivo == this.contaJurosAtivo &&
          other.contaDescontoObtido == this.contaDescontoObtido &&
          other.contaDescontoConcedido == this.contaDescontoConcedido &&
          other.contaCmv == this.contaCmv &&
          other.contaVenda == this.contaVenda &&
          other.contaVendaServico == this.contaVendaServico &&
          other.contaEstoque == this.contaEstoque &&
          other.contaApuraResultado == this.contaApuraResultado &&
          other.contaJurosApropriar == this.contaJurosApropriar &&
          other.idHistPadraoResultado == this.idHistPadraoResultado &&
          other.idHistPadraoLucro == this.idHistPadraoLucro &&
          other.idHistPadraoPrejuizo == this.idHistPadraoPrejuizo);
}

class ContabilParametrosCompanion extends UpdateCompanion<ContabilParametro> {
  final Value<int?> id;
  final Value<String?> mascara;
  final Value<int?> niveis;
  final Value<String?> informarContaPor;
  final Value<String?> compartilhaPlanoConta;
  final Value<String?> compartilhaHistoricos;
  final Value<String?> alteraLancamentoOutro;
  final Value<String?> historicoObrigatorio;
  final Value<String?> permiteLancamentoZerado;
  final Value<String?> geraInformativoSped;
  final Value<String?> spedFormaEscritDiario;
  final Value<String?> spedNomeLivroDiario;
  final Value<String?> assinaturaDireita;
  final Value<String?> assinaturaEsquerda;
  final Value<String?> contaAtivo;
  final Value<String?> contaPassivo;
  final Value<String?> contaPatrimonioLiquido;
  final Value<String?> contaDepreciacaoAcumulada;
  final Value<String?> contaCapitalSocial;
  final Value<String?> contaResultadoExercicio;
  final Value<String?> contaPrejuizoAcumulado;
  final Value<String?> contaLucroAcumulado;
  final Value<String?> contaTituloPagar;
  final Value<String?> contaTituloReceber;
  final Value<String?> contaJurosPassivo;
  final Value<String?> contaJurosAtivo;
  final Value<String?> contaDescontoObtido;
  final Value<String?> contaDescontoConcedido;
  final Value<String?> contaCmv;
  final Value<String?> contaVenda;
  final Value<String?> contaVendaServico;
  final Value<String?> contaEstoque;
  final Value<String?> contaApuraResultado;
  final Value<String?> contaJurosApropriar;
  final Value<int?> idHistPadraoResultado;
  final Value<int?> idHistPadraoLucro;
  final Value<int?> idHistPadraoPrejuizo;
  const ContabilParametrosCompanion({
    this.id = const Value.absent(),
    this.mascara = const Value.absent(),
    this.niveis = const Value.absent(),
    this.informarContaPor = const Value.absent(),
    this.compartilhaPlanoConta = const Value.absent(),
    this.compartilhaHistoricos = const Value.absent(),
    this.alteraLancamentoOutro = const Value.absent(),
    this.historicoObrigatorio = const Value.absent(),
    this.permiteLancamentoZerado = const Value.absent(),
    this.geraInformativoSped = const Value.absent(),
    this.spedFormaEscritDiario = const Value.absent(),
    this.spedNomeLivroDiario = const Value.absent(),
    this.assinaturaDireita = const Value.absent(),
    this.assinaturaEsquerda = const Value.absent(),
    this.contaAtivo = const Value.absent(),
    this.contaPassivo = const Value.absent(),
    this.contaPatrimonioLiquido = const Value.absent(),
    this.contaDepreciacaoAcumulada = const Value.absent(),
    this.contaCapitalSocial = const Value.absent(),
    this.contaResultadoExercicio = const Value.absent(),
    this.contaPrejuizoAcumulado = const Value.absent(),
    this.contaLucroAcumulado = const Value.absent(),
    this.contaTituloPagar = const Value.absent(),
    this.contaTituloReceber = const Value.absent(),
    this.contaJurosPassivo = const Value.absent(),
    this.contaJurosAtivo = const Value.absent(),
    this.contaDescontoObtido = const Value.absent(),
    this.contaDescontoConcedido = const Value.absent(),
    this.contaCmv = const Value.absent(),
    this.contaVenda = const Value.absent(),
    this.contaVendaServico = const Value.absent(),
    this.contaEstoque = const Value.absent(),
    this.contaApuraResultado = const Value.absent(),
    this.contaJurosApropriar = const Value.absent(),
    this.idHistPadraoResultado = const Value.absent(),
    this.idHistPadraoLucro = const Value.absent(),
    this.idHistPadraoPrejuizo = const Value.absent(),
  });
  ContabilParametrosCompanion.insert({
    this.id = const Value.absent(),
    this.mascara = const Value.absent(),
    this.niveis = const Value.absent(),
    this.informarContaPor = const Value.absent(),
    this.compartilhaPlanoConta = const Value.absent(),
    this.compartilhaHistoricos = const Value.absent(),
    this.alteraLancamentoOutro = const Value.absent(),
    this.historicoObrigatorio = const Value.absent(),
    this.permiteLancamentoZerado = const Value.absent(),
    this.geraInformativoSped = const Value.absent(),
    this.spedFormaEscritDiario = const Value.absent(),
    this.spedNomeLivroDiario = const Value.absent(),
    this.assinaturaDireita = const Value.absent(),
    this.assinaturaEsquerda = const Value.absent(),
    this.contaAtivo = const Value.absent(),
    this.contaPassivo = const Value.absent(),
    this.contaPatrimonioLiquido = const Value.absent(),
    this.contaDepreciacaoAcumulada = const Value.absent(),
    this.contaCapitalSocial = const Value.absent(),
    this.contaResultadoExercicio = const Value.absent(),
    this.contaPrejuizoAcumulado = const Value.absent(),
    this.contaLucroAcumulado = const Value.absent(),
    this.contaTituloPagar = const Value.absent(),
    this.contaTituloReceber = const Value.absent(),
    this.contaJurosPassivo = const Value.absent(),
    this.contaJurosAtivo = const Value.absent(),
    this.contaDescontoObtido = const Value.absent(),
    this.contaDescontoConcedido = const Value.absent(),
    this.contaCmv = const Value.absent(),
    this.contaVenda = const Value.absent(),
    this.contaVendaServico = const Value.absent(),
    this.contaEstoque = const Value.absent(),
    this.contaApuraResultado = const Value.absent(),
    this.contaJurosApropriar = const Value.absent(),
    this.idHistPadraoResultado = const Value.absent(),
    this.idHistPadraoLucro = const Value.absent(),
    this.idHistPadraoPrejuizo = const Value.absent(),
  });
  static Insertable<ContabilParametro> custom({
    Expression<int>? id,
    Expression<String>? mascara,
    Expression<int>? niveis,
    Expression<String>? informarContaPor,
    Expression<String>? compartilhaPlanoConta,
    Expression<String>? compartilhaHistoricos,
    Expression<String>? alteraLancamentoOutro,
    Expression<String>? historicoObrigatorio,
    Expression<String>? permiteLancamentoZerado,
    Expression<String>? geraInformativoSped,
    Expression<String>? spedFormaEscritDiario,
    Expression<String>? spedNomeLivroDiario,
    Expression<String>? assinaturaDireita,
    Expression<String>? assinaturaEsquerda,
    Expression<String>? contaAtivo,
    Expression<String>? contaPassivo,
    Expression<String>? contaPatrimonioLiquido,
    Expression<String>? contaDepreciacaoAcumulada,
    Expression<String>? contaCapitalSocial,
    Expression<String>? contaResultadoExercicio,
    Expression<String>? contaPrejuizoAcumulado,
    Expression<String>? contaLucroAcumulado,
    Expression<String>? contaTituloPagar,
    Expression<String>? contaTituloReceber,
    Expression<String>? contaJurosPassivo,
    Expression<String>? contaJurosAtivo,
    Expression<String>? contaDescontoObtido,
    Expression<String>? contaDescontoConcedido,
    Expression<String>? contaCmv,
    Expression<String>? contaVenda,
    Expression<String>? contaVendaServico,
    Expression<String>? contaEstoque,
    Expression<String>? contaApuraResultado,
    Expression<String>? contaJurosApropriar,
    Expression<int>? idHistPadraoResultado,
    Expression<int>? idHistPadraoLucro,
    Expression<int>? idHistPadraoPrejuizo,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (mascara != null) 'mascara': mascara,
      if (niveis != null) 'niveis': niveis,
      if (informarContaPor != null) 'informar_conta_por': informarContaPor,
      if (compartilhaPlanoConta != null)
        'compartilha_plano_conta': compartilhaPlanoConta,
      if (compartilhaHistoricos != null)
        'compartilha_historicos': compartilhaHistoricos,
      if (alteraLancamentoOutro != null)
        'altera_lancamento_outro': alteraLancamentoOutro,
      if (historicoObrigatorio != null)
        'historico_obrigatorio': historicoObrigatorio,
      if (permiteLancamentoZerado != null)
        'permite_lancamento_zerado': permiteLancamentoZerado,
      if (geraInformativoSped != null)
        'gera_informativo_sped': geraInformativoSped,
      if (spedFormaEscritDiario != null)
        'sped_forma_escrit_diario': spedFormaEscritDiario,
      if (spedNomeLivroDiario != null)
        'sped_nome_livro_diario': spedNomeLivroDiario,
      if (assinaturaDireita != null) 'assinatura_direita': assinaturaDireita,
      if (assinaturaEsquerda != null) 'assinatura_esquerda': assinaturaEsquerda,
      if (contaAtivo != null) 'conta_ativo': contaAtivo,
      if (contaPassivo != null) 'conta_passivo': contaPassivo,
      if (contaPatrimonioLiquido != null)
        'conta_patrimonio_liquido': contaPatrimonioLiquido,
      if (contaDepreciacaoAcumulada != null)
        'conta_depreciacao_acumulada': contaDepreciacaoAcumulada,
      if (contaCapitalSocial != null)
        'conta_capital_social': contaCapitalSocial,
      if (contaResultadoExercicio != null)
        'conta_resultado_exercicio': contaResultadoExercicio,
      if (contaPrejuizoAcumulado != null)
        'conta_prejuizo_acumulado': contaPrejuizoAcumulado,
      if (contaLucroAcumulado != null)
        'conta_lucro_acumulado': contaLucroAcumulado,
      if (contaTituloPagar != null) 'conta_titulo_pagar': contaTituloPagar,
      if (contaTituloReceber != null)
        'conta_titulo_receber': contaTituloReceber,
      if (contaJurosPassivo != null) 'conta_juros_passivo': contaJurosPassivo,
      if (contaJurosAtivo != null) 'conta_juros_ativo': contaJurosAtivo,
      if (contaDescontoObtido != null)
        'conta_desconto_obtido': contaDescontoObtido,
      if (contaDescontoConcedido != null)
        'conta_desconto_concedido': contaDescontoConcedido,
      if (contaCmv != null) 'conta_cmv': contaCmv,
      if (contaVenda != null) 'conta_venda': contaVenda,
      if (contaVendaServico != null) 'conta_venda_servico': contaVendaServico,
      if (contaEstoque != null) 'conta_estoque': contaEstoque,
      if (contaApuraResultado != null)
        'conta_apura_resultado': contaApuraResultado,
      if (contaJurosApropriar != null)
        'conta_juros_apropriar': contaJurosApropriar,
      if (idHistPadraoResultado != null)
        'id_hist_padrao_resultado': idHistPadraoResultado,
      if (idHistPadraoLucro != null) 'id_hist_padrao_lucro': idHistPadraoLucro,
      if (idHistPadraoPrejuizo != null)
        'id_hist_padrao_prejuizo': idHistPadraoPrejuizo,
    });
  }

  ContabilParametrosCompanion copyWith(
      {Value<int?>? id,
      Value<String?>? mascara,
      Value<int?>? niveis,
      Value<String?>? informarContaPor,
      Value<String?>? compartilhaPlanoConta,
      Value<String?>? compartilhaHistoricos,
      Value<String?>? alteraLancamentoOutro,
      Value<String?>? historicoObrigatorio,
      Value<String?>? permiteLancamentoZerado,
      Value<String?>? geraInformativoSped,
      Value<String?>? spedFormaEscritDiario,
      Value<String?>? spedNomeLivroDiario,
      Value<String?>? assinaturaDireita,
      Value<String?>? assinaturaEsquerda,
      Value<String?>? contaAtivo,
      Value<String?>? contaPassivo,
      Value<String?>? contaPatrimonioLiquido,
      Value<String?>? contaDepreciacaoAcumulada,
      Value<String?>? contaCapitalSocial,
      Value<String?>? contaResultadoExercicio,
      Value<String?>? contaPrejuizoAcumulado,
      Value<String?>? contaLucroAcumulado,
      Value<String?>? contaTituloPagar,
      Value<String?>? contaTituloReceber,
      Value<String?>? contaJurosPassivo,
      Value<String?>? contaJurosAtivo,
      Value<String?>? contaDescontoObtido,
      Value<String?>? contaDescontoConcedido,
      Value<String?>? contaCmv,
      Value<String?>? contaVenda,
      Value<String?>? contaVendaServico,
      Value<String?>? contaEstoque,
      Value<String?>? contaApuraResultado,
      Value<String?>? contaJurosApropriar,
      Value<int?>? idHistPadraoResultado,
      Value<int?>? idHistPadraoLucro,
      Value<int?>? idHistPadraoPrejuizo}) {
    return ContabilParametrosCompanion(
      id: id ?? this.id,
      mascara: mascara ?? this.mascara,
      niveis: niveis ?? this.niveis,
      informarContaPor: informarContaPor ?? this.informarContaPor,
      compartilhaPlanoConta:
          compartilhaPlanoConta ?? this.compartilhaPlanoConta,
      compartilhaHistoricos:
          compartilhaHistoricos ?? this.compartilhaHistoricos,
      alteraLancamentoOutro:
          alteraLancamentoOutro ?? this.alteraLancamentoOutro,
      historicoObrigatorio: historicoObrigatorio ?? this.historicoObrigatorio,
      permiteLancamentoZerado:
          permiteLancamentoZerado ?? this.permiteLancamentoZerado,
      geraInformativoSped: geraInformativoSped ?? this.geraInformativoSped,
      spedFormaEscritDiario:
          spedFormaEscritDiario ?? this.spedFormaEscritDiario,
      spedNomeLivroDiario: spedNomeLivroDiario ?? this.spedNomeLivroDiario,
      assinaturaDireita: assinaturaDireita ?? this.assinaturaDireita,
      assinaturaEsquerda: assinaturaEsquerda ?? this.assinaturaEsquerda,
      contaAtivo: contaAtivo ?? this.contaAtivo,
      contaPassivo: contaPassivo ?? this.contaPassivo,
      contaPatrimonioLiquido:
          contaPatrimonioLiquido ?? this.contaPatrimonioLiquido,
      contaDepreciacaoAcumulada:
          contaDepreciacaoAcumulada ?? this.contaDepreciacaoAcumulada,
      contaCapitalSocial: contaCapitalSocial ?? this.contaCapitalSocial,
      contaResultadoExercicio:
          contaResultadoExercicio ?? this.contaResultadoExercicio,
      contaPrejuizoAcumulado:
          contaPrejuizoAcumulado ?? this.contaPrejuizoAcumulado,
      contaLucroAcumulado: contaLucroAcumulado ?? this.contaLucroAcumulado,
      contaTituloPagar: contaTituloPagar ?? this.contaTituloPagar,
      contaTituloReceber: contaTituloReceber ?? this.contaTituloReceber,
      contaJurosPassivo: contaJurosPassivo ?? this.contaJurosPassivo,
      contaJurosAtivo: contaJurosAtivo ?? this.contaJurosAtivo,
      contaDescontoObtido: contaDescontoObtido ?? this.contaDescontoObtido,
      contaDescontoConcedido:
          contaDescontoConcedido ?? this.contaDescontoConcedido,
      contaCmv: contaCmv ?? this.contaCmv,
      contaVenda: contaVenda ?? this.contaVenda,
      contaVendaServico: contaVendaServico ?? this.contaVendaServico,
      contaEstoque: contaEstoque ?? this.contaEstoque,
      contaApuraResultado: contaApuraResultado ?? this.contaApuraResultado,
      contaJurosApropriar: contaJurosApropriar ?? this.contaJurosApropriar,
      idHistPadraoResultado:
          idHistPadraoResultado ?? this.idHistPadraoResultado,
      idHistPadraoLucro: idHistPadraoLucro ?? this.idHistPadraoLucro,
      idHistPadraoPrejuizo: idHistPadraoPrejuizo ?? this.idHistPadraoPrejuizo,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (mascara.present) {
      map['mascara'] = Variable<String>(mascara.value);
    }
    if (niveis.present) {
      map['niveis'] = Variable<int>(niveis.value);
    }
    if (informarContaPor.present) {
      map['informar_conta_por'] = Variable<String>(informarContaPor.value);
    }
    if (compartilhaPlanoConta.present) {
      map['compartilha_plano_conta'] =
          Variable<String>(compartilhaPlanoConta.value);
    }
    if (compartilhaHistoricos.present) {
      map['compartilha_historicos'] =
          Variable<String>(compartilhaHistoricos.value);
    }
    if (alteraLancamentoOutro.present) {
      map['altera_lancamento_outro'] =
          Variable<String>(alteraLancamentoOutro.value);
    }
    if (historicoObrigatorio.present) {
      map['historico_obrigatorio'] =
          Variable<String>(historicoObrigatorio.value);
    }
    if (permiteLancamentoZerado.present) {
      map['permite_lancamento_zerado'] =
          Variable<String>(permiteLancamentoZerado.value);
    }
    if (geraInformativoSped.present) {
      map['gera_informativo_sped'] =
          Variable<String>(geraInformativoSped.value);
    }
    if (spedFormaEscritDiario.present) {
      map['sped_forma_escrit_diario'] =
          Variable<String>(spedFormaEscritDiario.value);
    }
    if (spedNomeLivroDiario.present) {
      map['sped_nome_livro_diario'] =
          Variable<String>(spedNomeLivroDiario.value);
    }
    if (assinaturaDireita.present) {
      map['assinatura_direita'] = Variable<String>(assinaturaDireita.value);
    }
    if (assinaturaEsquerda.present) {
      map['assinatura_esquerda'] = Variable<String>(assinaturaEsquerda.value);
    }
    if (contaAtivo.present) {
      map['conta_ativo'] = Variable<String>(contaAtivo.value);
    }
    if (contaPassivo.present) {
      map['conta_passivo'] = Variable<String>(contaPassivo.value);
    }
    if (contaPatrimonioLiquido.present) {
      map['conta_patrimonio_liquido'] =
          Variable<String>(contaPatrimonioLiquido.value);
    }
    if (contaDepreciacaoAcumulada.present) {
      map['conta_depreciacao_acumulada'] =
          Variable<String>(contaDepreciacaoAcumulada.value);
    }
    if (contaCapitalSocial.present) {
      map['conta_capital_social'] = Variable<String>(contaCapitalSocial.value);
    }
    if (contaResultadoExercicio.present) {
      map['conta_resultado_exercicio'] =
          Variable<String>(contaResultadoExercicio.value);
    }
    if (contaPrejuizoAcumulado.present) {
      map['conta_prejuizo_acumulado'] =
          Variable<String>(contaPrejuizoAcumulado.value);
    }
    if (contaLucroAcumulado.present) {
      map['conta_lucro_acumulado'] =
          Variable<String>(contaLucroAcumulado.value);
    }
    if (contaTituloPagar.present) {
      map['conta_titulo_pagar'] = Variable<String>(contaTituloPagar.value);
    }
    if (contaTituloReceber.present) {
      map['conta_titulo_receber'] = Variable<String>(contaTituloReceber.value);
    }
    if (contaJurosPassivo.present) {
      map['conta_juros_passivo'] = Variable<String>(contaJurosPassivo.value);
    }
    if (contaJurosAtivo.present) {
      map['conta_juros_ativo'] = Variable<String>(contaJurosAtivo.value);
    }
    if (contaDescontoObtido.present) {
      map['conta_desconto_obtido'] =
          Variable<String>(contaDescontoObtido.value);
    }
    if (contaDescontoConcedido.present) {
      map['conta_desconto_concedido'] =
          Variable<String>(contaDescontoConcedido.value);
    }
    if (contaCmv.present) {
      map['conta_cmv'] = Variable<String>(contaCmv.value);
    }
    if (contaVenda.present) {
      map['conta_venda'] = Variable<String>(contaVenda.value);
    }
    if (contaVendaServico.present) {
      map['conta_venda_servico'] = Variable<String>(contaVendaServico.value);
    }
    if (contaEstoque.present) {
      map['conta_estoque'] = Variable<String>(contaEstoque.value);
    }
    if (contaApuraResultado.present) {
      map['conta_apura_resultado'] =
          Variable<String>(contaApuraResultado.value);
    }
    if (contaJurosApropriar.present) {
      map['conta_juros_apropriar'] =
          Variable<String>(contaJurosApropriar.value);
    }
    if (idHistPadraoResultado.present) {
      map['id_hist_padrao_resultado'] =
          Variable<int>(idHistPadraoResultado.value);
    }
    if (idHistPadraoLucro.present) {
      map['id_hist_padrao_lucro'] = Variable<int>(idHistPadraoLucro.value);
    }
    if (idHistPadraoPrejuizo.present) {
      map['id_hist_padrao_prejuizo'] =
          Variable<int>(idHistPadraoPrejuizo.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('ContabilParametrosCompanion(')
          ..write('id: $id, ')
          ..write('mascara: $mascara, ')
          ..write('niveis: $niveis, ')
          ..write('informarContaPor: $informarContaPor, ')
          ..write('compartilhaPlanoConta: $compartilhaPlanoConta, ')
          ..write('compartilhaHistoricos: $compartilhaHistoricos, ')
          ..write('alteraLancamentoOutro: $alteraLancamentoOutro, ')
          ..write('historicoObrigatorio: $historicoObrigatorio, ')
          ..write('permiteLancamentoZerado: $permiteLancamentoZerado, ')
          ..write('geraInformativoSped: $geraInformativoSped, ')
          ..write('spedFormaEscritDiario: $spedFormaEscritDiario, ')
          ..write('spedNomeLivroDiario: $spedNomeLivroDiario, ')
          ..write('assinaturaDireita: $assinaturaDireita, ')
          ..write('assinaturaEsquerda: $assinaturaEsquerda, ')
          ..write('contaAtivo: $contaAtivo, ')
          ..write('contaPassivo: $contaPassivo, ')
          ..write('contaPatrimonioLiquido: $contaPatrimonioLiquido, ')
          ..write('contaDepreciacaoAcumulada: $contaDepreciacaoAcumulada, ')
          ..write('contaCapitalSocial: $contaCapitalSocial, ')
          ..write('contaResultadoExercicio: $contaResultadoExercicio, ')
          ..write('contaPrejuizoAcumulado: $contaPrejuizoAcumulado, ')
          ..write('contaLucroAcumulado: $contaLucroAcumulado, ')
          ..write('contaTituloPagar: $contaTituloPagar, ')
          ..write('contaTituloReceber: $contaTituloReceber, ')
          ..write('contaJurosPassivo: $contaJurosPassivo, ')
          ..write('contaJurosAtivo: $contaJurosAtivo, ')
          ..write('contaDescontoObtido: $contaDescontoObtido, ')
          ..write('contaDescontoConcedido: $contaDescontoConcedido, ')
          ..write('contaCmv: $contaCmv, ')
          ..write('contaVenda: $contaVenda, ')
          ..write('contaVendaServico: $contaVendaServico, ')
          ..write('contaEstoque: $contaEstoque, ')
          ..write('contaApuraResultado: $contaApuraResultado, ')
          ..write('contaJurosApropriar: $contaJurosApropriar, ')
          ..write('idHistPadraoResultado: $idHistPadraoResultado, ')
          ..write('idHistPadraoLucro: $idHistPadraoLucro, ')
          ..write('idHistPadraoPrejuizo: $idHistPadraoPrejuizo')
          ..write(')'))
        .toString();
  }
}

class $PlanoContaRefSpedsTable extends PlanoContaRefSpeds
    with TableInfo<$PlanoContaRefSpedsTable, PlanoContaRefSped> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $PlanoContaRefSpedsTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
      'id', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _codCtaRefMeta =
      const VerificationMeta('codCtaRef');
  @override
  late final GeneratedColumn<String> codCtaRef = GeneratedColumn<String>(
      'cod_cta_ref', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 30),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _inicioValidadeMeta =
      const VerificationMeta('inicioValidade');
  @override
  late final GeneratedColumn<DateTime> inicioValidade =
      GeneratedColumn<DateTime>('inicio_validade', aliasedName, true,
          type: DriftSqlType.dateTime, requiredDuringInsert: false);
  static const VerificationMeta _fimValidadeMeta =
      const VerificationMeta('fimValidade');
  @override
  late final GeneratedColumn<DateTime> fimValidade = GeneratedColumn<DateTime>(
      'fim_validade', aliasedName, true,
      type: DriftSqlType.dateTime, requiredDuringInsert: false);
  static const VerificationMeta _tipoMeta = const VerificationMeta('tipo');
  @override
  late final GeneratedColumn<String> tipo = GeneratedColumn<String>(
      'tipo', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 1),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _descricaoMeta =
      const VerificationMeta('descricao');
  @override
  late final GeneratedColumn<String> descricao = GeneratedColumn<String>(
      'descricao', aliasedName, true,
      type: DriftSqlType.string, requiredDuringInsert: false);
  static const VerificationMeta _orientacoesMeta =
      const VerificationMeta('orientacoes');
  @override
  late final GeneratedColumn<String> orientacoes = GeneratedColumn<String>(
      'orientacoes', aliasedName, true,
      type: DriftSqlType.string, requiredDuringInsert: false);
  @override
  List<GeneratedColumn> get $columns => [
        id,
        codCtaRef,
        inicioValidade,
        fimValidade,
        tipo,
        descricao,
        orientacoes
      ];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'plano_conta_ref_sped';
  @override
  VerificationContext validateIntegrity(Insertable<PlanoContaRefSped> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('cod_cta_ref')) {
      context.handle(
          _codCtaRefMeta,
          codCtaRef.isAcceptableOrUnknown(
              data['cod_cta_ref']!, _codCtaRefMeta));
    }
    if (data.containsKey('inicio_validade')) {
      context.handle(
          _inicioValidadeMeta,
          inicioValidade.isAcceptableOrUnknown(
              data['inicio_validade']!, _inicioValidadeMeta));
    }
    if (data.containsKey('fim_validade')) {
      context.handle(
          _fimValidadeMeta,
          fimValidade.isAcceptableOrUnknown(
              data['fim_validade']!, _fimValidadeMeta));
    }
    if (data.containsKey('tipo')) {
      context.handle(
          _tipoMeta, tipo.isAcceptableOrUnknown(data['tipo']!, _tipoMeta));
    }
    if (data.containsKey('descricao')) {
      context.handle(_descricaoMeta,
          descricao.isAcceptableOrUnknown(data['descricao']!, _descricaoMeta));
    }
    if (data.containsKey('orientacoes')) {
      context.handle(
          _orientacoesMeta,
          orientacoes.isAcceptableOrUnknown(
              data['orientacoes']!, _orientacoesMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  PlanoContaRefSped map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return PlanoContaRefSped(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id']),
      codCtaRef: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}cod_cta_ref']),
      inicioValidade: attachedDatabase.typeMapping.read(
          DriftSqlType.dateTime, data['${effectivePrefix}inicio_validade']),
      fimValidade: attachedDatabase.typeMapping
          .read(DriftSqlType.dateTime, data['${effectivePrefix}fim_validade']),
      tipo: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}tipo']),
      descricao: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}descricao']),
      orientacoes: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}orientacoes']),
    );
  }

  @override
  $PlanoContaRefSpedsTable createAlias(String alias) {
    return $PlanoContaRefSpedsTable(attachedDatabase, alias);
  }
}

class PlanoContaRefSped extends DataClass
    implements Insertable<PlanoContaRefSped> {
  final int? id;
  final String? codCtaRef;
  final DateTime? inicioValidade;
  final DateTime? fimValidade;
  final String? tipo;
  final String? descricao;
  final String? orientacoes;
  const PlanoContaRefSped(
      {this.id,
      this.codCtaRef,
      this.inicioValidade,
      this.fimValidade,
      this.tipo,
      this.descricao,
      this.orientacoes});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || codCtaRef != null) {
      map['cod_cta_ref'] = Variable<String>(codCtaRef);
    }
    if (!nullToAbsent || inicioValidade != null) {
      map['inicio_validade'] = Variable<DateTime>(inicioValidade);
    }
    if (!nullToAbsent || fimValidade != null) {
      map['fim_validade'] = Variable<DateTime>(fimValidade);
    }
    if (!nullToAbsent || tipo != null) {
      map['tipo'] = Variable<String>(tipo);
    }
    if (!nullToAbsent || descricao != null) {
      map['descricao'] = Variable<String>(descricao);
    }
    if (!nullToAbsent || orientacoes != null) {
      map['orientacoes'] = Variable<String>(orientacoes);
    }
    return map;
  }

  factory PlanoContaRefSped.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return PlanoContaRefSped(
      id: serializer.fromJson<int?>(json['id']),
      codCtaRef: serializer.fromJson<String?>(json['codCtaRef']),
      inicioValidade: serializer.fromJson<DateTime?>(json['inicioValidade']),
      fimValidade: serializer.fromJson<DateTime?>(json['fimValidade']),
      tipo: serializer.fromJson<String?>(json['tipo']),
      descricao: serializer.fromJson<String?>(json['descricao']),
      orientacoes: serializer.fromJson<String?>(json['orientacoes']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'codCtaRef': serializer.toJson<String?>(codCtaRef),
      'inicioValidade': serializer.toJson<DateTime?>(inicioValidade),
      'fimValidade': serializer.toJson<DateTime?>(fimValidade),
      'tipo': serializer.toJson<String?>(tipo),
      'descricao': serializer.toJson<String?>(descricao),
      'orientacoes': serializer.toJson<String?>(orientacoes),
    };
  }

  PlanoContaRefSped copyWith(
          {Value<int?> id = const Value.absent(),
          Value<String?> codCtaRef = const Value.absent(),
          Value<DateTime?> inicioValidade = const Value.absent(),
          Value<DateTime?> fimValidade = const Value.absent(),
          Value<String?> tipo = const Value.absent(),
          Value<String?> descricao = const Value.absent(),
          Value<String?> orientacoes = const Value.absent()}) =>
      PlanoContaRefSped(
        id: id.present ? id.value : this.id,
        codCtaRef: codCtaRef.present ? codCtaRef.value : this.codCtaRef,
        inicioValidade:
            inicioValidade.present ? inicioValidade.value : this.inicioValidade,
        fimValidade: fimValidade.present ? fimValidade.value : this.fimValidade,
        tipo: tipo.present ? tipo.value : this.tipo,
        descricao: descricao.present ? descricao.value : this.descricao,
        orientacoes: orientacoes.present ? orientacoes.value : this.orientacoes,
      );
  PlanoContaRefSped copyWithCompanion(PlanoContaRefSpedsCompanion data) {
    return PlanoContaRefSped(
      id: data.id.present ? data.id.value : this.id,
      codCtaRef: data.codCtaRef.present ? data.codCtaRef.value : this.codCtaRef,
      inicioValidade: data.inicioValidade.present
          ? data.inicioValidade.value
          : this.inicioValidade,
      fimValidade:
          data.fimValidade.present ? data.fimValidade.value : this.fimValidade,
      tipo: data.tipo.present ? data.tipo.value : this.tipo,
      descricao: data.descricao.present ? data.descricao.value : this.descricao,
      orientacoes:
          data.orientacoes.present ? data.orientacoes.value : this.orientacoes,
    );
  }

  @override
  String toString() {
    return (StringBuffer('PlanoContaRefSped(')
          ..write('id: $id, ')
          ..write('codCtaRef: $codCtaRef, ')
          ..write('inicioValidade: $inicioValidade, ')
          ..write('fimValidade: $fimValidade, ')
          ..write('tipo: $tipo, ')
          ..write('descricao: $descricao, ')
          ..write('orientacoes: $orientacoes')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(
      id, codCtaRef, inicioValidade, fimValidade, tipo, descricao, orientacoes);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is PlanoContaRefSped &&
          other.id == this.id &&
          other.codCtaRef == this.codCtaRef &&
          other.inicioValidade == this.inicioValidade &&
          other.fimValidade == this.fimValidade &&
          other.tipo == this.tipo &&
          other.descricao == this.descricao &&
          other.orientacoes == this.orientacoes);
}

class PlanoContaRefSpedsCompanion extends UpdateCompanion<PlanoContaRefSped> {
  final Value<int?> id;
  final Value<String?> codCtaRef;
  final Value<DateTime?> inicioValidade;
  final Value<DateTime?> fimValidade;
  final Value<String?> tipo;
  final Value<String?> descricao;
  final Value<String?> orientacoes;
  const PlanoContaRefSpedsCompanion({
    this.id = const Value.absent(),
    this.codCtaRef = const Value.absent(),
    this.inicioValidade = const Value.absent(),
    this.fimValidade = const Value.absent(),
    this.tipo = const Value.absent(),
    this.descricao = const Value.absent(),
    this.orientacoes = const Value.absent(),
  });
  PlanoContaRefSpedsCompanion.insert({
    this.id = const Value.absent(),
    this.codCtaRef = const Value.absent(),
    this.inicioValidade = const Value.absent(),
    this.fimValidade = const Value.absent(),
    this.tipo = const Value.absent(),
    this.descricao = const Value.absent(),
    this.orientacoes = const Value.absent(),
  });
  static Insertable<PlanoContaRefSped> custom({
    Expression<int>? id,
    Expression<String>? codCtaRef,
    Expression<DateTime>? inicioValidade,
    Expression<DateTime>? fimValidade,
    Expression<String>? tipo,
    Expression<String>? descricao,
    Expression<String>? orientacoes,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (codCtaRef != null) 'cod_cta_ref': codCtaRef,
      if (inicioValidade != null) 'inicio_validade': inicioValidade,
      if (fimValidade != null) 'fim_validade': fimValidade,
      if (tipo != null) 'tipo': tipo,
      if (descricao != null) 'descricao': descricao,
      if (orientacoes != null) 'orientacoes': orientacoes,
    });
  }

  PlanoContaRefSpedsCompanion copyWith(
      {Value<int?>? id,
      Value<String?>? codCtaRef,
      Value<DateTime?>? inicioValidade,
      Value<DateTime?>? fimValidade,
      Value<String?>? tipo,
      Value<String?>? descricao,
      Value<String?>? orientacoes}) {
    return PlanoContaRefSpedsCompanion(
      id: id ?? this.id,
      codCtaRef: codCtaRef ?? this.codCtaRef,
      inicioValidade: inicioValidade ?? this.inicioValidade,
      fimValidade: fimValidade ?? this.fimValidade,
      tipo: tipo ?? this.tipo,
      descricao: descricao ?? this.descricao,
      orientacoes: orientacoes ?? this.orientacoes,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (codCtaRef.present) {
      map['cod_cta_ref'] = Variable<String>(codCtaRef.value);
    }
    if (inicioValidade.present) {
      map['inicio_validade'] = Variable<DateTime>(inicioValidade.value);
    }
    if (fimValidade.present) {
      map['fim_validade'] = Variable<DateTime>(fimValidade.value);
    }
    if (tipo.present) {
      map['tipo'] = Variable<String>(tipo.value);
    }
    if (descricao.present) {
      map['descricao'] = Variable<String>(descricao.value);
    }
    if (orientacoes.present) {
      map['orientacoes'] = Variable<String>(orientacoes.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('PlanoContaRefSpedsCompanion(')
          ..write('id: $id, ')
          ..write('codCtaRef: $codCtaRef, ')
          ..write('inicioValidade: $inicioValidade, ')
          ..write('fimValidade: $fimValidade, ')
          ..write('tipo: $tipo, ')
          ..write('descricao: $descricao, ')
          ..write('orientacoes: $orientacoes')
          ..write(')'))
        .toString();
  }
}

class $PlanoContasTable extends PlanoContas
    with TableInfo<$PlanoContasTable, PlanoConta> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $PlanoContasTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
      'id', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _nomeMeta = const VerificationMeta('nome');
  @override
  late final GeneratedColumn<String> nome = GeneratedColumn<String>(
      'nome', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 100),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _dataInclusaoMeta =
      const VerificationMeta('dataInclusao');
  @override
  late final GeneratedColumn<DateTime> dataInclusao = GeneratedColumn<DateTime>(
      'data_inclusao', aliasedName, true,
      type: DriftSqlType.dateTime, requiredDuringInsert: false);
  static const VerificationMeta _mascaraMeta =
      const VerificationMeta('mascara');
  @override
  late final GeneratedColumn<String> mascara = GeneratedColumn<String>(
      'mascara', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 50),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _niveisMeta = const VerificationMeta('niveis');
  @override
  late final GeneratedColumn<int> niveis = GeneratedColumn<int>(
      'niveis', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  @override
  List<GeneratedColumn> get $columns =>
      [id, nome, dataInclusao, mascara, niveis];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'plano_conta';
  @override
  VerificationContext validateIntegrity(Insertable<PlanoConta> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('nome')) {
      context.handle(
          _nomeMeta, nome.isAcceptableOrUnknown(data['nome']!, _nomeMeta));
    }
    if (data.containsKey('data_inclusao')) {
      context.handle(
          _dataInclusaoMeta,
          dataInclusao.isAcceptableOrUnknown(
              data['data_inclusao']!, _dataInclusaoMeta));
    }
    if (data.containsKey('mascara')) {
      context.handle(_mascaraMeta,
          mascara.isAcceptableOrUnknown(data['mascara']!, _mascaraMeta));
    }
    if (data.containsKey('niveis')) {
      context.handle(_niveisMeta,
          niveis.isAcceptableOrUnknown(data['niveis']!, _niveisMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  PlanoConta map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return PlanoConta(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id']),
      nome: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}nome']),
      dataInclusao: attachedDatabase.typeMapping
          .read(DriftSqlType.dateTime, data['${effectivePrefix}data_inclusao']),
      mascara: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}mascara']),
      niveis: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}niveis']),
    );
  }

  @override
  $PlanoContasTable createAlias(String alias) {
    return $PlanoContasTable(attachedDatabase, alias);
  }
}

class PlanoConta extends DataClass implements Insertable<PlanoConta> {
  final int? id;
  final String? nome;
  final DateTime? dataInclusao;
  final String? mascara;
  final int? niveis;
  const PlanoConta(
      {this.id, this.nome, this.dataInclusao, this.mascara, this.niveis});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || nome != null) {
      map['nome'] = Variable<String>(nome);
    }
    if (!nullToAbsent || dataInclusao != null) {
      map['data_inclusao'] = Variable<DateTime>(dataInclusao);
    }
    if (!nullToAbsent || mascara != null) {
      map['mascara'] = Variable<String>(mascara);
    }
    if (!nullToAbsent || niveis != null) {
      map['niveis'] = Variable<int>(niveis);
    }
    return map;
  }

  factory PlanoConta.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return PlanoConta(
      id: serializer.fromJson<int?>(json['id']),
      nome: serializer.fromJson<String?>(json['nome']),
      dataInclusao: serializer.fromJson<DateTime?>(json['dataInclusao']),
      mascara: serializer.fromJson<String?>(json['mascara']),
      niveis: serializer.fromJson<int?>(json['niveis']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'nome': serializer.toJson<String?>(nome),
      'dataInclusao': serializer.toJson<DateTime?>(dataInclusao),
      'mascara': serializer.toJson<String?>(mascara),
      'niveis': serializer.toJson<int?>(niveis),
    };
  }

  PlanoConta copyWith(
          {Value<int?> id = const Value.absent(),
          Value<String?> nome = const Value.absent(),
          Value<DateTime?> dataInclusao = const Value.absent(),
          Value<String?> mascara = const Value.absent(),
          Value<int?> niveis = const Value.absent()}) =>
      PlanoConta(
        id: id.present ? id.value : this.id,
        nome: nome.present ? nome.value : this.nome,
        dataInclusao:
            dataInclusao.present ? dataInclusao.value : this.dataInclusao,
        mascara: mascara.present ? mascara.value : this.mascara,
        niveis: niveis.present ? niveis.value : this.niveis,
      );
  PlanoConta copyWithCompanion(PlanoContasCompanion data) {
    return PlanoConta(
      id: data.id.present ? data.id.value : this.id,
      nome: data.nome.present ? data.nome.value : this.nome,
      dataInclusao: data.dataInclusao.present
          ? data.dataInclusao.value
          : this.dataInclusao,
      mascara: data.mascara.present ? data.mascara.value : this.mascara,
      niveis: data.niveis.present ? data.niveis.value : this.niveis,
    );
  }

  @override
  String toString() {
    return (StringBuffer('PlanoConta(')
          ..write('id: $id, ')
          ..write('nome: $nome, ')
          ..write('dataInclusao: $dataInclusao, ')
          ..write('mascara: $mascara, ')
          ..write('niveis: $niveis')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(id, nome, dataInclusao, mascara, niveis);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is PlanoConta &&
          other.id == this.id &&
          other.nome == this.nome &&
          other.dataInclusao == this.dataInclusao &&
          other.mascara == this.mascara &&
          other.niveis == this.niveis);
}

class PlanoContasCompanion extends UpdateCompanion<PlanoConta> {
  final Value<int?> id;
  final Value<String?> nome;
  final Value<DateTime?> dataInclusao;
  final Value<String?> mascara;
  final Value<int?> niveis;
  const PlanoContasCompanion({
    this.id = const Value.absent(),
    this.nome = const Value.absent(),
    this.dataInclusao = const Value.absent(),
    this.mascara = const Value.absent(),
    this.niveis = const Value.absent(),
  });
  PlanoContasCompanion.insert({
    this.id = const Value.absent(),
    this.nome = const Value.absent(),
    this.dataInclusao = const Value.absent(),
    this.mascara = const Value.absent(),
    this.niveis = const Value.absent(),
  });
  static Insertable<PlanoConta> custom({
    Expression<int>? id,
    Expression<String>? nome,
    Expression<DateTime>? dataInclusao,
    Expression<String>? mascara,
    Expression<int>? niveis,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (nome != null) 'nome': nome,
      if (dataInclusao != null) 'data_inclusao': dataInclusao,
      if (mascara != null) 'mascara': mascara,
      if (niveis != null) 'niveis': niveis,
    });
  }

  PlanoContasCompanion copyWith(
      {Value<int?>? id,
      Value<String?>? nome,
      Value<DateTime?>? dataInclusao,
      Value<String?>? mascara,
      Value<int?>? niveis}) {
    return PlanoContasCompanion(
      id: id ?? this.id,
      nome: nome ?? this.nome,
      dataInclusao: dataInclusao ?? this.dataInclusao,
      mascara: mascara ?? this.mascara,
      niveis: niveis ?? this.niveis,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (nome.present) {
      map['nome'] = Variable<String>(nome.value);
    }
    if (dataInclusao.present) {
      map['data_inclusao'] = Variable<DateTime>(dataInclusao.value);
    }
    if (mascara.present) {
      map['mascara'] = Variable<String>(mascara.value);
    }
    if (niveis.present) {
      map['niveis'] = Variable<int>(niveis.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('PlanoContasCompanion(')
          ..write('id: $id, ')
          ..write('nome: $nome, ')
          ..write('dataInclusao: $dataInclusao, ')
          ..write('mascara: $mascara, ')
          ..write('niveis: $niveis')
          ..write(')'))
        .toString();
  }
}

class $ContabilContasTable extends ContabilContas
    with TableInfo<$ContabilContasTable, ContabilConta> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $ContabilContasTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
      'id', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _idPlanoContaMeta =
      const VerificationMeta('idPlanoConta');
  @override
  late final GeneratedColumn<int> idPlanoConta = GeneratedColumn<int>(
      'id_plano_conta', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _idPlanoContaRefSpedMeta =
      const VerificationMeta('idPlanoContaRefSped');
  @override
  late final GeneratedColumn<int> idPlanoContaRefSped = GeneratedColumn<int>(
      'id_plano_conta_ref_sped', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _idContabilContaMeta =
      const VerificationMeta('idContabilConta');
  @override
  late final GeneratedColumn<int> idContabilConta = GeneratedColumn<int>(
      'id_contabil_conta', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _classificacaoMeta =
      const VerificationMeta('classificacao');
  @override
  late final GeneratedColumn<String> classificacao = GeneratedColumn<String>(
      'classificacao', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 30),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _tipoMeta = const VerificationMeta('tipo');
  @override
  late final GeneratedColumn<String> tipo = GeneratedColumn<String>(
      'tipo', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 1),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _descricaoMeta =
      const VerificationMeta('descricao');
  @override
  late final GeneratedColumn<String> descricao = GeneratedColumn<String>(
      'descricao', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 100),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _dataInclusaoMeta =
      const VerificationMeta('dataInclusao');
  @override
  late final GeneratedColumn<DateTime> dataInclusao = GeneratedColumn<DateTime>(
      'data_inclusao', aliasedName, true,
      type: DriftSqlType.dateTime, requiredDuringInsert: false);
  static const VerificationMeta _situacaoMeta =
      const VerificationMeta('situacao');
  @override
  late final GeneratedColumn<String> situacao = GeneratedColumn<String>(
      'situacao', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 1),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _naturezaMeta =
      const VerificationMeta('natureza');
  @override
  late final GeneratedColumn<String> natureza = GeneratedColumn<String>(
      'natureza', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 1),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _patrimonioResultadoMeta =
      const VerificationMeta('patrimonioResultado');
  @override
  late final GeneratedColumn<String> patrimonioResultado =
      GeneratedColumn<String>('patrimonio_resultado', aliasedName, true,
          additionalChecks: GeneratedColumn.checkTextLength(
              minTextLength: 0, maxTextLength: 1),
          type: DriftSqlType.string,
          requiredDuringInsert: false);
  static const VerificationMeta _livroCaixaMeta =
      const VerificationMeta('livroCaixa');
  @override
  late final GeneratedColumn<String> livroCaixa = GeneratedColumn<String>(
      'livro_caixa', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 1),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _dfcMeta = const VerificationMeta('dfc');
  @override
  late final GeneratedColumn<String> dfc = GeneratedColumn<String>(
      'dfc', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 1),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _codigoEfdMeta =
      const VerificationMeta('codigoEfd');
  @override
  late final GeneratedColumn<String> codigoEfd = GeneratedColumn<String>(
      'codigo_efd', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 2),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _ordemMeta = const VerificationMeta('ordem');
  @override
  late final GeneratedColumn<String> ordem = GeneratedColumn<String>(
      'ordem', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 20),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _codigoReduzidoMeta =
      const VerificationMeta('codigoReduzido');
  @override
  late final GeneratedColumn<String> codigoReduzido = GeneratedColumn<String>(
      'codigo_reduzido', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 10),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  @override
  List<GeneratedColumn> get $columns => [
        id,
        idPlanoConta,
        idPlanoContaRefSped,
        idContabilConta,
        classificacao,
        tipo,
        descricao,
        dataInclusao,
        situacao,
        natureza,
        patrimonioResultado,
        livroCaixa,
        dfc,
        codigoEfd,
        ordem,
        codigoReduzido
      ];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'contabil_conta';
  @override
  VerificationContext validateIntegrity(Insertable<ContabilConta> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('id_plano_conta')) {
      context.handle(
          _idPlanoContaMeta,
          idPlanoConta.isAcceptableOrUnknown(
              data['id_plano_conta']!, _idPlanoContaMeta));
    }
    if (data.containsKey('id_plano_conta_ref_sped')) {
      context.handle(
          _idPlanoContaRefSpedMeta,
          idPlanoContaRefSped.isAcceptableOrUnknown(
              data['id_plano_conta_ref_sped']!, _idPlanoContaRefSpedMeta));
    }
    if (data.containsKey('id_contabil_conta')) {
      context.handle(
          _idContabilContaMeta,
          idContabilConta.isAcceptableOrUnknown(
              data['id_contabil_conta']!, _idContabilContaMeta));
    }
    if (data.containsKey('classificacao')) {
      context.handle(
          _classificacaoMeta,
          classificacao.isAcceptableOrUnknown(
              data['classificacao']!, _classificacaoMeta));
    }
    if (data.containsKey('tipo')) {
      context.handle(
          _tipoMeta, tipo.isAcceptableOrUnknown(data['tipo']!, _tipoMeta));
    }
    if (data.containsKey('descricao')) {
      context.handle(_descricaoMeta,
          descricao.isAcceptableOrUnknown(data['descricao']!, _descricaoMeta));
    }
    if (data.containsKey('data_inclusao')) {
      context.handle(
          _dataInclusaoMeta,
          dataInclusao.isAcceptableOrUnknown(
              data['data_inclusao']!, _dataInclusaoMeta));
    }
    if (data.containsKey('situacao')) {
      context.handle(_situacaoMeta,
          situacao.isAcceptableOrUnknown(data['situacao']!, _situacaoMeta));
    }
    if (data.containsKey('natureza')) {
      context.handle(_naturezaMeta,
          natureza.isAcceptableOrUnknown(data['natureza']!, _naturezaMeta));
    }
    if (data.containsKey('patrimonio_resultado')) {
      context.handle(
          _patrimonioResultadoMeta,
          patrimonioResultado.isAcceptableOrUnknown(
              data['patrimonio_resultado']!, _patrimonioResultadoMeta));
    }
    if (data.containsKey('livro_caixa')) {
      context.handle(
          _livroCaixaMeta,
          livroCaixa.isAcceptableOrUnknown(
              data['livro_caixa']!, _livroCaixaMeta));
    }
    if (data.containsKey('dfc')) {
      context.handle(
          _dfcMeta, dfc.isAcceptableOrUnknown(data['dfc']!, _dfcMeta));
    }
    if (data.containsKey('codigo_efd')) {
      context.handle(_codigoEfdMeta,
          codigoEfd.isAcceptableOrUnknown(data['codigo_efd']!, _codigoEfdMeta));
    }
    if (data.containsKey('ordem')) {
      context.handle(
          _ordemMeta, ordem.isAcceptableOrUnknown(data['ordem']!, _ordemMeta));
    }
    if (data.containsKey('codigo_reduzido')) {
      context.handle(
          _codigoReduzidoMeta,
          codigoReduzido.isAcceptableOrUnknown(
              data['codigo_reduzido']!, _codigoReduzidoMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  ContabilConta map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return ContabilConta(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id']),
      idPlanoConta: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id_plano_conta']),
      idPlanoContaRefSped: attachedDatabase.typeMapping.read(
          DriftSqlType.int, data['${effectivePrefix}id_plano_conta_ref_sped']),
      idContabilConta: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id_contabil_conta']),
      classificacao: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}classificacao']),
      tipo: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}tipo']),
      descricao: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}descricao']),
      dataInclusao: attachedDatabase.typeMapping
          .read(DriftSqlType.dateTime, data['${effectivePrefix}data_inclusao']),
      situacao: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}situacao']),
      natureza: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}natureza']),
      patrimonioResultado: attachedDatabase.typeMapping.read(
          DriftSqlType.string, data['${effectivePrefix}patrimonio_resultado']),
      livroCaixa: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}livro_caixa']),
      dfc: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}dfc']),
      codigoEfd: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}codigo_efd']),
      ordem: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}ordem']),
      codigoReduzido: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}codigo_reduzido']),
    );
  }

  @override
  $ContabilContasTable createAlias(String alias) {
    return $ContabilContasTable(attachedDatabase, alias);
  }
}

class ContabilConta extends DataClass implements Insertable<ContabilConta> {
  final int? id;
  final int? idPlanoConta;
  final int? idPlanoContaRefSped;
  final int? idContabilConta;
  final String? classificacao;
  final String? tipo;
  final String? descricao;
  final DateTime? dataInclusao;
  final String? situacao;
  final String? natureza;
  final String? patrimonioResultado;
  final String? livroCaixa;
  final String? dfc;
  final String? codigoEfd;
  final String? ordem;
  final String? codigoReduzido;
  const ContabilConta(
      {this.id,
      this.idPlanoConta,
      this.idPlanoContaRefSped,
      this.idContabilConta,
      this.classificacao,
      this.tipo,
      this.descricao,
      this.dataInclusao,
      this.situacao,
      this.natureza,
      this.patrimonioResultado,
      this.livroCaixa,
      this.dfc,
      this.codigoEfd,
      this.ordem,
      this.codigoReduzido});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || idPlanoConta != null) {
      map['id_plano_conta'] = Variable<int>(idPlanoConta);
    }
    if (!nullToAbsent || idPlanoContaRefSped != null) {
      map['id_plano_conta_ref_sped'] = Variable<int>(idPlanoContaRefSped);
    }
    if (!nullToAbsent || idContabilConta != null) {
      map['id_contabil_conta'] = Variable<int>(idContabilConta);
    }
    if (!nullToAbsent || classificacao != null) {
      map['classificacao'] = Variable<String>(classificacao);
    }
    if (!nullToAbsent || tipo != null) {
      map['tipo'] = Variable<String>(tipo);
    }
    if (!nullToAbsent || descricao != null) {
      map['descricao'] = Variable<String>(descricao);
    }
    if (!nullToAbsent || dataInclusao != null) {
      map['data_inclusao'] = Variable<DateTime>(dataInclusao);
    }
    if (!nullToAbsent || situacao != null) {
      map['situacao'] = Variable<String>(situacao);
    }
    if (!nullToAbsent || natureza != null) {
      map['natureza'] = Variable<String>(natureza);
    }
    if (!nullToAbsent || patrimonioResultado != null) {
      map['patrimonio_resultado'] = Variable<String>(patrimonioResultado);
    }
    if (!nullToAbsent || livroCaixa != null) {
      map['livro_caixa'] = Variable<String>(livroCaixa);
    }
    if (!nullToAbsent || dfc != null) {
      map['dfc'] = Variable<String>(dfc);
    }
    if (!nullToAbsent || codigoEfd != null) {
      map['codigo_efd'] = Variable<String>(codigoEfd);
    }
    if (!nullToAbsent || ordem != null) {
      map['ordem'] = Variable<String>(ordem);
    }
    if (!nullToAbsent || codigoReduzido != null) {
      map['codigo_reduzido'] = Variable<String>(codigoReduzido);
    }
    return map;
  }

  factory ContabilConta.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return ContabilConta(
      id: serializer.fromJson<int?>(json['id']),
      idPlanoConta: serializer.fromJson<int?>(json['idPlanoConta']),
      idPlanoContaRefSped:
          serializer.fromJson<int?>(json['idPlanoContaRefSped']),
      idContabilConta: serializer.fromJson<int?>(json['idContabilConta']),
      classificacao: serializer.fromJson<String?>(json['classificacao']),
      tipo: serializer.fromJson<String?>(json['tipo']),
      descricao: serializer.fromJson<String?>(json['descricao']),
      dataInclusao: serializer.fromJson<DateTime?>(json['dataInclusao']),
      situacao: serializer.fromJson<String?>(json['situacao']),
      natureza: serializer.fromJson<String?>(json['natureza']),
      patrimonioResultado:
          serializer.fromJson<String?>(json['patrimonioResultado']),
      livroCaixa: serializer.fromJson<String?>(json['livroCaixa']),
      dfc: serializer.fromJson<String?>(json['dfc']),
      codigoEfd: serializer.fromJson<String?>(json['codigoEfd']),
      ordem: serializer.fromJson<String?>(json['ordem']),
      codigoReduzido: serializer.fromJson<String?>(json['codigoReduzido']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'idPlanoConta': serializer.toJson<int?>(idPlanoConta),
      'idPlanoContaRefSped': serializer.toJson<int?>(idPlanoContaRefSped),
      'idContabilConta': serializer.toJson<int?>(idContabilConta),
      'classificacao': serializer.toJson<String?>(classificacao),
      'tipo': serializer.toJson<String?>(tipo),
      'descricao': serializer.toJson<String?>(descricao),
      'dataInclusao': serializer.toJson<DateTime?>(dataInclusao),
      'situacao': serializer.toJson<String?>(situacao),
      'natureza': serializer.toJson<String?>(natureza),
      'patrimonioResultado': serializer.toJson<String?>(patrimonioResultado),
      'livroCaixa': serializer.toJson<String?>(livroCaixa),
      'dfc': serializer.toJson<String?>(dfc),
      'codigoEfd': serializer.toJson<String?>(codigoEfd),
      'ordem': serializer.toJson<String?>(ordem),
      'codigoReduzido': serializer.toJson<String?>(codigoReduzido),
    };
  }

  ContabilConta copyWith(
          {Value<int?> id = const Value.absent(),
          Value<int?> idPlanoConta = const Value.absent(),
          Value<int?> idPlanoContaRefSped = const Value.absent(),
          Value<int?> idContabilConta = const Value.absent(),
          Value<String?> classificacao = const Value.absent(),
          Value<String?> tipo = const Value.absent(),
          Value<String?> descricao = const Value.absent(),
          Value<DateTime?> dataInclusao = const Value.absent(),
          Value<String?> situacao = const Value.absent(),
          Value<String?> natureza = const Value.absent(),
          Value<String?> patrimonioResultado = const Value.absent(),
          Value<String?> livroCaixa = const Value.absent(),
          Value<String?> dfc = const Value.absent(),
          Value<String?> codigoEfd = const Value.absent(),
          Value<String?> ordem = const Value.absent(),
          Value<String?> codigoReduzido = const Value.absent()}) =>
      ContabilConta(
        id: id.present ? id.value : this.id,
        idPlanoConta:
            idPlanoConta.present ? idPlanoConta.value : this.idPlanoConta,
        idPlanoContaRefSped: idPlanoContaRefSped.present
            ? idPlanoContaRefSped.value
            : this.idPlanoContaRefSped,
        idContabilConta: idContabilConta.present
            ? idContabilConta.value
            : this.idContabilConta,
        classificacao:
            classificacao.present ? classificacao.value : this.classificacao,
        tipo: tipo.present ? tipo.value : this.tipo,
        descricao: descricao.present ? descricao.value : this.descricao,
        dataInclusao:
            dataInclusao.present ? dataInclusao.value : this.dataInclusao,
        situacao: situacao.present ? situacao.value : this.situacao,
        natureza: natureza.present ? natureza.value : this.natureza,
        patrimonioResultado: patrimonioResultado.present
            ? patrimonioResultado.value
            : this.patrimonioResultado,
        livroCaixa: livroCaixa.present ? livroCaixa.value : this.livroCaixa,
        dfc: dfc.present ? dfc.value : this.dfc,
        codigoEfd: codigoEfd.present ? codigoEfd.value : this.codigoEfd,
        ordem: ordem.present ? ordem.value : this.ordem,
        codigoReduzido:
            codigoReduzido.present ? codigoReduzido.value : this.codigoReduzido,
      );
  ContabilConta copyWithCompanion(ContabilContasCompanion data) {
    return ContabilConta(
      id: data.id.present ? data.id.value : this.id,
      idPlanoConta: data.idPlanoConta.present
          ? data.idPlanoConta.value
          : this.idPlanoConta,
      idPlanoContaRefSped: data.idPlanoContaRefSped.present
          ? data.idPlanoContaRefSped.value
          : this.idPlanoContaRefSped,
      idContabilConta: data.idContabilConta.present
          ? data.idContabilConta.value
          : this.idContabilConta,
      classificacao: data.classificacao.present
          ? data.classificacao.value
          : this.classificacao,
      tipo: data.tipo.present ? data.tipo.value : this.tipo,
      descricao: data.descricao.present ? data.descricao.value : this.descricao,
      dataInclusao: data.dataInclusao.present
          ? data.dataInclusao.value
          : this.dataInclusao,
      situacao: data.situacao.present ? data.situacao.value : this.situacao,
      natureza: data.natureza.present ? data.natureza.value : this.natureza,
      patrimonioResultado: data.patrimonioResultado.present
          ? data.patrimonioResultado.value
          : this.patrimonioResultado,
      livroCaixa:
          data.livroCaixa.present ? data.livroCaixa.value : this.livroCaixa,
      dfc: data.dfc.present ? data.dfc.value : this.dfc,
      codigoEfd: data.codigoEfd.present ? data.codigoEfd.value : this.codigoEfd,
      ordem: data.ordem.present ? data.ordem.value : this.ordem,
      codigoReduzido: data.codigoReduzido.present
          ? data.codigoReduzido.value
          : this.codigoReduzido,
    );
  }

  @override
  String toString() {
    return (StringBuffer('ContabilConta(')
          ..write('id: $id, ')
          ..write('idPlanoConta: $idPlanoConta, ')
          ..write('idPlanoContaRefSped: $idPlanoContaRefSped, ')
          ..write('idContabilConta: $idContabilConta, ')
          ..write('classificacao: $classificacao, ')
          ..write('tipo: $tipo, ')
          ..write('descricao: $descricao, ')
          ..write('dataInclusao: $dataInclusao, ')
          ..write('situacao: $situacao, ')
          ..write('natureza: $natureza, ')
          ..write('patrimonioResultado: $patrimonioResultado, ')
          ..write('livroCaixa: $livroCaixa, ')
          ..write('dfc: $dfc, ')
          ..write('codigoEfd: $codigoEfd, ')
          ..write('ordem: $ordem, ')
          ..write('codigoReduzido: $codigoReduzido')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(
      id,
      idPlanoConta,
      idPlanoContaRefSped,
      idContabilConta,
      classificacao,
      tipo,
      descricao,
      dataInclusao,
      situacao,
      natureza,
      patrimonioResultado,
      livroCaixa,
      dfc,
      codigoEfd,
      ordem,
      codigoReduzido);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is ContabilConta &&
          other.id == this.id &&
          other.idPlanoConta == this.idPlanoConta &&
          other.idPlanoContaRefSped == this.idPlanoContaRefSped &&
          other.idContabilConta == this.idContabilConta &&
          other.classificacao == this.classificacao &&
          other.tipo == this.tipo &&
          other.descricao == this.descricao &&
          other.dataInclusao == this.dataInclusao &&
          other.situacao == this.situacao &&
          other.natureza == this.natureza &&
          other.patrimonioResultado == this.patrimonioResultado &&
          other.livroCaixa == this.livroCaixa &&
          other.dfc == this.dfc &&
          other.codigoEfd == this.codigoEfd &&
          other.ordem == this.ordem &&
          other.codigoReduzido == this.codigoReduzido);
}

class ContabilContasCompanion extends UpdateCompanion<ContabilConta> {
  final Value<int?> id;
  final Value<int?> idPlanoConta;
  final Value<int?> idPlanoContaRefSped;
  final Value<int?> idContabilConta;
  final Value<String?> classificacao;
  final Value<String?> tipo;
  final Value<String?> descricao;
  final Value<DateTime?> dataInclusao;
  final Value<String?> situacao;
  final Value<String?> natureza;
  final Value<String?> patrimonioResultado;
  final Value<String?> livroCaixa;
  final Value<String?> dfc;
  final Value<String?> codigoEfd;
  final Value<String?> ordem;
  final Value<String?> codigoReduzido;
  const ContabilContasCompanion({
    this.id = const Value.absent(),
    this.idPlanoConta = const Value.absent(),
    this.idPlanoContaRefSped = const Value.absent(),
    this.idContabilConta = const Value.absent(),
    this.classificacao = const Value.absent(),
    this.tipo = const Value.absent(),
    this.descricao = const Value.absent(),
    this.dataInclusao = const Value.absent(),
    this.situacao = const Value.absent(),
    this.natureza = const Value.absent(),
    this.patrimonioResultado = const Value.absent(),
    this.livroCaixa = const Value.absent(),
    this.dfc = const Value.absent(),
    this.codigoEfd = const Value.absent(),
    this.ordem = const Value.absent(),
    this.codigoReduzido = const Value.absent(),
  });
  ContabilContasCompanion.insert({
    this.id = const Value.absent(),
    this.idPlanoConta = const Value.absent(),
    this.idPlanoContaRefSped = const Value.absent(),
    this.idContabilConta = const Value.absent(),
    this.classificacao = const Value.absent(),
    this.tipo = const Value.absent(),
    this.descricao = const Value.absent(),
    this.dataInclusao = const Value.absent(),
    this.situacao = const Value.absent(),
    this.natureza = const Value.absent(),
    this.patrimonioResultado = const Value.absent(),
    this.livroCaixa = const Value.absent(),
    this.dfc = const Value.absent(),
    this.codigoEfd = const Value.absent(),
    this.ordem = const Value.absent(),
    this.codigoReduzido = const Value.absent(),
  });
  static Insertable<ContabilConta> custom({
    Expression<int>? id,
    Expression<int>? idPlanoConta,
    Expression<int>? idPlanoContaRefSped,
    Expression<int>? idContabilConta,
    Expression<String>? classificacao,
    Expression<String>? tipo,
    Expression<String>? descricao,
    Expression<DateTime>? dataInclusao,
    Expression<String>? situacao,
    Expression<String>? natureza,
    Expression<String>? patrimonioResultado,
    Expression<String>? livroCaixa,
    Expression<String>? dfc,
    Expression<String>? codigoEfd,
    Expression<String>? ordem,
    Expression<String>? codigoReduzido,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (idPlanoConta != null) 'id_plano_conta': idPlanoConta,
      if (idPlanoContaRefSped != null)
        'id_plano_conta_ref_sped': idPlanoContaRefSped,
      if (idContabilConta != null) 'id_contabil_conta': idContabilConta,
      if (classificacao != null) 'classificacao': classificacao,
      if (tipo != null) 'tipo': tipo,
      if (descricao != null) 'descricao': descricao,
      if (dataInclusao != null) 'data_inclusao': dataInclusao,
      if (situacao != null) 'situacao': situacao,
      if (natureza != null) 'natureza': natureza,
      if (patrimonioResultado != null)
        'patrimonio_resultado': patrimonioResultado,
      if (livroCaixa != null) 'livro_caixa': livroCaixa,
      if (dfc != null) 'dfc': dfc,
      if (codigoEfd != null) 'codigo_efd': codigoEfd,
      if (ordem != null) 'ordem': ordem,
      if (codigoReduzido != null) 'codigo_reduzido': codigoReduzido,
    });
  }

  ContabilContasCompanion copyWith(
      {Value<int?>? id,
      Value<int?>? idPlanoConta,
      Value<int?>? idPlanoContaRefSped,
      Value<int?>? idContabilConta,
      Value<String?>? classificacao,
      Value<String?>? tipo,
      Value<String?>? descricao,
      Value<DateTime?>? dataInclusao,
      Value<String?>? situacao,
      Value<String?>? natureza,
      Value<String?>? patrimonioResultado,
      Value<String?>? livroCaixa,
      Value<String?>? dfc,
      Value<String?>? codigoEfd,
      Value<String?>? ordem,
      Value<String?>? codigoReduzido}) {
    return ContabilContasCompanion(
      id: id ?? this.id,
      idPlanoConta: idPlanoConta ?? this.idPlanoConta,
      idPlanoContaRefSped: idPlanoContaRefSped ?? this.idPlanoContaRefSped,
      idContabilConta: idContabilConta ?? this.idContabilConta,
      classificacao: classificacao ?? this.classificacao,
      tipo: tipo ?? this.tipo,
      descricao: descricao ?? this.descricao,
      dataInclusao: dataInclusao ?? this.dataInclusao,
      situacao: situacao ?? this.situacao,
      natureza: natureza ?? this.natureza,
      patrimonioResultado: patrimonioResultado ?? this.patrimonioResultado,
      livroCaixa: livroCaixa ?? this.livroCaixa,
      dfc: dfc ?? this.dfc,
      codigoEfd: codigoEfd ?? this.codigoEfd,
      ordem: ordem ?? this.ordem,
      codigoReduzido: codigoReduzido ?? this.codigoReduzido,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (idPlanoConta.present) {
      map['id_plano_conta'] = Variable<int>(idPlanoConta.value);
    }
    if (idPlanoContaRefSped.present) {
      map['id_plano_conta_ref_sped'] = Variable<int>(idPlanoContaRefSped.value);
    }
    if (idContabilConta.present) {
      map['id_contabil_conta'] = Variable<int>(idContabilConta.value);
    }
    if (classificacao.present) {
      map['classificacao'] = Variable<String>(classificacao.value);
    }
    if (tipo.present) {
      map['tipo'] = Variable<String>(tipo.value);
    }
    if (descricao.present) {
      map['descricao'] = Variable<String>(descricao.value);
    }
    if (dataInclusao.present) {
      map['data_inclusao'] = Variable<DateTime>(dataInclusao.value);
    }
    if (situacao.present) {
      map['situacao'] = Variable<String>(situacao.value);
    }
    if (natureza.present) {
      map['natureza'] = Variable<String>(natureza.value);
    }
    if (patrimonioResultado.present) {
      map['patrimonio_resultado'] = Variable<String>(patrimonioResultado.value);
    }
    if (livroCaixa.present) {
      map['livro_caixa'] = Variable<String>(livroCaixa.value);
    }
    if (dfc.present) {
      map['dfc'] = Variable<String>(dfc.value);
    }
    if (codigoEfd.present) {
      map['codigo_efd'] = Variable<String>(codigoEfd.value);
    }
    if (ordem.present) {
      map['ordem'] = Variable<String>(ordem.value);
    }
    if (codigoReduzido.present) {
      map['codigo_reduzido'] = Variable<String>(codigoReduzido.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('ContabilContasCompanion(')
          ..write('id: $id, ')
          ..write('idPlanoConta: $idPlanoConta, ')
          ..write('idPlanoContaRefSped: $idPlanoContaRefSped, ')
          ..write('idContabilConta: $idContabilConta, ')
          ..write('classificacao: $classificacao, ')
          ..write('tipo: $tipo, ')
          ..write('descricao: $descricao, ')
          ..write('dataInclusao: $dataInclusao, ')
          ..write('situacao: $situacao, ')
          ..write('natureza: $natureza, ')
          ..write('patrimonioResultado: $patrimonioResultado, ')
          ..write('livroCaixa: $livroCaixa, ')
          ..write('dfc: $dfc, ')
          ..write('codigoEfd: $codigoEfd, ')
          ..write('ordem: $ordem, ')
          ..write('codigoReduzido: $codigoReduzido')
          ..write(')'))
        .toString();
  }
}

class $ContabilHistoricosTable extends ContabilHistoricos
    with TableInfo<$ContabilHistoricosTable, ContabilHistorico> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $ContabilHistoricosTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
      'id', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _descricaoMeta =
      const VerificationMeta('descricao');
  @override
  late final GeneratedColumn<String> descricao = GeneratedColumn<String>(
      'descricao', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 100),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _pedeComplementoMeta =
      const VerificationMeta('pedeComplemento');
  @override
  late final GeneratedColumn<String> pedeComplemento = GeneratedColumn<String>(
      'pede_complemento', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 1),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _historicoMeta =
      const VerificationMeta('historico');
  @override
  late final GeneratedColumn<String> historico = GeneratedColumn<String>(
      'historico', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 250),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  @override
  List<GeneratedColumn> get $columns =>
      [id, descricao, pedeComplemento, historico];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'contabil_historico';
  @override
  VerificationContext validateIntegrity(Insertable<ContabilHistorico> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('descricao')) {
      context.handle(_descricaoMeta,
          descricao.isAcceptableOrUnknown(data['descricao']!, _descricaoMeta));
    }
    if (data.containsKey('pede_complemento')) {
      context.handle(
          _pedeComplementoMeta,
          pedeComplemento.isAcceptableOrUnknown(
              data['pede_complemento']!, _pedeComplementoMeta));
    }
    if (data.containsKey('historico')) {
      context.handle(_historicoMeta,
          historico.isAcceptableOrUnknown(data['historico']!, _historicoMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  ContabilHistorico map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return ContabilHistorico(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id']),
      descricao: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}descricao']),
      pedeComplemento: attachedDatabase.typeMapping.read(
          DriftSqlType.string, data['${effectivePrefix}pede_complemento']),
      historico: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}historico']),
    );
  }

  @override
  $ContabilHistoricosTable createAlias(String alias) {
    return $ContabilHistoricosTable(attachedDatabase, alias);
  }
}

class ContabilHistorico extends DataClass
    implements Insertable<ContabilHistorico> {
  final int? id;
  final String? descricao;
  final String? pedeComplemento;
  final String? historico;
  const ContabilHistorico(
      {this.id, this.descricao, this.pedeComplemento, this.historico});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || descricao != null) {
      map['descricao'] = Variable<String>(descricao);
    }
    if (!nullToAbsent || pedeComplemento != null) {
      map['pede_complemento'] = Variable<String>(pedeComplemento);
    }
    if (!nullToAbsent || historico != null) {
      map['historico'] = Variable<String>(historico);
    }
    return map;
  }

  factory ContabilHistorico.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return ContabilHistorico(
      id: serializer.fromJson<int?>(json['id']),
      descricao: serializer.fromJson<String?>(json['descricao']),
      pedeComplemento: serializer.fromJson<String?>(json['pedeComplemento']),
      historico: serializer.fromJson<String?>(json['historico']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'descricao': serializer.toJson<String?>(descricao),
      'pedeComplemento': serializer.toJson<String?>(pedeComplemento),
      'historico': serializer.toJson<String?>(historico),
    };
  }

  ContabilHistorico copyWith(
          {Value<int?> id = const Value.absent(),
          Value<String?> descricao = const Value.absent(),
          Value<String?> pedeComplemento = const Value.absent(),
          Value<String?> historico = const Value.absent()}) =>
      ContabilHistorico(
        id: id.present ? id.value : this.id,
        descricao: descricao.present ? descricao.value : this.descricao,
        pedeComplemento: pedeComplemento.present
            ? pedeComplemento.value
            : this.pedeComplemento,
        historico: historico.present ? historico.value : this.historico,
      );
  ContabilHistorico copyWithCompanion(ContabilHistoricosCompanion data) {
    return ContabilHistorico(
      id: data.id.present ? data.id.value : this.id,
      descricao: data.descricao.present ? data.descricao.value : this.descricao,
      pedeComplemento: data.pedeComplemento.present
          ? data.pedeComplemento.value
          : this.pedeComplemento,
      historico: data.historico.present ? data.historico.value : this.historico,
    );
  }

  @override
  String toString() {
    return (StringBuffer('ContabilHistorico(')
          ..write('id: $id, ')
          ..write('descricao: $descricao, ')
          ..write('pedeComplemento: $pedeComplemento, ')
          ..write('historico: $historico')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(id, descricao, pedeComplemento, historico);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is ContabilHistorico &&
          other.id == this.id &&
          other.descricao == this.descricao &&
          other.pedeComplemento == this.pedeComplemento &&
          other.historico == this.historico);
}

class ContabilHistoricosCompanion extends UpdateCompanion<ContabilHistorico> {
  final Value<int?> id;
  final Value<String?> descricao;
  final Value<String?> pedeComplemento;
  final Value<String?> historico;
  const ContabilHistoricosCompanion({
    this.id = const Value.absent(),
    this.descricao = const Value.absent(),
    this.pedeComplemento = const Value.absent(),
    this.historico = const Value.absent(),
  });
  ContabilHistoricosCompanion.insert({
    this.id = const Value.absent(),
    this.descricao = const Value.absent(),
    this.pedeComplemento = const Value.absent(),
    this.historico = const Value.absent(),
  });
  static Insertable<ContabilHistorico> custom({
    Expression<int>? id,
    Expression<String>? descricao,
    Expression<String>? pedeComplemento,
    Expression<String>? historico,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (descricao != null) 'descricao': descricao,
      if (pedeComplemento != null) 'pede_complemento': pedeComplemento,
      if (historico != null) 'historico': historico,
    });
  }

  ContabilHistoricosCompanion copyWith(
      {Value<int?>? id,
      Value<String?>? descricao,
      Value<String?>? pedeComplemento,
      Value<String?>? historico}) {
    return ContabilHistoricosCompanion(
      id: id ?? this.id,
      descricao: descricao ?? this.descricao,
      pedeComplemento: pedeComplemento ?? this.pedeComplemento,
      historico: historico ?? this.historico,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (descricao.present) {
      map['descricao'] = Variable<String>(descricao.value);
    }
    if (pedeComplemento.present) {
      map['pede_complemento'] = Variable<String>(pedeComplemento.value);
    }
    if (historico.present) {
      map['historico'] = Variable<String>(historico.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('ContabilHistoricosCompanion(')
          ..write('id: $id, ')
          ..write('descricao: $descricao, ')
          ..write('pedeComplemento: $pedeComplemento, ')
          ..write('historico: $historico')
          ..write(')'))
        .toString();
  }
}

class $ContabilLancamentoPadraosTable extends ContabilLancamentoPadraos
    with TableInfo<$ContabilLancamentoPadraosTable, ContabilLancamentoPadrao> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $ContabilLancamentoPadraosTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
      'id', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _descricaoMeta =
      const VerificationMeta('descricao');
  @override
  late final GeneratedColumn<String> descricao = GeneratedColumn<String>(
      'descricao', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 100),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _historicoMeta =
      const VerificationMeta('historico');
  @override
  late final GeneratedColumn<String> historico = GeneratedColumn<String>(
      'historico', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 250),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _idContaDebitoMeta =
      const VerificationMeta('idContaDebito');
  @override
  late final GeneratedColumn<int> idContaDebito = GeneratedColumn<int>(
      'id_conta_debito', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _idContaCreditoMeta =
      const VerificationMeta('idContaCredito');
  @override
  late final GeneratedColumn<int> idContaCredito = GeneratedColumn<int>(
      'id_conta_credito', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  @override
  List<GeneratedColumn> get $columns =>
      [id, descricao, historico, idContaDebito, idContaCredito];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'contabil_lancamento_padrao';
  @override
  VerificationContext validateIntegrity(
      Insertable<ContabilLancamentoPadrao> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('descricao')) {
      context.handle(_descricaoMeta,
          descricao.isAcceptableOrUnknown(data['descricao']!, _descricaoMeta));
    }
    if (data.containsKey('historico')) {
      context.handle(_historicoMeta,
          historico.isAcceptableOrUnknown(data['historico']!, _historicoMeta));
    }
    if (data.containsKey('id_conta_debito')) {
      context.handle(
          _idContaDebitoMeta,
          idContaDebito.isAcceptableOrUnknown(
              data['id_conta_debito']!, _idContaDebitoMeta));
    }
    if (data.containsKey('id_conta_credito')) {
      context.handle(
          _idContaCreditoMeta,
          idContaCredito.isAcceptableOrUnknown(
              data['id_conta_credito']!, _idContaCreditoMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  ContabilLancamentoPadrao map(Map<String, dynamic> data,
      {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return ContabilLancamentoPadrao(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id']),
      descricao: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}descricao']),
      historico: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}historico']),
      idContaDebito: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id_conta_debito']),
      idContaCredito: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id_conta_credito']),
    );
  }

  @override
  $ContabilLancamentoPadraosTable createAlias(String alias) {
    return $ContabilLancamentoPadraosTable(attachedDatabase, alias);
  }
}

class ContabilLancamentoPadrao extends DataClass
    implements Insertable<ContabilLancamentoPadrao> {
  final int? id;
  final String? descricao;
  final String? historico;
  final int? idContaDebito;
  final int? idContaCredito;
  const ContabilLancamentoPadrao(
      {this.id,
      this.descricao,
      this.historico,
      this.idContaDebito,
      this.idContaCredito});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || descricao != null) {
      map['descricao'] = Variable<String>(descricao);
    }
    if (!nullToAbsent || historico != null) {
      map['historico'] = Variable<String>(historico);
    }
    if (!nullToAbsent || idContaDebito != null) {
      map['id_conta_debito'] = Variable<int>(idContaDebito);
    }
    if (!nullToAbsent || idContaCredito != null) {
      map['id_conta_credito'] = Variable<int>(idContaCredito);
    }
    return map;
  }

  factory ContabilLancamentoPadrao.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return ContabilLancamentoPadrao(
      id: serializer.fromJson<int?>(json['id']),
      descricao: serializer.fromJson<String?>(json['descricao']),
      historico: serializer.fromJson<String?>(json['historico']),
      idContaDebito: serializer.fromJson<int?>(json['idContaDebito']),
      idContaCredito: serializer.fromJson<int?>(json['idContaCredito']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'descricao': serializer.toJson<String?>(descricao),
      'historico': serializer.toJson<String?>(historico),
      'idContaDebito': serializer.toJson<int?>(idContaDebito),
      'idContaCredito': serializer.toJson<int?>(idContaCredito),
    };
  }

  ContabilLancamentoPadrao copyWith(
          {Value<int?> id = const Value.absent(),
          Value<String?> descricao = const Value.absent(),
          Value<String?> historico = const Value.absent(),
          Value<int?> idContaDebito = const Value.absent(),
          Value<int?> idContaCredito = const Value.absent()}) =>
      ContabilLancamentoPadrao(
        id: id.present ? id.value : this.id,
        descricao: descricao.present ? descricao.value : this.descricao,
        historico: historico.present ? historico.value : this.historico,
        idContaDebito:
            idContaDebito.present ? idContaDebito.value : this.idContaDebito,
        idContaCredito:
            idContaCredito.present ? idContaCredito.value : this.idContaCredito,
      );
  ContabilLancamentoPadrao copyWithCompanion(
      ContabilLancamentoPadraosCompanion data) {
    return ContabilLancamentoPadrao(
      id: data.id.present ? data.id.value : this.id,
      descricao: data.descricao.present ? data.descricao.value : this.descricao,
      historico: data.historico.present ? data.historico.value : this.historico,
      idContaDebito: data.idContaDebito.present
          ? data.idContaDebito.value
          : this.idContaDebito,
      idContaCredito: data.idContaCredito.present
          ? data.idContaCredito.value
          : this.idContaCredito,
    );
  }

  @override
  String toString() {
    return (StringBuffer('ContabilLancamentoPadrao(')
          ..write('id: $id, ')
          ..write('descricao: $descricao, ')
          ..write('historico: $historico, ')
          ..write('idContaDebito: $idContaDebito, ')
          ..write('idContaCredito: $idContaCredito')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode =>
      Object.hash(id, descricao, historico, idContaDebito, idContaCredito);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is ContabilLancamentoPadrao &&
          other.id == this.id &&
          other.descricao == this.descricao &&
          other.historico == this.historico &&
          other.idContaDebito == this.idContaDebito &&
          other.idContaCredito == this.idContaCredito);
}

class ContabilLancamentoPadraosCompanion
    extends UpdateCompanion<ContabilLancamentoPadrao> {
  final Value<int?> id;
  final Value<String?> descricao;
  final Value<String?> historico;
  final Value<int?> idContaDebito;
  final Value<int?> idContaCredito;
  const ContabilLancamentoPadraosCompanion({
    this.id = const Value.absent(),
    this.descricao = const Value.absent(),
    this.historico = const Value.absent(),
    this.idContaDebito = const Value.absent(),
    this.idContaCredito = const Value.absent(),
  });
  ContabilLancamentoPadraosCompanion.insert({
    this.id = const Value.absent(),
    this.descricao = const Value.absent(),
    this.historico = const Value.absent(),
    this.idContaDebito = const Value.absent(),
    this.idContaCredito = const Value.absent(),
  });
  static Insertable<ContabilLancamentoPadrao> custom({
    Expression<int>? id,
    Expression<String>? descricao,
    Expression<String>? historico,
    Expression<int>? idContaDebito,
    Expression<int>? idContaCredito,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (descricao != null) 'descricao': descricao,
      if (historico != null) 'historico': historico,
      if (idContaDebito != null) 'id_conta_debito': idContaDebito,
      if (idContaCredito != null) 'id_conta_credito': idContaCredito,
    });
  }

  ContabilLancamentoPadraosCompanion copyWith(
      {Value<int?>? id,
      Value<String?>? descricao,
      Value<String?>? historico,
      Value<int?>? idContaDebito,
      Value<int?>? idContaCredito}) {
    return ContabilLancamentoPadraosCompanion(
      id: id ?? this.id,
      descricao: descricao ?? this.descricao,
      historico: historico ?? this.historico,
      idContaDebito: idContaDebito ?? this.idContaDebito,
      idContaCredito: idContaCredito ?? this.idContaCredito,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (descricao.present) {
      map['descricao'] = Variable<String>(descricao.value);
    }
    if (historico.present) {
      map['historico'] = Variable<String>(historico.value);
    }
    if (idContaDebito.present) {
      map['id_conta_debito'] = Variable<int>(idContaDebito.value);
    }
    if (idContaCredito.present) {
      map['id_conta_credito'] = Variable<int>(idContaCredito.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('ContabilLancamentoPadraosCompanion(')
          ..write('id: $id, ')
          ..write('descricao: $descricao, ')
          ..write('historico: $historico, ')
          ..write('idContaDebito: $idContaDebito, ')
          ..write('idContaCredito: $idContaCredito')
          ..write(')'))
        .toString();
  }
}

class $ContabilLotesTable extends ContabilLotes
    with TableInfo<$ContabilLotesTable, ContabilLote> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $ContabilLotesTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
      'id', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _descricaoMeta =
      const VerificationMeta('descricao');
  @override
  late final GeneratedColumn<String> descricao = GeneratedColumn<String>(
      'descricao', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 100),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _dataInclusaoMeta =
      const VerificationMeta('dataInclusao');
  @override
  late final GeneratedColumn<DateTime> dataInclusao = GeneratedColumn<DateTime>(
      'data_inclusao', aliasedName, true,
      type: DriftSqlType.dateTime, requiredDuringInsert: false);
  static const VerificationMeta _dataLiberacaoMeta =
      const VerificationMeta('dataLiberacao');
  @override
  late final GeneratedColumn<DateTime> dataLiberacao =
      GeneratedColumn<DateTime>('data_liberacao', aliasedName, true,
          type: DriftSqlType.dateTime, requiredDuringInsert: false);
  static const VerificationMeta _liberadoMeta =
      const VerificationMeta('liberado');
  @override
  late final GeneratedColumn<String> liberado = GeneratedColumn<String>(
      'liberado', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 1),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _programadoMeta =
      const VerificationMeta('programado');
  @override
  late final GeneratedColumn<String> programado = GeneratedColumn<String>(
      'programado', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 1),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _valorMeta = const VerificationMeta('valor');
  @override
  late final GeneratedColumn<double> valor = GeneratedColumn<double>(
      'valor', aliasedName, true,
      type: DriftSqlType.double, requiredDuringInsert: false);
  @override
  List<GeneratedColumn> get $columns =>
      [id, descricao, dataInclusao, dataLiberacao, liberado, programado, valor];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'contabil_lote';
  @override
  VerificationContext validateIntegrity(Insertable<ContabilLote> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('descricao')) {
      context.handle(_descricaoMeta,
          descricao.isAcceptableOrUnknown(data['descricao']!, _descricaoMeta));
    }
    if (data.containsKey('data_inclusao')) {
      context.handle(
          _dataInclusaoMeta,
          dataInclusao.isAcceptableOrUnknown(
              data['data_inclusao']!, _dataInclusaoMeta));
    }
    if (data.containsKey('data_liberacao')) {
      context.handle(
          _dataLiberacaoMeta,
          dataLiberacao.isAcceptableOrUnknown(
              data['data_liberacao']!, _dataLiberacaoMeta));
    }
    if (data.containsKey('liberado')) {
      context.handle(_liberadoMeta,
          liberado.isAcceptableOrUnknown(data['liberado']!, _liberadoMeta));
    }
    if (data.containsKey('programado')) {
      context.handle(
          _programadoMeta,
          programado.isAcceptableOrUnknown(
              data['programado']!, _programadoMeta));
    }
    if (data.containsKey('valor')) {
      context.handle(
          _valorMeta, valor.isAcceptableOrUnknown(data['valor']!, _valorMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  ContabilLote map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return ContabilLote(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id']),
      descricao: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}descricao']),
      dataInclusao: attachedDatabase.typeMapping
          .read(DriftSqlType.dateTime, data['${effectivePrefix}data_inclusao']),
      dataLiberacao: attachedDatabase.typeMapping.read(
          DriftSqlType.dateTime, data['${effectivePrefix}data_liberacao']),
      liberado: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}liberado']),
      programado: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}programado']),
      valor: attachedDatabase.typeMapping
          .read(DriftSqlType.double, data['${effectivePrefix}valor']),
    );
  }

  @override
  $ContabilLotesTable createAlias(String alias) {
    return $ContabilLotesTable(attachedDatabase, alias);
  }
}

class ContabilLote extends DataClass implements Insertable<ContabilLote> {
  final int? id;
  final String? descricao;
  final DateTime? dataInclusao;
  final DateTime? dataLiberacao;
  final String? liberado;
  final String? programado;
  final double? valor;
  const ContabilLote(
      {this.id,
      this.descricao,
      this.dataInclusao,
      this.dataLiberacao,
      this.liberado,
      this.programado,
      this.valor});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || descricao != null) {
      map['descricao'] = Variable<String>(descricao);
    }
    if (!nullToAbsent || dataInclusao != null) {
      map['data_inclusao'] = Variable<DateTime>(dataInclusao);
    }
    if (!nullToAbsent || dataLiberacao != null) {
      map['data_liberacao'] = Variable<DateTime>(dataLiberacao);
    }
    if (!nullToAbsent || liberado != null) {
      map['liberado'] = Variable<String>(liberado);
    }
    if (!nullToAbsent || programado != null) {
      map['programado'] = Variable<String>(programado);
    }
    if (!nullToAbsent || valor != null) {
      map['valor'] = Variable<double>(valor);
    }
    return map;
  }

  factory ContabilLote.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return ContabilLote(
      id: serializer.fromJson<int?>(json['id']),
      descricao: serializer.fromJson<String?>(json['descricao']),
      dataInclusao: serializer.fromJson<DateTime?>(json['dataInclusao']),
      dataLiberacao: serializer.fromJson<DateTime?>(json['dataLiberacao']),
      liberado: serializer.fromJson<String?>(json['liberado']),
      programado: serializer.fromJson<String?>(json['programado']),
      valor: serializer.fromJson<double?>(json['valor']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'descricao': serializer.toJson<String?>(descricao),
      'dataInclusao': serializer.toJson<DateTime?>(dataInclusao),
      'dataLiberacao': serializer.toJson<DateTime?>(dataLiberacao),
      'liberado': serializer.toJson<String?>(liberado),
      'programado': serializer.toJson<String?>(programado),
      'valor': serializer.toJson<double?>(valor),
    };
  }

  ContabilLote copyWith(
          {Value<int?> id = const Value.absent(),
          Value<String?> descricao = const Value.absent(),
          Value<DateTime?> dataInclusao = const Value.absent(),
          Value<DateTime?> dataLiberacao = const Value.absent(),
          Value<String?> liberado = const Value.absent(),
          Value<String?> programado = const Value.absent(),
          Value<double?> valor = const Value.absent()}) =>
      ContabilLote(
        id: id.present ? id.value : this.id,
        descricao: descricao.present ? descricao.value : this.descricao,
        dataInclusao:
            dataInclusao.present ? dataInclusao.value : this.dataInclusao,
        dataLiberacao:
            dataLiberacao.present ? dataLiberacao.value : this.dataLiberacao,
        liberado: liberado.present ? liberado.value : this.liberado,
        programado: programado.present ? programado.value : this.programado,
        valor: valor.present ? valor.value : this.valor,
      );
  ContabilLote copyWithCompanion(ContabilLotesCompanion data) {
    return ContabilLote(
      id: data.id.present ? data.id.value : this.id,
      descricao: data.descricao.present ? data.descricao.value : this.descricao,
      dataInclusao: data.dataInclusao.present
          ? data.dataInclusao.value
          : this.dataInclusao,
      dataLiberacao: data.dataLiberacao.present
          ? data.dataLiberacao.value
          : this.dataLiberacao,
      liberado: data.liberado.present ? data.liberado.value : this.liberado,
      programado:
          data.programado.present ? data.programado.value : this.programado,
      valor: data.valor.present ? data.valor.value : this.valor,
    );
  }

  @override
  String toString() {
    return (StringBuffer('ContabilLote(')
          ..write('id: $id, ')
          ..write('descricao: $descricao, ')
          ..write('dataInclusao: $dataInclusao, ')
          ..write('dataLiberacao: $dataLiberacao, ')
          ..write('liberado: $liberado, ')
          ..write('programado: $programado, ')
          ..write('valor: $valor')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(
      id, descricao, dataInclusao, dataLiberacao, liberado, programado, valor);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is ContabilLote &&
          other.id == this.id &&
          other.descricao == this.descricao &&
          other.dataInclusao == this.dataInclusao &&
          other.dataLiberacao == this.dataLiberacao &&
          other.liberado == this.liberado &&
          other.programado == this.programado &&
          other.valor == this.valor);
}

class ContabilLotesCompanion extends UpdateCompanion<ContabilLote> {
  final Value<int?> id;
  final Value<String?> descricao;
  final Value<DateTime?> dataInclusao;
  final Value<DateTime?> dataLiberacao;
  final Value<String?> liberado;
  final Value<String?> programado;
  final Value<double?> valor;
  const ContabilLotesCompanion({
    this.id = const Value.absent(),
    this.descricao = const Value.absent(),
    this.dataInclusao = const Value.absent(),
    this.dataLiberacao = const Value.absent(),
    this.liberado = const Value.absent(),
    this.programado = const Value.absent(),
    this.valor = const Value.absent(),
  });
  ContabilLotesCompanion.insert({
    this.id = const Value.absent(),
    this.descricao = const Value.absent(),
    this.dataInclusao = const Value.absent(),
    this.dataLiberacao = const Value.absent(),
    this.liberado = const Value.absent(),
    this.programado = const Value.absent(),
    this.valor = const Value.absent(),
  });
  static Insertable<ContabilLote> custom({
    Expression<int>? id,
    Expression<String>? descricao,
    Expression<DateTime>? dataInclusao,
    Expression<DateTime>? dataLiberacao,
    Expression<String>? liberado,
    Expression<String>? programado,
    Expression<double>? valor,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (descricao != null) 'descricao': descricao,
      if (dataInclusao != null) 'data_inclusao': dataInclusao,
      if (dataLiberacao != null) 'data_liberacao': dataLiberacao,
      if (liberado != null) 'liberado': liberado,
      if (programado != null) 'programado': programado,
      if (valor != null) 'valor': valor,
    });
  }

  ContabilLotesCompanion copyWith(
      {Value<int?>? id,
      Value<String?>? descricao,
      Value<DateTime?>? dataInclusao,
      Value<DateTime?>? dataLiberacao,
      Value<String?>? liberado,
      Value<String?>? programado,
      Value<double?>? valor}) {
    return ContabilLotesCompanion(
      id: id ?? this.id,
      descricao: descricao ?? this.descricao,
      dataInclusao: dataInclusao ?? this.dataInclusao,
      dataLiberacao: dataLiberacao ?? this.dataLiberacao,
      liberado: liberado ?? this.liberado,
      programado: programado ?? this.programado,
      valor: valor ?? this.valor,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (descricao.present) {
      map['descricao'] = Variable<String>(descricao.value);
    }
    if (dataInclusao.present) {
      map['data_inclusao'] = Variable<DateTime>(dataInclusao.value);
    }
    if (dataLiberacao.present) {
      map['data_liberacao'] = Variable<DateTime>(dataLiberacao.value);
    }
    if (liberado.present) {
      map['liberado'] = Variable<String>(liberado.value);
    }
    if (programado.present) {
      map['programado'] = Variable<String>(programado.value);
    }
    if (valor.present) {
      map['valor'] = Variable<double>(valor.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('ContabilLotesCompanion(')
          ..write('id: $id, ')
          ..write('descricao: $descricao, ')
          ..write('dataInclusao: $dataInclusao, ')
          ..write('dataLiberacao: $dataLiberacao, ')
          ..write('liberado: $liberado, ')
          ..write('programado: $programado, ')
          ..write('valor: $valor')
          ..write(')'))
        .toString();
  }
}

class $ContabilLancamentoOrcadosTable extends ContabilLancamentoOrcados
    with TableInfo<$ContabilLancamentoOrcadosTable, ContabilLancamentoOrcado> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $ContabilLancamentoOrcadosTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
      'id', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _idContabilContaMeta =
      const VerificationMeta('idContabilConta');
  @override
  late final GeneratedColumn<int> idContabilConta = GeneratedColumn<int>(
      'id_contabil_conta', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _anoMeta = const VerificationMeta('ano');
  @override
  late final GeneratedColumn<String> ano = GeneratedColumn<String>(
      'ano', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 4),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _janeiroMeta =
      const VerificationMeta('janeiro');
  @override
  late final GeneratedColumn<double> janeiro = GeneratedColumn<double>(
      'janeiro', aliasedName, true,
      type: DriftSqlType.double, requiredDuringInsert: false);
  static const VerificationMeta _fevereiroMeta =
      const VerificationMeta('fevereiro');
  @override
  late final GeneratedColumn<double> fevereiro = GeneratedColumn<double>(
      'fevereiro', aliasedName, true,
      type: DriftSqlType.double, requiredDuringInsert: false);
  static const VerificationMeta _marcoMeta = const VerificationMeta('marco');
  @override
  late final GeneratedColumn<double> marco = GeneratedColumn<double>(
      'marco', aliasedName, true,
      type: DriftSqlType.double, requiredDuringInsert: false);
  static const VerificationMeta _abrilMeta = const VerificationMeta('abril');
  @override
  late final GeneratedColumn<double> abril = GeneratedColumn<double>(
      'abril', aliasedName, true,
      type: DriftSqlType.double, requiredDuringInsert: false);
  static const VerificationMeta _maioMeta = const VerificationMeta('maio');
  @override
  late final GeneratedColumn<double> maio = GeneratedColumn<double>(
      'maio', aliasedName, true,
      type: DriftSqlType.double, requiredDuringInsert: false);
  static const VerificationMeta _junhoMeta = const VerificationMeta('junho');
  @override
  late final GeneratedColumn<double> junho = GeneratedColumn<double>(
      'junho', aliasedName, true,
      type: DriftSqlType.double, requiredDuringInsert: false);
  static const VerificationMeta _julhoMeta = const VerificationMeta('julho');
  @override
  late final GeneratedColumn<double> julho = GeneratedColumn<double>(
      'julho', aliasedName, true,
      type: DriftSqlType.double, requiredDuringInsert: false);
  static const VerificationMeta _agostoMeta = const VerificationMeta('agosto');
  @override
  late final GeneratedColumn<double> agosto = GeneratedColumn<double>(
      'agosto', aliasedName, true,
      type: DriftSqlType.double, requiredDuringInsert: false);
  static const VerificationMeta _setembroMeta =
      const VerificationMeta('setembro');
  @override
  late final GeneratedColumn<double> setembro = GeneratedColumn<double>(
      'setembro', aliasedName, true,
      type: DriftSqlType.double, requiredDuringInsert: false);
  static const VerificationMeta _outubroMeta =
      const VerificationMeta('outubro');
  @override
  late final GeneratedColumn<double> outubro = GeneratedColumn<double>(
      'outubro', aliasedName, true,
      type: DriftSqlType.double, requiredDuringInsert: false);
  static const VerificationMeta _novembroMeta =
      const VerificationMeta('novembro');
  @override
  late final GeneratedColumn<double> novembro = GeneratedColumn<double>(
      'novembro', aliasedName, true,
      type: DriftSqlType.double, requiredDuringInsert: false);
  static const VerificationMeta _dezembroMeta =
      const VerificationMeta('dezembro');
  @override
  late final GeneratedColumn<double> dezembro = GeneratedColumn<double>(
      'dezembro', aliasedName, true,
      type: DriftSqlType.double, requiredDuringInsert: false);
  @override
  List<GeneratedColumn> get $columns => [
        id,
        idContabilConta,
        ano,
        janeiro,
        fevereiro,
        marco,
        abril,
        maio,
        junho,
        julho,
        agosto,
        setembro,
        outubro,
        novembro,
        dezembro
      ];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'contabil_lancamento_orcado';
  @override
  VerificationContext validateIntegrity(
      Insertable<ContabilLancamentoOrcado> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('id_contabil_conta')) {
      context.handle(
          _idContabilContaMeta,
          idContabilConta.isAcceptableOrUnknown(
              data['id_contabil_conta']!, _idContabilContaMeta));
    }
    if (data.containsKey('ano')) {
      context.handle(
          _anoMeta, ano.isAcceptableOrUnknown(data['ano']!, _anoMeta));
    }
    if (data.containsKey('janeiro')) {
      context.handle(_janeiroMeta,
          janeiro.isAcceptableOrUnknown(data['janeiro']!, _janeiroMeta));
    }
    if (data.containsKey('fevereiro')) {
      context.handle(_fevereiroMeta,
          fevereiro.isAcceptableOrUnknown(data['fevereiro']!, _fevereiroMeta));
    }
    if (data.containsKey('marco')) {
      context.handle(
          _marcoMeta, marco.isAcceptableOrUnknown(data['marco']!, _marcoMeta));
    }
    if (data.containsKey('abril')) {
      context.handle(
          _abrilMeta, abril.isAcceptableOrUnknown(data['abril']!, _abrilMeta));
    }
    if (data.containsKey('maio')) {
      context.handle(
          _maioMeta, maio.isAcceptableOrUnknown(data['maio']!, _maioMeta));
    }
    if (data.containsKey('junho')) {
      context.handle(
          _junhoMeta, junho.isAcceptableOrUnknown(data['junho']!, _junhoMeta));
    }
    if (data.containsKey('julho')) {
      context.handle(
          _julhoMeta, julho.isAcceptableOrUnknown(data['julho']!, _julhoMeta));
    }
    if (data.containsKey('agosto')) {
      context.handle(_agostoMeta,
          agosto.isAcceptableOrUnknown(data['agosto']!, _agostoMeta));
    }
    if (data.containsKey('setembro')) {
      context.handle(_setembroMeta,
          setembro.isAcceptableOrUnknown(data['setembro']!, _setembroMeta));
    }
    if (data.containsKey('outubro')) {
      context.handle(_outubroMeta,
          outubro.isAcceptableOrUnknown(data['outubro']!, _outubroMeta));
    }
    if (data.containsKey('novembro')) {
      context.handle(_novembroMeta,
          novembro.isAcceptableOrUnknown(data['novembro']!, _novembroMeta));
    }
    if (data.containsKey('dezembro')) {
      context.handle(_dezembroMeta,
          dezembro.isAcceptableOrUnknown(data['dezembro']!, _dezembroMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  ContabilLancamentoOrcado map(Map<String, dynamic> data,
      {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return ContabilLancamentoOrcado(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id']),
      idContabilConta: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id_contabil_conta']),
      ano: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}ano']),
      janeiro: attachedDatabase.typeMapping
          .read(DriftSqlType.double, data['${effectivePrefix}janeiro']),
      fevereiro: attachedDatabase.typeMapping
          .read(DriftSqlType.double, data['${effectivePrefix}fevereiro']),
      marco: attachedDatabase.typeMapping
          .read(DriftSqlType.double, data['${effectivePrefix}marco']),
      abril: attachedDatabase.typeMapping
          .read(DriftSqlType.double, data['${effectivePrefix}abril']),
      maio: attachedDatabase.typeMapping
          .read(DriftSqlType.double, data['${effectivePrefix}maio']),
      junho: attachedDatabase.typeMapping
          .read(DriftSqlType.double, data['${effectivePrefix}junho']),
      julho: attachedDatabase.typeMapping
          .read(DriftSqlType.double, data['${effectivePrefix}julho']),
      agosto: attachedDatabase.typeMapping
          .read(DriftSqlType.double, data['${effectivePrefix}agosto']),
      setembro: attachedDatabase.typeMapping
          .read(DriftSqlType.double, data['${effectivePrefix}setembro']),
      outubro: attachedDatabase.typeMapping
          .read(DriftSqlType.double, data['${effectivePrefix}outubro']),
      novembro: attachedDatabase.typeMapping
          .read(DriftSqlType.double, data['${effectivePrefix}novembro']),
      dezembro: attachedDatabase.typeMapping
          .read(DriftSqlType.double, data['${effectivePrefix}dezembro']),
    );
  }

  @override
  $ContabilLancamentoOrcadosTable createAlias(String alias) {
    return $ContabilLancamentoOrcadosTable(attachedDatabase, alias);
  }
}

class ContabilLancamentoOrcado extends DataClass
    implements Insertable<ContabilLancamentoOrcado> {
  final int? id;
  final int? idContabilConta;
  final String? ano;
  final double? janeiro;
  final double? fevereiro;
  final double? marco;
  final double? abril;
  final double? maio;
  final double? junho;
  final double? julho;
  final double? agosto;
  final double? setembro;
  final double? outubro;
  final double? novembro;
  final double? dezembro;
  const ContabilLancamentoOrcado(
      {this.id,
      this.idContabilConta,
      this.ano,
      this.janeiro,
      this.fevereiro,
      this.marco,
      this.abril,
      this.maio,
      this.junho,
      this.julho,
      this.agosto,
      this.setembro,
      this.outubro,
      this.novembro,
      this.dezembro});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || idContabilConta != null) {
      map['id_contabil_conta'] = Variable<int>(idContabilConta);
    }
    if (!nullToAbsent || ano != null) {
      map['ano'] = Variable<String>(ano);
    }
    if (!nullToAbsent || janeiro != null) {
      map['janeiro'] = Variable<double>(janeiro);
    }
    if (!nullToAbsent || fevereiro != null) {
      map['fevereiro'] = Variable<double>(fevereiro);
    }
    if (!nullToAbsent || marco != null) {
      map['marco'] = Variable<double>(marco);
    }
    if (!nullToAbsent || abril != null) {
      map['abril'] = Variable<double>(abril);
    }
    if (!nullToAbsent || maio != null) {
      map['maio'] = Variable<double>(maio);
    }
    if (!nullToAbsent || junho != null) {
      map['junho'] = Variable<double>(junho);
    }
    if (!nullToAbsent || julho != null) {
      map['julho'] = Variable<double>(julho);
    }
    if (!nullToAbsent || agosto != null) {
      map['agosto'] = Variable<double>(agosto);
    }
    if (!nullToAbsent || setembro != null) {
      map['setembro'] = Variable<double>(setembro);
    }
    if (!nullToAbsent || outubro != null) {
      map['outubro'] = Variable<double>(outubro);
    }
    if (!nullToAbsent || novembro != null) {
      map['novembro'] = Variable<double>(novembro);
    }
    if (!nullToAbsent || dezembro != null) {
      map['dezembro'] = Variable<double>(dezembro);
    }
    return map;
  }

  factory ContabilLancamentoOrcado.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return ContabilLancamentoOrcado(
      id: serializer.fromJson<int?>(json['id']),
      idContabilConta: serializer.fromJson<int?>(json['idContabilConta']),
      ano: serializer.fromJson<String?>(json['ano']),
      janeiro: serializer.fromJson<double?>(json['janeiro']),
      fevereiro: serializer.fromJson<double?>(json['fevereiro']),
      marco: serializer.fromJson<double?>(json['marco']),
      abril: serializer.fromJson<double?>(json['abril']),
      maio: serializer.fromJson<double?>(json['maio']),
      junho: serializer.fromJson<double?>(json['junho']),
      julho: serializer.fromJson<double?>(json['julho']),
      agosto: serializer.fromJson<double?>(json['agosto']),
      setembro: serializer.fromJson<double?>(json['setembro']),
      outubro: serializer.fromJson<double?>(json['outubro']),
      novembro: serializer.fromJson<double?>(json['novembro']),
      dezembro: serializer.fromJson<double?>(json['dezembro']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'idContabilConta': serializer.toJson<int?>(idContabilConta),
      'ano': serializer.toJson<String?>(ano),
      'janeiro': serializer.toJson<double?>(janeiro),
      'fevereiro': serializer.toJson<double?>(fevereiro),
      'marco': serializer.toJson<double?>(marco),
      'abril': serializer.toJson<double?>(abril),
      'maio': serializer.toJson<double?>(maio),
      'junho': serializer.toJson<double?>(junho),
      'julho': serializer.toJson<double?>(julho),
      'agosto': serializer.toJson<double?>(agosto),
      'setembro': serializer.toJson<double?>(setembro),
      'outubro': serializer.toJson<double?>(outubro),
      'novembro': serializer.toJson<double?>(novembro),
      'dezembro': serializer.toJson<double?>(dezembro),
    };
  }

  ContabilLancamentoOrcado copyWith(
          {Value<int?> id = const Value.absent(),
          Value<int?> idContabilConta = const Value.absent(),
          Value<String?> ano = const Value.absent(),
          Value<double?> janeiro = const Value.absent(),
          Value<double?> fevereiro = const Value.absent(),
          Value<double?> marco = const Value.absent(),
          Value<double?> abril = const Value.absent(),
          Value<double?> maio = const Value.absent(),
          Value<double?> junho = const Value.absent(),
          Value<double?> julho = const Value.absent(),
          Value<double?> agosto = const Value.absent(),
          Value<double?> setembro = const Value.absent(),
          Value<double?> outubro = const Value.absent(),
          Value<double?> novembro = const Value.absent(),
          Value<double?> dezembro = const Value.absent()}) =>
      ContabilLancamentoOrcado(
        id: id.present ? id.value : this.id,
        idContabilConta: idContabilConta.present
            ? idContabilConta.value
            : this.idContabilConta,
        ano: ano.present ? ano.value : this.ano,
        janeiro: janeiro.present ? janeiro.value : this.janeiro,
        fevereiro: fevereiro.present ? fevereiro.value : this.fevereiro,
        marco: marco.present ? marco.value : this.marco,
        abril: abril.present ? abril.value : this.abril,
        maio: maio.present ? maio.value : this.maio,
        junho: junho.present ? junho.value : this.junho,
        julho: julho.present ? julho.value : this.julho,
        agosto: agosto.present ? agosto.value : this.agosto,
        setembro: setembro.present ? setembro.value : this.setembro,
        outubro: outubro.present ? outubro.value : this.outubro,
        novembro: novembro.present ? novembro.value : this.novembro,
        dezembro: dezembro.present ? dezembro.value : this.dezembro,
      );
  ContabilLancamentoOrcado copyWithCompanion(
      ContabilLancamentoOrcadosCompanion data) {
    return ContabilLancamentoOrcado(
      id: data.id.present ? data.id.value : this.id,
      idContabilConta: data.idContabilConta.present
          ? data.idContabilConta.value
          : this.idContabilConta,
      ano: data.ano.present ? data.ano.value : this.ano,
      janeiro: data.janeiro.present ? data.janeiro.value : this.janeiro,
      fevereiro: data.fevereiro.present ? data.fevereiro.value : this.fevereiro,
      marco: data.marco.present ? data.marco.value : this.marco,
      abril: data.abril.present ? data.abril.value : this.abril,
      maio: data.maio.present ? data.maio.value : this.maio,
      junho: data.junho.present ? data.junho.value : this.junho,
      julho: data.julho.present ? data.julho.value : this.julho,
      agosto: data.agosto.present ? data.agosto.value : this.agosto,
      setembro: data.setembro.present ? data.setembro.value : this.setembro,
      outubro: data.outubro.present ? data.outubro.value : this.outubro,
      novembro: data.novembro.present ? data.novembro.value : this.novembro,
      dezembro: data.dezembro.present ? data.dezembro.value : this.dezembro,
    );
  }

  @override
  String toString() {
    return (StringBuffer('ContabilLancamentoOrcado(')
          ..write('id: $id, ')
          ..write('idContabilConta: $idContabilConta, ')
          ..write('ano: $ano, ')
          ..write('janeiro: $janeiro, ')
          ..write('fevereiro: $fevereiro, ')
          ..write('marco: $marco, ')
          ..write('abril: $abril, ')
          ..write('maio: $maio, ')
          ..write('junho: $junho, ')
          ..write('julho: $julho, ')
          ..write('agosto: $agosto, ')
          ..write('setembro: $setembro, ')
          ..write('outubro: $outubro, ')
          ..write('novembro: $novembro, ')
          ..write('dezembro: $dezembro')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(
      id,
      idContabilConta,
      ano,
      janeiro,
      fevereiro,
      marco,
      abril,
      maio,
      junho,
      julho,
      agosto,
      setembro,
      outubro,
      novembro,
      dezembro);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is ContabilLancamentoOrcado &&
          other.id == this.id &&
          other.idContabilConta == this.idContabilConta &&
          other.ano == this.ano &&
          other.janeiro == this.janeiro &&
          other.fevereiro == this.fevereiro &&
          other.marco == this.marco &&
          other.abril == this.abril &&
          other.maio == this.maio &&
          other.junho == this.junho &&
          other.julho == this.julho &&
          other.agosto == this.agosto &&
          other.setembro == this.setembro &&
          other.outubro == this.outubro &&
          other.novembro == this.novembro &&
          other.dezembro == this.dezembro);
}

class ContabilLancamentoOrcadosCompanion
    extends UpdateCompanion<ContabilLancamentoOrcado> {
  final Value<int?> id;
  final Value<int?> idContabilConta;
  final Value<String?> ano;
  final Value<double?> janeiro;
  final Value<double?> fevereiro;
  final Value<double?> marco;
  final Value<double?> abril;
  final Value<double?> maio;
  final Value<double?> junho;
  final Value<double?> julho;
  final Value<double?> agosto;
  final Value<double?> setembro;
  final Value<double?> outubro;
  final Value<double?> novembro;
  final Value<double?> dezembro;
  const ContabilLancamentoOrcadosCompanion({
    this.id = const Value.absent(),
    this.idContabilConta = const Value.absent(),
    this.ano = const Value.absent(),
    this.janeiro = const Value.absent(),
    this.fevereiro = const Value.absent(),
    this.marco = const Value.absent(),
    this.abril = const Value.absent(),
    this.maio = const Value.absent(),
    this.junho = const Value.absent(),
    this.julho = const Value.absent(),
    this.agosto = const Value.absent(),
    this.setembro = const Value.absent(),
    this.outubro = const Value.absent(),
    this.novembro = const Value.absent(),
    this.dezembro = const Value.absent(),
  });
  ContabilLancamentoOrcadosCompanion.insert({
    this.id = const Value.absent(),
    this.idContabilConta = const Value.absent(),
    this.ano = const Value.absent(),
    this.janeiro = const Value.absent(),
    this.fevereiro = const Value.absent(),
    this.marco = const Value.absent(),
    this.abril = const Value.absent(),
    this.maio = const Value.absent(),
    this.junho = const Value.absent(),
    this.julho = const Value.absent(),
    this.agosto = const Value.absent(),
    this.setembro = const Value.absent(),
    this.outubro = const Value.absent(),
    this.novembro = const Value.absent(),
    this.dezembro = const Value.absent(),
  });
  static Insertable<ContabilLancamentoOrcado> custom({
    Expression<int>? id,
    Expression<int>? idContabilConta,
    Expression<String>? ano,
    Expression<double>? janeiro,
    Expression<double>? fevereiro,
    Expression<double>? marco,
    Expression<double>? abril,
    Expression<double>? maio,
    Expression<double>? junho,
    Expression<double>? julho,
    Expression<double>? agosto,
    Expression<double>? setembro,
    Expression<double>? outubro,
    Expression<double>? novembro,
    Expression<double>? dezembro,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (idContabilConta != null) 'id_contabil_conta': idContabilConta,
      if (ano != null) 'ano': ano,
      if (janeiro != null) 'janeiro': janeiro,
      if (fevereiro != null) 'fevereiro': fevereiro,
      if (marco != null) 'marco': marco,
      if (abril != null) 'abril': abril,
      if (maio != null) 'maio': maio,
      if (junho != null) 'junho': junho,
      if (julho != null) 'julho': julho,
      if (agosto != null) 'agosto': agosto,
      if (setembro != null) 'setembro': setembro,
      if (outubro != null) 'outubro': outubro,
      if (novembro != null) 'novembro': novembro,
      if (dezembro != null) 'dezembro': dezembro,
    });
  }

  ContabilLancamentoOrcadosCompanion copyWith(
      {Value<int?>? id,
      Value<int?>? idContabilConta,
      Value<String?>? ano,
      Value<double?>? janeiro,
      Value<double?>? fevereiro,
      Value<double?>? marco,
      Value<double?>? abril,
      Value<double?>? maio,
      Value<double?>? junho,
      Value<double?>? julho,
      Value<double?>? agosto,
      Value<double?>? setembro,
      Value<double?>? outubro,
      Value<double?>? novembro,
      Value<double?>? dezembro}) {
    return ContabilLancamentoOrcadosCompanion(
      id: id ?? this.id,
      idContabilConta: idContabilConta ?? this.idContabilConta,
      ano: ano ?? this.ano,
      janeiro: janeiro ?? this.janeiro,
      fevereiro: fevereiro ?? this.fevereiro,
      marco: marco ?? this.marco,
      abril: abril ?? this.abril,
      maio: maio ?? this.maio,
      junho: junho ?? this.junho,
      julho: julho ?? this.julho,
      agosto: agosto ?? this.agosto,
      setembro: setembro ?? this.setembro,
      outubro: outubro ?? this.outubro,
      novembro: novembro ?? this.novembro,
      dezembro: dezembro ?? this.dezembro,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (idContabilConta.present) {
      map['id_contabil_conta'] = Variable<int>(idContabilConta.value);
    }
    if (ano.present) {
      map['ano'] = Variable<String>(ano.value);
    }
    if (janeiro.present) {
      map['janeiro'] = Variable<double>(janeiro.value);
    }
    if (fevereiro.present) {
      map['fevereiro'] = Variable<double>(fevereiro.value);
    }
    if (marco.present) {
      map['marco'] = Variable<double>(marco.value);
    }
    if (abril.present) {
      map['abril'] = Variable<double>(abril.value);
    }
    if (maio.present) {
      map['maio'] = Variable<double>(maio.value);
    }
    if (junho.present) {
      map['junho'] = Variable<double>(junho.value);
    }
    if (julho.present) {
      map['julho'] = Variable<double>(julho.value);
    }
    if (agosto.present) {
      map['agosto'] = Variable<double>(agosto.value);
    }
    if (setembro.present) {
      map['setembro'] = Variable<double>(setembro.value);
    }
    if (outubro.present) {
      map['outubro'] = Variable<double>(outubro.value);
    }
    if (novembro.present) {
      map['novembro'] = Variable<double>(novembro.value);
    }
    if (dezembro.present) {
      map['dezembro'] = Variable<double>(dezembro.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('ContabilLancamentoOrcadosCompanion(')
          ..write('id: $id, ')
          ..write('idContabilConta: $idContabilConta, ')
          ..write('ano: $ano, ')
          ..write('janeiro: $janeiro, ')
          ..write('fevereiro: $fevereiro, ')
          ..write('marco: $marco, ')
          ..write('abril: $abril, ')
          ..write('maio: $maio, ')
          ..write('junho: $junho, ')
          ..write('julho: $julho, ')
          ..write('agosto: $agosto, ')
          ..write('setembro: $setembro, ')
          ..write('outubro: $outubro, ')
          ..write('novembro: $novembro, ')
          ..write('dezembro: $dezembro')
          ..write(')'))
        .toString();
  }
}

class $LancaCentroResultadosTable extends LancaCentroResultados
    with TableInfo<$LancaCentroResultadosTable, LancaCentroResultado> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $LancaCentroResultadosTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
      'id', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _idCentroResultadoMeta =
      const VerificationMeta('idCentroResultado');
  @override
  late final GeneratedColumn<int> idCentroResultado = GeneratedColumn<int>(
      'id_centro_resultado', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _valorMeta = const VerificationMeta('valor');
  @override
  late final GeneratedColumn<double> valor = GeneratedColumn<double>(
      'valor', aliasedName, true,
      type: DriftSqlType.double, requiredDuringInsert: false);
  static const VerificationMeta _dataLancamentoMeta =
      const VerificationMeta('dataLancamento');
  @override
  late final GeneratedColumn<DateTime> dataLancamento =
      GeneratedColumn<DateTime>('data_lancamento', aliasedName, true,
          type: DriftSqlType.dateTime, requiredDuringInsert: false);
  static const VerificationMeta _dataInclusaoMeta =
      const VerificationMeta('dataInclusao');
  @override
  late final GeneratedColumn<DateTime> dataInclusao = GeneratedColumn<DateTime>(
      'data_inclusao', aliasedName, true,
      type: DriftSqlType.dateTime, requiredDuringInsert: false);
  static const VerificationMeta _origemDeRateioMeta =
      const VerificationMeta('origemDeRateio');
  @override
  late final GeneratedColumn<String> origemDeRateio = GeneratedColumn<String>(
      'origem_de_rateio', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 1),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _historicoMeta =
      const VerificationMeta('historico');
  @override
  late final GeneratedColumn<String> historico = GeneratedColumn<String>(
      'historico', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 250),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  @override
  List<GeneratedColumn> get $columns => [
        id,
        idCentroResultado,
        valor,
        dataLancamento,
        dataInclusao,
        origemDeRateio,
        historico
      ];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'lanca_centro_resultado';
  @override
  VerificationContext validateIntegrity(
      Insertable<LancaCentroResultado> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('id_centro_resultado')) {
      context.handle(
          _idCentroResultadoMeta,
          idCentroResultado.isAcceptableOrUnknown(
              data['id_centro_resultado']!, _idCentroResultadoMeta));
    }
    if (data.containsKey('valor')) {
      context.handle(
          _valorMeta, valor.isAcceptableOrUnknown(data['valor']!, _valorMeta));
    }
    if (data.containsKey('data_lancamento')) {
      context.handle(
          _dataLancamentoMeta,
          dataLancamento.isAcceptableOrUnknown(
              data['data_lancamento']!, _dataLancamentoMeta));
    }
    if (data.containsKey('data_inclusao')) {
      context.handle(
          _dataInclusaoMeta,
          dataInclusao.isAcceptableOrUnknown(
              data['data_inclusao']!, _dataInclusaoMeta));
    }
    if (data.containsKey('origem_de_rateio')) {
      context.handle(
          _origemDeRateioMeta,
          origemDeRateio.isAcceptableOrUnknown(
              data['origem_de_rateio']!, _origemDeRateioMeta));
    }
    if (data.containsKey('historico')) {
      context.handle(_historicoMeta,
          historico.isAcceptableOrUnknown(data['historico']!, _historicoMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  LancaCentroResultado map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return LancaCentroResultado(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id']),
      idCentroResultado: attachedDatabase.typeMapping.read(
          DriftSqlType.int, data['${effectivePrefix}id_centro_resultado']),
      valor: attachedDatabase.typeMapping
          .read(DriftSqlType.double, data['${effectivePrefix}valor']),
      dataLancamento: attachedDatabase.typeMapping.read(
          DriftSqlType.dateTime, data['${effectivePrefix}data_lancamento']),
      dataInclusao: attachedDatabase.typeMapping
          .read(DriftSqlType.dateTime, data['${effectivePrefix}data_inclusao']),
      origemDeRateio: attachedDatabase.typeMapping.read(
          DriftSqlType.string, data['${effectivePrefix}origem_de_rateio']),
      historico: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}historico']),
    );
  }

  @override
  $LancaCentroResultadosTable createAlias(String alias) {
    return $LancaCentroResultadosTable(attachedDatabase, alias);
  }
}

class LancaCentroResultado extends DataClass
    implements Insertable<LancaCentroResultado> {
  final int? id;
  final int? idCentroResultado;
  final double? valor;
  final DateTime? dataLancamento;
  final DateTime? dataInclusao;
  final String? origemDeRateio;
  final String? historico;
  const LancaCentroResultado(
      {this.id,
      this.idCentroResultado,
      this.valor,
      this.dataLancamento,
      this.dataInclusao,
      this.origemDeRateio,
      this.historico});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || idCentroResultado != null) {
      map['id_centro_resultado'] = Variable<int>(idCentroResultado);
    }
    if (!nullToAbsent || valor != null) {
      map['valor'] = Variable<double>(valor);
    }
    if (!nullToAbsent || dataLancamento != null) {
      map['data_lancamento'] = Variable<DateTime>(dataLancamento);
    }
    if (!nullToAbsent || dataInclusao != null) {
      map['data_inclusao'] = Variable<DateTime>(dataInclusao);
    }
    if (!nullToAbsent || origemDeRateio != null) {
      map['origem_de_rateio'] = Variable<String>(origemDeRateio);
    }
    if (!nullToAbsent || historico != null) {
      map['historico'] = Variable<String>(historico);
    }
    return map;
  }

  factory LancaCentroResultado.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return LancaCentroResultado(
      id: serializer.fromJson<int?>(json['id']),
      idCentroResultado: serializer.fromJson<int?>(json['idCentroResultado']),
      valor: serializer.fromJson<double?>(json['valor']),
      dataLancamento: serializer.fromJson<DateTime?>(json['dataLancamento']),
      dataInclusao: serializer.fromJson<DateTime?>(json['dataInclusao']),
      origemDeRateio: serializer.fromJson<String?>(json['origemDeRateio']),
      historico: serializer.fromJson<String?>(json['historico']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'idCentroResultado': serializer.toJson<int?>(idCentroResultado),
      'valor': serializer.toJson<double?>(valor),
      'dataLancamento': serializer.toJson<DateTime?>(dataLancamento),
      'dataInclusao': serializer.toJson<DateTime?>(dataInclusao),
      'origemDeRateio': serializer.toJson<String?>(origemDeRateio),
      'historico': serializer.toJson<String?>(historico),
    };
  }

  LancaCentroResultado copyWith(
          {Value<int?> id = const Value.absent(),
          Value<int?> idCentroResultado = const Value.absent(),
          Value<double?> valor = const Value.absent(),
          Value<DateTime?> dataLancamento = const Value.absent(),
          Value<DateTime?> dataInclusao = const Value.absent(),
          Value<String?> origemDeRateio = const Value.absent(),
          Value<String?> historico = const Value.absent()}) =>
      LancaCentroResultado(
        id: id.present ? id.value : this.id,
        idCentroResultado: idCentroResultado.present
            ? idCentroResultado.value
            : this.idCentroResultado,
        valor: valor.present ? valor.value : this.valor,
        dataLancamento:
            dataLancamento.present ? dataLancamento.value : this.dataLancamento,
        dataInclusao:
            dataInclusao.present ? dataInclusao.value : this.dataInclusao,
        origemDeRateio:
            origemDeRateio.present ? origemDeRateio.value : this.origemDeRateio,
        historico: historico.present ? historico.value : this.historico,
      );
  LancaCentroResultado copyWithCompanion(LancaCentroResultadosCompanion data) {
    return LancaCentroResultado(
      id: data.id.present ? data.id.value : this.id,
      idCentroResultado: data.idCentroResultado.present
          ? data.idCentroResultado.value
          : this.idCentroResultado,
      valor: data.valor.present ? data.valor.value : this.valor,
      dataLancamento: data.dataLancamento.present
          ? data.dataLancamento.value
          : this.dataLancamento,
      dataInclusao: data.dataInclusao.present
          ? data.dataInclusao.value
          : this.dataInclusao,
      origemDeRateio: data.origemDeRateio.present
          ? data.origemDeRateio.value
          : this.origemDeRateio,
      historico: data.historico.present ? data.historico.value : this.historico,
    );
  }

  @override
  String toString() {
    return (StringBuffer('LancaCentroResultado(')
          ..write('id: $id, ')
          ..write('idCentroResultado: $idCentroResultado, ')
          ..write('valor: $valor, ')
          ..write('dataLancamento: $dataLancamento, ')
          ..write('dataInclusao: $dataInclusao, ')
          ..write('origemDeRateio: $origemDeRateio, ')
          ..write('historico: $historico')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(id, idCentroResultado, valor, dataLancamento,
      dataInclusao, origemDeRateio, historico);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is LancaCentroResultado &&
          other.id == this.id &&
          other.idCentroResultado == this.idCentroResultado &&
          other.valor == this.valor &&
          other.dataLancamento == this.dataLancamento &&
          other.dataInclusao == this.dataInclusao &&
          other.origemDeRateio == this.origemDeRateio &&
          other.historico == this.historico);
}

class LancaCentroResultadosCompanion
    extends UpdateCompanion<LancaCentroResultado> {
  final Value<int?> id;
  final Value<int?> idCentroResultado;
  final Value<double?> valor;
  final Value<DateTime?> dataLancamento;
  final Value<DateTime?> dataInclusao;
  final Value<String?> origemDeRateio;
  final Value<String?> historico;
  const LancaCentroResultadosCompanion({
    this.id = const Value.absent(),
    this.idCentroResultado = const Value.absent(),
    this.valor = const Value.absent(),
    this.dataLancamento = const Value.absent(),
    this.dataInclusao = const Value.absent(),
    this.origemDeRateio = const Value.absent(),
    this.historico = const Value.absent(),
  });
  LancaCentroResultadosCompanion.insert({
    this.id = const Value.absent(),
    this.idCentroResultado = const Value.absent(),
    this.valor = const Value.absent(),
    this.dataLancamento = const Value.absent(),
    this.dataInclusao = const Value.absent(),
    this.origemDeRateio = const Value.absent(),
    this.historico = const Value.absent(),
  });
  static Insertable<LancaCentroResultado> custom({
    Expression<int>? id,
    Expression<int>? idCentroResultado,
    Expression<double>? valor,
    Expression<DateTime>? dataLancamento,
    Expression<DateTime>? dataInclusao,
    Expression<String>? origemDeRateio,
    Expression<String>? historico,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (idCentroResultado != null) 'id_centro_resultado': idCentroResultado,
      if (valor != null) 'valor': valor,
      if (dataLancamento != null) 'data_lancamento': dataLancamento,
      if (dataInclusao != null) 'data_inclusao': dataInclusao,
      if (origemDeRateio != null) 'origem_de_rateio': origemDeRateio,
      if (historico != null) 'historico': historico,
    });
  }

  LancaCentroResultadosCompanion copyWith(
      {Value<int?>? id,
      Value<int?>? idCentroResultado,
      Value<double?>? valor,
      Value<DateTime?>? dataLancamento,
      Value<DateTime?>? dataInclusao,
      Value<String?>? origemDeRateio,
      Value<String?>? historico}) {
    return LancaCentroResultadosCompanion(
      id: id ?? this.id,
      idCentroResultado: idCentroResultado ?? this.idCentroResultado,
      valor: valor ?? this.valor,
      dataLancamento: dataLancamento ?? this.dataLancamento,
      dataInclusao: dataInclusao ?? this.dataInclusao,
      origemDeRateio: origemDeRateio ?? this.origemDeRateio,
      historico: historico ?? this.historico,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (idCentroResultado.present) {
      map['id_centro_resultado'] = Variable<int>(idCentroResultado.value);
    }
    if (valor.present) {
      map['valor'] = Variable<double>(valor.value);
    }
    if (dataLancamento.present) {
      map['data_lancamento'] = Variable<DateTime>(dataLancamento.value);
    }
    if (dataInclusao.present) {
      map['data_inclusao'] = Variable<DateTime>(dataInclusao.value);
    }
    if (origemDeRateio.present) {
      map['origem_de_rateio'] = Variable<String>(origemDeRateio.value);
    }
    if (historico.present) {
      map['historico'] = Variable<String>(historico.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('LancaCentroResultadosCompanion(')
          ..write('id: $id, ')
          ..write('idCentroResultado: $idCentroResultado, ')
          ..write('valor: $valor, ')
          ..write('dataLancamento: $dataLancamento, ')
          ..write('dataInclusao: $dataInclusao, ')
          ..write('origemDeRateio: $origemDeRateio, ')
          ..write('historico: $historico')
          ..write(')'))
        .toString();
  }
}

class $EncerraCentroResultadosTable extends EncerraCentroResultados
    with TableInfo<$EncerraCentroResultadosTable, EncerraCentroResultado> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $EncerraCentroResultadosTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
      'id', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _idCentroResultadoMeta =
      const VerificationMeta('idCentroResultado');
  @override
  late final GeneratedColumn<int> idCentroResultado = GeneratedColumn<int>(
      'id_centro_resultado', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _competenciaMeta =
      const VerificationMeta('competencia');
  @override
  late final GeneratedColumn<String> competencia = GeneratedColumn<String>(
      'competencia', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 7),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _valorTotalMeta =
      const VerificationMeta('valorTotal');
  @override
  late final GeneratedColumn<double> valorTotal = GeneratedColumn<double>(
      'valor_total', aliasedName, true,
      type: DriftSqlType.double, requiredDuringInsert: false);
  static const VerificationMeta _valorSubRateioMeta =
      const VerificationMeta('valorSubRateio');
  @override
  late final GeneratedColumn<double> valorSubRateio = GeneratedColumn<double>(
      'valor_sub_rateio', aliasedName, true,
      type: DriftSqlType.double, requiredDuringInsert: false);
  @override
  List<GeneratedColumn> get $columns =>
      [id, idCentroResultado, competencia, valorTotal, valorSubRateio];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'encerra_centro_resultado';
  @override
  VerificationContext validateIntegrity(
      Insertable<EncerraCentroResultado> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('id_centro_resultado')) {
      context.handle(
          _idCentroResultadoMeta,
          idCentroResultado.isAcceptableOrUnknown(
              data['id_centro_resultado']!, _idCentroResultadoMeta));
    }
    if (data.containsKey('competencia')) {
      context.handle(
          _competenciaMeta,
          competencia.isAcceptableOrUnknown(
              data['competencia']!, _competenciaMeta));
    }
    if (data.containsKey('valor_total')) {
      context.handle(
          _valorTotalMeta,
          valorTotal.isAcceptableOrUnknown(
              data['valor_total']!, _valorTotalMeta));
    }
    if (data.containsKey('valor_sub_rateio')) {
      context.handle(
          _valorSubRateioMeta,
          valorSubRateio.isAcceptableOrUnknown(
              data['valor_sub_rateio']!, _valorSubRateioMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  EncerraCentroResultado map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return EncerraCentroResultado(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id']),
      idCentroResultado: attachedDatabase.typeMapping.read(
          DriftSqlType.int, data['${effectivePrefix}id_centro_resultado']),
      competencia: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}competencia']),
      valorTotal: attachedDatabase.typeMapping
          .read(DriftSqlType.double, data['${effectivePrefix}valor_total']),
      valorSubRateio: attachedDatabase.typeMapping.read(
          DriftSqlType.double, data['${effectivePrefix}valor_sub_rateio']),
    );
  }

  @override
  $EncerraCentroResultadosTable createAlias(String alias) {
    return $EncerraCentroResultadosTable(attachedDatabase, alias);
  }
}

class EncerraCentroResultado extends DataClass
    implements Insertable<EncerraCentroResultado> {
  final int? id;
  final int? idCentroResultado;
  final String? competencia;
  final double? valorTotal;
  final double? valorSubRateio;
  const EncerraCentroResultado(
      {this.id,
      this.idCentroResultado,
      this.competencia,
      this.valorTotal,
      this.valorSubRateio});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || idCentroResultado != null) {
      map['id_centro_resultado'] = Variable<int>(idCentroResultado);
    }
    if (!nullToAbsent || competencia != null) {
      map['competencia'] = Variable<String>(competencia);
    }
    if (!nullToAbsent || valorTotal != null) {
      map['valor_total'] = Variable<double>(valorTotal);
    }
    if (!nullToAbsent || valorSubRateio != null) {
      map['valor_sub_rateio'] = Variable<double>(valorSubRateio);
    }
    return map;
  }

  factory EncerraCentroResultado.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return EncerraCentroResultado(
      id: serializer.fromJson<int?>(json['id']),
      idCentroResultado: serializer.fromJson<int?>(json['idCentroResultado']),
      competencia: serializer.fromJson<String?>(json['competencia']),
      valorTotal: serializer.fromJson<double?>(json['valorTotal']),
      valorSubRateio: serializer.fromJson<double?>(json['valorSubRateio']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'idCentroResultado': serializer.toJson<int?>(idCentroResultado),
      'competencia': serializer.toJson<String?>(competencia),
      'valorTotal': serializer.toJson<double?>(valorTotal),
      'valorSubRateio': serializer.toJson<double?>(valorSubRateio),
    };
  }

  EncerraCentroResultado copyWith(
          {Value<int?> id = const Value.absent(),
          Value<int?> idCentroResultado = const Value.absent(),
          Value<String?> competencia = const Value.absent(),
          Value<double?> valorTotal = const Value.absent(),
          Value<double?> valorSubRateio = const Value.absent()}) =>
      EncerraCentroResultado(
        id: id.present ? id.value : this.id,
        idCentroResultado: idCentroResultado.present
            ? idCentroResultado.value
            : this.idCentroResultado,
        competencia: competencia.present ? competencia.value : this.competencia,
        valorTotal: valorTotal.present ? valorTotal.value : this.valorTotal,
        valorSubRateio:
            valorSubRateio.present ? valorSubRateio.value : this.valorSubRateio,
      );
  EncerraCentroResultado copyWithCompanion(
      EncerraCentroResultadosCompanion data) {
    return EncerraCentroResultado(
      id: data.id.present ? data.id.value : this.id,
      idCentroResultado: data.idCentroResultado.present
          ? data.idCentroResultado.value
          : this.idCentroResultado,
      competencia:
          data.competencia.present ? data.competencia.value : this.competencia,
      valorTotal:
          data.valorTotal.present ? data.valorTotal.value : this.valorTotal,
      valorSubRateio: data.valorSubRateio.present
          ? data.valorSubRateio.value
          : this.valorSubRateio,
    );
  }

  @override
  String toString() {
    return (StringBuffer('EncerraCentroResultado(')
          ..write('id: $id, ')
          ..write('idCentroResultado: $idCentroResultado, ')
          ..write('competencia: $competencia, ')
          ..write('valorTotal: $valorTotal, ')
          ..write('valorSubRateio: $valorSubRateio')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(
      id, idCentroResultado, competencia, valorTotal, valorSubRateio);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is EncerraCentroResultado &&
          other.id == this.id &&
          other.idCentroResultado == this.idCentroResultado &&
          other.competencia == this.competencia &&
          other.valorTotal == this.valorTotal &&
          other.valorSubRateio == this.valorSubRateio);
}

class EncerraCentroResultadosCompanion
    extends UpdateCompanion<EncerraCentroResultado> {
  final Value<int?> id;
  final Value<int?> idCentroResultado;
  final Value<String?> competencia;
  final Value<double?> valorTotal;
  final Value<double?> valorSubRateio;
  const EncerraCentroResultadosCompanion({
    this.id = const Value.absent(),
    this.idCentroResultado = const Value.absent(),
    this.competencia = const Value.absent(),
    this.valorTotal = const Value.absent(),
    this.valorSubRateio = const Value.absent(),
  });
  EncerraCentroResultadosCompanion.insert({
    this.id = const Value.absent(),
    this.idCentroResultado = const Value.absent(),
    this.competencia = const Value.absent(),
    this.valorTotal = const Value.absent(),
    this.valorSubRateio = const Value.absent(),
  });
  static Insertable<EncerraCentroResultado> custom({
    Expression<int>? id,
    Expression<int>? idCentroResultado,
    Expression<String>? competencia,
    Expression<double>? valorTotal,
    Expression<double>? valorSubRateio,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (idCentroResultado != null) 'id_centro_resultado': idCentroResultado,
      if (competencia != null) 'competencia': competencia,
      if (valorTotal != null) 'valor_total': valorTotal,
      if (valorSubRateio != null) 'valor_sub_rateio': valorSubRateio,
    });
  }

  EncerraCentroResultadosCompanion copyWith(
      {Value<int?>? id,
      Value<int?>? idCentroResultado,
      Value<String?>? competencia,
      Value<double?>? valorTotal,
      Value<double?>? valorSubRateio}) {
    return EncerraCentroResultadosCompanion(
      id: id ?? this.id,
      idCentroResultado: idCentroResultado ?? this.idCentroResultado,
      competencia: competencia ?? this.competencia,
      valorTotal: valorTotal ?? this.valorTotal,
      valorSubRateio: valorSubRateio ?? this.valorSubRateio,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (idCentroResultado.present) {
      map['id_centro_resultado'] = Variable<int>(idCentroResultado.value);
    }
    if (competencia.present) {
      map['competencia'] = Variable<String>(competencia.value);
    }
    if (valorTotal.present) {
      map['valor_total'] = Variable<double>(valorTotal.value);
    }
    if (valorSubRateio.present) {
      map['valor_sub_rateio'] = Variable<double>(valorSubRateio.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('EncerraCentroResultadosCompanion(')
          ..write('id: $id, ')
          ..write('idCentroResultado: $idCentroResultado, ')
          ..write('competencia: $competencia, ')
          ..write('valorTotal: $valorTotal, ')
          ..write('valorSubRateio: $valorSubRateio')
          ..write(')'))
        .toString();
  }
}

class $ContabilContaRateiosTable extends ContabilContaRateios
    with TableInfo<$ContabilContaRateiosTable, ContabilContaRateio> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $ContabilContaRateiosTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
      'id', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _idCentroResultadoMeta =
      const VerificationMeta('idCentroResultado');
  @override
  late final GeneratedColumn<int> idCentroResultado = GeneratedColumn<int>(
      'id_centro_resultado', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _idContabilContaMeta =
      const VerificationMeta('idContabilConta');
  @override
  late final GeneratedColumn<int> idContabilConta = GeneratedColumn<int>(
      'id_contabil_conta', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _porcentoRateioMeta =
      const VerificationMeta('porcentoRateio');
  @override
  late final GeneratedColumn<double> porcentoRateio = GeneratedColumn<double>(
      'porcento_rateio', aliasedName, true,
      type: DriftSqlType.double, requiredDuringInsert: false);
  @override
  List<GeneratedColumn> get $columns =>
      [id, idCentroResultado, idContabilConta, porcentoRateio];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'contabil_conta_rateio';
  @override
  VerificationContext validateIntegrity(
      Insertable<ContabilContaRateio> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('id_centro_resultado')) {
      context.handle(
          _idCentroResultadoMeta,
          idCentroResultado.isAcceptableOrUnknown(
              data['id_centro_resultado']!, _idCentroResultadoMeta));
    }
    if (data.containsKey('id_contabil_conta')) {
      context.handle(
          _idContabilContaMeta,
          idContabilConta.isAcceptableOrUnknown(
              data['id_contabil_conta']!, _idContabilContaMeta));
    }
    if (data.containsKey('porcento_rateio')) {
      context.handle(
          _porcentoRateioMeta,
          porcentoRateio.isAcceptableOrUnknown(
              data['porcento_rateio']!, _porcentoRateioMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  ContabilContaRateio map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return ContabilContaRateio(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id']),
      idCentroResultado: attachedDatabase.typeMapping.read(
          DriftSqlType.int, data['${effectivePrefix}id_centro_resultado']),
      idContabilConta: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id_contabil_conta']),
      porcentoRateio: attachedDatabase.typeMapping
          .read(DriftSqlType.double, data['${effectivePrefix}porcento_rateio']),
    );
  }

  @override
  $ContabilContaRateiosTable createAlias(String alias) {
    return $ContabilContaRateiosTable(attachedDatabase, alias);
  }
}

class ContabilContaRateio extends DataClass
    implements Insertable<ContabilContaRateio> {
  final int? id;
  final int? idCentroResultado;
  final int? idContabilConta;
  final double? porcentoRateio;
  const ContabilContaRateio(
      {this.id,
      this.idCentroResultado,
      this.idContabilConta,
      this.porcentoRateio});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || idCentroResultado != null) {
      map['id_centro_resultado'] = Variable<int>(idCentroResultado);
    }
    if (!nullToAbsent || idContabilConta != null) {
      map['id_contabil_conta'] = Variable<int>(idContabilConta);
    }
    if (!nullToAbsent || porcentoRateio != null) {
      map['porcento_rateio'] = Variable<double>(porcentoRateio);
    }
    return map;
  }

  factory ContabilContaRateio.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return ContabilContaRateio(
      id: serializer.fromJson<int?>(json['id']),
      idCentroResultado: serializer.fromJson<int?>(json['idCentroResultado']),
      idContabilConta: serializer.fromJson<int?>(json['idContabilConta']),
      porcentoRateio: serializer.fromJson<double?>(json['porcentoRateio']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'idCentroResultado': serializer.toJson<int?>(idCentroResultado),
      'idContabilConta': serializer.toJson<int?>(idContabilConta),
      'porcentoRateio': serializer.toJson<double?>(porcentoRateio),
    };
  }

  ContabilContaRateio copyWith(
          {Value<int?> id = const Value.absent(),
          Value<int?> idCentroResultado = const Value.absent(),
          Value<int?> idContabilConta = const Value.absent(),
          Value<double?> porcentoRateio = const Value.absent()}) =>
      ContabilContaRateio(
        id: id.present ? id.value : this.id,
        idCentroResultado: idCentroResultado.present
            ? idCentroResultado.value
            : this.idCentroResultado,
        idContabilConta: idContabilConta.present
            ? idContabilConta.value
            : this.idContabilConta,
        porcentoRateio:
            porcentoRateio.present ? porcentoRateio.value : this.porcentoRateio,
      );
  ContabilContaRateio copyWithCompanion(ContabilContaRateiosCompanion data) {
    return ContabilContaRateio(
      id: data.id.present ? data.id.value : this.id,
      idCentroResultado: data.idCentroResultado.present
          ? data.idCentroResultado.value
          : this.idCentroResultado,
      idContabilConta: data.idContabilConta.present
          ? data.idContabilConta.value
          : this.idContabilConta,
      porcentoRateio: data.porcentoRateio.present
          ? data.porcentoRateio.value
          : this.porcentoRateio,
    );
  }

  @override
  String toString() {
    return (StringBuffer('ContabilContaRateio(')
          ..write('id: $id, ')
          ..write('idCentroResultado: $idCentroResultado, ')
          ..write('idContabilConta: $idContabilConta, ')
          ..write('porcentoRateio: $porcentoRateio')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode =>
      Object.hash(id, idCentroResultado, idContabilConta, porcentoRateio);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is ContabilContaRateio &&
          other.id == this.id &&
          other.idCentroResultado == this.idCentroResultado &&
          other.idContabilConta == this.idContabilConta &&
          other.porcentoRateio == this.porcentoRateio);
}

class ContabilContaRateiosCompanion
    extends UpdateCompanion<ContabilContaRateio> {
  final Value<int?> id;
  final Value<int?> idCentroResultado;
  final Value<int?> idContabilConta;
  final Value<double?> porcentoRateio;
  const ContabilContaRateiosCompanion({
    this.id = const Value.absent(),
    this.idCentroResultado = const Value.absent(),
    this.idContabilConta = const Value.absent(),
    this.porcentoRateio = const Value.absent(),
  });
  ContabilContaRateiosCompanion.insert({
    this.id = const Value.absent(),
    this.idCentroResultado = const Value.absent(),
    this.idContabilConta = const Value.absent(),
    this.porcentoRateio = const Value.absent(),
  });
  static Insertable<ContabilContaRateio> custom({
    Expression<int>? id,
    Expression<int>? idCentroResultado,
    Expression<int>? idContabilConta,
    Expression<double>? porcentoRateio,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (idCentroResultado != null) 'id_centro_resultado': idCentroResultado,
      if (idContabilConta != null) 'id_contabil_conta': idContabilConta,
      if (porcentoRateio != null) 'porcento_rateio': porcentoRateio,
    });
  }

  ContabilContaRateiosCompanion copyWith(
      {Value<int?>? id,
      Value<int?>? idCentroResultado,
      Value<int?>? idContabilConta,
      Value<double?>? porcentoRateio}) {
    return ContabilContaRateiosCompanion(
      id: id ?? this.id,
      idCentroResultado: idCentroResultado ?? this.idCentroResultado,
      idContabilConta: idContabilConta ?? this.idContabilConta,
      porcentoRateio: porcentoRateio ?? this.porcentoRateio,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (idCentroResultado.present) {
      map['id_centro_resultado'] = Variable<int>(idCentroResultado.value);
    }
    if (idContabilConta.present) {
      map['id_contabil_conta'] = Variable<int>(idContabilConta.value);
    }
    if (porcentoRateio.present) {
      map['porcento_rateio'] = Variable<double>(porcentoRateio.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('ContabilContaRateiosCompanion(')
          ..write('id: $id, ')
          ..write('idCentroResultado: $idCentroResultado, ')
          ..write('idContabilConta: $idContabilConta, ')
          ..write('porcentoRateio: $porcentoRateio')
          ..write(')'))
        .toString();
  }
}

class $ContabilFechamentosTable extends ContabilFechamentos
    with TableInfo<$ContabilFechamentosTable, ContabilFechamento> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $ContabilFechamentosTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
      'id', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _dataInicioMeta =
      const VerificationMeta('dataInicio');
  @override
  late final GeneratedColumn<DateTime> dataInicio = GeneratedColumn<DateTime>(
      'data_inicio', aliasedName, true,
      type: DriftSqlType.dateTime, requiredDuringInsert: false);
  static const VerificationMeta _dataFimMeta =
      const VerificationMeta('dataFim');
  @override
  late final GeneratedColumn<DateTime> dataFim = GeneratedColumn<DateTime>(
      'data_fim', aliasedName, true,
      type: DriftSqlType.dateTime, requiredDuringInsert: false);
  static const VerificationMeta _criterioLancamentoMeta =
      const VerificationMeta('criterioLancamento');
  @override
  late final GeneratedColumn<String> criterioLancamento =
      GeneratedColumn<String>('criterio_lancamento', aliasedName, true,
          additionalChecks: GeneratedColumn.checkTextLength(
              minTextLength: 0, maxTextLength: 1),
          type: DriftSqlType.string,
          requiredDuringInsert: false);
  @override
  List<GeneratedColumn> get $columns =>
      [id, dataInicio, dataFim, criterioLancamento];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'contabil_fechamento';
  @override
  VerificationContext validateIntegrity(Insertable<ContabilFechamento> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('data_inicio')) {
      context.handle(
          _dataInicioMeta,
          dataInicio.isAcceptableOrUnknown(
              data['data_inicio']!, _dataInicioMeta));
    }
    if (data.containsKey('data_fim')) {
      context.handle(_dataFimMeta,
          dataFim.isAcceptableOrUnknown(data['data_fim']!, _dataFimMeta));
    }
    if (data.containsKey('criterio_lancamento')) {
      context.handle(
          _criterioLancamentoMeta,
          criterioLancamento.isAcceptableOrUnknown(
              data['criterio_lancamento']!, _criterioLancamentoMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  ContabilFechamento map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return ContabilFechamento(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id']),
      dataInicio: attachedDatabase.typeMapping
          .read(DriftSqlType.dateTime, data['${effectivePrefix}data_inicio']),
      dataFim: attachedDatabase.typeMapping
          .read(DriftSqlType.dateTime, data['${effectivePrefix}data_fim']),
      criterioLancamento: attachedDatabase.typeMapping.read(
          DriftSqlType.string, data['${effectivePrefix}criterio_lancamento']),
    );
  }

  @override
  $ContabilFechamentosTable createAlias(String alias) {
    return $ContabilFechamentosTable(attachedDatabase, alias);
  }
}

class ContabilFechamento extends DataClass
    implements Insertable<ContabilFechamento> {
  final int? id;
  final DateTime? dataInicio;
  final DateTime? dataFim;
  final String? criterioLancamento;
  const ContabilFechamento(
      {this.id, this.dataInicio, this.dataFim, this.criterioLancamento});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || dataInicio != null) {
      map['data_inicio'] = Variable<DateTime>(dataInicio);
    }
    if (!nullToAbsent || dataFim != null) {
      map['data_fim'] = Variable<DateTime>(dataFim);
    }
    if (!nullToAbsent || criterioLancamento != null) {
      map['criterio_lancamento'] = Variable<String>(criterioLancamento);
    }
    return map;
  }

  factory ContabilFechamento.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return ContabilFechamento(
      id: serializer.fromJson<int?>(json['id']),
      dataInicio: serializer.fromJson<DateTime?>(json['dataInicio']),
      dataFim: serializer.fromJson<DateTime?>(json['dataFim']),
      criterioLancamento:
          serializer.fromJson<String?>(json['criterioLancamento']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'dataInicio': serializer.toJson<DateTime?>(dataInicio),
      'dataFim': serializer.toJson<DateTime?>(dataFim),
      'criterioLancamento': serializer.toJson<String?>(criterioLancamento),
    };
  }

  ContabilFechamento copyWith(
          {Value<int?> id = const Value.absent(),
          Value<DateTime?> dataInicio = const Value.absent(),
          Value<DateTime?> dataFim = const Value.absent(),
          Value<String?> criterioLancamento = const Value.absent()}) =>
      ContabilFechamento(
        id: id.present ? id.value : this.id,
        dataInicio: dataInicio.present ? dataInicio.value : this.dataInicio,
        dataFim: dataFim.present ? dataFim.value : this.dataFim,
        criterioLancamento: criterioLancamento.present
            ? criterioLancamento.value
            : this.criterioLancamento,
      );
  ContabilFechamento copyWithCompanion(ContabilFechamentosCompanion data) {
    return ContabilFechamento(
      id: data.id.present ? data.id.value : this.id,
      dataInicio:
          data.dataInicio.present ? data.dataInicio.value : this.dataInicio,
      dataFim: data.dataFim.present ? data.dataFim.value : this.dataFim,
      criterioLancamento: data.criterioLancamento.present
          ? data.criterioLancamento.value
          : this.criterioLancamento,
    );
  }

  @override
  String toString() {
    return (StringBuffer('ContabilFechamento(')
          ..write('id: $id, ')
          ..write('dataInicio: $dataInicio, ')
          ..write('dataFim: $dataFim, ')
          ..write('criterioLancamento: $criterioLancamento')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(id, dataInicio, dataFim, criterioLancamento);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is ContabilFechamento &&
          other.id == this.id &&
          other.dataInicio == this.dataInicio &&
          other.dataFim == this.dataFim &&
          other.criterioLancamento == this.criterioLancamento);
}

class ContabilFechamentosCompanion extends UpdateCompanion<ContabilFechamento> {
  final Value<int?> id;
  final Value<DateTime?> dataInicio;
  final Value<DateTime?> dataFim;
  final Value<String?> criterioLancamento;
  const ContabilFechamentosCompanion({
    this.id = const Value.absent(),
    this.dataInicio = const Value.absent(),
    this.dataFim = const Value.absent(),
    this.criterioLancamento = const Value.absent(),
  });
  ContabilFechamentosCompanion.insert({
    this.id = const Value.absent(),
    this.dataInicio = const Value.absent(),
    this.dataFim = const Value.absent(),
    this.criterioLancamento = const Value.absent(),
  });
  static Insertable<ContabilFechamento> custom({
    Expression<int>? id,
    Expression<DateTime>? dataInicio,
    Expression<DateTime>? dataFim,
    Expression<String>? criterioLancamento,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (dataInicio != null) 'data_inicio': dataInicio,
      if (dataFim != null) 'data_fim': dataFim,
      if (criterioLancamento != null) 'criterio_lancamento': criterioLancamento,
    });
  }

  ContabilFechamentosCompanion copyWith(
      {Value<int?>? id,
      Value<DateTime?>? dataInicio,
      Value<DateTime?>? dataFim,
      Value<String?>? criterioLancamento}) {
    return ContabilFechamentosCompanion(
      id: id ?? this.id,
      dataInicio: dataInicio ?? this.dataInicio,
      dataFim: dataFim ?? this.dataFim,
      criterioLancamento: criterioLancamento ?? this.criterioLancamento,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (dataInicio.present) {
      map['data_inicio'] = Variable<DateTime>(dataInicio.value);
    }
    if (dataFim.present) {
      map['data_fim'] = Variable<DateTime>(dataFim.value);
    }
    if (criterioLancamento.present) {
      map['criterio_lancamento'] = Variable<String>(criterioLancamento.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('ContabilFechamentosCompanion(')
          ..write('id: $id, ')
          ..write('dataInicio: $dataInicio, ')
          ..write('dataFim: $dataFim, ')
          ..write('criterioLancamento: $criterioLancamento')
          ..write(')'))
        .toString();
  }
}

class $ViewControleAcessosTable extends ViewControleAcessos
    with TableInfo<$ViewControleAcessosTable, ViewControleAcesso> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $ViewControleAcessosTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
      'id', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _idPessoaMeta =
      const VerificationMeta('idPessoa');
  @override
  late final GeneratedColumn<int> idPessoa = GeneratedColumn<int>(
      'id_pessoa', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _pessoaNomeMeta =
      const VerificationMeta('pessoaNome');
  @override
  late final GeneratedColumn<String> pessoaNome = GeneratedColumn<String>(
      'pessoa_nome', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 450),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _idColaboradorMeta =
      const VerificationMeta('idColaborador');
  @override
  late final GeneratedColumn<int> idColaborador = GeneratedColumn<int>(
      'id_colaborador', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _idUsuarioMeta =
      const VerificationMeta('idUsuario');
  @override
  late final GeneratedColumn<int> idUsuario = GeneratedColumn<int>(
      'id_usuario', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _administradorMeta =
      const VerificationMeta('administrador');
  @override
  late final GeneratedColumn<String> administrador = GeneratedColumn<String>(
      'administrador', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 3),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _idPapelMeta =
      const VerificationMeta('idPapel');
  @override
  late final GeneratedColumn<int> idPapel = GeneratedColumn<int>(
      'id_papel', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _papelNomeMeta =
      const VerificationMeta('papelNome');
  @override
  late final GeneratedColumn<String> papelNome = GeneratedColumn<String>(
      'papel_nome', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 300),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _papelDescricaoMeta =
      const VerificationMeta('papelDescricao');
  @override
  late final GeneratedColumn<String> papelDescricao = GeneratedColumn<String>(
      'papel_descricao', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 750),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _idFuncaoMeta =
      const VerificationMeta('idFuncao');
  @override
  late final GeneratedColumn<int> idFuncao = GeneratedColumn<int>(
      'id_funcao', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _funcaoNomeMeta =
      const VerificationMeta('funcaoNome');
  @override
  late final GeneratedColumn<String> funcaoNome = GeneratedColumn<String>(
      'funcao_nome', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 300),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _funcaoDescricaoMeta =
      const VerificationMeta('funcaoDescricao');
  @override
  late final GeneratedColumn<String> funcaoDescricao = GeneratedColumn<String>(
      'funcao_descricao', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 750),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _idPapelFuncaoMeta =
      const VerificationMeta('idPapelFuncao');
  @override
  late final GeneratedColumn<int> idPapelFuncao = GeneratedColumn<int>(
      'id_papel_funcao', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _habilitadoMeta =
      const VerificationMeta('habilitado');
  @override
  late final GeneratedColumn<String> habilitado = GeneratedColumn<String>(
      'habilitado', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 3),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _podeInserirMeta =
      const VerificationMeta('podeInserir');
  @override
  late final GeneratedColumn<String> podeInserir = GeneratedColumn<String>(
      'pode_inserir', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 3),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _podeAlterarMeta =
      const VerificationMeta('podeAlterar');
  @override
  late final GeneratedColumn<String> podeAlterar = GeneratedColumn<String>(
      'pode_alterar', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 3),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _podeExcluirMeta =
      const VerificationMeta('podeExcluir');
  @override
  late final GeneratedColumn<String> podeExcluir = GeneratedColumn<String>(
      'pode_excluir', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 3),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  @override
  List<GeneratedColumn> get $columns => [
        id,
        idPessoa,
        pessoaNome,
        idColaborador,
        idUsuario,
        administrador,
        idPapel,
        papelNome,
        papelDescricao,
        idFuncao,
        funcaoNome,
        funcaoDescricao,
        idPapelFuncao,
        habilitado,
        podeInserir,
        podeAlterar,
        podeExcluir
      ];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'view_controle_acesso';
  @override
  VerificationContext validateIntegrity(Insertable<ViewControleAcesso> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('id_pessoa')) {
      context.handle(_idPessoaMeta,
          idPessoa.isAcceptableOrUnknown(data['id_pessoa']!, _idPessoaMeta));
    }
    if (data.containsKey('pessoa_nome')) {
      context.handle(
          _pessoaNomeMeta,
          pessoaNome.isAcceptableOrUnknown(
              data['pessoa_nome']!, _pessoaNomeMeta));
    }
    if (data.containsKey('id_colaborador')) {
      context.handle(
          _idColaboradorMeta,
          idColaborador.isAcceptableOrUnknown(
              data['id_colaborador']!, _idColaboradorMeta));
    }
    if (data.containsKey('id_usuario')) {
      context.handle(_idUsuarioMeta,
          idUsuario.isAcceptableOrUnknown(data['id_usuario']!, _idUsuarioMeta));
    }
    if (data.containsKey('administrador')) {
      context.handle(
          _administradorMeta,
          administrador.isAcceptableOrUnknown(
              data['administrador']!, _administradorMeta));
    }
    if (data.containsKey('id_papel')) {
      context.handle(_idPapelMeta,
          idPapel.isAcceptableOrUnknown(data['id_papel']!, _idPapelMeta));
    }
    if (data.containsKey('papel_nome')) {
      context.handle(_papelNomeMeta,
          papelNome.isAcceptableOrUnknown(data['papel_nome']!, _papelNomeMeta));
    }
    if (data.containsKey('papel_descricao')) {
      context.handle(
          _papelDescricaoMeta,
          papelDescricao.isAcceptableOrUnknown(
              data['papel_descricao']!, _papelDescricaoMeta));
    }
    if (data.containsKey('id_funcao')) {
      context.handle(_idFuncaoMeta,
          idFuncao.isAcceptableOrUnknown(data['id_funcao']!, _idFuncaoMeta));
    }
    if (data.containsKey('funcao_nome')) {
      context.handle(
          _funcaoNomeMeta,
          funcaoNome.isAcceptableOrUnknown(
              data['funcao_nome']!, _funcaoNomeMeta));
    }
    if (data.containsKey('funcao_descricao')) {
      context.handle(
          _funcaoDescricaoMeta,
          funcaoDescricao.isAcceptableOrUnknown(
              data['funcao_descricao']!, _funcaoDescricaoMeta));
    }
    if (data.containsKey('id_papel_funcao')) {
      context.handle(
          _idPapelFuncaoMeta,
          idPapelFuncao.isAcceptableOrUnknown(
              data['id_papel_funcao']!, _idPapelFuncaoMeta));
    }
    if (data.containsKey('habilitado')) {
      context.handle(
          _habilitadoMeta,
          habilitado.isAcceptableOrUnknown(
              data['habilitado']!, _habilitadoMeta));
    }
    if (data.containsKey('pode_inserir')) {
      context.handle(
          _podeInserirMeta,
          podeInserir.isAcceptableOrUnknown(
              data['pode_inserir']!, _podeInserirMeta));
    }
    if (data.containsKey('pode_alterar')) {
      context.handle(
          _podeAlterarMeta,
          podeAlterar.isAcceptableOrUnknown(
              data['pode_alterar']!, _podeAlterarMeta));
    }
    if (data.containsKey('pode_excluir')) {
      context.handle(
          _podeExcluirMeta,
          podeExcluir.isAcceptableOrUnknown(
              data['pode_excluir']!, _podeExcluirMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  ViewControleAcesso map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return ViewControleAcesso(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id']),
      idPessoa: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id_pessoa']),
      pessoaNome: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}pessoa_nome']),
      idColaborador: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id_colaborador']),
      idUsuario: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id_usuario']),
      administrador: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}administrador']),
      idPapel: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id_papel']),
      papelNome: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}papel_nome']),
      papelDescricao: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}papel_descricao']),
      idFuncao: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id_funcao']),
      funcaoNome: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}funcao_nome']),
      funcaoDescricao: attachedDatabase.typeMapping.read(
          DriftSqlType.string, data['${effectivePrefix}funcao_descricao']),
      idPapelFuncao: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id_papel_funcao']),
      habilitado: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}habilitado']),
      podeInserir: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}pode_inserir']),
      podeAlterar: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}pode_alterar']),
      podeExcluir: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}pode_excluir']),
    );
  }

  @override
  $ViewControleAcessosTable createAlias(String alias) {
    return $ViewControleAcessosTable(attachedDatabase, alias);
  }
}

class ViewControleAcesso extends DataClass
    implements Insertable<ViewControleAcesso> {
  final int? id;
  final int? idPessoa;
  final String? pessoaNome;
  final int? idColaborador;
  final int? idUsuario;
  final String? administrador;
  final int? idPapel;
  final String? papelNome;
  final String? papelDescricao;
  final int? idFuncao;
  final String? funcaoNome;
  final String? funcaoDescricao;
  final int? idPapelFuncao;
  final String? habilitado;
  final String? podeInserir;
  final String? podeAlterar;
  final String? podeExcluir;
  const ViewControleAcesso(
      {this.id,
      this.idPessoa,
      this.pessoaNome,
      this.idColaborador,
      this.idUsuario,
      this.administrador,
      this.idPapel,
      this.papelNome,
      this.papelDescricao,
      this.idFuncao,
      this.funcaoNome,
      this.funcaoDescricao,
      this.idPapelFuncao,
      this.habilitado,
      this.podeInserir,
      this.podeAlterar,
      this.podeExcluir});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || idPessoa != null) {
      map['id_pessoa'] = Variable<int>(idPessoa);
    }
    if (!nullToAbsent || pessoaNome != null) {
      map['pessoa_nome'] = Variable<String>(pessoaNome);
    }
    if (!nullToAbsent || idColaborador != null) {
      map['id_colaborador'] = Variable<int>(idColaborador);
    }
    if (!nullToAbsent || idUsuario != null) {
      map['id_usuario'] = Variable<int>(idUsuario);
    }
    if (!nullToAbsent || administrador != null) {
      map['administrador'] = Variable<String>(administrador);
    }
    if (!nullToAbsent || idPapel != null) {
      map['id_papel'] = Variable<int>(idPapel);
    }
    if (!nullToAbsent || papelNome != null) {
      map['papel_nome'] = Variable<String>(papelNome);
    }
    if (!nullToAbsent || papelDescricao != null) {
      map['papel_descricao'] = Variable<String>(papelDescricao);
    }
    if (!nullToAbsent || idFuncao != null) {
      map['id_funcao'] = Variable<int>(idFuncao);
    }
    if (!nullToAbsent || funcaoNome != null) {
      map['funcao_nome'] = Variable<String>(funcaoNome);
    }
    if (!nullToAbsent || funcaoDescricao != null) {
      map['funcao_descricao'] = Variable<String>(funcaoDescricao);
    }
    if (!nullToAbsent || idPapelFuncao != null) {
      map['id_papel_funcao'] = Variable<int>(idPapelFuncao);
    }
    if (!nullToAbsent || habilitado != null) {
      map['habilitado'] = Variable<String>(habilitado);
    }
    if (!nullToAbsent || podeInserir != null) {
      map['pode_inserir'] = Variable<String>(podeInserir);
    }
    if (!nullToAbsent || podeAlterar != null) {
      map['pode_alterar'] = Variable<String>(podeAlterar);
    }
    if (!nullToAbsent || podeExcluir != null) {
      map['pode_excluir'] = Variable<String>(podeExcluir);
    }
    return map;
  }

  factory ViewControleAcesso.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return ViewControleAcesso(
      id: serializer.fromJson<int?>(json['id']),
      idPessoa: serializer.fromJson<int?>(json['idPessoa']),
      pessoaNome: serializer.fromJson<String?>(json['pessoaNome']),
      idColaborador: serializer.fromJson<int?>(json['idColaborador']),
      idUsuario: serializer.fromJson<int?>(json['idUsuario']),
      administrador: serializer.fromJson<String?>(json['administrador']),
      idPapel: serializer.fromJson<int?>(json['idPapel']),
      papelNome: serializer.fromJson<String?>(json['papelNome']),
      papelDescricao: serializer.fromJson<String?>(json['papelDescricao']),
      idFuncao: serializer.fromJson<int?>(json['idFuncao']),
      funcaoNome: serializer.fromJson<String?>(json['funcaoNome']),
      funcaoDescricao: serializer.fromJson<String?>(json['funcaoDescricao']),
      idPapelFuncao: serializer.fromJson<int?>(json['idPapelFuncao']),
      habilitado: serializer.fromJson<String?>(json['habilitado']),
      podeInserir: serializer.fromJson<String?>(json['podeInserir']),
      podeAlterar: serializer.fromJson<String?>(json['podeAlterar']),
      podeExcluir: serializer.fromJson<String?>(json['podeExcluir']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'idPessoa': serializer.toJson<int?>(idPessoa),
      'pessoaNome': serializer.toJson<String?>(pessoaNome),
      'idColaborador': serializer.toJson<int?>(idColaborador),
      'idUsuario': serializer.toJson<int?>(idUsuario),
      'administrador': serializer.toJson<String?>(administrador),
      'idPapel': serializer.toJson<int?>(idPapel),
      'papelNome': serializer.toJson<String?>(papelNome),
      'papelDescricao': serializer.toJson<String?>(papelDescricao),
      'idFuncao': serializer.toJson<int?>(idFuncao),
      'funcaoNome': serializer.toJson<String?>(funcaoNome),
      'funcaoDescricao': serializer.toJson<String?>(funcaoDescricao),
      'idPapelFuncao': serializer.toJson<int?>(idPapelFuncao),
      'habilitado': serializer.toJson<String?>(habilitado),
      'podeInserir': serializer.toJson<String?>(podeInserir),
      'podeAlterar': serializer.toJson<String?>(podeAlterar),
      'podeExcluir': serializer.toJson<String?>(podeExcluir),
    };
  }

  ViewControleAcesso copyWith(
          {Value<int?> id = const Value.absent(),
          Value<int?> idPessoa = const Value.absent(),
          Value<String?> pessoaNome = const Value.absent(),
          Value<int?> idColaborador = const Value.absent(),
          Value<int?> idUsuario = const Value.absent(),
          Value<String?> administrador = const Value.absent(),
          Value<int?> idPapel = const Value.absent(),
          Value<String?> papelNome = const Value.absent(),
          Value<String?> papelDescricao = const Value.absent(),
          Value<int?> idFuncao = const Value.absent(),
          Value<String?> funcaoNome = const Value.absent(),
          Value<String?> funcaoDescricao = const Value.absent(),
          Value<int?> idPapelFuncao = const Value.absent(),
          Value<String?> habilitado = const Value.absent(),
          Value<String?> podeInserir = const Value.absent(),
          Value<String?> podeAlterar = const Value.absent(),
          Value<String?> podeExcluir = const Value.absent()}) =>
      ViewControleAcesso(
        id: id.present ? id.value : this.id,
        idPessoa: idPessoa.present ? idPessoa.value : this.idPessoa,
        pessoaNome: pessoaNome.present ? pessoaNome.value : this.pessoaNome,
        idColaborador:
            idColaborador.present ? idColaborador.value : this.idColaborador,
        idUsuario: idUsuario.present ? idUsuario.value : this.idUsuario,
        administrador:
            administrador.present ? administrador.value : this.administrador,
        idPapel: idPapel.present ? idPapel.value : this.idPapel,
        papelNome: papelNome.present ? papelNome.value : this.papelNome,
        papelDescricao:
            papelDescricao.present ? papelDescricao.value : this.papelDescricao,
        idFuncao: idFuncao.present ? idFuncao.value : this.idFuncao,
        funcaoNome: funcaoNome.present ? funcaoNome.value : this.funcaoNome,
        funcaoDescricao: funcaoDescricao.present
            ? funcaoDescricao.value
            : this.funcaoDescricao,
        idPapelFuncao:
            idPapelFuncao.present ? idPapelFuncao.value : this.idPapelFuncao,
        habilitado: habilitado.present ? habilitado.value : this.habilitado,
        podeInserir: podeInserir.present ? podeInserir.value : this.podeInserir,
        podeAlterar: podeAlterar.present ? podeAlterar.value : this.podeAlterar,
        podeExcluir: podeExcluir.present ? podeExcluir.value : this.podeExcluir,
      );
  ViewControleAcesso copyWithCompanion(ViewControleAcessosCompanion data) {
    return ViewControleAcesso(
      id: data.id.present ? data.id.value : this.id,
      idPessoa: data.idPessoa.present ? data.idPessoa.value : this.idPessoa,
      pessoaNome:
          data.pessoaNome.present ? data.pessoaNome.value : this.pessoaNome,
      idColaborador: data.idColaborador.present
          ? data.idColaborador.value
          : this.idColaborador,
      idUsuario: data.idUsuario.present ? data.idUsuario.value : this.idUsuario,
      administrador: data.administrador.present
          ? data.administrador.value
          : this.administrador,
      idPapel: data.idPapel.present ? data.idPapel.value : this.idPapel,
      papelNome: data.papelNome.present ? data.papelNome.value : this.papelNome,
      papelDescricao: data.papelDescricao.present
          ? data.papelDescricao.value
          : this.papelDescricao,
      idFuncao: data.idFuncao.present ? data.idFuncao.value : this.idFuncao,
      funcaoNome:
          data.funcaoNome.present ? data.funcaoNome.value : this.funcaoNome,
      funcaoDescricao: data.funcaoDescricao.present
          ? data.funcaoDescricao.value
          : this.funcaoDescricao,
      idPapelFuncao: data.idPapelFuncao.present
          ? data.idPapelFuncao.value
          : this.idPapelFuncao,
      habilitado:
          data.habilitado.present ? data.habilitado.value : this.habilitado,
      podeInserir:
          data.podeInserir.present ? data.podeInserir.value : this.podeInserir,
      podeAlterar:
          data.podeAlterar.present ? data.podeAlterar.value : this.podeAlterar,
      podeExcluir:
          data.podeExcluir.present ? data.podeExcluir.value : this.podeExcluir,
    );
  }

  @override
  String toString() {
    return (StringBuffer('ViewControleAcesso(')
          ..write('id: $id, ')
          ..write('idPessoa: $idPessoa, ')
          ..write('pessoaNome: $pessoaNome, ')
          ..write('idColaborador: $idColaborador, ')
          ..write('idUsuario: $idUsuario, ')
          ..write('administrador: $administrador, ')
          ..write('idPapel: $idPapel, ')
          ..write('papelNome: $papelNome, ')
          ..write('papelDescricao: $papelDescricao, ')
          ..write('idFuncao: $idFuncao, ')
          ..write('funcaoNome: $funcaoNome, ')
          ..write('funcaoDescricao: $funcaoDescricao, ')
          ..write('idPapelFuncao: $idPapelFuncao, ')
          ..write('habilitado: $habilitado, ')
          ..write('podeInserir: $podeInserir, ')
          ..write('podeAlterar: $podeAlterar, ')
          ..write('podeExcluir: $podeExcluir')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(
      id,
      idPessoa,
      pessoaNome,
      idColaborador,
      idUsuario,
      administrador,
      idPapel,
      papelNome,
      papelDescricao,
      idFuncao,
      funcaoNome,
      funcaoDescricao,
      idPapelFuncao,
      habilitado,
      podeInserir,
      podeAlterar,
      podeExcluir);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is ViewControleAcesso &&
          other.id == this.id &&
          other.idPessoa == this.idPessoa &&
          other.pessoaNome == this.pessoaNome &&
          other.idColaborador == this.idColaborador &&
          other.idUsuario == this.idUsuario &&
          other.administrador == this.administrador &&
          other.idPapel == this.idPapel &&
          other.papelNome == this.papelNome &&
          other.papelDescricao == this.papelDescricao &&
          other.idFuncao == this.idFuncao &&
          other.funcaoNome == this.funcaoNome &&
          other.funcaoDescricao == this.funcaoDescricao &&
          other.idPapelFuncao == this.idPapelFuncao &&
          other.habilitado == this.habilitado &&
          other.podeInserir == this.podeInserir &&
          other.podeAlterar == this.podeAlterar &&
          other.podeExcluir == this.podeExcluir);
}

class ViewControleAcessosCompanion extends UpdateCompanion<ViewControleAcesso> {
  final Value<int?> id;
  final Value<int?> idPessoa;
  final Value<String?> pessoaNome;
  final Value<int?> idColaborador;
  final Value<int?> idUsuario;
  final Value<String?> administrador;
  final Value<int?> idPapel;
  final Value<String?> papelNome;
  final Value<String?> papelDescricao;
  final Value<int?> idFuncao;
  final Value<String?> funcaoNome;
  final Value<String?> funcaoDescricao;
  final Value<int?> idPapelFuncao;
  final Value<String?> habilitado;
  final Value<String?> podeInserir;
  final Value<String?> podeAlterar;
  final Value<String?> podeExcluir;
  const ViewControleAcessosCompanion({
    this.id = const Value.absent(),
    this.idPessoa = const Value.absent(),
    this.pessoaNome = const Value.absent(),
    this.idColaborador = const Value.absent(),
    this.idUsuario = const Value.absent(),
    this.administrador = const Value.absent(),
    this.idPapel = const Value.absent(),
    this.papelNome = const Value.absent(),
    this.papelDescricao = const Value.absent(),
    this.idFuncao = const Value.absent(),
    this.funcaoNome = const Value.absent(),
    this.funcaoDescricao = const Value.absent(),
    this.idPapelFuncao = const Value.absent(),
    this.habilitado = const Value.absent(),
    this.podeInserir = const Value.absent(),
    this.podeAlterar = const Value.absent(),
    this.podeExcluir = const Value.absent(),
  });
  ViewControleAcessosCompanion.insert({
    this.id = const Value.absent(),
    this.idPessoa = const Value.absent(),
    this.pessoaNome = const Value.absent(),
    this.idColaborador = const Value.absent(),
    this.idUsuario = const Value.absent(),
    this.administrador = const Value.absent(),
    this.idPapel = const Value.absent(),
    this.papelNome = const Value.absent(),
    this.papelDescricao = const Value.absent(),
    this.idFuncao = const Value.absent(),
    this.funcaoNome = const Value.absent(),
    this.funcaoDescricao = const Value.absent(),
    this.idPapelFuncao = const Value.absent(),
    this.habilitado = const Value.absent(),
    this.podeInserir = const Value.absent(),
    this.podeAlterar = const Value.absent(),
    this.podeExcluir = const Value.absent(),
  });
  static Insertable<ViewControleAcesso> custom({
    Expression<int>? id,
    Expression<int>? idPessoa,
    Expression<String>? pessoaNome,
    Expression<int>? idColaborador,
    Expression<int>? idUsuario,
    Expression<String>? administrador,
    Expression<int>? idPapel,
    Expression<String>? papelNome,
    Expression<String>? papelDescricao,
    Expression<int>? idFuncao,
    Expression<String>? funcaoNome,
    Expression<String>? funcaoDescricao,
    Expression<int>? idPapelFuncao,
    Expression<String>? habilitado,
    Expression<String>? podeInserir,
    Expression<String>? podeAlterar,
    Expression<String>? podeExcluir,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (idPessoa != null) 'id_pessoa': idPessoa,
      if (pessoaNome != null) 'pessoa_nome': pessoaNome,
      if (idColaborador != null) 'id_colaborador': idColaborador,
      if (idUsuario != null) 'id_usuario': idUsuario,
      if (administrador != null) 'administrador': administrador,
      if (idPapel != null) 'id_papel': idPapel,
      if (papelNome != null) 'papel_nome': papelNome,
      if (papelDescricao != null) 'papel_descricao': papelDescricao,
      if (idFuncao != null) 'id_funcao': idFuncao,
      if (funcaoNome != null) 'funcao_nome': funcaoNome,
      if (funcaoDescricao != null) 'funcao_descricao': funcaoDescricao,
      if (idPapelFuncao != null) 'id_papel_funcao': idPapelFuncao,
      if (habilitado != null) 'habilitado': habilitado,
      if (podeInserir != null) 'pode_inserir': podeInserir,
      if (podeAlterar != null) 'pode_alterar': podeAlterar,
      if (podeExcluir != null) 'pode_excluir': podeExcluir,
    });
  }

  ViewControleAcessosCompanion copyWith(
      {Value<int?>? id,
      Value<int?>? idPessoa,
      Value<String?>? pessoaNome,
      Value<int?>? idColaborador,
      Value<int?>? idUsuario,
      Value<String?>? administrador,
      Value<int?>? idPapel,
      Value<String?>? papelNome,
      Value<String?>? papelDescricao,
      Value<int?>? idFuncao,
      Value<String?>? funcaoNome,
      Value<String?>? funcaoDescricao,
      Value<int?>? idPapelFuncao,
      Value<String?>? habilitado,
      Value<String?>? podeInserir,
      Value<String?>? podeAlterar,
      Value<String?>? podeExcluir}) {
    return ViewControleAcessosCompanion(
      id: id ?? this.id,
      idPessoa: idPessoa ?? this.idPessoa,
      pessoaNome: pessoaNome ?? this.pessoaNome,
      idColaborador: idColaborador ?? this.idColaborador,
      idUsuario: idUsuario ?? this.idUsuario,
      administrador: administrador ?? this.administrador,
      idPapel: idPapel ?? this.idPapel,
      papelNome: papelNome ?? this.papelNome,
      papelDescricao: papelDescricao ?? this.papelDescricao,
      idFuncao: idFuncao ?? this.idFuncao,
      funcaoNome: funcaoNome ?? this.funcaoNome,
      funcaoDescricao: funcaoDescricao ?? this.funcaoDescricao,
      idPapelFuncao: idPapelFuncao ?? this.idPapelFuncao,
      habilitado: habilitado ?? this.habilitado,
      podeInserir: podeInserir ?? this.podeInserir,
      podeAlterar: podeAlterar ?? this.podeAlterar,
      podeExcluir: podeExcluir ?? this.podeExcluir,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (idPessoa.present) {
      map['id_pessoa'] = Variable<int>(idPessoa.value);
    }
    if (pessoaNome.present) {
      map['pessoa_nome'] = Variable<String>(pessoaNome.value);
    }
    if (idColaborador.present) {
      map['id_colaborador'] = Variable<int>(idColaborador.value);
    }
    if (idUsuario.present) {
      map['id_usuario'] = Variable<int>(idUsuario.value);
    }
    if (administrador.present) {
      map['administrador'] = Variable<String>(administrador.value);
    }
    if (idPapel.present) {
      map['id_papel'] = Variable<int>(idPapel.value);
    }
    if (papelNome.present) {
      map['papel_nome'] = Variable<String>(papelNome.value);
    }
    if (papelDescricao.present) {
      map['papel_descricao'] = Variable<String>(papelDescricao.value);
    }
    if (idFuncao.present) {
      map['id_funcao'] = Variable<int>(idFuncao.value);
    }
    if (funcaoNome.present) {
      map['funcao_nome'] = Variable<String>(funcaoNome.value);
    }
    if (funcaoDescricao.present) {
      map['funcao_descricao'] = Variable<String>(funcaoDescricao.value);
    }
    if (idPapelFuncao.present) {
      map['id_papel_funcao'] = Variable<int>(idPapelFuncao.value);
    }
    if (habilitado.present) {
      map['habilitado'] = Variable<String>(habilitado.value);
    }
    if (podeInserir.present) {
      map['pode_inserir'] = Variable<String>(podeInserir.value);
    }
    if (podeAlterar.present) {
      map['pode_alterar'] = Variable<String>(podeAlterar.value);
    }
    if (podeExcluir.present) {
      map['pode_excluir'] = Variable<String>(podeExcluir.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('ViewControleAcessosCompanion(')
          ..write('id: $id, ')
          ..write('idPessoa: $idPessoa, ')
          ..write('pessoaNome: $pessoaNome, ')
          ..write('idColaborador: $idColaborador, ')
          ..write('idUsuario: $idUsuario, ')
          ..write('administrador: $administrador, ')
          ..write('idPapel: $idPapel, ')
          ..write('papelNome: $papelNome, ')
          ..write('papelDescricao: $papelDescricao, ')
          ..write('idFuncao: $idFuncao, ')
          ..write('funcaoNome: $funcaoNome, ')
          ..write('funcaoDescricao: $funcaoDescricao, ')
          ..write('idPapelFuncao: $idPapelFuncao, ')
          ..write('habilitado: $habilitado, ')
          ..write('podeInserir: $podeInserir, ')
          ..write('podeAlterar: $podeAlterar, ')
          ..write('podeExcluir: $podeExcluir')
          ..write(')'))
        .toString();
  }
}

class $ViewPessoaUsuariosTable extends ViewPessoaUsuarios
    with TableInfo<$ViewPessoaUsuariosTable, ViewPessoaUsuario> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $ViewPessoaUsuariosTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
      'id', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _idPessoaMeta =
      const VerificationMeta('idPessoa');
  @override
  late final GeneratedColumn<int> idPessoa = GeneratedColumn<int>(
      'id_pessoa', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _pessoaNomeMeta =
      const VerificationMeta('pessoaNome');
  @override
  late final GeneratedColumn<String> pessoaNome = GeneratedColumn<String>(
      'pessoa_nome', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 450),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _tipoMeta = const VerificationMeta('tipo');
  @override
  late final GeneratedColumn<String> tipo = GeneratedColumn<String>(
      'tipo', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 3),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _emailMeta = const VerificationMeta('email');
  @override
  late final GeneratedColumn<String> email = GeneratedColumn<String>(
      'email', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 750),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _idColaboradorMeta =
      const VerificationMeta('idColaborador');
  @override
  late final GeneratedColumn<int> idColaborador = GeneratedColumn<int>(
      'id_colaborador', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _idUsuarioMeta =
      const VerificationMeta('idUsuario');
  @override
  late final GeneratedColumn<int> idUsuario = GeneratedColumn<int>(
      'id_usuario', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _loginMeta = const VerificationMeta('login');
  @override
  late final GeneratedColumn<String> login = GeneratedColumn<String>(
      'login', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 150),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _senhaMeta = const VerificationMeta('senha');
  @override
  late final GeneratedColumn<String> senha = GeneratedColumn<String>(
      'senha', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 150),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _dataCadastroMeta =
      const VerificationMeta('dataCadastro');
  @override
  late final GeneratedColumn<DateTime> dataCadastro = GeneratedColumn<DateTime>(
      'data_cadastro', aliasedName, true,
      type: DriftSqlType.dateTime, requiredDuringInsert: false);
  static const VerificationMeta _administradorMeta =
      const VerificationMeta('administrador');
  @override
  late final GeneratedColumn<String> administrador = GeneratedColumn<String>(
      'administrador', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 3),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  @override
  List<GeneratedColumn> get $columns => [
        id,
        idPessoa,
        pessoaNome,
        tipo,
        email,
        idColaborador,
        idUsuario,
        login,
        senha,
        dataCadastro,
        administrador
      ];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'view_pessoa_usuario';
  @override
  VerificationContext validateIntegrity(Insertable<ViewPessoaUsuario> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('id_pessoa')) {
      context.handle(_idPessoaMeta,
          idPessoa.isAcceptableOrUnknown(data['id_pessoa']!, _idPessoaMeta));
    }
    if (data.containsKey('pessoa_nome')) {
      context.handle(
          _pessoaNomeMeta,
          pessoaNome.isAcceptableOrUnknown(
              data['pessoa_nome']!, _pessoaNomeMeta));
    }
    if (data.containsKey('tipo')) {
      context.handle(
          _tipoMeta, tipo.isAcceptableOrUnknown(data['tipo']!, _tipoMeta));
    }
    if (data.containsKey('email')) {
      context.handle(
          _emailMeta, email.isAcceptableOrUnknown(data['email']!, _emailMeta));
    }
    if (data.containsKey('id_colaborador')) {
      context.handle(
          _idColaboradorMeta,
          idColaborador.isAcceptableOrUnknown(
              data['id_colaborador']!, _idColaboradorMeta));
    }
    if (data.containsKey('id_usuario')) {
      context.handle(_idUsuarioMeta,
          idUsuario.isAcceptableOrUnknown(data['id_usuario']!, _idUsuarioMeta));
    }
    if (data.containsKey('login')) {
      context.handle(
          _loginMeta, login.isAcceptableOrUnknown(data['login']!, _loginMeta));
    }
    if (data.containsKey('senha')) {
      context.handle(
          _senhaMeta, senha.isAcceptableOrUnknown(data['senha']!, _senhaMeta));
    }
    if (data.containsKey('data_cadastro')) {
      context.handle(
          _dataCadastroMeta,
          dataCadastro.isAcceptableOrUnknown(
              data['data_cadastro']!, _dataCadastroMeta));
    }
    if (data.containsKey('administrador')) {
      context.handle(
          _administradorMeta,
          administrador.isAcceptableOrUnknown(
              data['administrador']!, _administradorMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  ViewPessoaUsuario map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return ViewPessoaUsuario(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id']),
      idPessoa: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id_pessoa']),
      pessoaNome: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}pessoa_nome']),
      tipo: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}tipo']),
      email: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}email']),
      idColaborador: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id_colaborador']),
      idUsuario: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id_usuario']),
      login: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}login']),
      senha: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}senha']),
      dataCadastro: attachedDatabase.typeMapping
          .read(DriftSqlType.dateTime, data['${effectivePrefix}data_cadastro']),
      administrador: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}administrador']),
    );
  }

  @override
  $ViewPessoaUsuariosTable createAlias(String alias) {
    return $ViewPessoaUsuariosTable(attachedDatabase, alias);
  }
}

class ViewPessoaUsuario extends DataClass
    implements Insertable<ViewPessoaUsuario> {
  final int? id;
  final int? idPessoa;
  final String? pessoaNome;
  final String? tipo;
  final String? email;
  final int? idColaborador;
  final int? idUsuario;
  final String? login;
  final String? senha;
  final DateTime? dataCadastro;
  final String? administrador;
  const ViewPessoaUsuario(
      {this.id,
      this.idPessoa,
      this.pessoaNome,
      this.tipo,
      this.email,
      this.idColaborador,
      this.idUsuario,
      this.login,
      this.senha,
      this.dataCadastro,
      this.administrador});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || idPessoa != null) {
      map['id_pessoa'] = Variable<int>(idPessoa);
    }
    if (!nullToAbsent || pessoaNome != null) {
      map['pessoa_nome'] = Variable<String>(pessoaNome);
    }
    if (!nullToAbsent || tipo != null) {
      map['tipo'] = Variable<String>(tipo);
    }
    if (!nullToAbsent || email != null) {
      map['email'] = Variable<String>(email);
    }
    if (!nullToAbsent || idColaborador != null) {
      map['id_colaborador'] = Variable<int>(idColaborador);
    }
    if (!nullToAbsent || idUsuario != null) {
      map['id_usuario'] = Variable<int>(idUsuario);
    }
    if (!nullToAbsent || login != null) {
      map['login'] = Variable<String>(login);
    }
    if (!nullToAbsent || senha != null) {
      map['senha'] = Variable<String>(senha);
    }
    if (!nullToAbsent || dataCadastro != null) {
      map['data_cadastro'] = Variable<DateTime>(dataCadastro);
    }
    if (!nullToAbsent || administrador != null) {
      map['administrador'] = Variable<String>(administrador);
    }
    return map;
  }

  factory ViewPessoaUsuario.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return ViewPessoaUsuario(
      id: serializer.fromJson<int?>(json['id']),
      idPessoa: serializer.fromJson<int?>(json['idPessoa']),
      pessoaNome: serializer.fromJson<String?>(json['pessoaNome']),
      tipo: serializer.fromJson<String?>(json['tipo']),
      email: serializer.fromJson<String?>(json['email']),
      idColaborador: serializer.fromJson<int?>(json['idColaborador']),
      idUsuario: serializer.fromJson<int?>(json['idUsuario']),
      login: serializer.fromJson<String?>(json['login']),
      senha: serializer.fromJson<String?>(json['senha']),
      dataCadastro: serializer.fromJson<DateTime?>(json['dataCadastro']),
      administrador: serializer.fromJson<String?>(json['administrador']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'idPessoa': serializer.toJson<int?>(idPessoa),
      'pessoaNome': serializer.toJson<String?>(pessoaNome),
      'tipo': serializer.toJson<String?>(tipo),
      'email': serializer.toJson<String?>(email),
      'idColaborador': serializer.toJson<int?>(idColaborador),
      'idUsuario': serializer.toJson<int?>(idUsuario),
      'login': serializer.toJson<String?>(login),
      'senha': serializer.toJson<String?>(senha),
      'dataCadastro': serializer.toJson<DateTime?>(dataCadastro),
      'administrador': serializer.toJson<String?>(administrador),
    };
  }

  ViewPessoaUsuario copyWith(
          {Value<int?> id = const Value.absent(),
          Value<int?> idPessoa = const Value.absent(),
          Value<String?> pessoaNome = const Value.absent(),
          Value<String?> tipo = const Value.absent(),
          Value<String?> email = const Value.absent(),
          Value<int?> idColaborador = const Value.absent(),
          Value<int?> idUsuario = const Value.absent(),
          Value<String?> login = const Value.absent(),
          Value<String?> senha = const Value.absent(),
          Value<DateTime?> dataCadastro = const Value.absent(),
          Value<String?> administrador = const Value.absent()}) =>
      ViewPessoaUsuario(
        id: id.present ? id.value : this.id,
        idPessoa: idPessoa.present ? idPessoa.value : this.idPessoa,
        pessoaNome: pessoaNome.present ? pessoaNome.value : this.pessoaNome,
        tipo: tipo.present ? tipo.value : this.tipo,
        email: email.present ? email.value : this.email,
        idColaborador:
            idColaborador.present ? idColaborador.value : this.idColaborador,
        idUsuario: idUsuario.present ? idUsuario.value : this.idUsuario,
        login: login.present ? login.value : this.login,
        senha: senha.present ? senha.value : this.senha,
        dataCadastro:
            dataCadastro.present ? dataCadastro.value : this.dataCadastro,
        administrador:
            administrador.present ? administrador.value : this.administrador,
      );
  ViewPessoaUsuario copyWithCompanion(ViewPessoaUsuariosCompanion data) {
    return ViewPessoaUsuario(
      id: data.id.present ? data.id.value : this.id,
      idPessoa: data.idPessoa.present ? data.idPessoa.value : this.idPessoa,
      pessoaNome:
          data.pessoaNome.present ? data.pessoaNome.value : this.pessoaNome,
      tipo: data.tipo.present ? data.tipo.value : this.tipo,
      email: data.email.present ? data.email.value : this.email,
      idColaborador: data.idColaborador.present
          ? data.idColaborador.value
          : this.idColaborador,
      idUsuario: data.idUsuario.present ? data.idUsuario.value : this.idUsuario,
      login: data.login.present ? data.login.value : this.login,
      senha: data.senha.present ? data.senha.value : this.senha,
      dataCadastro: data.dataCadastro.present
          ? data.dataCadastro.value
          : this.dataCadastro,
      administrador: data.administrador.present
          ? data.administrador.value
          : this.administrador,
    );
  }

  @override
  String toString() {
    return (StringBuffer('ViewPessoaUsuario(')
          ..write('id: $id, ')
          ..write('idPessoa: $idPessoa, ')
          ..write('pessoaNome: $pessoaNome, ')
          ..write('tipo: $tipo, ')
          ..write('email: $email, ')
          ..write('idColaborador: $idColaborador, ')
          ..write('idUsuario: $idUsuario, ')
          ..write('login: $login, ')
          ..write('senha: $senha, ')
          ..write('dataCadastro: $dataCadastro, ')
          ..write('administrador: $administrador')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(id, idPessoa, pessoaNome, tipo, email,
      idColaborador, idUsuario, login, senha, dataCadastro, administrador);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is ViewPessoaUsuario &&
          other.id == this.id &&
          other.idPessoa == this.idPessoa &&
          other.pessoaNome == this.pessoaNome &&
          other.tipo == this.tipo &&
          other.email == this.email &&
          other.idColaborador == this.idColaborador &&
          other.idUsuario == this.idUsuario &&
          other.login == this.login &&
          other.senha == this.senha &&
          other.dataCadastro == this.dataCadastro &&
          other.administrador == this.administrador);
}

class ViewPessoaUsuariosCompanion extends UpdateCompanion<ViewPessoaUsuario> {
  final Value<int?> id;
  final Value<int?> idPessoa;
  final Value<String?> pessoaNome;
  final Value<String?> tipo;
  final Value<String?> email;
  final Value<int?> idColaborador;
  final Value<int?> idUsuario;
  final Value<String?> login;
  final Value<String?> senha;
  final Value<DateTime?> dataCadastro;
  final Value<String?> administrador;
  const ViewPessoaUsuariosCompanion({
    this.id = const Value.absent(),
    this.idPessoa = const Value.absent(),
    this.pessoaNome = const Value.absent(),
    this.tipo = const Value.absent(),
    this.email = const Value.absent(),
    this.idColaborador = const Value.absent(),
    this.idUsuario = const Value.absent(),
    this.login = const Value.absent(),
    this.senha = const Value.absent(),
    this.dataCadastro = const Value.absent(),
    this.administrador = const Value.absent(),
  });
  ViewPessoaUsuariosCompanion.insert({
    this.id = const Value.absent(),
    this.idPessoa = const Value.absent(),
    this.pessoaNome = const Value.absent(),
    this.tipo = const Value.absent(),
    this.email = const Value.absent(),
    this.idColaborador = const Value.absent(),
    this.idUsuario = const Value.absent(),
    this.login = const Value.absent(),
    this.senha = const Value.absent(),
    this.dataCadastro = const Value.absent(),
    this.administrador = const Value.absent(),
  });
  static Insertable<ViewPessoaUsuario> custom({
    Expression<int>? id,
    Expression<int>? idPessoa,
    Expression<String>? pessoaNome,
    Expression<String>? tipo,
    Expression<String>? email,
    Expression<int>? idColaborador,
    Expression<int>? idUsuario,
    Expression<String>? login,
    Expression<String>? senha,
    Expression<DateTime>? dataCadastro,
    Expression<String>? administrador,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (idPessoa != null) 'id_pessoa': idPessoa,
      if (pessoaNome != null) 'pessoa_nome': pessoaNome,
      if (tipo != null) 'tipo': tipo,
      if (email != null) 'email': email,
      if (idColaborador != null) 'id_colaborador': idColaborador,
      if (idUsuario != null) 'id_usuario': idUsuario,
      if (login != null) 'login': login,
      if (senha != null) 'senha': senha,
      if (dataCadastro != null) 'data_cadastro': dataCadastro,
      if (administrador != null) 'administrador': administrador,
    });
  }

  ViewPessoaUsuariosCompanion copyWith(
      {Value<int?>? id,
      Value<int?>? idPessoa,
      Value<String?>? pessoaNome,
      Value<String?>? tipo,
      Value<String?>? email,
      Value<int?>? idColaborador,
      Value<int?>? idUsuario,
      Value<String?>? login,
      Value<String?>? senha,
      Value<DateTime?>? dataCadastro,
      Value<String?>? administrador}) {
    return ViewPessoaUsuariosCompanion(
      id: id ?? this.id,
      idPessoa: idPessoa ?? this.idPessoa,
      pessoaNome: pessoaNome ?? this.pessoaNome,
      tipo: tipo ?? this.tipo,
      email: email ?? this.email,
      idColaborador: idColaborador ?? this.idColaborador,
      idUsuario: idUsuario ?? this.idUsuario,
      login: login ?? this.login,
      senha: senha ?? this.senha,
      dataCadastro: dataCadastro ?? this.dataCadastro,
      administrador: administrador ?? this.administrador,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (idPessoa.present) {
      map['id_pessoa'] = Variable<int>(idPessoa.value);
    }
    if (pessoaNome.present) {
      map['pessoa_nome'] = Variable<String>(pessoaNome.value);
    }
    if (tipo.present) {
      map['tipo'] = Variable<String>(tipo.value);
    }
    if (email.present) {
      map['email'] = Variable<String>(email.value);
    }
    if (idColaborador.present) {
      map['id_colaborador'] = Variable<int>(idColaborador.value);
    }
    if (idUsuario.present) {
      map['id_usuario'] = Variable<int>(idUsuario.value);
    }
    if (login.present) {
      map['login'] = Variable<String>(login.value);
    }
    if (senha.present) {
      map['senha'] = Variable<String>(senha.value);
    }
    if (dataCadastro.present) {
      map['data_cadastro'] = Variable<DateTime>(dataCadastro.value);
    }
    if (administrador.present) {
      map['administrador'] = Variable<String>(administrador.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('ViewPessoaUsuariosCompanion(')
          ..write('id: $id, ')
          ..write('idPessoa: $idPessoa, ')
          ..write('pessoaNome: $pessoaNome, ')
          ..write('tipo: $tipo, ')
          ..write('email: $email, ')
          ..write('idColaborador: $idColaborador, ')
          ..write('idUsuario: $idUsuario, ')
          ..write('login: $login, ')
          ..write('senha: $senha, ')
          ..write('dataCadastro: $dataCadastro, ')
          ..write('administrador: $administrador')
          ..write(')'))
        .toString();
  }
}

class $PlanoCentroResultadosTable extends PlanoCentroResultados
    with TableInfo<$PlanoCentroResultadosTable, PlanoCentroResultado> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $PlanoCentroResultadosTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
      'id', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _nomeMeta = const VerificationMeta('nome');
  @override
  late final GeneratedColumn<String> nome = GeneratedColumn<String>(
      'nome', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 100),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _mascaraMeta =
      const VerificationMeta('mascara');
  @override
  late final GeneratedColumn<String> mascara = GeneratedColumn<String>(
      'mascara', aliasedName, true,
      additionalChecks:
          GeneratedColumn.checkTextLength(minTextLength: 0, maxTextLength: 50),
      type: DriftSqlType.string,
      requiredDuringInsert: false);
  static const VerificationMeta _niveisMeta = const VerificationMeta('niveis');
  @override
  late final GeneratedColumn<int> niveis = GeneratedColumn<int>(
      'niveis', aliasedName, true,
      type: DriftSqlType.int, requiredDuringInsert: false);
  static const VerificationMeta _dataInclusaoMeta =
      const VerificationMeta('dataInclusao');
  @override
  late final GeneratedColumn<DateTime> dataInclusao = GeneratedColumn<DateTime>(
      'data_inclusao', aliasedName, true,
      type: DriftSqlType.dateTime, requiredDuringInsert: false);
  @override
  List<GeneratedColumn> get $columns =>
      [id, nome, mascara, niveis, dataInclusao];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'plano_centro_resultado';
  @override
  VerificationContext validateIntegrity(
      Insertable<PlanoCentroResultado> instance,
      {bool isInserting = false}) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('nome')) {
      context.handle(
          _nomeMeta, nome.isAcceptableOrUnknown(data['nome']!, _nomeMeta));
    }
    if (data.containsKey('mascara')) {
      context.handle(_mascaraMeta,
          mascara.isAcceptableOrUnknown(data['mascara']!, _mascaraMeta));
    }
    if (data.containsKey('niveis')) {
      context.handle(_niveisMeta,
          niveis.isAcceptableOrUnknown(data['niveis']!, _niveisMeta));
    }
    if (data.containsKey('data_inclusao')) {
      context.handle(
          _dataInclusaoMeta,
          dataInclusao.isAcceptableOrUnknown(
              data['data_inclusao']!, _dataInclusaoMeta));
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  PlanoCentroResultado map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return PlanoCentroResultado(
      id: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}id']),
      nome: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}nome']),
      mascara: attachedDatabase.typeMapping
          .read(DriftSqlType.string, data['${effectivePrefix}mascara']),
      niveis: attachedDatabase.typeMapping
          .read(DriftSqlType.int, data['${effectivePrefix}niveis']),
      dataInclusao: attachedDatabase.typeMapping
          .read(DriftSqlType.dateTime, data['${effectivePrefix}data_inclusao']),
    );
  }

  @override
  $PlanoCentroResultadosTable createAlias(String alias) {
    return $PlanoCentroResultadosTable(attachedDatabase, alias);
  }
}

class PlanoCentroResultado extends DataClass
    implements Insertable<PlanoCentroResultado> {
  final int? id;
  final String? nome;
  final String? mascara;
  final int? niveis;
  final DateTime? dataInclusao;
  const PlanoCentroResultado(
      {this.id, this.nome, this.mascara, this.niveis, this.dataInclusao});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || nome != null) {
      map['nome'] = Variable<String>(nome);
    }
    if (!nullToAbsent || mascara != null) {
      map['mascara'] = Variable<String>(mascara);
    }
    if (!nullToAbsent || niveis != null) {
      map['niveis'] = Variable<int>(niveis);
    }
    if (!nullToAbsent || dataInclusao != null) {
      map['data_inclusao'] = Variable<DateTime>(dataInclusao);
    }
    return map;
  }

  factory PlanoCentroResultado.fromJson(Map<String, dynamic> json,
      {ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return PlanoCentroResultado(
      id: serializer.fromJson<int?>(json['id']),
      nome: serializer.fromJson<String?>(json['nome']),
      mascara: serializer.fromJson<String?>(json['mascara']),
      niveis: serializer.fromJson<int?>(json['niveis']),
      dataInclusao: serializer.fromJson<DateTime?>(json['dataInclusao']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'nome': serializer.toJson<String?>(nome),
      'mascara': serializer.toJson<String?>(mascara),
      'niveis': serializer.toJson<int?>(niveis),
      'dataInclusao': serializer.toJson<DateTime?>(dataInclusao),
    };
  }

  PlanoCentroResultado copyWith(
          {Value<int?> id = const Value.absent(),
          Value<String?> nome = const Value.absent(),
          Value<String?> mascara = const Value.absent(),
          Value<int?> niveis = const Value.absent(),
          Value<DateTime?> dataInclusao = const Value.absent()}) =>
      PlanoCentroResultado(
        id: id.present ? id.value : this.id,
        nome: nome.present ? nome.value : this.nome,
        mascara: mascara.present ? mascara.value : this.mascara,
        niveis: niveis.present ? niveis.value : this.niveis,
        dataInclusao:
            dataInclusao.present ? dataInclusao.value : this.dataInclusao,
      );
  PlanoCentroResultado copyWithCompanion(PlanoCentroResultadosCompanion data) {
    return PlanoCentroResultado(
      id: data.id.present ? data.id.value : this.id,
      nome: data.nome.present ? data.nome.value : this.nome,
      mascara: data.mascara.present ? data.mascara.value : this.mascara,
      niveis: data.niveis.present ? data.niveis.value : this.niveis,
      dataInclusao: data.dataInclusao.present
          ? data.dataInclusao.value
          : this.dataInclusao,
    );
  }

  @override
  String toString() {
    return (StringBuffer('PlanoCentroResultado(')
          ..write('id: $id, ')
          ..write('nome: $nome, ')
          ..write('mascara: $mascara, ')
          ..write('niveis: $niveis, ')
          ..write('dataInclusao: $dataInclusao')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(id, nome, mascara, niveis, dataInclusao);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is PlanoCentroResultado &&
          other.id == this.id &&
          other.nome == this.nome &&
          other.mascara == this.mascara &&
          other.niveis == this.niveis &&
          other.dataInclusao == this.dataInclusao);
}

class PlanoCentroResultadosCompanion
    extends UpdateCompanion<PlanoCentroResultado> {
  final Value<int?> id;
  final Value<String?> nome;
  final Value<String?> mascara;
  final Value<int?> niveis;
  final Value<DateTime?> dataInclusao;
  const PlanoCentroResultadosCompanion({
    this.id = const Value.absent(),
    this.nome = const Value.absent(),
    this.mascara = const Value.absent(),
    this.niveis = const Value.absent(),
    this.dataInclusao = const Value.absent(),
  });
  PlanoCentroResultadosCompanion.insert({
    this.id = const Value.absent(),
    this.nome = const Value.absent(),
    this.mascara = const Value.absent(),
    this.niveis = const Value.absent(),
    this.dataInclusao = const Value.absent(),
  });
  static Insertable<PlanoCentroResultado> custom({
    Expression<int>? id,
    Expression<String>? nome,
    Expression<String>? mascara,
    Expression<int>? niveis,
    Expression<DateTime>? dataInclusao,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (nome != null) 'nome': nome,
      if (mascara != null) 'mascara': mascara,
      if (niveis != null) 'niveis': niveis,
      if (dataInclusao != null) 'data_inclusao': dataInclusao,
    });
  }

  PlanoCentroResultadosCompanion copyWith(
      {Value<int?>? id,
      Value<String?>? nome,
      Value<String?>? mascara,
      Value<int?>? niveis,
      Value<DateTime?>? dataInclusao}) {
    return PlanoCentroResultadosCompanion(
      id: id ?? this.id,
      nome: nome ?? this.nome,
      mascara: mascara ?? this.mascara,
      niveis: niveis ?? this.niveis,
      dataInclusao: dataInclusao ?? this.dataInclusao,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (nome.present) {
      map['nome'] = Variable<String>(nome.value);
    }
    if (mascara.present) {
      map['mascara'] = Variable<String>(mascara.value);
    }
    if (niveis.present) {
      map['niveis'] = Variable<int>(niveis.value);
    }
    if (dataInclusao.present) {
      map['data_inclusao'] = Variable<DateTime>(dataInclusao.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('PlanoCentroResultadosCompanion(')
          ..write('id: $id, ')
          ..write('nome: $nome, ')
          ..write('mascara: $mascara, ')
          ..write('niveis: $niveis, ')
          ..write('dataInclusao: $dataInclusao')
          ..write(')'))
        .toString();
  }
}

abstract class _$AppDatabase extends GeneratedDatabase {
  _$AppDatabase(QueryExecutor e) : super(e);
  $AppDatabaseManager get managers => $AppDatabaseManager(this);
  late final $ContabilLancamentoDetalhesTable contabilLancamentoDetalhes =
      $ContabilLancamentoDetalhesTable(this);
  late final $ContabilDreDetalhesTable contabilDreDetalhes =
      $ContabilDreDetalhesTable(this);
  late final $ContabilTermosTable contabilTermos = $ContabilTermosTable(this);
  late final $ContabilEncerramentoExeDetsTable contabilEncerramentoExeDets =
      $ContabilEncerramentoExeDetsTable(this);
  late final $RateioCentroResultadoDetsTable rateioCentroResultadoDets =
      $RateioCentroResultadoDetsTable(this);
  late final $ContabilIndiceValorsTable contabilIndiceValors =
      $ContabilIndiceValorsTable(this);
  late final $CtResultadoNtFinanceirasTable ctResultadoNtFinanceiras =
      $CtResultadoNtFinanceirasTable(this);
  late final $ContabilLancamentoCabecalhosTable contabilLancamentoCabecalhos =
      $ContabilLancamentoCabecalhosTable(this);
  late final $ContabilDreCabecalhosTable contabilDreCabecalhos =
      $ContabilDreCabecalhosTable(this);
  late final $ContabilLivrosTable contabilLivros = $ContabilLivrosTable(this);
  late final $ContabilEncerramentoExeCabsTable contabilEncerramentoExeCabs =
      $ContabilEncerramentoExeCabsTable(this);
  late final $CentroResultadosTable centroResultados =
      $CentroResultadosTable(this);
  late final $RateioCentroResultadoCabsTable rateioCentroResultadoCabs =
      $RateioCentroResultadoCabsTable(this);
  late final $ContabilIndicesTable contabilIndices =
      $ContabilIndicesTable(this);
  late final $FinNaturezaFinanceirasTable finNaturezaFinanceiras =
      $FinNaturezaFinanceirasTable(this);
  late final $AidfAimdfsTable aidfAimdfs = $AidfAimdfsTable(this);
  late final $FapsTable faps = $FapsTable(this);
  late final $RegistroCartoriosTable registroCartorios =
      $RegistroCartoriosTable(this);
  late final $ContabilParametrosTable contabilParametros =
      $ContabilParametrosTable(this);
  late final $PlanoContaRefSpedsTable planoContaRefSpeds =
      $PlanoContaRefSpedsTable(this);
  late final $PlanoContasTable planoContas = $PlanoContasTable(this);
  late final $ContabilContasTable contabilContas = $ContabilContasTable(this);
  late final $ContabilHistoricosTable contabilHistoricos =
      $ContabilHistoricosTable(this);
  late final $ContabilLancamentoPadraosTable contabilLancamentoPadraos =
      $ContabilLancamentoPadraosTable(this);
  late final $ContabilLotesTable contabilLotes = $ContabilLotesTable(this);
  late final $ContabilLancamentoOrcadosTable contabilLancamentoOrcados =
      $ContabilLancamentoOrcadosTable(this);
  late final $LancaCentroResultadosTable lancaCentroResultados =
      $LancaCentroResultadosTable(this);
  late final $EncerraCentroResultadosTable encerraCentroResultados =
      $EncerraCentroResultadosTable(this);
  late final $ContabilContaRateiosTable contabilContaRateios =
      $ContabilContaRateiosTable(this);
  late final $ContabilFechamentosTable contabilFechamentos =
      $ContabilFechamentosTable(this);
  late final $ViewControleAcessosTable viewControleAcessos =
      $ViewControleAcessosTable(this);
  late final $ViewPessoaUsuariosTable viewPessoaUsuarios =
      $ViewPessoaUsuariosTable(this);
  late final $PlanoCentroResultadosTable planoCentroResultados =
      $PlanoCentroResultadosTable(this);
  late final ContabilLancamentoCabecalhoDao contabilLancamentoCabecalhoDao =
      ContabilLancamentoCabecalhoDao(this as AppDatabase);
  late final ContabilDreCabecalhoDao contabilDreCabecalhoDao =
      ContabilDreCabecalhoDao(this as AppDatabase);
  late final ContabilLivroDao contabilLivroDao =
      ContabilLivroDao(this as AppDatabase);
  late final ContabilEncerramentoExeCabDao contabilEncerramentoExeCabDao =
      ContabilEncerramentoExeCabDao(this as AppDatabase);
  late final CentroResultadoDao centroResultadoDao =
      CentroResultadoDao(this as AppDatabase);
  late final RateioCentroResultadoCabDao rateioCentroResultadoCabDao =
      RateioCentroResultadoCabDao(this as AppDatabase);
  late final ContabilIndiceDao contabilIndiceDao =
      ContabilIndiceDao(this as AppDatabase);
  late final FinNaturezaFinanceiraDao finNaturezaFinanceiraDao =
      FinNaturezaFinanceiraDao(this as AppDatabase);
  late final AidfAimdfDao aidfAimdfDao = AidfAimdfDao(this as AppDatabase);
  late final FapDao fapDao = FapDao(this as AppDatabase);
  late final RegistroCartorioDao registroCartorioDao =
      RegistroCartorioDao(this as AppDatabase);
  late final ContabilParametroDao contabilParametroDao =
      ContabilParametroDao(this as AppDatabase);
  late final PlanoContaRefSpedDao planoContaRefSpedDao =
      PlanoContaRefSpedDao(this as AppDatabase);
  late final PlanoContaDao planoContaDao = PlanoContaDao(this as AppDatabase);
  late final ContabilContaDao contabilContaDao =
      ContabilContaDao(this as AppDatabase);
  late final ContabilHistoricoDao contabilHistoricoDao =
      ContabilHistoricoDao(this as AppDatabase);
  late final ContabilLancamentoPadraoDao contabilLancamentoPadraoDao =
      ContabilLancamentoPadraoDao(this as AppDatabase);
  late final ContabilLoteDao contabilLoteDao =
      ContabilLoteDao(this as AppDatabase);
  late final ContabilLancamentoOrcadoDao contabilLancamentoOrcadoDao =
      ContabilLancamentoOrcadoDao(this as AppDatabase);
  late final LancaCentroResultadoDao lancaCentroResultadoDao =
      LancaCentroResultadoDao(this as AppDatabase);
  late final EncerraCentroResultadoDao encerraCentroResultadoDao =
      EncerraCentroResultadoDao(this as AppDatabase);
  late final ContabilContaRateioDao contabilContaRateioDao =
      ContabilContaRateioDao(this as AppDatabase);
  late final ContabilFechamentoDao contabilFechamentoDao =
      ContabilFechamentoDao(this as AppDatabase);
  late final ViewControleAcessoDao viewControleAcessoDao =
      ViewControleAcessoDao(this as AppDatabase);
  late final ViewPessoaUsuarioDao viewPessoaUsuarioDao =
      ViewPessoaUsuarioDao(this as AppDatabase);
  late final PlanoCentroResultadoDao planoCentroResultadoDao =
      PlanoCentroResultadoDao(this as AppDatabase);
  @override
  Iterable<TableInfo<Table, Object?>> get allTables =>
      allSchemaEntities.whereType<TableInfo<Table, Object?>>();
  @override
  List<DatabaseSchemaEntity> get allSchemaEntities => [
        contabilLancamentoDetalhes,
        contabilDreDetalhes,
        contabilTermos,
        contabilEncerramentoExeDets,
        rateioCentroResultadoDets,
        contabilIndiceValors,
        ctResultadoNtFinanceiras,
        contabilLancamentoCabecalhos,
        contabilDreCabecalhos,
        contabilLivros,
        contabilEncerramentoExeCabs,
        centroResultados,
        rateioCentroResultadoCabs,
        contabilIndices,
        finNaturezaFinanceiras,
        aidfAimdfs,
        faps,
        registroCartorios,
        contabilParametros,
        planoContaRefSpeds,
        planoContas,
        contabilContas,
        contabilHistoricos,
        contabilLancamentoPadraos,
        contabilLotes,
        contabilLancamentoOrcados,
        lancaCentroResultados,
        encerraCentroResultados,
        contabilContaRateios,
        contabilFechamentos,
        viewControleAcessos,
        viewPessoaUsuarios,
        planoCentroResultados
      ];
}

typedef $$ContabilLancamentoDetalhesTableCreateCompanionBuilder
    = ContabilLancamentoDetalhesCompanion Function({
  Value<int?> id,
  Value<int?> idContabilLancamentoCab,
  Value<int?> idContabilConta,
  Value<int?> idContabilHistorico,
  Value<String?> tipo,
  Value<double?> valor,
  Value<String?> historico,
});
typedef $$ContabilLancamentoDetalhesTableUpdateCompanionBuilder
    = ContabilLancamentoDetalhesCompanion Function({
  Value<int?> id,
  Value<int?> idContabilLancamentoCab,
  Value<int?> idContabilConta,
  Value<int?> idContabilHistorico,
  Value<String?> tipo,
  Value<double?> valor,
  Value<String?> historico,
});

class $$ContabilLancamentoDetalhesTableTableManager extends RootTableManager<
    _$AppDatabase,
    $ContabilLancamentoDetalhesTable,
    ContabilLancamentoDetalhe,
    $$ContabilLancamentoDetalhesTableFilterComposer,
    $$ContabilLancamentoDetalhesTableOrderingComposer,
    $$ContabilLancamentoDetalhesTableCreateCompanionBuilder,
    $$ContabilLancamentoDetalhesTableUpdateCompanionBuilder> {
  $$ContabilLancamentoDetalhesTableTableManager(
      _$AppDatabase db, $ContabilLancamentoDetalhesTable table)
      : super(TableManagerState(
          db: db,
          table: table,
          filteringComposer: $$ContabilLancamentoDetalhesTableFilterComposer(
              ComposerState(db, table)),
          orderingComposer: $$ContabilLancamentoDetalhesTableOrderingComposer(
              ComposerState(db, table)),
          updateCompanionCallback: ({
            Value<int?> id = const Value.absent(),
            Value<int?> idContabilLancamentoCab = const Value.absent(),
            Value<int?> idContabilConta = const Value.absent(),
            Value<int?> idContabilHistorico = const Value.absent(),
            Value<String?> tipo = const Value.absent(),
            Value<double?> valor = const Value.absent(),
            Value<String?> historico = const Value.absent(),
          }) =>
              ContabilLancamentoDetalhesCompanion(
            id: id,
            idContabilLancamentoCab: idContabilLancamentoCab,
            idContabilConta: idContabilConta,
            idContabilHistorico: idContabilHistorico,
            tipo: tipo,
            valor: valor,
            historico: historico,
          ),
          createCompanionCallback: ({
            Value<int?> id = const Value.absent(),
            Value<int?> idContabilLancamentoCab = const Value.absent(),
            Value<int?> idContabilConta = const Value.absent(),
            Value<int?> idContabilHistorico = const Value.absent(),
            Value<String?> tipo = const Value.absent(),
            Value<double?> valor = const Value.absent(),
            Value<String?> historico = const Value.absent(),
          }) =>
              ContabilLancamentoDetalhesCompanion.insert(
            id: id,
            idContabilLancamentoCab: idContabilLancamentoCab,
            idContabilConta: idContabilConta,
            idContabilHistorico: idContabilHistorico,
            tipo: tipo,
            valor: valor,
            historico: historico,
          ),
        ));
}

class $$ContabilLancamentoDetalhesTableFilterComposer
    extends FilterComposer<_$AppDatabase, $ContabilLancamentoDetalhesTable> {
  $$ContabilLancamentoDetalhesTableFilterComposer(super.$state);
  ColumnFilters<int> get id => $state.composableBuilder(
      column: $state.table.id,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<int> get idContabilLancamentoCab => $state.composableBuilder(
      column: $state.table.idContabilLancamentoCab,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<int> get idContabilConta => $state.composableBuilder(
      column: $state.table.idContabilConta,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<int> get idContabilHistorico => $state.composableBuilder(
      column: $state.table.idContabilHistorico,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get tipo => $state.composableBuilder(
      column: $state.table.tipo,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<double> get valor => $state.composableBuilder(
      column: $state.table.valor,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get historico => $state.composableBuilder(
      column: $state.table.historico,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));
}

class $$ContabilLancamentoDetalhesTableOrderingComposer
    extends OrderingComposer<_$AppDatabase, $ContabilLancamentoDetalhesTable> {
  $$ContabilLancamentoDetalhesTableOrderingComposer(super.$state);
  ColumnOrderings<int> get id => $state.composableBuilder(
      column: $state.table.id,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<int> get idContabilLancamentoCab => $state.composableBuilder(
      column: $state.table.idContabilLancamentoCab,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<int> get idContabilConta => $state.composableBuilder(
      column: $state.table.idContabilConta,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<int> get idContabilHistorico => $state.composableBuilder(
      column: $state.table.idContabilHistorico,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get tipo => $state.composableBuilder(
      column: $state.table.tipo,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<double> get valor => $state.composableBuilder(
      column: $state.table.valor,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get historico => $state.composableBuilder(
      column: $state.table.historico,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));
}

typedef $$ContabilDreDetalhesTableCreateCompanionBuilder
    = ContabilDreDetalhesCompanion Function({
  Value<int?> id,
  Value<int?> idContabilDreCabecalho,
  Value<String?> classificacao,
  Value<String?> descricao,
  Value<String?> formaCalculo,
  Value<String?> sinal,
  Value<String?> natureza,
  Value<double?> valor,
});
typedef $$ContabilDreDetalhesTableUpdateCompanionBuilder
    = ContabilDreDetalhesCompanion Function({
  Value<int?> id,
  Value<int?> idContabilDreCabecalho,
  Value<String?> classificacao,
  Value<String?> descricao,
  Value<String?> formaCalculo,
  Value<String?> sinal,
  Value<String?> natureza,
  Value<double?> valor,
});

class $$ContabilDreDetalhesTableTableManager extends RootTableManager<
    _$AppDatabase,
    $ContabilDreDetalhesTable,
    ContabilDreDetalhe,
    $$ContabilDreDetalhesTableFilterComposer,
    $$ContabilDreDetalhesTableOrderingComposer,
    $$ContabilDreDetalhesTableCreateCompanionBuilder,
    $$ContabilDreDetalhesTableUpdateCompanionBuilder> {
  $$ContabilDreDetalhesTableTableManager(
      _$AppDatabase db, $ContabilDreDetalhesTable table)
      : super(TableManagerState(
          db: db,
          table: table,
          filteringComposer: $$ContabilDreDetalhesTableFilterComposer(
              ComposerState(db, table)),
          orderingComposer: $$ContabilDreDetalhesTableOrderingComposer(
              ComposerState(db, table)),
          updateCompanionCallback: ({
            Value<int?> id = const Value.absent(),
            Value<int?> idContabilDreCabecalho = const Value.absent(),
            Value<String?> classificacao = const Value.absent(),
            Value<String?> descricao = const Value.absent(),
            Value<String?> formaCalculo = const Value.absent(),
            Value<String?> sinal = const Value.absent(),
            Value<String?> natureza = const Value.absent(),
            Value<double?> valor = const Value.absent(),
          }) =>
              ContabilDreDetalhesCompanion(
            id: id,
            idContabilDreCabecalho: idContabilDreCabecalho,
            classificacao: classificacao,
            descricao: descricao,
            formaCalculo: formaCalculo,
            sinal: sinal,
            natureza: natureza,
            valor: valor,
          ),
          createCompanionCallback: ({
            Value<int?> id = const Value.absent(),
            Value<int?> idContabilDreCabecalho = const Value.absent(),
            Value<String?> classificacao = const Value.absent(),
            Value<String?> descricao = const Value.absent(),
            Value<String?> formaCalculo = const Value.absent(),
            Value<String?> sinal = const Value.absent(),
            Value<String?> natureza = const Value.absent(),
            Value<double?> valor = const Value.absent(),
          }) =>
              ContabilDreDetalhesCompanion.insert(
            id: id,
            idContabilDreCabecalho: idContabilDreCabecalho,
            classificacao: classificacao,
            descricao: descricao,
            formaCalculo: formaCalculo,
            sinal: sinal,
            natureza: natureza,
            valor: valor,
          ),
        ));
}

class $$ContabilDreDetalhesTableFilterComposer
    extends FilterComposer<_$AppDatabase, $ContabilDreDetalhesTable> {
  $$ContabilDreDetalhesTableFilterComposer(super.$state);
  ColumnFilters<int> get id => $state.composableBuilder(
      column: $state.table.id,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<int> get idContabilDreCabecalho => $state.composableBuilder(
      column: $state.table.idContabilDreCabecalho,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get classificacao => $state.composableBuilder(
      column: $state.table.classificacao,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get descricao => $state.composableBuilder(
      column: $state.table.descricao,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get formaCalculo => $state.composableBuilder(
      column: $state.table.formaCalculo,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get sinal => $state.composableBuilder(
      column: $state.table.sinal,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get natureza => $state.composableBuilder(
      column: $state.table.natureza,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<double> get valor => $state.composableBuilder(
      column: $state.table.valor,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));
}

class $$ContabilDreDetalhesTableOrderingComposer
    extends OrderingComposer<_$AppDatabase, $ContabilDreDetalhesTable> {
  $$ContabilDreDetalhesTableOrderingComposer(super.$state);
  ColumnOrderings<int> get id => $state.composableBuilder(
      column: $state.table.id,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<int> get idContabilDreCabecalho => $state.composableBuilder(
      column: $state.table.idContabilDreCabecalho,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get classificacao => $state.composableBuilder(
      column: $state.table.classificacao,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get descricao => $state.composableBuilder(
      column: $state.table.descricao,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get formaCalculo => $state.composableBuilder(
      column: $state.table.formaCalculo,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get sinal => $state.composableBuilder(
      column: $state.table.sinal,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get natureza => $state.composableBuilder(
      column: $state.table.natureza,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<double> get valor => $state.composableBuilder(
      column: $state.table.valor,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));
}

typedef $$ContabilTermosTableCreateCompanionBuilder = ContabilTermosCompanion
    Function({
  Value<int?> id,
  Value<int?> idContabilLivro,
  Value<String?> aberturaEncerramento,
  Value<int?> numero,
  Value<int?> paginaInicial,
  Value<int?> paginaFinal,
  Value<String?> registrado,
  Value<String?> numeroRegistro,
  Value<DateTime?> dataDespacho,
  Value<DateTime?> dataAbertura,
  Value<DateTime?> dataEncerramento,
  Value<DateTime?> escrituracaoInicio,
  Value<DateTime?> escrituracaoFim,
  Value<String?> texto,
});
typedef $$ContabilTermosTableUpdateCompanionBuilder = ContabilTermosCompanion
    Function({
  Value<int?> id,
  Value<int?> idContabilLivro,
  Value<String?> aberturaEncerramento,
  Value<int?> numero,
  Value<int?> paginaInicial,
  Value<int?> paginaFinal,
  Value<String?> registrado,
  Value<String?> numeroRegistro,
  Value<DateTime?> dataDespacho,
  Value<DateTime?> dataAbertura,
  Value<DateTime?> dataEncerramento,
  Value<DateTime?> escrituracaoInicio,
  Value<DateTime?> escrituracaoFim,
  Value<String?> texto,
});

class $$ContabilTermosTableTableManager extends RootTableManager<
    _$AppDatabase,
    $ContabilTermosTable,
    ContabilTermo,
    $$ContabilTermosTableFilterComposer,
    $$ContabilTermosTableOrderingComposer,
    $$ContabilTermosTableCreateCompanionBuilder,
    $$ContabilTermosTableUpdateCompanionBuilder> {
  $$ContabilTermosTableTableManager(
      _$AppDatabase db, $ContabilTermosTable table)
      : super(TableManagerState(
          db: db,
          table: table,
          filteringComposer:
              $$ContabilTermosTableFilterComposer(ComposerState(db, table)),
          orderingComposer:
              $$ContabilTermosTableOrderingComposer(ComposerState(db, table)),
          updateCompanionCallback: ({
            Value<int?> id = const Value.absent(),
            Value<int?> idContabilLivro = const Value.absent(),
            Value<String?> aberturaEncerramento = const Value.absent(),
            Value<int?> numero = const Value.absent(),
            Value<int?> paginaInicial = const Value.absent(),
            Value<int?> paginaFinal = const Value.absent(),
            Value<String?> registrado = const Value.absent(),
            Value<String?> numeroRegistro = const Value.absent(),
            Value<DateTime?> dataDespacho = const Value.absent(),
            Value<DateTime?> dataAbertura = const Value.absent(),
            Value<DateTime?> dataEncerramento = const Value.absent(),
            Value<DateTime?> escrituracaoInicio = const Value.absent(),
            Value<DateTime?> escrituracaoFim = const Value.absent(),
            Value<String?> texto = const Value.absent(),
          }) =>
              ContabilTermosCompanion(
            id: id,
            idContabilLivro: idContabilLivro,
            aberturaEncerramento: aberturaEncerramento,
            numero: numero,
            paginaInicial: paginaInicial,
            paginaFinal: paginaFinal,
            registrado: registrado,
            numeroRegistro: numeroRegistro,
            dataDespacho: dataDespacho,
            dataAbertura: dataAbertura,
            dataEncerramento: dataEncerramento,
            escrituracaoInicio: escrituracaoInicio,
            escrituracaoFim: escrituracaoFim,
            texto: texto,
          ),
          createCompanionCallback: ({
            Value<int?> id = const Value.absent(),
            Value<int?> idContabilLivro = const Value.absent(),
            Value<String?> aberturaEncerramento = const Value.absent(),
            Value<int?> numero = const Value.absent(),
            Value<int?> paginaInicial = const Value.absent(),
            Value<int?> paginaFinal = const Value.absent(),
            Value<String?> registrado = const Value.absent(),
            Value<String?> numeroRegistro = const Value.absent(),
            Value<DateTime?> dataDespacho = const Value.absent(),
            Value<DateTime?> dataAbertura = const Value.absent(),
            Value<DateTime?> dataEncerramento = const Value.absent(),
            Value<DateTime?> escrituracaoInicio = const Value.absent(),
            Value<DateTime?> escrituracaoFim = const Value.absent(),
            Value<String?> texto = const Value.absent(),
          }) =>
              ContabilTermosCompanion.insert(
            id: id,
            idContabilLivro: idContabilLivro,
            aberturaEncerramento: aberturaEncerramento,
            numero: numero,
            paginaInicial: paginaInicial,
            paginaFinal: paginaFinal,
            registrado: registrado,
            numeroRegistro: numeroRegistro,
            dataDespacho: dataDespacho,
            dataAbertura: dataAbertura,
            dataEncerramento: dataEncerramento,
            escrituracaoInicio: escrituracaoInicio,
            escrituracaoFim: escrituracaoFim,
            texto: texto,
          ),
        ));
}

class $$ContabilTermosTableFilterComposer
    extends FilterComposer<_$AppDatabase, $ContabilTermosTable> {
  $$ContabilTermosTableFilterComposer(super.$state);
  ColumnFilters<int> get id => $state.composableBuilder(
      column: $state.table.id,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<int> get idContabilLivro => $state.composableBuilder(
      column: $state.table.idContabilLivro,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get aberturaEncerramento => $state.composableBuilder(
      column: $state.table.aberturaEncerramento,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<int> get numero => $state.composableBuilder(
      column: $state.table.numero,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<int> get paginaInicial => $state.composableBuilder(
      column: $state.table.paginaInicial,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<int> get paginaFinal => $state.composableBuilder(
      column: $state.table.paginaFinal,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get registrado => $state.composableBuilder(
      column: $state.table.registrado,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get numeroRegistro => $state.composableBuilder(
      column: $state.table.numeroRegistro,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<DateTime> get dataDespacho => $state.composableBuilder(
      column: $state.table.dataDespacho,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<DateTime> get dataAbertura => $state.composableBuilder(
      column: $state.table.dataAbertura,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<DateTime> get dataEncerramento => $state.composableBuilder(
      column: $state.table.dataEncerramento,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<DateTime> get escrituracaoInicio => $state.composableBuilder(
      column: $state.table.escrituracaoInicio,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<DateTime> get escrituracaoFim => $state.composableBuilder(
      column: $state.table.escrituracaoFim,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get texto => $state.composableBuilder(
      column: $state.table.texto,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));
}

class $$ContabilTermosTableOrderingComposer
    extends OrderingComposer<_$AppDatabase, $ContabilTermosTable> {
  $$ContabilTermosTableOrderingComposer(super.$state);
  ColumnOrderings<int> get id => $state.composableBuilder(
      column: $state.table.id,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<int> get idContabilLivro => $state.composableBuilder(
      column: $state.table.idContabilLivro,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get aberturaEncerramento => $state.composableBuilder(
      column: $state.table.aberturaEncerramento,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<int> get numero => $state.composableBuilder(
      column: $state.table.numero,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<int> get paginaInicial => $state.composableBuilder(
      column: $state.table.paginaInicial,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<int> get paginaFinal => $state.composableBuilder(
      column: $state.table.paginaFinal,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get registrado => $state.composableBuilder(
      column: $state.table.registrado,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get numeroRegistro => $state.composableBuilder(
      column: $state.table.numeroRegistro,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<DateTime> get dataDespacho => $state.composableBuilder(
      column: $state.table.dataDespacho,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<DateTime> get dataAbertura => $state.composableBuilder(
      column: $state.table.dataAbertura,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<DateTime> get dataEncerramento => $state.composableBuilder(
      column: $state.table.dataEncerramento,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<DateTime> get escrituracaoInicio => $state.composableBuilder(
      column: $state.table.escrituracaoInicio,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<DateTime> get escrituracaoFim => $state.composableBuilder(
      column: $state.table.escrituracaoFim,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get texto => $state.composableBuilder(
      column: $state.table.texto,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));
}

typedef $$ContabilEncerramentoExeDetsTableCreateCompanionBuilder
    = ContabilEncerramentoExeDetsCompanion Function({
  Value<int?> id,
  Value<int?> idContabilEncerramentoExe,
  Value<int?> idContabilConta,
  Value<double?> saldoAnterior,
  Value<double?> valorDebito,
  Value<double?> valorCredito,
  Value<double?> saldo,
});
typedef $$ContabilEncerramentoExeDetsTableUpdateCompanionBuilder
    = ContabilEncerramentoExeDetsCompanion Function({
  Value<int?> id,
  Value<int?> idContabilEncerramentoExe,
  Value<int?> idContabilConta,
  Value<double?> saldoAnterior,
  Value<double?> valorDebito,
  Value<double?> valorCredito,
  Value<double?> saldo,
});

class $$ContabilEncerramentoExeDetsTableTableManager extends RootTableManager<
    _$AppDatabase,
    $ContabilEncerramentoExeDetsTable,
    ContabilEncerramentoExeDet,
    $$ContabilEncerramentoExeDetsTableFilterComposer,
    $$ContabilEncerramentoExeDetsTableOrderingComposer,
    $$ContabilEncerramentoExeDetsTableCreateCompanionBuilder,
    $$ContabilEncerramentoExeDetsTableUpdateCompanionBuilder> {
  $$ContabilEncerramentoExeDetsTableTableManager(
      _$AppDatabase db, $ContabilEncerramentoExeDetsTable table)
      : super(TableManagerState(
          db: db,
          table: table,
          filteringComposer: $$ContabilEncerramentoExeDetsTableFilterComposer(
              ComposerState(db, table)),
          orderingComposer: $$ContabilEncerramentoExeDetsTableOrderingComposer(
              ComposerState(db, table)),
          updateCompanionCallback: ({
            Value<int?> id = const Value.absent(),
            Value<int?> idContabilEncerramentoExe = const Value.absent(),
            Value<int?> idContabilConta = const Value.absent(),
            Value<double?> saldoAnterior = const Value.absent(),
            Value<double?> valorDebito = const Value.absent(),
            Value<double?> valorCredito = const Value.absent(),
            Value<double?> saldo = const Value.absent(),
          }) =>
              ContabilEncerramentoExeDetsCompanion(
            id: id,
            idContabilEncerramentoExe: idContabilEncerramentoExe,
            idContabilConta: idContabilConta,
            saldoAnterior: saldoAnterior,
            valorDebito: valorDebito,
            valorCredito: valorCredito,
            saldo: saldo,
          ),
          createCompanionCallback: ({
            Value<int?> id = const Value.absent(),
            Value<int?> idContabilEncerramentoExe = const Value.absent(),
            Value<int?> idContabilConta = const Value.absent(),
            Value<double?> saldoAnterior = const Value.absent(),
            Value<double?> valorDebito = const Value.absent(),
            Value<double?> valorCredito = const Value.absent(),
            Value<double?> saldo = const Value.absent(),
          }) =>
              ContabilEncerramentoExeDetsCompanion.insert(
            id: id,
            idContabilEncerramentoExe: idContabilEncerramentoExe,
            idContabilConta: idContabilConta,
            saldoAnterior: saldoAnterior,
            valorDebito: valorDebito,
            valorCredito: valorCredito,
            saldo: saldo,
          ),
        ));
}

class $$ContabilEncerramentoExeDetsTableFilterComposer
    extends FilterComposer<_$AppDatabase, $ContabilEncerramentoExeDetsTable> {
  $$ContabilEncerramentoExeDetsTableFilterComposer(super.$state);
  ColumnFilters<int> get id => $state.composableBuilder(
      column: $state.table.id,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<int> get idContabilEncerramentoExe => $state.composableBuilder(
      column: $state.table.idContabilEncerramentoExe,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<int> get idContabilConta => $state.composableBuilder(
      column: $state.table.idContabilConta,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<double> get saldoAnterior => $state.composableBuilder(
      column: $state.table.saldoAnterior,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<double> get valorDebito => $state.composableBuilder(
      column: $state.table.valorDebito,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<double> get valorCredito => $state.composableBuilder(
      column: $state.table.valorCredito,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<double> get saldo => $state.composableBuilder(
      column: $state.table.saldo,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));
}

class $$ContabilEncerramentoExeDetsTableOrderingComposer
    extends OrderingComposer<_$AppDatabase, $ContabilEncerramentoExeDetsTable> {
  $$ContabilEncerramentoExeDetsTableOrderingComposer(super.$state);
  ColumnOrderings<int> get id => $state.composableBuilder(
      column: $state.table.id,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<int> get idContabilEncerramentoExe =>
      $state.composableBuilder(
          column: $state.table.idContabilEncerramentoExe,
          builder: (column, joinBuilders) =>
              ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<int> get idContabilConta => $state.composableBuilder(
      column: $state.table.idContabilConta,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<double> get saldoAnterior => $state.composableBuilder(
      column: $state.table.saldoAnterior,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<double> get valorDebito => $state.composableBuilder(
      column: $state.table.valorDebito,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<double> get valorCredito => $state.composableBuilder(
      column: $state.table.valorCredito,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<double> get saldo => $state.composableBuilder(
      column: $state.table.saldo,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));
}

typedef $$RateioCentroResultadoDetsTableCreateCompanionBuilder
    = RateioCentroResultadoDetsCompanion Function({
  Value<int?> id,
  Value<int?> idCentroResultadoDestino,
  Value<int?> idRateioCentroResulCab,
  Value<double?> porcentoRateio,
});
typedef $$RateioCentroResultadoDetsTableUpdateCompanionBuilder
    = RateioCentroResultadoDetsCompanion Function({
  Value<int?> id,
  Value<int?> idCentroResultadoDestino,
  Value<int?> idRateioCentroResulCab,
  Value<double?> porcentoRateio,
});

class $$RateioCentroResultadoDetsTableTableManager extends RootTableManager<
    _$AppDatabase,
    $RateioCentroResultadoDetsTable,
    RateioCentroResultadoDet,
    $$RateioCentroResultadoDetsTableFilterComposer,
    $$RateioCentroResultadoDetsTableOrderingComposer,
    $$RateioCentroResultadoDetsTableCreateCompanionBuilder,
    $$RateioCentroResultadoDetsTableUpdateCompanionBuilder> {
  $$RateioCentroResultadoDetsTableTableManager(
      _$AppDatabase db, $RateioCentroResultadoDetsTable table)
      : super(TableManagerState(
          db: db,
          table: table,
          filteringComposer: $$RateioCentroResultadoDetsTableFilterComposer(
              ComposerState(db, table)),
          orderingComposer: $$RateioCentroResultadoDetsTableOrderingComposer(
              ComposerState(db, table)),
          updateCompanionCallback: ({
            Value<int?> id = const Value.absent(),
            Value<int?> idCentroResultadoDestino = const Value.absent(),
            Value<int?> idRateioCentroResulCab = const Value.absent(),
            Value<double?> porcentoRateio = const Value.absent(),
          }) =>
              RateioCentroResultadoDetsCompanion(
            id: id,
            idCentroResultadoDestino: idCentroResultadoDestino,
            idRateioCentroResulCab: idRateioCentroResulCab,
            porcentoRateio: porcentoRateio,
          ),
          createCompanionCallback: ({
            Value<int?> id = const Value.absent(),
            Value<int?> idCentroResultadoDestino = const Value.absent(),
            Value<int?> idRateioCentroResulCab = const Value.absent(),
            Value<double?> porcentoRateio = const Value.absent(),
          }) =>
              RateioCentroResultadoDetsCompanion.insert(
            id: id,
            idCentroResultadoDestino: idCentroResultadoDestino,
            idRateioCentroResulCab: idRateioCentroResulCab,
            porcentoRateio: porcentoRateio,
          ),
        ));
}

class $$RateioCentroResultadoDetsTableFilterComposer
    extends FilterComposer<_$AppDatabase, $RateioCentroResultadoDetsTable> {
  $$RateioCentroResultadoDetsTableFilterComposer(super.$state);
  ColumnFilters<int> get id => $state.composableBuilder(
      column: $state.table.id,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<int> get idCentroResultadoDestino => $state.composableBuilder(
      column: $state.table.idCentroResultadoDestino,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<int> get idRateioCentroResulCab => $state.composableBuilder(
      column: $state.table.idRateioCentroResulCab,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<double> get porcentoRateio => $state.composableBuilder(
      column: $state.table.porcentoRateio,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));
}

class $$RateioCentroResultadoDetsTableOrderingComposer
    extends OrderingComposer<_$AppDatabase, $RateioCentroResultadoDetsTable> {
  $$RateioCentroResultadoDetsTableOrderingComposer(super.$state);
  ColumnOrderings<int> get id => $state.composableBuilder(
      column: $state.table.id,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<int> get idCentroResultadoDestino => $state.composableBuilder(
      column: $state.table.idCentroResultadoDestino,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<int> get idRateioCentroResulCab => $state.composableBuilder(
      column: $state.table.idRateioCentroResulCab,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<double> get porcentoRateio => $state.composableBuilder(
      column: $state.table.porcentoRateio,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));
}

typedef $$ContabilIndiceValorsTableCreateCompanionBuilder
    = ContabilIndiceValorsCompanion Function({
  Value<int?> id,
  Value<int?> idContabilIndice,
  Value<DateTime?> dataIndice,
  Value<double?> valor,
});
typedef $$ContabilIndiceValorsTableUpdateCompanionBuilder
    = ContabilIndiceValorsCompanion Function({
  Value<int?> id,
  Value<int?> idContabilIndice,
  Value<DateTime?> dataIndice,
  Value<double?> valor,
});

class $$ContabilIndiceValorsTableTableManager extends RootTableManager<
    _$AppDatabase,
    $ContabilIndiceValorsTable,
    ContabilIndiceValor,
    $$ContabilIndiceValorsTableFilterComposer,
    $$ContabilIndiceValorsTableOrderingComposer,
    $$ContabilIndiceValorsTableCreateCompanionBuilder,
    $$ContabilIndiceValorsTableUpdateCompanionBuilder> {
  $$ContabilIndiceValorsTableTableManager(
      _$AppDatabase db, $ContabilIndiceValorsTable table)
      : super(TableManagerState(
          db: db,
          table: table,
          filteringComposer: $$ContabilIndiceValorsTableFilterComposer(
              ComposerState(db, table)),
          orderingComposer: $$ContabilIndiceValorsTableOrderingComposer(
              ComposerState(db, table)),
          updateCompanionCallback: ({
            Value<int?> id = const Value.absent(),
            Value<int?> idContabilIndice = const Value.absent(),
            Value<DateTime?> dataIndice = const Value.absent(),
            Value<double?> valor = const Value.absent(),
          }) =>
              ContabilIndiceValorsCompanion(
            id: id,
            idContabilIndice: idContabilIndice,
            dataIndice: dataIndice,
            valor: valor,
          ),
          createCompanionCallback: ({
            Value<int?> id = const Value.absent(),
            Value<int?> idContabilIndice = const Value.absent(),
            Value<DateTime?> dataIndice = const Value.absent(),
            Value<double?> valor = const Value.absent(),
          }) =>
              ContabilIndiceValorsCompanion.insert(
            id: id,
            idContabilIndice: idContabilIndice,
            dataIndice: dataIndice,
            valor: valor,
          ),
        ));
}

class $$ContabilIndiceValorsTableFilterComposer
    extends FilterComposer<_$AppDatabase, $ContabilIndiceValorsTable> {
  $$ContabilIndiceValorsTableFilterComposer(super.$state);
  ColumnFilters<int> get id => $state.composableBuilder(
      column: $state.table.id,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<int> get idContabilIndice => $state.composableBuilder(
      column: $state.table.idContabilIndice,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<DateTime> get dataIndice => $state.composableBuilder(
      column: $state.table.dataIndice,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<double> get valor => $state.composableBuilder(
      column: $state.table.valor,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));
}

class $$ContabilIndiceValorsTableOrderingComposer
    extends OrderingComposer<_$AppDatabase, $ContabilIndiceValorsTable> {
  $$ContabilIndiceValorsTableOrderingComposer(super.$state);
  ColumnOrderings<int> get id => $state.composableBuilder(
      column: $state.table.id,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<int> get idContabilIndice => $state.composableBuilder(
      column: $state.table.idContabilIndice,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<DateTime> get dataIndice => $state.composableBuilder(
      column: $state.table.dataIndice,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<double> get valor => $state.composableBuilder(
      column: $state.table.valor,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));
}

typedef $$CtResultadoNtFinanceirasTableCreateCompanionBuilder
    = CtResultadoNtFinanceirasCompanion Function({
  Value<int?> id,
  Value<int?> idCentroResultado,
  Value<int?> idFinNaturezaFinanceira,
  Value<double?> percentualRateio,
});
typedef $$CtResultadoNtFinanceirasTableUpdateCompanionBuilder
    = CtResultadoNtFinanceirasCompanion Function({
  Value<int?> id,
  Value<int?> idCentroResultado,
  Value<int?> idFinNaturezaFinanceira,
  Value<double?> percentualRateio,
});

class $$CtResultadoNtFinanceirasTableTableManager extends RootTableManager<
    _$AppDatabase,
    $CtResultadoNtFinanceirasTable,
    CtResultadoNtFinanceira,
    $$CtResultadoNtFinanceirasTableFilterComposer,
    $$CtResultadoNtFinanceirasTableOrderingComposer,
    $$CtResultadoNtFinanceirasTableCreateCompanionBuilder,
    $$CtResultadoNtFinanceirasTableUpdateCompanionBuilder> {
  $$CtResultadoNtFinanceirasTableTableManager(
      _$AppDatabase db, $CtResultadoNtFinanceirasTable table)
      : super(TableManagerState(
          db: db,
          table: table,
          filteringComposer: $$CtResultadoNtFinanceirasTableFilterComposer(
              ComposerState(db, table)),
          orderingComposer: $$CtResultadoNtFinanceirasTableOrderingComposer(
              ComposerState(db, table)),
          updateCompanionCallback: ({
            Value<int?> id = const Value.absent(),
            Value<int?> idCentroResultado = const Value.absent(),
            Value<int?> idFinNaturezaFinanceira = const Value.absent(),
            Value<double?> percentualRateio = const Value.absent(),
          }) =>
              CtResultadoNtFinanceirasCompanion(
            id: id,
            idCentroResultado: idCentroResultado,
            idFinNaturezaFinanceira: idFinNaturezaFinanceira,
            percentualRateio: percentualRateio,
          ),
          createCompanionCallback: ({
            Value<int?> id = const Value.absent(),
            Value<int?> idCentroResultado = const Value.absent(),
            Value<int?> idFinNaturezaFinanceira = const Value.absent(),
            Value<double?> percentualRateio = const Value.absent(),
          }) =>
              CtResultadoNtFinanceirasCompanion.insert(
            id: id,
            idCentroResultado: idCentroResultado,
            idFinNaturezaFinanceira: idFinNaturezaFinanceira,
            percentualRateio: percentualRateio,
          ),
        ));
}

class $$CtResultadoNtFinanceirasTableFilterComposer
    extends FilterComposer<_$AppDatabase, $CtResultadoNtFinanceirasTable> {
  $$CtResultadoNtFinanceirasTableFilterComposer(super.$state);
  ColumnFilters<int> get id => $state.composableBuilder(
      column: $state.table.id,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<int> get idCentroResultado => $state.composableBuilder(
      column: $state.table.idCentroResultado,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<int> get idFinNaturezaFinanceira => $state.composableBuilder(
      column: $state.table.idFinNaturezaFinanceira,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<double> get percentualRateio => $state.composableBuilder(
      column: $state.table.percentualRateio,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));
}

class $$CtResultadoNtFinanceirasTableOrderingComposer
    extends OrderingComposer<_$AppDatabase, $CtResultadoNtFinanceirasTable> {
  $$CtResultadoNtFinanceirasTableOrderingComposer(super.$state);
  ColumnOrderings<int> get id => $state.composableBuilder(
      column: $state.table.id,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<int> get idCentroResultado => $state.composableBuilder(
      column: $state.table.idCentroResultado,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<int> get idFinNaturezaFinanceira => $state.composableBuilder(
      column: $state.table.idFinNaturezaFinanceira,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<double> get percentualRateio => $state.composableBuilder(
      column: $state.table.percentualRateio,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));
}

typedef $$ContabilLancamentoCabecalhosTableCreateCompanionBuilder
    = ContabilLancamentoCabecalhosCompanion Function({
  Value<int?> id,
  Value<int?> idContabilLote,
  Value<DateTime?> dataLancamento,
  Value<DateTime?> dataInclusao,
  Value<String?> tipo,
  Value<String?> liberado,
  Value<double?> valor,
});
typedef $$ContabilLancamentoCabecalhosTableUpdateCompanionBuilder
    = ContabilLancamentoCabecalhosCompanion Function({
  Value<int?> id,
  Value<int?> idContabilLote,
  Value<DateTime?> dataLancamento,
  Value<DateTime?> dataInclusao,
  Value<String?> tipo,
  Value<String?> liberado,
  Value<double?> valor,
});

class $$ContabilLancamentoCabecalhosTableTableManager extends RootTableManager<
    _$AppDatabase,
    $ContabilLancamentoCabecalhosTable,
    ContabilLancamentoCabecalho,
    $$ContabilLancamentoCabecalhosTableFilterComposer,
    $$ContabilLancamentoCabecalhosTableOrderingComposer,
    $$ContabilLancamentoCabecalhosTableCreateCompanionBuilder,
    $$ContabilLancamentoCabecalhosTableUpdateCompanionBuilder> {
  $$ContabilLancamentoCabecalhosTableTableManager(
      _$AppDatabase db, $ContabilLancamentoCabecalhosTable table)
      : super(TableManagerState(
          db: db,
          table: table,
          filteringComposer: $$ContabilLancamentoCabecalhosTableFilterComposer(
              ComposerState(db, table)),
          orderingComposer: $$ContabilLancamentoCabecalhosTableOrderingComposer(
              ComposerState(db, table)),
          updateCompanionCallback: ({
            Value<int?> id = const Value.absent(),
            Value<int?> idContabilLote = const Value.absent(),
            Value<DateTime?> dataLancamento = const Value.absent(),
            Value<DateTime?> dataInclusao = const Value.absent(),
            Value<String?> tipo = const Value.absent(),
            Value<String?> liberado = const Value.absent(),
            Value<double?> valor = const Value.absent(),
          }) =>
              ContabilLancamentoCabecalhosCompanion(
            id: id,
            idContabilLote: idContabilLote,
            dataLancamento: dataLancamento,
            dataInclusao: dataInclusao,
            tipo: tipo,
            liberado: liberado,
            valor: valor,
          ),
          createCompanionCallback: ({
            Value<int?> id = const Value.absent(),
            Value<int?> idContabilLote = const Value.absent(),
            Value<DateTime?> dataLancamento = const Value.absent(),
            Value<DateTime?> dataInclusao = const Value.absent(),
            Value<String?> tipo = const Value.absent(),
            Value<String?> liberado = const Value.absent(),
            Value<double?> valor = const Value.absent(),
          }) =>
              ContabilLancamentoCabecalhosCompanion.insert(
            id: id,
            idContabilLote: idContabilLote,
            dataLancamento: dataLancamento,
            dataInclusao: dataInclusao,
            tipo: tipo,
            liberado: liberado,
            valor: valor,
          ),
        ));
}

class $$ContabilLancamentoCabecalhosTableFilterComposer
    extends FilterComposer<_$AppDatabase, $ContabilLancamentoCabecalhosTable> {
  $$ContabilLancamentoCabecalhosTableFilterComposer(super.$state);
  ColumnFilters<int> get id => $state.composableBuilder(
      column: $state.table.id,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<int> get idContabilLote => $state.composableBuilder(
      column: $state.table.idContabilLote,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<DateTime> get dataLancamento => $state.composableBuilder(
      column: $state.table.dataLancamento,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<DateTime> get dataInclusao => $state.composableBuilder(
      column: $state.table.dataInclusao,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get tipo => $state.composableBuilder(
      column: $state.table.tipo,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get liberado => $state.composableBuilder(
      column: $state.table.liberado,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<double> get valor => $state.composableBuilder(
      column: $state.table.valor,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));
}

class $$ContabilLancamentoCabecalhosTableOrderingComposer
    extends OrderingComposer<_$AppDatabase,
        $ContabilLancamentoCabecalhosTable> {
  $$ContabilLancamentoCabecalhosTableOrderingComposer(super.$state);
  ColumnOrderings<int> get id => $state.composableBuilder(
      column: $state.table.id,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<int> get idContabilLote => $state.composableBuilder(
      column: $state.table.idContabilLote,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<DateTime> get dataLancamento => $state.composableBuilder(
      column: $state.table.dataLancamento,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<DateTime> get dataInclusao => $state.composableBuilder(
      column: $state.table.dataInclusao,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get tipo => $state.composableBuilder(
      column: $state.table.tipo,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get liberado => $state.composableBuilder(
      column: $state.table.liberado,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<double> get valor => $state.composableBuilder(
      column: $state.table.valor,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));
}

typedef $$ContabilDreCabecalhosTableCreateCompanionBuilder
    = ContabilDreCabecalhosCompanion Function({
  Value<int?> id,
  Value<String?> descricao,
  Value<String?> padrao,
  Value<String?> periodoInicial,
  Value<String?> periodoFinal,
});
typedef $$ContabilDreCabecalhosTableUpdateCompanionBuilder
    = ContabilDreCabecalhosCompanion Function({
  Value<int?> id,
  Value<String?> descricao,
  Value<String?> padrao,
  Value<String?> periodoInicial,
  Value<String?> periodoFinal,
});

class $$ContabilDreCabecalhosTableTableManager extends RootTableManager<
    _$AppDatabase,
    $ContabilDreCabecalhosTable,
    ContabilDreCabecalho,
    $$ContabilDreCabecalhosTableFilterComposer,
    $$ContabilDreCabecalhosTableOrderingComposer,
    $$ContabilDreCabecalhosTableCreateCompanionBuilder,
    $$ContabilDreCabecalhosTableUpdateCompanionBuilder> {
  $$ContabilDreCabecalhosTableTableManager(
      _$AppDatabase db, $ContabilDreCabecalhosTable table)
      : super(TableManagerState(
          db: db,
          table: table,
          filteringComposer: $$ContabilDreCabecalhosTableFilterComposer(
              ComposerState(db, table)),
          orderingComposer: $$ContabilDreCabecalhosTableOrderingComposer(
              ComposerState(db, table)),
          updateCompanionCallback: ({
            Value<int?> id = const Value.absent(),
            Value<String?> descricao = const Value.absent(),
            Value<String?> padrao = const Value.absent(),
            Value<String?> periodoInicial = const Value.absent(),
            Value<String?> periodoFinal = const Value.absent(),
          }) =>
              ContabilDreCabecalhosCompanion(
            id: id,
            descricao: descricao,
            padrao: padrao,
            periodoInicial: periodoInicial,
            periodoFinal: periodoFinal,
          ),
          createCompanionCallback: ({
            Value<int?> id = const Value.absent(),
            Value<String?> descricao = const Value.absent(),
            Value<String?> padrao = const Value.absent(),
            Value<String?> periodoInicial = const Value.absent(),
            Value<String?> periodoFinal = const Value.absent(),
          }) =>
              ContabilDreCabecalhosCompanion.insert(
            id: id,
            descricao: descricao,
            padrao: padrao,
            periodoInicial: periodoInicial,
            periodoFinal: periodoFinal,
          ),
        ));
}

class $$ContabilDreCabecalhosTableFilterComposer
    extends FilterComposer<_$AppDatabase, $ContabilDreCabecalhosTable> {
  $$ContabilDreCabecalhosTableFilterComposer(super.$state);
  ColumnFilters<int> get id => $state.composableBuilder(
      column: $state.table.id,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get descricao => $state.composableBuilder(
      column: $state.table.descricao,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get padrao => $state.composableBuilder(
      column: $state.table.padrao,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get periodoInicial => $state.composableBuilder(
      column: $state.table.periodoInicial,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get periodoFinal => $state.composableBuilder(
      column: $state.table.periodoFinal,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));
}

class $$ContabilDreCabecalhosTableOrderingComposer
    extends OrderingComposer<_$AppDatabase, $ContabilDreCabecalhosTable> {
  $$ContabilDreCabecalhosTableOrderingComposer(super.$state);
  ColumnOrderings<int> get id => $state.composableBuilder(
      column: $state.table.id,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get descricao => $state.composableBuilder(
      column: $state.table.descricao,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get padrao => $state.composableBuilder(
      column: $state.table.padrao,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get periodoInicial => $state.composableBuilder(
      column: $state.table.periodoInicial,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get periodoFinal => $state.composableBuilder(
      column: $state.table.periodoFinal,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));
}

typedef $$ContabilLivrosTableCreateCompanionBuilder = ContabilLivrosCompanion
    Function({
  Value<int?> id,
  Value<String?> competencia,
  Value<String?> formaEscrituracao,
  Value<String?> descricao,
});
typedef $$ContabilLivrosTableUpdateCompanionBuilder = ContabilLivrosCompanion
    Function({
  Value<int?> id,
  Value<String?> competencia,
  Value<String?> formaEscrituracao,
  Value<String?> descricao,
});

class $$ContabilLivrosTableTableManager extends RootTableManager<
    _$AppDatabase,
    $ContabilLivrosTable,
    ContabilLivro,
    $$ContabilLivrosTableFilterComposer,
    $$ContabilLivrosTableOrderingComposer,
    $$ContabilLivrosTableCreateCompanionBuilder,
    $$ContabilLivrosTableUpdateCompanionBuilder> {
  $$ContabilLivrosTableTableManager(
      _$AppDatabase db, $ContabilLivrosTable table)
      : super(TableManagerState(
          db: db,
          table: table,
          filteringComposer:
              $$ContabilLivrosTableFilterComposer(ComposerState(db, table)),
          orderingComposer:
              $$ContabilLivrosTableOrderingComposer(ComposerState(db, table)),
          updateCompanionCallback: ({
            Value<int?> id = const Value.absent(),
            Value<String?> competencia = const Value.absent(),
            Value<String?> formaEscrituracao = const Value.absent(),
            Value<String?> descricao = const Value.absent(),
          }) =>
              ContabilLivrosCompanion(
            id: id,
            competencia: competencia,
            formaEscrituracao: formaEscrituracao,
            descricao: descricao,
          ),
          createCompanionCallback: ({
            Value<int?> id = const Value.absent(),
            Value<String?> competencia = const Value.absent(),
            Value<String?> formaEscrituracao = const Value.absent(),
            Value<String?> descricao = const Value.absent(),
          }) =>
              ContabilLivrosCompanion.insert(
            id: id,
            competencia: competencia,
            formaEscrituracao: formaEscrituracao,
            descricao: descricao,
          ),
        ));
}

class $$ContabilLivrosTableFilterComposer
    extends FilterComposer<_$AppDatabase, $ContabilLivrosTable> {
  $$ContabilLivrosTableFilterComposer(super.$state);
  ColumnFilters<int> get id => $state.composableBuilder(
      column: $state.table.id,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get competencia => $state.composableBuilder(
      column: $state.table.competencia,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get formaEscrituracao => $state.composableBuilder(
      column: $state.table.formaEscrituracao,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get descricao => $state.composableBuilder(
      column: $state.table.descricao,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));
}

class $$ContabilLivrosTableOrderingComposer
    extends OrderingComposer<_$AppDatabase, $ContabilLivrosTable> {
  $$ContabilLivrosTableOrderingComposer(super.$state);
  ColumnOrderings<int> get id => $state.composableBuilder(
      column: $state.table.id,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get competencia => $state.composableBuilder(
      column: $state.table.competencia,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get formaEscrituracao => $state.composableBuilder(
      column: $state.table.formaEscrituracao,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get descricao => $state.composableBuilder(
      column: $state.table.descricao,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));
}

typedef $$ContabilEncerramentoExeCabsTableCreateCompanionBuilder
    = ContabilEncerramentoExeCabsCompanion Function({
  Value<int?> id,
  Value<DateTime?> dataInicio,
  Value<DateTime?> dataFim,
  Value<DateTime?> dataInclusao,
  Value<String?> motivo,
});
typedef $$ContabilEncerramentoExeCabsTableUpdateCompanionBuilder
    = ContabilEncerramentoExeCabsCompanion Function({
  Value<int?> id,
  Value<DateTime?> dataInicio,
  Value<DateTime?> dataFim,
  Value<DateTime?> dataInclusao,
  Value<String?> motivo,
});

class $$ContabilEncerramentoExeCabsTableTableManager extends RootTableManager<
    _$AppDatabase,
    $ContabilEncerramentoExeCabsTable,
    ContabilEncerramentoExeCab,
    $$ContabilEncerramentoExeCabsTableFilterComposer,
    $$ContabilEncerramentoExeCabsTableOrderingComposer,
    $$ContabilEncerramentoExeCabsTableCreateCompanionBuilder,
    $$ContabilEncerramentoExeCabsTableUpdateCompanionBuilder> {
  $$ContabilEncerramentoExeCabsTableTableManager(
      _$AppDatabase db, $ContabilEncerramentoExeCabsTable table)
      : super(TableManagerState(
          db: db,
          table: table,
          filteringComposer: $$ContabilEncerramentoExeCabsTableFilterComposer(
              ComposerState(db, table)),
          orderingComposer: $$ContabilEncerramentoExeCabsTableOrderingComposer(
              ComposerState(db, table)),
          updateCompanionCallback: ({
            Value<int?> id = const Value.absent(),
            Value<DateTime?> dataInicio = const Value.absent(),
            Value<DateTime?> dataFim = const Value.absent(),
            Value<DateTime?> dataInclusao = const Value.absent(),
            Value<String?> motivo = const Value.absent(),
          }) =>
              ContabilEncerramentoExeCabsCompanion(
            id: id,
            dataInicio: dataInicio,
            dataFim: dataFim,
            dataInclusao: dataInclusao,
            motivo: motivo,
          ),
          createCompanionCallback: ({
            Value<int?> id = const Value.absent(),
            Value<DateTime?> dataInicio = const Value.absent(),
            Value<DateTime?> dataFim = const Value.absent(),
            Value<DateTime?> dataInclusao = const Value.absent(),
            Value<String?> motivo = const Value.absent(),
          }) =>
              ContabilEncerramentoExeCabsCompanion.insert(
            id: id,
            dataInicio: dataInicio,
            dataFim: dataFim,
            dataInclusao: dataInclusao,
            motivo: motivo,
          ),
        ));
}

class $$ContabilEncerramentoExeCabsTableFilterComposer
    extends FilterComposer<_$AppDatabase, $ContabilEncerramentoExeCabsTable> {
  $$ContabilEncerramentoExeCabsTableFilterComposer(super.$state);
  ColumnFilters<int> get id => $state.composableBuilder(
      column: $state.table.id,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<DateTime> get dataInicio => $state.composableBuilder(
      column: $state.table.dataInicio,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<DateTime> get dataFim => $state.composableBuilder(
      column: $state.table.dataFim,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<DateTime> get dataInclusao => $state.composableBuilder(
      column: $state.table.dataInclusao,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get motivo => $state.composableBuilder(
      column: $state.table.motivo,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));
}

class $$ContabilEncerramentoExeCabsTableOrderingComposer
    extends OrderingComposer<_$AppDatabase, $ContabilEncerramentoExeCabsTable> {
  $$ContabilEncerramentoExeCabsTableOrderingComposer(super.$state);
  ColumnOrderings<int> get id => $state.composableBuilder(
      column: $state.table.id,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<DateTime> get dataInicio => $state.composableBuilder(
      column: $state.table.dataInicio,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<DateTime> get dataFim => $state.composableBuilder(
      column: $state.table.dataFim,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<DateTime> get dataInclusao => $state.composableBuilder(
      column: $state.table.dataInclusao,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get motivo => $state.composableBuilder(
      column: $state.table.motivo,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));
}

typedef $$CentroResultadosTableCreateCompanionBuilder
    = CentroResultadosCompanion Function({
  Value<int?> id,
  Value<int?> idPlanoCentroResultado,
  Value<String?> descricao,
  Value<String?> classificacao,
  Value<String?> sofreRateiro,
});
typedef $$CentroResultadosTableUpdateCompanionBuilder
    = CentroResultadosCompanion Function({
  Value<int?> id,
  Value<int?> idPlanoCentroResultado,
  Value<String?> descricao,
  Value<String?> classificacao,
  Value<String?> sofreRateiro,
});

class $$CentroResultadosTableTableManager extends RootTableManager<
    _$AppDatabase,
    $CentroResultadosTable,
    CentroResultado,
    $$CentroResultadosTableFilterComposer,
    $$CentroResultadosTableOrderingComposer,
    $$CentroResultadosTableCreateCompanionBuilder,
    $$CentroResultadosTableUpdateCompanionBuilder> {
  $$CentroResultadosTableTableManager(
      _$AppDatabase db, $CentroResultadosTable table)
      : super(TableManagerState(
          db: db,
          table: table,
          filteringComposer:
              $$CentroResultadosTableFilterComposer(ComposerState(db, table)),
          orderingComposer:
              $$CentroResultadosTableOrderingComposer(ComposerState(db, table)),
          updateCompanionCallback: ({
            Value<int?> id = const Value.absent(),
            Value<int?> idPlanoCentroResultado = const Value.absent(),
            Value<String?> descricao = const Value.absent(),
            Value<String?> classificacao = const Value.absent(),
            Value<String?> sofreRateiro = const Value.absent(),
          }) =>
              CentroResultadosCompanion(
            id: id,
            idPlanoCentroResultado: idPlanoCentroResultado,
            descricao: descricao,
            classificacao: classificacao,
            sofreRateiro: sofreRateiro,
          ),
          createCompanionCallback: ({
            Value<int?> id = const Value.absent(),
            Value<int?> idPlanoCentroResultado = const Value.absent(),
            Value<String?> descricao = const Value.absent(),
            Value<String?> classificacao = const Value.absent(),
            Value<String?> sofreRateiro = const Value.absent(),
          }) =>
              CentroResultadosCompanion.insert(
            id: id,
            idPlanoCentroResultado: idPlanoCentroResultado,
            descricao: descricao,
            classificacao: classificacao,
            sofreRateiro: sofreRateiro,
          ),
        ));
}

class $$CentroResultadosTableFilterComposer
    extends FilterComposer<_$AppDatabase, $CentroResultadosTable> {
  $$CentroResultadosTableFilterComposer(super.$state);
  ColumnFilters<int> get id => $state.composableBuilder(
      column: $state.table.id,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<int> get idPlanoCentroResultado => $state.composableBuilder(
      column: $state.table.idPlanoCentroResultado,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get descricao => $state.composableBuilder(
      column: $state.table.descricao,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get classificacao => $state.composableBuilder(
      column: $state.table.classificacao,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get sofreRateiro => $state.composableBuilder(
      column: $state.table.sofreRateiro,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));
}

class $$CentroResultadosTableOrderingComposer
    extends OrderingComposer<_$AppDatabase, $CentroResultadosTable> {
  $$CentroResultadosTableOrderingComposer(super.$state);
  ColumnOrderings<int> get id => $state.composableBuilder(
      column: $state.table.id,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<int> get idPlanoCentroResultado => $state.composableBuilder(
      column: $state.table.idPlanoCentroResultado,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get descricao => $state.composableBuilder(
      column: $state.table.descricao,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get classificacao => $state.composableBuilder(
      column: $state.table.classificacao,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get sofreRateiro => $state.composableBuilder(
      column: $state.table.sofreRateiro,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));
}

typedef $$RateioCentroResultadoCabsTableCreateCompanionBuilder
    = RateioCentroResultadoCabsCompanion Function({
  Value<int?> id,
  Value<int?> idCentroResultado,
  Value<String?> descricao,
});
typedef $$RateioCentroResultadoCabsTableUpdateCompanionBuilder
    = RateioCentroResultadoCabsCompanion Function({
  Value<int?> id,
  Value<int?> idCentroResultado,
  Value<String?> descricao,
});

class $$RateioCentroResultadoCabsTableTableManager extends RootTableManager<
    _$AppDatabase,
    $RateioCentroResultadoCabsTable,
    RateioCentroResultadoCab,
    $$RateioCentroResultadoCabsTableFilterComposer,
    $$RateioCentroResultadoCabsTableOrderingComposer,
    $$RateioCentroResultadoCabsTableCreateCompanionBuilder,
    $$RateioCentroResultadoCabsTableUpdateCompanionBuilder> {
  $$RateioCentroResultadoCabsTableTableManager(
      _$AppDatabase db, $RateioCentroResultadoCabsTable table)
      : super(TableManagerState(
          db: db,
          table: table,
          filteringComposer: $$RateioCentroResultadoCabsTableFilterComposer(
              ComposerState(db, table)),
          orderingComposer: $$RateioCentroResultadoCabsTableOrderingComposer(
              ComposerState(db, table)),
          updateCompanionCallback: ({
            Value<int?> id = const Value.absent(),
            Value<int?> idCentroResultado = const Value.absent(),
            Value<String?> descricao = const Value.absent(),
          }) =>
              RateioCentroResultadoCabsCompanion(
            id: id,
            idCentroResultado: idCentroResultado,
            descricao: descricao,
          ),
          createCompanionCallback: ({
            Value<int?> id = const Value.absent(),
            Value<int?> idCentroResultado = const Value.absent(),
            Value<String?> descricao = const Value.absent(),
          }) =>
              RateioCentroResultadoCabsCompanion.insert(
            id: id,
            idCentroResultado: idCentroResultado,
            descricao: descricao,
          ),
        ));
}

class $$RateioCentroResultadoCabsTableFilterComposer
    extends FilterComposer<_$AppDatabase, $RateioCentroResultadoCabsTable> {
  $$RateioCentroResultadoCabsTableFilterComposer(super.$state);
  ColumnFilters<int> get id => $state.composableBuilder(
      column: $state.table.id,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<int> get idCentroResultado => $state.composableBuilder(
      column: $state.table.idCentroResultado,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get descricao => $state.composableBuilder(
      column: $state.table.descricao,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));
}

class $$RateioCentroResultadoCabsTableOrderingComposer
    extends OrderingComposer<_$AppDatabase, $RateioCentroResultadoCabsTable> {
  $$RateioCentroResultadoCabsTableOrderingComposer(super.$state);
  ColumnOrderings<int> get id => $state.composableBuilder(
      column: $state.table.id,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<int> get idCentroResultado => $state.composableBuilder(
      column: $state.table.idCentroResultado,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get descricao => $state.composableBuilder(
      column: $state.table.descricao,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));
}

typedef $$ContabilIndicesTableCreateCompanionBuilder = ContabilIndicesCompanion
    Function({
  Value<int?> id,
  Value<String?> indice,
  Value<String?> periodicidade,
  Value<DateTime?> diarioAPartirDe,
  Value<String?> mensalMesAno,
});
typedef $$ContabilIndicesTableUpdateCompanionBuilder = ContabilIndicesCompanion
    Function({
  Value<int?> id,
  Value<String?> indice,
  Value<String?> periodicidade,
  Value<DateTime?> diarioAPartirDe,
  Value<String?> mensalMesAno,
});

class $$ContabilIndicesTableTableManager extends RootTableManager<
    _$AppDatabase,
    $ContabilIndicesTable,
    ContabilIndice,
    $$ContabilIndicesTableFilterComposer,
    $$ContabilIndicesTableOrderingComposer,
    $$ContabilIndicesTableCreateCompanionBuilder,
    $$ContabilIndicesTableUpdateCompanionBuilder> {
  $$ContabilIndicesTableTableManager(
      _$AppDatabase db, $ContabilIndicesTable table)
      : super(TableManagerState(
          db: db,
          table: table,
          filteringComposer:
              $$ContabilIndicesTableFilterComposer(ComposerState(db, table)),
          orderingComposer:
              $$ContabilIndicesTableOrderingComposer(ComposerState(db, table)),
          updateCompanionCallback: ({
            Value<int?> id = const Value.absent(),
            Value<String?> indice = const Value.absent(),
            Value<String?> periodicidade = const Value.absent(),
            Value<DateTime?> diarioAPartirDe = const Value.absent(),
            Value<String?> mensalMesAno = const Value.absent(),
          }) =>
              ContabilIndicesCompanion(
            id: id,
            indice: indice,
            periodicidade: periodicidade,
            diarioAPartirDe: diarioAPartirDe,
            mensalMesAno: mensalMesAno,
          ),
          createCompanionCallback: ({
            Value<int?> id = const Value.absent(),
            Value<String?> indice = const Value.absent(),
            Value<String?> periodicidade = const Value.absent(),
            Value<DateTime?> diarioAPartirDe = const Value.absent(),
            Value<String?> mensalMesAno = const Value.absent(),
          }) =>
              ContabilIndicesCompanion.insert(
            id: id,
            indice: indice,
            periodicidade: periodicidade,
            diarioAPartirDe: diarioAPartirDe,
            mensalMesAno: mensalMesAno,
          ),
        ));
}

class $$ContabilIndicesTableFilterComposer
    extends FilterComposer<_$AppDatabase, $ContabilIndicesTable> {
  $$ContabilIndicesTableFilterComposer(super.$state);
  ColumnFilters<int> get id => $state.composableBuilder(
      column: $state.table.id,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get indice => $state.composableBuilder(
      column: $state.table.indice,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get periodicidade => $state.composableBuilder(
      column: $state.table.periodicidade,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<DateTime> get diarioAPartirDe => $state.composableBuilder(
      column: $state.table.diarioAPartirDe,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get mensalMesAno => $state.composableBuilder(
      column: $state.table.mensalMesAno,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));
}

class $$ContabilIndicesTableOrderingComposer
    extends OrderingComposer<_$AppDatabase, $ContabilIndicesTable> {
  $$ContabilIndicesTableOrderingComposer(super.$state);
  ColumnOrderings<int> get id => $state.composableBuilder(
      column: $state.table.id,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get indice => $state.composableBuilder(
      column: $state.table.indice,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get periodicidade => $state.composableBuilder(
      column: $state.table.periodicidade,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<DateTime> get diarioAPartirDe => $state.composableBuilder(
      column: $state.table.diarioAPartirDe,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get mensalMesAno => $state.composableBuilder(
      column: $state.table.mensalMesAno,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));
}

typedef $$FinNaturezaFinanceirasTableCreateCompanionBuilder
    = FinNaturezaFinanceirasCompanion Function({
  Value<int?> id,
  Value<String?> codigo,
  Value<String?> descricao,
  Value<String?> tipo,
  Value<String?> aplicacao,
});
typedef $$FinNaturezaFinanceirasTableUpdateCompanionBuilder
    = FinNaturezaFinanceirasCompanion Function({
  Value<int?> id,
  Value<String?> codigo,
  Value<String?> descricao,
  Value<String?> tipo,
  Value<String?> aplicacao,
});

class $$FinNaturezaFinanceirasTableTableManager extends RootTableManager<
    _$AppDatabase,
    $FinNaturezaFinanceirasTable,
    FinNaturezaFinanceira,
    $$FinNaturezaFinanceirasTableFilterComposer,
    $$FinNaturezaFinanceirasTableOrderingComposer,
    $$FinNaturezaFinanceirasTableCreateCompanionBuilder,
    $$FinNaturezaFinanceirasTableUpdateCompanionBuilder> {
  $$FinNaturezaFinanceirasTableTableManager(
      _$AppDatabase db, $FinNaturezaFinanceirasTable table)
      : super(TableManagerState(
          db: db,
          table: table,
          filteringComposer: $$FinNaturezaFinanceirasTableFilterComposer(
              ComposerState(db, table)),
          orderingComposer: $$FinNaturezaFinanceirasTableOrderingComposer(
              ComposerState(db, table)),
          updateCompanionCallback: ({
            Value<int?> id = const Value.absent(),
            Value<String?> codigo = const Value.absent(),
            Value<String?> descricao = const Value.absent(),
            Value<String?> tipo = const Value.absent(),
            Value<String?> aplicacao = const Value.absent(),
          }) =>
              FinNaturezaFinanceirasCompanion(
            id: id,
            codigo: codigo,
            descricao: descricao,
            tipo: tipo,
            aplicacao: aplicacao,
          ),
          createCompanionCallback: ({
            Value<int?> id = const Value.absent(),
            Value<String?> codigo = const Value.absent(),
            Value<String?> descricao = const Value.absent(),
            Value<String?> tipo = const Value.absent(),
            Value<String?> aplicacao = const Value.absent(),
          }) =>
              FinNaturezaFinanceirasCompanion.insert(
            id: id,
            codigo: codigo,
            descricao: descricao,
            tipo: tipo,
            aplicacao: aplicacao,
          ),
        ));
}

class $$FinNaturezaFinanceirasTableFilterComposer
    extends FilterComposer<_$AppDatabase, $FinNaturezaFinanceirasTable> {
  $$FinNaturezaFinanceirasTableFilterComposer(super.$state);
  ColumnFilters<int> get id => $state.composableBuilder(
      column: $state.table.id,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get codigo => $state.composableBuilder(
      column: $state.table.codigo,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get descricao => $state.composableBuilder(
      column: $state.table.descricao,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get tipo => $state.composableBuilder(
      column: $state.table.tipo,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get aplicacao => $state.composableBuilder(
      column: $state.table.aplicacao,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));
}

class $$FinNaturezaFinanceirasTableOrderingComposer
    extends OrderingComposer<_$AppDatabase, $FinNaturezaFinanceirasTable> {
  $$FinNaturezaFinanceirasTableOrderingComposer(super.$state);
  ColumnOrderings<int> get id => $state.composableBuilder(
      column: $state.table.id,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get codigo => $state.composableBuilder(
      column: $state.table.codigo,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get descricao => $state.composableBuilder(
      column: $state.table.descricao,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get tipo => $state.composableBuilder(
      column: $state.table.tipo,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get aplicacao => $state.composableBuilder(
      column: $state.table.aplicacao,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));
}

typedef $$AidfAimdfsTableCreateCompanionBuilder = AidfAimdfsCompanion Function({
  Value<int?> id,
  Value<int?> numero,
  Value<DateTime?> dataValidade,
  Value<DateTime?> dataAutorizacao,
  Value<String?> numeroAutorizacao,
  Value<String?> formularioDisponivel,
});
typedef $$AidfAimdfsTableUpdateCompanionBuilder = AidfAimdfsCompanion Function({
  Value<int?> id,
  Value<int?> numero,
  Value<DateTime?> dataValidade,
  Value<DateTime?> dataAutorizacao,
  Value<String?> numeroAutorizacao,
  Value<String?> formularioDisponivel,
});

class $$AidfAimdfsTableTableManager extends RootTableManager<
    _$AppDatabase,
    $AidfAimdfsTable,
    AidfAimdf,
    $$AidfAimdfsTableFilterComposer,
    $$AidfAimdfsTableOrderingComposer,
    $$AidfAimdfsTableCreateCompanionBuilder,
    $$AidfAimdfsTableUpdateCompanionBuilder> {
  $$AidfAimdfsTableTableManager(_$AppDatabase db, $AidfAimdfsTable table)
      : super(TableManagerState(
          db: db,
          table: table,
          filteringComposer:
              $$AidfAimdfsTableFilterComposer(ComposerState(db, table)),
          orderingComposer:
              $$AidfAimdfsTableOrderingComposer(ComposerState(db, table)),
          updateCompanionCallback: ({
            Value<int?> id = const Value.absent(),
            Value<int?> numero = const Value.absent(),
            Value<DateTime?> dataValidade = const Value.absent(),
            Value<DateTime?> dataAutorizacao = const Value.absent(),
            Value<String?> numeroAutorizacao = const Value.absent(),
            Value<String?> formularioDisponivel = const Value.absent(),
          }) =>
              AidfAimdfsCompanion(
            id: id,
            numero: numero,
            dataValidade: dataValidade,
            dataAutorizacao: dataAutorizacao,
            numeroAutorizacao: numeroAutorizacao,
            formularioDisponivel: formularioDisponivel,
          ),
          createCompanionCallback: ({
            Value<int?> id = const Value.absent(),
            Value<int?> numero = const Value.absent(),
            Value<DateTime?> dataValidade = const Value.absent(),
            Value<DateTime?> dataAutorizacao = const Value.absent(),
            Value<String?> numeroAutorizacao = const Value.absent(),
            Value<String?> formularioDisponivel = const Value.absent(),
          }) =>
              AidfAimdfsCompanion.insert(
            id: id,
            numero: numero,
            dataValidade: dataValidade,
            dataAutorizacao: dataAutorizacao,
            numeroAutorizacao: numeroAutorizacao,
            formularioDisponivel: formularioDisponivel,
          ),
        ));
}

class $$AidfAimdfsTableFilterComposer
    extends FilterComposer<_$AppDatabase, $AidfAimdfsTable> {
  $$AidfAimdfsTableFilterComposer(super.$state);
  ColumnFilters<int> get id => $state.composableBuilder(
      column: $state.table.id,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<int> get numero => $state.composableBuilder(
      column: $state.table.numero,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<DateTime> get dataValidade => $state.composableBuilder(
      column: $state.table.dataValidade,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<DateTime> get dataAutorizacao => $state.composableBuilder(
      column: $state.table.dataAutorizacao,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get numeroAutorizacao => $state.composableBuilder(
      column: $state.table.numeroAutorizacao,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get formularioDisponivel => $state.composableBuilder(
      column: $state.table.formularioDisponivel,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));
}

class $$AidfAimdfsTableOrderingComposer
    extends OrderingComposer<_$AppDatabase, $AidfAimdfsTable> {
  $$AidfAimdfsTableOrderingComposer(super.$state);
  ColumnOrderings<int> get id => $state.composableBuilder(
      column: $state.table.id,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<int> get numero => $state.composableBuilder(
      column: $state.table.numero,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<DateTime> get dataValidade => $state.composableBuilder(
      column: $state.table.dataValidade,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<DateTime> get dataAutorizacao => $state.composableBuilder(
      column: $state.table.dataAutorizacao,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get numeroAutorizacao => $state.composableBuilder(
      column: $state.table.numeroAutorizacao,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get formularioDisponivel => $state.composableBuilder(
      column: $state.table.formularioDisponivel,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));
}

typedef $$FapsTableCreateCompanionBuilder = FapsCompanion Function({
  Value<int?> id,
  Value<double?> fap,
  Value<DateTime?> dataInicial,
  Value<DateTime?> dataFinal,
});
typedef $$FapsTableUpdateCompanionBuilder = FapsCompanion Function({
  Value<int?> id,
  Value<double?> fap,
  Value<DateTime?> dataInicial,
  Value<DateTime?> dataFinal,
});

class $$FapsTableTableManager extends RootTableManager<
    _$AppDatabase,
    $FapsTable,
    Fap,
    $$FapsTableFilterComposer,
    $$FapsTableOrderingComposer,
    $$FapsTableCreateCompanionBuilder,
    $$FapsTableUpdateCompanionBuilder> {
  $$FapsTableTableManager(_$AppDatabase db, $FapsTable table)
      : super(TableManagerState(
          db: db,
          table: table,
          filteringComposer:
              $$FapsTableFilterComposer(ComposerState(db, table)),
          orderingComposer:
              $$FapsTableOrderingComposer(ComposerState(db, table)),
          updateCompanionCallback: ({
            Value<int?> id = const Value.absent(),
            Value<double?> fap = const Value.absent(),
            Value<DateTime?> dataInicial = const Value.absent(),
            Value<DateTime?> dataFinal = const Value.absent(),
          }) =>
              FapsCompanion(
            id: id,
            fap: fap,
            dataInicial: dataInicial,
            dataFinal: dataFinal,
          ),
          createCompanionCallback: ({
            Value<int?> id = const Value.absent(),
            Value<double?> fap = const Value.absent(),
            Value<DateTime?> dataInicial = const Value.absent(),
            Value<DateTime?> dataFinal = const Value.absent(),
          }) =>
              FapsCompanion.insert(
            id: id,
            fap: fap,
            dataInicial: dataInicial,
            dataFinal: dataFinal,
          ),
        ));
}

class $$FapsTableFilterComposer
    extends FilterComposer<_$AppDatabase, $FapsTable> {
  $$FapsTableFilterComposer(super.$state);
  ColumnFilters<int> get id => $state.composableBuilder(
      column: $state.table.id,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<double> get fap => $state.composableBuilder(
      column: $state.table.fap,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<DateTime> get dataInicial => $state.composableBuilder(
      column: $state.table.dataInicial,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<DateTime> get dataFinal => $state.composableBuilder(
      column: $state.table.dataFinal,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));
}

class $$FapsTableOrderingComposer
    extends OrderingComposer<_$AppDatabase, $FapsTable> {
  $$FapsTableOrderingComposer(super.$state);
  ColumnOrderings<int> get id => $state.composableBuilder(
      column: $state.table.id,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<double> get fap => $state.composableBuilder(
      column: $state.table.fap,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<DateTime> get dataInicial => $state.composableBuilder(
      column: $state.table.dataInicial,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<DateTime> get dataFinal => $state.composableBuilder(
      column: $state.table.dataFinal,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));
}

typedef $$RegistroCartoriosTableCreateCompanionBuilder
    = RegistroCartoriosCompanion Function({
  Value<int?> id,
  Value<String?> nomeCartorio,
  Value<DateTime?> dataRegistro,
  Value<int?> numero,
  Value<int?> folha,
  Value<int?> livro,
  Value<String?> nire,
});
typedef $$RegistroCartoriosTableUpdateCompanionBuilder
    = RegistroCartoriosCompanion Function({
  Value<int?> id,
  Value<String?> nomeCartorio,
  Value<DateTime?> dataRegistro,
  Value<int?> numero,
  Value<int?> folha,
  Value<int?> livro,
  Value<String?> nire,
});

class $$RegistroCartoriosTableTableManager extends RootTableManager<
    _$AppDatabase,
    $RegistroCartoriosTable,
    RegistroCartorio,
    $$RegistroCartoriosTableFilterComposer,
    $$RegistroCartoriosTableOrderingComposer,
    $$RegistroCartoriosTableCreateCompanionBuilder,
    $$RegistroCartoriosTableUpdateCompanionBuilder> {
  $$RegistroCartoriosTableTableManager(
      _$AppDatabase db, $RegistroCartoriosTable table)
      : super(TableManagerState(
          db: db,
          table: table,
          filteringComposer:
              $$RegistroCartoriosTableFilterComposer(ComposerState(db, table)),
          orderingComposer: $$RegistroCartoriosTableOrderingComposer(
              ComposerState(db, table)),
          updateCompanionCallback: ({
            Value<int?> id = const Value.absent(),
            Value<String?> nomeCartorio = const Value.absent(),
            Value<DateTime?> dataRegistro = const Value.absent(),
            Value<int?> numero = const Value.absent(),
            Value<int?> folha = const Value.absent(),
            Value<int?> livro = const Value.absent(),
            Value<String?> nire = const Value.absent(),
          }) =>
              RegistroCartoriosCompanion(
            id: id,
            nomeCartorio: nomeCartorio,
            dataRegistro: dataRegistro,
            numero: numero,
            folha: folha,
            livro: livro,
            nire: nire,
          ),
          createCompanionCallback: ({
            Value<int?> id = const Value.absent(),
            Value<String?> nomeCartorio = const Value.absent(),
            Value<DateTime?> dataRegistro = const Value.absent(),
            Value<int?> numero = const Value.absent(),
            Value<int?> folha = const Value.absent(),
            Value<int?> livro = const Value.absent(),
            Value<String?> nire = const Value.absent(),
          }) =>
              RegistroCartoriosCompanion.insert(
            id: id,
            nomeCartorio: nomeCartorio,
            dataRegistro: dataRegistro,
            numero: numero,
            folha: folha,
            livro: livro,
            nire: nire,
          ),
        ));
}

class $$RegistroCartoriosTableFilterComposer
    extends FilterComposer<_$AppDatabase, $RegistroCartoriosTable> {
  $$RegistroCartoriosTableFilterComposer(super.$state);
  ColumnFilters<int> get id => $state.composableBuilder(
      column: $state.table.id,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get nomeCartorio => $state.composableBuilder(
      column: $state.table.nomeCartorio,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<DateTime> get dataRegistro => $state.composableBuilder(
      column: $state.table.dataRegistro,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<int> get numero => $state.composableBuilder(
      column: $state.table.numero,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<int> get folha => $state.composableBuilder(
      column: $state.table.folha,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<int> get livro => $state.composableBuilder(
      column: $state.table.livro,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get nire => $state.composableBuilder(
      column: $state.table.nire,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));
}

class $$RegistroCartoriosTableOrderingComposer
    extends OrderingComposer<_$AppDatabase, $RegistroCartoriosTable> {
  $$RegistroCartoriosTableOrderingComposer(super.$state);
  ColumnOrderings<int> get id => $state.composableBuilder(
      column: $state.table.id,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get nomeCartorio => $state.composableBuilder(
      column: $state.table.nomeCartorio,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<DateTime> get dataRegistro => $state.composableBuilder(
      column: $state.table.dataRegistro,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<int> get numero => $state.composableBuilder(
      column: $state.table.numero,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<int> get folha => $state.composableBuilder(
      column: $state.table.folha,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<int> get livro => $state.composableBuilder(
      column: $state.table.livro,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get nire => $state.composableBuilder(
      column: $state.table.nire,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));
}

typedef $$ContabilParametrosTableCreateCompanionBuilder
    = ContabilParametrosCompanion Function({
  Value<int?> id,
  Value<String?> mascara,
  Value<int?> niveis,
  Value<String?> informarContaPor,
  Value<String?> compartilhaPlanoConta,
  Value<String?> compartilhaHistoricos,
  Value<String?> alteraLancamentoOutro,
  Value<String?> historicoObrigatorio,
  Value<String?> permiteLancamentoZerado,
  Value<String?> geraInformativoSped,
  Value<String?> spedFormaEscritDiario,
  Value<String?> spedNomeLivroDiario,
  Value<String?> assinaturaDireita,
  Value<String?> assinaturaEsquerda,
  Value<String?> contaAtivo,
  Value<String?> contaPassivo,
  Value<String?> contaPatrimonioLiquido,
  Value<String?> contaDepreciacaoAcumulada,
  Value<String?> contaCapitalSocial,
  Value<String?> contaResultadoExercicio,
  Value<String?> contaPrejuizoAcumulado,
  Value<String?> contaLucroAcumulado,
  Value<String?> contaTituloPagar,
  Value<String?> contaTituloReceber,
  Value<String?> contaJurosPassivo,
  Value<String?> contaJurosAtivo,
  Value<String?> contaDescontoObtido,
  Value<String?> contaDescontoConcedido,
  Value<String?> contaCmv,
  Value<String?> contaVenda,
  Value<String?> contaVendaServico,
  Value<String?> contaEstoque,
  Value<String?> contaApuraResultado,
  Value<String?> contaJurosApropriar,
  Value<int?> idHistPadraoResultado,
  Value<int?> idHistPadraoLucro,
  Value<int?> idHistPadraoPrejuizo,
});
typedef $$ContabilParametrosTableUpdateCompanionBuilder
    = ContabilParametrosCompanion Function({
  Value<int?> id,
  Value<String?> mascara,
  Value<int?> niveis,
  Value<String?> informarContaPor,
  Value<String?> compartilhaPlanoConta,
  Value<String?> compartilhaHistoricos,
  Value<String?> alteraLancamentoOutro,
  Value<String?> historicoObrigatorio,
  Value<String?> permiteLancamentoZerado,
  Value<String?> geraInformativoSped,
  Value<String?> spedFormaEscritDiario,
  Value<String?> spedNomeLivroDiario,
  Value<String?> assinaturaDireita,
  Value<String?> assinaturaEsquerda,
  Value<String?> contaAtivo,
  Value<String?> contaPassivo,
  Value<String?> contaPatrimonioLiquido,
  Value<String?> contaDepreciacaoAcumulada,
  Value<String?> contaCapitalSocial,
  Value<String?> contaResultadoExercicio,
  Value<String?> contaPrejuizoAcumulado,
  Value<String?> contaLucroAcumulado,
  Value<String?> contaTituloPagar,
  Value<String?> contaTituloReceber,
  Value<String?> contaJurosPassivo,
  Value<String?> contaJurosAtivo,
  Value<String?> contaDescontoObtido,
  Value<String?> contaDescontoConcedido,
  Value<String?> contaCmv,
  Value<String?> contaVenda,
  Value<String?> contaVendaServico,
  Value<String?> contaEstoque,
  Value<String?> contaApuraResultado,
  Value<String?> contaJurosApropriar,
  Value<int?> idHistPadraoResultado,
  Value<int?> idHistPadraoLucro,
  Value<int?> idHistPadraoPrejuizo,
});

class $$ContabilParametrosTableTableManager extends RootTableManager<
    _$AppDatabase,
    $ContabilParametrosTable,
    ContabilParametro,
    $$ContabilParametrosTableFilterComposer,
    $$ContabilParametrosTableOrderingComposer,
    $$ContabilParametrosTableCreateCompanionBuilder,
    $$ContabilParametrosTableUpdateCompanionBuilder> {
  $$ContabilParametrosTableTableManager(
      _$AppDatabase db, $ContabilParametrosTable table)
      : super(TableManagerState(
          db: db,
          table: table,
          filteringComposer:
              $$ContabilParametrosTableFilterComposer(ComposerState(db, table)),
          orderingComposer: $$ContabilParametrosTableOrderingComposer(
              ComposerState(db, table)),
          updateCompanionCallback: ({
            Value<int?> id = const Value.absent(),
            Value<String?> mascara = const Value.absent(),
            Value<int?> niveis = const Value.absent(),
            Value<String?> informarContaPor = const Value.absent(),
            Value<String?> compartilhaPlanoConta = const Value.absent(),
            Value<String?> compartilhaHistoricos = const Value.absent(),
            Value<String?> alteraLancamentoOutro = const Value.absent(),
            Value<String?> historicoObrigatorio = const Value.absent(),
            Value<String?> permiteLancamentoZerado = const Value.absent(),
            Value<String?> geraInformativoSped = const Value.absent(),
            Value<String?> spedFormaEscritDiario = const Value.absent(),
            Value<String?> spedNomeLivroDiario = const Value.absent(),
            Value<String?> assinaturaDireita = const Value.absent(),
            Value<String?> assinaturaEsquerda = const Value.absent(),
            Value<String?> contaAtivo = const Value.absent(),
            Value<String?> contaPassivo = const Value.absent(),
            Value<String?> contaPatrimonioLiquido = const Value.absent(),
            Value<String?> contaDepreciacaoAcumulada = const Value.absent(),
            Value<String?> contaCapitalSocial = const Value.absent(),
            Value<String?> contaResultadoExercicio = const Value.absent(),
            Value<String?> contaPrejuizoAcumulado = const Value.absent(),
            Value<String?> contaLucroAcumulado = const Value.absent(),
            Value<String?> contaTituloPagar = const Value.absent(),
            Value<String?> contaTituloReceber = const Value.absent(),
            Value<String?> contaJurosPassivo = const Value.absent(),
            Value<String?> contaJurosAtivo = const Value.absent(),
            Value<String?> contaDescontoObtido = const Value.absent(),
            Value<String?> contaDescontoConcedido = const Value.absent(),
            Value<String?> contaCmv = const Value.absent(),
            Value<String?> contaVenda = const Value.absent(),
            Value<String?> contaVendaServico = const Value.absent(),
            Value<String?> contaEstoque = const Value.absent(),
            Value<String?> contaApuraResultado = const Value.absent(),
            Value<String?> contaJurosApropriar = const Value.absent(),
            Value<int?> idHistPadraoResultado = const Value.absent(),
            Value<int?> idHistPadraoLucro = const Value.absent(),
            Value<int?> idHistPadraoPrejuizo = const Value.absent(),
          }) =>
              ContabilParametrosCompanion(
            id: id,
            mascara: mascara,
            niveis: niveis,
            informarContaPor: informarContaPor,
            compartilhaPlanoConta: compartilhaPlanoConta,
            compartilhaHistoricos: compartilhaHistoricos,
            alteraLancamentoOutro: alteraLancamentoOutro,
            historicoObrigatorio: historicoObrigatorio,
            permiteLancamentoZerado: permiteLancamentoZerado,
            geraInformativoSped: geraInformativoSped,
            spedFormaEscritDiario: spedFormaEscritDiario,
            spedNomeLivroDiario: spedNomeLivroDiario,
            assinaturaDireita: assinaturaDireita,
            assinaturaEsquerda: assinaturaEsquerda,
            contaAtivo: contaAtivo,
            contaPassivo: contaPassivo,
            contaPatrimonioLiquido: contaPatrimonioLiquido,
            contaDepreciacaoAcumulada: contaDepreciacaoAcumulada,
            contaCapitalSocial: contaCapitalSocial,
            contaResultadoExercicio: contaResultadoExercicio,
            contaPrejuizoAcumulado: contaPrejuizoAcumulado,
            contaLucroAcumulado: contaLucroAcumulado,
            contaTituloPagar: contaTituloPagar,
            contaTituloReceber: contaTituloReceber,
            contaJurosPassivo: contaJurosPassivo,
            contaJurosAtivo: contaJurosAtivo,
            contaDescontoObtido: contaDescontoObtido,
            contaDescontoConcedido: contaDescontoConcedido,
            contaCmv: contaCmv,
            contaVenda: contaVenda,
            contaVendaServico: contaVendaServico,
            contaEstoque: contaEstoque,
            contaApuraResultado: contaApuraResultado,
            contaJurosApropriar: contaJurosApropriar,
            idHistPadraoResultado: idHistPadraoResultado,
            idHistPadraoLucro: idHistPadraoLucro,
            idHistPadraoPrejuizo: idHistPadraoPrejuizo,
          ),
          createCompanionCallback: ({
            Value<int?> id = const Value.absent(),
            Value<String?> mascara = const Value.absent(),
            Value<int?> niveis = const Value.absent(),
            Value<String?> informarContaPor = const Value.absent(),
            Value<String?> compartilhaPlanoConta = const Value.absent(),
            Value<String?> compartilhaHistoricos = const Value.absent(),
            Value<String?> alteraLancamentoOutro = const Value.absent(),
            Value<String?> historicoObrigatorio = const Value.absent(),
            Value<String?> permiteLancamentoZerado = const Value.absent(),
            Value<String?> geraInformativoSped = const Value.absent(),
            Value<String?> spedFormaEscritDiario = const Value.absent(),
            Value<String?> spedNomeLivroDiario = const Value.absent(),
            Value<String?> assinaturaDireita = const Value.absent(),
            Value<String?> assinaturaEsquerda = const Value.absent(),
            Value<String?> contaAtivo = const Value.absent(),
            Value<String?> contaPassivo = const Value.absent(),
            Value<String?> contaPatrimonioLiquido = const Value.absent(),
            Value<String?> contaDepreciacaoAcumulada = const Value.absent(),
            Value<String?> contaCapitalSocial = const Value.absent(),
            Value<String?> contaResultadoExercicio = const Value.absent(),
            Value<String?> contaPrejuizoAcumulado = const Value.absent(),
            Value<String?> contaLucroAcumulado = const Value.absent(),
            Value<String?> contaTituloPagar = const Value.absent(),
            Value<String?> contaTituloReceber = const Value.absent(),
            Value<String?> contaJurosPassivo = const Value.absent(),
            Value<String?> contaJurosAtivo = const Value.absent(),
            Value<String?> contaDescontoObtido = const Value.absent(),
            Value<String?> contaDescontoConcedido = const Value.absent(),
            Value<String?> contaCmv = const Value.absent(),
            Value<String?> contaVenda = const Value.absent(),
            Value<String?> contaVendaServico = const Value.absent(),
            Value<String?> contaEstoque = const Value.absent(),
            Value<String?> contaApuraResultado = const Value.absent(),
            Value<String?> contaJurosApropriar = const Value.absent(),
            Value<int?> idHistPadraoResultado = const Value.absent(),
            Value<int?> idHistPadraoLucro = const Value.absent(),
            Value<int?> idHistPadraoPrejuizo = const Value.absent(),
          }) =>
              ContabilParametrosCompanion.insert(
            id: id,
            mascara: mascara,
            niveis: niveis,
            informarContaPor: informarContaPor,
            compartilhaPlanoConta: compartilhaPlanoConta,
            compartilhaHistoricos: compartilhaHistoricos,
            alteraLancamentoOutro: alteraLancamentoOutro,
            historicoObrigatorio: historicoObrigatorio,
            permiteLancamentoZerado: permiteLancamentoZerado,
            geraInformativoSped: geraInformativoSped,
            spedFormaEscritDiario: spedFormaEscritDiario,
            spedNomeLivroDiario: spedNomeLivroDiario,
            assinaturaDireita: assinaturaDireita,
            assinaturaEsquerda: assinaturaEsquerda,
            contaAtivo: contaAtivo,
            contaPassivo: contaPassivo,
            contaPatrimonioLiquido: contaPatrimonioLiquido,
            contaDepreciacaoAcumulada: contaDepreciacaoAcumulada,
            contaCapitalSocial: contaCapitalSocial,
            contaResultadoExercicio: contaResultadoExercicio,
            contaPrejuizoAcumulado: contaPrejuizoAcumulado,
            contaLucroAcumulado: contaLucroAcumulado,
            contaTituloPagar: contaTituloPagar,
            contaTituloReceber: contaTituloReceber,
            contaJurosPassivo: contaJurosPassivo,
            contaJurosAtivo: contaJurosAtivo,
            contaDescontoObtido: contaDescontoObtido,
            contaDescontoConcedido: contaDescontoConcedido,
            contaCmv: contaCmv,
            contaVenda: contaVenda,
            contaVendaServico: contaVendaServico,
            contaEstoque: contaEstoque,
            contaApuraResultado: contaApuraResultado,
            contaJurosApropriar: contaJurosApropriar,
            idHistPadraoResultado: idHistPadraoResultado,
            idHistPadraoLucro: idHistPadraoLucro,
            idHistPadraoPrejuizo: idHistPadraoPrejuizo,
          ),
        ));
}

class $$ContabilParametrosTableFilterComposer
    extends FilterComposer<_$AppDatabase, $ContabilParametrosTable> {
  $$ContabilParametrosTableFilterComposer(super.$state);
  ColumnFilters<int> get id => $state.composableBuilder(
      column: $state.table.id,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get mascara => $state.composableBuilder(
      column: $state.table.mascara,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<int> get niveis => $state.composableBuilder(
      column: $state.table.niveis,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get informarContaPor => $state.composableBuilder(
      column: $state.table.informarContaPor,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get compartilhaPlanoConta => $state.composableBuilder(
      column: $state.table.compartilhaPlanoConta,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get compartilhaHistoricos => $state.composableBuilder(
      column: $state.table.compartilhaHistoricos,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get alteraLancamentoOutro => $state.composableBuilder(
      column: $state.table.alteraLancamentoOutro,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get historicoObrigatorio => $state.composableBuilder(
      column: $state.table.historicoObrigatorio,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get permiteLancamentoZerado => $state.composableBuilder(
      column: $state.table.permiteLancamentoZerado,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get geraInformativoSped => $state.composableBuilder(
      column: $state.table.geraInformativoSped,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get spedFormaEscritDiario => $state.composableBuilder(
      column: $state.table.spedFormaEscritDiario,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get spedNomeLivroDiario => $state.composableBuilder(
      column: $state.table.spedNomeLivroDiario,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get assinaturaDireita => $state.composableBuilder(
      column: $state.table.assinaturaDireita,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get assinaturaEsquerda => $state.composableBuilder(
      column: $state.table.assinaturaEsquerda,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get contaAtivo => $state.composableBuilder(
      column: $state.table.contaAtivo,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get contaPassivo => $state.composableBuilder(
      column: $state.table.contaPassivo,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get contaPatrimonioLiquido => $state.composableBuilder(
      column: $state.table.contaPatrimonioLiquido,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get contaDepreciacaoAcumulada =>
      $state.composableBuilder(
          column: $state.table.contaDepreciacaoAcumulada,
          builder: (column, joinBuilders) =>
              ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get contaCapitalSocial => $state.composableBuilder(
      column: $state.table.contaCapitalSocial,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get contaResultadoExercicio => $state.composableBuilder(
      column: $state.table.contaResultadoExercicio,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get contaPrejuizoAcumulado => $state.composableBuilder(
      column: $state.table.contaPrejuizoAcumulado,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get contaLucroAcumulado => $state.composableBuilder(
      column: $state.table.contaLucroAcumulado,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get contaTituloPagar => $state.composableBuilder(
      column: $state.table.contaTituloPagar,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get contaTituloReceber => $state.composableBuilder(
      column: $state.table.contaTituloReceber,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get contaJurosPassivo => $state.composableBuilder(
      column: $state.table.contaJurosPassivo,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get contaJurosAtivo => $state.composableBuilder(
      column: $state.table.contaJurosAtivo,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get contaDescontoObtido => $state.composableBuilder(
      column: $state.table.contaDescontoObtido,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get contaDescontoConcedido => $state.composableBuilder(
      column: $state.table.contaDescontoConcedido,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get contaCmv => $state.composableBuilder(
      column: $state.table.contaCmv,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get contaVenda => $state.composableBuilder(
      column: $state.table.contaVenda,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get contaVendaServico => $state.composableBuilder(
      column: $state.table.contaVendaServico,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get contaEstoque => $state.composableBuilder(
      column: $state.table.contaEstoque,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get contaApuraResultado => $state.composableBuilder(
      column: $state.table.contaApuraResultado,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get contaJurosApropriar => $state.composableBuilder(
      column: $state.table.contaJurosApropriar,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<int> get idHistPadraoResultado => $state.composableBuilder(
      column: $state.table.idHistPadraoResultado,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<int> get idHistPadraoLucro => $state.composableBuilder(
      column: $state.table.idHistPadraoLucro,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<int> get idHistPadraoPrejuizo => $state.composableBuilder(
      column: $state.table.idHistPadraoPrejuizo,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));
}

class $$ContabilParametrosTableOrderingComposer
    extends OrderingComposer<_$AppDatabase, $ContabilParametrosTable> {
  $$ContabilParametrosTableOrderingComposer(super.$state);
  ColumnOrderings<int> get id => $state.composableBuilder(
      column: $state.table.id,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get mascara => $state.composableBuilder(
      column: $state.table.mascara,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<int> get niveis => $state.composableBuilder(
      column: $state.table.niveis,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get informarContaPor => $state.composableBuilder(
      column: $state.table.informarContaPor,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get compartilhaPlanoConta => $state.composableBuilder(
      column: $state.table.compartilhaPlanoConta,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get compartilhaHistoricos => $state.composableBuilder(
      column: $state.table.compartilhaHistoricos,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get alteraLancamentoOutro => $state.composableBuilder(
      column: $state.table.alteraLancamentoOutro,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get historicoObrigatorio => $state.composableBuilder(
      column: $state.table.historicoObrigatorio,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get permiteLancamentoZerado =>
      $state.composableBuilder(
          column: $state.table.permiteLancamentoZerado,
          builder: (column, joinBuilders) =>
              ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get geraInformativoSped => $state.composableBuilder(
      column: $state.table.geraInformativoSped,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get spedFormaEscritDiario => $state.composableBuilder(
      column: $state.table.spedFormaEscritDiario,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get spedNomeLivroDiario => $state.composableBuilder(
      column: $state.table.spedNomeLivroDiario,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get assinaturaDireita => $state.composableBuilder(
      column: $state.table.assinaturaDireita,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get assinaturaEsquerda => $state.composableBuilder(
      column: $state.table.assinaturaEsquerda,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get contaAtivo => $state.composableBuilder(
      column: $state.table.contaAtivo,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get contaPassivo => $state.composableBuilder(
      column: $state.table.contaPassivo,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get contaPatrimonioLiquido =>
      $state.composableBuilder(
          column: $state.table.contaPatrimonioLiquido,
          builder: (column, joinBuilders) =>
              ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get contaDepreciacaoAcumulada => $state
      .composableBuilder(
          column: $state.table.contaDepreciacaoAcumulada,
          builder: (column, joinBuilders) =>
              ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get contaCapitalSocial => $state.composableBuilder(
      column: $state.table.contaCapitalSocial,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get contaResultadoExercicio =>
      $state.composableBuilder(
          column: $state.table.contaResultadoExercicio,
          builder: (column, joinBuilders) =>
              ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get contaPrejuizoAcumulado =>
      $state.composableBuilder(
          column: $state.table.contaPrejuizoAcumulado,
          builder: (column, joinBuilders) =>
              ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get contaLucroAcumulado => $state.composableBuilder(
      column: $state.table.contaLucroAcumulado,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get contaTituloPagar => $state.composableBuilder(
      column: $state.table.contaTituloPagar,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get contaTituloReceber => $state.composableBuilder(
      column: $state.table.contaTituloReceber,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get contaJurosPassivo => $state.composableBuilder(
      column: $state.table.contaJurosPassivo,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get contaJurosAtivo => $state.composableBuilder(
      column: $state.table.contaJurosAtivo,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get contaDescontoObtido => $state.composableBuilder(
      column: $state.table.contaDescontoObtido,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get contaDescontoConcedido =>
      $state.composableBuilder(
          column: $state.table.contaDescontoConcedido,
          builder: (column, joinBuilders) =>
              ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get contaCmv => $state.composableBuilder(
      column: $state.table.contaCmv,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get contaVenda => $state.composableBuilder(
      column: $state.table.contaVenda,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get contaVendaServico => $state.composableBuilder(
      column: $state.table.contaVendaServico,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get contaEstoque => $state.composableBuilder(
      column: $state.table.contaEstoque,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get contaApuraResultado => $state.composableBuilder(
      column: $state.table.contaApuraResultado,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get contaJurosApropriar => $state.composableBuilder(
      column: $state.table.contaJurosApropriar,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<int> get idHistPadraoResultado => $state.composableBuilder(
      column: $state.table.idHistPadraoResultado,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<int> get idHistPadraoLucro => $state.composableBuilder(
      column: $state.table.idHistPadraoLucro,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<int> get idHistPadraoPrejuizo => $state.composableBuilder(
      column: $state.table.idHistPadraoPrejuizo,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));
}

typedef $$PlanoContaRefSpedsTableCreateCompanionBuilder
    = PlanoContaRefSpedsCompanion Function({
  Value<int?> id,
  Value<String?> codCtaRef,
  Value<DateTime?> inicioValidade,
  Value<DateTime?> fimValidade,
  Value<String?> tipo,
  Value<String?> descricao,
  Value<String?> orientacoes,
});
typedef $$PlanoContaRefSpedsTableUpdateCompanionBuilder
    = PlanoContaRefSpedsCompanion Function({
  Value<int?> id,
  Value<String?> codCtaRef,
  Value<DateTime?> inicioValidade,
  Value<DateTime?> fimValidade,
  Value<String?> tipo,
  Value<String?> descricao,
  Value<String?> orientacoes,
});

class $$PlanoContaRefSpedsTableTableManager extends RootTableManager<
    _$AppDatabase,
    $PlanoContaRefSpedsTable,
    PlanoContaRefSped,
    $$PlanoContaRefSpedsTableFilterComposer,
    $$PlanoContaRefSpedsTableOrderingComposer,
    $$PlanoContaRefSpedsTableCreateCompanionBuilder,
    $$PlanoContaRefSpedsTableUpdateCompanionBuilder> {
  $$PlanoContaRefSpedsTableTableManager(
      _$AppDatabase db, $PlanoContaRefSpedsTable table)
      : super(TableManagerState(
          db: db,
          table: table,
          filteringComposer:
              $$PlanoContaRefSpedsTableFilterComposer(ComposerState(db, table)),
          orderingComposer: $$PlanoContaRefSpedsTableOrderingComposer(
              ComposerState(db, table)),
          updateCompanionCallback: ({
            Value<int?> id = const Value.absent(),
            Value<String?> codCtaRef = const Value.absent(),
            Value<DateTime?> inicioValidade = const Value.absent(),
            Value<DateTime?> fimValidade = const Value.absent(),
            Value<String?> tipo = const Value.absent(),
            Value<String?> descricao = const Value.absent(),
            Value<String?> orientacoes = const Value.absent(),
          }) =>
              PlanoContaRefSpedsCompanion(
            id: id,
            codCtaRef: codCtaRef,
            inicioValidade: inicioValidade,
            fimValidade: fimValidade,
            tipo: tipo,
            descricao: descricao,
            orientacoes: orientacoes,
          ),
          createCompanionCallback: ({
            Value<int?> id = const Value.absent(),
            Value<String?> codCtaRef = const Value.absent(),
            Value<DateTime?> inicioValidade = const Value.absent(),
            Value<DateTime?> fimValidade = const Value.absent(),
            Value<String?> tipo = const Value.absent(),
            Value<String?> descricao = const Value.absent(),
            Value<String?> orientacoes = const Value.absent(),
          }) =>
              PlanoContaRefSpedsCompanion.insert(
            id: id,
            codCtaRef: codCtaRef,
            inicioValidade: inicioValidade,
            fimValidade: fimValidade,
            tipo: tipo,
            descricao: descricao,
            orientacoes: orientacoes,
          ),
        ));
}

class $$PlanoContaRefSpedsTableFilterComposer
    extends FilterComposer<_$AppDatabase, $PlanoContaRefSpedsTable> {
  $$PlanoContaRefSpedsTableFilterComposer(super.$state);
  ColumnFilters<int> get id => $state.composableBuilder(
      column: $state.table.id,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get codCtaRef => $state.composableBuilder(
      column: $state.table.codCtaRef,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<DateTime> get inicioValidade => $state.composableBuilder(
      column: $state.table.inicioValidade,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<DateTime> get fimValidade => $state.composableBuilder(
      column: $state.table.fimValidade,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get tipo => $state.composableBuilder(
      column: $state.table.tipo,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get descricao => $state.composableBuilder(
      column: $state.table.descricao,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get orientacoes => $state.composableBuilder(
      column: $state.table.orientacoes,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));
}

class $$PlanoContaRefSpedsTableOrderingComposer
    extends OrderingComposer<_$AppDatabase, $PlanoContaRefSpedsTable> {
  $$PlanoContaRefSpedsTableOrderingComposer(super.$state);
  ColumnOrderings<int> get id => $state.composableBuilder(
      column: $state.table.id,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get codCtaRef => $state.composableBuilder(
      column: $state.table.codCtaRef,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<DateTime> get inicioValidade => $state.composableBuilder(
      column: $state.table.inicioValidade,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<DateTime> get fimValidade => $state.composableBuilder(
      column: $state.table.fimValidade,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get tipo => $state.composableBuilder(
      column: $state.table.tipo,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get descricao => $state.composableBuilder(
      column: $state.table.descricao,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get orientacoes => $state.composableBuilder(
      column: $state.table.orientacoes,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));
}

typedef $$PlanoContasTableCreateCompanionBuilder = PlanoContasCompanion
    Function({
  Value<int?> id,
  Value<String?> nome,
  Value<DateTime?> dataInclusao,
  Value<String?> mascara,
  Value<int?> niveis,
});
typedef $$PlanoContasTableUpdateCompanionBuilder = PlanoContasCompanion
    Function({
  Value<int?> id,
  Value<String?> nome,
  Value<DateTime?> dataInclusao,
  Value<String?> mascara,
  Value<int?> niveis,
});

class $$PlanoContasTableTableManager extends RootTableManager<
    _$AppDatabase,
    $PlanoContasTable,
    PlanoConta,
    $$PlanoContasTableFilterComposer,
    $$PlanoContasTableOrderingComposer,
    $$PlanoContasTableCreateCompanionBuilder,
    $$PlanoContasTableUpdateCompanionBuilder> {
  $$PlanoContasTableTableManager(_$AppDatabase db, $PlanoContasTable table)
      : super(TableManagerState(
          db: db,
          table: table,
          filteringComposer:
              $$PlanoContasTableFilterComposer(ComposerState(db, table)),
          orderingComposer:
              $$PlanoContasTableOrderingComposer(ComposerState(db, table)),
          updateCompanionCallback: ({
            Value<int?> id = const Value.absent(),
            Value<String?> nome = const Value.absent(),
            Value<DateTime?> dataInclusao = const Value.absent(),
            Value<String?> mascara = const Value.absent(),
            Value<int?> niveis = const Value.absent(),
          }) =>
              PlanoContasCompanion(
            id: id,
            nome: nome,
            dataInclusao: dataInclusao,
            mascara: mascara,
            niveis: niveis,
          ),
          createCompanionCallback: ({
            Value<int?> id = const Value.absent(),
            Value<String?> nome = const Value.absent(),
            Value<DateTime?> dataInclusao = const Value.absent(),
            Value<String?> mascara = const Value.absent(),
            Value<int?> niveis = const Value.absent(),
          }) =>
              PlanoContasCompanion.insert(
            id: id,
            nome: nome,
            dataInclusao: dataInclusao,
            mascara: mascara,
            niveis: niveis,
          ),
        ));
}

class $$PlanoContasTableFilterComposer
    extends FilterComposer<_$AppDatabase, $PlanoContasTable> {
  $$PlanoContasTableFilterComposer(super.$state);
  ColumnFilters<int> get id => $state.composableBuilder(
      column: $state.table.id,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get nome => $state.composableBuilder(
      column: $state.table.nome,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<DateTime> get dataInclusao => $state.composableBuilder(
      column: $state.table.dataInclusao,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get mascara => $state.composableBuilder(
      column: $state.table.mascara,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<int> get niveis => $state.composableBuilder(
      column: $state.table.niveis,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));
}

class $$PlanoContasTableOrderingComposer
    extends OrderingComposer<_$AppDatabase, $PlanoContasTable> {
  $$PlanoContasTableOrderingComposer(super.$state);
  ColumnOrderings<int> get id => $state.composableBuilder(
      column: $state.table.id,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get nome => $state.composableBuilder(
      column: $state.table.nome,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<DateTime> get dataInclusao => $state.composableBuilder(
      column: $state.table.dataInclusao,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get mascara => $state.composableBuilder(
      column: $state.table.mascara,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<int> get niveis => $state.composableBuilder(
      column: $state.table.niveis,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));
}

typedef $$ContabilContasTableCreateCompanionBuilder = ContabilContasCompanion
    Function({
  Value<int?> id,
  Value<int?> idPlanoConta,
  Value<int?> idPlanoContaRefSped,
  Value<int?> idContabilConta,
  Value<String?> classificacao,
  Value<String?> tipo,
  Value<String?> descricao,
  Value<DateTime?> dataInclusao,
  Value<String?> situacao,
  Value<String?> natureza,
  Value<String?> patrimonioResultado,
  Value<String?> livroCaixa,
  Value<String?> dfc,
  Value<String?> codigoEfd,
  Value<String?> ordem,
  Value<String?> codigoReduzido,
});
typedef $$ContabilContasTableUpdateCompanionBuilder = ContabilContasCompanion
    Function({
  Value<int?> id,
  Value<int?> idPlanoConta,
  Value<int?> idPlanoContaRefSped,
  Value<int?> idContabilConta,
  Value<String?> classificacao,
  Value<String?> tipo,
  Value<String?> descricao,
  Value<DateTime?> dataInclusao,
  Value<String?> situacao,
  Value<String?> natureza,
  Value<String?> patrimonioResultado,
  Value<String?> livroCaixa,
  Value<String?> dfc,
  Value<String?> codigoEfd,
  Value<String?> ordem,
  Value<String?> codigoReduzido,
});

class $$ContabilContasTableTableManager extends RootTableManager<
    _$AppDatabase,
    $ContabilContasTable,
    ContabilConta,
    $$ContabilContasTableFilterComposer,
    $$ContabilContasTableOrderingComposer,
    $$ContabilContasTableCreateCompanionBuilder,
    $$ContabilContasTableUpdateCompanionBuilder> {
  $$ContabilContasTableTableManager(
      _$AppDatabase db, $ContabilContasTable table)
      : super(TableManagerState(
          db: db,
          table: table,
          filteringComposer:
              $$ContabilContasTableFilterComposer(ComposerState(db, table)),
          orderingComposer:
              $$ContabilContasTableOrderingComposer(ComposerState(db, table)),
          updateCompanionCallback: ({
            Value<int?> id = const Value.absent(),
            Value<int?> idPlanoConta = const Value.absent(),
            Value<int?> idPlanoContaRefSped = const Value.absent(),
            Value<int?> idContabilConta = const Value.absent(),
            Value<String?> classificacao = const Value.absent(),
            Value<String?> tipo = const Value.absent(),
            Value<String?> descricao = const Value.absent(),
            Value<DateTime?> dataInclusao = const Value.absent(),
            Value<String?> situacao = const Value.absent(),
            Value<String?> natureza = const Value.absent(),
            Value<String?> patrimonioResultado = const Value.absent(),
            Value<String?> livroCaixa = const Value.absent(),
            Value<String?> dfc = const Value.absent(),
            Value<String?> codigoEfd = const Value.absent(),
            Value<String?> ordem = const Value.absent(),
            Value<String?> codigoReduzido = const Value.absent(),
          }) =>
              ContabilContasCompanion(
            id: id,
            idPlanoConta: idPlanoConta,
            idPlanoContaRefSped: idPlanoContaRefSped,
            idContabilConta: idContabilConta,
            classificacao: classificacao,
            tipo: tipo,
            descricao: descricao,
            dataInclusao: dataInclusao,
            situacao: situacao,
            natureza: natureza,
            patrimonioResultado: patrimonioResultado,
            livroCaixa: livroCaixa,
            dfc: dfc,
            codigoEfd: codigoEfd,
            ordem: ordem,
            codigoReduzido: codigoReduzido,
          ),
          createCompanionCallback: ({
            Value<int?> id = const Value.absent(),
            Value<int?> idPlanoConta = const Value.absent(),
            Value<int?> idPlanoContaRefSped = const Value.absent(),
            Value<int?> idContabilConta = const Value.absent(),
            Value<String?> classificacao = const Value.absent(),
            Value<String?> tipo = const Value.absent(),
            Value<String?> descricao = const Value.absent(),
            Value<DateTime?> dataInclusao = const Value.absent(),
            Value<String?> situacao = const Value.absent(),
            Value<String?> natureza = const Value.absent(),
            Value<String?> patrimonioResultado = const Value.absent(),
            Value<String?> livroCaixa = const Value.absent(),
            Value<String?> dfc = const Value.absent(),
            Value<String?> codigoEfd = const Value.absent(),
            Value<String?> ordem = const Value.absent(),
            Value<String?> codigoReduzido = const Value.absent(),
          }) =>
              ContabilContasCompanion.insert(
            id: id,
            idPlanoConta: idPlanoConta,
            idPlanoContaRefSped: idPlanoContaRefSped,
            idContabilConta: idContabilConta,
            classificacao: classificacao,
            tipo: tipo,
            descricao: descricao,
            dataInclusao: dataInclusao,
            situacao: situacao,
            natureza: natureza,
            patrimonioResultado: patrimonioResultado,
            livroCaixa: livroCaixa,
            dfc: dfc,
            codigoEfd: codigoEfd,
            ordem: ordem,
            codigoReduzido: codigoReduzido,
          ),
        ));
}

class $$ContabilContasTableFilterComposer
    extends FilterComposer<_$AppDatabase, $ContabilContasTable> {
  $$ContabilContasTableFilterComposer(super.$state);
  ColumnFilters<int> get id => $state.composableBuilder(
      column: $state.table.id,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<int> get idPlanoConta => $state.composableBuilder(
      column: $state.table.idPlanoConta,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<int> get idPlanoContaRefSped => $state.composableBuilder(
      column: $state.table.idPlanoContaRefSped,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<int> get idContabilConta => $state.composableBuilder(
      column: $state.table.idContabilConta,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get classificacao => $state.composableBuilder(
      column: $state.table.classificacao,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get tipo => $state.composableBuilder(
      column: $state.table.tipo,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get descricao => $state.composableBuilder(
      column: $state.table.descricao,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<DateTime> get dataInclusao => $state.composableBuilder(
      column: $state.table.dataInclusao,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get situacao => $state.composableBuilder(
      column: $state.table.situacao,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get natureza => $state.composableBuilder(
      column: $state.table.natureza,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get patrimonioResultado => $state.composableBuilder(
      column: $state.table.patrimonioResultado,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get livroCaixa => $state.composableBuilder(
      column: $state.table.livroCaixa,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get dfc => $state.composableBuilder(
      column: $state.table.dfc,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get codigoEfd => $state.composableBuilder(
      column: $state.table.codigoEfd,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get ordem => $state.composableBuilder(
      column: $state.table.ordem,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get codigoReduzido => $state.composableBuilder(
      column: $state.table.codigoReduzido,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));
}

class $$ContabilContasTableOrderingComposer
    extends OrderingComposer<_$AppDatabase, $ContabilContasTable> {
  $$ContabilContasTableOrderingComposer(super.$state);
  ColumnOrderings<int> get id => $state.composableBuilder(
      column: $state.table.id,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<int> get idPlanoConta => $state.composableBuilder(
      column: $state.table.idPlanoConta,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<int> get idPlanoContaRefSped => $state.composableBuilder(
      column: $state.table.idPlanoContaRefSped,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<int> get idContabilConta => $state.composableBuilder(
      column: $state.table.idContabilConta,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get classificacao => $state.composableBuilder(
      column: $state.table.classificacao,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get tipo => $state.composableBuilder(
      column: $state.table.tipo,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get descricao => $state.composableBuilder(
      column: $state.table.descricao,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<DateTime> get dataInclusao => $state.composableBuilder(
      column: $state.table.dataInclusao,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get situacao => $state.composableBuilder(
      column: $state.table.situacao,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get natureza => $state.composableBuilder(
      column: $state.table.natureza,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get patrimonioResultado => $state.composableBuilder(
      column: $state.table.patrimonioResultado,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get livroCaixa => $state.composableBuilder(
      column: $state.table.livroCaixa,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get dfc => $state.composableBuilder(
      column: $state.table.dfc,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get codigoEfd => $state.composableBuilder(
      column: $state.table.codigoEfd,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get ordem => $state.composableBuilder(
      column: $state.table.ordem,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get codigoReduzido => $state.composableBuilder(
      column: $state.table.codigoReduzido,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));
}

typedef $$ContabilHistoricosTableCreateCompanionBuilder
    = ContabilHistoricosCompanion Function({
  Value<int?> id,
  Value<String?> descricao,
  Value<String?> pedeComplemento,
  Value<String?> historico,
});
typedef $$ContabilHistoricosTableUpdateCompanionBuilder
    = ContabilHistoricosCompanion Function({
  Value<int?> id,
  Value<String?> descricao,
  Value<String?> pedeComplemento,
  Value<String?> historico,
});

class $$ContabilHistoricosTableTableManager extends RootTableManager<
    _$AppDatabase,
    $ContabilHistoricosTable,
    ContabilHistorico,
    $$ContabilHistoricosTableFilterComposer,
    $$ContabilHistoricosTableOrderingComposer,
    $$ContabilHistoricosTableCreateCompanionBuilder,
    $$ContabilHistoricosTableUpdateCompanionBuilder> {
  $$ContabilHistoricosTableTableManager(
      _$AppDatabase db, $ContabilHistoricosTable table)
      : super(TableManagerState(
          db: db,
          table: table,
          filteringComposer:
              $$ContabilHistoricosTableFilterComposer(ComposerState(db, table)),
          orderingComposer: $$ContabilHistoricosTableOrderingComposer(
              ComposerState(db, table)),
          updateCompanionCallback: ({
            Value<int?> id = const Value.absent(),
            Value<String?> descricao = const Value.absent(),
            Value<String?> pedeComplemento = const Value.absent(),
            Value<String?> historico = const Value.absent(),
          }) =>
              ContabilHistoricosCompanion(
            id: id,
            descricao: descricao,
            pedeComplemento: pedeComplemento,
            historico: historico,
          ),
          createCompanionCallback: ({
            Value<int?> id = const Value.absent(),
            Value<String?> descricao = const Value.absent(),
            Value<String?> pedeComplemento = const Value.absent(),
            Value<String?> historico = const Value.absent(),
          }) =>
              ContabilHistoricosCompanion.insert(
            id: id,
            descricao: descricao,
            pedeComplemento: pedeComplemento,
            historico: historico,
          ),
        ));
}

class $$ContabilHistoricosTableFilterComposer
    extends FilterComposer<_$AppDatabase, $ContabilHistoricosTable> {
  $$ContabilHistoricosTableFilterComposer(super.$state);
  ColumnFilters<int> get id => $state.composableBuilder(
      column: $state.table.id,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get descricao => $state.composableBuilder(
      column: $state.table.descricao,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get pedeComplemento => $state.composableBuilder(
      column: $state.table.pedeComplemento,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get historico => $state.composableBuilder(
      column: $state.table.historico,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));
}

class $$ContabilHistoricosTableOrderingComposer
    extends OrderingComposer<_$AppDatabase, $ContabilHistoricosTable> {
  $$ContabilHistoricosTableOrderingComposer(super.$state);
  ColumnOrderings<int> get id => $state.composableBuilder(
      column: $state.table.id,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get descricao => $state.composableBuilder(
      column: $state.table.descricao,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get pedeComplemento => $state.composableBuilder(
      column: $state.table.pedeComplemento,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get historico => $state.composableBuilder(
      column: $state.table.historico,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));
}

typedef $$ContabilLancamentoPadraosTableCreateCompanionBuilder
    = ContabilLancamentoPadraosCompanion Function({
  Value<int?> id,
  Value<String?> descricao,
  Value<String?> historico,
  Value<int?> idContaDebito,
  Value<int?> idContaCredito,
});
typedef $$ContabilLancamentoPadraosTableUpdateCompanionBuilder
    = ContabilLancamentoPadraosCompanion Function({
  Value<int?> id,
  Value<String?> descricao,
  Value<String?> historico,
  Value<int?> idContaDebito,
  Value<int?> idContaCredito,
});

class $$ContabilLancamentoPadraosTableTableManager extends RootTableManager<
    _$AppDatabase,
    $ContabilLancamentoPadraosTable,
    ContabilLancamentoPadrao,
    $$ContabilLancamentoPadraosTableFilterComposer,
    $$ContabilLancamentoPadraosTableOrderingComposer,
    $$ContabilLancamentoPadraosTableCreateCompanionBuilder,
    $$ContabilLancamentoPadraosTableUpdateCompanionBuilder> {
  $$ContabilLancamentoPadraosTableTableManager(
      _$AppDatabase db, $ContabilLancamentoPadraosTable table)
      : super(TableManagerState(
          db: db,
          table: table,
          filteringComposer: $$ContabilLancamentoPadraosTableFilterComposer(
              ComposerState(db, table)),
          orderingComposer: $$ContabilLancamentoPadraosTableOrderingComposer(
              ComposerState(db, table)),
          updateCompanionCallback: ({
            Value<int?> id = const Value.absent(),
            Value<String?> descricao = const Value.absent(),
            Value<String?> historico = const Value.absent(),
            Value<int?> idContaDebito = const Value.absent(),
            Value<int?> idContaCredito = const Value.absent(),
          }) =>
              ContabilLancamentoPadraosCompanion(
            id: id,
            descricao: descricao,
            historico: historico,
            idContaDebito: idContaDebito,
            idContaCredito: idContaCredito,
          ),
          createCompanionCallback: ({
            Value<int?> id = const Value.absent(),
            Value<String?> descricao = const Value.absent(),
            Value<String?> historico = const Value.absent(),
            Value<int?> idContaDebito = const Value.absent(),
            Value<int?> idContaCredito = const Value.absent(),
          }) =>
              ContabilLancamentoPadraosCompanion.insert(
            id: id,
            descricao: descricao,
            historico: historico,
            idContaDebito: idContaDebito,
            idContaCredito: idContaCredito,
          ),
        ));
}

class $$ContabilLancamentoPadraosTableFilterComposer
    extends FilterComposer<_$AppDatabase, $ContabilLancamentoPadraosTable> {
  $$ContabilLancamentoPadraosTableFilterComposer(super.$state);
  ColumnFilters<int> get id => $state.composableBuilder(
      column: $state.table.id,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get descricao => $state.composableBuilder(
      column: $state.table.descricao,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get historico => $state.composableBuilder(
      column: $state.table.historico,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<int> get idContaDebito => $state.composableBuilder(
      column: $state.table.idContaDebito,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<int> get idContaCredito => $state.composableBuilder(
      column: $state.table.idContaCredito,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));
}

class $$ContabilLancamentoPadraosTableOrderingComposer
    extends OrderingComposer<_$AppDatabase, $ContabilLancamentoPadraosTable> {
  $$ContabilLancamentoPadraosTableOrderingComposer(super.$state);
  ColumnOrderings<int> get id => $state.composableBuilder(
      column: $state.table.id,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get descricao => $state.composableBuilder(
      column: $state.table.descricao,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get historico => $state.composableBuilder(
      column: $state.table.historico,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<int> get idContaDebito => $state.composableBuilder(
      column: $state.table.idContaDebito,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<int> get idContaCredito => $state.composableBuilder(
      column: $state.table.idContaCredito,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));
}

typedef $$ContabilLotesTableCreateCompanionBuilder = ContabilLotesCompanion
    Function({
  Value<int?> id,
  Value<String?> descricao,
  Value<DateTime?> dataInclusao,
  Value<DateTime?> dataLiberacao,
  Value<String?> liberado,
  Value<String?> programado,
  Value<double?> valor,
});
typedef $$ContabilLotesTableUpdateCompanionBuilder = ContabilLotesCompanion
    Function({
  Value<int?> id,
  Value<String?> descricao,
  Value<DateTime?> dataInclusao,
  Value<DateTime?> dataLiberacao,
  Value<String?> liberado,
  Value<String?> programado,
  Value<double?> valor,
});

class $$ContabilLotesTableTableManager extends RootTableManager<
    _$AppDatabase,
    $ContabilLotesTable,
    ContabilLote,
    $$ContabilLotesTableFilterComposer,
    $$ContabilLotesTableOrderingComposer,
    $$ContabilLotesTableCreateCompanionBuilder,
    $$ContabilLotesTableUpdateCompanionBuilder> {
  $$ContabilLotesTableTableManager(_$AppDatabase db, $ContabilLotesTable table)
      : super(TableManagerState(
          db: db,
          table: table,
          filteringComposer:
              $$ContabilLotesTableFilterComposer(ComposerState(db, table)),
          orderingComposer:
              $$ContabilLotesTableOrderingComposer(ComposerState(db, table)),
          updateCompanionCallback: ({
            Value<int?> id = const Value.absent(),
            Value<String?> descricao = const Value.absent(),
            Value<DateTime?> dataInclusao = const Value.absent(),
            Value<DateTime?> dataLiberacao = const Value.absent(),
            Value<String?> liberado = const Value.absent(),
            Value<String?> programado = const Value.absent(),
            Value<double?> valor = const Value.absent(),
          }) =>
              ContabilLotesCompanion(
            id: id,
            descricao: descricao,
            dataInclusao: dataInclusao,
            dataLiberacao: dataLiberacao,
            liberado: liberado,
            programado: programado,
            valor: valor,
          ),
          createCompanionCallback: ({
            Value<int?> id = const Value.absent(),
            Value<String?> descricao = const Value.absent(),
            Value<DateTime?> dataInclusao = const Value.absent(),
            Value<DateTime?> dataLiberacao = const Value.absent(),
            Value<String?> liberado = const Value.absent(),
            Value<String?> programado = const Value.absent(),
            Value<double?> valor = const Value.absent(),
          }) =>
              ContabilLotesCompanion.insert(
            id: id,
            descricao: descricao,
            dataInclusao: dataInclusao,
            dataLiberacao: dataLiberacao,
            liberado: liberado,
            programado: programado,
            valor: valor,
          ),
        ));
}

class $$ContabilLotesTableFilterComposer
    extends FilterComposer<_$AppDatabase, $ContabilLotesTable> {
  $$ContabilLotesTableFilterComposer(super.$state);
  ColumnFilters<int> get id => $state.composableBuilder(
      column: $state.table.id,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get descricao => $state.composableBuilder(
      column: $state.table.descricao,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<DateTime> get dataInclusao => $state.composableBuilder(
      column: $state.table.dataInclusao,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<DateTime> get dataLiberacao => $state.composableBuilder(
      column: $state.table.dataLiberacao,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get liberado => $state.composableBuilder(
      column: $state.table.liberado,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get programado => $state.composableBuilder(
      column: $state.table.programado,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<double> get valor => $state.composableBuilder(
      column: $state.table.valor,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));
}

class $$ContabilLotesTableOrderingComposer
    extends OrderingComposer<_$AppDatabase, $ContabilLotesTable> {
  $$ContabilLotesTableOrderingComposer(super.$state);
  ColumnOrderings<int> get id => $state.composableBuilder(
      column: $state.table.id,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get descricao => $state.composableBuilder(
      column: $state.table.descricao,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<DateTime> get dataInclusao => $state.composableBuilder(
      column: $state.table.dataInclusao,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<DateTime> get dataLiberacao => $state.composableBuilder(
      column: $state.table.dataLiberacao,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get liberado => $state.composableBuilder(
      column: $state.table.liberado,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get programado => $state.composableBuilder(
      column: $state.table.programado,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<double> get valor => $state.composableBuilder(
      column: $state.table.valor,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));
}

typedef $$ContabilLancamentoOrcadosTableCreateCompanionBuilder
    = ContabilLancamentoOrcadosCompanion Function({
  Value<int?> id,
  Value<int?> idContabilConta,
  Value<String?> ano,
  Value<double?> janeiro,
  Value<double?> fevereiro,
  Value<double?> marco,
  Value<double?> abril,
  Value<double?> maio,
  Value<double?> junho,
  Value<double?> julho,
  Value<double?> agosto,
  Value<double?> setembro,
  Value<double?> outubro,
  Value<double?> novembro,
  Value<double?> dezembro,
});
typedef $$ContabilLancamentoOrcadosTableUpdateCompanionBuilder
    = ContabilLancamentoOrcadosCompanion Function({
  Value<int?> id,
  Value<int?> idContabilConta,
  Value<String?> ano,
  Value<double?> janeiro,
  Value<double?> fevereiro,
  Value<double?> marco,
  Value<double?> abril,
  Value<double?> maio,
  Value<double?> junho,
  Value<double?> julho,
  Value<double?> agosto,
  Value<double?> setembro,
  Value<double?> outubro,
  Value<double?> novembro,
  Value<double?> dezembro,
});

class $$ContabilLancamentoOrcadosTableTableManager extends RootTableManager<
    _$AppDatabase,
    $ContabilLancamentoOrcadosTable,
    ContabilLancamentoOrcado,
    $$ContabilLancamentoOrcadosTableFilterComposer,
    $$ContabilLancamentoOrcadosTableOrderingComposer,
    $$ContabilLancamentoOrcadosTableCreateCompanionBuilder,
    $$ContabilLancamentoOrcadosTableUpdateCompanionBuilder> {
  $$ContabilLancamentoOrcadosTableTableManager(
      _$AppDatabase db, $ContabilLancamentoOrcadosTable table)
      : super(TableManagerState(
          db: db,
          table: table,
          filteringComposer: $$ContabilLancamentoOrcadosTableFilterComposer(
              ComposerState(db, table)),
          orderingComposer: $$ContabilLancamentoOrcadosTableOrderingComposer(
              ComposerState(db, table)),
          updateCompanionCallback: ({
            Value<int?> id = const Value.absent(),
            Value<int?> idContabilConta = const Value.absent(),
            Value<String?> ano = const Value.absent(),
            Value<double?> janeiro = const Value.absent(),
            Value<double?> fevereiro = const Value.absent(),
            Value<double?> marco = const Value.absent(),
            Value<double?> abril = const Value.absent(),
            Value<double?> maio = const Value.absent(),
            Value<double?> junho = const Value.absent(),
            Value<double?> julho = const Value.absent(),
            Value<double?> agosto = const Value.absent(),
            Value<double?> setembro = const Value.absent(),
            Value<double?> outubro = const Value.absent(),
            Value<double?> novembro = const Value.absent(),
            Value<double?> dezembro = const Value.absent(),
          }) =>
              ContabilLancamentoOrcadosCompanion(
            id: id,
            idContabilConta: idContabilConta,
            ano: ano,
            janeiro: janeiro,
            fevereiro: fevereiro,
            marco: marco,
            abril: abril,
            maio: maio,
            junho: junho,
            julho: julho,
            agosto: agosto,
            setembro: setembro,
            outubro: outubro,
            novembro: novembro,
            dezembro: dezembro,
          ),
          createCompanionCallback: ({
            Value<int?> id = const Value.absent(),
            Value<int?> idContabilConta = const Value.absent(),
            Value<String?> ano = const Value.absent(),
            Value<double?> janeiro = const Value.absent(),
            Value<double?> fevereiro = const Value.absent(),
            Value<double?> marco = const Value.absent(),
            Value<double?> abril = const Value.absent(),
            Value<double?> maio = const Value.absent(),
            Value<double?> junho = const Value.absent(),
            Value<double?> julho = const Value.absent(),
            Value<double?> agosto = const Value.absent(),
            Value<double?> setembro = const Value.absent(),
            Value<double?> outubro = const Value.absent(),
            Value<double?> novembro = const Value.absent(),
            Value<double?> dezembro = const Value.absent(),
          }) =>
              ContabilLancamentoOrcadosCompanion.insert(
            id: id,
            idContabilConta: idContabilConta,
            ano: ano,
            janeiro: janeiro,
            fevereiro: fevereiro,
            marco: marco,
            abril: abril,
            maio: maio,
            junho: junho,
            julho: julho,
            agosto: agosto,
            setembro: setembro,
            outubro: outubro,
            novembro: novembro,
            dezembro: dezembro,
          ),
        ));
}

class $$ContabilLancamentoOrcadosTableFilterComposer
    extends FilterComposer<_$AppDatabase, $ContabilLancamentoOrcadosTable> {
  $$ContabilLancamentoOrcadosTableFilterComposer(super.$state);
  ColumnFilters<int> get id => $state.composableBuilder(
      column: $state.table.id,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<int> get idContabilConta => $state.composableBuilder(
      column: $state.table.idContabilConta,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get ano => $state.composableBuilder(
      column: $state.table.ano,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<double> get janeiro => $state.composableBuilder(
      column: $state.table.janeiro,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<double> get fevereiro => $state.composableBuilder(
      column: $state.table.fevereiro,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<double> get marco => $state.composableBuilder(
      column: $state.table.marco,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<double> get abril => $state.composableBuilder(
      column: $state.table.abril,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<double> get maio => $state.composableBuilder(
      column: $state.table.maio,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<double> get junho => $state.composableBuilder(
      column: $state.table.junho,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<double> get julho => $state.composableBuilder(
      column: $state.table.julho,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<double> get agosto => $state.composableBuilder(
      column: $state.table.agosto,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<double> get setembro => $state.composableBuilder(
      column: $state.table.setembro,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<double> get outubro => $state.composableBuilder(
      column: $state.table.outubro,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<double> get novembro => $state.composableBuilder(
      column: $state.table.novembro,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<double> get dezembro => $state.composableBuilder(
      column: $state.table.dezembro,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));
}

class $$ContabilLancamentoOrcadosTableOrderingComposer
    extends OrderingComposer<_$AppDatabase, $ContabilLancamentoOrcadosTable> {
  $$ContabilLancamentoOrcadosTableOrderingComposer(super.$state);
  ColumnOrderings<int> get id => $state.composableBuilder(
      column: $state.table.id,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<int> get idContabilConta => $state.composableBuilder(
      column: $state.table.idContabilConta,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get ano => $state.composableBuilder(
      column: $state.table.ano,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<double> get janeiro => $state.composableBuilder(
      column: $state.table.janeiro,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<double> get fevereiro => $state.composableBuilder(
      column: $state.table.fevereiro,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<double> get marco => $state.composableBuilder(
      column: $state.table.marco,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<double> get abril => $state.composableBuilder(
      column: $state.table.abril,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<double> get maio => $state.composableBuilder(
      column: $state.table.maio,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<double> get junho => $state.composableBuilder(
      column: $state.table.junho,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<double> get julho => $state.composableBuilder(
      column: $state.table.julho,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<double> get agosto => $state.composableBuilder(
      column: $state.table.agosto,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<double> get setembro => $state.composableBuilder(
      column: $state.table.setembro,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<double> get outubro => $state.composableBuilder(
      column: $state.table.outubro,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<double> get novembro => $state.composableBuilder(
      column: $state.table.novembro,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<double> get dezembro => $state.composableBuilder(
      column: $state.table.dezembro,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));
}

typedef $$LancaCentroResultadosTableCreateCompanionBuilder
    = LancaCentroResultadosCompanion Function({
  Value<int?> id,
  Value<int?> idCentroResultado,
  Value<double?> valor,
  Value<DateTime?> dataLancamento,
  Value<DateTime?> dataInclusao,
  Value<String?> origemDeRateio,
  Value<String?> historico,
});
typedef $$LancaCentroResultadosTableUpdateCompanionBuilder
    = LancaCentroResultadosCompanion Function({
  Value<int?> id,
  Value<int?> idCentroResultado,
  Value<double?> valor,
  Value<DateTime?> dataLancamento,
  Value<DateTime?> dataInclusao,
  Value<String?> origemDeRateio,
  Value<String?> historico,
});

class $$LancaCentroResultadosTableTableManager extends RootTableManager<
    _$AppDatabase,
    $LancaCentroResultadosTable,
    LancaCentroResultado,
    $$LancaCentroResultadosTableFilterComposer,
    $$LancaCentroResultadosTableOrderingComposer,
    $$LancaCentroResultadosTableCreateCompanionBuilder,
    $$LancaCentroResultadosTableUpdateCompanionBuilder> {
  $$LancaCentroResultadosTableTableManager(
      _$AppDatabase db, $LancaCentroResultadosTable table)
      : super(TableManagerState(
          db: db,
          table: table,
          filteringComposer: $$LancaCentroResultadosTableFilterComposer(
              ComposerState(db, table)),
          orderingComposer: $$LancaCentroResultadosTableOrderingComposer(
              ComposerState(db, table)),
          updateCompanionCallback: ({
            Value<int?> id = const Value.absent(),
            Value<int?> idCentroResultado = const Value.absent(),
            Value<double?> valor = const Value.absent(),
            Value<DateTime?> dataLancamento = const Value.absent(),
            Value<DateTime?> dataInclusao = const Value.absent(),
            Value<String?> origemDeRateio = const Value.absent(),
            Value<String?> historico = const Value.absent(),
          }) =>
              LancaCentroResultadosCompanion(
            id: id,
            idCentroResultado: idCentroResultado,
            valor: valor,
            dataLancamento: dataLancamento,
            dataInclusao: dataInclusao,
            origemDeRateio: origemDeRateio,
            historico: historico,
          ),
          createCompanionCallback: ({
            Value<int?> id = const Value.absent(),
            Value<int?> idCentroResultado = const Value.absent(),
            Value<double?> valor = const Value.absent(),
            Value<DateTime?> dataLancamento = const Value.absent(),
            Value<DateTime?> dataInclusao = const Value.absent(),
            Value<String?> origemDeRateio = const Value.absent(),
            Value<String?> historico = const Value.absent(),
          }) =>
              LancaCentroResultadosCompanion.insert(
            id: id,
            idCentroResultado: idCentroResultado,
            valor: valor,
            dataLancamento: dataLancamento,
            dataInclusao: dataInclusao,
            origemDeRateio: origemDeRateio,
            historico: historico,
          ),
        ));
}

class $$LancaCentroResultadosTableFilterComposer
    extends FilterComposer<_$AppDatabase, $LancaCentroResultadosTable> {
  $$LancaCentroResultadosTableFilterComposer(super.$state);
  ColumnFilters<int> get id => $state.composableBuilder(
      column: $state.table.id,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<int> get idCentroResultado => $state.composableBuilder(
      column: $state.table.idCentroResultado,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<double> get valor => $state.composableBuilder(
      column: $state.table.valor,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<DateTime> get dataLancamento => $state.composableBuilder(
      column: $state.table.dataLancamento,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<DateTime> get dataInclusao => $state.composableBuilder(
      column: $state.table.dataInclusao,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get origemDeRateio => $state.composableBuilder(
      column: $state.table.origemDeRateio,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get historico => $state.composableBuilder(
      column: $state.table.historico,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));
}

class $$LancaCentroResultadosTableOrderingComposer
    extends OrderingComposer<_$AppDatabase, $LancaCentroResultadosTable> {
  $$LancaCentroResultadosTableOrderingComposer(super.$state);
  ColumnOrderings<int> get id => $state.composableBuilder(
      column: $state.table.id,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<int> get idCentroResultado => $state.composableBuilder(
      column: $state.table.idCentroResultado,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<double> get valor => $state.composableBuilder(
      column: $state.table.valor,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<DateTime> get dataLancamento => $state.composableBuilder(
      column: $state.table.dataLancamento,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<DateTime> get dataInclusao => $state.composableBuilder(
      column: $state.table.dataInclusao,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get origemDeRateio => $state.composableBuilder(
      column: $state.table.origemDeRateio,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get historico => $state.composableBuilder(
      column: $state.table.historico,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));
}

typedef $$EncerraCentroResultadosTableCreateCompanionBuilder
    = EncerraCentroResultadosCompanion Function({
  Value<int?> id,
  Value<int?> idCentroResultado,
  Value<String?> competencia,
  Value<double?> valorTotal,
  Value<double?> valorSubRateio,
});
typedef $$EncerraCentroResultadosTableUpdateCompanionBuilder
    = EncerraCentroResultadosCompanion Function({
  Value<int?> id,
  Value<int?> idCentroResultado,
  Value<String?> competencia,
  Value<double?> valorTotal,
  Value<double?> valorSubRateio,
});

class $$EncerraCentroResultadosTableTableManager extends RootTableManager<
    _$AppDatabase,
    $EncerraCentroResultadosTable,
    EncerraCentroResultado,
    $$EncerraCentroResultadosTableFilterComposer,
    $$EncerraCentroResultadosTableOrderingComposer,
    $$EncerraCentroResultadosTableCreateCompanionBuilder,
    $$EncerraCentroResultadosTableUpdateCompanionBuilder> {
  $$EncerraCentroResultadosTableTableManager(
      _$AppDatabase db, $EncerraCentroResultadosTable table)
      : super(TableManagerState(
          db: db,
          table: table,
          filteringComposer: $$EncerraCentroResultadosTableFilterComposer(
              ComposerState(db, table)),
          orderingComposer: $$EncerraCentroResultadosTableOrderingComposer(
              ComposerState(db, table)),
          updateCompanionCallback: ({
            Value<int?> id = const Value.absent(),
            Value<int?> idCentroResultado = const Value.absent(),
            Value<String?> competencia = const Value.absent(),
            Value<double?> valorTotal = const Value.absent(),
            Value<double?> valorSubRateio = const Value.absent(),
          }) =>
              EncerraCentroResultadosCompanion(
            id: id,
            idCentroResultado: idCentroResultado,
            competencia: competencia,
            valorTotal: valorTotal,
            valorSubRateio: valorSubRateio,
          ),
          createCompanionCallback: ({
            Value<int?> id = const Value.absent(),
            Value<int?> idCentroResultado = const Value.absent(),
            Value<String?> competencia = const Value.absent(),
            Value<double?> valorTotal = const Value.absent(),
            Value<double?> valorSubRateio = const Value.absent(),
          }) =>
              EncerraCentroResultadosCompanion.insert(
            id: id,
            idCentroResultado: idCentroResultado,
            competencia: competencia,
            valorTotal: valorTotal,
            valorSubRateio: valorSubRateio,
          ),
        ));
}

class $$EncerraCentroResultadosTableFilterComposer
    extends FilterComposer<_$AppDatabase, $EncerraCentroResultadosTable> {
  $$EncerraCentroResultadosTableFilterComposer(super.$state);
  ColumnFilters<int> get id => $state.composableBuilder(
      column: $state.table.id,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<int> get idCentroResultado => $state.composableBuilder(
      column: $state.table.idCentroResultado,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get competencia => $state.composableBuilder(
      column: $state.table.competencia,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<double> get valorTotal => $state.composableBuilder(
      column: $state.table.valorTotal,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<double> get valorSubRateio => $state.composableBuilder(
      column: $state.table.valorSubRateio,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));
}

class $$EncerraCentroResultadosTableOrderingComposer
    extends OrderingComposer<_$AppDatabase, $EncerraCentroResultadosTable> {
  $$EncerraCentroResultadosTableOrderingComposer(super.$state);
  ColumnOrderings<int> get id => $state.composableBuilder(
      column: $state.table.id,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<int> get idCentroResultado => $state.composableBuilder(
      column: $state.table.idCentroResultado,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get competencia => $state.composableBuilder(
      column: $state.table.competencia,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<double> get valorTotal => $state.composableBuilder(
      column: $state.table.valorTotal,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<double> get valorSubRateio => $state.composableBuilder(
      column: $state.table.valorSubRateio,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));
}

typedef $$ContabilContaRateiosTableCreateCompanionBuilder
    = ContabilContaRateiosCompanion Function({
  Value<int?> id,
  Value<int?> idCentroResultado,
  Value<int?> idContabilConta,
  Value<double?> porcentoRateio,
});
typedef $$ContabilContaRateiosTableUpdateCompanionBuilder
    = ContabilContaRateiosCompanion Function({
  Value<int?> id,
  Value<int?> idCentroResultado,
  Value<int?> idContabilConta,
  Value<double?> porcentoRateio,
});

class $$ContabilContaRateiosTableTableManager extends RootTableManager<
    _$AppDatabase,
    $ContabilContaRateiosTable,
    ContabilContaRateio,
    $$ContabilContaRateiosTableFilterComposer,
    $$ContabilContaRateiosTableOrderingComposer,
    $$ContabilContaRateiosTableCreateCompanionBuilder,
    $$ContabilContaRateiosTableUpdateCompanionBuilder> {
  $$ContabilContaRateiosTableTableManager(
      _$AppDatabase db, $ContabilContaRateiosTable table)
      : super(TableManagerState(
          db: db,
          table: table,
          filteringComposer: $$ContabilContaRateiosTableFilterComposer(
              ComposerState(db, table)),
          orderingComposer: $$ContabilContaRateiosTableOrderingComposer(
              ComposerState(db, table)),
          updateCompanionCallback: ({
            Value<int?> id = const Value.absent(),
            Value<int?> idCentroResultado = const Value.absent(),
            Value<int?> idContabilConta = const Value.absent(),
            Value<double?> porcentoRateio = const Value.absent(),
          }) =>
              ContabilContaRateiosCompanion(
            id: id,
            idCentroResultado: idCentroResultado,
            idContabilConta: idContabilConta,
            porcentoRateio: porcentoRateio,
          ),
          createCompanionCallback: ({
            Value<int?> id = const Value.absent(),
            Value<int?> idCentroResultado = const Value.absent(),
            Value<int?> idContabilConta = const Value.absent(),
            Value<double?> porcentoRateio = const Value.absent(),
          }) =>
              ContabilContaRateiosCompanion.insert(
            id: id,
            idCentroResultado: idCentroResultado,
            idContabilConta: idContabilConta,
            porcentoRateio: porcentoRateio,
          ),
        ));
}

class $$ContabilContaRateiosTableFilterComposer
    extends FilterComposer<_$AppDatabase, $ContabilContaRateiosTable> {
  $$ContabilContaRateiosTableFilterComposer(super.$state);
  ColumnFilters<int> get id => $state.composableBuilder(
      column: $state.table.id,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<int> get idCentroResultado => $state.composableBuilder(
      column: $state.table.idCentroResultado,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<int> get idContabilConta => $state.composableBuilder(
      column: $state.table.idContabilConta,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<double> get porcentoRateio => $state.composableBuilder(
      column: $state.table.porcentoRateio,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));
}

class $$ContabilContaRateiosTableOrderingComposer
    extends OrderingComposer<_$AppDatabase, $ContabilContaRateiosTable> {
  $$ContabilContaRateiosTableOrderingComposer(super.$state);
  ColumnOrderings<int> get id => $state.composableBuilder(
      column: $state.table.id,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<int> get idCentroResultado => $state.composableBuilder(
      column: $state.table.idCentroResultado,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<int> get idContabilConta => $state.composableBuilder(
      column: $state.table.idContabilConta,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<double> get porcentoRateio => $state.composableBuilder(
      column: $state.table.porcentoRateio,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));
}

typedef $$ContabilFechamentosTableCreateCompanionBuilder
    = ContabilFechamentosCompanion Function({
  Value<int?> id,
  Value<DateTime?> dataInicio,
  Value<DateTime?> dataFim,
  Value<String?> criterioLancamento,
});
typedef $$ContabilFechamentosTableUpdateCompanionBuilder
    = ContabilFechamentosCompanion Function({
  Value<int?> id,
  Value<DateTime?> dataInicio,
  Value<DateTime?> dataFim,
  Value<String?> criterioLancamento,
});

class $$ContabilFechamentosTableTableManager extends RootTableManager<
    _$AppDatabase,
    $ContabilFechamentosTable,
    ContabilFechamento,
    $$ContabilFechamentosTableFilterComposer,
    $$ContabilFechamentosTableOrderingComposer,
    $$ContabilFechamentosTableCreateCompanionBuilder,
    $$ContabilFechamentosTableUpdateCompanionBuilder> {
  $$ContabilFechamentosTableTableManager(
      _$AppDatabase db, $ContabilFechamentosTable table)
      : super(TableManagerState(
          db: db,
          table: table,
          filteringComposer: $$ContabilFechamentosTableFilterComposer(
              ComposerState(db, table)),
          orderingComposer: $$ContabilFechamentosTableOrderingComposer(
              ComposerState(db, table)),
          updateCompanionCallback: ({
            Value<int?> id = const Value.absent(),
            Value<DateTime?> dataInicio = const Value.absent(),
            Value<DateTime?> dataFim = const Value.absent(),
            Value<String?> criterioLancamento = const Value.absent(),
          }) =>
              ContabilFechamentosCompanion(
            id: id,
            dataInicio: dataInicio,
            dataFim: dataFim,
            criterioLancamento: criterioLancamento,
          ),
          createCompanionCallback: ({
            Value<int?> id = const Value.absent(),
            Value<DateTime?> dataInicio = const Value.absent(),
            Value<DateTime?> dataFim = const Value.absent(),
            Value<String?> criterioLancamento = const Value.absent(),
          }) =>
              ContabilFechamentosCompanion.insert(
            id: id,
            dataInicio: dataInicio,
            dataFim: dataFim,
            criterioLancamento: criterioLancamento,
          ),
        ));
}

class $$ContabilFechamentosTableFilterComposer
    extends FilterComposer<_$AppDatabase, $ContabilFechamentosTable> {
  $$ContabilFechamentosTableFilterComposer(super.$state);
  ColumnFilters<int> get id => $state.composableBuilder(
      column: $state.table.id,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<DateTime> get dataInicio => $state.composableBuilder(
      column: $state.table.dataInicio,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<DateTime> get dataFim => $state.composableBuilder(
      column: $state.table.dataFim,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get criterioLancamento => $state.composableBuilder(
      column: $state.table.criterioLancamento,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));
}

class $$ContabilFechamentosTableOrderingComposer
    extends OrderingComposer<_$AppDatabase, $ContabilFechamentosTable> {
  $$ContabilFechamentosTableOrderingComposer(super.$state);
  ColumnOrderings<int> get id => $state.composableBuilder(
      column: $state.table.id,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<DateTime> get dataInicio => $state.composableBuilder(
      column: $state.table.dataInicio,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<DateTime> get dataFim => $state.composableBuilder(
      column: $state.table.dataFim,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get criterioLancamento => $state.composableBuilder(
      column: $state.table.criterioLancamento,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));
}

typedef $$ViewControleAcessosTableCreateCompanionBuilder
    = ViewControleAcessosCompanion Function({
  Value<int?> id,
  Value<int?> idPessoa,
  Value<String?> pessoaNome,
  Value<int?> idColaborador,
  Value<int?> idUsuario,
  Value<String?> administrador,
  Value<int?> idPapel,
  Value<String?> papelNome,
  Value<String?> papelDescricao,
  Value<int?> idFuncao,
  Value<String?> funcaoNome,
  Value<String?> funcaoDescricao,
  Value<int?> idPapelFuncao,
  Value<String?> habilitado,
  Value<String?> podeInserir,
  Value<String?> podeAlterar,
  Value<String?> podeExcluir,
});
typedef $$ViewControleAcessosTableUpdateCompanionBuilder
    = ViewControleAcessosCompanion Function({
  Value<int?> id,
  Value<int?> idPessoa,
  Value<String?> pessoaNome,
  Value<int?> idColaborador,
  Value<int?> idUsuario,
  Value<String?> administrador,
  Value<int?> idPapel,
  Value<String?> papelNome,
  Value<String?> papelDescricao,
  Value<int?> idFuncao,
  Value<String?> funcaoNome,
  Value<String?> funcaoDescricao,
  Value<int?> idPapelFuncao,
  Value<String?> habilitado,
  Value<String?> podeInserir,
  Value<String?> podeAlterar,
  Value<String?> podeExcluir,
});

class $$ViewControleAcessosTableTableManager extends RootTableManager<
    _$AppDatabase,
    $ViewControleAcessosTable,
    ViewControleAcesso,
    $$ViewControleAcessosTableFilterComposer,
    $$ViewControleAcessosTableOrderingComposer,
    $$ViewControleAcessosTableCreateCompanionBuilder,
    $$ViewControleAcessosTableUpdateCompanionBuilder> {
  $$ViewControleAcessosTableTableManager(
      _$AppDatabase db, $ViewControleAcessosTable table)
      : super(TableManagerState(
          db: db,
          table: table,
          filteringComposer: $$ViewControleAcessosTableFilterComposer(
              ComposerState(db, table)),
          orderingComposer: $$ViewControleAcessosTableOrderingComposer(
              ComposerState(db, table)),
          updateCompanionCallback: ({
            Value<int?> id = const Value.absent(),
            Value<int?> idPessoa = const Value.absent(),
            Value<String?> pessoaNome = const Value.absent(),
            Value<int?> idColaborador = const Value.absent(),
            Value<int?> idUsuario = const Value.absent(),
            Value<String?> administrador = const Value.absent(),
            Value<int?> idPapel = const Value.absent(),
            Value<String?> papelNome = const Value.absent(),
            Value<String?> papelDescricao = const Value.absent(),
            Value<int?> idFuncao = const Value.absent(),
            Value<String?> funcaoNome = const Value.absent(),
            Value<String?> funcaoDescricao = const Value.absent(),
            Value<int?> idPapelFuncao = const Value.absent(),
            Value<String?> habilitado = const Value.absent(),
            Value<String?> podeInserir = const Value.absent(),
            Value<String?> podeAlterar = const Value.absent(),
            Value<String?> podeExcluir = const Value.absent(),
          }) =>
              ViewControleAcessosCompanion(
            id: id,
            idPessoa: idPessoa,
            pessoaNome: pessoaNome,
            idColaborador: idColaborador,
            idUsuario: idUsuario,
            administrador: administrador,
            idPapel: idPapel,
            papelNome: papelNome,
            papelDescricao: papelDescricao,
            idFuncao: idFuncao,
            funcaoNome: funcaoNome,
            funcaoDescricao: funcaoDescricao,
            idPapelFuncao: idPapelFuncao,
            habilitado: habilitado,
            podeInserir: podeInserir,
            podeAlterar: podeAlterar,
            podeExcluir: podeExcluir,
          ),
          createCompanionCallback: ({
            Value<int?> id = const Value.absent(),
            Value<int?> idPessoa = const Value.absent(),
            Value<String?> pessoaNome = const Value.absent(),
            Value<int?> idColaborador = const Value.absent(),
            Value<int?> idUsuario = const Value.absent(),
            Value<String?> administrador = const Value.absent(),
            Value<int?> idPapel = const Value.absent(),
            Value<String?> papelNome = const Value.absent(),
            Value<String?> papelDescricao = const Value.absent(),
            Value<int?> idFuncao = const Value.absent(),
            Value<String?> funcaoNome = const Value.absent(),
            Value<String?> funcaoDescricao = const Value.absent(),
            Value<int?> idPapelFuncao = const Value.absent(),
            Value<String?> habilitado = const Value.absent(),
            Value<String?> podeInserir = const Value.absent(),
            Value<String?> podeAlterar = const Value.absent(),
            Value<String?> podeExcluir = const Value.absent(),
          }) =>
              ViewControleAcessosCompanion.insert(
            id: id,
            idPessoa: idPessoa,
            pessoaNome: pessoaNome,
            idColaborador: idColaborador,
            idUsuario: idUsuario,
            administrador: administrador,
            idPapel: idPapel,
            papelNome: papelNome,
            papelDescricao: papelDescricao,
            idFuncao: idFuncao,
            funcaoNome: funcaoNome,
            funcaoDescricao: funcaoDescricao,
            idPapelFuncao: idPapelFuncao,
            habilitado: habilitado,
            podeInserir: podeInserir,
            podeAlterar: podeAlterar,
            podeExcluir: podeExcluir,
          ),
        ));
}

class $$ViewControleAcessosTableFilterComposer
    extends FilterComposer<_$AppDatabase, $ViewControleAcessosTable> {
  $$ViewControleAcessosTableFilterComposer(super.$state);
  ColumnFilters<int> get id => $state.composableBuilder(
      column: $state.table.id,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<int> get idPessoa => $state.composableBuilder(
      column: $state.table.idPessoa,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get pessoaNome => $state.composableBuilder(
      column: $state.table.pessoaNome,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<int> get idColaborador => $state.composableBuilder(
      column: $state.table.idColaborador,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<int> get idUsuario => $state.composableBuilder(
      column: $state.table.idUsuario,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get administrador => $state.composableBuilder(
      column: $state.table.administrador,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<int> get idPapel => $state.composableBuilder(
      column: $state.table.idPapel,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get papelNome => $state.composableBuilder(
      column: $state.table.papelNome,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get papelDescricao => $state.composableBuilder(
      column: $state.table.papelDescricao,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<int> get idFuncao => $state.composableBuilder(
      column: $state.table.idFuncao,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get funcaoNome => $state.composableBuilder(
      column: $state.table.funcaoNome,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get funcaoDescricao => $state.composableBuilder(
      column: $state.table.funcaoDescricao,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<int> get idPapelFuncao => $state.composableBuilder(
      column: $state.table.idPapelFuncao,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get habilitado => $state.composableBuilder(
      column: $state.table.habilitado,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get podeInserir => $state.composableBuilder(
      column: $state.table.podeInserir,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get podeAlterar => $state.composableBuilder(
      column: $state.table.podeAlterar,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get podeExcluir => $state.composableBuilder(
      column: $state.table.podeExcluir,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));
}

class $$ViewControleAcessosTableOrderingComposer
    extends OrderingComposer<_$AppDatabase, $ViewControleAcessosTable> {
  $$ViewControleAcessosTableOrderingComposer(super.$state);
  ColumnOrderings<int> get id => $state.composableBuilder(
      column: $state.table.id,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<int> get idPessoa => $state.composableBuilder(
      column: $state.table.idPessoa,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get pessoaNome => $state.composableBuilder(
      column: $state.table.pessoaNome,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<int> get idColaborador => $state.composableBuilder(
      column: $state.table.idColaborador,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<int> get idUsuario => $state.composableBuilder(
      column: $state.table.idUsuario,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get administrador => $state.composableBuilder(
      column: $state.table.administrador,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<int> get idPapel => $state.composableBuilder(
      column: $state.table.idPapel,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get papelNome => $state.composableBuilder(
      column: $state.table.papelNome,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get papelDescricao => $state.composableBuilder(
      column: $state.table.papelDescricao,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<int> get idFuncao => $state.composableBuilder(
      column: $state.table.idFuncao,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get funcaoNome => $state.composableBuilder(
      column: $state.table.funcaoNome,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get funcaoDescricao => $state.composableBuilder(
      column: $state.table.funcaoDescricao,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<int> get idPapelFuncao => $state.composableBuilder(
      column: $state.table.idPapelFuncao,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get habilitado => $state.composableBuilder(
      column: $state.table.habilitado,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get podeInserir => $state.composableBuilder(
      column: $state.table.podeInserir,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get podeAlterar => $state.composableBuilder(
      column: $state.table.podeAlterar,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get podeExcluir => $state.composableBuilder(
      column: $state.table.podeExcluir,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));
}

typedef $$ViewPessoaUsuariosTableCreateCompanionBuilder
    = ViewPessoaUsuariosCompanion Function({
  Value<int?> id,
  Value<int?> idPessoa,
  Value<String?> pessoaNome,
  Value<String?> tipo,
  Value<String?> email,
  Value<int?> idColaborador,
  Value<int?> idUsuario,
  Value<String?> login,
  Value<String?> senha,
  Value<DateTime?> dataCadastro,
  Value<String?> administrador,
});
typedef $$ViewPessoaUsuariosTableUpdateCompanionBuilder
    = ViewPessoaUsuariosCompanion Function({
  Value<int?> id,
  Value<int?> idPessoa,
  Value<String?> pessoaNome,
  Value<String?> tipo,
  Value<String?> email,
  Value<int?> idColaborador,
  Value<int?> idUsuario,
  Value<String?> login,
  Value<String?> senha,
  Value<DateTime?> dataCadastro,
  Value<String?> administrador,
});

class $$ViewPessoaUsuariosTableTableManager extends RootTableManager<
    _$AppDatabase,
    $ViewPessoaUsuariosTable,
    ViewPessoaUsuario,
    $$ViewPessoaUsuariosTableFilterComposer,
    $$ViewPessoaUsuariosTableOrderingComposer,
    $$ViewPessoaUsuariosTableCreateCompanionBuilder,
    $$ViewPessoaUsuariosTableUpdateCompanionBuilder> {
  $$ViewPessoaUsuariosTableTableManager(
      _$AppDatabase db, $ViewPessoaUsuariosTable table)
      : super(TableManagerState(
          db: db,
          table: table,
          filteringComposer:
              $$ViewPessoaUsuariosTableFilterComposer(ComposerState(db, table)),
          orderingComposer: $$ViewPessoaUsuariosTableOrderingComposer(
              ComposerState(db, table)),
          updateCompanionCallback: ({
            Value<int?> id = const Value.absent(),
            Value<int?> idPessoa = const Value.absent(),
            Value<String?> pessoaNome = const Value.absent(),
            Value<String?> tipo = const Value.absent(),
            Value<String?> email = const Value.absent(),
            Value<int?> idColaborador = const Value.absent(),
            Value<int?> idUsuario = const Value.absent(),
            Value<String?> login = const Value.absent(),
            Value<String?> senha = const Value.absent(),
            Value<DateTime?> dataCadastro = const Value.absent(),
            Value<String?> administrador = const Value.absent(),
          }) =>
              ViewPessoaUsuariosCompanion(
            id: id,
            idPessoa: idPessoa,
            pessoaNome: pessoaNome,
            tipo: tipo,
            email: email,
            idColaborador: idColaborador,
            idUsuario: idUsuario,
            login: login,
            senha: senha,
            dataCadastro: dataCadastro,
            administrador: administrador,
          ),
          createCompanionCallback: ({
            Value<int?> id = const Value.absent(),
            Value<int?> idPessoa = const Value.absent(),
            Value<String?> pessoaNome = const Value.absent(),
            Value<String?> tipo = const Value.absent(),
            Value<String?> email = const Value.absent(),
            Value<int?> idColaborador = const Value.absent(),
            Value<int?> idUsuario = const Value.absent(),
            Value<String?> login = const Value.absent(),
            Value<String?> senha = const Value.absent(),
            Value<DateTime?> dataCadastro = const Value.absent(),
            Value<String?> administrador = const Value.absent(),
          }) =>
              ViewPessoaUsuariosCompanion.insert(
            id: id,
            idPessoa: idPessoa,
            pessoaNome: pessoaNome,
            tipo: tipo,
            email: email,
            idColaborador: idColaborador,
            idUsuario: idUsuario,
            login: login,
            senha: senha,
            dataCadastro: dataCadastro,
            administrador: administrador,
          ),
        ));
}

class $$ViewPessoaUsuariosTableFilterComposer
    extends FilterComposer<_$AppDatabase, $ViewPessoaUsuariosTable> {
  $$ViewPessoaUsuariosTableFilterComposer(super.$state);
  ColumnFilters<int> get id => $state.composableBuilder(
      column: $state.table.id,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<int> get idPessoa => $state.composableBuilder(
      column: $state.table.idPessoa,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get pessoaNome => $state.composableBuilder(
      column: $state.table.pessoaNome,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get tipo => $state.composableBuilder(
      column: $state.table.tipo,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get email => $state.composableBuilder(
      column: $state.table.email,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<int> get idColaborador => $state.composableBuilder(
      column: $state.table.idColaborador,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<int> get idUsuario => $state.composableBuilder(
      column: $state.table.idUsuario,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get login => $state.composableBuilder(
      column: $state.table.login,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get senha => $state.composableBuilder(
      column: $state.table.senha,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<DateTime> get dataCadastro => $state.composableBuilder(
      column: $state.table.dataCadastro,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get administrador => $state.composableBuilder(
      column: $state.table.administrador,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));
}

class $$ViewPessoaUsuariosTableOrderingComposer
    extends OrderingComposer<_$AppDatabase, $ViewPessoaUsuariosTable> {
  $$ViewPessoaUsuariosTableOrderingComposer(super.$state);
  ColumnOrderings<int> get id => $state.composableBuilder(
      column: $state.table.id,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<int> get idPessoa => $state.composableBuilder(
      column: $state.table.idPessoa,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get pessoaNome => $state.composableBuilder(
      column: $state.table.pessoaNome,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get tipo => $state.composableBuilder(
      column: $state.table.tipo,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get email => $state.composableBuilder(
      column: $state.table.email,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<int> get idColaborador => $state.composableBuilder(
      column: $state.table.idColaborador,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<int> get idUsuario => $state.composableBuilder(
      column: $state.table.idUsuario,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get login => $state.composableBuilder(
      column: $state.table.login,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get senha => $state.composableBuilder(
      column: $state.table.senha,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<DateTime> get dataCadastro => $state.composableBuilder(
      column: $state.table.dataCadastro,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get administrador => $state.composableBuilder(
      column: $state.table.administrador,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));
}

typedef $$PlanoCentroResultadosTableCreateCompanionBuilder
    = PlanoCentroResultadosCompanion Function({
  Value<int?> id,
  Value<String?> nome,
  Value<String?> mascara,
  Value<int?> niveis,
  Value<DateTime?> dataInclusao,
});
typedef $$PlanoCentroResultadosTableUpdateCompanionBuilder
    = PlanoCentroResultadosCompanion Function({
  Value<int?> id,
  Value<String?> nome,
  Value<String?> mascara,
  Value<int?> niveis,
  Value<DateTime?> dataInclusao,
});

class $$PlanoCentroResultadosTableTableManager extends RootTableManager<
    _$AppDatabase,
    $PlanoCentroResultadosTable,
    PlanoCentroResultado,
    $$PlanoCentroResultadosTableFilterComposer,
    $$PlanoCentroResultadosTableOrderingComposer,
    $$PlanoCentroResultadosTableCreateCompanionBuilder,
    $$PlanoCentroResultadosTableUpdateCompanionBuilder> {
  $$PlanoCentroResultadosTableTableManager(
      _$AppDatabase db, $PlanoCentroResultadosTable table)
      : super(TableManagerState(
          db: db,
          table: table,
          filteringComposer: $$PlanoCentroResultadosTableFilterComposer(
              ComposerState(db, table)),
          orderingComposer: $$PlanoCentroResultadosTableOrderingComposer(
              ComposerState(db, table)),
          updateCompanionCallback: ({
            Value<int?> id = const Value.absent(),
            Value<String?> nome = const Value.absent(),
            Value<String?> mascara = const Value.absent(),
            Value<int?> niveis = const Value.absent(),
            Value<DateTime?> dataInclusao = const Value.absent(),
          }) =>
              PlanoCentroResultadosCompanion(
            id: id,
            nome: nome,
            mascara: mascara,
            niveis: niveis,
            dataInclusao: dataInclusao,
          ),
          createCompanionCallback: ({
            Value<int?> id = const Value.absent(),
            Value<String?> nome = const Value.absent(),
            Value<String?> mascara = const Value.absent(),
            Value<int?> niveis = const Value.absent(),
            Value<DateTime?> dataInclusao = const Value.absent(),
          }) =>
              PlanoCentroResultadosCompanion.insert(
            id: id,
            nome: nome,
            mascara: mascara,
            niveis: niveis,
            dataInclusao: dataInclusao,
          ),
        ));
}

class $$PlanoCentroResultadosTableFilterComposer
    extends FilterComposer<_$AppDatabase, $PlanoCentroResultadosTable> {
  $$PlanoCentroResultadosTableFilterComposer(super.$state);
  ColumnFilters<int> get id => $state.composableBuilder(
      column: $state.table.id,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get nome => $state.composableBuilder(
      column: $state.table.nome,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<String> get mascara => $state.composableBuilder(
      column: $state.table.mascara,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<int> get niveis => $state.composableBuilder(
      column: $state.table.niveis,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));

  ColumnFilters<DateTime> get dataInclusao => $state.composableBuilder(
      column: $state.table.dataInclusao,
      builder: (column, joinBuilders) =>
          ColumnFilters(column, joinBuilders: joinBuilders));
}

class $$PlanoCentroResultadosTableOrderingComposer
    extends OrderingComposer<_$AppDatabase, $PlanoCentroResultadosTable> {
  $$PlanoCentroResultadosTableOrderingComposer(super.$state);
  ColumnOrderings<int> get id => $state.composableBuilder(
      column: $state.table.id,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get nome => $state.composableBuilder(
      column: $state.table.nome,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<String> get mascara => $state.composableBuilder(
      column: $state.table.mascara,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<int> get niveis => $state.composableBuilder(
      column: $state.table.niveis,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));

  ColumnOrderings<DateTime> get dataInclusao => $state.composableBuilder(
      column: $state.table.dataInclusao,
      builder: (column, joinBuilders) =>
          ColumnOrderings(column, joinBuilders: joinBuilders));
}

class $AppDatabaseManager {
  final _$AppDatabase _db;
  $AppDatabaseManager(this._db);
  $$ContabilLancamentoDetalhesTableTableManager
      get contabilLancamentoDetalhes =>
          $$ContabilLancamentoDetalhesTableTableManager(
              _db, _db.contabilLancamentoDetalhes);
  $$ContabilDreDetalhesTableTableManager get contabilDreDetalhes =>
      $$ContabilDreDetalhesTableTableManager(_db, _db.contabilDreDetalhes);
  $$ContabilTermosTableTableManager get contabilTermos =>
      $$ContabilTermosTableTableManager(_db, _db.contabilTermos);
  $$ContabilEncerramentoExeDetsTableTableManager
      get contabilEncerramentoExeDets =>
          $$ContabilEncerramentoExeDetsTableTableManager(
              _db, _db.contabilEncerramentoExeDets);
  $$RateioCentroResultadoDetsTableTableManager get rateioCentroResultadoDets =>
      $$RateioCentroResultadoDetsTableTableManager(
          _db, _db.rateioCentroResultadoDets);
  $$ContabilIndiceValorsTableTableManager get contabilIndiceValors =>
      $$ContabilIndiceValorsTableTableManager(_db, _db.contabilIndiceValors);
  $$CtResultadoNtFinanceirasTableTableManager get ctResultadoNtFinanceiras =>
      $$CtResultadoNtFinanceirasTableTableManager(
          _db, _db.ctResultadoNtFinanceiras);
  $$ContabilLancamentoCabecalhosTableTableManager
      get contabilLancamentoCabecalhos =>
          $$ContabilLancamentoCabecalhosTableTableManager(
              _db, _db.contabilLancamentoCabecalhos);
  $$ContabilDreCabecalhosTableTableManager get contabilDreCabecalhos =>
      $$ContabilDreCabecalhosTableTableManager(_db, _db.contabilDreCabecalhos);
  $$ContabilLivrosTableTableManager get contabilLivros =>
      $$ContabilLivrosTableTableManager(_db, _db.contabilLivros);
  $$ContabilEncerramentoExeCabsTableTableManager
      get contabilEncerramentoExeCabs =>
          $$ContabilEncerramentoExeCabsTableTableManager(
              _db, _db.contabilEncerramentoExeCabs);
  $$CentroResultadosTableTableManager get centroResultados =>
      $$CentroResultadosTableTableManager(_db, _db.centroResultados);
  $$RateioCentroResultadoCabsTableTableManager get rateioCentroResultadoCabs =>
      $$RateioCentroResultadoCabsTableTableManager(
          _db, _db.rateioCentroResultadoCabs);
  $$ContabilIndicesTableTableManager get contabilIndices =>
      $$ContabilIndicesTableTableManager(_db, _db.contabilIndices);
  $$FinNaturezaFinanceirasTableTableManager get finNaturezaFinanceiras =>
      $$FinNaturezaFinanceirasTableTableManager(
          _db, _db.finNaturezaFinanceiras);
  $$AidfAimdfsTableTableManager get aidfAimdfs =>
      $$AidfAimdfsTableTableManager(_db, _db.aidfAimdfs);
  $$FapsTableTableManager get faps => $$FapsTableTableManager(_db, _db.faps);
  $$RegistroCartoriosTableTableManager get registroCartorios =>
      $$RegistroCartoriosTableTableManager(_db, _db.registroCartorios);
  $$ContabilParametrosTableTableManager get contabilParametros =>
      $$ContabilParametrosTableTableManager(_db, _db.contabilParametros);
  $$PlanoContaRefSpedsTableTableManager get planoContaRefSpeds =>
      $$PlanoContaRefSpedsTableTableManager(_db, _db.planoContaRefSpeds);
  $$PlanoContasTableTableManager get planoContas =>
      $$PlanoContasTableTableManager(_db, _db.planoContas);
  $$ContabilContasTableTableManager get contabilContas =>
      $$ContabilContasTableTableManager(_db, _db.contabilContas);
  $$ContabilHistoricosTableTableManager get contabilHistoricos =>
      $$ContabilHistoricosTableTableManager(_db, _db.contabilHistoricos);
  $$ContabilLancamentoPadraosTableTableManager get contabilLancamentoPadraos =>
      $$ContabilLancamentoPadraosTableTableManager(
          _db, _db.contabilLancamentoPadraos);
  $$ContabilLotesTableTableManager get contabilLotes =>
      $$ContabilLotesTableTableManager(_db, _db.contabilLotes);
  $$ContabilLancamentoOrcadosTableTableManager get contabilLancamentoOrcados =>
      $$ContabilLancamentoOrcadosTableTableManager(
          _db, _db.contabilLancamentoOrcados);
  $$LancaCentroResultadosTableTableManager get lancaCentroResultados =>
      $$LancaCentroResultadosTableTableManager(_db, _db.lancaCentroResultados);
  $$EncerraCentroResultadosTableTableManager get encerraCentroResultados =>
      $$EncerraCentroResultadosTableTableManager(
          _db, _db.encerraCentroResultados);
  $$ContabilContaRateiosTableTableManager get contabilContaRateios =>
      $$ContabilContaRateiosTableTableManager(_db, _db.contabilContaRateios);
  $$ContabilFechamentosTableTableManager get contabilFechamentos =>
      $$ContabilFechamentosTableTableManager(_db, _db.contabilFechamentos);
  $$ViewControleAcessosTableTableManager get viewControleAcessos =>
      $$ViewControleAcessosTableTableManager(_db, _db.viewControleAcessos);
  $$ViewPessoaUsuariosTableTableManager get viewPessoaUsuarios =>
      $$ViewPessoaUsuariosTableTableManager(_db, _db.viewPessoaUsuarios);
  $$PlanoCentroResultadosTableTableManager get planoCentroResultados =>
      $$PlanoCentroResultadosTableTableManager(_db, _db.planoCentroResultados);
}
