import 'package:contabil/app/data/provider/api/api_provider_base.dart';
import 'package:contabil/app/data/model/model_imports.dart';

class ContabilContaRateioApiProvider extends ApiProviderBase {
  static const _path = '/contabil-conta-rateio';

  Future<List<ContabilContaRateioModel>?> getList({Filter? filter}) {
    return super.getListBase(
      '$_path/',
      (json) => ContabilContaRateioModel.fromJson(json),
      filter: filter,
    );
  }

  Future<ContabilContaRateioModel?> getObject(dynamic pk) {
    return super.getObjectBase(
      _path,
      pk,
      (json) => ContabilContaRateioModel.fromJson(json),
    );
  }

  Future<ContabilContaRateioModel?>? insert(ContabilContaRateioModel model) {
    return super.insertBase(
      _path,
      model,
      (json) => ContabilContaRateioModel.fromJson(json),
    );
  }

  Future<ContabilContaRateioModel?>? update(ContabilContaRateioModel model) {
    return super.updateBase(
      _path,
      model,
      (json) => ContabilContaRateioModel.fromJson(json),
    );
  }

  Future<bool?> delete(dynamic pk) {
    return super.deleteBase(_path, pk);
  }
}
