import 'package:contabil/app/data/provider/api/api_provider_base.dart';
import 'package:contabil/app/data/model/model_imports.dart';

class ContabilFechamentoApiProvider extends ApiProviderBase {
  static const _path = '/contabil-fechamento';

  Future<List<ContabilFechamentoModel>?> getList({Filter? filter}) {
    return super.getListBase(
      '$_path/',
      (json) => ContabilFechamentoModel.fromJson(json),
      filter: filter,
    );
  }

  Future<ContabilFechamentoModel?> getObject(dynamic pk) {
    return super.getObjectBase(
      _path,
      pk,
      (json) => ContabilFechamentoModel.fromJson(json),
    );
  }

  Future<ContabilFechamentoModel?>? insert(ContabilFechamentoModel model) {
    return super.insertBase(
      _path,
      model,
      (json) => ContabilFechamentoModel.fromJson(json),
    );
  }

  Future<ContabilFechamentoModel?>? update(ContabilFechamentoModel model) {
    return super.updateBase(
      _path,
      model,
      (json) => ContabilFechamentoModel.fromJson(json),
    );
  }

  Future<bool?> delete(dynamic pk) {
    return super.deleteBase(_path, pk);
  }
}
