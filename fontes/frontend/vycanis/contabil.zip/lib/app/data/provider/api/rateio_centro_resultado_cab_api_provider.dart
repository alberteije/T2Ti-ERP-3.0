import 'package:contabil/app/data/provider/api/api_provider_base.dart';
import 'package:contabil/app/data/model/model_imports.dart';

class RateioCentroResultadoCabApiProvider extends ApiProviderBase {
  static const _path = '/rateio-centro-resultado-cab';

  Future<List<RateioCentroResultadoCabModel>?> getList({Filter? filter}) {
    return super.getListBase(
      '$_path/',
      (json) => RateioCentroResultadoCabModel.fromJson(json),
      filter: filter,
    );
  }

  Future<RateioCentroResultadoCabModel?> getObject(dynamic pk) {
    return super.getObjectBase(
      _path,
      pk,
      (json) => RateioCentroResultadoCabModel.fromJson(json),
    );
  }

  Future<RateioCentroResultadoCabModel?>? insert(RateioCentroResultadoCabModel model) {
    return super.insertBase(
      _path,
      model,
      (json) => RateioCentroResultadoCabModel.fromJson(json),
    );
  }

  Future<RateioCentroResultadoCabModel?>? update(RateioCentroResultadoCabModel model) {
    return super.updateBase(
      _path,
      model,
      (json) => RateioCentroResultadoCabModel.fromJson(json),
    );
  }

  Future<bool?> delete(dynamic pk) {
    return super.deleteBase(_path, pk);
  }
}
