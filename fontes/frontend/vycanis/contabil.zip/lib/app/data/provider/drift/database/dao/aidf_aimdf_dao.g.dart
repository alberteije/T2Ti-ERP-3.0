// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'aidf_aimdf_dao.dart';

// ignore_for_file: type=lint
mixin _$AidfAimdfDaoMixin on DatabaseAccessor<AppDatabase> {
  $AidfAimdfsTable get aidfAimdfs => attachedDatabase.aidfAimdfs;
}
