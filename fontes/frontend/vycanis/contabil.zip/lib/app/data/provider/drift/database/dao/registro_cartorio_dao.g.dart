// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'registro_cartorio_dao.dart';

// ignore_for_file: type=lint
mixin _$RegistroCartorioDaoMixin on DatabaseAccessor<AppDatabase> {
  $RegistroCartoriosTable get registroCartorios =>
      attachedDatabase.registroCartorios;
}
