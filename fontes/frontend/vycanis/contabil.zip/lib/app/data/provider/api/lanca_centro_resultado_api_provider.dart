import 'package:contabil/app/data/provider/api/api_provider_base.dart';
import 'package:contabil/app/data/model/model_imports.dart';

class LancaCentroResultadoApiProvider extends ApiProviderBase {
  static const _path = '/lanca-centro-resultado';

  Future<List<LancaCentroResultadoModel>?> getList({Filter? filter}) {
    return super.getListBase(
      '$_path/',
      (json) => LancaCentroResultadoModel.fromJson(json),
      filter: filter,
    );
  }

  Future<LancaCentroResultadoModel?> getObject(dynamic pk) {
    return super.getObjectBase(
      _path,
      pk,
      (json) => LancaCentroResultadoModel.fromJson(json),
    );
  }

  Future<LancaCentroResultadoModel?>? insert(LancaCentroResultadoModel model) {
    return super.insertBase(
      _path,
      model,
      (json) => LancaCentroResultadoModel.fromJson(json),
    );
  }

  Future<LancaCentroResultadoModel?>? update(LancaCentroResultadoModel model) {
    return super.updateBase(
      _path,
      model,
      (json) => LancaCentroResultadoModel.fromJson(json),
    );
  }

  Future<bool?> delete(dynamic pk) {
    return super.deleteBase(_path, pk);
  }
}
