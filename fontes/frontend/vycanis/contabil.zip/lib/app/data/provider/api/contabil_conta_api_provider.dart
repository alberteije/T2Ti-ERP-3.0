import 'package:contabil/app/data/provider/api/api_provider_base.dart';
import 'package:contabil/app/data/model/model_imports.dart';

class ContabilContaApiProvider extends ApiProviderBase {
  static const _path = '/contabil-conta';

  Future<List<ContabilContaModel>?> getList({Filter? filter}) {
    return super.getListBase(
      '$_path/',
      (json) => ContabilContaModel.fromJson(json),
      filter: filter,
    );
  }

  Future<ContabilContaModel?> getObject(dynamic pk) {
    return super.getObjectBase(
      _path,
      pk,
      (json) => ContabilContaModel.fromJson(json),
    );
  }

  Future<ContabilContaModel?>? insert(ContabilContaModel model) {
    return super.insertBase(
      _path,
      model,
      (json) => ContabilContaModel.fromJson(json),
    );
  }

  Future<ContabilContaModel?>? update(ContabilContaModel model) {
    return super.updateBase(
      _path,
      model,
      (json) => ContabilContaModel.fromJson(json),
    );
  }

  Future<bool?> delete(dynamic pk) {
    return super.deleteBase(_path, pk);
  }
}
