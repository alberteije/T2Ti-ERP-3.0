import 'package:contabil/app/data/provider/api/api_provider_base.dart';
import 'package:contabil/app/data/model/model_imports.dart';

class CentroResultadoApiProvider extends ApiProviderBase {
  static const _path = '/centro-resultado';

  Future<List<CentroResultadoModel>?> getList({Filter? filter}) {
    return super.getListBase(
      '$_path/',
      (json) => CentroResultadoModel.fromJson(json),
      filter: filter,
    );
  }

  Future<CentroResultadoModel?> getObject(dynamic pk) {
    return super.getObjectBase(
      _path,
      pk,
      (json) => CentroResultadoModel.fromJson(json),
    );
  }

  Future<CentroResultadoModel?>? insert(CentroResultadoModel model) {
    return super.insertBase(
      _path,
      model,
      (json) => CentroResultadoModel.fromJson(json),
    );
  }

  Future<CentroResultadoModel?>? update(CentroResultadoModel model) {
    return super.updateBase(
      _path,
      model,
      (json) => CentroResultadoModel.fromJson(json),
    );
  }

  Future<bool?> delete(dynamic pk) {
    return super.deleteBase(_path, pk);
  }
}
