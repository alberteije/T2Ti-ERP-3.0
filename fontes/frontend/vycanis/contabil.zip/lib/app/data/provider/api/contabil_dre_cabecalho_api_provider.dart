import 'package:contabil/app/data/provider/api/api_provider_base.dart';
import 'package:contabil/app/data/model/model_imports.dart';

class ContabilDreCabecalhoApiProvider extends ApiProviderBase {
  static const _path = '/contabil-dre-cabecalho';

  Future<List<ContabilDreCabecalhoModel>?> getList({Filter? filter}) {
    return super.getListBase(
      '$_path/',
      (json) => ContabilDreCabecalhoModel.fromJson(json),
      filter: filter,
    );
  }

  Future<ContabilDreCabecalhoModel?> getObject(dynamic pk) {
    return super.getObjectBase(
      _path,
      pk,
      (json) => ContabilDreCabecalhoModel.fromJson(json),
    );
  }

  Future<ContabilDreCabecalhoModel?>? insert(ContabilDreCabecalhoModel model) {
    return super.insertBase(
      _path,
      model,
      (json) => ContabilDreCabecalhoModel.fromJson(json),
    );
  }

  Future<ContabilDreCabecalhoModel?>? update(ContabilDreCabecalhoModel model) {
    return super.updateBase(
      _path,
      model,
      (json) => ContabilDreCabecalhoModel.fromJson(json),
    );
  }

  Future<bool?> delete(dynamic pk) {
    return super.deleteBase(_path, pk);
  }
}
