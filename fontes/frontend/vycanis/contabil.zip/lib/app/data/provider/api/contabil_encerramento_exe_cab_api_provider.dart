import 'package:contabil/app/data/provider/api/api_provider_base.dart';
import 'package:contabil/app/data/model/model_imports.dart';

class ContabilEncerramentoExeCabApiProvider extends ApiProviderBase {
  static const _path = '/contabil-encerramento-exe-cab';

  Future<List<ContabilEncerramentoExeCabModel>?> getList({Filter? filter}) {
    return super.getListBase(
      '$_path/',
      (json) => ContabilEncerramentoExeCabModel.fromJson(json),
      filter: filter,
    );
  }

  Future<ContabilEncerramentoExeCabModel?> getObject(dynamic pk) {
    return super.getObjectBase(
      _path,
      pk,
      (json) => ContabilEncerramentoExeCabModel.fromJson(json),
    );
  }

  Future<ContabilEncerramentoExeCabModel?>? insert(ContabilEncerramentoExeCabModel model) {
    return super.insertBase(
      _path,
      model,
      (json) => ContabilEncerramentoExeCabModel.fromJson(json),
    );
  }

  Future<ContabilEncerramentoExeCabModel?>? update(ContabilEncerramentoExeCabModel model) {
    return super.updateBase(
      _path,
      model,
      (json) => ContabilEncerramentoExeCabModel.fromJson(json),
    );
  }

  Future<bool?> delete(dynamic pk) {
    return super.deleteBase(_path, pk);
  }
}
