import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_bootstrap/flutter_bootstrap.dart';
import 'package:get/get.dart';
import 'package:contabil/app/page/shared_widget/shared_widget_imports.dart';
import 'package:contabil/app/data/domain/domain_imports.dart';
import 'package:contabil/app/controller/contabil_parametro_controller.dart';
import 'package:contabil/app/infra/infra_imports.dart';
import 'package:contabil/app/page/shared_widget/input/input_imports.dart';

class ContabilParametroEditPage extends StatelessWidget {
	ContabilParametroEditPage({Key? key}) : super(key: key);
	final contabilParametroController = Get.find<ContabilParametroController>();

	@override
	Widget build(BuildContext context) {
		return KeyboardListener(
			autofocus: false,
			focusNode: FocusNode(),
			onKeyEvent: (event) {
				if (event.logicalKey == LogicalKeyboardKey.escape) {
					contabilParametroController.preventDataLoss();
				}
			},
			child: Scaffold(
				key: contabilParametroController.scaffoldKey,
				appBar: AppBar(
					automaticallyImplyLeading: false,
					title: Text('${ contabilParametroController.screenTitle } - ${ contabilParametroController.isNewRecord ? 'inserting'.tr : 'editing'.tr }',),
					actions: [
						saveButton(onPressed: contabilParametroController.save),
						cancelAndExitButton(onPressed: contabilParametroController.preventDataLoss),
					]
				),
				body: SafeArea(
					top: false,
					bottom: false,
					child: Form(
						key: contabilParametroController.formKey,
						autovalidateMode: AutovalidateMode.always,
						child: Scrollbar(
							controller: contabilParametroController.scrollController,
							child: SingleChildScrollView(
								controller: contabilParametroController.scrollController,
								child: BootstrapContainer(
									fluid: true,
									padding: const EdgeInsets.fromLTRB(10.0, 10.0, 10.0, 10.0),
									children: <Widget>[
										const Divider(
											color: Colors.transparent,
										),
										BootstrapRow(
											height: 60,
											children: <BootstrapCol>[
												BootstrapCol(
													sizes: 'col-12 col-md-4',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: TextFormField(
															autofocus: true,
															maxLength: 30,
															controller: contabilParametroController.mascaraController,
															decoration: inputDecoration(
																hintText: 'Informe os dados para o campo Mascara',
																labelText: 'Mascara',
																usePadding: true,
															),
															onSaved: (String? value) {},
															onChanged: (text) {
																contabilParametroController.currentModel.mascara = text;
																contabilParametroController.formWasChanged = true;
															},
														),
													),
												),
												BootstrapCol(
													sizes: 'col-12 col-md-4',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: TextFormField(
															autofocus: true,
															controller: contabilParametroController.niveisController,
															decoration: inputDecoration(
																hintText: 'Informe os dados para o campo Niveis',
																labelText: 'Niveis',
																usePadding: true,
															),
															onSaved: (String? value) {},
															onChanged: (text) {
																contabilParametroController.currentModel.niveis = int.tryParse(text);
																contabilParametroController.formWasChanged = true;
															},
														),
													),
												),
												BootstrapCol(
													sizes: 'col-12 col-md-4',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: CustomDropdownButton(
															controller: contabilParametroController.informarContaPorController,
															labelText: 'Informar Conta Por',
															hintText: 'Informe os dados para o campo Informar Conta Por',
															items: ContabilParametroDomain.informarContaPorListDropdown,
															onChanged: (dynamic newValue) {
																contabilParametroController.currentModel.informarContaPor = newValue;
																contabilParametroController.formWasChanged = true;
															},
														),
													),
												),
											],
										),
										const Divider(
											color: Colors.transparent,
										),
										BootstrapRow(
											height: 60,
											children: <BootstrapCol>[
												BootstrapCol(
													sizes: 'col-12 col-md-2',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: CustomDropdownButton(
															controller: contabilParametroController.compartilhaPlanoContaController,
															labelText: 'Compartilha Plano Conta',
															hintText: 'Informe os dados para o campo Compartilha Plano Conta',
															items: ContabilParametroDomain.compartilhaPlanoContaListDropdown,
															onChanged: (dynamic newValue) {
																contabilParametroController.currentModel.compartilhaPlanoConta = newValue;
																contabilParametroController.formWasChanged = true;
															},
														),
													),
												),
												BootstrapCol(
													sizes: 'col-12 col-md-2',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: CustomDropdownButton(
															controller: contabilParametroController.compartilhaHistoricosController,
															labelText: 'Compartilha Historicos',
															hintText: 'Informe os dados para o campo Compartilha Historicos',
															items: ContabilParametroDomain.compartilhaHistoricosListDropdown,
															onChanged: (dynamic newValue) {
																contabilParametroController.currentModel.compartilhaHistoricos = newValue;
																contabilParametroController.formWasChanged = true;
															},
														),
													),
												),
												BootstrapCol(
													sizes: 'col-12 col-md-2',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: CustomDropdownButton(
															controller: contabilParametroController.alteraLancamentoOutroController,
															labelText: 'Altera Lancamento Outro',
															hintText: 'Informe os dados para o campo Altera Lancamento Outro',
															items: ContabilParametroDomain.alteraLancamentoOutroListDropdown,
															onChanged: (dynamic newValue) {
																contabilParametroController.currentModel.alteraLancamentoOutro = newValue;
																contabilParametroController.formWasChanged = true;
															},
														),
													),
												),
												BootstrapCol(
													sizes: 'col-12 col-md-2',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: CustomDropdownButton(
															controller: contabilParametroController.historicoObrigatorioController,
															labelText: 'Historico Obrigatorio',
															hintText: 'Informe os dados para o campo Historico Obrigatorio',
															items: ContabilParametroDomain.historicoObrigatorioListDropdown,
															onChanged: (dynamic newValue) {
																contabilParametroController.currentModel.historicoObrigatorio = newValue;
																contabilParametroController.formWasChanged = true;
															},
														),
													),
												),
												BootstrapCol(
													sizes: 'col-12 col-md-2',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: CustomDropdownButton(
															controller: contabilParametroController.permiteLancamentoZeradoController,
															labelText: 'Permite Lancamento Zerado',
															hintText: 'Informe os dados para o campo Permite Lancamento Zerado',
															items: ContabilParametroDomain.permiteLancamentoZeradoListDropdown,
															onChanged: (dynamic newValue) {
																contabilParametroController.currentModel.permiteLancamentoZerado = newValue;
																contabilParametroController.formWasChanged = true;
															},
														),
													),
												),
												BootstrapCol(
													sizes: 'col-12 col-md-2',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: CustomDropdownButton(
															controller: contabilParametroController.geraInformativoSpedController,
															labelText: 'Gera Informativo Sped',
															hintText: 'Informe os dados para o campo Gera Informativo Sped',
															items: ContabilParametroDomain.geraInformativoSpedListDropdown,
															onChanged: (dynamic newValue) {
																contabilParametroController.currentModel.geraInformativoSped = newValue;
																contabilParametroController.formWasChanged = true;
															},
														),
													),
												),
											],
										),
										const Divider(
											color: Colors.transparent,
										),
										BootstrapRow(
											height: 60,
											children: <BootstrapCol>[
												BootstrapCol(
													sizes: 'col-12 col-md-6',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: CustomDropdownButton(
															controller: contabilParametroController.spedFormaEscritDiarioController,
															labelText: 'Sped Forma Escrit Diario',
															hintText: 'Informe os dados para o campo Sped Forma Escrit Diario',
															items: ContabilParametroDomain.spedFormaEscritDiarioListDropdown,
															onChanged: (dynamic newValue) {
																contabilParametroController.currentModel.spedFormaEscritDiario = newValue;
																contabilParametroController.formWasChanged = true;
															},
														),
													),
												),
												BootstrapCol(
													sizes: 'col-12 col-md-6',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: TextFormField(
															autofocus: true,
															maxLength: 100,
															controller: contabilParametroController.spedNomeLivroDiarioController,
															decoration: inputDecoration(
																hintText: 'Informe os dados para o campo Sped Nome Livro Diario',
																labelText: 'Sped Nome Livro Diario',
																usePadding: true,
															),
															onSaved: (String? value) {},
															onChanged: (text) {
																contabilParametroController.currentModel.spedNomeLivroDiario = text;
																contabilParametroController.formWasChanged = true;
															},
														),
													),
												),
											],
										),
										const Divider(
											color: Colors.transparent,
										),
										BootstrapRow(
											height: 60,
											children: <BootstrapCol>[
												BootstrapCol(
													sizes: 'col-12 col-md-6',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: TextFormField(
															autofocus: true,
															maxLines: 3,
															controller: contabilParametroController.assinaturaDireitaController,
															decoration: inputDecoration(
																hintText: 'Informe os dados para o campo Assinatura Direita',
																labelText: 'Assinatura Direita',
																usePadding: true,
															),
															onSaved: (String? value) {},
															onChanged: (text) {
																contabilParametroController.currentModel.assinaturaDireita = text;
																contabilParametroController.formWasChanged = true;
															},
														),
													),
												),
												BootstrapCol(
													sizes: 'col-12 col-md-6',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: TextFormField(
															autofocus: true,
															maxLines: 3,
															controller: contabilParametroController.assinaturaEsquerdaController,
															decoration: inputDecoration(
																hintText: 'Informe os dados para o campo Assinatura Esquerda',
																labelText: 'Assinatura Esquerda',
																usePadding: true,
															),
															onSaved: (String? value) {},
															onChanged: (text) {
																contabilParametroController.currentModel.assinaturaEsquerda = text;
																contabilParametroController.formWasChanged = true;
															},
														),
													),
												),
											],
										),
										const Divider(
											color: Colors.transparent,
										),
										BootstrapRow(
											height: 60,
											children: <BootstrapCol>[
												BootstrapCol(
													sizes: 'col-12 col-md-4',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: TextFormField(
															autofocus: true,
															maxLength: 30,
															controller: contabilParametroController.contaAtivoController,
															decoration: inputDecoration(
																hintText: 'Informe os dados para o campo Conta Ativo',
																labelText: 'Conta Ativo',
																usePadding: true,
															),
															onSaved: (String? value) {},
															onChanged: (text) {
																contabilParametroController.currentModel.contaAtivo = text;
																contabilParametroController.formWasChanged = true;
															},
														),
													),
												),
												BootstrapCol(
													sizes: 'col-12 col-md-4',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: TextFormField(
															autofocus: true,
															maxLength: 30,
															controller: contabilParametroController.contaPassivoController,
															decoration: inputDecoration(
																hintText: 'Informe os dados para o campo Conta Passivo',
																labelText: 'Conta Passivo',
																usePadding: true,
															),
															onSaved: (String? value) {},
															onChanged: (text) {
																contabilParametroController.currentModel.contaPassivo = text;
																contabilParametroController.formWasChanged = true;
															},
														),
													),
												),
												BootstrapCol(
													sizes: 'col-12 col-md-4',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: TextFormField(
															autofocus: true,
															maxLength: 30,
															controller: contabilParametroController.contaPatrimonioLiquidoController,
															decoration: inputDecoration(
																hintText: 'Informe os dados para o campo Conta Patrimonio Liquido',
																labelText: 'Conta Patrimonio Liquido',
																usePadding: true,
															),
															onSaved: (String? value) {},
															onChanged: (text) {
																contabilParametroController.currentModel.contaPatrimonioLiquido = text;
																contabilParametroController.formWasChanged = true;
															},
														),
													),
												),
											],
										),
										const Divider(
											color: Colors.transparent,
										),
										BootstrapRow(
											height: 60,
											children: <BootstrapCol>[
												BootstrapCol(
													sizes: 'col-12 col-md-4',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: TextFormField(
															autofocus: true,
															maxLength: 30,
															controller: contabilParametroController.contaDepreciacaoAcumuladaController,
															decoration: inputDecoration(
																hintText: 'Informe os dados para o campo Conta Depreciacao Acumulada',
																labelText: 'Conta Depreciacao Acumulada',
																usePadding: true,
															),
															onSaved: (String? value) {},
															onChanged: (text) {
																contabilParametroController.currentModel.contaDepreciacaoAcumulada = text;
																contabilParametroController.formWasChanged = true;
															},
														),
													),
												),
												BootstrapCol(
													sizes: 'col-12 col-md-4',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: TextFormField(
															autofocus: true,
															maxLength: 30,
															controller: contabilParametroController.contaCapitalSocialController,
															decoration: inputDecoration(
																hintText: 'Informe os dados para o campo Conta Capital Social',
																labelText: 'Conta Capital Social',
																usePadding: true,
															),
															onSaved: (String? value) {},
															onChanged: (text) {
																contabilParametroController.currentModel.contaCapitalSocial = text;
																contabilParametroController.formWasChanged = true;
															},
														),
													),
												),
												BootstrapCol(
													sizes: 'col-12 col-md-4',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: TextFormField(
															autofocus: true,
															maxLength: 30,
															controller: contabilParametroController.contaResultadoExercicioController,
															decoration: inputDecoration(
																hintText: 'Informe os dados para o campo Conta Resultado Exercicio',
																labelText: 'Conta Resultado Exercicio',
																usePadding: true,
															),
															onSaved: (String? value) {},
															onChanged: (text) {
																contabilParametroController.currentModel.contaResultadoExercicio = text;
																contabilParametroController.formWasChanged = true;
															},
														),
													),
												),
											],
										),
										const Divider(
											color: Colors.transparent,
										),
										BootstrapRow(
											height: 60,
											children: <BootstrapCol>[
												BootstrapCol(
													sizes: 'col-12 col-md-4',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: TextFormField(
															autofocus: true,
															maxLength: 30,
															controller: contabilParametroController.contaPrejuizoAcumuladoController,
															decoration: inputDecoration(
																hintText: 'Informe os dados para o campo Conta Prejuizo Acumulado',
																labelText: 'Conta Prejuizo Acumulado',
																usePadding: true,
															),
															onSaved: (String? value) {},
															onChanged: (text) {
																contabilParametroController.currentModel.contaPrejuizoAcumulado = text;
																contabilParametroController.formWasChanged = true;
															},
														),
													),
												),
												BootstrapCol(
													sizes: 'col-12 col-md-4',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: TextFormField(
															autofocus: true,
															maxLength: 30,
															controller: contabilParametroController.contaLucroAcumuladoController,
															decoration: inputDecoration(
																hintText: 'Informe os dados para o campo Conta Lucro Acumulado',
																labelText: 'Conta Lucro Acumulado',
																usePadding: true,
															),
															onSaved: (String? value) {},
															onChanged: (text) {
																contabilParametroController.currentModel.contaLucroAcumulado = text;
																contabilParametroController.formWasChanged = true;
															},
														),
													),
												),
												BootstrapCol(
													sizes: 'col-12 col-md-4',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: TextFormField(
															autofocus: true,
															maxLength: 30,
															controller: contabilParametroController.contaTituloPagarController,
															decoration: inputDecoration(
																hintText: 'Informe os dados para o campo Conta Titulo Pagar',
																labelText: 'Conta Titulo Pagar',
																usePadding: true,
															),
															onSaved: (String? value) {},
															onChanged: (text) {
																contabilParametroController.currentModel.contaTituloPagar = text;
																contabilParametroController.formWasChanged = true;
															},
														),
													),
												),
											],
										),
										const Divider(
											color: Colors.transparent,
										),
										BootstrapRow(
											height: 60,
											children: <BootstrapCol>[
												BootstrapCol(
													sizes: 'col-12 col-md-4',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: TextFormField(
															autofocus: true,
															maxLength: 30,
															controller: contabilParametroController.contaTituloReceberController,
															decoration: inputDecoration(
																hintText: 'Informe os dados para o campo Conta Titulo Receber',
																labelText: 'Conta Titulo Receber',
																usePadding: true,
															),
															onSaved: (String? value) {},
															onChanged: (text) {
																contabilParametroController.currentModel.contaTituloReceber = text;
																contabilParametroController.formWasChanged = true;
															},
														),
													),
												),
												BootstrapCol(
													sizes: 'col-12 col-md-4',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: TextFormField(
															autofocus: true,
															maxLength: 30,
															controller: contabilParametroController.contaJurosPassivoController,
															decoration: inputDecoration(
																hintText: 'Informe os dados para o campo Conta Juros Passivo',
																labelText: 'Conta Juros Passivo',
																usePadding: true,
															),
															onSaved: (String? value) {},
															onChanged: (text) {
																contabilParametroController.currentModel.contaJurosPassivo = text;
																contabilParametroController.formWasChanged = true;
															},
														),
													),
												),
												BootstrapCol(
													sizes: 'col-12 col-md-4',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: TextFormField(
															autofocus: true,
															maxLength: 30,
															controller: contabilParametroController.contaJurosAtivoController,
															decoration: inputDecoration(
																hintText: 'Informe os dados para o campo Conta Juros Ativo',
																labelText: 'Conta Juros Ativo',
																usePadding: true,
															),
															onSaved: (String? value) {},
															onChanged: (text) {
																contabilParametroController.currentModel.contaJurosAtivo = text;
																contabilParametroController.formWasChanged = true;
															},
														),
													),
												),
											],
										),
										const Divider(
											color: Colors.transparent,
										),
										BootstrapRow(
											height: 60,
											children: <BootstrapCol>[
												BootstrapCol(
													sizes: 'col-12 col-md-4',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: TextFormField(
															autofocus: true,
															maxLength: 30,
															controller: contabilParametroController.contaDescontoObtidoController,
															decoration: inputDecoration(
																hintText: 'Informe os dados para o campo Conta Desconto Obtido',
																labelText: 'Conta Desconto Obtido',
																usePadding: true,
															),
															onSaved: (String? value) {},
															onChanged: (text) {
																contabilParametroController.currentModel.contaDescontoObtido = text;
																contabilParametroController.formWasChanged = true;
															},
														),
													),
												),
												BootstrapCol(
													sizes: 'col-12 col-md-4',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: TextFormField(
															autofocus: true,
															maxLength: 30,
															controller: contabilParametroController.contaDescontoConcedidoController,
															decoration: inputDecoration(
																hintText: 'Informe os dados para o campo Conta Desconto Concedido',
																labelText: 'Conta Desconto Concedido',
																usePadding: true,
															),
															onSaved: (String? value) {},
															onChanged: (text) {
																contabilParametroController.currentModel.contaDescontoConcedido = text;
																contabilParametroController.formWasChanged = true;
															},
														),
													),
												),
												BootstrapCol(
													sizes: 'col-12 col-md-4',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: TextFormField(
															autofocus: true,
															maxLength: 30,
															controller: contabilParametroController.contaCmvController,
															decoration: inputDecoration(
																hintText: 'Informe os dados para o campo Conta Cmv',
																labelText: 'Conta Cmv',
																usePadding: true,
															),
															onSaved: (String? value) {},
															onChanged: (text) {
																contabilParametroController.currentModel.contaCmv = text;
																contabilParametroController.formWasChanged = true;
															},
														),
													),
												),
											],
										),
										const Divider(
											color: Colors.transparent,
										),
										BootstrapRow(
											height: 60,
											children: <BootstrapCol>[
												BootstrapCol(
													sizes: 'col-12 col-md-4',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: TextFormField(
															autofocus: true,
															maxLength: 30,
															controller: contabilParametroController.contaVendaController,
															decoration: inputDecoration(
																hintText: 'Informe os dados para o campo Conta Venda',
																labelText: 'Conta Venda',
																usePadding: true,
															),
															onSaved: (String? value) {},
															onChanged: (text) {
																contabilParametroController.currentModel.contaVenda = text;
																contabilParametroController.formWasChanged = true;
															},
														),
													),
												),
												BootstrapCol(
													sizes: 'col-12 col-md-4',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: TextFormField(
															autofocus: true,
															maxLength: 30,
															controller: contabilParametroController.contaVendaServicoController,
															decoration: inputDecoration(
																hintText: 'Informe os dados para o campo Conta Venda Servico',
																labelText: 'Conta Venda Servico',
																usePadding: true,
															),
															onSaved: (String? value) {},
															onChanged: (text) {
																contabilParametroController.currentModel.contaVendaServico = text;
																contabilParametroController.formWasChanged = true;
															},
														),
													),
												),
												BootstrapCol(
													sizes: 'col-12 col-md-4',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: TextFormField(
															autofocus: true,
															maxLength: 30,
															controller: contabilParametroController.contaEstoqueController,
															decoration: inputDecoration(
																hintText: 'Informe os dados para o campo Conta Estoque',
																labelText: 'Conta Estoque',
																usePadding: true,
															),
															onSaved: (String? value) {},
															onChanged: (text) {
																contabilParametroController.currentModel.contaEstoque = text;
																contabilParametroController.formWasChanged = true;
															},
														),
													),
												),
											],
										),
										const Divider(
											color: Colors.transparent,
										),
										BootstrapRow(
											height: 60,
											children: <BootstrapCol>[
												BootstrapCol(
													sizes: 'col-12 col-md-6',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: TextFormField(
															autofocus: true,
															maxLength: 30,
															controller: contabilParametroController.contaApuraResultadoController,
															decoration: inputDecoration(
																hintText: 'Informe os dados para o campo Conta Apura Resultado',
																labelText: 'Conta Apura Resultado',
																usePadding: true,
															),
															onSaved: (String? value) {},
															onChanged: (text) {
																contabilParametroController.currentModel.contaApuraResultado = text;
																contabilParametroController.formWasChanged = true;
															},
														),
													),
												),
												BootstrapCol(
													sizes: 'col-12 col-md-6',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: TextFormField(
															autofocus: true,
															maxLength: 30,
															controller: contabilParametroController.contaJurosApropriarController,
															decoration: inputDecoration(
																hintText: 'Informe os dados para o campo Conta Juros Apropriar',
																labelText: 'Conta Juros Apropriar',
																usePadding: true,
															),
															onSaved: (String? value) {},
															onChanged: (text) {
																contabilParametroController.currentModel.contaJurosApropriar = text;
																contabilParametroController.formWasChanged = true;
															},
														),
													),
												),
											],
										),
										const Divider(
											color: Colors.transparent,
										),
										BootstrapRow(
											height: 60,
											children: <BootstrapCol>[
												BootstrapCol(
													sizes: 'col-12 col-md-4',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: TextFormField(
															autofocus: true,
															controller: contabilParametroController.idHistPadraoResultadoController,
															decoration: inputDecoration(
																hintText: 'Informe os dados para o campo Id Hist Padrao Resultado',
																labelText: 'Id Hist Padrao Resultado',
																usePadding: true,
															),
															onSaved: (String? value) {},
															onChanged: (text) {
																contabilParametroController.currentModel.idHistPadraoResultado = int.tryParse(text);
																contabilParametroController.formWasChanged = true;
															},
														),
													),
												),
												BootstrapCol(
													sizes: 'col-12 col-md-4',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: TextFormField(
															autofocus: true,
															controller: contabilParametroController.idHistPadraoLucroController,
															decoration: inputDecoration(
																hintText: 'Informe os dados para o campo Id Hist Padrao Lucro',
																labelText: 'Id Hist Padrao Lucro',
																usePadding: true,
															),
															onSaved: (String? value) {},
															onChanged: (text) {
																contabilParametroController.currentModel.idHistPadraoLucro = int.tryParse(text);
																contabilParametroController.formWasChanged = true;
															},
														),
													),
												),
												BootstrapCol(
													sizes: 'col-12 col-md-4',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: TextFormField(
															autofocus: true,
															controller: contabilParametroController.idHistPadraoPrejuizoController,
															decoration: inputDecoration(
																hintText: 'Informe os dados para o campo Id Hist Padrao Prejuizo',
																labelText: 'Id Hist Padrao Prejuizo',
																usePadding: true,
															),
															onSaved: (String? value) {},
															onChanged: (text) {
																contabilParametroController.currentModel.idHistPadraoPrejuizo = int.tryParse(text);
																contabilParametroController.formWasChanged = true;
															},
														),
													),
												),
											],
										),
										const Divider(
											indent: 10,
											endIndent: 10,
											thickness: 2,
										),
										BootstrapRow(
											height: 60,
											children: <BootstrapCol>[
												BootstrapCol(
													sizes: 'col-12',
													child: Text(
														'field_is_mandatory'.tr,
														style: Theme.of(context).textTheme.bodySmall,
													),
												),
											],
										),
										const SizedBox(height: 10.0),
									],
								),
							),
						),
					),
				),
			),
		);
	}
}
