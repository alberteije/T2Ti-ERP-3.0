import 'package:flutter/material.dart';
import 'package:flutter_bootstrap/flutter_bootstrap.dart';
import 'package:get/get.dart';
import 'package:contabil/app/page/shared_widget/shared_widget_imports.dart';
import 'package:contabil/app/data/domain/domain_imports.dart';
import 'package:contabil/app/controller/contabil_termo_controller.dart';
import 'package:contabil/app/infra/infra_imports.dart';
import 'package:contabil/app/page/shared_widget/input/input_imports.dart';

class ContabilTermoEditPage extends StatelessWidget {
	ContabilTermoEditPage({Key? key}) : super(key: key);
	final contabilTermoController = Get.find<ContabilTermoController>();

	@override
	Widget build(BuildContext context) {
			return Scaffold(
				key: contabilTermoController.contabilTermoScaffoldKey,	
				appBar: AppBar(
					automaticallyImplyLeading: false,
					title: Text('${ contabilTermoController.screenTitle } - ${ contabilTermoController.isNewRecord ? 'inserting'.tr : 'editing'.tr }',),
					actions: [
						saveButton(onPressed: contabilTermoController.save),
						cancelAndExitButton(onPressed: contabilTermoController.preventDataLoss),
					]
				),
				body: SafeArea(
					top: false,
					bottom: false,
					child: Form(
						key: contabilTermoController.contabilTermoFormKey,
						autovalidateMode: AutovalidateMode.always,
						child: Scrollbar(
							controller: contabilTermoController.scrollController,
							child: SingleChildScrollView(
								controller: contabilTermoController.scrollController,
								child: BootstrapContainer(
									fluid: true,
									padding: const EdgeInsets.all(10.0),
									children: <Widget>[
										const Divider(
											color: Colors.transparent,
										),
										BootstrapRow(
											height: 60,
											children: <BootstrapCol>[
												BootstrapCol(
													sizes: 'col-12 col-md-3',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: CustomDropdownButton(
															controller: contabilTermoController.aberturaEncerramentoController,
															labelText: 'Abertura Encerramento',
															hintText: 'Informe os dados para o campo Abertura Encerramento',
															items: ContabilTermoDomain.aberturaEncerramentoListDropdown,
															onChanged: (dynamic newValue) {
																contabilTermoController.contabilTermoModel.aberturaEncerramento = newValue;
																contabilTermoController.formWasChangedDetail = true;
															},
														),
													),
												),
												BootstrapCol(
													sizes: 'col-12 col-md-3',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: TextFormField(
															autofocus: true,
															controller: contabilTermoController.numeroController,
															decoration: inputDecoration(
																hintText: 'Informe os dados para o campo Numero',
																labelText: 'Numero',
																usePadding: true,
															),
															onSaved: (String? value) {},
															onChanged: (text) {
																contabilTermoController.contabilTermoModel.numero = int.tryParse(text);
																contabilTermoController.formWasChangedDetail = true;
															},
														),
													),
												),
												BootstrapCol(
													sizes: 'col-12 col-md-3',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: TextFormField(
															autofocus: true,
															controller: contabilTermoController.paginaInicialController,
															decoration: inputDecoration(
																hintText: 'Informe os dados para o campo Pagina Inicial',
																labelText: 'Pagina Inicial',
																usePadding: true,
															),
															onSaved: (String? value) {},
															onChanged: (text) {
																contabilTermoController.contabilTermoModel.paginaInicial = int.tryParse(text);
																contabilTermoController.formWasChangedDetail = true;
															},
														),
													),
												),
												BootstrapCol(
													sizes: 'col-12 col-md-3',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: TextFormField(
															autofocus: true,
															controller: contabilTermoController.paginaFinalController,
															decoration: inputDecoration(
																hintText: 'Informe os dados para o campo Pagina Final',
																labelText: 'Pagina Final',
																usePadding: true,
															),
															onSaved: (String? value) {},
															onChanged: (text) {
																contabilTermoController.contabilTermoModel.paginaFinal = int.tryParse(text);
																contabilTermoController.formWasChangedDetail = true;
															},
														),
													),
												),
											],
										),
										const Divider(
											color: Colors.transparent,
										),
										BootstrapRow(
											height: 60,
											children: <BootstrapCol>[
												BootstrapCol(
													sizes: 'col-12',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: TextFormField(
															autofocus: true,
															maxLength: 100,
															controller: contabilTermoController.registradoController,
															decoration: inputDecoration(
																hintText: 'Informe os dados para o campo Registrado',
																labelText: 'Registrado',
																usePadding: true,
															),
															onSaved: (String? value) {},
															onChanged: (text) {
																contabilTermoController.contabilTermoModel.registrado = text;
																contabilTermoController.formWasChangedDetail = true;
															},
														),
													),
												),
											],
										),
										const Divider(
											color: Colors.transparent,
										),
										BootstrapRow(
											height: 60,
											children: <BootstrapCol>[
												BootstrapCol(
													sizes: 'col-12',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: TextFormField(
															autofocus: true,
															maxLength: 50,
															controller: contabilTermoController.numeroRegistroController,
															decoration: inputDecoration(
																hintText: 'Informe os dados para o campo Numero Registro',
																labelText: 'Numero Registro',
																usePadding: true,
															),
															onSaved: (String? value) {},
															onChanged: (text) {
																contabilTermoController.contabilTermoModel.numeroRegistro = text;
																contabilTermoController.formWasChangedDetail = true;
															},
														),
													),
												),
											],
										),
										const Divider(
											color: Colors.transparent,
										),
										BootstrapRow(
											height: 60,
											children: <BootstrapCol>[
												BootstrapCol(
													sizes: 'col-12 col-md-2',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: InputDecorator(
															decoration: inputDecoration(
																hintText: 'Informe os dados para o campo Data Despacho',
																labelText: 'Data Despacho',
																usePadding: true,
															),
															isEmpty: false,
															child: DatePickerItem(
																controller: contabilTermoController.dataDespachoController,
																firstDate: DateTime.parse('1000-01-01'),
																lastDate: DateTime.parse('5000-01-01'),
																onChanged: (DateTime? value) {
																	contabilTermoController.contabilTermoModel.dataDespacho = value;
																	contabilTermoController.formWasChangedDetail = true;
																},
															),
														),
													),
												),
												BootstrapCol(
													sizes: 'col-12 col-md-2',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: InputDecorator(
															decoration: inputDecoration(
																hintText: 'Informe os dados para o campo Data Abertura',
																labelText: 'Data Abertura',
																usePadding: true,
															),
															isEmpty: false,
															child: DatePickerItem(
																controller: contabilTermoController.dataAberturaController,
																firstDate: DateTime.parse('1000-01-01'),
																lastDate: DateTime.parse('5000-01-01'),
																onChanged: (DateTime? value) {
																	contabilTermoController.contabilTermoModel.dataAbertura = value;
																	contabilTermoController.formWasChangedDetail = true;
																},
															),
														),
													),
												),
												BootstrapCol(
													sizes: 'col-12 col-md-2',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: InputDecorator(
															decoration: inputDecoration(
																hintText: 'Informe os dados para o campo Data Encerramento',
																labelText: 'Data Encerramento',
																usePadding: true,
															),
															isEmpty: false,
															child: DatePickerItem(
																controller: contabilTermoController.dataEncerramentoController,
																firstDate: DateTime.parse('1000-01-01'),
																lastDate: DateTime.parse('5000-01-01'),
																onChanged: (DateTime? value) {
																	contabilTermoController.contabilTermoModel.dataEncerramento = value;
																	contabilTermoController.formWasChangedDetail = true;
																},
															),
														),
													),
												),
												BootstrapCol(
													sizes: 'col-12 col-md-3',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: InputDecorator(
															decoration: inputDecoration(
																hintText: 'Informe os dados para o campo Escrituracao Inicio',
																labelText: 'Escrituracao Inicio',
																usePadding: true,
															),
															isEmpty: false,
															child: DatePickerItem(
																controller: contabilTermoController.escrituracaoInicioController,
																firstDate: DateTime.parse('1000-01-01'),
																lastDate: DateTime.parse('5000-01-01'),
																onChanged: (DateTime? value) {
																	contabilTermoController.contabilTermoModel.escrituracaoInicio = value;
																	contabilTermoController.formWasChangedDetail = true;
																},
															),
														),
													),
												),
												BootstrapCol(
													sizes: 'col-12 col-md-3',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: InputDecorator(
															decoration: inputDecoration(
																hintText: 'Informe os dados para o campo Escrituracao Fim',
																labelText: 'Escrituracao Fim',
																usePadding: true,
															),
															isEmpty: false,
															child: DatePickerItem(
																controller: contabilTermoController.escrituracaoFimController,
																firstDate: DateTime.parse('1000-01-01'),
																lastDate: DateTime.parse('5000-01-01'),
																onChanged: (DateTime? value) {
																	contabilTermoController.contabilTermoModel.escrituracaoFim = value;
																	contabilTermoController.formWasChangedDetail = true;
																},
															),
														),
													),
												),
											],
										),
										const Divider(
											color: Colors.transparent,
										),
										BootstrapRow(
											height: 60,
											children: <BootstrapCol>[
												BootstrapCol(
													sizes: 'col-12',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: TextFormField(
															autofocus: true,
															maxLines: 3,
															controller: contabilTermoController.textoController,
															decoration: inputDecoration(
																hintText: 'Informe os dados para o campo Texto',
																labelText: 'Texto',
																usePadding: true,
															),
															onSaved: (String? value) {},
															onChanged: (text) {
																contabilTermoController.contabilTermoModel.texto = text;
																contabilTermoController.formWasChangedDetail = true;
															},
														),
													),
												),
											],
										),
										const Divider(
											indent: 10,
											endIndent: 10,
											thickness: 2,
										),
										BootstrapRow(
											height: 60,
											children: <BootstrapCol>[
												BootstrapCol(
													sizes: 'col-12',
													child: Text(
														'field_is_mandatory'.tr,
														style: Theme.of(context).textTheme.bodySmall,
													),
												),
											],
										),
										const SizedBox(height: 10.0),
									],
								),
							),
						),
					),
				),
			);
	}
}
