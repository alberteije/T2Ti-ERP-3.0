import 'package:flutter/material.dart';
import 'package:flutter_bootstrap/flutter_bootstrap.dart';
import 'package:get/get.dart';
import 'package:contabil/app/page/shared_widget/shared_widget_imports.dart';
import 'package:contabil/app/data/domain/domain_imports.dart';
import 'package:contabil/app/controller/contabil_dre_detalhe_controller.dart';
import 'package:contabil/app/infra/infra_imports.dart';
import 'package:contabil/app/page/shared_widget/input/input_imports.dart';

class ContabilDreDetalheEditPage extends StatelessWidget {
	ContabilDreDetalheEditPage({Key? key}) : super(key: key);
	final contabilDreDetalheController = Get.find<ContabilDreDetalheController>();

	@override
	Widget build(BuildContext context) {
			return Scaffold(
				key: contabilDreDetalheController.contabilDreDetalheScaffoldKey,	
				appBar: AppBar(
					automaticallyImplyLeading: false,
					title: Text('${ contabilDreDetalheController.screenTitle } - ${ contabilDreDetalheController.isNewRecord ? 'inserting'.tr : 'editing'.tr }',),
					actions: [
						saveButton(onPressed: contabilDreDetalheController.save),
						cancelAndExitButton(onPressed: contabilDreDetalheController.preventDataLoss),
					]
				),
				body: SafeArea(
					top: false,
					bottom: false,
					child: Form(
						key: contabilDreDetalheController.contabilDreDetalheFormKey,
						autovalidateMode: AutovalidateMode.always,
						child: Scrollbar(
							controller: contabilDreDetalheController.scrollController,
							child: SingleChildScrollView(
								controller: contabilDreDetalheController.scrollController,
								child: BootstrapContainer(
									fluid: true,
									padding: const EdgeInsets.all(10.0),
									children: <Widget>[
										const Divider(
											color: Colors.transparent,
										),
										BootstrapRow(
											height: 60,
											children: <BootstrapCol>[
												BootstrapCol(
													sizes: 'col-12 col-md-4',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: TextFormField(
															autofocus: true,
															maxLength: 30,
															controller: contabilDreDetalheController.classificacaoController,
															decoration: inputDecoration(
																hintText: 'Informe os dados para o campo Classificacao',
																labelText: 'Classificacao',
																usePadding: true,
															),
															onSaved: (String? value) {},
															onChanged: (text) {
																contabilDreDetalheController.contabilDreDetalheModel.classificacao = text;
																contabilDreDetalheController.formWasChangedDetail = true;
															},
														),
													),
												),
												BootstrapCol(
													sizes: 'col-12 col-md-8',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: TextFormField(
															autofocus: true,
															maxLength: 100,
															controller: contabilDreDetalheController.descricaoController,
															decoration: inputDecoration(
																hintText: 'Informe os dados para o campo Descricao',
																labelText: 'Descricao',
																usePadding: true,
															),
															onSaved: (String? value) {},
															onChanged: (text) {
																contabilDreDetalheController.contabilDreDetalheModel.descricao = text;
																contabilDreDetalheController.formWasChangedDetail = true;
															},
														),
													),
												),
											],
										),
										const Divider(
											color: Colors.transparent,
										),
										BootstrapRow(
											height: 60,
											children: <BootstrapCol>[
												BootstrapCol(
													sizes: 'col-12 col-md-3',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: CustomDropdownButton(
															controller: contabilDreDetalheController.formaCalculoController,
															labelText: 'Forma Calculo',
															hintText: 'Informe os dados para o campo Forma Calculo',
															items: ContabilDreDetalheDomain.formaCalculoListDropdown,
															onChanged: (dynamic newValue) {
																contabilDreDetalheController.contabilDreDetalheModel.formaCalculo = newValue;
																contabilDreDetalheController.formWasChangedDetail = true;
															},
														),
													),
												),
												BootstrapCol(
													sizes: 'col-12 col-md-3',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: CustomDropdownButton(
															controller: contabilDreDetalheController.sinalController,
															labelText: 'Sinal',
															hintText: 'Informe os dados para o campo Sinal',
															items: ContabilDreDetalheDomain.sinalListDropdown,
															onChanged: (dynamic newValue) {
																contabilDreDetalheController.contabilDreDetalheModel.sinal = newValue;
																contabilDreDetalheController.formWasChangedDetail = true;
															},
														),
													),
												),
												BootstrapCol(
													sizes: 'col-12 col-md-3',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: CustomDropdownButton(
															controller: contabilDreDetalheController.naturezaController,
															labelText: 'Natureza',
															hintText: 'Informe os dados para o campo Natureza',
															items: ContabilDreDetalheDomain.naturezaListDropdown,
															onChanged: (dynamic newValue) {
																contabilDreDetalheController.contabilDreDetalheModel.natureza = newValue;
																contabilDreDetalheController.formWasChangedDetail = true;
															},
														),
													),
												),
												BootstrapCol(
													sizes: 'col-12 col-md-3',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: TextFormField(
															autofocus: true,
															controller: contabilDreDetalheController.valorController,
															decoration: inputDecoration(
																hintText: 'Informe os dados para o campo Valor',
																labelText: 'Valor',
																usePadding: true,
															),
															onSaved: (String? value) {},
															onChanged: (text) {
																contabilDreDetalheController.contabilDreDetalheModel.valor = contabilDreDetalheController.valorController.numberValue;
																contabilDreDetalheController.formWasChangedDetail = true;
															},
														),
													),
												),
											],
										),
										const Divider(
											indent: 10,
											endIndent: 10,
											thickness: 2,
										),
										BootstrapRow(
											height: 60,
											children: <BootstrapCol>[
												BootstrapCol(
													sizes: 'col-12',
													child: Text(
														'field_is_mandatory'.tr,
														style: Theme.of(context).textTheme.bodySmall,
													),
												),
											],
										),
										const SizedBox(height: 10.0),
									],
								),
							),
						),
					),
				),
			);
	}
}
