import 'package:flutter/material.dart';
import 'package:flutter_bootstrap/flutter_bootstrap.dart';
import 'package:get/get.dart';
import 'package:contabil/app/page/shared_widget/shared_widget_imports.dart';
import 'package:contabil/app/data/domain/domain_imports.dart';
import 'package:contabil/app/controller/centro_resultado_controller.dart';
import 'package:contabil/app/infra/infra_imports.dart';
import 'package:contabil/app/page/shared_widget/input/input_imports.dart';

class CentroResultadoEditPage extends StatelessWidget {
	CentroResultadoEditPage({Key? key}) : super(key: key);
	final centroResultadoController = Get.find<CentroResultadoController>();

	@override
	Widget build(BuildContext context) {
			return Scaffold(
				key: centroResultadoController.centroResultadoScaffoldKey,
				body: SafeArea(
					top: false,
					bottom: false,
					child: Form(
						key: centroResultadoController.centroResultadoFormKey,
						autovalidateMode: AutovalidateMode.always,
						child: Scrollbar(
							controller: centroResultadoController.scrollController,
							child: SingleChildScrollView(
								controller: centroResultadoController.scrollController,
								child: BootstrapContainer(
									fluid: true,
									padding: const EdgeInsets.all(10),
									children: <Widget>[
										const Divider(
											color: Colors.transparent,
										),
										BootstrapRow(
											height: 60,
											children: <BootstrapCol>[
												BootstrapCol(
													sizes: 'col-12',
													child: Row(
														children: <Widget>[
															Expanded(
																flex: 1,
																child: SizedBox(
																	child: TextFormField(
																		controller: centroResultadoController.planoCentroResultadoModelController,
																		validator: ValidateFormField.validateMandatory,
																		readOnly: true,
																		decoration: inputDecoration(
																			hintText: 'Informe os dados para o campo Informe os dados para o campo Plano Centro Resultado',
																			labelText: 'Plano Centro Resultado *',
																			usePadding: true,
																		),
																		onSaved: (String? value) {},
																		onChanged: (text) {},
																	),
																),
															),
															Expanded(
																flex: 0,
																child: lookupButton(onPressed: centroResultadoController.callPlanoCentroResultadoLookup),
															),
														],
													),
												),
											],
										),
										const Divider(
											color: Colors.transparent,
										),
										BootstrapRow(
											height: 60,
											children: <BootstrapCol>[
												BootstrapCol(
													sizes: 'col-12',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: TextFormField(
															autofocus: true,
															maxLength: 100,
															controller: centroResultadoController.descricaoController,
															decoration: inputDecoration(
																hintText: 'Informe os dados para o campo Descricao',
																labelText: 'Descricao',
																usePadding: true,
															),
															onSaved: (String? value) {},
															onChanged: (text) {
																centroResultadoController.currentModel.descricao = text;
																centroResultadoController.formWasChanged = true;
															},
														),
													),
												),
											],
										),
										const Divider(
											color: Colors.transparent,
										),
										BootstrapRow(
											height: 60,
											children: <BootstrapCol>[
												BootstrapCol(
													sizes: 'col-12 col-md-6',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: TextFormField(
															autofocus: true,
															maxLength: 30,
															controller: centroResultadoController.classificacaoController,
															decoration: inputDecoration(
																hintText: 'Informe os dados para o campo Classificacao',
																labelText: 'Classificacao',
																usePadding: true,
															),
															onSaved: (String? value) {},
															onChanged: (text) {
																centroResultadoController.currentModel.classificacao = text;
																centroResultadoController.formWasChanged = true;
															},
														),
													),
												),
												BootstrapCol(
													sizes: 'col-12 col-md-6',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: CustomDropdownButton(
															controller: centroResultadoController.sofreRateiroController,
															labelText: 'Sofre Rateiro',
															hintText: 'Informe os dados para o campo Sofre Rateiro',
															items: CentroResultadoDomain.sofreRateiroListDropdown,
															onChanged: (dynamic newValue) {
																centroResultadoController.currentModel.sofreRateiro = newValue;
																centroResultadoController.formWasChanged = true;
															},
														),
													),
												),
											],
										),
										const Divider(
											indent: 10,
											endIndent: 10,
											thickness: 2,
										),
										BootstrapRow(
											height: 60,
											children: <BootstrapCol>[
												BootstrapCol(
													sizes: 'col-12',
													child: Text(
														'field_is_mandatory'.tr,
														style: Theme.of(context).textTheme.bodySmall,
													),
												),
											],
										),
										const SizedBox(height: 10.0),
									],
								),
							),
						),
					),
				),
			);
	}
}
