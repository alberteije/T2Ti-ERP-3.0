import 'package:flutter/material.dart';
import 'package:contabil/app/controller/aidf_aimdf_controller.dart';
import 'package:contabil/app/page/shared_page/list_page_base.dart';

class AidfAimdfListPage extends ListPageBase<AidfAimdfController> {
  const AidfAimdfListPage({Key? key}) : super(key: key);

  @override
  List<Map<String, dynamic>> get mobileItems => controller.mobileItems;

  @override
  Map<String, dynamic> get mobileConfig => controller.mobileConfig;

  @override
  String get standardFieldForFilter => controller.standardFieldForFilter;
}