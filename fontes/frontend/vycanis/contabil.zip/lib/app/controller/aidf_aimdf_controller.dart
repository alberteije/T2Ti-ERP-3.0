import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:extended_masked_text/extended_masked_text.dart';
import 'package:contabil/app/page/shared_widget/input/input_imports.dart';

import 'package:contabil/app/page/shared_widget/message_dialog.dart';
import 'package:contabil/app/page/grid_columns/grid_columns_imports.dart';
import 'package:contabil/app/routes/app_routes.dart';
import 'package:contabil/app/controller/controller_imports.dart';
import 'package:contabil/app/data/model/model_imports.dart';
import 'package:contabil/app/data/repository/aidf_aimdf_repository.dart';

class AidfAimdfController extends ControllerBase<AidfAimdfModel, AidfAimdfRepository> {

  AidfAimdfController({required super.repository}) {
    dbColumns = AidfAimdfModel.dbColumns;
    aliasColumns = AidfAimdfModel.aliasColumns;
    gridColumns = aidfAimdfGridColumns();
    functionName = "aidf_aimdf";
    screenTitle = "AIDF";
  }

  @override
  AidfAimdfModel createNewModel() => AidfAimdfModel();

  @override
  final standardFieldForFilter = AidfAimdfModel.aliasColumns[AidfAimdfModel.dbColumns.indexOf('numero')];

  final numeroController = MoneyMaskedTextController(precision: 0, decimalSeparator: '', thousandSeparator: '');
  final dataValidadeController = DatePickerItemController(null);
  final dataAutorizacaoController = DatePickerItemController(null);
  final numeroAutorizacaoController = TextEditingController();
  final formularioDisponivelController = CustomDropdownButtonController('Sim');

  final Map<String, dynamic> mobileConfig = {
    'primaryColumns': ['numero'],
    'secondaryColumns': ['data_validade'],
  };

  List<Map<String, dynamic>> get mobileItems {
    return modelList.map((aidfAimdf) => aidfAimdf.toJson).toList();
  }

  @override
  void prepareForInsert() {
    isNewRecord = true;
    currentModel = createNewModel();
    _resetForm();
    Get.toNamed(Routes.aidfAimdfEditPage);
  }

  void _resetForm() {
    formWasChanged = false;
    numeroController.updateValue(0);
    dataValidadeController.date = null;
    dataAutorizacaoController.date = null;
    numeroAutorizacaoController.text = '';
    formularioDisponivelController.selected = 'Sim';
  }

  @override
  void selectRowForEditingById(int id) {
    final model = modelList.firstWhere((m) => m.id == id);
    currentModel = model.clone();
    updateControllersFromModel();
    Get.toNamed(Routes.aidfAimdfEditPage);
  }

  void updateControllersFromModel() {
    numeroController.updateValue((currentModel.numero ?? 0).toDouble());
    dataValidadeController.date = currentModel.dataValidade;
    dataAutorizacaoController.date = currentModel.dataAutorizacao;
    numeroAutorizacaoController.text = currentModel.numeroAutorizacao ?? '';
    formularioDisponivelController.selected = currentModel.formularioDisponivel ?? 'Sim';
    formWasChanged = false;
  }

  @override
  Future<void> save() async {
    if (!formKey.currentState!.validate()) {
      showErrorSnackBar(message: 'validator_form_message'.tr);
      return;
    }

    final existingIndex = modelList.indexWhere((m) => m.id == currentModel.id);

    if (existingIndex >= 0) {
      modelList[existingIndex] = currentModel.clone();
    }

    final result = await repository.save(aidfAimdfModel: currentModel);
    if (result == null) return;

    if (existingIndex >= 0) {
      modelList[existingIndex] = result;
    } else {
      modelList.insert(0, result);
    }

    if (!GetPlatform.isMobile) {
      updateGridRow(result);
    }

    Get.back(result: true);
  }


  @override
  void onClose() {
    numeroController.dispose();
    dataValidadeController.dispose();
    dataAutorizacaoController.dispose();
    numeroAutorizacaoController.dispose();
    formularioDisponivelController.dispose();
    super.onClose();
  }

}