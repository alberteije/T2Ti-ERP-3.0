import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:extended_masked_text/extended_masked_text.dart';

import 'package:contabil/app/page/shared_widget/message_dialog.dart';
import 'package:contabil/app/page/grid_columns/grid_columns_imports.dart';
import 'package:contabil/app/routes/app_routes.dart';
import 'package:contabil/app/controller/controller_imports.dart';
import 'package:contabil/app/data/model/model_imports.dart';
import 'package:contabil/app/data/repository/contabil_conta_rateio_repository.dart';

class ContabilContaRateioController extends ControllerBase<ContabilContaRateioModel, ContabilContaRateioRepository> {

  ContabilContaRateioController({required super.repository}) {
    dbColumns = ContabilContaRateioModel.dbColumns;
    aliasColumns = ContabilContaRateioModel.aliasColumns;
    gridColumns = contabilContaRateioGridColumns();
    functionName = "contabil_conta_rateio";
    screenTitle = "Rateio Conta Contábil";
  }

  @override
  ContabilContaRateioModel createNewModel() => ContabilContaRateioModel();

  @override
  final standardFieldForFilter = ContabilContaRateioModel.aliasColumns[ContabilContaRateioModel.dbColumns.indexOf('porcento_rateio')];

  final centroResultadoModelController = TextEditingController();
  final contabilContaModelController = TextEditingController();
  final porcentoRateioController = MoneyMaskedTextController();

  final Map<String, dynamic> mobileConfig = {
    'primaryColumns': ['porcento_rateio'],
    'secondaryColumns': [],
  };

  List<Map<String, dynamic>> get mobileItems {
    return modelList.map((contabilContaRateio) => contabilContaRateio.toJson).toList();
  }

  @override
  void prepareForInsert() {
    isNewRecord = true;
    currentModel = createNewModel();
    _resetForm();
    Get.toNamed(Routes.contabilContaRateioEditPage);
  }

  void _resetForm() {
    formWasChanged = false;
    centroResultadoModelController.text = '';
    contabilContaModelController.text = '';
    porcentoRateioController.updateValue(0);
  }

  @override
  void selectRowForEditingById(int id) {
    final model = modelList.firstWhere((m) => m.id == id);
    currentModel = model.clone();
    updateControllersFromModel();
    Get.toNamed(Routes.contabilContaRateioEditPage);
  }

  void updateControllersFromModel() {
    centroResultadoModelController.text = currentModel.centroResultadoModel?.descricao?.toString() ?? '';
    contabilContaModelController.text = currentModel.contabilContaModel?.descricao?.toString() ?? '';
    porcentoRateioController.updateValue(currentModel.porcentoRateio ?? 0);
    formWasChanged = false;
  }

  @override
  Future<void> save() async {
    if (!formKey.currentState!.validate()) {
      showErrorSnackBar(message: 'validator_form_message'.tr);
      return;
    }

    final existingIndex = modelList.indexWhere((m) => m.id == currentModel.id);

    if (existingIndex >= 0) {
      modelList[existingIndex] = currentModel.clone();
    }

    final result = await repository.save(contabilContaRateioModel: currentModel);
    if (result == null) return;

    if (existingIndex >= 0) {
      modelList[existingIndex] = result;
    } else {
      modelList.insert(0, result);
    }

    if (!GetPlatform.isMobile) {
      updateGridRow(result);
    }

    Get.back(result: true);
  }

  Future callCentroResultadoLookup() async { 
		final lookupController = Get.find<LookupController>(); 
		lookupController.refreshItems(standardValue: '%'); 
		lookupController.title = '${'lookup_page_title'.tr} [Centro Resultado]'; 
		lookupController.route = '/centro-resultado/'; 
		lookupController.gridColumns = centroResultadoGridColumns(isForLookup: true); 
		lookupController.aliasColumns = CentroResultadoModel.aliasColumns; 
		lookupController.dbColumns = CentroResultadoModel.dbColumns; 
		lookupController.standardColumn = CentroResultadoModel.aliasColumns[CentroResultadoModel.dbColumns.indexOf('descricao')]; 

		final plutoRowResult = await Get.toNamed(Routes.lookupPage); 
		if (plutoRowResult != null) { 
			currentModel.idCentroResultado = plutoRowResult.cells['id']!.value; 
			currentModel.centroResultadoModel = CentroResultadoModel.fromPlutoRow(plutoRowResult); 
			centroResultadoModelController.text = currentModel.centroResultadoModel?.descricao ?? ''; 
			formWasChanged = true; 
		}
	}

  Future callContabilContaLookup() async { 
		final lookupController = Get.find<LookupController>(); 
		lookupController.refreshItems(standardValue: '%'); 
		lookupController.title = '${'lookup_page_title'.tr} [Conta Contábil]'; 
		lookupController.route = '/contabil-conta/'; 
		lookupController.gridColumns = contabilContaGridColumns(isForLookup: true); 
		lookupController.aliasColumns = ContabilContaModel.aliasColumns; 
		lookupController.dbColumns = ContabilContaModel.dbColumns; 
		lookupController.standardColumn = ContabilContaModel.aliasColumns[ContabilContaModel.dbColumns.indexOf('descricao')]; 

		final plutoRowResult = await Get.toNamed(Routes.lookupPage); 
		if (plutoRowResult != null) { 
			currentModel.idContabilConta = plutoRowResult.cells['id']!.value; 
			currentModel.contabilContaModel = ContabilContaModel.fromPlutoRow(plutoRowResult); 
			contabilContaModelController.text = currentModel.contabilContaModel?.descricao ?? ''; 
			formWasChanged = true; 
		}
	}


  @override
  void onClose() {
    centroResultadoModelController.dispose();
    contabilContaModelController.dispose();
    porcentoRateioController.dispose();
    super.onClose();
  }

}