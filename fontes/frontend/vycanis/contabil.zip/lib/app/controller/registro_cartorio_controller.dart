import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:extended_masked_text/extended_masked_text.dart';
import 'package:contabil/app/page/shared_widget/input/input_imports.dart';

import 'package:contabil/app/page/shared_widget/message_dialog.dart';
import 'package:contabil/app/page/grid_columns/grid_columns_imports.dart';
import 'package:contabil/app/routes/app_routes.dart';
import 'package:contabil/app/controller/controller_imports.dart';
import 'package:contabil/app/data/model/model_imports.dart';
import 'package:contabil/app/data/repository/registro_cartorio_repository.dart';

class RegistroCartorioController extends ControllerBase<RegistroCartorioModel, RegistroCartorioRepository> {

  RegistroCartorioController({required super.repository}) {
    dbColumns = RegistroCartorioModel.dbColumns;
    aliasColumns = RegistroCartorioModel.aliasColumns;
    gridColumns = registroCartorioGridColumns();
    functionName = "registro_cartorio";
    screenTitle = "Registro em Cartório";
  }

  @override
  RegistroCartorioModel createNewModel() => RegistroCartorioModel();

  @override
  final standardFieldForFilter = RegistroCartorioModel.aliasColumns[RegistroCartorioModel.dbColumns.indexOf('nome_cartorio')];

  final nomeCartorioController = TextEditingController();
  final dataRegistroController = DatePickerItemController(null);
  final numeroController = MoneyMaskedTextController(precision: 0, decimalSeparator: '', thousandSeparator: '');
  final folhaController = MoneyMaskedTextController(precision: 0, decimalSeparator: '', thousandSeparator: '');
  final livroController = MoneyMaskedTextController(precision: 0, decimalSeparator: '', thousandSeparator: '');
  final nireController = TextEditingController();

  final Map<String, dynamic> mobileConfig = {
    'primaryColumns': ['nome_cartorio'],
    'secondaryColumns': ['data_registro'],
  };

  List<Map<String, dynamic>> get mobileItems {
    return modelList.map((registroCartorio) => registroCartorio.toJson).toList();
  }

  @override
  void prepareForInsert() {
    isNewRecord = true;
    currentModel = createNewModel();
    _resetForm();
    Get.toNamed(Routes.registroCartorioEditPage);
  }

  void _resetForm() {
    formWasChanged = false;
    nomeCartorioController.text = '';
    dataRegistroController.date = null;
    numeroController.updateValue(0);
    folhaController.updateValue(0);
    livroController.updateValue(0);
    nireController.text = '';
  }

  @override
  void selectRowForEditingById(int id) {
    final model = modelList.firstWhere((m) => m.id == id);
    currentModel = model.clone();
    updateControllersFromModel();
    Get.toNamed(Routes.registroCartorioEditPage);
  }

  void updateControllersFromModel() {
    nomeCartorioController.text = currentModel.nomeCartorio ?? '';
    dataRegistroController.date = currentModel.dataRegistro;
    numeroController.updateValue((currentModel.numero ?? 0).toDouble());
    folhaController.updateValue((currentModel.folha ?? 0).toDouble());
    livroController.updateValue((currentModel.livro ?? 0).toDouble());
    nireController.text = currentModel.nire ?? '';
    formWasChanged = false;
  }

  @override
  Future<void> save() async {
    if (!formKey.currentState!.validate()) {
      showErrorSnackBar(message: 'validator_form_message'.tr);
      return;
    }

    final existingIndex = modelList.indexWhere((m) => m.id == currentModel.id);

    if (existingIndex >= 0) {
      modelList[existingIndex] = currentModel.clone();
    }

    final result = await repository.save(registroCartorioModel: currentModel);
    if (result == null) return;

    if (existingIndex >= 0) {
      modelList[existingIndex] = result;
    } else {
      modelList.insert(0, result);
    }

    if (!GetPlatform.isMobile) {
      updateGridRow(result);
    }

    Get.back(result: true);
  }


  @override
  void onClose() {
    nomeCartorioController.dispose();
    dataRegistroController.dispose();
    numeroController.dispose();
    folhaController.dispose();
    livroController.dispose();
    nireController.dispose();
    super.onClose();
  }

}