import 'package:flutter/material.dart';
import 'dart:math';
import 'package:get/get.dart';

import 'package:contabil/app/infra/infra_imports.dart';
import 'package:contabil/app/page/page_imports.dart';
import 'package:contabil/app/page/shared_widget/message_dialog.dart';
import 'package:contabil/app/page/grid_columns/grid_columns_imports.dart';
import 'package:contabil/app/routes/app_routes.dart';
import 'package:contabil/app/controller/controller_imports.dart';
import 'package:contabil/app/data/model/model_imports.dart';
import 'package:contabil/app/data/repository/rateio_centro_resultado_cab_repository.dart';

class RateioCentroResultadoCabController extends ControllerBase<RateioCentroResultadoCabModel, RateioCentroResultadoCabRepository> 
with GetSingleTickerProviderStateMixin {

  RateioCentroResultadoCabController({required super.repository}) {
    dbColumns = RateioCentroResultadoCabModel.dbColumns;
    aliasColumns = RateioCentroResultadoCabModel.aliasColumns;
    gridColumns = rateioCentroResultadoCabGridColumns();
    functionName = "rateio_centro_resultado_cab";
    screenTitle = "Rateio Centro Resultado";
  }

  final rateioCentroResultadoCabScaffoldKey = GlobalKey<ScaffoldState>();
  final rateioCentroResultadoCabTabPageScaffoldKey = GlobalKey<ScaffoldState>();
  final rateioCentroResultadoCabFormKey = GlobalKey<FormState>();
  late TabController tabController;
  String? mandatoryMessage;  

  @override
  RateioCentroResultadoCabModel createNewModel() => RateioCentroResultadoCabModel();

  @override
  final standardFieldForFilter = RateioCentroResultadoCabModel.aliasColumns[RateioCentroResultadoCabModel.dbColumns.indexOf('descricao')];

  final centroResultadoModelController = TextEditingController();
  final descricaoController = TextEditingController();

  final Map<String, dynamic> mobileConfig = {
    'primaryColumns': ['descricao'],
    'secondaryColumns': [],
  };

  List<Map<String, dynamic>> get mobileItems {
    return modelList.map((rateioCentroResultadoCab) => rateioCentroResultadoCab.toJson).toList();
  }

  @override
  void prepareForInsert() {
    isNewRecord = true;
    currentModel = createNewModel();
    _resetForm();
    tabController.animateTo(0);
    updateControllersFromModel();
    Get.toNamed(Routes.rateioCentroResultadoCabTabPage);
  }

  void _resetForm() {
    formWasChanged = false;
    centroResultadoModelController.text = '';
    descricaoController.text = '';
  }

  @override
  void selectRowForEditingById(int id) {
    final model = modelList.firstWhere((m) => m.id == id);
    currentModel = model.clone();
    updateControllersFromModel();
    tabController.animateTo(0);
    Get.toNamed(Routes.rateioCentroResultadoCabTabPage);
  }

  _configureChildrenControllers() {
    //Detalhes
		Get.put<RateioCentroResultadoDetController>(RateioCentroResultadoDetController()); 

  }
	
	_releaseChildrenControllers() {
    //Detalhes
		Get.delete<RateioCentroResultadoDetController>(); 

	}
  
  void updateControllersFromModel() {
    centroResultadoModelController.text = currentModel.centroResultadoModel?.descricao?.toString() ?? '';
    descricaoController.text = currentModel.descricao ?? '';

    formWasChanged = false;
    _updateChildrenControllersFromModel();
  }

  void _updateChildrenControllersFromModel() {
    //Detalhes
		final rateioCentroResultadoDetController = Get.find<RateioCentroResultadoDetController>(); 
		rateioCentroResultadoDetController.userMadeChanges = false; 

  }

  @override
  Future<void> save() async {
    if (!validateCurrentForm()) return;
    if (validateForms()) {
      if (userMadeChanges()) {
        final existingIndex = modelList.indexWhere((m) => m.id == currentModel.id);

        if (existingIndex >= 0) {
          modelList[existingIndex] = currentModel.clone();
        }

        final result = await repository.save(rateioCentroResultadoCabModel: currentModel);
        if (result == null) return;

        if (existingIndex >= 0) {
          modelList[existingIndex] = result;
        } else {
          modelList.insert(0, result);
        }

        if (!GetPlatform.isMobile) {
          updateGridRow(result);
        }

        Get.back(result: true);
      } else {
        Get.back();
      }
    } 
  }

  Future callCentroResultadoLookup() async { 
		final lookupController = Get.find<LookupController>(); 
		lookupController.refreshItems(standardValue: '%'); 
		lookupController.title = '${'lookup_page_title'.tr} [Centro Resultado]'; 
		lookupController.route = '/centro-resultado/'; 
		lookupController.gridColumns = centroResultadoGridColumns(isForLookup: true); 
		lookupController.aliasColumns = CentroResultadoModel.aliasColumns; 
		lookupController.dbColumns = CentroResultadoModel.dbColumns; 
		lookupController.standardColumn = CentroResultadoModel.aliasColumns[CentroResultadoModel.dbColumns.indexOf('descricao')]; 

		final plutoRowResult = await Get.toNamed(Routes.lookupPage); 
		if (plutoRowResult != null) { 
			currentModel.idCentroResultado = plutoRowResult.cells['id']!.value; 
			currentModel.centroResultadoModel = CentroResultadoModel.fromPlutoRow(plutoRowResult); 
			centroResultadoModelController.text = currentModel.centroResultadoModel?.descricao ?? ''; 
			formWasChanged = true; 
		}
	}


  List<Tab> tabItems = [
    Tab( 
			icon: Icon(iconDataList[Random().nextInt(10)]), 
			text: 'Rateio Centro Resultado', 
		),
    Tab( 
			icon: Icon(iconDataList[Random().nextInt(10)]), 
			text: 'Detalhes', 
		),
  ];

  List<Widget> tabPages() {
    return [
      RateioCentroResultadoCabEditPage(),
      const RateioCentroResultadoDetListPage(),
    ];
  }

  @override
  void preventDataLoss() {
    if (userMadeChanges()) {
      showQuestionDialog('message_data_loss'.tr, () { 
        Get.back(); 
      });
    } else {
      Get.back();
    }
  }  

  bool userMadeChanges() {
    return
    formWasChanged 
    || 
		Get.find<RateioCentroResultadoDetController>().userMadeChanges
    ;
  }

  void tabChange(int index) {
    validateCurrentForm();
  }

  bool validateCurrentForm() {
    mandatoryMessage = ValidateFormField.validateMandatory(currentModel.centroResultadoModel?.descricao); 
		if (mandatoryMessage != null) { 
			tabController.animateTo(0); 
			showErrorSnackBar(message: '$mandatoryMessage [Centro Resultado]'); 
			return false; 
		}
    return true;
  }

  bool validateForms() {
    return true;
  }

  @override
  void onInit() {
    super.onInit();
    tabController = TabController(vsync: this, length: tabItems.length);
    _configureChildrenControllers();
  }
	
  @override
  void onClose() {
    tabController.dispose();
    centroResultadoModelController.dispose();
    descricaoController.dispose();
    _releaseChildrenControllers();
    super.onClose();
  }	
}