import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:extended_masked_text/extended_masked_text.dart';
import 'package:contabil/app/page/shared_widget/input/input_imports.dart';

import 'package:contabil/app/page/shared_widget/message_dialog.dart';
import 'package:contabil/app/page/grid_columns/grid_columns_imports.dart';
import 'package:contabil/app/routes/app_routes.dart';
import 'package:contabil/app/controller/controller_imports.dart';
import 'package:contabil/app/data/model/model_imports.dart';
import 'package:contabil/app/data/repository/plano_conta_repository.dart';

class PlanoContaController extends ControllerBase<PlanoContaModel, PlanoContaRepository> {

  PlanoContaController({required super.repository}) {
    dbColumns = PlanoContaModel.dbColumns;
    aliasColumns = PlanoContaModel.aliasColumns;
    gridColumns = planoContaGridColumns();
    functionName = "plano_conta";
    screenTitle = "Plano de Contas";
  }

  @override
  PlanoContaModel createNewModel() => PlanoContaModel();

  @override
  final standardFieldForFilter = PlanoContaModel.aliasColumns[PlanoContaModel.dbColumns.indexOf('nome')];

  final nomeController = TextEditingController();
  final dataInclusaoController = DatePickerItemController(null);
  final mascaraController = TextEditingController();
  final niveisController = MoneyMaskedTextController(precision: 0, decimalSeparator: '', thousandSeparator: '');

  final Map<String, dynamic> mobileConfig = {
    'primaryColumns': ['nome'],
    'secondaryColumns': ['data_inclusao'],
  };

  List<Map<String, dynamic>> get mobileItems {
    return modelList.map((planoConta) => planoConta.toJson).toList();
  }

  @override
  void prepareForInsert() {
    isNewRecord = true;
    currentModel = createNewModel();
    _resetForm();
    Get.toNamed(Routes.planoContaEditPage);
  }

  void _resetForm() {
    formWasChanged = false;
    nomeController.text = '';
    dataInclusaoController.date = null;
    mascaraController.text = '';
    niveisController.updateValue(0);
  }

  @override
  void selectRowForEditingById(int id) {
    final model = modelList.firstWhere((m) => m.id == id);
    currentModel = model.clone();
    updateControllersFromModel();
    Get.toNamed(Routes.planoContaEditPage);
  }

  void updateControllersFromModel() {
    nomeController.text = currentModel.nome ?? '';
    dataInclusaoController.date = currentModel.dataInclusao;
    mascaraController.text = currentModel.mascara ?? '';
    niveisController.updateValue((currentModel.niveis ?? 0).toDouble());
    formWasChanged = false;
  }

  @override
  Future<void> save() async {
    if (!formKey.currentState!.validate()) {
      showErrorSnackBar(message: 'validator_form_message'.tr);
      return;
    }

    final existingIndex = modelList.indexWhere((m) => m.id == currentModel.id);

    if (existingIndex >= 0) {
      modelList[existingIndex] = currentModel.clone();
    }

    final result = await repository.save(planoContaModel: currentModel);
    if (result == null) return;

    if (existingIndex >= 0) {
      modelList[existingIndex] = result;
    } else {
      modelList.insert(0, result);
    }

    if (!GetPlatform.isMobile) {
      updateGridRow(result);
    }

    Get.back(result: true);
  }


  @override
  void onClose() {
    nomeController.dispose();
    dataInclusaoController.dispose();
    mascaraController.dispose();
    niveisController.dispose();
    super.onClose();
  }

}