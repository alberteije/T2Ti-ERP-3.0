import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:contabil/app/page/shared_widget/input/input_imports.dart';

import 'package:contabil/app/page/shared_widget/message_dialog.dart';
import 'package:contabil/app/page/grid_columns/grid_columns_imports.dart';
import 'package:contabil/app/routes/app_routes.dart';
import 'package:contabil/app/controller/controller_imports.dart';
import 'package:contabil/app/data/model/model_imports.dart';
import 'package:contabil/app/data/repository/plano_conta_ref_sped_repository.dart';

class PlanoContaRefSpedController extends ControllerBase<PlanoContaRefSpedModel, PlanoContaRefSpedRepository> {

  PlanoContaRefSpedController({required super.repository}) {
    dbColumns = PlanoContaRefSpedModel.dbColumns;
    aliasColumns = PlanoContaRefSpedModel.aliasColumns;
    gridColumns = planoContaRefSpedGridColumns();
    functionName = "plano_conta_ref_sped";
    screenTitle = "Planos de Contas Sped";
  }

  @override
  PlanoContaRefSpedModel createNewModel() => PlanoContaRefSpedModel();

  @override
  final standardFieldForFilter = PlanoContaRefSpedModel.aliasColumns[PlanoContaRefSpedModel.dbColumns.indexOf('cod_cta_ref')];

  final codCtaRefController = TextEditingController();
  final inicioValidadeController = DatePickerItemController(null);
  final fimValidadeController = DatePickerItemController(null);
  final tipoController = CustomDropdownButtonController('Sintética');
  final descricaoController = TextEditingController();
  final orientacoesController = TextEditingController();

  final Map<String, dynamic> mobileConfig = {
    'primaryColumns': ['cod_cta_ref'],
    'secondaryColumns': ['inicio_validade'],
  };

  List<Map<String, dynamic>> get mobileItems {
    return modelList.map((planoContaRefSped) => planoContaRefSped.toJson).toList();
  }

  @override
  void prepareForInsert() {
    isNewRecord = true;
    currentModel = createNewModel();
    _resetForm();
    Get.toNamed(Routes.planoContaRefSpedEditPage);
  }

  void _resetForm() {
    formWasChanged = false;
    codCtaRefController.text = '';
    inicioValidadeController.date = null;
    fimValidadeController.date = null;
    tipoController.selected = 'Sintética';
    descricaoController.text = '';
    orientacoesController.text = '';
  }

  @override
  void selectRowForEditingById(int id) {
    final model = modelList.firstWhere((m) => m.id == id);
    currentModel = model.clone();
    updateControllersFromModel();
    Get.toNamed(Routes.planoContaRefSpedEditPage);
  }

  void updateControllersFromModel() {
    codCtaRefController.text = currentModel.codCtaRef ?? '';
    inicioValidadeController.date = currentModel.inicioValidade;
    fimValidadeController.date = currentModel.fimValidade;
    tipoController.selected = currentModel.tipo ?? 'Sintética';
    descricaoController.text = currentModel.descricao ?? '';
    orientacoesController.text = currentModel.orientacoes ?? '';
    formWasChanged = false;
  }

  @override
  Future<void> save() async {
    if (!formKey.currentState!.validate()) {
      showErrorSnackBar(message: 'validator_form_message'.tr);
      return;
    }

    final existingIndex = modelList.indexWhere((m) => m.id == currentModel.id);

    if (existingIndex >= 0) {
      modelList[existingIndex] = currentModel.clone();
    }

    final result = await repository.save(planoContaRefSpedModel: currentModel);
    if (result == null) return;

    if (existingIndex >= 0) {
      modelList[existingIndex] = result;
    } else {
      modelList.insert(0, result);
    }

    if (!GetPlatform.isMobile) {
      updateGridRow(result);
    }

    Get.back(result: true);
  }


  @override
  void onClose() {
    codCtaRefController.dispose();
    inicioValidadeController.dispose();
    fimValidadeController.dispose();
    tipoController.dispose();
    descricaoController.dispose();
    orientacoesController.dispose();
    super.onClose();
  }

}