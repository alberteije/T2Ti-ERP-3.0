import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:extended_masked_text/extended_masked_text.dart';

import 'package:contabil/app/page/shared_widget/message_dialog.dart';
import 'package:contabil/app/page/grid_columns/grid_columns_imports.dart';
import 'package:contabil/app/routes/app_routes.dart';
import 'package:contabil/app/controller/controller_imports.dart';
import 'package:contabil/app/data/model/model_imports.dart';
import 'package:contabil/app/data/repository/encerra_centro_resultado_repository.dart';

class EncerraCentroResultadoController extends ControllerBase<EncerraCentroResultadoModel, EncerraCentroResultadoRepository> {

  EncerraCentroResultadoController({required super.repository}) {
    dbColumns = EncerraCentroResultadoModel.dbColumns;
    aliasColumns = EncerraCentroResultadoModel.aliasColumns;
    gridColumns = encerraCentroResultadoGridColumns();
    functionName = "encerra_centro_resultado";
    screenTitle = "Encerra Centro Resultado";
  }

  @override
  EncerraCentroResultadoModel createNewModel() => EncerraCentroResultadoModel();

  @override
  final standardFieldForFilter = EncerraCentroResultadoModel.aliasColumns[EncerraCentroResultadoModel.dbColumns.indexOf('competencia')];

  final centroResultadoModelController = TextEditingController();
  final competenciaController = MaskedTextController(mask: '00:0000',);
  final valorTotalController = MoneyMaskedTextController();
  final valorSubRateioController = MoneyMaskedTextController();

  final Map<String, dynamic> mobileConfig = {
    'primaryColumns': ['competencia'],
    'secondaryColumns': ['valor_total'],
  };

  List<Map<String, dynamic>> get mobileItems {
    return modelList.map((encerraCentroResultado) => encerraCentroResultado.toJson).toList();
  }

  @override
  void prepareForInsert() {
    isNewRecord = true;
    currentModel = createNewModel();
    _resetForm();
    Get.toNamed(Routes.encerraCentroResultadoEditPage);
  }

  void _resetForm() {
    formWasChanged = false;
    centroResultadoModelController.text = '';
    competenciaController.text = '';
    valorTotalController.updateValue(0);
    valorSubRateioController.updateValue(0);
  }

  @override
  void selectRowForEditingById(int id) {
    final model = modelList.firstWhere((m) => m.id == id);
    currentModel = model.clone();
    updateControllersFromModel();
    Get.toNamed(Routes.encerraCentroResultadoEditPage);
  }

  void updateControllersFromModel() {
    centroResultadoModelController.text = currentModel.centroResultadoModel?.descricao?.toString() ?? '';
    competenciaController.text = currentModel.competencia ?? '';
    valorTotalController.updateValue(currentModel.valorTotal ?? 0);
    valorSubRateioController.updateValue(currentModel.valorSubRateio ?? 0);
    formWasChanged = false;
  }

  @override
  Future<void> save() async {
    if (!formKey.currentState!.validate()) {
      showErrorSnackBar(message: 'validator_form_message'.tr);
      return;
    }

    final existingIndex = modelList.indexWhere((m) => m.id == currentModel.id);

    if (existingIndex >= 0) {
      modelList[existingIndex] = currentModel.clone();
    }

    final result = await repository.save(encerraCentroResultadoModel: currentModel);
    if (result == null) return;

    if (existingIndex >= 0) {
      modelList[existingIndex] = result;
    } else {
      modelList.insert(0, result);
    }

    if (!GetPlatform.isMobile) {
      updateGridRow(result);
    }

    Get.back(result: true);
  }

  Future callCentroResultadoLookup() async { 
		final lookupController = Get.find<LookupController>(); 
		lookupController.refreshItems(standardValue: '%'); 
		lookupController.title = '${'lookup_page_title'.tr} [Centro Resultado]'; 
		lookupController.route = '/centro-resultado/'; 
		lookupController.gridColumns = centroResultadoGridColumns(isForLookup: true); 
		lookupController.aliasColumns = CentroResultadoModel.aliasColumns; 
		lookupController.dbColumns = CentroResultadoModel.dbColumns; 
		lookupController.standardColumn = CentroResultadoModel.aliasColumns[CentroResultadoModel.dbColumns.indexOf('descricao')]; 

		final plutoRowResult = await Get.toNamed(Routes.lookupPage); 
		if (plutoRowResult != null) { 
			currentModel.idCentroResultado = plutoRowResult.cells['id']!.value; 
			currentModel.centroResultadoModel = CentroResultadoModel.fromPlutoRow(plutoRowResult); 
			centroResultadoModelController.text = currentModel.centroResultadoModel?.descricao ?? ''; 
			formWasChanged = true; 
		}
	}


  @override
  void onClose() {
    centroResultadoModelController.dispose();
    competenciaController.dispose();
    valorTotalController.dispose();
    valorSubRateioController.dispose();
    super.onClose();
  }

}