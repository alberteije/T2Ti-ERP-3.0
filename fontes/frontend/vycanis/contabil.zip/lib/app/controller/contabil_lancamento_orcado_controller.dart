import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:extended_masked_text/extended_masked_text.dart';

import 'package:contabil/app/page/shared_widget/message_dialog.dart';
import 'package:contabil/app/page/grid_columns/grid_columns_imports.dart';
import 'package:contabil/app/routes/app_routes.dart';
import 'package:contabil/app/controller/controller_imports.dart';
import 'package:contabil/app/data/model/model_imports.dart';
import 'package:contabil/app/data/repository/contabil_lancamento_orcado_repository.dart';

class ContabilLancamentoOrcadoController extends ControllerBase<ContabilLancamentoOrcadoModel, ContabilLancamentoOrcadoRepository> {

  ContabilLancamentoOrcadoController({required super.repository}) {
    dbColumns = ContabilLancamentoOrcadoModel.dbColumns;
    aliasColumns = ContabilLancamentoOrcadoModel.aliasColumns;
    gridColumns = contabilLancamentoOrcadoGridColumns();
    functionName = "contabil_lancamento_orcado";
    screenTitle = "Lançamento Orcado";
  }

  @override
  ContabilLancamentoOrcadoModel createNewModel() => ContabilLancamentoOrcadoModel();

  @override
  final standardFieldForFilter = ContabilLancamentoOrcadoModel.aliasColumns[ContabilLancamentoOrcadoModel.dbColumns.indexOf('ano')];

  final contabilContaModelController = TextEditingController();
  final anoController = TextEditingController();
  final janeiroController = MoneyMaskedTextController();
  final fevereiroController = MoneyMaskedTextController();
  final marcoController = MoneyMaskedTextController();
  final abrilController = MoneyMaskedTextController();
  final maioController = MoneyMaskedTextController();
  final junhoController = MoneyMaskedTextController();
  final julhoController = MoneyMaskedTextController();
  final agostoController = MoneyMaskedTextController();
  final setembroController = MoneyMaskedTextController();
  final outubroController = MoneyMaskedTextController();
  final novembroController = MoneyMaskedTextController();
  final dezembroController = MoneyMaskedTextController();

  final Map<String, dynamic> mobileConfig = {
    'primaryColumns': ['ano'],
    'secondaryColumns': ['janeiro'],
  };

  List<Map<String, dynamic>> get mobileItems {
    return modelList.map((contabilLancamentoOrcado) => contabilLancamentoOrcado.toJson).toList();
  }

  @override
  void prepareForInsert() {
    isNewRecord = true;
    currentModel = createNewModel();
    _resetForm();
    Get.toNamed(Routes.contabilLancamentoOrcadoEditPage);
  }

  void _resetForm() {
    formWasChanged = false;
    contabilContaModelController.text = '';
    anoController.text = '';
    janeiroController.updateValue(0);
    fevereiroController.updateValue(0);
    marcoController.updateValue(0);
    abrilController.updateValue(0);
    maioController.updateValue(0);
    junhoController.updateValue(0);
    julhoController.updateValue(0);
    agostoController.updateValue(0);
    setembroController.updateValue(0);
    outubroController.updateValue(0);
    novembroController.updateValue(0);
    dezembroController.updateValue(0);
  }

  @override
  void selectRowForEditingById(int id) {
    final model = modelList.firstWhere((m) => m.id == id);
    currentModel = model.clone();
    updateControllersFromModel();
    Get.toNamed(Routes.contabilLancamentoOrcadoEditPage);
  }

  void updateControllersFromModel() {
    contabilContaModelController.text = currentModel.contabilContaModel?.descricao?.toString() ?? '';
    anoController.text = currentModel.ano ?? '';
    janeiroController.updateValue(currentModel.janeiro ?? 0);
    fevereiroController.updateValue(currentModel.fevereiro ?? 0);
    marcoController.updateValue(currentModel.marco ?? 0);
    abrilController.updateValue(currentModel.abril ?? 0);
    maioController.updateValue(currentModel.maio ?? 0);
    junhoController.updateValue(currentModel.junho ?? 0);
    julhoController.updateValue(currentModel.julho ?? 0);
    agostoController.updateValue(currentModel.agosto ?? 0);
    setembroController.updateValue(currentModel.setembro ?? 0);
    outubroController.updateValue(currentModel.outubro ?? 0);
    novembroController.updateValue(currentModel.novembro ?? 0);
    dezembroController.updateValue(currentModel.dezembro ?? 0);
    formWasChanged = false;
  }

  @override
  Future<void> save() async {
    if (!formKey.currentState!.validate()) {
      showErrorSnackBar(message: 'validator_form_message'.tr);
      return;
    }

    final existingIndex = modelList.indexWhere((m) => m.id == currentModel.id);

    if (existingIndex >= 0) {
      modelList[existingIndex] = currentModel.clone();
    }

    final result = await repository.save(contabilLancamentoOrcadoModel: currentModel);
    if (result == null) return;

    if (existingIndex >= 0) {
      modelList[existingIndex] = result;
    } else {
      modelList.insert(0, result);
    }

    if (!GetPlatform.isMobile) {
      updateGridRow(result);
    }

    Get.back(result: true);
  }

  Future callContabilContaLookup() async { 
		final lookupController = Get.find<LookupController>(); 
		lookupController.refreshItems(standardValue: '%'); 
		lookupController.title = '${'lookup_page_title'.tr} [Conta Contabil]'; 
		lookupController.route = '/contabil-conta/'; 
		lookupController.gridColumns = contabilContaGridColumns(isForLookup: true); 
		lookupController.aliasColumns = ContabilContaModel.aliasColumns; 
		lookupController.dbColumns = ContabilContaModel.dbColumns; 
		lookupController.standardColumn = ContabilContaModel.aliasColumns[ContabilContaModel.dbColumns.indexOf('descricao')]; 

		final plutoRowResult = await Get.toNamed(Routes.lookupPage); 
		if (plutoRowResult != null) { 
			currentModel.idContabilConta = plutoRowResult.cells['id']!.value; 
			currentModel.contabilContaModel = ContabilContaModel.fromPlutoRow(plutoRowResult); 
			contabilContaModelController.text = currentModel.contabilContaModel?.descricao ?? ''; 
			formWasChanged = true; 
		}
	}


  @override
  void onClose() {
    contabilContaModelController.dispose();
    anoController.dispose();
    janeiroController.dispose();
    fevereiroController.dispose();
    marcoController.dispose();
    abrilController.dispose();
    maioController.dispose();
    junhoController.dispose();
    julhoController.dispose();
    agostoController.dispose();
    setembroController.dispose();
    outubroController.dispose();
    novembroController.dispose();
    dezembroController.dispose();
    super.onClose();
  }

}