import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:extended_masked_text/extended_masked_text.dart';
import 'package:contabil/app/page/shared_widget/input/input_imports.dart';

import 'package:contabil/app/page/shared_widget/message_dialog.dart';
import 'package:contabil/app/page/grid_columns/grid_columns_imports.dart';
import 'package:contabil/app/routes/app_routes.dart';
import 'package:contabil/app/controller/controller_imports.dart';
import 'package:contabil/app/data/model/model_imports.dart';
import 'package:contabil/app/data/repository/lanca_centro_resultado_repository.dart';

class LancaCentroResultadoController extends ControllerBase<LancaCentroResultadoModel, LancaCentroResultadoRepository> {

  LancaCentroResultadoController({required super.repository}) {
    dbColumns = LancaCentroResultadoModel.dbColumns;
    aliasColumns = LancaCentroResultadoModel.aliasColumns;
    gridColumns = lancaCentroResultadoGridColumns();
    functionName = "lanca_centro_resultado";
    screenTitle = "Lançamento Centro Resultado";
  }

  @override
  LancaCentroResultadoModel createNewModel() => LancaCentroResultadoModel();

  @override
  final standardFieldForFilter = LancaCentroResultadoModel.aliasColumns[LancaCentroResultadoModel.dbColumns.indexOf('valor')];

  final centroResultadoModelController = TextEditingController();
  final valorController = MoneyMaskedTextController();
  final dataLancamentoController = DatePickerItemController(null);
  final dataInclusaoController = DatePickerItemController(null);
  final origemDeRateioController = CustomDropdownButtonController('Sim');
  final historicoController = TextEditingController();

  final Map<String, dynamic> mobileConfig = {
    'primaryColumns': ['valor'],
    'secondaryColumns': ['data_lancamento'],
  };

  List<Map<String, dynamic>> get mobileItems {
    return modelList.map((lancaCentroResultado) => lancaCentroResultado.toJson).toList();
  }

  @override
  void prepareForInsert() {
    isNewRecord = true;
    currentModel = createNewModel();
    _resetForm();
    Get.toNamed(Routes.lancaCentroResultadoEditPage);
  }

  void _resetForm() {
    formWasChanged = false;
    centroResultadoModelController.text = '';
    valorController.updateValue(0);
    dataLancamentoController.date = null;
    dataInclusaoController.date = null;
    origemDeRateioController.selected = 'Sim';
    historicoController.text = '';
  }

  @override
  void selectRowForEditingById(int id) {
    final model = modelList.firstWhere((m) => m.id == id);
    currentModel = model.clone();
    updateControllersFromModel();
    Get.toNamed(Routes.lancaCentroResultadoEditPage);
  }

  void updateControllersFromModel() {
    centroResultadoModelController.text = currentModel.centroResultadoModel?.descricao?.toString() ?? '';
    valorController.updateValue(currentModel.valor ?? 0);
    dataLancamentoController.date = currentModel.dataLancamento;
    dataInclusaoController.date = currentModel.dataInclusao;
    origemDeRateioController.selected = currentModel.origemDeRateio ?? 'Sim';
    historicoController.text = currentModel.historico ?? '';
    formWasChanged = false;
  }

  @override
  Future<void> save() async {
    if (!formKey.currentState!.validate()) {
      showErrorSnackBar(message: 'validator_form_message'.tr);
      return;
    }

    final existingIndex = modelList.indexWhere((m) => m.id == currentModel.id);

    if (existingIndex >= 0) {
      modelList[existingIndex] = currentModel.clone();
    }

    final result = await repository.save(lancaCentroResultadoModel: currentModel);
    if (result == null) return;

    if (existingIndex >= 0) {
      modelList[existingIndex] = result;
    } else {
      modelList.insert(0, result);
    }

    if (!GetPlatform.isMobile) {
      updateGridRow(result);
    }

    Get.back(result: true);
  }

  Future callCentroResultadoLookup() async { 
		final lookupController = Get.find<LookupController>(); 
		lookupController.refreshItems(standardValue: '%'); 
		lookupController.title = '${'lookup_page_title'.tr} [Centro Resultado]'; 
		lookupController.route = '/centro-resultado/'; 
		lookupController.gridColumns = centroResultadoGridColumns(isForLookup: true); 
		lookupController.aliasColumns = CentroResultadoModel.aliasColumns; 
		lookupController.dbColumns = CentroResultadoModel.dbColumns; 
		lookupController.standardColumn = CentroResultadoModel.aliasColumns[CentroResultadoModel.dbColumns.indexOf('descricao')]; 

		final plutoRowResult = await Get.toNamed(Routes.lookupPage); 
		if (plutoRowResult != null) { 
			currentModel.idCentroResultado = plutoRowResult.cells['id']!.value; 
			currentModel.centroResultadoModel = CentroResultadoModel.fromPlutoRow(plutoRowResult); 
			centroResultadoModelController.text = currentModel.centroResultadoModel?.descricao ?? ''; 
			formWasChanged = true; 
		}
	}


  @override
  void onClose() {
    centroResultadoModelController.dispose();
    valorController.dispose();
    dataLancamentoController.dispose();
    dataInclusaoController.dispose();
    origemDeRateioController.dispose();
    historicoController.dispose();
    super.onClose();
  }

}