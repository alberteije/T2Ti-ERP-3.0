import 'package:contabil/app/infra/infra_imports.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:pluto_grid/pluto_grid.dart';
import 'package:extended_masked_text/extended_masked_text.dart';
import 'package:contabil/app/page/shared_widget/input/input_imports.dart';
import 'package:contabil/app/routes/app_routes.dart';

import 'package:contabil/app/page/page_imports.dart';
import 'package:contabil/app/page/shared_widget/message_dialog.dart';
import 'package:contabil/app/page/grid_columns/grid_columns_imports.dart';
import 'package:contabil/app/controller/controller_imports.dart';
import 'package:contabil/app/data/model/model_imports.dart';

class ContabilLancamentoDetalheController extends ControllerBase<ContabilLancamentoDetalheModel, void> {

  ContabilLancamentoDetalheController() : super(repository: null) {
    dbColumns = ContabilLancamentoDetalheModel.dbColumns;
    aliasColumns = ContabilLancamentoDetalheModel.aliasColumns;
    gridColumns = contabilLancamentoDetalheGridColumns();
    functionName = "contabil_lancamento_detalhe";
    screenTitle = "Detalhes";
  }

  final _contabilLancamentoDetalheModel = ContabilLancamentoDetalheModel().obs;
  ContabilLancamentoDetalheModel get contabilLancamentoDetalheModel => _contabilLancamentoDetalheModel.value;
  set contabilLancamentoDetalheModel(value) => _contabilLancamentoDetalheModel.value = value ?? ContabilLancamentoDetalheModel();

  List<ContabilLancamentoDetalheModel> get contabilLancamentoDetalheModelList => Get.find<ContabilLancamentoCabecalhoController>().currentModel.contabilLancamentoDetalheModelList ?? [];

  final _userMadeChanges = false.obs;
  get userMadeChanges => _userMadeChanges.value;
  set userMadeChanges(value) => _userMadeChanges.value = value;

  final _formWasChangedDetail = false.obs;
  bool get formWasChangedDetail => _formWasChangedDetail.value;
  set formWasChangedDetail(value) => _formWasChangedDetail.value = value;

  late PlutoGridStateManager _plutoGridStateManager;
  @override
  PlutoGridStateManager get plutoGridStateManager => _plutoGridStateManager;
  @override
  set plutoGridStateManager(value) => _plutoGridStateManager = value;

  final contabilLancamentoDetalheScaffoldKey = GlobalKey<ScaffoldState>();
  final contabilLancamentoDetalheFormKey = GlobalKey<FormState>();

  @override
  ContabilLancamentoDetalheModel createNewModel() => ContabilLancamentoDetalheModel();

  @override
  final standardFieldForFilter = ContabilLancamentoDetalheModel.aliasColumns[ContabilLancamentoDetalheModel.dbColumns.indexOf('tipo')];

  final contabilContaModelController = TextEditingController();
  final contabilHistoricoModelController = TextEditingController();
  final tipoController = CustomDropdownButtonController('Débito');
  final valorController = MoneyMaskedTextController();
  final historicoController = TextEditingController();

  final Map<String, dynamic> mobileConfig = {
    'primaryColumns': ['tipo'],
    'secondaryColumns': ['valor'],
  };

  List<Map<String, dynamic>> get mobileItems {
    return modelList.map((contabilLancamentoDetalhe) => contabilLancamentoDetalhe.toJson).toList();
  }

  @override
  List<PlutoRow> plutoRows() => List<PlutoRow>.from(contabilLancamentoDetalheModelList.map((model) => model.toPlutoRow()));

  @override
  Future<void> getList({Filter? filter}) async {}

  @override
  void prepareForInsert() {
    isNewRecord = true;
    contabilLancamentoDetalheModel = createNewModel();
    _resetForm();
    Get.to(() => ContabilLancamentoDetalheEditPage());
  }

  void _resetForm() {
    formWasChangedDetail = false;
    contabilContaModelController.text = '';
    contabilHistoricoModelController.text = '';
    tipoController.selected = 'Débito';
    valorController.updateValue(0);
    historicoController.text = '';
  }

  @override
  void selectRowForEditing(PlutoRow? row) async {
    if (row == null) {
      showInfoSnackBar(message: 'message_select_one_to_edited'.tr);
      return;
    }

    selectRowForEditingByTempId(row.cells['tempId']?.value);
  }

  @override
  void selectRowForEditingById(int id) {}

  void selectRowForEditingByTempId(String tempId) {
		isNewRecord = false;
    final model = contabilLancamentoDetalheModelList.firstWhere((m) => m.tempId == tempId);
    contabilLancamentoDetalheModel = model.clone();
		contabilLancamentoDetalheModel.tempId = model.tempId;
    updateControllersFromModel();
    Get.to(() => ContabilLancamentoDetalheEditPage());
  }

  void updateControllersFromModel() {
    contabilContaModelController.text = contabilLancamentoDetalheModel.contabilContaModel?.descricao?.toString() ?? '';
    contabilHistoricoModelController.text = contabilLancamentoDetalheModel.contabilHistoricoModel?.descricao?.toString() ?? '';
    tipoController.selected = contabilLancamentoDetalheModel.tipo ?? 'Débito';
    valorController.updateValue(contabilLancamentoDetalheModel.valor ?? 0);
    historicoController.text = contabilLancamentoDetalheModel.historico ?? '';
    formWasChangedDetail = false;
  }

  @override
  Future<void> save() async {
    if (!contabilLancamentoDetalheFormKey.currentState!.validate()) {
      showErrorSnackBar(message: 'validator_form_message'.tr);
      return;
    }

    if (formWasChangedDetail) {
      if (isNewRecord) {
        contabilLancamentoDetalheModelList.insert(0, contabilLancamentoDetalheModel.clone());
      } else {
        final index = contabilLancamentoDetalheModelList.indexWhere((m) => m.tempId == contabilLancamentoDetalheModel.tempId);
        if (index >= 0) {
          contabilLancamentoDetalheModelList[index] = contabilLancamentoDetalheModel.clone();
        }
      }

      userMadeChanges = true;
      loadData();
      Get.back(result: true);
    } else {
      Get.back();
    }
  }

  Future callContabilContaLookup() async { 
		final lookupController = Get.find<LookupController>(); 
		lookupController.refreshItems(standardValue: '%'); 
		lookupController.title = '${'lookup_page_title'.tr} [Conta Contabil]'; 
		lookupController.route = '/contabil-conta/'; 
		lookupController.gridColumns = contabilContaGridColumns(isForLookup: true); 
		lookupController.aliasColumns = ContabilContaModel.aliasColumns; 
		lookupController.dbColumns = ContabilContaModel.dbColumns; 
		lookupController.standardColumn = ContabilContaModel.aliasColumns[ContabilContaModel.dbColumns.indexOf('descricao')]; 

		final plutoRowResult = await Get.toNamed(Routes.lookupPage); 
		if (plutoRowResult != null) { 
			contabilLancamentoDetalheModel.idContabilConta = plutoRowResult.cells['id']!.value; 
			contabilLancamentoDetalheModel.contabilContaModel = ContabilContaModel.fromPlutoRow(plutoRowResult); 
			contabilContaModelController.text = contabilLancamentoDetalheModel.contabilContaModel?.descricao ?? ''; 
			formWasChangedDetail = true; 
		}
	}

  Future callContabilHistoricoLookup() async { 
		final lookupController = Get.find<LookupController>(); 
		lookupController.refreshItems(standardValue: '%'); 
		lookupController.title = '${'lookup_page_title'.tr} [Historico]'; 
		lookupController.route = '/contabil-historico/'; 
		lookupController.gridColumns = contabilHistoricoGridColumns(isForLookup: true); 
		lookupController.aliasColumns = ContabilHistoricoModel.aliasColumns; 
		lookupController.dbColumns = ContabilHistoricoModel.dbColumns; 
		lookupController.standardColumn = ContabilHistoricoModel.aliasColumns[ContabilHistoricoModel.dbColumns.indexOf('descricao')]; 

		final plutoRowResult = await Get.toNamed(Routes.lookupPage); 
		if (plutoRowResult != null) { 
			contabilLancamentoDetalheModel.idContabilHistorico = plutoRowResult.cells['id']!.value; 
			contabilLancamentoDetalheModel.contabilHistoricoModel = ContabilHistoricoModel.fromPlutoRow(plutoRowResult); 
			contabilHistoricoModelController.text = contabilLancamentoDetalheModel.contabilHistoricoModel?.descricao ?? ''; 
			formWasChangedDetail = true; 
		}
	}


  @override
  Future deleteSelected() async {
    final currentRow = plutoGridStateManager.currentRow;
    if (currentRow == null) {
      showInfoSnackBar(message: 'message_select_one_to_delete'.tr);
      return null;
    }
    showDeleteDialog(() async {
      final id = currentRow.cells['id']?.value;
      final tempId = currentRow.cells['tempId']?.value;
      contabilLancamentoDetalheModelList.removeWhere((model) => (id != 0 && model.id == id) || (id == 0 && model.tempId == tempId));
      plutoGridStateManager.removeCurrentRow();
      userMadeChanges = true;
    });
  }

  void conciliarValores() {
    double creditos = 0.0;
    double debitos = 0.0;
    for (var lancamento in contabilLancamentoDetalheModelList) {
      if (lancamento.tipo == 'Crédito') {
        creditos += lancamento.valor ?? 0;
      } else {
        debitos += lancamento.valor ?? 0;
      }
    }
    if (creditos != debitos) {
      final diferenca = Util.decimalFormat(creditos - debitos);
      showErrorSnackBar(message: "Valores de créditos e débitos não correspondem. Diferença: $diferenca");
    } else {
      showInfoSnackBar(message: "Valores correspondem. Lançamento conciliado!");
    }
  }

  @override
  void preventDataLoss() {
    if (formWasChangedDetail) {
      showQuestionDialog('message_data_loss'.tr, () => Get.back());
    } else {
      formWasChangedDetail = false;
      Get.back();
    }
  }

  @override
  void onClose() {
    contabilContaModelController.dispose();
    contabilHistoricoModelController.dispose();
    tipoController.dispose();
    valorController.dispose();
    historicoController.dispose();
  }

}