import 'package:get/get.dart';
import 'package:contabil/app/page/shared_widget/input/input_imports.dart';

import 'package:contabil/app/page/shared_widget/message_dialog.dart';
import 'package:contabil/app/page/grid_columns/grid_columns_imports.dart';
import 'package:contabil/app/routes/app_routes.dart';
import 'package:contabil/app/controller/controller_imports.dart';
import 'package:contabil/app/data/model/model_imports.dart';
import 'package:contabil/app/data/repository/contabil_fechamento_repository.dart';

class ContabilFechamentoController extends ControllerBase<ContabilFechamentoModel, ContabilFechamentoRepository> {

  ContabilFechamentoController({required super.repository}) {
    dbColumns = ContabilFechamentoModel.dbColumns;
    aliasColumns = ContabilFechamentoModel.aliasColumns;
    gridColumns = contabilFechamentoGridColumns();
    functionName = "contabil_fechamento";
    screenTitle = "Fechamento";
  }

  @override
  ContabilFechamentoModel createNewModel() => ContabilFechamentoModel();

  @override
  final standardFieldForFilter = ContabilFechamentoModel.aliasColumns[ContabilFechamentoModel.dbColumns.indexOf('data_inicio')];

  final dataInicioController = DatePickerItemController(null);
  final dataFimController = DatePickerItemController(null);
  final criterioLancamentoController = CustomDropdownButtonController('Livre');

  final Map<String, dynamic> mobileConfig = {
    'primaryColumns': ['data_inicio'],
    'secondaryColumns': ['data_fim'],
  };

  List<Map<String, dynamic>> get mobileItems {
    return modelList.map((contabilFechamento) => contabilFechamento.toJson).toList();
  }

  @override
  void prepareForInsert() {
    isNewRecord = true;
    currentModel = createNewModel();
    _resetForm();
    Get.toNamed(Routes.contabilFechamentoEditPage);
  }

  void _resetForm() {
    formWasChanged = false;
    dataInicioController.date = null;
    dataFimController.date = null;
    criterioLancamentoController.selected = 'Livre';
  }

  @override
  void selectRowForEditingById(int id) {
    final model = modelList.firstWhere((m) => m.id == id);
    currentModel = model.clone();
    updateControllersFromModel();
    Get.toNamed(Routes.contabilFechamentoEditPage);
  }

  void updateControllersFromModel() {
    dataInicioController.date = currentModel.dataInicio;
    dataFimController.date = currentModel.dataFim;
    criterioLancamentoController.selected = currentModel.criterioLancamento ?? 'Livre';
    formWasChanged = false;
  }

  @override
  Future<void> save() async {
    if (!formKey.currentState!.validate()) {
      showErrorSnackBar(message: 'validator_form_message'.tr);
      return;
    }

    final existingIndex = modelList.indexWhere((m) => m.id == currentModel.id);

    if (existingIndex >= 0) {
      modelList[existingIndex] = currentModel.clone();
    }

    final result = await repository.save(contabilFechamentoModel: currentModel);
    if (result == null) return;

    if (existingIndex >= 0) {
      modelList[existingIndex] = result;
    } else {
      modelList.insert(0, result);
    }

    if (!GetPlatform.isMobile) {
      updateGridRow(result);
    }

    Get.back(result: true);
  }


  @override
  void onClose() {
    dataInicioController.dispose();
    dataFimController.dispose();
    criterioLancamentoController.dispose();
    super.onClose();
  }

}