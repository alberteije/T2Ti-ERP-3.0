import 'package:flutter/material.dart';
import 'dart:math';
import 'package:get/get.dart';
import 'package:contabil/app/page/shared_widget/input/input_imports.dart';

import 'package:contabil/app/infra/infra_imports.dart';
import 'package:contabil/app/page/page_imports.dart';
import 'package:contabil/app/page/shared_widget/message_dialog.dart';
import 'package:contabil/app/page/grid_columns/grid_columns_imports.dart';
import 'package:contabil/app/routes/app_routes.dart';
import 'package:contabil/app/controller/controller_imports.dart';
import 'package:contabil/app/data/model/model_imports.dart';
import 'package:contabil/app/data/repository/centro_resultado_repository.dart';

class CentroResultadoController extends ControllerBase<CentroResultadoModel, CentroResultadoRepository> 
with GetSingleTickerProviderStateMixin {

  CentroResultadoController({required super.repository}) {
    dbColumns = CentroResultadoModel.dbColumns;
    aliasColumns = CentroResultadoModel.aliasColumns;
    gridColumns = centroResultadoGridColumns();
    functionName = "centro_resultado";
    screenTitle = "Centro de Resultado";
  }

  final centroResultadoScaffoldKey = GlobalKey<ScaffoldState>();
  final centroResultadoTabPageScaffoldKey = GlobalKey<ScaffoldState>();
  final centroResultadoFormKey = GlobalKey<FormState>();
  late TabController tabController;
  String? mandatoryMessage;  

  @override
  CentroResultadoModel createNewModel() => CentroResultadoModel();

  @override
  final standardFieldForFilter = CentroResultadoModel.aliasColumns[CentroResultadoModel.dbColumns.indexOf('descricao')];

  final planoCentroResultadoModelController = TextEditingController();
  final descricaoController = TextEditingController();
  final classificacaoController = TextEditingController();
  final sofreRateiroController = CustomDropdownButtonController('Sim');

  final Map<String, dynamic> mobileConfig = {
    'primaryColumns': ['descricao'],
    'secondaryColumns': ['classificacao'],
  };

  List<Map<String, dynamic>> get mobileItems {
    return modelList.map((centroResultado) => centroResultado.toJson).toList();
  }

  @override
  void prepareForInsert() {
    isNewRecord = true;
    currentModel = createNewModel();
    _resetForm();
    tabController.animateTo(0);
    updateControllersFromModel();
    Get.toNamed(Routes.centroResultadoTabPage);
  }

  void _resetForm() {
    formWasChanged = false;
    planoCentroResultadoModelController.text = '';
    descricaoController.text = '';
    classificacaoController.text = '';
    sofreRateiroController.selected = 'Sim';
  }

  @override
  void selectRowForEditingById(int id) {
    final model = modelList.firstWhere((m) => m.id == id);
    currentModel = model.clone();
    updateControllersFromModel();
    tabController.animateTo(0);
    Get.toNamed(Routes.centroResultadoTabPage);
  }

  _configureChildrenControllers() {
    //Natureza Financeira Vinculada
		Get.put<CtResultadoNtFinanceiraController>(CtResultadoNtFinanceiraController()); 

  }
	
	_releaseChildrenControllers() {
    //Natureza Financeira Vinculada
		Get.delete<CtResultadoNtFinanceiraController>(); 

	}
  
  void updateControllersFromModel() {
    planoCentroResultadoModelController.text = currentModel.planoCentroResultadoModel?.nome?.toString() ?? '';
    descricaoController.text = currentModel.descricao ?? '';
    classificacaoController.text = currentModel.classificacao ?? '';
    sofreRateiroController.selected = currentModel.sofreRateiro ?? 'Sim';

    formWasChanged = false;
    _updateChildrenControllersFromModel();
  }

  void _updateChildrenControllersFromModel() {
    //Natureza Financeira Vinculada
		final ctResultadoNtFinanceiraController = Get.find<CtResultadoNtFinanceiraController>(); 
		ctResultadoNtFinanceiraController.userMadeChanges = false; 

  }

  @override
  Future<void> save() async {
    if (!validateCurrentForm()) return;
    if (validateForms()) {
      if (userMadeChanges()) {
        final existingIndex = modelList.indexWhere((m) => m.id == currentModel.id);

        if (existingIndex >= 0) {
          modelList[existingIndex] = currentModel.clone();
        }

        final result = await repository.save(centroResultadoModel: currentModel);
        if (result == null) return;

        if (existingIndex >= 0) {
          modelList[existingIndex] = result;
        } else {
          modelList.insert(0, result);
        }

        if (!GetPlatform.isMobile) {
          updateGridRow(result);
        }

        Get.back(result: true);
      } else {
        Get.back();
      }
    } 
  }

  Future callPlanoCentroResultadoLookup() async { 
		final lookupController = Get.find<LookupController>(); 
		lookupController.refreshItems(standardValue: '%'); 
		lookupController.title = '${'lookup_page_title'.tr} [Plano Centro Resultado]'; 
		lookupController.route = '/plano-centro-resultado/'; 
		lookupController.gridColumns = planoCentroResultadoGridColumns(isForLookup: true); 
		lookupController.aliasColumns = PlanoCentroResultadoModel.aliasColumns; 
		lookupController.dbColumns = PlanoCentroResultadoModel.dbColumns; 
		lookupController.standardColumn = PlanoCentroResultadoModel.aliasColumns[PlanoCentroResultadoModel.dbColumns.indexOf('nome')]; 

		final plutoRowResult = await Get.toNamed(Routes.lookupPage); 
		if (plutoRowResult != null) { 
			currentModel.idPlanoCentroResultado = plutoRowResult.cells['id']!.value; 
			currentModel.planoCentroResultadoModel = PlanoCentroResultadoModel.fromPlutoRow(plutoRowResult); 
			planoCentroResultadoModelController.text = currentModel.planoCentroResultadoModel?.nome ?? ''; 
			formWasChanged = true; 
		}
	}


  List<Tab> tabItems = [
    Tab( 
			icon: Icon(iconDataList[Random().nextInt(10)]), 
			text: 'Centro de Resultado', 
		),
    Tab( 
			icon: Icon(iconDataList[Random().nextInt(10)]), 
			text: 'Natureza Financeira Vinculada', 
		),
  ];

  List<Widget> tabPages() {
    return [
      CentroResultadoEditPage(),
      const CtResultadoNtFinanceiraListPage(),
    ];
  }

  @override
  void preventDataLoss() {
    if (userMadeChanges()) {
      showQuestionDialog('message_data_loss'.tr, () { 
        Get.back(); 
      });
    } else {
      Get.back();
    }
  }  

  bool userMadeChanges() {
    return
    formWasChanged 
    || 
		Get.find<CtResultadoNtFinanceiraController>().userMadeChanges
    ;
  }

  void tabChange(int index) {
    validateCurrentForm();
  }

  bool validateCurrentForm() {
    mandatoryMessage = ValidateFormField.validateMandatory(currentModel.planoCentroResultadoModel?.nome); 
		if (mandatoryMessage != null) { 
			tabController.animateTo(0); 
			showErrorSnackBar(message: '$mandatoryMessage [Plano Centro Resultado]'); 
			return false; 
		}
    return true;
  }

  bool validateForms() {
    return true;
  }

  @override
  void onInit() {
    super.onInit();
    tabController = TabController(vsync: this, length: tabItems.length);
    _configureChildrenControllers();
  }
	
  @override
  void onClose() {
    tabController.dispose();
    planoCentroResultadoModelController.dispose();
    descricaoController.dispose();
    classificacaoController.dispose();
    sofreRateiroController.dispose();
    _releaseChildrenControllers();
    super.onClose();
  }	
}