import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:extended_masked_text/extended_masked_text.dart';
import 'package:contabil/app/page/shared_widget/input/input_imports.dart';

import 'package:contabil/app/page/shared_widget/message_dialog.dart';
import 'package:contabil/app/page/grid_columns/grid_columns_imports.dart';
import 'package:contabil/app/routes/app_routes.dart';
import 'package:contabil/app/controller/controller_imports.dart';
import 'package:contabil/app/data/model/model_imports.dart';
import 'package:contabil/app/data/repository/contabil_parametro_repository.dart';

class ContabilParametroController extends ControllerBase<ContabilParametroModel, ContabilParametroRepository> {

  ContabilParametroController({required super.repository}) {
    dbColumns = ContabilParametroModel.dbColumns;
    aliasColumns = ContabilParametroModel.aliasColumns;
    gridColumns = contabilParametroGridColumns();
    functionName = "contabil_parametro";
    screenTitle = "Parâmetros";
  }

  @override
  ContabilParametroModel createNewModel() => ContabilParametroModel();

  @override
  final standardFieldForFilter = ContabilParametroModel.aliasColumns[ContabilParametroModel.dbColumns.indexOf('mascara')];

  final mascaraController = TextEditingController();
  final niveisController = MoneyMaskedTextController(precision: 0, decimalSeparator: '', thousandSeparator: '');
  final informarContaPorController = CustomDropdownButtonController('Código');
  final compartilhaPlanoContaController = CustomDropdownButtonController('Sim');
  final compartilhaHistoricosController = CustomDropdownButtonController('Sim');
  final alteraLancamentoOutroController = CustomDropdownButtonController('Sim');
  final historicoObrigatorioController = CustomDropdownButtonController('Sim');
  final permiteLancamentoZeradoController = CustomDropdownButtonController('Sim');
  final geraInformativoSpedController = CustomDropdownButtonController('Sim');
  final spedFormaEscritDiarioController = CustomDropdownButtonController('Livro Diário Completo');
  final spedNomeLivroDiarioController = TextEditingController();
  final assinaturaDireitaController = TextEditingController();
  final assinaturaEsquerdaController = TextEditingController();
  final contaAtivoController = TextEditingController();
  final contaPassivoController = TextEditingController();
  final contaPatrimonioLiquidoController = TextEditingController();
  final contaDepreciacaoAcumuladaController = TextEditingController();
  final contaCapitalSocialController = TextEditingController();
  final contaResultadoExercicioController = TextEditingController();
  final contaPrejuizoAcumuladoController = TextEditingController();
  final contaLucroAcumuladoController = TextEditingController();
  final contaTituloPagarController = TextEditingController();
  final contaTituloReceberController = TextEditingController();
  final contaJurosPassivoController = TextEditingController();
  final contaJurosAtivoController = TextEditingController();
  final contaDescontoObtidoController = TextEditingController();
  final contaDescontoConcedidoController = TextEditingController();
  final contaCmvController = TextEditingController();
  final contaVendaController = TextEditingController();
  final contaVendaServicoController = TextEditingController();
  final contaEstoqueController = TextEditingController();
  final contaApuraResultadoController = TextEditingController();
  final contaJurosApropriarController = TextEditingController();
  final idHistPadraoResultadoController = MoneyMaskedTextController(precision: 0, decimalSeparator: '', thousandSeparator: '');
  final idHistPadraoLucroController = MoneyMaskedTextController(precision: 0, decimalSeparator: '', thousandSeparator: '');
  final idHistPadraoPrejuizoController = MoneyMaskedTextController(precision: 0, decimalSeparator: '', thousandSeparator: '');

  final Map<String, dynamic> mobileConfig = {
    'primaryColumns': ['mascara'],
    'secondaryColumns': ['niveis'],
  };

  List<Map<String, dynamic>> get mobileItems {
    return modelList.map((contabilParametro) => contabilParametro.toJson).toList();
  }

  @override
  void prepareForInsert() {
    isNewRecord = true;
    currentModel = createNewModel();
    _resetForm();
    Get.toNamed(Routes.contabilParametroEditPage);
  }

  void _resetForm() {
    formWasChanged = false;
    mascaraController.text = '';
    niveisController.updateValue(0);
    informarContaPorController.selected = 'Código';
    compartilhaPlanoContaController.selected = 'Sim';
    compartilhaHistoricosController.selected = 'Sim';
    alteraLancamentoOutroController.selected = 'Sim';
    historicoObrigatorioController.selected = 'Sim';
    permiteLancamentoZeradoController.selected = 'Sim';
    geraInformativoSpedController.selected = 'Sim';
    spedFormaEscritDiarioController.selected = 'Livro Diário Completo';
    spedNomeLivroDiarioController.text = '';
    assinaturaDireitaController.text = '';
    assinaturaEsquerdaController.text = '';
    contaAtivoController.text = '';
    contaPassivoController.text = '';
    contaPatrimonioLiquidoController.text = '';
    contaDepreciacaoAcumuladaController.text = '';
    contaCapitalSocialController.text = '';
    contaResultadoExercicioController.text = '';
    contaPrejuizoAcumuladoController.text = '';
    contaLucroAcumuladoController.text = '';
    contaTituloPagarController.text = '';
    contaTituloReceberController.text = '';
    contaJurosPassivoController.text = '';
    contaJurosAtivoController.text = '';
    contaDescontoObtidoController.text = '';
    contaDescontoConcedidoController.text = '';
    contaCmvController.text = '';
    contaVendaController.text = '';
    contaVendaServicoController.text = '';
    contaEstoqueController.text = '';
    contaApuraResultadoController.text = '';
    contaJurosApropriarController.text = '';
    idHistPadraoResultadoController.updateValue(0);
    idHistPadraoLucroController.updateValue(0);
    idHistPadraoPrejuizoController.updateValue(0);
  }

  @override
  void selectRowForEditingById(int id) {
    final model = modelList.firstWhere((m) => m.id == id);
    currentModel = model.clone();
    updateControllersFromModel();
    Get.toNamed(Routes.contabilParametroEditPage);
  }

  void updateControllersFromModel() {
    mascaraController.text = currentModel.mascara ?? '';
    niveisController.updateValue((currentModel.niveis ?? 0).toDouble());
    informarContaPorController.selected = currentModel.informarContaPor ?? 'Código';
    compartilhaPlanoContaController.selected = currentModel.compartilhaPlanoConta ?? 'Sim';
    compartilhaHistoricosController.selected = currentModel.compartilhaHistoricos ?? 'Sim';
    alteraLancamentoOutroController.selected = currentModel.alteraLancamentoOutro ?? 'Sim';
    historicoObrigatorioController.selected = currentModel.historicoObrigatorio ?? 'Sim';
    permiteLancamentoZeradoController.selected = currentModel.permiteLancamentoZerado ?? 'Sim';
    geraInformativoSpedController.selected = currentModel.geraInformativoSped ?? 'Sim';
    spedFormaEscritDiarioController.selected = currentModel.spedFormaEscritDiario ?? 'Livro Diário Completo';
    spedNomeLivroDiarioController.text = currentModel.spedNomeLivroDiario ?? '';
    assinaturaDireitaController.text = currentModel.assinaturaDireita ?? '';
    assinaturaEsquerdaController.text = currentModel.assinaturaEsquerda ?? '';
    contaAtivoController.text = currentModel.contaAtivo ?? '';
    contaPassivoController.text = currentModel.contaPassivo ?? '';
    contaPatrimonioLiquidoController.text = currentModel.contaPatrimonioLiquido ?? '';
    contaDepreciacaoAcumuladaController.text = currentModel.contaDepreciacaoAcumulada ?? '';
    contaCapitalSocialController.text = currentModel.contaCapitalSocial ?? '';
    contaResultadoExercicioController.text = currentModel.contaResultadoExercicio ?? '';
    contaPrejuizoAcumuladoController.text = currentModel.contaPrejuizoAcumulado ?? '';
    contaLucroAcumuladoController.text = currentModel.contaLucroAcumulado ?? '';
    contaTituloPagarController.text = currentModel.contaTituloPagar ?? '';
    contaTituloReceberController.text = currentModel.contaTituloReceber ?? '';
    contaJurosPassivoController.text = currentModel.contaJurosPassivo ?? '';
    contaJurosAtivoController.text = currentModel.contaJurosAtivo ?? '';
    contaDescontoObtidoController.text = currentModel.contaDescontoObtido ?? '';
    contaDescontoConcedidoController.text = currentModel.contaDescontoConcedido ?? '';
    contaCmvController.text = currentModel.contaCmv ?? '';
    contaVendaController.text = currentModel.contaVenda ?? '';
    contaVendaServicoController.text = currentModel.contaVendaServico ?? '';
    contaEstoqueController.text = currentModel.contaEstoque ?? '';
    contaApuraResultadoController.text = currentModel.contaApuraResultado ?? '';
    contaJurosApropriarController.text = currentModel.contaJurosApropriar ?? '';
    idHistPadraoResultadoController.updateValue((currentModel.idHistPadraoResultado ?? 0).toDouble());
    idHistPadraoLucroController.updateValue((currentModel.idHistPadraoLucro ?? 0).toDouble());
    idHistPadraoPrejuizoController.updateValue((currentModel.idHistPadraoPrejuizo ?? 0).toDouble());
    formWasChanged = false;
  }

  @override
  Future<void> save() async {
    if (!formKey.currentState!.validate()) {
      showErrorSnackBar(message: 'validator_form_message'.tr);
      return;
    }

    final existingIndex = modelList.indexWhere((m) => m.id == currentModel.id);

    if (existingIndex >= 0) {
      modelList[existingIndex] = currentModel.clone();
    }

    final result = await repository.save(contabilParametroModel: currentModel);
    if (result == null) return;

    if (existingIndex >= 0) {
      modelList[existingIndex] = result;
    } else {
      modelList.insert(0, result);
    }

    if (!GetPlatform.isMobile) {
      updateGridRow(result);
    }

    Get.back(result: true);
  }


  @override
  void onClose() {
    mascaraController.dispose();
    niveisController.dispose();
    informarContaPorController.dispose();
    compartilhaPlanoContaController.dispose();
    compartilhaHistoricosController.dispose();
    alteraLancamentoOutroController.dispose();
    historicoObrigatorioController.dispose();
    permiteLancamentoZeradoController.dispose();
    geraInformativoSpedController.dispose();
    spedFormaEscritDiarioController.dispose();
    spedNomeLivroDiarioController.dispose();
    assinaturaDireitaController.dispose();
    assinaturaEsquerdaController.dispose();
    contaAtivoController.dispose();
    contaPassivoController.dispose();
    contaPatrimonioLiquidoController.dispose();
    contaDepreciacaoAcumuladaController.dispose();
    contaCapitalSocialController.dispose();
    contaResultadoExercicioController.dispose();
    contaPrejuizoAcumuladoController.dispose();
    contaLucroAcumuladoController.dispose();
    contaTituloPagarController.dispose();
    contaTituloReceberController.dispose();
    contaJurosPassivoController.dispose();
    contaJurosAtivoController.dispose();
    contaDescontoObtidoController.dispose();
    contaDescontoConcedidoController.dispose();
    contaCmvController.dispose();
    contaVendaController.dispose();
    contaVendaServicoController.dispose();
    contaEstoqueController.dispose();
    contaApuraResultadoController.dispose();
    contaJurosApropriarController.dispose();
    idHistPadraoResultadoController.dispose();
    idHistPadraoLucroController.dispose();
    idHistPadraoPrejuizoController.dispose();
    super.onClose();
  }

}