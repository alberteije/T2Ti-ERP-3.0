import 'package:get/get.dart';
import 'package:extended_masked_text/extended_masked_text.dart';
import 'package:contabil/app/page/shared_widget/input/input_imports.dart';

import 'package:contabil/app/page/shared_widget/message_dialog.dart';
import 'package:contabil/app/page/grid_columns/grid_columns_imports.dart';
import 'package:contabil/app/routes/app_routes.dart';
import 'package:contabil/app/controller/controller_imports.dart';
import 'package:contabil/app/data/model/model_imports.dart';
import 'package:contabil/app/data/repository/fap_repository.dart';

class FapController extends ControllerBase<FapModel, FapRepository> {

  FapController({required super.repository}) {
    dbColumns = FapModel.dbColumns;
    aliasColumns = FapModel.aliasColumns;
    gridColumns = fapGridColumns();
    functionName = "fap";
    screenTitle = "FAP";
  }

  @override
  FapModel createNewModel() => FapModel();

  @override
  final standardFieldForFilter = FapModel.aliasColumns[FapModel.dbColumns.indexOf('fap')];

  final fapController = MoneyMaskedTextController();
  final dataInicialController = DatePickerItemController(null);
  final dataFinalController = DatePickerItemController(null);

  final Map<String, dynamic> mobileConfig = {
    'primaryColumns': ['fap'],
    'secondaryColumns': ['data_inicial'],
  };

  List<Map<String, dynamic>> get mobileItems {
    return modelList.map((fap) => fap.toJson).toList();
  }

  @override
  void prepareForInsert() {
    isNewRecord = true;
    currentModel = createNewModel();
    _resetForm();
    Get.toNamed(Routes.fapEditPage);
  }

  void _resetForm() {
    formWasChanged = false;
    fapController.updateValue(0);
    dataInicialController.date = null;
    dataFinalController.date = null;
  }

  @override
  void selectRowForEditingById(int id) {
    final model = modelList.firstWhere((m) => m.id == id);
    currentModel = model.clone();
    updateControllersFromModel();
    Get.toNamed(Routes.fapEditPage);
  }

  void updateControllersFromModel() {
    fapController.updateValue(currentModel.fap ?? 0);
    dataInicialController.date = currentModel.dataInicial;
    dataFinalController.date = currentModel.dataFinal;
    formWasChanged = false;
  }

  @override
  Future<void> save() async {
    if (!formKey.currentState!.validate()) {
      showErrorSnackBar(message: 'validator_form_message'.tr);
      return;
    }

    final existingIndex = modelList.indexWhere((m) => m.id == currentModel.id);

    if (existingIndex >= 0) {
      modelList[existingIndex] = currentModel.clone();
    }

    final result = await repository.save(fapModel: currentModel);
    if (result == null) return;

    if (existingIndex >= 0) {
      modelList[existingIndex] = result;
    } else {
      modelList.insert(0, result);
    }

    if (!GetPlatform.isMobile) {
      updateGridRow(result);
    }

    Get.back(result: true);
  }


  @override
  void onClose() {
    fapController.dispose();
    dataInicialController.dispose();
    dataFinalController.dispose();
    super.onClose();
  }

}