import 'package:flutter/material.dart';
import 'dart:math';
import 'package:get/get.dart';
import 'package:extended_masked_text/extended_masked_text.dart';
import 'package:contabil/app/page/shared_widget/input/input_imports.dart';

import 'package:contabil/app/infra/infra_imports.dart';
import 'package:contabil/app/page/page_imports.dart';
import 'package:contabil/app/page/shared_widget/message_dialog.dart';
import 'package:contabil/app/page/grid_columns/grid_columns_imports.dart';
import 'package:contabil/app/routes/app_routes.dart';
import 'package:contabil/app/controller/controller_imports.dart';
import 'package:contabil/app/data/model/model_imports.dart';
import 'package:contabil/app/data/repository/contabil_dre_cabecalho_repository.dart';

class ContabilDreCabecalhoController extends ControllerBase<ContabilDreCabecalhoModel, ContabilDreCabecalhoRepository> 
with GetSingleTickerProviderStateMixin {

  ContabilDreCabecalhoController({required super.repository}) {
    dbColumns = ContabilDreCabecalhoModel.dbColumns;
    aliasColumns = ContabilDreCabecalhoModel.aliasColumns;
    gridColumns = contabilDreCabecalhoGridColumns();
    functionName = "contabil_dre_cabecalho";
    screenTitle = "DRE";
  }

  final contabilDreCabecalhoScaffoldKey = GlobalKey<ScaffoldState>();
  final contabilDreCabecalhoTabPageScaffoldKey = GlobalKey<ScaffoldState>();
  final contabilDreCabecalhoFormKey = GlobalKey<FormState>();
  late TabController tabController;
  String? mandatoryMessage;  

  @override
  ContabilDreCabecalhoModel createNewModel() => ContabilDreCabecalhoModel();

  @override
  final standardFieldForFilter = ContabilDreCabecalhoModel.aliasColumns[ContabilDreCabecalhoModel.dbColumns.indexOf('descricao')];

  final descricaoController = TextEditingController();
  final padraoController = CustomDropdownButtonController('Sim');
  final periodoInicialController = MaskedTextController(mask: '00/0000',);
  final periodoFinalController = MaskedTextController(mask: '00/0000',);

  final Map<String, dynamic> mobileConfig = {
    'primaryColumns': ['descricao'],
    'secondaryColumns': ['padrao'],
  };

  List<Map<String, dynamic>> get mobileItems {
    return modelList.map((contabilDreCabecalho) => contabilDreCabecalho.toJson).toList();
  }

  @override
  void prepareForInsert() {
    isNewRecord = true;
    currentModel = createNewModel();
    _resetForm();
    tabController.animateTo(0);
    updateControllersFromModel();
    Get.toNamed(Routes.contabilDreCabecalhoTabPage);
  }

  void _resetForm() {
    formWasChanged = false;
    descricaoController.text = '';
    padraoController.selected = 'Sim';
    periodoInicialController.text = '';
    periodoFinalController.text = '';
  }

  @override
  void selectRowForEditingById(int id) {
    final model = modelList.firstWhere((m) => m.id == id);
    currentModel = model.clone();
    updateControllersFromModel();
    tabController.animateTo(0);
    Get.toNamed(Routes.contabilDreCabecalhoTabPage);
  }

  _configureChildrenControllers() {
    //Detalhes
		Get.put<ContabilDreDetalheController>(ContabilDreDetalheController()); 

  }
	
	_releaseChildrenControllers() {
    //Detalhes
		Get.delete<ContabilDreDetalheController>(); 

	}
  
  void updateControllersFromModel() {
    descricaoController.text = currentModel.descricao ?? '';
    padraoController.selected = currentModel.padrao ?? 'Sim';
    periodoInicialController.text = currentModel.periodoInicial ?? '';
    periodoFinalController.text = currentModel.periodoFinal ?? '';

    formWasChanged = false;
    _updateChildrenControllersFromModel();
  }

  void _updateChildrenControllersFromModel() {
    //Detalhes
		final contabilDreDetalheController = Get.find<ContabilDreDetalheController>(); 
		contabilDreDetalheController.userMadeChanges = false; 

  }

  @override
  Future<void> save() async {
    if (!validateCurrentForm()) return;
    if (validateForms()) {
      if (userMadeChanges()) {
        final existingIndex = modelList.indexWhere((m) => m.id == currentModel.id);

        if (existingIndex >= 0) {
          modelList[existingIndex] = currentModel.clone();
        }

        final result = await repository.save(contabilDreCabecalhoModel: currentModel);
        if (result == null) return;

        if (existingIndex >= 0) {
          modelList[existingIndex] = result;
        } else {
          modelList.insert(0, result);
        }

        if (!GetPlatform.isMobile) {
          updateGridRow(result);
        }

        Get.back(result: true);
      } else {
        Get.back();
      }
    } 
  }


  List<Tab> tabItems = [
    Tab( 
			icon: Icon(iconDataList[Random().nextInt(10)]), 
			text: 'DRE', 
		),
    Tab( 
			icon: Icon(iconDataList[Random().nextInt(10)]), 
			text: 'Detalhes', 
		),
  ];

  List<Widget> tabPages() {
    return [
      ContabilDreCabecalhoEditPage(),
      const ContabilDreDetalheListPage(),
    ];
  }

  @override
  void preventDataLoss() {
    if (userMadeChanges()) {
      showQuestionDialog('message_data_loss'.tr, () { 
        Get.back(); 
      });
    } else {
      Get.back();
    }
  }  

  bool userMadeChanges() {
    return
    formWasChanged 
    || 
		Get.find<ContabilDreDetalheController>().userMadeChanges
    ;
  }

  void tabChange(int index) {
    validateCurrentForm();
  }

  bool validateCurrentForm() {
    return true;
  }

  bool validateForms() {
    return true;
  }

  @override
  void onInit() {
    super.onInit();
    tabController = TabController(vsync: this, length: tabItems.length);
    _configureChildrenControllers();
  }
	
  @override
  void onClose() {
    tabController.dispose();
    descricaoController.dispose();
    padraoController.dispose();
    periodoInicialController.dispose();
    periodoFinalController.dispose();
    _releaseChildrenControllers();
    super.onClose();
  }	
}