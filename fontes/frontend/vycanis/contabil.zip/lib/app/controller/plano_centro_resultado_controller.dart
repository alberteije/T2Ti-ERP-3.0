import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:extended_masked_text/extended_masked_text.dart';
import 'package:contabil/app/page/shared_widget/input/input_imports.dart';

import 'package:contabil/app/page/shared_widget/message_dialog.dart';
import 'package:contabil/app/page/grid_columns/grid_columns_imports.dart';
import 'package:contabil/app/routes/app_routes.dart';
import 'package:contabil/app/controller/controller_imports.dart';
import 'package:contabil/app/data/model/model_imports.dart';
import 'package:contabil/app/data/repository/plano_centro_resultado_repository.dart';

class PlanoCentroResultadoController extends ControllerBase<PlanoCentroResultadoModel, PlanoCentroResultadoRepository> {

  PlanoCentroResultadoController({required super.repository}) {
    dbColumns = PlanoCentroResultadoModel.dbColumns;
    aliasColumns = PlanoCentroResultadoModel.aliasColumns;
    gridColumns = planoCentroResultadoGridColumns();
    functionName = "plano_centro_resultado";
    screenTitle = "Plano Centro Resultado";
  }

  @override
  PlanoCentroResultadoModel createNewModel() => PlanoCentroResultadoModel();

  @override
  final standardFieldForFilter = PlanoCentroResultadoModel.aliasColumns[PlanoCentroResultadoModel.dbColumns.indexOf('nome')];

  final nomeController = TextEditingController();
  final mascaraController = TextEditingController();
  final niveisController = MoneyMaskedTextController(precision: 0, decimalSeparator: '', thousandSeparator: '');
  final dataInclusaoController = DatePickerItemController(null);

  final Map<String, dynamic> mobileConfig = {
    'primaryColumns': ['nome'],
    'secondaryColumns': ['mascara'],
  };

  List<Map<String, dynamic>> get mobileItems {
    return modelList.map((planoCentroResultado) => planoCentroResultado.toJson).toList();
  }

  @override
  void prepareForInsert() {
    isNewRecord = true;
    currentModel = createNewModel();
    _resetForm();
    Get.toNamed(Routes.planoCentroResultadoEditPage);
  }

  void _resetForm() {
    formWasChanged = false;
    nomeController.text = '';
    mascaraController.text = '';
    niveisController.updateValue(0);
    dataInclusaoController.date = null;
  }

  @override
  void selectRowForEditingById(int id) {
    final model = modelList.firstWhere((m) => m.id == id);
    currentModel = model.clone();
    updateControllersFromModel();
    Get.toNamed(Routes.planoCentroResultadoEditPage);
  }

  void updateControllersFromModel() {
    nomeController.text = currentModel.nome ?? '';
    mascaraController.text = currentModel.mascara ?? '';
    niveisController.updateValue((currentModel.niveis ?? 0).toDouble());
    dataInclusaoController.date = currentModel.dataInclusao;
    formWasChanged = false;
  }

  @override
  Future<void> save() async {
    if (!formKey.currentState!.validate()) {
      showErrorSnackBar(message: 'validator_form_message'.tr);
      return;
    }

    final existingIndex = modelList.indexWhere((m) => m.id == currentModel.id);

    if (existingIndex >= 0) {
      modelList[existingIndex] = currentModel.clone();
    }

    final result = await repository.save(planoCentroResultadoModel: currentModel);
    if (result == null) return;

    if (existingIndex >= 0) {
      modelList[existingIndex] = result;
    } else {
      modelList.insert(0, result);
    }

    if (!GetPlatform.isMobile) {
      updateGridRow(result);
    }

    Get.back(result: true);
  }


  @override
  void onClose() {
    nomeController.dispose();
    mascaraController.dispose();
    niveisController.dispose();
    dataInclusaoController.dispose();
    super.onClose();
  }

}