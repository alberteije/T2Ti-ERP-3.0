import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:extended_masked_text/extended_masked_text.dart';
import 'package:contabil/app/page/shared_widget/input/input_imports.dart';

import 'package:contabil/app/page/shared_widget/message_dialog.dart';
import 'package:contabil/app/page/grid_columns/grid_columns_imports.dart';
import 'package:contabil/app/routes/app_routes.dart';
import 'package:contabil/app/controller/controller_imports.dart';
import 'package:contabil/app/data/model/model_imports.dart';
import 'package:contabil/app/data/repository/contabil_conta_repository.dart';

class ContabilContaController extends ControllerBase<ContabilContaModel, ContabilContaRepository> {

  ContabilContaController({required super.repository}) {
    dbColumns = ContabilContaModel.dbColumns;
    aliasColumns = ContabilContaModel.aliasColumns;
    gridColumns = contabilContaGridColumns();
    functionName = "contabil_conta";
    screenTitle = "Conta Contábil";
  }

  @override
  ContabilContaModel createNewModel() => ContabilContaModel();

  @override
  final standardFieldForFilter = ContabilContaModel.aliasColumns[ContabilContaModel.dbColumns.indexOf('id_contabil_conta')];

  final planoContaModelController = TextEditingController();
  final planoContaRefSpedModelController = TextEditingController();
  final idContabilContaController = MoneyMaskedTextController(precision: 0, decimalSeparator: '', thousandSeparator: '');
  final classificacaoController = TextEditingController();
  final tipoController = CustomDropdownButtonController('Sintética');
  final descricaoController = TextEditingController();
  final dataInclusaoController = DatePickerItemController(null);
  final situacaoController = CustomDropdownButtonController('Ativa');
  final naturezaController = CustomDropdownButtonController('Credora');
  final patrimonioResultadoController = CustomDropdownButtonController('Patrimonio');
  final livroCaixaController = CustomDropdownButtonController('Sim');
  final dfcController = CustomDropdownButtonController('Não participa');
  final codigoEfdController = TextEditingController();
  final ordemController = TextEditingController();
  final codigoReduzidoController = TextEditingController();

  final Map<String, dynamic> mobileConfig = {
    'primaryColumns': ['id_contabil_conta'],
    'secondaryColumns': ['classificacao'],
  };

  List<Map<String, dynamic>> get mobileItems {
    return modelList.map((contabilConta) => contabilConta.toJson).toList();
  }

  @override
  void prepareForInsert() {
    isNewRecord = true;
    currentModel = createNewModel();
    _resetForm();
    Get.toNamed(Routes.contabilContaEditPage);
  }

  void _resetForm() {
    formWasChanged = false;
    planoContaModelController.text = '';
    planoContaRefSpedModelController.text = '';
    idContabilContaController.updateValue(0);
    classificacaoController.text = '';
    tipoController.selected = 'Sintética';
    descricaoController.text = '';
    dataInclusaoController.date = null;
    situacaoController.selected = 'Ativa';
    naturezaController.selected = 'Credora';
    patrimonioResultadoController.selected = 'Patrimonio';
    livroCaixaController.selected = 'Sim';
    dfcController.selected = 'Não participa';
    codigoEfdController.text = '';
    ordemController.text = '';
    codigoReduzidoController.text = '';
  }

  @override
  void selectRowForEditingById(int id) {
    final model = modelList.firstWhere((m) => m.id == id);
    currentModel = model.clone();
    updateControllersFromModel();
    Get.toNamed(Routes.contabilContaEditPage);
  }

  void updateControllersFromModel() {
    planoContaModelController.text = currentModel.planoContaModel?.nome?.toString() ?? '';
    planoContaRefSpedModelController.text = currentModel.planoContaRefSpedModel?.codCtaRef?.toString() ?? '';
    idContabilContaController.updateValue((currentModel.idContabilConta ?? 0).toDouble());
    classificacaoController.text = currentModel.classificacao ?? '';
    tipoController.selected = currentModel.tipo ?? 'Sintética';
    descricaoController.text = currentModel.descricao ?? '';
    dataInclusaoController.date = currentModel.dataInclusao;
    situacaoController.selected = currentModel.situacao ?? 'Ativa';
    naturezaController.selected = currentModel.natureza ?? 'Credora';
    patrimonioResultadoController.selected = currentModel.patrimonioResultado ?? 'Patrimonio';
    livroCaixaController.selected = currentModel.livroCaixa ?? 'Sim';
    dfcController.selected = currentModel.dfc ?? 'Não participa';
    codigoEfdController.text = currentModel.codigoEfd ?? '';
    ordemController.text = currentModel.ordem ?? '';
    codigoReduzidoController.text = currentModel.codigoReduzido ?? '';
    formWasChanged = false;
  }

  @override
  Future<void> save() async {
    if (!formKey.currentState!.validate()) {
      showErrorSnackBar(message: 'validator_form_message'.tr);
      return;
    }

    final existingIndex = modelList.indexWhere((m) => m.id == currentModel.id);

    if (existingIndex >= 0) {
      modelList[existingIndex] = currentModel.clone();
    }

    final result = await repository.save(contabilContaModel: currentModel);
    if (result == null) return;

    if (existingIndex >= 0) {
      modelList[existingIndex] = result;
    } else {
      modelList.insert(0, result);
    }

    if (!GetPlatform.isMobile) {
      updateGridRow(result);
    }

    Get.back(result: true);
  }

  Future callPlanoContaLookup() async { 
		final lookupController = Get.find<LookupController>(); 
		lookupController.refreshItems(standardValue: '%'); 
		lookupController.title = '${'lookup_page_title'.tr} [Plano Conta]'; 
		lookupController.route = '/plano-conta/'; 
		lookupController.gridColumns = planoContaGridColumns(isForLookup: true); 
		lookupController.aliasColumns = PlanoContaModel.aliasColumns; 
		lookupController.dbColumns = PlanoContaModel.dbColumns; 
		lookupController.standardColumn = PlanoContaModel.aliasColumns[PlanoContaModel.dbColumns.indexOf('nome')]; 

		final plutoRowResult = await Get.toNamed(Routes.lookupPage); 
		if (plutoRowResult != null) { 
			currentModel.idPlanoConta = plutoRowResult.cells['id']!.value; 
			currentModel.planoContaModel = PlanoContaModel.fromPlutoRow(plutoRowResult); 
			planoContaModelController.text = currentModel.planoContaModel?.nome ?? ''; 
			formWasChanged = true; 
		}
	}

  Future callPlanoContaRefSpedLookup() async { 
		final lookupController = Get.find<LookupController>(); 
		lookupController.refreshItems(standardValue: '%'); 
		lookupController.title = '${'lookup_page_title'.tr} [Conta SPED]'; 
		lookupController.route = '/plano-conta-ref-sped/'; 
		lookupController.gridColumns = planoContaRefSpedGridColumns(isForLookup: true); 
		lookupController.aliasColumns = PlanoContaRefSpedModel.aliasColumns; 
		lookupController.dbColumns = PlanoContaRefSpedModel.dbColumns; 
		lookupController.standardColumn = PlanoContaRefSpedModel.aliasColumns[PlanoContaRefSpedModel.dbColumns.indexOf('cod_cta_ref')]; 

		final plutoRowResult = await Get.toNamed(Routes.lookupPage); 
		if (plutoRowResult != null) { 
			currentModel.idPlanoContaRefSped = plutoRowResult.cells['id']!.value; 
			currentModel.planoContaRefSpedModel = PlanoContaRefSpedModel.fromPlutoRow(plutoRowResult); 
			planoContaRefSpedModelController.text = currentModel.planoContaRefSpedModel?.codCtaRef ?? ''; 
			formWasChanged = true; 
		}
	}


  @override
  void onClose() {
    planoContaModelController.dispose();
    planoContaRefSpedModelController.dispose();
    idContabilContaController.dispose();
    classificacaoController.dispose();
    tipoController.dispose();
    descricaoController.dispose();
    dataInclusaoController.dispose();
    situacaoController.dispose();
    naturezaController.dispose();
    patrimonioResultadoController.dispose();
    livroCaixaController.dispose();
    dfcController.dispose();
    codigoEfdController.dispose();
    ordemController.dispose();
    codigoReduzidoController.dispose();
    super.onClose();
  }

}