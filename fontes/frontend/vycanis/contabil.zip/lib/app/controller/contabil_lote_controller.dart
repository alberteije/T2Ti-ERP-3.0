import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:extended_masked_text/extended_masked_text.dart';
import 'package:contabil/app/page/shared_widget/input/input_imports.dart';

import 'package:contabil/app/page/shared_widget/message_dialog.dart';
import 'package:contabil/app/page/grid_columns/grid_columns_imports.dart';
import 'package:contabil/app/routes/app_routes.dart';
import 'package:contabil/app/controller/controller_imports.dart';
import 'package:contabil/app/data/model/model_imports.dart';
import 'package:contabil/app/data/repository/contabil_lote_repository.dart';

class ContabilLoteController extends ControllerBase<ContabilLoteModel, ContabilLoteRepository> {

  ContabilLoteController({required super.repository}) {
    dbColumns = ContabilLoteModel.dbColumns;
    aliasColumns = ContabilLoteModel.aliasColumns;
    gridColumns = contabilLoteGridColumns();
    functionName = "contabil_lote";
    screenTitle = "Lote Contábil";
  }

  @override
  ContabilLoteModel createNewModel() => ContabilLoteModel();

  @override
  final standardFieldForFilter = ContabilLoteModel.aliasColumns[ContabilLoteModel.dbColumns.indexOf('descricao')];

  final descricaoController = TextEditingController();
  final dataInclusaoController = DatePickerItemController(null);
  final dataLiberacaoController = DatePickerItemController(null);
  final liberadoController = CustomDropdownButtonController('Sim');
  final programadoController = CustomDropdownButtonController('Sim');
  final valorController = MoneyMaskedTextController();

  final Map<String, dynamic> mobileConfig = {
    'primaryColumns': ['descricao'],
    'secondaryColumns': ['data_inclusao'],
  };

  List<Map<String, dynamic>> get mobileItems {
    return modelList.map((contabilLote) => contabilLote.toJson).toList();
  }

  @override
  void prepareForInsert() {
    isNewRecord = true;
    currentModel = createNewModel();
    _resetForm();
    Get.toNamed(Routes.contabilLoteEditPage);
  }

  void _resetForm() {
    formWasChanged = false;
    descricaoController.text = '';
    dataInclusaoController.date = null;
    dataLiberacaoController.date = null;
    liberadoController.selected = 'Sim';
    programadoController.selected = 'Sim';
    valorController.updateValue(0);
  }

  @override
  void selectRowForEditingById(int id) {
    final model = modelList.firstWhere((m) => m.id == id);
    currentModel = model.clone();
    updateControllersFromModel();
    Get.toNamed(Routes.contabilLoteEditPage);
  }

  void updateControllersFromModel() {
    descricaoController.text = currentModel.descricao ?? '';
    dataInclusaoController.date = currentModel.dataInclusao;
    dataLiberacaoController.date = currentModel.dataLiberacao;
    liberadoController.selected = currentModel.liberado ?? 'Sim';
    programadoController.selected = currentModel.programado ?? 'Sim';
    valorController.updateValue(currentModel.valor ?? 0);
    formWasChanged = false;
  }

  @override
  Future<void> save() async {
    if (!formKey.currentState!.validate()) {
      showErrorSnackBar(message: 'validator_form_message'.tr);
      return;
    }

    final existingIndex = modelList.indexWhere((m) => m.id == currentModel.id);

    if (existingIndex >= 0) {
      modelList[existingIndex] = currentModel.clone();
    }

    final result = await repository.save(contabilLoteModel: currentModel);
    if (result == null) return;

    if (existingIndex >= 0) {
      modelList[existingIndex] = result;
    } else {
      modelList.insert(0, result);
    }

    if (!GetPlatform.isMobile) {
      updateGridRow(result);
    }

    Get.back(result: true);
  }


  @override
  void onClose() {
    descricaoController.dispose();
    dataInclusaoController.dispose();
    dataLiberacaoController.dispose();
    liberadoController.dispose();
    programadoController.dispose();
    valorController.dispose();
    super.onClose();
  }

}