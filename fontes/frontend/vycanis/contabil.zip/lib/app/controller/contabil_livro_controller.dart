import 'package:flutter/material.dart';
import 'dart:math';
import 'package:get/get.dart';
import 'package:extended_masked_text/extended_masked_text.dart';
import 'package:contabil/app/page/shared_widget/input/input_imports.dart';

import 'package:contabil/app/infra/infra_imports.dart';
import 'package:contabil/app/page/page_imports.dart';
import 'package:contabil/app/page/shared_widget/message_dialog.dart';
import 'package:contabil/app/page/grid_columns/grid_columns_imports.dart';
import 'package:contabil/app/routes/app_routes.dart';
import 'package:contabil/app/controller/controller_imports.dart';
import 'package:contabil/app/data/model/model_imports.dart';
import 'package:contabil/app/data/repository/contabil_livro_repository.dart';

class ContabilLivroController extends ControllerBase<ContabilLivroModel, ContabilLivroRepository> 
with GetSingleTickerProviderStateMixin {

  ContabilLivroController({required super.repository}) {
    dbColumns = ContabilLivroModel.dbColumns;
    aliasColumns = ContabilLivroModel.aliasColumns;
    gridColumns = contabilLivroGridColumns();
    functionName = "contabil_livro";
    screenTitle = "Livros";
  }

  final contabilLivroScaffoldKey = GlobalKey<ScaffoldState>();
  final contabilLivroTabPageScaffoldKey = GlobalKey<ScaffoldState>();
  final contabilLivroFormKey = GlobalKey<FormState>();
  late TabController tabController;
  String? mandatoryMessage;  

  @override
  ContabilLivroModel createNewModel() => ContabilLivroModel();

  @override
  final standardFieldForFilter = ContabilLivroModel.aliasColumns[ContabilLivroModel.dbColumns.indexOf('competencia')];

  final competenciaController = MaskedTextController(mask: '00:0000',);
  final formaEscrituracaoController = CustomDropdownButtonController('Diário Geral');
  final descricaoController = TextEditingController();

  final Map<String, dynamic> mobileConfig = {
    'primaryColumns': ['competencia'],
    'secondaryColumns': ['forma_escrituracao'],
  };

  List<Map<String, dynamic>> get mobileItems {
    return modelList.map((contabilLivro) => contabilLivro.toJson).toList();
  }

  @override
  void prepareForInsert() {
    isNewRecord = true;
    currentModel = createNewModel();
    _resetForm();
    tabController.animateTo(0);
    updateControllersFromModel();
    Get.toNamed(Routes.contabilLivroTabPage);
  }

  void _resetForm() {
    formWasChanged = false;
    competenciaController.text = '';
    formaEscrituracaoController.selected = 'Diário Geral';
    descricaoController.text = '';
  }

  @override
  void selectRowForEditingById(int id) {
    final model = modelList.firstWhere((m) => m.id == id);
    currentModel = model.clone();
    updateControllersFromModel();
    tabController.animateTo(0);
    Get.toNamed(Routes.contabilLivroTabPage);
  }

  _configureChildrenControllers() {
    //Termos
		Get.put<ContabilTermoController>(ContabilTermoController()); 

  }
	
	_releaseChildrenControllers() {
    //Termos
		Get.delete<ContabilTermoController>(); 

	}
  
  void updateControllersFromModel() {
    competenciaController.text = currentModel.competencia ?? '';
    formaEscrituracaoController.selected = currentModel.formaEscrituracao ?? 'Diário Geral';
    descricaoController.text = currentModel.descricao ?? '';

    formWasChanged = false;
    _updateChildrenControllersFromModel();
  }

  void _updateChildrenControllersFromModel() {
    //Termos
		final contabilTermoController = Get.find<ContabilTermoController>(); 
		contabilTermoController.userMadeChanges = false; 

  }

  @override
  Future<void> save() async {
    if (!validateCurrentForm()) return;
    if (validateForms()) {
      if (userMadeChanges()) {
        final existingIndex = modelList.indexWhere((m) => m.id == currentModel.id);

        if (existingIndex >= 0) {
          modelList[existingIndex] = currentModel.clone();
        }

        final result = await repository.save(contabilLivroModel: currentModel);
        if (result == null) return;

        if (existingIndex >= 0) {
          modelList[existingIndex] = result;
        } else {
          modelList.insert(0, result);
        }

        if (!GetPlatform.isMobile) {
          updateGridRow(result);
        }

        Get.back(result: true);
      } else {
        Get.back();
      }
    } 
  }


  List<Tab> tabItems = [
    Tab( 
			icon: Icon(iconDataList[Random().nextInt(10)]), 
			text: 'Livros', 
		),
    Tab( 
			icon: Icon(iconDataList[Random().nextInt(10)]), 
			text: 'Termos', 
		),
  ];

  List<Widget> tabPages() {
    return [
      ContabilLivroEditPage(),
      const ContabilTermoListPage(),
    ];
  }

  @override
  void preventDataLoss() {
    if (userMadeChanges()) {
      showQuestionDialog('message_data_loss'.tr, () { 
        Get.back(); 
      });
    } else {
      Get.back();
    }
  }  

  bool userMadeChanges() {
    return
    formWasChanged 
    || 
		Get.find<ContabilTermoController>().userMadeChanges
    ;
  }

  void tabChange(int index) {
    validateCurrentForm();
  }

  bool validateCurrentForm() {
    return true;
  }

  bool validateForms() {
    return true;
  }

  @override
  void onInit() {
    super.onInit();
    tabController = TabController(vsync: this, length: tabItems.length);
    _configureChildrenControllers();
  }
	
  @override
  void onClose() {
    tabController.dispose();
    competenciaController.dispose();
    formaEscrituracaoController.dispose();
    descricaoController.dispose();
    _releaseChildrenControllers();
    super.onClose();
  }	
}