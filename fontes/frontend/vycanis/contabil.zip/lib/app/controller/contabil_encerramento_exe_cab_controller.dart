import 'package:flutter/material.dart';
import 'dart:math';
import 'package:get/get.dart';
import 'package:contabil/app/page/shared_widget/input/input_imports.dart';

import 'package:contabil/app/infra/infra_imports.dart';
import 'package:contabil/app/page/page_imports.dart';
import 'package:contabil/app/page/shared_widget/message_dialog.dart';
import 'package:contabil/app/page/grid_columns/grid_columns_imports.dart';
import 'package:contabil/app/routes/app_routes.dart';
import 'package:contabil/app/controller/controller_imports.dart';
import 'package:contabil/app/data/model/model_imports.dart';
import 'package:contabil/app/data/repository/contabil_encerramento_exe_cab_repository.dart';

class ContabilEncerramentoExeCabController extends ControllerBase<ContabilEncerramentoExeCabModel, ContabilEncerramentoExeCabRepository> 
with GetSingleTickerProviderStateMixin {

  ContabilEncerramentoExeCabController({required super.repository}) {
    dbColumns = ContabilEncerramentoExeCabModel.dbColumns;
    aliasColumns = ContabilEncerramentoExeCabModel.aliasColumns;
    gridColumns = contabilEncerramentoExeCabGridColumns();
    functionName = "contabil_encerramento_exe_cab";
    screenTitle = "Encerramento do Exercício";
  }

  final contabilEncerramentoExeCabScaffoldKey = GlobalKey<ScaffoldState>();
  final contabilEncerramentoExeCabTabPageScaffoldKey = GlobalKey<ScaffoldState>();
  final contabilEncerramentoExeCabFormKey = GlobalKey<FormState>();
  late TabController tabController;
  String? mandatoryMessage;  

  @override
  ContabilEncerramentoExeCabModel createNewModel() => ContabilEncerramentoExeCabModel();

  @override
  final standardFieldForFilter = ContabilEncerramentoExeCabModel.aliasColumns[ContabilEncerramentoExeCabModel.dbColumns.indexOf('data_inicio')];

  final dataInicioController = DatePickerItemController(null);
  final dataFimController = DatePickerItemController(null);
  final dataInclusaoController = DatePickerItemController(null);
  final motivoController = TextEditingController();

  final Map<String, dynamic> mobileConfig = {
    'primaryColumns': ['data_inicio'],
    'secondaryColumns': ['data_fim'],
  };

  List<Map<String, dynamic>> get mobileItems {
    return modelList.map((contabilEncerramentoExeCab) => contabilEncerramentoExeCab.toJson).toList();
  }

  @override
  void prepareForInsert() {
    isNewRecord = true;
    currentModel = createNewModel();
    _resetForm();
    tabController.animateTo(0);
    updateControllersFromModel();
    Get.toNamed(Routes.contabilEncerramentoExeCabTabPage);
  }

  void _resetForm() {
    formWasChanged = false;
    dataInicioController.date = null;
    dataFimController.date = null;
    dataInclusaoController.date = null;
    motivoController.text = '';
  }

  @override
  void selectRowForEditingById(int id) {
    final model = modelList.firstWhere((m) => m.id == id);
    currentModel = model.clone();
    updateControllersFromModel();
    tabController.animateTo(0);
    Get.toNamed(Routes.contabilEncerramentoExeCabTabPage);
  }

  _configureChildrenControllers() {
    //Detalhes
		Get.put<ContabilEncerramentoExeDetController>(ContabilEncerramentoExeDetController()); 

  }
	
	_releaseChildrenControllers() {
    //Detalhes
		Get.delete<ContabilEncerramentoExeDetController>(); 

	}
  
  void updateControllersFromModel() {
    dataInicioController.date = currentModel.dataInicio;
    dataFimController.date = currentModel.dataFim;
    dataInclusaoController.date = currentModel.dataInclusao;
    motivoController.text = currentModel.motivo ?? '';

    formWasChanged = false;
    _updateChildrenControllersFromModel();
  }

  void _updateChildrenControllersFromModel() {
    //Detalhes
		final contabilEncerramentoExeDetController = Get.find<ContabilEncerramentoExeDetController>(); 
		contabilEncerramentoExeDetController.userMadeChanges = false; 

  }

  @override
  Future<void> save() async {
    if (!validateCurrentForm()) return;
    if (validateForms()) {
      if (userMadeChanges()) {
        final existingIndex = modelList.indexWhere((m) => m.id == currentModel.id);

        if (existingIndex >= 0) {
          modelList[existingIndex] = currentModel.clone();
        }

        final result = await repository.save(contabilEncerramentoExeCabModel: currentModel);
        if (result == null) return;

        if (existingIndex >= 0) {
          modelList[existingIndex] = result;
        } else {
          modelList.insert(0, result);
        }

        if (!GetPlatform.isMobile) {
          updateGridRow(result);
        }

        Get.back(result: true);
      } else {
        Get.back();
      }
    } 
  }


  List<Tab> tabItems = [
    Tab( 
			icon: Icon(iconDataList[Random().nextInt(10)]), 
			text: 'Encerramento do Exercício', 
		),
    Tab( 
			icon: Icon(iconDataList[Random().nextInt(10)]), 
			text: 'Detalhes', 
		),
  ];

  List<Widget> tabPages() {
    return [
      ContabilEncerramentoExeCabEditPage(),
      const ContabilEncerramentoExeDetListPage(),
    ];
  }

  @override
  void preventDataLoss() {
    if (userMadeChanges()) {
      showQuestionDialog('message_data_loss'.tr, () { 
        Get.back(); 
      });
    } else {
      Get.back();
    }
  }  

  bool userMadeChanges() {
    return
    formWasChanged 
    || 
		Get.find<ContabilEncerramentoExeDetController>().userMadeChanges
    ;
  }

  void tabChange(int index) {
    validateCurrentForm();
  }

  bool validateCurrentForm() {
    return true;
  }

  bool validateForms() {
    return true;
  }

  @override
  void onInit() {
    super.onInit();
    tabController = TabController(vsync: this, length: tabItems.length);
    _configureChildrenControllers();
  }
	
  @override
  void onClose() {
    tabController.dispose();
    dataInicioController.dispose();
    dataFimController.dispose();
    dataInclusaoController.dispose();
    motivoController.dispose();
    _releaseChildrenControllers();
    super.onClose();
  }	
}