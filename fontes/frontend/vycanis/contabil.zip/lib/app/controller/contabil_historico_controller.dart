import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:contabil/app/page/shared_widget/input/input_imports.dart';

import 'package:contabil/app/page/shared_widget/message_dialog.dart';
import 'package:contabil/app/page/grid_columns/grid_columns_imports.dart';
import 'package:contabil/app/routes/app_routes.dart';
import 'package:contabil/app/controller/controller_imports.dart';
import 'package:contabil/app/data/model/model_imports.dart';
import 'package:contabil/app/data/repository/contabil_historico_repository.dart';

class ContabilHistoricoController extends ControllerBase<ContabilHistoricoModel, ContabilHistoricoRepository> {

  ContabilHistoricoController({required super.repository}) {
    dbColumns = ContabilHistoricoModel.dbColumns;
    aliasColumns = ContabilHistoricoModel.aliasColumns;
    gridColumns = contabilHistoricoGridColumns();
    functionName = "contabil_historico";
    screenTitle = "Históricos";
  }

  @override
  ContabilHistoricoModel createNewModel() => ContabilHistoricoModel();

  @override
  final standardFieldForFilter = ContabilHistoricoModel.aliasColumns[ContabilHistoricoModel.dbColumns.indexOf('descricao')];

  final descricaoController = TextEditingController();
  final pedeComplementoController = CustomDropdownButtonController('Sim');
  final historicoController = TextEditingController();

  final Map<String, dynamic> mobileConfig = {
    'primaryColumns': ['descricao'],
    'secondaryColumns': ['pede_complemento'],
  };

  List<Map<String, dynamic>> get mobileItems {
    return modelList.map((contabilHistorico) => contabilHistorico.toJson).toList();
  }

  @override
  void prepareForInsert() {
    isNewRecord = true;
    currentModel = createNewModel();
    _resetForm();
    Get.toNamed(Routes.contabilHistoricoEditPage);
  }

  void _resetForm() {
    formWasChanged = false;
    descricaoController.text = '';
    pedeComplementoController.selected = 'Sim';
    historicoController.text = '';
  }

  @override
  void selectRowForEditingById(int id) {
    final model = modelList.firstWhere((m) => m.id == id);
    currentModel = model.clone();
    updateControllersFromModel();
    Get.toNamed(Routes.contabilHistoricoEditPage);
  }

  void updateControllersFromModel() {
    descricaoController.text = currentModel.descricao ?? '';
    pedeComplementoController.selected = currentModel.pedeComplemento ?? 'Sim';
    historicoController.text = currentModel.historico ?? '';
    formWasChanged = false;
  }

  @override
  Future<void> save() async {
    if (!formKey.currentState!.validate()) {
      showErrorSnackBar(message: 'validator_form_message'.tr);
      return;
    }

    final existingIndex = modelList.indexWhere((m) => m.id == currentModel.id);

    if (existingIndex >= 0) {
      modelList[existingIndex] = currentModel.clone();
    }

    final result = await repository.save(contabilHistoricoModel: currentModel);
    if (result == null) return;

    if (existingIndex >= 0) {
      modelList[existingIndex] = result;
    } else {
      modelList.insert(0, result);
    }

    if (!GetPlatform.isMobile) {
      updateGridRow(result);
    }

    Get.back(result: true);
  }


  @override
  void onClose() {
    descricaoController.dispose();
    pedeComplementoController.dispose();
    historicoController.dispose();
    super.onClose();
  }

}