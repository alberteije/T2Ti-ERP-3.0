import 'package:flutter/material.dart';
import 'dart:math';
import 'package:get/get.dart';
import 'package:extended_masked_text/extended_masked_text.dart';
import 'package:contabil/app/page/shared_widget/input/input_imports.dart';

import 'package:contabil/app/infra/infra_imports.dart';
import 'package:contabil/app/page/page_imports.dart';
import 'package:contabil/app/page/shared_widget/message_dialog.dart';
import 'package:contabil/app/page/grid_columns/grid_columns_imports.dart';
import 'package:contabil/app/routes/app_routes.dart';
import 'package:contabil/app/controller/controller_imports.dart';
import 'package:contabil/app/data/model/model_imports.dart';
import 'package:contabil/app/data/repository/contabil_indice_repository.dart';

class ContabilIndiceController extends ControllerBase<ContabilIndiceModel, ContabilIndiceRepository> 
with GetSingleTickerProviderStateMixin {

  ContabilIndiceController({required super.repository}) {
    dbColumns = ContabilIndiceModel.dbColumns;
    aliasColumns = ContabilIndiceModel.aliasColumns;
    gridColumns = contabilIndiceGridColumns();
    functionName = "contabil_indice";
    screenTitle = "Índices";
  }

  final contabilIndiceScaffoldKey = GlobalKey<ScaffoldState>();
  final contabilIndiceTabPageScaffoldKey = GlobalKey<ScaffoldState>();
  final contabilIndiceFormKey = GlobalKey<FormState>();
  late TabController tabController;
  String? mandatoryMessage;  

  @override
  ContabilIndiceModel createNewModel() => ContabilIndiceModel();

  @override
  final standardFieldForFilter = ContabilIndiceModel.aliasColumns[ContabilIndiceModel.dbColumns.indexOf('indice')];

  final indiceController = TextEditingController();
  final periodicidadeController = CustomDropdownButtonController('Diário');
  final diarioAPartirDeController = DatePickerItemController(null);
  final mensalMesAnoController = MaskedTextController(mask: '00/0000',);

  final Map<String, dynamic> mobileConfig = {
    'primaryColumns': ['indice'],
    'secondaryColumns': ['periodicidade'],
  };

  List<Map<String, dynamic>> get mobileItems {
    return modelList.map((contabilIndice) => contabilIndice.toJson).toList();
  }

  @override
  void prepareForInsert() {
    isNewRecord = true;
    currentModel = createNewModel();
    _resetForm();
    tabController.animateTo(0);
    updateControllersFromModel();
    Get.toNamed(Routes.contabilIndiceTabPage);
  }

  void _resetForm() {
    formWasChanged = false;
    indiceController.text = '';
    periodicidadeController.selected = 'Diário';
    diarioAPartirDeController.date = null;
    mensalMesAnoController.text = '';
  }

  @override
  void selectRowForEditingById(int id) {
    final model = modelList.firstWhere((m) => m.id == id);
    currentModel = model.clone();
    updateControllersFromModel();
    tabController.animateTo(0);
    Get.toNamed(Routes.contabilIndiceTabPage);
  }

  _configureChildrenControllers() {
    //Valores
		Get.put<ContabilIndiceValorController>(ContabilIndiceValorController()); 

  }
	
	_releaseChildrenControllers() {
    //Valores
		Get.delete<ContabilIndiceValorController>(); 

	}
  
  void updateControllersFromModel() {
    indiceController.text = currentModel.indice ?? '';
    periodicidadeController.selected = currentModel.periodicidade ?? 'Diário';
    diarioAPartirDeController.date = currentModel.diarioAPartirDe;
    mensalMesAnoController.text = currentModel.mensalMesAno ?? '';

    formWasChanged = false;
    _updateChildrenControllersFromModel();
  }

  void _updateChildrenControllersFromModel() {
    //Valores
		final contabilIndiceValorController = Get.find<ContabilIndiceValorController>(); 
		contabilIndiceValorController.userMadeChanges = false; 

  }

  @override
  Future<void> save() async {
    if (!validateCurrentForm()) return;
    if (validateForms()) {
      if (userMadeChanges()) {
        final existingIndex = modelList.indexWhere((m) => m.id == currentModel.id);

        if (existingIndex >= 0) {
          modelList[existingIndex] = currentModel.clone();
        }

        final result = await repository.save(contabilIndiceModel: currentModel);
        if (result == null) return;

        if (existingIndex >= 0) {
          modelList[existingIndex] = result;
        } else {
          modelList.insert(0, result);
        }

        if (!GetPlatform.isMobile) {
          updateGridRow(result);
        }

        Get.back(result: true);
      } else {
        Get.back();
      }
    } 
  }


  List<Tab> tabItems = [
    Tab( 
			icon: Icon(iconDataList[Random().nextInt(10)]), 
			text: 'Índices', 
		),
    Tab( 
			icon: Icon(iconDataList[Random().nextInt(10)]), 
			text: 'Valores', 
		),
  ];

  List<Widget> tabPages() {
    return [
      ContabilIndiceEditPage(),
      const ContabilIndiceValorListPage(),
    ];
  }

  @override
  void preventDataLoss() {
    if (userMadeChanges()) {
      showQuestionDialog('message_data_loss'.tr, () { 
        Get.back(); 
      });
    } else {
      Get.back();
    }
  }  

  bool userMadeChanges() {
    return
    formWasChanged 
    || 
		Get.find<ContabilIndiceValorController>().userMadeChanges
    ;
  }

  void tabChange(int index) {
    validateCurrentForm();
  }

  bool validateCurrentForm() {
    mandatoryMessage = ValidateFormField.validateMandatory(currentModel.periodicidade); 
		if (mandatoryMessage != null) { 
			tabController.animateTo(0); 
			showErrorSnackBar(message: '$mandatoryMessage [Periodicidade]'); 
			return false; 
		}
    return true;
  }

  bool validateForms() {
    return true;
  }

  @override
  void onInit() {
    super.onInit();
    tabController = TabController(vsync: this, length: tabItems.length);
    _configureChildrenControllers();
  }
	
  @override
  void onClose() {
    tabController.dispose();
    indiceController.dispose();
    periodicidadeController.dispose();
    diarioAPartirDeController.dispose();
    mensalMesAnoController.dispose();
    _releaseChildrenControllers();
    super.onClose();
  }	
}