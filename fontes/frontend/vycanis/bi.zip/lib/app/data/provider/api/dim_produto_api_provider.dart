import 'package:bi/app/data/provider/api/api_provider_base.dart';
import 'package:bi/app/data/model/model_imports.dart';

class DimProdutoApiProvider extends ApiProviderBase {
  static const _path = '/dim-produto';

  Future<List<DimProdutoModel>?> getList({Filter? filter}) {
    return super.getListBase(
      '$_path/',
      (json) => DimProdutoModel.fromJson(json),
      filter: filter,
    );
  }

  Future<DimProdutoModel?> getObject(dynamic pk) {
    return super.getObjectBase(
      _path,
      pk,
      (json) => DimProdutoModel.fromJson(json),
    );
  }

  Future<DimProdutoModel?>? insert(DimProdutoModel model) {
    return super.insertBase(
      _path,
      model,
      (json) => DimProdutoModel.fromJson(json),
    );
  }

  Future<DimProdutoModel?>? update(DimProdutoModel model) {
    return super.updateBase(
      _path,
      model,
      (json) => DimProdutoModel.fromJson(json),
    );
  }

  Future<bool?> delete(dynamic pk) {
    return super.deleteBase(_path, pk);
  }
}
