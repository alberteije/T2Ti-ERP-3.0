// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'fato_recebimento_dao.dart';

// ignore_for_file: type=lint
mixin _$FatoRecebimentoDaoMixin on DatabaseAccessor<AppDatabase> {
  $FatoRecebimentosTable get fatoRecebimentos =>
      attachedDatabase.fatoRecebimentos;
}
