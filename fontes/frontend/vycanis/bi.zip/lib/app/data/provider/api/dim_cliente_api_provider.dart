import 'package:bi/app/data/provider/api/api_provider_base.dart';
import 'package:bi/app/data/model/model_imports.dart';

class DimClienteApiProvider extends ApiProviderBase {
  static const _path = '/dim-cliente';

  Future<List<DimClienteModel>?> getList({Filter? filter}) {
    return super.getListBase(
      '$_path/',
      (json) => DimClienteModel.fromJson(json),
      filter: filter,
    );
  }

  Future<DimClienteModel?> getObject(dynamic pk) {
    return super.getObjectBase(
      _path,
      pk,
      (json) => DimClienteModel.fromJson(json),
    );
  }

  Future<DimClienteModel?>? insert(DimClienteModel model) {
    return super.insertBase(
      _path,
      model,
      (json) => DimClienteModel.fromJson(json),
    );
  }

  Future<DimClienteModel?>? update(DimClienteModel model) {
    return super.updateBase(
      _path,
      model,
      (json) => DimClienteModel.fromJson(json),
    );
  }

  Future<bool?> delete(dynamic pk) {
    return super.deleteBase(_path, pk);
  }
}
