import 'package:bi/app/data/provider/api/api_provider_base.dart';
import 'package:bi/app/data/model/model_imports.dart';

class DimTempoApiProvider extends ApiProviderBase {
  static const _path = '/dim-tempo';

  Future<List<DimTempoModel>?> getList({Filter? filter}) {
    return super.getListBase(
      '$_path/',
      (json) => DimTempoModel.fromJson(json),
      filter: filter,
    );
  }

  Future<DimTempoModel?> getObject(dynamic pk) {
    return super.getObjectBase(
      _path,
      pk,
      (json) => DimTempoModel.fromJson(json),
    );
  }

  Future<DimTempoModel?>? insert(DimTempoModel model) {
    return super.insertBase(
      _path,
      model,
      (json) => DimTempoModel.fromJson(json),
    );
  }

  Future<DimTempoModel?>? update(DimTempoModel model) {
    return super.updateBase(
      _path,
      model,
      (json) => DimTempoModel.fromJson(json),
    );
  }

  Future<bool?> delete(dynamic pk) {
    return super.deleteBase(_path, pk);
  }
}
