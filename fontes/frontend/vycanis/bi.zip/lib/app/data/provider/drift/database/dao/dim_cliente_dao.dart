import 'package:drift/drift.dart';
import 'package:bi/app/data/provider/drift/database/database.dart';
import 'package:bi/app/data/provider/drift/database/database_imports.dart';

part 'dim_cliente_dao.g.dart';

@DriftAccessor(tables: [
	DimClientes,
])
class DimClienteDao extends DatabaseAccessor<AppDatabase> with _$DimClienteDaoMixin {
	final AppDatabase db;

	List<DimCliente> dimClienteList = []; 
	List<DimClienteGrouped> dimClienteGroupedList = []; 

	DimClienteDao(this.db) : super(db);

	Future<List<DimCliente>> getList() async {
		dimClienteList = await select(dimClientes).get();
		return dimClienteList;
	}

	Future<List<DimCliente>> getListFilter(String field, String value) async {
		final query = " $field like '%$value%'";
		final expression = CustomExpression<bool>(query);
		dimClienteList = await (select(dimClientes)..where((t) => expression)).get();
		return dimClienteList;	 
	}

	Future<List<DimClienteGrouped>> getGroupedList({String? field, dynamic value}) async {
		final query = select(dimClientes)
			.join([]);

		if (field != null && field != '') { 
			final column = dimClientes.$columns.where(((column) => column.$name == field)).first;
			if (column is TextColumn) {
				query.where((column as TextColumn).like('%$value%'));
			} else if (column is IntColumn) {
				query.where(column.equals(int.tryParse(value) as Object));
			} else if (column is RealColumn) {
				query.where(column.equals(double.tryParse(value) as Object));
			}
		}

		dimClienteGroupedList = await query.map((row) {
			final dimCliente = row.readTableOrNull(dimClientes); 

			return DimClienteGrouped(
				dimCliente: dimCliente, 

			);
		}).get();

		// fill internal lists
		//dynamic expression;
		//for (var dimClienteGrouped in dimClienteGroupedList) {
		//}		

		return dimClienteGroupedList;	
	}

	Future<DimCliente?> getObject(dynamic pk) async {
		return await (select(dimClientes)..where((t) => t.id.equals(pk))).getSingleOrNull();
	} 

	Future<DimCliente?> getObjectFilter(String field, String value) async {
		final query = "SELECT * FROM dim_cliente WHERE $field like '%$value%'";
		return (await customSelect(query).getSingleOrNull()) as DimCliente;		 
	} 

	Future<DimClienteGrouped?> getObjectGrouped({String? field, dynamic value}) async {
		final result = await getGroupedList(field: field, value: value);

		if (result.length != 1) {
			return null;
		} else {
			return result[0];
		} 
	}

	Future<int> insertObject(DimClienteGrouped object) {
		return transaction(() async {
			final maxPk = await lastPk();
			object.dimCliente = object.dimCliente!.copyWith(id: Value(maxPk + 1));
			final pkInserted = await into(dimClientes).insert(object.dimCliente!);
			object.dimCliente = object.dimCliente!.copyWith(id: Value(pkInserted));			 
			await insertChildren(object);
			return pkInserted;
		});		
	}	 

	Future<bool> updateObject(DimClienteGrouped object) {
		return transaction(() async {
			await deleteChildren(object);
			await insertChildren(object);
			return update(dimClientes).replace(object.dimCliente!);
		});	 
	} 

	Future<int> deleteObject(DimClienteGrouped object) {
		return transaction(() async {
			await deleteChildren(object);
			return delete(dimClientes).delete(object.dimCliente!);
		});		
	}

	Future<void> insertChildren(DimClienteGrouped object) async {
	}
	
	Future<void> deleteChildren(DimClienteGrouped object) async {
	}

	Future<int> lastPk() async {
		final result = await customSelect("select MAX(id) as LAST from dim_cliente").getSingleOrNull();
		return result?.data["LAST"] ?? 0;
	} 
}