import 'package:drift/drift.dart';
import 'package:bi/app/data/provider/drift/database/database.dart';
import 'package:bi/app/data/provider/drift/database/database_imports.dart';

part 'dim_produto_dao.g.dart';

@DriftAccessor(tables: [
	DimProdutos,
])
class DimProdutoDao extends DatabaseAccessor<AppDatabase> with _$DimProdutoDaoMixin {
	final AppDatabase db;

	List<DimProduto> dimProdutoList = []; 
	List<DimProdutoGrouped> dimProdutoGroupedList = []; 

	DimProdutoDao(this.db) : super(db);

	Future<List<DimProduto>> getList() async {
		dimProdutoList = await select(dimProdutos).get();
		return dimProdutoList;
	}

	Future<List<DimProduto>> getListFilter(String field, String value) async {
		final query = " $field like '%$value%'";
		final expression = CustomExpression<bool>(query);
		dimProdutoList = await (select(dimProdutos)..where((t) => expression)).get();
		return dimProdutoList;	 
	}

	Future<List<DimProdutoGrouped>> getGroupedList({String? field, dynamic value}) async {
		final query = select(dimProdutos)
			.join([]);

		if (field != null && field != '') { 
			final column = dimProdutos.$columns.where(((column) => column.$name == field)).first;
			if (column is TextColumn) {
				query.where((column as TextColumn).like('%$value%'));
			} else if (column is IntColumn) {
				query.where(column.equals(int.tryParse(value) as Object));
			} else if (column is RealColumn) {
				query.where(column.equals(double.tryParse(value) as Object));
			}
		}

		dimProdutoGroupedList = await query.map((row) {
			final dimProduto = row.readTableOrNull(dimProdutos); 

			return DimProdutoGrouped(
				dimProduto: dimProduto, 

			);
		}).get();

		// fill internal lists
		//dynamic expression;
		//for (var dimProdutoGrouped in dimProdutoGroupedList) {
		//}		

		return dimProdutoGroupedList;	
	}

	Future<DimProduto?> getObject(dynamic pk) async {
		return await (select(dimProdutos)..where((t) => t.id.equals(pk))).getSingleOrNull();
	} 

	Future<DimProduto?> getObjectFilter(String field, String value) async {
		final query = "SELECT * FROM dim_produto WHERE $field like '%$value%'";
		return (await customSelect(query).getSingleOrNull()) as DimProduto;		 
	} 

	Future<DimProdutoGrouped?> getObjectGrouped({String? field, dynamic value}) async {
		final result = await getGroupedList(field: field, value: value);

		if (result.length != 1) {
			return null;
		} else {
			return result[0];
		} 
	}

	Future<int> insertObject(DimProdutoGrouped object) {
		return transaction(() async {
			final maxPk = await lastPk();
			object.dimProduto = object.dimProduto!.copyWith(id: Value(maxPk + 1));
			final pkInserted = await into(dimProdutos).insert(object.dimProduto!);
			object.dimProduto = object.dimProduto!.copyWith(id: Value(pkInserted));			 
			await insertChildren(object);
			return pkInserted;
		});		
	}	 

	Future<bool> updateObject(DimProdutoGrouped object) {
		return transaction(() async {
			await deleteChildren(object);
			await insertChildren(object);
			return update(dimProdutos).replace(object.dimProduto!);
		});	 
	} 

	Future<int> deleteObject(DimProdutoGrouped object) {
		return transaction(() async {
			await deleteChildren(object);
			return delete(dimProdutos).delete(object.dimProduto!);
		});		
	}

	Future<void> insertChildren(DimProdutoGrouped object) async {
	}
	
	Future<void> deleteChildren(DimProdutoGrouped object) async {
	}

	Future<int> lastPk() async {
		final result = await customSelect("select MAX(id) as LAST from dim_produto").getSingleOrNull();
		return result?.data["LAST"] ?? 0;
	} 
}