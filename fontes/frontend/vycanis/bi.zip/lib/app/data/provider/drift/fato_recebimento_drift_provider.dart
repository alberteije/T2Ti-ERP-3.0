import 'package:bi/app/data/provider/drift/database/database_imports.dart';
import 'package:bi/app/infra/infra_imports.dart';
import 'package:bi/app/data/provider/provider_base.dart';
import 'package:bi/app/data/provider/drift/database/database.dart';
import 'package:bi/app/data/model/model_imports.dart';

class FatoRecebimentoDriftProvider extends ProviderBase {

	Future<List<FatoRecebimentoModel>?> getList({Filter? filter}) async {
		List<FatoRecebimentoGrouped> fatoRecebimentoDriftList = [];

		try {
			if (filter != null && filter.field != null) {
				fatoRecebimentoDriftList = await Session.database.fatoRecebimentoDao.getGroupedList(field: filter.field, value: filter.value!);
			} else {
				fatoRecebimentoDriftList = await Session.database.fatoRecebimentoDao.getGroupedList(); 
			}
			if (fatoRecebimentoDriftList.isNotEmpty) {
				return toListModel(fatoRecebimentoDriftList);
			} else {
				return [];
			}			 
		} catch (e) {
			handleResultError(null, null, exception: e);
			return null;
		}
	}

	Future<FatoRecebimentoModel?> getObject(dynamic pk) async {
		try {
			final result = await Session.database.fatoRecebimentoDao.getObjectGrouped(field: 'id', value: pk);
			return toModel(result);
		} catch (e) {
			handleResultError(null, null, exception: e);
		}
		return null;
	}

	Future<FatoRecebimentoModel?>? insert(FatoRecebimentoModel fatoRecebimentoModel) async {
		try {
			final lastPk = await Session.database.fatoRecebimentoDao.insertObject(toDrift(fatoRecebimentoModel));
			fatoRecebimentoModel.id = lastPk;
			return fatoRecebimentoModel;
		} catch (e) {
			handleResultError(null, null, exception: e);
		}
		return null;
	}

	Future<FatoRecebimentoModel?>? update(FatoRecebimentoModel fatoRecebimentoModel) async {
		try {
			await Session.database.fatoRecebimentoDao.updateObject(toDrift(fatoRecebimentoModel));
			return fatoRecebimentoModel;
		} catch (e) {
			handleResultError(null, null, exception: e);
		}
		return null;
	}

	Future<bool?> delete(dynamic pk) async {
		try {
			await Session.database.fatoRecebimentoDao.deleteObject(toDrift(FatoRecebimentoModel(id: pk)));
			return true;
		} catch (e) {
			handleResultError(null, null, exception: e);
		}
		return null;
	}	

	List<FatoRecebimentoModel> toListModel(List<FatoRecebimentoGrouped> fatoRecebimentoDriftList) {
		List<FatoRecebimentoModel> listModel = [];
		for (var fatoRecebimentoDrift in fatoRecebimentoDriftList) {
			listModel.add(toModel(fatoRecebimentoDrift)!);
		}
		return listModel;
	}	

	FatoRecebimentoModel? toModel(FatoRecebimentoGrouped? fatoRecebimentoDrift) {
		if (fatoRecebimentoDrift != null) {
			return FatoRecebimentoModel(
				id: fatoRecebimentoDrift.fatoRecebimento?.id,
				idTempo: fatoRecebimentoDrift.fatoRecebimento?.idTempo,
				idCliente: fatoRecebimentoDrift.fatoRecebimento?.idCliente,
				valorRecebido: fatoRecebimentoDrift.fatoRecebimento?.valorRecebido,
				valorEmAberto: fatoRecebimentoDrift.fatoRecebimento?.valorEmAberto,
				atrasoDias: fatoRecebimentoDrift.fatoRecebimento?.atrasoDias,
			);
		} else {
			return null;
		}
	}


	FatoRecebimentoGrouped toDrift(FatoRecebimentoModel fatoRecebimentoModel) {
		return FatoRecebimentoGrouped(
			fatoRecebimento: FatoRecebimento(
				id: fatoRecebimentoModel.id,
				idTempo: fatoRecebimentoModel.idTempo,
				idCliente: fatoRecebimentoModel.idCliente,
				valorRecebido: fatoRecebimentoModel.valorRecebido,
				valorEmAberto: fatoRecebimentoModel.valorEmAberto,
				atrasoDias: fatoRecebimentoModel.atrasoDias,
			),
		);
	}

		
}
