import 'package:drift/drift.dart';
import 'package:bi/app/data/provider/drift/database/database.dart';

@DataClassName("FatoVenda")
class FatoVendas extends Table {
	@override
	String get tableName => 'fato_venda';

	IntColumn get id => integer().named('id').nullable()();
	IntColumn get idTempo => integer().named('id_tempo').nullable()();
	IntColumn get idCliente => integer().named('id_cliente').nullable()();
	IntColumn get idVendedor => integer().named('id_vendedor').nullable()();
	IntColumn get idProduto => integer().named('id_produto').nullable()();
	RealColumn get quantidade => real().named('quantidade').nullable()();
	RealColumn get valorTotal => real().named('valor_total').nullable()();
	RealColumn get custoTotal => real().named('custo_total').nullable()();
	RealColumn get lucro => real().named('lucro').nullable()();

	@override
	Set<Column> get primaryKey => { id };	
	
}

class FatoVendaGrouped {
	FatoVenda? fatoVenda; 

  FatoVendaGrouped({
		this.fatoVenda, 

  });
}
