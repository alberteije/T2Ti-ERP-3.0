import 'package:drift/drift.dart';
import 'package:bi/app/data/provider/drift/database/database.dart';
import 'package:bi/app/data/provider/drift/database/database_imports.dart';

part 'fato_venda_dao.g.dart';

@DriftAccessor(tables: [
	FatoVendas,
])
class FatoVendaDao extends DatabaseAccessor<AppDatabase> with _$FatoVendaDaoMixin {
	final AppDatabase db;

	List<FatoVenda> fatoVendaList = []; 
	List<FatoVendaGrouped> fatoVendaGroupedList = []; 

	FatoVendaDao(this.db) : super(db);

	Future<List<FatoVenda>> getList() async {
		fatoVendaList = await select(fatoVendas).get();
		return fatoVendaList;
	}

	Future<List<FatoVenda>> getListFilter(String field, String value) async {
		final query = " $field like '%$value%'";
		final expression = CustomExpression<bool>(query);
		fatoVendaList = await (select(fatoVendas)..where((t) => expression)).get();
		return fatoVendaList;	 
	}

	Future<List<FatoVendaGrouped>> getGroupedList({String? field, dynamic value}) async {
		final query = select(fatoVendas)
			.join([]);

		if (field != null && field != '') { 
			final column = fatoVendas.$columns.where(((column) => column.$name == field)).first;
			if (column is TextColumn) {
				query.where((column as TextColumn).like('%$value%'));
			} else if (column is IntColumn) {
				query.where(column.equals(int.tryParse(value) as Object));
			} else if (column is RealColumn) {
				query.where(column.equals(double.tryParse(value) as Object));
			}
		}

		fatoVendaGroupedList = await query.map((row) {
			final fatoVenda = row.readTableOrNull(fatoVendas); 

			return FatoVendaGrouped(
				fatoVenda: fatoVenda, 

			);
		}).get();

		// fill internal lists
		//dynamic expression;
		//for (var fatoVendaGrouped in fatoVendaGroupedList) {
		//}		

		return fatoVendaGroupedList;	
	}

	Future<FatoVenda?> getObject(dynamic pk) async {
		return await (select(fatoVendas)..where((t) => t.id.equals(pk))).getSingleOrNull();
	} 

	Future<FatoVenda?> getObjectFilter(String field, String value) async {
		final query = "SELECT * FROM fato_venda WHERE $field like '%$value%'";
		return (await customSelect(query).getSingleOrNull()) as FatoVenda;		 
	} 

	Future<FatoVendaGrouped?> getObjectGrouped({String? field, dynamic value}) async {
		final result = await getGroupedList(field: field, value: value);

		if (result.length != 1) {
			return null;
		} else {
			return result[0];
		} 
	}

	Future<int> insertObject(FatoVendaGrouped object) {
		return transaction(() async {
			final maxPk = await lastPk();
			object.fatoVenda = object.fatoVenda!.copyWith(id: Value(maxPk + 1));
			final pkInserted = await into(fatoVendas).insert(object.fatoVenda!);
			object.fatoVenda = object.fatoVenda!.copyWith(id: Value(pkInserted));			 
			await insertChildren(object);
			return pkInserted;
		});		
	}	 

	Future<bool> updateObject(FatoVendaGrouped object) {
		return transaction(() async {
			await deleteChildren(object);
			await insertChildren(object);
			return update(fatoVendas).replace(object.fatoVenda!);
		});	 
	} 

	Future<int> deleteObject(FatoVendaGrouped object) {
		return transaction(() async {
			await deleteChildren(object);
			return delete(fatoVendas).delete(object.fatoVenda!);
		});		
	}

	Future<void> insertChildren(FatoVendaGrouped object) async {
	}
	
	Future<void> deleteChildren(FatoVendaGrouped object) async {
	}

	Future<int> lastPk() async {
		final result = await customSelect("select MAX(id) as LAST from fato_venda").getSingleOrNull();
		return result?.data["LAST"] ?? 0;
	} 
}