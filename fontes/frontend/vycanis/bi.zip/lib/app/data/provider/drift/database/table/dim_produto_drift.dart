import 'package:drift/drift.dart';
import 'package:bi/app/data/provider/drift/database/database.dart';

@DataClassName("DimProduto")
class DimProdutos extends Table {
	@override
	String get tableName => 'dim_produto';

	IntColumn get id => integer().named('id').nullable()();
	TextColumn get descricao => text().named('descricao').nullable()();
	TextColumn get categoria => text().named('categoria').nullable()();
	TextColumn get marca => text().named('marca').nullable()();

	@override
	Set<Column> get primaryKey => { id };	
	
}

class DimProdutoGrouped {
	DimProduto? dimProduto; 

  DimProdutoGrouped({
		this.dimProduto, 

  });
}
