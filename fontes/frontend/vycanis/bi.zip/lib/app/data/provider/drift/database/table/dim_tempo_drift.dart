import 'package:drift/drift.dart';
import 'package:bi/app/data/provider/drift/database/database.dart';

@DataClassName("DimTempo")
class DimTempos extends Table {
	@override
	String get tableName => 'dim_tempo';

	IntColumn get id => integer().named('id').nullable()();
	DateTimeColumn get data => dateTime().named('data').nullable()();
	IntColumn get ano => integer().named('ano').nullable()();
	IntColumn get mes => integer().named('mes').nullable()();
	TextColumn get nomeMes => text().named('nome_mes').nullable()();
	IntColumn get trimestre => integer().named('trimestre').nullable()();
	IntColumn get dia => integer().named('dia').nullable()();
	IntColumn get diaSemana => integer().named('dia_semana').nullable()();

	@override
	Set<Column> get primaryKey => { id };	
	
}

class DimTempoGrouped {
	DimTempo? dimTempo; 

  DimTempoGrouped({
		this.dimTempo, 

  });
}
