import 'package:drift/drift.dart';
import 'package:bi/app/data/provider/drift/database/database.dart';
import 'package:bi/app/data/provider/drift/database/database_imports.dart';

part 'dim_vendedor_dao.g.dart';

@DriftAccessor(tables: [
	DimVendedors,
])
class DimVendedorDao extends DatabaseAccessor<AppDatabase> with _$DimVendedorDaoMixin {
	final AppDatabase db;

	List<DimVendedor> dimVendedorList = []; 
	List<DimVendedorGrouped> dimVendedorGroupedList = []; 

	DimVendedorDao(this.db) : super(db);

	Future<List<DimVendedor>> getList() async {
		dimVendedorList = await select(dimVendedors).get();
		return dimVendedorList;
	}

	Future<List<DimVendedor>> getListFilter(String field, String value) async {
		final query = " $field like '%$value%'";
		final expression = CustomExpression<bool>(query);
		dimVendedorList = await (select(dimVendedors)..where((t) => expression)).get();
		return dimVendedorList;	 
	}

	Future<List<DimVendedorGrouped>> getGroupedList({String? field, dynamic value}) async {
		final query = select(dimVendedors)
			.join([]);

		if (field != null && field != '') { 
			final column = dimVendedors.$columns.where(((column) => column.$name == field)).first;
			if (column is TextColumn) {
				query.where((column as TextColumn).like('%$value%'));
			} else if (column is IntColumn) {
				query.where(column.equals(int.tryParse(value) as Object));
			} else if (column is RealColumn) {
				query.where(column.equals(double.tryParse(value) as Object));
			}
		}

		dimVendedorGroupedList = await query.map((row) {
			final dimVendedor = row.readTableOrNull(dimVendedors); 

			return DimVendedorGrouped(
				dimVendedor: dimVendedor, 

			);
		}).get();

		// fill internal lists
		//dynamic expression;
		//for (var dimVendedorGrouped in dimVendedorGroupedList) {
		//}		

		return dimVendedorGroupedList;	
	}

	Future<DimVendedor?> getObject(dynamic pk) async {
		return await (select(dimVendedors)..where((t) => t.id.equals(pk))).getSingleOrNull();
	} 

	Future<DimVendedor?> getObjectFilter(String field, String value) async {
		final query = "SELECT * FROM dim_vendedor WHERE $field like '%$value%'";
		return (await customSelect(query).getSingleOrNull()) as DimVendedor;		 
	} 

	Future<DimVendedorGrouped?> getObjectGrouped({String? field, dynamic value}) async {
		final result = await getGroupedList(field: field, value: value);

		if (result.length != 1) {
			return null;
		} else {
			return result[0];
		} 
	}

	Future<int> insertObject(DimVendedorGrouped object) {
		return transaction(() async {
			final maxPk = await lastPk();
			object.dimVendedor = object.dimVendedor!.copyWith(id: Value(maxPk + 1));
			final pkInserted = await into(dimVendedors).insert(object.dimVendedor!);
			object.dimVendedor = object.dimVendedor!.copyWith(id: Value(pkInserted));			 
			await insertChildren(object);
			return pkInserted;
		});		
	}	 

	Future<bool> updateObject(DimVendedorGrouped object) {
		return transaction(() async {
			await deleteChildren(object);
			await insertChildren(object);
			return update(dimVendedors).replace(object.dimVendedor!);
		});	 
	} 

	Future<int> deleteObject(DimVendedorGrouped object) {
		return transaction(() async {
			await deleteChildren(object);
			return delete(dimVendedors).delete(object.dimVendedor!);
		});		
	}

	Future<void> insertChildren(DimVendedorGrouped object) async {
	}
	
	Future<void> deleteChildren(DimVendedorGrouped object) async {
	}

	Future<int> lastPk() async {
		final result = await customSelect("select MAX(id) as LAST from dim_vendedor").getSingleOrNull();
		return result?.data["LAST"] ?? 0;
	} 
}