import 'package:drift/drift.dart';
import 'package:bi/app/data/provider/drift/database/database.dart';
import 'package:bi/app/data/provider/drift/database/database_imports.dart';

part 'dim_tempo_dao.g.dart';

@DriftAccessor(tables: [
	DimTempos,
])
class DimTempoDao extends DatabaseAccessor<AppDatabase> with _$DimTempoDaoMixin {
	final AppDatabase db;

	List<DimTempo> dimTempoList = []; 
	List<DimTempoGrouped> dimTempoGroupedList = []; 

	DimTempoDao(this.db) : super(db);

	Future<List<DimTempo>> getList() async {
		dimTempoList = await select(dimTempos).get();
		return dimTempoList;
	}

	Future<List<DimTempo>> getListFilter(String field, String value) async {
		final query = " $field like '%$value%'";
		final expression = CustomExpression<bool>(query);
		dimTempoList = await (select(dimTempos)..where((t) => expression)).get();
		return dimTempoList;	 
	}

	Future<List<DimTempoGrouped>> getGroupedList({String? field, dynamic value}) async {
		final query = select(dimTempos)
			.join([]);

		if (field != null && field != '') { 
			final column = dimTempos.$columns.where(((column) => column.$name == field)).first;
			if (column is TextColumn) {
				query.where((column as TextColumn).like('%$value%'));
			} else if (column is IntColumn) {
				query.where(column.equals(int.tryParse(value) as Object));
			} else if (column is RealColumn) {
				query.where(column.equals(double.tryParse(value) as Object));
			}
		}

		dimTempoGroupedList = await query.map((row) {
			final dimTempo = row.readTableOrNull(dimTempos); 

			return DimTempoGrouped(
				dimTempo: dimTempo, 

			);
		}).get();

		// fill internal lists
		//dynamic expression;
		//for (var dimTempoGrouped in dimTempoGroupedList) {
		//}		

		return dimTempoGroupedList;	
	}

	Future<DimTempo?> getObject(dynamic pk) async {
		return await (select(dimTempos)..where((t) => t.id.equals(pk))).getSingleOrNull();
	} 

	Future<DimTempo?> getObjectFilter(String field, String value) async {
		final query = "SELECT * FROM dim_tempo WHERE $field like '%$value%'";
		return (await customSelect(query).getSingleOrNull()) as DimTempo;		 
	} 

	Future<DimTempoGrouped?> getObjectGrouped({String? field, dynamic value}) async {
		final result = await getGroupedList(field: field, value: value);

		if (result.length != 1) {
			return null;
		} else {
			return result[0];
		} 
	}

	Future<int> insertObject(DimTempoGrouped object) {
		return transaction(() async {
			final maxPk = await lastPk();
			object.dimTempo = object.dimTempo!.copyWith(id: Value(maxPk + 1));
			final pkInserted = await into(dimTempos).insert(object.dimTempo!);
			object.dimTempo = object.dimTempo!.copyWith(id: Value(pkInserted));			 
			await insertChildren(object);
			return pkInserted;
		});		
	}	 

	Future<bool> updateObject(DimTempoGrouped object) {
		return transaction(() async {
			await deleteChildren(object);
			await insertChildren(object);
			return update(dimTempos).replace(object.dimTempo!);
		});	 
	} 

	Future<int> deleteObject(DimTempoGrouped object) {
		return transaction(() async {
			await deleteChildren(object);
			return delete(dimTempos).delete(object.dimTempo!);
		});		
	}

	Future<void> insertChildren(DimTempoGrouped object) async {
	}
	
	Future<void> deleteChildren(DimTempoGrouped object) async {
	}

	Future<int> lastPk() async {
		final result = await customSelect("select MAX(id) as LAST from dim_tempo").getSingleOrNull();
		return result?.data["LAST"] ?? 0;
	} 
}