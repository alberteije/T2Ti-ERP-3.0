import 'package:bi/app/data/provider/drift/database/database_imports.dart';
import 'package:bi/app/infra/infra_imports.dart';
import 'package:bi/app/data/provider/provider_base.dart';
import 'package:bi/app/data/provider/drift/database/database.dart';
import 'package:bi/app/data/model/model_imports.dart';

class DimTempoDriftProvider extends ProviderBase {

	Future<List<DimTempoModel>?> getList({Filter? filter}) async {
		List<DimTempoGrouped> dimTempoDriftList = [];

		try {
			if (filter != null && filter.field != null) {
				dimTempoDriftList = await Session.database.dimTempoDao.getGroupedList(field: filter.field, value: filter.value!);
			} else {
				dimTempoDriftList = await Session.database.dimTempoDao.getGroupedList(); 
			}
			if (dimTempoDriftList.isNotEmpty) {
				return toListModel(dimTempoDriftList);
			} else {
				return [];
			}			 
		} catch (e) {
			handleResultError(null, null, exception: e);
			return null;
		}
	}

	Future<DimTempoModel?> getObject(dynamic pk) async {
		try {
			final result = await Session.database.dimTempoDao.getObjectGrouped(field: 'id', value: pk);
			return toModel(result);
		} catch (e) {
			handleResultError(null, null, exception: e);
		}
		return null;
	}

	Future<DimTempoModel?>? insert(DimTempoModel dimTempoModel) async {
		try {
			final lastPk = await Session.database.dimTempoDao.insertObject(toDrift(dimTempoModel));
			dimTempoModel.id = lastPk;
			return dimTempoModel;
		} catch (e) {
			handleResultError(null, null, exception: e);
		}
		return null;
	}

	Future<DimTempoModel?>? update(DimTempoModel dimTempoModel) async {
		try {
			await Session.database.dimTempoDao.updateObject(toDrift(dimTempoModel));
			return dimTempoModel;
		} catch (e) {
			handleResultError(null, null, exception: e);
		}
		return null;
	}

	Future<bool?> delete(dynamic pk) async {
		try {
			await Session.database.dimTempoDao.deleteObject(toDrift(DimTempoModel(id: pk)));
			return true;
		} catch (e) {
			handleResultError(null, null, exception: e);
		}
		return null;
	}	

	List<DimTempoModel> toListModel(List<DimTempoGrouped> dimTempoDriftList) {
		List<DimTempoModel> listModel = [];
		for (var dimTempoDrift in dimTempoDriftList) {
			listModel.add(toModel(dimTempoDrift)!);
		}
		return listModel;
	}	

	DimTempoModel? toModel(DimTempoGrouped? dimTempoDrift) {
		if (dimTempoDrift != null) {
			return DimTempoModel(
				id: dimTempoDrift.dimTempo?.id,
				data: dimTempoDrift.dimTempo?.data,
				ano: dimTempoDrift.dimTempo?.ano,
				mes: dimTempoDrift.dimTempo?.mes,
				nomeMes: dimTempoDrift.dimTempo?.nomeMes,
				trimestre: dimTempoDrift.dimTempo?.trimestre,
				dia: dimTempoDrift.dimTempo?.dia,
				diaSemana: dimTempoDrift.dimTempo?.diaSemana,
			);
		} else {
			return null;
		}
	}


	DimTempoGrouped toDrift(DimTempoModel dimTempoModel) {
		return DimTempoGrouped(
			dimTempo: DimTempo(
				id: dimTempoModel.id,
				data: dimTempoModel.data,
				ano: dimTempoModel.ano,
				mes: dimTempoModel.mes,
				nomeMes: dimTempoModel.nomeMes,
				trimestre: dimTempoModel.trimestre,
				dia: dimTempoModel.dia,
				diaSemana: dimTempoModel.diaSemana,
			),
		);
	}

		
}
