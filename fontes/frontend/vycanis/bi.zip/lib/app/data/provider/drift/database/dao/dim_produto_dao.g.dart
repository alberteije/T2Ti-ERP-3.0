// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'dim_produto_dao.dart';

// ignore_for_file: type=lint
mixin _$DimProdutoDaoMixin on DatabaseAccessor<AppDatabase> {
  $DimProdutosTable get dimProdutos => attachedDatabase.dimProdutos;
}
