import 'package:drift/drift.dart';
import 'package:bi/app/data/provider/drift/database/database.dart';

@DataClassName("DimVendedor")
class DimVendedors extends Table {
	@override
	String get tableName => 'dim_vendedor';

	IntColumn get id => integer().named('id').nullable()();
	TextColumn get nomeVendedor => text().named('nome_vendedor').nullable()();
	TextColumn get equipe => text().named('equipe').nullable()();
	TextColumn get regiao => text().named('regiao').nullable()();

	@override
	Set<Column> get primaryKey => { id };	
	
}

class DimVendedorGrouped {
	DimVendedor? dimVendedor; 

  DimVendedorGrouped({
		this.dimVendedor, 

  });
}
