import 'package:bi/app/data/provider/api/api_provider_base.dart';
import 'package:bi/app/data/model/model_imports.dart';

class DimVendedorApiProvider extends ApiProviderBase {
  static const _path = '/dim-vendedor';

  Future<List<DimVendedorModel>?> getList({Filter? filter}) {
    return super.getListBase(
      '$_path/',
      (json) => DimVendedorModel.fromJson(json),
      filter: filter,
    );
  }

  Future<DimVendedorModel?> getObject(dynamic pk) {
    return super.getObjectBase(
      _path,
      pk,
      (json) => DimVendedorModel.fromJson(json),
    );
  }

  Future<DimVendedorModel?>? insert(DimVendedorModel model) {
    return super.insertBase(
      _path,
      model,
      (json) => DimVendedorModel.fromJson(json),
    );
  }

  Future<DimVendedorModel?>? update(DimVendedorModel model) {
    return super.updateBase(
      _path,
      model,
      (json) => DimVendedorModel.fromJson(json),
    );
  }

  Future<bool?> delete(dynamic pk) {
    return super.deleteBase(_path, pk);
  }
}
