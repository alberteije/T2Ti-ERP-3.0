// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'dim_vendedor_dao.dart';

// ignore_for_file: type=lint
mixin _$DimVendedorDaoMixin on DatabaseAccessor<AppDatabase> {
  $DimVendedorsTable get dimVendedors => attachedDatabase.dimVendedors;
}
