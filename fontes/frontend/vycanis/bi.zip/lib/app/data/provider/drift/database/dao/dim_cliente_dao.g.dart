// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'dim_cliente_dao.dart';

// ignore_for_file: type=lint
mixin _$DimClienteDaoMixin on DatabaseAccessor<AppDatabase> {
  $DimClientesTable get dimClientes => attachedDatabase.dimClientes;
}
