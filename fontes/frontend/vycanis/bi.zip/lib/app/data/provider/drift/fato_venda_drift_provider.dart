import 'package:bi/app/data/provider/drift/database/database_imports.dart';
import 'package:bi/app/infra/infra_imports.dart';
import 'package:bi/app/data/provider/provider_base.dart';
import 'package:bi/app/data/provider/drift/database/database.dart';
import 'package:bi/app/data/model/model_imports.dart';

class FatoVendaDriftProvider extends ProviderBase {

	Future<List<FatoVendaModel>?> getList({Filter? filter}) async {
		List<FatoVendaGrouped> fatoVendaDriftList = [];

		try {
			if (filter != null && filter.field != null) {
				fatoVendaDriftList = await Session.database.fatoVendaDao.getGroupedList(field: filter.field, value: filter.value!);
			} else {
				fatoVendaDriftList = await Session.database.fatoVendaDao.getGroupedList(); 
			}
			if (fatoVendaDriftList.isNotEmpty) {
				return toListModel(fatoVendaDriftList);
			} else {
				return [];
			}			 
		} catch (e) {
			handleResultError(null, null, exception: e);
			return null;
		}
	}

	Future<FatoVendaModel?> getObject(dynamic pk) async {
		try {
			final result = await Session.database.fatoVendaDao.getObjectGrouped(field: 'id', value: pk);
			return toModel(result);
		} catch (e) {
			handleResultError(null, null, exception: e);
		}
		return null;
	}

	Future<FatoVendaModel?>? insert(FatoVendaModel fatoVendaModel) async {
		try {
			final lastPk = await Session.database.fatoVendaDao.insertObject(toDrift(fatoVendaModel));
			fatoVendaModel.id = lastPk;
			return fatoVendaModel;
		} catch (e) {
			handleResultError(null, null, exception: e);
		}
		return null;
	}

	Future<FatoVendaModel?>? update(FatoVendaModel fatoVendaModel) async {
		try {
			await Session.database.fatoVendaDao.updateObject(toDrift(fatoVendaModel));
			return fatoVendaModel;
		} catch (e) {
			handleResultError(null, null, exception: e);
		}
		return null;
	}

	Future<bool?> delete(dynamic pk) async {
		try {
			await Session.database.fatoVendaDao.deleteObject(toDrift(FatoVendaModel(id: pk)));
			return true;
		} catch (e) {
			handleResultError(null, null, exception: e);
		}
		return null;
	}	

	List<FatoVendaModel> toListModel(List<FatoVendaGrouped> fatoVendaDriftList) {
		List<FatoVendaModel> listModel = [];
		for (var fatoVendaDrift in fatoVendaDriftList) {
			listModel.add(toModel(fatoVendaDrift)!);
		}
		return listModel;
	}	

	FatoVendaModel? toModel(FatoVendaGrouped? fatoVendaDrift) {
		if (fatoVendaDrift != null) {
			return FatoVendaModel(
				id: fatoVendaDrift.fatoVenda?.id,
				idTempo: fatoVendaDrift.fatoVenda?.idTempo,
				idCliente: fatoVendaDrift.fatoVenda?.idCliente,
				idVendedor: fatoVendaDrift.fatoVenda?.idVendedor,
				idProduto: fatoVendaDrift.fatoVenda?.idProduto,
				quantidade: fatoVendaDrift.fatoVenda?.quantidade,
				valorTotal: fatoVendaDrift.fatoVenda?.valorTotal,
				custoTotal: fatoVendaDrift.fatoVenda?.custoTotal,
				lucro: fatoVendaDrift.fatoVenda?.lucro,
			);
		} else {
			return null;
		}
	}


	FatoVendaGrouped toDrift(FatoVendaModel fatoVendaModel) {
		return FatoVendaGrouped(
			fatoVenda: FatoVenda(
				id: fatoVendaModel.id,
				idTempo: fatoVendaModel.idTempo,
				idCliente: fatoVendaModel.idCliente,
				idVendedor: fatoVendaModel.idVendedor,
				idProduto: fatoVendaModel.idProduto,
				quantidade: fatoVendaModel.quantidade,
				valorTotal: fatoVendaModel.valorTotal,
				custoTotal: fatoVendaModel.custoTotal,
				lucro: fatoVendaModel.lucro,
			),
		);
	}

		
}
