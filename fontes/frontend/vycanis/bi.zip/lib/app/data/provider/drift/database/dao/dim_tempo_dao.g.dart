// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'dim_tempo_dao.dart';

// ignore_for_file: type=lint
mixin _$DimTempoDaoMixin on DatabaseAccessor<AppDatabase> {
  $DimTemposTable get dimTempos => attachedDatabase.dimTempos;
}
