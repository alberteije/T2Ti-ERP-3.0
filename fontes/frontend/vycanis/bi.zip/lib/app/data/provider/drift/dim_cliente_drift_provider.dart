import 'package:bi/app/data/provider/drift/database/database_imports.dart';
import 'package:bi/app/infra/infra_imports.dart';
import 'package:bi/app/data/provider/provider_base.dart';
import 'package:bi/app/data/provider/drift/database/database.dart';
import 'package:bi/app/data/model/model_imports.dart';

class DimClienteDriftProvider extends ProviderBase {

	Future<List<DimClienteModel>?> getList({Filter? filter}) async {
		List<DimClienteGrouped> dimClienteDriftList = [];

		try {
			if (filter != null && filter.field != null) {
				dimClienteDriftList = await Session.database.dimClienteDao.getGroupedList(field: filter.field, value: filter.value!);
			} else {
				dimClienteDriftList = await Session.database.dimClienteDao.getGroupedList(); 
			}
			if (dimClienteDriftList.isNotEmpty) {
				return toListModel(dimClienteDriftList);
			} else {
				return [];
			}			 
		} catch (e) {
			handleResultError(null, null, exception: e);
			return null;
		}
	}

	Future<DimClienteModel?> getObject(dynamic pk) async {
		try {
			final result = await Session.database.dimClienteDao.getObjectGrouped(field: 'id', value: pk);
			return toModel(result);
		} catch (e) {
			handleResultError(null, null, exception: e);
		}
		return null;
	}

	Future<DimClienteModel?>? insert(DimClienteModel dimClienteModel) async {
		try {
			final lastPk = await Session.database.dimClienteDao.insertObject(toDrift(dimClienteModel));
			dimClienteModel.id = lastPk;
			return dimClienteModel;
		} catch (e) {
			handleResultError(null, null, exception: e);
		}
		return null;
	}

	Future<DimClienteModel?>? update(DimClienteModel dimClienteModel) async {
		try {
			await Session.database.dimClienteDao.updateObject(toDrift(dimClienteModel));
			return dimClienteModel;
		} catch (e) {
			handleResultError(null, null, exception: e);
		}
		return null;
	}

	Future<bool?> delete(dynamic pk) async {
		try {
			await Session.database.dimClienteDao.deleteObject(toDrift(DimClienteModel(id: pk)));
			return true;
		} catch (e) {
			handleResultError(null, null, exception: e);
		}
		return null;
	}	

	List<DimClienteModel> toListModel(List<DimClienteGrouped> dimClienteDriftList) {
		List<DimClienteModel> listModel = [];
		for (var dimClienteDrift in dimClienteDriftList) {
			listModel.add(toModel(dimClienteDrift)!);
		}
		return listModel;
	}	

	DimClienteModel? toModel(DimClienteGrouped? dimClienteDrift) {
		if (dimClienteDrift != null) {
			return DimClienteModel(
				id: dimClienteDrift.dimCliente?.id,
				nomeCliente: dimClienteDrift.dimCliente?.nomeCliente,
				tipoCliente: dimClienteDrift.dimCliente?.tipoCliente,
				cidade: dimClienteDrift.dimCliente?.cidade,
				estado: dimClienteDrift.dimCliente?.estado,
				segmento: dimClienteDrift.dimCliente?.segmento,
			);
		} else {
			return null;
		}
	}


	DimClienteGrouped toDrift(DimClienteModel dimClienteModel) {
		return DimClienteGrouped(
			dimCliente: DimCliente(
				id: dimClienteModel.id,
				nomeCliente: dimClienteModel.nomeCliente,
				tipoCliente: dimClienteModel.tipoCliente,
				cidade: dimClienteModel.cidade,
				estado: dimClienteModel.estado,
				segmento: dimClienteModel.segmento,
			),
		);
	}

		
}
