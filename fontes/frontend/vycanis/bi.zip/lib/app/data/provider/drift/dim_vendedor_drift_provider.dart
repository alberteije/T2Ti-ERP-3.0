import 'package:bi/app/data/provider/drift/database/database_imports.dart';
import 'package:bi/app/infra/infra_imports.dart';
import 'package:bi/app/data/provider/provider_base.dart';
import 'package:bi/app/data/provider/drift/database/database.dart';
import 'package:bi/app/data/model/model_imports.dart';

class DimVendedorDriftProvider extends ProviderBase {

	Future<List<DimVendedorModel>?> getList({Filter? filter}) async {
		List<DimVendedorGrouped> dimVendedorDriftList = [];

		try {
			if (filter != null && filter.field != null) {
				dimVendedorDriftList = await Session.database.dimVendedorDao.getGroupedList(field: filter.field, value: filter.value!);
			} else {
				dimVendedorDriftList = await Session.database.dimVendedorDao.getGroupedList(); 
			}
			if (dimVendedorDriftList.isNotEmpty) {
				return toListModel(dimVendedorDriftList);
			} else {
				return [];
			}			 
		} catch (e) {
			handleResultError(null, null, exception: e);
			return null;
		}
	}

	Future<DimVendedorModel?> getObject(dynamic pk) async {
		try {
			final result = await Session.database.dimVendedorDao.getObjectGrouped(field: 'id', value: pk);
			return toModel(result);
		} catch (e) {
			handleResultError(null, null, exception: e);
		}
		return null;
	}

	Future<DimVendedorModel?>? insert(DimVendedorModel dimVendedorModel) async {
		try {
			final lastPk = await Session.database.dimVendedorDao.insertObject(toDrift(dimVendedorModel));
			dimVendedorModel.id = lastPk;
			return dimVendedorModel;
		} catch (e) {
			handleResultError(null, null, exception: e);
		}
		return null;
	}

	Future<DimVendedorModel?>? update(DimVendedorModel dimVendedorModel) async {
		try {
			await Session.database.dimVendedorDao.updateObject(toDrift(dimVendedorModel));
			return dimVendedorModel;
		} catch (e) {
			handleResultError(null, null, exception: e);
		}
		return null;
	}

	Future<bool?> delete(dynamic pk) async {
		try {
			await Session.database.dimVendedorDao.deleteObject(toDrift(DimVendedorModel(id: pk)));
			return true;
		} catch (e) {
			handleResultError(null, null, exception: e);
		}
		return null;
	}	

	List<DimVendedorModel> toListModel(List<DimVendedorGrouped> dimVendedorDriftList) {
		List<DimVendedorModel> listModel = [];
		for (var dimVendedorDrift in dimVendedorDriftList) {
			listModel.add(toModel(dimVendedorDrift)!);
		}
		return listModel;
	}	

	DimVendedorModel? toModel(DimVendedorGrouped? dimVendedorDrift) {
		if (dimVendedorDrift != null) {
			return DimVendedorModel(
				id: dimVendedorDrift.dimVendedor?.id,
				nomeVendedor: dimVendedorDrift.dimVendedor?.nomeVendedor,
				equipe: dimVendedorDrift.dimVendedor?.equipe,
				regiao: dimVendedorDrift.dimVendedor?.regiao,
			);
		} else {
			return null;
		}
	}


	DimVendedorGrouped toDrift(DimVendedorModel dimVendedorModel) {
		return DimVendedorGrouped(
			dimVendedor: DimVendedor(
				id: dimVendedorModel.id,
				nomeVendedor: dimVendedorModel.nomeVendedor,
				equipe: dimVendedorModel.equipe,
				regiao: dimVendedorModel.regiao,
			),
		);
	}

		
}
