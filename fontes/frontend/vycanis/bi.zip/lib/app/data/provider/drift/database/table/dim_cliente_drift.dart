import 'package:drift/drift.dart';
import 'package:bi/app/data/provider/drift/database/database.dart';

@DataClassName("DimCliente")
class DimClientes extends Table {
	@override
	String get tableName => 'dim_cliente';

	IntColumn get id => integer().named('id').nullable()();
	TextColumn get nomeCliente => text().named('nome_cliente').nullable()();
	TextColumn get tipoCliente => text().named('tipo_cliente').nullable()();
	TextColumn get cidade => text().named('cidade').nullable()();
	TextColumn get estado => text().named('estado').nullable()();
	TextColumn get segmento => text().named('segmento').nullable()();

	@override
	Set<Column> get primaryKey => { id };	
	
}

class DimClienteGrouped {
	DimCliente? dimCliente; 

  DimClienteGrouped({
		this.dimCliente, 

  });
}
