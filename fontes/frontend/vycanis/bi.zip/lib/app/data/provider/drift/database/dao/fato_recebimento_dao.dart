import 'package:drift/drift.dart';
import 'package:bi/app/data/provider/drift/database/database.dart';
import 'package:bi/app/data/provider/drift/database/database_imports.dart';

part 'fato_recebimento_dao.g.dart';

@DriftAccessor(tables: [
	FatoRecebimentos,
])
class FatoRecebimentoDao extends DatabaseAccessor<AppDatabase> with _$FatoRecebimentoDaoMixin {
	final AppDatabase db;

	List<FatoRecebimento> fatoRecebimentoList = []; 
	List<FatoRecebimentoGrouped> fatoRecebimentoGroupedList = []; 

	FatoRecebimentoDao(this.db) : super(db);

	Future<List<FatoRecebimento>> getList() async {
		fatoRecebimentoList = await select(fatoRecebimentos).get();
		return fatoRecebimentoList;
	}

	Future<List<FatoRecebimento>> getListFilter(String field, String value) async {
		final query = " $field like '%$value%'";
		final expression = CustomExpression<bool>(query);
		fatoRecebimentoList = await (select(fatoRecebimentos)..where((t) => expression)).get();
		return fatoRecebimentoList;	 
	}

	Future<List<FatoRecebimentoGrouped>> getGroupedList({String? field, dynamic value}) async {
		final query = select(fatoRecebimentos)
			.join([]);

		if (field != null && field != '') { 
			final column = fatoRecebimentos.$columns.where(((column) => column.$name == field)).first;
			if (column is TextColumn) {
				query.where((column as TextColumn).like('%$value%'));
			} else if (column is IntColumn) {
				query.where(column.equals(int.tryParse(value) as Object));
			} else if (column is RealColumn) {
				query.where(column.equals(double.tryParse(value) as Object));
			}
		}

		fatoRecebimentoGroupedList = await query.map((row) {
			final fatoRecebimento = row.readTableOrNull(fatoRecebimentos); 

			return FatoRecebimentoGrouped(
				fatoRecebimento: fatoRecebimento, 

			);
		}).get();

		// fill internal lists
		//dynamic expression;
		//for (var fatoRecebimentoGrouped in fatoRecebimentoGroupedList) {
		//}		

		return fatoRecebimentoGroupedList;	
	}

	Future<FatoRecebimento?> getObject(dynamic pk) async {
		return await (select(fatoRecebimentos)..where((t) => t.id.equals(pk))).getSingleOrNull();
	} 

	Future<FatoRecebimento?> getObjectFilter(String field, String value) async {
		final query = "SELECT * FROM fato_recebimento WHERE $field like '%$value%'";
		return (await customSelect(query).getSingleOrNull()) as FatoRecebimento;		 
	} 

	Future<FatoRecebimentoGrouped?> getObjectGrouped({String? field, dynamic value}) async {
		final result = await getGroupedList(field: field, value: value);

		if (result.length != 1) {
			return null;
		} else {
			return result[0];
		} 
	}

	Future<int> insertObject(FatoRecebimentoGrouped object) {
		return transaction(() async {
			final maxPk = await lastPk();
			object.fatoRecebimento = object.fatoRecebimento!.copyWith(id: Value(maxPk + 1));
			final pkInserted = await into(fatoRecebimentos).insert(object.fatoRecebimento!);
			object.fatoRecebimento = object.fatoRecebimento!.copyWith(id: Value(pkInserted));			 
			await insertChildren(object);
			return pkInserted;
		});		
	}	 

	Future<bool> updateObject(FatoRecebimentoGrouped object) {
		return transaction(() async {
			await deleteChildren(object);
			await insertChildren(object);
			return update(fatoRecebimentos).replace(object.fatoRecebimento!);
		});	 
	} 

	Future<int> deleteObject(FatoRecebimentoGrouped object) {
		return transaction(() async {
			await deleteChildren(object);
			return delete(fatoRecebimentos).delete(object.fatoRecebimento!);
		});		
	}

	Future<void> insertChildren(FatoRecebimentoGrouped object) async {
	}
	
	Future<void> deleteChildren(FatoRecebimentoGrouped object) async {
	}

	Future<int> lastPk() async {
		final result = await customSelect("select MAX(id) as LAST from fato_recebimento").getSingleOrNull();
		return result?.data["LAST"] ?? 0;
	} 
}