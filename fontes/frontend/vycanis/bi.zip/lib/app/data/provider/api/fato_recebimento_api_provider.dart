import 'package:bi/app/data/provider/api/api_provider_base.dart';
import 'package:bi/app/data/model/model_imports.dart';

class FatoRecebimentoApiProvider extends ApiProviderBase {
  static const _path = '/fato-recebimento';

  Future<List<FatoRecebimentoModel>?> getList({Filter? filter}) {
    return super.getListBase(
      '$_path/',
      (json) => FatoRecebimentoModel.fromJson(json),
      filter: filter,
    );
  }

  Future<FatoRecebimentoModel?> getObject(dynamic pk) {
    return super.getObjectBase(
      _path,
      pk,
      (json) => FatoRecebimentoModel.fromJson(json),
    );
  }

  Future<FatoRecebimentoModel?>? insert(FatoRecebimentoModel model) {
    return super.insertBase(
      _path,
      model,
      (json) => FatoRecebimentoModel.fromJson(json),
    );
  }

  Future<FatoRecebimentoModel?>? update(FatoRecebimentoModel model) {
    return super.updateBase(
      _path,
      model,
      (json) => FatoRecebimentoModel.fromJson(json),
    );
  }

  Future<bool?> delete(dynamic pk) {
    return super.deleteBase(_path, pk);
  }
}
