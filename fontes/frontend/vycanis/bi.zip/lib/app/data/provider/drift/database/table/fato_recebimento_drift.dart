import 'package:drift/drift.dart';
import 'package:bi/app/data/provider/drift/database/database.dart';

@DataClassName("FatoRecebimento")
class FatoRecebimentos extends Table {
	@override
	String get tableName => 'fato_recebimento';

	IntColumn get id => integer().named('id').nullable()();
	IntColumn get idTempo => integer().named('id_tempo').nullable()();
	IntColumn get idCliente => integer().named('id_cliente').nullable()();
	RealColumn get valorRecebido => real().named('valor_recebido').nullable()();
	RealColumn get valorEmAberto => real().named('valor_em_aberto').nullable()();
	IntColumn get atrasoDias => integer().named('atraso_dias').nullable()();

	@override
	Set<Column> get primaryKey => { id };	
	
}

class FatoRecebimentoGrouped {
	FatoRecebimento? fatoRecebimento; 

  FatoRecebimentoGrouped({
		this.fatoRecebimento, 

  });
}
