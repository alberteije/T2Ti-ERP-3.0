import 'package:bi/app/data/provider/drift/database/database_imports.dart';
import 'package:bi/app/infra/infra_imports.dart';
import 'package:bi/app/data/provider/provider_base.dart';
import 'package:bi/app/data/provider/drift/database/database.dart';
import 'package:bi/app/data/model/model_imports.dart';

class DimProdutoDriftProvider extends ProviderBase {

	Future<List<DimProdutoModel>?> getList({Filter? filter}) async {
		List<DimProdutoGrouped> dimProdutoDriftList = [];

		try {
			if (filter != null && filter.field != null) {
				dimProdutoDriftList = await Session.database.dimProdutoDao.getGroupedList(field: filter.field, value: filter.value!);
			} else {
				dimProdutoDriftList = await Session.database.dimProdutoDao.getGroupedList(); 
			}
			if (dimProdutoDriftList.isNotEmpty) {
				return toListModel(dimProdutoDriftList);
			} else {
				return [];
			}			 
		} catch (e) {
			handleResultError(null, null, exception: e);
			return null;
		}
	}

	Future<DimProdutoModel?> getObject(dynamic pk) async {
		try {
			final result = await Session.database.dimProdutoDao.getObjectGrouped(field: 'id', value: pk);
			return toModel(result);
		} catch (e) {
			handleResultError(null, null, exception: e);
		}
		return null;
	}

	Future<DimProdutoModel?>? insert(DimProdutoModel dimProdutoModel) async {
		try {
			final lastPk = await Session.database.dimProdutoDao.insertObject(toDrift(dimProdutoModel));
			dimProdutoModel.id = lastPk;
			return dimProdutoModel;
		} catch (e) {
			handleResultError(null, null, exception: e);
		}
		return null;
	}

	Future<DimProdutoModel?>? update(DimProdutoModel dimProdutoModel) async {
		try {
			await Session.database.dimProdutoDao.updateObject(toDrift(dimProdutoModel));
			return dimProdutoModel;
		} catch (e) {
			handleResultError(null, null, exception: e);
		}
		return null;
	}

	Future<bool?> delete(dynamic pk) async {
		try {
			await Session.database.dimProdutoDao.deleteObject(toDrift(DimProdutoModel(id: pk)));
			return true;
		} catch (e) {
			handleResultError(null, null, exception: e);
		}
		return null;
	}	

	List<DimProdutoModel> toListModel(List<DimProdutoGrouped> dimProdutoDriftList) {
		List<DimProdutoModel> listModel = [];
		for (var dimProdutoDrift in dimProdutoDriftList) {
			listModel.add(toModel(dimProdutoDrift)!);
		}
		return listModel;
	}	

	DimProdutoModel? toModel(DimProdutoGrouped? dimProdutoDrift) {
		if (dimProdutoDrift != null) {
			return DimProdutoModel(
				id: dimProdutoDrift.dimProduto?.id,
				descricao: dimProdutoDrift.dimProduto?.descricao,
				categoria: dimProdutoDrift.dimProduto?.categoria,
				marca: dimProdutoDrift.dimProduto?.marca,
			);
		} else {
			return null;
		}
	}


	DimProdutoGrouped toDrift(DimProdutoModel dimProdutoModel) {
		return DimProdutoGrouped(
			dimProduto: DimProduto(
				id: dimProdutoModel.id,
				descricao: dimProdutoModel.descricao,
				categoria: dimProdutoModel.categoria,
				marca: dimProdutoModel.marca,
			),
		);
	}

		
}
