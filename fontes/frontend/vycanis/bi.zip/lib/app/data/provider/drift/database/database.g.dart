// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'database.dart';

// ignore_for_file: type=lint
class $DimTemposTable extends DimTempos
    with TableInfo<$DimTemposTable, DimTempo> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $DimTemposTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
    'id',
    aliasedName,
    true,
    type: DriftSqlType.int,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _dataMeta = const VerificationMeta('data');
  @override
  late final GeneratedColumn<DateTime> data = GeneratedColumn<DateTime>(
    'data',
    aliasedName,
    true,
    type: DriftSqlType.dateTime,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _anoMeta = const VerificationMeta('ano');
  @override
  late final GeneratedColumn<int> ano = GeneratedColumn<int>(
    'ano',
    aliasedName,
    true,
    type: DriftSqlType.int,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _mesMeta = const VerificationMeta('mes');
  @override
  late final GeneratedColumn<int> mes = GeneratedColumn<int>(
    'mes',
    aliasedName,
    true,
    type: DriftSqlType.int,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _nomeMesMeta = const VerificationMeta(
    'nomeMes',
  );
  @override
  late final GeneratedColumn<String> nomeMes = GeneratedColumn<String>(
    'nome_mes',
    aliasedName,
    true,
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _trimestreMeta = const VerificationMeta(
    'trimestre',
  );
  @override
  late final GeneratedColumn<int> trimestre = GeneratedColumn<int>(
    'trimestre',
    aliasedName,
    true,
    type: DriftSqlType.int,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _diaMeta = const VerificationMeta('dia');
  @override
  late final GeneratedColumn<int> dia = GeneratedColumn<int>(
    'dia',
    aliasedName,
    true,
    type: DriftSqlType.int,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _diaSemanaMeta = const VerificationMeta(
    'diaSemana',
  );
  @override
  late final GeneratedColumn<int> diaSemana = GeneratedColumn<int>(
    'dia_semana',
    aliasedName,
    true,
    type: DriftSqlType.int,
    requiredDuringInsert: false,
  );
  @override
  List<GeneratedColumn> get $columns => [
    id,
    data,
    ano,
    mes,
    nomeMes,
    trimestre,
    dia,
    diaSemana,
  ];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'dim_tempo';
  @override
  VerificationContext validateIntegrity(
    Insertable<DimTempo> instance, {
    bool isInserting = false,
  }) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('data')) {
      context.handle(
        _dataMeta,
        this.data.isAcceptableOrUnknown(data['data']!, _dataMeta),
      );
    }
    if (data.containsKey('ano')) {
      context.handle(
        _anoMeta,
        ano.isAcceptableOrUnknown(data['ano']!, _anoMeta),
      );
    }
    if (data.containsKey('mes')) {
      context.handle(
        _mesMeta,
        mes.isAcceptableOrUnknown(data['mes']!, _mesMeta),
      );
    }
    if (data.containsKey('nome_mes')) {
      context.handle(
        _nomeMesMeta,
        nomeMes.isAcceptableOrUnknown(data['nome_mes']!, _nomeMesMeta),
      );
    }
    if (data.containsKey('trimestre')) {
      context.handle(
        _trimestreMeta,
        trimestre.isAcceptableOrUnknown(data['trimestre']!, _trimestreMeta),
      );
    }
    if (data.containsKey('dia')) {
      context.handle(
        _diaMeta,
        dia.isAcceptableOrUnknown(data['dia']!, _diaMeta),
      );
    }
    if (data.containsKey('dia_semana')) {
      context.handle(
        _diaSemanaMeta,
        diaSemana.isAcceptableOrUnknown(data['dia_semana']!, _diaSemanaMeta),
      );
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  DimTempo map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return DimTempo(
      id: attachedDatabase.typeMapping.read(
        DriftSqlType.int,
        data['${effectivePrefix}id'],
      ),
      data: attachedDatabase.typeMapping.read(
        DriftSqlType.dateTime,
        data['${effectivePrefix}data'],
      ),
      ano: attachedDatabase.typeMapping.read(
        DriftSqlType.int,
        data['${effectivePrefix}ano'],
      ),
      mes: attachedDatabase.typeMapping.read(
        DriftSqlType.int,
        data['${effectivePrefix}mes'],
      ),
      nomeMes: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}nome_mes'],
      ),
      trimestre: attachedDatabase.typeMapping.read(
        DriftSqlType.int,
        data['${effectivePrefix}trimestre'],
      ),
      dia: attachedDatabase.typeMapping.read(
        DriftSqlType.int,
        data['${effectivePrefix}dia'],
      ),
      diaSemana: attachedDatabase.typeMapping.read(
        DriftSqlType.int,
        data['${effectivePrefix}dia_semana'],
      ),
    );
  }

  @override
  $DimTemposTable createAlias(String alias) {
    return $DimTemposTable(attachedDatabase, alias);
  }
}

class DimTempo extends DataClass implements Insertable<DimTempo> {
  final int? id;
  final DateTime? data;
  final int? ano;
  final int? mes;
  final String? nomeMes;
  final int? trimestre;
  final int? dia;
  final int? diaSemana;
  const DimTempo({
    this.id,
    this.data,
    this.ano,
    this.mes,
    this.nomeMes,
    this.trimestre,
    this.dia,
    this.diaSemana,
  });
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || data != null) {
      map['data'] = Variable<DateTime>(data);
    }
    if (!nullToAbsent || ano != null) {
      map['ano'] = Variable<int>(ano);
    }
    if (!nullToAbsent || mes != null) {
      map['mes'] = Variable<int>(mes);
    }
    if (!nullToAbsent || nomeMes != null) {
      map['nome_mes'] = Variable<String>(nomeMes);
    }
    if (!nullToAbsent || trimestre != null) {
      map['trimestre'] = Variable<int>(trimestre);
    }
    if (!nullToAbsent || dia != null) {
      map['dia'] = Variable<int>(dia);
    }
    if (!nullToAbsent || diaSemana != null) {
      map['dia_semana'] = Variable<int>(diaSemana);
    }
    return map;
  }

  factory DimTempo.fromJson(
    Map<String, dynamic> json, {
    ValueSerializer? serializer,
  }) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return DimTempo(
      id: serializer.fromJson<int?>(json['id']),
      data: serializer.fromJson<DateTime?>(json['data']),
      ano: serializer.fromJson<int?>(json['ano']),
      mes: serializer.fromJson<int?>(json['mes']),
      nomeMes: serializer.fromJson<String?>(json['nomeMes']),
      trimestre: serializer.fromJson<int?>(json['trimestre']),
      dia: serializer.fromJson<int?>(json['dia']),
      diaSemana: serializer.fromJson<int?>(json['diaSemana']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'data': serializer.toJson<DateTime?>(data),
      'ano': serializer.toJson<int?>(ano),
      'mes': serializer.toJson<int?>(mes),
      'nomeMes': serializer.toJson<String?>(nomeMes),
      'trimestre': serializer.toJson<int?>(trimestre),
      'dia': serializer.toJson<int?>(dia),
      'diaSemana': serializer.toJson<int?>(diaSemana),
    };
  }

  DimTempo copyWith({
    Value<int?> id = const Value.absent(),
    Value<DateTime?> data = const Value.absent(),
    Value<int?> ano = const Value.absent(),
    Value<int?> mes = const Value.absent(),
    Value<String?> nomeMes = const Value.absent(),
    Value<int?> trimestre = const Value.absent(),
    Value<int?> dia = const Value.absent(),
    Value<int?> diaSemana = const Value.absent(),
  }) => DimTempo(
    id: id.present ? id.value : this.id,
    data: data.present ? data.value : this.data,
    ano: ano.present ? ano.value : this.ano,
    mes: mes.present ? mes.value : this.mes,
    nomeMes: nomeMes.present ? nomeMes.value : this.nomeMes,
    trimestre: trimestre.present ? trimestre.value : this.trimestre,
    dia: dia.present ? dia.value : this.dia,
    diaSemana: diaSemana.present ? diaSemana.value : this.diaSemana,
  );
  DimTempo copyWithCompanion(DimTemposCompanion data) {
    return DimTempo(
      id: data.id.present ? data.id.value : this.id,
      data: data.data.present ? data.data.value : this.data,
      ano: data.ano.present ? data.ano.value : this.ano,
      mes: data.mes.present ? data.mes.value : this.mes,
      nomeMes: data.nomeMes.present ? data.nomeMes.value : this.nomeMes,
      trimestre: data.trimestre.present ? data.trimestre.value : this.trimestre,
      dia: data.dia.present ? data.dia.value : this.dia,
      diaSemana: data.diaSemana.present ? data.diaSemana.value : this.diaSemana,
    );
  }

  @override
  String toString() {
    return (StringBuffer('DimTempo(')
          ..write('id: $id, ')
          ..write('data: $data, ')
          ..write('ano: $ano, ')
          ..write('mes: $mes, ')
          ..write('nomeMes: $nomeMes, ')
          ..write('trimestre: $trimestre, ')
          ..write('dia: $dia, ')
          ..write('diaSemana: $diaSemana')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode =>
      Object.hash(id, data, ano, mes, nomeMes, trimestre, dia, diaSemana);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is DimTempo &&
          other.id == this.id &&
          other.data == this.data &&
          other.ano == this.ano &&
          other.mes == this.mes &&
          other.nomeMes == this.nomeMes &&
          other.trimestre == this.trimestre &&
          other.dia == this.dia &&
          other.diaSemana == this.diaSemana);
}

class DimTemposCompanion extends UpdateCompanion<DimTempo> {
  final Value<int?> id;
  final Value<DateTime?> data;
  final Value<int?> ano;
  final Value<int?> mes;
  final Value<String?> nomeMes;
  final Value<int?> trimestre;
  final Value<int?> dia;
  final Value<int?> diaSemana;
  const DimTemposCompanion({
    this.id = const Value.absent(),
    this.data = const Value.absent(),
    this.ano = const Value.absent(),
    this.mes = const Value.absent(),
    this.nomeMes = const Value.absent(),
    this.trimestre = const Value.absent(),
    this.dia = const Value.absent(),
    this.diaSemana = const Value.absent(),
  });
  DimTemposCompanion.insert({
    this.id = const Value.absent(),
    this.data = const Value.absent(),
    this.ano = const Value.absent(),
    this.mes = const Value.absent(),
    this.nomeMes = const Value.absent(),
    this.trimestre = const Value.absent(),
    this.dia = const Value.absent(),
    this.diaSemana = const Value.absent(),
  });
  static Insertable<DimTempo> custom({
    Expression<int>? id,
    Expression<DateTime>? data,
    Expression<int>? ano,
    Expression<int>? mes,
    Expression<String>? nomeMes,
    Expression<int>? trimestre,
    Expression<int>? dia,
    Expression<int>? diaSemana,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (data != null) 'data': data,
      if (ano != null) 'ano': ano,
      if (mes != null) 'mes': mes,
      if (nomeMes != null) 'nome_mes': nomeMes,
      if (trimestre != null) 'trimestre': trimestre,
      if (dia != null) 'dia': dia,
      if (diaSemana != null) 'dia_semana': diaSemana,
    });
  }

  DimTemposCompanion copyWith({
    Value<int?>? id,
    Value<DateTime?>? data,
    Value<int?>? ano,
    Value<int?>? mes,
    Value<String?>? nomeMes,
    Value<int?>? trimestre,
    Value<int?>? dia,
    Value<int?>? diaSemana,
  }) {
    return DimTemposCompanion(
      id: id ?? this.id,
      data: data ?? this.data,
      ano: ano ?? this.ano,
      mes: mes ?? this.mes,
      nomeMes: nomeMes ?? this.nomeMes,
      trimestre: trimestre ?? this.trimestre,
      dia: dia ?? this.dia,
      diaSemana: diaSemana ?? this.diaSemana,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (data.present) {
      map['data'] = Variable<DateTime>(data.value);
    }
    if (ano.present) {
      map['ano'] = Variable<int>(ano.value);
    }
    if (mes.present) {
      map['mes'] = Variable<int>(mes.value);
    }
    if (nomeMes.present) {
      map['nome_mes'] = Variable<String>(nomeMes.value);
    }
    if (trimestre.present) {
      map['trimestre'] = Variable<int>(trimestre.value);
    }
    if (dia.present) {
      map['dia'] = Variable<int>(dia.value);
    }
    if (diaSemana.present) {
      map['dia_semana'] = Variable<int>(diaSemana.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('DimTemposCompanion(')
          ..write('id: $id, ')
          ..write('data: $data, ')
          ..write('ano: $ano, ')
          ..write('mes: $mes, ')
          ..write('nomeMes: $nomeMes, ')
          ..write('trimestre: $trimestre, ')
          ..write('dia: $dia, ')
          ..write('diaSemana: $diaSemana')
          ..write(')'))
        .toString();
  }
}

class $DimClientesTable extends DimClientes
    with TableInfo<$DimClientesTable, DimCliente> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $DimClientesTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
    'id',
    aliasedName,
    true,
    type: DriftSqlType.int,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _nomeClienteMeta = const VerificationMeta(
    'nomeCliente',
  );
  @override
  late final GeneratedColumn<String> nomeCliente = GeneratedColumn<String>(
    'nome_cliente',
    aliasedName,
    true,
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _tipoClienteMeta = const VerificationMeta(
    'tipoCliente',
  );
  @override
  late final GeneratedColumn<String> tipoCliente = GeneratedColumn<String>(
    'tipo_cliente',
    aliasedName,
    true,
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _cidadeMeta = const VerificationMeta('cidade');
  @override
  late final GeneratedColumn<String> cidade = GeneratedColumn<String>(
    'cidade',
    aliasedName,
    true,
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _estadoMeta = const VerificationMeta('estado');
  @override
  late final GeneratedColumn<String> estado = GeneratedColumn<String>(
    'estado',
    aliasedName,
    true,
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _segmentoMeta = const VerificationMeta(
    'segmento',
  );
  @override
  late final GeneratedColumn<String> segmento = GeneratedColumn<String>(
    'segmento',
    aliasedName,
    true,
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  @override
  List<GeneratedColumn> get $columns => [
    id,
    nomeCliente,
    tipoCliente,
    cidade,
    estado,
    segmento,
  ];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'dim_cliente';
  @override
  VerificationContext validateIntegrity(
    Insertable<DimCliente> instance, {
    bool isInserting = false,
  }) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('nome_cliente')) {
      context.handle(
        _nomeClienteMeta,
        nomeCliente.isAcceptableOrUnknown(
          data['nome_cliente']!,
          _nomeClienteMeta,
        ),
      );
    }
    if (data.containsKey('tipo_cliente')) {
      context.handle(
        _tipoClienteMeta,
        tipoCliente.isAcceptableOrUnknown(
          data['tipo_cliente']!,
          _tipoClienteMeta,
        ),
      );
    }
    if (data.containsKey('cidade')) {
      context.handle(
        _cidadeMeta,
        cidade.isAcceptableOrUnknown(data['cidade']!, _cidadeMeta),
      );
    }
    if (data.containsKey('estado')) {
      context.handle(
        _estadoMeta,
        estado.isAcceptableOrUnknown(data['estado']!, _estadoMeta),
      );
    }
    if (data.containsKey('segmento')) {
      context.handle(
        _segmentoMeta,
        segmento.isAcceptableOrUnknown(data['segmento']!, _segmentoMeta),
      );
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  DimCliente map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return DimCliente(
      id: attachedDatabase.typeMapping.read(
        DriftSqlType.int,
        data['${effectivePrefix}id'],
      ),
      nomeCliente: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}nome_cliente'],
      ),
      tipoCliente: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}tipo_cliente'],
      ),
      cidade: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}cidade'],
      ),
      estado: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}estado'],
      ),
      segmento: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}segmento'],
      ),
    );
  }

  @override
  $DimClientesTable createAlias(String alias) {
    return $DimClientesTable(attachedDatabase, alias);
  }
}

class DimCliente extends DataClass implements Insertable<DimCliente> {
  final int? id;
  final String? nomeCliente;
  final String? tipoCliente;
  final String? cidade;
  final String? estado;
  final String? segmento;
  const DimCliente({
    this.id,
    this.nomeCliente,
    this.tipoCliente,
    this.cidade,
    this.estado,
    this.segmento,
  });
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || nomeCliente != null) {
      map['nome_cliente'] = Variable<String>(nomeCliente);
    }
    if (!nullToAbsent || tipoCliente != null) {
      map['tipo_cliente'] = Variable<String>(tipoCliente);
    }
    if (!nullToAbsent || cidade != null) {
      map['cidade'] = Variable<String>(cidade);
    }
    if (!nullToAbsent || estado != null) {
      map['estado'] = Variable<String>(estado);
    }
    if (!nullToAbsent || segmento != null) {
      map['segmento'] = Variable<String>(segmento);
    }
    return map;
  }

  factory DimCliente.fromJson(
    Map<String, dynamic> json, {
    ValueSerializer? serializer,
  }) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return DimCliente(
      id: serializer.fromJson<int?>(json['id']),
      nomeCliente: serializer.fromJson<String?>(json['nomeCliente']),
      tipoCliente: serializer.fromJson<String?>(json['tipoCliente']),
      cidade: serializer.fromJson<String?>(json['cidade']),
      estado: serializer.fromJson<String?>(json['estado']),
      segmento: serializer.fromJson<String?>(json['segmento']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'nomeCliente': serializer.toJson<String?>(nomeCliente),
      'tipoCliente': serializer.toJson<String?>(tipoCliente),
      'cidade': serializer.toJson<String?>(cidade),
      'estado': serializer.toJson<String?>(estado),
      'segmento': serializer.toJson<String?>(segmento),
    };
  }

  DimCliente copyWith({
    Value<int?> id = const Value.absent(),
    Value<String?> nomeCliente = const Value.absent(),
    Value<String?> tipoCliente = const Value.absent(),
    Value<String?> cidade = const Value.absent(),
    Value<String?> estado = const Value.absent(),
    Value<String?> segmento = const Value.absent(),
  }) => DimCliente(
    id: id.present ? id.value : this.id,
    nomeCliente: nomeCliente.present ? nomeCliente.value : this.nomeCliente,
    tipoCliente: tipoCliente.present ? tipoCliente.value : this.tipoCliente,
    cidade: cidade.present ? cidade.value : this.cidade,
    estado: estado.present ? estado.value : this.estado,
    segmento: segmento.present ? segmento.value : this.segmento,
  );
  DimCliente copyWithCompanion(DimClientesCompanion data) {
    return DimCliente(
      id: data.id.present ? data.id.value : this.id,
      nomeCliente:
          data.nomeCliente.present ? data.nomeCliente.value : this.nomeCliente,
      tipoCliente:
          data.tipoCliente.present ? data.tipoCliente.value : this.tipoCliente,
      cidade: data.cidade.present ? data.cidade.value : this.cidade,
      estado: data.estado.present ? data.estado.value : this.estado,
      segmento: data.segmento.present ? data.segmento.value : this.segmento,
    );
  }

  @override
  String toString() {
    return (StringBuffer('DimCliente(')
          ..write('id: $id, ')
          ..write('nomeCliente: $nomeCliente, ')
          ..write('tipoCliente: $tipoCliente, ')
          ..write('cidade: $cidade, ')
          ..write('estado: $estado, ')
          ..write('segmento: $segmento')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode =>
      Object.hash(id, nomeCliente, tipoCliente, cidade, estado, segmento);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is DimCliente &&
          other.id == this.id &&
          other.nomeCliente == this.nomeCliente &&
          other.tipoCliente == this.tipoCliente &&
          other.cidade == this.cidade &&
          other.estado == this.estado &&
          other.segmento == this.segmento);
}

class DimClientesCompanion extends UpdateCompanion<DimCliente> {
  final Value<int?> id;
  final Value<String?> nomeCliente;
  final Value<String?> tipoCliente;
  final Value<String?> cidade;
  final Value<String?> estado;
  final Value<String?> segmento;
  const DimClientesCompanion({
    this.id = const Value.absent(),
    this.nomeCliente = const Value.absent(),
    this.tipoCliente = const Value.absent(),
    this.cidade = const Value.absent(),
    this.estado = const Value.absent(),
    this.segmento = const Value.absent(),
  });
  DimClientesCompanion.insert({
    this.id = const Value.absent(),
    this.nomeCliente = const Value.absent(),
    this.tipoCliente = const Value.absent(),
    this.cidade = const Value.absent(),
    this.estado = const Value.absent(),
    this.segmento = const Value.absent(),
  });
  static Insertable<DimCliente> custom({
    Expression<int>? id,
    Expression<String>? nomeCliente,
    Expression<String>? tipoCliente,
    Expression<String>? cidade,
    Expression<String>? estado,
    Expression<String>? segmento,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (nomeCliente != null) 'nome_cliente': nomeCliente,
      if (tipoCliente != null) 'tipo_cliente': tipoCliente,
      if (cidade != null) 'cidade': cidade,
      if (estado != null) 'estado': estado,
      if (segmento != null) 'segmento': segmento,
    });
  }

  DimClientesCompanion copyWith({
    Value<int?>? id,
    Value<String?>? nomeCliente,
    Value<String?>? tipoCliente,
    Value<String?>? cidade,
    Value<String?>? estado,
    Value<String?>? segmento,
  }) {
    return DimClientesCompanion(
      id: id ?? this.id,
      nomeCliente: nomeCliente ?? this.nomeCliente,
      tipoCliente: tipoCliente ?? this.tipoCliente,
      cidade: cidade ?? this.cidade,
      estado: estado ?? this.estado,
      segmento: segmento ?? this.segmento,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (nomeCliente.present) {
      map['nome_cliente'] = Variable<String>(nomeCliente.value);
    }
    if (tipoCliente.present) {
      map['tipo_cliente'] = Variable<String>(tipoCliente.value);
    }
    if (cidade.present) {
      map['cidade'] = Variable<String>(cidade.value);
    }
    if (estado.present) {
      map['estado'] = Variable<String>(estado.value);
    }
    if (segmento.present) {
      map['segmento'] = Variable<String>(segmento.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('DimClientesCompanion(')
          ..write('id: $id, ')
          ..write('nomeCliente: $nomeCliente, ')
          ..write('tipoCliente: $tipoCliente, ')
          ..write('cidade: $cidade, ')
          ..write('estado: $estado, ')
          ..write('segmento: $segmento')
          ..write(')'))
        .toString();
  }
}

class $DimVendedorsTable extends DimVendedors
    with TableInfo<$DimVendedorsTable, DimVendedor> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $DimVendedorsTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
    'id',
    aliasedName,
    true,
    type: DriftSqlType.int,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _nomeVendedorMeta = const VerificationMeta(
    'nomeVendedor',
  );
  @override
  late final GeneratedColumn<String> nomeVendedor = GeneratedColumn<String>(
    'nome_vendedor',
    aliasedName,
    true,
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _equipeMeta = const VerificationMeta('equipe');
  @override
  late final GeneratedColumn<String> equipe = GeneratedColumn<String>(
    'equipe',
    aliasedName,
    true,
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _regiaoMeta = const VerificationMeta('regiao');
  @override
  late final GeneratedColumn<String> regiao = GeneratedColumn<String>(
    'regiao',
    aliasedName,
    true,
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  @override
  List<GeneratedColumn> get $columns => [id, nomeVendedor, equipe, regiao];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'dim_vendedor';
  @override
  VerificationContext validateIntegrity(
    Insertable<DimVendedor> instance, {
    bool isInserting = false,
  }) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('nome_vendedor')) {
      context.handle(
        _nomeVendedorMeta,
        nomeVendedor.isAcceptableOrUnknown(
          data['nome_vendedor']!,
          _nomeVendedorMeta,
        ),
      );
    }
    if (data.containsKey('equipe')) {
      context.handle(
        _equipeMeta,
        equipe.isAcceptableOrUnknown(data['equipe']!, _equipeMeta),
      );
    }
    if (data.containsKey('regiao')) {
      context.handle(
        _regiaoMeta,
        regiao.isAcceptableOrUnknown(data['regiao']!, _regiaoMeta),
      );
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  DimVendedor map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return DimVendedor(
      id: attachedDatabase.typeMapping.read(
        DriftSqlType.int,
        data['${effectivePrefix}id'],
      ),
      nomeVendedor: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}nome_vendedor'],
      ),
      equipe: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}equipe'],
      ),
      regiao: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}regiao'],
      ),
    );
  }

  @override
  $DimVendedorsTable createAlias(String alias) {
    return $DimVendedorsTable(attachedDatabase, alias);
  }
}

class DimVendedor extends DataClass implements Insertable<DimVendedor> {
  final int? id;
  final String? nomeVendedor;
  final String? equipe;
  final String? regiao;
  const DimVendedor({this.id, this.nomeVendedor, this.equipe, this.regiao});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || nomeVendedor != null) {
      map['nome_vendedor'] = Variable<String>(nomeVendedor);
    }
    if (!nullToAbsent || equipe != null) {
      map['equipe'] = Variable<String>(equipe);
    }
    if (!nullToAbsent || regiao != null) {
      map['regiao'] = Variable<String>(regiao);
    }
    return map;
  }

  factory DimVendedor.fromJson(
    Map<String, dynamic> json, {
    ValueSerializer? serializer,
  }) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return DimVendedor(
      id: serializer.fromJson<int?>(json['id']),
      nomeVendedor: serializer.fromJson<String?>(json['nomeVendedor']),
      equipe: serializer.fromJson<String?>(json['equipe']),
      regiao: serializer.fromJson<String?>(json['regiao']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'nomeVendedor': serializer.toJson<String?>(nomeVendedor),
      'equipe': serializer.toJson<String?>(equipe),
      'regiao': serializer.toJson<String?>(regiao),
    };
  }

  DimVendedor copyWith({
    Value<int?> id = const Value.absent(),
    Value<String?> nomeVendedor = const Value.absent(),
    Value<String?> equipe = const Value.absent(),
    Value<String?> regiao = const Value.absent(),
  }) => DimVendedor(
    id: id.present ? id.value : this.id,
    nomeVendedor: nomeVendedor.present ? nomeVendedor.value : this.nomeVendedor,
    equipe: equipe.present ? equipe.value : this.equipe,
    regiao: regiao.present ? regiao.value : this.regiao,
  );
  DimVendedor copyWithCompanion(DimVendedorsCompanion data) {
    return DimVendedor(
      id: data.id.present ? data.id.value : this.id,
      nomeVendedor:
          data.nomeVendedor.present
              ? data.nomeVendedor.value
              : this.nomeVendedor,
      equipe: data.equipe.present ? data.equipe.value : this.equipe,
      regiao: data.regiao.present ? data.regiao.value : this.regiao,
    );
  }

  @override
  String toString() {
    return (StringBuffer('DimVendedor(')
          ..write('id: $id, ')
          ..write('nomeVendedor: $nomeVendedor, ')
          ..write('equipe: $equipe, ')
          ..write('regiao: $regiao')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(id, nomeVendedor, equipe, regiao);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is DimVendedor &&
          other.id == this.id &&
          other.nomeVendedor == this.nomeVendedor &&
          other.equipe == this.equipe &&
          other.regiao == this.regiao);
}

class DimVendedorsCompanion extends UpdateCompanion<DimVendedor> {
  final Value<int?> id;
  final Value<String?> nomeVendedor;
  final Value<String?> equipe;
  final Value<String?> regiao;
  const DimVendedorsCompanion({
    this.id = const Value.absent(),
    this.nomeVendedor = const Value.absent(),
    this.equipe = const Value.absent(),
    this.regiao = const Value.absent(),
  });
  DimVendedorsCompanion.insert({
    this.id = const Value.absent(),
    this.nomeVendedor = const Value.absent(),
    this.equipe = const Value.absent(),
    this.regiao = const Value.absent(),
  });
  static Insertable<DimVendedor> custom({
    Expression<int>? id,
    Expression<String>? nomeVendedor,
    Expression<String>? equipe,
    Expression<String>? regiao,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (nomeVendedor != null) 'nome_vendedor': nomeVendedor,
      if (equipe != null) 'equipe': equipe,
      if (regiao != null) 'regiao': regiao,
    });
  }

  DimVendedorsCompanion copyWith({
    Value<int?>? id,
    Value<String?>? nomeVendedor,
    Value<String?>? equipe,
    Value<String?>? regiao,
  }) {
    return DimVendedorsCompanion(
      id: id ?? this.id,
      nomeVendedor: nomeVendedor ?? this.nomeVendedor,
      equipe: equipe ?? this.equipe,
      regiao: regiao ?? this.regiao,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (nomeVendedor.present) {
      map['nome_vendedor'] = Variable<String>(nomeVendedor.value);
    }
    if (equipe.present) {
      map['equipe'] = Variable<String>(equipe.value);
    }
    if (regiao.present) {
      map['regiao'] = Variable<String>(regiao.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('DimVendedorsCompanion(')
          ..write('id: $id, ')
          ..write('nomeVendedor: $nomeVendedor, ')
          ..write('equipe: $equipe, ')
          ..write('regiao: $regiao')
          ..write(')'))
        .toString();
  }
}

class $DimProdutosTable extends DimProdutos
    with TableInfo<$DimProdutosTable, DimProduto> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $DimProdutosTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
    'id',
    aliasedName,
    true,
    type: DriftSqlType.int,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _descricaoMeta = const VerificationMeta(
    'descricao',
  );
  @override
  late final GeneratedColumn<String> descricao = GeneratedColumn<String>(
    'descricao',
    aliasedName,
    true,
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _categoriaMeta = const VerificationMeta(
    'categoria',
  );
  @override
  late final GeneratedColumn<String> categoria = GeneratedColumn<String>(
    'categoria',
    aliasedName,
    true,
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _marcaMeta = const VerificationMeta('marca');
  @override
  late final GeneratedColumn<String> marca = GeneratedColumn<String>(
    'marca',
    aliasedName,
    true,
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  @override
  List<GeneratedColumn> get $columns => [id, descricao, categoria, marca];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'dim_produto';
  @override
  VerificationContext validateIntegrity(
    Insertable<DimProduto> instance, {
    bool isInserting = false,
  }) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('descricao')) {
      context.handle(
        _descricaoMeta,
        descricao.isAcceptableOrUnknown(data['descricao']!, _descricaoMeta),
      );
    }
    if (data.containsKey('categoria')) {
      context.handle(
        _categoriaMeta,
        categoria.isAcceptableOrUnknown(data['categoria']!, _categoriaMeta),
      );
    }
    if (data.containsKey('marca')) {
      context.handle(
        _marcaMeta,
        marca.isAcceptableOrUnknown(data['marca']!, _marcaMeta),
      );
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  DimProduto map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return DimProduto(
      id: attachedDatabase.typeMapping.read(
        DriftSqlType.int,
        data['${effectivePrefix}id'],
      ),
      descricao: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}descricao'],
      ),
      categoria: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}categoria'],
      ),
      marca: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}marca'],
      ),
    );
  }

  @override
  $DimProdutosTable createAlias(String alias) {
    return $DimProdutosTable(attachedDatabase, alias);
  }
}

class DimProduto extends DataClass implements Insertable<DimProduto> {
  final int? id;
  final String? descricao;
  final String? categoria;
  final String? marca;
  const DimProduto({this.id, this.descricao, this.categoria, this.marca});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || descricao != null) {
      map['descricao'] = Variable<String>(descricao);
    }
    if (!nullToAbsent || categoria != null) {
      map['categoria'] = Variable<String>(categoria);
    }
    if (!nullToAbsent || marca != null) {
      map['marca'] = Variable<String>(marca);
    }
    return map;
  }

  factory DimProduto.fromJson(
    Map<String, dynamic> json, {
    ValueSerializer? serializer,
  }) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return DimProduto(
      id: serializer.fromJson<int?>(json['id']),
      descricao: serializer.fromJson<String?>(json['descricao']),
      categoria: serializer.fromJson<String?>(json['categoria']),
      marca: serializer.fromJson<String?>(json['marca']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'descricao': serializer.toJson<String?>(descricao),
      'categoria': serializer.toJson<String?>(categoria),
      'marca': serializer.toJson<String?>(marca),
    };
  }

  DimProduto copyWith({
    Value<int?> id = const Value.absent(),
    Value<String?> descricao = const Value.absent(),
    Value<String?> categoria = const Value.absent(),
    Value<String?> marca = const Value.absent(),
  }) => DimProduto(
    id: id.present ? id.value : this.id,
    descricao: descricao.present ? descricao.value : this.descricao,
    categoria: categoria.present ? categoria.value : this.categoria,
    marca: marca.present ? marca.value : this.marca,
  );
  DimProduto copyWithCompanion(DimProdutosCompanion data) {
    return DimProduto(
      id: data.id.present ? data.id.value : this.id,
      descricao: data.descricao.present ? data.descricao.value : this.descricao,
      categoria: data.categoria.present ? data.categoria.value : this.categoria,
      marca: data.marca.present ? data.marca.value : this.marca,
    );
  }

  @override
  String toString() {
    return (StringBuffer('DimProduto(')
          ..write('id: $id, ')
          ..write('descricao: $descricao, ')
          ..write('categoria: $categoria, ')
          ..write('marca: $marca')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(id, descricao, categoria, marca);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is DimProduto &&
          other.id == this.id &&
          other.descricao == this.descricao &&
          other.categoria == this.categoria &&
          other.marca == this.marca);
}

class DimProdutosCompanion extends UpdateCompanion<DimProduto> {
  final Value<int?> id;
  final Value<String?> descricao;
  final Value<String?> categoria;
  final Value<String?> marca;
  const DimProdutosCompanion({
    this.id = const Value.absent(),
    this.descricao = const Value.absent(),
    this.categoria = const Value.absent(),
    this.marca = const Value.absent(),
  });
  DimProdutosCompanion.insert({
    this.id = const Value.absent(),
    this.descricao = const Value.absent(),
    this.categoria = const Value.absent(),
    this.marca = const Value.absent(),
  });
  static Insertable<DimProduto> custom({
    Expression<int>? id,
    Expression<String>? descricao,
    Expression<String>? categoria,
    Expression<String>? marca,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (descricao != null) 'descricao': descricao,
      if (categoria != null) 'categoria': categoria,
      if (marca != null) 'marca': marca,
    });
  }

  DimProdutosCompanion copyWith({
    Value<int?>? id,
    Value<String?>? descricao,
    Value<String?>? categoria,
    Value<String?>? marca,
  }) {
    return DimProdutosCompanion(
      id: id ?? this.id,
      descricao: descricao ?? this.descricao,
      categoria: categoria ?? this.categoria,
      marca: marca ?? this.marca,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (descricao.present) {
      map['descricao'] = Variable<String>(descricao.value);
    }
    if (categoria.present) {
      map['categoria'] = Variable<String>(categoria.value);
    }
    if (marca.present) {
      map['marca'] = Variable<String>(marca.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('DimProdutosCompanion(')
          ..write('id: $id, ')
          ..write('descricao: $descricao, ')
          ..write('categoria: $categoria, ')
          ..write('marca: $marca')
          ..write(')'))
        .toString();
  }
}

class $FatoVendasTable extends FatoVendas
    with TableInfo<$FatoVendasTable, FatoVenda> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $FatoVendasTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
    'id',
    aliasedName,
    true,
    type: DriftSqlType.int,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _idTempoMeta = const VerificationMeta(
    'idTempo',
  );
  @override
  late final GeneratedColumn<int> idTempo = GeneratedColumn<int>(
    'id_tempo',
    aliasedName,
    true,
    type: DriftSqlType.int,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _idClienteMeta = const VerificationMeta(
    'idCliente',
  );
  @override
  late final GeneratedColumn<int> idCliente = GeneratedColumn<int>(
    'id_cliente',
    aliasedName,
    true,
    type: DriftSqlType.int,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _idVendedorMeta = const VerificationMeta(
    'idVendedor',
  );
  @override
  late final GeneratedColumn<int> idVendedor = GeneratedColumn<int>(
    'id_vendedor',
    aliasedName,
    true,
    type: DriftSqlType.int,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _idProdutoMeta = const VerificationMeta(
    'idProduto',
  );
  @override
  late final GeneratedColumn<int> idProduto = GeneratedColumn<int>(
    'id_produto',
    aliasedName,
    true,
    type: DriftSqlType.int,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _quantidadeMeta = const VerificationMeta(
    'quantidade',
  );
  @override
  late final GeneratedColumn<double> quantidade = GeneratedColumn<double>(
    'quantidade',
    aliasedName,
    true,
    type: DriftSqlType.double,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _valorTotalMeta = const VerificationMeta(
    'valorTotal',
  );
  @override
  late final GeneratedColumn<double> valorTotal = GeneratedColumn<double>(
    'valor_total',
    aliasedName,
    true,
    type: DriftSqlType.double,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _custoTotalMeta = const VerificationMeta(
    'custoTotal',
  );
  @override
  late final GeneratedColumn<double> custoTotal = GeneratedColumn<double>(
    'custo_total',
    aliasedName,
    true,
    type: DriftSqlType.double,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _lucroMeta = const VerificationMeta('lucro');
  @override
  late final GeneratedColumn<double> lucro = GeneratedColumn<double>(
    'lucro',
    aliasedName,
    true,
    type: DriftSqlType.double,
    requiredDuringInsert: false,
  );
  @override
  List<GeneratedColumn> get $columns => [
    id,
    idTempo,
    idCliente,
    idVendedor,
    idProduto,
    quantidade,
    valorTotal,
    custoTotal,
    lucro,
  ];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'fato_venda';
  @override
  VerificationContext validateIntegrity(
    Insertable<FatoVenda> instance, {
    bool isInserting = false,
  }) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('id_tempo')) {
      context.handle(
        _idTempoMeta,
        idTempo.isAcceptableOrUnknown(data['id_tempo']!, _idTempoMeta),
      );
    }
    if (data.containsKey('id_cliente')) {
      context.handle(
        _idClienteMeta,
        idCliente.isAcceptableOrUnknown(data['id_cliente']!, _idClienteMeta),
      );
    }
    if (data.containsKey('id_vendedor')) {
      context.handle(
        _idVendedorMeta,
        idVendedor.isAcceptableOrUnknown(data['id_vendedor']!, _idVendedorMeta),
      );
    }
    if (data.containsKey('id_produto')) {
      context.handle(
        _idProdutoMeta,
        idProduto.isAcceptableOrUnknown(data['id_produto']!, _idProdutoMeta),
      );
    }
    if (data.containsKey('quantidade')) {
      context.handle(
        _quantidadeMeta,
        quantidade.isAcceptableOrUnknown(data['quantidade']!, _quantidadeMeta),
      );
    }
    if (data.containsKey('valor_total')) {
      context.handle(
        _valorTotalMeta,
        valorTotal.isAcceptableOrUnknown(data['valor_total']!, _valorTotalMeta),
      );
    }
    if (data.containsKey('custo_total')) {
      context.handle(
        _custoTotalMeta,
        custoTotal.isAcceptableOrUnknown(data['custo_total']!, _custoTotalMeta),
      );
    }
    if (data.containsKey('lucro')) {
      context.handle(
        _lucroMeta,
        lucro.isAcceptableOrUnknown(data['lucro']!, _lucroMeta),
      );
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  FatoVenda map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return FatoVenda(
      id: attachedDatabase.typeMapping.read(
        DriftSqlType.int,
        data['${effectivePrefix}id'],
      ),
      idTempo: attachedDatabase.typeMapping.read(
        DriftSqlType.int,
        data['${effectivePrefix}id_tempo'],
      ),
      idCliente: attachedDatabase.typeMapping.read(
        DriftSqlType.int,
        data['${effectivePrefix}id_cliente'],
      ),
      idVendedor: attachedDatabase.typeMapping.read(
        DriftSqlType.int,
        data['${effectivePrefix}id_vendedor'],
      ),
      idProduto: attachedDatabase.typeMapping.read(
        DriftSqlType.int,
        data['${effectivePrefix}id_produto'],
      ),
      quantidade: attachedDatabase.typeMapping.read(
        DriftSqlType.double,
        data['${effectivePrefix}quantidade'],
      ),
      valorTotal: attachedDatabase.typeMapping.read(
        DriftSqlType.double,
        data['${effectivePrefix}valor_total'],
      ),
      custoTotal: attachedDatabase.typeMapping.read(
        DriftSqlType.double,
        data['${effectivePrefix}custo_total'],
      ),
      lucro: attachedDatabase.typeMapping.read(
        DriftSqlType.double,
        data['${effectivePrefix}lucro'],
      ),
    );
  }

  @override
  $FatoVendasTable createAlias(String alias) {
    return $FatoVendasTable(attachedDatabase, alias);
  }
}

class FatoVenda extends DataClass implements Insertable<FatoVenda> {
  final int? id;
  final int? idTempo;
  final int? idCliente;
  final int? idVendedor;
  final int? idProduto;
  final double? quantidade;
  final double? valorTotal;
  final double? custoTotal;
  final double? lucro;
  const FatoVenda({
    this.id,
    this.idTempo,
    this.idCliente,
    this.idVendedor,
    this.idProduto,
    this.quantidade,
    this.valorTotal,
    this.custoTotal,
    this.lucro,
  });
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || idTempo != null) {
      map['id_tempo'] = Variable<int>(idTempo);
    }
    if (!nullToAbsent || idCliente != null) {
      map['id_cliente'] = Variable<int>(idCliente);
    }
    if (!nullToAbsent || idVendedor != null) {
      map['id_vendedor'] = Variable<int>(idVendedor);
    }
    if (!nullToAbsent || idProduto != null) {
      map['id_produto'] = Variable<int>(idProduto);
    }
    if (!nullToAbsent || quantidade != null) {
      map['quantidade'] = Variable<double>(quantidade);
    }
    if (!nullToAbsent || valorTotal != null) {
      map['valor_total'] = Variable<double>(valorTotal);
    }
    if (!nullToAbsent || custoTotal != null) {
      map['custo_total'] = Variable<double>(custoTotal);
    }
    if (!nullToAbsent || lucro != null) {
      map['lucro'] = Variable<double>(lucro);
    }
    return map;
  }

  factory FatoVenda.fromJson(
    Map<String, dynamic> json, {
    ValueSerializer? serializer,
  }) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return FatoVenda(
      id: serializer.fromJson<int?>(json['id']),
      idTempo: serializer.fromJson<int?>(json['idTempo']),
      idCliente: serializer.fromJson<int?>(json['idCliente']),
      idVendedor: serializer.fromJson<int?>(json['idVendedor']),
      idProduto: serializer.fromJson<int?>(json['idProduto']),
      quantidade: serializer.fromJson<double?>(json['quantidade']),
      valorTotal: serializer.fromJson<double?>(json['valorTotal']),
      custoTotal: serializer.fromJson<double?>(json['custoTotal']),
      lucro: serializer.fromJson<double?>(json['lucro']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'idTempo': serializer.toJson<int?>(idTempo),
      'idCliente': serializer.toJson<int?>(idCliente),
      'idVendedor': serializer.toJson<int?>(idVendedor),
      'idProduto': serializer.toJson<int?>(idProduto),
      'quantidade': serializer.toJson<double?>(quantidade),
      'valorTotal': serializer.toJson<double?>(valorTotal),
      'custoTotal': serializer.toJson<double?>(custoTotal),
      'lucro': serializer.toJson<double?>(lucro),
    };
  }

  FatoVenda copyWith({
    Value<int?> id = const Value.absent(),
    Value<int?> idTempo = const Value.absent(),
    Value<int?> idCliente = const Value.absent(),
    Value<int?> idVendedor = const Value.absent(),
    Value<int?> idProduto = const Value.absent(),
    Value<double?> quantidade = const Value.absent(),
    Value<double?> valorTotal = const Value.absent(),
    Value<double?> custoTotal = const Value.absent(),
    Value<double?> lucro = const Value.absent(),
  }) => FatoVenda(
    id: id.present ? id.value : this.id,
    idTempo: idTempo.present ? idTempo.value : this.idTempo,
    idCliente: idCliente.present ? idCliente.value : this.idCliente,
    idVendedor: idVendedor.present ? idVendedor.value : this.idVendedor,
    idProduto: idProduto.present ? idProduto.value : this.idProduto,
    quantidade: quantidade.present ? quantidade.value : this.quantidade,
    valorTotal: valorTotal.present ? valorTotal.value : this.valorTotal,
    custoTotal: custoTotal.present ? custoTotal.value : this.custoTotal,
    lucro: lucro.present ? lucro.value : this.lucro,
  );
  FatoVenda copyWithCompanion(FatoVendasCompanion data) {
    return FatoVenda(
      id: data.id.present ? data.id.value : this.id,
      idTempo: data.idTempo.present ? data.idTempo.value : this.idTempo,
      idCliente: data.idCliente.present ? data.idCliente.value : this.idCliente,
      idVendedor:
          data.idVendedor.present ? data.idVendedor.value : this.idVendedor,
      idProduto: data.idProduto.present ? data.idProduto.value : this.idProduto,
      quantidade:
          data.quantidade.present ? data.quantidade.value : this.quantidade,
      valorTotal:
          data.valorTotal.present ? data.valorTotal.value : this.valorTotal,
      custoTotal:
          data.custoTotal.present ? data.custoTotal.value : this.custoTotal,
      lucro: data.lucro.present ? data.lucro.value : this.lucro,
    );
  }

  @override
  String toString() {
    return (StringBuffer('FatoVenda(')
          ..write('id: $id, ')
          ..write('idTempo: $idTempo, ')
          ..write('idCliente: $idCliente, ')
          ..write('idVendedor: $idVendedor, ')
          ..write('idProduto: $idProduto, ')
          ..write('quantidade: $quantidade, ')
          ..write('valorTotal: $valorTotal, ')
          ..write('custoTotal: $custoTotal, ')
          ..write('lucro: $lucro')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(
    id,
    idTempo,
    idCliente,
    idVendedor,
    idProduto,
    quantidade,
    valorTotal,
    custoTotal,
    lucro,
  );
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is FatoVenda &&
          other.id == this.id &&
          other.idTempo == this.idTempo &&
          other.idCliente == this.idCliente &&
          other.idVendedor == this.idVendedor &&
          other.idProduto == this.idProduto &&
          other.quantidade == this.quantidade &&
          other.valorTotal == this.valorTotal &&
          other.custoTotal == this.custoTotal &&
          other.lucro == this.lucro);
}

class FatoVendasCompanion extends UpdateCompanion<FatoVenda> {
  final Value<int?> id;
  final Value<int?> idTempo;
  final Value<int?> idCliente;
  final Value<int?> idVendedor;
  final Value<int?> idProduto;
  final Value<double?> quantidade;
  final Value<double?> valorTotal;
  final Value<double?> custoTotal;
  final Value<double?> lucro;
  const FatoVendasCompanion({
    this.id = const Value.absent(),
    this.idTempo = const Value.absent(),
    this.idCliente = const Value.absent(),
    this.idVendedor = const Value.absent(),
    this.idProduto = const Value.absent(),
    this.quantidade = const Value.absent(),
    this.valorTotal = const Value.absent(),
    this.custoTotal = const Value.absent(),
    this.lucro = const Value.absent(),
  });
  FatoVendasCompanion.insert({
    this.id = const Value.absent(),
    this.idTempo = const Value.absent(),
    this.idCliente = const Value.absent(),
    this.idVendedor = const Value.absent(),
    this.idProduto = const Value.absent(),
    this.quantidade = const Value.absent(),
    this.valorTotal = const Value.absent(),
    this.custoTotal = const Value.absent(),
    this.lucro = const Value.absent(),
  });
  static Insertable<FatoVenda> custom({
    Expression<int>? id,
    Expression<int>? idTempo,
    Expression<int>? idCliente,
    Expression<int>? idVendedor,
    Expression<int>? idProduto,
    Expression<double>? quantidade,
    Expression<double>? valorTotal,
    Expression<double>? custoTotal,
    Expression<double>? lucro,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (idTempo != null) 'id_tempo': idTempo,
      if (idCliente != null) 'id_cliente': idCliente,
      if (idVendedor != null) 'id_vendedor': idVendedor,
      if (idProduto != null) 'id_produto': idProduto,
      if (quantidade != null) 'quantidade': quantidade,
      if (valorTotal != null) 'valor_total': valorTotal,
      if (custoTotal != null) 'custo_total': custoTotal,
      if (lucro != null) 'lucro': lucro,
    });
  }

  FatoVendasCompanion copyWith({
    Value<int?>? id,
    Value<int?>? idTempo,
    Value<int?>? idCliente,
    Value<int?>? idVendedor,
    Value<int?>? idProduto,
    Value<double?>? quantidade,
    Value<double?>? valorTotal,
    Value<double?>? custoTotal,
    Value<double?>? lucro,
  }) {
    return FatoVendasCompanion(
      id: id ?? this.id,
      idTempo: idTempo ?? this.idTempo,
      idCliente: idCliente ?? this.idCliente,
      idVendedor: idVendedor ?? this.idVendedor,
      idProduto: idProduto ?? this.idProduto,
      quantidade: quantidade ?? this.quantidade,
      valorTotal: valorTotal ?? this.valorTotal,
      custoTotal: custoTotal ?? this.custoTotal,
      lucro: lucro ?? this.lucro,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (idTempo.present) {
      map['id_tempo'] = Variable<int>(idTempo.value);
    }
    if (idCliente.present) {
      map['id_cliente'] = Variable<int>(idCliente.value);
    }
    if (idVendedor.present) {
      map['id_vendedor'] = Variable<int>(idVendedor.value);
    }
    if (idProduto.present) {
      map['id_produto'] = Variable<int>(idProduto.value);
    }
    if (quantidade.present) {
      map['quantidade'] = Variable<double>(quantidade.value);
    }
    if (valorTotal.present) {
      map['valor_total'] = Variable<double>(valorTotal.value);
    }
    if (custoTotal.present) {
      map['custo_total'] = Variable<double>(custoTotal.value);
    }
    if (lucro.present) {
      map['lucro'] = Variable<double>(lucro.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('FatoVendasCompanion(')
          ..write('id: $id, ')
          ..write('idTempo: $idTempo, ')
          ..write('idCliente: $idCliente, ')
          ..write('idVendedor: $idVendedor, ')
          ..write('idProduto: $idProduto, ')
          ..write('quantidade: $quantidade, ')
          ..write('valorTotal: $valorTotal, ')
          ..write('custoTotal: $custoTotal, ')
          ..write('lucro: $lucro')
          ..write(')'))
        .toString();
  }
}

class $FatoRecebimentosTable extends FatoRecebimentos
    with TableInfo<$FatoRecebimentosTable, FatoRecebimento> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $FatoRecebimentosTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _idMeta = const VerificationMeta('id');
  @override
  late final GeneratedColumn<int> id = GeneratedColumn<int>(
    'id',
    aliasedName,
    true,
    type: DriftSqlType.int,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _idTempoMeta = const VerificationMeta(
    'idTempo',
  );
  @override
  late final GeneratedColumn<int> idTempo = GeneratedColumn<int>(
    'id_tempo',
    aliasedName,
    true,
    type: DriftSqlType.int,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _idClienteMeta = const VerificationMeta(
    'idCliente',
  );
  @override
  late final GeneratedColumn<int> idCliente = GeneratedColumn<int>(
    'id_cliente',
    aliasedName,
    true,
    type: DriftSqlType.int,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _valorRecebidoMeta = const VerificationMeta(
    'valorRecebido',
  );
  @override
  late final GeneratedColumn<double> valorRecebido = GeneratedColumn<double>(
    'valor_recebido',
    aliasedName,
    true,
    type: DriftSqlType.double,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _valorEmAbertoMeta = const VerificationMeta(
    'valorEmAberto',
  );
  @override
  late final GeneratedColumn<double> valorEmAberto = GeneratedColumn<double>(
    'valor_em_aberto',
    aliasedName,
    true,
    type: DriftSqlType.double,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _atrasoDiasMeta = const VerificationMeta(
    'atrasoDias',
  );
  @override
  late final GeneratedColumn<int> atrasoDias = GeneratedColumn<int>(
    'atraso_dias',
    aliasedName,
    true,
    type: DriftSqlType.int,
    requiredDuringInsert: false,
  );
  @override
  List<GeneratedColumn> get $columns => [
    id,
    idTempo,
    idCliente,
    valorRecebido,
    valorEmAberto,
    atrasoDias,
  ];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'fato_recebimento';
  @override
  VerificationContext validateIntegrity(
    Insertable<FatoRecebimento> instance, {
    bool isInserting = false,
  }) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('id')) {
      context.handle(_idMeta, id.isAcceptableOrUnknown(data['id']!, _idMeta));
    }
    if (data.containsKey('id_tempo')) {
      context.handle(
        _idTempoMeta,
        idTempo.isAcceptableOrUnknown(data['id_tempo']!, _idTempoMeta),
      );
    }
    if (data.containsKey('id_cliente')) {
      context.handle(
        _idClienteMeta,
        idCliente.isAcceptableOrUnknown(data['id_cliente']!, _idClienteMeta),
      );
    }
    if (data.containsKey('valor_recebido')) {
      context.handle(
        _valorRecebidoMeta,
        valorRecebido.isAcceptableOrUnknown(
          data['valor_recebido']!,
          _valorRecebidoMeta,
        ),
      );
    }
    if (data.containsKey('valor_em_aberto')) {
      context.handle(
        _valorEmAbertoMeta,
        valorEmAberto.isAcceptableOrUnknown(
          data['valor_em_aberto']!,
          _valorEmAbertoMeta,
        ),
      );
    }
    if (data.containsKey('atraso_dias')) {
      context.handle(
        _atrasoDiasMeta,
        atrasoDias.isAcceptableOrUnknown(data['atraso_dias']!, _atrasoDiasMeta),
      );
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {id};
  @override
  FatoRecebimento map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return FatoRecebimento(
      id: attachedDatabase.typeMapping.read(
        DriftSqlType.int,
        data['${effectivePrefix}id'],
      ),
      idTempo: attachedDatabase.typeMapping.read(
        DriftSqlType.int,
        data['${effectivePrefix}id_tempo'],
      ),
      idCliente: attachedDatabase.typeMapping.read(
        DriftSqlType.int,
        data['${effectivePrefix}id_cliente'],
      ),
      valorRecebido: attachedDatabase.typeMapping.read(
        DriftSqlType.double,
        data['${effectivePrefix}valor_recebido'],
      ),
      valorEmAberto: attachedDatabase.typeMapping.read(
        DriftSqlType.double,
        data['${effectivePrefix}valor_em_aberto'],
      ),
      atrasoDias: attachedDatabase.typeMapping.read(
        DriftSqlType.int,
        data['${effectivePrefix}atraso_dias'],
      ),
    );
  }

  @override
  $FatoRecebimentosTable createAlias(String alias) {
    return $FatoRecebimentosTable(attachedDatabase, alias);
  }
}

class FatoRecebimento extends DataClass implements Insertable<FatoRecebimento> {
  final int? id;
  final int? idTempo;
  final int? idCliente;
  final double? valorRecebido;
  final double? valorEmAberto;
  final int? atrasoDias;
  const FatoRecebimento({
    this.id,
    this.idTempo,
    this.idCliente,
    this.valorRecebido,
    this.valorEmAberto,
    this.atrasoDias,
  });
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (!nullToAbsent || id != null) {
      map['id'] = Variable<int>(id);
    }
    if (!nullToAbsent || idTempo != null) {
      map['id_tempo'] = Variable<int>(idTempo);
    }
    if (!nullToAbsent || idCliente != null) {
      map['id_cliente'] = Variable<int>(idCliente);
    }
    if (!nullToAbsent || valorRecebido != null) {
      map['valor_recebido'] = Variable<double>(valorRecebido);
    }
    if (!nullToAbsent || valorEmAberto != null) {
      map['valor_em_aberto'] = Variable<double>(valorEmAberto);
    }
    if (!nullToAbsent || atrasoDias != null) {
      map['atraso_dias'] = Variable<int>(atrasoDias);
    }
    return map;
  }

  factory FatoRecebimento.fromJson(
    Map<String, dynamic> json, {
    ValueSerializer? serializer,
  }) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return FatoRecebimento(
      id: serializer.fromJson<int?>(json['id']),
      idTempo: serializer.fromJson<int?>(json['idTempo']),
      idCliente: serializer.fromJson<int?>(json['idCliente']),
      valorRecebido: serializer.fromJson<double?>(json['valorRecebido']),
      valorEmAberto: serializer.fromJson<double?>(json['valorEmAberto']),
      atrasoDias: serializer.fromJson<int?>(json['atrasoDias']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'id': serializer.toJson<int?>(id),
      'idTempo': serializer.toJson<int?>(idTempo),
      'idCliente': serializer.toJson<int?>(idCliente),
      'valorRecebido': serializer.toJson<double?>(valorRecebido),
      'valorEmAberto': serializer.toJson<double?>(valorEmAberto),
      'atrasoDias': serializer.toJson<int?>(atrasoDias),
    };
  }

  FatoRecebimento copyWith({
    Value<int?> id = const Value.absent(),
    Value<int?> idTempo = const Value.absent(),
    Value<int?> idCliente = const Value.absent(),
    Value<double?> valorRecebido = const Value.absent(),
    Value<double?> valorEmAberto = const Value.absent(),
    Value<int?> atrasoDias = const Value.absent(),
  }) => FatoRecebimento(
    id: id.present ? id.value : this.id,
    idTempo: idTempo.present ? idTempo.value : this.idTempo,
    idCliente: idCliente.present ? idCliente.value : this.idCliente,
    valorRecebido:
        valorRecebido.present ? valorRecebido.value : this.valorRecebido,
    valorEmAberto:
        valorEmAberto.present ? valorEmAberto.value : this.valorEmAberto,
    atrasoDias: atrasoDias.present ? atrasoDias.value : this.atrasoDias,
  );
  FatoRecebimento copyWithCompanion(FatoRecebimentosCompanion data) {
    return FatoRecebimento(
      id: data.id.present ? data.id.value : this.id,
      idTempo: data.idTempo.present ? data.idTempo.value : this.idTempo,
      idCliente: data.idCliente.present ? data.idCliente.value : this.idCliente,
      valorRecebido:
          data.valorRecebido.present
              ? data.valorRecebido.value
              : this.valorRecebido,
      valorEmAberto:
          data.valorEmAberto.present
              ? data.valorEmAberto.value
              : this.valorEmAberto,
      atrasoDias:
          data.atrasoDias.present ? data.atrasoDias.value : this.atrasoDias,
    );
  }

  @override
  String toString() {
    return (StringBuffer('FatoRecebimento(')
          ..write('id: $id, ')
          ..write('idTempo: $idTempo, ')
          ..write('idCliente: $idCliente, ')
          ..write('valorRecebido: $valorRecebido, ')
          ..write('valorEmAberto: $valorEmAberto, ')
          ..write('atrasoDias: $atrasoDias')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(
    id,
    idTempo,
    idCliente,
    valorRecebido,
    valorEmAberto,
    atrasoDias,
  );
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is FatoRecebimento &&
          other.id == this.id &&
          other.idTempo == this.idTempo &&
          other.idCliente == this.idCliente &&
          other.valorRecebido == this.valorRecebido &&
          other.valorEmAberto == this.valorEmAberto &&
          other.atrasoDias == this.atrasoDias);
}

class FatoRecebimentosCompanion extends UpdateCompanion<FatoRecebimento> {
  final Value<int?> id;
  final Value<int?> idTempo;
  final Value<int?> idCliente;
  final Value<double?> valorRecebido;
  final Value<double?> valorEmAberto;
  final Value<int?> atrasoDias;
  const FatoRecebimentosCompanion({
    this.id = const Value.absent(),
    this.idTempo = const Value.absent(),
    this.idCliente = const Value.absent(),
    this.valorRecebido = const Value.absent(),
    this.valorEmAberto = const Value.absent(),
    this.atrasoDias = const Value.absent(),
  });
  FatoRecebimentosCompanion.insert({
    this.id = const Value.absent(),
    this.idTempo = const Value.absent(),
    this.idCliente = const Value.absent(),
    this.valorRecebido = const Value.absent(),
    this.valorEmAberto = const Value.absent(),
    this.atrasoDias = const Value.absent(),
  });
  static Insertable<FatoRecebimento> custom({
    Expression<int>? id,
    Expression<int>? idTempo,
    Expression<int>? idCliente,
    Expression<double>? valorRecebido,
    Expression<double>? valorEmAberto,
    Expression<int>? atrasoDias,
  }) {
    return RawValuesInsertable({
      if (id != null) 'id': id,
      if (idTempo != null) 'id_tempo': idTempo,
      if (idCliente != null) 'id_cliente': idCliente,
      if (valorRecebido != null) 'valor_recebido': valorRecebido,
      if (valorEmAberto != null) 'valor_em_aberto': valorEmAberto,
      if (atrasoDias != null) 'atraso_dias': atrasoDias,
    });
  }

  FatoRecebimentosCompanion copyWith({
    Value<int?>? id,
    Value<int?>? idTempo,
    Value<int?>? idCliente,
    Value<double?>? valorRecebido,
    Value<double?>? valorEmAberto,
    Value<int?>? atrasoDias,
  }) {
    return FatoRecebimentosCompanion(
      id: id ?? this.id,
      idTempo: idTempo ?? this.idTempo,
      idCliente: idCliente ?? this.idCliente,
      valorRecebido: valorRecebido ?? this.valorRecebido,
      valorEmAberto: valorEmAberto ?? this.valorEmAberto,
      atrasoDias: atrasoDias ?? this.atrasoDias,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (id.present) {
      map['id'] = Variable<int>(id.value);
    }
    if (idTempo.present) {
      map['id_tempo'] = Variable<int>(idTempo.value);
    }
    if (idCliente.present) {
      map['id_cliente'] = Variable<int>(idCliente.value);
    }
    if (valorRecebido.present) {
      map['valor_recebido'] = Variable<double>(valorRecebido.value);
    }
    if (valorEmAberto.present) {
      map['valor_em_aberto'] = Variable<double>(valorEmAberto.value);
    }
    if (atrasoDias.present) {
      map['atraso_dias'] = Variable<int>(atrasoDias.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('FatoRecebimentosCompanion(')
          ..write('id: $id, ')
          ..write('idTempo: $idTempo, ')
          ..write('idCliente: $idCliente, ')
          ..write('valorRecebido: $valorRecebido, ')
          ..write('valorEmAberto: $valorEmAberto, ')
          ..write('atrasoDias: $atrasoDias')
          ..write(')'))
        .toString();
  }
}

abstract class _$AppDatabase extends GeneratedDatabase {
  _$AppDatabase(QueryExecutor e) : super(e);
  $AppDatabaseManager get managers => $AppDatabaseManager(this);
  late final $DimTemposTable dimTempos = $DimTemposTable(this);
  late final $DimClientesTable dimClientes = $DimClientesTable(this);
  late final $DimVendedorsTable dimVendedors = $DimVendedorsTable(this);
  late final $DimProdutosTable dimProdutos = $DimProdutosTable(this);
  late final $FatoVendasTable fatoVendas = $FatoVendasTable(this);
  late final $FatoRecebimentosTable fatoRecebimentos = $FatoRecebimentosTable(
    this,
  );
  late final DimTempoDao dimTempoDao = DimTempoDao(this as AppDatabase);
  late final DimClienteDao dimClienteDao = DimClienteDao(this as AppDatabase);
  late final DimVendedorDao dimVendedorDao = DimVendedorDao(
    this as AppDatabase,
  );
  late final DimProdutoDao dimProdutoDao = DimProdutoDao(this as AppDatabase);
  late final FatoVendaDao fatoVendaDao = FatoVendaDao(this as AppDatabase);
  late final FatoRecebimentoDao fatoRecebimentoDao = FatoRecebimentoDao(
    this as AppDatabase,
  );
  @override
  Iterable<TableInfo<Table, Object?>> get allTables =>
      allSchemaEntities.whereType<TableInfo<Table, Object?>>();
  @override
  List<DatabaseSchemaEntity> get allSchemaEntities => [
    dimTempos,
    dimClientes,
    dimVendedors,
    dimProdutos,
    fatoVendas,
    fatoRecebimentos,
  ];
}

typedef $$DimTemposTableCreateCompanionBuilder =
    DimTemposCompanion Function({
      Value<int?> id,
      Value<DateTime?> data,
      Value<int?> ano,
      Value<int?> mes,
      Value<String?> nomeMes,
      Value<int?> trimestre,
      Value<int?> dia,
      Value<int?> diaSemana,
    });
typedef $$DimTemposTableUpdateCompanionBuilder =
    DimTemposCompanion Function({
      Value<int?> id,
      Value<DateTime?> data,
      Value<int?> ano,
      Value<int?> mes,
      Value<String?> nomeMes,
      Value<int?> trimestre,
      Value<int?> dia,
      Value<int?> diaSemana,
    });

class $$DimTemposTableFilterComposer
    extends Composer<_$AppDatabase, $DimTemposTable> {
  $$DimTemposTableFilterComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnFilters<int> get id => $composableBuilder(
    column: $table.id,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<DateTime> get data => $composableBuilder(
    column: $table.data,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<int> get ano => $composableBuilder(
    column: $table.ano,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<int> get mes => $composableBuilder(
    column: $table.mes,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get nomeMes => $composableBuilder(
    column: $table.nomeMes,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<int> get trimestre => $composableBuilder(
    column: $table.trimestre,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<int> get dia => $composableBuilder(
    column: $table.dia,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<int> get diaSemana => $composableBuilder(
    column: $table.diaSemana,
    builder: (column) => ColumnFilters(column),
  );
}

class $$DimTemposTableOrderingComposer
    extends Composer<_$AppDatabase, $DimTemposTable> {
  $$DimTemposTableOrderingComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnOrderings<int> get id => $composableBuilder(
    column: $table.id,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<DateTime> get data => $composableBuilder(
    column: $table.data,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<int> get ano => $composableBuilder(
    column: $table.ano,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<int> get mes => $composableBuilder(
    column: $table.mes,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get nomeMes => $composableBuilder(
    column: $table.nomeMes,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<int> get trimestre => $composableBuilder(
    column: $table.trimestre,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<int> get dia => $composableBuilder(
    column: $table.dia,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<int> get diaSemana => $composableBuilder(
    column: $table.diaSemana,
    builder: (column) => ColumnOrderings(column),
  );
}

class $$DimTemposTableAnnotationComposer
    extends Composer<_$AppDatabase, $DimTemposTable> {
  $$DimTemposTableAnnotationComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  GeneratedColumn<int> get id =>
      $composableBuilder(column: $table.id, builder: (column) => column);

  GeneratedColumn<DateTime> get data =>
      $composableBuilder(column: $table.data, builder: (column) => column);

  GeneratedColumn<int> get ano =>
      $composableBuilder(column: $table.ano, builder: (column) => column);

  GeneratedColumn<int> get mes =>
      $composableBuilder(column: $table.mes, builder: (column) => column);

  GeneratedColumn<String> get nomeMes =>
      $composableBuilder(column: $table.nomeMes, builder: (column) => column);

  GeneratedColumn<int> get trimestre =>
      $composableBuilder(column: $table.trimestre, builder: (column) => column);

  GeneratedColumn<int> get dia =>
      $composableBuilder(column: $table.dia, builder: (column) => column);

  GeneratedColumn<int> get diaSemana =>
      $composableBuilder(column: $table.diaSemana, builder: (column) => column);
}

class $$DimTemposTableTableManager
    extends
        RootTableManager<
          _$AppDatabase,
          $DimTemposTable,
          DimTempo,
          $$DimTemposTableFilterComposer,
          $$DimTemposTableOrderingComposer,
          $$DimTemposTableAnnotationComposer,
          $$DimTemposTableCreateCompanionBuilder,
          $$DimTemposTableUpdateCompanionBuilder,
          (DimTempo, BaseReferences<_$AppDatabase, $DimTemposTable, DimTempo>),
          DimTempo,
          PrefetchHooks Function()
        > {
  $$DimTemposTableTableManager(_$AppDatabase db, $DimTemposTable table)
    : super(
        TableManagerState(
          db: db,
          table: table,
          createFilteringComposer:
              () => $$DimTemposTableFilterComposer($db: db, $table: table),
          createOrderingComposer:
              () => $$DimTemposTableOrderingComposer($db: db, $table: table),
          createComputedFieldComposer:
              () => $$DimTemposTableAnnotationComposer($db: db, $table: table),
          updateCompanionCallback:
              ({
                Value<int?> id = const Value.absent(),
                Value<DateTime?> data = const Value.absent(),
                Value<int?> ano = const Value.absent(),
                Value<int?> mes = const Value.absent(),
                Value<String?> nomeMes = const Value.absent(),
                Value<int?> trimestre = const Value.absent(),
                Value<int?> dia = const Value.absent(),
                Value<int?> diaSemana = const Value.absent(),
              }) => DimTemposCompanion(
                id: id,
                data: data,
                ano: ano,
                mes: mes,
                nomeMes: nomeMes,
                trimestre: trimestre,
                dia: dia,
                diaSemana: diaSemana,
              ),
          createCompanionCallback:
              ({
                Value<int?> id = const Value.absent(),
                Value<DateTime?> data = const Value.absent(),
                Value<int?> ano = const Value.absent(),
                Value<int?> mes = const Value.absent(),
                Value<String?> nomeMes = const Value.absent(),
                Value<int?> trimestre = const Value.absent(),
                Value<int?> dia = const Value.absent(),
                Value<int?> diaSemana = const Value.absent(),
              }) => DimTemposCompanion.insert(
                id: id,
                data: data,
                ano: ano,
                mes: mes,
                nomeMes: nomeMes,
                trimestre: trimestre,
                dia: dia,
                diaSemana: diaSemana,
              ),
          withReferenceMapper:
              (p0) =>
                  p0
                      .map(
                        (e) => (
                          e.readTable(table),
                          BaseReferences(db, table, e),
                        ),
                      )
                      .toList(),
          prefetchHooksCallback: null,
        ),
      );
}

typedef $$DimTemposTableProcessedTableManager =
    ProcessedTableManager<
      _$AppDatabase,
      $DimTemposTable,
      DimTempo,
      $$DimTemposTableFilterComposer,
      $$DimTemposTableOrderingComposer,
      $$DimTemposTableAnnotationComposer,
      $$DimTemposTableCreateCompanionBuilder,
      $$DimTemposTableUpdateCompanionBuilder,
      (DimTempo, BaseReferences<_$AppDatabase, $DimTemposTable, DimTempo>),
      DimTempo,
      PrefetchHooks Function()
    >;
typedef $$DimClientesTableCreateCompanionBuilder =
    DimClientesCompanion Function({
      Value<int?> id,
      Value<String?> nomeCliente,
      Value<String?> tipoCliente,
      Value<String?> cidade,
      Value<String?> estado,
      Value<String?> segmento,
    });
typedef $$DimClientesTableUpdateCompanionBuilder =
    DimClientesCompanion Function({
      Value<int?> id,
      Value<String?> nomeCliente,
      Value<String?> tipoCliente,
      Value<String?> cidade,
      Value<String?> estado,
      Value<String?> segmento,
    });

class $$DimClientesTableFilterComposer
    extends Composer<_$AppDatabase, $DimClientesTable> {
  $$DimClientesTableFilterComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnFilters<int> get id => $composableBuilder(
    column: $table.id,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get nomeCliente => $composableBuilder(
    column: $table.nomeCliente,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get tipoCliente => $composableBuilder(
    column: $table.tipoCliente,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get cidade => $composableBuilder(
    column: $table.cidade,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get estado => $composableBuilder(
    column: $table.estado,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get segmento => $composableBuilder(
    column: $table.segmento,
    builder: (column) => ColumnFilters(column),
  );
}

class $$DimClientesTableOrderingComposer
    extends Composer<_$AppDatabase, $DimClientesTable> {
  $$DimClientesTableOrderingComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnOrderings<int> get id => $composableBuilder(
    column: $table.id,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get nomeCliente => $composableBuilder(
    column: $table.nomeCliente,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get tipoCliente => $composableBuilder(
    column: $table.tipoCliente,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get cidade => $composableBuilder(
    column: $table.cidade,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get estado => $composableBuilder(
    column: $table.estado,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get segmento => $composableBuilder(
    column: $table.segmento,
    builder: (column) => ColumnOrderings(column),
  );
}

class $$DimClientesTableAnnotationComposer
    extends Composer<_$AppDatabase, $DimClientesTable> {
  $$DimClientesTableAnnotationComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  GeneratedColumn<int> get id =>
      $composableBuilder(column: $table.id, builder: (column) => column);

  GeneratedColumn<String> get nomeCliente => $composableBuilder(
    column: $table.nomeCliente,
    builder: (column) => column,
  );

  GeneratedColumn<String> get tipoCliente => $composableBuilder(
    column: $table.tipoCliente,
    builder: (column) => column,
  );

  GeneratedColumn<String> get cidade =>
      $composableBuilder(column: $table.cidade, builder: (column) => column);

  GeneratedColumn<String> get estado =>
      $composableBuilder(column: $table.estado, builder: (column) => column);

  GeneratedColumn<String> get segmento =>
      $composableBuilder(column: $table.segmento, builder: (column) => column);
}

class $$DimClientesTableTableManager
    extends
        RootTableManager<
          _$AppDatabase,
          $DimClientesTable,
          DimCliente,
          $$DimClientesTableFilterComposer,
          $$DimClientesTableOrderingComposer,
          $$DimClientesTableAnnotationComposer,
          $$DimClientesTableCreateCompanionBuilder,
          $$DimClientesTableUpdateCompanionBuilder,
          (
            DimCliente,
            BaseReferences<_$AppDatabase, $DimClientesTable, DimCliente>,
          ),
          DimCliente,
          PrefetchHooks Function()
        > {
  $$DimClientesTableTableManager(_$AppDatabase db, $DimClientesTable table)
    : super(
        TableManagerState(
          db: db,
          table: table,
          createFilteringComposer:
              () => $$DimClientesTableFilterComposer($db: db, $table: table),
          createOrderingComposer:
              () => $$DimClientesTableOrderingComposer($db: db, $table: table),
          createComputedFieldComposer:
              () =>
                  $$DimClientesTableAnnotationComposer($db: db, $table: table),
          updateCompanionCallback:
              ({
                Value<int?> id = const Value.absent(),
                Value<String?> nomeCliente = const Value.absent(),
                Value<String?> tipoCliente = const Value.absent(),
                Value<String?> cidade = const Value.absent(),
                Value<String?> estado = const Value.absent(),
                Value<String?> segmento = const Value.absent(),
              }) => DimClientesCompanion(
                id: id,
                nomeCliente: nomeCliente,
                tipoCliente: tipoCliente,
                cidade: cidade,
                estado: estado,
                segmento: segmento,
              ),
          createCompanionCallback:
              ({
                Value<int?> id = const Value.absent(),
                Value<String?> nomeCliente = const Value.absent(),
                Value<String?> tipoCliente = const Value.absent(),
                Value<String?> cidade = const Value.absent(),
                Value<String?> estado = const Value.absent(),
                Value<String?> segmento = const Value.absent(),
              }) => DimClientesCompanion.insert(
                id: id,
                nomeCliente: nomeCliente,
                tipoCliente: tipoCliente,
                cidade: cidade,
                estado: estado,
                segmento: segmento,
              ),
          withReferenceMapper:
              (p0) =>
                  p0
                      .map(
                        (e) => (
                          e.readTable(table),
                          BaseReferences(db, table, e),
                        ),
                      )
                      .toList(),
          prefetchHooksCallback: null,
        ),
      );
}

typedef $$DimClientesTableProcessedTableManager =
    ProcessedTableManager<
      _$AppDatabase,
      $DimClientesTable,
      DimCliente,
      $$DimClientesTableFilterComposer,
      $$DimClientesTableOrderingComposer,
      $$DimClientesTableAnnotationComposer,
      $$DimClientesTableCreateCompanionBuilder,
      $$DimClientesTableUpdateCompanionBuilder,
      (
        DimCliente,
        BaseReferences<_$AppDatabase, $DimClientesTable, DimCliente>,
      ),
      DimCliente,
      PrefetchHooks Function()
    >;
typedef $$DimVendedorsTableCreateCompanionBuilder =
    DimVendedorsCompanion Function({
      Value<int?> id,
      Value<String?> nomeVendedor,
      Value<String?> equipe,
      Value<String?> regiao,
    });
typedef $$DimVendedorsTableUpdateCompanionBuilder =
    DimVendedorsCompanion Function({
      Value<int?> id,
      Value<String?> nomeVendedor,
      Value<String?> equipe,
      Value<String?> regiao,
    });

class $$DimVendedorsTableFilterComposer
    extends Composer<_$AppDatabase, $DimVendedorsTable> {
  $$DimVendedorsTableFilterComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnFilters<int> get id => $composableBuilder(
    column: $table.id,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get nomeVendedor => $composableBuilder(
    column: $table.nomeVendedor,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get equipe => $composableBuilder(
    column: $table.equipe,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get regiao => $composableBuilder(
    column: $table.regiao,
    builder: (column) => ColumnFilters(column),
  );
}

class $$DimVendedorsTableOrderingComposer
    extends Composer<_$AppDatabase, $DimVendedorsTable> {
  $$DimVendedorsTableOrderingComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnOrderings<int> get id => $composableBuilder(
    column: $table.id,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get nomeVendedor => $composableBuilder(
    column: $table.nomeVendedor,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get equipe => $composableBuilder(
    column: $table.equipe,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get regiao => $composableBuilder(
    column: $table.regiao,
    builder: (column) => ColumnOrderings(column),
  );
}

class $$DimVendedorsTableAnnotationComposer
    extends Composer<_$AppDatabase, $DimVendedorsTable> {
  $$DimVendedorsTableAnnotationComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  GeneratedColumn<int> get id =>
      $composableBuilder(column: $table.id, builder: (column) => column);

  GeneratedColumn<String> get nomeVendedor => $composableBuilder(
    column: $table.nomeVendedor,
    builder: (column) => column,
  );

  GeneratedColumn<String> get equipe =>
      $composableBuilder(column: $table.equipe, builder: (column) => column);

  GeneratedColumn<String> get regiao =>
      $composableBuilder(column: $table.regiao, builder: (column) => column);
}

class $$DimVendedorsTableTableManager
    extends
        RootTableManager<
          _$AppDatabase,
          $DimVendedorsTable,
          DimVendedor,
          $$DimVendedorsTableFilterComposer,
          $$DimVendedorsTableOrderingComposer,
          $$DimVendedorsTableAnnotationComposer,
          $$DimVendedorsTableCreateCompanionBuilder,
          $$DimVendedorsTableUpdateCompanionBuilder,
          (
            DimVendedor,
            BaseReferences<_$AppDatabase, $DimVendedorsTable, DimVendedor>,
          ),
          DimVendedor,
          PrefetchHooks Function()
        > {
  $$DimVendedorsTableTableManager(_$AppDatabase db, $DimVendedorsTable table)
    : super(
        TableManagerState(
          db: db,
          table: table,
          createFilteringComposer:
              () => $$DimVendedorsTableFilterComposer($db: db, $table: table),
          createOrderingComposer:
              () => $$DimVendedorsTableOrderingComposer($db: db, $table: table),
          createComputedFieldComposer:
              () =>
                  $$DimVendedorsTableAnnotationComposer($db: db, $table: table),
          updateCompanionCallback:
              ({
                Value<int?> id = const Value.absent(),
                Value<String?> nomeVendedor = const Value.absent(),
                Value<String?> equipe = const Value.absent(),
                Value<String?> regiao = const Value.absent(),
              }) => DimVendedorsCompanion(
                id: id,
                nomeVendedor: nomeVendedor,
                equipe: equipe,
                regiao: regiao,
              ),
          createCompanionCallback:
              ({
                Value<int?> id = const Value.absent(),
                Value<String?> nomeVendedor = const Value.absent(),
                Value<String?> equipe = const Value.absent(),
                Value<String?> regiao = const Value.absent(),
              }) => DimVendedorsCompanion.insert(
                id: id,
                nomeVendedor: nomeVendedor,
                equipe: equipe,
                regiao: regiao,
              ),
          withReferenceMapper:
              (p0) =>
                  p0
                      .map(
                        (e) => (
                          e.readTable(table),
                          BaseReferences(db, table, e),
                        ),
                      )
                      .toList(),
          prefetchHooksCallback: null,
        ),
      );
}

typedef $$DimVendedorsTableProcessedTableManager =
    ProcessedTableManager<
      _$AppDatabase,
      $DimVendedorsTable,
      DimVendedor,
      $$DimVendedorsTableFilterComposer,
      $$DimVendedorsTableOrderingComposer,
      $$DimVendedorsTableAnnotationComposer,
      $$DimVendedorsTableCreateCompanionBuilder,
      $$DimVendedorsTableUpdateCompanionBuilder,
      (
        DimVendedor,
        BaseReferences<_$AppDatabase, $DimVendedorsTable, DimVendedor>,
      ),
      DimVendedor,
      PrefetchHooks Function()
    >;
typedef $$DimProdutosTableCreateCompanionBuilder =
    DimProdutosCompanion Function({
      Value<int?> id,
      Value<String?> descricao,
      Value<String?> categoria,
      Value<String?> marca,
    });
typedef $$DimProdutosTableUpdateCompanionBuilder =
    DimProdutosCompanion Function({
      Value<int?> id,
      Value<String?> descricao,
      Value<String?> categoria,
      Value<String?> marca,
    });

class $$DimProdutosTableFilterComposer
    extends Composer<_$AppDatabase, $DimProdutosTable> {
  $$DimProdutosTableFilterComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnFilters<int> get id => $composableBuilder(
    column: $table.id,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get descricao => $composableBuilder(
    column: $table.descricao,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get categoria => $composableBuilder(
    column: $table.categoria,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get marca => $composableBuilder(
    column: $table.marca,
    builder: (column) => ColumnFilters(column),
  );
}

class $$DimProdutosTableOrderingComposer
    extends Composer<_$AppDatabase, $DimProdutosTable> {
  $$DimProdutosTableOrderingComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnOrderings<int> get id => $composableBuilder(
    column: $table.id,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get descricao => $composableBuilder(
    column: $table.descricao,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get categoria => $composableBuilder(
    column: $table.categoria,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get marca => $composableBuilder(
    column: $table.marca,
    builder: (column) => ColumnOrderings(column),
  );
}

class $$DimProdutosTableAnnotationComposer
    extends Composer<_$AppDatabase, $DimProdutosTable> {
  $$DimProdutosTableAnnotationComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  GeneratedColumn<int> get id =>
      $composableBuilder(column: $table.id, builder: (column) => column);

  GeneratedColumn<String> get descricao =>
      $composableBuilder(column: $table.descricao, builder: (column) => column);

  GeneratedColumn<String> get categoria =>
      $composableBuilder(column: $table.categoria, builder: (column) => column);

  GeneratedColumn<String> get marca =>
      $composableBuilder(column: $table.marca, builder: (column) => column);
}

class $$DimProdutosTableTableManager
    extends
        RootTableManager<
          _$AppDatabase,
          $DimProdutosTable,
          DimProduto,
          $$DimProdutosTableFilterComposer,
          $$DimProdutosTableOrderingComposer,
          $$DimProdutosTableAnnotationComposer,
          $$DimProdutosTableCreateCompanionBuilder,
          $$DimProdutosTableUpdateCompanionBuilder,
          (
            DimProduto,
            BaseReferences<_$AppDatabase, $DimProdutosTable, DimProduto>,
          ),
          DimProduto,
          PrefetchHooks Function()
        > {
  $$DimProdutosTableTableManager(_$AppDatabase db, $DimProdutosTable table)
    : super(
        TableManagerState(
          db: db,
          table: table,
          createFilteringComposer:
              () => $$DimProdutosTableFilterComposer($db: db, $table: table),
          createOrderingComposer:
              () => $$DimProdutosTableOrderingComposer($db: db, $table: table),
          createComputedFieldComposer:
              () =>
                  $$DimProdutosTableAnnotationComposer($db: db, $table: table),
          updateCompanionCallback:
              ({
                Value<int?> id = const Value.absent(),
                Value<String?> descricao = const Value.absent(),
                Value<String?> categoria = const Value.absent(),
                Value<String?> marca = const Value.absent(),
              }) => DimProdutosCompanion(
                id: id,
                descricao: descricao,
                categoria: categoria,
                marca: marca,
              ),
          createCompanionCallback:
              ({
                Value<int?> id = const Value.absent(),
                Value<String?> descricao = const Value.absent(),
                Value<String?> categoria = const Value.absent(),
                Value<String?> marca = const Value.absent(),
              }) => DimProdutosCompanion.insert(
                id: id,
                descricao: descricao,
                categoria: categoria,
                marca: marca,
              ),
          withReferenceMapper:
              (p0) =>
                  p0
                      .map(
                        (e) => (
                          e.readTable(table),
                          BaseReferences(db, table, e),
                        ),
                      )
                      .toList(),
          prefetchHooksCallback: null,
        ),
      );
}

typedef $$DimProdutosTableProcessedTableManager =
    ProcessedTableManager<
      _$AppDatabase,
      $DimProdutosTable,
      DimProduto,
      $$DimProdutosTableFilterComposer,
      $$DimProdutosTableOrderingComposer,
      $$DimProdutosTableAnnotationComposer,
      $$DimProdutosTableCreateCompanionBuilder,
      $$DimProdutosTableUpdateCompanionBuilder,
      (
        DimProduto,
        BaseReferences<_$AppDatabase, $DimProdutosTable, DimProduto>,
      ),
      DimProduto,
      PrefetchHooks Function()
    >;
typedef $$FatoVendasTableCreateCompanionBuilder =
    FatoVendasCompanion Function({
      Value<int?> id,
      Value<int?> idTempo,
      Value<int?> idCliente,
      Value<int?> idVendedor,
      Value<int?> idProduto,
      Value<double?> quantidade,
      Value<double?> valorTotal,
      Value<double?> custoTotal,
      Value<double?> lucro,
    });
typedef $$FatoVendasTableUpdateCompanionBuilder =
    FatoVendasCompanion Function({
      Value<int?> id,
      Value<int?> idTempo,
      Value<int?> idCliente,
      Value<int?> idVendedor,
      Value<int?> idProduto,
      Value<double?> quantidade,
      Value<double?> valorTotal,
      Value<double?> custoTotal,
      Value<double?> lucro,
    });

class $$FatoVendasTableFilterComposer
    extends Composer<_$AppDatabase, $FatoVendasTable> {
  $$FatoVendasTableFilterComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnFilters<int> get id => $composableBuilder(
    column: $table.id,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<int> get idTempo => $composableBuilder(
    column: $table.idTempo,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<int> get idCliente => $composableBuilder(
    column: $table.idCliente,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<int> get idVendedor => $composableBuilder(
    column: $table.idVendedor,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<int> get idProduto => $composableBuilder(
    column: $table.idProduto,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<double> get quantidade => $composableBuilder(
    column: $table.quantidade,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<double> get valorTotal => $composableBuilder(
    column: $table.valorTotal,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<double> get custoTotal => $composableBuilder(
    column: $table.custoTotal,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<double> get lucro => $composableBuilder(
    column: $table.lucro,
    builder: (column) => ColumnFilters(column),
  );
}

class $$FatoVendasTableOrderingComposer
    extends Composer<_$AppDatabase, $FatoVendasTable> {
  $$FatoVendasTableOrderingComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnOrderings<int> get id => $composableBuilder(
    column: $table.id,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<int> get idTempo => $composableBuilder(
    column: $table.idTempo,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<int> get idCliente => $composableBuilder(
    column: $table.idCliente,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<int> get idVendedor => $composableBuilder(
    column: $table.idVendedor,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<int> get idProduto => $composableBuilder(
    column: $table.idProduto,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<double> get quantidade => $composableBuilder(
    column: $table.quantidade,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<double> get valorTotal => $composableBuilder(
    column: $table.valorTotal,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<double> get custoTotal => $composableBuilder(
    column: $table.custoTotal,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<double> get lucro => $composableBuilder(
    column: $table.lucro,
    builder: (column) => ColumnOrderings(column),
  );
}

class $$FatoVendasTableAnnotationComposer
    extends Composer<_$AppDatabase, $FatoVendasTable> {
  $$FatoVendasTableAnnotationComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  GeneratedColumn<int> get id =>
      $composableBuilder(column: $table.id, builder: (column) => column);

  GeneratedColumn<int> get idTempo =>
      $composableBuilder(column: $table.idTempo, builder: (column) => column);

  GeneratedColumn<int> get idCliente =>
      $composableBuilder(column: $table.idCliente, builder: (column) => column);

  GeneratedColumn<int> get idVendedor => $composableBuilder(
    column: $table.idVendedor,
    builder: (column) => column,
  );

  GeneratedColumn<int> get idProduto =>
      $composableBuilder(column: $table.idProduto, builder: (column) => column);

  GeneratedColumn<double> get quantidade => $composableBuilder(
    column: $table.quantidade,
    builder: (column) => column,
  );

  GeneratedColumn<double> get valorTotal => $composableBuilder(
    column: $table.valorTotal,
    builder: (column) => column,
  );

  GeneratedColumn<double> get custoTotal => $composableBuilder(
    column: $table.custoTotal,
    builder: (column) => column,
  );

  GeneratedColumn<double> get lucro =>
      $composableBuilder(column: $table.lucro, builder: (column) => column);
}

class $$FatoVendasTableTableManager
    extends
        RootTableManager<
          _$AppDatabase,
          $FatoVendasTable,
          FatoVenda,
          $$FatoVendasTableFilterComposer,
          $$FatoVendasTableOrderingComposer,
          $$FatoVendasTableAnnotationComposer,
          $$FatoVendasTableCreateCompanionBuilder,
          $$FatoVendasTableUpdateCompanionBuilder,
          (
            FatoVenda,
            BaseReferences<_$AppDatabase, $FatoVendasTable, FatoVenda>,
          ),
          FatoVenda,
          PrefetchHooks Function()
        > {
  $$FatoVendasTableTableManager(_$AppDatabase db, $FatoVendasTable table)
    : super(
        TableManagerState(
          db: db,
          table: table,
          createFilteringComposer:
              () => $$FatoVendasTableFilterComposer($db: db, $table: table),
          createOrderingComposer:
              () => $$FatoVendasTableOrderingComposer($db: db, $table: table),
          createComputedFieldComposer:
              () => $$FatoVendasTableAnnotationComposer($db: db, $table: table),
          updateCompanionCallback:
              ({
                Value<int?> id = const Value.absent(),
                Value<int?> idTempo = const Value.absent(),
                Value<int?> idCliente = const Value.absent(),
                Value<int?> idVendedor = const Value.absent(),
                Value<int?> idProduto = const Value.absent(),
                Value<double?> quantidade = const Value.absent(),
                Value<double?> valorTotal = const Value.absent(),
                Value<double?> custoTotal = const Value.absent(),
                Value<double?> lucro = const Value.absent(),
              }) => FatoVendasCompanion(
                id: id,
                idTempo: idTempo,
                idCliente: idCliente,
                idVendedor: idVendedor,
                idProduto: idProduto,
                quantidade: quantidade,
                valorTotal: valorTotal,
                custoTotal: custoTotal,
                lucro: lucro,
              ),
          createCompanionCallback:
              ({
                Value<int?> id = const Value.absent(),
                Value<int?> idTempo = const Value.absent(),
                Value<int?> idCliente = const Value.absent(),
                Value<int?> idVendedor = const Value.absent(),
                Value<int?> idProduto = const Value.absent(),
                Value<double?> quantidade = const Value.absent(),
                Value<double?> valorTotal = const Value.absent(),
                Value<double?> custoTotal = const Value.absent(),
                Value<double?> lucro = const Value.absent(),
              }) => FatoVendasCompanion.insert(
                id: id,
                idTempo: idTempo,
                idCliente: idCliente,
                idVendedor: idVendedor,
                idProduto: idProduto,
                quantidade: quantidade,
                valorTotal: valorTotal,
                custoTotal: custoTotal,
                lucro: lucro,
              ),
          withReferenceMapper:
              (p0) =>
                  p0
                      .map(
                        (e) => (
                          e.readTable(table),
                          BaseReferences(db, table, e),
                        ),
                      )
                      .toList(),
          prefetchHooksCallback: null,
        ),
      );
}

typedef $$FatoVendasTableProcessedTableManager =
    ProcessedTableManager<
      _$AppDatabase,
      $FatoVendasTable,
      FatoVenda,
      $$FatoVendasTableFilterComposer,
      $$FatoVendasTableOrderingComposer,
      $$FatoVendasTableAnnotationComposer,
      $$FatoVendasTableCreateCompanionBuilder,
      $$FatoVendasTableUpdateCompanionBuilder,
      (FatoVenda, BaseReferences<_$AppDatabase, $FatoVendasTable, FatoVenda>),
      FatoVenda,
      PrefetchHooks Function()
    >;
typedef $$FatoRecebimentosTableCreateCompanionBuilder =
    FatoRecebimentosCompanion Function({
      Value<int?> id,
      Value<int?> idTempo,
      Value<int?> idCliente,
      Value<double?> valorRecebido,
      Value<double?> valorEmAberto,
      Value<int?> atrasoDias,
    });
typedef $$FatoRecebimentosTableUpdateCompanionBuilder =
    FatoRecebimentosCompanion Function({
      Value<int?> id,
      Value<int?> idTempo,
      Value<int?> idCliente,
      Value<double?> valorRecebido,
      Value<double?> valorEmAberto,
      Value<int?> atrasoDias,
    });

class $$FatoRecebimentosTableFilterComposer
    extends Composer<_$AppDatabase, $FatoRecebimentosTable> {
  $$FatoRecebimentosTableFilterComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnFilters<int> get id => $composableBuilder(
    column: $table.id,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<int> get idTempo => $composableBuilder(
    column: $table.idTempo,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<int> get idCliente => $composableBuilder(
    column: $table.idCliente,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<double> get valorRecebido => $composableBuilder(
    column: $table.valorRecebido,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<double> get valorEmAberto => $composableBuilder(
    column: $table.valorEmAberto,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<int> get atrasoDias => $composableBuilder(
    column: $table.atrasoDias,
    builder: (column) => ColumnFilters(column),
  );
}

class $$FatoRecebimentosTableOrderingComposer
    extends Composer<_$AppDatabase, $FatoRecebimentosTable> {
  $$FatoRecebimentosTableOrderingComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnOrderings<int> get id => $composableBuilder(
    column: $table.id,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<int> get idTempo => $composableBuilder(
    column: $table.idTempo,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<int> get idCliente => $composableBuilder(
    column: $table.idCliente,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<double> get valorRecebido => $composableBuilder(
    column: $table.valorRecebido,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<double> get valorEmAberto => $composableBuilder(
    column: $table.valorEmAberto,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<int> get atrasoDias => $composableBuilder(
    column: $table.atrasoDias,
    builder: (column) => ColumnOrderings(column),
  );
}

class $$FatoRecebimentosTableAnnotationComposer
    extends Composer<_$AppDatabase, $FatoRecebimentosTable> {
  $$FatoRecebimentosTableAnnotationComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  GeneratedColumn<int> get id =>
      $composableBuilder(column: $table.id, builder: (column) => column);

  GeneratedColumn<int> get idTempo =>
      $composableBuilder(column: $table.idTempo, builder: (column) => column);

  GeneratedColumn<int> get idCliente =>
      $composableBuilder(column: $table.idCliente, builder: (column) => column);

  GeneratedColumn<double> get valorRecebido => $composableBuilder(
    column: $table.valorRecebido,
    builder: (column) => column,
  );

  GeneratedColumn<double> get valorEmAberto => $composableBuilder(
    column: $table.valorEmAberto,
    builder: (column) => column,
  );

  GeneratedColumn<int> get atrasoDias => $composableBuilder(
    column: $table.atrasoDias,
    builder: (column) => column,
  );
}

class $$FatoRecebimentosTableTableManager
    extends
        RootTableManager<
          _$AppDatabase,
          $FatoRecebimentosTable,
          FatoRecebimento,
          $$FatoRecebimentosTableFilterComposer,
          $$FatoRecebimentosTableOrderingComposer,
          $$FatoRecebimentosTableAnnotationComposer,
          $$FatoRecebimentosTableCreateCompanionBuilder,
          $$FatoRecebimentosTableUpdateCompanionBuilder,
          (
            FatoRecebimento,
            BaseReferences<
              _$AppDatabase,
              $FatoRecebimentosTable,
              FatoRecebimento
            >,
          ),
          FatoRecebimento,
          PrefetchHooks Function()
        > {
  $$FatoRecebimentosTableTableManager(
    _$AppDatabase db,
    $FatoRecebimentosTable table,
  ) : super(
        TableManagerState(
          db: db,
          table: table,
          createFilteringComposer:
              () =>
                  $$FatoRecebimentosTableFilterComposer($db: db, $table: table),
          createOrderingComposer:
              () => $$FatoRecebimentosTableOrderingComposer(
                $db: db,
                $table: table,
              ),
          createComputedFieldComposer:
              () => $$FatoRecebimentosTableAnnotationComposer(
                $db: db,
                $table: table,
              ),
          updateCompanionCallback:
              ({
                Value<int?> id = const Value.absent(),
                Value<int?> idTempo = const Value.absent(),
                Value<int?> idCliente = const Value.absent(),
                Value<double?> valorRecebido = const Value.absent(),
                Value<double?> valorEmAberto = const Value.absent(),
                Value<int?> atrasoDias = const Value.absent(),
              }) => FatoRecebimentosCompanion(
                id: id,
                idTempo: idTempo,
                idCliente: idCliente,
                valorRecebido: valorRecebido,
                valorEmAberto: valorEmAberto,
                atrasoDias: atrasoDias,
              ),
          createCompanionCallback:
              ({
                Value<int?> id = const Value.absent(),
                Value<int?> idTempo = const Value.absent(),
                Value<int?> idCliente = const Value.absent(),
                Value<double?> valorRecebido = const Value.absent(),
                Value<double?> valorEmAberto = const Value.absent(),
                Value<int?> atrasoDias = const Value.absent(),
              }) => FatoRecebimentosCompanion.insert(
                id: id,
                idTempo: idTempo,
                idCliente: idCliente,
                valorRecebido: valorRecebido,
                valorEmAberto: valorEmAberto,
                atrasoDias: atrasoDias,
              ),
          withReferenceMapper:
              (p0) =>
                  p0
                      .map(
                        (e) => (
                          e.readTable(table),
                          BaseReferences(db, table, e),
                        ),
                      )
                      .toList(),
          prefetchHooksCallback: null,
        ),
      );
}

typedef $$FatoRecebimentosTableProcessedTableManager =
    ProcessedTableManager<
      _$AppDatabase,
      $FatoRecebimentosTable,
      FatoRecebimento,
      $$FatoRecebimentosTableFilterComposer,
      $$FatoRecebimentosTableOrderingComposer,
      $$FatoRecebimentosTableAnnotationComposer,
      $$FatoRecebimentosTableCreateCompanionBuilder,
      $$FatoRecebimentosTableUpdateCompanionBuilder,
      (
        FatoRecebimento,
        BaseReferences<_$AppDatabase, $FatoRecebimentosTable, FatoRecebimento>,
      ),
      FatoRecebimento,
      PrefetchHooks Function()
    >;

class $AppDatabaseManager {
  final _$AppDatabase _db;
  $AppDatabaseManager(this._db);
  $$DimTemposTableTableManager get dimTempos =>
      $$DimTemposTableTableManager(_db, _db.dimTempos);
  $$DimClientesTableTableManager get dimClientes =>
      $$DimClientesTableTableManager(_db, _db.dimClientes);
  $$DimVendedorsTableTableManager get dimVendedors =>
      $$DimVendedorsTableTableManager(_db, _db.dimVendedors);
  $$DimProdutosTableTableManager get dimProdutos =>
      $$DimProdutosTableTableManager(_db, _db.dimProdutos);
  $$FatoVendasTableTableManager get fatoVendas =>
      $$FatoVendasTableTableManager(_db, _db.fatoVendas);
  $$FatoRecebimentosTableTableManager get fatoRecebimentos =>
      $$FatoRecebimentosTableTableManager(_db, _db.fatoRecebimentos);
}
