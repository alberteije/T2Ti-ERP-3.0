// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'fato_venda_dao.dart';

// ignore_for_file: type=lint
mixin _$FatoVendaDaoMixin on DatabaseAccessor<AppDatabase> {
  $FatoVendasTable get fatoVendas => attachedDatabase.fatoVendas;
}
