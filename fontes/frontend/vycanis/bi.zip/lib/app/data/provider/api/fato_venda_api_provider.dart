import 'package:bi/app/data/provider/api/api_provider_base.dart';
import 'package:bi/app/data/model/model_imports.dart';

class FatoVendaApiProvider extends ApiProviderBase {
  static const _path = '/fato-venda';

  Future<List<FatoVendaModel>?> getList({Filter? filter}) {
    return super.getListBase(
      '$_path/',
      (json) => FatoVendaModel.fromJson(json),
      filter: filter,
    );
  }

  Future<FatoVendaModel?> getObject(dynamic pk) {
    return super.getObjectBase(
      _path,
      pk,
      (json) => FatoVendaModel.fromJson(json),
    );
  }

  Future<FatoVendaModel?>? insert(FatoVendaModel model) {
    return super.insertBase(
      _path,
      model,
      (json) => FatoVendaModel.fromJson(json),
    );
  }

  Future<FatoVendaModel?>? update(FatoVendaModel model) {
    return super.updateBase(
      _path,
      model,
      (json) => FatoVendaModel.fromJson(json),
    );
  }

  Future<bool?> delete(dynamic pk) {
    return super.deleteBase(_path, pk);
  }
}
