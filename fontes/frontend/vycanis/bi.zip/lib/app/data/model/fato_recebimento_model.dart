import 'dart:convert';
import 'package:pluto_grid/pluto_grid.dart';
import 'package:bi/app/data/model/model_imports.dart';


class FatoRecebimentoModel extends ModelBase {
  int? id;
  int? idTempo;
  int? idCliente;
  double? valorRecebido;
  double? valorEmAberto;
  int? atrasoDias;

  FatoRecebimentoModel({
    this.id,
    this.idTempo,
    this.idCliente,
    this.valorRecebido,
    this.valorEmAberto,
    this.atrasoDias,
  });

  static List<String> dbColumns = <String>[
    'id',
    'id_tempo',
    'id_cliente',
    'valor_recebido',
    'valor_em_aberto',
    'atraso_dias',
  ];

  static List<String> aliasColumns = <String>[
    'Id',
    'Id Tempo',
    'Id Cliente',
    'Valor Recebido',
    'Valor Em Aberto',
    'Atraso Dias',
  ];

  FatoRecebimentoModel.fromJson(Map<String, dynamic> jsonData) {
    id = jsonData['id'];
    idTempo = jsonData['idTempo'];
    idCliente = jsonData['idCliente'];
    valorRecebido = jsonData['valorRecebido']?.toDouble();
    valorEmAberto = jsonData['valorEmAberto']?.toDouble();
    atrasoDias = jsonData['atrasoDias'];
  }

  Map<String, dynamic> get toJson {
    Map<String, dynamic> jsonData = <String, dynamic>{};

    jsonData['id'] = id != 0 ? id : null;
    jsonData['idTempo'] = idTempo;
    jsonData['idCliente'] = idCliente;
    jsonData['valorRecebido'] = valorRecebido;
    jsonData['valorEmAberto'] = valorEmAberto;
    jsonData['atrasoDias'] = atrasoDias;

    return jsonData;
  }

  String objectEncodeJson() {
    final jsonData = toJson;
    return json.encode(jsonData);
  }

  static FatoRecebimentoModel fromPlutoRow(PlutoRow row) {
    return FatoRecebimentoModel(
      id: row.cells['id']?.value,
      idTempo: row.cells['idTempo']?.value,
      idCliente: row.cells['idCliente']?.value,
      valorRecebido: row.cells['valorRecebido']?.value,
      valorEmAberto: row.cells['valorEmAberto']?.value,
      atrasoDias: row.cells['atrasoDias']?.value,
    );
  }

  PlutoRow toPlutoRow() {
    return PlutoRow(
      cells: {
        'tempId': PlutoCell(value: tempId),
        'id': PlutoCell(value: id ?? 0),
        'idTempo': PlutoCell(value: idTempo ?? 0),
        'idCliente': PlutoCell(value: idCliente ?? 0),
        'valorRecebido': PlutoCell(value: valorRecebido ?? 0.0),
        'valorEmAberto': PlutoCell(value: valorEmAberto ?? 0.0),
        'atrasoDias': PlutoCell(value: atrasoDias ?? 0),
      },
    );
  }

  FatoRecebimentoModel clone() {
    return FatoRecebimentoModel(
      id: id,
      idTempo: idTempo,
      idCliente: idCliente,
      valorRecebido: valorRecebido,
      valorEmAberto: valorEmAberto,
      atrasoDias: atrasoDias,
    );
  }


}