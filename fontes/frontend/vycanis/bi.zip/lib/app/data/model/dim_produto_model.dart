import 'dart:convert';
import 'package:pluto_grid/pluto_grid.dart';
import 'package:bi/app/data/model/model_imports.dart';


class DimProdutoModel extends ModelBase {
  int? id;
  String? descricao;
  String? categoria;
  String? marca;

  DimProdutoModel({
    this.id,
    this.descricao,
    this.categoria,
    this.marca,
  });

  static List<String> dbColumns = <String>[
    'id',
    'descricao',
    'categoria',
    'marca',
  ];

  static List<String> aliasColumns = <String>[
    'Id',
    'Descricao',
    'Categoria',
    'Marca',
  ];

  DimProdutoModel.fromJson(Map<String, dynamic> jsonData) {
    id = jsonData['id'];
    descricao = jsonData['descricao'];
    categoria = jsonData['categoria'];
    marca = jsonData['marca'];
  }

  Map<String, dynamic> get toJson {
    Map<String, dynamic> jsonData = <String, dynamic>{};

    jsonData['id'] = id != 0 ? id : null;
    jsonData['descricao'] = descricao;
    jsonData['categoria'] = categoria;
    jsonData['marca'] = marca;

    return jsonData;
  }

  String objectEncodeJson() {
    final jsonData = toJson;
    return json.encode(jsonData);
  }

  static DimProdutoModel fromPlutoRow(PlutoRow row) {
    return DimProdutoModel(
      id: row.cells['id']?.value,
      descricao: row.cells['descricao']?.value,
      categoria: row.cells['categoria']?.value,
      marca: row.cells['marca']?.value,
    );
  }

  PlutoRow toPlutoRow() {
    return PlutoRow(
      cells: {
        'tempId': PlutoCell(value: tempId),
        'id': PlutoCell(value: id ?? 0),
        'descricao': PlutoCell(value: descricao ?? ''),
        'categoria': PlutoCell(value: categoria ?? ''),
        'marca': PlutoCell(value: marca ?? ''),
      },
    );
  }

  DimProdutoModel clone() {
    return DimProdutoModel(
      id: id,
      descricao: descricao,
      categoria: categoria,
      marca: marca,
    );
  }


}