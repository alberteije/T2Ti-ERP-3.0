import 'dart:convert';
import 'package:pluto_grid/pluto_grid.dart';
import 'package:bi/app/data/model/model_imports.dart';


class DimVendedorModel extends ModelBase {
  int? id;
  String? nomeVendedor;
  String? equipe;
  String? regiao;

  DimVendedorModel({
    this.id,
    this.nomeVendedor,
    this.equipe,
    this.regiao,
  });

  static List<String> dbColumns = <String>[
    'id',
    'nome_vendedor',
    'equipe',
    'regiao',
  ];

  static List<String> aliasColumns = <String>[
    'Id',
    'Nome Vendedor',
    'Equipe',
    'Regiao',
  ];

  DimVendedorModel.fromJson(Map<String, dynamic> jsonData) {
    id = jsonData['id'];
    nomeVendedor = jsonData['nomeVendedor'];
    equipe = jsonData['equipe'];
    regiao = jsonData['regiao'];
  }

  Map<String, dynamic> get toJson {
    Map<String, dynamic> jsonData = <String, dynamic>{};

    jsonData['id'] = id != 0 ? id : null;
    jsonData['nomeVendedor'] = nomeVendedor;
    jsonData['equipe'] = equipe;
    jsonData['regiao'] = regiao;

    return jsonData;
  }

  String objectEncodeJson() {
    final jsonData = toJson;
    return json.encode(jsonData);
  }

  static DimVendedorModel fromPlutoRow(PlutoRow row) {
    return DimVendedorModel(
      id: row.cells['id']?.value,
      nomeVendedor: row.cells['nomeVendedor']?.value,
      equipe: row.cells['equipe']?.value,
      regiao: row.cells['regiao']?.value,
    );
  }

  PlutoRow toPlutoRow() {
    return PlutoRow(
      cells: {
        'tempId': PlutoCell(value: tempId),
        'id': PlutoCell(value: id ?? 0),
        'nomeVendedor': PlutoCell(value: nomeVendedor ?? ''),
        'equipe': PlutoCell(value: equipe ?? ''),
        'regiao': PlutoCell(value: regiao ?? ''),
      },
    );
  }

  DimVendedorModel clone() {
    return DimVendedorModel(
      id: id,
      nomeVendedor: nomeVendedor,
      equipe: equipe,
      regiao: regiao,
    );
  }


}