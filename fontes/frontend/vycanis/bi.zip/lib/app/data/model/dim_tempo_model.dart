import 'dart:convert';
import 'package:pluto_grid/pluto_grid.dart';
import 'package:bi/app/data/model/model_imports.dart';

import 'package:bi/app/infra/infra_imports.dart';
import 'package:intl/intl.dart';

class DimTempoModel extends ModelBase {
  int? id;
  DateTime? data;
  int? ano;
  int? mes;
  String? nomeMes;
  int? trimestre;
  int? dia;
  int? diaSemana;

  DimTempoModel({
    this.id,
    this.data,
    this.ano,
    this.mes,
    this.nomeMes,
    this.trimestre,
    this.dia,
    this.diaSemana,
  });

  static List<String> dbColumns = <String>[
    'id',
    'data',
    'ano',
    'mes',
    'nome_mes',
    'trimestre',
    'dia',
    'dia_semana',
  ];

  static List<String> aliasColumns = <String>[
    'Id',
    'Data',
    'Ano',
    'Mes',
    'Nome Mes',
    'Trimestre',
    'Dia',
    'Dia Semana',
  ];

  DimTempoModel.fromJson(Map<String, dynamic> jsonData) {
    id = jsonData['id'];
    data = jsonData['data'] != null ? DateTime.tryParse(jsonData['data']) : null;
    ano = jsonData['ano'];
    mes = jsonData['mes'];
    nomeMes = jsonData['nomeMes'];
    trimestre = jsonData['trimestre'];
    dia = jsonData['dia'];
    diaSemana = jsonData['diaSemana'];
  }

  Map<String, dynamic> get toJson {
    Map<String, dynamic> jsonData = <String, dynamic>{};

    jsonData['id'] = id != 0 ? id : null;
    jsonData['data'] = data != null ? DateFormat('yyyy-MM-ddT00:00:00').format(data!) : null;
    jsonData['ano'] = ano;
    jsonData['mes'] = mes;
    jsonData['nomeMes'] = nomeMes;
    jsonData['trimestre'] = trimestre;
    jsonData['dia'] = dia;
    jsonData['diaSemana'] = diaSemana;

    return jsonData;
  }

  String objectEncodeJson() {
    final jsonData = toJson;
    return json.encode(jsonData);
  }

  static DimTempoModel fromPlutoRow(PlutoRow row) {
    return DimTempoModel(
      id: row.cells['id']?.value,
      data: Util.stringToDate(row.cells['data']?.value),
      ano: row.cells['ano']?.value,
      mes: row.cells['mes']?.value,
      nomeMes: row.cells['nomeMes']?.value,
      trimestre: row.cells['trimestre']?.value,
      dia: row.cells['dia']?.value,
      diaSemana: row.cells['diaSemana']?.value,
    );
  }

  PlutoRow toPlutoRow() {
    return PlutoRow(
      cells: {
        'tempId': PlutoCell(value: tempId),
        'id': PlutoCell(value: id ?? 0),
        'data': PlutoCell(value: data),
        'ano': PlutoCell(value: ano ?? 0),
        'mes': PlutoCell(value: mes ?? 0),
        'nomeMes': PlutoCell(value: nomeMes ?? ''),
        'trimestre': PlutoCell(value: trimestre ?? 0),
        'dia': PlutoCell(value: dia ?? 0),
        'diaSemana': PlutoCell(value: diaSemana ?? 0),
      },
    );
  }

  DimTempoModel clone() {
    return DimTempoModel(
      id: id,
      data: data,
      ano: ano,
      mes: mes,
      nomeMes: nomeMes,
      trimestre: trimestre,
      dia: dia,
      diaSemana: diaSemana,
    );
  }


}