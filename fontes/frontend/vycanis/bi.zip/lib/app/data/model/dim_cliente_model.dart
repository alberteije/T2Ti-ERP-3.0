import 'dart:convert';
import 'package:pluto_grid/pluto_grid.dart';
import 'package:bi/app/data/model/model_imports.dart';


class DimClienteModel extends ModelBase {
  int? id;
  String? nomeCliente;
  String? tipoCliente;
  String? cidade;
  String? estado;
  String? segmento;

  DimClienteModel({
    this.id,
    this.nomeCliente,
    this.tipoCliente,
    this.cidade,
    this.estado,
    this.segmento,
  });

  static List<String> dbColumns = <String>[
    'id',
    'nome_cliente',
    'tipo_cliente',
    'cidade',
    'estado',
    'segmento',
  ];

  static List<String> aliasColumns = <String>[
    'Id',
    'Nome Cliente',
    'Tipo Cliente',
    'Cidade',
    'Estado',
    'Segmento',
  ];

  DimClienteModel.fromJson(Map<String, dynamic> jsonData) {
    id = jsonData['id'];
    nomeCliente = jsonData['nomeCliente'];
    tipoCliente = jsonData['tipoCliente'];
    cidade = jsonData['cidade'];
    estado = jsonData['estado'];
    segmento = jsonData['segmento'];
  }

  Map<String, dynamic> get toJson {
    Map<String, dynamic> jsonData = <String, dynamic>{};

    jsonData['id'] = id != 0 ? id : null;
    jsonData['nomeCliente'] = nomeCliente;
    jsonData['tipoCliente'] = tipoCliente;
    jsonData['cidade'] = cidade;
    jsonData['estado'] = estado;
    jsonData['segmento'] = segmento;

    return jsonData;
  }

  String objectEncodeJson() {
    final jsonData = toJson;
    return json.encode(jsonData);
  }

  static DimClienteModel fromPlutoRow(PlutoRow row) {
    return DimClienteModel(
      id: row.cells['id']?.value,
      nomeCliente: row.cells['nomeCliente']?.value,
      tipoCliente: row.cells['tipoCliente']?.value,
      cidade: row.cells['cidade']?.value,
      estado: row.cells['estado']?.value,
      segmento: row.cells['segmento']?.value,
    );
  }

  PlutoRow toPlutoRow() {
    return PlutoRow(
      cells: {
        'tempId': PlutoCell(value: tempId),
        'id': PlutoCell(value: id ?? 0),
        'nomeCliente': PlutoCell(value: nomeCliente ?? ''),
        'tipoCliente': PlutoCell(value: tipoCliente ?? ''),
        'cidade': PlutoCell(value: cidade ?? ''),
        'estado': PlutoCell(value: estado ?? ''),
        'segmento': PlutoCell(value: segmento ?? ''),
      },
    );
  }

  DimClienteModel clone() {
    return DimClienteModel(
      id: id,
      nomeCliente: nomeCliente,
      tipoCliente: tipoCliente,
      cidade: cidade,
      estado: estado,
      segmento: segmento,
    );
  }


}