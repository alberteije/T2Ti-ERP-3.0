import 'dart:convert';
import 'package:pluto_grid/pluto_grid.dart';
import 'package:bi/app/data/model/model_imports.dart';


class FatoVendaModel extends ModelBase {
  int? id;
  int? idTempo;
  int? idCliente;
  int? idVendedor;
  int? idProduto;
  double? quantidade;
  double? valorTotal;
  double? custoTotal;
  double? lucro;

  FatoVendaModel({
    this.id,
    this.idTempo,
    this.idCliente,
    this.idVendedor,
    this.idProduto,
    this.quantidade,
    this.valorTotal,
    this.custoTotal,
    this.lucro,
  });

  static List<String> dbColumns = <String>[
    'id',
    'id_tempo',
    'id_cliente',
    'id_vendedor',
    'id_produto',
    'quantidade',
    'valor_total',
    'custo_total',
    'lucro',
  ];

  static List<String> aliasColumns = <String>[
    'Id',
    'Id Tempo',
    'Id Cliente',
    'Id Vendedor',
    'Id Produto',
    'Quantidade',
    'Valor Total',
    'Custo Total',
    'Lucro',
  ];

  FatoVendaModel.fromJson(Map<String, dynamic> jsonData) {
    id = jsonData['id'];
    idTempo = jsonData['idTempo'];
    idCliente = jsonData['idCliente'];
    idVendedor = jsonData['idVendedor'];
    idProduto = jsonData['idProduto'];
    quantidade = jsonData['quantidade']?.toDouble();
    valorTotal = jsonData['valorTotal']?.toDouble();
    custoTotal = jsonData['custoTotal']?.toDouble();
    lucro = jsonData['lucro']?.toDouble();
  }

  Map<String, dynamic> get toJson {
    Map<String, dynamic> jsonData = <String, dynamic>{};

    jsonData['id'] = id != 0 ? id : null;
    jsonData['idTempo'] = idTempo;
    jsonData['idCliente'] = idCliente;
    jsonData['idVendedor'] = idVendedor;
    jsonData['idProduto'] = idProduto;
    jsonData['quantidade'] = quantidade;
    jsonData['valorTotal'] = valorTotal;
    jsonData['custoTotal'] = custoTotal;
    jsonData['lucro'] = lucro;

    return jsonData;
  }

  String objectEncodeJson() {
    final jsonData = toJson;
    return json.encode(jsonData);
  }

  static FatoVendaModel fromPlutoRow(PlutoRow row) {
    return FatoVendaModel(
      id: row.cells['id']?.value,
      idTempo: row.cells['idTempo']?.value,
      idCliente: row.cells['idCliente']?.value,
      idVendedor: row.cells['idVendedor']?.value,
      idProduto: row.cells['idProduto']?.value,
      quantidade: row.cells['quantidade']?.value,
      valorTotal: row.cells['valorTotal']?.value,
      custoTotal: row.cells['custoTotal']?.value,
      lucro: row.cells['lucro']?.value,
    );
  }

  PlutoRow toPlutoRow() {
    return PlutoRow(
      cells: {
        'tempId': PlutoCell(value: tempId),
        'id': PlutoCell(value: id ?? 0),
        'idTempo': PlutoCell(value: idTempo ?? 0),
        'idCliente': PlutoCell(value: idCliente ?? 0),
        'idVendedor': PlutoCell(value: idVendedor ?? 0),
        'idProduto': PlutoCell(value: idProduto ?? 0),
        'quantidade': PlutoCell(value: quantidade ?? 0.0),
        'valorTotal': PlutoCell(value: valorTotal ?? 0.0),
        'custoTotal': PlutoCell(value: custoTotal ?? 0.0),
        'lucro': PlutoCell(value: lucro ?? 0.0),
      },
    );
  }

  FatoVendaModel clone() {
    return FatoVendaModel(
      id: id,
      idTempo: idTempo,
      idCliente: idCliente,
      idVendedor: idVendedor,
      idProduto: idProduto,
      quantidade: quantidade,
      valorTotal: valorTotal,
      custoTotal: custoTotal,
      lucro: lucro,
    );
  }


}