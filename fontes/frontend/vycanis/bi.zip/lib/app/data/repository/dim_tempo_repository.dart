import 'package:bi/app/infra/constants.dart';
import 'package:bi/app/data/provider/api/dim_tempo_api_provider.dart';
import 'package:bi/app/data/provider/drift/dim_tempo_drift_provider.dart';
import 'package:bi/app/data/model/model_imports.dart';

class DimTempoRepository {
  final DimTempoApiProvider dimTempoApiProvider;
  final DimTempoDriftProvider dimTempoDriftProvider;

  DimTempoRepository({required this.dimTempoApiProvider, required this.dimTempoDriftProvider});

  Future getList({Filter? filter}) async {
    if (Constants.usingLocalDatabase) {
      return await dimTempoDriftProvider.getList(filter: filter);
    } else {
      return await dimTempoApiProvider.getList(filter: filter);
    }
  }

  Future<DimTempoModel?>? save({required DimTempoModel dimTempoModel}) async {
    if (dimTempoModel.id != null) {
      if (Constants.usingLocalDatabase) {
        return await dimTempoDriftProvider.update(dimTempoModel);
      } else {
        return await dimTempoApiProvider.update(dimTempoModel);
      }
    } else {
      if (Constants.usingLocalDatabase) {
        return await dimTempoDriftProvider.insert(dimTempoModel);
      } else {
        return await dimTempoApiProvider.insert(dimTempoModel);
      }
    }   
  }

  Future<bool> delete({required int id}) async {
    if (Constants.usingLocalDatabase) {
      return await dimTempoDriftProvider.delete(id) ?? false;
    } else {
      return await dimTempoApiProvider.delete(id) ?? false;
    }
  }
}