import 'package:bi/app/infra/constants.dart';
import 'package:bi/app/data/provider/api/dim_vendedor_api_provider.dart';
import 'package:bi/app/data/provider/drift/dim_vendedor_drift_provider.dart';
import 'package:bi/app/data/model/model_imports.dart';

class DimVendedorRepository {
  final DimVendedorApiProvider dimVendedorApiProvider;
  final DimVendedorDriftProvider dimVendedorDriftProvider;

  DimVendedorRepository({required this.dimVendedorApiProvider, required this.dimVendedorDriftProvider});

  Future getList({Filter? filter}) async {
    if (Constants.usingLocalDatabase) {
      return await dimVendedorDriftProvider.getList(filter: filter);
    } else {
      return await dimVendedorApiProvider.getList(filter: filter);
    }
  }

  Future<DimVendedorModel?>? save({required DimVendedorModel dimVendedorModel}) async {
    if (dimVendedorModel.id != null) {
      if (Constants.usingLocalDatabase) {
        return await dimVendedorDriftProvider.update(dimVendedorModel);
      } else {
        return await dimVendedorApiProvider.update(dimVendedorModel);
      }
    } else {
      if (Constants.usingLocalDatabase) {
        return await dimVendedorDriftProvider.insert(dimVendedorModel);
      } else {
        return await dimVendedorApiProvider.insert(dimVendedorModel);
      }
    }   
  }

  Future<bool> delete({required int id}) async {
    if (Constants.usingLocalDatabase) {
      return await dimVendedorDriftProvider.delete(id) ?? false;
    } else {
      return await dimVendedorApiProvider.delete(id) ?? false;
    }
  }
}