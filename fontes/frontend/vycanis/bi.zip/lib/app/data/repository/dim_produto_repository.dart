import 'package:bi/app/infra/constants.dart';
import 'package:bi/app/data/provider/api/dim_produto_api_provider.dart';
import 'package:bi/app/data/provider/drift/dim_produto_drift_provider.dart';
import 'package:bi/app/data/model/model_imports.dart';

class DimProdutoRepository {
  final DimProdutoApiProvider dimProdutoApiProvider;
  final DimProdutoDriftProvider dimProdutoDriftProvider;

  DimProdutoRepository({required this.dimProdutoApiProvider, required this.dimProdutoDriftProvider});

  Future getList({Filter? filter}) async {
    if (Constants.usingLocalDatabase) {
      return await dimProdutoDriftProvider.getList(filter: filter);
    } else {
      return await dimProdutoApiProvider.getList(filter: filter);
    }
  }

  Future<DimProdutoModel?>? save({required DimProdutoModel dimProdutoModel}) async {
    if (dimProdutoModel.id != null) {
      if (Constants.usingLocalDatabase) {
        return await dimProdutoDriftProvider.update(dimProdutoModel);
      } else {
        return await dimProdutoApiProvider.update(dimProdutoModel);
      }
    } else {
      if (Constants.usingLocalDatabase) {
        return await dimProdutoDriftProvider.insert(dimProdutoModel);
      } else {
        return await dimProdutoApiProvider.insert(dimProdutoModel);
      }
    }   
  }

  Future<bool> delete({required int id}) async {
    if (Constants.usingLocalDatabase) {
      return await dimProdutoDriftProvider.delete(id) ?? false;
    } else {
      return await dimProdutoApiProvider.delete(id) ?? false;
    }
  }
}