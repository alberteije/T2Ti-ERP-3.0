import 'package:bi/app/infra/constants.dart';
import 'package:bi/app/data/provider/api/dim_cliente_api_provider.dart';
import 'package:bi/app/data/provider/drift/dim_cliente_drift_provider.dart';
import 'package:bi/app/data/model/model_imports.dart';

class DimClienteRepository {
  final DimClienteApiProvider dimClienteApiProvider;
  final DimClienteDriftProvider dimClienteDriftProvider;

  DimClienteRepository({required this.dimClienteApiProvider, required this.dimClienteDriftProvider});

  Future getList({Filter? filter}) async {
    if (Constants.usingLocalDatabase) {
      return await dimClienteDriftProvider.getList(filter: filter);
    } else {
      return await dimClienteApiProvider.getList(filter: filter);
    }
  }

  Future<DimClienteModel?>? save({required DimClienteModel dimClienteModel}) async {
    if (dimClienteModel.id != null) {
      if (Constants.usingLocalDatabase) {
        return await dimClienteDriftProvider.update(dimClienteModel);
      } else {
        return await dimClienteApiProvider.update(dimClienteModel);
      }
    } else {
      if (Constants.usingLocalDatabase) {
        return await dimClienteDriftProvider.insert(dimClienteModel);
      } else {
        return await dimClienteApiProvider.insert(dimClienteModel);
      }
    }   
  }

  Future<bool> delete({required int id}) async {
    if (Constants.usingLocalDatabase) {
      return await dimClienteDriftProvider.delete(id) ?? false;
    } else {
      return await dimClienteApiProvider.delete(id) ?? false;
    }
  }
}