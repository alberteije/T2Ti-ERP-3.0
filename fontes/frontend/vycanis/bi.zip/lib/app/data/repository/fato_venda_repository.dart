import 'package:bi/app/infra/constants.dart';
import 'package:bi/app/data/provider/api/fato_venda_api_provider.dart';
import 'package:bi/app/data/provider/drift/fato_venda_drift_provider.dart';
import 'package:bi/app/data/model/model_imports.dart';

class FatoVendaRepository {
  final FatoVendaApiProvider fatoVendaApiProvider;
  final FatoVendaDriftProvider fatoVendaDriftProvider;

  FatoVendaRepository({required this.fatoVendaApiProvider, required this.fatoVendaDriftProvider});

  Future getList({Filter? filter}) async {
    if (Constants.usingLocalDatabase) {
      return await fatoVendaDriftProvider.getList(filter: filter);
    } else {
      return await fatoVendaApiProvider.getList(filter: filter);
    }
  }

  Future<FatoVendaModel?>? save({required FatoVendaModel fatoVendaModel}) async {
    if (fatoVendaModel.id != null) {
      if (Constants.usingLocalDatabase) {
        return await fatoVendaDriftProvider.update(fatoVendaModel);
      } else {
        return await fatoVendaApiProvider.update(fatoVendaModel);
      }
    } else {
      if (Constants.usingLocalDatabase) {
        return await fatoVendaDriftProvider.insert(fatoVendaModel);
      } else {
        return await fatoVendaApiProvider.insert(fatoVendaModel);
      }
    }   
  }

  Future<bool> delete({required int id}) async {
    if (Constants.usingLocalDatabase) {
      return await fatoVendaDriftProvider.delete(id) ?? false;
    } else {
      return await fatoVendaApiProvider.delete(id) ?? false;
    }
  }
}