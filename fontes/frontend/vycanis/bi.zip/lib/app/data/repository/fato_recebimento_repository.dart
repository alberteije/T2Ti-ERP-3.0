import 'package:bi/app/infra/constants.dart';
import 'package:bi/app/data/provider/api/fato_recebimento_api_provider.dart';
import 'package:bi/app/data/provider/drift/fato_recebimento_drift_provider.dart';
import 'package:bi/app/data/model/model_imports.dart';

class FatoRecebimentoRepository {
  final FatoRecebimentoApiProvider fatoRecebimentoApiProvider;
  final FatoRecebimentoDriftProvider fatoRecebimentoDriftProvider;

  FatoRecebimentoRepository({required this.fatoRecebimentoApiProvider, required this.fatoRecebimentoDriftProvider});

  Future getList({Filter? filter}) async {
    if (Constants.usingLocalDatabase) {
      return await fatoRecebimentoDriftProvider.getList(filter: filter);
    } else {
      return await fatoRecebimentoApiProvider.getList(filter: filter);
    }
  }

  Future<FatoRecebimentoModel?>? save({required FatoRecebimentoModel fatoRecebimentoModel}) async {
    if (fatoRecebimentoModel.id != null) {
      if (Constants.usingLocalDatabase) {
        return await fatoRecebimentoDriftProvider.update(fatoRecebimentoModel);
      } else {
        return await fatoRecebimentoApiProvider.update(fatoRecebimentoModel);
      }
    } else {
      if (Constants.usingLocalDatabase) {
        return await fatoRecebimentoDriftProvider.insert(fatoRecebimentoModel);
      } else {
        return await fatoRecebimentoApiProvider.insert(fatoRecebimentoModel);
      }
    }   
  }

  Future<bool> delete({required int id}) async {
    if (Constants.usingLocalDatabase) {
      return await fatoRecebimentoDriftProvider.delete(id) ?? false;
    } else {
      return await fatoRecebimentoApiProvider.delete(id) ?? false;
    }
  }
}