import 'package:flutter/material.dart';
import 'package:get/get.dart';

import 'package:bi/app/page/shared_widget/message_dialog.dart';
import 'package:bi/app/page/grid_columns/grid_columns_imports.dart';
import 'package:bi/app/routes/app_routes.dart';
import 'package:bi/app/controller/controller_imports.dart';
import 'package:bi/app/data/model/model_imports.dart';
import 'package:bi/app/data/repository/dim_vendedor_repository.dart';

class DimVendedorController extends ControllerBase<DimVendedorModel, DimVendedorRepository> {

  DimVendedorController({required super.repository}) {
    dbColumns = DimVendedorModel.dbColumns;
    aliasColumns = DimVendedorModel.aliasColumns;
    gridColumns = dimVendedorGridColumns();
    functionName = "dim_vendedor";
    screenTitle = "Dimensão Vendedor";
  }

  @override
  DimVendedorModel createNewModel() => DimVendedorModel();

  @override
  final standardFieldForFilter = DimVendedorModel.aliasColumns[DimVendedorModel.dbColumns.indexOf('nome_vendedor')];

  final nomeVendedorController = TextEditingController();
  final equipeController = TextEditingController();
  final regiaoController = TextEditingController();

  final Map<String, dynamic> mobileConfig = {
    'primaryColumns': ['nome_vendedor'],
    'secondaryColumns': ['equipe'],
  };

  List<Map<String, dynamic>> get mobileItems {
    return modelList.map((dimVendedor) => dimVendedor.toJson).toList();
  }

  @override
  void prepareForInsert() {
    isNewRecord = true;
    currentModel = createNewModel();
    _resetForm();
    Get.toNamed(Routes.dimVendedorEditPage);
  }

  void _resetForm() {
    formWasChanged = false;
    nomeVendedorController.text = '';
    equipeController.text = '';
    regiaoController.text = '';
  }

  @override
  void selectRowForEditingById(int id) {
    final model = modelList.firstWhere((m) => m.id == id);
    currentModel = model.clone();
    updateControllersFromModel();
    Get.toNamed(Routes.dimVendedorEditPage);
  }

  void updateControllersFromModel() {
    nomeVendedorController.text = currentModel.nomeVendedor ?? '';
    equipeController.text = currentModel.equipe ?? '';
    regiaoController.text = currentModel.regiao ?? '';
    formWasChanged = false;
  }

  @override
  Future<void> save() async {
    if (!formKey.currentState!.validate()) {
      showErrorSnackBar(message: 'validator_form_message'.tr);
      return;
    }

    final existingIndex = modelList.indexWhere((m) => m.id == currentModel.id);

    if (existingIndex >= 0) {
      modelList[existingIndex] = currentModel.clone();
    }

    final result = await repository.save(dimVendedorModel: currentModel);
    if (result == null) return;

    if (existingIndex >= 0) {
      modelList[existingIndex] = result;
    } else {
      modelList.insert(0, result);
    }

    if (!GetPlatform.isMobile) {
      updateGridRow(result);
    }

    Get.back(result: true);
  }


  @override
  void onClose() {
    nomeVendedorController.dispose();
    equipeController.dispose();
    regiaoController.dispose();
    super.onClose();
  }

}