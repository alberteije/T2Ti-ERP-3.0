import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:extended_masked_text/extended_masked_text.dart';
import 'package:bi/app/page/shared_widget/input/input_imports.dart';

import 'package:bi/app/page/shared_widget/message_dialog.dart';
import 'package:bi/app/page/grid_columns/grid_columns_imports.dart';
import 'package:bi/app/routes/app_routes.dart';
import 'package:bi/app/controller/controller_imports.dart';
import 'package:bi/app/data/model/model_imports.dart';
import 'package:bi/app/data/repository/dim_tempo_repository.dart';

class DimTempoController extends ControllerBase<DimTempoModel, DimTempoRepository> {

  DimTempoController({required super.repository}) {
    dbColumns = DimTempoModel.dbColumns;
    aliasColumns = DimTempoModel.aliasColumns;
    gridColumns = dimTempoGridColumns();
    functionName = "dim_tempo";
    screenTitle = "Dimensão Tempo";
  }

  @override
  DimTempoModel createNewModel() => DimTempoModel();

  @override
  final standardFieldForFilter = DimTempoModel.aliasColumns[DimTempoModel.dbColumns.indexOf('data')];

  final dataController = DatePickerItemController(null);
  final anoController = MoneyMaskedTextController(precision: 0, decimalSeparator: '', thousandSeparator: '');
  final mesController = MoneyMaskedTextController(precision: 0, decimalSeparator: '', thousandSeparator: '');
  final nomeMesController = TextEditingController();
  final trimestreController = MoneyMaskedTextController(precision: 0, decimalSeparator: '', thousandSeparator: '');
  final diaController = MoneyMaskedTextController(precision: 0, decimalSeparator: '', thousandSeparator: '');
  final diaSemanaController = MoneyMaskedTextController(precision: 0, decimalSeparator: '', thousandSeparator: '');

  final Map<String, dynamic> mobileConfig = {
    'primaryColumns': ['data'],
    'secondaryColumns': ['ano'],
  };

  List<Map<String, dynamic>> get mobileItems {
    return modelList.map((dimTempo) => dimTempo.toJson).toList();
  }

  @override
  void prepareForInsert() {
    isNewRecord = true;
    currentModel = createNewModel();
    _resetForm();
    Get.toNamed(Routes.dimTempoEditPage);
  }

  void _resetForm() {
    formWasChanged = false;
    dataController.date = null;
    anoController.updateValue(0);
    mesController.updateValue(0);
    nomeMesController.text = '';
    trimestreController.updateValue(0);
    diaController.updateValue(0);
    diaSemanaController.updateValue(0);
  }

  @override
  void selectRowForEditingById(int id) {
    final model = modelList.firstWhere((m) => m.id == id);
    currentModel = model.clone();
    updateControllersFromModel();
    Get.toNamed(Routes.dimTempoEditPage);
  }

  void updateControllersFromModel() {
    dataController.date = currentModel.data;
    anoController.updateValue((currentModel.ano ?? 0).toDouble());
    mesController.updateValue((currentModel.mes ?? 0).toDouble());
    nomeMesController.text = currentModel.nomeMes ?? '';
    trimestreController.updateValue((currentModel.trimestre ?? 0).toDouble());
    diaController.updateValue((currentModel.dia ?? 0).toDouble());
    diaSemanaController.updateValue((currentModel.diaSemana ?? 0).toDouble());
    formWasChanged = false;
  }

  @override
  Future<void> save() async {
    if (!formKey.currentState!.validate()) {
      showErrorSnackBar(message: 'validator_form_message'.tr);
      return;
    }

    final existingIndex = modelList.indexWhere((m) => m.id == currentModel.id);

    if (existingIndex >= 0) {
      modelList[existingIndex] = currentModel.clone();
    }

    final result = await repository.save(dimTempoModel: currentModel);
    if (result == null) return;

    if (existingIndex >= 0) {
      modelList[existingIndex] = result;
    } else {
      modelList.insert(0, result);
    }

    if (!GetPlatform.isMobile) {
      updateGridRow(result);
    }

    Get.back(result: true);
  }


  @override
  void onClose() {
    dataController.dispose();
    anoController.dispose();
    mesController.dispose();
    nomeMesController.dispose();
    trimestreController.dispose();
    diaController.dispose();
    diaSemanaController.dispose();
    super.onClose();
  }

}