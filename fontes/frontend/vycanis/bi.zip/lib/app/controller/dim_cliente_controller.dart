import 'package:flutter/material.dart';
import 'package:get/get.dart';

import 'package:bi/app/page/shared_widget/message_dialog.dart';
import 'package:bi/app/page/grid_columns/grid_columns_imports.dart';
import 'package:bi/app/routes/app_routes.dart';
import 'package:bi/app/controller/controller_imports.dart';
import 'package:bi/app/data/model/model_imports.dart';
import 'package:bi/app/data/repository/dim_cliente_repository.dart';

class DimClienteController extends ControllerBase<DimClienteModel, DimClienteRepository> {

  DimClienteController({required super.repository}) {
    dbColumns = DimClienteModel.dbColumns;
    aliasColumns = DimClienteModel.aliasColumns;
    gridColumns = dimClienteGridColumns();
    functionName = "dim_cliente";
    screenTitle = "Dimensão Cliente";
  }

  @override
  DimClienteModel createNewModel() => DimClienteModel();

  @override
  final standardFieldForFilter = DimClienteModel.aliasColumns[DimClienteModel.dbColumns.indexOf('nome_cliente')];

  final nomeClienteController = TextEditingController();
  final tipoClienteController = TextEditingController();
  final cidadeController = TextEditingController();
  final estadoController = TextEditingController();
  final segmentoController = TextEditingController();

  final Map<String, dynamic> mobileConfig = {
    'primaryColumns': ['nome_cliente'],
    'secondaryColumns': ['tipo_cliente'],
  };

  List<Map<String, dynamic>> get mobileItems {
    return modelList.map((dimCliente) => dimCliente.toJson).toList();
  }

  @override
  void prepareForInsert() {
    isNewRecord = true;
    currentModel = createNewModel();
    _resetForm();
    Get.toNamed(Routes.dimClienteEditPage);
  }

  void _resetForm() {
    formWasChanged = false;
    nomeClienteController.text = '';
    tipoClienteController.text = '';
    cidadeController.text = '';
    estadoController.text = '';
    segmentoController.text = '';
  }

  @override
  void selectRowForEditingById(int id) {
    final model = modelList.firstWhere((m) => m.id == id);
    currentModel = model.clone();
    updateControllersFromModel();
    Get.toNamed(Routes.dimClienteEditPage);
  }

  void updateControllersFromModel() {
    nomeClienteController.text = currentModel.nomeCliente ?? '';
    tipoClienteController.text = currentModel.tipoCliente ?? '';
    cidadeController.text = currentModel.cidade ?? '';
    estadoController.text = currentModel.estado ?? '';
    segmentoController.text = currentModel.segmento ?? '';
    formWasChanged = false;
  }

  @override
  Future<void> save() async {
    if (!formKey.currentState!.validate()) {
      showErrorSnackBar(message: 'validator_form_message'.tr);
      return;
    }

    final existingIndex = modelList.indexWhere((m) => m.id == currentModel.id);

    if (existingIndex >= 0) {
      modelList[existingIndex] = currentModel.clone();
    }

    final result = await repository.save(dimClienteModel: currentModel);
    if (result == null) return;

    if (existingIndex >= 0) {
      modelList[existingIndex] = result;
    } else {
      modelList.insert(0, result);
    }

    if (!GetPlatform.isMobile) {
      updateGridRow(result);
    }

    Get.back(result: true);
  }


  @override
  void onClose() {
    nomeClienteController.dispose();
    tipoClienteController.dispose();
    cidadeController.dispose();
    estadoController.dispose();
    segmentoController.dispose();
    super.onClose();
  }

}