import 'package:get/get.dart';
import 'package:extended_masked_text/extended_masked_text.dart';

import 'package:bi/app/page/shared_widget/message_dialog.dart';
import 'package:bi/app/page/grid_columns/grid_columns_imports.dart';
import 'package:bi/app/routes/app_routes.dart';
import 'package:bi/app/controller/controller_imports.dart';
import 'package:bi/app/data/model/model_imports.dart';
import 'package:bi/app/data/repository/fato_venda_repository.dart';

class FatoVendaController extends ControllerBase<FatoVendaModel, FatoVendaRepository> {

  FatoVendaController({required super.repository}) {
    dbColumns = FatoVendaModel.dbColumns;
    aliasColumns = FatoVendaModel.aliasColumns;
    gridColumns = fatoVendaGridColumns();
    functionName = "fato_venda";
    screenTitle = "Fato Venda";
  }

  @override
  FatoVendaModel createNewModel() => FatoVendaModel();

  @override
  final standardFieldForFilter = FatoVendaModel.aliasColumns[FatoVendaModel.dbColumns.indexOf('id_tempo')];

  final idTempoController = MoneyMaskedTextController(precision: 0, decimalSeparator: '', thousandSeparator: '');
  final idClienteController = MoneyMaskedTextController(precision: 0, decimalSeparator: '', thousandSeparator: '');
  final idVendedorController = MoneyMaskedTextController(precision: 0, decimalSeparator: '', thousandSeparator: '');
  final idProdutoController = MoneyMaskedTextController(precision: 0, decimalSeparator: '', thousandSeparator: '');
  final quantidadeController = MoneyMaskedTextController();
  final valorTotalController = MoneyMaskedTextController();
  final custoTotalController = MoneyMaskedTextController();
  final lucroController = MoneyMaskedTextController();

  final Map<String, dynamic> mobileConfig = {
    'primaryColumns': ['id_tempo'],
    'secondaryColumns': ['id_cliente'],
  };

  List<Map<String, dynamic>> get mobileItems {
    return modelList.map((fatoVenda) => fatoVenda.toJson).toList();
  }

  @override
  void prepareForInsert() {
    isNewRecord = true;
    currentModel = createNewModel();
    _resetForm();
    Get.toNamed(Routes.fatoVendaEditPage);
  }

  void _resetForm() {
    formWasChanged = false;
    idTempoController.updateValue(0);
    idClienteController.updateValue(0);
    idVendedorController.updateValue(0);
    idProdutoController.updateValue(0);
    quantidadeController.updateValue(0);
    valorTotalController.updateValue(0);
    custoTotalController.updateValue(0);
    lucroController.updateValue(0);
  }

  @override
  void selectRowForEditingById(int id) {
    final model = modelList.firstWhere((m) => m.id == id);
    currentModel = model.clone();
    updateControllersFromModel();
    Get.toNamed(Routes.fatoVendaEditPage);
  }

  void updateControllersFromModel() {
    idTempoController.updateValue((currentModel.idTempo ?? 0).toDouble());
    idClienteController.updateValue((currentModel.idCliente ?? 0).toDouble());
    idVendedorController.updateValue((currentModel.idVendedor ?? 0).toDouble());
    idProdutoController.updateValue((currentModel.idProduto ?? 0).toDouble());
    quantidadeController.updateValue(currentModel.quantidade ?? 0);
    valorTotalController.updateValue(currentModel.valorTotal ?? 0);
    custoTotalController.updateValue(currentModel.custoTotal ?? 0);
    lucroController.updateValue(currentModel.lucro ?? 0);
    formWasChanged = false;
  }

  @override
  Future<void> save() async {
    if (!formKey.currentState!.validate()) {
      showErrorSnackBar(message: 'validator_form_message'.tr);
      return;
    }

    final existingIndex = modelList.indexWhere((m) => m.id == currentModel.id);

    if (existingIndex >= 0) {
      modelList[existingIndex] = currentModel.clone();
    }

    final result = await repository.save(fatoVendaModel: currentModel);
    if (result == null) return;

    if (existingIndex >= 0) {
      modelList[existingIndex] = result;
    } else {
      modelList.insert(0, result);
    }

    if (!GetPlatform.isMobile) {
      updateGridRow(result);
    }

    Get.back(result: true);
  }


  @override
  void onClose() {
    idTempoController.dispose();
    idClienteController.dispose();
    idVendedorController.dispose();
    idProdutoController.dispose();
    quantidadeController.dispose();
    valorTotalController.dispose();
    custoTotalController.dispose();
    lucroController.dispose();
    super.onClose();
  }

}