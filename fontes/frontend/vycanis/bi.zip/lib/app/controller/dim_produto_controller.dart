import 'package:flutter/material.dart';
import 'package:get/get.dart';

import 'package:bi/app/page/shared_widget/message_dialog.dart';
import 'package:bi/app/page/grid_columns/grid_columns_imports.dart';
import 'package:bi/app/routes/app_routes.dart';
import 'package:bi/app/controller/controller_imports.dart';
import 'package:bi/app/data/model/model_imports.dart';
import 'package:bi/app/data/repository/dim_produto_repository.dart';

class DimProdutoController extends ControllerBase<DimProdutoModel, DimProdutoRepository> {

  DimProdutoController({required super.repository}) {
    dbColumns = DimProdutoModel.dbColumns;
    aliasColumns = DimProdutoModel.aliasColumns;
    gridColumns = dimProdutoGridColumns();
    functionName = "dim_produto";
    screenTitle = "Dimensão Produto";
  }

  @override
  DimProdutoModel createNewModel() => DimProdutoModel();

  @override
  final standardFieldForFilter = DimProdutoModel.aliasColumns[DimProdutoModel.dbColumns.indexOf('descricao')];

  final descricaoController = TextEditingController();
  final categoriaController = TextEditingController();
  final marcaController = TextEditingController();

  final Map<String, dynamic> mobileConfig = {
    'primaryColumns': ['descricao'],
    'secondaryColumns': ['categoria'],
  };

  List<Map<String, dynamic>> get mobileItems {
    return modelList.map((dimProduto) => dimProduto.toJson).toList();
  }

  @override
  void prepareForInsert() {
    isNewRecord = true;
    currentModel = createNewModel();
    _resetForm();
    Get.toNamed(Routes.dimProdutoEditPage);
  }

  void _resetForm() {
    formWasChanged = false;
    descricaoController.text = '';
    categoriaController.text = '';
    marcaController.text = '';
  }

  @override
  void selectRowForEditingById(int id) {
    final model = modelList.firstWhere((m) => m.id == id);
    currentModel = model.clone();
    updateControllersFromModel();
    Get.toNamed(Routes.dimProdutoEditPage);
  }

  void updateControllersFromModel() {
    descricaoController.text = currentModel.descricao ?? '';
    categoriaController.text = currentModel.categoria ?? '';
    marcaController.text = currentModel.marca ?? '';
    formWasChanged = false;
  }

  @override
  Future<void> save() async {
    if (!formKey.currentState!.validate()) {
      showErrorSnackBar(message: 'validator_form_message'.tr);
      return;
    }

    final existingIndex = modelList.indexWhere((m) => m.id == currentModel.id);

    if (existingIndex >= 0) {
      modelList[existingIndex] = currentModel.clone();
    }

    final result = await repository.save(dimProdutoModel: currentModel);
    if (result == null) return;

    if (existingIndex >= 0) {
      modelList[existingIndex] = result;
    } else {
      modelList.insert(0, result);
    }

    if (!GetPlatform.isMobile) {
      updateGridRow(result);
    }

    Get.back(result: true);
  }


  @override
  void onClose() {
    descricaoController.dispose();
    categoriaController.dispose();
    marcaController.dispose();
    super.onClose();
  }

}