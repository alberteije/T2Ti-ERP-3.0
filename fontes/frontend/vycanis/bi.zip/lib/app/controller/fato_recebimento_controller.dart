import 'package:get/get.dart';
import 'package:extended_masked_text/extended_masked_text.dart';

import 'package:bi/app/page/shared_widget/message_dialog.dart';
import 'package:bi/app/page/grid_columns/grid_columns_imports.dart';
import 'package:bi/app/routes/app_routes.dart';
import 'package:bi/app/controller/controller_imports.dart';
import 'package:bi/app/data/model/model_imports.dart';
import 'package:bi/app/data/repository/fato_recebimento_repository.dart';

class FatoRecebimentoController extends ControllerBase<FatoRecebimentoModel, FatoRecebimentoRepository> {

  FatoRecebimentoController({required super.repository}) {
    dbColumns = FatoRecebimentoModel.dbColumns;
    aliasColumns = FatoRecebimentoModel.aliasColumns;
    gridColumns = fatoRecebimentoGridColumns();
    functionName = "fato_recebimento";
    screenTitle = "Fato Recebimento";
  }

  @override
  FatoRecebimentoModel createNewModel() => FatoRecebimentoModel();

  @override
  final standardFieldForFilter = FatoRecebimentoModel.aliasColumns[FatoRecebimentoModel.dbColumns.indexOf('id_tempo')];

  final idTempoController = MoneyMaskedTextController(precision: 0, decimalSeparator: '', thousandSeparator: '');
  final idClienteController = MoneyMaskedTextController(precision: 0, decimalSeparator: '', thousandSeparator: '');
  final valorRecebidoController = MoneyMaskedTextController();
  final valorEmAbertoController = MoneyMaskedTextController();
  final atrasoDiasController = MoneyMaskedTextController(precision: 0, decimalSeparator: '', thousandSeparator: '');

  final Map<String, dynamic> mobileConfig = {
    'primaryColumns': ['id_tempo'],
    'secondaryColumns': ['id_cliente'],
  };

  List<Map<String, dynamic>> get mobileItems {
    return modelList.map((fatoRecebimento) => fatoRecebimento.toJson).toList();
  }

  @override
  void prepareForInsert() {
    isNewRecord = true;
    currentModel = createNewModel();
    _resetForm();
    Get.toNamed(Routes.fatoRecebimentoEditPage);
  }

  void _resetForm() {
    formWasChanged = false;
    idTempoController.updateValue(0);
    idClienteController.updateValue(0);
    valorRecebidoController.updateValue(0);
    valorEmAbertoController.updateValue(0);
    atrasoDiasController.updateValue(0);
  }

  @override
  void selectRowForEditingById(int id) {
    final model = modelList.firstWhere((m) => m.id == id);
    currentModel = model.clone();
    updateControllersFromModel();
    Get.toNamed(Routes.fatoRecebimentoEditPage);
  }

  void updateControllersFromModel() {
    idTempoController.updateValue((currentModel.idTempo ?? 0).toDouble());
    idClienteController.updateValue((currentModel.idCliente ?? 0).toDouble());
    valorRecebidoController.updateValue(currentModel.valorRecebido ?? 0);
    valorEmAbertoController.updateValue(currentModel.valorEmAberto ?? 0);
    atrasoDiasController.updateValue((currentModel.atrasoDias ?? 0).toDouble());
    formWasChanged = false;
  }

  @override
  Future<void> save() async {
    if (!formKey.currentState!.validate()) {
      showErrorSnackBar(message: 'validator_form_message'.tr);
      return;
    }

    final existingIndex = modelList.indexWhere((m) => m.id == currentModel.id);

    if (existingIndex >= 0) {
      modelList[existingIndex] = currentModel.clone();
    }

    final result = await repository.save(fatoRecebimentoModel: currentModel);
    if (result == null) return;

    if (existingIndex >= 0) {
      modelList[existingIndex] = result;
    } else {
      modelList.insert(0, result);
    }

    if (!GetPlatform.isMobile) {
      updateGridRow(result);
    }

    Get.back(result: true);
  }


  @override
  void onClose() {
    idTempoController.dispose();
    idClienteController.dispose();
    valorRecebidoController.dispose();
    valorEmAbertoController.dispose();
    atrasoDiasController.dispose();
    super.onClose();
  }

}