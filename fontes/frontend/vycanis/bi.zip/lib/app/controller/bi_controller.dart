// lib/app/controller/bi_controller.dart
import 'package:get/get.dart';

class BIController extends GetxController {
  // Dados das dimensões
  final RxList<Map<String, dynamic>> clientes = <Map<String, dynamic>>[].obs;
  final RxList<Map<String, dynamic>> vendedores = <Map<String, dynamic>>[].obs;
  final RxList<Map<String, dynamic>> produtos = <Map<String, dynamic>>[].obs;
  final RxList<Map<String, dynamic>> tempo = <Map<String, dynamic>>[].obs;
  
  // Dados dos fatos
  final RxList<Map<String, dynamic>> vendas = <Map<String, dynamic>>[].obs;
  final RxList<Map<String, dynamic>> recebimentos = <Map<String, dynamic>>[].obs;
  
  // KPIs calculados
  final RxDouble totalVendas = 0.0.obs;
  final RxDouble ticketMedio = 0.0.obs;
  final RxDouble totalLucro = 0.0.obs;
  final RxDouble percentualLucro = 0.0.obs;
  final RxDouble valorEmAberto = 0.0.obs;
  final RxDouble percentualInadimplencia = 0.0.obs;
  
  // Métricas por dimensão
  final RxList<Map<String, dynamic>> vendasPorCliente = <Map<String, dynamic>>[].obs;
  final RxList<Map<String, dynamic>> vendasPorVendedor = <Map<String, dynamic>>[].obs;
  final RxList<Map<String, dynamic>> vendasPorProduto = <Map<String, dynamic>>[].obs;
  final RxList<Map<String, dynamic>> vendasPorMes = <Map<String, dynamic>>[].obs;
  
  // Filtros
  final RxString filtroPeriodo = 'Últimos 6 meses'.obs;
  final RxnInt filtroVendedorId = RxnInt();
  final RxnInt filtroClienteId = RxnInt();
  final RxnInt filtroProdutoId = RxnInt();
  
  @override
  void onInit() {
    super.onInit();
    carregarDadosBI();
  }
  
  Future<void> carregarDadosBI() async {
    // Carrega todas as dimensões e fatos
    await carregarDimensoes();
    await carregarFatos();
    await calcularKPIs();
    await calcularMetricasPorDimensao();
  }
  
  Future<void> carregarDimensoes() async {
    // Simula carregamento de dimensões
    await Future.delayed(const Duration(milliseconds: 500));
    
    // Dados de exemplo TODO: use o repository para carregar os dados
    clientes.assignAll([
      {'id_cliente': 1, 'nome_cliente': 'Supermercado Alpha', 'tipo_cliente': 'PJ', 'cidade': 'São Paulo', 'estado': 'SP', 'segmento': 'Varejo'},
      {'id_cliente': 2, 'nome_cliente': 'Loja Beta', 'tipo_cliente': 'PJ', 'cidade': 'Campinas', 'estado': 'SP', 'segmento': 'Varejo'},
      {'id_cliente': 3, 'nome_cliente': 'Cliente Final João', 'tipo_cliente': 'PF', 'cidade': 'Santos', 'estado': 'SP', 'segmento': 'Consumidor Final'},
      {'id_cliente': 4, 'nome_cliente': 'Distribuidora Gama', 'tipo_cliente': 'PJ', 'cidade': 'Ribeirão Preto', 'estado': 'SP', 'segmento': 'Atacado'},
    ]);
    
    vendedores.assignAll([
      {'id_vendedor': 1, 'nome_vendedor': 'Carlos Silva', 'equipe': 'Equipe A', 'regiao': 'Sudeste'},
      {'id_vendedor': 2, 'nome_vendedor': 'Mariana Souza', 'equipe': 'Equipe A', 'regiao': 'Sudeste'},
      {'id_vendedor': 3, 'nome_vendedor': 'João Pereira', 'equipe': 'Equipe B', 'regiao': 'Interior'},
    ]);
    
    produtos.assignAll([
      {'id_produto': 1, 'descricao': 'Arroz Tipo 1 5kg', 'categoria': 'Alimentos', 'marca': 'Marca Boa'},
      {'id_produto': 2, 'descricao': 'Feijão Carioca 1kg', 'categoria': 'Alimentos', 'marca': 'Marca Boa'},
      {'id_produto': 3, 'descricao': 'Óleo de Soja 900ml', 'categoria': 'Alimentos', 'marca': 'Marca Ótima'},
      {'id_produto': 4, 'descricao': 'Açúcar Refinado 1kg', 'categoria': 'Alimentos', 'marca': 'Marca Doce'},
    ]);
    
    tempo.assignAll([
      {'id_tempo': 1, 'data': '2024-01-15', 'ano': 2024, 'mes': 1, 'nome_mes': 'Janeiro', 'trimestre': 1, 'dia': 15, 'dia_semana': 1},
      {'id_tempo': 2, 'data': '2024-02-15', 'ano': 2024, 'mes': 2, 'nome_mes': 'Fevereiro', 'trimestre': 1, 'dia': 15, 'dia_semana': 4},
      {'id_tempo': 3, 'data': '2024-03-15', 'ano': 2024, 'mes': 3, 'nome_mes': 'Março', 'trimestre': 1, 'dia': 15, 'dia_semana': 5},
      {'id_tempo': 4, 'data': '2024-04-15', 'ano': 2024, 'mes': 4, 'nome_mes': 'Abril', 'trimestre': 2, 'dia': 15, 'dia_semana': 1},
      {'id_tempo': 5, 'data': '2024-05-15', 'ano': 2024, 'mes': 5, 'nome_mes': 'Maio', 'trimestre': 2, 'dia': 15, 'dia_semana': 3},
      {'id_tempo': 6, 'data': '2024-06-15', 'ano': 2024, 'mes': 6, 'nome_mes': 'Junho', 'trimestre': 2, 'dia': 15, 'dia_semana': 6},
    ]);
  }
  
  Future<void> carregarFatos() async {
    // Simula carregamento de fatos
    await Future.delayed(const Duration(milliseconds: 500));
    
    vendas.assignAll([
      {'id_fato': 1, 'id_tempo': 1, 'id_cliente': 1, 'id_vendedor': 1, 'id_produto': 1, 'quantidade': 100.0, 'valor_total': 2500.00, 'custo_total': 2000.00, 'lucro': 500.00},
      {'id_fato': 2, 'id_tempo': 1, 'id_cliente': 2, 'id_vendedor': 2, 'id_produto': 2, 'quantidade': 80.0, 'valor_total': 640.00, 'custo_total': 480.00, 'lucro': 160.00},
      {'id_fato': 3, 'id_tempo': 2, 'id_cliente': 3, 'id_vendedor': 1, 'id_produto': 3, 'quantidade': 50.0, 'valor_total': 450.00, 'custo_total': 350.00, 'lucro': 100.00},
      {'id_fato': 4, 'id_tempo': 3, 'id_cliente': 4, 'id_vendedor': 3, 'id_produto': 1, 'quantidade': 200.0, 'valor_total': 4800.00, 'custo_total': 3900.00, 'lucro': 900.00},
      {'id_fato': 5, 'id_tempo': 4, 'id_cliente': 1, 'id_vendedor': 2, 'id_produto': 4, 'quantidade': 150.0, 'valor_total': 525.00, 'custo_total': 400.00, 'lucro': 125.00},
      {'id_fato': 6, 'id_tempo': 5, 'id_cliente': 2, 'id_vendedor': 1, 'id_produto': 2, 'quantidade': 120.0, 'valor_total': 960.00, 'custo_total': 720.00, 'lucro': 240.00},
    ]);

    recebimentos.assignAll([
      {'id_fato': 1, 'id_tempo': 1, 'id_cliente': 1, 'valor_recebido': 2500.00, 'valor_em_aberto': 0.00, 'atraso_dias': 0},
      {'id_fato': 2, 'id_tempo': 2, 'id_cliente': 2, 'valor_recebido': 500.00, 'valor_em_aberto': 140.00, 'atraso_dias': 5},
      {'id_fato': 3, 'id_tempo': 3, 'id_cliente': 3, 'valor_recebido': 450.00, 'valor_em_aberto': 0.00, 'atraso_dias': 0},
      {'id_fato': 4, 'id_tempo': 4, 'id_cliente': 4, 'valor_recebido': 3000.00, 'valor_em_aberto': 1800.00, 'atraso_dias': 20},
      {'id_fato': 5, 'id_tempo': 5, 'id_cliente': 1, 'valor_recebido': 400.00, 'valor_em_aberto': 125.00, 'atraso_dias': 10},
    ]);
  }
  
  Future<void> calcularKPIs() async {
    // Total de vendas
    totalVendas.value = vendas.fold(0.0, (sum, venda) {
      final valor = venda['valor_total'];
      return sum + (valor is int ? valor.toDouble() : valor as double);
    });

    // Ticket médio
    final quantidadeVendas = vendas.fold(0.0, (sum, venda) {
      final quantidade = venda['quantidade'];
      return sum + (quantidade is int ? quantidade.toDouble() : quantidade as double);
    });
    
    ticketMedio.value = quantidadeVendas > 0 ? totalVendas.value / quantidadeVendas : 0;    
    
    // Total lucro
    totalLucro.value = vendas.fold(0.0, (sum, venda) {
      final lucro = venda['lucro'];
      return sum + (lucro is int ? lucro.toDouble() : lucro as double);
    });

    // Percentual de lucro
    percentualLucro.value = totalVendas.value > 0 ? (totalLucro.value / totalVendas.value) * 100 : 0;
    
    // Valor em aberto
    valorEmAberto.value = recebimentos.fold(0.0, (sum, rec) {
      final valorAberto = rec['valor_em_aberto'];
      return sum + (valorAberto is int ? valorAberto.toDouble() : valorAberto as double);
    });
        
    // Percentual de inadimplência
  final totalReceber = recebimentos.fold(0.0, (sum, rec) {
    final recebido = rec['valor_recebido'];
    final aberto = rec['valor_em_aberto'];
    final valRecebido = recebido is int ? recebido.toDouble() : recebido as double;
    final valAberto = aberto is int ? aberto.toDouble() : aberto as double;
    return sum + valRecebido + valAberto;
  });
  
  percentualInadimplencia.value = totalReceber > 0 ? (valorEmAberto.value / totalReceber) * 100 : 0;
}
  
  Future<void> calcularMetricasPorDimensao() async {
    // Vendas por cliente
    final Map<int, Map<String, dynamic>> mapClientes = {};
    for (var venda in vendas) {
      final clienteId = venda['id_cliente'] as int;
      if (!mapClientes.containsKey(clienteId)) {
        final cliente = clientes.firstWhere((c) => c['id_cliente'] == clienteId);
        mapClientes[clienteId] = {
          'cliente': cliente['nome_cliente'],
          'total_vendas': 0.0,
          'total_lucro': 0.0,
          'quantidade': 0.0,
        };
      }
      mapClientes[clienteId]!['total_vendas'] += _toDouble(venda['valor_total']);
      mapClientes[clienteId]!['total_lucro'] += _toDouble(venda['lucro']);
      mapClientes[clienteId]!['quantidade'] += _toDouble(venda['quantidade']);
    }
    vendasPorCliente.assignAll(mapClientes.values.toList()
      ..sort((a, b) => (b['total_vendas'] as double).compareTo(a['total_vendas'] as double)));
    
    // Vendas por vendedor
    final Map<int, Map<String, dynamic>> mapVendedores = {};
      for (var venda in vendas) {
        final vendedorId = venda['id_vendedor'] as int;
        if (!mapVendedores.containsKey(vendedorId)) {
          final vendedor = vendedores.firstWhere((v) => v['id_vendedor'] == vendedorId);
          mapVendedores[vendedorId] = {
            'vendedor': vendedor['nome_vendedor'],
            'total_vendas': 0.0,
            'total_lucro': 0.0,
            'quantidade': 0.0,
          };
        }
        
        mapVendedores[vendedorId]!['total_vendas'] += _toDouble(venda['valor_total']);
        mapVendedores[vendedorId]!['total_lucro'] += _toDouble(venda['lucro']);
        mapVendedores[vendedorId]!['quantidade'] += _toDouble(venda['quantidade']);
      }
    
    // Vendas por produto
    final Map<int, Map<String, dynamic>> mapProdutos = {};
      for (var venda in vendas) {
        final produtoId = venda['id_produto'] as int;
        if (!mapProdutos.containsKey(produtoId)) {
          final produto = produtos.firstWhere((p) => p['id_produto'] == produtoId);
          mapProdutos[produtoId] = {
            'produto': produto['descricao'],
            'total_vendas': 0.0,
            'total_lucro': 0.0,
            'quantidade': 0.0,
          };
        }
        
        mapProdutos[produtoId]!['total_vendas'] += _toDouble(venda['valor_total']);
        mapProdutos[produtoId]!['total_lucro'] += _toDouble(venda['lucro']);
        mapProdutos[produtoId]!['quantidade'] += _toDouble(venda['quantidade']);
      }
          
    // Vendas por mês
    final Map<int, Map<String, dynamic>> mapMeses = {};
      for (var venda in vendas) {
        final tempoId = venda['id_tempo'] as int;
        if (!mapMeses.containsKey(tempoId)) {
          final periodo = tempo.firstWhere((t) => t['id_tempo'] == tempoId);
          mapMeses[tempoId] = {
            'mes': periodo['nome_mes'],
            'total_vendas': 0.0,
            'total_lucro': 0.0,
            'quantidade': 0.0,
          };
        }
        
        mapMeses[tempoId]!['total_vendas'] += _toDouble(venda['valor_total']);
        mapMeses[tempoId]!['total_lucro'] += _toDouble(venda['lucro']);
        mapMeses[tempoId]!['quantidade'] += _toDouble(venda['quantidade']);
      }

      // Ordenar e atribuir
      vendasPorVendedor.assignAll(mapVendedores.values.toList()
        ..sort((a, b) => (b['total_vendas'] as double).compareTo(a['total_vendas'] as double)));
        
      vendasPorProduto.assignAll(mapProdutos.values.toList()
        ..sort((a, b) => (b['total_vendas'] as double).compareTo(a['total_vendas'] as double)));
        
      vendasPorMes.assignAll(mapMeses.values.toList()
        ..sort((a, b) {
          // Ordenar por ordem cronológica dos meses
          final mesesOrder = {
            'Janeiro': 1, 'Fevereiro': 2, 'Março': 3, 
            'Abril': 4, 'Maio': 5, 'Junho': 6,
          };
          final mesA = mesesOrder[a['mes']] ?? 0;
          final mesB = mesesOrder[b['mes']] ?? 0;
          return mesA.compareTo(mesB);
        }));      
  }
  

  void aplicarFiltros() {
    calcularMetricasPorDimensao(); 
  }

  double _toDouble(dynamic value) {
    if (value == null) return 0.0;
    if (value is double) return value;
    if (value is int) return value.toDouble();
    if (value is String) return double.tryParse(value) ?? 0.0;
    return 0.0;
  }  
}