// ignore_for_file: use_key_in_widget_constructors

import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:bi/app/controller/bi_controller.dart';

class BIAnaliseVendasPage extends StatelessWidget {
  final BIController controller = Get.find<BIController>();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Análise Detalhada de Vendas'),
        leading: IconButton(
          icon: const Icon(Icons.arrow_back),
          onPressed: () => Get.back(),
        ),
      ),
      body: ListView(        
        padding: const EdgeInsets.all(16),
          children: [
            // 1. Filtros Interativos (Opções avançadas)
            // _buildFiltrosSection(),
            // const SizedBox(height: 24),

            // 2. Comparativo entre Dimensões
            // _buildComparativoSection(),
            // const SizedBox(height: 24),

            // 3. Tabela Detalhada de Vendas
            _buildTabelaDetalhada(),
            const SizedBox(height: 24),

            // 4. Insights/Ações Sugeridas (Baseado nos dados)
            _buildInsightsSection(),
          ],
      ),
    );
  }

  // Widget _buildFiltrosSection() {
  //   return Card(
  //     child: Padding(
  //       padding: const EdgeInsets.all(16),
  //       child: Column(
  //         crossAxisAlignment: CrossAxisAlignment.start,
  //         children: [
  //           const Text('🔍 Filtros Avançados', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
  //           const SizedBox(height: 12),
  //           // Exemplo de filtros: período, vendedor, produto, cliente
  //           Wrap(
  //             spacing: 12,
  //             runSpacing: 12,
  //             children: [
  //               // Dropdown para período
  //               FilterChip(
  //                 label: const Text('Últimos 6 meses'),
  //                 selected: controller.filtroPeriodo.value == 'Últimos 6 meses',
  //                 onSelected: (bool selected) {
  //                   if (selected) {
  //                     controller.filtroPeriodo.value = 'Últimos 6 meses';
  //                     controller.aplicarFiltros();
  //                   }
  //                 },
  //               ),
  //               // Dropdown para vendedor
  //               // ... outros filtros
  //             ],
  //           ),
  //         ],
  //       ),
  //     ),
  //   );
  // }

  // Widget _buildComparativoSection() {
  //   return Card(
  //     child: Padding(
  //       padding: const EdgeInsets.all(16),
  //       child: Column(
  //         crossAxisAlignment: CrossAxisAlignment.start,
  //         children: [
  //           const Text('📈 Comparativo por Dimensão', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
  //           const SizedBox(height: 12),
  //           // Aqui você pode adicionar gráficos comparativos
  //           // Ex: Vendas por Vendedor vs Vendas por Produto
  //           Text('Vendas por Vendedor:', style: TextStyle(color: Colors.grey[600])),
  //           // Gráfico de barras horizontal
  //           const SizedBox(height: 20),
  //           Text('Vendas por Produto:', style: TextStyle(color: Colors.grey[600])),
  //           // Gráfico de pizza
  //         ],
  //       ),
  //     ),
  //   );
  // }

  Widget _buildTabelaDetalhada() {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text('📋 Vendas Detalhadas', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
            const SizedBox(height: 12),
            // Tabela com todas as vendas (fato_venda) com JOINs para mostrar nomes
            // Ex: Data | Cliente | Vendedor | Produto | Qtd | Valor | Lucro
            Obx(() {
              return DataTable(
                columns: const [
                  DataColumn(label: Text('Data')),
                  DataColumn(label: Text('Cliente')),
                  DataColumn(label: Text('Produto')),
                  DataColumn(label: Text('Qtd')),
                  DataColumn(label: Text('Valor'), numeric: true),
                  DataColumn(label: Text('Lucro'), numeric: true),
                ],
                rows: controller.vendas.map((venda) {
                  // Encontrar nome do cliente e produto (no real, você teria JOINs)
                  final cliente = controller.clientes.firstWhere(
                    (c) => c['id_cliente'] == venda['id_cliente'],
                    orElse: () => {'nome_cliente': 'N/A'},
                  );
                  
                  final produto = controller.produtos.firstWhere(
                    (p) => p['id_produto'] == venda['id_produto'],
                    orElse: () => {'descricao': 'N/A'},
                  );
                  
                  return DataRow(cells: [
                    DataCell(Text(venda['id_tempo'].toString())), // No real, converter para data
                    DataCell(Text(cliente['nome_cliente'])),
                    DataCell(Text(produto['descricao'])),
                    DataCell(Text(venda['quantidade'].toString())),
                    DataCell(Text('R\$${venda['valor_total']}')),
                    DataCell(Text('R\$${venda['lucro']}')),
                  ]);
                }).toList(),
              );
            }),
          ],
        ),
      ),
    );
  }

  Widget _buildInsightsSection() {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.blue[50],
        borderRadius: BorderRadius.circular(12),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text('💡 Insights & Ações Sugeridas', style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold, color: Colors.blue)),
          const SizedBox(height: 12),
          const Text('Baseado nos dados analisados:'),
          const SizedBox(height: 8),
          // Insights dinâmicos
          Obx(() {
            final topVendedor = controller.vendasPorVendedor.isNotEmpty ? controller.vendasPorVendedor.first : null;
            final topProduto = controller.vendasPorProduto.isNotEmpty ? controller.vendasPorProduto.first : null;
            
            return Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                if (topVendedor != null)
                  Text('• ${topVendedor['vendedor']} é o vendedor com mais vendas (R\$${topVendedor['total_vendas']})'),
                if (topProduto != null)
                  Text('• ${topProduto['produto']} é o produto mais vendido (${topProduto['quantidade']} unidades)'),
                if (controller.valorEmAberto.value > 0)
                  Text('• Atenção: R\$${controller.valorEmAberto.value.toStringAsFixed(2)} em aberto'),
              ],
            );
          }),
        ],
      ),
    );
  }
}