// ignore_for_file: use_key_in_widget_constructors

import 'package:flutter/material.dart';
import 'package:get/get.dart';

class BIEducacionalPage extends StatelessWidget {
  final List<Map<String, dynamic>> conceitos = [
    {
      'titulo': 'O que é BI?',
      'icone': Icons.lightbulb,
      'cor': Colors.blue,
      'conteudo': '''
Business Intelligence (BI) é o processo de transformar dados brutos em informações úteis para tomada de decisão.

No ERP T2Ti, o BI mostra:
• Dados organizados em fatos e dimensões
• KPIs (Indicadores Chave)
• Gráficos e relatórios
• Tendências e padrões
      ''',
    },
    {
      'titulo': 'Fato vs Dimensão',
      'icone': Icons.table_chart,
      'cor': Colors.green,
      'conteudo': '''
FATO: O que aconteceu
• Ex: Uma venda, um recebimento
• Contém medidas (quantidade, valor)
• Muitas linhas

DIMENSÃO: Contexto do fato
• Ex: Cliente, Produto, Tempo
• Descreve características
• Poucas linhas

Exemplo:
FATO_VENDA liga a:
• DIM_CLIENTE (quem comprou)
• DIM_PRODUTO (o que comprou)
• DIM_TEMPO (quando comprou)
      ''',
    },
    {
      'titulo': 'Como ler KPIs',
      'icone': Icons.trending_up,
      'cor': Colors.orange,
      'conteudo': '''
Ticket Médio: Valor médio por item
• Alto = vendas de maior valor
• Baixo = vendas de menor valor

Lucro %: Margem sobre vendas
• >20% = saudável
• <10% = preocupante

Inadimplência: % não recebido
• <5% = aceitável
• >15% = crítico
      ''',
    },
    {
      'titulo': 'Tomada de Decisão',
      'icone': Icons.headphones,
      'cor': Colors.purple,
      'conteudo': '''
Exemplo prático:

1. VENDEDOR X vende muito
2. Mas dá muito desconto (lucro baixo)
3. Conclusão: Treinar para vender com melhor margem

BI ajuda a:
• Identificar problemas
• Encontrar oportunidades
• Medir resultados
• Planejar estratégias
      ''',
    },
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Aprenda sobre BI'),
        leading: IconButton(
          icon: const Icon(Icons.arrow_back),
          onPressed: () => Get.back(),
        ),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text(
              '📚 Business Intelligence Didático',
              style: TextStyle(
                fontSize: 24,
                fontWeight: FontWeight.bold,
              ),
            ),
            const SizedBox(height: 8),
            const Text(
              'Entenda os conceitos por trás dos números',
              style: TextStyle(
                fontSize: 16,
                color: Colors.grey,
              ),
            ),
            const SizedBox(height: 24),

            ...conceitos.map((conceito) {
              return Card(
                margin: const EdgeInsets.only(bottom: 16),
                elevation: 4,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Padding(
                  padding: const EdgeInsets.all(16),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        children: [
                          Container(
                            padding: const EdgeInsets.all(8),
                            decoration: BoxDecoration(
                              color: conceito['cor'].withOpacity(0.1),
                              borderRadius: BorderRadius.circular(8),
                            ),
                            child: Icon(
                              conceito['icone'] as IconData,
                              color: conceito['cor'] as Color,
                              size: 24,
                            ),
                          ),
                          const SizedBox(width: 12),
                          Text(
                            conceito['titulo'] as String,
                            style: const TextStyle(
                              fontSize: 18,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 16),
                      Text(
                        conceito['conteudo'] as String,
                        style: const TextStyle(fontSize: 14, height: 1.5),
                      ),
                    ],
                  ),
                ),
              );
            }).toList(),

            const SizedBox(height: 24),
            Container(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: Colors.green[50],
                borderRadius: BorderRadius.circular(12),
                border: Border.all(color: Colors.green[100]!),
              ),
              child: const Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    '🎯 Próximos Passos',
                    style: TextStyle(
                      fontWeight: FontWeight.bold,
                      color: Colors.green,
                    ),
                  ),
                  SizedBox(height: 8),
                  Text('1. Explore o Dashboard BI\n'
                      '2. Clique em "Análise Detalhada"\n'
                      '3. Filtre por diferentes dimensões\n'
                      '4. Tente identificar padrões\n'
                      '5. Pense em ações baseadas nos dados'),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}