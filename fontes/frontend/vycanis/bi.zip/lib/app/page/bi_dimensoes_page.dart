// ignore_for_file: use_key_in_widget_constructors, library_private_types_in_public_api

import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:bi/app/controller/bi_controller.dart';

class BIDimensoesPage extends StatefulWidget {
  @override
  _BIDimensoesPageState createState() => _BIDimensoesPageState();
}

class _BIDimensoesPageState extends State<BIDimensoesPage> 
    with SingleTickerProviderStateMixin {  // ← Adicionar mixin
  final BIController controller = Get.find<BIController>();
  late TabController _tabController;

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 4, vsync: this);
  }

  @override
  void dispose() {
    _tabController.dispose();
    super.dispose();
  }
  
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Dimensões do BI'),
        leading: IconButton(
          icon: const Icon(Icons.arrow_back),
          onPressed: () => Get.back(),
        ),
        bottom: TabBar(
          controller: _tabController,
          tabs: const [
            Tab(text: 'Clientes', icon: Icon(Icons.people)),
            Tab(text: 'Vendedores', icon: Icon(Icons.person)),
            Tab(text: 'Produtos', icon: Icon(Icons.shopping_cart)),
            Tab(text: 'Tempo', icon: Icon(Icons.calendar_today)),
          ],
        ),
      ),
      body: TabBarView(
        controller: _tabController,
        children: [
          _buildClientesTab(),
          _buildVendedoresTab(),
          _buildProdutosTab(),
          _buildTempoTab(),
        ],
      ),
    );
  }

  Widget _buildClientesTab() {
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        const Text(
          '📋 Dimensão Cliente',
          style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
        ),
        const SizedBox(height: 8),
        const Text(
          'Cadastro de clientes usado para análise. Cada venda é ligada a um cliente.',
          style: TextStyle(color: Colors.grey),
        ),
        const SizedBox(height: 16),
        ...controller.clientes.map((cliente) {
          return Card(
            margin: const EdgeInsets.only(bottom: 8),
            child: ListTile(
              leading: CircleAvatar(
                backgroundColor: Colors.blue[100],
                child: Text(cliente['nome_cliente'].toString().substring(0, 1)),
              ),
              title: Text(cliente['nome_cliente'] as String),
              subtitle: Text(
                '${cliente['tipo_cliente']} • ${cliente['cidade']}/${cliente['estado']}\nSegmento: ${cliente['segmento']}',
              ),
              trailing: const Icon(Icons.visibility, color: Colors.grey),
            ),
          );
        }).toList(),
      ],
    );
  }

  Widget _buildVendedoresTab() {
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        const Text(
          '👥 Dimensão Vendedor',
          style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
        ),
        const SizedBox(height: 8),
        const Text(
          'Equipe de vendedores. Cada venda é atribuída a um vendedor.',
          style: TextStyle(color: Colors.grey),
        ),
        const SizedBox(height: 16),
        ...controller.vendedores.map((vendedor) {
          return Card(
            margin: const EdgeInsets.only(bottom: 8),
            child: ListTile(
              leading: CircleAvatar(
                backgroundColor: Colors.green[100],
                child: Text(vendedor['nome_vendedor'].toString().substring(0, 1)),
              ),
              title: Text(vendedor['nome_vendedor'] as String),
              subtitle: Text(
                '${vendedor['equipe']} • ${vendedor['regiao']}',
              ),
              trailing: Chip(
                label: const Text('Vendedor'),
                backgroundColor: Colors.green[50],
              ),
            ),
          );
        }).toList(),
      ],
    );
  }

  Widget _buildProdutosTab() {
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        const Text(
          '🛒 Dimensão Produto',
          style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
        ),
        const SizedBox(height: 8),
        const Text(
          'Catálogo de produtos. Cada item vendido é um produto.',
          style: TextStyle(color: Colors.grey),
        ),
        const SizedBox(height: 16),
        ...controller.produtos.map((produto) {
          return Card(
            margin: const EdgeInsets.only(bottom: 8),
            child: ListTile(
              leading: CircleAvatar(
                backgroundColor: Colors.orange[100],
                child: const Icon(Icons.shopping_basket, size: 20),
              ),
              title: Text(produto['descricao'] as String),
              subtitle: Text(
                '${produto['categoria']} • ${produto['marca']}',
              ),
              trailing: const Icon(Icons.inventory, color: Colors.grey),
            ),
          );
        }).toList(),
      ],
    );
  }

  Widget _buildTempoTab() {
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        const Text(
          '📅 Dimensão Tempo',
          style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
        ),
        const SizedBox(height: 8),
        const Text(
          'Calendário para análise temporal. Cada fato tem uma data.',
          style: TextStyle(color: Colors.grey),
        ),
        const SizedBox(height: 16),
        ...controller.tempo.map((periodo) {
          return Card(
            margin: const EdgeInsets.only(bottom: 8),
            child: ListTile(
              leading: CircleAvatar(
                backgroundColor: Colors.purple[100],
                child: Text(periodo['mes'].toString()),
              ),
              title: Text('${periodo['nome_mes']} ${periodo['ano']}'),
              subtitle: Text(
                'Dia ${periodo['dia']} • Trimestre ${periodo['trimestre']}',
              ),
              trailing: Chip(
                label: Text('Dia Semana: ${periodo['dia_semana']}º'),
                backgroundColor: Colors.purple[50],
              ),
            ),
          );
        }).toList(),
      ],
    );
  }
}