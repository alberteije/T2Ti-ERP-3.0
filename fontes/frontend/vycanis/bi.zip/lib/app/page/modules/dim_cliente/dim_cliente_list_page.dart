import 'package:flutter/material.dart';
import 'package:bi/app/controller/dim_cliente_controller.dart';
import 'package:bi/app/page/shared_page/list_page_base.dart';

class DimClienteListPage extends ListPageBase<DimClienteController> {
  const DimClienteListPage({Key? key}) : super(key: key);

  @override
  List<Map<String, dynamic>> get mobileItems => controller.mobileItems;

  @override
  Map<String, dynamic> get mobileConfig => controller.mobileConfig;

  @override
  String get standardFieldForFilter => controller.standardFieldForFilter;
}