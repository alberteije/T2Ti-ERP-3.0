import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_bootstrap/flutter_bootstrap.dart';
import 'package:get/get.dart';
import 'package:bi/app/page/shared_widget/shared_widget_imports.dart';
import 'package:bi/app/controller/dim_tempo_controller.dart';
import 'package:bi/app/infra/infra_imports.dart';
import 'package:bi/app/page/shared_widget/input/input_imports.dart';

class DimTempoEditPage extends StatelessWidget {
	DimTempoEditPage({Key? key}) : super(key: key);
	final dimTempoController = Get.find<DimTempoController>();

	@override
	Widget build(BuildContext context) {
		return KeyboardListener(
			autofocus: false,
			focusNode: FocusNode(),
			onKeyEvent: (event) {
				if (event.logicalKey == LogicalKeyboardKey.escape) {
					dimTempoController.preventDataLoss();
				}
			},
			child: Scaffold(
				key: dimTempoController.scaffoldKey,
				appBar: AppBar(
					automaticallyImplyLeading: false,
					title: Text('${ dimTempoController.screenTitle } - ${ dimTempoController.isNewRecord ? 'inserting'.tr : 'editing'.tr }',),
					actions: [
						saveButton(onPressed: dimTempoController.save),
						cancelAndExitButton(onPressed: dimTempoController.preventDataLoss),
					]
				),
				body: SafeArea(
					top: false,
					bottom: false,
					child: Form(
						key: dimTempoController.formKey,
						autovalidateMode: AutovalidateMode.always,
						child: Scrollbar(
							controller: dimTempoController.scrollController,
							child: SingleChildScrollView(
								controller: dimTempoController.scrollController,
								child: BootstrapContainer(
									fluid: true,
									padding: const EdgeInsets.fromLTRB(10.0, 10.0, 10.0, 10.0),
									children: <Widget>[
										const Divider(
											color: Colors.transparent,
										),
										BootstrapRow(
											height: 60,
											children: <BootstrapCol>[
												BootstrapCol(
													sizes: 'col-12',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: InputDecorator(
															decoration: inputDecoration(
																hintText: 'Informe os dados para o campo Data',
																labelText: 'Data',
																usePadding: true,
															),
															isEmpty: false,
															child: DatePickerItem(
																controller: dimTempoController.dataController,
																firstDate: DateTime.parse('1000-01-01'),
																lastDate: DateTime.parse('5000-01-01'),
																onChanged: (DateTime? value) {
																	dimTempoController.currentModel.data = value;
																	dimTempoController.formWasChanged = true;
																},
															),
														),
													),
												),
											],
										),
										const Divider(
											color: Colors.transparent,
										),
										BootstrapRow(
											height: 60,
											children: <BootstrapCol>[
												BootstrapCol(
													sizes: 'col-12',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: TextFormField(
															autofocus: true,
															controller: dimTempoController.anoController,
															decoration: inputDecoration(
																hintText: 'Informe os dados para o campo Ano',
																labelText: 'Ano',
																usePadding: true,
															),
															onSaved: (String? value) {},
															onChanged: (text) {
																dimTempoController.currentModel.ano = int.tryParse(text);
																dimTempoController.formWasChanged = true;
															},
														),
													),
												),
											],
										),
										const Divider(
											color: Colors.transparent,
										),
										BootstrapRow(
											height: 60,
											children: <BootstrapCol>[
												BootstrapCol(
													sizes: 'col-12',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: TextFormField(
															autofocus: true,
															controller: dimTempoController.mesController,
															decoration: inputDecoration(
																hintText: 'Informe os dados para o campo Mes',
																labelText: 'Mes',
																usePadding: true,
															),
															onSaved: (String? value) {},
															onChanged: (text) {
																dimTempoController.currentModel.mes = int.tryParse(text);
																dimTempoController.formWasChanged = true;
															},
														),
													),
												),
											],
										),
										const Divider(
											color: Colors.transparent,
										),
										BootstrapRow(
											height: 60,
											children: <BootstrapCol>[
												BootstrapCol(
													sizes: 'col-12',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: TextFormField(
															autofocus: true,
															controller: dimTempoController.nomeMesController,
															decoration: inputDecoration(
																hintText: 'Informe os dados para o campo Nome Mes',
																labelText: 'Nome Mes',
																usePadding: true,
															),
															onSaved: (String? value) {},
															onChanged: (text) {
																dimTempoController.currentModel.nomeMes = text;
																dimTempoController.formWasChanged = true;
															},
														),
													),
												),
											],
										),
										const Divider(
											color: Colors.transparent,
										),
										BootstrapRow(
											height: 60,
											children: <BootstrapCol>[
												BootstrapCol(
													sizes: 'col-12',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: TextFormField(
															autofocus: true,
															controller: dimTempoController.trimestreController,
															decoration: inputDecoration(
																hintText: 'Informe os dados para o campo Trimestre',
																labelText: 'Trimestre',
																usePadding: true,
															),
															onSaved: (String? value) {},
															onChanged: (text) {
																dimTempoController.currentModel.trimestre = int.tryParse(text);
																dimTempoController.formWasChanged = true;
															},
														),
													),
												),
											],
										),
										const Divider(
											color: Colors.transparent,
										),
										BootstrapRow(
											height: 60,
											children: <BootstrapCol>[
												BootstrapCol(
													sizes: 'col-12',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: TextFormField(
															autofocus: true,
															controller: dimTempoController.diaController,
															decoration: inputDecoration(
																hintText: 'Informe os dados para o campo Dia',
																labelText: 'Dia',
																usePadding: true,
															),
															onSaved: (String? value) {},
															onChanged: (text) {
																dimTempoController.currentModel.dia = int.tryParse(text);
																dimTempoController.formWasChanged = true;
															},
														),
													),
												),
											],
										),
										const Divider(
											color: Colors.transparent,
										),
										BootstrapRow(
											height: 60,
											children: <BootstrapCol>[
												BootstrapCol(
													sizes: 'col-12',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: TextFormField(
															autofocus: true,
															controller: dimTempoController.diaSemanaController,
															decoration: inputDecoration(
																hintText: 'Informe os dados para o campo Dia Semana',
																labelText: 'Dia Semana',
																usePadding: true,
															),
															onSaved: (String? value) {},
															onChanged: (text) {
																dimTempoController.currentModel.diaSemana = int.tryParse(text);
																dimTempoController.formWasChanged = true;
															},
														),
													),
												),
											],
										),
										const Divider(
											indent: 10,
											endIndent: 10,
											thickness: 2,
										),
										BootstrapRow(
											height: 60,
											children: <BootstrapCol>[
												BootstrapCol(
													sizes: 'col-12',
													child: Text(
														'field_is_mandatory'.tr,
														style: Theme.of(context).textTheme.bodySmall,
													),
												),
											],
										),
										const SizedBox(height: 10.0),
									],
								),
							),
						),
					),
				),
			),
		);
	}
}
