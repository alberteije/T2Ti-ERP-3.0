import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_bootstrap/flutter_bootstrap.dart';
import 'package:get/get.dart';
import 'package:bi/app/page/shared_widget/shared_widget_imports.dart';
import 'package:bi/app/controller/fato_recebimento_controller.dart';
import 'package:bi/app/infra/infra_imports.dart';
import 'package:bi/app/page/shared_widget/input/input_imports.dart';

class FatoRecebimentoEditPage extends StatelessWidget {
	FatoRecebimentoEditPage({Key? key}) : super(key: key);
	final fatoRecebimentoController = Get.find<FatoRecebimentoController>();

	@override
	Widget build(BuildContext context) {
		return KeyboardListener(
			autofocus: false,
			focusNode: FocusNode(),
			onKeyEvent: (event) {
				if (event.logicalKey == LogicalKeyboardKey.escape) {
					fatoRecebimentoController.preventDataLoss();
				}
			},
			child: Scaffold(
				key: fatoRecebimentoController.scaffoldKey,
				appBar: AppBar(
					automaticallyImplyLeading: false,
					title: Text('${ fatoRecebimentoController.screenTitle } - ${ fatoRecebimentoController.isNewRecord ? 'inserting'.tr : 'editing'.tr }',),
					actions: [
						saveButton(onPressed: fatoRecebimentoController.save),
						cancelAndExitButton(onPressed: fatoRecebimentoController.preventDataLoss),
					]
				),
				body: SafeArea(
					top: false,
					bottom: false,
					child: Form(
						key: fatoRecebimentoController.formKey,
						autovalidateMode: AutovalidateMode.always,
						child: Scrollbar(
							controller: fatoRecebimentoController.scrollController,
							child: SingleChildScrollView(
								controller: fatoRecebimentoController.scrollController,
								child: BootstrapContainer(
									fluid: true,
									padding: const EdgeInsets.fromLTRB(10.0, 10.0, 10.0, 10.0),
									children: <Widget>[
										const Divider(
											color: Colors.transparent,
										),
										BootstrapRow(
											height: 60,
											children: <BootstrapCol>[
												BootstrapCol(
													sizes: 'col-12',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: TextFormField(
															autofocus: true,
															controller: fatoRecebimentoController.idTempoController,
															decoration: inputDecoration(
																hintText: 'Informe os dados para o campo Id Tempo',
																labelText: 'Id Tempo',
																usePadding: true,
															),
															onSaved: (String? value) {},
															onChanged: (text) {
																fatoRecebimentoController.currentModel.idTempo = int.tryParse(text);
																fatoRecebimentoController.formWasChanged = true;
															},
														),
													),
												),
											],
										),
										const Divider(
											color: Colors.transparent,
										),
										BootstrapRow(
											height: 60,
											children: <BootstrapCol>[
												BootstrapCol(
													sizes: 'col-12',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: TextFormField(
															autofocus: true,
															controller: fatoRecebimentoController.idClienteController,
															decoration: inputDecoration(
																hintText: 'Informe os dados para o campo Id Cliente',
																labelText: 'Id Cliente',
																usePadding: true,
															),
															onSaved: (String? value) {},
															onChanged: (text) {
																fatoRecebimentoController.currentModel.idCliente = int.tryParse(text);
																fatoRecebimentoController.formWasChanged = true;
															},
														),
													),
												),
											],
										),
										const Divider(
											color: Colors.transparent,
										),
										BootstrapRow(
											height: 60,
											children: <BootstrapCol>[
												BootstrapCol(
													sizes: 'col-12',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: TextFormField(
															autofocus: true,
															controller: fatoRecebimentoController.valorRecebidoController,
															decoration: inputDecoration(
																hintText: 'Informe os dados para o campo Valor Recebido',
																labelText: 'Valor Recebido',
																usePadding: true,
															),
															onSaved: (String? value) {},
															onChanged: (text) {
																fatoRecebimentoController.currentModel.valorRecebido = fatoRecebimentoController.valorRecebidoController.numberValue;
																fatoRecebimentoController.formWasChanged = true;
															},
														),
													),
												),
											],
										),
										const Divider(
											color: Colors.transparent,
										),
										BootstrapRow(
											height: 60,
											children: <BootstrapCol>[
												BootstrapCol(
													sizes: 'col-12',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: TextFormField(
															autofocus: true,
															controller: fatoRecebimentoController.valorEmAbertoController,
															decoration: inputDecoration(
																hintText: 'Informe os dados para o campo Valor Em Aberto',
																labelText: 'Valor Em Aberto',
																usePadding: true,
															),
															onSaved: (String? value) {},
															onChanged: (text) {
																fatoRecebimentoController.currentModel.valorEmAberto = fatoRecebimentoController.valorEmAbertoController.numberValue;
																fatoRecebimentoController.formWasChanged = true;
															},
														),
													),
												),
											],
										),
										const Divider(
											color: Colors.transparent,
										),
										BootstrapRow(
											height: 60,
											children: <BootstrapCol>[
												BootstrapCol(
													sizes: 'col-12',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: TextFormField(
															autofocus: true,
															controller: fatoRecebimentoController.atrasoDiasController,
															decoration: inputDecoration(
																hintText: 'Informe os dados para o campo Atraso Dias',
																labelText: 'Atraso Dias',
																usePadding: true,
															),
															onSaved: (String? value) {},
															onChanged: (text) {
																fatoRecebimentoController.currentModel.atrasoDias = int.tryParse(text);
																fatoRecebimentoController.formWasChanged = true;
															},
														),
													),
												),
											],
										),
										const Divider(
											indent: 10,
											endIndent: 10,
											thickness: 2,
										),
										BootstrapRow(
											height: 60,
											children: <BootstrapCol>[
												BootstrapCol(
													sizes: 'col-12',
													child: Text(
														'field_is_mandatory'.tr,
														style: Theme.of(context).textTheme.bodySmall,
													),
												),
											],
										),
										const SizedBox(height: 10.0),
									],
								),
							),
						),
					),
				),
			),
		);
	}
}
