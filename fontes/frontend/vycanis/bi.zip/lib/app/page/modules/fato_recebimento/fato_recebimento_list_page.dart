import 'package:flutter/material.dart';
import 'package:bi/app/controller/fato_recebimento_controller.dart';
import 'package:bi/app/page/shared_page/list_page_base.dart';

class FatoRecebimentoListPage extends ListPageBase<FatoRecebimentoController> {
  const FatoRecebimentoListPage({Key? key}) : super(key: key);

  @override
  List<Map<String, dynamic>> get mobileItems => controller.mobileItems;

  @override
  Map<String, dynamic> get mobileConfig => controller.mobileConfig;

  @override
  String get standardFieldForFilter => controller.standardFieldForFilter;
}