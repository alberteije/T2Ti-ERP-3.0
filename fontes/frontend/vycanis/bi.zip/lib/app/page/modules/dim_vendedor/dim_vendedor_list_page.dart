import 'package:flutter/material.dart';
import 'package:bi/app/controller/dim_vendedor_controller.dart';
import 'package:bi/app/page/shared_page/list_page_base.dart';

class DimVendedorListPage extends ListPageBase<DimVendedorController> {
  const DimVendedorListPage({Key? key}) : super(key: key);

  @override
  List<Map<String, dynamic>> get mobileItems => controller.mobileItems;

  @override
  Map<String, dynamic> get mobileConfig => controller.mobileConfig;

  @override
  String get standardFieldForFilter => controller.standardFieldForFilter;
}