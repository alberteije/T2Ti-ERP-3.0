import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_bootstrap/flutter_bootstrap.dart';
import 'package:get/get.dart';
import 'package:bi/app/page/shared_widget/shared_widget_imports.dart';
import 'package:bi/app/controller/fato_venda_controller.dart';
import 'package:bi/app/infra/infra_imports.dart';
import 'package:bi/app/page/shared_widget/input/input_imports.dart';

class FatoVendaEditPage extends StatelessWidget {
	FatoVendaEditPage({Key? key}) : super(key: key);
	final fatoVendaController = Get.find<FatoVendaController>();

	@override
	Widget build(BuildContext context) {
		return KeyboardListener(
			autofocus: false,
			focusNode: FocusNode(),
			onKeyEvent: (event) {
				if (event.logicalKey == LogicalKeyboardKey.escape) {
					fatoVendaController.preventDataLoss();
				}
			},
			child: Scaffold(
				key: fatoVendaController.scaffoldKey,
				appBar: AppBar(
					automaticallyImplyLeading: false,
					title: Text('${ fatoVendaController.screenTitle } - ${ fatoVendaController.isNewRecord ? 'inserting'.tr : 'editing'.tr }',),
					actions: [
						saveButton(onPressed: fatoVendaController.save),
						cancelAndExitButton(onPressed: fatoVendaController.preventDataLoss),
					]
				),
				body: SafeArea(
					top: false,
					bottom: false,
					child: Form(
						key: fatoVendaController.formKey,
						autovalidateMode: AutovalidateMode.always,
						child: Scrollbar(
							controller: fatoVendaController.scrollController,
							child: SingleChildScrollView(
								controller: fatoVendaController.scrollController,
								child: BootstrapContainer(
									fluid: true,
									padding: const EdgeInsets.fromLTRB(10.0, 10.0, 10.0, 10.0),
									children: <Widget>[
										const Divider(
											color: Colors.transparent,
										),
										BootstrapRow(
											height: 60,
											children: <BootstrapCol>[
												BootstrapCol(
													sizes: 'col-12',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: TextFormField(
															autofocus: true,
															controller: fatoVendaController.idTempoController,
															decoration: inputDecoration(
																hintText: 'Informe os dados para o campo Id Tempo',
																labelText: 'Id Tempo',
																usePadding: true,
															),
															onSaved: (String? value) {},
															onChanged: (text) {
																fatoVendaController.currentModel.idTempo = int.tryParse(text);
																fatoVendaController.formWasChanged = true;
															},
														),
													),
												),
											],
										),
										const Divider(
											color: Colors.transparent,
										),
										BootstrapRow(
											height: 60,
											children: <BootstrapCol>[
												BootstrapCol(
													sizes: 'col-12',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: TextFormField(
															autofocus: true,
															controller: fatoVendaController.idClienteController,
															decoration: inputDecoration(
																hintText: 'Informe os dados para o campo Id Cliente',
																labelText: 'Id Cliente',
																usePadding: true,
															),
															onSaved: (String? value) {},
															onChanged: (text) {
																fatoVendaController.currentModel.idCliente = int.tryParse(text);
																fatoVendaController.formWasChanged = true;
															},
														),
													),
												),
											],
										),
										const Divider(
											color: Colors.transparent,
										),
										BootstrapRow(
											height: 60,
											children: <BootstrapCol>[
												BootstrapCol(
													sizes: 'col-12',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: TextFormField(
															autofocus: true,
															controller: fatoVendaController.idVendedorController,
															decoration: inputDecoration(
																hintText: 'Informe os dados para o campo Id Vendedor',
																labelText: 'Id Vendedor',
																usePadding: true,
															),
															onSaved: (String? value) {},
															onChanged: (text) {
																fatoVendaController.currentModel.idVendedor = int.tryParse(text);
																fatoVendaController.formWasChanged = true;
															},
														),
													),
												),
											],
										),
										const Divider(
											color: Colors.transparent,
										),
										BootstrapRow(
											height: 60,
											children: <BootstrapCol>[
												BootstrapCol(
													sizes: 'col-12',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: TextFormField(
															autofocus: true,
															controller: fatoVendaController.idProdutoController,
															decoration: inputDecoration(
																hintText: 'Informe os dados para o campo Id Produto',
																labelText: 'Id Produto',
																usePadding: true,
															),
															onSaved: (String? value) {},
															onChanged: (text) {
																fatoVendaController.currentModel.idProduto = int.tryParse(text);
																fatoVendaController.formWasChanged = true;
															},
														),
													),
												),
											],
										),
										const Divider(
											color: Colors.transparent,
										),
										BootstrapRow(
											height: 60,
											children: <BootstrapCol>[
												BootstrapCol(
													sizes: 'col-12',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: TextFormField(
															autofocus: true,
															controller: fatoVendaController.quantidadeController,
															decoration: inputDecoration(
																hintText: 'Informe os dados para o campo Quantidade',
																labelText: 'Quantidade',
																usePadding: true,
															),
															onSaved: (String? value) {},
															onChanged: (text) {
																fatoVendaController.currentModel.quantidade = fatoVendaController.quantidadeController.numberValue;
																fatoVendaController.formWasChanged = true;
															},
														),
													),
												),
											],
										),
										const Divider(
											color: Colors.transparent,
										),
										BootstrapRow(
											height: 60,
											children: <BootstrapCol>[
												BootstrapCol(
													sizes: 'col-12',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: TextFormField(
															autofocus: true,
															controller: fatoVendaController.valorTotalController,
															decoration: inputDecoration(
																hintText: 'Informe os dados para o campo Valor Total',
																labelText: 'Valor Total',
																usePadding: true,
															),
															onSaved: (String? value) {},
															onChanged: (text) {
																fatoVendaController.currentModel.valorTotal = fatoVendaController.valorTotalController.numberValue;
																fatoVendaController.formWasChanged = true;
															},
														),
													),
												),
											],
										),
										const Divider(
											color: Colors.transparent,
										),
										BootstrapRow(
											height: 60,
											children: <BootstrapCol>[
												BootstrapCol(
													sizes: 'col-12',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: TextFormField(
															autofocus: true,
															controller: fatoVendaController.custoTotalController,
															decoration: inputDecoration(
																hintText: 'Informe os dados para o campo Custo Total',
																labelText: 'Custo Total',
																usePadding: true,
															),
															onSaved: (String? value) {},
															onChanged: (text) {
																fatoVendaController.currentModel.custoTotal = fatoVendaController.custoTotalController.numberValue;
																fatoVendaController.formWasChanged = true;
															},
														),
													),
												),
											],
										),
										const Divider(
											color: Colors.transparent,
										),
										BootstrapRow(
											height: 60,
											children: <BootstrapCol>[
												BootstrapCol(
													sizes: 'col-12',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: TextFormField(
															autofocus: true,
															controller: fatoVendaController.lucroController,
															decoration: inputDecoration(
																hintText: 'Informe os dados para o campo Lucro',
																labelText: 'Lucro',
																usePadding: true,
															),
															onSaved: (String? value) {},
															onChanged: (text) {
																fatoVendaController.currentModel.lucro = fatoVendaController.lucroController.numberValue;
																fatoVendaController.formWasChanged = true;
															},
														),
													),
												),
											],
										),
										const Divider(
											indent: 10,
											endIndent: 10,
											thickness: 2,
										),
										BootstrapRow(
											height: 60,
											children: <BootstrapCol>[
												BootstrapCol(
													sizes: 'col-12',
													child: Text(
														'field_is_mandatory'.tr,
														style: Theme.of(context).textTheme.bodySmall,
													),
												),
											],
										),
										const SizedBox(height: 10.0),
									],
								),
							),
						),
					),
				),
			),
		);
	}
}
