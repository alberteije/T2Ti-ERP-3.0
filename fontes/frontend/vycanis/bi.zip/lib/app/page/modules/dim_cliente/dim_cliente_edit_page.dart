import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_bootstrap/flutter_bootstrap.dart';
import 'package:get/get.dart';
import 'package:bi/app/page/shared_widget/shared_widget_imports.dart';
import 'package:bi/app/controller/dim_cliente_controller.dart';
import 'package:bi/app/infra/infra_imports.dart';
import 'package:bi/app/page/shared_widget/input/input_imports.dart';

class DimClienteEditPage extends StatelessWidget {
	DimClienteEditPage({Key? key}) : super(key: key);
	final dimClienteController = Get.find<DimClienteController>();

	@override
	Widget build(BuildContext context) {
		return KeyboardListener(
			autofocus: false,
			focusNode: FocusNode(),
			onKeyEvent: (event) {
				if (event.logicalKey == LogicalKeyboardKey.escape) {
					dimClienteController.preventDataLoss();
				}
			},
			child: Scaffold(
				key: dimClienteController.scaffoldKey,
				appBar: AppBar(
					automaticallyImplyLeading: false,
					title: Text('${ dimClienteController.screenTitle } - ${ dimClienteController.isNewRecord ? 'inserting'.tr : 'editing'.tr }',),
					actions: [
						saveButton(onPressed: dimClienteController.save),
						cancelAndExitButton(onPressed: dimClienteController.preventDataLoss),
					]
				),
				body: SafeArea(
					top: false,
					bottom: false,
					child: Form(
						key: dimClienteController.formKey,
						autovalidateMode: AutovalidateMode.always,
						child: Scrollbar(
							controller: dimClienteController.scrollController,
							child: SingleChildScrollView(
								controller: dimClienteController.scrollController,
								child: BootstrapContainer(
									fluid: true,
									padding: const EdgeInsets.fromLTRB(10.0, 10.0, 10.0, 10.0),
									children: <Widget>[
										const Divider(
											color: Colors.transparent,
										),
										BootstrapRow(
											height: 60,
											children: <BootstrapCol>[
												BootstrapCol(
													sizes: 'col-12',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: TextFormField(
															autofocus: true,
															controller: dimClienteController.nomeClienteController,
															decoration: inputDecoration(
																hintText: 'Informe os dados para o campo Nome Cliente',
																labelText: 'Nome Cliente',
																usePadding: true,
															),
															onSaved: (String? value) {},
															onChanged: (text) {
																dimClienteController.currentModel.nomeCliente = text;
																dimClienteController.formWasChanged = true;
															},
														),
													),
												),
											],
										),
										const Divider(
											color: Colors.transparent,
										),
										BootstrapRow(
											height: 60,
											children: <BootstrapCol>[
												BootstrapCol(
													sizes: 'col-12',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: TextFormField(
															autofocus: true,
															controller: dimClienteController.tipoClienteController,
															decoration: inputDecoration(
																hintText: 'Informe os dados para o campo Tipo Cliente',
																labelText: 'Tipo Cliente',
																usePadding: true,
															),
															onSaved: (String? value) {},
															onChanged: (text) {
																dimClienteController.currentModel.tipoCliente = text;
																dimClienteController.formWasChanged = true;
															},
														),
													),
												),
											],
										),
										const Divider(
											color: Colors.transparent,
										),
										BootstrapRow(
											height: 60,
											children: <BootstrapCol>[
												BootstrapCol(
													sizes: 'col-12',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: TextFormField(
															autofocus: true,
															controller: dimClienteController.cidadeController,
															decoration: inputDecoration(
																hintText: 'Informe os dados para o campo Cidade',
																labelText: 'Cidade',
																usePadding: true,
															),
															onSaved: (String? value) {},
															onChanged: (text) {
																dimClienteController.currentModel.cidade = text;
																dimClienteController.formWasChanged = true;
															},
														),
													),
												),
											],
										),
										const Divider(
											color: Colors.transparent,
										),
										BootstrapRow(
											height: 60,
											children: <BootstrapCol>[
												BootstrapCol(
													sizes: 'col-12',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: TextFormField(
															autofocus: true,
															controller: dimClienteController.estadoController,
															decoration: inputDecoration(
																hintText: 'Informe os dados para o campo Estado',
																labelText: 'Estado',
																usePadding: true,
															),
															onSaved: (String? value) {},
															onChanged: (text) {
																dimClienteController.currentModel.estado = text;
																dimClienteController.formWasChanged = true;
															},
														),
													),
												),
											],
										),
										const Divider(
											color: Colors.transparent,
										),
										BootstrapRow(
											height: 60,
											children: <BootstrapCol>[
												BootstrapCol(
													sizes: 'col-12',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: TextFormField(
															autofocus: true,
															controller: dimClienteController.segmentoController,
															decoration: inputDecoration(
																hintText: 'Informe os dados para o campo Segmento',
																labelText: 'Segmento',
																usePadding: true,
															),
															onSaved: (String? value) {},
															onChanged: (text) {
																dimClienteController.currentModel.segmento = text;
																dimClienteController.formWasChanged = true;
															},
														),
													),
												),
											],
										),
										const Divider(
											indent: 10,
											endIndent: 10,
											thickness: 2,
										),
										BootstrapRow(
											height: 60,
											children: <BootstrapCol>[
												BootstrapCol(
													sizes: 'col-12',
													child: Text(
														'field_is_mandatory'.tr,
														style: Theme.of(context).textTheme.bodySmall,
													),
												),
											],
										),
										const SizedBox(height: 10.0),
									],
								),
							),
						),
					),
				),
			),
		);
	}
}
