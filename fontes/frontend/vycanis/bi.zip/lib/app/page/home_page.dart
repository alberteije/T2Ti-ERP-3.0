// ignore_for_file: use_key_in_widget_constructors

import 'package:bi/app/infra/infra_imports.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:bi/app/controller/bi_controller.dart';

class HomePage extends StatelessWidget {
  final BIController controller = Get.put(BIController());

  Widget _buildKPICard(String title, String value, IconData icon, Color color, String subtitle) {
    return Card(
      elevation: 4,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(12),
      ),
      child: Container(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Container(
                  padding: const EdgeInsets.all(8),
                  decoration: BoxDecoration(
                    color: color.withValues(alpha: 0.1),
                    borderRadius: BorderRadius.circular(8),
                  ),
                  child: Icon(icon, color: color, size: 24),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        title,
                        style: const TextStyle(
                          fontSize: 12,
                          color: Colors.grey,
                        ),
                      ),
                      Text(
                        value,
                        style: const TextStyle(
                          fontSize: 20,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
            const SizedBox(height: 8),
            Text(
              subtitle,
              style: TextStyle(
                fontSize: 11,
                color: Colors.grey[600],
                fontStyle: FontStyle.italic,
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildInfoBox(String title, String content) {
    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: Colors.blue[50],
        borderRadius: BorderRadius.circular(8),
        border: Border.all(color: Colors.blue[100]!),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            '💡 $title',
            style: const TextStyle(
              fontWeight: FontWeight.bold,
              color: Colors.blue,
            ),
          ),
          const SizedBox(height: 4),
          Text(
            content,
            style: const TextStyle(fontSize: 12),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Dashboard BI - T2Ti ERP'),
        actions: [
          IconButton(
            icon: const Icon(Icons.school),
            tooltip: 'Aprenda',
            onPressed: () => Get.toNamed('/bi/educacional'),
          ),
          IconButton(
            icon: const Icon(Icons.refresh),
            tooltip: 'Carregar Dados',
            onPressed: controller.carregarDadosBI,
          ),
        ],
      ),
      body: Obx(() {
        if (controller.vendas.isEmpty) {
          return const Center(child: CircularProgressIndicator());
        }

        return SingleChildScrollView(
          padding: const EdgeInsets.all(16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // CABEÇALHO DIDÁTICO
              _buildInfoBox(
                'O que é Business Intelligence?',
                'BI transforma dados em informações para tomada de decisão. Aqui você vê dados do modelo dimensional (fato + dimensões).'
              ),
              const SizedBox(height: 16),

              // KPI CARDS COM EXPLICAÇÃO
              const Text(
                'Indicadores Chave (KPIs)',
                style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
              ),
              const SizedBox(height: 8),
              Text(
                'Estes números mostram a saúde do negócio',
                style: TextStyle(color: Colors.grey[600]),
              ),
              const SizedBox(height: 16),

              GridView.count(
                crossAxisCount: 4,
                shrinkWrap: true,
                physics: const NeverScrollableScrollPhysics(),
                childAspectRatio: 1.5,
                mainAxisSpacing: 12,
                crossAxisSpacing: 12,
                children: [
                  _buildKPICard(
                    'Total de Vendas',
                    Util.moneyFormat(controller.totalVendas.value),
                    Icons.attach_money,
                    Colors.green,
                    'Soma de todas as vendas no período',
                  ),
                  _buildKPICard(
                    'Ticket Médio',
                    Util.moneyFormat(controller.ticketMedio.value),
                    Icons.shopping_cart,
                    Colors.blue,
                    'Valor médio por item vendido',
                  ),
                  _buildKPICard(
                    'Lucro Total',
                    Util.moneyFormat(controller.totalLucro.value),
                    Icons.trending_up,
                    Colors.green,
                    'Lucro após custos (${controller.percentualLucro.value.toStringAsFixed(1)}% sobre vendas)',
                  ),
                  _buildKPICard(
                    'Valor em Aberto',
                    Util.moneyFormat(controller.valorEmAberto.value),
                    Icons.warning,
                    Colors.orange,
                    'Dinheiro a receber (${controller.percentualInadimplencia.value.toStringAsFixed(1)}% de inadimplência)',
                  ),
                ],
              ),
              const SizedBox(height: 24),

              // GRÁFICO SIMPLES (DIDÁTICO)
              Card(
                elevation: 4,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Padding(
                  padding: const EdgeInsets.all(16),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Text(
                        '📊 Vendas por Mês',
                        style: TextStyle(
                          fontSize: 16,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      const SizedBox(height: 8),
                      Text(
                        'Visualize como as vendas se comportam ao longo do tempo',
                        style: TextStyle(color: Colors.grey[600], fontSize: 12),
                      ),
                      const SizedBox(height: 16),
                      _buildBarChartSimples(),
                      const SizedBox(height: 8),
                      _buildInfoBox(
                        'Como ler este gráfico?',
                        'Cada barra representa um mês. Altura maior = mais vendas. Isso ajuda a identificar tendências.',
                      ),
                    ],
                  ),
                ),
              ),
              const SizedBox(height: 24),

              // TABELA TOP CLIENTES
              Card(
                elevation: 4,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Padding(
                  padding: const EdgeInsets.all(16),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Text(
                        '🏆 Top Clientes',
                        style: TextStyle(
                          fontSize: 16,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      const SizedBox(height: 8),
                      Text(
                        'Clientes que mais compraram',
                        style: TextStyle(color: Colors.grey[600], fontSize: 12),
                      ),
                      const SizedBox(height: 16),
                      _buildTopClientesTable(),
                      const SizedBox(height: 8),
                      _buildInfoBox(
                        'Por que isso importa?',
                        'Identificar os melhores clientes ajuda a focar esforços e entender seu perfil de consumo.',
                      ),
                    ],
                  ),
                ),
              ),
              const SizedBox(height: 24),

              // BOTÕES DE AÇÃO
              Row(
                children: [
                  Expanded(
                    child: ElevatedButton.icon(
                      icon: const Icon(Icons.bar_chart),
                      label: const Text('Análise Detalhada'),
                      onPressed: () => Get.toNamed('/bi/analise-vendas'),
                      style: ElevatedButton.styleFrom(
                        padding: const EdgeInsets.symmetric(vertical: 16),
                      ),
                    ),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: ElevatedButton.icon(
                      icon: const Icon(Icons.people),
                      label: const Text('Ver Dimensões'),
                      onPressed: () => Get.toNamed('/bi/dimensoes'),
                      style: ElevatedButton.styleFrom(
                        padding: const EdgeInsets.symmetric(vertical: 16),
                        backgroundColor: Colors.blueGrey,
                      ),
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 32),
            ],
          ),
        );
      }),
    );
  }

  Widget _buildBarChartSimples() {
    final meses = ['Jan', 'Fev', 'Mar', 'Abr', 'Mai', 'Jun'];
    final valores = [2500.0, 640.0, 450.0, 4800.0, 525.0, 960.0];
    final maxValor = valores.reduce((a, b) => a > b ? a : b);

    return Container(
      height: 220,
      padding: const EdgeInsets.all(16),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.end,
        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
        children: List.generate(meses.length, (index) {
          final altura = (valores[index] / maxValor) * 150;
          return Column(
            mainAxisAlignment: MainAxisAlignment.end,
            children: [
              Container(
                width: 50,
                height: altura,
                decoration: BoxDecoration(
                  color: Colors.blue.withValues(alpha: 0.7),
                  borderRadius: const BorderRadius.only(
                    topLeft: Radius.circular(4),
                    topRight: Radius.circular(4),
                  ),
                ),
                child: Center(
                  child: Text(
                    'R\$${valores[index].toInt()}',
                    style: const TextStyle(
                      color: Colors.white,
                      fontSize: 9,
                      fontWeight: FontWeight.bold,
                    ),
                    textAlign: TextAlign.center,
                  ),
                ),
              ),
              const SizedBox(height: 8),
              Text(meses[index], style: const TextStyle(fontSize: 12)),
            ],
          );
        }),
      ),
    );
  }

  Widget _buildTopClientesTable() {
    return DataTable(
      columns: const [
        DataColumn(label: Text('Cliente')),
        DataColumn(label: Text('Vendas'), numeric: true),
        DataColumn(label: Text('Lucro'), numeric: true),
      ],
      rows: controller.vendasPorCliente.take(3).map((cliente) {
        return DataRow(cells: [
          DataCell(Text(cliente['cliente'] as String)),
          DataCell(Text(Util.moneyFormat(cliente['total_vendas'] as double))),
          DataCell(Text(Util.moneyFormat(cliente['total_lucro'] as double))),
        ]);
      }).toList(),
    );
  }
}