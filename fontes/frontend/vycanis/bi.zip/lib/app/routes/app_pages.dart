import 'package:get/get.dart';
import 'package:bi/app/routes/app_routes.dart';
import 'package:bi/app/page/login/login_page.dart';
import 'package:bi/app/page/shared_page/splash_screen_page.dart';
import 'package:bi/app/bindings/bindings_imports.dart';
import 'package:bi/app/page/shared_page/shared_page_imports.dart';
import 'package:bi/app/page/page_imports.dart';

class AppPages {
	
	static final pages = [
		GetPage(name: Routes.splashPage, page:()=> const SplashScreenPage()),
		GetPage(name: Routes.loginPage, page:()=> const LoginPage(), binding: LoginBindings()),
		GetPage(name: Routes.homePage, page:()=> HomePage()),
		GetPage(name: Routes.filterPage, page:()=> const FilterPage()),
		GetPage(name: Routes.lookupPage, page:()=> const LookupPage()),
		
		GetPage(name: Routes.dimTempoListPage, page:()=> const DimTempoListPage(), binding: DimTempoBindings()), 
		GetPage(name: Routes.dimTempoEditPage, page:()=> DimTempoEditPage()),
		GetPage(name: Routes.dimClienteListPage, page:()=> const DimClienteListPage(), binding: DimClienteBindings()), 
		GetPage(name: Routes.dimClienteEditPage, page:()=> DimClienteEditPage()),
		GetPage(name: Routes.dimVendedorListPage, page:()=> const DimVendedorListPage(), binding: DimVendedorBindings()), 
		GetPage(name: Routes.dimVendedorEditPage, page:()=> DimVendedorEditPage()),
		GetPage(name: Routes.dimProdutoListPage, page:()=> const DimProdutoListPage(), binding: DimProdutoBindings()), 
		GetPage(name: Routes.dimProdutoEditPage, page:()=> DimProdutoEditPage()),
		GetPage(name: Routes.fatoVendaListPage, page:()=> const FatoVendaListPage(), binding: FatoVendaBindings()), 
		GetPage(name: Routes.fatoVendaEditPage, page:()=> FatoVendaEditPage()),
		GetPage(name: Routes.fatoRecebimentoListPage, page:()=> const FatoRecebimentoListPage(), binding: FatoRecebimentoBindings()), 
		GetPage(name: Routes.fatoRecebimentoEditPage, page:()=> FatoRecebimentoEditPage()),

    // Adicionar às rotas
    GetPage(
      name: '/bi',
      page: () => HomePage(),
    ),
    GetPage(
      name: '/bi/educacional',
      page: () => BIEducacionalPage(),
    ),
    GetPage(
      name: '/bi/dimensoes',
      page: () => BIDimensoesPage(),
    ),
    GetPage(
      name: '/bi/analise-vendas', // A rota que o botão chama
      page: () => BIAnaliseVendasPage(), // A tela a ser criada
    ),    
	];
}