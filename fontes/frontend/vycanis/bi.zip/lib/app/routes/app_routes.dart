abstract class Routes{
	
	static const splashPage = '/splashPage';
	static const loginPage = '/loginPage';
	static const homePage = '/homePage';
	static const filterPage = '/filterPage';
	static const lookupPage = '/lookupPage';
		
	static const dimTempoListPage = '/dimTempoListPage'; 
	static const dimTempoEditPage = '/dimTempoEditPage';
	static const dimClienteListPage = '/dimClienteListPage'; 
	static const dimClienteEditPage = '/dimClienteEditPage';
	static const dimVendedorListPage = '/dimVendedorListPage'; 
	static const dimVendedorEditPage = '/dimVendedorEditPage';
	static const dimProdutoListPage = '/dimProdutoListPage'; 
	static const dimProdutoEditPage = '/dimProdutoEditPage';
	static const fatoVendaListPage = '/fatoVendaListPage'; 
	static const fatoVendaEditPage = '/fatoVendaEditPage';
	static const fatoRecebimentoListPage = '/fatoRecebimentoListPage'; 
	static const fatoRecebimentoEditPage = '/fatoRecebimentoEditPage';
}