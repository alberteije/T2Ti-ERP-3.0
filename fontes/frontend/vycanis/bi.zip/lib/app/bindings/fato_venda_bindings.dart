import 'package:get/get.dart';
import 'package:bi/app/controller/fato_venda_controller.dart';
import 'package:bi/app/data/provider/api/fato_venda_api_provider.dart';
import 'package:bi/app/data/provider/drift/fato_venda_drift_provider.dart';
import 'package:bi/app/data/repository/fato_venda_repository.dart';

class FatoVendaBindings implements Binding {
	@override
	List<Bind> dependencies() {
		return [
			Bind.lazyPut<FatoVendaController>(() => FatoVendaController(
					repository: FatoVendaRepository(fatoVendaApiProvider: FatoVendaApiProvider(), fatoVendaDriftProvider: FatoVendaDriftProvider()))),
		];
	}
}
