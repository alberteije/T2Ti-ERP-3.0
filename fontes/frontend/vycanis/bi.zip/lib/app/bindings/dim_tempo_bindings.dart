import 'package:get/get.dart';
import 'package:bi/app/controller/dim_tempo_controller.dart';
import 'package:bi/app/data/provider/api/dim_tempo_api_provider.dart';
import 'package:bi/app/data/provider/drift/dim_tempo_drift_provider.dart';
import 'package:bi/app/data/repository/dim_tempo_repository.dart';

class DimTempoBindings implements Binding {
	@override
	List<Bind> dependencies() {
		return [
			Bind.lazyPut<DimTempoController>(() => DimTempoController(
					repository: DimTempoRepository(dimTempoApiProvider: DimTempoApiProvider(), dimTempoDriftProvider: DimTempoDriftProvider()))),
		];
	}
}
