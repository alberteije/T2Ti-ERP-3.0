import 'package:get/get.dart';
import 'package:bi/app/controller/fato_recebimento_controller.dart';
import 'package:bi/app/data/provider/api/fato_recebimento_api_provider.dart';
import 'package:bi/app/data/provider/drift/fato_recebimento_drift_provider.dart';
import 'package:bi/app/data/repository/fato_recebimento_repository.dart';

class FatoRecebimentoBindings implements Binding {
	@override
	List<Bind> dependencies() {
		return [
			Bind.lazyPut<FatoRecebimentoController>(() => FatoRecebimentoController(
					repository: FatoRecebimentoRepository(fatoRecebimentoApiProvider: FatoRecebimentoApiProvider(), fatoRecebimentoDriftProvider: FatoRecebimentoDriftProvider()))),
		];
	}
}
