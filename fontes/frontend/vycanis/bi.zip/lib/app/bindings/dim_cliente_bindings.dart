import 'package:get/get.dart';
import 'package:bi/app/controller/dim_cliente_controller.dart';
import 'package:bi/app/data/provider/api/dim_cliente_api_provider.dart';
import 'package:bi/app/data/provider/drift/dim_cliente_drift_provider.dart';
import 'package:bi/app/data/repository/dim_cliente_repository.dart';

class DimClienteBindings implements Binding {
	@override
	List<Bind> dependencies() {
		return [
			Bind.lazyPut<DimClienteController>(() => DimClienteController(
					repository: DimClienteRepository(dimClienteApiProvider: DimClienteApiProvider(), dimClienteDriftProvider: DimClienteDriftProvider()))),
		];
	}
}
