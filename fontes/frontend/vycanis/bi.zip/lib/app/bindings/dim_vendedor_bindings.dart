import 'package:get/get.dart';
import 'package:bi/app/controller/dim_vendedor_controller.dart';
import 'package:bi/app/data/provider/api/dim_vendedor_api_provider.dart';
import 'package:bi/app/data/provider/drift/dim_vendedor_drift_provider.dart';
import 'package:bi/app/data/repository/dim_vendedor_repository.dart';

class DimVendedorBindings implements Binding {
	@override
	List<Bind> dependencies() {
		return [
			Bind.lazyPut<DimVendedorController>(() => DimVendedorController(
					repository: DimVendedorRepository(dimVendedorApiProvider: DimVendedorApiProvider(), dimVendedorDriftProvider: DimVendedorDriftProvider()))),
		];
	}
}
