import 'package:get/get.dart';
import 'package:bi/app/controller/dim_produto_controller.dart';
import 'package:bi/app/data/provider/api/dim_produto_api_provider.dart';
import 'package:bi/app/data/provider/drift/dim_produto_drift_provider.dart';
import 'package:bi/app/data/repository/dim_produto_repository.dart';

class DimProdutoBindings implements Binding {
	@override
	List<Bind> dependencies() {
		return [
			Bind.lazyPut<DimProdutoController>(() => DimProdutoController(
					repository: DimProdutoRepository(dimProdutoApiProvider: DimProdutoApiProvider(), dimProdutoDriftProvider: DimProdutoDriftProvider()))),
		];
	}
}
