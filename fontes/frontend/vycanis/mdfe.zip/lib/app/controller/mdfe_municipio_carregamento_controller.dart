import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:pluto_grid/pluto_grid.dart';

import 'package:mdfe/app/page/page_imports.dart';
import 'package:mdfe/app/page/shared_widget/message_dialog.dart';
import 'package:mdfe/app/page/grid_columns/grid_columns_imports.dart';
import 'package:mdfe/app/controller/controller_imports.dart';
import 'package:mdfe/app/data/model/model_imports.dart';

class MdfeMunicipioCarregamentoController extends ControllerBase<MdfeMunicipioCarregamentoModel, void> {

  MdfeMunicipioCarregamentoController() : super(repository: null) {
    dbColumns = MdfeMunicipioCarregamentoModel.dbColumns;
    aliasColumns = MdfeMunicipioCarregamentoModel.aliasColumns;
    gridColumns = mdfeMunicipioCarregamentoGridColumns();
    functionName = "mdfe_municipio_carregamento";
    screenTitle = "Município Carregamento";
  }

  final _mdfeMunicipioCarregamentoModel = MdfeMunicipioCarregamentoModel().obs;
  MdfeMunicipioCarregamentoModel get mdfeMunicipioCarregamentoModel => _mdfeMunicipioCarregamentoModel.value;
  set mdfeMunicipioCarregamentoModel(value) => _mdfeMunicipioCarregamentoModel.value = value ?? MdfeMunicipioCarregamentoModel();

  List<MdfeMunicipioCarregamentoModel> get mdfeMunicipioCarregamentoModelList => Get.find<MdfeCabecalhoController>().currentModel.mdfeMunicipioCarregamentoModelList ?? [];

  final _userMadeChanges = false.obs;
  get userMadeChanges => _userMadeChanges.value;
  set userMadeChanges(value) => _userMadeChanges.value = value;

  final _formWasChangedDetail = false.obs;
  bool get formWasChangedDetail => _formWasChangedDetail.value;
  set formWasChangedDetail(value) => _formWasChangedDetail.value = value;

  late PlutoGridStateManager _plutoGridStateManager;
  @override
  PlutoGridStateManager get plutoGridStateManager => _plutoGridStateManager;
  @override
  set plutoGridStateManager(value) => _plutoGridStateManager = value;

  final mdfeMunicipioCarregamentoScaffoldKey = GlobalKey<ScaffoldState>();
  final mdfeMunicipioCarregamentoFormKey = GlobalKey<FormState>();

  @override
  MdfeMunicipioCarregamentoModel createNewModel() => MdfeMunicipioCarregamentoModel();

  @override
  final standardFieldForFilter = MdfeMunicipioCarregamentoModel.aliasColumns[MdfeMunicipioCarregamentoModel.dbColumns.indexOf('codigo_municipio')];

  final codigoMunicipioController = TextEditingController();
  final nomeMunicipioController = TextEditingController();

  final Map<String, dynamic> mobileConfig = {
    'primaryColumns': ['codigo_municipio'],
    'secondaryColumns': ['nome_municipio'],
  };

  List<Map<String, dynamic>> get mobileItems {
    return modelList.map((mdfeMunicipioCarregamento) => mdfeMunicipioCarregamento.toJson).toList();
  }

  @override
  List<PlutoRow> plutoRows() => List<PlutoRow>.from(mdfeMunicipioCarregamentoModelList.map((model) => model.toPlutoRow()));

  @override
  Future<void> getList({Filter? filter}) async {}

  @override
  void prepareForInsert() {
    isNewRecord = true;
    mdfeMunicipioCarregamentoModel = createNewModel();
    _resetForm();
    Get.to(() => MdfeMunicipioCarregamentoEditPage());
  }

  void _resetForm() {
    formWasChangedDetail = false;
    codigoMunicipioController.text = '';
    nomeMunicipioController.text = '';
  }

  @override
  void selectRowForEditing(PlutoRow? row) async {
    if (row == null) {
      showInfoSnackBar(message: 'message_select_one_to_edited'.tr);
      return;
    }

    selectRowForEditingByTempId(row.cells['tempId']?.value);
  }

  @override
  void selectRowForEditingById(int id) {}

  void selectRowForEditingByTempId(String tempId) {
		isNewRecord = false;
    final model = mdfeMunicipioCarregamentoModelList.firstWhere((m) => m.tempId == tempId);
    mdfeMunicipioCarregamentoModel = model.clone();
		mdfeMunicipioCarregamentoModel.tempId = model.tempId;
    updateControllersFromModel();
    Get.to(() => MdfeMunicipioCarregamentoEditPage());
  }

  void updateControllersFromModel() {
    codigoMunicipioController.text = mdfeMunicipioCarregamentoModel.codigoMunicipio ?? '';
    nomeMunicipioController.text = mdfeMunicipioCarregamentoModel.nomeMunicipio ?? '';
    formWasChangedDetail = false;
  }

  @override
  Future<void> save() async {
    if (!mdfeMunicipioCarregamentoFormKey.currentState!.validate()) {
      showErrorSnackBar(message: 'validator_form_message'.tr);
      return;
    }

    if (formWasChangedDetail) {
      if (isNewRecord) {
        mdfeMunicipioCarregamentoModelList.insert(0, mdfeMunicipioCarregamentoModel.clone());
      } else {
        final index = mdfeMunicipioCarregamentoModelList.indexWhere((m) => m.tempId == mdfeMunicipioCarregamentoModel.tempId);
        if (index >= 0) {
          mdfeMunicipioCarregamentoModelList[index] = mdfeMunicipioCarregamentoModel.clone();
        }
      }

      userMadeChanges = true;
      loadData();
      Get.back(result: true);
    } else {
      Get.back();
    }
  }


  @override
  Future deleteSelected() async {
    final currentRow = plutoGridStateManager.currentRow;
    if (currentRow == null) {
      showInfoSnackBar(message: 'message_select_one_to_delete'.tr);
      return null;
    }
    showDeleteDialog(() async {
      final id = currentRow.cells['id']?.value;
      final tempId = currentRow.cells['tempId']?.value;
      mdfeMunicipioCarregamentoModelList.removeWhere((model) => (id != 0 && model.id == id) || (id == 0 && model.tempId == tempId));
      plutoGridStateManager.removeCurrentRow();
      userMadeChanges = true;
    });
  }

  @override
  void preventDataLoss() {
    if (formWasChangedDetail) {
      showQuestionDialog('message_data_loss'.tr, () => Get.back());
    } else {
      formWasChangedDetail = false;
      Get.back();
    }
  }

  @override
  void onClose() {
    codigoMunicipioController.dispose();
    nomeMunicipioController.dispose();
  }

}