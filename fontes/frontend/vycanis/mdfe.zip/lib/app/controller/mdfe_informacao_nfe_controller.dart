import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:extended_masked_text/extended_masked_text.dart';

import 'package:mdfe/app/page/shared_widget/message_dialog.dart';
import 'package:mdfe/app/page/grid_columns/grid_columns_imports.dart';
import 'package:mdfe/app/routes/app_routes.dart';
import 'package:mdfe/app/controller/controller_imports.dart';
import 'package:mdfe/app/data/model/model_imports.dart';
import 'package:mdfe/app/data/repository/mdfe_informacao_nfe_repository.dart';

class MdfeInformacaoNfeController extends ControllerBase<MdfeInformacaoNfeModel, MdfeInformacaoNfeRepository> {

  MdfeInformacaoNfeController({required super.repository}) {
    dbColumns = MdfeInformacaoNfeModel.dbColumns;
    aliasColumns = MdfeInformacaoNfeModel.aliasColumns;
    gridColumns = mdfeInformacaoNfeGridColumns();
    functionName = "mdfe_informacao_nfe";
    screenTitle = "Informacao NFe";
  }

  @override
  MdfeInformacaoNfeModel createNewModel() => MdfeInformacaoNfeModel();

  @override
  final standardFieldForFilter = MdfeInformacaoNfeModel.aliasColumns[MdfeInformacaoNfeModel.dbColumns.indexOf('chave_nfe')];

  final mdfeMunicipioDescarregaModelController = TextEditingController();
  final chaveNfeController = TextEditingController();
  final segundoCodigoBarraController = TextEditingController();
  final indicadorReentregaController = MoneyMaskedTextController(precision: 0, decimalSeparator: '', thousandSeparator: '');

  final Map<String, dynamic> mobileConfig = {
    'primaryColumns': ['chave_nfe'],
    'secondaryColumns': ['segundo_codigo_barra'],
  };

  List<Map<String, dynamic>> get mobileItems {
    return modelList.map((mdfeInformacaoNfe) => mdfeInformacaoNfe.toJson).toList();
  }

  @override
  void prepareForInsert() {
    isNewRecord = true;
    currentModel = createNewModel();
    _resetForm();
    Get.toNamed(Routes.mdfeInformacaoNfeEditPage);
  }

  void _resetForm() {
    formWasChanged = false;
    mdfeMunicipioDescarregaModelController.text = '';
    chaveNfeController.text = '';
    segundoCodigoBarraController.text = '';
    indicadorReentregaController.updateValue(0);
  }

  @override
  void selectRowForEditingById(int id) {
    final model = modelList.firstWhere((m) => m.id == id);
    currentModel = model.clone();
    updateControllersFromModel();
    Get.toNamed(Routes.mdfeInformacaoNfeEditPage);
  }

  void updateControllersFromModel() {
    mdfeMunicipioDescarregaModelController.text = currentModel.mdfeMunicipioDescarregaModel?.nomeMunicipio?.toString() ?? '';
    chaveNfeController.text = currentModel.chaveNfe ?? '';
    segundoCodigoBarraController.text = currentModel.segundoCodigoBarra ?? '';
    indicadorReentregaController.updateValue((currentModel.indicadorReentrega ?? 0).toDouble());
    formWasChanged = false;
  }

  @override
  Future<void> save() async {
    if (!formKey.currentState!.validate()) {
      showErrorSnackBar(message: 'validator_form_message'.tr);
      return;
    }

    final existingIndex = modelList.indexWhere((m) => m.id == currentModel.id);

    if (existingIndex >= 0) {
      modelList[existingIndex] = currentModel.clone();
    }

    final result = await repository.save(mdfeInformacaoNfeModel: currentModel);
    if (result == null) return;

    if (existingIndex >= 0) {
      modelList[existingIndex] = result;
    } else {
      modelList.insert(0, result);
    }

    if (!GetPlatform.isMobile) {
      updateGridRow(result);
    }

    Get.back(result: true);
  }

  Future callMdfeMunicipioDescarregaLookup() async { 
		final lookupController = Get.find<LookupController>(); 
		lookupController.refreshItems(standardValue: '%'); 
		lookupController.title = '${'lookup_page_title'.tr} [Id Mdfe Municipio Descarrega]'; 
		lookupController.route = '/mdfe-municipio-descarrega/'; 
		lookupController.gridColumns = mdfeMunicipioDescarregaGridColumns(isForLookup: true); 
		lookupController.aliasColumns = MdfeMunicipioDescarregaModel.aliasColumns; 
		lookupController.dbColumns = MdfeMunicipioDescarregaModel.dbColumns; 
		lookupController.standardColumn = MdfeMunicipioDescarregaModel.aliasColumns[MdfeMunicipioDescarregaModel.dbColumns.indexOf('nomeMunicipio')]; 

		final plutoRowResult = await Get.toNamed(Routes.lookupPage); 
		if (plutoRowResult != null) { 
			currentModel.idMdfeMunicipioDescarrega = plutoRowResult.cells['id']!.value; 
			currentModel.mdfeMunicipioDescarregaModel = MdfeMunicipioDescarregaModel.fromPlutoRow(plutoRowResult); 
			mdfeMunicipioDescarregaModelController.text = currentModel.mdfeMunicipioDescarregaModel?.nomeMunicipio ?? ''; 
			formWasChanged = true; 
		}
	}


  @override
  void onClose() {
    mdfeMunicipioDescarregaModelController.dispose();
    chaveNfeController.dispose();
    segundoCodigoBarraController.dispose();
    indicadorReentregaController.dispose();
    super.onClose();
  }

}