import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:pluto_grid/pluto_grid.dart';

import 'package:mdfe/app/page/page_imports.dart';
import 'package:mdfe/app/page/shared_widget/message_dialog.dart';
import 'package:mdfe/app/page/grid_columns/grid_columns_imports.dart';
import 'package:mdfe/app/controller/controller_imports.dart';
import 'package:mdfe/app/data/model/model_imports.dart';

class MdfeLacreController extends ControllerBase<MdfeLacreModel, void> {

  MdfeLacreController() : super(repository: null) {
    dbColumns = MdfeLacreModel.dbColumns;
    aliasColumns = MdfeLacreModel.aliasColumns;
    gridColumns = mdfeLacreGridColumns();
    functionName = "mdfe_lacre";
    screenTitle = "Lacre";
  }

  final _mdfeLacreModel = MdfeLacreModel().obs;
  MdfeLacreModel get mdfeLacreModel => _mdfeLacreModel.value;
  set mdfeLacreModel(value) => _mdfeLacreModel.value = value ?? MdfeLacreModel();

  List<MdfeLacreModel> get mdfeLacreModelList => Get.find<MdfeCabecalhoController>().currentModel.mdfeLacreModelList ?? [];

  final _userMadeChanges = false.obs;
  get userMadeChanges => _userMadeChanges.value;
  set userMadeChanges(value) => _userMadeChanges.value = value;

  final _formWasChangedDetail = false.obs;
  bool get formWasChangedDetail => _formWasChangedDetail.value;
  set formWasChangedDetail(value) => _formWasChangedDetail.value = value;

  late PlutoGridStateManager _plutoGridStateManager;
  @override
  PlutoGridStateManager get plutoGridStateManager => _plutoGridStateManager;
  @override
  set plutoGridStateManager(value) => _plutoGridStateManager = value;

  final mdfeLacreScaffoldKey = GlobalKey<ScaffoldState>();
  final mdfeLacreFormKey = GlobalKey<FormState>();

  @override
  MdfeLacreModel createNewModel() => MdfeLacreModel();

  @override
  final standardFieldForFilter = MdfeLacreModel.aliasColumns[MdfeLacreModel.dbColumns.indexOf('numero_lacre')];

  final numeroLacreController = TextEditingController();

  final Map<String, dynamic> mobileConfig = {
    'primaryColumns': ['numero_lacre'],
    'secondaryColumns': [],
  };

  List<Map<String, dynamic>> get mobileItems {
    return modelList.map((mdfeLacre) => mdfeLacre.toJson).toList();
  }

  @override
  List<PlutoRow> plutoRows() => List<PlutoRow>.from(mdfeLacreModelList.map((model) => model.toPlutoRow()));

  @override
  Future<void> getList({Filter? filter}) async {}

  @override
  void prepareForInsert() {
    isNewRecord = true;
    mdfeLacreModel = createNewModel();
    _resetForm();
    Get.to(() => MdfeLacreEditPage());
  }

  void _resetForm() {
    formWasChangedDetail = false;
    numeroLacreController.text = '';
  }

  @override
  void selectRowForEditing(PlutoRow? row) async {
    if (row == null) {
      showInfoSnackBar(message: 'message_select_one_to_edited'.tr);
      return;
    }

    selectRowForEditingByTempId(row.cells['tempId']?.value);
  }

  @override
  void selectRowForEditingById(int id) {}

  void selectRowForEditingByTempId(String tempId) {
		isNewRecord = false;
    final model = mdfeLacreModelList.firstWhere((m) => m.tempId == tempId);
    mdfeLacreModel = model.clone();
		mdfeLacreModel.tempId = model.tempId;
    updateControllersFromModel();
    Get.to(() => MdfeLacreEditPage());
  }

  void updateControllersFromModel() {
    numeroLacreController.text = mdfeLacreModel.numeroLacre ?? '';
    formWasChangedDetail = false;
  }

  @override
  Future<void> save() async {
    if (!mdfeLacreFormKey.currentState!.validate()) {
      showErrorSnackBar(message: 'validator_form_message'.tr);
      return;
    }

    if (formWasChangedDetail) {
      if (isNewRecord) {
        mdfeLacreModelList.insert(0, mdfeLacreModel.clone());
      } else {
        final index = mdfeLacreModelList.indexWhere((m) => m.tempId == mdfeLacreModel.tempId);
        if (index >= 0) {
          mdfeLacreModelList[index] = mdfeLacreModel.clone();
        }
      }

      userMadeChanges = true;
      loadData();
      Get.back(result: true);
    } else {
      Get.back();
    }
  }


  @override
  Future deleteSelected() async {
    final currentRow = plutoGridStateManager.currentRow;
    if (currentRow == null) {
      showInfoSnackBar(message: 'message_select_one_to_delete'.tr);
      return null;
    }
    showDeleteDialog(() async {
      final id = currentRow.cells['id']?.value;
      final tempId = currentRow.cells['tempId']?.value;
      mdfeLacreModelList.removeWhere((model) => (id != 0 && model.id == id) || (id == 0 && model.tempId == tempId));
      plutoGridStateManager.removeCurrentRow();
      userMadeChanges = true;
    });
  }

  @override
  void preventDataLoss() {
    if (formWasChangedDetail) {
      showQuestionDialog('message_data_loss'.tr, () => Get.back());
    } else {
      formWasChangedDetail = false;
      Get.back();
    }
  }

  @override
  void onClose() {
    numeroLacreController.dispose();
  }

}