import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:pluto_grid/pluto_grid.dart';
import 'package:mdfe/app/page/shared_widget/input/input_imports.dart';

import 'package:mdfe/app/page/page_imports.dart';
import 'package:mdfe/app/page/shared_widget/message_dialog.dart';
import 'package:mdfe/app/page/grid_columns/grid_columns_imports.dart';
import 'package:mdfe/app/controller/controller_imports.dart';
import 'package:mdfe/app/data/model/model_imports.dart';

class MdfePercursoController extends ControllerBase<MdfePercursoModel, void> {

  MdfePercursoController() : super(repository: null) {
    dbColumns = MdfePercursoModel.dbColumns;
    aliasColumns = MdfePercursoModel.aliasColumns;
    gridColumns = mdfePercursoGridColumns();
    functionName = "mdfe_percurso";
    screenTitle = "Percurso";
  }

  final _mdfePercursoModel = MdfePercursoModel().obs;
  MdfePercursoModel get mdfePercursoModel => _mdfePercursoModel.value;
  set mdfePercursoModel(value) => _mdfePercursoModel.value = value ?? MdfePercursoModel();

  List<MdfePercursoModel> get mdfePercursoModelList => Get.find<MdfeCabecalhoController>().currentModel.mdfePercursoModelList ?? [];

  final _userMadeChanges = false.obs;
  get userMadeChanges => _userMadeChanges.value;
  set userMadeChanges(value) => _userMadeChanges.value = value;

  final _formWasChangedDetail = false.obs;
  bool get formWasChangedDetail => _formWasChangedDetail.value;
  set formWasChangedDetail(value) => _formWasChangedDetail.value = value;

  late PlutoGridStateManager _plutoGridStateManager;
  @override
  PlutoGridStateManager get plutoGridStateManager => _plutoGridStateManager;
  @override
  set plutoGridStateManager(value) => _plutoGridStateManager = value;

  final mdfePercursoScaffoldKey = GlobalKey<ScaffoldState>();
  final mdfePercursoFormKey = GlobalKey<FormState>();

  @override
  MdfePercursoModel createNewModel() => MdfePercursoModel();

  @override
  final standardFieldForFilter = MdfePercursoModel.aliasColumns[MdfePercursoModel.dbColumns.indexOf('uf_percurso')];

  final ufPercursoController = CustomDropdownButtonController('AC');
  final dataInicioViagemController = DatePickerItemController(null);

  final Map<String, dynamic> mobileConfig = {
    'primaryColumns': ['uf_percurso'],
    'secondaryColumns': ['data_inicio_viagem'],
  };

  List<Map<String, dynamic>> get mobileItems {
    return modelList.map((mdfePercurso) => mdfePercurso.toJson).toList();
  }

  @override
  List<PlutoRow> plutoRows() => List<PlutoRow>.from(mdfePercursoModelList.map((model) => model.toPlutoRow()));

  @override
  Future<void> getList({Filter? filter}) async {}

  @override
  void prepareForInsert() {
    isNewRecord = true;
    mdfePercursoModel = createNewModel();
    _resetForm();
    Get.to(() => MdfePercursoEditPage());
  }

  void _resetForm() {
    formWasChangedDetail = false;
    ufPercursoController.selected = 'AC';
    dataInicioViagemController.date = null;
  }

  @override
  void selectRowForEditing(PlutoRow? row) async {
    if (row == null) {
      showInfoSnackBar(message: 'message_select_one_to_edited'.tr);
      return;
    }

    selectRowForEditingByTempId(row.cells['tempId']?.value);
  }

  @override
  void selectRowForEditingById(int id) {}

  void selectRowForEditingByTempId(String tempId) {
		isNewRecord = false;
    final model = mdfePercursoModelList.firstWhere((m) => m.tempId == tempId);
    mdfePercursoModel = model.clone();
		mdfePercursoModel.tempId = model.tempId;
    updateControllersFromModel();
    Get.to(() => MdfePercursoEditPage());
  }

  void updateControllersFromModel() {
    ufPercursoController.selected = mdfePercursoModel.ufPercurso ?? 'AC';
    dataInicioViagemController.date = mdfePercursoModel.dataInicioViagem;
    formWasChangedDetail = false;
  }

  @override
  Future<void> save() async {
    if (!mdfePercursoFormKey.currentState!.validate()) {
      showErrorSnackBar(message: 'validator_form_message'.tr);
      return;
    }

    if (formWasChangedDetail) {
      if (isNewRecord) {
        mdfePercursoModelList.insert(0, mdfePercursoModel.clone());
      } else {
        final index = mdfePercursoModelList.indexWhere((m) => m.tempId == mdfePercursoModel.tempId);
        if (index >= 0) {
          mdfePercursoModelList[index] = mdfePercursoModel.clone();
        }
      }

      userMadeChanges = true;
      loadData();
      Get.back(result: true);
    } else {
      Get.back();
    }
  }


  @override
  Future deleteSelected() async {
    final currentRow = plutoGridStateManager.currentRow;
    if (currentRow == null) {
      showInfoSnackBar(message: 'message_select_one_to_delete'.tr);
      return null;
    }
    showDeleteDialog(() async {
      final id = currentRow.cells['id']?.value;
      final tempId = currentRow.cells['tempId']?.value;
      mdfePercursoModelList.removeWhere((model) => (id != 0 && model.id == id) || (id == 0 && model.tempId == tempId));
      plutoGridStateManager.removeCurrentRow();
      userMadeChanges = true;
    });
  }

  @override
  void preventDataLoss() {
    if (formWasChangedDetail) {
      showQuestionDialog('message_data_loss'.tr, () => Get.back());
    } else {
      formWasChangedDetail = false;
      Get.back();
    }
  }

  @override
  void onClose() {
    ufPercursoController.dispose();
    dataInicioViagemController.dispose();
  }

}