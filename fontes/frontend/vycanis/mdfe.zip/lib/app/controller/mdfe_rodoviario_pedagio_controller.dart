import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:extended_masked_text/extended_masked_text.dart';

import 'package:mdfe/app/page/shared_widget/message_dialog.dart';
import 'package:mdfe/app/page/grid_columns/grid_columns_imports.dart';
import 'package:mdfe/app/routes/app_routes.dart';
import 'package:mdfe/app/controller/controller_imports.dart';
import 'package:mdfe/app/data/model/model_imports.dart';
import 'package:mdfe/app/data/repository/mdfe_rodoviario_pedagio_repository.dart';

class MdfeRodoviarioPedagioController extends ControllerBase<MdfeRodoviarioPedagioModel, MdfeRodoviarioPedagioRepository> {

  MdfeRodoviarioPedagioController({required super.repository}) {
    dbColumns = MdfeRodoviarioPedagioModel.dbColumns;
    aliasColumns = MdfeRodoviarioPedagioModel.aliasColumns;
    gridColumns = mdfeRodoviarioPedagioGridColumns();
    functionName = "mdfe_rodoviario_pedagio";
    screenTitle = "Rodoviario Pedagio";
  }

  @override
  MdfeRodoviarioPedagioModel createNewModel() => MdfeRodoviarioPedagioModel();

  @override
  final standardFieldForFilter = MdfeRodoviarioPedagioModel.aliasColumns[MdfeRodoviarioPedagioModel.dbColumns.indexOf('cnpj_fornecedor')];

  final mdfeRodoviarioModelController = TextEditingController();
  final cnpjFornecedorController = MaskedTextController(mask: '00.000.000/0000-00',);
  final cnpjResponsavelController = MaskedTextController(mask: '00.000.000/0000-00',);
  final cpfResponsavelController = MaskedTextController(mask: '000.000.000-00',);
  final numeroComprovanteController = TextEditingController();
  final valorController = MoneyMaskedTextController();

  final Map<String, dynamic> mobileConfig = {
    'primaryColumns': ['cnpj_fornecedor'],
    'secondaryColumns': ['cnpj_responsavel'],
  };

  List<Map<String, dynamic>> get mobileItems {
    return modelList.map((mdfeRodoviarioPedagio) => mdfeRodoviarioPedagio.toJson).toList();
  }

  @override
  void prepareForInsert() {
    isNewRecord = true;
    currentModel = createNewModel();
    _resetForm();
    Get.toNamed(Routes.mdfeRodoviarioPedagioEditPage);
  }

  void _resetForm() {
    formWasChanged = false;
    mdfeRodoviarioModelController.text = '';
    cnpjFornecedorController.text = '';
    cnpjResponsavelController.text = '';
    cpfResponsavelController.text = '';
    numeroComprovanteController.text = '';
    valorController.updateValue(0);
  }

  @override
  void selectRowForEditingById(int id) {
    final model = modelList.firstWhere((m) => m.id == id);
    currentModel = model.clone();
    updateControllersFromModel();
    Get.toNamed(Routes.mdfeRodoviarioPedagioEditPage);
  }

  void updateControllersFromModel() {
    mdfeRodoviarioModelController.text = currentModel.mdfeRodoviarioModel?.codigoAgendamento?.toString() ?? '';
    cnpjFornecedorController.text = currentModel.cnpjFornecedor ?? '';
    cnpjResponsavelController.text = currentModel.cnpjResponsavel ?? '';
    cpfResponsavelController.text = currentModel.cpfResponsavel ?? '';
    numeroComprovanteController.text = currentModel.numeroComprovante ?? '';
    valorController.updateValue(currentModel.valor ?? 0);
    formWasChanged = false;
  }

  @override
  Future<void> save() async {
    if (!formKey.currentState!.validate()) {
      showErrorSnackBar(message: 'validator_form_message'.tr);
      return;
    }

    final existingIndex = modelList.indexWhere((m) => m.id == currentModel.id);

    if (existingIndex >= 0) {
      modelList[existingIndex] = currentModel.clone();
    }

    final result = await repository.save(mdfeRodoviarioPedagioModel: currentModel);
    if (result == null) return;

    if (existingIndex >= 0) {
      modelList[existingIndex] = result;
    } else {
      modelList.insert(0, result);
    }

    if (!GetPlatform.isMobile) {
      updateGridRow(result);
    }

    Get.back(result: true);
  }

  Future callMdfeRodoviarioLookup() async { 
		final lookupController = Get.find<LookupController>(); 
		lookupController.refreshItems(standardValue: '%'); 
		lookupController.title = '${'lookup_page_title'.tr} [Id Mdfe Rodoviario]'; 
		lookupController.route = '/mdfe-rodoviario/'; 
		lookupController.gridColumns = mdfeRodoviarioGridColumns(isForLookup: true); 
		lookupController.aliasColumns = MdfeRodoviarioModel.aliasColumns; 
		lookupController.dbColumns = MdfeRodoviarioModel.dbColumns; 
		lookupController.standardColumn = MdfeRodoviarioModel.aliasColumns[MdfeRodoviarioModel.dbColumns.indexOf('codigoAgendamento')]; 

		final plutoRowResult = await Get.toNamed(Routes.lookupPage); 
		if (plutoRowResult != null) { 
			currentModel.idMdfeRodoviario = plutoRowResult.cells['id']!.value; 
			currentModel.mdfeRodoviarioModel = MdfeRodoviarioModel.fromPlutoRow(plutoRowResult); 
			mdfeRodoviarioModelController.text = currentModel.mdfeRodoviarioModel?.codigoAgendamento ?? ''; 
			formWasChanged = true; 
		}
	}


  @override
  void onClose() {
    mdfeRodoviarioModelController.dispose();
    cnpjFornecedorController.dispose();
    cnpjResponsavelController.dispose();
    cpfResponsavelController.dispose();
    numeroComprovanteController.dispose();
    valorController.dispose();
    super.onClose();
  }

}