import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:pluto_grid/pluto_grid.dart';

import 'package:mdfe/app/page/page_imports.dart';
import 'package:mdfe/app/page/shared_widget/message_dialog.dart';
import 'package:mdfe/app/page/grid_columns/grid_columns_imports.dart';
import 'package:mdfe/app/controller/controller_imports.dart';
import 'package:mdfe/app/data/model/model_imports.dart';

class MdfeRodoviarioController extends ControllerBase<MdfeRodoviarioModel, void> {

  MdfeRodoviarioController() : super(repository: null) {
    dbColumns = MdfeRodoviarioModel.dbColumns;
    aliasColumns = MdfeRodoviarioModel.aliasColumns;
    gridColumns = mdfeRodoviarioGridColumns();
    functionName = "mdfe_rodoviario";
    screenTitle = "Rodoviário";
  }

  final _mdfeRodoviarioModel = MdfeRodoviarioModel().obs;
  MdfeRodoviarioModel get mdfeRodoviarioModel => _mdfeRodoviarioModel.value;
  set mdfeRodoviarioModel(value) => _mdfeRodoviarioModel.value = value ?? MdfeRodoviarioModel();

  List<MdfeRodoviarioModel> get mdfeRodoviarioModelList => Get.find<MdfeCabecalhoController>().currentModel.mdfeRodoviarioModelList ?? [];

  final _userMadeChanges = false.obs;
  get userMadeChanges => _userMadeChanges.value;
  set userMadeChanges(value) => _userMadeChanges.value = value;

  final _formWasChangedDetail = false.obs;
  bool get formWasChangedDetail => _formWasChangedDetail.value;
  set formWasChangedDetail(value) => _formWasChangedDetail.value = value;

  late PlutoGridStateManager _plutoGridStateManager;
  @override
  PlutoGridStateManager get plutoGridStateManager => _plutoGridStateManager;
  @override
  set plutoGridStateManager(value) => _plutoGridStateManager = value;

  final mdfeRodoviarioScaffoldKey = GlobalKey<ScaffoldState>();
  final mdfeRodoviarioFormKey = GlobalKey<FormState>();

  @override
  MdfeRodoviarioModel createNewModel() => MdfeRodoviarioModel();

  @override
  final standardFieldForFilter = MdfeRodoviarioModel.aliasColumns[MdfeRodoviarioModel.dbColumns.indexOf('rntrc')];

  final rntrcController = TextEditingController();
  final codigoAgendamentoController = TextEditingController();

  final Map<String, dynamic> mobileConfig = {
    'primaryColumns': ['rntrc'],
    'secondaryColumns': ['codigo_agendamento'],
  };

  List<Map<String, dynamic>> get mobileItems {
    return modelList.map((mdfeRodoviario) => mdfeRodoviario.toJson).toList();
  }

  @override
  List<PlutoRow> plutoRows() => List<PlutoRow>.from(mdfeRodoviarioModelList.map((model) => model.toPlutoRow()));

  @override
  Future<void> getList({Filter? filter}) async {}

  @override
  void prepareForInsert() {
    isNewRecord = true;
    mdfeRodoviarioModel = createNewModel();
    _resetForm();
    Get.to(() => MdfeRodoviarioEditPage());
  }

  void _resetForm() {
    formWasChangedDetail = false;
    rntrcController.text = '';
    codigoAgendamentoController.text = '';
  }

  @override
  void selectRowForEditing(PlutoRow? row) async {
    if (row == null) {
      showInfoSnackBar(message: 'message_select_one_to_edited'.tr);
      return;
    }

    selectRowForEditingByTempId(row.cells['tempId']?.value);
  }

  @override
  void selectRowForEditingById(int id) {}

  void selectRowForEditingByTempId(String tempId) {
		isNewRecord = false;
    final model = mdfeRodoviarioModelList.firstWhere((m) => m.tempId == tempId);
    mdfeRodoviarioModel = model.clone();
		mdfeRodoviarioModel.tempId = model.tempId;
    updateControllersFromModel();
    Get.to(() => MdfeRodoviarioEditPage());
  }

  void updateControllersFromModel() {
    rntrcController.text = mdfeRodoviarioModel.rntrc ?? '';
    codigoAgendamentoController.text = mdfeRodoviarioModel.codigoAgendamento ?? '';
    formWasChangedDetail = false;
  }

  @override
  Future<void> save() async {
    if (!mdfeRodoviarioFormKey.currentState!.validate()) {
      showErrorSnackBar(message: 'validator_form_message'.tr);
      return;
    }

    if (formWasChangedDetail) {
      if (isNewRecord) {
        mdfeRodoviarioModelList.insert(0, mdfeRodoviarioModel.clone());
      } else {
        final index = mdfeRodoviarioModelList.indexWhere((m) => m.tempId == mdfeRodoviarioModel.tempId);
        if (index >= 0) {
          mdfeRodoviarioModelList[index] = mdfeRodoviarioModel.clone();
        }
      }

      userMadeChanges = true;
      loadData();
      Get.back(result: true);
    } else {
      Get.back();
    }
  }


  @override
  Future deleteSelected() async {
    final currentRow = plutoGridStateManager.currentRow;
    if (currentRow == null) {
      showInfoSnackBar(message: 'message_select_one_to_delete'.tr);
      return null;
    }
    showDeleteDialog(() async {
      final id = currentRow.cells['id']?.value;
      final tempId = currentRow.cells['tempId']?.value;
      mdfeRodoviarioModelList.removeWhere((model) => (id != 0 && model.id == id) || (id == 0 && model.tempId == tempId));
      plutoGridStateManager.removeCurrentRow();
      userMadeChanges = true;
    });
  }

  @override
  void preventDataLoss() {
    if (formWasChangedDetail) {
      showQuestionDialog('message_data_loss'.tr, () => Get.back());
    } else {
      formWasChangedDetail = false;
      Get.back();
    }
  }

  @override
  void onClose() {
    rntrcController.dispose();
    codigoAgendamentoController.dispose();
  }

}