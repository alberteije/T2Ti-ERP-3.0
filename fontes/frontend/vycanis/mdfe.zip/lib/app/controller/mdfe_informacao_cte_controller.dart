import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:extended_masked_text/extended_masked_text.dart';

import 'package:mdfe/app/page/shared_widget/message_dialog.dart';
import 'package:mdfe/app/page/grid_columns/grid_columns_imports.dart';
import 'package:mdfe/app/routes/app_routes.dart';
import 'package:mdfe/app/controller/controller_imports.dart';
import 'package:mdfe/app/data/model/model_imports.dart';
import 'package:mdfe/app/data/repository/mdfe_informacao_cte_repository.dart';

class MdfeInformacaoCteController extends ControllerBase<MdfeInformacaoCteModel, MdfeInformacaoCteRepository> {

  MdfeInformacaoCteController({required super.repository}) {
    dbColumns = MdfeInformacaoCteModel.dbColumns;
    aliasColumns = MdfeInformacaoCteModel.aliasColumns;
    gridColumns = mdfeInformacaoCteGridColumns();
    functionName = "mdfe_informacao_cte";
    screenTitle = "Informacão CTE";
  }

  @override
  MdfeInformacaoCteModel createNewModel() => MdfeInformacaoCteModel();

  @override
  final standardFieldForFilter = MdfeInformacaoCteModel.aliasColumns[MdfeInformacaoCteModel.dbColumns.indexOf('chave_cte')];

  final mdfeMunicipioDescarregaModelController = TextEditingController();
  final chaveCteController = TextEditingController();
  final segundoCodigoBarraController = TextEditingController();
  final indicadorReentregaController = MoneyMaskedTextController(precision: 0, decimalSeparator: '', thousandSeparator: '');

  final Map<String, dynamic> mobileConfig = {
    'primaryColumns': ['chave_cte'],
    'secondaryColumns': ['segundo_codigo_barra'],
  };

  List<Map<String, dynamic>> get mobileItems {
    return modelList.map((mdfeInformacaoCte) => mdfeInformacaoCte.toJson).toList();
  }

  @override
  void prepareForInsert() {
    isNewRecord = true;
    currentModel = createNewModel();
    _resetForm();
    Get.toNamed(Routes.mdfeInformacaoCteEditPage);
  }

  void _resetForm() {
    formWasChanged = false;
    mdfeMunicipioDescarregaModelController.text = '';
    chaveCteController.text = '';
    segundoCodigoBarraController.text = '';
    indicadorReentregaController.updateValue(0);
  }

  @override
  void selectRowForEditingById(int id) {
    final model = modelList.firstWhere((m) => m.id == id);
    currentModel = model.clone();
    updateControllersFromModel();
    Get.toNamed(Routes.mdfeInformacaoCteEditPage);
  }

  void updateControllersFromModel() {
    mdfeMunicipioDescarregaModelController.text = currentModel.mdfeMunicipioDescarregaModel?.nomeMunicipio?.toString() ?? '';
    chaveCteController.text = currentModel.chaveCte ?? '';
    segundoCodigoBarraController.text = currentModel.segundoCodigoBarra ?? '';
    indicadorReentregaController.updateValue((currentModel.indicadorReentrega ?? 0).toDouble());
    formWasChanged = false;
  }

  @override
  Future<void> save() async {
    if (!formKey.currentState!.validate()) {
      showErrorSnackBar(message: 'validator_form_message'.tr);
      return;
    }

    final existingIndex = modelList.indexWhere((m) => m.id == currentModel.id);

    if (existingIndex >= 0) {
      modelList[existingIndex] = currentModel.clone();
    }

    final result = await repository.save(mdfeInformacaoCteModel: currentModel);
    if (result == null) return;

    if (existingIndex >= 0) {
      modelList[existingIndex] = result;
    } else {
      modelList.insert(0, result);
    }

    if (!GetPlatform.isMobile) {
      updateGridRow(result);
    }

    Get.back(result: true);
  }

  Future callMdfeMunicipioDescarregaLookup() async { 
		final lookupController = Get.find<LookupController>(); 
		lookupController.refreshItems(standardValue: '%'); 
		lookupController.title = '${'lookup_page_title'.tr} [Id Mdfe Municipio Descarrega]'; 
		lookupController.route = '/mdfe-municipio-descarrega/'; 
		lookupController.gridColumns = mdfeMunicipioDescarregaGridColumns(isForLookup: true); 
		lookupController.aliasColumns = MdfeMunicipioDescarregaModel.aliasColumns; 
		lookupController.dbColumns = MdfeMunicipioDescarregaModel.dbColumns; 
		lookupController.standardColumn = MdfeMunicipioDescarregaModel.aliasColumns[MdfeMunicipioDescarregaModel.dbColumns.indexOf('nomeMunicipio')]; 

		final plutoRowResult = await Get.toNamed(Routes.lookupPage); 
		if (plutoRowResult != null) { 
			currentModel.idMdfeMunicipioDescarrega = plutoRowResult.cells['id']!.value; 
			currentModel.mdfeMunicipioDescarregaModel = MdfeMunicipioDescarregaModel.fromPlutoRow(plutoRowResult); 
			mdfeMunicipioDescarregaModelController.text = currentModel.mdfeMunicipioDescarregaModel?.nomeMunicipio ?? ''; 
			formWasChanged = true; 
		}
	}


  @override
  void onClose() {
    mdfeMunicipioDescarregaModelController.dispose();
    chaveCteController.dispose();
    segundoCodigoBarraController.dispose();
    indicadorReentregaController.dispose();
    super.onClose();
  }

}