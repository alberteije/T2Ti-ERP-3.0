import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:pluto_grid/pluto_grid.dart';
import 'package:extended_masked_text/extended_masked_text.dart';

import 'package:mdfe/app/page/page_imports.dart';
import 'package:mdfe/app/page/shared_widget/message_dialog.dart';
import 'package:mdfe/app/page/grid_columns/grid_columns_imports.dart';
import 'package:mdfe/app/controller/controller_imports.dart';
import 'package:mdfe/app/data/model/model_imports.dart';

class MdfeInformacaoSeguroController extends ControllerBase<MdfeInformacaoSeguroModel, void> {

  MdfeInformacaoSeguroController() : super(repository: null) {
    dbColumns = MdfeInformacaoSeguroModel.dbColumns;
    aliasColumns = MdfeInformacaoSeguroModel.aliasColumns;
    gridColumns = mdfeInformacaoSeguroGridColumns();
    functionName = "mdfe_informacao_seguro";
    screenTitle = "Informação Seguro";
  }

  final _mdfeInformacaoSeguroModel = MdfeInformacaoSeguroModel().obs;
  MdfeInformacaoSeguroModel get mdfeInformacaoSeguroModel => _mdfeInformacaoSeguroModel.value;
  set mdfeInformacaoSeguroModel(value) => _mdfeInformacaoSeguroModel.value = value ?? MdfeInformacaoSeguroModel();

  List<MdfeInformacaoSeguroModel> get mdfeInformacaoSeguroModelList => Get.find<MdfeCabecalhoController>().currentModel.mdfeInformacaoSeguroModelList ?? [];

  final _userMadeChanges = false.obs;
  get userMadeChanges => _userMadeChanges.value;
  set userMadeChanges(value) => _userMadeChanges.value = value;

  final _formWasChangedDetail = false.obs;
  bool get formWasChangedDetail => _formWasChangedDetail.value;
  set formWasChangedDetail(value) => _formWasChangedDetail.value = value;

  late PlutoGridStateManager _plutoGridStateManager;
  @override
  PlutoGridStateManager get plutoGridStateManager => _plutoGridStateManager;
  @override
  set plutoGridStateManager(value) => _plutoGridStateManager = value;

  final mdfeInformacaoSeguroScaffoldKey = GlobalKey<ScaffoldState>();
  final mdfeInformacaoSeguroFormKey = GlobalKey<FormState>();

  @override
  MdfeInformacaoSeguroModel createNewModel() => MdfeInformacaoSeguroModel();

  @override
  final standardFieldForFilter = MdfeInformacaoSeguroModel.aliasColumns[MdfeInformacaoSeguroModel.dbColumns.indexOf('responsavel')];

  final responsavelController = MoneyMaskedTextController(precision: 0, decimalSeparator: '', thousandSeparator: '');
  final cnpjCpfController = MaskedTextController(mask: '000.000.000-00',);
  final seguradoraController = TextEditingController();
  final cnpjSeguradoraController = MaskedTextController(mask: '00.000.000/0000-00',);
  final apoliceController = TextEditingController();
  final averbacaoController = TextEditingController();

  final Map<String, dynamic> mobileConfig = {
    'primaryColumns': ['responsavel'],
    'secondaryColumns': ['cnpj_cpf'],
  };

  List<Map<String, dynamic>> get mobileItems {
    return modelList.map((mdfeInformacaoSeguro) => mdfeInformacaoSeguro.toJson).toList();
  }

  @override
  List<PlutoRow> plutoRows() => List<PlutoRow>.from(mdfeInformacaoSeguroModelList.map((model) => model.toPlutoRow()));

  @override
  Future<void> getList({Filter? filter}) async {}

  @override
  void prepareForInsert() {
    isNewRecord = true;
    mdfeInformacaoSeguroModel = createNewModel();
    _resetForm();
    Get.to(() => MdfeInformacaoSeguroEditPage());
  }

  void _resetForm() {
    formWasChangedDetail = false;
    responsavelController.updateValue(0);
    cnpjCpfController.text = '';
    seguradoraController.text = '';
    cnpjSeguradoraController.text = '';
    apoliceController.text = '';
    averbacaoController.text = '';
  }

  @override
  void selectRowForEditing(PlutoRow? row) async {
    if (row == null) {
      showInfoSnackBar(message: 'message_select_one_to_edited'.tr);
      return;
    }

    selectRowForEditingByTempId(row.cells['tempId']?.value);
  }

  @override
  void selectRowForEditingById(int id) {}

  void selectRowForEditingByTempId(String tempId) {
		isNewRecord = false;
    final model = mdfeInformacaoSeguroModelList.firstWhere((m) => m.tempId == tempId);
    mdfeInformacaoSeguroModel = model.clone();
		mdfeInformacaoSeguroModel.tempId = model.tempId;
    updateControllersFromModel();
    Get.to(() => MdfeInformacaoSeguroEditPage());
  }

  void updateControllersFromModel() {
    responsavelController.updateValue((mdfeInformacaoSeguroModel.responsavel ?? 0).toDouble());
    cnpjCpfController.text = mdfeInformacaoSeguroModel.cnpjCpf ?? '';
    seguradoraController.text = mdfeInformacaoSeguroModel.seguradora ?? '';
    cnpjSeguradoraController.text = mdfeInformacaoSeguroModel.cnpjSeguradora ?? '';
    apoliceController.text = mdfeInformacaoSeguroModel.apolice ?? '';
    averbacaoController.text = mdfeInformacaoSeguroModel.averbacao ?? '';
    formWasChangedDetail = false;
  }

  @override
  Future<void> save() async {
    if (!mdfeInformacaoSeguroFormKey.currentState!.validate()) {
      showErrorSnackBar(message: 'validator_form_message'.tr);
      return;
    }

    if (formWasChangedDetail) {
      if (isNewRecord) {
        mdfeInformacaoSeguroModelList.insert(0, mdfeInformacaoSeguroModel.clone());
      } else {
        final index = mdfeInformacaoSeguroModelList.indexWhere((m) => m.tempId == mdfeInformacaoSeguroModel.tempId);
        if (index >= 0) {
          mdfeInformacaoSeguroModelList[index] = mdfeInformacaoSeguroModel.clone();
        }
      }

      userMadeChanges = true;
      loadData();
      Get.back(result: true);
    } else {
      Get.back();
    }
  }


  @override
  Future deleteSelected() async {
    final currentRow = plutoGridStateManager.currentRow;
    if (currentRow == null) {
      showInfoSnackBar(message: 'message_select_one_to_delete'.tr);
      return null;
    }
    showDeleteDialog(() async {
      final id = currentRow.cells['id']?.value;
      final tempId = currentRow.cells['tempId']?.value;
      mdfeInformacaoSeguroModelList.removeWhere((model) => (id != 0 && model.id == id) || (id == 0 && model.tempId == tempId));
      plutoGridStateManager.removeCurrentRow();
      userMadeChanges = true;
    });
  }

  @override
  void preventDataLoss() {
    if (formWasChangedDetail) {
      showQuestionDialog('message_data_loss'.tr, () => Get.back());
    } else {
      formWasChangedDetail = false;
      Get.back();
    }
  }

  @override
  void onClose() {
    responsavelController.dispose();
    cnpjCpfController.dispose();
    seguradoraController.dispose();
    cnpjSeguradoraController.dispose();
    apoliceController.dispose();
    averbacaoController.dispose();
  }

}