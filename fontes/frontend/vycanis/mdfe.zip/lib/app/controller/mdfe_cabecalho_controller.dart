import 'dart:typed_data';

import 'package:flutter/material.dart';
import 'dart:math';
import 'package:get/get.dart';
import 'package:extended_masked_text/extended_masked_text.dart';
import 'package:mdfe/app/page/shared_page/shared_page_imports.dart';
import 'package:mdfe/app/page/shared_widget/input/input_imports.dart';

import 'package:mdfe/app/infra/infra_imports.dart';
import 'package:mdfe/app/page/page_imports.dart';
import 'package:mdfe/app/page/shared_widget/message_dialog.dart';
import 'package:mdfe/app/page/grid_columns/grid_columns_imports.dart';
import 'package:mdfe/app/routes/app_routes.dart';
import 'package:mdfe/app/controller/controller_imports.dart';
import 'package:mdfe/app/data/model/model_imports.dart';
import 'package:mdfe/app/data/repository/mdfe_cabecalho_repository.dart';

class MdfeCabecalhoController extends ControllerBase<MdfeCabecalhoModel, MdfeCabecalhoRepository> 
with GetSingleTickerProviderStateMixin {

  MdfeCabecalhoController({required super.repository}) {
    dbColumns = MdfeCabecalhoModel.dbColumns;
    aliasColumns = MdfeCabecalhoModel.aliasColumns;
    gridColumns = mdfeCabecalhoGridColumns();
    functionName = "mdfe_cabecalho";
    screenTitle = "MDFe";
  }

  final mdfeCabecalhoScaffoldKey = GlobalKey<ScaffoldState>();
  final mdfeCabecalhoTabPageScaffoldKey = GlobalKey<ScaffoldState>();
  final mdfeCabecalhoFormKey = GlobalKey<FormState>();
  late TabController tabController;
  String? mandatoryMessage;  

  @override
  MdfeCabecalhoModel createNewModel() => MdfeCabecalhoModel();

  @override
  final standardFieldForFilter = MdfeCabecalhoModel.aliasColumns[MdfeCabecalhoModel.dbColumns.indexOf('uf')];

  final ufController = CustomDropdownButtonController('AC');
  final tipoAmbienteController = CustomDropdownButtonController('1-Produção');
  final tipoEmitenteController = CustomDropdownButtonController('1-Prestador de serviço de transporte');
  final tipoTransportadoraController = CustomDropdownButtonController('ETC');
  final modeloController = CustomDropdownButtonController('58');
  final serieController = TextEditingController();
  final numeroMdfeController = TextEditingController();
  final codigoNumericoController = TextEditingController();
  final chaveAcessoController = TextEditingController();
  final digitoVerificadorController = MoneyMaskedTextController(precision: 0, decimalSeparator: '', thousandSeparator: '');
  final modalController = CustomDropdownButtonController('1-Rodoviário');
  final dataHoraEmissaoController = DatePickerItemController(null);
  final tipoEmissaoController = CustomDropdownButtonController('1-Normal');
  final processoEmissaoController = CustomDropdownButtonController('0-Emissão de MDF-e com aplicativo do  contribuinte');
  final versaoProcessoEmissaoController = TextEditingController();
  final ufInicioController = CustomDropdownButtonController('AC');
  final ufFimController = CustomDropdownButtonController('AC');
  final dataHoraPrevisaoViagemController = DatePickerItemController(null);
  final quantidadeTotalCteController = MoneyMaskedTextController(precision: 0, decimalSeparator: '', thousandSeparator: '');
  final quantidadeTotalNfeController = MoneyMaskedTextController(precision: 0, decimalSeparator: '', thousandSeparator: '');
  final quantidadeTotalMdfeController = MoneyMaskedTextController(precision: 0, decimalSeparator: '', thousandSeparator: '');
  final codigoUnidadeMedidaController = CustomDropdownButtonController('01-KG');
  final pesoBrutoCargaController = MoneyMaskedTextController();
  final valorCargaController = MoneyMaskedTextController();
  final numeroProtocoloController = TextEditingController();

  final Map<String, dynamic> mobileConfig = {
    'primaryColumns': ['uf'],
    'secondaryColumns': ['tipo_ambiente'],
  };

  List<Map<String, dynamic>> get mobileItems {
    return modelList.map((mdfeCabecalho) => mdfeCabecalho.toJson).toList();
  }

  @override
  void prepareForInsert() {
    isNewRecord = true;
    currentModel = createNewModel();
    _resetForm();
    tabController.animateTo(0);
    updateControllersFromModel();
    Get.toNamed(Routes.mdfeCabecalhoTabPage);
  }

  void _resetForm() {
    formWasChanged = false;
    ufController.selected = 'AC';
    tipoAmbienteController.selected = '1-Produção';
    tipoEmitenteController.selected = '1-Prestador de serviço de transporte';
    tipoTransportadoraController.selected = 'ETC';
    modeloController.selected = '58';
    serieController.text = '';
    numeroMdfeController.text = '';
    codigoNumericoController.text = '';
    chaveAcessoController.text = '';
    digitoVerificadorController.updateValue(0);
    modalController.selected = '1-Rodoviário';
    dataHoraEmissaoController.date = null;
    tipoEmissaoController.selected = '1-Normal';
    processoEmissaoController.selected = '0-Emissão de MDF-e com aplicativo do  contribuinte';
    versaoProcessoEmissaoController.text = '';
    ufInicioController.selected = 'AC';
    ufFimController.selected = 'AC';
    dataHoraPrevisaoViagemController.date = null;
    quantidadeTotalCteController.updateValue(0);
    quantidadeTotalNfeController.updateValue(0);
    quantidadeTotalMdfeController.updateValue(0);
    codigoUnidadeMedidaController.selected = '01-KG';
    pesoBrutoCargaController.updateValue(0);
    valorCargaController.updateValue(0);
    numeroProtocoloController.text = '';
  }

  @override
  void selectRowForEditingById(int id) {
    final model = modelList.firstWhere((m) => m.id == id);
    currentModel = model.clone();
    updateControllersFromModel();
    tabController.animateTo(0);
    Get.toNamed(Routes.mdfeCabecalhoTabPage);
  }

  _configureChildrenControllers() {
    //Lacre
		Get.put<MdfeLacreController>(MdfeLacreController()); 

    //Município Descarrega
		Get.put<MdfeMunicipioDescarregaController>(MdfeMunicipioDescarregaController()); 

    //Emitente
		Get.put<MdfeEmitenteController>(MdfeEmitenteController()); 

    //Percurso
		Get.put<MdfePercursoController>(MdfePercursoController()); 

    //Município Carregamento
		Get.put<MdfeMunicipioCarregamentoController>(MdfeMunicipioCarregamentoController()); 

    //Rodoviário
		Get.put<MdfeRodoviarioController>(MdfeRodoviarioController()); 

    //Informação Seguro
		Get.put<MdfeInformacaoSeguroController>(MdfeInformacaoSeguroController()); 

  }
	
	_releaseChildrenControllers() {
    //Lacre
		Get.delete<MdfeLacreController>(); 

    //Município Descarrega
		Get.delete<MdfeMunicipioDescarregaController>(); 

    //Emitente
		Get.delete<MdfeEmitenteController>(); 

    //Percurso
		Get.delete<MdfePercursoController>(); 

    //Município Carregamento
		Get.delete<MdfeMunicipioCarregamentoController>(); 

    //Rodoviário
		Get.delete<MdfeRodoviarioController>(); 

    //Informação Seguro
		Get.delete<MdfeInformacaoSeguroController>(); 

	}
  
  void updateControllersFromModel() {
    ufController.selected = currentModel.uf ?? 'AC';
    tipoAmbienteController.selected = currentModel.tipoAmbiente ?? '1-Produção';
    tipoEmitenteController.selected = currentModel.tipoEmitente ?? '1-Prestador de serviço de transporte';
    tipoTransportadoraController.selected = currentModel.tipoTransportadora ?? 'ETC';
    modeloController.selected = currentModel.modelo ?? '58';
    serieController.text = currentModel.serie ?? '';
    numeroMdfeController.text = currentModel.numeroMdfe ?? '';
    codigoNumericoController.text = currentModel.codigoNumerico ?? '';
    chaveAcessoController.text = currentModel.chaveAcesso ?? '';
    digitoVerificadorController.updateValue((currentModel.digitoVerificador ?? 0).toDouble());
    modalController.selected = currentModel.modal ?? '1-Rodoviário';
    dataHoraEmissaoController.date = currentModel.dataHoraEmissao;
    tipoEmissaoController.selected = currentModel.tipoEmissao ?? '1-Normal';
    processoEmissaoController.selected = currentModel.processoEmissao ?? '0-Emissão de MDF-e com aplicativo do  contribuinte';
    versaoProcessoEmissaoController.text = currentModel.versaoProcessoEmissao ?? '';
    ufInicioController.selected = currentModel.ufInicio ?? 'AC';
    ufFimController.selected = currentModel.ufFim ?? 'AC';
    dataHoraPrevisaoViagemController.date = currentModel.dataHoraPrevisaoViagem;
    quantidadeTotalCteController.updateValue((currentModel.quantidadeTotalCte ?? 0).toDouble());
    quantidadeTotalNfeController.updateValue((currentModel.quantidadeTotalNfe ?? 0).toDouble());
    quantidadeTotalMdfeController.updateValue((currentModel.quantidadeTotalMdfe ?? 0).toDouble());
    codigoUnidadeMedidaController.selected = currentModel.codigoUnidadeMedida ?? '01-KG';
    pesoBrutoCargaController.updateValue(currentModel.pesoBrutoCarga ?? 0);
    valorCargaController.updateValue(currentModel.valorCarga ?? 0);
    numeroProtocoloController.text = currentModel.numeroProtocolo ?? '';

    formWasChanged = false;
    _updateChildrenControllersFromModel();
  }

  void _updateChildrenControllersFromModel() {
    //Lacre
		final mdfeLacreController = Get.find<MdfeLacreController>(); 
		mdfeLacreController.userMadeChanges = false; 

    //Município Descarrega
		final mdfeMunicipioDescarregaController = Get.find<MdfeMunicipioDescarregaController>(); 
		mdfeMunicipioDescarregaController.userMadeChanges = false; 

    //Emitente
		final mdfeEmitenteController = Get.find<MdfeEmitenteController>(); 
		mdfeEmitenteController.userMadeChanges = false; 

    //Percurso
		final mdfePercursoController = Get.find<MdfePercursoController>(); 
		mdfePercursoController.userMadeChanges = false; 

    //Município Carregamento
		final mdfeMunicipioCarregamentoController = Get.find<MdfeMunicipioCarregamentoController>(); 
		mdfeMunicipioCarregamentoController.userMadeChanges = false; 

    //Rodoviário
		final mdfeRodoviarioController = Get.find<MdfeRodoviarioController>(); 
		mdfeRodoviarioController.userMadeChanges = false; 

    //Informação Seguro
		final mdfeInformacaoSeguroController = Get.find<MdfeInformacaoSeguroController>(); 
		mdfeInformacaoSeguroController.userMadeChanges = false; 

  }

  @override
  Future<void> save() async {
    if (!validateCurrentForm()) return;
    if (validateForms()) {
      if (userMadeChanges()) {
        final existingIndex = modelList.indexWhere((m) => m.id == currentModel.id);

        if (existingIndex >= 0) {
          modelList[existingIndex] = currentModel.clone();
        }

        final result = await repository.save(mdfeCabecalhoModel: currentModel);
        if (result == null) return;

        if (existingIndex >= 0) {
          modelList[existingIndex] = result;
        } else {
          modelList.insert(0, result);
        }

        if (!GetPlatform.isMobile) {
          updateGridRow(result);
        }

        Get.back(result: true);
      } else {
        Get.back();
      }
    } 
  }


  List<Tab> tabItems = [
    Tab( 
			icon: Icon(iconDataList[Random().nextInt(10)]), 
			text: 'MDFe', 
		),
    Tab( 
			icon: Icon(iconDataList[Random().nextInt(10)]), 
			text: 'Lacre', 
		),
    Tab( 
			icon: Icon(iconDataList[Random().nextInt(10)]), 
			text: 'Município Descarrega', 
		),
    Tab( 
			icon: Icon(iconDataList[Random().nextInt(10)]), 
			text: 'Emitente', 
		),
    Tab( 
			icon: Icon(iconDataList[Random().nextInt(10)]), 
			text: 'Percurso', 
		),
    Tab( 
			icon: Icon(iconDataList[Random().nextInt(10)]), 
			text: 'Município Carregamento', 
		),
    Tab( 
			icon: Icon(iconDataList[Random().nextInt(10)]), 
			text: 'Rodoviário', 
		),
    Tab( 
			icon: Icon(iconDataList[Random().nextInt(10)]), 
			text: 'Informação Seguro', 
		),
  ];

  List<Widget> tabPages() {
    return [
      MdfeCabecalhoEditPage(),
      const MdfeLacreListPage(),
      const MdfeMunicipioDescarregaListPage(),
      const MdfeEmitenteListPage(),
      const MdfePercursoListPage(),
      const MdfeMunicipioCarregamentoListPage(),
      const MdfeRodoviarioListPage(),
      const MdfeInformacaoSeguroListPage(),
    ];
  }

  @override
  void preventDataLoss() {
    if (userMadeChanges()) {
      showQuestionDialog('message_data_loss'.tr, () { 
        Get.back(); 
      });
    } else {
      Get.back();
    }
  }  

  bool userMadeChanges() {
    return
    formWasChanged 
    || 
		Get.find<MdfeLacreController>().userMadeChanges
    || 
		Get.find<MdfeMunicipioDescarregaController>().userMadeChanges
    || 
		Get.find<MdfeEmitenteController>().userMadeChanges
    || 
		Get.find<MdfePercursoController>().userMadeChanges
    || 
		Get.find<MdfeMunicipioCarregamentoController>().userMadeChanges
    || 
		Get.find<MdfeRodoviarioController>().userMadeChanges
    || 
		Get.find<MdfeInformacaoSeguroController>().userMadeChanges
    ;
  }

  void tabChange(int index) {
    validateCurrentForm();
  }

  bool validateCurrentForm() {
    return true;
  }

  bool validateForms() {
    return true;
  }

  Future transmitirDocumento() async {
    if (currentModel.id == null) {
      showErrorSnackBar(message: 'Primeiro salve o documento para então transmiti-lo.');
      return;
    }

    showQuestionDialog('Deseja Gerar e Transmitir o Documento?', () async {
      try {
        final result = await repository.transmitirDocumento(mdfeCabecalhoModel: currentModel);
        if (result == null) return;

        if (result is String) {
          showErrorDialog('Ocorreu um problema na geração do documento: \n$result');
        } else if (result is Uint8List) {
          _imprimirDanfse(result);
        }
      } catch (e) {
        showErrorSnackBar(message: "Erro ao transmitir o documento: ${e.toString()}");
      }
    });
  }

  void _imprimirDanfse(Uint8List danfse) {
    Get.to(() => PdfPage(
      title: "DAMDFe",
      pdfFile: danfse,
    ));
  }

  @override
  void onInit() {
    super.onInit();
    tabController = TabController(vsync: this, length: tabItems.length);
    _configureChildrenControllers();
  }
	
  @override
  void onClose() {
    tabController.dispose();
    ufController.dispose();
    tipoAmbienteController.dispose();
    tipoEmitenteController.dispose();
    tipoTransportadoraController.dispose();
    modeloController.dispose();
    serieController.dispose();
    numeroMdfeController.dispose();
    codigoNumericoController.dispose();
    chaveAcessoController.dispose();
    digitoVerificadorController.dispose();
    modalController.dispose();
    dataHoraEmissaoController.dispose();
    tipoEmissaoController.dispose();
    processoEmissaoController.dispose();
    versaoProcessoEmissaoController.dispose();
    ufInicioController.dispose();
    ufFimController.dispose();
    dataHoraPrevisaoViagemController.dispose();
    quantidadeTotalCteController.dispose();
    quantidadeTotalNfeController.dispose();
    quantidadeTotalMdfeController.dispose();
    codigoUnidadeMedidaController.dispose();
    pesoBrutoCargaController.dispose();
    valorCargaController.dispose();
    numeroProtocoloController.dispose();
    _releaseChildrenControllers();
    super.onClose();
  }	
}