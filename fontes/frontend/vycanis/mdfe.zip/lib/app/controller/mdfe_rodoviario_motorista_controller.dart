import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:extended_masked_text/extended_masked_text.dart';

import 'package:mdfe/app/page/shared_widget/message_dialog.dart';
import 'package:mdfe/app/page/grid_columns/grid_columns_imports.dart';
import 'package:mdfe/app/routes/app_routes.dart';
import 'package:mdfe/app/controller/controller_imports.dart';
import 'package:mdfe/app/data/model/model_imports.dart';
import 'package:mdfe/app/data/repository/mdfe_rodoviario_motorista_repository.dart';

class MdfeRodoviarioMotoristaController extends ControllerBase<MdfeRodoviarioMotoristaModel, MdfeRodoviarioMotoristaRepository> {

  MdfeRodoviarioMotoristaController({required super.repository}) {
    dbColumns = MdfeRodoviarioMotoristaModel.dbColumns;
    aliasColumns = MdfeRodoviarioMotoristaModel.aliasColumns;
    gridColumns = mdfeRodoviarioMotoristaGridColumns();
    functionName = "mdfe_rodoviario_motorista";
    screenTitle = "Rodoviario Motorista";
  }

  @override
  MdfeRodoviarioMotoristaModel createNewModel() => MdfeRodoviarioMotoristaModel();

  @override
  final standardFieldForFilter = MdfeRodoviarioMotoristaModel.aliasColumns[MdfeRodoviarioMotoristaModel.dbColumns.indexOf('nome')];

  final mdfeRodoviarioModelController = TextEditingController();
  final nomeController = TextEditingController();
  final cpfController = MaskedTextController(mask: '000.000.000-00',);

  final Map<String, dynamic> mobileConfig = {
    'primaryColumns': ['nome'],
    'secondaryColumns': ['cpf'],
  };

  List<Map<String, dynamic>> get mobileItems {
    return modelList.map((mdfeRodoviarioMotorista) => mdfeRodoviarioMotorista.toJson).toList();
  }

  @override
  void prepareForInsert() {
    isNewRecord = true;
    currentModel = createNewModel();
    _resetForm();
    Get.toNamed(Routes.mdfeRodoviarioMotoristaEditPage);
  }

  void _resetForm() {
    formWasChanged = false;
    mdfeRodoviarioModelController.text = '';
    nomeController.text = '';
    cpfController.text = '';
  }

  @override
  void selectRowForEditingById(int id) {
    final model = modelList.firstWhere((m) => m.id == id);
    currentModel = model.clone();
    updateControllersFromModel();
    Get.toNamed(Routes.mdfeRodoviarioMotoristaEditPage);
  }

  void updateControllersFromModel() {
    mdfeRodoviarioModelController.text = currentModel.mdfeRodoviarioModel?.codigoAgendamento?.toString() ?? '';
    nomeController.text = currentModel.nome ?? '';
    cpfController.text = currentModel.cpf ?? '';
    formWasChanged = false;
  }

  @override
  Future<void> save() async {
    if (!formKey.currentState!.validate()) {
      showErrorSnackBar(message: 'validator_form_message'.tr);
      return;
    }

    final existingIndex = modelList.indexWhere((m) => m.id == currentModel.id);

    if (existingIndex >= 0) {
      modelList[existingIndex] = currentModel.clone();
    }

    final result = await repository.save(mdfeRodoviarioMotoristaModel: currentModel);
    if (result == null) return;

    if (existingIndex >= 0) {
      modelList[existingIndex] = result;
    } else {
      modelList.insert(0, result);
    }

    if (!GetPlatform.isMobile) {
      updateGridRow(result);
    }

    Get.back(result: true);
  }

  Future callMdfeRodoviarioLookup() async { 
		final lookupController = Get.find<LookupController>(); 
		lookupController.refreshItems(standardValue: '%'); 
		lookupController.title = '${'lookup_page_title'.tr} [Id Mdfe Rodoviario]'; 
		lookupController.route = '/mdfe-rodoviario/'; 
		lookupController.gridColumns = mdfeRodoviarioGridColumns(isForLookup: true); 
		lookupController.aliasColumns = MdfeRodoviarioModel.aliasColumns; 
		lookupController.dbColumns = MdfeRodoviarioModel.dbColumns; 
		lookupController.standardColumn = MdfeRodoviarioModel.aliasColumns[MdfeRodoviarioModel.dbColumns.indexOf('codigoAgendamento')]; 

		final plutoRowResult = await Get.toNamed(Routes.lookupPage); 
		if (plutoRowResult != null) { 
			currentModel.idMdfeRodoviario = plutoRowResult.cells['id']!.value; 
			currentModel.mdfeRodoviarioModel = MdfeRodoviarioModel.fromPlutoRow(plutoRowResult); 
			mdfeRodoviarioModelController.text = currentModel.mdfeRodoviarioModel?.codigoAgendamento ?? ''; 
			formWasChanged = true; 
		}
	}


  @override
  void onClose() {
    mdfeRodoviarioModelController.dispose();
    nomeController.dispose();
    cpfController.dispose();
    super.onClose();
  }

}