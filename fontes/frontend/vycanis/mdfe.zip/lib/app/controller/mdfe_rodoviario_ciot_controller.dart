import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:extended_masked_text/extended_masked_text.dart';

import 'package:mdfe/app/page/shared_widget/message_dialog.dart';
import 'package:mdfe/app/page/grid_columns/grid_columns_imports.dart';
import 'package:mdfe/app/routes/app_routes.dart';
import 'package:mdfe/app/controller/controller_imports.dart';
import 'package:mdfe/app/data/model/model_imports.dart';
import 'package:mdfe/app/data/repository/mdfe_rodoviario_ciot_repository.dart';

class MdfeRodoviarioCiotController extends ControllerBase<MdfeRodoviarioCiotModel, MdfeRodoviarioCiotRepository> {

  MdfeRodoviarioCiotController({required super.repository}) {
    dbColumns = MdfeRodoviarioCiotModel.dbColumns;
    aliasColumns = MdfeRodoviarioCiotModel.aliasColumns;
    gridColumns = mdfeRodoviarioCiotGridColumns();
    functionName = "mdfe_rodoviario_ciot";
    screenTitle = "Rodoviario CIOT";
  }

  @override
  MdfeRodoviarioCiotModel createNewModel() => MdfeRodoviarioCiotModel();

  @override
  final standardFieldForFilter = MdfeRodoviarioCiotModel.aliasColumns[MdfeRodoviarioCiotModel.dbColumns.indexOf('ciot')];

  final mdfeRodoviarioModelController = TextEditingController();
  final ciotController = TextEditingController();
  final cpfController = MaskedTextController(mask: '000.000.000-00',);
  final cnpjController = MaskedTextController(mask: '00.000.000/0000-00',);

  final Map<String, dynamic> mobileConfig = {
    'primaryColumns': ['ciot'],
    'secondaryColumns': ['cpf'],
  };

  List<Map<String, dynamic>> get mobileItems {
    return modelList.map((mdfeRodoviarioCiot) => mdfeRodoviarioCiot.toJson).toList();
  }

  @override
  void prepareForInsert() {
    isNewRecord = true;
    currentModel = createNewModel();
    _resetForm();
    Get.toNamed(Routes.mdfeRodoviarioCiotEditPage);
  }

  void _resetForm() {
    formWasChanged = false;
    mdfeRodoviarioModelController.text = '';
    ciotController.text = '';
    cpfController.text = '';
    cnpjController.text = '';
  }

  @override
  void selectRowForEditingById(int id) {
    final model = modelList.firstWhere((m) => m.id == id);
    currentModel = model.clone();
    updateControllersFromModel();
    Get.toNamed(Routes.mdfeRodoviarioCiotEditPage);
  }

  void updateControllersFromModel() {
    mdfeRodoviarioModelController.text = currentModel.mdfeRodoviarioModel?.codigoAgendamento?.toString() ?? '';
    ciotController.text = currentModel.ciot ?? '';
    cpfController.text = currentModel.cpf ?? '';
    cnpjController.text = currentModel.cnpj ?? '';
    formWasChanged = false;
  }

  @override
  Future<void> save() async {
    if (!formKey.currentState!.validate()) {
      showErrorSnackBar(message: 'validator_form_message'.tr);
      return;
    }

    final existingIndex = modelList.indexWhere((m) => m.id == currentModel.id);

    if (existingIndex >= 0) {
      modelList[existingIndex] = currentModel.clone();
    }

    final result = await repository.save(mdfeRodoviarioCiotModel: currentModel);
    if (result == null) return;

    if (existingIndex >= 0) {
      modelList[existingIndex] = result;
    } else {
      modelList.insert(0, result);
    }

    if (!GetPlatform.isMobile) {
      updateGridRow(result);
    }

    Get.back(result: true);
  }

  Future callMdfeRodoviarioLookup() async { 
		final lookupController = Get.find<LookupController>(); 
		lookupController.refreshItems(standardValue: '%'); 
		lookupController.title = '${'lookup_page_title'.tr} [Id Mdfe Rodoviario]'; 
		lookupController.route = '/mdfe-rodoviario/'; 
		lookupController.gridColumns = mdfeRodoviarioGridColumns(isForLookup: true); 
		lookupController.aliasColumns = MdfeRodoviarioModel.aliasColumns; 
		lookupController.dbColumns = MdfeRodoviarioModel.dbColumns; 
		lookupController.standardColumn = MdfeRodoviarioModel.aliasColumns[MdfeRodoviarioModel.dbColumns.indexOf('codigoAgendamento')]; 

		final plutoRowResult = await Get.toNamed(Routes.lookupPage); 
		if (plutoRowResult != null) { 
			currentModel.idMdfeRodoviario = plutoRowResult.cells['id']!.value; 
			currentModel.mdfeRodoviarioModel = MdfeRodoviarioModel.fromPlutoRow(plutoRowResult); 
			mdfeRodoviarioModelController.text = currentModel.mdfeRodoviarioModel?.codigoAgendamento ?? ''; 
			formWasChanged = true; 
		}
	}


  @override
  void onClose() {
    mdfeRodoviarioModelController.dispose();
    ciotController.dispose();
    cpfController.dispose();
    cnpjController.dispose();
    super.onClose();
  }

}