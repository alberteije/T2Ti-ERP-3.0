import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:extended_masked_text/extended_masked_text.dart';
import 'package:mdfe/app/page/shared_widget/input/input_imports.dart';

import 'package:mdfe/app/page/shared_widget/message_dialog.dart';
import 'package:mdfe/app/page/grid_columns/grid_columns_imports.dart';
import 'package:mdfe/app/routes/app_routes.dart';
import 'package:mdfe/app/controller/controller_imports.dart';
import 'package:mdfe/app/data/model/model_imports.dart';
import 'package:mdfe/app/data/repository/mdfe_rodoviario_veiculo_repository.dart';

class MdfeRodoviarioVeiculoController extends ControllerBase<MdfeRodoviarioVeiculoModel, MdfeRodoviarioVeiculoRepository> {

  MdfeRodoviarioVeiculoController({required super.repository}) {
    dbColumns = MdfeRodoviarioVeiculoModel.dbColumns;
    aliasColumns = MdfeRodoviarioVeiculoModel.aliasColumns;
    gridColumns = mdfeRodoviarioVeiculoGridColumns();
    functionName = "mdfe_rodoviario_veiculo";
    screenTitle = "Rodoviario Veiculo";
  }

  @override
  MdfeRodoviarioVeiculoModel createNewModel() => MdfeRodoviarioVeiculoModel();

  @override
  final standardFieldForFilter = MdfeRodoviarioVeiculoModel.aliasColumns[MdfeRodoviarioVeiculoModel.dbColumns.indexOf('codigo_interno')];

  final mdfeRodoviarioModelController = TextEditingController();
  final codigoInternoController = TextEditingController();
  final placaController = TextEditingController();
  final renavamController = TextEditingController();
  final taraController = MoneyMaskedTextController(precision: 0, decimalSeparator: '', thousandSeparator: '');
  final capacidadeKgController = MoneyMaskedTextController(precision: 0, decimalSeparator: '', thousandSeparator: '');
  final capacidadeM3Controller = MoneyMaskedTextController(precision: 0, decimalSeparator: '', thousandSeparator: '');
  final tipoRodadoController = CustomDropdownButtonController('AAA');
  final tipoCarroceriaController = CustomDropdownButtonController('AAA');
  final ufLicenciamentoController = CustomDropdownButtonController('AC');
  final proprietarioCpfController = MaskedTextController(mask: '000.000.000-00',);
  final proprietarioCnpjController = MaskedTextController(mask: '00.000.000/0000-00',);
  final proprietarioRntrcController = TextEditingController();
  final proprietarioNomeController = TextEditingController();
  final proprietarioIeController = TextEditingController();
  final proprietarioTipoController = MoneyMaskedTextController(precision: 0, decimalSeparator: '', thousandSeparator: '');

  final Map<String, dynamic> mobileConfig = {
    'primaryColumns': ['codigo_interno'],
    'secondaryColumns': ['placa'],
  };

  List<Map<String, dynamic>> get mobileItems {
    return modelList.map((mdfeRodoviarioVeiculo) => mdfeRodoviarioVeiculo.toJson).toList();
  }

  @override
  void prepareForInsert() {
    isNewRecord = true;
    currentModel = createNewModel();
    _resetForm();
    Get.toNamed(Routes.mdfeRodoviarioVeiculoEditPage);
  }

  void _resetForm() {
    formWasChanged = false;
    mdfeRodoviarioModelController.text = '';
    codigoInternoController.text = '';
    placaController.text = '';
    renavamController.text = '';
    taraController.updateValue(0);
    capacidadeKgController.updateValue(0);
    capacidadeM3Controller.updateValue(0);
    tipoRodadoController.selected = 'AAA';
    tipoCarroceriaController.selected = 'AAA';
    ufLicenciamentoController.selected = 'AC';
    proprietarioCpfController.text = '';
    proprietarioCnpjController.text = '';
    proprietarioRntrcController.text = '';
    proprietarioNomeController.text = '';
    proprietarioIeController.text = '';
    proprietarioTipoController.updateValue(0);
  }

  @override
  void selectRowForEditingById(int id) {
    final model = modelList.firstWhere((m) => m.id == id);
    currentModel = model.clone();
    updateControllersFromModel();
    Get.toNamed(Routes.mdfeRodoviarioVeiculoEditPage);
  }

  void updateControllersFromModel() {
    mdfeRodoviarioModelController.text = currentModel.mdfeRodoviarioModel?.codigoAgendamento?.toString() ?? '';
    codigoInternoController.text = currentModel.codigoInterno ?? '';
    placaController.text = currentModel.placa ?? '';
    renavamController.text = currentModel.renavam ?? '';
    taraController.updateValue((currentModel.tara ?? 0).toDouble());
    capacidadeKgController.updateValue((currentModel.capacidadeKg ?? 0).toDouble());
    capacidadeM3Controller.updateValue((currentModel.capacidadeM3 ?? 0).toDouble());
    tipoRodadoController.selected = currentModel.tipoRodado ?? 'AAA';
    tipoCarroceriaController.selected = currentModel.tipoCarroceria ?? 'AAA';
    ufLicenciamentoController.selected = currentModel.ufLicenciamento ?? 'AC';
    proprietarioCpfController.text = currentModel.proprietarioCpf ?? '';
    proprietarioCnpjController.text = currentModel.proprietarioCnpj ?? '';
    proprietarioRntrcController.text = currentModel.proprietarioRntrc ?? '';
    proprietarioNomeController.text = currentModel.proprietarioNome ?? '';
    proprietarioIeController.text = currentModel.proprietarioIe ?? '';
    proprietarioTipoController.updateValue((currentModel.proprietarioTipo ?? 0).toDouble());
    formWasChanged = false;
  }

  @override
  Future<void> save() async {
    if (!formKey.currentState!.validate()) {
      showErrorSnackBar(message: 'validator_form_message'.tr);
      return;
    }

    final existingIndex = modelList.indexWhere((m) => m.id == currentModel.id);

    if (existingIndex >= 0) {
      modelList[existingIndex] = currentModel.clone();
    }

    final result = await repository.save(mdfeRodoviarioVeiculoModel: currentModel);
    if (result == null) return;

    if (existingIndex >= 0) {
      modelList[existingIndex] = result;
    } else {
      modelList.insert(0, result);
    }

    if (!GetPlatform.isMobile) {
      updateGridRow(result);
    }

    Get.back(result: true);
  }

  Future callMdfeRodoviarioLookup() async { 
		final lookupController = Get.find<LookupController>(); 
		lookupController.refreshItems(standardValue: '%'); 
		lookupController.title = '${'lookup_page_title'.tr} [Id Mdfe Rodoviario]'; 
		lookupController.route = '/mdfe-rodoviario/'; 
		lookupController.gridColumns = mdfeRodoviarioGridColumns(isForLookup: true); 
		lookupController.aliasColumns = MdfeRodoviarioModel.aliasColumns; 
		lookupController.dbColumns = MdfeRodoviarioModel.dbColumns; 
		lookupController.standardColumn = MdfeRodoviarioModel.aliasColumns[MdfeRodoviarioModel.dbColumns.indexOf('codigoAgendamento')]; 

		final plutoRowResult = await Get.toNamed(Routes.lookupPage); 
		if (plutoRowResult != null) { 
			currentModel.idMdfeRodoviario = plutoRowResult.cells['id']!.value; 
			currentModel.mdfeRodoviarioModel = MdfeRodoviarioModel.fromPlutoRow(plutoRowResult); 
			mdfeRodoviarioModelController.text = currentModel.mdfeRodoviarioModel?.codigoAgendamento ?? ''; 
			formWasChanged = true; 
		}
	}


  @override
  void onClose() {
    mdfeRodoviarioModelController.dispose();
    codigoInternoController.dispose();
    placaController.dispose();
    renavamController.dispose();
    taraController.dispose();
    capacidadeKgController.dispose();
    capacidadeM3Controller.dispose();
    tipoRodadoController.dispose();
    tipoCarroceriaController.dispose();
    ufLicenciamentoController.dispose();
    proprietarioCpfController.dispose();
    proprietarioCnpjController.dispose();
    proprietarioRntrcController.dispose();
    proprietarioNomeController.dispose();
    proprietarioIeController.dispose();
    proprietarioTipoController.dispose();
    super.onClose();
  }

}