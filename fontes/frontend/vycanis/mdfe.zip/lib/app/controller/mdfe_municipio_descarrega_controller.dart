import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:pluto_grid/pluto_grid.dart';

import 'package:mdfe/app/page/page_imports.dart';
import 'package:mdfe/app/page/shared_widget/message_dialog.dart';
import 'package:mdfe/app/page/grid_columns/grid_columns_imports.dart';
import 'package:mdfe/app/controller/controller_imports.dart';
import 'package:mdfe/app/data/model/model_imports.dart';

class MdfeMunicipioDescarregaController extends ControllerBase<MdfeMunicipioDescarregaModel, void> {

  MdfeMunicipioDescarregaController() : super(repository: null) {
    dbColumns = MdfeMunicipioDescarregaModel.dbColumns;
    aliasColumns = MdfeMunicipioDescarregaModel.aliasColumns;
    gridColumns = mdfeMunicipioDescarregaGridColumns();
    functionName = "mdfe_municipio_descarrega";
    screenTitle = "Município Descarrega";
  }

  final _mdfeMunicipioDescarregaModel = MdfeMunicipioDescarregaModel().obs;
  MdfeMunicipioDescarregaModel get mdfeMunicipioDescarregaModel => _mdfeMunicipioDescarregaModel.value;
  set mdfeMunicipioDescarregaModel(value) => _mdfeMunicipioDescarregaModel.value = value ?? MdfeMunicipioDescarregaModel();

  List<MdfeMunicipioDescarregaModel> get mdfeMunicipioDescarregaModelList => Get.find<MdfeCabecalhoController>().currentModel.mdfeMunicipioDescarregaModelList ?? [];

  final _userMadeChanges = false.obs;
  get userMadeChanges => _userMadeChanges.value;
  set userMadeChanges(value) => _userMadeChanges.value = value;

  final _formWasChangedDetail = false.obs;
  bool get formWasChangedDetail => _formWasChangedDetail.value;
  set formWasChangedDetail(value) => _formWasChangedDetail.value = value;

  late PlutoGridStateManager _plutoGridStateManager;
  @override
  PlutoGridStateManager get plutoGridStateManager => _plutoGridStateManager;
  @override
  set plutoGridStateManager(value) => _plutoGridStateManager = value;

  final mdfeMunicipioDescarregaScaffoldKey = GlobalKey<ScaffoldState>();
  final mdfeMunicipioDescarregaFormKey = GlobalKey<FormState>();

  @override
  MdfeMunicipioDescarregaModel createNewModel() => MdfeMunicipioDescarregaModel();

  @override
  final standardFieldForFilter = MdfeMunicipioDescarregaModel.aliasColumns[MdfeMunicipioDescarregaModel.dbColumns.indexOf('codigo_municipio')];

  final codigoMunicipioController = TextEditingController();
  final nomeMunicipioController = TextEditingController();

  final Map<String, dynamic> mobileConfig = {
    'primaryColumns': ['codigo_municipio'],
    'secondaryColumns': ['nome_municipio'],
  };

  List<Map<String, dynamic>> get mobileItems {
    return modelList.map((mdfeMunicipioDescarrega) => mdfeMunicipioDescarrega.toJson).toList();
  }

  @override
  List<PlutoRow> plutoRows() => List<PlutoRow>.from(mdfeMunicipioDescarregaModelList.map((model) => model.toPlutoRow()));

  @override
  Future<void> getList({Filter? filter}) async {}

  @override
  void prepareForInsert() {
    isNewRecord = true;
    mdfeMunicipioDescarregaModel = createNewModel();
    _resetForm();
    Get.to(() => MdfeMunicipioDescarregaEditPage());
  }

  void _resetForm() {
    formWasChangedDetail = false;
    codigoMunicipioController.text = '';
    nomeMunicipioController.text = '';
  }

  @override
  void selectRowForEditing(PlutoRow? row) async {
    if (row == null) {
      showInfoSnackBar(message: 'message_select_one_to_edited'.tr);
      return;
    }

    selectRowForEditingByTempId(row.cells['tempId']?.value);
  }

  @override
  void selectRowForEditingById(int id) {}

  void selectRowForEditingByTempId(String tempId) {
		isNewRecord = false;
    final model = mdfeMunicipioDescarregaModelList.firstWhere((m) => m.tempId == tempId);
    mdfeMunicipioDescarregaModel = model.clone();
		mdfeMunicipioDescarregaModel.tempId = model.tempId;
    updateControllersFromModel();
    Get.to(() => MdfeMunicipioDescarregaEditPage());
  }

  void updateControllersFromModel() {
    codigoMunicipioController.text = mdfeMunicipioDescarregaModel.codigoMunicipio ?? '';
    nomeMunicipioController.text = mdfeMunicipioDescarregaModel.nomeMunicipio ?? '';
    formWasChangedDetail = false;
  }

  @override
  Future<void> save() async {
    if (!mdfeMunicipioDescarregaFormKey.currentState!.validate()) {
      showErrorSnackBar(message: 'validator_form_message'.tr);
      return;
    }

    if (formWasChangedDetail) {
      if (isNewRecord) {
        mdfeMunicipioDescarregaModelList.insert(0, mdfeMunicipioDescarregaModel.clone());
      } else {
        final index = mdfeMunicipioDescarregaModelList.indexWhere((m) => m.tempId == mdfeMunicipioDescarregaModel.tempId);
        if (index >= 0) {
          mdfeMunicipioDescarregaModelList[index] = mdfeMunicipioDescarregaModel.clone();
        }
      }

      userMadeChanges = true;
      loadData();
      Get.back(result: true);
    } else {
      Get.back();
    }
  }


  @override
  Future deleteSelected() async {
    final currentRow = plutoGridStateManager.currentRow;
    if (currentRow == null) {
      showInfoSnackBar(message: 'message_select_one_to_delete'.tr);
      return null;
    }
    showDeleteDialog(() async {
      final id = currentRow.cells['id']?.value;
      final tempId = currentRow.cells['tempId']?.value;
      mdfeMunicipioDescarregaModelList.removeWhere((model) => (id != 0 && model.id == id) || (id == 0 && model.tempId == tempId));
      plutoGridStateManager.removeCurrentRow();
      userMadeChanges = true;
    });
  }

  @override
  void preventDataLoss() {
    if (formWasChangedDetail) {
      showQuestionDialog('message_data_loss'.tr, () => Get.back());
    } else {
      formWasChangedDetail = false;
      Get.back();
    }
  }

  @override
  void onClose() {
    codigoMunicipioController.dispose();
    nomeMunicipioController.dispose();
  }

}