import 'package:flutter/material.dart';
import 'package:flutter_bootstrap/flutter_bootstrap.dart';
import 'package:get/get.dart';
import 'package:mdfe/app/data/domain/domain_imports.dart';
import 'package:mdfe/app/controller/mdfe_cabecalho_controller.dart';
import 'package:mdfe/app/infra/infra_imports.dart';
import 'package:mdfe/app/page/shared_widget/input/input_imports.dart';

class MdfeCabecalhoEditPage extends StatelessWidget {
	MdfeCabecalhoEditPage({Key? key}) : super(key: key);
	final mdfeCabecalhoController = Get.find<MdfeCabecalhoController>();

	@override
	Widget build(BuildContext context) {
			return Scaffold(
				key: mdfeCabecalhoController.mdfeCabecalhoScaffoldKey,
				body: SafeArea(
					top: false,
					bottom: false,
					child: Form(
						key: mdfeCabecalhoController.mdfeCabecalhoFormKey,
						autovalidateMode: AutovalidateMode.always,
						child: Scrollbar(
							controller: mdfeCabecalhoController.scrollController,
							child: SingleChildScrollView(
								controller: mdfeCabecalhoController.scrollController,
								child: BootstrapContainer(
									fluid: true,
									padding: const EdgeInsets.all(10),
									children: <Widget>[
										const Divider(
											color: Colors.transparent,
										),
										BootstrapRow(
											height: 60,
											children: <BootstrapCol>[
												BootstrapCol(
													sizes: 'col-12 col-md-2',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: CustomDropdownButton(
															controller: mdfeCabecalhoController.ufController,
															labelText: 'UF',
															hintText: 'Informe os dados para o campo Uf',
															items: MdfeCabecalhoDomain.ufListDropdown,
															onChanged: (dynamic newValue) {
																mdfeCabecalhoController.currentModel.uf = newValue;
																mdfeCabecalhoController.formWasChanged = true;
															},
														),
													),
												),
												BootstrapCol(
													sizes: 'col-12 col-md-2',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: CustomDropdownButton(
															controller: mdfeCabecalhoController.tipoAmbienteController,
															labelText: 'Tipo Ambiente',
															hintText: 'Informe os dados para o campo Tipo Ambiente',
															items: MdfeCabecalhoDomain.tipoAmbienteListDropdown,
															onChanged: (dynamic newValue) {
																mdfeCabecalhoController.currentModel.tipoAmbiente = newValue;
																mdfeCabecalhoController.formWasChanged = true;
															},
														),
													),
												),
												BootstrapCol(
													sizes: 'col-12 col-md-2',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: CustomDropdownButton(
															controller: mdfeCabecalhoController.tipoEmitenteController,
															labelText: 'Tipo Emitente',
															hintText: 'Informe os dados para o campo Tipo Emitente',
															items: MdfeCabecalhoDomain.tipoEmitenteListDropdown,
															onChanged: (dynamic newValue) {
																mdfeCabecalhoController.currentModel.tipoEmitente = newValue;
																mdfeCabecalhoController.formWasChanged = true;
															},
														),
													),
												),
												BootstrapCol(
													sizes: 'col-12 col-md-2',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: CustomDropdownButton(
															controller: mdfeCabecalhoController.tipoTransportadoraController,
															labelText: 'Tipo Transportadora',
															hintText: 'Informe os dados para o campo Tipo Transportadora',
															items: MdfeCabecalhoDomain.tipoTransportadoraListDropdown,
															onChanged: (dynamic newValue) {
																mdfeCabecalhoController.currentModel.tipoTransportadora = newValue;
																mdfeCabecalhoController.formWasChanged = true;
															},
														),
													),
												),
												BootstrapCol(
													sizes: 'col-12 col-md-2',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: CustomDropdownButton(
															controller: mdfeCabecalhoController.modeloController,
															labelText: 'Modelo',
															hintText: 'Informe os dados para o campo Modelo',
															items: MdfeCabecalhoDomain.modeloListDropdown,
															onChanged: (dynamic newValue) {
																mdfeCabecalhoController.currentModel.modelo = newValue;
																mdfeCabecalhoController.formWasChanged = true;
															},
														),
													),
												),
												BootstrapCol(
													sizes: 'col-12 col-md-2',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: TextFormField(
															autofocus: true,
															maxLength: 3,
															controller: mdfeCabecalhoController.serieController,
															decoration: inputDecoration(
																hintText: 'Informe os dados para o campo Serie',
																labelText: 'Serie',
																usePadding: true,
															),
															onSaved: (String? value) {},
															onChanged: (text) {
																mdfeCabecalhoController.currentModel.serie = text;
																mdfeCabecalhoController.formWasChanged = true;
															},
														),
													),
												),
											],
										),
										const Divider(
											color: Colors.transparent,
										),
										BootstrapRow(
											height: 60,
											children: <BootstrapCol>[
												BootstrapCol(
													sizes: 'col-12 col-md-3',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: TextFormField(
															autofocus: true,
															maxLength: 9,
															controller: mdfeCabecalhoController.numeroMdfeController,
															decoration: inputDecoration(
																hintText: 'Informe os dados para o campo Numero Mdfe',
																labelText: 'Numero MDFe',
																usePadding: true,
															),
															onSaved: (String? value) {},
															onChanged: (text) {
																mdfeCabecalhoController.currentModel.numeroMdfe = text;
																mdfeCabecalhoController.formWasChanged = true;
															},
														),
													),
												),
												BootstrapCol(
													sizes: 'col-12 col-md-3',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: TextFormField(
															autofocus: true,
															maxLength: 8,
															controller: mdfeCabecalhoController.codigoNumericoController,
															decoration: inputDecoration(
																hintText: 'Informe os dados para o campo Codigo Numerico',
																labelText: 'Codigo Numerico',
																usePadding: true,
															),
															onSaved: (String? value) {},
															onChanged: (text) {
																mdfeCabecalhoController.currentModel.codigoNumerico = text;
																mdfeCabecalhoController.formWasChanged = true;
															},
														),
													),
												),
												BootstrapCol(
													sizes: 'col-12 col-md-5',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: TextFormField(
															autofocus: true,
															maxLength: 44,
															controller: mdfeCabecalhoController.chaveAcessoController,
															decoration: inputDecoration(
																hintText: 'Informe os dados para o campo Chave Acesso',
																labelText: 'Chave Acesso',
																usePadding: true,
															),
															onSaved: (String? value) {},
															onChanged: (text) {
																mdfeCabecalhoController.currentModel.chaveAcesso = text;
																mdfeCabecalhoController.formWasChanged = true;
															},
														),
													),
												),
												BootstrapCol(
													sizes: 'col-12 col-md-1',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: TextFormField(
															autofocus: true,
															controller: mdfeCabecalhoController.digitoVerificadorController,
															decoration: inputDecoration(
																hintText: 'Informe os dados para o campo Digito Verificador',
																labelText: 'Digito Verificador',
																usePadding: true,
															),
															onSaved: (String? value) {},
															onChanged: (text) {
																mdfeCabecalhoController.currentModel.digitoVerificador = int.tryParse(text);
																mdfeCabecalhoController.formWasChanged = true;
															},
														),
													),
												),
											],
										),
										const Divider(
											color: Colors.transparent,
										),
										BootstrapRow(
											height: 60,
											children: <BootstrapCol>[
												BootstrapCol(
													sizes: 'col-12 col-md-3',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: CustomDropdownButton(
															controller: mdfeCabecalhoController.modalController,
															labelText: 'Modal',
															hintText: 'Informe os dados para o campo Modal',
															items: MdfeCabecalhoDomain.modalListDropdown,
															onChanged: (dynamic newValue) {
																mdfeCabecalhoController.currentModel.modal = newValue;
																mdfeCabecalhoController.formWasChanged = true;
															},
														),
													),
												),
												BootstrapCol(
													sizes: 'col-12 col-md-3',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: InputDecorator(
															decoration: inputDecoration(
																hintText: 'Informe os dados para o campo Data Hora Emissao',
																labelText: 'Data Hora Emissao',
																usePadding: true,
															),
															isEmpty: false,
															child: DatePickerItem(
																controller: mdfeCabecalhoController.dataHoraEmissaoController,
																firstDate: DateTime.parse('1000-01-01'),
																lastDate: DateTime.parse('5000-01-01'),
																onChanged: (DateTime? value) {
																	mdfeCabecalhoController.currentModel.dataHoraEmissao = value;
																	mdfeCabecalhoController.formWasChanged = true;
																},
															),
														),
													),
												),
												BootstrapCol(
													sizes: 'col-12 col-md-3',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: CustomDropdownButton(
															controller: mdfeCabecalhoController.tipoEmissaoController,
															labelText: 'Tipo Emissao',
															hintText: 'Informe os dados para o campo Tipo Emissao',
															items: MdfeCabecalhoDomain.tipoEmissaoListDropdown,
															onChanged: (dynamic newValue) {
																mdfeCabecalhoController.currentModel.tipoEmissao = newValue;
																mdfeCabecalhoController.formWasChanged = true;
															},
														),
													),
												),
												BootstrapCol(
													sizes: 'col-12 col-md-3',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: CustomDropdownButton(
															controller: mdfeCabecalhoController.processoEmissaoController,
															labelText: 'Processo Emissao',
															hintText: 'Informe os dados para o campo Processo Emissao',
															items: MdfeCabecalhoDomain.processoEmissaoListDropdown,
															onChanged: (dynamic newValue) {
																mdfeCabecalhoController.currentModel.processoEmissao = newValue;
																mdfeCabecalhoController.formWasChanged = true;
															},
														),
													),
												),
											],
										),
										const Divider(
											color: Colors.transparent,
										),
										BootstrapRow(
											height: 60,
											children: <BootstrapCol>[
												BootstrapCol(
													sizes: 'col-12 col-md-3',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: TextFormField(
															autofocus: true,
															maxLength: 20,
															controller: mdfeCabecalhoController.versaoProcessoEmissaoController,
															decoration: inputDecoration(
																hintText: 'Informe os dados para o campo Versao Processo Emissao',
																labelText: 'Versao Processo Emissao',
																usePadding: true,
															),
															onSaved: (String? value) {},
															onChanged: (text) {
																mdfeCabecalhoController.currentModel.versaoProcessoEmissao = text;
																mdfeCabecalhoController.formWasChanged = true;
															},
														),
													),
												),
												BootstrapCol(
													sizes: 'col-12 col-md-3',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: CustomDropdownButton(
															controller: mdfeCabecalhoController.ufInicioController,
															labelText: 'Uf Inicio',
															hintText: 'Informe os dados para o campo Uf Inicio',
															items: MdfeCabecalhoDomain.ufInicioListDropdown,
															onChanged: (dynamic newValue) {
																mdfeCabecalhoController.currentModel.ufInicio = newValue;
																mdfeCabecalhoController.formWasChanged = true;
															},
														),
													),
												),
												BootstrapCol(
													sizes: 'col-12 col-md-3',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: CustomDropdownButton(
															controller: mdfeCabecalhoController.ufFimController,
															labelText: 'Uf Fim',
															hintText: 'Informe os dados para o campo Uf Fim',
															items: MdfeCabecalhoDomain.ufFimListDropdown,
															onChanged: (dynamic newValue) {
																mdfeCabecalhoController.currentModel.ufFim = newValue;
																mdfeCabecalhoController.formWasChanged = true;
															},
														),
													),
												),
												BootstrapCol(
													sizes: 'col-12 col-md-3',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: InputDecorator(
															decoration: inputDecoration(
																hintText: 'Informe os dados para o campo Data Hora Previsao Viagem',
																labelText: 'Data Hora Previsao Viagem',
																usePadding: true,
															),
															isEmpty: false,
															child: DatePickerItem(
																controller: mdfeCabecalhoController.dataHoraPrevisaoViagemController,
																firstDate: DateTime.parse('1000-01-01'),
																lastDate: DateTime.parse('5000-01-01'),
																onChanged: (DateTime? value) {
																	mdfeCabecalhoController.currentModel.dataHoraPrevisaoViagem = value;
																	mdfeCabecalhoController.formWasChanged = true;
																},
															),
														),
													),
												),
											],
										),
										const Divider(
											color: Colors.transparent,
										),
										BootstrapRow(
											height: 60,
											children: <BootstrapCol>[
												BootstrapCol(
													sizes: 'col-12 col-md-3',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: TextFormField(
															autofocus: true,
															controller: mdfeCabecalhoController.quantidadeTotalCteController,
															decoration: inputDecoration(
																hintText: 'Informe os dados para o campo Quantidade Total Cte',
																labelText: 'Quantidade Total Cte',
																usePadding: true,
															),
															onSaved: (String? value) {},
															onChanged: (text) {
																mdfeCabecalhoController.currentModel.quantidadeTotalCte = int.tryParse(text);
																mdfeCabecalhoController.formWasChanged = true;
															},
														),
													),
												),
												BootstrapCol(
													sizes: 'col-12 col-md-3',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: TextFormField(
															autofocus: true,
															controller: mdfeCabecalhoController.quantidadeTotalNfeController,
															decoration: inputDecoration(
																hintText: 'Informe os dados para o campo Quantidade Total Nfe',
																labelText: 'Quantidade Total Nfe',
																usePadding: true,
															),
															onSaved: (String? value) {},
															onChanged: (text) {
																mdfeCabecalhoController.currentModel.quantidadeTotalNfe = int.tryParse(text);
																mdfeCabecalhoController.formWasChanged = true;
															},
														),
													),
												),
												BootstrapCol(
													sizes: 'col-12 col-md-3',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: TextFormField(
															autofocus: true,
															controller: mdfeCabecalhoController.quantidadeTotalMdfeController,
															decoration: inputDecoration(
																hintText: 'Informe os dados para o campo Quantidade Total Mdfe',
																labelText: 'Quantidade Total Mdfe',
																usePadding: true,
															),
															onSaved: (String? value) {},
															onChanged: (text) {
																mdfeCabecalhoController.currentModel.quantidadeTotalMdfe = int.tryParse(text);
																mdfeCabecalhoController.formWasChanged = true;
															},
														),
													),
												),
												BootstrapCol(
													sizes: 'col-12 col-md-3',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: CustomDropdownButton(
															controller: mdfeCabecalhoController.codigoUnidadeMedidaController,
															labelText: 'Codigo Unidade Medida',
															hintText: 'Informe os dados para o campo Codigo Unidade Medida',
															items: MdfeCabecalhoDomain.codigoUnidadeMedidaListDropdown,
															onChanged: (dynamic newValue) {
																mdfeCabecalhoController.currentModel.codigoUnidadeMedida = newValue;
																mdfeCabecalhoController.formWasChanged = true;
															},
														),
													),
												),
											],
										),
										const Divider(
											color: Colors.transparent,
										),
										BootstrapRow(
											height: 60,
											children: <BootstrapCol>[
												BootstrapCol(
													sizes: 'col-12 col-md-4',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: TextFormField(
															autofocus: true,
															controller: mdfeCabecalhoController.pesoBrutoCargaController,
															decoration: inputDecoration(
																hintText: 'Informe os dados para o campo Peso Bruto Carga',
																labelText: 'Peso Bruto Carga',
																usePadding: true,
															),
															onSaved: (String? value) {},
															onChanged: (text) {
																mdfeCabecalhoController.currentModel.pesoBrutoCarga = mdfeCabecalhoController.pesoBrutoCargaController.numberValue;
																mdfeCabecalhoController.formWasChanged = true;
															},
														),
													),
												),
												BootstrapCol(
													sizes: 'col-12 col-md-4',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: TextFormField(
															autofocus: true,
															controller: mdfeCabecalhoController.valorCargaController,
															decoration: inputDecoration(
																hintText: 'Informe os dados para o campo Valor Carga',
																labelText: 'Valor Carga',
																usePadding: true,
															),
															onSaved: (String? value) {},
															onChanged: (text) {
																mdfeCabecalhoController.currentModel.valorCarga = mdfeCabecalhoController.valorCargaController.numberValue;
																mdfeCabecalhoController.formWasChanged = true;
															},
														),
													),
												),
												BootstrapCol(
													sizes: 'col-12 col-md-4',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: TextFormField(
															autofocus: true,
															maxLength: 15,
															controller: mdfeCabecalhoController.numeroProtocoloController,
															decoration: inputDecoration(
																hintText: 'Informe os dados para o campo Numero Protocolo',
																labelText: 'Numero Protocolo',
																usePadding: true,
															),
															onSaved: (String? value) {},
															onChanged: (text) {
																mdfeCabecalhoController.currentModel.numeroProtocolo = text;
																mdfeCabecalhoController.formWasChanged = true;
															},
														),
													),
												),
											],
										),
										const Divider(
											indent: 10,
											endIndent: 10,
											thickness: 2,
										),
										BootstrapRow(
											height: 60,
											children: <BootstrapCol>[
												BootstrapCol(
													sizes: 'col-12',
													child: Text(
														'field_is_mandatory'.tr,
														style: Theme.of(context).textTheme.bodySmall,
													),
												),
											],
										),
										const SizedBox(height: 10.0),
									],
								),
							),
						),
					),
				),
			);
	}
}
