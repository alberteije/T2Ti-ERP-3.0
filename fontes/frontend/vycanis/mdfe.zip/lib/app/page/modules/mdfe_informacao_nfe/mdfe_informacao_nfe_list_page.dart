import 'package:flutter/material.dart';
import 'package:mdfe/app/controller/mdfe_informacao_nfe_controller.dart';
import 'package:mdfe/app/page/shared_page/list_page_base.dart';

class MdfeInformacaoNfeListPage extends ListPageBase<MdfeInformacaoNfeController> {
  const MdfeInformacaoNfeListPage({Key? key}) : super(key: key);

  @override
  List<Map<String, dynamic>> get mobileItems => controller.mobileItems;

  @override
  Map<String, dynamic> get mobileConfig => controller.mobileConfig;

  @override
  String get standardFieldForFilter => controller.standardFieldForFilter;
}