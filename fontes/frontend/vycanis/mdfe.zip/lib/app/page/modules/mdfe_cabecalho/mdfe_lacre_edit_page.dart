import 'package:flutter/material.dart';
import 'package:flutter_bootstrap/flutter_bootstrap.dart';
import 'package:get/get.dart';
import 'package:mdfe/app/page/shared_widget/shared_widget_imports.dart';
import 'package:mdfe/app/controller/mdfe_lacre_controller.dart';
import 'package:mdfe/app/infra/infra_imports.dart';
import 'package:mdfe/app/page/shared_widget/input/input_imports.dart';

class MdfeLacreEditPage extends StatelessWidget {
	MdfeLacreEditPage({Key? key}) : super(key: key);
	final mdfeLacreController = Get.find<MdfeLacreController>();

	@override
	Widget build(BuildContext context) {
			return Scaffold(
				key: mdfeLacreController.mdfeLacreScaffoldKey,	
				appBar: AppBar(
					automaticallyImplyLeading: false,
					title: Text('${ mdfeLacreController.screenTitle } - ${ mdfeLacreController.isNewRecord ? 'inserting'.tr : 'editing'.tr }',),
					actions: [
						saveButton(onPressed: mdfeLacreController.save),
						cancelAndExitButton(onPressed: mdfeLacreController.preventDataLoss),
					]
				),
				body: SafeArea(
					top: false,
					bottom: false,
					child: Form(
						key: mdfeLacreController.mdfeLacreFormKey,
						autovalidateMode: AutovalidateMode.always,
						child: Scrollbar(
							controller: mdfeLacreController.scrollController,
							child: SingleChildScrollView(
								controller: mdfeLacreController.scrollController,
								child: BootstrapContainer(
									fluid: true,
									padding: const EdgeInsets.all(10.0),
									children: <Widget>[
										const Divider(
											color: Colors.transparent,
										),
										BootstrapRow(
											height: 60,
											children: <BootstrapCol>[
												BootstrapCol(
													sizes: 'col-12',
													child: Padding(
														padding: Util.distanceBetweenColumnsLineBreak(context)!,
														child: TextFormField(
															autofocus: true,
															maxLength: 20,
															controller: mdfeLacreController.numeroLacreController,
															decoration: inputDecoration(
																hintText: 'Informe os dados para o campo Numero Lacre',
																labelText: 'Numero Lacre',
																usePadding: true,
															),
															onSaved: (String? value) {},
															onChanged: (text) {
																mdfeLacreController.mdfeLacreModel.numeroLacre = text;
																mdfeLacreController.formWasChangedDetail = true;
															},
														),
													),
												),
											],
										),
										const Divider(
											indent: 10,
											endIndent: 10,
											thickness: 2,
										),
										BootstrapRow(
											height: 60,
											children: <BootstrapCol>[
												BootstrapCol(
													sizes: 'col-12',
													child: Text(
														'field_is_mandatory'.tr,
														style: Theme.of(context).textTheme.bodySmall,
													),
												),
											],
										),
										const SizedBox(height: 10.0),
									],
								),
							),
						),
					),
				),
			);
	}
}
