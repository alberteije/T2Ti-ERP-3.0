abstract class Routes{
	
	static const splashPage = '/splashPage';
	static const loginPage = '/loginPage';
	static const homePage = '/homePage';
	static const filterPage = '/filterPage';
	static const lookupPage = '/lookupPage';
  static const menuModulesPage = '/menuModulesPage';
		
	static const mdfeCabecalhoListPage = '/mdfeCabecalhoListPage'; 
	static const mdfeCabecalhoTabPage = '/mdfeCabecalhoTabPage';
	static const mdfeInformacaoCteListPage = '/mdfeInformacaoCteListPage'; 
	static const mdfeInformacaoCteEditPage = '/mdfeInformacaoCteEditPage';
	static const mdfeInformacaoNfeListPage = '/mdfeInformacaoNfeListPage'; 
	static const mdfeInformacaoNfeEditPage = '/mdfeInformacaoNfeEditPage';
	static const mdfeRodoviarioMotoristaListPage = '/mdfeRodoviarioMotoristaListPage'; 
	static const mdfeRodoviarioMotoristaEditPage = '/mdfeRodoviarioMotoristaEditPage';
	static const mdfeRodoviarioVeiculoListPage = '/mdfeRodoviarioVeiculoListPage'; 
	static const mdfeRodoviarioVeiculoEditPage = '/mdfeRodoviarioVeiculoEditPage';
	static const mdfeRodoviarioPedagioListPage = '/mdfeRodoviarioPedagioListPage'; 
	static const mdfeRodoviarioPedagioEditPage = '/mdfeRodoviarioPedagioEditPage';
	static const mdfeRodoviarioCiotListPage = '/mdfeRodoviarioCiotListPage'; 
	static const mdfeRodoviarioCiotEditPage = '/mdfeRodoviarioCiotEditPage';
}