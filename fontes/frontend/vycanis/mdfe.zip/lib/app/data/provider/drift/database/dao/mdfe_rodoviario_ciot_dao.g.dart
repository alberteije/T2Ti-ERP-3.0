// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'mdfe_rodoviario_ciot_dao.dart';

// ignore_for_file: type=lint
mixin _$MdfeRodoviarioCiotDaoMixin on DatabaseAccessor<AppDatabase> {
  $MdfeRodoviarioCiotsTable get mdfeRodoviarioCiots =>
      attachedDatabase.mdfeRodoviarioCiots;
  $MdfeRodoviariosTable get mdfeRodoviarios => attachedDatabase.mdfeRodoviarios;
}
