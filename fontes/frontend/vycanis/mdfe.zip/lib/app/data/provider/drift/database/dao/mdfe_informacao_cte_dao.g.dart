// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'mdfe_informacao_cte_dao.dart';

// ignore_for_file: type=lint
mixin _$MdfeInformacaoCteDaoMixin on DatabaseAccessor<AppDatabase> {
  $MdfeInformacaoCtesTable get mdfeInformacaoCtes =>
      attachedDatabase.mdfeInformacaoCtes;
  $MdfeMunicipioDescarregasTable get mdfeMunicipioDescarregas =>
      attachedDatabase.mdfeMunicipioDescarregas;
}
