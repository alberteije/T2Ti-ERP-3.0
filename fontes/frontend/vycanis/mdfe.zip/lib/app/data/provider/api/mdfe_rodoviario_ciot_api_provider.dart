import 'package:mdfe/app/data/provider/api/api_provider_base.dart';
import 'package:mdfe/app/data/model/model_imports.dart';

class MdfeRodoviarioCiotApiProvider extends ApiProviderBase {
  static const _path = '/mdfe-rodoviario-ciot';

  Future<List<MdfeRodoviarioCiotModel>?> getList({Filter? filter}) {
    return super.getListBase(
      '$_path/',
      (json) => MdfeRodoviarioCiotModel.fromJson(json),
      filter: filter,
    );
  }

  Future<MdfeRodoviarioCiotModel?> getObject(dynamic pk) {
    return super.getObjectBase(
      _path,
      pk,
      (json) => MdfeRodoviarioCiotModel.fromJson(json),
    );
  }

  Future<MdfeRodoviarioCiotModel?>? insert(MdfeRodoviarioCiotModel model) {
    return super.insertBase(
      _path,
      model,
      (json) => MdfeRodoviarioCiotModel.fromJson(json),
    );
  }

  Future<MdfeRodoviarioCiotModel?>? update(MdfeRodoviarioCiotModel model) {
    return super.updateBase(
      _path,
      model,
      (json) => MdfeRodoviarioCiotModel.fromJson(json),
    );
  }

  Future<bool?> delete(dynamic pk) {
    return super.deleteBase(_path, pk);
  }
}
