import 'package:mdfe/app/data/provider/api/api_provider_base.dart';
import 'package:mdfe/app/data/model/model_imports.dart';

class MdfeInformacaoCteApiProvider extends ApiProviderBase {
  static const _path = '/mdfe-informacao-cte';

  Future<List<MdfeInformacaoCteModel>?> getList({Filter? filter}) {
    return super.getListBase(
      '$_path/',
      (json) => MdfeInformacaoCteModel.fromJson(json),
      filter: filter,
    );
  }

  Future<MdfeInformacaoCteModel?> getObject(dynamic pk) {
    return super.getObjectBase(
      _path,
      pk,
      (json) => MdfeInformacaoCteModel.fromJson(json),
    );
  }

  Future<MdfeInformacaoCteModel?>? insert(MdfeInformacaoCteModel model) {
    return super.insertBase(
      _path,
      model,
      (json) => MdfeInformacaoCteModel.fromJson(json),
    );
  }

  Future<MdfeInformacaoCteModel?>? update(MdfeInformacaoCteModel model) {
    return super.updateBase(
      _path,
      model,
      (json) => MdfeInformacaoCteModel.fromJson(json),
    );
  }

  Future<bool?> delete(dynamic pk) {
    return super.deleteBase(_path, pk);
  }
}
