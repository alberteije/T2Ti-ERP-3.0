import 'package:mdfe/app/data/provider/api/api_provider_base.dart';
import 'package:mdfe/app/data/model/model_imports.dart';

class MdfeRodoviarioMotoristaApiProvider extends ApiProviderBase {
  static const _path = '/mdfe-rodoviario-motorista';

  Future<List<MdfeRodoviarioMotoristaModel>?> getList({Filter? filter}) {
    return super.getListBase(
      '$_path/',
      (json) => MdfeRodoviarioMotoristaModel.fromJson(json),
      filter: filter,
    );
  }

  Future<MdfeRodoviarioMotoristaModel?> getObject(dynamic pk) {
    return super.getObjectBase(
      _path,
      pk,
      (json) => MdfeRodoviarioMotoristaModel.fromJson(json),
    );
  }

  Future<MdfeRodoviarioMotoristaModel?>? insert(MdfeRodoviarioMotoristaModel model) {
    return super.insertBase(
      _path,
      model,
      (json) => MdfeRodoviarioMotoristaModel.fromJson(json),
    );
  }

  Future<MdfeRodoviarioMotoristaModel?>? update(MdfeRodoviarioMotoristaModel model) {
    return super.updateBase(
      _path,
      model,
      (json) => MdfeRodoviarioMotoristaModel.fromJson(json),
    );
  }

  Future<bool?> delete(dynamic pk) {
    return super.deleteBase(_path, pk);
  }
}
