// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'mdfe_rodoviario_veiculo_dao.dart';

// ignore_for_file: type=lint
mixin _$MdfeRodoviarioVeiculoDaoMixin on DatabaseAccessor<AppDatabase> {
  $MdfeRodoviarioVeiculosTable get mdfeRodoviarioVeiculos =>
      attachedDatabase.mdfeRodoviarioVeiculos;
  $MdfeRodoviariosTable get mdfeRodoviarios => attachedDatabase.mdfeRodoviarios;
}
