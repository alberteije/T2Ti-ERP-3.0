// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'mdfe_rodoviario_pedagio_dao.dart';

// ignore_for_file: type=lint
mixin _$MdfeRodoviarioPedagioDaoMixin on DatabaseAccessor<AppDatabase> {
  $MdfeRodoviarioPedagiosTable get mdfeRodoviarioPedagios =>
      attachedDatabase.mdfeRodoviarioPedagios;
  $MdfeRodoviariosTable get mdfeRodoviarios => attachedDatabase.mdfeRodoviarios;
}
