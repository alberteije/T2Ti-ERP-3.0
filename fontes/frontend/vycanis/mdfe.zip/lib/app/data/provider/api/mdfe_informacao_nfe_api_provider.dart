import 'package:mdfe/app/data/provider/api/api_provider_base.dart';
import 'package:mdfe/app/data/model/model_imports.dart';

class MdfeInformacaoNfeApiProvider extends ApiProviderBase {
  static const _path = '/mdfe-informacao-nfe';

  Future<List<MdfeInformacaoNfeModel>?> getList({Filter? filter}) {
    return super.getListBase(
      '$_path/',
      (json) => MdfeInformacaoNfeModel.fromJson(json),
      filter: filter,
    );
  }

  Future<MdfeInformacaoNfeModel?> getObject(dynamic pk) {
    return super.getObjectBase(
      _path,
      pk,
      (json) => MdfeInformacaoNfeModel.fromJson(json),
    );
  }

  Future<MdfeInformacaoNfeModel?>? insert(MdfeInformacaoNfeModel model) {
    return super.insertBase(
      _path,
      model,
      (json) => MdfeInformacaoNfeModel.fromJson(json),
    );
  }

  Future<MdfeInformacaoNfeModel?>? update(MdfeInformacaoNfeModel model) {
    return super.updateBase(
      _path,
      model,
      (json) => MdfeInformacaoNfeModel.fromJson(json),
    );
  }

  Future<bool?> delete(dynamic pk) {
    return super.deleteBase(_path, pk);
  }
}
