import 'package:mdfe/app/data/provider/api/api_provider_base.dart';
import 'package:mdfe/app/data/model/model_imports.dart';

class MdfeRodoviarioVeiculoApiProvider extends ApiProviderBase {
  static const _path = '/mdfe-rodoviario-veiculo';

  Future<List<MdfeRodoviarioVeiculoModel>?> getList({Filter? filter}) {
    return super.getListBase(
      '$_path/',
      (json) => MdfeRodoviarioVeiculoModel.fromJson(json),
      filter: filter,
    );
  }

  Future<MdfeRodoviarioVeiculoModel?> getObject(dynamic pk) {
    return super.getObjectBase(
      _path,
      pk,
      (json) => MdfeRodoviarioVeiculoModel.fromJson(json),
    );
  }

  Future<MdfeRodoviarioVeiculoModel?>? insert(MdfeRodoviarioVeiculoModel model) {
    return super.insertBase(
      _path,
      model,
      (json) => MdfeRodoviarioVeiculoModel.fromJson(json),
    );
  }

  Future<MdfeRodoviarioVeiculoModel?>? update(MdfeRodoviarioVeiculoModel model) {
    return super.updateBase(
      _path,
      model,
      (json) => MdfeRodoviarioVeiculoModel.fromJson(json),
    );
  }

  Future<bool?> delete(dynamic pk) {
    return super.deleteBase(_path, pk);
  }
}
