import 'package:mdfe/app/data/provider/api/api_provider_base.dart';
import 'package:mdfe/app/data/model/model_imports.dart';

class MdfeRodoviarioPedagioApiProvider extends ApiProviderBase {
  static const _path = '/mdfe-rodoviario-pedagio';

  Future<List<MdfeRodoviarioPedagioModel>?> getList({Filter? filter}) {
    return super.getListBase(
      '$_path/',
      (json) => MdfeRodoviarioPedagioModel.fromJson(json),
      filter: filter,
    );
  }

  Future<MdfeRodoviarioPedagioModel?> getObject(dynamic pk) {
    return super.getObjectBase(
      _path,
      pk,
      (json) => MdfeRodoviarioPedagioModel.fromJson(json),
    );
  }

  Future<MdfeRodoviarioPedagioModel?>? insert(MdfeRodoviarioPedagioModel model) {
    return super.insertBase(
      _path,
      model,
      (json) => MdfeRodoviarioPedagioModel.fromJson(json),
    );
  }

  Future<MdfeRodoviarioPedagioModel?>? update(MdfeRodoviarioPedagioModel model) {
    return super.updateBase(
      _path,
      model,
      (json) => MdfeRodoviarioPedagioModel.fromJson(json),
    );
  }

  Future<bool?> delete(dynamic pk) {
    return super.deleteBase(_path, pk);
  }
}
