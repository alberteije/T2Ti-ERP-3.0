import 'dart:convert';

import 'package:mdfe/app/data/provider/api/api_provider_base.dart';
import 'package:mdfe/app/data/model/model_imports.dart';

class MdfeCabecalhoApiProvider extends ApiProviderBase {
  static const _path = '/mdfe-cabecalho';

  Future<List<MdfeCabecalhoModel>?> getList({Filter? filter}) {
    return super.getListBase(
      '$_path/',
      (json) => MdfeCabecalhoModel.fromJson(json),
      filter: filter,
    );
  }

  Future<MdfeCabecalhoModel?> getObject(dynamic pk) {
    return super.getObjectBase(
      _path,
      pk,
      (json) => MdfeCabecalhoModel.fromJson(json),
    );
  }

  Future<MdfeCabecalhoModel?>? insert(MdfeCabecalhoModel model) {
    return super.insertBase(
      _path,
      model,
      (json) => MdfeCabecalhoModel.fromJson(json),
    );
  }

  Future<MdfeCabecalhoModel?>? update(MdfeCabecalhoModel model) {
    return super.updateBase(
      _path,
      model,
      (json) => MdfeCabecalhoModel.fromJson(json),
    );
  }

  Future<bool?> delete(dynamic pk) {
    return super.deleteBase(_path, pk);
  }

  Future<dynamic> transmitirDocumento(MdfeCabecalhoModel mdfeCabecalhoModel) async {
    try {
      final response = await ApiProviderBase.httpClient.post(
        Uri.tryParse('$endpoint/mdfe-cabecalho/transmite-documento/')!,
				headers: ApiProviderBase.headerRequisition(),
				body: mdfeCabecalhoModel.objectEncodeJson(),
      );

      if (response.statusCode == 200 || response.statusCode == 201) {
        if (response.headers["content-type"]!.contains("html")) {
          handleResultError(response.body, response.headers);
          return null;
        } else {
          final pdf = response.bodyBytes;
          return pdf;
        }
      } else if (response.statusCode == 418) {
        return json.decode(response.body)["message"];
      } else {
        handleResultError(response.body, response.headers);
        return null;
      }
    } on Exception catch (e) {
      handleResultError(null, null, exception: e);
    }
    return null;
  }
}
