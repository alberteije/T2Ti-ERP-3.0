import 'dart:convert';
import 'package:pluto_grid/pluto_grid.dart';
import 'package:mdfe/app/data/model/model_imports.dart';

import 'package:mdfe/app/infra/infra_imports.dart';
import 'package:intl/intl.dart';
import 'package:mdfe/app/data/domain/domain_imports.dart';

class MdfeCabecalhoModel extends ModelBase {
  int? id;
  String? uf;
  String? tipoAmbiente;
  String? tipoEmitente;
  String? tipoTransportadora;
  String? modelo;
  String? serie;
  String? numeroMdfe;
  String? codigoNumerico;
  String? chaveAcesso;
  int? digitoVerificador;
  String? modal;
  DateTime? dataHoraEmissao;
  String? tipoEmissao;
  String? processoEmissao;
  String? versaoProcessoEmissao;
  String? ufInicio;
  String? ufFim;
  DateTime? dataHoraPrevisaoViagem;
  int? quantidadeTotalCte;
  int? quantidadeTotalNfe;
  int? quantidadeTotalMdfe;
  String? codigoUnidadeMedida;
  double? pesoBrutoCarga;
  double? valorCarga;
  String? numeroProtocolo;
  List<MdfeLacreModel>? mdfeLacreModelList;
  List<MdfeMunicipioDescarregaModel>? mdfeMunicipioDescarregaModelList;
  List<MdfeEmitenteModel>? mdfeEmitenteModelList;
  List<MdfePercursoModel>? mdfePercursoModelList;
  List<MdfeMunicipioCarregamentoModel>? mdfeMunicipioCarregamentoModelList;
  List<MdfeRodoviarioModel>? mdfeRodoviarioModelList;
  List<MdfeInformacaoSeguroModel>? mdfeInformacaoSeguroModelList;

  MdfeCabecalhoModel({
    this.id,
    this.uf = 'AC',
    this.tipoAmbiente = '1-Produção',
    this.tipoEmitente = '1-Prestador de serviço de transporte',
    this.tipoTransportadora = 'ETC',
    this.modelo = '58',
    this.serie,
    this.numeroMdfe,
    this.codigoNumerico,
    this.chaveAcesso,
    this.digitoVerificador,
    this.modal = '1-Rodoviário',
    this.dataHoraEmissao,
    this.tipoEmissao = '1-Normal',
    this.processoEmissao = '0-Emissão de MDF-e com aplicativo do  contribuinte',
    this.versaoProcessoEmissao,
    this.ufInicio = 'AC',
    this.ufFim = 'AC',
    this.dataHoraPrevisaoViagem,
    this.quantidadeTotalCte,
    this.quantidadeTotalNfe,
    this.quantidadeTotalMdfe,
    this.codigoUnidadeMedida = '01-KG',
    this.pesoBrutoCarga,
    this.valorCarga,
    this.numeroProtocolo,
    List<MdfeLacreModel>? mdfeLacreModelList,
    List<MdfeMunicipioDescarregaModel>? mdfeMunicipioDescarregaModelList,
    List<MdfeEmitenteModel>? mdfeEmitenteModelList,
    List<MdfePercursoModel>? mdfePercursoModelList,
    List<MdfeMunicipioCarregamentoModel>? mdfeMunicipioCarregamentoModelList,
    List<MdfeRodoviarioModel>? mdfeRodoviarioModelList,
    List<MdfeInformacaoSeguroModel>? mdfeInformacaoSeguroModelList,
  }) {
    this.mdfeLacreModelList = mdfeLacreModelList?.toList(growable: true) ?? [];
    this.mdfeMunicipioDescarregaModelList = mdfeMunicipioDescarregaModelList?.toList(growable: true) ?? [];
    this.mdfeEmitenteModelList = mdfeEmitenteModelList?.toList(growable: true) ?? [];
    this.mdfePercursoModelList = mdfePercursoModelList?.toList(growable: true) ?? [];
    this.mdfeMunicipioCarregamentoModelList = mdfeMunicipioCarregamentoModelList?.toList(growable: true) ?? [];
    this.mdfeRodoviarioModelList = mdfeRodoviarioModelList?.toList(growable: true) ?? [];
    this.mdfeInformacaoSeguroModelList = mdfeInformacaoSeguroModelList?.toList(growable: true) ?? [];
  }

  static List<String> dbColumns = <String>[
    'id',
    'uf',
    'tipo_ambiente',
    'tipo_emitente',
    'tipo_transportadora',
    'modelo',
    'serie',
    'numero_mdfe',
    'codigo_numerico',
    'chave_acesso',
    'digito_verificador',
    'modal',
    'data_hora_emissao',
    'tipo_emissao',
    'processo_emissao',
    'versao_processo_emissao',
    'uf_inicio',
    'uf_fim',
    'data_hora_previsao_viagem',
    'quantidade_total_cte',
    'quantidade_total_nfe',
    'quantidade_total_mdfe',
    'codigo_unidade_medida',
    'peso_bruto_carga',
    'valor_carga',
    'numero_protocolo',
  ];

  static List<String> aliasColumns = <String>[
    'Id',
    'Uf',
    'Tipo Ambiente',
    'Tipo Emitente',
    'Tipo Transportadora',
    'Modelo',
    'Serie',
    'Numero Mdfe',
    'Codigo Numerico',
    'Chave Acesso',
    'Digito Verificador',
    'Modal',
    'Data Hora Emissao',
    'Tipo Emissao',
    'Processo Emissao',
    'Versao Processo Emissao',
    'Uf Inicio',
    'Uf Fim',
    'Data Hora Previsao Viagem',
    'Quantidade Total Cte',
    'Quantidade Total Nfe',
    'Quantidade Total Mdfe',
    'Codigo Unidade Medida',
    'Peso Bruto Carga',
    'Valor Carga',
    'Numero Protocolo',
  ];

  MdfeCabecalhoModel.fromJson(Map<String, dynamic> jsonData) {
    id = jsonData['id'];
    uf = MdfeCabecalhoDomain.getUf(jsonData['uf'].toString());
    tipoAmbiente = MdfeCabecalhoDomain.getTipoAmbiente(jsonData['tipoAmbiente']);
    tipoEmitente = MdfeCabecalhoDomain.getTipoEmitente(jsonData['tipoEmitente']);
    tipoTransportadora = MdfeCabecalhoDomain.getTipoTransportadora(jsonData['tipoTransportadora']);
    modelo = MdfeCabecalhoDomain.getModelo(jsonData['modelo']);
    serie = jsonData['serie'];
    numeroMdfe = jsonData['numeroMdfe'];
    codigoNumerico = jsonData['codigoNumerico'];
    chaveAcesso = jsonData['chaveAcesso'];
    digitoVerificador = jsonData['digitoVerificador'];
    modal = MdfeCabecalhoDomain.getModal(jsonData['modal']);
    dataHoraEmissao = jsonData['dataHoraEmissao'] != null ? DateTime.tryParse(jsonData['dataHoraEmissao']) : null;
    tipoEmissao = MdfeCabecalhoDomain.getTipoEmissao(jsonData['tipoEmissao']);
    processoEmissao = MdfeCabecalhoDomain.getProcessoEmissao(jsonData['processoEmissao']);
    versaoProcessoEmissao = jsonData['versaoProcessoEmissao'];
    ufInicio = MdfeCabecalhoDomain.getUfInicio(jsonData['ufInicio']);
    ufFim = MdfeCabecalhoDomain.getUfFim(jsonData['ufFim']);
    dataHoraPrevisaoViagem = jsonData['dataHoraPrevisaoViagem'] != null ? DateTime.tryParse(jsonData['dataHoraPrevisaoViagem']) : null;
    quantidadeTotalCte = jsonData['quantidadeTotalCte'];
    quantidadeTotalNfe = jsonData['quantidadeTotalNfe'];
    quantidadeTotalMdfe = jsonData['quantidadeTotalMdfe'];
    codigoUnidadeMedida = MdfeCabecalhoDomain.getCodigoUnidadeMedida(jsonData['codigoUnidadeMedida']);
    pesoBrutoCarga = jsonData['pesoBrutoCarga']?.toDouble();
    valorCarga = jsonData['valorCarga']?.toDouble();
    numeroProtocolo = jsonData['numeroProtocolo'];
    mdfeLacreModelList = (jsonData['mdfeLacreModelList'] as Iterable?)?.map((m) => MdfeLacreModel.fromJson(m)).toList() ?? [];
    mdfeMunicipioDescarregaModelList = (jsonData['mdfeMunicipioDescarregaModelList'] as Iterable?)?.map((m) => MdfeMunicipioDescarregaModel.fromJson(m)).toList() ?? [];
    mdfeEmitenteModelList = (jsonData['mdfeEmitenteModelList'] as Iterable?)?.map((m) => MdfeEmitenteModel.fromJson(m)).toList() ?? [];
    mdfePercursoModelList = (jsonData['mdfePercursoModelList'] as Iterable?)?.map((m) => MdfePercursoModel.fromJson(m)).toList() ?? [];
    mdfeMunicipioCarregamentoModelList = (jsonData['mdfeMunicipioCarregamentoModelList'] as Iterable?)?.map((m) => MdfeMunicipioCarregamentoModel.fromJson(m)).toList() ?? [];
    mdfeRodoviarioModelList = (jsonData['mdfeRodoviarioModelList'] as Iterable?)?.map((m) => MdfeRodoviarioModel.fromJson(m)).toList() ?? [];
    mdfeInformacaoSeguroModelList = (jsonData['mdfeInformacaoSeguroModelList'] as Iterable?)?.map((m) => MdfeInformacaoSeguroModel.fromJson(m)).toList() ?? [];
  }

  Map<String, dynamic> get toJson {
    Map<String, dynamic> jsonData = <String, dynamic>{};

    jsonData['id'] = id != 0 ? id : null;
    jsonData['uf'] = MdfeCabecalhoDomain.setUf(uf);
    jsonData['tipoAmbiente'] = MdfeCabecalhoDomain.setTipoAmbiente(tipoAmbiente);
    jsonData['tipoEmitente'] = MdfeCabecalhoDomain.setTipoEmitente(tipoEmitente);
    jsonData['tipoTransportadora'] = MdfeCabecalhoDomain.setTipoTransportadora(tipoTransportadora);
    jsonData['modelo'] = MdfeCabecalhoDomain.setModelo(modelo);
    jsonData['serie'] = serie;
    jsonData['numeroMdfe'] = numeroMdfe;
    jsonData['codigoNumerico'] = codigoNumerico;
    jsonData['chaveAcesso'] = chaveAcesso;
    jsonData['digitoVerificador'] = digitoVerificador;
    jsonData['modal'] = MdfeCabecalhoDomain.setModal(modal);
    jsonData['dataHoraEmissao'] = dataHoraEmissao != null ? DateFormat('yyyy-MM-ddT00:00:00').format(dataHoraEmissao!) : null;
    jsonData['tipoEmissao'] = MdfeCabecalhoDomain.setTipoEmissao(tipoEmissao);
    jsonData['processoEmissao'] = MdfeCabecalhoDomain.setProcessoEmissao(processoEmissao);
    jsonData['versaoProcessoEmissao'] = versaoProcessoEmissao;
    jsonData['ufInicio'] = MdfeCabecalhoDomain.setUfInicio(ufInicio);
    jsonData['ufFim'] = MdfeCabecalhoDomain.setUfFim(ufFim);
    jsonData['dataHoraPrevisaoViagem'] = dataHoraPrevisaoViagem != null ? DateFormat('yyyy-MM-ddT00:00:00').format(dataHoraPrevisaoViagem!) : null;
    jsonData['quantidadeTotalCte'] = quantidadeTotalCte;
    jsonData['quantidadeTotalNfe'] = quantidadeTotalNfe;
    jsonData['quantidadeTotalMdfe'] = quantidadeTotalMdfe;
    jsonData['codigoUnidadeMedida'] = MdfeCabecalhoDomain.setCodigoUnidadeMedida(codigoUnidadeMedida);
    jsonData['pesoBrutoCarga'] = pesoBrutoCarga;
    jsonData['valorCarga'] = valorCarga;
    jsonData['numeroProtocolo'] = numeroProtocolo;
    
		var mdfeLacreModelLocalList = []; 
		for (MdfeLacreModel object in mdfeLacreModelList ?? []) { 
			mdfeLacreModelLocalList.add(object.toJson); 
		}
		jsonData['mdfeLacreModelList'] = mdfeLacreModelLocalList;
    
		var mdfeMunicipioDescarregaModelLocalList = []; 
		for (MdfeMunicipioDescarregaModel object in mdfeMunicipioDescarregaModelList ?? []) { 
			mdfeMunicipioDescarregaModelLocalList.add(object.toJson); 
		}
		jsonData['mdfeMunicipioDescarregaModelList'] = mdfeMunicipioDescarregaModelLocalList;
    
		var mdfeEmitenteModelLocalList = []; 
		for (MdfeEmitenteModel object in mdfeEmitenteModelList ?? []) { 
			mdfeEmitenteModelLocalList.add(object.toJson); 
		}
		jsonData['mdfeEmitenteModelList'] = mdfeEmitenteModelLocalList;
    
		var mdfePercursoModelLocalList = []; 
		for (MdfePercursoModel object in mdfePercursoModelList ?? []) { 
			mdfePercursoModelLocalList.add(object.toJson); 
		}
		jsonData['mdfePercursoModelList'] = mdfePercursoModelLocalList;
    
		var mdfeMunicipioCarregamentoModelLocalList = []; 
		for (MdfeMunicipioCarregamentoModel object in mdfeMunicipioCarregamentoModelList ?? []) { 
			mdfeMunicipioCarregamentoModelLocalList.add(object.toJson); 
		}
		jsonData['mdfeMunicipioCarregamentoModelList'] = mdfeMunicipioCarregamentoModelLocalList;
    
		var mdfeRodoviarioModelLocalList = []; 
		for (MdfeRodoviarioModel object in mdfeRodoviarioModelList ?? []) { 
			mdfeRodoviarioModelLocalList.add(object.toJson); 
		}
		jsonData['mdfeRodoviarioModelList'] = mdfeRodoviarioModelLocalList;
    
		var mdfeInformacaoSeguroModelLocalList = []; 
		for (MdfeInformacaoSeguroModel object in mdfeInformacaoSeguroModelList ?? []) { 
			mdfeInformacaoSeguroModelLocalList.add(object.toJson); 
		}
		jsonData['mdfeInformacaoSeguroModelList'] = mdfeInformacaoSeguroModelLocalList;

    return jsonData;
  }

  String objectEncodeJson() {
    final jsonData = toJson;
    return json.encode(jsonData);
  }

  static MdfeCabecalhoModel fromPlutoRow(PlutoRow row) {
    return MdfeCabecalhoModel(
      id: row.cells['id']?.value,
      uf: row.cells['uf']?.value,
      tipoAmbiente: row.cells['tipoAmbiente']?.value,
      tipoEmitente: row.cells['tipoEmitente']?.value,
      tipoTransportadora: row.cells['tipoTransportadora']?.value,
      modelo: row.cells['modelo']?.value,
      serie: row.cells['serie']?.value,
      numeroMdfe: row.cells['numeroMdfe']?.value,
      codigoNumerico: row.cells['codigoNumerico']?.value,
      chaveAcesso: row.cells['chaveAcesso']?.value,
      digitoVerificador: row.cells['digitoVerificador']?.value,
      modal: row.cells['modal']?.value,
      dataHoraEmissao: Util.stringToDate(row.cells['dataHoraEmissao']?.value),
      tipoEmissao: row.cells['tipoEmissao']?.value,
      processoEmissao: row.cells['processoEmissao']?.value,
      versaoProcessoEmissao: row.cells['versaoProcessoEmissao']?.value,
      ufInicio: row.cells['ufInicio']?.value,
      ufFim: row.cells['ufFim']?.value,
      dataHoraPrevisaoViagem: Util.stringToDate(row.cells['dataHoraPrevisaoViagem']?.value),
      quantidadeTotalCte: row.cells['quantidadeTotalCte']?.value,
      quantidadeTotalNfe: row.cells['quantidadeTotalNfe']?.value,
      quantidadeTotalMdfe: row.cells['quantidadeTotalMdfe']?.value,
      codigoUnidadeMedida: row.cells['codigoUnidadeMedida']?.value,
      pesoBrutoCarga: row.cells['pesoBrutoCarga']?.value,
      valorCarga: row.cells['valorCarga']?.value,
      numeroProtocolo: row.cells['numeroProtocolo']?.value,
    );
  }

  PlutoRow toPlutoRow() {
    return PlutoRow(
      cells: {
        'tempId': PlutoCell(value: tempId),
        'id': PlutoCell(value: id ?? 0),
        'uf': PlutoCell(value: uf ?? ''),
        'tipoAmbiente': PlutoCell(value: tipoAmbiente ?? ''),
        'tipoEmitente': PlutoCell(value: tipoEmitente ?? ''),
        'tipoTransportadora': PlutoCell(value: tipoTransportadora ?? ''),
        'modelo': PlutoCell(value: modelo ?? ''),
        'serie': PlutoCell(value: serie ?? ''),
        'numeroMdfe': PlutoCell(value: numeroMdfe ?? ''),
        'codigoNumerico': PlutoCell(value: codigoNumerico ?? ''),
        'chaveAcesso': PlutoCell(value: chaveAcesso ?? ''),
        'digitoVerificador': PlutoCell(value: digitoVerificador ?? 0),
        'modal': PlutoCell(value: modal ?? ''),
        'dataHoraEmissao': PlutoCell(value: dataHoraEmissao),
        'tipoEmissao': PlutoCell(value: tipoEmissao ?? ''),
        'processoEmissao': PlutoCell(value: processoEmissao ?? ''),
        'versaoProcessoEmissao': PlutoCell(value: versaoProcessoEmissao ?? ''),
        'ufInicio': PlutoCell(value: ufInicio ?? ''),
        'ufFim': PlutoCell(value: ufFim ?? ''),
        'dataHoraPrevisaoViagem': PlutoCell(value: dataHoraPrevisaoViagem),
        'quantidadeTotalCte': PlutoCell(value: quantidadeTotalCte ?? 0),
        'quantidadeTotalNfe': PlutoCell(value: quantidadeTotalNfe ?? 0),
        'quantidadeTotalMdfe': PlutoCell(value: quantidadeTotalMdfe ?? 0),
        'codigoUnidadeMedida': PlutoCell(value: codigoUnidadeMedida ?? ''),
        'pesoBrutoCarga': PlutoCell(value: pesoBrutoCarga ?? 0.0),
        'valorCarga': PlutoCell(value: valorCarga ?? 0.0),
        'numeroProtocolo': PlutoCell(value: numeroProtocolo ?? ''),
      },
    );
  }

  MdfeCabecalhoModel clone() {
    return MdfeCabecalhoModel(
      id: id,
      uf: uf,
      tipoAmbiente: tipoAmbiente,
      tipoEmitente: tipoEmitente,
      tipoTransportadora: tipoTransportadora,
      modelo: modelo,
      serie: serie,
      numeroMdfe: numeroMdfe,
      codigoNumerico: codigoNumerico,
      chaveAcesso: chaveAcesso,
      digitoVerificador: digitoVerificador,
      modal: modal,
      dataHoraEmissao: dataHoraEmissao,
      tipoEmissao: tipoEmissao,
      processoEmissao: processoEmissao,
      versaoProcessoEmissao: versaoProcessoEmissao,
      ufInicio: ufInicio,
      ufFim: ufFim,
      dataHoraPrevisaoViagem: dataHoraPrevisaoViagem,
      quantidadeTotalCte: quantidadeTotalCte,
      quantidadeTotalNfe: quantidadeTotalNfe,
      quantidadeTotalMdfe: quantidadeTotalMdfe,
      codigoUnidadeMedida: codigoUnidadeMedida,
      pesoBrutoCarga: pesoBrutoCarga,
      valorCarga: valorCarga,
      numeroProtocolo: numeroProtocolo,
      mdfeLacreModelList: mdfeLacreModelListClone(mdfeLacreModelList!),
      mdfeMunicipioDescarregaModelList: mdfeMunicipioDescarregaModelListClone(mdfeMunicipioDescarregaModelList!),
      mdfeEmitenteModelList: mdfeEmitenteModelListClone(mdfeEmitenteModelList!),
      mdfePercursoModelList: mdfePercursoModelListClone(mdfePercursoModelList!),
      mdfeMunicipioCarregamentoModelList: mdfeMunicipioCarregamentoModelListClone(mdfeMunicipioCarregamentoModelList!),
      mdfeRodoviarioModelList: mdfeRodoviarioModelListClone(mdfeRodoviarioModelList!),
      mdfeInformacaoSeguroModelList: mdfeInformacaoSeguroModelListClone(mdfeInformacaoSeguroModelList!),
    );
  }

  mdfeLacreModelListClone(List<MdfeLacreModel> mdfeLacreModelList) { 
		List<MdfeLacreModel> resultList = [];
		for (var mdfeLacreModel in mdfeLacreModelList) {
			resultList.add(mdfeLacreModel.clone());
		}
		return resultList;
	}

  mdfeMunicipioDescarregaModelListClone(List<MdfeMunicipioDescarregaModel> mdfeMunicipioDescarregaModelList) { 
		List<MdfeMunicipioDescarregaModel> resultList = [];
		for (var mdfeMunicipioDescarregaModel in mdfeMunicipioDescarregaModelList) {
			resultList.add(mdfeMunicipioDescarregaModel.clone());
		}
		return resultList;
	}

  mdfeEmitenteModelListClone(List<MdfeEmitenteModel> mdfeEmitenteModelList) { 
		List<MdfeEmitenteModel> resultList = [];
		for (var mdfeEmitenteModel in mdfeEmitenteModelList) {
			resultList.add(mdfeEmitenteModel.clone());
		}
		return resultList;
	}

  mdfePercursoModelListClone(List<MdfePercursoModel> mdfePercursoModelList) { 
		List<MdfePercursoModel> resultList = [];
		for (var mdfePercursoModel in mdfePercursoModelList) {
			resultList.add(mdfePercursoModel.clone());
		}
		return resultList;
	}

  mdfeMunicipioCarregamentoModelListClone(List<MdfeMunicipioCarregamentoModel> mdfeMunicipioCarregamentoModelList) { 
		List<MdfeMunicipioCarregamentoModel> resultList = [];
		for (var mdfeMunicipioCarregamentoModel in mdfeMunicipioCarregamentoModelList) {
			resultList.add(mdfeMunicipioCarregamentoModel.clone());
		}
		return resultList;
	}

  mdfeRodoviarioModelListClone(List<MdfeRodoviarioModel> mdfeRodoviarioModelList) { 
		List<MdfeRodoviarioModel> resultList = [];
		for (var mdfeRodoviarioModel in mdfeRodoviarioModelList) {
			resultList.add(mdfeRodoviarioModel.clone());
		}
		return resultList;
	}

  mdfeInformacaoSeguroModelListClone(List<MdfeInformacaoSeguroModel> mdfeInformacaoSeguroModelList) { 
		List<MdfeInformacaoSeguroModel> resultList = [];
		for (var mdfeInformacaoSeguroModel in mdfeInformacaoSeguroModelList) {
			resultList.add(mdfeInformacaoSeguroModel.clone());
		}
		return resultList;
	}


}