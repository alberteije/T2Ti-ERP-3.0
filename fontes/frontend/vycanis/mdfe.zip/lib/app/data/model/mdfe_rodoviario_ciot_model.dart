import 'dart:convert';
import 'package:pluto_grid/pluto_grid.dart';
import 'package:mdfe/app/data/model/model_imports.dart';

import 'package:mdfe/app/infra/infra_imports.dart';

class MdfeRodoviarioCiotModel extends ModelBase {
  int? id;
  int? idMdfeRodoviario;
  String? ciot;
  String? cpf;
  String? cnpj;
  MdfeRodoviarioModel? mdfeRodoviarioModel;

  MdfeRodoviarioCiotModel({
    this.id,
    this.idMdfeRodoviario,
    this.ciot,
    this.cpf,
    this.cnpj,
    MdfeRodoviarioModel? mdfeRodoviarioModel,
  }) {
    this.mdfeRodoviarioModel = mdfeRodoviarioModel ?? MdfeRodoviarioModel();
  }

  static List<String> dbColumns = <String>[
    'id',
    'ciot',
    'cpf',
    'cnpj',
  ];

  static List<String> aliasColumns = <String>[
    'Id',
    'Ciot',
    'Cpf',
    'Cnpj',
  ];

  MdfeRodoviarioCiotModel.fromJson(Map<String, dynamic> jsonData) {
    id = jsonData['id'];
    idMdfeRodoviario = jsonData['idMdfeRodoviario'];
    ciot = jsonData['ciot'];
    cpf = jsonData['cpf'];
    cnpj = jsonData['cnpj'];
    mdfeRodoviarioModel = jsonData['mdfeRodoviarioModel'] == null ? MdfeRodoviarioModel() : MdfeRodoviarioModel.fromJson(jsonData['mdfeRodoviarioModel']);
  }

  Map<String, dynamic> get toJson {
    Map<String, dynamic> jsonData = <String, dynamic>{};

    jsonData['id'] = id != 0 ? id : null;
    jsonData['idMdfeRodoviario'] = idMdfeRodoviario != 0 ? idMdfeRodoviario : null;
    jsonData['ciot'] = ciot;
    jsonData['cpf'] = Util.removeMask(cpf);
    jsonData['cnpj'] = Util.removeMask(cnpj);
    jsonData['mdfeRodoviarioModel'] = mdfeRodoviarioModel?.toJson;
    jsonData['mdfeRodoviario'] = mdfeRodoviarioModel?.codigoAgendamento ?? '';

    return jsonData;
  }

  String objectEncodeJson() {
    final jsonData = toJson;
    return json.encode(jsonData);
  }

  static MdfeRodoviarioCiotModel fromPlutoRow(PlutoRow row) {
    return MdfeRodoviarioCiotModel(
      id: row.cells['id']?.value,
      idMdfeRodoviario: row.cells['idMdfeRodoviario']?.value,
      ciot: row.cells['ciot']?.value,
      cpf: row.cells['cpf']?.value,
      cnpj: row.cells['cnpj']?.value,
    );
  }

  PlutoRow toPlutoRow() {
    return PlutoRow(
      cells: {
        'tempId': PlutoCell(value: tempId),
        'id': PlutoCell(value: id ?? 0),
        'idMdfeRodoviario': PlutoCell(value: idMdfeRodoviario ?? 0),
        'ciot': PlutoCell(value: ciot ?? ''),
        'cpf': PlutoCell(value: cpf ?? ''),
        'cnpj': PlutoCell(value: cnpj ?? ''),
        'mdfeRodoviario': PlutoCell(value: mdfeRodoviarioModel?.codigoAgendamento ?? ''),
      },
    );
  }

  MdfeRodoviarioCiotModel clone() {
    return MdfeRodoviarioCiotModel(
      id: id,
      idMdfeRodoviario: idMdfeRodoviario,
      ciot: ciot,
      cpf: cpf,
      cnpj: cnpj,
      mdfeRodoviarioModel: mdfeRodoviarioModel?.clone(),
    );
  }


}