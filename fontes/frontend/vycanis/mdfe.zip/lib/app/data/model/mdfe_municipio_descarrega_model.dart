import 'dart:convert';
import 'package:pluto_grid/pluto_grid.dart';
import 'package:mdfe/app/data/model/model_imports.dart';


class MdfeMunicipioDescarregaModel extends ModelBase {
  int? id;
  int? idMdfeCabecalho;
  String? codigoMunicipio;
  String? nomeMunicipio;

  MdfeMunicipioDescarregaModel({
    this.id,
    this.idMdfeCabecalho,
    this.codigoMunicipio,
    this.nomeMunicipio,
  });

  static List<String> dbColumns = <String>[
    'id',
    'codigo_municipio',
    'nome_municipio',
  ];

  static List<String> aliasColumns = <String>[
    'Id',
    'Codigo Municipio',
    'Nome Municipio',
  ];

  MdfeMunicipioDescarregaModel.fromJson(Map<String, dynamic> jsonData) {
    id = jsonData['id'];
    idMdfeCabecalho = jsonData['idMdfeCabecalho'];
    codigoMunicipio = jsonData['codigoMunicipio'];
    nomeMunicipio = jsonData['nomeMunicipio'];
  }

  Map<String, dynamic> get toJson {
    Map<String, dynamic> jsonData = <String, dynamic>{};

    jsonData['id'] = id != 0 ? id : null;
    jsonData['idMdfeCabecalho'] = idMdfeCabecalho != 0 ? idMdfeCabecalho : null;
    jsonData['codigoMunicipio'] = codigoMunicipio;
    jsonData['nomeMunicipio'] = nomeMunicipio;

    return jsonData;
  }

  String objectEncodeJson() {
    final jsonData = toJson;
    return json.encode(jsonData);
  }

  static MdfeMunicipioDescarregaModel fromPlutoRow(PlutoRow row) {
    return MdfeMunicipioDescarregaModel(
      id: row.cells['id']?.value,
      idMdfeCabecalho: row.cells['idMdfeCabecalho']?.value,
      codigoMunicipio: row.cells['codigoMunicipio']?.value,
      nomeMunicipio: row.cells['nomeMunicipio']?.value,
    );
  }

  PlutoRow toPlutoRow() {
    return PlutoRow(
      cells: {
        'tempId': PlutoCell(value: tempId),
        'id': PlutoCell(value: id ?? 0),
        'idMdfeCabecalho': PlutoCell(value: idMdfeCabecalho ?? 0),
        'codigoMunicipio': PlutoCell(value: codigoMunicipio ?? ''),
        'nomeMunicipio': PlutoCell(value: nomeMunicipio ?? ''),
      },
    );
  }

  MdfeMunicipioDescarregaModel clone() {
    return MdfeMunicipioDescarregaModel(
      id: id,
      idMdfeCabecalho: idMdfeCabecalho,
      codigoMunicipio: codigoMunicipio,
      nomeMunicipio: nomeMunicipio,
    );
  }


}