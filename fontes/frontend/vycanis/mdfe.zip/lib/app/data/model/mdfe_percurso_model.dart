import 'dart:convert';
import 'package:pluto_grid/pluto_grid.dart';
import 'package:mdfe/app/data/model/model_imports.dart';

import 'package:mdfe/app/infra/infra_imports.dart';
import 'package:intl/intl.dart';
import 'package:mdfe/app/data/domain/domain_imports.dart';

class MdfePercursoModel extends ModelBase {
  int? id;
  int? idMdfeCabecalho;
  String? ufPercurso;
  DateTime? dataInicioViagem;

  MdfePercursoModel({
    this.id,
    this.idMdfeCabecalho,
    this.ufPercurso = 'AC',
    this.dataInicioViagem,
  });

  static List<String> dbColumns = <String>[
    'id',
    'uf_percurso',
    'data_inicio_viagem',
  ];

  static List<String> aliasColumns = <String>[
    'Id',
    'Uf Percurso',
    'Data Inicio Viagem',
  ];

  MdfePercursoModel.fromJson(Map<String, dynamic> jsonData) {
    id = jsonData['id'];
    idMdfeCabecalho = jsonData['idMdfeCabecalho'];
    ufPercurso = MdfePercursoDomain.getUfPercurso(jsonData['ufPercurso']);
    dataInicioViagem = jsonData['dataInicioViagem'] != null ? DateTime.tryParse(jsonData['dataInicioViagem']) : null;
  }

  Map<String, dynamic> get toJson {
    Map<String, dynamic> jsonData = <String, dynamic>{};

    jsonData['id'] = id != 0 ? id : null;
    jsonData['idMdfeCabecalho'] = idMdfeCabecalho != 0 ? idMdfeCabecalho : null;
    jsonData['ufPercurso'] = MdfePercursoDomain.setUfPercurso(ufPercurso);
    jsonData['dataInicioViagem'] = dataInicioViagem != null ? DateFormat('yyyy-MM-ddT00:00:00').format(dataInicioViagem!) : null;

    return jsonData;
  }

  String objectEncodeJson() {
    final jsonData = toJson;
    return json.encode(jsonData);
  }

  static MdfePercursoModel fromPlutoRow(PlutoRow row) {
    return MdfePercursoModel(
      id: row.cells['id']?.value,
      idMdfeCabecalho: row.cells['idMdfeCabecalho']?.value,
      ufPercurso: row.cells['ufPercurso']?.value,
      dataInicioViagem: Util.stringToDate(row.cells['dataInicioViagem']?.value),
    );
  }

  PlutoRow toPlutoRow() {
    return PlutoRow(
      cells: {
        'tempId': PlutoCell(value: tempId),
        'id': PlutoCell(value: id ?? 0),
        'idMdfeCabecalho': PlutoCell(value: idMdfeCabecalho ?? 0),
        'ufPercurso': PlutoCell(value: ufPercurso ?? ''),
        'dataInicioViagem': PlutoCell(value: dataInicioViagem),
      },
    );
  }

  MdfePercursoModel clone() {
    return MdfePercursoModel(
      id: id,
      idMdfeCabecalho: idMdfeCabecalho,
      ufPercurso: ufPercurso,
      dataInicioViagem: dataInicioViagem,
    );
  }


}