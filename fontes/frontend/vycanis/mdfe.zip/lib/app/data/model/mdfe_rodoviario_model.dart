import 'dart:convert';
import 'package:pluto_grid/pluto_grid.dart';
import 'package:mdfe/app/data/model/model_imports.dart';


class MdfeRodoviarioModel extends ModelBase {
  int? id;
  int? idMdfeCabecalho;
  String? rntrc;
  String? codigoAgendamento;

  MdfeRodoviarioModel({
    this.id,
    this.idMdfeCabecalho,
    this.rntrc,
    this.codigoAgendamento,
  });

  static List<String> dbColumns = <String>[
    'id',
    'rntrc',
    'codigo_agendamento',
  ];

  static List<String> aliasColumns = <String>[
    'Id',
    'Rntrc',
    'Codigo Agendamento',
  ];

  MdfeRodoviarioModel.fromJson(Map<String, dynamic> jsonData) {
    id = jsonData['id'];
    idMdfeCabecalho = jsonData['idMdfeCabecalho'];
    rntrc = jsonData['rntrc'];
    codigoAgendamento = jsonData['codigoAgendamento'];
  }

  Map<String, dynamic> get toJson {
    Map<String, dynamic> jsonData = <String, dynamic>{};

    jsonData['id'] = id != 0 ? id : null;
    jsonData['idMdfeCabecalho'] = idMdfeCabecalho != 0 ? idMdfeCabecalho : null;
    jsonData['rntrc'] = rntrc;
    jsonData['codigoAgendamento'] = codigoAgendamento;

    return jsonData;
  }

  String objectEncodeJson() {
    final jsonData = toJson;
    return json.encode(jsonData);
  }

  static MdfeRodoviarioModel fromPlutoRow(PlutoRow row) {
    return MdfeRodoviarioModel(
      id: row.cells['id']?.value,
      idMdfeCabecalho: row.cells['idMdfeCabecalho']?.value,
      rntrc: row.cells['rntrc']?.value,
      codigoAgendamento: row.cells['codigoAgendamento']?.value,
    );
  }

  PlutoRow toPlutoRow() {
    return PlutoRow(
      cells: {
        'tempId': PlutoCell(value: tempId),
        'id': PlutoCell(value: id ?? 0),
        'idMdfeCabecalho': PlutoCell(value: idMdfeCabecalho ?? 0),
        'rntrc': PlutoCell(value: rntrc ?? ''),
        'codigoAgendamento': PlutoCell(value: codigoAgendamento ?? ''),
      },
    );
  }

  MdfeRodoviarioModel clone() {
    return MdfeRodoviarioModel(
      id: id,
      idMdfeCabecalho: idMdfeCabecalho,
      rntrc: rntrc,
      codigoAgendamento: codigoAgendamento,
    );
  }


}