import 'dart:convert';
import 'package:pluto_grid/pluto_grid.dart';
import 'package:mdfe/app/data/model/model_imports.dart';

import 'package:mdfe/app/infra/infra_imports.dart';

class MdfeRodoviarioPedagioModel extends ModelBase {
  int? id;
  int? idMdfeRodoviario;
  String? cnpjFornecedor;
  String? cnpjResponsavel;
  String? cpfResponsavel;
  String? numeroComprovante;
  double? valor;
  MdfeRodoviarioModel? mdfeRodoviarioModel;

  MdfeRodoviarioPedagioModel({
    this.id,
    this.idMdfeRodoviario,
    this.cnpjFornecedor,
    this.cnpjResponsavel,
    this.cpfResponsavel,
    this.numeroComprovante,
    this.valor,
    MdfeRodoviarioModel? mdfeRodoviarioModel,
  }) {
    this.mdfeRodoviarioModel = mdfeRodoviarioModel ?? MdfeRodoviarioModel();
  }

  static List<String> dbColumns = <String>[
    'id',
    'cnpj_fornecedor',
    'cnpj_responsavel',
    'cpf_responsavel',
    'numero_comprovante',
    'valor',
  ];

  static List<String> aliasColumns = <String>[
    'Id',
    'Cnpj Fornecedor',
    'Cnpj Responsavel',
    'Cpf Responsavel',
    'Numero Comprovante',
    'Valor',
  ];

  MdfeRodoviarioPedagioModel.fromJson(Map<String, dynamic> jsonData) {
    id = jsonData['id'];
    idMdfeRodoviario = jsonData['idMdfeRodoviario'];
    cnpjFornecedor = jsonData['cnpjFornecedor'];
    cnpjResponsavel = jsonData['cnpjResponsavel'];
    cpfResponsavel = jsonData['cpfResponsavel'];
    numeroComprovante = jsonData['numeroComprovante'];
    valor = jsonData['valor']?.toDouble();
    mdfeRodoviarioModel = jsonData['mdfeRodoviarioModel'] == null ? MdfeRodoviarioModel() : MdfeRodoviarioModel.fromJson(jsonData['mdfeRodoviarioModel']);
  }

  Map<String, dynamic> get toJson {
    Map<String, dynamic> jsonData = <String, dynamic>{};

    jsonData['id'] = id != 0 ? id : null;
    jsonData['idMdfeRodoviario'] = idMdfeRodoviario != 0 ? idMdfeRodoviario : null;
    jsonData['cnpjFornecedor'] = Util.removeMask(cnpjFornecedor);
    jsonData['cnpjResponsavel'] = Util.removeMask(cnpjResponsavel);
    jsonData['cpfResponsavel'] = Util.removeMask(cpfResponsavel);
    jsonData['numeroComprovante'] = numeroComprovante;
    jsonData['valor'] = valor;
    jsonData['mdfeRodoviarioModel'] = mdfeRodoviarioModel?.toJson;
    jsonData['mdfeRodoviario'] = mdfeRodoviarioModel?.codigoAgendamento ?? '';

    return jsonData;
  }

  String objectEncodeJson() {
    final jsonData = toJson;
    return json.encode(jsonData);
  }

  static MdfeRodoviarioPedagioModel fromPlutoRow(PlutoRow row) {
    return MdfeRodoviarioPedagioModel(
      id: row.cells['id']?.value,
      idMdfeRodoviario: row.cells['idMdfeRodoviario']?.value,
      cnpjFornecedor: row.cells['cnpjFornecedor']?.value,
      cnpjResponsavel: row.cells['cnpjResponsavel']?.value,
      cpfResponsavel: row.cells['cpfResponsavel']?.value,
      numeroComprovante: row.cells['numeroComprovante']?.value,
      valor: row.cells['valor']?.value,
    );
  }

  PlutoRow toPlutoRow() {
    return PlutoRow(
      cells: {
        'tempId': PlutoCell(value: tempId),
        'id': PlutoCell(value: id ?? 0),
        'idMdfeRodoviario': PlutoCell(value: idMdfeRodoviario ?? 0),
        'cnpjFornecedor': PlutoCell(value: cnpjFornecedor ?? ''),
        'cnpjResponsavel': PlutoCell(value: cnpjResponsavel ?? ''),
        'cpfResponsavel': PlutoCell(value: cpfResponsavel ?? ''),
        'numeroComprovante': PlutoCell(value: numeroComprovante ?? ''),
        'valor': PlutoCell(value: valor ?? 0.0),
        'mdfeRodoviario': PlutoCell(value: mdfeRodoviarioModel?.codigoAgendamento ?? ''),
      },
    );
  }

  MdfeRodoviarioPedagioModel clone() {
    return MdfeRodoviarioPedagioModel(
      id: id,
      idMdfeRodoviario: idMdfeRodoviario,
      cnpjFornecedor: cnpjFornecedor,
      cnpjResponsavel: cnpjResponsavel,
      cpfResponsavel: cpfResponsavel,
      numeroComprovante: numeroComprovante,
      valor: valor,
      mdfeRodoviarioModel: mdfeRodoviarioModel?.clone(),
    );
  }


}