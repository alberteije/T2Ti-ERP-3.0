import 'dart:convert';
import 'package:pluto_grid/pluto_grid.dart';
import 'package:mdfe/app/data/model/model_imports.dart';

import 'package:mdfe/app/infra/infra_imports.dart';
import 'package:mdfe/app/data/domain/domain_imports.dart';

class MdfeEmitenteModel extends ModelBase {
  int? id;
  int? idMdfeCabecalho;
  String? nome;
  String? fantasia;
  String? cnpj;
  int? ie;
  String? logradouro;
  String? numero;
  String? complemento;
  String? bairro;
  String? codigoMunicipio;
  String? nomeMunicipio;
  String? cep;
  String? uf;
  String? telefone;
  String? email;

  MdfeEmitenteModel({
    this.id,
    this.idMdfeCabecalho,
    this.nome,
    this.fantasia,
    this.cnpj,
    this.ie,
    this.logradouro,
    this.numero,
    this.complemento,
    this.bairro,
    this.codigoMunicipio,
    this.nomeMunicipio,
    this.cep,
    this.uf = 'AC',
    this.telefone,
    this.email,
  });

  static List<String> dbColumns = <String>[
    'id',
    'nome',
    'fantasia',
    'cnpj',
    'ie',
    'logradouro',
    'numero',
    'complemento',
    'bairro',
    'codigo_municipio',
    'nome_municipio',
    'cep',
    'uf',
    'telefone',
    'email',
  ];

  static List<String> aliasColumns = <String>[
    'Id',
    'Nome',
    'Fantasia',
    'Cnpj',
    'Ie',
    'Logradouro',
    'Numero',
    'Complemento',
    'Bairro',
    'Codigo Municipio',
    'Nome Municipio',
    'Cep',
    'Uf',
    'Telefone',
    'Email',
  ];

  MdfeEmitenteModel.fromJson(Map<String, dynamic> jsonData) {
    id = jsonData['id'];
    idMdfeCabecalho = jsonData['idMdfeCabecalho'];
    nome = jsonData['nome'];
    fantasia = jsonData['fantasia'];
    cnpj = jsonData['cnpj'];
    ie = jsonData['ie'];
    logradouro = jsonData['logradouro'];
    numero = jsonData['numero'];
    complemento = jsonData['complemento'];
    bairro = jsonData['bairro'];
    codigoMunicipio = jsonData['codigoMunicipio'];
    nomeMunicipio = jsonData['nomeMunicipio'];
    cep = jsonData['cep'];
    uf = MdfeEmitenteDomain.getUf(jsonData['uf']);
    telefone = jsonData['telefone'];
    email = jsonData['email'];
  }

  Map<String, dynamic> get toJson {
    Map<String, dynamic> jsonData = <String, dynamic>{};

    jsonData['id'] = id != 0 ? id : null;
    jsonData['idMdfeCabecalho'] = idMdfeCabecalho != 0 ? idMdfeCabecalho : null;
    jsonData['nome'] = nome;
    jsonData['fantasia'] = fantasia;
    jsonData['cnpj'] = Util.removeMask(cnpj);
    jsonData['ie'] = ie;
    jsonData['logradouro'] = logradouro;
    jsonData['numero'] = numero;
    jsonData['complemento'] = complemento;
    jsonData['bairro'] = bairro;
    jsonData['codigoMunicipio'] = codigoMunicipio;
    jsonData['nomeMunicipio'] = nomeMunicipio;
    jsonData['cep'] = Util.removeMask(cep);
    jsonData['uf'] = MdfeEmitenteDomain.setUf(uf);
    jsonData['telefone'] = Util.removeMask(telefone);
    jsonData['email'] = email;

    return jsonData;
  }

  String objectEncodeJson() {
    final jsonData = toJson;
    return json.encode(jsonData);
  }

  static MdfeEmitenteModel fromPlutoRow(PlutoRow row) {
    return MdfeEmitenteModel(
      id: row.cells['id']?.value,
      idMdfeCabecalho: row.cells['idMdfeCabecalho']?.value,
      nome: row.cells['nome']?.value,
      fantasia: row.cells['fantasia']?.value,
      cnpj: row.cells['cnpj']?.value,
      ie: row.cells['ie']?.value,
      logradouro: row.cells['logradouro']?.value,
      numero: row.cells['numero']?.value,
      complemento: row.cells['complemento']?.value,
      bairro: row.cells['bairro']?.value,
      codigoMunicipio: row.cells['codigoMunicipio']?.value,
      nomeMunicipio: row.cells['nomeMunicipio']?.value,
      cep: row.cells['cep']?.value,
      uf: row.cells['uf']?.value,
      telefone: row.cells['telefone']?.value,
      email: row.cells['email']?.value,
    );
  }

  PlutoRow toPlutoRow() {
    return PlutoRow(
      cells: {
        'tempId': PlutoCell(value: tempId),
        'id': PlutoCell(value: id ?? 0),
        'idMdfeCabecalho': PlutoCell(value: idMdfeCabecalho ?? 0),
        'nome': PlutoCell(value: nome ?? ''),
        'fantasia': PlutoCell(value: fantasia ?? ''),
        'cnpj': PlutoCell(value: cnpj ?? ''),
        'ie': PlutoCell(value: ie ?? 0),
        'logradouro': PlutoCell(value: logradouro ?? ''),
        'numero': PlutoCell(value: numero ?? ''),
        'complemento': PlutoCell(value: complemento ?? ''),
        'bairro': PlutoCell(value: bairro ?? ''),
        'codigoMunicipio': PlutoCell(value: codigoMunicipio ?? ''),
        'nomeMunicipio': PlutoCell(value: nomeMunicipio ?? ''),
        'cep': PlutoCell(value: cep ?? ''),
        'uf': PlutoCell(value: uf ?? ''),
        'telefone': PlutoCell(value: telefone ?? ''),
        'email': PlutoCell(value: email ?? ''),
      },
    );
  }

  MdfeEmitenteModel clone() {
    return MdfeEmitenteModel(
      id: id,
      idMdfeCabecalho: idMdfeCabecalho,
      nome: nome,
      fantasia: fantasia,
      cnpj: cnpj,
      ie: ie,
      logradouro: logradouro,
      numero: numero,
      complemento: complemento,
      bairro: bairro,
      codigoMunicipio: codigoMunicipio,
      nomeMunicipio: nomeMunicipio,
      cep: cep,
      uf: uf,
      telefone: telefone,
      email: email,
    );
  }


}