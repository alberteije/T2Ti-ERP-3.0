import 'dart:convert';
import 'package:pluto_grid/pluto_grid.dart';
import 'package:mdfe/app/data/model/model_imports.dart';

import 'package:mdfe/app/infra/infra_imports.dart';
import 'package:mdfe/app/data/domain/domain_imports.dart';

class MdfeRodoviarioVeiculoModel extends ModelBase {
  int? id;
  int? idMdfeRodoviario;
  String? codigoInterno;
  String? placa;
  String? renavam;
  int? tara;
  int? capacidadeKg;
  int? capacidadeM3;
  String? tipoRodado;
  String? tipoCarroceria;
  String? ufLicenciamento;
  String? proprietarioCpf;
  String? proprietarioCnpj;
  String? proprietarioRntrc;
  String? proprietarioNome;
  String? proprietarioIe;
  int? proprietarioTipo;
  MdfeRodoviarioModel? mdfeRodoviarioModel;

  MdfeRodoviarioVeiculoModel({
    this.id,
    this.idMdfeRodoviario,
    this.codigoInterno,
    this.placa,
    this.renavam,
    this.tara,
    this.capacidadeKg,
    this.capacidadeM3,
    this.tipoRodado = 'AAA',
    this.tipoCarroceria = 'AAA',
    this.ufLicenciamento = 'AC',
    this.proprietarioCpf,
    this.proprietarioCnpj,
    this.proprietarioRntrc,
    this.proprietarioNome,
    this.proprietarioIe,
    this.proprietarioTipo,
    MdfeRodoviarioModel? mdfeRodoviarioModel,
  }) {
    this.mdfeRodoviarioModel = mdfeRodoviarioModel ?? MdfeRodoviarioModel();
  }

  static List<String> dbColumns = <String>[
    'id',
    'codigo_interno',
    'placa',
    'renavam',
    'tara',
    'capacidade_kg',
    'capacidade_m3',
    'tipo_rodado',
    'tipo_carroceria',
    'uf_licenciamento',
    'proprietario_cpf',
    'proprietario_cnpj',
    'proprietario_rntrc',
    'proprietario_nome',
    'proprietario_ie',
    'proprietario_tipo',
  ];

  static List<String> aliasColumns = <String>[
    'Id',
    'Codigo Interno',
    'Placa',
    'Renavam',
    'Tara',
    'Capacidade Kg',
    'Capacidade M3',
    'Tipo Rodado',
    'Tipo Carroceria',
    'Uf Licenciamento',
    'Proprietario Cpf',
    'Proprietario Cnpj',
    'Proprietario Rntrc',
    'Proprietario Nome',
    'Proprietario Ie',
    'Proprietario Tipo',
  ];

  MdfeRodoviarioVeiculoModel.fromJson(Map<String, dynamic> jsonData) {
    id = jsonData['id'];
    idMdfeRodoviario = jsonData['idMdfeRodoviario'];
    codigoInterno = jsonData['codigoInterno'];
    placa = jsonData['placa'];
    renavam = jsonData['renavam'];
    tara = jsonData['tara'];
    capacidadeKg = jsonData['capacidadeKg'];
    capacidadeM3 = jsonData['capacidadeM3'];
    tipoRodado = MdfeRodoviarioVeiculoDomain.getTipoRodado(jsonData['tipoRodado']);
    tipoCarroceria = MdfeRodoviarioVeiculoDomain.getTipoCarroceria(jsonData['tipoCarroceria']);
    ufLicenciamento = MdfeRodoviarioVeiculoDomain.getUfLicenciamento(jsonData['ufLicenciamento']);
    proprietarioCpf = jsonData['proprietarioCpf'];
    proprietarioCnpj = jsonData['proprietarioCnpj'];
    proprietarioRntrc = jsonData['proprietarioRntrc'];
    proprietarioNome = jsonData['proprietarioNome'];
    proprietarioIe = jsonData['proprietarioIe'];
    proprietarioTipo = jsonData['proprietarioTipo'];
    mdfeRodoviarioModel = jsonData['mdfeRodoviarioModel'] == null ? MdfeRodoviarioModel() : MdfeRodoviarioModel.fromJson(jsonData['mdfeRodoviarioModel']);
  }

  Map<String, dynamic> get toJson {
    Map<String, dynamic> jsonData = <String, dynamic>{};

    jsonData['id'] = id != 0 ? id : null;
    jsonData['idMdfeRodoviario'] = idMdfeRodoviario != 0 ? idMdfeRodoviario : null;
    jsonData['codigoInterno'] = codigoInterno;
    jsonData['placa'] = placa;
    jsonData['renavam'] = renavam;
    jsonData['tara'] = tara;
    jsonData['capacidadeKg'] = capacidadeKg;
    jsonData['capacidadeM3'] = capacidadeM3;
    jsonData['tipoRodado'] = MdfeRodoviarioVeiculoDomain.setTipoRodado(tipoRodado);
    jsonData['tipoCarroceria'] = MdfeRodoviarioVeiculoDomain.setTipoCarroceria(tipoCarroceria);
    jsonData['ufLicenciamento'] = MdfeRodoviarioVeiculoDomain.setUfLicenciamento(ufLicenciamento);
    jsonData['proprietarioCpf'] = Util.removeMask(proprietarioCpf);
    jsonData['proprietarioCnpj'] = Util.removeMask(proprietarioCnpj);
    jsonData['proprietarioRntrc'] = proprietarioRntrc;
    jsonData['proprietarioNome'] = proprietarioNome;
    jsonData['proprietarioIe'] = proprietarioIe;
    jsonData['proprietarioTipo'] = proprietarioTipo;
    jsonData['mdfeRodoviarioModel'] = mdfeRodoviarioModel?.toJson;
    jsonData['mdfeRodoviario'] = mdfeRodoviarioModel?.codigoAgendamento ?? '';

    return jsonData;
  }

  String objectEncodeJson() {
    final jsonData = toJson;
    return json.encode(jsonData);
  }

  static MdfeRodoviarioVeiculoModel fromPlutoRow(PlutoRow row) {
    return MdfeRodoviarioVeiculoModel(
      id: row.cells['id']?.value,
      idMdfeRodoviario: row.cells['idMdfeRodoviario']?.value,
      codigoInterno: row.cells['codigoInterno']?.value,
      placa: row.cells['placa']?.value,
      renavam: row.cells['renavam']?.value,
      tara: row.cells['tara']?.value,
      capacidadeKg: row.cells['capacidadeKg']?.value,
      capacidadeM3: row.cells['capacidadeM3']?.value,
      tipoRodado: row.cells['tipoRodado']?.value,
      tipoCarroceria: row.cells['tipoCarroceria']?.value,
      ufLicenciamento: row.cells['ufLicenciamento']?.value,
      proprietarioCpf: row.cells['proprietarioCpf']?.value,
      proprietarioCnpj: row.cells['proprietarioCnpj']?.value,
      proprietarioRntrc: row.cells['proprietarioRntrc']?.value,
      proprietarioNome: row.cells['proprietarioNome']?.value,
      proprietarioIe: row.cells['proprietarioIe']?.value,
      proprietarioTipo: row.cells['proprietarioTipo']?.value,
    );
  }

  PlutoRow toPlutoRow() {
    return PlutoRow(
      cells: {
        'tempId': PlutoCell(value: tempId),
        'id': PlutoCell(value: id ?? 0),
        'idMdfeRodoviario': PlutoCell(value: idMdfeRodoviario ?? 0),
        'codigoInterno': PlutoCell(value: codigoInterno ?? ''),
        'placa': PlutoCell(value: placa ?? ''),
        'renavam': PlutoCell(value: renavam ?? ''),
        'tara': PlutoCell(value: tara ?? 0),
        'capacidadeKg': PlutoCell(value: capacidadeKg ?? 0),
        'capacidadeM3': PlutoCell(value: capacidadeM3 ?? 0),
        'tipoRodado': PlutoCell(value: tipoRodado ?? ''),
        'tipoCarroceria': PlutoCell(value: tipoCarroceria ?? ''),
        'ufLicenciamento': PlutoCell(value: ufLicenciamento ?? ''),
        'proprietarioCpf': PlutoCell(value: proprietarioCpf ?? ''),
        'proprietarioCnpj': PlutoCell(value: proprietarioCnpj ?? ''),
        'proprietarioRntrc': PlutoCell(value: proprietarioRntrc ?? ''),
        'proprietarioNome': PlutoCell(value: proprietarioNome ?? ''),
        'proprietarioIe': PlutoCell(value: proprietarioIe ?? ''),
        'proprietarioTipo': PlutoCell(value: proprietarioTipo ?? 0),
        'mdfeRodoviario': PlutoCell(value: mdfeRodoviarioModel?.codigoAgendamento ?? ''),
      },
    );
  }

  MdfeRodoviarioVeiculoModel clone() {
    return MdfeRodoviarioVeiculoModel(
      id: id,
      idMdfeRodoviario: idMdfeRodoviario,
      codigoInterno: codigoInterno,
      placa: placa,
      renavam: renavam,
      tara: tara,
      capacidadeKg: capacidadeKg,
      capacidadeM3: capacidadeM3,
      tipoRodado: tipoRodado,
      tipoCarroceria: tipoCarroceria,
      ufLicenciamento: ufLicenciamento,
      proprietarioCpf: proprietarioCpf,
      proprietarioCnpj: proprietarioCnpj,
      proprietarioRntrc: proprietarioRntrc,
      proprietarioNome: proprietarioNome,
      proprietarioIe: proprietarioIe,
      proprietarioTipo: proprietarioTipo,
      mdfeRodoviarioModel: mdfeRodoviarioModel?.clone(),
    );
  }


}