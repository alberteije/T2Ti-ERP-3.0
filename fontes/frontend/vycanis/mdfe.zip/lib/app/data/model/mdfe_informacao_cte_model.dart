import 'dart:convert';
import 'package:pluto_grid/pluto_grid.dart';
import 'package:mdfe/app/data/model/model_imports.dart';


class MdfeInformacaoCteModel extends ModelBase {
  int? id;
  int? idMdfeMunicipioDescarrega;
  String? chaveCte;
  String? segundoCodigoBarra;
  int? indicadorReentrega;
  MdfeMunicipioDescarregaModel? mdfeMunicipioDescarregaModel;

  MdfeInformacaoCteModel({
    this.id,
    this.idMdfeMunicipioDescarrega,
    this.chaveCte,
    this.segundoCodigoBarra,
    this.indicadorReentrega,
    MdfeMunicipioDescarregaModel? mdfeMunicipioDescarregaModel,
  }) {
    this.mdfeMunicipioDescarregaModel = mdfeMunicipioDescarregaModel ?? MdfeMunicipioDescarregaModel();
  }

  static List<String> dbColumns = <String>[
    'id',
    'chave_cte',
    'segundo_codigo_barra',
    'indicador_reentrega',
  ];

  static List<String> aliasColumns = <String>[
    'Id',
    'Chave Cte',
    'Segundo Codigo Barra',
    'Indicador Reentrega',
  ];

  MdfeInformacaoCteModel.fromJson(Map<String, dynamic> jsonData) {
    id = jsonData['id'];
    idMdfeMunicipioDescarrega = jsonData['idMdfeMunicipioDescarrega'];
    chaveCte = jsonData['chaveCte'];
    segundoCodigoBarra = jsonData['segundoCodigoBarra'];
    indicadorReentrega = jsonData['indicadorReentrega'];
    mdfeMunicipioDescarregaModel = jsonData['mdfeMunicipioDescarregaModel'] == null ? MdfeMunicipioDescarregaModel() : MdfeMunicipioDescarregaModel.fromJson(jsonData['mdfeMunicipioDescarregaModel']);
  }

  Map<String, dynamic> get toJson {
    Map<String, dynamic> jsonData = <String, dynamic>{};

    jsonData['id'] = id != 0 ? id : null;
    jsonData['idMdfeMunicipioDescarrega'] = idMdfeMunicipioDescarrega != 0 ? idMdfeMunicipioDescarrega : null;
    jsonData['chaveCte'] = chaveCte;
    jsonData['segundoCodigoBarra'] = segundoCodigoBarra;
    jsonData['indicadorReentrega'] = indicadorReentrega;
    jsonData['mdfeMunicipioDescarregaModel'] = mdfeMunicipioDescarregaModel?.toJson;
    jsonData['mdfeMunicipioDescarrega'] = mdfeMunicipioDescarregaModel?.nomeMunicipio ?? '';

    return jsonData;
  }

  String objectEncodeJson() {
    final jsonData = toJson;
    return json.encode(jsonData);
  }

  static MdfeInformacaoCteModel fromPlutoRow(PlutoRow row) {
    return MdfeInformacaoCteModel(
      id: row.cells['id']?.value,
      idMdfeMunicipioDescarrega: row.cells['idMdfeMunicipioDescarrega']?.value,
      chaveCte: row.cells['chaveCte']?.value,
      segundoCodigoBarra: row.cells['segundoCodigoBarra']?.value,
      indicadorReentrega: row.cells['indicadorReentrega']?.value,
    );
  }

  PlutoRow toPlutoRow() {
    return PlutoRow(
      cells: {
        'tempId': PlutoCell(value: tempId),
        'id': PlutoCell(value: id ?? 0),
        'idMdfeMunicipioDescarrega': PlutoCell(value: idMdfeMunicipioDescarrega ?? 0),
        'chaveCte': PlutoCell(value: chaveCte ?? ''),
        'segundoCodigoBarra': PlutoCell(value: segundoCodigoBarra ?? ''),
        'indicadorReentrega': PlutoCell(value: indicadorReentrega ?? 0),
        'mdfeMunicipioDescarrega': PlutoCell(value: mdfeMunicipioDescarregaModel?.nomeMunicipio ?? ''),
      },
    );
  }

  MdfeInformacaoCteModel clone() {
    return MdfeInformacaoCteModel(
      id: id,
      idMdfeMunicipioDescarrega: idMdfeMunicipioDescarrega,
      chaveCte: chaveCte,
      segundoCodigoBarra: segundoCodigoBarra,
      indicadorReentrega: indicadorReentrega,
      mdfeMunicipioDescarregaModel: mdfeMunicipioDescarregaModel?.clone(),
    );
  }


}