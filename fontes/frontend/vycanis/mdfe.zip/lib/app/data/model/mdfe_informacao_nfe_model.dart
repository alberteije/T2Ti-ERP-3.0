import 'dart:convert';
import 'package:pluto_grid/pluto_grid.dart';
import 'package:mdfe/app/data/model/model_imports.dart';


class MdfeInformacaoNfeModel extends ModelBase {
  int? id;
  int? idMdfeMunicipioDescarrega;
  String? chaveNfe;
  String? segundoCodigoBarra;
  int? indicadorReentrega;
  MdfeMunicipioDescarregaModel? mdfeMunicipioDescarregaModel;

  MdfeInformacaoNfeModel({
    this.id,
    this.idMdfeMunicipioDescarrega,
    this.chaveNfe,
    this.segundoCodigoBarra,
    this.indicadorReentrega,
    MdfeMunicipioDescarregaModel? mdfeMunicipioDescarregaModel,
  }) {
    this.mdfeMunicipioDescarregaModel = mdfeMunicipioDescarregaModel ?? MdfeMunicipioDescarregaModel();
  }

  static List<String> dbColumns = <String>[
    'id',
    'chave_nfe',
    'segundo_codigo_barra',
    'indicador_reentrega',
  ];

  static List<String> aliasColumns = <String>[
    'Id',
    'Chave Nfe',
    'Segundo Codigo Barra',
    'Indicador Reentrega',
  ];

  MdfeInformacaoNfeModel.fromJson(Map<String, dynamic> jsonData) {
    id = jsonData['id'];
    idMdfeMunicipioDescarrega = jsonData['idMdfeMunicipioDescarrega'];
    chaveNfe = jsonData['chaveNfe'];
    segundoCodigoBarra = jsonData['segundoCodigoBarra'];
    indicadorReentrega = jsonData['indicadorReentrega'];
    mdfeMunicipioDescarregaModel = jsonData['mdfeMunicipioDescarregaModel'] == null ? MdfeMunicipioDescarregaModel() : MdfeMunicipioDescarregaModel.fromJson(jsonData['mdfeMunicipioDescarregaModel']);
  }

  Map<String, dynamic> get toJson {
    Map<String, dynamic> jsonData = <String, dynamic>{};

    jsonData['id'] = id != 0 ? id : null;
    jsonData['idMdfeMunicipioDescarrega'] = idMdfeMunicipioDescarrega != 0 ? idMdfeMunicipioDescarrega : null;
    jsonData['chaveNfe'] = chaveNfe;
    jsonData['segundoCodigoBarra'] = segundoCodigoBarra;
    jsonData['indicadorReentrega'] = indicadorReentrega;
    jsonData['mdfeMunicipioDescarregaModel'] = mdfeMunicipioDescarregaModel?.toJson;
    jsonData['mdfeMunicipioDescarrega'] = mdfeMunicipioDescarregaModel?.nomeMunicipio ?? '';

    return jsonData;
  }

  String objectEncodeJson() {
    final jsonData = toJson;
    return json.encode(jsonData);
  }

  static MdfeInformacaoNfeModel fromPlutoRow(PlutoRow row) {
    return MdfeInformacaoNfeModel(
      id: row.cells['id']?.value,
      idMdfeMunicipioDescarrega: row.cells['idMdfeMunicipioDescarrega']?.value,
      chaveNfe: row.cells['chaveNfe']?.value,
      segundoCodigoBarra: row.cells['segundoCodigoBarra']?.value,
      indicadorReentrega: row.cells['indicadorReentrega']?.value,
    );
  }

  PlutoRow toPlutoRow() {
    return PlutoRow(
      cells: {
        'tempId': PlutoCell(value: tempId),
        'id': PlutoCell(value: id ?? 0),
        'idMdfeMunicipioDescarrega': PlutoCell(value: idMdfeMunicipioDescarrega ?? 0),
        'chaveNfe': PlutoCell(value: chaveNfe ?? ''),
        'segundoCodigoBarra': PlutoCell(value: segundoCodigoBarra ?? ''),
        'indicadorReentrega': PlutoCell(value: indicadorReentrega ?? 0),
        'mdfeMunicipioDescarrega': PlutoCell(value: mdfeMunicipioDescarregaModel?.nomeMunicipio ?? ''),
      },
    );
  }

  MdfeInformacaoNfeModel clone() {
    return MdfeInformacaoNfeModel(
      id: id,
      idMdfeMunicipioDescarrega: idMdfeMunicipioDescarrega,
      chaveNfe: chaveNfe,
      segundoCodigoBarra: segundoCodigoBarra,
      indicadorReentrega: indicadorReentrega,
      mdfeMunicipioDescarregaModel: mdfeMunicipioDescarregaModel?.clone(),
    );
  }


}