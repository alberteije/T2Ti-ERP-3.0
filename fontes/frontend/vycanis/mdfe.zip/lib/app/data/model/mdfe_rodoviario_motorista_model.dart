import 'dart:convert';
import 'package:pluto_grid/pluto_grid.dart';
import 'package:mdfe/app/data/model/model_imports.dart';

import 'package:mdfe/app/infra/infra_imports.dart';

class MdfeRodoviarioMotoristaModel extends ModelBase {
  int? id;
  int? idMdfeRodoviario;
  String? nome;
  String? cpf;
  MdfeRodoviarioModel? mdfeRodoviarioModel;

  MdfeRodoviarioMotoristaModel({
    this.id,
    this.idMdfeRodoviario,
    this.nome,
    this.cpf,
    MdfeRodoviarioModel? mdfeRodoviarioModel,
  }) {
    this.mdfeRodoviarioModel = mdfeRodoviarioModel ?? MdfeRodoviarioModel();
  }

  static List<String> dbColumns = <String>[
    'id',
    'nome',
    'cpf',
  ];

  static List<String> aliasColumns = <String>[
    'Id',
    'Nome',
    'Cpf',
  ];

  MdfeRodoviarioMotoristaModel.fromJson(Map<String, dynamic> jsonData) {
    id = jsonData['id'];
    idMdfeRodoviario = jsonData['idMdfeRodoviario'];
    nome = jsonData['nome'];
    cpf = jsonData['cpf'];
    mdfeRodoviarioModel = jsonData['mdfeRodoviarioModel'] == null ? MdfeRodoviarioModel() : MdfeRodoviarioModel.fromJson(jsonData['mdfeRodoviarioModel']);
  }

  Map<String, dynamic> get toJson {
    Map<String, dynamic> jsonData = <String, dynamic>{};

    jsonData['id'] = id != 0 ? id : null;
    jsonData['idMdfeRodoviario'] = idMdfeRodoviario != 0 ? idMdfeRodoviario : null;
    jsonData['nome'] = nome;
    jsonData['cpf'] = Util.removeMask(cpf);
    jsonData['mdfeRodoviarioModel'] = mdfeRodoviarioModel?.toJson;
    jsonData['mdfeRodoviario'] = mdfeRodoviarioModel?.codigoAgendamento ?? '';

    return jsonData;
  }

  String objectEncodeJson() {
    final jsonData = toJson;
    return json.encode(jsonData);
  }

  static MdfeRodoviarioMotoristaModel fromPlutoRow(PlutoRow row) {
    return MdfeRodoviarioMotoristaModel(
      id: row.cells['id']?.value,
      idMdfeRodoviario: row.cells['idMdfeRodoviario']?.value,
      nome: row.cells['nome']?.value,
      cpf: row.cells['cpf']?.value,
    );
  }

  PlutoRow toPlutoRow() {
    return PlutoRow(
      cells: {
        'tempId': PlutoCell(value: tempId),
        'id': PlutoCell(value: id ?? 0),
        'idMdfeRodoviario': PlutoCell(value: idMdfeRodoviario ?? 0),
        'nome': PlutoCell(value: nome ?? ''),
        'cpf': PlutoCell(value: cpf ?? ''),
        'mdfeRodoviario': PlutoCell(value: mdfeRodoviarioModel?.codigoAgendamento ?? ''),
      },
    );
  }

  MdfeRodoviarioMotoristaModel clone() {
    return MdfeRodoviarioMotoristaModel(
      id: id,
      idMdfeRodoviario: idMdfeRodoviario,
      nome: nome,
      cpf: cpf,
      mdfeRodoviarioModel: mdfeRodoviarioModel?.clone(),
    );
  }


}