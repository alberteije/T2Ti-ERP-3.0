import 'dart:convert';
import 'package:pluto_grid/pluto_grid.dart';
import 'package:mdfe/app/data/model/model_imports.dart';


class MdfeLacreModel extends ModelBase {
  int? id;
  int? idMdfeCabecalho;
  String? numeroLacre;

  MdfeLacreModel({
    this.id,
    this.idMdfeCabecalho,
    this.numeroLacre,
  });

  static List<String> dbColumns = <String>[
    'id',
    'numero_lacre',
  ];

  static List<String> aliasColumns = <String>[
    'Id',
    'Numero Lacre',
  ];

  MdfeLacreModel.fromJson(Map<String, dynamic> jsonData) {
    id = jsonData['id'];
    idMdfeCabecalho = jsonData['idMdfeCabecalho'];
    numeroLacre = jsonData['numeroLacre'];
  }

  Map<String, dynamic> get toJson {
    Map<String, dynamic> jsonData = <String, dynamic>{};

    jsonData['id'] = id != 0 ? id : null;
    jsonData['idMdfeCabecalho'] = idMdfeCabecalho != 0 ? idMdfeCabecalho : null;
    jsonData['numeroLacre'] = numeroLacre;

    return jsonData;
  }

  String objectEncodeJson() {
    final jsonData = toJson;
    return json.encode(jsonData);
  }

  static MdfeLacreModel fromPlutoRow(PlutoRow row) {
    return MdfeLacreModel(
      id: row.cells['id']?.value,
      idMdfeCabecalho: row.cells['idMdfeCabecalho']?.value,
      numeroLacre: row.cells['numeroLacre']?.value,
    );
  }

  PlutoRow toPlutoRow() {
    return PlutoRow(
      cells: {
        'tempId': PlutoCell(value: tempId),
        'id': PlutoCell(value: id ?? 0),
        'idMdfeCabecalho': PlutoCell(value: idMdfeCabecalho ?? 0),
        'numeroLacre': PlutoCell(value: numeroLacre ?? ''),
      },
    );
  }

  MdfeLacreModel clone() {
    return MdfeLacreModel(
      id: id,
      idMdfeCabecalho: idMdfeCabecalho,
      numeroLacre: numeroLacre,
    );
  }


}