// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'auditoria_dao.dart';

// ignore_for_file: type=lint
mixin _$AuditoriaDaoMixin on DatabaseAccessor<AppDatabase> {
  $AuditoriasTable get auditorias => attachedDatabase.auditorias;
}
