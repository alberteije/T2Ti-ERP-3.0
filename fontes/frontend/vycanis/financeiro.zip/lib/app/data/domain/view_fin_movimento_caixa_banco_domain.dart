class ViewFinMovimentoCaixaBancoDomain {
	ViewFinMovimentoCaixaBancoDomain._();

	static getOperacao(String? operacao) { 
		switch (operacao) { 
			case '': 
			case 'E': 
				return 'Entrada'; 
			case 'S': 
				return 'Saída'; 
			default: 
				return null; 
		} 
	} 

	static setOperacao(String? operacao) { 
		switch (operacao) { 
			case 'Entrada': 
				return 'E'; 
			case 'Saída': 
				return 'S'; 
			default: 
				return null; 
		} 
	}

}