import 'dart:convert';
import 'package:pluto_grid/pluto_grid.dart';
import 'package:financeiro/app/data/model/model_imports.dart';

import 'package:financeiro/app/infra/infra_imports.dart';
import 'package:intl/intl.dart';

class FinLancamentoPagarModel extends ModelBase {
  int? id;
  int? idFornecedor;
  int? idBancoContaCaixa;
  int? idFinDocumentoOrigem;
  int? idFinNaturezaFinanceira;
  int? quantidadeParcela;
  double? valorAPagar;
  DateTime? dataLancamento;
  String? numeroDocumento;
  DateTime? primeiroVencimento;
  int? intervaloEntreParcelas;
  String? diaFixo;
  String? imagemDocumento;
  List<FinParcelaPagarModel>? finParcelaPagarModelList;
  FinDocumentoOrigemModel? finDocumentoOrigemModel;
  BancoContaCaixaModel? bancoContaCaixaModel;
  FinNaturezaFinanceiraModel? finNaturezaFinanceiraModel;
  ViewPessoaFornecedorModel? viewPessoaFornecedorModel;

  FinLancamentoPagarModel({
    this.id,
    this.idFornecedor,
    this.idBancoContaCaixa,
    this.idFinDocumentoOrigem,
    this.idFinNaturezaFinanceira,
    this.quantidadeParcela,
    this.valorAPagar,
    this.dataLancamento,
    this.numeroDocumento,
    this.primeiroVencimento,
    this.intervaloEntreParcelas,
    this.diaFixo,
    this.imagemDocumento,
    List<FinParcelaPagarModel>? finParcelaPagarModelList,
    FinDocumentoOrigemModel? finDocumentoOrigemModel,
    BancoContaCaixaModel? bancoContaCaixaModel,
    FinNaturezaFinanceiraModel? finNaturezaFinanceiraModel,
    ViewPessoaFornecedorModel? viewPessoaFornecedorModel,
  }) {
    this.finParcelaPagarModelList = finParcelaPagarModelList?.toList(growable: true) ?? [];
    this.finDocumentoOrigemModel = finDocumentoOrigemModel ?? FinDocumentoOrigemModel();
    this.bancoContaCaixaModel = bancoContaCaixaModel ?? BancoContaCaixaModel();
    this.finNaturezaFinanceiraModel = finNaturezaFinanceiraModel ?? FinNaturezaFinanceiraModel();
    this.viewPessoaFornecedorModel = viewPessoaFornecedorModel ?? ViewPessoaFornecedorModel();
  }

  static List<String> dbColumns = <String>[
    'id',
    'quantidade_parcela',
    'valor_a_pagar',
    'data_lancamento',
    'numero_documento',
    'primeiro_vencimento',
    'intervalo_entre_parcelas',
    'dia_fixo',
    'imagem_documento',
  ];

  static List<String> aliasColumns = <String>[
    'Id',
    'Quantidade Parcela',
    'Valor A Pagar',
    'Data Lancamento',
    'Numero Documento',
    'Primeiro Vencimento',
    'Intervalo Entre Parcelas',
    'Dia Fixo',
    'Imagem Documento',
  ];

  FinLancamentoPagarModel.fromJson(Map<String, dynamic> jsonData) {
    id = jsonData['id'];
    idFornecedor = jsonData['idFornecedor'];
    idBancoContaCaixa = jsonData['idBancoContaCaixa'];
    idFinDocumentoOrigem = jsonData['idFinDocumentoOrigem'];
    idFinNaturezaFinanceira = jsonData['idFinNaturezaFinanceira'];
    quantidadeParcela = jsonData['quantidadeParcela'];
    valorAPagar = jsonData['valorAPagar']?.toDouble();
    dataLancamento = jsonData['dataLancamento'] != null ? DateTime.tryParse(jsonData['dataLancamento']) : null;
    numeroDocumento = jsonData['numeroDocumento'];
    primeiroVencimento = jsonData['primeiroVencimento'] != null ? DateTime.tryParse(jsonData['primeiroVencimento']) : null;
    intervaloEntreParcelas = jsonData['intervaloEntreParcelas'];
    diaFixo = jsonData['diaFixo'];
    imagemDocumento = jsonData['imagemDocumento'];
    finParcelaPagarModelList = (jsonData['finParcelaPagarModelList'] as Iterable?)?.map((m) => FinParcelaPagarModel.fromJson(m)).toList() ?? [];
    finDocumentoOrigemModel = jsonData['finDocumentoOrigemModel'] == null ? FinDocumentoOrigemModel() : FinDocumentoOrigemModel.fromJson(jsonData['finDocumentoOrigemModel']);
    bancoContaCaixaModel = jsonData['bancoContaCaixaModel'] == null ? BancoContaCaixaModel() : BancoContaCaixaModel.fromJson(jsonData['bancoContaCaixaModel']);
    finNaturezaFinanceiraModel = jsonData['finNaturezaFinanceiraModel'] == null ? FinNaturezaFinanceiraModel() : FinNaturezaFinanceiraModel.fromJson(jsonData['finNaturezaFinanceiraModel']);
    viewPessoaFornecedorModel = jsonData['viewPessoaFornecedorModel'] == null ? ViewPessoaFornecedorModel() : ViewPessoaFornecedorModel.fromJson(jsonData['viewPessoaFornecedorModel']);
  }

  Map<String, dynamic> get toJson {
    Map<String, dynamic> jsonData = <String, dynamic>{};

    jsonData['id'] = id != 0 ? id : null;
    jsonData['idFornecedor'] = idFornecedor != 0 ? idFornecedor : null;
    jsonData['idBancoContaCaixa'] = idBancoContaCaixa != 0 ? idBancoContaCaixa : null;
    jsonData['idFinDocumentoOrigem'] = idFinDocumentoOrigem != 0 ? idFinDocumentoOrigem : null;
    jsonData['idFinNaturezaFinanceira'] = idFinNaturezaFinanceira != 0 ? idFinNaturezaFinanceira : null;
    jsonData['quantidadeParcela'] = quantidadeParcela;
    jsonData['valorAPagar'] = valorAPagar;
    jsonData['dataLancamento'] = dataLancamento != null ? DateFormat('yyyy-MM-ddT00:00:00').format(dataLancamento!) : null;
    jsonData['numeroDocumento'] = numeroDocumento;
    jsonData['primeiroVencimento'] = primeiroVencimento != null ? DateFormat('yyyy-MM-ddT00:00:00').format(primeiroVencimento!) : null;
    jsonData['intervaloEntreParcelas'] = intervaloEntreParcelas;
    jsonData['diaFixo'] = diaFixo;
    jsonData['imagemDocumento'] = imagemDocumento;
    
		var finParcelaPagarModelLocalList = []; 
		for (FinParcelaPagarModel object in finParcelaPagarModelList ?? []) { 
			finParcelaPagarModelLocalList.add(object.toJson); 
		}
		jsonData['finParcelaPagarModelList'] = finParcelaPagarModelLocalList;
    jsonData['finDocumentoOrigemModel'] = finDocumentoOrigemModel?.toJson;
    jsonData['finDocumentoOrigem'] = finDocumentoOrigemModel?.sigla ?? '';
    jsonData['bancoContaCaixaModel'] = bancoContaCaixaModel?.toJson;
    jsonData['bancoContaCaixa'] = bancoContaCaixaModel?.nome ?? '';
    jsonData['finNaturezaFinanceiraModel'] = finNaturezaFinanceiraModel?.toJson;
    jsonData['finNaturezaFinanceira'] = finNaturezaFinanceiraModel?.descricao ?? '';
    jsonData['viewPessoaFornecedorModel'] = viewPessoaFornecedorModel?.toJson;
    jsonData['viewPessoaFornecedor'] = viewPessoaFornecedorModel?.nome ?? '';

    return jsonData;
  }

  String objectEncodeJson() {
    final jsonData = toJson;
    return json.encode(jsonData);
  }

  static FinLancamentoPagarModel fromPlutoRow(PlutoRow row) {
    return FinLancamentoPagarModel(
      id: row.cells['id']?.value,
      idFornecedor: row.cells['idFornecedor']?.value,
      idBancoContaCaixa: row.cells['idBancoContaCaixa']?.value,
      idFinDocumentoOrigem: row.cells['idFinDocumentoOrigem']?.value,
      idFinNaturezaFinanceira: row.cells['idFinNaturezaFinanceira']?.value,
      quantidadeParcela: row.cells['quantidadeParcela']?.value,
      valorAPagar: row.cells['valorAPagar']?.value,
      dataLancamento: Util.stringToDate(row.cells['dataLancamento']?.value),
      numeroDocumento: row.cells['numeroDocumento']?.value,
      primeiroVencimento: Util.stringToDate(row.cells['primeiroVencimento']?.value),
      intervaloEntreParcelas: row.cells['intervaloEntreParcelas']?.value,
      diaFixo: row.cells['diaFixo']?.value,
      imagemDocumento: row.cells['imagemDocumento']?.value,
    );
  }

  PlutoRow toPlutoRow() {
    return PlutoRow(
      cells: {
        'tempId': PlutoCell(value: tempId),
        'id': PlutoCell(value: id ?? 0),
        'idFornecedor': PlutoCell(value: idFornecedor ?? 0),
        'idBancoContaCaixa': PlutoCell(value: idBancoContaCaixa ?? 0),
        'idFinDocumentoOrigem': PlutoCell(value: idFinDocumentoOrigem ?? 0),
        'idFinNaturezaFinanceira': PlutoCell(value: idFinNaturezaFinanceira ?? 0),
        'quantidadeParcela': PlutoCell(value: quantidadeParcela ?? 0),
        'valorAPagar': PlutoCell(value: valorAPagar ?? 0.0),
        'dataLancamento': PlutoCell(value: dataLancamento),
        'numeroDocumento': PlutoCell(value: numeroDocumento ?? ''),
        'primeiroVencimento': PlutoCell(value: primeiroVencimento),
        'intervaloEntreParcelas': PlutoCell(value: intervaloEntreParcelas ?? 0),
        'diaFixo': PlutoCell(value: diaFixo ?? ''),
        'imagemDocumento': PlutoCell(value: imagemDocumento ?? ''),
        'finDocumentoOrigem': PlutoCell(value: finDocumentoOrigemModel?.sigla ?? ''),
        'bancoContaCaixa': PlutoCell(value: bancoContaCaixaModel?.nome ?? ''),
        'finNaturezaFinanceira': PlutoCell(value: finNaturezaFinanceiraModel?.descricao ?? ''),
        'viewPessoaFornecedor': PlutoCell(value: viewPessoaFornecedorModel?.nome ?? ''),
      },
    );
  }

  FinLancamentoPagarModel clone() {
    return FinLancamentoPagarModel(
      id: id,
      idFornecedor: idFornecedor,
      idBancoContaCaixa: idBancoContaCaixa,
      idFinDocumentoOrigem: idFinDocumentoOrigem,
      idFinNaturezaFinanceira: idFinNaturezaFinanceira,
      quantidadeParcela: quantidadeParcela,
      valorAPagar: valorAPagar,
      dataLancamento: dataLancamento,
      numeroDocumento: numeroDocumento,
      primeiroVencimento: primeiroVencimento,
      intervaloEntreParcelas: intervaloEntreParcelas,
      diaFixo: diaFixo,
      imagemDocumento: imagemDocumento,
      finParcelaPagarModelList: finParcelaPagarModelListClone(finParcelaPagarModelList!),
      finDocumentoOrigemModel: FinDocumentoOrigemModel.cloneFrom(finDocumentoOrigemModel),
      bancoContaCaixaModel: BancoContaCaixaModel.cloneFrom(bancoContaCaixaModel),
      finNaturezaFinanceiraModel: FinNaturezaFinanceiraModel.cloneFrom(finNaturezaFinanceiraModel),
      viewPessoaFornecedorModel: ViewPessoaFornecedorModel.cloneFrom(viewPessoaFornecedorModel),
    );
  }

  static FinLancamentoPagarModel cloneFrom(FinLancamentoPagarModel? model) {
    return FinLancamentoPagarModel(
      id: model?.id,
      idFornecedor: model?.idFornecedor,
      idBancoContaCaixa: model?.idBancoContaCaixa,
      idFinDocumentoOrigem: model?.idFinDocumentoOrigem,
      idFinNaturezaFinanceira: model?.idFinNaturezaFinanceira,
      quantidadeParcela: model?.quantidadeParcela,
      valorAPagar: model?.valorAPagar,
      dataLancamento: model?.dataLancamento,
      numeroDocumento: model?.numeroDocumento,
      primeiroVencimento: model?.primeiroVencimento,
      intervaloEntreParcelas: model?.intervaloEntreParcelas,
      diaFixo: model?.diaFixo,
      imagemDocumento: model?.imagemDocumento,
      finDocumentoOrigemModel: FinDocumentoOrigemModel.cloneFrom(model?.finDocumentoOrigemModel),
      bancoContaCaixaModel: BancoContaCaixaModel.cloneFrom(model?.bancoContaCaixaModel),
      finNaturezaFinanceiraModel: FinNaturezaFinanceiraModel.cloneFrom(model?.finNaturezaFinanceiraModel),
      viewPessoaFornecedorModel: ViewPessoaFornecedorModel.cloneFrom(model?.viewPessoaFornecedorModel),
    );
  }

  finParcelaPagarModelListClone(List<FinParcelaPagarModel> finParcelaPagarModelList) { 
		List<FinParcelaPagarModel> resultList = [];
		for (var finParcelaPagarModel in finParcelaPagarModelList) {
			resultList.add(FinParcelaPagarModel.cloneFrom(finParcelaPagarModel));
		}
		return resultList;
	}


}