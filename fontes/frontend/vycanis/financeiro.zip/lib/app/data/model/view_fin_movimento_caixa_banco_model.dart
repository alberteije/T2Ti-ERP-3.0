import 'dart:convert';
import 'package:pluto_grid/pluto_grid.dart';
import 'package:financeiro/app/data/model/model_imports.dart';

import 'package:financeiro/app/infra/infra_imports.dart';
import 'package:intl/intl.dart';
import 'package:financeiro/app/data/domain/domain_imports.dart';

class ViewFinMovimentoCaixaBancoModel extends ModelBase {
  int? id;
  int? idBancoContaCaixa;
  String? nomeContaCaixa;
  String? nomePessoa;
  DateTime? dataLancamento;
  DateTime? dataPagoRecebido;
  String? mesAno;
  String? historico;
  double? valor;
  String? descricaoDocumentoOrigem;
  String? operacao;
  BancoContaCaixaModel? bancoContaCaixaModel;

  ViewFinMovimentoCaixaBancoModel({
    this.id,
    this.idBancoContaCaixa,
    this.nomeContaCaixa,
    this.nomePessoa,
    this.dataLancamento,
    this.dataPagoRecebido,
    this.mesAno,
    this.historico,
    this.valor,
    this.descricaoDocumentoOrigem,
    this.operacao = 'Entrada',
    BancoContaCaixaModel? bancoContaCaixaModel,
  }) {
    this.bancoContaCaixaModel = bancoContaCaixaModel ?? BancoContaCaixaModel();
  }

  static List<String> dbColumns = <String>[
    'id',
    'nome_conta_caixa',
    'nome_pessoa',
    'data_lancamento',
    'data_pago_recebido',
    'mes_ano',
    'historico',
    'valor',
    'descricao_documento_origem',
    'operacao',
  ];

  static List<String> aliasColumns = <String>[
    'Id',
    'Nome Conta Caixa',
    'Nome Pessoa',
    'Data Lancamento',
    'Data Pago Recebido',
    'Mes Ano',
    'Historico',
    'Valor',
    'Descricao Documento Origem',
    'Operacao',
  ];

  ViewFinMovimentoCaixaBancoModel.fromJson(Map<String, dynamic> jsonData) {
    id = jsonData['id'];
    idBancoContaCaixa = jsonData['idBancoContaCaixa'];
    nomeContaCaixa = jsonData['nomeContaCaixa'];
    nomePessoa = jsonData['nomePessoa'];
    dataLancamento = jsonData['dataLancamento'] != null ? DateTime.tryParse(jsonData['dataLancamento']) : null;
    dataPagoRecebido = jsonData['dataPagoRecebido'] != null ? DateTime.tryParse(jsonData['dataPagoRecebido']) : null;
    mesAno = jsonData['mesAno'];
    historico = jsonData['historico'];
    valor = jsonData['valor']?.toDouble();
    descricaoDocumentoOrigem = jsonData['descricaoDocumentoOrigem'];
    operacao = ViewFinMovimentoCaixaBancoDomain.getOperacao(jsonData['operacao']);
    bancoContaCaixaModel = jsonData['bancoContaCaixaModel'] == null ? BancoContaCaixaModel() : BancoContaCaixaModel.fromJson(jsonData['bancoContaCaixaModel']);
  }

  Map<String, dynamic> get toJson {
    Map<String, dynamic> jsonData = <String, dynamic>{};

    jsonData['id'] = id != 0 ? id : null;
    jsonData['idBancoContaCaixa'] = idBancoContaCaixa != 0 ? idBancoContaCaixa : null;
    jsonData['nomeContaCaixa'] = nomeContaCaixa;
    jsonData['nomePessoa'] = nomePessoa;
    jsonData['dataLancamento'] = dataLancamento != null ? DateFormat('yyyy-MM-ddT00:00:00').format(dataLancamento!) : null;
    jsonData['dataPagoRecebido'] = dataPagoRecebido != null ? DateFormat('yyyy-MM-ddT00:00:00').format(dataPagoRecebido!) : null;
    jsonData['mesAno'] = mesAno;
    jsonData['historico'] = historico;
    jsonData['valor'] = valor;
    jsonData['descricaoDocumentoOrigem'] = descricaoDocumentoOrigem;
    jsonData['operacao'] = ViewFinMovimentoCaixaBancoDomain.setOperacao(operacao);
    jsonData['bancoContaCaixaModel'] = bancoContaCaixaModel?.toJson;
    jsonData['bancoContaCaixa'] = bancoContaCaixaModel?.nome ?? '';

    return jsonData;
  }

  String objectEncodeJson() {
    final jsonData = toJson;
    return json.encode(jsonData);
  }

  static ViewFinMovimentoCaixaBancoModel fromPlutoRow(PlutoRow row) {
    return ViewFinMovimentoCaixaBancoModel(
      id: row.cells['id']?.value,
      idBancoContaCaixa: row.cells['idBancoContaCaixa']?.value,
      nomeContaCaixa: row.cells['nomeContaCaixa']?.value,
      nomePessoa: row.cells['nomePessoa']?.value,
      dataLancamento: Util.stringToDate(row.cells['dataLancamento']?.value),
      dataPagoRecebido: Util.stringToDate(row.cells['dataPagoRecebido']?.value),
      mesAno: row.cells['mesAno']?.value,
      historico: row.cells['historico']?.value,
      valor: row.cells['valor']?.value,
      descricaoDocumentoOrigem: row.cells['descricaoDocumentoOrigem']?.value,
      operacao: row.cells['operacao']?.value,
    );
  }

  PlutoRow toPlutoRow() {
    return PlutoRow(
      cells: {
        'tempId': PlutoCell(value: tempId),
        'id': PlutoCell(value: id ?? 0),
        'idBancoContaCaixa': PlutoCell(value: idBancoContaCaixa ?? 0),
        'nomeContaCaixa': PlutoCell(value: nomeContaCaixa ?? ''),
        'nomePessoa': PlutoCell(value: nomePessoa ?? ''),
        'dataLancamento': PlutoCell(value: dataLancamento),
        'dataPagoRecebido': PlutoCell(value: dataPagoRecebido),
        'mesAno': PlutoCell(value: mesAno ?? ''),
        'historico': PlutoCell(value: historico ?? ''),
        'valor': PlutoCell(value: valor ?? 0.0),
        'descricaoDocumentoOrigem': PlutoCell(value: descricaoDocumentoOrigem ?? ''),
        'operacao': PlutoCell(value: operacao ?? ''),
        'bancoContaCaixa': PlutoCell(value: bancoContaCaixaModel?.nome ?? ''),
      },
    );
  }

  ViewFinMovimentoCaixaBancoModel clone() {
    return ViewFinMovimentoCaixaBancoModel(
      id: id,
      idBancoContaCaixa: idBancoContaCaixa,
      nomeContaCaixa: nomeContaCaixa,
      nomePessoa: nomePessoa,
      dataLancamento: dataLancamento,
      dataPagoRecebido: dataPagoRecebido,
      mesAno: mesAno,
      historico: historico,
      valor: valor,
      descricaoDocumentoOrigem: descricaoDocumentoOrigem,
      operacao: operacao,
      bancoContaCaixaModel: BancoContaCaixaModel.cloneFrom(bancoContaCaixaModel),
    );
  }

  static ViewFinMovimentoCaixaBancoModel cloneFrom(ViewFinMovimentoCaixaBancoModel? model) {
    return ViewFinMovimentoCaixaBancoModel(
      id: model?.id,
      idBancoContaCaixa: model?.idBancoContaCaixa,
      nomeContaCaixa: model?.nomeContaCaixa,
      nomePessoa: model?.nomePessoa,
      dataLancamento: model?.dataLancamento,
      dataPagoRecebido: model?.dataPagoRecebido,
      mesAno: model?.mesAno,
      historico: model?.historico,
      valor: model?.valor,
      descricaoDocumentoOrigem: model?.descricaoDocumentoOrigem,
      operacao: model?.operacao,
      bancoContaCaixaModel: BancoContaCaixaModel.cloneFrom(model?.bancoContaCaixaModel),
    );
  }


}