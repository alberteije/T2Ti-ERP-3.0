import 'dart:convert';
import 'package:pluto_grid/pluto_grid.dart';
import 'package:financeiro/app/data/model/model_imports.dart';

import 'package:financeiro/app/infra/infra_imports.dart';
import 'package:intl/intl.dart';
import 'package:financeiro/app/data/domain/domain_imports.dart';

class FinFechamentoCaixaBancoModel extends ModelBase {
  int? id;
  int? idBancoContaCaixa;
  DateTime? dataFechamento;
  String? mesAno;
  String? mes;
  String? ano;
  double? saldoAnterior;
  double? recebimentos;
  double? pagamentos;
  double? saldoConta;
  double? chequeNaoCompensado;
  double? saldoDisponivel;
  BancoContaCaixaModel? bancoContaCaixaModel;

  FinFechamentoCaixaBancoModel({
    this.id,
    this.idBancoContaCaixa,
    this.dataFechamento,
    this.mesAno,
    this.mes = 'AAA',
    this.ano = 'AAA',
    this.saldoAnterior,
    this.recebimentos,
    this.pagamentos,
    this.saldoConta,
    this.chequeNaoCompensado,
    this.saldoDisponivel,
    BancoContaCaixaModel? bancoContaCaixaModel,
  }) {
    this.bancoContaCaixaModel = bancoContaCaixaModel ?? BancoContaCaixaModel();
  }

  static List<String> dbColumns = <String>[
    'id',
    'data_fechamento',
    'mes_ano',
    'mes',
    'ano',
    'saldo_anterior',
    'recebimentos',
    'pagamentos',
    'saldo_conta',
    'cheque_nao_compensado',
    'saldo_disponivel',
  ];

  static List<String> aliasColumns = <String>[
    'Id',
    'Data Fechamento',
    'Mes Ano',
    'Mes',
    'Ano',
    'Saldo Anterior',
    'Recebimentos',
    'Pagamentos',
    'Saldo Conta',
    'Cheque Nao Compensado',
    'Saldo Disponivel',
  ];

  FinFechamentoCaixaBancoModel.fromJson(Map<String, dynamic> jsonData) {
    id = jsonData['id'];
    idBancoContaCaixa = jsonData['idBancoContaCaixa'];
    dataFechamento = jsonData['dataFechamento'] != null ? DateTime.tryParse(jsonData['dataFechamento']) : null;
    mesAno = jsonData['mesAno'];
    mes = FinFechamentoCaixaBancoDomain.getMes(jsonData['mes']);
    ano = FinFechamentoCaixaBancoDomain.getAno(jsonData['ano']);
    saldoAnterior = jsonData['saldoAnterior']?.toDouble();
    recebimentos = jsonData['recebimentos']?.toDouble();
    pagamentos = jsonData['pagamentos']?.toDouble();
    saldoConta = jsonData['saldoConta']?.toDouble();
    chequeNaoCompensado = jsonData['chequeNaoCompensado']?.toDouble();
    saldoDisponivel = jsonData['saldoDisponivel']?.toDouble();
    bancoContaCaixaModel = jsonData['bancoContaCaixaModel'] == null ? BancoContaCaixaModel() : BancoContaCaixaModel.fromJson(jsonData['bancoContaCaixaModel']);
  }

  Map<String, dynamic> get toJson {
    Map<String, dynamic> jsonData = <String, dynamic>{};

    jsonData['id'] = id != 0 ? id : null;
    jsonData['idBancoContaCaixa'] = idBancoContaCaixa != 0 ? idBancoContaCaixa : null;
    jsonData['dataFechamento'] = dataFechamento != null ? DateFormat('yyyy-MM-ddT00:00:00').format(dataFechamento!) : null;
    jsonData['mesAno'] = mesAno;
    jsonData['mes'] = FinFechamentoCaixaBancoDomain.setMes(mes);
    jsonData['ano'] = FinFechamentoCaixaBancoDomain.setAno(ano);
    jsonData['saldoAnterior'] = saldoAnterior;
    jsonData['recebimentos'] = recebimentos;
    jsonData['pagamentos'] = pagamentos;
    jsonData['saldoConta'] = saldoConta;
    jsonData['chequeNaoCompensado'] = chequeNaoCompensado;
    jsonData['saldoDisponivel'] = saldoDisponivel;
    jsonData['bancoContaCaixaModel'] = bancoContaCaixaModel?.toJson;
    jsonData['bancoContaCaixa'] = bancoContaCaixaModel?.nome ?? '';

    return jsonData;
  }

  String objectEncodeJson() {
    final jsonData = toJson;
    return json.encode(jsonData);
  }

  static FinFechamentoCaixaBancoModel fromPlutoRow(PlutoRow row) {
    return FinFechamentoCaixaBancoModel(
      id: row.cells['id']?.value,
      idBancoContaCaixa: row.cells['idBancoContaCaixa']?.value,
      dataFechamento: Util.stringToDate(row.cells['dataFechamento']?.value),
      mesAno: row.cells['mesAno']?.value,
      mes: row.cells['mes']?.value,
      ano: row.cells['ano']?.value,
      saldoAnterior: row.cells['saldoAnterior']?.value,
      recebimentos: row.cells['recebimentos']?.value,
      pagamentos: row.cells['pagamentos']?.value,
      saldoConta: row.cells['saldoConta']?.value,
      chequeNaoCompensado: row.cells['chequeNaoCompensado']?.value,
      saldoDisponivel: row.cells['saldoDisponivel']?.value,
    );
  }

  PlutoRow toPlutoRow() {
    return PlutoRow(
      cells: {
        'tempId': PlutoCell(value: tempId),
        'id': PlutoCell(value: id ?? 0),
        'idBancoContaCaixa': PlutoCell(value: idBancoContaCaixa ?? 0),
        'dataFechamento': PlutoCell(value: dataFechamento),
        'mesAno': PlutoCell(value: mesAno ?? ''),
        'mes': PlutoCell(value: mes ?? ''),
        'ano': PlutoCell(value: ano ?? ''),
        'saldoAnterior': PlutoCell(value: saldoAnterior ?? 0.0),
        'recebimentos': PlutoCell(value: recebimentos ?? 0.0),
        'pagamentos': PlutoCell(value: pagamentos ?? 0.0),
        'saldoConta': PlutoCell(value: saldoConta ?? 0.0),
        'chequeNaoCompensado': PlutoCell(value: chequeNaoCompensado ?? 0.0),
        'saldoDisponivel': PlutoCell(value: saldoDisponivel ?? 0.0),
        'bancoContaCaixa': PlutoCell(value: bancoContaCaixaModel?.nome ?? ''),
      },
    );
  }

  FinFechamentoCaixaBancoModel clone() {
    return FinFechamentoCaixaBancoModel(
      id: id,
      idBancoContaCaixa: idBancoContaCaixa,
      dataFechamento: dataFechamento,
      mesAno: mesAno,
      mes: mes,
      ano: ano,
      saldoAnterior: saldoAnterior,
      recebimentos: recebimentos,
      pagamentos: pagamentos,
      saldoConta: saldoConta,
      chequeNaoCompensado: chequeNaoCompensado,
      saldoDisponivel: saldoDisponivel,
      bancoContaCaixaModel: BancoContaCaixaModel.cloneFrom(bancoContaCaixaModel),
    );
  }

  static FinFechamentoCaixaBancoModel cloneFrom(FinFechamentoCaixaBancoModel? model) {
    return FinFechamentoCaixaBancoModel(
      id: model?.id,
      idBancoContaCaixa: model?.idBancoContaCaixa,
      dataFechamento: model?.dataFechamento,
      mesAno: model?.mesAno,
      mes: model?.mes,
      ano: model?.ano,
      saldoAnterior: model?.saldoAnterior,
      recebimentos: model?.recebimentos,
      pagamentos: model?.pagamentos,
      saldoConta: model?.saldoConta,
      chequeNaoCompensado: model?.chequeNaoCompensado,
      saldoDisponivel: model?.saldoDisponivel,
      bancoContaCaixaModel: BancoContaCaixaModel.cloneFrom(model?.bancoContaCaixaModel),
    );
  }


}