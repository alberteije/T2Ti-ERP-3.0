import 'dart:convert';
import 'package:pluto_grid/pluto_grid.dart';
import 'package:financeiro/app/data/model/model_imports.dart';

import 'package:financeiro/app/infra/infra_imports.dart';
import 'package:intl/intl.dart';

class FinParcelaPagarModel extends ModelBase {
  int? id;
  int? idFinLancamentoPagar;
  int? idFinChequeEmitido;
  int? idFinStatusParcela;
  int? idFinTipoPagamento;
  int? numeroParcela;
  DateTime? dataEmissao;
  DateTime? dataVencimento;
  DateTime? dataPagamento;
  DateTime? descontoAte;
  double? valor;
  double? taxaJuro;
  double? taxaMulta;
  double? taxaDesconto;
  double? valorJuro;
  double? valorMulta;
  double? valorDesconto;
  double? valorPago;
  String? historico;
  FinStatusParcelaModel? finStatusParcelaModel;
  FinTipoPagamentoModel? finTipoPagamentoModel;

  FinParcelaPagarModel({
    this.id,
    this.idFinLancamentoPagar,
    this.idFinChequeEmitido,
    this.idFinStatusParcela,
    this.idFinTipoPagamento,
    this.numeroParcela,
    this.dataEmissao,
    this.dataVencimento,
    this.dataPagamento,
    this.descontoAte,
    this.valor,
    this.taxaJuro,
    this.taxaMulta,
    this.taxaDesconto,
    this.valorJuro,
    this.valorMulta,
    this.valorDesconto,
    this.valorPago,
    this.historico,
    FinStatusParcelaModel? finStatusParcelaModel,
    FinTipoPagamentoModel? finTipoPagamentoModel,
  }) {
    this.finStatusParcelaModel = finStatusParcelaModel ?? FinStatusParcelaModel();
    this.finTipoPagamentoModel = finTipoPagamentoModel ?? FinTipoPagamentoModel();
  }

  static List<String> dbColumns = <String>[
    'id',
    'numero_parcela',
    'data_emissao',
    'data_vencimento',
    'data_pagamento',
    'desconto_ate',
    'valor',
    'taxa_juro',
    'taxa_multa',
    'taxa_desconto',
    'valor_juro',
    'valor_multa',
    'valor_desconto',
    'valor_pago',
    'historico',
  ];

  static List<String> aliasColumns = <String>[
    'Id',
    'Numero Parcela',
    'Data Emissao',
    'Data Vencimento',
    'Data Pagamento',
    'Desconto Ate',
    'Valor',
    'Taxa Juro',
    'Taxa Multa',
    'Taxa Desconto',
    'Valor Juro',
    'Valor Multa',
    'Valor Desconto',
    'Valor Pago',
    'Historico',
  ];

  FinParcelaPagarModel.fromJson(Map<String, dynamic> jsonData) {
    id = jsonData['id'];
    idFinLancamentoPagar = jsonData['idFinLancamentoPagar'];
    idFinChequeEmitido = jsonData['idFinChequeEmitido'];
    idFinStatusParcela = jsonData['idFinStatusParcela'];
    idFinTipoPagamento = jsonData['idFinTipoPagamento'];
    numeroParcela = jsonData['numeroParcela'];
    dataEmissao = jsonData['dataEmissao'] != null ? DateTime.tryParse(jsonData['dataEmissao']) : null;
    dataVencimento = jsonData['dataVencimento'] != null ? DateTime.tryParse(jsonData['dataVencimento']) : null;
    dataPagamento = jsonData['dataPagamento'] != null ? DateTime.tryParse(jsonData['dataPagamento']) : null;
    descontoAte = jsonData['descontoAte'] != null ? DateTime.tryParse(jsonData['descontoAte']) : null;
    valor = jsonData['valor']?.toDouble();
    taxaJuro = jsonData['taxaJuro']?.toDouble();
    taxaMulta = jsonData['taxaMulta']?.toDouble();
    taxaDesconto = jsonData['taxaDesconto']?.toDouble();
    valorJuro = jsonData['valorJuro']?.toDouble();
    valorMulta = jsonData['valorMulta']?.toDouble();
    valorDesconto = jsonData['valorDesconto']?.toDouble();
    valorPago = jsonData['valorPago']?.toDouble();
    historico = jsonData['historico'];
    finStatusParcelaModel = jsonData['finStatusParcelaModel'] == null ? FinStatusParcelaModel() : FinStatusParcelaModel.fromJson(jsonData['finStatusParcelaModel']);
    finTipoPagamentoModel = jsonData['finTipoPagamentoModel'] == null ? FinTipoPagamentoModel() : FinTipoPagamentoModel.fromJson(jsonData['finTipoPagamentoModel']);
  }

  Map<String, dynamic> get toJson {
    Map<String, dynamic> jsonData = <String, dynamic>{};

    jsonData['id'] = id != 0 ? id : null;
    jsonData['idFinLancamentoPagar'] = idFinLancamentoPagar != 0 ? idFinLancamentoPagar : null;
    jsonData['idFinChequeEmitido'] = idFinChequeEmitido != 0 ? idFinChequeEmitido : null;
    jsonData['idFinStatusParcela'] = idFinStatusParcela != 0 ? idFinStatusParcela : null;
    jsonData['idFinTipoPagamento'] = idFinTipoPagamento != 0 ? idFinTipoPagamento : null;
    jsonData['numeroParcela'] = numeroParcela;
    jsonData['dataEmissao'] = dataEmissao != null ? DateFormat('yyyy-MM-ddT00:00:00').format(dataEmissao!) : null;
    jsonData['dataVencimento'] = dataVencimento != null ? DateFormat('yyyy-MM-ddT00:00:00').format(dataVencimento!) : null;
    jsonData['dataPagamento'] = dataPagamento != null ? DateFormat('yyyy-MM-ddT00:00:00').format(dataPagamento!) : null;
    jsonData['descontoAte'] = descontoAte != null ? DateFormat('yyyy-MM-ddT00:00:00').format(descontoAte!) : null;
    jsonData['valor'] = valor;
    jsonData['taxaJuro'] = taxaJuro;
    jsonData['taxaMulta'] = taxaMulta;
    jsonData['taxaDesconto'] = taxaDesconto;
    jsonData['valorJuro'] = valorJuro;
    jsonData['valorMulta'] = valorMulta;
    jsonData['valorDesconto'] = valorDesconto;
    jsonData['valorPago'] = valorPago;
    jsonData['historico'] = historico;
    jsonData['finStatusParcelaModel'] = finStatusParcelaModel?.toJson;
    jsonData['finStatusParcela'] = finStatusParcelaModel?.descricao ?? '';
    jsonData['finTipoPagamentoModel'] = finTipoPagamentoModel?.toJson;
    jsonData['finTipoPagamento'] = finTipoPagamentoModel?.descricao ?? '';

    return jsonData;
  }

  String objectEncodeJson() {
    final jsonData = toJson;
    return json.encode(jsonData);
  }

  static FinParcelaPagarModel fromPlutoRow(PlutoRow row) {
    return FinParcelaPagarModel(
      id: row.cells['id']?.value,
      idFinLancamentoPagar: row.cells['idFinLancamentoPagar']?.value,
      idFinChequeEmitido: row.cells['idFinChequeEmitido']?.value,
      idFinStatusParcela: row.cells['idFinStatusParcela']?.value,
      idFinTipoPagamento: row.cells['idFinTipoPagamento']?.value,
      numeroParcela: row.cells['numeroParcela']?.value,
      dataEmissao: Util.stringToDate(row.cells['dataEmissao']?.value),
      dataVencimento: Util.stringToDate(row.cells['dataVencimento']?.value),
      dataPagamento: Util.stringToDate(row.cells['dataPagamento']?.value),
      descontoAte: Util.stringToDate(row.cells['descontoAte']?.value),
      valor: row.cells['valor']?.value,
      taxaJuro: row.cells['taxaJuro']?.value,
      taxaMulta: row.cells['taxaMulta']?.value,
      taxaDesconto: row.cells['taxaDesconto']?.value,
      valorJuro: row.cells['valorJuro']?.value,
      valorMulta: row.cells['valorMulta']?.value,
      valorDesconto: row.cells['valorDesconto']?.value,
      valorPago: row.cells['valorPago']?.value,
      historico: row.cells['historico']?.value,
    );
  }

  PlutoRow toPlutoRow() {
    return PlutoRow(
      cells: {
        'tempId': PlutoCell(value: tempId),
        'id': PlutoCell(value: id ?? 0),
        'idFinLancamentoPagar': PlutoCell(value: idFinLancamentoPagar ?? 0),
        'idFinChequeEmitido': PlutoCell(value: idFinChequeEmitido ?? 0),
        'idFinStatusParcela': PlutoCell(value: idFinStatusParcela ?? 0),
        'idFinTipoPagamento': PlutoCell(value: idFinTipoPagamento ?? 0),
        'numeroParcela': PlutoCell(value: numeroParcela ?? 0),
        'dataEmissao': PlutoCell(value: dataEmissao),
        'dataVencimento': PlutoCell(value: dataVencimento),
        'dataPagamento': PlutoCell(value: dataPagamento),
        'descontoAte': PlutoCell(value: descontoAte),
        'valor': PlutoCell(value: valor ?? 0.0),
        'taxaJuro': PlutoCell(value: taxaJuro ?? 0.0),
        'taxaMulta': PlutoCell(value: taxaMulta ?? 0.0),
        'taxaDesconto': PlutoCell(value: taxaDesconto ?? 0.0),
        'valorJuro': PlutoCell(value: valorJuro ?? 0.0),
        'valorMulta': PlutoCell(value: valorMulta ?? 0.0),
        'valorDesconto': PlutoCell(value: valorDesconto ?? 0.0),
        'valorPago': PlutoCell(value: valorPago ?? 0.0),
        'historico': PlutoCell(value: historico ?? ''),
        'finStatusParcela': PlutoCell(value: finStatusParcelaModel?.descricao ?? ''),
        'finTipoPagamento': PlutoCell(value: finTipoPagamentoModel?.descricao ?? ''),
      },
    );
  }

  FinParcelaPagarModel clone() {
    return FinParcelaPagarModel(
      id: id,
      idFinLancamentoPagar: idFinLancamentoPagar,
      idFinChequeEmitido: idFinChequeEmitido,
      idFinStatusParcela: idFinStatusParcela,
      idFinTipoPagamento: idFinTipoPagamento,
      numeroParcela: numeroParcela,
      dataEmissao: dataEmissao,
      dataVencimento: dataVencimento,
      dataPagamento: dataPagamento,
      descontoAte: descontoAte,
      valor: valor,
      taxaJuro: taxaJuro,
      taxaMulta: taxaMulta,
      taxaDesconto: taxaDesconto,
      valorJuro: valorJuro,
      valorMulta: valorMulta,
      valorDesconto: valorDesconto,
      valorPago: valorPago,
      historico: historico,
      finStatusParcelaModel: FinStatusParcelaModel.cloneFrom(finStatusParcelaModel),
      finTipoPagamentoModel: FinTipoPagamentoModel.cloneFrom(finTipoPagamentoModel),
    );
  }

  static FinParcelaPagarModel cloneFrom(FinParcelaPagarModel? model) {
    return FinParcelaPagarModel(
      id: model?.id,
      idFinLancamentoPagar: model?.idFinLancamentoPagar,
      idFinChequeEmitido: model?.idFinChequeEmitido,
      idFinStatusParcela: model?.idFinStatusParcela,
      idFinTipoPagamento: model?.idFinTipoPagamento,
      numeroParcela: model?.numeroParcela,
      dataEmissao: model?.dataEmissao,
      dataVencimento: model?.dataVencimento,
      dataPagamento: model?.dataPagamento,
      descontoAte: model?.descontoAte,
      valor: model?.valor,
      taxaJuro: model?.taxaJuro,
      taxaMulta: model?.taxaMulta,
      taxaDesconto: model?.taxaDesconto,
      valorJuro: model?.valorJuro,
      valorMulta: model?.valorMulta,
      valorDesconto: model?.valorDesconto,
      valorPago: model?.valorPago,
      historico: model?.historico,
      finStatusParcelaModel: FinStatusParcelaModel.cloneFrom(model?.finStatusParcelaModel),
      finTipoPagamentoModel: FinTipoPagamentoModel.cloneFrom(model?.finTipoPagamentoModel),
    );
  }


}