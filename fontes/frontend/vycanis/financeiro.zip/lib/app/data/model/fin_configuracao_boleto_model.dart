import 'dart:convert';
import 'package:pluto_grid/pluto_grid.dart';
import 'package:financeiro/app/data/model/model_imports.dart';

import 'package:financeiro/app/data/domain/domain_imports.dart';

class FinConfiguracaoBoletoModel extends ModelBase {
  int? id;
  int? idBancoContaCaixa;
  String? instrucao01;
  String? instrucao02;
  String? caminhoArquivoRemessa;
  String? caminhoArquivoRetorno;
  String? caminhoArquivoLogotipo;
  String? caminhoArquivoPdf;
  String? mensagem;
  String? localPagamento;
  String? layoutRemessa;
  String? aceite;
  String? especie;
  String? carteira;
  String? codigoConvenio;
  String? codigoCedente;
  double? taxaMulta;
  double? taxaJuro;
  int? diasProtesto;
  String? nossoNumeroAnterior;
  BancoContaCaixaModel? bancoContaCaixaModel;

  FinConfiguracaoBoletoModel({
    this.id,
    this.idBancoContaCaixa,
    this.instrucao01,
    this.instrucao02,
    this.caminhoArquivoRemessa,
    this.caminhoArquivoRetorno,
    this.caminhoArquivoLogotipo,
    this.caminhoArquivoPdf,
    this.mensagem,
    this.localPagamento,
    this.layoutRemessa = 'CNAB 240',
    this.aceite = 'S',
    this.especie = 'DM-Duplicata Mercantil',
    this.carteira,
    this.codigoConvenio,
    this.codigoCedente,
    this.taxaMulta,
    this.taxaJuro,
    this.diasProtesto,
    this.nossoNumeroAnterior,
    BancoContaCaixaModel? bancoContaCaixaModel,
  }) {
    this.bancoContaCaixaModel = bancoContaCaixaModel ?? BancoContaCaixaModel();
  }

  static List<String> dbColumns = <String>[
    'id',
    'instrucao01',
    'instrucao02',
    'caminho_arquivo_remessa',
    'caminho_arquivo_retorno',
    'caminho_arquivo_logotipo',
    'caminho_arquivo_pdf',
    'mensagem',
    'local_pagamento',
    'layout_remessa',
    'aceite',
    'especie',
    'carteira',
    'codigo_convenio',
    'codigo_cedente',
    'taxa_multa',
    'taxa_juro',
    'dias_protesto',
    'nosso_numero_anterior',
  ];

  static List<String> aliasColumns = <String>[
    'Id',
    'Instrucao01',
    'Instrucao02',
    'Caminho Arquivo Remessa',
    'Caminho Arquivo Retorno',
    'Caminho Arquivo Logotipo',
    'Caminho Arquivo Pdf',
    'Mensagem',
    'Local Pagamento',
    'Layout Remessa',
    'Aceite',
    'Especie',
    'Carteira',
    'Codigo Convenio',
    'Codigo Cedente',
    'Taxa Multa',
    'Taxa Juro',
    'Dias Protesto',
    'Nosso Numero Anterior',
  ];

  FinConfiguracaoBoletoModel.fromJson(Map<String, dynamic> jsonData) {
    id = jsonData['id'];
    idBancoContaCaixa = jsonData['idBancoContaCaixa'];
    instrucao01 = jsonData['instrucao01'];
    instrucao02 = jsonData['instrucao02'];
    caminhoArquivoRemessa = jsonData['caminhoArquivoRemessa'];
    caminhoArquivoRetorno = jsonData['caminhoArquivoRetorno'];
    caminhoArquivoLogotipo = jsonData['caminhoArquivoLogotipo'];
    caminhoArquivoPdf = jsonData['caminhoArquivoPdf'];
    mensagem = jsonData['mensagem'];
    localPagamento = jsonData['localPagamento'];
    layoutRemessa = FinConfiguracaoBoletoDomain.getLayoutRemessa(jsonData['layoutRemessa']);
    aceite = FinConfiguracaoBoletoDomain.getAceite(jsonData['aceite']);
    especie = FinConfiguracaoBoletoDomain.getEspecie(jsonData['especie']);
    carteira = jsonData['carteira'];
    codigoConvenio = jsonData['codigoConvenio'];
    codigoCedente = jsonData['codigoCedente'];
    taxaMulta = jsonData['taxaMulta']?.toDouble();
    taxaJuro = jsonData['taxaJuro']?.toDouble();
    diasProtesto = jsonData['diasProtesto'];
    nossoNumeroAnterior = jsonData['nossoNumeroAnterior'];
    bancoContaCaixaModel = jsonData['bancoContaCaixaModel'] == null ? BancoContaCaixaModel() : BancoContaCaixaModel.fromJson(jsonData['bancoContaCaixaModel']);
  }

  Map<String, dynamic> get toJson {
    Map<String, dynamic> jsonData = <String, dynamic>{};

    jsonData['id'] = id != 0 ? id : null;
    jsonData['idBancoContaCaixa'] = idBancoContaCaixa != 0 ? idBancoContaCaixa : null;
    jsonData['instrucao01'] = instrucao01;
    jsonData['instrucao02'] = instrucao02;
    jsonData['caminhoArquivoRemessa'] = caminhoArquivoRemessa;
    jsonData['caminhoArquivoRetorno'] = caminhoArquivoRetorno;
    jsonData['caminhoArquivoLogotipo'] = caminhoArquivoLogotipo;
    jsonData['caminhoArquivoPdf'] = caminhoArquivoPdf;
    jsonData['mensagem'] = mensagem;
    jsonData['localPagamento'] = localPagamento;
    jsonData['layoutRemessa'] = FinConfiguracaoBoletoDomain.setLayoutRemessa(layoutRemessa);
    jsonData['aceite'] = FinConfiguracaoBoletoDomain.setAceite(aceite);
    jsonData['especie'] = FinConfiguracaoBoletoDomain.setEspecie(especie);
    jsonData['carteira'] = carteira;
    jsonData['codigoConvenio'] = codigoConvenio;
    jsonData['codigoCedente'] = codigoCedente;
    jsonData['taxaMulta'] = taxaMulta;
    jsonData['taxaJuro'] = taxaJuro;
    jsonData['diasProtesto'] = diasProtesto;
    jsonData['nossoNumeroAnterior'] = nossoNumeroAnterior;
    jsonData['bancoContaCaixaModel'] = bancoContaCaixaModel?.toJson;
    jsonData['bancoContaCaixa'] = bancoContaCaixaModel?.nome ?? '';

    return jsonData;
  }

  String objectEncodeJson() {
    final jsonData = toJson;
    return json.encode(jsonData);
  }

  static FinConfiguracaoBoletoModel fromPlutoRow(PlutoRow row) {
    return FinConfiguracaoBoletoModel(
      id: row.cells['id']?.value,
      idBancoContaCaixa: row.cells['idBancoContaCaixa']?.value,
      instrucao01: row.cells['instrucao01']?.value,
      instrucao02: row.cells['instrucao02']?.value,
      caminhoArquivoRemessa: row.cells['caminhoArquivoRemessa']?.value,
      caminhoArquivoRetorno: row.cells['caminhoArquivoRetorno']?.value,
      caminhoArquivoLogotipo: row.cells['caminhoArquivoLogotipo']?.value,
      caminhoArquivoPdf: row.cells['caminhoArquivoPdf']?.value,
      mensagem: row.cells['mensagem']?.value,
      localPagamento: row.cells['localPagamento']?.value,
      layoutRemessa: row.cells['layoutRemessa']?.value,
      aceite: row.cells['aceite']?.value,
      especie: row.cells['especie']?.value,
      carteira: row.cells['carteira']?.value,
      codigoConvenio: row.cells['codigoConvenio']?.value,
      codigoCedente: row.cells['codigoCedente']?.value,
      taxaMulta: row.cells['taxaMulta']?.value,
      taxaJuro: row.cells['taxaJuro']?.value,
      diasProtesto: row.cells['diasProtesto']?.value,
      nossoNumeroAnterior: row.cells['nossoNumeroAnterior']?.value,
    );
  }

  PlutoRow toPlutoRow() {
    return PlutoRow(
      cells: {
        'tempId': PlutoCell(value: tempId),
        'id': PlutoCell(value: id ?? 0),
        'idBancoContaCaixa': PlutoCell(value: idBancoContaCaixa ?? 0),
        'instrucao01': PlutoCell(value: instrucao01 ?? ''),
        'instrucao02': PlutoCell(value: instrucao02 ?? ''),
        'caminhoArquivoRemessa': PlutoCell(value: caminhoArquivoRemessa ?? ''),
        'caminhoArquivoRetorno': PlutoCell(value: caminhoArquivoRetorno ?? ''),
        'caminhoArquivoLogotipo': PlutoCell(value: caminhoArquivoLogotipo ?? ''),
        'caminhoArquivoPdf': PlutoCell(value: caminhoArquivoPdf ?? ''),
        'mensagem': PlutoCell(value: mensagem ?? ''),
        'localPagamento': PlutoCell(value: localPagamento ?? ''),
        'layoutRemessa': PlutoCell(value: layoutRemessa ?? ''),
        'aceite': PlutoCell(value: aceite ?? ''),
        'especie': PlutoCell(value: especie ?? ''),
        'carteira': PlutoCell(value: carteira ?? ''),
        'codigoConvenio': PlutoCell(value: codigoConvenio ?? ''),
        'codigoCedente': PlutoCell(value: codigoCedente ?? ''),
        'taxaMulta': PlutoCell(value: taxaMulta ?? 0.0),
        'taxaJuro': PlutoCell(value: taxaJuro ?? 0.0),
        'diasProtesto': PlutoCell(value: diasProtesto ?? 0),
        'nossoNumeroAnterior': PlutoCell(value: nossoNumeroAnterior ?? ''),
        'bancoContaCaixa': PlutoCell(value: bancoContaCaixaModel?.nome ?? ''),
      },
    );
  }

  FinConfiguracaoBoletoModel clone() {
    return FinConfiguracaoBoletoModel(
      id: id,
      idBancoContaCaixa: idBancoContaCaixa,
      instrucao01: instrucao01,
      instrucao02: instrucao02,
      caminhoArquivoRemessa: caminhoArquivoRemessa,
      caminhoArquivoRetorno: caminhoArquivoRetorno,
      caminhoArquivoLogotipo: caminhoArquivoLogotipo,
      caminhoArquivoPdf: caminhoArquivoPdf,
      mensagem: mensagem,
      localPagamento: localPagamento,
      layoutRemessa: layoutRemessa,
      aceite: aceite,
      especie: especie,
      carteira: carteira,
      codigoConvenio: codigoConvenio,
      codigoCedente: codigoCedente,
      taxaMulta: taxaMulta,
      taxaJuro: taxaJuro,
      diasProtesto: diasProtesto,
      nossoNumeroAnterior: nossoNumeroAnterior,
      bancoContaCaixaModel: BancoContaCaixaModel.cloneFrom(bancoContaCaixaModel),
    );
  }

  static FinConfiguracaoBoletoModel cloneFrom(FinConfiguracaoBoletoModel? model) {
    return FinConfiguracaoBoletoModel(
      id: model?.id,
      idBancoContaCaixa: model?.idBancoContaCaixa,
      instrucao01: model?.instrucao01,
      instrucao02: model?.instrucao02,
      caminhoArquivoRemessa: model?.caminhoArquivoRemessa,
      caminhoArquivoRetorno: model?.caminhoArquivoRetorno,
      caminhoArquivoLogotipo: model?.caminhoArquivoLogotipo,
      caminhoArquivoPdf: model?.caminhoArquivoPdf,
      mensagem: model?.mensagem,
      localPagamento: model?.localPagamento,
      layoutRemessa: model?.layoutRemessa,
      aceite: model?.aceite,
      especie: model?.especie,
      carteira: model?.carteira,
      codigoConvenio: model?.codigoConvenio,
      codigoCedente: model?.codigoCedente,
      taxaMulta: model?.taxaMulta,
      taxaJuro: model?.taxaJuro,
      diasProtesto: model?.diasProtesto,
      nossoNumeroAnterior: model?.nossoNumeroAnterior,
      bancoContaCaixaModel: BancoContaCaixaModel.cloneFrom(model?.bancoContaCaixaModel),
    );
  }


}