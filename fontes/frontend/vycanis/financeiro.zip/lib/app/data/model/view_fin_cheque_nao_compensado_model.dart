import 'dart:convert';
import 'package:pluto_grid/pluto_grid.dart';
import 'package:financeiro/app/data/model/model_imports.dart';

import 'package:financeiro/app/infra/infra_imports.dart';
import 'package:intl/intl.dart';
import 'package:financeiro/app/data/domain/domain_imports.dart';

class ViewFinChequeNaoCompensadoModel extends ModelBase {
  int? id;
  int? idBancoContaCaixa;
  String? nomeContaCaixa;
  String? talao;
  String? numeroTalao;
  String? numeroCheque;
  String? statusCheque;
  DateTime? dataStatus;
  double? valor;
  BancoContaCaixaModel? bancoContaCaixaModel;

  ViewFinChequeNaoCompensadoModel({
    this.id,
    this.idBancoContaCaixa,
    this.nomeContaCaixa,
    this.talao,
    this.numeroTalao,
    this.numeroCheque,
    this.statusCheque = 'Em Ser',
    this.dataStatus,
    this.valor,
    BancoContaCaixaModel? bancoContaCaixaModel,
  }) {
    this.bancoContaCaixaModel = bancoContaCaixaModel ?? BancoContaCaixaModel();
  }

  static List<String> dbColumns = <String>[
    'id',
    'nome_conta_caixa',
    'talao',
    'numero_talao',
    'numero_cheque',
    'status_cheque',
    'data_status',
    'valor',
  ];

  static List<String> aliasColumns = <String>[
    'Id',
    'Nome Conta Caixa',
    'Talao',
    'Numero Talao',
    'Numero Cheque',
    'Status Cheque',
    'Data Status',
    'Valor',
  ];

  ViewFinChequeNaoCompensadoModel.fromJson(Map<String, dynamic> jsonData) {
    id = jsonData['id'];
    idBancoContaCaixa = jsonData['idBancoContaCaixa'];
    nomeContaCaixa = jsonData['nomeContaCaixa'];
    talao = jsonData['talao'];
    numeroTalao = jsonData['numeroTalao']?.toString();
    numeroCheque = jsonData['numeroCheque']?.toString();
    statusCheque = ViewFinChequeNaoCompensadoDomain.getStatusCheque(jsonData['statusCheque']);
    dataStatus = jsonData['dataStatus'] != null ? DateTime.tryParse(jsonData['dataStatus']) : null;
    valor = jsonData['valor']?.toDouble();
    bancoContaCaixaModel = jsonData['bancoContaCaixaModel'] == null ? BancoContaCaixaModel() : BancoContaCaixaModel.fromJson(jsonData['bancoContaCaixaModel']);
  }

  Map<String, dynamic> get toJson {
    Map<String, dynamic> jsonData = <String, dynamic>{};

    jsonData['id'] = id != 0 ? id : null;
    jsonData['idBancoContaCaixa'] = idBancoContaCaixa != 0 ? idBancoContaCaixa : null;
    jsonData['nomeContaCaixa'] = nomeContaCaixa;
    jsonData['talao'] = talao;
    jsonData['numeroTalao'] = numeroTalao;
    jsonData['numeroCheque'] = numeroCheque;
    jsonData['statusCheque'] = ViewFinChequeNaoCompensadoDomain.setStatusCheque(statusCheque);
    jsonData['dataStatus'] = dataStatus != null ? DateFormat('yyyy-MM-ddT00:00:00').format(dataStatus!) : null;
    jsonData['valor'] = valor;
    jsonData['bancoContaCaixaModel'] = bancoContaCaixaModel?.toJson;
    jsonData['bancoContaCaixa'] = bancoContaCaixaModel?.nome ?? '';

    return jsonData;
  }

  String objectEncodeJson() {
    final jsonData = toJson;
    return json.encode(jsonData);
  }

  static ViewFinChequeNaoCompensadoModel fromPlutoRow(PlutoRow row) {
    return ViewFinChequeNaoCompensadoModel(
      id: row.cells['id']?.value,
      idBancoContaCaixa: row.cells['idBancoContaCaixa']?.value,
      nomeContaCaixa: row.cells['nomeContaCaixa']?.value,
      talao: row.cells['talao']?.value,
      numeroTalao: row.cells['numeroTalao']?.value,
      numeroCheque: row.cells['numeroCheque']?.value,
      statusCheque: row.cells['statusCheque']?.value,
      dataStatus: Util.stringToDate(row.cells['dataStatus']?.value),
      valor: row.cells['valor']?.value,
    );
  }

  PlutoRow toPlutoRow() {
    return PlutoRow(
      cells: {
        'tempId': PlutoCell(value: tempId),
        'id': PlutoCell(value: id ?? 0),
        'idBancoContaCaixa': PlutoCell(value: idBancoContaCaixa ?? 0),
        'nomeContaCaixa': PlutoCell(value: nomeContaCaixa ?? ''),
        'talao': PlutoCell(value: talao ?? ''),
        'numeroTalao': PlutoCell(value: numeroTalao ?? ''),
        'numeroCheque': PlutoCell(value: numeroCheque ?? ''),
        'statusCheque': PlutoCell(value: statusCheque ?? ''),
        'dataStatus': PlutoCell(value: dataStatus),
        'valor': PlutoCell(value: valor ?? 0.0),
        'bancoContaCaixa': PlutoCell(value: bancoContaCaixaModel?.nome ?? ''),
      },
    );
  }

  ViewFinChequeNaoCompensadoModel clone() {
    return ViewFinChequeNaoCompensadoModel(
      id: id,
      idBancoContaCaixa: idBancoContaCaixa,
      nomeContaCaixa: nomeContaCaixa,
      talao: talao,
      numeroTalao: numeroTalao,
      numeroCheque: numeroCheque,
      statusCheque: statusCheque,
      dataStatus: dataStatus,
      valor: valor,
      bancoContaCaixaModel: BancoContaCaixaModel.cloneFrom(bancoContaCaixaModel),
    );
  }

  static ViewFinChequeNaoCompensadoModel cloneFrom(ViewFinChequeNaoCompensadoModel? model) {
    return ViewFinChequeNaoCompensadoModel(
      id: model?.id,
      idBancoContaCaixa: model?.idBancoContaCaixa,
      nomeContaCaixa: model?.nomeContaCaixa,
      talao: model?.talao,
      numeroTalao: model?.numeroTalao,
      numeroCheque: model?.numeroCheque,
      statusCheque: model?.statusCheque,
      dataStatus: model?.dataStatus,
      valor: model?.valor,
      bancoContaCaixaModel: BancoContaCaixaModel.cloneFrom(model?.bancoContaCaixaModel),
    );
  }


}