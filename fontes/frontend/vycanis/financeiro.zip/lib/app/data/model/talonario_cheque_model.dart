import 'dart:convert';
import 'package:pluto_grid/pluto_grid.dart';
import 'package:financeiro/app/data/model/model_imports.dart';

import 'package:financeiro/app/data/domain/domain_imports.dart';

class TalonarioChequeModel extends ModelBase {
  int? id;
  int? idBancoContaCaixa;
  String? talao;
  int? numero;
  String? statusTalao;
  List<ChequeModel>? chequeModelList;
  BancoContaCaixaModel? bancoContaCaixaModel;

  TalonarioChequeModel({
    this.id,
    this.idBancoContaCaixa,
    this.talao,
    this.numero,
    this.statusTalao = 'Normal',
    List<ChequeModel>? chequeModelList,
    BancoContaCaixaModel? bancoContaCaixaModel,
  }) {
    this.chequeModelList = chequeModelList?.toList(growable: true) ?? [];
    this.bancoContaCaixaModel = bancoContaCaixaModel ?? BancoContaCaixaModel();
  }

  static List<String> dbColumns = <String>[
    'id',
    'talao',
    'numero',
    'status_talao',
  ];

  static List<String> aliasColumns = <String>[
    'Id',
    'Talao',
    'Numero',
    'Status Talao',
  ];

  TalonarioChequeModel.fromJson(Map<String, dynamic> jsonData) {
    id = jsonData['id'];
    idBancoContaCaixa = jsonData['idBancoContaCaixa'];
    talao = jsonData['talao'];
    numero = jsonData['numero'];
    statusTalao = TalonarioChequeDomain.getStatusTalao(jsonData['statusTalao']);
    chequeModelList = (jsonData['chequeModelList'] as Iterable?)?.map((m) => ChequeModel.fromJson(m)).toList() ?? [];
    bancoContaCaixaModel = jsonData['bancoContaCaixaModel'] == null ? BancoContaCaixaModel() : BancoContaCaixaModel.fromJson(jsonData['bancoContaCaixaModel']);
  }

  Map<String, dynamic> get toJson {
    Map<String, dynamic> jsonData = <String, dynamic>{};

    jsonData['id'] = id != 0 ? id : null;
    jsonData['idBancoContaCaixa'] = idBancoContaCaixa != 0 ? idBancoContaCaixa : null;
    jsonData['talao'] = talao;
    jsonData['numero'] = numero;
    jsonData['statusTalao'] = TalonarioChequeDomain.setStatusTalao(statusTalao);
    
		var chequeModelLocalList = []; 
		for (ChequeModel object in chequeModelList ?? []) { 
			chequeModelLocalList.add(object.toJson); 
		}
		jsonData['chequeModelList'] = chequeModelLocalList;
    jsonData['bancoContaCaixaModel'] = bancoContaCaixaModel?.toJson;
    jsonData['bancoContaCaixa'] = bancoContaCaixaModel?.nome ?? '';

    return jsonData;
  }

  String objectEncodeJson() {
    final jsonData = toJson;
    return json.encode(jsonData);
  }

  static TalonarioChequeModel fromPlutoRow(PlutoRow row) {
    return TalonarioChequeModel(
      id: row.cells['id']?.value,
      idBancoContaCaixa: row.cells['idBancoContaCaixa']?.value,
      talao: row.cells['talao']?.value,
      numero: row.cells['numero']?.value,
      statusTalao: row.cells['statusTalao']?.value,
    );
  }

  PlutoRow toPlutoRow() {
    return PlutoRow(
      cells: {
        'tempId': PlutoCell(value: tempId),
        'id': PlutoCell(value: id ?? 0),
        'idBancoContaCaixa': PlutoCell(value: idBancoContaCaixa ?? 0),
        'talao': PlutoCell(value: talao ?? ''),
        'numero': PlutoCell(value: numero ?? 0),
        'statusTalao': PlutoCell(value: statusTalao ?? ''),
        'bancoContaCaixa': PlutoCell(value: bancoContaCaixaModel?.nome ?? ''),
      },
    );
  }

  TalonarioChequeModel clone() {
    return TalonarioChequeModel(
      id: id,
      idBancoContaCaixa: idBancoContaCaixa,
      talao: talao,
      numero: numero,
      statusTalao: statusTalao,
      chequeModelList: chequeModelListClone(chequeModelList!),
      bancoContaCaixaModel: BancoContaCaixaModel.cloneFrom(bancoContaCaixaModel),
    );
  }

  static TalonarioChequeModel cloneFrom(TalonarioChequeModel? model) {
    return TalonarioChequeModel(
      id: model?.id,
      idBancoContaCaixa: model?.idBancoContaCaixa,
      talao: model?.talao,
      numero: model?.numero,
      statusTalao: model?.statusTalao,
      bancoContaCaixaModel: BancoContaCaixaModel.cloneFrom(model?.bancoContaCaixaModel),
    );
  }

  chequeModelListClone(List<ChequeModel> chequeModelList) { 
		List<ChequeModel> resultList = [];
		for (var chequeModel in chequeModelList) {
			resultList.add(ChequeModel.cloneFrom(chequeModel));
		}
		return resultList;
	}


}