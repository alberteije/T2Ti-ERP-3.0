import 'dart:convert';
import 'package:pluto_grid/pluto_grid.dart';
import 'package:financeiro/app/data/model/model_imports.dart';

import 'package:financeiro/app/infra/infra_imports.dart';
import 'package:intl/intl.dart';

class FinChequeEmitidoModel extends ModelBase {
  int? id;
  int? idCheque;
  DateTime? dataEmissao;
  DateTime? bomPara;
  DateTime? dataCompensacao;
  double? valor;
  String? nominalA;
  ChequeModel? chequeModel;

  FinChequeEmitidoModel({
    this.id,
    this.idCheque,
    this.dataEmissao,
    this.bomPara,
    this.dataCompensacao,
    this.valor,
    this.nominalA,
    ChequeModel? chequeModel,
  }) {
    this.chequeModel = chequeModel ?? ChequeModel();
  }

  static List<String> dbColumns = <String>[
    'id',
    'data_emissao',
    'bom_para',
    'data_compensacao',
    'valor',
    'nominal_a',
  ];

  static List<String> aliasColumns = <String>[
    'Id',
    'Data Emissao',
    'Bom Para',
    'Data Compensacao',
    'Valor',
    'Nominal A',
  ];

  FinChequeEmitidoModel.fromJson(Map<String, dynamic> jsonData) {
    id = jsonData['id'];
    idCheque = jsonData['idCheque'];
    dataEmissao = jsonData['dataEmissao'] != null ? DateTime.tryParse(jsonData['dataEmissao']) : null;
    bomPara = jsonData['bomPara'] != null ? DateTime.tryParse(jsonData['bomPara']) : null;
    dataCompensacao = jsonData['dataCompensacao'] != null ? DateTime.tryParse(jsonData['dataCompensacao']) : null;
    valor = jsonData['valor']?.toDouble();
    nominalA = jsonData['nominalA'];
    chequeModel = jsonData['chequeModel'] == null ? ChequeModel() : ChequeModel.fromJson(jsonData['chequeModel']);
  }

  Map<String, dynamic> get toJson {
    Map<String, dynamic> jsonData = <String, dynamic>{};

    jsonData['id'] = id != 0 ? id : null;
    jsonData['idCheque'] = idCheque != 0 ? idCheque : null;
    jsonData['dataEmissao'] = dataEmissao != null ? DateFormat('yyyy-MM-ddT00:00:00').format(dataEmissao!) : null;
    jsonData['bomPara'] = bomPara != null ? DateFormat('yyyy-MM-ddT00:00:00').format(bomPara!) : null;
    jsonData['dataCompensacao'] = dataCompensacao != null ? DateFormat('yyyy-MM-ddT00:00:00').format(dataCompensacao!) : null;
    jsonData['valor'] = valor;
    jsonData['nominalA'] = nominalA;
    jsonData['chequeModel'] = chequeModel?.toJson;
    jsonData['cheque'] = chequeModel?.numero ?? '';

    return jsonData;
  }

  String objectEncodeJson() {
    final jsonData = toJson;
    return json.encode(jsonData);
  }

  static FinChequeEmitidoModel fromPlutoRow(PlutoRow row) {
    return FinChequeEmitidoModel(
      id: row.cells['id']?.value,
      idCheque: row.cells['idCheque']?.value,
      dataEmissao: Util.stringToDate(row.cells['dataEmissao']?.value),
      bomPara: Util.stringToDate(row.cells['bomPara']?.value),
      dataCompensacao: Util.stringToDate(row.cells['dataCompensacao']?.value),
      valor: row.cells['valor']?.value,
      nominalA: row.cells['nominalA']?.value,
    );
  }

  PlutoRow toPlutoRow() {
    return PlutoRow(
      cells: {
        'tempId': PlutoCell(value: tempId),
        'id': PlutoCell(value: id ?? 0),
        'idCheque': PlutoCell(value: idCheque ?? 0),
        'dataEmissao': PlutoCell(value: dataEmissao),
        'bomPara': PlutoCell(value: bomPara),
        'dataCompensacao': PlutoCell(value: dataCompensacao),
        'valor': PlutoCell(value: valor ?? 0.0),
        'nominalA': PlutoCell(value: nominalA ?? ''),
        'cheque': PlutoCell(value: chequeModel?.numero ?? ''),
      },
    );
  }

  FinChequeEmitidoModel clone() {
    return FinChequeEmitidoModel(
      id: id,
      idCheque: idCheque,
      dataEmissao: dataEmissao,
      bomPara: bomPara,
      dataCompensacao: dataCompensacao,
      valor: valor,
      nominalA: nominalA,
      chequeModel: ChequeModel.cloneFrom(chequeModel),
    );
  }

  static FinChequeEmitidoModel cloneFrom(FinChequeEmitidoModel? model) {
    return FinChequeEmitidoModel(
      id: model?.id,
      idCheque: model?.idCheque,
      dataEmissao: model?.dataEmissao,
      bomPara: model?.bomPara,
      dataCompensacao: model?.dataCompensacao,
      valor: model?.valor,
      nominalA: model?.nominalA,
      chequeModel: ChequeModel.cloneFrom(model?.chequeModel),
    );
  }


}