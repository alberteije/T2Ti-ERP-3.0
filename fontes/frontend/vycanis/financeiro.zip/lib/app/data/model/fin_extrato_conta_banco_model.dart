import 'dart:convert';
import 'package:pluto_grid/pluto_grid.dart';
import 'package:financeiro/app/data/model/model_imports.dart';

import 'package:financeiro/app/infra/infra_imports.dart';
import 'package:intl/intl.dart';
import 'package:financeiro/app/data/domain/domain_imports.dart';

class FinExtratoContaBancoModel extends ModelBase {
  int? id;
  int? idBancoContaCaixa;
  String? mesAno;
  String? mes;
  String? ano;
  DateTime? dataMovimento;
  DateTime? dataBalancete;
  String? historico;
  String? documento;
  double? valor;
  String? conciliado;
  String? observacao;
  BancoContaCaixaModel? bancoContaCaixaModel;

  FinExtratoContaBancoModel({
    this.id,
    this.idBancoContaCaixa,
    this.mesAno,
    this.mes,
    this.ano,
    this.dataMovimento,
    this.dataBalancete,
    this.historico,
    this.documento,
    this.valor,
    this.conciliado = 'S',
    this.observacao,
    BancoContaCaixaModel? bancoContaCaixaModel,
  }) {
    this.bancoContaCaixaModel = bancoContaCaixaModel ?? BancoContaCaixaModel();
  }

  static List<String> dbColumns = <String>[
    'id',
    'mes_ano',
    'mes',
    'ano',
    'data_movimento',
    'data_balancete',
    'historico',
    'documento',
    'valor',
    'conciliado',
    'observacao',
  ];

  static List<String> aliasColumns = <String>[
    'Id',
    'Mes Ano',
    'Mes',
    'Ano',
    'Data Movimento',
    'Data Balancete',
    'Historico',
    'Documento',
    'Valor',
    'Conciliado',
    'Observacao',
  ];

  FinExtratoContaBancoModel.fromJson(Map<String, dynamic> jsonData) {
    id = jsonData['id'];
    idBancoContaCaixa = jsonData['idBancoContaCaixa'];
    mesAno = jsonData['mesAno'];
    mes = jsonData['mes'];
    ano = jsonData['ano'];
    dataMovimento = jsonData['dataMovimento'] != null ? DateTime.tryParse(jsonData['dataMovimento']) : null;
    dataBalancete = jsonData['dataBalancete'] != null ? DateTime.tryParse(jsonData['dataBalancete']) : null;
    historico = jsonData['historico'];
    documento = jsonData['documento'];
    valor = jsonData['valor']?.toDouble();
    conciliado = FinExtratoContaBancoDomain.getConciliado(jsonData['conciliado']);
    observacao = jsonData['observacao'];
    bancoContaCaixaModel = jsonData['bancoContaCaixaModel'] == null ? BancoContaCaixaModel() : BancoContaCaixaModel.fromJson(jsonData['bancoContaCaixaModel']);
  }

  Map<String, dynamic> get toJson {
    Map<String, dynamic> jsonData = <String, dynamic>{};

    jsonData['id'] = id != 0 ? id : null;
    jsonData['idBancoContaCaixa'] = idBancoContaCaixa != 0 ? idBancoContaCaixa : null;
    jsonData['mesAno'] = mesAno;
    jsonData['mes'] = mes;
    jsonData['ano'] = ano;
    jsonData['dataMovimento'] = dataMovimento != null ? DateFormat('yyyy-MM-ddT00:00:00').format(dataMovimento!) : null;
    jsonData['dataBalancete'] = dataBalancete != null ? DateFormat('yyyy-MM-ddT00:00:00').format(dataBalancete!) : null;
    jsonData['historico'] = historico;
    jsonData['documento'] = documento;
    jsonData['valor'] = valor;
    jsonData['conciliado'] = FinExtratoContaBancoDomain.setConciliado(conciliado);
    jsonData['observacao'] = observacao;
    jsonData['bancoContaCaixaModel'] = bancoContaCaixaModel?.toJson;
    jsonData['bancoContaCaixa'] = bancoContaCaixaModel?.nome ?? '';

    return jsonData;
  }

  String objectEncodeJson() {
    final jsonData = toJson;
    return json.encode(jsonData);
  }

  static FinExtratoContaBancoModel fromPlutoRow(PlutoRow row) {
    return FinExtratoContaBancoModel(
      id: row.cells['id']?.value,
      idBancoContaCaixa: row.cells['idBancoContaCaixa']?.value,
      mesAno: row.cells['mesAno']?.value,
      mes: row.cells['mes']?.value,
      ano: row.cells['ano']?.value,
      dataMovimento: Util.stringToDate(row.cells['dataMovimento']?.value),
      dataBalancete: Util.stringToDate(row.cells['dataBalancete']?.value),
      historico: row.cells['historico']?.value,
      documento: row.cells['documento']?.value,
      valor: row.cells['valor']?.value,
      conciliado: row.cells['conciliado']?.value,
      observacao: row.cells['observacao']?.value,
    );
  }

  PlutoRow toPlutoRow() {
    return PlutoRow(
      cells: {
        'tempId': PlutoCell(value: tempId),
        'id': PlutoCell(value: id ?? 0),
        'idBancoContaCaixa': PlutoCell(value: idBancoContaCaixa ?? 0),
        'mesAno': PlutoCell(value: mesAno ?? ''),
        'mes': PlutoCell(value: mes ?? ''),
        'ano': PlutoCell(value: ano ?? ''),
        'dataMovimento': PlutoCell(value: dataMovimento),
        'dataBalancete': PlutoCell(value: dataBalancete),
        'historico': PlutoCell(value: historico ?? ''),
        'documento': PlutoCell(value: documento ?? ''),
        'valor': PlutoCell(value: valor ?? 0.0),
        'conciliado': PlutoCell(value: conciliado ?? ''),
        'observacao': PlutoCell(value: observacao ?? ''),
        'bancoContaCaixa': PlutoCell(value: bancoContaCaixaModel?.nome ?? ''),
      },
    );
  }

  FinExtratoContaBancoModel clone() {
    return FinExtratoContaBancoModel(
      id: id,
      idBancoContaCaixa: idBancoContaCaixa,
      mesAno: mesAno,
      mes: mes,
      ano: ano,
      dataMovimento: dataMovimento,
      dataBalancete: dataBalancete,
      historico: historico,
      documento: documento,
      valor: valor,
      conciliado: conciliado,
      observacao: observacao,
      bancoContaCaixaModel: BancoContaCaixaModel.cloneFrom(bancoContaCaixaModel),
    );
  }

  static FinExtratoContaBancoModel cloneFrom(FinExtratoContaBancoModel? model) {
    return FinExtratoContaBancoModel(
      id: model?.id,
      idBancoContaCaixa: model?.idBancoContaCaixa,
      mesAno: model?.mesAno,
      mes: model?.mes,
      ano: model?.ano,
      dataMovimento: model?.dataMovimento,
      dataBalancete: model?.dataBalancete,
      historico: model?.historico,
      documento: model?.documento,
      valor: model?.valor,
      conciliado: model?.conciliado,
      observacao: model?.observacao,
      bancoContaCaixaModel: BancoContaCaixaModel.cloneFrom(model?.bancoContaCaixaModel),
    );
  }


}