import 'dart:convert';
import 'package:pluto_grid/pluto_grid.dart';
import 'package:financeiro/app/data/model/model_imports.dart';

import 'package:financeiro/app/data/domain/domain_imports.dart';

class FinNaturezaFinanceiraModel extends ModelBase {
  int? id;
  String? codigo;
  String? tipo;
  String? descricao;
  String? aplicacao;

  FinNaturezaFinanceiraModel({
    this.id,
    this.codigo,
    this.tipo = 'Receita',
    this.descricao,
    this.aplicacao,
  });

  static List<String> dbColumns = <String>[
    'id',
    'codigo',
    'tipo',
    'descricao',
    'aplicacao',
  ];

  static List<String> aliasColumns = <String>[
    'Id',
    'Codigo',
    'Tipo',
    'Descricao',
    'Aplicacao',
  ];

  FinNaturezaFinanceiraModel.fromJson(Map<String, dynamic> jsonData) {
    id = jsonData['id'];
    codigo = jsonData['codigo'];
    tipo = FinNaturezaFinanceiraDomain.getTipo(jsonData['tipo']);
    descricao = jsonData['descricao'];
    aplicacao = jsonData['aplicacao'];
  }

  Map<String, dynamic> get toJson {
    Map<String, dynamic> jsonData = <String, dynamic>{};

    jsonData['id'] = id != 0 ? id : null;
    jsonData['codigo'] = codigo;
    jsonData['tipo'] = FinNaturezaFinanceiraDomain.setTipo(tipo);
    jsonData['descricao'] = descricao;
    jsonData['aplicacao'] = aplicacao;

    return jsonData;
  }

  String objectEncodeJson() {
    final jsonData = toJson;
    return json.encode(jsonData);
  }

  static FinNaturezaFinanceiraModel fromPlutoRow(PlutoRow row) {
    return FinNaturezaFinanceiraModel(
      id: row.cells['id']?.value,
      codigo: row.cells['codigo']?.value,
      tipo: row.cells['tipo']?.value,
      descricao: row.cells['descricao']?.value,
      aplicacao: row.cells['aplicacao']?.value,
    );
  }

  PlutoRow toPlutoRow() {
    return PlutoRow(
      cells: {
        'tempId': PlutoCell(value: tempId),
        'id': PlutoCell(value: id ?? 0),
        'codigo': PlutoCell(value: codigo ?? ''),
        'tipo': PlutoCell(value: tipo ?? ''),
        'descricao': PlutoCell(value: descricao ?? ''),
        'aplicacao': PlutoCell(value: aplicacao ?? ''),
      },
    );
  }

  FinNaturezaFinanceiraModel clone() {
    return FinNaturezaFinanceiraModel(
      id: id,
      codigo: codigo,
      tipo: tipo,
      descricao: descricao,
      aplicacao: aplicacao,
    );
  }

  static FinNaturezaFinanceiraModel cloneFrom(FinNaturezaFinanceiraModel? model) {
    return FinNaturezaFinanceiraModel(
      id: model?.id,
      codigo: model?.codigo,
      tipo: model?.tipo,
      descricao: model?.descricao,
      aplicacao: model?.aplicacao,
    );
  }


}