import 'dart:convert';
import 'package:pluto_grid/pluto_grid.dart';
import 'package:financeiro/app/data/model/model_imports.dart';


class BancoAgenciaModel extends ModelBase {
  int? id;
  int? idBanco;
  String? numero;
  String? digito;
  String? nome;
  String? telefone;
  String? contato;
  String? gerente;
  String? observacao;
  BancoModel? bancoModel;

  BancoAgenciaModel({
    this.id,
    this.idBanco,
    this.numero,
    this.digito,
    this.nome,
    this.telefone,
    this.contato,
    this.gerente,
    this.observacao,
    BancoModel? bancoModel,
  }) {
    this.bancoModel = bancoModel ?? BancoModel();
  }

  static List<String> dbColumns = <String>[
    'id',
    'numero',
    'digito',
    'nome',
    'telefone',
    'contato',
    'gerente',
    'observacao',
  ];

  static List<String> aliasColumns = <String>[
    'Id',
    'Numero',
    'Digito',
    'Nome',
    'Telefone',
    'Contato',
    'Gerente',
    'Observacao',
  ];

  BancoAgenciaModel.fromJson(Map<String, dynamic> jsonData) {
    id = jsonData['id'];
    idBanco = jsonData['idBanco'];
    numero = jsonData['numero'];
    digito = jsonData['digito'];
    nome = jsonData['nome'];
    telefone = jsonData['telefone'];
    contato = jsonData['contato'];
    gerente = jsonData['gerente'];
    observacao = jsonData['observacao'];
    bancoModel = jsonData['bancoModel'] == null ? BancoModel() : BancoModel.fromJson(jsonData['bancoModel']);
  }

  Map<String, dynamic> get toJson {
    Map<String, dynamic> jsonData = <String, dynamic>{};

    jsonData['id'] = id != 0 ? id : null;
    jsonData['idBanco'] = idBanco != 0 ? idBanco : null;
    jsonData['numero'] = numero;
    jsonData['digito'] = digito;
    jsonData['nome'] = nome;
    jsonData['telefone'] = telefone;
    jsonData['contato'] = contato;
    jsonData['gerente'] = gerente;
    jsonData['observacao'] = observacao;
    jsonData['bancoModel'] = bancoModel?.toJson;
    jsonData['banco'] = bancoModel?.nome ?? '';

    return jsonData;
  }

  String objectEncodeJson() {
    final jsonData = toJson;
    return json.encode(jsonData);
  }

  static BancoAgenciaModel fromPlutoRow(PlutoRow row) {
    return BancoAgenciaModel(
      id: row.cells['id']?.value,
      idBanco: row.cells['idBanco']?.value,
      numero: row.cells['numero']?.value,
      digito: row.cells['digito']?.value,
      nome: row.cells['nome']?.value,
      telefone: row.cells['telefone']?.value,
      contato: row.cells['contato']?.value,
      gerente: row.cells['gerente']?.value,
      observacao: row.cells['observacao']?.value,
    );
  }

  PlutoRow toPlutoRow() {
    return PlutoRow(
      cells: {
        'tempId': PlutoCell(value: tempId),
        'id': PlutoCell(value: id ?? 0),
        'idBanco': PlutoCell(value: idBanco ?? 0),
        'numero': PlutoCell(value: numero ?? ''),
        'digito': PlutoCell(value: digito ?? ''),
        'nome': PlutoCell(value: nome ?? ''),
        'telefone': PlutoCell(value: telefone ?? ''),
        'contato': PlutoCell(value: contato ?? ''),
        'gerente': PlutoCell(value: gerente ?? ''),
        'observacao': PlutoCell(value: observacao ?? ''),
        'banco': PlutoCell(value: bancoModel?.nome ?? ''),
      },
    );
  }

  BancoAgenciaModel clone() {
    return BancoAgenciaModel(
      id: id,
      idBanco: idBanco,
      numero: numero,
      digito: digito,
      nome: nome,
      telefone: telefone,
      contato: contato,
      gerente: gerente,
      observacao: observacao,
      bancoModel: BancoModel.cloneFrom(bancoModel),
    );
  }

  static BancoAgenciaModel cloneFrom(BancoAgenciaModel? model) {
    return BancoAgenciaModel(
      id: model?.id,
      idBanco: model?.idBanco,
      numero: model?.numero,
      digito: model?.digito,
      nome: model?.nome,
      telefone: model?.telefone,
      contato: model?.contato,
      gerente: model?.gerente,
      observacao: model?.observacao,
      bancoModel: BancoModel.cloneFrom(model?.bancoModel),
    );
  }


}