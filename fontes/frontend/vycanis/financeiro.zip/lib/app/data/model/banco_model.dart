import 'dart:convert';
import 'package:pluto_grid/pluto_grid.dart';
import 'package:financeiro/app/data/model/model_imports.dart';


class BancoModel extends ModelBase {
  int? id;
  String? codigo;
  String? nome;
  String? url;

  BancoModel({
    this.id,
    this.codigo,
    this.nome,
    this.url,
  });

  static List<String> dbColumns = <String>[
    'id',
    'codigo',
    'nome',
    'url',
  ];

  static List<String> aliasColumns = <String>[
    'Id',
    'Codigo',
    'Nome',
    'Url',
  ];

  BancoModel.fromJson(Map<String, dynamic> jsonData) {
    id = jsonData['id'];
    codigo = jsonData['codigo'];
    nome = jsonData['nome'];
    url = jsonData['url'];
  }

  Map<String, dynamic> get toJson {
    Map<String, dynamic> jsonData = <String, dynamic>{};

    jsonData['id'] = id != 0 ? id : null;
    jsonData['codigo'] = codigo;
    jsonData['nome'] = nome;
    jsonData['url'] = url;

    return jsonData;
  }

  String objectEncodeJson() {
    final jsonData = toJson;
    return json.encode(jsonData);
  }

  static BancoModel fromPlutoRow(PlutoRow row) {
    return BancoModel(
      id: row.cells['id']?.value,
      codigo: row.cells['codigo']?.value,
      nome: row.cells['nome']?.value,
      url: row.cells['url']?.value,
    );
  }

  PlutoRow toPlutoRow() {
    return PlutoRow(
      cells: {
        'tempId': PlutoCell(value: tempId),
        'id': PlutoCell(value: id ?? 0),
        'codigo': PlutoCell(value: codigo ?? ''),
        'nome': PlutoCell(value: nome ?? ''),
        'url': PlutoCell(value: url ?? ''),
      },
    );
  }

  BancoModel clone() {
    return BancoModel(
      id: id,
      codigo: codigo,
      nome: nome,
      url: url,
    );
  }

  static BancoModel cloneFrom(BancoModel? model) {
    return BancoModel(
      id: model?.id,
      codigo: model?.codigo,
      nome: model?.nome,
      url: model?.url,
    );
  }


}