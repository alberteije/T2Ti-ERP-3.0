import 'dart:convert';
import 'package:pluto_grid/pluto_grid.dart';
import 'package:financeiro/app/data/model/model_imports.dart';

import 'package:financeiro/app/infra/infra_imports.dart';
import 'package:intl/intl.dart';
import 'package:financeiro/app/data/domain/domain_imports.dart';

class ViewFinFluxoCaixaModel extends ModelBase {
  int? id;
  int? idBancoContaCaixa;
  String? nomeContaCaixa;
  String? nomePessoa;
  DateTime? dataLancamento;
  DateTime? dataVencimento;
  double? valor;
  String? codigoSituacao;
  String? descricaoSituacao;
  String? operacao;
  BancoContaCaixaModel? bancoContaCaixaModel;

  ViewFinFluxoCaixaModel({
    this.id,
    this.idBancoContaCaixa,
    this.nomeContaCaixa,
    this.nomePessoa,
    this.dataLancamento,
    this.dataVencimento,
    this.valor,
    this.codigoSituacao,
    this.descricaoSituacao,
    this.operacao = 'Entrada',
    BancoContaCaixaModel? bancoContaCaixaModel,
  }) {
    this.bancoContaCaixaModel = bancoContaCaixaModel ?? BancoContaCaixaModel();
  }

  static List<String> dbColumns = <String>[
    'id',
    'nome_conta_caixa',
    'nome_pessoa',
    'data_lancamento',
    'data_vencimento',
    'valor',
    'codigo_situacao',
    'descricao_situacao',
    'operacao',
  ];

  static List<String> aliasColumns = <String>[
    'Id',
    'Nome Conta Caixa',
    'Nome Pessoa',
    'Data Lancamento',
    'Data Vencimento',
    'Valor',
    'Codigo Situacao',
    'Descricao Situacao',
    'Operacao',
  ];

  ViewFinFluxoCaixaModel.fromJson(Map<String, dynamic> jsonData) {
    id = jsonData['id'];
    idBancoContaCaixa = jsonData['idBancoContaCaixa'];
    nomeContaCaixa = jsonData['nomeContaCaixa'];
    nomePessoa = jsonData['nomePessoa'];
    dataLancamento = jsonData['dataLancamento'] != null ? DateTime.tryParse(jsonData['dataLancamento']) : null;
    dataVencimento = jsonData['dataVencimento'] != null ? DateTime.tryParse(jsonData['dataVencimento']) : null;
    valor = jsonData['valor']?.toDouble();
    codigoSituacao = jsonData['codigoSituacao'];
    descricaoSituacao = jsonData['descricaoSituacao'];
    operacao = ViewFinFluxoCaixaDomain.getOperacao(jsonData['operacao']);
    bancoContaCaixaModel = jsonData['bancoContaCaixaModel'] == null ? BancoContaCaixaModel() : BancoContaCaixaModel.fromJson(jsonData['bancoContaCaixaModel']);
  }

  Map<String, dynamic> get toJson {
    Map<String, dynamic> jsonData = <String, dynamic>{};

    jsonData['id'] = id != 0 ? id : null;
    jsonData['idBancoContaCaixa'] = idBancoContaCaixa != 0 ? idBancoContaCaixa : null;
    jsonData['nomeContaCaixa'] = nomeContaCaixa;
    jsonData['nomePessoa'] = nomePessoa;
    jsonData['dataLancamento'] = dataLancamento != null ? DateFormat('yyyy-MM-ddT00:00:00').format(dataLancamento!) : null;
    jsonData['dataVencimento'] = dataVencimento != null ? DateFormat('yyyy-MM-ddT00:00:00').format(dataVencimento!) : null;
    jsonData['valor'] = valor;
    jsonData['codigoSituacao'] = codigoSituacao;
    jsonData['descricaoSituacao'] = descricaoSituacao;
    jsonData['operacao'] = ViewFinFluxoCaixaDomain.setOperacao(operacao);
    jsonData['bancoContaCaixaModel'] = bancoContaCaixaModel?.toJson;
    jsonData['bancoContaCaixa'] = bancoContaCaixaModel?.nome ?? '';

    return jsonData;
  }

  String objectEncodeJson() {
    final jsonData = toJson;
    return json.encode(jsonData);
  }

  static ViewFinFluxoCaixaModel fromPlutoRow(PlutoRow row) {
    return ViewFinFluxoCaixaModel(
      id: row.cells['id']?.value,
      idBancoContaCaixa: row.cells['idBancoContaCaixa']?.value,
      nomeContaCaixa: row.cells['nomeContaCaixa']?.value,
      nomePessoa: row.cells['nomePessoa']?.value,
      dataLancamento: Util.stringToDate(row.cells['dataLancamento']?.value),
      dataVencimento: Util.stringToDate(row.cells['dataVencimento']?.value),
      valor: row.cells['valor']?.value,
      codigoSituacao: row.cells['codigoSituacao']?.value,
      descricaoSituacao: row.cells['descricaoSituacao']?.value,
      operacao: row.cells['operacao']?.value,
    );
  }

  PlutoRow toPlutoRow() {
    return PlutoRow(
      cells: {
        'tempId': PlutoCell(value: tempId),
        'id': PlutoCell(value: id ?? 0),
        'idBancoContaCaixa': PlutoCell(value: idBancoContaCaixa ?? 0),
        'nomeContaCaixa': PlutoCell(value: nomeContaCaixa ?? ''),
        'nomePessoa': PlutoCell(value: nomePessoa ?? ''),
        'dataLancamento': PlutoCell(value: dataLancamento),
        'dataVencimento': PlutoCell(value: dataVencimento),
        'valor': PlutoCell(value: valor ?? 0.0),
        'codigoSituacao': PlutoCell(value: codigoSituacao ?? ''),
        'descricaoSituacao': PlutoCell(value: descricaoSituacao ?? ''),
        'operacao': PlutoCell(value: operacao ?? ''),
        'bancoContaCaixa': PlutoCell(value: bancoContaCaixaModel?.nome ?? ''),
      },
    );
  }

  ViewFinFluxoCaixaModel clone() {
    return ViewFinFluxoCaixaModel(
      id: id,
      idBancoContaCaixa: idBancoContaCaixa,
      nomeContaCaixa: nomeContaCaixa,
      nomePessoa: nomePessoa,
      dataLancamento: dataLancamento,
      dataVencimento: dataVencimento,
      valor: valor,
      codigoSituacao: codigoSituacao,
      descricaoSituacao: descricaoSituacao,
      operacao: operacao,
      bancoContaCaixaModel: BancoContaCaixaModel.cloneFrom(bancoContaCaixaModel),
    );
  }

  static ViewFinFluxoCaixaModel cloneFrom(ViewFinFluxoCaixaModel? model) {
    return ViewFinFluxoCaixaModel(
      id: model?.id,
      idBancoContaCaixa: model?.idBancoContaCaixa,
      nomeContaCaixa: model?.nomeContaCaixa,
      nomePessoa: model?.nomePessoa,
      dataLancamento: model?.dataLancamento,
      dataVencimento: model?.dataVencimento,
      valor: model?.valor,
      codigoSituacao: model?.codigoSituacao,
      descricaoSituacao: model?.descricaoSituacao,
      operacao: model?.operacao,
      bancoContaCaixaModel: BancoContaCaixaModel.cloneFrom(model?.bancoContaCaixaModel),
    );
  }


}