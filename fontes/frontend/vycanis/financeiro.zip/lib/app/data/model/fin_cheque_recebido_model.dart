import 'dart:convert';
import 'package:pluto_grid/pluto_grid.dart';
import 'package:financeiro/app/data/model/model_imports.dart';

import 'package:financeiro/app/infra/infra_imports.dart';
import 'package:intl/intl.dart';

class FinChequeRecebidoModel extends ModelBase {
  int? id;
  int? idCliente;
  String? cpf;
  String? cnpj;
  String? nome;
  String? codigoBanco;
  String? codigoAgencia;
  String? conta;
  int? numero;
  DateTime? dataEmissao;
  DateTime? bomPara;
  DateTime? dataCompensacao;
  double? valor;
  DateTime? custodiaData;
  double? custodiaTarifa;
  double? custodiaComissao;
  DateTime? descontoData;
  double? descontoTarifa;
  double? descontoComissao;
  double? valorRecebido;
  ViewPessoaClienteModel? viewPessoaClienteModel;

  FinChequeRecebidoModel({
    this.id,
    this.idCliente,
    this.cpf,
    this.cnpj,
    this.nome,
    this.codigoBanco,
    this.codigoAgencia,
    this.conta,
    this.numero,
    this.dataEmissao,
    this.bomPara,
    this.dataCompensacao,
    this.valor,
    this.custodiaData,
    this.custodiaTarifa,
    this.custodiaComissao,
    this.descontoData,
    this.descontoTarifa,
    this.descontoComissao,
    this.valorRecebido,
    ViewPessoaClienteModel? viewPessoaClienteModel,
  }) {
    this.viewPessoaClienteModel = viewPessoaClienteModel ?? ViewPessoaClienteModel();
  }

  static List<String> dbColumns = <String>[
    'id',
    'cpf',
    'cnpj',
    'nome',
    'codigo_banco',
    'codigo_agencia',
    'conta',
    'numero',
    'data_emissao',
    'bom_para',
    'data_compensacao',
    'valor',
    'custodia_data',
    'custodia_tarifa',
    'custodia_comissao',
    'desconto_data',
    'desconto_tarifa',
    'desconto_comissao',
    'valor_recebido',
  ];

  static List<String> aliasColumns = <String>[
    'Id',
    'Cpf',
    'Cnpj',
    'Nome',
    'Codigo Banco',
    'Codigo Agencia',
    'Conta',
    'Numero',
    'Data Emissao',
    'Bom Para',
    'Data Compensacao',
    'Valor',
    'Custodia Data',
    'Custodia Tarifa',
    'Custodia Comissao',
    'Desconto Data',
    'Desconto Tarifa',
    'Desconto Comissao',
    'Valor Recebido',
  ];

  FinChequeRecebidoModel.fromJson(Map<String, dynamic> jsonData) {
    id = jsonData['id'];
    idCliente = jsonData['idCliente'];
    cpf = jsonData['cpf'];
    cnpj = jsonData['cnpj'];
    nome = jsonData['nome'];
    codigoBanco = jsonData['codigoBanco'];
    codigoAgencia = jsonData['codigoAgencia'];
    conta = jsonData['conta'];
    numero = jsonData['numero'];
    dataEmissao = jsonData['dataEmissao'] != null ? DateTime.tryParse(jsonData['dataEmissao']) : null;
    bomPara = jsonData['bomPara'] != null ? DateTime.tryParse(jsonData['bomPara']) : null;
    dataCompensacao = jsonData['dataCompensacao'] != null ? DateTime.tryParse(jsonData['dataCompensacao']) : null;
    valor = jsonData['valor']?.toDouble();
    custodiaData = jsonData['custodiaData'] != null ? DateTime.tryParse(jsonData['custodiaData']) : null;
    custodiaTarifa = jsonData['custodiaTarifa']?.toDouble();
    custodiaComissao = jsonData['custodiaComissao']?.toDouble();
    descontoData = jsonData['descontoData'] != null ? DateTime.tryParse(jsonData['descontoData']) : null;
    descontoTarifa = jsonData['descontoTarifa']?.toDouble();
    descontoComissao = jsonData['descontoComissao']?.toDouble();
    valorRecebido = jsonData['valorRecebido']?.toDouble();
    viewPessoaClienteModel = jsonData['viewPessoaClienteModel'] == null ? ViewPessoaClienteModel() : ViewPessoaClienteModel.fromJson(jsonData['viewPessoaClienteModel']);
  }

  Map<String, dynamic> get toJson {
    Map<String, dynamic> jsonData = <String, dynamic>{};

    jsonData['id'] = id != 0 ? id : null;
    jsonData['idCliente'] = idCliente != 0 ? idCliente : null;
    jsonData['cpf'] = Util.removeMask(cpf);
    jsonData['cnpj'] = Util.removeMask(cnpj);
    jsonData['nome'] = nome;
    jsonData['codigoBanco'] = codigoBanco;
    jsonData['codigoAgencia'] = codigoAgencia;
    jsonData['conta'] = conta;
    jsonData['numero'] = numero;
    jsonData['dataEmissao'] = dataEmissao != null ? DateFormat('yyyy-MM-ddT00:00:00').format(dataEmissao!) : null;
    jsonData['bomPara'] = bomPara != null ? DateFormat('yyyy-MM-ddT00:00:00').format(bomPara!) : null;
    jsonData['dataCompensacao'] = dataCompensacao != null ? DateFormat('yyyy-MM-ddT00:00:00').format(dataCompensacao!) : null;
    jsonData['valor'] = valor;
    jsonData['custodiaData'] = custodiaData != null ? DateFormat('yyyy-MM-ddT00:00:00').format(custodiaData!) : null;
    jsonData['custodiaTarifa'] = custodiaTarifa;
    jsonData['custodiaComissao'] = custodiaComissao;
    jsonData['descontoData'] = descontoData != null ? DateFormat('yyyy-MM-ddT00:00:00').format(descontoData!) : null;
    jsonData['descontoTarifa'] = descontoTarifa;
    jsonData['descontoComissao'] = descontoComissao;
    jsonData['valorRecebido'] = valorRecebido;
    jsonData['viewPessoaClienteModel'] = viewPessoaClienteModel?.toJson;
    jsonData['viewPessoaCliente'] = viewPessoaClienteModel?.nome ?? '';

    return jsonData;
  }

  String objectEncodeJson() {
    final jsonData = toJson;
    return json.encode(jsonData);
  }

  static FinChequeRecebidoModel fromPlutoRow(PlutoRow row) {
    return FinChequeRecebidoModel(
      id: row.cells['id']?.value,
      idCliente: row.cells['idCliente']?.value,
      cpf: row.cells['cpf']?.value,
      cnpj: row.cells['cnpj']?.value,
      nome: row.cells['nome']?.value,
      codigoBanco: row.cells['codigoBanco']?.value,
      codigoAgencia: row.cells['codigoAgencia']?.value,
      conta: row.cells['conta']?.value,
      numero: row.cells['numero']?.value,
      dataEmissao: Util.stringToDate(row.cells['dataEmissao']?.value),
      bomPara: Util.stringToDate(row.cells['bomPara']?.value),
      dataCompensacao: Util.stringToDate(row.cells['dataCompensacao']?.value),
      valor: row.cells['valor']?.value,
      custodiaData: Util.stringToDate(row.cells['custodiaData']?.value),
      custodiaTarifa: row.cells['custodiaTarifa']?.value,
      custodiaComissao: row.cells['custodiaComissao']?.value,
      descontoData: Util.stringToDate(row.cells['descontoData']?.value),
      descontoTarifa: row.cells['descontoTarifa']?.value,
      descontoComissao: row.cells['descontoComissao']?.value,
      valorRecebido: row.cells['valorRecebido']?.value,
    );
  }

  PlutoRow toPlutoRow() {
    return PlutoRow(
      cells: {
        'tempId': PlutoCell(value: tempId),
        'id': PlutoCell(value: id ?? 0),
        'idCliente': PlutoCell(value: idCliente ?? 0),
        'cpf': PlutoCell(value: cpf ?? ''),
        'cnpj': PlutoCell(value: cnpj ?? ''),
        'nome': PlutoCell(value: nome ?? ''),
        'codigoBanco': PlutoCell(value: codigoBanco ?? ''),
        'codigoAgencia': PlutoCell(value: codigoAgencia ?? ''),
        'conta': PlutoCell(value: conta ?? ''),
        'numero': PlutoCell(value: numero ?? 0),
        'dataEmissao': PlutoCell(value: dataEmissao),
        'bomPara': PlutoCell(value: bomPara),
        'dataCompensacao': PlutoCell(value: dataCompensacao),
        'valor': PlutoCell(value: valor ?? 0.0),
        'custodiaData': PlutoCell(value: custodiaData),
        'custodiaTarifa': PlutoCell(value: custodiaTarifa ?? 0.0),
        'custodiaComissao': PlutoCell(value: custodiaComissao ?? 0.0),
        'descontoData': PlutoCell(value: descontoData),
        'descontoTarifa': PlutoCell(value: descontoTarifa ?? 0.0),
        'descontoComissao': PlutoCell(value: descontoComissao ?? 0.0),
        'valorRecebido': PlutoCell(value: valorRecebido ?? 0.0),
        'viewPessoaCliente': PlutoCell(value: viewPessoaClienteModel?.nome ?? ''),
      },
    );
  }

  FinChequeRecebidoModel clone() {
    return FinChequeRecebidoModel(
      id: id,
      idCliente: idCliente,
      cpf: cpf,
      cnpj: cnpj,
      nome: nome,
      codigoBanco: codigoBanco,
      codigoAgencia: codigoAgencia,
      conta: conta,
      numero: numero,
      dataEmissao: dataEmissao,
      bomPara: bomPara,
      dataCompensacao: dataCompensacao,
      valor: valor,
      custodiaData: custodiaData,
      custodiaTarifa: custodiaTarifa,
      custodiaComissao: custodiaComissao,
      descontoData: descontoData,
      descontoTarifa: descontoTarifa,
      descontoComissao: descontoComissao,
      valorRecebido: valorRecebido,
      viewPessoaClienteModel: ViewPessoaClienteModel.cloneFrom(viewPessoaClienteModel),
    );
  }

  static FinChequeRecebidoModel cloneFrom(FinChequeRecebidoModel? model) {
    return FinChequeRecebidoModel(
      id: model?.id,
      idCliente: model?.idCliente,
      cpf: model?.cpf,
      cnpj: model?.cnpj,
      nome: model?.nome,
      codigoBanco: model?.codigoBanco,
      codigoAgencia: model?.codigoAgencia,
      conta: model?.conta,
      numero: model?.numero,
      dataEmissao: model?.dataEmissao,
      bomPara: model?.bomPara,
      dataCompensacao: model?.dataCompensacao,
      valor: model?.valor,
      custodiaData: model?.custodiaData,
      custodiaTarifa: model?.custodiaTarifa,
      custodiaComissao: model?.custodiaComissao,
      descontoData: model?.descontoData,
      descontoTarifa: model?.descontoTarifa,
      descontoComissao: model?.descontoComissao,
      valorRecebido: model?.valorRecebido,
      viewPessoaClienteModel: ViewPessoaClienteModel.cloneFrom(model?.viewPessoaClienteModel),
    );
  }


}