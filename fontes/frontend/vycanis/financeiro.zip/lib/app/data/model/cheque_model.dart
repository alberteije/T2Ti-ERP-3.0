import 'dart:convert';
import 'package:pluto_grid/pluto_grid.dart';
import 'package:financeiro/app/data/model/model_imports.dart';

import 'package:financeiro/app/infra/infra_imports.dart';
import 'package:intl/intl.dart';
import 'package:financeiro/app/data/domain/domain_imports.dart';

class ChequeModel extends ModelBase {
  int? id;
  int? idTalonarioCheque;
  int? numero;
  String? statusCheque;
  DateTime? dataStatus;

  ChequeModel({
    this.id,
    this.idTalonarioCheque,
    this.numero,
    this.statusCheque = 'Em Ser',
    this.dataStatus,
  });

  static List<String> dbColumns = <String>[
    'id',
    'numero',
    'status_cheque',
    'data_status',
  ];

  static List<String> aliasColumns = <String>[
    'Id',
    'Numero',
    'Status Cheque',
    'Data Status',
  ];

  ChequeModel.fromJson(Map<String, dynamic> jsonData) {
    id = jsonData['id'];
    idTalonarioCheque = jsonData['idTalonarioCheque'];
    numero = jsonData['numero'];
    statusCheque = ChequeDomain.getStatusCheque(jsonData['statusCheque']);
    dataStatus = jsonData['dataStatus'] != null ? DateTime.tryParse(jsonData['dataStatus']) : null;
  }

  Map<String, dynamic> get toJson {
    Map<String, dynamic> jsonData = <String, dynamic>{};

    jsonData['id'] = id != 0 ? id : null;
    jsonData['idTalonarioCheque'] = idTalonarioCheque != 0 ? idTalonarioCheque : null;
    jsonData['numero'] = numero;
    jsonData['statusCheque'] = ChequeDomain.setStatusCheque(statusCheque);
    jsonData['dataStatus'] = dataStatus != null ? DateFormat('yyyy-MM-ddT00:00:00').format(dataStatus!) : null;

    return jsonData;
  }

  String objectEncodeJson() {
    final jsonData = toJson;
    return json.encode(jsonData);
  }

  static ChequeModel fromPlutoRow(PlutoRow row) {
    return ChequeModel(
      id: row.cells['id']?.value,
      idTalonarioCheque: row.cells['idTalonarioCheque']?.value,
      numero: row.cells['numero']?.value,
      statusCheque: row.cells['statusCheque']?.value,
      dataStatus: Util.stringToDate(row.cells['dataStatus']?.value),
    );
  }

  PlutoRow toPlutoRow() {
    return PlutoRow(
      cells: {
        'tempId': PlutoCell(value: tempId),
        'id': PlutoCell(value: id ?? 0),
        'idTalonarioCheque': PlutoCell(value: idTalonarioCheque ?? 0),
        'numero': PlutoCell(value: numero ?? 0),
        'statusCheque': PlutoCell(value: statusCheque ?? ''),
        'dataStatus': PlutoCell(value: dataStatus),
      },
    );
  }

  ChequeModel clone() {
    return ChequeModel(
      id: id,
      idTalonarioCheque: idTalonarioCheque,
      numero: numero,
      statusCheque: statusCheque,
      dataStatus: dataStatus,
    );
  }

  static ChequeModel cloneFrom(ChequeModel? model) {
    return ChequeModel(
      id: model?.id,
      idTalonarioCheque: model?.idTalonarioCheque,
      numero: model?.numero,
      statusCheque: model?.statusCheque,
      dataStatus: model?.dataStatus,
    );
  }


}