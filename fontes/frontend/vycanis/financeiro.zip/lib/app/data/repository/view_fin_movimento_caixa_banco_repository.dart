import 'package:financeiro/app/infra/constants.dart';
import 'package:financeiro/app/data/provider/api/view_fin_movimento_caixa_banco_api_provider.dart';
import 'package:financeiro/app/data/provider/drift/view_fin_movimento_caixa_banco_drift_provider.dart';
import 'package:financeiro/app/data/model/model_imports.dart';

class ViewFinMovimentoCaixaBancoRepository {
  final ViewFinMovimentoCaixaBancoApiProvider viewFinMovimentoCaixaBancoApiProvider;
  final ViewFinMovimentoCaixaBancoDriftProvider viewFinMovimentoCaixaBancoDriftProvider;

  ViewFinMovimentoCaixaBancoRepository({required this.viewFinMovimentoCaixaBancoApiProvider, required this.viewFinMovimentoCaixaBancoDriftProvider});

  Future getList({Filter? filter}) async {
    if (Constants.usingLocalDatabase) {
      return await viewFinMovimentoCaixaBancoDriftProvider.getList(filter: filter);
    } else {
      return await viewFinMovimentoCaixaBancoApiProvider.getList(filter: filter);
    }
  }

}