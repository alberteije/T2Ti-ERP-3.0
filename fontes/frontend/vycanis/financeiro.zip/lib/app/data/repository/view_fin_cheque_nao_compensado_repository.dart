import 'package:financeiro/app/infra/constants.dart';
import 'package:financeiro/app/data/provider/api/view_fin_cheque_nao_compensado_api_provider.dart';
import 'package:financeiro/app/data/provider/drift/view_fin_cheque_nao_compensado_drift_provider.dart';
import 'package:financeiro/app/data/model/model_imports.dart';

class ViewFinChequeNaoCompensadoRepository {
  final ViewFinChequeNaoCompensadoApiProvider viewFinChequeNaoCompensadoApiProvider;
  final ViewFinChequeNaoCompensadoDriftProvider viewFinChequeNaoCompensadoDriftProvider;

  ViewFinChequeNaoCompensadoRepository({required this.viewFinChequeNaoCompensadoApiProvider, required this.viewFinChequeNaoCompensadoDriftProvider});

  Future getList({Filter? filter}) async {
    if (Constants.usingLocalDatabase) {
      return await viewFinChequeNaoCompensadoDriftProvider.getList(filter: filter);
    } else {
      return await viewFinChequeNaoCompensadoApiProvider.getList(filter: filter);
    }
  }

  Future<ViewFinChequeNaoCompensadoModel?>? save({required ViewFinChequeNaoCompensadoModel viewFinChequeNaoCompensadoModel}) async {
    if (viewFinChequeNaoCompensadoModel.id != null) {
      if (Constants.usingLocalDatabase) {
        return await viewFinChequeNaoCompensadoDriftProvider.update(viewFinChequeNaoCompensadoModel);
      } else {
        return await viewFinChequeNaoCompensadoApiProvider.update(viewFinChequeNaoCompensadoModel);
      }
    } else {
      if (Constants.usingLocalDatabase) {
        return await viewFinChequeNaoCompensadoDriftProvider.insert(viewFinChequeNaoCompensadoModel);
      } else {
        return await viewFinChequeNaoCompensadoApiProvider.insert(viewFinChequeNaoCompensadoModel);
      }
    }   
  }

  Future<bool> delete({required int id}) async {
    if (Constants.usingLocalDatabase) {
      return await viewFinChequeNaoCompensadoDriftProvider.delete(id) ?? false;
    } else {
      return await viewFinChequeNaoCompensadoApiProvider.delete(id) ?? false;
    }
  }
}