import 'package:financeiro/app/infra/constants.dart';
import 'package:financeiro/app/data/provider/api/view_fin_fluxo_caixa_api_provider.dart';
import 'package:financeiro/app/data/provider/drift/view_fin_fluxo_caixa_drift_provider.dart';
import 'package:financeiro/app/data/model/model_imports.dart';

class ViewFinFluxoCaixaRepository {
  final ViewFinFluxoCaixaApiProvider viewFinFluxoCaixaApiProvider;
  final ViewFinFluxoCaixaDriftProvider viewFinFluxoCaixaDriftProvider;

  ViewFinFluxoCaixaRepository({required this.viewFinFluxoCaixaApiProvider, required this.viewFinFluxoCaixaDriftProvider});

  Future getList({Filter? filter}) async {
    if (Constants.usingLocalDatabase) {
      return await viewFinFluxoCaixaDriftProvider.getList(filter: filter);
    } else {
      return await viewFinFluxoCaixaApiProvider.getList(filter: filter);
    }
  }

  Future<ViewFinFluxoCaixaModel?>? save({required ViewFinFluxoCaixaModel viewFinFluxoCaixaModel}) async {
    if (viewFinFluxoCaixaModel.id != null) {
      if (Constants.usingLocalDatabase) {
        return await viewFinFluxoCaixaDriftProvider.update(viewFinFluxoCaixaModel);
      } else {
        return await viewFinFluxoCaixaApiProvider.update(viewFinFluxoCaixaModel);
      }
    } else {
      if (Constants.usingLocalDatabase) {
        return await viewFinFluxoCaixaDriftProvider.insert(viewFinFluxoCaixaModel);
      } else {
        return await viewFinFluxoCaixaApiProvider.insert(viewFinFluxoCaixaModel);
      }
    }   
  }

  Future<bool> delete({required int id}) async {
    if (Constants.usingLocalDatabase) {
      return await viewFinFluxoCaixaDriftProvider.delete(id) ?? false;
    } else {
      return await viewFinFluxoCaixaApiProvider.delete(id) ?? false;
    }
  }
}