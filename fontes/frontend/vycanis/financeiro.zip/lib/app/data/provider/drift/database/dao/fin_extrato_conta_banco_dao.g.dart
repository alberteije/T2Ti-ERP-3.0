// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'fin_extrato_conta_banco_dao.dart';

// ignore_for_file: type=lint
mixin _$FinExtratoContaBancoDaoMixin on DatabaseAccessor<AppDatabase> {
  $FinExtratoContaBancosTable get finExtratoContaBancos =>
      attachedDatabase.finExtratoContaBancos;
  $BancoContaCaixasTable get bancoContaCaixas =>
      attachedDatabase.bancoContaCaixas;
}
